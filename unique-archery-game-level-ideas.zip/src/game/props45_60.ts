import { Ctx, V, v, add, clamp, circle, shape, stroke, fromAngle } from './util';
import { drawApple } from './gear';
import { APPLE_R } from './target';

/** Level 45: Zipline pulley trolley + foothold */
export function drawZiplineTrolley(ctx: Ctx, cableA: V, cableB: V, riderFoot: V, col = '#ef4444') {
  stroke(ctx, [cableA, cableB], '#64748b', 3.5, 'butt');
  // Find point on cable above riderFoot.x
  const t = clamp((riderFoot.x - cableA.x) / ((cableB.x - cableA.x) || 1), 0, 1);
  const pulley = v(riderFoot.x, cableA.y + (cableB.y - cableA.y) * t);
  // Hanger rod from pulley down to stirrup under feet
  stroke(ctx, [pulley, v(riderFoot.x, riderFoot.y + 4)], '#475569', 3);
  shape(ctx, (p) => p.roundRect(riderFoot.x - 24, riderFoot.y + 2, 48, 7, 3), col);
  shape(ctx, (p) => p.roundRect(pulley.x - 14, pulley.y - 9, 28, 16, 5), col);
  circle(ctx, v(pulley.x - 6, pulley.y - 1), 4.5, '#1e293b');
  circle(ctx, v(pulley.x + 6, pulley.y - 1), 4.5, '#1e293b');
}

/** Level 46: Hovering security drone with laser barrier */
export function drawSecurityDrone(ctx: Ctx, c: V, time: number, alive: boolean, laserH = 115) {
  if (!alive) return;
  ctx.save();
  ctx.translate(c.x, c.y);
  // Laser beam emitter below drone
  const pulse = 0.55 + 0.35 * Math.sin(time * 22);
  ctx.globalAlpha = pulse * 0.35;
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(-5, 12, 10, laserH);
  ctx.globalAlpha = pulse;
  ctx.fillStyle = '#fca5a5';
  ctx.fillRect(-2, 12, 4, laserH);
  ctx.globalAlpha = 1;

  // Spinning top rotor blades
  const bladeW = 28 * Math.cos(time * 38);
  stroke(ctx, [v(-22, -14), v(-22, -7)], '#475569', 3);
  stroke(ctx, [v(22, -14), v(22, -7)], '#475569', 3);
  stroke(ctx, [v(-22 - bladeW * 0.5, -15), v(-22 + bladeW * 0.5, -15)], '#94a3b8', 3.5);
  stroke(ctx, [v(22 - bladeW * 0.5, -15), v(22 + bladeW * 0.5, -15)], '#94a3b8', 3.5);

  // Drone armored hull
  shape(ctx, (p) => p.roundRect(-26, -10, 52, 22, 10), '#1e293b');
  shape(ctx, (p) => p.roundRect(-20, -6, 40, 14, 6), '#334155');
  // Glowing red scanner eye (shootable weakspot!)
  circle(ctx, v(0, 1), 7.5, '#dc2626');
  circle(ctx, v(-2, -1), 3, '#fecaca');
  ctx.restore();
}

/** Level 47: Giant Wooden Slingshot */
export function drawGiantSlingshot(ctx: Ctx, base: V, pouch: V, released: boolean) {
  const forkL = v(base.x - 18, base.y - 128);
  const forkR = v(base.x + 18, base.y - 118);
  if (!released) {
    stroke(ctx, [forkR, pouch], '#991b1b', 5);
  }
  // Y-frame wooden post
  stroke(ctx, [base, v(base.x, base.y - 72)], '#8a5a2e', 16, 'butt');
  stroke(ctx, [v(base.x, base.y - 70), forkL], '#a16836', 12);
  stroke(ctx, [v(base.x, base.y - 70), forkR], '#784c25', 12);
  if (!released) {
    // Anchor rope tied to ground peg (shootable!)
    const peg = v(pouch.x + 56, base.y);
    stroke(ctx, [v(peg.x, peg.y), v(peg.x + 6, peg.y - 22)], '#475569', 6);
    stroke(ctx, [pouch, v(peg.x + 3, peg.y - 16)], '#ef4444', 4);
    circle(ctx, v((pouch.x + peg.x) * 0.5, (pouch.y + peg.y - 16) * 0.5), 9, '#ef4444');
    circle(ctx, v((pouch.x + peg.x) * 0.5, (pouch.y + peg.y - 16) * 0.5), 4, '#ffffff');
    // Leather pouch
    shape(ctx, (p) => p.roundRect(pouch.x - 18, pouch.y - 14, 32, 28, 8), '#5c3a21');
    stroke(ctx, [forkL, pouch], '#dc2626', 5.5);
  }
}

/** Level 48: Crystalline Icicle & Ice Shield */
export function drawIcicle(ctx: Ctx, p: V, h: number) {
  shape(
    ctx,
    (q) => {
      q.moveTo(p.x - 14, p.y);
      q.lineTo(p.x + 14, p.y);
      q.lineTo(p.x + 4, p.y + h * 0.7);
      q.lineTo(p.x, p.y + h);
      q.lineTo(p.x - 5, p.y + h * 0.65);
      q.closePath();
    },
    '#38bdf8',
  );
  shape(
    ctx,
    (q) => {
      q.moveTo(p.x - 11, p.y);
      q.lineTo(p.x - 1, p.y);
      q.lineTo(p.x - 1, p.y + h * 0.82);
      q.closePath();
    },
    '#bae6fd',
  );
  // Target ring at top of icicle
  circle(ctx, v(p.x, p.y + 12), 6, '#ef4444');
  circle(ctx, v(p.x, p.y + 12), 2.5, '#ffffff');
}

/** Level 50: Giant Red-Light Green-Light Robot Doll */
export function drawRobotDoll(ctx: Ctx, x: number, groundY: number, light: 'green' | 'yellow' | 'red', time: number, beamTo: V | null) {
  ctx.save();
  ctx.translate(x, groundY);
  // Pedestal
  shape(ctx, (p) => p.roundRect(-34, -36, 68, 36, 6), '#475569');
  // Legs & Dress
  shape(ctx, (p) => p.roundRect(-18, -82, 12, 48, 5), '#fde68a');
  shape(ctx, (p) => p.roundRect(6, -82, 12, 48, 5), '#fde68a');
  shape(
    ctx,
    (p) => {
      p.moveTo(-22, -162);
      p.lineTo(22, -162);
      p.lineTo(34, -80);
      p.lineTo(-34, -80);
      p.closePath();
    },
    '#f97316',
  );
  shape(ctx, (p) => p.roundRect(-24, -168, 48, 26, 6), '#facc15');

  // Head (turns around when green!)
  const headY = -198;
  circle(ctx, v(-28, headY - 4), 10, '#1e293b');
  circle(ctx, v(28, headY - 4), 10, '#1e293b');
  circle(ctx, v(0, headY), 26, '#fde68a');

  if (light === 'green') {
    // Back of the doll's hair (safe to shoot!)
    shape(
      ctx,
      (p) => {
        p.arc(0, headY, 26, 0, Math.PI * 2);
      },
      '#1e293b',
    );
    stroke(ctx, [v(-16, headY), v(16, headY)], '#f97316', 4);
  } else {
    // Bangs + scanning eyes
    shape(
      ctx,
      (p) => {
        p.arc(0, headY - 4, 25, Math.PI, Math.PI * 2);
      },
      '#1e293b',
    );
    const eyeCol = light === 'red' ? '#ef4444' : '#fbbf24';
    circle(ctx, v(-9, headY - 2), 5.5, '#1e293b');
    circle(ctx, v(9, headY - 2), 5.5, '#1e293b');
    circle(ctx, v(-9, headY - 2), 3.8, eyeCol);
    circle(ctx, v(9, headY - 2), 3.8, eyeCol);
    shape(ctx, (p) => p.roundRect(-7, headY + 9, 14, 5, 2.5), '#dc2626');
  }

  // Traffic light beacon above doll
  const beaconY = -246;
  shape(ctx, (p) => p.roundRect(-30, beaconY - 14, 60, 28, 14), '#111827');
  const cols: [string, string][] = [['red', '#ef4444'], ['yellow', '#fbbf24'], ['green', '#22c55e']];
  cols.forEach(([name, c], i) => {
    const on = light === name;
    ctx.globalAlpha = on ? 1 : 0.25;
    circle(ctx, v(-18 + i * 18, beaconY), 8, c);
  });
  ctx.globalAlpha = 1;
  ctx.restore();

  // Scanning laser cone when red
  if (light === 'red') {
    const eyeWorld = v(x - 6, groundY - 200);
    const sweepX = x - 260 - 220 * Math.sin(time * 3.8);
    ctx.save();
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.moveTo(eyeWorld.x, eyeWorld.y);
    ctx.lineTo(sweepX - 55, groundY);
    ctx.lineTo(sweepX + 55, groundY);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 0.7;
    stroke(ctx, [eyeWorld, v(sweepX, groundY)], '#ef4444', 2.5);
    ctx.restore();
  }
  if (beamTo) {
    const eyeWorld = v(x - 6, groundY - 200);
    stroke(ctx, [eyeWorld, beamTo], '#ef4444', 6);
    stroke(ctx, [eyeWorld, beamTo], '#fef08a', 2.5);
  }
}

/** Level 51: Counterweight Elevator Cabin & Pulley */
export function drawElevatorSystem(ctx: Ctx, xA: number, yA: number, xB: number, yB: number, topY: number) {
  // Overhead beam & pulleys
  stroke(ctx, [v(xA, topY), v(xB, topY)], '#475569', 8, 'butt');
  stroke(ctx, [v(xA, yA - 210), v(xA, topY)], '#64748b', 3);
  stroke(ctx, [v(xB, yB - 210), v(xB, topY)], '#64748b', 3);
  circle(ctx, v(xA, topY), 14, '#334155');
  circle(ctx, v(xB, topY), 14, '#334155');
  circle(ctx, v(xA, topY), 5, '#94a3b8');
  circle(ctx, v(xB, topY), 5, '#94a3b8');

  const drawCabin = (cx: number, floorY: number, col: string) => {
    shape(ctx, (p) => p.roundRect(cx - 46, floorY, 92, 12, 4), col);
    shape(ctx, (p) => p.roundRect(cx - 46, floorY - 210, 92, 10, 4), col);
    stroke(ctx, [v(cx - 42, floorY), v(cx - 42, floorY - 206)], '#475569', 4, 'butt');
    stroke(ctx, [v(cx + 42, floorY), v(cx + 42, floorY - 206)], '#475569', 4, 'butt');
  };
  drawCabin(xA, yA, '#dc2626');
  drawCabin(xB, yB, '#2563eb');
}

/** Level 52: Pirate Ship Hull & Rolling Waves */
export function drawShipHull(ctx: Ctx, cx: number, cy: number, tilt: number, enemy: boolean) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(tilt);
  // Mast & Sail
  stroke(ctx, [v(enemy ? 36 : -36, 0), v(enemy ? 36 : -36, -240)], '#784c25', 8, 'butt');
  // Flag at top
  ctx.fillStyle = enemy ? '#1e293b' : '#ef4444';
  ctx.beginPath();
  ctx.moveTo(enemy ? 36 : -36, -240);
  ctx.lineTo((enemy ? 36 : -36) + (enemy ? -42 : 42), -226);
  ctx.lineTo(enemy ? 36 : -36, -212);
  ctx.closePath();
  ctx.fill();
  // Wooden hull deck
  shape(
    ctx,
    (p) => {
      p.moveTo(-105, -4);
      p.lineTo(105, -4);
      p.lineTo(82, 42);
      p.lineTo(-82, 42);
      p.closePath();
    },
    enemy ? '#5c3a21' : '#8a5a2e',
  );
  shape(ctx, (p) => p.roundRect(-110, -10, 220, 9, 4), '#b47b44');
  for (const dx of [-60, -20, 20, 60]) {
    circle(ctx, v(dx, 16), 7, '#1e293b');
    circle(ctx, v(dx, 16), 3.5, '#fbbf24');
  }
  if (enemy) {
    // Deck cannon on front of pirate ship
    shape(ctx, (p) => p.roundRect(-92, -32, 36, 18, 6), '#1e293b');
    circle(ctx, v(-72, -12), 7, '#475569');
  }
  ctx.restore();
}

export function drawOceanWaves(ctx: Ctx, leftX: number, rightX: number, baseY: number, time: number) {
  ctx.save();
  ctx.globalAlpha = 0.36;
  ctx.fillStyle = '#0ea5e9';
  ctx.beginPath();
  ctx.moveTo(leftX, baseY + 120);
  for (let x = leftX; x <= rightX; x += 28) {
    const wy = baseY + 8 * Math.sin(x * 0.018 + time * 2.8) + 4 * Math.cos(x * 0.035 - time * 1.9);
    ctx.lineTo(x, wy);
  }
  ctx.lineTo(rightX, baseY + 120);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

/** Level 53: Crystal Laser Mirror */
export function drawCrystalMirror(ctx: Ctx, a: V, b: V, n: V, flash: number) {
  const mid = v((a.x + b.x) * 0.5, (a.y + b.y) * 0.5);
  circle(ctx, mid, 11, '#334155');
  stroke(ctx, [a, b], '#1e1b4b', 11, 'round');
  stroke(ctx, [a, b], flash > 0.05 ? '#f0abfc' : '#38bdf8', 6.5, 'round');
  stroke(ctx, [add(a, v(n.x * 2, n.y * 2)), add(b, v(n.x * 2, n.y * 2))], '#ffffff', 2.2, 'round');
}

/** Level 55: Castle Spiked Chandelier */
export function drawChandelier(ctx: Ctx, p: V, ceilingY: number, cut: boolean, time: number) {
  if (!cut) {
    stroke(ctx, [v(p.x, ceilingY), v(p.x, p.y - 24)], '#64748b', 3.5, 'butt');
    // Shootable chain link ring
    circle(ctx, v(p.x, p.y - 36), 8, '#f59e0b');
    circle(ctx, v(p.x, p.y - 36), 3.5, '#ffffff');
  }
  ctx.save();
  ctx.translate(p.x, p.y);
  // Ornate iron tier + spikes + candles
  stroke(ctx, [v(0, -24), v(-38, 0), v(38, 0), v(0, -24)], '#334155', 3);
  shape(ctx, (q) => q.roundRect(-44, -4, 88, 12, 5), '#1e293b');
  for (const dx of [-32, -16, 0, 16, 32]) {
    // Bottom spikes
    shape(
      ctx,
      (q) => {
        q.moveTo(dx - 5, 8);
        q.lineTo(dx + 5, 8);
        q.lineTo(dx, 22);
        q.closePath();
      },
      '#64748b',
    );
  }
  for (const dx of [-32, 0, 32]) {
    shape(ctx, (q) => q.roundRect(dx - 3.5, -18, 7, 14, 2), '#fef3c7');
    const fl = 1 + 0.2 * Math.sin(time * 28 + dx);
    circle(ctx, v(dx, -23), 4.5 * fl, '#f97316');
    circle(ctx, v(dx, -22), 2.2 * fl, '#fde047');
  }
  ctx.restore();
}

/** Level 57: Rescue Helicopter */
export function drawHelicopter(ctx: Ctx, c: V, time: number, hitFlash: number) {
  ctx.save();
  ctx.translate(c.x, c.y);
  // Tail boom & tail rotor
  stroke(ctx, [v(20, -4), v(92, -14)], '#334155', 10);
  stroke(ctx, [v(86, -14), v(96, -32)], '#ef4444', 7);
  circle(ctx, v(92, -18), 13, 'rgba(148,163,184,0.4)');
  stroke(ctx, [add(v(92, -18), fromAngle(time * 40, 12)), add(v(92, -18), fromAngle(time * 40 + Math.PI, 12))], '#1e293b', 2.5);

  // Landing skids
  stroke(ctx, [v(-24, 16), v(-24, 28)], '#475569', 3.5);
  stroke(ctx, [v(18, 16), v(18, 28)], '#475569', 3.5);
  stroke(ctx, [v(-42, 28), v(34, 28), v(40, 22)], '#334155', 4);

  // Cabin body
  shape(ctx, (p) => p.roundRect(-48, -24, 82, 42, 18), hitFlash > 0 ? '#fca5a5' : '#dc2626');
  shape(ctx, (p) => p.roundRect(-46, -20, 38, 24, 11), '#bae6fd');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-4, -8, 22, 6);
  ctx.fillRect(4, -16, 6, 22);

  // Main rotor mast & blades
  stroke(ctx, [v(-6, -24), v(-6, -36)], '#1e293b', 6, 'butt');
  const span = 115 * Math.cos(time * 36);
  stroke(ctx, [v(-6 - 115, -36), v(-6 + 115, -36)], 'rgba(100,116,139,0.28)', 4);
  stroke(ctx, [v(-6 - span, -36), v(-6 + span, -36)], '#1e293b', 4.5);
  circle(ctx, v(-6, -36), 5, '#475569');
  ctx.restore();
}

/** Level 58: Electric Jellyfish & Scuba Goggles */
export function drawJellyfish(ctx: Ctx, c: V, time: number, ph: number) {
  ctx.save();
  ctx.translate(c.x, c.y);
  const pulse = 1 + 0.12 * Math.sin(time * 6 + ph);
  ctx.scale(pulse, 2 - pulse);
  // Tentacles with electric sparks
  for (const dx of [-12, -4, 4, 12]) {
    const sw = 6 * Math.sin(time * 8 + dx + ph);
    stroke(ctx, [v(dx, 4), v(dx + sw, 18), v(dx - sw * 0.6, 32)], '#c084fc', 2.5);
  }
  // Translucent glowing bell
  ctx.globalAlpha = 0.35;
  circle(ctx, v(0, -2), 26, '#a855f7');
  ctx.globalAlpha = 0.9;
  shape(
    ctx,
    (p) => {
      p.arc(0, 2, 20, Math.PI, 0);
      p.quadraticCurveTo(10, 8, 0, 4);
      p.quadraticCurveTo(-10, 8, -20, 2);
      p.closePath();
    },
    '#e879f9',
  );
  circle(ctx, v(-6, -4), 4, '#fef08a');
  circle(ctx, v(6, -4), 4, '#fef08a');
  ctx.restore();
}

export function drawScubaGear(ctx: Ctx, headC: V, neck: V, facingRight: boolean) {
  const dir = facingRight ? 1 : -1;
  // Oxygen tank on back
  shape(ctx, (p) => p.roundRect(neck.x - dir * 21, neck.y + 2, 12, 36, 5), '#facc15');
  // Diving goggles + snorkel
  shape(ctx, (p) => p.roundRect(headC.x + (facingRight ? 2 : -18), headC.y - 8, 16, 10, 4), '#38bdf8');
  stroke(
    ctx,
    [v(headC.x + dir * 6, headC.y + 8), v(headC.x + dir * 16, headC.y + 6), v(headC.x + dir * 16, headC.y - 20)],
    '#ef4444',
    3,
  );
}

/** Level 60: Giant Apple Mecha Boss */
export function drawMechaBoss(
  ctx: Ctx,
  x: number,
  groundY: number,
  hp: number,
  maxHp: number,
  shieldOn: boolean,
  ph: number,
  hurt: number,
  sticks: { d: V; ang: number }[],
  drawArr: (p: V, ang: number) => void,
) {
  const bob = Math.abs(Math.sin(ph * Math.PI * 2)) * 8;
  const bodyC = v(x, groundY - 128 - bob);
  const antC = v(x + 6, bodyC.y - 92);

  // Hydraulic Legs
  const stepA = Math.sin(ph * Math.PI * 2) * 18;
  const stepB = -stepA;
  for (const [lx, far] of [[stepB + 12, true], [stepA - 12, false]] as [number, boolean][]) {
    const col = far ? '#334155' : '#475569';
    const knee = v(x + lx * 0.5 - 14, groundY - 56 - bob * 0.5);
    const foot = v(x + lx, groundY - 8);
    stroke(ctx, [v(x, bodyC.y + 38), knee], col, 16);
    stroke(ctx, [knee, foot], col, 14);
    shape(ctx, (p) => p.roundRect(foot.x - 24, groundY - 14, 44, 14, 5), far ? '#1e293b' : '#334155');
  }

  // Main Armored Mecha Torso
  ctx.save();
  ctx.translate(bodyC.x, bodyC.y);
  shape(ctx, (p) => p.roundRect(-62, -64, 124, 112, 26), hurt > 0 ? '#fca5a5' : '#334155');
  shape(ctx, (p) => p.roundRect(-52, -54, 104, 92, 20), '#475569');

  // Glass Cockpit Dome on top with Pak Bejo silhouette
  shape(
    ctx,
    (p) => {
      p.arc(0, -60, 34, Math.PI, 0);
      p.closePath();
    },
    'rgba(186,230,253,0.65)',
  );
  circle(ctx, v(-4, -74), 11, '#e9b48b');

  // Antenna Generator on top-back (shootable to disable shield!)
  stroke(ctx, [v(6, -64), v(6, -92)], '#94a3b8', 5, 'butt');
  circle(ctx, v(6, -92), 14, shieldOn ? '#facc15' : '#64748b');
  if (shieldOn) {
    circle(ctx, v(6, -92), 7, '#fef08a');
  }

  // Exposed Apple Reactor Core in Chest
  circle(ctx, v(-18, -4), 30, '#1e293b');
  drawApple(ctx, v(-18, -4), APPLE_R * 1.45, 0);

  // Arm Cannon
  shape(ctx, (p) => p.roundRect(-84, 14, 48, 22, 7), '#1e293b');
  circle(ctx, v(-84, 25), 7, '#ef4444');
  ctx.restore();

  // Energy Shield Wall in front of Reactor Core when active
  if (shieldOn) {
    ctx.save();
    ctx.globalAlpha = 0.35 + 0.15 * Math.sin(ph * 25);
    shape(ctx, (p) => p.roundRect(x - 82, bodyC.y - 54, 14, 96, 7), '#38bdf8');
    ctx.globalAlpha = 0.85;
    stroke(ctx, [v(x - 75, bodyC.y - 48), v(x - 75, bodyC.y + 36)], '#bae6fd', 3.5);
    ctx.restore();
  }

  // Lodged arrows in the reactor
  for (const st of sticks) {
    drawArr(add(bodyC, st.d), st.ang);
  }

  // Boss HP pips above antenna
  for (let i = 0; i < maxHp; i++) {
    ctx.fillStyle = i < hp ? '#ef4444' : '#e5e7eb';
    ctx.beginPath();
    ctx.roundRect(x - maxHp * 9 + i * 18, antC.y - 32, 14, 7, 3.5);
    ctx.fill();
  }
}
