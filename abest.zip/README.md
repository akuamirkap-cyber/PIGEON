# Kungfu Drifter V2: Menara Kantor

Game stickman dari arsip PIGEON (`a1best (1).zip`). Build ini hanya berisi **Game V2**. Game V1 sudah dihapus; pustaka latar kantor, menu, dan suara yang masih dipakai V2 dipindah ke `src/original/shared/`.

## Menjalankan

```sh
npm install
npm run dev
```

`npm run build` membuat build produksi di `dist/`.

Dojo latihan masih dapat dibuka dari lobi situs (`#arena/training/foot`) walaupun tidak lagi ada di menu game.

## Cara main

- Menu judul hanya menyimpan tiga mode: **MULAI: MENARA KANTOR** (wave tanpa akhir), **STORY MODE**, dan **ARENA 3/4 KLASIK**. Sistem desain map, map kustom, mode lain (survival, tim, papan skor), dan dojo dari menu sudah dihapus.
- Latar menu adalah tangkapan gameplay Menara Kantor yang sesungguhnya.
- WASD bergerak, J / klik kiri serangan ringan, K / klik kanan serangan berat, Spasi lompat, Shift dash, Esc jeda.
- **O** memilih Foot Mode. Saat Foot Mode aktif, **scroll mouse** (atau O lagi) memutar **Foot Mode V1**, **V2**, dan **V3**. Di senjata lain scroll tetap memutar senjata; Q selalu memutar senjata.
- Pilihan versi tersimpan di perangkat. Tombol V1/V2/V3 juga ada di bilah atas dan di panel **Senjata**.

## Foot Mode V3: silang V1 + V2

Ikat kepala emas. Jurus V1 dan V2 bergantian dalam satu rantai, dan mengganti tombol setelah tendangan kena membuka cabang dari versi seberang. Semua jurus memakai suara hit Fist Mode.

| Input | Jurus |
| --- | --- |
| J x6 | Yeop Chagi (V2), Rasteira Sweep (V1), Backlash Heel kiri (V2), Au Batido (V1), Konoha Senpu (V2), Ember Crescent (V1) |
| K x5 | Moon Sweep (V1), 540 Tornado (V2), Break Windmill (V1), Konoha Dai Senpu (V2), Hunting Hawk (V2) |
| J kena, lalu K | Yeop > Lotus Wheel, Rasteira > Backlash kanan, Backlash kiri > Tornado Heel, Au Batido > Hunting Hawk, Konoha Senpu > Blazing Comet |
| K kena, lalu J | Moon Sweep > Flamingo Thrust, 540 > Side Snap, Windmill > Crosswind, Dai Senpu > Cinder Dragon |
| I, J, J, K | Flamingo Rush (V1) |
| S + K | Flamingo Sky Lift (V2). W + K: Comet Back Kick (V1). Serang saat lari: Flying Side Kick (V2) |
| **Lari + K** | **Shotgun Dropkick (V3)**: badan mendatar di udara, kaki depan lurus mengenai duluan lalu kaki belakang menyusul — dorong lawan terpental jauh, lalu badan berputar sejajar lantai dengan dagu ditempelkan ke dada sebelum mendarat |
| Di udara: J / K | Sky Snap, Sky Scissors, Sky Tornado / bergantian Comet Drop dan 540 banting |

Scroll turun memutar V1 > V2 > V3, scroll naik sebaliknya. Versi bawaan sekarang V3.

## Foot Mode V2: Hwoarang + Rock Lee

Ikat kepala merah muda, kuda-kuda Taekwondo memantul, tempo lebih cepat dari V1, dan suara hit memakai jalur Fist Mode (hit + punch / kick / heavy).

| Input | Jurus |
| --- | --- |
| J x5 | Yeop Chagi, Right Flamingo Thrust, Backlash Heel kiri, Backlash Heel kanan, Konoha Senpu (sapuan rendah berputar) |
| K x3 | 540 Tornado Kick, Konoha Dai Senpu (sapuan lalu tebasan tinggi), Hunting Hawk (tiga tendangan sambil melompat) |
| J x4 lalu K | Langsung Hunting Hawk setelah Backlash kanan kena |
| J x5, K, K | Konoha Senpu, Konoha Dai Senpu, Hunting Hawk |
| S + K atau I | Flamingo Sky Lift (pelontar). Tekan Spasi untuk menyusul ke udara |
| W + K, atau serang saat lari / dash | Flying Side Kick |
| Di udara: J | Right Sky Snap (bisa diulang) |
| Di udara: K | 540 Tornado Kick versi udara, membanting lawan |

## Foot Mode V1: Capoeira + Break

| Input | Jurus |
| --- | --- |
| J x5 | Rasteira Sweep, Side Snap, Au Batido (kayang satu tangan), Lotus Wheel, Ember Crescent |
| K x4 | Moon Sweep, Break Windmill (kincir dua kaki), Tornado Heel, Blazing Comet |
| I, J, J, K | Flamingo Rush: Switch Double, Reverse Hook, Heel Breaker |
| J, J, K, J | Crossflow: Crosswind lalu Cinder Dragon |
| S + K | Rising Lotus. W + K: Comet Back Kick |
| Di udara: J / K | Sky Scissors, Sky Tornado / Comet Drop |

## Catatan teknis

- Jurus dan rute kombo: `src/original/v2/games/maxkungfu/game/footwork.ts`.
- Animasi keyframe, putaran badan, dan koreksi postur (badan tidak rebah ke belakang saat menendang): `footPoses.ts`.
- Jejak dan efek kontak: `footEffects.ts`. Integrasi mesin game: `game.ts`.
- Dojo latihan (Cara Main > Jurus Foot Mode > Latihan Foot Mode) punya rute **Foot V2**; scroll mouse di dojo ikut menukar rute.
- Font dimuat dari Google Fonts karena berkas font lokal tidak ada di arsip.

Sumber asli: https://github.com/akuamirkap-cyber/PIGEON
