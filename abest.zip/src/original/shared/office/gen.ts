// GENERATOR MENARA (100 LEVEL). Tiap level = potongan gedung pencakar langit 96 petak (2x lebih luas),
// tata ruang unik dari 12 tema kantor, perabot ditata per "kluster" yang masuk akal (meja + kursi, sofa + karpet, dst).
import { STORY, type OfficeMap, type ThemeId } from './map';
import type { AtmoId } from './atmo';

export const LEVEL_COUNT = 100;
export const ATMO_CYCLE: AtmoId[] = ['pagi', 'siang', 'sore', 'malam', 'subuh', 'hujan'];
const TOWER_NAMES = ['MENARA NAGA', 'NAGA CORP PLAZA', 'MENARA KACA', 'PUSAT BISNIS', 'MENARA SENJA', 'GEDUNG BAYANGAN', 'MENARA BADAI', 'PUNCAK NAGA', 'MENARA EMAS', 'SINGGASANA LANGIT'];

export interface LevelSpec { level: number; stories: number; waves: number; diff: number; atmo: AtmoId; floorBase: number; name: string; boss: boolean }
export function levelSpec(level: number): LevelSpec {
  const L = Math.max(1, Math.min(LEVEL_COUNT, Math.round(level)));
  const stories = L === 1 ? 6 : 5 + Math.min(2, Math.floor((L - 1) / 34));
  return {
    level: L, stories,
    waves: 3 + Math.floor((L - 1) / 20),
    diff: Math.floor((L - 1) * 0.55),
    atmo: ATMO_CYCLE[(L - 1) % ATMO_CYCLE.length],
    floorBase: 1 + (L - 1) * 4,
    name: `${TOWER_NAMES[Math.floor((L - 1) / 10) % TOWER_NAMES.length]} ${L}`,
    boss: L % 10 === 0,
  };
}

function prng(seed: number) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

/** kluster perabot per tema (dibaca kiri ke kanan, '.' = celah) dengan bobot */
export const SETS: Record<ThemeId, [string, number][]> = {
  lobby: [['kk', 3], ['B', 3], ['p', 2], ['I.I', 2], ['Y', 2], ['v', 1], ['w', 1], ['C', 1], ['Z', 1], ['l', 1], ['RRR', 1]],
  cubicle: [['cdd', 4], ['ddc', 4], ['cddc', 3], ['p', 2], ['x', 1], ['w', 1], ['ff', 2], ['b', 1], ['Z', 1], ['dd', 2]],
  meeting: [['cLLLLc', 4], ['cLLLc', 3], ['i', 2], ['p', 2], ['f', 1], ['y', 1], ['B', 1], ['Z', 1]],
  pantry: [['KKKK', 4], ['KKK', 2], ['F', 2], ['v', 2], ['y', 2], ['cCc', 3], ['w', 1], ['Z', 1], ['p', 1]],
  server: [['rrr', 4], ['rr', 3], ['rrrr', 2], ['b', 1], ['bb', 1], ['O', 1], ['Z', 1]],
  exec: [['DDD', 3], ['mmm', 3], ['kkk', 2], ['A', 2], ['h', 2], ['s', 1], ['B', 2], ['J', 1], ['Y', 1], ['l', 2], ['RRRR', 2]],
  gym: [['TT', 3], ['TTT', 2], ['W', 2], ['WW', 2], ['jjj', 2], ['w', 1], ['p', 1], ['Z', 1]],
  archive: [['mmmm', 4], ['mmm', 3], ['ff', 2], ['bb', 2], ['l', 1], ['C', 1], ['J', 1]],
  lab: [['ddO', 3], ['A', 3], ['AA', 2], ['xr', 2], ['F', 1], ['O', 1], ['w', 1], ['Z', 1]],
  lounge: [['kkk', 3], ['QQ', 2], ['V', 2], ['VV', 1], ['i', 2], ['C', 2], ['B', 2], ['l', 2], ['RRR', 2], ['p', 1]],
  security: [['OO', 3], ['OOO', 2], ['jjj', 2], ['s', 1], ['c', 1], ['w', 1], ['Z', 1]],
  roof: [['aa', 3], ['a', 2], ['b', 2], ['bb', 1], ['p', 2], ['B', 2], ['C', 1]],
};
const MEZZ: Partial<Record<ThemeId, string[]>> = { lobby: ['p', 'p', 'l'], archive: ['b', 'p', 'l'], gym: ['W', 'p'], lounge: ['p', 'l', 'C'], server: ['b', 'r'], lab: ['A', 'p'] };
const POOL_EARLY: ThemeId[] = ['cubicle', 'pantry', 'meeting', 'lounge', 'archive'];
const POOL_MID: ThemeId[] = [...POOL_EARLY, 'server', 'gym', 'security'];
const POOL_LATE: ThemeId[] = [...POOL_MID, 'lab', 'exec'];

/** gedung untuk level tertentu (deterministik). seed opsional untuk peta acak editor. */
export function generateTower(level: number, seed?: number): OfficeMap {
  const spec = levelSpec(level);
  const R = prng(seed ?? level * 7919 + 101);
  const ri = (a: number, b: number) => a + Math.floor(R() * (b - a + 1));
  const W = 96, n = spec.stories, H = n * STORY;
  const g: string[][] = Array.from({ length: H }, () => Array(W).fill('.'));
  const put = (c: number, r: number, ch: string) => { if (r >= 0 && r < H && c >= 0 && c < W) g[r][c] = ch; };

  // ---- tema per lantai
  const themes: ThemeId[] = [];
  const pool = spec.level <= 10 ? POOL_EARLY : spec.level <= 35 ? POOL_MID : POOL_LATE;
  for (let s = 0; s < n; s++) {
    if (s === 0) { themes.push('roof'); continue; }
    if (s === n - 1 && spec.level === 1) { themes.push('lobby'); continue; }
    if (s === 1 && (spec.boss || spec.level === 1)) { themes.push('exec'); continue; }
    let t: ThemeId; let guard = 0;
    do { t = pool[Math.floor(R() * pool.length)]; guard++; } while ((t === themes[s - 1] || (t === 'exec' && R() < 0.6)) && guard < 12);
    themes.push(t);
  }
  if (spec.level === 1) themes.splice(0, n, 'roof', 'exec', 'meeting', 'pantry', 'cubicle', 'lobby');

  // ---- struktur: pelat, dinding kaca luar, penghubung
  const conns = [2, 32, 63, W - 3];
  const reserved: Set<number>[] = Array.from({ length: n }, () => new Set<number>());
  const reserve = (s: number, c0: number, c1: number) => { for (let c = c0; c <= c1; c++) reserved[s].add(c); };
  for (let s = 0; s < n; s++) {
    const r0 = s * STORY, fl = r0 + 3, slab = r0 + 4;
    for (let c = 0; c < W; c++) put(c, slab, '#');
    if (s === 0) { put(0, fl, '#'); put(W - 1, fl, '#'); }
    else for (let r = r0; r <= fl; r++) { const ch = r === r0 ? '#' : 'G'; put(0, r, ch); put(W - 1, r, ch); }
    const here = s === 0 ? [2, W - 3] : conns;
    for (const c of here) { put(c, fl, c === 2 || c === 32 ? 'S' : 'E'); reserve(s, c - 2, c + 2); }
    reserve(s, 0, 3); reserve(s, W - 4, W - 1);
  }
  // ---- tangga panjat menembus pelat (1-2 per lantai)
  for (let s = 0; s < n - 1; s++) {
    const k = R() < 0.5 ? 2 : 1;
    for (let i = 0; i < k; i++) {
      let c = 0, guard = 0;
      do { c = ri(6, W - 7); guard++; } while ((reserved[s].has(c) || reserved[s + 1].has(c) || reserved[s].has(c - 1) || reserved[s + 1].has(c + 1)) && guard < 40);
      if (guard >= 40) continue;
      const slab = s * STORY + 4;
      for (let r = slab; r <= slab + STORY - 1; r++) put(c, r, 'H');
      reserve(s, c - 1, c + 1); reserve(s + 1, c - 1, c + 1);
    }
  }
  // ---- pijakan mezzanine & ventilasi musuh
  for (let s = 1; s < n; s++) {
    const th = themes[s], r0 = s * STORY;
    if (MEZZ[th] && R() < 0.8) {
      const len = ri(5, 9);
      for (let tries = 0; tries < 20; tries++) {
        const c0 = ri(6, W - 7 - len);
        let ok = true;
        for (let c = c0 - 1; c <= c0 + len; c++) if (g[r0 + 2][c] !== '.' || g[r0 + 3][c] === 'H') ok = false;
        if (!ok) continue;
        for (let c = c0; c < c0 + len; c++) put(c, r0 + 2, '=');
        const items = MEZZ[th]!;
        for (let c = c0 + 1; c < c0 + len - 1; c += ri(2, 3)) if (R() < 0.6) put(c, r0 + 1, items[Math.floor(R() * items.length)]);
        break;
      }
    }
    if (s > 0) for (let tries = 0; tries < 20; tries++) { const c = ri(10, W - 11); if (g[r0 + 1][c] === '.' && g[r0][c] === '.' && !reserved[s].has(c)) { put(c, r0, 'X'); break; } }
  }
  // ---- perabot per kluster
  const weighted = (set: [string, number][]) => { let tot = 0; for (const [, w] of set) tot += w; let x = R() * tot; for (const [k, w] of set) { x -= w; if (x <= 0) return k; } return set[0][0]; };
  for (let s = 0; s < n; s++) {
    const th = themes[s], fl = s * STORY + 3, set = SETS[th];
    let c = 4;
    // lobi: meja resepsionis di tengah
    if (th === 'lobby') { const qc = 40; for (let i = 0; i < 6; i++) put(qc + i, fl, 'q'); reserve(s, qc - 1, qc + 6); }
    while (c < W - 4) {
      if (reserved[s].has(c) || g[fl][c] !== '.') { c++; continue; }
      const k = weighted(set);
      let fits = true;
      for (let i = 0; i < k.length; i++) if (reserved[s].has(c + i) || c + i >= W - 4 || g[fl][c + i] !== '.') { fits = false; break; }
      if (!fits) { c++; continue; }
      for (let i = 0; i < k.length; i++) if (k[i] !== '.') put(c + i, fl, k[i]);
      c += k.length + ri(1, th === 'roof' ? 4 : 3);
    }
    // hiasan dinding 't' (papan / lukisan)
    if (th !== 'roof') for (let i = 0; i < ri(1, 3); i++) { const cc = ri(6, W - 7); if (!reserved[s].has(cc) && g[s * STORY + 1][cc] === '.' && g[s * STORY + 2][cc] === '.') put(cc, s * STORY + 1, 't'); }
  }
  // ---- pemain di lantai terbawah
  const pr = (n - 1) * STORY + 3;
  let pc = 46; while (g[pr][pc] !== '.' && pc < W - 6) pc++;
  put(pc, pr, 'P');
  return { name: spec.level === 1 ? 'MENARA NAGA' : spec.name, w: W, h: H, rows: g.map((r) => r.join('')), roof: true, themes, floorBase: spec.level === 1 ? undefined : spec.floorBase };
}

/** Menara kantor bawaan (level 1): lobi -> kubikel -> pantri -> rapat -> direksi -> atap, 96 petak. */
export function defaultMap(): OfficeMap { return generateTower(1); }
/** gedung acak untuk editor */
export function randomTower(): OfficeMap { const lv = 1 + Math.floor(Math.random() * LEVEL_COUNT); const m = generateTower(lv, Math.floor(Math.random() * 1e9)); return { ...m, name: 'MENARA ACAK', floorBase: undefined }; }
