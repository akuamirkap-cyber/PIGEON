// MENARA KANTOR — model peta side view.
// Peta = grid petak 16px. Tinggi peta selalu kelipatan STORY (1 lantai = 4 baris ruang + 1 baris pelat beton).

export const T = 16;
export const STORY = 5;
export const STORY_PX = T * STORY;

export type TileKind = 'air' | 'solid' | 'platform' | 'ladder' | 'glass' | 'door' | 'elevator' | 'spawn' | 'player' | 'prop' | 'deco';

export interface TileDef { ch: string; name: string; kind: TileKind; color: string; hint: string; group: 'struktur' | 'jalur' | 'perabot' | 'dekor' }

export const TILES: TileDef[] = [
  { ch: '.', name: 'HAPUS', kind: 'air', color: '#1b1f2e', hint: 'Kosongkan petak (klik kanan juga menghapus)', group: 'struktur' },
  { ch: '#', name: 'BETON', kind: 'solid', color: '#7a8196', hint: 'Lantai, dinding & langit-langit padat', group: 'struktur' },
  { ch: '=', name: 'PIJAKAN', kind: 'platform', color: '#d1a54a', hint: 'Platform satu arah (S + LOMPAT untuk turun)', group: 'struktur' },
  { ch: 'G', name: 'KACA', kind: 'glass', color: '#8fd8ff', hint: 'Jendela kaca: musuh bisa terlempar menembusnya & jatuh', group: 'struktur' },
  { ch: 'H', name: 'TANGGA PANJAT', kind: 'ladder', color: '#e7b85c', hint: 'Tangga panjat. Lubangi pelat lantai agar tembus ke lantai atas', group: 'jalur' },
  { ch: 'S', name: 'PINTU DARURAT', kind: 'door', color: '#3ddc84', hint: 'Pintu tangga darurat: W naik / S turun. Musuh muncul dari sini', group: 'jalur' },
  { ch: 'E', name: 'LIFT', kind: 'elevator', color: '#ffd166', hint: 'Lift: W naik / S turun. Musuh keluar bergerombol (DING!)', group: 'jalur' },
  { ch: 'X', name: 'VENTILASI MUSUH', kind: 'spawn', color: '#ff4d6d', hint: 'Musuh turun dari ventilasi langit-langit', group: 'jalur' },
  { ch: 'P', name: 'POSISI PEMAIN', kind: 'player', color: '#ffffff', hint: 'Titik awal pemain (hanya satu)', group: 'jalur' },
  { ch: 'd', name: 'MEJA KERJA', kind: 'prop', color: '#a8865e', hint: 'Meja + monitor. Hancur bila musuh terbanting', group: 'perabot' },
  { ch: 'c', name: 'KURSI', kind: 'prop', color: '#4a5266', hint: 'Kursi kantor beroda', group: 'perabot' },
  { ch: 'p', name: 'TANAMAN', kind: 'prop', color: '#4fbf6a', hint: 'Pot tanaman', group: 'perabot' },
  { ch: 'w', name: 'DISPENSER', kind: 'prop', color: '#9fd6ff', hint: 'Dispenser air: pecah menyemburkan air', group: 'perabot' },
  { ch: 'f', name: 'LEMARI ARSIP', kind: 'prop', color: '#9aa0ad', hint: 'Lemari arsip besi: kertas berhamburan', group: 'perabot' },
  { ch: 'v', name: 'MESIN MINUMAN', kind: 'prop', color: '#ff5a5a', hint: 'Vending machine: pecah menjatuhkan minuman penambah HP', group: 'perabot' },
  { ch: 'x', name: 'FOTOKOPI', kind: 'prop', color: '#d8dce4', hint: 'Mesin fotokopi', group: 'perabot' },
  { ch: 'r', name: 'RAK SERVER', kind: 'prop', color: '#3a8bff', hint: 'Rak server berkedip: musuh yang dilempar ke sini kesetrum', group: 'perabot' },
  { ch: 'b', name: 'KARDUS', kind: 'prop', color: '#c08a4a', hint: 'Tumpukan kardus', group: 'perabot' },
  { ch: 'k', name: 'SOFA', kind: 'prop', color: '#a0435a', hint: 'Sofa (sambung beberapa petak)', group: 'perabot' },
  { ch: 'q', name: 'MEJA RESEPSIONIS', kind: 'prop', color: '#e8d8b0', hint: 'Meja resepsionis lobi (sambung beberapa petak)', group: 'perabot' },
  { ch: 'a', name: 'UNIT AC', kind: 'prop', color: '#b9c2cf', hint: 'Unit AC atap dengan kipas berputar', group: 'perabot' },
  { ch: 'D', name: 'MEJA DIREKTUR', kind: 'prop', color: '#7a4a2a', hint: 'Meja kayu besar + laptop & lampu meja (sambung 3 petak)', group: 'perabot' },
  { ch: 'L', name: 'MEJA RAPAT', kind: 'prop', color: '#6a4a34', hint: 'Meja rapat panjang dengan kursi (sambung beberapa petak)', group: 'perabot' },
  { ch: 'K', name: 'KONTER DAPUR', kind: 'prop', color: '#d8d0c0', hint: 'Konter pantri: wastafel, microwave (sambung beberapa petak)', group: 'perabot' },
  { ch: 'F', name: 'KULKAS', kind: 'prop', color: '#e4e8ec', hint: 'Kulkas dua pintu', group: 'perabot' },
  { ch: 'y', name: 'MESIN KOPI', kind: 'prop', color: '#5a3a2a', hint: 'Mesin kopi espresso: pecah menyemburkan kopi', group: 'perabot' },
  { ch: 'm', name: 'RAK BUKU', kind: 'prop', color: '#8a5a32', hint: 'Rak buku tinggi (sambung beberapa petak)', group: 'perabot' },
  { ch: 'j', name: 'LOKER', kind: 'prop', color: '#5a7a9a', hint: 'Loker besi karyawan', group: 'perabot' },
  { ch: 'O', name: 'MONITOR CCTV', kind: 'prop', color: '#2a3a4a', hint: 'Meja keamanan dengan layar CCTV (sambung 2 petak)', group: 'perabot' },
  { ch: 'T', name: 'TREADMILL', kind: 'prop', color: '#3a3f4a', hint: 'Treadmill pusat kebugaran', group: 'perabot' },
  { ch: 'W', name: 'RAK BEBAN', kind: 'prop', color: '#6a6f7a', hint: 'Rak dumbel & barbel', group: 'perabot' },
  { ch: 'Q', name: 'MEJA PINGPONG', kind: 'prop', color: '#2a7a4a', hint: 'Meja pingpong lounge (sambung 2 petak)', group: 'perabot' },
  { ch: 'V', name: 'MESIN ARCADE', kind: 'prop', color: '#7a3aff', hint: 'Mesin arcade bercahaya', group: 'perabot' },
  { ch: 'C', name: 'MEJA TAMU', kind: 'prop', color: '#8a6a4a', hint: 'Meja kopi rendah + cangkir', group: 'perabot' },
  { ch: 'I', name: 'GERBANG KEAMANAN', kind: 'prop', color: '#c0c8d4', hint: 'Turnstile kartu akses lobi', group: 'perabot' },
  { ch: 'i', name: 'TV LAYAR', kind: 'prop', color: '#1a2a3a', hint: 'TV besar di atas kabinet', group: 'dekor' },
  { ch: 'A', name: 'AKUARIUM', kind: 'prop', color: '#3ab8e8', hint: 'Akuarium ikan (di lab jadi tabung spesimen)', group: 'dekor' },
  { ch: 'B', name: 'POHON HIAS', kind: 'prop', color: '#2f8a3f', hint: 'Pohon hias besar dalam pot', group: 'dekor' },
  { ch: 'h', name: 'LEMARI PIALA', kind: 'prop', color: '#e0b84a', hint: 'Lemari kaca berisi piala emas', group: 'dekor' },
  { ch: 's', name: 'BRANKAS', kind: 'prop', color: '#4a4f5a', hint: 'Brankas baja: pecah menghamburkan uang', group: 'dekor' },
  { ch: 'Y', name: 'PATUNG', kind: 'prop', color: '#d8d4c8', hint: 'Patung naga marmer', group: 'dekor' },
  { ch: 'J', name: 'JAM ANTIK', kind: 'prop', color: '#6a3a1a', hint: 'Jam kakek berbandul', group: 'dekor' },
  { ch: 'l', name: 'LAMPU LANTAI', kind: 'prop', color: '#ffd99a', hint: 'Lampu berdiri: menyala saat malam', group: 'dekor' },
  { ch: 'Z', name: 'TEMPAT SAMPAH', kind: 'prop', color: '#5a6a5a', hint: 'Tempat sampah', group: 'dekor' },
  { ch: 'R', name: 'KARPET', kind: 'prop', color: '#8a2433', hint: 'Karpet lantai (sambung beberapa petak)', group: 'dekor' },
  { ch: 't', name: 'PAPAN / LUKISAN', kind: 'deco', color: '#f4f4f4', hint: 'Hiasan dinding (papan tulis, lukisan, jam)', group: 'dekor' },
];
export const TILE_BY_CH: Record<string, TileDef> = Object.fromEntries(TILES.map((t) => [t.ch, t]));
export const PROP_CHARS = TILES.filter((t) => t.kind === 'prop').map((t) => t.ch).join('');

export interface OfficeMap {
  name: string; w: number; h: number; rows: string[]; roof: boolean;
  /** tema per lantai (indeks lantai dari atas). Kosong = siklus bawaan */
  themes?: string[];
  /** nomor lantai terbawah (gedung pencakar langit: level tinggi = lantai tinggi) */
  floorBase?: number;
}

export type ThemeId = 'lobby' | 'cubicle' | 'server' | 'meeting' | 'exec' | 'pantry' | 'gym' | 'archive' | 'lab' | 'lounge' | 'security' | 'roof';
export interface Theme {
  id: ThemeId;
  name: string; wall: string; wall2: string; panel: string; trim: string; floor: string; floorTop: string; light: string; accent: string; outdoor?: boolean;
}

export const THEMES: Record<ThemeId, Theme> = {
  lobby: { id: 'lobby', name: 'LOBI UTAMA', wall: '#3a3f57', wall2: '#2c3045', panel: '#4a5070', trim: '#d4af5a', floor: '#3b3a40', floorTop: '#cfc6b4', light: '#ffe6b0', accent: '#ffd166' },
  cubicle: { id: 'cubicle', name: 'RUANG KUBIKEL', wall: '#35504f', wall2: '#2a403f', panel: '#46625f', trim: '#7fa09a', floor: '#2b2f3a', floorTop: '#4c5f80', light: '#e6fbff', accent: '#5ff0d0' },
  server: { id: 'server', name: 'RUANG SERVER', wall: '#1a2233', wall2: '#131a28', panel: '#222d44', trim: '#2f8fff', floor: '#22262f', floorTop: '#5a6578', light: '#9fd0ff', accent: '#3aa0ff' },
  meeting: { id: 'meeting', name: 'RUANG RAPAT', wall: '#4d3b33', wall2: '#3e2f29', panel: '#5e4a3f', trim: '#a3794e', floor: '#2e2724', floorTop: '#7a5338', light: '#ffd8a0', accent: '#ff9f43' },
  exec: { id: 'exec', name: 'KANTOR DIREKSI', wall: '#3f2b45', wall2: '#30203a', panel: '#4e3656', trim: '#e0b84a', floor: '#2a1d22', floorTop: '#8a2433', light: '#ffe2c4', accent: '#ff4f7a' },
  pantry: { id: 'pantry', name: 'PANTRI & KANTIN', wall: '#4a4436', wall2: '#3a3528', panel: '#d8d2c0', trim: '#c96a3a', floor: '#2e2a24', floorTop: '#b8a888', light: '#ffe8c0', accent: '#ffb347' },
  gym: { id: 'gym', name: 'PUSAT KEBUGARAN', wall: '#2e3440', wall2: '#232832', panel: '#3b4252', trim: '#ff3b5c', floor: '#1e2128', floorTop: '#3a3e48', light: '#e0f0ff', accent: '#ff3b5c' },
  archive: { id: 'archive', name: 'PERPUSTAKAAN ARSIP', wall: '#3d2f26', wall2: '#30241c', panel: '#4e3a2c', trim: '#c9a063', floor: '#2a1f18', floorTop: '#6b4a30', light: '#ffd9a0', accent: '#e8b860' },
  lab: { id: 'lab', name: 'LAB RISET', wall: '#8a9aa4', wall2: '#6e7e88', panel: '#c4d0d6', trim: '#3ad8a8', floor: '#3a4248', floorTop: '#a8b6bc', light: '#e8fff8', accent: '#3ad8a8' },
  lounge: { id: 'lounge', name: 'LOUNGE KREATIF', wall: '#3a2a4a', wall2: '#2c2038', panel: '#4a3560', trim: '#ff8fd0', floor: '#241a2c', floorTop: '#5a4a6a', light: '#ffd0f0', accent: '#ff8fd0' },
  security: { id: 'security', name: 'RUANG KEAMANAN', wall: '#2a3530', wall2: '#202a26', panel: '#34423c', trim: '#ff4d4d', floor: '#1c2420', floorTop: '#3a4440', light: '#d0ffe0', accent: '#ff4d4d' },
  roof: { id: 'roof', name: 'ATAP GEDUNG', wall: '#000000', wall2: '#000000', panel: '#000000', trim: '#8c96a8', floor: '#3a3d45', floorTop: '#6b6e78', light: '#ffffff', accent: '#ff3b3b', outdoor: true },
};
export const THEME_IDS = Object.keys(THEMES) as ThemeId[];
const CYCLE: ThemeId[] = ['cubicle', 'pantry', 'server', 'meeting', 'lounge', 'archive', 'gym', 'lab', 'security', 'exec'];

export const storiesOf = (m: OfficeMap) => Math.floor(m.h / STORY);
export const floorNumber = (m: OfficeMap, story: number) => storiesOf(m) - story;
export const floorRowOf = (story: number) => story * STORY + STORY - 2;
export const slabRowOf = (story: number) => story * STORY + STORY - 1;

export function themeOf(m: OfficeMap, story: number): Theme {
  const n = storiesOf(m);
  const forced = m.themes?.[story] as ThemeId | undefined;
  if (forced && THEMES[forced]) return THEMES[forced];
  const b = n - 1 - story;
  if (m.roof && story === 0 && n > 1) return THEMES.roof;
  if (b <= 0 && !(m.floorBase && m.floorBase > 1)) return THEMES.lobby;
  return THEMES[CYCLE[(b - 1 + CYCLE.length + ((m.floorBase ?? 1) - 1)) % CYCLE.length]];
}
export function floorLabel(m: OfficeMap, story: number): string {
  const th = themeOf(m, story);
  return th.id === 'roof' ? 'ATAP' : `LANTAI ${floorNumber(m, story) + (m.floorBase ?? 1) - 1}`;
}

function grid(w: number, h: number): string[][] { return Array.from({ length: h }, () => Array(w).fill('.')); }
function pack(name: string, g: string[][], roof: boolean): OfficeMap { return { name, w: g[0].length, h: g.length, rows: g.map((r) => r.join('')), roof }; }

/** Peta kosong untuk editor: pelat lantai, dinding kaca, pintu darurat kiri & lift kanan. */
export function blankMap(w = 48, n = 3): OfficeMap {
  const h = n * STORY;
  const g = grid(w, h);
  for (let s = 0; s < n; s++) {
    const r0 = s * STORY, fl = r0 + 3, slab = r0 + 4;
    for (let c = 0; c < w; c++) g[slab][c] = '#';
    for (let r = r0; r <= fl; r++) { const ch = r === r0 ? '#' : 'G'; g[r][0] = ch; g[r][w - 1] = ch; }
    g[fl][2] = 'S'; g[fl][w - 3] = 'E';
  }
  g[floorRowOf(n - 1)][Math.floor(w / 2)] = 'P';
  return pack('MAP BARU', g, false);
}

/** Rapikan peta dari editor / impor: ukuran konsisten, tinggi kelipatan STORY, satu pemain. */
export function normalizeMap(m: OfficeMap): OfficeMap {
  const w = Math.max(16, Math.min(192, Math.round(m.w || 40)));
  let rows = (m.rows || []).map((r) => String(r).slice(0, w).padEnd(w, '.'));
  const n = Math.max(1, Math.min(12, Math.ceil(rows.length / STORY)));
  while (rows.length < n * STORY) rows.unshift('.'.repeat(w));
  rows = rows.slice(0, n * STORY).map((r) => [...r].map((ch) => (TILE_BY_CH[ch] ? ch : '.')).join(''));
  let seen = false;
  rows = rows.map((r) => [...r].map((ch) => { if (ch !== 'P') return ch; if (seen) return '.'; seen = true; return ch; }).join(''));
  if (!seen) {
    const r = floorRowOf(n - 1), c = Math.floor(w / 2);
    rows[r] = rows[r].slice(0, c) + 'P' + rows[r].slice(c + 1);
  }
  const themes = Array.isArray(m.themes) ? m.themes.slice(0, n).map((t) => (THEMES[t as ThemeId] ? t : '')) : undefined;
  while (themes && themes.length < n) themes.push('');
  return { name: String(m.name || 'MAP KUSTOM').slice(0, 24).toUpperCase(), w, h: n * STORY, rows, roof: !!m.roof, themes: themes && themes.some(Boolean) ? themes : undefined, floorBase: m.floorBase && m.floorBase > 1 ? Math.round(m.floorBase) : undefined };
}

const KEY = 'office_map_custom_v1';
export function saveCustomMap(m: OfficeMap) { try { localStorage.setItem(KEY, JSON.stringify(normalizeMap(m))); } catch { /* penyimpanan penuh */ } }
export function loadCustomMap(): OfficeMap | null {
  try { const s = localStorage.getItem(KEY); return s ? normalizeMap(JSON.parse(s)) : null; } catch { return null; }
}
export function exportMap(m: OfficeMap): string { return JSON.stringify(normalizeMap(m)); }
export function importMap(s: string): OfficeMap | null {
  try { const o = JSON.parse(s.trim()); if (!o || !Array.isArray(o.rows)) return null; return normalizeMap(o); } catch { return null; }
}
