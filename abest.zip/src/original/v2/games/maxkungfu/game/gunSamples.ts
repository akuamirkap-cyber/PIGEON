// data identik dengan V1: dipakai bersama supaya bundle tidak dobel (hanya konstanta)
export * from '../../../../shared/maxkungfu/game/gunSamples';
