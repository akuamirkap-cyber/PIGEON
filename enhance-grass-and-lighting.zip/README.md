# ProDrift

Simulator drift berbasis React, Vite, dan Three.js. Jalankan `npm install`, lalu `npm run dev`. Gunakan browser dengan WebGL 2. Untuk build produksi, jalankan `npm run build` dan sajikan folder `dist/`.

## Cara bermain

- **SOLO** membuka Rally Group B di **Pigeon Touge** pada kunjungan pertama. Gunakan **Pengaturan > Lintasan** atau menu jeda untuk memilih **Mt. Haruna** atau **Sirkuit Pinus** klasik. Pilihan disimpan di perangkat.
- **GARASI** menampilkan mobil Rally Group B di diorama menu asli. Opsi bodi, spoiler, livery, dan warna bisa dipratinjau langsung. Pilih **Apply** untuk memakai dan menyimpan modifikasi.
- **Mt. Haruna** memakai gerbang, garis start, posisi dan arah mobil, serta kendali dan batas lintasan dari ZIP ProDrift. **R** mengulang dari titik start yang sama. Pilih **Jeda > Jelajah medan** untuk membuka pembatas jalan dan memakai fisika lereng bebas; **Kembali ke kendali ProDrift** mengaktifkan kembali mode asli.
- **WASD** atau tombol panah untuk berkendara, **Spasi** untuk rem tangan, **C** untuk kamera, **R** untuk kembali ke titik awal, dan **P** atau **Esc** untuk jeda. Kontrol sentuh tersedia di layar kecil.
- **G** membuka pencahayaan di lintasan. Atur cahaya sekitar, matahari, dan bayangan masing-masing dari 0 sampai 100%. Tombol **Tanpa bayangan** hanya mengubah bayangan, sehingga cahaya lainnya tetap sama saat dibandingkan.
- **PIGEON asli** adalah tampilan bawaan kedua map pegunungan. Berkas cahaya di sela pepohonan, debu, kabut, dan pascaproses HDR (bloom, vignette, ACES) mengikuti arsip PIGEON. **Pulihkan PIGEON asli** memilih cuaca cerah dan mengembalikan ketiga slider ke 100%. `F` atau pilihan **Sinematik ProDrift** membandingkan filter tanpa mengganti map atau mereset mobil.

## Sumber trek

- [Arsip ProDrift](<https://github.com/akuamirkap-cyber/knife/blob/main/refine-hand-and-lighting%20(2).zip>): mobil, kendali drift, menu dan garasi, arena lama, serta rute, perbukitan, pegunungan, dan danau Mt. Haruna.
- [Arsip PIGEON](<https://github.com/akuamirkap-cyber/PIGEON/blob/main/realistic-3d-map-creation%20(1).zip>): geometri jalur utama, profil medan, tekstur aspal dan tanah, pohon serta semak prosedural, dan rig cahaya hutan. Mt. Haruna mempertahankan rutenya sendiri tetapi menggunakan material, vegetasi, dan cahaya dari PIGEON.

Di **Pigeon Touge** dan **Jelajah medan**, roda mengambil ketinggian dari segitiga yang sama dengan permukaan yang dirender. Gravitasi memengaruhi laju di lereng dan mobil bisa meninggalkan tanah, jatuh, lalu mendarat. Kabut di sekitar lintasan Haruna tetap mengikuti PIGEON; pada medan jauh, siluet gunung dibiarkan terlihat melalui kabut. Arena Haruna klasik yang terpisah tetap tersedia dari tab **Arena lainnya**.