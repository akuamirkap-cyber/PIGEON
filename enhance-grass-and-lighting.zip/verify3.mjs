import { chromium } from 'playwright';

const base = 'http://127.0.0.1:4173';
const browser = await chromium.launch({
  args: ['--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader', '--disable-gpu-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 800, height: 450 } });
page.on('pageerror', e => console.log('[pageerror]', e.message));
const shot = (path) => page.screenshot({ path, timeout: 120000 });
await page.goto(base, { waitUntil: 'load', timeout: 90000 });
await page.waitForTimeout(3000);
await page.getByRole('button', { name: 'SOLO', exact: true }).click();
await page.waitForTimeout(12000);
await page.keyboard.press('p');
await page.waitForTimeout(1500);
await page.getByRole('button', { name: 'Mt. Haruna', exact: true }).first().click({ noWaitAfter: true, timeout: 6000 });
console.log('haruna clicked');
await page.waitForTimeout(20000);
await page.keyboard.press('p');
await page.waitForTimeout(3000);
await page.keyboard.press('c'); // overhead
await page.waitForTimeout(2500);
await page.keyboard.press('c'); // cockpit
await page.waitForTimeout(4000);
await shot('v3-cockpit-default.png');
console.log('cockpit default ok');
await page.keyboard.press('g');
await page.waitForTimeout(900);
const v2 = page.getByRole('button', { name: 'Pencahayaan V2 Alami' });
console.log('v2 buttons:', await v2.count());
if (await v2.count()) await v2.first().click({ noWaitAfter: true, timeout: 6000 });
await page.waitForTimeout(1200);
await page.keyboard.press('g');
await page.waitForTimeout(3500);
await shot('v3-cockpit-v2.png');
console.log('cockpit v2 ok');
await page.keyboard.press('c'); // bumper? cycles to bumper
await page.waitForTimeout(2500);
await page.keyboard.press('c'); // back to chase
await page.waitForTimeout(4000);
await shot('v3-chase-v2.png');
console.log('chase v2 ok');
await browser.close();
