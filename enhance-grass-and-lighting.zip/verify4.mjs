import { chromium } from 'playwright';

const base = 'http://127.0.0.1:4173';
const browser = await chromium.launch({
  args: ['--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader', '--disable-gpu-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 800, height: 450 } });
page.on('pageerror', e => console.log('[pageerror]', e.message));
const shot = (path) => page.screenshot({ path, timeout: 120000 });
await page.goto(base, { waitUntil: 'load', timeout: 90000 });
await page.waitForTimeout(3000);
await page.getByRole('button', { name: 'SOLO', exact: true }).click();
await page.waitForTimeout(12000);
await page.keyboard.press('p');
await page.waitForTimeout(1500);
await page.getByRole('button', { name: 'Mt. Haruna', exact: true }).first().click({ noWaitAfter: true, timeout: 6000 });
console.log('haruna clicked; waiting for rebuild');
await page.waitForTimeout(35000);
const resume = page.getByRole('button', { name: 'Lanjut mengemudi' });
console.log('resume buttons:', await resume.count());
if (await resume.count()) await resume.first().click({ noWaitAfter: true, timeout: 6000 });
await page.waitForTimeout(6000);
await shot('v4-haruna-chase.png');
console.log('chase ok');
// cockpit via keyboard C twice (chase -> overhead -> cockpit)
await page.keyboard.press('c');
await page.waitForTimeout(3000);
await page.keyboard.press('c');
await page.waitForTimeout(4000);
await shot('v4-haruna-cockpit.png');
console.log('cockpit ok');
// open Pencahayaan panel via the minimal-HUD button
const penc = page.getByRole('button', { name: 'Pencahayaan dan bayangan' });
console.log('penc buttons:', await penc.count());
if (await penc.count()) await penc.first().click({ noWaitAfter: true, timeout: 6000 });
await page.waitForTimeout(1500);
const v2 = page.getByRole('button', { name: 'Pencahayaan V2 Alami' });
console.log('v2 buttons:', await v2.count());
if (await v2.count()) await v2.first().click({ noWaitAfter: true, timeout: 6000 });
await page.waitForTimeout(1500);
await shot('v4-panel-v2.png');
// close panel
const close = page.getByRole('button', { name: 'Tutup panel' });
if (await close.count()) await close.first().click({ noWaitAfter: true, timeout: 6000 });
await page.waitForTimeout(4000);
await shot('v4-cockpit-v2.png');
console.log('v2 cockpit ok');
await browser.close();
