import { chromium } from 'playwright';

const base = 'http://127.0.0.1:4173';
const browser = await chromium.launch({
  args: ['--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader', '--disable-gpu-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
page.on('pageerror', e => console.log('[pageerror]', e.message));
await page.goto(base, { waitUntil: 'load', timeout: 90000 });
await page.waitForTimeout(2500);
await page.getByRole('button', { name: 'SOLO', exact: true }).click();
await page.waitForTimeout(10000);
console.log('course loaded');
await page.keyboard.press('p');
await page.waitForTimeout(1200);
await page.getByRole('button', { name: 'Mt. Haruna', exact: true }).first().click({ noWaitAfter: true, timeout: 8000 });
console.log('clicked haruna; waiting for rebuild');
await page.waitForTimeout(15000);
await page.screenshot({ path: 'verify-paused-haruna.png' });
await page.keyboard.press('p'); // resume race
await page.waitForTimeout(2500);
await page.screenshot({ path: 'verify-haruna.png' });
console.log('haruna shot');
// open lighting panel and enable V2
await page.keyboard.press('g');
await page.waitForTimeout(900);
await page.getByRole('button', { name: 'Pencahayaan V2 Alami' }).click({ noWaitAfter: true, timeout: 8000 });
console.log('v2 selected');
await page.waitForTimeout(1200);
await page.keyboard.press('g');
await page.waitForTimeout(2500);
await page.screenshot({ path: 'verify-haruna-v2.png' });
console.log('v2 shot');
await browser.close();
