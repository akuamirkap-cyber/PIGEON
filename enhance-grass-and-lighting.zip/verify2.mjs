import { chromium } from 'playwright';

const base = 'http://127.0.0.1:4173';
const browser = await chromium.launch({
  args: ['--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader', '--disable-gpu-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 800, height: 450 } });
page.on('pageerror', e => console.log('[pageerror]', e.message));
const shot = (path) => page.screenshot({ path, timeout: 120000 });
await page.goto(base, { waitUntil: 'load', timeout: 90000 });
await page.waitForTimeout(3000);
await page.getByRole('button', { name: 'SOLO', exact: true }).click();
await page.waitForTimeout(14000);
console.log('pigeon loaded');
await page.keyboard.press('p');
await page.waitForTimeout(1500);
await page.getByRole('button', { name: 'Mt. Haruna', exact: true }).first().click({ noWaitAfter: true, timeout: 6000 });
console.log('haruna clicked');
await page.waitForTimeout(22000);
await shot('v2-haruna-paused.png');
console.log('paused shot ok');
await page.keyboard.press('p');
await page.waitForTimeout(4000);
await shot('v2-haruna-chase.png');
console.log('chase shot ok');
await page.getByRole('button', { name: 'Kokpit', exact: true }).click({ timeout: 8000 });
await page.waitForTimeout(4000);
await shot('v2-haruna-cockpit.png');
console.log('cockpit shot ok');
// V2 lighting
await page.keyboard.press('c'); // back to overhead? (cycle: cockpit -> bumper)
await page.waitForTimeout(500);
await page.keyboard.press('g');
await page.waitForTimeout(800);
const v2 = page.getByRole('button', { name: 'Pencahayaan V2 Alami' });
console.log('v2 buttons:', await v2.count());
if (await v2.count()) await v2.first().click({ noWaitAfter: true, timeout: 6000 });
await page.waitForTimeout(1000);
await page.keyboard.press('g');
await page.waitForTimeout(3000);
await shot('v2-haruna-v2.png');
console.log('v2 shot ok');
await browser.close();
