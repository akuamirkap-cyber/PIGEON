import { useEffect, useReducer, useSyncExternalStore } from 'react';
import { settingsStore, uiStore } from '../game/settings';
import { engineRef, onGameEvent, type GameEvent } from '../game/engine';

export function useSettings() {
  return useSyncExternalStore(settingsStore.subscribe, settingsStore.get);
}

export function useUI() {
  return useSyncExternalStore(uiStore.subscribe, uiStore.get);
}

export function useTicker(hz = 30) {
  const [tick, force] = useReducer((x: number) => x + 1, 0);
  useEffect(() => {
    const id = window.setInterval(force, 1000 / hz);
    return () => window.clearInterval(id);
  }, [hz]);
  return tick;
}

export function useTelemetry(hz = 30) {
  useTicker(hz);
  return engineRef.current?.telemetry ?? null;
}

export function useGameEvents(fn: (e: GameEvent) => void) {
  useEffect(() => onGameEvent(fn), [fn]);
}

export const fmtTime = (t: number) => {
  if (!t) return '--:--.--';
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${m}:${s.toFixed(2).padStart(5, '0')}`;
};

export const fmtNum = (n: number) => Math.round(n).toLocaleString('id-ID');
