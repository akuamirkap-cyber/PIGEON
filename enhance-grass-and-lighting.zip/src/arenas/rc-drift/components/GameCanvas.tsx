import { useEffect, useRef, useState } from 'react';
import { GameEngine } from '../game/engine';

export default function GameCanvas({ onReady }: { onReady?: () => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    let engine: GameEngine | null = null;
    try {
      engine = new GameEngine(ref.current);
      onReady?.();
    } catch (e) {
      console.error(e);
      setError('WebGL tidak tersedia di browser ini. Coba gunakan Chrome/Edge/Firefox terbaru.');
    }
    return () => engine?.dispose();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div ref={ref} className="absolute inset-0">
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black text-center text-red-400 p-8">{error}</div>
      )}
    </div>
  );
}
