import { useCallback, useMemo, useRef, useState } from 'react';
import { CAMERA_NAMES, engineRef, type GameEvent, type Telemetry } from '../game/engine';
import { matchPreset, type Settings } from '../game/settings';
import { fmtNum, fmtTime, useGameEvents, useSettings, useTelemetry } from './useGame';

interface Toast {
  id: number;
  kind: 'drift' | 'crash' | 'lap' | 'info' | 'maneuver';
  title: string;
  sub?: string;
  tone?: string;
  born: number;
}

function Bar({ value, color, center = true, label, right }: { value: number; color: string; center?: boolean; label: string; right?: string }) {
  const v = Math.max(-1, Math.min(1, value));
  return (
    <div className="mb-1.5">
      <div className="flex justify-between text-[9px] font-bold tracking-[0.18em] text-white/55 uppercase">
        <span>{label}</span>
        <span className="tabular-nums text-white/75">{right}</span>
      </div>
      <div className="relative h-2 rounded-full bg-white/10 overflow-hidden">
        {center && <div className="absolute left-1/2 top-0 h-full w-px bg-white/30" />}
        <div
          className="absolute top-0 h-full rounded-full transition-[width,left] duration-75"
          style={
            center
              ? { left: `${50 + Math.min(0, -v) * 50}%`, width: `${Math.abs(v) * 50}%`, background: color }
              : { left: 0, width: `${Math.max(0, v) * 100}%`, background: color }
          }
        />
      </div>
    </div>
  );
}

function Transmitter({ t, s }: { t: Telemetry; s: Settings }) {
  const wheelRot = -t.steerInput * 42;
  const trig = t.throttle > 0.01 ? -t.throttle / Math.max(0.3, s.throttleEPA / 100) : t.brake > 0 || t.reversing ? 0.8 : 0;
  return (
    <div className="pointer-events-none w-[300px] rounded-2xl border border-white/10 bg-black/65 p-3 shadow-2xl">
      <div className="mb-2 flex items-center justify-between">
        <div className="text-[10px] font-black tracking-[0.25em] text-white/70">XTR-03 • FULL PROPO</div>
        <div className="flex items-center gap-1.5 text-[10px] font-bold">
          <span
            className={`h-2 w-2 rounded-full ${s.gyroOn ? 'bg-sky-400 shadow-[0_0_8px_#38bdf8] animate-pulse' : 'bg-red-500 shadow-[0_0_8px_#ef4444]'}`}
          />
          <span className={s.gyroOn ? 'text-sky-300' : 'text-red-400'}>MGX {s.gyroOn ? `${s.gyroGain}%` : 'OFF'}</span>
        </div>
      </div>
      <div className="flex gap-3">
        <svg viewBox="0 0 110 120" className="h-[112px] w-[100px] shrink-0">
          <defs>
            <linearGradient id="txb" x1="0" x2="1">
              <stop offset="0" stopColor="#2b2f38" />
              <stop offset="1" stopColor="#14161b" />
            </linearGradient>
          </defs>
          {/* body */}
          <path d="M18 18 L80 14 Q92 14 92 26 L90 52 Q88 60 78 62 L58 64 L52 112 Q50 118 42 118 L34 118 Q27 117 28 110 L34 62 L20 58 Q12 55 12 46 L12 26 Q12 18 18 18 Z" fill="url(#txb)" stroke="#555b66" strokeWidth="1.2" />
          <rect x="22" y="22" width="34" height="14" rx="2" fill="#0d1117" stroke="#3b82f6" strokeWidth="0.8" />
          <text x="39" y="32" textAnchor="middle" fontSize="7" fill="#60a5fa" fontFamily="monospace">
            {Math.round(t.speedKmh)}k
          </text>
          {/* trigger */}
          <g transform={`translate(${44 + trig * 7} 0)`}>
            <path d="M34 66 Q30 76 36 84 L42 84 Q40 75 44 66 Z" fill={t.throttle > 0.01 ? '#22c55e' : t.brake > 0 || t.reversing ? '#ef4444' : '#9ca3af'} />
          </g>
          {/* wheel */}
          <g transform={`translate(86 38) rotate(${wheelRot})`}>
            <circle r="20" fill="#1f2229" stroke="#e5e7eb" strokeWidth="3" />
            <circle r="14" fill="none" stroke="#4b5563" strokeWidth="1" />
            {[0, 120, 240].map((a) => (
              <line key={a} x1="0" y1="0" x2={Math.sin((a * Math.PI) / 180) * 18} y2={-Math.cos((a * Math.PI) / 180) * 18} stroke="#d1d5db" strokeWidth="2.5" />
            ))}
            <rect x="-2" y="-21" width="4" height="6" rx="1" fill="#f59e0b" />
            <circle r="4" fill="#ef4444" />
          </g>
        </svg>
        <div className="flex-1 pt-1">
          <Bar label="Input Setir" value={t.userSteer} color="#e5e7eb" right={`${Math.round(t.steerInput * 100)}%`} />
          <Bar label="Koreksi Gyro" value={t.gyroCorr} color="#38bdf8" right={`${Math.round(t.gyroCorr * s.steerAngle)}°`} />
          <Bar label="Output Servo" value={t.servo} color="#f59e0b" right={`${Math.round(t.servo * s.steerAngle)}°`} />
          <Bar label={t.reversing ? 'Mundur' : t.brake > 0 ? 'Rem ESC' : 'Gas'} value={t.reversing ? 0.5 : t.brake > 0 ? t.brake : t.throttle} center={false} color={t.brake > 0 || t.reversing ? '#ef4444' : '#22c55e'} right={`${Math.round((t.brake > 0 ? t.brake : t.throttle) * 100)}%`} />
        </div>
      </div>
    </div>
  );
}

function DriftGauge({ angle, yaw }: { angle: number; yaw: number }) {
  const a = Math.max(-90, Math.min(90, angle));
  const abs = Math.abs(a);
  const col = abs > 60 ? '#ef4444' : abs > 25 ? '#f59e0b' : abs > 12 ? '#22c55e' : '#9ca3af';
  const arc = (from: number, to: number) => {
    const r = 46;
    const p = (d: number) => {
      const rad = ((d - 90) * Math.PI) / 180;
      return `${60 + Math.cos(rad) * r} ${58 + Math.sin(rad) * r}`;
    };
    return `M ${p(from)} A ${r} ${r} 0 ${Math.abs(to - from) > 180 ? 1 : 0} 1 ${p(to)}`;
  };
  return (
    <svg viewBox="0 0 120 70" className="w-[150px]">
      <path d={arc(-90, 90)} stroke="#ffffff22" strokeWidth="7" fill="none" strokeLinecap="round" />
      <path d={arc(-60, -25)} stroke="#f59e0b55" strokeWidth="7" fill="none" />
      <path d={arc(25, 60)} stroke="#f59e0b55" strokeWidth="7" fill="none" />
      <path d={arc(-25, -12)} stroke="#22c55e55" strokeWidth="7" fill="none" />
      <path d={arc(12, 25)} stroke="#22c55e55" strokeWidth="7" fill="none" />
      <g transform={`rotate(${-a} 60 58)`}>
        <line x1="60" y1="58" x2="60" y2="16" stroke={col} strokeWidth="3" strokeLinecap="round" />
      </g>
      <circle cx="60" cy="58" r="4" fill={col} />
      <text x="60" y="44" textAnchor="middle" fontSize="15" fontWeight="900" fill="white" fontStyle="italic">
        {Math.round(abs)}°
      </text>
      <text x="6" y="68" fontSize="6.5" fill="#ffffff88">
        YAW {Math.round(yaw)}°/s
      </text>
    </svg>
  );
}

function WheelLoads({ loads }: { loads: number[] }) {
  const total = loads.reduce((a, b) => a + b, 0) || 1;
  const pct = loads.map((l) => (l / total) * 100);
  const cell = (i: number) => {
    const p = pct[i];
    const h = Math.min(1, p / 45);
    const col = p > 31 ? '#ef4444' : p > 26 ? '#f59e0b' : p > 19 ? '#22c55e' : '#38bdf8';
    return (
      <div key={i} className="flex flex-col items-center gap-0.5">
        <div className="relative h-7 w-3.5 overflow-hidden rounded-sm bg-white/10">
          <div className="absolute bottom-0 w-full rounded-sm" style={{ height: `${h * 100}%`, background: col }} />
        </div>
        <span className="text-[8px] tabular-nums text-white/60">{Math.round(p)}%</span>
      </div>
    );
  };
  return (
    <div className="flex items-center gap-2">
      <div className="text-[9px] font-bold leading-tight tracking-widest text-white/50">
        BEBAN
        <br />
        RODA
      </div>
      <div className="relative grid grid-cols-2 gap-x-5 gap-y-0.5 rounded-lg border border-white/10 px-2 py-1">
        <div className="absolute left-1/2 top-2 bottom-2 w-1.5 -translate-x-1/2 rounded bg-white/15" />
        {cell(0)}
        {cell(1)}
        {cell(2)}
        {cell(3)}
      </div>
    </div>
  );
}

function MiniMap({ t }: { t: Telemetry }) {
  const geo = useMemo(() => {
    const tr = engineRef.current?.track;
    if (!tr) return null;
    const pts = tr.pts.filter((_, i) => i % 4 === 0);
    const xs = pts.map((p) => p.x);
    const ys = pts.map((p) => p.y);
    const minX = Math.min(...xs) - 2;
    const maxX = Math.max(...xs) + 2;
    const minY = Math.min(...ys) - 2;
    const maxY = Math.max(...ys) + 2;
    const W = 200;
    const sc = W / (maxX - minX);
    const H = (maxY - minY) * sc;
    const map = (x: number, y: number) => [(x - minX) * sc, (maxY - y) * sc] as const;
    const d = pts.map((p, i) => `${i ? 'L' : 'M'}${map(p.x, p.y)[0].toFixed(1)} ${map(p.x, p.y)[1].toFixed(1)}`).join(' ') + 'Z';
    const st = tr.pts[0];
    return { d, W, H, map, sc, start: map(st.x, st.y), stAng: Math.atan2(st.ty, st.tx) };
  }, [engineRef.current]);
  if (!geo) return null;
  const [cx, cy] = geo.map(t.x, t.y);
  const hd = (-t.heading * 180) / Math.PI;
  return (
    <svg viewBox={`0 0 ${geo.W} ${geo.H}`} className="w-[200px]">
      <path d={geo.d} fill="none" stroke="#ffffff20" strokeWidth={3.2 * geo.sc} strokeLinejoin="round" />
      <path d={geo.d} fill="none" stroke="#ffffff70" strokeWidth="1.2" />
      <rect x={geo.start[0] - 1.5} y={geo.start[1] - 5} width="3" height="10" fill="#facc15" transform={`rotate(${(-geo.stAng * 180) / Math.PI + 90} ${geo.start[0]} ${geo.start[1]})`} />
      <g transform={`translate(${cx} ${cy}) rotate(${hd})`}>
        <circle r="7" fill="#ef444433" />
        <path d="M6 0 L-4 -3.5 L-2 0 L-4 3.5 Z" fill="#ef4444" stroke="white" strokeWidth="0.8" />
      </g>
    </svg>
  );
}

export default function HUD() {
  const t = useTelemetry(30);
  const s = useSettings();
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);

  const onEvent = useCallback((e: GameEvent) => {
    const id = ++idRef.current;
    let toast: Toast;
    if (e.type === 'drift') toast = { id, kind: 'drift', title: e.label, sub: `+${fmtNum(e.score)}  •  x${e.mult.toFixed(1)}`, born: Date.now() };
    else if (e.type === 'crash') toast = { id, kind: 'crash', title: 'NABRAK!', sub: `Combo hilang −${fmtNum(e.lost)}`, born: Date.now() };
    else if (e.type === 'maneuver')
      toast = { id, kind: 'maneuver', title: e.kind === 'donut' ? `DONUT x${e.count}` : `ANGKA 8! #${e.count}`, sub: `+${fmtNum(e.bonus)}`, born: Date.now() };
    else if (e.type === 'lap') toast = { id, kind: 'lap', title: e.best ? 'LAP TERBAIK!' : 'LAP SELESAI', sub: fmtTime(e.time), born: Date.now() };
    else toast = { id, kind: 'info', title: e.text, tone: e.tone, born: Date.now() };
    setToasts((ts) => [...ts.filter((x) => (toast.kind === 'info' ? x.kind !== 'info' : true)).slice(-3), toast]);
    window.setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), toast.kind === 'info' ? 1500 : 2600);
  }, []);
  useGameEvents(onEvent);

  if (!t) return null;
  const drifting = t.drifting;

  return (
    <div className="pointer-events-none absolute inset-0 select-none font-game text-white">
      {/* score */}
      <div className="absolute left-4 top-4 w-[260px] rounded-2xl border border-white/10 bg-black/60 p-3">
        <div className="flex items-baseline justify-between">
          <span className="text-[10px] font-bold tracking-[0.25em] text-white/50">SKOR TOTAL</span>
          <span className="text-2xl font-black italic tabular-nums">{fmtNum(t.totalScore)}</span>
        </div>
        <div
          className={`mt-2 overflow-hidden rounded-xl transition-all duration-200 ${drifting ? 'max-h-24 bg-gradient-to-r from-amber-500/90 to-red-600/90 px-3 py-2' : 'max-h-0'}`}
        >
          <div className="flex items-end justify-between">
            <div>
              <div className="text-[10px] font-black tracking-[0.3em] text-black/70">DRIFT!</div>
              <div className="text-3xl font-black italic leading-none tabular-nums">{fmtNum(t.driftScore)}</div>
            </div>
            <div className="text-3xl font-black italic text-black/80">x{t.multiplier.toFixed(1)}</div>
          </div>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] font-semibold text-white/60">
          <span>
            Donut <b className="text-fuchsia-300">{t.donuts}</b> • Angka 8 <b className="text-fuchsia-300">{t.eights}</b>
          </span>
          {t.loopProgress > 0.05 && (
            <span className="flex items-center gap-1">
              {t.loopDir > 0 ? '↺' : '↻'}
              <span className="h-1.5 w-14 overflow-hidden rounded-full bg-white/10">
                <span className="block h-full bg-fuchsia-400" style={{ width: `${t.loopProgress * 100}%` }} />
              </span>
            </span>
          )}
        </div>
        <div className="mt-1 flex justify-between text-[11px] font-semibold text-white/60">
          <span>Rekor drift</span>
          <span className="tabular-nums text-amber-300">{fmtNum(t.bestDrift)}</span>
        </div>
      </div>

      {/* status chips */}
      <div className="absolute right-4 top-4 flex max-w-[60vw] flex-wrap justify-end gap-1.5 text-[11px] font-black tracking-wider">
        <span className="rounded-md bg-white/90 px-2 py-1 text-black">SETELAN: {matchPreset(s)?.name ?? 'Kustom'}</span>
        <span className={`rounded-md px-2 py-1 ${s.drivetrain === 'RWD' ? 'bg-red-600/85' : 'bg-emerald-600/85'}`}>
          {s.drivetrain}
          {s.drivetrain === 'AWD' ? ` ${s.awdRatio.toFixed(2)}` : ''}
        </span>
        <span className={`rounded-md px-2 py-1 ${s.gyroOn ? 'bg-sky-600/85' : 'bg-zinc-700/85 text-red-300'}`}>GYRO {s.gyroOn ? `${s.gyroGain}%` : 'OFF'}</span>
        <span className={`rounded-md px-2 py-1 ${s.steerAssist ? 'bg-violet-600/80' : 'bg-zinc-700/85'}`}>ASISTEN {s.steerAssist ? 'ON' : 'OFF'}</span>
        <span className="rounded-md bg-zinc-800/85 px-2 py-1">EPA {s.throttleEPA}%</span>
        {s.tractionControl > 0 && (
          <span className={`rounded-md px-2 py-1 ${t.tcCut > 0.15 ? 'bg-lime-500 text-black' : 'bg-lime-700/80'}`}>TC {s.tractionControl}%</span>
        )}
        {s.speedLimit > 0 && <span className="rounded-md bg-amber-600/85 px-2 py-1">MAKS {s.speedLimit} km/j</span>}
        <span className="rounded-md bg-zinc-800/85 px-2 py-1">CAM: {CAMERA_NAMES[t.camera]}</span>
        <span className="rounded-md bg-zinc-900/70 px-2 py-1 text-white/50">{Math.round(t.fps)} FPS</span>
      </div>

      {/* toasts */}
      <div className="absolute left-1/2 top-20 flex -translate-x-1/2 flex-col items-center gap-2">
        {toasts.map((x) => (
          <div
            key={x.id}
            className={`animate-[toastIn_0.25s_ease-out] text-center ${
              x.kind === 'info'
                ? `rounded-full px-4 py-1.5 text-sm font-black tracking-widest ${x.tone === 'warn' ? 'bg-red-600/80' : x.tone === 'good' ? 'bg-emerald-600/80' : 'bg-black/60'}`
                : ''
            }`}
          >
            {x.kind === 'info' ? (
              x.title
            ) : (
              <>
                <div
                  className={`text-4xl font-black italic tracking-tight drop-shadow-[0_3px_0_rgba(0,0,0,0.6)] md:text-5xl ${
                    x.kind === 'crash' ? 'text-red-500' : x.kind === 'lap' ? 'text-sky-300' : x.kind === 'maneuver' ? 'text-fuchsia-300' : 'text-amber-300'
                  }`}
                >
                  {x.title}
                </div>
                {x.sub && <div className="text-xl font-black tabular-nums drop-shadow-[0_2px_0_rgba(0,0,0,0.6)]">{x.sub}</div>}
              </>
            )}
          </div>
        ))}
      </div>

      {/* bottom left: transmitter */}
      <div className="absolute bottom-12 left-4">
        <Transmitter t={t} s={s} />
      </div>

      {/* bottom center: speed + drift gauge */}
      <div className="absolute bottom-12 left-1/2 flex -translate-x-1/2 items-end gap-3 rounded-2xl border border-white/10 bg-black/60 px-4 py-2">
        <div className="text-center">
          <div className="text-5xl font-black italic leading-none tabular-nums">{Math.round(t.speedKmh)}</div>
          <div className="text-[10px] font-bold tracking-[0.3em] text-white/50">KM/JAM</div>
          <div className="mt-0.5 text-[9px] text-white/40">skala 1:10 ≈ {Math.round(t.speedKmh * 10)} km/j</div>
          <div className="mt-1 h-1.5 w-24 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-gradient-to-r from-sky-400 to-fuchsia-500" style={{ width: `${Math.min(100, t.rpm * 100)}%` }} />
          </div>
          <div className="text-[8px] tracking-widest text-white/40">RPM RODA BELAKANG</div>
        </div>
        <div className="flex flex-col items-center">
          <DriftGauge angle={t.driftAngle} yaw={t.yawRate} />
          <div className="-mt-1 text-[9px] font-bold tracking-[0.3em] text-white/50">SUDUT DRIFT</div>
        </div>
      </div>

      {/* bottom right: minimap + laps */}
      <div className="absolute bottom-12 right-4 w-[232px] rounded-2xl border border-white/10 bg-black/60 p-3">
        <MiniMap t={t} />
        <div className="mt-2 grid grid-cols-3 gap-1 text-center">
          <div>
            <div className="text-[9px] font-bold tracking-widest text-white/45">LAP {t.lap + 1}</div>
            <div className="text-sm font-black tabular-nums">{fmtTime(t.lapTime)}</div>
          </div>
          <div>
            <div className="text-[9px] font-bold tracking-widest text-white/45">TERAKHIR</div>
            <div className="text-sm font-black tabular-nums text-white/80">{fmtTime(t.lastLap)}</div>
          </div>
          <div>
            <div className="text-[9px] font-bold tracking-widest text-white/45">TERBAIK</div>
            <div className="text-sm font-black tabular-nums text-amber-300">{fmtTime(t.bestLap)}</div>
          </div>
        </div>
        <div className="mt-2 flex justify-center">
          <WheelLoads loads={t.loads} />
        </div>
      </div>

      {/* key hints */}
      <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 flex-wrap justify-center gap-x-3 gap-y-1 whitespace-nowrap text-[11px] font-semibold text-white/60">
        {[
          ['W/S', 'Gas/Rem'],
          ['A/D', 'Setir'],
          ['SHIFT', 'Gas halus'],
          ['SPACE', 'Rem tangan'],
          ['G', 'Gyro'],
          ['Q/E', 'Gain'],
          ['T', 'RWD/AWD'],
          ['C', 'Kamera'],
          ['B', 'Sasis'],
          ['R', 'Reset'],
          ['TAB', 'Setup'],
          ['H', 'Bantuan'],
        ].map(([k, v]) => (
          <span key={k}>
            <kbd className="rounded bg-white/15 px-1.5 py-0.5 font-black text-white">{k}</kbd> {v}
          </span>
        ))}
      </div>
    </div>
  );
}
