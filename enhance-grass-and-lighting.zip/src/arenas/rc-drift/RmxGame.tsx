import { useEffect } from 'react';
import GameCanvas from './components/GameCanvas';
import HUD from './components/HUD';
import SetupPanel from './components/SetupPanel';
import StartScreen from './components/StartScreen';
import HelpOverlay from './components/HelpOverlay';
import { useUI } from './components/useGame';
import { uiStore } from './game/settings';

export default function RmxGame({ onExit }: { onExit: () => void }) {
  const ui = useUI();

  useEffect(() => {
    uiStore.set({ mode: 'start' });
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'F2') {
        e.preventDefault();
        onExit();
        return;
      }
      const mode = uiStore.get().mode;
      const toggleSetup = e.code === 'Tab' || e.code === 'KeyP' || e.code === 'Escape';
      if (mode === 'drive') {
        if (toggleSetup) {
          e.preventDefault();
          uiStore.set({ mode: 'setup' });
        } else if (e.code === 'KeyH') {
          uiStore.set({ mode: 'help' });
        }
      } else if (mode === 'setup') {
        if (toggleSetup) {
          e.preventDefault();
          uiStore.set({ mode: 'drive' });
        }
      } else if (mode === 'help') {
        if (['KeyH', 'Escape', 'Enter', 'Tab'].includes(e.code)) {
          e.preventDefault();
          uiStore.set({ mode: 'drive' });
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onExit]);

  return (
    <div className="fixed inset-0 overflow-hidden bg-black">
      <GameCanvas />
      {ui.mode === 'drive' && <HUD />}
      {ui.mode === 'setup' && <SetupPanel onMenu={onExit} />}
      {ui.mode === 'help' && <HelpOverlay />}
      {ui.mode === 'start' && <StartScreen onExit={onExit} />}
    </div>
  );
}
