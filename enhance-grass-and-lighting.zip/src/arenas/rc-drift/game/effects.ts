import * as THREE from 'three';
import { makeSoftDotTexture } from './textures';

// ------------------------------------------------------------
//  Skid marks: ring buffer of quads (one strip per wheel)
// ------------------------------------------------------------
export class Skidmarks {
  mesh: THREE.Mesh;
  private max: number;
  private pos: Float32Array;
  private alpha: Float32Array;
  private head = 0;
  private dirty = false;
  private last: ({ x: number; z: number; lx: number; lz: number; rx: number; rz: number; a: number } | null)[] = [null, null, null, null];

  constructor(max = 4000) {
    this.max = max;
    this.pos = new Float32Array(max * 4 * 3);
    this.alpha = new Float32Array(max * 4);
    const idx = new Uint32Array(max * 6);
    for (let i = 0; i < max; i++) {
      const v = i * 4;
      idx.set([v, v + 2, v + 1, v + 1, v + 2, v + 3], i * 6);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    g.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e4);
    const m = new THREE.ShaderMaterial({
      uniforms: { color: { value: new THREE.Color(0x0c0c0e) } },
      vertexShader: `attribute float alpha; varying float vA;
        void main(){ vA = alpha; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `uniform vec3 color; varying float vA;
        void main(){ gl_FragColor = vec4(color, vA); }`,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      side: THREE.DoubleSide,
    });
    this.mesh = new THREE.Mesh(g, m);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 1;
  }

  add(wheel: number, x: number, z: number, dx: number, dz: number, intensity: number, width = 0.024) {
    const l = Math.hypot(dx, dz) || 1;
    const px = (-dz / l) * width * 0.5;
    const pz = (dx / l) * width * 0.5;
    const cur = { x, z, lx: x + px, lz: z + pz, rx: x - px, rz: z - pz, a: Math.min(0.55, intensity * 0.6) };
    const prev = this.last[wheel];
    if (!prev) {
      this.last[wheel] = cur;
      return;
    }
    const d = Math.hypot(x - prev.x, z - prev.z);
    if (d < 0.025) return;
    if (d > 0.5) {
      this.last[wheel] = cur;
      return;
    }
    const i = this.head;
    const y = 0.0062;
    this.pos.set([prev.lx, y, prev.lz, prev.rx, y, prev.rz, cur.lx, y, cur.lz, cur.rx, y, cur.rz], i * 12);
    this.alpha.set([prev.a, prev.a, cur.a, cur.a], i * 4);
    this.head = (this.head + 1) % this.max;
    this.last[wheel] = cur;
    this.dirty = true;
  }

  lift(wheel: number) {
    this.last[wheel] = null;
  }

  clear() {
    this.pos.fill(0);
    this.alpha.fill(0);
    this.last = [null, null, null, null];
    this.dirty = true;
  }

  flush() {
    if (!this.dirty) return;
    const g = this.mesh.geometry;
    g.attributes.position.needsUpdate = true;
    g.attributes.alpha.needsUpdate = true;
    this.dirty = false;
  }
}

// ------------------------------------------------------------
//  Dust / light smoke particles
// ------------------------------------------------------------
export class Smoke {
  points: THREE.Points;
  private max: number;
  private pos: Float32Array;
  private vel: Float32Array;
  private life: Float32Array;
  private maxLife: Float32Array;
  private size: Float32Array;
  private alpha: Float32Array;
  private next = 0;
  material: THREE.ShaderMaterial;

  constructor(max = 600) {
    this.max = max;
    this.pos = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max).fill(1);
    this.size = new Float32Array(max);
    this.alpha = new Float32Array(max);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('size', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.material = new THREE.ShaderMaterial({
      uniforms: {
        map: { value: makeSoftDotTexture() },
        color: { value: new THREE.Color(0xd9dbe0) },
        scale: { value: 500 },
      },
      vertexShader: `attribute float size; attribute float alpha; varying float vA; uniform float scale;
        void main(){ vA = alpha; vec4 mv = modelViewMatrix * vec4(position,1.0);
          gl_PointSize = size * scale / max(0.05, -mv.z); gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform sampler2D map; uniform vec3 color; varying float vA;
        void main(){ vec4 t = texture2D(map, gl_PointCoord); float a = t.a * vA; if (a < 0.003) discard; gl_FragColor = vec4(color, a); }`,
      transparent: true,
      depthWrite: false,
    });
    this.points = new THREE.Points(g, this.material);
    this.points.frustumCulled = false;
    this.points.renderOrder = 2;
  }

  spawn(x: number, y: number, z: number, vx: number, vz: number, intensity: number) {
    const i = this.next;
    this.next = (this.next + 1) % this.max;
    this.pos[i * 3] = x + (Math.random() - 0.5) * 0.03;
    this.pos[i * 3 + 1] = y;
    this.pos[i * 3 + 2] = z + (Math.random() - 0.5) * 0.03;
    this.vel[i * 3] = vx * 0.25 + (Math.random() - 0.5) * 0.25;
    this.vel[i * 3 + 1] = 0.08 + Math.random() * 0.12;
    this.vel[i * 3 + 2] = vz * 0.25 + (Math.random() - 0.5) * 0.25;
    this.maxLife[i] = 0.9 + Math.random() * 1.1;
    this.life[i] = this.maxLife[i];
    this.size[i] = 0.04;
    this.alpha[i] = 0.18 * intensity;
  }

  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) {
        if (this.alpha[i] !== 0) this.alpha[i] = 0;
        continue;
      }
      this.life[i] -= dt;
      const t = 1 - this.life[i] / this.maxLife[i];
      const damp = Math.exp(-dt * 1.8);
      this.vel[i * 3] *= damp;
      this.vel[i * 3 + 2] *= damp;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.size[i] = 0.05 + t * 0.32;
      this.alpha[i] = Math.max(0, (1 - t) * (1 - t)) * 0.2;
    }
    const g = this.points.geometry;
    g.attributes.position.needsUpdate = true;
    g.attributes.size.needsUpdate = true;
    g.attributes.alpha.needsUpdate = true;
  }
}
