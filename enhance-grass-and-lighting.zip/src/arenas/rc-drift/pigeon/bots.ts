import type * as Three from 'three';
import { createRallyCarModel } from './rally-model.js';
import { CAR_SCALE } from './rmx-drift-adapter';
import { defaultBuild } from './rally-config';
import type { RallyBuild } from './rally-config';

/**
 * 5 AI rivals for PRODRIFT's Rally Group B Lab.
 * Track positions are kinematic (follow the racing line, corner-speed limited by upcoming curvature,
 * light rubber-banding vs the player's lap distance) and the full Group B model is animated through
 * its own tick() for wheels, body roll and brake lights. Bots start behind the player, race to the
 * finish, and either loop the circuit or re-grid themselves automatically; a player restart (R)
 * resets the whole grid.
 */
export type BotTrackSample = { x: number; y: number; z: number; tx: number; tz: number; curv: number };
export type BotTrack = {
  length: number;
  /** loop = circuit, odometer wraps; otherwise point-to-point (bots re-grid at the finish) */
  loop: boolean;
  at(s: number): BotTrackSample;
};

export type BotPlayerBody = { x: number; z: number; yaw: number; vx: number; vz: number; yawRate?: number };

export type BotGrid = {
  group: Three.Group;
  setTrack(next: BotTrack): void;
  update(dt: number, playerDistance: number, playerLane: number, active: boolean): void;
  /**
   * Hard 2D OBB collision between the player's car and the bots — cars are solid, not ghosts.
   * SAT on both vehicles' ejes, full positional depenetration for the player, momentum exchange
   * along the contact normal, bot lane/speed/yaw-kick shove. Returns the strongest closing speed (m/s).
   */
  resolvePlayerCollision(player: BotPlayerBody): number;
  /** Put every bot back on the start grid, behind the player's start line. */
  placeAtStart(): void;
  dispose(): void;
};

/** Five liveries clearly distinct from the player's usual build. */
const BOT_BUILDS: RallyBuild[] = [
  { ...defaultBuild, theme: 'blue', nose: 'evo', wing: 'works', vinyl: 'rally', skin: 'peach' },
  { ...defaultBuild, theme: 'green', nose: 'evo', wing: 'high', vinyl: 'rally', skin: 'asian' },
  { ...defaultBuild, theme: 'black', nose: 'classic', wing: 'high', vinyl: 'rally', skin: 'ethiopian' },
  { ...defaultBuild, theme: 'blue', nose: 'classic', wing: 'works', vinyl: 'heritage', skin: 'ethiopian' },
  { ...defaultBuild, theme: 'green', nose: 'evo', wing: 'works', vinyl: 'heritage', skin: 'peach' },
];
/** Grid slots behind the start line: two abreast, then a staggered single file. */
const GRID_SLOTS = [
  { back: 6.1, lane: -1.5 },
  { back: 6.1, lane: 1.5 },
  { back: 10.2, lane: -0.35 },
  { back: 14.6, lane: 1.8 },
  { back: 14.6, lane: -2.0 },
] as const;
/** Personal pace per bot so the field spreads out and they genuinely duel each other (and the player). */
const PACE = [1.0, 0.952, 1.046, 0.976, 1.02] as const;

export function createBotGrid(T: typeof Three, track: BotTrack): BotGrid {
  const group = new T.Group();
  group.name = 'Rival Bot Grid';

  const bots = BOT_BUILDS.map((build, index) => {
    const car = createRallyCarModel({ THREE: T, build, headlights: false });
    // Rival cars stay light on the shadow pass: they do not cast or receive sun shadows.
    car.traverse(node => {
      const mesh = node as Three.Mesh;
      if (mesh.isMesh) { mesh.castShadow = false; mesh.receiveShadow = false; }
    });
    car.name = `Rival Bot ${index + 1}`;
    car.scale.setScalar(CAR_SCALE);
    car.rotation.order = 'YXZ';
    group.add(car);
    return {
      car,
      index,
      dist: -GRID_SLOTS[index].back,
      v: 0,
      lane: GRID_SLOTS[index].lane as number,
      phase: index * 2.13 + 0.7,
      steerVis: 0,
      betaVis: 0,
      prevV: 0,
      braking: false,
    };
  });

  let current = track;
  const clamp = T.MathUtils.clamp;
  const euclidModulo = T.MathUtils.euclideanModulo;

  function sampleWorld(s: number): BotTrackSample {
    if (current.loop) return current.at(euclidModulo(s, current.length));
    if (s < 0) { // before the start: extrapolate straight back from the line
      const p0 = current.at(0), back = -s;
      return { ...p0, x: p0.x - p0.tx * back, z: p0.z - p0.tz * back };
    }
    return current.at(clamp(s, 0, current.length - 1e-3));
  }
  function lapPosition(s: number): number {
    return current.loop ? euclidModulo(s, current.length) : clamp(s, 0, current.length - 1e-3);
  }

  function placeAtStart() {
    for (const bot of bots) {
      const slot = GRID_SLOTS[bot.index];
      bot.dist = -slot.back; bot.v = 0; bot.prevV = 0;
      bot.lane = slot.lane; bot.steerVis = 0; bot.betaVis = 0; bot.braking = false;
      poseCar(bot);
    }
  }

  function poseCar(bot: (typeof bots)[number]) {
    const s = lapPosition(bot.dist);
    const here = sampleWorld(s);
    const aheadS = lapPosition(bot.dist + 1.6), behindS = lapPosition(bot.dist - 1.6);
    const ahead = sampleWorld(aheadS), behind = sampleWorld(behindS);
    // right of the path: (tz, -tx) — same convention as the course's lane math
    const rx = here.tz, rz = -here.tx;
    const x = here.x + rx * bot.lane, z = here.z + rz * bot.lane;
    const rise = ahead.y - behind.y;
    const run = Math.hypot(ahead.x - behind.x, ahead.z - behind.z) || 1;
    bot.car.position.set(x, here.y, z);
    // Nose-up when climbing, nose-down downhill (matches model: +rotation.x drops the nose).
    bot.car.rotation.x = -Math.atan2(rise, run);
    bot.car.rotation.y = Math.atan2(here.tx, here.tz) + bot.betaVis * 0.55;
    bot.car.rotation.z = 0;
    bot.car.visible = true;
  }

  function botCurvatureAhead(s: number, from: number, to: number): number {
    let max = 0;
    for (let d = from; d < to; d += 3) max = Math.max(max, Math.abs(sampleWorld(lapPosition(s + d)).curv));
    return max;
  }

  function update(dt: number, playerDistance: number, playerLane: number, active: boolean) {
    if (!(dt > 0)) return;
    for (const bot of bots) {
      const sNow = lapPosition(bot.dist);
      // Corner speed from the sharpest upcoming bend (mirrors the Ghost AI's planning distance)
      const look = clamp(11 + bot.v * 0.36, 12, 34);
      const maxCurv = Math.max(botCurvatureAhead(bot.dist, 3, look), 0.0042);
      const cornerSpeed = clamp(Math.sqrt(30 / maxCurv), 19.5, 46);
      // Gentle rubber-band vs the human's lap (neutral pre-start / in ghost watch): trailing bots claw back, leaders back off
      const gapToPlayer = bot.dist - playerDistance;
      let rubber = 1;
      if (playerDistance > 1) {
        if (gapToPlayer < -55) rubber = 1.10; else if (gapToPlayer < -28) rubber = 1.05;
        else if (gapToPlayer > 60) rubber = 0.90; else if (gapToPlayer > 32) rubber = 0.96;
      }
      const target = active ? clamp(cornerSpeed * rubber * PACE[bot.index], 4, 46) : 0;
      if (target >= bot.v) bot.v = Math.min(target, bot.v + 11.4 * dt);
      else bot.v = Math.max(target, bot.v - 17.5 * dt);
      bot.braking = target < bot.v - 2.2;
      bot.dist += bot.v * dt;

      // Finished the point-to-point stage → automatically re-grid for the next run
      if (!current.loop && bot.dist >= current.length) {
        bot.dist = -GRID_SLOTS[bot.index].back; bot.v = 0; bot.prevV = 0; bot.lane = GRID_SLOTS[bot.index].lane;
        poseCar(bot);
        continue;
      }

      // Racing line: clip the inside of the upcoming bend + a light wander, and slip around the player
      const bendHere = sampleWorld(lapPosition(bot.dist + 5)).curv;
      let targetLane = -Math.sign(bendHere) * clamp(Math.abs(bendHere) * 125, 0, 1.85);
      targetLane += Math.sin(bot.phase + sNow * 0.018) * 0.42;
      const alongside = Math.abs(sNow - playerDistance) < 3.6;
      const sideGap = bot.lane - playerLane;
      if (alongside && Math.abs(sideGap) < 1.5) targetLane = clamp(bot.lane + (sideGap >= 0 ? 1.2 : -1.2), -4.3, 4.3);
      bot.lane += (clamp(targetLane, -4.3, 4.3) - bot.lane) * (1 - Math.exp(-dt * 2.1));

      // Visual drift attitude & steer (cosmetic only)
      const steer = clamp(bendHere * 36 + (targetLane - bot.lane) * 0.24, -1, 1);
      const beta = Math.abs(bot.v) > 16 ? clamp(bot.v * bot.v * bendHere * 0.0034, -0.4, 0.4) : 0;
      bot.steerVis += (steer - bot.steerVis) * (1 - Math.exp(-dt * 8.5));
      bot.betaVis += (beta - bot.betaVis) * (1 - Math.exp(-dt * 6));
      poseCar(bot);

      const accelLong = (bot.v - bot.prevV) / Math.max(dt, 1e-3);
      bot.prevV = bot.v;
      const accelLat = bot.v * bot.v * bendHere;
      bot.car.userData.tick(dt, {
        speed: bot.v, steer: bot.steerVis, steerAngle: bot.steerVis * 0.43,
        accelLong, accelLat, serviceBrake: bot.braking, handbrake: false,
      });
    }
  }

  const PROBE_HW = 1.01, PROBE_HL = 2.12; // matches the physics barrier probes (m)
  function resolvePlayerCollision(player: BotPlayerBody): number {
    let strongest = 0;
    const fwX = Math.sin(player.yaw), fwZ = Math.cos(player.yaw);
    const sdX = Math.cos(player.yaw), sdZ = -Math.sin(player.yaw);
    for (const bot of bots) {
      const px = bot.car.position.x, pz = bot.car.position.z;
      const dx = player.x - px, dz = player.z - pz;
      if (dx * dx + dz * dz > 90) continue; // ~9.5 m quick reject
      const fx = Math.sin(bot.car.rotation.y), fz = Math.cos(bot.car.rotation.y);
      const rx = Math.cos(bot.car.rotation.y), rz = -Math.sin(bot.car.rotation.y);
      // SAT over both vehicles' forward/right axes
      const axes = [[fx, fz], [rx, rz], [fwX, fwZ], [sdX, sdZ]] as const;
      let minPen = Infinity, nx = 0, nz = 0, separated = false;
      for (const [ax, az] of axes) {
        const pc = player.x * ax + player.z * az;
        const pw = Math.abs(fwX * ax + fwZ * az) * PROBE_HL + Math.abs(sdX * ax + sdZ * az) * PROBE_HW;
        const bc = px * ax + pz * az;
        const bw = Math.abs(fx * ax + fz * az) * PROBE_HL + Math.abs(rx * ax + rz * az) * PROBE_HW;
        const pen = pw + bw - Math.abs(pc - bc);
        if (pen <= 0) { separated = true; break; }
        if (pen < minPen) { minPen = pen; const s = pc >= bc ? 1 : -1; nx = ax * s; nz = az * s; }
      }
      if (separated || !Number.isFinite(minPen)) continue;
      const signed = nx * rx + nz * rz; // normal projected on the bot's right axis
      // Depenetrate exactly: player takes 55%, the bot is shoved the remaining 45% this frame
      // (immediate visual correction) plus a persistent lane shove that keeps them apart afterwards.
      player.x += nx * minPen * 0.55;
      player.z += nz * minPen * 0.55;
      bot.car.position.x -= nx * minPen * 0.45;
      bot.car.position.z -= nz * minPen * 0.45;
      bot.lane = clamp(bot.lane - signed * minPen * 0.8, -4.4, 4.4);
      // Momentum exchange along the normal (equal mass, mostly inelastic — steel on steel)
      const bvx = fx * bot.v, bvz = fz * bot.v;
      const rvx = player.vx - bvx, rvz = player.vz - bvz;
      const vn = rvx * nx + rvz * nz;
      if (vn < 0) {
        const e = 0.38;
        const j = (-(1 + e) * vn) / 2;
        player.vx += nx * j;
        player.vz += nz * j;
        const along = fx * nx + fz * nz;
        bot.v = clamp(bot.v - along * j * 1.35, 1.5, 46);
        bot.lane = clamp(bot.lane - signed * Math.abs(j) * 0.055, -4.4, 4.4);
        bot.betaVis += clamp(signed * j * 0.02, -0.3, 0.3);
        const torque = fwX * nz - fwZ * nx;
        if (typeof player.yawRate === 'number') player.yawRate += torque * -j * 0.055;
        bot.braking = j > 2.5;
        strongest = Math.max(strongest, -vn);
      }
    }
    return strongest;
  }

  return {
    group,
    setTrack(next) { current = next; placeAtStart(); },
    update,
    resolvePlayerCollision,
    placeAtStart,
    dispose() {
      group.removeFromParent();
      group.traverse(object => {
        const mesh = object as Three.Mesh;
        if (!mesh.isMesh) return;
        mesh.geometry?.dispose();
        const material = mesh.material as Three.Material | Three.Material[] | undefined;
        if (Array.isArray(material)) for (const entry of material) entry.dispose();
        else material?.dispose();
      });
    },
  };
}
