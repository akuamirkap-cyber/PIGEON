// ============================================================================
//  100% Exact 3D Car Drift Simulator Physics Adapter for Rally Group B Lab
//  Ported verbatim from `3d-car-drift-simulator (2).zip` (updateCarPhysics):
//    - Exact heading vs. velocity separation (oversteer / slip angle)
//    - Exact engine force (33.0), high-speed taper (/47, 0.55), brake (38.0),
//      reverse (18.0), handbrake drag (7.5), aero/rolling drag
//    - Exact steering smoothing (engage 7.5, return 9.5) & front visual steer (*0.48)
//    - Exact lateral grip (straight 6.4, sliding 3.25, handbrake 1.55, power-over *0.84)
//    - Exact tanh lateral tire force (-tanh(vLat*0.28)*grip*4.4 - vLat*(0.35|0.95))
//    - Exact yaw torque (5.4 normal / 7.6 handbrake), auto counter-steer assist (2.55),
//      intentional 360° spin / donut freedom (handbrake + |steer| > 0.85),
//      angular damping (4.2 normal / 2.4 handbrake)
//    - Exact body roll/pitch, wheel spin (vLong / 0.36), brake lights, and
//      lateral smoke intensity formula wired into PRODRIFT's own 3D smoke puffs!
//    - Exact Rally Group B Lab car body, cabin, driver hands & wheels preserved.
// ============================================================================
import { physicsStep as classicStep, wheelRadius as classicWheelRadius } from './drift-physics.js';
import type { DriftState, DriftWheel, DriverInput, Surface, WheelId } from './drift-physics.js';

export const wheelRadius = classicWheelRadius;
export const physicsStep = classicStep;

// Real-world Group B car scale (matches the 1.96m x 4.45m car in 3d-car-drift-simulator zip!)
// Rally Lab's native Group B model is 2.736 m wide -> scaled to 1.90 m wide (4.14 m long).
const MODEL_BODY_WIDTH = 2.736;
export const CAR_WIDTH = 1.9;
export const CAR_SCALE = CAR_WIDTH / MODEL_BODY_WIDTH; // ≈ 0.6944
const HALF_TRACK = 1.038 * CAR_SCALE;
const FRONT_Z = 1.665 * CAR_SCALE;
const REAR_Z = -1.433 * CAR_SCALE;

// Retained solely so rally-road.js preserves its spacious ~30 m circuit runoff (~15.07 m half-width)
export const RALLY_SCALE = (FRONT_Z - REAR_Z) / 0.257; // ≈ 8.37
export const CUE_SCALE = 1;

// Exact constants copied verbatim from 3d-car-drift-simulator (2).zip
export const DRIFT_SIM = {
  MAX_ENGINE_FORCE: 33.0,
  REVERSE_FORCE: 18.0,
  BRAKE_FORCE: 38.0,
  SPEED_TAPER_REF: 47.0,
  SPEED_TAPER_FACTOR: 0.55,
  HANDBRAKE_DRAG: 7.5,
  AERO_DRAG: 0.011,
  ROLL_DRAG: 0.55,
  DRAG_SCALE: 0.45,
  STEER_SPEED_ON: 11.0,
  STEER_SPEED_OFF: 14.0,
  GRIP_STRAIGHT: 6.4,
  GRIP_SLIDE: 4.9,
  GRIP_HANDBRAKE: 1.55,
  SLIP_SOFTEN_RAD: 0.40,
  POWER_OVER_MULT: 0.78,
  TANH_LAT_GAIN: 0.28,
  LAT_FORCE_SCALE: 4.4,
  LAT_DAMP_NORMAL: 0.95,
  LAT_DAMP_HANDBRAKE: 0.35,
  STEER_FACTOR_SPEED: 5.5,
  YAW_NORMAL: 5.1,
  YAW_HANDBRAKE: 8.2,
  COUNTER_ASSIST: 2.80,
  COUNTER_MIN_SPEED: 5.0,
  COUNTER_MIN_SLIP: 0.14,
  HARD_SPIN_STEER: 0.85,
  ANG_DAMP_NORMAL: 4.6,
  ANG_DAMP_HANDBRAKE: 2.4,
  VISUAL_STEER_MAX: 0.48,
  WHEEL_RADIUS: 0.36,
  CAR_RADIUS: 1.65,
  // Wall contact: reflect only the INTO-wall component (hard hits bounce a bit more), tangential speed preserved.
  WALL_RESTITUTION_SCRAPE: 0.12,
  WALL_RESTITUTION_CRASH: 0.30,
  WALL_CRASH_SPEED: 6.0,
  CRASH_IMPACT_SPEED: 4.5,
  CAM_DIST_CLOSE: 8.4,
  CAM_HEIGHT_CLOSE: 3.35,
  CAM_LOOK_AHEAD: 3.5,
  CAM_LOOK_Y: 1.25,
  CAM_VEL_BLEND: 0.38,
  CAM_POS_LERP: 7.5,
  CAM_LOOK_LERP: 11.0,
  CAM_BASE_FOV: 60,
  CAM_FOV_SPEED: 0.28,
  CAM_FOV_MAX_BOOST: 13,
  CAM_FOV_LERP: 5.0,
} as const;

const TAU = Math.PI * 2;
const RAD2DEG = 180 / Math.PI;
const UPSHIFT = [0, 11.2, 20.4, 29.2, 37.8, Infinity];
const DOWNSHIFT = [0, 0, 8.4, 16.5, 25.0, 33.8];
const pavement: Surface = { grip: 1, roughness: 0, height: 0 };

const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);
const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const damp = (x: number, y: number, rate: number, dt: number) => mix(x, y, 1 - Math.exp(-rate * dt));

export type DriftPopupEvent = {
  id: number;
  kind: 'power_over' | 'ebrake' | 'feint' | 'manji' | 'spin360' | 'donut';
  label: string;
  accent: 'cyan' | 'amber' | 'violet' | 'rose' | 'emerald';
  time: number;
};

/** Live 3D Car Drift Simulator telemetry mirrored to Rally Group B Lab overlay. */
export const rmxLive = {
  active: false,
  speedKmh: 0,
  slipAngleDeg: 0,
  isDrifting: false,
  isHandbrake: false,
  isManji: false,
  manjiChanges: 0,
  spinReady: false,
  steerAngle: 0,
  throttle: 0,
  brake: 0,
  vLong: 0,
  vLat: 0,
  lateralIntensity: 0,
  cueText: '',
  events: [] as DriftPopupEvent[],
};

/** Track barrier callback in real-world metres (exact drift-sim barrier bounce/slide). */
export type DriftBarrier = {
  halfWidth: number;
  laneAt: (wx: number, wz: number) => { off: number; nx: number; nz: number };
  carRadius?: number;
};

// Backwards-compatible alias
export type RmxBarrier = DriftBarrier;
export const GHOST_SETTINGS = Object.freeze({ mode: 'drift-sim' });

export function createDriftCar(
  surfaceAt: (x: number, z: number) => Surface = () => pavement,
  opts: {
    isolated?: boolean;
    settings?: unknown;
    barrier?: DriftBarrier;
    touge?: boolean;
  } = {},
) {
  const isolated = !!opts.isolated;
  const barrier = opts.barrier;

  const ids: WheelId[] = ['FL', 'FR', 'RL', 'RR'];
  const wheels = Object.fromEntries(
    ids.map((id) => [
      id,
      {
        front: id[0] === 'F',
        side: id[1] === 'L' ? 1 : -1,
        x: 0,
        z: 0,
        angle: 0,
        omega: 0,
        spin: 0,
        along: 0,
        across: 0,
        slip: 0,
        load: (1220 * 9.81) / 4,
        roughness: 0,
        height: 0,
        worldY: 0,
      } as DriftWheel,
    ]),
  ) as Record<WheelId, DriftWheel>;
  const list = ids.map((id) => wheels[id]);

  // Exact physics state matching `car` in 3d-car-drift-simulator (2).zip
  const sim = {
    x: 0,
    z: 0,
    vx: 0,
    vz: 0,
    heading: 0,
    angularVel: 0,
    steerAngle: 0, // [-1, +1]: +1 = left (A), -1 = right (D)
    wheelSpin: 0,
    roll: 0,
    pitch: 0,
    speed: 0,
    vLong: 0,
    vLat: 0,
    slipAngle: 0,
    slipAngleDeg: 0,
    lateralIntensity: 0,
    isHandbrake: false,
    collidedRecently: 0,
  };

  // Real-time maneuver detector (matching 3d-car-drift-simulator (2).zip rules)
  let simTime = 0;
  // SCANDINAVIAN FLICK state (player toggles with M in Rally Group B Lab)
  let feintMode = false, feintGripCut = 0, lastFeintSign = 0, lastFeintFlip = -9, feintKickTime = -9;
  let nextEventId = 1;
  const cooldowns: Record<DriftPopupEvent['kind'], number> = {
    power_over: -99,
    ebrake: -99,
    feint: -99,
    manji: -99,
    spin360: -99,
    donut: -99,
  };
  const det = {
    isDrifting: false,
    driftDuration: 0,
    driftSign: 0,
    signChanges: 0,
    lastSignChangeTime: -99,
    handbrakeUsed: false,
    hadFeint: false,
    lastSteerSign: 0,
    lastSteerFlipTime: -99,
    prevHeading: 0,
    spinAccum: 0,
    spinWindowStart: 0,
    spinReady: false,
    spinReadyTime: -99,
    donutAccum: 0,
    donutDir: 0,
    graceTimer: 0,
  };

  const state: DriftState = {
    x: 0,
    z: 0,
    yaw: 0,
    vx: 0,
    vz: 0,
    yawRate: 0,
    speed: 0,
    forwardSpeed: 0,
    lateralSpeed: 0,
    beta: 0,
    steer: 0,
    steerAngle: 0,
    accelLong: 0,
    accelLat: 0,
    throttle: 0,
    brake: 0,
    rearLock: 0,
    rev: 0.16,
    gear: '1',
    shifting: false,
    handbrake: false,
    serviceBrake: false,
    rearSlip: 0,
    tireNoise: 0,
    roughness: 0,
    wheels,
    driftBlend: 0,
    driftPhase: 'grip',
    driftDirection: 0,
    coasting: false,
    cueSpeed: 0,
    cueScale: 1,
    bodyRoll: 0,
    bodyPitch: 0,
    wheelTurn: 0,
  };

  let lastImpact = 0;
  let gear = 1;
  let shiftT = 0;
  let holdT = 0;
  let linkT = 0;
  let lastSign = 0;

  function pushEvent(kind: DriftPopupEvent['kind'], label: string, accent: DriftPopupEvent['accent'], cd = 4.2) {
    if (isolated) return;
    if (simTime - cooldowns[kind] < cd) return;
    cooldowns[kind] = simTime;
    rmxLive.events.push({ id: nextEventId++, kind, label, accent, time: performance.now() });
    if (rmxLive.events.length > 6) rmxLive.events.shift();
  }

  function resetDetector() {
    det.isDrifting = false;
    det.driftDuration = 0;
    det.driftSign = 0;
    det.signChanges = 0;
    det.lastSignChangeTime = -99;
    det.handbrakeUsed = false;
    det.hadFeint = false;
    det.lastSteerSign = 0;
    det.lastSteerFlipTime = -99;
    det.prevHeading = sim.heading;
    det.spinAccum = 0;
    det.spinWindowStart = simTime;
    det.spinReady = false;
    det.spinReadyTime = -99;
    det.donutAccum = 0;
    det.donutDir = 0;
    det.graceTimer = 0;
  }

  function refresh() {
    const fx = Math.sin(state.yaw);
    const fz = Math.cos(state.yaw);
    const rx = Math.cos(state.yaw);
    const rz = -Math.sin(state.yaw);

    state.speed = Math.hypot(state.vx, state.vz);
    state.forwardSpeed = state.vx * fx + state.vz * fz;
    state.lateralSpeed = state.vx * rx + state.vz * rz;
    state.beta = state.speed > 1.8 ? Math.atan2(state.lateralSpeed, Math.max(0.5, Math.abs(state.forwardSpeed))) : 0;
    state.cueSpeed = state.speed;

    // Keep sync if external code moves state
    sim.x = state.x;
    sim.z = state.z;
    sim.vx = state.vx;
    sim.vz = state.vz;
    sim.heading = state.yaw;
    sim.angularVel = state.yawRate;

    // Exact world positions of all 4 Rally Group B Lab wheels (for tire marks + puff smoke!)
    for (const w of list) {
      const lx = w.side * HALF_TRACK;
      const lz = w.front ? FRONT_Z : REAR_Z;
      w.x = state.x + lx * rx + lz * fx;
      w.z = state.z + lx * rz + lz * fz;
    }
  }

  function reset(x = 0, z = 0, yaw = 0) {
    sim.x = x;
    sim.z = z;
    sim.vx = 0;
    sim.vz = 0;
    sim.heading = yaw;
    sim.angularVel = 0;
    sim.steerAngle = 0;
    sim.wheelSpin = 0;
    sim.roll = 0;
    sim.pitch = 0;
    sim.speed = 0;
    sim.vLong = 0;
    sim.vLat = 0;
    sim.slipAngle = 0;
    sim.slipAngleDeg = 0;
    sim.lateralIntensity = 0;
    sim.isHandbrake = false;
    sim.collidedRecently = 0;

    Object.assign(state, {
      x,
      z,
      yaw,
      vx: 0,
      vz: 0,
      yawRate: 0,
      speed: 0,
      forwardSpeed: 0,
      lateralSpeed: 0,
      beta: 0,
      steer: 0,
      steerAngle: 0,
      accelLong: 0,
      accelLat: 0,
      throttle: 0,
      brake: 0,
      rearLock: 0,
      rev: 0.16,
      gear: '1',
      shifting: false,
      handbrake: false,
      serviceBrake: false,
      rearSlip: 0,
      tireNoise: 0,
      roughness: 0,
      driftBlend: 0,
      driftPhase: 'grip',
      driftDirection: 0,
      coasting: false,
      cueSpeed: 0,
      cueScale: 1,
      bodyRoll: 0,
      bodyPitch: 0,
      wheelTurn: 0,
    });

    for (const w of list) {
      Object.assign(w, {
        angle: 0,
        omega: 0,
        spin: 0,
        along: 0,
        across: 0,
        slip: 0,
        load: (1220 * 9.81) / 4,
        roughness: 0,
        height: 0,
        worldY: 0,
      });
    }

    lastImpact = 0;
    gear = 1;
    shiftT = 0;
    holdT = 0;
    linkT = 0;
    lastSign = 0;
    resetDetector();

    if (!isolated) {
      rmxLive.speedKmh = 0;
      rmxLive.slipAngleDeg = 0;
      rmxLive.isDrifting = false;
      rmxLive.isHandbrake = false;
      rmxLive.isManji = false;
      rmxLive.manjiChanges = 0;
      rmxLive.spinReady = false;
      rmxLive.steerAngle = 0;
      rmxLive.throttle = 0;
      rmxLive.brake = 0;
      rmxLive.vLong = 0;
      rmxLive.vLat = 0;
      rmxLive.lateralIntensity = 0;
      rmxLive.cueText = '';
      rmxLive.events.length = 0;
    }

    refresh();
  }

  // Oriented box probe points for the footprint (2.02 m × 4.24 m, incl. bumpers) instead of the old 1.15 m circle.
  const PROBE_HALF_W = 1.01, PROBE_HALF_L = 2.12;
  const PROBES: ReadonlyArray<readonly [number, number]> = [
    [PROBE_HALF_W, PROBE_HALF_L], [PROBE_HALF_W, 0], [PROBE_HALF_W, -PROBE_HALF_L], [0, PROBE_HALF_L],
    [0, -PROBE_HALF_L], [-PROBE_HALF_W, PROBE_HALF_L], [-PROBE_HALF_W, 0], [-PROBE_HALF_W, -PROBE_HALF_L],
  ];
  function handleBarrierCollision(): number {
    if (!barrier) return 0;
    const fwX = Math.sin(sim.heading), fwZ = Math.cos(sim.heading);
    const sdX = Math.cos(sim.heading), sdZ = -Math.sin(sim.heading);
    // Test each probe against the barrier line and push out by the WORST penetration. The old circle
    // let the nose/tail sink deep into the rail and drained speed every frame — the "macet" grind.
    let maxPen = 0, hitNx = 0, hitNz = 0;
    for (const [a, b] of PROBES) {
      const px = sim.x + sdX * a + fwX * b, pz = sim.z + sdZ * a + fwZ * b;
      const q = barrier.laneAt(px, pz);
      const pen = Math.abs(q.off) - barrier.halfWidth;
      if (pen > maxPen) {
        const side = q.off > 0 ? 1 : -1;
        maxPen = pen;
        hitNx = -q.nx * side;
        hitNz = -q.nz * side;
      }
    }
    if (maxPen <= 0) return 0;
    const nx = hitNx, nz = hitNz;
    sim.x += nx * maxPen;
    sim.z += nz * maxPen;

    // Kill ONLY the component pointing into the wall (+ a little bounce on hard hits). Tangential drive is
    // preserved, so a car that slides wide grinds down the guardrail instead of anchoring to it.
    const vn = sim.vx * nx + sim.vz * nz;
    if (vn < 0) {
      const approach = -vn;
      const e = approach > DRIFT_SIM.WALL_CRASH_SPEED ? DRIFT_SIM.WALL_RESTITUTION_CRASH : DRIFT_SIM.WALL_RESTITUTION_SCRAPE;
      sim.vx -= (1 + e) * vn * nx;
      sim.vz -= (1 + e) * vn * nz;
      if (approach > DRIFT_SIM.WALL_CRASH_SPEED) { sim.vx *= 0.9; sim.vz *= 0.9; } // one-time scrub on heavy impacts
      sim.angularVel *= 0.85; // keep yaw authority so the nose can rotate out of the corner
      if (approach > DRIFT_SIM.CRASH_IMPACT_SPEED) {
        sim.collidedRecently = 1.2;
      }
      return approach;
    }
    return 0;
  }

  function updateManeuvers(dt: number, targetSteer: number, handbrake: boolean) {
    const absDeg = Math.abs(sim.slipAngleDeg);
    const speed = sim.speed;
    const driftingNow = speed > 6.5 && absDeg > 14 && sim.collidedRecently <= 0;

    // Track crisp steer reversal for Feint (Scandinavian Flick)
    const steerSign = targetSteer > 0.35 ? 1 : targetSteer < -0.35 ? -1 : 0;
    if (steerSign !== 0 && det.lastSteerSign !== 0 && steerSign !== det.lastSteerSign) {
      if (simTime - det.lastSteerFlipTime < 1.1 && !det.isDrifting && speed > 10) {
        det.hadFeint = true;
      }
      det.lastSteerFlipTime = simTime;
    } else if (steerSign !== 0 && det.lastSteerSign === 0) {
      det.lastSteerFlipTime = simTime;
    }
    if (steerSign !== 0) det.lastSteerSign = steerSign;

    // Track heading rotation for 360° Spin & Donut
    const dHeading = Math.atan2(Math.sin(sim.heading - det.prevHeading), Math.cos(sim.heading - det.prevHeading));
    det.prevHeading = sim.heading;

    if (Math.abs(sim.angularVel) > 1.35 && speed > 4.2 && sim.collidedRecently <= 0) {
      if (Math.abs(det.spinAccum) < 0.05) det.spinWindowStart = simTime;
      det.spinAccum += dHeading;
      if (Math.abs(det.spinAccum) >= Math.PI * 1.78 && simTime - det.spinWindowStart < 4.5) {
        det.spinReady = true;
        det.spinReadyTime = simTime;
        det.spinAccum = 0;
        if (speed < 16 && handbrake) {
          pushEvent('donut', 'DONUT DRIFT 360°!', 'amber', 5.0);
          det.spinReady = false;
        }
      }
    } else {
      det.spinAccum *= Math.exp(-3.5 * dt);
    }

    if (det.spinReady && simTime - det.spinReadyTime > 2.6) {
      det.spinReady = false;
    }

    // Drift session tracking
    if (driftingNow) {
      const sign = sim.slipAngleDeg >= 0 ? 1 : -1;
      if (!det.isDrifting) {
        det.isDrifting = true;
        det.driftDuration = 0;
        det.driftSign = sign;
        det.signChanges = 0;
        det.handbrakeUsed = handbrake;
      } else {
        det.driftDuration += dt;
        if (handbrake) det.handbrakeUsed = true;
        if (sign !== det.driftSign && absDeg > 16) {
          if (simTime - det.lastSignChangeTime < 3.0 || det.driftDuration > 0.35) {
            det.signChanges++;
            det.lastSignChangeTime = simTime;
            if (det.signChanges >= 2) {
              pushEvent('manji', 'MANJI DRIFT CHAIN!', 'violet', 4.5);
            }
          }
          det.driftSign = sign;
        }
      }
      det.graceTimer = 0;

      // Catch from a 360° spin!
      if (det.spinReady && det.driftDuration > 0.25 && speed > 8) {
        pushEvent('spin360', '360° REVERSE ENTRY!', 'rose', 5.5);
        det.spinReady = false;
      } else if (det.hadFeint && det.driftDuration > 0.55) {
        pushEvent('feint', 'FEINT FLICK DRIFT!', 'emerald', 5.0);
        det.hadFeint = false;
      } else if (det.handbrakeUsed && det.driftDuration > 0.65 && absDeg > 22) {
        pushEvent('ebrake', 'E-BRAKE DRIFT!', 'amber', 5.2);
      } else if (!det.handbrakeUsed && det.driftDuration > 1.05 && speed > 13 && absDeg > 20) {
        pushEvent('power_over', 'POWER OVER DRIFT!', 'cyan', 5.8);
      }
    } else if (det.isDrifting) {
      det.graceTimer += dt;
      if (det.graceTimer > 0.55 || sim.collidedRecently > 0.8) {
        det.isDrifting = false;
        det.driftDuration = 0;
        det.signChanges = 0;
        det.handbrakeUsed = false;
        det.hadFeint = false;
        det.graceTimer = 0;
      }
    }

    // Live subtle cue line
    let cueText = '';
    if (det.spinReady) cueText = '360° TERCAPAI — TAHAN DRIFT!';
    else if (det.signChanges === 1 && simTime - det.lastSignChangeTime < 2.6) cueText = 'MANJI x1 — BANTING BALIK!';
    else if (det.signChanges >= 2 && det.isDrifting) cueText = `MANJI CHAIN x${det.signChanges}`;
    rmxLive.cueText = cueText;
  }

  function step(dt: number, input: DriverInput) {
    simTime += dt;

    // -----------------------------------------------------------------------
    // 1. EXACT INPUTS (100% verbatim from 3d-car-drift-simulator (2).zip)
    // -----------------------------------------------------------------------
    const throttle = clamp(Number(input.gas) || 0, 0, 1);
    const brake = clamp(Number(input.brake) || 0, 0, 1);
    const targetSteer = clamp(Number(input.steer) || 0, -1, 1); // +1 = left (A), -1 = right (D)
    const handbrake = !!input.handbrake;
    sim.isHandbrake = handbrake;

    // Forward (+heading) and lateral unit vectors in XZ plane
    // heading = 0 => +Z; heading = PI/2 => +X (left-hand perpendicular is +X = car left)
    const fx = Math.sin(sim.heading);
    const fz = Math.cos(sim.heading);
    const rx = Math.cos(sim.heading);
    const rz = -Math.sin(sim.heading);

    // Decompose world velocity into car's local forward & lateral speeds
    const vLong = sim.vx * fx + sim.vz * fz;
    const vLat = sim.vx * rx + sim.vz * rz;
    const speed = Math.hypot(sim.vx, sim.vz);

    sim.speed = speed;
    sim.vLong = vLong;
    sim.vLat = vLat;

    // Smooth steering input: +1 = left (+heading), -1 = right (-heading)
    // Speed-sensitive lock: full lock stays available through the midrange, blended down progressively at top end.
    const speedTaper = speed > 24 ? 1 - Math.min(0.34, (speed - 24) * 0.0115) : 1;
    const steerGoal = targetSteer * speedTaper;
    const steerSpeed = targetSteer !== 0 ? DRIFT_SIM.STEER_SPEED_ON : DRIFT_SIM.STEER_SPEED_OFF;
    sim.steerAngle += (steerGoal - sim.steerAngle) * Math.min(1, steerSpeed * dt);

    // Slip angle between heading and velocity vector (in radians & degrees)
    let slipAngle = 0;
    if (speed > 1.8) {
      slipAngle = Math.atan2(vLat, Math.max(0.5, Math.abs(vLong)));
    }
    sim.slipAngle = slipAngle;
    sim.slipAngleDeg = slipAngle * RAD2DEG;

    // -----------------------------------------------------------------------
    // 2. LONGITUDINAL ACCELERATION & BRAKING (100% verbatim!)
    // -----------------------------------------------------------------------
    let longAccel = 0;
    if (throttle > 0) {
      // High-speed aerodynamic taper so top speed ~ 165 km/h (46 m/s)
      const speedRatio = Math.min(1, Math.max(0, vLong) / DRIFT_SIM.SPEED_TAPER_REF);
      longAccel += DRIFT_SIM.MAX_ENGINE_FORCE * (1 - DRIFT_SIM.SPEED_TAPER_FACTOR * speedRatio) * throttle;
    }
    if (brake > 0) {
      if (vLong > 1.5) {
        longAccel -= DRIFT_SIM.BRAKE_FORCE * brake;
      } else {
        longAccel -= DRIFT_SIM.REVERSE_FORCE * brake;
      }
    }

    // Handbrake slows forward speed slightly while killing rear lateral grip
    if (handbrake && speed > 1.0) {
      longAccel -= Math.sign(vLong) * DRIFT_SIM.HANDBRAKE_DRAG;
    }

    // Rolling resistance + aero drag
    const drag = DRIFT_SIM.AERO_DRAG * speed * speed + DRIFT_SIM.ROLL_DRAG * Math.abs(vLong);
    longAccel -= Math.sign(vLong) * drag * DRIFT_SIM.DRAG_SCALE;

    // -----------------------------------------------------------------------
    // 3. LATERAL GRIP & OVERSTEER MODEL (100% verbatim!)
    // -----------------------------------------------------------------------
    // SCANDINAVIAN FLICK / FEINT: a hard full-lock reversal at speed snaps the rear out.
    // Detect the pattern (both signs, >0.55 lock, 0.55 s window, 0.9 s cooldown) and kick yaw into the new lock.
    if (feintMode) {
      const feintSign = Math.sign(targetSteer);
      if (feintSign !== 0 && feintSign !== lastFeintSign && Math.abs(targetSteer) > 0.55 && speed > 12) {
        if (simTime - lastFeintFlip < 0.55 && simTime - feintKickTime > 0.9) {
          feintKickTime = simTime;
          feintGripCut = 0.78;
          sim.angularVel += feintSign * (1.35 + Math.min(1, speed / 46) * 1.0);
        }
        lastFeintSign = feintSign;
        lastFeintFlip = simTime;
      }
    }
    if (feintGripCut > 0) feintGripCut = Math.max(0, feintGripCut - dt);
    const feintCut = feintGripCut > 0;
    const absSlip = Math.abs(slipAngle);
    let lateralGrip: number = handbrake
      ? DRIFT_SIM.GRIP_HANDBRAKE
      : absSlip > DRIFT_SIM.SLIP_SOFTEN_RAD
        ? DRIFT_SIM.GRIP_SLIDE
        : DRIFT_SIM.GRIP_STRAIGHT;
    if (feintCut) lateralGrip *= 0.42;
    // Hidden stability control: cornering gently (small slip, no handbrake/flick) gets a firm, flat, grippy
    // response — like a real stability system. Demand more angle (slip grows past the window) and it steps
    // aside so slides happen exactly when the driver asks for them.
    // …stepping aside progressively when the driver demands a slide: full throttle + big lock = power-over.
    const demand = Math.min(1, Math.max(0, (Math.abs(sim.steerAngle) - 0.45) / 0.4) + Math.max(0, (throttle - 0.55) / 0.45));
    const stability = (feintCut || handbrake) ? 0 : Math.max(0, 1 - absSlip / 0.30) * (1 - demand);
    lateralGrip += 2.4 * stability;

    // Power-oversteer, scaled by slide amount: full grip when cornering cleanly, so a straight-into-corner
    // car doesn't kick out. Grip only gives way once the rear is already sliding (that's what power-over IS).
    const slideFactor = clamp((absSlip - 0.15) / 0.45, 0, 1);
    if (throttle > 0 && Math.abs(sim.steerAngle) > 0.3 && speed > 9 && slideFactor > 0) {
      lateralGrip *= 1 - (1 - DRIFT_SIM.POWER_OVER_MULT) * slideFactor;
    }

    // Lateral tire friction opposing vLat (soft saturation so car glides silkily!)
    const lateralForce =
      -Math.tanh(vLat * DRIFT_SIM.TANH_LAT_GAIN) * lateralGrip * DRIFT_SIM.LAT_FORCE_SCALE -
      vLat * (handbrake ? DRIFT_SIM.LAT_DAMP_HANDBRAKE : DRIFT_SIM.LAT_DAMP_NORMAL);

    // Convert local accelerations back to world X/Z
    const ax = fx * longAccel + rx * lateralForce;
    const az = fz * longAccel + rz * lateralForce;

    sim.vx += ax * dt;
    sim.vz += az * dt;

    // Clamp near-zero jitter when stationary
    if (throttle <= 0 && brake <= 0 && Math.hypot(sim.vx, sim.vz) < 0.25) {
      sim.vx = 0;
      sim.vz = 0;
    }

    // -----------------------------------------------------------------------
    // 4. YAW / STEERING TORQUE + COUNTER-STEER ASSIST + ANGULAR DAMPING (100% verbatim!)
    // -----------------------------------------------------------------------
    const steerFactor = Math.min(1, speed / DRIFT_SIM.STEER_FACTOR_SPEED);
    const directionSign = vLong >= -0.5 ? 1 : -1;

    const yawStrength = handbrake ? DRIFT_SIM.YAW_HANDBRAKE : DRIFT_SIM.YAW_NORMAL;
    let yawTorque = sim.steerAngle * yawStrength * steerFactor * directionSign;

    // Counter-Steer Assist & Drift Stabilization:
    // Gently pulls nose toward velocity vector to hold a clean drift angle without spinning out.
    // Holding Space (handbrake) + full steer allows intentional 360° spins or tight donuts!
    const intentionalHardSpin = handbrake && Math.abs(sim.steerAngle) > DRIFT_SIM.HARD_SPIN_STEER;
    const counterAssist = feintMode ? DRIFT_SIM.COUNTER_ASSIST * 1.32 : DRIFT_SIM.COUNTER_ASSIST;
    const counterMinSlip = feintMode ? DRIFT_SIM.COUNTER_MIN_SLIP * 0.7 : DRIFT_SIM.COUNTER_MIN_SLIP;
    if (speed > DRIFT_SIM.COUNTER_MIN_SPEED && absSlip > counterMinSlip && !intentionalHardSpin) {
      const autoCounter = Math.sin(slipAngle) * counterAssist;
      yawTorque += autoCounter;
    }

    // Angular damping keeps transitions silky smooth and completely catchable
    const angularDamping = handbrake
      ? DRIFT_SIM.ANG_DAMP_HANDBRAKE
      : feintCut
        ? DRIFT_SIM.ANG_DAMP_HANDBRAKE * 0.875
        : DRIFT_SIM.ANG_DAMP_NORMAL + 1.8 * stability;
    sim.angularVel += (yawTorque - sim.angularVel * angularDamping) * dt;
    sim.heading += sim.angularVel * dt;

    // Integrate world position
    sim.x += sim.vx * dt;
    sim.z += sim.vz * dt;

    // Exact wall / track-barrier collision (1.35 recoil, 0.72 speed retention)
    lastImpact = handleBarrierCollision();

    if (sim.collidedRecently > 0) sim.collidedRecently = Math.max(0, sim.collidedRecently - dt);

    // -----------------------------------------------------------------------
    // 5. EXACT BODY ROLL / PITCH, FRONT STEER & WHEEL SPIN (from drift sim!)
    // -----------------------------------------------------------------------
    const targetRoll = clamp(-vLat * 0.012 + sim.angularVel * 0.035, -0.11, 0.11);
    const targetPitch = clamp(throttle * -0.025 + brake * 0.035, -0.05, 0.05);
    sim.roll += (targetRoll - sim.roll) * Math.min(1, 10 * dt);
    sim.pitch += (targetPitch - sim.pitch) * Math.min(1, 10 * dt);

    const visualSteer = sim.steerAngle * DRIFT_SIM.VISUAL_STEER_MAX;
    const wheelOmega = vLong / DRIFT_SIM.WHEEL_RADIUS;
    sim.wheelSpin = (sim.wheelSpin + wheelOmega * dt) % TAU;

    // Exact lateral slide intensity from 3d-car-drift-simulator (2).zip (feeds PRODRIFT smoke + skids!)
    const lateralIntensity = clamp(
      (Math.abs(vLat) - 2.2) / 14 + (handbrake && speed > 4 ? 0.55 : 0),
      0,
      1,
    );
    sim.lateralIntensity = lateralIntensity;
    const sliding = lateralIntensity > 0.12 && speed > 3.5;

    // -----------------------------------------------------------------------
    // 6. SYNC INTO RALLY GROUP B LAB STATE (car body, wheels, smoke, cockpit, audio!)
    // -----------------------------------------------------------------------
    state.x = sim.x;
    state.z = sim.z;
    state.yaw = sim.heading;
    state.vx = sim.vx;
    state.vz = sim.vz;
    state.yawRate = sim.angularVel;

    const newFx = Math.sin(sim.heading);
    const newFz = Math.cos(sim.heading);
    const newRx = Math.cos(sim.heading);
    const newRz = -Math.sin(sim.heading);
    const newSpeed = Math.hypot(sim.vx, sim.vz);
    const newVLong = sim.vx * newFx + sim.vz * newFz;
    const newVLat = sim.vx * newRx + sim.vz * newRz;

    state.speed = newSpeed;
    state.forwardSpeed = newVLong;
    state.lateralSpeed = newVLat;
    state.beta = newSpeed > 1.8 ? Math.atan2(newVLat, Math.max(0.5, Math.abs(newVLong))) : 0;
    state.cueSpeed = newSpeed;
    state.cueScale = 1;
    state.rcSpeed = undefined;

    // Steering, chassis lean & driver arms
    state.steer = sim.steerAngle;
    state.steerAngle = visualSteer;
    state.bodyRoll = sim.roll;
    state.bodyPitch = sim.pitch;
    state.wheelTurn = sim.steerAngle;
    state.accelLong = longAccel;
    state.accelLat = lateralForce;

    // Controls, brake lights (bright red on brake OR handbrake!), handbrake pull
    state.throttle = throttle;
    state.brake = brake > 0.05 ? brake : handbrake ? 0.65 : 0;
    state.serviceBrake = brake > 0.05 || handbrake;
    state.handbrake = handbrake;
    state.rearLock = handbrake ? 1 : 0;
    state.coasting = throttle < 0.02 && brake < 0.02 && !handbrake && newSpeed > 2.5;

    // Sync all 4 Rally Group B Lab wheels (exact steering, rolling, surface height & Rally smoke/skids!)
    const rearSlipVal = sliding ? clamp(0.32 + lateralIntensity * 0.68, 0, 1) : 0;
    const frontSlipVal = sliding && lateralIntensity > 0.42 ? clamp((lateralIntensity - 0.32) * 0.62, 0, 0.72) : 0;
    let rough = 0;
    for (let i = 0; i < 4; i++) {
      const w = list[i];
      const lx = w.side * HALF_TRACK;
      const lz = w.front ? FRONT_Z : REAR_Z;
      w.x = state.x + lx * newRx + lz * newFx;
      w.z = state.z + lx * newRz + lz * newFz;
      const surf = surfaceAt(w.x, w.z);
      w.roughness = surf.roughness;
      w.height = surf.height;
      w.worldY = surf.worldY ?? surf.height;
      rough += surf.roughness * 0.25;

      w.angle = w.front ? visualSteer : 0;
      w.omega = wheelOmega;
      w.spin = sim.wheelSpin;
      w.along = newVLong;
      w.across = newVLat;
      w.slip = w.front ? frontSlipVal : rearSlipVal;
      w.load = (1220 * 9.81) / 4;
    }
    state.roughness = rough;
    state.rearSlip = rearSlipVal;
    state.tireNoise = sliding ? lateralIntensity : 0;

    // Cosmetic 5-speed automatic rally gearbox (dash gauge, driver hand shift, engine audio!)
    const reversing = newVLong < -0.5;
    shiftT = Math.max(0, shiftT - dt);
    const inDrift = Math.abs(state.beta) > 0.18 || handbrake || Math.abs(sim.angularVel) > 1.25;
    holdT = inDrift ? 0.85 : Math.max(0, holdT - dt);
    if (reversing) {
      gear = 1;
    } else if (shiftT === 0 && holdT === 0) {
      const prev = gear;
      if (gear < 5 && newSpeed >= UPSHIFT[gear]) gear++;
      else if (gear > 1 && newSpeed < DOWNSHIFT[gear]) gear--;
      if (gear !== prev) shiftT = 0.34;
    }
    state.gear = reversing ? 'R' : String(gear);
    state.shifting = !handbrake && shiftT > 0.22;

    const gearLo = reversing ? 0 : DOWNSHIFT[gear] * 0.55;
    const gearHi = reversing ? 14 : gear === 5 ? 48 : UPSHIFT[gear];
    const ratio = clamp((Math.abs(newSpeed) - gearLo) / Math.max(4, gearHi - gearLo), 0, 1);
    const revGoal = clamp(
      0.16 + ratio * 0.64 + throttle * 0.14 + (sliding ? lateralIntensity * 0.14 : 0) - (state.shifting ? 0.18 : 0),
      0.14,
      0.99,
    );
    state.rev = damp(state.rev, revGoal, state.shifting ? 14 : 8, dt);

    // Drift blend & phase (for Rally Group B Lab smoke thickening, HUD & transition link detection)
    const ab = Math.abs(state.beta);
    const activeSlide = (newSpeed > 4.5 && ab > 0.2) || (handbrake && newSpeed > 4.0);
    const blendTarget = activeSlide ? clamp((ab - 0.14) / 0.55 + (handbrake ? 0.35 : 0), 0, 1) : 0;
    state.driftBlend = damp(state.driftBlend, blendTarget, activeSlide ? 10 : 6, dt);
    const sign = ab > 0.18 && newSpeed > 4.5 ? (state.beta >= 0 ? 1 : -1) : 0;
    if (sign !== 0 && lastSign !== 0 && sign !== lastSign) linkT = 0.52;
    else linkT = Math.max(0, linkT - dt);
    if (sign !== 0) lastSign = sign;
    else if (newSpeed < 3.5) lastSign = 0;

    state.driftDirection = sign;
    state.driftPhase =
      linkT > 0 && state.driftBlend > 0.15
        ? 'link'
        : handbrake && newSpeed > 4 && ab < 0.32
          ? 'entry'
          : activeSlide
            ? 'slide'
            : state.driftBlend > 0.14
              ? 'exit'
              : 'grip';

    // Publish live telemetry & detect tricks for player (never for ghost AI)
    if (!isolated) {
      updateManeuvers(dt, targetSteer, handbrake);
      rmxLive.active = true;
      rmxLive.speedKmh = Math.round(newSpeed * 3.6);
      rmxLive.slipAngleDeg = state.beta * RAD2DEG;
      rmxLive.isDrifting = det.isDrifting;
      rmxLive.isHandbrake = handbrake;
      rmxLive.isManji = det.signChanges > 0 && det.isDrifting;
      rmxLive.manjiChanges = det.signChanges;
      rmxLive.spinReady = det.spinReady;
      rmxLive.steerAngle = sim.steerAngle;
      rmxLive.throttle = throttle;
      rmxLive.brake = brake;
      rmxLive.vLong = newVLong;
      rmxLive.vLat = newVLat;
      rmxLive.lateralIntensity = lateralIntensity;
    }
  }

  reset();

  return {
    state,
    step,
    reset,
    refresh,
    /** Arm / disarm the Scandinavian Flick feint mode (Rally Group B Lab, M key). */
    setFeintMode(enabled: boolean) { feintMode = Boolean(enabled); if (!feintMode) feintGripCut = 0; },
    get feintMode() { return feintMode; },
    get lastImpact() {
      return lastImpact;
    },
    get collidedRecently() {
      return sim.collidedRecently;
    },
  };
}
