// Qualifying line selected for lap time, scored outside-zone distance and clean exits.
// Gates are course stations; the entries that follow are inputs to the shared tyre model.
export const ghostPlan = [
  // Opening linked corners
  { seconds: 2.8678, steer: 0.0349, gas: 1 },
  { seconds: 0.2757, steer: -0.673, gas: 0.6428, handbrake: true },
  { seconds: 0.2963, steer: -0.5657, gas: 0.9857 },
  { seconds: 1.4933, steer: -0.1254, gas: 0.9172 },
  { seconds: 1.0939, steer: 0.5811, gas: 0.9365 },
  { seconds: 0.8174, steer: -0.0971, gas: 0.7291 },
  { seconds: 0.2299, steer: -0.2613, gas: 0.07 },
  { seconds: 0.2987, steer: 0.0081, gas: 0.1032 },

  // Sector gate near 166 metres
  { until: 165.545, offset: 2.13777917, width: 31.39764837, pace: 23.61522468, entry: 18.89020667 },
  { seconds: 0.3543, steer: -0.9915, gas: 0.8956 },
  { seconds: 0.5488, steer: -0.9751, gas: 0.7527 },
  { seconds: 0.4045, steer: 0.0923, gas: 0.9527 },
  { seconds: 0.3499, steer: 0.9645, gas: 0.0996 },
  { seconds: 0.237, steer: -0.0281, gas: 0.0774 },

  // Sector gate near 239 metres
  { until: 238.911, offset: -2.45811881, width: 22.16683303, pace: 27.49160614, entry: 23.44813443 },
  { seconds: 0.36, steer: 0.6776, gas: 1 },
  { seconds: 0.4974, steer: 0.48034046, gas: 0.9369 },
  { seconds: 1.6943, steer: 0.1836, gas: 0.9942 },
  { seconds: 0.1691, steer: -0.3649, gas: 0.0817 },
  { seconds: 0.0651, steer: 0.0414, gas: 0.15348376 },

  // Sector gate near 306 metres
  { until: 306.271, offset: -2.55605471, width: 42.90162262, pace: 24.73081452, entry: 22.42317555 },
  { seconds: 0.3481, steer: 0.9727, gas: 0.9743, brake: 0.479 },
  { seconds: 0.5279, steer: 0.9252, gas: 0.9245 },
  { seconds: 0.4684, steer: 0.1377, gas: 0.5771 },
  { seconds: 0.2233, steer: -0.5593, gas: 0.2861 },
  { seconds: 0.5617, steer: -0.0704, gas: 0.188 },

  // Sector gate near 378 metres
  { until: 378.482, offset: -4.72545212, width: 21.79313173, pace: 25.96022781, entry: 21.17785254 },
  { seconds: 0.1554, steer: 0.9593, gas: 0.8447, handbrake: true },
  { seconds: 0.3379, steer: 0.70195096, gas: 0.7216 },
  { seconds: 1.3956, steer: 0.0275, gas: 0.8023 },
  { seconds: 0.2935, steer: -0.6215, gas: 0.0078 },
  { seconds: 0.5107, steer: -0.15, gas: 0.0326 },

  // Sector gate near 448 metres
  { until: 447.505, offset: 2.18358204, width: 16.19472097, pace: 24.34833531, entry: 16.12679298 },
  { seconds: 0.3209, steer: -0.77777616, gas: 1, handbrake: true },
  { seconds: 0.4731, steer: -0.8237, gas: 0.9052 },
  { seconds: 1.1801, steer: -0.3482, gas: 0.8426 },
  { seconds: 0.2651, steer: 0.7875, gas: 0.0931 },
  { seconds: 0.3272, steer: -0.3038, gas: 0.13378887 },

  // Sector gate near 521 metres
  { until: 520.666, offset: -2.88574163, width: 42.21692408, pace: 28.46803898, entry: 21.7596471 },
  { seconds: 0.3094, steer: 0.6597, gas: 0.9113, brake: 0.4361 },
  { seconds: 0.5018, steer: 0.72583475, gas: 0.7658 },
  { seconds: 0.6672, steer: -0.0968, gas: 0.809 },
  { seconds: 0.3511, steer: -0.4704, gas: 0.3564 },
  { seconds: 0.5633, steer: 0.12449453, gas: 0.1718 },

  // Sector gate near 582 metres
  { until: 582.415, offset: -1.45998956, width: 33.9171313, pace: 24.96658669, entry: 23.43272043 },
  { seconds: 0.1615, steer: 0.77297222, gas: 0.8455, handbrake: true },
  { seconds: 0.491, steer: 0.8868, gas: 0.7341 },
  { seconds: 0.3285, steer: 0.44591371, gas: 0.86074799 },
  { seconds: 0.1646, steer: -0.46498985, gas: 0.34340334 },
  { seconds: 0.357, steer: 0.42605833, gas: 0.1916 },

  // Sector gate near 613 metres
  { until: 613.147, offset: -2.22069967, width: 12, pace: 28.06384711, entry: 19.53530981 },
  { seconds: 0.2094, steer: 0.88185007, gas: 0.9229 },
  { seconds: 0.4241, steer: 0.84384035, gas: 0.8333 },
  { seconds: 1.7843, steer: 0.018, gas: 1 },
  { seconds: 0.3349, steer: -0.6625142, gas: 0.41938759 },
  { seconds: 0.5266, steer: 0.19863611, gas: 0.23222415 },
];
