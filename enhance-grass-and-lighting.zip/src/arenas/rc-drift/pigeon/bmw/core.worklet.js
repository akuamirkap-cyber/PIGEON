/*
 * M ACOUSTIC CORE — sintesis prosedural + fisika kendaraan, tanpa sampel audio.
 * File ini dimuat mentah (?raw) lalu dijalankan di AudioWorklet (atau ScriptProcessor sebagai cadangan).
 * Jangan gunakan import/export di sini.
 */
const TAU = 6.283185307179586;
const RW = 0.335; // radius roda (m)
const MU = 1.15; // koefisien grip ban
const CLUTCH_T = 1150; // kapasitas torsi kopling (Nm)
const EXH_GAIN = 0.8;
const RASP_GAIN = 0.48;
const SQ_GAIN = 0.95;
const POP_GAIN = 1.25;

function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
function sstep(x) { x = x < 0 ? 0 : x > 1 ? 1 : x; return x * x * (3 - 2 * x); }
function lerp(a, b, t) { return a + (b - a) * t; }
function ftanh(x) { if (x > 3) return 1; if (x < -3) return -1; const x2 = x * x; return x * (27 + x2) / (27 + 9 * x2); }

/* State-variable filter (TPT) — stabil saat dimodulasi */
class SVF {
  constructor() { this.ic1 = 0; this.ic2 = 0; this.k = 1; this.a1 = 0; this.a2 = 0; this.a3 = 0; }
  set(f, q, sr) {
    const g = Math.tan(Math.PI * clamp(f, 10, sr * 0.45) / sr);
    this.k = 1 / q;
    this.a1 = 1 / (1 + g * (g + this.k));
    this.a2 = g * this.a1;
    this.a3 = g * this.a2;
    return this;
  }
  lpf(x) {
    const v3 = x - this.ic2;
    const v1 = this.a1 * this.ic1 + this.a2 * v3;
    const v2 = this.ic2 + this.a2 * this.ic1 + this.a3 * v3;
    this.ic1 = 2 * v1 - this.ic1; this.ic2 = 2 * v2 - this.ic2;
    return v2;
  }
  bpf(x) { // puncak ternormalisasi = 1
    const v3 = x - this.ic2;
    const v1 = this.a1 * this.ic1 + this.a2 * v3;
    const v2 = this.ic2 + this.a2 * this.ic1 + this.a3 * v3;
    this.ic1 = 2 * v1 - this.ic1; this.ic2 = 2 * v2 - this.ic2;
    return v1 * this.k;
  }
  hpf(x) {
    const v3 = x - this.ic2;
    const v1 = this.a1 * this.ic1 + this.a2 * v3;
    const v2 = this.ic2 + this.a2 * this.ic1 + this.a3 * v3;
    this.ic1 = 2 * v1 - this.ic1; this.ic2 = 2 * v2 - this.ic2;
    return x - this.k * v1 - v2;
  }
}

/* Pipa knalpot: comb feedback dengan redaman di dalam loop (waveguide sederhana) */
class Comb {
  constructor() { this.buf = new Float32Array(4096); this.i = 0; this.len = 512; this.fb = 0; this.lp = 0; this.damp = 0.4; }
  setup(len, fb, damp) { this.len = clamp(Math.round(len), 2, 4095); this.fb = fb; this.damp = damp; if (this.i >= this.len) this.i = 0; }
  tick(x) {
    this.lp += (this.buf[this.i] - this.lp) * this.damp;
    const y = x + this.fb * this.lp + 1e-18;
    this.buf[this.i] = y;
    if (++this.i >= this.len) this.i = 0;
    return y;
  }
}

/* Allpass Schroeder — menyebar pulsa di dalam muffler (difusi) */
class Allpass {
  constructor() { this.buf = new Float32Array(512); this.i = 0; this.len = 60; this.g = 0.45; }
  setup(len, g) { this.len = clamp(Math.round(len), 2, 511); this.g = g; if (this.i >= this.len) this.i = 0; }
  tick(x) {
    const d = this.buf[this.i];
    const y = d - this.g * x;
    this.buf[this.i] = x + this.g * y + 1e-18;
    if (++this.i >= this.len) this.i = 0;
    return y;
  }
}

const GEARBOX = {
  dct: { ratios: [0, 4.806, 2.593, 1.701, 1.277, 1.0, 0.844, 0.671], teeth: [0, 13, 19, 25, 29, 33, 36, 39] },
  mt: { ratios: [0, 4.11, 2.315, 1.542, 1.179, 1.0, 0.846], teeth: [0, 14, 21, 27, 31, 34, 37] },
};

const ENGINES = {
  // S55B30 — inline-6 3.0 twin-turbo (M3 F80 / M4 F82). Urutan pengapian 1-5-3-6-2-4
  s55: {
    cyl: 6, idle: 720, coldIdle: 1320, limiter: 7550, redline: 7600,
    tqMax: 550, pMax: 317000, boostMax: 1.25,
    tq: [[500, 0.4], [1000, 0.6], [1850, 1], [5500, 1], [6500, 0.9], [7300, 0.8], [7800, 0.7]],
    inertia: 0.27, mass: 1640, final: 3.462,
    slots: [0, 4, 2, 5, 1, 3],
    banks: [0, 0, 0, 1, 1, 1],
    cylGain: [1, 0.95, 1.04, 0.97, 1.03, 0.94],
    cylLag: [0, 0.005, -0.004, 0.003, -0.005, 0.004],
    cross: 0.36,
    voice: {
      combL: [0.0112, 0.0121], combS: [0.00295, 0.00327], fbL: -0.42, fbS: -0.36,
      chA: [0.0053, 0.0058], chB: [0.0079, 0.0085], ap: [0.0013, 0.0015],
      boom: 98, bark: 430, honk: 960, rasp: [2050, 3350, 2380, 3720], raspAmt: 1.0,
      tpIdle: 0.0048, tpHigh: 0.0043, jitter: 0.05, noise: 0.55,
      raspFrom: 2900, raspMid: 0.4, raspQ: 7, intakeGain: 1, bright: 1, popTune: 1,
      mech: [3, 6, 1.5], mechA: [1, 0.45, 0.3], intake: [330, 680],
    },
  },
  // S54B32HP — inline-6 3.2 NA, 8000 rpm, airbox karbon (E46 M3 CSL). Sumber "raspy metallic" yang paling ikonik.
  s54: {
    cyl: 6, idle: 880, coldIdle: 1400, limiter: 7900, redline: 7950, na: true,
    tqMax: 370, pMax: 265000, boostMax: 0,
    tq: [[500, 0.5], [1500, 0.72], [2500, 0.86], [4900, 1], [6500, 0.97], [7900, 0.86], [8300, 0.75]],
    inertia: 0.19, mass: 1385, final: 3.62,
    slots: [0, 4, 2, 5, 1, 3],
    banks: [0, 0, 0, 1, 1, 1],
    cylGain: [1, 0.93, 1.05, 0.96, 1.04, 0.92],
    cylLag: [0, 0.006, -0.005, 0.004, -0.006, 0.005],
    cross: 0.3,
    voice: {
      combL: [0.0098, 0.0107], combS: [0.0026, 0.0029], fbL: -0.4, fbS: -0.4,
      chA: [0.0046, 0.0051], chB: [0.0069, 0.0075], ap: [0.0011, 0.0013],
      boom: 112, bark: 520, honk: 1150, rasp: [2300, 3700, 2650, 4150], raspAmt: 1.5,
      tpIdle: 0.0042, tpHigh: 0.0036, jitter: 0.085, noise: 0.5,
      raspFrom: 2600, raspMid: 0.7, raspQ: 9, intakeGain: 2.0, bright: 1.3, popTune: 1.18,
      mech: [3, 6, 9], mechA: [1, 0.6, 0.35], intake: [420, 840],
    },
  },
  // S63B44TÜ — V8 4.4 twin-turbo hot-V (M5 F10). Urutan pengapian 1-5-4-8-6-3-7-2
  s63: {
    cyl: 8, idle: 650, coldIdle: 1180, limiter: 7150, redline: 7200,
    tqMax: 680, pMax: 412000, boostMax: 1.5,
    tq: [[500, 0.42], [1000, 0.66], [1500, 1], [5750, 1], [6400, 0.9], [7000, 0.8], [7400, 0.7]],
    inertia: 0.33, mass: 1945, final: 3.154,
    slots: [0, 7, 5, 2, 1, 4, 6, 3],
    banks: [0, 0, 0, 0, 1, 1, 1, 1],
    cylGain: [1, 0.88, 1.08, 0.93, 1.03, 0.89, 1.06, 0.95],
    cylLag: [0, 0.007, -0.006, 0.004, -0.007, 0.006, -0.003, 0.005],
    cross: 0.4,
    voice: {
      combL: [0.0141, 0.0153], combS: [0.0037, 0.0041], fbL: -0.46, fbS: -0.38,
      chA: [0.0067, 0.0073], chB: [0.0099, 0.0107], ap: [0.0017, 0.0019],
      boom: 76, bark: 340, honk: 780, rasp: [1650, 2700, 1880, 3050], raspAmt: 0.6,
      tpIdle: 0.0056, tpHigh: 0.0047, jitter: 0.08, noise: 0.6,
      raspFrom: 3600, raspMid: 0.12, raspQ: 5, intakeGain: 1, bright: 1, popTune: 0.8,
      mech: [4, 8, 2], mechA: [1, 0.4, 0.45], intake: [270, 560],
    },
  },
};

class BMWCore {
  constructor(sr) {
    this.sr = sr; this.isr = 1 / sr; this.k48 = 48000 / sr;
    this.seed = 987654321;
    this.post = null; this.postN = 0;
    this.cfg = { engine: 's55', trans: 'dct', auto: 1, mode: 2, dsc: 1, bumpy: 0, view: 0 };
    this.lg = new Float64Array(15).fill(1);
    this.master = 0.9;
    this.inp = { throttle: 0, brake: 0, steer: 0, handbrake: 0, kerb: 0, skid: 0 };

    // ---- state fisika
    this.estate = 0; this.et = 0; this.rpm = 0; this.rpmS = 0; this.cyc = 0;
    this.thrU = 0; this.brk = 0; this.steer = 0; this.thr = 0; this.thrHold = 0;
    this.load = 0; this.heat = 0; this.cold = 1; this.flare = 0; this.tn = 0;
    this.spool = 0; this.cut = false; this.cutT = 0; this.refT = 1;
    this.gear = 0; this.clutch = 0; this.locked = false; this.v = 0; this.vw = 0;
    this.spin = false; this.spinDir = 1; this.beta = 0; this.aLat = 0; this.aLong = 0;
    this.shift = null; this.shiftCool = 0; this.shiftCutT = 0; this.launch = false;
    this.tc = 0; this.Ti = 0; this.Fd = 0; this.slipR = 0; this.slipF = 0; this.slipV = 0; this.slipPk = 0;
    this.crankDur = 0.8; this.starterOn = 0; this.pumpOn = 0; this.resume = 0;
    this.burbleT = 0; this.burbleInt = 0; this.clu = 0.5; this.coolT = 0;
    this.sportHold = 0; this.bumpRear = -1; this.bumpAmp = 0; this.bumpN = 0; this.deny = 0; this.autoWait = 0;

    // ---- state audio
    this.amp = new Float64Array(8); this.px = new Float64Array(8); this.off = new Float64Array(8);
    this.bank = new Uint8Array(8);
    this.loadAmp = 0; this.motorAmp = 0; this.fuelA = false; this.jit = 0.05; this.popProb = 0;
    this.tickAmt = 0; this.tickEnv = 0; this.flap = 0; this.fireMask = 0;
    this.toneLP = [new SVF(), new SVF()]; this.combL = [new Comb(), new Comb()]; this.combS = [new Comb(), new Comb()];
    this.chA = [new Comb(), new Comb()]; this.chB = [new Comb(), new Comb()]; this.ap = [new Allpass(), new Allpass()];
    this.cabLP = [new SVF(), new SVF()]; this.pg = new Float64Array(12); this.pgInit = false; this.ic0 = 0; this.ic1 = 0;
    this.tfm = 0; this.wfm = 0; this.dist = 0;
    this.boom = [new SVF(), new SVF()]; this.bark = [new SVF(), new SVF()]; this.honk = [new SVF(), new SVF()];
    this.raspA = [new SVF(), new SVF()]; this.raspB = [new SVF(), new SVF()];
    this.flapLP = [new SVF(), new SVF()];
    this.dcx = [0, 0]; this.dcy = [0, 0]; this.bo = [0, 0];
    this.crackHP = new SVF().set(1100, 0.7, sr);
    this.inBP1 = new SVF(); this.inBP2 = new SVF(); this.inNz = new SVF(); this.inDc = 0;
    this.mechLP = new SVF().set(1400, 0.7, sr); this.tickBP = new SVF().set(5200, 2.2, sr);
    this.stBP = new SVF().set(1500, 1.3, sr); this.stPh = 0; this.stF = 0; this.stEnv = 0; this.pumpEnv = 0; this.pumpPh = 0;
    this.turboBP = new SVF(); this.rushBP = new SVF().set(2600, 0.6, sr); this.tPh1 = 0; this.tPh2 = 0;
    this.bovBP = new SVF(); this.bovHP = new SVF().set(4200, 0.7, sr); this.bovEnv = 0; this.bovDec = 0.999; this.bovT = 0; this.bovA = 0;
    this.wPh1 = 0; this.wPh2 = 0; this.wA = 0;
    this.rollL = new SVF(); this.rollR = new SVF(); this.rollB = new SVF().set(920, 1.1, sr); this.windBP = new SVF();
    this.kBP1 = new SVF().set(92, 3, sr); this.kBP2 = new SVF().set(560, 2.5, sr); this.kBP3 = new SVF().set(228, 6, sr); this.kPh = 0; this.kEnv = 0;
    this.sq = [];
    const sqF = [870, 985, 660], sqPan = [-0.75, 0.75, 0];
    this.sqHiss = new SVF().set(3600, 0.7, sr); this.brkBP = new SVF().set(2700, 0.8, sr);
    for (let i = 0; i < 3; i++) this.sq.push({ bp1: new SVF(), bp2: new SVF(), bp3: new SVF(), ch: 0, scr: new SVF().set(430 + i * 70, 0.75, sr), ph: 0, jv: 0, am: 0, drift: 0, env: 0, tgt: 0, f0: sqF[i], f: sqF[i], l: Math.cos((sqPan[i] + 1) * 0.7854), r: Math.sin((sqPan[i] + 1) * 0.7854) });
    this.pops = []; for (let i = 0; i < 10; i++) this.pops.push({ e1: 0, d1: 0.99, w: 0, ph: 0, eN: 0, dN: 0.99, eB: 0, dB: 0.99, lp: 0, l: 0.7, r: 0.7 });
    this.popI = 0; this.popOn = false; this.popTail = 0;
    this.pm = []; for (let i = 0; i < 8; i++) this.pm.push(new SVF());
    this.popCab = [new SVF().set(1900, 0.7, sr), new SVF().set(1900, 0.7, sr)];
    this.bGap = 0; this.bN = 0; this.bIpi = 0; this.bAmp = 0; this.bBig = false; this.gurg = 0; this.gurgK = 0;
    this.fartEnv = 0; this.fartDec = 0.999; this.fartPh = 0; this.fartF = 0; this.fartT = 0;
    this.hits = []; for (let i = 0; i < 36; i++) this.hits.push({ on: false, ph: 0, w: 0, env: 0, dec: 0, a: 0, nz: 0, c: 0, s: 0, gl: 1, l: 0.7, r: 0.7 });
    this.hitI = 0; this.hitsOn = false;
    // meter
    this.mPop = 0; this.mLim = 0; this.mFart = 0; this.mShift = 0; this.mThud = 0; this.mKerb = 0; this.mStart = 0;
    this.meters = new Float64Array(15);
    this.setEngine('s55');
  }

  rnd() { this.seed = (Math.imul(this.seed, 1664525) + 1013904223) | 0; return this.seed * 4.656612873077393e-10; }
  rnd01() { return this.rnd() * 0.5 + 0.5; }

  setEngine(key) {
    const E = ENGINES[key] || ENGINES.s55; this.E = E; this.cfg.engine = key;
    const V = E.voice, sr = this.sr;
    for (let c = 0; c < E.cyl; c++) {
      let o = 1 - E.slots[c] / E.cyl + E.cylLag[c]; o -= Math.floor(o);
      this.off[c] = o; this.bank[c] = E.banks[c]; this.amp[c] = 0;
      let x = this.cyc + o; if (x >= 1) x -= 1; this.px[c] = x;
    }
    for (let j = 0; j < 2; j++) {
      this.combL[j].setup(V.combL[j] * sr, V.fbL, 0.22 * this.k48);
      this.combS[j].setup(V.combS[j] * sr, V.fbS, 0.5 * this.k48);
      this.chA[j].setup(V.chA[j] * sr, -0.34, 0.45 * this.k48);
      this.chB[j].setup(V.chB[j] * sr, 0.3, 0.34 * this.k48);
      this.ap[j].setup(V.ap[j] * sr, 0.45);
      this.boom[j].set(V.boom * (j ? 1.06 : 1), 1.4, sr);
      this.bark[j].set(V.bark * (j ? 1.09 : 1), 1.8, sr);
      this.honk[j].set(V.honk * (j ? 1.07 : 1), 2.2, sr);
      this.raspA[j].set(V.rasp[j * 2], V.raspQ, sr);
      this.raspB[j].set(V.rasp[j * 2 + 1], V.raspQ + 1.5, sr);
    }
    const pmF = [205, 455, 1010, 2150], pmQ = [2.2, 3, 3.6, 3];
    for (let k = 0; k < 4; k++) { this.pm[k].set(pmF[k] * V.popTune, pmQ[k], sr); this.pm[k + 4].set(pmF[k] * V.popTune * 1.07, pmQ[k], sr); }
    this.inBP1.set(V.intake[0], 2.6, sr); this.inBP2.set(V.intake[1], 3.2, sr); this.inNz.set(1150, 0.8, sr);
    if (this.rpm > E.limiter) this.rpm = E.limiter;
  }

  tqAt(rpm) {
    const t = this.E.tq;
    if (rpm <= t[0][0]) return t[0][1];
    for (let i = 1; i < t.length; i++) if (rpm < t[i][0]) return lerp(t[i - 1][1], t[i][1], (rpm - t[i - 1][0]) / (t[i][0] - t[i - 1][0]));
    return t[t.length - 1][1];
  }

  /* ------------------------------------------------------------ pesan */
  onMessage(d) {
    if (!d) return;
    if (d.t === 'in') { const v = d.v; for (const k in v) this.inp[k] = v[k]; }
    else if (d.t === 'cfg') {
      const v = d.v;
      for (const k in v) {
        if (k === 'engine') { if (v[k] !== this.cfg.engine) this.setEngine(v[k]); }
        else if (k === 'trans') { if (v[k] !== this.cfg.trans) { this.cfg.trans = v[k]; this.shift = null; const mx = GEARBOX[v[k]].ratios.length - 1; if (this.gear > mx) this.gear = mx; this.locked = false; } }
        else this.cfg[k] = v[k];
      }
    }
    else if (d.t === 'lg') { for (let i = 0; i < 15; i++) this.lg[i] = d.v[i]; }
    else if (d.t === 'master') this.master = d.v;
    else if (d.t === 'cmd') this.cmd(d.c);
  }

  cmd(c) {
    switch (c) {
      case 'start': if (this.estate === 0 || this.estate === 4) { this.estate = 1; this.et = 0; this.pumpOn = 1; this.coolT = 0; this.gear = 0; this.shift = null; this.crankDur = 0.6 + 0.3 * this.cold; this.hit(0, 2100, 0.004, 0.08, 0, 0.2, 0.6, 1); this.hit(0, 587.3, 0.42, 0.085, 0, 0, 0, 1); this.hit(0, 1174.7, 0.26, 0.04, 0, 0, 0, 1); this.hit(0, 1762, 0.12, 0.016, 0, 0, 0, 1); } break;
      case 'stop': if (this.estate !== 0) { if (this.estate === 3) this.coolT = 9; this.estate = this.estate === 3 ? 4 : 0; this.starterOn = 0; this.pumpOn = 0; this.cut = false; this.burbleT = 0; this.shift = null; } break;
      case 'toggle': this.cmd(this.estate === 0 || this.estate === 4 ? 'start' : 'stop'); break;
      case 'cold': this.cold = 1; break;
      case 'grid': this.v = 0; this.vw = 0; this.gear = 0; this.dist = 0; this.spin = false; this.beta = 0; this.locked = false; this.shift = null; this.aLong = 0; break;
      case 'up': this.reqShift(1); break;
      case 'down': this.reqShift(-1); break;
      case 'neutral': this.reqNeutral(); break;
      case 'bump': this.bump(0.9); break;
      case 'bov': this.bov(0.9, 1); break;
      case 'crack': this.fart(1); break;
      case 'shifter': this.shClick(0.8); this._demoThunk = 0.2; break;
      case 'pop': this.burbleT = 1; this.burbleInt = 1; break;
    }
  }

  /* ------------------------------------------------------------ pemicu suara */
  hit(grp, f, tau, a, pan, nz, c, gl) {
    const g = grp === 12 ? this.lg[12] : grp === 10 ? this.lg[10] * (this.cfg.view ? 0.62 : 0.38) : grp === 14 ? this.lg[14] : grp === 13 ? this.lg[13] : grp === 0 ? this.lg[0] : 1;
    if (g <= 0.001) return;
    const v = this.hits[this.hitI]; this.hitI = (this.hitI + 1) % this.hits.length;
    v.on = true; v.ph = 0; v.w = TAU * f * this.isr; v.env = 1; v.dec = Math.exp(-this.isr / tau);
    v.a = a * g; v.nz = nz * g; v.c = Math.min(1, c * this.k48); v.s = 0; v.gl = gl;
    v.l = Math.cos((pan + 1) * 0.7854); v.r = Math.sin((pan + 1) * 0.7854);
    this.hitsOn = true;
  }
  shClick(l) { // "klik" keluar gigi / melewati gate
    this.hit(10, 1350, 0.011, 0.2 * l, 0.1, 0.55, 0.55, 1);
    this.hit(10, 2950, 0.005, 0.12 * l, 0.1, 0.4, 0.8, 1);
    this.hit(10, 310, 0.014, 0.18 * l, 0.1, 0, 0, 1);
    this.mShift = 1;
  }
  shThunk(l) { // "thunk" masuk gigi — padat & notchy
    this.hit(10, 168, 0.034, 0.6 * l, 0.1, 0.6, 0.12, 0.99996);
    this.hit(10, 415, 0.018, 0.3 * l, 0.1, 0.3, 0.3, 1);
    this.hit(10, 790, 0.045, 0.07 * l, 0.1, 0, 0, 1);
    this.hit(10, 2300, 0.004, 0.1 * l, 0.1, 0.5, 0.8, 1);
    this.mShift = 1;
  }
  thud(a, pan, low) { // hentakan suspensi kaku: pukulan modal bersih, tanpa noise rendah & tanpa nada meluncur
    this.hit(14, 52 * low, 0.042, 0.45 * a, pan, 0, 0, 1);   // bodi
    this.hit(14, 88 * low, 0.028, 0.45 * a, pan, 0, 0, 1);   // ban + as roda
    this.hit(14, 215, 0.036, 0.22 * a, pan, 0, 0, 1);        // rongga ban ("pong" pendek)
    this.hit(14, 405 * low, 0.013, 0.4 * a, pan, 0, 0, 1);   // top-mount ("tok")
    this.hit(14, 930, 0.006, 0.12 * a, pan, 0, 0, 1);        // logam damper
    this.hit(14, 2100, 0.002, 0.03 * a, pan, 0.07, 0.9, 1);  // klik kontak
    this.mThud = 1;
  }
  bump(a) {
    this.thud(a, 0, 1); this.bumpN++;
    this.bumpRear = this.v > 1 ? clamp(2.85 / this.v, 0.035, 0.6) : 0.15; this.bumpAmp = a * 0.8;
  }
  pop(a, big, g) {
    const isBurble = g === undefined;
    if (isBurble) g = this.lg[4];
    if (g <= 0.001) return;
    const v = this.pops[this.popI]; this.popI = (this.popI + 1) % this.pops.length;
    const r = this.rnd01(), r2 = this.rnd01();
    // N-wave: satu–dua siklus teredam. Crackle kecil = pendek & tinggi ("tak"), bang = panjang & rendah ("POK")
    const Tn = big ? 0.0024 + 0.0014 * r : 0.0007 + 0.001 * r;
    v.w = TAU / (Tn * this.sr); v.ph = 0;
    v.e1 = a * (big ? 1.7 : 1.0) * g; v.d1 = Math.exp(-this.isr / (Tn * (big ? 1.1 : 1.0)));
    v.eN = a * (big ? 1.1 : 0.85) * g; v.dN = Math.exp(-this.isr / (big ? 0.005 + 0.004 * r2 : 0.002 + 0.0025 * r2));
    v.eB = a * (big ? 1.6 : 0.6) * g; v.dB = Math.exp(-this.isr / (big ? 0.028 + 0.022 * r2 : 0.009 + 0.009 * r2));
    v.lp = 0;
    const pan = (this.rnd() * 0.55 + 1) * 0.7854;
    v.l = Math.cos(pan); v.r = Math.sin(pan);
    this.popOn = true; this.popTail = Math.round(this.sr * 0.14);
    if (isBurble) this.mPop = 1;
  }
  fart(a) {
    if (this.lg[9] <= 0.001) return;
    this.fartEnv = a * this.lg[9]; this.fartT = 0; this.fartPh = 0; this.popTail = Math.max(this.popTail, Math.round(this.sr * 0.2));
    this.fartF = TAU * (138 - 26 * this.rnd01()) * this.isr;
    this.fartDec = Math.exp(-this.isr / (0.03 + 0.03 * a));
    this.mFart = 1;
  }
  bov(a, long) {
    this.bovA = a; this.bovEnv = a; this.bovT = 0;
    this.bovDec = Math.exp(-this.isr / ((0.07 + 0.24 * a) * (long ? 1 : 0.4)));
  }

  /* ------------------------------------------------------------ transmisi */
  rpmInGear(g) { const GB = GEARBOX[this.cfg.trans]; return this.vw / RW * GB.ratios[g] * this.E.final * 9.5493; }

  reqNeutral() {
    if (this.gear === 0 || this.shift) return;
    if (this.cfg.trans === 'dct') { this.gear = 0; this.locked = false; this.hit(10, 240, 0.012, 0.1, 0.1, 0.3, 0.3, 1); }
    else this.shift = { k: 3, t: 0, from: this.gear, to: 0, st: 0, gate: false, blip: false };
  }

  reqShift(dir) {
    if (this.shift || this.shiftCool > 0) return false;
    const E = this.E, GB = GEARBOX[this.cfg.trans], max = GB.ratios.length - 1;
    const from = this.gear; let to = from + dir;
    if (from === 0) {
      if (dir < 0) return false;
      to = 1; while (to < max && this.rpmInGear(to) > E.limiter - 1500) to++;
    }
    if (to < 1 || to > max) return false;
    if ((dir < 0 || from === 0) && this.rpmInGear(to) > E.limiter + 120) { this.deny = 6; return false; }
    const mode = this.cfg.mode;
    if (this.cfg.trans === 'dct') {
      if (from === 0) { this.gear = to; this.shiftCool = 0.15; this.hit(10, 210, 0.016, 0.14, 0.1, 0.3, 0.25, 1); return true; }
      if (dir > 0) {
        const dur = [0.2, 0.12, 0.085][mode];
        const crack = this.estate === 3 ? this.load * sstep((this.rpm - 2800) / 3000) * [0.25, 0.7, 1][mode] : 0;
        this.shift = { k: 1, t: 0, dur: dur, crack: crack, cutOn: this.load > 0.2 };
        if (this.spool > 0.35 && this.load > 0.4) this.bov(0.32 * this.spool, 0);
        this.gear = to; this.locked = false;
      } else {
        this.shift = { k: 2, t: 0, to: to, done: false };
        this.gear = to; this.locked = false;
      }
    } else {
      const gate = from > 0 && Math.floor((from - 1) / 2) !== Math.floor((to - 1) / 2);
      this.shift = { k: 3, t: 0, from: from, to: to, st: 0, gate: gate, blip: dir < 0 && from > 0 };
    }
    return true;
  }

  /* ------------------------------------------------------------ fisika (per blok) */
  step(dt) {
    const E = this.E, cfg = this.cfg, inp = this.inp;
    const GB = GEARBOX[cfg.trans];
    const maxGear = GB.ratios.length - 1;
    const isDct = cfg.trans === 'dct';
    const mode = cfg.mode;

    this.thrU += clamp(inp.throttle - this.thrU, -dt * 16, dt * 12);
    this.brk += clamp(inp.brake - this.brk, -dt * 14, dt * 10);
    this.steer += clamp(inp.steer - this.steer, -dt * 5, dt * 5);
    const hb = inp.handbrake > 0.5;
    this.et += dt;
    if (this.shiftCool > 0) this.shiftCool -= dt;
    if (this.shiftCutT > 0) this.shiftCutT -= dt;
    if (this.deny > 0) this.deny--;

    let rpm = this.rpm;

    // ---- state mesin: 0 mati, 1 prime, 2 starter, 3 hidup, 4 berhenti berputar
    if (this.estate === 1) {
      if (this.et > 0.36) { this.estate = 2; this.et = 0; this.starterOn = 1; this.pumpOn = 0; }
    } else if (this.estate === 2) {
      const wob = 0.5 + 0.5 * Math.cos(TAU * this.cyc * E.cyl);
      const tgt = (205 + 45 * Math.min(1, this.et * 2.5)) * (0.78 + 0.22 * wob);
      rpm += (tgt - rpm) * Math.min(1, dt * 22);
      if (this.et > this.crankDur) {
        this.estate = 3; this.et = 0; this.starterOn = 0; this.flare = 1; this.resume = E.cyl + 3;
        this.pop(0.8, true, this.lg[0]);
      }
    }
    const running = this.estate === 3;
    if (this.estate === 2 || this.estate === 1) this.mStart = 1;

    let thr = running ? this.thrU : 0;
    let clutchOv = -1, clutchRate = 12;

    // ---- proses perpindahan gigi
    const sh = this.shift;
    if (sh) {
      sh.t += dt;
      if (sh.k === 1) { // DCT naik: ignition cut → "crack"
        if (sh.cutOn) this.shiftCutT = 0.02;
        if (sh.t >= sh.dur && (this.locked || sh.t > 0.3)) { this.shiftCutT = 0; if (sh.crack > 0.1) this.fart(sh.crack); this.shift = null; this.shiftCool = 0.2; }
      } else if (sh.k === 2) { // DCT turun: rev-match blip
        const want = this.rpmInGear(sh.to);
        if (!sh.done) {
          clutchOv = 0;
          if (running && rpm < want - 50 && sh.t < 0.32) thr = Math.max(thr, 0.9); else sh.done = true;
        }
        if (sh.done && (this.locked || sh.t > 0.5)) { this.shift = null; this.shiftCool = 0.18; }
      } else { // manual: kopling → klik → gate → thunk → kopling
        const t = sh.t;
        if (t < 0.34) clutchOv = 0;
        clutchRate = 9;
        if (t < 0.3) thr = 0;
        if (sh.st === 0 && t >= 0.08) { sh.st = 1; if (sh.from > 0) this.shClick(0.85); this.gear = 0; }
        if (sh.st === 1 && t >= 0.19) { sh.st = 2; if (sh.gate) this.shClick(0.5); }
        if (sh.st === 2 && t >= 0.28) { sh.st = 3; if (sh.to > 0) this.shThunk(1); this.gear = sh.to; }
        if (sh.blip && running && t > 0.13 && t < 0.31) { if (rpm < this.rpmInGear(sh.to) - 100) thr = 0.75; }
        if (t >= 0.47) { this.shift = null; this.shiftCool = 0.04; }
      }
    }
    if (this._demoThunk > 0) { this._demoThunk -= dt; if (this._demoThunk <= 0) this.shThunk(1); }

    // ---- launch control (DCT: rem + gas penuh saat diam)
    this.launch = running && isDct && this.gear === 1 && this.brk > 0.5 && this.thrU > 0.8 && this.v < 0.8;

    // ---- rev limiter (hard cut)
    const lim = this.launch ? 99999 : E.limiter;
    const hyst = this.locked ? 90 : 170;
    this.refT += dt;
    if (running) {
      if (!this.cut) {
        if (rpm >= lim && this.refT > 0.034 && thr > 0.05) { this.cut = true; this.cutT = 0; }
      } else {
        this.cutT += dt;
        if (thr <= 0.05 || (this.cutT > 0.05 && (rpm < lim - hyst || this.cutT > 0.1))) {
          this.cut = false; this.refT = 0;
          if (thr > 0.05) { this.resume = 2; this.pop(0.5 + 0.35 * this.rnd01(), false, this.lg[5]); }
        }
      }
    } else this.cut = false;
    if (this.cut) this.mLim = 1;

    // ---- torsi mesin
    const fuel = running && !this.cut && this.shiftCutT <= 0;
    const Tf = 16 + 0.0092 * rpm + (1 - thr) * 0.0075 * rpm;
    let Ti = 0;
    if (fuel) {
      Ti = E.tqMax * this.tqAt(rpm) * (E.na ? 1 : 0.42 + 0.58 * this.spool) * thr;
      const w = Math.max(rpm, 400) * 0.10472;
      Ti = Math.min(Ti, (E.pMax * 1.15 * Math.pow(thr, 1.6) + 3000) / w);
      if (this.launch) { Ti = Math.min(Ti, clamp((3400 - rpm) * 1.5 + Tf, 0, 420)); this.burbleT = 0.7; this.burbleInt = 0.75; }
      const idleT = lerp(E.idle, E.coldIdle, sstep(this.cold * 1.5)) + this.flare * 480;
      const gov = clamp((idleT - rpm) * 0.6 + Tf, 0, 170);
      if (gov > Ti) Ti = gov;
      this.tn += (this.rnd() - this.tn) * 0.25;
      Ti *= 1 + this.tn * (0.12 + 0.3 * this.cold) * (1 - 0.85 * sstep((rpm - 900) / 1500));
    }
    let Te = Ti - Tf;
    if (!running) Te = -(Tf * 0.9 + 12);

    // ---- lateral
    const m = E.mass, v = this.v;
    const aMax = MU * 9.81;
    const aDem = v * v * this.steer / (5.5 + 0.05 * v * v);
    const aLat = clamp(aDem, -aMax, aMax);
    const under = clamp((Math.abs(aDem) - aMax) / aMax, 0, 1);
    const latUse = Math.min(0.97, Math.abs(aLat) / aMax);
    const Nr = m * Math.max(2, 9.81 * 0.52 + 0.16 * this.aLong);
    // saat ban belakang sudah sliding, vektor gesek tetap mendorong mobil → drift bisa ditahan
    const latEff = this.spin || Math.abs(this.beta) > 0.12 ? Math.min(latUse, 0.8) : latUse;
    const Fmax = MU * Nr * Math.sqrt(1 - latEff * latEff);

    // ---- kopling
    const G = this.gear > 0 ? GB.ratios[this.gear] * E.final : 0;
    const kr = G > 0 ? G / RW * 9.5493 : 0;
    const rpmT = this.vw * kr;
    let ccmd = 0;
    if (G > 0 && running && !hb && !this.launch) {
      if (rpmT > 1000) ccmd = 1;
      else {
        ccmd = sstep((rpm - 1050) / 1500);
        if (isDct && this.brk < 0.05 && ccmd < 0.035) ccmd = 0.035;
        if (this.brk > 0.3 && v < 2.5 && thr < 0.1) ccmd = 0;
      }
    }
    if (clutchOv >= 0) ccmd = clutchOv;
    this.clutch += clamp(ccmd - this.clutch, -dt * 28, dt * clutchRate);
    if (this.clutch < 0.97 || G === 0) this.locked = false;

    // ---- drivetrain
    const I = E.inertia, eff = 0.92;
    let Fd = 0, mEq = 30, Kimp = 0, tc = 0;
    const drag = 0.42 * v * v + (v > 0.05 ? 0.013 * m * 9.81 : 0) + (v > 1 ? m * Math.abs(this.beta) * 4.5 : 0);
    const Rres = drag + this.brk * 1.05 * m * 9.81 + (hb ? 0.45 * m * 9.81 : 0);
    if (G > 0 && this.clutch > 0.002) {
      if (this.locked) {
        mEq += I * G * G / (RW * RW);
        const TwMax = cfg.dsc ? Math.max(20, (0.95 * Fmax * (m + mEq) - mEq * Rres) / m * RW / (G * eff)) : 1e9;
        if (Te > TwMax) { Te = TwMax; tc = 1; }
        Fd = Te * G * eff / RW;
      } else {
        const TwMax = cfg.dsc ? 0.95 * Fmax * RW / (G * eff) : 1e9;
        const d = rpm - rpmT;
        const th = Math.tanh(d / 250);
        let Tc = this.clutch * CLUTCH_T * th;
        if (Tc > TwMax) { Tc = TwMax; tc = 1; if (Te > TwMax - 70) Te = TwMax - 70; }
        else if (cfg.dsc && Tc < -0.8 * TwMax) Tc = -0.8 * TwMax;
        else Kimp = this.clutch * CLUTCH_T * (1 - th * th) / 250 * kr * G * eff / RW;
        if (this.estate !== 2) rpm += (Te - Tc) / I * 9.5493 * dt;
        Fd = Tc * G * eff / RW;
        if (this.clutch > 0.97 && Math.abs(d) < 60) { this.locked = true; if (Math.abs(d) > 25 && !isDct) this.hit(10, 92, 0.03, 0.1, 0, 0.3, 0.05, 1); }
      }
    } else if (this.estate !== 2) {
      rpm += Te / I * 9.5493 * dt;
    }

    // ---- ban belakang: stick / slip
    let a = 0;
    if (!this.spin) {
      const Ft = (Fd * m + mEq * Rres) / (m + mEq);
      if (Math.abs(Ft) <= Fmax) { a = (Ft - Rres) / m; }
      else { this.spin = true; this.spinDir = Ft > 0 ? 1 : -1; }
    }
    let vN;
    if (this.spin) {
      const dir = this.vw > v + 1e-6 ? 1 : this.vw < v - 1e-6 ? -1 : this.spinDir;
      const Ft = dir * Fmax * 0.86;
      a = (Ft - Rres) / m;
      vN = Math.max(0, v + a * dt);
      this.vw = Math.max(0, this.vw + dt * (Fd - Ft) / (mEq + dt * Kimp));
      if ((this.vw - vN) * dir <= 0) { this.spin = false; this.vw = vN; }
    } else {
      vN = Math.max(0, v + a * dt);
      this.vw = vN;
    }
    this.aLong += ((vN - v) / dt - this.aLong) * 0.2;
    this.v = vN; this.aLat = aLat; this.dist += vN * dt;
    if (this.locked) rpm = this.vw * kr;
    if (rpm < 0) rpm = 0;
    if (rpm > E.limiter + 500) rpm = E.limiter + 500;
    if (this.estate === 4 && rpm < 40) { rpm = 0; this.estate = 0; }
    if (this.estate === 0) rpm = Math.max(0, rpm - dt * 900);

    // ---- drift / slip
    const sl = Math.abs(this.vw - this.v);
    const spinN = this.spin ? clamp(sl / 10, 0, 1) : 0;
    let bT = 0;
    if (vN > 3 && Math.abs(aLat) > 1.5 && (this.spin || hb)) {
      bT = (this.steer > 0 ? 1 : -1) * Math.min(0.72, (Math.abs(aLat) / aMax) * (0.3 + 0.7 * (hb ? clamp(vN / 15, 0, 1) : spinN)) * 0.9);
    }
    this.beta += (bT - this.beta) * Math.min(1, dt * (bT !== 0 ? 2.5 : 4));
    let sR = this.spin ? Math.sqrt(clamp(sl / 8, 0, 1)) : 0;
    sR = Math.max(sR, Math.min(1, Math.abs(this.beta) / 0.5) * clamp(vN / 10, 0, 1));
    if (hb) sR = Math.max(sR, clamp(vN / 12, 0, 1));
    if (tc && vN > 0.5) sR = Math.max(sR, 0.1);
    let sF = under * clamp(vN / 9, 0, 1) * 0.85;
    sF = Math.max(sF, sstep((latUse - 0.8) / 0.17) * 0.32 * clamp(vN / 9, 0, 1));
    if (this.brk > 0.92 && vN > 4) sF = Math.max(sF, 0.14);
    if (inp.skid > 0) sR = Math.max(sR, inp.skid);
    this.slipV = Math.max(this.spin ? sl : 0, Math.abs(vN * Math.sin(this.beta)), hb ? vN : 0, inp.skid > 0 ? 6 + 16 * (0.5 + 0.5 * Math.sin(this.et * 2.1)) : 0);
    // ban menggigit lagi setelah sliding → "chirp"
    this.slipPk = Math.max(sR, (this.slipPk || 0) - dt * 2.2);
    if (this.slipPk > 0.5 && sR < 0.12 && vN > 4) {
      this.slipPk = 0;
      this.hit(12, 1180, 0.04, 0.2, -0.6, 0.5, 0.5, 1.00003); this.hit(12, 1330, 0.032, 0.17, 0.6, 0.5, 0.5, 1.00004);
    }
    this.slipR = sR; this.slipF = sF; this.tc = tc;

    // ---- load, panas, cold
    const TiEff = fuel ? Math.max(0, Te + Tf) : 0;
    this.Ti = TiEff; this.Fd = Fd;
    const loadRaw = clamp(TiEff / (E.tqMax * 0.92), 0, 1);
    this.load += (loadRaw - this.load) * Math.min(1, dt * 45);
    this.heat += (this.load - this.heat) * dt * (this.load > this.heat ? 1.6 : 0.3);
    if (running) { this.cold = Math.max(0, this.cold - dt / 15 * (1 + 2.5 * this.load)); this.flare *= Math.exp(-dt / 0.45); }

    // ---- deteksi lepas gas → diverter valve + burble
    if (thr > this.thrHold) this.thrHold = thr; else this.thrHold = Math.max(0, this.thrHold - dt * 6);
    if (running && thr < 0.1 && this.thrHold > 0.45) {
      this.thrHold = 0;
      if (this.spool > 0.22) { this.bov(Math.min(1, this.spool * 1.15), 1); this.spool *= 0.4; }
      if (rpm > 2400 && mode > 0) { this.burbleT = 1; this.burbleInt = clamp(0.35 + this.heat * 1.1, 0, 1) * sstep((rpm - 2200) / 1800); }
    }
    if (this.burbleT > 0) {
      this.burbleT -= dt / 2.3;
      if ((thr > 0.15 && !this.launch) || rpm < 1700 || !running) this.burbleT = 0;
    }

    // ---- turbo
    const rpmN = clamp(rpm / E.redline, 0, 1.05);
    const tgt = running && !E.na ? thr * sstep((rpm - 1100) / 2600) * (this.locked ? 1 : 0.62) : 0;
    const tau = tgt > this.spool ? 0.2 + 0.5 * (1 - rpmN) : 0.8;
    this.spool += (tgt - this.spool) * (1 - Math.exp(-dt / tau));

    // ---- logika otomatis DCT
    if (isDct && this.gear > 0 && !this.shift && this.shiftCool <= 0 && running && !this.launch) {
      if (cfg.auto) {
        // Sport+: setelah gas dalam, tahan gigi (tidak upshift dini saat gas dikurangi)
        if (this.thrU > 0.7) this.sportHold = 3.5; else if (this.sportHold > 0) this.sportHold -= dt;
        const up = mode === 2 && this.sportHold > 0 ? E.limiter - 260 : lerp([2300, 3300, 4400][mode], E.limiter - 260, Math.pow(this.thrU, 1.3));
        const dn = lerp([950, 1300, 1900][mode], 3600, this.thrU * this.thrU) + this.brk * [300, 1500, 2600][mode];
        const aft = this.gear > 1 ? this.rpmInGear(this.gear - 1) : 0;
        if (vN < 2 && this.gear > 1 && this.thrU < 0.1) { this.gear = 1; this.locked = false; }
        else if (rpm > up && this.gear < maxGear && this.locked && this.burbleT <= 0 && this.brk < 0.05 && !(this.spin && this.gear >= 2 && !cfg.dsc)) this.reqShift(1);
        else if (this.gear > 1 && rpmT < dn && aft < E.limiter - 900 && aft < Math.max(up - 300, this.brk > 0.05 ? 5600 : 0)) this.reqShift(-1);
      } else if (this.gear > 1 && vN < 2) { this.gear = 1; this.locked = false; } else if (this.gear > 1 && rpmT < 900) this.reqShift(-1);
    }

    // ---- jalan bergelombang, kerb, pendinginan knalpot
    if (this.bumpRear > 0) { this.bumpRear -= dt; if (this.bumpRear <= 0) this.thud(this.bumpAmp, 0, 0.9); }
    if (cfg.bumpy && vN > 3 && this.rnd01() < dt * (0.35 + vN * 0.025)) this.bump(0.3 + 0.6 * this.rnd01());
    if (this.coolT > 0 && this.estate === 0) {
      this.coolT -= dt;
      if (this.rnd01() < dt * 0.45 * this.coolT) this.hit(1, 2600 + 3200 * this.rnd01(), 0.02 + 0.03 * this.rnd01(), 0.03, this.rnd() * 0.6, 0.006, 0.9, 1);
    }

    this.thr = thr; this.rpm = rpm;
  }

  /* ------------------------------------------------------------ pengapian per silinder */
  onFire(c) {
    this.fireMask |= 1 << c;
    let a;
    if (this.fuelA) {
      this.gurg += (this.rnd() - this.gurg) * 0.12;
      a = this.loadAmp * this.E.cylGain[c] * (1 + this.jit * this.rnd()) * Math.max(0.3, 1 + this.gurgK * this.gurg * 3.2);
      if (this.resume > 0) { a = a * 1.35 + 0.25; this.resume--; }
      this.tickEnv = this.tickAmt;
    } else a = this.motorAmp;
    this.amp[c] = a;
  }

  /* ------------------------------------------------------------ audio (per blok) */
  block(L, R, o, n) {
    const sr = this.sr, isr = this.isr, E = this.E, V = E.voice, lg = this.lg, cfg = this.cfg;
    const nc = E.cyl, off = this.off, px = this.px, amp = this.amp, bank = this.bank;
    const running = this.estate === 3;
    const rpm1 = this.rpm, rpm0 = this.rpmS, drpm = (rpm1 - rpm0) / n;
    let rpm = rpm0; this.rpmS = rpm1;
    const rpmN = clamp(rpm1 / E.redline, 0, 1.05);
    const load = this.load, cold = this.cold, mode = cfg.mode;
    const rot = rpm1 > 1 || rpm0 > 1;
    const dtB = n * isr;

    // -- parameter mesin
    const cycFreq = rpm1 / 120;
    const w = clamp(lerp(V.tpIdle, V.tpHigh, rpmN) * cycFreq, 0.012, 0.3), invW = 1 / w;
    const flapT = Math.max([0, 0.6, 1][mode], running && cold > 0.35 ? 1 : 0, load > 0.7 && rpmN > 0.55 ? 0.8 : 0);
    this.flap += (flapT - this.flap) * Math.min(1, dtB * 14);
    const flap = this.flap;
    const sharp = clamp(0.22 + 0.78 * Math.pow(load, 0.6), 0, 1);
    const rr = lerp(0.26, 0.05, sharp), invRr = 1 / rr, invFall = 1 / (1 - rr);
    const cab = cfg.view ? 1 : 0;
    const coldK = running ? cold * lg[0] : 0;
    this.loadAmp = (0.4 + 0.6 * Math.pow(load, 0.8)) * (0.42 + 0.58 * rpmN) * (1 + 0.75 * coldK);
    this.motorAmp = this.estate === 2 ? 0.3 * lg[0] : this.estate === 4 ? 0.22 : 0.06 * (0.3 + 0.7 * rpmN);
    this.fuelA = running && !this.cut && this.shiftCutT <= 0;
    const wIdle = 1 - sstep((rpm1 - 950) / 900), wHigh = sstep((rpm1 - 4200) / 2400), wLow = 1 - wIdle - wHigh;
    const overrun = running && load < 0.08 && rpm1 > 2200 ? 1 : 0;
    this.jit = V.jitter + 0.1 * wIdle + 0.16 * cold + overrun * 0.1;
    this.gurgK = overrun * 0.28 * mode;
    this.tickAmt = running ? 0.5 * (1 - sstep((rpm1 - 1300) / 1700)) : 0;
    // letupan datang per rentetan tak beraturan: jeda → 1–7 crackle rapat (makin kecil) → jeda; sesekali diawali bang
    const act = this.burbleT > 0 && rot && rpm1 > 1700 ? this.burbleInt * (0.3 + 0.7 * this.burbleT) * [0, 0.6, 1][mode] : 0;
    if (act > 0.02) {
      if (this.bN <= 0) {
        this.bGap -= dtB;
        if (this.bGap <= 0) {
          this.bN = 1 + Math.floor(Math.pow(this.rnd01(), 1.5) * (2 + 5 * act));
          this.bAmp = (0.4 + 0.6 * this.rnd01()) * (0.45 + 0.55 * act);
          this.bBig = this.rnd01() < 0.08 + 0.14 * act;
          this.bIpi = 0;
        }
      }
      if (this.bN > 0) {
        this.bIpi -= dtB;
        if (this.bIpi <= 0) {
          this.pop(this.bAmp, this.bBig);
          this.bBig = false; this.bN--;
          this.bAmp *= 0.55 + 0.38 * this.rnd01();
          this.bIpi = 0.012 + 0.03 * this.rnd01();
          if (this.bN <= 0) { const q = this.rnd01(); this.bGap = (0.06 + 0.3 * q * q) / (0.4 + 0.6 * act); }
        }
      }
    } else { this.bN = 0; this.bGap = 0.03 + 0.05 * this.rnd01(); }
    this.popProb = 0;

    const fTone = V.bright * (1000 + 900 * rpmN + 5400 * Math.pow(load, 1.3) * (0.25 + 0.75 * rpmN)) * (0.5 + 0.5 * flap) * (1 + 0.6 * coldK);
    const fFlap = lerp(1500, 11000, flap);
    for (let j = 0; j < 2; j++) { this.toneLP[j].set(fTone * (j ? 1.05 : 1), 0.75, sr); this.flapLP[j].set(fFlap, 0.7, sr); }
    const gBoom = lerp(1.6, 0.3, sstep(rpmN * 2.3));
    const gBark = 0.6 + 0.6 * load;
    const gHonk = 0.3 + 0.85 * load;
    const evenK = 0.55 - 0.2 * load;
    const honk = this.honk;
    const gEngT = wIdle * lg[1] + wLow * lg[2] + wHigh * lg[3];
    const driveT = 0.8 + 1.5 * load;
    const gExhT = EXH_GAIN * (0.55 + 0.45 * flap) * (cab ? 0.8 : 1);
    const gBreathT = (0.42 - 0.2 * rpmN) * (0.6 + 0.8 * load) * gEngT;
    const rz = (rpm1 - 3900) / 950;
    const gRaspT = V.raspAmt * (sstep((rpm1 - V.raspFrom) / 3000) + V.raspMid * Math.exp(-rz * rz)) * (0.18 + 0.82 * load) * (0.25 + 0.75 * flap) * lg[3] * RASP_GAIN;
    const nzKT = V.noise * (0.6 + 0.6 * load + 0.5 * coldK);
    if (cab) for (let j = 0; j < 2; j++) this.cabLP[j].set(1500 + 1500 * flap, 0.8, sr);
    const cabLP = this.cabLP, chA = this.chA, chB = this.chB, ap = this.ap;
    const xm = E.cross, xd = 1 - xm;
    let nlp0 = this.nlp0 || 0, nlp1 = this.nlp1 || 0;
    const toneLP = this.toneLP, combL = this.combL, combS = this.combS, boom = this.boom, bark = this.bark;
    const raspA = this.raspA, raspB = this.raspB, flapLP = this.flapLP, dcx = this.dcx, dcy = this.dcy, bo = this.bo;
    const dcR = 1 - TAU * 18 * isr;
    const cycK = isr / 120;
    let cyc = this.cyc;

    // -- intake + mekanis
    const gInT = lg[8] * (0.05 + 0.95 * Math.pow(load, 1.2)) * (0.2 + 0.8 * rpmN) * 1.25 * V.intakeGain * (rot ? 1 : 0) * (cab ? 1.9 : 1);
    const gAirT = lg[8] * load * rpmN * 0.1 * (cab ? 1.5 : 1);
    const gMechT = gEngT * (0.08 + 0.92 * Math.pow(rpmN, 1.5)) * (0.5 + 0.5 * load) * 0.1 * (rot ? 1 : 0) * (cab ? 2.4 : 1);
    const mo = V.mech, ma = V.mechA;
    const gTick = gEngT * 0.4 * (cab ? 1.6 : 1);
    // interpolasi gain per-sampel (tanpa zipper)
    const pg = this.pg;
    if (!this.pgInit) { this.pgInit = true; pg[0] = gEngT; pg[1] = driveT; pg[2] = gExhT; pg[3] = gBreathT; pg[4] = gRaspT; pg[5] = nzKT; pg[6] = gInT; pg[7] = gAirT; pg[8] = gMechT; }
    const inv = 1 / n;
    let gEng = pg[0], drive = pg[1], gExh = pg[2], gBreath = pg[3], gRasp = pg[4], nzK = pg[5], gIn = pg[6], gAir = pg[7], gMech = pg[8];
    const dEng = (gEngT - gEng) * inv, dDrive = (driveT - drive) * inv, dExh = (gExhT - gExh) * inv, dBreath = (gBreathT - gBreath) * inv, dRasp = (gRaspT - gRasp) * inv, dNz = (nzKT - nzK) * inv, dIn = (gInT - gIn) * inv, dAir = (gAirT - gAir) * inv, dMech = (gMechT - gMech) * inv;
    pg[0] = gEngT; pg[1] = driveT; pg[2] = gExhT; pg[3] = gBreathT; pg[4] = gRaspT; pg[5] = nzKT; pg[6] = gInT; pg[7] = gAirT; pg[8] = gMechT;
    const invDrive0 = 1 / Math.sqrt(drive), dInvDrive = (1 / Math.sqrt(driveT) - invDrive0) * inv;
    let invDrive = invDrive0;
    const tickDec = Math.exp(-isr / 0.0007);

    // -- starter + pompa bensin
    const stTgt = this.starterOn ? 1 : 0;
    if (this.starterOn) this.stF = 395 * (rpm1 / 230); else this.stF *= Math.pow(0.975, n / 128);
    const stK = stTgt > this.stEnv ? 1 - Math.exp(-isr / 0.012) : 1 - Math.exp(-isr / 0.09);
    const stFk = this.stF * isr;
    const gSt = 0.3 * lg[0];
    const pumpTgt = this.pumpOn ? 1 : 0;

    // -- turbo
    const sp = this.spool;
    const tF = 900 + 4500 * Math.pow(sp, 1.2);
    this.turboBP.set(tF, 16, sr);
    const vT = cab ? 1.15 : 1;
    const tA = Math.pow(sp, 1.6) * 0.022 * lg[6] * vT;
    const tN = Math.pow(sp, 1.4) * 0.5 * lg[6] * vT;
    const tRush = sp * sp * 0.04 * lg[6] * vT;
    const tK1 = tF * isr, tK2 = tF * 1.031 * isr;

    // -- diverter / blow-off
    this.bovT += dtB;
    const bovOn = this.bovEnv > 0.0005;
    if (bovOn) this.bovBP.set(900 + 2100 * Math.exp(-this.bovT * 7) + 500 * this.bovA, 1.1, sr);
    const bovFl = TAU * (36 - 30 * Math.min(0.5, this.bovT)) * isr;
    const gBov = 0.95 * lg[7] * (cab ? 1.3 : 1);
    let bovPh = this.bovPh || 0;

    // -- dengung transmisi
    const GB = GEARBOX[cfg.trans];
    const gr = this.gear > 0 ? GB.ratios[this.gear] : 0;
    const rpmT = gr > 0 ? this.vw / RW * gr * E.final * 9.5493 : 0;
    const wF1 = rpmT / 60 * (gr > 0 ? GB.teeth[this.gear] : 0);
    const wF2 = this.vw / (TAU * RW) * E.final * 11;
    const tqN = this.Fd >= 0 ? Math.pow(clamp(this.Fd / 11000, 0, 1), 0.6) : Math.pow(clamp(-this.Fd / 3500, 0, 1), 0.7) * 0.75;
    const wAT = gr > 0 ? (0.1 + 0.9 * tqN) * sstep(this.v / 7) * (0.45 + 0.55 * clamp(this.v / 50, 0, 1)) * this.clutch : 0;
    this.wA += (wAT - this.wA) * Math.min(1, dtB * 18);
    const vW = cab ? 1.9 : 1;
    const wA1 = this.wA * 0.055 * lg[11] * clamp(1.4 - wF1 / 6000, 0.5, 1) * vW, wA2 = this.wA * 0.05 * lg[11] * vW;
    const wK1 = wF1 * isr, wK2 = wF2 * isr;

    // -- ban + jalan
    const v = this.v;
    const vN = clamp(v / 60, 0, 1.4);
    this.rollL.set(240 + 13 * v, 0.9, sr); this.rollR.set(255 + 13.5 * v, 0.9, sr);
    this.windBP.set(450 + 22 * v, 0.5, sr);
    const vR = cab ? 1.5 : 1;
    const gRoll = Math.pow(vN, 1.2) * 0.6 * lg[13] * vR, gRollB = Math.pow(vN, 1.4) * 0.2 * lg[13] * vR;
    const gWind = vN * vN * 0.15 * lg[13];
    const kerbV = inp_kerbSpeed(this.inp.kerb, v);
    const kK = kerbV / 0.55 * isr;
    const kOn = kerbV > 1;
    const kDec = Math.exp(-isr / 0.0022);
    const gKerb = 1.7 * lg[13];
    if (kOn) this.mKerb = 1;
    const sq = this.sq;
    sq[0].tgt = this.slipR; sq[1].tgt = this.slipR * 0.94; sq[2].tgt = this.slipF;
    let sqOn = false;
    for (let k = 0; k < 3; k++) {
      const s = sq[k];
      s.drift += (this.rnd() - s.drift) * 0.02;
      // nada naik mengikuti kecepatan selip (roda berputar makin liar → lengkingan makin tinggi)
      const sv = k < 2 ? clamp(this.slipV / 26, 0, 1) : clamp(v / 40, 0, 1) * 0.5;
      s.f = s.f0 * (1 + s.drift * 1.7) * (0.8 + 0.5 * sv) * (1.06 - 0.12 * s.tgt);
      if (s.tgt > 0.002 || s.env > 0.002) { sqOn = true; s.bp1.set(s.f, 13, sr); s.bp3.set(s.f * 1.34, 11, sr); s.bp2.set(s.f * 2.05, 8, sr); }
    }
    const sqK = 1 - Math.exp(-isr / 0.035);
    const gSq = SQ_GAIN * lg[12] * (cab ? 0.65 : 1);
    const hissK = clamp(this.slipV / 14, 0, 1);
    const gBrk = this.brk * Math.pow(clamp(v / 28, 0, 1), 0.7) * 0.05 * lg[13] * (v > 0.5 ? 1 : 0);
    const jvK = 0.004 * this.k48;

    const hits = this.hits, pops = this.pops;
    const gPop = POP_GAIN * (0.6 + 0.4 * flap) * (cab ? 0.6 : 1);
    const pm = this.pm, popCab = this.popCab;
    const master = this.master;
    let tPh1 = this.tPh1, tPh2 = this.tPh2, wPh1 = this.wPh1, wPh2 = this.wPh2, stPh = this.stPh, kPh = this.kPh;
    let inPeak = 0;

    for (let i = 0; i < n; i++) {
      rpm += drpm;
      const n1 = this.rnd(), n2 = this.rnd(), n3 = this.rnd();
      let oL = 0, oR = 0, ctr = 0;
      let s0 = 0, s1 = 0, i0 = this.ic0, i1 = this.ic1, inS = 0, mech = 0;
      this.ic0 = 0; this.ic1 = 0;
      gEng += dEng; drive += dDrive; invDrive += dInvDrive; gExh += dExh; gBreath += dBreath; gRasp += dRasp; nzK += dNz; gIn += dIn; gAir += dAir; gMech += dMech;

      if (rot) {
        cyc += rpm * cycK; if (cyc >= 1) cyc -= 1;
        for (let c = 0; c < nc; c++) {
          let x = cyc + off[c]; if (x >= 1) x -= 1;
          if (x < px[c]) {
            this.onFire(c);
            // impuls rasp ditempatkan sub-sampel (interpolasi linear) agar bebas jitter kuantisasi
            const fr = Math.min(1, x / (rpm * cycK + 1e-12)), a = amp[c];
            if (bank[c]) { i1 += a * fr; this.ic1 += a * (1 - fr); } else { i0 += a * fr; this.ic0 += a * (1 - fr); }
          }
          px[c] = x;
          if (x < w) {
            const u = x * invW;
            let p;
            if (u < rr) p = u * invRr; else { const q = (1 - u) * invFall; p = q * q * (0.55 + 0.45 * q); }
            p *= amp[c];
            if (bank[c]) s1 += p; else s0 += p;
          }
          let xi = x + 0.45; if (xi >= 1) xi -= 1;
          if (xi < 0.3) { const u = xi * 3.33333, q = 1 - u; inS += u * q * q * 6.75; }
        }
        const cp = TAU * 2 * cyc;
        mech = Math.sin(cp * mo[0]) * ma[0] + Math.sin(cp * mo[1]) * ma[1] + Math.sin(cp * mo[2]) * ma[2];
      }

      // letupan knalpot — jalur tersendiri (tidak lewat comb pipa, supaya kering & tajam)
      let p0 = 0, p1 = 0, pmL = 0, pmR = 0, phL = 0, phR = 0;
      if (this.popOn) {
        let any = false;
        for (let k = 0; k < pops.length; k++) {
          const pv = pops[k];
          if (pv.eB > 1e-4 || pv.e1 > 1e-4) {
            any = true;
            pv.lp += (n1 - pv.lp) * 0.3;
            const body = Math.sin(pv.ph) * pv.e1 + pv.lp * pv.eB * 1.8;
            const hf = n2 * pv.eN;
            pv.ph += pv.w; pv.e1 *= pv.d1; pv.eN *= pv.dN; pv.eB *= pv.dB;
            pmL += body * pv.l; pmR += body * pv.r; phL += hf * pv.l; phR += hf * pv.r;
          }
        }
        this.popOn = any;
      }
      // DCT "fart" / crack
      if (this.fartEnv > 1e-4) {
        this.fartT += isr;
        const att = Math.min(1, this.fartT * 500);
        const fp = this.fartPh * 0.15915494, saw = 2 * (fp - Math.floor(fp)) - 1;
        const f = (saw * 0.75 + Math.tanh(Math.sin(this.fartPh) * 5) * 0.45) * this.fartEnv * att * 1.1 + n2 * this.fartEnv * (Math.exp(-this.fartT * 60) * 2.2 + 0.35);
        this.fartPh += this.fartF; this.fartF *= 0.99996; this.fartEnv *= this.fartDec;
        p0 += f; p1 += f;
      }

      // dua bank knalpot → pipa → muffler
      nlp0 += (n1 - nlp0) * 0.3; nlp1 += (n2 - nlp1) * 0.3;
      const m0 = s0 * xd + s1 * xm, m1 = s1 * xd + s0 * xm;
      const q0 = p0, q1 = p1;
      const k0 = i0 * xd + i1 * xm, k1 = i1 * xd + i0 * xm;
      for (let j = 0; j < 2; j++) {
        const sj = j ? m1 : m0, nj = j ? nlp1 : nlp0, pj = j ? q1 : q0;
        const src = sj * (1 + nzK * nj);
        let y = toneLP[j].lpf(src) * gEng + sj * nj * gBreath + pj * 0.7;
        // header → tiga ruang muffler paralel → diffuser
        const h = combS[j].tick(y);
        y = h * 0.5 + chA[j].tick(h) * 0.42 + chB[j].tick(h) * 0.4 + combL[j].tick(h) * 0.5;
        y = ap[j].tick(y);
        y = y + boom[j].bpf(y) * gBoom + bark[j].bpf(y) * gBark + honk[j].bpf(y) * gHonk;
        y = ftanh((y + evenK * (y < 0 ? -y : y)) * drive) * invDrive;
        const d = y - dcx[j] + dcR * dcy[j]; dcx[j] = y; dcy[j] = d;
        const re = (j ? k1 : k0) * 14 + sj * nj * 2.4;
        const r = raspA[j].bpf(re) + raspB[j].bpf(re) * 0.7;
        let b = flapLP[j].lpf(d) * gExh + r * gRasp;
        if (cab) b = cabLP[j].lpf(b);
        bo[j] = b;
      }
      oL += bo[0] * 0.88 + bo[1] * 0.22;
      oR += bo[1] * 0.88 + bo[0] * 0.22;
      if (this.popTail > 0) {
        this.popTail--;
        // resonansi mulut pipa: empat mode per sisi memberi warna "pok", bukan dengung
        let yl = pmL * 0.45 + pm[0].bpf(pmL) * 0.8 + pm[1].bpf(pmL) + pm[2].bpf(pmL) * 0.85 + pm[3].bpf(pmL) * 0.5;
        let yr = pmR * 0.45 + pm[4].bpf(pmR) * 0.8 + pm[5].bpf(pmR) + pm[6].bpf(pmR) * 0.85 + pm[7].bpf(pmR) * 0.5;
        const hf = this.crackHP.hpf(phL + phR + (p0 + p1) * 0.3) * 0.5;
        yl = (yl + hf + phL * 0.25) * gPop; yr = (yr + hf + phR * 0.25) * gPop;
        if (cab) { yl = popCab[0].lpf(yl); yr = popCab[1].lpf(yr); }
        oL += yl; oR += yr;
      }

      // intake karbon
      this.inDc += (inS - this.inDc) * 0.0005;
      const iv = (inS - this.inDc) * (0.55 + 0.35 * n3);
      const io = this.inBP1.bpf(iv) + this.inBP2.bpf(iv) * 0.85;
      const inOut = ftanh(io * 1.6) * gIn + this.inNz.bpf(n3) * gAir;
      ctr += inOut;
      const ia = inOut < 0 ? -inOut : inOut; if (ia > inPeak) inPeak = ia;

      // mekanis + injektor
      ctr += this.mechLP.lpf(mech) * gMech;
      if (this.tickEnv > 1e-4) { ctr += this.tickBP.bpf(n2 * this.tickEnv) * gTick; this.tickEnv *= tickDec; }

      // starter
      this.stEnv += (stTgt - this.stEnv) * stK;
      if (this.stEnv > 0.001) {
        stPh += stFk; if (stPh >= 1) stPh -= 1;
        const st = ((2 * stPh - 1) * 0.5 + Math.sin(TAU * 2 * stPh) * 0.3 + n3 * 0.3) * this.stEnv;
        ctr += (this.stBP.bpf(st) + st * 0.18) * gSt;
      }
      this.pumpEnv += (pumpTgt - this.pumpEnv) * 0.0015;
      if (this.pumpEnv > 0.001) {
        this.pumpPh += 0.0745 * this.k48; if (this.pumpPh > TAU) this.pumpPh -= TAU;
        ctr += (Math.sin(this.pumpPh) + 0.4 * Math.sin(2 * this.pumpPh + 1) + n3 * 0.2) * this.pumpEnv * 0.012 * lg[0];
      }

      // twin-turbo
      if (sp > 0.004) {
        this.tfm += (n3 - this.tfm) * 0.01;
        const fmk = 1 + this.tfm * 0.3;
        tPh1 += tK1 * fmk; if (tPh1 >= 1) tPh1 -= 1;
        tPh2 += tK2 * fmk; if (tPh2 >= 1) tPh2 -= 1;
        const t1 = Math.sin(TAU * tPh1) * tA, t2 = Math.sin(TAU * tPh2) * tA;
        const tn = this.turboBP.bpf(n3) * tN + this.rushBP.bpf(n1) * tRush;
        oL += t1 * 0.85 + t2 * 0.4 + tn; oR += t2 * 0.85 + t1 * 0.4 + tn;
      }

      // diverter valve
      if (bovOn) {
        bovPh += bovFl;
        const fl = 1 - 0.55 * this.bovA * (0.5 + 0.5 * Math.sin(bovPh)) * Math.min(1, this.bovT * 9);
        const b = (this.bovBP.bpf(n2) * 1.3 + this.bovHP.hpf(n3) * 0.22) * this.bovEnv * fl * gBov;
        ctr += b; this.bovEnv *= this.bovDec;
      }

      // transmisi
      if (this.wA > 0.0005) {
        this.wfm += (n2 - this.wfm) * 0.02;
        const wk = 1 + this.wfm * 0.12;
        wPh1 += wK1 * wk; if (wPh1 >= 1) wPh1 -= 1;
        wPh2 += wK2 * wk; if (wPh2 >= 1) wPh2 -= 1;
        const a1 = TAU * wPh1;
        ctr += (Math.sin(a1) + 0.35 * Math.sin(2 * a1 + 0.6)) * wA1 + Math.sin(TAU * wPh2) * wA2;
      }

      // ban menggelinding + angin
      if (v > 0.2) {
        const rl = this.rollL.lpf(n1), rr = this.rollR.lpf(n2);
        const rb = this.rollB.bpf(n3) * gRollB, wd = this.windBP.bpf(n3) * gWind;
        oL += rl * gRoll + rb + wd; oR += rr * gRoll + rb + wd;
      }
      if (gBrk > 0.0005) { const bn = this.brkBP.bpf(n1) * gBrk; oL += bn; oR += bn; }
      // kerb
      if (kOn || this.kEnv > 1e-4) {
        if (kOn) { kPh += kK; if (kPh >= 1) { kPh -= 1; this.kEnv = 0.75 + 0.25 * n1; } }
        const kx = this.kEnv; this.kEnv *= kDec;
        const ky = (this.kBP1.bpf(kx) * 1.5 + this.kBP3.bpf(kx) * 1.6 + this.kBP2.bpf(kx) * 2.6 + kx * n2 * 0.25) * gKerb;
        oL += ky * 0.55; oR += ky;
      }
      // decit ban
      if (sqOn) {
        for (let k = 0; k < 3; k++) {
          const s = sq[k];
          s.env += (s.tgt - s.env) * sqK;
          if (s.env > 0.002) {
            const nk = k === 0 ? n1 : k === 1 ? n2 : n3;
            s.jv += (nk - s.jv) * jvK;
            s.ph += s.f * isr * (1 + s.jv * 1.3); if (s.ph >= 1) s.ph -= 1;
            const ex = (2 * s.ph - 1) * 0.35 + nk * 2.4;
            s.am += (nk - s.am) * 0.006;
            s.ch += (nk - s.ch) * 0.012;
            const e = Math.pow(s.env, 0.7) * clamp(1 + s.am * 5, 0.45, 1.6);
            const tonal = s.bp1.bpf(ex) + s.bp3.bpf(ex) * 0.7 + s.bp2.bpf(ex) * 0.45;
            const roar = s.scr.bpf(nk) * (0.35 + 0.9 * s.env) * clamp(1 + s.ch * 7, 0.3, 1.8);
            const hiss = k < 2 ? this.sqHiss.hpf(nk) * 0.1 * s.env * hissK : 0;
            const y = (tonal + roar * 1.0 + hiss) * e * gSq;
            oL += y * s.l; oR += y * s.r;
          }
        }
      }
      // impak (tuas, suspensi, relay…)
      if (this.hitsOn) {
        let any = false;
        for (let k = 0; k < hits.length; k++) {
          const h = hits[k];
          if (h.on) {
            any = true;
            h.s += (n3 - h.s) * h.c;
            const s = h.env * (Math.sin(h.ph) * h.a + h.s * h.nz * 3);
            h.ph += h.w; h.w *= h.gl; h.env *= h.dec;
            if (h.env < 2e-4) h.on = false;
            oL += s * h.l; oR += s * h.r;
          }
        }
        this.hitsOn = any;
      }

      L[o + i] = ftanh((oL + ctr) * master) * 0.85;
      R[o + i] = ftanh((oR + ctr) * master) * 0.85;
    }

    this.nlp0 = nlp0; this.nlp1 = nlp1;
    this.cyc = cyc; this.tPh1 = tPh1; this.tPh2 = tPh2; this.wPh1 = wPh1; this.wPh2 = wPh2; this.stPh = stPh; this.kPh = kPh; this.bovPh = bovPh % TAU;
    if (!rot) for (let c = 0; c < nc; c++) amp[c] *= 0.9;

    // -- meter layer
    const dk = Math.exp(-dtB / 0.22), M = this.meters;
    this.mPop *= dk; this.mLim *= Math.exp(-dtB / 0.12); this.mFart *= dk; this.mShift *= dk; this.mThud *= dk; this.mKerb *= dk; this.mStart *= dk;
    const run = running ? 1 : 0;
    M[0] = Math.max(this.mStart, this.stEnv, run * cold * 0.8);
    M[1] = run * wIdle * (0.75 + 0.25 * Math.sin(cyc * TAU * 3) * 0.3);
    M[2] = run * wLow * (0.4 + 0.6 * load);
    M[3] = run * wHigh * (0.35 + 0.65 * load);
    M[4] = this.mPop;
    M[5] = this.mLim;
    M[6] = Math.pow(sp, 0.8);
    M[7] = Math.min(1, this.bovEnv * 1.5);
    M[8] = Math.min(1, inPeak * 7);
    M[9] = this.mFart;
    M[10] = this.mShift;
    M[11] = Math.min(1, this.wA * 1.4);
    M[12] = Math.max(this.slipR, this.slipF);
    M[13] = Math.max(Math.min(1, Math.pow(vN, 0.8)), this.mKerb);
    M[14] = this.mThud;
  }

  render(L, R, n) {
    let o = 0;
    while (o < n) {
      const m = Math.min(128, n - o);
      this.step(m * this.isr);
      this.block(L, R, o, m);
      o += m;
      if (++this.postN >= 6) { this.postN = 0; this.report(); }
    }
  }

  report() {
    if (!this.post) return;
    const E = this.E, M = this.meters, m = new Array(15);
    for (let i = 0; i < 15; i++) m[i] = M[i];
    this.post({
      rpm: this.rpm, v: this.v, gear: this.gear, sh: this.shift ? this.shift.k : 0, cl: this.clutch,
      thr: this.thr, brk: this.brk, steer: this.steer, boost: Math.pow(this.spool, 1.5) * E.boostMax, spool: this.spool,
      load: this.load, cold: this.cold, es: this.estate, lim: this.mLim > 0.35 ? 1 : 0, launch: this.launch ? 1 : 0,
      tc: this.tc, sr: this.slipR, sf: this.slipF, beta: this.beta, ax: this.aLong, ay: this.aLat,
      tq: this.Ti, fire: this.fireMask, m: m, deny: this.deny > 0 ? 1 : 0, bump: this.bumpN,
      vw: this.vw, burble: this.burbleT > 0 ? 1 : 0, dist: this.dist,
    });
    this.fireMask = 0;
  }
}

function inp_kerbSpeed(k, v) { return k >= 2 ? Math.max(v, 24) : k >= 1 ? v : 0; }

if (typeof AudioWorkletProcessor !== 'undefined' && typeof registerProcessor === 'function') {
  class BMWCoreProcessor extends AudioWorkletProcessor {
    constructor() {
      super();
      this.core = new BMWCore(sampleRate);
      this.tmp = new Float32Array(128);
      this.core.post = (m) => this.port.postMessage(m);
      this.port.onmessage = (e) => this.core.onMessage(e.data);
    }
    process(inputs, outputs) {
      const out = outputs[0];
      if (!out || !out[0]) return true;
      const L = out[0];
      let R = out[1];
      if (!R) { if (this.tmp.length < L.length) this.tmp = new Float32Array(L.length); R = this.tmp; }
      this.core.render(L, R, L.length);
      return true;
    }
  }
  registerProcessor('bmw-core', BMWCoreProcessor);
}
