import { useEffect, useState } from 'react';
import { rmxLive, type DriftPopupEvent } from './rmx-drift-adapter';

interface Props {
  hud: boolean;
  /** Render only the maneuver callout popups (keeps the minimal drive HUD clean) */
  popupsOnly?: boolean;
  garage: boolean;
  canHotkey: boolean;
  panelOpen: boolean;
  onOpenPanel: () => void;
  onClosePanel: () => void;
  onRestart: () => void;
  onExit: () => void;
}

const ACCENT_STYLE: Record<DriftPopupEvent['accent'], string> = {
  cyan: 'linear-gradient(90deg, rgba(6,182,212,.92), rgba(37,99,235,.92))',
  amber: 'linear-gradient(90deg, rgba(245,158,11,.94), rgba(234,88,12,.92))',
  violet: 'linear-gradient(90deg, rgba(168,85,247,.92), rgba(236,72,153,.92))',
  rose: 'linear-gradient(90deg, rgba(244,63,94,.94), rgba(225,29,72,.92))',
  emerald: 'linear-gradient(90deg, rgba(16,185,129,.92), rgba(13,148,136,.92))',
};

const F = "'Barlow Condensed','Chakra Petch','Rajdhani',sans-serif";
const M = "'IBM Plex Mono',monospace";

/** Live 3D Car Drift Simulator overlay for Rally Group B Lab (E-Brake, drift bar, maneuver banners & controls drawer). */
export default function RmxRallyOverlay({ hud, popupsOnly = false, garage, canHotkey, panelOpen, onOpenPanel, onClosePanel, onExit }: Props) {
  const [snap, setSnap] = useState({
    speedKmh: 0,
    absAngle: 0,
    isDrifting: false,
    isHandbrake: false,
    isManji: false,
    steerAngle: 0,
    throttle: 0,
    brake: 0,
    cueText: '',
  });
  const [popups, setPopups] = useState<DriftPopupEvent[]>([]);

  // Global keyboard shortcuts: Tab = Info Fisika, F2 = Kembali ke Menu 5 Arena
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT')) return;
      if (e.code === 'Tab') {
        if (panelOpen) {
          e.preventDefault();
          e.stopPropagation();
          onClosePanel();
        } else if (canHotkey) {
          e.preventDefault();
          e.stopPropagation();
          onOpenPanel();
        }
        return;
      }
      if (e.code === 'Escape' && panelOpen) {
        e.preventDefault();
        e.stopPropagation();
        onClosePanel();
        return;
      }
      if (e.code === 'F2') {
        e.preventDefault();
        e.stopPropagation();
        onExit();
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [canHotkey, panelOpen, onOpenPanel, onClosePanel, onExit]);

  // Poll live drift-sim telemetry smoothly at ~16 Hz
  useEffect(() => {
    if (!hud && !popupsOnly && !panelOpen) return;
    const id = window.setInterval(() => {
      if (rmxLive.events.length) {
        const fresh = rmxLive.events.splice(0);
        setPopups((prev) => [...prev.slice(-2), ...fresh]);
      }
      const now = performance.now();
      setPopups((prev) => (prev.some((p) => now - p.time > 2100) ? prev.filter((p) => now - p.time <= 2100) : prev));
      setSnap({
        speedKmh: rmxLive.speedKmh,
        absAngle: Math.round(Math.abs(rmxLive.slipAngleDeg)),
        isDrifting: rmxLive.isDrifting,
        isHandbrake: rmxLive.isHandbrake,
        isManji: rmxLive.isManji,
        steerAngle: rmxLive.steerAngle,
        throttle: rmxLive.throttle,
        brake: rmxLive.brake,
        cueText: rmxLive.cueText,
      });
    }, 60);
    return () => window.clearInterval(id);
  }, [hud, popupsOnly, panelOpen]);

  const activeMode = hud || garage;
  const barPct = Math.min(100, (snap.absAngle / 65) * 100);
  const steerPct = (1 - snap.steerAngle) * 50; // left (+1) -> 0%, right (-1) -> 100%

  return (
    <>
      {/* Subtle E-Brake & Live Drift Angle Pill (cleanly stacked above .speed-hud on left edge) */}
      {hud && (
        <div
          style={{
            position: 'fixed',
            left: 'clamp(14px, 2.3vw, 34px)',
            bottom: 'clamp(148px, 21vh, 176px)',
            zIndex: 42,
            pointerEvents: 'none',
            display: 'flex',
            flexDirection: 'column',
            gap: 5,
            minWidth: 162,
            padding: '7px 10px',
            borderRadius: 9,
            background: 'rgba(10, 14, 22, 0.68)',
            border: snap.isHandbrake
              ? '1px solid rgba(245, 158, 11, 0.72)'
              : snap.isDrifting
                ? '1px solid rgba(34, 211, 238, 0.55)'
                : '1px solid rgba(255, 255, 255, 0.14)',
            backdropFilter: 'blur(10px)',
            color: '#f1f5f9',
            fontFamily: F,
          }}
          aria-hidden="true"
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
            <span
              style={{
                fontSize: 11,
                fontWeight: 800,
                letterSpacing: '0.1em',
                color: snap.isManji ? '#f0abfc' : snap.isDrifting ? '#67e8f9' : '#94a3b8',
              }}
            >
              {snap.isManji ? 'MANJI CHAIN' : snap.isDrifting ? 'DRIFTING' : 'DRIFT SIM'}
            </span>
            <span
              style={{
                fontFamily: M,
                fontSize: 10,
                fontWeight: 700,
                padding: '1px 6px',
                borderRadius: 4,
                letterSpacing: '0.06em',
                background: snap.isHandbrake ? '#f59e0b' : 'rgba(30, 41, 59, 0.85)',
                color: snap.isHandbrake ? '#090d16' : '#64748b',
                border: snap.isHandbrake ? '1px solid #fcd34d' : '1px solid rgba(255,255,255,0.08)',
              }}
            >
              E-BRAKE
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ flex: 1, height: 5, borderRadius: 99, background: 'rgba(255,255,255,0.1)', overflow: 'hidden' }}>
              <div
                style={{
                  width: `${barPct}%`,
                  height: '100%',
                  background: 'linear-gradient(90deg, #22d3ee, #fbbf24, #f43f5e)',
                  transition: 'width 60ms linear',
                }}
              />
            </div>
            <span style={{ fontFamily: M, fontSize: 11, fontWeight: 700, color: snap.absAngle >= 14 ? '#fde68a' : '#94a3b8', minWidth: 28, textAlign: 'right' }}>
              {snap.absAngle}°
            </span>
          </div>
          {snap.cueText && (
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', color: '#fcd34d' }}>
              {snap.cueText}
            </div>
          )}
        </div>
      )}

      {/* Compact Shortcut Buttons positioned neatly beneath .course-tools (zero overlap) */}
      {activeMode && !panelOpen && (
        <div
          style={{
            position: 'fixed',
            right: 'clamp(14px, 2.3vw, 34px)',
            top: garage ? 74 : 114,
            zIndex: 42,
            display: 'flex',
            gap: 6,
            alignItems: 'center',
          }}
        >
          {hud && (
            <button
              type="button"
              onClick={onOpenPanel}
              title="Info Fisika & Teknik Drift (Tab)"
              style={{
                padding: '6px 10px',
                borderRadius: 8,
                background: 'rgba(10, 14, 22, 0.66)',
                border: '1px solid rgba(255,255,255,0.16)',
                color: '#cbd5e1',
                fontFamily: F,
                fontSize: 12,
                fontWeight: 700,
                letterSpacing: '0.07em',
                cursor: 'pointer',
                backdropFilter: 'blur(8px)',
              }}
            >
              DRIFT INFO <span style={{ opacity: 0.6, fontFamily: M, fontSize: 10, marginLeft: 3 }}>TAB</span>
            </button>
          )}
          <button
            type="button"
            onClick={onExit}
            title="Kembali ke Menu 5 Arena (F2)"
            style={{
              padding: '6px 10px',
              borderRadius: 8,
              background: 'rgba(10, 14, 22, 0.66)',
              border: '1px solid rgba(255,255,255,0.16)',
              color: '#f8fafc',
              fontFamily: F,
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: '0.07em',
              cursor: 'pointer',
              backdropFilter: 'blur(8px)',
            }}
          >
            MENU <span style={{ opacity: 0.6, fontFamily: M, fontSize: 10, marginLeft: 3 }}>F2</span>
          </button>
        </div>
      )}

      {/* Maneuver Callout Popup (same vibe as 3D Car Drift Simulator!) */}
      {(hud || popupsOnly) && popups.length > 0 && (
        <div
          style={{
            position: 'fixed',
            top: 22,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 44,
            pointerEvents: 'none',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 6,
          }}
        >
          {popups.slice(-1).map((ev) => (
            <div
              key={ev.id}
              style={{
                padding: '7px 18px',
                borderRadius: 11,
                background: ACCENT_STYLE[ev.accent],
                border: '1px solid rgba(255,255,255,0.32)',
                boxShadow: '0 10px 28px rgba(0,0,0,0.38)',
                color: '#ffffff',
                fontFamily: F,
                fontSize: 18,
                fontWeight: 800,
                letterSpacing: '0.1em',
                textShadow: '0 1px 4px rgba(0,0,0,0.4)',
                animation: 'toastIn 220ms cubic-bezier(.22,1,.36,1)',
              }}
            >
              {ev.label}
            </div>
          ))}
        </div>
      )}

      {/* Optional Physics Telemetry & 6-Technique Reference Drawer (Tab) */}
      {panelOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Info Fisika 3D Car Drift Simulator"
          onClick={onClosePanel}
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 70,
            background: 'rgba(6, 10, 16, 0.62)',
            backdropFilter: 'blur(6px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 16,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 'min(460px, 100%)',
              borderRadius: 14,
              background: 'rgba(13, 18, 28, 0.96)',
              border: '1px solid rgba(255,255,255,0.14)',
              boxShadow: '0 24px 60px rgba(0,0,0,0.6)',
              padding: '20px 22px',
              color: '#f1f5f9',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <div>
                <div style={{ fontSize: 11, fontFamily: M, letterSpacing: '0.14em', color: '#fbbf24', textTransform: 'uppercase' }}>
                  Rally Group B Lab × Drift Sim
                </div>
                <h2 style={{ margin: '2px 0 0', fontFamily: F, fontSize: 24, fontWeight: 800, letterSpacing: '0.03em' }}>
                  Fisika 3D Car Drift Simulator (100%)
                </h2>
              </div>
              <button
                type="button"
                onClick={onClosePanel}
                style={{
                  padding: '6px 12px',
                  borderRadius: 8,
                  background: '#f59e0b',
                  color: '#090d16',
                  border: 0,
                  fontFamily: F,
                  fontSize: 13,
                  fontWeight: 800,
                  letterSpacing: '0.06em',
                  cursor: 'pointer',
                }}
              >
                LANJUT (TAB)
              </button>
            </div>

            <p style={{ margin: '0 0 14px', fontSize: 13, lineHeight: 1.5, color: '#cbd5e1' }}>
              Mobil Group B (bodi, kokpit &amp; roda PRODRIFT) plus asap 3D volumetric khas PRODRIFT kini bergerak &amp;
              nge-drift 100% memakai fisika <strong style={{ color: '#fff' }}>3D Car Drift Simulator</strong>: gas puncak
              ~165 km/h, oversteer heading vs kecepatan, auto counter-steer assist, dan handbrake E-Brake mulus.
            </p>

            {/* Compact live steering indicator */}
            <div
              style={{
                padding: '10px 12px',
                borderRadius: 10,
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                marginBottom: 14,
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: M, fontSize: 11, color: '#94a3b8', marginBottom: 6 }}>
                <span>SETIR {Math.round(-snap.steerAngle * 100)}%</span>
                <span>SLIP {snap.absAngle}°</span>
                <span>{snap.speedKmh} KM/H</span>
              </div>
              <div style={{ position: 'relative', height: 6, borderRadius: 99, background: 'rgba(255,255,255,0.1)' }}>
                <div
                  style={{
                    position: 'absolute',
                    left: '50%',
                    top: -2,
                    width: 1,
                    height: 10,
                    background: 'rgba(255,255,255,0.35)',
                  }}
                />
                <div
                  style={{
                    position: 'absolute',
                    top: -2,
                    width: 10,
                    height: 10,
                    borderRadius: 99,
                    background: '#38bdf8',
                    transform: 'translateX(-50%)',
                    left: `${steerPct}%`,
                  }}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, fontSize: 12, color: '#cbd5e1', marginBottom: 14 }}>
              <div style={{ padding: '8px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.04)' }}>
                <strong style={{ color: '#67e8f9', display: 'block', fontFamily: F, fontSize: 13 }}>POWER OVER</strong>
                Tahan W + A/D saat laju kencang untuk masuk slide halus.
              </div>
              <div style={{ padding: '8px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.04)' }}>
                <strong style={{ color: '#fbbf24', display: 'block', fontFamily: F, fontSize: 13 }}>E-BRAKE (SPASI)</strong>
                Tarik Spasi di tikungan untuk banting belakang &amp; sudut lebar.
              </div>
              <div style={{ padding: '8px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.04)' }}>
                <strong style={{ color: '#c084fc', display: 'block', fontFamily: F, fontSize: 13 }}>FEINT &amp; MANJI</strong>
                Banting A↔D bolak-balik di jalur lurus untuk rantai drift.
              </div>
              <div style={{ padding: '8px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.04)' }}>
                <strong style={{ color: '#fb7185', display: 'block', fontFamily: F, fontSize: 13 }}>360° SPIN &amp; DONUT</strong>
                Tahan Spasi + A/D penuh untuk putar 360° &amp; lanjut drift!
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 11, fontFamily: M, color: '#94a3b8' }}>
                W/A/S/D · Spasi Handbrake · C Kamera · R Reset · L Lampu
              </span>
              <button
                type="button"
                onClick={onExit}
                style={{
                  padding: '6px 12px',
                  borderRadius: 8,
                  background: 'rgba(255,255,255,0.08)',
                  color: '#f8fafc',
                  border: '1px solid rgba(255,255,255,0.16)',
                  fontFamily: F,
                  fontSize: 12,
                  fontWeight: 700,
                  cursor: 'pointer',
                  flexShrink: 0,
                }}
              >
                Menu Arena (F2)
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
