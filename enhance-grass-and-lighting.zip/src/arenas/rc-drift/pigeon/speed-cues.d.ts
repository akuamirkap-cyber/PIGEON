export function toKmh(metresPerSecond:number):number;
export function lensRush(speed:number):number;
export function roadFlow(speed:number):number;
export function windRush(speed:number):number;
export function roadExposure(speed:number):number;
export const courseMarkerInterval:number;
export function chaseLens(tall:number,rush:number,slide:number,acceleration?:number):{
  following:number; height:number; lookAhead:number; lookHeight:number; field:number;
};
export function bumperLens(tall:number,rush:number):{height:number;field:number;pitch:number};
export function createDriveClock(step:number):{
  readonly alpha:number;
  reset():void;
  advance(elapsed:number,tick:(step:number,sampleAge:number)=>boolean|void):void;
};
export function createRenderBudget():{
  readonly scale:number;
  sample(frameSeconds:number):boolean;
  clearSamples():void;
};