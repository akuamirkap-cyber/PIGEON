// Ghost AI pilot driven strictly by the exact 3D Car Drift Simulator physics (1:1 m/s).
// Reads upcoming corner curvature on Sirkuit Pinus, kicks the tail out cleanly with E-Brake
// (Space) into sweeping turns, holds stylish wide drift angles with billowing white Rally
// smoke, and links corners smoothly with zero barrier impacts.

const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));
const clamp = (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x);

export function createRmxPilot(track) {
  const F = track.frames;
  const N = F.length;
  const gap = track.length / N;
  const kc = Math.max(2, Math.round(10 / gap));
  const j0 = Math.max(1, Math.round(6 / gap));
  const j1 = Math.max(j0 + 2, Math.round(52 / gap));
  const js = Math.max(1, Math.round(3 / gap));

  // Signed curvature: positive = bending right, negative = bending left
  const signedCurv = F.map((_, i) => {
    const a = F[(i - kc + N) % N];
    const b = F[(i + kc) % N];
    return Math.atan2(a.tz * b.tx - a.tx * b.tz, a.tx * b.tx + a.tz * b.tz) / (2 * kc * gap);
  });

  let near = -1;

  return function pilot(run) {
    const st = run.state;
    if (near < 0) {
      let best = Infinity;
      for (let i = 0; i < N; i++) {
        const d = (F[i].x - st.x) ** 2 + (F[i].z - st.z) ** 2;
        if (d < best) {
          best = d;
          near = i;
        }
      }
    } else {
      let bi = near;
      let bd = Infinity;
      for (let k = -45; k <= 45; k++) {
        const q = (near + k + N) % N;
        const d = (F[q].x - st.x) ** 2 + (F[q].z - st.z) ** 2;
        if (d < bd) {
          bd = d;
          bi = q;
        }
      }
      near = bi;
    }

    const curFrame = F[near];
    const lane = (st.x - curFrame.x) * curFrame.tz - (st.z - curFrame.z) * curFrame.tx;

    // Inspect upcoming curvature peak & sign
    let maxCurv = 0;
    let peakSigned = 0;
    for (let j = j0; j < j1; j += js) {
      const sc = signedCurv[(near + j) % N];
      const ac = Math.abs(sc);
      if (ac > maxCurv) {
        maxCurv = ac;
        peakSigned = sc;
      }
    }
    const localCurv = Math.abs(signedCurv[(near + Math.round(12 / gap)) % N]);

    // Aim slightly toward outside of bends to sweep stylish racing/drift lines while clearing walls
    const lookDist = clamp(16 + st.speed * 0.44, 16, 33);
    const lookIdx = Math.max(2, Math.round(lookDist / gap));
    const tp = F[(near + lookIdx) % N];
    const desiredHeading = Math.atan2(tp.x - st.x, tp.z - st.z);

    // Subtle velocity lead so car drives nose-inside while gliding sideways smoothly
    const noseErr = wrap(desiredHeading - st.yaw);
    const velHeading = st.speed > 5 ? Math.atan2(st.vx, st.vz) : st.yaw;
    const velErr = wrap(desiredHeading - velHeading);
    const steerErr = st.speed > 12 ? velErr * 0.62 + noseErr * 0.38 : noseErr;

    // Fast sweeping target speed that initiates juicy Power-Over + E-Brake drifts safely inside 15m wall
    const targetSpeed = clamp(Math.sqrt(26 / Math.max(maxCurv, 0.0055)), 24, 44);
    const safeLane = Math.abs(lane) < 7.8;

    // Stylish quick E-Brake flick when entering a true bend with headroom on road
    const inCorner = localCurv > 0.011 && Math.abs(peakSigned) > 0.011;
    const absBeta = Math.abs(st.beta);
    const flickHandbrake =
      safeLane &&
      inCorner &&
      st.speed > 21 &&
      Math.abs(steerErr) > 0.14 &&
      absBeta < 0.46;

    // Hold confident steer angle in bend, pull back smoothly if drifting too wide near road edge
    let steer = clamp(steerErr * 2.4, -1, 1);
    if (Math.abs(lane) > 9.5) {
      // Gently guard from hitting outer rails
      const recover = lane > 0 ? -0.35 : 0.35;
      steer = clamp(steer + recover, -1, 1);
    }

    const speedOver = st.speed - targetSpeed;
    const brake = speedOver > 5.5 && Math.abs(lane) > 6.5 ? clamp((speedOver - 5.5) / 7, 0.25, 0.9) : 0;
    const gas = brake > 0 ? 0 : speedOver < 2.2 ? 1 : 0.6;

    return {
      gas,
      brake,
      steer,
      handbrake: flickHandbrake,
      response: 'smooth',
    };
  };
}
