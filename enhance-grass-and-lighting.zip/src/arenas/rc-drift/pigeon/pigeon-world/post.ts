import { HalfFloatType, NoToneMapping, UnsignedByteType, Vector2 } from 'three';
import type { Camera, Scene, WebGLRenderer } from 'three';
import { BloomEffect, EffectComposer, EffectPass, RenderPass, ToneMappingEffect, ToneMappingMode, VignetteEffect } from 'postprocessing';

export const PIGEON_EXPOSURE = 1.25;

export function createPigeonPost(renderer: WebGLRenderer, scene: Scene, camera: Camera, lowPower: boolean) {
  const hdr = renderer.extensions.has('EXT_color_buffer_float');
  const initialAutoClear = renderer.autoClear;
  const composer = new EffectComposer(renderer, {
    frameBufferType: hdr ? HalfFloatType : UnsignedByteType,
    multisampling: hdr && !lowPower ? Math.min(4, renderer.capabilities.maxSamples) : 0,
  });
  renderer.autoClear = initialAutoClear;
  // Same combined pass and order as the PIGEON scene's React EffectComposer.
  composer.addPass(new RenderPass(scene, camera));
  composer.addPass(new EffectPass(camera,
    new BloomEffect({ luminanceThreshold: 0.7, luminanceSmoothing: 0.35, intensity: 0.85, mipmapBlur: true, radius: 0.7 }),
    new VignetteEffect({ eskil: false, offset: 0.18, darkness: 0.75 }),
    new ToneMappingEffect({ mode: ToneMappingMode.ACES_FILMIC }),
  ));

  let mainScene = scene, mainCamera = camera;
  const size = new Vector2(), cssSize = new Vector2(), lastSize = new Vector2();
  return {
    render(nextScene: Scene, nextCamera: Camera, dt: number) {
      if (mainScene !== nextScene) composer.setMainScene(mainScene = nextScene);
      if (mainCamera !== nextCamera) composer.setMainCamera(mainCamera = nextCamera);
      renderer.getDrawingBufferSize(size);
      if (!size.equals(lastSize)) {
        renderer.getSize(cssSize);
        composer.setSize(cssSize.x, cssSize.y, false);
        lastSize.copy(size);
      }
      const toneMapping = renderer.toneMapping, autoClear = renderer.autoClear;
      const previousTarget = renderer.getRenderTarget();
      renderer.toneMapping = NoToneMapping;
      renderer.autoClear = true;
      try { composer.render(dt); }
      finally {
        renderer.toneMapping = toneMapping;
        renderer.autoClear = autoClear;
        renderer.setRenderTarget(previousTarget);
      }
    },
    dispose() { composer.dispose(); },
  };
}