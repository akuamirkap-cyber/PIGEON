import * as THREE from 'three';
import { mulberry32 } from './noise';

/* ------------------------------------------------------------------ */
/* Tyre smoke: faceted low-poly puffs                                    */
/* ------------------------------------------------------------------ */
export class Smoke {
  mesh: THREE.InstancedMesh;
  max = 650;
  px = new Float32Array(this.max);
  py = new Float32Array(this.max);
  pz = new Float32Array(this.max);
  vx = new Float32Array(this.max);
  vy = new Float32Array(this.max);
  vz = new Float32Array(this.max);
  age = new Float32Array(this.max).fill(99);
  life = new Float32Array(this.max).fill(1);
  size = new Float32Array(this.max);
  rot = new Float32Array(this.max);
  head = 0;
  rnd = mulberry32(5);
  private m = new THREE.Matrix4();
  private q = new THREE.Quaternion();
  private e = new THREE.Euler();
  private p = new THREE.Vector3();
  private s = new THREE.Vector3();
  private tint = new THREE.Color();

  constructor(scene: THREE.Scene) {
    const g = new THREE.IcosahedronGeometry(1, 0);
    const mat = new THREE.MeshLambertMaterial({
      color: 0xffffff,
      flatShading: true,
      transparent: true,
      opacity: 0.86,
      emissive: 0x39414a,
      emissiveIntensity: 0.5,
    });
    this.mesh = new THREE.InstancedMesh(g, mat, this.max);
    this.mesh.frustumCulled = false;
    this.mesh.castShadow = false;
    this.mesh.receiveShadow = false;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    for (let i = 0; i < this.max; i++) {
      this.m.makeScale(0, 0, 0);
      this.mesh.setMatrixAt(i, this.m);
      this.mesh.setColorAt(i, this.tint.setRGB(1, 1, 1));
    }
    scene.add(this.mesh);
  }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number, life: number) {
    const i = this.head;
    this.head = (this.head + 1) % this.max;
    this.px[i] = x;
    this.py[i] = y;
    this.pz[i] = z;
    this.vx[i] = vx;
    this.vy[i] = vy;
    this.vz[i] = vz;
    this.size[i] = size;
    this.life[i] = life;
    this.age[i] = 0;
    this.rot[i] = this.rnd() * 6.28;
    const k = 0.92 + this.rnd() * 0.1;
    this.mesh.setColorAt(i, this.tint.setRGB(k, k, k));
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  update(dt: number, cam?: THREE.Vector3) {
    for (let i = 0; i < this.max; i++) {
      if (this.age[i] >= this.life[i]) {
        if (this.age[i] < 90) {
          this.age[i] = 99;
          this.m.makeScale(0, 0, 0);
          this.mesh.setMatrixAt(i, this.m);
        }
        continue;
      }
      this.age[i] += dt;
      const t = this.age[i] / this.life[i];
      const drag = Math.exp(-1.6 * dt);
      this.vx[i] *= drag;
      this.vz[i] *= drag;
      this.vy[i] = this.vy[i] * drag + 0.25 * dt;
      this.px[i] += this.vx[i] * dt;
      this.py[i] += this.vy[i] * dt;
      this.pz[i] += this.vz[i] * dt;
      // grow fast, hold, then shrink
      const grow = Math.min(1, t * 4.5);
      const shrink = 1 - Math.max(0, (t - 0.55) / 0.45);
      let sc = this.size[i] * (0.35 + 0.95 * grow) * Math.max(0.001, shrink * shrink * (3 - 2 * shrink));
      if (cam) {
        // puffs melt away when they get too close to the lens
        const dx = this.px[i] - cam.x;
        const dy = this.py[i] - cam.y;
        const dz = this.pz[i] - cam.z;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        const k = Math.min(1, Math.max(0, (d - 4.4) / 7.5));
        sc *= k * k * (3 - 2 * k) + 0.0001;
      }
      this.e.set(this.rot[i] + t, this.rot[i] * 0.7, this.rot[i] * 0.3 + t * 0.6);
      this.q.setFromEuler(this.e);
      this.p.set(this.px[i], this.py[i], this.pz[i]);
      this.s.set(sc, sc * 0.82, sc);
      this.m.compose(this.p, this.q, this.s);
      this.mesh.setMatrixAt(i, this.m);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }

  clear() {
    this.age.fill(99);
    this.mesh.count = this.max;
    for (let i = 0; i < this.max; i++) {
      this.m.makeScale(0, 0, 0);
      this.mesh.setMatrixAt(i, this.m);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}

/* ------------------------------------------------------------------ */
/* Skid marks                                                            */
/* ------------------------------------------------------------------ */
export class Skids {
  max = 5200; // quads
  pos: Float32Array;
  alpha: Float32Array;
  geo: THREE.BufferGeometry;
  mesh: THREE.Mesh;
  head = 0;
  last: (THREE.Vector3 | null)[] = [null, null, null, null];
  lastAlive: boolean[] = [false, false, false, false];
  constructor(scene: THREE.Scene) {
    this.pos = new Float32Array(this.max * 18);
    this.alpha = new Float32Array(this.max * 6).fill(0);
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('a', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -8,
      polygonOffsetUnits: -8,
      fog: false,
      vertexShader: `attribute float a; varying float vA; void main(){ vA=a; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0);} `,
      fragmentShader: `varying float vA; void main(){ gl_FragColor = vec4(0.06,0.06,0.07, vA*0.62); }`,
    });
    this.mesh = new THREE.Mesh(this.geo, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 4;
    scene.add(this.mesh);
  }
  add(wheel: number, p: THREE.Vector3, rx: number, rz: number, on: boolean, strength: number, width = 0.2) {
    if (!on) {
      this.last[wheel] = null;
      return;
    }
    const prev = this.last[wheel];
    if (!prev) {
      this.last[wheel] = p.clone();
      return;
    }
    if (prev.distanceToSquared(p) < 0.35) return;
    const i = this.head;
    this.head = (this.head + 1) % this.max;
    const o = i * 18;
    const ax = prev.x - rx * width;
    const az = prev.z - rz * width;
    const bx = prev.x + rx * width;
    const bz = prev.z + rz * width;
    const cx = p.x + rx * width;
    const cz = p.z + rz * width;
    const dx = p.x - rx * width;
    const dz = p.z - rz * width;
    const ya = prev.y + 0.07;
    const yb = p.y + 0.07;
    const v = [ax, ya, az, bx, ya, bz, cx, yb, cz, ax, ya, az, cx, yb, cz, dx, yb, dz];
    this.pos.set(v, o);
    const s = Math.min(1, strength);
    for (let k = 0; k < 6; k++) this.alpha[i * 6 + k] = s;
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.a as THREE.BufferAttribute).needsUpdate = true;
    this.last[wheel] = p.clone();
  }
  clear() {
    this.pos.fill(0);
    this.alpha.fill(0);
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.a as THREE.BufferAttribute).needsUpdate = true;
    this.last = [null, null, null, null];
  }
}

/* ------------------------------------------------------------------ */
/* Falling sakura petals & autumn leaves                                  */
/* ------------------------------------------------------------------ */
export class Petals {
  pts: THREE.Points;
  n = 520;
  pos: Float32Array;
  vel: Float32Array;
  box = 70;
  mat: THREE.ShaderMaterial;
  constructor(scene: THREE.Scene) {
    this.pos = new Float32Array(this.n * 3);
    this.vel = new Float32Array(this.n * 3);
    const col = new Float32Array(this.n * 3);
    const r = mulberry32(12);
    const pal = [new THREE.Color(0xffc2d6), new THREE.Color(0xff9fbe), new THREE.Color(0xffe6ee), new THREE.Color(0xf6b26b)];
    for (let i = 0; i < this.n; i++) {
      this.pos[i * 3] = (r() - 0.5) * this.box * 2;
      this.pos[i * 3 + 1] = r() * 40;
      this.pos[i * 3 + 2] = (r() - 0.5) * this.box * 2;
      this.vel[i * 3] = 0.6 + r() * 0.8;
      this.vel[i * 3 + 1] = -(0.5 + r() * 0.9);
      this.vel[i * 3 + 2] = (r() - 0.5) * 0.8;
      const c = pal[Math.floor(r() * pal.length)];
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    this.mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      fog: false,
      uniforms: { scale: { value: 600 } },
      vertexShader: `
        attribute vec3 color; varying vec3 vC; varying float vA; uniform float scale;
        void main(){
          vC = color;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          float d = -mv.z;
          vA = smoothstep(3.0, 8.0, d);
          gl_PointSize = clamp(0.2 * scale / max(d, 0.1), 1.5, 9.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec3 vC; varying float vA;
        void main(){
          vec2 p = gl_PointCoord * 2.0 - 1.0;
          p.x *= 1.5;
          if (dot(p, p) > 1.0) discard;
          gl_FragColor = vec4(vC, 0.9 * vA);
          #include <colorspace_fragment>
        }`,
    });
    this.pts = new THREE.Points(g, this.mat);
    this.pts.frustumCulled = false;
    scene.add(this.pts);
  }
  setScale(h: number) {
    this.mat.uniforms.scale.value = h * 0.9;
  }
  update(dt: number, cam: THREE.Vector3, t: number, strength: number) {
    this.pts.visible = strength > 0.02;
    const b = this.box;
    for (let i = 0; i < this.n; i++) {
      const k = i * 3;
      this.pos[k] += (this.vel[k] + Math.sin(t * 1.3 + i) * 0.6) * dt;
      this.pos[k + 1] += (this.vel[k + 1] + Math.sin(t * 2.1 + i * 1.7) * 0.3) * dt;
      this.pos[k + 2] += (this.vel[k + 2] + Math.cos(t * 1.1 + i * 0.7) * 0.5) * dt;
      const wx = this.pos[k] - cam.x;
      const wz = this.pos[k + 2] - cam.z;
      const wy = this.pos[k + 1] - cam.y;
      if (wx > b) this.pos[k] -= b * 2;
      else if (wx < -b) this.pos[k] += b * 2;
      if (wz > b) this.pos[k + 2] -= b * 2;
      else if (wz < -b) this.pos[k + 2] += b * 2;
      if (wy < -14) this.pos[k + 1] += 40;
      else if (wy > 26) this.pos[k + 1] -= 40;
    }
    (this.pts.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }
}
