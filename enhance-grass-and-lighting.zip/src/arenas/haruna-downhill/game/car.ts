import * as THREE from 'three';

export interface CarStyle {
  body: number;
  lower: number;
  hood: number;
  trim?: number;
}

export const PANDA: CarStyle = { body: 0xf3f3ef, lower: 0x17181b, hood: 0x17181b };
export const STYLE_BLUE: CarStyle = { body: 0x2d62d6, lower: 0x14161c, hood: 0x2d62d6 };
export const STYLE_YELLOW: CarStyle = { body: 0xf2c21b, lower: 0x17181b, hood: 0xf2c21b };
export const STYLE_RED: CarStyle = { body: 0xd8262d, lower: 0x17181b, hood: 0xd8262d };
export const STYLE_SILVER: CarStyle = { body: 0xb7bcc4, lower: 0x17181b, hood: 0xb7bcc4 };

export interface CarRig {
  root: THREE.Group; // world placement (position + heading)
  body: THREE.Group; // pitch / roll
  frontPivots: THREE.Group[]; // steering
  wheelSpin: THREE.Group[]; // rotate about local x
  tailMat: THREE.MeshBasicMaterial;
  wheelPositions: THREE.Vector3[];
}

interface Rect {
  w0: number; // half width at the bottom (x)
  w1: number; // half width at the top
  y0: number;
  y1: number;
}

class Builder {
  pos: number[] = [];
  col: number[] = [];

  quad(a: number[], b: number[], c: number[], d: number[], color: THREE.Color, center: number[]) {
    // orient outward
    const ux = b[0] - a[0];
    const uy = b[1] - a[1];
    const uz = b[2] - a[2];
    const vx = c[0] - a[0];
    const vy = c[1] - a[1];
    const vz = c[2] - a[2];
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const cx = (a[0] + b[0] + c[0] + d[0]) / 4 - center[0];
    const cy = (a[1] + b[1] + c[1] + d[1]) / 4 - center[1];
    const cz = (a[2] + b[2] + c[2] + d[2]) / 4 - center[2];
    const flip = nx * cx + ny * cy + nz * cz < 0;
    const tri = (p: number[], q: number[], r: number[]) => {
      if (flip) [q, r] = [r, q];
      this.pos.push(...p, ...q, ...r);
      for (let k = 0; k < 3; k++) this.col.push(color.r, color.g, color.b);
    };
    tri(a, b, c);
    tri(a, c, d);
  }

  /** frustum-like hull between two rectangles (at z0 and z1). x+ = left */
  hull(z0: number, r0: Rect, z1: number, r1: Rect, colors: Partial<Record<'front' | 'back' | 'top' | 'bottom' | 'side', number>>) {
    const v = (z: number, r: Rect) => ({
      bl: [r.w0, r.y0, z],
      br: [-r.w0, r.y0, z],
      tr: [-r.w1, r.y1, z],
      tl: [r.w1, r.y1, z],
    });
    const A = v(z0, r0);
    const B = v(z1, r1);
    const center = [0, (r0.y0 + r0.y1 + r1.y0 + r1.y1) / 4, (z0 + z1) / 2];
    const c = (h: number | undefined, def: number) => new THREE.Color(h ?? def);
    const cs = c(colors.side, 0x888888);
    this.quad(A.bl, A.br, A.tr, A.tl, c(colors.back, 0x888888), center);
    this.quad(B.bl, B.br, B.tr, B.tl, c(colors.front, 0x888888), center);
    this.quad(A.tl, A.tr, B.tr, B.tl, c(colors.top, 0x888888), center);
    this.quad(A.bl, A.br, B.br, B.bl, c(colors.bottom, 0x111111), center);
    this.quad(A.bl, A.tl, B.tl, B.bl, cs, center);
    this.quad(A.br, A.tr, B.tr, B.br, cs, center);
  }

  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.computeVertexNormals();
    return g;
  }
}

export function buildCar(style: CarStyle = PANDA): CarRig {
  const B = new Builder();
  const GLASS = 0x1c2a38;
  const GLASS_TOP = 0x2b4256;
  const BODY = style.body;
  const LOW = style.lower;
  const HOOD = style.hood;
  const R = (w0: number, w1: number, y0: number, y1: number): Rect => ({ w0, w1, y0, y1 });

  // lower sill / floor
  B.hull(-1.95, R(0.74, 0.74, 0.26, 0.5), 1.95, R(0.74, 0.74, 0.26, 0.5), { front: LOW, back: LOW, top: LOW, bottom: 0x0b0b0d, side: LOW });
  // body main (upper white, lower black stripe)
  B.hull(-1.9, R(0.83, 0.8, 0.5, 0.64), 0.75, R(0.83, 0.8, 0.5, 0.64), { front: LOW, back: LOW, top: LOW, side: LOW });
  B.hull(-1.9, R(0.8, 0.74, 0.64, 0.97), 0.75, R(0.8, 0.74, 0.64, 0.95), { front: BODY, back: BODY, top: BODY, side: BODY });
  // hood
  B.hull(0.75, R(0.8, 0.74, 0.5, 0.95), 2.0, R(0.78, 0.68, 0.5, 0.72), { front: LOW, back: HOOD, top: HOOD, bottom: 0x111111, side: BODY });
  // front bumper + rear bumper
  B.hull(1.9, R(0.8, 0.78, 0.3, 0.52), 2.14, R(0.78, 0.74, 0.32, 0.55), { front: LOW, back: LOW, top: LOW, side: LOW });
  B.hull(-2.14, R(0.8, 0.78, 0.3, 0.6), -1.88, R(0.82, 0.8, 0.3, 0.6), { front: LOW, back: LOW, top: LOW, side: LOW });
  // grille
  B.hull(2.1, R(0.5, 0.48, 0.42, 0.5), 2.16, R(0.5, 0.48, 0.42, 0.5), { front: 0x303338, back: 0x303338, top: 0x303338, side: 0x303338 });
  // cabin: windshield
  B.hull(0.72, R(0.73, 0.7, 0.95, 0.97), 0.02, R(0.69, 0.62, 0.95, 1.37), { front: GLASS_TOP, back: GLASS, top: GLASS_TOP, side: GLASS });
  // roof
  B.hull(0.02, R(0.69, 0.62, 0.95, 1.37), -0.78, R(0.69, 0.62, 0.95, 1.37), { front: GLASS, back: GLASS, top: BODY, side: GLASS });
  // hatch / rear window
  B.hull(-0.78, R(0.69, 0.62, 0.95, 1.37), -1.65, R(0.75, 0.66, 0.95, 1.0), { front: GLASS, back: BODY, top: GLASS_TOP, side: GLASS });
  // B-pillar band (white)
  B.hull(-0.42, R(0.7, 0.63, 0.95, 1.36), -0.28, R(0.7, 0.63, 0.95, 1.36), { front: BODY, back: BODY, top: BODY, side: BODY });
  // roof lip + ducktail spoiler
  B.hull(-2.14, R(0.76, 0.76, 0.96, 1.07), -1.7, R(0.78, 0.78, 0.96, 1.01), { front: BODY, back: LOW, top: BODY, side: BODY });
  const bodyGeo = B.geometry();

  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.5, metalness: 0.1, emissive: 0x2b2d33 });
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const bodyMesh = new THREE.Mesh(bodyGeo, mat);
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = false;
  body.add(bodyMesh);

  // mirrors (small boxes)
  const mirrorMat = new THREE.MeshStandardMaterial({ color: 0x15161a, flatShading: true, roughness: 0.5 });
  for (const s of [1, -1]) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.1), mirrorMat);
    m.position.set(0.9 * s, 1.02, 0.58);
    body.add(m);
  }

  // lights
  const headMat = new THREE.MeshBasicMaterial({ color: 0xfff2c4 });
  for (const s of [1, -1]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.13, 0.12), headMat);
    hl.position.set(0.5 * s, 0.7, 2.06);
    body.add(hl);
    const fog = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.07, 0.06), new THREE.MeshBasicMaterial({ color: 0xffe08a }));
    fog.position.set(0.66 * s, 0.38, 2.15);
    body.add(fog);
  }
  const tailMat = new THREE.MeshBasicMaterial({ color: 0x9e1b22 });
  for (const s of [1, -1]) {
    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.16, 0.08), tailMat);
    tl.position.set(0.58 * s, 0.72, -2.14);
    body.add(tl);
  }
  const plate = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.15, 0.04), new THREE.MeshBasicMaterial({ color: 0xf4f4e8 }));
  plate.position.set(0, 0.52, -2.17);
  body.add(plate);
  // exhaust
  const ex = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.2, 6), new THREE.MeshStandardMaterial({ color: 0x9aa0a6, flatShading: true }));
  ex.rotation.x = Math.PI / 2;
  ex.position.set(-0.5, 0.3, -2.14);
  body.add(ex);

  // wheels
  const tireMat = new THREE.MeshStandardMaterial({ color: 0x1b1c21, flatShading: true, roughness: 0.9 });
  const rimMat = new THREE.MeshStandardMaterial({ color: 0xd2d6dc, flatShading: true, roughness: 0.35, metalness: 0.4 });
  const frontPivots: THREE.Group[] = [];
  const wheelSpin: THREE.Group[] = [];
  const wheelPositions: THREE.Vector3[] = [];
  const mkWheel = (x: number, z: number, front: boolean) => {
    const pivot = new THREE.Group();
    pivot.position.set(x, 0.31, z);
    const spin = new THREE.Group();
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.31, 0.22, 10), tireMat);
    tire.rotation.z = Math.PI / 2;
    tire.castShadow = true;
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.24, 6), rimMat);
    rim.rotation.z = Math.PI / 2;
    const hub = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.06, 0.34), rimMat);
    spin.add(tire, rim, hub);
    pivot.add(spin);
    body.parent!.add(pivot);
    if (front) frontPivots.push(pivot);
    wheelSpin.push(spin);
    wheelPositions.push(new THREE.Vector3(x, 0, z));
  };
  mkWheel(0.76, 1.25, true);
  mkWheel(-0.76, 1.25, true);
  mkWheel(0.76, -1.2, false);
  mkWheel(-0.76, -1.2, false);

  return { root, body, frontPivots, wheelSpin, tailMat, wheelPositions };
}
