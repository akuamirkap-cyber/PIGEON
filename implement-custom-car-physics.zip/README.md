# Rally B | Group B Drift Lab

Game drift React + Three.js yang dapat dimainkan langsung di browser, dengan kontrol keyboard dan sentuh.

## Menjalankan

```sh
npm install
npm run dev -- --host 0.0.0.0
```

## Kontrol

- W / panah atas: gas.
- S / panah bawah: rem, lalu mundur.
- A dan D / panah kiri dan kanan: setir.
- Space: handbrake.
- C: kamera belakang, kokpit, atau atas.
- R: reset mobil dan sesi.
- Escape: jeda / lanjut.
- H: panduan.

Garasi menyimpan konfigurasi mobil secara lokal. Skor terbaik juga tersimpan di browser. Tidak memerlukan API key, CDN, atau aset dari layanan eksternal.

## Sumber Asli

Repositori: https://github.com/akuamirkap-cyber/PIGEON

Revisi sumber: `277121cd0128f60b7c849d0363c86f83c5c1211f`

- `src/game/rally-model.js`: model mobil dan roda asli dari `hellosimple.zip`, bagian Rally Group B Lab. Geometri tidak digambar ulang. Hash SHA-256 sama dengan sumber: `787b96c5babcb2ae02c38bbe28306ad8e634cdec66284e81a42a1a4d3e47c5cd`.
- `src/game/drift-effects.ts`: asap volumetrik dan jejak ban asli Rally Lab, dengan penyesuaian impor dan pemetaan state.
- `src/game/course.ts` dan `src/game/track.ts`: visual serta layout Sirkuit Pinus Rally Lab, dipisahkan dari fisika lama.
- `src/game/audio.ts`, `src/game/render-batching.ts`, dan `src/game/render-budget.js`: audio dan optimasi render asli Rally Lab.
- `src/game/physics.ts`: port langsung rumus gerak dari `3d-car-drift-simulator (2).zip` (SHA-256 ZIP: `2e18a111036ced35c4a196a016f59c260ae3fd3ee23e0e8a81b7e29f7e36adde`).

Konstanta mesin, rem, drag, grip lateral, yaw, damping, handbrake, dan counter-steer dipertahankan. Posisi awal dan bentuk batas tabrakan mengikuti Sirkuit Pinus, bukan arena Drift Park pada ZIP. UI, kamera presentasi, transmisi HUD, dan sistem skor merupakan integrasi aplikasi ini. Kesamaan seluruh pengalaman permainan tidak dapat disimpulkan hanya dari kesamaan rumus.

## Verifikasi

```sh
node tests/physics-parity.mjs
npx tsc --noEmit
npm run build
```

Dengan server Vite berjalan, jalankan `node tests/browser-smoke.mjs` untuk menguji keyboard, drift dan asap, konfigurasi garasi, kamera, jeda, reset, pengaturan, serta kontrol sentuh pada layar portrait dan landscape. Instal browser pengujian jika diperlukan dengan `npx playwright install --with-deps chromium`.

Uji paritas membandingkan 10.800 frame dalam enam skenario: akselerasi, rem/mundur, power drift, putaran handbrake, counter-steer, serta input gabungan. Fixture adalah potongan fungsi asli ZIP sebelum pembaruan visual, dengan collision callback kosong pada kedua sisi. Hasil: selisih absolut maksimum 0 untuk posisi, kecepatan, heading, yaw rate, steering, dan sudut slip.

Font disajikan lokal dari `public/fonts`. Artefak uji disimpan di `artifacts`.