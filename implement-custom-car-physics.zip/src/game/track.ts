import * as T from 'three';

export type RoadFrame = { x: number; z: number; tx: number; tz: number };

// The layout and real-world dimensions are retained from Rally Group B Lab.
export function createTrack(Three: typeof T) {
  const scale = 1.45;
  const roadWidth = 7.5;
  const barrier = 1.8 * ((1.665 + 1.433) * (1.9 / 2.736) / 0.257);
  const layout = [
    [0, -87], [0, -60], [.4, -42], [-4.4, -25], [-17, -9], [-27, -3],
    [-34, 5], [-39, 15], [-41, 29], [-39, 46], [-33, 57], [-34, 71],
    [-24, 87], [-2, 101], [23, 106], [45, 98], [61, 80], [68, 52],
    [65, 22], [49, -3], [45, -22], [49, -43], [55, -63], [58, -80],
    [55, -95], [45, -108], [30, -115], [15, -111], [4, -101],
  ];
  const curve = new Three.CatmullRomCurve3(
    layout.map(([x, z]) => new Three.Vector3(x * 1.23 * scale, 0, z * 1.23 * scale)),
    true, 'centripetal',
  );
  curve.arcLengthDivisions = Math.round(2600 * scale);
  const length = curve.getLength();
  const segments = Math.round(960 * scale);
  const start = 32.1 * scale;
  const centers = curve.getSpacedPoints(segments).slice(0, -1);
  const diff = new Three.Vector3();
  const frames = centers.map((point, i) => {
    diff.subVectors(centers[(i + 1) % segments], centers[(i + segments - 1) % segments]).normalize();
    return { x: point.x, z: point.z, tx: diff.x, tz: diff.z };
  });
  function at(distance: number, target: RoadFrame = { x: 0, z: 0, tx: 0, tz: 1 }) {
    const offset = Three.MathUtils.euclideanModulo(distance, length) / length * segments;
    const index = Math.floor(offset);
    const fraction = offset - index;
    const a = frames[index], b = frames[(index + 1) % segments];
    target.x = Three.MathUtils.lerp(a.x, b.x, fraction);
    target.z = Three.MathUtils.lerp(a.z, b.z, fraction);
    target.tx = Three.MathUtils.lerp(a.tx, b.tx, fraction);
    target.tz = Three.MathUtils.lerp(a.tz, b.tz, fraction);
    return target;
  }
  const minX = Math.min(...centers.map(p => p.x)), minZ = Math.min(...centers.map(p => p.z));
  const rangeX = Math.max(...centers.map(p => p.x)) - minX;
  const rangeZ = Math.max(...centers.map(p => p.z)) - minZ;
  const mapScale = 77 / Math.max(rangeX, rangeZ), mapOffset = (100 - rangeX * mapScale) / 2;
  const toMapX = (x: number) => 100 - mapOffset - (x - minX) * mapScale;
  const toMapY = (z: number) => 89 - (z - minZ) * mapScale;
  const mapPoint = (p: RoadFrame) => `${toMapX(p.x).toFixed(2)},${toMapY(p.z).toFixed(2)}`;
  const route = `M${frames.filter((_, i) => i % 9 === 0).map(mapPoint).join(' ')}Z`;
  const origin = at(start);
  const startMarker = { x: toMapX(origin.x), y: toMapY(origin.z) };
  const zones: { start: number; end: number; side: number; path: string }[] = [];
  const before = at(0), after = at(0);
  let zoneStart = 20, runSide = 0;
  for (let d = 20; d <= length - 10; d += 2) {
    at(start + d - 7.4 * scale, before);
    at(start + d + 7.4 * scale, after);
    const bend = Math.atan2(after.tx * before.tz - after.tz * before.tx, after.tx * before.tx + after.tz * before.tz);
    const side = d > length - 13 * scale || Math.abs(bend) <= .119 ? 0 : -Math.sign(bend);
    if (side === runSide) continue;
    if (runSide && d - zoneStart >= 13 * scale) {
      const points: string[] = [];
      for (let i = zoneStart; i <= d + 1; i += 2) points.push(mapPoint(at(start + Math.min(i, d))));
      zones.push({ start: zoneStart, end: d, side: runSide, path: `M${points.join(' ')}` });
    }
    runSide = side;
    zoneStart = d;
  }
  return {
    length, segments, start, roadWidth, barrier, frames, at, origin, startMarker, zones, route,
    scale, laneScale: roadWidth / 7.65, runoff: barrier - 1.6, toMapX, toMapY,
  };
}