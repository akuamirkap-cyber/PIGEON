import type * as Three from 'three';
import type { RallyBuild } from './rally-config';
import type { DriftState } from './types';

type ModelOptions = Partial<RallyBuild> & {
  build?: Partial<RallyBuild>;
  THREE?: typeof Three;
  headlights?: boolean;
  cockpit?: boolean;
  canvasFactory?: (width: number, height: number) => HTMLCanvasElement;
};

type DriveFrame = {
  speed: number;
  steer: number;
  gear?: string;
  rev?: number;
  handbrake?: boolean;
  serviceBrake?: boolean;
  displayKmh?: number;
  wheels?: DriftState['wheels'];
  roughness?: number;
};

export type RallyModel = Three.Group & { userData: {
  tick: (dt: number, state: DriveFrame) => void;
  setHeadlights: (enabled: boolean) => void;
  updateGlow: (eye: Three.Vector3) => void;
  setCockpitView: (enabled: boolean, preservePose?: boolean) => void;
  resetDriver: (gear?: string) => void;
  sockets: { driverEye: Three.Object3D };
  build: RallyBuild;
  setBuild: (patch: Partial<RallyBuild>) => RallyBuild;
} };

export const DEFAULT_RALLY_BUILD: Readonly<RallyBuild>;
export function configureRallyThree(three: typeof Three): void;
export function createRallyCarModel(options?: ModelOptions): RallyModel;
