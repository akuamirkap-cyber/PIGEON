export type WheelId = 'FL' | 'FR' | 'RL' | 'RR';
export type DriftWheel = {
  front: boolean; side: number; x: number; z: number; angle: number; omega: number; spin: number;
  slip: number; roughness: number; height: number;
};
export type DriftState = {
  x: number; z: number; yaw: number; vx: number; vz: number; speed: number;
  beta: number; steer: number; throttle: number; brake: number; rev: number;
  gear: string; handbrake: boolean; serviceBrake: boolean; tireNoise: number;
  roughness: number; wheels: Record<WheelId, DriftWheel>;
};
