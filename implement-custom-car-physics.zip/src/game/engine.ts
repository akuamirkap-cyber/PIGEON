import * as T from 'three';
import { createRallyCourse } from './course';
import { createRallyCarModel } from './rally-model.js';
import { createDriftEffects } from './drift-effects';
import { createDriveAudio } from './audio';
import { batchRigidParts } from './render-batching';
import { createRenderBudget } from './render-budget.js';
import { createCarState, emptyInput, stepCarPhysics, type CarInput } from './physics';
import type { DriftState, DriftWheel, WheelId } from './types';
import type { RallyBuild } from './rally-config';

export type CameraMode = 'chase' | 'cockpit' | 'top';
export type GameOptions = {
  running: boolean; paused: boolean; view: 'arena' | 'garage'; camera: CameraMode;
  sound: boolean; smoke: boolean; quality: 'balanced' | 'high';
};
export type Telemetry = {
  speed: number; angle: number; gear: string; rev: number; score: number; best: number;
  combo: number; drifting: boolean; handbrake: boolean; time: number; distance: number;
  mapX: number; mapY: number; heading: number; lap: number; message: string;
};
export const initialTelemetry: Telemetry = {
  speed: 0, angle: 0, gear: 'N', rev: .12, score: 0, best: 0, combo: 1,
  drifting: false, handbrake: false, time: 0, distance: 0, mapX: 50, mapY: 85,
  heading: 0, lap: 1, message: '',
};
const CAR_SCALE = 1.9 / 2.736;
const WHEEL_KEYS: WheelId[] = ['FL', 'FR', 'RL', 'RR'];

export function createGame(host: HTMLDivElement, build: RallyBuild, onTelemetry: (data: Telemetry) => void) {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const renderer = new T.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
  renderer.outputColorSpace = T.SRGBColorSpace;
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.setClearColor(0x9bb1b8);
  renderer.domElement.setAttribute('aria-label', 'Arena 3D Rally B Group Lab');
  renderer.domElement.setAttribute('role', 'img');
  host.appendChild(renderer.domElement);

  const course = createRallyCourse(T);
  const { scene, track } = course;
  const model = createRallyCarModel({ THREE: T, build, headlights: true });
  batchRigidParts(model);
  model.scale.setScalar(CAR_SCALE);
  scene.add(model);
  const car = createCarState(track.origin.x, track.origin.z, Math.atan2(track.origin.tx, track.origin.tz));
  const effects = createDriftEffects(T);
  const audio = createDriveAudio();
  const renderBudget = createRenderBudget();
  audio.setEnabled(false);
  scene.add(effects.root);
  const camera = new T.PerspectiveCamera(43, 1, .07, 950);
  let width = 1, height = 1;
  let options: GameOptions = {
    running: false, paused: false, view: 'arena', camera: 'chase', sound: false, smoke: true, quality: 'high',
  };
  let disposed = false, frameId = 0, elapsed = 0, distance = 0, score = 0, best = 0;
  let combo = 1, driftDuration = 0, gap = 0, message = '', messageUntil = 0;
  let nearest = Math.round(track.start / track.length * track.segments);
  let routeProgress = 0, previousRoute = nearest * track.length / track.segments;
  let lastTime = performance.now(), lastPublish = 0, introTime = 0, cameraInitialized = false;
  let frameMs = 0;
  const keys = new Set<string>();
  let touch = emptyInput();
  try { best = Number(localStorage.getItem('rally-b.best') || 0); } catch { /* Session scores still work. */ }

  const shadeCanvas = document.createElement('canvas');
  shadeCanvas.width = shadeCanvas.height = 128;
  const ink = shadeCanvas.getContext('2d')!;
  const shade = ink.createRadialGradient(64, 64, 12, 64, 64, 62);
  shade.addColorStop(0, '#0000009c'); shade.addColorStop(.55, '#00000065'); shade.addColorStop(1, '#00000000');
  ink.fillStyle = shade; ink.fillRect(0, 0, 128, 128);
  const shadeTexture = new T.CanvasTexture(shadeCanvas);
  const shadow = new T.Mesh(new T.PlaneGeometry(3.7, 6.2), new T.MeshBasicMaterial({
    map: shadeTexture, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1,
  }));
  shadow.rotation.x = -Math.PI / 2;
  scene.add(shadow);

  const makeWheel = (id: WheelId): DriftWheel => ({
    front: id[0] === 'F', side: id[1] === 'L' ? 1 : -1, x: 0, z: 0, angle: 0,
    omega: 0, spin: 0, slip: 0, roughness: 0, height: 0,
  });
  const wheels: Record<WheelId, DriftWheel> = { FL: makeWheel('FL'), FR: makeWheel('FR'), RL: makeWheel('RL'), RR: makeWheel('RR') };
  const visualState: DriftState = {
    x: car.x, z: car.z, yaw: car.heading, vx: 0, vz: 0, speed: 0,
    beta: 0, steer: 0, throttle: 0, brake: 0, rev: .16,
    gear: 'N', handbrake: false, serviceBrake: false,
    tireNoise: 0, roughness: 0, wheels,
  };

  function inputState(): CarInput {
    return {
      gas: keys.has('KeyW') || keys.has('ArrowUp') || touch.gas,
      brake: keys.has('KeyS') || keys.has('ArrowDown') || touch.brake,
      left: keys.has('KeyA') || keys.has('ArrowLeft') || touch.left,
      right: keys.has('KeyD') || keys.has('ArrowRight') || touch.right,
      handbrake: keys.has('Space') || touch.handbrake,
    };
  }
  const movementKeys = ['KeyW', 'KeyS', 'KeyA', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'];
  const keyDown = (event: KeyboardEvent) => {
    if (!movementKeys.includes(event.code) || /INPUT|SELECT|TEXTAREA/.test((event.target as HTMLElement)?.tagName)) return;
    if (options.running && !options.paused && options.view === 'arena') event.preventDefault();
    keys.add(event.code);
  };
  const keyUp = (event: KeyboardEvent) => keys.delete(event.code);
  const clearInput = () => { keys.clear(); touch = emptyInput(); audio.silence(); };
  window.addEventListener('keydown', keyDown);
  window.addEventListener('keyup', keyUp);
  window.addEventListener('blur', clearInput);

  function findNearest() {
    let closest = Infinity, index = nearest;
    for (let offset = -24; offset <= 24; offset++) {
      const i = (nearest + offset + track.segments) % track.segments;
      const point = track.frames[i];
      const d = (car.x - point.x) ** 2 + (car.z - point.z) ** 2;
      if (d < closest) { closest = d; index = i; }
    }
    nearest = index;
  }

  function collide() {
    findNearest();
    const point = track.frames[nearest];
    const lane = (car.x - point.x) * point.tz - (car.z - point.z) * point.tx;
    const limit = track.barrier - 1.65 - .35;
    if (Math.abs(lane) <= limit) return;
    const side = Math.sign(lane);
    const nx = -point.tz * side, nz = point.tx * side;
    const overlap = Math.abs(lane) - limit;
    car.x += nx * overlap; car.z += nz * overlap;
    const vn = car.vx * nx + car.vz * nz;
    if (vn < 0) {
      // Same wall impulse as the reference, applied to the retained Pine Circuit.
      car.vx -= 1.35 * vn * nx; car.vz -= 1.35 * vn * nz;
      car.vx *= .72; car.vz *= .72;
      if (Math.abs(vn) > 4.5) {
        car.collidedRecently = 1.2; combo = 1; driftDuration = 0;
        message = 'KONTAK DINDING'; messageUntil = elapsed + 1.4;
      }
    }
  }

  function syncVisuals(dt: number, input: CarInput) {
    const fx = Math.sin(car.heading), fz = Math.cos(car.heading);
    const rx = Math.cos(car.heading), rz = -Math.sin(car.heading);
    const intensity = T.MathUtils.clamp((Math.abs(car.vLat) - 2.2) / 14 + (input.handbrake && car.speed > 4 ? .55 : 0), 0, 1);
    const point = track.frames[nearest];
    const lane = Math.abs((car.x - point.x) * point.tz - (car.z - point.z) * point.tx);
    for (const id of WHEEL_KEYS) {
      const wheel = wheels[id];
      const along = (wheel.front ? 1.665 : -1.433) * CAR_SCALE;
      const across = 1.038 * CAR_SCALE * wheel.side;
      wheel.x = car.x + fx * along + rx * across;
      wheel.z = car.z + fz * along + rz * across;
      wheel.angle = wheel.front ? car.steerAngle * .48 : 0;
      wheel.spin = car.wheelSpin;
      wheel.omega = car.vLong / .36;
      wheel.slip = intensity * (wheel.front ? .55 : 1);
      wheel.roughness = lane > track.runoff ? .8 : 0;
    }
    const speed = Math.hypot(car.vx, car.vz);
    const gear = car.vLong < -.5 ? 'R' : speed < .6 ? 'N' : String(Math.min(6, 1 + Math.floor(speed / 9)));
    const rev = speed < .6 ? .15 : .25 + ((speed % 9) / 9) * .72;
    Object.assign(visualState, {
      x: car.x, z: car.z, yaw: car.heading, vx: car.vx, vz: car.vz,
      speed, beta: car.slipAngleDeg * Math.PI / 180, steer: car.steerAngle,
      throttle: input.gas ? 1 : 0, brake: input.brake ? 1 : 0,
      handbrake: input.handbrake, serviceBrake: input.brake,
      tireNoise: intensity, rev, gear, roughness: lane > track.runoff ? .8 : 0,
    });
    model.position.set(car.x, 0, car.z);
    model.rotation.y = car.heading;
    model.userData.tick(dt, { ...visualState, speed: car.vLong, displayKmh: speed * 3.6 });
    shadow.position.set(car.x, .008, car.z); shadow.rotation.z = -car.heading;
    if (options.smoke) effects.step(dt, visualState);
  }

  function updateScore(dt: number) {
    elapsed += dt;
    distance += car.speed * dt;
    const drifting = car.speed > 5 && Math.abs(car.slipAngleDeg) > 12 && car.collidedRecently <= 0;
    if (drifting) {
      driftDuration += dt; gap = 0;
      combo = Math.min(5, 1 + Math.floor(driftDuration / 2.5) * .5);
      score += (Math.abs(car.slipAngleDeg) * .45 + car.speed * .85) * dt * combo;
      if (driftDuration > 2.5) { message = driftDuration > 6 ? 'DRIFT TANPA BATAS' : 'CLEAN DRIFT'; messageUntil = elapsed + .2; }
    } else {
      gap += dt;
      if (gap > .8) { driftDuration = 0; combo = 1; }
    }
    if (score > best) {
      best = Math.floor(score);
      try { localStorage.setItem('rally-b.best', String(best)); } catch { /* Optional persistence. */ }
    }
    const nextRoute = nearest * track.length / track.segments;
    let delta = nextRoute - previousRoute;
    if (delta < -track.length / 2) delta += track.length;
    if (delta > track.length / 2) delta -= track.length;
    routeProgress += delta; previousRoute = nextRoute;
  }

  function snapshot(): Telemetry {
    return {
      speed: Math.round(Math.hypot(car.vx, car.vz) * 3.6), angle: Math.round(Math.abs(car.slipAngleDeg)),
      gear: visualState.gear, rev: visualState.rev, score: Math.floor(score), best, combo,
      drifting: car.speed > 5 && Math.abs(car.slipAngleDeg) > 12 && car.collidedRecently <= 0,
      handbrake: car.isHandbrake, time: elapsed, distance,
      mapX: track.toMapX(car.x), mapY: track.toMapY(car.z), heading: car.heading,
      lap: 1 + Math.max(0, Math.floor(routeProgress / track.length)), message: elapsed < messageUntil ? message : '',
    };
  }

  const desiredEye = new T.Vector3(), desiredTarget = new T.Vector3(), lookTarget = new T.Vector3();
  const eyeSocket = new T.Vector3(), direction = new T.Vector3(), sideVector = new T.Vector3();
  function updateCamera(dt: number) {
    const fx = Math.sin(car.heading), fz = Math.cos(car.heading);
    const rx = Math.cos(car.heading), rz = -Math.sin(car.heading);
    const intro = !options.running || options.view === 'garage';
    model.userData.setCockpitView(!intro && options.camera === 'cockpit', true);
    if (intro) {
      const garage = options.view === 'garage';
      const orbit = reducedMotion ? 0 : Math.sin(introTime * .13) * .25;
      const portrait = width / height < 1;
      const along = portrait ? 8.8 : garage ? 5.1 : 5.2;
      const across = portrait ? 8.5 : garage ? 4.9 : 5.0 + orbit;
      desiredEye.set(car.x + fx * along + rx * across, (portrait ? 2.65 : 2.1) + (reducedMotion ? 0 : Math.sin(introTime * .2) * .035), car.z + fz * along + rz * across);
      desiredTarget.set(car.x, .88, car.z);
      direction.subVectors(desiredTarget, desiredEye).normalize();
      sideVector.crossVectors(direction, T.Object3D.DEFAULT_UP).normalize();
      const offset = width / height < 1 ? 0 : (garage ? 1.85 : 2.1);
      desiredTarget.addScaledVector(sideVector, -offset);
      desiredTarget.y += portrait ? (garage ? 1.85 : .4) : .1;
      camera.fov = width / height < 1 ? 48 : 43;
    } else if (options.camera === 'top') {
      desiredEye.set(car.x - fx * 3, 29, car.z - fz * 3);
      desiredTarget.set(car.x + fx * 3, 0, car.z + fz * 3); camera.fov = 48;
    } else if (options.camera === 'cockpit') {
      model.updateMatrixWorld(true);
      model.userData.sockets.driverEye.getWorldPosition(eyeSocket);
      desiredEye.copy(eyeSocket);
      desiredTarget.set(eyeSocket.x + fx * 14, eyeSocket.y - .95, eyeSocket.z + fz * 14);
      camera.fov = 77;
    } else {
      const follow = width / height < 1 ? 9.7 : 7.6;
      desiredEye.set(car.x - fx * follow + car.vx * .035, 3.3, car.z - fz * follow + car.vz * .035);
      desiredTarget.set(car.x + fx * 3, .9, car.z + fz * 3);
      camera.fov = 53 + Math.min(7, car.speed * .12);
    }
    const blend = cameraInitialized && !reducedMotion ? 1 - Math.exp(-dt * (options.camera === 'cockpit' && !intro ? 24 : 4.2)) : 1;
    camera.position.lerp(desiredEye, blend); lookTarget.lerp(desiredTarget, blend);
    camera.lookAt(lookTarget); camera.updateProjectionMatrix(); cameraInitialized = true;
    model.userData.updateGlow(camera.position);
    effects.update(1, camera.position);
  }

  function resize() {
    width = Math.max(1, host.clientWidth); height = Math.max(1, host.clientHeight);
    renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix();
  }
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(host); resize();

  function animate(now: number) {
    if (disposed) return;
    frameMs = now - lastTime;
    const dt = Math.min(.04, Math.max(.001, (now - lastTime) / 1000));
    lastTime = now; introTime += dt;
    const active = options.running && !options.paused && options.view === 'arena';
    if (active && renderBudget.sample(frameMs / 1000)) {
      renderer.setPixelRatio(Math.min(devicePixelRatio, options.quality === 'high' ? 1.7 : 1) * renderBudget.scale);
      resize();
    }
    const input = active ? inputState() : emptyInput();
    if (active) { stepCarPhysics(car, input, dt, collide); updateScore(dt); }
    if (!options.paused) syncVisuals(dt, input);
    updateCamera(Math.max(.001, Math.min(.2, frameMs / 1000)));
    if (options.sound && active) audio.sample(visualState, options.camera === 'cockpit');
    else audio.silence();
    renderer.render(scene, camera);
    if (now - lastPublish > 70) { onTelemetry(snapshot()); lastPublish = now; }
    frameId = requestAnimationFrame(animate);
  }
  syncVisuals(.016, emptyInput()); updateCamera(.016); onTelemetry(snapshot());
  frameId = requestAnimationFrame(animate);

  return {
    info: { route: course.route, startMarker: course.startMarker, length: course.length },
    configure(patch: Partial<GameOptions>) {
      options = { ...options, ...patch };
      if (patch.sound !== undefined) { audio.setEnabled(patch.sound); if (patch.sound) audio.unlock(); }
      if (patch.paused || patch.running === false || patch.view === 'garage') clearInput();
      if (patch.quality || patch.running !== undefined || patch.view) {
        renderer.setPixelRatio(Math.min(devicePixelRatio, options.quality === 'high' ? 1.7 : 1) * (options.running && options.view === 'arena' ? renderBudget.scale : 1));
        resize();
      }
      effects.root.visible = options.smoke;
    },
    setTouch(key: keyof CarInput, pressed: boolean) { touch[key] = pressed; if (pressed && options.sound) audio.unlock(); },
    setBuild(patch: Partial<RallyBuild>) { model.userData.setBuild(patch); },
    unlockAudio() { audio.unlock(); },
    reset() {
      Object.assign(car, createCarState(track.origin.x, track.origin.z, Math.atan2(track.origin.tx, track.origin.tz)));
      elapsed = distance = score = routeProgress = driftDuration = gap = 0; combo = 1; message = '';
      nearest = Math.round(track.start / track.length * track.segments);
      previousRoute = nearest * track.length / track.segments;
      effects.reset(); clearInput(); model.userData.resetDriver(); onTelemetry(snapshot());
    },
    dispose() {
      disposed = true; cancelAnimationFrame(frameId); resizeObserver.disconnect(); audio.dispose();
      window.removeEventListener('keydown', keyDown); window.removeEventListener('keyup', keyUp); window.removeEventListener('blur', clearInput);
      const materials = new Set<T.Material>(), geometries = new Set<T.BufferGeometry>(), textures = new Set<T.Texture>();
      scene.traverse(object => {
        const mesh = object as T.Mesh;
        if (mesh.geometry) geometries.add(mesh.geometry);
        const list = mesh.material ? (Array.isArray(mesh.material) ? mesh.material : [mesh.material]) : [];
        for (const material of list) {
          materials.add(material);
          for (const value of Object.values(material)) if (value instanceof T.Texture) textures.add(value);
        }
      });
      geometries.forEach(value => value.dispose()); materials.forEach(value => value.dispose()); textures.forEach(value => value.dispose());
      renderer.dispose(); renderer.domElement.remove();
    },
  };
}

export type GameEngine = ReturnType<typeof createGame>;