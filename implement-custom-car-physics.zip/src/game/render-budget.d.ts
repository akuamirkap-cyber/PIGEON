export function createRenderBudget(): {
  readonly scale: number;
  sample(frameSeconds: number): boolean;
  clearSamples(): void;
};