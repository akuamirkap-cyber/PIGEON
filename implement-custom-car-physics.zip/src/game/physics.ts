export type CarInput = { gas: boolean; brake: boolean; left: boolean; right: boolean; handbrake: boolean };
export type CarState = {
  x: number; z: number; vx: number; vz: number; heading: number; angularVel: number;
  steerAngle: number; wheelSpin: number; roll: number; pitch: number; speed: number;
  vLong: number; vLat: number; slipAngleDeg: number; isHandbrake: boolean; collidedRecently: number;
};

export const emptyInput = (): CarInput => ({ gas: false, brake: false, left: false, right: false, handbrake: false });
export function createCarState(x = 0, z = 0, heading = 0): CarState {
  return {
    x, z, heading, vx: 0, vz: 0, angularVel: 0, steerAngle: 0, wheelSpin: 0,
    roll: 0, pitch: 0, speed: 0, vLong: 0, vLat: 0, slipAngleDeg: 0,
    isHandbrake: false, collidedRecently: 0,
  };
}

// Direct port of updateCarPhysics in 3d-car-drift-simulator (2).zip.
// Only input, rendering and circuit collision handling are decoupled here.
export function stepCarPhysics(car: CarState, input: CarInput, dt: number, collide?: () => void) {
  const throttle = input.gas ? 1 : 0;
  const brake = input.brake ? 1 : 0;
  const steerLeft = input.left ? 1 : 0;
  const steerRight = input.right ? 1 : 0;
  const handbrake = input.handbrake;
  car.isHandbrake = handbrake;
  const fx = Math.sin(car.heading), fz = Math.cos(car.heading);
  const rx = Math.cos(car.heading), rz = -Math.sin(car.heading);
  const vLong = car.vx * fx + car.vz * fz;
  const vLat = car.vx * rx + car.vz * rz;
  const speed = Math.hypot(car.vx, car.vz);
  car.speed = speed;
  car.vLong = vLong;
  car.vLat = vLat;
  const targetSteer = steerLeft - steerRight;
  const steerSpeed = targetSteer !== 0 ? 7.5 : 9.5;
  car.steerAngle += (targetSteer - car.steerAngle) * Math.min(1, steerSpeed * dt);
  let slipAngle = 0;
  if (speed > 1.8) slipAngle = Math.atan2(vLat, Math.max(0.5, Math.abs(vLong)));
  car.slipAngleDeg = slipAngle * 180 / Math.PI;

  let longAccel = 0;
  if (throttle > 0) {
    const speedRatio = Math.min(1, Math.max(0, vLong) / 47);
    longAccel += 33.0 * (1 - 0.55 * speedRatio);
  }
  if (brake > 0) longAccel -= vLong > 1.5 ? 38.0 : 18.0;
  if (handbrake && speed > 1.0) longAccel -= Math.sign(vLong) * 7.5;
  const drag = 0.011 * speed * speed + 0.55 * Math.abs(vLong);
  longAccel -= Math.sign(vLong) * drag * 0.45;

  const absSlip = Math.abs(slipAngle);
  let lateralGrip = handbrake ? 1.55 : (absSlip > 0.28 ? 3.25 : 6.4);
  if (throttle > 0 && Math.abs(car.steerAngle) > 0.25 && speed > 9) lateralGrip *= 0.84;
  const lateralForce = -Math.tanh(vLat * 0.28) * lateralGrip * 4.4 - vLat * (handbrake ? 0.35 : 0.95);
  const ax = fx * longAccel + rx * lateralForce;
  const az = fz * longAccel + rz * lateralForce;
  car.vx += ax * dt;
  car.vz += az * dt;
  if (!throttle && !brake && Math.hypot(car.vx, car.vz) < 0.25) { car.vx = 0; car.vz = 0; }

  const steerFactor = Math.min(1, speed / 5.5);
  const directionSign = vLong >= -0.5 ? 1 : -1;
  const yawStrength = handbrake ? 7.6 : 5.4;
  let yawTorque = car.steerAngle * yawStrength * steerFactor * directionSign;
  const intentionalHardSpin = handbrake && Math.abs(car.steerAngle) > 0.85;
  if (speed > 5.0 && absSlip > 0.14 && !intentionalHardSpin) yawTorque += Math.sin(slipAngle) * 2.55;
  const angularDamping = handbrake ? 2.4 : 4.2;
  car.angularVel += (yawTorque - car.angularVel * angularDamping) * dt;
  car.heading += car.angularVel * dt;
  car.x += car.vx * dt;
  car.z += car.vz * dt;
  collide?.();

  const clamp = (n: number, a: number, b: number) => Math.max(a, Math.min(b, n));
  const targetRoll = clamp(-vLat * 0.012 + car.angularVel * 0.035, -0.11, 0.11);
  const targetPitch = clamp((throttle * -0.025) + (brake * 0.035), -0.05, 0.05);
  car.roll += (targetRoll - car.roll) * Math.min(1, 10 * dt);
  car.pitch += (targetPitch - car.pitch) * Math.min(1, 10 * dt);
  car.wheelSpin += (vLong / 0.36) * dt;
  if (car.collidedRecently > 0) car.collidedRecently -= dt;
}