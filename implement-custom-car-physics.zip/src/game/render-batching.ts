import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export function batchRigidParts(root:T.Object3D) {
  const retired=new Set<T.BufferGeometry>();
  root.traverse(parent=>{
    if(parent.children.length<3) return;
    const buckets=new Map<string,T.Mesh<T.BufferGeometry,T.Material>[]>();
    for(const object of parent.children) {
      const mesh=object as T.Mesh;
      if(!mesh.isMesh||mesh.children.length||!mesh.visible||Array.isArray(mesh.material)||mesh.material.transparent) continue;
      const geo=mesh.geometry;
      if(geo.morphAttributes.position||(geo.attributes.position as T.BufferAttribute).usage===T.DynamicDrawUsage||mesh.name==='forearmBone') continue;
      mesh.updateMatrix();
      if(mesh.matrix.determinant()<0) continue;
      const signature=Object.keys(geo.attributes).sort().join(',');
      const key=`${mesh.material.id}/${mesh.layers.mask}/${mesh.renderOrder}/${mesh.castShadow}/${mesh.receiveShadow}/${signature}`;
      const list=buckets.get(key);
      if(list) list.push(mesh as T.Mesh<T.BufferGeometry,T.Material>);else buckets.set(key,[mesh as T.Mesh<T.BufferGeometry,T.Material>]);
    }
    for(const group of buckets.values()) if(group.length>=3) {
      // Children of a single parent share its motion and kit visibility; animated pivots are left intact.
      const parts=group.map(mesh=>{
        const geo=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();
        return geo.applyMatrix4(mesh.matrix);
      });
      const geometry=mergeGeometries(parts);
      for(const part of parts)part.dispose();
      if(!geometry) continue;
      const first=group[0], combined=new T.Mesh(geometry,first.material);
      combined.name=`${parent.name} surface batch`;
      combined.layers.mask=first.layers.mask;combined.renderOrder=first.renderOrder;
      combined.castShadow=first.castShadow;combined.receiveShadow=first.receiveShadow;
      for(const mesh of group) {retired.add(mesh.geometry);parent.remove(mesh);}
      parent.add(combined);
    }
  });
  root.traverse(obj=>{const mesh=obj as T.Mesh;if(mesh.isMesh)retired.delete(mesh.geometry);});
  for(const geo of retired)geo.dispose();
}