export function createRenderBudget() {
  const scales = [1, .83, .68, .55, .46];
  let index = 0, slowFor = 0, fastFor = 0, cooldown = 0, heavyFrames = 0;
  return {
    get scale() { return scales[index]; },
    sample(frameSeconds) {
      if (frameSeconds <= 0 || frameSeconds > 2.4) return false;
      const dt = Math.min(.25, frameSeconds);
      cooldown = Math.max(0, cooldown - dt);
      slowFor = frameSeconds > .0235 ? slowFor + dt : Math.max(0, slowFor - 2 * dt); // Hold ~60 fps for fluid drifting
      fastFor = frameSeconds < .0205 ? fastFor + dt : 0;
      heavyFrames = frameSeconds > .06 ? heavyFrames + 1 : Math.max(heavyFrames - 1, 0);
      if (!cooldown && index < scales.length - 1 && (slowFor > .3 || heavyFrames >= 2)) {
        index++; slowFor = fastFor = heavyFrames = 0; cooldown = .32; return true;
      }
      if (!cooldown && index > 0 && fastFor > 4) {
        index--; slowFor = fastFor = 0; cooldown = 2.4; return true;
      }
      return false;
    },
    clearSamples() { slowFor = fastFor = heavyFrames = 0; },
  };
}