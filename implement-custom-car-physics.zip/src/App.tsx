import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight, Check, ChevronDown,
  ChevronRight, CircleHelp, Flag, Gauge, Keyboard, MapPin, Maximize2, Minimize2,
  Pause, Play, RotateCcw, Settings2, Volume2, VolumeX, X,
} from 'lucide-react';
import { createGame, initialTelemetry, type CameraMode, type GameEngine } from './game/engine';
import { readBuild, writeBuild, type RallyBuild } from './game/rally-config';
import type { CarInput } from './game/physics';

type Panel = 'guide' | 'settings' | null;
type Tab = 'arena' | 'garage';
type TrackInfo = { route: string; startMarker: { x: number; y: number }; length: number };
const cameraNames: Record<CameraMode, string> = { chase: 'BELAKANG', cockpit: 'KOKPIT', top: 'ATAS' };
const cameraModes: CameraMode[] = ['chase', 'cockpit', 'top'];
const formatTime = (seconds: number) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${(seconds % 60).toFixed(2).padStart(5, '0')}`;
const formatScore = (score: number) => String(score).padStart(6, '0');

function Brand({ small = false }: { small?: boolean }) {
  return <span className={`brand ${small ? 'brand-small' : ''}`}>
    <span className="brand-mark" aria-hidden="true"><i /><i /><i /></span>
    <span>RALLY<span className="brand-b">B</span><span className="brand-period">.</span></span>
  </span>;
}

function Key({ children, accent = false }: { children: ReactNode; accent?: boolean }) {
  return <kbd className={accent ? 'key key-accent' : 'key'}>{children}</kbd>;
}

function IconButton({ label, children, onClick, active = false }: {
  label: string; children: ReactNode; onClick: () => void; active?: boolean;
}) {
  return <button type="button" className={`icon-button ${active ? 'is-active' : ''}`} onClick={onClick} aria-label={label} title={label}>{children}</button>;
}

function Toggle({ label, description, checked, onChange }: {
  label: string; description: string; checked: boolean; onChange: (next: boolean) => void;
}) {
  return <label className="setting-row">
    <span><strong>{label}</strong><small>{description}</small></span>
    <input className="switch-input" type="checkbox" checked={checked} onChange={event => onChange(event.target.checked)} />
    <span className={`toggle ${checked ? 'toggle-on' : ''}`} aria-hidden="true"><i /></span>
  </label>;
}

function TrackMap({ info, x, y, heading, active }: {
  info: TrackInfo | null; x: number; y: number; heading: number; active: boolean;
}) {
  return <div className={`track-map ${active ? 'track-map-active' : ''}`}>
    <div className="map-heading"><span>TRACK 01</span><span className="map-north">N <ArrowUp size={10} /></span></div>
    <svg viewBox="17 4 68 92" aria-label="Peta Sirkuit Pinus" role="img">
      {info && <>
        <path d={info.route} fill="none" stroke="rgba(0,0,0,.3)" strokeWidth="5.5" />
        <path d={info.route} fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        <path d={info.route} fill="none" stroke="rgba(255,255,255,.1)" strokeWidth=".4" />
        <path d={`M${info.startMarker.x - 3},${info.startMarker.y}h6`} stroke="white" strokeWidth="1.5" />
        <circle cx={x} cy={y} r="4.2" fill="#f34336" fillOpacity=".2" />
        <g transform={`translate(${x},${y}) rotate(${-heading * 180 / Math.PI})`}>
          <path d="M0,-3.1 L2.1,2.4 L0,1.3 L-2.1,2.4 Z" fill="#ff5144" stroke="#ffaaa3" strokeWidth=".4" />
        </g>
      </>}
    </svg>
    <div className="map-caption"><i /> {active ? 'POSISI MOBIL' : 'SIRKUIT PINUS'}</div>
  </div>;
}

function BuildSelector<K extends keyof RallyBuild>({ title, part, options, build, onChange }: {
  title: string; part: K; options: { value: RallyBuild[K]; label: string }[];
  build: RallyBuild; onChange: (part: K, value: RallyBuild[K]) => void;
}) {
  return <div className="build-selector">
    <div className="build-label">{title}</div>
    <div className="build-segments">
      {options.map(option => <button key={option.value} aria-pressed={build[part] === option.value} className={build[part] === option.value ? 'selected' : ''}
        onClick={() => onChange(part, option.value)}>{option.label}{build[part] === option.value && <Check size={12} />}</button>)}
    </div>
  </div>;
}

export default function App() {
  const canvasHost = useRef<HTMLDivElement>(null);
  const root = useRef<HTMLDivElement>(null);
  const game = useRef<GameEngine | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<Tab>('arena');
  const [started, setStarted] = useState(false);
  const [paused, setPaused] = useState(false);
  const [panel, setPanel] = useState<Panel>(null);
  const [sound, setSound] = useState(false);
  const [smoke, setSmoke] = useState(true);
  const [camera, setCamera] = useState<CameraMode>('chase');
  const [quality, setQuality] = useState<'balanced' | 'high'>('high');
  const [fullscreen, setFullscreen] = useState(false);
  const [build, setBuild] = useState<RallyBuild>(readBuild);
  const initialBuild = useRef(build);
  const [telemetry, setTelemetry] = useState(initialTelemetry);
  const [trackInfo, setTrackInfo] = useState<TrackInfo | null>(null);
  const [notice, setNotice] = useState('');
  const closeButton = useRef<HTMLButtonElement>(null);
  const isDriving = started && tab === 'arena';

  useEffect(() => {
    if (!canvasHost.current) return;
    let engine: GameEngine | null = null;
    const id = window.setTimeout(() => {
      try {
        if (!canvasHost.current) return;
        engine = createGame(canvasHost.current, initialBuild.current, setTelemetry);
        game.current = engine; setTrackInfo(engine.info); setReady(true);
      } catch (cause) {
        console.error(cause);
        setError('Arena 3D tidak dapat dimuat. Aktifkan WebGL atau coba browser terbaru.');
      }
    }, 80);
    return () => { window.clearTimeout(id); engine?.dispose(); game.current = null; };
  }, []);

  useEffect(() => {
    game.current?.configure({ running: started, paused: paused || panel !== null, view: tab, camera, sound, smoke, quality });
  }, [started, paused, panel, tab, camera, sound, smoke, quality, ready]);

  useEffect(() => {
    if (!notice) return;
    const id = window.setTimeout(() => setNotice(''), 2200);
    return () => window.clearTimeout(id);
  }, [notice]);

  useEffect(() => {
    if (!panel && !paused) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    closeButton.current?.focus();
    const trapFocus = (event: KeyboardEvent) => {
      if (event.key !== 'Tab') return;
      const dialog = root.current?.querySelector('[role="dialog"]');
      const elements = dialog?.querySelectorAll<HTMLElement>('button, input, select, a[href]');
      if (!elements?.length) return;
      const first = elements[0], last = elements[elements.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    window.addEventListener('keydown', trapFocus);
    return () => { window.removeEventListener('keydown', trapFocus); previousFocus?.focus(); };
  }, [panel, paused]);

  const startDriving = useCallback(() => {
    if (!game.current || !ready) return;
    setTab('arena'); setStarted(true); setPaused(false); setPanel(null);
    game.current.configure({ running: true, paused: false, view: 'arena' });
    if (sound) game.current.unlockAudio();
    (document.activeElement as HTMLElement | null)?.blur();
  }, [ready, sound]);

  const cycleCamera = useCallback(() => setCamera(current => cameraModes[(cameraModes.indexOf(current) + 1) % cameraModes.length]), []);
  const resetCar = useCallback(() => { game.current?.reset(); setNotice('MOBIL KEMBALI KE GARIS START'); }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (/INPUT|SELECT|TEXTAREA/.test((event.target as HTMLElement)?.tagName)) return;
      if (event.repeat) return;
      if (event.code === 'Escape') {
        event.preventDefault();
        if (panel) setPanel(null);
        else if (isDriving) setPaused(value => !value);
        return;
      }
      if (panel || paused) return;
      if ((event.code === 'Enter' || event.code === 'KeyW' || event.code === 'ArrowUp') && !started && tab === 'arena') startDriving();
      if (event.code === 'KeyC') cycleCamera();
      if (event.code === 'KeyR') resetCar();
      if (event.code === 'KeyH') setPanel('guide');
      if (event.code === 'KeyP' && isDriving) setPaused(value => !value);
    };
    const onBlur = () => { if (isDriving) setPaused(true); };
    const onFullscreenChange = () => setFullscreen(!!document.fullscreenElement);
    window.addEventListener('keydown', onKeyDown); window.addEventListener('blur', onBlur);
    document.addEventListener('fullscreenchange', onFullscreenChange);
    return () => {
      window.removeEventListener('keydown', onKeyDown); window.removeEventListener('blur', onBlur);
      document.removeEventListener('fullscreenchange', onFullscreenChange);
    };
  }, [cycleCamera, isDriving, panel, paused, resetCar, startDriving, started, tab]);

  function selectTab(next: Tab) {
    setTab(next); setPanel(null); setPaused(false);
    if (next === 'garage') setStarted(false);
  }
  function changeBuild<K extends keyof RallyBuild>(part: K, value: RallyBuild[K]) {
    const next = { ...build, [part]: value }; setBuild(next); writeBuild(next); game.current?.setBuild(next);
  }
  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (root.current?.requestFullscreen) await root.current.requestFullscreen();
      else setNotice('LAYAR PENUH TIDAK DIDUKUNG BROWSER INI');
    } catch { setNotice('LAYAR PENUH TIDAK TERSEDIA'); }
  }
  function touchButton(action: keyof CarInput, label: string, child: ReactNode, className = '') {
    return <button className={`touch-button ${className}`} aria-label={label}
      onPointerDown={event => { event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); game.current?.setTouch(action, true); }}
      onPointerUp={() => game.current?.setTouch(action, false)}
      onPointerCancel={() => game.current?.setTouch(action, false)}
      onLostPointerCapture={() => game.current?.setTouch(action, false)}>{child}</button>;
  }
  const speed = String(telemetry.speed).padStart(3, '0');

  return <div ref={root} className={`rally-app ${isDriving ? 'is-driving' : 'is-showroom'} ${tab === 'garage' ? 'is-garage' : ''}`}>
    <div ref={canvasHost} className={`game-canvas ${ready ? 'canvas-ready' : ''}`} />
    <div className="world-shading" aria-hidden="true" />
    <div className="film-grain" aria-hidden="true" />

    <header className="app-header">
      <button className="brand-home" onClick={() => { setStarted(false); selectTab('arena'); }} aria-label="Rally B, halaman utama"><Brand small /></button>
      <div className="header-divider" />
      <span className="header-caption">GROUP B<br /><b>DRIFT LAB</b></span>
      <nav className="main-nav" aria-label="Navigasi utama">
        <button className={tab === 'arena' && !panel ? 'nav-active' : ''} onClick={() => selectTab('arena')}><span>01</span> ARENA</button>
        <button className={tab === 'garage' && !panel ? 'nav-active' : ''} onClick={() => selectTab('garage')}><span>02</span> GARASI</button>
        <button className={panel === 'guide' ? 'nav-active' : ''} onClick={() => setPanel('guide')}><span>03</span> PANDUAN</button>
      </nav>
      <div className="header-right">
        <span className="live-status"><i /> {ready ? 'SIAP DIMAINKAN' : 'MENYIAPKAN ARENA'}</span>
        <span className="utility-divider" />
        <IconButton label={sound ? 'Matikan suara' : 'Aktifkan suara'} onClick={() => { const next = !sound; setSound(next); game.current?.configure({ sound: next }); }} active={sound}>{sound ? <Volume2 size={18} /> : <VolumeX size={18} />}</IconButton>
        <IconButton label="Pengaturan" onClick={() => setPanel('settings')} active={panel === 'settings'}><Settings2 size={18} /></IconButton>
        <IconButton label={fullscreen ? 'Keluar layar penuh' : 'Layar penuh'} onClick={toggleFullscreen}>{fullscreen ? <Minimize2 size={17} /> : <Maximize2 size={17} />}</IconButton>
      </div>
    </header>

    <main className="arena-main">
      {!isDriving && tab === 'arena' && <section className="intro-copy" aria-labelledby="hero-title">
        <div className="eyebrow enter enter-1"><span /> NO LIMITS. JUST CONTROL.</div>
        <h1 id="hero-title" className="hero-title enter enter-2">RALLY<span>B</span><i>.</i></h1>
        <h2 className="hero-subtitle enter enter-3">GROUP B DRIFT LAB</h2>
        <p className="intro-description enter enter-4">Mesin buas. Tikungan tajam.<br />Sisanya ada di tanganmu.</p>
        <div className="intro-actions enter enter-5">
          <button className="primary-button" onClick={startDriving} disabled={!ready}><Play size={14} fill="currentColor" />{ready ? 'MULAI MENGEMUDI' : 'MENYIAPKAN ARENA'}<ArrowUpRight size={18} /></button>
          <button className="text-button" onClick={() => setPanel('guide')}>Lihat kontrol <ChevronRight size={14} /></button>
        </div>
        <div className="intro-hint enter enter-5"><span className="tiny-key">ENTER</span> untuk langsung masuk arena</div>
      </section>}

      {tab === 'garage' && <section className="garage-copy" aria-labelledby="garage-title">
        <div className="eyebrow"><span /> GROUP B / CONFIGURATOR</div>
        <h1 id="garage-title">GARASI<span>.</span></h1>
        <p>Karakter asli. Sentuhan personal.</p>
        <div className="garage-options">
          <BuildSelector title="01 / BAGIAN DEPAN" part="nose" build={build} onChange={changeBuild} options={[{ value: 'evo', label: 'EVO S1' }, { value: 'classic', label: 'CLASSIC' }]} />
          <BuildSelector title="02 / AERO BELAKANG" part="wing" build={build} onChange={changeBuild} options={[{ value: 'works', label: 'WORKS' }, { value: 'high', label: 'HIGH WING' }]} />
          <BuildSelector title="03 / LIVERY" part="vinyl" build={build} onChange={changeBuild} options={[{ value: 'heritage', label: 'HERITAGE' }, { value: 'rally', label: 'RALLY 12' }]} />
          <div className="paint-row"><span className="build-label">04 / WARNA</span><div className="paint-swatches">
            {([{ value: 'black', color: '#e9e7dd', label: 'Heritage' }, { value: 'blue', color: '#326eae', label: 'Biru' }, { value: 'green', color: '#428267', label: 'Hijau' }] as const).map(paint =>
              <button key={paint.value} style={{ '--paint': paint.color } as React.CSSProperties} className={`paint-swatch ${build.theme === paint.value ? 'selected' : ''}`} onClick={() => changeBuild('theme', paint.value)} aria-label={`Warna ${paint.label}`} aria-pressed={build.theme === paint.value}>{build.theme === paint.value && <Check size={13} />}</button>)}
          </div><span className="paint-name">{build.theme === 'black' ? 'HERITAGE' : build.theme.toUpperCase()}</span></div>
        </div>
        <button className="primary-button garage-drive" onClick={startDriving} disabled={!ready}>BAWA KE ARENA<ArrowUpRight size={18} /></button>
        <span className="autosave"><Check size={11} /> Konfigurasi tersimpan otomatis</span>
      </section>}

      {isDriving && <section className="driving-score" aria-label="Skor drift langsung">
        <div className="eyebrow"><span /> DRIFT SESSION</div>
        <div className="score-label">TOTAL DRIFT SCORE</div>
        <div className="score-number">{formatScore(telemetry.score)}<span>x{telemetry.combo.toFixed(1)}</span></div>
        <div className="best-score">PERSONAL BEST <b>{String(telemetry.best).padStart(6, '0')}</b></div>
        <div className={`drift-live ${telemetry.drifting ? 'drift-live-active' : ''}`}><i /><span>{telemetry.drifting ? 'DRIFTING' : 'SIAP DRIFT'}</span><b>{telemetry.angle}<sup>o</sup></b></div>
      </section>}

      <aside className="course-info">
        <div className="location-label"><MapPin size={12} /><span>THE OPEN TRACK</span></div>
        <h2>SIRKUIT PINUS<span> / 01</span></h2>
        <div className="course-meta">{isDriving ? <><span>LAP {String(telemetry.lap).padStart(2, '0')}</span><b>{formatTime(telemetry.time)}</b></> : <><span>FOREST CIRCUIT</span><i /><span>FREE ROAM</span></>}</div>
        <TrackMap info={trackInfo} x={telemetry.mapX} y={telemetry.mapY} heading={telemetry.heading} active={isDriving} />
      </aside>

      {isDriving && telemetry.message && <div className={`maneuver-message ${telemetry.message.includes('DINDING') ? 'message-crash' : ''}`}><span>{telemetry.message.includes('DINDING') ? 'JAGA KENDALI' : 'KEEP IT SIDEWAYS'}</span><strong>{telemetry.message}</strong></div>}
      <div className="bottom-hud">
        <section className="vehicle-info" aria-label="Mobil terpilih"><span className="vehicle-rule" /><div><span className="vehicle-eyebrow">1986 LEGEND / GROUP B</span><h3>SPORT QUATTRO <span>S1</span></h3><div className="vehicle-detail"><span>{build.nose === 'evo' ? 'EVO BODY' : 'CLASSIC BODY'}</span><i /><span>{build.wing === 'works' ? 'WORKS AERO' : 'HIGH WING'}</span><i /><span>ORIGINAL WHEELS</span></div></div></section>
        <div className="quick-actions">
          <button onClick={cycleCamera}><Key>C</Key><span>KAMERA <b>{cameraNames[camera]}</b></span><ChevronDown size={12} /></button>
          <button onClick={resetCar}><RotateCcw size={13} /><span>RESET MOBIL</span></button>
        </div>
        <section className="speed-hud" aria-label={`Kecepatan ${telemetry.speed} kilometer per jam`}>
          <div className="speed-top"><span><i className={telemetry.handbrake ? 'brake-on' : ''} />{telemetry.handbrake ? 'HANDBRAKE' : 'TELEMETRY / LIVE'}</span><span className="assist">ASSIST ON</span></div>
          <div className="speed-main"><div className="gear"><span>GEAR</span><b>{telemetry.gear}</b></div><div className="speed-digits">{speed.split('').map((digit, index) => <span key={index} className={index < 2 && Number(speed.slice(0, index + 1)) === 0 ? 'leading-zero' : ''}>{digit}</span>)}</div><div className="speed-unit">KM/H<small>{telemetry.angle}<sup>o</sup> SLIP</small></div></div>
          <div className="rev-meter" aria-label="Putaran mesin">{Array.from({ length: 28 }, (_, index) => <i key={index} className={`${index / 28 < telemetry.rev ? 'rev-lit' : ''} ${index > 21 ? 'rev-red' : ''}`} />)}</div>
        </section>
      </div>

      {isDriving && <div className="touch-controls" aria-label="Kontrol sentuh">
        <div className="touch-steer">{touchButton('left', 'Belok kiri', <ArrowLeft />)}{touchButton('right', 'Belok kanan', <ArrowRight />)}</div>
        <div className="touch-pedals">{touchButton('handbrake', 'Handbrake', 'HB', 'touch-hb')}{touchButton('brake', 'Rem dan mundur', <ArrowDown />)}{touchButton('gas', 'Gas', <ArrowUp />, 'touch-gas')}</div>
      </div>}
    </main>

    <footer className="controls-bar">
      <button className="controls-label" onClick={() => setPanel('guide')}><Keyboard size={16} /><span>KONTROL</span></button>
      <div className="control-item"><span><Key>W</Key><Key>S</Key></span><span>Gas / Rem</span></div>
      <div className="control-item"><span><Key>A</Key><Key>D</Key></span><span>Setir</span></div>
      <div className="control-item"><Key accent>SPACE</Key><span>Handbrake</span></div>
      <div className="control-item control-secondary"><Key>C</Key><span>Kamera</span></div>
      <div className="control-item control-secondary"><Key>R</Key><span>Reset</span></div>
      <button className="pause-control" onClick={() => isDriving ? setPaused(true) : setPanel('guide')}><Key>{isDriving ? 'ESC' : 'H'}</Key><span>{isDriving ? 'Jeda' : 'Bantuan'}</span></button>
      <div className="physics-status"><i /><span>REFERENCE PHYSICS<span className="physics-version"> / V.02</span></span></div>
    </footer>

    {notice && <div className="notice" role="status"><Check size={14} />{notice}</div>}
    {error && <div className="error-overlay" role="alert"><Gauge size={35} /><h2>ARENA BELUM TERSEDIA</h2><p>{error}</p><button className="primary-button" onClick={() => location.reload()}>COBA LAGI <RotateCcw size={15} /></button></div>}

    {(panel || paused) && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) { setPanel(null); setPaused(false); } }}>
      <section className={`modal ${paused && !panel ? 'pause-modal' : ''}`} role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-top"><span>RALLY B / {panel === 'settings' ? 'PREFERENCES' : panel === 'guide' ? 'DRIVER MANUAL' : 'SESSION PAUSED'}</span><button ref={closeButton} className="icon-button" aria-label="Tutup dialog" onClick={() => { setPanel(null); setPaused(false); }}><X size={19} /></button></div>
        {panel === 'guide' ? <>
          <div className="modal-title-row"><CircleHelp size={24} /><h2 id="modal-title">KENALI KENDALIMU<span>.</span></h2></div>
          <p className="modal-description">Satu mobil. Satu sirkuit. Tak terbatas cara menikung.</p>
          <div className="guide-controls">
            <div><span>Akselerasi</span><span><Key>W</Key><em>atau</em><Key><ArrowUp size={12} /></Key></span></div>
            <div><span>Rem / Mundur</span><span><Key>S</Key><em>atau</em><Key><ArrowDown size={12} /></Key></span></div>
            <div><span>Setir kiri / kanan</span><span><Key>A</Key><Key>D</Key><em>atau</em><Key><ArrowLeft size={12} /></Key><Key><ArrowRight size={12} /></Key></span></div>
            <div><span>Handbrake</span><Key accent>SPACE</Key></div>
            <div><span>Ganti kamera / Reset / Jeda</span><span><Key>C</Key><Key>R</Key><Key>ESC</Key></span></div>
          </div>
          <div className="drift-tip"><span>PRO TIP / 01</span><p>Tambah kecepatan, belok, lalu ketuk <b>SPACE</b> untuk melepas grip belakang. Lepas handbrake dan lakukan counter-steer untuk menjaga sudut drift.</p></div>
          <div className="source-note">Fisika gerak dari <b>3D Car Drift Simulator (2)</b>.<br />Model mobil, ban, asap, dan sirkuit asli Rally Group B Lab.</div>
          <button className="primary-button modal-cta" onClick={() => { setPanel(null); if (!started && tab === 'arena') startDriving(); }}>SIAP, GAS!<ArrowRight size={17} /></button>
        </> : panel === 'settings' ? <>
          <div className="modal-title-row"><Settings2 size={24} /><h2 id="modal-title">SESUAIKAN SESIMU<span>.</span></h2></div>
          <p className="modal-description">Tampilan dan suara sesuai caramu bermain.</p>
          <div className="settings-list">
            <Toggle label="Suara mesin & ban" description="Suara mesin, gesekan ban, dan angin." checked={sound} onChange={value => { setSound(value); game.current?.configure({ sound: value }); }} />
            <Toggle label="Asap & jejak ban" description="Efek volumetrik asli Rally Group B Lab." checked={smoke} onChange={setSmoke} />
            <label className="setting-row"><span><strong>Kualitas grafis</strong><small>Seimbang untuk performa lebih ringan.</small></span><select value={quality} onChange={event => setQuality(event.target.value as typeof quality)}><option value="high">TINGGI</option><option value="balanced">SEIMBANG</option></select></label>
            <label className="setting-row"><span><strong>Kamera mengemudi</strong><small>Tekan C untuk berpindah saat mengemudi.</small></span><select value={camera} onChange={event => setCamera(event.target.value as CameraMode)}><option value="chase">BELAKANG</option><option value="cockpit">KOKPIT</option><option value="top">ATAS</option></select></label>
          </div>
          <div className="physics-note"><i /><span>FISIKA REFERENSI AKTIF<b>Gas, grip, yaw, dan counter-steer mengikuti ZIP referensi. Tidak ada tuning tambahan.</b></span></div>
          <button className="primary-button modal-cta" onClick={() => setPanel(null)}>SIMPAN & KEMBALI<Check size={17} /></button>
        </> : <>
          <div className="pause-symbol"><Pause size={28} fill="currentColor" /></div>
          <h2 id="modal-title">TARIK NAPAS<span>.</span></h2><p className="modal-description">Sirkuitnya tidak ke mana-mana.</p>
          <div className="pause-session"><span>SKOR SESI<b>{formatScore(telemetry.score)}</b></span><span>WAKTU<b>{formatTime(telemetry.time)}</b></span></div>
          <button className="primary-button modal-cta" onClick={() => setPaused(false)}><Play size={14} fill="currentColor" />LANJUT MENGEMUDI<ArrowRight size={16} /></button>
          <button className="pause-restart" onClick={() => { resetCar(); setPaused(false); }}><RotateCcw size={13} /> MULAI SESI BARU</button>
          <button className="pause-home" onClick={() => { setStarted(false); setPaused(false); }}>Kembali ke arena</button>
        </>}
        <div className="modal-bottom"><Brand small /><span>BUILT TO GO SIDEWAYS.</span><Flag size={13} /></div>
      </section>
    </div>}
  </div>;
}
