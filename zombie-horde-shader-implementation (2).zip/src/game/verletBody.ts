import * as THREE from 'three';
import type { BoxCollider3D } from './compoundBuilder';

/**
 * Generic 16-joint Verlet ragdoll used by the team-match bots.
 * Joint positions (and therefore bone lengths) are taken from the character's LIVE pose at the moment of death,
 * so it works with any skin of the pack. The rig's pivots are then driven from the joints (see teamMatch.ts).
 */
export const JT = {
  PELVIS: 0, HIPB: 1, HIPA: 2, KNEEB: 3, KNEEA: 4, FOOTB: 5, FOOTA: 6, CHEST: 7,
  NECK: 8, HEAD: 9, SHB: 10, SHA: 11, ELBB: 12, ELBA: 13, HANDB: 14, HANDA: 15,
} as const;
export const JN = 16;
const DT = 1 / 60;
const RADIUS = [0.17, 0.09, 0.09, 0.09, 0.09, 0.09, 0.09, 0.17, 0.09, 0.14, 0.09, 0.09, 0.07, 0.07, 0.07, 0.07];
const PAIRS: [number, number][] = [
  [0, 1], [0, 2], [1, 2],
  [0, 7], [7, 8], [0, 8],
  [7, 10], [7, 11], [8, 10], [8, 11], [10, 11],
  [1, 7], [2, 7], [1, 11], [2, 10],
  [8, 9], [7, 9],
  [1, 3], [3, 5], [2, 4], [4, 6], [0, 3], [0, 4],
  [10, 12], [12, 14], [11, 13], [13, 15],
];

/** [root joint, middle joint, end joint]: the end may never come closer to the root than ~36 % of the bone chain (no flat folding) */
const MIN_CHAINS: [number, number, number][] = [
  [JT.HIPA, JT.KNEEA, JT.FOOTA],
  [JT.HIPB, JT.KNEEB, JT.FOOTB],
  [JT.SHA, JT.ELBA, JT.HANDA],
  [JT.SHB, JT.ELBB, JT.HANDB],
];

export interface BodyImpulse {
  dx: number;
  dz: number;
  force: number;
  up: number;
  hitY: number;
}

export class VerletBody {
  public p = new Float32Array(JN * 3);
  public q = new Float32Array(JN * 3);
  public asleep = false;
  public t = 0;
  private acc = 0;
  private rest = 0;
  private gy = new Float32Array(JN);
  private lens: number[];
  private minLens: number[];

  constructor(
    points: THREE.Vector3[],
    private near: BoxCollider3D[],
    private getGround: (x: number, z: number, y: number) => number
  ) {
    for (let i = 0; i < JN; i++) {
      this.p[i * 3] = this.q[i * 3] = points[i].x;
      this.p[i * 3 + 1] = this.q[i * 3 + 1] = points[i].y;
      this.p[i * 3 + 2] = this.q[i * 3 + 2] = points[i].z;
    }
    this.lens = PAIRS.map(([a, b]) => points[a].distanceTo(points[b]));
    this.minLens = MIN_CHAINS.map(([a, m, b]) => 0.36 * (points[a].distanceTo(points[m]) + points[m].distanceTo(points[b])));
  }

  /** inherit running momentum (m/s) */
  public setVelocity(vx: number, vz: number) {
    for (let i = 0; i < JN; i++) {
      this.q[i * 3] = this.p[i * 3] - vx * DT;
      this.q[i * 3 + 2] = this.p[i * 3 + 2] - vz * DT;
    }
  }

  public impulse(f: BodyImpulse) {
    const { p, q } = this;
    for (let i = 0; i < JN; i++) {
      const dyh = (p[i * 3 + 1] - f.hitY) / 0.6;
      const w = 0.4 + 0.6 * Math.exp(-dyh * dyh);
      const v = f.force * w * DT;
      q[i * 3] -= f.dx * v;
      q[i * 3 + 1] -= f.up * v * (0.6 + 0.4 * w);
      q[i * 3 + 2] -= f.dz * v;
    }
    // cartwheel + flailing limbs
    const tw = (Math.random() * 2 - 1) * 0.02 * Math.min(1.6, f.force / 9);
    const px = -f.dz;
    const pz = f.dx;
    const spin = (a: number, b: number, k: number) => {
      q[a * 3] -= px * tw * k;
      q[a * 3 + 2] -= pz * tw * k;
      q[b * 3] += px * tw * k;
      q[b * 3 + 2] += pz * tw * k;
    };
    spin(JT.SHA, JT.SHB, 1);
    spin(JT.HIPA, JT.HIPB, 0.5);
    spin(JT.HANDA, JT.HANDB, 1.2);
    spin(JT.FOOTA, JT.FOOTB, 0.8);
    for (const j of [JT.HANDA, JT.HANDB, JT.FOOTA, JT.FOOTB, JT.ELBA, JT.ELBB, JT.KNEEA, JT.KNEEB]) {
      q[j * 3] -= (Math.random() * 2 - 1) * 0.012;
      q[j * 3 + 1] -= Math.random() * 0.014;
      q[j * 3 + 2] -= (Math.random() * 2 - 1) * 0.012;
    }
  }

  /** @returns true the moment the body comes to rest */
  public step(dt: number): boolean {
    if (this.asleep) return false;
    this.t += dt;
    this.acc += Math.min(dt, 0.05);
    let n = 0;
    let justSlept = false;
    while (this.acc >= DT && n < 3) {
      if (this.sub()) justSlept = true;
      this.acc -= DT;
      n++;
    }
    if (this.t > 6 && !this.asleep) {
      this.asleep = true;
      justSlept = true;
    }
    return justSlept;
  }

  private sub(): boolean {
    const { p, q } = this;
    const grav = -24 * DT * DT;
    let energy = 0;
    for (let i = 0; i < JN; i++) {
      const k = i * 3;
      const vx = (p[k] - q[k]) * 0.993;
      const vy = (p[k + 1] - q[k + 1]) * 0.997;
      const vz = (p[k + 2] - q[k + 2]) * 0.993;
      q[k] = p[k];
      q[k + 1] = p[k + 1];
      q[k + 2] = p[k + 2];
      p[k] += vx;
      p[k + 1] += vy + grav;
      p[k + 2] += vz;
      energy += vx * vx + vy * vy + vz * vz;
      let g = this.getGround(p[k], p[k + 2], Math.max(0, p[k + 1]));
      for (const c of this.near) {
        if (p[k] > c.minX && p[k] < c.maxX && p[k + 2] > c.minZ && p[k + 2] < c.maxZ && c.maxY <= p[k + 1] + 0.55 && c.maxY > g && c.maxY - c.minY < 40) g = c.maxY;
      }
      this.gy[i] = g;
    }
    for (let iter = 0; iter < 5; iter++) {
      for (let l = 0; l < PAIRS.length; l++) {
        const a = PAIRS[l][0] * 3;
        const b = PAIRS[l][1] * 3;
        const dx = p[b] - p[a];
        const dy = p[b + 1] - p[a + 1];
        const dz = p[b + 2] - p[a + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-5;
        const diff = ((dist - this.lens[l]) / dist) * 0.5;
        p[a] += dx * diff;
        p[a + 1] += dy * diff;
        p[a + 2] += dz * diff;
        p[b] -= dx * diff;
        p[b + 1] -= dy * diff;
        p[b + 2] -= dz * diff;
      }
      for (let c = 0; c < MIN_CHAINS.length; c++) {
        const a = MIN_CHAINS[c][0] * 3;
        const b = MIN_CHAINS[c][2] * 3;
        const dx = p[b] - p[a];
        const dy = p[b + 1] - p[a + 1];
        const dz = p[b + 2] - p[a + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-5;
        if (dist < this.minLens[c]) {
          const push = ((this.minLens[c] - dist) / dist) * 0.5;
          p[a] -= dx * push;
          p[a + 1] -= dy * push;
          p[a + 2] -= dz * push;
          p[b] += dx * push;
          p[b + 1] += dy * push;
          p[b + 2] += dz * push;
        }
      }
      for (let i = 0; i < JN; i++) {
        const k = i * 3;
        const rad = RADIUS[i];
        const floor = this.gy[i] + rad;
        if (p[k + 1] < floor) p[k + 1] = floor;
        for (const c of this.near) {
          if (p[k + 1] + rad <= c.minY || p[k + 1] - rad >= c.maxY) continue;
          if (p[k] > c.minX - rad && p[k] < c.maxX + rad && p[k + 2] > c.minZ - rad && p[k + 2] < c.maxZ + rad) {
            const pxl = p[k] - (c.minX - rad);
            const pxr = c.maxX + rad - p[k];
            const pzl = p[k + 2] - (c.minZ - rad);
            const pzr = c.maxZ + rad - p[k + 2];
            const pyt = p[k + 1] > c.maxY - 0.35 ? c.maxY + rad - p[k + 1] : 1e9;
            const m = Math.min(pxl, pxr, pzl, pzr, pyt);
            if (m === pyt) p[k + 1] += pyt;
            else if (m === pxl) p[k] -= pxl;
            else if (m === pxr) p[k] += pxr;
            else if (m === pzl) p[k + 2] -= pzl;
            else p[k + 2] += pzr;
          }
        }
      }
    }
    for (let i = 0; i < JN; i++) {
      const k = i * 3;
      if (p[k + 1] <= this.gy[i] + RADIUS[i] + 0.02) {
        q[k] = p[k] - (p[k] - q[k]) * 0.82;
        q[k + 2] = p[k + 2] - (p[k + 2] - q[k + 2]) * 0.82;
        q[k + 1] = p[k + 1] - (p[k + 1] - q[k + 1]) * 0.2;
      }
    }
    if (energy / JN < 6e-6 && this.t > 0.5) this.rest += DT;
    else this.rest = 0;
    if (this.rest > 0.45) {
      this.asleep = true;
      return true;
    }
    return false;
  }
}
