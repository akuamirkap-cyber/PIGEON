import * as THREE from 'three';
import { buildModularCharacterRig, disposeSubtreeGeometries, updateCharacterAnimation } from '../skins';
import type { CharacterRig } from '../skins/animation';
import type { AnimMode, FaceId, HitZone, SkinId } from '../skins/types';
import { ALL_SKIN_IDS, SKINS_META } from '../skins/types';
import { BotWeapon } from './botPose';
import type { PoseInput } from './botPose';
import type { WeaponRig } from './weaponModels';
import type { BoxCollider3D, CompoundContext } from './compoundBuilder';
import { soundEngine } from './audio';
import { JN, JT, VerletBody } from './verletBody';
import type { BodyImpulse } from './verletBody';
import type { ZombieFx } from './zombieFx';

/**
 * =====================================================================================
 *  TEAM DEATHMATCH 5 v 5   (player + 4 allies  VS  5 enemies) in the Graffiti Compound
 * =====================================================================================
 *  - every fighter is a full rigged character of the skin pack (walk / run / hit-react animations)
 *  - bots fight EACH OTHER (allies vs enemies) and the player — nav-graph pathing, LOS, bursts, strafing
 *  - accurate hit-boxes follow the *rendered* bones (head / chest / pelvis / limbs)
 *  - every death → Verlet ragdoll that drives the character's own pivots (no canned death animation)
 * =====================================================================================
 */

export type Team = 'blue' | 'red';
export type MatchPhase = 'lobby' | 'live' | 'over';

export interface FeedItem {
  id: number;
  killer: string;
  victim: string;
  killerTeam: Team;
  victimTeam: Team;
  headshot: boolean;
  points: number;
  mine: boolean;
}

export interface TdmHud {
  active: boolean;
  phase: MatchPhase;
  blue: number;
  red: number;
  target: number;
  timeLeft: number;
  playerKills: number;
  playerDeaths: number;
  playerStreak: number;
  playerSkin: SkinId;
  feed: FeedItem[];
  winner: Team | null;
  roster: { name: string; team: Team; alive: boolean; hp: number; kills: number; deaths: number; isPlayer: boolean }[];
  protectT: number;
}

export interface TdmContext {
  dt: number;
  camera: THREE.Camera;
  playerPos: THREE.Vector3; // eye position
  playerFootY: number;
  playerAlive: boolean;
  playerProtected: boolean;
  onPlayerHit: (damage: number, from: THREE.Vector3, bot: { id: number; name: string }) => void;
  onShotFx: (muzzle: THREE.Vector3, end: THREE.Vector3) => void;
}

export interface BotHit {
  botId: number;
  zone: 'head' | 'body';
  flinch: HitZone;
  dist: number;
  point: THREE.Vector3;
}

interface Drive {
  node: THREE.Object3D;
  kind: 'torso' | 'head' | 'dir';
  a: number;
  b: number;
  anchor: number;
  q0: THREE.Quaternion;
  pos0: THREE.Vector3;
  anchor0: THREE.Vector3;
  F0: THREE.Quaternion;
}

interface Bot {
  id: number;
  team: Team;
  name: string;
  skin: SkinId;
  face: FaceId;
  rig: CharacterRig | null;
  pending: CharacterRig | null;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  yaw: number;
  hp: number;
  alive: boolean;
  deadT: number;
  respawnT: number;
  lastHitT: number;
  mode: AnimMode;
  elapsed: number;
  phaseOff: number;
  path: number[];
  pathIdx: number;
  repathT: number;
  stuckT: number;
  lastPos: THREE.Vector3;
  targetKey: number; // bot id · -1 player · -2 none
  seen: boolean;
  scanT: number;
  reactT: number;
  lastSeen: THREE.Vector3 | null;
  fireCd: number;
  burst: number;
  burstCd: number;
  strafeDir: number;
  strafeT: number;
  crouchT: number;
  doorT: number;
  stuckN: number;
  // ---- tactics
  ammo: number;
  reloadT: number;
  cover: 0 | 1 | 2 | 3; // none · running to cover · hiding (crouched) · peeking & shooting
  coverPos: THREE.Vector3 | null;
  peekPos: THREE.Vector3 | null;
  coverT: number;
  hideT: number;
  peekT: number;
  coverCd: number;
  hideTotal: number;
  shootPoseT: number;
  // ---- body
  grounded: boolean;
  vy: number;
  landT: number;
  weapon: BotWeapon | null;
  gun: { obj: THREE.Object3D; vel: THREE.Vector3; spin: THREE.Vector3; t: number } | null;
  kills: number;
  deaths: number;
  body: VerletBody | null;
  drives: Drive[];
  ragRoot: THREE.Group | null;
  mark: THREE.Sprite;
  barBg: THREE.Sprite;
  barFill: THREE.Sprite;
}

const RUN = 4.4;
const WALK = 1.9;
const BLUE_SPAWNS: [number, number][] = [[-5.5, 22.5], [-2.8, 24.5], [2.8, 24.5], [5.5, 22.5], [0, 21.5]];
const RED_SPAWNS: [number, number][] = [[-14.2, -12.3], [-5.2, -12.6], [0, -12.6], [5.2, -12.6], [14.2, -12.3]];
const ALLY_NAMES = ['Rex', 'Kilo', 'Vega', 'Nova'];
const ENEMY_NAMES = ['Viper', 'Havoc', 'Raven', 'Ghost', 'Titan'];
// bots use the skins whose arms can be posed on the rifle (the 'skill' pistol-only skin stays player-only)
const SKIN_PICK_ORDER: SkinId[] = ['police', 'gunner', 'boonie', 'spetsnaz', 'gold', 'reaper', 'venom', 'silat'];

function rnd(a: number, b: number) {
  return a + Math.random() * (b - a);
}

function markerTexture(color: string) {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  g.fillStyle = color;
  g.strokeStyle = 'rgba(0,0,0,0.85)';
  g.lineWidth = 5;
  g.beginPath();
  g.moveTo(8, 12);
  g.lineTo(56, 12);
  g.lineTo(32, 54);
  g.closePath();
  g.stroke();
  g.fill();
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _q1 = new THREE.Quaternion();
const _q2 = new THREE.Quaternion();
const _m4 = new THREE.Matrix4();
const _DOWN = new THREE.Vector3(0, -1, 0);

export class TeamMatchManager {
  public phase: MatchPhase = 'lobby';
  public winner: Team | null = null;
  public blue = 0;
  public red = 0;
  public readonly target = 40;
  public timeLeft = 480;
  public playerSkin: SkinId = 'police';
  public playerFace: FaceId = 'cool';
  public player = { kills: 0, deaths: 0, streak: 0, protectT: 0 };
  public feed: FeedItem[] = [];

  private bots: Bot[] = [];
  private nextId = 1;
  private feedId = 1;
  private ray = new THREE.Raycaster();
  private time = 0;
  private shotSoundBudget = 0;
  private tex = { blue: markerTexture('#3b9dff'), red: markerTexture('#ff4545') };
  private mats: Record<string, THREE.SpriteMaterial> = {};
  private rifle: WeaponRig | null = null;
  /** Dead-Island style blood (set by the engine) */
  public fx: ZombieFx | null = null;
  private weapons = new WeakMap<CharacterRig, BotWeapon>();

  /** the player's own rifle model: bots clone it so they hold the very same weapon */
  public setRifle(r: WeaponRig) {
    this.rifle = r;
  }

  constructor(
    private scene: THREE.Scene,
    private compound: CompoundContext,
    private colliders: BoxCollider3D[]
  ) {
    this.mats.blueAlly = new THREE.SpriteMaterial({ map: this.tex.blue, depthTest: false, transparent: true });
    this.mats.redMark = new THREE.SpriteMaterial({ map: this.tex.red, depthTest: true, transparent: true });
    this.mats.barBg = new THREE.SpriteMaterial({ color: 0x000000, opacity: 0.65, transparent: true, depthTest: false });
    this.mats.barBlue = new THREE.SpriteMaterial({ color: 0x4aa8ff, depthTest: false, transparent: true });
    this.mats.barRed = new THREE.SpriteMaterial({ color: 0xff5555, depthTest: false, transparent: true });
  }

  // ===========================================================================
  //  LIFECYCLE
  // ===========================================================================
  public start(skin: SkinId, face: FaceId) {
    this.stop();
    this.playerSkin = skin;
    this.playerFace = face;
    this.blue = 0;
    this.red = 0;
    this.timeLeft = 480;
    this.winner = null;
    this.feed = [];
    this.player = { kills: 0, deaths: 0, streak: 0, protectT: 2.0 };
    this.phase = 'live';

    const pool = SKIN_PICK_ORDER.filter((s) => s !== skin);
    const allies = pool.slice(0, 4);
    const enemies = pool.slice(4);
    while (enemies.length < 5) enemies.push(pool[(enemies.length * 3) % pool.length]);
    allies.forEach((s, i) => this.addBot('blue', ALLY_NAMES[i], s, i));
    enemies.slice(0, 5).forEach((s, i) => this.addBot('red', ENEMY_NAMES[i], s, i));
  }

  public stop() {
    for (const b of this.bots) this.removeBot(b);
    this.bots = [];
    this.phase = 'lobby';
  }

  private addBot(team: Team, name: string, skin: SkinId, idx: number) {
    const mark = new THREE.Sprite(team === 'blue' ? this.mats.blueAlly : this.mats.redMark);
    mark.scale.set(0.3, 0.3, 1);
    const barBg = new THREE.Sprite(this.mats.barBg);
    barBg.scale.set(0.62, 0.075, 1);
    const barFill = new THREE.Sprite(team === 'blue' ? this.mats.barBlue : this.mats.barRed);
    barFill.center.set(0, 0.5);
    barFill.scale.set(0.58, 0.05, 1);
    for (const s of [mark, barBg, barFill]) {
      s.visible = false;
      s.userData.isFx = true;
      s.raycast = () => {};
      this.scene.add(s);
    }
    barBg.renderOrder = 10;
    barFill.renderOrder = 11;
    const faces: FaceId[] = ['grin', 'smirk', 'fierce', 'cool', 'neutral'];
    const bot: Bot = {
      id: this.nextId++,
      team,
      name,
      skin,
      face: faces[(idx + (team === 'red' ? 2 : 0)) % faces.length],
      rig: null,
      pending: null,
      pos: new THREE.Vector3(),
      vel: new THREE.Vector3(),
      yaw: team === 'blue' ? Math.PI : 0,
      hp: 100,
      alive: false,
      deadT: 0,
      respawnT: 0.2 + idx * 0.25,
      lastHitT: 99,
      mode: 'idle',
      elapsed: Math.random() * 10,
      phaseOff: Math.random() * 3,
      path: [],
      pathIdx: 0,
      repathT: 0,
      stuckT: 0,
      lastPos: new THREE.Vector3(),
      targetKey: -2,
      seen: false,
      scanT: Math.random() * 0.2,
      reactT: 0,
      lastSeen: null,
      fireCd: 0,
      burst: 0,
      burstCd: 0,
      strafeDir: Math.random() < 0.5 ? -1 : 1,
      strafeT: 1,
      crouchT: 0,
      doorT: 0,
      stuckN: 0,
      ammo: 30,
      reloadT: 0,
      cover: 0,
      coverPos: null,
      peekPos: null,
      coverT: 0,
      hideT: 0,
      peekT: 0,
      coverCd: 2 + Math.random() * 3,
      hideTotal: 0,
      shootPoseT: 0,
      grounded: true,
      vy: 0,
      landT: 0,
      weapon: null,
      gun: null,
      kills: 0,
      deaths: 0,
      body: null,
      drives: [],
      ragRoot: null,
      mark,
      barBg,
      barFill,
    };
    this.bots.push(bot);
  }

  private removeBot(b: Bot) {
    this.cleanupCorpse(b);
    b.weapon?.detach();
    if (b.rig) {
      this.scene.remove(b.rig.root);
      disposeSubtreeGeometries(b.rig.root);
      b.rig = null;
    }
    if (b.pending) {
      disposeSubtreeGeometries(b.pending.root);
      b.pending = null;
    }
    for (const s of [b.mark, b.barBg, b.barFill]) this.scene.remove(s);
  }

  private cleanupCorpse(b: Bot) {
    if (b.gun) {
      this.scene.remove(b.gun.obj);
      b.gun = null;
    }
    if (b.ragRoot) {
      this.scene.remove(b.ragRoot);
      disposeSubtreeGeometries(b.ragRoot);
      b.ragRoot = null;
    }
    if (b.rig && !b.alive) {
      this.scene.remove(b.rig.root);
      disposeSubtreeGeometries(b.rig.root);
      b.rig = null;
    }
    b.body = null;
    b.drives = [];
  }

  private buildRig(b: Bot): CharacterRig {
    const rig = buildModularCharacterRig(
      { head: b.skin, face: b.face, torso: b.skin, pants: b.skin, shoes: b.skin },
      b.id
    );
    this.weapons.set(rig, new BotWeapon(rig, this.rifle));
    rig.root.traverse((o) => {
      o.userData.isFx = true;
    });
    return rig;
  }

  private spawn(b: Bot) {
    const list = b.team === 'blue' ? BLUE_SPAWNS : RED_SPAWNS;
    let best = list[Math.floor(Math.random() * list.length)];
    // prefer the spawn farthest from living enemies
    let bestScore = -1;
    for (const s of list) {
      let nearest = 999;
      for (const o of this.bots) if (o.alive && o.team !== b.team) nearest = Math.min(nearest, Math.hypot(o.pos.x - s[0], o.pos.z - s[1]));
      const sc = nearest + Math.random() * 6;
      if (sc > bestScore) {
        bestScore = sc;
        best = s;
      }
    }
    b.pos.set(best[0] + rnd(-0.8, 0.8), 0, best[1] + rnd(-0.8, 0.8));
    b.pos.y = this.compound.getFloorHeight(b.pos.x, b.pos.z, 0);
    b.vel.set(0, 0, 0);
    b.hp = 100;
    b.alive = true;
    b.deadT = 0;
    b.targetKey = -2;
    b.seen = false;
    b.path = [];
    b.lastSeen = null;
    b.yaw = b.team === 'blue' ? Math.PI : 0;
    const rig = b.pending ?? this.buildRig(b);
    b.pending = null;
    b.rig = rig;
    b.weapon = this.weapons.get(rig) ?? null;
    b.ammo = 30;
    b.reloadT = 0;
    b.cover = 0;
    b.coverPos = null;
    b.peekPos = null;
    b.coverCd = 2 + Math.random() * 3;
    b.grounded = true;
    b.vy = 0;
    b.shootPoseT = 0;
    rig.root.position.copy(b.pos);
    rig.root.rotation.y = b.yaw;
    this.scene.add(rig.root);
    b.mark.visible = true;
  }

  public getPlayerSpawn(): THREE.Vector3 {
    const s = BLUE_SPAWNS[Math.floor(Math.random() * BLUE_SPAWNS.length)];
    return new THREE.Vector3(s[0] + rnd(-1, 1), 0, s[1] + rnd(-1, 1));
  }

  // ===========================================================================
  //  HIT DETECTION — spheres glued to the rendered bones
  // ===========================================================================
  private probes(b: Bot): { c: THREE.Vector3; r: number; zone: 'head' | 'body'; flinch: HitZone }[] {
    const rig = b.rig!;
    rig.root.updateMatrixWorld(true);
    const out: { c: THREE.Vector3; r: number; zone: 'head' | 'body'; flinch: HitZone }[] = [];
    out.push({ c: rig.headPivot.localToWorld(new THREE.Vector3(0, 0.17, 0.01)), r: 0.2, zone: 'head', flinch: 'head' });
    out.push({ c: rig.upperBodyPivot.localToWorld(new THREE.Vector3(0, 0.34, 0)), r: 0.3, zone: 'body', flinch: 'chest' });
    out.push({ c: rig.upperBodyPivot.localToWorld(new THREE.Vector3(0, 0.0, 0)), r: 0.27, zone: 'body', flinch: 'chest' });
    for (const [leg, zone] of [[rig.leftLeg, 'leftLeg'], [rig.rightLeg, 'rightLeg']] as const) {
      const hip = leg.hipPivot.getWorldPosition(new THREE.Vector3());
      const knee = leg.kneePivot.getWorldPosition(new THREE.Vector3());
      const ank = leg.anklePivot.getWorldPosition(new THREE.Vector3());
      out.push({ c: hip.clone().lerp(knee, 0.5), r: 0.17, zone: 'body', flinch: zone });
      out.push({ c: knee.clone().lerp(ank, 0.55), r: 0.15, zone: 'body', flinch: zone });
    }
    for (const [pv, zone] of [[rig.leftArmPivot, 'leftArm'], [rig.rightArmPivot, 'rightArm']] as const) {
      if (pv) out.push({ c: pv.localToWorld(new THREE.Vector3(0, -0.2, 0.05)), r: 0.13, zone: 'body', flinch: zone });
    }
    return out;
  }

  /** player bullets vs ENEMY team (no friendly fire) */
  public raycast(origin: THREE.Vector3, dir: THREE.Vector3, maxDist: number): BotHit | null {
    let best: BotHit | null = null;
    for (const b of this.bots) {
      if (!b.alive || !b.rig || b.team !== 'red') continue;
      const dx = b.pos.x - origin.x;
      const dz = b.pos.z - origin.z;
      const proj = dx * dir.x + dz * dir.z;
      if (proj < -2 || proj > maxDist + 2) continue;
      for (const pr of this.probes(b)) {
        _v1.copy(pr.c).sub(origin);
        const tc = _v1.dot(dir);
        if (tc < 0 || tc > (best ? best.dist : maxDist)) continue;
        const d2 = _v1.lengthSq() - tc * tc;
        if (d2 > pr.r * pr.r) continue;
        const t = tc - Math.sqrt(pr.r * pr.r - d2);
        const tt = Math.max(0, t);
        if (!best || tt < best.dist || (pr.zone === 'head' && tt < best.dist + 0.25 && best.botId === b.id)) {
          best = { botId: b.id, zone: pr.zone, flinch: pr.flinch, dist: tt, point: origin.clone().addScaledVector(dir, tt) };
        }
      }
    }
    return best;
  }

  /** @returns kill info (or null when the bot was already dead) */
  public damageBot(
    id: number,
    dmg: number,
    hit: { zone: 'head' | 'body'; flinch: HitZone; point: THREE.Vector3 },
    fromPos: THREE.Vector3,
    attacker: { name: string; team: Team; isPlayer: boolean } | null
  ): { killed: boolean; name: string; headshot: boolean } | null {
    const b = this.bots.find((o) => o.id === id);
    if (!b || !b.alive || !b.rig || this.phase !== 'live') return null;
    const headshot = hit.zone === 'head';
    b.hp -= headshot ? Math.max(dmg * 2.6, 70) : dmg;
    b.lastHitT = 0;
    {
      const bd = new THREE.Vector3(b.pos.x - fromPos.x, 0.12, b.pos.z - fromPos.z).normalize();
      this.fx?.bloodHit(hit.point, bd, b.hp <= 0, headshot);
    }
    if (b.hp > 0) {
      const c = b.rig.combat;
      c.activeHitZone = hit.flinch;
      c.hitTimer = 0;
      c.hitDuration = 0.8;
      c.hitDirSign *= -1;
      c.hitFlashTimer = 0.14;
      return { killed: false, name: b.name, headshot };
    }
    // ------------- death
    const dx = b.pos.x - fromPos.x;
    const dz = b.pos.z - fromPos.z;
    const dl = Math.hypot(dx, dz) || 1;
    this.kill(
      b,
      {
        dx: dx / dl,
        dz: dz / dl,
        force: 12.5 + dmg * 0.1 + (headshot ? 3 : 0),
        up: headshot ? 0.42 : 0.3,
        hitY: hit.point.y,
      },
      headshot
    );
    let points = 0;
    if (attacker) {
      if (attacker.team === 'blue') this.blue++;
      else this.red++;
      if (attacker.isPlayer) {
        this.player.kills++;
        this.player.streak++;
        points = 100 + (headshot ? 50 : 0) + Math.min(100, (this.player.streak - 1) * 20);
      } else {
        const k = this.bots.find((o) => o.name === attacker.name);
        if (k) k.kills++;
      }
      this.pushFeed(attacker.name, b.name, attacker.team, b.team, headshot, points, attacker.isPlayer);
      this.checkEnd();
    }
    return { killed: true, name: b.name, headshot };
  }

  public playerKilledBy(bot: { id: number; name: string }) {
    const b = this.bots.find((o) => o.id === bot.id);
    this.player.deaths++;
    this.player.streak = 0;
    this.red++;
    if (b) b.kills++;
    this.pushFeed(bot.name, 'KAMU', 'red', 'blue', false, 0, false);
    this.checkEnd();
  }

  private pushFeed(killer: string, victim: string, kt: Team, vt: Team, headshot: boolean, points: number, mine: boolean) {
    this.feed.push({ id: this.feedId++, killer, victim, killerTeam: kt, victimTeam: vt, headshot, points, mine });
    if (this.feed.length > 6) this.feed.shift();
  }

  private checkEnd() {
    if (this.phase !== 'live') return;
    if (this.blue >= this.target || this.red >= this.target) {
      this.phase = 'over';
      this.winner = this.blue >= this.red ? 'blue' : 'red';
    }
  }

  // ===========================================================================
  //  RAGDOLL
  // ===========================================================================
  private extractJoints(b: Bot): THREE.Vector3[] {
    const rig = b.rig!;
    rig.root.updateMatrixWorld(true);
    const xw = _v1.set(1, 0, 0).transformDirection(rig.root.matrixWorld).clone();
    const origin = rig.root.getWorldPosition(new THREE.Vector3());
    const w = (o: THREE.Object3D, off?: THREE.Vector3) => (off ? o.localToWorld(off.clone()) : o.getWorldPosition(new THREE.Vector3()));
    const side = (p: THREE.Vector3) => _v2.copy(p).sub(origin).dot(xw) > 0;

    const pts: THREE.Vector3[] = new Array(JN);
    pts[JT.PELVIS] = w(rig.hipsPivot);
    const pairs = (l: THREE.Vector3, r: THREE.Vector3, ia: number, ib: number) => {
      if (side(l)) {
        pts[ia] = l;
        pts[ib] = r;
      } else {
        pts[ia] = r;
        pts[ib] = l;
      }
    };
    const hipL = w(rig.leftLeg.hipPivot);
    const hipR = w(rig.rightLeg.hipPivot);
    const kneeL = w(rig.leftLeg.kneePivot);
    const kneeR = w(rig.rightLeg.kneePivot);
    const footL = w(rig.leftLeg.anklePivot);
    const footR = w(rig.rightLeg.anklePivot);
    pairs(hipL, hipR, JT.HIPA, JT.HIPB);
    pairs(kneeL, kneeR, JT.KNEEA, JT.KNEEB);
    pairs(footL, footR, JT.FOOTA, JT.FOOTB);
    pts[JT.CHEST] = w(rig.upperBodyPivot, new THREE.Vector3(0, 0.3, 0));
    pts[JT.NECK] = w(rig.headPivot);
    pts[JT.HEAD] = w(rig.headPivot, new THREE.Vector3(0, 0.2, 0.02));
    const chest = pts[JT.CHEST];
    const fb = (pv: THREE.Object3D | null, sd: number) => (pv ? w(pv) : chest.clone().addScaledVector(xw, 0.2 * sd).add(new THREE.Vector3(0, 0.2, 0)));
    const shL = fb(rig.leftArmPivot, -1);
    const shR = fb(rig.rightArmPivot, 1);
    const elL = rig.leftElbowPivot ? w(rig.leftElbowPivot) : shL.clone().add(new THREE.Vector3(0, -0.27, 0.05));
    const elR = rig.rightElbowPivot ? w(rig.rightElbowPivot) : shR.clone().add(new THREE.Vector3(0, -0.27, 0.05));
    const haL = rig.leftArmIK?.handGroup ? w(rig.leftArmIK.handGroup) : elL.clone().add(new THREE.Vector3(0, -0.25, 0.12));
    const haR = rig.rightArmIK?.handGroup ? w(rig.rightArmIK.handGroup) : elR.clone().add(new THREE.Vector3(0, -0.25, 0.12));
    pairs(shL, shR, JT.SHA, JT.SHB);
    pairs(elL, elR, JT.ELBA, JT.ELBB);
    pairs(haL, haR, JT.HANDA, JT.HANDB);
    return pts;
  }

  private frameFor(body: VerletBody, d: { kind: 'torso' | 'head' | 'dir'; a: number; b: number }, out: THREE.Quaternion) {
    const p = body.p;
    const get = (i: number, v: THREE.Vector3) => v.set(p[i * 3], p[i * 3 + 1], p[i * 3 + 2]);
    if (d.kind === 'dir') {
      get(d.b, _v1).sub(get(d.a, _v2)).normalize();
      return out.setFromUnitVectors(_DOWN, _v1);
    }
    // side vector from the shoulders
    const side = new THREE.Vector3();
    get(JT.SHA, side).sub(get(JT.SHB, _v2));
    const up = new THREE.Vector3();
    if (d.kind === 'torso') get(JT.NECK, up).sub(get(JT.PELVIS, _v2));
    else get(JT.HEAD, up).sub(get(JT.NECK, _v2));
    up.normalize();
    side.addScaledVector(up, -side.dot(up));
    if (side.lengthSq() < 1e-6) side.set(1, 0, 0);
    side.normalize();
    const fwd = new THREE.Vector3().crossVectors(side, up);
    _m4.makeBasis(side, up, fwd);
    return out.setFromRotationMatrix(_m4);
  }

  private kill(b: Bot, imp: BodyImpulse, headshot = false) {
    const rig = b.rig!;
    b.alive = false;
    b.deadT = 0;
    b.respawnT = 4.6;
    b.deaths++;
    b.mark.visible = false;
    b.barBg.visible = false;
    b.barFill.visible = false;
    const droppedGun = b.weapon?.releaseGun(this.scene) ?? null;
    if (droppedGun) {
      b.gun = {
        obj: droppedGun,
        vel: new THREE.Vector3(b.vel.x * 0.6 + (Math.random() - 0.5) * 2, 2.6 + Math.random() * 1.6, b.vel.z * 0.6 + (Math.random() - 0.5) * 2),
        spin: new THREE.Vector3((Math.random() - 0.5) * 9, (Math.random() - 0.5) * 9, (Math.random() - 0.5) * 9),
        t: 0,
      };
    }
    const pts = this.extractJoints(b);
    const near = this.colliders.filter((c) => !c.disabled && b.pos.x > c.minX - 7 && b.pos.x < c.maxX + 7 && b.pos.z > c.minZ - 7 && b.pos.z < c.maxZ + 7);
    const level = b.pos.y;
    const body = new VerletBody(pts, near, (x, z, y) => this.compound.getFloorHeight(x, z, Math.min(Math.max(0, y), level + 0.25)));
    body.setVelocity(b.vel.x * 0.5, b.vel.z * 0.5);
    body.impulse(imp);
    b.body = body;
    // the body keeps bleeding while it tumbles (neck gusher after a headshot) and leaves a pool where it settles
    if (this.fx) {
      const key = b.id * 1000 + b.deaths;
      const joint = (j: number) => (pos: THREE.Vector3, vel: THREE.Vector3) => {
        if (!b.body || b.alive) return false;
        const P = b.body.p;
        const Q = b.body.q;
        pos.set(P[j * 3], P[j * 3 + 1], P[j * 3 + 2]);
        vel.set((P[j * 3] - Q[j * 3]) * 60, (P[j * 3 + 1] - Q[j * 3 + 1]) * 60, (P[j * 3 + 2] - Q[j * 3 + 2]) * 60);
        return true;
      };
      if (headshot) this.fx.bleed(key, 'neck', 2.4, joint(JT.NECK));
      this.fx.bleed(key + 500, 'trail', 1.7, joint(JT.PELVIS));
    }

    // ---- detach the articulated pieces and let the joints drive them
    const ragRoot = new THREE.Group();
    ragRoot.name = 'ragdoll';
    this.scene.add(ragRoot);
    b.ragRoot = ragRoot;
    const specs: { node: THREE.Object3D | null; kind: 'torso' | 'head' | 'dir'; a: number; b: number; anchor: number }[] = [
      { node: rig.hipsPivot, kind: 'torso', a: 0, b: 0, anchor: JT.PELVIS },
      { node: rig.upperBodyPivot, kind: 'torso', a: 0, b: 0, anchor: JT.PELVIS },
      { node: rig.headPivot, kind: 'head', a: 0, b: 0, anchor: JT.NECK },
    ];
    const sideA = (pv: THREE.Object3D) => {
      const origin = rig.root.getWorldPosition(new THREE.Vector3());
      const xw = new THREE.Vector3(1, 0, 0).transformDirection(rig.root.matrixWorld);
      return pv.getWorldPosition(new THREE.Vector3()).sub(origin).dot(xw) > 0;
    };
    const legSpec = (leg: CharacterRig['leftLeg']) => {
      const A = sideA(leg.hipPivot);
      specs.push({ node: leg.hipPivot, kind: 'dir', a: A ? JT.HIPA : JT.HIPB, b: A ? JT.KNEEA : JT.KNEEB, anchor: A ? JT.HIPA : JT.HIPB });
      specs.push({ node: leg.kneePivot, kind: 'dir', a: A ? JT.KNEEA : JT.KNEEB, b: A ? JT.FOOTA : JT.FOOTB, anchor: A ? JT.KNEEA : JT.KNEEB });
    };
    legSpec(rig.leftLeg);
    legSpec(rig.rightLeg);
    const armSpec = (sh: THREE.Object3D | null, el: THREE.Object3D | null) => {
      if (!sh || !el) return;
      const A = sideA(sh);
      specs.push({ node: sh, kind: 'dir', a: A ? JT.SHA : JT.SHB, b: A ? JT.ELBA : JT.ELBB, anchor: A ? JT.SHA : JT.SHB });
      specs.push({ node: el, kind: 'dir', a: A ? JT.ELBA : JT.ELBB, b: A ? JT.HANDA : JT.HANDB, anchor: A ? JT.ELBA : JT.ELBB });
    };
    armSpec(rig.leftArmPivot, rig.leftElbowPivot);
    armSpec(rig.rightArmPivot, rig.rightElbowPivot);

    const anchorPos = (i: number, v: THREE.Vector3) => v.set(body.p[i * 3], body.p[i * 3 + 1], body.p[i * 3 + 2]);
    // frames at the moment of death (computed BEFORE re-parenting, from the same joints)
    const F0s = specs.map((sp) => this.frameFor(body, sp, new THREE.Quaternion()));
    specs.forEach((sp, i) => {
      if (!sp.node) return;
      ragRoot.attach(sp.node);
      b.drives.push({
        node: sp.node,
        kind: sp.kind,
        a: sp.a,
        b: sp.b,
        anchor: sp.anchor,
        q0: sp.node.quaternion.clone(),
        pos0: sp.node.position.clone(),
        anchor0: anchorPos(sp.anchor, new THREE.Vector3()),
        F0: F0s[i],
      });
    });
  }

  private poseRagdoll(b: Bot) {
    const body = b.body!;
    const anchor = _v1;
    for (const d of b.drives) {
      this.frameFor(body, d, _q1);
      _q2.copy(d.F0).invert();
      _q1.multiply(_q2); // D = Fnew * F0^-1
      d.node.quaternion.copy(_q1).multiply(d.q0);
      anchor.set(body.p[d.anchor * 3], body.p[d.anchor * 3 + 1], body.p[d.anchor * 3 + 2]);
      d.node.position.copy(d.pos0).sub(d.anchor0).applyQuaternion(_q1).add(anchor);
    }
  }

  // ===========================================================================
  //  UPDATE
  // ===========================================================================
  public update(ctx: TdmContext) {
    if (this.phase === 'lobby') return;
    const dt = Math.min(ctx.dt, 0.05);
    this.time += dt;
    this.shotSoundBudget = Math.min(6, this.shotSoundBudget + dt * 12);
    this.player.protectT = Math.max(0, this.player.protectT - dt);
    if (this.phase === 'live') {
      this.timeLeft = Math.max(0, this.timeLeft - dt);
      if (this.timeLeft <= 0) {
        this.phase = 'over';
        this.winner = this.blue >= this.red ? 'blue' : 'red';
      }
    }
    const live = this.phase === 'live';
    const camRight = _v2.set(1, 0, 0).applyQuaternion(ctx.camera.quaternion).clone();

    for (const b of this.bots) {
      b.lastHitT += dt;
      if (!b.alive) {
        this.updateDead(b, dt, live);
        continue;
      }
      this.updateAlive(b, ctx, dt, live);
      this.updateBars(b, camRight);
    }
  }

  private updateDead(b: Bot, dt: number, live: boolean) {
    b.deadT += dt;
    if (b.gun && b.gun.t < 3) {
      const g = b.gun;
      g.t += dt;
      g.vel.y -= 14 * dt;
      g.obj.position.addScaledVector(g.vel, dt);
      const fl = this.compound.getFloorHeight(g.obj.position.x, g.obj.position.z, Math.min(b.pos.y + 0.5, g.obj.position.y)) + 0.05;
      if (g.obj.position.y < fl) {
        g.obj.position.y = fl;
        g.vel.y = Math.abs(g.vel.y) * 0.3;
        g.vel.x *= 0.6;
        g.vel.z *= 0.6;
        g.spin.multiplyScalar(0.5);
      }
      g.obj.rotation.x += g.spin.x * dt;
      g.obj.rotation.y += g.spin.y * dt;
      g.obj.rotation.z += g.spin.z * dt;
    }
    b.respawnT -= dt;
    if (b.body) {
      const slept = b.body.step(dt);
      if (slept || !b.body.asleep || b.deadT < 6) this.poseRagdoll(b);
      if (slept && this.fx) this.fx.pool(b.body.p[0], this.compound.getFloorHeight(b.body.p[0], b.body.p[2], Math.min(b.pos.y + 0.5, b.body.p[1])), b.body.p[2], 1);
    }
    // pre-build the next body a moment before respawn (avoids a hitch at the spawn instant)
    if (!b.pending && b.respawnT < 1.6 && live) b.pending = this.buildRig(b);
    if (b.deadT > 5.2 && b.ragRoot) this.cleanupCorpse(b);
    if (b.respawnT <= 0 && live && !b.ragRoot) this.spawn(b);
  }

  private updateBars(b: Bot, camRight: THREE.Vector3) {
    const showBar = b.team === 'blue' || b.lastHitT < 2.6;
    const head = _v1.copy(b.pos).add(_v2.set(0, 2.05, 0));
    b.mark.position.copy(head).add(_v2.set(0, 0.3, 0));
    b.mark.visible = true;
    b.barBg.visible = b.barFill.visible = showBar;
    if (showBar) {
      b.barBg.position.copy(head).addScaledVector(camRight, 0.0);
      b.barFill.position.copy(head).addScaledVector(camRight, -0.29);
      b.barFill.scale.x = Math.max(0.001, 0.58 * (b.hp / 100));
    }
  }

  private eye(b: Bot, out: THREE.Vector3) {
    return out.set(b.pos.x, b.pos.y + 1.5, b.pos.z);
  }

  private hasLos(from: THREE.Vector3, to: THREE.Vector3): boolean {
    _v1.copy(to).sub(from);
    const d = _v1.length();
    if (d < 0.6) return true;
    if (d > 62) return false;
    _v1.divideScalar(d);
    this.ray.set(from, _v1);
    this.ray.far = d - 0.4;
    return this.ray.intersectObjects(this.compound.losMeshes, false).length === 0;
  }

  private updateAlive(b: Bot, ctx: TdmContext, dt: number, live: boolean) {
    const rig = b.rig!;
    b.elapsed += dt;
    b.fireCd = Math.max(0, b.fireCd - dt);
    b.burstCd = Math.max(0, b.burstCd - dt);
    b.reactT = Math.max(0, b.reactT - dt);
    b.crouchT = Math.max(0, b.crouchT - dt);
    b.shootPoseT = Math.max(0, b.shootPoseT - dt);
    b.landT = Math.max(0, b.landT - dt);
    b.coverCd = Math.max(0, b.coverCd - dt);
    b.scanT -= dt;
    b.repathT -= dt;
    b.doorT -= dt;
    b.coverT -= dt;
    if (b.reloadT > 0) {
      b.reloadT -= dt;
      if (b.reloadT <= 0) b.ammo = 30;
    }
    // out of ammo → reload right away (even while sprinting to cover, like a pro)
    if (b.ammo <= 0 && b.reloadT <= 0) b.reloadT = 1.3;
    // wounded bots recover while they stay out of the fight
    if (b.lastHitT > 3.2 && b.hp < 100) b.hp = Math.min(100, b.hp + (b.cover === 2 ? 12 : 4) * dt);

    // ---------------- perception
    if (live && b.scanT <= 0) {
      b.scanT = 0.18 + Math.random() * 0.08;
      this.scan(b, ctx);
    }
    const tgt = live ? this.targetPoint(b, ctx) : null;
    const tp = tgt ? tgt.clone() : null;
    const seen = !!tp && b.seen;
    let dist = 0;
    let tdx = 0;
    let tdz = 0;
    if (tp && seen) {
      tdx = tp.x - b.pos.x;
      tdz = tp.z - b.pos.z;
      dist = Math.hypot(tdx, tdz);
    }

    // ---------------- tactical state machine: run to cover · hide (crouch, reload, heal) · peek & shoot
    if (live) this.tactics(b, ctx, tp, seen, dist, dt);

    let wantSpeed = 0;
    let moveDir: THREE.Vector3 | null = null;
    let faceYaw: number | null = null;

    if (b.cover === 1 && b.coverPos) {
      // sprint for cover (shortest route along the nav graph, final approach straight in)
      const dx = b.coverPos.x - b.pos.x;
      const dz = b.coverPos.z - b.pos.z;
      const d = Math.hypot(dx, dz);
      moveDir = d < 2.2 ? new THREE.Vector3(dx / d, 0, dz / d) : this.pathDir(b, b.coverPos);
      wantSpeed = RUN;
      if (moveDir) faceYaw = Math.atan2(moveDir.x, moveDir.z);
    } else if (b.cover === 2) {
      // hiding: crouched behind cover, eyes on where the enemy is
      b.crouchT = Math.max(b.crouchT, 0.3);
      const look = tp ?? b.lastSeen;
      if (look) faceYaw = Math.atan2(look.x - b.pos.x, look.z - b.pos.z);
    } else if (b.cover === 3) {
      // peeking: step out to the firing spot, shoulder the rifle and shoot
      if (b.peekPos) {
        const dx = b.peekPos.x - b.pos.x;
        const dz = b.peekPos.z - b.pos.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.25) {
          moveDir = new THREE.Vector3(dx / d, 0, dz / d);
          wantSpeed = WALK * 1.1;
        }
      }
      const look = tp ?? b.lastSeen;
      if (look) faceYaw = Math.atan2(look.x - b.pos.x, look.z - b.pos.z);
    } else if (tp && seen) {
      faceYaw = Math.atan2(tdx, tdz);
      b.strafeT -= dt;
      if (b.strafeT <= 0) {
        b.strafeT = rnd(0.7, 1.7);
        b.strafeDir = Math.random() < 0.5 ? -1 : 1;
        if (dist < 20 && Math.random() < 0.25) b.crouchT = rnd(0.8, 1.5);
        if (b.grounded && dist < 16 && Math.random() < 0.22) this.startJump(b, 4.7); // dodge-hop
      }
      if (dist > 15) {
        wantSpeed = RUN;
        moveDir = this.pathDir(b, tp);
        if (moveDir) faceYaw = Math.atan2(moveDir.x, moveDir.z) * 0.0 + this.lerpAngle(Math.atan2(moveDir.x, moveDir.z), Math.atan2(tdx, tdz), 0.55);
      } else if (dist < 5.5) {
        wantSpeed = WALK;
        moveDir = new THREE.Vector3(-tdx, 0, -tdz).normalize();
      } else if (b.crouchT <= 0) {
        wantSpeed = WALK * 0.9;
        moveDir = new THREE.Vector3(-tdz * b.strafeDir, 0, tdx * b.strafeDir).normalize();
      }
      this.tryShoot(b, ctx, tp, dist);
    } else if (live) {
      // hunt: head for where the enemy was — odd-numbered bots take a different route to flank
      if (b.repathT <= 0 || b.path.length === 0) {
        b.repathT = rnd(3.2, 5.5);
        const base = b.lastSeen ?? this.randomEnemyPos(b, ctx);
        if (base) {
          let goal = base;
          if (b.id % 2 === 1) {
            const near = this.compound.navNodes.filter((n) => Math.abs(n.pos.y - base.y) < 1.8 && n.pos.distanceTo(base) < 13 && n.pos.distanceTo(base) > 3);
            if (near.length) goal = near[Math.floor(Math.random() * near.length)].pos;
          }
          this.setPath(b, goal);
        }
      }
      moveDir = this.followPath(b);
      wantSpeed = RUN * 0.92;
      if (moveDir) faceYaw = Math.atan2(moveDir.x, moveDir.z);
    }
    if (faceYaw !== null) b.yaw = this.lerpAngle(b.yaw, faceYaw, Math.min(1, dt * (b.cover === 1 ? 8 : 9)));

    // ---------------- movement (with hops over low obstacles)
    if (moveDir && wantSpeed > 0) {
      b.vel.x = THREE.MathUtils.lerp(b.vel.x, moveDir.x * wantSpeed, Math.min(1, dt * 9));
      b.vel.z = THREE.MathUtils.lerp(b.vel.z, moveDir.z * wantSpeed, Math.min(1, dt * 9));
    } else {
      b.vel.x *= Math.exp(-10 * dt);
      b.vel.z *= Math.exp(-10 * dt);
    }
    const inside = this.blocker(b.pos.x, b.pos.y, b.pos.z);
    const nx = b.pos.x + b.vel.x * dt;
    const nz = b.pos.z + b.vel.z * dt;
    const bx = inside ? null : this.blocker(nx, b.pos.y, b.pos.z);
    const bz = inside ? null : this.blocker(b.pos.x, b.pos.y, nz);
    if (!bx) b.pos.x = nx;
    if (!bz) b.pos.z = nz;
    const obst = bx ?? bz;
    if (obst && b.grounded && wantSpeed > 0 && b.cover !== 2) {
      const h = obst.maxY - b.pos.y;
      if (h > 0.3 && h < 1.2) this.startJump(b, 4.9 + h * 1.2);
    }
    for (const o of this.bots) {
      if (o === b || !o.alive) continue;
      const sx = b.pos.x - o.pos.x;
      const sz = b.pos.z - o.pos.z;
      const d2 = sx * sx + sz * sz;
      if (d2 < 0.55 && d2 > 1e-4) {
        const d = Math.sqrt(d2);
        b.pos.x += (sx / d) * (0.74 - d) * 0.25;
        b.pos.z += (sz / d) * (0.74 - d) * 0.25;
      }
    }
    const floor = this.compound.getFloorHeight(b.pos.x, b.pos.z, Math.max(b.pos.y, 0));
    if (!b.grounded) {
      b.vy -= 15 * dt;
      b.pos.y += b.vy * dt;
      const fl = this.compound.getFloorHeight(b.pos.x, b.pos.z, b.pos.y);
      if (b.pos.y <= fl && b.vy <= 0) {
        b.pos.y = fl;
        b.vy = 0;
        b.grounded = true;
        b.landT = 0.18;
      }
    } else {
      b.pos.y = THREE.MathUtils.lerp(b.pos.y, floor, Math.min(1, dt * 14));
    }

    // stuck detection → new route
    b.stuckT += dt;
    if (b.stuckT > 1.2) {
      if (moveDir && wantSpeed > 0 && b.pos.distanceTo(b.lastPos) < 0.2) {
        b.stuckN++;
        b.path = [];
        b.repathT = 0;
        b.strafeDir *= -1;
        b.lastSeen = null;
        if (b.cover === 1) b.cover = 0;
        if (b.stuckN >= 2) {
          const nodes = this.compound.navNodes.filter((n) => Math.abs(n.pos.y - b.pos.y) < 1.5);
          const n = nodes[Math.floor(Math.random() * nodes.length)];
          if (n) this.setPath(b, n.pos);
        }
        if (b.stuckN >= 4) {
          const n = this.nearestNode(b.pos);
          b.pos.x = n.pos.x;
          b.pos.z = n.pos.z;
          b.stuckN = 0;
        }
      } else {
        b.stuckN = Math.max(0, b.stuckN - 1);
      }
      b.lastPos.copy(b.pos);
      b.stuckT = 0;
    }
    if (b.doorT <= 0) {
      b.doorT = 0.35;
      this.openNearbyDoor(b, ctx);
    }

    // ---------------- animation: the pack's walk / run / crouch cycle for the legs …
    const spd = Math.hypot(b.vel.x, b.vel.z);
    const crouching = b.cover === 2 || (b.crouchT > 0 && b.cover === 0);
    const mode: AnimMode = crouching && spd < 0.7 ? 'crouch' : spd > 3.0 ? 'chase' : spd > 0.45 ? 'walk' : 'idle';
    b.mode = mode;
    rig.root.position.copy(b.pos);
    rig.root.rotation.y = b.yaw;
    updateCharacterAnimation(rig, mode, b.elapsed, b.phaseOff, dt);

    // … and the PLAYER's weapon handling for everything the hands do
    if (b.weapon) {
      const engaged = (seen && b.cover !== 2 && (dist <= 15 || spd < 2.2)) || b.shootPoseT > 0;
      const eyeY = b.pos.y + 1.45;
      const pitch = tp && seen ? THREE.MathUtils.clamp(Math.atan2(tp.y - eyeY, Math.max(dist, 1)), -0.6, 0.6) : 0;
      const inp: PoseInput = {
        run: THREE.MathUtils.clamp((spd - 1.6) / 2.4, 0, 1),
        aim: engaged ? 1 : 0,
        ads: (engaged && ((dist > 14 && spd < 1.7) || b.cover === 3)) || (b.cover === 3 && seen) ? 1 : 0,
        reload: b.reloadT > 0 ? 1 : 0,
        jump: b.grounded ? 0 : 1,
        aimPitch: pitch,
      };
      b.weapon.update(inp, dt);
    }
  }

  private startJump(b: Bot, vy: number) {
    if (!b.grounded) return;
    b.grounded = false;
    b.vy = vy;
  }

  /** cover logic: pick a hidden node, run there, crouch / reload / heal, then pop out and shoot */
  private tactics(b: Bot, ctx: TdmContext, tp: THREE.Vector3 | null, seen: boolean, dist: number, dt: number) {
    const known = tp ?? b.lastSeen;
    switch (b.cover) {
      case 0: {
        if (!known || b.coverCd > 0 || !seen) break;
        const hurt = b.hp < 45;
        const reloading = b.reloadT > 0;
        const underFire = b.lastHitT < 1.3 && b.hp < 78;
        const tactical = dist > 9 && Math.random() < dt * 0.1; // sometimes just uses cover on principle
        if (hurt || reloading || (underFire && Math.random() < dt * 2) || tactical) {
          const c = this.pickCover(b, known);
          if (c) {
            b.cover = 1;
            b.coverPos = c;
            b.peekPos = null;
            b.coverT = 7;
            b.path = [];
            b.repathT = 0;
            this.setPath(b, c);
          } else b.coverCd = 1.2;
        }
        break;
      }
      case 1: {
        if (!b.coverPos) {
          b.cover = 0;
          break;
        }
        const d = Math.hypot(b.coverPos.x - b.pos.x, b.coverPos.z - b.pos.z);
        if (d < 0.8 || b.coverT <= 0) {
          b.cover = 2;
          b.hideT = rnd(1.4, 2.8);
          b.hideTotal = 0;
          b.vel.multiplyScalar(0.3);
        }
        break;
      }
      case 2: {
        b.hideT -= dt;
        b.hideTotal += dt;
        const close = seen && dist < 7;
        if (b.hideTotal > 10 || (!known && b.hideTotal > 3.5)) {
          b.cover = 0;
          b.coverCd = 3;
          break;
        }
        if ((b.hideT <= 0 && b.reloadT <= 0 && b.hp > 38 && b.ammo > 0 && known) || (close && b.reloadT <= 0 && b.ammo > 0)) {
          b.peekPos = known && b.coverPos ? this.pickPeek(b.coverPos, known) : null;
          b.cover = 3;
          b.peekT = rnd(1.3, 2.5);
        }
        break;
      }
      case 3: {
        b.peekT -= dt;
        if (b.peekT <= 0 || b.ammo <= 0 || (b.lastHitT < 0.25 && b.hp < 62)) {
          b.cover = 2;
          b.hideT = rnd(1.0, 2.2);
          b.hideTotal = 0;
          b.peekPos = null;
          if (b.coverPos) {
            // slip back behind the wall
            b.pos.x += (b.coverPos.x - b.pos.x) * 0.0;
          }
          if (b.ammo <= 0 || b.hp < 45) b.coverCd = 0;
          else b.coverCd = rnd(2, 4);
          if (b.peekT <= 0 && b.hp >= 60 && b.ammo > 8 && Math.random() < 0.55) {
            // confident → leave cover and push
            b.cover = 0;
            b.coverCd = rnd(4, 7);
          }
        }
        break;
      }
    }
    void ctx;
  }

  /** nearest cover node the enemy cannot see (crouched head height), not too close to the enemy */
  private pickCover(b: Bot, enemy: THREE.Vector3): THREE.Vector3 | null {
    const cands = this.compound.navNodes
      .filter((n) => n.isCover && Math.abs(n.pos.y - b.pos.y) < 1.5 && n.pos.distanceTo(b.pos) < 20 && Math.hypot(n.pos.x - enemy.x, n.pos.z - enemy.z) > 5)
      .sort((a, c) => a.pos.distanceTo(b.pos) - c.pos.distanceTo(b.pos))
      .slice(0, 7);
    const from = new THREE.Vector3(enemy.x, enemy.y + 0.3, enemy.z);
    let best: THREE.Vector3 | null = null;
    let bestScore = Infinity;
    for (const n of cands) {
      const eye = new THREE.Vector3(n.pos.x, n.pos.y + 0.95, n.pos.z);
      if (this.hasLos(from, eye)) continue; // still exposed
      // prefer cover that does not mean running TOWARD the enemy
      const toward = (n.pos.x - b.pos.x) * (enemy.x - b.pos.x) + (n.pos.z - b.pos.z) * (enemy.z - b.pos.z);
      const score = n.pos.distanceTo(b.pos) + (toward > 0 ? 6 : 0) + Math.random() * 2;
      if (score < bestScore) {
        bestScore = score;
        best = n.pos.clone();
      }
    }
    return best;
  }

  /** a spot ~1 m to the side of the cover from which the enemy IS visible */
  private pickPeek(cover: THREE.Vector3, enemy: THREE.Vector3): THREE.Vector3 | null {
    const dx = enemy.x - cover.x;
    const dz = enemy.z - cover.z;
    const l = Math.hypot(dx, dz) || 1;
    const px = -dz / l;
    const pz = dx / l;
    const sides = Math.random() < 0.5 ? [1, -1] : [-1, 1];
    const from = new THREE.Vector3(enemy.x, enemy.y + 0.3, enemy.z);
    for (const sd of sides) {
      const c = new THREE.Vector3(cover.x + px * 1.15 * sd, cover.y, cover.z + pz * 1.15 * sd);
      if (this.blocker(c.x, c.y, c.z)) continue;
      if (this.hasLos(from, new THREE.Vector3(c.x, c.y + 1.5, c.z))) return c;
    }
    return null;
  }

  /** "enemy spotted!" — teammates learn where the contact is */
  private callout(b: Bot, pos: THREE.Vector3) {
    for (const o of this.bots) {
      if (o === b || !o.alive || o.team !== b.team) continue;
      if (o.pos.distanceTo(b.pos) > 48) continue;
      if (!o.seen) {
        o.lastSeen = pos.clone();
        o.repathT = 0;
      }
    }
  }

  // ---------------------------------------------------------------- targeting
  private scan(b: Bot, ctx: TdmContext) {
    const eye = this.eye(b, new THREE.Vector3());
    const cands: { key: number; pos: THREE.Vector3; d: number }[] = [];
    for (const o of this.bots) {
      if (!o.alive || o.team === b.team) continue;
      cands.push({ key: o.id, pos: new THREE.Vector3(o.pos.x, o.pos.y + 1.2, o.pos.z), d: o.pos.distanceTo(b.pos) });
    }
    if (b.team === 'red' && ctx.playerAlive) {
      cands.push({ key: -1, pos: new THREE.Vector3(ctx.playerPos.x, ctx.playerPos.y - 0.2, ctx.playerPos.z), d: ctx.playerPos.distanceTo(b.pos) });
    }
    cands.sort((x, y) => x.d - y.d);
    let found = false;
    for (let i = 0; i < Math.min(3, cands.length); i++) {
      const c = cands[i];
      if (c.d > 58) break;
      if (this.hasLos(eye, c.pos)) {
        if (b.targetKey !== c.key || !b.seen) {
          b.reactT = rnd(0.28, 0.55);
          this.callout(b, c.pos);
        }
        b.targetKey = c.key;
        b.seen = true;
        b.lastSeen = c.pos.clone();
        found = true;
        break;
      }
    }
    if (!found) {
      if (b.seen) b.repathT = 0;
      b.seen = false;
    }
  }

  private targetPoint(b: Bot, ctx: TdmContext): THREE.Vector3 | null {
    if (b.targetKey === -1) return ctx.playerAlive ? _v2.set(ctx.playerPos.x, ctx.playerPos.y - 0.2, ctx.playerPos.z) : null;
    const o = this.bots.find((x) => x.id === b.targetKey);
    if (!o || !o.alive) {
      b.seen = false;
      return null;
    }
    return _v2.set(o.pos.x, o.pos.y + 1.2, o.pos.z);
  }

  private randomEnemyPos(b: Bot, ctx: TdmContext): THREE.Vector3 | null {
    const list = this.bots.filter((o) => o.alive && o.team !== b.team);
    if (b.team === 'red' && ctx.playerAlive && Math.random() < 0.45) return ctx.playerPos.clone();
    if (list.length === 0) return null;
    return list[Math.floor(Math.random() * list.length)].pos.clone();
  }

  // ---------------------------------------------------------------- shooting
  private tryShoot(b: Bot, ctx: TdmContext, target: THREE.Vector3, dist: number) {
    if (b.reactT > 0 || b.fireCd > 0 || b.reloadT > 0) return;
    if (b.ammo <= 0) return;
    if (b.burst <= 0) {
      if (b.burstCd > 0) return;
      b.burst = 3 + Math.floor(Math.random() * 4);
    }
    b.burst--;
    b.ammo--;
    b.fireCd = 0.1 + Math.random() * 0.025;
    b.shootPoseT = 0.45;
    if (b.burst <= 0) b.burstCd = rnd(0.35, 0.85);

    this.fireAt(b, ctx, target, dist);
  }

  private fireAt(b: Bot, ctx: TdmContext, target: THREE.Vector3, dist: number) {
    const muzzle = new THREE.Vector3(b.pos.x + Math.sin(b.yaw) * 0.8, b.pos.y + (b.cover === 2 ? 0.9 : 1.38), b.pos.z + Math.cos(b.yaw) * 0.8);
    const spd = Math.hypot(b.vel.x, b.vel.z);
    let p = 0.16 + 0.46 * Math.exp(-dist / 22);
    p *= spd > 2.5 ? 0.6 : 1;
    if (!b.grounded) p *= 0.5;
    if (dist > 14 && spd < 1.7) p *= 1.25; // zoomed in
    const targetBot = b.targetKey >= 0 ? this.bots.find((o) => o.id === b.targetKey) : null;
    if (targetBot) {
      const ts = Math.hypot(targetBot.vel.x, targetBot.vel.z);
      p *= ts > 2.5 ? 0.72 : 1;
      if (targetBot.cover === 2) p *= 0.6; // crouched behind a wall
    } else p *= 0.78; // go easy on the human
    const hit = Math.random() < p;
    const end = target.clone();
    if (!hit) end.add(new THREE.Vector3(rnd(-1.1, 1.1), rnd(-0.6, 0.8), rnd(-1.1, 1.1)));
    ctx.onShotFx(muzzle, end);
    if (this.shotSoundBudget >= 1 && dist < 55) {
      this.shotSoundBudget -= 1;
      soundEngine.playBotShot(ctx.playerPos.distanceTo(muzzle), !hit && ctx.playerPos.distanceTo(end) < 3);
    }
    if (!hit) return;
    if (b.targetKey === -1) {
      if (!ctx.playerProtected && ctx.playerAlive) ctx.onPlayerHit(rnd(6, 10), muzzle, { id: b.id, name: b.name });
    } else if (targetBot && targetBot.alive && targetBot.rig && this.phase === 'live') {
      const head = Math.random() < 0.09;
      this.damageBot(
        targetBot.id,
        rnd(9, 13),
        { zone: head ? 'head' : 'body', flinch: head ? 'head' : 'chest', point: new THREE.Vector3(targetBot.pos.x, targetBot.pos.y + (head ? 1.65 : 1.2), targetBot.pos.z) },
        b.pos,
        { name: b.name, team: b.team, isPlayer: false }
      );
    }
  }

  // ---------------------------------------------------------------- navigation
  private nearestNode(pos: THREE.Vector3) {
    let best = this.compound.navNodes[0];
    let bd = Infinity;
    for (const n of this.compound.navNodes) {
      const dy = (n.pos.y - Math.max(0, pos.y - 1.1)) * 2.5;
      const d = Math.hypot(n.pos.x - pos.x, n.pos.z - pos.z, dy);
      if (d < bd) {
        bd = d;
        best = n;
      }
    }
    return best;
  }

  private setPath(b: Bot, goal: THREE.Vector3) {
    const nodes = this.compound.navNodes;
    const startId = this.nearestNode(b.pos).id;
    const goalId = this.nearestNode(goal).id;
    b.path = [];
    b.pathIdx = 0;
    if (startId === goalId) {
      b.path = [goalId];
      return;
    }
    const goalPos = nodes[goalId].pos;
    const open = new Set<number>([startId]);
    const came = new Map<number, number>();
    const g = new Map<number, number>([[startId, 0]]);
    const f = new Map<number, number>([[startId, nodes[startId].pos.distanceTo(goalPos)]]);
    while (open.size > 0) {
      let cur = -1;
      let lo = Infinity;
      for (const id of open) {
        const v = f.get(id) ?? Infinity;
        if (v < lo) {
          lo = v;
          cur = id;
        }
      }
      if (cur === goalId) {
        const out = [cur];
        let c = cur;
        while (came.has(c)) {
          c = came.get(c)!;
          out.push(c);
        }
        out.reverse();
        b.path = out;
        b.pathIdx = out.length > 1 ? 1 : 0;
        return;
      }
      open.delete(cur);
      const cg = g.get(cur) ?? Infinity;
      for (const nb of nodes[cur].neighbors) {
        const t = cg + nodes[cur].pos.distanceTo(nodes[nb].pos);
        if (t < (g.get(nb) ?? Infinity)) {
          came.set(nb, cur);
          g.set(nb, t);
          f.set(nb, t + nodes[nb].pos.distanceTo(goalPos));
          open.add(nb);
        }
      }
    }
    b.path = [goalId];
  }

  private followPath(b: Bot): THREE.Vector3 | null {
    if (b.pathIdx >= b.path.length) {
      b.path = [];
      return null;
    }
    const tp = this.compound.navNodes[b.path[b.pathIdx]].pos;
    const dx = tp.x - b.pos.x;
    const dz = tp.z - b.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.7) {
      b.pathIdx++;
      return null;
    }
    return new THREE.Vector3(dx / d, 0, dz / d);
  }

  private pathDir(b: Bot, target: THREE.Vector3): THREE.Vector3 | null {
    if (b.repathT <= 0 || b.path.length === 0) {
      b.repathT = rnd(1.4, 2.4);
      this.setPath(b, target);
    }
    return this.followPath(b);
  }

  private blocker(x: number, footY: number, z: number): BoxCollider3D | null {
    for (const c of this.colliders) {
      if (c.disabled) continue;
      if (footY + 1.5 > c.minY && footY + 0.35 < c.maxY && x > c.minX - 0.2 && x < c.maxX + 0.2 && z > c.minZ - 0.2 && z < c.maxZ + 0.2) return c;
    }
    return null;
  }

  private openNearbyDoor(b: Bot, ctx: TdmContext) {
    for (const d of this.compound.doors) {
      if (d.isOpen) continue;
      const floor = b.pos.y > 2.4 ? 1 : 0;
      if (d.floor !== floor) continue;
      if (Math.hypot(d.center.x - b.pos.x, d.center.z - b.pos.z) < 1.8) {
        d.isOpen = true;
        const dd = ctx.playerPos.distanceTo(b.pos);
        if (dd < 24) soundEngine.playDoorToggle(true, dd);
      }
    }
  }

  private lerpAngle(a: number, b: number, t: number) {
    let d = b - a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return a + d * t;
  }

  // ===========================================================================
  //  HUD
  // ===========================================================================
  public getHud(): TdmHud {
    return {
      active: this.phase !== 'lobby',
      phase: this.phase,
      blue: this.blue,
      red: this.red,
      target: this.target,
      timeLeft: Math.ceil(this.timeLeft),
      playerKills: this.player.kills,
      playerDeaths: this.player.deaths,
      playerStreak: this.player.streak,
      playerSkin: this.playerSkin,
      feed: this.feed.slice(),
      winner: this.winner,
      roster: [
        { name: 'KAMU', team: 'blue', alive: true, hp: 100, kills: this.player.kills, deaths: this.player.deaths, isPlayer: true },
        ...this.bots.map((b) => ({ name: b.name, team: b.team, alive: b.alive, hp: Math.max(0, Math.round(b.hp)), kills: b.kills, deaths: b.deaths, isPlayer: false })),
      ],
      protectT: this.player.protectT,
    };
  }

  public skinName(id: SkinId) {
    return SKINS_META.find((s) => s.id === id)?.name ?? id;
  }

  public static get skinIds() {
    return ALL_SKIN_IDS;
  }
}
