import * as THREE from 'three';
import type { ArmIKChain, CharacterRig } from '../skins/animation';
import { applyTwoBoneArmPlantIK } from '../skins/animation';
import type { WeaponRig } from './weaponModels';

/**
 * =====================================================================================
 *  BOT WEAPON HANDLING — the squad holds its guns EXACTLY like the player does
 * =====================================================================================
 *  The poses below are the player's first-person rifle poses (READY / SPRINT low-ready / RELOAD / ADS),
 *  expressed relative to the chest-mounted camera and converted to the character's space.
 *  The pack supplies the legs & the walk / run cycle; this module drives everything about the gun:
 *
 *    • PATH B (Boonie, Red-Eye, Spetsnaz, Silat): the player's own M4 model is carried and BOTH arms are solved with
 *      the pack's two-bone IK onto its grips — full freedom: low-ready while running, ready while idle,
 *      shouldered while firing, cheek-weld ADS, canted reload.
 *    • PATH A (Venom, Golden, SWAT, Gunner): gun + arms are one rigid pack assembly pivoting on the shoulder line,
 *      so the same states are expressed as pitch / offset of that assembly.
 *    • Jump: the pack's legs are tucked while airborne, the weapon stays in its current hold.
 * =====================================================================================
 */

export interface PoseInput {
  /** 0..1 running fast (→ low ready) */
  run: number;
  /** 0..1 engaging a target (weapon raised / shouldered) */
  aim: number;
  /** 0..1 zoomed (cheek-weld) */
  ads: number;
  /** 0..1 reloading */
  reload: number;
  /** 0..1 airborne */
  jump: number;
  /** radians, + = target above the muzzle */
  aimPitch: number;
}

type V3 = [number, number, number];
interface Pose {
  p: V3;
  r: V3;
}
// the player's rifle poses (camera space: x right, y up, −z forward) — see WEAPON_POSES in engine.ts
const READY: Pose = { p: [0.02, -0.125, -0.37], r: [0.02, 0, -0.03] };
const RELOAD: Pose = { p: [0.06, -0.135, -0.46], r: [0.23, 0.56, -0.48] };
const SPRINT: Pose = { p: [0.03, -0.175, -0.38], r: [-0.3, 0.26, -0.18] };
const ADS: Pose = { p: [0.0, -0.118, -0.25], r: [0, 0, 0] };

const mix3 = (a: V3, b: V3, t: number): V3 => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

const _e = new THREE.Euler();
const _q = new THREE.Quaternion();
const _qFlip = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI);
const _qRootInv = new THREE.Quaternion();
const _qPar = new THREE.Quaternion();
const _qDes = new THREE.Quaternion();
const _qOff = new THREE.Quaternion();
const _tgt = new THREE.Vector3();
// fingers (−Y in the pack's hand) along the barrel (−Z of the gun), a little roll per hand
const HAND_R = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0.55));
const HAND_L = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, -0.55));

export class BotWeapon {
  public holder: THREE.Group | null = null;
  public readonly pathB: boolean;
  private gripR = new THREE.Vector3();
  private gripL = new THREE.Vector3();
  private s = { run: 0, aim: 0, ads: 0, reload: 0, jump: 0 };
  private pitchA = 0;

  constructor(private rig: CharacterRig, rifle: WeaponRig | null) {
    this.pathB = !rig.weaponRig && !!rifle && !!rig.leftArmIK && !!rig.rightArmIK;
    if (this.pathB && rifle) {
      const body = rifle.weaponBody.clone(true);
      // strip the first-person arms off the clone (they are children at the same indices)
      const drop: THREE.Object3D[] = [];
      rifle.weaponBody.children.forEach((o, i) => {
        if (o === rifle.leftArm || o === rifle.rightArm) drop.push(body.children[i]);
      });
      drop.forEach((o) => o.removeFromParent());
      const holder = new THREE.Group();
      holder.name = 'bot-rifle';
      holder.add(body);
      rig.root.add(holder);
      this.holder = holder;
      this.gripR.copy(rifle.rightArmRestPos);
      this.gripL.copy(rifle.leftArmRestPos);
    }
  }

  /** gun leaves the character (death) — returns it re-parented to the scene, keeping its world transform */
  public releaseGun(scene: THREE.Scene): THREE.Group | null {
    if (!this.holder) return null;
    const h = this.holder;
    scene.attach(h);
    this.holder = null;
    return h;
  }

  public detach() {
    if (this.holder) {
      this.holder.removeFromParent();
      this.holder = null;
    }
  }

  /** call AFTER updateCharacterAnimation each frame */
  public update(inp: PoseInput, dt: number) {
    const k = 1 - Math.exp(-11 * dt);
    const s = this.s;
    s.run += (inp.run - s.run) * k;
    s.aim += (inp.aim - s.aim) * k;
    s.ads += (inp.ads - s.ads) * (1 - Math.exp(-9 * dt));
    s.reload += (inp.reload - s.reload) * (1 - Math.exp(-14 * dt));
    s.jump += (inp.jump - s.jump) * (1 - Math.exp(-16 * dt));

    if (this.holder) this.updateB(inp);
    else if (this.rig.weaponRig) this.updateA(inp, dt);
    this.tuckLegs();
  }

  // ---------------------------------------------------------------- PATH B: our rifle + two-bone IK
  private updateB(inp: PoseInput) {
    const holder = this.holder!;
    const rig = this.rig;
    const s = this.s;
    let pose = { p: READY.p, r: READY.r } as Pose;
    pose = { p: mix3(pose.p, RELOAD.p, s.reload), r: mix3(pose.r, RELOAD.r, s.reload) };
    const runW = s.run * (1 - s.aim) * (1 - s.reload);
    pose = { p: mix3(pose.p, SPRINT.p, runW), r: mix3(pose.r, SPRINT.r, runW) };
    const adsW = s.ads * (1 - s.reload);
    pose = { p: mix3(pose.p, ADS.p, adsW), r: mix3(pose.r, ADS.r, adsW) };

    // third person: the stock goes to the SHOULDER when engaging (the first-person camera sits at the chest)
    const lift = (s.aim * 0.13 + s.ads * 0.05) * (1 - s.reload);
    const pull = s.aim * 0.05 * (1 - s.reload);
    const anchorY = rig.hipsPivot.position.y + 0.42 + lift;
    holder.position.set(-pose.p[0], anchorY + pose.p[1], -pose.p[2] - pull);
    _e.set(pose.r[0] + inp.aimPitch * s.aim * (1 - s.reload), pose.r[1], pose.r[2], 'XYZ');
    _q.setFromEuler(_e);
    holder.quaternion.copy(_qFlip).multiply(_q);
    holder.updateMatrix();

    this.solveArm(rig.rightArmIK, this.gripR, HAND_R);
    this.solveArm(rig.leftArmIK, this.gripL, HAND_L);
  }

  private solveArm(chain: ArmIKChain | null, grip: THREE.Vector3, handOffset: THREE.Quaternion) {
    if (!chain || !this.holder) return;
    const rig = this.rig;
    _tgt.copy(grip).applyMatrix4(this.holder.matrix); // holder lives directly under the root → root space
    applyTwoBoneArmPlantIK(rig, chain, _tgt, 1);
    const hand = chain.handGroup;
    if (hand && hand.parent) {
      rig.root.updateMatrixWorld(true);
      rig.root.getWorldQuaternion(_qRootInv).invert();
      hand.parent.getWorldQuaternion(_qPar);
      _qPar.premultiply(_qRootInv); // parent rotation in root space
      _qOff.copy(this.holder.quaternion).multiply(handOffset);
      _qDes.copy(_qPar).invert().multiply(_qOff);
      hand.quaternion.copy(_qDes);
    }
  }

  // ---------------------------------------------------------------- PATH A: pack gun + arms as one rigid assembly
  private updateA(inp: PoseInput, dt: number) {
    const wr = this.rig.weaponRig!;
    const s = this.s;
    const runW = s.run * (1 - s.aim) * (1 - s.reload);
    // + pitch = muzzle DOWN for these rigs
    const target = -0.05 + runW * 0.4 + s.reload * 0.46 - inp.aimPitch * s.aim * (1 - s.reload) - s.ads * 0.02;
    this.pitchA += (target - this.pitchA) * (1 - Math.exp(-13 * dt));
    wr.rotation.x = this.pitchA;
    if (wr.userData.baseZ === undefined) wr.userData.baseZ = wr.position.z;
    wr.position.z = (wr.userData.baseZ as number) - 0.04 * runW + 0.025 * s.aim + 0.02 * s.ads;
    wr.position.y += -0.045 * runW + 0.02 * s.aim * (1 - s.reload);
    wr.rotation.z += -0.1 * s.reload;
  }

  // ---------------------------------------------------------------- jump: knees up (pack legs)
  private tuckLegs() {
    const j = this.s.jump;
    if (j < 0.02) return;
    const rig = this.rig;
    const L = rig.leftLeg;
    const R = rig.rightLeg;
    const mixTo = (cur: number, to: number) => cur + (to - cur) * j;
    L.hipPivot.rotation.x = mixTo(L.hipPivot.rotation.x, -1.0);
    L.kneePivot.rotation.x = mixTo(L.kneePivot.rotation.x, 1.65);
    L.anklePivot.rotation.x = mixTo(L.anklePivot.rotation.x, 0.35);
    R.hipPivot.rotation.x = mixTo(R.hipPivot.rotation.x, -0.42);
    R.kneePivot.rotation.x = mixTo(R.kneePivot.rotation.x, 1.05);
    R.anklePivot.rotation.x = mixTo(R.anklePivot.rotation.x, 0.25);
  }
}
