import * as THREE from 'three';
import { IQ } from './iqLighting';

export interface BodycamParams {
  enabled: boolean;
  time: number;
  exposure: number; // Aggressive auto-exposure multiplier
  brightness: number; // Adjustable bright sunlit baseline (default ~1.18 matching previous brightness!)
  glareStrength: number; // Highlight halation when looking at sun / exiting dark room / firing
  focusDistance: number; // Live autofocus distance in meters
  dofStrength: number; // 0..1 optical bokeh intensity
  fisheyeStrength: number; // 0..1 wide-angle barrel distortion
  blackFrameStrength: number; // 0..1 morphs between full-bleed (0) and previous curved black lens border (1)
  chromaticStrength: number; // 0..1 edge RGB dispersion
  grainStrength: number; // 0..1 sensor grain intensity
  vignetteStrength: number; // 0..1 optical corner falloff
  damagePulse: number; // 0..1 crimson peripheral hit feedback when taking bot fire
  sunScreenPos: THREE.Vector2; // Projected sun UV (0..1) for AAA golden sun corona & lens flare
  sunFlareStrength: number; // 0..1 sun visibility strength
  cameraNear: number;
  cameraFar: number;
  sniperScoped: boolean;
}

const VERT_SHADER = /* glsl */ `
  varying vec2 vUv;

  void main() {
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }
`;

const FRAG_SHADER = /* glsl */ `
  precision highp float;

  uniform sampler2D tWorld;
  uniform sampler2D tWorldDepth;
  uniform sampler2D tVm;

  uniform vec2 uResolution;
  uniform float uTime;
  uniform float uEnabled;
  uniform float uExposure;
  uniform float uBrightness;
  uniform float uGlareStrength;
  uniform float uFocusDist;
  uniform float uDofStrength;
  uniform float uFisheye;
  uniform float uBlackFrame;
  uniform float uChromatic;
  uniform float uGrain;
  uniform float uVignette;
  uniform float uDamagePulse;
  uniform vec2 uSunScreenPos;
  uniform float uSunFlare;
  uniform float uNear;
  uniform float uFar;

  // IQ "Elephant" screen-space SDF lighting (depth-buffer soft shadows + AO + grade)
  uniform float uIqMix;
  uniform vec2 uProjScale;
  uniform float uIqSteps;
  uniform float uIqAoTaps;
  uniform vec3 uSunViewDir;

  varying vec2 vUv;

  float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
  }

  float getLuma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
  }

  vec3 linearToSrgb(vec3 c) {
    return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2));
  }

  // Bright, airy sunlit filmic tone curve (preserves previous bright look while keeping hand facets crisp!)
  vec3 brightFilmic(vec3 x) {
    vec3 a = x * (x * 1.48 + 0.24);
    vec3 b = x * (x * 1.18 + 0.68) + 0.045;
    return clamp(a / b, 0.0, 1.0);
  }

  float linearizeDepth(float depthSample) {
    float z = depthSample * 2.0 - 1.0;
    return (2.0 * uNear * uFar) / max(0.0001, (uFar + uNear - z * (uFar - uNear)));
  }

  // Dual-Mode Wide-Angle Fisheye:
  // uBlackFrame = 0.0 -> Full-bleed edge-to-edge wide lens (ZERO black borders!)
  // uBlackFrame = 1.0 -> Previous classic curved bodycam housing frame!
  vec2 computeFisheyeUv(vec2 uv, float fisheyeAmt, float frameAmt, out float outMask) {
    vec2 p = uv * 2.0 - 1.0;
    float aspect = uResolution.x / max(1.0, uResolution.y);

    // 1. Clean full-bleed normalized barrel warp (guaranteed in [0,1])
    float kClean = fisheyeAmt * 0.34;
    float ax = mix(1.0, aspect, 0.32);
    vec2 pa = vec2(p.x * ax, p.y);
    float r2Clean = dot(pa, pa);
    float maxR2 = ax * ax + 1.0;
    float scaleClean = (1.0 + kClean * r2Clean) / (1.0 + kClean * maxR2);
    vec2 uvClean = p * scaleClean * 0.5 + 0.5;

    // 2. Previous classic curved bodycam bezel warp
    float kRetro = 0.08 + fisheyeAmt * 0.26;
    vec2 pr = vec2(p.x * aspect, p.y);
    float r2Retro = dot(pr, pr);
    float zoomRetro = 1.0 - kRetro * 0.34;
    vec2 uvRetro = (p * (1.0 + kRetro * r2Retro + kRetro * 0.22 * r2Retro * r2Retro) * zoomRetro) * 0.5 + 0.5;

    // Smoothly morph between full-screen clean warp and curved retro frame!
    vec2 warped = mix(uvClean, uvRetro, frameAmt);

    // Out-of-lens rounded housing mask engages smoothly as uBlackFrame increases toward Filter Sebelumnya!
    vec2 edgeDist = abs(warped - 0.5) * 2.0;
    float maskRetro = 1.0 - smoothstep(0.985, 1.018, max(edgeDist.x, edgeDist.y));
    outMask = mix(1.0, maskRetro, smoothstep(0.15, 0.42, frameAmt));

    return warped;
  }

  // Lightweight high-quality FXAA sample for crisp anti-aliased world geometry
  vec3 sampleWorldFXAA(vec2 uv) {
    vec2 px = 1.0 / uResolution;
    vec3 rgbM  = texture2D(tWorld, uv).rgb;
    vec3 rgbNW = texture2D(tWorld, uv + vec2(-1.0, -1.0) * px).rgb;
    vec3 rgbNE = texture2D(tWorld, uv + vec2( 1.0, -1.0) * px).rgb;
    vec3 rgbSW = texture2D(tWorld, uv + vec2(-1.0,  1.0) * px).rgb;
    vec3 rgbSE = texture2D(tWorld, uv + vec2( 1.0,  1.0) * px).rgb;

    float lumaM  = getLuma(rgbM);
    float lumaNW = getLuma(rgbNW);
    float lumaNE = getLuma(rgbNE);
    float lumaSW = getLuma(rgbSW);
    float lumaSE = getLuma(rgbSE);

    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));
    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));
    float lumaRange = lumaMax - lumaMin;

    if (lumaRange < max(0.03, lumaMax * 0.085)) {
      return rgbM;
    }

    vec2 dir;
    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));
    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));

    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-5.0), vec2(5.0)) * px;

    vec3 rgbA = 0.5 * (
      texture2D(tWorld, uv + dir * (1.0 / 3.0 - 0.5)).rgb +
      texture2D(tWorld, uv + dir * (2.0 / 3.0 - 0.5)).rgb
    );
    vec3 rgbB = rgbA * 0.5 + 0.25 * (
      texture2D(tWorld, uv + dir * -0.5).rgb +
      texture2D(tWorld, uv + dir *  0.5).rgb
    );

    float lumaB = getLuma(rgbB);
    return (lumaB < lumaMin || lumaB > lumaMax) ? rgbA : rgbB;
  }

  // Adjustable Dynamic Depth of Field Circle-of-Confusion
  float computeWorldCoC(float linearDist) {
    if (uDofStrength < 0.02) return 0.0;
    float d = min(linearDist, 230.0);
    float f = max(0.55, uFocusDist);

    float relDiff = abs(d - f) / max(d, f);
    float closeFactor = 1.0 - smoothstep(1.2, 18.0, f);
    // Wider deadzone when DoF slider is low -> razor crisp; tighter dreamy bokeh when DoF slider is high!
    float deadzone = mix(0.30, 0.08, max(closeFactor, uDofStrength * 0.55));
    float coc = smoothstep(deadzone, deadzone + 0.55, relDiff) * uDofStrength;
    return coc * mix(2.2, 5.8, max(closeFactor, uDofStrength * 0.45));
  }

  vec3 sampleWorldDoF(vec2 uv) {
    float centerDepth = linearizeDepth(texture2D(tWorldDepth, uv).r);
    float coc = computeWorldCoC(centerDepth);

    vec3 sharp = sampleWorldFXAA(uv);
    if (coc < 0.35) {
      return sharp;
    }

    vec2 texel = (1.0 / uResolution) * coc;
    vec3 acc = sharp * 1.4;
    float wSum = 1.4;

    vec2 offsets[8];
    offsets[0] = vec2( 1.0,  0.0);
    offsets[1] = vec2(-1.0,  0.0);
    offsets[2] = vec2( 0.0,  1.0);
    offsets[3] = vec2( 0.0, -1.0);
    offsets[4] = vec2( 0.58,  0.58);
    offsets[5] = vec2(-0.58,  0.58);
    offsets[6] = vec2( 0.58, -0.58);
    offsets[7] = vec2(-0.58, -0.58);

    for (int i = 0; i < 8; i++) {
      vec2 suv = clamp(uv + offsets[i] * texel, vec2(0.001), vec2(0.999));
      float sDepth = linearizeDepth(texture2D(tWorldDepth, suv).r);
      float sCoc = computeWorldCoC(sDepth);
      float w = (sDepth >= centerDepth - 0.6) ? 1.0 : clamp(sCoc / max(coc, 0.01), 0.12, 1.0);
      acc += texture2D(tWorld, suv).rgb * w;
      wSum += w;
    }
    return acc / wSum;
  }

  vec3 compositeRaw(vec2 uv) {
    vec3 w = texture2D(tWorld, uv).rgb;
    vec4 vm = texture2D(tVm, uv);
    return mix(w, vm.rgb, vm.a);
  }

  // AAA Clean Depth-Buffer Screen-Space Contact Ambient Occlusion (darkens corners, door trims, sills & under boots!)
  float computeContactSSAO(vec2 uv) {
    float cDepth = linearizeDepth(texture2D(tWorldDepth, uv).r);
    if (cDepth > 110.0) return 1.0; // sky / far mountains stay crisp & bright

    // Scale sampling radius in screen space inversely with distance so crevices stay physically consistent
    float radiusPx = clamp(24.0 / max(cDepth, 1.4), 3.0, 15.0);
    vec2 stepUv = (1.0 / uResolution) * radiusPx;
    float bias = 0.055 + cDepth * 0.012;
    float maxRange = 1.25 + cDepth * 0.05;

    float occ = 0.0;
    // 8 balanced compass & diagonal taps around pixel
    vec2 dirs[8];
    dirs[0] = vec2( 1.0,  0.0);
    dirs[1] = vec2(-1.0,  0.0);
    dirs[2] = vec2( 0.0,  1.0);
    dirs[3] = vec2( 0.0, -1.0);
    dirs[4] = vec2( 0.71,  0.71);
    dirs[5] = vec2(-0.71,  0.71);
    dirs[6] = vec2( 0.71, -0.71);
    dirs[7] = vec2(-0.71, -0.71);

    for (int i = 0; i < 8; i++) {
      vec2 suv = clamp(uv + dirs[i] * stepUv, vec2(0.002), vec2(0.998));
      float sDepth = linearizeDepth(texture2D(tWorldDepth, suv).r);
      float diff = cDepth - sDepth;
      if (diff > bias && diff < maxRange) {
        float rangeFade = 1.0 - smoothstep(bias, maxRange, diff);
        occ += rangeFade;
      }
    }
    // Smooth natural contact occlusion (up to ~34% crevice darkening — deep AAA grounding, zero muddy halos!)
    float ao = 1.0 - clamp((occ / 8.0) * 0.62, 0.0, 0.34);
    return mix(ao, 1.0, smoothstep(55.0, 110.0, cDepth));
  }

  // ===========================================================================
  //  IQ ELEPHANT LIGHTING — SCREEN-SPACE SDF  (soft shadow + AO on the depth buffer)
  //  The depth buffer acts as a height-field "distance field": free-space distance h
  //  = sceneDepth - sampleDepth, then iq's classic  res = min(res, 8*h/t)  and the
  //  5-tap  occ += (h - d) * sca  AO  are evaluated exactly like in the shadertoy.
  // ===========================================================================
  // symmetric-perspective reconstruction (no mat4 math per tap)
  vec3 iqViewPos(vec2 uv, float depthSample) {
    float d = linearizeDepth(depthSample);
    return vec3((uv * 2.0 - 1.0) * uProjScale * d, -d);
  }

  bool iqProject(vec3 p, out vec2 uv) {
    float w = -p.z;
    if (w <= 0.0001) { uv = vec2(0.0); return false; }
    uv = (p.xy / (w * uProjScale)) * 0.5 + 0.5;
    return uv.x > 0.002 && uv.x < 0.998 && uv.y > 0.002 && uv.y < 0.998;
  }

  float iqSceneDist(vec2 uv) {
    return linearizeDepth(texture2D(tWorldDepth, uv).r);
  }

  vec3 iqViewNormal(vec2 uv, vec3 P) {
    vec2 px = 1.0 / uResolution;
    vec2 uR = uv + vec2(px.x, 0.0);
    vec2 uL = uv - vec2(px.x, 0.0);
    vec2 uU = uv + vec2(0.0, px.y);
    vec2 uD = uv - vec2(0.0, px.y);
    vec3 Pr = iqViewPos(uR, texture2D(tWorldDepth, uR).r);
    vec3 Pl = iqViewPos(uL, texture2D(tWorldDepth, uL).r);
    vec3 Pu = iqViewPos(uU, texture2D(tWorldDepth, uU).r);
    vec3 Pd = iqViewPos(uD, texture2D(tWorldDepth, uD).r);
    vec3 dx = abs(Pr.z - P.z) < abs(Pl.z - P.z) ? (Pr - P) : (P - Pl);
    vec3 dy = abs(Pu.z - P.z) < abs(Pd.z - P.z) ? (Pu - P) : (P - Pd);
    vec3 n = normalize(cross(dx, dy) + vec3(0.0, 0.0, 1e-6));
    if (dot(n, -P) < 0.0) n = -n;
    return n;
  }

  // iq soft shadow:  res = min( res, 8.0*h/t )  — marched on the depth buffer toward the sun
  float iqSoftShadow(vec3 ro, vec3 rd, float jitter, float dist) {
    float res = 1.0;
    float t = 0.07 + jitter * 0.06;
    float thick = 0.9 + dist * 0.035;
    for (int i = 0; i < 12; i++) {
      if (float(i) >= uIqSteps) break;
      vec3 S = ro + rd * t;
      vec2 suv;
      if (!iqProject(S, suv)) break;
      float h = iqSceneDist(suv) - (-S.z);
      if (h < 0.0 && h > -thick) {
        res = min(res, clamp(8.0 * (h + 0.05) / t, 0.0, 1.0));
      } else if (h >= 0.0) {
        res = min(res, clamp(8.0 * h / t, 0.0, 1.0));
      }
      if (res < 0.02) break;
      t += clamp(0.14 + t * 0.4, 0.14, 0.9);
      if (t > 7.5) break;
    }
    res = clamp(res, 0.0, 1.0);
    return res * res * (3.0 - 2.0 * res);
  }

  // iq calcAO:  occ += (h - d) * sca ; sca *= 0.95  — samples along the normal
  float iqCalcAO(vec3 P, vec3 N, float dist) {
    float occ = 0.0;
    float sca = 1.0;
    float norm = 0.0;
    for (int i = 0; i < 5; i++) {
      if (float(i) >= uIqAoTaps) break;
      float hh = 0.05 + 0.6 * float(i) / max(uIqAoTaps - 1.0, 1.0);
      vec3 Q = P + N * hh;
      vec2 suv;
      if (!iqProject(Q, suv)) break;
      float d = iqSceneDist(suv) - (-Q.z);
      float behind = -d;
      float rangeW = 1.0 - smoothstep(0.9, 1.8, behind);
      occ += clamp(hh - d, 0.0, hh) * sca * rangeW;
      norm += hh * sca;
      sca *= 0.92;
    }
    return clamp(1.0 - 0.95 * occ / max(norm, 0.001), 0.0, 1.0);
  }

  vec3 applyIqScreen(vec3 col, vec2 uv) {
    if (uIqMix < 0.002) return col;
    float dRaw = texture2D(tWorldDepth, uv).r;
    if (dRaw >= 0.99995) return col; // sky stays pure

    vec3 P = iqViewPos(uv, dRaw);
    float dist = -P.z;
    if (dist > 160.0) return col;

    vec3 N = iqViewNormal(uv, P);
    vec3 L = normalize(uSunViewDir);
    float ndl = dot(N, L);

    float sh = 1.0;
    if (uIqSteps > 0.5 && ndl > 0.03 && dist < 130.0) {
      float jit = hash12(gl_FragCoord.xy + fract(uTime) * 61.0);
      vec3 Pb = P + N * (0.025 + dist * 0.0018);
      sh = iqSoftShadow(Pb, L, jit, dist);
    }
    float ao = (dist < 100.0) ? iqCalcAO(P, N, dist) : 1.0;
    float aoFade = 1.0 - smoothstep(60.0, 100.0, dist);

    // Where the sun is blocked the key light vanishes and iq's blue sky fill remains
    float sunAmt = clamp(ndl * 1.25, 0.0, 1.0);
    float shadowDepth = (1.0 - sh) * sunAmt * (1.0 - smoothstep(70.0, 130.0, dist));
    vec3 shadowMul = mix(vec3(1.0), vec3(0.60, 0.70, 0.80), shadowDepth * 0.55);
    vec3 aoMul = vec3(mix(1.0, ao, 0.92 * aoFade));

    // Sun-kissed haze (iq fog: mix toward warm sun colour looking into the sun)
    vec3 rdV = normalize(P);
    float sunAlign = pow(clamp(dot(rdV, L), 0.0, 1.0), 8.0);
    float fogAmt = (1.0 - exp(-0.0000008 * dist * dist * dist)) * 0.5;
    vec3 fogCol = mix(vec3(0.66, 0.76, 0.88), vec3(1.05, 0.84, 0.58), sunAlign);

    vec3 lit = col * shadowMul * aoMul;
    lit = mix(lit, fogCol * (0.35 + 0.65 * clamp(length(col), 0.2, 1.4)), fogAmt * 0.45);
    return mix(col, lit, uIqMix);
  }

  // iq's finishing touch: smooth S-curve contrast + mild saturation + soft vignette (post tone-map, sRGB)
  vec3 iqGrade(vec3 c, vec2 uv) {
    if (uIqMix < 0.002) return c;
    vec3 sc = clamp(c, 0.0, 1.0);
    vec3 g = mix(sc, sc * sc * (3.0 - 2.0 * sc), 0.22);
    float l = getLuma(g);
    g = mix(vec3(l), g, 1.0);
    vec2 q = uv;
    g *= 0.78 + 0.22 * pow(clamp(16.0 * q.x * q.y * (1.0 - q.x) * (1.0 - q.y), 0.0, 1.0), 0.22);
    return mix(c, g, uIqMix);
  }


  void main() {
    // Clean bypass if Bodycam mode toggled OFF via [O] (still keeps crisp AAA SSAO & golden filmic tone!)
    if (uEnabled < 0.5) {
      vec3 rawW = sampleWorldFXAA(vUv) * (uIqMix > 0.98 ? 1.0 : computeContactSSAO(vUv));
      rawW = applyIqScreen(rawW, vUv);
      vec4 rawVm = texture2D(tVm, vUv);
      vec3 col = mix(rawW, rawVm.rgb, rawVm.a) * uBrightness;
      vec3 bypassOut = linearToSrgb(brightFilmic(col));
      gl_FragColor = vec4(iqGrade(bypassOut, vUv), 1.0);
      return;
    }

    // 1. Adjustable Wide-Angle Fisheye & Optional Retro Curved Lens Frame
    float outMask = 1.0;
    vec2 uv = computeFisheyeUv(vUv, uFisheye, uBlackFrame, outMask);
    vec2 clampedUv = clamp(uv, vec2(0.001), vec2(0.999));

    // 2. Razor-Sharp World (FXAA + Dynamic DoF + Real Contact SSAO) + Crisp 4x MSAA Weapon & White Hands!
    float ssao = uIqMix > 0.98 ? 1.0 : computeContactSSAO(clampedUv);
    vec3 worldCol = sampleWorldDoF(clampedUv) * ssao;
    worldCol = applyIqScreen(worldCol, clampedUv);
    vec4 vmSample = texture2D(tVm, clampedUv);
    vec3 baseCol = mix(worldCol, vmSample.rgb, vmSample.a);

    // 3. Adjustable Radial Chromatic Aberration
    vec2 radial = uv - 0.5;
    float r2 = dot(radial, radial);
    vec2 caShift = radial * (0.0005 + r2 * 0.0145) * uChromatic;
    float edgeWeight = smoothstep(0.02, 0.38, r2);

    vec3 color = baseCol;
    if (uChromatic > 0.02 && edgeWeight > 0.01) {
      vec3 colR = compositeRaw(clamp(clampedUv + caShift, vec2(0.001), vec2(0.999)));
      vec3 colB = compositeRaw(clamp(clampedUv - caShift, vec2(0.001), vec2(0.999)));
      color.r = mix(baseCol.r, colR.r, 0.78 * edgeWeight);
      color.b = mix(baseCol.b, colB.b, 0.78 * edgeWeight);
    }

    // 4. Bright Daylight Aggressive Auto-Exposure + Sun/Doorway Halation Glare
    float totalGain = uExposure * uBrightness;
    vec3 exposed = color * totalGain;
    if (uGlareStrength > 0.04) {
      vec2 gStep = (1.0 / uResolution) * (5.5 + uGlareStrength * 7.0);
      vec3 glare = vec3(0.0);
      vec3 s1 = compositeRaw(clamp(clampedUv + vec2( 1.0,  0.0) * gStep, 0.002, 0.998)) * totalGain;
      vec3 s2 = compositeRaw(clamp(clampedUv + vec2(-1.0,  0.0) * gStep, 0.002, 0.998)) * totalGain;
      vec3 s3 = compositeRaw(clamp(clampedUv + vec2( 0.0,  1.0) * gStep, 0.002, 0.998)) * totalGain;
      vec3 s4 = compositeRaw(clamp(clampedUv + vec2( 0.0, -1.0) * gStep, 0.002, 0.998)) * totalGain;
      glare += max(vec3(0.0), s1 - vec3(0.96));
      glare += max(vec3(0.0), s2 - vec3(0.96));
      glare += max(vec3(0.0), s3 - vec3(0.96));
      glare += max(vec3(0.0), s4 - vec3(0.96));
      exposed += glare * (0.16 * uGlareStrength);
    }

    // 4.5 AAA Cinematic Golden Sun Corona & Subtle Anamorphic Lens Flare (when looking near sun!)
    if (uSunFlare > 0.01) {
      float aspect = uResolution.x / max(1.0, uResolution.y);
      vec2 toSun = (clampedUv - uSunScreenPos) * vec2(aspect, 1.0);
      float sunDist = length(toSun);
      // Warm atmospheric golden corona
      float corona = exp(-sunDist * 3.4) * 0.36 + exp(-sunDist * 11.0) * 0.42;
      // Subtle horizontal anamorphic sunlight streak across lens!
      float anamorphic = exp(-abs(toSun.y) * 28.0) * exp(-abs(toSun.x) * 2.1) * 0.24;
      // Gentle opposite-corner optical ghost ring
      vec2 ghostPos = vec2(1.0) - uSunScreenPos;
      float ghostDist = length((clampedUv - ghostPos) * vec2(aspect, 1.0));
      float ghostRing = smoothstep(0.11, 0.06, abs(ghostDist - 0.12)) * 0.07;

      exposed += vec3(1.15, 0.88, 0.54) * (corona + anamorphic) * uSunFlare;
      exposed += vec3(0.75, 0.92, 1.08) * ghostRing * uSunFlare;
    }

    // 5. Luminous Bright-Daylight Filmic Tone Curve + Linear -> sRGB
    vec3 mapped = brightFilmic(exposed);
    // Preserve bright sunlit "silau" bloom when sensor genuinely overloads
    float overload = smoothstep(1.38, 2.5, max(exposed.r, max(exposed.g, exposed.b)));
    mapped = mix(mapped, vec3(1.0), overload * 0.45);

    color = linearToSrgb(mapped);
    color = iqGrade(color, clampedUv);

    // Subtle bodycam CMOS color response (keeps bright, lively sunlit palette!)
    float luma = getLuma(color);
    color = mix(vec3(luma), color, 0.94);
    color *= vec3(1.0, 1.0, 1.0);

    // 6. Adjustable Fine Sensor Grain (boosts naturally in dark CQB interior when ISO rises!)
    float isoBoost = 1.0 + max(0.0, uExposure - 1.15) * 1.4;
    vec2 grainCoord = gl_FragCoord.xy + vec2(fract(uTime * 23.17) * 512.0, fract(uTime * 37.91) * 512.0);
    float noise = (hash12(grainCoord) - 0.5) * 2.0;
    float shadowMask = mix(1.15, 0.45, luma);
    color += vec3(noise) * (uGrain * 0.048) * isoBoost * shadowMask;

    // 7. Adjustable Optical Vignette + Optional Curved Corner Darkening + Peripheral Damage Trauma Pulse
    vec2 vPos = (vUv - 0.5) * vec2(1.04, 1.04);
    float vDist = dot(vPos, vPos);
    float vigCurve = 1.0 - smoothstep(0.22, 0.94, vDist * (0.65 + uVignette * 0.72));
    float minCorner = mix(0.84, 0.34, uVignette);
    color *= mix(minCorner, 1.0, vigCurve) * outMask;

    if (uDamagePulse > 0.01) {
      float edgeBlood = smoothstep(0.16, 0.62, vDist) * uDamagePulse;
      color = mix(color, vec3(0.75, 0.06, 0.04), clamp(edgeBlood * 0.78, 0.0, 0.78));
    }

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
  }
`;

// =====================================================================================
//  FINAL "HD" PASS — decouples internal render resolution from the display resolution.
//   internal > display  → supersampling (4-tap box downsample = very smooth, crisp edges)
//   internal < display  → bicubic Catmull-Rom upscale (much sharper than browser bilinear)
//   then contrast-adaptive sharpening that never overshoots local min/max (no halos)
// =====================================================================================
const FINAL_FRAG = /* glsl */ `
  precision highp float;
  uniform sampler2D tSrc;
  uniform vec2 uSrcRes;
  uniform vec2 uOutRes;
  uniform float uScale;   // internal px / display px
  uniform float uSharpen; // 0..1
  varying vec2 vUv;

  vec3 tex(vec2 uv) { return texture2D(tSrc, uv).rgb; }

  vec3 bicubic(vec2 uv) {
    vec2 pos = uv * uSrcRes;
    vec2 center = floor(pos - 0.5) + 0.5;
    vec2 f = pos - center;
    vec2 f2 = f * f;
    vec2 f3 = f2 * f;
    vec2 w0 = -0.5 * f3 + f2 - 0.5 * f;
    vec2 w1 = 1.5 * f3 - 2.5 * f2 + 1.0;
    vec2 w3 = 0.5 * f3 - 0.5 * f2;
    vec2 w2 = 1.0 - w0 - w1 - w3;
    vec2 w12 = w1 + w2;
    vec2 tc0 = (center - 1.0) / uSrcRes;
    vec2 tc3 = (center + 2.0) / uSrcRes;
    vec2 tc12 = (center + w2 / w12) / uSrcRes;
    vec3 c = tex(vec2(tc12.x, tc0.y)) * (w12.x * w0.y)
           + tex(vec2(tc0.x, tc12.y)) * (w0.x * w12.y)
           + tex(tc12) * (w12.x * w12.y)
           + tex(vec2(tc3.x, tc12.y)) * (w3.x * w12.y)
           + tex(vec2(tc12.x, tc3.y)) * (w12.x * w3.y);
    float ws = (w12.x * w0.y) + (w0.x * w12.y) + (w12.x * w12.y) + (w3.x * w12.y) + (w12.x * w3.y);
    return c / ws;
  }

  void main() {
    vec3 c;
    if (uScale > 1.02) {
      // supersampled: 4 bilinear taps → 4x4 source footprint per display pixel
      vec2 o = 0.25 * uScale / uSrcRes;
      c = 0.25 * (tex(vUv + vec2( o.x,  o.y)) + tex(vUv + vec2(-o.x,  o.y))
                + tex(vUv + vec2( o.x, -o.y)) + tex(vUv + vec2(-o.x, -o.y)));
    } else if (uScale < 0.98) {
      c = bicubic(vUv);
    } else {
      c = tex(vUv);
    }

    if (uSharpen > 0.001) {
      vec2 d = 1.0 / uOutRes;
      vec3 n = tex(vUv + vec2(0.0,  d.y));
      vec3 s = tex(vUv + vec2(0.0, -d.y));
      vec3 e = tex(vUv + vec2( d.x, 0.0));
      vec3 w = tex(vUv + vec2(-d.x, 0.0));
      vec3 mn = min(min(min(n, s), min(e, w)), c);
      vec3 mx = max(max(max(n, s), max(e, w)), c);
      vec3 blur = (n + s + e + w) * 0.25;
      // a little stronger when we had to upscale
      float k = uSharpen * (1.35 + max(0.0, 1.0 - uScale) * 1.4);
      vec3 sharp = c + (c - blur) * k;
      // soft clamp to the local range (CAS-like): crisp edges, zero ringing
      vec3 lim = clamp(sharp, mn - 0.015, mx + 0.015);
      c = mix(sharp, lim, 0.85);
    }
    gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
  }
`;

export class BodycamPostPipeline {
  private worldRT: THREE.WebGLRenderTarget;
  private vmRT: THREE.WebGLRenderTarget;
  private postScene: THREE.Scene;
  private postCamera: THREE.OrthographicCamera;
  private material: THREE.ShaderMaterial;
  private quad: THREE.Mesh;
  private postRT: THREE.WebGLRenderTarget;
  private finalScene: THREE.Scene;
  private finalMaterial: THREE.ShaderMaterial;
  private finalQuad: THREE.Mesh;

  /** internal render pixel ratio (display DPR × user render-scale × adaptive quality scale) */
  public pixelRatio = 1;
  /** display (canvas) pixel ratio */
  public outputPixelRatio = 1;
  /** final-pass sharpening 0..1 */
  public sharpen = 0.6;
  /** 2 = full · 1 = lighter · 0 = minimal post (set by the PerfGovernor) */
  public quality: 0 | 1 | 2 = 2;

  constructor(renderer: THREE.WebGLRenderer, width: number, height: number, pixelRatio = 1, outputPixelRatio = 1) {
    this.pixelRatio = pixelRatio;
    this.outputPixelRatio = outputPixelRatio;
    const dpr = this.pixelRatio;
    const rtW = Math.max(2, Math.floor(width * dpr));
    const rtH = Math.max(2, Math.floor(height * dpr));

    const isWebGL2 = renderer.capabilities.isWebGL2;
    const texType = isWebGL2 ? THREE.HalfFloatType : THREE.UnsignedByteType;

    const depthTex = new THREE.DepthTexture(rtW, rtH);
    depthTex.type = isWebGL2 ? THREE.UnsignedIntType : THREE.UnsignedShortType;
    depthTex.format = THREE.DepthFormat;

    this.worldRT = new THREE.WebGLRenderTarget(rtW, rtH, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: texType,
      depthBuffer: true,
      depthTexture: depthTex,
    });

    // Viewmodel target with hardware 4x MSAA so sculpted polygon hands & gun sights stay razor clean!
    this.vmRT = new THREE.WebGLRenderTarget(rtW, rtH, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: texType,
      depthBuffer: true,
      samples: isWebGL2 ? 4 : 0,
    });

    // LDR target holding the fully post-processed (already sRGB) image at INTERNAL resolution
    this.postRT = new THREE.WebGLRenderTarget(rtW, rtH, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: THREE.UnsignedByteType,
      depthBuffer: false,
    });

    this.postScene = new THREE.Scene();
    this.postCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    this.finalScene = new THREE.Scene();
    this.finalMaterial = new THREE.ShaderMaterial({
      vertexShader: VERT_SHADER,
      fragmentShader: FINAL_FRAG,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        tSrc: { value: this.postRT.texture },
        uSrcRes: { value: new THREE.Vector2(rtW, rtH) },
        uOutRes: { value: new THREE.Vector2(Math.max(2, Math.floor(width * outputPixelRatio)), Math.max(2, Math.floor(height * outputPixelRatio))) },
        uScale: { value: 1 },
        uSharpen: { value: this.sharpen },
      },
    });
    this.finalQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.finalMaterial);
    this.finalScene.add(this.finalQuad);
    this.updateFinalUniforms(width, height);

    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT_SHADER,
      fragmentShader: FRAG_SHADER,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        tWorld: { value: this.worldRT.texture },
        tWorldDepth: { value: this.worldRT.depthTexture },
        tVm: { value: this.vmRT.texture },
        uResolution: { value: new THREE.Vector2(rtW, rtH) },
        uTime: { value: 0 },
        uEnabled: { value: 1 },
        uExposure: { value: 1.05 },
        uBrightness: { value: 1.18 },
        uGlareStrength: { value: 0.15 },
        uFocusDist: { value: 14.0 },
        uDofStrength: { value: 0.35 },
        uFisheye: { value: 0.42 },
        uBlackFrame: { value: 0.14 },
        uChromatic: { value: 0.35 },
        uGrain: { value: 0.32 },
        uVignette: { value: 0.35 },
        uDamagePulse: { value: 0.0 },
        uSunScreenPos: { value: new THREE.Vector2(0.5, 0.5) },
        uSunFlare: { value: 0.0 },
        uNear: { value: 0.1 },
        uFar: { value: 700.0 },
        uIqMix: { value: 1.0 },
        uProjScale: { value: new THREE.Vector2(1, 1) },
        uIqSteps: { value: 12 },
        uIqAoTaps: { value: 5 },
        uSunViewDir: { value: new THREE.Vector3(0.5, 0.7, 0.5) },
      },
    });

    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material);
    this.postScene.add(this.quad);
  }

  public setSize(width: number, height: number, pixelRatio?: number, outputPixelRatio?: number) {
    if (pixelRatio !== undefined) this.pixelRatio = pixelRatio;
    if (outputPixelRatio !== undefined) this.outputPixelRatio = outputPixelRatio;
    const dpr = this.pixelRatio;
    const rtW = Math.max(2, Math.floor(width * dpr));
    const rtH = Math.max(2, Math.floor(height * dpr));
    this.worldRT.setSize(rtW, rtH);
    this.vmRT.setSize(rtW, rtH);
    this.postRT.setSize(rtW, rtH);
    this.material.uniforms.uResolution.value.set(rtW, rtH);
    this.updateFinalUniforms(width, height);
  }

  private updateFinalUniforms(width: number, height: number) {
    const srcW = Math.max(2, Math.floor(width * this.pixelRatio));
    const srcH = Math.max(2, Math.floor(height * this.pixelRatio));
    const outW = Math.max(2, Math.floor(width * this.outputPixelRatio));
    const outH = Math.max(2, Math.floor(height * this.outputPixelRatio));
    const u = this.finalMaterial.uniforms;
    u.uSrcRes.value.set(srcW, srcH);
    u.uOutRes.value.set(outW, outH);
    u.uScale.value = srcW / outW;
  }

  /** actual internal / display pixel dimensions (for the HUD) */
  public getResolutionInfo() {
    const s = this.finalMaterial.uniforms.uSrcRes.value as THREE.Vector2;
    const o = this.finalMaterial.uniforms.uOutRes.value as THREE.Vector2;
    return { internalW: s.x, internalH: s.y, outW: o.x, outH: o.y };
  }

  public render(
    renderer: THREE.WebGLRenderer,
    worldScene: THREE.Scene,
    worldCamera: THREE.Camera,
    vmScene: THREE.Scene,
    vmCamera: THREE.Camera,
    renderViewmodel: boolean,
    params: BodycamParams
  ) {
    IQ.setPass('world');
    renderer.setRenderTarget(this.worldRT);
    renderer.setClearColor(0xa6daf7, 1);
    renderer.clear(true, true, true);
    renderer.render(worldScene, worldCamera);

    IQ.setPass('vm');
    renderer.setRenderTarget(this.vmRT);
    renderer.setClearColor(0x000000, 0);
    renderer.clear(true, true, true);
    if (renderViewmodel) {
      renderer.render(vmScene, vmCamera);
    }
    IQ.setPass('world');

    const u = this.material.uniforms;
    u.uTime.value = params.time;
    u.uEnabled.value = params.enabled ? 1.0 : 0.0;
    u.uExposure.value = params.exposure;
    u.uBrightness.value = params.brightness;
    u.uGlareStrength.value = this.quality === 0 ? 0 : params.glareStrength;
    u.uFocusDist.value = params.focusDistance;
    u.uDofStrength.value = params.sniperScoped || this.quality === 0 ? 0.0 : params.dofStrength * (this.quality === 1 ? 0.75 : 1);
    u.uFisheye.value = params.sniperScoped ? 0.05 : params.fisheyeStrength;
    u.uBlackFrame.value = params.sniperScoped ? 0.0 : params.blackFrameStrength;
    u.uChromatic.value = params.sniperScoped ? 0.0 : Math.max(0, params.chromaticStrength - 0.55) * 0.6;
    u.uGrain.value = params.grainStrength;
    u.uVignette.value = params.sniperScoped ? 0.25 : params.vignetteStrength;
    u.uNear.value = params.cameraNear;
    u.uFar.value = params.cameraFar;

    // IQ Elephant screen-space SDF lighting uniforms (sun direction in view space)
    u.uIqMix.value = IQ.mix;
    const wc = worldCamera as THREE.PerspectiveCamera;
    u.uProjScale.value.set(1 / wc.projectionMatrix.elements[0], 1 / wc.projectionMatrix.elements[5]);
    const q = this.quality;
    u.uIqSteps.value = q === 2 ? 12 : q === 1 ? 7 : 0;
    u.uIqAoTaps.value = q === 2 ? 5 : q === 1 ? 4 : 3;
    u.uSunViewDir.value.copy(IQ.sunDirWorld).transformDirection(wc.matrixWorldInverse);

    // pass 1: grade / DoF / SDF lighting … at INTERNAL resolution
    renderer.setRenderTarget(this.postRT);
    renderer.render(this.postScene, this.postCamera);

    // pass 2: HD resolve to the native-resolution canvas (supersample / bicubic + sharpen)
    this.finalMaterial.uniforms.uSharpen.value = this.sharpen;
    renderer.setRenderTarget(null);
    renderer.clear(true, true, false);
    renderer.render(this.finalScene, this.postCamera);
  }

  public dispose() {
    this.worldRT.depthTexture?.dispose();
    this.worldRT.dispose();
    this.vmRT.dispose();
    this.postRT.dispose();
    this.quad.geometry.dispose();
    this.finalQuad.geometry.dispose();
    this.finalMaterial.dispose();
    this.material.dispose();
  }
}
