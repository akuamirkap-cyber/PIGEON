import { useEffect, useRef, useState } from 'react';

interface Splat {
  id: number;
  x: number;
  y: number;
  size: number;
  rot: number;
  drip: number;
  life: number;
  hue: number;
}

let splatUrl: string | null = null;
/** one reusable glossy splat image painted on a canvas (dark arterial red with a wet highlight) */
function getSplatUrl(): string {
  if (splatUrl) return splatUrl;
  const S = 256;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d')!;
  const cx = S / 2;
  let seed = 9;
  const r = () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };
  const body = (fill: string | CanvasGradient) => {
    g.fillStyle = fill;
    g.beginPath();
    for (let i = 0; i <= 28; i++) {
      const a = (i / 28) * Math.PI * 2;
      const rr = 52 + r() * 30;
      const x = cx + Math.cos(a) * rr;
      const y = cx + Math.sin(a) * rr;
      if (i === 0) g.moveTo(x, y);
      else g.lineTo(x, y);
    }
    g.closePath();
    g.fill();
  };
  const grad = g.createRadialGradient(cx - 14, cx - 18, 6, cx, cx, 96);
  grad.addColorStop(0, '#b3121a');
  grad.addColorStop(0.55, '#7c0a10');
  grad.addColorStop(1, '#430407');
  body(grad);
  g.fillStyle = '#5a060b';
  for (let i = 0; i < 20; i++) {
    const a = r() * Math.PI * 2;
    const len = 70 + r() * 54;
    const w = 3 + r() * 8;
    const ex = cx + Math.cos(a) * len;
    const ey = cx + Math.sin(a) * len;
    g.beginPath();
    g.moveTo(cx - Math.sin(a) * w, cx + Math.cos(a) * w);
    g.lineTo(ex, ey);
    g.lineTo(cx + Math.sin(a) * w, cx - Math.cos(a) * w);
    g.closePath();
    g.fill();
    g.beginPath();
    g.arc(ex, ey, 2 + r() * 6, 0, Math.PI * 2);
    g.fill();
  }
  for (let i = 0; i < 22; i++) {
    const a = r() * Math.PI * 2;
    const d = 92 + r() * 34;
    g.beginPath();
    g.arc(cx + Math.cos(a) * d, cx + Math.sin(a) * d, 1.5 + r() * 5, 0, Math.PI * 2);
    g.fill();
  }
  // wet highlight
  g.fillStyle = 'rgba(255,170,170,0.28)';
  g.beginPath();
  g.ellipse(cx - 18, cx - 22, 22, 11, -0.6, 0, Math.PI * 2);
  g.fill();
  splatUrl = c.toDataURL('image/png');
  return splatUrl;
}

/**
 * Blood on the bodycam lens: every close-range kill splashes a few glossy splats that hang on the glass,
 * slowly run down and fade out (Dead Island / CoD style).
 */
export function BloodLens({ events }: { events: { id: number; power: number }[] }) {
  const [splats, setSplats] = useState<Splat[]>([]);
  const lastId = useRef(0);
  const counter = useRef(0);

  useEffect(() => {
    const fresh = events.filter((e) => e.id > lastId.current);
    if (fresh.length === 0) return;
    lastId.current = Math.max(...fresh.map((e) => e.id));
    const add: Splat[] = [];
    for (const e of fresh) {
      const n = e.power > 0.7 ? 3 : e.power > 0.35 ? 2 : 1;
      for (let i = 0; i < n; i++) {
        // blood lands mostly around the edges and the lower half of the lens
        const edge = Math.random() < 0.6;
        const x = edge ? (Math.random() < 0.5 ? Math.random() * 28 : 72 + Math.random() * 28) : 15 + Math.random() * 70;
        const y = 12 + Math.random() * 78;
        add.push({
          id: ++counter.current,
          x,
          y,
          size: 90 + e.power * 230 * (0.55 + Math.random() * 0.7),
          rot: Math.random() * 360,
          drip: 24 + Math.random() * 70 * e.power,
          life: 3.6 + Math.random() * 1.6 + e.power * 1.5,
          hue: Math.random(),
        });
      }
    }
    setSplats((s) => [...s, ...add].slice(-14));
    const ids = add.map((a) => a.id);
    const maxLife = Math.max(...add.map((a) => a.life));
    const t = window.setTimeout(() => setSplats((s) => s.filter((q) => !ids.includes(q.id))), maxLife * 1000 + 200);
    return () => window.clearTimeout(t);
  }, [events]);

  if (splats.length === 0) return null;
  const url = getSplatUrl();
  return (
    <div className="pointer-events-none fixed inset-0 z-[25] overflow-hidden">
      {splats.map((s) => (
        <div
          key={s.id}
          style={
            {
              left: `${s.x}%`,
              top: `${s.y}%`,
              width: s.size,
              height: s.size,
              backgroundImage: `url(${url})`,
              backgroundSize: 'contain',
              backgroundRepeat: 'no-repeat',
              transform: `translate(-50%, -50%) rotate(${s.rot}deg)`,
              '--drip': `${s.drip}px`,
              animation: `bloodLens ${s.life}s ease-out forwards`,
              filter: `saturate(${1 + s.hue * 0.3}) brightness(${0.62 + s.hue * 0.22})`,
            } as React.CSSProperties
          }
          className="absolute"
        />
      ))}
    </div>
  );
}
