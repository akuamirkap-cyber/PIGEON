import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Crosshair, Play, Shield, Swords, Users } from 'lucide-react';
import { buildModularCharacterRig, disposeSubtreeGeometries, updateCharacterAnimation } from '../skins';
import type { CharacterRig } from '../skins/animation';
import { FACES_META, OPEN_FACE_HEADS, SKINS_META } from '../skins/types';
import type { AnimMode, FaceId, SkinId } from '../skins/types';

interface Props {
  initialSkin?: SkinId;
  onStart: (skin: SkinId, face: FaceId) => void;
}

const MODES: { id: AnimMode; label: string }[] = [
  { id: 'idle', label: 'Siaga' },
  { id: 'walk', label: 'Jalan' },
  { id: 'chase', label: 'Lari' },
  { id: 'crouch', label: 'Jongkok' },
];

const DEFAULT_FACE: Record<SkinId, FaceId> = {
  boonie: 'grin',
  venom: 'fierce',
  gold: 'cool',
  reaper: 'fierce',
  police: 'cool',
  gunner: 'fierce',
  skill: 'smirk',
  spetsnaz: 'grin',
  silat: 'neutral',
};

/**
 * Pre-match lobby: pick the player's skin (full 3D preview with the pack's own walk / run animations).
 * The same skins are then used by the bots of both teams in the 5v5.
 */
export function SkinSelect({ initialSkin = 'police', onStart }: Props) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [skin, setSkin] = useState<SkinId>(initialSkin);
  const [face, setFace] = useState<FaceId>(DEFAULT_FACE[initialSkin]);
  const [mode, setMode] = useState<AnimMode>('chase');
  const live = useRef({ skin, face, mode, dirty: true });
  live.current.skin = skin;
  live.current.face = face;
  live.current.mode = mode;

  useEffect(() => {
    live.current.dirty = true;
  }, [skin, face]);

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(el.clientWidth, el.clientHeight);
    el.appendChild(renderer.domElement);
    renderer.domElement.style.display = 'block';

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(30, el.clientWidth / el.clientHeight, 0.1, 40);
    camera.position.set(0, 1.35, 5.2);
    camera.lookAt(0, 0.98, 0);
    scene.add(new THREE.HemisphereLight(0xdbeaff, 0x4a4338, 1.25));
    const key = new THREE.DirectionalLight(0xfff0d8, 2.6);
    key.position.set(3, 5, 4);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x8fb3ff, 1.1);
    rim.position.set(-4, 2.5, -3);
    scene.add(rim);
    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(1.5, 56),
      new THREE.MeshStandardMaterial({ color: 0x1b2230, roughness: 0.9, metalness: 0.1 })
    );
    floor.rotation.x = -Math.PI / 2;
    scene.add(floor);
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(1.5, 1.56, 64),
      new THREE.MeshBasicMaterial({ color: 0xfbbf24, side: THREE.DoubleSide })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.002;
    scene.add(ring);

    let rig: CharacterRig | null = null;
    let yaw = 0.5;
    let dragging = false;
    let lastX = 0;
    const down = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      yaw += (e.clientX - lastX) * 0.012;
      lastX = e.clientX;
    };
    const up = () => (dragging = false);
    renderer.domElement.addEventListener('pointerdown', down);
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);

    const clock = new THREE.Clock();
    let raf = 0;
    let t = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, clock.getDelta());
      t += dt;
      if (live.current.dirty) {
        live.current.dirty = false;
        if (rig) {
          scene.remove(rig.root);
          disposeSubtreeGeometries(rig.root);
        }
        rig = buildModularCharacterRig(
          {
            head: live.current.skin,
            face: live.current.face,
            torso: live.current.skin,
            pants: live.current.skin,
            shoes: live.current.skin,
          },
          0
        );
        scene.add(rig.root);
      }
      if (rig) {
        if (!dragging) yaw += dt * 0.5;
        rig.root.rotation.y = yaw;
        updateCharacterAnimation(rig, live.current.mode, t, 0, dt);
      }
      renderer.render(scene, camera);
    };
    loop();

    const onResize = () => {
      renderer.setSize(el.clientWidth, el.clientHeight);
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
    };
    window.addEventListener('resize', onResize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      renderer.domElement.removeEventListener('pointerdown', down);
      if (rig) disposeSubtreeGeometries(rig.root);
      renderer.dispose();
      renderer.forceContextLoss();
      if (renderer.domElement.parentNode === el) el.removeChild(renderer.domElement);
    };
  }, []);

  const meta = SKINS_META.find((s) => s.id === skin)!;
  const hasOpenFace = OPEN_FACE_HEADS.includes(skin);

  const pick = (id: SkinId) => {
    setSkin(id);
    setFace(DEFAULT_FACE[id]);
  };

  return (
    <div className="fixed inset-0 z-[60] flex flex-col overflow-hidden bg-[radial-gradient(ellipse_at_top,#1f2a3d_0%,#0b0f17_70%)] text-white">
      <div className="flex items-center justify-between gap-3 border-b border-white/10 px-5 py-3">
        <div>
          <div className="flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.25em] text-amber-300">
            <Swords className="h-3.5 w-3.5" /> Tim vs Tim • 5 vs 5
          </div>
          <h1 className="text-xl font-black tracking-tight sm:text-2xl">PILIH SKIN PEMAIN</h1>
        </div>
        <div className="hidden items-center gap-4 text-[11px] text-slate-300 md:flex">
          <span className="flex items-center gap-1.5">
            <Users className="h-4 w-4 text-sky-300" /> Tim Biru: kamu + 4 sekutu
          </span>
          <span className="flex items-center gap-1.5">
            <Shield className="h-4 w-4 text-red-300" /> Tim Merah: 5 musuh
          </span>
          <span className="flex items-center gap-1.5">
            <Crosshair className="h-4 w-4 text-amber-300" /> Kill pertama ke-40 menang
          </span>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 p-3 md:grid-cols-[250px_1fr_290px]">
        {/* skin list */}
        <div className="min-h-0 overflow-y-auto rounded-xl border border-white/10 bg-white/5 p-2">
          <div className="grid grid-cols-3 gap-1.5 md:grid-cols-1">
            {SKINS_META.map((s) => {
              const active = s.id === skin;
              return (
                <button
                  key={s.id}
                  onClick={() => pick(s.id)}
                  className={`flex items-center gap-2.5 rounded-lg border px-2.5 py-2 text-left transition ${
                    active ? 'border-amber-300 bg-amber-400/15' : 'border-white/10 bg-black/20 hover:bg-white/10'
                  }`}
                >
                  <span className="h-8 w-1.5 shrink-0 rounded-full" style={{ background: s.accentHex }} />
                  <span className="min-w-0">
                    <span className="block truncate text-[12px] font-black leading-tight">{s.name}</span>
                    <span className="block truncate text-[10px] text-slate-400">{s.role}</span>
                  </span>
                  <span className="ml-auto font-mono text-[10px] text-slate-500">{s.index}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* preview */}
        <div className="relative min-h-[260px] overflow-hidden rounded-xl border border-white/10 bg-gradient-to-b from-slate-800/60 to-slate-950/80">
          <div ref={mountRef} className="absolute inset-0 cursor-grab active:cursor-grabbing" />
          <div className="pointer-events-none absolute left-3 top-3">
            <div className="text-[10px] font-bold uppercase tracking-widest" style={{ color: meta.accentHex }}>
              {meta.codename}
            </div>
            <div className="text-lg font-black leading-tight">{meta.name}</div>
          </div>
          <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 rounded-full border border-white/10 bg-black/55 p-1 backdrop-blur">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`rounded-full px-3 py-1 text-[11px] font-bold transition ${
                  mode === m.id ? 'bg-amber-400 text-slate-950' : 'text-slate-200 hover:bg-white/10'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
          <div className="pointer-events-none absolute right-3 top-3 text-[10px] text-slate-400">seret untuk memutar</div>
        </div>

        {/* details */}
        <div className="flex min-h-0 flex-col gap-3 overflow-y-auto rounded-xl border border-white/10 bg-white/5 p-3">
          <p className="text-[12px] leading-relaxed text-slate-200">{meta.description}</p>
          <div>
            <div className="mb-1 text-[10px] font-black uppercase tracking-widest text-slate-400">Perlengkapan</div>
            <ul className="space-y-0.5 text-[11px] text-slate-300">
              {meta.gear.map((g) => (
                <li key={g} className="flex gap-1.5">
                  <span className="text-amber-300">•</span>
                  {g}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {meta.palette.map((p) => (
              <span key={p.hex} className="flex items-center gap-1 rounded-full bg-black/30 px-2 py-0.5 text-[10px] text-slate-300">
                <span className="h-2.5 w-2.5 rounded-full ring-1 ring-white/30" style={{ background: p.hex }} />
                {p.label}
              </span>
            ))}
          </div>
          {hasOpenFace && (
            <div>
              <div className="mb-1 text-[10px] font-black uppercase tracking-widest text-slate-400">Ekspresi wajah</div>
              <div className="grid grid-cols-3 gap-1">
                {FACES_META.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFace(f.id)}
                    className={`rounded-md border px-1 py-1 text-[10px] font-bold transition ${
                      face === f.id ? 'border-amber-300 bg-amber-400/20 text-amber-100' : 'border-white/10 bg-black/20 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    {f.shortName}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="mt-auto rounded-lg bg-black/30 p-2 text-[10px] leading-snug text-slate-400">
            Sekutu & musuh memakai skin lain dari pack yang sama — mereka berjalan, berlari, tertembak, dan jatuh sebagai ragdoll.
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center border-t border-white/10 p-3">
        <button
          onClick={() => onStart(skin, face)}
          className="flex items-center gap-2 rounded-xl bg-amber-400 px-8 py-3 text-sm font-black tracking-wide text-slate-950 shadow-lg shadow-amber-500/30 transition hover:scale-[1.03] hover:bg-amber-300 active:scale-95"
        >
          <Play className="h-4 w-4 fill-current" />
          MULAI TIM vs TIM 5v5
        </button>
      </div>
    </div>
  );
}
