import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import * as THREE from 'three';
import { createDriftCar, physicsStep, wheelRadius } from '../src/drift-physics.js';
import { createTrack } from '../src/rally-road.js';

const base={gas:1,brake:0,steer:0,handbrake:false,response:'responsive'};
function step(run,seconds,control={},observe) {
  for(let i=0;i<Math.round(seconds*120);i++) {
    run.step(physicsStep,{...base,...control});observe?.(run.state,run);
  }
  return run.state;
}
function intoSlide(car) {
  step(car,2.46);step(car,.13,{steer:-1,handbrake:true});
  step(car,.39,{steer:-1});return step(car,.7);
}

test('the player tune makes a real 0-100 run faster and spends less time on the automatic torque cut',()=>{
  const measure=(response)=>{
    const car=createDriftCar();let torqueCut=0;
    for(let i=1;i<1200;i++) {
      car.step(physicsStep,{...base,response});
      if(car.state.shifting)torqueCut++;
      if(car.state.speed*3.6>=100)return {time:i*physicsStep,torqueCut,displacement:car.state.z};
    }
    throw Error('100 km/h not reached');
  };
  const legacy=measure(undefined), current=measure('responsive');
  assert.ok(legacy.time-current.time>.94&&current.time<4.8);
  assert.ok(current.torqueCut<legacy.torqueCut*.72);
  assert.ok(current.displacement>52);
});

test('normal steering does not trigger the drift assist, but a handbrake tap can precede steering',()=>{
  const car=createDriftCar();car.state.vz=50/3.6;car.refresh();
  for(const wheel of Object.values(car.state.wheels))wheel.omega=car.state.speed/wheelRadius;
  assert.equal(step(car,.17,{steer:.26}).driftPhase,'grip');
  const speed=car.state.speed;
  assert.equal(step(car,.095,{handbrake:true}).driftPhase,'grip');
  const overlap=step(car,.110,{steer:-1});
  assert.equal(overlap.driftPhase,'entry');
  assert.ok(overlap.speed>speed*.91);
});

test('a short countersteer unwinds instead of pulling the car back into the same slide',()=>{
  const car=createDriftCar(), slide=intoSlide(car);
  assert.equal(slide.driftPhase,'slide');assert.ok(slide.beta>.39);
  const speed=slide.speed;
  step(car,.23,{steer:1});
  const exit=step(car,.45);
  assert.equal(exit.driftPhase,'grip');assert.ok(Math.abs(exit.beta)<.105&&exit.speed>speed*1.09);
  assert.equal(step(car,.62).driftPhase,'grip');
});

test('holding the opposite steer can intentionally link into a new slide',()=>{
  const car=createDriftCar();intoSlide(car);
  let linking=false;
  step(car,.94,{steer:1},state=>{if(state.driftPhase==='link')linking=true;});
  const next=step(car,.46);
  assert.ok(linking&&next.beta<-.27&&next.speed>20);
});

test('the new handling can finish and bank the opening drift without touching the wall',()=>{
  const course=createTrack(THREE).createRun();let impact=0;
  const observe=(_,run)=>{impact=Math.max(impact,run.impact);};
  for(const [duration,input] of [[2.46,{}],[.14,{steer:-1,handbrake:true}],[.41,{steer:-1}],[.84,{gas:.78}],[.24,{steer:1,gas:.59}],[1.35,{gas:.26}]]) {
    step(course,duration,input,observe);
  }
  assert.equal(impact,0);assert.equal(course.state.driftPhase,'grip');
  assert.ok(course.snapshot().drift.total>=170);
});