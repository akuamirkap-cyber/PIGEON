import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { createDriftScore, driftMedal, medalGoals } from '../src/drift-score.js';

const clean={speed:17,beta:.46,forward:14,along:15,slip:.82,roughness:0,impact:0,outside:false,linking:false};
function play(score, seconds, change={}) {
  for(let i=0;i<Math.round(seconds*120);i++) score.step(1/120,{...clean,...change});
  return score.snapshot();
}

test('opposite slides connect through the grace window then bank once on recovery',()=>{
  const score=createDriftScore();
  const one=play(score,1.1);
  assert.equal(one.total,0);assert.ok(one.points>200);
  const carry=play(score,.76,{beta:0,linking:true});
  assert.equal(carry.phase,'carry');assert.equal(carry.points,one.points);assert.ok(carry.grace>0);
  const two=play(score,.84,{beta:-.49});
  assert.equal(two.links,1);assert.ok(two.multiplier>1.9);assert.ok(two.points>one.points*2);
  const finish=play(score,1.5,{beta:0});
  assert.equal(finish.phase,'banked');assert.equal(finish.total,two.points);assert.equal(finish.top,two.points);assert.equal(finish.allLinks,1);
  assert.equal(play(score,4,{beta:.05}).total,finish.total);
});

test('the outside zone pays more for identical angle and speed',()=>{
  const base=play(createDriftScore(),1.1), outside=play(createDriftScore(),1.1,{outside:true});
  assert.ok(outside.outer);
  assert.ok(Math.abs(outside.points/base.points-1.48)<.015);
});

test('outside points are counted as bonus only after the combo is banked',()=>{
  const run=createDriftScore();
  const open=play(run,1.0,{outside:true});
  assert.equal(open.bonusPoints,0);assert.ok(open.pendingBonus>0);
  assert.equal(play(run,.1,{impact:3}).bonusPoints,0);
  run.reset();const second=play(run,1.0,{outside:true});run.finish();
  assert.equal(run.snapshot().bonusPoints,second.pendingBonus);
  assert.equal(run.snapshot().pendingBonus,0);
});

test('wall impact and spin lose the chain; stationary or backwards motion cannot farm points',()=>{
  const wall=createDriftScore(),spin=createDriftScore(),idle=createDriftScore();
  play(wall,1);play(spin,1);
  const impact=play(wall,.018,{impact:2});
  assert.equal(impact.phase,'lost');assert.equal(impact.cause,'DINDING');assert.equal(impact.total,0);
  assert.equal(play(spin,.39,{beta:1.37,forward:0}).cause,'SPIN');
  assert.equal(play(idle,3,{along:-8}).points,0);
  assert.equal(play(idle,3,{speed:2,forward:1}).total,0);
});

test('a finish banks a live clean chain and medals respect score thresholds',()=>{
  const score=createDriftScore();const points=play(score,1.2).points;
  score.finish();assert.equal(score.snapshot().total,points);
  score.reset();assert.equal(score.snapshot().total,0);
  assert.equal(driftMedal(medalGoals.bronze-1),null);
  assert.equal(driftMedal(medalGoals.bronze),'bronze');
  assert.equal(driftMedal(medalGoals.silver),'silver');
  assert.equal(driftMedal(medalGoals.gold),'gold');
});