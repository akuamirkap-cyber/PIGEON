import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import * as THREE from 'three';
import { createRallyCarModel } from '../src/rally-model.js';
import { createDriftCar, physicsStep } from '../src/drift-physics.js';

const gradient = { addColorStop() {} };
const canvasFactory = () => ({
  getContext: () => new Proxy({ createLinearGradient: () => gradient, createRadialGradient: () => gradient }, {
    get: (target, key) => target[key] ?? (() => undefined),
  }),
});

function createRig() {
  const car = createRallyCarModel({ THREE, canvasFactory, cockpit: true });
  const get = name => car.getObjectByName(name);
  const step = (frames, state = {}) => {
    for (let i = 0; i < frames; i++) car.userData.tick(1 / 60, { speed: 0, steer: 0, gear: '1', ...state });
    car.updateMatrixWorld(true);
  };
  const at = name => get(name).getWorldPosition(new THREE.Vector3());
  function vertices(hand, mesh, relativeTo) {
    const part = get(hand).getObjectByName(mesh);
    const positions = part.geometry.attributes.position;
    return Array.from({ length: positions.count }, (_, i) => {
      const world = part.localToWorld(new THREE.Vector3().fromBufferAttribute(positions, i));
      return get(relativeTo).worldToLocal(world);
    });
  }
  const checkAnchor = (hand, anchor) => assert.ok(at(hand).distanceTo(at(anchor)) < 1e-6, `${hand} follows ${anchor}`);
  return { car, get, step, vertices, checkAnchor };
}

test('both hands follow the rotating wheel, with fingers and thumbs around opposite sides of the rim', () => {
  const rig = createRig();
  for (const steer of [0, 1, -1]) {
    rig.step(44, { steer });
    for (const side of [1, -1]) {
      const hand = `stickHand${side}`;
      rig.checkAnchor(hand, `handGrip${side}`);
      for (const digit of ['seamlessGloveFinger1', 'seamlessGloveFinger2', 'seamlessGloveFinger3', 'seamlessGloveFinger4', 'opposedThumb']) {
        const points = rig.vertices(hand, digit, 'steeringWheel');
        const gap = Math.min(...points.map(p => Math.hypot(Math.hypot(p.x, p.y) - .257, p.z)));
        assert.ok(gap > .028 && gap < .041, `${digit} contacts the 36 mm rim without passing through it`);
        if (digit === 'opposedThumb') assert.ok(points.at(-1).z < -.015);
        else assert.ok(points.some(p => p.z > .048), 'finger loops behind the rim');
      }
    }
  }
});

test('the right glove caps the shifter with its index and thumb while the left hand stays planted', () => {
  const rig = createRig();
  rig.step(35, { inspectGear: true });
  assert.deepEqual(rig.car.userData.driverAction, { mode: 'gear', reach: 1, contact: true });
  rig.checkAnchor('stickHand-1', 'gearHandAnchor');
  rig.checkAnchor('stickHand1', 'handGrip1');
  const index = rig.vertices('stickHand-1', 'seamlessGloveFinger1', 'gearShifter');
  const thumb = rig.vertices('stickHand-1', 'opposedThumb', 'gearShifter').at(-1);
  assert.ok(Math.max(...index.map(p => p.y)) > .354, 'index wraps over the knob');
  assert.ok(thumb.y > .293 && thumb.y < .354 && thumb.z < -.04, 'thumb lies over the driver-facing knob face');
  for (const digit of [2, 3, 4]) {
    const points = rig.vertices('stickHand-1', `seamlessGloveFinger${digit}`, 'gearShifter');
    const nearest = Math.min(...points.map(p => Math.hypot(p.x, p.z)));
    assert.ok(nearest > .026 && nearest < .042, 'lower fingers curl close to the black grip');
  }
  rig.step(26);
  rig.checkAnchor('stickHand-1', 'handGrip-1');
});

test('a real shift drives the lever while the right hand is attached, then returns it to the wheel', () => {
  const rig = createRig();
  rig.step(1);
  rig.step(24, { speed: 8, gear: '2' });
  assert.equal(rig.car.userData.driverAction.mode, 'gear');
  assert.equal(rig.car.userData.driverAction.contact, true);
  assert.ok(Math.abs(rig.get('gearShifter').rotation.x) > .12);
  rig.checkAnchor('stickHand-1', 'gearHandAnchor');
  rig.checkAnchor('stickHand1', 'handGrip1');
  rig.step(65, { speed: 8, gear: '2' });
  rig.checkAnchor('stickHand-1', 'handGrip-1');
  rig.step(34, { gear: '2', handbrake: true });
  assert.equal(rig.car.userData.driverAction.mode, 'brake');
  rig.checkAnchor('stickHand-1', 'brakeHandAnchor');
  rig.step(24, { gear: '2', handbrake: false, serviceBrake: true });
  rig.checkAnchor('stickHand-1', 'handGrip-1');
});

test('wheel mesh pivots use the individual simulated tyre angle and spin', () => {
  const rig=createRig(), drive=createDriftCar();
  for(let i=0;i<231;i++) drive.step(physicsStep,{gas:true,brake:false,steer:i<150?0:1,handbrake:i>=208});
  rig.step(1,drive.state);
  for(const id of ['FL','FR','RL','RR']) {
    const pivot=rig.get(`wheel${id}`), tyre=drive.state.wheels[id];
    assert.equal(pivot.rotation.y,tyre.angle);
    assert.equal(pivot.getObjectByName('axle').rotation.x,tyre.spin);
  }
  assert.equal(drive.state.wheels.RL.omega,0);
  assert.notEqual(drive.state.wheels.FL.spin,drive.state.wheels.RL.spin);
});