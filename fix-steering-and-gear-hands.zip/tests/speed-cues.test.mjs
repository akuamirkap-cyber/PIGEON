import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { PerspectiveCamera, Vector3 } from 'three';
import { createDriftCar, physicsStep, wheelRadius } from '../src/drift-physics.js';
import { bumperLens, chaseLens, courseMarkerInterval, createDriveClock, createRenderBudget, lensRush, roadExposure, roadFlow, toKmh, windRush } from '../src/speed-cues.js';

test('100 km/h still represents 27.78 metres of world movement per second',()=>{
  const meters=100/3.6, clock=createDriveClock(physicsStep);
  const car=createDriftCar();car.state.vz=meters;car.refresh();
  for(const wheel of Object.values(car.state.wheels)) wheel.omega=meters/wheelRadius;
  assert.equal(toKmh(car.state.speed),100);
  let distance=0;
  for(const elapsed of [.43,.37,.20])clock.advance(elapsed,dt=>{
    car.step(dt,{gas:0,brake:0,steer:0,handbrake:false});distance+=car.state.speed*dt;
  });
  assert.ok(Math.abs(distance-car.state.z)<1e-5);
  assert.ok(distance>26&&distance<meters);
});

test('low rendering frame rates do not slow acceleration and suspended tabs do not jump forward',()=>{
  const gas={gas:true,brake:false,steer:0,handbrake:false};
  const normal=createDriftCar(), slow=createDriftCar();
  const a=createDriveClock(physicsStep),b=createDriveClock(physicsStep);
  for(let i=0;i<336;i++)a.advance(1/60,dt=>normal.step(dt,gas));
  for(const elapsed of [1.43,.30,.49,.34,1.21,.55,1.28])b.advance(elapsed,dt=>slow.step(dt,gas));
  assert.ok(Math.abs(normal.state.z-slow.state.z)<1e-7);
  assert.equal(toKmh(normal.state.speed),toKmh(slow.state.speed));
  const previous=slow.state.z;
  b.advance(2.5,dt=>slow.step(dt,gas));
  assert.equal(slow.state.z,previous);
});

test('near-road perspective, optical exposure and wind build towards highway speed',()=>{
  assert.equal(lensRush(0),0);assert.equal(roadFlow(25/3.6),0);assert.equal(windRush(0),0);
  assert.ok(roadFlow(100/3.6)>.9&&windRush(100/3.6)>.6);
  const slow=chaseLens(0,0,0), fast=chaseLens(0,lensRush(100/3.6),0);
  assert.ok(fast.field>slow.field+10);
  assert.ok(fast.height<slow.height-1&&fast.following<slow.following-2);
  assert.ok(fast.lookAhead>slow.lookAhead+3);
  assert.ok(slow.height<4&&fast.height<2.7);
  assert.ok(bumperLens(0,lensRush(100/3.6)).height<.63);
});

test('stationary markers have twice the pass frequency at 100 km/h and their exposure uses world metres',()=>{
  const slow=50/3.6,fast=100/3.6;
  assert.equal((fast/courseMarkerInterval)/(slow/courseMarkerInterval),2);
  assert.equal(roadExposure(fast),roadExposure(slow)*2);
  const optics=bumperLens(0,0), lens=new PerspectiveCamera(optics.field,16/9,.058,640);
  const marker=new Vector3(2.2,0,9.5);
  function project(travel){
    lens.position.set(0,optics.height,travel);lens.lookAt(0,optics.height+optics.pitch,travel+1);
    lens.updateMatrixWorld(true);return marker.clone().project(lens);
  }
  const before=project(0), at50=project(roadExposure(slow)), at100=project(roadExposure(fast));
  assert.ok(at100.distanceTo(before)>at50.distanceTo(before)*1.94);
});

test('render resolution responds to sustained slow frames and recovers after stable frame times',()=>{
  const budget=createRenderBudget();
  budget.sample(.23);assert.equal(budget.scale,1);
  for(let i=0;i<20;i++)budget.sample(.07);
  assert.ok(budget.scale<.85);
  const lower=budget.scale;
  for(let i=0;i<240;i++)budget.sample(.016);
  assert.equal(budget.scale,lower);
  for(let i=0;i<40;i++)budget.sample(.016);
  assert.ok(budget.scale>lower);
});