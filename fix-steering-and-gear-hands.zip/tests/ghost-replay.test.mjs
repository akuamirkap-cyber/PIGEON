import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import * as THREE from 'three';
import { createTrack } from '../src/rally-road.js';
import { buildGhostReference, createGhostPlayback, coachingCue, ghostFollowTime } from '../src/ghost-replay.js';
import { physicsStep } from '../src/drift-physics.js';

const track=createTrack(THREE), reference=buildGhostReference(track);

test('the Ghost beats 42 seconds while scoring bonus in at least six sectors without impacts',()=>{
  const result=reference.result;
  assert.equal(result.finished,true);assert.equal(result.distance,track.length);
  assert.ok(result.time>30&&result.time<42);
  assert.ok(result.drift.total>=15000&&result.drift.allLinks>=2);
  assert.ok(result.drift.bonusPoints>4250);
  assert.ok(reference.bonusSeconds>=18&&reference.zoneSeconds.filter(seconds=>seconds>=.25).length>=6);
  assert.ok(reference.impact<.01&&reference.activeDrift>=20);
  assert.ok(reference.frames.every(frame=>frame.state.gear!=='R'&&Number.isFinite(frame.state.vx)&&Number.isFinite(frame.state.vz)));
});

test('Ghost coaching displays real pedal inputs, handbrake, linked drifts, and countersteer',()=>{
  const cues=new Set(reference.frames.map(coachingCue));
  for(const cue of ['brake','trailBrake','handbrake','counter','link','hold','exit','bonus','finish'])assert.ok(cues.has(cue),cue);
  const braking=reference.frames.find((frame,index)=>index+12<reference.frames.length&&Number(frame.input.brake)>.5&&
    reference.frames[index+12].state.speed<frame.state.speed-.5);
  assert.ok(braking,'a real brake input reduces simulated velocity');
  assert.ok(reference.frames.some(frame=>frame.input.handbrake&&frame.state.wheels.RL.omega===0&&frame.state.wheels.FL.omega>10));
});

test('pace comparisons use the same track distance and bonus shortcuts come from actual scoring',()=>{
  assert.equal(reference.timeAtDistance(0),0);
  let last=0;
  for(let distance=20;distance<track.length;distance+=20) {
    const time=reference.timeAtDistance(distance);
    assert.ok(time>last&&time<reference.result.time);last=time;
  }
  assert.equal(reference.timeAtDistance(track.length),reference.result.time);
  const playback=createGhostPlayback(reference);
  for(const clip of reference.clips) {
    playback.seek(clip.time+.82);
    assert.equal(playback.frame.bonusZone+1,clip.zone);
    assert.equal(coachingCue(playback.frame),'bonus');
  }
});

test('playback can seek, use half-speed in the spectator view and return to its starting pose',()=>{
  const playback=createGhostPlayback(reference);
  playback.seek(12);
  const viewed=playback.pose();
  playback.setRate(.5);playback.advance(1,true);assert.equal(playback.time,12.5);
  playback.advance(1,false);assert.equal(playback.time,13.5);
  playback.seek(12);assert.deepEqual(playback.pose(),viewed);
  playback.seek(reference.duration+30);assert.equal(playback.ended,true);
  playback.seek(0);assert.equal(playback.ended,false);assert.equal(playback.frame.telemetry.speed,0);
});

test('the Ghost and player do not share motion, scoring, or the current lap',()=>{
  const player=track.createRun();player.reset('practice');
  for(let i=0;i<360;i++)player.step(physicsStep,{gas:true,brake:false,steer:0,handbrake:false});
  const original=player.snapshot();
  const ghost=createGhostPlayback(reference);ghost.seek(reference.duration);
  assert.equal(ghost.frame.telemetry.finished,true);
  assert.deepEqual(player.snapshot(),original);
  assert.equal(original.mode,'practice');assert.equal(original.finished,false);
});

test('follow positions advance on every render even when a HUD sample would repeat',()=>{
  const ghost=createGhostPlayback(reference), hz=144, origin=9;
  let previous=null, smallest=Infinity, largest=0;
  for(let i=0;i<hz;i++) {
    const actual=origin+i/hz, fixed=Math.floor(actual/physicsStep)*physicsStep;
    ghost.seek(ghostFollowTime(fixed,0,(actual-fixed)/physicsStep));
    const {x,z}=ghost.sample();
    if(previous) {
      const displacement=Math.hypot(x-previous.x,z-previous.z);
      smallest=Math.min(smallest,displacement);largest=Math.max(largest,displacement);
    }
    previous={x,z};
  }
  assert.ok(smallest>.025&&largest<.20);
});

test('wheel interpolation follows rotation across the 2-pi wrap without changing saved frames',()=>{
  const frames=reference.frames;
  const i=frames.findIndex((frame,j)=>j+1<frames.length&&Math.abs(frames[j+1].state.wheels.FL.spin-frame.state.wheels.FL.spin)>Math.PI);
  assert.ok(i>=0);
  const a=frames[i],b=frames[i+1],before=a.state.wheels.FL.spin,gh=createGhostPlayback(reference);
  gh.seek((a.time+b.time)*.5);
  const wheel=gh.sample().wheels.FL, difference=Math.atan2(Math.sin(wheel.spin-before),Math.cos(wheel.spin-before));
  assert.ok(difference>0&&difference<1.4);
  assert.equal(a.state.wheels.FL.spin,before);
});