import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import * as THREE from 'three';
import { createDriftCar, physicsStep, wheelRadius } from '../src/drift-physics.js';
import { createTrack } from '../src/rally-road.js';

const track=createTrack(THREE);
const input={gas:1,brake:0,steer:0,handbrake:false,response:'smooth',assist:true};
function advance(run,seconds,change={},observe) {
  for(let i=0;i<Math.round(seconds/physicsStep);i++) {
    run.step(physicsStep,{...input,...change});observe?.(run.state);
  }
  return run.state;
}
function launch(response='smooth',target=100) {
  const car=createDriftCar();
  for(let i=1;i<=2400;i++) {
    car.step(physicsStep,{...input,response});
    if(car.state.speed*3.6>=target)return {car,time:i*physicsStep};
  }
  throw Error(`${target} km/h not reached`);
}

test('gas comes in gradually yet reaches a real 100 and 140 km/h sooner than the previous tune',()=>{
  const fresh=createDriftCar();
  assert.ok(advance(fresh,.05).throttle<.4&&fresh.state.throttle>.3);
  assert.ok(advance(fresh,1).throttle>.99);
  assert.ok(launch().time<launch('responsive').time-.11);
  assert.ok(launch('smooth',140).time<launch('responsive',140).time-.44);
});

test('one second off the gas coasts with no brake and barely loses speed',()=>{
  const {car}=launch(), initial=car.state.speed, start=car.state.z;
  let peak=initial;
  const lift=advance(car,.1,{gas:0},s=>{peak=Math.max(peak,s.speed);});
  assert.ok(lift.throttle>.49&&lift.throttle<.63);
  const coast=advance(car,.9,{gas:0},s=>{peak=Math.max(peak,s.speed);});
  assert.equal(coast.coasting,true);
  assert.equal(coast.serviceBrake,false);assert.equal(coast.brake,0);
  assert.ok(coast.speed*3.6>97.8&&coast.speed<initial);
  assert.ok((peak-initial)*3.6<1.65&&coast.z-start>27);
  const afterOneSecond=coast.speed;
  const previous=launch('responsive').car;
  advance(previous,1,{gas:0,response:'responsive'});assert.ok(afterOneSecond>previous.state.speed+.45);
  advance(car,2,{gas:0});advance(previous,2,{gas:0,response:'responsive'});
  assert.ok(car.state.speed>previous.state.speed+1.25);
});

test('a fresh brake press overrides the throttle tail, while a short lift in a drift does not cut the slide',()=>{
  const {car}=launch(), speed=car.state.speed;
  const brake=advance(car,.22,{gas:1,brake:1});
  assert.equal(brake.coasting,false);assert.equal(brake.serviceBrake,true);
  assert.ok(brake.throttle<.015&&brake.speed<speed-1.3);

  const drift=createDriftCar();advance(drift,2.36);advance(drift,.13,{steer:-1,handbrake:true});advance(drift,.4,{steer:-1});
  const before=advance(drift,.67).speed;
  const lift=advance(drift,.22,{gas:0});
  assert.ok(Math.abs(lift.beta)>.3&&lift.speed>before*.955);
  assert.equal(lift.serviceBrake,false);
  const recovery=advance(drift,.9,{gas:0});
  assert.ok(recovery.coasting&&recovery.driftPhase==='grip'&&recovery.speed>before*.88);
});

test('effective initiation and exit do not require a single exact keyboard timing',()=>{
  for(const launchTime of [2.12,2.48]) for(const hold of [.50,.80]) {
    const run=track.createRun();let maxHit=0;
    const inspect=()=>{maxHit=Math.max(maxHit,run.impact);};
    advance(run,launchTime,{},inspect);
    advance(run,.13,{steer:-1,handbrake:true},inspect);advance(run,.37,{steer:-1},inspect);advance(run,hold,{},inspect);
    advance(run,.22,{steer:1,gas:0},inspect);advance(run,1.45,{gas:0},inspect);
    assert.equal(maxHit,0);assert.equal(run.state.driftPhase,'grip');
    assert.ok(run.snapshot().drift.total>=100&&run.snapshot().speed>=57);
  }
});

test('a shallow brush keeps speed, but a hard barrier impact still costs momentum',()=>{
  const hit=heading=>{
    const run=track.createRun(), frame=track.at(track.start), s=run.state, speed=17;
    s.x=frame.x+frame.tz*8.38;s.z=frame.z-frame.tx*8.38;s.yaw=Math.atan2(frame.tx,frame.tz)+heading;
    const cos=Math.cos(s.yaw),sin=Math.sin(s.yaw);
    s.speed=s.forwardSpeed=speed;s.vx=speed*sin;s.vz=speed*cos;
    for(const wheel of Object.values(s.wheels)) {
      const x=wheel.side*1.038,z=wheel.front?1.665:-1.433;
      wheel.x=s.x+x*cos+z*sin;wheel.z=s.z-x*sin+z*cos;wheel.omega=speed/wheelRadius;
    }
    advance(run,physicsStep,{gas:0});return run;
  };
  const light=hit(.055),hard=hit(.90);
  assert.ok(light.impact>.3&&light.impact<1.45&&light.state.speed>16.5);
  assert.ok(hard.impact>8&&hard.state.speed<10);
});