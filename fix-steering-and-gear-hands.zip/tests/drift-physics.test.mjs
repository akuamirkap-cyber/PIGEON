import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { createDriftCar, physicsStep, wheelRadius } from '../src/drift-physics.js';

const throttle = { gas: true, brake: false, steer: 0, handbrake: false };
function advance(car, seconds, command = throttle, observe) {
  for(let i=0;i<Math.round(seconds/physicsStep);i++) {
    car.step(physicsStep,{...throttle,...command});
    observe?.(car.state);
  }
  return car.state;
}

test('automatic transmission upshifts with a torque dip and driven tyres can outspin the road speed', () => {
  const car=createDriftCar(), shifts=new Set(), gears=new Set();
  let wheelspin=0;
  const state=advance(car,3.2,throttle,s=>{
    gears.add(s.gear);if(s.shifting) shifts.add(s.gear);
    wheelspin=Math.max(wheelspin,s.wheels.RL.omega*wheelRadius-s.wheels.FL.omega*wheelRadius);
  });
  assert.deepEqual([...gears],['1','2','3']);
  assert.deepEqual([...shifts],['2','3']);
  assert.ok(state.z>25&&state.speed>16&&Math.abs(state.x)<.15);
  assert.ok(Math.abs(state.wheels.FL.omega*wheelRadius-state.speed)<.45);
  assert.ok(wheelspin>2&&wheelspin<14);
  assert.ok(state.wheels.RL.load+state.wheels.RR.load>state.wheels.FL.load+state.wheels.FR.load);
});

test('the handbrake locks the rear only, retaining linear momentum until countersteer catches the slide', () => {
  const car=createDriftCar();
  const entry=advance(car,3).speed;
  const locked=advance(car,.56,{steer:-1,handbrake:true});
  assert.equal(locked.wheels.RL.omega,0);
  assert.equal(locked.wheels.RR.omega,0);
  assert.ok(locked.wheels.FL.omega>20);
  assert.ok(locked.wheels.FR.angle<locked.wheels.FL.angle&&locked.wheels.FR.angle<0);
  assert.ok(locked.speed>entry*.73);
  let peak=0;
  const catchState=advance(car,.34,{steer:1},s=>{peak=Math.max(peak,s.beta);});
  assert.ok(peak>.35&&peak<.72);
  assert.ok(catchState.steerAngle>0&&catchState.wheels.RL.omega>18);
  assert.ok(catchState.yaw<-.3&&catchState.vz>Math.abs(catchState.vx)*2);
  const straightening=advance(car,.96,{gas:false});
  assert.ok(Math.abs(straightening.beta)<.13);
  assert.ok(straightening.speed>entry*.73);
});

test('foot brake decelerates before reverse and the wheels then spin backwards', () => {
  const car=createDriftCar();
  advance(car,2.6);
  const slowed=advance(car,.45,{gas:false,brake:true});
  assert.notEqual(slowed.gear,'R');
  assert.ok(slowed.accelLong<-5&&slowed.forwardSpeed>0);
  assert.ok(slowed.wheels.FL.omega>0&&slowed.wheels.RL.omega>0);
  const reversed=advance(car,2.8,{gas:false,brake:true});
  assert.equal(reversed.gear,'R');
  assert.ok(reversed.forwardSpeed<-.7&&reversed.wheels.FL.omega<0&&reversed.wheels.RL.omega<0);
});

test('each tyre samples its contact patch and loose ground transfers less braking force', () => {
  const asphalt=createDriftCar(), mixed=createDriftCar(x=>x>0?{grip:.65,roughness:1,height:-.025}:{grip:1,roughness:0,height:0});
  mixed.reset();advance(mixed,.08,{gas:false});
  assert.equal(mixed.state.wheels.FL.roughness,1);
  assert.equal(mixed.state.wheels.FR.roughness,0);
  assert.equal(mixed.state.wheels.FL.height,-.025);
  const loose=createDriftCar(()=>({grip:.59,roughness:1,height:-.025}));
  for(const car of [asphalt,loose]) {car.state.vz=17;for(const wheel of Object.values(car.state.wheels))wheel.omega=17/wheelRadius;car.refresh();}
  assert.ok(advance(asphalt,.94,{gas:false,brake:true}).speed<advance(loose,.94,{gas:false,brake:true}).speed-1.3);
});

test('a short clutch-free handbrake entry can hold angle on throttle and link the opposite direction', () => {
  const car=createDriftCar();
  advance(car,3);
  advance(car,.20,{steer:-1,handbrake:true});
  advance(car,.30,{steer:-1});
  let onAngle=0;
  const first=advance(car,1.5,{},s=>{if(s.beta>.31&&s.beta<.62)onAngle+=physicsStep;});
  assert.ok(onAngle>1.03&&first.beta>.34&&first.driftPhase==='slide');
  let sawLink=false;
  const flip=advance(car,.9,{steer:1},s=>{sawLink||=s.driftPhase==='link';});
  assert.ok(sawLink&&flip.beta<-.21&&flip.driftDirection===-1);
  const second=advance(car,.84);
  assert.ok(second.beta<-.36&&second.driftPhase==='slide');
  const exit=advance(car,1.18,{gas:0});
  assert.ok(Math.abs(exit.beta)<.10&&exit.driftPhase==='grip'&&exit.speed>14);
});

test('brake tap and power entries are possible without a long handbrake pull', () => {
  for(const plan of [[.24,.38,1],[.68,.30,0]]) {
    const car=createDriftCar();advance(car,3);
    advance(car,plan[0],{steer:-.85,brake:plan[2]});
    advance(car,plan[1],{steer:-.85});
    const slide=advance(car,1.14,{gas:.85});
    assert.ok(slide.beta>.29&&slide.driftPhase==='slide'&&slide.speed>13);
  }
});

test('short grip corrections and straight acceleration do not start a drift', () => {
  const car=createDriftCar();advance(car,2.7);
  for(let i=0;i<4;i++) {advance(car,.09,{steer:i%2?1:-1});advance(car,.27);}
  assert.equal(car.state.driftPhase,'grip');
  assert.ok(Math.abs(car.state.beta)<.1);
});

test('a quick steering feint can transfer weight and trigger the opposite slide', () => {
  const car=createDriftCar();advance(car,3);advance(car,.24,{steer:1});
  assert.equal(car.state.driftPhase,'grip');
  const entry=advance(car,.09,{steer:-1});
  assert.equal(entry.driftPhase,'entry');
  assert.equal(entry.driftDirection,1);
  advance(car,.32,{steer:-1});
  assert.ok(advance(car,.84).beta>.32);
});