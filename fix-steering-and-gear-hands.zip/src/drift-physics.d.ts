export type DriverInput = { gas: boolean | number; brake: boolean | number; steer: number; handbrake: boolean; assist?: boolean; response?: 'responsive' | 'smooth' };
export type Surface = { grip: number; roughness: number; height: number };
export type WheelId = 'FL' | 'FR' | 'RL' | 'RR';
export type DriftWheel = {
  front: boolean; side: number; x: number; z: number; angle: number; omega: number; spin: number;
  along: number; across: number; slip: number; load: number; roughness: number; height: number;
};
export type DriftState = {
  x: number; z: number; yaw: number; vx: number; vz: number; yawRate: number; speed: number;
  forwardSpeed: number; lateralSpeed: number; beta: number; steer: number; steerAngle: number;
  accelLong: number; accelLat: number; throttle: number; brake: number; rearLock: number; rev: number;
  gear: string; shifting: boolean; handbrake: boolean; serviceBrake: boolean; rearSlip: number; tireNoise: number;
  roughness: number; wheels: Record<WheelId, DriftWheel>;
  driftBlend: number; driftPhase: 'grip' | 'entry' | 'slide' | 'link' | 'exit'; driftDirection: number; coasting: boolean;
};
export const wheelRadius: number;
export const physicsStep: number;
export function createDriftCar(surfaceAt?: (x: number, z: number) => Surface): {
  state: DriftState;
  step(dt: number, input: DriverInput): void;
  reset(x?: number, z?: number, yaw?: number): void;
  refresh(): void;
};