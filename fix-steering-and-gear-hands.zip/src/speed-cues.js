const clamp01 = n => Math.max(0, Math.min(1, n));
const ease = (speed, low, high) => {
  const t = clamp01((speed - low) / (high - low));
  return t * t * (3 - 2 * t);
};

export const toKmh = metresPerSecond => Math.round(metresPerSecond * 3.6);
export const lensRush = speed => ease(speed, 4.0, 31.8);
export const roadFlow = speed => ease(speed, 9.2, 27.6);
export const windRush = speed => clamp01((speed - 3.8) / 32) ** 1.63;
export const roadExposure = speed => Math.max(0, Math.min(speed / 43, 1.05));
export const courseMarkerInterval = 10;

export function chaseLens(tall, rush, slide, acceleration = 0) {
  const load = Math.max(-.28, Math.min(.46, acceleration * .061)) * rush;
  return {
    following: 8.85 + 3.35 * tall - rush * (2.38 + tall * .22) + slide * 1.03 + load,
    height: 3.69 + .62 * tall - rush * 1.28 + slide * .24,
    lookAhead: 9 + 1.1 * tall + rush * 3.9,
    lookHeight: 1.39 - rush * .35,
    field: 56 + 10 * tall + rush * (12.6 - tall * 4.3) + slide * 1.85,
  };
}

export function bumperLens(tall, rush) {
  return { height: .62 - .035 * rush, field: 58 + tall * 15 + rush * (8.7 - tall * 3.1), pitch: -.059 + .015 * rush };
}

export function createDriveClock(step) {
  let backlog = 0;
  return {
    get alpha() { return clamp01(backlog / step); },
    reset() { backlog = 0; },
    advance(elapsed, tick) {
      // Catch up slow visible frames but don't replay a suspended or hidden tab.
      if (!Number.isFinite(elapsed) || elapsed < 0 || elapsed > 2.4) { backlog = 0; return; }
      backlog += elapsed;
      while (backlog + 1e-9 >= step) {
        const sampleAge = Math.max(0, backlog - step * .5);
        backlog -= step;
        if (tick(step, sampleAge) === false) { backlog = 0; break; }
      }
    },
  };
}

export function createRenderBudget() {
  const scales = [1, .83, .68, .55, .46];
  let index = 0, slowFor = 0, fastFor = 0, cooldown = 0, heavyFrames = 0;
  return {
    get scale() { return scales[index]; },
    sample(frameSeconds) {
      if (frameSeconds <= 0 || frameSeconds > 2.4) return false;
      const dt = Math.min(.25, frameSeconds);
      cooldown = Math.max(0, cooldown - dt);
      slowFor = frameSeconds > .037 ? slowFor + dt : Math.max(0, slowFor - 2 * dt);
      fastFor = frameSeconds < .0205 ? fastFor + dt : 0;
      heavyFrames = frameSeconds > .095 ? heavyFrames + 1 : Math.max(heavyFrames - 1, 0);
      if (!cooldown && index < scales.length - 1 && (slowFor > .44 || heavyFrames >= 2)) {
        index++; slowFor = fastFor = heavyFrames = 0; cooldown = .32; return true;
      }
      if (!cooldown && index > 0 && fastFor > 4) {
        index--; slowFor = fastFor = 0; cooldown = 2.4; return true;
      }
      return false;
    },
    clearSamples() { slowFor = fastFor = heavyFrames = 0; },
  };
}