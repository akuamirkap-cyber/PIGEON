// 01 / detailInventory: object, hard-surface. Keep the six-view base, then trace the four modification references.
// Evo front reference: rolled fender shoulders flow into a curved black lamp mask and a long, low, rounded splitter.
// Match inset silver lenses, amber markers, dark chamfered bumper ducts, hood extractors and swept louver banks.
// Follow the uninterrupted black/red/ochre bonnet and chin stripe, corner piping, red oval and period fender markings.
// Refs 2 + 3: low white upswept foil, rounded tips, wide swept white supports, silver fasteners and red rear emblems.
// Ref 4: raised straight light foil, thin black struts, deep black vertical endplates, and clear space above the deck.
// Retain animation pivots, rear lamp clusters, five-spoke white wheels and the original four-pod nose as a selectable kit.
// Heritage follows the first photo's stripe layout; Rally 12 retains the race number and fictional sponsor artwork.
// S1 rear: broad box flares, two recessed round-corner grilles, upright smoked lenses, and tall black corner protectors.
// S1 rear: white perforated bumper insert, wraparound ochre/orange lip and flaps, low offset exhaust, and a sloped plate panel.
// Use the rear-on photo for widths and heights, the low rear-quarter photo for depth and blended wing supports.
// Cockpit reference: clear apertures, pale roll cage, close black three-spoke wheel, green instruments and two white stick arms.
// Separate contact shapes wrap the wheel rim and sequential shifter, with a continuous palm and fitted cuff.
// Quality contract: compare the splitter reach, mask, extractor placement, panel joins, two spoiler profiles and mirrored graphics.
// No projection or image-derived pixels: only procedural geometry and generated canvas marks.

let defaultThree;
export function configureRallyThree(three) { defaultThree = three; }
export const DEFAULT_RALLY_BUILD = Object.freeze({ nose:'evo', rear:'s1', wing:'works', vinyl:'heritage', theme:'black' });

// +Y is up, +Z is forward, and +X is the driver's left. Units are metres.
// tick(dt, { speed, steer }) uses seconds, signed metres/second and steer in [-1, 1], with positive steer to the left.
export function createRallyCarModel(options = {}) {
  const T = options.THREE || defaultThree || globalThis.THREE;
  if (!T) throw new Error('Supply Three.js as options.THREE or call configureRallyThree first.');

  // 02a / blockout: key the width and beltline in plan and elevation, then lock the two axles, roof and wing envelope.
  const radius = 0.479, axleY = 0.481, halfTrack = 1.038;
  const axles = { F: 1.665, R: -1.433 };
  const sections = [ // z, top half-width, top y, shoulder x, shoulder y, lower x
    [-2.54, 1.092, 1.269, 1.140, 1.041, 1.140],
    [-2.42, 1.156, 1.320, 1.219, 1.100, 1.212],
    [-1.87, 1.178, 1.342, 1.248, 1.121, 1.250],
    [-1.19, 1.164, 1.353, 1.239, 1.145, 1.251],
    [-0.85, 1.123, 1.353, 1.199, 1.157, 1.220],
    [-0.65, 1.090, 1.351, 1.112, 1.156, 1.107],
    [ 0.91, 1.101, 1.352, 1.129, 1.164, 1.120],
    [ 1.18, 1.134, 1.325, 1.216, 1.151, 1.228],
    [ 1.67, 1.173, 1.250, 1.243, 1.111, 1.256],
    [ 1.96, 1.164, 1.204, 1.231, 1.016, 1.249],
    [ 2.23, 1.146, 1.156, 1.207, 0.837, 1.222],
    [ 2.41, 1.123, 1.127, 1.179, 0.704, 1.190],
    [ 2.55, 1.041, 1.101, 1.084, 0.677, 1.092],
  ];
  const rockerProfile = [[-2.54, .465], [-2.39, .425], [-2.03, .279], [2.24, .279], [2.55, .303]];
  const archProfile = [
    [-.589,.274],[-.567,.513],[-.506,.724],[-.387,.891],[-.211,1.010],[-.096,1.049],
    [.101,1.051],[.237,1.003],[.410,.883],[.523,.711],[.572,.505],[.593,.274],
  ];
  const canopy = { front: .92, rear: -1.88, roofFront: .21, roofRear: -.97, roofY: 1.944, baseWidth: 1.085, roofWidth: .859 };
  const mix = (a,b,t) => a + (b-a)*t;
  const blend = (a,b,t) => a.map((v,i)=>mix(v,b[i],t));
  const clamp = T.MathUtils.clamp;
  function interpolate(rows, z) {
    const i = rows.findIndex(row => row[0] >= z);
    if (i === 0) return rows[0];
    if (i < 0) return rows[rows.length - 1];
    const a = rows[i-1], b = rows[i];
    return a.map((v,j) => mix(v,b[j],(z-a[0])/(b[0]-a[0])));
  }
  const clipLine = axles.F+archProfile[0][0];
  const evoTip = 2.625;
  const evoSections = [...sections.filter(row=>row[0]<clipLine),interpolate(sections,clipLine),
    [1.26,1.153,1.330,1.251,1.162,1.262],
    [1.47,1.190,1.309,1.295,1.133,1.295],
    [1.67,1.212,1.282,1.310,1.113,1.311],
    [1.87,1.216,1.252,1.310,1.083,1.314],
    [2.08,1.199,1.219,1.292,1.015,1.303],
    [2.28,1.176,1.184,1.265,.950,1.288],
    [2.46,1.140,1.143,1.229,.900,1.267],
    [evoTip,1.107,1.101,1.182,.865,1.226],
  ];
  const evoArch = [[-.589,.279],[-.574,.457],[-.538,.621],[-.469,.791],[-.371,.922],[-.248,1.019],[-.117,1.070],
    [.014,1.086],[.146,1.063],[.276,1.012],[.391,.920],[.489,.795],[.563,.637],[.607,.472],[.624,.281]];
  const evoSweep = [[0,.019,0],[.45,.017,0],[.66,.007,.004],[.79,-.011,.007],
    [.91,-.043,.011],[1.016,-.087,.017],[1.106,-.143,.025],[1.31,-.165,.027]];
  const profiles = { evo:evoSections, classic:sections };
  const rearClip=-.824, s1Tail=-2.447;
  const s1Sections=[
    [s1Tail,1.206,1.312,1.291,1.111,1.302],
    [-2.271,1.232,1.342,1.338,1.136,1.343],
    [-2.083,1.233,1.351,1.342,1.144,1.350],
    [-1.885,1.230,1.357,1.329,1.150,1.346],
    [-1.647,1.228,1.363,1.309,1.158,1.326],
    [-1.401,1.211,1.361,1.300,1.161,1.321],
    [-1.171,1.175,1.357,1.264,1.158,1.290],
    [-1.006,1.147,1.354,1.227,1.156,1.242],
    interpolate(sections,rearClip),
  ];
  const s1Arch=[[-.622,.288],[-.614,.448],[-.574,.610],[-.495,.778],[-.381,.907],[-.253,1.004],[-.112,1.053],
    [.032,1.061],[.171,1.031],[.310,.967],[.423,.859],[.515,.731],[.567,.583],[.591,.420],[.603,.277]];
  const s1Rocker=[[s1Tail,.392],[-2.285,.362],[-2.064,.282],[rearClip,.279]];

  // 02b / structural: separate the sprung shell from the four steering/axle pivots and parent hardpoints to real parts.
  function group(name, parent) {
    const node = new T.Group(); node.name = name;
    if (parent) parent.add(node);
    return node;
  }
  const car = group('car');
  const bodyPivot = group('bodyPivot', car);
  const body = group('body', bodyPivot);
  const cabin = group('cabin', bodyPivot), glass = group('glass', cabin);
  const cockpit = group('cockpit',cabin), driver = group('stickDriver',cockpit);
  const hood = group('hood', bodyPivot), wing = group('wing', bodyPivot), struts = group('struts', wing);
  const bumpers = group('bumpers', bodyPivot), mirrors = group('mirrors', bodyPivot), lights = group('lights', bodyPivot);
  const livery = group('livery', bodyPivot);
  const vinyl = { heritage:group('vinylHeritage',livery), rally:group('vinylRally12',livery) };
  const noses = {};
  for (const id of ['evo','classic']) {
    noses[id] = { shell:group(`${id}FrontShell`,body), hood:group(`${id}Hood`,hood), bumper:group(`${id}Nose`,bumpers), lamps:group(`${id}Lamps`,lights),
      heritage:group(`${id}HeritageDecals`,vinyl.heritage), rally:group(`${id}RallyDecals`,vinyl.rally) };
  }
  const rearKits={};
  for(const id of ['standard','s1']) rearKits[id]={ shell:group(`${id}RearShell`,body), bumper:group(`${id}RearBumper`,bumpers),
    lamps:group(`${id}RearLamps`,lights), heritage:group(`${id}RearHeritage`,vinyl.heritage), rally:group(`${id}RearRally`,vinyl.rally) };
  const standardRear=rearKits.standard, s1Rear=rearKits.s1;
  const spoilers = {
    works: { foil:group('worksWing',wing), mounts:group('worksStruts',struts), height:1.853, z:-2.45 },
    high: { foil:group('highWing',wing), mounts:group('highStruts',struts), height:2.216, z:-2.48 },
  };
  const worksS1={ foil:group('s1WorksWing',spoilers.works.foil), mounts:group('s1WorksStruts',spoilers.works.mounts), height:2.02, z:-2.54 };
  const worksStandard={ foil:group('standardWorksWing',spoilers.works.foil), mounts:group('standardWorksStruts',spoilers.works.mounts) };
  const wheels = {};
  for (const [end,z] of Object.entries(axles)) for (const side of [1,-1]) {
    const name = `wheel${end}${side === 1 ? 'L' : 'R'}`;
    const pivot = group(name,car); pivot.position.set(side*halfTrack,axleY,z);
    const axle = group('axle',pivot);
    const rim = group('rim',axle);
    wheels[name] = { pivot, axle, rim, end, side };
  }
  function socket(name,parent,x,y,z) {
    const node = new T.Object3D(); node.name = name; node.position.set(x,y,z); parent.add(node); return node;
  }
  const sockets = {
    exhaust: socket('socketExhaust',bumpers,.03,.421,-2.652),
    wing: socket('socketWing',wing,0,spoilers.works.height,spoilers.works.z),
    cameraMount: socket('socketCameraMount',cabin,0,2.025,-.07),
    driverEye: socket('socketDriverEye',cockpit,.500,1.576,-.600),
    headlights: [],
  };
  sockets.exhaust.rotation.y = Math.PI;

  // 02c / form: bridge the cross-sections into faceted panels, cut the wheel openings, and build the wing, lamps and rims.
  const pieces = [];
  function piece(parent,name,geometry,mat,at,rotation,settings) {
    const descriptor = { parent,name,geometry,mat,at,rotation,settings };
    pieces.push(descriptor);
    return descriptor;
  }
  const deltaA = new T.Vector3(), deltaB = new T.Vector3(), cross = new T.Vector3();
  const squareUV = [[0,0],[1,0],[1,1],[0,1]];
  function faceGeometry(faces, forward) {
    const pos = [], uv = [];
    for (const face of faces) {
      const p = face.p || face;
      const tex = face.uv || squareUV;
      const normal = face.n || forward;
      for (let i=1; i<p.length-1; i++) {
        let order = [0,i,i+1];
        deltaA.set(p[i][0]-p[0][0],p[i][1]-p[0][1],p[i][2]-p[0][2]);
        deltaB.set(p[i+1][0]-p[0][0],p[i+1][1]-p[0][1],p[i+1][2]-p[0][2]);
        cross.crossVectors(deltaA,deltaB);
        if(cross.lengthSq()<1e-15) continue;
        if (normal) {
          if (cross.x*normal[0]+cross.y*normal[1]+cross.z*normal[2] < 0) order = [0,i+1,i];
        }
        for (const j of order) { pos.push(...p[j]); uv.push(...(tex[j] || [0,0])); }
      }
    }
    const geo = new T.BufferGeometry();
    geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));
    geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
    geo.computeVertexNormals();
    return geo;
  }
  function panel(parent,name,faces,mat,forward,settings) {
    return piece(parent,name,faceGeometry(faces,forward),mat,null,null,settings);
  }
  function box(parent,name,mat,size,at,rotation) {
    return piece(parent,name,new T.BoxGeometry(...size),mat,at,rotation);
  }
  function cylinder(parent,name,mat,diameter,depth,segments,at,axis='y') {
    const rot = axis === 'z' ? [Math.PI/2,0,0] : axis === 'x' ? [0,0,Math.PI/2] : null;
    return piece(parent,name,new T.CylinderGeometry(diameter/2,diameter/2,depth,segments),mat,at,rot);
  }
  function solidX(parent,name,section,x0,x1,mat,capMat=mat) {
    const a = section.map(([y,z]) => [x0,y,z]), b = section.map(([y,z]) => [x1,y,z]);
    panel(parent,name,[{ p:a,n:[-1,0,0] },{ p:b,n:[1,0,0] }],capMat);
    const centerY = section.reduce((sum,p) => sum+p[0],0)/section.length;
    const centerZ = section.reduce((sum,p) => sum+p[1],0)/section.length;
    panel(parent,`${name}Edge`,a.map((point,i) => {
      const j = (i+1)%a.length;
      return { p:[point,a[j],b[j],b[i]], n:[0,(point[1]+a[j][1])/2-centerY,(point[2]+a[j][2])/2-centerZ] };
    }),mat);
  }
  function evoWarp(x,y,z,falloff=1,offsetY=0,depthFalloff=falloff) {
    const [,sweep,fall]=interpolate(evoSweep,Math.abs(x));
    const f=clamp((z-2.022)/(evoTip-2.022),0,1);
    return [x,y-fall*(.30+.70*f)*falloff+offsetY,z+sweep*f*depthFalloff];
  }
  function skin(side,z,y,offset=0,profile=sections) {
    const [,xTop,yTop,xShoulder,yShoulder,xLower] = interpolate(profile,z);
    const upper=y>=yShoulder, v=clamp(upper?(y-yShoulder)/(yTop-yShoulder):(yShoulder-y)/(yShoulder-.275),0,1);
    const evo=profile===evoSections;
    const contour=upper ? Math.min(v,1-v)*(evo?.070*clamp((z-clipLine)/.32,0,1)
      : profile===s1Sections?.045*clamp((rearClip-z)/.52,0,1):0) : 0;
    const x=mix(xShoulder,upper?xTop:xLower,v)+contour;
    if (evo) {
      const fall=clamp((y-.25)/(yTop-.25),0,1);
      const sweep=mix(fall,1,clamp((y-.24)/.44,0,1)*clamp((z-2.31)/(evoTip-2.31),0,1));
      const point=evoWarp(x*side,y,z,fall,0,sweep);
      point[0]+=side*offset; return point;
    }
    return [(x+offset)*side,y,z];
  }
  function bottomAt(z,profile=sections) {
    const flat = profile===s1Sections ? interpolate(s1Rocker,z)[1]
      : profile===evoSections&&z>2.28 ? mix(.283,.304,clamp((z-2.28)/(evoTip-2.28),0,1)) : interpolate(rockerProfile,z)[1];
    for (const [end,axleZ] of Object.entries(axles)) {
      const arc=end==='F'&&profile===evoSections?evoArch:end==='R'&&profile===s1Sections?s1Arch:archProfile;
      if (z>axleZ+arc[0][0] && z<axleZ+arc.at(-1)[0]) {
        return Math.max(flat,interpolate(arc,z-axleZ)[1]);
      }
    }
    return flat;
  }
  const ordered = arr => [...new Set(arr)].sort((a,b)=>a-b);
  const bridge = (a,b) => a.slice(1).map((_,i)=>[a[i],a[i+1],b[i+1],b[i]]);
  function sideShell(parent,id,profile,side,z0,z1) {
    const belt=[], lower=[], quarter=[], round=[], heel=[], heelEdge=[];
    const evo=id==='evo', s1=id==='s1';
    const all=[...profile.map(p=>p[0]),...(s1?s1Rocker:rockerProfile).map(p=>p[0]),
      ...(s1?s1Arch:archProfile).map(p=>axles.R+p[0]),...(evo?evoArch:archProfile).map(p=>axles.F+p[0])];
    const rows=ordered([z0,z1,...all.filter(z=>z>z0 && z<z1)]);
    for (let i=1;i<rows.length;i++) {
      const a=rows[i-1], b=rows[i], [, ,ta,,sa]=interpolate(profile,a), [, ,tb,,sb]=interpolate(profile,b);
      const p=(z,y)=>skin(side,z,y,0,profile);
      const ma=evo||s1?mix(sa,ta,.49):ta, mb=evo||s1?mix(sb,tb,.49):tb;
      belt.push([p(a,sa),p(b,sb),p(b,mb),p(a,ma)]);
      if(evo||s1) round.push([p(a,ma),p(b,mb),p(b,tb),p(a,ta)]);
      const floor=z=>bottomAt(z,profile), pin=z=>s1?Math.max(floor(z),.429):floor(z);
      const lowerFace=[p(a,pin(a)),p(b,pin(b)),p(b,sb),p(a,sa)];
      if ((a+b)/2 < -.85 || id!=='main') quarter.push(lowerFace); else lower.push(lowerFace);
      if(s1) {
        const edge=z=>Math.max(floor(z),.416);
        heel.push([p(a,floor(a)),p(b,floor(b)),p(b,edge(b)),p(a,edge(a))]);
        heelEdge.push([p(a,edge(a)),p(b,edge(b)),p(b,pin(b)),p(a,pin(a))]);
      }
    }
    panel(parent,`${id}Shoulder${side}`,belt,evo?'evoFender':s1?'s1Gold':id==='main'?'midShoulder':'beltPaint',[side,0,0]);
    if (round.length) panel(parent,`${id}RolledShoulder${side}`,round,s1?'s1Gold':'evoBonnet',[side,1,0]);
    if (lower.length) panel(parent,`doorSkin${side}`,lower,'bodyGrey',[side,0,0]);
    if (quarter.length) panel(parent,`${id}Quarter${side}`,quarter,evo?'evoFender':s1?'s1Body':'bodyWhite',[side,0,0]);
    if(s1) {
      panel(parent,`s1LowerQuarter${side}`,heel,'s1Lower',[side,0,0]);
      panel(parent,`s1HeelEdge${side}`,heelEdge,'s1Gold',[side,0,0]);
    }
  }
  function arch(parent,id,side,z,profile) {
      const evo=id==='evo', s1=id==='s1';
      const arc=evo?evoArch:s1?s1Arch:archProfile;
      const point=([dz,y],ratio,dy,offset)=>skin(side,z+dz*ratio,y>axleY?mix(axleY,y,dy):Math.max(y,interpolate(s1?s1Rocker:rockerProfile,z+dz)[1]),offset,profile);
      const outer=arc.map(p=>point(p,1,1,evo||s1?0:.004));
      const crest=arc.map(p=>point(p,evo||s1?.970:.957,evo||s1?.944:.951,evo?.031:s1?.033:.012));
      const inner=arc.map(p=>point(p,evo||s1?.908:.911,evo?.867:s1?.889:.904,evo||s1?.020:.012));
      const innerWell = inner.map(([x,y,zz])=>[x-side*.105,y+.018,zz]);
      const rimFaces = [], wellFaces = [];
      for (let i=1; i<outer.length; i++) {
        rimFaces.push([outer[i-1],outer[i],crest[i],crest[i-1]],[crest[i-1],crest[i],inner[i],inner[i-1]]);
        wellFaces.push({ p:[inner[i-1],inner[i],innerWell[i],innerWell[i-1]], n:[0,axleY-inner[i][1],z-inner[i][2]] });
      }
      panel(parent,`${id}Flare${side}`,rimFaces,evo?'evoBonnet':s1?'s1Body':'arch',[side,0,0]);
      panel(parent,`${id}WheelWell${side}`,wellFaces,'deep');
  }
  for (const side of [1,-1]) {
    sideShell(body,'main',sections,side,rearClip,clipLine);
    sideShell(standardRear.shell,'standard',sections,side,sections[0][0],rearClip);
    sideShell(s1Rear.shell,'s1',s1Sections,side,s1Tail,rearClip);
    arch(standardRear.shell,'rear',side,axles.R,sections);
    arch(s1Rear.shell,'s1',side,axles.R,s1Sections);
    for (const [id,kit] of Object.entries(noses)) {
      const profile=profiles[id];
      sideShell(kit.shell,id,profile,side,clipLine,profile.at(-1)[0]);
      arch(kit.shell,id,side,axles.F,profile);
    }

    const sillZ = [-.878,-.788,.930,1.086];
    const sillTop = sillZ.map((z,i)=>skin(side,z,i === 0 || i === 3 ? .322 : .421,.007));
    const sillEdge = sillZ.map((z,i)=>[side*(i === 0 || i === 3 ? 1.228 : 1.248),.324,z]);
    const sillBase = sillEdge.map(([x,,z])=>[x-side*.009,.232,z]);
    panel(body,`sillCap${side}`,sillZ.slice(1).map((_,i)=>[sillEdge[i],sillEdge[i+1],sillTop[i+1],sillTop[i]]),'sill',[side,1,0]);
    panel(body,`sillFace${side}`,sillZ.slice(1).map((_,i)=>[sillBase[i],sillBase[i+1],sillEdge[i+1],sillEdge[i]]),'midSill',[side,0,0]);
    const mudZ = axles.R-.517;
    panel(standardRear.shell,`rearMudflap${side}`,[[[side*.806,.165,mudZ-.05],[side*1.246,.137,mudZ-.055],[side*1.231,.484,mudZ],[side*.822,.49,mudZ]]],'rubber',[0,0,-1],{ double:true });
  }

  const hoodY = (z,id='classic') => interpolate(profiles[id],z)[2]+.022;
  const hoodRows = id=>profiles[id].filter(p=>p[0]>=.91);
  const hoodInner = (z,id) => id==='evo' ? mix(1.008,.968,clamp((z-2.30)/.325,0,1)) : mix(.973,.896,clamp((z-2.30)/.25,0,1));
  const hoodPoint = (x,z,id,d=0) => id==='evo' ? evoWarp(x,hoodY(z,id),z,1,d) : [x,hoodY(z,id)+d,z];
  const ductA=.424, ductB=.659, ductZ0=2.205, ductZ1=2.397;
  const evoHoodX=ordered([-1,1,...evoSweep.map(p=>p[0]).filter(x=>x<.965).flatMap(x=>[-x,x]),-ductB,-ductA,ductA,ductB]);
  const hoodGrid=id=>ordered([...hoodRows(id).map(p=>p[0]),...(id==='evo'?[2.022,2.3,ductZ0,ductZ1]:[])]);
  const louvres=[-1,1].flatMap(side=>Array.from({length:6},(_,i)=>{
    const z=1.434+i*.096, inner=.657+i*.010, outer=.944-i*.008;
    return [[side*inner,z+.079],[side*outer,z-.100],[side*(outer-.019),z-.065],[side*(inner+.012),z+.115]];
  }));
  function area2(poly) {
    return poly.reduce((total,[x,z],i)=>{const [u,v]=poly[(i+1)%poly.length];return total+x*v-u*z;},0);
  }
  // Partition a hood facet into pieces outside each convex opening, keeping any extra UV coordinates.
  function removeCutouts(subject,holes) {
    let pieces=[subject];
    for(const hole of holes) {
      const min=hole[0].map((_,i)=>Math.min(...hole.map(p=>p[i])));
      const max=hole[0].map((_,i)=>Math.max(...hole.map(p=>p[i])));
      const winding=Math.sign(area2(hole));
      pieces=pieces.flatMap(poly=>{
        if(min.some((v,i)=>poly.every(p=>p[i]<=v)||poly.every(p=>p[i]>=max[i]))) return [poly];
        let inside=poly; const outside=[];
        for(let i=0;i<hole.length&&inside.length>=3;i++) {
          const [x,z]=hole[i], [u,v]=hole[(i+1)%hole.length];
          const distance=p=>winding*((u-x)*(p[1]-z)-(v-z)*(p[0]-x));
          const next=[], remainder=[];
          for(let j=0;j<inside.length;j++) {
            const a=inside[j], b=inside[(j+1)%inside.length], da=distance(a), db=distance(b);
            (da>=0?next:remainder).push(a);
            if((da>=0)!==(db>=0)) {const crossing=blend(a,b,da/(da-db));next.push(crossing);remainder.push(crossing);}
          }
          if(remainder.length>=3 && Math.abs(area2(remainder))>1e-11) outside.push(remainder);
          inside=next;
        }
        return inside.length>=3&&Math.abs(area2(inside))>1e-11?outside:[poly];
      });
    }
    return pieces;
  }
  for (const [id,kit] of Object.entries(noses)) {
    const evo=id==='evo', rows=hoodGrid(id), hoodCenter=[], hoodEdges=[];
    for (let i=1;i<rows.length;i++) {
      const a=rows[i-1], b=rows[i], [,ax,ay]=interpolate(profiles[id],a), [,bx,by]=interpolate(profiles[id],b);
      const hw=z=>hoodInner(z,id), band=evo&&a>=ductZ0&&b<=ductZ1, cuts=evo?evoHoodX:[-1,1];
      const p=(u,z)=>hoodPoint(Math.abs(u)===1 ? u*hw(z) : u,z,id);
      for (let i=1;i<cuts.length;i++) {
        const l=cuts[i-1], r=cuts[i], mid=Math.abs((l+r)/2);
        if (band && mid>ductA && mid<ductB) continue;
        const canonical=[[Math.abs(l)===1?l*hw(a):l,a],[Math.abs(r)===1?r*hw(a):r,a],
          [Math.abs(r)===1?r*hw(b):r,b],[Math.abs(l)===1?l*hw(b):l,b]];
        const subfaces=evo?removeCutouts(canonical,louvres):[canonical];
        hoodCenter.push(...subfaces.map(face=>face.map(([x,z])=>hoodPoint(x,z,id))));
      }
      for (const side of [1,-1]) hoodEdges.push([p(side,a),evo?skin(side,a,ay,0,evoSections):[side*ax,ay,a],
        evo?skin(side,b,by,0,evoSections):[side*bx,by,b],p(side,b)]);
    }
    panel(kit.hood,`${id}HoodPressing`,hoodCenter,evo?'evoBonnet':'roofWhite',[0,1,0]);
    panel(kit.hood,`${id}HoodBevel`,hoodEdges,evo?'evoBonnet':'beltPaint',[0,1,0]);
  }
  const deckY = z => interpolate(sections,z)[2]+.014;
  const deckRows = [-2.54,-2.42,-1.87];
  for (let i=1;i<deckRows.length;i++) {
    const a=deckRows[i-1], b=deckRows[i];
    panel(standardRear.shell,`deck${i}`,[[[-.915,deckY(a),a],[.915,deckY(a),a],[.915,deckY(b),b],[-.915,deckY(b),b]]],'roofWhite',[0,1,0]);
    for (const side of [1,-1]) {
      const [,ax,ay]=interpolate(sections,a), [,bx,by]=interpolate(sections,b);
      panel(standardRear.shell,`deckShoulder${side}-${i}`,[[[side*.915,deckY(a),a],[side*ax,ay,a],[side*bx,by,b],[side*.915,deckY(b),b]]],'beltPaint',[0,1,0]);
    }
  }
  box(body,'floorTub','deep',[1.56,.737,4.49],[0,.649,.013]);
  box(body,'skidPlate','bareAlloy',[1.29,.046,1.46],[0,.255,1.363]);
  box(body,'rearUndertray','rubber',[1.53,.08,.834],[0,.287,-2.042]);
  cylinder(body,'driveShaft','steel',.083,2.21,8,[.16,.30,.035],'z');

  const topNose = [[-1.041,1.101,2.55],[-.896,hoodY(2.55),2.55],[.896,hoodY(2.55),2.55],[1.041,1.101,2.55]];
  const baseNose = [[-1.084,.677,2.55],[-.929,.677,2.578],[.929,.677,2.578],[1.084,.677,2.55]];
  const plow = [[-1.139,.302,2.63],[-1.003,.267,2.786],[1.003,.267,2.786],[1.139,.302,2.63]];
  const edge = plow.map(([x,y,z])=>[x*.997,y-.074,z-.015]);
  const classicNose=noses.classic.bumper, evoNose=noses.evo.bumper;
  panel(classicNose,'classicNoseMask',bridge(baseNose,topNose),'beltPaint',[0,0,1]);
  panel(classicNose,'classicFrontAirdam',bridge(plow,baseNose),'roofWhite',[0,1,1]);
  panel(classicNose,'classicSplitterLip',bridge(edge,plow),'sillEdgePaint',[0,0,1]);
  for (const side of [1,-1]) {
    const i = side === 1 ? 3 : 0, endpoint = skin(side,2.41,.295);
    panel(classicNose,`classicAirdamReturn${side}`,[[endpoint,plow[i],baseNose[i],skin(side,2.41,.704)]],'bodyWhite',[side,0,1]);
    panel(classicNose,`classicLipReturn${side}`,[[[endpoint[0],.232,endpoint[2]],edge[i],plow[i],endpoint]],'sillEdgePaint',[side,0,0]);
    const start=skin(side,2.253,.280,.004), end=skin(side,2.41,.295,.004);
    panel(classicNose,`classicLipExtension${side}`,[[[start[0],.222,start[2]],[end[0],.232,end[2]],end,start]],'sillEdgePaint',[side,0,0]);
  }

  // Shared transverse stations keep the brow, ducts, apron and splitter joined at the swept corners.
  const faceStations = [ // half-span, brow y, mask base y, apron shoulder y, mask z, shoulder z, chin y, chin z, chin flare
    [0,1.099,.844,.559,2.690,2.780,.224,3.154,0], [.39,1.100,.844,.559,2.686,2.777,.224,3.145,.027],
    [.61,1.099,.843,.563,2.675,2.766,.226,3.122,.046], [.76,1.093,.842,.573,2.656,2.747,.228,3.096,.061],
    [.89,1.082,.841,.590,2.626,2.707,.231,3.052,.077], [1.00,1.066,.846,.616,2.579,2.655,.238,2.975,.090],
    [1.085,1.040,.855,.649,2.529,2.590,.251,2.872,.101], [1.137,1.006,.874,.689,2.486,2.524,.268,2.735,.098]
  ];
  const frontW=faceStations.at(-1)[0], frontCuts=ordered(faceStations.flatMap(([x])=>[-x,x]));
  const faceAt=x=>interpolate(faceStations,Math.abs(x));
  const evoMask=(x,v,d=0)=>{
    const [,top,base,,z]=faceAt(x);
    return [x,mix(base,top,v),z+.009*(1-v)+d];
  };
  const evoFascia=(x,v,d=0)=>{
    const [,,top,base,z,lowerZ]=faceAt(x);
    return [x,mix(base,top,v),mix(lowerZ,z+.009,v)+d];
  };
  const chinRings=[0,.17,.52,.82,1];
  const chinEase=[[0,0,0,0],[.17,.223,.129,.21],[.52,.591,.519,.61],[.82,.896,.850,.91],[1,1,1,1]];
  const chinPoint=(x,t,d=0)=>{
    const [,,,a,,z,y,end,dx]=faceAt(x);
    const [,rise,run,flare]=interpolate(chinEase,t);
    return [x+Math.sign(x)*dx*flare,mix(a,y,rise)+d*.74,mix(z,end,run)+d*.68];
  };
  const splitterBevel=[[0,.009,-.069,.027],[.73,.014,-.019,.046],[.92,.008,-.006,.025],[1,0,0,0]];
  const splitterPoint=(x,t,d=0)=>{
    const [px,y,z]=chinPoint(x,1);
    const [,dx,dy,dz]=interpolate(splitterBevel,t);
    return [px+Math.sign(x)*dx*Math.min(1,Math.abs(x)*2),y+dy,z+dz+d];
  };
  const bonnetLipX=evoSections.at(-1)[1];
  function browPoint(x,d=0) {
    const px=x*bonnetLipX/frontW, inner=hoodInner(evoTip,'evo');
    if(Math.abs(px)<=inner) return hoodPoint(px,evoTip,'evo',d);
    const side=Math.sign(x), outer=skin(side,evoTip,evoSections.at(-1)[2],0,evoSections);
    outer[1]+=d;
    return blend(hoodPoint(side*inner,evoTip,'evo',d),outer,(Math.abs(px)-inner)/(bonnetLipX-inner));
  }
  const browCuts=ordered([...frontCuts,...evoHoodX.map(x=>(Math.abs(x)===1?Math.sign(x)*hoodInner(evoTip,'evo'):x)*frontW/bonnetLipX)]);
  panel(evoNose,'evoPaintedGrilleHeader',bridge(browCuts.map(x=>evoMask(x,1)),browCuts.map(x=>browPoint(x))),'evoBonnet',[0,1,1]);
  panel(evoNose,'evoMaskLowerBead',bridge(frontCuts.map(x=>evoMask(x,0,.0018)),frontCuts.map(x=>evoMask(x,.046,.002))),'evoMaskEdge',[0,0,1]);
  const apronFaces=chinRings.slice(1).flatMap((t,i)=>bridge(frontCuts.map(x=>chinPoint(x,t)),frontCuts.map(x=>chinPoint(x,chinRings[i]))));
  panel(evoNose,'evoApron',apronFaces,'evoApronPaint',[0,1,1]);
  panel(evoNose,'evoSplitterTop',bridge(frontCuts.map(x=>splitterPoint(x,.73)),frontCuts.map(x=>splitterPoint(x,.92)))
    .concat(bridge(frontCuts.map(x=>splitterPoint(x,.92)),frontCuts.map(x=>splitterPoint(x,1)))),'evoSplitterBevel',[0,1,1]);
  panel(evoNose,'evoSplitterLip',bridge(frontCuts.map(x=>splitterPoint(x,0)),frontCuts.map(x=>splitterPoint(x,.73))),'evoSplitter',[0,0,1]);
  panel(evoNose,'evoSplitterUndertray',bridge(frontCuts.map(x=>[x*1.06,.201,2.42]),frontCuts.map(x=>splitterPoint(x,0))),'evoSplitter',[0,-1,0]);

  function port(x0,x1,lo,hi,corner,vertical,depth) { return {x0,x1,lo,hi,corner,vertical,depth}; }
  function portCuts(p) { return [p.x0,p.x0+p.corner,p.x1-p.corner,p.x1]; }
  function portV(p,x,upper) {
    const bevel=1-clamp(Math.min(x-p.x0,p.x1-x)/p.corner,0,1);
    return upper?p.hi-bevel*p.vertical:p.lo+bevel*p.vertical;
  }
  function portLoop(p,cuts) {
    const xs=ordered([...portCuts(p),...cuts.filter(x=>x>p.x0&&x<p.x1)]);
    return [...xs.map(x=>[x,portV(p,x,false)]),...xs.reverse().map(x=>[x,portV(p,x,true)])];
  }
  function perforate(map,ports) {
    const cuts=ordered([...frontCuts,...ports.flatMap(portCuts)]), skin=[], walls=[], backs=[];
    for(let i=1;i<cuts.length;i++) {
      const a=cuts[i-1], b=cuts[i], mid=(a+b)/2;
      const q=ports.find(p=>mid>p.x0&&mid<p.x1);
      if(q) skin.push([map(a,0),map(b,0),map(b,portV(q,b,false)),map(a,portV(q,a,false))],
        [map(a,portV(q,a,true)),map(b,portV(q,b,true)),map(b,1),map(a,1)]);
      else skin.push([map(a,0),map(b,0),map(b,1),map(a,1)]);
    }
    for(const p of ports) {
      const edge=portLoop(p,frontCuts), cx=(p.x0+p.x1)/2, cy=(p.lo+p.hi)/2;
      const floor=edge.map(([x,v])=>map(mix(x,cx,.078),mix(v,cy,.087),-p.depth));
      for(let i=0;i<edge.length;i++) {
        const j=(i+1)%edge.length, [x,v]=edge[i], [x1,v1]=edge[j];
        walls.push({p:[map(x,v),map(x1,v1),floor[j],floor[i]],n:[cx-(x+x1)/2,cy-(v+v1)/2,.035]});
      }
      backs.push(floor);
    }
    return {skin,walls,backs};
  }
  const lampPorts = [port(-1.041,-.756,.179,.851,.021,.092,.051),port(.756,1.041,.179,.851,.021,.092,.051)];
  const lampMask=perforate(evoMask,lampPorts);
  panel(evoNose,'evoFullWidthBlackMask',lampMask.skin,'evoMaskPaint',[0,0,1]);
  panel(evoNose,'evoHeadlightPocketWalls',lampMask.walls,'evoSocketShade');
  panel(evoNose,'evoHeadlightPocketBacks',lampMask.backs,'deep',[0,0,1]);

  const intakePorts = [port(-.957,-.741,.245,.777,.026,.113,.142),port(-.492,.519,.179,.779,.046,.112,.182),
    port(.741,.957,.245,.777,.026,.113,.142)];
  const markerPorts = [port(-1.082,-.972,.363,.811,.010,.073,.019),port(.972,1.082,.363,.811,.010,.073,.019)];
  const intake=perforate(evoFascia,[...intakePorts,...markerPorts]);
  panel(evoNose,'evoPerforatedBumper',intake.skin,'evoBumperPaint',[0,0,1]);
  panel(evoNose,'evoInsetDuctWalls',intake.walls,'evoDuctShade');
  panel(evoNose,'evoRadiatorCavity',intake.backs,'deep',[0,0,1]);
  for(const t of [.32,.48,.64]) box(evoNose,`evoIntercoolerFin${t}`,'evoRadFin',[.828,.008,.030],evoFascia(.014,t,-.147));
  box(evoNose,'evoCentreDuctDivider','grilleBlack',[.040,.143,.081],evoFascia(.012,.481,-.079),[-.16,0,0]);
  box(evoNose,'evoTowBase','evoSocketShade',[.056,.066,.037],evoFascia(.164,.340,-.052));
  const frontEye=piece(evoNose,'evoTowHook',new T.TorusGeometry(.021,.006,5,12),'evoTow',evoFascia(.166,.317,-.028),[.09,0,-.21]);
  frontEye.geometry.scale(.88,1.20,1);

  const cornerLips={};

  for (const side of [1,-1]) {
    const x=side*frontW, profile=evoSections, z=evoTip;
    const [, ,top,,shoulder]=profile.at(-1), bottom=bottomAt(z,profile);
    const sideY=[top,mix(shoulder,top,.49),shoulder,.641,...chinRings.slice(1).map(t=>mix(.641,bottom,t))];
    const outer=[browPoint(x),evoMask(x,1),evoMask(x,0),...chinRings.map(t=>chinPoint(x,t))];
    const inner=sideY.map(y=>skin(side,z,y,0,profile));
    const mid=inner.map((p,i)=>blend(p,outer[i],.52));
    panel(evoNose,`evoWrapAround${side}`,bridge(inner,mid).concat(bridge(mid,outer)),'evoFender',[side,0,.40],{double:true});
    const sill=[axles.F+evoArch.at(-1)[0],2.46,z].map(k=>skin(side,k,bottomAt(k,profile),0,profile));
    const upper=[...sill,chinPoint(x,1)], lower=[...sill.map(([a,,b])=>[a-side*.008,.206,b]),splitterPoint(x,0)];
    const strap=(t,d=0)=>upper.map((p,i)=>{const q=blend(lower[i],p,t);q[0]+=side*d;return q;});
    cornerLips[side]=strap;
    panel(evoNose,`evoCornerLip${side}`,bridge(lower,upper),'evoSplitter',[side,0,0]);

    const ductRows=hoodGrid('evo').filter(z=>z>=ductZ0&&z<=ductZ1);
    const lip=(x,z,d=0)=>hoodPoint(side*x,z,'evo',d);
    const surround=[], floors=[];
    for(let i=1;i<ductRows.length;i++) {
      const a=ductRows[i-1],b=ductRows[i];
      for(const [u,n,dx] of [[ductA,side,.011],[ductB,-side,-.011]]) surround.push({p:[lip(u,a),lip(u,b),lip(u+dx,b,-.055),lip(u+dx,a,-.055)],n:[n,.45,0]});
      floors.push([lip(ductA+.006,a,-.056),lip(ductB-.006,a,-.056),lip(ductB-.006,b,-.056),lip(ductA+.006,b,-.056)]);
    }
    for(const [u,n] of [[ductZ0,1],[ductZ1,-1]]) surround.push({p:[lip(ductA,u),lip(ductB,u),lip(ductB-.010,u+n*.013,-.055),lip(ductA+.010,u+n*.013,-.055)],n:[0,.38,n]});
    panel(noses.evo.hood,`evoExtractorWalls${side}`,surround,'evoSocketShade');
    panel(noses.evo.hood,`evoExtractorRecess${side}`,floors,'deep',[0,1,0]);
    for (const zz of [2.274,2.344]) panel(noses.evo.hood,`evoExtractorVane${side}-${zz}`,[[lip(ductA+.011,zz,-.037),lip(ductB-.011,zz,-.037),lip(ductB-.011,zz+.021,-.046),lip(ductA+.011,zz+.021,-.046)]],'evoSocketShade',[0,1,0]);
    const catchPoint=lip(.834,2.532,.008);
    cylinder(noses.evo.hood,`evoBonnetCatch${side}`,'bareAlloy',.033,.010,10,catchPoint);
    box(noses.evo.hood,`evoCatchPin${side}`,'evoSocketShade',[.039,.008,.013],[catchPoint[0],catchPoint[1]+.005,catchPoint[2]],[.24,0,0]);
  }
  for(const [i,opening] of louvres.entries()) {
    const cx=opening.reduce((s,p)=>s+p[0],0)/opening.length, cz=opening.reduce((s,p)=>s+p[1],0)/opening.length;
    const rim=opening.map(([x,z])=>hoodPoint(x,z,'evo'));
    const floor=opening.map(([x,z])=>hoodPoint(mix(x,cx,.051),mix(z,cz,.076),'evo',-.034));
    const walls=rim.map((p,k)=>{
      const j=(k+1)%rim.length, a=opening[k], b=opening[j];
      return {p:[p,rim[j],floor[j],floor[k]],n:[cx-(a[0]+b[0])/2,.036,cz-(a[1]+b[1])/2]};
    });
    panel(noses.evo.hood,`evoFenderLouvre${i}`,walls,'evoDuctShade');
    panel(noses.evo.hood,`evoLouvreRecess${i}`,[floor],'deep',[0,1,0]);
  }

  const rearFaceZ = -2.54;
  const stockBumper=standardRear.bumper, s1Bumper=s1Rear.bumper;
  panel(stockBumper,'rearHeader',[[[-1.14,1.041,rearFaceZ],[1.14,1.041,rearFaceZ],[1.092,1.269,rearFaceZ],[-1.092,1.269,rearFaceZ]]],'beltPaint',[0,0,-1]);
  panel(stockBumper,'rearValance',[[[-1.122,.54,rearFaceZ],[1.122,.54,rearFaceZ],[1.14,1.041,rearFaceZ],[-1.14,1.041,rearFaceZ]]],'bodyGrey',[0,0,-1]);
  function rearBumperRow(y,z,w) { return [[-w,y,z+.081],[-w+.115,y,z],[w-.115,y,z],[w,y,z+.081]]; }
  const rearUpper = rearBumperRow(.557,-2.599,1.151), rearLower = rearBumperRow(.319,-2.578,1.112);
  panel(stockBumper,'rearBumper',bridge(rearLower,rearUpper),'bumper',[0,0,-1]);
  panel(stockBumper,'rearBumperTop',bridge(rearUpper,rearBumperRow(.557,-2.493,1.142)),'arch',[0,1,0]);
  cylinder(stockBumper,'exhaustTip','steel',.243,.204,8,[.03,.421,-2.554],'z');
  cylinder(stockBumper,'exhaustCore','deep',.179,.008,8,[.03,.421,-2.660],'z');
  const tow = piece(stockBumper,'towHook',new T.TorusGeometry(.067,.014,5,10),'redHardware',[.372,.350,-2.591],[0,0,Math.PI/10]);
  tow.geometry.scale(.80,1.14,1.0);
  box(stockBumper,'towHookTab','bareAlloy',[.044,.102,.066],[.372,.404,-2.563]);

  // Cross sections share the same crown, bumper joint and rolled lip so the rear stays closed in profile.
  const s1Cross=[ // span, crown Z, joint Z, lip Z, foot Z, crown Y, joint Y, lip Y, foot Y
    [0,-2.593,-2.650,-2.731,-2.690,1.312,.720,.470,.330],
    [.630,-2.592,-2.648,-2.728,-2.684,1.312,.720,.470,.332],
    [.895,-2.586,-2.639,-2.715,-2.672,1.310,.720,.469,.340],
    [1.036,-2.570,-2.625,-2.694,-2.641,1.304,.720,.467,.351],
    [1.142,-2.539,-2.597,-2.658,-2.596,1.287,.719,.465,.365],
    [1.231,-2.494,-2.550,-2.603,-2.531,1.251,.715,.464,.386],
    [1.300,-2.441,-2.484,-2.528,-2.470,1.207,.711,.460,.402],
    [1.349,-2.396,-2.425,-2.471,-2.427,1.160,.703,.451,.422],
  ];
  const s1W=s1Cross.at(-1)[0], s1Cuts=ordered(s1Cross.flatMap(([x])=>[-x,x]));
  function s1Point(x,y,d=0) {
    const [,cap,joint,lip,foot,top,mid,low,base]=interpolate(s1Cross,Math.abs(x));
    const rows=[[base,foot],[mix(base,low,.38),mix(foot,lip,.69)],[low,lip],[mid,joint],[top,cap]];
    return [x,y,interpolate(rows,y)[1]-d];
  }
  function s1Fascia(x,v,d=0) {
    const [,,,,,top,mid]=interpolate(s1Cross,Math.abs(x));
    return s1Point(x,mix(mid,top,v),d);
  }
  function s1Apron(x,v,d=0) {
    const [,,,,,,mid,low]=interpolate(s1Cross,Math.abs(x));
    return s1Point(x,mix(low,mid,v),d);
  }
  function s1Heel(x,v,d=0) {
    const [,,,,,,,low,base]=interpolate(s1Cross,Math.abs(x));
    return s1Point(x,mix(base,low,v),d);
  }
  function roundAperture(a,b,lo,hi,rx,ry) {
    const ring=[];
    for(const [x,y,start] of [[b-rx,hi-ry,0],[a+rx,hi-ry,1],[a+rx,lo+ry,2],[b-rx,lo+ry,3]]) {
      for(let i=0;i<=4;i++) {const t=(start+i/4)*Math.PI/2; ring.push([x+rx*Math.cos(t),y+ry*Math.sin(t)]);}
    }
    return ring;
  }
  function rearBand(map,lo,hi,holes=[],cuts=s1Cuts) {
    const faces=[];
    for(let i=1;i<cuts.length;i++) {
      const a=cuts[i-1], b=cuts[i];
      const p=[[a,lo],[b,lo],[b,hi],[a,hi]];
      faces.push(...removeCutouts(p,holes).map(poly=>poly.map(([x,v])=>map(x,v))));
    }
    return faces;
  }
  function recess(parent,name,map,loop,depth,outer,inner) {
    const n=loop.length, mid=[loop.reduce((a,p)=>a+p[0],0)/n,loop.reduce((a,p)=>a+p[1],0)/n];
    const ring=(shrink,d)=>loop.map(([x,y])=>map(mix(x,mid[0],shrink),mix(y,mid[1],shrink),d));
    const mouth=ring(0,0), bezel=ring(.035,-.015), back=ring(.105,-depth);
    function returnFaces(a,b) {
      return a.map((p,i)=>{
        const j=(i+1)%a.length, [x,v]=loop[i], [q,w]=loop[j];
        return {p:[p,a[j],b[j],b[i]],n:[mid[0]-(x+q)/2,mid[1]-(v+w)/2,-.21]};
      });
    }
    panel(parent,`${name}Bezel`,returnFaces(mouth,bezel),outer);
    panel(parent,`${name}Return`,returnFaces(bezel,back),inner);
    panel(parent,`${name}Cavity`,[back],'deep',[0,0,-1]);
  }
  function sliceRange(loop,value,axis) {
    const hits=[];
    for(let i=0;i<loop.length;i++) {
      const a=loop[i], b=loop[(i+1)%loop.length], u=a[axis], v=b[axis];
      if((u<=value&&v>value)||(v<=value&&u>value)) hits.push(mix(a[1-axis],b[1-axis],(value-u)/(v-u)));
    }
    return hits.length>1?[Math.min(...hits),Math.max(...hits)]:null;
  }
  function s1Grille(parent,name,loop) {
    recess(parent,name,s1Fascia,loop,.123,'s1Bezel','s1VentWall');
    const xs=loop.map(p=>p[0]), x0=Math.min(...xs), x1=Math.max(...xs), cx=(x0+x1)/2;
    const slats=[], web=[];
    for(let i=0;i<12;i++) {
      const v=.161+.0507*i, edge=sliceRange(loop,v,1);
      if(!edge) continue;
      const a=edge[0]+.009,b=edge[1]-.009;
      const cuts=ordered([a,b,...s1Cuts.filter(x=>x>a&&x<b)]);
      slats.push(...bridge(cuts.map(x=>s1Fascia(x,v-.010,-.034)),cuts.map(x=>s1Fascia(x,v+.010,-.030))));
      slats.push(...bridge(cuts.map(x=>s1Fascia(x,v+.010,-.030)),cuts.map(x=>s1Fascia(x,v+.015,-.052))));
    }
    for(let i=1;i<26;i++) {
      const x=mix(x0,x1,i/26), r=sliceRange(loop,x,0);
      if(r) web.push([s1Fascia(x-.0022,r[0]+.026,-.050),s1Fascia(x+.0022,r[0]+.026,-.050),
        s1Fascia(x+.0022,r[1]-.032,-.050),s1Fascia(x-.0022,r[1]-.032,-.050)]);
    }
    panel(parent,`${name}HorizontalSlats`,slats,'s1Slat',[0,0,-1]);
    panel(parent,`${name}VerticalMesh`,web,'s1Wire',[0,0,-1]);
    const [x,y,z]=s1Fascia(cx,.436,-.098);
    const fan=piece(parent,`${name}CoolingFan`,new T.RingGeometry(.118,.143,24),'s1VentWall',[x,y,z]);
    fan.geometry.rotateY(Math.PI);
    cylinder(parent,`${name}FanHub`,'s1Wire',.061,.017,12,[x,y,z+.005],'z');
    const blades=[];
    for(let i=0;i<7;i++) {
      const a=i*Math.PI*2/7;
      const p=(r,o)=>[x+r*Math.cos(a+o),y+r*Math.sin(a+o),z+.003];
      blades.push([p(.034,0),p(.128,.30),p(.133,.59),p(.043,.45)]);
    }
    panel(parent,`${name}FanBlades`,blades,'s1Wire',[0,0,-1]);
  }

  const s1Apertures=[roundAperture(-.87,-.034,.129,.744,.071,.117),roundAperture(.034,.87,.129,.744,.071,.117)];
  const s1LampLoops=[1,-1].map(side=>[[.935,.148],[1.136,.154],[1.176,.253],[1.179,.581],[1.161,.773],[1.139,.851],
    [1.009,.875],[.986,.823],[.964,.532],[.943,.273]].map(([x,v])=>[side*x,v]));
  const topHoles=[...s1Apertures,...s1LampLoops];
  panel(s1Bumper,'s1VentedRearPanel',rearBand(s1Fascia,0,.610,topHoles),'s1Body',[0,0,-1]);
  panel(s1Bumper,'s1RearGoldBelt',rearBand(s1Fascia,.610,1,topHoles),'s1Gold',[0,0,-1]);
  const lowers=roundAperture(-.824,.824,.130,.808,.029,.105);
  const bumperFace=(x,v,d=0)=>s1Apron(x,v,d+.017*v);
  panel(s1Bumper,'s1WhiteBumper',rearBand(bumperFace,0,1,[lowers]),'s1Body',[0,0,-1]);
  panel(s1Bumper,'s1BumperLedge',bridge(s1Cuts.map(x=>s1Fascia(x,0)),s1Cuts.map(x=>bumperFace(x,1))),'s1PanelSeam',[0,1,-1]);
  panel(s1Bumper,'s1RolledLowerEdge',rearBand(s1Heel,.38,1),'s1Lower',[0,0,-1]);
  panel(s1Bumper,'s1LowerReturn',rearBand(s1Heel,0,.38),'s1UnderGold',[0,-1,-.27]);
  panel(s1Bumper,'s1RearUndertray',bridge(s1Cuts.map(x=>s1Heel(x,0)),s1Cuts.map(x=>[x*.924,.288,-2.31])),'s1VentWall',[0,-1,0]);
  recess(s1Bumper,'s1PerforatedLowerIntake',bumperFace,lowers,.062,'s1Metal','s1PanelSeam');
  const meshLoop=lowers.map(([x,v])=>[x*.983,mix(v,.469,.057)]);
  panel(s1Bumper,'s1LowerPerforatedMesh',[{p:meshLoop.map(([x,v])=>bumperFace(x,v,-.026)),uv:meshLoop.map(([x,v])=>[(.824-x)/1.648,(v-.130)/.678])}],'s1Perforation',[0,0,-1]);
  for(const [i,loop] of s1Apertures.entries()) s1Grille(s1Bumper,`s1RearGrille${i+1}`,loop);
  for(const [i,loop] of s1LampLoops.entries()) {
    const side=i===0?1:-1, parent=s1Rear.lamps;
    recess(parent,`s1VerticalLight${i+1}`,s1Fascia,loop,.050,'s1Bezel','s1VentWall');
    const shaped=loop.map(([x,v])=>[mix(x,side*1.056,.095),mix(v,.529,.045)]);
    panel(parent,`s1SmokedTail${i+1}`,[{p:shaped.map(([x,v])=>s1Fascia(x,v,-.017)),
      uv:shaped.map(([x,v])=>[(Math.abs(x)-.915)/.259,(v-.145)/.750])}],'s1TailLens',[0,0,-1]);
    for(const v of [.187,.824]) cylinder(parent,`s1LensScrew${i}-${v}`,'s1Bolt',.018,.008,8,s1Fascia(side*1.082,v,-.010),'z');
  }

  const s1PlateFace=[[-1.026,1.312,-2.590],[1.026,1.312,-2.590],[.978,1.651,-2.447],[-.978,1.651,-2.447]];
  panel(s1Rear.shell,'s1RakedHatch',[s1PlateFace],'s1Body',[0,.4,-1]);
  panel(s1Rear.shell,'s1HatchCrown',[[s1PlateFace[3],s1PlateFace[2],[.973,1.654,-2.391],[-.973,1.654,-2.391]]],'s1Body',[0,1,0]);
  panel(s1Rear.shell,'s1HatchBacking',[[[-.973,1.654,-2.391],[.973,1.654,-2.391],[.963,1.355,-2.111],[-.963,1.355,-2.111]]],'s1Body',[0,1,0]);
  const s1DeckCuts=ordered([...s1Cuts.map(x=>x/s1W),-.848,-.625,.625,.848]);
  const s1DeckRows=[s1Tail,-2.285,-2.083,-1.876];
  function s1Deck(u,z) {
    const [,w,y]=interpolate(s1Sections,z), blendRear=clamp((-z-2.290)/(-s1Tail-2.290),0,1);
    return blend([u*w,y+.006*(1-Math.abs(u)),z],s1Fascia(u*s1W,1),blendRear);
  }
  for(let i=1;i<s1DeckRows.length;i++) for(let j=1;j<s1DeckCuts.length;j++) {
    const a=s1DeckRows[i-1], b=s1DeckRows[i], l=s1DeckCuts[j-1], r=s1DeckCuts[j];
    panel(s1Rear.shell,`s1DeckPanel${i}-${j}`,[[s1Deck(l,a),s1Deck(r,a),s1Deck(r,b),s1Deck(l,b)]],Math.abs((l+r)/2)>.845?'s1Gold':'s1Body',[0,1,0]);
  }

  const s1MudPivots=[];
  for(const side of [1,-1]) {
    const x=side*s1W;
    const b0=s1Heel(x,0), b1=s1Heel(x,1), b2=s1Apron(x,1), b3=s1Fascia(x,1);
    const p0=skin(side,s1Tail,.392,0,s1Sections), p1=skin(side,s1Tail,.467,0,s1Sections), p2=skin(side,s1Tail,.711,0,s1Sections),
      p3=skin(side,s1Tail,1.111,0,s1Sections), p4=skin(side,s1Tail,1.312,0,s1Sections);
    panel(s1Bumper,`s1WrapAround${side}`,[[p1,b1,b2,p2],[p2,b2,b3,p3]],'s1Body',[side,0,-.05],{double:true});
    panel(s1Bumper,`s1LipWrap${side}`,[[p0,b0,b1,p1]],'s1Lower',[side,0,-.05],{double:true});
    panel(s1Rear.shell,`s1CrownTurn${side}`,[[p3,b3,p4]],'s1Gold',[side,1,-.1],{double:true});
    const base=[side*1.026,1.312,-2.590], head=[side*.978,1.651,-2.447], top=[side*.973,1.654,-2.391], rail=[side*.963,1.355,-2.111];
    const deck=[side*1.033,1.351,-2.307];
    panel(s1Rear.shell,`s1HatchSideReturn${side}`,[[base,head,top,deck],[deck,top,rail]],'s1Body',[side,.16,0],{double:true});
    const guard=[[1.153,.434],[1.253,.397],[1.332,.416],[1.371,.477],[1.378,.977],[1.359,1.034],[1.236,1.106],[1.168,1.127],[1.150,1.068]];
    const guardSkin=(u,y,d)=>s1Point(side*u,y,d+(Math.min(u,s1W)-1.15)*.055);
    const seal=guard.map(([u,y])=>guardSkin(u,y,.003));
    const close=guard.map(([u,y])=>guardSkin(mix(u,1.265,.072),mix(y,.755,.028),.036));
    const flat=guard.map(([u,y])=>guardSkin(mix(u,1.265,.094),mix(y,.755,.041),.052));
    const joins=(a,b)=>a.map((p,i)=>[p,a[(i+1)%a.length],b[(i+1)%a.length],b[i]]);
    panel(s1Bumper,`s1TallCornerGuard${side}`,[{p:flat,uv:flat.map(([u,y])=>[(Math.abs(u)-1.15)/.23,(y-.397)/.730])}],'s1Guard',[0,0,-1]);
    panel(s1Bumper,`s1CornerGuardReturn${side}`,joins(seal,close).concat(joins(close,flat)),'s1GuardEdge',[side*.4,0,-1],{double:true});
    for(const [u,y] of [[1.181,1.068],[1.335,1.013],[1.180,.476],[1.326,.458]]) cylinder(s1Bumper,`s1GuardRivet${side}-${u}-${y}`,'s1Bolt',.015,.007,8,guardSkin(u,y,.055),'z');

    const hinge=group(`s1MudflapPivot${side}`,s1Rear.shell);
    hinge.position.set(side*1.044,.388,-2.048); s1MudPivots.push(hinge);
    const flapRows=[[.061,-.004,.203],[-.085,-.018,.213],[-.247,-.056,.220],[-.350,-.118,.228]];
    const flap=(d)=>flapRows.map(([y,z,w])=>[[-w,y+.006,z+d],[w,y,z+d-.008]]);
    const front=flap(.012), back=flap(-.002);
    const flapSkin=rows=>rows.slice(1).map((p,i)=>[...rows[i],p[1],p[0]]);
    panel(hinge,`s1WideMudflap${side}`,flapSkin(back),'s1Flap',[0,0,-1]);
    panel(hinge,`s1MudflapBack${side}`,flapSkin(front),'s1UnderGold',[0,0,1]);
    panel(hinge,`s1MudflapEdges${side}`,[...bridge(back.map(r=>r[0]),front.map(r=>r[0])),...bridge(back.map(r=>r[1]),front.map(r=>r[1])),[...back.at(-1),...front.at(-1).slice().reverse()]],'s1Flap',[0,-1,-.2],{double:true});
    box(hinge,`s1MudflapClamp${side}`,'s1VentWall',[.315,.021,.028],[0,.003,-.007]);
    for(const u of [-.122,.122]) cylinder(hinge,`s1MudflapRivet${side}-${u}`,'s1Bolt',.016,.007,8,[u,.004,-.025],'z');
  }

  const s1Exhaust=[-.266,.251,-2.757];
  piece(s1Bumper,'s1ExhaustTube',new T.LatheGeometry([[.066,.173],[.069,.136],[.069,-.092],[.063,-.124],[.049,-.124]]
    .map(p=>new T.Vector2(...p)),24),'s1ExhaustMetal',[-.266,.251,-2.633],[Math.PI/2,0,0],{double:true});
  piece(s1Bumper,'s1ExhaustBore',new T.LatheGeometry([[.049,-.124],[.049,.072]].map(p=>new T.Vector2(...p)),24),
    's1VentWall',[-.266,.251,-2.633],[Math.PI/2,0,0],{double:true});
  cylinder(s1Bumper,'s1ExhaustInside','deep',.102,.010,18,[-.266,.251,-2.575],'z');
  box(s1Bumper,'s1ExhaustHanger','s1VentWall',[.046,.136,.077],[-.263,.360,-2.603]);
  const rearEye=piece(s1Bumper,'s1OffsetTowHook',new T.TorusGeometry(.042,.009,5,12),'redHardware',[-.796,.303,-2.634],[.16,0,-.23]);
  rearEye.geometry.scale(1.3,.72,1);

  const baseFL = [canopy.baseWidth,1.359,canopy.front], baseFR = [-canopy.baseWidth,1.359,canopy.front];
  const baseRL = [1.106,1.352,canopy.rear], baseRR = [-1.106,1.352,canopy.rear];
  const roofFL = [canopy.roofWidth,1.894,canopy.roofFront], roofFR = [-canopy.roofWidth,1.894,canopy.roofFront];
  const roofRL = [.887,1.895,canopy.roofRear], roofRR = [-.887,1.895,canopy.roofRear];
  const frontFrame = [baseFR,baseFL,roofFL,roofFR], rearFrame = [baseRL,baseRR,roofRR,roofRL];
  const sideFrames = [[baseFL,baseRL,roofRL,roofFL],[baseFR,baseRR,roofRR,roofFR]];
  const panePoint = (q,u,v,off) => blend(blend(q[0],q[1],u),blend(q[3],q[2],u),v).map((x,i)=>x+off[i]);
  function inset(q,u0,u1,v0,v1,off) {
    const point = (u,v) => panePoint(q,u,v,off);
    return [point(u0,v0),point(u1,v0),point(u1,v1),point(u0,v1)];
  }
  const noOffset=[0,0,0];
  const windAperture=inset(frontFrame,.049,.951,.057,.939,noOffset);
  const rearAperture=inset(rearFrame,.045,.955,.126,.944,noOffset);
  panel(cabin,'windshieldFrame',capRing(frontFrame,windAperture),'windowFrame',[0,1,1],{double:true});
  panel(cabin,'rearWindowFrame',capRing(rearFrame,rearAperture),'roofWhite',[0,1,-1],{double:true});
  panel(glass,'windscreen',[windAperture],'frontGlass',[0,1,1],{shadow:false});
  panel(glass,'rearScreen',[rearAperture],'rearGlass',[0,1,-1],{shadow:false});
  for (const [i,side] of [1,-1].entries()) {
    const frame=sideFrames[i], dir=[side,0,0];
    const divider = (z,v) => {
      const front=mix(canopy.front,canopy.roofFront,v), rear=mix(canopy.rear,canopy.roofRear,v);
      return (z-.036*(1-v)-front)/(rear-front);
    };
    const glassV0=.052, glassV1=.957;
    const pane=(a,b)=>[panePoint(frame,a(glassV0),glassV0,noOffset),panePoint(frame,b(glassV0),glassV0,noOffset),
      panePoint(frame,b(glassV1),glassV1,noOffset),panePoint(frame,a(glassV1),glassV1,noOffset)];
    const door=pane(()=>.036,v=>divider(-.506,v)), quarter=pane(v=>divider(-.641,v),()=>.952);
    const surround=[[frame[0],frame[1],quarter[1],quarter[0],door[1],door[0]],
      [door[3],door[2],quarter[3],quarter[2],frame[2],frame[3]],
      [frame[0],door[0],door[3],frame[3]],[door[1],quarter[0],quarter[3],door[2]],
      [quarter[1],frame[1],frame[2],quarter[2]]];
    panel(cabin,`sideWindowFrame${side}`,surround,'windowFrame',dir,{double:true});
    panel(glass,`doorGlass${side}`,[door],'sideGlass',dir,{shadow:false});
    panel(glass,`quarterGlass${side}`,[quarter],'sideGlass',dir,{shadow:false});
    panel(cabin,`roofGutter${side}`,[inset(frame,0,1,.957,1,[side*.008,.009,0])],'roofWhite',dir);
    panel(cabin,`cPillar${side}`,[inset(frame,.952,1,.019,1,[side*.009,.004,0])],'roofWhite',dir);
    const railInner=z=>{
      const f=clamp((z-canopy.rear)/(canopy.front-canopy.rear),0,1);
      return [side*(mix(1.106,canopy.baseWidth,f)-.012),mix(1.352,1.359,f)-.004,z];
    };
    const addShoulder=(parent,name,profile,stations,mat)=>{
      const outer=stations.map(z=>{const [,x,y]=interpolate(profile,z);return [side*x,y,z];});
      panel(parent,name,bridge(stations.map(railInner),outer),mat,[0,1,0]);
    };
    addShoulder(body,`canopyShoulder${side}`,sections,[rearClip,-.65,.91],'midShoulder');
    addShoulder(standardRear.shell,`standardCanopyRearShoulder${side}`,sections,[-1.87,-1.19,-.85,rearClip],'beltPaint');
    addShoulder(s1Rear.shell,`s1CanopyRearShoulder${side}`,s1Sections,[-1.876,-1.647,-1.401,-1.171,-1.006,rearClip],'s1Gold');
  }
  const roofUnder = [roofFR,roofFL,roofRL,roofRR];
  const roofEdge = [[-.809,1.931,.169],[.809,1.931,.169],[.844,1.935,-.952],[-.844,1.935,-.952]];
  const roofCrown = [[-.642,canopy.roofY,.106],[.642,canopy.roofY,.106],[.667,canopy.roofY,-.899],[-.667,canopy.roofY,-.899]];
  function capRing(a,b) { return a.map((p,i)=>[p,a[(i+1)%a.length],b[(i+1)%a.length],b[i]]); }
  panel(cabin,'roofOuterBevel',capRing(roofUnder,roofEdge),'bodyWhite',[0,1,0]);
  panel(cabin,'roofCrown',[...capRing(roofEdge,roofCrown),roofCrown],'roofWhite',[0,1,0]);

  // Interior hard surfaces share the car's axes, so the same body pivot carries both the shell and the driver's eye.
  const wheelCenter=[.500,1.216,.042], wheelTilt=group('steeringColumn',cockpit);
  const wheelRadius=.257;
  const gloveSteerStation=1.17, rimSteps=26;
  wheelTilt.position.set(...wheelCenter); wheelTilt.rotation.x=.212;
  const wheelSpin=group('steeringWheel',wheelTilt);
  const arms=[], eyeMirror=group('cabinMirror',cockpit);
  const axisY=new T.Vector3(0,1,0);
  const limbVector=new T.Vector3();
  const qTube=new T.Quaternion();
  function shapeBetween(a,b) {
    const delta=new T.Vector3().subVectors(b,a);
    qTube.setFromUnitVectors(axisY,delta.clone().normalize());
    const e=new T.Euler().setFromQuaternion(qTube);
    return [a.clone().lerp(b,.5).toArray(),[e.x,e.y,e.z],delta.length()];
  }
  function bar(parent,name,from,to,r,material,sides=7,endRadius=r) {
    const [at,rotation,length]=shapeBetween(new T.Vector3(...from),new T.Vector3(...to));
    return piece(parent,name,new T.CylinderGeometry(endRadius,r,length,sides),material,at,rotation);
  }
  function faceted(parent,name,at,size,material,detail=0,angle) {
    const geo=new T.IcosahedronGeometry(1,detail);
    geo.scale(...size);
    return piece(parent,name,geo,material,at,angle);
  }
  panel(cockpit,'roofLiner',[[[-.843,1.885,.181],[.843,1.885,.181],[.868,1.886,-.953],[-.868,1.886,-.953]]],
    'liner',[0,-1,0],{double:true});
  bar(cockpit,'frontCrossTube',[-.831,1.833,.250],[.831,1.833,.250],.049,'cage');
  bar(cockpit,'rearCrossTube',[-.850,1.809,-1.028],[.850,1.809,-1.028],.039,'cage');
  const dashCuts=[-1.053,-.91,-.46,-.05,.35,.77,1.051];
  const rimLine=dashCuts.map(x=>[x,1.257+(.024*(1-Math.abs(x))),.155+Math.abs(x)*.066]);
  const rimBottom=rimLine.map(([x,y,z])=>[x,y-.085,z-.037]);
  const scuttle=dashCuts.map(x=>[x*.988,1.345,.869]);
  const shelf=rimLine.map(([x,y,z])=>[x,y+.026,z+.132]);
  panel(cockpit,'facetedDashboard',bridge(rimLine,shelf).concat(bridge(shelf,scuttle)),'dash',[0,1,0],{double:true});
  panel(cockpit,'dashboardFace',bridge(rimBottom,rimLine),'dashFace',[0,0,-1]);
  panel(cockpit,'gloveboxPanel',[[[-1.058,.894,.218],[-.086,.894,.182],[-.086,1.171,.184],[-1.058,1.171,.218]]],
    'dashFace',[0,0,-1]);
  box(cockpit,'gloveboxHandle','liner',[.209,.021,.031],[-.612,1.087,.181]);
  box(cockpit,'dashEdge','dashEdge',[1.95,.018,.022],[0,1.243,.169]);
  box(cockpit,'centreTunnel','dashFace',[.272,.374,1.61],[-.049,.829,-.210]);
  for(const side of [1,-1]) {
    bar(cockpit,`frontCageUpright${side}`,[side*1.016,1.246,.783],[side*.829,1.829,.248],.053,'cage',7,.048);
    bar(cockpit,`roofCageRail${side}`,[side*.829,1.833,.250],[side*.847,1.811,-1.028],.044,'cage');
    bar(cockpit,`rearCageUpright${side}`,[side*1.000,.901,-1.561],[side*.846,1.813,-1.026],.037,'cage');
    bar(cockpit,`doorCageBar${side}`,[side*1.000,.945,.779],[side*.941,1.160,-1.427],.036,'dashEdge');
    const railA=[side*1.061,1.318,.853], railB=[side*1.058,1.318,-1.599];
    panel(cockpit,`innerDoor${side}`,[[[side*1.052,.672,.855],[side*1.041,.693,-1.609],railB,railA]],'dash',[side,0,0],{double:true});
    panel(cockpit,`doorSillCap${side}`,[[railA,railB,[side*1.108,1.337,-1.607],[side*1.102,1.344,.872]]],'liner',[0,1,0]);
    box(cockpit,`doorPull${side}`,'dashEdge',[.031,.024,.231],[side*1.025,1.202,.340]);
    box(cockpit,`doorRelease${side}`,'cageHardware',[.020,.015,.089],[side*1.016,1.241,.394]);

    box(cockpit,`bucketCushion${side}`,'seatCloth',[.454,.095,.467],[side*.468,.874,-.816],[-.12,0,0]);
    box(cockpit,`bucketBack${side}`,'seatCloth',[.442,.565,.098],[side*.468,1.178,-1.081],[-.200,0,0]);
    for(const lip of [1,-1]) bar(cockpit,`bucketBolster${side}-${lip}`,[side*.468+lip*.199,.948,-1.032],
      [side*.468+lip*.174,1.438,-1.105],.038,'seatBolster',7,.048);
    for(const dx of [-.095,.095]) box(cockpit,`harness${side}-${dx}`,'harness',[.040,.317,.024],[side*.468+dx,1.25,-1.016],[-.19,0,0]);
  }
  const dashShape=[[.178,1.252],[.172,1.339],[.209,1.402],[.288,1.440],[.714,1.440],[.795,1.393],[.824,1.327],[.817,1.249]];
  const shellBack=dashShape.map(([x,y])=>[mix(x,.501,.08),y-.012,.374]);
  const shellFront=dashShape.map(([x,y])=>[x,y,.168]);
  panel(cockpit,'instrumentHood',capRing(shellFront,shellBack).map((p,i)=>({p,n:[i<3?-1:i>4?1:0,i===7?-1:1,0]})),'liner');
  panel(cockpit,'instrumentBezel',[shellFront],'dashEdge',[0,0,-1]);
  const dashDisplay=group('digitalInstruments',cockpit); dashDisplay.position.set(.501,1.341,.156); dashDisplay.rotation.x=-.040;
  const gearDisplay=group('gearDisplay',cockpit), controlDisplay=group('controlDisplay',cockpit);
  box(cockpit,'gearDisplayHousing','liner',[.103,.089,.082],[-.261,1.331,.288],[-.13,0,0]);
  box(cockpit,'controlDisplayHousing','liner',[.175,.068,.084],[-.436,1.323,.289],[-.13,0,0]);
  gearDisplay.position.set(-.261,1.327,.246);gearDisplay.rotation.x=-.13;
  controlDisplay.position.set(-.436,1.322,.246);controlDisplay.rotation.x=-.13;
  const gaugeX=-.069;
  cylinder(cockpit,'gaugeCase','liner',.120,.037,12,[gaugeX,1.347,.269],'z');
  cylinder(cockpit,'gaugeDial','dialWhite',.099,.006,16,[gaugeX,1.347,.246],'z');
  box(cockpit,'gaugeNeedle','warmKnob',[.037,.006,.006],[gaugeX+.010,1.344,.241],[0,0,-.29]);
  box(cockpit,'shiftTellTaleHousing','liner',[.048,.024,.041],[-.146,1.313,.267]);
  for(const [i,y] of [1.167,1.148,1.129,1.110].entries()) {
    box(cockpit,`dashVentSlat${i}`,'liner',[.238,.010,.019],[-.105,y,.128]);
    box(cockpit,`dashVentSlatPassenger${i}`,'liner',[.238,.010,.019],[-.774,y,.195]);
  }
  for(const [i,x] of [-.210,-.142,-.074,-.006].entries()) {
    box(cockpit,`consoleLabel${i}`,'dashEdge',[.038,.018,.075],[x,1.015,.024]);
    bar(cockpit,`toggleSwitch${i}`,[x,1.024,.031],[x+.008,1.066,.042],.009,i===1?'warmKnob':'cageHardware',6);
  }
  const shifter=group('gearShifter',cockpit); shifter.position.set(.137,1.020,-.018);
  box(cockpit,'shiftBoot','liner',[.151,.039,.145],[.137,1.005,-.018]);
  for(const [i,y] of [.016,.027,.039].entries()) box(cockpit,`shiftGaiter${i}`,'dashEdge',[.118-i*.024,.011,.110-i*.021],[.137,1.020+y,-.018]);
  bar(shifter,'shiftLever',[0,.026,0],[0,.235,0],.018,'shiftMetal',8);
  bar(shifter,'sequentialGrip',[0,.208,0],[0,.309,0],.032,'wheelRubber',8,.034);
  const knobShape=new T.LatheGeometry([[0,.293],[.037,.293],[.049,.302],[.051,.347],[.044,.354],[0,.354]]
    .map(p=>new T.Vector2(...p)),8);
  knobShape.rotateY(Math.PI/8);
  piece(shifter,'amberSequentialGearKnob',knobShape,'warmKnob');
  const gearGrip=socket('gearHandAnchor',shifter,0,.263,0); gearGrip.rotation.z=-Math.PI/2;

  const brakeArm=group('handbrakeLever',cockpit); brakeArm.position.set(-.098,1.025,.098);
  box(cockpit,'handbrakeBracket','dashFace',[.210,.113,.309],[-.072,.961,.111],[-.04,0,0]);
  box(cockpit,'handbrakeMount','liner',[.116,.059,.154],[-.098,1.020,.098]);
  cylinder(cockpit,'handbrakePivotPin','wheelMetal',.028,.070,8,[-.098,1.046,.098],'x');
  bar(brakeArm,'handbrake',[0,.024,0],[-.010,.192,.024],.016,'shiftMetal',8);
  bar(brakeArm,'handbrakeGrip',[-.010,.155,.020],[-.016,.239,.033],.031,'wheelRubber',8,.030);
  bar(brakeArm,'handbrakeCap',[-.015,.219,.030],[-.018,.248,.035],.038,'wheelMetal',8,.036);
  const brakeGrip=socket('brakeHandAnchor',brakeArm,-.013,.184,.025); brakeGrip.rotation.set(.12,0,-Math.PI/2,'ZXY');
  box(cockpit,'pedalPlate','liner',[.491,.108,.249],[.475,.722,.697],[-.15,0,0]);
  for (const x of [.343,.482,.610]) box(cockpit,`pedal${x}`,'cageHardware',[.063,.081,.026],[x,.786,.684],[-.32,0,0]);

  eyeMirror.position.set(-.444,1.755,.309); eyeMirror.rotation.y=.12; eyeMirror.rotation.z=-.016;
  bar(cockpit,'interiorMirrorStem',[-.365,1.880,.279],[-.428,1.804,.311],.021,'liner',6);
  box(eyeMirror,'interiorMirrorCase','liner',[.534,.153,.033],[0,0,0]);
  const cabinMirrorFace=group('interiorMirrorFace',eyeMirror); cabinMirrorFace.position.z=-.019;
  bar(cockpit,'steeringShaft',[.500,1.211,.211],wheelCenter,.045,'liner');
  const stitchedRim=new T.TorusGeometry(wheelRadius,.036,8,rimSteps);
  const rimClock=Math.PI/2-gloveSteerStation-Math.PI/rimSteps;
  stitchedRim.rotateZ(rimClock);
  piece(wheelSpin,'wrappedWheelRim',stitchedRim,'wheelRubber');
  const rimSeam=new T.TorusGeometry(.233,.003,5,rimSteps);rimSeam.rotateZ(rimClock);
  piece(wheelSpin,'wheelMouldingSeam',rimSeam,'dashEdge',[0,0,-.030]);
  const spoke=[[-.061,-.034],[-.090,.044],[-.251,.055],[-.252,-.001],[-.097,-.039]];
  const rimSpokes=[spoke,spoke.map(([x,y])=>[-x,y]),[[-.054,.018],[.058,.018],[.037,-.249],[-.036,-.249]]];
  panel(wheelSpin,'brushedThreeSpokes',rimSpokes.map(p=>p.map(([x,y])=>[x,y,-.022])),'wheelMetal',[0,0,-1]);
  cylinder(wheelSpin,'steeringCentre','wheelMetal',.167,.042,8,[0,.003,-.022],'z');
  cylinder(wheelSpin,'steeringHorn','liner',.118,.037,8,[0,.003,-.041],'z');
  for(const x of [-.079,.079]) cylinder(wheelSpin,`spokeFastener${x}`,'cageHardware',.015,.008,7,[x,.002,-.031],'z');
  box(wheelSpin,'rimCentreMarker','warmKnob',[.048,.078,.036],[0,.259,-.019],[.035,0,0]);
  for(const a of [-1.65,-1.00,1.00,1.65]) box(wheelSpin,`rimSeam${a}`,'liner',[.008,.041,.023],
    [Math.sin(a)*.255,Math.cos(a)*.255,-.024],[0,0,-a]);

  // In the contact frame, +X follows the rim or handle and +Y crosses it toward the fingertips.
  const ringN=10;
  const wheelPalm=[
    [-.106,-.070,-.084,.028,.022,.08],[-.095,-.069,-.076,.030,.024,.13],[-.082,-.068,-.066,.033,.024,.20],
    [-.064,-.065,-.051,.039,.025,.32],[-.045,-.063,-.035,.042,.025,.53],[-.026,-.060,-.020,.044,.024,.73],
    [-.013,-.058,-.003,.045,.020,.88],[-.003,-.055,.012,.043,.018,1.00],[.002,-.049,.024,.039,.014,.99],
  ];
  const leverPalm=[
    [-.071,-.102,-.069,.027,.022,.09],[-.062,-.095,-.063,.029,.024,.20],[-.050,-.085,-.058,.032,.024,.30],
    [-.035,-.070,-.049,.036,.025,.46],[-.022,-.057,-.038,.041,.025,.59],[-.009,-.050,-.020,.046,.023,.77],
    [0,-.051,-.004,.048,.020,.91],[.005,-.050,.012,.047,.018,1.04],[.007,-.048,.024,.042,.014,.99],
  ];
  function newPalm(hand) {
    const geometry=new T.BufferGeometry(), indices=[], shade=[];
    const count=wheelPalm.length*ringN;
    for(let i=0;i<wheelPalm.length;i++) for(let j=0;j<ringN;j++) {
      const offset=i*ringN, a=offset+j,b=offset+(j+1)%ringN;
      if(i<wheelPalm.length-1) indices.push(a,a+ringN,b,b,a+ringN,b+ringN);
      const tint=i===1?.87:i===0?.95:i===2?.98:1;
      shade.push(tint,tint,tint);
    }
    for(let j=1;j<ringN-1;j++) indices.push(count-ringN,count-ringN+j+1,count-ringN+j);
    const attr=new T.BufferAttribute(new Float32Array(count*3),3);attr.setUsage(T.DynamicDrawUsage);
    geometry.setAttribute('position',attr);
    geometry.setAttribute('color',new T.Float32BufferAttribute(shade,3));
    geometry.setIndex(indices);
    piece(hand,'formedGlovePalm',geometry,'driverPalm',null,null,{shadow:false});
    return geometry;
  }
  const fingerSections=[1.06,1.04,1.01,.99,.97,.96,.93,.83,.58], fingerSides=8, fingerRingCount=fingerSections.length;
  function newFinger(hand,name) {
    const geometry=new T.BufferGeometry(), count=fingerRingCount*fingerSides+2, indices=[];
    for(let i=0;i<fingerRingCount-1;i++) for(let j=0;j<fingerSides;j++) {
      const a=i*fingerSides+j,b=i*fingerSides+(j+1)%fingerSides,c=b+fingerSides,d=a+fingerSides;
      indices.push(a,b,d,b,c,d);
    }
    for(let j=0;j<fingerSides;j++) {
      const k=(j+1)%fingerSides, end=(fingerRingCount-1)*fingerSides;
      indices.push(count-2,k,j,count-1,end+j,end+k);
    }
    const attr=new T.BufferAttribute(new Float32Array(count*3),3);attr.setUsage(T.DynamicDrawUsage);
    geometry.setAttribute('position',attr);geometry.setIndex(indices);
    piece(hand,name,geometry,'driverWhite',null,null,{shadow:false});
    return geometry;
  }
  const digitPoints=Array.from({length:fingerRingCount},()=>new T.Vector3());
  const digitAcross=new T.Vector3(),digitTangent=new T.Vector3(),digitNormal=new T.Vector3(),digitGuide=new T.Vector3(),digitEnd=new T.Vector3();
  const wheelCurl=[[-.055,.015],[-.048,.030],[-.030,.043],[-.009,.050],[.015,.048],[.037,.034],[.048,.014],[.044,-.013],[.035,-.032]];
  const leverCurl=[[-.051,.014],[-.044,.030],[-.027,.043],[-.005,.048],[.018,.045],[.037,.035],[.046,.015],[.040,-.026],[.017,-.044]];
  const gearIndexCurl=[[.040,-.053,.012],[.062,-.054,.015],[.086,-.049,.014],[.100,-.022,.014],[.101,.005,.016],
    [.096,.035,.018],[.079,.054,.009],[.062,.052,-.019],[.047,.038,-.041]];
  const openCurl=[[-.054,.014],[-.046,.032],[-.030,.048],[-.009,.059],[.016,.064],[.038,.064],[.061,.060],[.079,.052],[.092,.045]];
  const wheelThumb=[[-.046,-.063,-.041],[-.028,-.055,-.046],[-.010,-.042,-.052],[.005,-.028,-.055],
    [.018,-.012,-.054],[.028,.007,-.051],[.036,.023,-.046],[.039,.034,-.036],[.037,.036,-.026]];
  const leverThumb=[[-.023,-.075,-.061],[.001,-.066,-.061],[.025,-.055,-.062],[.046,-.045,-.063],
    [.061,-.026,-.062],[.072,-.007,-.061],[.076,.010,-.057],[.075,.023,-.052],[.072,.031,-.048]];
  const palmTangent=new T.Vector3(), palmDepth=new T.Vector3(), palmAcross=new T.Vector3(), cuffBasis=new T.Matrix4();
  function writeDigit(geometry,radius,thumb=false) {
    const position=geometry.attributes.position;
    for(let i=0;i<fingerRingCount;i++) {
      const p=digitPoints[i];
      digitTangent.subVectors(digitPoints[Math.min(i+1,fingerRingCount-1)],digitPoints[Math.max(i-1,0)]).normalize();
      digitGuide.set(1,0,0);
      if(thumb) digitGuide.set(.04,.88,-.46);
      digitAcross.copy(digitGuide).addScaledVector(digitTangent,-digitGuide.dot(digitTangent)).normalize();
      digitNormal.crossVectors(digitTangent,digitAcross).normalize();
      const r=radius*fingerSections[i];
      for(let j=0;j<fingerSides;j++) {
        const a=(j+.5)*Math.PI*2/fingerSides,rx=Math.cos(a)*r,rz=Math.sin(a)*r*.88;
        position.setXYZ(i*fingerSides+j,p.x+digitAcross.x*rx+digitNormal.x*rz,
          p.y+digitAcross.y*rx+digitNormal.y*rz,p.z+digitAcross.z*rx+digitNormal.z*rz);
      }
    }
    digitEnd.copy(digitPoints[0]);position.setXYZ(position.count-2,digitEnd.x,digitEnd.y,digitEnd.z);
    digitEnd.copy(digitPoints.at(-1)).addScaledVector(digitTangent,radius*.37);
    position.setXYZ(position.count-1,digitEnd.x,digitEnd.y,digitEnd.z);
    position.needsUpdate=true;geometry.computeVertexNormals();geometry.computeBoundingSphere();
  }
  function formGlove(arm,opening,profile=0,braking=0) {
    const {side,fingers,thumb,palm}=arm;
    const version=`${Math.round(opening*170)}:${Math.round(profile*170)}:${Math.round(braking*170)}`;
    if(arm.gripVersion===version)return;
    arm.gripVersion=version;
    const palmPosition=palm.attributes.position, size=1-braking*.11;
    const sections=wheelPalm.map((row,i)=>blend(row,leverPalm[i],profile));
    for(let i=0;i<wheelPalm.length;i++) {
      const [x,y,z,wide,deep,tilt]=sections[i];
      const [ax,ay,az]=sections[Math.max(0,i-1)], [bx,by,bz]=sections[Math.min(i+1,sections.length-1)];
      palmTangent.set(side*(bx-ax),by-ay,bz-az).normalize();
      palmDepth.set(0,-Math.sin(tilt),Math.cos(tilt));
      palmAcross.crossVectors(palmTangent,palmDepth).normalize();
      palmDepth.crossVectors(palmAcross,palmTangent);
      if(i===0) {
        arm.cuff.set(side*x*size,y*size,z*size);
        arm.cuffFrame.setFromRotationMatrix(cuffBasis.makeBasis(palmAcross,palmTangent,palmDepth));
      }
      for(let j=0;j<ringN;j++) {
        const angle=(j+.5)*Math.PI*2/ringN, xx=wide*Math.cos(angle), zz=deep*Math.sin(angle);
        palmPosition.setXYZ(i*ringN+j,(x*side+palmAcross.x*xx+palmDepth.x*zz)*size,
          (y+palmAcross.y*xx+palmDepth.y*zz)*size,(z+palmAcross.z*xx+palmDepth.z*zz)*size);
      }
    }
    palmPosition.needsUpdate=true;palm.computeVertexNormals();palm.computeBoundingSphere();
    for(let i=0;i<fingers.length;i++) {
      const rimStation=[.032,.009,-.014,-.036][i], leverStation=[.044,.015,-.011,-.035][i];
      const r=mix([.0119,.0120,.0113,.0105][i],[.0134,.0141,.0132,.0123][i],profile);
      const capGrip=profile*(1-braking)*(1-opening);
      for(let k=0;k<fingerRingCount;k++) {
        const [wy,wz]=wheelCurl[k], [ly,lz]=leverCurl[k], [oy,oz]=openCurl[k], f=k/(fingerRingCount-1);
        const [ix,iy,iz]=gearIndexCurl[k], wrap=i===0?capGrip:0;
        const short=i===3?1-.064*f:1;
        const along=side*mix(mix(rimStation,leverStation,profile)-i*.0011*f,ix,wrap);
        const curvature=(wheelRadius-Math.sqrt(wheelRadius**2-along**2))*(1-profile);
        const dy=mix(mix(mix(wy,ly,profile),iy,wrap),oy,opening)*short;
        const dz=mix(mix(mix(wz,lz,profile),iz,wrap),oz,opening)+(i-1.5)*.0021*f;
        digitPoints[k].set(along*size,(dy+curvature)*size,dz*size);
      }
      writeDigit(fingers[i],r*size);
    }
    for(let k=0;k<fingerRingCount;k++) {
      const [x,y,z]=blend(wheelThumb[k],leverThumb[k],profile), f=k/(fingerRingCount-1);
      digitPoints[k].set(side*(x+.015*opening*f)*size,(y-.049*opening*f)*size,(z-.026*opening*f)*size);
    }
    writeDigit(thumb,.0171*size,true);
  }

  const wristCuts=[0,.36,.71,1], sleevePoint=new T.Vector3(), cuffPoint=new T.Vector3(), wristSectionPoint=new T.Vector3();
  function newWristLink(parent,name) {
    const geometry=new T.BufferGeometry(), index=[];
    const attr=new T.BufferAttribute(new Float32Array(wristCuts.length*ringN*3),3);attr.setUsage(T.DynamicDrawUsage);
    geometry.setAttribute('position',attr);
    for(let i=1;i<wristCuts.length;i++) for(let j=0;j<ringN;j++) {
      const a=(i-1)*ringN+j,b=(i-1)*ringN+(j+1)%ringN,c=b+ringN,d=a+ringN;
      index.push(a,d,b,b,d,c);
    }
    geometry.setIndex(index);
    piece(parent,name,geometry,'driverSleeve',null,null,{shadow:false});
    return geometry;
  }
  function writeWrist(arm) {
    const attr=arm.wristLink.attributes.position;
    if(!arm.sleeve) arm.sleeve=arm.lower.getObjectByName('forearmBone');
    const pan=arm.sleeve.geometry.attributes.position;
    const palmPosition=arm.palm.attributes.position;
    arm.lower.updateMatrix();
    for(let j=0;j<ringN;j++) {
      sleevePoint.fromBufferAttribute(pan,((ringN-j)%ringN)*6+5).applyMatrix4(arm.lower.matrix);
      cuffPoint.fromBufferAttribute(palmPosition,j).applyQuaternion(arm.hand.quaternion).add(arm.hand.position);
      for(let i=0;i<wristCuts.length;i++) {
        wristSectionPoint.copy(sleevePoint).lerp(cuffPoint,wristCuts[i]);
        attr.setXYZ(i*ringN+j,wristSectionPoint.x,wristSectionPoint.y,wristSectionPoint.z);
      }
    }
    attr.needsUpdate=true;arm.wristLink.computeVertexNormals();arm.wristLink.computeBoundingSphere();
  }

  for(const side of [1,-1]) {
    const grip=group(`handGrip${side}`,wheelSpin);
    grip.rotation.order='ZYX';
    const hand=group(`stickHand${side}`,driver);
    const palm=newPalm(hand);
    const fingers=Array.from({length:4},(_,i)=>newFinger(hand,`seamlessGloveFinger${i+1}`));
    const thumb=newFinger(hand,'opposedThumb');
    const lower=group(`stickForearm${side}`,driver);
    const forearm=new T.LatheGeometry([[.038,-.5],[.047,-.37],[.045,-.13],[.038,.13],[.032,.30],[.0275,.451]]
      .map(p=>new T.Vector2(...p)),ringN);forearm.rotateY(Math.PI/2-Math.PI/ringN);forearm.scale(1,1,.86);
    piece(lower,'forearmBone',forearm,'driverSleeve',null,null,{shadow:false});
    const arm={side,grip,hand,palm,fingers,thumb,lower,cuff:new T.Vector3(),cuffFrame:new T.Quaternion(),wristLink:newWristLink(driver,`fittedWrist${side}`),gripVersion:'',
      shoulder:new T.Vector3(wheelCenter[0]+side*.263,1.238,-.659)};
    formGlove(arm,0);arms.push(arm);
  }

  for (const side of [1,-1]) {
    box(mirrors,`mirrorStalk${side}`,'deep',[.175,.054,.081],[side*1.135,1.345,.893],[0,0,side*.15]);
    const shell = [[1.121,1.318,.807],[1.375,1.327,.815],[1.395,1.445,.815],[1.144,1.443,.807]].map(([x,y,z])=>[side*x,y,z]);
    const nose = shell.map(([x,y])=>[x-side*.014,mix(1.382,y,.82),.990]);
    panel(mirrors,`mirrorShell${side}`,[{ p:shell,n:[0,0,-1] },{ p:nose,n:[0,0,1] },
      ...capRing(shell,nose).map((p,i)=>({p,n:[[0,-1,0],[side,0,0],[0,1,0],[-side,0,0]][i]}))],'bumper');
    panel(mirrors,`mirrorGlass${side}`,[inset(shell,.075,.93,.116,.889,[0,0,-.003])],'mirror',[0,0,-1]);
  }
  const { high }=spoilers;
  function foil(parent, name, profile, spans, top, underside, tip) {
    const rows=spans.map(([x,dy,scale,dz])=>profile.map(([y,z])=>[x,y+dy,-2.40+(z+2.40)*scale+dz]));
    const crown=[], bottom=[], edges=[];
    const winding=Math.sign(profile.reduce((s,[y,z],i)=>{const [yy,zz]=profile[(i+1)%profile.length];return s+z*yy-zz*y;},0));
    for(let j=1;j<rows.length;j++) for(let i=0;i<profile.length;i++) {
      const k=(i+1)%profile.length;
      const p=[rows[j-1][i],rows[j][i],rows[j][k],rows[j-1][k]];
      const face={ p,n:[0,winding*(profile[i][1]-profile[k][1]),winding*(profile[k][0]-profile[i][0])] };
      if (tip && (j===1 || j===rows.length-1)) edges.push(face);
      else (i<6?crown:bottom).push(face);
    }
    panel(parent,`${name}Crown`,crown,top); panel(parent,`${name}Underside`,bottom,underside);
    panel(parent,`${name}Tips`,[{p:rows[0],n:[-1,0,0]},{p:rows.at(-1),n:[1,0,0]},...edges],tip||top);
  }
  const worksProfile=[[1.685,-2.042],[1.720,-2.123],[1.767,-2.302],[1.817,-2.487],[1.884,-2.650],[1.929,-2.740],[1.917,-2.795],
    [1.873,-2.771],[1.820,-2.658],[1.745,-2.477],[1.689,-2.266],[1.648,-2.126],[1.654,-2.069]];
  foil(worksStandard.foil,'worksAirfoil',worksProfile,[[-1.263,.034,.75,.022],[-1.213,.028,.934,.004],[-1.119,.007,1,0],
    [-.747,0,1,0],[.747,0,1,0],[1.119,.007,1,0],[1.213,.028,.934,.004],[1.263,.034,.75,.022]],'wingWhite','wingShade','wingTip');
  const aftBends=[[-1.174,.015,.020],[-.746,0,0],[.746,0,0],[1.174,.015,.020]];
  const trailing=(y,z)=>aftBends.map(([x,dy,dz])=>[x,y+dy,z+dz]);
  panel(worksStandard.foil,'worksRolledTrailingEdge',bridge(trailing(1.875,-2.771),trailing(1.916,-2.798)),'wingWhite',[0,0,-1]);
  panel(worksStandard.foil,'worksUndersideSpanRib',bridge(trailing(1.799,-2.619),trailing(1.809,-2.642)),'wingWhite',[0,-1,-1]);

  foil(high.foil,'highAirfoil',[[2.167,-2.183],[2.187,-2.226],[2.208,-2.392],[2.226,-2.582],[2.235,-2.697],[2.227,-2.737],
    [2.194,-2.735],[2.166,-2.611],[2.148,-2.421],[2.144,-2.264]],
    [[-1.254,0,1,0],[1.254,0,1,0]],'wingWhite','wingShade');

  function blade(parent,name,side,profile,width,mat,outerMat=mat) {
    const caps=T.ShapeUtils.triangulateShape(profile.map(([y,z])=>new T.Vector2(z,y)),[]);
    const point=(i,dx)=>{const [y,z,x]=profile[i];return [side*(x+dx),y,z];};
    panel(parent,name,caps.flatMap(indices=>[ {p:indices.map(i=>point(i,width/2)),n:[side,0,0]},
      {p:indices.map(i=>point(i,-width/2)),n:[-side,0,0]} ]),outerMat);
    const area=profile.reduce((sum,[y,z],i)=>{const [ny,nz]=profile[(i+1)%profile.length];return sum+z*ny-nz*y;},0);
    const winding=Math.sign(area);
    panel(parent,`${name}Edge`,profile.map(([y,z],i)=>{
      const j=(i+1)%profile.length, [ny,nz]=profile[j];
      return {p:[point(i,-width/2),point(j,-width/2),point(j,width/2),point(i,width/2)],n:[0,winding*(z-nz),winding*(ny-y)]};
    }),mat);
  }
  const worksFace=[[-.994,1.282,-2.544],[.994,1.282,-2.544],[.858,1.540,-2.433],[-.858,1.540,-2.433]];
  panel(worksStandard.mounts,'worksRearPlinth',[worksFace],'wingWhite',[0,1,-1]);
  panel(worksStandard.mounts,'worksPlinthShelf',[[[-.91,1.327,-2.095],[.91,1.327,-2.095],worksFace[2],worksFace[3]]],'wingShade',[0,1,0]);

  foil(worksS1.foil,'s1WorksUpperAirfoil',[[1.842,-2.094],[1.882,-2.166],[1.942,-2.349],[1.986,-2.517],[2.024,-2.688],
    [2.043,-2.786],[2.024,-2.825],[1.979,-2.779],[1.940,-2.631],[1.882,-2.435],[1.812,-2.223],[1.821,-2.128]],
    [[-1.310,.019,.93,.029],[-1.236,.009,1,0],[-.985,0,1,0],[.985,0,1,0],[1.236,.009,1,0],[1.310,.019,.93,.029]],'s1Body','s1WingUnderside');
  foil(worksS1.foil,'s1WorksLowerAirfoil',[[1.704,-2.288],[1.731,-2.337],[1.764,-2.486],[1.797,-2.617],[1.815,-2.719],
    [1.797,-2.756],[1.756,-2.726],[1.728,-2.585],[1.689,-2.397],[1.679,-2.325]],
    [[-1.149,.008,.973,.003],[-.944,0,1,0],[.944,0,1,0],[1.149,.008,.973,.003]],'s1Body','s1WingUnderside');
  for (const side of [1,-1]) {
    blade(worksStandard.mounts,`worksSweptStrut${side}`,side,[[1.324,-2.117,.642],[1.306,-2.536,.669],[1.408,-2.539,.719],
      [1.526,-2.529,.775],[1.678,-2.584,.815],[1.841,-2.655,.860],[1.777,-2.477,.854],[1.730,-2.294,.837],
      [1.688,-2.270,.807],[1.552,-2.243,.746]],.086,'wingShade','wingWhite');
    blade(worksStandard.foil,`worksUpsweptTip${side}`,side,[[1.725,-2.124,1.204],[1.763,-2.207,1.225],[1.822,-2.407,1.241],
      [1.908,-2.629,1.249],[1.946,-2.741,1.239],[1.905,-2.765,1.231],[1.842,-2.714,1.235],
      [1.784,-2.595,1.236],[1.718,-2.397,1.231],[1.687,-2.223,1.209],[1.696,-2.156,1.197]],.043,'wingTip','wingWhite');
    const foot=[[side*.952,1.300,-2.528],[side*.833,1.301,-2.546],[side*.727,1.553,-2.457],[side*.810,1.553,-2.434]];
    panel(worksStandard.mounts,`worksBracedRearFace${side}`,[foot],'wingWhite',[0,1,-1]);
    const tipRivetSpots=[[1.705,-2.215,1.235],[1.760,-2.373,1.258],[1.807,-2.522,1.265],[1.865,-2.657,1.270]];
    for (const [i,[y,z,x]] of tipRivetSpots.entries()) cylinder(worksStandard.foil,`worksTipRivet${side}-${i}`,'wingBolt',.018,.009,8,[side*x,y,z],'x');

    blade(worksS1.mounts,`s1WorksSculptedUpright${side}`,side,[[1.303,-2.574,1.039],[1.321,-2.345,.953],[1.390,-2.173,.885],
      [1.498,-2.203,.911],[1.603,-2.288,.949],[1.733,-2.371,.982],[1.874,-2.393,1.006],[2.019,-2.492,1.020],
      [2.039,-2.724,1.018],[1.944,-2.706,1.015],[1.806,-2.652,1.029],[1.696,-2.600,1.041],[1.559,-2.576,1.047]],
      .068,'s1WingUnderside','s1Body');
    const shoulder=[[side*1.009,1.311,-2.578],[side*1.166,1.317,-2.486],[side*1.067,1.597,-2.493],[side*.955,1.643,-2.447]];
    panel(worksS1.mounts,`s1WingBaseFairing${side}`,[shoulder],'s1Body',[side,.45,-1],{double:true});
    const cap=[[2.085,-2.190,1.29],[2.092,-2.240,1.314],[2.065,-2.446,1.319],[2.054,-2.700,1.327],
      [2.051,-2.810,1.314],[1.987,-2.831,1.315],[1.863,-2.755,1.317],[1.772,-2.667,1.309],[1.749,-2.560,1.291],
      [1.770,-2.438,1.291],[1.828,-2.306,1.295],[1.954,-2.228,1.305]];
    blade(worksS1.foil,`s1DarkWorksEndplate${side}`,side,cap,.043,'s1GuardEdge','s1WingCap');
    for(const [y,z,x] of [[2.015,-2.255,1.330],[2.011,-2.414,1.346],[1.987,-2.569,1.352],[1.936,-2.708,1.348],[1.837,-2.644,1.336]]) {
      cylinder(worksS1.foil,`s1EndplateBolt${side}-${z}`,'s1Bolt',.019,.008,8,[side*x,y,z],'x');
    }

    blade(high.mounts,`highAngledStrut${side}`,side,[[deckY(-2.145)-.008,-2.099,.636],[deckY(-2.377)-.015,-2.381,.660],
      [2.172,-2.570,.735],[2.194,-2.430,.735],[1.443,-2.165,.646]],.053,'splitter','grilleBlack');
    box(high.mounts,`highMountFoot${side}`,'splitter',[.134,.029,.246],[side*.650,deckY(-2.212)+.005,-2.23],[.043,0,0]);
    solidX(high.foil,`highVerticalEndplate${side}`,[[2.257,-2.148],[2.299,-2.235],[2.283,-2.739],[2.043,-2.779],[1.907,-2.751],[1.917,-2.277]],
      side*1.258-.028,side*1.258+.028,'splitter','grilleBlack');
    for (const z of [-2.367,-2.633]) cylinder(high.foil,`highEndplateRivet${side}-${z}`,'wingBolt',.024,.009,8,[side*1.285,2.169,z],'x');
  }
  for (const x of [-.96,-.70,-.39,0,.39,.70,.96]) {
    cylinder(worksStandard.foil,`worksTrailingRivet${x}`,'wingBolt',.016,.008,8,[x,1.904,-2.793],'z');
    cylinder(worksS1.foil,`s1WingTrailingRivet${x}`,'s1Bolt',.015,.006,8,[x,2.023,-2.823],'z');
  }

  function latheX(parent,name,profile,segments,side,mat) {
    const faces = [];
    for (let j=1;j<profile.length;j++) for (let i=0;i<segments;i++) {
      const a = i/segments*Math.PI*2, b=(i+1)/segments*Math.PI*2;
      const point = ([x,r],p) => [side*x,r*Math.cos(p),r*Math.sin(p)];
      const [x0,r0]=profile[j-1], [x1,r1]=profile[j];
      const n = [side*(r0-r1),(x1-x0)*Math.cos((a+b)/2),(x1-x0)*Math.sin((a+b)/2)];
      faces.push({ p:[point(profile[j-1],a),point(profile[j-1],b),point(profile[j],b),point(profile[j],a)],n });
    }
    return panel(parent,name,faces,mat);
  }
  const frontWheelTrims=[];
  for (const { pivot,axle,rim,side,end } of Object.values(wheels)) {
    const spokes=end==='F'?group('classicRim',rim):rim;
    latheX(axle,'tyre',[[-.166,.351],[-.197,.418],[-.161,.466],[-.114,radius],[.110,radius],[.166,.464],[.193,.421],[.179,.349]],20,side,'rubber');
    latheX(spokes,'outerRim',[[.091,.345],[.161,.355],[.182,.359],[.197,.348],[.197,.332],[.165,.317],[.102,.313]],20,side,'alloy');
    cylinder(spokes,'barrel','deep',.626,.138,20,[side*.017,0,0],'x');
    cylinder(spokes,'brakeDisc','steel',.508,.022,16,[side*.101,0,0],'x');
    cylinder(spokes,'brakeHat','bareAlloy',.200,.034,10,[side*.123,0,0],'x');
    for (let i=0;i<5;i++) {
      const a = i*Math.PI*2/5+(end === 'F' ? .07 : .37);
      const polar = (r,w) => [r*Math.cos(a)-w*Math.sin(a),r*Math.sin(a)+w*Math.cos(a)];
      const spoke = [polar(.066,-.071),polar(.282,-.040),polar(.325,-.035),polar(.332,.039),polar(.271,.047),polar(.066,.069)];
      solidX(spokes,`spoke${i+1}`,spoke,side*.143-.029,side*.143+.029,'alloyShade','alloy');
    }
    cylinder(spokes,'hub','alloy',.208,.039,10,[side*.155,0,0],'x');
    cylinder(spokes,'centerCap','steel',.096,.023,6,[side*.182,0,0],'x');
    for (let i=0;i<5;i++) {
      const a = (i+.5)*Math.PI*2/5;
      cylinder(spokes,`lug${i+1}`,'steel',.022,.017,6,[side*.183,.080*Math.cos(a),.080*Math.sin(a)],'x');
    }
    if(end!=='F') continue;

    const disc=group('evoRim',rim), caliper=group('evoBrake',pivot);
    frontWheelTrims.push({spokes,disc,caliper});
    latheX(disc,'evoPolishedRim',[[.098,.349],[.172,.359],[.199,.351],[.212,.338],[.212,.324],[.198,.308],[.170,.298]],28,side,'evoAlloy');
    latheX(disc,'evoInsetRim',[[.126,.315],[.170,.317],[.177,.304],[.163,.299]],28,side,'evoRimShadow');
    cylinder(disc,'evoBrakeRotor','evoRimShadow',.556,.033,28,[side*.065,0,0],'x');
    box(caliper,'evoRedCaliper','redHardware',[.049,.156,.109],[side*.112,.076,-.189],[.37,0,0]);

    const outline=Array.from({length:28},(_,i)=>new T.Vector2(.312*Math.cos(i*Math.PI/14),.312*Math.sin(i*Math.PI/14)));
    const windows=Array.from({length:5},(_,i)=>{
      const a=i*Math.PI*2/5+.36;
      return Array.from({length:10},(_,j)=>{
        const t=-j*Math.PI/5, r=.221+.061*Math.cos(t), w=.067*Math.sin(t)*(1+.18*Math.cos(t));
        return new T.Vector2(r*Math.cos(a)-w*Math.sin(a),r*Math.sin(a)+w*Math.cos(a));
      });
    });
    const points=outline.concat(...windows);
    const onDisc=(p,d=0)=>[side*(.144+.033*Math.hypot(p.x,p.y)/.312+d),p.x,p.y];
    const faces=T.ShapeUtils.triangulateShape(outline,windows).map(indices=>indices.map(i=>onDisc(points[i])));
    panel(disc,'evoFiveWebWheelFace',faces,'evoAlloy',[side,0,0]);
    const portWalls=[];
    for(const ring of windows) {
      const cy=ring.reduce((s,p)=>s+p.x,0)/ring.length, cz=ring.reduce((s,p)=>s+p.y,0)/ring.length;
      for(let i=0;i<ring.length;i++) {
        const a=ring[i], b=ring[(i+1)%ring.length];
        portWalls.push({p:[onDisc(a),onDisc(b),onDisc(b,-.029),onDisc(a,-.029)],n:[side*.07,cy-(a.x+b.x)/2,cz-(a.y+b.y)/2]});
      }
    }
    panel(disc,'evoWheelWindowReturns',portWalls,'evoRimShadow');
    cylinder(disc,'evoCenterHub','evoAlloy',.195,.039,15,[side*.153,0,0],'x');
    cylinder(disc,'evoInsetHub','evoSocketShade',.092,.023,12,[side*.175,0,0],'x');
    for(let i=0;i<5;i++) {
      const a=i*Math.PI*2/5+.36;
      cylinder(disc,`evoLug${i+1}`,'evoRimShadow',.023,.012,6,[side*.174,.068*Math.cos(a),.068*Math.sin(a)],'x');
    }
  }

  const pods = [], classicLamps=noses.classic.lamps, evoLamps=noses.evo.lamps;
  box(classicLamps,'classicFrontGrille','deep',[1.751,.224,.049],[0,.944,2.573]);
  for (const y of [.866,.904,.942,.980,1.015]) box(classicLamps,`classicGrilleSlat${y}`,'arch',[1.262,.009,.014],[0,y,2.604]);
  const grilleCuts=ordered([-.714,.714,...frontCuts.filter(x=>Math.abs(x)<.714)]);
  const grilleBase=grilleCuts.map(x=>evoMask(x,.206,.0019)), grilleTop=grilleCuts.map(x=>evoMask(x,.796,.0019));
  panel(evoLamps,'evoGrilleInset',bridge(grilleBase,grilleTop).map((p,i)=>{
    const a=(grilleCuts[i]+.714)/1.428, b=(grilleCuts[i+1]+.714)/1.428;
    return {p,uv:[[a,0],[b,0],[b,1],[a,1]]};
  }),'evoGrilleMesh',[0,0,1]);
  function lampFaces(map,q,padX,padV,depth) {
    const cx=(q.x0+q.x1)/2, cy=(q.lo+q.hi)/2;
    const xs=ordered([...portCuts(q),...frontCuts.filter(x=>x>q.x0&&x<q.x1)]);
    return xs.slice(1).map((x,i)=>{
      const a=xs[i], vl=(v,x)=>map(mix(x,cx,padX),mix(v,cy,padV),depth);
      return {p:[vl(portV(q,a,false),a),vl(portV(q,x,false),x),vl(portV(q,x,true),x),vl(portV(q,a,true),a)],
        uv:[[(a-q.x0)/(q.x1-q.x0),0],[(x-q.x0)/(q.x1-q.x0),0],[(x-q.x0)/(q.x1-q.x0),1],[(a-q.x0)/(q.x1-q.x0),1]]};
    });
  }
  for (const side of [1,-1]) {
    const x = side*.815;
    const hand=side===1?'L':'R';
    box(classicLamps,`mainLampHousing${side}`,'bumper',[.443,.242,.085],[x,.931,2.570]);
    box(classicLamps,`mainLampBezel${side}`,'bareAlloy',[.385,.180,.021],[x,.944,2.616]);
    box(classicLamps,`rectLamp${side}`,'headlamp',[.345,.122,.020],[x,.962,2.625]);
    box(classicLamps,`indicator${side}`,'indicator',[.344,.042,.024],[x,.864,2.618]);
    pods.push({ id:'classic',name:`Main${hand}`, x,y:.962,z:2.64,size:.389,rect:true });
    for (const low of [false,true]) {
      const px = side*(low ? .583 : .388), y = low ? .654 : .926, z = low ? 2.70 : 2.660;
      const r = low ? .151 : .121, name = `Aux${low?'Low':'High'}${side===1?'L':'R'}`;
      box(classicLamps,`${name}Mount`,'steel',[.098,.082,.134],[px,y-.037,z-.095]);
      cylinder(classicLamps,`${name}Pod`,'bumper',r*2.16,.127,16,[px,y,z-.052],'z');
      cylinder(classicLamps,`${name}Retainer`,'goldHardware',r*2.04,.043,16,[px,y,z+.012],'z');
      cylinder(classicLamps,`${name}Lens`,'auxLamp',r*1.81,.024,16,[px,y,z+.039],'z');
      pods.push({ id:'classic',name,x:px,y,z:z+.056,size:r*4.1 });
    }
    const lamp=lampPorts[side===1?1:0], marker=markerPorts[side===1?1:0];
    panel(evoLamps,`evoLampBezel${hand}`,lampFaces(evoMask,lamp,.093,.089,-.021),'evoRimShadow',[0,0,1]);
    panel(evoLamps,`evoRectLamp${hand}`,lampFaces(evoMask,lamp,.177,.163,-.018),'evoLamp',[0,0,1]);
    panel(evoLamps,`evoIndicatorGasket${hand}`,lampFaces(evoFascia,marker,.018,.025,-.008),'evoSocketShade',[0,0,1]);
    panel(evoLamps,`evoAmberIndicator${hand}`,lampFaces(evoFascia,marker,.084,.115,-.005),'evoIndicator',[0,0,1]);
    const [ex,ey,ez]=evoMask(side*.898,.517,.015);
    pods.push({ id:'evo',name:`Evo${hand}`,x:ex,y:ey,z:ez,size:.303,rect:true });

    const tailX = side*.829;
    const tails=standardRear.lamps;
    box(tails,`tailGasket${side}`,'deep',[.462,.208,.048],[tailX,1.046,-2.537]);
    box(tails,`tailRed${side}`,'tailRed',[.437,.104,.016],[tailX,1.085,-2.565]);
    box(tails,`tailRedLow${side}`,'tailRed',[.281,.069,.017],[tailX+side*.076,.987,-2.565]);
    box(tails,`tailReverse${side}`,'tailReverse',[.137,.069,.017],[tailX-side*.149,.987,-2.565]);
    box(tails,`tailDivider${side}`,'arch',[.011,.191,.016],[tailX-side*.079,1.047,-2.576]);
  }

  // 02d / material: use flat-shaded PBR paint, lavender-grey side panels, dark trim, and separate emissive lens materials.
  const std = (color,roughness=.68,metalness=.0,extra={}) => new T.MeshStandardMaterial({ color,roughness,metalness,flatShading:true,...extra });
  const m = {
    roofWhite:std(0xf5f3ef,.54,.035), bodyWhite:std(0xebebef,.57,.03), bodyGrey:std(0xe1e0e7,.60,.025),
    beltPaint:std(0xebebef,.59,.03), midShoulder:std(0xebebef,.59,.03), sillEdgePaint:std(0xc72d39,.64,.035), midSill:std(0xc72d39,.64,.035), sill:std(0xe6e6ed,.77,.02),
    deep:std(0x111216,.92), arch:std(0x1a1b1e,.79,.05), bumper:std(0x17191c,.70,.075), wingTop:std(0x1b1c1f,.78,.05),
    grilleBlack:std(0x16191e,.66,.10), splitter:std(0x25272b,.80,.09),
    evoBonnet:std(0xf0eeea,.50,.031), evoFender:std(0xe6e5e0,.55,.036), evoApronPaint:std(0xd0d0cc,.61,.041), evoBumperPaint:std(0xa3a5a1,.61,.06),
    evoMaskPaint:std(0x111313,.66,.075), evoMaskEdge:std(0x282a29,.66,.06), evoGrilleMesh:std(0xffffff,.78,.03), evoSocketShade:std(0x30312f,.76,.07),
    evoDuctShade:std(0x141616,.91,.024), evoRadFin:std(0x242524,.87,.21), evoTow:std(0xab5129,.66,.15), evoSplitter:std(0x52524e,.83,.025), evoSplitterBevel:std(0x3f403c,.71,.06),
    evoAlloy:std(0xc8c9c6,.33,.32), evoRimShadow:std(0x747775,.44,.27),
    s1Body:std(0xefeee9,.56,.035), s1Gold:std(0xffab0d,.56,.045,{emissiveIntensity:.115}),
    s1Lower:std(0xffa10b,.57,.043,{emissiveIntensity:.15}), s1UnderGold:std(0xcd7815,.66,.036),
    s1Flap:std(0xf7a30f,.86,.008,{emissive:0x8e4800,emissiveIntensity:.13}), s1Nameplate:std(0x252526,.70,.005),
    s1Metal:std(0xb9bdbb,.69,.23), s1Perforation:std(0xf4f5f0,.71,.11), s1PanelSeam:std(0x6b6964,.73,.04),
    s1WingUnderside:std(0xcdcdc8,.63,.035,{emissive:0xd5d6d2,emissiveIntensity:.305}), s1WingCap:std(0x363637,.64,.11),
    s1VentWall:std(0x151719,.86,.07), s1Bezel:std(0x2a2b2a,.69,.105), s1Slat:std(0x2d3031,.76,.12), s1Wire:std(0x27292a,.81,.11),
    s1Guard:std(0xffffff,.91,.035), s1GuardEdge:std(0x212326,.84,.023), s1Bolt:std(0x6c6864,.65,.32),
    s1TailLens:std(0xffffff,.34,.064,{emissive:0xb34222,emissiveIntensity:.07}), s1ExhaustMetal:std(0x827470,.57,.43),
    wingWhite:std(0xf0eee8,.56,.045), wingShade:std(0xd2d2da,.62,.04,{emissive:0xa5acbb,emissiveIntensity:.18}), wingTip:std(0xc88997,.54,.045), wingBolt:std(0x707580,.54,.48),
    rubber:std(0x1d1d20,.93), windowFrame:std(0x17181b,.72),
    frontGlass:std(0xb0d7db,.21,.02,{transparent:true,opacity:.12,depthWrite:false,side:T.DoubleSide,forceSinglePass:true}),
    sideGlass:std(0x8bacb9,.25,.02,{transparent:true,opacity:.20,depthWrite:false,side:T.DoubleSide,forceSinglePass:true}),
    rearGlass:std(0x9fbdc4,.26,.02,{transparent:true,opacity:.19,depthWrite:false,side:T.DoubleSide,forceSinglePass:true}),
    mirror:std(0x898f99,.32,.26),
    dash:std(0x282b30,.87,.02), dashFace:std(0x22262a,.85,.015), dashEdge:std(0x41464c,.76,.04), liner:std(0x171a1e,.92,.01),
    cage:std(0xd1d7d0,.59,.06), cageHardware:std(0x9da7a6,.51,.21), wheelRubber:std(0x15181b,.83,.02),
    wheelMetal:std(0x9ca6a9,.54,.27), shiftMetal:std(0x434750,.51,.18), warmKnob:std(0xfb9029,.57,.03),
    dialWhite:std(0xd7ded5,.76,.02), tellDim:std(0x434b4a,.66,.02), tellGreen:std(0x337a56,.67,.02,{emissive:0x69d49a,emissiveIntensity:.34}),
    seatCloth:std(0x24272c,.92,.01), seatBolster:std(0x3d3e43,.91,.00), harness:std(0x61342d,.91,.01),
    driverWhite:std(0xf2f1ec,.82,.0,{emissive:0xc8d2dc,emissiveIntensity:.073}),
    driverPalm:std(0xf2f1ec,.82,.0,{emissive:0xc8d2dc,emissiveIntensity:.073,vertexColors:true}),
    driverSleeve:std(0xe4e6e5,.87,.0,{emissive:0xc0c9ce,emissiveIntensity:.078}),
    alloy:std(0xf0eff4,.43,.15), alloyShade:std(0xb9bbc8,.47,.18), steel:std(0x545965,.64,.22), bareAlloy:std(0x9799a2,.49,.29),
    goldHardware:std(0x9c782e,.55,.15), redHardware:std(0xb8442c,.65,.10),
    headlamp:std(0xe9e9e3,.30,.02,{ emissive:0xffedca,emissiveIntensity:.0 }),
    evoLamp:std(0xe6e9e2,.295,.135,{ emissive:0xfff1d5,emissiveIntensity:.0 }),
    auxLamp:std(0xffe6a0,.32,.02,{ emissive:0xffdd75,emissiveIntensity:.0 }),
    indicator:std(0xe3a258,.42,.02,{ emissive:0xb86123,emissiveIntensity:.12 }),
    evoIndicator:std(0xe39436,.43,.025,{ emissive:0x9e4b16,emissiveIntensity:.12 }),
    tailRed:std(0xb82226,.38,.03,{ emissive:0xe51f21,emissiveIntensity:.27 }), tailReverse:std(0xc08683,.42,.02),
    paintRed:std(0xd22636,.61,.025), paintInk:std(0x292a30,.64,.02), paintDim:std(0x4d5058,.65,.025), paintPin:std(0xb7904d,.61,.02),
    evoHeritageInk:std(0x222422,.66,.018), evoHeritageRed:std(0xb91e27,.62,.025), evoHeritagePin:std(0xb79748,.64,.025),
  };
  const palettes={
    black:{ ink:0x282931, dim:0x4d4f55, red:0xcc2633, pin:0xb5934c },
    blue:{ ink:0x1c56b2, dim:0x4574bc, red:0xd1243e, pin:0x90b7dc },
    green:{ ink:0x176d46, dim:0x4c9670, red:0xd32937, pin:0xb2c278 },
  };
  function mount(d) {
    const base = typeof d.mat === 'string' ? m[d.mat] : d.mat;
    if (!base) throw new Error(`Missing material ${d.mat} for ${d.name}`);
    const mat = d.settings?.double ? base.clone() : base;
    if (d.settings?.double) mat.side = T.DoubleSide;
    const node = new T.Mesh(d.geometry,mat); node.name = d.name;
    if (d.at) node.position.set(...d.at);
    if (d.rotation) node.rotation.set(...d.rotation);
    node.castShadow = d.settings?.shadow !== false;
    node.receiveShadow = d.settings?.shadow !== false;
    if (d.settings?.decal) node.renderOrder = 2;
    d.parent.add(node);
    return node;
  }
  pieces.forEach(mount);
  function finishPieces(draw) {
    const start = pieces.length; draw(); pieces.slice(start).forEach(mount);
  }

  // 02e / surface: draw the decals and glass tint in canvas; conform the numbers, stripes and mesh pattern to their panels.
  function texture(w,h,draw) {
    const canvas = options.canvasFactory?.(w,h) || document.createElement('canvas');
    canvas.width=w; canvas.height=h;
    const ctx = canvas.getContext('2d'); draw(ctx,w,h);
    const tex = new T.CanvasTexture(canvas); tex.colorSpace=T.SRGBColorSpace; tex.anisotropy=8; return tex;
  }
  const glassShade=texture(64,128,(c,w,h)=>{
    const g=c.createLinearGradient(0,0,w*.2,h);
    g.addColorStop(0,'rgba(230,244,243,0.92)'); g.addColorStop(.19,'rgba(187,219,223,0.53)');
    g.addColorStop(.64,'rgba(163,193,202,0.31)'); g.addColorStop(1,'rgba(211,229,230,0.66)');
    c.fillStyle=g; c.fillRect(0,0,w,h);
  });
  m.frontGlass.map=m.sideGlass.map=m.rearGlass.map=glassShade;
  const rimSweep=texture(64,64,(c,w,h)=>{
    const r=w/2, fade=c.createRadialGradient(r,r,0,r,r,r);
    fade.addColorStop(0,'#bfc2ba00');fade.addColorStop(.27,'#bfc2ba00');fade.addColorStop(.48,'#bfc2ba91');
    fade.addColorStop(.78,'#a7aeac75');fade.addColorStop(.95,'#c3c6c25c');fade.addColorStop(1,'#bfc2ba00');
    c.fillStyle=fade;c.fillRect(0,0,w,h);
  });
  const rimSweepFace=new T.CircleGeometry(.326,28);
  for(const wheel of Object.values(wheels)) {
    const haze=new T.Mesh(rimSweepFace,new T.MeshBasicMaterial({map:rimSweep,side:T.DoubleSide,transparent:true,depthWrite:false,opacity:0}));
    haze.rotation.y=Math.PI/2;haze.position.x=wheel.side*.214;haze.visible=false;
    haze.name='rollingSpokeSweep';wheel.pivot.add(haze);wheel.haze=haze;
  }
  const instrumentsTexture=texture(512,176,()=>{});
  const meter=instrumentsTexture.image.getContext('2d');
  const digital=new T.MeshBasicMaterial({map:instrumentsTexture,toneMapped:false,alphaTest:.16});
  const gearTexture=texture(96,80,()=>{}), controlTexture=texture(160,52,()=>{});
  const gearInk=gearTexture.image.getContext('2d'), controlInk=controlTexture.image.getContext('2d');
  const mirrorFallback=texture(256,64,(c,w,h)=>{
    const g=c.createLinearGradient(0,0,0,h);
    g.addColorStop(0,'#829cae');g.addColorStop(.48,'#9baeb2');g.addColorStop(.52,'#737f74');g.addColorStop(1,'#57646b');
    c.fillStyle=g;c.fillRect(0,0,w,h);
  });
  const mirrorScreen=new T.MeshBasicMaterial({map:mirrorFallback,toneMapped:false,color:0xd5e2e7});
  const lampScreen=new T.MeshBasicMaterial({color:0xeac382,toneMapped:false});
  function rearFacingScreen(parent,name,w,h,material) {
    const mesh=new T.Mesh(new T.PlaneGeometry(w,h),material); mesh.name=name; mesh.rotation.y=Math.PI; parent.add(mesh); return mesh;
  }
  rearFacingScreen(dashDisplay,'instrumentScreen',.601,.189,digital);
  rearFacingScreen(gearDisplay,'gearReadoutGlass',.077,.066,new T.MeshBasicMaterial({map:gearTexture,toneMapped:false}));
  rearFacingScreen(controlDisplay,'controlReadoutGlass',.144,.048,new T.MeshBasicMaterial({map:controlTexture,toneMapped:false}));
  rearFacingScreen(cabinMirrorFace,'interiorReflectiveGlass',.496,.113,mirrorScreen);
  const hornMark=texture(96,96,(c,w,h)=>{
    c.fillStyle='#181b1f';c.fillRect(0,0,w,h);
    c.fillStyle='#868c8d';
    for(const [x,y] of [[24,25],[53,25],[39,40],[20,55],[49,55]]) {
      c.beginPath();c.moveTo(x+6,y);c.lineTo(x+23,y);c.lineTo(x+17,y+15);c.lineTo(x,y+15);c.closePath();c.fill();
    }
  });
  const markOnHorn=rearFacingScreen(wheelSpin,'hornCheckerPlate',.041,.041,new T.MeshBasicMaterial({map:hornMark}));
  markOnHorn.position.set(0,.003,-.062);
  const shiftIndicator=rearFacingScreen(warningPodForLight(),'shiftIndicatorLens',.015,.007,lampScreen);
  function warningPodForLight() {
    const indicator=group('shiftIndicator',cockpit); indicator.position.set(-.146,1.313,.245); return indicator;
  }
  const digits=['abcedf','bc','abdeg','abcdg','bcfg','acdfg','acdefg','abc','abcdefg','abcdfg'];
  const segments={a:[6,0,32,6],b:[38,6,6,27],c:[38,42,6,27],d:[6,69,32,6],e:[0,42,6,27],f:[0,6,6,27],g:[6,34,32,6]};
  function segmented(ctx,char,x,y,scale,ink) {
    ctx.save(); ctx.translate(x,y); ctx.scale(scale,scale); ctx.transform(1,0,-.06,1,0,0);
    for(const [segment,rect] of Object.entries(segments)) {
      ctx.fillStyle=(digits[char] || 'g').includes(segment)?ink:'#142a20';
      ctx.fillRect(...rect);
    }
    ctx.restore();
  }
  let dashKey='';
  function drawMeters(speed,gear,rev,action='wheel',shifting=false,displayKmh) {
    const amount=Math.round(clamp(rev,0,1)*24),kmh=Number.isFinite(displayKmh)?Math.round(Math.abs(displayKmh)):Math.round(Math.abs(speed)*3.6);
    const key=`${kmh}:${gear}:${amount}:${action}:${shifting}`;
    if(key===dashKey) return;
    dashKey=key;
    meter.clearRect(0,0,512,176);
    const tint=meter.createLinearGradient(0,0,0,176);
    tint.addColorStop(0,'#0d1c14');tint.addColorStop(1,'#06110d');
    meter.beginPath();meter.moveTo(11,166);meter.lineTo(11,95);meter.quadraticCurveTo(38,12,103,8);
    meter.lineTo(427,8);meter.quadraticCurveTo(479,13,500,84);meter.lineTo(500,166);meter.closePath();
    meter.fillStyle=tint;meter.fill();meter.strokeStyle='#263a30';meter.lineWidth=3;meter.stroke();
    for(let i=0;i<24;i++) {
      const rise=Math.sin((i+.5)/24*Math.PI)*10;
      meter.fillStyle=i<amount?(i>18?'#ffa454':'#72e4a7'):(i>18?'#39251e':'#1b3c2b');
      meter.fillRect(38+i*18.7,37-rise,12,10+(i>17?3:0));
    }
    const tachX=110,tachY=113;
    for(let i=0;i<30;i++) {
      const a=Math.PI*(.78+1.44*i/29), r=49;
      meter.save();meter.translate(tachX+Math.cos(a)*r,tachY+Math.sin(a)*r);meter.rotate(a);
      meter.fillStyle=i<rev*30?'#87edb5':'#17432e';meter.fillRect(-6,-2.5,12,5);meter.restore();
    }
    meter.fillStyle='#a4d9b8'; meter.font='700 27px monospace';meter.textAlign='center';meter.fillText((1.1+clamp(rev,0,1)*7.9).toFixed(1),tachX,122);
    meter.fillStyle='#7fad91';meter.font='700 9px monospace';meter.fillText('RPM x 1000',tachX,143);
    const n=String(kmh).padStart(3,' ');
    for(let i=0;i<3;i++) segmented(meter,n[i]===' '?'-':n[i],218+i*67,61,1.05,n[i]===' '?'#142a20':'#beffd5');
    meter.font='700 13px monospace';meter.fillStyle='#a4d9b8';meter.fillText('KM/J',377,155);meter.textAlign='left';
    gearInk.fillStyle='#06130d';gearInk.fillRect(0,0,96,80);
    if(gear==='R'||gear==='N') {gearInk.font='700 58px monospace';gearInk.fillStyle='#8cf8b7';gearInk.fillText(gear,30,63);}
    else segmented(gearInk,gear,32,12,.73,'#8cf8b7');
    controlInk.fillStyle='#08140e';controlInk.fillRect(0,0,160,52);
    controlInk.font='700 24px monospace';controlInk.textAlign='center';
    controlInk.fillStyle=action==='brake'?'#ffad61':shifting?'#ffd083':'#7de4ac';
    controlInk.fillText(action==='brake'?'BRAKE':shifting?'SHIFT':'AUTO',80,34);
    instrumentsTexture.needsUpdate=gearTexture.needsUpdate=controlTexture.needsUpdate=true;
    shiftIndicator.visible=amount>=19||shifting;
  }
  drawMeters(0,'1',.22);
  m.sill.map = texture(768,128,(c,w,h)=>{
    c.fillStyle='#f1f1ef'; c.fillRect(0,0,w,h);
    for (let y=4;y<h;y+=11) for (let x=(y%2)*5+3;x<w;x+=10) {
      c.fillStyle=(x+y)%3 ? '#a6a8b1' : '#c3c3ca'; c.fillRect(x,y,3.25,3.1);
    }
  });
  m.evoLamp.map=texture(192,100,(c,w,h)=>{
    c.fillStyle='#535953'; c.fillRect(0,0,w,h);
    for(const [x,y,a,b] of [[7,8,109,64],[123,9,59,63],[7,77,176,15]]) {
      const g=c.createLinearGradient(x,y,x+a*.27,y+b); g.addColorStop(0,'#77817c'); g.addColorStop(.19,'#d0d9d3');
      g.addColorStop(.43,'#a3aead'); g.addColorStop(.66,'#68716e'); g.addColorStop(1,'#a9aea0');
      c.fillStyle=g; c.fillRect(x,y,a,b);
      c.fillStyle='#f6f5df'; c.fillRect(x+a*.16,y+b*.29,a*.67,Math.max(1,b*.066));
      c.fillStyle='#747b79'; c.fillRect(x+a*.43,y+b*.64,a*.22,Math.max(1,b*.039));
    }
    c.globalAlpha=.28; c.fillStyle='#454d50';
    for(let x=6;x<w;x+=8) c.fillRect(x,3,1.6,h-6);
    for(let y=14;y<h;y+=16) c.fillRect(3,y,w-6,1.0);
  });
  m.evoLamp.emissiveMap=m.evoLamp.map;
  m.evoGrilleMesh.map=texture(512,64,(c,w,h)=>{
    c.fillStyle='#141716'; c.fillRect(0,0,w,h);
    for(let y=4;y<h;y+=7) {
      c.fillStyle=y%2?'#252826':'#202322'; c.fillRect(0,y,w,1.1);
      c.fillStyle='#0e100f'; for(let x=(y%2)*5;x<w;x+=8)c.fillRect(x,y+2,5,2);
    }
  });
  m.evoIndicator.map=texture(96,48,(c,w,h)=>{
    c.fillStyle='#ffbe70'; c.fillRect(0,0,w,h); c.fillStyle='#a95f1d'; c.fillRect(0,h*.69,w,h*.31);
    c.fillStyle='#d08a3d'; for(let x=3;x<w;x+=6) c.fillRect(x,0,.8,h);
  });
  m.s1Perforation.map=texture(768,128,(c,w,h)=>{
    const satin=c.createLinearGradient(0,0,0,h);
    satin.addColorStop(0,'#c9cbc7'); satin.addColorStop(.23,'#eeeae4'); satin.addColorStop(.57,'#d5d7d2'); satin.addColorStop(1,'#ced0cd');
    c.fillStyle=satin; c.fillRect(0,0,w,h);
    for(let y=5,row=0;y<h-3;y+=6,row++) for(let x=6+(row%2)*3;x<w-4;x+=7) {
      c.fillStyle='#292d2e'; c.beginPath(); c.ellipse(x,y,1.63,1.55,0,0,Math.PI*2); c.fill();
      c.fillStyle='#f5f2eb'; c.fillRect(x-1.7,y+1.65,2.7,.55);
    }
    for(const x of [27,w-27]) {c.fillStyle='#a2a3a0';c.fillRect(x,1,2,h-2);}
  });
  m.s1Guard.map=texture(64,256,(c,w,h)=>{
    const satin=c.createLinearGradient(0,0,w,0);
    satin.addColorStop(0,'#262628');satin.addColorStop(.19,'#202123');satin.addColorStop(.71,'#18191b');satin.addColorStop(1,'#292a2c');
    c.fillStyle=satin;c.fillRect(0,0,w,h);
    for(let y=5;y<h-5;y+=7) for(let x=5;x<w-4;x+=4) {
      c.fillStyle=(x+y)%4===0?'#2b2b2a':'#252525'; c.fillRect(x,y,1.2,2);
    }
  });
  m.s1TailLens.map=texture(128,256,(c,w,h)=>{
    const g=c.createLinearGradient(0,0,w,h*.18);
    g.addColorStop(0,'#15171a');g.addColorStop(.38,'#252429');g.addColorStop(.72,'#393534');g.addColorStop(1,'#252624');
    c.fillStyle=g;c.fillRect(0,0,w,h);
    const blocks=[[16,32,96,51,'#996037','#2e211a'],[12,92,104,43,'#654a3d','#2b2426'],
      [10,143,110,47,'#662a2b','#281e22'],[12,199,104,43,'#573332','#232024']];
    for(const [x,y,a,b,high,low] of blocks) {
      const g=c.createLinearGradient(x,y,x+a*.21,y+b);
      g.addColorStop(0,low);g.addColorStop(.47,high);g.addColorStop(.66,high);g.addColorStop(1,low);
      c.fillStyle=g;c.fillRect(x,y,a,b);
      for(let row=y+3;row<y+b-3;row+=5) {c.fillStyle='#221d20';c.globalAlpha=.43;c.fillRect(x,row,a,1);}
      c.globalAlpha=.22;c.fillStyle='#bba299';c.fillRect(x+3,y+5,a-6,1.9);c.globalAlpha=1;
    }
    const shine=c.createLinearGradient(0,0,w,0);
    shine.addColorStop(0,'#5d65683d');shine.addColorStop(.27,'#565d5810');shine.addColorStop(.72,'#33363500');shine.addColorStop(1,'#777b6f26');
    c.fillStyle=shine;c.fillRect(0,0,w,h);
  });
  m.s1TailLens.emissiveMap=m.s1TailLens.map;
  const decalMat = map => std(0xffffff,.85,0,{ map,alphaTest:.18,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1 });
  const number = decalMat(texture(512,512,(c,w,h)=>{
    c.fillStyle='#121215'; c.fillRect(0,0,w,h);
    c.translate(w*.5,h*.515); c.scale(.84,1.05);
    c.font='900 352px Arial, sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.lineJoin='round';
    c.strokeStyle='#b82127'; c.lineWidth=15; c.strokeText('12',1,12); c.fillStyle='#f9f8f7'; c.fillText('12',1,12);
  }));
  const sponsors = {};
  function sponsor(logo, dark=false) { return decalMat(texture(512,168,(c,w,h)=>{
    const gym=logo==='GYM', kcrn=logo==='KCRN';
    if (!gym) { c.fillStyle = kcrn ? '#f1f1ed' : '#371754'; c.fillRect(0,0,w,h); }
    if (gym) {
      c.save(); c.translate(68,84); c.rotate(-.18); c.fillStyle=dark?'#ad7225':'#fff9ed';
      for (const [x,y] of [[-29,-29],[0,-29],[-29,0],[29,0],[0,29],[29,29]]) {
        c.beginPath(); c.moveTo(x,y-17); c.lineTo(x+17,y); c.lineTo(x,y+17); c.lineTo(x-17,y); c.closePath(); c.fill();
      }
      c.restore();
    } else {
      c.fillStyle=kcrn?'#1a6d90':'#7695c0'; c.beginPath(); c.moveTo(66,18); c.lineTo(112,82); c.lineTo(66,150); c.lineTo(20,82); c.closePath(); c.fill();
      c.fillStyle=kcrn?'#56a360':'#8d50a6'; c.beginPath(); c.moveTo(66,18); c.lineTo(66,150); c.lineTo(20,82); c.fill();
    }
    c.save(); c.translate(gym?130:134,87); c.scale(gym?.99:.89,1);
    c.textBaseline='middle'; c.font=`${gym?'italic ':''}900 ${gym?156:121}px Arial, sans-serif`;
    c.fillStyle=kcrn?'#1b466c':gym?(dark?'#33343b':'#fff9ed'):'#f2e7fc'; c.fillText(logo,0,1,405); c.restore();
  })); }
  for (const logo of ['GYM','KCRN','MOT']) sponsors[logo]=sponsor(logo);
  sponsors.deckGYM=sponsor('GYM',true);

  const mark = (w,h,draw)=>decalMat(texture(w,h,draw));
  const heritageOval=mark(512,256,(c,w,h)=>{
    c.fillStyle='#cb2334'; c.beginPath(); c.ellipse(w*.5,h*.5,w*.489,h*.413,0,0,Math.PI*2); c.fill();
    c.strokeStyle='#fff3e8'; c.lineWidth=5; c.beginPath(); c.ellipse(w*.5,h*.5,w*.463,h*.362,0,0,Math.PI*2); c.stroke();
    c.font='italic 900 135px Arial, sans-serif'; c.textAlign='center'; c.textBaseline='middle';
    c.fillStyle='#fcfaf4'; c.fillText('Audi',w*.482,h*.521);
  });
  const audiSport=mark(640,156,(c,w,h)=>{
    c.fillStyle='#c81f32'; c.beginPath(); c.moveTo(3,128); c.lineTo(49,24); c.lineTo(95,24); c.lineTo(49,128); c.fill();
    c.fillStyle='#212329'; c.font='italic 800 109px Arial, sans-serif'; c.textBaseline='middle'; c.fillText('Audi Sport',108,h*.53,w-110);
  });
  const blaupunkt=mark(512,112,(c,w,h)=>{
    c.fillStyle='#2760a7'; c.beginPath(); c.arc(43,56,26,0,Math.PI*2); c.fill();
    c.fillStyle='#25252b'; c.font='800 72px Arial, sans-serif'; c.textBaseline='middle'; c.fillText('BLAUPUNKT',82,58,w-86);
  });
  const michelin=mark(640,128,(c,w,h)=>{
    c.fillStyle='#171918'; c.font='italic 900 111px Arial, sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.fillText('MICHELIN',w/2,h*.53,w*.96);
  });
  const tireMascot=mark(256,256,(c)=>{
    c.translate(125,125); c.rotate(.21); c.strokeStyle='#4d524e'; c.fillStyle='#efefdf'; c.lineWidth=3.4;
    function ring(x,y,rx,ry,r=0) { c.beginPath(); c.ellipse(x,y,rx,ry,r,0,Math.PI*2); c.fill(); c.stroke(); }
    for(const [x,y] of [[-15,67],[-23,57],[-23,46],[15,64],[24,56],[26,44]]) ring(x,y,11,8,-.29);
    for(const [x,y] of [[-34,-12],[-41,-22],[-44,-31],[35,-1],[44,-12],[48,-21]]) ring(x,y,10,7,.47);
    for(const [y,w] of [[39,19],[28,25],[16,31],[4,34],[-8,31],[-20,25]]) ring(0,y,w,10,.075);
    ring(0,-37,20,19,-.12); ring(-4,-41,17,13,-.14);
    c.fillStyle='#4d524e'; c.beginPath(); c.ellipse(-9,-43,2,3,0,0,Math.PI*2); c.ellipse(2,-43,2,3,0,0,Math.PI*2); c.fill();
    c.beginPath(); c.arc(-3,-38,7,.12,Math.PI-.15); c.stroke();
  });
  const quattro=mark(512,140,(c,w,h)=>{
    c.fillStyle='#28262a'; c.font='italic 900 121px Arial, sans-serif'; c.textAlign='center'; c.textBaseline='middle'; c.fillText('quattro',w/2,h*.46);
  });
  const worksPlate=mark(640,200,(c,w,h)=>{
    c.fillStyle='#efede6'; c.fillRect(0,0,w,h);
    c.strokeStyle='#282829'; c.lineWidth=11; c.strokeRect(8,8,w-16,h-16);
    c.fillStyle='#272728'; c.font='800 126px monospace'; c.textAlign='center'; c.textBaseline='middle'; c.fillText('IN-NL 24',w/2,h*.55,w*.90);
  });
  const worksCrest=mark(220,245,(c,w,h)=>{
    c.fillStyle='#ae2737'; c.beginPath(); c.moveTo(w*.50,h*.053); c.lineTo(w*.88,h*.816); c.quadraticCurveTo(w*.52,h*.992,w*.12,h*.816); c.closePath(); c.fill();
    c.strokeStyle='#e0b16e'; c.lineWidth=5; c.beginPath(); c.moveTo(w*.50,h*.169); c.lineTo(w*.79,h*.794); c.quadraticCurveTo(w*.50,h*.912,w*.22,h*.791); c.closePath(); c.stroke();
    c.fillStyle='#e5b473'; c.font='bold 65px Georgia, serif'; c.textAlign='center'; c.fillText('HB',w*.50,h*.74);
  });
  const s1Audi=mark(384,100,(c,w,h)=>{
    c.fillStyle='#f5f5f5';c.font='italic 900 88px Arial, sans-serif';c.textAlign='center';c.textBaseline='middle';
    c.save();c.translate(w/2,h*.535);c.scale(1.24,1);c.fillText('Audi',0,0);c.restore();
  });
  const s1Quattro=mark(512,120,(c,w,h)=>{
    c.fillStyle='#f5f5f5';c.font='italic 900 112px Arial, sans-serif';c.textAlign='center';c.textBaseline='middle';
    c.save();c.translate(w/2,h*.49);c.scale(1.25,.79);c.fillText('quattro',0,0,w*.76);c.restore();
  });
  const s1Plate=mark(640,152,(c,w,h)=>{
    c.fillStyle='#eeeee8';c.fillRect(0,0,w,h);c.strokeStyle='#272827';c.lineWidth=8;c.strokeRect(5,5,w-10,h-10);
    c.fillStyle='#245499';c.fillRect(8,8,57,h-16);c.fillStyle='#e1ca55';
    for(let i=0;i<10;i++) {const a=i*Math.PI/5;c.beginPath();c.arc(35+14*Math.cos(a),49+14*Math.sin(a),1.45,0,Math.PI*2);c.fill();}
    c.fillStyle='#eeeef1';c.font='bold 30px Arial, sans-serif';c.textAlign='center';c.fillText('PL',36,111);
    c.fillStyle='#242525';c.textBaseline='middle';c.font='650 119px Arial, sans-serif';c.fillText('RZE 82984',353,h*.535,547);
  });
  const sanremo=mark(680,267,(c,w,h)=>{
    function shield(a,b){
      c.beginPath();c.moveTo(12+a,83+b);c.lineTo(193,77+b);c.bezierCurveTo(235,47,271,15+b,340,15+b);
      c.bezierCurveTo(413,15+b,444,48,488,77+b);c.lineTo(668-a,83+b);c.lineTo(668-a,h-14-b);
      c.lineTo(12+a,h-14-b);c.closePath();
    }
    shield(0,0);c.fillStyle='#c82936';c.fill();shield(12,12);c.strokeStyle='#fff5e4';c.lineWidth=6.0;c.stroke();
    c.fillStyle='#fff2db';c.beginPath();c.ellipse(340,83,112,42,0,0,Math.PI*2);c.fill();
    c.textAlign='center';c.textBaseline='middle';c.fillStyle='#242421';c.font='bold 73px Arial, sans-serif';c.fillText('5',340,88);
    c.font='italic 800 61px Arial, sans-serif';c.fillStyle='#fff5e5';c.fillText('RALLYE SANREMO',340,162,601);
    c.font='600 23px Arial, sans-serif';c.fillText('1985',88,113);c.fillText('1985',590,113);c.fillText('CAMPIONATO MONDIALE RALLIES',340,213);
  });
  const s1Sponsor=mark(380,392,(c,w,h)=>{
    c.textBaseline='middle';c.textAlign='center';
    c.fillStyle='#1a4c99';c.fillRect(6,6,w-12,114);c.fillStyle='#f7f6f1';c.font='900 104px Arial, sans-serif';c.fillText('SKF',w/2,68,333);
    c.fillStyle='#262726';c.font='800 70px Arial, sans-serif';c.fillText('speedline',w/2,176,352);
    c.fillStyle='#282829';c.fillRect(6,224,w-12,132);c.fillStyle='#f3f1e8';c.font='800 96px Arial, sans-serif';c.fillText('BOGE',w/2,292,340);
  });
  s1Audi.color=m.s1Nameplate.color; s1Quattro.color=m.s1Nameplate.color;
  const flags={ shadow:false,decal:true };

  // Interpolate each mark's UVs where it crosses a panel seam so the ink stays on the facets.
  function projectedMark(footprint,levels,axis,mapPoint,across,holes) {
    const input=footprint.map(([a,b],i)=>[a,b,...squareUV[i]]);
    const clip=(polygon,z,s,k)=>polygon.flatMap((p,i)=>{
      const q=polygon[(i+1)%polygon.length], pInside=(p[k]-z)*s>=-1e-8, qInside=(q[k]-z)*s>=-1e-8;
      const next=pInside?[p]:[];
      if(pInside!==qInside) next.push(blend(p,q,clamp((z-p[k])/(q[k]-p[k]),0,1)));
      return next;
    });
    const stripes=(points,steps,k)=>steps.slice(1).map((z,i)=>clip(clip(points,steps[i],1,k),z,-1,k)).filter(p=>p.length>=3);
    const patches=stripes(input,levels,axis).flatMap(p=>across?stripes(p,across,1-axis):[p])
      .flatMap(p=>holes?removeCutouts(p,holes):[p]);
    return patches.flatMap(vertices=>{
      return vertices.length<3?[]:[{p:vertices.map(([a,b])=>mapPoint(a,b)),uv:vertices.map(p=>p.slice(2))}];
    });
  }
  function sideMark(parent,name,mat,side,points,offset=.005,profile=sections) {
    return panel(parent,name,projectedMark(points,profile.map(p=>p[0]),0,(z,y)=>skin(side,z,y,offset,profile)),mat,[side,0,0],flags);
  }
  function sideDecal(parent,name,mat,side,z,y,w,h,offset=.005,profile=sections) {
    const a=z+side*w*.5,b=z-side*w*.5;
    return sideMark(parent,name,mat,side,[[a,y-h/2],[b,y-h/2],[b,y+h/2],[a,y+h/2]],offset,profile);
  }
  function hoodMark(parent,id,name,mat,points,dy=.004) {
    const evo=id==='evo';
    const patches=projectedMark(points,hoodGrid(id),1,(x,z)=>hoodPoint(x,z,id,dy),evo?evoHoodX:undefined,evo?louvres:undefined);
    return panel(parent,name,patches,mat,[0,1,0],flags);
  }
  function hoodDecal(parent,id,name,mat,x,z,w,depth) {
    return hoodMark(parent,id,name,mat,[[x-w/2,z+depth/2],[x+w/2,z+depth/2],[x+w/2,z-depth/2],[x-w/2,z-depth/2]],.0085);
  }
  function evoFenderDecal(name,mat,side,z,w,lo,hi,d=.004) {
    const a=z+side*w/2,b=z-side*w/2;
    const onFender=(u,v)=>{
      const [, ,top,,shoulder]=interpolate(evoSections,u);
      return skin(side,u,v<0?mix(shoulder,bottomAt(u,evoSections),-v):mix(shoulder,top,v),d,evoSections);
    };
    const cuts=ordered([...evoSections.map(row=>row[0]),...evoArch.map(([dz])=>axles.F+dz)]);
    const faces=projectedMark([[a,lo],[b,lo],[b,hi],[a,hi]],cuts,0,onFender,[-1,0,.49,1]);
    return panel(noses.evo.heritage,name,faces,mat,[side,0,0],flags);
  }
  finishPieces(()=>{
    for (const side of [1,-1]) {
      const point = (z,y,d=.012) => skin(side,z,y,d);
      const seam = (z,y0,y1) => [point(z-.008,y0),point(z+.008,y0),point(z+.008,y1),point(z-.008,y1)];
      panel(body,`doorShutline${side}`,[seam(.934,.423,1.153),seam(-.626,.419,1.154)],'alloyShade',[side,0,0],{shadow:false});
      panel(body,`handle${side}`,[[point(-.321,1.075,.020),point(-.583,1.075,.020),point(-.577,1.130,.020),point(-.314,1.131,.020)]],'deep',[side,0,0]);
      const port = [point(-.655,.422,.019),point(-.857,.335,.022),point(-.864,1.118,.021),point(-.655,1.154,.019)];
      panel(body,`intakeFlange${side}`,[port],'bodyWhite',[side,0,0]);
      panel(body,`sideIntake${side}`,[inset(port,.104,.893,.042,.975,[side*.003,0,0])],'deep',[side,0,0]);
      sideMark(vinyl.heritage,`heritageSideSkirt${side}`,'paintInk',side,[[1.04,.382],[-.649,.382],[-.649,.520],[.920,.506]],.010);
      sideMark(vinyl.heritage,`heritageSideRed${side}`,'paintRed',side,[[.954,.502],[-.649,.512],[-.649,.570],[.980,.552]],.013);
      sideDecal(vinyl.heritage,`heritageAudiSport${side}`,audiSport,side,.300,.652,.780,.168,.012);
      sideDecal(vinyl.heritage,`heritageBlaupunkt${side}`,blaupunkt,side,-.318,.993,.460,.102,.015);
      sideDecal(standardRear.heritage,`heritageQuarterQuattro${side}`,quattro,side,-2.089,1.225,.460,.132,.014);

      sideMark(vinyl.rally,`rallySweep${side}`,'paintInk',side,[[-.655,.408],[.032,.408],[-.415,1.154],[-.655,1.154]],.008);
      sideMark(vinyl.rally,`rallyAccentSweep${side}`,'paintRed',side,[[.037,.408],[.264,.408],[-.191,1.154],[-.416,1.154]],.009);
      sideMark(vinyl.rally,`rallyHairline${side}`,'paintDim',side,[[.278,.408],[.327,.408],[-.119,1.154],[-.166,1.154]],.010);
      sideDecal(vinyl.rally,`doorNumber${side}`,number,side,.554,.848,.565,.550,.011);
      sideDecal(standardRear.rally,`sideGYM${side}`,sponsors.GYM,side,-1.975,1.235,.692,.161,.018);
      sideDecal(standardRear.rally,`sideKCRN${side}`,sponsors.KCRN,side,-2.223,.926,.373,.128);
      sideDecal(standardRear.rally,`sideMOT${side}`,sponsors.MOT,side,-2.223,.744,.373,.128);
      sideDecal(s1Rear.heritage,`s1RearQuarterSponsors${side}`,s1Sponsor,side,-2.236,.922,.366,.345,.006,s1Sections);
      sideDecal(s1Rear.heritage,`s1RearQuarterMichelin${side}`,michelin,side,-1.556,1.080,.330,.065,.008,s1Sections);
      sideDecal(s1Rear.heritage,`s1RearQuarterQuattro${side}`,s1Quattro,side,-1.439,1.240,.565,.104,.008,s1Sections);
      sideDecal(s1Rear.rally,`s1SideGYM${side}`,sponsors.GYM,side,-1.492,1.254,.673,.139,.009,s1Sections);
      sideDecal(s1Rear.rally,`s1SideKCRN${side}`,sponsors.KCRN,side,-2.236,.970,.343,.111,.008,s1Sections);
      sideDecal(s1Rear.rally,`s1SideMOT${side}`,sponsors.MOT,side,-2.236,.794,.343,.111,.008,s1Sections);
      for(const [i,y] of [.441,.463].entries()) {
        sideMark(s1Rear.shell,`s1LowerQuarterPin${side}-${i}`,'s1Gold',side,[[s1Tail,y],[-2.077,y],[-2.077,y+.008],[s1Tail,y+.008]],.0035,s1Sections);
      }

      evoFenderDecal(`evoBlaupunktShoulder${side}`,blaupunkt,side,1.433,.405,.38,.97,.005);
      evoFenderDecal(`evoFenderMichelin${side}`,michelin,side,1.294,.250,-.14,.24,.005);
      evoFenderDecal(`evoTireMascot${side}`,tireMascot,side,2.384,.312,-.36,.61,.005);
      sideDecal(noses.evo.heritage,`evoFenderSport${side}`,audiSport,side,2.426,.428,.366,.098,.008,evoSections);
      const corner=cornerLips[side];
      panel(noses.evo.heritage,`evoCornerRed${side}`,bridge(corner(.29,.0025),corner(.92,.0025)),'evoHeritageRed',[side,0,.12],flags);
      panel(noses.evo.heritage,`evoCornerOchre${side}`,bridge(corner(.10,.0027),corner(.29,.0027)),'evoHeritagePin',[side,0,.12],flags);
    }

    for (const [id,kit] of Object.entries(noses)) {
      const z0=.952,z1=profiles[id].at(-1)[0], evo=id==='evo';
      const stripes=evo ? [[-.167,-.135,'evoHeritagePin'],[-.135,-.057,'evoHeritageRed'],[-.057,.151,'evoHeritageInk']]
        : [[-.207,-.174,'paintPin'],[-.174,-.077,'paintRed'],[-.077,.165,'paintInk']];
      for(const [a,b,mat] of stripes) {
        const rear=evo?-.064:-.105, front=evo?.026:.070;
        hoodMark(kit.heritage,id,`heritageBonnetStripe-${id}-${mat}`,mat,[[a+rear,z0],[b+rear,z0],[b+front,z1],[a+front,z1]],.0045);
        if(evo) {
          const p=(x,t)=>chinPoint(x+mix(front,.042,t),t,.003);
          panel(kit.heritage,`heritageApronStripe-${mat}`,chinRings.slice(1).map((t,i)=>[p(a,t),p(b,t),p(b,chinRings[i]),p(a,chinRings[i])]),mat,[0,1,1],flags);
          const low=(x,v)=>evoFascia(x+front,v,.003);
          panel(kit.heritage,`heritageBumperStripe-${mat}`,[[low(a,0),low(b,0),low(b,.175),low(a,.175)],
            [low(a,.783),low(b,.783),low(b,1),low(a,1)]],mat,[0,0,1],flags);
          const t=x=>evoMask(x+front,1,.003);
          panel(kit.heritage,`heritageHeaderStripe-${mat}`,[[t(a),t(b),browPoint((b+front)*frontW/bonnetLipX,.004),browPoint((a+front)*frontW/bonnetLipX,.004)]],mat,[0,1,1],flags);
        }
      }
      hoodDecal(kit.heritage,id,`heritageHoodOval-${id}`,heritageOval,evo?-.055:-.035,evo?1.227:1.256,evo?.549:.510,evo?.253:.282);
      if(!evo) hoodDecal(kit.heritage,id,`heritageHoodBlaupunkt-${id}`,blaupunkt,-.600,1.385,.388,.102);

      const stripeZ=1.510;
      for (const side of [1,-1]) for (const [i,mat] of ['paintInk','paintRed','paintDim'].entries()) {
        const z=stripeZ+i*.103;
        const p=(x,depth)=>[side*x,z+depth+x*.20];
        hoodMark(kit.rally,id,`rallyHoodStripe${side}-${i}`,mat,[p(0,0),p(.958,0),p(.958,.078),p(0,.078)]);
      }
      hoodDecal(kit.rally,id,`hoodNumber-${id}`,number,0,1.693,.672,.442);
    }
    for(const x of [-.556,.563]) {
      const faces=projectedMark([[x-.302,.06],[x+.302,.06],[x+.302,.729],[x-.302,.729]],frontCuts,0,(a,t)=>splitterPoint(a,t,.0026));
      panel(noses.evo.heritage,`michelinSplitter-${x}`,faces,michelin,[0,0,1],flags);
    }
    const rearDecal=(parent,name,mat,x,y,w,h)=>panel(parent,name,[[[x+w/2,y-h/2,-2.546],[x-w/2,y-h/2,-2.546],[x-w/2,y+h/2,-2.546],[x+w/2,y+h/2,-2.546]]],mat,[0,0,-1],flags);
    rearDecal(standardRear.heritage,'heritageRearQuattro',quattro,0,1.166,.510,.130);
    rearDecal(standardRear.rally,'rearGYM',sponsors.GYM,0,1.172,.515,.135);
    rearDecal(standardRear.rally,'rearKCRN',sponsors.KCRN,.849,.841,.344,.113);
    rearDecal(standardRear.rally,'rearMOT',sponsors.MOT,-.849,.841,.344,.113);
    const onDeck=(x,z)=>[x,deckY(z)+.004,z];
    panel(standardRear.rally,'deckGYM',[[onDeck(.345,-2.190),onDeck(-.345,-2.190),onDeck(-.345,-2.004),onDeck(.345,-2.004)]],sponsors.deckGYM,[0,1,0],flags);

    const aft=[worksFace[1],worksFace[0],worksFace[3],worksFace[2]], off=[0,.003,-.007];
    panel(worksStandard.mounts,'worksRegistration',[inset(aft,.151,.421,.178,.797,off)],worksPlate,[0,1,-1],flags);
    panel(worksStandard.mounts,'worksRearCrest',[inset(aft,.492,.588,.107,.829,off)],worksCrest,[0,1,-1],flags);
    panel(worksStandard.mounts,'worksRightCrest',[inset(aft,.715,.812,.128,.830,off)],worksCrest,[0,1,-1],flags);

    const hatch=[s1PlateFace[1],s1PlateFace[0],s1PlateFace[3],s1PlateFace[2]], hatchOffset=[0,.002,-.006];
    panel(s1Rear.shell,'s1PeriodRegistration',[inset(hatch,.047,.459,.221,.759,hatchOffset)],s1Plate,[0,.4,-1],flags);
    panel(s1Rear.shell,'s1CenterCrest',[inset(hatch,.473,.573,.160,.799,hatchOffset)],worksCrest,[0,.4,-1],flags);
    panel(s1Rear.heritage,'s1SanremoBadge',[inset(hatch,.594,.942,.092,.892,hatchOffset)],sanremo,[0,.4,-1],flags);
    panel(s1Rear.rally,'s1HatchRallyBadge',[inset(hatch,.632,.913,.304,.727,hatchOffset)],sponsors.deckGYM,[0,.4,-1],flags);
    function fasciaDecal(name,mat,x,v,w,h) {
      const a=x+w/2,b=x-w/2,p=[[a,v-h/2],[b,v-h/2],[b,v+h/2],[a,v+h/2]];
      panel(s1Rear.shell,name,projectedMark(p,s1Cuts,0,(u,y)=>s1Fascia(u,y,.0045)),mat,[0,0,-1],flags);
    }
    fasciaDecal('s1AudiRearWordmark',s1Audi,.769,.871,.286,.166);
    fasciaDecal('s1QuattroRearWordmark',s1Quattro,-.641,.870,.530,.159);
    for(const side of [1,-1]) {
      const spans=(a,b)=>[side*a,side*b].sort((x,y)=>x-y);
      for(const [i,v] of [.066,.109,.148].entries()) {
        panel(s1Rear.bumper,`s1ApronPin${side}-${i}`,rearBand((x,v)=>bumperFace(x,v,.0025),v,v+.022,[],spans(.848,1.168)),'s1Gold',[0,0,-1],flags);
      }
      for(const [i,v] of [.566,.594].entries()) {
        panel(s1Rear.bumper,`s1RearBeltPin${side}-${i}`,rearBand((x,v)=>s1Fascia(x,v,.0025),v,v+.013,topHoles,spans(.877,1.195)),'s1Lower',[0,0,-1],flags);
      }
      for(const v of [.213,.720]) cylinder(s1Rear.bumper,`s1LowerMeshBolt${side}-${v}`,'s1Bolt',.014,.009,8,bumperFace(side*.787,v,-.017),'z');
    }
  });

  // 02f / lighting: use warm emissive lens faces, bounded point fills and procedural additive halos on each headlight socket.
  const glow = texture(128,128,(c,w,h)=>{
    const r=w/2, g=c.createRadialGradient(r,r,0,r,r,r);
    g.addColorStop(0,'rgba(255,247,210,0.92)'); g.addColorStop(.20,'rgba(255,224,146,0.52)');
    g.addColorStop(.48,'rgba(255,195,80,0.15)'); g.addColorStop(1,'rgba(255,182,50,0)');
    c.fillStyle=g; c.fillRect(0,0,w,h);
  });
  const halos=[], headlightSockets={ evo:[], classic:[] };
  for (const pod of pods) {
    const marker=socket(`socketHeadlight${pod.name}`,noses[pod.id].lamps,pod.x,pod.y,pod.z);
    headlightSockets[pod.id].push(marker);
    const sprite = new T.Sprite(new T.SpriteMaterial({ map:glow,blending:T.AdditiveBlending,depthWrite:false,toneMapped:false,opacity:0 }));
    sprite.name=`halo${pod.name}`; sprite.position.z=.013;
    sprite.scale.set(pod.size*(pod.rect?1.37:1),pod.size*(pod.rect?.72:1),1);
    marker.add(sprite); halos.push([sprite,pod.id==='evo'?.53:.73]);
  }
  const fills=[];
  for (const id of ['evo','classic']) for (const side of [1,-1]) {
    const light=new T.PointLight(0xffe1a0,0,1.6,2);
    light.name=`${id}HeadlightFill${side}`; light.position.set(side*.475,.73,id==='evo'?2.980:2.963);
    noses[id].lamps.add(light); fills.push([light,id==='evo'?.34:.53]);
  }

  // 02g / interaction: spin about local X, steer about Y, and damp pitch/roll on the sprung body without lifting the tyres.
  let lampsOn=options.headlights !== false, power=lampsOn?1:0, headFacing=1, previousSpeed=0, pitch=0, roll=0;
  let cockpitView=false, wheelAngle=0, tailBrake=0, tremor=0;
  let handTarget='wheel', reach=0, leverLoad=0;
  let activeGear=null, shiftAge=Infinity, shiftDirection=1;
  const actionPose={ mode:'wheel', reach:0, contact:false };
  const pivotPoint=new T.Vector3(0,.65,.07), turnedPivot=new T.Vector3(), ahead=new T.Vector3(), forward=new T.Vector3(), modelCentre=new T.Vector3(), worldRotation=new T.Quaternion();
  const wrist=new T.Vector3(), bend=new T.Vector3(), elbow=new T.Vector3(), armLine=new T.Vector3();
  const neutralPoint=new T.Vector3(), targetPoint=new T.Vector3(), extraPoint=new T.Vector3(), targetRotation=new T.Quaternion(), baseRotation=new T.Quaternion(),
    wheelRotation=new T.Quaternion(), neutralRotation=new T.Quaternion(), wristTwist=new T.Quaternion(), cuffRotation=new T.Quaternion(), handAxis=new T.Vector3(), forearmAxis=new T.Vector3(), shoulder=new T.Vector3();
  function anchoredPose(anchor,parent,pt,rotation) {
    rotation.setFromEuler(parent.rotation).multiply(baseRotation.setFromEuler(anchor.rotation));
    pt.copy(anchor.position).applyEuler(parent.rotation).add(parent.position);
  }
  function placeBone(mesh,a,b) {
    limbVector.subVectors(b,a);
    const length=limbVector.length();
    mesh.position.copy(a).lerp(b,.5);
    mesh.quaternion.setFromUnitVectors(axisY,limbVector.multiplyScalar(1/Math.max(length,.01)));
    mesh.scale.y=length;
  }
  function moveHands() {
    // Loosen the fingers before leaving a socket, then close them after arriving at the next control.
    wheelRotation.setFromEuler(wheelTilt.rotation).multiply(baseRotation.setFromEuler(wheelSpin.rotation));
    const progress=T.MathUtils.smoothstep(reach,.12,.89);
    const arc=Math.sin(Math.PI*progress)*.095;
    const opening=T.MathUtils.smoothstep(reach,0,.31)*(1-T.MathUtils.smoothstep(reach,.66,.99));
    if(handTarget!=='wheel') anchoredPose(handTarget==='brake'?brakeGrip:gearGrip,handTarget==='brake'?brakeArm:shifter,targetPoint,targetRotation);
    for(const arm of arms) {
      const {grip,hand,side}=arm, right=side===-1;
      const a=side*gloveSteerStation;
      grip.position.set(Math.sin(a)*wheelRadius,Math.cos(a)*wheelRadius,0);
      grip.rotation.set(0,0,Math.PI-a);
      neutralPoint.copy(grip.position).applyQuaternion(wheelRotation).add(wheelTilt.position);
      neutralRotation.copy(wheelRotation).multiply(baseRotation.setFromEuler(grip.rotation));
      hand.position.copy(neutralPoint);hand.quaternion.copy(neutralRotation);
      if(right&&handTarget!=='wheel') {
        hand.position.lerp(targetPoint,progress).add(extraPoint.set(-.16*arc,(handTarget==='brake'?.66:.39)*arc,-arc));
        hand.quaternion.slerp(targetRotation,progress);
      }
      const reaching=right&&handTarget!=='wheel';
      formGlove(arm,reaching?opening:0,reaching?progress:0,reaching&&handTarget==='brake'?progress:0);
      cuffRotation.copy(hand.quaternion).multiply(arm.cuffFrame);
      handAxis.set(0,1,0).applyQuaternion(cuffRotation);
      wrist.copy(arm.cuff).applyQuaternion(hand.quaternion).add(hand.position).addScaledVector(handAxis,.006);
      shoulder.copy(arm.shoulder).add(extraPoint.set(-wheelAngle*.021,0,0));
      armLine.subVectors(wrist,shoulder);
      const distance=Math.max(armLine.length(),.04), upper=.375, lower=.436;
      armLine.divideScalar(distance);
      const along=clamp((upper**2-lower**2+distance**2)/(2*distance),.018,upper);
      bend.set(side*(right?mix(.46,.49,progress):.46),-.76,-.10).addScaledVector(armLine,-bend.dot(armLine)).normalize();
      elbow.copy(shoulder).addScaledVector(armLine,along).addScaledVector(bend,Math.sqrt(Math.max(0,upper**2-along**2)));
      placeBone(arm.lower,elbow,wrist);
      forearmAxis.subVectors(wrist,elbow).normalize();
      wristTwist.setFromUnitVectors(handAxis,forearmAxis);
      arm.lower.quaternion.copy(wristTwist).multiply(cuffRotation);
      writeWrist(arm);
    }
    actionPose.mode=handTarget;actionPose.reach=progress;actionPose.contact=handTarget==='wheel'||reach>=.999;
  }
  function resetDriver(gear=null) {
    activeGear=gear===null?null:String(gear);shiftAge=Infinity;handTarget='wheel';reach=leverLoad=0;
    wheelAngle=0;wheelSpin.rotation.z=0;
    brakeArm.rotation.x=0;shifter.rotation.set(0,0,0);moveHands();
  }
  function animateDriver(dt,state,gear) {
    const shiftDuration=.71, inspect=Boolean(state.inspectGear);
    if(inspect) {activeGear=gear;shiftAge=Infinity;}
    else if(activeGear===null) activeGear=gear;
    else if(gear!==activeGear) {
      shiftDirection=gear==='R'?-1:activeGear==='R'?1:Number(gear)>=Number(activeGear)?1:-1;
      activeGear=gear;shiftAge=0;
    }
    const braking=!inspect&&Boolean(state.handbrake??state.braking);
    const shifting=shiftAge<shiftDuration;
    const goal=braking?'brake':shifting||inspect?'gear':'wheel';
    let extending=goal!=='wheel'&&goal===handTarget;
    if(goal!==handTarget&&reach===0) {handTarget=goal;extending=goal!=='wheel';}
    reach=clamp(reach+dt*(extending?4.50:-4.03),0,1);
    if(reach===0&&!extending) handTarget='wheel';
    if(shifting) {
      if(braking) shiftAge=0;
      else if(handTarget==='gear') shiftAge+=dt;
    }
    const locked=T.MathUtils.smoothstep(reach,.72,1);
    leverLoad=mix(leverLoad,handTarget==='brake'&&braking?locked:0,1-Math.exp(-dt*21));
    brakeArm.rotation.x=-leverLoad*.275;
    const shiftStroke=T.MathUtils.smoothstep(shiftAge,.23,.37)*(1-T.MathUtils.smoothstep(shiftAge,.47,.65));
    const lane=gear==='R'?-1:Number(gear)%2===0?1:-1;
    const inGear=handTarget==='gear'?shiftStroke*locked:0, linkage=1-Math.exp(-dt*29);
    shifter.rotation.x=mix(shifter.rotation.x,shiftDirection*.205*inGear,linkage);
    shifter.rotation.z=mix(shifter.rotation.z,lane*.139*inGear,linkage);
    if(cockpitView)moveHands();
    else {
      actionPose.mode=handTarget;actionPose.reach=reach;
      actionPose.contact=handTarget==='wheel'||reach>.95;
    }
    return shifting&&handTarget==='gear';
  }
  car.userData.setCockpitView = (enabled,preservePose=false) => {
    cockpitView=Boolean(enabled);
    driver.visible=cockpitView;
    for(const arm of arms) arm.hand.visible=cockpitView;
    m.frontGlass.opacity=cockpitView?.044:.18;
    m.sideGlass.opacity=cockpitView?.067:.27;
    m.rearGlass.opacity=cockpitView?.115:.23;
    if(!preservePose) resetDriver();
  };
  car.userData.resetDriver = resetDriver;
  car.userData.driverAction = actionPose;
  car.userData.setMirrorTexture = texture => {
    mirrorScreen.map=texture||mirrorFallback;
    mirrorScreen.toneMapped=Boolean(texture);
    mirrorScreen.needsUpdate=true;
  };
  function applyHalos() { for (const [sprite,level] of halos) sprite.material.opacity=power*headFacing*level; }
  function applyLamps() {
    m.headlamp.emissiveIntensity=power*2.72;
    m.evoLamp.emissiveIntensity=power*1.14;
    m.auxLamp.emissiveIntensity=power*3.35;
    m.s1TailLens.emissiveIntensity=.062+power*.40+tailBrake*2.55;
    for (const [light,level] of fills) light.intensity=power*level;
    applyHalos();
  }
  applyLamps();
  car.userData.setHeadlights = enabled => { lampsOn = Boolean(enabled); };
  car.userData.updateGlow = eye => {
    car.getWorldPosition(modelCentre); bodyPivot.getWorldQuaternion(worldRotation);
    const facing=ahead.copy(eye).sub(modelCentre).normalize().dot(forward.set(0,0,1).applyQuaternion(worldRotation));
    headFacing=T.MathUtils.smoothstep(facing,.11,.69);
    applyHalos();
  };
  car.userData.tick = (dt,state={}) => {
    dt=clamp(Number.isFinite(dt)?dt:0,0,.075);
    if (!dt) return;
    const speed=Number.isFinite(state.speed)?state.speed:0, steer=clamp(Number.isFinite(state.steer)?state.steer:0,-1,1);
    const blend=1-Math.exp(-dt*10);
    for (const [name,{ pivot,axle,end,side,haze }] of Object.entries(wheels)) {
      const tyre=state.wheels?.[name.slice(-2)];
      if(tyre) {
        axle.rotation.x=tyre.spin;
        pivot.rotation.y=tyre.angle;
        pivot.position.y=mix(pivot.position.y,axleY+tyre.height,blend);
      } else {
        axle.rotation.x=(axle.rotation.x+(speed/radius)*dt)%(Math.PI*2);
        if(end === 'F') pivot.rotation.y=mix(pivot.rotation.y,steer*.285*(Math.sign(steer)===side?1.07:.93),blend);
        pivot.position.y=mix(pivot.position.y,axleY,blend);
      }
      const blur=T.MathUtils.smoothstep(Math.abs(tyre?.omega??speed/radius),25,69);
      haze.visible=blur>.006;haze.material.opacity=blur*.79;
    }
    const foreA=Number.isFinite(state.accelLong)?state.accelLong:(speed-previousSpeed)/dt*.36;
    const sideA=Number.isFinite(state.accelLat)?state.accelLat:steer*Math.min(Math.abs(speed)*.51,4.8);
    pitch=mix(pitch,clamp(-foreA*.0074,-.072,.090),blend*.80);
    roll=mix(roll,clamp(sideA*.0104,-.117,.117),blend*.73);
    bodyPivot.rotation.set(pitch,0,roll);
    bodyPivot.position.copy(pivotPoint).sub(turnedPivot.copy(pivotPoint).applyEuler(bodyPivot.rotation));
    tremor=(tremor+Math.abs(speed)*dt*7.6)%(Math.PI*2);
    bodyPivot.position.y+=Math.sin(tremor)*(state.roughness??0)*Math.min(Math.abs(speed)*.0017,.022);
    for(const flap of s1MudPivots) flap.rotation.x=mix(flap.rotation.x,clamp(speed*.009,-.11,.20),blend*.63);
    const wheelGoal=state.steerAngle===undefined?-steer*.78:clamp(-state.steerAngle*2.02,-1.18,1.18);
    wheelAngle=mix(wheelAngle,wheelGoal,1-Math.exp(-dt*18)); wheelSpin.rotation.z=wheelAngle;
    if(cockpitView||state.animateCabin) {
      const gear=String(state.gear ?? (speed<-.18?'R':1+Math.floor(Math.abs(speed)/7)));
      const shifting=animateDriver(dt,state,gear);
      if(cockpitView) drawMeters(speed,gear,state.rev ?? clamp(.22+Math.abs(speed)*.029,0,1),handTarget,shifting,state.displayKmh);
    }
    tailBrake=mix(tailBrake,state.serviceBrake||state.handbrake?1:0,1-Math.exp(-dt*19));
    previousSpeed=speed; power=mix(power,lampsOn?1:0,1-Math.exp(-dt*19)); applyLamps();
  };
  car.userData.sockets = sockets;
  car.userData.wheels = Object.fromEntries(Object.entries(wheels).map(([name,{pivot}])=>[name,pivot]));
  car.userData.bodyPivot = bodyPivot;
  car.userData.classification = 'object, hard-surface';
  car.userData.lowConfidence = ['Underside and hidden cockpit fittings','Bumper and hood duct depths','Rear cooling duct and exhaust routing','Wing chord, internal braces and unseen mounting surfaces'];

  // Switch only the kit groups and paint. The pivot identities, speed, and orientation stay intact.
  let build=DEFAULT_RALLY_BUILD;
  function setBuild(patch={}) {
    const next={...build};
    if (Object.hasOwn(noses,patch.nose)) next.nose=patch.nose;
    if (Object.hasOwn(rearKits,patch.rear)) next.rear=patch.rear;
    if (Object.hasOwn(spoilers,patch.wing)) next.wing=patch.wing;
    if (Object.hasOwn(vinyl,patch.vinyl)) next.vinyl=patch.vinyl;
    if (Object.hasOwn(palettes,patch.theme)) next.theme=patch.theme;
    build=Object.freeze(next);
    for (const [id,kit] of Object.entries(noses)) for (const group of Object.values(kit)) group.visible=(id===build.nose);
    for (const [id,kit] of Object.entries(rearKits)) for (const group of Object.values(kit)) group.visible=(id===build.rear);
    for (const trim of frontWheelTrims) {
      trim.disc.visible=trim.caliper.visible=build.nose==='evo';
      trim.spokes.visible=build.nose==='classic';
    }
    for (const [id,kit] of Object.entries(spoilers)) kit.foil.visible=kit.mounts.visible=(id===build.wing);
    const rearS1=build.rear==='s1';
    worksS1.foil.visible=worksS1.mounts.visible=rearS1;
    worksStandard.foil.visible=worksStandard.mounts.visible=!rearS1;
    for (const [id,layer] of Object.entries(vinyl)) layer.visible=(id===build.vinyl);
    sockets.headlights=headlightSockets[build.nose];
    sockets.exhaust.position.set(...(rearS1?s1Exhaust:[.03,.421,-2.652]));
    const spec=rearS1&&build.wing==='works'?worksS1:spoilers[build.wing]; sockets.wing.position.set(0,spec.height,spec.z);
    const colors=palettes[build.theme], worksVinyl=build.vinyl==='rally';
    m.paintInk.color.setHex(colors.ink);
    m.paintDim.color.setHex(colors.dim);
    m.paintRed.color.setHex(colors.red);
    m.paintPin.color.setHex(colors.pin);
    m.evoHeritageInk.color.setHex(build.theme==='black'?0x222422:colors.ink);
    m.evoHeritageRed.color.setHex(build.theme==='black'?0xb91e27:colors.red);
    m.evoHeritagePin.color.setHex(build.theme==='black'?0xb79748:colors.pin);
    m.beltPaint.color.setHex(worksVinyl?colors.ink:0xebebef);
    m.sillEdgePaint.color.setHex(worksVinyl?colors.ink:colors.red);
    m.sill.color.setHex(worksVinyl?colors.dim:0xe0e0e6);
    m.bodyGrey.color.setHex(worksVinyl?0xd8dbe5:0xe3e3e9);
    const photo=build.theme==='black'&&!worksVinyl;
    m.s1Gold.color.setHex(photo?0xffab0d:colors.ink);
    m.s1Lower.color.setHex(photo?0xff9b09:worksVinyl?colors.red:colors.ink);
    m.s1Gold.emissive.copy(m.s1Gold.color);
    m.s1Lower.emissive.copy(m.s1Lower.color);
    m.midShoulder.color.copy(rearS1?m.s1Gold.color:m.beltPaint.color);
    m.midShoulder.emissive.copy(rearS1?m.s1Gold.emissive:m.beltPaint.emissive);
    m.midShoulder.emissiveIntensity=rearS1?.115:0;
    m.midSill.color.copy(rearS1&&photo?m.s1Lower.color:m.sillEdgePaint.color);
    m.s1UnderGold.color.setHex(photo?0xc97310:worksVinyl?colors.red:colors.ink).multiplyScalar(.68);
    m.s1Flap.color.copy(m.s1Lower.color);
    m.s1Flap.emissive.copy(m.s1Lower.color).multiplyScalar(.5);
    m.s1Nameplate.color.setHex(photo?0x262527:0xf3f0ea);
    car.userData.build=build;
    return build;
  }
  car.userData.setBuild=setBuild;
  setBuild(options.build || options);
  car.userData.setCockpitView(options.cockpit===true);
  return car;
}

// 03 / self-review: check the S1 straight-on for grille/optic spacing, and the rear quarter for flare, bumper and wing continuity.
// Compare the standard kit and other wing on the same pivots; inferred duct and underbody details are listed in userData.lowConfidence.
// At the eye socket, check the open windshield, the left grip at both locks, and the right hand's brake and shift contacts.
