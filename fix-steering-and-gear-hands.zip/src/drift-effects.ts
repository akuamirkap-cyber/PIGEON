import type * as Three from 'three';
import type { DriftState, DriftWheel, WheelId } from './drift-physics.js';

export function createDriftEffects(T: typeof Three) {
  const root = new T.Group();
  root.name = 'Drift effects';
  const tyreKeys = ['FL', 'FR', 'RL', 'RR'] as const;
  const marks = 2400, puffs = 144;
  const trackPositions = new Float32Array(marks * 18), trackInk = new Float32Array(marks * 6);
  const buffer = (array: Float32Array, size: number) => new T.BufferAttribute(array,size).setUsage(T.DynamicDrawUsage);
  const tracks = new T.BufferGeometry();
  tracks.setAttribute('position',buffer(trackPositions,3));
  tracks.setAttribute('ink',buffer(trackInk,1));
  tracks.setDrawRange(0,0);
  const strips = new T.Mesh(tracks,new T.ShaderMaterial({
    transparent:true,depthWrite:false,side:T.DoubleSide,
    vertexShader:`attribute float ink; varying float shade; void main(){shade=ink;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`varying float shade; void main(){gl_FragColor=vec4(.075,.086,.080,shade);}`,
  }));
  strips.frustumCulled=false;strips.renderOrder=2;root.add(strips);
  let markIndex=0, markCount=0, marksDirty=false;
  const previous=Object.fromEntries(tyreKeys.map(id=>[id,{x:0,z:0,dx:0,dz:0,ink:0,active:false,smoke:0}])) as Record<WheelId,{x:number;z:number;dx:number;dz:number;ink:number;active:boolean;smoke:number}>;

  function rubber(id:WheelId, wheel:DriftWheel, opacity:number) {
    const p=previous[id], sx=wheel.x-p.x, sz=wheel.z-p.z;
    const distance=Math.hypot(sx,sz);
    if (distance<.12) return;
    if (distance>2) {p.x=wheel.x;p.z=wheel.z;p.active=false;return;}
    const half=.127+opacity*.16;
    const dx=sz/distance*half,dz=-sx/distance*half;
    if (!p.active) {p.x=wheel.x;p.z=wheel.z;p.dx=dx;p.dz=dz;p.ink=0;p.active=true;return;}
    const y=.010;
    trackPositions.set([p.x+p.dx,y,p.z+p.dz,p.x-p.dx,y,p.z-p.dz,wheel.x+dx,y,wheel.z+dz,
      wheel.x+dx,y,wheel.z+dz,p.x-p.dx,y,p.z-p.dz,wheel.x-dx,y,wheel.z-dz],markIndex*18);
    trackInk.set([p.ink,p.ink,opacity,opacity,p.ink,opacity],markIndex*6);
    markIndex=(markIndex+1)%marks;markCount=Math.min(marks,markCount+1);marksDirty=true;
    p.x=wheel.x;p.z=wheel.z;p.dx=dx;p.dz=dz;p.ink=opacity;
  }

  const particles=Array.from({length:puffs},()=>({ x:0,y:0,z:0,vx:0,vy:0,vz:0,life:0,max:1,seed:0,dust:0 }));
  const fogPositions=new Float32Array(puffs*3), fogData=new Float32Array(puffs*4);
  const fogGeo=new T.BufferGeometry();
  fogGeo.setAttribute('position',buffer(fogPositions,3));
  fogGeo.setAttribute('puff',buffer(fogData,4));
  const fogMat=new T.ShaderMaterial({transparent:true,depthWrite:false,
    uniforms:{viewScale:{value:480}},
    vertexShader:`uniform float viewScale; attribute vec4 puff; varying vec4 info;
      void main(){info=puff; vec4 eye=modelViewMatrix*vec4(position,1.); gl_Position=projectionMatrix*eye;
      gl_PointSize=clamp(puff.x*viewScale/max(.35,-eye.z),1.,120.);}`,
    fragmentShader:`varying vec4 info;
      void main(){vec2 p=gl_PointCoord-.5; float r=dot(p,p); if(r>.25||info.y<=.0)discard;
      float w=1.-smoothstep(.006,.25,r+.016*sin(p.x*27.+info.z)*sin(p.y*23.-info.z));
      vec3 tint=mix(vec3(.82,.86,.87),vec3(.69,.52,.36),info.w);
      gl_FragColor=vec4(tint,w*w*info.y);}`,
  });
  const fog=new T.Points(fogGeo,fogMat);fog.frustumCulled=false;fog.renderOrder=3;root.add(fog);
  let next=0, seed=1405, active=0;
  const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  function spawn(wheel:DriftWheel, state:DriftState) {
    const p=particles[next];next=(next+1)%puffs;
    p.x=wheel.x+(rand()-.5)*.21;p.y=.12;p.z=wheel.z+(rand()-.5)*.21;
    p.vx=state.vx*.135+(rand()-.5)*1.5+.14;p.vy=.38+rand()*.49;p.vz=state.vz*.135+(rand()-.5)*1.1;
    p.life=p.max=.75+rand()*.93;p.seed=rand()*Math.PI*2;p.dust=wheel.roughness>.55?.90:0;
  }

  function step(dt:number, state:DriftState) {
    for(const id of tyreKeys) {
      const wheel=state.wheels[id], p=previous[id];
      if(state.speed>2.1&&wheel.slip>.31&&wheel.roughness<.6) rubber(id,wheel,wheel.slip*(wheel.front?.23:.52));
      else {p.active=false;p.x=wheel.x;p.z=wheel.z;}
      if(!wheel.front&&state.speed>2) {
        const drift=Math.min(1,Math.abs(state.beta)*2.35)*state.driftBlend;
        const strength=Math.max(wheel.roughness*.46*state.speed/15,(wheel.slip-.29)*(1.42+drift*.48));
        p.smoke+=Math.max(0,strength)*dt*23;
        if(p.smoke>1) {p.smoke-=1;spawn(wheel,state);}
      }
    }
    for(const p of particles) if(p.life>0) {
      p.life=Math.max(0,p.life-dt);p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;
    }
  }

  function update(viewScale:number) {
    if(marksDirty) {
      tracks.attributes.position.needsUpdate=tracks.attributes.ink.needsUpdate=true;
      tracks.setDrawRange(0,markCount*6);marksDirty=false;
    }
    active=0;
    for(const p of particles) if(p.life>0) {
      const age=1-p.life/p.max;
      fogPositions.set([p.x,p.y,p.z],active*3);
      fogData.set([.36+age*(p.dust>.5?1.85:1.55),p.life/p.max*(p.dust>.5?.37:.32),p.seed,p.dust],active*4);
      active++;
    }
    fogGeo.setDrawRange(0,active);
    if(active) fogGeo.attributes.position.needsUpdate=fogGeo.attributes.puff.needsUpdate=true;
    fogMat.uniforms.viewScale.value=viewScale;
  }

  function reset() {
    markIndex=markCount=next=active=0;tracks.setDrawRange(0,0);fogGeo.setDrawRange(0,0);
    for(const p of particles) p.life=0;
    for(const p of Object.values(previous)) {p.active=false;p.smoke=0;}
  }
  fogGeo.setDrawRange(0,0);
  return {root,step,update,reset,get smoky(){return active>0;}};
}