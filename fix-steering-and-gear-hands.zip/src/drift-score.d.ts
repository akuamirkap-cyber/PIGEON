export type DriftMedal = 'bronze' | 'silver' | 'gold' | null;
export type DriftScore = {
  total: number; top: number; points: number; multiplier: number; links: number; allLinks: number;
  grace: number; outer: boolean; phase: 'idle' | 'drift' | 'carry' | 'banked' | 'lost'; cause: string; sequence: number;
  bonusPoints: number; pendingBonus: number;
};
type DriftSample = {
  speed: number; beta: number; forward: number; along: number; slip: number; roughness: number;
  impact: number; outside: boolean; linking: boolean;
};
export const medalGoals: Readonly<{bronze:number;silver:number;gold:number}>;
export const outsideMultiplier: number;
export function driftMedal(score:number): DriftMedal;
export function createDriftScore(): {
  step(dt:number, sample:DriftSample): void;
  reset(): void;
  finish(): void;
  snapshot(): DriftScore;
  readonly inBonus: boolean;
};