import { useEffect, useRef, useState } from 'react';
import type { PointerEvent, ReactNode } from 'react';
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Box, CircleHelp, Flag, Focus, Gauge, Maximize, Video,
  Minimize, Minus, Pause, Play, Plus, RotateCcw, Trophy, Volume2, VolumeX, X,
} from 'lucide-react';
import { BuildPanel } from './BuildPanel';
import { DriftReadout, DrivePrompt, formatScore, LapReadout, RaceBrand, RouteMap, SpeedReadout } from './DriveHud';
import { GhostCoach, GhostIcon } from './GhostHud';
import type { GhostHudData, GhostMode } from './ghost-replay.js';
import type { Route } from './DriveHud';
import { driftMedal, medalGoals } from './drift-score.js';
import { defaultBuild, readBuild, writeBuild } from './rally-config';
import type { RallyBuild } from './rally-config';
import { emptyTelemetry } from './rally-course';
import type { RunMode } from './rally-course';
import { createStudio } from './rally-studio';
import type { DriveCamera, GripKey, Studio, ViewId, ViewerMode } from './rally-studio';

const cameras: { id: DriveCamera; label: string; accessible: string }[] = [
  { id: 'chase', label: 'Belakang', accessible: 'Kamera belakang' },
  { id: 'overhead', label: 'Atas', accessible: 'Kamera atas' },
  { id: 'cockpit', label: 'Kokpit', accessible: 'Kamera kokpit' },
  { id: 'bumper', label: 'Bemper', accessible: 'Kamera bemper' },
];
const garageViews: { id: ViewId; label: string }[] = [
  { id: 'threeQuarter', label: 'Sudut 3/4' }, { id: 'front', label: 'Depan' }, { id: 'rear', label: 'Belakang' },
  { id: 'left', label: 'Kiri' }, { id: 'right', label: 'Kanan' }, { id: 'top', label: 'Atas' },
];
const keyBindings: Partial<Record<string, GripKey>> = {
  KeyW:'w', KeyS:'s', KeyA:'a', KeyD:'d', Space:'space', ArrowUp:'w', ArrowDown:'s', ArrowLeft:'a', ArrowRight:'d',
};
const names: Record<GripKey, string> = { w:'Gas', s:'Rem atau mundur', a:'Belok kiri', d:'Belok kanan', space:'Rem tangan' };
const settingKey = 'rally-lab.drift.settings';
const recordKey = 'rally-lab.drift.record.v1';

function readRecord() {
  try {
    const score=Number(localStorage.getItem(recordKey));
    return Number.isFinite(score)?Math.max(0,Math.floor(score)):0;
  } catch { return 0; }
}

function getSettings() {
  try {
    const values = JSON.parse(localStorage.getItem(settingKey) ?? '{}');
    return { assist: values?.assist !== false, sound: values?.sound !== false, speedEffects:values?.speedEffects!==false };
  } catch { return { assist:true, sound:true, speedEffects:true }; }
}

function CameraIcon({ kind }: { kind: DriveCamera }) {
  return <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {kind === 'chase' && <><path d="m5.1 10.3 1.7-4.2h10.4l1.7 4.2M4 11.5l1.4-1.4h13.2l1.4 1.4v4.8H4v-4.8ZM5.7 16.4v2.2m12.6-2.2v2.2M7 13.3h2.4m5.2 0H17M10.9 16.3h2.2"/></>}
    {kind === 'overhead' && <><path d="M5 9V5h4m6 0h4v4m0 6v4h-4m-6 0H5v-4M9 11.2l3-3.7 3 3.7v4.5l-3-1.6-3 1.6v-4.5Z"/></>}
    {kind === 'cockpit' && <><circle cx="12" cy="12" r="8.1"/><circle cx="12" cy="12" r="2.24"/><path d="m4.1 10.7 5.6.83m4.6 0 5.6-.83M12 14.2v5.9"/></>}
    {kind === 'bumper' && <><path d="M4 9V6h3m10 0h3v3M4 15v3h3m10 0h3v-3M7.2 14.5l3-4.9m6.6 4.9-3-4.9M12 14.5v.1"/><path d="M8 14.5h8"/></>}
  </svg>;
}

function ShiftIcon() {
  return <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
    <path d="M5 6v12m7-12v12m7-12v12M5 12h14M4 5h2m5 0h2m5 0h2M4 19h2m5 0h2m5 0h2"/>
  </svg>;
}

function ToolButton({ label, title, onClick, children, disabled }: {
  label: string; title?: string; onClick: () => void; children: ReactNode; disabled?: boolean;
}) {
  return <button type="button" className="hud-button" aria-label={label} title={title ?? label} onClick={onClick} disabled={disabled}>{children}</button>;
}

export default function App() {
  const viewport = useRef<HTMLDivElement>(null), stage = useRef<HTMLElement>(null), menu = useRef<HTMLDialogElement>(null);
  const engine = useRef<Studio | undefined>(undefined), held = useRef(new Map<GripKey, Set<string>>());
  const [build,setBuild] = useState(readBuild);
  const [settings,setSettings] = useState(getSettings);
  const [record,setRecord] = useState(readRecord);
  const initialView = build.rear === 's1' ? 'rearQuarter' : 'threeQuarter';
  const live = useRef({build,settings,record,finished:false,view:initialView as ViewId,mode:'drive' as ViewerMode,camera:'chase' as DriveCamera,ghostCamera:'chase' as DriveCamera,ghost:'off' as GhostMode,paused:false,inspect:false,headlights:false,turning:false,guide:false});
  const [mode,setMode] = useState<ViewerMode>('drive');
  const [selected,setSelected] = useState<DriveCamera>('chase');
  const [selectedGhost,setSelectedGhost] = useState<DriveCamera>('chase');
  const [ghostMode,setGhostMode] = useState<GhostMode>('off');
  const [ghostData,setGhostData] = useState<GhostHudData|null>(null);
  const ghostState = useRef<GhostHudData|null>(null);
  const [inspect,setInspect] = useState(false);
  const [paused,setPaused] = useState(false);
  const [guide,setGuide] = useState(false);
  const [ready,setReady] = useState(false);
  const [error,setError] = useState(false);
  const [pressed,setPressed] = useState<GripKey[]>([]);
  const [fullscreen,setFullscreen] = useState(false);
  const [telemetry,setTelemetry] = useState(emptyTelemetry);
  const [route,setRoute] = useState<Route>({path:'',start:{x:0,y:0},length:1,zones:[]});
  const [newRecord,setNewRecord] = useState(false);
  const [view,setView] = useState<ViewId|null>(initialView);
  const [turning,setTurning] = useState(false);

  const driving = mode === 'drive';
  const watching=ghostMode==='watch';
  const visibleTelemetry=watching&&ghostData?ghostData.telemetry:telemetry;
  const finished = telemetry.finished&&!watching;
  const medal = driftMedal(telemetry.drift.total);
  const alternate:RunMode = telemetry.mode==='attack'?'practice':'attack';
  const camera = watching?selectedGhost:inspect?'cockpit':selected;
  const isRear = view === 'rear' || view === 'rearQuarter' || view === 'rearDetail';

  function focusDrive() { viewport.current?.focus({preventScroll:true}); }

  function clearInputs() {
    held.current.clear();engine.current?.releaseInputs();setPressed([]);
  }

  function input(key:GripKey, source:string, down:boolean) {
    if (down && (!engine.current || live.current.mode !== 'drive' || live.current.ghost==='watch' || live.current.paused || live.current.inspect || live.current.finished)) return;
    const state = held.current, sources=state.get(key);
    if (down) {
      if (sources?.size) { sources.add(source); return; }
      state.set(key,new Set([source]));
      if(key==='w'||key==='s') engine.current?.unlockAudio();
      engine.current?.input(key,true);
    } else {
      if(!sources?.delete(source)||sources.size) return;
      state.delete(key);engine.current?.input(key,false);
    }
    setPressed([...state.keys()]);
  }

  function changeInspect(next:boolean) {
    if (live.current.mode !== 'drive' || live.current.ghost==='watch' || live.current.inspect === next || !engine.current) return;
    live.current.inspect=next;setInspect(next);clearInputs();engine.current.inspectGear(next);
    if(!next) focusDrive();
  }

  function chooseCamera(next:DriveCamera) {
    if(live.current.ghost==='watch') {live.current.ghostCamera=next;setSelectedGhost(next);}
    else {live.current.camera=next;setSelected(next);}
    engine.current?.camera(next);
    if(live.current.inspect) changeInspect(false);
  }

  function cycleCamera() {
    const active=live.current.ghost==='watch'?live.current.ghostCamera:live.current.camera;
    const i=cameras.findIndex(item=>item.id===active);
    chooseCamera(cameras[(i+1)%cameras.length].id);
    focusDrive();
  }

  function toggleBumper() {
    const active=live.current.ghost==='watch'?live.current.ghostCamera:live.current.camera;
    chooseCamera(active==='bumper'?'chase':'bumper');focusDrive();
  }

  function chooseGhost(next:GhostMode) {
    const current=live.current,player=engine.current;
    if(!player||current.mode!=='drive'||current.ghost===next)return;
    if(current.inspect)changeInspect(false);
    if(next==='watch'||current.ghost==='watch') {
      clearInputs();current.paused=current.guide=false;setPaused(false);setGuide(false);
      player.pause(false);menu.current?.close();
    }
    current.ghost=next;setGhostMode(next);
    if(next==='watch')player.unlockAudio();
    player.ghost(next);player.camera(next==='watch'?current.ghostCamera:current.camera);
    focusDrive();
  }

  function toggleGhostCamera() {chooseGhost(live.current.ghost==='watch'?'follow':'watch');}

  function playGhost() {
    if(!engine.current||live.current.ghost!=='watch')return;
    engine.current.unlockAudio();engine.current.ghostPlay(!ghostState.current?.playing);
  }

  function replayGhost() {
    if(live.current.paused)togglePause(false);
    engine.current?.ghostSeek(0);engine.current?.ghostPlay(true);focusDrive();
  }

  function togglePause(next:boolean) {
    if (live.current.mode!=='drive'||live.current.paused===next||(live.current.finished&&live.current.ghost!=='watch')||!engine.current) return;
    live.current.paused=next;
    live.current.guide=false;setGuide(false);
    clearInputs();engine.current.pause(next);setPaused(next);
    if(!next) {
      menu.current?.close();
      focusDrive();
    }
  }

  function restart(type?:RunMode) {
    if(live.current.ghost==='watch'){replayGhost();return;}
    togglePause(false);clearInputs();
    live.current.finished=false;setNewRecord(false);
    live.current.inspect=false;setInspect(false);
    engine.current?.restart(type);
    if(menu.current?.open) menu.current.close();
    focusDrive();
  }

  function chooseView(next:ViewId) {
    live.current.view=next;live.current.turning=false;setView(next);setTurning(false);
    engine.current?.turntable(false);engine.current?.view(next);
  }

  function switchMode(next:ViewerMode) {
    if(live.current.mode===next) return;
    togglePause(false);menu.current?.close();clearInputs();
    live.current.mode=next;live.current.inspect=false;setInspect(false);setMode(next);
    engine.current?.mode(next);
    if(next==='garage') {
      chooseView(live.current.build.rear==='s1'?'rearQuarter':'threeQuarter');
    } else focusDrive();
  }

  function selectPart<K extends keyof RallyBuild>(part:K,value:RallyBuild[K]) {
    if (value === live.current.build[part]) return;
    const next={...live.current.build,[part]:value};
    live.current.build=next;setBuild(next);engine.current?.configure(next);writeBuild(next);
    if(part==='nose') chooseView('noseDetail');
    if(part==='rear'||part==='wing') chooseView('rearQuarter');
  }

  function resetBuild() {
    const fresh={...defaultBuild};live.current.build=fresh;setBuild(fresh);engine.current?.configure(fresh);writeBuild(fresh);chooseView('rearQuarter');
  }

  function toggleTurntable() {
    const next=!live.current.turning;
    if(next&&live.current.view==='noseDetail') chooseView('threeQuarter');
    if(next&&live.current.view==='rearDetail') chooseView('rearQuarter');
    live.current.turning=next;setTurning(next);engine.current?.turntable(next);
  }

  function changeSetting(key:keyof typeof settings) {
    const next={...live.current.settings,[key]:!live.current.settings[key]};
    live.current.settings=next;
    if(key==='sound')engine.current?.sound(next.sound);
    else if(key==='assist')engine.current?.assist(next.assist);
    else engine.current?.speedEffects(next.speedEffects);
    setSettings(next);
    try { localStorage.setItem(settingKey,JSON.stringify(next)); } catch { /* Storage is optional. */ }
  }

  async function toggleFullscreen() {
    if(!stage.current) return;
    if(document.fullscreenElement===stage.current) {await document.exitFullscreen().catch(()=>undefined);return;}
    if(stage.current.requestFullscreen) await stage.current.requestFullscreen().catch(()=>undefined);
  }

  useEffect(()=>{
    if(!viewport.current) return;
    const abort=new AbortController(), start=live.current;
    createStudio(viewport.current,{
      onManualOrbit:()=>{live.current.turning=false;setTurning(false);setView(null);},
      onTelemetry:data=>{
        if(data.finished&&!live.current.finished) {
          live.current.finished=true;clearInputs();
          const total=data.drift.total;
          if(total>live.current.record) {
            live.current.record=total;setRecord(total);setNewRecord(true);
            try {localStorage.setItem(recordKey,String(total));} catch { /* A run can finish without storage. */ }
          }
        }
        setTelemetry(data);
      },
      onGhost:data=>{ghostState.current=data;setGhostData(data);},
      onCourse:(path,marker,length,zones)=>setRoute({path,start:marker,length,zones}),
    },abort.signal,{build:start.build,headlights:start.headlights,view:start.view,mode:start.mode,camera:start.camera,...start.settings}).then(studio=>{
      if(!studio) return;
      if(abort.signal.aborted) {studio.dispose();return;}
      engine.current=studio;setReady(true);
    }).catch((reason:unknown)=>{if(!abort.signal.aborted){console.error(reason);setError(true);}});

    function keyDown(event:KeyboardEvent) {
      const code=event.code, target=event.target as HTMLElement|null;
      if(event.metaKey||event.ctrlKey||event.altKey||target?.closest('input,textarea,[contenteditable]'))return;
      const state=live.current;
      if(code==='KeyG'&&state.mode==='drive'&&!event.repeat){event.preventDefault();toggleGhostCamera();return;}
      if(state.finished&&state.ghost!=='watch') {if(code==='KeyR'&&!event.repeat) restart();return;}
      if(state.paused) {
        if(code==='KeyP'&&!event.repeat){event.preventDefault();togglePause(false);}
        return;
      }
      if(state.mode==='garage') {
        if(code==='Escape'&&!event.repeat) switchMode('drive');
        return;
      }
      if(state.ghost==='watch') {
        if(event.repeat)return;
        if(code==='Space'&&!target?.closest('button:focus-visible, a:focus-visible')){event.preventDefault();playGhost();}
        if(code==='KeyR')replayGhost();
        if(code==='KeyC')cycleCamera();
        if(code==='KeyB')toggleBumper();
        if(code==='KeyP')togglePause(true);
        if(code==='Escape'&&!document.fullscreenElement) chooseGhost('follow');
        if(code==='KeyM')changeSetting('sound');
        return;
      }
      const key=keyBindings[code];
      if(key&&!state.inspect) {
        if(code==='Space'&&target?.closest('button:focus-visible, a:focus-visible'))return;
        event.preventDefault();
        if(!event.repeat) {
          if(key!=='space') focusDrive();
          input(key,code,true);
        }
        return;
      }
      if(event.repeat)return;
      if(code==='KeyC') cycleCamera();
      if(code==='KeyB') toggleBumper();
      if(code==='KeyE') changeInspect(!state.inspect);
      if(code==='KeyR') restart();
      if(code==='KeyM') changeSetting('sound');
      if(code==='KeyL') {state.headlights=!state.headlights;engine.current?.headlights(state.headlights);}
      if(code==='KeyP'||code==='Escape') {
        if(code==='Escape'&&state.inspect) changeInspect(false);
        else if(code!=='Escape'||!document.fullscreenElement) togglePause(true);
      }
    }
    const keyUp=(event:KeyboardEvent)=>{const key=keyBindings[event.code];if(key)input(key,event.code,false);};
    const onFull=()=>setFullscreen(document.fullscreenElement===stage.current);
    const onVisibility=()=>{
      if(document.hidden && live.current.mode==='drive') {
        clearInputs();
        if(engine.current&&!live.current.paused) togglePause(true);
      }
    };
    window.addEventListener('keydown',keyDown);window.addEventListener('keyup',keyUp);window.addEventListener('blur',clearInputs);
    document.addEventListener('fullscreenchange',onFull);document.addEventListener('visibilitychange',onVisibility);
    return ()=>{
      abort.abort();engine.current?.dispose();engine.current=undefined;
      window.removeEventListener('keydown',keyDown);window.removeEventListener('keyup',keyUp);window.removeEventListener('blur',clearInputs);
      document.removeEventListener('fullscreenchange',onFull);document.removeEventListener('visibilitychange',onVisibility);
    };
  },[]);

  useEffect(()=>{
    if((paused||finished)&&!menu.current?.open) menu.current?.showModal();
    else if(!paused&&!finished&&menu.current?.open) menu.current.close();
  },[paused,finished]);

  function pedal(key:GripKey, mobile=false, icon?:ReactNode) {
    const pressedNow=pressed.includes(key);
    function down(event:PointerEvent<HTMLButtonElement>) {
      if(event.button!==0)return;
      event.currentTarget.setPointerCapture(event.pointerId);
      input(key,`pointer-${event.pointerId}`,true);
    }
    const release=(event:PointerEvent<HTMLButtonElement>)=>input(key,`pointer-${event.pointerId}`,false);
    return <button type="button" className={`${mobile?'touch-pedal':'keycap'}${key==='space'?' handbrake-key':''}${pressedNow?' key-active':''}`}
      aria-label={names[key]} aria-pressed={pressedNow} disabled={!ready||paused||inspect} title={names[key]}
      onPointerDown={down} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}
      onClick={event=>{
        if(event.detail===0){input(key,'accessible-tap',true);window.setTimeout(()=>input(key,'accessible-tap',false),195);}
      }}>
      {icon ?? (key==='space'?'SPASI':key.toUpperCase())}
    </button>;
  }

  return <main className={`race-screen${driving?'':' garage-screen'}${ready?' is-ready':''}${error?' race-error':''}${inspect?' is-inspecting':''}${watching?' ghost-watch':''}`} ref={stage} data-mode={mode} data-camera={driving?inspect?'gear':camera:'garage'} data-ghost={ghostMode} aria-label="Rally Lab Drift">
    <div className="game-viewport" ref={viewport} tabIndex={-1} onPointerDown={()=>{if(driving&&!paused&&!inspect) focusDrive();}}/>
    {driving&&<div className="race-vignette" aria-hidden="true"/>}

    <div className="corner corner-left">
      <RaceBrand/>
      {driving&&ready&&!inspect&&<LapReadout data={visibleTelemetry} route={route} record={record} ghost={ghostData}/>}
      {driving&&ready&&inspect&&<div className="inspect-view" aria-label="Inspeksi genggaman persneling">
        <span>INSPEKSI / KOKPIT</span><h1>Persneling</h1><p>Genggaman tangan kanan pada tuas otomatis.</p>
      </div>}
      {!driving&&<div className="garage-heading"><span>GROUP B / STUDIO</span><h1>Garasi</h1></div>}
    </div>

    {driving&&ready&&!paused&&!finished&&<div className="ghost-tools" role="group" aria-label="Mode Ghost AI">
      <button type="button" aria-label="Ghost AI di lintasan" aria-pressed={ghostMode!=='off'} title={ghostMode==='off'?'Tampilkan Ghost di lintasan':'Sembunyikan Ghost'} onClick={()=>chooseGhost(ghostMode==='off'?'follow':'off')}><GhostIcon/><span>Ghost AI</span></button>
      <button type="button" aria-label={watching?'Kembali ke kamera pemain':'Kamera Ghost'} aria-pressed={watching} aria-keyshortcuts="G" onClick={toggleGhostCamera}><Video size={16}/><span>{watching?'Kamera pemain':'Kamera Ghost'}</span><kbd aria-hidden="true">G</kbd></button>
    </div>}

    <div className="corner corner-right">
      {driving ? <>
        <div className="camera-switch" role="group" aria-label="Pilih kamera (C)">
          {cameras.map(item=><button type="button" key={item.id} aria-label={item.accessible} aria-pressed={camera===item.id}
            title={item.id==='bumper'?'Kamera bemper dekat aspal (B)':`${item.accessible} (C)`} aria-keyshortcuts={item.id==='bumper'?'B':undefined} onClick={event=>{chooseCamera(item.id);if(event.detail>0)focusDrive();}} disabled={!ready}>
            <CameraIcon kind={item.id}/><span>{item.label}</span>
          </button>)}
        </div>
        <ToolButton label="Jeda" title="Jeda (Esc / P)" onClick={()=>togglePause(true)} disabled={!ready}><Pause size={18}/></ToolButton>
      </> : <button className="back-to-track" type="button" onClick={()=>switchMode('drive')}><ArrowLeft size={17}/> Kembali ke lintasan</button>}
      {document.fullscreenEnabled&&<ToolButton label={fullscreen?'Keluar layar penuh':'Layar penuh'} onClick={()=>void toggleFullscreen()}>{fullscreen?<Minimize size={18}/>:<Maximize size={18}/>}</ToolButton>}
    </div>

    {!ready&&<div className="game-loading" role="status">
      {error?<><CircleHelp size={26}/><strong>WebGL tidak tersedia</strong><p>Aktifkan akselerasi grafis browser untuk bermain.</p><button className="primary-action" type="button" onClick={()=>location.reload()}><RotateCcw size={16}/> Muat ulang</button></>
        :<><span className="spinner"/><span>MEMUAT SIRKUIT PINUS</span></>}
    </div>}

    {driving&&ready&&!paused&&!finished&&(!inspect?<>
      <SpeedReadout data={visibleTelemetry} pedal={!watching}/>
      <RouteMap data={visibleTelemetry} route={route} ghost={watching} companion={ghostMode==='follow'?ghostData?.telemetry:undefined}/>
      <DriftReadout data={visibleTelemetry}/>
      {watching&&ghostData?<GhostCoach data={ghostData} onPlay={playGhost} onReplay={replayGhost} onExit={()=>chooseGhost('follow')}
        onRate={()=>engine.current?.ghostRate(ghostData.rate===.5?1:.5)} onSeek={time=>{engine.current?.ghostPlay(false);engine.current?.ghostSeek(time);}}/>:<>
      {camera==='cockpit'&&<button type="button" className="gear-inspect" aria-keyshortcuts="E" title="Detail gear (E)" onClick={()=>changeInspect(true)}><ShiftIcon/><span>Detail gear</span><kbd aria-hidden="true">E</kbd></button>}
      <div className="controls-cluster">
        {telemetry.time===0?<div className="start-hint"><i/> TAHAN W UNTUK MULAI <i/></div>:<DrivePrompt data={telemetry}/>}
        <div className="keyboard-controls" aria-label="Kontrol berkendara">
          <div><span className="key-group">{pedal('w')}{pedal('s')}</span><span>Gas / Rem</span></div>
          <div><span className="key-group">{pedal('a')}{pedal('d')}</span><span>Belok</span></div>
          <div><span className="key-group">{pedal('space')}</span><span>Rem tangan</span></div>
        </div>
      </div>
      <div className="touch-controls" aria-label="Kontrol sentuh">
        <div className="touch-steer">{pedal('a',true,<ArrowLeft/>)}{pedal('d',true,<ArrowRight/>)}</div>
        <div className="touch-drive">{pedal('space',true,<span>REM<br/>TANGAN</span>)}{pedal('s',true,<ArrowDown/>)}{pedal('w',true,<ArrowUp/>)}</div>
      </div>
      </>}
    </>:<button type="button" className="leave-inspect" aria-keyshortcuts="E" onClick={()=>changeInspect(false)}><ArrowLeft size={16}/> Kembali mengemudi <kbd aria-hidden="true">E</kbd></button>)}

    {!driving&&ready&&<>
      <div className="garage-build"><BuildPanel build={build} onPart={selectPart} onReset={resetBuild} onPreview={()=>chooseView('threeQuarter')}/></div>
      <div className="garage-bottom">
        <div className="garage-views" aria-label="Sudut pandang mobil">
          {garageViews.map(item=><button type="button" key={item.id} aria-pressed={view===item.id||(item.id==='rear'&&isRear)} onClick={()=>chooseView(item.id)}>{item.label}</button>)}
        </div>
        <div className="garage-tools">
          <ToolButton label="Perkecil kamera" onClick={()=>engine.current?.zoomBy(-1)}><Minus size={17}/></ToolButton>
          <ToolButton label="Perbesar kamera" onClick={()=>engine.current?.zoomBy(1)}><Plus size={17}/></ToolButton>
          <ToolButton label="Detail mobil" onClick={()=>chooseView(isRear?'rearDetail':'noseDetail')}><Focus size={17}/></ToolButton>
          <button className="hud-button" type="button" title="Putar otomatis" aria-label="Putar otomatis" aria-pressed={turning} onClick={toggleTurntable}><RotateCcw size={17}/></button>
        </div>
      </div>
    </>}

    <dialog className={`pause-menu${finished?' finish-menu':''}`} ref={menu} aria-labelledby="menu-title" onCancel={event=>{event.preventDefault();if(finished)return;if(live.current.guide){live.current.guide=false;setGuide(false);}else togglePause(false);}}>
      <div className="pause-top"><span><i/> RALLY LAB / {watching?'GHOST AI':'SIRKUIT PINUS'}</span>{!finished&&<ToolButton label={guide?'Kembali ke menu':'Tutup menu'} onClick={()=>{if(guide){live.current.guide=false;setGuide(false);}else togglePause(false);}}>{guide?<ArrowLeft size={18}/>:<X size={19}/>}</ToolButton>}</div>
      <h1 id="menu-title">{finished?'FINIS':guide?'Kontrol':'Dijeda'}</h1>
      {finished?<>
        <div className="finish-score"><span>{newRecord?'REKOR BARU':'SKOR PUTARAN'}</span><strong>{formatScore(telemetry.drift.total)}</strong></div>
        <div className="finish-splits"><div><span>KOMBO TERBAIK</span><b>{formatScore(telemetry.drift.top)}</b></div><div><span>SAMBUNGAN</span><b>{telemetry.drift.allLinks}</b></div></div>
        <div className={`finish-medal${medal?` medal-${medal}`:''}`}><Trophy size={17}/><span>{medal?({gold:'MEDALI EMAS',silver:'MEDALI PERAK',bronze:'MEDALI PERUNGGU'} as const)[medal]:'TARGET PERUNGGU'}</span>
          {!medal&&<b>{formatScore(medalGoals.bronze)} poin</b>}</div>
        <div className="pause-actions"><button className="primary-action" type="button" onClick={()=>restart('attack')}><RotateCcw size={18}/> Coba lagi</button><button type="button" onClick={()=>restart('practice')}><Flag size={18}/> Latihan bebas</button><button type="button" onClick={()=>chooseGhost('watch')}><GhostIcon size={18}/> Tonton Ghost AI</button></div>
      </>:guide ? <>
        <dl className="help-controls">
          <div><dt>Gas / rem dan mundur</dt><dd><kbd>W</kbd><kbd>S</kbd></dd></div>
          <div><dt>Belok kiri / kanan</dt><dd><kbd>A</kbd><kbd>D</kbd></dd></div>
          <div><dt>Rem tangan</dt><dd><kbd>SPASI</kbd></dd></div>
          <div><dt>Ganti kamera / detail persneling</dt><dd><kbd>C</kbd><kbd>E</kbd></dd></div>
          <div><dt>Kamera bemper dekat aspal</dt><dd><kbd>B</kbd></dd></div>
          <div><dt>Lihat kamera Ghost AI</dt><dd><kbd>G</kbd></dd></div>
          <div><dt>Ulang lintasan / jeda</dt><dd><kbd>R</kbd><kbd>P</kbd></dd></div>
        </dl>
        <p className="drift-tip">Masuk tikungan pertama sekitar 55-65 km/j. Ketuk Spasi sambil belok, lalu lepas rem tangan. Kalau garis melebar, lepas W sebentar: mobil tetap meluncur dan slide tidak langsung putus. Koreksi arah lawan sebentar untuk lurus, atau tahan lebih lama untuk menyambung drift.</p>
        <p className="gamepad-help">Gamepad: stik kiri untuk belok, RT untuk gas, LT untuk rem, dan tombol bawah (A) untuk rem tangan.</p>
      </> : watching ? <div className="pause-actions">
        <button className="primary-action" type="button" autoFocus onClick={()=>{togglePause(false);engine.current?.ghostPlay(true);}}><Play size={19}/> Lanjutkan demo</button>
        <button type="button" onClick={replayGhost}><RotateCcw size={18}/> Ulang demo Ghost</button>
        <button type="button" onClick={()=>chooseGhost('follow')}><ArrowLeft size={18}/> Kembali ke mobil sendiri</button>
      </div> : <>
        <div className="pause-actions">
          <button className="primary-action" type="button" autoFocus onClick={()=>togglePause(false)}><Play size={19}/> Lanjut mengemudi</button>
          <button type="button" aria-keyshortcuts="R" onClick={()=>restart()}><RotateCcw size={18}/> Ulang lintasan <kbd aria-hidden="true">R</kbd></button>
          <button type="button" onClick={()=>restart(alternate)}><Flag size={18}/> {alternate==='practice'?'Latihan bebas':'Drift Attack'}</button>
          <button type="button" onClick={()=>chooseGhost('watch')}><GhostIcon size={18}/> Tonton Ghost AI <kbd aria-hidden="true">G</kbd></button>
          <button type="button" onClick={()=>{live.current.guide=true;setGuide(true);}}><CircleHelp size={18}/> Kontrol dan cara drift</button>
          <button type="button" onClick={()=>switchMode('garage')}><Box size={18}/> Garasi</button>
        </div>
        <div className="pause-settings">
          <button type="button" role="switch" aria-label="Bantuan drift" aria-checked={settings.assist} onClick={()=>changeSetting('assist')}><CameraIcon kind="cockpit"/> Bantuan drift <span>{settings.assist?'NYAMAN':'PRO'}</span></button>
          <button type="button" role="switch" aria-checked={settings.sound} onClick={()=>changeSetting('sound')}>{settings.sound?<Volume2 size={17}/>:<VolumeX size={17}/>} Suara <span>{settings.sound?'ON':'OFF'}</span></button>
          <button type="button" role="switch" className="speed-setting" aria-label="Efek laju" aria-checked={settings.speedEffects} onClick={()=>changeSetting('speedEffects')}><Gauge size={18}/> Efek laju <span>{settings.speedEffects?'ON':'OFF'}</span></button>
        </div>
      </>}
    </dialog>
  </main>;
}