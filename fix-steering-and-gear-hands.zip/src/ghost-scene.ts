import * as T from 'three';
import { createRallyCarModel } from './rally-model.js';
import { defaultBuild } from './rally-config';
import { createDriftEffects } from './drift-effects';
import { buildGhostReference, createGhostPlayback } from './ghost-replay.js';
import type { GhostReference } from './ghost-replay.js';
import type { RallyTrack } from './rally-road.js';
import { createGhostShell } from './ghost-shell';

function makeTrail(reference:GhostReference) {
  const ribbon:number[]=[], ink:number[]=[], distance:number[]=[];
  const cyan=new T.Color('#87eadd'), slow=new T.Color('#ff9e69'), coast=new T.Color('#9cbcb6'), gold=new T.Color('#ffdb78');
  const rows=reference.frames;
  let start=0,mark=0;
  for(let i=1;i<rows.length;i+=2) {
    const first=rows[start], next=rows[i], dx=next.state.x-first.state.x,dz=next.state.z-first.state.z;
    const length=Math.hypot(dx,dz);
    if(length<1.84)continue;
    start=i;
    if(mark++%2===1)continue;
    const cutting=first.input.handbrake||Number(first.input.brake)>.125,bonus=first.telemetry.drift.outer;
    const half=bonus?.175:cutting?.140:.099, nx=dz*half/length, nz=-dx*half/length;
    const a=[first.state.x+nx,.032,first.state.z+nz],b=[first.state.x-nx,.032,first.state.z-nz];
    const c=[next.state.x-nx,.032,next.state.z-nz],d=[next.state.x+nx,.032,next.state.z+nz];
    ribbon.push(...a,...b,...c,...a,...c,...d);
    const tint=bonus?gold:cutting?slow:Number(first.input.gas)<.19?coast:cyan;
    for(let k=0;k<6;k++) ink.push(tint.r,tint.g,tint.b);
    distance.push(first.telemetry.distance,first.telemetry.distance,next.telemetry.distance,first.telemetry.distance,next.telemetry.distance,next.telemetry.distance);
  }
  const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(ribbon,3));
  geometry.setAttribute('ink',new T.Float32BufferAttribute(ink,3));geometry.setAttribute('roadAt',new T.Float32BufferAttribute(distance,1));
  const material=new T.ShaderMaterial({uniforms:{here:{value:0},windowSize:{value:70},nearCut:{value:-15}},transparent:true,depthWrite:false,side:T.DoubleSide,
    vertexShader:`attribute vec3 ink; attribute float roadAt; varying vec3 tint; varying float lane;
      void main(){tint=ink;lane=roadAt;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
    fragmentShader:`uniform float here;uniform float windowSize;uniform float nearCut;varying vec3 tint;varying float lane;
      void main(){float at=lane-here;float quiet=smoothstep(nearCut,nearCut+7.,at)*(1.-smoothstep(windowSize*.57,windowSize,at));
      if(quiet<.01)discard;gl_FragColor=vec4(tint,.84*quiet);
      #include <colorspace_fragment>
      }`,
  });
  const mesh=new T.Mesh(geometry,material);mesh.renderOrder=2;mesh.name='Ghost pedal trace';
  return {mesh,update(at:number,watching:boolean,interior:boolean){material.uniforms.here.value=at;
    material.uniforms.windowSize.value=watching?93:55;material.uniforms.nearCut.value=interior?2:-15;}};
}

function makeBeacon() {
  const canvas=document.createElement('canvas');canvas.width=160;canvas.height=66;
  const ink=canvas.getContext('2d')!;
  ink.beginPath();ink.moveTo(3,3);ink.lineTo(157,3);ink.lineTo(157,49);ink.lineTo(88,49);ink.lineTo(80,61);ink.lineTo(72,49);ink.lineTo(3,49);ink.closePath();
  ink.fillStyle='#142a2c';ink.fill();ink.lineWidth=3;ink.strokeStyle='#84eddf';ink.stroke();
  ink.fillStyle='#a4fcf2';ink.font='bold 25px sans-serif';ink.textAlign='center';ink.fillText('GHOST AI',80,36);
  const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;
  const marker=new T.Sprite(new T.SpriteMaterial({map,depthWrite:false,transparent:true,toneMapped:false}));
  marker.position.y=2.67;marker.scale.set(1.84,.76,1);marker.renderOrder=5;marker.name='Ghost marker';
  return marker;
}

export function createGhostScene(track:RallyTrack) {
  const reference=buildGhostReference(track), playback=createGhostPlayback(reference), trail=makeTrail(reference);
  const car=createRallyCarModel({THREE:T,build:{...defaultBuild,theme:'green',vinyl:'rally'},headlights:false});
  car.name='Ghost AI car';
  const shell=createGhostShell(car);
  const tint=new T.Color('#48c9b6'), tinted=new Set<T.MeshStandardMaterial>();
  car.traverse(object=>{
    const mesh=object as T.Mesh;
    if(mesh.isMesh&&!Array.isArray(mesh.material)&&(mesh.material as T.MeshStandardMaterial).isMeshStandardMaterial&&!mesh.material.transparent) {
      const metal=mesh.material as T.MeshStandardMaterial;
      if(tinted.has(metal))return;
      tinted.add(metal);
      const {r,g,b}=metal.color,light=r*.2126+g*.7152+b*.0722;
      metal.color.lerp(tint,light>.24?.35:light>.065?.19:.09);
    }
  });
  const effects=createDriftEffects(T),marker=makeBeacon();shell.root.add(marker);
  let motion=playback.sample(), cockpit=false, lastDetailed=-1;

  function syncCockpit() {
    const finish=Math.min(reference.frames.length-1,Math.round(playback.time*60));
    const first=Math.max(0,finish-35),initial=reference.frames[first];
    car.userData.resetDriver(initial.state.gear);
    for(let i=first;i<=finish;i+=3)car.userData.tick(.05,reference.frames[i].state);
    lastDetailed=playback.time;
  }
  function setCockpit(enabled:boolean) {
    if(enabled===cockpit)return;
    cockpit=enabled;car.userData.setCockpitView(enabled,true);
    if(enabled)syncCockpit();
  }
  function place(watching:boolean) {
    motion=playback.sample();car.position.set(motion.x,0,motion.z);car.rotation.y=motion.yaw;
    if(!watching)shell.paint(motion);
  }
  function seek(time:number,watching=false) {
    playback.seek(time);effects.reset();place(watching);
    lastDetailed=playback.time;
    if(cockpit)syncCockpit();
    if(watching)car.userData.tick(.035,motion);
  }
  function move(time:number,watching:boolean) {
    const before=playback.time;
    if(time<=before)return false;
    playback.seek(time);
    if(playback.time<=before)return false;
    place(watching);
    if(watching) effects.step(Math.min(playback.time-before,.041),motion);
    return true;
  }
  function paintDetail(dt:number) {
    const delta=playback.time-lastDetailed;
    if(delta>.0001) {car.userData.tick(Math.min(delta,.065),motion);lastDetailed=playback.time;}
    else if(lastDetailed<0) {car.userData.tick(Math.max(.001,dt),motion);lastDetailed=playback.time;}
  }
  function display(follow:boolean,detail:boolean,light:boolean) {
    car.visible=detail;
    shell.root.visible=follow||light;
    if(!shell.root.visible)return;
    marker.visible=follow;shell.setTranslucent(follow);
    if(light)shell.paint(motion);
  }
  car.visible=false;shell.root.visible=false;effects.root.visible=false;trail.mesh.visible=false;
  return {reference,playback,car,shell:shell.root,effects,trail,setCockpit,seek,move,paintDetail,display,get motion(){return motion;}};
}