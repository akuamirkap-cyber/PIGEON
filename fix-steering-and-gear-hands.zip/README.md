# Rally Lab Drift

Adaptasi game asli dari ZIP [`akuamirkap-cyber/PIGEON`](https://github.com/akuamirkap-cyber/PIGEON/blob/main/halo%20(2).zip). Mobil Group B, rig tangan, dan garasi 3D tetap digunakan. Sirkuit Pinus memakai pengendalian drift RWD dengan transmisi otomatis dan HUD layar penuh.

## Menjalankan

1. Jalankan `npm install`.
2. Jalankan `npm run dev` dan buka alamat yang ditampilkan Vite. Browser memerlukan WebGL.
3. Tahan `W` untuk gas, `S` untuk rem atau mundur setelah berhenti, `A` / `D` untuk belok, dan `Spasi` untuk rem tangan. Gigi berpindah otomatis saat mobil melaju. Ponsel bisa menggunakan kontrol sentuh. Gamepad dengan pemetaan standar memakai stik kiri, RT, LT, dan tombol bawah untuk rem tangan.
4. Tekan `C` untuk mengganti kamera belakang, atas, kokpit, atau bemper. `B` langsung mengganti ke kamera bemper. `E` membuka inspeksi persneling, `R` mengulang lintasan, `P` menjeda, dan `M` mengatur suara. Garasi dan bantuan drift tersedia dari menu jeda.

## Ghost AI

- Klik **Ghost AI** untuk menempatkan mobil pembanding beberapa meter di depan, tanpa tabrakan dengan mobil pemain. Saat memulai sesi, Ghost mulai bergerak ketika pemain mulai melaju.
- Klik **Kamera Ghost** atau tekan `G` untuk belajar dari sudut belakang, atas, atau kokpit dengan `C`. Posisi, waktu, dan skor pemain tidak ikut berubah selama menonton.
- Lihat input gas, rem kaki, rem tangan, arah setir, dan sudut drift. Jejak hijau menunjukkan akselerasi, jingga pengereman, dan emas bagian yang benar-benar mendapat bonus. Klik tanda emas pada timeline untuk langsung melihat cara Ghost masuk zona tersebut. Tekan `Spasi` untuk menjeda demo atau pilih `0,5x`. `R` memutar ulang demo saat kamera Ghost dipilih.
- **Acuan Ghost** menampilkan target waktu putaran. Ketika membuntuti Ghost, selisih waktunya dihitung di jarak lintasan yang sama. **Bonus tersimpan** hanya menghitung poin tambahan dari zona luar pada kombo yang berhasil disimpan.

Pilot AI menggunakan profil pengereman berdasarkan kelengkungan jalan, persiapan di sisi luar tikungan, dan input yang disetel terhadap waktu putaran, jarak saat mendapat bonus, serta risiko benturan. Putaran acuan 39,45 detik memakai setelan kualifikasi tetap. Ghost tidak menunggu pembaruan angka HUD: posisi dan putaran ban diinterpolasi untuk setiap frame, dan model pendamping menggunakan geometri yang digabung untuk mengurangi beban render.

## Drift Attack

Mode awal adalah satu putaran Drift Attack. Skor didapat dari sudut, kecepatan, dan kelanjutan garis drift. Cat marka hijau menandai zona luar dengan bonus 48%. Arah slide yang berganti dengan bersih menyambung kombo. Benturan atau spin membuat poin kombo yang belum tersimpan hilang. Rekor putaran disimpan lokal; latihan tanpa batas tersedia di menu jeda.

Di tikungan pertama, masuk sekitar 55-65 km/j dan ketuk rem tangan sambil belok kanan. Lepas rem tangan lalu atur gas. Kalau garis melebar, lepas `W` sebentar tanpa mengerem. Koreksi arah lawan sebentar untuk lurus, atau tahan lebih lama untuk menyambung drift. **Bantuan Nyaman** memperlebar jendela masuk drift dan menstabilkan sudut; **Pro** mematikan koreksi itu.

Mobil pemain tetap matic. Gas naik dan turun secara bertahap, dan saat lepas gas transmisi mengurangi hambatan mesin sehingga mobil tetap meluncur. HUD menampilkan bukaan gas, lalu **Meluncur** ketika tidak ada input pedal dan tenaga sudah turun. `S` dan rem tangan tetap memotong tenaga dengan cepat; tabrakan keras tetap mengurangi kecepatan dan poin. Kecepatan dan skor tidak digandakan, dan acuan Ghost tidak ikut berubah.

## Gerakan mobil

`src/drift-physics.js` menghitung momentum, distribusi beban, sudut slip, grip longitudinal/lateral, dan kecepatan sudut masing-masing ban pada timestep tetap 120 Hz. Mobil tidak diarahkan mengikuti jalur; lintasan menyediakan permukaan, batas, dan waktu putaran. Model ini disetel sebagai simcade untuk input digital, bukan simulasi kendaraan yang dikalibrasi ke mobil sungguhan.

Speedometer membaca kecepatan dunia: 100 km/j setara dengan sekitar 27,8 meter per detik. Reflektor menunjukkan jarak tetap di lintasan, kamera belakang lebih dekat ke aspal, dan kamera bemper berada sekitar 60 cm dari permukaan. Efek kabur di pinggir pada kamera belakang dan bemper mengikuti arah serta laju gerak, bukan animasi garis acak; efek kabur dilewati bila render tidak cukup lancar. **Efek laju** di menu jeda mematikan pelebaran kamera dan efek kabur. Fisika, catatan waktu, dan skor tidak ikut berubah.

## Verifikasi

Jalankan `node --test tests/*.test.mjs` untuk menguji putaran Ghost, putar ulang, tempo simulasi, fisika drift, sambungan, skor, gigi otomatis, putaran roda, dan kontak tangan. `npm run build` membuat build produksi.