import { ReactNode, useEffect, useRef, useState } from 'react';
import { Game, LEVELS, Ui } from './game/engine';
import { Duel, DuelUi } from './game/duel';
import { STORY_CHAPTERS, Story, StoryMode, StoryUi, WAR_CHAPTERS_N } from './game/story';
import { setMuted } from './game/sfx';
import RagdollArcher from './RagdollArcher';

type Mode = 'menu' | 'levels' | 'misi' | 'duel' | 'story' | 'perang' | 'ragdoll';

const HINTS: Record<Ui['stage'], string> = {
  idle: 'Klik / tap di mana saja untuk mengambil busur',
  busy: 'Menyiapkan anak panah…',
  ready: 'Tekan, tarik ke belakang untuk membidik, lalu lepas untuk menembak',
  aiming: 'Makin jauh ditarik makin kencang — lepas untuk menembak!',
  flying: '', win: '', lose: '', out: '',
};

/** what the "lost" card says, depending on what ended the round */
const FAIL: Record<string, [string, string]> = {
  man: ['Waduh, kena orangnya!', 'Sasarannya apel, bukan orangnya. Perhatikan garis lintasan saat membidik.'],
  plate: ['Kena piring!', 'Pecahkan piringnya sebelum sampai ke kamu. Makin dekat makin mudah dibidik, tapi makin berbahaya.'],
  shot: ['Dia lebih cepat!', 'Kenai dia sebelum garis merah di atas kepalanya penuh.'],
  duck: ['Kena bebek!', 'Bebeknya tidak apa-apa, cuma kaget. Tunggu celah di antara mereka, atau lambungkan panah di atasnya.'],
  fly: ['Pak Bejo terbang ke langit!', 'Letuskan balonnya supaya dia turun — atau panah apelnya lebih cepat.'],
  ufo: ['Apelnya diculik alien!', 'Panah apelnya selagi masih melayang di dalam sinar.'],
  boss: ['Diseruduk Raja Apel!', 'Tembak secepat mungkin: setiap panah mendorongnya mundur. Kamu juga boleh mundur.'],
  time: ['Waktu habis!', 'Lebih cepat lagi! Siapkan bidikan selagi sasaran berikutnya muncul.'],
  self: ['Kena panah sendiri!', 'Panah yang masuk portal oranye keluar lagi dari portal biru, ke arahmu.'],
  drop: ['Bolanya jatuh!', 'Panah bolanya lagi sebelum menyentuh tanah. Bidik sedikit di bawah bola yang sedang turun.'],
  clash: ['Tabrakan!', 'Panahmu mengenai panah yang sudah menancap. Tunggu celah kosong di roda lewat di depanmu.'],
  mob: ['Diserbu apel mini!', 'Dahulukan yang paling dekat, dan bidik rendah — mereka kecil dan melompat-lompat.'],
  bite: ['Digigit zombie!', 'Bidik titik vital (KEPALA atau JANTUNG yang menyala di dada). Panah kaki untuk membuatnya pincang dan melambat!'],
  curse: ['Kena bola kutukan!', 'Panah bola kutukan Raja Zombie di udara supaya pecah, atau maju/mundur untuk menghindar!'],
  wrong: ['Salah!', 'Urutan atau pilihannya keliru. Perhatikan baik-baik sebelum melepas panah.'],
  bust: ['Kelebihan!', 'Skornya harus tepat 20. Hitung dulu ring mana yang masih kamu butuhkan.'],
  bomb: ['Ledakan fatal!', 'Hati-hati dengan meriam/roket atau ledakan bom! Kamu bisa memanah peluru meriam/roket di udara.'],
  red: ['Terdeteksi laser boneka!', 'Jangan melepas panah atau bergerak saat lampu merah menyala!'],
  burn: ['Panahnya gosong!', 'Panahmu menyentuh tali api. Lepas panah saat tali sedang di bawah kaki Pak Bejo atau jauh di atas kepalanya.'],
  dragon: ['Naganya marah!', 'Jangan kena kepala barongsai. Apelnya ada di BUNTUT — bidik ujung ekor saat naga melintas.'],
  bubble: ['Kena gelembung kepiting!', 'Pecahkan gelembung yang meluncur ke arahmu dengan panah, lalu balas tembak matanya.'],
  chicken: ['Kena ayamnya!', 'Petok! Ayamnya cuma kaget. Bidik telurnya yang sedang jatuh, bukan si ayam.'],
  cat: ['Apelnya dicuri kucing!', 'Kucing oren berhenti tiap kamu membidik. Tarik busur cepat dan tembak apelnya sebelum dia sampai.'],
  catHit: ['Kasihan kucingnya!', 'Jangan panah kucingnya — dia cuma lapar. Panah apel Pak Bejo saja.'],
  duck2: ['Ditabrak bebek raksasa!', 'Tembak apelnya sebelum bebeknya sampai. Mengenai bebek malah membuatnya makin ngebut.'],
};

interface Section { title: string; from: number; to: number; color: string; note: string }
const SECTIONS: Section[] = [
  { title: 'DASAR', from: 1, to: 16, color: 'text-neutral-500', note: 'belajar tarik, bidik, lepas' },
  { title: 'LABORATORIUM', from: 17, to: 30, color: 'text-violet-600', note: 'gravitasi, portal, magnet' },
  { title: 'MINIGAME', from: 31, to: 44, color: 'text-amber-600', note: 'permainan kecil beraturan khusus' },
  { title: 'BARU & SEGAR', from: 45, to: 60, color: 'text-blue-600', note: 'brankas waktu, meriam sirkus, naga barongsai…' },
  { title: 'SPESIAL & ZOMBIE', from: 61, to: 74, color: 'text-red-500', note: 'pemanah berubah wujud, zombie ragdoll' },
  { title: 'ABSURD', from: 75, to: 84, color: 'text-pink-600', note: 'ayam emas, kentut roket, hujan Pak Bejo' },
];

const STORE = 'perfectshot.cleared';
const blankUi = (level: number): Ui => ({
  stage: 'idle', level, arrows: LEVELS[level].arrows, total: LEVELS[level].arrows, shots: 0, stars: 3, canMove: false,
  why: '', goals: [],
});
const blankDuel: DuelUi = { stage: 'intro', you: 0, bot: 0, time: 60, result: null };
const blankStory = (mode: StoryMode): StoryUi => ({ stage: 'intro', chapter: 1, chapters: mode === 'war' ? WAR_CHAPTERS_N : STORY_CHAPTERS, hp: 100, maxHp: 100, kills: 0, left: 1, score: 0, best: 0, title: '', mode });

function loadCleared(): number[] {
  try {
    const arr: unknown = JSON.parse(localStorage.getItem(STORE) ?? '[]');
    return Array.isArray(arr) ? arr.filter((n): n is number => Number.isInteger(n) && n >= 0 && n < LEVELS.length) : [];
  } catch {
    return [];
  }
}

function Levels({ cleared, onLevel, onBack }: { cleared: number[]; onLevel: (i: number) => void; onBack: () => void }) {
  return (
    <div className="absolute inset-0 z-20 overflow-y-auto bg-white text-neutral-900">
      <div className="mx-auto w-full max-w-3xl px-5 py-8 sm:px-8">
        <div className="menu-in">
          <div className="flex items-center justify-between">
            <button onClick={onBack} className="rounded-lg bg-neutral-100 px-3 py-1.5 text-[11px] font-black tracking-[0.14em] text-neutral-600 hover:bg-neutral-200">← MENU</button>
            <div className="text-sm font-bold text-neutral-400">{cleared.length}/{LEVELS.length} selesai</div>
          </div>
          <h2 className="mt-5 text-4xl font-black lowercase tracking-tight">pilih level<span className="text-red-500">.</span></h2>
          <p className="mt-1 text-sm font-medium text-neutral-400">Semua {LEVELS.length} level bisa dimainkan kapan saja.</p>
          {SECTIONS.map((s) => (
            <section key={s.title} className="mt-8">
              <div className="flex items-baseline justify-between">
                <div className={`text-[11px] font-black tracking-[0.22em] ${s.color}`}>{s.title} · {s.from}–{s.to}</div>
                <div className="text-xs font-medium text-neutral-400">{s.note}</div>
              </div>
              <div className="mt-3 grid grid-cols-1 gap-1.5 sm:grid-cols-2 md:grid-cols-3">
                {LEVELS.slice(s.from - 1, s.to).map((l) => {
                  const i = l.id - 1;
                  const done = cleared.includes(i);
                  return (
                    <button
                      key={l.id}
                      onClick={() => onLevel(i)}
                      title={l.brief}
                      className={`flex items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-bold transition active:scale-95 ${
                        done ? 'bg-neutral-900 text-white hover:bg-red-500' : 'bg-neutral-100 text-neutral-900 ring-1 ring-inset ring-neutral-200 hover:bg-red-50 hover:text-red-600'
                      }`}
                    >
                      <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-black ${done ? 'bg-white/20 text-white' : 'bg-neutral-900 text-white'}`}>{l.id}</span>
                      <span className="truncate">{l.name}</span>
                      {done && <span className="ml-auto text-green-400">✓</span>}
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}

function ArrowIcon({ used }: { used: boolean }) {
  return (
    <svg viewBox="0 0 12 40" className={`h-8 w-2.5 transition-all duration-300 sm:h-9 sm:w-3 ${used ? 'opacity-15' : ''}`}>
      <path d="M6 1 L9 10 L3 10 Z" fill="#9aa3ad" />
      <rect x="5" y="9" width="2" height="26" fill="#25272d" />
      <path d="M6 24 Q1 27 1.5 33 L6 37 Z" fill="#fb923c" />
      <path d="M6 24 Q11 27 10.5 33 L6 37 Z" fill="#ea6a12" />
    </svg>
  );
}

function Star({ on, delay }: { on: boolean; delay: number }) {
  return (
    <svg viewBox="0 0 48 48" className="star-pop h-14 w-14 sm:h-16 sm:w-16" style={{ animationDelay: `${delay}ms` }}>
      <path d="M24 3.5l6.2 13.1 14.3 1.9-10.5 10 2.7 14.2L24 35.8 11.3 42.7 14 28.5 3.5 18.5l14.3-1.9z" fill={on ? '#ffc933' : '#eceef1'} />
    </svg>
  );
}

/** press-and-hold control (walk, crouch) or a tap (flip) */
function Pad({ title, on, off, children }: { title: string; on: () => void; off?: () => void; children: ReactNode }) {
  return (
    <button
      aria-label={title}
      title={title}
      onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); on(); }}
      onPointerUp={off}
      onPointerCancel={off}
      onLostPointerCapture={off}
      onContextMenu={(e) => e.preventDefault()}
      className="grid h-12 min-w-12 touch-none place-items-center rounded-2xl bg-neutral-900 px-3 text-[11px] font-black tracking-wider text-white transition active:scale-90 active:bg-red-500"
    >
      {children}
    </button>
  );
}

const btn = 'grid h-10 w-10 place-items-center rounded-xl bg-neutral-100 text-neutral-900 transition hover:bg-neutral-200 active:scale-95';
const chip = (on: boolean) =>
  `flex h-7 items-center gap-1 rounded-lg px-2.5 text-[11px] font-black tracking-[0.14em] transition active:scale-95 ${
    on ? 'bg-neutral-900 text-white' : 'bg-neutral-100 text-neutral-500 hover:bg-neutral-200'
  }`;
const big = (primary: boolean) =>
  `w-full rounded-2xl px-5 py-3 text-base font-black tracking-wide transition active:scale-[0.98] ${
    primary ? 'bg-red-500 text-white hover:bg-red-600' : 'bg-neutral-100 text-neutral-900 hover:bg-neutral-200'
  }`;

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const duelRef = useRef<Duel | null>(null);
  const storyRef = useRef<Story | null>(null);
  const startRef = useRef(0);
  const [mode, setMode] = useState<Mode>('menu');
  const [ui, setUi] = useState<Ui>(() => blankUi(0));
  const [du, setDu] = useState<DuelUi>(blankDuel);
  const [st, setSt] = useState<StoryUi>(() => blankStory('sky'));
  const [mute, setMute] = useState(false);
  const [cine, setCine] = useState(true);
  const cineRef = useRef(cine);
  const [cleared, setCleared] = useState<number[]>(loadCleared);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c || mode === 'menu' || mode === 'levels' || mode === 'ragdoll') return;
    if (mode === 'misi') {
      const g = new Game(c, setUi);
      g.setCine(cineRef.current);
      g.setLevel(startRef.current);
      gameRef.current = g;
      return () => { g.destroy(); gameRef.current = null; };
    }
    if (mode === 'story' || mode === 'perang') {
      const s = new Story(c, setSt, mode === 'perang' ? 'war' : 'sky');
      s.setCine(cineRef.current);
      storyRef.current = s;
      return () => { s.destroy(); storyRef.current = null; };
    }
    const d = new Duel(c, setDu);
    d.setCine(cineRef.current);
    duelRef.current = d;
    return () => { d.destroy(); duelRef.current = null; };
  }, [mode]);

  useEffect(() => { setMuted(mute); }, [mute]);
  useEffect(() => {
    cineRef.current = cine;
    gameRef.current?.setCine(cine);
    duelRef.current?.setCine(cine);
    storyRef.current?.setCine(cine);
  }, [cine]);
  useEffect(() => {
    if (ui.stage !== 'win') return;
    setCleared((c) => {
      if (c.includes(ui.level)) return c;
      const next = [...c, ui.level];
      try {
        localStorage.setItem(STORE, JSON.stringify(next));
      } catch {
        /* storage unavailable: progress simply is not kept */
      }
      return next;
    });
  }, [ui.stage, ui.level]);

  const duel = mode === 'duel';
  const story = mode === 'story' || mode === 'perang';
  const war = mode === 'perang';
  const misi = mode === 'misi';
  const playLevel = (i: number) => { startRef.current = i; setUi(blankUi(i)); setMode('misi'); };
  const playDuel = () => { setDu(blankDuel); setMode('duel'); };
  const playStory = () => { setSt(blankStory('sky')); setMode('story'); };
  const playWar = () => { setSt(blankStory('war')); setMode('perang'); };
  const toMenu = () => setMode('menu');
  const restart = () => (duel ? duelRef.current?.reset() : story ? storyRef.current?.reset() : gameRef.current?.reset());
  const goLevel = (i: number) => gameRef.current?.setLevel(i);
  const move = (dir: number) => (duel ? duelRef.current?.setMove(dir) : story ? storyRef.current?.setMove(dir) : gameRef.current?.setMove(dir));
  const def = LEVELS[ui.level];
  const done =
    misi ? ui.stage === 'win' || ui.stage === 'lose' || ui.stage === 'out'
    : duel ? du.stage === 'over'
    : story ? st.stage === 'over' || st.stage === 'won'
    : false;
  const hasNext = ui.level < LEVELS.length - 1;
  const canMove = duel ? du.stage === 'play' : story ? st.stage === 'play' || st.stage === 'clear' : ui.canMove;
  const fail = FAIL[ui.why] ?? FAIL.man;
  const hint = duel
    ? du.stage === 'intro' ? 'Klik / tap untuk mulai — 60 detik, panah terbanyak di KEPALA & DADA lawan menang' : ''
    : story
      ? st.stage === 'intro' ? `${war ? 'Gelombang' : 'Bab'} ${st.chapter}: ${st.title} — klik / tap untuk mulai. ${war ? 'Bertahanlah — naik ke batu melayang dengan salto!' : 'Tumbangkan semua pemanah di pijakan langit!'}` : st.stage === 'clear' ? `${war ? 'Gelombang' : 'Bab'} selesai! Bersiap ke berikutnya…` : ''
      : HINTS[ui.stage];
  const hpPct = Math.round((st.hp / st.maxHp) * 100);

  return (
    <div className="relative h-full w-full overflow-hidden bg-white font-sans text-neutral-900 select-none">
      <canvas
        ref={canvasRef}
        onContextMenu={(e) => e.preventDefault()}
        aria-label="Arena memanah"
        className="absolute inset-0 h-full w-full touch-none cursor-crosshair"
      />

      {/* navigation + mission */}
      <div className="pointer-events-none absolute left-3 top-3 max-w-[58%] sm:left-6 sm:top-5 sm:max-w-md">
        <div className="pointer-events-auto flex flex-wrap items-center gap-1.5">
          <button onClick={toMenu} className={chip(false)} title="Kembali ke menu">← MENU</button>
          {misi && (
            <>
              <button onClick={() => setMode('levels')} className={chip(false)} title="Pilih level">LEVEL</button>
              <button onClick={() => goLevel(ui.level - 1)} disabled={ui.level === 0} aria-label="Level sebelumnya" title="Level sebelumnya" className={`${chip(false)} disabled:opacity-30`}>‹</button>
              <span className={chip(true)}>
                {def.id}
                {cleared.includes(ui.level) && <span className="text-green-400">✓</span>}
              </span>
              <button onClick={() => goLevel(ui.level + 1)} disabled={!hasNext} aria-label="Level berikutnya" title="Level berikutnya" className={`${chip(false)} disabled:opacity-30`}>›</button>
            </>
          )}
          {story && <span className={chip(true)}>{war ? 'GEL.' : 'BAB'} {st.chapter}/{st.chapters}</span>}
        </div>
        <h1 className="mt-2 text-xl font-black leading-tight tracking-tight sm:text-3xl">
          {duel ? 'Duel lawan bot' : story ? st.title || (war ? 'Perang' : 'Story') : def.name}
          <span className="text-red-500">.</span>
        </h1>
        <p className="text-xs font-semibold text-neutral-500 sm:text-sm">
          {duel
            ? 'Siapa paling banyak menancapkan panah di titik vital (kepala & dada) dalam 60 detik, dia menang. Pakai barikade kayu untuk berlindung.'
            : story
              ? war ? 'Bertahan hidup! Tentara pemanah berbaris dari kanan dan muncul di batu melayang, prajurit pedang berlari menyerbu. Salto (W/spasi) untuk naik ke batu, nunduk (S) di atas batu untuk turun.' : 'Kamu berdiri di pijakan langit. Pemanah musuh muncul di pijakan lain dan membalas tembakanmu — nunduk atau salto untuk menghindar.'
              : def.brief}
        </p>
        {misi && (
          <ul className="mt-2 flex flex-wrap gap-1.5">
            {ui.goals.map((g) => (
              <li key={g.label} className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ${g.done ? 'bg-green-100 text-green-700' : 'bg-red-50 text-red-600'}`}>
                <span className={`grid h-3.5 w-3.5 place-items-center rounded-full text-[9px] text-white ${g.done ? 'bg-green-500' : 'bg-red-400'}`}>{g.done ? '✓' : ''}</span>
                {g.label}
              </li>
            ))}
          </ul>
        )}
        {story && (
          <div className="mt-2 w-56 max-w-full">
            <div className="flex items-center justify-between text-[10px] font-black tracking-[0.18em] text-neutral-400">
              <span>NYAWA</span><span className={hpPct <= 30 ? 'text-red-500' : ''}>{st.hp}/{st.maxHp}</span>
            </div>
            <div className="mt-1 h-2.5 overflow-hidden rounded-full bg-neutral-200">
              <div className={`h-full rounded-full transition-all duration-300 ${hpPct <= 30 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: `${hpPct}%` }} />
            </div>
          </div>
        )}
      </div>

      {/* duel scoreboard */}
      {duel && (
        <div className="pointer-events-none absolute left-1/2 top-3 flex -translate-x-1/2 items-center gap-3 rounded-2xl bg-neutral-900 px-4 py-2 text-white sm:top-5">
          <div className="text-center">
            <div className="text-[10px] font-black tracking-[0.18em] text-red-400">KAMU</div>
            <div className="text-2xl font-black leading-none tabular-nums">{du.you}</div>
          </div>
          <div className={`rounded-lg px-2 py-1 text-lg font-black tabular-nums ${du.time <= 10 ? 'bg-red-500' : 'bg-white/10'}`}>
            {Math.floor(du.time / 60)}:{String(du.time % 60).padStart(2, '0')}
          </div>
          <div className="text-center">
            <div className="text-[10px] font-black tracking-[0.18em] text-violet-400">BOT</div>
            <div className="text-2xl font-black leading-none tabular-nums">{du.bot}</div>
          </div>
        </div>
      )}

      {/* story scoreboard */}
      {story && (
        <div className="pointer-events-none absolute left-1/2 top-3 flex -translate-x-1/2 items-center gap-3 rounded-2xl bg-neutral-900 px-4 py-2 text-white sm:top-5">
          <div className="text-center">
            <div className="text-[10px] font-black tracking-[0.18em] text-red-400">MUSUH</div>
            <div className="text-2xl font-black leading-none tabular-nums">{st.left}</div>
          </div>
          <div className="text-center">
            <div className="text-[10px] font-black tracking-[0.18em] text-amber-300">SKOR</div>
            <div className="text-2xl font-black leading-none tabular-nums">{st.score}</div>
          </div>
          <div className="text-center">
            <div className="text-[10px] font-black tracking-[0.18em] text-neutral-400">TUMBANG</div>
            <div className="text-2xl font-black leading-none tabular-nums">{st.kills}</div>
          </div>
        </div>
      )}

      {/* quiver + controls */}
      <div className="absolute right-3 top-3 flex items-start gap-2 sm:right-6 sm:top-5">
        {misi && (
          <div className="pointer-events-none rounded-2xl bg-neutral-100 px-3 py-2">
            <div className="text-[10px] font-black tracking-[0.18em] text-neutral-400">ANAK PANAH</div>
            <div className="mt-1 flex items-end gap-1.5">
              {Array.from({ length: ui.total }, (_, i) => <ArrowIcon key={i} used={i >= ui.arrows} />)}
            </div>
          </div>
        )}
        <div className="flex flex-col gap-2">
          <button onClick={restart} aria-label="Ulangi" title="Ulangi" className={btn}>
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12a9 9 0 1 0 3-6.7" /><path d="M3 4v5h5" />
            </svg>
          </button>
          <button onClick={() => setMute((m) => !m)} aria-label={mute ? 'Nyalakan suara' : 'Matikan suara'} title={mute ? 'Nyalakan suara' : 'Matikan suara'} className={btn}>
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 9v6h4l5 4V5L8 9z" fill="currentColor" />
              {mute ? <path d="M17 9l5 6M22 9l-5 6" /> : <path d="M17 8.5a5 5 0 0 1 0 7M19.5 6a8.5 8.5 0 0 1 0 12" />}
            </svg>
          </button>
          <button
            onClick={() => setCine((c) => !c)}
            aria-pressed={cine}
            aria-label="Zoom dan slow motion"
            title={cine ? 'Zoom & slow-mo: NYALA (klik untuk mematikan)' : 'Zoom & slow-mo: MATI (klik untuk menyalakan)'}
            className={`${btn} text-[9px] font-black leading-none ${cine ? '' : 'text-neutral-400'}`}
          >
            SLOW
            <br />
            {cine ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* movement */}
      <div className={`absolute bottom-3 left-3 flex items-center gap-2 transition-opacity duration-300 sm:bottom-6 sm:left-6 ${canMove ? 'opacity-100' : 'pointer-events-none opacity-25'}`}>
        <Pad title="Mundur / kiri (A)" on={() => move(-1)} off={() => move(0)}>◀</Pad>
        <Pad title="Maju / kanan (D)" on={() => move(1)} off={() => move(0)}>▶</Pad>
        {(duel || story) && <Pad title="Nunduk (S) — tahan" on={() => (duel ? duelRef.current : storyRef.current)?.setCrouch(true)} off={() => (duel ? duelRef.current : storyRef.current)?.setCrouch(false)}>NUNDUK</Pad>}
        {(duel || story) && <Pad title="Salto (W / spasi)" on={() => (duel ? duelRef.current : storyRef.current)?.flip()}>SALTO</Pad>}
        <span className="hidden text-[11px] font-bold text-neutral-400 lg:block">
          {war ? 'A·D lari  ·  S nunduk / turun dari batu  ·  W / spasi salto (naik batu)' : duel || story ? 'A·D lari  ·  S nunduk  ·  W / spasi salto' : 'A·D mundur / maju'}
        </span>
      </div>

      {/* contextual hint */}
      <div className="pointer-events-none absolute inset-x-0 bottom-[4.75rem] flex justify-center px-4 sm:bottom-7 sm:px-40 lg:px-[26rem]">
        <div key={hint} className={`hint-in rounded-full bg-neutral-900 px-4 py-2 text-center text-xs font-bold text-white sm:text-sm ${hint ? '' : 'hidden'}`}>
          {hint}
        </div>
      </div>

      {/* result */}
      {done && (
        <div className="absolute inset-0 z-10 grid place-items-center bg-white/70 p-4 backdrop-blur-[2px]">
          <div className="card-in w-full max-w-sm rounded-3xl bg-white p-6 text-center shadow-[0_24px_70px_-20px_rgba(15,23,42,0.45)] ring-1 ring-neutral-200 sm:p-8">
            {duel ? (
              <>
                <div className={`text-[11px] font-black tracking-[0.22em] ${du.result === 'win' ? 'text-green-600' : du.result === 'lose' ? 'text-red-500' : 'text-amber-500'}`}>
                  WAKTU HABIS
                </div>
                <h2 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">
                  {du.result === 'win' ? 'Kamu menang!' : du.result === 'lose' ? 'Bot menang' : 'Seri!'}
                </h2>
                <p className="mt-3 text-5xl font-black tabular-nums">
                  <span className="text-red-500">{du.you}</span>
                  <span className="mx-2 text-neutral-300">–</span>
                  <span className="text-violet-600">{du.bot}</span>
                </p>
                <p className="mt-2 text-sm font-semibold text-neutral-500">Jumlah panah yang menancap di kepala & dada.</p>
              </>
            ) : story ? (
              <>
                <div className={`text-[11px] font-black tracking-[0.22em] ${st.stage === 'won' ? 'text-green-600' : 'text-red-500'}`}>
                  {st.stage === 'won' ? (war ? 'SEMUA GELOMBANG DITAHAN' : 'SEMUA BAB TAMAT') : `GUGUR DI ${war ? 'GELOMBANG' : 'BAB'} ${st.chapter}`}
                </div>
                <h2 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">{st.stage === 'won' ? (war ? 'Pahlawan lapangan!' : 'Penguasa langit!') : 'Kamu tertembak'}</h2>
                <p className="mt-3 text-5xl font-black tabular-nums text-amber-500">{st.score}</p>
                <p className="mt-2 text-sm font-semibold text-neutral-500">
                  {st.kills} pemanah tumbang · skor terbaik {Math.max(st.best, st.score)}
                </p>
              </>
            ) : ui.stage === 'win' ? (
              <>
                <div className="text-[11px] font-black tracking-[0.22em] text-green-600">LEVEL {def.id} SELESAI</div>
                <h2 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">Tepat sasaran!</h2>
                <div className="mt-4 flex justify-center gap-1">
                  {[0, 1, 2].map((i) => <Star key={i} on={i < ui.stars} delay={150 + i * 160} />)}
                </div>
                <p className="mt-3 text-sm font-semibold text-neutral-500">
                  Selesai dengan {ui.shots} anak panah.{!hasNext && ' Semua level tamat — kamu resmi perfectshot!'}
                </p>
              </>
            ) : ui.stage === 'lose' ? (
              <>
                <div className="text-[11px] font-black tracking-[0.22em] text-red-500">GAGAL</div>
                <h2 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">{fail[0]}</h2>
                <p className="mt-3 text-sm font-semibold text-neutral-500">{fail[1]}</p>
              </>
            ) : (
              <>
                <div className="text-[11px] font-black tracking-[0.22em] text-amber-500">PANAH HABIS</div>
                <h2 className="mt-1 text-3xl font-black tracking-tight sm:text-4xl">Belum selesai</h2>
                <p className="mt-3 text-sm font-semibold text-neutral-500">Coba maju atau mundur untuk mencari sudut tembak yang lebih enak.</p>
              </>
            )}
            <div className="mt-6 flex flex-col gap-2">
              {misi && ui.stage === 'win' && hasNext && (
                <button onClick={() => goLevel(ui.level + 1)} className={big(true)}>LEVEL {def.id + 1} →</button>
              )}
              {story && st.stage === 'over' && (
                <button onClick={() => storyRef.current?.retry()} className={big(true)}>ULANGI {war ? 'GELOMBANG' : 'BAB'} {st.chapter}</button>
              )}
              <button onClick={restart} className={big(duel || (story && st.stage === 'won') || !(misi && ui.stage === 'win' && hasNext))}>
                {duel ? 'DUEL LAGI' : story ? (war ? 'MULAI DARI GELOMBANG 1' : 'MULAI DARI BAB 1') : ui.stage === 'win' ? 'MAIN LAGI' : 'COBA LAGI'}
              </button>
              <button onClick={toMenu} className="mt-1 py-1 text-sm font-bold text-neutral-400 transition hover:text-neutral-900">
                menu
              </button>
            </div>
          </div>
        </div>
      )}

      {(mode === 'menu' || mode === 'ragdoll') && (
        <RagdollArcher
          title={mode === 'menu'}
          onStart={() => setMode('ragdoll')}
          onExit={toMenu}
          mute={mute}
          onMute={() => setMute((m) => !m)}
          cleared={cleared.length}
          levels={LEVELS.length}
          onPlay={() => { const next = LEVELS.findIndex((_, i) => !cleared.includes(i)); playLevel(next < 0 ? 0 : next); }}
          onLevels={() => setMode('levels')}
          onStory={playStory}
          onWar={playWar}
          onDuel={playDuel}
        />
      )}
      {mode === 'levels' && <Levels cleared={cleared} onLevel={playLevel} onBack={toMenu} />}
    </div>
  );
}
