// "Ragdoll Archer" mode. Black stickmen on floating grounds, drag-back-and-release archery, and every body
// is a live ragdoll: drawing leans it back, the release kicks it, a hit staggers it, a kill lets it crumple.
// Each level adds grounds and enemies. RagWorld is DOM-free (it is fed a size, a clock and pointer events,
// and paints into any 2D context); RagdollGame at the bottom wires it to a real canvas.
// The same world also runs behind the title screen as a self-playing demo.
import { Ctx, V, v, add, mul, dist, clamp, damp, ease, fromAngle, lerpV, segDist } from '../util';
import { ArcherRag, RAG_STICKS, punchRag } from '../archerRag';
import { ambStart, ambStop, ambTick, audioDuck, audioInit, snd } from './audio';
import { ARROW_LEN, HEAD_R, Slab2, Stick, StickLook, angLerp, drawArrow, drawAxe, drawBow, drawSkeleton, drawStick, fireAngle, impulse, makeStick, onString, startReact, stepStick, woundPoint } from './stick';
import { CanvasLike, MakeCanvas, Scene, THEMES, Theme, glowSprite, paintScene } from './scenery';

const H = 1 / 120;
const AG = 980; // gravity on arrows
const speedOf = (pull: number) => 430 + 800 * pull;
const rand = Math.random;
const gauss = () => (rand() + rand() + rand() - 1.5) * 1.15;
const FONT = '"Russo One","Arial Black","Segoe UI Black",system-ui,sans-serif';
const BEST_KEY = 'perfectshot.ragdoll.best';

export type UpId = 'hp' | 'dmg' | 'multi' | 'leech';
export const UP_MAX: Record<UpId, number> = { hp: 8, dmg: 8, multi: 2, leech: 5 };
export interface RUi {
  stage: 'play' | 'clear' | 'shop' | 'dying' | 'dead';
  demo: boolean; level: number; kills: number; total: number; grounds: number; coins: number; shown: number; bump: number;
  /** the prisoner this level: 0 none, 1 still tied, 2 freed */
  hostage: number; totalKills: number; headshots: number;
  hp: number; maxHp: number; best: number; boss: boolean; hint: boolean; paused: boolean; theme: string; stars: number; reward: number;
  up: Record<UpId, number>; cost: Record<UpId, number | null>;
}

type Kind = 'player' | 'archer' | 'helm' | 'heavy' | 'boss' | 'axer' | 'hostage';
interface Plat {
  x: number; y: number; w: number; h: number; fx: number; fy: number;
  rise: number; state: 'rise' | 'on' | 'sink' | 'off'; phase: number; amp: number; sway: number; sinkT: number;
  /** a little spring: the ground dips when its archer is struck or looses an arrow */
  off: number; vel: number;
}
interface Stuck { stick: number; lx: number; ly: number; rel: number }
interface Ai { state: 'wait' | 'draw' | 'hold'; t: number; aim: number; pull: number; drawT: number; spread: number; floor: number }
interface Fighter {
  k: Stick; kind: Kind; team: 0 | 1; hp: number; maxHp: number; helm: boolean; plat: Plat; stuck: Stuck[];
  vib: number; hpShow: number; flash: number; deadT: number; dmg: number; pitch: number; ai: Ai;
}
interface Arrow { p: V; prev: V; vel: V; ang: number; team: 0 | 1; dmg: number; main: boolean; near: boolean; stuckIn: Plat | null; ox: number; oy: number; life: number; dead: boolean }
interface Part { p: V; vel: V; life: number; max: number; r: number; col: string; grav: number; kind?: 'helm' | 'ring'; rot?: number }
/** a coin on its way to the purse (screen space, CSS px) */
interface Coin {
  x: number; y: number; ox: number; oy: number; slx: number; sly: number; t: number; i: number; n: number; sc: number;
  fly: number; sx: number; sy: number; cx: number; cy: number; val: number; spin: number; trail: V[]; done: boolean; born: boolean;
  from: V | null; at: V | null;
}
/** `full`: the whole-screen head shot; otherwise a small window over just the bone that was hit */
interface Xray { f: Fighter; stick: number; u: number; pt: V; ang: number; t: number; dur: number; full: boolean }
interface Axe { p: V; vel: V; ang: number; vr: number; s: number; dmg: number; spent: boolean; life: number; dead: boolean }
interface Txt { x: number; y: number; life: number; max: number; text: string; col: string; size: number }
interface LooseBow { p: V; vel: V; ang: number; vr: number; s: number }
interface Balloon { x: number; y: number; kind: 'heart' | 'coin'; phase: number }

const toSlab = (p: Plat): Slab2 => ({ x0: p.x - p.w / 2, x1: p.x + p.w / 2, top: p.y, bot: p.y + p.h });

export class RagWorld {
  w = 960; h = 600; dpr = 1; VW = 1200; VH = 680; sc = 1; cy = 380; span = 180; pullPx = 140;
  t = 0; rt = 0; private acc = 0; private ts = 1; private slowT = 0; private slowK = 1; private hitStop = 0;
  private shake = 0; private hurt = 0; private banner = 0; private bannerText = ''; private bannerSub = '';
  private cam = 0; private zoom = 1; private zoomTo = 1; private focus: V = v(0, 0);
  stage: RUi['stage'] = 'play'; paused = false; hint = true; demo = true;
  level = 1; kills = 0; total = 2; spawned = 0; maxAlive = 1;
  coins = 0; totalKills = 0; headshots = 0; best = 1; stars = 0;
  up: Record<UpId, number> = { hp: 0, dmg: 0, multi: 0, leech: 0 };
  private check = { coins: 0, totalKills: 0, headshots: 0, up: { hp: 0, dmg: 0, multi: 0, leech: 0 } as Record<UpId, number> };
  private spawnT = 0; private clearT = 0; private deadT = 0; private holdAim = 0; private balloonT = 9;
  private creakAt = 0.14; private heartT = 0; private combo = 0; private coinSeq = 0;
  private lvShots = 0; private lvHits = 0; private lvHurt = 0;
  private pFyT = 0.25;
  pPlat: Plat = { x: 200, y: 400, w: 66, h: 30, fx: 0.17, fy: 0.25, rise: 1, state: 'on', phase: 0.6, amp: 5, sway: 0, sinkT: 0, off: 0, vel: 0 };
  player!: Fighter;
  foes: Fighter[] = []; plats: Plat[] = []; arrows: Arrow[] = [];
  private parts: Part[] = []; private texts: Txt[] = []; private bows: LooseBow[] = []; private balloons: Balloon[] = [];
  private drag = { on: false, sx: 0, sy: 0, x: 0, y: 0 };
  private theme: Theme = THEMES[0]; private scene: Scene | null = null; private sceneKey = '';
  private flySpr: CanvasLike | null = null; private mistSpr: CanvasLike | null = null;
  // the living backdrop (all in 0..1 screen fractions, so it survives any resize)
  private flies: { x: number; y: number; ph: number; sp: number; bl: number; r: number; front: boolean }[] = [];
  private leaves: { x: number; y: number; ph: number; sp: number; rs: number; r: number }[] = [];
  private rays: { x: number; w: number; ph: number }[] = [];
  private mists: { x: number; y: number; sp: number }[] = [];
  private vines: { x: number; len: number; ph: number }[] = [];
  private blades: { x: number; h: number; w: number; ph: number }[] = [];
  private birds: { x: number; y: number; vx: number; n: number; ph: number }[] = []; private birdT = 5;
  private coinFx: Coin[] = []; private pending = 0; private bumpN = 0; private hudFlash = 0; private rewardPaid = false;
  private goldSpr: CanvasLike | null = null;
  private xray: Xray | null = null; private panK = 0;
  private axes: Axe[] = [];
  hostage: Fighter | null = null; hostState = 0; private freeT = 0;
  private last = '';

  constructor(private emit: (ui: RUi) => void, private make: MakeCanvas) {
    try { this.best = Math.max(1, Number(localStorage.getItem(BEST_KEY) ?? 1) || 1); } catch { this.best = 1; }
    for (let i = 0; i < 38; i++) {
      const front = i >= 27;
      this.flies.push({ x: rand(), y: 0.28 + rand() * 0.66, ph: rand() * 6.28, sp: 0.25 + rand() * 0.45, bl: 0.6 + rand() * 1.3, r: front ? 13 + rand() * 12 : 4.5 + rand() * 5, front });
    }
    for (let i = 0; i < 13; i++) this.leaves.push({ x: rand(), y: rand(), ph: rand() * 6.28, sp: 0.018 + rand() * 0.03, rs: (rand() - 0.5) * 1.6, r: 4 + rand() * 4 });
    for (let i = 0; i < 5; i++) this.rays.push({ x: 0.08 + i * 0.2 + rand() * 0.1, w: 0.03 + rand() * 0.05, ph: rand() * 6.28 });
    for (let i = 0; i < 3; i++) this.mists.push({ x: rand() * 1.4, y: 0.74 + i * 0.07, sp: (0.006 + rand() * 0.008) * (i % 2 ? -1 : 1) });
    for (let i = 0; i < 6; i++) this.vines.push({ x: (i + 0.2 + rand() * 0.6) / 6, len: 0.1 + rand() * 0.2, ph: rand() * 6.28 });
    for (let i = 0; i < 96; i++) this.blades.push({ x: (i + rand()) / 96, h: 10 + rand() * 30 + (rand() < 0.12 ? 22 : 0), w: 2 + rand() * 2.4, ph: rand() * 6.28 });
    this.resize(960, 600, 1);
    this.makePlayer();
    this.setupDemo();
    audioDuck(0.3);
  }

  /* ---------------- layout ---------------- */

  resize(w: number, h: number, dpr: number) {
    this.w = w; this.h = h; this.dpr = dpr;
    let VW = clamp((w / h) * 680, 660, 1400);
    let sc = w / VW; let VH = h / sc;
    if (VH < 560) { sc = h / 560; VW = w / sc; VH = 560; }
    this.VW = VW; this.VH = VH; this.sc = sc;
    const topSafe = (h < 520 ? 80 : 120) / sc; // the HUD lives up there
    this.cy = (topSafe + VH) / 2 + 12;
    this.span = clamp((VH - topSafe) / 2 - 112, 80, 240);
    this.pullPx = clamp(Math.min(w, h) * 0.3, 90, 170);
    this.pPlat.fx = clamp(VW * 0.17, 110, 260) / VW;
    this.sceneKey = '';
  }

  private placePlat(p: Plat) {
    const ty = this.cy + p.fy * this.span;
    const e = ease.out(clamp(p.rise, 0, 1));
    p.x = p.fx * this.VW + Math.sin(this.t * 0.7 + p.phase * 1.7) * p.sway;
    p.y = ty + (1 - e) * (this.VH - ty + 170) + Math.sin(this.t * 1.3 + p.phase) * p.amp + p.off;
  }
  private pan(x: number) { return clamp((x / this.VW) * 2 - 1, -0.85, 0.85); }

  /* ---------------- run / level flow ---------------- */

  private makePlayer() {
    this.pPlat.off = 0; this.pPlat.vel = 0;
    this.placePlat(this.pPlat);
    const maxHp = 100 + 20 * this.up.hp;
    this.player = {
      k: makeStick(v(this.pPlat.x, this.pPlat.y), 1, 1, false, true), kind: 'player', team: 0, hp: maxHp, maxHp, helm: false,
      plat: this.pPlat, stuck: [], vib: 9, hpShow: 0, flash: 0, deadT: 0, dmg: 0, pitch: 1.12,
      ai: { state: 'wait', t: 1.2, aim: 0, pull: 0.9, drawT: 0.6, spread: 0.045, floor: 0.045 },
    };
  }

  private setupLevel() {
    const L = this.level;
    this.kills = 0; this.spawned = 0;
    this.total = Math.min(1 + L, 14);
    this.maxAlive = Math.min(1 + Math.floor(L / 2), 5);
    this.spawnT = 0.9; this.clearT = 0; this.stage = 'play';
    this.theme = THEMES[Math.floor((L - 1) / 3) % THEMES.length];
    this.pFyT = [0.25, -0.05, 0.4, 0.1, -0.2][(L - 1) % 5];
    this.pPlat.amp = 4 + Math.min(L, 8) * 0.7;
    this.banner = 2.4; this.bannerText = `LEVEL ${L}`;
    const prisoner = L % 4 === 3 && L % 5 !== 0; // only some rounds have someone to rescue
    this.bannerSub = L % 5 === 0 ? (L % 10 === 5 ? 'BOS KAPAK MENANTI!' : 'BOS MENANTI!') : prisoner ? 'BEBASKAN TAWANAN!' : `${this.maxAlive} PIJAKAN  ·  ${this.total} MUSUH`;
    this.check = { coins: this.coins, totalKills: this.totalKills, headshots: this.headshots, up: { ...this.up } };
    this.lvShots = 0; this.lvHits = 0; this.lvHurt = 0; this.combo = 0; this.stars = 0; this.rewardPaid = false;
    if (L > this.best) { this.best = L; try { localStorage.setItem(BEST_KEY, String(L)); } catch { /* not kept */ } }
    this.axes = []; this.hostage = null; this.hostState = 0;
    if (prisoner) this.spawnHostage();
    snd.banner();
  }

  /** the title screen: he fights on by himself, forever */
  private setupDemo() {
    this.level = 1; this.kills = 0; this.spawned = 0; this.total = 1e9; this.maxAlive = 2;
    this.spawnT = 0.6; this.stage = 'play'; this.theme = THEMES[0]; this.pFyT = 0.25; this.pPlat.amp = 5;
    this.banner = 0; this.hint = false;
  }

  private clearWorld() {
    this.foes = []; this.plats = []; this.arrows = []; this.parts = []; this.texts = []; this.bows = []; this.balloons = [];
    this.slowT = 0; this.hitStop = 0; this.hurt = 0; this.drag.on = false; this.balloonT = 9;
    this.zoom = 1; this.zoomTo = 1; this.ts = 1;
    this.coinFx = []; this.pending = 0; this.xray = null; this.panK = 0;
    this.axes = []; this.hostage = null; this.hostState = 0;
  }

  nextLevel() {
    if (this.stage !== 'shop') return;
    this.level++;
    this.setupLevel();
  }

  /** again from the start of this level, with what you had when it began */
  retry() {
    this.coins = this.check.coins; this.totalKills = this.check.totalKills; this.headshots = this.check.headshots; this.up = { ...this.check.up };
    this.clearWorld(); this.makePlayer(); this.setupLevel(); this.paused = false;
  }

  restart() {
    this.level = 1; this.coins = 0; this.totalKills = 0; this.headshots = 0; this.up = { hp: 0, dmg: 0, multi: 0, leech: 0 };
    this.clearWorld(); this.makePlayer(); this.setupLevel(); this.paused = false; this.hint = true;
  }

  /** leave the title screen and start a run */
  startRun() { this.demo = false; audioDuck(1); this.restart(); }
  /** back to the self-playing title screen */
  toDemo() {
    this.demo = true; audioDuck(0.3);
    this.coins = 0; this.totalKills = 0; this.headshots = 0; this.up = { hp: 0, dmg: 0, multi: 0, leech: 0 };
    this.clearWorld(); this.makePlayer(); this.setupDemo(); this.paused = false;
  }

  setPaused(p: boolean) { this.paused = p; if (p) this.drag.on = false; }

  costOf(id: UpId): number | null {
    const n = this.up[id];
    if (n >= UP_MAX[id]) return null;
    if (id === 'hp') return 25 + 20 * n;
    if (id === 'dmg') return 30 + 25 * n;
    if (id === 'multi') return [90, 220][n];
    return 35 + 25 * n;
  }

  buy(id: UpId) {
    const c = this.costOf(id);
    if (c === null || this.coins < c) { snd.deny(); return; }
    this.coins -= c; this.up[id]++;
    if (id === 'hp') { this.player.maxHp += 20; this.player.hp += 20; }
    snd.buy();
  }

  /* ---------------- input ---------------- */

  pointerDown(x: number, y: number) {
    audioInit();
    if (this.demo || this.paused || this.stage === 'shop' || this.stage === 'dead' || this.stage === 'dying') return;
    this.drag = { on: true, sx: x, sy: y, x, y };
  }
  pointerMove(x: number, y: number) { if (this.drag.on) { this.drag.x = x; this.drag.y = y; } }
  pointerUp() {
    if (!this.drag.on) return;
    this.drag.on = false;
    const k = this.player.k;
    if (k.alive && onString(k) && k.pull > 0.12 && !this.paused) this.fire(this.player);
  }
  pointerCancel() { this.drag.on = false; }

  /* ---------------- coins ---------------- */

  /** where the purse sits on the HUD (CSS px) */
  private purse(): V { return this.w >= 640 ? v(40, 36) : v(30, 24); }
  /** a point in the world → CSS px on screen, through the current zoom */
  private toScreen(p: V): V {
    const [ck, cx0, cy0] = this.camTf();
    return v(p.x * ck + cx0, p.y * ck + cy0);
  }
  /** the camera: scale and offset (CSS px). It zooms about the focus, and for an X-ray slides the focus to mid-screen */
  private camTf(): [number, number, number] {
    const k = this.sc * this.zoom; const F = this.focus;
    const cx = F.x * this.sc + (this.w * 0.5 - F.x * this.sc) * this.panK;
    const cy = F.y * this.sc + (this.h * 0.5 - F.y * this.sc) * this.panK;
    return [k, cx - F.x * k, cy - F.y * k];
  }

  /** a haul of coins: they pop out big into a neat fan, hang there a beat, then stream home in single file */
  private spawnCoins(at: V, total: number, screen = false) {
    if (this.demo || total <= 0) return;
    const n = Math.min(total, clamp(Math.round(total / 1.5), 4, 10));
    this.coins += total; this.pending += total;
    // if a full X-ray is on screen the coins wait for it to finish - they deserve to be seen
    const hold = this.xray && this.xray.full ? this.xray.dur - this.xray.t + 0.12 : 0;
    const outer = Math.min(n, 6);
    for (let i = 0; i < n; i++) {
      // the fan: an arc of up to six above the spot, the rest on a tighter arc inside it
      const row = i < outer ? 0 : 1; const cnt = row ? n - outer : outer; const j = row ? i - outer : i;
      const ang = -Math.PI / 2 + (j - (cnt - 1) / 2) * (row ? 0.86 : 0.44);
      const R = row ? 38 : 74;
      this.coinFx.push({
        x: 0, y: 0, ox: 0, oy: 0, slx: Math.cos(ang) * R, sly: Math.sin(ang) * R, t: -hold, i, n, sc: 0, fly: -1, sx: 0, sy: 0, cx: 0, cy: 0,
        val: Math.floor(total / n) + (i < total % n ? 1 : 0), spin: i * 0.7, trail: [], done: false, born: false,
        from: screen ? null : { ...at }, at: screen ? { ...at } : null,
      });
    }
  }

  private stepCoins(dt: number) {
    this.hudFlash = Math.max(0, this.hudFlash - dt * 4);
    if (!this.coinFx.length) return;
    const tgt = this.purse();
    for (const c of this.coinFx) {
      c.t += dt;
      if (c.t < 0) continue;
      if (!c.born) {
        // start from where the body is on screen now (an X-ray may have moved the camera since)
        c.born = true;
        const o = c.from ? this.toScreen(c.from) : (c.at as V);
        c.ox = clamp(o.x, 84, this.w - 84); c.oy = clamp(o.y - 8, 100, this.h - 30);
        c.x = c.ox; c.y = c.oy;
      }
      const lt = c.t - c.i * 0.035; // each coin appears a beat behind the last
      if (lt < 0) continue;
      if (lt - dt < 0) snd.coinTick(c.i);
      c.spin += dt * 10;
      const depart = c.n * 0.035 + 0.56 + c.i * 0.075; // and they leave in the same order, evenly spaced
      if (c.t < depart) {
        // out to its slot at 1.7x size, overshooting and settling; then a slow bob that runs along the fan like a wave
        const u = Math.min(1, lt / 0.34); const e = ease.outBack(u);
        c.x = c.ox + c.slx * e; c.y = c.oy + c.sly * e + (u >= 1 ? Math.sin(c.t * 7 - c.i * 0.7) * 3 : 0);
        c.sc = 1.7 * Math.min(1.14, 0.15 + e);
        continue;
      }
      if (c.fly < 0) {
        // every coin takes the same road: up and over, then down into the purse
        c.fly = 0; c.sx = c.x; c.sy = c.y;
        c.cx = c.sx + (tgt.x - c.sx) * 0.4;
        c.cy = Math.max(24, (c.sy + tgt.y) / 2 - Math.min(90, 40 + Math.abs(c.sx - tgt.x) * 0.12)); // never off the top of the screen
      }
      c.fly = Math.min(1, c.fly + dt / 0.5);
      const e = c.fly * c.fly * (0.6 + 0.4 * c.fly); const m = 1 - e; // drifts off, then is pulled home
      c.trail.push(v(c.x, c.y)); if (c.trail.length > 9) c.trail.shift();
      c.x = m * m * c.sx + 2 * m * e * c.cx + e * e * tgt.x;
      c.y = m * m * c.sy + 2 * m * e * c.cy + e * e * tgt.y;
      c.sc = 1.7 - 0.85 * e;
      if (c.fly >= 1) {
        c.done = true;
        this.pending = Math.max(0, this.pending - c.val); this.bumpN++; this.hudFlash = 1;
        snd.coin(this.coinSeq++);
      }
    }
    this.coinFx = this.coinFx.filter((c) => !c.done);
    if (!this.coinFx.length) { snd.coinEnd(this.coinSeq - 1); this.coinSeq = 0; this.pending = 0; }
  }

  private drawCoins(ctx: Ctx) {
    const gold = this.goldSpr;
    ctx.lineCap = 'round';
    for (const c of this.coinFx) {
      if (!c.born || c.t - c.i * 0.035 < 0) continue;
      const r = 7.5 * c.sc;
      // a ribbon of light behind it on the way home
      for (let i = 1; i < c.trail.length; i++) {
        const u = i / c.trail.length;
        ctx.strokeStyle = '#ffe27a'; ctx.globalAlpha = u * 0.7; ctx.lineWidth = r * 0.95 * u;
        ctx.beginPath(); ctx.moveTo(c.trail[i - 1].x, c.trail[i - 1].y); ctx.lineTo(c.trail[i].x, c.trail[i].y); ctx.stroke();
      }
      if (gold) {
        ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.5;
        ctx.drawImage(gold as unknown as CanvasImageSource, c.x - r * 2.3, c.y - r * 2.3, r * 4.6, r * 4.6);
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.globalAlpha = 1;
      // the coin itself, turning on its axis: dark rim, gold face, a raised inner ring and a bar that narrows as it turns
      // face-on (just rocking) while it sits in the fan, spinning freely once it flies
      const wx = c.fly < 0 ? 0.82 + 0.18 * Math.cos(c.spin) : Math.abs(Math.cos(c.spin));
      ctx.fillStyle = '#9a6200'; ctx.beginPath(); ctx.ellipse(c.x, c.y + r * 0.1, r * wx + r * 0.16, r * 1.08, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffc933'; ctx.beginPath(); ctx.ellipse(c.x, c.y, r * wx + r * 0.07, r, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#e39a00'; ctx.lineWidth = Math.max(0.8, r * 0.13);
      ctx.beginPath(); ctx.ellipse(c.x, c.y, Math.max(0.4, r * wx * 0.68), r * 0.68, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#e39a00'; ctx.fillRect(c.x - r * 0.12 * wx, c.y - r * 0.4, r * 0.24 * wx, r * 0.8);
      ctx.fillStyle = '#fff6c8'; ctx.beginPath(); ctx.ellipse(c.x - r * wx * 0.34, c.y - r * 0.4, Math.max(0.3, r * wx * 0.2), r * 0.17, -0.5, 0, Math.PI * 2); ctx.fill();
      // a glint now and then
      const tw = Math.max(0, Math.sin(c.t * 9 + c.i * 2.1)) ** 6;
      if (tw > 0.05) {
        const gx = c.x + r * 0.55; const gy = c.y - r * 0.6; const gl = r * 0.75 * tw;
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.4; ctx.globalAlpha = tw;
        ctx.beginPath(); ctx.moveTo(gx - gl, gy); ctx.lineTo(gx + gl, gy); ctx.moveTo(gx, gy - gl); ctx.lineTo(gx, gy + gl); ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    // the purse flashes every time one lands
    if (this.hudFlash > 0.01) {
      const tgt = this.purse(); const u = 1 - this.hudFlash;
      ctx.strokeStyle = '#ffe27a';
      ctx.globalAlpha = this.hudFlash; ctx.lineWidth = 3 * this.hudFlash + 1;
      ctx.beginPath(); ctx.arc(tgt.x, tgt.y, 12 + u * 20, 0, Math.PI * 2); ctx.stroke();
      ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) {
        const a = i * 1.047 + 0.3; const r0 = 18 + u * 22; const r1 = r0 + 7 * this.hudFlash;
        ctx.beginPath(); ctx.moveTo(tgt.x + Math.cos(a) * r0, tgt.y + Math.sin(a) * r0); ctx.lineTo(tgt.x + Math.cos(a) * r1, tgt.y + Math.sin(a) * r1); ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
  }

  /* ---------------- the prisoner ---------------- */

  /** some rounds a prisoner stands tied on a ground of his own, leashed to a peg above: cut the rope, not him */
  private spawnHostage() {
    const plat: Plat = {
      x: 0, y: 0, w: 58, h: 28, fx: 0.4 + rand() * 0.11, fy: -0.15 + rand() * 0.6, rise: 0, state: 'rise', phase: rand() * 6.28,
      amp: 6, sway: 0, sinkT: 0, off: 0, vel: 0,
    };
    this.placePlat(plat);
    this.plats.push(plat);
    this.hostage = {
      k: makeStick(v(plat.x, plat.y), -1, 1, false, true, 'hostage'), kind: 'hostage', team: 0, hp: 1, maxHp: 1, helm: false, plat, stuck: [],
      vib: 9, hpShow: 0, flash: 0, deadT: 0, dmg: 0, pitch: 1.3,
      ai: { state: 'wait', t: 0, aim: 0, pull: 0, drawT: 1, spread: 0, floor: 0 },
    };
    this.hostState = 1; this.freeT = 0;
  }
  /** the taut stretch of rope you have to hit: from the peg down to just above his head */
  private rope(hs: Fighter): [V, V] {
    return [v(hs.plat.x, hs.plat.y - 176), v(hs.k.p[0].x, hs.k.p[0].y - HEAD_R - 3)];
  }

  private freeHostage(at: V) {
    const hs = this.hostage;
    if (!hs || this.hostState !== 1) return;
    const k = hs.k; const pan = this.pan(at.x);
    this.hostState = 2; this.freeT = 0;
    this.burst(at, v(0, -1), 9, '#e3c283', 170);
    for (let i = 0; i < 8; i++) this.parts.push({ p: lerpV(k.p[2], k.p[1], 0.3 + rand() * 0.4), vel: v((rand() - 0.5) * 220, -60 - rand() * 120), life: 0, max: 0.7 + rand() * 0.3, r: 2.2, col: '#e3c283', grav: 900 });
    this.parts.push({ p: { ...at }, vel: v(0, 0), life: 0, max: 0.25, r: 20, col: '#ffe9b0', grav: 0, kind: 'ring' });
    snd.ropeSnap(pan); snd.yay(pan); snd.heal();
    this.say(k.p[0].x, k.p[0].y - 64, 'BEBAS!  TERIMA KASIH!', '#7dffa0', 19, 1.7);
    this.spawnCoins(k.p[1], 15);
    const pf = this.player; pf.hp = Math.min(pf.maxHp, pf.hp + 20);
    this.lvHits++; this.combo++;
    if (this.kills >= this.total) this.beginClear(null);
  }

  /** you shot the man you were meant to save */
  private hostageHit(a: Arrow, hs: Fighter, hit: { stick: number; u: number }) {
    const k = hs.k; const pan = this.pan(a.p.x);
    this.lodge(a, hs, hit);
    a.dead = true;
    punchRag(k as unknown as ArcherRag, hit.stick, hit.u, a.vel, false);
    k.muscle = Math.min(k.muscle, 0.5); k.hurt = 1; k.hurtDir = Math.sign(a.vel.x) || 1; k.wound = { stick: hit.stick, u: hit.u };
    hs.flash = 1; hs.plat.vel += 70;
    this.burst(a.p, mul(a.vel, -1), 6, '#d3141f', 200);
    this.hitStop = 0.04; this.shake = Math.max(this.shake, 5);
    snd.hit(pan, false); snd.grunt(pan, hs.pitch); snd.deny();
    this.coins = Math.max(0, this.coins - 10); this.combo = 0;
    this.say(k.p[0].x, k.p[0].y - 56, 'JANGAN TEMBAK TAWANAN!  -10', '#ff6b6b', 16, 1.5);
  }

  private drawHostage(ctx: Ctx) {
    const hs = this.hostage;
    if (!hs) return;
    const k = hs.k; const th = this.theme; const pl = hs.plat;
    const al = pl.state === 'on' ? 1 : clamp(pl.rise * 1.5, 0, 1);
    const [top, bot] = this.rope(hs);
    ctx.globalAlpha = al;
    // the peg: a chip of floating rock with an iron ring under it
    ctx.fillStyle = th.plat; ctx.fillRect(top.x - 14, top.y - 14, 28, 12);
    ctx.fillStyle = th.platTop; ctx.fillRect(top.x - 14, top.y - 14, 28, 3);
    ctx.strokeStyle = '#9fb4bb'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(top.x, top.y + 2, 4, 0, Math.PI * 2); ctx.stroke();
    ctx.lineCap = 'round';
    const rope = (a: V, b: V, sag: number) => {
      for (const [col, lw] of [['#8a6a34', 4.2], ['#e3c283', 2.4]] as [string, number][]) {
        ctx.strokeStyle = col; ctx.lineWidth = lw;
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.quadraticCurveTo((a.x + b.x) / 2 + sag, (a.y + b.y) / 2, b.x, b.y); ctx.stroke();
      }
    };
    if (this.hostState === 1) {
      rope(v(top.x, top.y + 5), k.p[1], Math.sin(this.t * 2.1) * 2.5);
      // a ring on the rope: this is the place to hit
      const m = lerpV(top, bot, 0.52); const pu = 0.5 + 0.5 * Math.sin(this.rt * 5);
      ctx.strokeStyle = '#ffe27a'; ctx.globalAlpha = al * (0.45 + 0.5 * pu); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(m.x, m.y, 10 + pu * 4, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(m.x - 17 - pu * 4, m.y); ctx.lineTo(m.x - 11, m.y); ctx.moveTo(m.x + 11, m.y); ctx.lineTo(m.x + 17 + pu * 4, m.y); ctx.stroke();
      ctx.globalAlpha = al;
    } else {
      // what is left of it swings from the peg
      const sw = Math.sin(this.freeT * 9) * 9 * Math.exp(-this.freeT * 1.4);
      rope(v(top.x, top.y + 5), v(top.x + sw, top.y + 34), sw * 0.5);
    }
    this.drawFighter(ctx, hs);
    if (this.hostState === 1 && pl.state === 'on' && Math.sin(this.rt * 1.6 + 1) > -0.2) {
      this.text(ctx, 'TOLONG!', k.p[0].x + 44, k.p[0].y - 26 + Math.sin(this.rt * 9) * 1.5, 13, '#ffffff', 0.95);
    }
    ctx.globalAlpha = 1;
  }

  /* ---------------- the axe boss ---------------- */

  /** a slow, heavy, perfectly aimed axe: it will land unless an arrow takes it out of the air */
  private throwAxe(f: Fighter) {
    const k = f.k; const pk = this.player.k;
    const from = { ...k.p[4] }; const to = lerpV(pk.p[1], pk.p[2], 0.3);
    const T = 1.5 + rand() * 0.3; const g = 620; // slow enough to answer with an arrow
    this.axes.push({ p: from, vel: v((to.x - from.x) / T, (to.y - from.y) / T - 0.5 * g * T), ang: 0, vr: -k.face * 12, s: 1.3, dmg: f.dmg * 1.5, spent: false, life: 0, dead: false });
    impulse(k, 4, v(k.face * 260, -40)); impulse(k, 1, v(k.face * 90, 0)); impulse(k, 0, v(k.face * 120, 20));
    k.muscle = Math.min(k.muscle, 0.6); k.exert = Math.min(1, k.exert + 0.4);
    k.pull = 0; k.nock = 0; f.plat.vel += 40;
    snd.throwAxe(this.pan(from.x), f.pitch);
  }

  private parry(ax: Axe, a: Arrow) {
    ax.dead = true; a.dead = true;
    const pan = this.pan(ax.p.x);
    this.burst(ax.p, a.vel, 10, '#dbe8ec', 320);
    this.burst(ax.p, v(0, -1), 7, '#7a4a2a', 220);
    this.parts.push({ p: { ...ax.p }, vel: v(0, 0), life: 0, max: 0.24, r: 30, col: '#ffffff', grav: 0, kind: 'ring' });
    this.hitStop = 0.05; this.shake = Math.max(this.shake, 6);
    snd.parry(pan);
    this.say(ax.p.x, ax.p.y - 28, 'TANGKIS!  +3', '#bff4fa', 19, 1.1);
    this.spawnCoins(ax.p, 3);
    this.lvHits++; this.combo++;
  }

  private axeHit(ax: Axe) {
    const pf = this.player; const k = pf.k; const pan = this.pan(ax.p.x);
    const dmg = Math.max(1, Math.round(ax.dmg));
    pf.hp -= dmg; pf.flash = 1; this.lvHurt += dmg;
    const fatal = pf.hp <= 0;
    punchRag(k as unknown as ArcherRag, 1, 0.6, mul(ax.vel, 2.2), fatal);
    k.muscle = Math.min(k.muscle, 0.3); k.hurt = 1; k.hurtDir = Math.sign(ax.vel.x) || -1; k.wound = { stick: 1, u: 0.6 }; k.exert = 1;
    pf.plat.vel += 140;
    this.burst(ax.p, mul(ax.vel, -1), 14, '#d3141f', 320);
    this.parts.push({ p: { ...ax.p }, vel: v(0, 0), life: 0, max: 0.24, r: 30, col: '#ffffff', grav: 0, kind: 'ring' });
    this.hitStop = 0.08; this.shake = Math.max(this.shake, 13); this.hurt = 1;
    snd.hit(pan, true);
    if (!fatal) snd.grunt(pan, pf.pitch);
    this.say(k.p[0].x, k.p[0].y - 52, `-${dmg}`, '#ff6b6b', 24);
    ax.spent = true; ax.vel = v(-ax.vel.x * 0.25, -220); ax.vr *= -0.5;
    if (fatal) this.die(pf, false);
  }

  /** the round is won: every enemy down and nobody left tied up */
  private beginClear(focus: V | null) {
    this.stage = 'clear'; this.clearT = 0; this.drag.on = false;
    if (focus) { this.zoomTo = 1.13; if (!(this.xray && this.xray.full)) this.focus = { ...focus }; }
    const acc = this.lvHits / Math.max(1, this.lvShots);
    this.stars = 1 + (acc >= 0.5 ? 1 : 0) + (this.lvHurt <= this.player.maxHp * 0.35 ? 1 : 0);
    snd.win();
  }

  /* ---------------- spawning ---------------- */

  private spawnEnemy() {
    const L = this.level;
    const boss = !this.demo && L % 5 === 0 && this.spawned === this.total - 1;
    const r = rand();
    const kind: Kind = boss ? (L % 10 === 5 ? 'axer' : 'boss') : L >= 6 && r < 0.2 ? 'heavy' : (L >= 3 || this.demo) && r < 0.5 ? 'helm' : 'archer';
    const big = kind === 'boss' || kind === 'axer';
    const s = big ? 1.5 : kind === 'heavy' ? 1.22 : 1;
    const kneel = !big && rand() < 0.5;
    let fx = 0.78; let fy = 0.1;
    if (!boss) {
      for (let i = 0; i < 40; i++) {
        // on the title screen they keep to the right, clear of the logo
        fx = this.demo ? 0.74 + rand() * 0.2 : 0.5 + rand() * 0.43; fy = rand() * 2 - 1;
        const x = fx * this.VW; const y = this.cy + fy * this.span;
        // clear of the other grounds, and never up in the prisoner's rope
        const hp = this.hostState === 1 && this.hostage ? this.hostage.plat : null;
        if (hp && Math.abs(hp.fx * this.VW - x) < 115 && y < this.cy + hp.fy * this.span) continue;
        if (!this.plats.some((p) => Math.abs(p.fx * this.VW - x) < 125 && Math.abs(this.cy + p.fy * this.span - y) < 150)) break;
      }
    }
    const plat: Plat = {
      x: 0, y: 0, w: (kneel ? 72 : 60) * s, h: 28 * Math.min(s, 1.25), fx, fy, rise: 0, state: 'rise', phase: rand() * 6.28,
      amp: 5 + Math.min(L, 10) * 1.6, sway: L >= 4 && !boss ? rand() * Math.min(L * 3, 26) : 0, sinkT: 0, off: 0, vel: 0,
    };
    this.placePlat(plat);
    this.plats.push(plat);
    const hp = Math.round((34 + 6 * Math.min(L, 14)) * (kind === 'heavy' ? 1.8 : 1) + (big ? 150 + 22 * L : 0));
    const dmg = (8 + 0.6 * Math.min(L, 15)) * (big ? 1.5 : kind === 'heavy' ? 1.25 : 1);
    this.foes.push({
      k: makeStick(v(plat.x, plat.y), -1, s, kneel, kind === 'boss', kind === 'axer' ? 'thrower' : 'archer'), kind, team: 1, hp, maxHp: hp, helm: kind === 'helm', plat, stuck: [],
      vib: 9, hpShow: 0, flash: 0, deadT: 0, dmg, pitch: big ? 0.68 : kind === 'heavy' ? 0.8 : 0.9 + rand() * 0.2,
      ai: { state: 'wait', t: 1.9 + rand() * 1.5, aim: Math.PI, pull: 0.8, drawT: 0.7, spread: Math.max(0.08, 0.24 - 0.01 * L), floor: Math.max(0.03, 0.065 - 0.0025 * L) },
    });
    this.spawned++;
    snd.rise(this.pan(plat.x));
    if (boss) { this.banner = 2.4; this.bannerText = kind === 'axer' ? 'BOS KAPAK!' : 'BOS!'; this.bannerSub = kind === 'axer' ? 'PANAH KAPAKNYA DI UDARA' : 'BIDIK KEPALANYA'; snd.boss(); }
  }

  /* ---------------- shooting ---------------- */

  private fire(f: Fighter) {
    const k = f.k; const ang = fireAngle(k); const pull = k.pull; const sp = speedOf(pull); const dir = fromAngle(ang);
    const n = f.team === 0 ? 1 + this.up.multi : f.kind === 'boss' && this.level >= 15 ? 2 : 1;
    for (let i = 0; i < n; i++) {
      const a = ang + (i - (n - 1) / 2) * 0.075;
      const tip = add(k.p[4], fromAngle(a, 14 * k.s));
      const dmg = f.team === 0 ? 40 * (0.45 + 0.65 * pull) * (1 + 0.18 * this.up.dmg) : f.dmg * (0.7 + 0.3 * pull);
      this.arrows.push({ p: tip, prev: { ...tip }, vel: fromAngle(a, sp), ang: a, team: f.team, dmg, main: i === Math.floor((n - 1) / 2), near: false, stuckIn: null, ox: 0, oy: 0, life: 0, dead: false });
    }
    // the release: bow hand jumps forward, the string hand swings back, the torso rocks, the muscles go soft a moment
    impulse(k, 4, mul(dir, 100 * pull)); impulse(k, 3, mul(dir, 45 * pull));
    impulse(k, 6, mul(dir, -250 * pull)); impulse(k, 5, mul(dir, -170 * pull));
    impulse(k, 1, mul(dir, -115 * pull)); impulse(k, 0, mul(dir, -160 * pull)); impulse(k, 2, mul(dir, -45 * pull));
    k.muscle = Math.min(k.muscle, 0.58);
    k.exert = Math.min(1, k.exert + 0.3);
    k.pull = 0; k.nock = 0; f.vib = 0;
    f.plat.vel += 26 * pull;
    snd.release(f.team === 0 ? pull : pull * 0.6, this.pan(k.p[4].x));
    if (f.team === 0 && !this.demo) { this.hint = false; this.holdAim = 0.55; this.shake = Math.max(this.shake, 1.5 + pull * 3); this.lvShots++; }
    if (this.arrows.length > 60) this.arrows.splice(0, this.arrows.length - 60);
  }

  /** pick an angle and draw for a lobbed shot at the target, with an error that shrinks every shot */
  private aimAt(f: Fighter, tgt: Fighter) {
    const from = f.k.p[1]; const tk = tgt.k;
    const to = lerpV(tk.p[1], tk.p[2], 0.35);
    const dx = to.x - from.x; const dy = to.y - from.y; const X = Math.max(40, Math.abs(dx));
    let pull = clamp(0.5 + X / 1300 + rand() * 0.12, 0.55, 1);
    let sp = speedOf(pull);
    let disc = sp ** 4 - AG * (AG * X * X - 2 * dy * sp * sp);
    if (disc < 0) { pull = 1; sp = speedOf(1); disc = sp ** 4 - AG * (AG * X * X - 2 * dy * sp * sp); }
    const th = (disc < 0 ? Math.PI / 4 : Math.atan((sp * sp - Math.sqrt(disc)) / (AG * X))) + gauss() * f.ai.spread;
    f.ai.aim = Math.atan2(-Math.sin(th), Math.sign(dx || -1) * Math.cos(th));
    f.ai.pull = pull;
    f.ai.drawT = (f.kind === 'boss' ? 0.5 : 0.65) + rand() * 0.3;
    if (f.kind === 'axer') { f.ai.pull = 1; f.ai.drawT = 0.8; } // the wind-up is the warning
  }

  /** wait → raise and draw → hold a breath → loose. Runs the enemies, and the player on the title screen */
  private think(f: Fighter, tgt: Fighter | null, can: boolean) {
    const k = f.k; const ai = f.ai;
    if (ai.state === 'wait') {
      k.aiming = damp(k.aiming, 0, 4, H); k.pull = damp(k.pull, 0, 12, H);
      if (can) ai.t -= H;
      if (can && tgt && ai.t <= 0 && onString(k) && k.react === 'none' && k.muscle > 0.85 && k.hurt < 0.05) {
        // only a couple of them draw at the same moment, so a crowd never turns into a wall of arrows
        const busy = f.team === 1 ? this.foes.reduce((n, o) => n + (o.k.alive && o.ai.state !== 'wait' ? 1 : 0), 0) : 0;
        if (busy >= (this.level >= 9 ? 3 : 2)) ai.t = 0.35 + rand() * 0.4;
        else { this.aimAt(f, tgt); ai.state = 'draw'; }
      }
    } else if (ai.state === 'draw') {
      k.aim = angLerp(k.aim, ai.aim, 1 - Math.exp(-10 * H));
      k.aiming = damp(k.aiming, 1, 9, H);
      if (k.aiming > 0.6) k.pull = Math.min(ai.pull, k.pull + (H * ai.pull) / ai.drawT);
      if (!can || !tgt) { ai.state = 'wait'; ai.t = 1; }
      else if (k.pull >= ai.pull - 0.001 && k.aiming > 0.97) { ai.state = 'hold'; ai.t = 0.15 + rand() * 0.3; }
    } else {
      ai.t -= H;
      if (!can || !tgt) { ai.state = 'wait'; ai.t = 1; }
      else if (ai.t <= 0) {
        if (f.kind === 'axer') this.throwAxe(f); else this.fire(f);
        ai.state = 'wait';
        ai.t = f.team === 0 ? 0.5 + rand() * 0.8 : f.kind === 'axer' ? 1.3 + rand() * 0.8 : Math.max(1.6, 2.8 - this.level * 0.07) * (f.kind === 'boss' ? 0.75 : 1) + rand() * 1.4;
        ai.spread = Math.max(ai.floor, ai.spread * 0.8);
      }
    }
  }

  private hitTest(tip: V, f: Fighter): { stick: number; u: number } | null {
    const P = f.k.p; const s = f.k.s;
    if (Math.abs(tip.x - P[2].x) > 95 * s || Math.abs(tip.y - P[2].y) > 115 * s) return null;
    if (dist(tip, P[0]) < HEAD_R * s + 2.5) return { stick: 0, u: 1 };
    let best: { stick: number; u: number } | null = null; let bd = 1e9;
    for (let i = 1; i < RAG_STICKS.length; i++) {
      const [a, b] = RAG_STICKS[i];
      const r = segDist(tip, P[a], P[b]);
      if (r.d < (i === 1 ? 5.6 : 4.6) * s + 2 && r.d < bd) { bd = r.d; best = { stick: i, u: r.t }; }
    }
    return best;
  }

  private burst(p: V, dir: V, n: number, col: string, speed = 260) {
    for (let i = 0; i < n; i++) {
      const a = Math.atan2(dir.y, dir.x) + (rand() - 0.5) * 1.5;
      const sp = speed * (0.3 + rand() * 0.9);
      this.parts.push({ p: { ...p }, vel: v(Math.cos(a) * sp, Math.sin(a) * sp - 60), life: 0, max: 0.35 + rand() * 0.4, r: 1.6 + rand() * 2.6, col, grav: 900 });
    }
    if (this.parts.length > 300) this.parts.splice(0, this.parts.length - 300);
  }

  private say(x: number, y: number, text: string, col: string, size = 18, max = 0.9) {
    if (!this.demo) this.texts.push({ x, y, life: 0, max, text, col, size });
  }

  /**
   * Leave the arrow in the bone it struck. It is slid in along its own line until the point sits in the middle
   * of that bone, so the shaft meets the body with no gap (the body is drawn over the buried end).
   */
  private lodge(a: Arrow, f: Fighter, hit: { stick: number; u: number }): V {
    const k = f.k; const head = hit.stick === 0;
    const [ia, ib] = RAG_STICKS[hit.stick];
    const A = k.p[ia]; const B = k.p[ib];
    let tip = a.p; let best = 1e9;
    for (let i = 0; i <= 18; i++) {
      const q = add(a.p, fromAngle(a.ang, i));
      const dd = head ? dist(q, k.p[0]) : segDist(q, A, B).d;
      if (dd < best) { best = dd; tip = q; } else if (dd > best + 1) break;
    }
    if (head) tip = add(tip, fromAngle(a.ang, -3 * k.s));
    const ba = Math.atan2(B.y - A.y, B.x - A.x);
    const rx = tip.x - A.x; const ry = tip.y - A.y; const c = Math.cos(-ba); const sn = Math.sin(-ba);
    f.stuck.push({ stick: hit.stick, lx: rx * c - ry * sn, ly: rx * sn + ry * c, rel: a.ang - ba });
    if (f.stuck.length > 7) f.stuck.shift();
    return tip;
  }

  private onHit(a: Arrow, f: Fighter, hit: { stick: number; u: number }) {
    const k = f.k; const head = hit.stick === 0; const torso = hit.stick === 1;
    // the arrow stays in the bone it struck and rides the ragdoll from now on
    const tip = this.lodge(a, f, hit);
    a.dead = true;
    const back = mul(a.vel, -1); const pan = this.pan(a.p.x);
    if (!k.alive) {
      punchRag(k as unknown as ArcherRag, hit.stick, hit.u, a.vel, true);
      this.burst(a.p, back, 5, '#b3121b'); snd.hit(pan, false);
      return;
    }
    // the player's headshots are the big reward; an enemy's lucky one hurts but does not end the run
    const heart = torso && hit.u > 0.58 && hit.u < 0.93; // the upper chest
    let helmHit = false;
    let dmg = a.dmg * (f.team === 0 ? (head ? 1.5 : torso ? 1 : 0.6) : head ? (f.kind === 'boss' ? 1.8 : 2.6) : heart ? 1.4 : torso ? 1 : 0.55);
    if (this.demo && f.team === 0) dmg *= 0.25;
    if (head && f.helm) {
      f.helm = false; dmg *= 0.3; helmHit = true;
      this.parts.push({ p: { ...k.p[0] }, vel: v(a.vel.x * 0.25 + (rand() - 0.5) * 80, -330), life: 0, max: 2.4, r: (HEAD_R + 2) * k.s, col: '#51666f', grav: 1100, kind: 'helm', rot: 0 });
      this.say(k.p[0].x, k.p[0].y - 34, 'HELM LEPAS!', '#cfe3ea', 15);
      snd.clang(pan);
    }
    dmg = Math.max(1, Math.round(dmg));
    f.hp -= dmg; f.hpShow = 3; f.flash = 1;
    if (this.demo && f.team === 0) f.hp = Math.max(f.hp, 20);
    const fatal = f.hp <= 0;
    punchRag(k as unknown as ArcherRag, hit.stick, hit.u, a.vel, fatal);
    k.muscle = Math.min(k.muscle, head ? 0.26 : torso ? 0.44 : 0.6);
    // the pain: flinch away from the blow, a hand to the wound, breath knocked short
    k.hurt = 1; k.hurtDir = Math.sign(a.vel.x) || 1; k.wound = { stick: hit.stick, u: hit.u }; k.exert = Math.min(1, k.exert + 0.45);
    f.plat.vel += head ? 120 : 80;
    this.burst(a.p, back, head ? 14 : 8, '#d3141f', head ? 330 : 240);
    this.parts.push({ p: { ...a.p }, vel: v(0, 0), life: 0, max: 0.22, r: head ? 26 : 18, col: '#ffffff', grav: 0, kind: 'ring' });
    this.hitStop = head ? 0.07 : 0.035;
    this.shake = Math.max(this.shake, (head ? 9 : 5) * (this.demo ? 0.3 : 1));
    snd.hit(pan, head);
    if (!fatal) snd.grunt(pan, f.pitch);
    // every hit shows what it did inside. A head shot gets the full treatment - the world goes dark and the camera
    // closes in on the whole skeleton; anywhere else a small X-ray window opens over just the bone that was hit
    if (!this.demo && !helmHit) {
      const full = head;
      this.xray = { f, stick: hit.stick, u: hit.u, pt: { ...tip }, ang: a.ang, t: 0, dur: full ? (f.team === 0 ? 0.42 : fatal ? 0.8 : 0.5) : fatal ? 0.6 : 0.36, full };
      if (full) { this.ts = 0.03; this.hitStop = 0; this.focus = { ...a.p }; snd.crack(pan); snd.xray(); }
      else snd.snap(pan);
    }
    const hx = k.p[0].x; const hy = k.p[0].y - (HEAD_R + 22) * k.s;
    if (f.team === 1) {
      this.say(hx + (rand() - 0.5) * 16, hy, `-${dmg}`, head ? '#ffe14d' : '#ffffff', head ? 22 : 17);
      if (head && !fatal) this.say(hx, hy - 20, 'HEADSHOT!', '#ffe14d', 17, 1.1);
      else if (heart && !fatal) this.say(hx, hy - 20, 'JANTUNG!', '#ff9a9a', 16, 1.1);
      if (!this.demo) {
        this.lvHits++; this.combo++;
        if (this.combo >= 2) {
          const bonus = Math.min(this.combo - 1, 5);
          this.spawnCoins(this.player.k.p[0], bonus);
          this.say(this.player.k.p[0].x + 60, this.player.k.p[0].y - 64, `COMBO x${this.combo}  +${bonus}`, '#7fe9f2', 16, 1.2);
          snd.combo(this.combo);
        }
      }
      // a staggered archer loses his draw
      if (f.ai.state !== 'wait' && (head || torso)) { f.ai.state = 'wait'; f.ai.t = 0.8 + rand() * 0.5; }
      else f.ai.t = Math.max(f.ai.t, 0.7);
      if (!fatal) {
        // a hard enough blow takes his balance: sat down half off the edge, dropped to a knee, or windmilling -
        // and each time he finds his feet again
        const leg = hit.stick >= 2 && hit.stick <= 5;
        const strong = Math.hypot(a.vel.x, a.vel.y) > 900;
        if (head && f.kind !== 'boss' && f.kind !== 'axer') { startReact(k, 'down', 2.1); snd.thud(pan, 0.28); snd.hup(pan, f.pitch, 1.05); }
        else if (leg) { startReact(k, 'knee', 1.35); snd.thud(pan, 0.16); }
        else if ((torso && strong) || head) { startReact(k, 'teeter', 1.05); snd.whoa(pan, f.pitch); }
        if (k.react !== 'none') { f.ai.state = 'wait'; f.ai.t = Math.max(f.ai.t, k.rdur + 0.3); }
      }
    } else {
      this.say(hx, hy, `-${dmg}`, '#ff6b6b', 20);
      if (!this.demo) { this.hurt = 1; this.lvHurt += dmg; }
      if (this.demo) { f.ai.state = 'wait'; f.ai.t = 0.8; }
    }
    if (fatal) this.die(f, head);
  }

  private die(f: Fighter, head: boolean) {
    const k = f.k; const pan = this.pan(k.p[1].x);
    k.alive = false; k.muscle = 0; k.pull = 0; k.hasBow = false; f.hp = 0;
    // a headshot drops him like a cut string; anything else and he folds over the wound first
    k.fade = head ? 0.05 : 0.38; k.hurt = 1;
    snd.cry(pan, f.pitch); snd.fall(pan);
    this.bows.push({
      p: { ...k.p[4] }, vel: v(((k.p[4].x - k.o[4].x) / H) * 0.6 + (rand() - 0.5) * 140, ((k.p[4].y - k.o[4].y) / H) * 0.6 - 190),
      ang: k.bowAng, vr: (rand() - 0.5) * 16, s: k.s,
    });
    if (f.team === 1) {
      f.plat.sinkT = 1.7;
      this.spawnT = Math.max(this.spawnT, this.demo ? 1.4 : 0.6);
      if (this.demo) return;
      this.kills++; this.totalKills++;
      if (head) this.headshots++;
      const reward = (f.kind === 'boss' || f.kind === 'axer' ? 60 : f.kind === 'heavy' ? 12 : f.kind === 'helm' ? 7 : 5) + (head ? 5 : 0);
      this.spawnCoins(k.p[1], reward);
      const hx = k.p[0].x; const hy = k.p[0].y - (HEAD_R + 44) * k.s;
      this.say(hx, hy, head ? `HEADSHOT! +${reward}` : `+${reward}`, '#ffd23f', head ? 21 : 18, 1.3);
      if (this.up.leech) this.player.hp = Math.min(this.player.maxHp, this.player.hp + 5 * this.up.leech);
      const last = this.kills >= this.total && this.hostState !== 1;
      this.slowT = last ? 1.2 : 0.3; this.slowK = last ? 0.16 : 0.3;
      if (last) this.beginClear(k.p[1]);
      else if (this.kills >= this.total) { this.banner = 2.4; this.bannerText = 'BEBASKAN TAWANAN!'; this.bannerSub = 'PANAH TEPAT DI TALINYA'; }
    } else {
      this.stage = 'dying'; this.deadT = 0; this.drag.on = false;
      this.slowT = 1.4; this.slowK = 0.2;
      this.zoomTo = 1.16; if (!(this.xray && this.xray.full)) this.focus = { ...k.p[1] };
    }
  }

  /* ---------------- simulation ---------------- */

  private step() {
    this.t += H;
    const pl = this.pPlat;
    pl.fy = damp(pl.fy, this.pFyT, 1.4, H);
    const all = [pl, ...this.plats];
    for (const p of all) {
      p.vel += (-p.off * 110 - p.vel * 9) * H; p.off += p.vel * H;
      if (p !== pl) {
        if (p.state === 'rise') { p.rise = Math.min(1, p.rise + H / 1.1); if (p.rise >= 1) p.state = 'on'; }
        else if (p.state === 'on' && p.sinkT > 0) { p.sinkT -= H; if (p.sinkT <= 0) p.state = 'sink'; }
        else if (p.state === 'sink') { p.rise -= H / 1.4; if (p.rise <= 0) p.state = 'off'; }
      }
      this.placePlat(p);
      // crumbs of earth drift off the underside
      if (p.state === 'on' && rand() < 0.005) {
        this.parts.push({ p: v(p.x + (rand() - 0.5) * p.w * 0.8, p.y + p.h), vel: v((rand() - 0.5) * 8, 14), life: 0, max: 0.9 + rand() * 0.6, r: 1 + rand() * 1.4, col: this.theme.platTop, grav: 260 });
      }
    }
    this.plats = this.plats.filter((p) => p.state !== 'off');
    // a ground that is still floating in (or sinking away) only carries its own archer
    const slabs = all.filter((p) => p.state === 'on').map(toSlab);
    const slabsFor = (f: Fighter) => (f.plat.state === 'on' ? slabs : [...slabs, toSlab(f.plat)]);

    const pf = this.player; const pk = pf.k;
    pk.base = v(pl.x, pl.y);
    pk.vigor = clamp(pf.hp / pf.maxHp, 0, 1);
    let nearest: Fighter | null = null; let nd = 1e9;
    for (const f of this.foes) {
      if (!f.k.alive || f.plat.state !== 'on') continue;
      const d = dist(f.k.p[1], pk.p[1]);
      if (d < nd) { nd = d; nearest = f; }
    }
    if (pk.alive) {
      const d = this.drag; let want = 0;
      const wasNock = pk.nock;
      if (pk.nock < 1) pk.nock = Math.min(1, pk.nock + H / 0.46);
      if (!this.demo) {
        if (wasNock < 0.55 && pk.nock >= 0.55) snd.quiver();
        if (wasNock < 1 && pk.nock >= 1) snd.nock();
      }
      if (this.demo) {
        this.think(pf, nearest, this.stage === 'play');
        pf.hp = Math.min(pf.maxHp, pf.hp + 5 * H);
      } else {
        // aim follows the drag; the draw follows with a little lag, like real arms taking the load
        this.holdAim -= H;
        if (d.on) {
          const dx = d.sx - d.x; const dy = d.sy - d.y; const L = Math.hypot(dx, dy);
          if (L > 6) {
            pk.aim = angLerp(pk.aim, clamp(Math.atan2(dy, dx), -1.45, 1.15), 1 - Math.exp(-22 * H));
            want = clamp((L - 6) / this.pullPx, 0, 1);
          }
          pk.aiming = damp(pk.aiming, 1, 14, H);
        } else pk.aiming = damp(pk.aiming, this.holdAim > 0 ? 1 : 0, 5, H);
        if (!onString(pk)) want = 0;
        // the last part of the draw is the heaviest: it comes slower
        pk.pull = damp(pk.pull, want, want > pk.pull ? 17 - 7 * pk.pull : 20, H);
        if (pk.pull > this.creakAt) { snd.creak(pk.pull); this.creakAt += 0.14; }
        if (pk.pull < this.creakAt - 0.3) this.creakAt = Math.max(0.14, this.creakAt - 0.14);
      }
      pk.muscle = Math.min(1, pk.muscle + H * 1.1);
      // eyes: down the arrow while aiming, otherwise on the nearest danger
      let threat: V | null = null; let td = 420;
      for (const a of this.arrows) if (a.team === 1 && !a.stuckIn) { const dd = dist(a.p, pk.p[0]); if (dd < td) { td = dd; threat = a.p; } }
      pk.lookAt = (d.on && !this.demo) || pk.aiming > 0.5 ? null : threat ?? (nearest ? nearest.k.p[0] : null);
    } else pf.deadT += H;
    pf.vib += H; pf.flash = Math.max(0, pf.flash - H * 5);
    stepStick(pk, slabsFor(pf));

    for (const f of this.foes) {
      const k = f.k;
      f.vib += H; f.flash = Math.max(0, f.flash - H * 5); f.hpShow -= H;
      if (k.alive) {
        k.base = v(f.plat.x, f.plat.y);
        k.vigor = clamp(f.hp / f.maxHp, 0, 1);
        k.muscle = Math.min(1, k.muscle + H * 0.9);
        if (k.nock < 1) k.nock = Math.min(1, k.nock + H / (f.kind === 'axer' ? 1 : 0.6));
        this.think(f, pf, this.stage === 'play' && pk.alive && f.plat.state === 'on');
        // he watches you - and now and then glances away
        k.lookAt = k.aiming > 0.5 ? null : Math.sin(this.t * 0.45 + k.seed * 3) > 0.9 ? v(k.p[0].x + 80 * Math.sin(k.seed * 7), k.p[0].y - 60) : pk.p[0];
      } else f.deadT += H;
      stepStick(k, slabsFor(f));
      // blood drips from a fresh wound
      if (k.hurt > 0.2 && k.alive && rand() < 0.2) {
        const wp = woundPoint(k);
        if (wp) this.parts.push({ p: wp, vel: v((rand() - 0.5) * 40, -10 + rand() * 30), life: 0, max: 0.5 + rand() * 0.3, r: 1.3 + rand() * 1.3, col: '#c4121c', grav: 900 });
      }
    }
    if (pk.hurt > 0.2 && pk.alive && rand() < 0.2) {
      const wp = woundPoint(pk);
      if (wp) this.parts.push({ p: wp, vel: v((rand() - 0.5) * 40, -10 + rand() * 30), life: 0, max: 0.5 + rand() * 0.3, r: 1.3 + rand() * 1.3, col: '#c4121c', grav: 900 });
    }
    this.foes = this.foes.filter((f) => f.k.alive || (f.deadT < 6 && f.k.p[2].y < this.VH + 260));

    // the prisoner: squirming while tied; once free he celebrates, then his ground carries him away
    const hs = this.hostage;
    if (hs) {
      const hk = hs.k;
      hk.base = v(hs.plat.x, hs.plat.y); hk.muscle = Math.min(1, hk.muscle + H); hk.lookAt = pk.p[0];
      hk.happy = damp(hk.happy, this.hostState === 2 ? 1 : 0, 7, H);
      hs.flash = Math.max(0, hs.flash - H * 5);
      stepStick(hk, slabsFor(hs));
      if (this.hostState === 2) {
        this.freeT += H;
        if (this.freeT > 1.9 && hs.plat.state === 'on' && hs.plat.sinkT <= 0) hs.plat.sinkT = 0.01;
      }
      if (hs.plat.state === 'off') this.hostage = null;
    }

    // axes in the air: heavy, slow, spinning - and they hurt
    for (const ax of this.axes) {
      ax.life += H; ax.vel.y += 620 * H; ax.p = add(ax.p, mul(ax.vel, H)); ax.ang += ax.vr * H;
      if (!ax.spent) {
        if (Math.floor(ax.life / 0.26) !== Math.floor((ax.life - H) / 0.26)) snd.whup(this.pan(ax.p.x));
        if (pk.alive && Math.abs(ax.p.x - pk.p[2].x) < 70 && Math.abs(ax.p.y - pk.p[2].y) < 100) {
          let near = dist(ax.p, pk.p[0]) - HEAD_R;
          for (const [ia, ib] of RAG_STICKS) near = Math.min(near, segDist(ax.p, pk.p[ia], pk.p[ib]).d);
          if (near < 15) this.axeHit(ax);
        }
      }
      if (ax.p.y > this.VH + 160 || ax.p.x < -200 || ax.p.x > this.VW + 300) ax.dead = true;
    }
    this.axes = this.axes.filter((x) => !x.dead);

    // arrows
    for (const a of this.arrows) {
      a.life += H;
      if (a.stuckIn) {
        a.p = v(a.stuckIn.x + a.ox, a.stuckIn.y + a.oy);
        if (a.life > 5 || a.stuckIn.state === 'off') a.dead = true;
        continue;
      }
      a.prev = { ...a.p };
      a.vel.y += AG * H;
      a.p = add(a.p, mul(a.vel, H));
      a.ang = Math.atan2(a.vel.y, a.vel.x);
      const end = { ...a.p };
      if (a.team === 1 && !a.near && pk.alive && !this.demo && dist(a.p, pk.p[0]) < 80) { a.near = true; snd.whoosh(this.pan(a.p.x)); }
      for (const tt of [0.5, 1]) {
        const tip = lerpV(a.prev, end, tt);
        if (a.team === 0) {
          // an axe in the air can be shot down
          const ax = this.axes.find((x) => !x.spent && dist(tip, x.p) < 24 * x.s);
          if (ax) { this.parry(ax, a); break; }
          // the prisoner: the rope is the target, the man is not
          if (hs && this.hostState === 1 && hs.plat.state === 'on') {
            const [top, bot] = this.rope(hs);
            if (segDist(tip, top, bot).d < 7) this.freeHostage(tip);
            else {
              const hh = this.hitTest(tip, hs);
              if (hh) { a.p = tip; this.hostageHit(a, hs, hh); break; }
            }
          }
        }
        for (const f of a.team === 0 ? this.foes : [pf]) {
          const hit = this.hitTest(tip, f);
          if (hit) { a.p = tip; this.onHit(a, f, hit); break; }
        }
        if (a.dead) break;
        if (a.team === 0) {
          for (const b of this.balloons) {
            if (dist(tip, v(b.x, b.y)) < 19) { this.popBalloon(b); break; }
          }
        }
        const sl = all.find((p) => p.rise > 0.6 && tip.x > p.x - p.w / 2 && tip.x < p.x + p.w / 2 && tip.y > p.y && tip.y < p.y + p.h);
        if (sl) {
          const in4 = add(tip, fromAngle(a.ang, 9)); // well into the wood: the ground is drawn over the buried end
          a.stuckIn = sl; a.ox = in4.x - sl.x; a.oy = in4.y - sl.y; a.life = 0;
          sl.vel += 30;
          this.burst(tip, mul(a.vel, -1), 4, this.theme.platTop, 150);
          snd.wood(this.pan(tip.x));
          if (a.team === 0 && a.main) this.combo = 0;
          break;
        }
      }
      if (a.p.y > this.VH + 140 || a.p.x < -320 || a.p.x > this.VW + 320) { a.dead = true; if (a.team === 0 && a.main) this.combo = 0; }
    }
    this.arrows = this.arrows.filter((a) => !a.dead);

    for (const p of this.parts) {
      p.life += H;
      p.vel.y += p.grav * H; p.p = add(p.p, mul(p.vel, H));
      if (p.rot !== undefined) p.rot += H * 9;
    }
    this.parts = this.parts.filter((p) => p.life < p.max);
    for (const b of this.bows) { b.vel.y += 1100 * H; b.p = add(b.p, mul(b.vel, H)); b.ang += b.vr * H; }
    this.bows = this.bows.filter((b) => b.p.y < this.VH + 120);
    for (const b of this.balloons) { b.y -= 46 * H; b.x += Math.sin(this.t * 1.4 + b.phase) * 12 * H; }
    this.balloons = this.balloons.filter((b) => b.y > -70);

    if (this.stage === 'play') {
      this.spawnT -= H;
      const alive = this.foes.reduce((n, f) => n + (f.k.alive ? 1 : 0), 0);
      if (alive < this.maxAlive && this.spawned < this.total && this.spawnT <= 0) { this.spawnEnemy(); this.spawnT = this.demo ? 1.2 : 0.55; }
      this.balloonT -= H;
      if (this.balloonT <= 0 && !this.demo) {
        this.balloonT = 12 + rand() * 9;
        this.balloons.push({ x: this.VW * (0.3 + rand() * 0.16), y: this.VH + 40, kind: pf.hp < pf.maxHp * 0.8 ? 'heart' : 'coin', phase: rand() * 6 });
      }
    }
  }

  private popBalloon(b: Balloon) {
    this.balloons = this.balloons.filter((x) => x !== b);
    const p = v(b.x, b.y);
    this.burst(p, v(0, -1), 12, b.kind === 'heart' ? '#ff5a5f' : '#ffc933', 220);
    snd.pop(this.pan(b.x));
    if (b.kind === 'heart') {
      const pf = this.player;
      pf.hp = Math.min(pf.maxHp, pf.hp + 30);
      this.say(b.x, b.y - 20, '+30 NYAWA', '#7dffa0', 18, 1.2);
      snd.heal();
    } else {
      this.spawnCoins(p, 10);
      this.say(b.x, b.y - 20, '+10', '#ffd23f', 18, 1.2);
    }
  }

  update(dtReal: number) {
    const dt = Math.min(Math.max(dtReal, 0), 0.05);
    this.rt += dt;
    ambTick(dt, THEMES.indexOf(this.theme));
    // the camera breathes, and leans a little toward where you aim
    const pk = this.player.k;
    this.cam = damp(this.cam, Math.sin(this.rt * 0.11) * 0.55 + (this.drag.on ? Math.cos(pk.aim) * 0.3 * pk.pull : 0), 2, dt);
    if (this.xray) { this.xray.t += dt; if (this.xray.t >= this.xray.dur) this.xray = null; }
    const fullX = !!this.xray && this.xray.full; // only the head shot takes over the camera
    this.zoom = damp(this.zoom, fullX ? 2.3 : this.zoomTo, fullX ? 16 : 5, dt);
    this.panK = damp(this.panK, fullX ? 0.82 : 0, fullX ? 16 : 6, dt);
    this.stepCoins(dt);
    this.birdT -= dt;
    if (this.birdT <= 0) {
      this.birdT = 11 + rand() * 16;
      const dir = rand() < 0.5 ? 1 : -1;
      this.birds.push({ x: dir > 0 ? -0.08 : 1.08, y: 0.08 + rand() * 0.22, vx: dir * (0.045 + rand() * 0.03), n: 3 + Math.floor(rand() * 3), ph: rand() * 6 });
    }
    for (const b of this.birds) b.x += b.vx * dt;
    this.birds = this.birds.filter((b) => b.x > -0.3 && b.x < 1.3);
    if (!this.paused) {
      if (this.hitStop > 0) this.hitStop -= dt;
      else {
        // an X-ray all but stops the clock; the kill's slow motion picks up after it
        if (!fullX) this.slowT -= dt;
        const pace = this.slowT > 0 ? this.slowK : 1;
        this.ts = fullX ? 0.03 : damp(this.ts, this.xray ? Math.min(0.3, pace) : pace, 14, dt);
        this.acc += dt * this.ts;
        let guard = 0;
        while (this.acc >= H && guard++ < 10) { this.step(); this.acc -= H; }
        if (guard >= 10) this.acc = 0;
      }
      this.shake = Math.max(0, this.shake - dt * 28);
      this.hurt = Math.max(0, this.hurt - dt * 2.2);
      this.banner = Math.max(0, this.banner - dt);
      for (const t of this.texts) t.life += dt;
      this.texts = this.texts.filter((t) => t.life < t.max);
      const pf = this.player;
      if (!this.demo && pf.k.alive && pf.hp < pf.maxHp * 0.3 && this.stage === 'play') {
        this.heartT -= dt;
        if (this.heartT <= 0) { this.heartT = 0.85; snd.heart(); }
      }
      if (fullX) { /* the moment holds */ }
      else if (this.stage === 'clear') {
        this.clearT += dt;
        if (this.clearT > 1.3) this.zoomTo = 1;
        if (this.clearT > 0.95 && !this.rewardPaid) { this.rewardPaid = true; this.spawnCoins(v(this.w / 2, this.h * 0.36 + 44), 10 + 2 * this.level, true); }
        if (this.clearT > 3.2) {
          this.pending = 0; this.coinFx = [];
          pf.hp = Math.min(pf.maxHp, Math.round(pf.hp + pf.maxHp * 0.4));
          this.stage = 'shop'; this.drag.on = false;
          snd.open();
        }
      } else if (this.stage === 'dying') {
        this.deadT += dt;
        if (this.deadT > 1.9) { this.stage = 'dead'; snd.lose(); }
      }
    }
    this.emitUi();
  }

  private emitUi() {
    const pf = this.player;
    const ui: RUi = {
      stage: this.stage, demo: this.demo, level: this.level, kills: this.kills, total: this.demo ? 1 : this.total, grounds: this.maxAlive, coins: this.coins, shown: this.coins - this.pending, bump: this.bumpN, hostage: this.hostState,
      totalKills: this.totalKills, headshots: this.headshots, hp: Math.max(0, Math.round(pf.hp)), maxHp: pf.maxHp, best: this.best,
      boss: this.level % 5 === 0, hint: this.hint, paused: this.paused, theme: this.theme.name, stars: this.stars, reward: 10 + 2 * this.level, up: { ...this.up },
      cost: { hp: this.costOf('hp'), dmg: this.costOf('dmg'), multi: this.costOf('multi'), leech: this.costOf('leech') },
    };
    const key = JSON.stringify(ui);
    if (key !== this.last) { this.last = key; this.emit(ui); }
  }

  /* ---------------- drawing ---------------- */

  private drawFighter(ctx: Ctx, f: Fighter) {
    const k = f.k;
    const fl = Math.round(f.flash * 215);
    const big = f.kind === 'boss' || f.kind === 'axer';
    const look: StickLook = {
      color: fl > 4 ? `rgb(${fl},${Math.round(fl * 0.1)},${Math.round(fl * 0.1)})` : '#000000',
      rim: fl > 4 ? null : this.theme.rim,
      eye: big || f.kind === 'heavy' ? '#ff4b4b' : '#ffffff',
      helm: f.helm, crown: f.kind === 'boss', horns: f.kind === 'axer',
      band: f.kind === 'player' ? '#e5352f' : f.kind === 'boss' ? '#8f1220' : f.kind === 'hostage' ? '#5ad1ff' : null,
      quiver: f.kind !== 'axer' && f.kind !== 'hostage', bound: f.kind === 'hostage' && this.hostState === 1,
    };
    const base = ctx.globalAlpha;
    if (f.kind !== 'hostage') ctx.globalAlpha = f.deadT > 5 ? clamp(6 - f.deadT, 0, 1) : 1;
    drawStick(ctx, k, look, () => {
      if (f.kind === 'axer') {
        // the next axe is in his hand as soon as he has reached back for it
        if (k.alive && k.nock > 0.6) drawAxe(ctx, k.p[4], Math.atan2(k.p[4].y - k.p[3].y, k.p[4].x - k.p[3].x) - k.face * 0.25, k.s * 1.25);
        return;
      }
      if (!k.hasBow) return;
      const hold = onString(k);
      const vib = f.vib < 0.5 ? Math.exp(-f.vib * 12) * Math.cos(f.vib * 85) * 7 : 0;
      drawBow(ctx, k.p[4], k.bowAng, k.s, hold ? dist(k.p[4], k.p[6]) : null, vib, k.nock >= 1);
      if (k.nock < 1 && k.nock > 0.55) drawArrow(ctx, add(k.p[6], fromAngle(k.bowAng, ARROW_LEN * k.s)), k.bowAng, k.s);
    }, () => {
      // arrows in him go down first: the body then closes over the buried points, so each shaft sits flush
      for (const st of f.stuck) {
        const [ia, ib] = RAG_STICKS[st.stick];
        const A = k.p[ia]; const B = k.p[ib];
        const ba = Math.atan2(B.y - A.y, B.x - A.x); const c = Math.cos(ba); const sn = Math.sin(ba);
        drawArrow(ctx, v(A.x + st.lx * c - st.ly * sn, A.y + st.lx * sn + st.ly * c), ba + st.rel, 1, true);
      }
    });
    ctx.globalAlpha = f.kind === 'hostage' ? base : 1;
  }

  private drawBar(ctx: Ctx, f: Fighter, col: string) {
    const k = f.k; const s = k.s;
    const bw = 46 * s; const x = k.p[0].x - bw / 2; const y = k.p[0].y - (HEAD_R + 16) * s - (f.kind === 'boss' ? 12 : f.kind === 'axer' ? 22 : 0);
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(x - 1.5, y - 1.5, bw + 3, 8);
    ctx.fillStyle = col; ctx.fillRect(x, y, bw * clamp(f.hp / f.maxHp, 0, 1), 5);
  }

  private text(ctx: Ctx, s: string, x: number, y: number, size: number, col: string, alpha = 1) {
    ctx.globalAlpha = alpha;
    ctx.font = `italic 900 ${size}px ${FONT}`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(3, size * 0.2); ctx.strokeStyle = 'rgba(0,18,30,0.6)';
    ctx.strokeText(s, x, y);
    ctx.fillStyle = col; ctx.fillText(s, x, y);
    ctx.globalAlpha = 1;
  }

  /** everything that lives in the forest behind and in front of the fight */
  private ambience(ctx: Ctx, W: number, Hh: number, part: 'sky' | 'mid' | 'front', off: number) {
    const th = this.theme; const dpr = this.dpr; const rt = this.rt;
    const u = Math.max(0.5, Math.min(W, Hh * 1.5) / (1100 * dpr));
    if (part === 'sky') {
      // shafts of light through the canopy
      ctx.globalCompositeOperation = 'lighter';
      const leanX = Math.tan(th.disc[0] > 0.5 ? -0.36 : 0.36) * Hh;
      for (const r of this.rays) {
        const a = 0.05 + 0.04 * Math.sin(rt * 0.35 + r.ph);
        const x = r.x * W + off + Math.sin(rt * 0.12 + r.ph) * 24 * dpr; const w0 = r.w * W;
        const g = ctx.createLinearGradient(x, 0, x + leanX, Hh * 0.95);
        g.addColorStop(0, `rgba(${th.ray},${a})`); g.addColorStop(1, `rgba(${th.ray},0)`);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.moveTo(x - w0 / 2, -10); ctx.lineTo(x + w0 / 2, -10); ctx.lineTo(x + leanX + w0 * 1.4, Hh * 0.95); ctx.lineTo(x + leanX - w0 * 1.4, Hh * 0.95); ctx.closePath(); ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
      // a flock crossing far away
      ctx.strokeStyle = th.tree; ctx.globalAlpha = 0.55; ctx.lineWidth = 1.8 * dpr * u; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (const b of this.birds) {
        const dir = Math.sign(b.vx);
        for (let i = 0; i < b.n; i++) {
          const x = (b.x - dir * i * 0.02) * W; const y = (b.y + (i % 2 ? 1 : -1) * i * 0.012 + Math.sin(rt * 0.9 + i + b.ph) * 0.006) * Hh;
          const s = (6 + (i % 3)) * dpr * u; const flap = Math.sin(rt * 9 + i * 1.3 + b.ph) * 0.7;
          ctx.beginPath(); ctx.moveTo(x - s, y - s * flap); ctx.quadraticCurveTo(x - s * 0.4, y - s * 0.25 * flap - s * 0.2, x, y); ctx.quadraticCurveTo(x + s * 0.4, y - s * 0.25 * flap - s * 0.2, x + s, y - s * flap); ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
    }
    if (part === 'sky' || part === 'front') {
      // fireflies: small and many among the trees, a few big soft ones close to the lens
      const front = part === 'front'; const spr = this.flySpr;
      if (spr) {
        ctx.globalCompositeOperation = 'lighter';
        for (const fl of this.flies) {
          if (fl.front !== front) continue;
          const t = rt * fl.sp;
          const b = Math.pow(Math.max(0, Math.sin(rt * fl.bl + fl.ph * 3)), 1.6);
          if (b < 0.02) continue;
          const x = (fl.x + Math.sin(t + fl.ph) * 0.035 + Math.sin(t * 0.37 + fl.ph * 2.1) * 0.05) * W;
          const y = (fl.y + Math.cos(t * 0.8 + fl.ph * 1.3) * 0.04 + Math.sin(t * 0.23 + fl.ph) * 0.03) * Hh;
          const r = fl.r * dpr * u;
          ctx.globalAlpha = b * (front ? 0.42 : 0.95);
          ctx.drawImage(spr as unknown as CanvasImageSource, x - r, y - r, r * 2, r * 2);
        }
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    }
    if (part === 'mid') {
      // vines swaying from the canopy
      ctx.strokeStyle = th.tree; ctx.fillStyle = th.tree; ctx.globalAlpha = 0.4; ctx.lineWidth = 2.4 * dpr * u; ctx.lineCap = 'round';
      for (const vn of this.vines) {
        const x = vn.x * W + off; const L = vn.len * Hh;
        const sw = Math.sin(rt * 0.8 + vn.ph) * L * 0.09 + Math.sin(rt * 1.9 + vn.ph * 2) * L * 0.02;
        ctx.beginPath(); ctx.moveTo(x, -4); ctx.quadraticCurveTo(x + sw * 0.35, L * 0.55, x + sw, L); ctx.stroke();
        let side = 1;
        for (const t of [0.3, 0.52, 0.72, 0.9, 1]) {
          const m = 1 - t;
          const px = m * m * x + 2 * m * t * (x + sw * 0.35) + t * t * (x + sw); const py = 2 * m * t * L * 0.55 + t * t * L;
          ctx.beginPath(); ctx.ellipse(px + side * 5 * dpr * u, py, 6.5 * dpr * u, 3.2 * dpr * u, side * 0.6, 0, Math.PI * 2); ctx.fill();
          side = -side;
        }
      }
      // low mist drifting between the trunks
      const mist = this.mistSpr;
      if (mist) {
        for (const m of this.mists) {
          const x = ((((m.x + rt * m.sp) % 1.5) + 1.5) % 1.5) - 0.25;
          ctx.globalAlpha = 0.1 + 0.04 * Math.sin(rt * 0.3 + m.y * 20);
          ctx.drawImage(mist as unknown as CanvasImageSource, x * W - W * 0.45, m.y * Hh - Hh * 0.11, W * 0.9, Hh * 0.22);
        }
      }
      // leaves tumbling down
      ctx.fillStyle = th.tree; ctx.globalAlpha = 0.5;
      for (const lf of this.leaves) {
        const y = ((lf.y + rt * lf.sp) % 1.15) - 0.08;
        const x = ((lf.x + Math.sin(rt * 0.9 + lf.ph) * 0.03 + rt * 0.012) % 1.1) - 0.05;
        ctx.save();
        ctx.translate(x * W, y * Hh); ctx.rotate(rt * lf.rs + lf.ph + Math.sin(rt * 1.7 + lf.ph));
        ctx.scale(1, 0.35 + 0.65 * Math.abs(Math.sin(rt * 1.3 + lf.ph)));
        ctx.beginPath(); ctx.ellipse(0, 0, lf.r * dpr * u, lf.r * dpr * u * 0.48, 0, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
    }
    if (part === 'front') {
      // tall grass right at the lens, moving with the wind
      ctx.fillStyle = th.fg; ctx.globalAlpha = 0.94;
      ctx.beginPath();
      const gust = Math.sin(rt * 0.5) * 0.12;
      for (const b of this.blades) {
        const x = b.x * W; const hh = b.h * dpr * u; const bw = b.w * dpr * u;
        const sw = (Math.sin(rt * 1.5 + b.x * 14 + b.ph) * 0.2 + Math.sin(rt * 0.63 + b.x * 5) * 0.16 + gust) * hh;
        ctx.moveTo(x - bw, Hh + 2);
        ctx.quadraticCurveTo(x + sw * 0.3 - bw * 0.3, Hh - hh * 0.6, x + sw, Hh - hh);
        ctx.quadraticCurveTo(x + sw * 0.3 + bw, Hh - hh * 0.5, x + bw, Hh + 2);
      }
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  /**
   * X-ray. A head shot is the Mortal-Kombat moment: the world goes dark and cold, the camera closes in and you
   * see the whole skeleton with the skull splitting. Any other hit opens a small window over just the bone that
   * was struck - no zoom, the fight carries on around it.
   */
  private drawXray(ctx: Ctx, W: number, Hh: number, shx: number, shy: number) {
    const x = this.xray;
    if (!x) return;
    const { w, h, dpr } = this; const k = x.f.k; const s = k.s;
    const u = x.t / x.dur;
    const e = clamp(x.t / 0.06, 0, 1) * clamp((x.dur - x.t) / 0.12, 0, 1);
    const [ck, cx0, cy0] = this.camTf();
    const world = () => ctx.setTransform(dpr * ck, 0, 0, dpr * ck, dpr * (cx0 + shx), dpr * (cy0 + shy));
    const inside = () => {
      // the flesh is only a dim blue shadow with a cold halo, and inside it, the bones
      ctx.shadowColor = 'rgba(60,180,255,0.95)'; ctx.shadowBlur = 14 * dpr;
      drawStick(ctx, k, { color: '#17588a', rim: null, eye: 'rgba(0,0,0,0)', helm: false, crown: false, band: null, quiver: false });
      ctx.shadowColor = 'rgba(170,240,255,0.95)'; ctx.shadowBlur = 7 * dpr;
      drawSkeleton(ctx, k, x.stick, x.pt, u, !x.full);
      ctx.shadowBlur = 0;
      drawArrow(ctx, add(x.pt, fromAngle(x.ang, 2)), x.ang, 1, false);
    };
    const chips = (n: number, reach: number) => {
      ctx.fillStyle = '#ecfcff';
      for (let i = 0; i < n; i++) {
        const a = x.ang + (i - (n - 1) / 2) * 0.33; const dd = 5 + u * (reach + i * 7);
        ctx.globalAlpha = e * (1 - u * 0.6);
        ctx.save();
        ctx.translate(x.pt.x + Math.cos(a) * dd, x.pt.y + Math.sin(a) * dd + u * u * 26); ctx.rotate(i * 2 + u * 9);
        ctx.beginPath(); ctx.moveTo(-2.4, -1.2); ctx.lineTo(2.6, 0); ctx.lineTo(-1.6, 1.8); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    };
    if (!x.full) {
      world();
      // the window: a capsule laid along the bone that was hit (for the chest, along that stretch of the spine)
      const [ia, ib] = RAG_STICKS[x.stick];
      let A = k.p[ia]; let B = k.p[ib];
      if (x.stick === 1) { A = lerpV(k.p[2], k.p[1], clamp(x.u - 0.2, 0, 1)); B = lerpV(k.p[2], k.p[1], clamp(x.u + 0.2, 0, 0.97)); }
      const r = (x.stick === 1 ? 17 : 14) * s * (0.55 + 0.45 * ease.out(Math.min(1, x.t / 0.09)));
      const ang = Math.atan2(B.y - A.y, B.x - A.x);
      const path = () => { ctx.beginPath(); ctx.arc(A.x, A.y, r, ang + Math.PI / 2, ang - Math.PI / 2); ctx.arc(B.x, B.y, r, ang - Math.PI / 2, ang + Math.PI / 2); ctx.closePath(); };
      ctx.save();
      path(); ctx.clip();
      ctx.globalAlpha = 0.95 * e; ctx.fillStyle = '#03101f';
      ctx.fillRect(Math.min(A.x, B.x) - r - 4, Math.min(A.y, B.y) - r - 4, Math.abs(A.x - B.x) + r * 2 + 8, Math.abs(A.y - B.y) + r * 2 + 8);
      ctx.globalAlpha = e;
      inside();
      ctx.restore();
      ctx.shadowColor = 'rgba(120,225,255,0.95)'; ctx.shadowBlur = 8 * dpr;
      ctx.strokeStyle = '#bff4ff'; ctx.lineWidth = 1.8; ctx.globalAlpha = e;
      path(); ctx.stroke();
      ctx.shadowBlur = 0;
      chips(4, 20);
      const mid = lerpV(A, B, 0.5);
      const label = x.stick === 1 ? 'RUSUK RETAK!' : x.stick <= 5 ? 'TULANG KAKI RETAK!' : 'TULANG LENGAN RETAK!';
      this.text(ctx, label, mid.x, Math.min(A.y, B.y) - r - 11 - u * 8, 12 * (1 + 0.3 * Math.max(0, 1 - u * 5)), '#dffaff', e);
      ctx.globalAlpha = 1;
      return;
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 0.84 * e; ctx.fillStyle = '#020a18'; ctx.fillRect(0, 0, W, Hh);
    world();
    ctx.globalAlpha = e;
    inside();
    // the shock of the impact, a red ring, chips of bone leaving with the arrow
    const pop = Math.max(0, 1 - u * 2.2);
    ctx.strokeStyle = '#ffffff'; ctx.lineCap = 'round';
    for (let i = 0; i < 9; i++) {
      const a = i * 0.7 + 0.3; const r0 = 9 + u * 30; const r1 = r0 + (10 + (i % 3) * 7) * (0.4 + pop);
      ctx.globalAlpha = e * (0.3 + 0.7 * pop); ctx.lineWidth = 2.2 * (0.4 + pop);
      ctx.beginPath(); ctx.moveTo(x.pt.x + Math.cos(a) * r0, x.pt.y + Math.sin(a) * r0); ctx.lineTo(x.pt.x + Math.cos(a) * r1, x.pt.y + Math.sin(a) * r1); ctx.stroke();
    }
    ctx.strokeStyle = '#ff4d4d'; ctx.globalAlpha = e * (1 - u); ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(x.pt.x, x.pt.y, 6 + u * 30, 0, Math.PI * 2); ctx.stroke();
    chips(7, 34);
    // on the glass: scan lines, a cold vignette, and what just happened
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalAlpha = 0.07 * e; ctx.fillStyle = '#9fe6ff';
    for (let y = (this.rt * 60) % 4; y < h; y += 4) ctx.fillRect(0, y, w, 1);
    ctx.globalAlpha = e;
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.72);
    g.addColorStop(0, 'rgba(30,120,200,0)'); g.addColorStop(1, 'rgba(30,120,200,0.4)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const size = clamp(w * 0.05, 22, 44) * (1 + 0.35 * Math.max(0, 1 - u * 5));
    this.text(ctx, 'TENGKORAK RETAK!', w / 2 + (rand() - 0.5) * 3 * pop, h * 0.84, size, '#eafcff', e);
    ctx.globalAlpha = 1;
  }

  render(ctx: Ctx) {
    const { w, h, dpr } = this;
    const W = Math.round(w * dpr); const Hh = Math.round(h * dpr);
    const th = this.theme;
    const key = `${W}x${Hh}:${th.name}`;
    if (key !== this.sceneKey || !this.scene) {
      this.scene = paintScene(W, Hh, th, THEMES.indexOf(th) + 1, this.make);
      this.flySpr = glowSprite(this.make, th.fly, 64);
      if (!this.mistSpr) this.mistSpr = glowSprite(this.make, '#ffffff', 128);
      if (!this.goldSpr) this.goldSpr = glowSprite(this.make, '#ffc933', 64);
      this.sceneKey = key;
    }
    const sn = this.scene; const pad = sn.pad; const cam = clamp(this.cam, -1, 1);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    ctx.drawImage(sn.sky as unknown as CanvasImageSource, -pad - cam * pad * 0.25, 0);
    this.ambience(ctx, W, Hh, 'sky', -cam * pad * 0.3);
    ctx.drawImage(sn.near as unknown as CanvasImageSource, -pad - cam * pad * 0.55, 0);
    this.ambience(ctx, W, Hh, 'mid', -cam * pad * 0.55);
    ctx.drawImage(sn.hills as unknown as CanvasImageSource, -pad - cam * pad * 0.9, 0);

    const shx = (rand() - 0.5) * this.shake; const shy = (rand() - 0.5) * this.shake;
    const [ck, cx0, cy0] = this.camTf();
    ctx.setTransform(dpr * ck, 0, 0, dpr * ck, dpr * (cx0 + shx), dpr * (cy0 + shy));

    for (const b of this.balloons) {
      const col = b.kind === 'heart' ? '#ff5a5f' : '#ffc933';
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(b.x, b.y + 17); ctx.quadraticCurveTo(b.x + Math.sin(this.t * 3 + b.phase) * 5, b.y + 30, b.x, b.y + 42); ctx.stroke();
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(b.x, b.y, 14, 17, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(b.x - 3.5, b.y + 16); ctx.lineTo(b.x + 3.5, b.y + 16); ctx.lineTo(b.x, b.y + 21); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath(); ctx.ellipse(b.x - 5, b.y - 7, 3, 5, -0.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `900 14px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(b.kind === 'heart' ? '+' : '$', b.x + 1, b.y + 1);
    }

    // arrows stuck in a ground go down first, so the ground closes over the buried point
    for (const a of this.arrows) if (a.stuckIn) { ctx.globalAlpha = clamp(5 - a.life, 0, 1); drawArrow(ctx, a.p, a.ang, 1, true); }
    ctx.globalAlpha = 1;
    // the floating grounds, each on its own cushion of light
    for (const p of [this.pPlat, ...this.plats]) {
      const x = p.x - p.w / 2;
      ctx.globalAlpha = (p.state === 'on' ? 1 : clamp(p.rise * 1.6, 0, 1)) * (0.75 + 0.25 * Math.sin(this.rt * 2.2 + p.phase));
      const g = ctx.createLinearGradient(0, p.y + p.h, 0, p.y + p.h + 38);
      g.addColorStop(0, th.glow); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.fillRect(x + 5, p.y + p.h, p.w - 10, 38);
      ctx.globalAlpha = p.state === 'on' ? 1 : clamp(p.rise * 1.6, 0, 1);
      ctx.fillStyle = th.plat; ctx.fillRect(x, p.y, p.w, p.h);
      ctx.fillStyle = th.platTop; ctx.fillRect(x, p.y, p.w, 3.5);
    }
    ctx.globalAlpha = 1;

    for (const f of this.foes) if (!f.k.alive) this.drawFighter(ctx, f);
    for (const f of this.foes) if (f.k.alive) this.drawFighter(ctx, f);
    this.drawHostage(ctx);
    this.drawFighter(ctx, this.player);
    for (const b of this.bows) drawBow(ctx, b.p, b.ang, b.s, null, 0, false);
    for (const ax of this.axes) {
      // a spinning axe with two ghosts of where it just was
      for (const [back, al] of [[0.5, 0.18], [0.25, 0.32], [0, 1]]) {
        ctx.globalAlpha = ax.spent ? al * 0.7 : al;
        const an = ax.ang - ax.vr * 0.045 * back * 2;
        drawAxe(ctx, add(ax.p, fromAngle(an, -12 * ax.s)), an, ax.s);
      }
      ctx.globalAlpha = 1;
    }
    ctx.lineCap = 'round';
    for (const a of this.arrows) {
      if (a.stuckIn) continue;
      // a streak of air behind every arrow in flight
      const tail = add(a.p, mul(a.vel, -0.045));
      const g = ctx.createLinearGradient(a.p.x, a.p.y, tail.x, tail.y);
      g.addColorStop(0, 'rgba(255,255,255,0.4)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = g; ctx.lineWidth = 2.6;
      ctx.beginPath(); ctx.moveTo(a.p.x, a.p.y); ctx.lineTo(tail.x, tail.y); ctx.stroke();
      drawArrow(ctx, a.p, a.ang, 1, false);
    }

    for (const p of this.parts) {
      const u = p.life / p.max;
      if (p.kind === 'ring') {
        ctx.globalAlpha = (1 - u) * 0.9; ctx.strokeStyle = p.col; ctx.lineWidth = 3.5 * (1 - u) + 0.5;
        ctx.beginPath(); ctx.arc(p.p.x, p.p.y, p.r * (0.25 + 0.75 * ease.out(u)), 0, Math.PI * 2); ctx.stroke();
        continue;
      }
      ctx.globalAlpha = clamp(1 - u, 0, 1) ** 0.6;
      ctx.fillStyle = p.col;
      ctx.beginPath();
      if (p.kind === 'helm') { ctx.arc(p.p.x, p.p.y, p.r, (p.rot ?? 0) - 1.75 - Math.PI / 2, (p.rot ?? 0) + 1.75 - Math.PI / 2); ctx.closePath(); }
      else ctx.arc(p.p.x, p.p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    if (!this.demo) {
      for (const f of this.foes) {
        const big = f.kind === 'boss' || f.kind === 'axer';
        if (f.k.alive && (f.hpShow > 0 || big)) this.drawBar(ctx, f, big ? '#ffc933' : '#ff5a4f');
        // the axe boss winding up: a warning over his head
        if (f.kind === 'axer' && f.k.alive && f.ai.state !== 'wait') this.text(ctx, '!', f.k.p[0].x, f.k.p[0].y - 58 * f.k.s, 26 + 6 * Math.sin(this.rt * 22), '#ff5a4f', 1);
      }
      if (this.player.k.alive) this.drawBar(ctx, this.player, this.player.hp < this.player.maxHp * 0.3 ? '#ff5a4f' : '#5cf08a');
    }

    for (const t of this.texts) {
      const u = t.life / t.max;
      this.text(ctx, t.text, t.x, t.y - ease.out(u) * 38, t.size * (1 + 0.5 * Math.max(0, 1 - u * 6)), t.col, clamp((1 - u) * 2.5, 0, 1));
    }

    // a short, honest preview: it starts at the real bow hand and wobbles with the body
    const pk = this.player.k;
    if (this.drag.on && pk.alive && onString(pk) && pk.pull > 0.06) {
      const ang = fireAngle(pk); const sp = speedOf(pk.pull);
      const o = add(pk.p[4], fromAngle(ang, 14)); const vel = fromAngle(ang, sp);
      ctx.fillStyle = '#ffffff';
      for (let i = 1; i <= 11; i++) {
        const tt = i * 0.036;
        ctx.globalAlpha = 0.85 - i * 0.065;
        ctx.beginPath(); ctx.arc(o.x + vel.x * tt, o.y + vel.y * tt + 0.5 * AG * tt * tt, 3.4 - i * 0.17, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    // back to the lens: big fireflies and the grass in front of everything
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ambience(ctx, W, Hh, 'front', 0);
    if (this.xray) this.drawXray(ctx, W, Hh, shx, shy);

    // screen space
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.drawCoins(ctx);
    const d = this.drag;
    if (d.on) {
      ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(d.sx, d.sy, 24, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = pk.pull > 0.92 ? '#ffb02e' : '#ffffff'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(d.sx, d.sy, 24, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * pk.pull); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.45)'; ctx.lineWidth = 2; ctx.setLineDash([5, 6]);
      ctx.beginPath(); ctx.moveTo(d.sx, d.sy); ctx.lineTo(d.x, d.y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.beginPath(); ctx.arc(d.x, d.y, 10, 0, Math.PI * 2); ctx.fill();
    }
    const pf = this.player;
    const lowHp = !this.demo && pf.k.alive && pf.hp < pf.maxHp * 0.3 ? 0.16 + 0.12 * Math.sin(this.rt * 7) : 0;
    const red = Math.max(this.hurt * 0.5, lowHp);
    if (red > 0.01) {
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.7);
      g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(255,20,30,${red})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    }
    const title = this.demo ? '' : this.stage === 'clear' ? 'LEVEL SELESAI!' : this.banner > 0 ? this.bannerText : '';
    if (title) {
      const clear = this.stage === 'clear';
      const al = clear ? clamp(this.clearT * 3, 0, 1) : clamp(this.banner * 2, 0, 1) * clamp((2.4 - this.banner) * 5, 0, 1);
      const pop = clear ? 1 + 0.25 * Math.max(0, 1 - this.clearT * 4) : 1 + 0.3 * Math.max(0, 1 - (2.4 - this.banner) * 5);
      const size = clamp(w * 0.075, 30, 66) * pop;
      // a dark band behind the words, like a title card
      ctx.globalAlpha = al * 0.38; ctx.fillStyle = '#00141f';
      ctx.fillRect(0, h * 0.36 - size * 0.75, w, size * 2.05);
      ctx.globalAlpha = 1;
      this.text(ctx, title, w / 2, h * 0.36, size, clear ? '#ffd23f' : '#ffffff', al);
      this.text(ctx, clear ? `+${10 + 2 * this.level} KOIN` : this.bannerSub, w / 2, h * 0.36 + size * 0.85, clamp(size * 0.3, 13, 20), '#dffcff', al);
    }
  }
}

/** binds a RagWorld to a real canvas: sizing, the frame loop and pointer input */
export class RagdollGame {
  world: RagWorld;
  private ctx: Ctx;
  private raf = 0;
  private prev = 0;

  constructor(private canvas: HTMLCanvasElement, emit: (ui: RUi) => void) {
    this.ctx = canvas.getContext('2d') as Ctx;
    this.world = new RagWorld(emit, (w, h) => {
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      return c;
    });
    this.fit();
    ambStart();
    window.addEventListener('resize', this.fit);
    canvas.addEventListener('pointerdown', this.down);
    canvas.addEventListener('pointermove', this.move);
    canvas.addEventListener('pointerup', this.up);
    canvas.addEventListener('pointercancel', this.cancel);
    this.raf = requestAnimationFrame(this.loop);
  }

  private fit = () => {
    const r = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(200, r.width); const h = Math.max(200, r.height);
    this.canvas.width = Math.round(w * dpr); this.canvas.height = Math.round(h * dpr);
    this.world.resize(w, h, dpr);
  };
  private pos(e: PointerEvent): [number, number] {
    const r = this.canvas.getBoundingClientRect();
    return [e.clientX - r.left, e.clientY - r.top];
  }
  private down = (e: PointerEvent) => {
    try { this.canvas.setPointerCapture(e.pointerId); } catch { /* fine without capture */ }
    this.world.pointerDown(...this.pos(e));
  };
  private move = (e: PointerEvent) => this.world.pointerMove(...this.pos(e));
  private up = () => this.world.pointerUp();
  private cancel = () => this.world.pointerCancel();
  private loop = (now: number) => {
    const dt = this.prev ? (now - this.prev) / 1000 : 0.016;
    this.prev = now;
    this.world.update(dt);
    this.world.render(this.ctx);
    this.raf = requestAnimationFrame(this.loop);
  };

  destroy() {
    cancelAnimationFrame(this.raf);
    ambStop();
    window.removeEventListener('resize', this.fit);
    this.canvas.removeEventListener('pointerdown', this.down);
    this.canvas.removeEventListener('pointermove', this.move);
    this.canvas.removeEventListener('pointerup', this.up);
    this.canvas.removeEventListener('pointercancel', this.cancel);
  }
}
