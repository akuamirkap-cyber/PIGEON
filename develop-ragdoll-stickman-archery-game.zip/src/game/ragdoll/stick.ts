// Active-ragdoll stickman, grown out of the verlet ragdoll in ../archerRag (same joints, same sticks, same
// punch). It is ALWAYS simulated. While alive, soft "muscles" pull every joint toward a pose, so the body
// lags, sways, recoils and staggers for real; when it dies the muscles let go and the same body crumples.
//
// What makes him feel alive lives in the pose: he breathes (deeper after effort, panting when wounded),
// shifts his weight, blinks and looks around, leans and anchors through the draw, flinches and clutches a
// wound, hunches when he is nearly done - and when a blow takes his balance he windmills on the edge,
// drops to a knee, or lands on his back half off the ground and hauls himself up again.
import { Ctx, V, v, add, sub, mul, len, dist, lerp, lerpV, fromAngle, ik, clamp, damp } from '../util';
import { RAG_STICKS } from '../archerRag';

// joints: 0 head, 1 neck, 2 hip, 3 bow elbow, 4 bow hand, 5 draw elbow, 6 draw hand,
//         7 back knee, 8 back ankle, 9 front knee, 10 front ankle
export const HEAD_R = 11;
const NECK = 14;
const TORSO = 36;
const UARM = 18;
const FARM = 18;
const THIGH = 23;
const SHIN = 23;
const BONE = [NECK, TORSO, THIGH, SHIN, THIGH, SHIN, UARM, FARM, UARM, FARM];
const INV_M = [0.85, 0.45, 0.4, 1.3, 1.7, 1.3, 1.7, 0.9, 1.2, 0.9, 1.2];
const JRAD = [11, 4, 5, 3, 3, 3, 3, 3.5, 3, 3.5, 3];
/** how hard each joint is pulled to its pose, per 120 Hz step, at full muscle */
const STIFF = [0.045, 0.08, 0.11, 0.05, 0.2, 0.06, 0.2, 0.1, 0.55, 0.1, 0.55];
/** how much of that pull turns into velocity (1 = springy wobble, 0 = glued) */
const BOUNCE = [0.86, 0.76, 0.7, 0.55, 0.32, 0.55, 0.32, 0.5, 0, 0.5, 0];
/** knocked down: only the seat and the feet still hold on; everything above flops */
const LYING = [0.02, 0.03, 0.95, 0.02, 0.02, 0.02, 0.02, 0.35, 0.85, 0.35, 0.85];
const STRUTS: [number, number, number][] = [
  [0, 2, 0.86 * (NECK + TORSO)], [1, 7, 0.62 * (TORSO + THIGH)], [1, 9, 0.62 * (TORSO + THIGH)],
  [2, 8, 0.36 * (THIGH + SHIN)], [2, 10, 0.36 * (THIGH + SHIN)],
];
const HINGES: [number, number, number, number][] = [[2, 7, 8, -1], [2, 9, 10, -1], [1, 3, 4, 1], [1, 5, 6, 1]];
const G = 1400;
const H = 1 / 120;
/** string distance from the grip: at rest, and extra at full draw (full draw puts the hand under the jaw) */
const BRACE = 11;
const DRAW = 21.5;

export const angWrap = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));
export const angLerp = (a: number, b: number, t: number) => a + angWrap(b - a) * t;
const smooth = (a: number, b: number, x: number) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

export interface Slab2 { x0: number; x1: number; top: number; bot: number }
export type React = 'none' | 'teeter' | 'down' | 'knee';
/** archer with a bow, the axe-throwing boss, or the tied-up prisoner */
export type Role = 'archer' | 'thrower' | 'hostage';

export interface Stick {
  p: V[]; o: V[]; L: number[];
  s: number; face: number;
  alive: boolean; muscle: number; base: V; kneel: boolean; role: Role;
  /** the prisoner once his rope is cut: 0 bound .. 1 jumping for joy */
  happy: number;
  /** intended aim (world angle), draw 0..1, arrow readiness 0..1 (1 = hand on the string), idle→aim blend */
  aim: number; pull: number; nock: number; aiming: number;
  /** where the bow really points right now - read from the two hands */
  bowAng: number; hasBow: boolean; t: number; seed: number;
  /** life signs */
  breath: number; exert: number; vigor: number;
  look: V; lookAt: V | null; blink: number; lid: number;
  /** pain: flinch 0..1, which way the blow travelled, where it landed, and the hand that goes to it */
  hurt: number; hurtDir: number; wound: { stick: number; u: number } | null; clutch: number;
  /** losing and finding his balance again: which way, how far along, how long it takes */
  react: React; rt: number; rdur: number;
  /** what is left of the muscles after death: he crumples before he goes slack */
  fade: number;
  ribbon: V[] | null; ribbonO: V[] | null;
}

const idleAng = (k: Stick) => (k.face > 0 ? -0.55 : Math.PI + 0.55);
const handAngle = (k: Stick) => angLerp(idleAng(k), k.aim, k.aiming);
/** true while the string hand is actually on the string */
export const onString = (k: Stick) => k.nock >= 1 && k.clutch < 0.3 && k.react !== 'down' && k.react !== 'teeter';

/** knock him off balance; he will find his feet again after `dur` seconds */
export function startReact(k: Stick, kind: React, dur: number) {
  k.react = kind; k.rt = 0; k.rdur = dur; k.pull = 0;
}

/** two-bone IK whose middle joint drifts toward a preferred side - continuously, so it never pops over */
function ikToward(root: V, target: V, l1: number, l2: number, pref: V, max = 1) {
  const th = Math.atan2(target.y - root.y, target.x - root.x);
  const bend = clamp((-Math.sin(th) * pref.x + Math.cos(th) * pref.y) * 3, -max, max);
  return ik(root, target, l1, l2, bend).mid;
}

export function woundPoint(k: Stick): V | null {
  if (!k.wound) return null;
  const [a, b] = RAG_STICKS[k.wound.stick];
  return lerpV(k.p[a], k.p[b], k.wound.stick === 0 ? 0.85 : k.wound.u);
}

/** the pose the muscles are reaching for */
export function poseTargets(k: Stick): V[] {
  const f = k.face; const s = k.s; const B = k.base;
  const am = k.aiming; const pull = k.pull; const calm = 1 - am;
  const dying = k.alive ? 0 : 1;
  const hurt = k.hurt; const low = 1 - k.vigor;
  const br = Math.sin(k.breath);                       // +1 = lungs full
  const depth = 1.3 + 1.7 * k.exert + 1.0 * low;       // how big the breath is
  const steady = 1 - 0.8 * am;                         // a drawn bow is held still: the breath barely moves it
  const shift = Math.sin(k.t * 0.55 + k.seed) * 1.9 * calm; // idle weight shift from foot to foot
  const back = hurt * -k.hurtDir * f;                  // >0: knocked backwards, <0: shoved forwards
  const push = k.hurtDir * hurt;                       // world x of the shove

  // balance lost and found
  const ru = k.react === 'none' ? 0 : clamp(k.rt / k.rdur, 0, 1);
  const side = -k.hurtDir * f >= 0 ? 1 : -1;           // +1: thrown backwards, -1: pitched forwards
  const teeter = k.react === 'teeter' ? Math.sin(Math.PI * Math.pow(ru, 0.75)) : 0;
  const kneeDrop = k.react === 'knee' ? smooth(0, 0.13, ru) * (1 - smooth(0.6, 1, ru)) : 0;
  const up = k.react === 'down' ? smooth(0.45, 1, ru) : 1; // 0 = sat on the ground, 1 = back on his feet
  const sit = 1 - up;
  const heave = k.react === 'down' ? Math.sin(Math.PI * up) : 0; // bowed over, one hand down, pushing up
  const buckle = hurt * 5 + low * 2.2 * calm + dying * 17 + heave * 9;

  // legs: standing and kneeling are two poses he can slide between (a hit in the leg drops him to a knee)
  const kb = k.kneel ? 1 : kneeDrop;
  const wide = k.role === 'hostage' ? 6 + 6 * k.happy : 15 + 3 * pull * am;
  const hipS = v(B.x - (2 + pull * 5 * am - shift) * f * s + push * 5 * s - teeter * side * f * 7 * s, B.y - (43 - pull * 3 * am - buckle) * s - br * depth * 0.45 * steady * s);
  const hipK = v(B.x - (3 - shift * 0.4) * f * s + push * 3 * s, B.y - (27 - buckle * 0.45 - (k.kneel ? kneeDrop * 6 : 0)) * s - br * depth * 0.3 * steady * s);
  let hip = lerpV(hipS, hipK, kb);
  let ankB = lerpV(v(B.x - wide * f * s, B.y - 3 * s), v(B.x - 31 * f * s, B.y - 3 * s), kb);
  let ankF = lerpV(v(B.x + wide * f * s, B.y - 3 * s), v(B.x + 13 * f * s, B.y - 3 * s), kb);
  if (kb < 0.5) {
    // a stagger step: the foot on the side he is shoved to lifts and replants a little further out
    const step = v(push * 7 * s, -Math.max(0, hurt - 0.7) * 16 * s);
    if (back > 0) ankB = add(ankB, step); else if (back < 0) ankF = add(ankF, step);
    // teetering on the edge: the far foot comes right off the ground
    if (teeter > 0) {
      if (side > 0) ankF = add(ankF, v(f * 8 * s * teeter, -15 * s * teeter));
      else ankB = add(ankB, v(-f * 8 * s * teeter, -15 * s * teeter));
    }
  }
  if (sit > 0) {
    // sat down hard, legs out in front, the rest of him hanging over the edge
    const far = v(B.x + side * f * 19 * s, B.y - 3 * s); const near = v(B.x + side * f * 8 * s, B.y - 3 * s);
    hip = lerpV(hip, v(B.x - side * f * 11 * s, B.y - 7 * s), sit);
    ankF = lerpV(ankF, side > 0 ? far : near, sit);
    ankB = lerpV(ankB, side > 0 ? near : far, sit);
  }
  if (k.happy > 0) {
    // free! he hops on the spot
    const jump = Math.abs(Math.sin(k.t * 7.5)) * 13 * s * k.happy;
    hip = add(hip, v(0, -jump)); ankB = add(ankB, v(0, -jump)); ankF = add(ankF, v(0, -jump));
  }
  const kneeF = ik(hip, ankF, THIGH * s, SHIN * s, -f).mid;
  let kneeB = lerpV(ik(hip, ankB, THIGH * s, SHIN * s, -f * 0.6).mid, v(B.x - 9 * f * s, B.y - 4 * s), kb);
  if (sit > 0) kneeB = lerpV(kneeB, ik(hip, ankB, THIGH * s, SHIN * s, -f).mid, sit);

  const dir = fromAngle(k.aim);
  const elev = Math.atan2(-dir.y, dir.x * f);
  // lean: back into the draw, a tired hunch at rest, thrown by a hit, way out over the edge when teetering
  let lean = am * (0.08 + 0.15 * pull + clamp(elev, -0.6, 1.2) * 0.22) - calm * (0.04 + low * 0.24) + back * 0.3 - br * 0.018 * calm - dying * 0.5
    + teeter * side * (0.62 + Math.sin(k.t * 13) * 0.1) - heave * 0.75 - kneeDrop * 0.3;
  // the axe thrower rears back to wind up and whips forward on the throw; the prisoner squirms in his rope
  const swing = k.role === 'thrower' && k.nock < 1 ? Math.sin(Math.PI * Math.min(1, k.nock * 1.8)) : 0;
  if (k.role === 'thrower') lean += 0.3 * pull - 0.45 * swing;
  if (k.role === 'hostage') lean += Math.sin(k.t * 6.3) * 0.05 * (1 - k.happy);
  lean = lerp(lean, side * 1.25, sit);
  const neck = add(hip, v(-Math.sin(lean) * f * TORSO * s, -Math.cos(lean) * TORSO * s));
  // head: tips toward the string at anchor, droops when worn out, snaps with a blow
  const tilt = am * (0.12 + 0.1 * pull) + calm * (0.05 + low * 0.42) - back * 0.7 + dying * 0.8 + Math.sin(k.t * 0.37 + k.seed * 2) * 0.05 * calm
    + teeter * side * 0.5 + heave * 0.3 + sit * 0.2;
  const ha = lean - tilt;
  const head = add(neck, v(-Math.sin(ha) * f * NECK * s, -Math.cos(ha) * NECK * s));

  const hd = handAngle(k); const d = fromAngle(hd);
  const idleHand = add(neck, v((17 + shift * 0.4) * f * s, (23 - br * depth * 0.55) * s));
  const aimHand = add(neck, mul(dir, 33.5 * s));
  let bowHand = lerpV(idleHand, aimHand, am);
  bowHand = add(bowHand, v(push * 4 * s, (hurt * 7 + dying * 14 + heave * 10) * s)); // the bow arm sags with the pain
  // the string hand: rock steady on the string, all the way back to the jaw
  const rest = sub(bowHand, mul(d, (BRACE + DRAW * pull) * s));
  let drawHand = rest;
  if (k.nock < 1) {
    // release: the hand opens and swings back and down past the hip, takes an arrow from the hip quiver,
    // and brings it up to the string - the arm never has to fold up over the shoulder
    const follow = add(neck, add(mul(d, -19 * s), v(0, 10 * s)));
    const quiver = add(hip, v(-10 * f * s, -5 * s));
    const q = k.nock;
    drawHand = q < 0.2 ? lerpV(rest, follow, smooth(0, 0.2, q))
      : q < 0.55 ? lerpV(follow, quiver, smooth(0.2, 0.55, q))
        : lerpV(quiver, rest, smooth(0.55, 1, q));
  }
  if (k.role === 'thrower') {
    // front hand carries the axe: low at his side, cocked back over the shoulder, whipped forward, and down again
    const idleA = add(neck, v(10 * f * s, 26 * s)); const cocked = add(neck, v(-15 * f * s, -27 * s)); const thrown = add(neck, v(31 * f * s, 4 * s));
    let hand = lerpV(idleA, cocked, smooth(0, 1, pull));
    if (k.nock < 1) hand = k.nock < 0.22 ? lerpV(cocked, thrown, smooth(0, 0.22, k.nock)) : lerpV(thrown, idleA, smooth(0.22, 1, k.nock));
    bowHand = add(hand, v(push * 4 * s, hurt * 7 * s));
    drawHand = lerpV(add(neck, v(5 * f * s, 25 * s)), add(neck, v(26 * f * s, 1 * s)), pull); // the other arm points at his mark
  } else if (k.role === 'hostage') {
    // wrists tied behind him; arms thrown up and waving once he is loose
    const wave = Math.sin(k.t * 9);
    bowHand = lerpV(add(hip, v(-5 * f * s, -9 * s)), add(neck, v((16 + wave * 6) * f * s, -27 * s)), k.happy);
    drawHand = lerpV(add(hip, v(-8 * f * s, -6 * s)), add(neck, v((-14 + wave * 6) * f * s, -27 * s)), k.happy);
  }
  const wp = woundPoint(k);
  if (wp && k.clutch > 0.01) {
    const r = sub(wp, neck); const l = len(r) || 1;
    const reach = add(neck, mul(r, Math.min(1, (33 * s) / l)));
    drawHand = lerpV(drawHand, reach, k.clutch);
  }
  if (teeter > 0) {
    // arms windmilling for balance, half a turn apart
    const spin = k.t * 13 * side * f;
    bowHand = lerpV(bowHand, add(neck, fromAngle(spin, 27 * s)), teeter * 0.9);
    drawHand = lerpV(drawHand, add(neck, fromAngle(spin + Math.PI, 27 * s)), teeter * 0.9);
  }
  if (heave > 0) drawHand = lerpV(drawHand, v(B.x + f * 20 * s, B.y - 4 * s), heave * 0.85); // a hand on the ground to push off
  // elbows hang down-and-back; at full draw the string elbow swings in line behind the arrow
  const pref = v(-0.6 * f, 0.8);
  const bowEl = ikToward(neck, bowHand, UARM * s, FARM * s, pref, 0.6);
  let drawEl = ikToward(neck, drawHand, UARM * s, FARM * s, pref, 1);
  const tuck = smooth(0.4, 1, pull) * am * (1 - k.clutch) * (k.nock >= 1 && k.react === 'none' && k.role === 'archer' ? 1 : 0);
  if (tuck > 0) drawEl = lerpV(drawEl, add(neck, add(mul(d, -17 * s), v(0, 3 * s))), tuck);
  return [head, neck, hip, bowEl, bowHand, drawEl, drawHand, kneeB, ankB, kneeF, ankF];
}

export function makeStick(base: V, face: number, s: number, kneel: boolean, ribbon: boolean, role: Role = 'archer'): Stick {
  const k: Stick = {
    p: [], o: [], L: BONE.map((b) => b * s), s, face, alive: true, muscle: 1, base: { ...base }, kneel, role, happy: 0,
    aim: face > 0 ? -0.1 : Math.PI + 0.1, pull: 0, nock: 1, aiming: 0, bowAng: 0, hasBow: role === 'archer', t: Math.random() * 10, seed: Math.random() * 6.28,
    breath: Math.random() * 6.28, exert: 0, vigor: 1, look: v(face, 0), lookAt: null, blink: 1 + Math.random() * 3, lid: 0,
    hurt: 0, hurtDir: 0, wound: null, clutch: 0, react: 'none', rt: 0, rdur: 1, fade: 0,
    ribbon: null, ribbonO: null,
  };
  k.bowAng = idleAng(k);
  k.p = poseTargets(k);
  k.o = k.p.map((q) => ({ ...q }));
  if (ribbon) {
    k.ribbon = Array.from({ length: 6 }, (_, i) => v(k.p[0].x - face * (10 + i * 6) * s, k.p[0].y - 5 * s));
    k.ribbonO = k.ribbon.map((q) => ({ ...q }));
  }
  return k;
}

/** shove one joint (px/s) */
export function impulse(k: Stick, i: number, vel: V) {
  k.o[i] = v(k.o[i].x - vel.x * H, k.o[i].y - vel.y * H);
}

/** where a shot would really go: the line through both hands, held near the intended aim */
export function fireAngle(k: Stick) {
  const phys = Math.atan2(k.p[4].y - k.p[6].y, k.p[4].x - k.p[6].x);
  return k.aim + Math.max(-0.2, Math.min(0.2, angWrap(phys - k.aim)));
}

/** one 120 Hz physics step */
export function stepStick(k: Stick, slabs: Slab2[]) {
  const n = k.p.length; const s = k.s;
  k.t += H;
  // life signs
  k.breath += H * Math.PI * 2 * (0.27 + 0.55 * k.exert + 0.36 * (1 - k.vigor));
  k.exert = Math.max(0, k.exert - H * 0.22);
  k.hurt = Math.max(0, k.hurt - H * (k.alive ? 1.45 : 0));
  if (!k.alive) k.react = 'none';
  else if (k.react !== 'none') { k.rt += H; if (k.rt >= k.rdur) k.react = 'none'; }
  const canClutch = (k.react === 'none' || k.react === 'knee') && k.role !== 'hostage';
  const wantClutch = k.wound && ((k.alive && canClutch && k.hurt > 0.22 && k.pull < 0.2) || (!k.alive && k.fade > 0.02)) ? 1 : 0;
  k.clutch = damp(k.clutch, wantClutch, wantClutch ? 16 : 6, H);
  k.fade = Math.max(0, k.fade - H * 2.4);
  k.blink -= H;
  if (k.blink < 0) k.blink = Math.random() < 0.2 ? 0.28 : 1.6 + Math.random() * 3.6;
  k.lid = damp(k.lid, k.blink < 0.11 ? 1 : 0, 45, H);
  const to = k.lookAt ? sub(k.lookAt, k.p[0]) : fromAngle(k.aim);
  const tl = len(to) || 1;
  k.look = v(damp(k.look.x, to.x / tl, 9, H), damp(k.look.y, to.y / tl, 9, H));

  // how much muscle each joint has right now
  let m = k.alive ? k.muscle : k.fade;
  let mult: number[] | null = null;
  let dm = m;
  if (k.alive && k.react === 'down') {
    const w = smooth(0.42, 0.92, k.rt / k.rdur);
    mult = LYING.map((l) => lerp(l, 1, w)); m = 1; dm = w * 0.9;
  } else if (k.alive && k.react !== 'none') { m = Math.max(m, 0.75); dm = m; }
  const dampK = k.alive ? lerp(0.99, 0.925, dm) : lerp(0.997, 0.95, m);
  const before: number[] = [];
  for (let i = 0; i < n; i++) {
    const vx = (k.p[i].x - k.o[i].x) * dampK;
    const vy = (k.p[i].y - k.o[i].y) * dampK;
    before[i] = vy;
    k.o[i] = { ...k.p[i] };
    k.p[i] = v(k.p[i].x + vx, k.p[i].y + vy + G * H * H);
  }
  if (m > 0.01) {
    const T = poseTargets(k);
    for (let i = 0; i < n; i++) {
      // a dying man's feet are no longer planted: he can go over the edge
      const st = STIFF[i] * m * (mult ? mult[i] : 1) * (!k.alive && (i === 8 || i === 10) ? 0.12 : 1);
      const dx = (T[i].x - k.p[i].x) * st; const dy = (T[i].y - k.p[i].y) * st;
      k.p[i].x += dx; k.p[i].y += dy;
      const keep = 1 - BOUNCE[i];
      k.o[i].x += dx * keep; k.o[i].y += dy * keep;
    }
  }
  const solve = (a: number, b: number, target: number, onlyIfShorter: boolean) => {
    const dx = k.p[b].x - k.p[a].x; const dy = k.p[b].y - k.p[a].y;
    const l = Math.hypot(dx, dy) || 0.0001;
    if (onlyIfShorter && l >= target) return;
    const wa = INV_M[a]; const wb = INV_M[b];
    const c = (l - target) / l / (wa + wb);
    k.p[a].x += dx * c * wa; k.p[a].y += dy * c * wa;
    k.p[b].x -= dx * c * wb; k.p[b].y -= dy * c * wb;
  };
  const onSlab: (Slab2 | null)[] = new Array(n).fill(null);
  const limp = 1 - (mult ? dm : m);
  for (let it = 0; it < 9; it++) {
    RAG_STICKS.forEach(([a, b], i) => solve(a, b, k.L[i], false));
    for (const [a, b, l] of STRUTS) solve(a, b, l * s, true);
    if (limp > 0.4) {
      // knees and elbows only fold the human way once the body has gone slack
      for (const [a, mid, e, sign] of HINGES) {
        const d1 = sub(k.p[mid], k.p[a]); const d2 = sub(k.p[e], k.p[mid]);
        if ((d1.x * d2.y - d1.y * d2.x) * sign * -k.face < 0) {
          const straight = add(k.p[mid], mul(d1, len(d2) / (len(d1) || 1)));
          const c = mul(sub(straight, k.p[e]), 0.4 * limp);
          const we = INV_M[e] / (INV_M[e] + INV_M[mid]);
          k.p[e] = add(k.p[e], mul(c, we));
          k.p[mid] = sub(k.p[mid], mul(c, 1 - we));
        }
      }
    }
    for (let i = 0; i < n; i++) {
      const rad = JRAD[i] * s; const p = k.p[i];
      for (const sl of slabs) {
        const inX = p.x > sl.x0 - rad * 0.5 && p.x < sl.x1 + rad * 0.5;
        const bottom = sl.bot + rad * 0.6;
        if (!inX || p.y <= sl.top - rad || p.y >= bottom) continue;
        const o = k.o[i];
        const wasAbove = o.y <= sl.top - rad + 4;
        const wasBelow = o.y >= bottom - 4;
        const wasOutX = o.x <= sl.x0 - rad * 0.5 || o.x >= sl.x1 + rad * 0.5;
        if (wasAbove || (!wasBelow && !wasOutX && p.y - (sl.top - rad) < 14)) { p.y = sl.top - rad; onSlab[i] = sl; }
        // for the living a ground is one-way: he can be hauled back up onto it from wherever he ended up hanging
        else if (k.alive) continue;
        else if (wasBelow || (!wasOutX && bottom - p.y < 14)) { p.y = bottom; o.y = Math.max(o.y, bottom); }
        else if (wasOutX) p.x = p.x < (sl.x0 + sl.x1) / 2 ? sl.x0 - rad * 0.5 : sl.x1 + rad * 0.5;
        else p.y = sl.top - rad;
      }
    }
  }
  if (!k.alive) {
    for (let i = 0; i < n; i++) {
      const sl = onSlab[i];
      if (sl && k.p[i].y >= sl.top - JRAD[i] * s - 0.01) {
        k.o[i].x = k.p[i].x - (k.p[i].x - k.o[i].x) * (i === 0 ? 0.8 : 0.7);
        if (before[i] > 1.2) k.o[i].y = k.p[i].y + before[i] * (i === 0 ? 0.3 : 0.22);
      }
    }
  }
  // the bow follows the real hands, so every wobble of the body shows in the aim;
  // after a release it tips forward in the hand and comes back as the next arrow goes on
  const phys = Math.atan2(k.p[4].y - k.p[6].y, k.p[4].x - k.p[6].x);
  const tip = k.nock < 1 ? k.face * 0.42 * Math.sin(Math.PI * Math.min(1, k.nock * 1.25)) : 0;
  const loose = k.react === 'down' || k.react === 'teeter' ? Math.atan2(k.p[4].y - k.p[3].y, k.p[4].x - k.p[3].x) - k.face * 0.9 : handAngle(k) + tip;
  k.bowAng = angLerp(k.bowAng, onString(k) ? phys : loose, 0.3);

  // headband tails / cape: a little verlet chain pinned behind the head
  if (k.ribbon && k.ribbonO) {
    const R = k.ribbon; const O = k.ribbonO;
    const u = headUp(k); const fw = v(-u.y * k.face, u.x * k.face);
    const anchor = v(k.p[0].x + u.x * 5.5 * s - fw.x * 9.5 * s, k.p[0].y + u.y * 5.5 * s - fw.y * 9.5 * s);
    for (let i = 1; i < R.length; i++) {
      const vx = (R[i].x - O[i].x) * 0.965; const vy = (R[i].y - O[i].y) * 0.965;
      O[i] = { ...R[i] };
      const wind = (-k.face * 260 + Math.sin(k.t * 5 + i * 0.9) * 240) * H * H;
      R[i] = v(R[i].x + vx + wind, R[i].y + vy + 330 * H * H + Math.cos(k.t * 6.3 + i * 1.3) * 150 * H * H);
    }
    R[0] = anchor;
    for (let it = 0; it < 3; it++) {
      for (let i = 1; i < R.length; i++) {
        const dx = R[i].x - R[i - 1].x; const dy = R[i].y - R[i - 1].y;
        const l = Math.hypot(dx, dy) || 0.001; const c = (l - 6 * s) / l;
        R[i].x -= dx * c; R[i].y -= dy * c;
      }
    }
  }
}

function headUp(k: Stick): V {
  const d = sub(k.p[0], k.p[1]); const l = len(d) || 1;
  return v(d.x / l, d.y / l);
}

/** how flat his feet sit: planted while he stands, loose while he is down or dead */
const planted = (k: Stick) => (!k.alive ? 0 : k.react === 'down' ? smooth(0.5, 0.9, k.rt / k.rdur) : 1);

/** where the toes are: straight ahead along the ground when planted, hanging off the shin otherwise */
function toeOf(k: Stick, kn: number, an: number): V {
  const P = k.p; const f = k.face; const s = k.s;
  const d = sub(P[an], P[kn]); const l = len(d) || 1;
  const flat = planted(k);
  const tx = lerp((d.y / l) * f, f, flat); const ty = lerp(-(d.x / l) * f, 0, flat);
  const tl = Math.hypot(tx, ty) || 1;
  return v(P[an].x + (tx / tl) * 9.5 * s, P[an].y + (ty / tl) * 9.5 * s + flat * 0.5 * s);
}

/** the curved spine: control point of the quadratic from hip to neck */
function spineCtrl(k: Stick): V {
  const P = k.p; const u = headUp(k);
  const sd = sub(P[1], P[2]); const sl = len(sd) || 1;
  const cross = (sd.x / sl) * u.y - (sd.y / sl) * u.x;
  const mid = lerpV(P[2], P[1], 0.5);
  return v(mid.x + (sd.y / sl) * cross * 11 * k.s, mid.y - (sd.x / sl) * cross * 11 * k.s);
}

/* ------------------------------------------------------------------ */
/* drawing                                                             */
/* ------------------------------------------------------------------ */

export interface StickLook { color: string; rim: string | null; eye: string; helm: boolean; crown: boolean; band: string | null; quiver: boolean; horns?: boolean; bound?: boolean }

/** a limb as one flowing shape: thick at the root, thin at the end, the joint rounded instead of cornered */
function limb(ctx: Ctx, A: V, J: V, B: V, w0: number, w1: number, w2: number) {
  const la = dist(A, J) || 1; const lb = dist(J, B) || 1;
  const r = Math.min(la, lb) * 0.46;
  const p1 = lerpV(J, A, r / la); const p2 = lerpV(J, B, r / lb);
  const pts: V[] = [A, p1]; const ts: number[] = [0, 0.5 * (1 - r / la)];
  for (let i = 1; i <= 3; i++) {
    const t = i / 4; const m = 1 - t;
    pts.push(v(m * m * p1.x + 2 * m * t * J.x + t * t * p2.x, m * m * p1.y + 2 * m * t * J.y + t * t * p2.y));
    ts.push(0.5 * (1 - r / la) + (0.5 * r / la + 0.5 * r / lb) * t);
  }
  pts.push(p2); ts.push(0.5 + 0.5 * r / lb);
  pts.push(B); ts.push(1);
  for (let i = 0; i < pts.length - 1; i++) {
    const t = (ts[i] + ts[i + 1]) / 2;
    ctx.lineWidth = t < 0.5 ? lerp(w0, w1, t * 2) : lerp(w1, w2, (t - 0.5) * 2);
    ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[i + 1].x, pts[i + 1].y); ctx.stroke();
  }
}

/** silhouette stickman; `held` is called just before the bow arm so the bow sits in his front hand */
export function drawStick(ctx: Ctx, k: Stick, look: StickLook, held?: () => void, behind?: () => void) {
  const P = k.p; const s = k.s; const f = k.face;
  const u = headUp(k); const fw = v(-u.y * f, u.x * f);
  const ua = Math.atan2(u.y, u.x);
  const br = Math.sin(k.breath) * (0.5 + k.exert * 0.5 + (1 - k.vigor) * 0.4);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';

  // the whole sole on the ground - heel and toe - whenever he is standing on it
  const foot = (kn: number, an: number) => {
    const toe = toeOf(k, kn, an);
    const heel = lerpV(P[an], toe, -0.22);
    limb(ctx, heel, lerpV(heel, toe, 0.5), toe, 5 * s, 4.6 * s, 3.4 * s);
  };
  const leg = (kn: number, an: number) => { limb(ctx, P[2], P[kn], P[an], 7.6 * s, 6.3 * s, 4.9 * s); foot(kn, an); };
  const arm = (el: number, ha: number) => {
    limb(ctx, P[1], P[el], P[ha], 6.4 * s, 5.3 * s, 4.3 * s);
    ctx.beginPath(); ctx.arc(P[ha].x, P[ha].y, 3.7 * s, 0, Math.PI * 2); ctx.fill();
  };
  // the spine bows toward wherever the head has gone, so the torso reads as one supple line
  const spine = () => {
    limb(ctx, P[2], spineCtrl(k), P[1], 7.8 * s, (8.7 + br * 0.9) * s, 6.3 * s);
    ctx.lineWidth = 5.6 * s;
    ctx.beginPath(); ctx.moveTo(P[1].x, P[1].y); ctx.lineTo(P[0].x, P[0].y); ctx.stroke();
  };
  const body = (front: boolean) => {
    if (!front) {
      arm(5, 6);
      leg(7, 8);
      spine();
      ctx.beginPath(); ctx.arc(P[0].x, P[0].y, HEAD_R * s, 0, Math.PI * 2); ctx.fill();
      leg(9, 10);
    } else arm(3, 4);
  };

  // quiver on the rear hip
  if (look.quiver) {
    ctx.save();
    ctx.translate(P[2].x - f * 6 * s, P[2].y - 1 * s);
    ctx.rotate(Math.atan2(P[1].y - P[2].y, P[1].x - P[2].x) + Math.PI / 2 - f * 0.5);
    ctx.scale(s, s);
    ctx.fillStyle = '#e5352f';
    for (const ox of [-2.2, 1.2]) { ctx.beginPath(); ctx.moveTo(ox, -11); ctx.lineTo(ox - 2.4, -17); ctx.lineTo(ox + 2.6, -16); ctx.closePath(); ctx.fill(); }
    ctx.fillStyle = '#24130b';
    ctx.beginPath(); ctx.moveTo(-4.2, -11); ctx.lineTo(4.2, -11); ctx.lineTo(3, 8); ctx.lineTo(-3, 8); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#5a3320'; ctx.fillRect(-4.4, -11.5, 8.8, 2.4);
    ctx.restore();
  }

  if (k.ribbon && look.band) {
    ctx.strokeStyle = look.band; ctx.lineWidth = 3.4 * s;
    ctx.beginPath();
    k.ribbon.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y)));
    ctx.stroke();
    ctx.lineWidth = 2.6 * s;
    ctx.beginPath();
    k.ribbon.slice(0, 5).forEach((q, i) => (i ? ctx.lineTo(q.x + i * 0.6 * s, q.y + i * 2.2 * s) : ctx.moveTo(q.x, q.y)));
    ctx.stroke();
  }

  // whatever is stuck in him goes down first, so the body closes over the buried end
  behind?.();
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';

  // a thin rim of light on the upper-left edge lifts the silhouette off the forest
  if (look.rim) {
    ctx.save();
    ctx.translate(-1.2 * s, -1.4 * s);
    ctx.strokeStyle = look.rim; ctx.fillStyle = look.rim;
    body(false);
    ctx.restore();
  }
  ctx.strokeStyle = look.color; ctx.fillStyle = look.color;
  body(false);

  // head dressing
  if (look.band) {
    ctx.lineCap = 'butt'; ctx.strokeStyle = look.band; ctx.lineWidth = 4.2 * s;
    ctx.beginPath();
    ctx.moveTo(P[0].x + u.x * 5.5 * s - fw.x * 9.3 * s, P[0].y + u.y * 5.5 * s - fw.y * 9.3 * s);
    ctx.lineTo(P[0].x + u.x * 5.5 * s + fw.x * 9.3 * s, P[0].y + u.y * 5.5 * s + fw.y * 9.3 * s);
    ctx.stroke();
    ctx.lineCap = 'round';
  }
  if (look.helm) {
    ctx.fillStyle = '#51666f';
    ctx.beginPath(); ctx.arc(P[0].x, P[0].y, (HEAD_R + 2) * s, ua - 1.75, ua + 1.75); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#9fb4bb'; ctx.lineWidth = 2 * s;
    ctx.beginPath(); ctx.arc(P[0].x, P[0].y, (HEAD_R + 1) * s, ua - 1.2, ua + 0.2); ctx.stroke();
  }
  if (look.crown) {
    ctx.save();
    ctx.translate(P[0].x, P[0].y); ctx.rotate(ua + Math.PI / 2); ctx.scale(s, s);
    ctx.fillStyle = '#ffc933';
    ctx.beginPath();
    ctx.moveTo(-9, -HEAD_R + 3); ctx.lineTo(-11, -HEAD_R - 9); ctx.lineTo(-5, -HEAD_R - 3); ctx.lineTo(0, -HEAD_R - 11);
    ctx.lineTo(5, -HEAD_R - 3); ctx.lineTo(11, -HEAD_R - 9); ctx.lineTo(9, -HEAD_R + 3);
    ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  if (look.horns) {
    // the axe boss: a dark iron cap with two pale horns
    ctx.save();
    ctx.translate(P[0].x, P[0].y); ctx.rotate(ua + Math.PI / 2); ctx.scale(s, s);
    ctx.fillStyle = '#efe6d0';
    for (const sd of [-1, 1]) {
      ctx.beginPath(); ctx.moveTo(sd * 7, -7); ctx.quadraticCurveTo(sd * 17, -8, sd * 15.5, -21); ctx.quadraticCurveTo(sd * 12, -12, sd * 4, -10.5); ctx.closePath(); ctx.fill();
    }
    ctx.fillStyle = '#414e56';
    ctx.beginPath(); ctx.arc(0, 0, HEAD_R + 1.8, Math.PI * 1.04, Math.PI * 1.96); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#8fa3ab'; ctx.fillRect(-HEAD_R - 1.5, -3.2, (HEAD_R + 1.5) * 2, 2.2);
    ctx.restore();
  }

  // the face: an eye that looks, blinks, narrows on the draw and screws shut in pain; a mouth only when it hurts
  const lf = k.look.x * fw.x + k.look.y * fw.y; const lu = k.look.x * u.x + k.look.y * u.y;
  const ex = P[0].x + fw.x * (3.4 + 1.5 * lf) * s + u.x * (0.3 + 1.7 * lu) * s;
  const ey = P[0].y + fw.y * (3.4 + 1.5 * lf) * s + u.y * (0.3 + 1.7 * lu) * s;
  const dizzy = k.react === 'down' && k.rt / k.rdur < 0.5;
  const pain = k.alive ? Math.max(smooth(0.2, 0.5, k.hurt), dizzy ? 1 : 0, k.react === 'teeter' ? 0.4 : 0) : 0;
  ctx.save();
  ctx.translate(ex, ey); ctx.rotate(ua + Math.PI / 2); ctx.scale(f * s, s);
  if (!k.alive) {
    ctx.strokeStyle = look.eye; ctx.lineWidth = 1.7;
    ctx.beginPath(); ctx.moveTo(-2.6, -2.6); ctx.lineTo(2.6, 2.6); ctx.moveTo(2.6, -2.6); ctx.lineTo(-2.6, 2.6); ctx.stroke();
  } else if (k.happy > 0.5) {
    // eyes squeezed into a smile
    ctx.strokeStyle = look.eye; ctx.lineWidth = 1.9;
    ctx.beginPath(); ctx.moveTo(-3, 1.3); ctx.quadraticCurveTo(0, -3.3, 3, 1.3); ctx.stroke();
  } else if (pain > 0.5) {
    ctx.strokeStyle = look.eye; ctx.lineWidth = 1.8; ctx.lineJoin = 'miter';
    ctx.beginPath(); ctx.moveTo(-2.8, -2.6); ctx.lineTo(2.2, 0); ctx.lineTo(-2.8, 2.6); ctx.stroke();
    ctx.lineJoin = 'round';
  } else {
    // wide-eyed while he fights for balance, narrowed down the arrow
    const squint = k.react === 'teeter' ? 1.35 : 1 - 0.38 * k.pull * k.aiming - 0.3 * (1 - k.vigor);
    ctx.rotate(0.3 - lu * 0.25);
    ctx.fillStyle = look.eye;
    ctx.beginPath(); ctx.ellipse(0, 0, 3.5, Math.max(0.25, 2.25 * (1 - k.lid) * squint), 0, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
  const mouth = k.alive ? Math.max(pain, k.react === 'teeter' ? 0.9 : 0, k.happy * 0.95) : 0.8;
  if (mouth > 0.05) {
    ctx.fillStyle = look.eye;
    ctx.beginPath();
    ctx.ellipse(P[0].x + fw.x * 6.4 * s - u.x * 5.2 * s, P[0].y + fw.y * 6.4 * s - u.y * 5.2 * s, 2 * s * mouth, 2.5 * s * mouth, ua, 0, Math.PI * 2);
    ctx.fill();
  }

  held?.();
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (look.rim) {
    ctx.save(); ctx.translate(-1.2 * s, -1.4 * s);
    ctx.strokeStyle = look.rim; ctx.fillStyle = look.rim; body(true);
    ctx.restore();
  }
  ctx.strokeStyle = look.color; ctx.fillStyle = look.color;
  body(true);
  if (look.bound) {
    // coils of rope round his chest
    const C = spineCtrl(k); const sd = sub(P[1], P[2]); const sl = len(sd) || 1;
    const nx = -sd.y / sl; const ny = sd.x / sl;
    for (const q of [0.3, 0.46, 0.62]) {
      const m = 1 - q;
      const cx = m * m * P[2].x + 2 * m * q * C.x + q * q * P[1].x; const cy = m * m * P[2].y + 2 * m * q * C.y + q * q * P[1].y;
      for (const [col, lw] of [['#8a6a34', 4.4], ['#e3c283', 2.6]] as [string, number][]) {
        ctx.strokeStyle = col; ctx.lineWidth = lw * s;
        ctx.beginPath(); ctx.moveTo(cx - nx * 8 * s, cy - ny * 8 * s - 1.5 * s); ctx.lineTo(cx + nx * 8 * s, cy + ny * 8 * s + 1.5 * s); ctx.stroke();
      }
    }
  }
}

/**
 * The inside of him, for the X-ray: skull with jaw and socket, vertebrae, rib cage, pelvis, long bones.
 * `crack` is the stick (bone) that just took the arrow at world point `pt`: the skull splits, ribs snap,
 * or the long bone of that limb breaks in two - growing with `t` (0..1).
 * With `local` only the part that was hit is drawn: that one arm, that one leg, or the spine and ribs.
 */
export function drawSkeleton(ctx: Ctx, k: Stick, crack: number | null, pt: V, t: number, local = false) {
  const P = k.p; const s = k.s; const f = k.face;
  const up = headUp(k); const fw = v(-up.y * f, up.x * f);
  const BONE_C = '#ecfcff'; const DARK = '#04121f';
  ctx.strokeStyle = BONE_C; ctx.fillStyle = BONE_C; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const seg = (a: V, b: V) => { ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); };
  /** where along a→b the arrow went through, and the two broken ends pushed apart */
  const split = (a: V, b: V): [V, V, V] => {
    const d = sub(b, a); const l = len(d) || 1; const ux = d.x / l; const uy = d.y / l;
    const q = clamp(((pt.x - a.x) * ux + (pt.y - a.y) * uy) / l, 0.22, 0.78);
    const m = lerpV(a, b, q); const gap = (1.2 + 2.2 * t) * s; const off = 2.6 * t * s;
    return [v(m.x - ux * gap, m.y - uy * gap), v(m.x + ux * gap - uy * off, m.y + uy * gap + ux * off), v(-uy, ux)];
  };
  const long = (a: V, b: V, w: number, broken: boolean) => {
    ctx.lineWidth = w * s;
    if (!broken) seg(a, b);
    else {
      const [e1, e2, n] = split(a, b);
      seg(a, e1); seg(e2, b);
      // splintered ends
      ctx.lineWidth = 1.1 * s;
      for (const [e, sg] of [[e1, 1], [e2, -1]] as [V, number][]) {
        seg(v(e.x + n.x * w * 0.5 * s, e.y + n.y * w * 0.5 * s), v(e.x + n.x * w * 0.9 * s + (b.x - a.x) * 0.04 * sg, e.y + n.y * w * 0.9 * s + (b.y - a.y) * 0.04 * sg));
      }
    }
    for (const q of [a, b]) { ctx.beginPath(); ctx.arc(q.x, q.y, w * 0.92 * s, 0, Math.PI * 2); ctx.fill(); }
  };
  const twin = (a: V, b: V, w: number, gap: number, broken: boolean) => {
    const d = sub(b, a); const l = len(d) || 1; const nx = (-d.y / l) * gap * s; const ny = (d.x / l) * gap * s;
    ctx.lineWidth = w * s;
    for (const sg of [-1, 1]) {
      const a2 = v(a.x + nx * sg, a.y + ny * sg); const b2 = v(b.x + nx * sg * 0.7, b.y + ny * sg * 0.7);
      if (!broken) seg(a2, b2);
      else { const [e1, e2] = split(a2, b2); seg(a2, e1); seg(v(e2.x + nx * sg * t, e2.y + ny * sg * t), b2); }
    }
  };
  // limbs: humerus, radius+ulna, hand; femur, kneecap, tibia+fibula, foot
  for (const [el, ha, su, sf] of [[5, 6, 8, 9], [3, 4, 6, 7]]) {
    if (local && crack !== su && crack !== sf) continue;
    long(P[1], P[el], 2.1, crack === su); twin(P[el], P[ha], 1.2, 1.15, crack === sf);
    ctx.beginPath(); ctx.arc(P[ha].x, P[ha].y, 2.1 * s, 0, Math.PI * 2); ctx.fill();
  }
  for (const [kn, an, st, ss] of [[7, 8, 2, 3], [9, 10, 4, 5]]) {
    if (local && crack !== st && crack !== ss) continue;
    long(P[2], P[kn], 2.6, crack === st); twin(P[kn], P[an], 1.4, 1.3, crack === ss);
    ctx.beginPath(); ctx.arc(P[kn].x, P[kn].y, 2.2 * s, 0, Math.PI * 2); ctx.fill();
    const toe = toeOf(k, kn, an);
    ctx.lineWidth = 1.7 * s; seg(P[an], toe);
  }
  // spine: a row of vertebrae along the same curve the body draws, ribs hanging off the upper ones
  const C = spineCtrl(k);
  const at = (q: number) => { const m = 1 - q; return v(m * m * P[2].x + 2 * m * q * C.x + q * q * P[1].x, m * m * P[2].y + 2 * m * q * C.y + q * q * P[1].y); };
  const sd = sub(P[1], P[2]); const sl = len(sd) || 1;
  const along = v(sd.x / sl, sd.y / sl); const front = v(-along.y * f, along.x * f); // toward his chest
  const hitQ = clamp(((pt.x - P[2].x) * along.x + (pt.y - P[2].y) * along.y) / sl, 0.5, 0.95);
  const ends: V[] = [];
  for (let i = 0; i <= 10; i++) {
    if (local && crack !== 1) break;
    const q = i / 10; const c = at(q);
    ctx.lineWidth = 2.5 * s;
    seg(v(c.x - front.x * 2.1 * s, c.y - front.y * 2.1 * s), v(c.x + front.x * 1.2 * s, c.y + front.y * 1.2 * s));
    if (i >= 5 && i <= 9) {
      const reach = (8.2 - Math.abs(i - 7) * 0.7) * s;
      const end = v(c.x + front.x * reach - along.x * 4.4 * s, c.y + front.y * reach - along.y * 4.4 * s);
      const ctl = v(c.x + front.x * reach * 1.05 + along.x * 1.2 * s, c.y + front.y * reach * 1.05 + along.y * 1.2 * s);
      const broken = crack === 1 && Math.abs(q - hitQ) < 0.11;
      ctx.lineWidth = 1.5 * s;
      if (!broken) { ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.quadraticCurveTo(ctl.x, ctl.y, end.x, end.y); ctx.stroke(); }
      else {
        // snapped: a stump on the spine, the front half knocked loose and turning
        seg(c, lerpV(c, ctl, 0.55));
        const off = v(front.x * 3 * s * t + along.x * (i % 2 ? 2 : -2) * s * t, front.y * 3 * s * t + 3 * s * t);
        seg(v(ctl.x + off.x, ctl.y + off.y), v(end.x + off.x * 1.6, end.y + off.y * 1.6));
      }
      ends.push(end);
    }
  }
  if (ends.length > 1) { ctx.lineWidth = 1.6 * s; seg(ends[0], ends[ends.length - 1]); } // sternum
  for (const q of [0.3, 0.6]) { // neck vertebrae
    if (local) break;
    const c = lerpV(P[1], P[0], q);
    ctx.lineWidth = 2.2 * s; seg(v(c.x - fw.x * 1.7 * s, c.y - fw.y * 1.7 * s), v(c.x + fw.x * 1.2 * s, c.y + fw.y * 1.2 * s));
  }
  if (local) return;
  ctx.lineWidth = 2.2 * s; // pelvis
  ctx.beginPath(); ctx.ellipse(P[2].x, P[2].y - 0.5 * s, 6 * s, 4.2 * s, Math.atan2(along.y, along.x) + Math.PI / 2, 0, Math.PI * 2); ctx.stroke();

  // skull, in the head's own frame: x toward the face, y toward the chin
  ctx.save();
  ctx.transform(fw.x, fw.y, -up.x, -up.y, P[0].x, P[0].y);
  ctx.scale(s, s);
  ctx.beginPath(); ctx.ellipse(-0.8, -1.6, 8.9, 8.3, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.moveTo(1.5, 1); ctx.lineTo(8.3, 1.2); ctx.lineTo(8.7, 5.2); ctx.lineTo(6.4, 9.6); ctx.lineTo(0.4, 8.8); ctx.lineTo(-2, 4); ctx.closePath(); ctx.fill();
  const glow = ctx.shadowBlur; ctx.shadowBlur = 0;
  ctx.fillStyle = DARK; ctx.strokeStyle = DARK;
  ctx.beginPath(); ctx.ellipse(4.5, -1.1, 2.5, 2.9, 0.15, 0, Math.PI * 2); ctx.fill();          // eye socket
  ctx.beginPath(); ctx.moveTo(8.6, 1.4); ctx.lineTo(6.9, 3.4); ctx.lineTo(8.9, 3.6); ctx.closePath(); ctx.fill(); // nose
  ctx.lineWidth = 0.9;
  ctx.beginPath(); ctx.moveTo(3.2, 6.3); ctx.lineTo(8.2, 5.8);                                   // teeth
  for (let i = 0; i < 4; i++) { ctx.moveTo(4.2 + i * 1.15, 5.3); ctx.lineTo(4.3 + i * 1.15, 7.2); }
  ctx.stroke();
  if (crack === 0) {
    // the fracture runs out from where the arrow went in
    let lx = ((pt.x - P[0].x) * fw.x + (pt.y - P[0].y) * fw.y) / s; let ly = ((pt.x - P[0].x) * -up.x + (pt.y - P[0].y) * -up.y) / s;
    const ll = Math.hypot(lx, ly); if (ll > 7.5) { lx *= 7.5 / ll; ly *= 7.5 / ll; }
    ctx.lineWidth = 1.15; ctx.lineJoin = 'miter';
    const grow = 0.35 + 0.65 * Math.min(1, t * 2.2);
    for (let i = 0; i < 6; i++) {
      const a = i * 1.05 + 0.4 + Math.sin(i * 7.3) * 0.3; const L = (5 + (i % 3) * 2.6) * grow;
      const mx = lx + Math.cos(a) * L * 0.5 + Math.cos(a + 1.5) * 1.3; const my = ly + Math.sin(a) * L * 0.5 + Math.sin(a + 1.5) * 1.3;
      ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(mx, my); ctx.lineTo(lx + Math.cos(a) * L, ly + Math.sin(a) * L); ctx.stroke();
    }
    ctx.beginPath(); ctx.arc(lx, ly, 1.7, 0, Math.PI * 2); ctx.fill();
  }
  ctx.shadowBlur = glow;
  ctx.restore();
}

/** a throwing axe; `p` is the grip, the haft runs along `ang` and the blade hangs off its far end */
export function drawAxe(ctx: Ctx, p: V, ang: number, s: number) {
  ctx.save();
  ctx.translate(p.x, p.y); ctx.rotate(ang); ctx.scale(s, s);
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#3a2013'; ctx.lineWidth = 4.6; ctx.beginPath(); ctx.moveTo(-7, 0); ctx.lineTo(25, 0); ctx.stroke();
  ctx.strokeStyle = '#7a4a2a'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(24, 0); ctx.stroke();
  ctx.fillStyle = '#7f9199';
  ctx.beginPath(); ctx.moveTo(14, -1.5); ctx.quadraticCurveTo(15.5, -11, 11, -17); ctx.quadraticCurveTo(22, -19, 30, -12); ctx.quadraticCurveTo(26.5, -6, 27, -1.5); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#dbe8ec';
  ctx.beginPath(); ctx.moveTo(12.5, -15.5); ctx.quadraticCurveTo(22, -18.5, 29, -12.5); ctx.quadraticCurveTo(21.5, -14.5, 14.5, -11); ctx.closePath(); ctx.fill();
  ctx.restore();
}

const cubic = (a: number, b: number, c: number, d: number, t: number) => {
  const m = 1 - t;
  return m * m * m * a + 3 * m * m * t * b + 3 * m * t * t * c + t * t * t * d;
};

/**
 * The recurve bow: one clean red-brown limb top and bottom with a soft highlight, dark grip, thin white
 * string. `nockDist` is how far the string is pulled from the grip (world px); the limbs bend to match.
 * `vib` wobbles the loose string after a release.
 */
export function drawBow(ctx: Ctx, grip: V, ang: number, s: number, nockDist: number | null, vib = 0, arrow = false) {
  ctx.save();
  ctx.translate(grip.x, grip.y); ctx.rotate(ang); ctx.scale(s, s);
  const nd = nockDist === null ? BRACE - 2 : nockDist / s;
  const pull = Math.max(0, Math.min(1.15, (nd - BRACE) / DRAW));
  const tipX = -9 - 10 * pull; const tipY = 35 - 5 * pull;
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  for (const sd of [-1, 1]) {
    const X = (t: number) => cubic(1.5, 12, 6, tipX, t);
    const Y = (t: number) => sd * cubic(4, 13, 25, tipY, t);
    const run = (t0: number, t1: number, col: string, lw: number) => {
      ctx.strokeStyle = col; ctx.lineWidth = lw;
      ctx.beginPath();
      for (let i = 0; i <= 10; i++) { const t = t0 + ((t1 - t0) * i) / 10; if (i) ctx.lineTo(X(t), Y(t)); else ctx.moveTo(X(t), Y(t)); }
      ctx.stroke();
    };
    run(0, 1, '#7c2516', 5.6);
    run(0.03, 0.97, '#b9452a', 3.4);
    run(0.1, 0.9, '#d9683f', 1.2);
    // the recurve flick at the tip
    ctx.strokeStyle = '#7c2516'; ctx.lineWidth = 3.6;
    ctx.beginPath(); ctx.moveTo(tipX, sd * tipY); ctx.quadraticCurveTo(tipX + 1, sd * (tipY + 4), tipX + 6, sd * (tipY + 5)); ctx.stroke();
  }
  ctx.strokeStyle = '#3d160c'; ctx.lineWidth = 6.8;
  ctx.beginPath(); ctx.moveTo(1.5, -6); ctx.lineTo(1.5, 6); ctx.stroke();
  const nx = nockDist === null ? tipX + vib : -nd;
  ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.35;
  ctx.beginPath(); ctx.moveTo(tipX, -tipY); ctx.lineTo(nx, 0); ctx.lineTo(tipX, tipY); ctx.stroke();
  ctx.restore();
  if (arrow) {
    const tip = add(grip, fromAngle(ang, (-nd + ARROW_LEN) * s));
    drawArrow(ctx, tip, ang, s, false);
  }
}

export const ARROW_LEN = 48;
/** orange shaft, red fletching, steel head; `embedded` hides the head inside whatever it hit */
export function drawArrow(ctx: Ctx, tip: V, ang: number, s = 1, embedded = false) {
  ctx.save();
  ctx.translate(tip.x, tip.y); ctx.rotate(ang); ctx.scale(s, s);
  const L = ARROW_LEN;
  ctx.lineCap = 'butt';
  ctx.strokeStyle = '#f5a92f'; ctx.lineWidth = 2.4;
  ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(embedded ? -0.5 : -6, 0); ctx.stroke();
  ctx.fillStyle = '#e5352f';
  ctx.beginPath();
  ctx.moveTo(-L + 1, 0); ctx.lineTo(-L - 3, -4.4); ctx.lineTo(-L + 7, -4.4); ctx.lineTo(-L + 12, 0);
  ctx.lineTo(-L + 7, 4.4); ctx.lineTo(-L - 3, 4.4);
  ctx.closePath(); ctx.fill();
  if (!embedded) {
    ctx.fillStyle = '#a9b6bb';
    ctx.beginPath(); ctx.moveTo(1, 0); ctx.lineTo(-9, -3.6); ctx.lineTo(-6.5, 0); ctx.lineTo(-9, 3.6); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}
