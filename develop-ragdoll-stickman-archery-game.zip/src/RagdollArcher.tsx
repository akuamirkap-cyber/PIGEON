import { ReactNode, useEffect, useRef, useState } from 'react';
import { RagdollGame, RUi, UP_MAX, UpId } from './game/ragdoll/game';
import { audioInit, audioMute, snd } from './game/ragdoll/audio';

/* ---------- icons ---------- */

function Coins({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 32" className={className} aria-hidden>
      <path d="M4 20l7-9 9 2 2 9-9 7z" fill="#f59f1b" />
      <path d="M4 20l7-9 4 6-2 12z" fill="#ffc94a" />
      <path d="M15 9l10-6 9 6-3 10-12 1z" fill="#ffb52e" />
      <path d="M15 9l10-6 1 9-7 8z" fill="#ffe08a" />
      <path d="M20 24l9-5 8 4-5 7-10-1z" fill="#f08c12" />
      <path d="M20 24l9-5 1 6-8 4z" fill="#ffc94a" />
    </svg>
  );
}

function Skull({ className = '', fill = '#ffffff', hole = '#000000' }: { className?: string; fill?: string; hole?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path d="M12 1.8C6.8 1.8 3 5.5 3 10.3c0 2.6 1.1 4.6 2.9 5.9v3A1.8 1.8 0 0 0 7.7 21h8.6a1.8 1.8 0 0 0 1.8-1.8v-3c1.8-1.3 2.9-3.3 2.9-5.9C21 5.5 17.2 1.8 12 1.8z" fill={fill} />
      <circle cx="8.4" cy="10.8" r="2.5" fill={hole} />
      <circle cx="15.6" cy="10.8" r="2.5" fill={hole} />
      <path d="M12 13.3l-1.4 2.6h2.8z" fill={hole} />
      <path d="M9.5 17.8V21M12 17.8V21M14.5 17.8V21" stroke={hole} strokeWidth="1.1" />
    </svg>
  );
}

function Castle({ n, color, small = false }: { n: number; color: string; small?: boolean }) {
  return (
    <div className={`relative z-10 shrink-0 ${small ? 'h-10 w-10' : 'h-11 w-11 sm:h-14 sm:w-14'}`}>
      <svg viewBox="0 0 44 44" className="h-full w-full drop-shadow-[0_2px_0_rgba(0,0,0,0.3)]" aria-hidden>
        <path d="M3 2h8v6h6V2h10v6h6V2h8v15l-4 4v21H7V21l-4-4z" fill={color} />
      </svg>
      <span className={`font-game absolute inset-0 grid place-items-center pt-3 leading-none text-white ${small ? 'text-base' : 'text-lg sm:text-2xl'}`}>{n}</span>
    </div>
  );
}

function Star({ on, delay }: { on: boolean; delay: number }) {
  return (
    <svg viewBox="0 0 48 48" className="g-star h-16 w-16 sm:h-20 sm:w-20" style={{ animationDelay: `${delay}ms` }} aria-hidden>
      <path d="M24 3.5l6.2 13.1 14.3 1.9-10.5 10 2.7 14.2L24 35.8 11.3 42.7 14 28.5 3.5 18.5l14.3-1.9z" fill={on ? '#ffd23f' : '#0a3140'} stroke="#031a24" strokeWidth="3" strokeLinejoin="round" />
      {on && <path d="M24 9l4 9.5 9 1.2" fill="none" stroke="#fff6c4" strokeWidth="2.4" strokeLinecap="round" />}
    </svg>
  );
}

const I = {
  play: <path d="M8 4.5v15l12-7.5z" fill="currentColor" />,
  pause: <><rect x="6" y="5" width="4.5" height="14" rx="1" fill="currentColor" /><rect x="13.5" y="5" width="4.5" height="14" rx="1" fill="currentColor" /></>,
  retry: <path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z" fill="currentColor" />,
  home: <path d="M12 3l9 8h-2.5v9h-5v-6h-3v6h-5v-9H3z" fill="currentColor" />,
  first: <path d="M6 5h2.5v14H6zM19 5v14l-9.5-7z" fill="currentColor" />,
  soundOn: <><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor" /><path d="M15 8.5a5 5 0 0 1 0 7M17.5 6a8.5 8.5 0 0 1 0 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" /></>,
  soundOff: <><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor" /><path d="M15 9.5l5 5m0-5l-5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" /></>,
  target: <><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2.4" /><circle cx="12" cy="12" r="4.6" fill="none" stroke="currentColor" strokeWidth="2.4" /><circle cx="12" cy="12" r="1.6" fill="currentColor" /></>,
  grid: <path d="M4 4h4.5v4.5H4zM9.750 4h4.5v4.5h-4.5zM15.5 4H20v4.5h-4.5zM4 9.750h4.5v4.5H4zM9.750 9.750h4.5v4.5h-4.5zM15.5 9.750H20v4.5h-4.5zM4 15.5h4.5V20H4zM9.750 15.5h4.5V20h-4.5zM15.5 15.5H20V20h-4.5z" fill="currentColor" />,
  cloud: <path d="M7 18a4.5 4.5 0 0 1-.600-8.960A6 6 0 0 1 18 10.2 4 4 0 0 1 17.5 18z" fill="currentColor" />,
  swords: <path d="M4 3l9.5 9.5-2 2L3 5zM20 3l-9.5 9.5 2 2L21 5zM6.5 14.5l3 3-1.5 1.5 1.5 1.5-1.5 1.5L6.5 20.5 5 22l-3-3 1.5-1.5L2 16l1.5-1.5L5 16zM17.5 14.5l-3 3 1.5 1.5-1.5 1.5 1.5 1.5 1.5-1.5L19 22l3-3-1.5-1.5L22 16l-1.5-1.5L19 16z" fill="currentColor" />,
  ground: <path d="M3 9h18v7H3zM6 16h3v4H6zM14 16h4v3h-4z" fill="currentColor" />,
};
function Ico({ d, className = 'h-6 w-6' }: { d: ReactNode; className?: string }) {
  return <svg viewBox="0 0 24 24" className={className} aria-hidden>{d}</svg>;
}

const UPS: { id: UpId; name: string; icon: ReactNode }[] = [
  { id: 'hp', name: 'NYAWA +20', icon: <path d="M12 20.5S3.5 15 3.5 9a4.5 4.5 0 0 1 8.5-2 4.5 4.5 0 0 1 8.5 2c0 6-8.5 11.5-8.5 11.5z" fill="#ff5a5f" stroke="#031a24" strokeWidth="1.4" /> },
  { id: 'dmg', name: 'TENAGA +18%', icon: <path d="M13.5 2L5 13.5h5.5L9.5 22 19 10h-6z" fill="#ffd23f" stroke="#031a24" strokeWidth="1.4" strokeLinejoin="round" /> },
  {
    id: 'multi', name: 'PANAH GANDA',
    icon: (
      <g strokeLinecap="round" fill="none">
        <path d="M3 18L19 5M3 12l15-1M5 21l15-6" stroke="#f5a92f" strokeWidth="2.2" />
        <path d="M19 5l-4.5.500M19 5l-.800 4.4M18 11l-3.5-2M18 11l-3 2.5M20 15l-4-.800M20 15l-2.5 3.3" stroke="#e8f4f7" strokeWidth="1.8" />
      </g>
    ),
  },
  { id: 'leech', name: '+5 NYAWA / KILL', icon: <path d="M12 2.5S5.5 10 5.5 14.5a6.5 6.5 0 0 0 13 0C18.5 10 12 2.5 12 2.5z" fill="#5cf08a" stroke="#031a24" strokeWidth="1.4" /> },
];

/* ---------- little pieces ---------- */

/** numbers that roll up to their value instead of jumping */
function useCount(target: number) {
  const [val, setVal] = useState(target);
  const cur = useRef(target);
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const d = target - cur.current;
      if (Math.abs(d) < 1) { cur.current = target; setVal(target); return; }
      cur.current += d * 0.16 + Math.sign(d) * 0.6;
      setVal(Math.round(cur.current));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return val;
}

function Btn({ tone, className = '', onClick, children, label, disabled }: { tone: 'orange' | 'green' | 'dark' | 'red'; className?: string; onClick: () => void; children: ReactNode; label?: string; disabled?: boolean }) {
  return (
    <button aria-label={label} title={label} disabled={disabled} onClick={() => { audioInit(); snd.tap(); onClick(); }} className={`g-btn g-${tone} font-game ${className}`}>
      {children}
    </button>
  );
}

function Pill({ icon, children, label }: { icon: ReactNode; children: ReactNode; label: string }) {
  return (
    <div aria-label={label} className="relative flex h-8 min-w-[5.5rem] items-center rounded-full bg-black/85 pl-11 pr-4 sm:h-10 sm:min-w-[7.5rem] sm:pl-14 sm:pr-5">
      <span className="absolute -left-1 top-1/2 -translate-y-1/2">{icon}</span>
      <span className="font-game text-lg leading-none text-white tabular-nums sm:text-2xl">{children}</span>
    </div>
  );
}

function Panel({ ribbon, tone = '', children }: { ribbon: string; tone?: string; children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-20 grid place-items-center overflow-y-auto bg-[#01121b]/60 px-3 py-8">
      <div className="g-pop relative w-full max-w-[25rem]">
        <div className={`g-ribbon ${tone} font-game text-xl sm:text-2xl`}>{ribbon}</div>
        <div className="g-panel px-4 pb-5 pt-10 text-white sm:px-6">{children}</div>
      </div>
    </div>
  );
}

function Stat({ icon, value }: { icon: ReactNode; value: ReactNode }) {
  return (
    <div className="g-chip flex items-center gap-2 py-1.5 pl-2 pr-4">
      {icon}
      <span className="font-game text-xl leading-none tabular-nums">{value}</span>
    </div>
  );
}

interface Props {
  title: boolean; onStart: () => void; onExit: () => void; mute: boolean; onMute: () => void;
  cleared: number; levels: number; onPlay: () => void; onLevels: () => void; onStory: () => void; onWar: () => void; onDuel: () => void;
}

export default function RagdollArcher({ title, onStart, onExit, mute, onMute, cleared, levels, onPlay, onLevels, onStory, onWar, onDuel }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<RagdollGame | null>(null);
  const [ui, setUi] = useState<RUi | null>(null);
  const coins = useCount(ui?.coins ?? 0);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const g = new RagdollGame(c, setUi);
    gameRef.current = g;
    return () => { g.destroy(); gameRef.current = null; };
  }, []);

  // the same world is the title backdrop (playing itself) and the game
  useEffect(() => {
    const w = gameRef.current?.world;
    if (!w || w.demo === title) return;
    if (title) w.toDemo(); else w.startRun();
  }, [title]);

  useEffect(() => { audioMute(mute); }, [mute]);

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      const w = gameRef.current?.world;
      if (!w || w.demo || (e.key !== 'Escape' && e.key.toLowerCase() !== 'p')) return;
      if (w.stage === 'play' || w.stage === 'clear') w.setPaused(!w.paused);
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  // the stars land one by one, each with its own note
  const shop = ui?.stage === 'shop';
  const stars = ui?.stars ?? 0;
  useEffect(() => {
    if (!shop) return;
    const ids = Array.from({ length: stars }, (_, i) => window.setTimeout(() => snd.star(i), 380 + i * 280));
    return () => ids.forEach((id) => window.clearTimeout(id));
  }, [shop, stars]);

  const w = () => gameRef.current?.world;
  const demo = ui?.demo ?? true;
  const pct = ui ? Math.round((ui.kills / ui.total) * 100) : 0;
  const hpPct = ui ? Math.round((ui.hp / ui.maxHp) * 100) : 100;
  const nextGrounds = ui ? Math.min(1 + Math.floor((ui.level + 1) / 2), 5) : 1;
  const nextTotal = ui ? Math.min(2 + ui.level, 14) : 2;
  const sound = <Ico d={mute ? I.soundOff : I.soundOn} className="h-5 w-5" />;

  const modes: [string, ReactNode, () => void][] = [
    ['MISI', I.target, onPlay], ['LEVEL', I.grid, onLevels], ['STORY', I.cloud, onStory], ['PERANG', I.swords, onWar],
    ['DUEL', <text key="vs" x="12" y="16.5" textAnchor="middle" fontSize="11" fontWeight="900" fontStyle="italic" fill="currentColor">VS</text>, onDuel],
  ];

  return (
    <div className="absolute inset-0 z-30 overflow-hidden bg-[#0a4767] select-none">
      <canvas
        ref={canvasRef}
        onContextMenu={(e) => e.preventDefault()}
        aria-label="Arena ragdoll archer"
        className="absolute inset-0 h-full w-full touch-none cursor-crosshair"
      />

      {/* ============ title screen: the world keeps fighting behind it ============ */}
      {demo && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-between overflow-y-auto bg-gradient-to-b from-[#02141f]/45 via-transparent to-[#02141f]/55 p-3 sm:p-5">
          <div className="g-drop flex w-full items-start justify-between">
            <div className="g-chip flex items-center gap-2 py-1 pl-1.5 pr-4" aria-label={`Level terbaik ${ui?.best ?? 1}`}>
              <Castle n={ui?.best ?? 1} color="#2a78d8" small />
              <span className="font-game text-xs leading-tight text-white/80">LEVEL<br />TERBAIK</span>
            </div>
            <Btn tone="dark" label={mute ? 'Nyalakan suara' : 'Matikan suara'} onClick={onMute} className="h-11 w-11">{sound}</Btn>
          </div>

          <div className="flex flex-col items-center py-4">
            <h1 aria-label="Ragdoll Archer" className="g-float font-game relative text-center leading-[0.84]">
              <svg viewBox="0 0 300 24" className="absolute left-1/2 top-1/2 z-10 w-[118%] -translate-x-1/2 -translate-y-1/2 -rotate-3 drop-shadow-[0_3px_0_rgba(0,0,0,0.35)]" aria-hidden>
                <path d="M14 12H282" stroke="#f5a92f" strokeWidth="4" strokeLinecap="round" />
                <path d="M2 4l14 8-14 8 6-8zM10 2l18 10-18 10 6-10z" fill="#e5352f" stroke="#031a24" strokeWidth="1.5" strokeLinejoin="round" />
                <path d="M298 12l-22-8 5 8-5 8z" fill="#cfdde2" stroke="#031a24" strokeWidth="1.5" strokeLinejoin="round" />
              </svg>
              <span className="g-title relative block text-[clamp(3.2rem,15vw,7rem)] text-white">RAGDOLL</span>
              <span className="g-title relative z-20 block text-[clamp(3.2rem,15vw,7rem)] text-[#ffb02e]">ARCHER</span>
            </h1>
            <div className="g-pulse mt-7 sm:mt-9">
              <Btn tone="orange" label="Main" onClick={onStart} className="h-[4.5rem] gap-3 px-10 text-4xl sm:h-20 sm:px-14 sm:text-5xl">
                <Ico d={I.play} className="h-9 w-9 sm:h-11 sm:w-11" />
                MAIN
              </Btn>
            </div>
          </div>

          <nav aria-label="Mode klasik" className="g-rise flex flex-wrap items-end justify-center gap-2.5 pb-1 sm:gap-4">
            {modes.map(([name, icon, go]) => (
              <div key={name} className="flex flex-col items-center gap-1">
                <Btn tone="dark" label={name === 'MISI' ? `Misi, ${cleared} dari ${levels} selesai` : name} onClick={go} className="h-12 w-12 text-[#bff4fa] sm:h-14 sm:w-14">
                  <Ico d={icon} className="h-6 w-6 sm:h-7 sm:w-7" />
                </Btn>
                <span className="font-game g-outline text-[11px] leading-none text-white sm:text-xs">{name}</span>
              </div>
            ))}
          </nav>
        </div>
      )}

      {/* ============ HUD ============ */}
      {ui && !demo && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex flex-wrap items-start gap-x-3 gap-y-2 p-2 sm:p-4">
          <div className="order-1">
            <div className="flex gap-3 pl-1 sm:gap-4">
              <Pill label="Koin" icon={<span key={ui.bump} className="g-bump-icon block"><Coins className="h-8 w-10 sm:h-10 sm:w-12" /></span>}><span key={ui.bump} className="g-bump inline-block">{ui.shown}</span></Pill>
              <Pill label="Total musuh tumbang" icon={<Skull className="h-9 w-9 sm:h-11 sm:w-11" hole="#111" />}>{ui.totalKills}</Pill>
            </div>
            <div className="mt-2 hidden items-center gap-2 pl-1 sm:flex" aria-label={`Nyawa ${ui.hp} dari ${ui.maxHp}`}>
              <svg viewBox="0 0 24 24" className={`h-6 w-6 ${hpPct <= 30 ? 'g-pulse' : ''}`} aria-hidden>
                <path d="M12 20.5S3.5 15 3.5 9a4.5 4.5 0 0 1 8.5-2 4.5 4.5 0 0 1 8.5 2c0 6-8.5 11.5-8.5 11.5z" fill={hpPct <= 30 ? '#ff5a4f' : '#5cf08a'} stroke="#031a24" strokeWidth="1.5" />
              </svg>
              <div className="h-4 w-40 overflow-hidden rounded-full border-2 border-[#031a24] bg-black/60">
                <div className={`h-full transition-all duration-300 ${hpPct <= 30 ? 'bg-[#ff5a4f]' : 'bg-[#5cf08a]'}`} style={{ width: `${hpPct}%` }} />
              </div>
              <span className="font-game g-outline text-sm text-white tabular-nums">{ui.hp}</span>
            </div>
          </div>

          <div className="order-3 mx-auto w-full max-w-[460px] sm:order-2 sm:w-auto sm:flex-1" aria-label={`Level ${ui.level}, ${ui.kills} dari ${ui.total} musuh`}>
            <div className="flex items-center">
              <Castle n={ui.level} color="#2a78d8" />
              <div className="relative -mx-1.5 h-3.5 flex-1 overflow-hidden bg-[#06202e]/90 sm:h-4">
                <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#2a78d8] to-[#a9dcff] transition-all duration-500" style={{ width: `${pct}%` }} />
                <div className="absolute inset-x-0 top-0 h-1 bg-white/15" />
              </div>
              <Castle n={ui.level + 1} color="#06202e" />
            </div>
            <div className="relative mx-auto -mt-0.5 flex w-fit items-center gap-1.5 rounded-md bg-[#a7c3c8]/90 px-2.5 py-0.5 shadow">
              <span className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 bg-[#a7c3c8]/90" />
              <Skull className="relative h-5 w-5" hole="#06202e" />
              <span className="font-game relative text-base leading-none text-[#06202e] tabular-nums">{ui.kills}/{ui.total}</span>
              {ui.boss && <span className="font-game relative rounded bg-[#e5352f] px-1.5 text-[10px] leading-4 text-white">BOS</span>}
              {ui.hostage > 0 && (
                <span aria-label={ui.hostage === 2 ? 'Tawanan bebas' : 'Bebaskan tawanan'} className={`font-game relative flex items-center gap-1 rounded px-1.5 text-[10px] leading-4 text-white ${ui.hostage === 2 ? 'bg-[#2fae3c]' : 'bg-[#d98a00]'}`}>
                  <svg viewBox="0 0 16 16" className="h-3 w-3" aria-hidden>
                    <circle cx="8" cy="3.4" r="2.6" fill="currentColor" />
                    <path d="M8 6v8" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
                    {ui.hostage === 1 && <path d="M4.5 8.5h7M4.5 11h7" stroke="#06202e" strokeWidth="1.4" />}
                  </svg>
                  {ui.hostage === 2 ? 'BEBAS' : 'TAWANAN'}
                </span>
              )}
            </div>
          </div>

          <div className="pointer-events-auto order-2 ml-auto flex gap-2 sm:order-3">
            <Btn tone="orange" label={mute ? 'Nyalakan suara' : 'Matikan suara'} onClick={onMute} className="h-10 w-10 sm:h-11 sm:w-11">{sound}</Btn>
            <Btn tone="orange" label="Jeda" onClick={() => w()?.setPaused(true)} className="h-10 w-10 sm:h-11 sm:w-11"><Ico d={I.pause} className="h-5 w-5" /></Btn>
          </div>
        </div>
      )}

      {/* how to shoot, shown as the gesture itself */}
      {ui?.hint && !demo && ui.stage === 'play' && !ui.paused && (
        <div className="pointer-events-none absolute inset-x-0 bottom-[16%] z-10 flex flex-col items-center gap-3">
          <div className="relative h-14 w-28">
            <span className="absolute right-3 top-2 h-9 w-9 rounded-full border-[3px] border-dashed border-white/60" />
            <span className="g-drag absolute right-5 top-4 h-5 w-5 rounded-full bg-white shadow-[0_0_0_6px_rgba(255,255,255,0.25)]" />
          </div>
          <span className="font-game g-outline text-lg text-white sm:text-xl">TARIK &amp; LEPAS</span>
        </div>
      )}

      {/* ============ pause ============ */}
      {ui?.paused && !demo && (
        <Panel ribbon="JEDA" tone="blue">
          <div className="flex items-center justify-center gap-4 pt-1">
            <Btn tone="dark" label="Ke menu" onClick={onExit} className="h-14 w-14"><Ico d={I.home} className="h-7 w-7" /></Btn>
            <Btn tone="green" label="Lanjut" onClick={() => w()?.setPaused(false)} className="h-20 w-20"><Ico d={I.play} className="h-11 w-11" /></Btn>
            <Btn tone="dark" label={`Ulangi level ${ui.level}`} onClick={() => w()?.retry()} className="h-14 w-14"><Ico d={I.retry} className="h-7 w-7" /></Btn>
          </div>
          <div className="mt-5 flex items-center justify-center gap-3">
            <Stat icon={<Castle n={ui.level} color="#2a78d8" small />} value={ui.theme.toUpperCase()} />
            <Btn tone="dark" label={mute ? 'Nyalakan suara' : 'Matikan suara'} onClick={onMute} className="h-11 w-11">{sound}</Btn>
          </div>
        </Panel>
      )}

      {/* ============ level complete + upgrades ============ */}
      {shop && ui && !ui.paused && (
        <Panel ribbon={`LEVEL ${ui.level} SELESAI!`}>
          <div className="flex items-end justify-center gap-1" aria-label={`${ui.stars} dari 3 bintang`}>
            {[0, 1, 2].map((i) => (
              <div key={i} className={i === 1 ? '-translate-y-3' : ''}><Star on={i < ui.stars} delay={350 + i * 280} /></div>
            ))}
          </div>
          <div className="mt-2 flex items-center justify-center gap-2.5">
            <Stat icon={<Coins className="h-7 w-9" />} value={coins} />
            <span className="font-game g-outline text-lg text-[#ffd23f]">+{ui.reward}</span>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2.5">
            {UPS.map((u) => {
              const cost = ui.cost[u.id];
              const can = cost !== null && ui.coins >= cost;
              return (
                <button
                  key={u.id}
                  onClick={() => w()?.buy(u.id)}
                  aria-label={`${u.name}, ${cost === null ? 'maksimal' : `${cost} koin`}`}
                  aria-disabled={!can}
                  className={`g-btn g-dark flex-col gap-1 px-2 pb-2 pt-2.5 ${can ? '' : 'opacity-60 saturate-50'}`}
                >
                  <svg viewBox="0 0 24 24" className="h-10 w-10" aria-hidden>{u.icon}</svg>
                  <span className="font-game text-[13px] leading-none">{u.name}</span>
                  <span className="flex gap-0.5" aria-hidden>
                    {Array.from({ length: UP_MAX[u.id] }, (_, i) => (
                      <span key={i} className={`h-1.5 w-2.5 rounded-sm ${i < ui.up[u.id] ? 'bg-[#ffb02e]' : 'bg-black/40'}`} />
                    ))}
                  </span>
                  <span className={`g-chip mt-0.5 flex items-center gap-1 py-0.5 pl-1 pr-2.5 ${cost === null ? 'text-[#5cf08a]' : can ? 'text-[#ffd23f]' : 'text-white/60'}`}>
                    {cost !== null && <Coins className="h-5 w-6" />}
                    <span className="font-game text-base leading-none tabular-nums">{cost === null ? 'MAKS' : cost}</span>
                  </span>
                </button>
              );
            })}
          </div>

          <Btn tone="green" label={`Lanjut ke level ${ui.level + 1}`} onClick={() => w()?.nextLevel()} className="mt-5 h-16 w-full text-2xl">
            LEVEL {ui.level + 1}
            <Ico d={I.play} className="h-8 w-8" />
          </Btn>
          <div className="mt-4 flex items-center justify-center gap-4 text-[#bff4fa]" aria-label={`Berikutnya ${nextGrounds} pijakan, ${nextTotal} musuh`}>
            <span className="flex items-center gap-1.5"><Ico d={I.ground} className="h-5 w-5" /><span className="font-game text-base">×{nextGrounds}</span></span>
            <span className="flex items-center gap-1.5"><Skull className="h-5 w-5" fill="#bff4fa" hole="#0b3443" /><span className="font-game text-base">×{nextTotal}</span></span>
            {(ui.level + 1) % 5 === 0 && <span className="font-game rounded bg-[#e5352f] px-2 text-xs leading-5 text-white">BOS</span>}
          </div>
        </Panel>
      )}

      {/* ============ defeat ============ */}
      {ui?.stage === 'dead' && !ui.paused && !demo && (
        <Panel ribbon="KALAH" tone="red">
          <div className="flex justify-center"><Skull className="g-float h-24 w-24" hole="#082a38" /></div>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
            <Stat icon={<Castle n={ui.level} color="#2a78d8" small />} value="LEVEL" />
            <Stat icon={<Skull className="h-7 w-7" hole="#04202c" />} value={ui.totalKills} />
            <Stat icon={<Ico d={I.target} className="h-7 w-7 text-[#ffd23f]" />} value={ui.headshots} />
          </div>
          <Btn tone="orange" label={`Ulangi level ${ui.level}`} onClick={() => w()?.retry()} className="mt-5 h-16 w-full text-2xl">
            <Ico d={I.retry} className="h-8 w-8" />
            ULANGI
          </Btn>
          <div className="mt-4 flex justify-center gap-4">
            <Btn tone="dark" label="Mulai dari level 1" onClick={() => w()?.restart()} className="h-14 w-14"><Ico d={I.first} className="h-7 w-7" /></Btn>
            <Btn tone="dark" label="Ke menu" onClick={onExit} className="h-14 w-14"><Ico d={I.home} className="h-7 w-7" /></Btn>
          </div>
        </Panel>
      )}
    </div>
  );
}
