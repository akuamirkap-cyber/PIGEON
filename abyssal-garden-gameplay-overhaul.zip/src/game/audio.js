// ============================================================================
// audio: procedural underwater ambience (100% Noniv/abyssal-garden + sub foley)
// ============================================================================
import { min, pow, exp, hypot, clamp, ernd, err } from './math.js';

export function createAudio(getCamPos) {
  let AC = null, OUT = null, muted = false;
  let subHumG = null, subHumF = null, subPropO = null, playFn = null, bubPool = null, chimePool = null, whalePool = null, wetNode = null;
  let subThr = 0, subActive = false;
  const VOL = 0.78;

  function mkSound(ac) {
    const sr = ac.sampleRate;
    const N = (C, o, ...to) => { const n = new C(ac, o); for (const d of to) n.connect(d); if (n.start) n.start(); return n; };
    const G = (gain, ...to) => N(GainNode, { gain }, ...to);
    const BQ = (type, frequency, Q, ...to) => N(BiquadFilterNode, { type, frequency, Q }, ...to);
    const lfo = (frequency, depth, to) => N(OscillatorNode, { frequency }, G(depth, to));
    const noise = (secs, f) => {
      const n = sr * secs | 0, b = new AudioBuffer({ length: n, numberOfChannels: 2, sampleRate: sr });
      f(b.getChannelData(0), n); f(b.getChannelData(1), n); return b;
    };
    // seamless brown noise loop (100% identical to Noniv/abyssal-garden)
    const nb = noise(11, (d, n) => {
      for (let i = 0, b = 0; i < n + 4096; i++) {
        b = (b + 0.02 * (ernd() * 2 - 1)) / 1.02;
        if (i < n) d[i] = b * 3.5;
        else { const k = (i - n) / 4096; d[i - n] = d[i - n] * k + b * 3.5 * (1 - k); }
      }
    });
    // reverb impulse: 5 s of noise that fades out and gets darker
    const ir = noise(5, (d, n) => {
      for (let i = 0, b = 0; i < n; i++) {
        const t = i / sr;
        b += (ernd() * 2 - 1 - b) * (0.04 + 0.5 * exp(-t * 2));
        d[i] = b * (1 - exp(-t * 30)) * exp(-t * 1.5) * (1 - i / n);
      }
    });

    const lim = N(DynamicsCompressorNode, { threshold: -6, knee: 6, ratio: 20, attack: 0.003, release: 0.3 }, ac.destination);
    const out = OUT = G(0, lim), wet = wetNode = N(ConvolverNode, { buffer: ir }, out);
    const src = (playbackRate, ...to) => N(AudioBufferSourceNode, { buffer: nb, loop: true, playbackRate }, ...to);
    // rumble
    const rum = G(0.34, out); src(1, BQ('lowpass', 150, 0.7, rum)); lfo(0.07, 0.11, rum.gain); lfo(0.113, 0.08, rum.gain);
    // surface wash + water rush
    const wash = G(0.25, out), wave = G(1, wash), rush = G(0, out), rushF = BQ('bandpass', 300, 0.9, rush);
    src(0.63, BQ('bandpass', 420, 0.5, wave), rushF); lfo(0.09, 0.3, wave.gain); lfo(0.151, 0.25, wave.gain);
    // drone: stacked fifths on D
    const pad = G(1, out, G(1.5, wet));
    [73.42, 110, 164.81, 246.94, 369.99].forEach((f, i) => {
      const g = G(0.022 - i * 0.003, pad);
      N(OscillatorNode, { frequency: f }, g);
      N(OscillatorNode, { frequency: f + err(0.03, 0.11) }, g);
    });

    // Subtle vintage submarine electric-brass turbine & propeller thrum (silent when outside)
    subHumG = G(0, out);
    subHumF = BQ('lowpass', 110, 1.4, subHumG);
    subPropO = N(OscillatorNode, { type: 'sawtooth', frequency: 44 }, subHumF);
    src(0.82, BQ('bandpass', 95, 1.8, subHumG));

    // pooled voices: oscillator -> envelope -> pan -> dry + reverb
    const pool = (n, send, type) => Array.from({ length: n }, () => {
      const p = N(StereoPannerNode, {}, out, G(send, wet)), g = G(0, p);
      return { p, g, o: N(OscillatorNode, { type }, g) };
    });
    const bub = bubPool = pool(5, 0.12);
    const chime = chimePool = pool(4, 1.2);
    const whale = whalePool = pool(2, 2, 'triangle');

    const play = playFn = (vs, t, f0, f1, dur, vol, att) => {
      const v = vs.shift(), f = v.o.frequency, g = v.g.gain; vs.push(v);
      v.p.pan.setValueAtTime(err(-0.7, 0.7), t);
      f.setValueAtTime(f0, t); f.exponentialRampToValueAtTime(f1, t + dur);
      g.setValueAtTime(0, t); g.linearRampToValueAtTime(vol, t + att); g.setTargetAtTime(0, t + att, (dur - att) / 5);
    };

    const NOTES = [0, 2, 5, 7, 9, 12, 14, 17, 19]; // D major pentatonic
    const p0 = getCamPos();
    let lt = ac.currentTime, tB = lt + 1.5, tC = lt + 5, tW = lt + 12, tS = lt + 9;
    let lx = p0[0], ly = p0[1], lz = p0[2];
    out.gain.setTargetAtTime(VOL, lt, 1);

    return () => {
      const now = ac.currentTime, t = now + 0.05, dt = now - lt;
      if (dt <= 0) return;
      const cp = getCamPos();
      let v = hypot(cp[0] - lx, cp[1] - ly, cp[2] - lz) / dt;
      if (v > 60) v = 0;
      lt = now; lx = cp[0]; ly = cp[1]; lz = cp[2];

      rush.gain.setTargetAtTime(0.5 * pow(min(v / 26, 1), 1.2), t, 0.3);
      rushF.frequency.setTargetAtTime(220 + v * 14, t, 0.3);
      const s = clamp(1 + ly / 30, 0, 1);
      wash.gain.setTargetAtTime(0.25 + 0.55 * s * s, t, 0.5);

      // Update vintage submarine engine & propeller hum
      const wantHum = subActive ? (0.045 + 0.14 * min(subThr, 1.2)) : (subThr > 0 ? 0.04 : 0);
      subHumG.gain.setTargetAtTime(wantHum, t, 0.25);
      subPropO.frequency.setTargetAtTime(38 + subThr * 34, t, 0.25);
      subHumF.frequency.setTargetAtTime(85 + subThr * 95, t, 0.25);

      // Gentle occasional submarine ambient sonar ping while piloting
      if (subActive && t > tS) {
        play(chime, t, 1174.66, 1170, 2.8, 0.018, 0.012);
        tS = t + err(14, 26);
      }

      if (t > tB) {
        let tt = t;
        for (let n = 1 + ernd() * ernd() * 6 | 0; n--;) {
          const f = err(380, 1300);
          play(bub, tt, f, f * err(1.4, 2.2), 0.05 + 40 / f, err(0.03, 0.08), 0.006);
          tt += err(0.07, 0.2);
        }
        tB = tt + err(0.5, 4.2);
      }
      if (t > tC) {
        const f = 440 * pow(2, NOTES[ernd() * 9 | 0] / 12);
        play(chime, t, f, f, 5, err(0.02, 0.04), 0.03);
        tC = t + err(2.5, 9);
      }
      if (t > tW) {
        let tt = t;
        for (let n = 2 + ernd() * 2 | 0; n--;) {
          const f = err(170, 380), d = err(1.6, 3.2);
          play(whale, tt, f, f * err(0.6, 1.7), d, 0.08, d * 0.4);
          tt += d * 0.8;
        }
        tW = tt + err(20, 50);
      }
    };
  }

  let timerId = null;
  function sound() {
    if (!AC) {
      try {
        AC = new AudioContext({ latencyHint: 'playback' });
        timerId = setInterval(mkSound(AC), 100);
      } catch { return; }
    }
    if (AC && AC.state === 'suspended' && !document.hidden) AC.resume().catch(() => {});
  }

  function mute() {
    sound();
    muted = !muted;
    if (OUT && AC) OUT.gain.setTargetAtTime(muted ? 0 : VOL, AC.currentTime, 0.08);
    return muted;
  }

  // Vintage brass hatch thud + ballast bubble cascade on board/disembark
  function onHatch(boarding) {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.02;
    // Deep metallic brass hatch clunk
    const o = new OscillatorNode(AC, { type: 'triangle', frequency: boarding ? 145 : 175 });
    const g = new GainNode(AC, { gain: 0 });
    o.connect(g); g.connect(OUT); if (wetNode) g.connect(wetNode);
    o.frequency.exponentialRampToValueAtTime(52, t + 0.24);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.16, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
    o.start(t); o.stop(t + 0.38);
    // Airlock bubble stream
    for (let k = 0; k < 5; k++) {
      const f = err(420, 1150);
      playFn(bubPool, t + 0.05 + k * 0.06, f, f * 1.85, 0.09, 0.065, 0.006);
    }
  }

  function onBell() {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.02;
    // Friendly two-note D-major brass dive-bell to gather the 5 friend bots
    playFn(chimePool, t, 587.33, 587.33, 2.6, 0.055, 0.01);
    playFn(chimePool, t + 0.14, 880.0, 880.0, 3.0, 0.05, 0.01);
  }

  function onSonar() {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.02;
    playFn(chimePool, t, 1174.66, 1168, 3.2, 0.06, 0.008);
    playFn(chimePool, t + 0.45, 880.0, 876, 2.8, 0.035, 0.012);
  }

  function onSwitch(on) {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.01;
    playFn(bubPool, t, on ? 720 : 560, on ? 960 : 420, 0.055, 0.04, 0.004);
  }

  function onHarpoonShot(hit) {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.01;
    playFn(bubPool, t, 380, 125, 0.16, 0.085, 0.006);
    playFn(chimePool, t + 0.018, hit ? 1046 : 784, hit ? 880 : 392, 0.22, 0.035, 0.004);
  }

  function onHarpoonHit() {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.01;
    playFn(chimePool, t, 880, 1318, 0.28, 0.045, 0.008);
  }

  function onHarpoonReel() {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.01;
    playFn(bubPool, t, 155, 248, 0.72, 0.055, 0.08);
    playFn(chimePool, t + 0.05, 440, 660, 0.48, 0.022, 0.06);
  }

  function onHarpoonMiss() {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.01;
    playFn(bubPool, t, 620, 180, 0.22, 0.04, 0.008);
  }

  function onFishCatch() {
    if (!AC || !playFn || muted) return;
    const t = AC.currentTime + 0.01;
    playFn(chimePool, t, 659.25, 659.25, 0.9, 0.04, 0.01);
    playFn(chimePool, t + 0.12, 987.77, 987.77, 1.15, 0.035, 0.015);
  }

  // Deep awe-inspiring leviathan resonance when the 10x Giant Manta Ray glides in front of the submarine!
  function onLeviathan() {
    if (!AC || !playFn || !whalePool || muted) return;
    const t = AC.currentTime + 0.08;
    playFn(whalePool, t, 92, 58, 4.4, 0.14, 1.4);
    playFn(whalePool, t + 1.8, 138, 82, 3.8, 0.09, 1.2);
  }

  function setSubThrottle(thr, active) {
    subThr = thr;
    subActive = active;
  }

  const onVis = () => { if (AC) (document.hidden ? AC.suspend() : AC.resume()).catch(() => {}); };
  document.addEventListener('visibilitychange', onVis);

  function destroy() {
    if (timerId) clearInterval(timerId);
    document.removeEventListener('visibilitychange', onVis);
    if (AC) AC.close().catch(() => {});
  }

  return {
    sound, mute, isMuted: () => muted,
    onHatch, onBell, onSonar, onSwitch, onLeviathan,
    onHarpoonShot, onHarpoonHit, onHarpoonReel, onHarpoonMiss, onFishCatch,
    setSubThrottle, destroy,
  };
}
