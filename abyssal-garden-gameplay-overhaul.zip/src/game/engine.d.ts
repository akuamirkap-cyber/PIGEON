export const VIEWPOINT_NAMES: string[];

export interface HudState {
  inSub: boolean;
  miniMode: boolean;
  midnightMode: boolean;
  nearSub: boolean;
  subDist: number;
  depth: number;
  speed: number;
  lightsOn: boolean;
  viewMode: number; // 0 = Standar, 1 = Megalophobia, 2 = POV / Kokpit 3D
  botsAboard: number;
  summoning: boolean;
  mantaFlyby: boolean;
  mantaDist: number;
  fishCount: number;
  fishInventory: number[];
  teamInventory?: number[];
  teamCount?: number;
  fishNames?: string[];
  aimLock?: boolean;
  hull?: number;
  inside?: string;
  interactLabel?: string;
  proc?: { kind: string; idx: number; steps: string[]; progress: number } | null;
  fade?: number;
  repairing?: boolean;
  hatchDist?: number;
  megaActive?: boolean;
  megaDist?: number;
  megaPhase?: string;
  harpoonPhase: 'ready' | 'flying' | 'tethered' | 'reeling' | 'miss';
  harpoonTargetVisible: boolean;
  harpoonTargetX: number;
  harpoonTargetY: number;
  harpoonRecoil: number;
  toastEvent: string;
  toastSeq: number;
}

export interface EngineCallbacks {
  onProgress?: (msg: string, ratio: number) => void;
  onBrowserHint?: (show: boolean) => void;
  onError?: (msg: string) => void;
  onMenuChange?: (inMenu: boolean, pointerLocked: boolean) => void;
  onHud?: (hud: HudState) => void;
  onStats?: (stats: string) => void;
  onMute?: (muted: boolean) => void;
  onViewpoint?: (idx: number, name: string) => void;
}

export interface EngineHandle {
  level: number;
  isMobile: boolean;
  diveIn: () => void;
  openMenu: () => void;
  setDetail: (lv: number) => void;
  toggleSubmarine: () => void;
  toggleMiniMode: (val?: boolean) => void;
  setViewMode: (mode: number) => void;
  toggleCockpit: () => void;
  toggleMegalophobia: () => void;
  toggleLights: () => void;
  toggleMidnight: (force?: boolean) => boolean;
  fireHarpoon: () => boolean;
  reelHarpoon: () => boolean;
  cycleView: () => void;
  callFriends: () => void;
  summonSubmarine: () => void;
  spawnMegalodon: () => boolean;
  getLabels: () => { show: boolean; x: number; y: number; a: number; s?: number; name: string; i: number }[];
  jumpToPose: (idx: number) => void;
  toggleMute: () => boolean;
  destroy: () => void;
}

export function startAbyssalGarden(
  canvas: HTMLCanvasElement,
  barEl: HTMLElement | null,
  callbacks: EngineCallbacks
): Promise<EngineHandle>;
