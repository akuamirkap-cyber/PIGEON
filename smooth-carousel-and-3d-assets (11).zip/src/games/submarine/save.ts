import type { Upgrades } from "./game/engine";
import { SKINS } from "./game/species";

// every fish is unlocked from the start
const ALL_SKINS = () => SKINS.map((s) => s.id);

export interface TrophyUnlockRecord {
  unlockedAt: number;
  bestMetric?: number;
}

export type BgStyle = "game1" | "game2" | "reef_g1" | "shipwreck" | "kelp" | "temple" | "lagoon";
export type ReefMixMode = "game1" | "game2" | "mix";
export type ReefRockMode = "g1" | "g2";
export type SoundPack = "wav" | "classic";
export type OceanLightingMode = "after" | "before";
export type GraphicsMode = "hd_boost" | "super_hd" | "ultra_fps";
export type AppLang = "en" | "id";

export interface SaveData {
  coins: number;
  upgrades: Upgrades;
  owned: string[];
  skin: string;
  name: string;
  best: number;
  speedPref: number;
  bulkPref: number;
  rank1Count: number;
  peakLevelCount: number;
  bestPeakTimeSec: number | null;
  bestCombo: number;
  bestDepth: number;
  totalRuns: number;
  unlockedTrophies: Record<string, TrophyUnlockRecord>;
  equippedTitle: string | null;
  mode3D: boolean;
  reef3D: boolean;
  /** Live 3D water + coral reef mode */
  laut: boolean;
  /** Ocean background & water theme */
  bgStyle: BgStyle;
  /** Coral reef model in 3D Ocean: Game 1, 100% Game 2, or Mix */
  reefMix: ReefMixMode;
  /** Giant boulders style when using Game 2 corals */
  rockStyle: ReefRockMode;
  /** Audio pack: "wav" or "classic" synth */
  soundPack: SoundPack;
  /** Ocean & fish lighting preset: "after" or "before" */
  oceanLighting: OceanLightingMode;
  /** Graphics & super sampling mode */
  graphicsMode: GraphicsMode;
  /** Camera zoom scale: 1.0 (Normal), ~1.34 (Medium), ~1.75 (Close) */
  cameraZoom: number;
  /** UI & game language ("en" default, "id" optional) */
  lang: AppLang;
  /** Migration flag ensuring old saves default to 3D fish */
  mode3DV2?: boolean;
  /** Migration flag applying new Tropical Reef + Mix G1+G2 default once while respecting later manual picks */
  themeMixV1?: boolean;
}

const KEY = "ffio-save-sub-v1";
const VALID_BG_STYLES = new Set<string>(["game1", "game2", "reef_g1", "shipwreck", "kelp", "temple", "lagoon"]);
const VALID_REEF_MIX = new Set<string>(["game1", "game2", "mix"]);
const VALID_ROCK_STYLES = new Set<string>(["g1", "g2"]);
const VALID_SOUND_PACKS = new Set<string>(["wav", "classic"]);
const VALID_LIGHTING = new Set<string>(["after", "before"]);
const VALID_GRAPHICS_MODES = new Set<string>(["hd_boost", "super_hd", "ultra_fps"]);
const VALID_LANGS = new Set<string>(["en", "id"]);

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const d = JSON.parse(raw);
      const owned = ALL_SKINS();
      const rawSkin = d.skin === "boris_3d" ? "boris" : d.skin;
      const migrated3D = d.mode3DV2 === true ? !!d.mode3D : true;
      return {
        coins: d.coins ?? 0,
        upgrades: { suck: 0, speed: 0, size: 0, ...(d.upgrades || {}) },
        owned,
        skin: owned.includes(rawSkin) ? rawSkin : "andy",
        name: d.name ?? "",
        best: d.best ?? 0,
        speedPref: typeof d.speedPref === "number" ? Math.max(0.7, Math.min(1.8, d.speedPref)) : 1.0,
        bulkPref: typeof d.bulkPref === "number" ? Math.max(0.7, Math.min(2.5, d.bulkPref)) : 1.7,
        rank1Count: typeof d.rank1Count === "number" ? d.rank1Count : 0,
        peakLevelCount: typeof d.peakLevelCount === "number" ? d.peakLevelCount : 0,
        bestPeakTimeSec: typeof d.bestPeakTimeSec === "number" ? d.bestPeakTimeSec : null,
        bestCombo: typeof d.bestCombo === "number" ? d.bestCombo : 0,
        bestDepth: typeof d.bestDepth === "number" ? d.bestDepth : 0,
        totalRuns: typeof d.totalRuns === "number" ? d.totalRuns : 0,
        unlockedTrophies: d.unlockedTrophies && typeof d.unlockedTrophies === "object" ? d.unlockedTrophies : {},
        equippedTitle: typeof d.equippedTitle === "string" ? d.equippedTitle : null,
        mode3D: migrated3D,
        mode3DV2: true,
        reef3D: d.reef3D === undefined ? true : !!d.reef3D,
        laut: d.laut === undefined ? true : !!d.laut,
        bgStyle: d.themeMixV1 === true && VALID_BG_STYLES.has(d.bgStyle) ? (d.bgStyle as BgStyle) : "game2",
        reefMix: d.themeMixV1 === true && VALID_REEF_MIX.has(d.reefMix) ? (d.reefMix as ReefMixMode) : "mix",
        themeMixV1: true,
        rockStyle: VALID_ROCK_STYLES.has(d.rockStyle) ? (d.rockStyle as ReefRockMode) : "g1",
        soundPack: VALID_SOUND_PACKS.has(d.soundPack) ? (d.soundPack as SoundPack) : "wav",
        oceanLighting: VALID_LIGHTING.has(d.oceanLighting) ? (d.oceanLighting as OceanLightingMode) : "after",
        graphicsMode: VALID_GRAPHICS_MODES.has(d.graphicsMode) ? (d.graphicsMode as GraphicsMode) : "hd_boost",
        cameraZoom: typeof d.cameraZoom === "number" ? Math.max(1.0, Math.min(1.85, d.cameraZoom)) : 1.0,
        lang: VALID_LANGS.has(d.lang) ? (d.lang as AppLang) : "en",
      };
    }
  } catch {
    /* ignore */
  }
  return {
    coins: 0,
    upgrades: { suck: 0, speed: 0, size: 0 },
    owned: ALL_SKINS(),
    skin: "andy",
    name: "",
    best: 0,
    speedPref: 1.0,
    bulkPref: 1.7,
    rank1Count: 0,
    peakLevelCount: 0,
    bestPeakTimeSec: null,
    bestCombo: 0,
    bestDepth: 0,
    totalRuns: 0,
    unlockedTrophies: {},
    equippedTitle: null,
    mode3D: true,
    mode3DV2: true,
    reef3D: true,
    laut: true,
    bgStyle: "game2",
    reefMix: "mix",
    themeMixV1: true,
    rockStyle: "g1",
    soundPack: "wav",
    oceanLighting: "after",
    graphicsMode: "hd_boost",
    cameraZoom: 1.0,
    lang: "en",
  };
}

export function writeSave(d: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...d, mode3DV2: true, themeMixV1: true }));
  } catch {
    /* ignore */
  }
}

export const UPGRADE_COSTS = [40, 100, 220, 450, 800];
export const MAX_UPGRADE = UPGRADE_COSTS.length;
