import * as THREE from "three";
import type { Species } from "./species";
import {
  baseGroups,
  blendBotToPalate,
  bodySpineOutlineMask,
  buildLoftedSurface,
  buildOutlineGeometry,
  buildSlicedHeadBody,
  buildSmoothLoftedFin,
  clamp,
  computeEyeZ,
  createBiteRing,
  createEyePair,
  createExtrudedFin,
  createOralParts,
  createRigContext,
  createWorldMapper,
  drawBlob,
  drawFinRays,
  drawGlow,
  injectSerpentineSpineShader,
  injectSpineShader,
  interpCurveY,
  evalSerpentineOffset,
  jawOutlineMask,
  makeLin,
  makePaintedFinTex,
  makeSpineFinMesh,
  mixHex,
  mouthSeamOutlineMask,
  rgbaHex,
  sampleBezierChain,
  smoothstep,
  surfaceZAt,
} from "./fish3dShared";
import type { Fish3DRig } from "./fish3dShared";

function drawStar4Canvas(
  c: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  r: number,
  starCol: string,
  haloCol?: string
) {
  c.save();
  c.translate(sx, sy);
  if (haloCol) {
    c.fillStyle = haloCol;
    c.beginPath();
    c.arc(0, 0, r * 1.65, 0, Math.PI * 2);
    c.fill();
  }
  c.fillStyle = starCol;
  c.beginPath();
  c.moveTo(0, -r);
  c.lineTo(r * 0.34, -r * 0.34);
  c.lineTo(r, 0);
  c.lineTo(r * 0.34, r * 0.34);
  c.lineTo(0, r);
  c.lineTo(-r * 0.34, r * 0.34);
  c.lineTo(-r, 0);
  c.lineTo(-r * 0.34, -r * 0.34);
  c.closePath();
  c.fill();
  c.fillStyle = "#ffffff";
  c.beginPath();
  c.arc(0, 0, r * 0.24, 0, Math.PI * 2);
  c.fill();
  c.restore();
}

// =====================================================================================
// 1. MANDARIN (Naga Karang Langka — Sapphire Dragonet, Cyan-Outlined Tangerine Swirls)
// =====================================================================================
function createMandarin3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#041033";
  const SAP = pal.body || "#0e47b8";
  const DK = pal.dark || "#061d66";
  const AQUA = pal.belly || "#279cf5";
  const CRMS = pal.tail || "#ff4757";
  const ORN = pal.stripe || "#ff7b1c";
  const CYAN = pal.spot || "#2cf5e8";

  const ctx = createRigContext(OL, "#4a4a4a");
  const { track, uniforms, makeOutlineMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const xTail = -0.172;
  const xHead = 0.244;
  const hy = -0.028;
  const xSnout = 0.348;
  const tipY = -0.026;

  const topProf = sampleBezierChain(
    [
      [[-0.172, 0.035], [-0.085, 0.095], [0.078, 0.116], [0.202, 0.092]],
      [[0.202, 0.092], [0.278, 0.076], [0.328, 0.024], [xSnout, tipY]],
    ],
    22
  );
  const botProf = sampleBezierChain(
    [
      [[-0.172, -0.035], [-0.082, -0.082], [0.055, -0.112], [0.182, -0.09]],
      [[0.182, -0.09], [0.285, -0.074], [0.324, -0.046], [xSnout, tipY]],
    ],
    22
  );
  const evalTop = (x: number) => interpCurveY(topProf, x);
  const evalBot = (x: number) => interpCurveY(botProf, x);
  const evalZ = (x: number, t: number) => {
    const base = 0.02 + 0.076 * Math.sin(Math.pow(clamp(t, 0, 1), 0.72) * Math.PI);
    const cheek = x > 0.23 ? base * clamp(1 - (x - 0.23) / 0.16, 0.44, 1) : base;
    const noseRound =
      x > 0.275 ? Math.sqrt(clamp(1 - Math.pow((x - 0.275) / (xSnout - 0.275), 2) * 0.995, 0.002, 1)) : 1;
    const hH = Math.max(0.002, (evalTop(x) - evalBot(x)) * 0.5);
    return x > 0.275 ? Math.min(cheek * noseRound, Math.max(0.002, hH * 1.12)) : cheek;
  };

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.188, 0.36, -0.125, 0.125, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);
  bc.fillStyle = makeLin(bc, 0.06, -0.112, 0.06, 0.108, [
    [0, DK],
    [0.34, SAP],
    [0.74, AQUA],
    [1, "#1870db"],
  ]);
  bc.fillRect(-0.3, -0.2, 0.75, 0.45);
  drawGlow(bc, 0.08, -0.062, 0.21, 0.046, 0, "120,245,255", 0.3);

  const drawSwirl = (pathFn: () => void) => {
    bc.beginPath();
    pathFn();
    bc.closePath();
    bc.fillStyle = makeLin(bc, -0.12, -0.08, 0.24, 0.08, [
      [0, "#ffa62b"],
      [0.52, ORN],
      [1, CRMS],
    ]);
    bc.fill();
    bc.strokeStyle = CYAN;
    bc.lineWidth = 0.005;
    bc.stroke();
    bc.strokeStyle = rgbaHex("#030e2b", 0.72);
    bc.lineWidth = 0.0022;
    bc.stroke();
  };
  drawSwirl(() => {
    bc.moveTo(0.112, -0.105);
    bc.bezierCurveTo(0.148, -0.048, 0.155, 0.015, 0.228, 0.044);
    bc.bezierCurveTo(0.258, 0.056, 0.232, 0.088, 0.178, 0.076);
    bc.bezierCurveTo(0.12, 0.062, 0.108, -0.025, 0.068, -0.098);
  });
  drawSwirl(() => {
    bc.moveTo(0.015, -0.104);
    bc.bezierCurveTo(-0.022, -0.045, 0.038, 0.018, -0.018, 0.078);
    bc.bezierCurveTo(-0.048, 0.102, -0.088, 0.082, -0.068, 0.046);
    bc.bezierCurveTo(-0.038, -0.004, -0.072, -0.058, -0.032, -0.098);
  });
  drawSwirl(() => {
    bc.moveTo(-0.105, -0.068);
    bc.bezierCurveTo(-0.135, -0.025, -0.108, 0.022, -0.145, 0.052);
    bc.lineTo(-0.175, 0.034);
    bc.bezierCurveTo(-0.154, 0, -0.165, -0.032, -0.138, -0.058);
  });

  bc.fillStyle = ORN;
  drawBlob(bc, 0.278, -0.015, 0.019, 0.011, 0.35);
  bc.strokeStyle = CYAN;
  bc.lineWidth = 0.0036;
  bc.stroke();

  bc.fillStyle = CYAN;
  drawBlob(bc, 0.188, -0.055, 0.009, 0.0065, -0.2);
  drawBlob(bc, 0.042, 0.052, 0.01, 0.007, 0.2);
  drawBlob(bc, -0.088, -0.024, 0.009, 0.0065, 0);

  bc.strokeStyle = rgbaHex(CYAN, 0.85);
  bc.lineWidth = 0.0038;
  bc.beginPath();
  bc.moveTo(0.245, 0.048);
  bc.quadraticCurveTo(0.272, 0.035, 0.285, 0.056);
  bc.stroke();
  bc.restore();

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const evalSeamY = (x: number) => {
    const u = clamp((x - xHead) / (xSnout - xHead), 0, 1);
    return hy - Math.sin(u * Math.PI) * 0.004 + u * (tipY - hy);
  };
  const evalMidY = (x: number) => (evalTop(x) + evalBot(x)) * 0.5;
  const mandarinSpineMask = bodySpineOutlineMask(
    evalMidY,
    [
      { x0: -0.182, x1: 0.112, top: true },
      { x0: -0.188, x1: 0.015, top: false },
    ],
    0.024
  );
  const mandarinSeamMask = mouthSeamOutlineMask(xHead, xSnout, hy, evalSeamY, false);
  const mandarinMask = (x: number, y: number, z: number) => mandarinSpineMask(x, y, z) * mandarinSeamMask(x, y, z);

  const { bodyGeo, lowerJawGeo: lGeo } = buildSlicedHeadBody({
    xStart: xTail,
    xHinge: xHead,
    xEnd: xSnout,
    xLowerEnd: xSnout - 0.001,
    jawY: hy,
    evalTopY: evalTop,
    evalBotY: evalBot,
    evalSeamY,
    evalHalfZ: evalZ,
    mapUV,
    rearBulge: 0.004,
    uSteps: 54,
    vSteps: 28,
  });
  track(bodyGeo);
  track(lGeo);
  const bodyMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.32 });
  injectSpineShader(bodyMat, uniforms, 0, 0);
  bodyGroup.add(
    new THREE.Mesh(bodyGeo, bodyMat),
    new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0038, mandarinMask)), makeOutlineMat(0, 0))
  );

  // Lower Jaw (upper snout unified into cranium)
  const upperJawGroup = new THREE.Group();
  upperJawGroup.position.set(xHead, hy, 0);
  bodyGroup.add(upperJawGroup);

  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(xHead, hy, 0);
  bodyGroup.add(lowerJawGroup);
  const lMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.32 });
  injectSpineShader(lMat, uniforms, xHead, hy);
  lowerJawGroup.add(
    new THREE.Mesh(lGeo, lMat),
    new THREE.Mesh(
      track(buildOutlineGeometry(lGeo, 0.0032, mouthSeamOutlineMask(xHead, xSnout, hy, evalSeamY, true))),
      makeOutlineMat(xHead, hy)
    )
  );

  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    xHead + 0.02,
    hy,
    "#5c0f24",
    "#ff6a88",
    [0.032, 0.022, 0.02],
    [0.022, 0.009, 0.013],
    0.034
  );

  // 1st Dorsal Plume (tall non-crossing sickle crown)
  const d1Shape = new THREE.Shape();
  d1Shape.moveTo(0.002, 0.095);
  d1Shape.bezierCurveTo(0.004, 0.178, -0.032, 0.252, -0.112, 0.292);
  d1Shape.bezierCurveTo(-0.048, 0.282, 0.065, 0.215, 0.112, 0.09);
  d1Shape.closePath();
  bodyGroup.add(
    makeSpineFinMesh(ctx, d1Shape, 0, 0, 0.0034, 0.0008, (fc) => {
      fc.fillStyle = makeLin(fc, -0.105, 0.292, 0.085, 0.092, [
        [0, CYAN],
        [0.28, "#ffe268"],
        [0.62, ORN],
        [1, "#2b42d6"],
      ]);
      fc.fillRect(-0.15, 0.06, 0.3, 0.26);
      fc.strokeStyle = "rgba(255,250,220,0.68)";
      fc.lineWidth = 0.0034;
      fc.beginPath();
      fc.moveTo(0.088, 0.098);
      fc.bezierCurveTo(0.048, 0.195, -0.025, 0.258, -0.095, 0.282);
      fc.stroke();
      fc.strokeStyle = rgbaHex(CYAN, 0.74);
      fc.lineWidth = 0.003;
      fc.beginPath();
      fc.moveTo(0.048, 0.098);
      fc.bezierCurveTo(0.022, 0.178, -0.018, 0.228, -0.065, 0.252);
      fc.stroke();
    }, maxAnisotropy, true, 0.001, undefined, (x, y) => smoothstep(evalTop(x) - 0.006, evalTop(x) + 0.016, y)).mesh
  );

  // 2nd Dorsal Sail
  const d2Shape = new THREE.Shape();
  d2Shape.moveTo(-0.172, 0.038);
  d2Shape.bezierCurveTo(-0.182, 0.132, -0.125, 0.186, -0.048, 0.168);
  d2Shape.bezierCurveTo(-0.018, 0.16, 0.004, 0.128, 0.01, 0.092);
  d2Shape.closePath();
  bodyGroup.add(
    makeSpineFinMesh(ctx, d2Shape, 0, 0, 0.0034, 0.0008, (fc) => {
      fc.fillStyle = makeLin(fc, -0.08, 0.185, -0.08, 0.045, [
        [0, "#1d8ae8"],
        [0.42, ORN],
        [0.85, "#1154bd"],
        [1, DK],
      ]);
      fc.fillRect(-0.22, 0.02, 0.26, 0.2);
      fc.strokeStyle = "rgba(255,245,210,0.38)";
      fc.lineWidth = 0.0028;
      for (let i = 0; i < 4; i++) {
        const bx = -0.145 + i * 0.038;
        fc.beginPath();
        fc.moveTo(bx, 0.055);
        fc.quadraticCurveTo(bx - 0.012, 0.115, bx - 0.022, 0.162);
        fc.stroke();
      }
      fc.strokeStyle = rgbaHex(CYAN, 0.92);
      fc.lineWidth = 0.0062;
      fc.beginPath();
      fc.moveTo(-0.168, 0.102);
      fc.bezierCurveTo(-0.142, 0.168, -0.072, 0.174, -0.01, 0.142);
      fc.stroke();
      fc.fillStyle = rgbaHex("#ffe270", 0.88);
      drawBlob(fc, -0.115, 0.118, 0.01, 0.007, 0.2);
      drawBlob(fc, -0.068, 0.122, 0.01, 0.007, 0.15);
      drawBlob(fc, -0.032, 0.116, 0.008, 0.006, 0);
    }, maxAnisotropy, true, 0.001, undefined, (x, y) => smoothstep(evalTop(x) - 0.006, evalTop(x) + 0.016, y)).mesh
  );

  // Anal Fin
  const aShape = new THREE.Shape();
  aShape.moveTo(-0.162, -0.042);
  aShape.bezierCurveTo(-0.188, -0.125, -0.118, -0.17, -0.025, -0.145);
  aShape.quadraticCurveTo(0.002, -0.128, 0.015, -0.092);
  aShape.closePath();
  bodyGroup.add(
    makeSpineFinMesh(ctx, aShape, 0, 0, 0.0032, 0.0008, (fc) => {
      fc.fillStyle = makeLin(fc, -0.1, -0.055, -0.1, -0.168, [
        [0, SAP],
        [0.52, ORN],
        [1, CRMS],
      ]);
      fc.fillRect(-0.22, -0.2, 0.26, 0.18);
      fc.strokeStyle = rgbaHex(CYAN, 0.9);
      fc.lineWidth = 0.0058;
      fc.beginPath();
      fc.moveTo(-0.155, -0.115);
      fc.quadraticCurveTo(-0.1, -0.16, -0.028, -0.136);
      fc.stroke();
    }, maxAnisotropy, true, 0.001, undefined, (x, y) => smoothstep(evalBot(x) + 0.006, evalBot(x) - 0.016, y)).mesh
  );

  // Paired Dragonet Pelvic Fan Fins
  const pelvicFin = new THREE.Group();
  pelvicFin.position.set(0.088, -0.086, 0);
  bodyGroup.add(pelvicFin);
  const pvShape = new THREE.Shape();
  pvShape.moveTo(0, 0);
  pvShape.bezierCurveTo(0.02, -0.072, -0.043, -0.106, -0.086, -0.069);
  pvShape.quadraticCurveTo(-0.063, -0.032, -0.036, -0.002);
  pvShape.closePath();
  const pvObj = makeSpineFinMesh(ctx, pvShape, 0.088, -0.086, 0.0028, 0.0007, (fc) => {
    fc.fillStyle = makeLin(fc, -0.01, -0.004, -0.06, -0.095, [
      [0, SAP],
      [0.5, ORN],
      [1, CYAN],
    ]);
    fc.fillRect(-0.12, -0.13, 0.16, 0.15);
  }, maxAnisotropy, true, 0.0009);
  for (const s of [1, -1]) {
    const m = s === 1 ? pvObj.mesh : pvObj.mesh.clone();
    m.position.z = s * 0.028;
    m.rotation.x = s * 0.22;
    pelvicFin.add(m);
  }

  // Ornate Peacock Tail Fan
  const tailPivot = new THREE.Group();
  tailPivot.position.set(-0.158, 0, 0);
  bodyGroup.add(tailPivot);
  const tShape = new THREE.Shape();
  tShape.moveTo(0.012, 0.032);
  tShape.bezierCurveTo(-0.075, 0.105, -0.168, 0.145, -0.225, 0.088);
  tShape.bezierCurveTo(-0.258, 0.042, -0.258, -0.042, -0.225, -0.088);
  tShape.bezierCurveTo(-0.168, -0.145, -0.075, -0.105, 0.012, -0.032);
  tShape.closePath();
  tailPivot.add(
    makeSpineFinMesh(ctx, tShape, -0.158, 0, 0.0034, 0.0008, (fc) => {
      fc.fillStyle = makeLin(fc, 0.01, 0, -0.255, 0, [
        [0, "#1558cf"],
        [0.36, ORN],
        [0.74, CRMS],
        [1, "#b81845"],
      ]);
      fc.fillRect(-0.28, -0.17, 0.32, 0.34);
      fc.strokeStyle = "rgba(255,240,185,0.45)";
      fc.lineWidth = 0.0032;
      for (let i = -3; i <= 3; i++) {
        fc.beginPath();
        fc.moveTo(-0.005, i * 0.006);
        fc.quadraticCurveTo(-0.115, i * 0.018, -0.225, i * 0.026);
        fc.stroke();
      }
      fc.strokeStyle = rgbaHex(CYAN, 0.92);
      fc.lineWidth = 0.007;
      fc.beginPath();
      fc.moveTo(-0.214, -0.084);
      fc.quadraticCurveTo(-0.25, 0, -0.214, 0.084);
      fc.stroke();
      fc.fillStyle = rgbaHex(CYAN, 0.85);
      for (let i = -2; i <= 2; i++) {
        fc.beginPath();
        fc.arc(-0.184 + Math.abs(i) * 0.008, i * 0.029, 0.0062, 0, Math.PI * 2);
        fc.fill();
      }
    }, maxAnisotropy, false, 0.001).mesh
  );

  // Gossamer Rounded Pectoral Wings
  const pShape = new THREE.Shape();
  pShape.moveTo(0, 0);
  pShape.bezierCurveTo(-0.028, 0.038, -0.102, 0.022, -0.092, -0.032);
  pShape.bezierCurveTo(-0.078, -0.076, -0.018, -0.064, 0, -0.016);
  pShape.closePath();
  const pecObj = makeSpineFinMesh(ctx, pShape, 0, 0, 0.0028, 0.0007, (fc) => {
    fc.fillStyle = makeLin(fc, 0, 0, -0.09, -0.028, [
      [0, rgbaHex(AQUA, 0.9)],
      [0.58, rgbaHex(ORN, 0.85)],
      [1, rgbaHex(CYAN, 0.92)],
    ]);
    fc.fillRect(-0.12, -0.09, 0.14, 0.14);
    drawFinRays(fc, [-0.006, -0.004], [[-0.076, -0.018], [-0.076, 0], [-0.076, 0.018], [-0.076, -0.036]], "rgba(255,255,255,0.52)", 0.0026);
  }, maxAnisotropy, false, 0.0009, { transparent: true, opacity: 0.94 });
  const pecZ = surfaceZAt(
    evalTop,
    evalBot,
    (x) => evalZ(x, (x - xTail) / (xSnout - xTail)),
    0.105,
    -0.032,
    0.22,
    1.0
  ) + 0.006;
  const pecLeft = new THREE.Group();
  pecLeft.position.set(0.105, -0.032, pecZ);
  pecLeft.add(pecObj.mesh);
  const pecRight = new THREE.Group();
  pecRight.position.set(0.105, -0.032, -pecZ);
  pecRight.add(pecObj.mesh.clone());
  bodyGroup.add(pecLeft, pecRight);

  // Gold-ringed emerald jewel eye
  const eyeZ = surfaceZAt(evalTop, evalBot, (x) => evalZ(x, (x - xTail) / (xSnout - xTail)), 0.228, 0.034);
  const goldRingGeo = track(new THREE.CylinderGeometry(0.041 * 1.18, 0.041 * 1.18, 0.008, 22));
  goldRingGeo.rotateX(Math.PI * 0.5);
  const goldRingMat = track(
    new THREE.MeshPhysicalMaterial({
      color: "#ffae2b",
      emissive: "#ffae2b",
      emissiveIntensity: 0.25,
      roughness: 0.28,
    })
  );
  for (const s of [1, -1]) {
    const gr = new THREE.Mesh(goldRingGeo, goldRingMat);
    gr.position.set(0.228, 0.034, s * (eyeZ - 0.002));
    gr.rotation.y = s * 0.2;
    bodyGroup.add(gr);
  }
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: 0.228,
    ey: 0.034,
    ez: eyeZ + 0.002,
    er: 0.041,
    irisColor: pal.iris || "#18c98f",
    rimColor: OL,
    happyColor: "#ffe999",
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout + 0.02, -0.015, CYAN, 0.05);

  return {
    speciesKey: sp.id,
    tailPivotX: -0.158,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 2. AURORA (Cupang Surgawi Langka — Rose-Opal Betta + Colossal 180° Halfmoon Veils!)
// =====================================================================================
function createAurora3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#2a0b4a";
  const ROSE = pal.body || "#ff85c0";
  const AMET = pal.dark || "#6928a8";
  const OPAL = pal.belly || "#ffe8f7";
  const ORCH = pal.fin || "#9c5cf5";
  const AUR = pal.tail || "#4df5e8";
  const STAR = pal.spot || "#7df9ff";

  const ctx = createRigContext(OL, "#464646");
  const { track, uniforms, makeOutlineMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const xTail = -0.085;
  const xHead = 0.252;
  const hy = -0.024;
  const xSnout = 0.355;
  const tipY = -0.018;

  const topProf = sampleBezierChain(
    [
      [[-0.085, 0.044], [0.01, 0.098], [0.155, 0.105], [0.255, 0.068]],
      [[0.255, 0.068], [0.305, 0.048], [0.338, 0.016], [xSnout, tipY]],
    ],
    22
  );
  const botProf = sampleBezierChain(
    [
      [[-0.085, -0.045], [-0.02, -0.075], [0.07, -0.095], [0.185, -0.084]],
      [[0.185, -0.084], [0.295, -0.070], [0.328, -0.042], [xSnout, tipY]],
    ],
    22
  );
  const evalTop = (x: number) => interpCurveY(topProf, x);
  const evalBot = (x: number) => interpCurveY(botProf, x);
  const evalZ = (x: number, t: number) => {
    const base = 0.018 + 0.064 * Math.sin(Math.pow(clamp(t, 0, 1), 0.76) * Math.PI);
    const cheek = x > 0.23 ? base * clamp(1 - (x - 0.23) / 0.16, 0.44, 1) : base;
    const noseRound =
      x > 0.285 ? Math.sqrt(clamp(1 - Math.pow((x - 0.285) / (xSnout - 0.285), 2) * 0.995, 0.002, 1)) : 1;
    const hH = Math.max(0.002, (evalTop(x) - evalBot(x)) * 0.5);
    return x > 0.285 ? Math.min(cheek * noseRound, Math.max(0.002, hH * 1.12)) : cheek;
  };

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.1, 0.37, -0.115, 0.115, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);
  bc.fillStyle = makeLin(bc, 0.08, -0.105, 0.08, 0.095, [
    [0, AMET],
    [0.34, ORCH],
    [0.64, ROSE],
    [1, OPAL],
  ]);
  bc.fillRect(-0.2, -0.2, 0.7, 0.4);
  drawGlow(bc, 0.08, -0.04, 0.19, 0.055, -0.08, "125,249,255", 0.34);
  drawGlow(bc, 0.17, 0.02, 0.12, 0.05, 0, "255,190,235", 0.45);

  bc.strokeStyle = rgbaHex(STAR, 0.45);
  bc.lineWidth = 0.003;
  for (let r = 0; r < 3; r++) {
    for (let col = 0; col < 5; col++) {
      const sx = -0.03 + col * 0.042 + (r % 2) * 0.02;
      const sy = -0.035 + r * 0.035;
      bc.beginPath();
      bc.arc(sx, sy, 0.022, -Math.PI * 0.35, Math.PI * 0.35);
      bc.stroke();
    }
  }
  bc.fillStyle = "rgba(255,110,175,0.44)";
  drawBlob(bc, 0.21, 0.032, 0.024, 0.015, 0.1);
  bc.strokeStyle = rgbaHex(AMET, 0.55);
  bc.lineWidth = 0.004;
  bc.beginPath();
  bc.arc(0.145, 0.005, 0.045, -Math.PI * 0.32, Math.PI * 0.38);
  bc.stroke();
  bc.restore();

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const evalSeamY = (x: number) => {
    const u = clamp((x - xHead) / (xSnout - xHead), 0, 1);
    return hy - Math.sin(u * Math.PI) * 0.004 + u * (tipY - hy);
  };
  const evalMidY = (x: number) => (evalTop(x) + evalBot(x)) * 0.5;
  const auroraSpineMask = bodySpineOutlineMask(
    evalMidY,
    [
      { x0: -0.085, x1: 0.115, top: true },
      { x0: -0.085, x1: 0.125, top: false },
    ],
    0.024
  );
  const auroraSeamMask = mouthSeamOutlineMask(xHead, xSnout, hy, evalSeamY, false);
  const auroraMask = (x: number, y: number, z: number) => auroraSpineMask(x, y, z) * auroraSeamMask(x, y, z);

  const { bodyGeo, lowerJawGeo: lGeo } = buildSlicedHeadBody({
    xStart: xTail,
    xHinge: xHead,
    xEnd: xSnout,
    xLowerEnd: xSnout - 0.001,
    jawY: hy,
    evalTopY: evalTop,
    evalBotY: evalBot,
    evalSeamY,
    evalHalfZ: evalZ,
    mapUV,
    rearBulge: 0.004,
    uSteps: 52,
    vSteps: 26,
  });
  track(bodyGeo);
  track(lGeo);
  const bodyMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.32, clearcoat: 0.58 });
  injectSpineShader(bodyMat, uniforms, 0, 0);
  bodyGroup.add(
    new THREE.Mesh(bodyGeo, bodyMat),
    new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0036, auroraMask)), makeOutlineMat(0, 0))
  );

  // Lower Jaw (upper snout unified cleanly into cranium)
  const upperJawGroup = new THREE.Group();
  upperJawGroup.position.set(xHead, hy, 0);
  bodyGroup.add(upperJawGroup);

  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(xHead, hy, 0);
  bodyGroup.add(lowerJawGroup);
  const lMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.32, clearcoat: 0.58 });
  injectSpineShader(lMat, uniforms, xHead, hy);
  lowerJawGroup.add(
    new THREE.Mesh(lGeo, lMat),
    new THREE.Mesh(
      track(buildOutlineGeometry(lGeo, 0.003, mouthSeamOutlineMask(xHead, xSnout, hy, evalSeamY, true))),
      makeOutlineMat(xHead, hy)
    )
  );

  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    xHead + 0.018,
    hy,
    "#591032",
    "#ff78a5",
    [0.03, 0.02, 0.018],
    [0.022, 0.008, 0.012],
    0.032
  );

  // Colossal 180° Halfmoon Silk Veil Tail
  const tailPivot = new THREE.Group();
  tailPivot.position.set(-0.04, 0, 0);
  bodyGroup.add(tailPivot);
  const tShape = new THREE.Shape();
  tShape.moveTo(0.02, 0.048);
  tShape.bezierCurveTo(-0.08, 0.18, -0.22, 0.35, -0.375, 0.305);
  tShape.bezierCurveTo(-0.435, 0.18, -0.455, 0.06, -0.438, 0);
  tShape.bezierCurveTo(-0.455, -0.07, -0.43, -0.2, -0.368, -0.312);
  tShape.bezierCurveTo(-0.21, -0.348, -0.075, -0.178, 0.02, -0.05);
  tShape.closePath();
  tailPivot.add(
    makeSpineFinMesh(
      ctx,
      tShape,
      -0.04,
      0,
      0.0026,
      0.0006,
      (fc) => {
        fc.fillStyle = makeLin(fc, 0.02, 0, -0.44, 0, [
          [0, AMET],
          [0.32, ORCH],
          [0.65, ROSE],
          [0.88, "#ffbde8"],
          [1, AUR],
        ]);
        fc.fillRect(-0.48, -0.38, 0.54, 0.76);
        fc.strokeStyle = rgbaHex(AUR, 0.88);
        fc.lineWidth = 0.015;
        fc.beginPath();
        fc.moveTo(-0.358, 0.29);
        fc.bezierCurveTo(-0.432, 0.12, -0.432, -0.12, -0.352, -0.295);
        fc.stroke();
        fc.strokeStyle = "rgba(255,250,255,0.48)";
        fc.lineWidth = 0.0032;
        for (let i = -5; i <= 5; i++) {
          const ang = i * 0.16;
          const ex = -Math.cos(ang) * 0.39;
          const ey = Math.sin(ang) * 0.305;
          fc.beginPath();
          fc.moveTo(0, i * 0.006);
          fc.quadraticCurveTo(ex * 0.52, ey * 0.52, ex, ey);
          fc.stroke();
        }
        fc.fillStyle = "rgba(255,255,255,0.82)";
        drawBlob(fc, -0.28, 0.14, 0.01, 0.007, -0.3);
        drawBlob(fc, -0.33, -0.05, 0.011, 0.007, 0.2);
        drawBlob(fc, -0.26, -0.17, 0.009, 0.006, -0.1);
      },
      maxAnisotropy,
      false,
      0.0009,
      { transparent: true, opacity: 0.9, emissiveIntensity: 0.36 }
    ).mesh
  );

  // Sweeping Crown Dorsal Silk Veil
  const dShape = new THREE.Shape();
  dShape.moveTo(0.115, 0.075);
  dShape.bezierCurveTo(0.06, 0.19, -0.04, 0.345, -0.185, 0.345);
  dShape.bezierCurveTo(-0.155, 0.245, -0.125, 0.145, -0.065, 0.052);
  dShape.closePath();
  bodyGroup.add(
    makeSpineFinMesh(ctx, dShape, 0, 0, 0.0026, 0.0006, (fc) => {
      fc.fillStyle = makeLin(fc, 0.05, 0.07, -0.17, 0.34, [
        [0, ORCH],
        [0.52, ROSE],
        [1, AUR],
      ]);
      fc.fillRect(-0.22, 0.02, 0.38, 0.36);
      fc.strokeStyle = "rgba(255,255,255,0.5)";
      fc.lineWidth = 0.003;
      for (let i = 0; i < 5; i++) {
        fc.beginPath();
        fc.moveTo(0.08 - i * 0.032, 0.07);
        fc.quadraticCurveTo(0.01 - i * 0.042, 0.2, -0.095 - i * 0.02, 0.295 + i * 0.008);
        fc.stroke();
      }
    }, maxAnisotropy, true, 0.0009, { transparent: true, opacity: 0.9, emissiveIntensity: 0.34 }, (x, y) =>
      smoothstep(evalTop(x) - 0.006, evalTop(x) + 0.016, y)
    ).mesh
  );

  // Long Flowing Ventral / Anal Ribbon Veil
  const aShape = new THREE.Shape();
  aShape.moveTo(0.125, -0.072);
  aShape.bezierCurveTo(0.05, -0.205, -0.055, -0.355, -0.215, -0.345);
  aShape.bezierCurveTo(-0.155, -0.245, -0.12, -0.145, -0.058, -0.048);
  aShape.closePath();
  bodyGroup.add(
    makeSpineFinMesh(ctx, aShape, 0, 0, 0.0026, 0.0006, (fc) => {
      fc.fillStyle = makeLin(fc, 0.06, -0.06, -0.19, -0.34, [
        [0, ORCH],
        [0.55, ROSE],
        [1, AUR],
      ]);
      fc.fillRect(-0.24, -0.38, 0.4, 0.36);
      fc.strokeStyle = "rgba(255,255,255,0.48)";
      fc.lineWidth = 0.003;
      for (let i = 0; i < 5; i++) {
        fc.beginPath();
        fc.moveTo(0.09 - i * 0.034, -0.065);
        fc.quadraticCurveTo(0.01 - i * 0.042, -0.2, -0.1 - i * 0.025, -0.29 - i * 0.01);
        fc.stroke();
      }
    }, maxAnisotropy, true, 0.0009, { transparent: true, opacity: 0.9, emissiveIntensity: 0.34 }, (x, y) =>
      smoothstep(evalBot(x) + 0.006, evalBot(x) - 0.016, y)
    ).mesh
  );

  // Paired Delicate Silk Pelvic Ribbon Streamers
  const pelvicFin = new THREE.Group();
  pelvicFin.position.set(0.155, -0.075, 0);
  bodyGroup.add(pelvicFin);
  const pvShape = new THREE.Shape();
  pvShape.moveTo(0, 0);
  pvShape.bezierCurveTo(-0.025, -0.11, -0.1, -0.21, -0.17, -0.23);
  pvShape.bezierCurveTo(-0.125, -0.15, -0.08, -0.07, -0.04, -0.007);
  pvShape.closePath();
  const pvObj = makeSpineFinMesh(ctx, pvShape, 0.155, -0.075, 0.0022, 0.0006, (fc) => {
    fc.fillStyle = makeLin(fc, -0.01, -0.005, -0.15, -0.22, [
      [0, OPAL],
      [0.6, "#ff99d6"],
      [1, AUR],
    ]);
    fc.fillRect(-0.2, -0.26, 0.24, 0.28);
  }, maxAnisotropy, true, 0.0008, { transparent: true, opacity: 0.92 });
  for (const s of [1, -1]) {
    const m = s === 1 ? pvObj.mesh : pvObj.mesh.clone();
    m.position.z = s * 0.018;
    m.rotation.x = s * 0.14;
    pelvicFin.add(m);
  }

  // Gossamer Opal Pectorals
  const pShape = new THREE.Shape();
  pShape.moveTo(0, 0);
  pShape.bezierCurveTo(-0.04, 0.048, -0.145, 0.018, -0.135, -0.042);
  pShape.bezierCurveTo(-0.11, -0.088, -0.03, -0.068, 0, -0.015);
  pShape.closePath();
  const pecObj = makeSpineFinMesh(ctx, pShape, 0, 0, 0.0024, 0.0006, (fc) => {
    fc.fillStyle = makeLin(fc, 0, 0, -0.13, -0.04, [
      [0, "rgba(255,240,252,0.88)"],
      [0.65, "rgba(185,135,255,0.8)"],
      [1, "rgba(77,245,232,0.9)"],
    ]);
    fc.fillRect(-0.16, -0.1, 0.18, 0.16);
  }, maxAnisotropy, false, 0.0008, { transparent: true, opacity: 0.88 });
  const pecZ = surfaceZAt(
    evalTop,
    evalBot,
    (x) => evalZ(x, (x - xTail) / (xSnout - xTail)),
    0.13,
    -0.024,
    0.22,
    1.0
  ) + 0.006;
  const pecLeft = new THREE.Group();
  pecLeft.position.set(0.13, -0.024, pecZ);
  pecLeft.add(pecObj.mesh);
  const pecRight = new THREE.Group();
  pecRight.position.set(0.13, -0.024, -pecZ);
  pecRight.add(pecObj.mesh.clone());
  bodyGroup.add(pecLeft, pecRight);

  const eyeZ = surfaceZAt(evalTop, evalBot, (x) => evalZ(x, (x - xTail) / (xSnout - xTail)), 0.242, 0.024);
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: 0.242,
    ey: 0.024,
    ez: eyeZ,
    er: 0.043,
    irisColor: pal.iris || "#2d68e6",
    rimColor: OL,
    happyColor: "#ffffff",
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout + 0.02, -0.008, AUR, 0.048);

  return {
    speciesKey: sp.id,
    tailPivotX: -0.04,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 3. NARWHAL (Lumina — Moonlit Lavender Whale, Ice-Cyan Spots & Spiraled Ivory Tusk!)
// =====================================================================================
function createNarwhal3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#1a1047";
  const LAV = pal.body || "#8e78ff";
  const IND = pal.dark || "#4432a8";
  const PRL = pal.belly || "#f7f4ff";
  const FIN = pal.fin || "#6b54e8";
  const TAIL = pal.tail || "#5746cc";
  const GOLD = pal.stripe || "#ffe58f";
  const STAR = pal.spot || "#b5f4ff";

  const ctx = createRigContext(OL, "#4a4a4a");
  const { track, uniforms, makeOutlineMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const xTail = -0.245;
  const xHead = 0.185;
  const hy = -0.058;
  const xSnout = 0.292;

  const topProf = sampleBezierChain(
    [
      [[-0.245, 0.028], [-0.145, 0.108], [0.02, 0.142], [0.175, 0.118]],
      [[0.175, 0.118], [0.238, 0.105], [0.278, 0.072], [xSnout, 0.008]],
    ],
    22
  );
  const botProf = sampleBezierChain(
    [
      [[-0.245, -0.032], [-0.135, -0.09], [0.015, -0.12], [0.135, -0.106]],
      [[0.135, -0.106], [0.225, -0.1], [0.258, -0.076], [0.276, -0.068]],
    ],
    22
  );
  const evalZ = (x: number, t: number) => {
    const base = 0.022 + 0.104 * Math.sin(Math.pow(clamp(t, 0, 1), 0.72) * Math.PI);
    return x > 0.19 ? base * clamp(1 - (x - 0.19) / 0.12, 0.36, 1) : base;
  };

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.26, 0.305, -0.145, 0.155, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);
  bc.fillStyle = makeLin(bc, 0, -0.14, 0, 0.12, [
    [0, IND],
    [0.42, LAV],
    [0.72, "#c6bdff"],
    [1, PRL],
  ]);
  bc.fillRect(-0.35, -0.25, 0.8, 0.5);

  // Pearl underbelly wave
  bc.fillStyle = makeLin(bc, 0, 0.02, 0, 0.12, [
    [0, PRL],
    [0.72, "#eee8ff"],
    [1, "#d2c8f7"],
  ]);
  bc.beginPath();
  bc.moveTo(-0.25, 0.018);
  bc.bezierCurveTo(-0.11, 0.035, 0.06, 0.048, 0.285, 0.045);
  bc.lineTo(0.295, 0.16);
  bc.lineTo(-0.26, 0.15);
  bc.closePath();
  bc.fill();

  drawGlow(bc, 0.08, -0.09, 0.18, 0.04, -0.05, "215,245,255", 0.34);

  const dots: [number, number, number, number, number, number][] = [
    [-0.08, -0.065, 0.022, 0.011, -0.15, 0.58],
    [-0.01, -0.085, 0.026, 0.012, 0.08, 0.58],
    [0.065, -0.078, 0.02, 0.01, -0.1, 0.62],
    [0.125, -0.058, 0.018, 0.009, 0.15, 0.58],
    [-0.145, -0.04, 0.019, 0.01, -0.12, 0.48],
    [-0.045, -0.035, 0.015, 0.008, 0.05, 0.52],
    [0.035, -0.042, 0.016, 0.008, -0.2, 0.48],
  ];
  for (const [dx, dy, rx, ry, rot, a] of dots) {
    bc.fillStyle = rgbaHex(STAR, a);
    drawBlob(bc, dx, dy, rx, ry, rot);
  }
  bc.fillStyle = "rgba(255,130,185,0.52)";
  drawBlob(bc, 0.17, 0.045, 0.025, 0.015, 0.08);
  bc.restore();

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const evalTop = (x: number) => interpCurveY(topProf, x);
  const evalBot = (x: number) => interpCurveY(botProf, x);
  const evalUpperPalate = () => -0.052;
  const evalUnifiedBot = blendBotToPalate(evalBot, evalUpperPalate, xHead, 0.052, 0.016);

  const bodyGeo = track(
    buildLoftedSurface({
      xStart: xTail,
      xEnd: xSnout,
      uSteps: 42,
      vSteps: 26,
      evalTopY: evalTop,
      evalBotY: evalUnifiedBot,
      evalHalfZ: evalZ,
      mapUV,
      rearBulge: 0.004,
      roundFront: true,
    })
  );
  const bodyMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.3 });
  injectSpineShader(bodyMat, uniforms, 0, 0);
  bodyGroup.add(
    new THREE.Mesh(bodyGeo, bodyMat),
    new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0038)), makeOutlineMat(0, 0))
  );

  // Empty upperJawGroup compat anchor; Spiraled Golden-Ivory Tusk attached to cranium
  const upperJawGroup = new THREE.Group();
  upperJawGroup.position.set(xHead, hy + 0.016, 0);
  bodyGroup.add(upperJawGroup);

  const hornCv = document.createElement("canvas");
  hornCv.width = 256;
  hornCv.height = 256;
  const hc = hornCv.getContext("2d")!;
  hc.fillStyle = makeLin(hc, 0, 0, 0, 256, [
    [0, "#fffdf2"],
    [0.45, GOLD],
    [1, "#d99b26"],
  ]);
  hc.fillRect(0, 0, 256, 256);
  hc.strokeStyle = "rgba(175,110,15,0.68)";
  hc.lineWidth = 10;
  for (let i = -2; i < 8; i++) {
    hc.beginPath();
    hc.moveTo(0, i * 42);
    hc.lineTo(256, i * 42 + 64);
    hc.stroke();
  }
  hc.strokeStyle = "rgba(255,255,255,0.82)";
  hc.lineWidth = 4;
  for (let i = -2; i < 8; i++) {
    hc.beginPath();
    hc.moveTo(0, i * 42 - 10);
    hc.lineTo(256, i * 42 + 54);
    hc.stroke();
  }
  const hornTex = track(new THREE.CanvasTexture(hornCv));
  hornTex.colorSpace = THREE.SRGBColorSpace;
  hornTex.anisotropy = maxAnisotropy;
  const tuskLen = 0.235;
  const hornGeo = track(new THREE.ConeGeometry(0.018, tuskLen, 16));
  hornGeo.rotateZ(-Math.PI * 0.5);
  hornGeo.translate(tuskLen * 0.5, 0, 0);
  const hornMat = ctx.makeFishMat(hornTex, { clearcoat: 0.72, emissiveIntensity: 0.3 });
  const hornMesh = new THREE.Mesh(hornGeo, hornMat);
  hornMesh.position.set(0.248, 0.026, 0);
  hornMesh.rotation.z = 0.15;
  hornMesh.add(new THREE.Mesh(track(buildOutlineGeometry(hornGeo, 0.002)), makeOutlineMat(0, 0, false)));
  bodyGroup.add(hornMesh);

  // Lower Jaw
  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(xHead, hy - 0.008, 0);
  bodyGroup.add(lowerJawGroup);
  const lGeo = track(
    buildLoftedSurface({
      xStart: xHead - 0.018,
      xEnd: xSnout - 0.016,
      uSteps: 16,
      vSteps: 18,
      evalTopY: () => -0.052,
      evalBotY: evalBot,
      evalHalfZ: (x) => evalZ(x, (x - xTail) / (xSnout - xTail)) * 0.9,
      mapUV,
      localOffsetX: xHead,
      localOffsetY: hy - 0.008,
      roundFront: true,
      rearInsetAt: (x) => (x < xHead ? smoothstep(xHead - 0.018, xHead + 0.008, x) * 0.92 + 0.08 : 1),
    })
  );
  const lMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.3 });
  injectSpineShader(lMat, uniforms, xHead, hy - 0.008);
  lowerJawGroup.add(
    new THREE.Mesh(lGeo, lMat),
    new THREE.Mesh(track(buildOutlineGeometry(lGeo, 0.0032, jawOutlineMask(0.006, 0.038))), makeOutlineMat(xHead, hy - 0.008))
  );

  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    xHead + 0.016,
    hy,
    "#5c1438",
    "#ff7aa8",
    [0.032, 0.024, 0.022],
    [0.022, 0.009, 0.013],
    0.03
  );

  // Horizontal Crescent Whale Fluke
  const tailPivot = new THREE.Group();
  tailPivot.position.set(-0.24, -0.005, 0);
  bodyGroup.add(tailPivot);
  const fShape = new THREE.Shape();
  fShape.moveTo(0.02, 0.028);
  fShape.bezierCurveTo(-0.07, 0.06, -0.155, 0.165, -0.215, 0.18);
  fShape.bezierCurveTo(-0.18, 0.095, -0.145, 0.032, -0.105, 0);
  fShape.bezierCurveTo(-0.145, -0.032, -0.18, -0.095, -0.215, -0.18);
  fShape.bezierCurveTo(-0.155, -0.165, -0.07, -0.06, 0.02, -0.028);
  fShape.closePath();
  const flukeObj = makeSpineFinMesh(ctx, fShape, -0.24, -0.005, 0.004, 0.001, (fc) => {
    fc.fillStyle = makeLin(fc, 0, 0.16, -0.18, -0.16, [
      [0, IND],
      [0.5, LAV],
      [1, TAIL],
    ]);
    fc.fillRect(-0.24, -0.2, 0.28, 0.4);
    fc.strokeStyle = rgbaHex(STAR, 0.65);
    fc.lineWidth = 0.0042;
    fc.beginPath();
    fc.moveTo(-0.02, 0.022);
    fc.quadraticCurveTo(-0.12, 0.08, -0.195, 0.16);
    fc.moveTo(-0.02, -0.022);
    fc.quadraticCurveTo(-0.12, -0.08, -0.195, -0.16);
    fc.stroke();
  }, maxAnisotropy, false, 0.0011);
  flukeObj.mesh.rotation.x = Math.PI * 0.5;
  tailPivot.add(flukeObj.mesh);

  // Rounded Flippers
  const pShape = new THREE.Shape();
  pShape.moveTo(0.01, 0.008);
  pShape.bezierCurveTo(-0.025, -0.055, -0.088, -0.082, -0.112, -0.055);
  pShape.bezierCurveTo(-0.125, -0.03, -0.072, 0.012, -0.008, 0.014);
  pShape.closePath();
  const pecObj = makeSpineFinMesh(ctx, pShape, 0, 0, 0.0034, 0.0008, (fc) => {
    fc.fillStyle = makeLin(fc, 0, 0.01, -0.11, -0.07, [
      [0, LAV],
      [0.65, IND],
      [1, FIN],
    ]);
    fc.fillRect(-0.15, -0.11, 0.18, 0.15);
    fc.strokeStyle = rgbaHex(STAR, 0.58);
    fc.lineWidth = 0.0034;
    fc.beginPath();
    fc.moveTo(-0.015, -0.045);
    fc.quadraticCurveTo(-0.065, -0.068, -0.102, -0.052);
    fc.stroke();
  }, maxAnisotropy, false, 0.001);
  const pecZ = surfaceZAt(
    evalTop,
    evalUnifiedBot,
    (x) => evalZ(x, (x - xTail) / (xSnout - xTail)),
    0.055,
    -0.052,
    0.22,
    1.0
  ) + 0.006;
  const pecLeft = new THREE.Group();
  pecLeft.position.set(0.055, -0.052, pecZ);
  pecLeft.rotation.x = -0.24;
  pecLeft.add(pecObj.mesh);
  const pecRight = new THREE.Group();
  pecRight.position.set(0.055, -0.052, -pecZ);
  pecRight.rotation.x = 0.24;
  pecRight.add(pecObj.mesh.clone());
  bodyGroup.add(pecLeft, pecRight);

  const pelvicFin = new THREE.Group();
  bodyGroup.add(pelvicFin);

  const eyeZ = surfaceZAt(evalTop, evalUnifiedBot, (x) => evalZ(x, (x - xTail) / (xSnout - xTail)), 0.202, -0.002);
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: 0.202,
    ey: -0.002,
    ez: eyeZ,
    er: 0.041,
    irisColor: pal.iris || "#1f3a8a",
    rimColor: OL,
    happyColor: "#ffffff",
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout + 0.14, 0.025, STAR, 0.052);

  return {
    speciesKey: sp.id,
    tailPivotX: -0.24,
    isFluke: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p, open, swimAmp) => {
      const tightClamp = p.jaw < 0 ? clamp(-p.jaw, 0, 0.48) : 0;
      lowerJawGroup.rotation.z = -open * 0.94 + tightClamp * 0.16;
      mouthInterior.visible = open > 0.03;
      if (open > 0.03) {
        mouthInterior.rotation.z = -open * 0.26;
        mouthInterior.scale.set(0.84 + open * 0.18, 0.28 + open * 0.98, 0.54 + open * 0.12);
      }
      tongueMesh.visible = open > 0.04;
      tailPivot.rotation.y = 0;
      tailPivot.rotation.z = Math.sin(p.tailPh - 2.3) * (0.34 + p.swimSpeed * 0.22);
      tailPivot.position.y = Math.sin(p.tailPh - 1.6) * 0.018;
      pecLeft.rotation.z = -0.14 + Math.sin(p.wag2 * 2) * (0.14 + swimAmp * 0.6);
      pecRight.rotation.z = -0.14 - Math.sin(p.wag2 * 2) * (0.14 + swimAmp * 0.6);
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 4. SEADRAGON (Naga Daun — S-Curved Armored Emerald & Gold + Multi-Branch Kelp Plumes)
// =====================================================================================
function createSeadragon3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#07261c";
  const EMR = pal.body || "#22b87a";
  const DK = pal.dark || "#0c4a38";
  const GOLD = pal.body || "#eab62a";
  const AMBER = pal.dark || "#b87a10";
  const CREAM = pal.belly || "#ffe88a";
  const LIME = pal.fin || "#92bf24";
  const CHART = pal.spot || "#b6e034";
  const DEEP_LEAF = "#5e8f16";

  const ctx = createRigContext(OL, "#3d2c05");
  const { track, uniforms, makeOutlineMat, makeFishMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  // 1. S-Curved Armored Golden Seadragon Torso & Curled Tail (Custom Catmull-Rom Spine Mesh)
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 256;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  bc.fillStyle = makeLin(bc, 0, 0, 256, 512, [
    [0, CREAM],
    [0.18, GOLD],
    [0.52, "#f0b926"],
    [0.84, AMBER],
    [1, "#9a630c"],
  ]);
  bc.fillRect(0, 0, 256, 512);

  // Subtle sunlit lime-olive dorsal gradient on back side (u ~ 1) and warm honey belly (u ~ 0)
  const flankGrad = bc.createLinearGradient(0, 0, 256, 0);
  flankGrad.addColorStop(0, "rgba(255, 240, 158, 0.72)");
  flankGrad.addColorStop(0.45, "rgba(240, 185, 38, 0.12)");
  flankGrad.addColorStop(0.85, "rgba(138, 178, 34, 0.45)");
  flankGrad.addColorStop(1, "rgba(104, 146, 22, 0.65)");
  bc.fillStyle = flankGrad;
  bc.fillRect(0, 0, 256, 512);

  // Delicate cream bony segment ribs & subtle speck dots like natural leafy seadragon armor
  bc.strokeStyle = "rgba(255, 246, 198, 0.62)";
  bc.lineWidth = 3.2;
  for (let y = 24; y < 495; y += 22) {
    bc.beginPath();
    bc.moveTo(0, y);
    bc.quadraticCurveTo(128, y + 6, 256, y);
    bc.stroke();
  }
  bc.fillStyle = "rgba(255, 250, 222, 0.52)";
  for (let i = 0; i < 22; i++) {
    const px = 28 + ((i * 37) % 120);
    const py = 120 + ((i * 53) % 210);
    bc.beginPath();
    bc.arc(px, py, 2.2 + (i % 2), 0, Math.PI * 2);
    bc.fill();
  }

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  // Control knots along graceful S-curve facing +X: [x, y, rx, rz]
  const knots: [number, number, number, number][] = [
    [0.242, 0.145, 0.028, 0.022], // Forehead / snout root
    [0.205, 0.164, 0.044, 0.036], // Domed golden skull
    [0.162, 0.156, 0.042, 0.034], // Occiput
    [0.142, 0.114, 0.027, 0.022], // Slender upper neck
    [0.118, 0.062, 0.029, 0.024], // S-neck dip
    [0.088, 0.015, 0.041, 0.033], // Upper chest swell
    [0.038, -0.012, 0.060, 0.045], // Full rounded golden chest/belly
    [-0.026, -0.004, 0.058, 0.044], // Mid torso
    [-0.092, 0.014, 0.045, 0.036], // Dorsal arch
    [-0.155, -0.006, 0.033, 0.027], // Waist taper
    [-0.208, -0.054, 0.024, 0.020], // Tail curve start
    [-0.242, -0.128, 0.018, 0.015], // Sweeping downward tail
    [-0.242, -0.205, 0.014, 0.012], // Curving tail lower arc
    [-0.202, -0.258, 0.010, 0.009], // Curling forward
    [-0.148, -0.276, 0.006, 0.005], // Graceful tapered tail tip
  ];

  const splinePts = knots.map((k) => new THREE.Vector3(k[0], k[1], 0));
  const spineCurve = new THREE.CatmullRomCurve3(splinePts);
  const segCount = 46;
  const radialSegs = 20;
  const positions: number[] = [];
  const uvs: number[] = [];
  const spineT: number[] = [];
  const spinePerp: number[] = [];
  const indices: number[] = [];

  const interpRadius = (t: number): [number, number] => {
    const f = clamp(t, 0, 1) * (knots.length - 1);
    const i0 = Math.min(knots.length - 2, Math.floor(f));
    const lt = f - i0;
    const rx = knots[i0][2] + (knots[i0 + 1][2] - knots[i0][2]) * lt;
    const rz = knots[i0][3] + (knots[i0 + 1][3] - knots[i0][3]) * lt;
    return [rx, rz];
  };

  for (let i = 0; i <= segCount; i++) {
    const t = i / segCount;
    const pt = spineCurve.getPoint(t);
    const tang = spineCurve.getTangent(t);
    const nx = tang.y;
    const ny = -tang.x;
    const [rx, rz] = interpRadius(t);
    const ridge = 1 + 0.05 * Math.sin(t * Math.PI * 28);
    for (let j = 0; j <= radialSegs; j++) {
      const a = (j / radialSegs) * Math.PI * 2;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      const px = pt.x + nx * ca * rx * ridge;
      const py = pt.y + ny * ca * rx * ridge;
      const pz = sa * rz * ridge;
      positions.push(px, py, pz);
      uvs.push(Math.abs(ca * 0.5 + 0.5), t);
      spineT.push(t);
      spinePerp.push(nx, ny);
    }
  }
  const stride = radialSegs + 1;
  for (let i = 0; i < segCount; i++) {
    for (let j = 0; j < radialSegs; j++) {
      const a = i * stride + j;
      const b = a + stride;
      indices.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  const torsoGeo = track(new THREE.BufferGeometry());
  torsoGeo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  torsoGeo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  torsoGeo.setAttribute("aSpineT", new THREE.Float32BufferAttribute(spineT, 1));
  torsoGeo.setAttribute("aSpinePerp", new THREE.Float32BufferAttribute(spinePerp, 2));
  torsoGeo.setIndex(indices);
  torsoGeo.computeVertexNormals();

  const bodyMat = makeFishMat(bodyTex, { roughness: 0.42, emissiveIntensity: 0.24 });
  injectSerpentineSpineShader(bodyMat, uniforms, 0.13);
  bodyGroup.add(
    new THREE.Mesh(torsoGeo, bodyMat),
    new THREE.Mesh(track(buildOutlineGeometry(torsoGeo, 0.0028)), makeOutlineMat(0, 0, false))
  );

  const spineSamples = Array.from({ length: 64 }, (_, k) => {
    const st = k / 63;
    const pt = spineCurve.getPoint(st);
    const tang = spineCurve.getTangent(st);
    return { x: pt.x, y: pt.y, st, nx: tang.y, ny: -tang.x };
  });
  const closestSpine = (px: number, py: number) => {
    let best = spineSamples[0];
    let bestD = Infinity;
    for (const smp of spineSamples) {
      const d = (smp.x - px) ** 2 + (smp.y - py) ** 2;
      if (d < bestD) {
        bestD = d;
        best = smp;
      }
    }
    return best;
  };

  // 2. Long Slender Golden Pipe Snout + Articulated Trumpet Jaw
  const snoutMat = track(
    new THREE.MeshPhysicalMaterial({
      color: mixHex(GOLD, CREAM, 0.25),
      emissive: GOLD,
      emissiveIntensity: 0.16,
      roughness: 0.4,
    })
  );
  const snoutGeo = track(new THREE.CylinderGeometry(0.0115, 0.023, 0.148, 14));
  snoutGeo.rotateZ(-Math.PI / 2 - 0.17);
  snoutGeo.translate(0.302, 0.132, 0);
  bodyGroup.add(
    new THREE.Mesh(snoutGeo, snoutMat),
    new THREE.Mesh(track(buildOutlineGeometry(snoutGeo, 0.0022)), makeOutlineMat(0, 0, false))
  );

  const hx = 0.365;
  const hy = 0.121;
  const upperJawGroup = new THREE.Group();
  upperJawGroup.position.set(hx - 0.008, hy + 0.003, 0);
  const snoutTip = track(new THREE.SphereGeometry(0.0135, 10, 8));
  snoutTip.scale(1.3, 0.85, 0.92);
  snoutTip.translate(0.008, 0.002, 0);
  upperJawGroup.add(new THREE.Mesh(snoutTip, snoutMat));
  bodyGroup.add(upperJawGroup);

  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(hx - 0.042, hy - 0.005, 0);
  const lJawGeo = track(new THREE.CylinderGeometry(0.0085, 0.011, 0.046, 10));
  lJawGeo.rotateZ(-Math.PI / 2 - 0.12);
  lJawGeo.translate(0.022, -0.002, 0);
  lowerJawGroup.add(
    new THREE.Mesh(lJawGeo, snoutMat),
    new THREE.Mesh(track(buildOutlineGeometry(lJawGeo, 0.0018)), makeOutlineMat(0, 0, false))
  );
  bodyGroup.add(lowerJawGroup);

  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    hx - 0.015,
    hy - 0.002,
    "#5c1328",
    "#ff8aa8",
    [0.018, 0.011, 0.01],
    [0.012, 0.005, 0.007],
    0.024
  );

  // 3. Delicate Dorsal Spine Prickles & Branching Green Antler Horns on Head
  const spineNubMat = track(
    new THREE.MeshPhysicalMaterial({
      color: mixHex(GOLD, LIME, 0.35),
      emissive: LIME,
      emissiveIntensity: 0.16,
      roughness: 0.42,
    })
  );
  const spineNubGeo = track(new THREE.ConeGeometry(0.006, 0.022, 6));
  const prickleCoords: [number, number, number][] = [
    [0.148, 0.144, 0.25],
    [0.112, 0.095, 0.38],
    [0.088, 0.055, 0.25],
    [0.045, 0.048, 0.05],
    [-0.015, 0.056, -0.08],
    [-0.075, 0.056, -0.18],
    [0.072, -0.058, 2.7],
    [0.032, -0.072, 2.9],
  ];
  const prickles: { mesh: THREE.Mesh; baseX: number; baseY: number; baseRotZ: number; st: number; nx: number; ny: number }[] = [];
  for (const [px, py, rot] of prickleCoords) {
    const m = new THREE.Mesh(spineNubGeo, spineNubMat);
    m.position.set(px, py, 0);
    m.rotation.z = rot;
    bodyGroup.add(m);
    const spm = closestSpine(px, py);
    prickles.push({ mesh: m, baseX: px, baseY: py, baseRotZ: rot, st: spm.st, nx: spm.nx, ny: spm.ny });
  }

  // Sculpted branching green antler horns on the crown (matching reference head crest!)
  const antlerMat = track(
    new THREE.MeshPhysicalMaterial({
      color: LIME,
      emissive: DEEP_LEAF,
      emissiveIntensity: 0.2,
      roughness: 0.44,
    })
  );
  const buildAntlerHorn = (zSide: number) => {
    const hGrp = new THREE.Group();
    hGrp.position.set(0.186, 0.194, zSide * 0.012);
    const stemCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0.015, 0.045, zSide * 0.005),
      new THREE.Vector3(0.042, 0.085, zSide * 0.012),
    ]);
    const forkCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.014, 0.042, zSide * 0.005),
      new THREE.Vector3(-0.016, 0.074, zSide * 0.012),
    ]);
    const tipCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.025, 0.064, zSide * 0.008),
      new THREE.Vector3(0.006, 0.096, zSide * 0.012),
    ]);
    for (const crv of [stemCurve, forkCurve, tipCurve]) {
      const g = track(new THREE.TubeGeometry(crv, 8, 0.0052, 6, false));
      hGrp.add(new THREE.Mesh(g, antlerMat));
      const endPt = crv.getPoint(1);
      const bud = track(new THREE.SphereGeometry(0.0072, 7, 6));
      bud.translate(endPt.x, endPt.y, endPt.z);
      hGrp.add(new THREE.Mesh(bud, antlerMat));
    }
    bodyGroup.add(hGrp);
  };
  buildAntlerHorn(1);
  buildAntlerHorn(-1);

  // 4. Graceful Elongated Deeply-Lobed Chartreuse-Lime Kelp Fronds (matching image 2!)
  const buildKelpFrondAsset = (variant: number) => {
    const s = new THREE.Shape();
    if (variant === 0) {
      // Grand 5-lobe sinuous oak-kelp ribbon blade extending from (0,0) to (1, 0.08)
      s.moveTo(0, 0);
      s.bezierCurveTo(0.12, 0.08, 0.16, 0.36, 0.26, 0.34);
      s.bezierCurveTo(0.32, 0.32, 0.28, 0.12, 0.36, 0.14);
      s.bezierCurveTo(0.42, 0.16, 0.44, 0.42, 0.56, 0.40);
      s.bezierCurveTo(0.64, 0.38, 0.56, 0.14, 0.66, 0.16);
      s.bezierCurveTo(0.74, 0.18, 0.78, 0.32, 0.88, 0.28);
      s.bezierCurveTo(0.95, 0.24, 0.97, 0.12, 1.0, 0.06);
      s.bezierCurveTo(0.96, -0.06, 0.86, -0.18, 0.78, -0.14);
      s.bezierCurveTo(0.72, -0.10, 0.74, -0.02, 0.66, -0.06);
      s.bezierCurveTo(0.58, -0.10, 0.58, -0.36, 0.46, -0.34);
      s.bezierCurveTo(0.38, -0.32, 0.44, -0.10, 0.34, -0.12);
      s.bezierCurveTo(0.24, -0.14, 0.24, -0.34, 0.14, -0.28);
      s.bezierCurveTo(0.08, -0.24, 0.12, -0.08, 0, -0.015);
    } else {
      // Slender curved 4-lobe flowing streamer frond
      s.moveTo(0, 0);
      s.bezierCurveTo(0.14, 0.10, 0.22, 0.32, 0.34, 0.28);
      s.bezierCurveTo(0.42, 0.25, 0.36, 0.08, 0.48, 0.12);
      s.bezierCurveTo(0.58, 0.16, 0.64, 0.30, 0.78, 0.24);
      s.bezierCurveTo(0.90, 0.18, 0.96, 0.08, 1.0, 0.02);
      s.bezierCurveTo(0.95, -0.08, 0.82, -0.18, 0.72, -0.10);
      s.bezierCurveTo(0.64, -0.04, 0.64, -0.26, 0.50, -0.24);
      s.bezierCurveTo(0.40, -0.22, 0.44, -0.06, 0.32, -0.08);
      s.bezierCurveTo(0.20, -0.10, 0.16, -0.24, 0.08, -0.16);
      s.bezierCurveTo(0.04, -0.12, 0.05, -0.03, 0, -0.012);
    }
    s.closePath();

    const { geo, bounds } = createExtrudedFin(s, 0.012, 0.0025, 18);
    track(geo);
    const tex = track(
      makePaintedFinTex(
        maxAnisotropy,
        bounds,
        (fc) => {
          fc.fillStyle = makeLin(
            fc,
            0,
            0.22,
            1,
            -0.12,
            variant === 0
              ? [
                  [0, AMBER],
                  [0.14, GOLD],
                  [0.36, LIME],
                  [0.72, CHART],
                  [1, "#c9e84b"],
                ]
              : [
                  [0, LIME],
                  [0.45, CHART],
                  [0.85, "#a6cf2c"],
                  [1, "#d2ee5c"],
                ]
          );
          fc.fillRect(-0.1, -0.5, 1.25, 1.1);
          // Delicate golden-olive central vein & soft leaf ribs
          fc.strokeStyle = rgbaHex(DEEP_LEAF, 0.42);
          fc.lineWidth = 0.022;
          fc.beginPath();
          fc.moveTo(0.01, 0);
          fc.quadraticCurveTo(0.52, 0.06, 0.95, 0.04);
          fc.stroke();
          fc.strokeStyle = "rgba(232, 250, 145, 0.55)";
          fc.lineWidth = 0.014;
          for (const vx of [0.24, 0.50, 0.74]) {
            fc.beginPath();
            fc.moveTo(vx, 0.02);
            fc.lineTo(vx + 0.06, 0.24);
            fc.moveTo(vx, 0.02);
            fc.lineTo(vx + 0.04, -0.20);
            fc.stroke();
          }
        },
        192
      )
    );
    const mat = makeFishMat(tex, { roughness: 0.46, emissiveIntensity: 0.24 });
    const olGeo = track(buildOutlineGeometry(geo, 0.009));
    const olMat = makeOutlineMat(0, 0, false);
    return { geo, mat, olGeo, olMat };
  };

  const grandFrond = buildKelpFrondAsset(0);
  const slenderFrond = buildKelpFrondAsset(1);

  const kelpSwayGroups: {
    g: THREE.Group;
    baseX: number;
    baseY: number;
    baseZ: number;
    baseRotZ: number;
    baseRotY: number;
    phase: number;
    amp: number;
    st: number;
    nx: number;
    ny: number;
  }[] = [];
  const addFrond = (
    px: number,
    py: number,
    pz: number,
    angZ: number,
    angY: number,
    len: number,
    wid: number,
    slender: boolean,
    phase: number,
    amp = 0.14
  ) => {
    const asset = slender ? slenderFrond : grandFrond;
    const g = new THREE.Group();
    g.position.set(px, py, pz);
    g.rotation.set(0, angY, angZ);
    const mesh = new THREE.Mesh(asset.geo, asset.mat);
    mesh.scale.set(len, wid, 0.18);
    mesh.add(new THREE.Mesh(asset.olGeo, asset.olMat));
    g.add(mesh);
    bodyGroup.add(g);
    const spm = closestSpine(px, py);
    kelpSwayGroups.push({
      g,
      baseX: px,
      baseY: py,
      baseZ: pz,
      baseRotZ: angZ,
      baseRotY: angY,
      phase,
      amp,
      st: spm.st,
      nx: spm.nx,
      ny: spm.ny,
    });
  };

  // Grand Dorsal Sweeping Fronds arcing gracefully back & up from neck & arched spine (matching Image 2!)
  addFrond(0.118, 0.088, 0.012, 2.38, -0.18, 0.285, 0.145, false, 0.2, 0.12);
  addFrond(0.055, 0.046, 0.018, 2.48, -0.12, 0.305, 0.155, false, 0.9, 0.13);
  addFrond(-0.025, 0.052, -0.016, 2.66, 0.18, 0.245, 0.125, true, 1.5, 0.14);
  addFrond(-0.095, 0.052, 0.015, 2.86, -0.14, 0.225, 0.118, false, 2.1, 0.15);

  // Flowing Ventral Throat, Chest & Belly Fronds sweeping gracefully down & slightly forward/back
  addFrond(0.125, 0.042, 0.014, -2.26, -0.2, 0.205, 0.11, true, 0.5, 0.12);
  addFrond(0.072, -0.048, 0.022, -1.74, -0.14, 0.255, 0.132, false, 1.2, 0.14);
  addFrond(0.008, -0.068, -0.02, -1.32, 0.18, 0.235, 0.122, true, 1.9, 0.14);
  addFrond(-0.065, -0.044, 0.018, -1.38, -0.12, 0.205, 0.112, false, 2.5, 0.15);

  // Delicate Chin & Cheek Sprout Frondlets
  addFrond(0.158, 0.112, 0.02, -2.55, -0.25, 0.092, 0.055, true, 0.4, 0.16);
  addFrond(0.152, 0.175, -0.014, 2.18, 0.22, 0.112, 0.062, true, 1.1, 0.13);

  // Sweeping Down-Curled Tail Plume Fronds (top, outer back, and tip curl!)
  addFrond(-0.165, -0.012, 0.012, 3.04, -0.1, 0.215, 0.112, true, 0.8, 0.17);
  addFrond(-0.228, -0.098, 0.01, -3.02, -0.08, 0.178, 0.095, false, 1.6, 0.18);
  addFrond(-0.242, -0.182, -0.008, -2.72, 0.12, 0.155, 0.086, true, 2.2, 0.18);
  addFrond(-0.158, -0.268, 0.004, -2.35, 0, 0.165, 0.088, false, 2.8, 0.19);

  // 5. Gossamer Translucent Propeller Finlets (Dorsal + Neck Pectoral)
  const propShape = new THREE.Shape();
  propShape.moveTo(-0.045, -0.014);
  propShape.bezierCurveTo(-0.042, 0.048, 0.018, 0.058, 0.044, 0.004);
  propShape.closePath();
  const propFin = makeSpineFinMesh(
    ctx,
    propShape,
    0,
    0,
    0.0018,
    0.0005,
    (fc) => {
      fc.fillStyle = makeLin(fc, -0.04, 0.06, 0.04, -0.01, [
        [0, "rgba(255,248,195,0.92)"],
        [0.58, "rgba(234,182,42,0.78)"],
        [1, "rgba(146,191,36,0.85)"],
      ]);
      fc.fillRect(-0.07, -0.03, 0.14, 0.11);
    },
    maxAnisotropy,
    true,
    0.0006,
    { transparent: true, opacity: 0.84 }
  );
  propFin.mesh.position.set(-0.088, 0.042, 0);
  propFin.mesh.rotation.z = -0.28;
  bodyGroup.add(propFin.mesh);

  const tailPivot = new THREE.Group();
  tailPivot.position.set(-0.18, -0.18, 0);
  bodyGroup.add(tailPivot);

  const pShape = new THREE.Shape();
  pShape.moveTo(0, 0);
  pShape.bezierCurveTo(-0.018, 0.034, -0.068, 0.018, -0.064, -0.02);
  pShape.bezierCurveTo(-0.05, -0.05, -0.01, -0.038, 0, -0.01);
  pShape.closePath();
  const pecObj = makeSpineFinMesh(
    ctx,
    pShape,
    0,
    0,
    0.0018,
    0.0005,
    (fc) => {
      fc.fillStyle = makeLin(fc, 0, 0, -0.07, -0.02, [
        [0, "rgba(234,182,42,0.86)"],
        [0.55, "rgba(255,232,138,0.9)"],
        [1, "rgba(205,242,102,0.92)"],
      ]);
      fc.fillRect(-0.09, -0.06, 0.11, 0.11);
    },
    maxAnisotropy,
    false,
    0.0006,
    { transparent: true, opacity: 0.85 }
  );
  const pecLeft = new THREE.Group();
  pecLeft.position.set(0.115, 0.095, 0.026);
  pecLeft.add(pecObj.mesh);
  const pecRight = new THREE.Group();
  pecRight.position.set(0.115, 0.095, -0.026);
  pecRight.add(pecObj.mesh.clone());
  bodyGroup.add(pecLeft, pecRight);

  const pelvicFin = new THREE.Group();
  bodyGroup.add(pelvicFin);

  // 6. Sculpted Chestnut-Amber Jewel Eye (sleek natural size matching reference!)
  const eyeX = 0.202;
  const eyeY = 0.162;
  const eyeZ = 0.032;
  const amberRingGeo = track(new THREE.CylinderGeometry(0.024 * 1.24, 0.024 * 1.24, 0.006, 18));
  amberRingGeo.rotateX(Math.PI * 0.5);
  const amberRingMat = track(
    new THREE.MeshPhysicalMaterial({ color: GOLD, emissive: AMBER, emissiveIntensity: 0.22, roughness: 0.32 })
  );
  for (const s of [1, -1]) {
    const r = new THREE.Mesh(amberRingGeo, amberRingMat);
    r.position.set(eyeX, eyeY, s * (eyeZ - 0.001));
    r.rotation.y = s * 0.16;
    bodyGroup.add(r);
  }
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: eyeX,
    ey: eyeY,
    ez: eyeZ + 0.002,
    er: 0.023,
    irisColor: pal.iris || "#3a2208",
    rimColor: OL,
    happyColor: GOLD,
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, hx + 0.02, hy, CHART, 0.038);

  const propSpine = closestSpine(-0.088, 0.042);
  const pecSpine = closestSpine(0.115, 0.095);

  return {
    speciesKey: sp.id,
    tailPivotX: -0.18,
    isFluke: true,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p, open, swimAmp) => {
      uniforms.uSwimAmp.value = Math.max(uniforms.uSwimAmp.value * 1.45, 0.030 + clamp(p.swimSpeed, 0, 1.5) * 0.034);
      const tightClamp = p.jaw < 0 ? clamp(-p.jaw, 0, 0.48) : 0;
      bodyGroup.position.y = Math.sin(p.tailPh) * 0.014;
      bodyGroup.rotation.z = -p.tilt * 0.6 - clamp(p.swimSpeed, 0, 1.4) * 0.12;
      upperJawGroup.rotation.z = open * 0.24;
      lowerJawGroup.rotation.z = -open * 0.85 + tightClamp * 0.15;
      mouthInterior.visible = open > 0.03;
      if (open > 0.03) {
        mouthInterior.rotation.z = -open * 0.24;
        mouthInterior.scale.set(0.84 + open * 0.18, 0.28 + open * 0.96, 0.54 + open * 0.12);
      }
      tongueMesh.visible = open > 0.04;
      for (const pk of prickles) {
        const off = evalSerpentineOffset(pk.st, pk.nx, pk.ny, uniforms, 0.13);
        pk.mesh.position.set(pk.baseX + off.dx, pk.baseY + off.dy, off.dz);
        pk.mesh.rotation.z = pk.baseRotZ + off.rotZ * 0.45;
      }
      for (const k of kelpSwayGroups) {
        const off = evalSerpentineOffset(k.st, k.nx, k.ny, uniforms, 0.13);
        const w = Math.sin(p.wag2 * 1.45 + k.phase);
        k.g.position.set(k.baseX + off.dx, k.baseY + off.dy, k.baseZ + off.dz);
        k.g.rotation.z = k.baseRotZ + off.rotZ * 0.55 + w * (k.amp + swimAmp * 0.34);
        k.g.rotation.y = k.baseRotY + Math.cos(p.wag2 * 1.2 + k.phase) * 0.12 - off.dz * 1.8;
      }
      const pOff = evalSerpentineOffset(propSpine.st, propSpine.nx, propSpine.ny, uniforms, 0.13);
      propFin.mesh.position.set(-0.088 + pOff.dx, 0.042 + pOff.dy, pOff.dz);
      propFin.mesh.rotation.z = -0.28 + pOff.rotZ * 0.4;
      const pecOff = evalSerpentineOffset(pecSpine.st, pecSpine.nx, pecSpine.ny, uniforms, 0.13);
      pecLeft.position.set(0.115 + pecOff.dx, 0.095 + pecOff.dy, 0.026 + pecOff.dz);
      pecRight.position.set(0.115 + pecOff.dx, 0.095 + pecOff.dy, -0.026 + pecOff.dz);

      const buzz = p.wag2 * 3.4;
      propFin.mesh.rotation.y = Math.sin(buzz) * 0.34;
      pecLeft.rotation.y = 0.25 + Math.sin(buzz + 0.4) * 0.36;
      pecRight.rotation.y = -0.25 - Math.sin(buzz + 0.4) * 0.36;
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 5. AXOLOTL (Mochi — Chibi Sakura Salamander, 3x2 Feathered Gills, 4 3-Toed Feet!)
// =====================================================================================
function createAxolotl3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#4d1234";
  const PINK = pal.body || "#ffb6d9";
  const DK = pal.dark || "#db5c98";
  const BELLY = pal.belly || "#fff2f9";
  const GILL = pal.fin || "#ff3f82";
  const CRYS = pal.spot || "#6ef7ff";

  const ctx = createRigContext(OL, "#464646");
  const { track, uniforms, makeOutlineMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const xTail = -0.205;
  const xHead = 0.244;
  const hy = -0.040;
  const xSnout = 0.354;
  const tipY = -0.024;

  // Match drawAxolotl broad rounded chibi head & smooth closed mouth converging cleanly to nose tip
  const topProf = sampleBezierChain(
    [
      [[-0.205, 0.022], [-0.105, 0.076], [0.055, 0.096], [0.178, 0.104]],
      [[0.178, 0.104], [0.278, 0.112], [0.342, 0.062], [xSnout, tipY]],
    ],
    24
  );
  const botProf = sampleBezierChain(
    [
      [[-0.205, -0.022], [-0.09, -0.078], [0.052, -0.106], [0.175, -0.098]],
      [[0.175, -0.098], [0.285, -0.088], [0.340, -0.050], [xSnout, tipY]],
    ],
    24
  );
  const evalTop = (x: number) => interpCurveY(topProf, x);
  const evalBot = (x: number) => interpCurveY(botProf, x);
  // Smooth C1 cheek width tapering with ellipsoidal dome rounding at nose tip (zero cliff/crease, zero flat chisel)
  const evalZ = (x: number, t: number) => {
    const base = 0.026 + 0.086 * Math.sin(Math.pow(clamp(t, 0, 1), 0.72) * Math.PI);
    const cheekBoost = 0.032 * smoothstep(0.02, 0.23, x);
    const noseRound =
      x > 0.235 ? Math.sqrt(clamp(1 - Math.pow((x - 0.235) / (xSnout - 0.235), 2) * 0.996, 0.002, 1)) : 1;
    const hH = Math.max(0.002, (evalTop(x) - evalBot(x)) * 0.5);
    const w = (base + cheekBoost) * noseRound;
    return x > 0.235 ? Math.min(w, Math.max(0.002, hH * 1.32)) : w;
  };

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.22, 0.37, -0.125, 0.125, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);
  bc.fillStyle = makeLin(bc, 0.06, -0.108, 0.06, 0.105, [
    [0, DK],
    [0.42, PINK],
    [0.74, mixHex(PINK, BELLY, 0.45)],
    [1, mixHex(PINK, BELLY, 0.74)],
  ]);
  bc.fillRect(-0.32, -0.22, 0.78, 0.44);
  drawGlow(bc, 0.08, -0.058, 0.21, 0.045, 0, "255,255,255", 0.16);

  drawStar4Canvas(bc, 0.06, -0.042, 0.013, CRYS);
  drawStar4Canvas(bc, -0.03, -0.026, 0.015, CRYS);
  drawStar4Canvas(bc, -0.115, -0.012, 0.012, CRYS);
  bc.fillStyle = rgbaHex(CRYS, 0.85);
  drawBlob(bc, 0.015, 0.026, 0.009, 0.0065, 0);

  // Rosy merona cheek blush sits cleanly behind smile corner + twin white shine slashes
  bc.fillStyle = rgbaHex(GILL, 0.42);
  drawBlob(bc, 0.220, 0.026, 0.024, 0.014, 0.06);
  bc.strokeStyle = "rgba(255,255,255,0.68)";
  bc.lineWidth = 0.0024;
  bc.beginPath();
  bc.moveTo(0.212, 0.024);
  bc.lineTo(0.217, 0.018);
  bc.moveTo(0.222, 0.026);
  bc.lineTo(0.227, 0.020);
  bc.stroke();

  // Adorable delicate curved axolotl smile & friendly corner dimple matching evalSeamY
  bc.strokeStyle = rgbaHex(OL, 0.84);
  bc.lineWidth = 0.0046;
  bc.lineCap = "round";
  bc.beginPath();
  bc.moveTo(0.350, 0.024);
  bc.quadraticCurveTo(0.298, 0.044, 0.244, 0.038);
  bc.stroke();
  bc.lineWidth = 0.0038;
  bc.beginPath();
  bc.arc(0.241, 0.036, 0.008, Math.PI * 0.65, Math.PI * 1.45);
  bc.stroke();

  bc.restore();

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const evalSeamY = (x: number) => {
    const u = clamp((x - xHead) / (xSnout - xHead), 0, 1);
    return hy - Math.sin(u * Math.PI) * 0.005 + u * (tipY - hy);
  };
  const evalMidY = (x: number) => (evalTop(x) + evalBot(x)) * 0.5;
  const axoSpineMask = bodySpineOutlineMask(
    evalMidY,
    [{ x0: -0.205, x1: 0.02, top: true }, { x0: -0.205, x1: -0.09, top: false }],
    0.022
  );
  const axoSeamMask = mouthSeamOutlineMask(xHead, xSnout, hy, evalSeamY, false);
  const axoBodyMask = (x: number, y: number, z: number) => axoSpineMask(x, y, z) * axoSeamMask(x, y, z);

  const { bodyGeo, lowerJawGeo: lGeo } = buildSlicedHeadBody({
    xStart: xTail,
    xHinge: xHead,
    xEnd: xSnout,
    xLowerEnd: xSnout - 0.001,
    jawY: hy,
    evalTopY: evalTop,
    evalBotY: evalBot,
    evalSeamY,
    evalHalfZ: evalZ,
    mapUV,
    rearBulge: 0.004,
    uSteps: 60,
    vSteps: 32,
  });
  track(bodyGeo);
  track(lGeo);
  const bodyMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.18 });
  injectSpineShader(bodyMat, uniforms, 0, 0);
  bodyGroup.add(
    new THREE.Mesh(bodyGeo, bodyMat),
    new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0036, axoBodyMask)), makeOutlineMat(0, 0))
  );

  // Compact Cute Front Mouth Lower Jaw (hinged cleanly below eye & ahead of blush)
  const upperJawGroup = new THREE.Group();
  upperJawGroup.position.set(xHead, hy, 0);
  bodyGroup.add(upperJawGroup);

  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(xHead, hy, 0);
  bodyGroup.add(lowerJawGroup);
  const lMat = ctx.makeFishMat(bodyTex, { emissiveIntensity: 0.18 });
  injectSpineShader(lMat, uniforms, xHead, hy);
  lowerJawGroup.add(
    new THREE.Mesh(lGeo, lMat),
    new THREE.Mesh(
      track(buildOutlineGeometry(lGeo, 0.0032, mouthSeamOutlineMask(xHead, xSnout, hy, evalSeamY, true))),
      makeOutlineMat(xHead, hy)
    )
  );

  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    xHead + 0.028,
    hy + 0.004,
    "#7a1440",
    "#ff78aa",
    [0.044, 0.028, 0.042],
    [0.032, 0.011, 0.020],
    0.044
  );

  // 3 PAIRS of Fluffy Curved Feathered Coral-Magenta External Gills! (No spiky outline extrusion!)
  const makeFeatheredGillObj = (len: number) => {
    const gShape = new THREE.Shape();
    gShape.moveTo(0, -0.013);
    const nPinnae = 5;
    for (let i = 1; i <= nPinnae; i++) {
      const t = i / (nPinnae + 0.7);
      const bx = len * t;
      const fl = len * (0.30 + Math.sin(t * Math.PI) * 0.15);
      const tipX = bx - fl * 0.28;
      const tipY = -fl * 0.92;
      gShape.lineTo(bx - 0.006, -0.012);
      gShape.quadraticCurveTo(bx - fl * 0.20, -fl * 0.65, tipX, tipY);
      gShape.quadraticCurveTo(bx + 0.008, -fl * 0.62, bx + 0.009, -0.011);
    }
    gShape.quadraticCurveTo(len * 1.07, 0, len * 0.98, 0.011);
    for (let i = nPinnae; i >= 1; i--) {
      const t = i / (nPinnae + 0.7);
      const bx = len * t;
      const fl = len * (0.30 + Math.sin(t * Math.PI) * 0.15);
      const tipX = bx - fl * 0.28;
      const tipY = fl * 0.92;
      gShape.lineTo(bx + 0.009, 0.011);
      gShape.quadraticCurveTo(bx + 0.008, fl * 0.62, tipX, tipY);
      gShape.quadraticCurveTo(bx - fl * 0.20, fl * 0.65, bx - 0.006, 0.012);
    }
    gShape.lineTo(0, 0.013);
    gShape.closePath();

    return makeSpineFinMesh(ctx, gShape, 0, 0, 0.0055, 0.0022, (fc) => {
      fc.fillStyle = makeLin(fc, 0, 0, len, 0, [
        [0, PINK],
        [0.42, GILL],
        [0.82, "#ff8fc0"],
        [1, "#ffd9ec"],
      ]);
      fc.fillRect(-0.02, -len * 0.65, len * 1.2, len * 1.3);
      // Soft painted pinna shading & contour lines instead of jagged 3D backface spikes
      fc.strokeStyle = rgbaHex(OL, 0.42);
      fc.lineWidth = 0.0032;
      fc.lineCap = "round";
      for (let i = 1; i <= nPinnae; i++) {
        const t = i / (nPinnae + 0.7);
        const bx = len * t;
        const fl = len * (0.30 + Math.sin(t * Math.PI) * 0.15);
        fc.beginPath();
        fc.moveTo(bx, 0);
        fc.quadraticCurveTo(bx - fl * 0.14, -fl * 0.48, bx - fl * 0.26, -fl * 0.82);
        fc.moveTo(bx, 0);
        fc.quadraticCurveTo(bx - fl * 0.14, fl * 0.48, bx - fl * 0.26, fl * 0.82);
        fc.stroke();
      }
      fc.strokeStyle = rgbaHex(CRYS, 0.68);
      fc.lineWidth = 0.0028;
      fc.beginPath();
      fc.moveTo(0.01, 0);
      fc.lineTo(len * 0.86, 0);
      fc.stroke();
    }, maxAnisotropy, false, 0);
  };

  // Crowned halo arrangement flaring softly OUTWARD (-s * angle) so front & side views read lush & feathery!
  const gillConfigs: [number, number, number, number][] = [
    [0.162, 0.072, 1.88, 0.126],
    [0.146, 0.036, 2.28, 0.140],
    [0.140, -0.004, 2.68, 0.122],
  ];
  const evalAxoZ = (x: number) => evalZ(x, (x - xTail) / (xSnout - xTail));
  const gillMeshes: { mesh: THREE.Object3D; baseRotY: number; phase: number }[] = [];
  for (const s of [1, -1]) {
    gillConfigs.forEach(([gx, gy, rotZ, gLen], gi) => {
      const obj = makeFeatheredGillObj(gLen);
      const gz = Math.max(0.01, surfaceZAt(evalTop, evalBot, evalAxoZ, gx, gy, 0.22, 0.94));
      const pivotZ = new THREE.Group();
      pivotZ.position.set(gx, gy, s * gz);
      pivotZ.rotation.z = rotZ;
      const flare = new THREE.Group();
      const baseRotY = -s * (0.48 + gi * 0.07);
      flare.rotation.y = baseRotY;
      flare.rotation.x = s * (0.08 - gi * 0.04);
      flare.add(obj.mesh);
      pivotZ.add(flare);
      bodyGroup.add(pivotZ);
      gillMeshes.push({ mesh: flare, baseRotY, phase: gi * 0.55 });
    });
  }

  // 4 Cute Plump 3-Toed Paddle Feet!
  const footShape = new THREE.Shape();
  footShape.moveTo(-0.015, 0.008);
  footShape.bezierCurveTo(-0.019, -0.032, -0.035, -0.058, -0.022, -0.068);
  footShape.quadraticCurveTo(-0.01, -0.078, -0.002, -0.065);
  footShape.quadraticCurveTo(0.008, -0.076, 0.016, -0.064);
  footShape.quadraticCurveTo(0.027, -0.07, 0.025, -0.052);
  footShape.bezierCurveTo(0.023, -0.03, 0.013, -0.008, 0.011, 0.008);
  footShape.closePath();
  const footAsset = makeSpineFinMesh(ctx, footShape, 0, 0, 0.0075, 0.002, (fc) => {
    fc.fillStyle = makeLin(fc, 0, 0.01, 0, -0.07, [
      [0, PINK],
      [0.75, BELLY],
      [1, "#ffe3f2"],
    ]);
    fc.fillRect(-0.05, -0.1, 0.1, 0.14);
  }, maxAnisotropy, false, 0.0011);

  const feet: { g: THREE.Group; baseRotZ: number; phase: number }[] = [];
  for (const [fx, fy, s, baseRotZ, ph] of [
    [0.092, -0.058, 1, -0.36, 0],
    [0.092, -0.058, -1, -0.36, Math.PI],
    [-0.095, -0.048, 1, -0.72, Math.PI],
    [-0.095, -0.048, -1, -0.72, 0],
  ] as const) {
    const fz = s * (surfaceZAt(evalTop, evalBot, evalAxoZ, fx, fy, 0.22, 1.0) + 0.005);
    const fg = new THREE.Group();
    fg.position.set(fx, fy, fz);
    fg.rotation.z = baseRotZ;
    fg.rotation.x = s > 0 ? -0.44 : 0.44;
    fg.rotation.y = s * 0.24;
    const fm = feesClone(footAsset.mesh);
    fg.add(fm);
    bodyGroup.add(fg);
    feet.push({ g: fg, baseRotZ, phase: ph });
  }
  function feesClone(m: THREE.Mesh) {
    return m === footAsset.mesh && feet.length === 0 ? m : m.clone();
  }

  // ONE Continuous Seamless Spine-Waving Crystal Ribbon Tail (dense regular lofted quad grid = zero facets, zero seam/tear!)
  const tailTopPts = sampleBezierChain(
    [
      [[-0.448, -0.006], [-0.422, 0.088], [-0.305, 0.148], [-0.155, 0.132]],
      [[-0.155, 0.132], [-0.075, 0.118], [-0.025, 0.095], [0.015, 0.068]],
    ],
    26
  );
  const tailBotPts = sampleBezierChain(
    [
      [[-0.448, -0.006], [-0.415, -0.092], [-0.315, -0.128], [-0.205, -0.020]],
      [[-0.205, -0.020], [-0.145, 0.012], [-0.065, 0.044], [0.015, 0.065]],
    ],
    26
  );
  const { geo: tailRibbonGeo, bounds: tailRibbonBounds } = buildSmoothLoftedFin({
    xStart: -0.448,
    xEnd: 0.015,
    uSteps: 40,
    vSteps: 14,
    evalTopY: (x) => interpCurveY(tailTopPts, x),
    evalBotY: (x) => interpCurveY(tailBotPts, x),
    maxHalfZ: 0.0042,
  });
  track(tailRibbonGeo);

  const tailRibbonTex = track(
    makePaintedFinTex(
      maxAnisotropy,
      tailRibbonBounds,
      (fc) => {
        fc.fillStyle = makeLin(fc, 0.02, 0.11, -0.44, -0.08, [
          [0, "rgba(255,182,217,0.88)"],
          [0.42, "rgba(255,110,175,0.74)"],
          [0.78, "rgba(110,247,255,0.82)"],
          [1, "rgba(218,252,255,0.94)"],
        ]);
        fc.fillRect(-0.52, -0.18, 0.60, 0.38);
        // Subtle iridescent crystal facets
        fc.fillStyle = "rgba(255,255,255,0.28)";
        fc.beginPath();
        fc.moveTo(-0.22, 0.115);
        fc.lineTo(-0.31, 0.04);
        fc.lineTo(-0.37, 0.085);
        fc.closePath();
        fc.fill();
        fc.fillStyle = "rgba(110,247,255,0.34)";
        fc.beginPath();
        fc.moveTo(-0.32, -0.015);
        fc.lineTo(-0.41, -0.045);
        fc.lineTo(-0.36, -0.095);
        fc.closePath();
        fc.fill();
        // Continuous iridescent aqua-pearl rim along crest & crystal tail edge
        fc.strokeStyle = rgbaHex(CRYS, 0.88);
        fc.lineWidth = 0.0075;
        fc.lineCap = "round";
        fc.beginPath();
        fc.moveTo(0.0, 0.074);
        fc.bezierCurveTo(-0.14, 0.132, -0.32, 0.138, -0.415, 0.032);
        fc.bezierCurveTo(-0.442, -0.004, -0.430, -0.056, -0.395, -0.084);
        fc.stroke();
        drawStar4Canvas(fc, -0.14, 0.098, 0.014, CRYS);
        drawStar4Canvas(fc, -0.265, 0.068, 0.016, CRYS);
        drawStar4Canvas(fc, -0.365, 0.015, 0.018, "#ffffff");
        drawStar4Canvas(fc, -0.315, -0.058, 0.014, CRYS);
      },
      384
    )
  );
  const tailRibbonMat = ctx.makeFishMat(tailRibbonTex, {
    transparent: true,
    opacity: 0.92,
    emissiveIntensity: 0.28,
  });
  injectSpineShader(tailRibbonMat, uniforms, 0, 0);
  const tailRibbonMesh = new THREE.Mesh(tailRibbonGeo, tailRibbonMat);
  const ribbonTailMask = (x: number, y: number) => {
    if (x >= -0.205) {
      return smoothstep(evalTop(x) - 0.002, evalTop(x) + 0.012, y);
    }
    return 1;
  };
  tailRibbonMesh.add(
    new THREE.Mesh(track(buildOutlineGeometry(tailRibbonGeo, 0.0011, ribbonTailMask)), makeOutlineMat(0, 0, true))
  );
  bodyGroup.add(tailRibbonMesh);

  // Empty tailPivot kept at tail root for pose API compatibility (ribbon waves organically with spine shader)
  const tailPivot = new THREE.Group();
  tailPivot.position.set(-0.205, 0, 0);
  bodyGroup.add(tailPivot);

  const pecLeft = new THREE.Group();
  const pecRight = new THREE.Group();
  const pelvicFin = new THREE.Group();

  const eyeZ = computeEyeZ(
    evalTop,
    evalBot,
    (x) => evalZ(x, clamp((x - xTail) / (xSnout - xTail), 0, 1)),
    0.252,
    0.032,
    0.042
  );
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: 0.252,
    ey: 0.032,
    ez: eyeZ,
    er: 0.042,
    sx: 0.94,
    yawRot: 0.28,
    irisScale: 0.68,
    pupilScale: 0.44,
    irisColor: pal.iris || "#28143b",
    rimColor: OL,
    happyColor: GILL,
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout + 0.02, -0.02, CRYS, 0.05);

  return {
    speciesKey: sp.id,
    tailPivotX: -0.192,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p, open) => {
      const tightClamp = p.jaw < 0 ? clamp(-p.jaw, 0, 0.48) : 0;
      // Wide cute cartoon axolotl mangap + happy gill/paddle flare!
      lowerJawGroup.rotation.z = -open * 1.02 + tightClamp * 0.16;
      mouthInterior.visible = open > 0.03;
      if (open > 0.03) {
        mouthInterior.rotation.z = -open * 0.28;
        mouthInterior.scale.set(0.86 + open * 0.20, 0.30 + open * 1.04, 0.56 + open * 0.12);
      }
      tongueMesh.visible = open > 0.04;
      tongueMesh.position.y = 0.002 + open * 0.008;
      const excite = open > 0.2 ? 1.45 : 1;
      for (const f of feet) {
        f.g.rotation.z = f.baseRotZ + Math.sin(p.tailPh * excite + f.phase) * 0.34;
      }
      for (const gm of gillMeshes) {
        gm.mesh.rotation.y = gm.baseRotY + Math.sin(p.wag2 * excite + gm.phase) * (0.12 + open * 0.08);
      }
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// DISPATCHER
// =====================================================================================
export function createRareFish3DRig(sp: Species, maxAnisotropy = 4): Fish3DRig | null {
  switch (sp.style) {
    case "mandarin":
      return createMandarin3DRig(sp, maxAnisotropy);
    case "aurora":
      return createAurora3DRig(sp, maxAnisotropy);
    case "narwhal":
      return createNarwhal3DRig(sp, maxAnisotropy);
    case "seadragon":
      return createSeadragon3DRig(sp, maxAnisotropy);
    case "axolotl":
      return createAxolotl3DRig(sp, maxAnisotropy);
    default:
      return null;
  }
}
