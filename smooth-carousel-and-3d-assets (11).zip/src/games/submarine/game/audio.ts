import type { SoundPack } from "../save";
import { SFX_DATA } from "./sfxData";
const spawnWav = SFX_DATA["playerSpawn"];
const growWav = SFX_DATA["playerGrow"];
const eatWav = SFX_DATA["playerEat"];
const dashWav = SFX_DATA["playerDash"];
const eatSmallWav = SFX_DATA["EATSMALLFISH"];
const bite1Wav = SFX_DATA["bite1"];
const bite2Wav = SFX_DATA["bite2"];
const bite3Wav = SFX_DATA["bite3"];
const bite4Wav = SFX_DATA["bite4"];
const bubbleLoopWav = SFX_DATA["bubbleLoop"];
const bubbles1Wav = SFX_DATA["bubbles1"];
const bubbles2Wav = SFX_DATA["bubbles2"];
const playerSuckWav = SFX_DATA["playerSuck"];
const stageClearWav = SFX_DATA["stageClear"];
const waterAmb1Wav = SFX_DATA["waterAmb1"];
const waterAmb2Wav = SFX_DATA["waterAmb2"];
const waterLoopWav = SFX_DATA["waterLoop"];
const wave1Wav = SFX_DATA["wave1"];
const wave2Wav = SFX_DATA["wave2"];

type SfxKey =
  | "spawn"
  | "grow"
  | "eat"
  | "dash"
  | "eatSmall"
  | "bite1"
  | "bite2"
  | "bite3"
  | "bite4"
  | "bubbleLoop"
  | "bubbles1"
  | "bubbles2"
  | "playerSuck"
  | "stageClear"
  | "waterAmb1"
  | "waterAmb2"
  | "waterLoop"
  | "wave1"
  | "wave2";

const WAV_URLS: Record<SfxKey, string> = {
  spawn: spawnWav,
  grow: growWav,
  eat: eatWav,
  dash: dashWav,
  eatSmall: eatSmallWav,
  bite1: bite1Wav,
  bite2: bite2Wav,
  bite3: bite3Wav,
  bite4: bite4Wav,
  bubbleLoop: bubbleLoopWav,
  bubbles1: bubbles1Wav,
  bubbles2: bubbles2Wav,
  playerSuck: playerSuckWav,
  stageClear: stageClearWav,
  waterAmb1: waterAmb1Wav,
  waterAmb2: waterAmb2Wav,
  waterLoop: waterLoopWav,
  wave1: wave1Wav,
  wave2: wave2Wav,
};

const WAV_PRIORITY_ORDER: SfxKey[] = [
  "bite1",
  "bite2",
  "bite3",
  "bite4",
  "eat",
  "eatSmall",
  "dash",
  "spawn",
  "grow",
  "playerSuck",
  "stageClear",
  "bubbleLoop",
  "waterLoop",
  "bubbles1",
  "bubbles2",
  "wave1",
  "wave2",
  "waterAmb2",
  "waterAmb1",
];

const BITE_KEYS: SfxKey[] = ["bite1", "bite2", "bite3", "bite4"];
const BUBBLE_KEYS: SfxKey[] = ["bubbles1", "bubbles2"];
const WATER_AMB_KEYS: SfxKey[] = ["waterAmb1", "waterAmb2"];
const WAVE_KEYS: SfxKey[] = ["wave1", "wave2"];

export interface AmbienceState {
  inPlay: boolean;
  playerY: number;
  camTop: number;
  sucking: boolean;
  boosting: boolean;
  ventProx: number;
}

class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  musicGain: GainNode | null = null;
  wavBus: GainNode | null = null;
  ambBus: GainNode | null = null;

  // Fallback synthetic suction loop + real WAV loops
  suckGain: GainNode | null = null;
  suckFilter: BiquadFilterNode | null = null;
  suckWavGain: GainNode | null = null;
  suckWavSrc: AudioBufferSourceNode | null = null;
  bubbleLoopGain: GainNode | null = null;
  bubbleLoopSrc: AudioBufferSourceNode | null = null;
  waterLoopGain: GainNode | null = null;
  waterLoopSrc: AudioBufferSourceNode | null = null;

  suckWanted = false;
  muted = false;
  pack: SoundPack = "wav";
  lastCoin = -99;
  lastPop = -99;
  lastSmallWav = -99;
  lastBiteWav = -99;
  lastDashWav = -99;
  lastStageClear = -99;
  lastBubbleBurst = -99;
  lastSurfaceSplash = -99;
  lastWaveAmb = -99;
  lastWaterAmb = -99;
  lastAmbBubble = -99;
  lastWhaleCall = -99;
  lastSonarPing = -99;
  nextWaveDelay = 4.6;
  nextWaterAmbDelay = 9.5;
  nextAmbBubbleDelay = 7.5;
  nextWhaleDelay = 18;
  nextSonarDelay = 14;

  lastBiteIdx = -1;
  lastBubbleIdx = 0;
  lastWaveIdx = 0;
  lastWaterAmbIdx = 0;

  musicTimer: number | null = null;
  buffers = new Map<SfxKey, AudioBuffer>();
  loadPromises = new Map<SfxKey, Promise<AudioBuffer | null>>();
  failedKeys = new Set<SfxKey>();
  loadingStarted = false;
  pendingSpawnAt = 0;
  pendingBiteAt = 0;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      this.preloadWavs();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    if (this.ctx.state === "suspended") void this.ctx.resume();

    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.34;
    this.master.connect(this.ctx.destination);

    // Chiptune background music gain (active ONLY in "classic" mode, muted in "wav" mode)
    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = this.pack === "classic" && !this.muted ? 1 : 0;
    this.musicGain.connect(this.master);

    // Dedicated balanced bus for mastered gameplay WAV sound effects
    this.wavBus = this.ctx.createGain();
    this.wavBus.gain.value = this.muted ? 0 : 0.85;
    this.wavBus.connect(this.ctx.destination);

    // Dedicated bus for underwater / surface / bubble ambience
    this.ambBus = this.ctx.createGain();
    this.ambBus.gain.value = this.muted ? 0 : 0.72;
    this.ambBus.connect(this.ctx.destination);

    // Classic synthetic suction noise loop (used ONLY in "classic" mode)
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    this.suckFilter = this.ctx.createBiquadFilter();
    this.suckFilter.type = "bandpass";
    this.suckFilter.frequency.value = 600;
    this.suckFilter.Q.value = 2;
    this.suckGain = this.ctx.createGain();
    this.suckGain.gain.value = 0;
    src.connect(this.suckFilter);
    this.suckFilter.connect(this.suckGain);
    this.suckGain.connect(this.master);
    src.start();

    this.startMusic();
    this.preloadWavs();
  }

  private startLoopNode(key: SfxKey, initialGain: number, rate = 1.0): { src: AudioBufferSourceNode; gain: GainNode } | null {
    if (!this.ctx || !this.ambBus) return null;
    const buf = this.buffers.get(key);
    if (!buf) return null;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    src.playbackRate.value = rate;
    const gain = this.ctx.createGain();
    gain.gain.value = initialGain;
    src.connect(gain);
    gain.connect(this.ambBus);
    src.start();
    return { src, gain };
  }

  private ensureLoopNodes(loadedKey?: SfxKey) {
    if (!this.ctx || !this.ambBus || this.pack !== "wav") return;
    if ((!loadedKey || loadedKey === "playerSuck") && !this.suckWavSrc && this.buffers.has("playerSuck")) {
      const node = this.startLoopNode("playerSuck", 0, 1.0);
      if (node) {
        this.suckWavSrc = node.src;
        this.suckWavGain = node.gain;
        if (this.suckWanted) this.setSuck(true);
      }
    }
    if ((!loadedKey || loadedKey === "bubbleLoop") && !this.bubbleLoopSrc && this.buffers.has("bubbleLoop")) {
      const node = this.startLoopNode("bubbleLoop", 0, 1.02);
      if (node) {
        this.bubbleLoopSrc = node.src;
        this.bubbleLoopGain = node.gain;
      }
    }
    if ((!loadedKey || loadedKey === "waterLoop") && !this.waterLoopSrc && this.buffers.has("waterLoop")) {
      const node = this.startLoopNode("waterLoop", 0.36, 1.0);
      if (node) {
        this.waterLoopSrc = node.src;
        this.waterLoopGain = node.gain;
      }
    }
  }

  private loadKey(key: SfxKey): Promise<AudioBuffer | null> {
    const existingBuf = this.buffers.get(key);
    if (existingBuf) return Promise.resolve(existingBuf);
    const existingPromise = this.loadPromises.get(key);
    if (existingPromise) return existingPromise;
    if (!this.ctx) return Promise.resolve(null);

    const ctx = this.ctx;
    const p = fetch(WAV_URLS[key])
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.arrayBuffer();
      })
      .then((arr) => ctx.decodeAudioData(arr))
      .then((decoded) => {
        this.buffers.set(key, decoded);
        this.failedKeys.delete(key);
        this.ensureLoopNodes(key);
        if (
          this.pack === "wav" &&
          key === "spawn" &&
          this.pendingSpawnAt > 0 &&
          performance.now() - this.pendingSpawnAt < 1800
        ) {
          this.pendingSpawnAt = 0;
          this.playWav("spawn", 0.95);
          this.bubbleBurst(0.32, 1.3);
        }
        return decoded;
      })
      .catch(() => {
        this.failedKeys.add(key);
        return null;
      });
    this.loadPromises.set(key, p);
    return p;
  }

  private preloadWavs() {
    if (this.loadingStarted || !this.ctx) return;
    this.loadingStarted = true;
    WAV_PRIORITY_ORDER.forEach((key) => {
      void this.loadKey(key);
    });
  }

  whenReady(keys: SfxKey[] = ["bite1", "bite2", "eat", "spawn"]): Promise<void> {
    if (!this.ctx) this.init();
    if (!this.ctx) return Promise.resolve();
    this.preloadWavs();
    const promises = keys.map((k) => this.loadKey(k));
    const timeout = new Promise<void>((resolve) => window.setTimeout(resolve, 1400));
    return Promise.race([Promise.all(promises).then(() => undefined), timeout]);
  }

  setPack(pack: SoundPack) {
    if (this.pack === pack) return;
    this.pack = pack;
    // Reset short cooldowns so immediate menu/HUD preview clicks always sound right away
    this.lastBiteWav = -99;
    this.lastSmallWav = -99;
    this.lastDashWav = -99;
    if (!this.ctx) return;
    if (this.ctx.state === "suspended") void this.ctx.resume();
    const t = this.ctx.currentTime;
    if (pack === "classic") {
      this.pendingSpawnAt = 0;
      this.pendingBiteAt = 0;
      if (this.musicGain) this.musicGain.gain.setTargetAtTime(this.muted ? 0 : 1, t, 0.05);
      if (this.suckWavGain) this.suckWavGain.gain.setTargetAtTime(0, t, 0.04);
      if (this.bubbleLoopGain) this.bubbleLoopGain.gain.setTargetAtTime(0, t, 0.05);
      if (this.waterLoopGain) this.waterLoopGain.gain.setTargetAtTime(0, t, 0.08);
    } else {
      if (this.musicGain) this.musicGain.gain.setTargetAtTime(0, t, 0.04);
      this.preloadWavs();
      this.ensureLoopNodes();
      if (this.waterLoopGain) this.waterLoopGain.gain.setTargetAtTime(0.36, t, 0.12);
    }
    this.setSuck(this.suckWanted);
  }

  private playWav(key: SfxKey, gain = 0.9, rate = 1.0, delay = 0, toAmb = false, offset = 0): boolean {
    if (this.pack !== "wav") return false;
    const dest = toAmb ? this.ambBus : this.wavBus;
    if (!this.ctx || !dest || this.muted) return false;
    if (this.ctx.state === "suspended") void this.ctx.resume();
    const buf = this.buffers.get(key);
    if (!buf) return false;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.setValueAtTime(Math.max(0.5, Math.min(2, rate)), t);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    src.connect(g);
    g.connect(dest);
    const safeOff = Math.max(0, Math.min(offset, Math.max(0, buf.duration - 0.04)));
    src.start(t, safeOff);
    return true;
  }

  /** Plays a smooth enveloped slice (fade-in & fade-out) for long ambient/bubble/wave recordings */
  private playEnvWav(key: SfxKey, peakGain: number, maxDur?: number, fadeIn = 0.25, fadeOut = 0.65, rate = 1.0, offset = 0, toAmb = true): boolean {
    if (this.pack !== "wav") return false;
    const dest = toAmb ? this.ambBus : this.wavBus;
    if (!this.ctx || !dest || this.muted) return false;
    if (this.ctx.state === "suspended") void this.ctx.resume();
    const buf = this.buffers.get(key);
    if (!buf) return false;
    const safeOff = Math.max(0, Math.min(offset, Math.max(0, buf.duration - 0.2)));
    const avail = Math.max(0.15, (buf.duration - safeOff) / rate);
    const dur = maxDur ? Math.min(avail, maxDur) : avail;
    const fi = Math.min(fadeIn, dur * 0.35);
    const fo = Math.min(fadeOut, dur * 0.45);
    const t = this.ctx.currentTime;

    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.setValueAtTime(Math.max(0.5, Math.min(2, rate)), t);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peakGain, t + fi);
    if (dur > fi + fo) {
      g.gain.setValueAtTime(peakGain, t + dur - fo);
    }
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    src.connect(g);
    g.connect(dest);
    src.start(t, safeOff, dur * rate + 0.05);
    src.stop(t + dur + 0.05);
    return true;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.34;
    if (this.musicGain) this.musicGain.gain.value = !m && this.pack === "classic" ? 1 : 0;
    if (this.wavBus) this.wavBus.gain.value = m ? 0 : 0.85;
    if (this.ambBus) this.ambBus.gain.value = m ? 0 : 0.72;
  }

  tone(type: OscillatorType, f0: number, f1: number, dur: number, vol = 0.3, delay = 0, destNode?: AudioNode | null) {
    const dest = destNode ?? this.master;
    if (!this.ctx || !dest) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(dest);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  spawn() {
    if (this.pack === "wav") {
      if (this.playWav("spawn", 0.95)) {
        this.bubbleBurst(0.32, 1.3);
        return;
      }
      if (!this.failedKeys.has("spawn")) {
        this.pendingSpawnAt = performance.now();
        this.preloadWavs();
        return;
      }
    }
    [392, 523.25, 659.25].forEach((f, i) => this.tone("triangle", f, f * 1.12, 0.12, 0.14, i * 0.045));
    this.bubble();
  }

  gulp(size = 1, isPlayer = true, comboStep = 0) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;

    if (this.pack === "wav") {
      const readyBites = BITE_KEYS.filter((k) => this.buffers.has(k));
      const pool = readyBites.length > 0 ? readyBites : BITE_KEYS;
      let idx = Math.floor(Math.random() * pool.length);
      if (pool.length > 1 && idx === this.lastBiteIdx) {
        idx = (idx + 1 + Math.floor(Math.random() * (pool.length - 1))) % pool.length;
      }
      this.lastBiteIdx = idx;
      const biteKey = pool[idx];
      const comboLift = isPlayer ? Math.min(10, Math.max(0, comboStep)) * 0.022 : 0;
      const biteRate = Math.max(0.84, Math.min(1.32, 1.08 - size * 0.07 + comboLift)) * (0.96 + Math.random() * 0.08);

      if (isPlayer) {
        if (now - this.lastBiteWav < 0.06) return;
        this.lastBiteWav = now;
        const playedBite = this.playWav(biteKey, 0.98, biteRate);
        const playedEat = this.playWav("eat", 0.8, Math.min(1.25, 0.98 + comboLift * 0.7 + Math.random() * 0.06), 0.035);
        if (size > 1.35) this.bubbleBurst(0.3, 1.1);
        if (playedBite || playedEat) return;

        // If WAVs are still decoding right after first click, wait briefly instead of falling back to synth
        if (!this.failedKeys.has(biteKey) || !this.failedKeys.has("eat")) {
          const reqAt = performance.now();
          this.pendingBiteAt = reqAt;
          void this.whenReady([biteKey, "eat"]).then(() => {
            if (this.pack !== "wav" || this.pendingBiteAt !== reqAt) return;
            this.playWav(biteKey, 0.98, biteRate);
            this.playWav("eat", 0.8, 1.0, 0.035);
          });
          return;
        }
      } else {
        if (now - this.lastBiteWav < 0.14) return;
        this.lastBiteWav = now;
        if (this.playWav(biteKey, 0.3, biteRate) || !this.failedKeys.has(biteKey)) return;
      }
    }

    // Classic synth bite
    const p = 1 / Math.max(0.6, Math.min(2.5, size));
    const j = 0.9 + Math.random() * 0.2;
    this.tone("square", 520 * p * j, 140 * p, 0.09, 0.22);
    this.tone("triangle", 260 * p * j, 60 * p, 0.14, 0.35, 0.03);
    this.tone("sine", 900 * j, 1400 * j, 0.05, 0.12, 0.08);
    if (size > 0.7) this.tone("sine", 170 * p, 46, 0.17, Math.min(0.5, 0.22 + size * 0.1), 0.01);
  }

  /** bubbly slurp for every little fish eaten; EATSMALLFISH.wav starts past its 42ms silent intro in WAV mode */
  pop(n = 1) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (this.pack === "wav") {
      if (now - this.lastSmallWav < 0.048) return;
      const rate = 0.95 + Math.min(14, Math.max(0, n - 1)) * 0.022;
      if (this.playWav("eatSmall", 1.12, rate, 0, false, 0.042)) {
        this.lastSmallWav = now;
        this.lastPop = now;
        return;
      }
      if (!this.failedKeys.has("eatSmall")) return;
    }
    if (now - this.lastPop < 0.035) return;
    this.lastPop = now;
    const ladder = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24];
    const f = 494 * Math.pow(2, ladder[Math.min(ladder.length - 1, Math.max(0, n - 1))] / 12);
    this.tone("sine", f * 0.62, f * 1.3, 0.065, 0.12);
  }

  /** coin chime; crystal aquatic pearl chime in WAV mode, retro square arpeggio in Classic mode */
  coin(step = 0) {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime;
    if (now - this.lastCoin < 0.04) return;
    this.lastCoin = now;
    const scale = [0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17];
    const f = 988 * Math.pow(2, scale[Math.min(scale.length - 1, Math.max(0, step))] / 12);
    if (this.pack === "wav") {
      this.tone("sine", f * 0.78, f * 0.78, 0.11, 0.09, 0, this.wavBus);
      this.tone("sine", f * 1.18, f * 1.2, 0.18, 0.08, 0.04, this.wavBus);
      this.tone("sine", f * 2.36, f * 2.36, 0.22, 0.025, 0.045, this.wavBus);
      return;
    }
    this.tone("square", f, f, 0.05, 0.07);
    this.tone("square", f * 1.335, f * 1.335, 0.11, 0.07, 0.045);
    this.tone("sine", f * 2.67, f * 2.67, 0.18, 0.03, 0.045);
  }

  stageClear(gain = 0.9) {
    if (!this.ctx) return false;
    const now = this.ctx.currentTime;
    if (now - this.lastStageClear < 2.8) return false;
    if (this.playWav("stageClear", gain)) {
      this.lastStageClear = now;
      return true;
    }
    return false;
  }

  /** celebratory fanfare for clearing an entire fish school ("SAPU BERSIH!") */
  bonus() {
    if (this.pack === "wav") {
      if (this.stageClear(0.92)) return;
      if (!this.failedKeys.has("stageClear")) {
        this.playWav("grow", 0.65, 1.12);
        this.bubbleBurst(0.38, 1.2);
        return;
      }
    }
    [0, 4, 7, 12, 16, 19, 24, 28].forEach((s, i) => this.tone("triangle", 659 * Math.pow(2, s / 12), 659 * Math.pow(2, s / 12), 0.14, 0.16, i * 0.045));
    this.tone("sine", 1318, 2637, 0.5, 0.07, 0.36);
  }

  combo(n: number) {
    if (!this.ctx || this.muted) return;
    if (this.pack === "wav") {
      const rate = Math.min(1.5, 1.15 + Math.min(n, 10) * 0.03);
      this.playWav("eat", 0.44, rate, 0, false, 0.02);
      const base = 523.25 * Math.pow(2, Math.min(n, 10) / 12);
      this.tone("sine", base, base * 1.25, 0.14, 0.06, 0.02, this.wavBus);
      return;
    }
    const base = 440 * Math.pow(2, Math.min(n, 12) / 12);
    [0, 4, 7, 12].forEach((s, i) => this.tone("square", base * Math.pow(2, s / 12), base * Math.pow(2, s / 12), 0.08, 0.1, i * 0.06));
  }

  frenzy() {
    if (this.pack === "wav") {
      if (this.stageClear(0.85)) return;
      if (!this.failedKeys.has("stageClear")) {
        this.playWav("grow", 0.62, 1.08);
        this.bubbleBurst(0.36, 1.15);
        return;
      }
    }
    [0, 4, 7, 12, 16, 19, 24].forEach((s, i) => this.tone("square", 523 * Math.pow(2, s / 12), 523 * Math.pow(2, s / 12), 0.09, 0.1, i * 0.05));
  }

  levelUp() {
    if (this.pack === "wav") {
      if (this.playWav("grow", 1.02)) {
        this.bubbleBurst(0.35, 1.25);
        return;
      }
      if (!this.failedKeys.has("grow")) return;
    }
    [0, 7, 12, 19].forEach((s, i) => this.tone("triangle", 392 * Math.pow(2, s / 12), 392 * Math.pow(2, s / 12), 0.15, 0.25, i * 0.08));
  }

  /** Crystalline sparkle arpeggio for collecting giant pearls and power-up bubbles */
  powerup() {
    if (!this.ctx || this.muted) return;
    if (this.pack === "wav") {
      this.playWav("grow", 0.45, 1.28);
      [587.33, 739.99, 880, 1174.66].forEach((freq, i) => {
        this.tone("sine", freq, freq * 1.02, 0.18, 0.065, i * 0.05, this.wavBus);
      });
      this.bubbleBurst(0.32, 1.0);
      return;
    }
    [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((freq, i) => {
      this.tone("triangle", freq, freq * 1.03, 0.14, 0.14, i * 0.045);
      this.tone("sine", freq * 2, freq * 2, 0.12, 0.06, i * 0.045 + 0.015);
    });
    this.bubbleBurst(0.2, 0.9);
  }

  /** Resonant protective pop when Bubble Shield deflects a predator attack */
  shieldBreak() {
    if (!this.ctx || this.muted) return;
    if (this.pack === "wav") {
      this.tone("sine", 620, 180, 0.24, 0.16, 0, this.wavBus);
      this.playWav("eat", 0.55, 0.82);
      this.bubbleBurst(0.45, 1.2);
      return;
    }
    this.tone("sine", 780, 220, 0.28, 0.26);
    this.tone("triangle", 420, 960, 0.16, 0.18, 0.03);
    this.bubbleBurst(0.32, 1.1);
  }

  /** Wobbling underwater chime when poison dizziness kicks in */
  dizzy() {
    if (!this.ctx || this.muted) return;
    if (this.pack === "wav") {
      [440, 360, 510, 310, 460].forEach((freq, i) => {
        this.tone("sine", freq, freq * (i % 2 === 0 ? 0.85 : 1.14), 0.14, 0.09, i * 0.07, this.wavBus);
      });
      this.bubbleBurst(0.36, 1.0);
      return;
    }
    [520, 415, 620, 360, 560, 320].forEach((freq, i) => {
      this.tone("triangle", freq, freq * (i % 2 === 0 ? 0.86 : 1.15), 0.14, 0.18, i * 0.065);
    });
    this.bubbleBurst(0.24, 0.85);
  }

  /** Soft distant whale harmonic call in twilight & deep zones */
  private whaleCall() {
    if (!this.ctx || !this.ambBus || this.muted) return;
    const t = this.ctx.currentTime;
    const f0 = 135 + Math.random() * 25;
    for (const [mult, gain] of [[1, 0.11], [2, 0.04]] as const) {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(f0 * mult, t);
      o.frequency.exponentialRampToValueAtTime(f0 * 0.78 * mult, t + 1.4);
      o.frequency.exponentialRampToValueAtTime(f0 * 0.92 * mult, t + 2.4);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(gain, t + 0.45);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 2.55);
      o.connect(g);
      g.connect(this.ambBus);
      o.start(t);
      o.stop(t + 2.65);
    }
  }

  /** Soft distant submarine sonar ping with faint underwater echo */
  private sonarPing() {
    if (!this.ctx || !this.ambBus || this.muted) return;
    const t = this.ctx.currentTime;
    for (const [delay, peak] of [[0, 0.075], [0.42, 0.028]] as const) {
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = "sine";
      o.frequency.setValueAtTime(1180, t + delay);
      o.frequency.exponentialRampToValueAtTime(1152, t + delay + 0.35);
      g.gain.setValueAtTime(0.0001, t + delay);
      g.gain.linearRampToValueAtTime(peak, t + delay + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + delay + 0.55);
      o.connect(g);
      g.connect(this.ambBus);
      o.start(t + delay);
      o.stop(t + delay + 0.6);
    }
  }

  die() {
    if (!this.ctx || this.muted) return;
    if (this.pack === "wav") {
      this.playWav("bite3", 0.75, 0.68);
      this.tone("sine", 240, 45, 0.65, 0.24, 0, this.wavBus);
      this.bubbleBurst(0.45, 1.3);
      return;
    }
    this.tone("square", 600, 60, 0.7, 0.2);
    this.tone("triangle", 300, 40, 0.9, 0.3, 0.1);
  }

  /** Heavy underwater sea-mine detonation boom + shockwave rumble + bubble burst */
  explode() {
    if (!this.ctx || !this.master || this.muted) return;
    const t = this.ctx.currentTime;
    const out = this.pack === "wav" && this.wavBus ? this.wavBus : this.master;

    // 1. Sub-bass concussive pressure boom
    const sub = this.ctx.createOscillator();
    const subG = this.ctx.createGain();
    sub.type = "sine";
    sub.frequency.setValueAtTime(165, t);
    sub.frequency.exponentialRampToValueAtTime(24, t + 0.85);
    subG.gain.setValueAtTime(0.001, t);
    subG.gain.linearRampToValueAtTime(0.55, t + 0.015);
    subG.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    sub.connect(subG);
    subG.connect(out);
    sub.start(t);
    sub.stop(t + 0.92);

    // 2. Punchy mid-low metallic hull crack
    const punch = this.ctx.createOscillator();
    const punchG = this.ctx.createGain();
    punch.type = this.pack === "wav" ? "sine" : "triangle";
    punch.frequency.setValueAtTime(220, t);
    punch.frequency.exponentialRampToValueAtTime(34, t + 0.48);
    punchG.gain.setValueAtTime(0.4, t);
    punchG.gain.exponentialRampToValueAtTime(0.0001, t + 0.52);
    punch.connect(punchG);
    punchG.connect(out);
    punch.start(t);
    punch.stop(t + 0.54);

    // 3. Muffled underwater noise roar sweeping down into deep water rumble
    const len = Math.floor(this.ctx.sampleRate * 1.15);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      const k = 1 - i / len;
      d[i] = (Math.random() * 2 - 1) * Math.pow(k, 1.35);
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buf;

    const lp = this.ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.Q.value = 1.8;
    lp.frequency.setValueAtTime(1900, t);
    lp.frequency.exponentialRampToValueAtTime(105, t + 1.05);

    const nG = this.ctx.createGain();
    nG.gain.setValueAtTime(0.001, t);
    nG.gain.linearRampToValueAtTime(0.6, t + 0.012);
    nG.gain.exponentialRampToValueAtTime(0.0001, t + 1.12);

    noise.connect(lp);
    lp.connect(nG);
    nG.connect(out);
    noise.start(t);

    // 4. Sharp initial shrapnel snap
    const snap = this.ctx.createBufferSource();
    snap.buffer = buf;
    const bp = this.ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = 2.4;
    bp.frequency.setValueAtTime(920, t);
    const sG = this.ctx.createGain();
    sG.gain.setValueAtTime(0.32, t);
    sG.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
    snap.connect(bp);
    bp.connect(sG);
    sG.connect(out);
    snap.start(t);
    snap.stop(t + 0.24);

    // 5. Real bubble turbulence burst after detonation
    this.bubbleBurst(0.45, 1.3);
  }

  whoosh(isPlayer = true) {
    if (!this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    if (this.pack === "wav") {
      if (isPlayer) {
        if (now - this.lastDashWav < 0.09) return;
        this.lastDashWav = now;
        const played = this.playWav("dash", 0.96, 0.96 + Math.random() * 0.08);
        this.bubbleBurst(0.3, 1.0);
        if (played || !this.failedKeys.has("dash")) return;
      } else {
        if (now - this.lastDashWav < 0.18) return;
        this.lastDashWav = now;
        if (this.playWav("dash", 0.26, 1.08) || !this.failedKeys.has("dash")) return;
      }
    }

    const t = this.ctx.currentTime;
    const len = Math.floor(this.ctx.sampleRate * 0.35);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.5;
    f.frequency.setValueAtTime(400, t);
    f.frequency.exponentialRampToValueAtTime(2400, t + 0.3);
    const g = this.ctx.createGain();
    g.gain.value = isPlayer ? 0.4 : 0.16;
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t);
    this.tone("square", 220, 660, 0.12, isPlayer ? 0.06 : 0.02);
  }

  /** Short crisp bubble burst from bubbles1.wav / bubbles2.wav (offset past silent intro) */
  bubbleBurst(gain = 0.35, dur = 1.25): boolean {
    if (!this.ctx || this.pack !== "wav") return false;
    const now = this.ctx.currentTime;
    if (now - this.lastBubbleBurst < 0.72) return false;
    this.lastBubbleIdx = (this.lastBubbleIdx + 1) % BUBBLE_KEYS.length;
    const key = BUBBLE_KEYS[this.lastBubbleIdx];
    const off = 0.85 + Math.random() * 0.9;
    if (this.playEnvWav(key, gain, dur, 0.05, 0.4, 0.96 + Math.random() * 0.14, off, true)) {
      this.lastBubbleBurst = now;
      return true;
    }
    return false;
  }

  bubble() {
    if (this.bubbleBurst(0.34, 1.2)) return;
    if (this.pack === "wav") return;
    this.tone("sine", 400 + Math.random() * 400, 1200, 0.06, 0.06);
  }

  /** Crisp surface splash/wave swell when breaking or diving back into the ocean surface */
  surfaceSplash(vol = 0.42) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (now - this.lastSurfaceSplash < 0.32) return;
    if (this.pack === "wav") {
      this.lastWaveIdx = (this.lastWaveIdx + 1) % WAVE_KEYS.length;
      const key = WAVE_KEYS[this.lastWaveIdx];
      // Start at 1.02s so we land directly on the crest of wave1.wav / wave2.wav (past their 1.0s silent intro)
      const played = this.playEnvWav(key, Math.min(1.6, vol * 2.6), 1.45, 0.04, 0.55, 1.04 + Math.random() * 0.14, 1.02 + Math.random() * 0.35, true);
      if (played) {
        this.bubbleBurst(Math.min(0.65, vol * 1.1), 0.85);
        this.lastSurfaceSplash = now;
        this.lastWaveAmb = now;
        return;
      }
      if (!this.failedKeys.has(key)) return;
    }
    // Classic fallback crisp water splash burst
    this.lastSurfaceSplash = now;
    this.tone("triangle", 280, 120, 0.14, vol * 0.25);
  }

  /** Deep-water current swell when descending into or ascending out of a new depth zone */
  onZoneChange(deeper: boolean) {
    if (!this.ctx || this.pack !== "wav") return;
    const now = this.ctx.currentTime;
    if (now - this.lastWaterAmb < 3.5) return;
    const key: SfxKey = deeper ? "waterAmb1" : "waterAmb2";
    const rate = deeper ? 0.92 : 1.05;
    const off = deeper ? 2.4 : 1.1;
    if (this.playEnvWav(key, 0.52, deeper ? 6.0 : 4.2, 0.5, 1.4, rate, off, true)) {
      this.lastWaterAmb = now;
      this.nextWaterAmbDelay = 10 + Math.random() * 6;
    }
  }

  setSuck(on: boolean) {
    this.suckWanted = on;
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const useWavSuck = this.pack === "wav" && !!this.suckWavGain;
    if (this.suckWavGain) {
      this.suckWavGain.gain.setTargetAtTime(useWavSuck && on ? 0.78 : 0, t, 0.045);
    }
    if (this.suckGain && this.suckFilter) {
      if (this.pack === "wav") {
        // Never leak synthetic bandpass noise in WAV mode
        this.suckGain.gain.setTargetAtTime(0, t, 0.03);
      } else {
        this.suckGain.gain.setTargetAtTime(on ? 0.25 : 0, t, 0.05);
        this.suckFilter.frequency.setTargetAtTime(on ? 1400 : 500, t, 0.3);
      }
    }
  }

  /** Continuous frame-by-frame ocean ambience mixer (waterLoop, bubbleLoop, waterAmb1/2, wave1/2, bubbles1/2) */
  updateAmbience(state: AmbienceState) {
    if (!this.ctx || !this.ambBus) return;
    const now = this.ctx.currentTime;

    // 1. Continuous base underwater water loop (only active in WAV mode, clearly audible)
    if (this.waterLoopGain) {
      const depthFactor = Math.min(1, Math.max(0, state.playerY / 2300));
      const targetWater = this.pack === "wav" ? (state.inPlay ? 0.55 + depthFactor * 0.16 : 0.36) : 0;
      this.waterLoopGain.gain.setTargetAtTime(targetWater, now, 0.25);
    }

    // 2. Continuous subtle bubble loop during suction, dash boost, or near hydrothermal vents (WAV mode)
    if (this.bubbleLoopGain) {
      const suckAmt = state.inPlay && state.sucking ? 0.34 : 0;
      const boostAmt = state.inPlay && state.boosting ? 0.22 : 0;
      const ventAmt = Math.max(0, Math.min(1, state.ventProx)) * 0.32;
      const targetBubble = this.pack === "wav" ? Math.min(0.5, suckAmt + boostAmt + ventAmt) : 0;
      this.bubbleLoopGain.gain.setTargetAtTime(targetBubble, now, 0.08);
    }

    if (this.muted || this.pack !== "wav") return;

    // 3. Surface waves (wave1.wav / wave2.wav, offset past 1s quiet intro) when player/camera is near the ocean surface
    const nearSurface = state.playerY < 150 || state.camTop < 45;
    if (nearSurface && now - this.lastWaveAmb >= this.nextWaveDelay) {
      this.lastWaveIdx = (this.lastWaveIdx + 1) % WAVE_KEYS.length;
      const prox = Math.max(0.28, 1 - Math.max(0, state.playerY - 15) / 150);
      const gain = (state.inPlay ? 0.65 : 0.38) * prox;
      if (this.playEnvWav(WAVE_KEYS[this.lastWaveIdx], gain, 3.0, 0.35, 0.85, 0.97 + Math.random() * 0.06, 0.95, true)) {
        this.lastWaveAmb = now;
        this.nextWaveDelay = 4.2 + Math.random() * 2.4;
      }
    }

    // 4. Periodic deep-water current ambience swells (waterAmb1.wav / waterAmb2.wav)
    if (state.inPlay && now - this.lastWaterAmb >= this.nextWaterAmbDelay) {
      this.lastWaterAmbIdx = (this.lastWaterAmbIdx + 1) % WATER_AMB_KEYS.length;
      const key = WATER_AMB_KEYS[this.lastWaterAmbIdx];
      const off = key === "waterAmb1" ? 2.4 : 1.1;
      const maxDur = key === "waterAmb1" ? 8.5 : 4.2;
      if (this.playEnvWav(key, 0.48, maxDur, 0.7, 1.5, 0.95 + Math.random() * 0.08, off, true)) {
        this.lastWaterAmb = now;
        this.nextWaterAmbDelay = 10 + Math.random() * 6;
      }
    }

    // 5. Periodic gentle ambient underwater bubble streams (bubbles1.wav / bubbles2.wav)
    if (state.inPlay && now - this.lastAmbBubble >= this.nextAmbBubbleDelay) {
      this.lastBubbleIdx = (this.lastBubbleIdx + 1) % BUBBLE_KEYS.length;
      const key = BUBBLE_KEYS[this.lastBubbleIdx];
      const vent = Math.max(0, Math.min(1, state.ventProx));
      const gain = (key === "bubbles2" ? 0.42 : 0.28) + vent * 0.24;
      if (this.playEnvWav(key, gain, 2.8, 0.25, 0.75, 0.94 + Math.random() * 0.12, 0.85, true)) {
        this.lastAmbBubble = now;
        this.nextAmbBubbleDelay = 7.5 + Math.random() * 5.5;
      }
    }

    // 6. Occasional distant whale song & submarine sonar ping when swimming in twilight/deep waters
    if (state.inPlay && state.playerY > 360) {
      if (now - this.lastWhaleCall >= this.nextWhaleDelay) {
        this.whaleCall();
        this.lastWhaleCall = now;
        this.nextWhaleDelay = 22 + Math.random() * 14;
      }
      if (now - this.lastSonarPing >= this.nextSonarDelay) {
        this.sonarPing();
        this.lastSonarPing = now;
        this.nextSonarDelay = 17 + Math.random() * 12;
      }
    }
  }

  startMusic() {
    if (!this.ctx) return;
    const notes = [0, 7, 12, 7, 3, 10, 15, 10, 5, 12, 17, 12, 7, 14, 19, 14];
    const bass = [0, 0, -4, -4, -7, -7, -5, -5];
    let step = 0;
    const tick = () => {
      if (!this.ctx || !this.musicGain || this.muted || this.pack !== "classic") return;
      const n = notes[step % notes.length];
      const chord = Math.floor(step / 4) % 4;
      const shift = [0, -4, -7, -5][chord];
      this.tone("triangle", 330 * Math.pow(2, (n + shift) / 12), 330 * Math.pow(2, (n + shift) / 12), 0.18, 0.05, 0, this.musicGain);
      if (step % 2 === 0) {
        const b = bass[Math.floor(step / 2) % bass.length];
        this.tone("square", 82 * Math.pow(2, b / 12), 82 * Math.pow(2, b / 12), 0.2, 0.035, 0, this.musicGain);
      }
      step++;
    };
    this.musicTimer = window.setInterval(tick, 190);
  }
}

export const sfx = new Sfx();
