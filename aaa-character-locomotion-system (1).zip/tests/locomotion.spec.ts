import { expect, test } from "@playwright/test";

test("keyboard locomotion, camera and field guide work", async ({ page }) => {
  await page.goto("/");
  const state = page.locator(".motion-readout strong");
  await expect(state).toHaveText("IDLE", { timeout: 30_000 });

  await page.getByRole("button", { name: "CONTROLS" }).click();
  await expect(page.getByText("Walk / strafe")).toBeVisible();
  await page.getByRole("button", { name: "Close controls" }).click();

  await page.keyboard.down("Alt");
  await page.keyboard.down("a");
  await expect(state).toHaveText("WALK", { timeout: 20_000 });
  await page.keyboard.up("Alt");
  await page.keyboard.up("a");
  await expect(page.locator(".experience")).toHaveClass(/has-entered/);

  await page.keyboard.down("w");
  await page.keyboard.down("Shift");
  await expect(state).toHaveText("SPRINT", { timeout: 25_000 });
  await page.keyboard.up("w");
  await page.keyboard.up("Shift");
  await expect(state).toHaveText("IDLE", { timeout: 20_000 });
  await expect(page.locator(".foot-row i.on")).toHaveCount(2);
  await page.waitForTimeout(1500);
  await expect(state).toHaveText("IDLE");
  await expect(page.locator(".foot-row i.on")).toHaveCount(2);

  await page.keyboard.press("c");
  await expect(state).toHaveText("CROUCH IDLE", { timeout: 15_000 });
  await page.keyboard.down("s");
  await expect(state).toHaveText(/CROUCH (WALK|TURN)/, { timeout: 20_000 });
  await page.keyboard.up("s");
  await page.keyboard.press("r");
  await expect(state).toHaveText("IDLE", { timeout: 20_000 });

  await page.keyboard.press("Space");
  await expect(state).toHaveText(/JUMP START|IN THE AIR|LANDING/, { timeout: 15_000 });
  await expect(state).toHaveText("IDLE", { timeout: 20_000 });

  const backdrop = page.locator(".scene-backdrop");
  const before = await backdrop.evaluate((element) => element.getAttribute("style"));
  await page.mouse.move(510, 320);
  await page.mouse.down();
  await page.mouse.move(610, 320, { steps: 5 });
  await page.mouse.up();
  await expect.poll(() => backdrop.evaluate((element) => element.getAttribute("style")), { timeout: 10_000 }).not.toBe(before);
});

test("touch controls move and crouch the character", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  const state = page.locator(".motion-readout strong");
  await expect(state).toHaveText("IDLE", { timeout: 30_000 });
  await page.getByRole("button", { name: "CROUCH" }).click();
  await expect(state).toHaveText("CROUCH IDLE", { timeout: 15_000 });
  const pad = page.locator(".touch-pad");
  const bounds = await pad.boundingBox();
  if (!bounds) throw new Error("Touch joystick was not rendered");
  await page.mouse.move(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
  await page.mouse.down();
  await page.mouse.move(bounds.x + bounds.width / 2, bounds.y + 8);
  await expect(state).toHaveText(/CROUCH (WALK|TURN)/, { timeout: 20_000 });
  await page.mouse.up();
  await page.getByRole("button", { name: "JUMP" }).click();
  await expect(state).toHaveText(/JUMP START|IN THE AIR|LANDING/, { timeout: 15_000 });
});