# Kinetic Movement Lab

A browser-based third-person locomotion prototype. The character is driven by a procedural gait and two-bone foot IK, with acceleration, braking, speed-dependent turns, crouching, jump preparation, airborne motion, and landing recovery. The camera follows with damping and responds to crouching and landing.

## Run

```sh
npm install
npm run dev
```

Use `npm run build` for a production build.

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys | Move relative to the camera |
| Hold Alt | Walk; side and backward input strafe or backpedal |
| Hold Shift | Sprint |
| C | Toggle crouch |
| Space | Jump |
| Click and drag | Rotate the camera |
| R | Reset position and camera |

On a narrow touch screen, use the virtual stick and action buttons. A partial stick deflection walks more slowly; crouching also enables directional movement.

## Implementation Notes

`src/locomotion.ts` connects Three.js to [three-procedural-locomotion](https://github.com/PabloMesquida/three-procedural-locomotion), which supplies continuous gait blending, foot planning, IK, body mechanics, and jump phases. `src/upperBodyLayer.ts` phase-matches the model's idle, walk, and run clips to the procedural foot cycle, and fades them out for crouching and jumping. On stopping, the last step finishes before both feet settle. The live readout reflects the simulated movement state. The landscape is a visual backdrop over a flat movement test surface, not an expandable game world.

This is a playable prototype rather than a finished AAA animation set: its lower body is procedural rather than a bespoke full-body animation set, and it does not include a full collision or physics engine. The placeholder Vanguard character is from Mixamo/Adobe via the Three.js examples; review Mixamo's terms or replace it before distributing commercially. The procedural locomotion library and Three.js are MIT licensed. If the local model is unavailable, the app loads the Three.js example model as a fallback.