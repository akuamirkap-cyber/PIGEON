import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDownLeft, ArrowRight, ChevronDown, Crosshair, Mouse, RotateCcw, X } from "lucide-react";
import { createLocomotionScene, type MotionTelemetry, type SceneControls } from "./locomotion";

const defaultTelemetry: MotionTelemetry = {
  state: "IDLE",
  speed: 0,
  crouched: false,
  leftFoot: "PLANTED",
  rightFoot: "PLANTED",
  ready: false,
};

function BrandMark() {
  return (
    <svg className="brand-mark" viewBox="0 0 38 38" fill="none" aria-hidden="true">
      <path d="M19 2 35.2 30.2H2.8L19 2Z" stroke="currentColor" strokeWidth="1.4" />
      <path d="M19 10.3 28 26H10L19 10.3Z" stroke="currentColor" strokeWidth="1.4" />
      <path d="M19 19v16M12.5 30.2 19 19l6.5 11.2" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

function Key({ children, wide = false }: { children: React.ReactNode; wide?: boolean }) {
  return <span className={`key ${wide ? "key-wide" : ""}`}>{children}</span>;
}

function ControlItem({ keys, label }: { keys: React.ReactNode; label: string }) {
  return (
    <div className="control-item">
      <div className="key-group">{keys}</div>
      <span>{label}</span>
    </div>
  );
}

function TouchControls({ controls, crouched }: { controls: React.RefObject<SceneControls | null>; crouched: boolean }) {
  const pad = useRef<HTMLDivElement>(null);
  const [stick, setStick] = useState({ x: 0, y: 0 });
  const updateStick = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!pad.current) return;
    const bounds = pad.current.getBoundingClientRect();
    let x = (event.clientX - (bounds.left + bounds.width / 2)) / (bounds.width * 0.34);
    let y = (event.clientY - (bounds.top + bounds.height / 2)) / (bounds.height * 0.34);
    const length = Math.hypot(x, y);
    if (length > 1) {
      x /= length;
      y /= length;
    }
    setStick({ x, y });
    controls.current?.setMove(x, -y);
  };
  const releaseStick = () => {
    setStick({ x: 0, y: 0 });
    controls.current?.setMove(0, 0);
  };
  return (
    <div className="touch-controls">
      <div
        ref={pad}
        className="touch-pad"
        aria-label="Movement joystick"
        onPointerDown={(event) => {
          event.currentTarget.setPointerCapture(event.pointerId);
          updateStick(event);
        }}
        onPointerMove={(event) => {
          if (event.currentTarget.hasPointerCapture(event.pointerId)) updateStick(event);
        }}
        onPointerUp={releaseStick}
        onPointerCancel={releaseStick}
      >
        <div className="touch-stick" style={{ transform: `translate(${stick.x * 28}px, ${stick.y * 28}px)` }} />
      </div>
      <div className="touch-actions">
        <button className={crouched ? "touch-button active" : "touch-button"} onClick={() => controls.current?.toggleCrouch()}>CROUCH</button>
        <button
          className="touch-button"
          onPointerDown={(event) => {
            event.currentTarget.setPointerCapture(event.pointerId);
            controls.current?.setSprint(true);
          }}
          onPointerUp={() => controls.current?.setSprint(false)}
          onPointerCancel={() => controls.current?.setSprint(false)}
        >SPRINT</button>
        <button className="touch-button touch-jump" onClick={() => controls.current?.jump()}>JUMP</button>
      </div>
    </div>
  );
}

export default function App() {
  const sceneRef = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<SceneControls | null>(null);
  const [telemetry, setTelemetry] = useState(defaultTelemetry);
  const [entered, setEntered] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const onInteract = useCallback(() => setEntered(true), []);

  useEffect(() => {
    if (!sceneRef.current) return;
    try {
      const controls = createLocomotionScene(sceneRef.current, backdropRef.current, setTelemetry, onInteract);
      controlsRef.current = controls;
      return () => {
        controls.dispose();
        controlsRef.current = null;
      };
    } catch (error) {
      console.error("Unable to start the 3D scene:", error);
      setTelemetry((current) => ({ ...current, error: true }));
    }
  }, [onInteract]);

  const footOnGround = (phase: string) => phase === "PLANTED" || phase === "PLANT";

  return (
    <main className={`experience ${entered ? "has-entered" : ""}`}>
      <div ref={backdropRef} className="scene-backdrop" />
      <div ref={sceneRef} className="scene-canvas" />
      <div className="scene-shade" />
      <div className="scene-grain" />

      <div className="interface">
        <header className="topbar">
          <div className="brand" aria-label="Kinetic Movement Lab">
            <BrandMark />
            <div className="brand-name">
              <strong>KINETIC</strong>
              <span>MOVEMENT LAB</span>
            </div>
          </div>
          <div className="topbar-middle"><span /> AN EXPERIMENT IN MOVEMENT</div>
          <div className="topbar-actions">
            <div className="live-indicator"><i /> LIVE EXPERIENCE <span> / 01</span></div>
            <button className="header-link" onClick={() => setShowControls((value) => !value)} aria-expanded={showControls}>
              CONTROLS <ChevronDown size={13} className={showControls ? "chevron open" : "chevron"} />
            </button>
            <button className="icon-button reset-button" onClick={() => controlsRef.current?.reset()} aria-label="Reset character position" title="Reset character position">
              <RotateCcw size={17} />
            </button>
          </div>
        </header>

        {showControls && (
          <aside className="controls-popover">
            <div className="popover-heading"><span>FIELD GUIDE <small> / 01</small></span><button onClick={() => setShowControls(false)} aria-label="Close controls"><X size={16} /></button></div>
            <p>Get a feel for the movement.</p>
            <div><span>Move</span><b>W A S D / ARROWS</b></div>
            <div><span>Walk / strafe</span><b>HOLD ALT</b></div>
            <div><span>Sprint</span><b>HOLD SHIFT</b></div>
            <div><span>Crouch</span><b>C</b></div>
            <div><span>Jump</span><b>SPACE</b></div>
            <div><span>Look around</span><b>CLICK + DRAG</b></div>
            <div><span>Reset position</span><b>R</b></div>
          </aside>
        )}

        <section className="hero-copy" aria-label="Introduction">
          <div className="eyebrow"><span className="eyebrow-line" /> 01 <span className="eyebrow-slash">/</span> THE MOVEMENT STUDY</div>
          <h1>KINETIC<br /><span>BY NATURE.</span></h1>
          <p>A little more human, with every step.<br />An exploration of movement and momentum.</p>
          <button className="enter-button" onClick={() => setEntered(true)}>
            <span>{entered ? "YOU'RE IN THE FIELD" : "ENTER THE FIELD"}</span>
            <span className="enter-arrow"><ArrowRight size={18} strokeWidth={1.5} /></span>
          </button>
          <div className="hero-note"><span /> INTERACTIVE CHARACTER EXPERIENCE</div>
        </section>

        <div className="world-label">
          <div className="world-label-line" />
          <span>THE WILDS</span>
          <small>FIELD STUDY / 01</small>
        </div>

        <div className="look-hint"><Mouse size={19} strokeWidth={1.3} /><span>CLICK + DRAG<br /><b>TO LOOK AROUND</b></span></div>

        <aside className="motion-readout">
          <div className="readout-heading"><Crosshair size={14} strokeWidth={1.5} /> <span>LIVE MOTION</span></div>
          <div className="readout-rule" />
          <span className="readout-label">CURRENT STATE</span>
          <strong aria-live="polite">{telemetry.error ? "UNAVAILABLE" : telemetry.ready ? telemetry.state : "LOADING"}</strong>
          <div className="speed-row"><span>SPEED</span><b>{telemetry.speed.toFixed(1)} <small>M/S</small></b></div>
          <div className="speed-track"><span style={{ width: `${Math.min((telemetry.speed / 5) * 100, 100)}%` }} /></div>
          <div className="foot-row"><span>FOOT CONTACT</span><div><i className={footOnGround(telemetry.leftFoot) ? "on" : ""} /> L <i className={footOnGround(telemetry.rightFoot) ? "on" : ""} /> R</div></div>
        </aside>

        <footer className="bottom-hud">
          <div className="controls-title"><span>TAKE CONTROL</span><small>THE BASICS <ArrowDownLeft size={11} /></small></div>
          <div className="controls-list">
            <ControlItem keys={<><Key>W</Key><Key>A</Key><Key>S</Key><Key>D</Key></>} label="MOVE" />
            <ControlItem keys={<Key wide>SHIFT</Key>} label="SPRINT" />
            <ControlItem keys={<Key>C</Key>} label="CROUCH" />
            <ControlItem keys={<Key wide>SPACE</Key>} label="JUMP" />
            <ControlItem keys={<Key wide>ALT</Key>} label="WALK" />
          </div>
          <div className="bottom-index"><span>CHARACTER CONTROLLER</span><strong>01 <i>/</i> 01</strong></div>
        </footer>
        <TouchControls controls={controlsRef} crouched={telemetry.crouched} />
      </div>
      {telemetry.error && <div className="error-message">The character could not be loaded. Please refresh to try again.</div>}
    </main>
  );
}