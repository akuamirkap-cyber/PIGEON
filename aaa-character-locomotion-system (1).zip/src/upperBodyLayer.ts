import * as THREE from "three";
import { clone as cloneSkeleton } from "three/addons/utils/SkeletonUtils.js";
import type { ProceduralHuman } from "three-procedural-locomotion";

const upperBodyStrength: Record<string, number> = {
  mixamorigSpine: 0.12,
  mixamorigSpine1: 0.18,
  mixamorigSpine2: 0.24,
  mixamorigLeftShoulder: 0.45,
  mixamorigRightShoulder: 0.45,
  mixamorigLeftArm: 0.82,
  mixamorigRightArm: 0.82,
  mixamorigLeftForeArm: 0.82,
  mixamorigRightForeArm: 0.82,
  mixamorigLeftHand: 0.55,
  mixamorigRightHand: 0.55,
};

/** Blend the character's authored upper-body motion over the planted IK legs. */
export function createUpperBodyLayer(model: THREE.Object3D, clips: THREE.AnimationClip[]) {
  const reference = cloneSkeleton(model);
  const mixer = new THREE.AnimationMixer(reference);
  const findClip = (name: string) => {
    const source = clips.find((clip) => clip.name === name);
    if (!source) return null;
    const tracks = source.tracks.filter((track) => {
      if (!track.name.endsWith(".quaternion")) return false;
      return Object.prototype.hasOwnProperty.call(upperBodyStrength, track.name.slice(0, -".quaternion".length));
    });
    return new THREE.AnimationClip(`${name} upper body`, source.duration, tracks);
  };
  const idleClip = findClip("Idle");
  const walkClip = findClip("Walk");
  const runClip = findClip("Run");
  if (!idleClip || !walkClip || !runClip) return null;

  const idle = mixer.clipAction(idleClip).play();
  const walk = mixer.clipAction(walkClip).play();
  const run = mixer.clipAction(runClip).play();
  walk.paused = true;
  run.paused = true;
  const links = Object.entries(upperBodyStrength).flatMap(([name, strength]) => {
    const target = model.getObjectByName(name);
    const animated = reference.getObjectByName(name);
    return target && animated ? [{ target, animated, strength }] : [];
  });

  let idleWeight = 1;
  let walkWeight = 0;
  let runWeight = 0;
  let influence = 1;
  return {
    update(delta: number, human: ProceduralHuman) {
      const speed = human.speed / human.speedScale;
      const moving = THREE.MathUtils.smoothstep(speed, 0.08, 0.85);
      const running = THREE.MathUtils.smoothstep(speed, 1.65, 2.8);
      const blend = 1 - Math.exp(-5.5 * delta);
      idleWeight = THREE.MathUtils.lerp(idleWeight, 1 - moving, blend);
      walkWeight = THREE.MathUtils.lerp(walkWeight, moving * (1 - running), blend);
      runWeight = THREE.MathUtils.lerp(runWeight, moving * running, blend);
      idle.setEffectiveWeight(idleWeight);
      walk.setEffectiveWeight(walkWeight);
      run.setEffectiveWeight(runWeight);

      // The source clips are sampled at left-foot contact so arms stay opposite the IK legs.
      const phase = human.locomotion.gait.footPhase("left");
      walk.time = ((phase + 0.25) % 1) * walkClip.duration;
      run.time = ((phase + 0.31) % 1) * runClip.duration;
      mixer.update(delta);

      const clearForAction = human.targetCrouch < 0.5 && human.jumpPhase === "GROUNDED";
      influence = THREE.MathUtils.lerp(influence, clearForAction ? 1 : 0, 1 - Math.exp(-(clearForAction ? 5 : 10) * delta));
      for (const { target, animated, strength } of links) {
        target.quaternion.slerp(animated.quaternion, strength * influence);
      }
    },
    dispose() {
      mixer.stopAllAction();
      mixer.uncacheRoot(reference);
    },
  };
}