import * as THREE from "three";
import { GLTFLoader, type GLTF } from "three/addons/loaders/GLTFLoader.js";
import {
  createProceduralHuman,
  mixamoMapping,
  type ProceduralHuman,
} from "three-procedural-locomotion";
import { createUpperBodyLayer } from "./upperBodyLayer";

export type MotionTelemetry = {
  state: string;
  speed: number;
  crouched: boolean;
  leftFoot: string;
  rightFoot: string;
  ready: boolean;
  error?: boolean;
};

export type SceneControls = {
  reset: () => void;
  jump: () => void;
  toggleCrouch: () => void;
  setMove: (x: number, y: number) => void;
  setSprint: (value: boolean) => void;
  dispose: () => void;
};

const initialTelemetry: MotionTelemetry = {
  state: "IDLE",
  speed: 0,
  crouched: false,
  leftFoot: "PLANTED",
  rightFoot: "PLANTED",
  ready: false,
};

const damp = (current: number, target: number, rate: number, delta: number) =>
  THREE.MathUtils.lerp(current, target, 1 - Math.exp(-rate * delta));

function addDriftingSnow(scene: THREE.Scene) {
  const count = 130;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    positions[i * 3] = (Math.random() - 0.5) * 22;
    positions[i * 3 + 1] = Math.random() * 8;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 22;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const snow = new THREE.Points(
    geometry,
    new THREE.PointsMaterial({
      color: 0xe6eee9,
      size: 0.035,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
      sizeAttenuation: true,
    }),
  );
  scene.add(snow);
  return snow;
}

export function createLocomotionScene(
  container: HTMLDivElement,
  backdrop: HTMLDivElement | null,
  onTelemetry: (data: MotionTelemetry) => void,
  onInteract: () => void,
): SceneControls {
  let disposed = false;
  let human: ProceduralHuman | null = null;
  let model: THREE.Object3D | null = null;
  let upperBody: ReturnType<typeof createUpperBodyLayer> = null;
  let frame = 0;
  let lastTime = 0;
  let lastTelemetry = 0;
  let elapsed = 0;
  let impact = 0;
  let mobileX = 0;
  let mobileY = 0;
  let mobileSprint = false;
  let wasMoving = false;
  let stopTime = 0;
  let yaw = 0;
  let desiredYaw = 0;
  let pitch = 0.2;
  let desiredPitch = 0.2;
  let dragging = false;
  let lastPointerX = 0;
  let lastPointerY = 0;
  let precisionMode = false;
  let steeringRequested = false;
  let settledStop = false;
  const precisionFacing = new THREE.Vector3(0, 0, -1);
  const airSteer = new THREE.Vector3();
  const airTarget = new THREE.Vector3();
  const airDisplacement = new THREE.Vector3();
  const keys = new Set<string>();
  const currentTelemetry = { ...initialTelemetry };

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
  const gl = renderer.getContext();
  const rendererInfo = gl.getExtension("WEBGL_debug_renderer_info");
  const rendererName = rendererInfo ? String(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL)) : "";
  const softwareRenderer = /swiftshader|llvmpipe|software/i.test(rendererName);
  renderer.setPixelRatio(softwareRenderer ? 0.7 : Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.16;
  renderer.shadowMap.enabled = false;
  renderer.domElement.setAttribute("aria-label", "Interactive third-person character scene");
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(43, container.clientWidth / container.clientHeight, 0.1, 400);
  camera.position.set(-0.7, 2.25, 5.4);
  const cameraLook = new THREE.Vector3(-0.7, 1.12, 0);
  camera.lookAt(cameraLook);

  scene.add(new THREE.HemisphereLight(0xd9e6e8, 0x4b4e43, 2.0));
  const sunlight = new THREE.DirectionalLight(0xfff5df, 2.2);
  sunlight.position.set(-4, 9, 5);
  scene.add(sunlight);
  scene.add(sunlight.target);

  const groundTexture = new THREE.TextureLoader().load("/images/frost-ground-light.jpg");
  groundTexture.colorSpace = THREE.SRGBColorSpace;
  groundTexture.wrapS = THREE.RepeatWrapping;
  groundTexture.wrapT = THREE.RepeatWrapping;
  groundTexture.repeat.set(100, 100);
  groundTexture.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 2);
  const groundMaterial = new THREE.MeshBasicMaterial({
    map: groundTexture,
    color: 0xb8c0ba,
    transparent: true,
    depthWrite: false,
  });
  const contactPosition = { value: new THREE.Vector3() };
  const contactStrength = { value: 0 };
  // Fade the playable ground into the distant photographic landscape.
  groundMaterial.onBeforeCompile = (shader) => {
    shader.uniforms.uContactPosition = contactPosition;
    shader.uniforms.uContactStrength = contactStrength;
    shader.vertexShader = `varying vec3 vTerrainWorld;\n${shader.vertexShader}`;
    shader.vertexShader = shader.vertexShader.replace(
      "#include <worldpos_vertex>",
      "#include <worldpos_vertex>\nvTerrainWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;",
    );
    shader.fragmentShader = `varying vec3 vTerrainWorld;\nuniform vec3 uContactPosition;\nuniform float uContactStrength;\n${shader.fragmentShader}`;
    shader.fragmentShader = shader.fragmentShader.replace(
      "#include <dithering_fragment>",
      "vec2 contactDelta = vTerrainWorld.xz - uContactPosition.xz;\nfloat contact = exp(-dot(contactDelta, contactDelta) * 4.0) * uContactStrength;\ngl_FragColor.rgb *= 1.0 - contact;\ngl_FragColor.a *= 0.9 * (1.0 - smoothstep(5.0, 13.0, distance(vTerrainWorld.xz, cameraPosition.xz)));\n#include <dithering_fragment>",
    );
  };
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);
  const snow = addDriftingSnow(scene);

  const loader = new GLTFLoader();
  const characterLoaded = (gltf: GLTF) => {
    if (disposed) return;
    model = gltf.scene;
    model.updateMatrixWorld(true);

    // Orient the character away from the initial camera, using its actual toe direction.
    const foot = model.getObjectByName("mixamorigLeftFoot");
    const toe = model.getObjectByName("mixamorigLeftToeBase");
    if (foot && toe) {
      const forward = toe.getWorldPosition(new THREE.Vector3()).sub(foot.getWorldPosition(new THREE.Vector3()));
      forward.y = 0;
      if (forward.lengthSq() > 0.0001) {
        model.rotation.y += Math.PI - Math.atan2(forward.x, forward.z);
      }
    }
    model.updateMatrixWorld(true);
    model.traverse((object) => {
      if ((object as THREE.Mesh).isMesh) {
        object.castShadow = true;
        object.receiveShadow = true;
      }
    });
    scene.add(model);

    try {
      human = createProceduralHuman({
        model,
        mapping: mixamoMapping,
        ground: [ground],
        preset: "athletic",
        config: {
          walkSpeed: 1.35,
          jogSpeed: 2.8,
          runSpeed: 5,
          acceleration: 3.1,
          deceleration: 3.4,
          speedEasing: 0.3,
          stepWidth: 0.22,
          stepLength: 0.74,
          stepHeight: 0.04,
          jogStepLength: 1.15,
          jogStepHeight: 0.12,
          jogLean: 7,
          jogArmSwing: 22,
          runStepLength: 1.6,
          runStepHeight: 0.22,
          runStepFrequency: 3.25,
          runLean: 12,
          runArmSwing: 34,
          runElbowBend: 82,
          runElbowSwingBend: 6,
          runArmInward: 12,
          runArmAbduction: 7,
          heelLiftAngle: 40,
          heelStrikeAngle: 12,
          runHeelLiftAngle: 38,
          pelvisRotation: 3.5,
          pelvisObliquity: 2.5,
          lateralShift: 0.17,
          shoulderTilt: 0.3,
          idleArmAbduction: 7,
          idleElbowBend: 12,
          armSwing: 13,
          armSwingDamping: 0.9,
          armInertia: 1.1,
          trunkDamping: 0.85,
          pelvisDamping: 0.85,
          headStabilization: 0.92,
          crouchDepth: 0.4,
          crouchLean: 25,
        },
      });
      const character = human;
      upperBody = createUpperBodyLayer(model, gltf.animations);
      // The controller's ledge-facing layer also gives slow movement a true strafe/backpedal.
      const locomotion = human.locomotion as unknown as {
        updateLedge: (dt: number) => boolean;
        updateGaitMode: (dt: number) => void;
        setGaitMode: (mode: "idle" | "walk") => void;
        body: typeof human.locomotion.body;
        gait: typeof human.locomotion.gait;
        feet: typeof human.locomotion.feet;
      };
      const updateLedge = locomotion.updateLedge.bind(locomotion);
      const facingAxis = new THREE.Vector3();
      locomotion.updateLedge = (dt) => {
        const stopped = updateLedge(dt);
        if (precisionMode) {
          const body = locomotion.body;
          const travel = body.state.travel;
          const angle = Math.atan2(facingAxis.crossVectors(travel, precisionFacing).y, travel.dot(precisionFacing));
          const current = body.state.facingOffset;
          body.facingTarget = current + Math.atan2(Math.sin(angle - current), Math.cos(angle - current));
        }
        return stopped;
      };
      const updateGaitMode = locomotion.updateGaitMode.bind(locomotion);
      // Finish the last step, then keep both feet planted instead of stepping in place.
      locomotion.updateGaitMode = (dt) => {
        const canSettle = !steeringRequested && !character.airborne && character.jumpPhase === "GROUNDED" && !locomotion.body.isTurning();
        if (!canSettle) {
          settledStop = false;
          updateGaitMode(dt);
          return;
        }
        if (settledStop && locomotion.body.state.speed < 0.1) {
          if (locomotion.gait.mode !== "idle") locomotion.setGaitMode("idle");
          return;
        }
        updateGaitMode(dt);
        const left = locomotion.feet.left.position;
        const right = locomotion.feet.right.position;
        const stanceWidth = Math.hypot(left.x - right.x, left.z - right.z);
        if (locomotion.body.state.speed < 0.1 && locomotion.gait.doubleSupport() && stanceWidth < 0.5) {
          locomotion.setGaitMode("idle");
          settledStop = true;
        }
      };
      human.on("land", ({ impactSpeed }) => {
        impact = Math.min(impactSpeed * 0.012, 0.07);
      });
      currentTelemetry.ready = true;
      onTelemetry({ ...currentTelemetry });
    } catch (error) {
      console.error("Unable to initialize the character rig:", error);
      currentTelemetry.error = true;
      onTelemetry({ ...currentTelemetry });
    }
  };
  const characterFailed = (error: unknown) => {
    if (disposed) return;
    console.error("Unable to load the character:", error);
    currentTelemetry.error = true;
    onTelemetry({ ...currentTelemetry });
  };
  loader.load("/models/soldier.glb", characterLoaded, undefined, () => {
    if (!disposed) loader.load("https://threejs.org/examples/models/gltf/Soldier.glb", characterLoaded, undefined, characterFailed);
  });

  const direction = new THREE.Vector3();
  const axis = new THREE.Vector3();
  const right = new THREE.Vector3();
  const targetPosition = new THREE.Vector3();
  const desiredLook = new THREE.Vector3();

  const reset = () => {
    keys.clear();
    mobileX = 0;
    mobileY = 0;
    mobileSprint = false;
    desiredYaw = 0;
    desiredPitch = 0.2;
    impact = 0;
    precisionMode = false;
    steeringRequested = false;
    settledStop = false;
    airSteer.set(0, 0, 0);
    if (human && model) {
      model.position.set(0, 0, 0);
      human.targetCrouch = 0;
      human.reset();
    }
    onInteract();
  };
  const jump = () => {
    if (human) human.jump();
    onInteract();
  };
  const toggleCrouch = () => {
    if (human) human.targetCrouch = human.targetCrouch > 0.5 ? 0 : 1;
    onInteract();
  };

  const keyDown = (event: KeyboardEvent) => {
    const active = ["KeyW", "KeyA", "KeyS", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "ShiftLeft", "ShiftRight", "AltLeft", "AltRight", "Space", "KeyC", "KeyR"];
    if (!active.includes(event.code)) return;
    event.preventDefault();
    keys.add(event.code);
    if (!event.repeat) {
      if (event.code === "Space") jump();
      else if (event.code === "KeyC") toggleCrouch();
      else if (event.code === "KeyR") reset();
      else onInteract();
    }
  };
  const keyUp = (event: KeyboardEvent) => keys.delete(event.code);
  const clearKeys = () => {
    keys.clear();
    mobileX = 0;
    mobileY = 0;
    mobileSprint = false;
  };
  const pointerDown = (event: PointerEvent) => {
    if (event.pointerType === "touch" && event.isPrimary === false) return;
    dragging = true;
    lastPointerX = event.clientX;
    lastPointerY = event.clientY;
    renderer.domElement.setPointerCapture(event.pointerId);
    renderer.domElement.classList.add("is-dragging");
  };
  const pointerMove = (event: PointerEvent) => {
    if (!dragging) return;
    desiredYaw -= (event.clientX - lastPointerX) * 0.005;
    desiredPitch = THREE.MathUtils.clamp(desiredPitch + (event.clientY - lastPointerY) * 0.004, -0.05, 0.7);
    lastPointerX = event.clientX;
    lastPointerY = event.clientY;
    onInteract();
  };
  const pointerUp = () => {
    dragging = false;
    renderer.domElement.classList.remove("is-dragging");
  };
  const resize = () => {
    const width = container.clientWidth;
    const height = container.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  };
  window.addEventListener("keydown", keyDown);
  window.addEventListener("keyup", keyUp);
  window.addEventListener("blur", clearKeys);
  window.addEventListener("resize", resize);
  renderer.domElement.addEventListener("pointerdown", pointerDown);
  renderer.domElement.addEventListener("pointermove", pointerMove);
  renderer.domElement.addEventListener("pointerup", pointerUp);
  renderer.domElement.addEventListener("pointercancel", pointerUp);

  function tick(time: number) {
    if (disposed) return;
    frame = requestAnimationFrame(tick);
    const delta = lastTime ? Math.min((time - lastTime) / 1000, 0.15) : 0;
    lastTime = time;
    elapsed += delta;
    yaw = damp(yaw, desiredYaw, 7, delta);
    pitch = damp(pitch, desiredPitch, 7, delta);

    if (human) {
      const x = THREE.MathUtils.clamp(
        Number(keys.has("KeyD") || keys.has("ArrowRight")) - Number(keys.has("KeyA") || keys.has("ArrowLeft")) + mobileX,
        -1,
        1,
      );
      const z = THREE.MathUtils.clamp(
        Number(keys.has("KeyW") || keys.has("ArrowUp")) - Number(keys.has("KeyS") || keys.has("ArrowDown")) + mobileY,
        -1,
        1,
      );
      const moving = Math.hypot(x, z) > 0.1;
      steeringRequested = moving;
      const sprinting = keys.has("ShiftLeft") || keys.has("ShiftRight") || mobileSprint;
      const walking = keys.has("AltLeft") || keys.has("AltRight");
      const gentleStick = Math.hypot(mobileX, mobileY) > 0.1 && Math.hypot(mobileX, mobileY) < 0.55;
      if (moving) {
        direction.set(-Math.sin(yaw) * z + Math.cos(yaw) * x, 0, -Math.cos(yaw) * z - Math.sin(yaw) * x).normalize();
        precisionMode = (walking || gentleStick || human.targetCrouch > 0.5) && !sprinting;
        if (precisionMode) precisionFacing.set(-Math.sin(yaw), 0, -Math.cos(yaw));
        const forward = human.locomotion.body.state.travel;
        const turn = Math.atan2(axis.crossVectors(forward, direction).y, forward.dot(direction));
        human.targetHeading = human.heading + turn;
        human.targetSpeed = (sprinting ? human.config.runSpeed : walking ? human.config.walkSpeed : 3.3) * human.speedScale * Math.min(1, Math.hypot(x, z));
        stopTime = 0;
      } else {
        human.targetSpeed = 0;
        if (wasMoving) stopTime = 0.5;
      }
      wasMoving = moving;
      stopTime = Math.max(0, stopTime - delta);
      const wasAirborne = human.airborne;
      if (wasAirborne && moving) {
        airTarget.copy(direction).multiplyScalar(Math.max(1.5, Math.min(human.speed, 3.5))).sub(human.velocity);
        airSteer.lerp(airTarget, 1 - Math.exp(-1.8 * delta));
      } else if (!wasAirborne) {
        airSteer.set(0, 0, 0);
      }
      human.update(delta);
      if (wasAirborne && human.airborne) {
        human.shiftOrigin(airDisplacement.copy(airSteer).multiplyScalar(delta * 0.42));
      }
      upperBody?.update(delta, human);
      const breathing = Math.sin(elapsed * 1.7) * 0.009 * Math.max(0.15, 1 - human.speed / 2);
      human.rig.chest?.rotateX(breathing);

      const position = human.position;
      const crouch = human.crouch;
      const speed = human.speed;
      const isNarrow = window.innerWidth < 700;
      const distance = (isNarrow ? 6.1 : 5.25) + Math.min(speed / 5, 1) * 0.22;
      right.set(Math.cos(yaw), 0, -Math.sin(yaw));
      const shoulder = isNarrow ? -0.48 : -0.72;
      const lookHeight = (isNarrow ? 1.28 : 1.1) - crouch * 0.3;
      const verticalBob = Math.sin(elapsed * (speed > 2 ? 8 : 5)) * Math.min(speed * 0.0024, 0.012);
      desiredLook.copy(position).addScaledVector(right, shoulder);
      desiredLook.y += lookHeight + verticalBob - impact;
      targetPosition.copy(desiredLook).add(new THREE.Vector3(
        Math.sin(yaw) * Math.cos(pitch) * distance,
        Math.sin(pitch) * distance,
        Math.cos(yaw) * Math.cos(pitch) * distance,
      ));
      camera.position.lerp(targetPosition, 1 - Math.exp(-(speed > 3.5 ? 3.8 : 5.5) * delta));
      cameraLook.lerp(desiredLook, 1 - Math.exp(-5.5 * delta));
      camera.lookAt(cameraLook);
      const desiredFov = 43 + Math.max(0, speed - 3) * 0.8;
      camera.fov = damp(camera.fov, desiredFov, 2.2, delta);
      camera.updateProjectionMatrix();
      impact = damp(impact, 0, 5, delta);

      const airHeight = Math.max(0, position.y);
      contactPosition.value.copy(position);
      contactStrength.value = Math.max(0.08, 0.6 - airHeight * 0.42);
      sunlight.position.set(position.x - 4, 9, position.z + 5);
      sunlight.target.position.set(position.x, 0, position.z);
      snow.position.set(position.x, 0, position.z);
      snow.rotation.y = elapsed * 0.005;

      if (time - lastTelemetry > 110) {
        let state = "IDLE";
        if (human.jumpPhase === "TAKEOFF") state = "JUMP START";
        else if (human.jumpPhase === "AIRBORNE") state = "IN THE AIR";
        else if (human.jumpPhase === "LANDING") state = "LANDING";
        else if (crouch > 0.4) state = speed > 0.15 ? Math.abs(human.locomotion.body.state.turnRate) > 0.5 ? "CROUCH TURN" : "CROUCH WALK" : "CROUCH IDLE";
        else if (!moving && speed > 0.18) state = "STOPPING";
        else if (!moving && (stopTime > 0 || human.gaitMode !== "idle")) state = "RECOVERY";
        else if (speed > 4.1 * human.speedScale) state = "SPRINT";
        else if (speed > 2.9 * human.speedScale) state = "RUN";
        else if (speed > 1.75 * human.speedScale) state = "JOG";
        else if (speed > 0.12) state = "WALK";
        else if (moving && Math.abs(human.locomotion.body.state.angularVelocity) > 0.1) state = human.locomotion.body.state.angularVelocity > 0 ? "TURN LEFT" : "TURN RIGHT";
        currentTelemetry.state = state;
        currentTelemetry.speed = speed;
        currentTelemetry.crouched = human.targetCrouch > 0.5;
        currentTelemetry.leftFoot = human.footPhase("left");
        currentTelemetry.rightFoot = human.footPhase("right");
        onTelemetry({ ...currentTelemetry });
        lastTelemetry = time;
      }
    } else camera.lookAt(cameraLook);
    if (backdrop) {
      backdrop.style.transform = `scale(1.09) translate3d(${Math.sin(yaw) * -2.5}%, ${Math.sin(pitch - 0.2) * 1.5}%, 0)`;
    }
    renderer.render(scene, camera);
  }
  frame = requestAnimationFrame(tick);

  return {
    reset,
    jump,
    toggleCrouch,
    setMove: (x, y) => {
      mobileX = x;
      mobileY = y;
      if (Math.abs(x) + Math.abs(y) > 0.1) onInteract();
    },
    setSprint: (value) => {
      mobileSprint = value;
      if (value) onInteract();
    },
    dispose: () => {
      disposed = true;
      cancelAnimationFrame(frame);
      window.removeEventListener("keydown", keyDown);
      window.removeEventListener("keyup", keyUp);
      window.removeEventListener("blur", clearKeys);
      window.removeEventListener("resize", resize);
      renderer.domElement.removeEventListener("pointerdown", pointerDown);
      renderer.domElement.removeEventListener("pointermove", pointerMove);
      renderer.domElement.removeEventListener("pointerup", pointerUp);
      renderer.domElement.removeEventListener("pointercancel", pointerUp);
      upperBody?.dispose();
      human?.dispose();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
      groundTexture.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    },
  };
}