import * as THREE from 'three';
import { CharacterConfig, DebugTelemetry } from '../config/GameConfig';
import { soundEngine } from '../fps/audio';
import { AudioSystem } from '../systems/AudioSystem';
import { CharacterController } from '../systems/CharacterController';
import { InputManager } from '../systems/InputManager';
import { SnowTerrain } from '../world/SnowTerrain';

export class SimulationEngine {
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private sunLight: THREE.DirectionalLight;
  private sunTarget = new THREE.Object3D();

  public readonly terrain: SnowTerrain;
  public readonly audio: AudioSystem;
  public readonly character: CharacterController;
  public readonly input: InputManager;

  private config: CharacterConfig;
  private rafId = 0;
  private lastTime = performance.now();
  private telemetryTimer = 0;
  private onTelemetryUpdate: (telemetry: DebugTelemetry) => void;

  constructor(
    container: HTMLElement,
    initialConfig: CharacterConfig,
    onTelemetryUpdate: (telemetry: DebugTelemetry) => void
  ) {
    this.config = { ...initialConfig };
    this.onTelemetryUpdate = onTelemetryUpdate;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#9fd6ff');
    this.scene.fog = new THREE.FogExp2('#b8e2ff', 0.0085);

    const hemiLight = new THREE.HemisphereLight(0xe0f4ff, 0x93b4d4, 1.05);
    this.scene.add(hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff8eb, 1.72);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.set(2048, 2048);
    this.sunLight.shadow.camera.near = 1;
    this.sunLight.shadow.camera.far = 65;
    const d = 24;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0004;

    this.scene.add(this.sunTarget);
    this.sunLight.target = this.sunTarget;
    this.scene.add(this.sunLight);

    const rimLight = new THREE.DirectionalLight(0xbae6fd, 0.52);
    rimLight.position.set(-12, 10, -15);
    this.scene.add(rimLight);

    this.audio = new AudioSystem();
    this.terrain = new SnowTerrain(this.scene);
    const aspect = container.clientWidth / Math.max(1, container.clientHeight);
    this.character = new CharacterController(this.scene, this.terrain, aspect, initialConfig, this.audio);
    this.input = new InputManager(this.renderer.domElement, () => {
      this.audio.unlock();
      soundEngine.unlock();
    });

    window.addEventListener('resize', this.onResize);
    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  public updateConfig(nextConfig: CharacterConfig): void {
    this.config = { ...nextConfig };
  }

  public restartMatch(): void {
    this.audio.unlock();
    soundEngine.unlock();
    this.character.restartMatch(this.terrain);
  }

  private onResize = (): void => {
    const parent = this.renderer.domElement.parentElement;
    if (!parent) return;
    const w = parent.clientWidth;
    const h = Math.max(1, parent.clientHeight);
    this.renderer.setSize(w, h);
    this.character.onResize(w / h);
  };

  private loop = (now: number): void => {
    this.rafId = requestAnimationFrame(this.loop);

    const rawDt = (now - this.lastTime) * 0.001;
    this.lastTime = now;
    const dt = Math.min(0.05, Math.max(0.001, rawDt));

    this.character.update(dt, this.input, this.config, this.terrain);
    this.terrain.update(dt, this.character.movement.position);

    const pos = this.character.movement.position;
    this.sunTarget.position.set(pos.x, pos.y, pos.z);
    this.sunLight.position.set(pos.x + 14, pos.y + 22, pos.z - 12);

    // FPS: world pass + viewmodel pass (+ live sniper scope). Ragdoll: third-person chase cam.
    this.character.renderFrame(this.renderer);

    this.telemetryTimer += dt;
    if (this.telemetryTimer >= 0.05) {
      this.telemetryTimer = 0;
      this.onTelemetryUpdate(this.character.getTelemetry(this.input.isPointerLocked, this.config));
    }

    this.input.endFrame();
  };

  public dispose(): void {
    cancelAnimationFrame(this.rafId);
    window.removeEventListener('resize', this.onResize);
    this.input.dispose();
    this.character.fps.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
