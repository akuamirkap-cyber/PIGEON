import * as THREE from 'three';
import { WeaponType } from '../config/GameConfig';
import { CharacterRig } from './CharacterRig';

interface WeaponModel {
  group: THREE.Group;
  gripR: THREE.Object3D;
  gripL: THREE.Object3D;
  muzzle: THREE.Object3D;
  mountPos: THREE.Vector3;
  rocketVisual?: THREE.Group;
}

const Z_AXIS = new THREE.Vector3(0, 0, 1);

function stdMat(color: number, rough = 0.42, metal = 0.08): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
}

function glowMat(color: number): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color,
    emissive: color,
    emissiveIntensity: 0.9,
    roughness: 0.25,
  });
}

function addMesh(parent: THREE.Object3D, mesh: THREE.Mesh, x: number, y: number, z: number): THREE.Mesh {
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function box(w: number, h: number, d: number, m: THREE.Material): THREE.Mesh {
  return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
}

/** Cylinder whose axis runs along +Z. rTop is the radius at the +Z end. */
function zCyl(rTop: number, rBot: number, len: number, m: THREE.Material): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, len, 20), m);
  mesh.rotation.x = Math.PI / 2;
  return mesh;
}

function buildLauncher(): WeaponModel {
  const g = new THREE.Group();
  const white = stdMat(0xeef6ff, 0.32, 0.05);
  const orange = stdMat(0xf97316, 0.4, 0.05);
  const dark = stdMat(0x1e293b, 0.5, 0.2);
  const metal = stdMat(0x94a3b8, 0.28, 0.75);
  const glass = new THREE.MeshStandardMaterial({
    color: 0x9bdcff,
    roughness: 0.1,
    metalness: 0.1,
    transparent: true,
    opacity: 0.42,
  });
  const cyan = glowMat(0x22d3ee);
  const snow = stdMat(0xffffff, 0.8, 0);

  // Receiver body + orange underside
  addMesh(g, box(0.12, 0.12, 0.3, white), 0, 0, 0.15);
  addMesh(g, box(0.13, 0.035, 0.26, orange), 0, -0.07, 0.15);
  addMesh(g, box(0.05, 0.02, 0.28, dark), 0, 0.075, 0.15);
  // Rear stock pad
  addMesh(g, box(0.105, 0.105, 0.03, dark), 0, 0, -0.005);

  // Snowball hopper on top (transparent drum filled with snowballs)
  addMesh(g, new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.1, 18), glass), 0, 0.13, 0.12);
  addMesh(g, new THREE.Mesh(new THREE.CylinderGeometry(0.064, 0.064, 0.018, 18), dark), 0, 0.078, 0.12);
  addMesh(g, new THREE.Mesh(new THREE.CylinderGeometry(0.064, 0.064, 0.02, 18), orange), 0, 0.187, 0.12);
  const ballOffsets: [number, number, number][] = [
    [0, 0.105, 0.12],
    [0.025, 0.14, 0.105],
    [-0.025, 0.14, 0.14],
    [0, 0.165, 0.12],
  ];
  ballOffsets.forEach(([bx, by, bz]) => {
    addMesh(g, new THREE.Mesh(new THREE.SphereGeometry(0.03, 12, 10), snow), bx, by, bz);
  });

  // Barrel assembly
  addMesh(g, zCyl(0.05, 0.05, 0.2, white), 0, 0.005, 0.4);
  addMesh(g, zCyl(0.03, 0.03, 0.36, metal), 0, 0.005, 0.46);
  addMesh(g, zCyl(0.058, 0.036, 0.085, orange), 0, 0.005, 0.645);
  addMesh(g, zCyl(0.026, 0.026, 0.012, dark), 0, 0.005, 0.69);
  // Barrel rings
  addMesh(g, zCyl(0.054, 0.054, 0.014, dark), 0, 0.005, 0.33);
  addMesh(g, zCyl(0.054, 0.054, 0.014, dark), 0, 0.005, 0.5);

  // Scope
  addMesh(g, zCyl(0.021, 0.021, 0.14, dark), 0, 0.112, 0.26);
  addMesh(g, zCyl(0.024, 0.024, 0.008, cyan), 0, 0.112, 0.335);
  addMesh(g, zCyl(0.018, 0.018, 0.008, cyan), 0, 0.112, 0.19);

  // Glowing power cells on both sides
  addMesh(g, box(0.014, 0.05, 0.13, cyan), 0.066, 0.01, 0.15);
  addMesh(g, box(0.014, 0.05, 0.13, cyan), -0.066, 0.01, 0.15);

  // Pistol grip (right) and foregrip (left)
  const pistol = addMesh(g, box(0.042, 0.1, 0.05, dark), -0.05, -0.115, 0.05);
  pistol.rotation.x = -0.18;
  addMesh(g, box(0.042, 0.09, 0.05, dark), 0.045, -0.105, 0.07);
  addMesh(g, box(0.05, 0.014, 0.06, orange), -0.05, -0.065, 0.06);

  const gripR = new THREE.Object3D();
  gripR.position.set(-0.05, -0.07, 0.05);
  const gripL = new THREE.Object3D();
  gripL.position.set(0.045, -0.06, 0.07);
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0.005, 0.7);
  g.add(gripR, gripL, muzzle);

  return { group: g, gripR, gripL, muzzle, mountPos: new THREE.Vector3(0, 0.035, 0.235) };
}

function buildBazooka(): WeaponModel {
  const g = new THREE.Group();
  const white = stdMat(0xf1f5f9, 0.35, 0.05);
  const orange = stdMat(0xf97316, 0.4, 0.05);
  const dark = stdMat(0x1e293b, 0.5, 0.2);
  const red = stdMat(0xef4444, 0.35, 0.05);
  const cyan = glowMat(0x22d3ee);
  const black = stdMat(0x0b1220, 0.7, 0.1);

  // Main launch tube
  addMesh(g, zCyl(0.075, 0.075, 0.78, white), 0, 0, 0.26);
  // Rear exhaust flare (wider at the back, -Z)
  addMesh(g, zCyl(0.076, 0.118, 0.13, dark), 0, 0, -0.2);
  addMesh(g, zCyl(0.1, 0.1, 0.01, black), 0, 0, -0.268);
  // Front muzzle ring
  addMesh(g, zCyl(0.1, 0.08, 0.1, orange), 0, 0, 0.68);
  // Orange bands
  const bandGeo = new THREE.TorusGeometry(0.078, 0.012, 8, 28);
  addMesh(g, new THREE.Mesh(bandGeo, orange), 0, 0, 0.04);
  addMesh(g, new THREE.Mesh(bandGeo, orange), 0, 0, 0.4);
  addMesh(g, new THREE.Mesh(bandGeo, dark), 0, 0, 0.5);

  // Glowing spine strip
  addMesh(g, box(0.018, 0.01, 0.42, cyan), 0, 0.078, 0.28);

  // Loaded snow-rocket peeking out of the muzzle
  const rocket = new THREE.Group();
  addMesh(rocket, zCyl(0.056, 0.056, 0.2, white), 0, 0, 0.72);
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.056, 0.15, 18), red);
  nose.rotation.x = Math.PI / 2;
  addMesh(rocket, nose, 0, 0, 0.9);
  g.add(rocket);

  // Sights
  addMesh(g, box(0.03, 0.045, 0.05, dark), 0, 0.105, 0.2);
  const sightRing = new THREE.Mesh(new THREE.TorusGeometry(0.022, 0.005, 6, 16), dark);
  addMesh(g, sightRing, 0, 0.14, 0.2);
  addMesh(g, box(0.02, 0.04, 0.02, dark), 0, 0.1, 0.52);

  // Shoulder pad
  addMesh(g, box(0.13, 0.04, 0.12, dark), 0, 0.085, -0.04);

  // Grip handle (right) + side handle bar (left)
  addMesh(g, box(0.042, 0.1, 0.05, dark), 0, -0.125, 0.03);
  addMesh(g, box(0.12, 0.03, 0.035, dark), 0.07, -0.075, 0.1);
  addMesh(g, new THREE.Mesh(new THREE.SphereGeometry(0.028, 10, 10), orange), 0.13, -0.075, 0.1);

  const gripR = new THREE.Object3D();
  gripR.position.set(0, -0.1, 0.03);
  const gripL = new THREE.Object3D();
  gripL.position.set(0.1, -0.08, 0.1);
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, 0, 0.98);
  g.add(gripR, gripL, muzzle);

  return {
    group: g,
    gripR,
    gripL,
    muzzle,
    mountPos: new THREE.Vector3(-0.05, 0.09, 0.2),
    rocketVisual: rocket,
  };
}

/**
 * Owns the Snowball Launcher + Bazooka models for one character, mounts them
 * onto the chest, aims them at a world direction and exposes grip/muzzle sockets for IK & firing.
 */
export class WeaponController {
  public current: WeaponType = 'SNOWBALL';
  private readonly rig: CharacterRig;
  private readonly launcher: WeaponModel;
  private readonly bazooka: WeaponModel;
  private kick = 0;
  private readonly aimQuat = new THREE.Quaternion();
  private readonly tmpQ = new THREE.Quaternion();
  private readonly kickQ = new THREE.Quaternion();
  private readonly xAxis = new THREE.Vector3(1, 0, 0);

  constructor(rig: CharacterRig) {
    this.rig = rig;
    this.launcher = buildLauncher();
    this.bazooka = buildBazooka();
    this.launcher.group.visible = false;
    this.bazooka.group.visible = false;
    rig.weaponMount.add(this.launcher.group, this.bazooka.group);
    rig.weaponMount.visible = false;
  }

  public get isArmed(): boolean {
    return this.current !== 'SNOWBALL';
  }

  private activeModel(): WeaponModel | null {
    if (this.current === 'LAUNCHER') return this.launcher;
    if (this.current === 'BAZOOKA') return this.bazooka;
    return null;
  }

  public setWeapon(type: WeaponType): void {
    this.current = type;
    this.launcher.group.visible = type === 'LAUNCHER';
    this.bazooka.group.visible = type === 'BAZOOKA';
    this.rig.weaponMount.visible = type !== 'SNOWBALL';
    this.kick = 0;
    this.aimQuat.identity();
    this.applyTransform();
  }

  public setRocketLoaded(loaded: boolean): void {
    if (this.bazooka.rocketVisual) this.bazooka.rocketVisual.visible = loaded;
  }

  public triggerKick(amount: number): void {
    this.kick = Math.min(1.6, this.kick + amount);
  }

  /** Orient the weapon so its barrel (+Z) points along a world-space direction. */
  public aimAt(worldDir: THREE.Vector3, maxAngle = 1.15): void {
    if (!this.isArmed) return;
    this.rig.root.updateMatrixWorld(true);
    this.rig.chest.getWorldQuaternion(this.tmpQ).invert();
    const local = worldDir.clone().normalize().applyQuaternion(this.tmpQ);
    const target = new THREE.Quaternion().setFromUnitVectors(Z_AXIS, local);
    this.aimQuat.identity().rotateTowards(target, maxAngle);
    this.applyTransform();
  }

  private applyTransform(): void {
    const m = this.activeModel();
    if (!m) return;
    this.rig.weaponMount.position.copy(m.mountPos);
    this.rig.weaponMount.position.z -= this.kick * 0.07;
    this.kickQ.setFromAxisAngle(this.xAxis, -this.kick * 0.1);
    this.rig.weaponMount.quaternion.copy(this.aimQuat).multiply(this.kickQ);
  }

  public update(dt: number): void {
    if (this.kick > 0) this.kick = Math.max(0, this.kick - dt * 7);
    if (this.isArmed) this.applyTransform();
  }

  public getMuzzleWorld(out: THREE.Vector3): THREE.Vector3 {
    const m = this.activeModel();
    this.rig.root.updateMatrixWorld(true);
    if (m) return m.muzzle.getWorldPosition(out);
    return out.copy(this.rig.root.position);
  }

  public getGripRWorld(out: THREE.Vector3): THREE.Vector3 {
    const m = this.activeModel() ?? this.launcher;
    return m.gripR.getWorldPosition(out);
  }

  public getGripLWorld(out: THREE.Vector3): THREE.Vector3 {
    const m = this.activeModel() ?? this.launcher;
    return m.gripL.getWorldPosition(out);
  }
}
