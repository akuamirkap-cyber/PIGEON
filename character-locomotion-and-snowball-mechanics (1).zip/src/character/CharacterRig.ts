import * as THREE from 'three';
import { CharacterAppearance } from '../config/GameConfig';
import { addToonOutline, createToonMat } from '../fps/toon';

export interface LookSpec {
  name: string;
  jacket: number;
  stripe: number;
  scarfA: number;
  scarfB: number;
  glove: number;
  boot: number;
  bootTrim: number;
  hair: number;
  hat: 'BEANIE' | 'POMPOM' | 'USHANKA' | 'EARMUFF';
  hatMain: number;
  hatTrim: number;
  pompom: number;
  patch: number;
}

/** 4 male kids (short hair) in snow-play outfits */
export const LOOKS: LookSpec[] = [
  {
    name: 'Jaket merah + beanie oranye',
    jacket: 0xe8302d,
    stripe: 0xffffff,
    scarfA: 0xffffff,
    scarfB: 0xffd426,
    glove: 0xffd426,
    boot: 0x7a5238,
    bootTrim: 0xffffff,
    hair: 0x3a2a20,
    hat: 'BEANIE',
    hatMain: 0xff8a1f,
    hatTrim: 0xffb454,
    pompom: 0,
    patch: 0xffd426,
  },
  {
    name: 'Jaket hijau + topi bulu coklat + syal kuning',
    jacket: 0x2fb344,
    stripe: 0xffe86a,
    scarfA: 0xffd426,
    scarfB: 0xffe97a,
    glove: 0xe5322d,
    boot: 0x5fb4ff,
    bootTrim: 0xffffff,
    hair: 0x1b1b1b,
    hat: 'USHANKA',
    hatMain: 0x7a4b2e,
    hatTrim: 0xb07848,
    pompom: 0,
    patch: 0xffe86a,
  },
  {
    name: 'Jaket biru + earmuff putih',
    jacket: 0x2f7bff,
    stripe: 0xffffff,
    scarfA: 0xffffff,
    scarfB: 0x9fd0ff,
    glove: 0xffd426,
    boot: 0x2b3446,
    bootTrim: 0xffffff,
    hair: 0xa8723c,
    hat: 'EARMUFF',
    hatMain: 0xffffff,
    hatTrim: 0xdfe9ff,
    pompom: 0,
    patch: 0xffd426,
  },
  {
    name: 'Jaket oranye + beanie merah berpompom',
    jacket: 0xff7a1a,
    stripe: 0xffffff,
    scarfA: 0xffffff,
    scarfB: 0xe0242a,
    glove: 0x2f7bff,
    boot: 0x333b57,
    bootTrim: 0xffffff,
    hair: 0x241b16,
    hat: 'POMPOM',
    hatMain: 0xe0242a,
    hatTrim: 0xff6a6a,
    pompom: 0xff5252,
    patch: 0x2f7bff,
  },
];

export const DEFAULT_PLAYER_APPEARANCE: CharacterAppearance = { look: 2, teamColor: 0x38bdf8 };

const SKIN = 0xffcfa8;
const PANTS = 0x232a48;

export class CharacterRig {
  public static readonly THIGH_LEN = 0.22;
  public static readonly CALF_LEN = 0.2;
  public static readonly FOOT_SOLE_HEIGHT = 0.075;
  public static readonly STANDING_PELVIS_Y = 0.482;

  public static readonly UPPER_ARM_LEN = 0.185;
  public static readonly FOREARM_LEN = 0.175;

  public readonly root = new THREE.Group();
  public readonly squashGroup = new THREE.Group();

  public readonly pelvis = new THREE.Group();
  public readonly spineLower = new THREE.Group();
  public readonly spineUpper = new THREE.Group();
  public readonly chest = new THREE.Group();
  public readonly neck = new THREE.Group();
  public readonly head = new THREE.Group();

  // face
  public readonly eyeL = new THREE.Group();
  public readonly eyeR = new THREE.Group();
  public readonly dazeStars = new THREE.Group();
  public readonly leaderCrown = new THREE.Group();
  public readonly shieldBubble: THREE.Mesh;

  public readonly clavicleL = new THREE.Group();
  public readonly upperArmL = new THREE.Group();
  public readonly forearmL = new THREE.Group();
  public readonly handL = new THREE.Group();

  public readonly clavicleR = new THREE.Group();
  public readonly upperArmR = new THREE.Group();
  public readonly forearmR = new THREE.Group();
  public readonly handR = new THREE.Group();
  public readonly snowballSocket = new THREE.Group();
  public readonly weaponMount = new THREE.Group();

  public readonly thighL = new THREE.Group();
  public readonly calfL = new THREE.Group();
  public readonly footL = new THREE.Group();
  public readonly soleL = new THREE.Group();

  public readonly thighR = new THREE.Group();
  public readonly calfR = new THREE.Group();
  public readonly footR = new THREE.Group();
  public readonly soleR = new THREE.Group();

  public readonly scarfBase = new THREE.Group();
  public readonly scarfTail = new THREE.Group();
  private scarfVelYaw = 0;
  private scarfVelPitch = 0;
  private prevChestWorldPos = new THREE.Vector3();

  private squashY = 1.0;
  private squashVel = 0.0;

  // blink / squint
  private blinkTimer = 1.5 + Math.random() * 2.5;
  private blinkPhase = 0;
  private eyeOpen = 1;

  private readonly allJoints: THREE.Group[] = [];
  public readonly look: LookSpec;

  constructor(appearance: CharacterAppearance = DEFAULT_PLAYER_APPEARANCE) {
    this.look = LOOKS[((appearance.look % LOOKS.length) + LOOKS.length) % LOOKS.length];

    const shieldGeo = new THREE.SphereGeometry(0.68, 18, 14);
    const shieldMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.45,
      transparent: true,
      opacity: 0.28,
      roughness: 0.15,
      depthWrite: false,
    });
    this.shieldBubble = new THREE.Mesh(shieldGeo, shieldMat);
    this.shieldBubble.position.set(0, 0.65, 0);
    this.shieldBubble.visible = false;

    this.setupHierarchy();
    this.buildToonVisuals(this.look, appearance.teamColor);
  }

  private setupHierarchy(): void {
    this.root.add(this.squashGroup);
    this.squashGroup.add(this.shieldBubble);

    this.pelvis.position.set(0, CharacterRig.STANDING_PELVIS_Y, 0);
    this.squashGroup.add(this.pelvis);

    this.spineLower.position.set(0, 0.055, 0);
    this.pelvis.add(this.spineLower);
    this.spineUpper.position.set(0, 0.115, 0);
    this.spineLower.add(this.spineUpper);
    this.chest.position.set(0, 0.11, 0);
    this.spineUpper.add(this.chest);
    this.neck.position.set(0, 0.135, 0);
    this.chest.add(this.neck);
    this.head.position.set(0, 0.045, 0);
    this.neck.add(this.head);

    this.scarfBase.position.set(0, 0.17, -0.13);
    this.chest.add(this.scarfBase);
    this.scarfTail.position.set(0, -0.14, -0.02);
    this.scarfBase.add(this.scarfTail);

    this.clavicleL.position.set(0.085, 0.105, 0);
    this.chest.add(this.clavicleL);
    this.upperArmL.position.set(0.148, -0.01, 0);
    this.clavicleL.add(this.upperArmL);
    this.forearmL.position.set(0, -CharacterRig.UPPER_ARM_LEN, 0);
    this.upperArmL.add(this.forearmL);
    this.handL.position.set(0, -CharacterRig.FOREARM_LEN, 0);
    this.forearmL.add(this.handL);

    this.clavicleR.position.set(-0.085, 0.105, 0);
    this.chest.add(this.clavicleR);
    this.upperArmR.position.set(-0.148, -0.01, 0);
    this.clavicleR.add(this.upperArmR);
    this.forearmR.position.set(0, -CharacterRig.UPPER_ARM_LEN, 0);
    this.upperArmR.add(this.forearmR);
    this.handR.position.set(0, -CharacterRig.FOREARM_LEN, 0);
    this.forearmR.add(this.handR);

    this.snowballSocket.position.set(0.012, -0.058, 0.055);
    this.handR.add(this.snowballSocket);

    this.chest.add(this.weaponMount);
    this.weaponMount.visible = false;

    this.thighL.position.set(0.118, 0, 0);
    this.pelvis.add(this.thighL);
    this.calfL.position.set(0, -CharacterRig.THIGH_LEN, 0);
    this.thighL.add(this.calfL);
    this.footL.position.set(0, -CharacterRig.CALF_LEN, 0);
    this.calfL.add(this.footL);
    this.soleL.position.set(0, -CharacterRig.FOOT_SOLE_HEIGHT, 0.03);
    this.footL.add(this.soleL);

    this.thighR.position.set(-0.118, 0, 0);
    this.pelvis.add(this.thighR);
    this.calfR.position.set(0, -CharacterRig.THIGH_LEN, 0);
    this.thighR.add(this.calfR);
    this.footR.position.set(0, -CharacterRig.CALF_LEN, 0);
    this.calfR.add(this.footR);
    this.soleR.position.set(0, -CharacterRig.FOOT_SOLE_HEIGHT, 0.03);
    this.footR.add(this.soleR);

    this.pelvis.rotation.order = 'YXZ';
    this.spineLower.rotation.order = 'YXZ';
    this.spineUpper.rotation.order = 'YXZ';
    this.chest.rotation.order = 'YXZ';
    this.neck.rotation.order = 'YXZ';
    this.head.rotation.order = 'YXZ';
    this.clavicleL.rotation.order = 'YXZ';
    this.clavicleR.rotation.order = 'YXZ';
    this.upperArmL.rotation.order = 'ZXY';
    this.upperArmR.rotation.order = 'ZXY';
    this.thighL.rotation.order = 'ZXY';
    this.thighR.rotation.order = 'ZXY';

    this.allJoints.push(
      this.pelvis,
      this.spineLower,
      this.spineUpper,
      this.chest,
      this.neck,
      this.head,
      this.clavicleL,
      this.upperArmL,
      this.forearmL,
      this.handL,
      this.clavicleR,
      this.upperArmR,
      this.forearmR,
      this.handR,
      this.thighL,
      this.calfL,
      this.footL,
      this.thighR,
      this.calfR,
      this.footR
    );
  }

  // ------------------------------------------------------------------------
  //  Splatoon-style toon visuals (MeshToonMaterial + inverted-hull outline + rim light)
  // ------------------------------------------------------------------------
  private part(
    parent: THREE.Object3D,
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number,
    outline = 0.011,
    sx = 1,
    sy = 1,
    sz = 1
  ): THREE.Mesh {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    m.scale.set(sx, sy, sz);
    m.castShadow = true;
    m.receiveShadow = true;
    if (outline > 0) addToonOutline(m, outline, 0x141a38);
    parent.add(m);
    return m;
  }

  private buildToonVisuals(look: LookSpec, teamColor: number): void {
    const jacket = createToonMat(look.jacket, { rim: 0.55 });
    const stripe = createToonMat(look.stripe, { rim: 0.3 });
    const pants = createToonMat(PANTS, { rim: 0.4 });
    const skin = createToonMat(SKIN, { rim: 0.35, rimColor: 0xffe6d0 });
    const skinDark = createToonMat(0xf2b48c, { rim: 0.2 });
    const glove = createToonMat(look.glove, { rim: 0.45 });
    const boot = createToonMat(look.boot, { rim: 0.45 });
    const white = createToonMat(0xffffff, { rim: 0.35 });
    const scarfA = createToonMat(look.scarfA, { rim: 0.4 });
    const scarfB = createToonMat(look.scarfB, { rim: 0.4 });
    const hairMat = createToonMat(look.hair, { rim: 0.3 });
    const patchMat = createToonMat(look.patch, { rim: 0.3 });
    const team = createToonMat(teamColor, { rim: 0.6, emissive: teamColor, emissiveIntensity: 0.25 });
    const gold = createToonMat(0xffd426, { rim: 0.6, emissive: 0xffa500, emissiveIntensity: 0.3 });
    const belt = createToonMat(0x1d2340);

    // ---- pelvis / belt
    this.part(this.pelvis, new THREE.SphereGeometry(0.215, 22, 16), pants, 0, 0.02, 0, 0.012, 1.06, 0.68, 0.92);
    this.part(this.pelvis, new THREE.TorusGeometry(0.205, 0.022, 8, 28), belt, 0, 0.065, 0, 0, 1.05, 0.9, 1).rotation.x = Math.PI / 2;
    const buckle = this.part(this.pelvis, new THREE.CylinderGeometry(0.03, 0.03, 0.014, 14), gold, 0, 0.065, 0.2, 0.003);
    buckle.rotation.x = Math.PI / 2;

    // ---- puffy jacket: three squashed puffs with seams, sport stripe & round logo
    this.part(this.spineLower, new THREE.SphereGeometry(0.235, 22, 16), jacket, 0, 0.06, 0, 0.012, 1.04, 0.66, 0.92);
    this.part(this.spineUpper, new THREE.SphereGeometry(0.238, 22, 16), jacket, 0, 0.06, 0, 0.012, 1.07, 0.7, 0.93);
    this.part(this.chest, new THREE.SphereGeometry(0.24, 24, 18), jacket, 0, 0.055, 0, 0.013, 1.1, 0.76, 0.92);
    const seam = this.part(this.chest, new THREE.TorusGeometry(0.235, 0.008, 6, 28), stripe, 0, 0.01, 0, 0, 1.08, 1, 0.92);
    seam.rotation.x = Math.PI / 2;
    const seam2 = this.part(this.spineUpper, new THREE.TorusGeometry(0.23, 0.007, 6, 28), stripe, 0, 0.05, 0, 0, 1.06, 1, 0.93);
    seam2.rotation.x = Math.PI / 2;
    const logoOuter = this.part(this.chest, new THREE.CircleGeometry(0.05, 20), white, 0.07, 0.07, 0.222, 0.003);
    logoOuter.rotation.y = 0.18;
    const logoInner = this.part(this.chest, new THREE.CircleGeometry(0.03, 20), team, 0.0704, 0.07, 0.2235, 0);
    logoInner.rotation.y = 0.18;
    this.part(this.chest, new THREE.BoxGeometry(0.03, 0.26, 0.016), stripe, -0.01, 0.0, 0.222, 0).rotation.z = 0;

    // collar + thick scarf wraps
    this.part(this.chest, new THREE.TorusGeometry(0.12, 0.05, 10, 24), jacket, 0, 0.145, -0.01, 0.009).rotation.x = Math.PI / 2;
    const wrapA = this.part(this.chest, new THREE.TorusGeometry(0.122, 0.048, 10, 26), scarfA, 0, 0.175, -0.005, 0.01);
    wrapA.rotation.x = Math.PI / 2 + 0.1;
    const wrapB = this.part(this.chest, new THREE.TorusGeometry(0.118, 0.04, 10, 26), scarfB, 0, 0.205, 0.0, 0.009);
    wrapB.rotation.x = Math.PI / 2 + 0.08;
    // scarf tail (physics-driven)
    this.part(this.scarfBase, new THREE.CapsuleGeometry(0.04, 0.1, 6, 10), scarfA, 0.02, -0.07, -0.01, 0.009, 1.2, 1, 0.55);
    this.part(this.scarfTail, new THREE.CapsuleGeometry(0.038, 0.09, 6, 10), scarfB, 0.02, -0.065, -0.01, 0.009, 1.2, 1, 0.55);

    // ---- head: skin sphere, ears, short hair, nose, smile, blush
    this.part(this.neck, new THREE.CylinderGeometry(0.06, 0.07, 0.07, 12), skin, 0, 0.03, 0, 0.006);
    this.part(this.head, new THREE.SphereGeometry(0.205, 28, 22), skin, 0, 0.165, 0.01, 0.012, 1.06, 0.98, 1.0);
    for (const s of [-1, 1]) {
      this.part(this.head, new THREE.SphereGeometry(0.04, 12, 10), skin, s * 0.212, 0.16, 0.0, 0.006, 0.6, 1, 0.9);
    }
    // short hair: cap + side tufts
    const hairCap = this.part(
      this.head,
      new THREE.SphereGeometry(0.212, 22, 14, 0, Math.PI * 2, 0, Math.PI * 0.5),
      hairMat,
      0,
      0.185,
      -0.012,
      0.01,
      1.07,
      0.99,
      1.03
    );
    hairCap.rotation.x = -0.28;
    for (const s of [-1, 1]) {
      this.part(this.head, new THREE.SphereGeometry(0.05, 10, 8), hairMat, s * 0.198, 0.2, 0.0, 0.006, 0.7, 1.1, 1.1);
    }
    // nose, smile & blush
    this.part(this.head, new THREE.SphereGeometry(0.026, 12, 10), skinDark, 0, 0.125, 0.216, 0.004);
    const smile = this.part(
      this.head,
      new THREE.TorusGeometry(0.036, 0.0075, 6, 14, Math.PI),
      createToonMat(0x8a2e35, { rim: 0 }),
      0,
      0.092,
      0.2,
      0
    );
    smile.rotation.z = Math.PI;
    smile.rotation.x = -0.12;
    const blushMat = createToonMat(0xff9a9a, { rim: 0 });
    for (const s of [-1, 1]) {
      this.part(this.head, new THREE.SphereGeometry(0.026, 10, 8), blushMat, s * 0.128, 0.115, 0.178, 0, 1.1, 0.62, 0.3);
    }

    // ---- Mario-style eyes: big white sclera, close together, glossy black pupils with white highlights
    const eyeWhite = createToonMat(0xffffff, { rim: 0.12 });
    const pupilMat = new THREE.MeshStandardMaterial({ color: 0x06080f, roughness: 0.08, metalness: 0.3 });
    const glintMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    for (const s of [1, -1]) {
      const eye = s === 1 ? this.eyeL : this.eyeR;
      eye.position.set(s * 0.062, 0.178, 0.186);
      this.head.add(eye);
      this.part(eye, new THREE.SphereGeometry(0.064, 24, 18), eyeWhite, 0, 0, 0, 0.0055, 1.0, 1.2, 0.64);
      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.038, 18, 14), pupilMat);
      pupil.position.set(-s * 0.013, -0.01, 0.033);
      pupil.scale.set(1.0, 1.12, 0.55);
      eye.add(pupil);
      const g1 = new THREE.Mesh(new THREE.SphereGeometry(0.0125, 10, 8), glintMat);
      g1.position.set(-s * 0.013 - 0.013, 0.005, 0.05);
      eye.add(g1);
      const g2 = new THREE.Mesh(new THREE.SphereGeometry(0.0065, 8, 6), glintMat);
      g2.position.set(-s * 0.013 + 0.011, -0.025, 0.051);
      eye.add(g2);
    }

    // ---- hats
    this.buildHat(look, jacket, white);

    // ---- stars (daze) & leader crown
    this.dazeStars.position.set(0, 0.48, 0);
    this.dazeStars.visible = false;
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2;
      const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.05, 0), gold);
      star.position.set(Math.cos(a) * 0.22, 0, Math.sin(a) * 0.22);
      this.dazeStars.add(star);
    }
    this.head.add(this.dazeStars);

    this.leaderCrown.position.set(0, 0.6, 0);
    this.leaderCrown.visible = false;
    this.leaderCrown.add(new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.105, 0.08, 8), gold));
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.036, 0.08, 5), gold);
      spike.position.set(Math.cos(a) * 0.11, 0.07, Math.sin(a) * 0.11);
      this.leaderCrown.add(spike);
    }
    this.head.add(this.leaderCrown);

    // ---- arms: puffy sleeves, cuff, mitten, team armband
    const buildArm = (
      clavicle: THREE.Group,
      upperArm: THREE.Group,
      forearm: THREE.Group,
      hand: THREE.Group,
      sign: number
    ) => {
      this.part(clavicle, new THREE.SphereGeometry(0.078, 14, 12), jacket, sign * 0.135, -0.005, 0, 0.01);
      this.part(
        upperArm,
        new THREE.CapsuleGeometry(0.06, Math.max(0.04, CharacterRig.UPPER_ARM_LEN - 0.07), 8, 12),
        jacket,
        0,
        -CharacterRig.UPPER_ARM_LEN * 0.5,
        0,
        0.01
      );
      const band = this.part(upperArm, new THREE.TorusGeometry(0.064, 0.014, 6, 16), team, 0, -0.07, 0, 0.003);
      band.rotation.x = Math.PI / 2;
      this.part(
        forearm,
        new THREE.CapsuleGeometry(0.055, Math.max(0.04, CharacterRig.FOREARM_LEN - 0.07), 8, 12),
        jacket,
        0,
        -CharacterRig.FOREARM_LEN * 0.48,
        0,
        0.01
      );
      const cuff = this.part(forearm, new THREE.TorusGeometry(0.055, 0.017, 6, 16), white, 0, -CharacterRig.FOREARM_LEN + 0.012, 0, 0.004);
      cuff.rotation.x = Math.PI / 2;
      this.part(hand, new THREE.SphereGeometry(0.066, 14, 12), glove, 0, -0.052, 0.01, 0.008, 0.98, 1.15, 0.95);
      this.part(hand, new THREE.SphereGeometry(0.03, 10, 8), glove, sign * -0.048, -0.04, 0.034, 0.005);
    };
    buildArm(this.clavicleL, this.upperArmL, this.forearmL, this.handL, 1);
    buildArm(this.clavicleR, this.upperArmR, this.forearmR, this.handR, -1);

    // ---- legs: dark pants (one knee patch), chunky snow boots with fur cuffs
    const buildLeg = (thigh: THREE.Group, calf: THREE.Group, foot: THREE.Group, withPatch: boolean) => {
      this.part(
        thigh,
        new THREE.CapsuleGeometry(0.078, Math.max(0.04, CharacterRig.THIGH_LEN - 0.08), 8, 12),
        pants,
        0,
        -CharacterRig.THIGH_LEN * 0.5,
        0,
        0.01
      );
      this.part(
        calf,
        new THREE.CapsuleGeometry(0.07, Math.max(0.04, CharacterRig.CALF_LEN - 0.08), 8, 12),
        pants,
        0,
        -CharacterRig.CALF_LEN * 0.48,
        0,
        0.01
      );
      if (withPatch) {
        const patch = this.part(calf, new THREE.CylinderGeometry(0.036, 0.036, 0.008, 12), patchMat, 0.0, -0.07, 0.066, 0.002);
        patch.rotation.x = Math.PI / 2;
        const stitch = this.part(calf, new THREE.TorusGeometry(0.04, 0.0035, 6, 14), white, 0.0, -0.07, 0.07, 0);
        stitch.rotation.x = 0;
      }
      // boot
      this.part(foot, new THREE.SphereGeometry(0.08, 18, 14), boot, 0, -0.007, 0.04, 0.009, 1.05, 0.85, 1.5);
      const sole = this.part(foot, new THREE.BoxGeometry(0.15, 0.022, 0.25), white, 0, -0.065, 0.045, 0);
      sole.rotation.x = 0;
      this.part(foot, new THREE.SphereGeometry(0.045, 12, 10), patchMat, 0, -0.018, 0.14, 0.005, 1.0, 0.8, 0.9);
      const fur = this.part(foot, new THREE.TorusGeometry(0.074, 0.028, 8, 18), white, 0, 0.045, 0.0, 0.006);
      fur.rotation.x = Math.PI / 2;
    };
    buildLeg(this.thighL, this.calfL, this.footL, false);
    buildLeg(this.thighR, this.calfR, this.footR, true);
  }

  private buildHat(look: LookSpec, jacket: THREE.Material, white: THREE.Material): void {
    void jacket;
    const main = createToonMat(look.hatMain, { rim: 0.5 });
    const trim = createToonMat(look.hatTrim, { rim: 0.4 });

    if (look.hat === 'BEANIE' || look.hat === 'POMPOM') {
      const dome = this.part(
        this.head,
        new THREE.SphereGeometry(0.222, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.56),
        main,
        0,
        0.262,
        -0.01,
        0.012
      );
      dome.rotation.x = -0.15;
      const cuff = this.part(this.head, new THREE.TorusGeometry(0.19, 0.04, 10, 28), trim, 0, 0.292, -0.005, 0.009);
      cuff.rotation.x = Math.PI / 2 - 0.14;
      const rib = this.part(this.head, new THREE.TorusGeometry(0.2, 0.011, 6, 28), white, 0, 0.352, -0.035, 0, 1, 1, 1);
      rib.rotation.x = Math.PI / 2 - 0.15;
      if (look.hat === 'POMPOM') {
        const pomMat = createToonMat(look.pompom, { rim: 0.45 });
        this.part(this.head, new THREE.SphereGeometry(0.075, 14, 12), pomMat, 0, 0.47, -0.055, 0.008);
        for (let i = 0; i < 5; i++) {
          const a = (i / 5) * Math.PI * 2;
          this.part(this.head, new THREE.SphereGeometry(0.03, 8, 6), pomMat, Math.cos(a) * 0.055, 0.47 + Math.sin(a * 2) * 0.02, -0.055 + Math.sin(a) * 0.055, 0.004);
        }
      } else {
        // small knit tuft
        this.part(this.head, new THREE.SphereGeometry(0.034, 10, 8), trim, 0, 0.45, -0.055, 0.005);
      }
    } else if (look.hat === 'USHANKA') {
      const crown = this.part(
        this.head,
        new THREE.SphereGeometry(0.226, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55),
        main,
        0,
        0.255,
        -0.01,
        0.012,
        1.0,
        0.86,
        1.0
      );
      crown.rotation.x = -0.1;
      // fur front band (open at the back)
      const band = this.part(this.head, new THREE.TorusGeometry(0.2, 0.048, 10, 26, Math.PI * 1.15), trim, 0, 0.285, 0.0, 0.009);
      band.rotation.x = Math.PI / 2 - 0.1;
      band.rotation.z = Math.PI * 0.425;
      // ear flaps
      for (const s of [-1, 1]) {
        const flap = this.part(this.head, new THREE.CapsuleGeometry(0.055, 0.08, 8, 12), trim, s * 0.205, 0.13, 0.0, 0.009, 0.8, 1, 1);
        flap.rotation.z = -s * 0.12;
        this.part(this.head, new THREE.SphereGeometry(0.018, 8, 6), white, s * 0.21, 0.04, 0.02, 0.003);
      }
      this.part(this.head, new THREE.SphereGeometry(0.026, 8, 6), trim, 0, 0.375, 0.0, 0.004);
    } else {
      // EARMUFF: headband + two big fluffy puffs
      const bandTube = this.part(this.head, new THREE.TorusGeometry(0.226, 0.016, 8, 28, Math.PI), trim, 0, 0.165, 0.0, 0.006);
      bandTube.rotation.z = 0;
      for (const s of [-1, 1]) {
        this.part(this.head, new THREE.SphereGeometry(0.082, 16, 12), main, s * 0.225, 0.165, 0.0, 0.009, 0.62, 1, 1);
        this.part(this.head, new THREE.SphereGeometry(0.05, 12, 10), trim, s * 0.252, 0.165, 0.0, 0.004, 0.4, 1, 1);
      }
    }
  }

  // ------------------------------------------------------------------------
  public triggerSquash(targetScaleY: number): void {
    this.squashY = targetScaleY;
  }

  public resetPose(): void {
    for (const joint of this.allJoints) joint.rotation.set(0, 0, 0);
    this.pelvis.position.set(0, CharacterRig.STANDING_PELVIS_Y, 0);
  }

  public updateSecondaryDynamics(
    dt: number,
    worldVelocity: THREE.Vector3,
    expression: 'NORMAL' | 'FIERCE' | 'DAZED' = 'NORMAL',
    isLeader = false,
    hasShield = false
  ): void {
    // jelly squash & stretch
    this.squashVel += ((1.0 - this.squashY) * 110 - this.squashVel * 11) * dt;
    this.squashY = THREE.MathUtils.clamp(this.squashY + this.squashVel * dt, 0.68, 1.32);
    const invXz = 1 / Math.sqrt(Math.max(0.5, this.squashY));
    this.squashGroup.scale.set(invXz, this.squashY, invXz);

    // periodic blink + squint while shooting / throwing + wide eyes when dazed
    this.blinkTimer -= dt;
    if (this.blinkTimer <= 0 && this.blinkPhase <= 0) {
      this.blinkPhase = 0.15;
      this.blinkTimer = 2.2 + Math.random() * 3.2;
    }
    let blink = 0;
    if (this.blinkPhase > 0) {
      this.blinkPhase = Math.max(0, this.blinkPhase - dt);
      blink = Math.sin(Math.PI * (1 - this.blinkPhase / 0.15));
    }
    const baseOpen = expression === 'FIERCE' ? 0.5 : expression === 'DAZED' ? 1.12 : 1.0;
    this.eyeOpen = THREE.MathUtils.lerp(this.eyeOpen, baseOpen, 1 - Math.exp(-18 * dt));
    const open = Math.max(0.06, this.eyeOpen * (1 - blink * 0.94));
    this.eyeL.scale.set(1, open, 1);
    this.eyeR.scale.set(1, open, 1);

    this.dazeStars.visible = expression === 'DAZED';
    if (expression === 'DAZED') this.dazeStars.rotation.y += 6.5 * dt;

    this.leaderCrown.visible = isLeader;
    if (isLeader) {
      this.leaderCrown.rotation.y += 2.2 * dt;
      this.leaderCrown.position.y = 0.6 + Math.sin(performance.now() * 0.005) * 0.03;
    }

    this.shieldBubble.visible = hasShield;
    if (hasShield) this.shieldBubble.rotation.y += 1.5 * dt;

    // scarf physics
    this.root.updateMatrixWorld(true);
    const chestPos = new THREE.Vector3();
    this.chest.getWorldPosition(chestPos);
    if (this.prevChestWorldPos.lengthSq() === 0) this.prevChestWorldPos.copy(chestPos);

    const chestVel = chestPos.clone().sub(this.prevChestWorldPos).divideScalar(Math.max(0.001, dt));
    const effectiveSpeed = Math.max(
      Math.hypot(worldVelocity.x, worldVelocity.z),
      Math.min(9.0, Math.hypot(chestVel.x, chestVel.z))
    );

    const targetPitch = Math.min(1.08, 0.14 + effectiveSpeed * 0.12);
    const flutter = Math.sin(performance.now() * 0.016) * Math.min(0.22, effectiveSpeed * 0.032);
    this.scarfVelPitch += ((targetPitch + flutter - this.scarfBase.rotation.x) * 30 - this.scarfVelPitch * 6.2) * dt;
    this.scarfBase.rotation.x += this.scarfVelPitch * dt;
    this.scarfTail.rotation.x = this.scarfBase.rotation.x * 0.68 + flutter * 0.85;

    const targetYaw = Math.sin(performance.now() * 0.0095) * Math.min(0.26, effectiveSpeed * 0.038);
    this.scarfVelYaw += ((targetYaw - this.scarfBase.rotation.z) * 22 - this.scarfVelYaw * 5.2) * dt;
    this.scarfBase.rotation.z += this.scarfVelYaw * dt;

    this.prevChestWorldPos.copy(chestPos);
  }
}
