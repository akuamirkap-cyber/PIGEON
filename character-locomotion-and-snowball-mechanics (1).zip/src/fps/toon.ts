import * as THREE from 'three';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

/**
 * Shared Splatoon-style cel-shading helpers:
 *  - 3-band toon gradient
 *  - MeshToonMaterial with a rim light
 *  - inverted-hull outline (back-face, extruded along smoothed normals)
 */

let gradientTex: THREE.DataTexture | null = null;
export function getToonGradient(): THREE.DataTexture {
  if (!gradientTex) {
    const data = new Uint8Array([110, 110, 110, 255, 180, 180, 180, 255, 255, 255, 255, 255]);
    gradientTex = new THREE.DataTexture(data, 3, 1, THREE.RGBAFormat);
    gradientTex.minFilter = THREE.NearestFilter;
    gradientTex.magFilter = THREE.NearestFilter;
    gradientTex.generateMipmaps = false;
    gradientTex.needsUpdate = true;
  }
  return gradientTex;
}

export interface ToonOpts {
  rim?: number;
  rimColor?: number;
  emissive?: number;
  emissiveIntensity?: number;
  transparent?: boolean;
  opacity?: number;
  side?: THREE.Side;
  depthWrite?: boolean;
}

export function createToonMat(color: number, opts: ToonOpts = {}): THREE.MeshToonMaterial {
  const m = new THREE.MeshToonMaterial({
    color,
    gradientMap: getToonGradient(),
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 1,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
    depthWrite: opts.depthWrite ?? true,
  });
  const rimStrength = opts.rim ?? 0.5;
  const rimColor = new THREE.Color(opts.rimColor ?? 0xcdeaff);
  m.onBeforeCompile = (shader) => {
    shader.uniforms.uRimColor = { value: rimColor };
    shader.uniforms.uRimStrength = { value: rimStrength };
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\nuniform vec3 uRimColor;\nuniform float uRimStrength;')
      .replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        float rimF = pow(1.0 - saturate(dot(normalize(vViewPosition), normal)), 2.6);
        totalEmissiveRadiance += uRimColor * rimF * uRimStrength;`
      );
  };
  m.customProgramCacheKey = () => 'toon-rim-v1';
  return m;
}

// ---- inverted hull outline -------------------------------------------------
const outlineGeoCache = new WeakMap<THREE.BufferGeometry, THREE.BufferGeometry>();
const outlineMatCache = new Map<string, THREE.ShaderMaterial>();

function getOutlineGeo(src: THREE.BufferGeometry): THREE.BufferGeometry {
  let g = outlineGeoCache.get(src);
  if (!g) {
    const c = src.clone();
    c.deleteAttribute('normal');
    c.deleteAttribute('uv');
    g = mergeVertices(c, 1e-4);
    g.computeVertexNormals();
    outlineGeoCache.set(src, g);
  }
  return g;
}

function getOutlineMat(thickness: number, color: number): THREE.ShaderMaterial {
  const key = `${thickness.toFixed(4)}-${color}`;
  let m = outlineMatCache.get(key);
  if (!m) {
    m = new THREE.ShaderMaterial({
      uniforms: { uThick: { value: thickness }, uColor: { value: new THREE.Color(color) } },
      vertexShader: /* glsl */ `
        uniform float uThick;
        void main() {
          vec3 p = position + normalize(normal) * uThick;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform vec3 uColor;
        void main() { gl_FragColor = vec4(uColor, 1.0); }
      `,
      side: THREE.BackSide,
    });
    outlineMatCache.set(key, m);
  }
  return m;
}

export function addToonOutline(mesh: THREE.Mesh, thickness = 0.01, color = 0x1a2038): THREE.Mesh {
  const o = new THREE.Mesh(getOutlineGeo(mesh.geometry), getOutlineMat(thickness, color));
  o.castShadow = false;
  o.receiveShadow = false;
  mesh.add(o);
  return mesh;
}
