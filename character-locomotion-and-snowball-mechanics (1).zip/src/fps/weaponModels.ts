// @ts-nocheck
import * as THREE from 'three';
import { createStylizedHand } from './skins/common';
import { createMat } from './skins/materials';
import { createToonMat } from './toon';
import { WeaponId } from './types';
type SkinId = 'boonie' | 'venom' | 'gold' | 'reaper' | 'police' | 'gunner' | 'skill' | 'spetsnaz' | 'silat';

export interface ScopeLensUniforms {
  uScopeTex: { value: THREE.Texture | null };
  uEyeOffset: { value: THREE.Vector2 };
  uAdsBlend: { value: number };
}

export interface WeaponRig {
  id: WeaponId;
  root: THREE.Group;
  weaponBody: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  // Animated mechanical parts
  slide?: THREE.Group;
  hammer?: THREE.Group;
  bolt?: THREE.Group;
  boltHandle?: THREE.Group;
  dustCover?: THREE.Group;
  chargingHandle?: THREE.Group;
  mag: THREE.Group;
  trigger?: THREE.Group;
  holoReticle?: THREE.Mesh;
  scopeLensUniforms?: ScopeLensUniforms;
  // Exact 3D sockets in weaponBody local space
  muzzleSocket: THREE.Object3D;
  ejectionSocket: THREE.Object3D;
  actionSocket: THREE.Object3D;
  magSocket: THREE.Object3D;
  // Built-in low-poly muzzle flash meshes attached to muzzleSocket
  muzzleFlash: THREE.Group;
  // Rest poses for animated arms/mag so animations smoothly blend back
  leftArmRestPos: THREE.Vector3;
  leftArmRestRot: THREE.Euler;
  rightArmRestPos: THREE.Vector3;
  rightArmRestRot: THREE.Euler;
  magRestPos: THREE.Vector3;
  magRestRot: THREE.Euler;
}

/**
 * First-person hands use the skin pack's sculpted hand (articulated fingers, cel outline).
 * Two shared materials are re-tinted live when the player picks a skin: `hand` (glove or skin) and `sleeve`.
 */
const FP = {
  hand: createToonMat(0xffd426, { rim: 0.35 }),
  sleeve: createToonMat(0x2f7bff, { rim: 0.35 }),
};
const FP_LOOK: Record<SkinId, { hand: number; sleeve: number }> = {
  boonie: { hand: 0xc99a73, sleeve: 0x1c1e21 },
  venom: { hand: 0x2a2d31, sleeve: 0x282b2f },
  gold: { hand: 0xd3aa3c, sleeve: 0xa7c2e4 },
  reaper: { hand: 0x1e2024, sleeve: 0x2d3137 },
  police: { hand: 0x1a1c20, sleeve: 0x24365a },
  gunner: { hand: 0xb98764, sleeve: 0xb98764 },
  skill: { hand: 0xd9a77f, sleeve: 0xdfe3ea },
  spetsnaz: { hand: 0x2f3a2c, sleeve: 0x3e4a35 },
  silat: { hand: 0xb07d5b, sleeve: 0xb07d5b },
};
/** re-tint gloves / hands / sleeves to match the chosen skin */
export function setFirstPersonColors(hand: number, sleeve: number) {
  FP.hand.color.setHex(hand);
  FP.sleeve.color.setHex(sleeve);
}

export function setFirstPersonSkin(id: SkinId) {
  const look = FP_LOOK[id];
  FP.hand.color.setHex(look.hand);
  FP.sleeve.color.setHex(look.sleeve);
}

// Shared stylized low-poly flat-shaded materials matching the reference art style
const MAT = {
  handWhite: new THREE.MeshStandardMaterial({
    color: 0xf2f5f9,
    roughness: 0.85,
    metalness: 0.0,
    flatShading: true,
  }),
  handShadowWhite: new THREE.MeshStandardMaterial({
    color: 0xe4eaf1,
    roughness: 0.88,
    metalness: 0.0,
    flatShading: true,
  }),
  gunDark: new THREE.MeshStandardMaterial({
    color: 0x262c34,
    roughness: 0.56,
    metalness: 0.28,
    flatShading: true,
  }),
  gunCharcoal: new THREE.MeshStandardMaterial({
    color: 0x313842,
    roughness: 0.48,
    metalness: 0.36,
    flatShading: true,
  }),
  gunDeepBlack: new THREE.MeshStandardMaterial({
    color: 0x1b2027,
    roughness: 0.62,
    metalness: 0.22,
    flatShading: true,
  }),
  gunSteel: new THREE.MeshStandardMaterial({
    color: 0x56606d,
    roughness: 0.34,
    metalness: 0.72,
    flatShading: true,
  }),
  pistolBronze: new THREE.MeshStandardMaterial({
    color: 0xc97e47,
    roughness: 0.38,
    metalness: 0.52,
    flatShading: true,
  }),
  sightOrange: new THREE.MeshBasicMaterial({
    color: 0xff7a2f,
  }),
  holoGlass: new THREE.MeshPhysicalMaterial({
    color: 0x54d68c,
    emissive: 0x164a2c,
    emissiveIntensity: 0.4,
    transparent: true,
    opacity: 0.28,
    roughness: 0.08,
    metalness: 0.1,
    side: THREE.DoubleSide,
    depthWrite: false,
  }),
  scopeLens: new THREE.MeshStandardMaterial({
    color: 0x0d2230,
    emissive: 0x081c28,
    emissiveIntensity: 0.6,
    roughness: 0.08,
    metalness: 0.92,
    flatShading: true,
  }),
  flashOuter: new THREE.MeshBasicMaterial({
    color: 0xff9b26,
    transparent: true,
    opacity: 0.92,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  }),
  flashCore: new THREE.MeshBasicMaterial({
    color: 0xfff5c0,
    transparent: true,
    opacity: 0.98,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  }),
  flashGas: new THREE.MeshBasicMaterial({
    color: 0xffcf75,
    transparent: true,
    opacity: 0.78,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
  }),
};

function makeBox(
  w: number,
  h: number,
  d: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  rx = 0,
  ry = 0,
  rz = 0
): THREE.Mesh {
  const geo = new THREE.BoxGeometry(w, h, d).toNonIndexed();
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(x, y, z);
  mesh.rotation.set(rx, ry, rz);
  return mesh;
}

function makeCyl(
  rTop: number,
  rBot: number,
  len: number,
  segs: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  rx = 0,
  ry = 0,
  rz = 0,
  openEnded = false
): THREE.Mesh {
  const geo = new THREE.CylinderGeometry(rTop, rBot, len, segs, 1, openEnded).toNonIndexed();
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(x, y, z);
  mesh.rotation.set(rx, ry, rz);
  return mesh;
}

/**
 * Live Picture-in-Picture Optical Magnifying Glass Scope Shader (Exact PIGEON Reference Technique!)
 * Outputs linear optical HDR matching our BodycamPostPipeline so the magnified enemy inside the glass
 * has identical crisp daylight lighting, auto-exposure, etched Mil-Dot reticle, glowing red dot,
 * subtle optical eye-relief parallax, and multi-coated lens sheen!
 */
export function createLiveMagnifyingScopeMaterial(
  scopeTexture?: THREE.Texture
): { material: THREE.ShaderMaterial; uniforms: ScopeLensUniforms } {
  const uniforms: ScopeLensUniforms = {
    uScopeTex: { value: scopeTexture ?? null },
    uEyeOffset: { value: new THREE.Vector2(0, 0) },
    uAdsBlend: { value: 0 },
  };

  const material = new THREE.ShaderMaterial({
    uniforms: uniforms as unknown as Record<string, THREE.IUniform>,
    polygonOffset: true,
    polygonOffsetFactor: -3,
    polygonOffsetUnits: -3,
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      varying vec3 vViewPos;
      varying vec3 vViewNormal;
      void main() {
        vUv = uv;
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPos = -mvPosition.xyz;
        vViewNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D uScopeTex;
      uniform vec2 uEyeOffset;
      uniform float uAdsBlend;
      varying vec2 vUv;
      varying vec3 vViewPos;
      varying vec3 vViewNormal;

      void main() {
        vec2 p = vUv * 2.0 - 1.0;
        float r2 = dot(p, p);
        float r = sqrt(r2);

        // Clean convex optical magnifying glass distortion + gentle eye-relief parallax
        float magCurve = 0.89 + 0.11 * r2;
        vec2 parallax = uEyeOffset * (1.0 - uAdsBlend * 0.90);
        vec2 sampleUv = clamp((p * magCurve + parallax) * 0.5 + 0.5, vec2(0.008), vec2(0.992));

        // Sample high-res 4x-MSAA linear world magnification render target (100% crisp!)
        vec3 sceneCol = texture2D(uScopeTex, sampleUv).rgb;
        // Slight optical glass clarity boost (stays in linear space for seamless BodycamPost tone-mapping!)
        sceneCol *= 1.06;

        // Derivative-AA Etched Precision Sniper Reticle (Razor-sharp at every zoom level, zero shimmer!)
        vec2 rp = p + parallax * 0.16;
        float pxSize = max(fwidth(rp.x), 0.0035);
        float thinHalf = pxSize * 0.9;
        float postHalf = pxSize * 2.3;

        float hCross = (1.0 - smoothstep(thinHalf * 0.5, thinHalf * 1.5, abs(rp.y))) * smoothstep(0.032, 0.048, abs(rp.x));
        float vCross = (1.0 - smoothstep(thinHalf * 0.5, thinHalf * 1.5, abs(rp.x))) * smoothstep(0.032, 0.048, abs(rp.y));

        // Outer heavy duplex stadia posts
        float outerPosts =
          (1.0 - smoothstep(postHalf * 0.6, postHalf * 1.5, abs(rp.y))) * smoothstep(0.54, 0.56, abs(rp.x)) +
          (1.0 - smoothstep(postHalf * 0.6, postHalf * 1.5, abs(rp.x))) * smoothstep(0.54, 0.56, -rp.y);

        // Clean Mil-Dot rangefinding hash ticks
        float ticks = 0.0;
        for (int i = -3; i <= 3; i++) {
          if (i != 0) {
            float tPos = float(i) * 0.135;
            float hTick = (1.0 - smoothstep(thinHalf * 0.6, thinHalf * 1.6, abs(rp.x - tPos))) * (1.0 - smoothstep(0.016, 0.025, abs(rp.y)));
            float vTick = (1.0 - smoothstep(thinHalf * 0.6, thinHalf * 1.6, abs(rp.y - tPos))) * (1.0 - smoothstep(0.016, 0.025, abs(rp.x)));
            ticks += hTick + vTick;
          }
        }

        float reticleAlpha = clamp(hCross + vCross + outerPosts + ticks, 0.0, 1.0);
        sceneCol = mix(sceneCol, vec3(0.012, 0.015, 0.018), reticleAlpha * 0.94);

        // Crisp Illuminated Tactical Red Center Aim Dot (linear HDR bright)
        float dotDist = length(rp);
        float redDot = 1.0 - smoothstep(pxSize * 1.35, pxSize * 2.6, dotDist);
        sceneCol = mix(sceneCol, vec3(1.8, 0.08, 0.05), redDot);

        // Subtle Multi-Coated Optical Glass Sheen (Sky-Cyan & Emerald Rim Glint, fades cleanly when ADSing!)
        vec3 viewDir = normalize(vViewPos);
        float fresnel = pow(1.0 - clamp(abs(dot(viewDir, normalize(vViewNormal))), 0.0, 1.0), 2.8);
        float glassStreak = smoothstep(0.24, 0.0, abs((p.x * 0.75 + p.y * 0.65) - 0.38)) * (1.0 - r2 * 0.65);
        sceneCol += vec3(0.14, 0.58, 0.55) * (fresnel * 0.22 + glassStreak * 0.06 * (1.0 - uAdsBlend * 0.8));

        // Clean Smooth Inner Scope Tube Rim Feather (Authentic eye-box shadow edge!)
        float innerEdge = smoothstep(1.01, 0.89, r);
        gl_FragColor = vec4(sceneCol * innerEdge, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });

  return { material, uniforms };
}

/**
 * Builds a chamfered/beveled low-poly faceted prism (extruded octagon-like block)
 * so slides, receivers, and scopes have true faceted polygon silhouettes instead of plain boxes.
 */
function makeBeveledBlock(
  w: number,
  h: number,
  d: number,
  chamfer: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0
): THREE.Mesh {
  const hw = w / 2;
  const hh = h / 2;
  const c = Math.min(chamfer, hw * 0.45, hh * 0.45);
  const shape = new THREE.Shape();
  shape.moveTo(-hw + c, -hh);
  shape.lineTo(hw - c, -hh);
  shape.lineTo(hw, -hh + c);
  shape.lineTo(hw, hh - c);
  shape.lineTo(hw - c, hh);
  shape.lineTo(-hw + c, hh);
  shape.lineTo(-hw, hh - c);
  shape.lineTo(-hw, -hh + c);
  shape.closePath();

  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: d,
    bevelEnabled: true,
    bevelSegments: 1,
    steps: 1,
    bevelSize: c * 0.35,
    bevelThickness: c * 0.35,
  }).toNonIndexed();
  geo.translate(0, 0, -d / 2);
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(x, y, z);
  return mesh;
}

/**
 * Builds a seamless faceted low-poly lofted mesh from an array of cross-section rings
 * (ordered from larger Z to smaller Z, vertices CCW in XY) with guaranteed outward flat normals!
 */
interface LoftRing {
  points: [number, number, number][];
}

function makeEllipseRing(
  cx: number,
  cy: number,
  z: number,
  rx: number,
  ry: number,
  segs: number,
  options?: { topArch?: number; bottomFlat?: number; twist?: number; tiltX?: number }
): LoftRing {
  const pts: [number, number, number][] = [];
  const twist = options?.twist ?? 0;
  const topArch = options?.topArch ?? 0;
  const bottomFlat = options?.bottomFlat ?? 0;
  const tiltX = options?.tiltX ?? 0;
  for (let i = 0; i < segs; i++) {
    const a = (i / segs) * Math.PI * 2 + twist;
    const ca = Math.cos(a);
    const sa = Math.sin(a);
    let x = cx + ca * rx;
    let y = cy + sa * ry;
    // Anatomical dorsal arch on top (+Y) and gentle palm flattening underneath (-Y)
    if (sa > 0) {
      y += Math.pow(sa, 1.6) * topArch;
    } else {
      y -= sa * bottomFlat;
    }
    const zOff = ca * tiltX;
    pts.push([x, y, z + zOff]);
  }
  return { points: pts };
}

function buildLoftedMesh(rings: LoftRing[], mat: THREE.Material, capStart = true, capEnd = true): THREE.Mesh {
  const positions: number[] = [];
  const segs = rings[0].points.length;

  const pushTri = (a: [number, number, number], b: [number, number, number], c: [number, number, number]) => {
    positions.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
  };

  // Detect Z progression so outward normals are 100% consistent regardless of direction
  const zStart = rings[0].points[0][2];
  const zEnd = rings[rings.length - 1].points[0][2];
  const forwardNegZ = zEnd < zStart;

  for (let r = 0; r < rings.length - 1; r++) {
    const r0 = rings[r].points;
    const r1 = rings[r + 1].points;
    for (let i = 0; i < segs; i++) {
      const ni = (i + 1) % segs;
      const a = r0[i];
      const b = r0[ni];
      const c = r1[ni];
      const d = r1[i];
      // Alternate triangulation diagonal across rings for crisp sculptural low-poly diamond facets!
      const alt = (r + i) % 2 === 0;
      if (forwardNegZ) {
        if (alt) {
          pushTri(a, d, c);
          pushTri(a, c, b);
        } else {
          pushTri(a, d, b);
          pushTri(b, d, c);
        }
      } else {
        if (alt) {
          pushTri(a, c, d);
          pushTri(a, b, c);
        } else {
          pushTri(a, b, d);
          pushTri(b, c, d);
        }
      }
    }
  }

  // Optional start & end polygon caps
  const addCap = (ring: LoftRing, flip: boolean) => {
    let cx = 0;
    let cy = 0;
    let cz = 0;
    for (const p of ring.points) {
      cx += p[0];
      cy += p[1];
      cz += p[2];
    }
    const center: [number, number, number] = [cx / segs, cy / segs, cz / segs];
    for (let i = 0; i < segs; i++) {
      const ni = (i + 1) % segs;
      if (flip) pushTri(center, ring.points[ni], ring.points[i]);
      else pushTri(center, ring.points[i], ring.points[ni]);
    }
  };

  if (capStart) addCap(rings[0], !forwardNegZ);
  if (capEnd) addCap(rings[rings.length - 1], forwardNegZ);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.computeVertexNormals();
  return new THREE.Mesh(geo, mat);
}

/**
 * Builds a single chunky sculpted faceted finger segment (wider knuckle base, pinched mid-shaft, rounded distal knuckle)
 */
function buildSculptedPhalanx(rBase: number, rTip: number, len: number): THREE.Mesh {
  const rings: LoftRing[] = [
    makeEllipseRing(0, 0, 0.003, rBase * 1.04, rBase * 0.96, 6, { twist: Math.PI / 6 }),
    makeEllipseRing(0, 0.0008, -len * 0.16, rBase * 1.08, rBase * 1.02, 6, { twist: Math.PI / 6 }),
    makeEllipseRing(0, -0.0004, -len * 0.56, (rBase + rTip) * 0.48, (rBase + rTip) * 0.45, 6, { twist: Math.PI / 6 }),
    makeEllipseRing(0, 0.0005, -len * 0.92, rTip * 1.04, rTip * 0.96, 6, { twist: Math.PI / 6 }),
    makeEllipseRing(0, -0.0005, -len - 0.003, rTip * 0.72, rTip * 0.68, 6, { twist: Math.PI / 6 }),
  ];
  return buildLoftedMesh(rings, MAT.handWhite, true, true);
}

/**
 * Sculpted stylized matte-white faceted low-poly Hand + Forearm matching the exact reference silhouette!
 * - Continuous lofted triangular faceted palm, dorsal arch, wrist pinch & knuckle ridge
 * - Sleek tapered octagonal low-poly forearm matching Panels 1, 2 & 3
 * - Chunky sculpted multi-ring faceted fingers & seamless fleshy thumb pad
 * Origin of the returned Group is centered at the PALM/GRIP anchor so rotating/positioning the arm
 * during reload, bolt-action, and shooting pivots cleanly around the hand!
 */
interface HandStyle {
  side: 'left' | 'right';
  fingerCurl: number; // 0 = flat open, 1 = tight pistol grip wrap
  indexExtended?: boolean; // trigger finger reach
  thumbSpread: number;
  thumbPitch: number;
  forearmPitch: number;
  forearmYaw: number;
  forearmLength?: number;
}

export function createSculptedLowPolyArm(style: HandStyle): THREE.Group {
  const s = style.side === 'right' ? 1 : -1;
  const group = new THREE.Group();

  // 1-3. The pack's sculpted hand (fingers hang along -Y there → rotate so they point along -Z like our grip rigs)
  const hand = createStylizedHand(FP.hand, style.side, 'grip', 0.0032, undefined, 1.4);
  const wrap = new THREE.Group();
  wrap.rotation.x = Math.PI / 2;
  wrap.position.set(0, 0, 0.05);
  wrap.add(hand);
  group.add(wrap);
  void s;

  // 4. SEAMLESS TAPERED FACETED ANATOMICAL WRIST & FOREARM (Sleek sculpted low-poly look from Gambar 1 & 2!)
  const forearmPivot = new THREE.Group();
  forearmPivot.position.set(0, -0.003, 0.048);
  forearmPivot.rotation.set(style.forearmPitch, style.forearmYaw, 0);

  const fLen = style.forearmLength ?? 0.58;
  const forearmRings: LoftRing[] = [
    // Starts cleanly inside the palm wrist socket (no gap!)
    makeEllipseRing(0, 0, -0.008, 0.030, 0.021, 8, { twist: Math.PI / 8 }),
    // Narrow sculpted wrist pinch (iconic silhouette line seen in Pistol & Sniper reference panels!)
    makeEllipseRing(0, -0.001, 0.022, 0.029, 0.022, 8, { twist: Math.PI / 8 }),
    // Lower forearm facet transition
    makeEllipseRing(0, -0.002, 0.085, 0.035, 0.029, 8, { twist: Math.PI / 8 }),
    // Muscular sculpted mid-forearm swell (subtle oval cross section)
    makeEllipseRing(0, -0.001, fLen * 0.44, 0.043, 0.038, 8, { twist: Math.PI / 8 }),
    // Upper forearm widening cleanly toward elbow off-screen
    makeEllipseRing(0, 0, fLen * 0.78, 0.048, 0.044, 8, { twist: Math.PI / 8 }),
    makeEllipseRing(0, 0, fLen, 0.052, 0.048, 8, { twist: Math.PI / 8 }),
  ];
  forearmPivot.add(buildLoftedMesh(forearmRings, FP.sleeve, true, true));

  group.add(forearmPivot);
  return group;
}

/**
 * Creates a stylized low-poly muzzle flash group tuned to each firearm type.
 */
export function createMuzzleFlash(type: WeaponId): THREE.Group {
  const g = new THREE.Group();
  g.visible = false;

  if (type === 'pistol') {
    // Crisp 4-petal faceted star + compact forward cone
    for (let i = 0; i < 4; i++) {
      const petal = makeCyl(0.002, 0.024, 0.11, 4, MAT.flashOuter);
      petal.rotation.z = (i * Math.PI) / 2 + Math.PI / 4;
      petal.position.set(Math.cos(petal.rotation.z + Math.PI / 2) * 0.045, Math.sin(petal.rotation.z + Math.PI / 2) * 0.045, -0.015);
      g.add(petal);
    }
    const forward = makeCyl(0.002, 0.036, 0.15, 5, MAT.flashOuter, 0, 0, -0.075, -Math.PI / 2);
    const core = makeCyl(0.002, 0.02, 0.09, 5, MAT.flashCore, 0, 0, -0.045, -Math.PI / 2);
    g.add(forward, core);
  } else if (type === 'rifle') {
    // 6-prong flash-hider sunburst + sharp supersonic forward flame cone
    for (let i = 0; i < 6; i++) {
      const ang = (i * Math.PI * 2) / 6;
      const spoke = makeCyl(0.002, 0.022, 0.145, 4, MAT.flashOuter);
      spoke.rotation.z = ang;
      spoke.position.set(-Math.sin(ang) * 0.065, Math.cos(ang) * 0.065, -0.02);
      g.add(spoke);
    }
    const forward = makeCyl(0.002, 0.048, 0.24, 6, MAT.flashOuter, 0, 0, -0.12, -Math.PI / 2);
    const core = makeCyl(0.002, 0.026, 0.14, 5, MAT.flashCore, 0, 0, -0.07, -Math.PI / 2);
    g.add(forward, core);
  } else {
    // SNIPER: Massive twin lateral muzzle-brake gas jets (-X and +X) + huge forward blast cone!
    const leftJet = makeCyl(0.005, 0.056, 0.34, 5, MAT.flashGas, -0.17, 0, 0.025, 0, 0, Math.PI / 2);
    const rightJet = makeCyl(0.005, 0.056, 0.34, 5, MAT.flashGas, 0.17, 0, 0.025, 0, 0, -Math.PI / 2);
    const leftJet2 = makeCyl(0.004, 0.038, 0.24, 5, MAT.flashOuter, -0.12, 0, -0.02, 0, 0.22, Math.PI / 2);
    const rightJet2 = makeCyl(0.004, 0.038, 0.24, 5, MAT.flashOuter, 0.12, 0, -0.02, 0, -0.22, -Math.PI / 2);
    const forward = makeCyl(0.003, 0.064, 0.38, 6, MAT.flashOuter, 0, 0, -0.19, -Math.PI / 2);
    const core = makeCyl(0.003, 0.034, 0.22, 6, MAT.flashCore, 0, 0, -0.1, -Math.PI / 2);
    g.add(leftJet, rightJet, leftJet2, rightJet2, forward, core);
  }

  return g;
}

/**
 * 1. PISTOL — Stylized Low-Poly 1911 / Tactical Sidearm (Matches Panel 1 of Gambar 1 & Gambar 2!)
 * Signature details:
 * - Matte charcoal beveled blocky slide with open right ejection window
 * - Prominent copper/bronze barrel hood & ejection chamber visible from top & side!
 * - Prominent copper/bronze faceted rear hammer + bronze/wood side grip panels!
 * - Two-handed symmetrical matte-white faceted arms gripping the frame!
 */
export function buildPistolRig(): WeaponRig {
  const root = new THREE.Group();
  const weaponBody = new THREE.Group();
  root.add(weaponBody);

  // --- LOWER FRAME & GRIP ---
  const lowerFrame = makeBeveledBlock(0.034, 0.022, 0.215, 0.004, MAT.gunDark, 0, 0.012, -0.052);
  weaponBody.add(lowerFrame);

  // Under-barrel tactical Picatinny rail notches
  for (let i = 0; i < 3; i++) {
    weaponBody.add(makeBox(0.024, 0.006, 0.012, MAT.gunDeepBlack, 0, -0.001, -0.112 - i * 0.02));
  }

  // Grip frame (angled slightly rearward at 16 deg)
  const gripGroup = new THREE.Group();
  gripGroup.position.set(0, -0.052, 0.024);
  gripGroup.rotation.x = 0.24;
  gripGroup.add(makeBeveledBlock(0.033, 0.118, 0.052, 0.005, MAT.gunDark, 0, 0, 0));
  // Prominent copper/bronze grip side panels (matches Panel 1!)
  gripGroup.add(makeBeveledBlock(0.039, 0.096, 0.042, 0.004, MAT.pistolBronze, 0, -0.002, 0));
  // Rear tang / beaver-tail extension
  gripGroup.add(makeBox(0.026, 0.016, 0.03, MAT.gunDark, 0, 0.06, 0.024));
  weaponBody.add(gripGroup);

  // Trigger guard
  weaponBody.add(makeBox(0.016, 0.006, 0.056, MAT.gunDark, 0, -0.034, -0.038));
  weaponBody.add(makeBox(0.016, 0.036, 0.007, MAT.gunDark, 0, -0.017, -0.064));

  // Animated Trigger
  const trigger = new THREE.Group();
  trigger.position.set(0, -0.002, -0.025);
  trigger.add(makeBox(0.008, 0.026, 0.009, MAT.gunSteel, 0, -0.013, -0.003, 0.28));
  weaponBody.add(trigger);

  // Animated Prominent Copper/Bronze Rear Hammer (Exact match to Gambar 1 & Gambar 2!)
  const hammer = new THREE.Group();
  hammer.position.set(0, 0.028, 0.054);
  hammer.add(makeBeveledBlock(0.016, 0.032, 0.018, 0.003, MAT.pistolBronze, 0, 0.01, 0.008));
  hammer.add(makeBox(0.018, 0.008, 0.018, MAT.pistolBronze, 0, 0.024, 0.014, -0.4));
  weaponBody.add(hammer);

  // Fixed Inner Barrel + Prominent Copper/Bronze Chamber Hood (Visible inside top slide cutout!)
  const barrel = makeCyl(0.009, 0.009, 0.21, 8, MAT.gunSteel, 0, 0.044, -0.095, Math.PI / 2);
  weaponBody.add(barrel);
  // Dark bore interior at muzzle
  weaponBody.add(makeCyl(0.0068, 0.0068, 0.01, 8, MAT.gunDeepBlack, 0, 0.044, -0.201, Math.PI / 2));
  // Exposed Copper/Bronze Chamber Block (Super iconic in Panel 1 of both images!)
  const chamberHood = makeBeveledBlock(0.026, 0.022, 0.046, 0.004, MAT.pistolBronze, 0.003, 0.049, -0.036);
  weaponBody.add(chamberHood);

  // --- ANIMATED TOP SLIDE (Blowback on every shot & locks back when empty!) ---
  const slide = new THREE.Group();
  // Front slide body (ahead of ejection port)
  slide.add(makeBeveledBlock(0.038, 0.038, 0.145, 0.006, MAT.gunCharcoal, 0, 0.044, -0.13));
  // Rear slide body (behind ejection port)
  slide.add(makeBeveledBlock(0.038, 0.038, 0.068, 0.006, MAT.gunCharcoal, 0, 0.044, 0.022));
  // Left wall bridge alongside ejection port (right side stays open so bronze chamber shows!)
  slide.add(makeBox(0.01, 0.036, 0.056, MAT.gunCharcoal, -0.014, 0.044, -0.036));
  // Lower right bridge under ejection port
  slide.add(makeBox(0.008, 0.012, 0.056, MAT.gunCharcoal, 0.015, 0.031, -0.036));

  // Rear slide cocking serrations (subtle faceted grooves)
  for (let i = 0; i < 4; i++) {
    slide.add(makeBox(0.04, 0.024, 0.004, MAT.gunDeepBlack, 0, 0.043, 0.004 + i * 0.01));
  }

  // Rear U-Notch Iron Sights (Left & Right posts cleanly framing the front sight!)
  slide.add(makeBox(0.011, 0.012, 0.014, MAT.gunDark, -0.012, 0.067, 0.043));
  slide.add(makeBox(0.011, 0.012, 0.014, MAT.gunDark, 0.012, 0.067, 0.043));
  slide.add(makeBox(0.004, 0.004, 0.003, MAT.handWhite, -0.011, 0.067, 0.0505));
  slide.add(makeBox(0.004, 0.004, 0.003, MAT.handWhite, 0.011, 0.067, 0.0505));

  // Front Blade Sight with copper-orange sighting dot!
  slide.add(makeBox(0.006, 0.013, 0.014, MAT.gunDark, 0, 0.067, -0.188));
  slide.add(makeBox(0.0045, 0.005, 0.004, MAT.sightOrange, 0, 0.069, -0.18));

  weaponBody.add(slide);

  // --- DETACHABLE MAGAZINE ---
  const mag = new THREE.Group();
  mag.position.set(0, -0.06, 0.026);
  mag.rotation.x = 0.24;
  mag.add(makeBox(0.024, 0.112, 0.04, MAT.gunDeepBlack, 0, 0, 0));
  mag.add(makeBeveledBlock(0.032, 0.014, 0.048, 0.003, MAT.gunDark, 0, -0.06, 0.002));
  weaponBody.add(mag);

  // --- EXACT SOCKETS ---
  const muzzleSocket = new THREE.Object3D();
  muzzleSocket.position.set(0, 0.044, -0.214);
  weaponBody.add(muzzleSocket);

  const muzzleFlash = createMuzzleFlash('pistol');
  muzzleSocket.add(muzzleFlash);

  const ejectionSocket = new THREE.Object3D();
  ejectionSocket.position.set(0.024, 0.054, -0.036);
  weaponBody.add(ejectionSocket);

  const actionSocket = new THREE.Object3D();
  actionSocket.position.set(-0.02, 0.06, -0.09);
  weaponBody.add(actionSocket);

  const magSocket = new THREE.Object3D();
  magSocket.position.set(0, -0.115, 0.042);
  weaponBody.add(magSocket);

  // --- TWO-HANDED SYMMETRICAL MATTE-WHITE POLYGON ARMS (Exact Panel 1 Reference Match!) ---
  const rightArm = createSculptedLowPolyArm({
    side: 'right',
    fingerCurl: 1.0,
    indexExtended: true,
    thumbSpread: 0.26,
    thumbPitch: 0.14,
    forearmPitch: -0.24, // sweeps forearm outward right (+X)
    forearmYaw: 0.28, // sweeps forearm downward (-Y)
    forearmLength: 0.62,
  });
  rightArm.position.set(0.032, -0.042, 0.038);
  rightArm.rotation.set(0.18, 0.08, -1.4);

  const leftArm = createSculptedLowPolyArm({
    side: 'left',
    fingerCurl: 1.04,
    indexExtended: false,
    thumbSpread: 0.2,
    thumbPitch: 0.18,
    forearmPitch: -0.24, // sweeps forearm outward left (-X)
    forearmYaw: -0.28, // sweeps forearm downward (-Y)
    forearmLength: 0.62,
  });
  leftArm.position.set(-0.036, -0.04, 0.026);
  leftArm.rotation.set(0.18, -0.08, 1.38);

  weaponBody.add(rightArm, leftArm);

  return {
    id: 'pistol',
    root,
    weaponBody,
    leftArm,
    rightArm,
    slide,
    hammer,
    mag,
    trigger,
    muzzleSocket,
    ejectionSocket,
    actionSocket,
    magSocket,
    muzzleFlash,
    leftArmRestPos: leftArm.position.clone(),
    leftArmRestRot: leftArm.rotation.clone(),
    rightArmRestPos: rightArm.position.clone(),
    rightArmRestRot: rightArm.rotation.clone(),
    magRestPos: mag.position.clone(),
    magRestRot: mag.rotation.clone(),
  };
}

/**
 * 2. RIFLE — Stylized Low-Poly M4A1 Tactical Carbine (Matches Panel 2 of Gambar 1 & Gambar 2!)
 * Signature details:
 * - Ribbed quad-rail handguard with crisp horizontal faceted ridges!
 * - Classic triangular A2 front sight post ahead of handguard!
 * - Boxy low-poly Holographic/Reflex sight with translucent emerald-green glass lens & glowing dot!
 * - T-shaped charging handle & segmented top Picatinny rail!
 * - Curved faceted 30-round detachable magazine!
 * - Right-side hinged dust cover, brass deflector, and reciprocating bolt carrier!
 */
export function buildRifleRig(): WeaponRig {
  const root = new THREE.Group();
  const weaponBody = new THREE.Group();
  root.add(weaponBody);

  // --- UPPER & LOWER RECEIVER ---
  const upperRec = makeBeveledBlock(0.056, 0.058, 0.24, 0.008, MAT.gunCharcoal, 0, 0.036, -0.03);
  weaponBody.add(upperRec);

  const lowerRec = makeBeveledBlock(0.052, 0.05, 0.215, 0.007, MAT.gunDark, 0, -0.012, -0.032);
  weaponBody.add(lowerRec);

  // Magwell flared block
  weaponBody.add(makeBeveledBlock(0.056, 0.052, 0.088, 0.006, MAT.gunDark, 0, -0.036, -0.092));

  // Brass deflector wedge & forward assist on RIGHT side (+X) behind ejection port
  weaponBody.add(makeBeveledBlock(0.016, 0.022, 0.022, 0.003, MAT.gunCharcoal, 0.032, 0.038, 0.022));
  weaponBody.add(makeCyl(0.008, 0.009, 0.036, 6, MAT.gunDark, 0.03, 0.032, 0.058, Math.PI / 2, 0, -0.3));

  // Right-side Ejection Port Recess
  weaponBody.add(makeBox(0.008, 0.024, 0.072, MAT.gunDeepBlack, 0.026, 0.038, -0.035));

  // Animated Bolt Carrier inside right ejection port!
  const bolt = new THREE.Group();
  bolt.add(makeBox(0.008, 0.02, 0.068, MAT.gunSteel, 0.028, 0.038, -0.035));
  weaponBody.add(bolt);

  // Animated Hinged Dust Cover on right ejection port (flips open on shot!)
  const dustCover = new THREE.Group();
  dustCover.position.set(0.0295, 0.025, -0.035);
  dustCover.add(makeBox(0.004, 0.024, 0.074, MAT.gunDark, 0, 0.012, 0));
  weaponBody.add(dustCover);

  // Top Receiver Picatinny Rail Teeth (clearly visible in Gambar 2!)
  weaponBody.add(makeBox(0.032, 0.009, 0.23, MAT.gunDark, 0, 0.068, -0.032));
  for (let i = 0; i < 12; i++) {
    weaponBody.add(makeBox(0.034, 0.006, 0.01, MAT.gunCharcoal, 0, 0.074, 0.072 - i * 0.019));
  }

  // Animated T-Shaped Charging Handle (Super distinct in Gambar 2!)
  const chargingHandle = new THREE.Group();
  chargingHandle.position.set(0, 0.055, 0.095);
  chargingHandle.add(makeBeveledBlock(0.082, 0.014, 0.016, 0.003, MAT.gunCharcoal, 0, 0, 0));
  chargingHandle.add(makeBox(0.018, 0.012, 0.04, MAT.gunDark, 0, 0, -0.02));
  weaponBody.add(chargingHandle);

  // --- BOXY HOLOGRAPHIC / REFLEX SIGHT WITH EMERALD-GREEN GLASS (Exact match to Gambar 1 & 2!) ---
  const optic = new THREE.Group();
  optic.position.set(0, 0.076, -0.078);
  // Base mount
  optic.add(makeBeveledBlock(0.044, 0.02, 0.105, 0.005, MAT.gunDark, 0, 0.01, 0));
  // Left & Right protective hood walls + Top roof bridge (open center sight window!)
  optic.add(makeBeveledBlock(0.01, 0.048, 0.088, 0.003, MAT.gunCharcoal, -0.022, 0.042, 0.002));
  optic.add(makeBeveledBlock(0.01, 0.048, 0.088, 0.003, MAT.gunCharcoal, 0.022, 0.042, 0.002));
  optic.add(makeBeveledBlock(0.054, 0.011, 0.088, 0.003, MAT.gunCharcoal, 0, 0.066, 0.002));
  // Angled front battery housing hood
  optic.add(makeBeveledBlock(0.048, 0.028, 0.038, 0.005, MAT.gunDark, 0, 0.022, -0.046));
  // Translucent Green Glass Lens
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(0.036, 0.042), MAT.holoGlass);
  glass.position.set(0, 0.042, 0.006);
  optic.add(glass);
  // Glowing Red/Green Holographic Reticle Dot + crisp thin outer ring!
  const holoReticle = new THREE.Mesh(
    new THREE.CircleGeometry(0.0022, 8),
    new THREE.MeshBasicMaterial({ color: 0xff3b30 })
  );
  holoReticle.position.set(0, 0.042, 0.007);
  optic.add(holoReticle);
  const holoRing = new THREE.Mesh(
    new THREE.RingGeometry(0.0075, 0.0088, 16),
    new THREE.MeshBasicMaterial({ color: 0x54ff9f, transparent: true, opacity: 0.72, side: THREE.DoubleSide })
  );
  holoRing.position.set(0, 0.042, 0.007);
  optic.add(holoRing);
  weaponBody.add(optic);

  // --- RIBBED QUAD-RAIL HANDGUARD (Signature Panel 2 Polygon Detail!) ---
  const handguardLen = 0.29;
  const handguardZ = -0.305;
  // Delta ring collar
  weaponBody.add(makeCyl(0.034, 0.036, 0.028, 8, MAT.gunDeepBlack, 0, 0.038, -0.158, Math.PI / 2));
  // Core octagonal handguard shroud
  weaponBody.add(makeCyl(0.029, 0.031, handguardLen, 8, MAT.gunDark, 0, 0.038, handguardZ, Math.PI / 2));
  // Crisp repeating faceted quad-rail ribs (top, bottom, left, right!)
  for (let i = 0; i < 11; i++) {
    const rz = -0.185 - i * 0.024;
    weaponBody.add(makeBox(0.026, 0.009, 0.013, MAT.gunCharcoal, 0, 0.068, rz)); // top rail tooth
    weaponBody.add(makeBox(0.026, 0.009, 0.013, MAT.gunCharcoal, 0, 0.008, rz)); // bottom rail tooth
    weaponBody.add(makeBox(0.009, 0.024, 0.013, MAT.gunCharcoal, -0.031, 0.038, rz)); // left rail tooth
    weaponBody.add(makeBox(0.009, 0.024, 0.013, MAT.gunCharcoal, 0.031, 0.038, rz)); // right rail tooth
  }

  // --- CLASSIC A2 TRIANGULAR FRONT SIGHT POST (Exact match to Gambar 1 & Gambar 2!) ---
  const frontSight = new THREE.Group();
  frontSight.position.set(0, 0.038, -0.495);
  // Base gas block clamp
  frontSight.add(makeBeveledBlock(0.028, 0.032, 0.044, 0.004, MAT.gunDark, 0, 0.004, 0));
  // Slanted rear & front A-frame struts forming classic M4 triangle
  frontSight.add(makeBox(0.012, 0.072, 0.012, MAT.gunCharcoal, 0, 0.048, 0.015, 0.34));
  frontSight.add(makeBox(0.012, 0.072, 0.012, MAT.gunCharcoal, 0, 0.048, -0.015, -0.34));
  // Sight protector ears + center front post pin
  frontSight.add(makeBox(0.005, 0.022, 0.012, MAT.gunDark, -0.008, 0.082, 0));
  frontSight.add(makeBox(0.005, 0.022, 0.012, MAT.gunDark, 0.008, 0.082, 0));
  frontSight.add(makeBox(0.004, 0.016, 0.004, MAT.sightOrange, 0, 0.08, 0));
  weaponBody.add(frontSight);

  // --- BARREL & BIRDCAGE FLASH HIDER ---
  weaponBody.add(makeCyl(0.012, 0.013, 0.25, 8, MAT.gunDeepBlack, 0, 0.038, -0.56, Math.PI / 2));
  // Slotted birdcage flash hider
  weaponBody.add(makeCyl(0.0155, 0.0155, 0.062, 8, MAT.gunCharcoal, 0, 0.038, -0.695, Math.PI / 2));
  weaponBody.add(makeCyl(0.01, 0.01, 0.012, 8, MAT.gunDeepBlack, 0, 0.038, -0.727, Math.PI / 2));

  // --- COLLAPSIBLE CRANE BUTTSTOCK (Prominent in bottom-center of Gambar 2!) ---
  const stock = new THREE.Group();
  stock.position.set(0, 0.028, 0.1);
  // Buffer tube
  stock.add(makeCyl(0.022, 0.022, 0.22, 8, MAT.gunDark, 0, 0.006, 0.11, Math.PI / 2));
  // Sloped faceted cheek rest & buttplate
  stock.add(makeBeveledBlock(0.056, 0.062, 0.23, 0.01, MAT.gunCharcoal, 0, 0.002, 0.195));
  stock.add(makeBeveledBlock(0.046, 0.112, 0.055, 0.007, MAT.gunDark, 0, -0.032, 0.285));
  stock.add(makeBox(0.044, 0.115, 0.014, MAT.gunDeepBlack, 0, -0.034, 0.314));
  weaponBody.add(stock);

  // --- PISTOL GRIP & TRIGGER ---
  const grip = new THREE.Group();
  grip.position.set(0, -0.086, 0.042);
  grip.rotation.x = 0.36;
  grip.add(makeBeveledBlock(0.036, 0.125, 0.05, 0.006, MAT.gunDark, 0, 0, 0));
  weaponBody.add(grip);

  // Trigger guard + trigger
  weaponBody.add(makeBox(0.016, 0.006, 0.066, MAT.gunDark, 0, -0.066, -0.018));
  const trigger = new THREE.Group();
  trigger.position.set(0, -0.032, -0.008);
  trigger.add(makeBox(0.007, 0.028, 0.008, MAT.gunSteel, 0, -0.014, -0.002, 0.28));
  weaponBody.add(trigger);

  // --- CURVED 30-ROUND STANAG MAGAZINE (Exact curved faceted look of Panel 2 Gambar 1!) ---
  const mag = new THREE.Group();
  mag.position.set(0, -0.07, -0.094);
  // Upper straight segment entering magwell
  mag.add(makeBeveledBlock(0.03, 0.11, 0.072, 0.004, MAT.gunCharcoal, 0, -0.025, 0));
  // Lower forward-curving segment
  const magLower = makeBeveledBlock(0.03, 0.125, 0.072, 0.004, MAT.gunCharcoal, 0, -0.125, -0.018);
  magLower.rotation.x = -0.24;
  mag.add(magLower);
  // Ribbing lines on magazine sides
  for (let i = -1; i <= 1; i += 2) {
    mag.add(makeBox(0.033, 0.105, 0.008, MAT.gunDark, 0, -0.03, i * 0.014));
    const ribLow = makeBox(0.033, 0.11, 0.008, MAT.gunDark, 0, -0.125, -0.018 + i * 0.014);
    ribLow.rotation.x = -0.24;
    mag.add(ribLow);
  }
  weaponBody.add(mag);

  // --- EXACT SOCKETS ---
  const muzzleSocket = new THREE.Object3D();
  muzzleSocket.position.set(0, 0.038, -0.732);
  weaponBody.add(muzzleSocket);

  const muzzleFlash = createMuzzleFlash('rifle');
  muzzleSocket.add(muzzleFlash);

  const ejectionSocket = new THREE.Object3D();
  ejectionSocket.position.set(0.034, 0.04, -0.032);
  weaponBody.add(ejectionSocket);

  const actionSocket = new THREE.Object3D();
  actionSocket.position.set(0.028, 0.056, -0.032);
  weaponBody.add(actionSocket);

  const magSocket = new THREE.Object3D();
  magSocket.position.set(0, -0.17, -0.112);
  weaponBody.add(magSocket);

  // --- MATTE-WHITE FACETED POLYGON HANDS (Exact Gambar 1 & Gambar 2!) ---
  // Right hand firmly wrapping the M4 pistol grip with chunky stacked curled white fingers (Exact Panel 2 Reference Match!)
  const rightArm = createSculptedLowPolyArm({
    side: 'right',
    fingerCurl: 1.08,
    indexExtended: true,
    thumbSpread: 0.34,
    thumbPitch: 0.16,
    forearmPitch: -0.24,
    forearmYaw: 0.32,
    forearmLength: 0.58,
  });
  rightArm.position.set(0.029, -0.094, 0.05);
  rightArm.rotation.set(0.34, 0.08, -1.44);

  // Left hand tucked snugly under the ribbed quad-rail handguard; forearm angles steeply down-back toward left shoulder
  const leftArm = createSculptedLowPolyArm({
    side: 'left',
    fingerCurl: 0.88,
    indexExtended: false,
    thumbSpread: 0.36,
    thumbPitch: 0.14,
    forearmPitch: -0.44,
    forearmYaw: -0.24,
    forearmLength: 0.6,
  });
  leftArm.position.set(-0.022, -0.028, -0.275);
  leftArm.rotation.set(0.14, -0.12, 2.44);

  weaponBody.add(rightArm, leftArm);

  return {
    id: 'rifle',
    root,
    weaponBody,
    leftArm,
    rightArm,
    bolt,
    dustCover,
    chargingHandle,
    mag,
    trigger,
    holoReticle,
    muzzleSocket,
    ejectionSocket,
    actionSocket,
    magSocket,
    muzzleFlash,
    leftArmRestPos: leftArm.position.clone(),
    leftArmRestRot: leftArm.rotation.clone(),
    rightArmRestPos: rightArm.position.clone(),
    rightArmRestRot: rightArm.rotation.clone(),
    magRestPos: mag.position.clone(),
    magRestRot: mag.rotation.clone(),
  };
}

/**
 * 3. SNIPER — Stylized Low-Poly Bolt-Action Marksman Rifle (Matches Panel 3 of Gambar 1 & Gambar 2!)
 * Signature details:
 * - Angular matte-charcoal faceted tactical chassis & long free-float octagonal barrel
 * - Heavy slotted dual-chamber muzzle brake (fires twin lateral gas jets + forward flash!)
 * - Large faceted low-poly telescopic scope with wide tapered front bell, central turret knobs,
 *   and rear dark glossy eyepiece lens!
 * - Animated rotating & sliding Bolt + Bolt Handle on right side (+X)
 */
export function buildSniperRig(scopeTexture?: THREE.Texture): WeaponRig {
  const root = new THREE.Group();
  const weaponBody = new THREE.Group();
  root.add(weaponBody);

  // --- HEAVY FACETED CHASSIS & RECEIVER ---
  const receiver = makeBeveledBlock(0.062, 0.064, 0.29, 0.009, MAT.gunCharcoal, 0, 0.028, -0.05);
  weaponBody.add(receiver);

  // Long angular chamfered forend chassis extending toward barrel
  const forend = makeBeveledBlock(0.058, 0.056, 0.36, 0.01, MAT.gunDark, 0, 0.016, -0.355);
  weaponBody.add(forend);
  // Subtle cooling slots along forend flanks
  for (let i = 0; i < 4; i++) {
    weaponBody.add(makeBox(0.061, 0.01, 0.044, MAT.gunDeepBlack, 0, 0.022, -0.24 - i * 0.066));
  }

  // Right-side Bolt Ejection Port Cutout
  weaponBody.add(makeBox(0.012, 0.026, 0.095, MAT.gunDeepBlack, 0.028, 0.036, -0.055));

  // --- ANIMATED BOLT & ROTATING BOLT HANDLE (Right side +X) ---
  const bolt = new THREE.Group();
  bolt.position.set(0, 0.036, -0.02);
  // Cylindrical faceted steel bolt body visible inside ejection port
  bolt.add(makeCyl(0.013, 0.013, 0.145, 8, MAT.gunSteel, 0.014, 0, -0.015, Math.PI / 2));
  // Bolt rear shroud cap
  bolt.add(makeBeveledBlock(0.036, 0.034, 0.04, 0.006, MAT.gunCharcoal, 0, 0.002, 0.075));

  // Pivoting Bolt Handle (lifts UP 60 deg before bolt pulls back!)
  const boltHandle = new THREE.Group();
  boltHandle.position.set(0.016, 0.0, 0.045);
  // Angled bolt lever arm (high-contrast brushed steel so bolt cycle reads super cleanly!)
  boltHandle.add(makeCyl(0.0072, 0.0082, 0.064, 6, MAT.gunSteel, 0.03, -0.009, 0.005, 0, 0, Math.PI / 2 + 0.32));
  // Faceted tactical bolt knob sphere/icosahedron
  const knobGeo = new THREE.IcosahedronGeometry(0.017, 0).toNonIndexed();
  knobGeo.computeVertexNormals();
  const knob = new THREE.Mesh(knobGeo, MAT.gunCharcoal);
  knob.position.set(0.064, -0.022, 0.008);
  boltHandle.add(knob);
  bolt.add(boltHandle);
  weaponBody.add(bolt);

  // --- TOP PICATINNY RAIL & HEAVY SCOPE RINGS ---
  weaponBody.add(makeBox(0.032, 0.01, 0.28, MAT.gunDark, 0, 0.064, -0.07));
  for (let i = 0; i < 11; i++) {
    weaponBody.add(makeBox(0.034, 0.005, 0.011, MAT.gunCharcoal, 0, 0.071, 0.055 - i * 0.023));
  }
  // Two heavy faceted scope ring mounts
  weaponBody.add(makeBeveledBlock(0.042, 0.048, 0.028, 0.006, MAT.gunDark, 0, 0.096, 0.012));
  weaponBody.add(makeBeveledBlock(0.042, 0.048, 0.028, 0.006, MAT.gunDark, 0, 0.096, -0.148));

  // --- PROMINENT FACETED LOW-POLY TELESCOPIC SNIPER SCOPE (Exact Panel 3 Match!) ---
  const scope = new THREE.Group();
  scope.position.set(0, 0.124, -0.068);
  // Main central scope tube (10-sided faceted cylinder)
  scope.add(makeCyl(0.022, 0.022, 0.25, 10, MAT.gunCharcoal, 0, 0, 0, Math.PI / 2));
  // Central turret saddle cube
  scope.add(makeBeveledBlock(0.05, 0.05, 0.052, 0.008, MAT.gunDark, 0, 0, 0));
  // Top Elevation Turret Knob (very clear in Gambar 1 & Gambar 2!)
  scope.add(makeCyl(0.018, 0.019, 0.028, 10, MAT.gunCharcoal, 0, 0.036, 0));
  scope.add(makeCyl(0.021, 0.021, 0.012, 10, MAT.gunDark, 0, 0.046, 0));
  // Right Windage Turret Knob
  scope.add(makeCyl(0.017, 0.018, 0.026, 10, MAT.gunCharcoal, 0.035, 0, 0, 0, 0, Math.PI / 2));
  // Left Parallax Knob
  scope.add(makeCyl(0.015, 0.016, 0.022, 10, MAT.gunCharcoal, -0.032, 0, 0, 0, 0, Math.PI / 2));

  // Wide Tapered Front Objective Bell (signature Panel 3 silhouette!)
  scope.add(makeCyl(0.044, 0.023, 0.095, 10, MAT.gunCharcoal, 0, 0, -0.165, -Math.PI / 2));
  scope.add(makeCyl(0.045, 0.045, 0.072, 10, MAT.gunDark, 0, 0, -0.246, Math.PI / 2));
  scope.add(makeCyl(0.038, 0.038, 0.008, 10, MAT.scopeLens, 0, 0, -0.281, Math.PI / 2));

  // Rear Ocular Eyepiece Housing — OPEN-ENDED HOLLOW CYLINDERS (Zero Z-Fighting, crystal-clear glass!)
  scope.add(makeCyl(0.036, 0.023, 0.068, 20, MAT.gunCharcoal, 0, 0, 0.148, Math.PI / 2, 0, 0, true));
  scope.add(makeCyl(0.0375, 0.036, 0.056, 20, MAT.gunDark, 0, 0, 0.206, Math.PI / 2, 0, 0, true));
  scope.add(makeCyl(0.0385, 0.0375, 0.016, 20, MAT.gunDeepBlack, 0, 0, 0.234, Math.PI / 2, 0, 0, true));

  // Dark inner backstop deep behind the magnifying glass lens
  const ocuBackstop = new THREE.Mesh(
    new THREE.CircleGeometry(0.034, 24),
    new THREE.MeshBasicMaterial({ color: 0x050709 })
  );
  ocuBackstop.position.set(0, 0, 0.195);
  scope.add(ocuBackstop);

  // Slim Matte Rubberized Eyepiece Bezel Ring + Live 4.7x Magnifying Glass Lens (z = 0.242 -> weaponBody z = +0.174)!
  const lensLocalZ = 0.241;
  const ocuBezelRim = new THREE.Mesh(new THREE.RingGeometry(0.0322, 0.0388, 32), MAT.gunDeepBlack);
  ocuBezelRim.position.set(0, 0, lensLocalZ + 0.0014);
  scope.add(ocuBezelRim);

  const { material: liveScopeMat, uniforms: scopeLensUniforms } =
    createLiveMagnifyingScopeMaterial(scopeTexture);
  const ocuMagnifyingLens = new THREE.Mesh(new THREE.CircleGeometry(0.0332, 36), liveScopeMat);
  ocuMagnifyingLens.position.set(0, 0, lensLocalZ);
  scope.add(ocuMagnifyingLens);

  weaponBody.add(scope);

  // --- LONG FREE-FLOAT BARREL & DUAL-CHAMBER MUZZLE BRAKE ---
  weaponBody.add(makeCyl(0.015, 0.019, 0.44, 8, MAT.gunCharcoal, 0, 0.034, -0.68, Math.PI / 2));
  // Chunky slotted tactical muzzle brake
  const brake = makeBeveledBlock(0.042, 0.036, 0.092, 0.006, MAT.gunDark, 0, 0.034, -0.925);
  weaponBody.add(brake);
  // Lateral gas exhaust vent cutouts on brake
  weaponBody.add(makeBox(0.045, 0.018, 0.022, MAT.gunDeepBlack, 0, 0.034, -0.905));
  weaponBody.add(makeBox(0.045, 0.018, 0.022, MAT.gunDeepBlack, 0, 0.034, -0.94));

  // --- TACTICAL PRECISION BUTTSTOCK & PISTOL GRIP ---
  const stock = new THREE.Group();
  stock.position.set(0, 0.016, 0.095);
  stock.add(makeBeveledBlock(0.052, 0.072, 0.27, 0.009, MAT.gunDark, 0, 0.004, 0.14));
  // Adjustable cheek riser
  stock.add(makeBeveledBlock(0.054, 0.024, 0.14, 0.006, MAT.gunCharcoal, 0, 0.046, 0.145));
  // Rear rubber buttpad
  stock.add(makeBeveledBlock(0.05, 0.118, 0.038, 0.006, MAT.gunDeepBlack, 0, -0.018, 0.28));
  weaponBody.add(stock);

  const grip = new THREE.Group();
  grip.position.set(0, -0.068, 0.066);
  grip.rotation.x = 0.28;
  grip.add(makeBeveledBlock(0.038, 0.12, 0.052, 0.006, MAT.gunDark, 0, 0, 0));
  weaponBody.add(grip);

  // Trigger guard & trigger
  weaponBody.add(makeBox(0.018, 0.006, 0.068, MAT.gunDark, 0, -0.052, 0.005));
  const trigger = new THREE.Group();
  trigger.position.set(0, -0.016, 0.014);
  trigger.add(makeBox(0.006, 0.028, 0.008, MAT.gunSteel, 0, -0.014, -0.002, 0.24));
  weaponBody.add(trigger);

  // --- DETACHABLE 5-ROUND SNIPER BOX MAGAZINE ---
  const mag = new THREE.Group();
  mag.position.set(0, -0.048, -0.095);
  mag.add(makeBeveledBlock(0.038, 0.094, 0.096, 0.005, MAT.gunDeepBlack, 0, -0.018, 0));
  mag.add(makeBeveledBlock(0.044, 0.014, 0.102, 0.003, MAT.gunCharcoal, 0, -0.066, 0));
  weaponBody.add(mag);

  // --- EXACT SOCKETS ---
  const muzzleSocket = new THREE.Object3D();
  muzzleSocket.position.set(0, 0.034, -0.975);
  weaponBody.add(muzzleSocket);

  const muzzleFlash = createMuzzleFlash('sniper');
  muzzleSocket.add(muzzleFlash);

  const ejectionSocket = new THREE.Object3D();
  ejectionSocket.position.set(0.038, 0.044, -0.052);
  weaponBody.add(ejectionSocket);

  const actionSocket = new THREE.Object3D();
  actionSocket.position.set(0.065, 0.035, 0.025);
  weaponBody.add(actionSocket);

  const magSocket = new THREE.Object3D();
  magSocket.position.set(0, -0.11, -0.095);
  weaponBody.add(magSocket);

  // --- MATTE-WHITE FACETED POLYGON HANDS (Exact Panel 3 Gambar 1 & Gambar 2!) ---
  // Right hand gripping rear sniper grip with chunky faceted curled fingers (Exact Panel 3 Reference Match!)
  const rightArm = createSculptedLowPolyArm({
    side: 'right',
    fingerCurl: 1.06,
    indexExtended: true,
    thumbSpread: 0.34,
    thumbPitch: 0.15,
    forearmPitch: -0.24,
    forearmYaw: 0.3,
    forearmLength: 0.58,
  });
  rightArm.position.set(0.031, -0.074, 0.068);
  rightArm.rotation.set(0.32, 0.08, -1.44);

  // Left hand cupping the left-bottom flank of the angular sniper chassis with sleek tapered white forearm down-left!
  const leftArm = createSculptedLowPolyArm({
    side: 'left',
    fingerCurl: 0.84,
    indexExtended: false,
    thumbSpread: 0.32,
    thumbPitch: 0.14,
    forearmPitch: -0.3,
    forearmYaw: -0.34,
    forearmLength: 0.64,
  });
  leftArm.position.set(-0.036, -0.018, -0.27);
  leftArm.rotation.set(0.12, -0.14, 1.98);

  weaponBody.add(rightArm, leftArm);

  return {
    id: 'sniper',
    root,
    weaponBody,
    leftArm,
    rightArm,
    bolt,
    boltHandle,
    mag,
    trigger,
    scopeLensUniforms,
    muzzleSocket,
    ejectionSocket,
    actionSocket,
    magSocket,
    muzzleFlash,
    leftArmRestPos: leftArm.position.clone(),
    leftArmRestRot: leftArm.rotation.clone(),
    rightArmRestPos: rightArm.position.clone(),
    rightArmRestRot: rightArm.rotation.clone(),
    magRestPos: mag.position.clone(),
    magRestRot: mag.rotation.clone(),
  };
}

export function buildLegacyWeaponRigs(sniperScopeTexture?: THREE.Texture): Record<WeaponId, WeaponRig> {
  return {
    pistol: buildPistolRig(),
    rifle: buildRifleRig(),
    sniper: buildSniperRig(sniperScopeTexture),
  };
}

// (kept for reference — the old sculpted phalanx builder)
void buildSculptedPhalanx;
