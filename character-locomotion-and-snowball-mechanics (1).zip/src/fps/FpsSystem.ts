import * as THREE from 'three';
import { soundEngine } from './audio';
import { WEAPON_SPECS, WeaponAnimState, WeaponId, WeaponSpec } from './types';
import { buildAllWeaponRigs } from './splatGuns';
import { WeaponRig } from './weaponModels';

/**
 * First-person weapon + camera system, ported from the PIGEON "PolyBallisticsEngine":
 *  - separate viewmodel scene/camera (hands + gun never clip into the world)
 *  - free-aim deadzone, elastic chest follow, C-infinity gimbal bob, breathing, trauma, landing jolt
 *  - procedural recoil springs, ADS, sprint low-ready, reload / bolt-cycle / inspect animations
 *  - muzzle flash + light, brass ejection, tracers, sniper contrail, muzzle smoke
 *  - live picture-in-picture sniper scope
 */

export type AmmoType = 'BULLET' | 'SNOWBALL';

interface Pose {
  pos: THREE.Vector3;
  rot: THREE.Euler;
}

const WEAPON_POSES: Record<WeaponId, { ready: Pose; ads: Pose; reload: Pose; bolt: Pose; sprint: Pose }> = {
  pistol: {
    ready: { pos: new THREE.Vector3(0.015, -0.115, -0.45), rot: new THREE.Euler(0.025, 0.0, -0.025) },
    ads: { pos: new THREE.Vector3(0.0, -0.068, -0.36), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(-0.005, -0.105, -0.42), rot: new THREE.Euler(0.16, 0.27, -0.21) },
    bolt: { pos: new THREE.Vector3(0.015, -0.115, -0.45), rot: new THREE.Euler(0.025, 0.0, -0.025) },
    sprint: { pos: new THREE.Vector3(0.0, -0.17, -0.43), rot: new THREE.Euler(-0.34, 0.12, -0.1) },
  },
  rifle: {
    ready: { pos: new THREE.Vector3(0.02, -0.125, -0.37), rot: new THREE.Euler(0.02, 0.0, -0.03) },
    ads: { pos: new THREE.Vector3(0.0, -0.118, -0.25), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(0.06, -0.135, -0.46), rot: new THREE.Euler(0.23, 0.56, -0.48) },
    bolt: { pos: new THREE.Vector3(0.02, -0.125, -0.37), rot: new THREE.Euler(0.02, 0.0, -0.03) },
    sprint: { pos: new THREE.Vector3(0.03, -0.175, -0.38), rot: new THREE.Euler(-0.3, 0.26, -0.18) },
  },
  sniper: {
    ready: { pos: new THREE.Vector3(0.095, -0.14, -0.42), rot: new THREE.Euler(0.025, 0.055, -0.045) },
    ads: { pos: new THREE.Vector3(0.0, -0.124, -0.285), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(0.065, -0.13, -0.46), rot: new THREE.Euler(0.2, 0.46, -0.34) },
    bolt: { pos: new THREE.Vector3(0.075, -0.135, -0.44), rot: new THREE.Euler(0.14, 0.3, -0.24) },
    sprint: { pos: new THREE.Vector3(0.05, -0.19, -0.44), rot: new THREE.Euler(-0.28, 0.3, -0.16) },
  },
};

const FPS_BASE_FOV = 84;
const FPS_VM_FOV = 60;
const ADS_WORLD_FOV: Record<WeaponId, number> = { pistol: 58, rifle: 52, sniper: 46 };

export interface FpsFrameInput {
  dt: number;
  position: THREE.Vector3; // feet position
  eyeHeight: number;
  horizSpeed: number;
  velX: number;
  velZ: number;
  isGrounded: boolean;
  landImpact: number; // >0 on the frame the player lands
  crouchBlend: number;
  sprinting: boolean;
  strafeInput: number; // -1 left … +1 right
  fireHeld: boolean;
  adsHeld: boolean;
  fireRateMult: number;
}

export interface FpsActions {
  fireJustPressed: boolean;
  reload: boolean;
  inspect: boolean;
  adsToggle: boolean;
  weaponSlot: number; // 0 = none, 1..3
}

export interface ShotRequest {
  origin: THREE.Vector3;
  dir: THREE.Vector3;
  muzzle: THREE.Vector3;
  weaponId: WeaponId;
  ammoType: AmmoType;
  spec: WeaponSpec;
}

export interface FpsHooks {
  onShot: (req: ShotRequest) => void;
  onFootstep: (foot: 'left' | 'right', stance: 'crouch' | 'walk' | 'sprint') => void;
  playSnowShot: () => void;
}

interface ShellCasing {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  age: number;
  maxAge: number;
  bounces: number;
  weapon: WeaponId;
}

interface TracerBullet {
  mesh: THREE.Mesh;
  start: THREE.Vector3;
  dir: THREE.Vector3;
  distTotal: number;
  distTraveled: number;
  speed: number;
}

interface ContrailLine {
  mesh: THREE.Mesh;
  age: number;
  maxAge: number;
}

interface SmokeParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  gravity: number;
  age: number;
  maxAge: number;
  startScale: number;
  endScale: number;
}

export class FpsSystem {
  public readonly worldCamera: THREE.PerspectiveCamera;
  public readonly vmScene = new THREE.Scene();
  public readonly vmCamera: THREE.PerspectiveCamera;
  private readonly worldScene: THREE.Scene;
  private readonly hooks: FpsHooks;
  private readonly groundHeight: (x: number, z: number) => number;

  private vmHemiLight: THREE.HemisphereLight;
  private vmSunLight: THREE.DirectionalLight;
  private vmMuzzleLight: THREE.PointLight;

  private scopeRT: THREE.WebGLRenderTarget;
  private scopeCamera: THREE.PerspectiveCamera;
  private rigs: Record<WeaponId, WeaponRig>;

  // ----- look state (three.js camera convention: rYaw = camera.rotation.y, 0 faces -Z) -----
  public rYaw = Math.PI;
  public pitch = 0;
  public freeAimYaw = 0;
  public freeAimPitch = 0;
  private turnRoll = 0;
  private swayX = 0;
  private swayY = 0;

  // ----- camera feel -----
  private moveBobTime = 0;
  private lastFootstepIdx = 0;
  private moveSpeedNorm = 0;
  private sprintBlend = 0;
  private crouchBlend = 0;
  private smoothCamBobX = 0;
  private smoothCamBobY = 0;
  private smoothCamPitch = 0;
  private smoothRollZ = 0;
  private camRecoilPitch = 0;
  private camRecoilVel = 0;
  private camTrauma = 0;
  private landJolt = 0;
  private landJoltVel = 0;
  private adrenaline = 0;
  private rawTime = 0;
  private fireRateMult = 1;

  // ----- weapon state -----
  public weaponId: WeaponId = 'rifle';
  public ammoType: AmmoType = 'BULLET';
  private ammoMap: Record<WeaponId, number> = {
    pistol: WEAPON_SPECS.pistol.magSize,
    rifle: WEAPON_SPECS.rifle.magSize,
    sniper: WEAPON_SPECS.sniper.magSize,
  };
  public animState: WeaponAnimState = 'ready';
  private fireCooldown = 0;
  private equipTimer = 0;
  private reloadTimer = 0;
  private reloadDuration = 1.75;
  private reloadStageTriggered = new Set<string>();
  private boltTimer = 0;
  private boltDuration = 1.05;
  private boltStageTriggered = new Set<string>();
  private inspectTimer = 0;
  public adsBlend = 0;
  private adsToggle = false;
  private muzzleFlashTimer = 0;
  private triggerPullTimer = 0;
  private slideKick = 0;
  private rifleBoltKick = 0;
  private rifleDustCoverOpen = false;
  private recoilPosZ = 0;
  private recoilRotX = 0;
  private recoilRotY = 0;
  private recoilRotZ = 0;
  public spreadBloom = 0;
  private sprintRaise = 0;
  private curVmPos = new THREE.Vector3();
  private curVmRot = new THREE.Euler();

  // ----- FX -----
  private shells: ShellCasing[] = [];
  private tracers: TracerBullet[] = [];
  private contrails: ContrailLine[] = [];
  private smoke: SmokeParticle[] = [];
  private brassMat = new THREE.MeshStandardMaterial({ color: 0xe8b954, roughness: 0.25, metalness: 0.88, flatShading: true });
  private shellGeos: Record<WeaponId, THREE.BufferGeometry>;
  private tracerGeoByWeapon: Record<WeaponId, THREE.BufferGeometry>;
  private tracerMatByWeapon: Record<WeaponId, THREE.MeshBasicMaterial>;
  private snowTracerMat = new THREE.MeshBasicMaterial({ color: 0xe6f6ff, transparent: true, opacity: 0.95 });
  private smokeGeo = new THREE.IcosahedronGeometry(0.11, 0).toNonIndexed();
  private smokeMatBase = new THREE.MeshStandardMaterial({
    color: 0xeef4f8,
    roughness: 0.95,
    transparent: true,
    opacity: 0.58,
    flatShading: true,
    depthWrite: false,
  });
  private smokeMatPool: THREE.MeshStandardMaterial[] = [];
  private smokeMatIdx = 0;

  private tmpV1 = new THREE.Vector3();
  private tmpV2 = new THREE.Vector3();
  private tmpEuler = new THREE.Euler();

  constructor(
    worldScene: THREE.Scene,
    aspect: number,
    groundHeight: (x: number, z: number) => number,
    hooks: FpsHooks
  ) {
    this.worldScene = worldScene;
    this.groundHeight = groundHeight;
    this.hooks = hooks;

    this.worldCamera = new THREE.PerspectiveCamera(FPS_BASE_FOV, aspect, 0.05, 420);
    this.worldCamera.rotation.order = 'YXZ';
    this.vmCamera = new THREE.PerspectiveCamera(FPS_VM_FOV, aspect, 0.01, 10);

    // viewmodel lighting (sculptural daylight so every faceted hand plane reads clearly)
    this.vmHemiLight = new THREE.HemisphereLight(0xd2e6fb, 0x677b93, 0.62);
    this.vmScene.add(this.vmHemiLight);
    this.vmSunLight = new THREE.DirectionalLight(0xfff9ee, 1.1);
    this.vmSunLight.position.set(2.8, 3.5, 1.2);
    this.vmScene.add(this.vmSunLight);
    const rim = new THREE.DirectionalLight(0xa4c9ea, 0.26);
    rim.position.set(-2.8, 1.0, -1.8);
    this.vmScene.add(rim);
    this.vmMuzzleLight = new THREE.PointLight(0xffa73b, 0, 2.5);
    this.vmScene.add(this.vmMuzzleLight);

    // live sniper scope (picture-in-picture magnifier)
    this.scopeRT = new THREE.WebGLRenderTarget(768, 768, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: THREE.HalfFloatType,
      depthBuffer: true,
      samples: 4,
    });
    this.scopeCamera = new THREE.PerspectiveCamera(14.5, 1.0, 0.2, 380);
    this.scopeCamera.rotation.order = 'YXZ';

    this.rigs = buildAllWeaponRigs(this.scopeRT.texture);
    (Object.keys(this.rigs) as WeaponId[]).forEach((id) => {
      this.rigs[id].root.visible = id === this.weaponId;
      this.vmScene.add(this.rigs[id].root);
    });

    this.shellGeos = {
      pistol: new THREE.CylinderGeometry(0.0065, 0.0065, 0.024, 6).toNonIndexed(),
      rifle: new THREE.CylinderGeometry(0.0052, 0.0072, 0.044, 6).toNonIndexed(),
      sniper: new THREE.CylinderGeometry(0.0068, 0.0095, 0.068, 7).toNonIndexed(),
    };
    const mk = (len: number, rad: number) => {
      const g = new THREE.CylinderGeometry(rad * 0.5, rad, len, 5);
      g.rotateX(Math.PI / 2);
      return g;
    };
    this.tracerGeoByWeapon = { pistol: mk(1.35, 0.015), rifle: mk(2.1, 0.015), sniper: mk(3.2, 0.024) };
    this.tracerMatByWeapon = {
      pistol: new THREE.MeshBasicMaterial({ color: 0xffd066, transparent: true, opacity: 0.95 }),
      rifle: new THREE.MeshBasicMaterial({ color: 0xffd066, transparent: true, opacity: 0.95 }),
      sniper: new THREE.MeshBasicMaterial({ color: 0xfff5ba, transparent: true, opacity: 0.95 }),
    };
    this.smokeGeo.computeVertexNormals();

    const startPose = WEAPON_POSES[this.weaponId].ready;
    this.curVmPos.copy(startPose.pos);
    this.curVmRot.copy(startPose.rot);
    this.vmCamera.updateMatrixWorld(true);
  }

  // ===========================================================================
  //  Public API
  // ===========================================================================

  /** Game-convention yaw (0 faces +Z, forward = (sin y, cos y)) used by MovementController */
  public get gameYaw(): number {
    return this.rYaw - Math.PI;
  }

  public get spec(): WeaponSpec {
    return WEAPON_SPECS[this.weaponId];
  }

  public get ammo(): number {
    return this.ammoMap[this.weaponId];
  }

  public get isScoped(): boolean {
    return this.weaponId === 'sniper' && this.adsBlend > 0.45;
  }

  public get isReloading(): boolean {
    return this.animState === 'reloading';
  }

  public setAmmoType(t: AmmoType): void {
    this.ammoType = t;
  }

  public toggleAmmoType(): AmmoType {
    this.ammoType = this.ammoType === 'BULLET' ? 'SNOWBALL' : 'BULLET';
    soundEngine.playReloadStep('mag_in');
    return this.ammoType;
  }

  public addTrauma(v: number): void {
    this.camTrauma = Math.min(1, this.camTrauma + v);
  }

  public refillAmmo(): void {
    this.ammoMap.pistol = WEAPON_SPECS.pistol.magSize;
    this.ammoMap.rifle = WEAPON_SPECS.rifle.magSize;
    this.ammoMap.sniper = WEAPON_SPECS.sniper.magSize;
  }

  public resetLook(gameYaw: number): void {
    this.rYaw = gameYaw + Math.PI;
    this.pitch = 0;
    this.freeAimYaw = 0;
    this.freeAimPitch = 0;
    this.camRecoilPitch = 0;
    this.camRecoilVel = 0;
    this.adsToggle = false;
    this.adsBlend = 0;
    this.animState = 'ready';
    this.reloadTimer = 0;
    this.boltTimer = 0;
    this.fireCooldown = 0;
  }

  public resize(aspect: number): void {
    this.worldCamera.aspect = aspect;
    this.worldCamera.updateProjectionMatrix();
    this.vmCamera.aspect = aspect;
    this.vmCamera.updateProjectionMatrix();
  }

  /** Mouse look with the PIGEON free-aim deadzone (gun leads, camera follows). */
  public look(dx: number, dy: number, baseSens: number): void {
    const scoped = this.isScoped;
    const sens = baseSens * (scoped ? 0.22 : this.adsBlend > 0.5 ? 0.58 : 1.0);
    const dYaw = -dx * sens;
    const dPitch = -dy * sens;

    if (!scoped) {
      const maxYaw = THREE.MathUtils.lerp(0.22, 0.042, this.adsBlend);
      const maxPitch = THREE.MathUtils.lerp(0.16, 0.032, this.adsBlend);

      this.freeAimYaw += dYaw;
      if (this.freeAimYaw > maxYaw) {
        this.rYaw += this.freeAimYaw - maxYaw;
        this.freeAimYaw = maxYaw;
      } else if (this.freeAimYaw < -maxYaw) {
        this.rYaw += this.freeAimYaw + maxYaw;
        this.freeAimYaw = -maxYaw;
      }

      this.freeAimPitch += dPitch;
      if (this.freeAimPitch > maxPitch) {
        this.pitch = THREE.MathUtils.clamp(this.pitch + (this.freeAimPitch - maxPitch), -1.28, 1.28);
        this.freeAimPitch = maxPitch;
      } else if (this.freeAimPitch < -maxPitch) {
        this.pitch = THREE.MathUtils.clamp(this.pitch + (this.freeAimPitch + maxPitch), -1.28, 1.28);
        this.freeAimPitch = -maxPitch;
      }
      this.turnRoll = THREE.MathUtils.clamp(this.turnRoll - dx * 0.00048, -0.085, 0.085);
    } else {
      this.rYaw += dYaw;
      this.pitch = THREE.MathUtils.clamp(this.pitch + dPitch, -1.32, 1.32);
      this.freeAimYaw = 0;
      this.freeAimPitch = 0;
    }

    this.swayX = THREE.MathUtils.clamp(this.swayX - dx * 0.00055, -0.055, 0.055);
    this.swayY = THREE.MathUtils.clamp(this.swayY + dy * 0.00055, -0.042, 0.042);
  }

  public switchWeapon(id: WeaponId): void {
    if (id === this.weaponId) return;
    this.rigs[this.weaponId].root.visible = false;
    this.resetRigAnimatedParts(this.rigs[this.weaponId]);
    this.rigs[this.weaponId].muzzleFlash.visible = false;

    this.weaponId = id;
    this.rigs[id].root.visible = true;
    this.animState = 'equipping';
    this.equipTimer = 0.28;
    this.reloadTimer = 0;
    this.boltTimer = 0;
    this.inspectTimer = 0;
    this.adsToggle = false;
    this.adsBlend = 0;
    this.muzzleFlashTimer = 0;
    this.rigs[id].muzzleFlash.visible = false;
    this.vmMuzzleLight.intensity = 0;
    this.recoilPosZ = 0;
    this.recoilRotX = 0;
    this.recoilRotY = 0;
    this.recoilRotZ = 0;
    this.slideKick = 0;
    this.rifleBoltKick = 0;

    const ready = WEAPON_POSES[id].ready;
    this.curVmPos.set(ready.pos.x, ready.pos.y - 0.16, ready.pos.z + 0.08);
    this.curVmRot.set(-0.28, 0.15, -0.1);
    soundEngine.playReloadStep('bolt_down');
  }

  public triggerReload(): void {
    if (this.animState === 'reloading' || this.animState === 'equipping') return;
    const spec = WEAPON_SPECS[this.weaponId];
    if (this.ammoMap[this.weaponId] >= spec.magSize) return;
    this.animState = 'reloading';
    this.reloadDuration = spec.reloadDuration;
    this.reloadTimer = 0;
    this.reloadStageTriggered.clear();
    this.boltTimer = 0;
    this.inspectTimer = 0;
    this.adsToggle = false;
  }

  public triggerInspect(): void {
    if (this.animState === 'reloading' || this.animState === 'bolt_cycle' || this.animState === 'equipping') return;
    if (this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
    } else {
      this.animState = 'inspecting';
      this.inspectTimer = 3.2;
      this.adsToggle = false;
    }
  }

  // ===========================================================================
  //  Per-frame update
  // ===========================================================================
  public update(inp: FpsFrameInput, act: FpsActions): void {
    const dt = inp.dt;
    this.rawTime += dt;
    this.fireRateMult = inp.fireRateMult;
    this.crouchBlend = inp.crouchBlend;

    if (act.weaponSlot > 0) {
      const ids: WeaponId[] = ['pistol', 'rifle', 'sniper'];
      this.switchWeapon(ids[act.weaponSlot - 1]);
    }
    if (act.reload) this.triggerReload();
    if (act.inspect) this.triggerInspect();
    if (act.adsToggle) {
      this.adsToggle = !this.adsToggle;
      if (this.adsToggle && this.animState === 'inspecting') {
        this.animState = 'ready';
        this.inspectTimer = 0;
      }
    }

    // fire (full-auto while held, others per click)
    if (inp.fireHeld && this.spec.fireMode === 'FULL-AUTO') this.tryFire();
    if (act.fireJustPressed) this.tryFire();

    // elastic chest follow behind the free-aim weapon direction
    {
      const isSniperGlass = this.weaponId === 'sniper' && this.adsBlend > 0.35;
      const followRate = isSniperGlass ? 18.0 : this.adsBlend > 0.5 ? 11.5 : 3.2 + this.moveSpeedNorm * 2.8;
      const chaseYaw = this.freeAimYaw * Math.min(1, dt * followRate);
      const chasePitch = this.freeAimPitch * Math.min(1, dt * followRate);
      this.rYaw += chaseYaw;
      this.freeAimYaw -= chaseYaw;
      this.pitch = THREE.MathUtils.clamp(this.pitch + chasePitch, -1.28, 1.28);
      this.freeAimPitch -= chasePitch;
    }

    // camera recoil / trauma decay
    this.camRecoilPitch += this.camRecoilVel;
    this.camRecoilVel *= Math.exp(-24 * dt);
    this.camRecoilPitch *= Math.exp(-9.0 * dt);
    this.camTrauma = Math.max(0, this.camTrauma - dt * 1.85);
    this.turnRoll *= Math.exp(-7.5 * dt);

    // sprint blend + adrenaline
    this.sprintBlend = THREE.MathUtils.lerp(this.sprintBlend, inp.sprinting ? 1 : 0, 1 - Math.exp(-8.5 * dt));
    if (inp.sprinting) this.adrenaline = Math.min(1.0, this.adrenaline + dt * 0.32);
    else this.adrenaline = Math.max(0.0, this.adrenaline - dt * 0.26);

    // landing knee-compression spring
    if (inp.landImpact > 0) {
      this.landJoltVel = -2.2 * inp.landImpact;
      this.camTrauma = Math.min(1.0, this.camTrauma + 0.22 * inp.landImpact);
    }
    this.landJoltVel += (-68 * this.landJolt - 11.5 * this.landJoltVel) * dt;
    this.landJolt += this.landJoltVel * dt;

    // distance-driven stride cadence + synchronized footsteps
    this.moveSpeedNorm = THREE.MathUtils.clamp(inp.horizSpeed / 5.2, 0, 1.45);
    if (inp.isGrounded && inp.horizSpeed > 0.35) {
      const crouching = this.crouchBlend > 0.5;
      const stepMeters = crouching ? 1.15 : THREE.MathUtils.lerp(1.5, 2.1, this.sprintBlend);
      this.moveBobTime += (inp.horizSpeed * dt * Math.PI) / stepMeters;
      const stepIdx = Math.floor(this.moveBobTime / Math.PI);
      if (stepIdx > this.lastFootstepIdx) {
        this.lastFootstepIdx = stepIdx;
        const stance = crouching ? 'crouch' : this.sprintBlend > 0.42 ? 'sprint' : 'walk';
        this.hooks.onFootstep(stepIdx % 2 === 0 ? 'left' : 'right', stance);
      }
    } else if (inp.isGrounded) {
      const curBase = Math.floor(this.moveBobTime / Math.PI);
      this.lastFootstepIdx = curBase;
      const primedPhase = curBase * Math.PI + Math.PI * 0.72;
      if (this.moveBobTime < primedPhase) {
        this.moveBobTime = THREE.MathUtils.lerp(this.moveBobTime, primedPhase, Math.min(1, dt * 8));
      }
    }

    this.updateCamera(inp);
    this.updateWeaponAnimations(dt, inp);
    this.updateFx(dt);
  }

  // ---------------------------------------------------------------------------
  private updateCamera(inp: FpsFrameInput): void {
    const dt = inp.dt;
    const t = this.rawTime;
    const adsDamp = THREE.MathUtils.lerp(1.0, 0.16, this.adsBlend);
    const shakeFactor = 0.3;
    const moveWeight = inp.isGrounded ? THREE.MathUtils.clamp(inp.horizSpeed / 4.4, 0, 1.15) : 0.08;

    // breathing (steady when crouched / aiming)
    const breathAmp = (1.0 + this.adrenaline * 0.55) * (1 - this.crouchBlend * 0.3) * adsDamp * (0.6 + shakeFactor);
    const breathPitch = (Math.sin(t * 1.55) * 0.0028 + Math.cos(t * 2.4) * 0.0012) * breathAmp;
    const breathYaw = (Math.cos(t * 1.15) * 0.0024 + Math.sin(t * 1.9) * 0.001) * breathAmp;
    const breathRoll = Math.sin(t * 1.32) * Math.cos(t * 0.85) * 0.0052 * breathAmp;

    // silky C-infinity stride glide
    const smoothWaveY = (1 - Math.cos(this.moveBobTime * 2)) * 0.5;
    const rawBobY = -smoothWaveY * THREE.MathUtils.lerp(0.011, 0.024, this.sprintBlend) * moveWeight * adsDamp;
    const rawBobX = Math.sin(this.moveBobTime) * THREE.MathUtils.lerp(0.007, 0.016, this.sprintBlend) * moveWeight * adsDamp;
    const rawBobPitch =
      Math.sin(this.moveBobTime * 2 - 0.5) * THREE.MathUtils.lerp(0.0018, 0.0058, this.sprintBlend) * moveWeight * adsDamp -
      this.sprintBlend * 0.01;

    const camSmoothAlpha = 1 - Math.exp(-14.5 * dt);
    this.smoothCamBobX = THREE.MathUtils.lerp(this.smoothCamBobX, rawBobX, camSmoothAlpha);
    this.smoothCamBobY = THREE.MathUtils.lerp(this.smoothCamBobY, rawBobY, camSmoothAlpha);
    this.smoothCamPitch = THREE.MathUtils.lerp(this.smoothCamPitch, rawBobPitch, camSmoothAlpha);

    const strideRoll =
      Math.sin(this.moveBobTime) * THREE.MathUtils.lerp(0.0035, 0.0105, this.sprintBlend) * moveWeight * adsDamp;
    const strafeLean = -inp.strafeInput * 0.014 * adsDamp;
    const targetRollZ = breathRoll + strideRoll + strafeLean + this.turnRoll * 0.7 * adsDamp;
    this.smoothRollZ = THREE.MathUtils.lerp(this.smoothRollZ, targetRollZ, 1 - Math.exp(-11.5 * dt));

    // firing / impact trauma (sharp punch without nausea)
    const traumaSq = this.camTrauma * this.camTrauma * 0.7;
    const traumaPitch = Math.sin(t * 48.0) * 0.024 * traumaSq;
    const traumaYaw = Math.cos(t * 42.0) * 0.018 * traumaSq;
    const traumaRoll = Math.sin(t * 54.0) * 0.034 * traumaSq;

    const lateralX = Math.cos(this.rYaw) * this.smoothCamBobX;
    const lateralZ = -Math.sin(this.rYaw) * this.smoothCamBobX;

    this.worldCamera.position.set(
      inp.position.x + lateralX,
      inp.position.y + inp.eyeHeight + this.smoothCamBobY + this.landJolt * 0.065,
      inp.position.z + lateralZ
    );
    this.worldCamera.rotation.y = this.rYaw + breathYaw + traumaYaw;
    this.worldCamera.rotation.x = THREE.MathUtils.clamp(
      this.pitch + this.smoothCamPitch + this.camRecoilPitch + breathPitch + traumaPitch,
      -1.4,
      1.4
    );
    this.worldCamera.rotation.z = this.smoothRollZ + traumaRoll;
    this.worldCamera.updateMatrixWorld(true);
  }

  // ---------------------------------------------------------------------------
  private updateWeaponAnimations(dt: number, inp: FpsFrameInput): void {
    const rig = this.rigs[this.weaponId];
    const spec = WEAPON_SPECS[this.weaponId];

    if (this.fireCooldown > 0) this.fireCooldown = Math.max(0, this.fireCooldown - dt);
    if (this.triggerPullTimer > 0) this.triggerPullTimer = Math.max(0, this.triggerPullTimer - dt);

    if (this.muzzleFlashTimer > 0) {
      this.muzzleFlashTimer -= dt;
      if (this.muzzleFlashTimer <= 0) {
        rig.muzzleFlash.visible = false;
        this.vmMuzzleLight.intensity = 0;
      }
    }

    if (this.animState === 'equipping') {
      this.equipTimer -= dt;
      if (this.equipTimer <= 0) this.animState = 'ready';
    }
    if (this.animState === 'inspecting') {
      this.inspectTimer -= dt;
      if (this.inspectTimer <= 0) this.animState = 'ready';
    }

    // ADS blend
    const wantAds =
      (inp.adsHeld || this.adsToggle) &&
      this.animState !== 'reloading' &&
      this.animState !== 'bolt_cycle' &&
      this.animState !== 'inspecting' &&
      this.animState !== 'equipping';
    const adsRate = this.weaponId === 'sniper' ? 9.5 : 12.0;
    this.adsBlend = THREE.MathUtils.lerp(this.adsBlend, wantAds ? 1 : 0, Math.min(1, dt * adsRate));
    if (this.animState === 'ready' || this.animState === 'ads') {
      this.animState = this.adsBlend > 0.55 ? 'ads' : 'ready';
    }

    // FOV (wide base + sprint surge + ADS peripheral zoom)
    const baseFov = FPS_BASE_FOV + this.sprintBlend * 6.0;
    const targetFov = THREE.MathUtils.lerp(baseFov, ADS_WORLD_FOV[this.weaponId], this.adsBlend);
    if (Math.abs(this.worldCamera.fov - targetFov) > 0.04) {
      this.worldCamera.fov = THREE.MathUtils.lerp(this.worldCamera.fov, targetFov, 1 - Math.exp(-12.5 * dt));
      this.worldCamera.updateProjectionMatrix();
    }
    const adsVmFov = this.weaponId === 'sniper' ? 46 : 54;
    const targetVmFov = THREE.MathUtils.lerp(FPS_VM_FOV, adsVmFov, this.adsBlend);
    if (Math.abs(this.vmCamera.fov - targetVmFov) > 0.04) {
      this.vmCamera.fov = THREE.MathUtils.lerp(this.vmCamera.fov, targetVmFov, 1 - Math.exp(-13 * dt));
      this.vmCamera.updateProjectionMatrix();
    }

    this.resetRigAnimatedParts(rig);

    // 1. recoil spring recovery & mechanical blowback
    const recDecay = this.weaponId === 'sniper' ? 6.2 : this.weaponId === 'rifle' ? 14.5 : 13.0;
    this.recoilPosZ *= Math.exp(-recDecay * dt);
    this.recoilRotX *= Math.exp(-recDecay * dt);
    this.recoilRotY *= Math.exp(-recDecay * 1.1 * dt);
    this.recoilRotZ *= Math.exp(-recDecay * 1.1 * dt);
    this.spreadBloom = Math.max(0, this.spreadBloom - dt * 2.4);

    if (rig.trigger) rig.trigger.rotation.x = this.triggerPullTimer > 0 ? -0.55 : 0;

    if (this.weaponId === 'pistol' && rig.slide && rig.hammer) {
      this.slideKick = Math.max(0, this.slideKick - dt * 12.5);
      const lockedBack = this.ammoMap.pistol === 0 && this.animState !== 'reloading';
      const slideBackAmount = lockedBack ? 0.92 : Math.sin(this.slideKick * Math.PI);
      rig.slide.position.z = slideBackAmount * 0.064;
      rig.hammer.rotation.x = this.slideKick > 0.72 ? -0.65 : slideBackAmount * 0.42;
    }

    if (this.weaponId === 'rifle' && rig.bolt && rig.dustCover) {
      this.rifleBoltKick = Math.max(0, this.rifleBoltKick - dt * 18.0);
      const boltTravel = Math.sin(this.rifleBoltKick * Math.PI);
      rig.bolt.position.z = boltTravel * 0.072;
      rig.dustCover.rotation.z = this.rifleDustCoverOpen ? -2.35 : 0;
    }

    // 2. sniper bolt-action cycle (shell ejects on pull-back)
    if (this.animState === 'bolt_cycle' && this.weaponId === 'sniper' && rig.bolt && rig.boltHandle) {
      this.boltTimer += dt;
      const p = THREE.MathUtils.clamp(this.boltTimer / this.boltDuration, 0, 1);

      if (p >= 0.06 && !this.boltStageTriggered.has('up')) {
        this.boltStageTriggered.add('up');
        soundEngine.playReloadStep('bolt_up');
      }
      if (p >= 0.24 && !this.boltStageTriggered.has('back')) {
        this.boltStageTriggered.add('back');
        soundEngine.playReloadStep('bolt_back');
      }
      if (p >= 0.43 && !this.boltStageTriggered.has('eject')) {
        this.boltStageTriggered.add('eject');
        if (this.ammoType === 'BULLET') this.spawnShellCasing('sniper');
      }
      if (p >= 0.56 && !this.boltStageTriggered.has('fwd')) {
        this.boltStageTriggered.add('fwd');
        soundEngine.playReloadStep('bolt_fwd');
      }
      if (p >= 0.8 && !this.boltStageTriggered.has('down')) {
        this.boltStageTriggered.add('down');
        soundEngine.playReloadStep('bolt_down');
      }

      let lift = 0;
      let pull = 0;
      let handOnBolt = 0;
      if (p < 0.14) {
        handOnBolt = p / 0.14;
      } else if (p < 0.26) {
        handOnBolt = 1;
        lift = (p - 0.14) / 0.12;
      } else if (p < 0.48) {
        handOnBolt = 1;
        lift = 1;
        pull = (p - 0.26) / 0.22;
      } else if (p < 0.72) {
        handOnBolt = 1;
        lift = 1;
        pull = 1 - (p - 0.48) / 0.24;
      } else if (p < 0.86) {
        handOnBolt = 1;
        lift = 1 - (p - 0.72) / 0.14;
      } else {
        handOnBolt = 1 - (p - 0.86) / 0.14;
      }

      rig.boltHandle.rotation.z = lift * 1.08;
      rig.bolt.position.z = -0.02 + pull * 0.112;

      const knobTargetPos = new THREE.Vector3(0.098 - lift * 0.022, 0.012 + lift * 0.052, 0.055 + pull * 0.112);
      const knobTargetRot = new THREE.Euler(0.2, -0.12, -1.05 + lift * 0.38);
      rig.rightArm.position.lerpVectors(rig.rightArmRestPos, knobTargetPos, handOnBolt);
      rig.rightArm.rotation.set(
        THREE.MathUtils.lerp(rig.rightArmRestRot.x, knobTargetRot.x, handOnBolt),
        THREE.MathUtils.lerp(rig.rightArmRestRot.y, knobTargetRot.y, handOnBolt),
        THREE.MathUtils.lerp(rig.rightArmRestRot.z, knobTargetRot.z, handOnBolt)
      );

      if (p >= 1) this.animState = 'ready';
    }

    // 3. reload animations
    if (this.animState === 'reloading') {
      this.reloadTimer += dt;
      const p = THREE.MathUtils.clamp(this.reloadTimer / this.reloadDuration, 0, 1);
      this.animateWeaponReload(rig, p);
      if (p >= 1) {
        this.ammoMap[this.weaponId] = spec.magSize;
        this.animState = 'ready';
      }
    }

    // 4. target pose blending
    const poses = WEAPON_POSES[this.weaponId];
    const targetPos = this.tmpV1;
    const targetRot = this.tmpEuler;

    if (this.animState === 'reloading' || this.animState === 'inspecting') {
      targetPos.copy(poses.reload.pos);
      targetRot.copy(poses.reload.rot);
      if (this.animState === 'inspecting') {
        const w = Math.sin(this.rawTime * 1.9);
        targetRot.y += w * 0.14;
        targetRot.z += w * 0.08;
      }
    } else if (this.animState === 'bolt_cycle') {
      targetPos.copy(poses.bolt.pos);
      targetRot.copy(poses.bolt.rot);
    } else {
      this.sprintRaise = THREE.MathUtils.lerp(this.sprintRaise, inp.fireHeld ? 1 : 0, 1 - Math.exp(-12 * dt));
      const sp = this.sprintBlend * (1 - this.adsBlend) * (1 - this.sprintRaise);
      const basePosX = THREE.MathUtils.lerp(poses.ready.pos.x, poses.sprint.pos.x, sp);
      const basePosY = THREE.MathUtils.lerp(poses.ready.pos.y, poses.sprint.pos.y, sp);
      const basePosZ = THREE.MathUtils.lerp(poses.ready.pos.z, poses.sprint.pos.z, sp);
      const baseRotX = THREE.MathUtils.lerp(poses.ready.rot.x, poses.sprint.rot.x, sp);
      const baseRotY = THREE.MathUtils.lerp(poses.ready.rot.y, poses.sprint.rot.y, sp);
      const baseRotZ = THREE.MathUtils.lerp(poses.ready.rot.z, poses.sprint.rot.z, sp);

      targetPos.set(
        THREE.MathUtils.lerp(basePosX, poses.ads.pos.x, this.adsBlend),
        THREE.MathUtils.lerp(basePosY, poses.ads.pos.y, this.adsBlend),
        THREE.MathUtils.lerp(basePosZ, poses.ads.pos.z, this.adsBlend)
      );
      targetRot.set(
        THREE.MathUtils.lerp(baseRotX, poses.ads.rot.x, this.adsBlend),
        THREE.MathUtils.lerp(baseRotY, poses.ads.rot.y, this.adsBlend),
        THREE.MathUtils.lerp(baseRotZ, poses.ads.rot.z, this.adsBlend)
      );
    }

    const blendSpeed = this.animState === 'reloading' || this.animState === 'bolt_cycle' ? 9.5 : 14.0;
    const vmAlpha = 1 - Math.exp(-blendSpeed * dt);
    this.curVmPos.lerp(targetPos, vmAlpha);
    this.curVmRot.x = THREE.MathUtils.lerp(this.curVmRot.x, targetRot.x, vmAlpha);
    this.curVmRot.y = THREE.MathUtils.lerp(this.curVmRot.y, targetRot.y, vmAlpha);
    this.curVmRot.z = THREE.MathUtils.lerp(this.curVmRot.z, targetRot.z, vmAlpha);

    // weapon sway, crouch tuck, sprint glide, free-aim lead
    const swayScale = 1 - this.adsBlend * 0.88;
    const crouchSteady = 1 - this.crouchBlend * 0.35;
    this.swayX *= Math.exp(-9.5 * dt);
    this.swayY *= Math.exp(-9.5 * dt);

    const idleX = Math.cos(this.rawTime * 1.45) * 0.0026 * crouchSteady * swayScale;
    const idleY = Math.sin(this.rawTime * 2.15) * 0.003 * crouchSteady * swayScale;

    const sprintFactor = this.sprintBlend * (this.animState === 'reloading' ? 0.2 : 1.0);
    const waveY = (1 - Math.cos(this.moveBobTime * 2)) * 0.5;
    const bobX = Math.sin(this.moveBobTime) * (0.0085 + sprintFactor * 0.015) * this.moveSpeedNorm * crouchSteady * swayScale;
    const bobY = -waveY * (0.008 + sprintFactor * 0.013) * this.moveSpeedNorm * crouchSteady * swayScale;

    const crouchCantZ = -0.055 * this.crouchBlend * swayScale;
    const crouchDropY = -0.008 * this.crouchBlend * swayScale;

    const faScale = 1 - this.adsBlend * 0.72;
    const faPosX = -this.freeAimYaw * 0.24 * faScale;
    const faPosY = this.freeAimPitch * 0.19 * faScale;
    const faRotY = this.freeAimYaw * 1.02 * faScale;
    const faRotX = this.freeAimPitch * 1.0 * faScale;
    const faRotZ = this.freeAimYaw * 0.38 * faScale;

    rig.root.position.set(
      this.curVmPos.x + idleX + bobX + faPosX + this.swayX * 0.52 * swayScale,
      this.curVmPos.y + idleY + bobY + crouchDropY + faPosY + this.swayY * 0.52 * swayScale + this.landJolt * 0.028,
      this.curVmPos.z + this.recoilPosZ
    );
    rig.root.rotation.set(
      this.curVmRot.x + this.recoilRotX + faRotX + this.landJolt * 0.055,
      this.curVmRot.y + this.recoilRotY + faRotY + this.swayX * 1.0 * swayScale,
      this.curVmRot.z +
        this.recoilRotZ +
        faRotZ +
        crouchCantZ -
        this.swayX * 1.05 * swayScale -
        Math.sin(this.moveBobTime) * 0.022 * sprintFactor
    );

    if (this.vmMuzzleLight.intensity > 0.01) {
      rig.muzzleSocket.updateWorldMatrix(true, false);
      rig.muzzleSocket.getWorldPosition(this.tmpV2);
      this.vmMuzzleLight.position.copy(this.tmpV2);
    }

    // scope lens uniforms (eye-relief parallax)
    if (this.weaponId === 'sniper' && rig.scopeLensUniforms) {
      rig.scopeLensUniforms.uAdsBlend.value = this.adsBlend;
      rig.scopeLensUniforms.uEyeOffset.value.set(
        THREE.MathUtils.clamp(this.swayX * 1.35, -0.075, 0.075),
        THREE.MathUtils.clamp(this.swayY * 1.35, -0.075, 0.075)
      );
    }
  }

  // ---------------------------------------------------------------------------
  private animateWeaponReload(rig: WeaponRig, p: number): void {
    if (rig.id === 'pistol') {
      if (p >= 0.14 && !this.reloadStageTriggered.has('out')) {
        this.reloadStageTriggered.add('out');
        soundEngine.playReloadStep('mag_out');
      }
      if (p >= 0.48 && !this.reloadStageTriggered.has('in')) {
        this.reloadStageTriggered.add('in');
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.06;
      }
      if (p >= 0.68 && !this.reloadStageTriggered.has('rack')) {
        this.reloadStageTriggered.add('rack');
        soundEngine.playReloadStep('rack');
      }

      if (p < 0.34) {
        const t = THREE.MathUtils.smoothstep(p, 0.0, 0.34);
        rig.mag.position.set(0, rig.magRestPos.y - t * 0.22, rig.magRestPos.z + t * 0.055);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, new THREE.Vector3(-0.06, -0.26, 0.09), t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.85, t);
      } else if (p < 0.58) {
        const t = THREE.MathUtils.smoothstep(p, 0.34, 0.58);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.22, rig.magRestPos.z + (1 - t) * 0.055);
        rig.leftArm.position.lerpVectors(new THREE.Vector3(-0.06, -0.26, 0.09), new THREE.Vector3(-0.032, -0.11, 0.06), t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(1.85, 1.48, t);
      } else if (p < 0.86) {
        const t = (p - 0.58) / 0.28;
        const rackCurve = Math.sin(t * Math.PI);
        if (rig.slide) rig.slide.position.z = rackCurve * 0.062;
        rig.leftArm.position.set(-0.042, 0.062, -0.02 + rackCurve * 0.062);
        rig.leftArm.rotation.set(0.12, -0.2, 0.85);
      } else {
        const t = (p - 0.86) / 0.14;
        rig.leftArm.position.lerpVectors(new THREE.Vector3(-0.042, 0.062, -0.02), rig.leftArmRestPos, t);
        rig.leftArm.rotation.set(
          THREE.MathUtils.lerp(0.12, rig.leftArmRestRot.x, t),
          THREE.MathUtils.lerp(-0.2, rig.leftArmRestRot.y, t),
          THREE.MathUtils.lerp(0.85, rig.leftArmRestRot.z, t)
        );
      }
    } else if (rig.id === 'rifle') {
      if (p >= 0.22 && !this.reloadStageTriggered.has('out')) {
        this.reloadStageTriggered.add('out');
        soundEngine.playReloadStep('mag_out');
      }
      if (p >= 0.62 && !this.reloadStageTriggered.has('in')) {
        this.reloadStageTriggered.add('in');
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.055;
      }
      if (p >= 0.74 && !this.reloadStageTriggered.has('rack')) {
        this.reloadStageTriggered.add('rack');
        soundEngine.playReloadStep('rack');
      }

      const magGripHand = new THREE.Vector3(-0.048, -0.16, -0.095);
      const magOutHand = new THREE.Vector3(-0.11, -0.36, -0.06);
      const chargeHand = new THREE.Vector3(-0.055, 0.065, 0.095);

      if (p < 0.2) {
        const t = THREE.MathUtils.smoothstep(p, 0, 0.2);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, magGripHand, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.52, t);
      } else if (p < 0.44) {
        const t = THREE.MathUtils.smoothstep(p, 0.2, 0.44);
        rig.mag.position.set(0, rig.magRestPos.y - t * 0.25, rig.magRestPos.z + t * 0.03);
        rig.mag.rotation.x = t * 0.22;
        rig.leftArm.position.lerpVectors(magGripHand, magOutHand, t);
        rig.leftArm.rotation.z = 1.52;
      } else if (p < 0.68) {
        const t = THREE.MathUtils.smoothstep(p, 0.44, 0.68);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.25, rig.magRestPos.z + (1 - t) * 0.03);
        rig.mag.rotation.x = (1 - t) * 0.22;
        rig.leftArm.position.lerpVectors(magOutHand, magGripHand, t);
        rig.leftArm.rotation.z = 1.52;
      } else if (p < 0.9) {
        const t = (p - 0.68) / 0.22;
        const pull = Math.sin(t * Math.PI);
        if (rig.chargingHandle) rig.chargingHandle.position.z = 0.095 + pull * 0.072;
        if (rig.bolt) rig.bolt.position.z = pull * 0.072;
        rig.leftArm.position.set(chargeHand.x, chargeHand.y, chargeHand.z + pull * 0.072);
        rig.leftArm.rotation.set(0.12, -0.18, 1.15);
      } else {
        const t = (p - 0.9) / 0.1;
        rig.leftArm.position.lerpVectors(chargeHand, rig.leftArmRestPos, t);
        rig.leftArm.rotation.set(
          THREE.MathUtils.lerp(0.12, rig.leftArmRestRot.x, t),
          THREE.MathUtils.lerp(-0.18, rig.leftArmRestRot.y, t),
          THREE.MathUtils.lerp(1.15, rig.leftArmRestRot.z, t)
        );
      }
    } else if (rig.id === 'sniper') {
      if (p >= 0.16 && !this.reloadStageTriggered.has('out')) {
        this.reloadStageTriggered.add('out');
        soundEngine.playReloadStep('mag_out');
      }
      if (p >= 0.44 && !this.reloadStageTriggered.has('in')) {
        this.reloadStageTriggered.add('in');
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.06;
      }
      if (p >= 0.62 && !this.reloadStageTriggered.has('bback')) {
        this.reloadStageTriggered.add('bback');
        soundEngine.playReloadStep('bolt_back');
      }
      if (p >= 0.78 && !this.reloadStageTriggered.has('bfwd')) {
        this.reloadStageTriggered.add('bfwd');
        soundEngine.playReloadStep('bolt_fwd');
      }
      if (p >= 0.88 && !this.reloadStageTriggered.has('bdown')) {
        this.reloadStageTriggered.add('bdown');
        soundEngine.playReloadStep('bolt_down');
      }

      const magHandIn = new THREE.Vector3(-0.045, -0.14, -0.095);
      const magHandOut = new THREE.Vector3(-0.095, -0.34, -0.065);

      if (p < 0.28) {
        const t = THREE.MathUtils.smoothstep(p, 0.0, 0.28);
        const magT = THREE.MathUtils.smoothstep(p, 0.1, 0.28);
        rig.mag.position.set(0, rig.magRestPos.y - magT * 0.22, rig.magRestPos.z);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, magHandOut, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.55, t);
      } else if (p < 0.52) {
        const t = THREE.MathUtils.smoothstep(p, 0.28, 0.52);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.22, rig.magRestPos.z);
        rig.leftArm.position.lerpVectors(magHandOut, magHandIn, t);
        rig.leftArm.rotation.z = 1.55;
      } else if (p < 0.62) {
        const t = (p - 0.52) / 0.1;
        rig.leftArm.position.lerpVectors(magHandIn, rig.leftArmRestPos, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(1.55, rig.leftArmRestRot.z, t);
      }

      if (p >= 0.55 && rig.bolt && rig.boltHandle) {
        const bp = THREE.MathUtils.clamp((p - 0.55) / 0.4, 0, 1);
        const lift = bp < 0.2 ? bp / 0.2 : bp < 0.8 ? 1 : (1 - bp) / 0.2;
        const pull = bp < 0.2 ? 0 : bp < 0.5 ? (bp - 0.2) / 0.3 : bp < 0.8 ? 1 - (bp - 0.5) / 0.3 : 0;
        const handBlend = bp < 0.12 ? bp / 0.12 : bp > 0.88 ? (1 - bp) / 0.12 : 1;

        rig.boltHandle.rotation.z = lift * 1.08;
        rig.bolt.position.z = -0.02 + pull * 0.11;

        const knobPos = new THREE.Vector3(0.098 - lift * 0.022, 0.012 + lift * 0.052, 0.055 + pull * 0.11);
        rig.rightArm.position.lerpVectors(rig.rightArmRestPos, knobPos, handBlend);
        rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArmRestRot.z, -0.95 + lift * 0.3, handBlend);
      }
    }
  }

  private resetRigAnimatedParts(rig: WeaponRig): void {
    rig.leftArm.position.copy(rig.leftArmRestPos);
    rig.leftArm.rotation.copy(rig.leftArmRestRot);
    rig.rightArm.position.copy(rig.rightArmRestPos);
    rig.rightArm.rotation.copy(rig.rightArmRestRot);
    rig.mag.position.copy(rig.magRestPos);
    rig.mag.rotation.copy(rig.magRestRot);
    rig.mag.visible = true;
    if (rig.slide) rig.slide.position.set(0, 0, 0);
    if (rig.hammer) rig.hammer.rotation.set(0, 0, 0);
    if (rig.bolt) rig.bolt.position.set(0, rig.id === 'sniper' ? 0.036 : 0, rig.id === 'sniper' ? -0.02 : 0);
    if (rig.boltHandle) rig.boltHandle.rotation.set(0, 0, 0);
    if (rig.chargingHandle) rig.chargingHandle.position.set(0, 0.055, 0.095);
    if (rig.trigger) rig.trigger.rotation.set(0, 0, 0);
  }

  // ===========================================================================
  //  Firing (PIGEON tryFire: recoil, flash, ejection, smoke, then the ballistic hook)
  // ===========================================================================
  private tryFire(): void {
    if (this.animState === 'reloading' || this.animState === 'bolt_cycle' || this.animState === 'equipping') return;
    if (this.fireCooldown > 0) return;

    const spec = WEAPON_SPECS[this.weaponId];
    const ammo = this.ammoMap[this.weaponId];
    if (ammo <= 0) {
      soundEngine.playDryFire();
      this.fireCooldown = 0.22;
      this.triggerReload();
      return;
    }

    if (this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
    }

    this.ammoMap[this.weaponId] = ammo - 1;
    this.fireCooldown = 60 / (spec.rpm * this.fireRateMult);
    this.triggerPullTimer = 0.09;

    const rig = this.rigs[this.weaponId];
    const isSnow = this.ammoType === 'SNOWBALL';
    this.muzzleFlashTimer = this.weaponId === 'sniper' ? 0.095 : this.weaponId === 'rifle' ? 0.058 : 0.052;
    rig.muzzleFlash.visible = true;
    rig.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
    const fScale = (0.88 + Math.random() * 0.26) * (isSnow ? 0.62 : 1);
    rig.muzzleFlash.scale.set(fScale, fScale, fScale);
    this.vmMuzzleLight.intensity = (this.weaponId === 'sniper' ? 8.5 : this.weaponId === 'rifle' ? 5.2 : 4.2) * (isSnow ? 0.45 : 1);

    // recoil impulses (steadier when crouched / aiming)
    const adsScale = this.adsBlend > 0.5 ? 0.58 : 1.0;
    const crouchScale = 1 - this.crouchBlend * 0.3;
    const stability = adsScale * crouchScale;
    this.recoilPosZ = Math.min(0.14, this.recoilPosZ + spec.recoilKickZ * stability);
    this.recoilRotX = Math.min(0.42, this.recoilRotX + spec.recoilPitch * stability);
    this.recoilRotY += (Math.random() - 0.5) * spec.recoilYaw * stability;
    this.recoilRotZ += (Math.random() - 0.5) * spec.recoilYaw * 1.35 * stability;
    this.camRecoilVel += spec.cameraPunch * (this.adsBlend > 0.5 ? 0.68 : 1.0) * crouchScale;
    this.spreadBloom = Math.min(1.0, this.spreadBloom + (this.weaponId === 'rifle' ? 0.22 : 0.42) * crouchScale);
    this.camTrauma = Math.min(1.0, this.camTrauma + (this.weaponId === 'sniper' ? 0.52 : this.weaponId === 'rifle' ? 0.18 : 0.24) * crouchScale);
    this.adrenaline = Math.min(1.0, this.adrenaline + 0.22);

    if (isSnow) this.hooks.playSnowShot();
    else soundEngine.playShot(this.weaponId, false, 0.0, this.ammoMap[this.weaponId] === 0);

    const isSniperScoped = this.weaponId === 'sniper' && this.adsBlend > 0.68;
    const muzzleWorld = isSniperScoped
      ? this.worldCamera.position
          .clone()
          .addScaledVector(this.worldCamera.getWorldDirection(this.tmpV1), 0.9)
          .add(new THREE.Vector3(0, -0.06, 0))
      : this.vmSocketToWorld(rig.muzzleSocket, this.weaponId === 'sniper' ? 1.15 : this.weaponId === 'rifle' ? 0.9 : 0.62);

    if (this.weaponId === 'pistol') {
      this.slideKick = 1.0;
      if (!isSnow) this.spawnShellCasing('pistol');
      this.spawnMuzzleSmoke(muzzleWorld, isSnow ? 4 : 2, isSnow ? 0.6 : 0.7);
    } else if (this.weaponId === 'rifle') {
      this.rifleDustCoverOpen = true;
      this.rifleBoltKick = 1.0;
      if (!isSnow) this.spawnShellCasing('rifle');
      this.spawnMuzzleSmoke(muzzleWorld, isSnow ? 5 : 2, isSnow ? 0.7 : 0.9);
    } else {
      this.spawnSniperBrakeBlast(muzzleWorld);
      if (isSnow) this.spawnMuzzleSmoke(muzzleWorld, 4, 0.8);
      if (this.ammoMap.sniper > 0) {
        this.animState = 'bolt_cycle';
        this.boltTimer = 0;
        this.boltDuration = spec.boltCycleDuration;
        this.boltStageTriggered.clear();
      }
    }

    // true ballistic line = camera orientation + live free-aim offset + spread
    const crouchSpreadScale = 1 - this.crouchBlend * 0.32;
    const spread =
      (THREE.MathUtils.lerp(spec.spreadHip, spec.spreadAds, this.adsBlend) + this.spreadBloom * 0.014) * crouchSpreadScale;
    const jitterPitch = (Math.random() - 0.5) * spread * 2.0;
    const jitterYaw = (Math.random() - 0.5) * spread * 2.0;
    const aimEuler = new THREE.Euler(
      this.worldCamera.rotation.x + this.freeAimPitch + jitterPitch,
      this.worldCamera.rotation.y + this.freeAimYaw + jitterYaw,
      0,
      'YXZ'
    );
    const shotDir = new THREE.Vector3(0, 0, -1).applyEuler(aimEuler).normalize();

    this.hooks.onShot({
      origin: this.worldCamera.position.clone(),
      dir: shotDir,
      muzzle: muzzleWorld,
      weaponId: this.weaponId,
      ammoType: this.ammoType,
      spec,
    });
  }

  /** current aim direction (camera + free-aim, no jitter) */
  public getAimDirection(out: THREE.Vector3): THREE.Vector3 {
    const e = new THREE.Euler(
      this.worldCamera.rotation.x + this.freeAimPitch,
      this.worldCamera.rotation.y + this.freeAimYaw,
      0,
      'YXZ'
    );
    return out.set(0, 0, -1).applyEuler(e).normalize();
  }

  /** viewmodel socket -> world point (projects through the viewmodel camera onto the world camera ray) */
  private vmSocketToWorld(socket: THREE.Object3D, worldDist: number): THREE.Vector3 {
    socket.updateWorldMatrix(true, false);
    const vmPos = new THREE.Vector3();
    socket.getWorldPosition(vmPos);
    this.vmCamera.updateMatrixWorld(true);
    const ndc = vmPos.clone().project(this.vmCamera);
    const worldPoint = new THREE.Vector3(ndc.x, ndc.y, 0.5).unproject(this.worldCamera);
    const dir = worldPoint.sub(this.worldCamera.position).normalize();
    return this.worldCamera.position.clone().addScaledVector(dir, worldDist);
  }

  // ===========================================================================
  //  FX spawners
  // ===========================================================================
  public spawnTracer(start: THREE.Vector3, end: THREE.Vector3, speed: number): void {
    const dir = end.clone().sub(start);
    const distTotal = dir.length();
    if (distTotal < 0.2) return;
    dir.normalize();
    const mesh = new THREE.Mesh(this.tracerGeoByWeapon[this.weaponId], this.tracerMatByWeapon[this.weaponId]);
    mesh.position.copy(start);
    mesh.lookAt(end);
    this.worldScene.add(mesh);
    this.tracers.push({ mesh, start: start.clone(), dir, distTotal, distTraveled: 0, speed });
  }

  public spawnSniperContrail(start: THREE.Vector3, end: THREE.Vector3): void {
    const dir = end.clone().sub(start);
    const len = Math.min(dir.length(), 280);
    if (len < 1) return;
    const mid = start.clone().addScaledVector(dir.normalize(), len * 0.5);
    const geo = new THREE.CylinderGeometry(0.016, 0.028, len, 5);
    geo.rotateX(Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42, depthWrite: false });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(mid);
    mesh.lookAt(end);
    this.worldScene.add(mesh);
    this.contrails.push({ mesh, age: 0, maxAge: 0.95 });
  }

  private acquireSmokeMat(): THREE.MeshStandardMaterial {
    if (this.smokeMatPool.length < 48) {
      const m = this.smokeMatBase.clone();
      this.smokeMatPool.push(m);
      return m;
    }
    const m = this.smokeMatPool[this.smokeMatIdx++ % this.smokeMatPool.length];
    m.opacity = this.smokeMatBase.opacity;
    return m;
  }

  private spawnMuzzleSmoke(pos: THREE.Vector3, count: number, scale: number): void {
    const forward = this.worldCamera.getWorldDirection(new THREE.Vector3());
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.smokeGeo, this.acquireSmokeMat());
      m.position.copy(pos);
      this.worldScene.add(m);
      const vel = forward
        .clone()
        .multiplyScalar(1.4 + Math.random() * 1.4)
        .add(new THREE.Vector3((Math.random() - 0.5) * 0.7, 0.65 + Math.random() * 0.55, (Math.random() - 0.5) * 0.7));
      this.smoke.push({
        mesh: m,
        vel,
        angVel: new THREE.Vector3(Math.random() * 2, Math.random() * 2, Math.random() * 2),
        gravity: -0.35,
        age: 0,
        maxAge: 0.55 + Math.random() * 0.3,
        startScale: 0.35 * scale,
        endScale: 1.85 * scale,
      });
    }
  }

  private spawnSniperBrakeBlast(pos: THREE.Vector3): void {
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.worldCamera.quaternion);
    const forward = this.worldCamera.getWorldDirection(new THREE.Vector3());
    [-1, 1].forEach((side) => {
      for (let i = 0; i < 4; i++) {
        const m = new THREE.Mesh(this.smokeGeo, this.acquireSmokeMat());
        m.position.copy(pos);
        this.worldScene.add(m);
        const vel = right
          .clone()
          .multiplyScalar(side * (3.2 + i * 1.1))
          .addScaledVector(forward, -0.4 + Math.random() * 0.6)
          .add(new THREE.Vector3(0, 0.35 + Math.random() * 0.4, 0));
        this.smoke.push({
          mesh: m,
          vel,
          angVel: new THREE.Vector3(3, 3, 3),
          gravity: -0.25,
          age: 0,
          maxAge: 0.75 + Math.random() * 0.3,
          startScale: 0.5,
          endScale: 2.5,
        });
      }
    });
    this.spawnMuzzleSmoke(pos, 3, 1.3);
  }

  private spawnShellCasing(weapon: WeaponId): void {
    const rig = this.rigs[weapon];
    const startPos = this.vmSocketToWorld(rig.ejectionSocket, weapon === 'pistol' ? 0.44 : 0.48);
    const mesh = new THREE.Mesh(this.shellGeos[weapon], this.brassMat);
    mesh.position.copy(startPos);
    mesh.quaternion.copy(this.worldCamera.quaternion);
    mesh.rotateZ(Math.PI / 2);
    this.worldScene.add(mesh);

    const localVel = new THREE.Vector3();
    if (weapon === 'pistol') {
      localVel.set(1.55 + Math.random() * 0.55, 1.85 + Math.random() * 0.55, 0.35 + Math.random() * 0.3);
    } else if (weapon === 'rifle') {
      localVel.set(2.35 + Math.random() * 0.65, 1.35 + Math.random() * 0.45, 0.2 + Math.random() * 0.35);
    } else {
      localVel.set(1.65 + Math.random() * 0.45, 1.45 + Math.random() * 0.35, 0.45 + Math.random() * 0.25);
    }
    localVel.applyQuaternion(this.worldCamera.quaternion);

    this.shells.push({
      mesh,
      vel: localVel,
      angVel: new THREE.Vector3((Math.random() - 0.5) * 26, (Math.random() - 0.5) * 26, -18 - Math.random() * 14),
      age: 0,
      maxAge: 6.5,
      bounces: 0,
      weapon,
    });
  }

  /** snowball-ammo tracer (a fast white streak following the real physical snowball) */
  public spawnSnowStreak(start: THREE.Vector3, end: THREE.Vector3, speed: number): void {
    const dir = end.clone().sub(start);
    const distTotal = dir.length();
    if (distTotal < 0.2) return;
    dir.normalize();
    const mesh = new THREE.Mesh(this.tracerGeoByWeapon.pistol, this.snowTracerMat);
    mesh.position.copy(start);
    mesh.lookAt(end);
    this.worldScene.add(mesh);
    this.tracers.push({ mesh, start: start.clone(), dir, distTotal, distTraveled: 0, speed });
  }

  // ===========================================================================
  private updateFx(dt: number): void {
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.age += dt;
      if (s.age >= s.maxAge) {
        this.worldScene.remove(s.mesh);
        this.shells.splice(i, 1);
        continue;
      }
      s.vel.y -= 9.8 * dt;
      s.mesh.position.addScaledVector(s.vel, dt);
      s.mesh.rotation.x += s.angVel.x * dt;
      s.mesh.rotation.y += s.angVel.y * dt;
      s.mesh.rotation.z += s.angVel.z * dt;

      const floorY = this.groundHeight(s.mesh.position.x, s.mesh.position.z) + 0.02;
      if (s.mesh.position.y < floorY) {
        s.mesh.position.y = floorY;
        if (Math.abs(s.vel.y) > 0.65 && s.bounces < 2) {
          s.vel.y = -s.vel.y * 0.3;
          s.vel.x *= 0.45;
          s.vel.z *= 0.45;
          s.angVel.multiplyScalar(0.5);
          s.bounces++;
        } else {
          // casing sinks softly into the snow
          s.vel.set(0, 0, 0);
          s.angVel.set(0, 0, 0);
          s.mesh.position.y = floorY - 0.012;
        }
      }
      if (s.age > s.maxAge - 0.8) {
        s.mesh.scale.setScalar(Math.max(0.01, (s.maxAge - s.age) / 0.8));
      }
    }

    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const tr = this.tracers[i];
      tr.distTraveled += tr.speed * dt;
      if (tr.distTraveled >= tr.distTotal) {
        this.worldScene.remove(tr.mesh);
        this.tracers.splice(i, 1);
        continue;
      }
      tr.mesh.position.copy(tr.start).addScaledVector(tr.dir, tr.distTraveled);
    }

    for (let i = this.contrails.length - 1; i >= 0; i--) {
      const c = this.contrails[i];
      c.age += dt;
      if (c.age >= c.maxAge) {
        this.worldScene.remove(c.mesh);
        c.mesh.geometry.dispose();
        (c.mesh.material as THREE.Material).dispose();
        this.contrails.splice(i, 1);
        continue;
      }
      (c.mesh.material as THREE.MeshBasicMaterial).opacity = 0.42 * (1 - c.age / c.maxAge);
    }

    for (let i = this.smoke.length - 1; i >= 0; i--) {
      const p = this.smoke[i];
      p.age += dt;
      if (p.age >= p.maxAge) {
        this.worldScene.remove(p.mesh);
        this.smoke.splice(i, 1);
        continue;
      }
      const t = p.age / p.maxAge;
      p.vel.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      p.mesh.rotation.x += p.angVel.x * dt;
      p.mesh.rotation.y += p.angVel.y * dt;
      p.mesh.scale.setScalar(THREE.MathUtils.lerp(p.startScale, p.endScale, t));
      (p.mesh.material as THREE.MeshStandardMaterial).opacity = (1 - t) * 0.65;
    }
  }

  // ===========================================================================
  //  Rendering (world pass -> clear depth -> viewmodel pass, + live scope PiP)
  // ===========================================================================
  public render(renderer: THREE.WebGLRenderer): void {
    const rig = this.rigs.sniper;
    if (this.weaponId === 'sniper' && rig.scopeLensUniforms && this.adsBlend > 0.04) {
      const breath = this.adsBlend > 0.4 ? Math.sin(this.rawTime * 1.65) * 0.0018 * (1 - this.crouchBlend * 0.45) : 0;
      this.scopeCamera.position.copy(this.worldCamera.position);
      this.scopeCamera.position.y += this.landJolt * 0.2;
      this.scopeCamera.rotation.y = this.rYaw + this.freeAimYaw;
      this.scopeCamera.rotation.x = THREE.MathUtils.clamp(
        this.pitch + this.freeAimPitch + this.camRecoilPitch + breath,
        -1.38,
        1.38
      );
      this.scopeCamera.rotation.z = 0;
      this.scopeCamera.updateMatrixWorld(true);

      const prevAuto = renderer.shadowMap.autoUpdate;
      renderer.shadowMap.autoUpdate = false;
      renderer.setRenderTarget(this.scopeRT);
      renderer.render(this.worldScene, this.scopeCamera);
      renderer.setRenderTarget(null);
      renderer.shadowMap.autoUpdate = prevAuto;
    }

    renderer.render(this.worldScene, this.worldCamera);
    const prevClear = renderer.autoClear;
    renderer.autoClear = false;
    renderer.clearDepth();
    renderer.render(this.vmScene, this.vmCamera);
    renderer.autoClear = prevClear;
  }

  public dispose(): void {
    this.scopeRT.dispose();
  }
}
