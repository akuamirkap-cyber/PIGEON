import * as THREE from 'three';
import { WeaponId } from './types';
import { addToonOutline, createToonMat } from './toon';
import {
  createLiveMagnifyingScopeMaterial,
  createMuzzleFlash,
  createSculptedLowPolyArm,
  WeaponRig,
} from './weaponModels';

/**
 * Splatoon-style toy snowball guns (chunky rounded shapes, bright two-tone colours, clear snow tanks
 * full of snowballs, glossy rim-lit toon shading + thin ink outline).
 * Hand grip points, animated parts (slide / hammer / bolt / dust cover / charging handle / mag) and sockets
 * keep the exact coordinates of the original rigs, so every recoil / reload / bolt-cycle animation still works.
 */

const NAVY_OUTLINE = 0x141a38;

function mk(
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x: number,
  y: number,
  z: number,
  outline = 0.0026,
  rx = 0,
  ry = 0,
  rz = 0
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  if (outline > 0) addToonOutline(m, outline, NAVY_OUTLINE);
  return m;
}

/** capsule whose axis runs along Z */
function zCap(r: number, len: number): THREE.CapsuleGeometry {
  const g = new THREE.CapsuleGeometry(r, len, 6, 16);
  g.rotateX(Math.PI / 2);
  return g;
}

/** cylinder along Z: rFront is the radius at the -Z (muzzle) end, rBack at the +Z end */
function zTube(rFront: number, rBack: number, len: number, seg = 18): THREE.CylinderGeometry {
  const g = new THREE.CylinderGeometry(rBack, rFront, len, seg);
  g.rotateX(Math.PI / 2);
  return g;
}

function tankMat(): THREE.MeshToonMaterial {
  return createToonMat(0x9fe9ff, { transparent: true, opacity: 0.4, depthWrite: false, rim: 0.9, rimColor: 0xffffff });
}

function ball(r: number): THREE.SphereGeometry {
  return new THREE.SphereGeometry(r, 12, 10);
}

interface Parts {
  id: WeaponId;
  root: THREE.Group;
  weaponBody: THREE.Group;
  rightArm: THREE.Group;
  leftArm: THREE.Group;
  mag: THREE.Group;
  muzzle: THREE.Vector3;
  eject: THREE.Vector3;
  action: THREE.Vector3;
  magSock: THREE.Vector3;
  extras: Partial<WeaponRig>;
}

function finish(p: Parts): WeaponRig {
  const muzzleSocket = new THREE.Object3D();
  muzzleSocket.position.copy(p.muzzle);
  p.weaponBody.add(muzzleSocket);
  const muzzleFlash = createMuzzleFlash(p.id);
  muzzleSocket.add(muzzleFlash);

  const ejectionSocket = new THREE.Object3D();
  ejectionSocket.position.copy(p.eject);
  p.weaponBody.add(ejectionSocket);
  const actionSocket = new THREE.Object3D();
  actionSocket.position.copy(p.action);
  p.weaponBody.add(actionSocket);
  const magSocket = new THREE.Object3D();
  magSocket.position.copy(p.magSock);
  p.weaponBody.add(magSocket);

  p.weaponBody.add(p.rightArm, p.leftArm);

  return {
    id: p.id,
    root: p.root,
    weaponBody: p.weaponBody,
    leftArm: p.leftArm,
    rightArm: p.rightArm,
    mag: p.mag,
    muzzleSocket,
    ejectionSocket,
    actionSocket,
    magSocket,
    muzzleFlash,
    leftArmRestPos: p.leftArm.position.clone(),
    leftArmRestRot: p.leftArm.rotation.clone(),
    rightArmRestPos: p.rightArm.position.clone(),
    rightArmRestRot: p.rightArm.rotation.clone(),
    magRestPos: p.mag.position.clone(),
    magRestRot: p.mag.rotation.clone(),
    ...p.extras,
  } as WeaponRig;
}

function snowCartridge(accent: THREE.Material, tank: THREE.Material, snow: THREE.Material): THREE.Group {
  const mag = new THREE.Group();
  mag.add(mk(new THREE.CapsuleGeometry(0.019, 0.05, 6, 12), tank, 0, 0, 0, 0));
  mag.add(mk(ball(0.014), snow, 0, 0.018, 0, 0.001));
  mag.add(mk(ball(0.014), snow, 0, -0.012, 0.002, 0.001));
  mag.add(mk(new THREE.CylinderGeometry(0.021, 0.021, 0.012, 14), accent, 0, -0.045, 0, 0.002));
  return mag;
}

// ============================================================================
//  1. SNOWBALL PISTOL — "Pop Blaster" (aqua body, orange pump nozzle)
// ============================================================================
function buildSplatPistol(): WeaponRig {
  const root = new THREE.Group();
  const wb = new THREE.Group();
  root.add(wb);

  const main = createToonMat(0x19d3da);
  const accent = createToonMat(0xff7a1a);
  const dark = createToonMat(0x1b2a5a);
  const white = createToonMat(0xf4f9ff);
  const snow = createToonMat(0xffffff);
  const tank = tankMat();

  // chunky rounded body + accent ring + rear cap
  wb.add(mk(zCap(0.026, 0.13), main, 0, 0.012, -0.04));
  wb.add(mk(new THREE.TorusGeometry(0.0275, 0.0045, 8, 22), accent, 0, 0.012, -0.012, 0.0015));
  wb.add(mk(ball(0.021), white, 0, 0.012, 0.05));

  // grip (hands wrap here: same place as the original pistol grip)
  const grip = new THREE.Group();
  grip.position.set(0, -0.05, 0.026);
  grip.rotation.x = 0.24;
  grip.add(mk(new THREE.CapsuleGeometry(0.02, 0.07, 6, 14), dark, 0, 0, 0));
  grip.add(mk(new THREE.TorusGeometry(0.0208, 0.004, 6, 18), accent, 0, 0.012, 0, 0.0015, Math.PI / 2));
  grip.add(mk(ball(0.0215), accent, 0, -0.045, 0));
  wb.add(grip);

  // trigger + guard
  const trigger = new THREE.Group();
  trigger.position.set(0, -0.002, -0.025);
  trigger.add(mk(new THREE.CapsuleGeometry(0.005, 0.02, 4, 8), white, 0, -0.014, -0.003, 0.0012, 0.28));
  wb.add(trigger);
  wb.add(mk(zCap(0.005, 0.045), dark, 0, -0.03, -0.04, 0.001));

  // pump nozzle (slides back on every shot)
  const slide = new THREE.Group();
  slide.add(mk(zCap(0.021, 0.05), accent, 0, 0.014, -0.12));
  slide.add(mk(zTube(0.014, 0.017, 0.05), main, 0, 0.014, -0.19));
  slide.add(mk(new THREE.TorusGeometry(0.0148, 0.0035, 6, 16), white, 0, 0.014, -0.216, 0.001));
  slide.add(mk(new THREE.CapsuleGeometry(0.0035, 0.018, 4, 8), dark, 0, 0.044, -0.17, 0.0008));
  slide.add(mk(ball(0.0065), accent, 0, 0.0605, -0.17, 0.001));
  wb.add(slide);

  // rear notch sight
  for (const sx of [-1, 1]) {
    wb.add(mk(new THREE.CapsuleGeometry(0.0045, 0.018, 4, 8), accent, sx * 0.011, 0.05, 0.036, 0.001));
  }

  // charge knob ("hammer")
  const hammer = new THREE.Group();
  hammer.position.set(0, 0.02, 0.055);
  hammer.add(mk(new THREE.CapsuleGeometry(0.006, 0.014, 4, 8), white, 0, 0.012, 0.004, 0.001));
  hammer.add(mk(ball(0.013), accent, 0, 0.028, 0.008, 0.0015));
  wb.add(hammer);

  // snow cartridge (reload part)
  const mag = snowCartridge(accent, tank, snow);
  mag.position.set(0, -0.048, -0.045);
  mag.rotation.x = 0.24;
  wb.add(mag);

  const rightArm = createSculptedLowPolyArm({
    side: 'right',
    fingerCurl: 1.0,
    indexExtended: true,
    thumbSpread: 0.26,
    thumbPitch: 0.14,
    forearmPitch: -0.24,
    forearmYaw: 0.28,
    forearmLength: 0.62,
  });
  rightArm.position.set(0.032, -0.042, 0.038);
  rightArm.rotation.set(0.18, 0.08, -1.4);
  const leftArm = createSculptedLowPolyArm({
    side: 'left',
    fingerCurl: 1.04,
    indexExtended: false,
    thumbSpread: 0.2,
    thumbPitch: 0.18,
    forearmPitch: -0.24,
    forearmYaw: -0.28,
    forearmLength: 0.62,
  });
  leftArm.position.set(-0.036, -0.04, 0.026);
  leftArm.rotation.set(0.18, -0.08, 1.38);

  return finish({
    id: 'pistol',
    root,
    weaponBody: wb,
    rightArm,
    leftArm,
    mag,
    muzzle: new THREE.Vector3(0, 0.014, -0.222),
    eject: new THREE.Vector3(0.024, 0.04, -0.036),
    action: new THREE.Vector3(-0.02, 0.05, -0.09),
    magSock: new THREE.Vector3(0, -0.115, -0.045),
    extras: { slide, hammer, trigger },
  });
}

// ============================================================================
//  2. SNOWBALL RIFLE — "Blast Rifle" (pink body, lime ring sight, snow drum)
// ============================================================================
function buildSplatRifle(): WeaponRig {
  const root = new THREE.Group();
  const wb = new THREE.Group();
  root.add(wb);

  const main = createToonMat(0xff3d8b);
  const accent = createToonMat(0xb6ff2e);
  const dark = createToonMat(0x2a1b5a);
  const white = createToonMat(0xf8f4ff);
  const snow = createToonMat(0xffffff);
  const tank = tankMat();
  const ringGlass = new THREE.MeshBasicMaterial({
    color: 0xb6ff2e,
    transparent: true,
    opacity: 0.16,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  // receiver, stock, handguard
  wb.add(mk(zCap(0.034, 0.28), main, 0, 0.012, -0.1));
  wb.add(mk(new THREE.TorusGeometry(0.0355, 0.005, 8, 22), accent, 0, 0.012, -0.02, 0.0018));
  wb.add(mk(new THREE.TorusGeometry(0.0355, 0.005, 8, 22), accent, 0, 0.012, -0.2, 0.0018));
  wb.add(mk(zCap(0.028, 0.08), dark, 0, -0.004, 0.15));
  wb.add(mk(ball(0.03), white, 0, -0.004, 0.2, 0.002));
  wb.add(mk(zCap(0.036, 0.1), dark, 0, 0.0, -0.275));

  // barrel shroud + splat nozzle
  wb.add(mk(zTube(0.03, 0.03, 0.26), main, 0, 0.012, -0.45));
  wb.add(mk(zTube(0.046, 0.03, 0.1), accent, 0, 0.012, -0.63));
  wb.add(mk(new THREE.TorusGeometry(0.047, 0.006, 8, 22), white, 0, 0.012, -0.685, 0.0018));
  wb.add(mk(zTube(0.027, 0.027, 0.04), dark, 0, 0.012, -0.72));

  // big snow tank under the barrel
  wb.add(mk(zCap(0.044, 0.16), tank, 0, -0.045, -0.42, 0));
  for (let i = 0; i < 4; i++) {
    wb.add(mk(ball(0.03), snow, 0, -0.045, -0.35 - i * 0.05, 0.0015));
  }
  wb.add(mk(zTube(0.048, 0.048, 0.012), accent, 0, -0.045, -0.5, 0.002));
  wb.add(mk(zTube(0.048, 0.048, 0.012), accent, 0, -0.045, -0.33, 0.002));

  // lime ring sight (eye line y = 0.118)
  wb.add(mk(new THREE.CapsuleGeometry(0.011, 0.04, 4, 10), dark, 0, 0.068, -0.02, 0.0015));
  wb.add(mk(new THREE.TorusGeometry(0.027, 0.0055, 8, 24), accent, 0, 0.118, -0.02, 0.0016));
  const glass = new THREE.Mesh(new THREE.CircleGeometry(0.0235, 24), ringGlass);
  glass.position.set(0, 0.118, -0.02);
  wb.add(glass);

  // grip (hand wraps here)
  const grip = new THREE.Group();
  grip.position.set(0, -0.094, 0.05);
  grip.rotation.x = 0.34;
  grip.add(mk(new THREE.CapsuleGeometry(0.021, 0.075, 6, 14), dark, 0, 0, 0));
  grip.add(mk(new THREE.TorusGeometry(0.0218, 0.0045, 6, 18), accent, 0, 0.014, 0, 0.0016, Math.PI / 2));
  grip.add(mk(ball(0.0225), accent, 0, -0.048, 0));
  wb.add(grip);

  const trigger = new THREE.Group();
  trigger.position.set(0, -0.045, 0.0);
  trigger.add(mk(new THREE.CapsuleGeometry(0.005, 0.02, 4, 8), white, 0, -0.012, -0.003, 0.0012, 0.28));
  wb.add(trigger);

  // reciprocating feed piston ("bolt")
  const bolt = new THREE.Group();
  bolt.add(mk(zCap(0.009, 0.05), white, 0.037, 0.03, -0.035, 0.0014));
  bolt.add(mk(ball(0.012), accent, 0.037, 0.03, 0.0, 0.0014));
  wb.add(bolt);

  // feed lid ("dust cover")
  const dustCover = new THREE.Group();
  dustCover.position.set(0.0295, 0.025, -0.035);
  const lid = mk(ball(0.02), accent, 0, 0.012, 0, 0.0014);
  lid.scale.set(0.22, 1, 1.7);
  dustCover.add(lid);
  wb.add(dustCover);

  // cocking T-handle
  const chargingHandle = new THREE.Group();
  chargingHandle.position.set(0, 0.055, 0.095);
  chargingHandle.add(mk(new THREE.CapsuleGeometry(0.008, 0.05, 4, 8), accent, 0, 0, 0, 0.0014, 0, 0, Math.PI / 2));
  chargingHandle.add(mk(zCap(0.005, 0.02), white, 0, 0, -0.02, 0.001));
  wb.add(chargingHandle);

  // snow drum magazine
  const mag = new THREE.Group();
  mag.position.set(0, -0.07, -0.094);
  mag.add(mk(new THREE.CylinderGeometry(0.03, 0.03, 0.09, 16), tank, 0, -0.04, 0, 0));
  mag.add(mk(ball(0.02), snow, 0, -0.02, 0.0, 0.001));
  mag.add(mk(ball(0.02), snow, 0.004, -0.05, 0.004, 0.001));
  mag.add(mk(new THREE.CylinderGeometry(0.032, 0.032, 0.014, 16), accent, 0, -0.09, 0, 0.002));
  wb.add(mag);

  const rightArm = createSculptedLowPolyArm({
    side: 'right',
    fingerCurl: 1.08,
    indexExtended: true,
    thumbSpread: 0.34,
    thumbPitch: 0.16,
    forearmPitch: -0.24,
    forearmYaw: 0.32,
    forearmLength: 0.58,
  });
  rightArm.position.set(0.029, -0.094, 0.05);
  rightArm.rotation.set(0.34, 0.08, -1.44);
  const leftArm = createSculptedLowPolyArm({
    side: 'left',
    fingerCurl: 0.88,
    indexExtended: false,
    thumbSpread: 0.36,
    thumbPitch: 0.14,
    forearmPitch: -0.44,
    forearmYaw: -0.24,
    forearmLength: 0.6,
  });
  leftArm.position.set(-0.022, -0.028, -0.275);
  leftArm.rotation.set(0.14, -0.12, 2.44);

  return finish({
    id: 'rifle',
    root,
    weaponBody: wb,
    rightArm,
    leftArm,
    mag,
    muzzle: new THREE.Vector3(0, 0.014, -0.74),
    eject: new THREE.Vector3(0.034, 0.04, -0.032),
    action: new THREE.Vector3(0.028, 0.056, -0.032),
    magSock: new THREE.Vector3(0, -0.17, -0.112),
    extras: { bolt, dustCover, chargingHandle, trigger },
  });
}

// ============================================================================
//  3. SNOWBALL SNIPER — "Snow Charger" (purple body, yellow nozzle, long clear snow tube, live scope)
// ============================================================================
function buildSplatSniper(scopeTexture?: THREE.Texture): WeaponRig {
  const root = new THREE.Group();
  const wb = new THREE.Group();
  root.add(wb);

  const main = createToonMat(0x8f4dff);
  const accent = createToonMat(0xffd426);
  const dark = createToonMat(0x1a1740);
  const white = createToonMat(0xf6f2ff);
  const snow = createToonMat(0xffffff);
  const tank = tankMat();
  const black = new THREE.MeshBasicMaterial({ color: 0x05060a, side: THREE.DoubleSide });

  // chassis + stock
  wb.add(mk(zCap(0.03, 0.28), main, 0, 0.012, -0.04));
  wb.add(mk(new THREE.TorusGeometry(0.0315, 0.0048, 8, 22), accent, 0, 0.012, -0.12, 0.0018));
  wb.add(mk(zCap(0.03, 0.1), dark, 0, -0.004, 0.15));
  wb.add(mk(ball(0.032), white, 0, -0.004, 0.205, 0.002));
  wb.add(mk(zCap(0.036, 0.09), main, 0, 0.0, -0.27));

  // long barrel + charger snow tube with a line of snowballs
  wb.add(mk(zCap(0.016, 0.55), dark, 0, 0.026, -0.5));
  wb.add(mk(zCap(0.027, 0.34), tank, 0, -0.012, -0.6, 0));
  for (let i = 0; i < 6; i++) {
    wb.add(mk(ball(0.02), snow, 0, -0.012, -0.47 - i * 0.052, 0.0012));
  }
  wb.add(mk(zTube(0.03, 0.03, 0.012), accent, 0, -0.012, -0.435, 0.002));
  wb.add(mk(zTube(0.03, 0.03, 0.012), accent, 0, -0.012, -0.765, 0.002));

  // flared nozzle
  wb.add(mk(zTube(0.036, 0.016, 0.1), accent, 0, 0.026, -0.84));
  wb.add(mk(new THREE.TorusGeometry(0.037, 0.005, 8, 22), white, 0, 0.026, -0.892, 0.0016));
  wb.add(mk(zTube(0.022, 0.022, 0.06), dark, 0, 0.026, -0.94));

  // grip
  const grip = new THREE.Group();
  grip.position.set(0, -0.074, 0.068);
  grip.rotation.x = 0.32;
  grip.add(mk(new THREE.CapsuleGeometry(0.021, 0.07, 6, 14), dark, 0, 0, 0));
  grip.add(mk(new THREE.TorusGeometry(0.0218, 0.0045, 6, 18), accent, 0, 0.012, 0, 0.0016, Math.PI / 2));
  grip.add(mk(ball(0.0225), accent, 0, -0.044, 0));
  wb.add(grip);

  const trigger = new THREE.Group();
  trigger.position.set(0, -0.026, 0.02);
  trigger.add(mk(new THREE.CapsuleGeometry(0.005, 0.02, 4, 8), white, 0, -0.012, -0.003, 0.0012, 0.28));
  wb.add(trigger);

  // bolt + rotating charge handle (same pivots as the original so the hand grabs the knob)
  const bolt = new THREE.Group();
  bolt.position.set(0, 0.036, -0.02);
  bolt.add(mk(zCap(0.012, 0.1), accent, 0.014, 0, -0.015, 0.0016));
  bolt.add(mk(ball(0.02), white, 0, 0.002, 0.075, 0.0018));
  const boltHandle = new THREE.Group();
  boltHandle.position.set(0.016, 0.0, 0.045);
  boltHandle.add(mk(new THREE.CapsuleGeometry(0.0075, 0.045, 4, 10), dark, 0.03, -0.009, 0.005, 0.0014, 0, 0, Math.PI / 2 + 0.32));
  boltHandle.add(mk(ball(0.02), accent, 0.064, -0.022, 0.008, 0.0018));
  bolt.add(boltHandle);
  wb.add(bolt);

  // scope: same axis / lens position as the original so ADS lines the eye up behind the live lens
  const scope = new THREE.Group();
  scope.position.set(0, 0.124, -0.068);
  scope.add(mk(zCap(0.022, 0.2), dark, 0, 0, 0, 0.0018));
  scope.add(mk(zTube(0.04, 0.026, 0.07), accent, 0, 0, -0.16, 0.002));
  scope.add(mk(zTube(0.026, 0.026, 0.006), black, 0, 0, -0.197, 0));
  scope.add(mk(zTube(0.031, 0.024, 0.07), main, 0, 0, 0.2, 0.002));
  scope.add(mk(ball(0.0125), accent, 0.032, 0, 0, 0.0012));
  scope.add(mk(ball(0.0125), accent, -0.032, 0, 0, 0.0012));
  scope.add(mk(ball(0.0125), accent, 0, 0.034, 0, 0.0012));
  const backstop = new THREE.Mesh(new THREE.CircleGeometry(0.034, 24), black);
  backstop.position.set(0, 0, 0.236);
  scope.add(backstop);
  const lensZ = 0.241;
  const { material: lensMat, uniforms: scopeLensUniforms } = createLiveMagnifyingScopeMaterial(scopeTexture);
  const lens = new THREE.Mesh(new THREE.CircleGeometry(0.0332, 36), lensMat);
  lens.position.set(0, 0, lensZ);
  scope.add(lens);
  const bezel = new THREE.Mesh(new THREE.TorusGeometry(0.0345, 0.0035, 8, 32), createToonMat(0xffffff));
  bezel.position.set(0, 0, lensZ + 0.0016);
  scope.add(bezel);
  wb.add(scope);
  // scope mounts
  wb.add(mk(new THREE.CapsuleGeometry(0.011, 0.03, 4, 10), dark, 0, 0.082, 0.012, 0.0014));
  wb.add(mk(new THREE.CapsuleGeometry(0.011, 0.03, 4, 10), dark, 0, 0.082, -0.148, 0.0014));

  // snow cartridge (reload part)
  const mag = snowCartridge(accent, tank, snow);
  mag.position.set(0, -0.048, -0.095);
  wb.add(mag);

  const rightArm = createSculptedLowPolyArm({
    side: 'right',
    fingerCurl: 1.06,
    indexExtended: true,
    thumbSpread: 0.34,
    thumbPitch: 0.15,
    forearmPitch: -0.24,
    forearmYaw: 0.3,
    forearmLength: 0.58,
  });
  rightArm.position.set(0.031, -0.074, 0.068);
  rightArm.rotation.set(0.32, 0.08, -1.44);
  const leftArm = createSculptedLowPolyArm({
    side: 'left',
    fingerCurl: 0.84,
    indexExtended: false,
    thumbSpread: 0.32,
    thumbPitch: 0.14,
    forearmPitch: -0.3,
    forearmYaw: -0.34,
    forearmLength: 0.64,
  });
  leftArm.position.set(-0.036, -0.018, -0.27);
  leftArm.rotation.set(0.12, -0.14, 1.98);

  return finish({
    id: 'sniper',
    root,
    weaponBody: wb,
    rightArm,
    leftArm,
    mag,
    muzzle: new THREE.Vector3(0, 0.026, -0.975),
    eject: new THREE.Vector3(0.038, 0.044, -0.052),
    action: new THREE.Vector3(0.065, 0.035, 0.025),
    magSock: new THREE.Vector3(0, -0.11, -0.095),
    extras: { bolt, boltHandle, trigger, scopeLensUniforms },
  });
}

export function buildAllWeaponRigs(sniperScopeTexture?: THREE.Texture): Record<WeaponId, WeaponRig> {
  return {
    pistol: buildSplatPistol(),
    rifle: buildSplatRifle(),
    sniper: buildSplatSniper(sniperScopeTexture),
  };
}
