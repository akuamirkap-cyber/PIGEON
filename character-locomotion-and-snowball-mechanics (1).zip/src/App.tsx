import React, { useEffect, useRef, useState } from 'react';
import {
  Crown,
  Flame,
  Heart,
  RefreshCw,
  RotateCcw,
  Shield,
  Sliders,
  Snowflake,
  Sparkles,
  Trophy,
  Users,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { BrawlHud } from './components/BrawlHud';
import {
  CharacterConfig,
  DebugTelemetry,
  DEFAULT_CONFIG,
  INITIAL_TESTS,
  PowerUpType,
} from './config/GameConfig';
import { SimulationEngine } from './engine/SimulationEngine';

const INITIAL_TELEMETRY: DebugTelemetry = {
  velocity: { x: 0, y: 0, z: 0 },
  speed: 0,
  blendSpeed: 0,
  blendDirection: 0,
  forwardComponent: 1,
  locomotionState: 'IDLE',
  upperActionState: 'NONE',
  throwPhase: 'NONE',
  directionMode: 'COMBAT',
  baseGait: 'JOG',
  hasSnowball: false,
  chargeRatio: 0,
  throwPowerFactor: 1,
  aimDirection: { x: 0, y: 0, z: 1 },
  aimPitchDeg: 0,
  projectileVelocity: { x: 0, y: 0, z: 0 },
  projectileSpeed: 0,
  activeProjectiles: 0,
  lastHitInfo: '',
  pointerLocked: false,
  playerHp: 3,
  playerMaxHp: 3,
  playerScore: 0,
  playerKos: 0,
  playerStreak: 0,
  activePowerUp: null,
  powerUpRemaining: 0,
  botAliveCount: 5,
  totalBotCount: 5,
  matchTimeRemaining: 150,
  hitMarkerActive: false,
  leaderboard: [],
  killFeed: [],
  latestCallout: null,
  playerTeam: 'BLUE',
  blueScore: 0,
  redScore: 0,
  scoreLimit: 25,
  alliesAlive: 5,
  enemiesAlive: 5,
  fpsActive: true,
  fpsWeapon: 'rifle',
  fpsWeaponName: 'M4A1 CARBINE',
  fpsFireMode: 'FULL-AUTO',
  fpsAmmo: 30,
  fpsMagSize: 30,
  fpsReloading: false,
  fpsAmmoType: 'BULLET',
  fpsAdsBlend: 0,
  fpsSpread: 0.2,
  fpsScoped: false,
  damagePulse: 0,
  isRolling: false,
  rollEnergy: 1,
  isCrouching: false,
  crosshairOnEnemy: false,
  tests: { ...INITIAL_TESTS },
};

const POWERUP_META: Record<PowerUpType, { label: string; badgeClass: string; icon: React.ReactNode; unit: 'sec' | 'x' }> = {
  MEGA: {
    label: 'DAMAGE x2',
    badgeClass: 'border-orange-400 bg-orange-500/30 text-orange-100',
    icon: <Snowflake className="h-4 w-4 text-orange-300" />,
    unit: 'sec',
  },
  TURBO: {
    label: 'TURBO BOOTS',
    badgeClass: 'border-yellow-400 bg-yellow-500/30 text-yellow-100',
    icon: <Zap className="h-4 w-4 text-yellow-300" />,
    unit: 'sec',
  },
  TRIPLE: {
    label: 'RAPID FIRE',
    badgeClass: 'border-purple-400 bg-purple-500/30 text-purple-100',
    icon: <Sparkles className="h-4 w-4 text-purple-300" />,
    unit: 'sec',
  },
  SHIELD: {
    label: 'FROST SHIELD',
    badgeClass: 'border-sky-400 bg-sky-500/30 text-sky-100',
    icon: <Shield className="h-4 w-4 text-sky-300" />,
    unit: 'x',
  },
};

interface SliderRowProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  onChange: (val: number) => void;
}

const SliderRow: React.FC<SliderRowProps> = ({ label, value, min, max, step, unit = '', onChange }) => (
  <div className="space-y-1">
    <div className="flex items-center justify-between text-[11px]">
      <span className="text-slate-300">{label}</span>
      <span className="font-mono font-semibold text-sky-300">
        {value.toFixed(step < 0.01 ? 4 : step < 0.1 ? 2 : 1)}
        {unit}
      </span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-slate-700 accent-sky-400"
    />
  </div>
);

function formatMatchTime(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;
}

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<SimulationEngine | null>(null);

  const [config, setConfig] = useState<CharacterConfig>(DEFAULT_CONFIG);
  const [telemetry, setTelemetry] = useState<DebugTelemetry>(INITIAL_TELEMETRY);
  const [tuningOpen, setTuningOpen] = useState(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;
    const engine = new SimulationEngine(container, DEFAULT_CONFIG, (snap) => setTelemetry(snap));
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const updateParam = <K extends keyof CharacterConfig>(key: K, val: CharacterConfig[K]) => {
    setConfig((prev) => {
      const next = { ...prev, [key]: val };
      engineRef.current?.updateConfig(next);
      return next;
    });
  };

  const resetConfig = () => {
    setConfig(DEFAULT_CONFIG);
    engineRef.current?.updateConfig(DEFAULT_CONFIG);
  };

  const powerMeta = telemetry.activePowerUp ? POWERUP_META[telemetry.activePowerUp] : null;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-sky-950 text-slate-100">
      <div ref={mountRef} className="h-full w-full cursor-crosshair" />

      <BrawlHud telemetry={telemetry} />

      {/* Arcade callout banner */}
      {telemetry.latestCallout && (
        <div className="pointer-events-none absolute top-[28%] left-1/2 flex -translate-x-1/2 flex-col items-center text-center">
          <div
            className="whitespace-nowrap rounded-2xl border-2 border-white/30 bg-slate-950/80 px-5 py-1.5 text-xl font-black tracking-wider uppercase shadow-2xl backdrop-blur-md"
            style={{ color: telemetry.latestCallout.color }}
          >
            {telemetry.latestCallout.text}
          </div>
          {telemetry.latestCallout.subtext && (
            <div className="mt-1 whitespace-nowrap rounded-full bg-slate-900/80 px-3 py-0.5 text-xs font-bold text-white shadow">
              {telemetry.latestCallout.subtext}
            </div>
          )}
        </div>
      )}

      {/* TOP-CENTER scoreboard bar */}
      <div className="pointer-events-auto absolute top-3 left-1/2 -translate-x-1/2">
        <div className="flex items-center gap-3 rounded-2xl border-2 border-white/25 bg-slate-900/85 px-4 py-1.5 shadow-2xl backdrop-blur-md">
          <div className="flex items-center gap-1.5 border-r border-slate-700 pr-3">
            <span className="text-[10px] font-bold tracking-wider text-sky-300 uppercase">TIME</span>
            <span className="font-mono text-base font-black text-white">{formatMatchTime(telemetry.matchTimeRemaining)}</span>
          </div>
          <div className="flex items-center gap-1.5 border-r border-slate-700 pr-3">
            <Trophy className="h-4 w-4 text-amber-400" />
            <span className="font-mono text-base font-black text-amber-300">{telemetry.playerScore}</span>
          </div>
          <div className="flex items-center gap-1.5 border-r border-slate-700 pr-3">
            <Flame className="h-4 w-4 text-rose-400" />
            <span className="font-mono text-sm font-extrabold text-white">{telemetry.playerKos} KO</span>
            {telemetry.playerStreak >= 2 && (
              <span className="rounded-full bg-orange-500 px-1.5 py-0.5 text-[10px] font-black text-white">
                {telemetry.playerStreak}x
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5">
            <Users className="h-4 w-4 text-emerald-400" />
            <span className="font-mono text-xs font-bold text-emerald-300">5 VS 5 • FPS</span>
          </div>
          <button
            type="button"
            onClick={() => engineRef.current?.restartMatch()}
            className="ml-1 rounded-lg bg-sky-500/25 p-1.5 text-sky-200 transition hover:bg-sky-500/40"
            title="Mulai Ronde Baru"
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* TOP-RIGHT: audio, tuning, leaderboard & killfeed */}
      <div className="pointer-events-auto absolute top-3 right-3 flex flex-col items-end gap-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => updateParam('audioEnabled', !config.audioEnabled)}
            className="rounded-xl border border-white/20 bg-slate-900/80 p-2 text-slate-200 shadow-lg backdrop-blur-md hover:border-sky-400/50"
            title="Toggle Audio"
          >
            {config.audioEnabled ? <Volume2 className="h-4 w-4 text-sky-300" /> : <VolumeX className="h-4 w-4 text-slate-500" />}
          </button>
          <button
            type="button"
            onClick={() => setTuningOpen((o) => !o)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-bold shadow-lg backdrop-blur-md transition ${
              tuningOpen
                ? 'border-sky-400 bg-sky-500/25 text-sky-200'
                : 'border-white/20 bg-slate-900/80 text-slate-200 hover:border-sky-400/50'
            }`}
          >
            <Sliders className="h-3.5 w-3.5" />
            <span>Tuning</span>
          </button>
        </div>

        {!tuningOpen && telemetry.leaderboard.length > 0 && (
          <div className="w-56 rounded-2xl border border-white/20 bg-slate-900/80 p-2.5 text-xs shadow-xl backdrop-blur-md">
            <div className="mb-1.5 flex items-center justify-between border-b border-slate-700/70 pb-1">
              <div className="flex items-center gap-1.5 font-extrabold tracking-wide text-amber-300">
                <Crown className="h-3.5 w-3.5" />
                <span>TOP BRAWLERS</span>
              </div>
              <span className="text-[10px] font-semibold text-slate-400">SKOR</span>
            </div>
            <div className="space-y-1">
              {telemetry.leaderboard.map((entry, idx) => (
                <div
                  key={entry.id}
                  className={`flex items-center justify-between rounded-lg px-2 py-1 ${
                    entry.isPlayer ? 'border border-sky-400/50 bg-sky-500/25 font-bold text-white' : 'bg-slate-800/60 text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <span className={`font-mono text-[10px] font-black ${idx === 0 ? 'text-amber-300' : 'text-slate-400'}`}>#{idx + 1}</span>
                    <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: entry.colorHex }} />
                    <span className="truncate text-[11px]">{entry.name}</span>
                  </div>
                  <span className="font-mono text-[11px] font-bold text-amber-300">{entry.score}</span>
                </div>
              ))}
            </div>
            {telemetry.killFeed.length > 0 && (
              <div className="mt-2 space-y-1 border-t border-slate-700/70 pt-1.5">
                {telemetry.killFeed.slice(0, 3).map((kf) => (
                  <div key={kf.id} className="flex items-center justify-between truncate rounded bg-slate-950/60 px-2 py-0.5 text-[10px]">
                    <span className={`truncate font-bold ${kf.killerIsPlayer ? 'text-sky-300' : 'text-slate-300'}`}>{kf.killer}</span>
                    <span className="mx-1 shrink-0 text-orange-400">{kf.isMega ? '💥' : '❄️'}</span>
                    <span className={`truncate font-semibold ${kf.victimIsPlayer ? 'text-rose-400' : 'text-slate-400'}`}>{kf.victim}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tuningOpen && (
          <div className="max-h-[calc(100vh-8rem)] w-80 space-y-3 overflow-y-auto rounded-xl border border-slate-700/80 bg-slate-900/92 p-3.5 text-xs shadow-2xl backdrop-blur-md">
            <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
              <span className="font-semibold text-sky-300">TUNING FPS</span>
              <button
                type="button"
                onClick={resetConfig}
                className="flex items-center gap-1 rounded bg-slate-800 px-2 py-0.5 text-[11px] text-slate-300 hover:bg-slate-700"
              >
                <RotateCcw className="h-3 w-3" />
                Reset
              </button>
            </div>
            <SliderRow label="aimSensitivity" value={config.aimSensitivity} min={0.0008} max={0.005} step={0.0002} onChange={(v) => updateParam('aimSensitivity', v)} />
            <SliderRow label="jogSpeed (jalan)" value={config.jogSpeed} min={2.5} max={6.0} step={0.05} unit=" m/s" onChange={(v) => updateParam('jogSpeed', v)} />
            <SliderRow label="runSpeed (sprint)" value={config.runSpeed} min={4.0} max={8.0} step={0.05} unit=" m/s" onChange={(v) => updateParam('runSpeed', v)} />
            <SliderRow label="jumpForce" value={config.jumpForce} min={4.5} max={9.0} step={0.1} unit=" m/s" onChange={(v) => updateParam('jumpForce', v)} />
            <SliderRow label="acceleration" value={config.acceleration} min={6.0} max={26.0} step={0.5} unit=" m/s²" onChange={(v) => updateParam('acceleration', v)} />
            <SliderRow label="deceleration" value={config.deceleration} min={3.5} max={16.0} step={0.2} unit=" m/s²" onChange={(v) => updateParam('deceleration', v)} />
          </div>
        )}
      </div>

      {/* BOTTOM-LEFT: HP + power-up */}
      <div className="pointer-events-none absolute bottom-3 left-3 flex flex-col gap-2">
        {powerMeta && (
          <div className={`flex items-center gap-2 rounded-xl border-2 px-3 py-1.5 text-xs font-extrabold shadow-xl backdrop-blur-md ${powerMeta.badgeClass}`}>
            {powerMeta.icon}
            <span>{powerMeta.label}</span>
            <span className="rounded bg-slate-950/50 px-1.5 py-0.5 font-mono text-[11px]">
              {powerMeta.unit === 'sec' ? `${telemetry.powerUpRemaining.toFixed(1)}s` : `x${Math.round(telemetry.powerUpRemaining)}`}
            </span>
          </div>
        )}
        <div className="flex items-center gap-1 rounded-2xl border-2 border-white/20 bg-slate-900/85 px-3.5 py-2 shadow-xl backdrop-blur-md">
          {Array.from({ length: telemetry.playerMaxHp }).map((_, i) => (
            <Heart
              key={i}
              className={`h-5 w-5 ${i < telemetry.playerHp ? 'scale-105 fill-rose-500 text-rose-400' : 'fill-slate-800 text-slate-600'}`}
            />
          ))}
        </div>
      </div>

      {/* BOTTOM-CENTER controls */}
      <div className="pointer-events-none absolute bottom-3 left-1/2 flex max-w-[70vw] -translate-x-1/2 flex-wrap items-center justify-center gap-x-3 gap-y-1 rounded-2xl border border-white/20 bg-slate-900/80 px-4 py-1.5 text-[11px] text-slate-200 shadow-xl backdrop-blur-md">
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-sky-300">WASD</kbd> Gerak</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-sky-300">Shift</kbd> Sprint</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-emerald-300">Space</kbd> Lompat</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-emerald-300">C</kbd> Jongkok</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-sky-300">V</kbd> Gelinding (tahan)</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-orange-300">LMB</kbd> Tembak</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-indigo-300">RMB</kbd> Bidik</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-amber-300">R</kbd> Reload</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-cyan-300">1/2/3</kbd> Senjata</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-sky-300">B</kbd> Peluru↔Snowball</span>
        <span><kbd className="rounded bg-slate-800 px-1.5 py-0.5 font-mono font-bold text-slate-300">F</kbd> Inspect</span>
      </div>
    </div>
  );
}

export default App;
