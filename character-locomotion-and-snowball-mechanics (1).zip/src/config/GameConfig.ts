export type LocomotionState =
  | 'IDLE'
  | 'TURN'
  | 'WALK'
  | 'JOG'
  | 'RUN'
  | 'JUMP'
  | 'DIVE'
  | 'FLINCH'
  | 'RAGDOLL'
  | 'STUMBLE'
  | 'SHARP_TURN'
  | 'STOP';

export type UpperActionState =
  | 'NONE'
  | 'SNOWBALL_PICKUP'
  | 'SNOWBALL_HOLD'
  | 'THROW_PREPARATION'
  | 'THROW'
  | 'THROW_RECOVERY';

export type ThrowPhase =
  | 'NONE'
  | 'ANTICIPATION'
  | 'ACCELERATION'
  | 'RELEASE'
  | 'FOLLOW_THROUGH'
  | 'RECOVERY';

export type DirectionMode = 'MOVEMENT' | 'COMBAT';

export type BaseGaitMode = 'WALK' | 'JOG';

export type PowerUpType = 'MEGA' | 'TURBO' | 'TRIPLE' | 'SHIELD';

export type TeamId = 'BLUE' | 'RED';

export type WeaponType = 'SNOWBALL' | 'LAUNCHER' | 'BAZOOKA';

export type FpsWeaponId = 'pistol' | 'rifle' | 'sniper';

export type HatStyle =
  | 'BEANIE'
  | 'CROWN'
  | 'VIKING'
  | 'BUNNY'
  | 'DINO'
  | 'TOPHAT'
  | 'NINJA';

export interface CharacterAppearance {
  /** 0..3 = the four snow-kid looks */
  look: number;
  /** team accent colour (armbands, roll ball stripes) */
  teamColor: number;
}

export const TEAM_SIZE = 5;
export const SCORE_LIMIT = 25;

export const TEAM_HEX: Record<TeamId, string> = {
  BLUE: '#38bdf8',
  RED: '#f87171',
};

export interface LauncherStats {
  magazine: number;
  burstCount: number;
  burstInterval: number;
  cooldown: number;
  reload: number;
  speedMult: number;
  spread: number;
  gravity: number;
  drag: number;
}

export interface BazookaStats {
  magazine: number;
  cooldown: number;
  reload: number;
  speed: number;
  gravity: number;
  drag: number;
  blastRadius: number;
}

export const WEAPON_STATS: { LAUNCHER: LauncherStats; BAZOOKA: BazookaStats } = {
  LAUNCHER: {
    magazine: 12,
    burstCount: 3,
    burstInterval: 0.07,
    cooldown: 0.46,
    reload: 2.0,
    speedMult: 1.35,
    spread: 0.028,
    gravity: 5.5,
    drag: 0.004,
  },
  BAZOOKA: {
    magazine: 2,
    cooldown: 0.8,
    reload: 5.2,
    speed: 30,
    gravity: 3.0,
    drag: 0,
    blastRadius: 4.4,
  },
};

export interface CharacterConfig {
  botCount: number;
  walkSpeed: number;
  jogSpeed: number;
  runSpeed: number;
  strafeSpeed: number;
  jumpForce: number;
  acceleration: number;
  deceleration: number;
  rotationSpeed: number;
  throwPower: number;
  quickThrowMultiplier: number;
  normalThrowMultiplier: number;
  maxChargeMultiplier: number;
  chargeTime: number;
  throwGravity: number;
  throwDrag: number;
  aimSensitivity: number;
  cameraFollowSpeed: number;
  cameraRotationSpeed: number;
  bodyLeanAmount: number;
  footIKWeight: number;
  handIKWeight: number;
  audioEnabled: boolean;
  showTrajectoryAlways: boolean;
}

export const DEFAULT_CONFIG: CharacterConfig = {
  botCount: 9, // 5 vs 5 (player + 4 allies vs 5 enemies)
  walkSpeed: 2.475, // -10%
  jogSpeed: 4.0, // -10%
  runSpeed: 5.7, // -10%
  strafeSpeed: 3.06, // -10%
  jumpForce: 6.4,
  acceleration: 16.5,
  deceleration: 8.5,
  rotationSpeed: 9.8,
  throwPower: 31.5, // 1.5x faster throw
  quickThrowMultiplier: 0.78,
  normalThrowMultiplier: 1.0,
  maxChargeMultiplier: 1.28,
  chargeTime: 0.65,
  throwGravity: 13.5,
  throwDrag: 0.011,
  aimSensitivity: 0.0022,
  cameraFollowSpeed: 11.5,
  cameraRotationSpeed: 16.0,
  bodyLeanAmount: 1.1,
  footIKWeight: 1.0,
  handIKWeight: 1.0,
  audioEnabled: true,
  showTrajectoryAlways: false,
};

export interface LeaderboardEntry {
  id: string;
  name: string;
  kos: number;
  score: number;
  isPlayer: boolean;
  colorHex: string;
  team: TeamId;
}

export interface KillFeedItem {
  id: number;
  killer: string;
  victim: string;
  killerIsPlayer: boolean;
  victimIsPlayer: boolean;
  isMega: boolean;
}

export interface ArcadeCallout {
  id: number;
  text: string;
  subtext?: string;
  color: string;
}

export interface LockMarker {
  x: number;
  y: number;
  visible: boolean;
  name: string;
  distance: number;
  hp: number;
  maxHp: number;
}

export interface TestChecklist {
  test1_idleOrganic: boolean;
  test2_smoothWalk: boolean;
  test3_walkToRun: boolean;
  test4_decelAndStop: boolean;
  test5_smoothStrafe: boolean;
  test6_fullBodyPickup: boolean;
  test7_walkWithSnowballIK: boolean;
  test8_throwAnticipation: boolean;
  test9_handSocketRelease: boolean;
  test10_ballisticArc: boolean;
  test11_throwFollowThrough: boolean;
  test12_moveWhileThrowing: boolean;
  test13_cameraAimThrow: boolean;
  test14_smoothPostThrowStop: boolean;
}

export interface DebugTelemetry {
  velocity: { x: number; y: number; z: number };
  speed: number;
  blendSpeed: number;
  blendDirection: number;
  forwardComponent: number;
  locomotionState: LocomotionState;
  upperActionState: UpperActionState;
  throwPhase: ThrowPhase;
  directionMode: DirectionMode;
  baseGait: BaseGaitMode;
  hasSnowball: boolean;
  chargeRatio: number;
  throwPowerFactor: number;
  aimDirection: { x: number; y: number; z: number };
  aimPitchDeg: number;
  projectileVelocity: { x: number; y: number; z: number };
  projectileSpeed: number;
  activeProjectiles: number;
  lastHitInfo: string;
  pointerLocked: boolean;
  playerHp: number;
  playerMaxHp: number;
  playerScore: number;
  playerKos: number;
  playerStreak: number;
  activePowerUp: PowerUpType | null;
  powerUpRemaining: number;
  botAliveCount: number;
  totalBotCount: number;
  matchTimeRemaining: number;
  hitMarkerActive: boolean;
  leaderboard: LeaderboardEntry[];
  killFeed: KillFeedItem[];
  latestCallout: ArcadeCallout | null;
  // Team vs Team / FPS
  playerTeam: TeamId;
  blueScore: number;
  redScore: number;
  scoreLimit: number;
  alliesAlive: number;
  enemiesAlive: number;
  fpsActive: boolean;
  fpsWeapon: FpsWeaponId;
  fpsWeaponName: string;
  fpsFireMode: string;
  fpsAmmo: number;
  fpsMagSize: number;
  fpsReloading: boolean;
  fpsAmmoType: 'BULLET' | 'SNOWBALL';
  fpsAdsBlend: number;
  fpsSpread: number;
  fpsScoped: boolean;
  damagePulse: number;
  isRolling: boolean;
  rollEnergy: number;
  isCrouching: boolean;
  crosshairOnEnemy: boolean;
  tests: TestChecklist;
}

export const INITIAL_TESTS: TestChecklist = {
  test1_idleOrganic: false,
  test2_smoothWalk: false,
  test3_walkToRun: false,
  test4_decelAndStop: false,
  test5_smoothStrafe: false,
  test6_fullBodyPickup: false,
  test7_walkWithSnowballIK: false,
  test8_throwAnticipation: false,
  test9_handSocketRelease: false,
  test10_ballisticArc: false,
  test11_throwFollowThrough: false,
  test12_moveWhileThrowing: false,
  test13_cameraAimThrow: false,
  test14_smoothPostThrowStop: false,
};
