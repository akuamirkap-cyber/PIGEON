import * as THREE from 'three';
import { PowerUpType } from '../config/GameConfig';

export interface RangeTarget {
  id: string;
  label: string;
  position: THREE.Vector3;
  hitCenter: THREE.Vector3;
  hitRadius: number;
  pivotGroup: THREE.Group;
  wobbleAngle: number;
  wobbleVel: number;
  wobbleAxis: THREE.Vector3;
}

export interface ArenaBumper {
  position: THREE.Vector3;
  radius: number;
  height: number;
  bounceSpeed: number;
  meshGroup: THREE.Group;
  pulse: number;
}

export interface ArenaObstacle {
  position: THREE.Vector3;
  halfExtents: THREE.Vector3;
  yaw: number;
}

export interface PowerUpSpot {
  id: string;
  position: THREE.Vector3;
  type: PowerUpType;
  active: boolean;
  respawnTimer: number;
  orbGroup: THREE.Group;
  orbMat: THREE.MeshStandardMaterial;
}

interface FootprintItem {
  mesh: THREE.Mesh;
  age: number;
  maxAge: number;
}

interface SplatterDecalItem {
  mesh: THREE.Mesh;
  mat: THREE.MeshStandardMaterial;
  age: number;
  maxAge: number;
  isBodyAttached: boolean;
}

interface ClingingSnowballItem {
  mesh: THREE.Mesh;
  phase: 'CLINGING' | 'FALLING';
  clingTimer: number;
  worldVel: THREE.Vector3;
  slideSpeed: number;
  scaleBase: number;
}

interface SnowParticle {
  active: boolean;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  age: number;
  life: number;
  size: number;
  drag: number;
  bouncesLeft: number;
  color: THREE.Color;
}

interface ExplosionFxItem {
  ring: THREE.Mesh;
  ringMat: THREE.MeshBasicMaterial;
  flash: THREE.Mesh;
  flashMat: THREE.MeshBasicMaterial;
  age: number;
  duration: number;
  radius: number;
  active: boolean;
}

const POWERUP_COLORS: Record<PowerUpType, number> = {
  MEGA: 0xf97316,
  TURBO: 0xfacc15,
  TRIPLE: 0xa855f7,
  SHIELD: 0x38bdf8,
};

const ALL_POWERUP_TYPES: PowerUpType[] = ['MEGA', 'TURBO', 'TRIPLE', 'SHIELD'];

export class SnowTerrain {
  public static readonly ARENA_RADIUS = 36.0;

  public readonly group = new THREE.Group();
  private terrainMesh!: THREE.Mesh;
  private terrainGeo!: THREE.PlaneGeometry;
  private baseHeights!: Float32Array;
  private deformOffsets!: Float32Array;

  private readonly size = 120;
  private readonly segments = 120;

  private footprints: FootprintItem[] = [];
  private footprintPoolIndex = 0;
  private readonly maxFootprints = 220;
  private footprintGeo: THREE.PlaneGeometry;
  private footprintMatBase: THREE.MeshStandardMaterial;

  // Snow Splatter Decal Pool (for ground, walls, bumpers, and character bodies!)
  private splatterTexture: THREE.CanvasTexture;
  private splatterPlaneGeo: THREE.PlaneGeometry;
  private worldSplatters: SplatterDecalItem[] = [];
  private worldSplatterIndex = 0;
  private readonly maxWorldSplatters = 90;
  private bodySplatters: SplatterDecalItem[] = [];

  // Clinging Snowballs that stick for 2–3.5s then fall & crumble!
  private clingingBallGeo: THREE.IcosahedronGeometry;
  private clingingBallMat: THREE.MeshStandardMaterial;
  private clingingBalls: ClingingSnowballItem[] = [];

  // Multi-size Instanced Snow Particles (chunks, medium flakes, fine mist)
  private readonly maxParticles = 1400;
  private particles: SnowParticle[] = [];
  private particleMesh: THREE.InstancedMesh;
  private dummyObj = new THREE.Object3D();

  private ambientSnowPoints!: THREE.Points;
  private ambientPositions!: Float32Array;
  private readonly ambientCount = 380;

  public readonly targets: RangeTarget[] = [];
  public readonly bumpers: ArenaBumper[] = [];
  public readonly obstacles: ArenaObstacle[] = [];
  public readonly powerUps: PowerUpSpot[] = [];
  private explosionFx: ExplosionFxItem[] = [];

  constructor(scene: THREE.Scene) {
    this.footprintGeo = new THREE.PlaneGeometry(0.14, 0.24);
    this.footprintGeo.rotateX(-Math.PI / 2);

    this.footprintMatBase = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#93b0cf'),
      roughness: 0.95,
      metalness: 0.0,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });

    this.splatterTexture = this.createSnowSplatterTexture();
    // Plane faces +Z local so lookAt / quaternion from +Z aligns cleanly to surface normal!
    this.splatterPlaneGeo = new THREE.PlaneGeometry(1, 1);

    this.clingingBallGeo = new THREE.IcosahedronGeometry(0.088, 2);
    const cbPos = this.clingingBallGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < cbPos.count; i++) {
      const vx = cbPos.getX(i);
      const vy = cbPos.getY(i);
      const vz = cbPos.getZ(i);
      const lump = 1 + 0.12 * Math.sin(vx * 38) * Math.cos(vy * 33 + vz * 27);
      cbPos.setXYZ(i, vx * lump, vy * lump, vz * lump);
    }
    this.clingingBallGeo.computeVertexNormals();
    this.clingingBallMat = new THREE.MeshStandardMaterial({
      color: 0xf8fcff,
      roughness: 0.78,
      metalness: 0.02,
    });

    const pGeo = new THREE.DodecahedronGeometry(1, 0);
    const pMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.68,
      metalness: 0.03,
    });
    this.particleMesh = new THREE.InstancedMesh(pGeo, pMat, this.maxParticles);
    this.particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.particleMesh.frustumCulled = false;

    const white = new THREE.Color(0xf8fbff);
    for (let i = 0; i < this.maxParticles; i++) {
      this.particles.push({
        active: false,
        pos: new THREE.Vector3(0, -100, 0),
        vel: new THREE.Vector3(),
        age: 0,
        life: 1,
        size: 0.03,
        drag: 1.5,
        bouncesLeft: 0,
        color: white.clone(),
      });
      this.dummyObj.position.set(0, -100, 0);
      this.dummyObj.scale.setScalar(0.001);
      this.dummyObj.updateMatrix();
      this.particleMesh.setMatrixAt(i, this.dummyObj.matrix);
      this.particleMesh.setColorAt(i, white);
    }

    this.buildTerrain();
    this.buildFootprintPool();
    this.buildWorldSplatterPool();
    this.buildStumbleArenaFeatures();
    this.buildRangeTargets();
    this.buildPerimeterFestivalProps();
    this.buildAmbientSnowfall();
    this.buildTeamBases();
    this.buildExplosionFxPool();

    this.group.add(this.particleMesh);
    scene.add(this.group);
  }

  /**
   * Procedurally paints an organic flattened snow splatter texture with irregular lobes & satellite specks.
   */
  private createSnowSplatterTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, 128, 128);
      const cx = 64;
      const cy = 64;

      // Soft outer frosty halo
      const grad = ctx.createRadialGradient(cx, cy, 8, cx, cy, 52);
      grad.addColorStop(0, 'rgba(255, 255, 255, 0.98)');
      grad.addColorStop(0.55, 'rgba(241, 248, 255, 0.92)');
      grad.addColorStop(0.82, 'rgba(219, 236, 252, 0.45)');
      grad.addColorStop(1, 'rgba(219, 236, 252, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, 52, 0, Math.PI * 2);
      ctx.fill();

      // Irregular multi-lobed snow pancake core
      ctx.fillStyle = 'rgba(255, 255, 255, 0.96)';
      ctx.beginPath();
      const lobes = 14;
      for (let i = 0; i <= lobes; i++) {
        const a = (i / lobes) * Math.PI * 2;
        const r = 27 + Math.sin(i * 2.7) * 9 + Math.cos(i * 4.3) * 5;
        const px = cx + Math.cos(a) * r;
        const py = cy + Math.sin(a) * r;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();

      // Satellite snow droplets around rim
      for (let i = 0; i < 18; i++) {
        const a = (i / 18) * Math.PI * 2 + (i % 3) * 0.19;
        const dist = 34 + (i % 4) * 6.5;
        const rad = 2.2 + (i % 3) * 1.8;
        ctx.fillStyle = 'rgba(248, 252, 255, 0.88)';
        ctx.beginPath();
        ctx.arc(cx + Math.cos(a) * dist, cy + Math.sin(a) * dist, rad, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.needsUpdate = true;
    return tex;
  }

  private buildWorldSplatterPool(): void {
    for (let i = 0; i < this.maxWorldSplatters; i++) {
      const mat = new THREE.MeshStandardMaterial({
        map: this.splatterTexture,
        color: 0xffffff,
        roughness: 0.85,
        metalness: 0.0,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -3,
      });
      const mesh = new THREE.Mesh(this.splatterPlaneGeo, mat);
      mesh.visible = false;
      this.group.add(mesh);
      this.worldSplatters.push({
        mesh,
        mat,
        age: 0,
        maxAge: 8.0,
        isBodyAttached: false,
      });
    }
  }

  public getBaseHeightAt(x: number, z: number): number {
    const h =
      Math.sin(x * 0.075) * Math.cos(z * 0.075) * 0.28 +
      Math.sin(x * 0.16 + z * 0.12) * 0.11;

    const dist = Math.hypot(x, z);
    const centerHill =
      Math.exp(-(dist * dist) / 42.0) * 0.52 * THREE.MathUtils.smoothstep(dist, 1.2, 4.2);

    const mound1 = Math.exp(-((x - 10.5) ** 2 + (z - 9.5) ** 2) / 18.0) * 0.65;
    const mound2 = Math.exp(-((x + 11.0) ** 2 + (z - 8.5) ** 2) / 18.0) * 0.65;
    const mound3 = Math.exp(-((x - 9.5) ** 2 + (z + 11.5) ** 2) / 18.0) * 0.62;
    const mound4 = Math.exp(-((x + 10.5) ** 2 + (z + 10.5) ** 2) / 18.0) * 0.62;

    return h + centerHill + mound1 + mound2 + mound3 + mound4;
  }

  public getHeightAt(x: number, z: number): number {
    const base = this.getBaseHeightAt(x, z);
    const half = this.size * 0.5;
    const gx = ((x + half) / this.size) * this.segments;
    const gz = ((z + half) / this.size) * this.segments;
    const ix = Math.round(gx);
    const iz = Math.round(gz);
    if (ix >= 0 && ix <= this.segments && iz >= 0 && iz <= this.segments && this.deformOffsets) {
      const idx = iz * (this.segments + 1) + ix;
      return base + this.deformOffsets[idx];
    }
    return base;
  }

  public getNormalAt(x: number, z: number, target = new THREE.Vector3()): THREE.Vector3 {
    const eps = 0.22;
    const hL = this.getHeightAt(x - eps, z);
    const hR = this.getHeightAt(x + eps, z);
    const hD = this.getHeightAt(x, z - eps);
    const hU = this.getHeightAt(x, z + eps);
    target.set(hL - hR, 2 * eps, hD - hU).normalize();
    return target;
  }

  private buildTerrain(): void {
    this.terrainGeo = new THREE.PlaneGeometry(this.size, this.size, this.segments, this.segments);
    this.terrainGeo.rotateX(-Math.PI / 2);

    const posAttr = this.terrainGeo.attributes.position as THREE.BufferAttribute;
    const count = posAttr.count;
    this.baseHeights = new Float32Array(count);
    this.deformOffsets = new Float32Array(count);

    const colors = new Float32Array(count * 3);
    const cPeak = new THREE.Color('#ffffff');
    const cHollow = new THREE.Color('#d4e8fb');
    const cCenterRing = new THREE.Color('#e0f2fe');
    const tempCol = new THREE.Color();

    for (let i = 0; i < count; i++) {
      const x = posAttr.getX(i);
      const z = posAttr.getZ(i);
      const y = this.getBaseHeightAt(x, z);
      this.baseHeights[i] = y;
      posAttr.setY(i, y);

      const t = THREE.MathUtils.clamp((y + 0.3) / 1.1, 0, 1);
      tempCol.copy(cHollow).lerp(cPeak, t);

      const r = Math.hypot(x, z);
      if (Math.abs(r - SnowTerrain.ARENA_RADIUS) < 0.85) {
        tempCol.lerp(new THREE.Color('#38bdf8'), 0.45);
      } else if (r < 6.0) {
        tempCol.lerp(cCenterRing, 0.25);
      }

      colors[i * 3] = tempCol.r;
      colors[i * 3 + 1] = tempCol.g;
      colors[i * 3 + 2] = tempCol.b;
    }

    this.terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    this.terrainGeo.computeVertexNormals();

    const snowMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.82,
      metalness: 0.02,
    });

    this.terrainMesh = new THREE.Mesh(this.terrainGeo, snowMat);
    this.terrainMesh.receiveShadow = true;
    this.group.add(this.terrainMesh);
  }

  private buildFootprintPool(): void {
    for (let i = 0; i < this.maxFootprints; i++) {
      const mat = this.footprintMatBase.clone();
      const mesh = new THREE.Mesh(this.footprintGeo, mat);
      mesh.visible = false;
      mesh.receiveShadow = true;
      this.group.add(mesh);
      this.footprints.push({ mesh, age: 0, maxAge: 18 });
    }
  }

  private buildStumbleArenaFeatures(): void {
    const bumperColors = [0xf43f5e, 0xfacc15, 0x06b6d4, 0xa855f7];
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
    const darkBaseMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });

    const bumperCoords: [number, number, number][] = [
      [0, 8.5, 0],
      [8.5, 0, 1],
      [0, -8.5, 2],
      [-8.5, 0, 3],
      [15.5, 15.5, 0],
      [-15.5, 15.5, 1],
      [15.5, -15.5, 2],
      [-15.5, -15.5, 3],
    ];

    bumperCoords.forEach(([bx, bz, cIdx]) => {
      const gy = this.getBaseHeightAt(bx, bz);
      const bGroup = new THREE.Group();
      bGroup.position.set(bx, gy, bz);

      const padMat = new THREE.MeshStandardMaterial({
        color: bumperColors[cIdx % bumperColors.length],
        roughness: 0.32,
        metalness: 0.08,
      });

      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.05, 0.22, 20), darkBaseMat);
      base.position.y = 0.11;
      base.receiveShadow = true;

      const core = new THREE.Mesh(new THREE.CylinderGeometry(0.88, 0.88, 1.05, 20), padMat);
      core.position.y = 0.68;
      core.castShadow = true;
      core.receiveShadow = true;

      const midStripe = new THREE.Mesh(new THREE.TorusGeometry(0.89, 0.11, 10, 24), whiteMat);
      midStripe.rotation.x = Math.PI / 2;
      midStripe.position.y = 0.72;
      midStripe.castShadow = true;

      const topCap = new THREE.Mesh(
        new THREE.SphereGeometry(0.88, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.5),
        padMat
      );
      topCap.scale.set(1, 0.35, 1);
      topCap.position.y = 1.2;
      topCap.castShadow = true;

      bGroup.add(base, core, midStripe, topCap);
      this.group.add(bGroup);

      this.bumpers.push({
        position: new THREE.Vector3(bx, gy, bz),
        radius: 0.96,
        height: 1.45,
        bounceSpeed: 11.5,
        meshGroup: bGroup,
        pulse: 0,
      });
    });

    const iceBrickMat = new THREE.MeshStandardMaterial({
      color: 0x93c5fd,
      roughness: 0.4,
      metalness: 0.05,
    });
    const snowTopMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.85,
    });

    const wallSpecs = [
      { x: 0, z: 18.5, w: 3.4, h: 0.92, d: 0.85, yaw: 0 },
      { x: 0, z: -18.5, w: 3.4, h: 0.92, d: 0.85, yaw: 0 },
      { x: 18.5, z: 0, w: 3.4, h: 0.92, d: 0.85, yaw: Math.PI / 2 },
      { x: -18.5, z: 0, w: 3.4, h: 0.92, d: 0.85, yaw: Math.PI / 2 },
      { x: 9.5, z: -11.5, w: 2.6, h: 0.86, d: 0.8, yaw: 0.72 },
      { x: -9.5, z: 11.5, w: 2.6, h: 0.86, d: 0.8, yaw: 0.72 },
    ];

    wallSpecs.forEach((ws) => {
      const gy = this.getBaseHeightAt(ws.x, ws.z);
      const wg = new THREE.Group();
      wg.position.set(ws.x, gy, ws.z);
      wg.rotation.y = ws.yaw;

      const block = new THREE.Mesh(new THREE.BoxGeometry(ws.w, ws.h, ws.d), iceBrickMat);
      block.position.y = ws.h * 0.5 - 0.05;
      block.castShadow = true;
      block.receiveShadow = true;

      const cap = new THREE.Mesh(
        new THREE.BoxGeometry(ws.w + 0.12, 0.18, ws.d + 0.12),
        snowTopMat
      );
      cap.position.y = ws.h - 0.02;
      cap.castShadow = true;
      cap.receiveShadow = true;

      wg.add(block, cap);
      this.group.add(wg);

      this.obstacles.push({
        position: new THREE.Vector3(ws.x, gy, ws.z),
        halfExtents: new THREE.Vector3(ws.w * 0.5, ws.h, ws.d * 0.5),
        yaw: ws.yaw,
      });
    });

    const powerCoords: [number, number, PowerUpType][] = [
      [0, 0, 'MEGA'],
      [13.5, 0, 'TRIPLE'],
      [-13.5, 0, 'TURBO'],
      [0, 14.0, 'SHIELD'],
      [0, -14.0, 'MEGA'],
      [21.0, -9.0, 'TURBO'],
      [-21.0, 9.0, 'TRIPLE'],
    ];

    const ringBaseMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.4,
    });

    powerCoords.forEach(([px, pz, initType], idx) => {
      const gy = this.getBaseHeightAt(px, pz);
      const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.88, 0.12, 18), ringBaseMat);
      pad.position.set(px, gy + 0.05, pz);
      pad.receiveShadow = true;
      this.group.add(pad);

      const orbGroup = new THREE.Group();
      orbGroup.position.set(px, gy + 0.72, pz);

      const orbMat = new THREE.MeshStandardMaterial({
        color: POWERUP_COLORS[initType],
        emissive: POWERUP_COLORS[initType],
        emissiveIntensity: 0.45,
        roughness: 0.2,
        metalness: 0.3,
      });

      const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.32, 0), orbMat);
      gem.castShadow = true;
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(0.44, 0.04, 8, 24),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      halo.rotation.x = Math.PI / 3;
      orbGroup.add(gem, halo);
      this.group.add(orbGroup);

      this.powerUps.push({
        id: `pu_${idx}`,
        position: new THREE.Vector3(px, gy, pz),
        type: initType,
        active: true,
        respawnTimer: 0,
        orbGroup,
        orbMat,
      });
    });
  }

  private buildRangeTargets(): void {
    const snowBodyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.8 });
    const scarfMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.5 });

    const angles = [0.35, 1.9, 3.5, 5.0];
    angles.forEach((ang, idx) => {
      const r = 32.5;
      const x = Math.cos(ang) * r;
      const z = Math.sin(ang) * r;
      const gy = this.getBaseHeightAt(x, z);

      const pivotGroup = new THREE.Group();
      pivotGroup.position.set(x, gy, z);

      const b1 = new THREE.Mesh(new THREE.SphereGeometry(0.42, 14, 12), snowBodyMat);
      b1.position.y = 0.36;
      b1.castShadow = true;
      const b2 = new THREE.Mesh(new THREE.SphereGeometry(0.3, 14, 12), snowBodyMat);
      b2.position.y = 0.92;
      b2.castShadow = true;
      const b3 = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10), snowBodyMat);
      b3.position.y = 1.35;
      b3.castShadow = true;
      const scarf = new THREE.Mesh(new THREE.CylinderGeometry(0.23, 0.25, 0.1, 12), scarfMat);
      scarf.position.y = 1.16;

      pivotGroup.add(b1, b2, b3, scarf);
      this.group.add(pivotGroup);

      this.targets.push({
        id: `snowman_${idx}`,
        label: `Snowman #${idx + 1}`,
        position: new THREE.Vector3(x, gy, z),
        hitCenter: new THREE.Vector3(x, gy + 0.95, z),
        hitRadius: 0.52,
        pivotGroup,
        wobbleAngle: 0,
        wobbleVel: 0,
        wobbleAxis: new THREE.Vector3(1, 0, 0),
      });
    });
  }

  private buildPerimeterFestivalProps(): void {
    const postRedMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.45 });
    const postWhiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
    const ropeMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.4 });

    const postCount = 24;
    const r = SnowTerrain.ARENA_RADIUS + 0.6;
    for (let i = 0; i < postCount; i++) {
      const a = (i / postCount) * Math.PI * 2;
      const nextA = ((i + 1) / postCount) * Math.PI * 2;
      const px = Math.cos(a) * r;
      const pz = Math.sin(a) * r;
      const gy = this.getBaseHeightAt(px, pz);

      const postGroup = new THREE.Group();
      postGroup.position.set(px, gy, pz);

      const seg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 0.55, 10), postWhiteMat);
      seg1.position.y = 0.27;
      seg1.castShadow = true;
      const seg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.55, 10), postRedMat);
      seg2.position.y = 0.82;
      seg2.castShadow = true;
      const knob = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 10), postWhiteMat);
      knob.position.y = 1.15;

      postGroup.add(seg1, seg2, knob);
      this.group.add(postGroup);

      const nx = Math.cos(nextA) * r;
      const nz = Math.sin(nextA) * r;
      const ngy = this.getBaseHeightAt(nx, nz);
      const p1 = new THREE.Vector3(px, gy + 0.9, pz);
      const p2 = new THREE.Vector3(nx, ngy + 0.9, nz);
      const mid = p1.clone().add(p2).multiplyScalar(0.5);
      const len = p1.distanceTo(p2);
      const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, len, 6), ropeMat);
      bar.position.copy(mid);
      bar.quaternion.setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        p2.clone().sub(p1).normalize()
      );
      this.group.add(bar);
    }

    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3525, roughness: 0.9 });
    const pineMat = new THREE.MeshStandardMaterial({ color: 0x1e4d40, roughness: 0.8 });
    const snowCapMat = new THREE.MeshStandardMaterial({ color: 0xf8fbff, roughness: 0.9 });

    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * Math.PI * 2 + 0.13;
      const tr = 43 + (i % 3) * 5.5;
      const tx = Math.cos(a) * tr;
      const tz = Math.sin(a) * tr;
      const scale = 0.9 + (i % 4) * 0.25;
      const gy = this.getBaseHeightAt(tx, tz);

      const tree = new THREE.Group();
      tree.position.set(tx, gy, tz);

      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.16 * scale, 0.24 * scale, 1.4 * scale, 7),
        trunkMat
      );
      trunk.position.y = 0.7 * scale;

      const f1 = new THREE.Mesh(new THREE.ConeGeometry(1.4 * scale, 2.6 * scale, 7), pineMat);
      f1.position.y = 2.1 * scale;
      f1.castShadow = true;

      const f2 = new THREE.Mesh(new THREE.ConeGeometry(1.05 * scale, 2.1 * scale, 7), pineMat);
      f2.position.y = 3.3 * scale;

      const cap = new THREE.Mesh(new THREE.ConeGeometry(0.7 * scale, 1.1 * scale, 7), snowCapMat);
      cap.position.y = 3.95 * scale;

      tree.add(trunk, f1, f2, cap);
      this.group.add(tree);
    }
  }

  private buildAmbientSnowfall(): void {
    const geo = new THREE.BufferGeometry();
    this.ambientPositions = new Float32Array(this.ambientCount * 3);
    for (let i = 0; i < this.ambientCount; i++) {
      this.ambientPositions[i * 3] = (Math.random() - 0.5) * 56;
      this.ambientPositions[i * 3 + 1] = Math.random() * 14 + 0.5;
      this.ambientPositions[i * 3 + 2] = (Math.random() - 0.5) * 56;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(this.ambientPositions, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.075,
      transparent: true,
      opacity: 0.6,
    });
    this.ambientSnowPoints = new THREE.Points(geo, mat);
    this.group.add(this.ambientSnowPoints);
  }

  /**
   * Raycasts against Snow Fort Obstacles (exact oriented box) for aiming & wall splatter decals.
   */
  public raycastObstacleWalls(
    origin: THREE.Vector3,
    dir: THREE.Vector3,
    maxDist: number
  ): { distance: number; point: THREE.Vector3; normal: THREE.Vector3 } | null {
    let bestT = maxDist;
    let hitNormal: THREE.Vector3 | null = null;

    for (const obs of this.obstacles) {
      const cosY = Math.cos(-obs.yaw);
      const sinY = Math.sin(-obs.yaw);

      // Transform ray into obstacle's local frame (box spans [-hx..hx], [0..hy], [-hz..hz])
      const relX = origin.x - obs.position.x;
      const relY = origin.y - obs.position.y;
      const relZ = origin.z - obs.position.z;

      const ox = relX * cosY - relZ * sinY;
      const oy = relY;
      const oz = relX * sinY + relZ * cosY;

      const dx = dir.x * cosY - dir.z * sinY;
      const dy = dir.y;
      const dz = dir.x * sinY + dir.z * cosY;

      const hx = obs.halfExtents.x;
      const hy = obs.halfExtents.y;
      const hz = obs.halfExtents.z;

      let tMin = 0.001;
      let tMax = bestT;
      let localNx = 0;
      let localNy = 0;
      let localNz = 0;

      // X slab
      if (Math.abs(dx) < 1e-6) {
        if (ox < -hx || ox > hx) continue;
      } else {
        const inv = 1 / dx;
        let t1 = (-hx - ox) * inv;
        let t2 = (hx - ox) * inv;
        let nSign = -1;
        if (t1 > t2) {
          const tmp = t1;
          t1 = t2;
          t2 = tmp;
          nSign = 1;
        }
        if (t1 > tMin) {
          tMin = t1;
          localNx = nSign;
          localNy = 0;
          localNz = 0;
        }
        if (t2 < tMax) tMax = t2;
        if (tMin > tMax) continue;
      }

      // Y slab [0 .. hy]
      if (Math.abs(dy) < 1e-6) {
        if (oy < 0 || oy > hy) continue;
      } else {
        const inv = 1 / dy;
        let t1 = (0 - oy) * inv;
        let t2 = (hy - oy) * inv;
        let nSign = -1;
        if (t1 > t2) {
          const tmp = t1;
          t1 = t2;
          t2 = tmp;
          nSign = 1;
        }
        if (t1 > tMin) {
          tMin = t1;
          localNx = 0;
          localNy = nSign;
          localNz = 0;
        }
        if (t2 < tMax) tMax = t2;
        if (tMin > tMax) continue;
      }

      // Z slab
      if (Math.abs(dz) < 1e-6) {
        if (oz < -hz || oz > hz) continue;
      } else {
        const inv = 1 / dz;
        let t1 = (-hz - oz) * inv;
        let t2 = (hz - oz) * inv;
        let nSign = -1;
        if (t1 > t2) {
          const tmp = t1;
          t1 = t2;
          t2 = tmp;
          nSign = 1;
        }
        if (t1 > tMin) {
          tMin = t1;
          localNx = 0;
          localNy = 0;
          localNz = nSign;
        }
        if (t2 < tMax) tMax = t2;
        if (tMin > tMax) continue;
      }

      if (tMin > 0.001 && tMin < bestT) {
        bestT = tMin;
        const cosInv = Math.cos(obs.yaw);
        const sinInv = Math.sin(obs.yaw);
        hitNormal = new THREE.Vector3(
          localNx * cosInv - localNz * sinInv,
          localNy,
          localNx * sinInv + localNz * cosInv
        ).normalize();
      }
    }

    if (!hitNormal) return null;
    return {
      distance: bestT,
      point: origin.clone().addScaledVector(dir, bestT),
      normal: hitNormal,
    };
  }

  public resolveArenaCollisions(
    pos: THREE.Vector3,
    charRadius = 0.34
  ): THREE.Vector3 | null {
    let bounceImpulse: THREE.Vector3 | null = null;

    for (const b of this.bumpers) {
      if (pos.y > b.position.y + b.height + 0.2) continue;
      const dx = pos.x - b.position.x;
      const dz = pos.z - b.position.z;
      const dist = Math.hypot(dx, dz);
      const minDist = b.radius + charRadius;
      if (dist < minDist && dist > 0.0001) {
        const nx = dx / dist;
        const nz = dz / dist;
        pos.x = b.position.x + nx * (minDist + 0.04);
        pos.z = b.position.z + nz * (minDist + 0.04);
        b.pulse = 1.0;
        bounceImpulse = new THREE.Vector3(nx * b.bounceSpeed, 3.2, nz * b.bounceSpeed);
      }
    }

    for (const obs of this.obstacles) {
      const wallTopY = obs.position.y + obs.halfExtents.y - 0.12;
      if (pos.y > wallTopY) continue;

      const cosY = Math.cos(-obs.yaw);
      const sinY = Math.sin(-obs.yaw);
      const relX = pos.x - obs.position.x;
      const relZ = pos.z - obs.position.z;
      const lx = relX * cosY - relZ * sinY;
      const lz = relX * sinY + relZ * cosY;

      const ex = obs.halfExtents.x + charRadius;
      const ez = obs.halfExtents.z + charRadius;

      if (Math.abs(lx) < ex && Math.abs(lz) < ez) {
        const penX = ex - Math.abs(lx);
        const penZ = ez - Math.abs(lz);
        let pushLX = lx;
        let pushLZ = lz;
        if (penX < penZ) {
          pushLX = lx >= 0 ? ex : -ex;
        } else {
          pushLZ = lz >= 0 ? ez : -ez;
        }
        const cosInv = Math.cos(obs.yaw);
        const sinInv = Math.sin(obs.yaw);
        pos.x = obs.position.x + pushLX * cosInv - pushLZ * sinInv;
        pos.z = obs.position.z + pushLX * sinInv + pushLZ * cosInv;
      }
    }

    const distCenter = Math.hypot(pos.x, pos.z);
    if (distCenter > SnowTerrain.ARENA_RADIUS) {
      const scale = SnowTerrain.ARENA_RADIUS / distCenter;
      pos.x *= scale;
      pos.z *= scale;
    }

    return bounceImpulse;
  }

  public tryPickupPowerUp(pos: THREE.Vector3, collectRadius = 0.95): PowerUpType | null {
    for (const pu of this.powerUps) {
      if (!pu.active) continue;
      const d = Math.hypot(pos.x - pu.position.x, pos.z - pu.position.z);
      if (d <= collectRadius && Math.abs(pos.y - pu.position.y) < 1.5) {
        const picked = pu.type;
        pu.active = false;
        pu.respawnTimer = 9.5;
        pu.orbGroup.visible = false;
        this.emitSnowballShatter(pu.orbGroup.position, new THREE.Vector3(0, 1, 0), new THREE.Vector3(), 0.9, false);
        return picked;
      }
    }
    return null;
  }

  public deformSnowAt(x: number, z: number, depth = 0.032, radius = 0.65): void {
    const half = this.size * 0.5;
    const gx = ((x + half) / this.size) * this.segments;
    const gz = ((z + half) / this.size) * this.segments;
    const cellRadius = Math.ceil((radius / this.size) * this.segments);
    const ixCenter = Math.round(gx);
    const izCenter = Math.round(gz);

    const posAttr = this.terrainGeo.attributes.position as THREE.BufferAttribute;
    let modified = false;

    for (let iz = izCenter - cellRadius; iz <= izCenter + cellRadius; iz++) {
      if (iz < 0 || iz > this.segments) continue;
      for (let ix = ixCenter - cellRadius; ix <= ixCenter + cellRadius; ix++) {
        if (ix < 0 || ix > this.segments) continue;
        const idx = iz * (this.segments + 1) + ix;
        const vx = posAttr.getX(idx);
        const vz = posAttr.getZ(idx);
        const dist = Math.hypot(vx - x, vz - z);
        if (dist <= radius) {
          const falloff = 1 - dist / radius;
          const targetDip = -depth * falloff * falloff;
          if (targetDip < this.deformOffsets[idx]) {
            this.deformOffsets[idx] = Math.max(-0.085, targetDip);
            posAttr.setY(idx, this.baseHeights[idx] + this.deformOffsets[idx]);
            modified = true;
          }
        }
      }
    }

    if (modified) {
      posAttr.needsUpdate = true;
    }
  }

  public addFootprint(worldPos: THREE.Vector3, yaw: number, scaleWidth = 1.0, scaleLength = 1.0): void {
    const item = this.footprints[this.footprintPoolIndex];
    this.footprintPoolIndex = (this.footprintPoolIndex + 1) % this.maxFootprints;

    const gy = this.getHeightAt(worldPos.x, worldPos.z);
    const normal = this.getNormalAt(worldPos.x, worldPos.z);

    item.mesh.position.set(worldPos.x, gy + 0.012, worldPos.z);
    const up = new THREE.Vector3(0, 1, 0);
    const slopeQuat = new THREE.Quaternion().setFromUnitVectors(up, normal);
    const yawQuat = new THREE.Quaternion().setFromAxisAngle(up, yaw);
    item.mesh.quaternion.copy(slopeQuat).multiply(yawQuat);

    item.mesh.scale.set(scaleWidth, 1, scaleLength);
    item.age = 0;
    item.maxAge = 18;
    item.mesh.visible = true;
    (item.mesh.material as THREE.MeshStandardMaterial).opacity = 0.62;
  }

  /**
   * Places a flattened Snow Splatter Decal onto any world surface (ground, wall, bumper).
   */
  public addSurfaceSnowSplatter(
    worldPos: THREE.Vector3,
    worldNormal: THREE.Vector3,
    diameter = 0.45
  ): void {
    const item = this.worldSplatters[this.worldSplatterIndex];
    this.worldSplatterIndex = (this.worldSplatterIndex + 1) % this.maxWorldSplatters;

    const n = worldNormal.clone().normalize();
    item.mesh.position.copy(worldPos).addScaledVector(n, 0.016);

    const zAxis = new THREE.Vector3(0, 0, 1);
    const alignQ = new THREE.Quaternion().setFromUnitVectors(zAxis, n);
    const spinQ = new THREE.Quaternion().setFromAxisAngle(n, Math.random() * Math.PI * 2);
    item.mesh.quaternion.copy(spinQ).multiply(alignQ);

    const stretchX = diameter * (0.88 + Math.random() * 0.28);
    const stretchY = diameter * (0.88 + Math.random() * 0.28);
    item.mesh.scale.set(stretchX, stretchY, 1);
    item.mat.opacity = 0.94;
    item.age = 0;
    item.maxAge = 7.5 + Math.random() * 2.5;
    item.mesh.visible = true;
  }

  /**
   * Attaches a flattened Snow Decal directly onto a hit character's skeletal bone (chest/head/pelvis)
   * so the white snow mark stays stuck on their clothing/face while flinching or ragdolling!
   */
  public addBodySnowDecal(
    parentJoint: THREE.Object3D,
    worldHitPos: THREE.Vector3,
    worldOutwardNormal: THREE.Vector3,
    diameter = 0.26
  ): void {
    parentJoint.updateWorldMatrix(true, false);

    const mat = new THREE.MeshStandardMaterial({
      map: this.splatterTexture,
      color: 0xffffff,
      roughness: 0.82,
      transparent: true,
      opacity: 0.96,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -4,
    });

    const mesh = new THREE.Mesh(this.splatterPlaneGeo, mat);
    const nWorld = worldOutwardNormal.clone().normalize();
    const surfaceWorld = worldHitPos.clone().addScaledVector(nWorld, 0.018);

    const localPos = parentJoint.worldToLocal(surfaceWorld.clone());
    mesh.position.copy(localPos);

    const zAxis = new THREE.Vector3(0, 0, 1);
    const qWorld = new THREE.Quaternion().setFromUnitVectors(zAxis, nWorld);
    const qSpin = new THREE.Quaternion().setFromAxisAngle(nWorld, Math.random() * Math.PI * 2);
    qWorld.premultiply(qSpin);

    const qParentWorld = new THREE.Quaternion();
    parentJoint.getWorldQuaternion(qParentWorld);
    mesh.quaternion.copy(qParentWorld.invert()).multiply(qWorld);

    mesh.scale.set(diameter, diameter * (0.85 + Math.random() * 0.25), 1);
    parentJoint.add(mesh);

    this.bodySplatters.push({
      mesh,
      mat,
      age: 0,
      maxAge: 6.5,
      isBodyAttached: true,
    });
  }

  /**
   * Attaches a squashed 3D Snowball lump that CLINGS to the enemy's body (or wall)
   * for 2.0–3.5 seconds, slowly creeping downward before detaching, falling, and crumbling on snow!
   */
  public attachClingingSnowball(
    parentObj: THREE.Object3D | null,
    worldHitPos: THREE.Vector3,
    worldOutwardNormal: THREE.Vector3,
    isMega = false
  ): void {
    const mesh = new THREE.Mesh(this.clingingBallGeo, this.clingingBallMat);
    mesh.castShadow = true;

    const scaleBase = isMega ? 1.65 : 0.96;
    const nWorld = worldOutwardNormal.clone().normalize();
    const attachWorld = worldHitPos.clone().addScaledVector(nWorld, 0.028 * scaleBase);

    const yAxis = new THREE.Vector3(0, 1, 0);
    const qWorld = new THREE.Quaternion().setFromUnitVectors(yAxis, nWorld);

    if (parentObj) {
      parentObj.updateWorldMatrix(true, false);
      mesh.position.copy(parentObj.worldToLocal(attachWorld.clone()));
      const qParent = new THREE.Quaternion();
      parentObj.getWorldQuaternion(qParent);
      mesh.quaternion.copy(qParent.invert()).multiply(qWorld);
      parentObj.add(mesh);
    } else {
      mesh.position.copy(attachWorld);
      mesh.quaternion.copy(qWorld);
      this.group.add(mesh);
    }

    // Squashed pancake-sphere shape against surface!
    mesh.scale.set(scaleBase * 1.18, scaleBase * 0.66, scaleBase * 1.18);

    this.clingingBalls.push({
      mesh,
      phase: 'CLINGING',
      clingTimer: 2.1 + Math.random() * 1.4, // Clings 2.1s – 3.5s before dropping!
      worldVel: new THREE.Vector3(),
      slideSpeed: 0.025 + Math.random() * 0.02,
      scaleBase,
    });
  }

  /**
   * Splatters snow onto any wall or snow ground right behind a hit target along the throw vector!
   */
  public emitThroughSplatterBehindTarget(
    hitPos: THREE.Vector3,
    impactVel: THREE.Vector3,
    isMega = false
  ): void {
    const dir = impactVel.clone().normalize();
    const wallHit = this.raycastObstacleWalls(hitPos, dir, 3.6);
    if (wallHit) {
      this.addSurfaceSnowSplatter(wallHit.point, wallHit.normal, isMega ? 0.85 : 0.48);
    }

    // Also splatter snow spray patch on the snow ground 0.7m–1.6m behind the hit enemy!
    const behindX = hitPos.x + dir.x * (0.85 + Math.random() * 0.65);
    const behindZ = hitPos.z + dir.z * (0.85 + Math.random() * 0.65);
    const gy = this.getHeightAt(behindX, behindZ);
    const gn = this.getNormalAt(behindX, behindZ);
    this.addSurfaceSnowSplatter(
      new THREE.Vector3(behindX, gy, behindZ),
      gn,
      isMega ? 0.9 : 0.46
    );
  }

  public addSnowImpactMark(worldPos: THREE.Vector3, isMega = false): void {
    const normal = this.getNormalAt(worldPos.x, worldPos.z);
    this.addSurfaceSnowSplatter(worldPos, normal, isMega ? 0.95 : 0.48);
    this.deformSnowAt(worldPos.x, worldPos.z, isMega ? 0.075 : 0.042, isMega ? 1.6 : 0.8);
  }

  private spawnParticle(
    pos: THREE.Vector3,
    vel: THREE.Vector3,
    size: number,
    life: number,
    colorHex = 0xf8fbff,
    drag = 1.6,
    bouncesLeft = 0
  ): void {
    for (let i = 0; i < this.maxParticles; i++) {
      const p = this.particles[i];
      if (!p.active) {
        p.active = true;
        p.pos.copy(pos);
        p.vel.copy(vel);
        p.age = 0;
        p.life = life;
        p.size = size;
        p.drag = drag;
        p.bouncesLeft = bouncesLeft;
        p.color.setHex(colorHex);
        this.particleMesh.setColorAt(i, p.color);
        if (this.particleMesh.instanceColor) {
          this.particleMesh.instanceColor.needsUpdate = true;
        }
        return;
      }
    }
  }

  /**
   * Multi-Size Snow Burst Particles:
   * 1) Large 3D Snow Chunks (arc & bounce on snow ground)
   * 2) Medium Snow Flakes (360° radial scatter)
   * 3) Fine Snow Mist / Powder (airy puff cloud at impact point)
   */
  public emitSnowballShatter(
    pos: THREE.Vector3,
    normal: THREE.Vector3,
    impactVel: THREE.Vector3,
    power = 1.0,
    isMega = false,
    didCling = false
  ): void {
    const mult = isMega ? 1.65 : 1.0;
    const countMult = didCling ? 0.55 : 1.0;

    const fwdSplash = impactVel.lengthSq() > 0.1
      ? impactVel.clone().normalize().multiplyScalar(1.4)
      : new THREE.Vector3();

    // Tier 1: Heavy Bouncing Snow Chunks (varied big sizes 0.048m – 0.082m)
    const chunkCount = Math.max(3, Math.round((isMega ? 14 : 8) * countMult));
    for (let i = 0; i < chunkCount; i++) {
      const rand = new THREE.Vector3(
        Math.random() * 2 - 1,
        Math.random() * 1.4 + 0.15,
        Math.random() * 2 - 1
      ).normalize();
      const vel = normal
        .clone()
        .multiplyScalar((1.6 + Math.random() * 1.8) * power)
        .addScaledVector(rand, (2.2 + Math.random() * 3.0) * mult)
        .addScaledVector(fwdSplash, 0.35);
      this.spawnParticle(
        pos,
        vel,
        (0.048 + Math.random() * 0.034) * (isMega ? 1.3 : 1.0),
        0.75 + Math.random() * 0.45,
        0xffffff,
        0.55,
        1 // Bounces on snow!
      );
    }

    // Tier 2: Medium Omnidirectional Snow Flakes (0.024m – 0.042m)
    const midCount = Math.round((isMega ? 26 : 16) * countMult);
    for (let i = 0; i < midCount; i++) {
      const rand = new THREE.Vector3(
        Math.random() * 2 - 1,
        Math.random() * 2 - 0.6,
        Math.random() * 2 - 1
      ).normalize();
      const vel = normal
        .clone()
        .multiplyScalar(1.5 * power)
        .addScaledVector(rand, (2.4 + Math.random() * 3.8) * mult);
      this.spawnParticle(
        pos,
        vel,
        0.024 + Math.random() * 0.019,
        0.44 + Math.random() * 0.3,
        i % 4 === 0 ? 0xe0f2fe : 0xf8fbff,
        1.8,
        0
      );
    }

    // Tier 3: Fine Snow Powder Mist (0.011m – 0.020m, high air drag)
    const mistCount = Math.round((isMega ? 24 : 15) * countMult);
    for (let i = 0; i < mistCount; i++) {
      const rand = new THREE.Vector3(
        Math.random() * 2 - 1,
        Math.random() * 2 - 0.5,
        Math.random() * 2 - 1
      ).normalize();
      const vel = rand.multiplyScalar((1.0 + Math.random() * 2.6) * mult);
      vel.y += 0.6;
      this.spawnParticle(
        pos,
        vel,
        0.011 + Math.random() * 0.01,
        0.28 + Math.random() * 0.22,
        0xffffff,
        4.6,
        0
      );
    }
  }

  public emitImpactBurst(pos: THREE.Vector3, normal: THREE.Vector3, power = 1.0, isMega = false): void {
    this.emitSnowballShatter(pos, normal, new THREE.Vector3(), power, isMega, false);
  }

  public emitFootSnow(pos: THREE.Vector3, moveDir: THREE.Vector3, isRun: boolean): void {
    const count = isRun ? 6 : 3;
    const baseSpeed = isRun ? 2.0 : 0.9;
    for (let i = 0; i < count; i++) {
      const spreadAngle = (Math.random() - 0.5) * 1.8;
      const kickBack = moveDir.clone().multiplyScalar(-baseSpeed * (0.4 + Math.random() * 0.6));
      kickBack.applyAxisAngle(new THREE.Vector3(0, 1, 0), spreadAngle);
      kickBack.y = (isRun ? 1.25 : 0.7) + Math.random() * 0.75;

      const spawnPos = pos.clone();
      spawnPos.y = this.getHeightAt(pos.x, pos.z) + 0.04;
      this.spawnParticle(
        spawnPos,
        kickBack,
        isRun ? 0.024 + Math.random() * 0.02 : 0.018 + Math.random() * 0.014,
        0.34 + Math.random() * 0.22
      );
    }
  }

  public emitStopSpray(pos: THREE.Vector3, slideDir: THREE.Vector3, intensity = 1.0): void {
    const count = Math.round(11 * intensity);
    const safeDir = slideDir.lengthSq() > 0.001 ? slideDir.clone().normalize() : new THREE.Vector3(0, 0, 1);
    for (let i = 0; i < count; i++) {
      const vel = safeDir.clone().multiplyScalar((1.5 + Math.random() * 1.8) * intensity);
      vel.x += (Math.random() - 0.5) * 1.3;
      vel.z += (Math.random() - 0.5) * 1.3;
      vel.y = 1.0 + Math.random() * 1.3;

      const spawnPos = pos.clone();
      spawnPos.y = this.getHeightAt(pos.x, pos.z) + 0.05;
      this.spawnParticle(spawnPos, vel, 0.024 + Math.random() * 0.022, 0.4 + Math.random() * 0.25);
    }
  }

  public emitScoopSnow(pos: THREE.Vector3): void {
    this.deformSnowAt(pos.x, pos.z, 0.04, 0.55);
    for (let i = 0; i < 8; i++) {
      const vel = new THREE.Vector3(
        (Math.random() - 0.5) * 1.5,
        0.9 + Math.random() * 1.0,
        (Math.random() - 0.5) * 1.5
      );
      this.spawnParticle(pos, vel, 0.02 + Math.random() * 0.016, 0.36 + Math.random() * 0.18);
    }
  }

  // ===================== TEAM BASES =====================
  private buildTeamBases(): void {
    const teams: { z: number; color: number; flag: number }[] = [
      { z: -26.5, color: 0x38bdf8, flag: 0x2563eb },
      { z: 26.5, color: 0xf87171, flag: 0xdc2626 },
    ];
    const poleMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4 });
    teams.forEach((tm) => {
      const padMat = new THREE.MeshStandardMaterial({
        color: tm.color,
        emissive: tm.color,
        emissiveIntensity: 0.25,
        roughness: 0.5,
      });
      for (let slot = 0; slot < 5; slot++) {
        const px = (slot - 2) * 3.4;
        const gy = this.getBaseHeightAt(px, tm.z);
        const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.78, 0.9, 0.1, 20), padMat);
        pad.position.set(px, gy + 0.03, tm.z);
        pad.receiveShadow = true;
        this.group.add(pad);
      }
      [-11.5, 11.5].forEach((fx) => {
        const gy = this.getBaseHeightAt(fx, tm.z);
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 3.6, 8), poleMat);
        pole.position.set(fx, gy + 1.8, tm.z);
        pole.castShadow = true;
        const flagMat = new THREE.MeshStandardMaterial({
          color: tm.flag,
          roughness: 0.55,
          side: THREE.DoubleSide,
        });
        const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.95), flagMat);
        flag.position.set(fx + 0.78, gy + 3.05, tm.z);
        flag.rotation.y = Math.PI / 2;
        flag.castShadow = true;
        const knob = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 10), padMat);
        knob.position.set(fx, gy + 3.65, tm.z);
        this.group.add(pole, flag, knob);
      });
    });
  }

  // ===================== EXPLOSION FX =====================
  private buildExplosionFxPool(): void {
    for (let i = 0; i < 4; i++) {
      const ringGeo = new THREE.RingGeometry(0.86, 1.0, 56);
      ringGeo.rotateX(-Math.PI / 2);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xd8f6ff,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.visible = false;
      const flashMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
      const flash = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), flashMat);
      flash.visible = false;
      this.group.add(ring, flash);
      this.explosionFx.push({ ring, ringMat, flash, flashMat, age: 0, duration: 0.62, radius: 4, active: false });
    }
  }

  /** Big snow blast: shockwave ring, flash dome, crater, giant chunk + powder burst. */
  public emitSnowExplosion(pos: THREE.Vector3, radius = 4.4): void {
    let fx = this.explosionFx.find((f) => !f.active);
    if (!fx) fx = this.explosionFx[0];
    const gy = this.getHeightAt(pos.x, pos.z);
    fx.active = true;
    fx.age = 0;
    fx.radius = radius;
    fx.ring.visible = true;
    fx.flash.visible = true;
    fx.ring.position.set(pos.x, gy + 0.2, pos.z);
    fx.flash.position.copy(pos);

    const gn = this.getNormalAt(pos.x, pos.z);
    this.addSurfaceSnowSplatter(new THREE.Vector3(pos.x, gy, pos.z), gn, radius * 1.15);
    this.addSurfaceSnowSplatter(new THREE.Vector3(pos.x, gy, pos.z), gn, radius * 0.7);
    this.deformSnowAt(pos.x, pos.z, 0.085, radius * 0.7);

    // Giant bouncing chunks
    for (let i = 0; i < 28; i++) {
      const ang = Math.random() * Math.PI * 2;
      const up = 3.5 + Math.random() * 7.5;
      const out = 1.5 + Math.random() * 5.5;
      const vel = new THREE.Vector3(Math.cos(ang) * out, up, Math.sin(ang) * out);
      this.spawnParticle(pos, vel, 0.075 + Math.random() * 0.075, 0.9 + Math.random() * 0.6, 0xffffff, 0.5, 1);
    }
    // Medium flakes
    for (let i = 0; i < 46; i++) {
      const rand = new THREE.Vector3(Math.random() * 2 - 1, Math.random() * 1.6 - 0.2, Math.random() * 2 - 1).normalize();
      const vel = rand.multiplyScalar(4 + Math.random() * 8);
      this.spawnParticle(pos, vel, 0.03 + Math.random() * 0.035, 0.6 + Math.random() * 0.5, i % 4 === 0 ? 0xbae6fd : 0xf8fbff, 1.6, 0);
    }
    // Ground-hugging dust ring
    for (let i = 0; i < 30; i++) {
      const ang = (i / 30) * Math.PI * 2 + Math.random() * 0.2;
      const sp = 5 + Math.random() * 5;
      const vel = new THREE.Vector3(Math.cos(ang) * sp, 0.8 + Math.random() * 1.4, Math.sin(ang) * sp);
      this.spawnParticle(new THREE.Vector3(pos.x, gy + 0.1, pos.z), vel, 0.05 + Math.random() * 0.04, 0.55 + Math.random() * 0.3, 0xffffff, 3.2, 0);
    }
    // Fine powder cloud
    for (let i = 0; i < 40; i++) {
      const rand = new THREE.Vector3(Math.random() * 2 - 1, Math.random() * 1.2, Math.random() * 2 - 1).normalize();
      const vel = rand.multiplyScalar(1.2 + Math.random() * 3.4);
      vel.y += 1.2;
      this.spawnParticle(pos, vel, 0.02 + Math.random() * 0.02, 0.7 + Math.random() * 0.5, 0xffffff, 3.8, 0);
    }
  }

  public emitMuzzlePuff(pos: THREE.Vector3, dir: THREE.Vector3): void {
    for (let i = 0; i < 7; i++) {
      const vel = dir
        .clone()
        .multiplyScalar(2 + Math.random() * 4)
        .add(new THREE.Vector3((Math.random() - 0.5) * 1.6, (Math.random() - 0.5) * 1.6, (Math.random() - 0.5) * 1.6));
      this.spawnParticle(pos, vel, 0.02 + Math.random() * 0.022, 0.28 + Math.random() * 0.2, 0xf0fbff, 3.4, 0);
    }
  }

  public emitTrailPuff(pos: THREE.Vector3): void {
    const vel = new THREE.Vector3((Math.random() - 0.5) * 0.9, 0.2 + Math.random() * 0.6, (Math.random() - 0.5) * 0.9);
    this.spawnParticle(pos, vel, 0.045 + Math.random() * 0.03, 0.5 + Math.random() * 0.25, 0xffffff, 2.6, 0);
  }

  public triggerTargetHit(target: RangeTarget, impactDir: THREE.Vector3, powerFactor: number): void {
    const up = new THREE.Vector3(0, 1, 0);
    const flatDir = new THREE.Vector3(impactDir.x, 0, impactDir.z);
    if (flatDir.lengthSq() < 0.001) flatDir.set(0, 0, 1);
    flatDir.normalize();
    target.wobbleAxis.crossVectors(up, flatDir).normalize();
    target.wobbleVel += 6.5 * powerFactor;
  }

  public update(dt: number, focusPos: THREE.Vector3): void {
    // 1. Footprints fade
    for (let i = 0; i < this.footprints.length; i++) {
      const fp = this.footprints[i];
      if (!fp.mesh.visible) continue;
      fp.age += dt;
      if (fp.age >= fp.maxAge) {
        fp.mesh.visible = false;
      } else if (fp.age > fp.maxAge * 0.65) {
        const fade = 1 - (fp.age - fp.maxAge * 0.65) / (fp.maxAge * 0.35);
        (fp.mesh.material as THREE.MeshStandardMaterial).opacity = 0.62 * fade;
      }
    }

    // 2. World Surface Snow Splatter Decals fade
    for (let i = 0; i < this.worldSplatters.length; i++) {
      const sp = this.worldSplatters[i];
      if (!sp.mesh.visible) continue;
      sp.age += dt;
      if (sp.age >= sp.maxAge) {
        sp.mesh.visible = false;
      } else if (sp.age > sp.maxAge * 0.65) {
        const fade = 1 - (sp.age - sp.maxAge * 0.65) / (sp.maxAge * 0.35);
        sp.mat.opacity = 0.94 * fade;
      }
    }

    // 3. Body-Attached Snow Decals fade & cleanup
    for (let i = this.bodySplatters.length - 1; i >= 0; i--) {
      const bs = this.bodySplatters[i];
      bs.age += dt;
      if (bs.age >= bs.maxAge) {
        bs.mesh.parent?.remove(bs.mesh);
        bs.mat.dispose();
        this.bodySplatters.splice(i, 1);
      } else if (bs.age > bs.maxAge * 0.65) {
        const fade = 1 - (bs.age - bs.maxAge * 0.65) / (bs.maxAge * 0.35);
        bs.mat.opacity = 0.96 * fade;
      }
    }

    // 4. Clinging Snowballs: Stick for 2–3.5s -> Slowly Slip -> Detach & Fall -> Shatter on Ground!
    for (let i = this.clingingBalls.length - 1; i >= 0; i--) {
      const cb = this.clingingBalls[i];
      if (cb.phase === 'CLINGING') {
        cb.clingTimer -= dt;
        // Slowly slip downward slightly right before detaching!
        if (cb.clingTimer < 0.85) {
          cb.mesh.position.y -= cb.slideSpeed * dt;
        }
        if (cb.clingTimer <= 0) {
          // Detach into world space and start falling with gravity!
          const worldPos = new THREE.Vector3();
          const worldQuat = new THREE.Quaternion();
          cb.mesh.getWorldPosition(worldPos);
          cb.mesh.getWorldQuaternion(worldQuat);
          cb.mesh.parent?.remove(cb.mesh);

          cb.mesh.position.copy(worldPos);
          cb.mesh.quaternion.copy(worldQuat);
          cb.mesh.scale.setScalar(cb.scaleBase * 0.92);
          this.group.add(cb.mesh);

          cb.phase = 'FALLING';
          cb.worldVel.set((Math.random() - 0.5) * 0.6, -0.4, (Math.random() - 0.5) * 0.6);
        }
      } else {
        cb.worldVel.y -= 15.5 * dt;
        cb.mesh.position.addScaledVector(cb.worldVel, dt);
        cb.mesh.rotation.x += 5.0 * dt;
        cb.mesh.rotation.z += 3.5 * dt;

        const gy = this.getHeightAt(cb.mesh.position.x, cb.mesh.position.z);
        if (cb.mesh.position.y <= gy + 0.05) {
          const landPos = new THREE.Vector3(cb.mesh.position.x, gy + 0.03, cb.mesh.position.z);
          const gn = this.getNormalAt(landPos.x, landPos.z);
          this.addSurfaceSnowSplatter(landPos, gn, 0.32 * cb.scaleBase);
          // Crumble into small snow chunks upon hitting the ground!
          for (let k = 0; k < 8; k++) {
            const v = new THREE.Vector3(
              (Math.random() - 0.5) * 2.2,
              0.8 + Math.random() * 1.4,
              (Math.random() - 0.5) * 2.2
            );
            this.spawnParticle(landPos, v, 0.025 + Math.random() * 0.02, 0.42, 0xffffff, 1.4, 0);
          }
          this.group.remove(cb.mesh);
          this.clingingBalls.splice(i, 1);
        }
      }
    }

    // 5. Bumper Jelly Bounce Pulse
    for (const b of this.bumpers) {
      if (b.pulse > 0.001) {
        b.pulse = Math.max(0, b.pulse - dt * 4.2);
        const sXZ = 1 + Math.sin(b.pulse * Math.PI) * 0.24;
        const sY = 1 - Math.sin(b.pulse * Math.PI) * 0.14;
        b.meshGroup.scale.set(sXZ, sY, sXZ);
      } else {
        b.meshGroup.scale.set(1, 1, 1);
      }
    }

    // 6. Power-Ups Spin & Respawn
    const nowSec = performance.now() * 0.001;
    for (let i = 0; i < this.powerUps.length; i++) {
      const pu = this.powerUps[i];
      if (pu.active) {
        pu.orbGroup.rotation.y += 2.2 * dt;
        pu.orbGroup.position.y = pu.position.y + 0.72 + Math.sin(nowSec * 3.0 + i) * 0.12;
      } else {
        pu.respawnTimer -= dt;
        if (pu.respawnTimer <= 0) {
          pu.active = true;
          pu.type = ALL_POWERUP_TYPES[Math.floor(Math.random() * ALL_POWERUP_TYPES.length)];
          pu.orbMat.color.setHex(POWERUP_COLORS[pu.type]);
          pu.orbMat.emissive.setHex(POWERUP_COLORS[pu.type]);
          pu.orbGroup.visible = true;
        }
      }
    }

    // 7. Update Multi-Size Particles (including bouncing snow chunks!)
    let anyActive = false;
    for (let i = 0; i < this.maxParticles; i++) {
      const p = this.particles[i];
      if (!p.active) continue;
      anyActive = true;
      p.age += dt;
      if (p.age >= p.life) {
        p.active = false;
        this.dummyObj.position.set(0, -100, 0);
        this.dummyObj.scale.setScalar(0.0001);
        this.dummyObj.updateMatrix();
        this.particleMesh.setMatrixAt(i, this.dummyObj.matrix);
        continue;
      }
      p.vel.y -= 12.2 * dt;
      p.vel.multiplyScalar(Math.max(0, 1 - p.drag * dt));
      p.pos.addScaledVector(p.vel, dt);

      const groundY = this.getHeightAt(p.pos.x, p.pos.z);
      if (p.pos.y < groundY + p.size * 0.6) {
        p.pos.y = groundY + p.size * 0.6;
        if (p.bouncesLeft > 0 && Math.abs(p.vel.y) > 0.8) {
          p.vel.y = -p.vel.y * 0.34;
          p.vel.x *= 0.55;
          p.vel.z *= 0.55;
          p.bouncesLeft--;
        } else {
          p.vel.set(0, 0, 0);
        }
      }

      const scaleFade = p.size * (1 - Math.pow(p.age / p.life, 1.5) * 0.72);
      this.dummyObj.position.copy(p.pos);
      this.dummyObj.scale.setScalar(Math.max(0.001, scaleFade));
      this.dummyObj.updateMatrix();
      this.particleMesh.setMatrixAt(i, this.dummyObj.matrix);
    }
    if (anyActive) {
      this.particleMesh.instanceMatrix.needsUpdate = true;
    }

    // 7b. Explosion shockwave rings & flash domes
    for (const fx of this.explosionFx) {
      if (!fx.active) continue;
      fx.age += dt;
      const t = fx.age / fx.duration;
      if (t >= 1) {
        fx.active = false;
        fx.ring.visible = false;
        fx.flash.visible = false;
        continue;
      }
      const ease = 1 - Math.pow(1 - t, 3);
      fx.ring.scale.setScalar(0.4 + fx.radius * 1.25 * ease);
      fx.ringMat.opacity = (1 - t) * 0.9;
      fx.flash.scale.setScalar(0.5 + fx.radius * 0.55 * ease);
      fx.flashMat.opacity = Math.pow(1 - t, 2) * 0.75;
    }

    // 8. Target wobble
    for (const t of this.targets) {
      if (Math.abs(t.wobbleAngle) > 0.0005 || Math.abs(t.wobbleVel) > 0.0005) {
        t.wobbleVel += (-52 * t.wobbleAngle - 5.8 * t.wobbleVel) * dt;
        t.wobbleAngle += t.wobbleVel * dt;
        t.pivotGroup.quaternion.setFromAxisAngle(t.wobbleAxis, t.wobbleAngle);
      }
    }

    // 9. Ambient Snowfall
    const posAttr = this.ambientSnowPoints.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < this.ambientCount; i++) {
      let x = posAttr.getX(i) + Math.sin(nowSec * 0.6 + i) * 0.25 * dt;
      let y = posAttr.getY(i) - 0.95 * dt;
      let z = posAttr.getZ(i) + Math.cos(nowSec * 0.5 + i) * 0.2 * dt;

      if (y < focusPos.y - 0.5) {
        y = focusPos.y + 12 + Math.random() * 3;
        x = focusPos.x + (Math.random() - 0.5) * 44;
        z = focusPos.z + (Math.random() - 0.5) * 44;
      }
      posAttr.setXYZ(i, x, y, z);
    }
    posAttr.needsUpdate = true;
  }
}
