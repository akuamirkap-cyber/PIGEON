export class InputManager {
  private keys = new Set<string>();
  private canvas: HTMLElement;

  public mouseDeltaX = 0;
  public mouseDeltaY = 0;
  public isPointerLocked = false;
  private pointerLockRejected = false;
  private isDraggingUnlocked = false;
  private lastClientX = 0;
  private lastClientY = 0;
  private onUserInteractCallback?: () => void;

  // Weapon / action state
  public fireHeld = false;
  public fireJustPressed = false;
  public adsHeld = false;
  public adsToggleJustPressed = false;
  public reloadJustPressed = false;
  public inspectJustPressed = false;
  public ammoToggleJustPressed = false;
  public weaponSlotRequest = 0;
  public jumpJustPressed = false;

  constructor(canvas: HTMLElement, onUserInteract?: () => void) {
    this.canvas = canvas;
    this.onUserInteractCallback = onUserInteract;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('pointerlockchange', this.onPointerLockChange);
    document.addEventListener('pointerlockerror', this.onPointerLockError);
    canvas.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    window.addEventListener('mousemove', this.onMouseMove);
    canvas.addEventListener('contextmenu', this.onContextMenu);
  }

  public dispose(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('pointerlockchange', this.onPointerLockChange);
    document.removeEventListener('pointerlockerror', this.onPointerLockError);
    this.canvas.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('mousemove', this.onMouseMove);
    this.canvas.removeEventListener('contextmenu', this.onContextMenu);
  }

  /** True when mouse input should drive the game (pointer locked, or the browser refused the lock). */
  public get active(): boolean {
    return this.isPointerLocked || this.pointerLockRejected;
  }

  private onContextMenu = (e: MouseEvent): void => {
    e.preventDefault();
  };

  private onPointerLockChange = (): void => {
    this.isPointerLocked = document.pointerLockElement === this.canvas;
    if (!this.isPointerLocked) {
      this.fireHeld = false;
      this.adsHeld = false;
    }
  };

  private onPointerLockError = (): void => {
    this.pointerLockRejected = true;
  };

  private onBlur = (): void => {
    this.keys.clear();
    this.fireHeld = false;
    this.adsHeld = false;
    this.isDraggingUnlocked = false;
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
    this.onUserInteractCallback?.();

    if (e.code === 'Space' || e.code === 'Tab') e.preventDefault();

    if (!this.keys.has(e.code)) {
      if (e.code === 'Space') this.jumpJustPressed = true;
      if (e.code === 'KeyR') this.reloadJustPressed = true;
      if (e.code === 'KeyF') this.inspectJustPressed = true;
      if (e.code === 'KeyB') this.ammoToggleJustPressed = true;
      if (e.code === 'KeyQ') this.adsToggleJustPressed = true;
      if (e.code === 'Digit1') this.weaponSlotRequest = 1;
      if (e.code === 'Digit2') this.weaponSlotRequest = 2;
      if (e.code === 'Digit3') this.weaponSlotRequest = 3;
    }
    this.keys.add(e.code);
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
  };

  private onMouseDown = (e: MouseEvent): void => {
    this.onUserInteractCallback?.();

    if (!this.isPointerLocked && !this.pointerLockRejected) {
      // first click only captures the mouse (like the original FPS)
      try {
        this.canvas.requestPointerLock?.();
      } catch {
        this.pointerLockRejected = true;
      }
      return;
    }

    if (!this.isPointerLocked) {
      this.isDraggingUnlocked = true;
      this.lastClientX = e.clientX;
      this.lastClientY = e.clientY;
    }

    if (e.button === 0) {
      this.fireHeld = true;
      this.fireJustPressed = true;
    } else if (e.button === 2) {
      this.adsHeld = true;
    }
  };

  private onMouseUp = (e: MouseEvent): void => {
    this.isDraggingUnlocked = false;
    if (e.button === 0) this.fireHeld = false;
    else if (e.button === 2) this.adsHeld = false;
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (this.isPointerLocked) {
      this.mouseDeltaX += e.movementX;
      this.mouseDeltaY += e.movementY;
    } else if (this.isDraggingUnlocked) {
      this.mouseDeltaX += e.clientX - this.lastClientX;
      this.mouseDeltaY += e.clientY - this.lastClientY;
      this.lastClientX = e.clientX;
      this.lastClientY = e.clientY;
    }
  };

  public getMoveInput(): { x: number; z: number; magnitude: number } {
    let x = 0;
    let z = 0;
    if (this.keys.has('KeyW')) z += 1;
    if (this.keys.has('KeyS')) z -= 1;
    if (this.keys.has('KeyA')) x -= 1;
    if (this.keys.has('KeyD')) x += 1;
    const mag = Math.hypot(x, z);
    if (mag > 1) {
      x /= mag;
      z /= mag;
    }
    return { x, z, magnitude: Math.min(1, mag) };
  }

  /** Mouse delta plus arrow-key look (fallback when pointer lock is unavailable). */
  public getCameraDelta(dt: number): { dx: number; dy: number } {
    const k = 680;
    let keyX = 0;
    let keyY = 0;
    if (this.keys.has('ArrowRight')) keyX += k * dt;
    if (this.keys.has('ArrowLeft')) keyX -= k * dt;
    if (this.keys.has('ArrowDown')) keyY += k * dt * 0.75;
    if (this.keys.has('ArrowUp')) keyY -= k * dt * 0.75;
    return { dx: this.mouseDeltaX + keyX, dy: this.mouseDeltaY + keyY };
  }

  public isRunHeld(): boolean {
    return this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
  }

  public isRollHeld(): boolean {
    return this.keys.has('KeyV') || this.keys.has('KeyE');
  }

  public isCrouchHeld(): boolean {
    return this.keys.has('KeyC') || this.keys.has('ControlLeft');
  }

  public endFrame(): void {
    this.mouseDeltaX = 0;
    this.mouseDeltaY = 0;
    this.fireJustPressed = false;
    this.adsToggleJustPressed = false;
    this.reloadJustPressed = false;
    this.inspectJustPressed = false;
    this.ammoToggleJustPressed = false;
    this.weaponSlotRequest = 0;
    this.jumpJustPressed = false;
  }
}
