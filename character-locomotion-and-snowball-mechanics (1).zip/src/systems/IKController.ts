import * as THREE from 'three';
import { CharacterRig } from '../character/CharacterRig';
import { CharacterConfig } from '../config/GameConfig';
import { SnowTerrain } from '../world/SnowTerrain';
import { WeaponController } from '../character/WeaponModels';

export class IKController {
  private smoothedPelvisOffset = 0;

  public footGroundedL = true;
  public footGroundedR = true;

  private readonly tempV1 = new THREE.Vector3();
  private readonly tempV2 = new THREE.Vector3();
  private readonly tempV3 = new THREE.Vector3();
  private readonly tempMat = new THREE.Matrix4();
  private readonly tempQ1 = new THREE.Quaternion();
  private readonly worldUp = new THREE.Vector3(0, 1, 0);

  /**
   * Analytical 2-Bone Limb IK solver in world space with explicit Pole Vector.
   * Assumes bones extend along their local -Y axis from rootBone -> midBone -> endBone.
   */
  public solveTwoBoneIK(
    rootBone: THREE.Object3D,
    midBone: THREE.Object3D,
    endBone: THREE.Object3D,
    len1: number,
    len2: number,
    worldTarget: THREE.Vector3,
    worldPoleDir: THREE.Vector3,
    weight: number
  ): void {
    if (weight <= 0.001 || !rootBone.parent) return;

    rootBone.parent.updateWorldMatrix(true, false);
    rootBone.updateWorldMatrix(false, true);

    const pRoot = new THREE.Vector3();
    const pEndAnim = new THREE.Vector3();
    rootBone.getWorldPosition(pRoot);
    endBone.getWorldPosition(pEndAnim);

    const pGoal = pEndAnim.lerp(worldTarget, THREE.MathUtils.clamp(weight, 0, 1));
    const toGoal = this.tempV1.copy(pGoal).sub(pRoot);
    const rawDist = toGoal.length();
    if (rawDist < 0.0001) return;

    const minReach = Math.abs(len1 - len2) + 0.018;
    const maxReach = (len1 + len2) * 0.992; // Soft cap prevents knee/elbow hyperextension snap
    const d = THREE.MathUtils.clamp(rawDist, minReach, maxReach);

    const uDir = toGoal.divideScalar(rawDist);

    // Law of cosines for interior angle alpha at rootBone
    const cosAlpha = THREE.MathUtils.clamp(
      (len1 * len1 + d * d - len2 * len2) / (2 * len1 * d),
      -1,
      1
    );
    const alpha = Math.acos(cosAlpha);

    // Project pole direction perpendicular to limb line uDir
    const poleOrtho = this.tempV2
      .copy(worldPoleDir)
      .addScaledVector(uDir, -worldPoleDir.dot(uDir));
    if (poleOrtho.lengthSq() < 0.0001) {
      poleOrtho.set(0, 0, 1).addScaledVector(uDir, -uDir.z);
    }
    poleOrtho.normalize();

    // Exact world positions of middle joint (knee/elbow) and end joint (ankle/wrist)
    const pMid = new THREE.Vector3()
      .copy(pRoot)
      .addScaledVector(uDir, len1 * Math.cos(alpha))
      .addScaledVector(poleOrtho, len1 * Math.sin(alpha));

    const pEnd = this.tempV3.copy(pRoot).addScaledVector(uDir, d);

    // 1. Solve rootBone world basis using singularity-free hinge (-uDir x poleOrtho)
    const negUDir = uDir.clone().negate();
    const xHinge = new THREE.Vector3().crossVectors(negUDir, poleOrtho).normalize();
    const yRoot = new THREE.Vector3().copy(pRoot).sub(pMid).normalize();
    const zRoot = new THREE.Vector3().crossVectors(xHinge, yRoot).normalize();

    this.tempMat.makeBasis(xHinge, yRoot, zRoot);
    const qWorldRoot = new THREE.Quaternion().setFromRotationMatrix(this.tempMat);

    rootBone.parent.getWorldQuaternion(this.tempQ1);
    rootBone.quaternion.copy(this.tempQ1.invert()).multiply(qWorldRoot);

    // 2. Solve midBone world basis (bone extends along -Y from pMid to pEnd, sharing hinge xHinge)
    const yMid = new THREE.Vector3().copy(pMid).sub(pEnd).normalize();
    const zMid = new THREE.Vector3().crossVectors(xHinge, yMid).normalize();
    const xMid = new THREE.Vector3().crossVectors(yMid, zMid).normalize();

    this.tempMat.makeBasis(xMid, yMid, zMid);
    const qWorldMid = new THREE.Quaternion().setFromRotationMatrix(this.tempMat);

    midBone.quaternion.copy(qWorldRoot.invert()).multiply(qWorldMid);
  }

  public applyFootIK(
    dt: number,
    rig: CharacterRig,
    facingYaw: number,
    stanceWeightL: number,
    stanceWeightR: number,
    ankleSlopeWeightL: number,
    ankleSlopeWeightR: number,
    config: CharacterConfig,
    terrain: SnowTerrain
  ): void {
    const ikWeight = config.footIKWeight;
    if (ikWeight <= 0.001) return;

    rig.root.updateMatrixWorld(true);

    const rootY = rig.root.position.y;
    const animFootL = new THREE.Vector3();
    const animFootR = new THREE.Vector3();
    const animSoleL = new THREE.Vector3();
    const animSoleR = new THREE.Vector3();
    const qAnimFootL = new THREE.Quaternion();
    const qAnimFootR = new THREE.Quaternion();

    rig.footL.getWorldPosition(animFootL);
    rig.footR.getWorldPosition(animFootR);
    rig.soleL.getWorldPosition(animSoleL);
    rig.soleR.getWorldPosition(animSoleR);
    rig.footL.getWorldQuaternion(qAnimFootL);
    rig.footR.getWorldQuaternion(qAnimFootR);

    this.footGroundedL = stanceWeightL > 0.45;
    this.footGroundedR = stanceWeightR > 0.45;

    // Sample snow terrain height beneath each boot + subtle snow sink (-0.012m)
    const snowSink = 0.012;
    const groundYL = terrain.getHeightAt(animFootL.x, animFootL.z) - snowSink;
    const groundYR = terrain.getHeightAt(animFootR.x, animFootR.z) - snowSink;

    // Terrain height difference relative to character root
    const deltaL = groundYL - rootY;
    const deltaR = groundYR - rootY;

    // Lower pelvis smoothly when a planted foot steps down a slope so legs never over-stretch
    const plantedMinDelta = Math.min(deltaL * stanceWeightL, deltaR * stanceWeightR);
    const targetPelvisShift = THREE.MathUtils.clamp(plantedMinDelta, -0.22, 0.05);
    this.smoothedPelvisOffset = THREE.MathUtils.lerp(
      this.smoothedPelvisOffset,
      targetPelvisShift,
      1 - Math.exp(-14 * dt)
    );
    rig.pelvis.position.y += this.smoothedPelvisOffset * ikWeight;

    rig.root.updateMatrixWorld(true);
    // Re-read animated ankle positions after pelvis height adjustment
    rig.footL.getWorldPosition(animFootL);
    rig.footR.getWorldPosition(animFootR);

    // Terrain-delta target ankle Y:
    // On flat ground (delta ≈ -0.012m), preserves 100% of the biomechanical run/walk curve!
    // On snow mounds/slopes, shifts planted ankle cleanly onto uneven terrain AND prevents snow clipping!
    const minNonClipAnkleL = groundYL + CharacterRig.FOOT_SOLE_HEIGHT;
    const minNonClipAnkleR = groundYR + CharacterRig.FOOT_SOLE_HEIGHT;

    let desiredAnkleYL = animFootL.y + (deltaL - this.smoothedPelvisOffset) * stanceWeightL;
    let desiredAnkleYR = animFootR.y + (deltaR - this.smoothedPelvisOffset) * stanceWeightR;

    let effWeightL = stanceWeightL;
    let effWeightR = stanceWeightR;

    // Anti-penetration guard if swinging foot passes over a tall snowbank
    if (desiredAnkleYL < minNonClipAnkleL && minNonClipAnkleL > animFootL.y) {
      desiredAnkleYL = minNonClipAnkleL;
      effWeightL = 1.0;
    }
    if (desiredAnkleYR < minNonClipAnkleR && minNonClipAnkleR > animFootR.y) {
      desiredAnkleYR = minNonClipAnkleR;
      effWeightR = 1.0;
    }

    const targetAnkleL = new THREE.Vector3(animFootL.x, desiredAnkleYL, animFootL.z);
    const targetAnkleR = new THREE.Vector3(animFootR.x, desiredAnkleYR, animFootR.z);

    // Forward knee pole vectors
    const fwdX = Math.sin(facingYaw);
    const fwdZ = Math.cos(facingYaw);
    const leftX = Math.cos(facingYaw);
    const leftZ = -Math.sin(facingYaw);

    const poleL = new THREE.Vector3(fwdX + leftX * 0.04, 0.06, fwdZ + leftZ * 0.04).normalize();
    const poleR = new THREE.Vector3(fwdX - leftX * 0.04, 0.06, fwdZ - leftZ * 0.04).normalize();

    this.solveTwoBoneIK(
      rig.thighL,
      rig.calfL,
      rig.footL,
      CharacterRig.THIGH_LEN,
      CharacterRig.CALF_LEN,
      targetAnkleL,
      poleL,
      THREE.MathUtils.clamp(effWeightL * ikWeight, 0, 1)
    );

    this.solveTwoBoneIK(
      rig.thighR,
      rig.calfR,
      rig.footR,
      CharacterRig.THIGH_LEN,
      CharacterRig.CALF_LEN,
      targetAnkleR,
      poleR,
      THREE.MathUtils.clamp(effWeightR * ikWeight, 0, 1)
    );

    // Multiplicative Slope Alignment:
    // Tilts animated foot rotation by terrain slope delta WITHOUT erasing heel-strike or toe-off pitch!
    rig.root.updateMatrixWorld(true);
    this.alignFootToSlopeDelta(
      rig.calfL,
      rig.footL,
      qAnimFootL,
      animFootL,
      THREE.MathUtils.clamp(ankleSlopeWeightL * ikWeight, 0, 1),
      terrain
    );
    this.alignFootToSlopeDelta(
      rig.calfR,
      rig.footR,
      qAnimFootR,
      animFootR,
      THREE.MathUtils.clamp(ankleSlopeWeightR * ikWeight, 0, 1),
      terrain
    );
  }

  private alignFootToSlopeDelta(
    calfBone: THREE.Object3D,
    footBone: THREE.Object3D,
    qAnimFootWorld: THREE.Quaternion,
    footPos: THREE.Vector3,
    slopeWeight: number,
    terrain: SnowTerrain
  ): void {
    const normal = terrain.getNormalAt(footPos.x, footPos.z);
    const qSlopeDelta = new THREE.Quaternion().setFromUnitVectors(this.worldUp, normal);
    const qSlopeAdjustedWorld = qSlopeDelta.multiply(qAnimFootWorld);

    const qFinalWorld = qAnimFootWorld.clone().slerp(qSlopeAdjustedWorld, slopeWeight);
    const qCalfWorld = new THREE.Quaternion();
    calfBone.getWorldQuaternion(qCalfWorld);

    footBone.quaternion.copy(qCalfWorld.invert()).multiply(qFinalWorld);
  }

  /**
   * Two-handed weapon IK: right hand on the pistol grip / handle, left hand on the foregrip.
   */
  public applyWeaponIK(rig: CharacterRig, weapon: WeaponController, weight: number): void {
    if (weight <= 0.001) return;
    rig.root.updateMatrixWorld(true);
    const gR = weapon.getGripRWorld(new THREE.Vector3());
    const gL = weapon.getGripLWorld(new THREE.Vector3());
    const yaw = rig.root.rotation.y;
    const fwd = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
    const right = new THREE.Vector3(-Math.cos(yaw), 0, Math.sin(yaw));
    const poleR = new THREE.Vector3()
      .addScaledVector(right, 0.8)
      .addScaledVector(fwd, -0.25)
      .add(new THREE.Vector3(0, -0.55, 0))
      .normalize();
    const poleL = new THREE.Vector3()
      .addScaledVector(right, -0.8)
      .addScaledVector(fwd, -0.25)
      .add(new THREE.Vector3(0, -0.55, 0))
      .normalize();

    this.solveTwoBoneIK(
      rig.upperArmR,
      rig.forearmR,
      rig.handR,
      CharacterRig.UPPER_ARM_LEN,
      CharacterRig.FOREARM_LEN,
      gR,
      poleR,
      weight
    );
    this.solveTwoBoneIK(
      rig.upperArmL,
      rig.forearmL,
      rig.handL,
      CharacterRig.UPPER_ARM_LEN,
      CharacterRig.FOREARM_LEN,
      gL,
      poleL,
      weight
    );
  }

  public applyHandIK(
    rig: CharacterRig,
    facingYaw: number,
    isPickingUp: boolean,
    pickupProgress: number,
    scoopWorldTarget: THREE.Vector3,
    hasSnowball: boolean,
    isAiming: boolean,
    throwPhase: string,
    throwPhaseProgress: number,
    aimDirection: THREE.Vector3,
    config: CharacterConfig
  ): void {
    const ikWeight = config.handIKWeight;
    if (ikWeight <= 0.001) return;

    rig.root.updateMatrixWorld(true);

    const fwd = new THREE.Vector3(Math.sin(facingYaw), 0, Math.cos(facingYaw));
    const right = new THREE.Vector3(-Math.cos(facingYaw), 0, Math.sin(facingYaw));

    // 1. Full-Body Snowball Pickup Right Hand IK -> touches exact snow surface!
    if (isPickingUp) {
      let scoopWeight = 0;
      if (pickupProgress < 0.45) {
        scoopWeight = THREE.MathUtils.smoothstep(pickupProgress, 0.06, 0.38);
      } else {
        scoopWeight = 1 - THREE.MathUtils.smoothstep(pickupProgress, 0.48, 0.86);
      }

      const elbowPoleR = new THREE.Vector3()
        .addScaledVector(fwd, -0.55)
        .addScaledVector(right, 0.8)
        .add(new THREE.Vector3(0, 0.1, 0))
        .normalize();

      this.solveTwoBoneIK(
        rig.upperArmR,
        rig.forearmR,
        rig.handR,
        CharacterRig.UPPER_ARM_LEN,
        CharacterRig.FOREARM_LEN,
        scoopWorldTarget,
        elbowPoleR,
        scoopWeight * ikWeight
      );

      // Left hand counterbalance near left knee during deep crouch
      const thighKneePos = new THREE.Vector3();
      rig.calfL.getWorldPosition(thighKneePos);
      thighKneePos.addScaledVector(fwd, 0.08).addScaledVector(right, -0.14);
      thighKneePos.y += 0.14;

      const elbowPoleL = new THREE.Vector3()
        .addScaledVector(fwd, -0.6)
        .addScaledVector(right, -0.75)
        .normalize();

      this.solveTwoBoneIK(
        rig.upperArmL,
        rig.forearmL,
        rig.handL,
        CharacterRig.UPPER_ARM_LEN,
        CharacterRig.FOREARM_LEN,
        thighKneePos,
        elbowPoleL,
        scoopWeight * 0.55 * ikWeight
      );
      return;
    }

    // 2. Smooth Continuous Release-Window Aim IK (Zero pop across ACCELERATION -> FOLLOW_THROUGH!)
    if (throwPhase === 'ACCELERATION' || throwPhase === 'FOLLOW_THROUGH') {
      let bellWeight = 0;
      if (throwPhase === 'ACCELERATION') {
        // Smooth ramp up from t=0.38 -> 1.0
        bellWeight = THREE.MathUtils.smoothstep(throwPhaseProgress, 0.38, 1.0);
      } else {
        // Smooth ramp down from t=0.0 -> 0.42 in FOLLOW_THROUGH so arm never snaps!
        bellWeight = 1 - THREE.MathUtils.smoothstep(throwPhaseProgress, 0.0, 0.42);
      }

      if (bellWeight > 0.005) {
        const shoulderPos = new THREE.Vector3();
        rig.upperArmR.getWorldPosition(shoulderPos);

        const reachDist = (CharacterRig.UPPER_ARM_LEN + CharacterRig.FOREARM_LEN) * 0.9;
        // Follow-through drifts target slightly downward & across left along natural arc
        const followSweep =
          throwPhase === 'FOLLOW_THROUGH' ? throwPhaseProgress * 0.25 : 0;

        const releaseApexTarget = shoulderPos
          .clone()
          .addScaledVector(aimDirection, reachDist)
          .addScaledVector(right, -followSweep * 0.45)
          .add(new THREE.Vector3(0, 0.05 - followSweep * 0.35, 0));

        // High-3/4 overhand athletic elbow pole (outward + upward, NEVER tucked under ribs!)
        const elbowPoleR = new THREE.Vector3()
          .addScaledVector(right, 0.72)
          .addScaledVector(fwd, 0.28)
          .add(new THREE.Vector3(0, 0.56, 0))
          .normalize();

        this.solveTwoBoneIK(
          rig.upperArmR,
          rig.forearmR,
          rig.handR,
          CharacterRig.UPPER_ARM_LEN,
          CharacterRig.FOREARM_LEN,
          releaseApexTarget,
          elbowPoleR,
          bellWeight * 0.42 * ikWeight
        );
      }
      return;
    }

    // 3. Right & Left Hand IK during Precision Aiming while holding snowball
    if (hasSnowball && isAiming && throwPhase === 'NONE') {
      const chestPos = new THREE.Vector3();
      rig.chest.getWorldPosition(chestPos);

      const holdTargetR = chestPos
        .clone()
        .addScaledVector(right, 0.23)
        .addScaledVector(aimDirection, 0.32)
        .add(new THREE.Vector3(0, 0.04, 0));

      const elbowPoleR = new THREE.Vector3()
        .addScaledVector(right, 0.72)
        .addScaledVector(fwd, -0.4)
        .add(new THREE.Vector3(0, -0.55, 0))
        .normalize();

      this.solveTwoBoneIK(
        rig.upperArmR,
        rig.forearmR,
        rig.handR,
        CharacterRig.UPPER_ARM_LEN,
        CharacterRig.FOREARM_LEN,
        holdTargetR,
        elbowPoleR,
        0.48 * ikWeight
      );

      const sightTargetL = chestPos
        .clone()
        .addScaledVector(right, -0.18)
        .addScaledVector(aimDirection, 0.42)
        .add(new THREE.Vector3(0, -0.02, 0));

      const elbowPoleL = new THREE.Vector3()
        .addScaledVector(right, -0.7)
        .add(new THREE.Vector3(0, -0.6, 0))
        .normalize();

      this.solveTwoBoneIK(
        rig.upperArmL,
        rig.forearmL,
        rig.handL,
        CharacterRig.UPPER_ARM_LEN,
        CharacterRig.FOREARM_LEN,
        sightTargetL,
        elbowPoleL,
        0.38 * ikWeight
      );
    }
  }
}
