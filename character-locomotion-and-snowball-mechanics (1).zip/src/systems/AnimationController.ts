import * as THREE from 'three';
import { CharacterRig } from '../character/CharacterRig';
import {
  CharacterConfig,
  LocomotionState,
  ThrowPhase,
  UpperActionState,
} from '../config/GameConfig';

export interface FootPlantEvent {
  side: 'L' | 'R';
  worldPos: THREE.Vector3;
  yaw: number;
  isRun: boolean;
}

// ============================================================================
// BIOMECHANICAL 8-KEYFRAME MOTION CURVES OVER NORMALIZED CYCLE u ∈ [0, 1)
// Keyframe indices k = 0..7 correspond to u = 0.000, 0.125, 0.250, ..., 0.875
// u = 0.000 is Initial Foot Contact (Strike)
// ============================================================================

// WALK: Grounded snow walk, 50%+ stance duty, heel-to-toe roll, inverted-pendulum pelvis vault
const WALK_THIGH_X = [-0.36, -0.18, 0.05, 0.26, 0.32, 0.02, -0.27, -0.38];
const WALK_CALF_X = [0.12, 0.27, 0.14, 0.16, 0.52, 0.94, 0.76, 0.30];
const WALK_FOOT_X = [-0.22, 0.03, 0.08, 0.20, 0.30, 0.02, -0.14, -0.22];
const WALK_PELVIS_Y = [-0.022, -0.010, 0.009, -0.006, -0.022, -0.010, 0.009, -0.006];

// JOG: Athletic mid-tempo stride, spring-mass cushion, crisp heel lift
const JOG_THIGH_X = [-0.42, -0.16, 0.40, 0.24, -0.18, -0.56, -0.70, -0.55];
const JOG_CALF_X = [0.34, 0.56, 0.22, 1.04, 1.52, 1.34, 0.98, 0.56];
const JOG_FOOT_X = [-0.14, 0.07, 0.38, 0.16, -0.04, -0.10, -0.16, -0.18];
const JOG_PELVIS_Y = [-0.028, -0.042, 0.004, 0.016, -0.028, -0.042, 0.004, 0.016];

// RUN: Energetic athletic run with true flight phase, explosive push-off (+30° hip ext),
// high heel-to-glute recovery fold (+111°), high knee punch (-53°), and vertical-shin paw-back
const RUN_THIGH_X = [-0.48, -0.18, 0.54, 0.34, -0.22, -0.75, -0.92, -0.68];
const RUN_CALF_X = [0.44, 0.68, 0.22, 1.38, 1.94, 1.72, 1.32, 0.74];
const RUN_FOOT_X = [-0.10, 0.10, 0.48, 0.20, -0.04, -0.12, -0.18, -0.20];
const RUN_PELVIS_Y = [-0.034, -0.054, 0.008, 0.025, -0.034, -0.054, 0.008, 0.025];

function sampleCyclicSpline(keys: readonly number[], uNorm: number): number {
  const n = keys.length;
  const wrapped = ((uNorm % 1) + 1) % 1;
  const scaled = wrapped * n;
  const i1 = Math.floor(scaled) % n;
  const t = scaled - Math.floor(scaled);

  const v0 = keys[(i1 - 1 + n) % n];
  const v1 = keys[i1];
  const v2 = keys[(i1 + 1) % n];
  const v3 = keys[(i1 + 2) % n];

  const t2 = t * t;
  const t3 = t2 * t;
  return (
    0.5 *
    (2 * v1 +
      (-v0 + v2) * t +
      (2 * v0 - 5 * v1 + 4 * v2 - v3) * t2 +
      (-v0 + 3 * v1 - 3 * v2 + v3) * t3)
  );
}

/**
 * Computes smooth stance weight (1 = boot planted on snow, 0 = boot airborne in swing/flight)
 * for normalized leg cycle u ∈ [0, 1) where u = 0 is initial contact and u = stanceEnd is toe-off.
 */
function computePhaseStanceWeight(uNorm: number, stanceEnd: number): number {
  const u = ((uNorm % 1) + 1) % 1;
  // Feather in just before strike [0.93 .. 1.00] -> [0.00 .. 0.03]
  if (u >= 0.93) {
    return THREE.MathUtils.smoothstep(u, 0.93, 1.0);
  }
  if (u <= stanceEnd) {
    return 1 - THREE.MathUtils.smoothstep(u, stanceEnd - 0.1, stanceEnd + 0.02);
  }
  return 0;
}

export class AnimationController {
  public crouchAmount = 0;
  private cycleU = 0; // Normalized gait cycle [0 .. 1), u=0 is Left Foot Strike, u=0.5 is Right Foot Strike
  private prevCycleU = 0;
  private idleTime = 0;
  private turnInPlacePhase = 0;

  // Exposed to IKController so Foot IK respects true flight vs stance phases
  public stanceWeightL = 1.0;
  public stanceWeightR = 1.0;
  public ankleSlopeWeightL = 1.0;
  public ankleSlopeWeightR = 1.0;

  // Smoothed layer weights to guarantee silky transitions with zero popping
  private smoothHoldWeight = 0;
  private smoothAimLayerWeight = 0;
  private smoothPitchLean = 0;
  private smoothRollLean = 0;

  public update(
    dt: number,
    rig: CharacterRig,
    locomotionState: LocomotionState,
    upperState: UpperActionState,
    stopProgress: number,
    sharpTurnTimer: number,
    sharpTurnSign: number,
    turnInPlaceSign: number,
    speed: number,
    blendSpeed: number, // 0.0 idle, 0.3 walk, 0.6 jog, 1.0 run
    blendDirection: number, // -1 left .. 0 fwd .. +1 right
    localForwardRatio: number, // -1 back .. +1 fwd
    localAccelForward: number,
    localAccelRight: number,
    angularVelocityYaw: number,
    facingYaw: number,
    isPickingUp: boolean,
    pickupProgress: number,
    hasSnowball: boolean,
    isAiming: boolean,
    throwPhase: ThrowPhase,
    throwPhaseProgress: number,
    chargeRatio: number,
    aimYawOffset: number,
    aimPitch: number,
    config: CharacterConfig,
    onFootPlant: (ev: FootPlantEvent) => void
  ): void {
    rig.resetPose();
    this.idleTime += dt;

    // =========================================================================
    // 1. ADVANCE NORMALIZED GAIT CYCLE u ∈ [0, 1) (Stumble-proportioned cadence!)
    // =========================================================================
    const moveWeight = THREE.MathUtils.clamp(blendSpeed / 0.24, 0, 1);
    this.prevCycleU = this.cycleU;

    if (speed > 0.08) {
      // Snappy Stumble Guys stride cadence matched to compact 0.42m legs!
      const tStride = THREE.MathUtils.clamp((blendSpeed - 0.28) / 0.72, 0, 1);
      const strideLength = THREE.MathUtils.lerp(0.88, 1.72, tStride);
      const dirSign = localForwardRatio < -0.2 ? -1 : 1;
      const deltaU = (speed / strideLength) * dt * dirSign;
      this.cycleU = (((this.cycleU + deltaU) % 1) + 1) % 1;
    }

    const idleWeight = 1 - moveWeight;
    this.stanceWeightL = idleWeight;
    this.stanceWeightR = idleWeight;
    this.ankleSlopeWeightL = idleWeight;
    this.ankleSlopeWeightR = idleWeight;

    // =========================================================================
    // 2. BASE LAYER: IDLE + BIOMECHANICAL 2D LOCOMOTION BLEND TREE
    // =========================================================================

    // --- 2A. Organic Human Idle Pose (Breathing + Subtle Weight Shift) ---
    if (idleWeight > 0.001) {
      const breath = Math.sin(this.idleTime * 1.85);
      const slowShift = Math.sin(this.idleTime * 0.72);

      rig.pelvis.position.y += (-0.008 + breath * 0.004) * idleWeight;
      rig.pelvis.position.x += slowShift * 0.012 * idleWeight;
      rig.pelvis.rotation.z += -slowShift * 0.02 * idleWeight;
      rig.pelvis.rotation.y += -0.05 * idleWeight;

      rig.spineLower.rotation.x += 0.016 * idleWeight;
      rig.spineUpper.rotation.x += (0.02 + breath * 0.013) * idleWeight;
      rig.chest.rotation.x += breath * 0.015 * idleWeight;
      rig.chest.rotation.y += 0.05 * idleWeight;

      rig.head.rotation.y += -0.02 * idleWeight;
      rig.head.rotation.x += -breath * 0.01 * idleWeight;

      // Natural relaxed arms (using 'ZXY' order on upperArms)
      rig.upperArmL.rotation.z += 0.11 * idleWeight;
      rig.upperArmL.rotation.x += 0.04 * idleWeight;
      rig.upperArmL.rotation.y += -0.12 * idleWeight;
      rig.forearmL.rotation.x += (-0.24 - breath * 0.02) * idleWeight;

      rig.upperArmR.rotation.z += -0.11 * idleWeight;
      rig.upperArmR.rotation.x += 0.04 * idleWeight;
      rig.upperArmR.rotation.y += 0.12 * idleWeight;
      rig.forearmR.rotation.x += (-0.24 - breath * 0.02) * idleWeight;

      // Soft athletic knees in snow
      rig.thighL.rotation.z += 0.02 * idleWeight;
      rig.thighL.rotation.x += -0.05 * idleWeight;
      rig.calfL.rotation.x += 0.1 * idleWeight;
      rig.footL.rotation.x += -0.05 * idleWeight;

      rig.thighR.rotation.z += -0.02 * idleWeight;
      rig.thighR.rotation.x += -0.065 * idleWeight;
      rig.calfR.rotation.x += 0.13 * idleWeight;
      rig.footR.rotation.x += -0.065 * idleWeight;

      // Standing Turn-in-Place footwork
      if (locomotionState === 'TURN') {
        this.turnInPlacePhase += dt * 7.5;
        const stepL = Math.max(0, Math.sin(this.turnInPlacePhase));
        const stepR = Math.max(0, Math.sin(this.turnInPlacePhase + Math.PI));

        rig.pelvis.position.y += (stepL + stepR) * 0.012 * idleWeight;
        rig.thighL.rotation.x += -stepL * 0.25 * idleWeight;
        rig.calfL.rotation.x += stepL * 0.48 * idleWeight;
        rig.thighL.rotation.y += turnInPlaceSign * stepL * 0.16 * idleWeight;

        rig.thighR.rotation.x += -stepR * 0.25 * idleWeight;
        rig.calfR.rotation.x += stepR * 0.48 * idleWeight;
        rig.thighR.rotation.y += turnInPlaceSign * stepR * 0.16 * idleWeight;

        rig.chest.rotation.y += turnInPlaceSign * 0.12 * idleWeight;
      }
    }

    // --- 2B. 2D Biomechanical Spline Blend Tree: Walk (0.3) -> Jog (0.6) -> Run (1.0) ---
    if (moveWeight > 0.001) {
      // Blend weights between Walk -> Jog -> Run
      const wJog = THREE.MathUtils.clamp((blendSpeed - 0.3) / 0.3, 0, 1);
      const wRun = THREE.MathUtils.clamp((blendSpeed - 0.6) / 0.38, 0, 1);
      const athletic = wJog * 0.46 + wRun * 0.54; // 0.0 = Walk, 0.46 = Jog, 1.0 = Run

      const strafeAbs = Math.abs(blendDirection);
      const fwdScale = Math.max(0.22, 1 - strafeAbs * 0.62);
      const isBackward = localForwardRatio < -0.18;

      const uL = this.cycleU;
      const uR = (this.cycleU + 0.5) % 1;

      const blend3Curves = (
        walkArr: readonly number[],
        jogArr: readonly number[],
        runArr: readonly number[],
        u: number
      ): number => {
        if (wRun <= 0.001) {
          const vWalk = sampleCyclicSpline(walkArr, u);
          if (wJog <= 0.001) return vWalk;
          const vJog = sampleCyclicSpline(jogArr, u);
          return THREE.MathUtils.lerp(vWalk, vJog, wJog);
        }
        const vJog = sampleCyclicSpline(jogArr, u);
        const vRun = sampleCyclicSpline(runArr, u);
        return THREE.MathUtils.lerp(vJog, vRun, wRun);
      };

      // Stance duty factor shrinks from Walk (0.48) -> Jog (0.36) -> Run (0.27 with true flight phase!)
      const stanceEnd = THREE.MathUtils.lerp(0.48, 0.27, athletic);
      const rawStanceL = computePhaseStanceWeight(uL, stanceEnd);
      const rawStanceR = computePhaseStanceWeight(uR, stanceEnd);
      this.stanceWeightL += rawStanceL * moveWeight;
      this.stanceWeightR += rawStanceR * moveWeight;

      // Fade out ankle slope flattening during late toe push-off so +28° plantarflexion stays crisp!
      const flatEnd = stanceEnd * 0.62;
      this.ankleSlopeWeightL += computePhaseStanceWeight(uL, flatEnd) * moveWeight;
      this.ankleSlopeWeightR += computePhaseStanceWeight(uR, flatEnd) * moveWeight;

      // 1) Pelvis Vertical Trajectory (Inverted pendulum in Walk -> Spring-mass flight bounce in Run)
      const pelvY = blend3Curves(WALK_PELVIS_Y, JOG_PELVIS_Y, RUN_PELVIS_Y, uL);
      rig.pelvis.position.y += pelvY * moveWeight;

      // Harmonic drive signal:
      // At uL = 0.25 (Left Leg extended BACK, Right Leg driving HIGH FORWARD): driveL = +1 (Left Arm Forward)
      // At uL = 0.75 (Left Leg driving HIGH FORWARD, Right Leg extended BACK): driveL = -1 (Right Arm Forward)
      const phase2Pi = uL * Math.PI * 2;
      const armDriveL = Math.sin(phase2Pi); // +1 when Right leg & Left arm are forward
      const armDriveR = -armDriveL; // +1 when Left leg & Right arm are forward

      // Pelvis Lateral Sway & Trendelenburg Hip Drop:
      // At uL = 0.125 (Left Mid-Stance), sin(phase2Pi + π/4) = +1 -> Left hip slightly higher (+z), body shifts slightly over left foot (+x)
      const stanceRollWave = Math.sin(phase2Pi + Math.PI * 0.25);
      const hipRollAmp = THREE.MathUtils.lerp(0.036, 0.068, athletic);
      rig.pelvis.rotation.z += stanceRollWave * hipRollAmp * moveWeight;
      rig.pelvis.position.x += stanceRollWave * THREE.MathUtils.lerp(0.02, 0.012, athletic) * moveWeight;

      // Pelvis Axial Yaw Twist (CORRECT RIGHT-HAND SIGN!):
      // Left hip (+X) rotates FORWARD (+Z) when pelvis.rotation.y < 0!
      // When armDriveR > 0 (Left leg forward), pelvis.rotation.y MUST be < 0 (-armDriveR)!
      const hipYawAmp = THREE.MathUtils.lerp(0.075, 0.155, athletic) * fwdScale;
      const strafeHipAngle = -blendDirection * 0.34 * (isBackward ? -1 : 1);
      const pelvisYaw = -armDriveR * hipYawAmp + strafeHipAngle;
      rig.pelvis.rotation.y += pelvisYaw * moveWeight;

      // Pelvis slight anterior tilt during athletic run
      const pelvisPitch = isBackward ? -0.04 : THREE.MathUtils.lerp(0.02, 0.09, athletic);
      rig.pelvis.rotation.x += pelvisPitch * moveWeight;

      // 2) Spine & Chest Athletic Forward Lean + True Counter-Rotation!
      // Total forward lean from vertical in Run ≈ pelvis(0.09) + spine(0.11) = 0.20 rad (~11.4° proud athletic lean, NOT hunched!)
      const spineLean = isBackward ? -0.05 : THREE.MathUtils.lerp(0.035, 0.115, athletic);
      const bouncePitch = Math.sin(phase2Pi * 2) * THREE.MathUtils.lerp(0.008, 0.022, athletic);
      rig.spineLower.rotation.x += spineLean * 0.45 * moveWeight;
      rig.spineUpper.rotation.x += spineLean * 0.35 * moveWeight;
      rig.chest.rotation.x += (spineLean * 0.2 + bouncePitch) * moveWeight;

      // Chest Counter-Rotation:
      // Since chest inherits pelvisYaw (-armDriveR * hipYawAmp), to achieve world chest yaw = +armDriveR * shoulderWorldAmp
      // (which brings Right Shoulder [-X] FORWARD when Right Arm & Left Leg are forward!),
      // local spine+chest yaw must overcome pelvisYaw AND add shoulderWorldAmp!
      const shoulderWorldAmp = THREE.MathUtils.lerp(0.075, 0.185, athletic) * fwdScale;
      const neededLocalTorsoYaw = armDriveR * (hipYawAmp + shoulderWorldAmp) - strafeHipAngle * 0.92;
      rig.spineLower.rotation.y += neededLocalTorsoYaw * 0.25 * moveWeight;
      rig.spineUpper.rotation.y += neededLocalTorsoYaw * 0.35 * moveWeight;
      rig.chest.rotation.y += neededLocalTorsoYaw * 0.4 * moveWeight;

      // Counter-roll shoulders opposite to pelvis roll so head stays centered
      rig.spineUpper.rotation.z += -stanceRollWave * hipRollAmp * 0.45 * moveWeight;
      rig.chest.rotation.z += -stanceRollWave * hipRollAmp * 0.5 * moveWeight;

      // Stabilize Head on Target Horizon (cancels torso pitch & yaw twist!)
      const totalForwardPitch = pelvisPitch + spineLean;
      rig.neck.rotation.x += -totalForwardPitch * 0.45 * moveWeight;
      rig.head.rotation.x += (-totalForwardPitch * 0.48 - bouncePitch * 0.6) * moveWeight;
      rig.head.rotation.y += (-armDriveR * shoulderWorldAmp * 0.78) * moveWeight;

      // 3) Biomechanical Left & Right Leg Evaluation
      const evalLeg = (
        thigh: THREE.Group,
        calf: THREE.Group,
        foot: THREE.Group,
        uLeg: number,
        isLeft: boolean
      ) => {
        const signSide = isLeft ? 1 : -1;
        // If moving backward, sample time-reversed gait curve with slightly softer extension
        const sampleU = isBackward ? (1 - uLeg) % 1 : uLeg;
        const rawThighX = blend3Curves(WALK_THIGH_X, JOG_THIGH_X, RUN_THIGH_X, sampleU);
        const rawCalfX = blend3Curves(WALK_CALF_X, JOG_CALF_X, RUN_CALF_X, sampleU);
        const rawFootX = blend3Curves(WALK_FOOT_X, JOG_FOOT_X, RUN_FOOT_X, sampleU);

        const backwardScale = isBackward ? 0.72 : 1.0;
        thigh.rotation.x += rawThighX * fwdScale * backwardScale * moveWeight;
        calf.rotation.x += rawCalfX * (0.75 + 0.25 * fwdScale) * moveWeight;
        foot.rotation.x += rawFootX * backwardScale * moveWeight;

        // Athletic Midline Foot Tracking:
        // In human running, thighs adduct ~2.3° inward toward body centerline so boots track cleanly under CoM
        // instead of waddling wide apart like a robot!
        const midlineAdduction = -signSide * THREE.MathUtils.lerp(0.015, 0.042, athletic) * (1 - strafeAbs);
        thigh.rotation.z += midlineAdduction * moveWeight;
        foot.rotation.z += -midlineAdduction * 0.75 * moveWeight;

        // Lateral Strafe Abduction/Adduction when strafing left/right
        if (strafeAbs > 0.02) {
          const swingWave = Math.sin(uLeg * Math.PI * 2);
          const strafeStepZ = -swingWave * 0.34 * blendDirection;
          const wideBaseZ = signSide * 0.055 * strafeAbs;
          thigh.rotation.z += (strafeStepZ + wideBaseZ) * strafeAbs * moveWeight;
          foot.rotation.z += -strafeStepZ * 0.45 * strafeAbs * moveWeight;
        }
      };

      evalLeg(rig.thighL, rig.calfL, rig.footL, uL, true);
      evalLeg(rig.thighR, rig.calfR, rig.footR, uR, false);

      // 4) Athletic Sprinter/Runner Arm Pump ('ZXY' order: z=Abduction, x=Fwd/Back Swing, y=Inward Sternum Turn)
      const evalArm = (
        clavicle: THREE.Group,
        upperArm: THREE.Group,
        forearm: THREE.Group,
        hand: THREE.Group,
        drive: number, // +1 = Peak Forward Upswing, -1 = Peak Backward Hip-Pocket Drive
        isLeft: boolean
      ) => {
        const signSide = isLeft ? 1 : -1;
        // Clavicle protraction/retraction (CORRECT SIGN: Left clavicle [+X] moves +Z when y < 0; Right [-X] moves +Z when y > 0)
        clavicle.rotation.y += -signSide * drive * THREE.MathUtils.lerp(0.05, 0.13, athletic) * moveWeight;

        // Asymmetric sagittal swing: vigorous forward upswing & crisp backward elbow drive past hip
        const fwdAmp = THREE.MathUtils.lerp(0.32, 0.76, athletic);
        const backAmp = THREE.MathUtils.lerp(0.26, 0.66, athletic);
        const swingX = drive >= 0 ? -drive * fwdAmp : -drive * backAmp;
        upperArm.rotation.x += (swingX + THREE.MathUtils.lerp(0.04, 0.08, athletic)) * moveWeight;

        // Outward elbow clearance (z) + Dynamic cross-body inward angle (y) on forward upswing!
        // ("Cheek-to-hip-pocket": hand angles ~22° inward toward chest centerline on upswing, straightens on backswing)
        const baseAbduct = signSide * THREE.MathUtils.lerp(0.11, 0.21, athletic);
        const swingFlare = signSide * Math.max(0, -drive) * THREE.MathUtils.lerp(0.02, 0.08, athletic);
        upperArm.rotation.z += (baseAbduct + swingFlare + signSide * strafeAbs * 0.06) * moveWeight;

        const crossBodyInward =
          -signSide *
          (THREE.MathUtils.lerp(0.12, 0.34, athletic) +
            Math.max(0, drive) * THREE.MathUtils.lerp(0.05, 0.22, athletic));
        upperArm.rotation.y += crossBodyInward * moveWeight;

        // Dynamic Elbow Flexion:
        // Walk: soft ~20°-34° bend; Run: compact ~85°-110° bend (tighter on upswing, opens slightly pushing back!)
        const baseElbow = THREE.MathUtils.lerp(-0.36, -1.48, athletic);
        const upswingFold = -Math.max(0, drive) * THREE.MathUtils.lerp(0.14, 0.38, athletic);
        const backOpen = Math.max(0, -drive) * THREE.MathUtils.lerp(0.08, 0.24, athletic);
        forearm.rotation.x += (baseElbow + upswingFold + backOpen) * moveWeight;

        // Subtle athletic neutral fist/mitten alignment
        hand.rotation.x += THREE.MathUtils.lerp(-0.04, -0.1, athletic) * moveWeight;
      };

      evalArm(rig.clavicleL, rig.upperArmL, rig.forearmL, rig.handL, armDriveL, true);
      evalArm(rig.clavicleR, rig.upperArmR, rig.forearmR, rig.handR, armDriveR, false);
    }

    // --- 2C. Stopping Momentum Surge & Recovery (STOP State) ---
    if (locomotionState === 'STOP') {
      const surge = Math.sin(stopProgress * Math.PI);
      rig.pelvis.position.y -= surge * 0.068;
      rig.pelvis.position.z += surge * 0.045;

      rig.spineLower.rotation.x += surge * 0.13;
      rig.spineUpper.rotation.x += surge * 0.11;
      rig.chest.rotation.x += surge * 0.09;
      rig.head.rotation.x -= surge * 0.18;

      rig.thighL.rotation.x -= surge * 0.3;
      rig.calfL.rotation.x += surge * 0.48;
      rig.thighR.rotation.x += surge * 0.14;
      rig.calfR.rotation.x += surge * 0.28;

      rig.upperArmL.rotation.z += surge * 0.24;
      rig.upperArmL.rotation.x -= surge * 0.18;
      rig.upperArmR.rotation.z -= surge * 0.24;
      rig.upperArmR.rotation.x += surge * 0.16;
    }

    // --- 2D. Sharp Turn Foot Plant, Body Bank & Shoulder Lead (SHARP_TURN State) ---
    if (locomotionState === 'SHARP_TURN' && sharpTurnTimer > 0) {
      const p = Math.sin((sharpTurnTimer / 0.36) * Math.PI);
      rig.pelvis.position.y -= p * 0.085;
      rig.pelvis.rotation.z += -sharpTurnSign * p * 0.18;
      rig.spineLower.rotation.z += -sharpTurnSign * p * 0.14;
      rig.spineUpper.rotation.y += sharpTurnSign * p * 0.28;
      rig.chest.rotation.y += sharpTurnSign * p * 0.34;
      rig.head.rotation.y += sharpTurnSign * p * 0.22;

      rig.thighL.rotation.z += p * 0.18;
      rig.thighR.rotation.z -= p * 0.18;
      rig.calfL.rotation.x += p * 0.38;
      rig.calfR.rotation.x += p * 0.38;

      rig.upperArmL.rotation.z += p * 0.3;
      rig.upperArmR.rotation.z -= p * 0.3;
    }

    // --- 2E. Joyful Stumble JUMP, Superman BELLY-DIVE & Bonked STUMBLE Poses! ---
    if (locomotionState === 'JUMP') {
      this.stanceWeightL = 0;
      this.stanceWeightR = 0;
      this.ankleSlopeWeightL = 0;
      this.ankleSlopeWeightR = 0;

      // Bouncy tucked knees & cheerful raised Stumble arms!
      rig.thighL.rotation.x = -0.65;
      rig.calfL.rotation.x = 1.25;
      rig.footL.rotation.x = 0.25;

      rig.thighR.rotation.x = -0.35;
      rig.calfR.rotation.x = 1.15;
      rig.footR.rotation.x = 0.3;

      rig.upperArmL.rotation.z = 0.95;
      rig.upperArmL.rotation.x = -0.45;
      rig.forearmL.rotation.x = -0.65;

      rig.upperArmR.rotation.z = -0.95;
      rig.upperArmR.rotation.x = -0.45;
      rig.forearmR.rotation.x = -0.65;
    } else if (locomotionState === 'DIVE') {
      this.stanceWeightL = 0;
      this.stanceWeightR = 0;
      this.ankleSlopeWeightL = 0;
      this.ankleSlopeWeightR = 0;

      // Iconic Stumble Guys Horizontal Superman Belly-Dive!
      rig.pelvis.position.y = 0.28;
      rig.pelvis.rotation.x = 1.32; // Tilted ~76° forward!
      rig.spineUpper.rotation.x = -0.15;
      rig.head.rotation.x = -0.85; // Looking ahead while diving!

      rig.thighL.rotation.x = 0.22;
      rig.calfL.rotation.x = 0.45;
      rig.thighR.rotation.x = 0.22;
      rig.calfR.rotation.x = 0.45;

      rig.upperArmL.rotation.z = 0.45;
      rig.upperArmL.rotation.x = -2.35; // Arms stretched superman-style ahead!
      rig.forearmL.rotation.x = -0.2;

      rig.upperArmR.rotation.z = -0.45;
      rig.upperArmR.rotation.x = -2.35;
      rig.forearmR.rotation.x = -0.2;
    } else if (locomotionState === 'STUMBLE') {
      this.stanceWeightL = 0.25;
      this.stanceWeightR = 0.25;
      const flail = Math.sin(this.idleTime * 24);
      rig.pelvis.rotation.x = -0.28;
      rig.pelvis.rotation.z = flail * 0.25;
      rig.chest.rotation.x = -0.22;
      rig.upperArmL.rotation.z = 1.25 + flail * 0.35;
      rig.upperArmR.rotation.z = -1.25 - flail * 0.35;
      rig.thighL.rotation.x = -0.35 + flail * 0.4;
      rig.thighR.rotation.x = -0.35 - flail * 0.4;
    }

    // =========================================================================
    // 3. FULL-BODY SNOWBALL PICKUP LAYER (Calibrated for Stumble Proportions)
    // =========================================================================
    if (isPickingUp) {
      let bendW = 0;
      if (pickupProgress < 0.45) {
        bendW = THREE.MathUtils.smoothstep(pickupProgress, 0.0, 0.42);
      } else {
        bendW = 1 - THREE.MathUtils.smoothstep(pickupProgress, 0.48, 0.96);
      }

      rig.pelvis.position.y -= bendW * 0.175;
      rig.pelvis.rotation.x += bendW * 0.26;
      rig.pelvis.rotation.y -= bendW * 0.18;

      rig.thighL.rotation.x -= bendW * 0.68;
      rig.calfL.rotation.x += bendW * 1.24;
      rig.footL.rotation.x -= bendW * 0.48;

      rig.thighR.rotation.x -= bendW * 0.82;
      rig.calfR.rotation.x += bendW * 1.36;
      rig.footR.rotation.x -= bendW * 0.52;

      rig.spineLower.rotation.x += bendW * 0.34;
      rig.spineUpper.rotation.x += bendW * 0.36;
      rig.chest.rotation.x += bendW * 0.32;

      rig.spineUpper.rotation.y -= bendW * 0.16;
      rig.chest.rotation.y -= bendW * 0.22;
      rig.clavicleR.rotation.y += bendW * 0.26;
      rig.clavicleR.rotation.z -= bendW * 0.18;

      rig.head.rotation.x -= bendW * 0.42;
    }

    // =========================================================================
    // 4. DYNAMIC SNOWBALL HOLD LAYER (Cradles snowball naturally; still pumps rhythmically when running!)
    // =========================================================================
    const targetHoldWeight =
      hasSnowball && !isPickingUp && throwPhase === 'NONE' ? 0.88 : 0.0;
    this.smoothHoldWeight = THREE.MathUtils.lerp(
      this.smoothHoldWeight,
      targetHoldWeight,
      1 - Math.exp(-14 * dt)
    );

    if (this.smoothHoldWeight > 0.005) {
      const hw = this.smoothHoldWeight;
      const runCarry = THREE.MathUtils.clamp((blendSpeed - 0.35) / 0.65, 0, 1);
      // Preserve ~52% of natural right-arm stride pump while running so character never looks stiff/one-armed!
      const dynamicBlend = hw * (1 - runCarry * 0.48);
      const runPumpWave = -Math.sin(this.cycleU * Math.PI * 2) * 0.26 * moveWeight;

      rig.clavicleR.rotation.y = THREE.MathUtils.lerp(rig.clavicleR.rotation.y, 0.16, dynamicBlend);
      rig.upperArmR.rotation.z = THREE.MathUtils.lerp(rig.upperArmR.rotation.z, -0.22, dynamicBlend);
      rig.upperArmR.rotation.x = THREE.MathUtils.lerp(
        rig.upperArmR.rotation.x,
        -0.36 - runPumpWave,
        dynamicBlend
      );
      rig.upperArmR.rotation.y = THREE.MathUtils.lerp(rig.upperArmR.rotation.y, 0.34, dynamicBlend);

      rig.forearmR.rotation.x = THREE.MathUtils.lerp(
        rig.forearmR.rotation.x,
        -1.42 - Math.max(0, runPumpWave) * 0.35,
        hw
      );

      // Cup right mitten upward so snowball sits securely in palm
      rig.handR.rotation.y = THREE.MathUtils.lerp(rig.handR.rotation.y, -0.32, hw);
      rig.handR.rotation.x = THREE.MathUtils.lerp(rig.handR.rotation.x, -0.18, hw);
    }

    // =========================================================================
    // 5. FULL-BODY OVERHAND KINETIC CHAIN THROW LAYER
    //    Feet/Stride -> Pelvis Whip -> Hip-Shoulder Separation -> High-3/4 Elbow Lead
    //    -> Humeral Layback & Internal Rotation Snap -> Diagonal Cross-Body Follow-Through
    // =========================================================================
    if (throwPhase !== 'NONE') {
      // Lower-body stride/coil applies strongly when standing, tapering smoothly when running
      const standFactor = 1 - THREE.MathUtils.clamp(blendSpeed / 0.38, 0, 0.88);
      let upperOverride = 1.0;

      // Pelvis & Lower-Body Stride accumulators
      let pelvisShiftZ = 0;
      let pelvisShiftX = 0;
      let pelvisDropY = 0;
      let pelvisYaw = 0;

      let lThighX = -0.12;
      let lThighZ = 0.04;
      let lCalfX = 0.24;
      let lFootX = -0.06;

      let rThighX = -0.1;
      let rThighZ = -0.04;
      let rCalfX = 0.24;
      let rFootX = -0.06;

      // Spine & Chest Kinetic Coil accumulators (relative to pelvis!)
      let spinePitch = 0;
      let torsoRelYaw = 0; // <0 coils right shoulder BACK; >0 whips right shoulder FORWARD!
      let torsoTiltZ = 0; // <0 contralateral tilt to left so throwing shoulder comes high over the top!

      // Right Throwing Arm ('ZXY' on upperArmR: z=AbductionSlot, x=HorizDrive, y=HumeralExtIntRot)
      let rClavY = 0;
      let rClavZ = 0;
      let rArmZ = -0.15;
      let rArmX = 0;
      let rArmY = 0;
      let rForearmX = -0.3;
      let rWristX = 0;
      let rWristY = 0;

      // Left Lead / Counterbalance Arm ('ZXY' on upperArmL)
      let lClavY = 0;
      let lArmZ = 0.15;
      let lArmX = 0;
      let lArmY = 0;
      let lForearmX = -0.3;

      const powerBoost = 1 + chargeRatio * 0.26;

      if (throwPhase === 'ANTICIPATION') {
        // PHASE A — FULL ATHLETIC WINDUP & COIL:
        // Body turns sideways (~68° closed), weight loads onto bent rear right leg,
        // front left leg cocks ready to stride, left hand sights target,
        // right arm raises into 90/90 L-cocking slot with snowball high behind right ear!
        const w = THREE.MathUtils.smoothstep(throwPhaseProgress, 0, 1);
        const tremor = chargeRatio > 0.82 ? Math.sin(this.idleTime * 30) * 0.014 : 0;

        pelvisDropY = -0.065 * w * powerBoost;
        pelvisShiftZ = -0.095 * w * powerBoost; // Load weight back onto rear right leg!
        pelvisShiftX = -0.035 * w;
        pelvisYaw = -0.58 * w * powerBoost; // Closed hips (-33°.. -42°)

        // Loaded Rear Right Leg + Cocked Front Left Stride Leg
        rThighX = 0.16 * w;
        rThighZ = -0.08 * w;
        rCalfX = (0.12 + 0.56 * w) * powerBoost;
        rFootX = -0.18 * w;

        lThighX = (-0.06 - 0.46 * w) * powerBoost; // Left knee lifts slightly ready to step into throw!
        lThighZ = -0.06 * w;
        lCalfX = 0.12 + 0.68 * w;
        lFootX = 0.08 * w;

        // Deep Spine & Shoulder Coil behind hips (Hip-Shoulder Separation!)
        spinePitch = -0.13 * w * powerBoost;
        torsoRelYaw = -0.62 * w * powerBoost + tremor; // Total chest yaw ≈ -1.20 rad (-69° sideways!)
        torsoTiltZ = 0.12 * w; // Slight load tilt toward rear leg

        // Right Throwing Arm: High 80° Shoulder Slot + External Rotation behind ear!
        rClavY = -0.36 * w; // Retract right shoulder blade back
        rClavZ = -0.1 * w;
        rArmZ = THREE.MathUtils.lerp(-0.18, -1.38, w); // Abduct elbow up to shoulder height (~79°)
        rArmX = 0.36 * w * powerBoost; // Pull elbow horizontally back behind torso plane
        rArmY = THREE.MathUtils.lerp(0.2, -1.82 - chargeRatio * 0.24, w); // Cock forearm UP & BACK behind ear!
        rForearmX = THREE.MathUtils.lerp(-1.35, -1.72, w); // Tight ~98° cocked elbow
        rWristX = -0.36 * w; // Wrist cocked back
        rWristY = -0.25 * w;

        // Left Lead Arm: Reaches forward over front hip pointing/sighting at target!
        lClavY = -0.28 * w; // Protract left shoulder toward target
        lArmZ = THREE.MathUtils.lerp(0.14, 0.58, w);
        lArmX = THREE.MathUtils.lerp(0.04, -0.92, w);
        lArmY = -0.32 * w;
        lForearmX = THREE.MathUtils.lerp(-0.28, -0.62, w);
      } else if (throwPhase === 'ACCELERATION') {
        // PHASE B — EXPLOSIVE SEQUENTIAL KINETIC CHAIN WHIP (t: 0.0 -> 1.0 = THROW_RELEASE):
        // 1) Stride foot plants & Hips snap open FIRST (hipT: 0.00 -> 0.54)
        // 2) Torso uncoils & tilts contralaterally left while arm hits MAX LAYBACK (torsoT: 0.10 -> 0.82)
        // 3) Right Elbow drives forward ahead of hand (armT: 0.22 -> 0.94)
        // 4) Forearm whips open + Wrist snaps through release point (snapT: 0.46 -> 1.00)
        const t = THREE.MathUtils.clamp(throwPhaseProgress, 0, 1);

        const hipT = THREE.MathUtils.smoothstep(t, 0.0, 0.54);
        const torsoT = THREE.MathUtils.smoothstep(t, 0.1, 0.82);
        const armT = THREE.MathUtils.smoothstep(t, 0.22, 0.94);
        const snapT = THREE.MathUtils.smoothstep(t, 0.46, 1.0);

        pelvisDropY = THREE.MathUtils.lerp(-0.065 * powerBoost, -0.05, hipT);
        pelvisShiftZ = THREE.MathUtils.lerp(-0.095 * powerBoost, 0.11, hipT); // Surge forward onto front leg!
        pelvisShiftX = THREE.MathUtils.lerp(-0.035, 0.02, hipT);
        pelvisYaw = THREE.MathUtils.lerp(-0.58 * powerBoost, 0.28, hipT); // Hips fire OPEN toward target!

        // Rear Right Leg drives off on toes; Front Left Leg plants & braces!
        rThighX = THREE.MathUtils.lerp(0.16, 0.54, hipT);
        rThighZ = -0.06;
        rCalfX = THREE.MathUtils.lerp(0.68 * powerBoost, 0.26, hipT);
        rFootX = THREE.MathUtils.lerp(-0.18, 0.48, hipT); // Explosive rear-toe push-off!

        lThighX = THREE.MathUtils.lerp(-0.52 * powerBoost, -0.44, hipT);
        lThighZ = THREE.MathUtils.lerp(-0.06, 0.05, hipT);
        lCalfX = THREE.MathUtils.lerp(0.8, 0.56, hipT);
        lFootX = THREE.MathUtils.lerp(0.08, -0.1, hipT);

        // Torso uncoils + athletic contralateral left tilt (-0.22 rad) bringing right shoulder high over the top!
        spinePitch = THREE.MathUtils.lerp(-0.13 * powerBoost, 0.24, torsoT);
        torsoRelYaw = THREE.MathUtils.lerp(-0.62 * powerBoost, 0.44, torsoT);
        torsoTiltZ = THREE.MathUtils.lerp(0.12, -0.22, torsoT);

        // Right Arm Whip:
        // Notice external layback peaks around t=0.28 (-2.18 rad!) as chest fires forward while hand lags behind!
        const laybackDip = Math.sin(THREE.MathUtils.clamp(t / 0.55, 0, 1) * Math.PI) * -0.28;
        rClavY = THREE.MathUtils.lerp(-0.36, 0.48, armT); // Protract shoulder powerfully forward
        rClavZ = THREE.MathUtils.lerp(-0.1, -0.16, armT);
        rArmZ = THREE.MathUtils.lerp(-1.38, -1.08, armT); // High-3/4 overhand release slot!
        rArmX = THREE.MathUtils.lerp(0.36 * powerBoost, -0.78, armT); // Elbow whips forward in front of chest
        rArmY = THREE.MathUtils.lerp(-1.82 - chargeRatio * 0.24, -0.55, snapT) + laybackDip;
        rForearmX = THREE.MathUtils.lerp(-1.72, -0.24, snapT); // Forearm extends rapidly into release!
        rWristX = THREE.MathUtils.lerp(-0.36, 0.62, snapT); // Crisp downward/forward wrist snap at release!
        rWristY = THREE.MathUtils.lerp(-0.25, 0.15, snapT);

        // Left Glove Tuck: pulls tightly into left ribs to accelerate torso rotation!
        lClavY = THREE.MathUtils.lerp(-0.28, 0.22, torsoT);
        lArmZ = THREE.MathUtils.lerp(0.58, 0.22, torsoT);
        lArmX = THREE.MathUtils.lerp(-0.92, 0.28, torsoT);
        lArmY = THREE.MathUtils.lerp(-0.32, -0.45, torsoT);
        lForearmX = THREE.MathUtils.lerp(-0.62, -1.58, torsoT);
      } else if (throwPhase === 'FOLLOW_THROUGH') {
        // PHASE D — FULL DIAGONAL CROSS-BODY FOLLOW-THROUGH & REAR-LEG COUNTERBALANCE:
        // Right arm sweeps continuously from high release slot diagonally across chest down past left hip!
        const t = THREE.MathUtils.smoothstep(throwPhaseProgress, 0, 1);
        const decelCurve = 1 - Math.pow(1 - throwPhaseProgress, 2.4); // Fast initial carry, smooth cushioned settle

        pelvisDropY = THREE.MathUtils.lerp(-0.05, -0.085, t);
        pelvisShiftZ = THREE.MathUtils.lerp(0.11, 0.16, t);
        pelvisShiftX = THREE.MathUtils.lerp(0.02, 0.04, t);
        pelvisYaw = THREE.MathUtils.lerp(0.28, 0.42, decelCurve);

        // Braced Front Left Leg + Athletic Rear Right Leg Counterbalance Lift!
        lThighX = THREE.MathUtils.lerp(-0.44, -0.56, t);
        lThighZ = 0.05;
        lCalfX = THREE.MathUtils.lerp(0.56, 0.82, t);
        lFootX = -0.14;

        rThighX = THREE.MathUtils.lerp(0.54, 0.72 * powerBoost, decelCurve); // Rear leg extends/lifts behind for balance!
        rThighZ = -0.06;
        rCalfX = THREE.MathUtils.lerp(0.26, 0.74, decelCurve);
        rFootX = THREE.MathUtils.lerp(0.48, 0.32, t);

        // Torso flexes forward over front thigh & completes follow-through rotation
        spinePitch = THREE.MathUtils.lerp(0.24, 0.44, decelCurve);
        torsoRelYaw = THREE.MathUtils.lerp(0.44, 0.68, decelCurve);
        torsoTiltZ = THREE.MathUtils.lerp(-0.22, -0.26, t);

        // Continuous Diagonal Arm Sweep across chest to left hip (z goes from -1.08 out right -> +0.38 across left!)
        rClavY = THREE.MathUtils.lerp(0.48, 0.82, decelCurve);
        rClavZ = THREE.MathUtils.lerp(-0.16, 0.12, decelCurve);
        rArmZ = THREE.MathUtils.lerp(-1.08, 0.38, decelCurve); // Sweeps cleanly across chest!
        rArmX = THREE.MathUtils.lerp(-0.78, -0.84, decelCurve);
        rArmY = THREE.MathUtils.lerp(-0.55, 0.72, decelCurve); // Natural forearm pronation!
        rForearmX = THREE.MathUtils.lerp(-0.24, -0.82, decelCurve);
        rWristX = THREE.MathUtils.lerp(0.62, 0.32, t);
        rWristY = 0.15;

        // Left arm extends slightly back-left for counterbalance
        lClavY = THREE.MathUtils.lerp(0.22, 0.34, t);
        lArmZ = THREE.MathUtils.lerp(0.22, 0.34, t);
        lArmX = THREE.MathUtils.lerp(0.28, 0.48, t);
        lArmY = -0.35;
        lForearmX = THREE.MathUtils.lerp(-1.58, -1.18, t);
      } else if (throwPhase === 'RECOVERY') {
        // PHASE E — SMOOTH RECOVERY BACK TO LOCOMOTION / IDLE
        const rec = 1 - THREE.MathUtils.smoothstep(throwPhaseProgress, 0, 1);
        upperOverride = rec;

        pelvisDropY = -0.085 * rec;
        pelvisShiftZ = 0.16 * rec;
        pelvisShiftX = 0.04 * rec;
        pelvisYaw = 0.42 * rec;

        lThighX = -0.56 * rec;
        lThighZ = 0.05 * rec;
        lCalfX = 0.82 * rec;
        lFootX = -0.14 * rec;

        rThighX = 0.72 * powerBoost * rec;
        rThighZ = -0.06 * rec;
        rCalfX = 0.74 * rec;
        rFootX = 0.32 * rec;

        spinePitch = 0.44 * rec;
        torsoRelYaw = 0.68 * rec;
        torsoTiltZ = -0.26 * rec;

        rClavY = 0.82 * rec;
        rClavZ = 0.12 * rec;
        rArmZ = 0.38 * rec;
        rArmX = -0.84 * rec;
        rArmY = 0.72 * rec;
        rForearmX = -0.82 * rec;
        rWristX = 0.32 * rec;
        rWristY = 0.15 * rec;

        lClavY = 0.34 * rec;
        lArmZ = 0.34 * rec;
        lArmX = 0.48 * rec;
        lArmY = -0.35 * rec;
        lForearmX = -1.18 * rec;
      }

      // 1) Blend Standing Stride & Weight Shift onto Lower Body (preserves locomotion when running!)
      const lowerWeight = standFactor * upperOverride;
      rig.pelvis.position.y += pelvisDropY * standFactor;
      rig.pelvis.position.z += pelvisShiftZ * standFactor;
      rig.pelvis.position.x += pelvisShiftX * standFactor;
      rig.pelvis.rotation.y += pelvisYaw * (0.35 + 0.65 * standFactor);

      if (lowerWeight > 0.01) {
        rig.thighL.rotation.x = THREE.MathUtils.lerp(rig.thighL.rotation.x, lThighX, lowerWeight);
        rig.thighL.rotation.z = THREE.MathUtils.lerp(rig.thighL.rotation.z, lThighZ, lowerWeight);
        rig.calfL.rotation.x = THREE.MathUtils.lerp(rig.calfL.rotation.x, lCalfX, lowerWeight);
        rig.footL.rotation.x = THREE.MathUtils.lerp(rig.footL.rotation.x, lFootX, lowerWeight);

        rig.thighR.rotation.x = THREE.MathUtils.lerp(rig.thighR.rotation.x, rThighX, lowerWeight);
        rig.thighR.rotation.z = THREE.MathUtils.lerp(rig.thighR.rotation.z, rThighZ, lowerWeight);
        rig.calfR.rotation.x = THREE.MathUtils.lerp(rig.calfR.rotation.x, rCalfX, lowerWeight);
        rig.footR.rotation.x = THREE.MathUtils.lerp(rig.footR.rotation.x, rFootX, lowerWeight);

        // Release Foot IK on rear kicking foot during explosive follow-through counterbalance!
        if (throwPhase === 'FOLLOW_THROUGH' || throwPhase === 'RECOVERY') {
          this.stanceWeightR *= 1 - lowerWeight * 0.85;
          this.ankleSlopeWeightR *= 1 - lowerWeight;
        }
        // Release Foot IK on cocked front stride foot during anticipation lift!
        if (throwPhase === 'ANTICIPATION') {
          this.stanceWeightL *= 1 - lowerWeight * 0.65;
        }
      }

      // 2) Apply Upper-Body Kinetic Chain Override cleanly across Spine, Chest, Shoulders, Arms, Wrist
      rig.spineLower.rotation.x = THREE.MathUtils.lerp(
        rig.spineLower.rotation.x,
        spinePitch * 0.3,
        upperOverride
      );
      rig.spineUpper.rotation.x = THREE.MathUtils.lerp(
        rig.spineUpper.rotation.x,
        spinePitch * 0.35,
        upperOverride
      );
      rig.chest.rotation.x = THREE.MathUtils.lerp(
        rig.chest.rotation.x,
        spinePitch * 0.35,
        upperOverride
      );

      rig.spineLower.rotation.y = THREE.MathUtils.lerp(
        rig.spineLower.rotation.y,
        torsoRelYaw * 0.28,
        upperOverride
      );
      rig.spineUpper.rotation.y = THREE.MathUtils.lerp(
        rig.spineUpper.rotation.y,
        torsoRelYaw * 0.34,
        upperOverride
      );
      rig.chest.rotation.y = THREE.MathUtils.lerp(
        rig.chest.rotation.y,
        torsoRelYaw * 0.38,
        upperOverride
      );

      rig.spineUpper.rotation.z = THREE.MathUtils.lerp(
        rig.spineUpper.rotation.z,
        torsoTiltZ * 0.45,
        upperOverride
      );
      rig.chest.rotation.z = THREE.MathUtils.lerp(
        rig.chest.rotation.z,
        torsoTiltZ * 0.55,
        upperOverride
      );

      // Head Counter-Tracking: keeps eyes locked onto target despite heavy hip + chest coil!
      const totalBodyYaw = pelvisYaw * (0.35 + 0.65 * standFactor) + torsoRelYaw;
      rig.neck.rotation.y = THREE.MathUtils.lerp(
        rig.neck.rotation.y,
        -totalBodyYaw * 0.38,
        upperOverride
      );
      rig.head.rotation.y = THREE.MathUtils.lerp(
        rig.head.rotation.y,
        -totalBodyYaw * 0.56,
        upperOverride
      );
      rig.neck.rotation.x = THREE.MathUtils.lerp(
        rig.neck.rotation.x,
        -spinePitch * 0.35,
        upperOverride
      );
      rig.head.rotation.x = THREE.MathUtils.lerp(
        rig.head.rotation.x,
        -spinePitch * 0.52,
        upperOverride
      );
      rig.head.rotation.z = THREE.MathUtils.lerp(
        rig.head.rotation.z,
        -torsoTiltZ * 0.65,
        upperOverride
      );

      // Right Throwing Arm
      rig.clavicleR.rotation.y = THREE.MathUtils.lerp(rig.clavicleR.rotation.y, rClavY, upperOverride);
      rig.clavicleR.rotation.z = THREE.MathUtils.lerp(rig.clavicleR.rotation.z, rClavZ, upperOverride);
      rig.upperArmR.rotation.z = THREE.MathUtils.lerp(rig.upperArmR.rotation.z, rArmZ, upperOverride);
      rig.upperArmR.rotation.x = THREE.MathUtils.lerp(rig.upperArmR.rotation.x, rArmX, upperOverride);
      rig.upperArmR.rotation.y = THREE.MathUtils.lerp(rig.upperArmR.rotation.y, rArmY, upperOverride);
      rig.forearmR.rotation.x = THREE.MathUtils.lerp(rig.forearmR.rotation.x, rForearmX, upperOverride);
      rig.handR.rotation.x = THREE.MathUtils.lerp(rig.handR.rotation.x, rWristX, upperOverride);
      rig.handR.rotation.y = THREE.MathUtils.lerp(rig.handR.rotation.y, rWristY, upperOverride);

      // Left Lead / Balance Arm
      rig.clavicleL.rotation.y = THREE.MathUtils.lerp(rig.clavicleL.rotation.y, lClavY, upperOverride);
      rig.upperArmL.rotation.z = THREE.MathUtils.lerp(rig.upperArmL.rotation.z, lArmZ, upperOverride);
      rig.upperArmL.rotation.x = THREE.MathUtils.lerp(rig.upperArmL.rotation.x, lArmX, upperOverride);
      rig.upperArmL.rotation.y = THREE.MathUtils.lerp(rig.upperArmL.rotation.y, lArmY, upperOverride);
      rig.forearmL.rotation.x = THREE.MathUtils.lerp(rig.forearmL.rotation.x, lForearmX, upperOverride);
    }

    // =========================================================================
    // 6. ADDITIVE AIMING LAYER (Distributes camera elevation & azimuth naturally across spine & shoulder)
    // =========================================================================
    if (this.crouchAmount > 0.003) {
      const c = this.crouchAmount;
      rig.pelvis.position.y -= 0.11 * c;
      rig.pelvis.rotation.x += 0.12 * c;
      rig.thighL.rotation.x -= 0.85 * c;
      rig.thighR.rotation.x -= 0.85 * c;
      rig.calfL.rotation.x += 1.55 * c;
      rig.calfR.rotation.x += 1.55 * c;
      rig.footL.rotation.x -= 0.7 * c;
      rig.footR.rotation.x -= 0.7 * c;
      rig.spineLower.rotation.x += 0.16 * c;
      rig.spineUpper.rotation.x += 0.1 * c;
      rig.head.rotation.x -= 0.2 * c;
    }

    const wantsAimLayer =
      !isPickingUp && (isAiming || throwPhase !== 'NONE' || upperState === 'SNOWBALL_HOLD');
    const targetAimWeight = wantsAimLayer ? (isAiming || throwPhase !== 'NONE' ? 1.0 : 0.32) : 0.0;
    this.smoothAimLayerWeight = THREE.MathUtils.lerp(
      this.smoothAimLayerWeight,
      targetAimWeight,
      1 - Math.exp(-12 * dt)
    );

    if (this.smoothAimLayerWeight > 0.005) {
      const aw = this.smoothAimLayerWeight;
      const additivePitch = -aimPitch * aw;
      const additiveYaw = aimYawOffset * aw;

      rig.spineLower.rotation.x += additivePitch * 0.2;
      rig.spineUpper.rotation.x += additivePitch * 0.28;
      rig.chest.rotation.x += additivePitch * 0.32;
      rig.head.rotation.x += additivePitch * 0.2;

      rig.spineLower.rotation.y += additiveYaw * 0.22;
      rig.spineUpper.rotation.y += additiveYaw * 0.3;
      rig.chest.rotation.y += additiveYaw * 0.32;
      rig.head.rotation.y += additiveYaw * 0.16;

      if (isAiming || throwPhase !== 'NONE') {
        rig.clavicleR.rotation.z += -aimPitch * 0.22 * aw;
      }
    }

    // =========================================================================
    // 7. PROCEDURAL VELOCITY, ACCELERATION, BRAKING & STRAFE LEAN LAYER
    // =========================================================================
    const leanScale = config.bodyLeanAmount;
    const targetPitchLean = THREE.MathUtils.clamp(localAccelForward * 0.014, -0.14, 0.15) * leanScale;

    const turnBank = -angularVelocityYaw * speed * 0.018;
    const strafeCounterBalance = -localAccelRight * 0.01;
    const targetRollLean =
      THREE.MathUtils.clamp(turnBank + strafeCounterBalance, -0.17, 0.17) * leanScale;

    const procSmooth = 1 - Math.exp(-10 * dt);
    this.smoothPitchLean = THREE.MathUtils.lerp(this.smoothPitchLean, targetPitchLean, procSmooth);
    this.smoothRollLean = THREE.MathUtils.lerp(this.smoothRollLean, targetRollLean, procSmooth);

    rig.pelvis.rotation.z += this.smoothRollLean * 0.32;
    rig.spineLower.rotation.x += this.smoothPitchLean * 0.55;
    rig.spineUpper.rotation.x += this.smoothPitchLean * 0.45;
    rig.spineLower.rotation.z += this.smoothRollLean * 0.42;
    rig.chest.rotation.z += this.smoothRollLean * 0.25;

    // =========================================================================
    // 8. EXACT PHASE-SYNCHRONIZED FOOT STRIKE EVENTS (Snowprints, Spray & Audio)
    // =========================================================================
    if (speed > 0.25 && locomotionState !== 'JUMP' && locomotionState !== 'DIVE') {
      const isRunning = blendSpeed > 0.65;
      const crossedPhase = (prev: number, curr: number, target: number): boolean => {
        if (localForwardRatio < -0.2) {
          // Moving backward: cycleU decreases across target
          if (prev >= curr) return prev >= target && curr < target;
          return prev >= target || curr < target;
        }
        // Moving forward: cycleU increases across target
        if (curr >= prev) return prev < target && curr >= target;
        return prev < target || curr >= target;
      };

      const leftStrike = crossedPhase(this.prevCycleU, this.cycleU, 0.02);
      const rightStrike = crossedPhase(this.prevCycleU, this.cycleU, 0.52);

      if (leftStrike || rightStrike) {
        rig.root.updateMatrixWorld(true);
        if (leftStrike) {
          const soleWorldL = new THREE.Vector3();
          rig.soleL.getWorldPosition(soleWorldL);
          onFootPlant({ side: 'L', worldPos: soleWorldL, yaw: facingYaw, isRun: isRunning });
        }
        if (rightStrike) {
          const soleWorldR = new THREE.Vector3();
          rig.soleR.getWorldPosition(soleWorldR);
          onFootPlant({ side: 'R', worldPos: soleWorldR, yaw: facingYaw, isRun: isRunning });
        }
      }
    }
  }

  /**
   * Additive Directional Impact Flinch (when HP > 0):
   * Jolts upper body, head, arms, and knees naturally along the snowball's push direction
   * with fast initial snap and smooth damped muscular recovery.
   */
  public applyDirectionalFlinch(
    rig: CharacterRig,
    flinchNorm: number, // 0 (impact start) -> 1 (recovered)
    localPushFwd: number, // -1 hit in chest pushing backward, +1 hit in back pushing forward
    localPushRight: number // +1 pushing toward character's right (-X), -1 toward left (+X)
  ): void {
    const clamped = THREE.MathUtils.clamp(flinchNorm, 0, 1);
    // Sharp initial jolt peaking around t = 0.18, then smooth muscular recovery
    const jolt =
      clamped < 0.18
        ? THREE.MathUtils.smoothstep(clamped, 0.0, 0.18)
        : 1 - THREE.MathUtils.smoothstep(clamped, 0.18, 1.0);

    // Shock-absorbing knee bend & slight pelvis drop
    rig.pelvis.position.y -= 0.055 * jolt;
    rig.pelvis.position.z += localPushFwd * 0.05 * jolt;
    rig.pelvis.rotation.x += localPushFwd * 0.14 * jolt;
    rig.pelvis.rotation.z += -localPushRight * 0.12 * jolt;

    // Multi-segment torso & head recoil along impact vector
    rig.spineLower.rotation.x += localPushFwd * 0.22 * jolt;
    rig.spineUpper.rotation.x += localPushFwd * 0.28 * jolt;
    rig.chest.rotation.x += localPushFwd * 0.32 * jolt;

    rig.spineUpper.rotation.z += -localPushRight * 0.2 * jolt;
    rig.chest.rotation.z += -localPushRight * 0.24 * jolt;
    rig.chest.rotation.y += localPushRight * 0.28 * jolt;

    rig.head.rotation.x += localPushFwd * 0.34 * jolt;
    rig.head.rotation.z += -localPushRight * 0.22 * jolt;

    // Reflexive balance arm flare & bracing knees
    rig.upperArmL.rotation.z += 0.48 * jolt;
    rig.upperArmL.rotation.x += -0.35 * jolt;
    rig.forearmL.rotation.x += -0.42 * jolt;

    rig.upperArmR.rotation.z += -0.48 * jolt;
    rig.upperArmR.rotation.x += -0.35 * jolt;
    rig.forearmR.rotation.x += -0.42 * jolt;

    rig.thighL.rotation.x += -0.24 * jolt;
    rig.calfL.rotation.x += 0.45 * jolt;
    rig.thighR.rotation.x += -0.24 * jolt;
    rig.calfR.rotation.x += 0.45 * jolt;
  }

  /**
   * Natural Articulated Ragdoll Knockdown Pose (when HP == 0):
   * Smoothly tumbles body backward (if hit from front) or forward (if hit from behind) onto the snow,
   * with secondary inertia lag on arms/legs during fall and damped flop/settle upon hitting snow!
   */
  public applyNaturalRagdoll(
    rig: CharacterRig,
    ragdollElapsed: number,
    onGround: boolean,
    groundElapsed: number,
    localPushFwd: number,
    localPushRight: number
  ): void {
    rig.resetPose();
    this.stanceWeightL = 0;
    this.stanceWeightR = 0;
    this.ankleSlopeWeightL = 0;
    this.ankleSlopeWeightR = 0;

    // fallSign = -1 -> hit from front, pitches backward onto back (-X rotation)
    // fallSign = +1 -> hit from behind, pitches forward onto belly (+X rotation)
    const fallSign = localPushFwd <= 0.1 ? -1 : 1;

    // Smooth tumble pitch progression over first ~0.42s of knockdown
    const tumbleT = 1 - Math.exp(-6.8 * ragdollElapsed);
    // Subtle cushioned bounce when torso hits snow
    const groundBounce = onGround
      ? Math.exp(-7.5 * groundElapsed) * Math.cos(16.0 * groundElapsed) * 0.1
      : 0;
    const settleT = onGround ? THREE.MathUtils.clamp(groundElapsed / 0.32, 0, 1) : 0;

    // Lower pelvis from standing (0.482m) to snow-resting thickness (0.175m)
    rig.pelvis.position.y = THREE.MathUtils.lerp(
      CharacterRig.STANDING_PELVIS_Y,
      0.175,
      THREE.MathUtils.clamp(tumbleT * 1.05, 0, 1)
    ) + Math.abs(groundBounce) * 0.12;

    const targetPitch = fallSign < 0 ? -1.48 : 1.44; // ~84° lying flush on snow!
    rig.pelvis.rotation.x = targetPitch * tumbleT + groundBounce * -fallSign;
    rig.pelvis.rotation.z = -localPushRight * 0.32 * tumbleT;
    rig.pelvis.rotation.y = localPushRight * 0.24 * tumbleT;

    // Spine & Head curve naturally during fall, then relax flat onto snow
    const airArch = (1 - settleT) * -fallSign * 0.24;
    rig.spineLower.rotation.x = airArch * 0.45;
    rig.spineUpper.rotation.x = airArch * 0.55;
    rig.chest.rotation.x = airArch * 0.4 + groundBounce * 0.5;
    rig.chest.rotation.z = -localPushRight * 0.12 * settleT;

    // Head lags during fall, then rests relaxed to one side on snow
    const sideRestYaw = (localPushRight >= 0 ? 1 : -1) * 0.42 * settleT;
    rig.head.rotation.x = THREE.MathUtils.lerp(-fallSign * 0.32, fallSign * 0.08, settleT);
    rig.head.rotation.y = sideRestYaw;

    // Secondary Limb Ragdoll Physics (Airborne Trailing -> Damped Snow Flop)
    if (fallSign < 0) {
      // Falling onto BACK:
      // In air: arms reach/trail forward & upward with soft elbows; on snow: flop open relaxed beside body!
      rig.upperArmL.rotation.z = THREE.MathUtils.lerp(0.55, 0.96, settleT);
      rig.upperArmL.rotation.x = THREE.MathUtils.lerp(-0.85, 0.12 + groundBounce, settleT);
      rig.upperArmL.rotation.y = THREE.MathUtils.lerp(-0.2, 0.35, settleT);
      rig.forearmL.rotation.x = THREE.MathUtils.lerp(-0.82, -0.32, settleT);

      rig.upperArmR.rotation.z = THREE.MathUtils.lerp(-0.55, -0.92, settleT);
      rig.upperArmR.rotation.x = THREE.MathUtils.lerp(-0.78, 0.16 + groundBounce, settleT);
      rig.upperArmR.rotation.y = THREE.MathUtils.lerp(0.2, -0.35, settleT);
      rig.forearmR.rotation.x = THREE.MathUtils.lerp(-0.76, -0.38, settleT);

      // Legs lift slightly as feet are swept out, then flop relaxed & slightly splayed on snow!
      rig.thighL.rotation.z = THREE.MathUtils.lerp(0.08, 0.22, settleT);
      rig.thighL.rotation.x = THREE.MathUtils.lerp(-0.58, -0.06 + groundBounce, settleT);
      rig.calfL.rotation.x = THREE.MathUtils.lerp(0.78, 0.24, settleT);
      rig.footL.rotation.x = THREE.MathUtils.lerp(0.15, 0.28, settleT);

      rig.thighR.rotation.z = THREE.MathUtils.lerp(-0.08, -0.2, settleT);
      rig.thighR.rotation.x = THREE.MathUtils.lerp(-0.42, -0.1 + groundBounce, settleT);
      rig.calfR.rotation.x = THREE.MathUtils.lerp(0.68, 0.3, settleT);
      rig.footR.rotation.x = THREE.MathUtils.lerp(0.18, 0.26, settleT);
    } else {
      // Falling onto FRONT / BELLY:
      rig.upperArmL.rotation.z = THREE.MathUtils.lerp(0.68, 1.12, settleT);
      rig.upperArmL.rotation.x = THREE.MathUtils.lerp(-0.95, -0.25, settleT);
      rig.forearmL.rotation.x = THREE.MathUtils.lerp(-0.65, -1.05, settleT);

      rig.upperArmR.rotation.z = THREE.MathUtils.lerp(-0.68, -1.06, settleT);
      rig.upperArmR.rotation.x = THREE.MathUtils.lerp(-0.9, -0.2, settleT);
      rig.forearmR.rotation.x = THREE.MathUtils.lerp(-0.65, -0.95, settleT);

      rig.thighL.rotation.z = THREE.MathUtils.lerp(0.08, 0.18, settleT);
      rig.thighL.rotation.x = THREE.MathUtils.lerp(0.28, 0.06, settleT);
      rig.calfL.rotation.x = THREE.MathUtils.lerp(0.62, 0.22, settleT);

      rig.thighR.rotation.z = THREE.MathUtils.lerp(-0.08, -0.18, settleT);
      rig.thighR.rotation.x = THREE.MathUtils.lerp(0.22, 0.08, settleT);
      rig.calfR.rotation.x = THREE.MathUtils.lerp(0.55, 0.28, settleT);
    }
  }
}
