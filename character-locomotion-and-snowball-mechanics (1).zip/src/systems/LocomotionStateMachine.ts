import {
  CharacterConfig,
  LocomotionState,
  UpperActionState,
} from '../config/GameConfig';

export class LocomotionStateMachine {
  public locomotionState: LocomotionState = 'IDLE';
  public prevLocomotionState: LocomotionState = 'IDLE';
  public stateTime = 0;

  public upperState: UpperActionState = 'NONE';
  public upperStateTime = 0;

  private stopDuration = 0.36;
  private peakSpeedBeforeStop = 0;
  public justEnteredStop = false;

  public updateLocomotion(
    dt: number,
    speed: number,
    hasMoveInput: boolean,
    isGrounded: boolean,
    isDiving: boolean,
    inRagdoll: boolean,
    stumbleTimer: number,
    isTurningInPlace: boolean,
    sharpTurnTimer: number,
    config: CharacterConfig
  ): void {
    this.justEnteredStop = false;
    this.stateTime += dt;

    if (hasMoveInput && speed > this.peakSpeedBeforeStop) {
      this.peakSpeedBeforeStop = speed;
    }

    let nextState: LocomotionState = this.locomotionState;

    if (inRagdoll) {
      nextState = 'RAGDOLL';
    } else if (stumbleTimer > 0.05) {
      nextState = 'FLINCH';
    } else if (isDiving) {
      nextState = 'DIVE';
    } else if (!isGrounded) {
      nextState = 'JUMP';
    } else if (sharpTurnTimer > 0) {
      nextState = 'SHARP_TURN';
    } else if (hasMoveInput) {
      if (speed < 0.16) {
        nextState = 'IDLE';
      } else if (speed < (config.walkSpeed + config.jogSpeed) * 0.48) {
        nextState = 'WALK';
      } else if (speed < (config.jogSpeed + config.runSpeed) * 0.48) {
        nextState = 'JOG';
      } else {
        nextState = 'RUN';
      }
    } else {
      if (
        this.locomotionState !== 'STOP' &&
        this.peakSpeedBeforeStop > config.walkSpeed * 1.18 &&
        speed > 1.25
      ) {
        nextState = 'STOP';
        this.stopDuration = this.peakSpeedBeforeStop > config.jogSpeed + 0.5 ? 0.38 : 0.3;
      } else if (this.locomotionState === 'STOP') {
        if (this.stateTime >= this.stopDuration && speed < 0.25) {
          nextState = 'IDLE';
          this.peakSpeedBeforeStop = 0;
        }
      } else {
        if (speed > (config.jogSpeed + config.runSpeed) * 0.5) {
          nextState = 'RUN';
        } else if (speed > (config.walkSpeed + config.jogSpeed) * 0.5) {
          nextState = 'JOG';
        } else if (speed > 0.22) {
          nextState = 'WALK';
        } else if (isTurningInPlace) {
          nextState = 'TURN';
          this.peakSpeedBeforeStop = 0;
        } else {
          nextState = 'IDLE';
          this.peakSpeedBeforeStop = 0;
        }
      }
    }

    if (nextState !== this.locomotionState) {
      this.prevLocomotionState = this.locomotionState;
      this.locomotionState = nextState;
      this.stateTime = 0;
      if (nextState === 'STOP') {
        this.justEnteredStop = true;
      }
    }
  }

  public setUpperState(next: UpperActionState): void {
    if (this.upperState !== next) {
      this.upperState = next;
      this.upperStateTime = 0;
    }
  }

  public advanceUpperTimer(dt: number): void {
    this.upperStateTime += dt;
  }

  public getStopNormalizedProgress(): number {
    if (this.locomotionState !== 'STOP') return 0;
    return Math.min(1, this.stateTime / Math.max(0.1, this.stopDuration));
  }
}
