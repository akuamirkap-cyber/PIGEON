export class AudioSystem {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private lastHitPitch = 1.0;
  public enabled = true;

  private ensureContext(): AudioContext | null {
    if (!this.enabled) return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    if (!this.noiseBuffer && this.ctx) {
      const sampleRate = this.ctx.sampleRate;
      const length = sampleRate * 1.5;
      const buffer = this.ctx.createBuffer(1, length, sampleRate);
      const data = buffer.getChannelData(0);
      let last = 0;
      for (let i = 0; i < length; i++) {
        const white = Math.random() * 2 - 1;
        const crackle = Math.random() > 0.9 ? (Math.random() * 2 - 1) * 1.75 : white * 0.68;
        last = last * 0.22 + crackle * 0.78;
        data[i] = Math.max(-1, Math.min(1, last));
      }
      this.noiseBuffer = buffer;
    }
    return this.ctx;
  }

  public unlock(): void {
    this.ensureContext();
  }

  /**
   * Generates a 5%–10% pitch variation (0.90 .. 1.10) guaranteed to differ
   * noticeably from the previous hit so rapid consecutive hits never sound monotonous.
   */
  private nextRandomHitPitch(): number {
    let candidate = 1.0;
    for (let attempt = 0; attempt < 4; attempt++) {
      const sign = Math.random() < 0.5 ? -1 : 1;
      const offset = 0.05 + Math.random() * 0.05; // 5% to 10%
      candidate = 1.0 + sign * offset;
      if (Math.abs(candidate - this.lastHitPitch) >= 0.045) break;
    }
    this.lastHitPitch = candidate;
    return candidate;
  }

  /**
   * Dense Wet-Packed Snow / Flour-Pillow THUD + Layered Crushed Ice/Snow CRUNCH
   * with 5%–10% random pitch variation on every hit.
   */
  public playDenseSnowBodyHit(distance: number, isKo = false, isMega = false): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    const pitch = this.nextRandomHitPitch() * (isMega ? 0.88 : 1.0);
    const atten = Math.max(0.18, Math.min(1.0, 20 / Math.max(5, distance)));
    const weightBoost = isKo ? 1.22 : 1.0;

    // =========================================================================
    // LAYER 1A: Dense Flour-Pillow / Wet-Sand Low-End Body THUD
    // =========================================================================
    const thudOsc = ctx.createOscillator();
    thudOsc.type = 'sine';
    thudOsc.frequency.setValueAtTime(148 * pitch, now);
    thudOsc.frequency.exponentialRampToValueAtTime(46 * pitch, now + 0.095);

    const thudGain = ctx.createGain();
    thudGain.gain.setValueAtTime(0.001, now);
    thudGain.gain.linearRampToValueAtTime(0.38 * atten * weightBoost, now + 0.006);
    thudGain.gain.exponentialRampToValueAtTime(0.001, now + 0.115);

    thudOsc.connect(thudGain);
    thudGain.connect(ctx.destination);
    thudOsc.start(now);
    thudOsc.stop(now + 0.12);

    // =========================================================================
    // LAYER 1B: Muffled Packed-Mass Slap (Wet Sand / Padded Jacket Compression)
    // =========================================================================
    const denseNoise = ctx.createBufferSource();
    denseNoise.buffer = this.noiseBuffer;
    denseNoise.playbackRate.value = 0.72 * pitch;

    const denseLp = ctx.createBiquadFilter();
    denseLp.type = 'lowpass';
    denseLp.frequency.setValueAtTime(520 * pitch, now);
    denseLp.frequency.exponentialRampToValueAtTime(145 * pitch, now + 0.09);
    denseLp.Q.value = 1.65;

    const denseGain = ctx.createGain();
    denseGain.gain.setValueAtTime(0.001, now);
    denseGain.gain.linearRampToValueAtTime(0.34 * atten * weightBoost, now + 0.005);
    denseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    denseNoise.connect(denseLp);
    denseLp.connect(denseGain);
    denseGain.connect(ctx.destination);
    denseNoise.start(now, Math.random() * 0.7, 0.115);

    // =========================================================================
    // LAYER 2A: Crushed Ice & Packed Snow CRUNCH (Mid-High Shatter)
    // =========================================================================
    const crunchSrc = ctx.createBufferSource();
    crunchSrc.buffer = this.noiseBuffer;
    crunchSrc.playbackRate.value = 1.08 * pitch;

    const crunchBp = ctx.createBiquadFilter();
    crunchBp.type = 'bandpass';
    crunchBp.frequency.setValueAtTime(1950 * pitch, now + 0.004);
    crunchBp.frequency.exponentialRampToValueAtTime(840 * pitch, now + 0.135);
    crunchBp.Q.value = 1.25;

    const crunchGain = ctx.createGain();
    crunchGain.gain.setValueAtTime(0.001, now);
    crunchGain.gain.linearRampToValueAtTime(0.28 * atten, now + 0.01);
    crunchGain.gain.exponentialRampToValueAtTime(0.001, now + 0.145);

    crunchSrc.connect(crunchBp);
    crunchBp.connect(crunchGain);
    crunchGain.connect(ctx.destination);
    crunchSrc.start(now, Math.random() * 0.6, 0.16);

    // =========================================================================
    // LAYER 2B: Fine Ice-Crystal Scatter Spray
    // =========================================================================
    const spraySrc = ctx.createBufferSource();
    spraySrc.buffer = this.noiseBuffer;
    spraySrc.playbackRate.value = 1.35 * pitch;

    const sprayHp = ctx.createBiquadFilter();
    sprayHp.type = 'highpass';
    sprayHp.frequency.setValueAtTime(2900 * pitch, now + 0.01);

    const sprayGain = ctx.createGain();
    sprayGain.gain.setValueAtTime(0.001, now + 0.008);
    sprayGain.gain.linearRampToValueAtTime(0.14 * atten, now + 0.018);
    sprayGain.gain.exponentialRampToValueAtTime(0.001, now + 0.165);

    spraySrc.connect(sprayHp);
    sprayHp.connect(sprayGain);
    sprayGain.connect(ctx.destination);
    spraySrc.start(now + 0.008, Math.random() * 0.5, 0.17);

    // Optional heavier low-end body-knock punch when enemy is KO'd off their feet
    if (isKo) {
      const koSub = ctx.createOscillator();
      koSub.type = 'triangle';
      koSub.frequency.setValueAtTime(98 * pitch, now + 0.015);
      koSub.frequency.exponentialRampToValueAtTime(34 * pitch, now + 0.16);

      const koGain = ctx.createGain();
      koGain.gain.setValueAtTime(0.22 * atten, now + 0.015);
      koGain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);

      koSub.connect(koGain);
      koGain.connect(ctx.destination);
      koSub.start(now + 0.015);
      koSub.stop(now + 0.18);
    }
  }

  public playRagdollSnowFall(distance: number): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const atten = Math.max(0.1, Math.min(1.0, 16 / Math.max(5, distance)));
    const now = ctx.currentTime;
    const pitch = 0.92 + Math.random() * 0.16;

    // Soft padded body landing into snowbank
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(88 * pitch, now);
    osc.frequency.exponentialRampToValueAtTime(36, now + 0.11);

    const gOsc = ctx.createGain();
    gOsc.gain.setValueAtTime(0.18 * atten, now);
    gOsc.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gOsc);
    gOsc.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 0.85 * pitch;

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(1100 * pitch, now);
    lp.frequency.exponentialRampToValueAtTime(340, now + 0.18);

    const gNoise = ctx.createGain();
    gNoise.gain.setValueAtTime(0.2 * atten, now);
    gNoise.gain.exponentialRampToValueAtTime(0.001, now + 0.19);

    src.connect(lp);
    lp.connect(gNoise);
    gNoise.connect(ctx.destination);
    src.start(now, Math.random() * 0.5, 0.2);
  }

  public playFootstepSnow(intensity = 0.6): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    const pitchJitter = 0.95 + Math.random() * 0.16;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 0.92 * pitchJitter;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1550 * pitchJitter, now);
    bp.frequency.exponentialRampToValueAtTime(800, now + 0.1);
    bp.Q.value = 1.4;

    const gain = ctx.createGain();
    const vol = Math.min(0.24, 0.12 * intensity);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(vol, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

    src.connect(bp);
    bp.connect(gain);
    gain.connect(ctx.destination);
    src.start(now, Math.random() * 0.8, 0.13);
  }

  public playRunSnowFootstep(intensity = 1.0): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    const pitchJitter = 0.96 + Math.random() * 0.18;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 1.12 * pitchJitter;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(2050 * pitchJitter, now);
    bp.frequency.exponentialRampToValueAtTime(920, now + 0.12);
    bp.Q.value = 1.2;

    const gain = ctx.createGain();
    const vol = Math.min(0.28, 0.18 * intensity);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(vol, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);

    src.connect(bp);
    bp.connect(gain);
    gain.connect(ctx.destination);
    src.start(now, Math.random() * 0.8, 0.15);

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(135 * pitchJitter, now);
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.075);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.11 * intensity, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(subGain);
    subGain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.085);
  }

  public playSnowCrunch(intensity = 0.9): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 0.82;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1600, now);
    filter.frequency.exponentialRampToValueAtTime(540, now + 0.25);
    filter.Q.value = 1.0;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.22 * intensity, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(now, Math.random() * 0.5, 0.28);
  }

  public playSnowballPickup(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    [0, 0.085].forEach((offset, idx) => {
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer!;
      src.playbackRate.value = idx === 0 ? 0.95 : 1.25;

      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(idx === 0 ? 1300 : 1950, now + offset);
      bp.Q.value = 1.8;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.001, now + offset);
      gain.gain.linearRampToValueAtTime(idx === 0 ? 0.2 : 0.16, now + offset + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.095);

      src.connect(bp);
      bp.connect(gain);
      gain.connect(ctx.destination);
      src.start(now + offset, Math.random() * 0.6, 0.11);
    });
  }

  public playJumpHop(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(210, now);
    osc.frequency.exponentialRampToValueAtTime(490, now + 0.13);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  public playDiveWhoosh(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(170, now + 0.18);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  public playBumperBoing(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(540, now + 0.09);
    osc.frequency.exponentialRampToValueAtTime(290, now + 0.19);
    osc.frequency.exponentialRampToValueAtTime(430, now + 0.28);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.31);
  }

  public playThrowWhoosh(powerFactor = 1.0): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 1.25;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(340, now);
    bp.frequency.exponentialRampToValueAtTime(1450 * powerFactor, now + 0.075);
    bp.frequency.exponentialRampToValueAtTime(380, now + 0.18);
    bp.Q.value = 2.0;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.24 * Math.min(1.3, powerFactor), now + 0.055);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);

    src.connect(bp);
    bp.connect(gain);
    gain.connect(ctx.destination);
    src.start(now, 0.1, 0.21);
  }

  public playSnowballRelease(powerFactor = 1.0): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(310 * powerFactor, now);
    osc.frequency.exponentialRampToValueAtTime(125, now + 0.05);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.055);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playLauncherShot(distance = 1): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;
    const now = ctx.currentTime;
    const atten = Math.max(0.2, Math.min(1.0, 14 / Math.max(4, distance)));
    const pitch = 0.94 + Math.random() * 0.12;

    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(260 * pitch, now);
    osc.frequency.exponentialRampToValueAtTime(80 * pitch, now + 0.06);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.1 * atten, now);
    og.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(og);
    og.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.075);

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 1.3 * pitch;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1500 * pitch, now);
    bp.frequency.exponentialRampToValueAtTime(420, now + 0.09);
    bp.Q.value = 1.1;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.001, now);
    ng.gain.linearRampToValueAtTime(0.22 * atten, now + 0.006);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    src.connect(bp);
    bp.connect(ng);
    ng.connect(ctx.destination);
    src.start(now, Math.random() * 0.6, 0.11);
  }

  public playBazookaLaunch(distance = 1): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;
    const now = ctx.currentTime;
    const atten = Math.max(0.25, Math.min(1.0, 18 / Math.max(5, distance)));

    const thump = ctx.createOscillator();
    thump.type = 'sine';
    thump.frequency.setValueAtTime(130, now);
    thump.frequency.exponentialRampToValueAtTime(38, now + 0.22);
    const tg = ctx.createGain();
    tg.gain.setValueAtTime(0.4 * atten, now);
    tg.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    thump.connect(tg);
    tg.connect(ctx.destination);
    thump.start(now);
    thump.stop(now + 0.26);

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 0.8;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2600, now);
    lp.frequency.exponentialRampToValueAtTime(260, now + 0.5);
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.001, now);
    ng.gain.linearRampToValueAtTime(0.34 * atten, now + 0.02);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    src.connect(lp);
    lp.connect(ng);
    ng.connect(ctx.destination);
    src.start(now, 0.1, 0.6);
  }

  public playExplosion(distance = 1): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;
    const now = ctx.currentTime;
    const atten = Math.max(0.3, Math.min(1.0, 22 / Math.max(6, distance)));

    const boom = ctx.createOscillator();
    boom.type = 'sine';
    boom.frequency.setValueAtTime(82, now);
    boom.frequency.exponentialRampToValueAtTime(24, now + 0.7);
    const bg = ctx.createGain();
    bg.gain.setValueAtTime(0.001, now);
    bg.gain.linearRampToValueAtTime(0.62 * atten, now + 0.01);
    bg.gain.exponentialRampToValueAtTime(0.001, now + 0.75);
    boom.connect(bg);
    bg.connect(ctx.destination);
    boom.start(now);
    boom.stop(now + 0.8);

    const body = ctx.createBufferSource();
    body.buffer = this.noiseBuffer;
    body.playbackRate.value = 0.62;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2800, now);
    lp.frequency.exponentialRampToValueAtTime(110, now + 0.8);
    const lg = ctx.createGain();
    lg.gain.setValueAtTime(0.001, now);
    lg.gain.linearRampToValueAtTime(0.5 * atten, now + 0.008);
    lg.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    body.connect(lp);
    lp.connect(lg);
    lg.connect(ctx.destination);
    body.start(now, Math.random() * 0.4, 0.9);

    const crack = ctx.createBufferSource();
    crack.buffer = this.noiseBuffer;
    crack.playbackRate.value = 1.25;
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(2200, now);
    const cg = ctx.createGain();
    cg.gain.setValueAtTime(0.001, now);
    cg.gain.linearRampToValueAtTime(0.3 * atten, now + 0.01);
    cg.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    crack.connect(hp);
    hp.connect(cg);
    cg.connect(ctx.destination);
    crack.start(now, Math.random() * 0.4, 0.55);
  }

  public playReloadClick(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    [0, 0.09].forEach((off, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(i === 0 ? 520 : 760, now + off);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.08, now + off);
      g.gain.exponentialRampToValueAtTime(0.001, now + off + 0.04);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now + off);
      osc.stop(now + off + 0.045);
    });
  }

  public playWeaponSwitch(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(380, now);
    osc.frequency.exponentialRampToValueAtTime(820, now + 0.08);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  public playLockToggle(on: boolean): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const freqs = on ? [880, 1320] : [620, 420];
    freqs.forEach((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + i * 0.07);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.14, now + i * 0.07);
      g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.09);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now + i * 0.07);
      osc.stop(now + i * 0.07 + 0.1);
    });
  }

  public playPowerUpPickup(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    [440, 554.37, 659.25, 880].forEach((freq, i) => {
      const t = now + i * 0.048;
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.15, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.17);
    });
  }

  public playSnowballImpact(distance: number, hitSolid = false): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.noiseBuffer) return;

    const now = ctx.currentTime;
    const pitch = this.nextRandomHitPitch();
    const atten = Math.max(0.08, Math.min(1.0, 16 / Math.max(5, distance)));

    // Subtle soft snow thud + crunch on terrain/wall impact
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(115 * pitch, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.07);

    const gOsc = ctx.createGain();
    gOsc.gain.setValueAtTime(0.16 * atten, now);
    gOsc.gain.exponentialRampToValueAtTime(0.001, now + 0.075);

    osc.connect(gOsc);
    gOsc.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.08);

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = (hitSolid ? 1.18 : 0.96) * pitch;

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime((hitSolid ? 2400 : 1850) * pitch, now);
    lp.frequency.exponentialRampToValueAtTime(420, now + 0.15);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.24 * atten, now + 0.007);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    src.connect(lp);
    lp.connect(gain);
    gain.connect(ctx.destination);
    src.start(now, Math.random() * 0.5, 0.18);
  }
}
