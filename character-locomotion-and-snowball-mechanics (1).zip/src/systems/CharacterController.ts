import * as THREE from 'three';
import { CharacterRig, DEFAULT_PLAYER_APPEARANCE } from '../character/CharacterRig';
import {
  ArcadeCallout,
  CharacterConfig,
  DebugTelemetry,
  INITIAL_TESTS,
  KillFeedItem,
  LeaderboardEntry,
  PowerUpType,
  SCORE_LIMIT,
  TEAM_HEX,
  TeamId,
} from '../config/GameConfig';
import { AmmoType, FpsSystem, ShotRequest } from '../fps/FpsSystem';
import { soundEngine } from '../fps/audio';
import { setFirstPersonColors } from '../fps/weaponModels';
import { RollController } from './RollController';
import { WeaponId } from '../fps/types';
import { RangeTarget, SnowTerrain } from '../world/SnowTerrain';
import { solveBallisticLaunchDirection } from './AimController';
import { AnimationController } from './AnimationController';
import { AudioSystem } from './AudioSystem';
import { BotInstance, BotManager } from './BotManager';
import { CameraController } from './CameraController';
import { InputManager } from './InputManager';
import { LocomotionStateMachine } from './LocomotionStateMachine';
import { MovementController } from './MovementController';
import { CombatantHitbox, ExplosionEvent, ProjectileHitEvent, ProjectilePhysics } from './ProjectilePhysics';

type HitType = 'none' | 'bot' | 'target' | 'wall' | 'ground' | 'bumper';

interface HitscanResult {
  type: HitType;
  dist: number;
  point: THREE.Vector3;
  normal: THREE.Vector3;
  bot?: BotInstance;
  headshot?: boolean;
  target?: RangeTarget;
}

function raySphere(origin: THREE.Vector3, dir: THREE.Vector3, c: THREE.Vector3, r: number): number | null {
  const ox = origin.x - c.x;
  const oy = origin.y - c.y;
  const oz = origin.z - c.z;
  const b = ox * dir.x + oy * dir.y + oz * dir.z;
  const cc = ox * ox + oy * oy + oz * oz - r * r;
  const disc = b * b - cc;
  if (disc < 0) return null;
  const s = Math.sqrt(disc);
  const t1 = -b - s;
  if (t1 > 0.05) return t1;
  const t2 = -b + s;
  if (t2 > 0.05) return t2;
  return null;
}

// Snowball-ammo ballistics per weapon (fast, light gravity so the weapon still feels like a rifle)
const SNOW_SHOT: Record<WeaponId, { speed: number; gravity: number }> = {
  pistol: { speed: 52, gravity: 6.5 },
  rifle: { speed: 68, gravity: 4.5 },
  sniper: { speed: 105, gravity: 1.8 },
};

const EYE_STAND = 1.1;
const EYE_CROUCH = 0.74;

export class CharacterController {
  public readonly rig: CharacterRig;
  public readonly movement: MovementController;
  public readonly fsm: LocomotionStateMachine;
  public readonly animation: AnimationController;
  public readonly projectiles: ProjectilePhysics;
  public readonly botManager: BotManager;
  public readonly cameraCtrl: CameraController;
  public readonly audio: AudioSystem;
  public readonly fps: FpsSystem;
  public readonly roll: RollController;
  private readonly terrain: SnowTerrain;
  private readonly scene: THREE.Scene;

  public readonly team: TeamId = 'BLUE';

  // Player state
  public playerHp = 3;
  public readonly playerMaxHp = 3;
  public playerAlive = true;
  private playerInvulnTimer = 0;
  private damagePulse = 0;

  private playerLocalHitFwd = -1;
  private playerLocalHitRight = 0;
  private playerInRagdoll = false;
  private playerRagdollElapsed = 0;
  private readonly playerRagdollDuration = 2.2;
  private playerRagdollGrounded = false;
  private playerRagdollGroundElapsed = 0;

  public playerScore = 0;
  public playerKos = 0;
  public playerStreak = 0;
  private streakTimeout = 0;
  public blueScore = 0;
  public redScore = 0;

  public activePowerUp: PowerUpType | null = null;
  public powerUpTimer = 0;
  public powerUpCharges = 0;

  private crouchAmount = 0;
  private lastFallVy = 0;
  private crosshairOnEnemy = false;
  private hitMarkerTimer = 0;

  public matchTimeRemaining = 150;
  private nextEventId = 1;
  private killFeed: KillFeedItem[] = [];
  private latestCallout: ArcadeCallout | null = null;
  private calloutTimer = 0;

  private readonly combatantHitboxes: CombatantHitbox[] = [];

  constructor(
    scene: THREE.Scene,
    terrain: SnowTerrain,
    aspect: number,
    _initialConfig: CharacterConfig,
    audio: AudioSystem
  ) {
    this.audio = audio;
    this.terrain = terrain;
    this.scene = scene;

    this.rig = new CharacterRig(DEFAULT_PLAYER_APPEARANCE);
    const startY = terrain.getHeightAt(0, -25);
    this.rig.root.position.set(0, startY, -25);
    this.rig.root.visible = false; // first-person: no visible body while alive
    setFirstPersonColors(this.rig.look.glove, this.rig.look.jacket);
    this.roll = new RollController(scene, 0x38bdf8);
    scene.add(this.rig.root);

    this.movement = new MovementController(startY);
    this.movement.position.set(0, startY, -25);
    this.movement.disableSharpTurn = true;

    this.fsm = new LocomotionStateMachine();
    this.animation = new AnimationController();
    this.projectiles = new ProjectilePhysics(scene);
    this.botManager = new BotManager(scene, terrain);
    this.cameraCtrl = new CameraController(aspect);

    this.fps = new FpsSystem(scene, aspect, (x, z) => terrain.getHeightAt(x, z), {
      onShot: (req) => this.handleFpsShot(req),
      onFootstep: (foot, stance) => this.handleFootstep(foot, stance),
      playSnowShot: () => this.audio.playLauncherShot(1),
    });

    this.pushCallout('TIM BIRU vs TIM MERAH!', '5 vs 5 • FPS • Capai 25 KO duluan! ❄️', '#38bdf8');
  }

  // ---------------------------------------------------------------- helpers
  private pushCallout(text: string, subtext: string | undefined, color: string): void {
    this.latestCallout = { id: this.nextEventId++, text, subtext, color };
    this.calloutTimer = 2.0;
  }

  private pushKillFeed(killer: string, victim: string, killerIsPlayer: boolean, victimIsPlayer: boolean, isMega: boolean): void {
    this.killFeed.unshift({ id: this.nextEventId++, killer, victim, killerIsPlayer, victimIsPlayer, isMega });
    if (this.killFeed.length > 5) this.killFeed.pop();
  }

  private blueBaseSpawn(): THREE.Vector3 {
    const x = (Math.random() - 0.5) * 10;
    const z = -25 + (Math.random() - 0.5) * 1.6;
    return new THREE.Vector3(x, this.terrain.getHeightAt(x, z), z);
  }

  private addTeamKill(team: TeamId): void {
    if (team === 'BLUE') this.blueScore++;
    else this.redScore++;
    if (this.blueScore >= SCORE_LIMIT) this.endMatch('BLUE');
    else if (this.redScore >= SCORE_LIMIT) this.endMatch('RED');
  }

  private endMatch(winner: TeamId | null): void {
    this.restartMatch(this.terrain);
    if (winner) {
      this.pushCallout(
        winner === 'BLUE' ? 'TIM BIRU MENANG! 🏆' : 'TIM MERAH MENANG!',
        'Ronde baru dimulai!',
        winner === 'BLUE' ? '#38bdf8' : '#f87171'
      );
    } else {
      this.pushCallout('SERI!', 'Ronde baru dimulai!', '#facc15');
    }
  }

  public restartMatch(terrain: SnowTerrain): void {
    this.playerScore = 0;
    this.playerKos = 0;
    this.playerStreak = 0;
    this.blueScore = 0;
    this.redScore = 0;
    this.playerHp = this.playerMaxHp;
    this.playerAlive = true;
    this.playerInRagdoll = false;
    this.activePowerUp = null;
    this.powerUpTimer = 0;
    this.powerUpCharges = 0;
    this.matchTimeRemaining = 150;
    this.killFeed = [];
    this.damagePulse = 0;
    const sp = this.blueBaseSpawn();
    this.movement.position.copy(sp);
    this.movement.velocity.set(0, 0, 0);
    this.rig.root.visible = false;
    this.fps.refillAmmo();
    this.fps.resetLook(0);
    this.botManager.resetScores(terrain);
    this.pushCallout('RONDE BARU!', 'Tim Biru vs Tim Merah ❄️', '#facc15');
  }

  public triggerManualPickup(_terrain: SnowTerrain): void {
    // snowballs are fired from the weapon in FPS mode — nothing to pick up
  }

  private startRoll(): void {
    const yaw = this.fps.gameYaw;
    this.roll.start(this.movement.position, yaw, this.movement.velocity);
    this.cameraCtrl.snapTo(yaw, -0.2);
    this.audio.playDiveWhoosh();
    this.rig.root.visible = false;
    this.pushCallout('GELINDING! 🌨️', 'Tabrak musuh untuk menjatuhkan mereka!', '#7dd3fc');
  }

  private endRoll(): void {
    this.fps.resetLook(this.cameraCtrl.currentYaw);
    this.movement.velocity.copy(this.roll.velocity).multiplyScalar(0.7);
    this.movement.isGrounded = true;
    this.rig.root.visible = false;
  }

  private handleRollStrike(bot: BotInstance, dir: THREE.Vector3, speed: number, terrain: SnowTerrain): void {
    const pos = new THREE.Vector3(bot.position.x, bot.position.y + 0.7, bot.position.z);
    terrain.emitSnowballShatter(pos, dir.clone().negate(), dir.clone().multiplyScalar(speed), 1.2, true, false);
    terrain.emitStopSpray(bot.position, dir, 1.4);
    this.fps.addTrauma(0.15);
    this.handleCombatantHit(
      {
        ownerId: 'player',
        ownerName: 'YOU',
        teamId: this.team,
        victimId: bot.id,
        victimName: bot.name,
        impactPos: pos,
        impactVel: dir.clone().multiplyScalar(speed),
        impactNormal: dir.clone().negate(),
        hitBone: bot.rig.chest,
        throwDistance: 0,
        powerFactor: 1.3,
        isMega: true,
        didCling: false,
        hitstopDuration: 0.06,
        kind: 'ROLL',
        forceKo: true,
        damage: 99,
        knockScale: 1 + speed / 14,
      },
      terrain
    );
  }

  public isFpsView(): boolean {
    return this.playerAlive && !this.playerInRagdoll && !this.roll.active;
  }

  public renderFrame(renderer: THREE.WebGLRenderer): void {
    if (this.isFpsView()) {
      this.fps.render(renderer);
    } else {
      renderer.render(this.scene, this.cameraCtrl.camera);
    }
  }

  public onResize(aspect: number): void {
    this.cameraCtrl.resize(aspect);
    this.fps.resize(aspect);
  }

  private damageMult(): number {
    return this.activePowerUp === 'MEGA' ? 2.0 : 1.0;
  }

  // ------------------------------------------------------------ footsteps
  private handleFootstep(foot: 'left' | 'right', stance: 'crouch' | 'walk' | 'sprint'): void {
    const yaw = this.movement.facingYaw;
    const side = foot === 'left' ? 1 : -1;
    const pos = new THREE.Vector3(
      this.movement.position.x + Math.cos(yaw) * 0.1 * side,
      this.movement.position.y,
      this.movement.position.z - Math.sin(yaw) * 0.1 * side
    );
    this.terrain.addFootprint(pos, yaw);
    const speed = Math.hypot(this.movement.velocity.x, this.movement.velocity.z);
    const dir =
      speed > 0.2
        ? new THREE.Vector3(this.movement.velocity.x, 0, this.movement.velocity.z).normalize()
        : new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
    this.terrain.emitFootSnow(pos, dir, stance === 'sprint');
    if (stance === 'sprint') this.audio.playRunSnowFootstep(1.0);
    else this.audio.playFootstepSnow(stance === 'crouch' ? 0.4 : 0.75);
  }

  // ------------------------------------------------------------- hitscan
  private fpsHitscan(origin: THREE.Vector3, dir: THREE.Vector3, maxDist: number): HitscanResult {
    let best: HitscanResult = {
      type: 'none',
      dist: maxDist,
      point: origin.clone().addScaledVector(dir, maxDist),
      normal: dir.clone().negate(),
    };
    const head = new THREE.Vector3();
    const body = new THREE.Vector3();

    for (const bot of this.botManager.bots) {
      if (bot.team === this.team || !bot.alive || bot.inRagdoll) continue;
      head.set(bot.position.x, bot.position.y + 1.1, bot.position.z);
      body.set(bot.position.x, bot.position.y + 0.58, bot.position.z);
      const dh = raySphere(origin, dir, head, 0.27);
      const db = raySphere(origin, dir, body, 0.4);
      let d: number | null = null;
      let isHead = false;
      if (dh !== null && (db === null || dh <= db)) {
        d = dh;
        isHead = true;
      } else if (db !== null) {
        d = db;
      }
      if (d !== null && d < best.dist) {
        const point = origin.clone().addScaledVector(dir, d);
        const center = isHead ? head : body;
        best = { type: 'bot', dist: d, point, normal: point.clone().sub(center).normalize(), bot, headshot: isHead };
      }
    }

    for (const t of this.terrain.targets) {
      const d = raySphere(origin, dir, t.hitCenter, t.hitRadius);
      if (d !== null && d < best.dist) {
        const point = origin.clone().addScaledVector(dir, d);
        best = { type: 'target', dist: d, point, normal: point.clone().sub(t.hitCenter).normalize(), target: t };
      }
    }

    const wall = this.terrain.raycastObstacleWalls(origin, dir, best.dist);
    if (wall && wall.distance < best.dist) {
      best = { type: 'wall', dist: wall.distance, point: wall.point, normal: wall.normal };
    }

    // snow ground + bumpers (ray-march with binary refinement)
    const step = 0.4;
    const p = new THREE.Vector3();
    let prevD = 0.3;
    for (let d = 0.5; d < best.dist; d += step) {
      p.copy(origin).addScaledVector(dir, d);

      let hitBumper = false;
      for (const b of this.terrain.bumpers) {
        if (p.y <= b.position.y + b.height && Math.hypot(p.x - b.position.x, p.z - b.position.z) <= b.radius) {
          const n = new THREE.Vector3(p.x - b.position.x, 0, p.z - b.position.z);
          if (n.lengthSq() < 0.0001) n.set(0, 1, 0);
          best = { type: 'bumper', dist: d, point: p.clone(), normal: n.normalize() };
          hitBumper = true;
          break;
        }
      }
      if (hitBumper) break;

      if (p.y <= this.terrain.getHeightAt(p.x, p.z)) {
        let lo = prevD;
        let hi = d;
        for (let i = 0; i < 6; i++) {
          const mid = (lo + hi) * 0.5;
          p.copy(origin).addScaledVector(dir, mid);
          if (p.y <= this.terrain.getHeightAt(p.x, p.z)) hi = mid;
          else lo = mid;
        }
        const dist = (lo + hi) * 0.5;
        const point = origin.clone().addScaledVector(dir, dist);
        best = { type: 'ground', dist, point, normal: this.terrain.getNormalAt(point.x, point.z) };
        break;
      }
      prevD = d;
    }
    return best;
  }

  private updateCrosshairHover(): void {
    const origin = this.fps.worldCamera.position;
    const dir = this.fps.getAimDirection(new THREE.Vector3());
    const c = new THREE.Vector3();
    let on = false;
    for (const bot of this.botManager.bots) {
      if (bot.team === this.team || !bot.alive || bot.inRagdoll) continue;
      c.set(bot.position.x, bot.position.y + 0.7, bot.position.z);
      const d = raySphere(origin, dir, c, 0.5);
      if (d !== null && d < 90) {
        on = true;
        break;
      }
    }
    this.crosshairOnEnemy = on;
  }

  // -------------------------------------------------------------- shooting
  private handleFpsShot(req: ShotRequest): void {
    const spec = req.spec;
    const maxDist = req.weaponId === 'sniper' ? 320 : 220;
    const hit = this.fpsHitscan(req.origin, req.dir, maxDist);
    const endPoint = hit.point;
    const bodyDmg = (spec.damageBody / 100) * 3 * this.damageMult();
    const headDmg = (spec.damageHead / 100) * 3 * this.damageMult();

    if (req.ammoType === ('BULLET' as AmmoType)) {
      // PIGEON-style hitscan bullet with a glowing tracer from the real muzzle tip
      this.fps.spawnTracer(req.muzzle, endPoint, spec.muzzleVelocity);
      if (req.weaponId === 'sniper') this.fps.spawnSniperContrail(req.muzzle, endPoint);
      this.applyHitscanHit(hit, req, bodyDmg, headDmg);
      return;
    }

    // SNOWBALL ammo: a real physical snowball leaves the muzzle and flies a ballistic arc to the crosshair point
    const ss = SNOW_SHOT[req.weaponId];
    const aimPoint = hit.type !== 'none' ? endPoint : req.origin.clone().addScaledVector(req.dir, 120);
    const launchDir = solveBallisticLaunchDirection(req.muzzle, aimPoint, ss.speed, ss.gravity, 0.003);
    this.projectiles.spawn({
      ownerId: 'player',
      ownerName: 'YOU',
      teamId: this.team,
      origin: req.muzzle,
      velocity: launchDir.clone().multiplyScalar(ss.speed),
      kind: 'BULLET',
      powerFactor: 1,
      isMega: false,
      gravity: ss.gravity,
      drag: 0.003,
      damage: bodyDmg,
      headMult: headDmg / Math.max(0.01, bodyDmg),
    });
  }

  private applyHitscanHit(hit: HitscanResult, req: ShotRequest, bodyDmg: number, headDmg: number): void {
    const t = this.terrain;
    const dir = req.dir;

    if (hit.type === 'bot' && hit.bot) {
      const bot = hit.bot;
      const headshot = hit.headshot === true;
      const bone = headshot ? bot.rig.head : bot.rig.chest;
      t.addBodySnowDecal(bone, hit.point, hit.normal, headshot ? 0.24 : 0.2);
      t.emitSnowballShatter(hit.point, hit.normal, dir.clone().multiplyScalar(8), 0.55, false, true);
      t.emitThroughSplatterBehindTarget(hit.point, dir, false);
      this.handleCombatantHit(
        {
          ownerId: 'player',
          ownerName: 'YOU',
          teamId: this.team,
          victimId: bot.id,
          victimName: bot.name,
          impactPos: hit.point.clone(),
          impactVel: dir.clone().multiplyScalar(req.spec.muzzleVelocity * 0.06),
          impactNormal: hit.normal.clone(),
          hitBone: bone,
          throwDistance: hit.dist,
          powerFactor: 1,
          isMega: false,
          didCling: false,
          hitstopDuration: headshot ? 0.05 : 0.035,
          kind: 'BULLET',
          forceKo: false,
          damage: headshot ? headDmg : bodyDmg,
          headshot,
        },
        t
      );
    } else if (hit.type === 'target' && hit.target) {
      t.triggerTargetHit(hit.target, dir, 1.0);
      t.addBodySnowDecal(hit.target.pivotGroup, hit.point, hit.normal, 0.3);
      t.emitSnowballShatter(hit.point, hit.normal, dir.clone().multiplyScalar(8), 0.6, false, false);
      this.hitMarkerTimer = 0.2;
      this.audio.playSnowballImpact(hit.dist, true);
    } else if (hit.type === 'wall') {
      t.addSurfaceSnowSplatter(hit.point, hit.normal, 0.28);
      t.emitSnowballShatter(hit.point, hit.normal, dir.clone().multiplyScalar(8), 0.55, false, false);
      this.audio.playSnowballImpact(hit.dist, true);
    } else if (hit.type === 'bumper') {
      for (const b of t.bumpers) {
        if (Math.hypot(hit.point.x - b.position.x, hit.point.z - b.position.z) <= b.radius + 0.2) b.pulse = 0.75;
      }
      t.emitSnowballShatter(hit.point, hit.normal, dir.clone().multiplyScalar(8), 0.5, false, false);
      this.audio.playSnowballImpact(hit.dist, true);
    } else if (hit.type === 'ground') {
      t.addSurfaceSnowSplatter(hit.point, hit.normal, 0.24);
      t.deformSnowAt(hit.point.x, hit.point.z, 0.03, 0.5);
      t.emitSnowballShatter(hit.point, hit.normal, dir.clone().multiplyScalar(8), 0.55, false, false);
      this.audio.playSnowballImpact(hit.dist, false);
    }
  }

  // ---------------------------------------------------------------- update
  public update(dt: number, input: InputManager, config: CharacterConfig, terrain: SnowTerrain): void {
    this.audio.enabled = config.audioEnabled;
    soundEngine.setMuted(!config.audioEnabled);

    this.matchTimeRemaining = Math.max(0, this.matchTimeRemaining - dt);
    if (this.matchTimeRemaining <= 0) {
      this.endMatch(this.blueScore > this.redScore ? 'BLUE' : this.redScore > this.blueScore ? 'RED' : null);
    }

    if (this.hitMarkerTimer > 0) this.hitMarkerTimer = Math.max(0, this.hitMarkerTimer - dt);
    if (this.calloutTimer > 0) {
      this.calloutTimer = Math.max(0, this.calloutTimer - dt);
      if (this.calloutTimer <= 0) this.latestCallout = null;
    }
    if (this.streakTimeout > 0) {
      this.streakTimeout = Math.max(0, this.streakTimeout - dt);
      if (this.streakTimeout <= 0) this.playerStreak = 0;
    }
    if (this.playerInvulnTimer > 0) this.playerInvulnTimer = Math.max(0, this.playerInvulnTimer - dt);
    this.damagePulse = Math.max(0, this.damagePulse - dt * 1.6);

    if (this.activePowerUp && this.activePowerUp !== 'SHIELD') {
      this.powerUpTimer -= dt;
      if (this.powerUpTimer <= 0) this.activePowerUp = null;
    }

    const canAct = this.playerAlive && !this.playerInRagdoll;

    // ---- ammo type toggle (bullet <-> snowball)
    if (input.ammoToggleJustPressed && canAct) {
      const t = this.fps.toggleAmmoType();
      this.pushCallout(
        t === 'SNOWBALL' ? '❄️ AMUNISI: SNOWBALL' : '🔫 AMUNISI: PELURU',
        t === 'SNOWBALL' ? 'Senjata menembakkan bola salju fisik' : 'Peluru tracer standar',
        t === 'SNOWBALL' ? '#7dd3fc' : '#fbbf24'
      );
    }

    // ---- crouch (smooth)
    const wantCrouch = canAct && input.isCrouchHeld() && this.movement.isGrounded;
    this.crouchAmount = THREE.MathUtils.lerp(this.crouchAmount, wantCrouch ? 1 : 0, 1 - Math.exp(-12 * dt));
    if (this.crouchAmount < 0.004) this.crouchAmount = 0;

    const camDelta = input.getCameraDelta(dt);

    // =========================================================================
    // PLAYER NATURAL RAGDOLL (third-person death cam, same physics as bots)
    // =========================================================================
    const rollHeld = input.isRollHeld();
    if (!this.roll.active) {
      // regenerate roll energy / cooldown while not rolling
      this.roll.update(dt, { x: 0, z: 0, magnitude: 0 }, 0, false, this.movement.position, terrain, [], this.team, this.audio, () => {});
    }
    if (canAct && !this.roll.active && rollHeld && this.roll.canStart() && this.movement.isGrounded) {
      this.startRoll();
    }
    if (!canAct && this.roll.active) {
      this.roll.stop();
    }

    if (this.playerInRagdoll) {
      this.playerRagdollElapsed += dt;
      this.movement.position.x += this.movement.velocity.x * dt;
      this.movement.position.z += this.movement.velocity.z * dt;

      if (!this.playerRagdollGrounded) {
        this.movement.velocity.y -= 18.5 * dt;
        this.movement.position.y += this.movement.velocity.y * dt;
      } else {
        this.playerRagdollGroundElapsed += dt;
        const hSpd = Math.hypot(this.movement.velocity.x, this.movement.velocity.z);
        if (hSpd > 0.01) {
          const nextSpd = Math.max(0, hSpd - 11.5 * dt);
          this.movement.velocity.x = (this.movement.velocity.x / hSpd) * nextSpd;
          this.movement.velocity.z = (this.movement.velocity.z / hSpd) * nextSpd;
        }
      }

      terrain.resolveArenaCollisions(this.movement.position, 0.35);
      const gy = terrain.getHeightAt(this.movement.position.x, this.movement.position.z);
      if (this.movement.position.y <= gy) {
        this.movement.position.y = gy;
        if (!this.playerRagdollGrounded) {
          this.playerRagdollGrounded = true;
          this.playerRagdollGroundElapsed = 0;
          this.movement.velocity.y = 0;
          terrain.deformSnowAt(this.movement.position.x, this.movement.position.z, 0.055, 0.95);
          terrain.emitStopSpray(this.movement.position, this.movement.velocity, 0.85);
          this.audio.playRagdollSnowFall(1.0);
        }
      }

      this.rig.root.position.copy(this.movement.position);
      this.rig.root.rotation.y = this.movement.facingYaw;
      this.animation.applyNaturalRagdoll(
        this.rig,
        this.playerRagdollElapsed,
        this.playerRagdollGrounded,
        this.playerRagdollGroundElapsed,
        this.playerLocalHitFwd,
        this.playerLocalHitRight
      );
      this.rig.updateSecondaryDynamics(dt, this.movement.velocity, 'DAZED', false, false);

      if (this.playerRagdollElapsed >= this.playerRagdollDuration) {
        this.playerInRagdoll = false;
        this.playerAlive = true;
        this.playerHp = this.playerMaxHp;
        this.playerInvulnTimer = 2.0;
        const sp = this.blueBaseSpawn();
        this.movement.position.set(sp.x, sp.y + 1.6, sp.z);
        this.movement.velocity.set(0, -1.0, 0);
        this.movement.isGrounded = false;
        this.rig.root.visible = false;
        this.fps.refillAmmo();
        this.fps.resetLook(0);
        this.pushCallout('BANGKIT DI BASE!', 'Balas dendam timmu! ❄️', '#4ade80');
      }
    } else if (this.playerAlive && this.roll.active) {
      // ---- ROLLING: giant fast snowball, third-person chase camera
      this.roll.update(
        dt,
        input.getMoveInput(),
        this.cameraCtrl.currentYaw,
        rollHeld,
        this.movement.position,
        terrain,
        this.botManager.bots,
        this.team,
        this.audio,
        (bot, dir, spd) => this.handleRollStrike(bot, dir, spd, terrain)
      );
      this.movement.velocity.copy(this.roll.velocity);
      this.movement.isGrounded = true;
      this.rig.root.position.copy(this.movement.position);
      if (!this.roll.active) this.endRoll();
    } else if (this.playerAlive) {
      // ---- look
      if (input.active) this.fps.look(camDelta.dx, camDelta.dy, config.aimSensitivity);

      // ---- power-up pickup
      const picked = terrain.tryPickupPowerUp(this.movement.position, 0.98);
      if (picked) {
        this.audio.playPowerUpPickup();
        this.activePowerUp = picked;
        if (picked === 'TURBO') {
          this.powerUpTimer = 9;
          this.pushCallout('⚡ TURBO BOOTS!', 'Lari lebih cepat 9 detik!', '#facc15');
        } else if (picked === 'MEGA') {
          this.powerUpTimer = 12;
          this.pushCallout('💥 DAMAGE x2!', 'Tembakan 2x lebih mematikan 12 detik!', '#f97316');
        } else if (picked === 'TRIPLE') {
          this.powerUpTimer = 12;
          this.pushCallout('🔥 RAPID FIRE!', 'Kecepatan tembak 1.6x selama 12 detik!', '#a855f7');
        } else {
          this.playerHp = this.playerMaxHp;
          this.powerUpCharges = 1;
          this.pushCallout('🛡️ FROST SHIELD!', 'HP penuh + 1 serangan ditangkis!', '#38bdf8');
        }
      }

      // ---- locomotion (snowball-game movement: run / jump / crouch / acceleration & snow slide)
      const moveInput = input.getMoveInput();
      const turbo = this.activePowerUp === 'TURBO' ? 1.35 : 1.0;
      const crouchFactor = 1 - 0.5 * this.crouchAmount;
      const adsFactor = THREE.MathUtils.lerp(1, 0.66, this.fps.adsBlend);
      const backFactor = moveInput.z < -0.2 ? 0.85 : 1;
      const sprinting =
        input.isRunHeld() &&
        moveInput.z > 0.3 &&
        this.crouchAmount < 0.25 &&
        this.fps.adsBlend < 0.3 &&
        this.movement.isGrounded;

      const fallVyBefore = this.movement.velocity.y;
      this.movement.update(
        dt,
        moveInput,
        input.jumpJustPressed && this.movement.isGrounded && this.crouchAmount < 0.35,
        false,
        sprinting,
        turbo * crouchFactor * adsFactor * backFactor,
        'JOG',
        'MOVEMENT',
        this.fsm.upperState,
        this.fps.gameYaw,
        config,
        terrain
      );
      this.movement.facingYaw = this.fps.gameYaw;
      if (!this.movement.isGrounded) this.lastFallVy = fallVyBefore;

      let landImpact = 0;
      if (this.movement.justJumped) this.audio.playJumpHop();
      if (this.movement.justLanded) {
        landImpact = THREE.MathUtils.clamp(Math.abs(this.lastFallVy) / 6.2, 0.15, 1.45);
        this.audio.playFootstepSnow(0.95);
        terrain.emitStopSpray(this.movement.position, new THREE.Vector3(0, 0, 1), 0.5);
      }
      if (this.movement.justBouncedBumper) {
        this.audio.playBumperBoing();
        this.fps.addTrauma(0.35);
        this.pushCallout('BOING!!', 'Pantulan Stumble Bumper!', '#f43f5e');
      }

      const speed = Math.hypot(this.movement.velocity.x, this.movement.velocity.z);
      this.fsm.updateLocomotion(
        dt,
        speed,
        moveInput.magnitude > 0.05,
        this.movement.isGrounded,
        false,
        false,
        0,
        false,
        0,
        config
      );

      // strafe amount relative to look direction
      const strafeInput = moveInput.x;

      // ---- FPS camera + weapon system (PIGEON port)
      this.fps.update(
        {
          dt,
          position: this.movement.position,
          eyeHeight: THREE.MathUtils.lerp(EYE_STAND, EYE_CROUCH, this.crouchAmount),
          horizSpeed: speed,
          velX: this.movement.velocity.x,
          velZ: this.movement.velocity.z,
          isGrounded: this.movement.isGrounded,
          landImpact,
          crouchBlend: this.crouchAmount,
          sprinting,
          strafeInput,
          fireHeld: input.fireHeld && input.active,
          adsHeld: input.adsHeld,
          fireRateMult: this.activePowerUp === 'TRIPLE' ? 1.6 : 1.0,
        },
        {
          fireJustPressed: input.fireJustPressed && input.active,
          reload: input.reloadJustPressed,
          inspect: input.inspectJustPressed,
          adsToggle: input.adsToggleJustPressed,
          weaponSlot: input.weaponSlotRequest,
        }
      );

      this.updateCrosshairHover();

      this.rig.root.position.copy(this.movement.position);
      this.rig.root.rotation.y = this.movement.facingYaw;
    }

    // ---- camera: third-person chase cam only while ragdolled
    if (!this.isFpsView()) {
      this.cameraCtrl.update(
        dt,
        camDelta.dx,
        camDelta.dy,
        this.movement.position,
        this.movement.velocity,
        this.roll.active ? 'RUN' : this.fsm.locomotionState,
        false,
        false,
        null,
        0,
        config,
        terrain
      );
    }

    // ---- hitboxes (player hitbox shrinks while crouching)
    this.combatantHitboxes.length = 0;
    if (canAct && !this.roll.active && this.playerInvulnTimer <= 0) {
      this.combatantHitboxes.push({
        id: 'player',
        name: 'YOU',
        isPlayer: true,
        teamId: this.team,
        center: new THREE.Vector3(
          this.movement.position.x,
          this.movement.position.y + 0.72 - 0.22 * this.crouchAmount,
          this.movement.position.z
        ),
        radius: 0.46 - 0.08 * this.crouchAmount,
        chestBone: this.rig.chest,
        headBone: this.rig.head,
        pelvisBone: this.rig.pelvis,
      });
    }
    this.botManager.collectHitboxes(this.combatantHitboxes);

    const lb = this.computeLeaderboard();
    const leaderId = lb.length > 0 && lb[0].score > 0 ? lb[0].id : '';

    this.botManager.update(
      dt,
      this.movement.position,
      this.movement.velocity,
      canAct,
      leaderId,
      config,
      terrain,
      this.projectiles,
      this.audio
    );

    this.projectiles.update(
      dt,
      this.movement.position,
      this.combatantHitboxes,
      terrain,
      (hitEv) => this.handleCombatantHit(hitEv, terrain),
      (distToPlayer, hitSolid) => this.audio.playSnowballImpact(distToPlayer, hitSolid),
      (exEv) => this.handleExplosion(exEv, terrain)
    );
  }

  // ---------------------------------------------------------------- combat
  private handleExplosion(ev: ExplosionEvent, terrain: SnowTerrain): void {
    const dPlayer = ev.position.distanceTo(this.movement.position);
    this.audio.playExplosion(dPlayer);
    const blast = THREE.MathUtils.clamp(1.0 - dPlayer / 30, 0, 1);
    if (this.isFpsView()) this.fps.addTrauma(blast * 0.9);
    else this.cameraCtrl.triggerBlastShake(THREE.MathUtils.clamp(1.7 * blast, 0.15, 1.7));

    for (const cb of this.combatantHitboxes) {
      if (cb.teamId === ev.teamId) continue;
      const d = cb.center.distanceTo(ev.position);
      if (d > ev.radius + 0.3) continue;
      const away = cb.center.clone().sub(ev.position);
      away.y = 0;
      if (away.lengthSq() < 0.01) away.set(0, 0, 1);
      away.normalize().multiplyScalar(15 * (1 - 0.35 * Math.min(1, d / ev.radius)));
      this.handleCombatantHit(
        {
          ownerId: ev.ownerId,
          ownerName: ev.ownerName,
          teamId: ev.teamId,
          victimId: cb.id,
          victimName: cb.name,
          impactPos: cb.center.clone(),
          impactVel: away,
          impactNormal: new THREE.Vector3(0, 1, 0),
          hitBone: cb.chestBone,
          throwDistance: 0,
          powerFactor: 1.2,
          isMega: true,
          didCling: false,
          hitstopDuration: 0.05,
          kind: 'ROCKET',
          forceKo: true,
        },
        terrain
      );
    }
  }

  private handleCombatantHit(ev: ProjectileHitEvent, terrain: SnowTerrain): void {
    const isBlast = ev.kind === 'ROCKET';

    // ======================= Enemy hit the Player =======================
    if (ev.victimId === 'player') {
      if (!this.playerAlive || this.playerInRagdoll || this.playerInvulnTimer > 0) return;

      const pushHoriz = new THREE.Vector3(ev.impactVel.x, 0, ev.impactVel.z);
      if (pushHoriz.lengthSq() < 0.001) pushHoriz.set(0, 0, 1);
      pushHoriz.normalize();

      const yaw = this.movement.facingYaw;
      this.playerLocalHitFwd = pushHoriz.x * Math.sin(yaw) + pushHoriz.z * Math.cos(yaw);
      this.playerLocalHitRight = pushHoriz.x * -Math.cos(yaw) + pushHoriz.z * Math.sin(yaw);

      if (!ev.forceKo && this.activePowerUp === 'SHIELD') {
        this.activePowerUp = null;
        this.powerUpCharges = 0;
        this.audio.playBumperBoing();
        this.fps.addTrauma(0.3);
        this.pushCallout('PERISAI MENAHAN!', `Serangan ${ev.ownerName} ditangkis!`, '#38bdf8');
        return;
      }

      this.playerHp = ev.forceKo ? 0 : Math.max(0, this.playerHp - (ev.isMega ? 2 : 1));
      const isKo = this.playerHp <= 0;

      if (!isBlast) this.audio.playDenseSnowBodyHit(1.0, isKo, ev.isMega);
      this.damagePulse = 1;
      this.fps.addTrauma(isKo ? 0.9 : 0.55);

      if (isKo) {
        this.playerAlive = false;
        this.playerInRagdoll = true;
        this.playerRagdollElapsed = 0;
        this.playerRagdollGrounded = false;
        this.playerRagdollGroundElapsed = 0;
        this.playerStreak = 0;
        this.rig.root.visible = true;
        this.rig.resetPose();
        this.cameraCtrl.snapTo(this.fps.gameYaw, -0.12);

        const knockSpd = ev.forceKo ? 8.4 : ev.isMega ? 7.2 : 5.5;
        this.movement.velocity.set(
          pushHoriz.x * knockSpd,
          ev.forceKo ? 3.4 : ev.isMega ? 2.6 : 2.1,
          pushHoriz.z * knockSpd
        );
        this.movement.isGrounded = false;

        const killerBot = this.botManager.findBotById(ev.ownerId);
        if (killerBot) {
          killerBot.kos++;
          killerBot.score += 250;
        }
        this.addTeamKill(ev.teamId);
        this.pushKillFeed(ev.ownerName, 'YOU', false, true, ev.isMega);
        this.pushCallout('JATUH KO!', `Kena serangan ${ev.ownerName}! Bangkit di base...`, '#fb7185');
      } else {
        this.movement.applyKnockback(pushHoriz.clone().multiplyScalar(ev.isMega ? 5.2 : 3.4), 0.2);
        terrain.emitStopSpray(this.movement.position, pushHoriz, 0.5);
      }
      return;
    }

    // ======================= Hit landed on a Bot =======================
    const victimBot = this.botManager.findBotById(ev.victimId);
    if (!victimBot || victimBot.team === ev.teamId) return;

    const wasKo = this.botManager.applyHitToBot(
      victimBot,
      ev.impactVel,
      ev.isMega,
      ev.hitstopDuration,
      terrain,
      ev.forceKo,
      ev.damage,
      ev.knockScale
    );

    if (!isBlast) {
      const distToPlayer = ev.impactPos.distanceTo(this.movement.position);
      this.audio.playDenseSnowBodyHit(
        ev.ownerId === 'player' ? Math.min(8.0, distToPlayer) : distToPlayer,
        wasKo,
        ev.isMega
      );
    }

    if (ev.ownerId === 'player') {
      this.hitMarkerTimer = ev.headshot ? 0.32 : 0.2;
      const headBonus = ev.headshot ? 50 : 0;
      const distBonus = ev.throwDistance >= 18 ? 100 : 0;
      if (wasKo) {
        this.playerKos++;
        this.playerStreak++;
        this.streakTimeout = 6.5;
        const pts = 250 + distBonus + headBonus + (this.playerStreak - 1) * 50;
        this.playerScore += pts;
        this.addTeamKill(ev.teamId);
        this.pushKillFeed('YOU', victimBot.name, true, false, ev.isMega);

        if (!isBlast) {
          if (ev.kind === 'ROLL') {
            this.pushCallout(`STRIKE! 🎳 ${victimBot.name}`, `+${pts} pts • Digulung bola salju!`, '#7dd3fc');
          } else if (ev.headshot) {
            this.pushCallout(`HEADSHOT! 🎯 ${victimBot.name}`, `+${pts} pts`, '#fbbf24');
          } else if (this.playerStreak >= 4) {
            this.pushCallout(`UNSTOPPABLE! (${this.playerStreak}x KO!)`, `+${pts} pts • ${victimBot.name}`, '#facc15');
          } else if (this.playerStreak === 3) {
            this.pushCallout('TRIPLE KO!! 🔥', `+${pts} pts • ${victimBot.name}`, '#f97316');
          } else if (this.playerStreak === 2) {
            this.pushCallout('DOUBLE KO! ⚡', `+${pts} pts • ${victimBot.name}`, '#38bdf8');
          } else if (ev.throwDistance >= 18) {
            this.pushCallout(`SNIPER KO! (${ev.throwDistance.toFixed(0)}m)`, `+${pts} pts • ${victimBot.name}`, '#a855f7');
          } else {
            this.pushCallout(`KO! ${victimBot.name}`, `+${pts} Poin`, '#4ade80');
          }
        }
      } else {
        this.playerScore += 40 + headBonus + distBonus;
      }
    } else if (wasKo) {
      const killerBot = this.botManager.findBotById(ev.ownerId);
      if (killerBot) {
        killerBot.kos++;
        killerBot.score += 220;
      }
      this.addTeamKill(ev.teamId);
      this.pushKillFeed(ev.ownerName, victimBot.name, false, false, ev.isMega);
    }
  }

  private computeLeaderboard(): LeaderboardEntry[] {
    const list: LeaderboardEntry[] = [
      {
        id: 'player',
        name: 'YOU (Player)',
        kos: this.playerKos,
        score: this.playerScore,
        isPlayer: true,
        colorHex: TEAM_HEX.BLUE,
        team: 'BLUE',
      },
    ];
    for (const b of this.botManager.bots) {
      list.push({ id: b.id, name: b.name, kos: b.kos, score: b.score, isPlayer: false, colorHex: b.colorHex, team: b.team });
    }
    list.sort((a, b) => b.score - a.score || b.kos - a.kos);
    return list.slice(0, 6);
  }

  public getTelemetry(isPointerLocked: boolean, config: CharacterConfig): DebugTelemetry {
    void config;
    const projVel = this.projectiles.getLatestVelocity();
    const speed = Math.hypot(this.movement.velocity.x, this.movement.velocity.z);
    const spec = this.fps.spec;
    const ads = this.fps.adsBlend;
    const spread = THREE.MathUtils.clamp(
      (0.2 + this.fps.spreadBloom * 0.7 + Math.min(1, speed / 6) * 0.35) * (1 - ads * 0.85) * (1 - this.crouchAmount * 0.3),
      0,
      1
    );
    const powerRemaining =
      this.activePowerUp === 'SHIELD' ? this.powerUpCharges : this.activePowerUp ? Math.max(0, this.powerUpTimer) : 0;

    return {
      velocity: { x: this.movement.velocity.x, y: this.movement.velocity.y, z: this.movement.velocity.z },
      speed,
      blendSpeed: this.movement.blendSpeed,
      blendDirection: this.movement.blendDirection,
      forwardComponent: this.movement.localForwardRatio,
      locomotionState: this.fsm.locomotionState,
      upperActionState: 'NONE',
      throwPhase: 'NONE',
      directionMode: 'COMBAT',
      baseGait: 'JOG',
      hasSnowball: this.fps.ammoType === 'SNOWBALL',
      chargeRatio: 0,
      throwPowerFactor: 1,
      aimDirection: { x: 0, y: 0, z: 1 },
      aimPitchDeg: THREE.MathUtils.radToDeg(this.fps.pitch),
      projectileVelocity: { x: projVel.x, y: projVel.y, z: projVel.z },
      projectileSpeed: projVel.length(),
      activeProjectiles: this.projectiles.activeCount,
      lastHitInfo: this.projectiles.lastHitDescription,
      pointerLocked: isPointerLocked,
      playerHp: this.playerHp,
      playerMaxHp: this.playerMaxHp,
      playerScore: this.playerScore,
      playerKos: this.playerKos,
      playerStreak: this.playerStreak,
      activePowerUp: this.activePowerUp,
      powerUpRemaining: powerRemaining,
      botAliveCount: this.botManager.countAlive('RED'),
      totalBotCount: 5,
      matchTimeRemaining: this.matchTimeRemaining,
      hitMarkerActive: this.hitMarkerTimer > 0,
      leaderboard: this.computeLeaderboard(),
      killFeed: [...this.killFeed],
      latestCallout: this.latestCallout ? { ...this.latestCallout } : null,
      playerTeam: this.team,
      blueScore: this.blueScore,
      redScore: this.redScore,
      scoreLimit: SCORE_LIMIT,
      alliesAlive: this.botManager.countAlive('BLUE') + (this.playerAlive && !this.playerInRagdoll ? 1 : 0),
      enemiesAlive: this.botManager.countAlive('RED'),
      fpsActive: this.isFpsView(),
      isRolling: this.roll.active,
      rollEnergy: this.roll.energy,
      fpsWeapon: this.fps.weaponId,
      fpsWeaponName: spec.name,
      fpsFireMode: spec.fireMode,
      fpsAmmo: this.fps.ammo,
      fpsMagSize: spec.magSize,
      fpsReloading: this.fps.isReloading,
      fpsAmmoType: this.fps.ammoType,
      fpsAdsBlend: ads,
      fpsSpread: spread,
      fpsScoped: this.fps.isScoped,
      damagePulse: this.damagePulse,
      isCrouching: this.crouchAmount > 0.5,
      crosshairOnEnemy: this.crosshairOnEnemy,
      tests: { ...INITIAL_TESTS },
    };
  }
}
