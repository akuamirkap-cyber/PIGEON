import * as THREE from 'three';
import { CharacterRig } from '../character/CharacterRig';
import { WeaponController } from '../character/WeaponModels';
import {
  CharacterAppearance,
  CharacterConfig,
  LocomotionState,
  PowerUpType,
  TEAM_HEX,
  TeamId,
  UpperActionState,
  WEAPON_STATS,
  WeaponType,
} from '../config/GameConfig';
import { SnowTerrain } from '../world/SnowTerrain';
import { solveBallisticLaunchDirection } from './AimController';
import { AnimationController } from './AnimationController';
import { AudioSystem } from './AudioSystem';
import { IKController } from './IKController';
import { normalizeAngle } from './MovementController';
import { CombatantHitbox, ProjectilePhysics } from './ProjectilePhysics';
import { SnowballController } from './SnowballController';
import { ThrowController } from './ThrowController';

interface BotProfile {
  name: string;
  team: TeamId;
  look: number; // 0..3 = the four snow-kid outfits
}

// 4 allies (BLUE, with the player = 5) vs 5 enemies (RED)
const BOT_ROSTER: BotProfile[] = [
  { name: 'PinguDash', team: 'BLUE', look: 1 },
  { name: 'BobaBean', team: 'BLUE', look: 0 },
  { name: 'MochiPop', team: 'BLUE', look: 3 },
  { name: 'YetiCub', team: 'BLUE', look: 2 },
  { name: 'KingSlush', team: 'RED', look: 0 },
  { name: 'ChibiBlaze', team: 'RED', look: 1 },
  { name: 'FrostNinja', team: 'RED', look: 2 },
  { name: 'SirSlippy', team: 'RED', look: 3 },
  { name: 'TacoTumble', team: 'RED', look: 0 },
];

type BotWeaponPhase = 'NONE' | 'RAISE' | 'FIRING' | 'LOWER';

export interface BotInstance {
  id: string;
  name: string;
  team: TeamId;
  slot: number;
  colorHex: string;
  rig: CharacterRig;
  anim: AnimationController;
  snowball: SnowballController;
  throwCtrl: ThrowController;
  weapon: WeaponController;

  position: THREE.Vector3;
  velocity: THREE.Vector3;
  facingYaw: number;
  blendSpeed: number;
  blendDir: number;

  hp: number;
  maxHp: number;
  kos: number;
  score: number;

  alive: boolean;
  hitstopTimer: number;
  pendingImpulse: THREE.Vector3 | null;

  flinchTimer: number;
  flinchDuration: number;
  localHitPushFwd: number;
  localHitPushRight: number;

  inRagdoll: boolean;
  ragdollElapsed: number;
  ragdollDuration: number;
  ragdollGrounded: boolean;
  ragdollGroundElapsed: number;

  isGrounded: boolean;
  locomotionState: LocomotionState;
  upperState: UpperActionState;

  powerUp: PowerUpType | null;
  powerUpTimer: number;

  // Weapon use (launcher burst / bazooka)
  botWeapon: WeaponType;
  weaponPhase: BotWeaponPhase;
  weaponTimer: number;
  burstLeft: number;
  burstTimer: number;
  bazookaCooldown: number;

  // AI
  targetId: string | null;
  aiDecisionTimer: number;
  strafeSign: number;
  strafeSwitchTimer: number;
  throwCooldown: number;
  jumpCooldown: number;
  wanderGoal: THREE.Vector3;

  tagCanvas: HTMLCanvasElement;
  tagTexture: THREE.CanvasTexture;
  tagSprite: THREE.Sprite;
  lastRenderedHp: number;
}

export class BotManager {
  private readonly scene: THREE.Scene;
  public readonly bots: BotInstance[] = [];
  private readonly weaponIK = new IKController();

  constructor(scene: THREE.Scene, terrain: SnowTerrain) {
    this.scene = scene;
    BOT_ROSTER.forEach((profile, idx) => this.createBot(profile, idx, terrain));
  }

  private teamSpawn(team: TeamId, slot: number, terrain: SnowTerrain): THREE.Vector3 {
    const x = (slot - 2) * 3.4 + (Math.random() - 0.5) * 0.8;
    const z = (team === 'BLUE' ? -25 : 25) + (Math.random() - 0.5) * 1.6;
    return new THREE.Vector3(x, terrain.getHeightAt(x, z), z);
  }

  private createBot(profile: BotProfile, idx: number, terrain: SnowTerrain): void {
    const slot = profile.team === 'BLUE' ? idx + 1 : idx - 4;
    const appearance: CharacterAppearance = {
      look: profile.look,
      teamColor: profile.team === 'BLUE' ? 0x38bdf8 : 0xf87171,
    };

    const rig = new CharacterRig(appearance);
    const spawnPos = this.teamSpawn(profile.team, slot, terrain);
    rig.root.position.copy(spawnPos);
    this.scene.add(rig.root);

    const colorHex = TEAM_HEX[profile.team];
    const { canvas, texture, sprite } = this.createNameplateSprite(profile.name, colorHex, 3, 3);
    sprite.position.set(0, 1.56, 0);
    rig.root.add(sprite);

    const startWithBall = idx % 2 === 0;
    const snowball = new SnowballController(rig, startWithBall);
    const weapon = new WeaponController(rig);

    this.bots.push({
      id: `bot_${idx}`,
      name: profile.name,
      team: profile.team,
      slot,
      colorHex,
      rig,
      anim: new AnimationController(),
      snowball,
      throwCtrl: new ThrowController(),
      weapon,
      position: spawnPos.clone(),
      velocity: new THREE.Vector3(),
      facingYaw: profile.team === 'BLUE' ? 0 : Math.PI,
      blendSpeed: 0,
      blendDir: 0,
      hp: 3,
      maxHp: 3,
      kos: 0,
      score: 0,
      alive: true,
      hitstopTimer: 0,
      pendingImpulse: null,
      flinchTimer: 0,
      flinchDuration: 0.36,
      localHitPushFwd: -1,
      localHitPushRight: 0,
      inRagdoll: false,
      ragdollElapsed: 0,
      ragdollDuration: 2.15,
      ragdollGrounded: false,
      ragdollGroundElapsed: 0,
      isGrounded: true,
      locomotionState: 'IDLE',
      upperState: startWithBall ? 'SNOWBALL_HOLD' : 'NONE',
      powerUp: null,
      powerUpTimer: 0,
      botWeapon: 'SNOWBALL',
      weaponPhase: 'NONE',
      weaponTimer: 0,
      burstLeft: 0,
      burstTimer: 0,
      bazookaCooldown: 6 + Math.random() * 10,
      targetId: null,
      aiDecisionTimer: Math.random() * 0.8,
      strafeSign: Math.random() > 0.5 ? 1 : -1,
      strafeSwitchTimer: 1.2 + Math.random() * 1.5,
      throwCooldown: 1.0 + Math.random() * 1.8,
      jumpCooldown: 1.5 + Math.random() * 3.0,
      wanderGoal: new THREE.Vector3((Math.random() - 0.5) * 24, 0, (Math.random() - 0.5) * 24),
      tagCanvas: canvas,
      tagTexture: texture,
      tagSprite: sprite,
      lastRenderedHp: 3,
    });
  }

  private createNameplateSprite(
    name: string,
    colorHex: string,
    hp: number,
    maxHp: number
  ): { canvas: HTMLCanvasElement; texture: THREE.CanvasTexture; sprite: THREE.Sprite } {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 80;
    this.drawNameplate(canvas, name, colorHex, hp, maxHp);
    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const mat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false });
    const sprite = new THREE.Sprite(mat);
    sprite.scale.set(1.35, 0.42, 1);
    return { canvas, texture, sprite };
  }

  private drawNameplate(canvas: HTMLCanvasElement, name: string, colorHex: string, hp: number, maxHp: number): void {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = 'rgba(15, 23, 42, 0.78)';
    ctx.beginPath();
    ctx.roundRect(28, 8, 200, 34, 14);
    ctx.fill();
    ctx.strokeStyle = colorHex;
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.font = 'bold 20px system-ui, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(name, 128, 26);

    const pipW = 46;
    const gap = 8;
    const totalW = maxHp * pipW + (maxHp - 1) * gap;
    const startX = (canvas.width - totalW) * 0.5;
    for (let i = 0; i < maxHp; i++) {
      ctx.fillStyle = i < hp ? '#4ade80' : 'rgba(30, 41, 59, 0.85)';
      ctx.beginPath();
      ctx.roundRect(startX + i * (pipW + gap), 50, pipW, 14, 6);
      ctx.fill();
    }
  }

  public countAlive(team: TeamId): number {
    let c = 0;
    for (const b of this.bots) {
      if (b.team === team && b.alive && !b.inRagdoll) c++;
    }
    return c;
  }

  public collectHitboxes(out: CombatantHitbox[]): void {
    for (const b of this.bots) {
      if (!b.alive || b.inRagdoll) continue;
      out.push({
        id: b.id,
        name: b.name,
        isPlayer: false,
        teamId: b.team,
        center: new THREE.Vector3(b.position.x, b.position.y + 0.72, b.position.z),
        radius: 0.5,
        chestBone: b.rig.chest,
        headBone: b.rig.head,
        pelvisBone: b.rig.pelvis,
      });
    }
  }

  public findBotById(id: string): BotInstance | undefined {
    return this.bots.find((b) => b.id === id);
  }

  public resetScores(terrain: SnowTerrain): void {
    for (const b of this.bots) {
      b.kos = 0;
      b.score = 0;
      b.hp = b.maxHp;
      b.alive = true;
      b.inRagdoll = false;
      b.hitstopTimer = 0;
      b.pendingImpulse = null;
      b.flinchTimer = 0;
      b.targetId = null;
      b.bazookaCooldown = 6 + Math.random() * 10;
      this.endBotWeapon(b);
      const sp = this.teamSpawn(b.team, b.slot, terrain);
      b.position.copy(sp);
      b.velocity.set(0, 0, 0);
      b.facingYaw = b.team === 'BLUE' ? 0 : Math.PI;
      b.rig.root.visible = true;
      b.tagSprite.visible = true;
      b.lastRenderedHp = -1;
    }
  }

  private endBotWeapon(bot: BotInstance): void {
    bot.weaponPhase = 'NONE';
    bot.botWeapon = 'SNOWBALL';
    bot.burstLeft = 0;
    bot.weapon.setWeapon('SNOWBALL');
  }

  /**
   * Applies a hit to a bot. forceKo (bazooka blast) drops it instantly, bypassing the shield.
   * KO = natural ragdoll tumble onto the snow, then respawn at the team base.
   */
  public applyHitToBot(
    bot: BotInstance,
    impactVel: THREE.Vector3,
    isMega: boolean,
    hitstopDuration: number,
    terrain: SnowTerrain,
    forceKo = false,
    damage?: number,
    knockScale = 1
  ): boolean {
    if (!bot.alive || bot.inRagdoll) return false;

    const pushHoriz = new THREE.Vector3(impactVel.x, 0, impactVel.z);
    if (pushHoriz.lengthSq() < 0.001) pushHoriz.set(0, 0, -1);
    pushHoriz.normalize();

    const charFwdX = Math.sin(bot.facingYaw);
    const charFwdZ = Math.cos(bot.facingYaw);
    const charRightX = -Math.cos(bot.facingYaw);
    const charRightZ = Math.sin(bot.facingYaw);
    bot.localHitPushFwd = pushHoriz.x * charFwdX + pushHoriz.z * charFwdZ;
    bot.localHitPushRight = pushHoriz.x * charRightX + pushHoriz.z * charRightZ;

    this.endBotWeapon(bot);

    if (!forceKo && bot.powerUp === 'SHIELD') {
      bot.powerUp = null;
      bot.powerUpTimer = 0;
      bot.hitstopTimer = hitstopDuration * 0.7;
      bot.flinchDuration = 0.26;
      bot.flinchTimer = bot.flinchDuration;
      bot.pendingImpulse = pushHoriz.clone().multiplyScalar(2.8);
      bot.rig.triggerSquash(0.86);
      return false;
    }

    const dmg = forceKo ? 99 : damage ?? (isMega ? 3 : 1);
    bot.hp = Math.max(0, bot.hp - dmg);
    bot.hitstopTimer = hitstopDuration;
    bot.rig.triggerSquash(0.88);

    if (bot.hp <= 0) {
      bot.alive = false;
      bot.inRagdoll = true;
      bot.ragdollElapsed = 0;
      bot.ragdollDuration = forceKo ? 2.5 : 2.25;
      bot.ragdollGrounded = false;
      bot.ragdollGroundElapsed = 0;
      bot.flinchTimer = 0;
      bot.throwCtrl.phase = 'NONE';

      if (bot.snowball.hasSnowball) {
        const dropPos = bot.snowball.detachAtReleaseSocket(bot.rig);
        terrain.attachClingingSnowball(null, dropPos, new THREE.Vector3(0, 1, 0), false);
      }
      bot.snowball.isPickingUp = false;

      const knockSpeed = (forceKo ? 8.6 : isMega ? 7.4 : 5.6) * knockScale;
      const knockUp = (forceKo ? 3.6 : isMega ? 2.65 : 2.1) * (0.8 + knockScale * 0.35);
      bot.pendingImpulse = new THREE.Vector3(
        pushHoriz.x * knockSpeed,
        knockUp,
        pushHoriz.z * knockSpeed
      );
      return true;
    }

    bot.flinchDuration = 0.36;
    bot.flinchTimer = bot.flinchDuration;
    bot.snowball.isPickingUp = false;
    bot.pendingImpulse = pushHoriz.clone().multiplyScalar(isMega ? 5.2 : 3.9);
    terrain.emitStopSpray(bot.position, pushHoriz, 0.7);
    return false;
  }

  private resolveTarget(
    bot: BotInstance,
    playerPos: THREE.Vector3,
    playerVel: THREE.Vector3,
    playerAlive: boolean
  ): { pos: THREE.Vector3; vel: THREE.Vector3 } | null {
    if (!bot.targetId) return null;
    if (bot.targetId === 'player') {
      if (bot.team === 'RED' && playerAlive) return { pos: playerPos, vel: playerVel };
      return null;
    }
    const rival = this.findBotById(bot.targetId);
    if (rival && rival.alive && !rival.inRagdoll && rival.team !== bot.team) {
      return { pos: rival.position, vel: rival.velocity };
    }
    return null;
  }

  private chooseTargetForBot(bot: BotInstance, playerPos: THREE.Vector3, playerAlive: boolean): void {
    let bestId: string | null = null;
    let bestScore = Infinity;

    for (const other of this.bots) {
      if (other.team === bot.team || !other.alive || other.inRagdoll) continue;
      const d = bot.position.distanceTo(other.position) * (0.85 + Math.random() * 0.3);
      if (d < bestScore) {
        bestScore = d;
        bestId = other.id;
      }
    }

    if (bot.team === 'RED' && playerAlive) {
      const d = bot.position.distanceTo(playerPos) * (0.8 + Math.random() * 0.3);
      if (d < bestScore) {
        bestScore = d;
        bestId = 'player';
      }
    }

    bot.targetId = bestId;
  }

  private fireBotLauncherShot(
    bot: BotInstance,
    targetPos: THREE.Vector3,
    targetVel: THREE.Vector3,
    config: CharacterConfig,
    terrain: SnowTerrain,
    projectiles: ProjectilePhysics,
    audio: AudioSystem,
    playerPos: THREE.Vector3
  ): void {
    const st = WEAPON_STATS.LAUNCHER;
    const muzzle = bot.weapon.getMuzzleWorld(new THREE.Vector3());
    const speed = config.throwPower * st.speedMult * 0.88;
    const dist = muzzle.distanceTo(targetPos);
    const aimPoint = targetPos
      .clone()
      .add(new THREE.Vector3(0, 0.62, 0))
      .addScaledVector(targetVel, (dist / speed) * 0.8);
    aimPoint.x += (Math.random() - 0.5) * 1.5;
    aimPoint.z += (Math.random() - 0.5) * 1.5;
    aimPoint.y += (Math.random() - 0.5) * 0.5;

    const dir = solveBallisticLaunchDirection(muzzle, aimPoint, speed, st.gravity, st.drag);
    projectiles.spawn({
      ownerId: bot.id,
      ownerName: bot.name,
      teamId: bot.team,
      origin: muzzle,
      velocity: dir.clone().multiplyScalar(speed),
      kind: 'BULLET',
      powerFactor: 1,
      isMega: false,
      gravity: st.gravity,
      drag: st.drag,
    });
    bot.weapon.triggerKick(1);
    terrain.emitMuzzlePuff(muzzle, dir);
    if (bot.position.distanceTo(playerPos) < 24) audio.playLauncherShot(bot.position.distanceTo(playerPos));
  }

  private fireBotBazooka(
    bot: BotInstance,
    targetPos: THREE.Vector3,
    targetVel: THREE.Vector3,
    terrain: SnowTerrain,
    projectiles: ProjectilePhysics,
    audio: AudioSystem,
    playerPos: THREE.Vector3
  ): void {
    const st = WEAPON_STATS.BAZOOKA;
    const muzzle = bot.weapon.getMuzzleWorld(new THREE.Vector3());
    const speed = st.speed * 0.9;
    const dist = muzzle.distanceTo(targetPos);
    const aimPoint = targetPos.clone().addScaledVector(targetVel, (dist / speed) * 0.7);
    aimPoint.x += (Math.random() - 0.5) * 1.6;
    aimPoint.z += (Math.random() - 0.5) * 1.6;

    const dir = solveBallisticLaunchDirection(muzzle, aimPoint, speed, st.gravity, st.drag);
    projectiles.spawn({
      ownerId: bot.id,
      ownerName: bot.name,
      teamId: bot.team,
      origin: muzzle,
      velocity: dir.clone().multiplyScalar(speed),
      kind: 'ROCKET',
      powerFactor: 1.2,
      isMega: true,
      gravity: st.gravity,
      drag: st.drag,
    });
    bot.weapon.triggerKick(1.6);
    bot.weapon.setRocketLoaded(false);
    terrain.emitMuzzlePuff(muzzle, dir);
    if (bot.position.distanceTo(playerPos) < 28) audio.playBazookaLaunch(bot.position.distanceTo(playerPos));
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    playerVel: THREE.Vector3,
    playerAlive: boolean,
    leaderId: string,
    config: CharacterConfig,
    terrain: SnowTerrain,
    projectiles: ProjectilePhysics,
    audio: AudioSystem
  ): void {
    // Crowd jostling between standing bots (and the player)
    const minCharSep = 0.72;
    for (let i = 0; i < this.bots.length; i++) {
      const a = this.bots[i];
      if (!a.alive || a.inRagdoll) continue;

      if (playerAlive) {
        const dxP = a.position.x - playerPos.x;
        const dzP = a.position.z - playerPos.z;
        const dP = Math.hypot(dxP, dzP);
        if (dP < minCharSep && dP > 0.001) {
          const push = (minCharSep - dP) * 0.65;
          a.position.x += (dxP / dP) * push;
          a.position.z += (dzP / dP) * push;
        }
      }

      for (let j = i + 1; j < this.bots.length; j++) {
        const b = this.bots[j];
        if (!b.alive || b.inRagdoll) continue;
        const dx = b.position.x - a.position.x;
        const dz = b.position.z - a.position.z;
        const d = Math.hypot(dx, dz);
        if (d < minCharSep && d > 0.001) {
          const halfPush = (minCharSep - d) * 0.5;
          const nx = dx / d;
          const nz = dz / d;
          a.position.x -= nx * halfPush;
          a.position.z -= nz * halfPush;
          b.position.x += nx * halfPush;
          b.position.z += nz * halfPush;
        }
      }
    }

    for (let i = 0; i < this.bots.length; i++) {
      const bot = this.bots[i];

      if (bot.lastRenderedHp !== bot.hp) {
        bot.lastRenderedHp = bot.hp;
        this.drawNameplate(bot.tagCanvas, bot.name, bot.colorHex, bot.hp, bot.maxHp);
        bot.tagTexture.needsUpdate = true;
      }

      // ===== HITSTOP FREEZE =====
      if (bot.hitstopTimer > 0) {
        bot.hitstopTimer -= dt;
        if (bot.hitstopTimer <= 0 && bot.pendingImpulse) {
          if (bot.inRagdoll) {
            bot.velocity.copy(bot.pendingImpulse);
            bot.isGrounded = false;
          } else {
            bot.velocity.x += bot.pendingImpulse.x;
            bot.velocity.z += bot.pendingImpulse.z;
          }
          bot.pendingImpulse = null;
        }
        continue;
      }

      // ===== NATURAL KO RAGDOLL, SLIDE & RESPAWN AT TEAM BASE =====
      if (bot.inRagdoll) {
        bot.tagSprite.visible = false;
        bot.ragdollElapsed += dt;

        bot.position.x += bot.velocity.x * dt;
        bot.position.z += bot.velocity.z * dt;

        if (!bot.ragdollGrounded) {
          bot.velocity.y -= 18.5 * dt;
          bot.position.y += bot.velocity.y * dt;
        } else {
          bot.ragdollGroundElapsed += dt;
          const hSpd = Math.hypot(bot.velocity.x, bot.velocity.z);
          if (hSpd > 0.01) {
            const nextSpd = Math.max(0, hSpd - 11.5 * dt);
            bot.velocity.x = (bot.velocity.x / hSpd) * nextSpd;
            bot.velocity.z = (bot.velocity.z / hSpd) * nextSpd;
          }
        }

        terrain.resolveArenaCollisions(bot.position, 0.35);

        const gy = terrain.getHeightAt(bot.position.x, bot.position.z);
        if (bot.position.y <= gy) {
          bot.position.y = gy;
          if (!bot.ragdollGrounded) {
            bot.ragdollGrounded = true;
            bot.ragdollGroundElapsed = 0;
            bot.velocity.y = 0;
            terrain.deformSnowAt(bot.position.x, bot.position.z, 0.055, 0.95);
            terrain.emitStopSpray(bot.position, bot.velocity, 0.85);
            audio.playRagdollSnowFall(bot.position.distanceTo(playerPos));
          }
        }

        bot.rig.root.position.copy(bot.position);
        bot.rig.root.rotation.y = bot.facingYaw;
        bot.anim.applyNaturalRagdoll(
          bot.rig,
          bot.ragdollElapsed,
          bot.ragdollGrounded,
          bot.ragdollGroundElapsed,
          bot.localHitPushFwd,
          bot.localHitPushRight
        );
        bot.rig.updateSecondaryDynamics(dt, bot.velocity, 'DAZED', false, false);

        if (bot.ragdollElapsed >= bot.ragdollDuration) {
          bot.inRagdoll = false;
          bot.alive = true;
          bot.hp = bot.maxHp;
          bot.tagSprite.visible = true;
          bot.lastRenderedHp = -1;

          const sp = this.teamSpawn(bot.team, bot.slot, terrain);
          bot.position.set(sp.x, sp.y + 3.0, sp.z);
          bot.velocity.set(0, -1.5, 0);
          bot.isGrounded = false;
          bot.facingYaw = bot.team === 'BLUE' ? 0 : Math.PI;
          bot.powerUp = null;
          bot.targetId = null;
          bot.snowball.grantInstantSnowball();
          bot.upperState = 'SNOWBALL_HOLD';
          bot.rig.root.position.copy(bot.position);
          bot.rig.triggerSquash(1.18);
        }
        continue;
      }

      // ===== ACTIVE BOT AI =====
      bot.tagSprite.visible = true;

      if (bot.powerUpTimer > 0) {
        bot.powerUpTimer -= dt;
        if (bot.powerUpTimer <= 0) bot.powerUp = null;
      }

      const grabbed = terrain.tryPickupPowerUp(bot.position, 0.85);
      if (grabbed) {
        bot.powerUp = grabbed;
        bot.powerUpTimer = grabbed === 'TURBO' ? 8.0 : 12.0;
        if (grabbed === 'SHIELD') bot.hp = bot.maxHp;
      }

      if (bot.flinchTimer > 0) bot.flinchTimer = Math.max(0, bot.flinchTimer - dt);
      if (bot.throwCooldown > 0) bot.throwCooldown = Math.max(0, bot.throwCooldown - dt);
      if (bot.jumpCooldown > 0) bot.jumpCooldown = Math.max(0, bot.jumpCooldown - dt);
      if (bot.bazookaCooldown > 0) bot.bazookaCooldown = Math.max(0, bot.bazookaCooldown - dt);

      bot.aiDecisionTimer -= dt;
      if (bot.aiDecisionTimer <= 0) {
        bot.aiDecisionTimer = 0.8 + Math.random() * 0.7;
        this.chooseTargetForBot(bot, playerPos, playerAlive);
      }

      bot.strafeSwitchTimer -= dt;
      if (bot.strafeSwitchTimer <= 0) {
        bot.strafeSwitchTimer = 1.1 + Math.random() * 1.6;
        bot.strafeSign = Math.random() > 0.5 ? 1 : -1;
      }

      const target = this.resolveTarget(bot, playerPos, playerVel, playerAlive);
      if (!target) bot.targetId = null;
      const targetPos = target ? target.pos : null;
      const targetVel = target ? target.vel : new THREE.Vector3();

      const speedMult = bot.powerUp === 'TURBO' ? 1.32 : 1.0;
      const usingWeapon = bot.weaponPhase !== 'NONE';
      let desiredVelX = 0;
      let desiredVelZ = 0;
      let wantCombatFacing = false;
      let targetAimYaw = bot.facingYaw;

      if (bot.flinchTimer <= bot.flinchDuration * 0.45) {
        if (!bot.snowball.hasSnowball && !bot.snowball.isPickingUp && !bot.throwCtrl.isBusy && !usingWeapon) {
          if (bot.isGrounded) {
            bot.snowball.startPickup(bot.position, bot.facingYaw, (x, z) => terrain.getHeightAt(x, z));
            bot.upperState = 'SNOWBALL_PICKUP';
          }
        } else if (targetPos && (bot.snowball.hasSnowball || usingWeapon)) {
          const toTgtX = targetPos.x - bot.position.x;
          const toTgtZ = targetPos.z - bot.position.z;
          const dist = Math.hypot(toTgtX, toTgtZ);
          const dirX = toTgtX / Math.max(0.01, dist);
          const dirZ = toTgtZ / Math.max(0.01, dist);
          const rightX = -dirZ;
          const rightZ = dirX;

          targetAimYaw = Math.atan2(dirX, dirZ);

          if (dist > 18.0 && !usingWeapon) {
            const runSpd = config.runSpeed * 0.92 * speedMult;
            desiredVelX = (dirX * 0.88 + rightX * bot.strafeSign * 0.35) * runSpd;
            desiredVelZ = (dirZ * 0.88 + rightZ * bot.strafeSign * 0.35) * runSpd;
          } else {
            wantCombatFacing = true;
            const pushPull = dist < 7.0 ? -0.45 : dist > 13.5 ? 0.45 : 0.0;
            const strafeSpd = config.jogSpeed * 0.9 * speedMult * (usingWeapon ? 0.6 : 1);
            desiredVelX = (dirX * pushPull + rightX * bot.strafeSign * 0.85) * strafeSpd;
            desiredVelZ = (dirZ * pushPull + rightZ * bot.strafeSign * 0.85) * strafeSpd;

            if (
              bot.isGrounded &&
              bot.jumpCooldown <= 0 &&
              !bot.throwCtrl.isBusy &&
              !usingWeapon &&
              Math.random() < 0.025
            ) {
              bot.velocity.y = config.jumpForce * 0.92;
              bot.isGrounded = false;
              bot.jumpCooldown = 2.8 + Math.random() * 2.5;
              bot.rig.triggerSquash(1.18);
            }

            if (
              bot.throwCooldown <= 0 &&
              !bot.throwCtrl.isBusy &&
              !bot.snowball.isPickingUp &&
              !usingWeapon
            ) {
              const roll = Math.random();
              if (bot.bazookaCooldown <= 0 && dist > 7 && dist < 30 && roll < 0.2) {
                bot.botWeapon = 'BAZOOKA';
                bot.weaponPhase = 'RAISE';
                bot.weaponTimer = 0.8;
                bot.weapon.setWeapon('BAZOOKA');
                bot.weapon.setRocketLoaded(true);
                bot.bazookaCooldown = 16 + Math.random() * 12;
                bot.throwCooldown = 2.6 + Math.random() * 1.6;
              } else if (roll < 0.38 && dist < 26) {
                bot.botWeapon = 'LAUNCHER';
                bot.weaponPhase = 'RAISE';
                bot.weaponTimer = 0.5;
                bot.weapon.setWeapon('LAUNCHER');
                bot.throwCooldown = 2.2 + Math.random() * 1.6;
              } else {
                bot.throwCtrl.startThrowPreparation(config);
                bot.upperState = 'THROW_PREPARATION';
                bot.throwCooldown = (bot.powerUp === 'TURBO' ? 1.05 : 1.65) + Math.random() * 1.25;
              }
            }
          }
        } else {
          const wx = bot.wanderGoal.x - bot.position.x;
          const wz = bot.wanderGoal.z - bot.position.z;
          const wd = Math.hypot(wx, wz);
          if (wd < 2.5) {
            bot.wanderGoal.set((Math.random() - 0.5) * 28, 0, (Math.random() - 0.5) * 28);
          } else {
            desiredVelX = (wx / wd) * config.jogSpeed;
            desiredVelZ = (wz / wd) * config.jogSpeed;
          }
        }
      }

      if (bot.snowball.isPickingUp) {
        desiredVelX *= 0.3;
        desiredVelZ *= 0.3;
      }

      const accelRate = Math.hypot(desiredVelX, desiredVelZ) > 0.1 ? config.acceleration : config.deceleration;
      const dvx = desiredVelX - bot.velocity.x;
      const dvz = desiredVelZ - bot.velocity.z;
      const dvm = Math.hypot(dvx, dvz);
      const step = (bot.flinchTimer > 0 ? config.deceleration * 1.15 : accelRate) * dt;
      if (dvm <= step) {
        bot.velocity.x = desiredVelX;
        bot.velocity.z = desiredVelZ;
      } else if (dvm > 0.0001) {
        bot.velocity.x += (dvx / dvm) * step;
        bot.velocity.z += (dvz / dvm) * step;
      }

      bot.position.x += bot.velocity.x * dt;
      bot.position.z += bot.velocity.z * dt;

      if (!bot.isGrounded) {
        bot.velocity.y -= 18.5 * dt;
        bot.position.y += bot.velocity.y * dt;
      }

      const bumperBounce = terrain.resolveArenaCollisions(bot.position, 0.34);
      if (bumperBounce) {
        bot.velocity.copy(bumperBounce);
        bot.isGrounded = false;
        bot.rig.triggerSquash(1.2);
        if (bot.position.distanceTo(playerPos) < 16) audio.playBumperBoing();
      }

      const gy = terrain.getHeightAt(bot.position.x, bot.position.z);
      if (bot.isGrounded) {
        bot.position.y = gy;
        bot.velocity.y = 0;
      } else if (bot.position.y <= gy) {
        bot.position.y = gy;
        bot.velocity.y = 0;
        bot.isGrounded = true;
        bot.rig.triggerSquash(0.84);
      }

      const speed = Math.hypot(bot.velocity.x, bot.velocity.z);
      if (bot.flinchTimer <= 0) {
        if (wantCombatFacing || bot.throwCtrl.isPreparingOrAccelerating) {
          const diff = normalizeAngle(targetAimYaw - bot.facingYaw);
          bot.facingYaw = normalizeAngle(bot.facingYaw + diff * (1 - Math.exp(-10 * dt)));
        } else if (speed > 0.15) {
          const moveYaw = Math.atan2(bot.velocity.x, bot.velocity.z);
          const diff = normalizeAngle(moveYaw - bot.facingYaw);
          bot.facingYaw = normalizeAngle(bot.facingYaw + diff * (1 - Math.exp(-9 * dt)));
        }
      }

      if (bot.flinchTimer > 0) bot.locomotionState = 'FLINCH';
      else if (!bot.isGrounded) bot.locomotionState = 'JUMP';
      else if (speed > config.jogSpeed + 0.3) bot.locomotionState = 'RUN';
      else if (speed > config.walkSpeed + 0.3) bot.locomotionState = 'JOG';
      else if (speed > 0.2) bot.locomotionState = 'WALK';
      else bot.locomotionState = 'IDLE';

      const targetBlend = THREE.MathUtils.clamp(speed / config.runSpeed, 0, 1);
      bot.blendSpeed = THREE.MathUtils.lerp(bot.blendSpeed, targetBlend, 1 - Math.exp(-12 * dt));

      const charRightX = -Math.cos(bot.facingYaw);
      const charRightZ = Math.sin(bot.facingYaw);
      const charFwdX = Math.sin(bot.facingYaw);
      const charFwdZ = Math.cos(bot.facingYaw);
      const localFwd = speed > 0.15 ? (bot.velocity.x * charFwdX + bot.velocity.z * charFwdZ) / speed : 1;
      const localRight = speed > 0.15 ? (bot.velocity.x * charRightX + bot.velocity.z * charRightZ) / speed : 0;
      bot.blendDir = THREE.MathUtils.lerp(bot.blendDir, localRight, 1 - Math.exp(-12 * dt));

      const isMega = bot.powerUp === 'MEGA';
      bot.snowball.update(
        dt,
        bot.position,
        bot.facingYaw,
        speedMult,
        isMega,
        (x, z) => terrain.getHeightAt(x, z),
        (scoopPos) => {
          if (scoopPos.distanceTo(playerPos) < 14) terrain.emitScoopSnow(scoopPos);
        },
        () => {
          bot.upperState = 'SNOWBALL_HOLD';
        }
      );
      bot.snowball.heldSnowballMesh.visible = bot.snowball.hasSnowball && bot.botWeapon === 'SNOWBALL';

      bot.rig.root.position.copy(bot.position);
      bot.rig.root.rotation.y = bot.facingYaw;

      bot.anim.update(
        dt,
        bot.rig,
        bot.locomotionState === 'FLINCH' ? 'IDLE' : bot.locomotionState,
        bot.upperState,
        0,
        0,
        1,
        1,
        speed,
        bot.blendSpeed,
        bot.blendDir,
        localFwd,
        0,
        0,
        0,
        bot.facingYaw,
        bot.snowball.isPickingUp,
        bot.snowball.pickupProgress,
        bot.snowball.hasSnowball,
        wantCombatFacing,
        bot.throwCtrl.phase,
        bot.throwCtrl.phaseProgress,
        bot.throwCtrl.chargeRatio,
        0,
        0.04,
        config,
        (footEv) => {
          if (footEv.worldPos.distanceTo(playerPos) < 18) {
            terrain.addFootprint(footEv.worldPos, footEv.yaw);
            if (footEv.isRun) {
              terrain.emitFootSnow(footEv.worldPos, new THREE.Vector3(charFwdX, 0, charFwdZ), true);
            }
          }
        }
      );

      if (bot.flinchTimer > 0) {
        const flinchProgress = 1 - bot.flinchTimer / bot.flinchDuration;
        bot.anim.applyDirectionalFlinch(bot.rig, flinchProgress, bot.localHitPushFwd, bot.localHitPushRight);
      }

      // ===== Weapon pose + two-handed IK + firing =====
      if (bot.weaponPhase !== 'NONE') {
        const chestWorld = new THREE.Vector3(bot.position.x, bot.position.y + 0.85, bot.position.z);
        const aimDir = targetPos
          ? targetPos.clone().add(new THREE.Vector3(0, 0.62, 0)).sub(chestWorld).normalize()
          : new THREE.Vector3(charFwdX, 0.05, charFwdZ);
        bot.weapon.aimAt(aimDir);
        bot.weapon.update(dt);
        this.weaponIK.applyWeaponIK(bot.rig, bot.weapon, 1);

        bot.weaponTimer -= dt;
        if (bot.weaponPhase === 'RAISE' && bot.weaponTimer <= 0) {
          if (!targetPos) {
            this.endBotWeapon(bot);
          } else if (bot.botWeapon === 'BAZOOKA') {
            this.fireBotBazooka(bot, targetPos, targetVel, terrain, projectiles, audio, playerPos);
            bot.weaponPhase = 'LOWER';
            bot.weaponTimer = 0.6;
          } else {
            bot.weaponPhase = 'FIRING';
            bot.burstLeft = WEAPON_STATS.LAUNCHER.burstCount;
            bot.burstTimer = 0;
          }
        } else if (bot.weaponPhase === 'FIRING') {
          bot.burstTimer -= dt;
          while (bot.burstLeft > 0 && bot.burstTimer <= 0 && targetPos) {
            this.fireBotLauncherShot(bot, targetPos, targetVel, config, terrain, projectiles, audio, playerPos);
            bot.burstLeft--;
            bot.burstTimer += WEAPON_STATS.LAUNCHER.burstInterval * 1.2;
          }
          if (bot.burstLeft <= 0 || !targetPos) {
            bot.weaponPhase = 'LOWER';
            bot.weaponTimer = 0.3;
          }
        } else if (bot.weaponPhase === 'LOWER' && bot.weaponTimer <= 0) {
          this.endBotWeapon(bot);
        }
      }

      const expr = bot.flinchTimer > 0 ? 'DAZED' : bot.throwCtrl.isBusy || usingWeapon ? 'FIERCE' : 'NORMAL';
      bot.rig.updateSecondaryDynamics(dt, bot.velocity, expr, leaderId === bot.id, bot.powerUp === 'SHIELD');

      // ===== Snowball throw kinetic chain =====
      const holdFakeTrigger = bot.throwCtrl.phase === 'ANTICIPATION' && bot.throwCtrl.chargeTimer < 0.26;
      bot.throwCtrl.update(
        dt,
        holdFakeTrigger,
        config,
        () => {
          bot.upperState = 'THROW';
        },
        (powerFactor) => {
          const releaseOrigin = bot.snowball.detachAtReleaseSocket(bot.rig);
          const botLaunchSpd = config.throwPower * powerFactor * 0.84;
          const distEst = targetPos ? targetPos.distanceTo(releaseOrigin) : 12;
          const tFlight = distEst / Math.max(10, botLaunchSpd);

          const aimCenter = targetPos
            ? targetPos
                .clone()
                .add(new THREE.Vector3(0, 0.65, 0))
                .addScaledVector(targetVel, tFlight * 0.65)
            : bot.position.clone().add(new THREE.Vector3(charFwdX * 12, 0.7, charFwdZ * 12));

          aimCenter.x += (Math.random() - 0.5) * 1.4;
          aimCenter.z += (Math.random() - 0.5) * 1.4;

          const launchDir = solveBallisticLaunchDirection(
            releaseOrigin,
            aimCenter,
            botLaunchSpd,
            config.throwGravity,
            config.throwDrag
          );

          if (bot.powerUp === 'TRIPLE') {
            [-0.12, 0, 0.12].forEach((spread) => {
              const spreadDir = launchDir.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), spread);
              projectiles.spawnSnowball(
                bot.id,
                bot.name,
                bot.team,
                releaseOrigin,
                spreadDir,
                bot.velocity,
                powerFactor,
                false,
                config
              );
            });
          } else {
            projectiles.spawnSnowball(
              bot.id,
              bot.name,
              bot.team,
              releaseOrigin,
              launchDir,
              bot.velocity,
              powerFactor,
              isMega,
              config
            );
          }

          if (bot.position.distanceTo(playerPos) < 16) audio.playThrowWhoosh(powerFactor * 0.8);
        },
        () => {
          bot.upperState = 'NONE';
        }
      );
    }
  }
}
