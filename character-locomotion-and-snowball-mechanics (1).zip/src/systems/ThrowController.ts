import * as THREE from 'three';
import { CharacterConfig, ThrowPhase } from '../config/GameConfig';

export class ThrowController {
  public phase: ThrowPhase = 'NONE';
  public phaseProgress = 0; // 0..1 within current phase

  public chargeTimer = 0;
  public chargeRatio = 0; // 0..1
  public lockedPowerFactor = 1.0;

  private releaseQueued = false;
  private releaseEventFired = false;

  // Athletic kinetic-chain phase timings:
  // Clear windup coil -> explosive sequential whip -> full cross-body follow-through -> smooth recovery
  private readonly minWindupDuration = 0.24;
  private readonly accelerationDuration = 0.175;
  private readonly followThroughDuration = 0.34;
  private readonly recoveryDuration = 0.27;

  public get isBusy(): boolean {
    return this.phase !== 'NONE';
  }

  public get isPreparingOrAccelerating(): boolean {
    return this.phase === 'ANTICIPATION' || this.phase === 'ACCELERATION';
  }

  public computePowerFactor(chargeNorm: number, config: CharacterConfig): number {
    if (chargeNorm <= 0.45) {
      const t = chargeNorm / 0.45;
      return THREE.MathUtils.lerp(config.quickThrowMultiplier, config.normalThrowMultiplier, t);
    }
    const t = (chargeNorm - 0.45) / 0.55;
    return THREE.MathUtils.lerp(config.normalThrowMultiplier, config.maxChargeMultiplier, t);
  }

  public startThrowPreparation(config: CharacterConfig): void {
    this.phase = 'ANTICIPATION';
    this.phaseProgress = 0;
    this.chargeTimer = 0;
    this.chargeRatio = 0;
    this.lockedPowerFactor = config.quickThrowMultiplier;
    this.releaseQueued = false;
    this.releaseEventFired = false;
  }

  public update(
    dt: number,
    throwHeld: boolean,
    config: CharacterConfig,
    onStartAccelerationWhoosh: (powerFactor: number) => void,
    onThrowReleaseEvent: (powerFactor: number) => void,
    onThrowFinished: () => void
  ): void {
    if (this.phase === 'NONE') return;

    if (this.phase === 'ANTICIPATION') {
      this.chargeTimer += dt;
      this.chargeRatio = THREE.MathUtils.clamp(
        this.chargeTimer / Math.max(0.15, config.chargeTime),
        0,
        1
      );
      this.lockedPowerFactor = this.computePowerFactor(this.chargeRatio, config);

      // Base anticipation windup reaches ready coil at minWindupDuration, then deepens with charge
      this.phaseProgress = THREE.MathUtils.clamp(this.chargeTimer / this.minWindupDuration, 0, 1);

      if (!throwHeld) {
        this.releaseQueued = true;
      }

      // Transition to kinetic chain ACCELERATION once windup coil has completed and button is released
      if (this.releaseQueued && this.chargeTimer >= this.minWindupDuration) {
        this.phase = 'ACCELERATION';
        this.phaseProgress = 0;
        onStartAccelerationWhoosh(this.lockedPowerFactor);
      }
      return;
    }

    if (this.phase === 'ACCELERATION') {
      this.phaseProgress += dt / this.accelerationDuration;

      // Exact animation keyframe event: THROW_RELEASE when hand reaches release apex (t = 1.0)
      if (this.phaseProgress >= 1.0 && !this.releaseEventFired) {
        this.releaseEventFired = true;
        this.phase = 'RELEASE';
        onThrowReleaseEvent(this.lockedPowerFactor);

        // Immediately enter FOLLOW_THROUGH preserving leftover fractional progress for zero-stutter continuity
        const overshoot = Math.max(0, this.phaseProgress - 1.0) * (this.accelerationDuration / this.followThroughDuration);
        this.phase = 'FOLLOW_THROUGH';
        this.phaseProgress = Math.min(0.25, overshoot);
      }
      return;
    }

    if (this.phase === 'FOLLOW_THROUGH') {
      const dynamicFollowDur = this.followThroughDuration * (0.94 + this.chargeRatio * 0.16);
      this.phaseProgress += dt / dynamicFollowDur;
      if (this.phaseProgress >= 1.0) {
        this.phase = 'RECOVERY';
        this.phaseProgress = 0;
      }
      return;
    }

    if (this.phase === 'RECOVERY') {
      this.phaseProgress += dt / this.recoveryDuration;
      if (this.phaseProgress >= 1.0) {
        this.phase = 'NONE';
        this.phaseProgress = 0;
        this.chargeTimer = 0;
        this.chargeRatio = 0;
        onThrowFinished();
      }
    }
  }
}
