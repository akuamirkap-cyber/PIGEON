import * as THREE from 'three';
import { CharacterConfig, LocomotionState } from '../config/GameConfig';
import { SnowTerrain } from '../world/SnowTerrain';

export class CameraController {
  public readonly camera: THREE.PerspectiveCamera;

  private targetYaw = 0; // 0 = facing +Z
  private targetPitch = -0.05;

  public currentYaw = 0;
  public currentPitch = -0.05;

  private smoothedPivot = new THREE.Vector3(0, 1.15, 0);
  private pivotLagOffset = new THREE.Vector3();

  private currentDistance = 2.95;
  private currentShoulderOffset = 0.44;
  private currentFov = 54;

  // Clean unshaken camera ray origin & direction for 100% pinpoint crosshair targeting
  public readonly cleanRayOrigin = new THREE.Vector3();
  public readonly cleanRayDir = new THREE.Vector3(0, 0, 1);

  // Spring-damped subtle release impulse
  private impulsePitch = 0;
  private impulsePitchVel = 0;
  private impulseBack = 0;
  private impulseBackVel = 0;

  // Micro Screen Shake (very brief 0.08s, low-amplitude crisp impact feel)
  private microShakeTimer = 0;
  private microShakeDuration = 0.085;
  private microShakeAmp = 0;
  private microShakeSeed = 0;

  private walkBobPhase = 0;

  constructor(aspect: number) {
    this.camera = new THREE.PerspectiveCamera(54, aspect, 0.1, 220);
  }

  public snapTo(yaw: number, pitch: number): void {
    this.targetYaw = yaw;
    this.currentYaw = yaw;
    this.targetPitch = pitch;
    this.currentPitch = pitch;
  }

  public getForwardVector(target = new THREE.Vector3()): THREE.Vector3 {
    const cosP = Math.cos(this.currentPitch);
    return target
      .set(
        Math.sin(this.currentYaw) * cosP,
        Math.sin(this.currentPitch),
        Math.cos(this.currentYaw) * cosP
      )
      .normalize();
  }

  public getHorizontalForward(target = new THREE.Vector3()): THREE.Vector3 {
    return target.set(Math.sin(this.currentYaw), 0, Math.cos(this.currentYaw)).normalize();
  }

  public getHorizontalRight(target = new THREE.Vector3()): THREE.Vector3 {
    return target.set(-Math.cos(this.currentYaw), 0, Math.sin(this.currentYaw)).normalize();
  }

  public triggerReleaseImpulse(powerFactor: number): void {
    this.impulsePitchVel += 0.26 * powerFactor;
    this.impulseBackVel -= 0.42 * powerFactor;
  }

  /**
   * Very short (0.07–0.095s), subtle low-amplitude micro screen shake on enemy snowball impact.
   */
  public triggerBlastShake(intensity = 1.0): void {
    this.microShakeDuration = 0.38;
    this.microShakeTimer = this.microShakeDuration;
    this.microShakeAmp = Math.min(0.11, 0.06 * intensity);
    this.microShakeSeed = Math.random() * 100;
  }

  public triggerMicroShake(intensity = 1.0): void {
    this.microShakeDuration = 0.085;
    this.microShakeDuration = 0.085;
    this.microShakeTimer = this.microShakeDuration;
    this.microShakeAmp = Math.min(0.036, 0.021 * intensity);
    this.microShakeSeed = Math.random() * 100;
  }

  public update(
    dt: number,
    mouseDeltaX: number,
    mouseDeltaY: number,
    characterWorldPos: THREE.Vector3,
    characterVelocity: THREE.Vector3,
    locomotionState: LocomotionState,
    isAimingOrPreparing: boolean,
    isFreeModeMoving: boolean,
    lockAssistPoint: THREE.Vector3 | null,
    crouchAmount: number,
    config: CharacterConfig,
    terrain: SnowTerrain
  ): void {
    // 1. Accumulate mouse input into target angles
    const sens = config.aimSensitivity * (isAimingOrPreparing ? 0.78 : 1.0);
    this.targetYaw -= mouseDeltaX * sens;
    this.targetPitch -= mouseDeltaY * sens;
    this.targetPitch = THREE.MathUtils.clamp(this.targetPitch, -0.68, 0.78);

    // Soft lock-on assist: gently steer the camera toward the locked enemy (mouse input weakens it)
    if (lockAssistPoint) {
      const ax = lockAssistPoint.x - this.cleanRayOrigin.x;
      const ay = lockAssistPoint.y - this.cleanRayOrigin.y;
      const az = lockAssistPoint.z - this.cleanRayOrigin.z;
      const len = Math.max(0.5, Math.hypot(ax, ay, az));
      const desiredYaw = Math.atan2(ax, az);
      const desiredPitch = Math.asin(THREE.MathUtils.clamp(ay / len, -0.9, 0.9));
      const mouseActive = Math.abs(mouseDeltaX) + Math.abs(mouseDeltaY) > 2 ? 0.3 : 1.0;
      const k = 1 - Math.exp(-3.6 * dt * mouseActive);
      let dyaw = desiredYaw - this.targetYaw;
      dyaw = Math.atan2(Math.sin(dyaw), Math.cos(dyaw));
      this.targetYaw += dyaw * k;
      this.targetPitch += (desiredPitch - this.targetPitch) * k;
      this.targetPitch = THREE.MathUtils.clamp(this.targetPitch, -0.68, 0.78);
    }

    if (isFreeModeMoving && !isAimingOrPreparing && Math.abs(mouseDeltaX) < 0.01) {
      const horizSpeed = Math.hypot(characterVelocity.x, characterVelocity.z);
      if (horizSpeed > 0.6) {
        const right = this.getHorizontalRight();
        const lateralSpeed = characterVelocity.dot(right);
        this.targetYaw -= lateralSpeed * 0.075 * dt;
      }
    }

    // 2. Smooth rotational interpolation
    const rotAlpha = 1 - Math.exp(-config.cameraRotationSpeed * dt);
    this.currentYaw = THREE.MathUtils.lerp(this.currentYaw, this.targetYaw, rotAlpha);
    this.currentPitch = THREE.MathUtils.lerp(this.currentPitch, this.targetPitch, rotAlpha);

    // 3. Spring-damped release impulse
    const impSpring = 70;
    const impDamp = 13;
    this.impulsePitchVel += (-impSpring * this.impulsePitch - impDamp * this.impulsePitchVel) * dt;
    this.impulsePitch += this.impulsePitchVel * dt;

    this.impulseBackVel += (-impSpring * this.impulseBack - impDamp * this.impulseBackVel) * dt;
    this.impulseBack += this.impulseBackVel * dt;

    // 4. Smooth positional follow with subtle inertia lag
    if (locomotionState === 'WALK' || locomotionState === 'JOG' || locomotionState === 'RUN') {
      const freq = locomotionState === 'RUN' ? 10.5 : locomotionState === 'JOG' ? 8.2 : 6.0;
      this.walkBobPhase += dt * freq;
    }

    const bobAmp =
      locomotionState === 'RUN'
        ? 0.014
        : locomotionState === 'JOG'
        ? 0.009
        : locomotionState === 'WALK'
        ? 0.005
        : 0;
    const verticalCadence = Math.sin(this.walkBobPhase) * bobAmp;

    const desiredLag = characterVelocity.clone().multiplyScalar(-0.038);
    desiredLag.y = 0;
    if (desiredLag.length() > 0.24) desiredLag.setLength(0.24);
    this.pivotLagOffset.lerp(desiredLag, 1 - Math.exp(-7.0 * dt));

    const idealPivot = new THREE.Vector3(
      characterWorldPos.x + this.pivotLagOffset.x,
      characterWorldPos.y + 1.15 - 0.34 * crouchAmount + verticalCadence,
      characterWorldPos.z + this.pivotLagOffset.z
    );

    const followAlpha = 1 - Math.exp(-config.cameraFollowSpeed * dt);
    this.smoothedPivot.lerp(idealPivot, followAlpha);

    // 5. Framing distances & FOV
    const targetDist = isAimingOrPreparing
      ? 2.15
      : locomotionState === 'RUN' || locomotionState === 'DIVE'
      ? 3.35
      : 2.95;
    const targetShoulder = isAimingOrPreparing ? 0.56 : 0.44;
    const targetFov = isAimingOrPreparing ? 48.0 : locomotionState === 'RUN' ? 57.5 : 54.0;

    const frameAlpha = 1 - Math.exp(-8.0 * dt);
    this.currentDistance = THREE.MathUtils.lerp(this.currentDistance, targetDist, frameAlpha);
    this.currentShoulderOffset = THREE.MathUtils.lerp(
      this.currentShoulderOffset,
      targetShoulder,
      frameAlpha
    );
    this.currentFov = THREE.MathUtils.lerp(this.currentFov, targetFov, frameAlpha);

    if (Math.abs(this.camera.fov - this.currentFov) > 0.02) {
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    // 6. Store clean unshaken camera ray first (for exact crosshair aim!), then apply visual shake
    const cleanFwd = this.getForwardVector(this.cleanRayDir);
    const right = this.getHorizontalRight();
    const shoulderAnchor = this.smoothedPivot
      .clone()
      .addScaledVector(right, this.currentShoulderOffset);
    const baseCamPos = shoulderAnchor.clone().addScaledVector(cleanFwd, -this.currentDistance);

    const groundAtCam = terrain.getHeightAt(baseCamPos.x, baseCamPos.z) + 0.28;
    if (baseCamPos.y < groundAtCam) {
      baseCamPos.y = groundAtCam;
    }
    this.cleanRayOrigin.copy(baseCamPos);

    // Apply subtle release impulse & micro screen shake strictly to visual camera transform
    const visualPitch = this.currentPitch + this.impulsePitch * 0.45;
    const cosVP = Math.cos(visualPitch);
    const visualFwd = new THREE.Vector3(
      Math.sin(this.currentYaw) * cosVP,
      Math.sin(visualPitch),
      Math.cos(this.currentYaw) * cosVP
    ).normalize();

    const visualPos = baseCamPos.clone().addScaledVector(cleanFwd, this.impulseBack * 0.45);

    if (this.microShakeTimer > 0) {
      this.microShakeTimer = Math.max(0, this.microShakeTimer - dt);
      const decay = this.microShakeTimer / this.microShakeDuration;
      const t = (this.microShakeDuration - this.microShakeTimer) * 58 + this.microShakeSeed;
      const sx = Math.sin(t * 1.7) * this.microShakeAmp * decay;
      const sy = Math.cos(t * 2.3) * this.microShakeAmp * decay * 0.85;
      visualPos.addScaledVector(right, sx);
      visualPos.y += sy;
    }

    this.camera.position.copy(visualPos);
    const lookPoint = visualPos.clone().addScaledVector(visualFwd, 25.0);
    this.camera.lookAt(lookPoint);
  }

  public resize(aspect: number): void {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }
}
