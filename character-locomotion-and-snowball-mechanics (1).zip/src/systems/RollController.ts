import * as THREE from 'three';
import { addToonOutline, createToonMat } from '../fps/toon';
import { SnowTerrain } from '../world/SnowTerrain';
import { AudioSystem } from './AudioSystem';
import { BotInstance } from './BotManager';

/**
 * "Snowball roll": the player curls into a giant, fast-rolling snowball.
 * Steering is camera-relative with limited turn rate (momentum), the ball bounces off walls & bumpers,
 * and any enemy it touches is bowled over (knocked far away and downed).
 */
export class RollController {
  public static readonly RADIUS = 0.72;
  public static readonly MAX_SPEED = 11.5;
  public static readonly MIN_STRIKE_SPEED = 3.6;

  public active = false;
  public energy = 1;
  private cooldown = 0;
  private speed = 0;
  private heading = 0;
  private readonly vel = new THREE.Vector3();
  private trailTimer = 0;
  private crunchTimer = 0;

  public readonly group = new THREE.Group();
  private readonly spin = new THREE.Group();

  constructor(scene: THREE.Scene, teamColor: number) {
    const r = RollController.RADIUS;
    const geo = new THREE.IcosahedronGeometry(r, 3);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const z = pos.getZ(i);
      const lump = 1 + 0.035 * Math.sin(x * 9 + y * 7) * Math.cos(z * 8 - y * 5);
      pos.setXYZ(i, x * lump, y * lump, z * lump);
    }
    geo.computeVertexNormals();

    const snowMat = createToonMat(0xf3faff, { rim: 0.9, rimColor: 0xbfe3ff });
    const ball = new THREE.Mesh(geo, snowMat);
    ball.castShadow = true;
    addToonOutline(ball, 0.03, 0x141a38);
    this.spin.add(ball);

    // team-coloured stripes + dull snow patches make the rotation readable
    const stripeMat = createToonMat(teamColor, { rim: 0.6, emissive: teamColor, emissiveIntensity: 0.3 });
    const s1 = new THREE.Mesh(new THREE.TorusGeometry(r * 1.005, 0.045, 8, 40), stripeMat);
    const s2 = new THREE.Mesh(new THREE.TorusGeometry(r * 1.005, 0.045, 8, 40), stripeMat);
    s2.rotation.y = Math.PI / 2;
    this.spin.add(s1, s2);
    const patchMat = createToonMat(0xbfd8ef, { rim: 0.3 });
    const dirs = [
      [0.8, 0.5, 0.3],
      [-0.7, 0.6, 0.35],
      [0.2, -0.8, 0.55],
      [-0.4, -0.3, -0.85],
      [0.6, 0.2, -0.77],
    ];
    for (const d of dirs) {
      const v = new THREE.Vector3(d[0], d[1], d[2]).normalize().multiplyScalar(r * 0.99);
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), patchMat);
      p.position.copy(v);
      p.scale.set(1, 1, 0.5);
      p.lookAt(v.clone().multiplyScalar(2));
      this.spin.add(p);
    }

    this.group.add(this.spin);
    this.group.visible = false;
    scene.add(this.group);
  }

  public get velocity(): THREE.Vector3 {
    return this.vel;
  }

  public canStart(): boolean {
    return !this.active && this.energy > 0.3 && this.cooldown <= 0;
  }

  public start(pos: THREE.Vector3, yaw: number, startVel: THREE.Vector3): void {
    this.active = true;
    this.heading = yaw;
    const horiz = Math.hypot(startVel.x, startVel.z);
    this.speed = Math.max(5.5, horiz);
    this.vel.set(Math.sin(this.heading) * this.speed, 0, Math.cos(this.heading) * this.speed);
    this.group.visible = true;
    this.group.position.set(pos.x, pos.y + RollController.RADIUS, pos.z);
    this.trailTimer = 0;
    this.crunchTimer = 0;
  }

  public stop(): void {
    if (!this.active) return;
    this.active = false;
    this.group.visible = false;
    this.cooldown = 2.2;
  }

  /** Called every frame (also when idle, to regenerate energy). */
  public update(
    dt: number,
    move: { x: number; z: number; magnitude: number },
    camYaw: number,
    holding: boolean,
    position: THREE.Vector3,
    terrain: SnowTerrain,
    bots: BotInstance[],
    team: string,
    audio: AudioSystem,
    onStrike: (bot: BotInstance, dir: THREE.Vector3, speed: number) => void
  ): void {
    if (!this.active) {
      if (this.cooldown > 0) this.cooldown = Math.max(0, this.cooldown - dt);
      this.energy = Math.min(1, this.energy + dt * 0.16);
      return;
    }

    this.energy -= dt * 0.26;
    if (!holding || this.energy <= 0) {
      this.energy = Math.max(0, this.energy);
      this.stop();
      return;
    }

    // ---- steering (camera-relative, limited turn rate => momentum)
    if (move.magnitude > 0.05) {
      const fx = Math.sin(camYaw);
      const fz = Math.cos(camYaw);
      const rx = -Math.cos(camYaw);
      const rz = Math.sin(camYaw);
      const wx = fx * move.z + rx * move.x;
      const wz = fz * move.z + rz * move.x;
      const desired = Math.atan2(wx, wz);
      let diff = desired - this.heading;
      diff = Math.atan2(Math.sin(diff), Math.cos(diff));
      const maxTurn = (2.2 + (1 - this.speed / RollController.MAX_SPEED) * 2.6) * dt;
      this.heading += THREE.MathUtils.clamp(diff, -maxTurn, maxTurn);
    }

    // ---- speed: accelerate fast, roll downhill faster
    const n = terrain.getNormalAt(position.x, position.z);
    const dirX = Math.sin(this.heading);
    const dirZ = Math.cos(this.heading);
    const slope = -(n.x * dirX + n.z * dirZ);
    this.speed = Math.min(RollController.MAX_SPEED + 2.5, this.speed + (9 + slope * 14) * dt);
    this.speed = Math.max(4.5, Math.min(this.speed, RollController.MAX_SPEED + slope * 4));
    this.vel.set(dirX * this.speed, 0, dirZ * this.speed);

    // ---- move + collisions
    const intended = new THREE.Vector3(position.x + this.vel.x * dt, 0, position.z + this.vel.z * dt);
    position.x = intended.x;
    position.z = intended.z;
    const bounce = terrain.resolveArenaCollisions(position, RollController.RADIUS * 0.85);
    if (bounce) {
      this.heading = Math.atan2(bounce.x, bounce.z);
      this.speed = Math.max(this.speed * 0.85, 7.5);
      audio.playBumperBoing();
    } else {
      const push = new THREE.Vector3(position.x - intended.x, 0, position.z - intended.z);
      if (push.lengthSq() > 0.0004) {
        // wall / fence: reflect with some energy loss
        push.normalize();
        const vdot = this.vel.x * push.x + this.vel.z * push.z;
        if (vdot < 0) {
          this.vel.x -= 1.5 * vdot * push.x;
          this.vel.z -= 1.5 * vdot * push.z;
          this.heading = Math.atan2(this.vel.x, this.vel.z);
          this.speed *= 0.78;
          terrain.emitStopSpray(position, push, 1.0);
          audio.playSnowCrunch(0.9);
        }
      }
    }
    position.y = terrain.getHeightAt(position.x, position.z);

    // ---- bowl over enemies
    const dir = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
    for (const bot of bots) {
      if (bot.team === team || !bot.alive || bot.inRagdoll) continue;
      const d = Math.hypot(bot.position.x - position.x, bot.position.z - position.z);
      if (d < RollController.RADIUS + 0.42 && this.speed > RollController.MIN_STRIKE_SPEED) {
        onStrike(bot, dir, this.speed);
        this.speed *= 0.93;
      }
    }

    // ---- visuals: roll the ball, snow trail, crunch
    const r = RollController.RADIUS;
    this.group.position.set(position.x, position.y + r, position.z);
    const axis = new THREE.Vector3(dir.z, 0, -dir.x);
    if (axis.lengthSq() > 0.0001) {
      axis.normalize();
      const q = new THREE.Quaternion().setFromAxisAngle(axis, (this.speed * dt) / r);
      this.spin.quaternion.premultiply(q);
    }
    this.trailTimer -= dt;
    if (this.trailTimer <= 0) {
      this.trailTimer = 0.05;
      terrain.emitFootSnow(position, dir, true);
      terrain.deformSnowAt(position.x, position.z, 0.05, 0.95);
    }
    this.crunchTimer -= dt;
    if (this.crunchTimer <= 0) {
      this.crunchTimer = 0.2;
      audio.playSnowCrunch(0.55);
    }
  }
}
