import * as THREE from 'three';
import { CharacterRig } from '../character/CharacterRig';

export class SnowballController {
  public hasSnowball = false;
  public isPickingUp = false;
  public pickupProgress = 0; // 0..1
  public basePickupDuration = 0.48;
  private scoopTriggeredInCurrentPickup = false;

  public readonly heldSnowballMesh: THREE.Mesh;
  private readonly snowballMat: THREE.MeshStandardMaterial;
  public readonly scoopWorldTarget = new THREE.Vector3();

  constructor(rig: CharacterRig, startWithSnowball = false) {
    const geo = new THREE.IcosahedronGeometry(0.088, 2);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i);
      const vy = pos.getY(i);
      const vz = pos.getZ(i);
      const lump = 1 + 0.07 * Math.sin(vx * 35) * Math.cos(vy * 32 + vz * 29);
      pos.setXYZ(i, vx * lump, vy * lump, vz * lump);
    }
    geo.computeVertexNormals();

    this.snowballMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.72,
      metalness: 0.03,
    });

    this.heldSnowballMesh = new THREE.Mesh(geo, this.snowballMat);
    this.heldSnowballMesh.castShadow = true;
    this.heldSnowballMesh.receiveShadow = true;
    this.heldSnowballMesh.visible = startWithSnowball;
    this.hasSnowball = startWithSnowball;

    rig.snowballSocket.add(this.heldSnowballMesh);
  }

  public grantInstantSnowball(): void {
    this.isPickingUp = false;
    this.pickupProgress = 0;
    this.hasSnowball = true;
    this.heldSnowballMesh.visible = true;
    this.heldSnowballMesh.scale.setScalar(1.0);
  }

  public setMegaAppearance(isMega: boolean): void {
    if (!this.isPickingUp && this.hasSnowball) {
      this.heldSnowballMesh.scale.setScalar(isMega ? 2.0 : 1.0);
    }
    if (isMega) {
      this.snowballMat.color.setHex(0xe0f2fe);
      this.snowballMat.emissive.setHex(0x38bdf8);
      this.snowballMat.emissiveIntensity = 0.35;
    } else {
      this.snowballMat.color.setHex(0xffffff);
      this.snowballMat.emissive.setHex(0x000000);
      this.snowballMat.emissiveIntensity = 0.0;
    }
  }

  public canStartPickup(isThrowing: boolean): boolean {
    return !this.hasSnowball && !this.isPickingUp && !isThrowing;
  }

  public startPickup(
    characterPos: THREE.Vector3,
    facingYaw: number,
    groundHeightFn: (x: number, z: number) => number
  ): void {
    this.isPickingUp = true;
    this.pickupProgress = 0;
    this.scoopTriggeredInCurrentPickup = false;

    const fwdX = Math.sin(facingYaw);
    const fwdZ = Math.cos(facingYaw);
    const rightX = -Math.cos(facingYaw);
    const rightZ = Math.sin(facingYaw);

    const sx = characterPos.x + fwdX * 0.3 + rightX * 0.22;
    const sz = characterPos.z + fwdZ * 0.3 + rightZ * 0.22;
    const sy = groundHeightFn(sx, sz) + 0.04;
    this.scoopWorldTarget.set(sx, sy, sz);
  }

  public update(
    dt: number,
    characterPos: THREE.Vector3,
    facingYaw: number,
    speedMultiplier: number,
    isMega: boolean,
    groundHeightFn: (x: number, z: number) => number,
    onSnowScoopEvent: (scoopPos: THREE.Vector3) => void,
    onPickupComplete: () => void
  ): void {
    if (!this.isPickingUp) {
      this.setMegaAppearance(isMega);
      return;
    }

    const effDuration = this.basePickupDuration / Math.max(0.5, speedMultiplier);
    this.pickupProgress += dt / effDuration;

    if (this.pickupProgress < 0.5) {
      const fwdX = Math.sin(facingYaw);
      const fwdZ = Math.cos(facingYaw);
      const rightX = -Math.cos(facingYaw);
      const rightZ = Math.sin(facingYaw);
      const sx = characterPos.x + fwdX * 0.3 + rightX * 0.22;
      const sz = characterPos.z + fwdZ * 0.3 + rightZ * 0.22;
      this.scoopWorldTarget.set(sx, groundHeightFn(sx, sz) + 0.04, sz);
    }

    const targetFinalScale = isMega ? 2.0 : 1.0;

    if (!this.scoopTriggeredInCurrentPickup && this.pickupProgress >= 0.44) {
      this.scoopTriggeredInCurrentPickup = true;
      this.hasSnowball = true;
      this.heldSnowballMesh.visible = true;
      this.heldSnowballMesh.scale.setScalar(0.35 * targetFinalScale);
      onSnowScoopEvent(this.scoopWorldTarget.clone());
    }

    if (this.scoopTriggeredInCurrentPickup) {
      const packT = THREE.MathUtils.clamp((this.pickupProgress - 0.44) / 0.34, 0, 1);
      const s = (0.35 + 0.65 * packT) * targetFinalScale;
      this.heldSnowballMesh.scale.setScalar(s);
    }

    if (this.pickupProgress >= 1.0) {
      this.isPickingUp = false;
      this.pickupProgress = 0;
      this.heldSnowballMesh.scale.setScalar(targetFinalScale);
      onPickupComplete();
    }
  }

  public detachAtReleaseSocket(rig: CharacterRig, outWorldPos = new THREE.Vector3()): THREE.Vector3 {
    rig.root.updateMatrixWorld(true);
    rig.snowballSocket.getWorldPosition(outWorldPos);
    this.hasSnowball = false;
    this.heldSnowballMesh.visible = false;
    return outWorldPos;
  }
}
