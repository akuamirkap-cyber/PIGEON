import * as THREE from 'three';
import { SnowTerrain } from '../world/SnowTerrain';
import { normalizeAngle } from './MovementController';
import { CombatantHitbox } from './ProjectilePhysics';

function raySphereDistance(
  origin: THREE.Vector3,
  dir: THREE.Vector3,
  center: THREE.Vector3,
  radius: number
): number | null {
  const ocX = origin.x - center.x;
  const ocY = origin.y - center.y;
  const ocZ = origin.z - center.z;
  const b = ocX * dir.x + ocY * dir.y + ocZ * dir.z;
  const c = ocX * ocX + ocY * ocY + ocZ * ocZ - radius * radius;
  const disc = b * b - c;
  if (disc < 0) return null;
  const sqrtD = Math.sqrt(disc);
  const t1 = -b - sqrtD;
  if (t1 > 0.5) return t1;
  const t2 = -b + sqrtD;
  if (t2 > 0.5) return t2;
  return null;
}

/**
 * Exact iterative ballistic solver accounting for both gravity AND quadratic aerodynamic drag,
 * ensuring high-velocity snowballs pass dead-center through targetPoint!
 */
export function solveBallisticLaunchDirection(
  origin: THREE.Vector3,
  targetPoint: THREE.Vector3,
  launchSpeed: number,
  gravity: number,
  drag: number,
  outDir = new THREE.Vector3()
): THREE.Vector3 {
  const delta = targetPoint.clone().sub(origin);
  const totalDist = delta.length();
  if (totalDist < 0.25) {
    return outDir.copy(delta).normalize();
  }

  // Initial aim estimate with analytical gravity + drag time compensation
  const aimPoint = targetPoint.clone();
  const simPos = new THREE.Vector3();
  const simVel = new THREE.Vector3();

  // 4-pass iterative trajectory refinement
  for (let iter = 0; iter < 4; iter++) {
    outDir.copy(aimPoint).sub(origin).normalize();
    simPos.copy(origin);
    simVel.copy(outDir).multiplyScalar(launchSpeed);

    // Estimate flight time until horizontal distance matches target
    const targetHoriz = Math.hypot(delta.x, delta.z);
    const stepDt = 0.012;
    let reached = false;

    for (let s = 0; s < 180; s++) {
      const spd = simVel.length();
      simVel.x -= drag * spd * simVel.x * stepDt;
      simVel.y -= (gravity + drag * spd * simVel.y) * stepDt;
      simVel.z -= drag * spd * simVel.z * stepDt;
      simPos.addScaledVector(simVel, stepDt);

      const curHoriz = Math.hypot(simPos.x - origin.x, simPos.z - origin.z);
      if (curHoriz >= targetHoriz) {
        // Measure vertical & lateral error at target plane and compensate aimPoint!
        const errY = targetPoint.y - simPos.y;
        aimPoint.y += errY;
        reached = true;
        break;
      }
    }

    if (!reached) break;
  }

  // Clamp extreme vertical lob if target is unrealistically far
  const maxLoftY = targetPoint.y + totalDist * 0.45;
  aimPoint.y = Math.min(aimPoint.y, maxLoftY);

  return outDir.copy(aimPoint).sub(origin).normalize();
}

export class AimController {
  public readonly targetPoint = new THREE.Vector3();
  public lockedTargetId: string | null = null;
  public readonly throwDirection = new THREE.Vector3(0, 0, 1);
  public aimYawOffset = 0;
  public aimPitch = 0;

  private trajectoryLine: THREE.Line;
  private landingMarker: THREE.Mesh;
  private readonly maxSimSteps = 56;
  private readonly linePoints: THREE.Vector3[] = [];

  constructor(scene: THREE.Scene) {
    for (let i = 0; i < this.maxSimSteps; i++) {
      this.linePoints.push(new THREE.Vector3());
    }

    const lineGeo = new THREE.BufferGeometry().setFromPoints(this.linePoints);
    const lineMat = new THREE.LineDashedMaterial({
      color: 0x38bdf8,
      dashSize: 0.28,
      gapSize: 0.14,
      transparent: true,
      opacity: 0.88,
    });
    this.trajectoryLine = new THREE.Line(lineGeo, lineMat);
    this.trajectoryLine.computeLineDistances();
    this.trajectoryLine.visible = false;
    this.trajectoryLine.frustumCulled = false;

    const ringGeo = new THREE.RingGeometry(0.16, 0.27, 24);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
    });
    this.landingMarker = new THREE.Mesh(ringGeo, ringMat);
    this.landingMarker.visible = false;

    scene.add(this.trajectoryLine);
    scene.add(this.landingMarker);
  }

  public update(
    cameraRayOrigin: THREE.Vector3,
    cameraRayDir: THREE.Vector3,
    cameraYaw: number,
    characterFacingYaw: number,
    estimatedReleaseOrigin: THREE.Vector3,
    effectiveThrowSpeed: number,
    showPreview: boolean,
    botHitboxes: CombatantHitbox[],
    gravity: number,
    drag: number,
    lockedPoint: THREE.Vector3 | null,
    terrain: SnowTerrain
  ): void {
    // 1. Exact analytical raycast along center crosshair!
    let bestDist = 48.0;
    this.lockedTargetId = null;

    // 1A) Exact Ray-Sphere against all alive Bots (slight magnetism +0.06m on reticle for crisp targeting)
    for (const cb of botHitboxes) {
      if (cb.isPlayer) continue;
      const dHit = raySphereDistance(cameraRayOrigin, cameraRayDir, cb.center, cb.radius + 0.08);
      if (dHit !== null && dHit > 1.8 && dHit < bestDist) {
        bestDist = dHit;
        this.lockedTargetId = cb.id;
      }
    }

    // 1B) Exact Ray-Sphere against Snowman targets
    for (const t of terrain.targets) {
      const dHit = raySphereDistance(cameraRayOrigin, cameraRayDir, t.hitCenter, t.hitRadius + 0.05);
      if (dHit !== null && dHit > 1.8 && dHit < bestDist) {
        bestDist = dHit;
        this.lockedTargetId = null;
      }
    }

    // 1C) Exact Ray-OBB against Snow Fort Walls
    const wallHit = terrain.raycastObstacleWalls(cameraRayOrigin, cameraRayDir, bestDist);
    if (wallHit && wallHit.distance > 1.8 && wallHit.distance < bestDist) {
      bestDist = wallHit.distance;
      this.lockedTargetId = null;
    }

    // 1D) Fine Raymarch + Binary Search against Snow Terrain
    const step = 0.28;
    const tempPt = new THREE.Vector3();
    for (let d = 2.2; d <= bestDist; d += step) {
      tempPt.copy(cameraRayOrigin).addScaledVector(cameraRayDir, d);
      const gy = terrain.getHeightAt(tempPt.x, tempPt.z);
      if (tempPt.y <= gy) {
        // 6-iteration binary search for sub-centimeter terrain intersection!
        let lo = d - step;
        let hi = d;
        for (let b = 0; b < 6; b++) {
          const mid = (lo + hi) * 0.5;
          tempPt.copy(cameraRayOrigin).addScaledVector(cameraRayDir, mid);
          if (tempPt.y <= terrain.getHeightAt(tempPt.x, tempPt.z)) {
            hi = mid;
          } else {
            lo = mid;
          }
        }
        bestDist = (lo + hi) * 0.5;
        this.lockedTargetId = null;
        break;
      }
    }

    this.targetPoint.copy(cameraRayOrigin).addScaledVector(cameraRayDir, bestDist);

    // If locked onto a bot's outer sphere surface, bias target slightly toward bot's core center for dead-center hits!
    if (this.lockedTargetId) {
      const lockedCb = botHitboxes.find((c) => c.id === this.lockedTargetId);
      if (lockedCb) {
        this.targetPoint.lerp(lockedCb.center, 0.55);
      }
    }

    if (lockedPoint) {
      this.targetPoint.copy(lockedPoint);
    }

    // 2. Solve Exact Drag+Gravity Ballistic Launch Direction from estimatedReleaseOrigin -> targetPoint
    solveBallisticLaunchDirection(
      estimatedReleaseOrigin,
      this.targetPoint,
      effectiveThrowSpeed,
      gravity,
      drag,
      this.throwDirection
    );

    // 3. Relative aim angles for Upper Body Additive Layer & Hand IK
    const rawYawDiff = normalizeAngle(cameraYaw - characterFacingYaw);
    this.aimYawOffset = THREE.MathUtils.clamp(rawYawDiff, -1.15, 1.15);
    this.aimPitch = THREE.MathUtils.clamp(
      Math.asin(THREE.MathUtils.clamp(this.throwDirection.y, -0.85, 0.85)),
      -0.75,
      0.85
    );

    // 4. Trajectory Prediction Line (when aiming or charging)
    if (!showPreview) {
      this.trajectoryLine.visible = false;
      this.landingMarker.visible = false;
      return;
    }

    this.trajectoryLine.visible = true;
    const simPos = estimatedReleaseOrigin.clone();
    const simVel = this.throwDirection.clone().multiplyScalar(effectiveThrowSpeed);
    const simDt = 0.022;

    let impactPos: THREE.Vector3 | null = null;
    const impactNormal = new THREE.Vector3(0, 1, 0);

    for (let i = 0; i < this.maxSimSteps; i++) {
      this.linePoints[i].copy(simPos);

      if (impactPos) {
        this.linePoints[i].copy(impactPos);
        continue;
      }

      const speed = simVel.length();
      simVel.x -= drag * speed * simVel.x * simDt;
      simVel.y -= (gravity + drag * speed * simVel.y) * simDt;
      simVel.z -= drag * speed * simVel.z * simDt;

      const prevPos = simPos.clone();
      simPos.addScaledVector(simVel, simDt);

      // Check bot hitboxes
      for (const cb of botHitboxes) {
        if (!cb.isPlayer && simPos.distanceTo(cb.center) <= cb.radius + 0.08) {
          impactPos = simPos.clone();
          impactNormal.copy(simPos).sub(cb.center).normalize();
          break;
        }
      }

      // Check wall hit
      if (!impactPos) {
        const segVec = simPos.clone().sub(prevPos);
        const segLen = segVec.length();
        if (segLen > 0.001) {
          const wHit = terrain.raycastObstacleWalls(prevPos, segVec.divideScalar(segLen), segLen);
          if (wHit) {
            impactPos = wHit.point;
            impactNormal.copy(wHit.normal);
          }
        }
      }

      // Check snowman target hit
      if (!impactPos) {
        for (const t of terrain.targets) {
          if (simPos.distanceTo(t.hitCenter) <= t.hitRadius) {
            impactPos = simPos.clone();
            impactNormal.copy(simPos).sub(t.hitCenter).normalize();
            break;
          }
        }
      }

      // Check terrain hit
      if (!impactPos) {
        const gy = terrain.getHeightAt(simPos.x, simPos.z);
        if (simPos.y <= gy + 0.04) {
          impactPos = new THREE.Vector3(simPos.x, gy + 0.025, simPos.z);
          terrain.getNormalAt(simPos.x, simPos.z, impactNormal);
        }
      }
    }

    const posAttr = this.trajectoryLine.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < this.maxSimSteps; i++) {
      posAttr.setXYZ(i, this.linePoints[i].x, this.linePoints[i].y, this.linePoints[i].z);
    }
    posAttr.needsUpdate = true;
    this.trajectoryLine.computeLineDistances();

    if (impactPos) {
      this.landingMarker.visible = true;
      this.landingMarker.position.copy(impactPos);
      const up = new THREE.Vector3(0, 1, 0);
      this.landingMarker.quaternion.setFromUnitVectors(up, impactNormal);
    } else {
      this.landingMarker.visible = false;
    }
  }
}
