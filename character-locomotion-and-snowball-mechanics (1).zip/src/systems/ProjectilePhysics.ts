import * as THREE from 'three';
import { CharacterConfig, TeamId, WEAPON_STATS } from '../config/GameConfig';
import { RangeTarget, SnowTerrain } from '../world/SnowTerrain';

export type ProjectileKind = 'BALL' | 'BULLET' | 'ROCKET' | 'ROLL';

export interface CombatantHitbox {
  id: string;
  name: string;
  isPlayer: boolean;
  teamId: TeamId;
  center: THREE.Vector3;
  radius: number;
  chestBone?: THREE.Object3D;
  headBone?: THREE.Object3D;
  pelvisBone?: THREE.Object3D;
}

export interface ProjectileHitEvent {
  ownerId: string;
  ownerName: string;
  teamId: TeamId;
  victimId: string;
  victimName: string;
  impactPos: THREE.Vector3;
  impactVel: THREE.Vector3;
  impactNormal: THREE.Vector3;
  hitBone?: THREE.Object3D;
  throwDistance: number;
  powerFactor: number;
  isMega: boolean;
  didCling: boolean;
  hitstopDuration: number;
  kind: ProjectileKind;
  forceKo: boolean;
  damage?: number;
  headshot?: boolean;
  knockScale?: number;
}

export interface ExplosionEvent {
  ownerId: string;
  ownerName: string;
  teamId: TeamId;
  position: THREE.Vector3;
  radius: number;
}

export interface SpawnParams {
  ownerId: string;
  ownerName: string;
  teamId: TeamId;
  origin: THREE.Vector3;
  velocity: THREE.Vector3;
  kind: ProjectileKind;
  powerFactor: number;
  isMega: boolean;
  gravity: number;
  drag: number;
  damage?: number;
  headMult?: number;
}

interface ActiveProjectile {
  ownerId: string;
  ownerName: string;
  teamId: TeamId;
  kind: ProjectileKind;
  object: THREE.Object3D;
  trailLine: THREE.Line;
  trailPoints: THREE.Vector3[];
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  spawnOrigin: THREE.Vector3;
  powerFactor: number;
  isMega: boolean;
  gravity: number;
  drag: number;
  age: number;
  radius: number;
  inHitstop: boolean;
  hitstopTimer: number;
  didClingOnFinish: boolean;
  clingTargetBone: THREE.Object3D | null;
  impactNormal: THREE.Vector3;
  damage: number;
  headMult: number;
}

function segmentSphereHit(
  p0: THREE.Vector3,
  p1: THREE.Vector3,
  center: THREE.Vector3,
  combinedRadius: number,
  outHitPoint: THREE.Vector3
): boolean {
  const seg = p1.clone().sub(p0);
  const segLenSq = seg.lengthSq();
  if (segLenSq < 1e-8) {
    if (p0.distanceTo(center) <= combinedRadius) {
      outHitPoint.copy(p0);
      return true;
    }
    return false;
  }
  const toCenter = center.clone().sub(p0);
  const t = THREE.MathUtils.clamp(toCenter.dot(seg) / segLenSq, 0, 1);
  outHitPoint.copy(p0).addScaledVector(seg, t);
  return outHitPoint.distanceTo(center) <= combinedRadius;
}

export class ProjectilePhysics {
  private readonly group = new THREE.Group();
  private activeProjectiles: ActiveProjectile[] = [];
  private snowballGeo: THREE.IcosahedronGeometry;
  private normalMat: THREE.MeshStandardMaterial;
  private megaMat: THREE.MeshStandardMaterial;
  private bulletMat: THREE.MeshStandardMaterial;
  private normalTrailMat: THREE.LineBasicMaterial;
  private megaTrailMat: THREE.LineBasicMaterial;
  private bulletTrailMat: THREE.LineBasicMaterial;
  private rocketTrailMat: THREE.LineBasicMaterial;

  private rocketBodyGeo: THREE.BufferGeometry;
  private rocketNoseGeo: THREE.BufferGeometry;
  private rocketFinGeo: THREE.BoxGeometry;
  private rocketBodyMat: THREE.MeshStandardMaterial;
  private rocketNoseMat: THREE.MeshStandardMaterial;
  private rocketFinMat: THREE.MeshStandardMaterial;
  private rocketFlameMat: THREE.MeshBasicMaterial;

  public readonly lastLaunchVelocity = new THREE.Vector3();
  public lastHitDescription = 'Siap lempar!';
  public hasCompletedBallisticFlight = false;

  constructor(scene: THREE.Scene) {
    this.snowballGeo = new THREE.IcosahedronGeometry(0.095, 2);
    this.normalMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.72, metalness: 0.03 });
    this.megaMat = new THREE.MeshStandardMaterial({
      color: 0xe0f2fe,
      emissive: 0x0284c7,
      emissiveIntensity: 0.45,
      roughness: 0.35,
    });
    this.bulletMat = new THREE.MeshStandardMaterial({
      color: 0xf0fbff,
      emissive: 0x22d3ee,
      emissiveIntensity: 0.35,
      roughness: 0.5,
    });
    this.normalTrailMat = new THREE.LineBasicMaterial({ color: 0xe0f2fe, transparent: true, opacity: 0.72 });
    this.megaTrailMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.92 });
    this.bulletTrailMat = new THREE.LineBasicMaterial({ color: 0x67e8f9, transparent: true, opacity: 0.85 });
    this.rocketTrailMat = new THREE.LineBasicMaterial({ color: 0xfdba74, transparent: true, opacity: 0.9 });

    const bodyGeo = new THREE.CylinderGeometry(0.055, 0.055, 0.3, 14);
    bodyGeo.rotateX(Math.PI / 2);
    this.rocketBodyGeo = bodyGeo;
    const noseGeo = new THREE.ConeGeometry(0.055, 0.16, 14);
    noseGeo.rotateX(Math.PI / 2);
    noseGeo.translate(0, 0, 0.23);
    this.rocketNoseGeo = noseGeo;
    this.rocketFinGeo = new THREE.BoxGeometry(0.014, 0.075, 0.09);
    this.rocketBodyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
    this.rocketNoseMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.35 });
    this.rocketFinMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.4 });
    this.rocketFlameMat = new THREE.MeshBasicMaterial({ color: 0xfbbf24 });

    scene.add(this.group);
  }

  public get activeCount(): number {
    return this.activeProjectiles.length;
  }

  public getLatestVelocity(out = new THREE.Vector3()): THREE.Vector3 {
    for (let i = this.activeProjectiles.length - 1; i >= 0; i--) {
      if (this.activeProjectiles[i].ownerId === 'player') {
        return out.copy(this.activeProjectiles[i].velocity);
      }
    }
    return out.copy(this.lastLaunchVelocity);
  }

  /** Classic hand-thrown snowball helper (velocity derived from throwPower). */
  public spawnSnowball(
    ownerId: string,
    ownerName: string,
    teamId: TeamId,
    releaseOrigin: THREE.Vector3,
    aimDirection: THREE.Vector3,
    characterVelocity: THREE.Vector3,
    powerFactor: number,
    isMega: boolean,
    config: CharacterConfig
  ): void {
    const dir = aimDirection.clone().normalize();
    const spread = ownerId === 'player' ? 0.0006 : 0.008;
    dir.x += (Math.random() - 0.5) * spread;
    dir.y += (Math.random() - 0.5) * spread;
    dir.z += (Math.random() - 0.5) * spread;
    dir.normalize();

    const speed =
      config.throwPower * powerFactor * (ownerId === 'player' ? 1.0 : 0.8 + Math.random() * 0.08);
    const launchVel = dir.multiplyScalar(speed);
    if (ownerId !== 'player') {
      launchVel.addScaledVector(new THREE.Vector3(characterVelocity.x, 0, characterVelocity.z), 0.12);
    }

    this.spawn({
      ownerId,
      ownerName,
      teamId,
      origin: releaseOrigin,
      velocity: launchVel,
      kind: 'BALL',
      powerFactor,
      isMega,
      gravity: config.throwGravity,
      drag: config.throwDrag,
    });
  }

  public spawn(p: SpawnParams): void {
    if (p.ownerId === 'player') {
      this.lastLaunchVelocity.copy(p.velocity);
    }

    let object: THREE.Object3D;
    let radius: number;
    let trailLen: number;
    let trailMat: THREE.LineBasicMaterial;

    if (p.kind === 'ROCKET') {
      const rocket = new THREE.Group();
      const body = new THREE.Mesh(this.rocketBodyGeo, this.rocketBodyMat);
      const nose = new THREE.Mesh(this.rocketNoseGeo, this.rocketNoseMat);
      body.castShadow = true;
      nose.castShadow = true;
      rocket.add(body, nose);
      for (let i = 0; i < 3; i++) {
        const pivot = new THREE.Group();
        pivot.rotation.z = (i / 3) * Math.PI * 2;
        const fin = new THREE.Mesh(this.rocketFinGeo, this.rocketFinMat);
        fin.position.set(0, 0.07, -0.11);
        pivot.add(fin);
        rocket.add(pivot);
      }
      const flame = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), this.rocketFlameMat);
      flame.scale.set(1, 1, 1.9);
      flame.position.set(0, 0, -0.2);
      rocket.add(flame);
      rocket.quaternion.setFromUnitVectors(Z_AXIS, p.velocity.clone().normalize());
      object = rocket;
      radius = 0.14;
      trailLen = 20;
      trailMat = this.rocketTrailMat;
    } else {
      const mesh = new THREE.Mesh(
        this.snowballGeo,
        p.kind === 'BULLET' ? this.bulletMat : p.isMega ? this.megaMat : this.normalMat
      );
      const scale = p.kind === 'BULLET' ? 0.72 : p.isMega ? 2.3 : 1.0;
      mesh.scale.setScalar(scale);
      mesh.castShadow = true;
      object = mesh;
      radius = 0.095 * scale;
      trailLen = p.kind === 'BULLET' ? 9 : p.isMega ? 16 : 12;
      trailMat =
        p.kind === 'BULLET' ? this.bulletTrailMat : p.isMega ? this.megaTrailMat : this.normalTrailMat;
    }
    object.position.copy(p.origin);

    const trailPoints: THREE.Vector3[] = [];
    for (let i = 0; i < trailLen; i++) trailPoints.push(p.origin.clone());
    const trailGeo = new THREE.BufferGeometry().setFromPoints(trailPoints);
    const trailLine = new THREE.Line(trailGeo, trailMat);
    trailLine.frustumCulled = false;

    this.group.add(object);
    this.group.add(trailLine);

    this.activeProjectiles.push({
      ownerId: p.ownerId,
      ownerName: p.ownerName,
      teamId: p.teamId,
      kind: p.kind,
      object,
      trailLine,
      trailPoints,
      position: p.origin.clone(),
      velocity: p.velocity.clone(),
      spawnOrigin: p.origin.clone(),
      powerFactor: p.powerFactor,
      isMega: p.isMega,
      gravity: p.gravity,
      drag: p.drag,
      age: 0,
      radius,
      inHitstop: false,
      hitstopTimer: 0,
      didClingOnFinish: false,
      clingTargetBone: null,
      impactNormal: new THREE.Vector3(0, 1, 0),
      damage: p.damage ?? (p.isMega ? 3 : 1),
      headMult: p.headMult ?? 1,
    });
  }

  private removeProjectile(index: number): void {
    const p = this.activeProjectiles[index];
    this.group.remove(p.object);
    this.group.remove(p.trailLine);
    p.trailLine.geometry.dispose();
    this.activeProjectiles.splice(index, 1);
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    combatants: CombatantHitbox[],
    terrain: SnowTerrain,
    onCombatantHit: (ev: ProjectileHitEvent) => void,
    onEnvironmentImpact: (distanceToPlayer: number, hitSolid: boolean) => void,
    onExplosion: (ev: ExplosionEvent) => void
  ): void {
    const subSteps = 6;
    const subDt = dt / subSteps;
    const hitPointTemp = new THREE.Vector3();

    for (let i = this.activeProjectiles.length - 1; i >= 0; i--) {
      const p = this.activeProjectiles[i];

      // ===== HITSTOP FREEZE (ball frozen & squashed on the victim) =====
      if (p.inHitstop) {
        p.hitstopTimer -= dt;
        if (p.hitstopTimer <= 0) {
          if (p.didClingOnFinish) {
            terrain.attachClingingSnowball(p.clingTargetBone, p.position, p.impactNormal, p.isMega);
            terrain.emitSnowballShatter(p.position, p.impactNormal, p.velocity, p.powerFactor * 0.75, p.isMega, true);
          } else {
            terrain.emitSnowballShatter(p.position, p.impactNormal, p.velocity, p.powerFactor * 1.1, p.isMega, false);
          }
          this.removeProjectile(i);
        }
        continue;
      }

      p.age += dt;

      let collidedEnv = false;
      let exploded = false;
      let hitSolidObstacle = false;
      let hitSnowman: RangeTarget | null = null;
      const hitNormal = new THREE.Vector3(0, 1, 0);

      for (let s = 0; s < subSteps; s++) {
        const prevPos = p.position.clone();
        const speed = p.velocity.length();
        p.velocity.x -= p.drag * speed * p.velocity.x * subDt;
        p.velocity.y -= (p.gravity + p.drag * speed * p.velocity.y) * subDt;
        p.velocity.z -= p.drag * speed * p.velocity.z * subDt;
        p.position.addScaledVector(p.velocity, subDt);

        // 1. Swept segment vs enemy combatants (same team & owner are skipped: no friendly fire)
        let hitCombatant: CombatantHitbox | null = null;
        for (let c = 0; c < combatants.length; c++) {
          const cb = combatants[c];
          if (cb.id === p.ownerId || cb.teamId === p.teamId) continue;
          if (segmentSphereHit(prevPos, p.position, cb.center, cb.radius + p.radius, hitPointTemp)) {
            hitCombatant = cb;
            break;
          }
        }

        if (hitCombatant) {
          if (p.kind === 'ROCKET') {
            p.position.copy(hitPointTemp);
            exploded = true;
            break;
          }

          p.position.copy(hitPointTemp);
          const outNormal = hitPointTemp.clone().sub(hitCombatant.center);
          if (outNormal.lengthSq() < 0.0001) outNormal.set(0, 0, -1);
          outNormal.normalize();

          const surfaceHitPos = hitCombatant.center.clone().addScaledVector(outNormal, 0.23);
          p.position.copy(surfaceHitPos);
          p.impactNormal.copy(outNormal);

          const relY = surfaceHitPos.y - hitCombatant.center.y;
          const chosenBone =
            relY > 0.2 && hitCombatant.headBone
              ? hitCombatant.headBone
              : relY < -0.3 && hitCombatant.pelvisBone
              ? hitCombatant.pelvisBone
              : hitCombatant.chestBone;

          const isBullet = p.kind === 'BULLET';
          const willCling = !p.isMega && !isBullet && Math.random() < 0.42;
          const freezeDuration = p.isMega ? 0.056 : isBullet ? 0.03 : 0.045;

          if (chosenBone) {
            terrain.addBodySnowDecal(chosenBone, surfaceHitPos, outNormal, p.isMega ? 0.42 : 0.26);
          }
          terrain.emitThroughSplatterBehindTarget(surfaceHitPos, p.velocity, p.isMega);
          terrain.emitSnowballShatter(surfaceHitPos, outNormal, p.velocity, 0.45, false, true);

          const throwDist = surfaceHitPos.distanceTo(p.spawnOrigin);
          onCombatantHit({
            ownerId: p.ownerId,
            ownerName: p.ownerName,
            teamId: p.teamId,
            victimId: hitCombatant.id,
            victimName: hitCombatant.name,
            impactPos: surfaceHitPos.clone(),
            impactVel: p.velocity.clone(),
            impactNormal: outNormal.clone(),
            hitBone: chosenBone,
            throwDistance: throwDist,
            powerFactor: p.powerFactor,
            isMega: p.isMega,
            didCling: willCling,
            hitstopDuration: freezeDuration,
            kind: p.kind,
            forceKo: false,
            damage: p.damage * (chosenBone === hitCombatant.headBone ? p.headMult : 1),
            headshot: chosenBone === hitCombatant.headBone,
          });

          // Mega snowball splash on nearby ENEMIES
          if (p.isMega) {
            for (const other of combatants) {
              if (other.id === p.ownerId || other.id === hitCombatant.id || other.teamId === p.teamId) continue;
              if (other.center.distanceTo(surfaceHitPos) <= 3.1) {
                const splashVel = other.center.clone().sub(surfaceHitPos).setY(0.25).normalize().multiplyScalar(22.0);
                onCombatantHit({
                  ownerId: p.ownerId,
                  ownerName: p.ownerName,
                  teamId: p.teamId,
                  victimId: other.id,
                  victimName: other.name,
                  impactPos: other.center.clone(),
                  impactVel: splashVel,
                  impactNormal: new THREE.Vector3(0, 1, 0),
                  hitBone: other.chestBone,
                  throwDistance: throwDist,
                  powerFactor: p.powerFactor,
                  isMega: true,
                  didCling: false,
                  hitstopDuration: 0.04,
                  kind: 'BALL',
                  forceKo: false,
                });
              }
            }
          }

          if (p.ownerId === 'player') {
            this.hasCompletedBallisticFlight = true;
            this.lastHitDescription = `HIT ${hitCombatant.name} (${throwDist.toFixed(1)}m)`;
          }

          p.inHitstop = true;
          p.hitstopTimer = freezeDuration;
          p.didClingOnFinish = willCling;
          p.clingTargetBone = chosenBone ?? null;
          p.trailLine.visible = false;

          const baseS = p.isMega ? 2.3 : isBullet ? 0.72 : 1.0;
          p.object.position.copy(surfaceHitPos);
          p.object.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), outNormal);
          p.object.scale.set(baseS * 1.38, baseS * 0.52, baseS * 1.38);
          break;
        }

        // 2. Bouncy bumpers (rockets detonate, snowballs ricochet)
        for (const b of terrain.bumpers) {
          if (p.position.y > b.position.y + b.height + p.radius) continue;
          const dx = p.position.x - b.position.x;
          const dz = p.position.z - b.position.z;
          const hDist = Math.hypot(dx, dz);
          if (hDist <= b.radius + p.radius && hDist > 0.001) {
            if (p.kind === 'ROCKET') {
              exploded = true;
              break;
            }
            const nx = dx / hDist;
            const nz = dz / hDist;
            p.position.x = b.position.x + nx * (b.radius + p.radius + 0.03);
            p.position.z = b.position.z + nz * (b.radius + p.radius + 0.03);
            const dot = p.velocity.x * nx + p.velocity.z * nz;
            if (dot < 0) {
              p.velocity.x = (p.velocity.x - 2 * dot * nx) * 0.88;
              p.velocity.z = (p.velocity.z - 2 * dot * nz) * 0.88;
              p.velocity.y += 1.2;
              b.pulse = 0.85;
              terrain.addSurfaceSnowSplatter(
                new THREE.Vector3(b.position.x + nx * b.radius, p.position.y, b.position.z + nz * b.radius),
                new THREE.Vector3(nx, 0, nz),
                0.38
              );
            }
          }
        }
        if (exploded) break;

        // 3. Snow fort walls
        const segVec = p.position.clone().sub(prevPos);
        const segLen = segVec.length();
        if (segLen > 0.0001) {
          const wallHit = terrain.raycastObstacleWalls(prevPos, segVec.divideScalar(segLen), segLen + p.radius * 0.5);
          if (wallHit) {
            p.position.copy(wallHit.point);
            hitNormal.copy(wallHit.normal);
            if (p.kind === 'ROCKET') {
              exploded = true;
              break;
            }
            terrain.addSurfaceSnowSplatter(wallHit.point, wallHit.normal, p.isMega ? 0.9 : 0.5);
            if (!p.isMega && p.kind === 'BALL' && Math.random() < 0.38) {
              terrain.attachClingingSnowball(null, wallHit.point, wallHit.normal, false);
            }
            collidedEnv = true;
            hitSolidObstacle = true;
            break;
          }
        }

        // 4. Snowman targets
        for (const t of terrain.targets) {
          if (segmentSphereHit(prevPos, p.position, t.hitCenter, t.hitRadius + p.radius, hitPointTemp)) {
            p.position.copy(hitPointTemp);
            hitNormal.copy(p.position).sub(t.hitCenter).normalize();
            if (p.kind === 'ROCKET') {
              exploded = true;
              break;
            }
            collidedEnv = true;
            hitSolidObstacle = true;
            hitSnowman = t;
            terrain.triggerTargetHit(t, p.velocity, p.powerFactor);
            terrain.addBodySnowDecal(t.pivotGroup, hitPointTemp, hitNormal, 0.36);
            if (p.kind === 'BALL' && Math.random() < 0.45) {
              terrain.attachClingingSnowball(t.pivotGroup, hitPointTemp, hitNormal, p.isMega);
            }
            break;
          }
        }
        if (collidedEnv || exploded) break;

        // 5. Snow ground
        const groundY = terrain.getHeightAt(p.position.x, p.position.z);
        if (p.position.y <= groundY + p.radius * 0.6) {
          p.position.y = groundY + 0.03;
          terrain.getNormalAt(p.position.x, p.position.z, hitNormal);
          if (p.kind === 'ROCKET') {
            exploded = true;
            break;
          }
          terrain.addSnowImpactMark(p.position, p.isMega);
          collidedEnv = true;
          break;
        }
      }

      if (p.inHitstop) continue;

      // ===== ROCKET DETONATION =====
      if (exploded) {
        const radius = WEAPON_STATS.BAZOOKA.blastRadius;
        terrain.emitSnowExplosion(p.position, radius);
        onExplosion({
          ownerId: p.ownerId,
          ownerName: p.ownerName,
          teamId: p.teamId,
          position: p.position.clone(),
          radius,
        });
        if (p.ownerId === 'player') {
          this.hasCompletedBallisticFlight = true;
          this.lastHitDescription = `BOOM @ ${p.position.distanceTo(p.spawnOrigin).toFixed(1)}m`;
        }
        this.removeProjectile(i);
        continue;
      }

      p.object.position.copy(p.position);
      if (p.kind === 'ROCKET') {
        if (p.velocity.lengthSq() > 0.01) {
          p.object.quaternion.setFromUnitVectors(Z_AXIS, p.velocity.clone().normalize());
        }
        terrain.emitTrailPuff(p.position);
      } else {
        p.object.rotation.x += 14 * dt;
        p.object.rotation.z += 9 * dt;
      }

      p.trailPoints.pop();
      p.trailPoints.unshift(p.position.clone());
      const posAttr = p.trailLine.geometry.attributes.position as THREE.BufferAttribute;
      for (let k = 0; k < p.trailPoints.length; k++) {
        posAttr.setXYZ(k, p.trailPoints[k].x, p.trailPoints[k].y, p.trailPoints[k].z);
      }
      posAttr.needsUpdate = true;

      if (collidedEnv || p.age > 5.0) {
        if (collidedEnv) {
          if (p.ownerId === 'player') this.hasCompletedBallisticFlight = true;
          terrain.emitSnowballShatter(p.position, hitNormal, p.velocity, p.powerFactor, p.isMega, false);
          onEnvironmentImpact(p.position.distanceTo(playerPos), hitSolidObstacle);

          if (p.ownerId === 'player') {
            const throwDist = p.position.distanceTo(p.spawnOrigin);
            this.lastHitDescription = hitSnowman
              ? `HIT ${hitSnowman.label} (${throwDist.toFixed(1)}m)`
              : `Salju @ ${throwDist.toFixed(1)}m`;
          }
        }
        this.removeProjectile(i);
      }
    }
  }
}

const Z_AXIS = new THREE.Vector3(0, 0, 1);
