import * as THREE from 'three';
import {
  BaseGaitMode,
  CharacterConfig,
  DirectionMode,
  UpperActionState,
} from '../config/GameConfig';
import { SnowTerrain } from '../world/SnowTerrain';

export function normalizeAngle(angle: number): number {
  let a = angle % (Math.PI * 2);
  if (a > Math.PI) a -= Math.PI * 2;
  if (a < -Math.PI) a += Math.PI * 2;
  return a;
}

export class MovementController {
  public readonly position = new THREE.Vector3(0, 0, 0);
  public readonly velocity = new THREE.Vector3(0, 0, 0);
  public readonly accelerationVec = new THREE.Vector3(0, 0, 0);

  public facingYaw = 0;
  public angularVelocityYaw = 0;

  public blendSpeed = 0; // 0.0 idle, 0.3 walk, 0.6 jog, 1.0 run
  public blendDirection = 0; // -1 left .. 0 forward .. +1 right
  public localForwardRatio = 1; // -1 backward .. +1 forward

  public localAccelForward = 0;
  public localAccelRight = 0;

  // Vertical Jump, Dive & Stumble Knockback States
  public isGrounded = true;
  public isDiving = false;
  public diveTimer = 0;
  public hasAirDived = false;
  public stumbleTimer = 0;

  public justJumped = false;
  public justDived = false;
  public justLanded = false;
  public justBouncedBumper = false;

  private moveStartTimer = 0;
  public sharpTurnTimer = 0;
  public sharpTurnTargetYaw = 0;
  public sharpTurnSign = 1;
  public justTriggeredSharpTurn = false;

  public isTurningInPlace = false;
  /** FPS mode: no sharp-turn pivot braking, direction changes stay instant & responsive */
  public disableSharpTurn = false;
  public turnInPlaceSign = 1;

  private prevVelocity = new THREE.Vector3();

  constructor(initialGroundY = 0) {
    this.position.set(0, initialGroundY, 0);
  }

  public applyKnockback(impulse: THREE.Vector3, stumbleDuration = 0.42): void {
    this.velocity.x += impulse.x;
    this.velocity.z += impulse.z;
    if (impulse.y > 0) {
      this.velocity.y = Math.max(this.velocity.y, impulse.y);
      this.isGrounded = false;
    }
    this.stumbleTimer = Math.max(this.stumbleTimer, stumbleDuration);
    this.isDiving = false;
  }

  public update(
    dt: number,
    moveInput: { x: number; z: number; magnitude: number },
    jumpJustPressed: boolean,
    diveJustPressed: boolean,
    isRunHeld: boolean,
    speedMultiplier: number,
    baseGait: BaseGaitMode,
    directionMode: DirectionMode,
    upperState: UpperActionState,
    cameraYaw: number,
    config: CharacterConfig,
    terrain: SnowTerrain
  ): void {
    this.justTriggeredSharpTurn = false;
    this.justJumped = false;
    this.justDived = false;
    this.justLanded = false;
    this.justBouncedBumper = false;
    this.prevVelocity.copy(this.velocity);

    if (this.stumbleTimer > 0) {
      this.stumbleTimer = Math.max(0, this.stumbleTimer - dt);
    }
    if (this.diveTimer > 0) {
      this.diveTimer = Math.max(0, this.diveTimer - dt);
      if (this.diveTimer <= 0) {
        this.isDiving = false;
      }
    }

    // 1. World desired input direction
    const camFwdX = Math.sin(cameraYaw);
    const camFwdZ = Math.cos(cameraYaw);
    const camRightX = -Math.cos(cameraYaw);
    const camRightZ = Math.sin(cameraYaw);

    const worldInputX = camFwdX * moveInput.z + camRightX * moveInput.x;
    const worldInputZ = camFwdZ * moveInput.z + camRightZ * moveInput.x;
    const inputLen = Math.hypot(worldInputX, worldInputZ);
    const hasInput = inputLen > 0.05 && this.stumbleTimer <= 0.12;

    const desiredDirX = hasInput ? worldInputX / inputLen : Math.sin(this.facingYaw);
    const desiredDirZ = hasInput ? worldInputZ / inputLen : Math.cos(this.facingYaw);

    // 2. Stumble Jump & Iconic Mid-Air Belly Dive!
    if (jumpJustPressed && this.stumbleTimer <= 0.05) {
      if (this.isGrounded && !this.isDiving) {
        this.velocity.y = config.jumpForce;
        this.isGrounded = false;
        this.hasAirDived = false;
        this.justJumped = true;
      } else if (!this.isGrounded && !this.hasAirDived) {
        // Double-tap Space mid-air triggers Stumble Guys Belly-Dive!
        this.triggerBellyDive(desiredDirX, desiredDirZ, config.runSpeed * 1.32 * speedMultiplier);
      }
    } else if (diveJustPressed && !this.isDiving && this.stumbleTimer <= 0.05 && !this.hasAirDived) {
      this.triggerBellyDive(desiredDirX, desiredDirZ, config.runSpeed * 1.28 * speedMultiplier);
    }

    // 3. Target horizontal speed
    let targetSpeed = 0;
    if (hasInput && !this.isDiving) {
      this.moveStartTimer = Math.min(0.25, this.moveStartTimer + dt);

      if (directionMode === 'COMBAT') {
        const isMostlyBackward = moveInput.z < -0.25;
        const isPureStrafe = Math.abs(moveInput.x) > 0.5 && Math.abs(moveInput.z) < 0.45;

        if (isRunHeld && moveInput.z > 0.2) {
          targetSpeed = config.jogSpeed * 1.16;
        } else if (isMostlyBackward) {
          targetSpeed = config.walkSpeed * 0.88;
        } else if (isPureStrafe) {
          targetSpeed = isRunHeld ? config.strafeSpeed * 1.28 : config.strafeSpeed;
        } else {
          targetSpeed = baseGait === 'JOG' ? config.jogSpeed : config.walkSpeed * 1.08;
        }
      } else {
        if (isRunHeld) {
          targetSpeed = config.runSpeed;
        } else if (baseGait === 'JOG') {
          targetSpeed = config.jogSpeed;
        } else {
          targetSpeed = config.walkSpeed;
        }
      }

      targetSpeed *= Math.min(1, moveInput.magnitude) * speedMultiplier;

      const currentHorizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
      if (currentHorizSpeed < 0.35 && this.moveStartTimer < 0.08) {
        const antFactor = 0.42 + 0.58 * (this.moveStartTimer / 0.08);
        targetSpeed *= antFactor;
      }
    } else if (!hasInput) {
      this.moveStartTimer = 0;
    }

    if (upperState === 'SNOWBALL_PICKUP') {
      targetSpeed *= 0.38;
    }

    // 4. Sharp Turn detection
    const currentSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    if (
      this.isGrounded &&
      !this.isDiving &&
      this.stumbleTimer <= 0 &&
      directionMode === 'MOVEMENT' &&
      !this.disableSharpTurn &&
      hasInput &&
      this.sharpTurnTimer <= 0 &&
      currentSpeed > 3.9 &&
      upperState !== 'SNOWBALL_PICKUP'
    ) {
      const inputYaw = Math.atan2(desiredDirX, desiredDirZ);
      const velYaw = Math.atan2(this.velocity.x, this.velocity.z);
      const angleDelta = normalizeAngle(inputYaw - velYaw);
      if (Math.abs(angleDelta) > 2.05) {
        this.sharpTurnTimer = 0.32;
        this.sharpTurnTargetYaw = inputYaw;
        this.sharpTurnSign = angleDelta >= 0 ? 1 : -1;
        this.justTriggeredSharpTurn = true;
      }
    }

    if (this.sharpTurnTimer > 0) {
      this.sharpTurnTimer = Math.max(0, this.sharpTurnTimer - dt);
    }

    // 5. Horizontal Velocity Integration
    const desiredVelX = hasInput && !this.isDiving ? desiredDirX * targetSpeed : 0;
    const desiredVelZ = hasInput && !this.isDiving ? desiredDirZ * targetSpeed : 0;

    const deltaVX = desiredVelX - this.velocity.x;
    const deltaVZ = desiredVelZ - this.velocity.z;
    const deltaMag = Math.hypot(deltaVX, deltaVZ);

    if (deltaMag > 0.0001) {
      const dotVel = this.velocity.x * desiredVelX + this.velocity.z * desiredVelZ;
      const isBrakingOrStopping = !hasInput || targetSpeed < currentSpeed - 0.15 || dotVel < 0;

      let rate = isBrakingOrStopping ? config.deceleration : config.acceleration;
      if (!this.isGrounded) {
        rate *= 0.55; // Responsive air control without snapping
      } else if (this.isDiving || this.stumbleTimer > 0) {
        rate = config.deceleration * 0.65; // Slippery snow belly-slide / knockback skid!
      } else if (this.sharpTurnTimer > 0) {
        rate = this.sharpTurnTimer > 0.14 ? config.deceleration * 1.7 : config.acceleration * 1.2;
      }

      const maxStep = rate * dt;
      if (deltaMag <= maxStep) {
        this.velocity.x = desiredVelX;
        this.velocity.z = desiredVelZ;
      } else {
        this.velocity.x += (deltaVX / deltaMag) * maxStep;
        this.velocity.z += (deltaVZ / deltaMag) * maxStep;
      }
    }

    const newSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    if (!hasInput && this.stumbleTimer <= 0 && !this.isDiving && newSpeed < 0.03) {
      this.velocity.x = 0;
      this.velocity.z = 0;
    }

    // 6. Rotational Interpolation
    const prevYaw = this.facingYaw;
    if (this.stumbleTimer > 0.05) {
      // Keep natural facing during impact knockback skid (no cartoon spinning!)
    } else if (this.isDiving) {
      if (newSpeed > 0.4) {
        const diveYaw = Math.atan2(this.velocity.x, this.velocity.z);
        const diff = normalizeAngle(diveYaw - this.facingYaw);
        this.facingYaw = normalizeAngle(this.facingYaw + diff * (1 - Math.exp(-14 * dt)));
      }
    } else if (directionMode === 'COMBAT') {
      const yawDiff = normalizeAngle(cameraYaw - this.facingYaw);
      if (newSpeed < 0.18) {
        if (Math.abs(yawDiff) > 0.55) {
          this.isTurningInPlace = true;
          this.turnInPlaceSign = yawDiff >= 0 ? 1 : -1;
        } else if (Math.abs(yawDiff) < 0.06) {
          this.isTurningInPlace = false;
        }
        if (this.isTurningInPlace || upperState === 'THROW_PREPARATION' || upperState === 'THROW') {
          const alpha = 1 - Math.exp(-config.rotationSpeed * 1.2 * dt);
          this.facingYaw = normalizeAngle(this.facingYaw + yawDiff * alpha);
        }
      } else {
        this.isTurningInPlace = false;
        const alpha = 1 - Math.exp(-config.rotationSpeed * 1.3 * dt);
        this.facingYaw = normalizeAngle(this.facingYaw + yawDiff * alpha);
      }
    } else {
      this.isTurningInPlace = false;
      if (this.sharpTurnTimer > 0) {
        const pivotAlpha = 1 - Math.exp(-config.rotationSpeed * 1.25 * dt);
        const diff = normalizeAngle(this.sharpTurnTargetYaw - this.facingYaw);
        this.facingYaw = normalizeAngle(this.facingYaw + diff * pivotAlpha);
      } else if (hasInput && newSpeed > 0.08) {
        const targetYaw = Math.atan2(desiredDirX, desiredDirZ);
        const diff = normalizeAngle(targetYaw - this.facingYaw);
        let gaitTurnMult = 1.15;
        if (newSpeed > config.jogSpeed + 0.4) {
          gaitTurnMult = 0.76;
        } else if (newSpeed > config.walkSpeed + 0.4) {
          gaitTurnMult = 0.94;
        }
        const alpha = 1 - Math.exp(-config.rotationSpeed * gaitTurnMult * dt);
        this.facingYaw = normalizeAngle(this.facingYaw + diff * alpha);
      }
    }

    this.angularVelocityYaw = normalizeAngle(this.facingYaw - prevYaw) / Math.max(0.0001, dt);

    // 7. Vertical Gravity, Arena Bumper/Wall Collisions & Ground Landing
    this.position.x += this.velocity.x * dt;
    this.position.z += this.velocity.z * dt;

    if (!this.isGrounded) {
      this.velocity.y -= 18.5 * dt;
      this.position.y += this.velocity.y * dt;
    }

    const bumperHit = terrain.resolveArenaCollisions(this.position, 0.35);
    if (bumperHit) {
      this.velocity.copy(bumperHit);
      this.isGrounded = false;
      this.justBouncedBumper = true;
    }

    const groundY = terrain.getHeightAt(this.position.x, this.position.z);
    if (this.isGrounded) {
      this.position.y = groundY;
      this.velocity.y = 0;
    } else if (this.position.y <= groundY) {
      this.position.y = groundY;
      this.velocity.y = 0;
      this.isGrounded = true;
      this.hasAirDived = false;
      this.justLanded = true;
    }

    // 8. Local Acceleration & 2D Blend Tree Parameters
    this.accelerationVec
      .copy(this.velocity)
      .sub(this.prevVelocity)
      .divideScalar(Math.max(0.0001, dt));

    const charFwdX = Math.sin(this.facingYaw);
    const charFwdZ = Math.cos(this.facingYaw);
    const charRightX = -Math.cos(this.facingYaw);
    const charRightZ = Math.sin(this.facingYaw);

    const rawAccelFwd = this.accelerationVec.x * charFwdX + this.accelerationVec.z * charFwdZ;
    const rawAccelRight = this.accelerationVec.x * charRightX + this.accelerationVec.z * charRightZ;

    const leanSmooth = 1 - Math.exp(-10.0 * dt);
    this.localAccelForward = THREE.MathUtils.lerp(this.localAccelForward, rawAccelFwd, leanSmooth);
    this.localAccelRight = THREE.MathUtils.lerp(this.localAccelRight, rawAccelRight, leanSmooth);

    const finalHorizSpeed = Math.hypot(this.velocity.x, this.velocity.z);
    let targetBlendSpeed = 0;
    if (finalHorizSpeed <= config.walkSpeed) {
      targetBlendSpeed = (finalHorizSpeed / Math.max(0.1, config.walkSpeed)) * 0.3;
    } else if (finalHorizSpeed <= config.jogSpeed) {
      const t =
        (finalHorizSpeed - config.walkSpeed) / Math.max(0.1, config.jogSpeed - config.walkSpeed);
      targetBlendSpeed = 0.3 + t * 0.3;
    } else {
      const t =
        (finalHorizSpeed - config.jogSpeed) / Math.max(0.1, config.runSpeed - config.jogSpeed);
      targetBlendSpeed = 0.6 + Math.min(0.55, t * 0.4);
    }

    const blendAlpha = 1 - Math.exp(-15.0 * dt);
    this.blendSpeed = THREE.MathUtils.lerp(this.blendSpeed, targetBlendSpeed, blendAlpha);
    if (this.blendSpeed < 0.005) this.blendSpeed = 0;

    if (finalHorizSpeed > 0.12) {
      const velFwd = (this.velocity.x * charFwdX + this.velocity.z * charFwdZ) / finalHorizSpeed;
      const velRight =
        (this.velocity.x * charRightX + this.velocity.z * charRightZ) / finalHorizSpeed;
      this.blendDirection = THREE.MathUtils.lerp(
        this.blendDirection,
        THREE.MathUtils.clamp(velRight, -1, 1),
        blendAlpha
      );
      this.localForwardRatio = THREE.MathUtils.lerp(
        this.localForwardRatio,
        THREE.MathUtils.clamp(velFwd, -1, 1),
        blendAlpha
      );
    } else {
      this.blendDirection = THREE.MathUtils.lerp(this.blendDirection, 0, blendAlpha);
      this.localForwardRatio = THREE.MathUtils.lerp(this.localForwardRatio, 1, blendAlpha);
    }
  }

  private triggerBellyDive(dirX: number, dirZ: number, burstSpeed: number): void {
    this.isDiving = true;
    this.hasAirDived = true;
    this.diveTimer = 0.48;
    this.velocity.x = dirX * burstSpeed;
    this.velocity.z = dirZ * burstSpeed;
    this.velocity.y = Math.max(this.velocity.y, 2.4);
    this.isGrounded = false;
    this.facingYaw = Math.atan2(dirX, dirZ);
    this.justDived = true;
  }
}
