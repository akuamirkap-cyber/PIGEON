import { Crosshair, Snowflake } from 'lucide-react';
import { DebugTelemetry, FpsWeaponId } from '../config/GameConfig';

const WEAPON_SLOTS: { id: FpsWeaponId; slot: number; label: string }[] = [
  { id: 'pistol', slot: 1, label: 'PISTOL' },
  { id: 'rifle', slot: 2, label: 'RIFLE' },
  { id: 'sniper', slot: 3, label: 'SNIPER' },
];

export function BrawlHud({ telemetry }: { telemetry: DebugTelemetry }) {
  const t = telemetry;
  const blueRatio = Math.min(1, t.blueScore / t.scoreLimit);
  const redRatio = Math.min(1, t.redScore / t.scoreLimit);

  // dynamic crosshair: opens with bloom / movement, closes while aiming down sights
  const gap = 5 + t.fpsSpread * 26;
  const showCrosshair = t.fpsActive && !t.fpsScoped && t.fpsAdsBlend < 0.85;
  const crossOpacity = Math.max(0, 1 - t.fpsAdsBlend * 1.15);
  const crossColor = t.crosshairOnEnemy ? '#ef4444' : '#ffffff';
  const magLow = t.fpsAmmo <= Math.max(2, Math.floor(t.fpsMagSize * 0.25));

  return (
    <>
      {/* Damage vignette */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          opacity: Math.min(1, t.damagePulse),
          background: 'radial-gradient(ellipse at center, rgba(220,38,38,0) 45%, rgba(220,38,38,0.55) 100%)',
        }}
      />

      {/* FPS crosshair + hitmarker */}
      {t.fpsActive && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          {showCrosshair && (
            <div className="relative h-0 w-0" style={{ opacity: crossOpacity }}>
              {[
                { x: 0, y: -1, w: 2, h: 9 },
                { x: 0, y: 1, w: 2, h: 9 },
                { x: -1, y: 0, w: 9, h: 2 },
                { x: 1, y: 0, w: 9, h: 2 },
              ].map((b, i) => (
                <div
                  key={i}
                  className="absolute rounded-full"
                  style={{
                    width: b.w,
                    height: b.h,
                    background: crossColor,
                    boxShadow: '0 0 3px rgba(0,0,0,0.8)',
                    left: b.x * (gap + (b.w > 2 ? 4.5 : 0)) - b.w / 2,
                    top: b.y * (gap + (b.h > 2 ? 4.5 : 0)) - b.h / 2,
                  }}
                />
              ))}
              <div
                className="absolute rounded-full"
                style={{ width: 3, height: 3, left: -1.5, top: -1.5, background: crossColor, boxShadow: '0 0 3px rgba(0,0,0,0.9)' }}
              />
            </div>
          )}
          {t.hitMarkerActive && (
            <div className="absolute flex items-center justify-center">
              <div className="h-7 w-0.5 rotate-45 rounded-full bg-amber-300 shadow-[0_0_8px_#facc15]" />
              <div className="absolute h-7 w-0.5 -rotate-45 rounded-full bg-amber-300 shadow-[0_0_8px_#facc15]" />
            </div>
          )}
        </div>
      )}

      {/* Team vs Team scoreboard */}
      <div className="pointer-events-none absolute top-[5.2rem] left-1/2 -translate-x-1/2">
        <div className="flex items-center gap-2 rounded-2xl border-2 border-white/20 bg-slate-950/80 px-3 py-1 shadow-xl backdrop-blur-md">
          <div className="flex w-28 flex-col items-end gap-0.5">
            <span className="text-[10px] font-extrabold tracking-wider text-sky-300">TIM BIRU (KAMU)</span>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
              <div className="h-full rounded-full bg-sky-400 transition-all" style={{ width: `${blueRatio * 100}%` }} />
            </div>
          </div>
          <div className="flex items-center gap-1.5 font-mono text-lg font-black">
            <span className="text-sky-300">{t.blueScore}</span>
            <span className="text-[10px] font-bold text-slate-400">5v5 / {t.scoreLimit}</span>
            <span className="text-red-300">{t.redScore}</span>
          </div>
          <div className="flex w-28 flex-col items-start gap-0.5">
            <span className="text-[10px] font-extrabold tracking-wider text-red-300">TIM MERAH</span>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
              <div className="h-full rounded-full bg-red-400 transition-all" style={{ width: `${redRatio * 100}%` }} />
            </div>
          </div>
        </div>
        <div className="mt-0.5 flex justify-center gap-3 text-[10px] font-bold">
          <span className="text-sky-300">Sekutu hidup: {t.alliesAlive}/5</span>
          <span className="text-red-300">Musuh hidup: {t.enemiesAlive}/5</span>
        </div>
      </div>

      {/* Weapon / ammo panel */}
      <div className="pointer-events-none absolute right-3 bottom-3 flex flex-col items-end gap-2">
        <div
          className={`flex items-center gap-1.5 rounded-full border-2 px-3 py-1 text-[11px] font-extrabold shadow-lg backdrop-blur-md ${
            t.fpsAmmoType === 'SNOWBALL'
              ? 'border-sky-300 bg-sky-500/25 text-sky-100'
              : 'border-amber-300 bg-amber-500/20 text-amber-100'
          }`}
        >
          {t.fpsAmmoType === 'SNOWBALL' ? <Snowflake className="h-3.5 w-3.5" /> : <Crosshair className="h-3.5 w-3.5" />}
          <span>AMUNISI: {t.fpsAmmoType === 'SNOWBALL' ? 'SNOWBALL' : 'PELURU'}</span>
          <kbd className="rounded bg-slate-900/70 px-1.5 font-mono text-[10px]">B</kbd>
        </div>

        <div className="rounded-2xl border-2 border-white/20 bg-slate-950/80 px-4 py-2 text-right shadow-xl backdrop-blur-md">
          <div className="text-[10px] font-bold tracking-widest text-slate-400">{t.fpsWeaponName}</div>
          <div className="flex items-baseline justify-end gap-1.5">
            <span className={`font-mono text-4xl font-black leading-none ${magLow ? 'text-red-400' : 'text-white'}`}>
              {t.fpsReloading ? '--' : t.fpsAmmo}
            </span>
            <span className="font-mono text-lg font-bold text-slate-400">/ {t.fpsMagSize}</span>
          </div>
          <div className="mt-0.5 text-[10px] font-semibold text-sky-300">
            {t.fpsReloading ? 'MENGISI ULANG...' : t.fpsFireMode}
            {t.fpsAmmo === 0 && !t.fpsReloading ? ' • TEKAN R' : ''}
          </div>
        </div>

        <div className="flex gap-1.5">
          {WEAPON_SLOTS.map((w) => (
            <div
              key={w.id}
              className={`flex items-center gap-1.5 rounded-lg border-2 px-2 py-1 text-[10px] font-extrabold backdrop-blur-md ${
                t.fpsWeapon === w.id
                  ? 'border-sky-400 bg-sky-500/30 text-white'
                  : 'border-white/15 bg-slate-900/70 text-slate-400'
              }`}
            >
              <kbd className="rounded bg-slate-800 px-1 font-mono text-sky-300">{w.slot}</kbd>
              {w.label}
            </div>
          ))}
        </div>

        {t.isCrouching && (
          <div className="rounded-lg border-2 border-emerald-400/60 bg-emerald-500/20 px-2.5 py-0.5 text-[11px] font-extrabold text-emerald-200 backdrop-blur-md">
            JONGKOK
          </div>
        )}
      </div>

      {/* Snowball roll energy */}
      <div className="pointer-events-none absolute bottom-[4.6rem] left-3 w-44">
        <div className="mb-0.5 flex items-center justify-between text-[10px] font-extrabold text-sky-200">
          <span>
            {t.isRolling ? 'MENGGELINDING!' : t.rollEnergy >= 0.99 ? 'BOLA SALJU SIAP' : 'MENGISI BOLA SALJU'}
          </span>
          <kbd className="rounded bg-slate-900/80 px-1.5 font-mono text-sky-300">V</kbd>
        </div>
        <div className="h-2.5 w-full overflow-hidden rounded-full border border-white/25 bg-slate-900/80">
          <div
            className={`h-full rounded-full transition-all ${t.isRolling ? 'bg-orange-400' : t.rollEnergy > 0.3 ? 'bg-sky-300' : 'bg-slate-500'}`}
            style={{ width: `${Math.round(t.rollEnergy * 100)}%` }}
          />
        </div>
      </div>

      {!t.pointerLocked && (
        <div className="pointer-events-none absolute bottom-[5.5rem] left-1/2 -translate-x-1/2 rounded-2xl border border-sky-400/50 bg-slate-950/85 px-4 py-2 text-center text-xs font-semibold text-sky-100 shadow-xl backdrop-blur-md">
          Klik layar untuk mengunci mouse & mulai FPS • <span className="font-mono text-sky-300">Esc</span> melepas kursor
        </div>
      )}
    </>
  );
}
