import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import { chromium } from "playwright";

await mkdir("artifacts", { recursive: true });
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1157, height: 776 }, deviceScaleFactor: 1 });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
try {
  await page.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
  await page.getByRole("button", { name: /MASUK ARENA/ }).first().click();
  await page.getByRole("button", { name: /GOA KRISTAL AGUNG/ }).click();
  await page.screenshot({ path: "artifacts/hollow-lobby.png" });
  await page.getByRole("button", { name: /MASUK ARENA/ }).last().click();
  await page.waitForTimeout(1600);
  await page.screenshot({ path: "artifacts/hollow-gameplay.png" });
  await page.keyboard.down("KeyD"); await page.keyboard.down("Space");
  await page.waitForTimeout(2200);
  await page.keyboard.up("Space"); await page.keyboard.up("KeyD");
  await page.screenshot({ path: "artifacts/hollow-flight.png" });
  await page.keyboard.press("Escape");
  await page.getByRole("heading", { name: "PAUSE", exact: true }).waitFor();
  await page.getByRole("button", { name: "LANJUT", exact: true }).click();

  const geometry = await page.evaluate(async () => {
    const { getMap, findPath, solidPx, solidT, tileAt } = await import("/src/arena/maps.ts");
    const { hollowRockAtlas, crystalVistaUrl, hollowAccent } = await import("/src/arena/hollow.ts");
    const m = getMap(2), spawnIssues = [];
    for (const pts of m.spawns) for (const s of pts) {
      for (let dy = 1; dy < 19; dy++) for (const dx of [-4, 0, 3.9]) {
        if (solidPx(m, s.x + dx, s.y - dy)) spawnIssues.push(s);
      }
    }
    const pickupIssues = m.picks.filter((p) => solidPx(m, p.x, p.y - 4));
    const hatchIssues = m.hatches.filter((h) => {
      const x = Math.floor(h.x / 8), y = Math.floor(h.y / 8);
      return [-2, -1, 1, 2].some((d) => solidT(tileAt(m, x, y + d)));
    });
    const s = m.spawns[0][0];
    const paths = [...m.picks, ...m.spawns[1]].map((p) => ({ x: p.x, y: p.y, ok: findPath(m, s.x, s.y, p.x, p.y).length > 0 }));
    const decor = {};
    for (const d of m.decor) decor[d.k] = (decor[d.k] ?? 0) + 1;
    const material = hollowRockAtlas();
    let amethyst = 0, cyanVeins = 0, violetVeins = 0;
    for (let p = 0; p < material.glow.length; p++) {
      const o = p * 3;
      if (material.rgb[o + 2] > material.rgb[o] && material.rgb[o] > material.rgb[o + 1]) amethyst++;
      if (material.glow[p] > 0) {
        if (material.veins[o] > material.veins[o + 1]) violetVeins++;
        else cyanVeins++;
      }
    }
    const combination = {
      amethystRatio: amethyst / material.glow.length,
      cyanVeins, violetVeins,
      variedCrystals: hollowAccent(0.18) !== hollowAccent(0.65),
      backdropLoaded: (await fetch(crystalVistaUrl())).ok,
    };
    return { spawnIssues, pickupIssues, hatchIssues, paths, rivers: m.rivers, falls: m.dyn.filter((d) => d.k === "fall"), hides: m.hides.length, decor, combination };
  });
  await writeFile("artifacts/hollow-geometry.json", JSON.stringify(geometry, null, 2));

  await page.evaluate(async () => {
    const { ArenaGame } = await import("/src/arena/engine.ts");
    window.__chibi?.destroy();
    document.getElementById("root").innerHTML = "";
    const c = document.createElement("canvas");
    c.style.cssText = "position:fixed;inset:0;image-rendering:pixelated";
    document.body.append(c);
    const g = new ArenaGame(c, { hud() {}, end() {} });
    g.start({ map: 2, size: 4, kills: 50, time: 10, diff: "normal", skin: 6, startWep: "bolter" });
    cancelAnimationFrame(g.raf); g.paused = true; g.phase = "live"; g.banner = null;
    window.__hollowTest = g;
  });
  await page.waitForTimeout(1000);
  for (const [name, tx, ty] of [["sanctuary", 23, 65], ["geode-valley", 58, 60], ["upper-vault", 92, 28], ["great-falls", 132, 66], ["underground-river", 90, 92]]) {
    await page.evaluate(({ tx, ty }) => {
      const g = window.__hollowTest;
      g.me.x = tx * 8; g.me.y = ty * 8; g.me.vx = 0; g.me.vy = 0;
      g.cl = Math.max(0, Math.min(g.map.w * 8 - g.W, g.me.x - g.W / 2));
      g.ct = Math.max(0, Math.min(g.map.h * 8 - g.H, g.me.y - 55 - g.H / 2));
      g.cam.x = g.cl + g.W / 2; g.cam.y = g.ct + g.H / 2;
      g.zoom = 1; g.zoomKick = 0; g.roll = 0; g.t = 8.2; g.render();
    }, { tx, ty });
    await page.screenshot({ path: `artifacts/hollow-${name}.png` });
  }

  assert.equal(geometry.spawnIssues.length, 0, "Cave spawns must fit standing operators");
  assert.equal(geometry.pickupIssues.length, 0, "Cave pickups must be outside rock");
  assert.equal(geometry.hatchIssues.length, 0, "Secret passages must remain usable");
  assert(geometry.paths.every((p) => p.ok), "Bots must reach every pickup and enemy spawn");
  assert.equal(geometry.falls.length, 3, "Keep the three cathedral waterfalls");
  assert(geometry.rivers.length >= 5, "Hollow Earth must include playable underground rivers");
  assert(geometry.decor.mycotree >= 8, "Include a giant luminous mushroom biome");
  assert(geometry.decor.gotharch >= 8 && geometry.decor.runepillar >= 8, "Keep the classic crystal sanctuary structures");
  assert(geometry.combination.amethystRatio > 0.5, "Restore amethyst stone identity");
  assert(geometry.combination.cyanVeins > 0 && geometry.combination.violetVeins > 0, "Include both classic cyan and violet mineral veins");
  assert(geometry.combination.variedCrystals && geometry.combination.backdropLoaded, "Hybrid cave visuals must load");

  const gameplay = await page.evaluate(() => {
    const g = window.__hollowTest;
    const r = g.map.rivers[0];
    g.me.x = r.x + 24; g.me.y = r.y + 10; g.me.vy = 0; g.me.fuel = 0.3;
    for (let i = 0; i < 90; i++) g.step(1 / 60);
    const buoyancy = Math.abs(g.me.y - r.y) < 17;
    g.keys.add("KeyW"); for (let i = 0; i < 35; i++) g.step(1 / 60); g.keys.delete("KeyW");
    const jetExit = g.me.y < r.y - 18;
    const fall = g.map.dyn.find((d) => d.k === "fall");
    g.me.burn = 1;
    g.me.x = fall.x; g.me.y = fall.y + 35; g.step(1 / 60);
    const extinguished = g.me.burn === 0;
    const d = g.map.decor.find((d) => d.k === "bigcrystal");
    g.breakDecor(d);
    const crystalBreaks = !g.map.decor.includes(d);
    const stalactite = g.stalags[0];
    g.breakDecor(stalactite, 0.1);
    const fallingRock = g.rocks.some((r) => r.kind === 0);
    g.quakeT = 0.01;
    for (let i = 0; i < 170; i++) g.step(1 / 60);
    const quakeActive = g.qk > 0 || g.quake > 0;
    const start = performance.now();
    for (let i = 0; i < 600; i++) g.step(1 / 60);
    const elapsed = performance.now() - start;
    const finite = g.sol.every((s) => [s.x, s.y, s.vx, s.vy, s.hp, s.armor].every(Number.isFinite));
    g.t = 13; g.render(); const a = g.cv.toDataURL();
    g.t = 13.5; g.render(); const animated = a !== g.cv.toDataURL();
    const maps = [];
    for (let map = 0; map < 4; map++) {
      g.start({ map, size: 3, kills: 10, time: 3, diff: "easy", skin: 6, startWep: "bolter" }); cancelAnimationFrame(g.raf); g.phase = "live";
      for (let i = 0; i < 60; i++) g.step(1 / 60);
      maps.push({ map, finite: g.sol.every((s) => [s.x, s.y, s.vx, s.vy].every(Number.isFinite)) });
    }
    g.destroy();
    return { buoyancy, jetExit, extinguished, crystalBreaks, fallingRock, quakeActive, finite, animated, elapsed, maps };
  });
  for (const [key, result] of Object.entries(gameplay)) if (typeof result === "boolean") assert(result, `${key} must pass`);
  assert(gameplay.maps.every((m) => m.finite), "All four arenas must remain stable");

  const mobile = await browser.newPage({ viewport: { width: 844, height: 390 }, isMobile: true, hasTouch: true });
  mobile.on("pageerror", (e) => errors.push(e.message));
  await mobile.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
  await mobile.getByRole("button", { name: /MASUK ARENA/ }).first().click();
  await mobile.getByRole("button", { name: /GOA KRISTAL AGUNG/ }).click();
  await mobile.getByRole("button", { name: /MASUK ARENA/ }).last().click();
  await mobile.getByLabel("Stik gerak dan jetpack").waitFor();
  await mobile.screenshot({ path: "artifacts/hollow-mobile.png" });
  await mobile.close();
  assert.equal(errors.length, 0, errors.join("; "));
  await writeFile("artifacts/hollow-verification.json", JSON.stringify({ geometry, gameplay, errors }, null, 2));
  console.log(JSON.stringify({ paths: geometry.paths.length, rivers: geometry.rivers.length, hides: geometry.hides, decor: geometry.decor, combination: geometry.combination, gameplay, errors }, null, 2));
} finally {
  await browser.close();
}