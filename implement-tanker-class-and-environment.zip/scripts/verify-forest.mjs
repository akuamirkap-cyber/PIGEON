import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import { chromium } from "playwright";

await mkdir("artifacts", { recursive: true });
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1157, height: 776 }, deviceScaleFactor: 1 });
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
await page.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
await page.getByRole("button", { name: /MASUK ARENA/ }).first().click();
await page.getByRole("button", { name: /HUTAN BASTION/ }).click();
await page.getByRole("button", { name: /MASUK ARENA/ }).last().click();
await page.waitForTimeout(1200);
await page.screenshot({ path: "artifacts/forest-gameplay.png" });
await page.keyboard.down("KeyD");
await page.keyboard.down("KeyW");
await page.waitForTimeout(1200);
await page.keyboard.up("KeyW");
await page.waitForTimeout(1000);
await page.keyboard.up("KeyD");
await page.screenshot({ path: "artifacts/forest-flight.png" });

const geometry = await page.evaluate(async () => {
  const { getMap, findPath, solidPx, tileAt, solidT } = await import("/src/arena/maps.ts");
  const m = getMap(3);
  const spawnIssues = [];
  for (const [team, points] of m.spawns.entries()) for (const s of points) {
    for (let dy = 1; dy < 19; dy++) for (const dx of [-4, 0, 3.9]) {
      if (solidPx(m, s.x + dx, s.y - dy)) spawnIssues.push({ team, ...s });
    }
  }
  const pickupIssues = m.picks.filter((p) => solidPx(m, p.x, p.y - 4));
  const hatchIssues = m.hatches.filter((h) => {
    const x = Math.floor(h.x / 8), y = Math.floor(h.y / 8);
    return [-2, -1, 1, 2].some((d) => solidT(tileAt(m, x, y + d)));
  });
  const s = m.spawns[0][0];
  const paths = [...m.picks, ...m.spawns[1]].map((p) => ({
    x: p.x, y: p.y, ok: findPath(m, s.x, s.y, p.x, p.y).length > 0,
  }));
  return {
    spawnIssues, pickupIssues, hatchIssues, paths,
    rivers: m.rivers, falls: m.dyn.filter((d) => d.k === "fall"),
    trees: m.decor.filter((d) => ["canopytree", "banyantree"].includes(d.k)).length,
    hides: m.hides.length,
  };
});
await writeFile("artifacts/forest-geometry.json", JSON.stringify(geometry, null, 2));
assert.equal(geometry.spawnIssues.length, 0, "All spawn points must fit standing operators");
assert.equal(geometry.pickupIssues.length, 0, "No pickup may spawn inside rock");
assert.equal(geometry.hatchIssues.length, 0, "Crawl tunnel hatches must have room on both sides");
assert(geometry.rivers.length >= 4, "The forest must have playable rivers");
assert.equal(geometry.falls.length, 5, "Keep all five waterfalls");
assert(geometry.paths.every((p) => p.ok), "Bots must reach all pickups and opposing spawns");

await page.evaluate(async () => {
  const { ArenaGame } = await import("/src/arena/engine.ts");
  window.__chibi?.destroy();
  document.getElementById("root").innerHTML = "";
  const cv = document.createElement("canvas");
  cv.style.cssText = "position:fixed;inset:0;image-rendering:pixelated";
  document.body.append(cv);
  const g = new ArenaGame(cv, { hud() {}, end() {} });
  g.start({ map: 3, size: 4, kills: 50, time: 10, diff: "normal", skin: 6, startWep: "bolter" });
  g.paused = true;
  cancelAnimationFrame(g.raf);
  g.phase = "live"; g.banner = null;
  window.__forestTest = g;
});
await page.waitForTimeout(1000);
for (const [name, tx, ty] of [["riverbank", 44, 63], ["canopy", 88, 33], ["great-falls", 128, 63], ["root-river", 85, 87]]) {
  await page.evaluate(({ tx, ty }) => {
    const g = window.__forestTest;
    g.me.x = tx * 8; g.me.y = ty * 8; g.me.vx = 0; g.me.vy = 0;
    g.cl = Math.max(0, Math.min(g.map.w * 8 - g.W, g.me.x - g.W / 2));
    g.ct = Math.max(0, Math.min(g.map.h * 8 - g.H, g.me.y - 60 - g.H / 2));
    g.cam.x = g.cl + g.W / 2; g.cam.y = g.ct + g.H / 2;
    g.zoom = 1; g.zoomKick = 0; g.roll = 0; g.t = 8.2;
    g.render();
  }, { tx, ty });
  await page.screenshot({ path: `artifacts/forest-${name}.png` });
}

const simulation = await page.evaluate(() => {
  const g = window.__forestTest;
  const river = g.map.rivers[0];
  g.me.x = river.x + 24; g.me.y = river.y + 10; g.me.vy = 30; g.me.fuel = 0.3;
  for (let i = 0; i < 90; i++) g.step(1 / 60);
  const buoyancy = { feet: g.me.y, surface: river.y, fuel: g.me.fuel };
  g.keys.add("KeyW");
  for (let i = 0; i < 30; i++) g.step(1 / 60);
  g.keys.delete("KeyW");
  const leftWater = g.me.y < river.y - 20;
  const fall = g.map.dyn.find((d) => d.k === "fall");
  g.me.fuel = 0.2; g.me.nos = 0.3; g.me.burn = 1;
  for (let i = 0; i < 30; i++) {
    g.me.x = fall.x; g.me.y = fall.y + 30; g.me.vy = 0;
    g.step(1 / 60);
  }
  const cooling = { fuel: g.me.fuel, nos: g.me.nos, burn: g.me.burn };
  const start = performance.now();
  for (let i = 0; i < 600; i++) g.step(1 / 60);
  const elapsed = performance.now() - start;
  const finite = g.sol.every((s) => [s.x, s.y, s.hp, s.armor, s.vx, s.vy].every(Number.isFinite));
  const score = [...g.score];
  g.t = 8; g.render(); const frameA = g.cv.toDataURL();
  g.t = 8.5; g.render(); const animated = frameA !== g.cv.toDataURL();
  const maps = [];
  for (let map = 0; map < 4; map++) {
    g.start({ map, size: 3, kills: 10, time: 3, diff: "easy", skin: map === 3 ? 6 : map, startWep: map === 3 ? "chainsword" : "rifle" });
    cancelAnimationFrame(g.raf); g.phase = "live";
    for (let i = 0; i < 60; i++) g.step(1 / 60);
    maps.push({ map, finite: g.sol.every((s) => [s.x, s.y, s.vx, s.vy].every(Number.isFinite)) });
  }
  g.destroy();
  return { buoyancy, leftWater, cooling, elapsed, finite, animated, score, maps };
});
assert(simulation.finite, "Combat state must remain finite");
assert(simulation.buoyancy.feet - simulation.buoyancy.surface < 17, "Operators should float near the river surface");
assert(simulation.leftWater, "Jetpack must lift operators out of water");
assert(simulation.cooling.fuel > 0.45, "Waterfalls must recharge fuel");
assert.equal(simulation.cooling.burn, 0, "Waterfalls must extinguish burning operators");
assert(simulation.animated, "Water and forest atmospherics must animate");
assert(simulation.maps.every((m) => m.finite), "All four duel arenas must remain playable");
assert.equal(errors.length, 0, `Browser errors: ${errors.join("; ")}`);
const mobile = await browser.newPage({ viewport: { width: 844, height: 390 }, isMobile: true, hasTouch: true });
mobile.on("pageerror", (error) => errors.push(error.message));
await mobile.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
await mobile.getByRole("button", { name: /MASUK ARENA/ }).first().click();
await mobile.getByRole("button", { name: /HUTAN BASTION/ }).click();
await mobile.getByRole("button", { name: /MASUK ARENA/ }).last().click();
await mobile.getByLabel("Stik gerak dan jetpack").waitFor();
await mobile.screenshot({ path: "artifacts/forest-mobile.png" });
await mobile.close();
assert.equal(errors.length, 0, `Mobile browser errors: ${errors.join("; ")}`);
await writeFile("artifacts/forest-verification.json", JSON.stringify({ geometry, simulation, errors }, null, 2));
console.log(JSON.stringify({ paths: geometry.paths.length, rivers: geometry.rivers.length, trees: geometry.trees, simulation, errors }, null, 2));
await browser.close();