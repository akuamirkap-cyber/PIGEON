import { useEffect, useMemo, useRef, useState } from "react";
import "@fontsource/press-start-2p/400.css";
import { Hud } from "./components/Hud";
import { Menu } from "./components/Menu";
import { ChatBox } from "./components/ChatBox";
import { NewYork } from "./ny/NewYork";
import { Arena } from "./arena/Arena";
import { ASTARTES } from "./arena/skins";
import { nyNearestFront } from "./game/nyc";
import { Pause, Results, TouchControls } from "./components/Overlays";
import { RidePanel } from "./components/RidePanel";
import { audio } from "./game/audio";
import type { DiffId, GameMode, WeatherId } from "./game/defs";
import { Game } from "./game/engine";
import { HOUSES, WINDOWS } from "./game/map";
import type { HudState, MatchResult } from "./game/engine";

type Screen = "menu" | "game" | "result";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const [hud, setHud] = useState<HudState | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [skin, setSkin] = useState(ASTARTES);
  const [diff, setDiff] = useState<DiffId>("normal");
  const [mode, setMode] = useState<GameMode>("pvp");
  const [weather, setWeather] = useState<WeatherId>("day"); // a bright morning by default: the city - and its buildings - are best seen in daylight
  const [chatOpen, setChatOpen] = useState(false);
  const [lvl, setLvl] = useState(1);
  const [loading, setLoading] = useState(false);
  const [ny, setNy] = useState<"" | "peace" | "zombie">("");
  /** the side-view team deathmatch (DUEL TIM) runs on its own canvas: the menu game waits behind it */
  const [arena, setArena] = useState(false);
  useEffect(() => { if (game) game.halt = !!ny || arena; }, [ny, arena, game]);
  const coarse = useMemo(() => typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches, []);

  useEffect(() => {
    const g = new Game(canvasRef.current!, {
      onHud: setHud,
      onChat: setChatOpen,
      onMatchEnd: (r) => {
        setResult(r);
        setScreen("result");
      },
    });
    g.startDemo();
    setGame(g);
    // debug handle for testing from the console
    (window as unknown as { __chibi?: Game; __chibiHouses?: () => unknown }).__chibi = g;
    (window as unknown as { __chibiHouses?: () => unknown }).__chibiHouses = () => HOUSES;
    (window as unknown as { __chibiWins?: () => unknown }).__chibiWins = () => WINDOWS;
    (window as unknown as { __nyFront?: unknown }).__nyFront = nyNearestFront;
    return () => g.destroy();
  }, []);

  const click = () => {
    audio.unlock();
    audio.play("click");
  };
  /** level 1 = the usual maps; level 3 = the co-op zombie game on the streets of New York (the city has to be built first) */
  const start = (m: GameMode, level: number) => {
    click();
    setResult(null);
    setLvl(level);
    const zSkin = skin < 5 ? skin : 1;
    if (level === 3) {
      setLoading(true);
      setTimeout(() => {
        game?.startMatch(zSkin, diff, "bugs", weather, 3);
        setScreen("game");
        setLoading(false);
      }, 80);
    } else {
      setScreen("game");
      game?.startMatch(zSkin, diff, m, weather, level);
    }
  };
  const play = () => {
    if (mode === "pvp") { click(); setArena(true); return; }
    start(mode, 1);
  };
  const toMenu = () => {
    click();
    setResult(null);
    setChatOpen(false);
    game?.closeChat();
    setScreen("menu");
    game?.startDemo();
  };

  const inGame = screen === "game" && hud?.mode === "play";
  const inPlay = inGame && !hud.ride; // (on the bus between two maps the fight is far away)
  const showTouch = inPlay && (coarse || hud.touch) && !hud.paused;

  return (
    <div className={`fixed inset-0 select-none overflow-hidden bg-[#0b0910] ${inPlay && !hud.paused && !showTouch ? "cursor-none" : ""}`}>
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
        <canvas ref={canvasRef} className="game" />
      </div>

      {inPlay && game && showTouch && <TouchControls game={game} />}
      {inPlay && game && (
        <Hud hud={hud} onSelect={(i) => game.selectWeapon(i)} onPause={() => game.togglePause()} onMute={() => game.toggleMute()} onStrat={(n) => game.action(n === 0 ? "strat1" : "strat2")} />
      )}
      {inPlay && game && hud.game === "bugs" && !hud.paused && !chatOpen && (
        <button onClick={() => game.openChat()} className="btn btn-dark absolute left-2 top-[98px] z-20 px-2 py-1.5 font-pixel text-[7px]">[T] OBROL DENGAN TIM</button>
      )}
      {inPlay && game && hud.game === "bugs" && !hud.paused && !chatOpen && (
        <button onClick={() => game.toggleRest()} className={`btn absolute left-2 top-[128px] z-20 px-2 py-1.5 font-pixel text-[7px] ${hud.resting ? "btn-on" : "btn-dark"}`}>[C] {hud.resting ? "BERDIRI" : "ISTIRAHAT"} · [SHIFT] LARI</button>
      )}
      {inPlay && game && hud.game === "bugs" && !hud.paused && !chatOpen && (
        <button onClick={() => game.skipMission()} className="btn btn-dark absolute left-2 top-[158px] z-20 px-2 py-1.5 font-pixel text-[7px]">[F] LEWATI MISI</button>
      )}
      {inPlay && game && hud.game === "bugs" && (hud.nearBus || hud.driving) && !hud.paused && !chatOpen && (
        <button onClick={() => game.bug.toggleBus()} className={`btn absolute left-2 top-[188px] z-20 px-2 py-1.5 font-pixel text-[7px] ${hud.driving ? "btn-on" : "btn-dark"}`}>
          [G] {hud.driving ? "TURUN BUS" : "NAIK BUS"}
        </button>
      )}
      {inPlay && game && !hud.paused && (
        <button onClick={() => game.toggleMusic()} className={`btn absolute right-2 top-[44px] z-20 px-2 py-1.5 font-pixel text-[7px] ${hud.music ? "btn-on" : "btn-dark"}`}>[N] MUSIK {hud.music ? "ON" : "OFF"}</button>
      )}
      {inPlay && game && hud.game === "bugs" && hud.safe > 0 && !hud.paused && (
        <div className="ts pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap px-2 py-1 font-pixel text-[7px]" style={{ top: hud.boss >= 0 ? 118 : 78, background: "rgba(12,10,16,0.88)", color: hud.safe === 3 ? "#7dff9a" : hud.safe === 2 ? "#ff6b7a" : "#f5c542", boxShadow: `0 0 0 2px #0a0a0f, 0 0 0 3px ${hud.safe === 3 ? "#7dff9a" : hud.safe === 2 ? "#ff6b7a" : "#f5c542"}` }}>
          {hud.safe === 3 ? "TEMPAT AMAN - [C] ISTIRAHAT SAMPAI PULIH" : hud.safe === 2 ? "PINTU TERTUTUP - MASIH ADA ZOMBIE DI DALAM!" : "[E] TUTUP PINTU - JADIKAN TEMPAT BERLINDUNG"}
        </div>
      )}
      {inPlay && game && hud.game === "bugs" && hud.perch && !hud.paused && (
        <div className="ts pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap px-2 py-1 font-pixel text-[7px]" style={{ top: hud.boss >= 0 ? 118 : 78, background: "rgba(12,10,16,0.88)", color: "#8af0ff", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #8af0ff" }}>
          {hud.perch} · [W] NAIK · [S] TURUN · [A/D] GESER · [SPASI] LOMPAT TURUN
        </div>
      )}
      {inPlay && game && hud.game === "bugs" && hud.driving && !hud.paused && (
        <div className="ts pointer-events-none absolute left-1/2 z-10 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap px-2 py-1 font-pixel text-[7px]" style={{ top: hud.boss >= 0 ? 118 : 78, background: "rgba(12,10,16,0.88)", color: "#ffd75e", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #ffd75e" }}>
          <span>BUS SEKOLAH · [WASD] SETIR · [KLIK] TEMBAK · [SPASI] TURBO · [G] TURUN</span>
          {hud.canDepart && (
            <button onClick={() => game.boardTruck()} className="btn pointer-events-auto px-2 py-0.5 text-[7px]">
              [ENTER] BERANGKAT!
            </button>
          )}
        </div>
      )}
      {inPlay && game && hud.game === "bugs" && hud.nearBus && !hud.driving && hud.safe === 0 && !hud.paused && (
        <div className="ts pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap px-2 py-1 font-pixel text-[7px]" style={{ top: hud.boss >= 0 ? 118 : 78, background: "rgba(12,10,16,0.88)", color: "#ffd75e", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #ffd75e" }}>
          [G] ATAU [E] KENDARAI BUS SEKOLAH
        </div>
      )}
      {screen === "menu" && game && !ny && !arena && (
        <button onClick={() => { audio.unlock(); game.toggleMusic(); }} className={`btn absolute right-3 top-3 z-30 px-3 py-2 font-pixel text-[8px] ${hud?.music ? "btn-on" : "btn-dark"}`}>MUSIK {hud?.music ? "ON" : "OFF"}</button>
      )}
      {inPlay && game && chatOpen && <ChatBox onSend={(t) => game.talk.hear(t)} onClose={() => game.closeChat()} />}
      {inGame && game && hud.ride && !hud.paused && <RidePanel ride={hud.ride} onAct={(id) => { audio.unlock(); game.ride?.act(id); }} />}
      {inGame && game && hud.paused && (
        <Pause muted={hud.muted} onResume={() => { click(); game.togglePause(false); }} onMute={() => game.toggleMute()} onQuit={toMenu} />
      )}

      {screen === "menu" && (
        <Menu
          skin={skin}
          setSkin={(s) => { click(); setSkin(s); }}
          diff={diff}
          setDiff={(d) => { click(); setDiff(d); }}
          mode={mode}
          setMode={(m) => { click(); setMode(m); }}
          weather={weather}
          setWeather={(w) => { click(); setWeather(w); }}
          onPlay={play}
          onNY={() => { click(); setNy("peace"); }}
          onNYZ={() => start("bugs", 3)}
        />
      )}
      {loading && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-4 bg-[#0b0910]/90 font-pixel">
          <div className="ts-big text-2xl text-[#f5c542] sm:text-4xl">NEW YORK</div>
          <div className="ts blink text-[9px] text-white sm:text-xs">MEMBANGUN KOTA...</div>
        </div>
      )}
      {ny && <NewYork key={ny} zombie={ny === "zombie"} onExit={() => setNy("")} />}
      {arena && <Arena skin={skin <= ASTARTES ? skin : ASTARTES} diff={diff} onExit={() => setArena(false)} />}
      {screen === "result" && result && <Results result={result} onAgain={() => start(lvl === 3 ? "bugs" : mode, lvl)} onMenu={toMenu} />}
    </div>
  );
}
