import type { RideHud } from "../game/ride";

interface Props {
  ride: RideHud;
  onAct: (id: string) => void;
}

interface BtnProps {
  id: string;
  k: string;
  label: string;
  sub: string;
  on?: boolean;
  dim?: boolean;
  onAct: (id: string) => void;
}

function Btn({ id, k, label, sub, on, dim, onAct }: BtnProps) {
  return (
    <button
      onClick={() => onAct(id)}
      className={`btn ${on ? "btn-on" : "btn-dark"} min-w-[92px] px-2 py-2 text-left font-pixel text-[7px] leading-tight sm:min-w-[112px] sm:text-[8px] ${dim ? "opacity-50" : ""}`}
    >
      <span className="block whitespace-nowrap">[{k}] {label}</span>
      <span className="mt-1.5 block whitespace-nowrap text-[6px] opacity-80 sm:text-[7px]">{sub}</span>
    </button>
  );
}

/** the road trip between two maps: what you can do while the bus drives */
export function RidePanel({ ride, onAct }: Props) {
  const busy = !!ride.busy;
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-3 z-30 flex flex-col items-center gap-2 px-2">
      <div
        className="ts whitespace-nowrap px-3 py-1.5 font-pixel text-[7px] text-white sm:text-[9px]"
        style={{ background: "rgba(12,10,16,0.88)", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #f5c542" }}
      >
        HP <span style={{ color: ride.hp < 40 ? "#ff6b7a" : ride.hp < 75 ? "#f5c542" : "#7dff9a" }}>{ride.hp}</span>
        <span className="mx-2 text-[#5b5d69]">|</span>
        SENJATA <span className="text-[#9fd8ff]">{ride.weapon}</span>
        <span className="mx-2 text-[#5b5d69]">|</span>
        OBAT <span className="text-[#7dff9a]">x{ride.meds}</span>
      </div>
      <div className="pointer-events-auto flex max-w-[760px] flex-wrap items-stretch justify-center gap-1.5">
        <Btn id="med" k="1" label="PAKAI OBAT" sub={ride.meds > 0 ? "+45 HP SEMUA" : "HABIS"} dim={busy || ride.meds <= 0} onAct={onAct} />
        <Btn id="fix" k="2" label="SERVIS SENJATA" sub={ride.tuned ? "PRIMA +15%" : "BONGKAR & SETEL"} on={ride.tuned} dim={busy} onAct={onAct} />
        <Btn id="load" k="3" label="ISI PELURU" sub={ride.loaded ? "SEMUA PENUH" : "SEMUA MAGASIN"} on={ride.loaded} dim={busy} onAct={onAct} />
        <Btn id="gun" k="4" label="GANTI SENJATA" sub={ride.weapon} dim={busy} onAct={onAct} />
        <Btn id="nap" k="5" label="TIDUR" sub={ride.napped ? "SEGAR!" : "+20 HP & TENAGA"} on={ride.napped} dim={busy} onAct={onAct} />
        <Btn id="go" k="ENTER" label={ride.ready ? "TURUN!" : "LANGSUNG TIBA"} sub={ride.next} on={ride.ready} onAct={onAct} />
      </div>
    </div>
  );
}
