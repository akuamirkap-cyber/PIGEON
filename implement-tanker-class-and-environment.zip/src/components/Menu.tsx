import type { ReactNode } from "react";
import { DIFFS, SURVIVORS, WEAPONS, WEAPON_ORDER } from "../game/defs";
import type { DiffId, GameMode, WeatherId } from "../game/defs";
import { PERSONA } from "../game/talk";
import { portrait, weaponIcon } from "../game/sprites";
import { AWEP, AW_ORDER, awIcon, isTankWep } from "../arena/weapons";
import { ARENA_SKINS, ASTARTES, SKIN_TAGS, opPortrait } from "../arena/skins";

const ARENA_KEYS: [string, string][] = [
  ["A / D", "Jalan"],
  ["W / SPASI", "Jetpack / Jump-Pack ganda"],
  ["S (DI UDARA)", "Tukik Meteor Slam!"],
  ["B / V", "Bolter Rifle & Chainsword (Astartes)"],
  ["SHIFT", "Sprint + NOS"],
  ["MOUSE", "Bidik 360°"],
  ["KLIK KIRI", "Tembak / kombo Chainsword"],
  ["KLIK KANAN", "Perisai Iron Halo / Hologram"],
  ["G", "Granat"],
  ["1-0 / - / = / K / T / P", "Pilih semua senjata"],
  ["Q", "Tukar cepat (Bolter ⇄ Chainsword)"],
  ["F", "Tebasan SAMPING / pukul"],
  ["E", "Sembunyi / ambil"],
  ["S", "Merunduk / jalan tikus"],
  ["R", "Reload"],
  ["TAB", "Papan skor"],
];
const KEYS: [string, string][] = [
  ["WASD", "Gerak"],
  ["MOUSE", "Bidik"],
  ["KLIK KIRI", "Tembak / tebas"],
  ["SPACE", "Dash (kebal sesaat)"],
  ["1-6 / SCROLL / Q", "Ganti senjata"],
  ["R", "Reload"],
  ["E / F", "Rudal / turret (mode zombie)"],
  ["ESC", "Pause"],
];

function Panel({ title, children, className = "" }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={`panel p-3 sm:p-4 ${className}`}>
      <h2 className="mb-3 text-[9px] text-[#f5c542] sm:text-[10px]">
        <span className="text-[#ff4d5e]">//</span> {title}
      </h2>
      {children}
    </section>
  );
}

interface Props {
  skin: number;
  setSkin: (s: number) => void;
  diff: DiffId;
  setDiff: (d: DiffId) => void;
  mode: GameMode;
  setMode: (m: GameMode) => void;
  weather: WeatherId;
  setWeather: (w: WeatherId) => void;
  onPlay: () => void;
  onNY: () => void;
  onNYZ: () => void;
}

const SKY: [WeatherId, string][] = [["auto", "DINAMIS"], ["rain", "HUJAN DERAS"], ["fog", "KABUT"], ["clear", "SIANG BERAWAN"], ["day", "PAGI CERAH"]];

export function Menu({ skin, setSkin, diff, setDiff, mode, setMode, weather, setWeather, onPlay, onNY, onNYZ }: Props) {
  const bugs = mode === "bugs";
  return (
    <div className="scroll-thin absolute inset-0 z-20 overflow-y-auto font-pixel text-white" style={{ background: "radial-gradient(ellipse at center, rgba(11,9,16,0.5) 0%, rgba(11,9,16,0.86) 85%)" }}>
      <div className="mx-auto flex min-h-full w-full max-w-5xl flex-col items-center justify-center gap-4 px-4 py-3">
        <header className="flex flex-col items-center text-center">
          <div className="mb-3 bg-[#ff4d5e] px-2 py-1 text-[7px] text-[#0a0a0f] sm:text-[9px]">{bugs ? "CO-OP 4 PENYINTAS - KABUR DARI KOTA ZOMBIE" : "ARENA SIDE-VIEW - JETPACK TEAM DEATHMATCH"}</div>
          <h1 className="ts-big text-3xl leading-tight text-[#f5c542] sm:text-4xl lg:text-6xl">
            CHIBI <span className="text-white">STRIKE</span>
          </h1>
          <p className="ts mt-4 text-[8px] text-[#e9e2d2] sm:text-[10px]">MINI WARFARE - TAKTIS TAPI IMUT</p>
        </header>

        <div className="grid w-full gap-5 md:grid-cols-2">
          <div className="flex flex-col gap-5">
            <Panel title={bugs ? "PILIH PENYINTAS" : "PILIH OPERATOR"}>
              <div className={`grid gap-2 ${bugs ? "grid-cols-5" : "grid-cols-4 sm:grid-cols-7"}`}>
                {(bugs ? SURVIVORS : ARENA_SKINS).map((name, i) => {
                  const isMarine = !bugs && i === ASTARTES;
                  const on = bugs ? i === (skin < SURVIVORS.length ? skin : 1) : i === skin;
                  return (
                    <button key={name} onClick={() => setSkin(i)} className={`relative flex cursor-pointer flex-col items-center justify-end gap-1.5 px-1 py-2 ${on ? "bg-[#f5c542]/25" : isMarine ? "bg-[#182442] hover:bg-[#22325c]" : "bg-[#1a1822] hover:bg-[#262330]"}`} style={{ boxShadow: on ? `0 0 0 2px ${isMarine ? "#ffe26a" : "#f5c542"}` : isMarine ? "0 0 0 2px #4a82e8" : "0 0 0 2px #0a0a0f" }}>
                      {isMarine && <span className="absolute -top-1.5 bg-[#ffe26a] px-1 py-0.5 text-[4.5px] text-[#0a0a0f]">★ TANK</span>}
                      <img src={bugs ? portrait(i, 2) : opPortrait(i)} alt={name} className={`px object-contain ${bugs ? "h-[44px] w-8 sm:h-[66px] sm:w-12" : isMarine ? "h-[52px] w-10 sm:h-[66px] sm:w-[50px]" : "h-[46px] w-8 sm:h-[60px] sm:w-10"} ${on ? "hop" : "opacity-75"}`} />
                      <span className={`text-[5.5px] sm:text-[6.5px] ${on ? "text-[#ffe26a]" : isMarine ? "text-[#9ec8ff]" : "text-white/70"}`}>{name}</span>
                      <span className={`hidden text-[4.5px] sm:block ${isMarine ? "text-[#f5c542]" : "text-white/40"}`}>{bugs ? PERSONA[i].trait : SKIN_TAGS[i]}</span>
                    </button>
                  );
                })}
              </div>
              {!bugs && skin === ASTARTES && (
                <div className="mt-3 bg-[#141c34] p-2.5 text-[6px] leading-[1.85] text-[#e8eeff] sm:text-[7px]" style={{ boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #ffe26a" }}>
                  <span className="text-[#ffe26a]">★ TANKER SPACE MARINE (ADEPTUS ASTARTES):</span> Armor tebal <span className="text-[#ffe26a]">220 Ceramite</span> + <span className="text-[#7dff9a]">135 HP</span> + Jump-Pack Ganda &amp; <span className="text-[#ffb03a]">Meteor Slam [S di udara]</span>. Senjata eksklusif: <span className="text-[#ffd24a]">BOLTER RIFLE [B]</span> (peluru kendali mini mass-reactive) &amp; <span className="text-[#ff7a5a]">CHAINSWORD [V]</span> (pedang rantai perobek lapis baja)!
                </div>
              )}
            </Panel>

            <Panel title="TINGKAT KESULITAN">
              <div className="grid grid-cols-3 gap-3 pb-1.5">
                {(Object.keys(DIFFS) as DiffId[]).map((d) => (
                  <button key={d} onClick={() => setDiff(d)} className={`btn px-1 py-2.5 text-[8px] sm:text-[10px] ${d === diff ? "btn-on" : "btn-dark"}`}>
                    {DIFFS[d].label}
                  </button>
                ))}
              </div>
            </Panel>

            {bugs && (
              <Panel title="CUACA">
                <div className="grid grid-cols-5 gap-1.5 pb-1.5">
                  {SKY.map(([id, label]) => (
                    <button key={id} onClick={() => setWeather(id)} className={`btn px-0.5 py-2.5 text-[6px] sm:text-[8px] ${id === weather ? "btn-on" : "btn-dark"}`}>
                      {label}
                    </button>
                  ))}
                </div>
              </Panel>
            )}

            <button onClick={onPlay} className="btn mx-1 mb-2 px-4 py-4 text-sm sm:text-lg">
              <span className="blink">&gt;</span> {bugs ? "MASUK KE KOTA" : "MASUK ARENA"}
            </button>
          </div>

          <div className="flex flex-col gap-5">
            <Panel title="PILIH MODE" className="panel-red">
              <div className="grid grid-cols-2 gap-3 pb-1.5">
                <button onClick={() => setMode("pvp")} className={`btn flex flex-col items-center gap-1.5 px-1 py-2.5 ${!bugs ? "btn-on" : "btn-dark"}`}>
                  <span className="text-[8px] sm:text-[10px]">DUEL TIM</span>
                  <span className="text-[6px] opacity-70">ARENA SIDE-VIEW</span>
                </button>
                <button onClick={() => setMode("bugs")} className={`btn flex flex-col items-center gap-1.5 px-1 py-2.5 ${bugs ? "btn-on" : "btn-dark"}`}>
                  <span className="text-[8px] sm:text-[10px]">KOTA ZOMBIE</span>
                  <span className="text-[6px] opacity-70">CO-OP MISI KABUR</span>
                </button>
              </div>
              {bugs ? (
                <p className="mt-3 text-[7px] leading-[2] text-[#e9e2d2] sm:text-[8px]">
                  Jelajahi <span className="text-[#f5c542]">rumah besar dua lantai & minimarket</span> untuk cari <span className="text-[#5ff0e0]">baterai</span>,{" "}
                  <span className="text-[#ff6b7a]">bensin</span>, dan <span className="text-[#ffb347]">suar</span>. Bawa ke{" "}
                  <span className="text-[#7dff9a]">zona evac</span>, panggil helikopter, bertahan, lalu kabur! Temanmu punya sifat sendiri: mereka ngobrol, khawatir, dan saling menolong. Penyintas yang kamu temukan ikut angkat senjata, dan di antara dua map kalian istirahat di BUS SEKOLAH: obati luka, servis & isi senjata.
                </p>
              ) : (
                <p className="mt-3 text-[7px] leading-[2] text-[#e9e2d2] sm:text-[8px]">
                  Jelajahi <span className="text-[#cbb6e2]">GOA KRISTAL AGUNG: CRYSTAL SANCTUM</span>, perpaduan gua kristal klasik dengan kemegahan Hollow Earth, rune kuno, sungai aquamarine &amp; air terjun berkabut. Atau terbang di <span className="text-[#8eff84]">HUTAN BASTION</span> yang rimbun! Pakai Tanker <span className="text-[#ffe26a]">ASTARTES</span> dengan <span className="text-[#ffe26a]">220 Ceramite</span>, Jump-Pack <span className="text-[#ffb03a]">Meteor Slam</span>, <span className="text-[#ffd24a]">BOLTER RIFLE</span> &amp; <span className="text-[#ff7a5a]">CHAINSWORD</span>.
                </p>
              )}
            <button onClick={onNY} className="mt-3 flex w-full cursor-pointer items-center justify-between gap-2 bg-[#14162a] px-3 py-2.5 text-left hover:bg-[#1f2344]" style={{ boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 4px #3ad0ff" }}>
                <span>
                  <span className="block text-[8px] text-[#3ad0ff] sm:text-[10px]">★ NEW YORK - SEBELUM WABAH</span>
                  <span className="mt-1.5 block text-[5px] leading-relaxed text-white/60 sm:text-[7px]">Jelajahi kota, masuk gedung unik, kunjungi Mega Mall 3 lantai, naik lift, dan kumpulkan benda. Belum ada zombie.</span>
                </span>
                <span className="blink text-[10px] text-[#ffd23a]">&gt;</span>
              </button>
            <button onClick={onNYZ} className="mt-3 flex w-full cursor-pointer items-center justify-between gap-2 bg-[#1c0a10] px-3 py-2.5 text-left hover:bg-[#2c1018]" style={{ boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 4px #ff4d5e" }}>
                <span>
                  <span className="block text-[8px] text-[#ff7a8a] sm:text-[10px]">☣ NEW YORK - HARI WABAH</span>
                  <span className="mt-1.5 block text-[5px] leading-relaxed text-white/60 sm:text-[7px]">Hari wabah dimulai dari kota normal: warga lengkap seperti Sebelum Wabah beraktivitas, 4 detik kemudian 1 zombie muncul dan menggigit - yang tergigit berubah dalam 2 detik sampai seluruh kota jatuh. Lalu buka 3 peti suplai, selamatkan penyintas, dan kabur dengan heli di Battery Park.</span>
                </span>
                <span className="blink text-[10px] text-[#ffd23a]">&gt;</span>
              </button>
            </Panel>

            <Panel title="ARSENAL">
              <ul className="flex flex-col gap-2">
                {!bugs && AW_ORDER.map((id, i) => (
                  <li key={id} className="flex items-center gap-3">
                    <span className="w-4 text-[8px] text-[#f5c542]">{i + 1}</span>
                    <span className="flex w-[56px] flex-none justify-center"><img src={awIcon(id)} alt="" className="px h-[16px] w-auto" /></span>
                    <div className="flex min-w-0 flex-col gap-1">
                      <span className={`flex items-center gap-1.5 text-[8px] ${isTankWep(id) ? "text-[#ffe26a]" : "text-white"}`}>
                        {AWEP[id].name}
                        {isTankWep(id) && <span className="bg-[#c42032] px-1 py-0.5 text-[5px] text-white">★ TANKER ASTARTES</span>}
                      </span>
                      <span className="text-[6px] leading-[1.7] text-white/60 sm:text-[7px]">{AWEP[id].desc}</span>
                    </div>
                  </li>
                ))}
                {bugs && WEAPON_ORDER.map((id, i) => (
                  <li key={id} className="flex items-center gap-3">
                    <span className="w-3 text-[8px] text-[#f5c542]">{i + 1}</span>
                    <img src={weaponIcon(id)} alt="" className="px h-[20px] w-[52px] flex-none" />
                    <div className="flex min-w-0 flex-col gap-1">
                      <span className="text-[8px] text-white">{WEAPONS[id].name}</span>
                      <span className="text-[6px] leading-[1.7] text-white/55 sm:text-[7px]">{WEAPONS[id].desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </Panel>

          </div>

          <Panel title="KONTROL" className="md:col-span-2">
            <ul className="flex flex-wrap gap-x-5 gap-y-2.5">
              {(bugs ? KEYS : ARENA_KEYS).map(([k, v]) => (
                <li key={k} className="flex items-center gap-2 text-[7px]">
                  <span className="flex-none bg-[#23212c] px-1.5 py-1 text-[#f5c542]" style={{ boxShadow: "0 0 0 1px #0a0a0f, 0 2px 0 1px #3b3848" }}>{k}</span>
                  <span className="text-white/70">{v}</span>
                </li>
              ))}
              <li className="flex items-center text-[7px] text-white/40">{bugs ? "Di HP: stik kiri gerak, stik kanan bidik + tembak" : "Di HP: stik kiri jalan + jetpack, stik kanan bidik + tembak"}</li>
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}
