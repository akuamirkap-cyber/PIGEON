import { TILE } from "./defs";
import { CRATES, HOUSES, hall, house, kindAt, link, loadCustom, portalAt, put } from "./map";
import { glyphs } from "./sprites";
import type { Pt } from "./map";
import { BUCKET, generateWorld } from "../ny/world";
import type { Obj, World } from "../ny/world";
import { ATLAS_COLS, ICE, buildAtlas, isRoad, isWater } from "../ny/tiles";
import { buildCars, buildProps } from "../ny/sprites";
import type { Props } from "../ny/sprites";
import { drawBoard } from "../ny/buildings";
import { MH as NH, MW as NW } from "../ny/util";
import { boardShift, boardShiftY, canClimb, draw3D, fireEscape } from "../ny/b3d";
import { drawCar3D } from "../ny/car3d";

/**
 * New York as a map for the co-op zombie game: the streets, buildings and wrecks come from the New York world,
 * everything that moves, shoots and bites is the co-op game itself.
 */
type Cv = HTMLCanvasElement;
/** an abandoned car, cab, bus or food truck standing in its lane */
export interface Wreck { x: number; y: number; dir: number; spr: Cv; len: number; sy: number; kind: number; body: string; sign?: string }
/** something of New York in the y-sorted pass: a building / tree / lamp / sign, or a wreck */
export interface NyItem { o?: Obj; c?: Wreck }
interface NY {
  w: World; props: Props; floor: Cv; clean: Cv; blank: Cv; cars: Wreck[]; spawns: Pt[]; nests: Pt[];
  pad: { x: number; y: number; w: number; h: number }; truck: Pt; truckT: number[]; frame: number; cache: Obj[]; vis: Obj[]; places: Place[];
}
/** somewhere you can go into: a building (kind 0) or a subway station (1). (sx, sy) = its door tile in the street, (x, y, w, h) = its inside */
interface Place { kind: number; name: string; sx: number; sy: number; x: number; y: number; w: number; h: number; hi: number }
/** rows of interiors below the city */
export const NY_STRIP = 38;
let ny: NY | null = null;

const mkc = (w: number, h: number): Cv => {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
};
const freeT = (w: World, tx: number, ty: number) => {
  if (tx < 1 || ty < 1 || tx >= NW - 1 || ty >= NH - 1) return false;
  const i = ty * NW + tx;
  return !w.solid[i] && !isWater(w.tiles[i]) && w.tiles[i] !== ICE;
};
/** closest walkable tile to (tx, ty); with `room` the eight tiles around it must be walkable too */
function nearFree(w: World, tx: number, ty: number, room = false): [number, number] {
  for (let r = 0; r < 16; r++)
    for (let j = -r; j <= r; j++)
      for (let i = -r; i <= r; i++) {
        if (Math.max(Math.abs(i), Math.abs(j)) !== r || !freeT(w, tx + i, ty + j)) continue;
        if (room) {
          let ok = true;
          for (let b = -1; b <= 1 && ok; b++) for (let a = -1; a <= 1; a++) if (!freeT(w, tx + i + a, ty + j + b)) { ok = false; break; }
          if (!ok) continue;
        }
        return [tx + i, ty + j];
      }
  return [tx, ty];
}
const ctr = (tx: number, ty: number): Pt => ({ x: (tx + 0.5) * TILE, y: (ty + 0.5) * TILE });

function build(): NY {
  const types = buildCars(), props = buildProps(), w = generateWorld(props, types);
  // the ground: every tile of the city, drawn once
  const floor = mkc(NW * TILE, (NH + NY_STRIP) * TILE), g = floor.getContext("2d")!, atlas = buildAtlas()[0];
  g.imageSmoothingEnabled = false;
  for (let ty = 0; ty < NH; ty++)
    for (let tx = 0; tx < NW; tx++) {
      const id = w.gfx[ty * NW + tx];
      g.drawImage(atlas, (id % ATLAS_COLS) * TILE, ((id / ATLAS_COLS) | 0) * TILE, TILE, TILE, tx * TILE, ty * TILE, TILE, TILE);
    }
  // the squad starts where the walk through New York starts
  const [s0x, s0y] = nearFree(w, Math.floor(w.start.x / TILE), Math.floor(w.start.y / TILE), true);
  const spawns: Pt[] = [];
  for (let r = 0; r < 6 && spawns.length < 5; r++)
    for (let j = -r; j <= r && spawns.length < 5; j++)
      for (let i = -r; i <= r && spawns.length < 5; i++) if (Math.max(Math.abs(i), Math.abs(j)) === r && freeT(w, s0x + i, s0y + j)) spawns.push(ctr(s0x + i, s0y + j));
  while (spawns.length < 5) spawns.push(ctr(s0x, s0y));
  // the helicopter comes to Battery Park
  const bp = w.landmarks.find((l) => /Battery/i.test(l.name)) ?? w.landmarks[w.landmarks.length - 1];
  const [pcx, pcy] = nearFree(w, bp.x, bp.y, true);
  const pad = { x: pcx - 5, y: pcy - 5, w: 10, h: 10 }, pc = ctr(pcx, pcy);
  const px0 = pad.x * TILE, py0 = pad.y * TILE;
  g.fillStyle = "rgba(16,18,26,0.4)";
  g.fillRect(px0, py0, 160, 160);
  g.fillStyle = "#f5c542";
  for (let i = 0; i < 160; i += 12) { g.fillRect(px0 + i, py0, 7, 2); g.fillRect(px0 + i, py0 + 158, 7, 2); g.fillRect(px0, py0 + i, 2, 7); g.fillRect(px0 + 158, py0 + i, 2, 7); }
  g.strokeStyle = "#f5c542";
  g.lineWidth = 2;
  g.beginPath();
  g.arc(pc.x, pc.y, 26, 0, 6.283);
  g.stroke();
  g.fillRect(pc.x - 10, pc.y - 12, 4, 24); g.fillRect(pc.x + 6, pc.y - 12, 4, 24); g.fillRect(pc.x - 10, pc.y - 2, 20, 4);
  // the white pickup the squad came in: on the road next to the start
  let truck = { x: spawns[0].x + 48, y: spawns[0].y }, truckT: number[] = [];
  // (it needs a long, straight, empty street: it comes in fast and it leaves fast)
  const lane = (tx: number, ty: number, n: number) => {
    for (let i = -n; i <= n; i++) if (!freeT(w, tx + i, ty) || !isRoad(w.tiles[ty * NW + tx + i])) return false;
    return true;
  };
  search: for (const n of [14, 1])
    for (let r = 3; r < 16; r++)
      for (let j = -r; j <= r; j++)
        for (let i = -r; i <= r; i++) {
          const tx = s0x + i, ty = s0y + j;
          if (Math.max(Math.abs(i), Math.abs(j)) !== r || !lane(tx, ty, n)) continue;
          truck = ctr(tx, ty);
          truckT = [];
          for (const k of [-2, -1, 0, 1, 2]) if (Math.abs(k) < 2 || freeT(w, tx + k, ty)) truckT.push(tx + k, ty); // a school bus is a long thing
          break search;
        }
  if (truckT.length) {
    // the squad climbs out right next to it
    const tx = Math.floor(truck.x / TILE), ty = Math.floor(truck.y / TILE);
    spawns.length = 0;
    for (const j of [1, -1, 2, -2]) for (const i of [0, -1, 1, -2, 2]) if (spawns.length < 5 && freeT(w, tx + i, ty + j)) spawns.push(ctr(tx + i, ty + j));
    while (spawns.length < 5) spawns.push(spawns[0] ?? ctr(s0x, s0y));
  }
  // wrecks: the traffic stopped for good - cars, cabs, buses and food trucks left in their lanes
  const cars: Wreck[] = [], L = w.lanes, cand = types.filter((t) => t.kind !== 5);
  for (let n = 0, tries = 0; n < 300 && tries < 4000; tries++) {
    const k = ((Math.random() * (L.length / 3)) | 0) * 3, x = L[k] + (Math.random() * 8 - 4), y = L[k + 1] + (Math.random() * 8 - 4), dir = L[k + 2];
    if (Math.hypot(x - spawns[0].x, y - spawns[0].y) < 110 || Math.hypot(x - pc.x, y - pc.y) < 130 || Math.hypot(x - truck.x, y - truck.y) < 80 || (Math.abs(y - truck.y) < 28 && Math.abs(x - truck.x) < 360)) continue;
    if (cars.some((c) => Math.abs(c.x - x) < 50 && Math.abs(c.y - y) < 50)) continue;
    const t = cand[(Math.random() * cand.length) | 0];
    cars.push({ x, y, dir, spr: t.c[dir], len: t.len, sy: y + (dir % 2 ? 6 : t.len / 2), kind: t.kind, body: t.body, sign: t.sign });
    n++;
  }
  // the holes the dead climb out of: one on the asphalt of every few blocks
  const nests: Pt[] = [];
  for (let ty = 5; ty < NH - 5; ty += 11)
    for (let tx = 5; tx < NW - 5; tx += 11) {
      let done = false;
      for (let j = 0; j < 11 && !done; j++)
        for (let i = 0; i < 11; i++) {
          const X = tx + i, Y = ty + j, q = Y * NW + X, p = ctr(X, Y);
          if (!isRoad(w.tiles[q]) || !freeT(w, X, Y) || cars.some((c) => Math.abs(c.x - p.x) < 34 && Math.abs(c.y - p.y) < 34)) continue;
          if (Math.hypot(p.x - spawns[0].x, p.y - spawns[0].y) < 220 || Math.hypot(p.x - pc.x, p.y - pc.y) < 200 || (Math.abs(p.y - truck.y) < 24 && Math.abs(p.x - truck.x) < 260)) continue;
          nests.push(p);
          done = true;
          break;
        }
    }
  // ...and the holes themselves, broken through the asphalt
  for (const n of nests) {
    g.fillStyle = "#3a3c46";
    g.beginPath(); g.ellipse(n.x, n.y + 2, 11, 7, 0, 0, 6.283); g.fill();
    g.fillStyle = "#0a0a10";
    g.beginPath(); g.ellipse(n.x, n.y + 2, 8, 5, 0, 0, 6.283); g.fill();
    g.fillStyle = "#5a5c68";
    for (let i = 0; i < 6; i++) g.fillRect(Math.round(n.x + Math.cos(i * 1.05) * 12) - 1, Math.round(n.y + 2 + Math.sin(i * 1.05) * 8) - 1, 3, 2);
  }
  // ── the places you can go into: a spread of buildings, and every subway station. Their insides lie in a strip below the city.
  const places: Place[] = [], picked: { tx: number; ty: number; name: string }[] = [];
  const order = w.doors.map((_, i) => i).sort(() => Math.random() - 0.5);
  for (const min of [200, 120])
    for (const i of order) {
      if (picked.length >= 28) break;
      const dr = w.doors[i], tx = Math.floor(dr.x / TILE);
      let ty = -1;
      for (let k = 0; k < 3; k++) {
        const y = Math.floor((dr.y - 1) / TILE) - k;
        if (y > 0 && w.solid[y * NW + tx] && freeT(w, tx, y + 1)) { ty = y; break; } // the facade tile right above the pavement
      }
      if (ty < 0 || picked.some((q) => Math.hypot(q.tx - tx, q.ty - ty) * TILE < min)) continue;
      picked.push({ tx, ty, name: dr.name.toUpperCase() });
    }
  picked.forEach((q, n) => places.push({ kind: 0, name: q.name, sx: q.tx, sy: q.ty, x: 2 + (n % 14) * 12, y: NH + 1 + ((n / 14) | 0) * 9, w: 11, h: 8, hi: -1 }));
  let sn = 0;
  for (const s of w.stations) {
    const ty = Math.floor(s.y / TILE);
    let tx = -1;
    for (const k of [-1, -2, 0]) {
      const x = Math.floor(s.x / TILE) + k;
      if (w.solid[ty * NW + x] && (freeT(w, x + 1, ty) || freeT(w, x, ty + 1) || freeT(w, x - 1, ty))) { tx = x; break; } // a tile of the entrance itself
    }
    if (tx < 0) continue;
    places.push({ kind: 1, name: s.name.toUpperCase(), sx: tx, sy: ty, x: 2 + (sn % 9) * 19, y: NH + 19 + ((sn / 9) | 0) * 9, w: 17, h: 8, hi: -1 });
    sn++;
  }
  const clean = mkc(floor.width, floor.height);
  clean.getContext("2d")!.drawImage(floor, 0, 0);
  return { w, props, floor, clean, blank: mkc(1, 1), cars, spawns, nests, pad, truck, truckT, frame: 0, cache: [], vis: [], places };
}

/** the New York world itself (its pavements, the places people gather) and its sprites: the people of the city live in it */
export function nyCity() {
  return ny ? { w: ny.w, props: ny.props } : null;
}

/** make New York the active map: collision grid, spawn, nests, evac zone */
export function installNY() {
  const d = ny ?? (ny = build()), w = d.w;
  loadCustom(3, NW, NH + NY_STRIP, NH, () => {
    for (let ty = 0; ty < NH; ty++)
      for (let tx = 0; tx < NW; tx++) {
        const i = ty * NW + tx;
        if (w.solid[i]) put(tx, ty, 1, 2);                                   // buildings, trees, street furniture
        else if (isWater(w.tiles[i]) || w.tiles[i] === ICE) put(tx, ty, 3, 0); // water: no way through, but you can see and shoot across
      }
    for (const c of d.cars) {
      const hw = c.dir % 2 ? c.len / 2 - 3 : 5, hh = c.dir % 2 ? 5 : c.len / 2 - 3;
      for (let ty = Math.floor((c.y - hh) / TILE); ty <= Math.floor((c.y + hh) / TILE); ty++)
        for (let tx = Math.floor((c.x - hw) / TILE); tx <= Math.floor((c.x + hw) / TILE); tx++) if (freeT(w, tx, ty)) put(tx, ty, 2, 2);
    }
    // (bus collision is handled dynamically so the school bus can drive anywhere)
    // below the city: the insides of the buildings you can enter, and the subway stations
    for (let ty = NH; ty < NH + NY_STRIP; ty++) for (let tx = 0; tx < NW; tx++) put(tx, ty, 1, 9);
    const st: Place[] = [];
    d.places.forEach((pl, n) => {
      let ix: number, iy: number;
      if (pl.kind === 0) {
        // a flat, an office, a lobby: rooms and furniture, the door in the middle of the south wall
        ix = pl.x + (pl.w >> 1); iy = pl.y + pl.h - 1;
        pl.hi = house(pl.x, pl.y, pl.w, pl.h, 5 + (n % 3), [[ix, iy]], false);
      } else {
        // a station: one long tiled hall - stairs in the north wall, pillars, vending machines, a bench; the tracks run along the south side
        ix = pl.x + 3; iy = pl.y;
        pl.hi = hall(pl.x, pl.y, pl.w, pl.h, 6);
        put(ix, iy, 0, 0);
        HOUSES[pl.hi].doors.push({ tx: ix, ty: iy, ox: 0, oy: -1 });
        put(pl.x + 6, pl.y + 2, 1, 6); put(pl.x + 11, pl.y + 2, 1, 6);
        for (const vx of [pl.x + 8, pl.x + 13]) { put(vx, pl.y + 1, 2, 15); CRATES.push({ tx: vx, ty: pl.y + 1, house: pl.hi }); }
        put(pl.x + 9, pl.y + 1, 3, 21);
        st.push(pl);
      }
      put(pl.sx, pl.sy, 0, 0); // the doorway in the facade / the steps of the subway entrance
      link(pl.sx, pl.sy, ix, iy);
      const H = HOUSES[pl.hi];
      H.dx = ix - pl.sx; H.dy = iy - pl.sy; // on the radar, everything inside shows up at the door
    });
    // the tunnels: from the east end of every platform you walk on to the next station, all the way round the city
    if (st.length > 1) st.forEach((a, i) => { const b = st[(i + 1) % st.length]; link(a.x + a.w - 2, a.y + 5, b.x + 1, b.y + 5); });
    return { spawns: d.spawns, nests: d.nests, pad: d.pad, truck: d.truck, barrels: [] };
  });
}

export function nyArt() {
  const d = ny ?? (ny = build());
  return { floor: d.floor, clean: d.clean, blank: d.blank, mini: d.w.mini };
}

/** landmarks where a supply crate can stand (moved onto the nearest walkable tile) */
export function nyGoals(): { x: number; y: number; name: string }[] {
  const w = ny!.w;
  return w.landmarks.filter((l) => !/Liberty|Ellis|Governor|Battery/i.test(l.name)).map((l) => {
    const [tx, ty] = nearFree(w, l.x, l.y);
    return { ...ctr(tx, ty), name: l.name.toUpperCase() };
  });
}
export const nyRoad = (tx: number, ty: number) => isRoad(ny!.w.tiles[ty * NW + tx]);

/** everything of the city that is on screen goes into the y-sorted pass, so you walk behind towers and in front of lamp posts */
export function nySortables(list: { y: number; nyo?: NyItem }[], cl: number, ct: number, W: number, H: number) {
  const d = ny!, w = d.w;
  d.frame++;
  d.vis.length = 0;
  const bx0 = Math.max(0, Math.floor(cl / BUCKET)), bx1 = Math.min(w.bw - 1, Math.floor((cl + W) / BUCKET));
  const by0 = Math.max(0, Math.floor(ct / BUCKET)), by1 = Math.min(w.bh - 1, Math.floor((ct + H) / BUCKET));
  for (let by = by0; by <= by1; by++)
    for (let bx = bx0; bx <= bx1; bx++)
      for (const o of w.buckets[by * w.bw + bx]) {
        if (o.stamp === d.frame) continue;
        o.stamp = d.frame;
        if (o.x > cl + W || o.x + o.w < cl || o.y > ct + H || o.y + o.h < ct) continue;
        if (!o.spr) {
          o.spr = o.make!();
          if (o.fh !== undefined) fireEscape(o.spr.c, o.fh); // every front gets its fire escape: landings at floors 1-4, ladders up to the roof
          d.cache.push(o);
        }
        // (in a row of buildings the far ones go first: the near one leans over its neighbour)
        list.push({ y: o.sy - (o.fh !== undefined ? Math.abs(o.x + o.w / 2 - cl - W / 2) * 1e-4 : 0), nyo: { o } });
        d.vis.push(o);
      }
  for (const c of d.cars) if (c.x > cl - 40 && c.x < cl + W + 40 && c.y > ct - 40 && c.y < ct + H + 40) list.push({ y: c.sy, nyo: { c } });
  if (d.frame % 180 === 0 && d.cache.length > 170) {
    // building sprites that have been out of sight for a while are thrown away again
    const keep: Obj[] = [];
    for (const o of d.cache) {
      if ((o.stamp ?? 0) >= d.frame - 2) keep.push(o);
      else o.spr = undefined;
    }
    d.cache = keep;
  }
}

/** draw one of them; (fx, fy) = whoever the camera follows: buildings in front of them turn see-through */
const DIR_ANG = [-Math.PI / 2, 0, Math.PI / 2, Math.PI];
/** whether the cars in the street are abandoned wrecks yet (New York, the day it happened, starts as an ordinary traffic jam) */
let wrecked = true;
export function nyWrecked(on: boolean) { wrecked = on; }

export function nyDraw(ctx: CanvasRenderingContext2D, it: NyItem, cl: number, ct: number, t: number, fx: number, fy: number, fz = 0, night = false) {
  const vx = ctx.canvas.width / 2, vy = ctx.canvas.height / 2;
  if (it.c) {
    const c = it.c;
    drawCar3D(ctx, {
      x: c.x - cl, y: c.y - ct, ang: DIR_ANG[c.dir] ?? 0,
      kind: c.kind, body: c.body, len: c.len, sign: c.sign,
      vx, vy, night, t, wreck: wrecked,
    });
    return;
  }
  const o = it.o!, s = o.spr!, sx = o.x - cl, sy = o.y - ct;
  if (o.car) {
    drawCar3D(ctx, {
      x: sx + o.w / 2, y: sy + o.h / 2, ang: DIR_ANG[o.car.dir] ?? 0,
      kind: o.car.kind, body: o.car.body, len: o.car.len, sign: o.car.sign,
      vx, vy, night, t, wreck: wrecked,
    });
    return;
  }
  // (the towers are tall now: anything standing in a wide band around whoever the camera follows shows through)
  const behind = !!o.fade && fy < o.sy && fx + 36 > o.x && fx - 36 < o.x + o.w && fy - fz > o.y && fy - fz - 22 < o.y + o.h;
  if (behind) ctx.globalAlpha = 0.4;
  if (o.fh !== undefined) {
    // a solid 3D prism standing on its lot, projecting cleanly in both X and Y away from the centre of view
    const vx = ctx.canvas.width / 2, vy = ctx.canvas.height / 2;
    draw3D(ctx, s, sx, sy, o.fh, o.dp ?? TILE, vx, vy, night);
    if (behind) ctx.globalAlpha = 1;
    if (s.boards) {
      const sh = s.c.height, by = sy + sh;
      for (const b of s.boards) drawBoard(ctx, b, sx + boardShift(sx, b, sh, o.fh, vx), sy + boardShiftY(by, b.y, b.h, sh, o.fh, vy), t);
    }
    return;
  }
  ctx.drawImage(s.c, sx, sy);
  if (behind) ctx.globalAlpha = 1;
  if (s.boards) for (const b of s.boards) drawBoard(ctx, b, sx, sy, t);
}

/** the street lamps that are on screen (world position and radius) */
export function nyLamps(cb: (x: number, y: number, r: number) => void) {
  if (!ny) return;
  for (const o of ny.vis) {
    const L = o.spr?.lamps;
    if (L) for (let i = 0; i < L.length; i += 3) cb(o.x + L[i], o.y + L[i + 1], L[i + 2]);
  }
}

/** painted onto the finished ground: mats in front of every way in, the way out of every room, and the subway tracks and tunnels */
export function nyDecor(g: CanvasRenderingContext2D) {
  const d = ny!, w = d.w;
  const R = (c: string, x: number, y: number, ww: number, h: number) => { g.fillStyle = c; g.fillRect(x, y, ww, h); };
  for (const p of d.places) {
    let mx = p.sx, my = p.sy + 1;
    if (!freeT(w, mx, my)) {
      if (freeT(w, p.sx + 1, p.sy)) { mx = p.sx + 1; my = p.sy; }
      else if (freeT(w, p.sx - 1, p.sy)) { mx = p.sx - 1; my = p.sy; }
    }
    const X = mx * TILE, Y = my * TILE, col = p.kind ? "#2b5fb0" : "#2f8a4a", hi = p.kind ? "#9cc6ff" : "#7dff9a";
    R("#0b0b10", X + 1, Y + 1, 14, 11); R(col, X + 2, Y + 2, 12, 9);
    R(hi, X + 7, Y + 4, 2, 6); R(hi, X + 6, Y + 5, 4, 1); R(hi, X + 5, Y + 6, 6, 1); // an arrow pointing in
    if (p.kind === 0) {
      const ex = (p.x + (p.w >> 1)) * TILE, ey = (p.y + p.h - 1) * TILE;
      R("#07050c", ex, ey + TILE, TILE, TILE);
      R("#140e0a", ex, ey, TILE, TILE); R("#4a3626", ex + 1, ey, 14, 13); R("#2a1c12", ex + 1, ey + 13, 14, 3);
      R("#7dff9a", ex + 7, ey + 2, 2, 6); R("#7dff9a", ex + 5, ey + 7, 6, 1); R("#7dff9a", ex + 6, ey + 8, 4, 1); R("#7dff9a", ex + 7, ey + 9, 2, 1); // the way out
    } else {
      const x0 = (p.x + 1) * TILE, x1 = (p.x + p.w - 1) * TILE, yT = (p.y + 5) * TILE;
      R("#07050c", (p.x + 3) * TILE, (p.y - 1) * TILE, TILE, TILE);
      // the track bed: ballast, sleepers, two rails - and a yellow line along the platform edge
      R("#16161c", x0, yT, x1 - x0, 2 * TILE);
      for (let x = x0 + 3; x < x1; x += 8) R("#3a2c20", x, yT + 5, 3, 22);
      R("#8d949e", x0, yT + 8, x1 - x0, 2); R("#8d949e", x0, yT + 22, x1 - x0, 2);
      R("#d9dee8", x0, yT + 8, x1 - x0, 1); R("#d9dee8", x0, yT + 22, x1 - x0, 1);
      for (let x = x0; x < x1; x += 8) R("#f5c542", x, yT - 3, 5, 2);
      // the tunnel mouths at both ends
      for (const [tx, dir] of [[p.x + 1, -1], [p.x + p.w - 2, 1]]) {
        R("#050308", tx * TILE, yT, TILE, 2 * TILE);
        for (let i = 0; i < 3; i++) R("#f5c542", tx * TILE + 8 + dir * (i - 1) * 2, yT + 13 + i, 1, 6 - i * 2);
      }
      // the name of the station on a board on the platform
      const bx = x0 + 68, by = (p.y + 3) * TILE + 3, name = p.name.slice(0, 26);
      R("#0b0b10", bx - 1, by - 1, name.length * 4 + 8, 11); R("#1c2c55", bx, by, name.length * 4 + 6, 9); R("#f5f5f5", bx, by, name.length * 4 + 6, 1);
      g.fillStyle = "#ffffff";
      glyphs(g, name, bx + 3, by + 3, 1);
    }
  }
}

/** every way in that is on the map: kind 0 a building, 1 a subway station (world position of the door) */
export function nyEntrances(cb: (x: number, y: number, kind: number) => void) {
  if (ny) for (const p of ny.places) cb(p.sx * TILE + 8, p.sy * TILE + 8, p.kind);
}
/** the name of the building or station an interior belongs to */
export const nyPlace = (hi: number) => ny?.places.find((p) => p.hi === hi)?.name;

/** ceiling lights inside: strip lights along every platform (a few of them dying), one bulb in every building */
export function nyLights(cb: (x: number, y: number, r: number, a: number, house: number, flicker: boolean) => void) {
  if (!ny) return;
  for (const p of ny.places) {
    if (p.kind) for (let i = 0; i < 3; i++) cb((p.x + 3 + i * 5.5) * TILE, (p.y + 3) * TILE, 64, 0.62, p.hi, (p.sx + i) % 3 === 0);
  }
}

/** the building whose front rises right above this spot of pavement - if it has a fire escape to climb */
export function nyClimb(x: number, y: number): Obj | null {
  if (!ny) return null;
  for (const o of ny.vis) if (o.make && canClimb(o.w, o.fh) && x > o.x + 5 && x < o.x + o.w - 5 && y > o.sy - 1 && y < o.sy + 15) return o;
  return null;
}

/** the closest front with a fire escape to a point: where to stand on the pavement below it - not in front of a door (used by the tests) */
export function nyNearestFront(x: number, y: number): { x: number; y: number } | null {
  if (!ny) return null;
  let best: { x: number; y: number } | null = null, bd = 1e9;
  for (const o of ny.w.objs) {
    if (!o.make || !canClimb(o.w, o.fh)) continue;
    for (const k of [0.25, 0.5, 0.75]) {
      const px = o.x + o.w * k, py = o.sy + 8, tx = Math.floor(px / TILE), ty = Math.floor(py / TILE), d = Math.hypot(px - x, py - y);
      if (d >= bd || kindAt(tx, ty) !== 0 || kindAt(tx, ty - 1) !== 1) continue;
      if ([0, -7, 7].some((q) => portalAt(Math.floor((px + q) / TILE), ty - 1) >= 0)) continue;
      bd = d; best = { x: px, y: py };
    }
  }
  return best;
}

/** by day every building throws its shadow to the west, over the pavement and the street (one shape: where two shadows meet they do not get darker) */
export function nyShadows(ctx: CanvasRenderingContext2D, cl: number, ct: number, day: number) {
  if (!ny) return;
  ctx.fillStyle = "rgba(8,10,34," + (0.24 * day).toFixed(3) + ")";
  ctx.beginPath();
  for (const o of ny.vis) {
    if (o.fh === undefined) continue;
    const a = Math.min(44, o.fh * 0.3), b = a * 0.42, x = o.x - cl, r = x + o.w, y = o.sy - (o.dp ?? TILE) - ct, bt = o.sy - ct;
    ctx.moveTo(r, y); ctx.lineTo(r, bt); ctx.lineTo(r - a, bt + b); ctx.lineTo(x - a, bt + b); ctx.lineTo(x - a, y + b); ctx.lineTo(x, y);
    ctx.closePath();
  }
  ctx.fill();
}
