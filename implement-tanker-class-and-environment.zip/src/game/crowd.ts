import { TILE } from "./defs";
import { CH, TRUCK, kindAt } from "./map";
import { nyCity } from "./nyc";
import { zombieSprites } from "./city";
import type { BugMode } from "./bugs";
import type { Game, Sortable } from "./engine";
import { COBBLE, GRASS, ICE, PATH, PLAZA, REDPAVE, SIDEWALK, WOOD, isRoad } from "../ny/tiles";
import {
  LK_COSTUME, LK_COURIER, LK_ELDER, LK_END, LK_HOMELESS, LK_PRO, N_BASE,
  SP_COOKIE, SP_COP, SP_ELMO, SP_JOG, SP_LIBERTY, SP_MUSIC, SP_RANDOM, SP_VENDOR, SP_WORKER, buildPeople,
} from "../ny/sprites";
import type { PeopleAtlas } from "../ny/sprites";
import type { World } from "../ny/world";
import { MH as NH, MW as NW, drawText, textW } from "../ny/util";

/**
 * New York on the day it happened. The people of the city - the same walkers, vendors, cops, mascots, buskers, crowds,
 * queues, joggers and dog walkers as before the outbreak - go about their morning until the first of the dead shows up.
 * Whoever is bitten turns two seconds later, and the dead go for the next person, until nobody is left.
 * The living, and the dead that are out of sight, are simulated cheaply here; the dead that come into view are the real
 * zombies of the co-op game (never the street-scale zombies of the peaceful walk).
 */
export interface Cit {
  x: number; y: number;
  /** the tile it is walking to, the goal (px), and its lane offset inside a tile */
  cx: number; cy: number; gx: number; gy: number; ox: number; oy: number;
  dir: number; sp: number; look: number;
  /** 0 walker, 1 vendor, 2 busker, 3 cop, 4 mascot, 5 stander, 6 jogger, 7 dog */
  kind: number;
  /** 0 walking, 1 waiting at the kerb, 2 standing; for how long (t < 0: for good); walk cycle; update phase */
  st: number; t: number; an: number; ph: number;
  own: Cit | null; dog: number; xok: boolean;
  /** running for their life (time left, direction, speed, out of breath), frozen in shock, in a zombie's grip, unaware */
  fl: number; fx: number; fy: number; fsp: number; tired: number; shock: number; held: number; calm: number;
  /** seconds since the bite (-1: never bitten), and which way they fall */
  bit: number; side: number;
  /** the dead: kind (0 shambler, 1 runner, 2 dog), look, sprinter; think timer, prey */
  zk: number; zv: number; zf: boolean; zt: number; tg: Cit | null;
  /** what they are saying (a speech bubble, like before the outbreak); yellow when it is a scream */
  say: string; sayT: number; sayY: boolean;
  gone: boolean;
}

const DX = [0, -1, 1, 0], DY = [1, 0, 0, -1];
const WALK = [1, 0, 2, 0];
const CELL = 64;
/** seconds from the bite to the zombie */
const TURN = 2;
/** real zombies made out of the crowd at most (the rest wait out of sight) */
const CAP = 110;
const PI2 = Math.PI * 2;
const R = Math.random;
const GOO = ["#a8202c", "#6e1420", "#d04a4a"];
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const dirOf = (x: number, y: number) => (Math.abs(x) > Math.abs(y) ? (x < 0 ? 1 : 2) : y < 0 ? 3 : 0);
const pick = <T>(a: T[]) => a[(R() * a.length) | 0];
const hex = (s: string) => [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)];

const CHAT = [
  "NICE DAY, HUH?", "LATE FOR WORK!", "TAXI!!", "NEED... COFFEE...", "BEST PIZZA IN TOWN!", "HOW YOU DOIN'?", "ONLY IN NEW YORK...",
  "BAGEL TIME", "GO KNICKS!", "EXCUSE ME!", "I'M ON THE PHONE!", "WHAT A VIEW!", "WAH KEREN BANGET!", "FOTO DULU YUK!",
  "GEDUNGNYA TINGGI BANGET", "MAHAL BANGET DI SINI", "KANGEN NASI GORENG...", "INI KAYAK DI FILM!", "SANTAI DULU, BRO",
];
const VENDOR = ["HOT DOGS! HOT DOGS!", "PRETZELS! 3 BUCKS!", "CHICKEN OVER RICE!", "COLD WATER! ONE DOLLAR!"];
const COP = ["MOVE ALONG, FOLKS", "STAY SAFE OUT THERE", "CROSS AT THE LIGHT!"];
const MUSIC = ["LA LA LAAA", "NEW YORK, NEW YORK!", "TIPS WELCOME!"];
const PANIC = ["AAAAA!!", "ZOMBIE!!", "TOLONG!!", "LARIII!", "APA ITU?!", "DIA MENGGIGIT!", "RUN!!", "OH MY GOD!", "JANGAN MENDEKAT!", "MINGGIR!!"];
const BITTEN = ["AAARGH!", "TANGANKU...!", "SAKIT...!", "TOLONG AKU..."];

/** the people atlas of the peaceful walk, a sickly copy of it for the turn, and the shambler each look turns into */
let atlas: { pa: PeopleAtlas; sick: HTMLCanvasElement; shirt: number[] } | null = null;
function people() {
  if (atlas) return atlas;
  const pa = buildPeople(777);
  const sick = document.createElement("canvas");
  sick.width = pa.c.width;
  sick.height = pa.c.height;
  const sg = sick.getContext("2d")!;
  sg.drawImage(pa.c, 0, 0);
  sg.globalCompositeOperation = "source-atop";
  sg.fillStyle = "rgba(96,140,84,0.62)";
  sg.fillRect(0, 0, sick.width, sick.height);
  // the zombie somebody becomes keeps their colours: the shambler whose shirt is closest to theirs
  const zs = zombieSprites().scav.map((v) => hex(v.sleeve)), pg = pa.c.getContext("2d")!, shirt: number[] = [];
  for (let L = 0; L < pa.n; L++) {
    const sx = (L % pa.per) * 64, sy = Math.floor(L / pa.per) * 96, d = pg.getImageData(sx + 4, sy + 12, 8, 4).data;
    let r = 0, gg = 0, b = 0, k = 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 200 || d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11 < 34) continue; // (the outline)
      r += d[i]; gg += d[i + 1]; b += d[i + 2]; k++;
    }
    let best = L % zs.length, bd = 1e9;
    if (k) {
      r /= k; gg /= k; b /= k;
      zs.forEach((c, i) => { const q = (c[0] - r) ** 2 + (c[1] - gg) ** 2 + (c[2] - b) ** 2; if (q < bd) { bd = q; best = i; } });
    }
    shirt.push(best);
  }
  atlas = { pa, sick, shirt };
  return atlas;
}

export class Crowd {
  /** the people of the city (and the ones turning), and the dead that are out of sight */
  cits: Cit[] = [];
  zs: Cit[] = [];
  total = 0;
  healthy = 0;
  turning = 0;
  turned = 0;
  private g: Game;
  private B: BugMode;
  private w: World;
  private pa: PeopleAtlas;
  private sick: HTMLCanvasElement;
  private shirt: number[];
  private dogs: HTMLCanvasElement | null;
  private GW = Math.ceil((NW * TILE) / CELL);
  private GH = Math.ceil((NH * TILE) / CELL);
  private head: Int32Array;
  private next = new Int32Array(0);
  private ws = [0, 0, 0, 0];
  private vis: Cit[] = [];
  private frame = 0;
  private real = 0;
  private smell = 110;
  private chatT = 2.5;
  private loudT = 0;
  private screams = 0;
  private screamT = 0;
  private seedT = 2;
  private bitten = false;

  constructor(g: Game, B: BugMode) {
    this.g = g;
    this.B = B;
    const city = nyCity()!;
    this.w = city.w;
    this.dogs = city.props.dogs ?? null;
    const a = people();
    this.pa = a.pa;
    this.sick = a.sick;
    this.shirt = a.shirt;
    this.head = new Int32Array(this.GW * this.GH);
    this.populate();
    this.grid();
  }

  // ───────────── the morning crowd
  private randLook() {
    if (R() < 0.15) {
      // one in seven is somebody in particular: the old, the homeless, couriers, people at work - and the odd costume
      const q = R();
      const a = q < 0.3 ? LK_ELDER : q < 0.43 ? LK_HOMELESS : q < 0.58 ? LK_COURIER : q < 0.85 ? LK_PRO : LK_COSTUME;
      const b = q < 0.3 ? LK_HOMELESS : q < 0.43 ? LK_COURIER : q < 0.58 ? LK_PRO : q < 0.85 ? LK_COSTUME : LK_END;
      return a + Math.floor(R() * (b - a));
    }
    return SP_RANDOM + Math.floor(R() * (N_BASE - SP_RANDOM));
  }

  private mk(x: number, y: number, look: number, kind: number, st: number, dir: number): Cit {
    const cx = clamp(Math.floor(x / TILE), 0, NW - 1), cy = clamp(Math.floor(y / TILE), 0, NH - 1);
    return {
      x, y, cx, cy, gx: x, gy: y, ox: clamp(x - cx * TILE - 8, -5, 5), oy: clamp(y - cy * TILE - 8, -5, 5),
      dir, sp: 22 + R() * 16, look, kind, st, t: st === 2 ? -1 : 0, an: R() * 40, ph: (R() * 4) | 0,
      own: null, dog: 0, xok: false, fl: 0, fx: 0, fy: 0, fsp: 80, tired: 0, shock: 0, held: 0, calm: 0,
      bit: -1, side: 1, zk: 0, zv: 0, zf: false, zt: R(), tg: null, say: "", sayT: 0, sayY: false, gone: false,
    };
  }

  /** pavement, crossings, paths and plazas - and nothing of the co-op map is standing on it (wrecks, the bus) */
  private okT(tx: number, ty: number) {
    return tx >= 0 && ty >= 0 && tx < NW && ty < NH && this.w.npcOk[ty * NW + tx] === 1 && kindAt(tx, ty) === 0;
  }
  /** the street the school bus comes in along */
  private lane(x: number, y: number) {
    return Math.abs(y - TRUCK.y) < 18 && x > TRUCK.x - 380 && x < TRUCK.x + 70;
  }

  private populate() {
    const w = this.w;
    let made = 0, tries = 0;
    while (made < 2600 && tries < 900000) { // exactly as crowded as New York before the outbreak
      tries++;
      const tx = (R() * NW) | 0, ty = (R() * NH) | 0, i = ty * NW + tx;
      if (!w.npcOk[i] || kindAt(tx, ty) !== 0) continue;
      const t = w.tiles[i];
      if (isRoad(t) || t === ICE) continue;
      let wt = t === SIDEWALK ? 1 : t === PLAZA ? 1.6 : t === REDPAVE ? 4 : t === PATH ? 1.2 : t === WOOD ? 1 : t === COBBLE ? 0.7 : t === GRASS ? 0.05 : 0.3;
      if (ty >= 72 && ty < 126 && tx >= 18 && tx < 126) wt *= 1.5; // Midtown is packed
      if (R() * 3.2 > wt) continue;
      const x = tx * TILE + 8 + (R() * 10 - 5), y = ty * TILE + 8 + (R() * 10 - 5);
      if (this.lane(x, y)) continue;
      const n = this.mk(x, y, this.randLook(), 0, 0, (R() * 4) | 0);
      if (n.look >= LK_ELDER && n.look < LK_HOMELESS) n.sp *= 0.5; // the old take their time
      else if (n.look >= LK_HOMELESS && n.look < LK_COURIER) {
        n.sp *= 0.6;
        if (R() < 0.45) { n.kind = 5; n.st = 2; n.t = -1; } // many just stand at their corner
      } else if (n.look >= LK_COURIER && n.look < LK_PRO) n.sp = 46 + R() * 12; // couriers are always late
      if (t === PATH && tx >= 46 && tx < 98 && ty >= 30 && ty < 70 && R() < 0.3) {
        n.look = SP_JOG + ((R() * 4) | 0);
        n.sp = 56 + R() * 14;
        n.kind = 6;
      } else if (R() < 0.015) n.look = SP_WORKER;
      else if (R() < 0.02) n.look = SP_COP;
      this.cits.push(n);
      made++;
      if (n.kind === 0 && R() < 0.07) {
        const d = this.mk(n.x + 8, n.y, 0, 7, 0, 1);
        d.own = n;
        d.dog = (R() * 4) | 0;
        d.ox = R() < 0.5 ? -9 : 9;
        d.oy = R() * 4 - 1;
        this.cits.push(d);
      }
    }
    // the people at their places: vendors at their carts, cops on the beat, mascots, a busker and his audience, crowds and queues at the sights
    const ok = (x: number, y: number) => this.okT(Math.floor(x / TILE), Math.floor(y / TILE)) && !this.lane(x, y);
    for (const s of w.spots) {
      if (s.kind === "vendor") { if (ok(s.x, s.y)) this.cits.push(this.mk(s.x, s.y, SP_VENDOR, 1, 2, 0)); }
      else if (s.kind === "cop") { if (ok(s.x, s.y)) this.cits.push(this.mk(s.x, s.y, SP_COP, 3, 2, (R() * 4) | 0)); }
      else if (s.kind === "mascot") { if (ok(s.x, s.y)) this.cits.push(this.mk(s.x, s.y, [SP_ELMO, SP_LIBERTY, SP_COOKIE][s.v ?? 0], 4, 2, 0)); }
      else if (s.kind === "perf") {
        if (ok(s.x, s.y)) this.cits.push(this.mk(s.x, s.y, SP_MUSIC, 2, 2, 0));
        for (let i = 0; i < 6; i++) {
          const px = s.x + (i - 2.5) * 11, py = s.y + 22 - Math.abs(i - 2.5) * 3 + R() * 3;
          if (ok(px, py)) this.cits.push(this.mk(px, py, this.randLook(), 5, 2, 3));
        }
      } else if (s.kind === "crowd") {
        const rad = s.w ?? 40;
        for (let i = 0; i < (s.n ?? 6); i++)
          for (let k = 0; k < 20; k++) {
            const a = R() * PI2, d = Math.sqrt(R()) * rad, px = s.x + Math.cos(a) * d, py = s.y + Math.sin(a) * d * 0.7;
            if (!ok(px, py)) continue;
            this.cits.push(this.mk(px, py, this.randLook(), 5, 2, (R() * 4) | 0));
            break;
          }
      } else if (s.kind === "queue") {
        for (let i = 0; i < (s.n ?? 5); i++) {
          const px = s.x - i * 10, py = s.y + (i % 2);
          if (ok(px, py)) this.cits.push(this.mk(px, py, this.randLook(), 5, 2, i === 0 ? 3 : 2));
        }
      }
    }
    this.total = this.healthy = this.cits.length;
  }

  // ───────────── every frame
  update(dt: number) {
    const g = this.g, B = this.B;
    this.frame++;
    const ccx = g.cl + g.W / 2, ccy = g.ct + g.H / 2;
    if ((this.screamT -= dt) <= 0) { this.screamT = 1; this.screams = 0; }
    // gunfire: everybody close to it runs
    if ((this.loudT -= dt) <= 0) {
      this.loudT = 0.3;
      for (const f of g.fighters) if (f.alive && !f.civ && f.loud > 0 && f.y < CH * TILE) this.alarm(f.x, f.y, 70, 0.35);
    }
    // the school bus: people jump out of its way
    const bdx = g.truckDX(), bus = bdx !== 0 || (B.driving && Math.abs(B.busSp) > 20), bx = TRUCK.x + bdx, by = TRUCK.y;
    let healthy = 0, turning = 0;
    const L = this.cits;
    for (const c of L) {
      if (c.gone) continue;
      if (c.sayT > 0) c.sayT -= dt;
      if (c.bit >= 0) { turning++; this.turn(c, dt); continue; }
      healthy++;
      if (bus && c.fl <= 0 && Math.abs(c.x - bx) < 54 && Math.abs(c.y - by) < 24) { c.fl = 0.9; c.fx = 0; c.fy = c.y < by ? -1 : 1; c.fsp = 96; c.shock = 0; c.st = 0; }
      const far = Math.abs(c.x - ccx) > 620 || Math.abs(c.y - ccy) > 480;
      if (far && ((this.frame + c.ph) & 3)) continue; // far away: a quarter of the rate
      this.live(c, far ? dt * 4 : dt);
    }
    // nobody walks through the squad
    for (const f of g.fighters) {
      if (!f.alive || f.gone || f.y >= CH * TILE) continue;
      this.near(f.x, f.y, 8, (c) => {
        const dx = c.x - f.x, dy = c.y - f.y, d = Math.hypot(dx, dy) || 1;
        this.move(c, (dx / d) * 1.4, (dy / d) * 1.4);
      });
    }
    this.healthy = healthy;
    this.turning = turning;
    // the fewer the living, the farther off the dead can smell them
    this.smell = 110 + Math.min(220, (1 - healthy / Math.max(1, this.total)) * 260);
    const Z = this.zs;
    for (let i = 0; i < Z.length; i++) {
      const z = Z[i];
      if (z.gone || this.inView(z.x, z.y)) continue;
      const far = Math.abs(z.x - ccx) > 620 || Math.abs(z.y - ccy) > 480;
      if (far && ((this.frame + i) & 3)) continue;
      this.hunt(z, far ? dt * 4 : dt);
    }
    this.swap();
    this.chat(dt);
    let j = 0;
    for (const c of L) if (!c.gone) L[j++] = c;
    L.length = j;
    j = 0;
    for (const z of Z) if (!z.gone) Z[j++] = z;
    Z.length = j;
    this.grid();
  }

  /** a living New Yorker: walking the pavement - or running for their life */
  private live(c: Cit, dt: number) {
    if (c.calm > 0) c.calm -= dt;
    if (c.held > 0) { c.held -= dt; return; }
    if (c.shock > 0) { c.shock -= dt; return; }
    if (c.fl > 0) {
      c.fl -= dt;
      c.tired += dt;
      const s = (c.tired > 2.2 ? Math.min(c.fsp, 40) : c.fsp) * dt, bx = c.x, by = c.y; // (nobody sprints for long)
      this.move(c, c.fx * s, c.fy * s);
      if (Math.abs(c.x - bx) + Math.abs(c.y - by) < s * 0.3) { const a = R() * PI2; c.fx = Math.cos(a); c.fy = Math.sin(a); } // cornered: bolt another way
      c.an += s;
      c.st = 0;
      c.dir = dirOf(c.fx, c.fy);
      if (c.fl <= 0) this.regrid(c);
      return;
    }
    if (c.tired > 0) c.tired = Math.max(0, c.tired - dt * 0.4);
    if (c.kind === 7 && c.own) {
      const o = c.own;
      if (o.gone || o.bit >= 0) { c.own = null; c.sp = 34; this.regrid(c); return; } // its owner is gone: it runs off on its own
      const tx = o.x + c.ox - DX[o.dir] * 6, ty = o.y + c.oy - DY[o.dir] * 6, dx = tx - c.x, dy = ty - c.y, d = Math.hypot(dx, dy);
      if (d > 2) {
        const s = Math.min(d, (o.fl > 0 ? o.fsp + 10 : o.sp + 14) * dt);
        c.x += (dx / d) * s;
        c.y += (dy / d) * s;
        c.an += s;
        if (Math.abs(dx) > 0.5) c.dir = dx < 0 ? 1 : 2;
        c.st = 0;
      } else c.st = 2;
      return;
    }
    if (c.st === 0) {
      const dx = c.gx - c.x, dy = c.gy - c.y, step = c.sp * dt;
      if (Math.abs(dx) + Math.abs(dy) <= step) { c.x = c.gx; c.y = c.gy; this.choose(c); }
      else if (Math.abs(dx) > 0.01) c.x += clamp(dx, -step, step);
      else c.y += clamp(dy, -step, step);
      c.an += step;
    } else if (c.t >= 0) {
      c.t -= dt;
      if (c.t <= 0) this.choose(c);
    } else if (c.kind === 5 && R() < dt * 0.12) c.dir = (R() * 4) | 0;
  }

  /** the next tile: straight on along the pavement mostly, a look left and right before stepping onto a crossing */
  private choose(c: Cit) {
    const w = this.w, cur = w.tiles[c.cy * NW + c.cx], onRoad = isRoad(cur), ws = this.ws;
    let tot = 0, wait = false;
    for (let d = 0; d < 4; d++) {
      ws[d] = 0;
      const nx = c.cx + DX[d], ny = c.cy + DY[d];
      if (!this.okT(nx, ny)) continue;
      const t = w.tiles[ny * NW + nx];
      let wt = d === c.dir ? 14 : d === 3 - c.dir ? 0.12 : 1;
      if (isRoad(t)) {
        if (!onRoad) {
          if (d === c.dir && !c.xok && R() < 0.6) wait = true;
          wt *= 1.5;
        } else wt = d === c.dir ? 60 : d === 3 - c.dir ? 0.01 : 0.4;
      } else if (onRoad) wt = d === c.dir ? 60 : 2;
      else if (c.kind === 6) { if (t !== PATH) wt *= 0.02; }
      else if (t === GRASS && cur !== GRASS) wt *= 0.12;
      else if (cur === GRASS && t !== GRASS) wt *= 3;
      ws[d] = wt;
      tot += wt;
    }
    if (wait) { c.st = 1; c.t = 0.4 + R() * 0.9; c.xok = true; return; }
    if (tot <= 0) { c.st = 2; c.t = 1 + R() * 2; c.dir = 3 - c.dir; return; }
    if (c.kind === 0 && !onRoad && R() < 0.006) { c.st = 2; c.t = 1.5 + R() * 4; return; }
    let q = R() * tot, d = 0;
    for (; d < 4; d++) {
      if (ws[d] <= 0) continue;
      q -= ws[d];
      if (q <= 0) break;
    }
    if (d > 3) d = ws[0] > 0 ? 0 : ws[1] > 0 ? 1 : ws[2] > 0 ? 2 : 3;
    if (!isRoad(w.tiles[(c.cy + DY[d]) * NW + c.cx + DX[d]])) c.xok = false;
    c.dir = d;
    c.cx += DX[d];
    c.cy += DY[d];
    c.gx = c.cx * TILE + 8 + c.ox;
    c.gy = c.cy * TILE + 8 + c.oy;
    c.st = 0;
  }

  /** after running: back onto the nearest bit of pavement, and on with the walk */
  private regrid(c: Cit) {
    const tx = clamp(Math.floor(c.x / TILE), 0, NW - 1), ty = clamp(Math.floor(c.y / TILE), 0, NH - 1);
    c.st = 0;
    if (!this.okT(tx, ty)) {
      let bx = -1, by = -1, bd = 1e9;
      for (let j = -2; j <= 2; j++)
        for (let i = -2; i <= 2; i++) if (this.okT(tx + i, ty + j) && i * i + j * j < bd) { bd = i * i + j * j; bx = tx + i; by = ty + j; }
      if (bx >= 0) {
        c.cx = bx; c.cy = by; c.ox = c.oy = 0;
        c.gx = bx * TILE + 8; c.gy = by * TILE + 8;
        return;
      }
    }
    c.cx = tx; c.cy = ty;
    c.ox = clamp(c.x - tx * TILE - 8, -5, 5);
    c.oy = clamp(c.y - ty * TILE - 8, -5, 5);
    c.gx = c.x; c.gy = c.y;
  }

  private move(c: Cit, dx: number, dy: number) {
    if (!this.blocked(c.x + dx, c.y)) c.x += dx;
    if (!this.blocked(c.x, c.y + dy)) c.y += dy;
  }
  private blocked(x: number, y: number) {
    if (x < 8 || y < 10 || x > NW * TILE - 8 || y > CH * TILE - 6) return true;
    for (let k = 0; k < 4; k++) if (kindAt(Math.floor((x + (k & 1 ? 4 : -4)) / TILE), Math.floor((y + (k & 2 ? 0 : -4)) / TILE)) !== 0) return true;
    return this.B.inBus(x, y);
  }

  // ───────────── the bite, the turn, and the dead
  /** bitten: two seconds later they are one of them */
  bite(c: Cit) {
    if (c.gone || c.bit >= 0) return;
    c.bit = 0; c.held = 0; c.fl = 0; c.shock = 0; c.st = 2;
    c.side = R() < 0.5 ? -1 : 1;
    this.bitten = true;
    const g = this.g;
    if (this.seen(c.x, c.y, 10)) {
      g.puff(c.x, c.y - 9, 7, GOO, 55, { vz: 50, max: 0.5, size: 2, grav: 260, stamp: true });
      g.snd("scream", c.x, c.y, 0.9);
      if (c.kind !== 7) this.shout(c, pick(BITTEN), true);
    }
    this.alarm(c.x, c.y, 72, 0.9, this.seen(c.x, c.y, 40) ? 0.3 : 0.12); // everybody who saw it happen runs
  }

  private turn(c: Cit, dt: number) {
    const was = c.bit;
    c.bit += dt;
    if (was < 0.6 && c.bit >= 0.6 && this.seen(c.x, c.y, 0)) this.g.puff(c.x + c.side * 6, c.y - 2, 5, GOO, 30, { vz: 24, max: 0.45, size: 2, grav: 200, stamp: true });
    if (was < 0.9 && c.bit >= 0.9 && this.seen(c.x, c.y, 20)) this.g.snd("gurgle", c.x, c.y, 0.7); // choking on the floor
    if (c.bit < TURN) return;
    c.gone = true;
    this.turned++;
    const zk = c.kind === 7 ? 2 : R() < 0.12 ? 1 : 0, zf = zk === 0 && R() < 0.22; // the freshly turned are quick
    const zv = zk === 0 ? this.shirt[c.look] ?? 0 : zk === 2 ? c.dog : (R() * 4) | 0;
    c.zk = zk; c.zv = zv; c.zf = zf; c.tg = null;
    if (this.seen(c.x, c.y, 24) && this.real < CAP + 24) { this.B.crowdZombie(c, true); this.real++; this.g.snd("growl", c.x, c.y, 0.75); } // right in front of you: it gets up off the pavement
    else this.zs.push(this.virtual(c.x, c.y, zk, zv, zf));
  }

  private virtual(x: number, y: number, zk: number, zv: number, zf: boolean): Cit {
    const z = this.mk(x, y, 0, 0, 0, 0);
    z.zk = zk; z.zv = zv; z.zf = zf; z.bit = 99; z.t = 0;
    z.sp = zk === 2 ? 92 : zk === 1 ? 70 : zf ? 80 : 28 + R() * 14;
    z.zt = R() * 0.3;
    return z;
  }

  /** one of the dead out of sight: it goes for the nearest living person it can smell, or wanders */
  private hunt(z: Cit, d: number) {
    if ((z.zt -= d) <= 0) {
      z.zt = 0.45 + R() * 0.4;
      const p = z.tg;
      if (!p || p.gone || p.bit >= 0 || Math.abs(p.x - z.x) + Math.abs(p.y - z.y) > this.smell * 1.5) z.tg = this.nearest(z.x, z.y, this.smell);
      if (z.tg) { if (Math.abs(z.tg.x - z.x) + Math.abs(z.tg.y - z.y) < 80) this.alarm(z.x, z.y, 44, 0.65, 0.12); }
      else { const a = R() * PI2; z.fx = Math.cos(a); z.fy = Math.sin(a); }
    }
    const q = z.tg && !z.tg.gone && z.tg.bit < 0 ? z.tg : null;
    let tx = z.fx, ty = z.fy, sp = z.sp * 0.4;
    if (q) { tx = q.x - z.x; ty = q.y - z.y; sp = z.sp; }
    const l = Math.hypot(tx, ty) || 1, s = sp * d, bx = z.x, by = z.y;
    this.move(z, (tx / l) * s, (ty / l) * s);
    z.an += s;
    if (Math.abs(z.x - bx) + Math.abs(z.y - by) < s * 0.2) {
      this.move(z, (R() - 0.5) * 8, (R() - 0.5) * 8);
      // stuck behind a building: it wanders off for a moment instead
      if ((z.t += d) > 0.8) { z.t = 0; z.tg = null; z.zt = 1 + R() * 1.4; const a = R() * PI2; z.fx = Math.cos(a); z.fy = Math.sin(a); }
    } else if (z.t > 0) z.t = Math.max(0, z.t - d);
    if (q && l < 11 && R() < d * 0.9 && !this.seen(q.x, q.y, 16)) this.bite(q); // (most people tear themselves loose a few times first)
  }

  /** coming into view, the dead become real zombies of the co-op game; far out of view, real ones go back to being simulated */
  private swap() {
    const g = this.g, B = this.B, cl = g.cl, ct = g.ct, W = g.W, H = g.H, bs = B.bugs;
    let real = 0;
    for (const b of bs) if (b.cz) real++;
    for (const z of this.zs) {
      if (z.gone || real >= CAP || !this.inView(z.x, z.y)) continue;
      B.crowdZombie(z, false);
      z.gone = true;
      real++;
    }
    for (let i = bs.length - 1; i >= 0; i--) {
      const b = bs[i];
      if (!b.cz || !b.alive || (b.x > cl - 220 && b.x < cl + W + 220 && b.y > ct - 220 && b.y < ct + H + 220)) continue;
      if (b.y >= CH * TILE || (b.state !== "walk" && b.state !== "sleep") || b.hitT > 0 || (b.fat ?? 0) > 0 || b.hp < b.max * 0.9 || b.lost || b.limp || (b.chomp ?? 0) > 0) continue;
      bs.splice(i, 1);
      b.alive = false;
      const z = this.virtual(b.x, b.y, b.kind === "dog" ? 2 : b.kind === "warrior" ? 1 : 0, b.v, !!b.fast);
      z.tg = b.prey && !b.prey.gone ? b.prey : null;
      this.zs.push(z);
      real--;
    }
    this.real = real;
  }

  private inView(x: number, y: number) {
    const g = this.g;
    return x > g.cl - 40 && x < g.cl + g.W + 40 && y > g.ct - 30 && y < g.ct + g.H + 50;
  }
  private seen(x: number, y: number, m: number) {
    const g = this.g;
    return x > g.cl - m && x < g.cl + g.W + m && y > g.ct - m && y < g.ct + g.H + m + 24;
  }

  // ───────────── who is where
  private grid() {
    const L = this.cits, n = L.length, GW = this.GW;
    if (this.next.length < n) this.next = new Int32Array(n + 256);
    this.head.fill(-1);
    for (let i = 0; i < n; i++) {
      const c = L[i];
      if (c.gone || c.bit >= 0) continue;
      const gx = (c.x / CELL) | 0, gy = (c.y / CELL) | 0;
      if (gx < 0 || gy < 0 || gx >= GW || gy >= this.GH) continue;
      const k = gy * GW + gx;
      this.next[i] = this.head[k];
      this.head[k] = i;
    }
  }
  private near(x: number, y: number, r: number, fn: (c: Cit) => void) {
    const GW = this.GW, L = this.cits, r2 = r * r;
    const x0 = Math.max(0, ((x - r) / CELL) | 0), x1 = Math.min(GW - 1, ((x + r) / CELL) | 0);
    const y0 = Math.max(0, ((y - r) / CELL) | 0), y1 = Math.min(this.GH - 1, ((y + r) / CELL) | 0);
    for (let gy = y0; gy <= y1; gy++)
      for (let gx = x0; gx <= x1; gx++)
        for (let i = this.head[gy * GW + gx]; i >= 0; i = this.next[i]) {
          const c = L[i];
          if (!c || c.gone || c.bit >= 0) continue;
          const dx = c.x - x, dy = c.y - y;
          if (dx * dx + dy * dy <= r2) fn(c);
        }
  }
  /** the closest living person within r */
  nearest(x: number, y: number, r: number): Cit | null {
    let best: Cit | null = null, bd = r * r;
    this.near(x, y, r, (c) => {
      const d = (c.x - x) ** 2 + (c.y - y) ** 2;
      if (d < bd) { bd = d; best = c; }
    });
    return best;
  }

  /** they have seen one of them (or heard shots): a moment of disbelief, then everybody runs */
  alarm(x: number, y: number, r: number, p = 1, fz = 0.3) {
    this.near(x, y, r, (c) => {
      if (c.fl > 0 || c.shock > 0 || c.held > 0 || c.calm > 0 || (c.kind === 7 && c.own) || R() > p) return;
      const dx = c.x - x, dy = c.y - y, d = Math.hypot(dx, dy) || 1;
      c.shock = R() < fz ? 1 + R() * 0.6 : 0.25 + R() * 0.45; // some stand frozen for a deadly second
      c.fx = dx / d;
      c.fy = dy / d;
      c.dir = dirOf(-c.fx, -c.fy); // staring at it
      c.fl = 1.5 + R() * 1.6;
      c.fsp = (70 + R() * 24) * (c.look >= LK_ELDER && c.look < LK_HOMELESS ? 0.55 : c.kind === 7 ? 1.35 : 1);
      c.st = 0;
      if (c.kind !== 7 && R() < 0.35) this.shout(c, pick(PANIC), true);
    });
  }

  /** the people on screen: how many are going about their day, how many are running or screaming */
  mood() {
    let calm = 0, panic = 0;
    for (const c of this.vis) {
      if (c.gone) continue;
      if (c.bit >= 0 || c.fl > 0 || c.shock > 0 || c.held > 0) panic++;
      else calm++;
    }
    return { calm, panic };
  }

  /** the first victim: somebody you can see, a little way from the squad, with no idea what is behind them */
  victim(px: number, py: number): Cit | null {
    let best: Cit | null = null, bs = -1e9;
    for (const c of this.cits) {
      if (c.gone || c.bit >= 0 || c.kind === 7 || c.fl > 0) continue;
      const d = Math.hypot(c.x - px, c.y - py);
      if (d < 64 || d > 420) continue;
      const s = (this.seen(c.x, c.y, -28) ? 1000 : 0) - Math.abs(d - 120);
      if (s > bs) { bs = s; best = c; }
    }
    return best;
  }

  /** out of sight the sickness keeps travelling: now and then somebody far away turns out to have been bitten already */
  seed(dt: number, t: number) {
    if (t < 12 || this.healthy === 0 || (this.seedT -= dt) > 0) return;
    this.seedT = (t < 90 ? 3.2 : t < 170 ? 1.6 : t < 250 ? 0.7 : 0.2) * (0.6 + R() * 0.8);
    const L = this.cits;
    for (let k = 0; k < 30; k++) {
      const c = L[(R() * L.length) | 0];
      if (c && !c.gone && c.bit < 0 && !this.seen(c.x, c.y, 280)) { this.bite(c); return; }
    }
    if (this.healthy < 60) for (const c of L) if (!c.gone && c.bit < 0 && !this.seen(c.x, c.y, 40)) { this.bite(c); return; }
  }

  private shout(c: Cit, text: string, scream: boolean) {
    if (this.screams >= 4 || !this.seen(c.x, c.y, 0) || (c.sayT > 0.6 && !scream)) return;
    this.screams++;
    if (scream) this.g.snd(R() < 0.6 ? "shout" : "scream", c.x, c.y, 0.5);
    c.say = text;
    c.sayT = scream ? 1.8 : 3;
    c.sayY = scream;
  }
  /** the city talking to itself - until the first bite */
  private chat(dt: number) {
    if ((this.chatT -= dt) > 0 || !this.vis.length) return;
    this.chatT = 0.8 + R() * 1.1;
    if (this.bitten) return;
    const c = this.vis[(R() * this.vis.length) | 0];
    if (!c || c.gone || c.bit >= 0 || c.fl > 0 || c.kind === 7 || c.sayT > 0) return;
    this.shout(c, pick(c.kind === 1 ? VENDOR : c.kind === 3 ? COP : c.kind === 2 ? MUSIC : CHAT), false);
  }

  // ───────────── drawing
  addSortables(list: Sortable[]) {
    const g = this.g, cl = g.cl, ct = g.ct, W = g.W, H = g.H;
    this.vis.length = 0;
    for (const c of this.cits)
      if (!c.gone && c.x > cl - 20 && c.x < cl + W + 20 && c.y > ct - 6 && c.y < ct + H + 30) {
        list.push({ y: c.y, cit: c });
        this.vis.push(c);
      }
  }

  draw(c: Cit) {
    const g = this.g, ctx = g.ctx, pa = this.pa, t = g.t;
    const X = Math.round(c.x) - g.cl, Y = Math.round(c.y) - g.ct;
    if (c.kind === 7) {
      if (!this.dogs) return;
      const mv = c.bit < 0 && (c.st === 0 || c.fl > 0), fr = mv ? ((c.an / 5) | 0) & 1 : 0, sh = c.bit >= 0 || c.shock > 0 ? Math.round(Math.sin(t * 40 + c.x)) : 0;
      ctx.fillStyle = "rgba(0,0,0,0.2)";
      ctx.fillRect(X - 6, Y - 1, 11, 2);
      ctx.drawImage(this.dogs, (c.dir === 2 ? 28 : 0) + fr * 14, c.dog * 10, 14, 10, X - 7 + sh, Y - 9, 14, 10);
      return;
    }
    const sx = (c.look % pa.per) * 64, sy = Math.floor(c.look / pa.per) * 96;
    if (c.bit >= 0) { this.drawTurn(c, sx, sy, X, Y); return; }
    let dx = 0, dy = 0, fr: number;
    if (c.kind === 2 || c.kind === 4) dy -= Math.sin(t * 7 + c.x) > 0.3 ? 1 : 0; // the busker and the mascots bounce
    if (c.held > 0) { dx = Math.round(Math.sin(t * 42 + c.x) * 1.5); fr = 3; }
    else if (c.shock > 0) { dx = Math.round(Math.sin(t * 55 + c.x)); fr = 0; }
    else fr = c.st === 0 ? WALK[((c.an / (c.fl > 0 ? 3.2 : 4.5)) | 0) & 3] : Math.sin(t * 2.6 + c.an) > 0.55 ? 3 : 0;
    ctx.fillStyle = "rgba(0,0,0,0.22)";
    ctx.fillRect(X - 5, Y - 1, 10, 2);
    ctx.drawImage(pa.c, sx + fr * 16, sy + c.dir * 24, 16, 24, X - 8 + dx, Y - 22 + dy, 16, 24);
    if (c.kind === 2 && !this.bitten) {
      // a note floating up from the busker
      const k = (t * 0.7 + c.x * 0.01) % 1, nx = X + 6 + Math.round(Math.sin(t * 4) * 2), ny = Y - 24 - Math.round(k * 12);
      ctx.fillStyle = k < 0.5 ? "#ffffff" : "#ffe14a";
      ctx.fillRect(nx, ny, 2, 2);
      ctx.fillRect(nx + 1, ny - 4, 1, 4);
      ctx.fillRect(nx + 2, ny - 4, 2, 1);
    }
  }

  /** bitten: it reels, goes down, twitches, and the colour drains out of it */
  private drawTurn(c: Cit, sx: number, sy: number, X: number, Y: number) {
    const ctx = this.g.ctx, t = this.g.t, k = c.bit, src = this.pa.c;
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(X - 6, Y - 1, 12, 2);
    if (k < 0.6) {
      const sh = Math.round(Math.sin(t * 40 + c.x) * 1.6);
      ctx.drawImage(src, sx + 48, sy + c.dir * 24, 16, 24, X - 8 + sh, Y - 22 + (k > 0.35 ? 1 : 0), 16, 24);
      ctx.fillStyle = "#a8202c";
      ctx.fillRect(X - 2 + sh, Y - 15, 3, 2);
      return;
    }
    const fall = Math.min(1, (k - 0.6) / 0.22), tw = k > 1.1 && Math.sin(t * 47 + c.x) > 0.55 ? 1 : 0, sick = clamp(k - 1, 0, 1);
    ctx.save();
    ctx.translate(X, Y);
    ctx.rotate(c.side * fall * 1.5708);
    ctx.drawImage(src, sx, sy + c.dir * 24, 16, 24, -8, -22 + tw, 16, 24);
    if (sick > 0) {
      ctx.globalAlpha = sick;
      ctx.drawImage(this.sick, sx, sy + c.dir * 24, 16, 24, -8, -22 + tw, 16, 24);
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }

  /** speech bubbles over the people on screen - the same bubbles as in New York before the outbreak */
  drawBubbles() {
    const g = this.g, ctx = g.ctx, W = g.W;
    for (const c of this.vis) {
      if (c.gone || c.sayT <= 0 || !c.say) continue;
      const x = c.x - g.cl, y = c.y - g.ct - (c.bit >= 0.6 ? 12 : 25), w = textW(c.say) + 6;
      const bx = clamp(Math.round(x - w / 2), 1, Math.max(1, W - w - 1)), by = Math.round(y) - 9, rx = clamp(Math.round(x), bx + 2, bx + w - 3);
      ctx.fillStyle = "#1b1b26";
      ctx.fillRect(bx - 1, by, w + 2, 9);
      ctx.fillRect(bx, by - 1, w, 11);
      ctx.fillRect(rx - 1, by + 10, 3, 1);
      ctx.fillRect(rx, by + 11, 1, 1);
      ctx.fillStyle = c.sayY ? "#ffe14a" : "#ffffff";
      ctx.fillRect(bx, by, w, 9);
      ctx.fillRect(rx, by + 9, 1, 2);
      drawText(ctx, c.say, bx + 3, by + 2, "#1b1b26");
    }
  }

  /** on the radar: the living as faint dots, the dead out of sight in orange */
  radar(ctx: CanvasRenderingContext2D, px: number, py: number) {
    ctx.fillStyle = "rgba(236,238,248,0.5)";
    for (const c of this.cits) if (!c.gone && c.bit < 0 && Math.abs(c.x - px) < 520 && Math.abs(c.y - py) < 340) ctx.fillRect(Math.floor(c.x / TILE), Math.floor(c.y / TILE), 1, 1);
    ctx.fillStyle = "#ff9a3c";
    for (const z of this.zs) if (!z.gone && Math.abs(z.x - px) < 520 && Math.abs(z.y - py) < 340) ctx.fillRect(Math.floor(z.x / TILE), Math.floor(z.y / TILE), 1, 1);
  }

  line() {
    return `WARGA SEHAT ${this.healthy} - TERINFEKSI ${this.total - this.healthy}`;
  }
}
