export type SfxName =
  | "pistol" | "shotgun" | "sniper" | "bazooka" | "slash" | "whoosh" | "thunk" | "hit" | "hurt" | "ko" | "boom"
  | "squish" | "roar" | "beep" | "pod" | "groan" | "bark" | "crack" | "thunder" | "alarm" | "ping" | "heart" | "screech" | "rumble" | "reload" | "dash" | "deflect" | "start" | "win" | "lose" | "click" | "wall" | "pick" | "tick" | "engine" | "bite" | "step" | "door" | "ak47" | "goldgun" | "magout" | "magin" | "rack" | "shellin" | "pump" | "shell"
  // people, the dead, the street
  | "scream" | "shout" | "gurgle" | "growl" | "headshot" | "horn" | "honk" | "chime" | "ding" | "bell" | "brakes" | "train" | "jingle" | "swoosh" | "siren"
  // the arena: blasters, lightsabers, jetpacks, a dripping cave
  | "blaster" | "saberon" | "saberoff" | "saberswing" | "saberclash" | "jetburst" | "sputter" | "drip"
  // the hologram shield of the arena: raised, lowered, struck, shattered
  | "holoon" | "holooff" | "holohit" | "holobreak"
  // armour: a round on the plate, the plate giving way, the plates locking back into place
  | "armorhit" | "armorbreak" | "armorup"
  // the duel: the thump under a shot, the tesla gun, portals, the argent axe, breaking rock, rounds that glance off or pass close, a kill
  | "kick" | "zap" | "shock" | "portalshot" | "portalopen" | "portalgo" | "axeswing" | "axehit" | "slam" | "rockcrack" | "crumble" | "shatter" | "ricochet" | "whiz" | "killding"
  // critical hits, a body thrown against the rock, the living cave
  | "crit" | "bodyslam" | "geyser" | "bats"
  // Adeptus Astartes tanker: mass-reactive bolter, roaring chainsword, jump-pack turbines & meteor ground-slam
  | "bolter" | "boltboom" | "chainrev" | "chainrip" | "slamland" | "heavystep" | "jumpboost";

/** where a sound comes from: pan -1 (left) .. 1 (right); far 0 (right here) .. 1 (across the street: duller, more echo); pitch multiplier */
export interface PlayOpt { pan?: number; far?: number; pitch?: number }
/** the city around you, every layer 0..1 */
export interface CityMix { traffic?: number; crowd?: number; panic?: number; birds?: number; night?: number; water?: number; sirens?: number; drone?: number; wind?: number; rain?: number }
/** engines and machines that run as long as you keep them going */
export type LoopId = "scooter" | "bus" | "heli" | "train" | "jet" | "flame" | "saber" | "chainsaw";
/** musical hits for the moments of the story */
export type Stinger = "dread" | "hit" | "boss" | "fall" | "found" | "win" | "lose";

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
/** vowels: three formants each */
const VOW = { a: [800, 1200, 2500], e: [500, 1800, 2500], o: [500, 850, 2400], u: [350, 700, 2400], i: [300, 2200, 3000] };
const VOWS = [VOW.a, VOW.e, VOW.o, VOW.u, VOW.i];
/** the least time between two of the same sound (ms): crowds and gunfire must not pile up into a wall of noise */
const GAP: Partial<Record<SfxName, number>> = { groan: 90, scream: 120, shout: 80, growl: 70, step: 55, heavystep: 70, honk: 220, siren: 3500, train: 2500, gurgle: 200, blaster: 40, bolter: 50, boltboom: 42, chainrev: 55, chainrip: 45, saberswing: 60, saberclash: 45, drip: 140, sputter: 110, jetburst: 70, jumpboost: 65, slamland: 95, holohit: 45, armorhit: 40, kick: 28, rockcrack: 60, crumble: 55, ricochet: 120, whiz: 90, shock: 60, crit: 90, bodyslam: 80 };

/**
 * The game's sound: everything is synthesized with WebAudio - nothing is loaded.
 * Every effect is placed in the stereo field and in depth (far away = duller and wetter), and rings off the buildings
 * through a street-canyon reverb. The city has a living bed of traffic, voices, birds and sirens; engines run as loops;
 * the music follows the danger, and the story has its own stingers.
 */
class SoundKit {
  private ctx: AudioContext | null = null;
  /** effects volume (muting the effects leaves the music alone) */
  private master: GainNode | null = null;
  /** the last stage before the speakers */
  private out: AudioNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private brownBuf: AudioBuffer | null = null;
  private ir: AudioBuffer | null = null;
  /** reverb send: shots get a tail off the buildings, voices get distance */
  private verb: GainNode | null = null;
  private verbLp: BiquadFilterNode | null = null;
  /** ambience bus (city bed, crowd, weather): it ducks under explosions */
  private ambBus: GainNode | null = null;
  /** where the sound being built right now goes (its own panner / distance filter); null = straight to the effects bus */
  private dest: AudioNode | null = null;
  private wetK = 1;
  private pk = 1;
  private last: Partial<Record<SfxName, number>> = {};
  private load: number[] = [];
  muted = false;

  unlock() {
    try {
      if (!this.ctx) {
        const AC: typeof AudioContext =
          window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        const c = (this.ctx = new AC());
        this.master = c.createGain();
        this.master.gain.value = this.muted ? 0 : 0.32;
        // a compressor glues the layers together and keeps loud moments punchy instead of clipping
        const comp = c.createDynamicsCompressor();
        comp.threshold.value = -16; comp.knee.value = 18; comp.ratio.value = 5; comp.attack.value = 0.002; comp.release.value = 0.18;
        this.master.connect(comp);
        comp.connect(c.destination);
        this.out = comp;
        // the street canyon: a handful of early slaps off the facades on both sides, then a diffuse tail
        const sr = c.sampleRate, len = Math.floor(sr * 1.7), ir = c.createBuffer(2, len, sr);
        for (let ch = 0; ch < 2; ch++) {
          const q = ir.getChannelData(ch);
          for (let i = 0; i < len; i++) q[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.1) * 0.6;
          for (const [ms, g] of [[9, 0.55], [21, 0.4], [34, 0.32], [49, 0.24], [68, 0.18], [93, 0.13], [127, 0.09]]) {
            const i = Math.floor(((ms + (ch ? 4.3 : 0)) / 1000) * sr);
            if (i < len) q[i] += g * (Math.random() < 0.5 ? -1 : 1);
          }
        }
        this.ir = ir;
        const conv = c.createConvolver();
        conv.buffer = ir;
        this.verb = c.createGain();
        this.verb.gain.value = 0.5;
        this.verbLp = c.createBiquadFilter();
        this.verbLp.type = "lowpass";
        this.verbLp.frequency.value = 5200;
        this.verb.connect(conv).connect(this.verbLp).connect(this.master);
        const wn = c.createBuffer(1, sr * 2, sr), d = wn.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
        this.noiseBuf = wn;
        // brown noise: the deep rumble of traffic, wind and trains
        const bn = c.createBuffer(1, sr * 4, sr), b = bn.getChannelData(0);
        let lastB = 0;
        for (let i = 0; i < b.length; i++) { lastB = (lastB + 0.02 * (Math.random() * 2 - 1)) / 1.02; b[i] = lastB * 3.5; }
        this.brownBuf = bn;
        this.ambBus = c.createGain();
        this.ambBus.gain.value = 1;
        this.ambBus.connect(this.master);
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.32;
  }

  /** indoors (1) the echo gets closer and brighter, out in the street (0) darker and longer */
  private spaceK = -1;
  space(indoor: number) {
    if (!this.ctx || !this.verb || !this.verbLp) return;
    const t = this.ctx.currentTime, k = clamp(indoor, 0, 1);
    if (Math.abs(k - this.spaceK) < 0.02) return;
    this.spaceK = k;
    this.verb.gain.setTargetAtTime(0.5 + 0.28 * k, t, 0.3);
    this.verbLp.frequency.setTargetAtTime(5200 + 2600 * k, t, 0.3);
  }

  /** music and the city bed dip for a moment under something huge */
  duck(depth = 0.45, dur = 0.9) {
    const c = this.ctx;
    if (!c) return;
    const t = c.currentTime;
    for (const [b, v] of [[this.mBus, this.musicOn ? 0.55 : 0], [this.ambBus, 1]] as [GainNode | null, number][]) {
      if (!b) continue;
      b.gain.cancelScheduledValues(t);
      b.gain.setTargetAtTime(v * (1 - depth), t, 0.03);
      b.gain.setTargetAtTime(v, t + dur * 0.35, dur * 0.35);
    }
  }

  // ───────── building blocks ─────────
  private get to(): AudioNode { return this.dest ?? this.master!; }
  private send(node: AudioNode, wet: number) {
    if (wet <= 0 || !this.verb || !this.ctx) return;
    const w = this.ctx.createGain();
    w.gain.value = Math.min(1.5, wet * this.wetK);
    node.connect(w).connect(this.verb);
  }
  /** an oscillator with a pitch sweep; held = it sustains instead of dying away at once */
  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0, wet = 0, held = false) {
    const c = this.ctx!, t = c.currentTime + delay, k = this.pk;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0 * k, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1 * k), t + dur);
    if (held) {
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + Math.min(0.04, dur * 0.2));
      g.gain.setValueAtTime(vol, t + dur * 0.8);
      g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    } else {
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    }
    o.connect(g).connect(this.to);
    this.send(g, wet);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
  /** filtered noise with a filter sweep; atk > 0 = it swells in instead of starting at full */
  private noise(ftype: BiquadFilterType, f0: number, f1: number, dur: number, vol: number, delay = 0, wet = 0, atk = 0, brown = false) {
    const c = this.ctx!, t = c.currentTime + delay, k = this.pk;
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = brown ? this.brownBuf : this.noiseBuf;
    s.loop = true;
    f.type = ftype;
    f.frequency.setValueAtTime(f0 * k, t);
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1 * k), t + dur);
    if (atk > 0) {
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + atk);
    } else g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f).connect(g).connect(this.to);
    this.send(g, wet);
    s.start(t, Math.random() * 1.5);
    s.stop(t + dur + 0.02);
  }
  /** a throat: detuned saws through two formants, roughened by a fast flutter - groans, roars, barks, engines */
  private voice(f0: number, f1: number, dur: number, vol: number, formant: number, rough = 30, delay = 0, wet = 0.3) {
    const c = this.ctx!, t = c.currentTime + delay, k = this.pk, fk = Math.sqrt(k);
    const g = c.createGain(), bp = c.createBiquadFilter(), bp2 = c.createBiquadFilter(), lp = c.createBiquadFilter(), am = c.createGain(), mix = c.createGain(), m2 = c.createGain();
    bp.type = "bandpass"; bp.Q.value = 2.2;
    bp.frequency.setValueAtTime(formant * fk, t);
    bp.frequency.linearRampToValueAtTime(formant * fk * 0.7, t + dur);
    bp2.type = "bandpass"; bp2.Q.value = 4;
    bp2.frequency.setValueAtTime(formant * fk * 2.1, t);
    bp2.frequency.linearRampToValueAtTime(formant * fk * 1.6, t + dur);
    lp.type = "lowpass"; lp.frequency.value = formant * fk * 2.4;
    for (const det of [1, 1.012, 0.5]) {
      const o = c.createOscillator();
      o.type = "sawtooth";
      o.frequency.setValueAtTime(f0 * k * det, t);
      o.frequency.linearRampToValueAtTime(Math.max(20, f1 * k * det), t + dur);
      o.connect(am);
      o.start(t);
      o.stop(t + dur + 0.05);
    }
    const l = c.createOscillator(), lg = c.createGain();
    l.type = "square"; l.frequency.value = rough * (0.85 + Math.random() * 0.3);
    lg.gain.value = 0.45; am.gain.value = 0.6;
    l.connect(lg).connect(am.gain);
    l.start(t);
    l.stop(t + dur + 0.05);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t + Math.min(0.08, dur * 0.3));
    g.gain.setValueAtTime(Math.max(0.001, vol), t + dur * 0.6);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    mix.gain.value = 0.5; m2.gain.value = 0.35;
    am.connect(bp).connect(g);
    am.connect(bp2).connect(m2).connect(g);
    am.connect(lp).connect(mix).connect(g);
    g.connect(this.to);
    this.send(g, wet);
  }
  /** a human voice: a buzzing glottis (saw + pulse) with vibrato through three vowel formants - screams, shouts, babble */
  private human(f0: number, f1: number, dur: number, vol: number, fm: number[], delay = 0, wet = 0.25, vib = 0.025) {
    const c = this.ctx!, t = c.currentTime + delay, k = this.pk, fk = Math.sqrt(k);
    const src = c.createGain(), out = c.createGain();
    for (const [type, mul, g0] of [["sawtooth", 1, 0.7], ["square", 1.004, 0.22]] as [OscillatorType, number, number][]) {
      const o = c.createOscillator(), og = c.createGain(), l = c.createOscillator(), lg = c.createGain();
      o.type = type;
      o.frequency.setValueAtTime(f0 * k * mul, t);
      o.frequency.linearRampToValueAtTime(Math.max(40, f1 * k * mul), t + dur);
      l.frequency.value = 5 + Math.random() * 2.5;
      lg.gain.value = f0 * k * vib;
      l.connect(lg).connect(o.frequency);
      og.gain.value = g0;
      o.connect(og).connect(src);
      o.start(t); o.stop(t + dur + 0.05);
      l.start(t); l.stop(t + dur + 0.05);
    }
    fm.forEach((f, i) => {
      const bp = c.createBiquadFilter(), bg = c.createGain();
      bp.type = "bandpass"; bp.frequency.value = f * fk; bp.Q.value = 5 + i * 2.5;
      bg.gain.value = [1.5, 0.95, 0.45][i] ?? 0.3;
      src.connect(bp).connect(bg).connect(out);
    });
    out.gain.setValueAtTime(0.0001, t);
    out.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t + Math.min(0.05, dur * 0.25));
    out.gain.setValueAtTime(Math.max(0.001, vol * 0.85), t + dur * 0.7);
    out.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    out.connect(this.to);
    this.send(out, wet);
  }
  /** an FM bell: chimes, lifts, shop doors, the jingle of a new place */
  private bell(f: number, dur: number, vol: number, delay = 0, ratio = 3.5, wet = 0.5) {
    const c = this.ctx!, t = c.currentTime + delay, k = this.pk;
    const car = c.createOscillator(), mod = c.createOscillator(), mg = c.createGain(), g = c.createGain();
    car.frequency.value = f * k;
    mod.frequency.value = f * k * ratio;
    mg.gain.setValueAtTime(f * k * 2.2, t);
    mg.gain.exponentialRampToValueAtTime(Math.max(1, f * k * 0.04), t + dur);
    mod.connect(mg).connect(car.frequency);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    car.connect(g).connect(this.to);
    this.send(g, wet);
    car.start(t); mod.start(t);
    car.stop(t + dur + 0.05); mod.stop(t + dur + 0.05);
  }

  // ───────── the effects ─────────
  /** layered, slightly randomised sounds; returns false for what it does not cover */
  private rich(name: SfxName, v: number): boolean {
    const r = 0.93 + Math.random() * 0.14;
    switch (name) {
      case "pistol":
        this.noise("highpass", 3200 * r, 1400, 0.045, 0.6 * v);          // crack
        this.noise("bandpass", 1100 * r, 320, 0.13, 0.55 * v, 0, 0.35);  // body, into the street
        this.tone("sine", 210 * r, 55, 0.1, 0.6 * v);                    // thump
        this.tone("square", 2600, 1500, 0.012, 0.12 * v, 0.05);          // slide
        this.noise("lowpass", 700, 220, 0.25, 0.12 * v, 0.06, 0.6);      // the report rolling off the facades
        return true;
      case "ak47":
        this.noise("highpass", 2600 * r, 1100, 0.05, 0.6 * v);
        this.noise("bandpass", 800 * r, 240, 0.16, 0.7 * v, 0, 0.4);
        this.tone("sine", 150 * r, 48, 0.12, 0.85 * v);
        this.tone("square", 1900, 900, 0.015, 0.14 * v, 0.03); // the bolt slamming back
        return true;
      case "goldgun":
        this.noise("highpass", 3600 * r, 1500, 0.05, 0.75 * v);
        this.noise("lowpass", 3000 * r, 180, 0.42, 0.95 * v, 0, 0.6);
        this.tone("sine", 190 * r, 34, 0.34, 1.0 * v);
        this.tone("triangle", 2400, 1700, 0.22, 0.1 * v, 0.02, 0.5); // it rings like a bell
        this.tone("triangle", 3200, 2600, 0.3, 0.06 * v, 0.03, 0.5);
        return true;
      case "magout":
        this.noise("bandpass", 1900, 1500, 0.03, 0.34 * v);
        this.tone("square", 1200, 800, 0.02, 0.12 * v, 0.01);
        this.noise("lowpass", 600, 300, 0.05, 0.2 * v, 0.03);
        return true;
      case "magin":
        this.tone("sine", 220, 140, 0.05, 0.42 * v);
        this.noise("bandpass", 1400, 1100, 0.035, 0.38 * v);
        this.tone("square", 900, 700, 0.02, 0.14 * v, 0.02);
        return true;
      case "rack":
        this.noise("bandpass", 2500, 2000, 0.03, 0.36 * v);
        this.noise("bandpass", 1700, 1400, 0.04, 0.36 * v, 0.07);
        this.tone("square", 2000, 1400, 0.02, 0.14 * v, 0.07);
        return true;
      case "shellin":
        this.noise("bandpass", 1300, 1000, 0.03, 0.32 * v);
        this.tone("square", 700 * r, 500, 0.025, 0.14 * v);
        this.tone("sine", 180, 120, 0.04, 0.26 * v);
        return true;
      case "pump":
        this.noise("bandpass", 1500, 1300, 0.04, 0.36 * v);
        this.noise("bandpass", 2300, 1900, 0.05, 0.4 * v, 0.1);
        this.tone("sine", 160, 90, 0.05, 0.3 * v, 0.1);
        return true;
      case "shell":
        // the brass bounces on the asphalt: tink... tink-tink
        this.tone("triangle", 4200 * r, 3400, 0.05, 0.1 * v);
        this.tone("triangle", 5600 * r, 5000, 0.03, 0.05 * v, 0.02);
        this.tone("triangle", 4000 * r, 3300, 0.04, 0.05 * v, 0.13);
        this.tone("triangle", 3900 * r, 3300, 0.03, 0.03 * v, 0.2);
        return true;
      case "shotgun":
        this.noise("highpass", 2800 * r, 1200, 0.06, 0.75 * v);
        this.noise("lowpass", 3800 * r, 130, 0.5, 1.15 * v, 0, 0.7);
        this.tone("sine", 105 * r, 26, 0.42, 1.2 * v);
        this.tone("sawtooth", 170, 36, 0.18, 0.4 * v);
        this.noise("lowpass", 900, 150, 0.4, 0.3 * v, 0.12, 0.7); // the boom rolls back off the walls
        this.noise("bandpass", 1500, 1300, 0.035, 0.24 * v, 0.26); // the pump: ch-
        this.noise("bandpass", 2300, 1900, 0.045, 0.28 * v, 0.36); // -chk
        return true;
      case "sniper":
        this.noise("highpass", 5200 * r, 2200, 0.04, 0.8 * v);
        this.noise("lowpass", 5200 * r, 140, 0.55, 1.0 * v, 0, 0.7);
        this.tone("sine", 170 * r, 26, 0.5, 1.0 * v);
        this.tone("square", 1800, 240, 0.05, 0.2 * v);
        this.noise("lowpass", 1400, 200, 0.3, 0.3 * v, 0.14, 0.6);       // the echo comes back off the buildings
        this.noise("lowpass", 900, 160, 0.34, 0.16 * v, 0.33, 0.6);
        return true;
      case "bazooka":
        this.noise("bandpass", 320, 2200, 0.4, 0.7 * v, 0, 0.3);
        this.tone("sawtooth", 95 * r, 48, 0.32, 0.6 * v);
        this.noise("highpass", 2800, 5200, 0.3, 0.25 * v, 0.03);
        return true;
      case "boom":
        this.noise("lowpass", 1500, 50, 0.95, 1.2 * v, 0, 0.8);
        this.tone("sine", 80 * r, 22, 0.85, 1.2 * v);
        this.tone("sine", 42 * r, 24, 1.3, 0.8 * v);                    // the sub: you feel it in your chest
        this.tone("sawtooth", 130, 30, 0.3, 0.5 * v);
        this.noise("highpass", 3000, 900, 0.12, 0.6 * v);
        for (let i = 0; i < 6; i++) this.noise("bandpass", 900 + Math.random() * 1800, 300, 0.07, 0.22 * v, 0.18 + i * 0.09 + Math.random() * 0.05, 0.2); // debris raining down
        this.noise("lowpass", 600, 90, 1.6, 0.35 * v, 0.25, 0.9, 0.3, true); // the rumble rolling down the avenue
        if (v > 0.4) this.duck(0.55, 1.2);
        return true;
      case "slash":
        this.noise("bandpass", 2400 * r, 7200, 0.11, 0.42 * v);
        this.noise("highpass", 6000, 9000, 0.07, 0.2 * v, 0.02);
        this.tone("triangle", 2700 * r, 1900, 0.09, 0.07 * v, 0.02);
        return true;
      case "whoosh":
        this.noise("bandpass", 420 * r, 1700, 0.2, 0.6 * v);
        this.noise("lowpass", 300, 900, 0.16, 0.3 * v, 0.02);
        return true;
      case "thunk":
        this.tone("sine", 160 * r, 42, 0.16, 1.0 * v);
        this.noise("lowpass", 1000, 180, 0.09, 0.7 * v, 0, 0.25);
        this.tone("square", 950 * r, 280, 0.03, 0.22 * v);
        this.noise("bandpass", 600, 200, 0.12, 0.3 * v, 0.02);
        return true;
      case "hit":
        this.noise("lowpass", 1500 * r, 260, 0.07, 0.55 * v);
        this.tone("sine", 190 * r, 80, 0.07, 0.4 * v);
        this.noise("bandpass", 700, 300, 0.05, 0.25 * v, 0.02);
        return true;
      case "hurt":
        // the squad takes a hit: a grunt, not a buzzer
        this.human(rnd(150, 210) * r, 110, 0.18, 0.32 * v, VOW.u, 0, 0.15, 0.03);
        this.noise("lowpass", 1200, 300, 0.08, 0.3 * v);
        return true;
      case "headshot":
        this.noise("highpass", 4500 * r, 2600, 0.03, 0.55 * v);
        this.tone("square", 760 * r, 110, 0.06, 0.25 * v);
        this.noise("bandpass", 900, 260, 0.14, 0.5 * v, 0.01, 0.2);
        this.tone("sine", 240, 70, 0.1, 0.4 * v, 0.01);
        return true;
      case "squish":
        this.noise("bandpass", 800 * r, 180, 0.18, 0.7 * v);
        this.tone("sawtooth", 130 * r, 45, 0.16, 0.3 * v);
        this.noise("highpass", 2400, 1200, 0.05, 0.25 * v, 0.05);
        this.noise("lowpass", 500, 150, 0.12, 0.35 * v, 0.08);
        return true;
      case "crack":
        this.tone("square", 1900 * r, 180, 0.05, 0.35 * v);
        this.noise("highpass", 3200, 1500, 0.04, 0.5 * v);
        this.noise("bandpass", 700, 200, 0.16, 0.5 * v, 0.03);
        this.tone("sine", 140, 50, 0.12, 0.5 * v);
        return true;
      case "bite":
        this.noise("bandpass", 950 * r, 240, 0.1, 0.7 * v);
        this.tone("square", 320 * r, 90, 0.06, 0.3 * v);
        this.noise("highpass", 2600, 1400, 0.04, 0.3 * v, 0.03);
        this.voice(150 * r, 90, 0.22, 0.4 * v, 700, 40, 0.02, 0.2);
        this.noise("bandpass", 500, 200, 0.2, 0.25 * v, 0.06); // wet tearing
        return true;
      case "groan": {
        const fm = [380, 520, 700][(Math.random() * 3) | 0] * (0.9 + Math.random() * 0.25);
        this.voice(rnd(80, 104) * r, rnd(52, 70) * r, 0.7 + Math.random() * 0.6, 0.5 * v, fm, rnd(18, 32));
        this.noise("bandpass", 700, 400, 0.5, 0.08 * v, 0.05);
        if (Math.random() < 0.3) this.voice(70 * r, 50, 0.4, 0.25 * v, fm * 0.8, 40, 0.55 + Math.random() * 0.3); // ...and another breath out
        return true;
      }
      case "growl":
        this.voice(105 * r, 72, 0.32, 0.6 * v, 620, 58, 0, 0.3);
        this.noise("bandpass", 900, 500, 0.25, 0.12 * v);
        return true;
      case "gurgle":
        // the bitten turning: choking, blood in the throat, the last of the voice going
        this.voice(120 * r, 70, 1.1, 0.42 * v, 420, 52, 0, 0.35);
        for (let i = 0; i < 6; i++) this.noise("bandpass", rnd(300, 900), rnd(200, 400), 0.05, 0.16 * v, 0.1 + i * rnd(0.09, 0.15));
        this.human(260 * r, 140, 0.5, 0.12 * v, VOW.o, 0.55, 0.3, 0.06);
        return true;
      case "scream": {
        const fem = Math.random() < 0.55, f = (fem ? rnd(560, 760) : rnd(300, 420)) * r, d = rnd(0.5, 0.9);
        this.human(f, f * rnd(0.7, 0.88), d, 0.3 * v, fem ? [950, 1500, 2900] : [780, 1150, 2500], 0, 0.4, 0.035);
        this.tone("sine", f * 2, f * 1.5, d * 0.6, 0.025 * v, 0.02);      // the edge of it
        this.noise("bandpass", 2800, 2000, d * 0.7, 0.05 * v, 0, 0.25);  // breath
        return true;
      }
      case "shout": {
        const fem = Math.random() < 0.5, f = (fem ? rnd(320, 420) : rnd(170, 240)) * r;
        this.human(f, f * 0.82, rnd(0.16, 0.26), 0.28 * v, Math.random() < 0.5 ? VOW.e : VOW.a, 0, 0.3, 0.02);
        if (Math.random() < 0.5) this.human(f * 1.05, f * 0.8, rnd(0.12, 0.2), 0.24 * v, VOW.o, 0.24, 0.3, 0.02); // "to-LONG!"
        return true;
      }
      case "roar":
        this.voice(84 * r, 40, 1.15, 0.95 * v, 430, 34, 0, 0.6);
        this.voice(126 * r, 60, 0.9, 0.4 * v, 900, 46, 0.04, 0.5);
        this.tone("sine", 52 * r, 34, 1.2, 0.55 * v, 0, 0.3);               // the chest of something enormous
        this.noise("lowpass", 900, 200, 0.9, 0.3 * v, 0, 0.5);
        if (v > 0.5) this.duck(0.35, 1);
        return true;
      case "bark":
        this.voice(330 * r, 170, 0.1, 0.7 * v, 1150, 60, 0, 0.25);
        this.voice(300 * r, 150, 0.12, 0.6 * v, 1000, 60, 0.15, 0.25);
        this.noise("bandpass", 1600, 700, 0.08, 0.2 * v);
        return true;
      case "screech":
        this.human(rnd(900, 1150) * r, 1700, 0.28, 0.2 * v, [1100, 2400, 3600], 0, 0.4, 0.06);
        this.noise("bandpass", 3200, 5200, 0.22, 0.22 * v);
        this.tone("sawtooth", 950 * r, 2200, 0.2, 0.08 * v);
        return true;
      case "wall":
        this.noise("highpass", 2600 * r, 900, 0.05, 0.3 * v);
        this.tone("triangle", 1700 * r, 600, 0.05, 0.12 * v);
        this.noise("bandpass", 1200, 500, 0.06, 0.1 * v, 0.01); // a puff of plaster
        return true;
      case "reload":
        this.noise("bandpass", 1900, 1700, 0.03, 0.3 * v);               // magazine out
        this.tone("square", 1300, 900, 0.02, 0.12 * v, 0.01);
        this.noise("bandpass", 1300, 1100, 0.035, 0.28 * v, 0.16);       // magazine in
        this.tone("square", 2100, 1500, 0.02, 0.14 * v, 0.3);            // bolt
        this.noise("bandpass", 2600, 2200, 0.03, 0.3 * v, 0.3);
        return true;
      case "step":
        // heel and toe on concrete, never twice the same
        this.noise("lowpass", rnd(420, 640) * r, 160, 0.045, 0.16 * v);
        this.noise("bandpass", rnd(1800, 2600), 1400, 0.02, 0.05 * v, 0.03);
        return true;
      case "door":
        this.tone("sine", 140, 60, 0.12, 0.7 * v);
        this.noise("lowpass", 900, 200, 0.08, 0.5 * v, 0, 0.3);
        this.noise("bandpass", 2400, 1600, 0.05, 0.12 * v, 0.02); // the latch
        return true;
      case "engine":
        this.voice(46, 100, 1.9, 0.8 * v, 300, 21, 0.15, 0.3);
        this.noise("lowpass", 280, 760, 1.8, 0.3 * v, 0.15);
        this.tone("square", 70, 150, 1.7, 0.12 * v, 0.2);
        return true;
      case "horn":
        // the school bus: a deep two-tone air horn
        for (const f of [233, 294]) {
          this.tone("sawtooth", f * r, f * r * 0.99, 0.62, 0.15 * v, 0, 0.3, true);
          this.tone("square", f * r * 1.004, f * r, 0.6, 0.06 * v, 0, 0, true);
        }
        return true;
      case "honk": {
        const f = rnd(380, 560), n = Math.random() < 0.4 ? 2 : 1;
        for (let i = 0; i < n; i++) {
          this.tone("square", f, f * 0.98, rnd(0.12, 0.22), 0.09 * v, i * 0.26, 0.3, true);
          this.tone("sawtooth", f * 1.26, f * 1.24, rnd(0.12, 0.2), 0.05 * v, i * 0.26, 0, true);
        }
        return true;
      }
      case "siren":
        // a police car somewhere, wailing past
        for (let i = 0; i < 2; i++) {
          this.tone("sine", 650, 1250, 0.9, 0.07 * v, i * 1.8, 0.9, true);
          this.tone("sine", 1250, 650, 0.9, 0.07 * v, i * 1.8 + 0.9, 0.9, true);
        }
        return true;
      case "brakes":
        this.tone("sawtooth", 2400 * r, 2050, 1.3, 0.05 * v, 0, 0.5, true);
        this.tone("sine", 3100 * r, 2900, 1.2, 0.06 * v, 0.05, 0.5, true);
        this.noise("highpass", 3000, 2000, 1.3, 0.08 * v, 0, 0.4);
        return true;
      case "train":
        // a train pulling into the station: the rumble swells, the wheels clack over the joints, then the brakes squeal
        this.noise("lowpass", 140, 420, 3.4, 0.6 * v, 0, 0.6, 1.4, true);
        for (let i = 0; i < 12; i++) this.tone("sine", 120, 60, 0.06, 0.22 * v * (0.35 + i / 14), 0.4 + i * 0.21, 0.3);
        this.tone("sawtooth", 2300 * r, 2000, 1.1, 0.04 * v, 2.3, 0.5, true);
        this.tone("sine", 3000 * r, 2850, 1, 0.05 * v, 2.35, 0.5, true);
        return true;
      case "blaster":
        // a struck steel cable: a bright crack falling into a ringing "pyeww"
        this.noise("highpass", 5200, 1800, 0.035, 0.34 * v); // (the crack of the bolt leaving,
        this.tone("sine", 190 * r, 46, 0.12, 0.5 * v); // and a thump under it)
        this.tone("sawtooth", 2400 * r, 170, 0.2, 0.2 * v, 0, 0.25);
        this.tone("sine", 1500 * r, 130, 0.24, 0.32 * v, 0, 0.3);
        this.tone("square", 4800 * r, 1100, 0.045, 0.07 * v);
        this.noise("bandpass", 4200, 1600, 0.04, 0.14 * v);
        this.bell(2100 * r, 0.22, 0.045 * v, 0.005, 1.37, 0.35);
        return true;
      case "saberon":
        // the blade springs out: a crackling hiss rising into the hum
        this.noise("bandpass", 700, 3200, 0.22, 0.28 * v, 0, 0.3, 0.02);
        this.tone("sawtooth", 46, 128, 0.38, 0.26 * v, 0, 0.3, true);
        this.tone("sawtooth", 47.5, 131, 0.38, 0.22 * v, 0, 0.3, true);
        this.tone("sine", 260, 700, 0.22, 0.1 * v, 0.03, 0.35);
        return true;
      case "saberoff":
        this.tone("sawtooth", 128, 44, 0.32, 0.22 * v, 0, 0.3, true);
        this.tone("sawtooth", 131, 45, 0.32, 0.18 * v, 0, 0.3, true);
        this.noise("bandpass", 2600, 600, 0.25, 0.12 * v, 0, 0.2);
        return true;
      case "saberswing":
        // the hum swells and bends as the blade cuts the air
        this.tone("sawtooth", 92 * r, 150, 0.12, 0.2 * v, 0, 0.3, true);
        this.tone("sawtooth", 150 * r, 84, 0.16, 0.18 * v, 0.11, 0.3, true);
        this.tone("sine", 184 * r, 300, 0.2, 0.12 * v, 0, 0.25);
        this.noise("bandpass", 420, 1900, 0.24, 0.2 * v, 0, 0.3, 0.06);
        return true;
      case "saberclash":
        // blade on blade, a bolt turned away, a blade through armour: a fierce crackle and a sizzle
        for (let i = 0; i < 6; i++) this.tone("square", rnd(1100, 3400), rnd(380, 900), 0.03, 0.11 * v, i * 0.014);
        this.noise("highpass", 3200, 1300, 0.16, 0.42 * v, 0, 0.35);
        this.noise("bandpass", 2600, 900, 0.36, 0.14 * v, 0.03, 0.4);
        this.tone("sawtooth", 150 * r, 90, 0.24, 0.22 * v, 0, 0.3);
        return true;
      case "jetburst":
        // the jetpack lights: a deep whoomp and a rush of gas
        this.tone("sine", 130 * r, 38, 0.3, 0.6 * v);
        this.noise("lowpass", 2200, 180, 0.4, 0.5 * v, 0, 0.35, 0, true);
        this.noise("bandpass", 500, 2600, 0.32, 0.22 * v, 0, 0.3, 0.03);
        return true;
      case "sputter":
        for (let i = 0; i < 3; i++) this.noise("bandpass", rnd(500, 1000), rnd(200, 400), 0.05, 0.24 * v, i * rnd(0.06, 0.1));
        this.tone("sine", 90, 50, 0.08, 0.2 * v, 0.02);
        return true;
      case "holoon":
        // a wall of hard light unfolds: an electric shimmer rising into a clear note
        this.tone("sine", 300 * r, 1180, 0.2, 0.22 * v, 0, 0.3);
        this.tone("triangle", 600 * r, 2360, 0.2, 0.09 * v, 0.02, 0.3);
        this.noise("bandpass", 1600, 5200, 0.18, 0.1 * v, 0, 0.3, 0.02);
        this.bell(1760 * r, 0.3, 0.07 * v, 0.15, 2, 0.4);
        return true;
      case "holooff":
        this.tone("sine", 1100 * r, 260, 0.16, 0.18 * v, 0, 0.3);
        this.noise("bandpass", 4200, 1100, 0.14, 0.08 * v, 0, 0.3);
        return true;
      case "holohit":
        // something strikes it: a glassy, electric ping
        this.bell(1480 * r, 0.24, 0.12 * v, 0, 2.4, 0.35);
        this.tone("square", 2600 * r, 800, 0.04, 0.08 * v);
        this.noise("highpass", 5200, 2400, 0.05, 0.16 * v);
        return true;
      case "holobreak":
        // it shatters: glass flying apart, and the hum of the projector dying away
        for (let i = 0; i < 7; i++) this.bell(rnd(1300, 4200), rnd(0.15, 0.4), 0.07 * v, i * 0.018, 2.7, 0.4);
        this.noise("highpass", 3600, 900, 0.3, 0.45 * v, 0, 0.4);
        this.tone("sawtooth", 880 * r, 70, 0.45, 0.24 * v, 0, 0.35);
        this.tone("sine", 220, 40, 0.5, 0.3 * v, 0.02);
        return true;
      case "armorhit":
        // a round strikes armour plate: a hard clank, and the ping of the ricochet
        this.tone("square", 1900 * r, 520, 0.045, 0.16 * v);
        this.noise("bandpass", 3400 * r, 1800, 0.05, 0.3 * v);
        this.bell(2500 * r, 0.16, 0.07 * v, 0.01, 1.6, 0.3);
        this.tone("sine", 240 * r, 90, 0.06, 0.25 * v);
        return true;
      case "armorbreak":
        // the armour gives way: plate cracking, splinters of steel ringing on the ground
        this.noise("lowpass", 2600, 300, 0.2, 0.7 * v, 0, 0.3);
        this.tone("sawtooth", 320 * r, 60, 0.26, 0.35 * v);
        for (let i = 0; i < 5; i++) this.bell(rnd(900, 2600), rnd(0.12, 0.3), 0.07 * v, 0.03 + i * 0.03, 1.9, 0.35);
        this.noise("highpass", 4200, 1500, 0.14, 0.3 * v, 0.02);
        return true;
      case "armorup":
        // the plates lock back into place: two rising clicks and a soft chime
        this.tone("square", 520 * r, 780, 0.05, 0.12 * v);
        this.tone("square", 780 * r, 1170, 0.05, 0.12 * v, 0.07);
        this.bell(1560, 0.3, 0.07 * v, 0.14, 2, 0.4);
        return true;
      case "kick":
        // the thump under a gunshot: felt more than heard
        this.tone("sine", 165 * r, 40, 0.1, 0.95 * v);
        this.noise("lowpass", 1100, 220, 0.045, 0.45 * v);
        return true;
      case "zap":
        // the tesla gun: a hard electric crack, then a buzz that tears away
        this.noise("highpass", 6200, 2600, 0.05, 0.5 * v);
        this.tone("sawtooth", 2000 * r, 230, 0.17, 0.26 * v, 0, 0.25);
        this.tone("square", 120 * r, 52, 0.22, 0.32 * v, 0, 0.2);
        for (let i = 0; i < 4; i++) this.tone("square", rnd(900, 3400), rnd(300, 900), 0.025, 0.12 * v, 0.03 + i * 0.03);
        return true;
      case "shock":
        // somebody is electrocuted: a crackling, stuttering buzz
        for (let i = 0; i < 10; i++) this.tone("square", rnd(700, 3800), rnd(200, 1200), 0.03, 0.1 * v, i * 0.034);
        this.tone("sawtooth", 100, 96, 0.36, 0.2 * v, 0, 0.2, true);
        this.noise("bandpass", 3800, 2400, 0.32, 0.16 * v, 0, 0.3);
        return true;
      case "portalshot":
        // the portal gun: a soft thump and a rising whistle
        this.tone("sine", 240 * r, 900, 0.16, 0.3 * v, 0, 0.3);
        this.tone("triangle", 480 * r, 1800, 0.16, 0.12 * v, 0.01, 0.3);
        this.noise("bandpass", 900, 3200, 0.14, 0.16 * v, 0, 0.3, 0.02);
        this.tone("sine", 140, 60, 0.1, 0.4 * v);
        return true;
      case "portalopen":
        // a portal opens: the air is drawn in, and a chord rings
        this.noise("bandpass", 300, 2400, 0.3, 0.26 * v, 0, 0.4, 0.05);
        this.tone("sine", 196 * r, 392, 0.3, 0.2 * v, 0, 0.4);
        this.bell(784 * r, 0.5, 0.09 * v, 0.12, 2, 0.5);
        this.bell(1175 * r, 0.5, 0.06 * v, 0.2, 2, 0.5);
        return true;
      case "portalgo":
        // through a portal: a swallowed whoosh, and a deep note that bends
        this.noise("bandpass", 2600, 300, 0.22, 0.3 * v, 0, 0.4);
        this.tone("sine", 620 * r, 140, 0.24, 0.3 * v, 0, 0.4);
        this.tone("triangle", 1240 * r, 300, 0.18, 0.1 * v, 0.02, 0.4);
        return true;
      case "axeswing":
        // the argent axe through the air: heavy, and it roars
        this.noise("bandpass", 260 * r, 1300, 0.26, 0.5 * v, 0, 0.3, 0.04);
        this.noise("lowpass", 700, 200, 0.3, 0.34 * v, 0.02, 0.3, 0.05, true);
        this.tone("sawtooth", 70 * r, 130, 0.24, 0.2 * v, 0, 0.25, true);
        return true;
      case "axehit":
        // it lands: a chop, steel, and the hiss of something burning
        this.tone("sine", 130 * r, 36, 0.2, 1.0 * v);
        this.noise("lowpass", 1600, 200, 0.1, 0.7 * v, 0, 0.3);
        this.tone("square", 1500 * r, 420, 0.04, 0.16 * v);
        this.noise("highpass", 4200, 2000, 0.3, 0.2 * v, 0.03, 0.3);
        return true;
      case "slam":
        // both hands, down on the ground: a boom, a crack, fire
        this.tone("sine", 95 * r, 24, 0.6, 1.1 * v);
        this.noise("lowpass", 1800, 90, 0.5, 0.9 * v, 0, 0.6);
        this.noise("highpass", 3200, 1100, 0.1, 0.5 * v);
        this.noise("bandpass", 900, 300, 0.5, 0.25 * v, 0.08, 0.5, 0, true);
        if (v > 0.5) this.duck(0.6, 0.8);
        return true;
      case "rockcrack":
        // rock cracks: a dry snap
        this.noise("highpass", 2600 * r, 1200, 0.03, 0.4 * v);
        this.noise("bandpass", 900 * r, 400, 0.06, 0.3 * v, 0.01);
        this.tone("square", 700 * r, 180, 0.03, 0.12 * v);
        return true;
      case "crumble":
        // rock gives way: a crunch, and the pieces coming down
        this.noise("lowpass", 1400 * r, 160, 0.22, 0.7 * v, 0, 0.35);
        this.tone("sine", 110 * r, 40, 0.16, 0.5 * v);
        for (let i = 0; i < 4; i++) this.noise("bandpass", rnd(500, 1800), rnd(250, 700), 0.05, 0.2 * v, 0.06 + i * 0.05 + Math.random() * 0.03, 0.2);
        return true;
      case "shatter":
        // a crystal breaks: glass
        for (let i = 0; i < 6; i++) this.bell(rnd(1800, 5200), rnd(0.12, 0.35), 0.07 * v, i * 0.02, 2.9, 0.45);
        this.noise("highpass", 4800, 2000, 0.16, 0.34 * v, 0, 0.35);
        return true;
      case "ricochet":
        // a round glances off the rock and whines away
        this.tone("sine", 2600 * r, 700, 0.3, 0.14 * v, 0, 0.45);
        this.tone("triangle", 3400 * r, 900, 0.24, 0.06 * v, 0.01, 0.45);
        this.noise("highpass", 5200, 3000, 0.03, 0.2 * v);
        return true;
      case "whiz":
        // a round goes past your head
        this.noise("bandpass", 3600 * r, 700, 0.11, 0.42 * v, 0, 0.1, 0.01);
        this.tone("sine", 2200 * r, 500, 0.1, 0.08 * v);
        return true;
      case "killding":
        // you got one: two bright notes
        this.bell(1568, 0.22, 0.14 * v, 0, 2, 0.3);
        this.bell(2093, 0.4, 0.14 * v, 0.07, 2, 0.4);
        return true;
      case "crit":
        // a critical hit: a hard crack, the bottom dropping out, a ring of steel
        this.noise("highpass", 3800, 1200, 0.07, 0.7 * v);
        this.tone("square", 1800 * r, 300, 0.07, 0.3 * v);
        this.tone("sine", 220 * r, 34, 0.42, 1.1 * v);
        this.bell(2637, 0.5, 0.12 * v, 0.02, 2.4, 0.4);
        this.bell(3520, 0.4, 0.07 * v, 0.06, 2.4, 0.4);
        if (v > 0.5) this.duck(0.5, 0.5);
        return true;
      case "bodyslam":
        // a body strikes the rock at speed
        this.tone("sine", 120 * r, 30, 0.3, 1.1 * v);
        this.noise("lowpass", 1300, 140, 0.2, 0.9 * v, 0, 0.4);
        this.noise("bandpass", 2400, 700, 0.06, 0.4 * v, 0.01);
        for (let i = 0; i < 3; i++) this.noise("bandpass", rnd(600, 1600), rnd(250, 600), 0.05, 0.18 * v, 0.08 + i * 0.05, 0.2);
        return true;
      case "geyser":
        // a geyser lets go: a roar of water and steam
        this.noise("bandpass", 500, 2600, 0.9, 0.5 * v, 0, 0.5, 0.12);
        this.noise("highpass", 3000, 5000, 1.0, 0.22 * v, 0.05, 0.5, 0.2);
        this.tone("sine", 70, 46, 0.8, 0.5 * v, 0, 0.3);
        return true;
      case "bats":
        // bats: squeaks and a flutter of wings
        for (let i = 0; i < 9; i++) this.tone("sine", rnd(5200, 7800), rnd(4200, 6200), 0.03, 0.05 * v, i * rnd(0.03, 0.06));
        for (let i = 0; i < 6; i++) this.noise("bandpass", rnd(900, 1500), rnd(500, 900), 0.03, 0.12 * v, i * 0.05);
        return true;
      case "drip":
        this.tone("sine", 1500 * r, 700, 0.06, 0.12 * v, 0, 0.6);
        return true;
      case "chime":
        [1318, 1661, 1976, 2637].forEach((f, i) => this.bell(f, 0.9, 0.15 * v, i * 0.07, 3.5, 0.5));
        return true;
      case "ding":
        this.bell(1318, 1.4, 0.22 * v, 0, 2.0, 0.6);
        this.bell(1046, 1.6, 0.2 * v, 0.32, 2.0, 0.6);
        return true;
      case "bell":
        for (let i = 0; i < 3; i++) this.bell(2350 + rnd(-60, 60), 0.5, 0.08 * v, i * 0.09, 2.76, 0.3);
        return true;
      case "jingle":
        [784, 988, 1175, 1568].forEach((f, i) => this.bell(f, 1.1, 0.14 * v, i * 0.11, 3.0, 0.55));
        this.tone("triangle", 392, 392, 0.9, 0.07 * v, 0.33, 0.4, true);
        return true;
      case "swoosh":
        this.noise("bandpass", 300, 3200, 0.5, 0.35 * v, 0, 0.3, 0.25);
        return true;
      case "pick":
        this.bell(1568, 0.35, 0.16 * v, 0, 3.5, 0.3);
        this.bell(2093, 0.45, 0.14 * v, 0.06, 3.5, 0.3);
        return true;
      case "click":
        this.tone("triangle", 1400, 1700, 0.03, 0.18 * v);
        this.noise("highpass", 4000, 4000, 0.012, 0.06 * v);
        return true;
      case "tick":
        // a wood block, not a beep
        this.tone("sine", 1050, 900, 0.05, 0.3 * v);
        this.noise("bandpass", 2200, 1800, 0.02, 0.1 * v);
        return true;
      case "start":
        [440, 554, 659, 880].forEach((f, i) => this.bell(f, 0.6, 0.12 * v, i * 0.08, 2, 0.4));
        this.tone("sawtooth", 110, 110, 0.7, 0.06 * v, 0.32, 0.4, true);
        return true;
      case "win":
        [523, 659, 784, 1047, 1319].forEach((f, i) => this.bell(f, 1.2, 0.13 * v, i * 0.1, 2, 0.55));
        for (const f of [262, 330, 392]) this.tone("triangle", f, f, 1.6, 0.06 * v, 0.5, 0.5, true);
        return true;
      case "lose":
        [440, 370, 311, 233].forEach((f, i) => this.tone("triangle", f, f * 0.97, 0.3, 0.3 * v, i * 0.16, 0.5, true));
        this.tone("sine", 58, 40, 1.6, 0.4 * v, 0.6, 0.6);
        return true;
      case "bolter":
        // Adeptus Astartes .75 cal Godwyn Bolter: thunderous cannon THOOM + metallic bolt-slam + gyrojet rocket hiss
        this.tone("sine", 132 * r, 28, 0.28, 1.25 * v, 0, 0.35);
        this.tone("sawtooth", 168 * r, 42, 0.14, 0.48 * v);
        this.noise("lowpass", 2400 * r, 160, 0.26, 0.95 * v, 0, 0.55);
        this.noise("highpass", 3200 * r, 1400, 0.05, 0.62 * v);
        this.tone("square", 1550 * r, 620, 0.025, 0.24 * v, 0.028);        // heavy bolt carrier slam
        this.noise("bandpass", 2200, 4800, 0.13, 0.28 * v, 0.035, 0.3);    // micro-rocket thruster ignition
        this.noise("lowpass", 520, 110, 0.32, 0.28 * v, 0.08, 0.7, 0, true); // cathedral cannon echo
        return true;
      case "boltboom":
        // mass-reactive bolt detonation inside target or rock: sharp armor-cracking CRACK-BOOM
        this.tone("sine", 112 * r, 26, 0.3, 0.95 * v, 0, 0.45);
        this.tone("sawtooth", 190 * r, 44, 0.14, 0.42 * v);
        this.noise("lowpass", 2800 * r, 120, 0.32, 0.85 * v, 0, 0.6);
        this.noise("highpass", 3600 * r, 1300, 0.055, 0.52 * v);
        return true;
      case "chainrev":
        // roaring Astartes chainsword throttle burst: snarling V-twin growl + screaming adamantium teeth
        this.voice(68 * r, 178 * r, 0.26, 0.78 * v, 620, 44, 0, 0.35);
        this.voice(148 * r, 112 * r, 0.22, 0.55 * v, 1150, 52, 0.1, 0.35);
        this.tone("sawtooth", 96 * r, 240 * r, 0.19, 0.36 * v, 0, 0.25, true);
        this.noise("bandpass", 1800 * r, 4600 * r, 0.24, 0.48 * v, 0.02, 0.3);
        this.noise("highpass", 4200, 6800, 0.15, 0.24 * v, 0.04); // chain links rattling at high RPM
        return true;
      case "chainrip":
        // adamantium saw-teeth chewing straight through ceramite plate & flesh
        this.voice(135 * r, 78 * r, 0.24, 0.9 * v, 880, 58, 0, 0.3);
        this.tone("sawtooth", 340 * r, 120, 0.18, 0.42 * v);
        this.noise("bandpass", 2600 * r, 950, 0.2, 0.85 * v, 0, 0.35);
        this.noise("highpass", 4400 * r, 2200, 0.11, 0.55 * v, 0.02); // metallic spark shriek
        this.tone("sine", 145 * r, 36, 0.16, 0.85 * v);
        return true;
      case "jumpboost":
        // twin Astartes assault jump-pack turbines igniting: sub-thump + plasma roar + turbine spool
        this.tone("sine", 118 * r, 34, 0.28, 1.0 * v, 0, 0.4);
        this.noise("lowpass", 1600, 180, 0.34, 0.88 * v, 0, 0.55, 0, true);
        this.noise("bandpass", 900 * r, 2800 * r, 0.26, 0.52 * v, 0.01, 0.4);
        this.tone("sawtooth", 210 * r, 520 * r, 0.2, 0.18 * v, 0.02, 0.3, true); // turbine whine
        return true;
      case "heavystep":
        // ceramite power-armour sabaton planting onto stone + servo whirr
        this.tone("sine", 95 * r, 32, 0.12, 0.72 * v, 0, 0.25);
        this.noise("lowpass", 680 * r, 150, 0.08, 0.52 * v, 0, 0.22);
        this.tone("triangle", 420 * r, 310, 0.04, 0.12 * v, 0.01);
        return true;
      case "slamland":
        // meteor superhero landing: colossal sub-bass impact + cracking stone + metallic ceramite shockwave
        this.tone("sine", 86 * r, 21, 0.55, 1.3 * v, 0, 0.65);
        this.tone("sine", 44 * r, 22, 0.75, 0.85 * v);
        this.tone("sawtooth", 125 * r, 32, 0.22, 0.45 * v);
        this.noise("lowpass", 1900, 90, 0.52, 1.05 * v, 0, 0.7);
        this.noise("highpass", 2800 * r, 950, 0.08, 0.48 * v);
        for (let i = 0; i < 4; i++) this.noise("bandpass", 1100 + Math.random() * 1600, 320, 0.06, 0.22 * v, 0.08 + i * 0.06, 0.25);
        if (v > 0.65) this.duck(0.32, 0.6);
        return true;
    }
    return false;
  }

  /** the simple chiptune ones that stay as they are */
  private basic(name: SfxName, v: number) {
    switch (name) {
      case "thunder":
        this.noise("lowpass", 420, 60, 1.5, 1.1 * v, 0, 0.6);
        this.tone("sine", 58, 30, 1.1, 0.9 * v);
        this.noise("lowpass", 2400, 300, 0.25, 0.5 * v);
        this.noise("lowpass", 300, 60, 2.2, 0.5 * v, 0.6, 0.8, 0.4, true); // and it rolls on over the rooftops
        break;
      case "alarm":
        for (let i = 0; i < 3; i++) {
          this.tone("square", 640, 640, 0.15, 0.2 * v, i * 0.36, 0.3);
          this.tone("square", 470, 470, 0.15, 0.2 * v, i * 0.36 + 0.18, 0.3);
        }
        break;
      case "ping":
        this.tone("sine", 1760, 1700, 0.07, 0.3 * v);
        this.tone("sine", 1760, 1700, 0.07, 0.11 * v, 0.1);
        break;
      case "heart":
        this.tone("sine", 74, 44, 0.1, 1.0 * v);
        this.tone("sine", 64, 40, 0.1, 0.8 * v, 0.17);
        break;
      case "rumble":
        this.noise("lowpass", 190, 80, 0.6, 1.1 * v, 0, 0.4, 0, true);
        this.tone("sine", 48, 34, 0.55, 0.8 * v);
        break;
      case "beep":
        this.tone("square", 1250, 1250, 0.07, 0.25 * v);
        break;
      case "pod":
        this.noise("lowpass", 3000, 150, 0.35, 0.9 * v);
        this.tone("sine", 140, 40, 0.3, 0.9 * v);
        break;
      case "ko":
        this.tone("triangle", 780, 780, 0.07, 0.5 * v);
        this.tone("triangle", 590, 590, 0.07, 0.5 * v, 0.07);
        this.tone("triangle", 390, 300, 0.14, 0.5 * v, 0.14);
        break;
      case "dash":
        this.noise("bandpass", 700, 2600, 0.13, 0.35 * v);
        break;
      case "deflect":
        this.tone("square", 1300, 2200, 0.09, 0.4 * v);
        this.tone("triangle", 2600, 2600, 0.12, 0.3 * v, 0.03);
        break;
      default:
        break;
    }
  }

  /** play an effect; o places it in the street (see PlayOpt) */
  play(name: SfxName, v = 1, o: PlayOpt = {}) {
    if (!this.ctx || !this.master || this.muted || v < 0.02) return;
    const now = performance.now();
    if (now - (this.last[name] ?? 0) < (GAP[name] ?? 35)) return;
    // a pile-up of sounds turns into mud: when a lot is going on, the quiet far-away ones give way
    this.load = this.load.filter((q) => now - q < 400);
    if (this.load.length > 26 && v < 0.35) return;
    this.load.push(now);
    this.last[name] = now;
    const c = this.ctx, far = clamp(o.far ?? 0, 0, 1);
    try {
      const g = c.createGain();
      let head: AudioNode = g;
      if (c.createStereoPanner) {
        const p = c.createStereoPanner();
        p.pan.value = clamp(o.pan ?? 0, -1, 1) * 0.85;
        g.connect(p);
        head = p;
      }
      if (far > 0.05) {
        // the air and the buildings in between take the edge off
        const lp = c.createBiquadFilter();
        lp.type = "lowpass";
        lp.frequency.value = 9500 - far * 7800;
        head.connect(lp);
        head = lp;
      }
      head.connect(this.master);
      this.dest = g;
      this.wetK = 1 + far * 1.6;
      this.pk = o.pitch ?? 1;
      if (!this.rich(name, v)) this.basic(name, v);
    } catch {
      /* audio is optional */
    } finally {
      this.dest = null;
      this.wetK = 1;
      this.pk = 1;
    }
  }

  /** a musical hit for a moment of the story (it plays even with the music off: it is part of what happens) */
  stinger(kind: Stinger) {
    if (!this.ctx || !this.master || this.muted) return;
    try {
      this.dest = null;
      switch (kind) {
        case "dread":
          // something is wrong: a low boom, a string cluster swelling, a cymbal drawn backwards
          this.tone("sine", 46, 30, 2.6, 0.6, 0, 0.6);
          for (const f of [220, 233, 330, 349]) this.tone("sawtooth", f, f * 0.995, 2.4, 0.035, 0.1, 0.8, true);
          this.noise("highpass", 2000, 9000, 1.6, 0.16, 0, 0.6, 1.5);
          break;
        case "hit":
          // the orchestra slams down
          for (const f of [110, 131, 156, 208]) this.tone("sawtooth", f, f * 0.97, 0.9, 0.08, 0, 0.8);
          this.tone("sine", 55, 30, 1.4, 0.8, 0, 0.5);
          this.noise("lowpass", 4000, 200, 0.8, 0.5, 0, 0.8);
          break;
        case "boss":
          // BRAAAM - twice
          for (let i = 0; i < 2; i++) {
            for (const f of [55, 82.4, 110]) this.tone("sawtooth", f, f * 0.98, 1.3, 0.12, i * 1.1, 0.8, true);
            this.tone("sine", 41, 30, 1.3, 0.7, i * 1.1, 0.4);
            this.noise("lowpass", 1400, 150, 1.2, 0.3, i * 1.1, 0.7, 0.15);
          }
          break;
        case "fall":
          // the city is gone: brass sinking, a gong
          [220, 196, 175, 147].forEach((f, i) => this.tone("sawtooth", f, f * 0.98, 0.8, 0.06, i * 0.5, 0.8, true));
          this.bell(98, 4, 0.25, 0.2, 1.41, 0.9);
          this.tone("sine", 49, 30, 3, 0.5, 0.2, 0.6);
          break;
        case "found":
          [784, 988, 1175, 1568].forEach((f, i) => this.bell(f, 1, 0.14, i * 0.09, 3, 0.5));
          break;
        case "win":
          [523, 659, 784, 1047].forEach((f, i) => this.bell(f, 1.6, 0.14, i * 0.12, 2, 0.6));
          for (const f of [262, 330, 392, 523]) this.tone("sawtooth", f, f, 2, 0.04, 0.5, 0.7, true);
          break;
        case "lose":
          [330, 311, 294, 262].forEach((f, i) => this.tone("sawtooth", f, f * 0.98, 0.7, 0.06, i * 0.45, 0.8, true));
          this.tone("sine", 41, 28, 3, 0.6, 0.3, 0.6);
          break;
      }
      this.duck(kind === "found" ? 0.2 : 0.5, kind === "dread" ? 2.2 : 1.4);
    } catch {
      /* optional */
    }
  }

  // ───────── the city: a living bed of sound, and the odd thing happening somewhere ─────────
  private bed: { traffic: GainNode; hiss: GainNode; crowd: GainNode; water: GainNode; drone: GainNode; wind: GainNode; rain: GainNode } | null = null;
  private mix: Required<CityMix> = { traffic: 0, crowd: 0, panic: 0, birds: 0, night: 0, water: 0, sirens: 0, drone: 0, wind: 0, rain: 0 };
  private ev: Record<string, number> = {};

  private buildBed() {
    const c = this.ctx!, bus = this.ambBus!;
    const loop = (buf: AudioBuffer, off: number) => { const s = c.createBufferSource(); s.buffer = buf; s.loop = true; s.start(0, off); return s; };
    const gain = () => { const g = c.createGain(); g.gain.value = 0; g.connect(bus); return g; };
    const filt = (type: BiquadFilterType, f: number, q = 0.7) => { const b = c.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; };
    const lfo = (rate: number, depth: number, to: AudioParam) => { const o = c.createOscillator(), g = c.createGain(); o.frequency.value = rate; g.gain.value = depth; o.connect(g).connect(to); o.start(); };
    // traffic: the low roar of the avenues, and tyres hissing over the asphalt
    const traffic = gain(), tl = filt("lowpass", 230);
    loop(this.brownBuf!, 0.3).connect(tl).connect(traffic);
    lfo(0.07, 60, tl.frequency);
    const hiss = gain(), hb = filt("bandpass", 900, 0.5);
    loop(this.noiseBuf!, 0.8).connect(hb).connect(hiss);
    lfo(0.11, 300, hb.frequency);
    // the crowd: a bed of voices too far to make out (the babble on top is scheduled below)
    const crowd = gain(), cb = filt("bandpass", 520, 1.1), cb2 = filt("bandpass", 1400, 1.6), cm = c.createGain();
    cm.gain.value = 0.6;
    const cs = loop(this.noiseBuf!, 1.1);
    cs.connect(cb).connect(crowd);
    cs.connect(cb2).connect(cm).connect(crowd);
    lfo(0.4, 160, cb.frequency);
    // water lapping at the piers
    const water = gain(), wf = filt("bandpass", 380, 0.8);
    loop(this.brownBuf!, 2.1).connect(wf).connect(water);
    lfo(0.18, 140, wf.frequency);
    // the drone: something wrong with the city, under everything
    const drone = gain(), dl = filt("lowpass", 210);
    for (const [type, f] of [["sine", 46], ["sawtooth", 69.4], ["sine", 92.5]] as [OscillatorType, number][]) {
      const o = c.createOscillator();
      o.type = type; o.frequency.value = f;
      o.connect(dl);
      o.start();
    }
    lfo(0.13, 70, dl.frequency);
    dl.connect(drone);
    // wind through the streets, rain hissing on everything
    const wind = gain(), wb = filt("bandpass", 520, 0.6);
    loop(this.noiseBuf!, 0.2).connect(wb).connect(wind);
    lfo(0.21, 260, wb.frequency);
    const rain = gain(), rh = filt("highpass", 2600);
    loop(this.noiseBuf!, 1.37).connect(rh).connect(rain);
    this.bed = { traffic, hiss, crowd, water, drone, wind, rain };
  }

  /** the old ambience call: drone + wind + rain for the zombie cities (level 0 turns it off) */
  ambience(level: number, wind = 0.5, rain = 0) {
    this.city({ drone: level * 1.35, wind: level * wind * 2, rain: level > 0 ? rain : 0 });
  }

  /** the city around you; call it every frame with what is going on (missing layers fade out) */
  city(m: CityMix) {
    const c = this.ctx;
    if (!c || !this.master || !this.ambBus || !this.noiseBuf) return;
    try {
      if (!this.bed) {
        if (!Object.values(m).some((x) => (x ?? 0) > 0.01)) return;
        this.buildBed();
      }
      const B = this.bed!, t = c.currentTime, M = this.mix;
      const set = (k: keyof CityMix, g: GainNode | null, scale: number) => {
        const v = clamp(m[k] ?? 0, 0, 2);
        if (Math.abs(v - M[k]) < 0.01 && t > 0.5) return;
        M[k] = v;
        if (g) g.gain.setTargetAtTime(v * scale, t, 0.6);
      };
      set("traffic", B.traffic, 0.34); B.hiss.gain.setTargetAtTime(M.traffic * 0.035, t, 0.6);
      set("crowd", B.crowd, 0.05);
      set("water", B.water, 0.2);
      set("drone", B.drone, 0.4);
      set("wind", B.wind, 0.25);
      set("rain", B.rain, 0.12);
      set("panic", null, 0); set("birds", null, 0); set("night", null, 0); set("sirens", null, 0);
      this.happen(t);
    } catch {
      /* optional */
    }
  }

  /** a sound somewhere out in the street, routed through the ambience bus */
  private far(fn: () => void, pan: number, far: number, v: number) {
    const c = this.ctx!;
    if (this.muted || v < 0.02) return;
    const g = c.createGain(), lp = c.createBiquadFilter();
    let head: AudioNode = g;
    if (c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = clamp(pan, -1, 1) * 0.9; g.connect(p); head = p; }
    lp.type = "lowpass"; lp.frequency.value = 9500 - clamp(far, 0, 1) * 7400;
    head.connect(lp).connect(this.ambBus!);
    this.dest = g; this.wetK = 1 + far * 1.4;
    try { fn(); } finally { this.dest = null; this.wetK = 1; }
  }
  private every(key: string, t: number, rate: number, fire: () => void) {
    if (rate <= 0.001) { this.ev[key] = 0; return; }
    const next = this.ev[key] ?? 0;
    if (!next) { this.ev[key] = t + rnd(0.2, 1.2) / rate; return; }
    if (t < next) return;
    this.ev[key] = t + rnd(0.5, 1.5) / rate;
    fire();
  }
  /** the things that happen now and then: horns, voices in the crowd, a laugh, screams, birds, crickets, sirens */
  private happen(t: number) {
    const M = this.mix;
    this.every("honk", t, M.traffic * 0.32, () => this.far(() => this.rich("honk", 1), rnd(-1, 1), rnd(0.35, 0.95), 0.5 * M.traffic));
    this.every("pass", t, M.traffic * 0.25, () => this.far(() => { this.noise("bandpass", 220, 900, 1.4, 0.16, 0, 0.3, 0.6, true); this.noise("bandpass", 900, 260, 1.2, 0.05, 0.4, 0.3); }, rnd(-1, 1), rnd(0.2, 0.7), M.traffic));
    // babble: a crowd is many voices, each a few syllables - no two the same
    this.every("babble", t, M.crowd * 10, () => this.far(() => {
      const fem = Math.random() < 0.5, f = fem ? rnd(190, 260) : rnd(105, 150), n = 1 + ((Math.random() * 3) | 0);
      for (let i = 0; i < n; i++) this.human(f * rnd(0.9, 1.15), f * rnd(0.85, 1.05), rnd(0.07, 0.15), rnd(0.02, 0.045) * Math.min(1, M.crowd + 0.3), VOWS[(Math.random() * 5) | 0], i * rnd(0.11, 0.17), 0.2, 0.01);
    }, rnd(-1, 1), rnd(0.25, 0.9), 1));
    this.every("laugh", t, M.crowd * 0.12, () => this.far(() => {
      const f = Math.random() < 0.5 ? rnd(230, 300) : rnd(130, 170);
      for (let i = 0; i < 4; i++) this.human(f * (1 - i * 0.04), f * 0.95, 0.08, 0.04, VOW.a, i * 0.13, 0.25, 0.01);
    }, rnd(-1, 1), rnd(0.3, 0.8), 1));
    this.every("panic", t, M.panic * 1.4, () => this.far(() => this.rich(Math.random() < 0.6 ? "scream" : "shout", rnd(0.35, 0.8)), rnd(-1, 1), rnd(0.35, 1), 1));
    this.every("bird", t, M.birds * 1.6, () => this.far(() => {
      const f = rnd(2800, 5200), n = 2 + ((Math.random() * 4) | 0);
      for (let i = 0; i < n; i++) this.tone("sine", f * rnd(0.9, 1.1), f * rnd(1.15, 1.45), rnd(0.04, 0.08), 0.03, i * rnd(0.07, 0.12), 0.25);
    }, rnd(-1, 1), rnd(0.2, 0.7), 1));
    this.every("cricket", t, M.night * 2.2, () => this.far(() => {
      const f = rnd(4300, 4900);
      for (let i = 0; i < 3; i++) this.tone("sine", f, f, 0.025, 0.018, i * 0.045, 0.15);
    }, rnd(-1, 1), rnd(0.3, 0.8), 1));
    this.every("siren", t, M.sirens * 0.07, () => this.far(() => this.rich("siren", rnd(0.6, 1)), rnd(-1, 1), rnd(0.6, 1), 1));
  }

  // ───────── engines and machines ─────────
  private loops: Partial<Record<LoopId, { g: GainNode; f: AudioParam[]; base: number[]; lv: number; rt: number }>> = {};
  private buildLoop(id: LoopId) {
    const c = this.ctx!, g = c.createGain(), f: AudioParam[] = [], base: number[] = [];
    g.gain.value = 0;
    g.connect(this.master!);
    const osc = (type: OscillatorType, hz: number, to: AudioNode, vol: number) => {
      const o = c.createOscillator(), og = c.createGain();
      o.type = type; o.frequency.value = hz; og.gain.value = vol;
      o.connect(og).connect(to); o.start();
      f.push(o.frequency); base.push(hz);
      return o;
    };
    const filt = (type: BiquadFilterType, hz: number) => { const b = c.createBiquadFilter(); b.type = type; b.frequency.value = hz; return b; };
    const trem = (rate: number, depth: number, to: GainNode, follow = true) => {
      const o = c.createOscillator(), og = c.createGain();
      o.type = "square"; o.frequency.value = rate; og.gain.value = depth;
      o.connect(og).connect(to.gain); o.start();
      if (follow) { f.push(o.frequency); base.push(rate); }
    };
    const noiseIn = (buf: AudioBuffer, to: AudioNode) => { const s = c.createBufferSource(); s.buffer = buf; s.loop = true; s.connect(to); s.start(0, Math.random()); };
    if (id === "scooter") {
      // a small two-stroke: buzzy, revving with the speed
      const lp = filt("lowpass", 1100), am = c.createGain();
      am.gain.value = 0.7;
      osc("sawtooth", 46, lp, 0.5); osc("square", 92, lp, 0.18);
      trem(23, 0.3, am);
      lp.connect(am).connect(g);
    } else if (id === "bus") {
      // the school bus diesel: a deep rattle
      const lp = filt("lowpass", 420), am = c.createGain();
      am.gain.value = 0.7;
      osc("sawtooth", 33, lp, 0.6); osc("sawtooth", 49.5, lp, 0.35);
      noiseIn(this.brownBuf!, lp);
      trem(11, 0.28, am);
      lp.connect(am).connect(g);
    } else if (id === "heli") {
      // rotor blades chopping the air, a turbine whine above it
      const lp = filt("lowpass", 520), am = c.createGain();
      am.gain.value = 0.5;
      noiseIn(this.noiseBuf!, lp);
      osc("sine", 48, lp, 0.6);
      trem(12.5, 0.48, am, false);
      lp.connect(am).connect(g);
      const wh = c.createGain(); wh.gain.value = 0.02; osc("sine", 2600, wh, 1); wh.connect(g);
    } else if (id === "jet") {
      // a jetpack: a hissing blast of gas over a low roar, flickering
      const hp = filt("bandpass", 1500), lp = filt("lowpass", 240), am = c.createGain(), hg = c.createGain();
      am.gain.value = 0.75; hg.gain.value = 0.55;
      noiseIn(this.noiseBuf!, hp); hp.connect(hg).connect(am);
      noiseIn(this.brownBuf!, lp); lp.connect(am);
      osc("sawtooth", 58, lp, 0.25);
      trem(31, 0.18, am);
      am.connect(g);
    } else if (id === "saber") {
      // a lightsaber's hum: two detuned low buzzes and an octave above them, wavering
      const lp = filt("lowpass", 1100), am = c.createGain();
      am.gain.value = 0.8;
      osc("sawtooth", 88, lp, 0.32); osc("sawtooth", 89.6, lp, 0.28); osc("sine", 176, lp, 0.22); osc("square", 44, lp, 0.05);
      trem(6.5, 0.1, am, false);
      lp.connect(am).connect(g);
    } else if (id === "chainsaw") {
      // Astartes chainsword motor: guttural chugging 2-stroke idle that screams into a ferocious saw-tooth roar when swung
      const lp = filt("lowpass", 920), bp = filt("bandpass", 2400), am = c.createGain(), ng = c.createGain();
      bp.Q.value = 1.6; am.gain.value = 0.62; ng.gain.value = 0.24;
      f.push(lp.frequency); base.push(920);
      osc("sawtooth", 54, lp, 0.48); osc("sawtooth", 56.2, lp, 0.38); osc("square", 108, lp, 0.24); osc("sawtooth", 27, lp, 0.3);
      noiseIn(this.noiseBuf!, bp); bp.connect(ng).connect(am);
      trem(22, 0.38, am, true);
      lp.connect(am).connect(g);
    } else if (id === "flame") {
      // a flamethrower: a roaring gas jet that crackles
      const bp = filt("bandpass", 700), lp = filt("lowpass", 300), am = c.createGain();
      bp.Q.value = 0.6; am.gain.value = 0.7;
      noiseIn(this.noiseBuf!, bp); bp.connect(am);
      noiseIn(this.brownBuf!, lp); lp.connect(am);
      trem(17, 0.32, am, false);
      am.connect(g);
    } else {
      // a train in the tunnel: rumble and hum
      const lp = filt("lowpass", 280);
      noiseIn(this.brownBuf!, lp);
      osc("sawtooth", 60, lp, 0.25);
      lp.connect(g);
    }
    return { g, f, base, lv: -1, rt: -1 };
  }
  /** keep an engine running at a level (0 = off) and a rate 0..1 (revs) - call it every frame */
  loop(id: LoopId, level: number, rate = 0) {
    const c = this.ctx;
    if (!c || !this.master) return;
    try {
      let L = this.loops[id];
      if (!L) {
        if (level <= 0.01) return;
        L = this.loops[id] = this.buildLoop(id);
      }
      const t = c.currentTime, k = clamp(rate, 0, 1.5), lv = this.muted ? 0 : clamp(level, 0, 1);
      if (Math.abs(lv - L.lv) > 0.01) { L.lv = lv; L.g.gain.setTargetAtTime(lv * 0.5, t, 0.12); }
      if (Math.abs(k - L.rt) > 0.01) { L.rt = k; L.f.forEach((p, i) => p.setTargetAtTime(L!.base[i] * (1 + k * 1.3), t, 0.12)); }
    } catch {
      /* optional */
    }
  }
  /** silence every bed and engine (leaving a mode) */
  hush() {
    this.city({});
    for (const id of Object.keys(this.loops) as LoopId[]) this.loop(id, 0);
  }

  // ───────── background music: one clock, two moods, cross-faded by how dangerous it is right now ─────────
  musicOn = false;
  private mBus: GainNode | null = null;
  private mWet: GainNode | null = null;
  private mNext = 0;
  private mStep = 0;

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.mBus && this.ctx) this.mBus.gain.setTargetAtTime(on ? 0.55 : 0, this.ctx.currentTime, 0.25);
  }

  private mEnv(g: GainNode, at: number, dur: number, vol: number, atk: number) {
    g.gain.setValueAtTime(0.0001, at);
    g.gain.linearRampToValueAtTime(Math.max(0.0002, vol), at + Math.max(0.004, atk));
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
  }
  private mOut(g: GainNode, wet: number) {
    g.connect(this.mBus!);
    if (wet > 0 && this.mWet) { const w = this.ctx!.createGain(); w.gain.value = wet; g.connect(w).connect(this.mWet); }
  }
  private mTone(type: OscillatorType, f: number, at: number, dur: number, vol: number, atk: number, lp = 0, f1 = f, wet = 0.15) {
    const c = this.ctx!, o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, at);
    if (f1 !== f) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), at + dur);
    this.mEnv(g, at, dur, vol, atk);
    if (lp) {
      const q = c.createBiquadFilter();
      q.type = "lowpass";
      q.frequency.value = lp;
      o.connect(q).connect(g);
    } else o.connect(g);
    this.mOut(g, wet);
    o.start(at);
    o.stop(at + dur + 0.05);
  }
  /** a soft pad: two detuned saws, slowly opening */
  private mPad(f: number, at: number, dur: number, vol: number) {
    const c = this.ctx!, g = c.createGain(), lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(500, at);
    lp.frequency.linearRampToValueAtTime(1300, at + dur * 0.5);
    lp.frequency.linearRampToValueAtTime(700, at + dur);
    for (const d of [0.996, 1.004]) {
      const o = c.createOscillator();
      o.type = "sawtooth"; o.frequency.value = f * d;
      o.connect(lp); o.start(at); o.stop(at + dur + 0.05);
    }
    lp.connect(g);
    this.mEnv(g, at, dur, vol, dur * 0.35);
    this.mOut(g, 0.55);
  }
  /** an electric piano: a sine with a little bell on top, dying away */
  private mKey(f: number, at: number, dur: number, vol: number) {
    this.mTone("sine", f, at, dur, vol, 0.005, 0, f, 0.35);
    this.mTone("triangle", f * 2, at, dur * 0.4, vol * 0.25, 0.003, 0, f * 2, 0.35);
  }
  private mBell(f: number, at: number, dur: number, vol: number) {
    const c = this.ctx!, car = c.createOscillator(), mod = c.createOscillator(), mg = c.createGain(), g = c.createGain();
    car.frequency.value = f; mod.frequency.value = f * 3.5;
    mg.gain.setValueAtTime(f * 1.8, at); mg.gain.exponentialRampToValueAtTime(Math.max(1, f * 0.05), at + dur);
    mod.connect(mg).connect(car.frequency);
    this.mEnv(g, at, dur, vol, 0.004);
    car.connect(g);
    this.mOut(g, 0.6);
    car.start(at); mod.start(at); car.stop(at + dur + 0.05); mod.stop(at + dur + 0.05);
  }
  private mHat(at: number, vol: number, dur = 0.04) {
    const c = this.ctx!, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf;
    f.type = "highpass";
    f.frequency.value = 6500;
    g.gain.setValueAtTime(Math.max(0.0002, vol), at);
    g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    s.connect(f).connect(g);
    this.mOut(g, 0.1);
    s.start(at, Math.random() * 1.5);
    s.stop(at + dur + 0.03);
  }
  private mKick(at: number, vol: number) {
    this.mTone("sine", 150, at, 0.16, vol, 0.002, 0, 42, 0);
    this.mHat(at, vol * 0.18, 0.006); // the click of the beater
  }
  private mSnare(at: number, vol: number) {
    const c = this.ctx!, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf;
    f.type = "bandpass"; f.frequency.value = 1900; f.Q.value = 0.7;
    g.gain.setValueAtTime(vol, at);
    g.gain.exponentialRampToValueAtTime(0.0001, at + 0.16);
    s.connect(f).connect(g);
    this.mOut(g, 0.3);
    s.start(at, Math.random() * 1.5);
    s.stop(at + 0.2);
    this.mTone("triangle", 220, at, 0.09, vol * 0.7, 0.002, 0, 140, 0.2);
  }
  private mBrass(f: number, at: number, dur: number, vol: number) {
    const c = this.ctx!, g = c.createGain(), lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(350, at);
    lp.frequency.linearRampToValueAtTime(2200, at + 0.08);
    lp.frequency.exponentialRampToValueAtTime(500, at + dur);
    for (const m of [1, 1.5, 2]) {
      const o = c.createOscillator();
      o.type = "sawtooth"; o.frequency.value = f * m;
      o.connect(lp); o.start(at); o.stop(at + dur + 0.05);
    }
    lp.connect(g);
    this.mEnv(g, at, dur, vol, 0.03);
    this.mOut(g, 0.45);
  }

  /** one sixteenth note of the tune. T = tension 0..1 */
  private mNote(step: number, at: number, T: number) {
    const hz = (m: number) => 440 * Math.pow(2, (m - 69) / 12);
    const bar = (step >> 4) & 3, s = step & 15, calm = 1 - T, beat = 60 / (72 + 56 * T);
    const ROOT = [57, 53, 48, 55]; // A minor - F - C - G
    const tri = [0, bar === 0 ? 3 : 4, 7];
    if (calm > 0.06) {
      // safe: a warm pad, a walking bass, an electric piano comping, bells picking out the chord on top, a soft shaker
      if (s === 0) {
        for (const iv of tri) this.mPad(hz(ROOT[bar] + iv + 12), at, beat * 4.4, 0.035 * calm);
        this.mTone("triangle", hz(ROOT[bar] - 12), at, beat * 1.7, 0.13 * calm, 0.02, 0, hz(ROOT[bar] - 12), 0.1);
      }
      if (s === 8) this.mTone("triangle", hz(ROOT[bar] - 5), at, beat * 1.5, 0.1 * calm, 0.02, 0, hz(ROOT[bar] - 5), 0.1);
      if (s === 0 || s === 6 || s === 10) for (const iv of tri) this.mKey(hz(ROOT[bar] + iv + 12), at, beat * (s === 0 ? 1.6 : 0.9), 0.028 * calm);
      if (s % 4 === 2 || s === 12) this.mBell(hz(ROOT[bar] + 24 + tri[(s >> 2) % 3]), at, beat * 2.2, 0.026 * calm);
      if (s === 8 && bar & 1) this.mBell(hz(ROOT[bar] + 31), at, beat * 3, 0.02 * calm);
      if (s % 2 === 1 && calm > 0.5) this.mHat(at, (s % 4 === 3 ? 0.014 : 0.008) * calm, 0.03);
    }
    if (T > 0.08) {
      // danger: a pulsing bass, a kick on every beat, hats and a snare as it gets worse, strings grinding a semitone apart,
      // brass stabbing at the top of the bar, a tom fill when they are all over you
      const rt = [45, 45, 41, 43][bar];
      if (s % 2 === 0) this.mTone("sawtooth", hz(rt + (s === 14 ? 3 : 0)), at, beat * 0.42, 0.18 * T, 0.005, 260 + 700 * T, hz(rt + (s === 14 ? 3 : 0)), 0.05);
      if (s % 4 === 0) this.mKick(at, 0.55 * T);
      if (T > 0.35 && s % 4 === 2) this.mHat(at, 0.06 * T);
      if (T > 0.6 && s % 2 === 1) this.mHat(at, 0.03 * T, 0.02);
      if (T > 0.5 && (s === 4 || s === 12)) this.mSnare(at, 0.22 * T);
      if (s === 0 && !(bar & 1)) {
        this.mPad(hz(rt + 12), at, beat * 8, 0.045 * T);
        this.mPad(hz(rt + 13), at, beat * 8, 0.04 * T);
      }
      if (T > 0.72 && s === 0) this.mBrass(hz(rt), at, beat * 1.4, 0.08 * T);
      if (T > 0.8 && s >= 13) this.mTone("sine", 120 - (s - 13) * 16, at, 0.22, 0.32 * T, 0.003, 0, 70 - (s - 13) * 8, 0.3);
      if (T > 0.75 && s % 8 === 6) this.mTone("square", hz(rt + 24 + [0, 3, 6, 1][bar]), at, beat * 0.3, 0.04 * T, 0.004, 1800);
    }
  }

  /** call every frame. tension: 0 = safe and quiet, 1 = they are on you. Does nothing until the music has been switched on. */
  music(tension: number) {
    const c = this.ctx;
    if (!c || !this.out || !this.noiseBuf) return;
    if (!this.mBus) {
      this.mBus = c.createGain();
      this.mBus.gain.value = this.musicOn ? 0.55 : 0;
      this.mBus.connect(this.out); // not through the effects volume: muting the effects leaves the music alone
      // the music has its own hall
      if (this.ir) {
        const conv = c.createConvolver(), lp = c.createBiquadFilter();
        conv.buffer = this.ir;
        lp.type = "lowpass"; lp.frequency.value = 4200;
        this.mWet = c.createGain();
        this.mWet.gain.value = 0.6;
        this.mWet.connect(conv).connect(lp).connect(this.mBus);
      }
    }
    if (!this.musicOn) { this.mNext = 0; return; }
    const t = c.currentTime, T = tension < 0 ? 0 : tension > 1 ? 1 : tension;
    if (this.mNext < t - 0.4) this.mNext = t + 0.05;
    try {
      for (let guard = 0; this.mNext < t + 0.2 && guard < 8; guard++) {
        this.mNote(this.mStep++, this.mNext, T);
        this.mNext += 60 / (72 + 56 * T) / 4;
      }
    } catch {
      /* optional */
    }
  }
}

export const audio = new SoundKit();
