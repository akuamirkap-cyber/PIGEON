import type { ArenaMap, Decor } from "./maps";
import { WaterScene } from "./water";

type Ctx = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const hash = (x: number, y: number, seed = 0) => {
  let n = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 1442695041);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
};
const noise = (x: number, y: number, seed: number) => {
  const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  const a = hash(ix, iy, seed), b = hash(ix + 1, iy, seed), c = hash(ix, iy + 1, seed), d = hash(ix + 1, iy + 1, seed);
  return a * (1 - u) * (1 - v) + b * u * (1 - v) + c * (1 - u) * v + d * u * v;
};
const canvas = (w: number, h: number) => {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return [c, c.getContext("2d")!] as const;
};
const rect = (g: Ctx, col: string, x: number, y: number, w: number, h: number) => {
  g.fillStyle = col;
  g.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
};

let vista: HTMLImageElement | null = null;
export function preloadForest() {
  if (!vista && typeof Image !== "undefined") {
    vista = new Image();
    vista.src = new URL("images/bastion-rainforest.jpg", document.baseURI).href;
  }
  return vista;
}

// The irregular foliage and bark are baked once, not regenerated during combat.
const treeCache = new Map<string, { c: HTMLCanvasElement; ox: number; oy: number }>();
function leafCloud(g: Ctx, cx: number, cy: number, rx: number, ry: number, seed: number, dark = false) {
  const colors = dark
    ? ["#112f29", "#194235", "#255541", "#39704c", "#527e53"]
    : ["#123c2e", "#1c5035", "#2d6840", "#428048", "#6b9b56", "#a5bd75"];
  g.fillStyle = colors[0];
  g.beginPath();
  for (let i = 0; i < 22; i++) {
    const a = (i / 22) * TAU, r = 0.8 + hash(i, seed, 70) * 0.26;
    const x = Math.round(cx + Math.cos(a) * rx * r), y = Math.round(cy + Math.sin(a) * ry * r);
    if (i) g.lineTo(x, y); else g.moveTo(x, y);
  }
  g.closePath(); g.fill();
  for (let i = 0; i < Math.round(rx * ry * 0.22); i++) {
    const a = hash(i, seed, 71) * TAU, r = Math.sqrt(hash(i, seed, 72));
    const dx = Math.cos(a) * r * rx * 0.92, dy = Math.sin(a) * r * ry * 0.86;
    const light = clamp(Math.floor(2.3 - dy / ry * 2 + hash(i, seed, 73) * 1.6), 1, colors.length - 1);
    const w = 2 + hash(i, seed, 74) * 5, h = 1 + hash(i, seed, 75) * 3;
    rect(g, colors[light], cx + dx, cy + dy, w, h);
    if (i % 6 === 0) rect(g, colors[Math.min(colors.length - 1, light + 1)], cx + dx - 1, cy + dy - 1, w * 0.6, 1);
  }
}

function treeSprite(seed: number, banyan: boolean, distant = false) {
  const key = `${seed}:${banyan}:${distant}`;
  const old = treeCache.get(key);
  if (old) return old;
  const W = banyan ? 218 : 242, H = banyan ? 205 : 242;
  const [c, g] = canvas(W, H), ox = Math.round(W / 2), oy = H - 5;
  const ht = (banyan ? 123 : 151) + hash(seed, 2, 20) * 25;
  const lean = (hash(seed, 3, 20) - 0.5) * 28;
  const crown: number[][] = [];
  const bark = distant ? ["#173c32", "#234d3b", "#365e45"] : ["#252d23", "#3c3d2a", "#57533a", "#79694a", "#a18b61"];
  const branch = (x: number, y: number, ang: number, len: number, width: number, level: number, id: number) => {
    const bend = (hash(id, seed, 80) - 0.5) * 0.42;
    const ex = x + Math.cos(ang + bend) * len, ey = y + Math.sin(ang + bend) * len;
    const mx = x + Math.cos(ang - bend * 0.5) * len * 0.53, my = y + Math.sin(ang - bend * 0.5) * len * 0.53;
    const nx = -Math.sin(ang) * width, ny = Math.cos(ang) * width;
    g.fillStyle = bark[0];
    g.beginPath();
    g.moveTo(x + nx, y + ny); g.lineTo(mx + nx * 0.62, my + ny * 0.62);
    g.lineTo(ex + nx * 0.26, ey + ny * 0.26); g.lineTo(ex - nx * 0.26, ey - ny * 0.26);
    g.lineTo(mx - nx * 0.62, my - ny * 0.62); g.lineTo(x - nx, y - ny); g.closePath(); g.fill();
    g.strokeStyle = bark[2]; g.lineWidth = Math.max(1, width * 0.65); g.lineCap = "round";
    g.beginPath(); g.moveTo(x - width * 0.25, y); g.quadraticCurveTo(mx - width * 0.3, my, ex, ey); g.stroke();
    if (level < 1) {
      crown.push([ex, ey, 17 + hash(id, seed, 82) * 15, 11 + hash(id, seed, 83) * 9, id]);
      return;
    }
    branch(ex, ey, ang - (0.38 + hash(id, seed, 84) * 0.25), len * 0.72, width * 0.55, level - 1, id * 2 + 1);
    branch(ex, ey, ang + (0.35 + hash(id, seed, 85) * 0.35), len * 0.66, width * 0.52, level - 1, id * 2 + 2);
  };
  // Flared buttress roots are rooted in the walkable bank, not in a floating sprite box.
  for (let i = 0; i < 7; i++) {
    const dir = i % 2 ? 1 : -1, reach = 12 + hash(i, seed, 31) * 25;
    g.fillStyle = bark[1]; g.beginPath(); g.moveTo(ox + dir * 2, oy - 26);
    g.quadraticCurveTo(ox + dir * 7, oy - 5, ox + dir * reach, oy);
    g.lineTo(ox + dir * (reach + 3), oy + 2); g.lineTo(ox, oy + 1); g.closePath(); g.fill();
    g.strokeStyle = bark[3] ?? bark[2]; g.lineWidth = 1;
    g.beginPath(); g.moveTo(ox + dir * 4, oy - 17); g.quadraticCurveTo(ox + dir * 8, oy - 4, ox + dir * reach, oy); g.stroke();
  }
  for (let y = 0; y < ht * 0.67; y++) {
    const q = y / ht, tx = ox + lean * q + Math.sin(q * 7 + seed) * 2;
    const hw = 8.5 - q * 6.4 + (y < 12 ? (12 - y) * 0.34 : 0);
    rect(g, bark[0], tx - hw, oy - y, hw * 2 + 1, 1);
    rect(g, bark[1], tx - hw + 1, oy - y, hw * 1.3, 1);
    rect(g, bark[2], tx - hw + 2, oy - y, hw * 0.55, 1);
    if (!distant) {
      for (let k = 0; k < 3; k++) {
        const bx = tx - hw + 2 + k * hw * 0.6 + Math.sin(y * 0.05 + k * 3) * 1.3;
        rect(g, k === 0 ? "#94805a" : "#292f23", bx, oy - y, 1, 1);
      }
      if (noise(y * 0.09, seed, 91) > 0.48) rect(g, "#3e673a", tx - hw, oy - y, 2 + hash(y, seed, 92) * 2, 1);
    }
  }
  const forkY = oy - ht * 0.54, forkX = ox + lean * 0.54;
  branch(forkX, forkY, -2.43, ht * 0.27, 6, 2, seed + 12);
  branch(forkX + 3, forkY - 7, -0.75, ht * 0.3, 6, 2, seed + 57);
  branch(forkX, forkY - 8, -1.63, ht * 0.28, 6, 2, seed + 93);
  // Aerial roots and vines hang behind the crown; a few attach to actual branches.
  for (let i = 0; i < 11; i++) {
    const rx = forkX - 62 + hash(i, seed, 41) * 124, ry = forkY - 18 - hash(i, seed, 42) * 50;
    const len = (banyan ? 25 : 13) + hash(i, seed, 43) * (banyan ? 62 : 30);
    g.strokeStyle = distant ? "#214c3a" : "#344b2e"; g.lineWidth = 1;
    g.beginPath(); g.moveTo(rx, ry); g.quadraticCurveTo(rx + 4, ry + len * 0.5, rx - 2, ry + len); g.stroke();
    for (let j = 3; j < len; j += 7) rect(g, distant ? "#396346" : "#567c40", rx + Math.sin(j * 0.1) * 2 - 1, ry + j, 3, 1);
  }
  crown.sort((a, b) => b[1] - a[1]);
  for (const [x, y, rx, ry, id] of crown) leafCloud(g, x, y, rx, ry, id + seed, distant);
  if (!distant) {
    for (let i = 0; i < 16; i++) {
      const cy = oy - 5 - hash(i, seed, 100) * 48, cx = ox - 10 + hash(i, seed, 101) * 20;
      rect(g, "#597d3c", cx, cy, 4, 2);
      if (i % 4 === 0) { rect(g, "#de8357", cx + 1, cy - 2, 2, 2); rect(g, "#e8ce88", cx + 1, cy - 2, 1, 1); }
    }
  }
  const sp = { c, ox, oy };
  treeCache.set(key, sp);
  return sp;
}

export function paintForestTree(g: Ctx, d: Decor) {
  const sp = treeSprite(Math.floor(d.v * 23), d.k === "banyantree");
  const size = d.h > 0 ? d.h / 180 : d.k === "banyantree" ? 0.88 : 1;
  g.drawImage(sp.c, Math.round(d.x - sp.ox * size), Math.round(d.y - sp.oy * size), Math.round(sp.c.width * size), Math.round(sp.c.height * size));
}

function frond(g: Ctx, x: number, y: number, dir: number, len: number, lift: number, light = false) {
  for (let j = 0; j < len; j++) {
    const q = j / len, px = x + dir * j, py = y - Math.sin(q * 1.9) * lift + q * q * 3;
    rect(g, light ? "#849f55" : "#4f7d46", px, py, 1, 1);
    if (j > 2 && j < len - 1 && j % 2 === 0) {
      const tip = Math.sin(q * Math.PI) * (len > 14 ? 4 : 2.5);
      for (let k = -tip; k <= tip; k++) rect(g, k < 0 ? "#739950" : "#365f3a", px - dir * Math.abs(k) * 0.5, py + k, 1, 1);
    }
  }
}

function broadLeaf(g: Ctx, x: number, y: number, ang: number, len: number, width: number, light: boolean) {
  g.save(); g.translate(x, y); g.rotate(ang);
  g.fillStyle = light ? "#507e46" : "#2c623d";
  g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(-width, -len * 0.5, 0, -len);
  g.quadraticCurveTo(width * 0.95, -len * 0.6, 0, 0); g.fill();
  g.strokeStyle = light ? "#a2b46a" : "#6b9856"; g.lineWidth = 0.6;
  g.beginPath(); g.moveTo(0, -1); g.quadraticCurveTo(1, -len * 0.5, 0, -len + 1); g.stroke();
  g.strokeStyle = light ? "#709451" : "#406d43";
  for (let j = 3; j < len - 3; j += 3) {
    const w = Math.sin(j / len * Math.PI) * width * 0.55;
    g.beginPath(); g.moveTo(-w, -j - 2); g.lineTo(0, -j); g.lineTo(w, -j - 2); g.stroke();
  }
  g.restore();
}

const plants = new Set(["treefern", "bamboo", "rafflesia", "heliconia", "orchid", "bromeliad", "wildfern", "jungleshroom", "lotuspad", "mossrock", "flowervine", "shaperrelic"]);
export function paintForestPlant(g: Ctx, eg: Ctx | null, d: Decor): boolean {
  if (!plants.has(d.k)) return false;
  const x = Math.round(d.x), y = Math.round(d.y), seed = Math.floor(d.v * 500);
  if (d.k === "flowervine") {
    const h = d.h || 24;
    g.strokeStyle = "#3b5234"; g.lineWidth = 1;
    g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x - 3, y + h * 0.4, x + 4, y + h * 0.6, x + 1, y + h); g.stroke();
    for (let i = 3; i < h; i += 4) {
      const lx = x + Math.sin(i / h * TAU) * 1.5;
      broadLeaf(g, lx, y + i, i % 8 ? -1.2 : 1.2, 5, 2.2, i % 3 === 0);
      if (i % 17 === 0) { rect(g, "#d79983", lx + 1, y + i, 2, 2); rect(g, "#e9d0a1", lx + 1, y + i, 1, 1); }
    }
  } else if (d.k === "wildfern" || d.k === "treefern") {
    const tall = d.k === "treefern", ht = tall ? 19 + d.v * 16 : 1;
    if (tall) {
      for (let i = 0; i < ht; i++) {
        rect(g, i % 3 ? "#4d4630" : "#756044", x - 1 + i * 0.08, y - i, 3, 1);
        if (i % 5 === 0) rect(g, "#324d31", x - 2 + i * 0.08, y - i, 2, 1);
      }
    }
    const cy = y - ht;
    for (let i = 0; i < 5; i++) for (const dir of [-1, 1]) frond(g, x, cy, dir, (tall ? 22 : 9) - i * (tall ? 2.3 : 0.9), 3 + i * 2, i % 3 === 0);
    rect(g, "#b0bb79", x, cy - 8, 1, 7); rect(g, "#a7b46e", x + 1, cy - 9, 2, 1);
  } else if (d.k === "bamboo") {
    for (let i = 0; i < 4; i++) {
      const sx = x + i * 4 - 6, h = 19 + hash(i, seed, 15) * 25;
      rect(g, "#365739", sx, y - h, 2, h); rect(g, "#789454", sx, y - h, 1, h);
      for (let j = 4; j < h; j += 6) {
        rect(g, "#b0b77c", sx, y - j, 2, 1);
        if (j > 9) {
          frond(g, sx, y - j, j % 12 ? -1 : 1, 7, 3, true);
          frond(g, sx, y - j, j % 12 ? 1 : -1, 4, 4);
        }
      }
    }
  } else if (d.k === "orchid" || d.k === "heliconia" || d.k === "bromeliad") {
    const tall = d.k === "heliconia", h = tall ? 20 + d.v * 8 : 10 + d.v * 5;
    for (let i = -2; i <= 2; i++) broadLeaf(g, x + i, y, i * 0.56, tall ? 15 + Math.abs(i) * 3 : 9 + (2 - Math.abs(i)) * 2, tall ? 4 : 3, i < 0);
    for (let i = 0; i < (tall ? 3 : 2); i++) {
      const fx = x - 3 + i * 4, fy = y - h + i * (tall ? 4 : 3);
      g.strokeStyle = "#5b753f"; g.lineWidth = 1; g.beginPath(); g.moveTo(x, y - 2); g.quadraticCurveTo(fx - 2, fy + 4, fx, fy); g.stroke();
      const col = tall ? "#ce6e3b" : d.v > 0.6 ? "#b4a2b7" : "#d3a29e";
      rect(g, col, fx - 2, fy - 2, 4, 2); rect(g, col, fx - 1, fy - 3, 2, 4);
      rect(g, tall ? "#edb85a" : "#f0d5ab", fx, fy - 2, 1, 2);
    }
  } else if (d.k === "rafflesia") {
    for (let i = -2; i <= 2; i++) broadLeaf(g, x, y, i * 0.7, 9 + Math.abs(i) * 2, 4, i < 0);
    for (let i = 0; i < 6; i++) {
      const a = i * TAU / 6, px = x + Math.cos(a) * 5, py = y - 5 + Math.sin(a) * 2.5;
      g.fillStyle = "#a94a3a"; g.beginPath(); g.ellipse(px, py, 4.5, 2.8, a * 0.3, 0, TAU); g.fill();
      rect(g, "#dda77c", px - 1, py - 1, 1, 1);
    }
    g.fillStyle = "#4e3329"; g.beginPath(); g.ellipse(x, y - 5, 3.6, 2, 0, 0, TAU); g.fill();
    rect(g, "#d5ac68", x - 1, y - 6, 2, 1);
  } else if (d.k === "jungleshroom") {
    for (let i = 0; i < 3; i++) {
      const sx = x + i * 4 - 4, h = 5 + hash(i, seed, 19) * 5, w = i === 1 ? 5 : 3;
      rect(g, "#a6b398", sx, y - h, 1, h);
      g.fillStyle = d.v > 0.5 ? "#b69b62" : "#71aca4";
      g.beginPath(); g.ellipse(sx + 0.5, y - h, w, w * 0.42, 0, Math.PI, TAU); g.fill();
      rect(g, "#c0d4af", sx - w + 1, y - h, w * 2 - 1, 1);
      if (eg) rect(eg, "rgba(110,193,167,0.32)", sx - w + 1, y - h, w * 2 - 1, 1);
    }
  } else if (d.k === "lotuspad") {
    for (const dir of [-1, 1]) frond(g, x + dir * 2, y, dir, 6, 4);
    rect(g, "#4d8355", x - 5, y - 1, 10, 2);
    rect(g, "#ddbbbb", x - 2, y - 4, 5, 2); rect(g, "#f1debc", x, y - 5, 2, 2);
  } else if (d.k === "mossrock") {
    g.fillStyle = "#384f44"; g.beginPath(); g.moveTo(x - 8, y); g.lineTo(x - 6, y - 6);
    g.lineTo(x + 1, y - 9); g.lineTo(x + 7, y - 5); g.lineTo(x + 8, y); g.closePath(); g.fill();
    rect(g, "#72806a", x - 4, y - 7, 5, 2); rect(g, "#6c924b", x - 5, y - 8, 8, 2);
    frond(g, x - 4, y - 6, -1, 6, 4, true);
  } else if (d.k === "shaperrelic") {
    const h = 25;
    rect(g, "#253b35", x - 5, y - h, 10, h);
    rect(g, "#657465", x - 4, y - h + 1, 3, h - 1);
    rect(g, "#b29a63", x - 4, y - h + 2, 8, 1); rect(g, "#8c764a", x - 4, y - 7, 8, 2);
    rect(g, "#70bfb0", x, y - h + 6, 1, h - 14);
    for (let i = 0; i < 4; i++) broadLeaf(g, x + 3, y - i * 3, 0.9, 6, 3, i % 2 === 0);
    frond(g, x - 4, y, -1, 10, 7);
  }
  return true;
}

export function paintForestCover(g: Ctx | null, k: string, x: number, y: number, part: number): boolean {
  if (!["monstera", "blossom", "banyan", "fern", "grove"].includes(k)) return false;
  if (!g) return true;
  g.save();
  if (part === 0) {
    for (let i = -2; i <= 2; i++) broadLeaf(g, x + i * 3, y, i * 0.43, 17 - Math.abs(i) * 2, 6, false);
  } else {
    if (k === "banyan") {
      g.strokeStyle = "#464c32"; g.lineWidth = 4; g.beginPath(); g.moveTo(x - 12, y);
      g.bezierCurveTo(x - 10, y - 22, x + 13, y - 24, x + 12, y); g.stroke();
      g.strokeStyle = "#8b7b51"; g.lineWidth = 1; g.stroke();
    }
    for (let i = -3; i <= 3; i++) broadLeaf(g, x + i * 3, y, i * 0.39, 14 - Math.abs(i) * 1.1, 5.5, i % 2 === 0);
    for (const dir of [-1, 1]) frond(g, x + dir * 3, y - 1, dir, 12, 5, true);
    if (k === "blossom" || k === "grove") for (let i = -2; i <= 2; i++) {
      const px = x + i * 4, py = y - 8 - (i % 2 ? 3 : 0);
      rect(g, i % 2 ? "#ce9aa7" : "#d8bd87", px - 1, py - 1, 3, 3);
      rect(g, "#f0ddaf", px, py, 1, 1);
    }
  }
  g.restore();
  return true;
}

let rockAtlas: Uint8ClampedArray | null = null;
export function forestRockAtlas() {
  if (rockAtlas) return rockAtlas;
  const W = 512, H = 256, a = new Uint8ClampedArray(W * H * 3);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const wx = x + noise(x / 100, y / 110, 4) * 24;
    const wy = y + noise(x / 95, y / 80, 9) * 24;
    const cx = Math.floor(wx / 29), cy = Math.floor(wy / 23);
    let best = 1e9, second = 1e9, cellX = 0, cellY = 0;
    for (let iy = -1; iy <= 1; iy++) for (let ix = -1; ix <= 1; ix++) {
      const sx = cx + ix, sy = cy + iy;
      const dx = wx - (sx + 0.15 + hash(sx, sy, 12) * 0.7) * 29;
      const dy = wy - (sy + 0.15 + hash(sx, sy, 17) * 0.7) * 23;
      const dist = dx * dx + dy * dy;
      if (dist < best) { second = best; best = dist; cellX = sx; cellY = sy; }
      else if (dist < second) second = dist;
    }
    const edge = Math.sqrt(second) - Math.sqrt(best);
    const facet = hash(cellX, cellY, 30), fine = hash(x, y, 34) * 5;
    const rough = noise(x / 13, y / 11, 42) * 14;
    const fractured = hash(cellX, cellY, 39) > 0.32;
    const light = facet * 21 + rough + fine - (fractured && edge < 0.65 ? 13 : edge < 1.5 ? 5 : 0);
    const moss = noise(x / 43, y / 37, 56) > 0.65 ? 10 : 0;
    const o = (y * W + x) * 3;
    a[o] = 46 + light - moss * 0.4; a[o + 1] = 58 + light + moss; a[o + 2] = 49 + light - moss * 0.25;
  }
  rockAtlas = a;
  return a;
}

export function paintForestRoots(g: Ctx, m: ArenaMap) {
  const solid = (x: number, y: number) => {
    const tx = Math.floor(x / 8), ty = Math.floor(y / 8);
    const t = m.grid[ty * m.w + tx];
    return t === 1 || t === 2;
  };
  for (let x = 20; x < m.w * 8 - 20; x += 17) {
    for (let ty = 12; ty < m.h - 2; ty++) {
      if (!solid(x, ty * 8) || solid(x, ty * 8 - 1)) continue;
      const len = 14 + hash(x, ty, 4) * 42, dir = hash(x, ty, 9) > 0.5 ? 1 : -1;
      for (let j = 0; j < len; j++) {
        const px = Math.round(x + dir * j * 0.22 + Math.sin(j * 0.075) * 3), py = ty * 8 + j;
        if (!solid(px, py)) break;
        rect(g, "#343827", px, py, j < 12 ? 3 : 2, 1);
        rect(g, "#7b6c45", px, py, 1, 1);
        if (j > 8 && j % 12 === 0 && solid(px + dir * 5, py + 2)) {
          for (let k = 0; k < 7; k++) if (solid(px + k * dir, py + k * 0.5)) rect(g, "#474733", px + k * dir, py + k * 0.5, 1, 1);
        }
      }
    }
  }
}

export class ForestScene extends WaterScene {
  private trunks: HTMLCanvasElement;

  constructor(map: ArenaMap) {
    super(map);
    preloadForest();
    const [trunks, tg] = canvas(map.w * 8, map.h * 8);
    for (let i = 0; i < 24; i++) {
      const x = 20 + i * 88 + hash(i, 7, 4) * 44;
      const y = 535 + Math.sin(i * 1.5) * 15;
      const sp = treeSprite(i % 12, i % 3 === 0, true), size = 1.2 + hash(i, 3, 18) * 0.9;
      tg.globalAlpha = 0.54 + hash(i, 1, 5) * 0.16;
      tg.drawImage(sp.c, x - sp.ox * size, y - sp.oy * size, sp.c.width * size, sp.c.height * size);
    }
    tg.globalAlpha = 1;
    this.trunks = trunks;
  }

  drawBackground(g: Ctx, cl: number, ct: number, W: number, H: number, t: number) {
    const image = preloadForest();
    if (image?.complete && image.naturalWidth > 0) {
      const zoom = Math.max(W / image.naturalWidth, H / image.naturalHeight) * 1.38;
      const dw = image.naturalWidth * zoom, dh = image.naturalHeight * zoom;
      const x = -(dw - W) * (0.22 + 0.55 * cl / Math.max(1, this.map.w * 8 - W));
      const y = -(dh - H) * clamp(0.33 + ct / 1500, 0, 1);
      g.save(); g.imageSmoothingEnabled = true; g.drawImage(image, x, y, dw, dh); g.restore();
    } else {
      g.fillStyle = "#659889"; g.fillRect(0, 0, W, H);
    }
    g.globalAlpha = 0.6;
    g.drawImage(this.trunks, Math.round(-cl * 0.67), Math.round(168 - ct * 0.69));
    g.globalAlpha = 1;
    // Slow low-contrast mist separates distant vegetation from the playable bank.
    for (let i = 0; i < 3; i++) {
      const mx = ((i * 219 + t * (2 + i) - cl * 0.23) % (W + 250) + W + 250) % (W + 250) - 180;
      g.globalAlpha = 0.25;
      g.drawImage(this.mist, mx, H * 0.57 + Math.sin(i + t * 0.2) * 9, 280, 74);
    }
    g.globalAlpha = 1;
    if (ct > 510) { g.fillStyle = `rgba(9,35,29,${clamp((ct - 510) / 260, 0, 0.68)})`; g.fillRect(0, 0, W, H); }
  }

  drawAtmosphere(g: Ctx, cl: number, ct: number, W: number, H: number, t: number) {
    // A few near-camera leaves frame the view without covering targets or crosshairs.
    if (ct > 510 || H < 180) return;
    g.save();
    g.globalAlpha = 0.58;
    const off = Math.round(Math.sin(t * 0.7 + cl * 0.001) * 1.5);
    for (const side of [0, 1]) {
      const x = side ? W + 11 : -11, sign = side ? -1 : 1;
      g.strokeStyle = "#15382c"; g.lineWidth = 2;
      g.beginPath(); g.moveTo(x, -9); g.quadraticCurveTo(x + sign * 23, 5 + off, x + sign * 45, 22 + off); g.stroke();
      for (let i = 0; i < 8; i++) {
        const lx = x + sign * (6 + i * 5), ly = i * 3 - 3 + off;
        g.fillStyle = i % 2 ? "#31583a" : "#20492f";
        g.beginPath(); g.ellipse(lx, ly, 4, 1.7, sign * 0.55, 0, TAU); g.fill();
      }
    }
    g.restore();
  }
}