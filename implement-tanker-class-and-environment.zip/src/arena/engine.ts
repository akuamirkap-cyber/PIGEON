import { audio } from "../game/audio";
import type { SfxName } from "../game/audio";
import { DIFFS, TEAMS } from "../game/defs";
import type { DiffId } from "../game/defs";
import { drawText, glyphs, initSprites, mk } from "../game/sprites";
import { AIR, AT, PLAT, ROCK, decorDraw, findPath, getMap, hideSprite, paintBackdrop, paintMini, paintTerrain, solidPx, solidT, tileAt } from "./maps";
import type { ArenaMap, Backdrop, Decor, HideSpot, PickKind } from "./maps";
import { AWEP, AW_ORDER, BEAM, CHAIN_L, KATANA_L, SABER_L, isBlade, isTankWep, medSpr, nadeSpr, wspr } from "./weapons";
import type { AW, AWDef } from "./weapons";
import { ARENA_SKINS, ASTARTES, EYES, TROOPER, blobSpr, opHead, opPal, opTorso, tumbleSpr } from "./skins";
import { ForestScene } from "./forest";
import { hollowAccent, HollowScene } from "./hollow";

/**
 * The side-view team deathmatch: jetpacks, 360° aim, FULL 12-weapon arsenal per player (including Katana & Lightsaber
 * with vertical + 2.5D horizontal side-sweep combos & bullet parry/deflection), punchy ballistics & gunfire VFX,
 * multi-node Verlet articulated ragdoll physics, and richly detailed atmospheric arenas.
 */
export interface ArenaConfig { map: number; size: number; kills: number; time: number; diff: DiffId; skin: number; startWep?: AW; portalMe?: boolean }
export interface FeedItem { id: number; k: string; kt: number; v: string; vt: number; w: string; head: boolean; me: boolean; t: number }
export interface ArenaRow { name: string; team: number; k: number; d: number; dmg: number; me: boolean }
export interface SlotHud { id: AW; name: string; mag: number; ammo: number; max: number }
export interface ArenaHud {
  phase: "count" | "live" | "end"; time: number; score: [number, number]; target: number; myTeam: number;
  hp: number; fuel: number; nades: number; alive: boolean; respawn: number; shield: boolean;
  slots: (SlotHud | null)[]; cur: number; reload: number;
  feed: FeedItem[]; banner: { id: number; text: string; sub: string; color: string } | null;
  near: string; rows: ArenaRow[]; killer: string; streak: number; music: boolean;
  /** the hiding place within reach (its name), whether you are tucked away in one, and a line of advice for where you stand */
  hide: string; hidden: boolean; tip: string;
  /** the NOS tank 0..1, and whether you are sprinting on it right now */
  nos: number; sprint: boolean;
  /** the hologram shield: its energy 0..1, raised right now, and the seconds left until it can be raised again after it broke (0 = ready) */
  holo: number; holoUp: boolean; holoCd: number;
  /** the armour that is left (100, or 220 ceramite on Astartes) and its max, plus maxHp, whether you wear Astartes power armour, and whether you are diving into a meteor slam */
  armor: number; maxArmor: number; maxHp: number; isTank: boolean; dive: boolean;
  /** stunned by a tesla bolt (seconds left); the portals of your side that are open ([A, B] as 0/1 - null when it is not you who carries the portal gun) and which one the next shot opens */
  zap: number; portal: number[] | null; pnext: number;
}
export interface ArenaResult { win: number; myTeam: number; score: [number, number]; rows: ArenaRow[]; mvp: string; mvpTeam: number }
export interface ArenaCb { hud(h: ArenaHud): void; end(r: ArenaResult): void }

interface Slot { id: AW; mag: number; ammo: number }
interface Ctl { mx: number; jet: boolean; drop: boolean; fire: boolean; aim: number; nade: boolean; melee: boolean; reload: boolean; swap: boolean; pick: boolean; sprint: boolean; guard: boolean }
interface Bot {
  path: number[]; pi: number; pathT: number; pgx: number; pgy: number; gx: number; gy: number;
  target: Sol | null; react: number; lock: number; err: number; errT: number;
  firing: boolean; burstT: number; strafe: number; strafeT: number; hop: number; hopT: number;
  lx: number; ly: number; stuckT: number; unstuck: number; nadeCd: number; think: number; swapCd: number;
  fav: AW; hideGo: boolean;
  /** the hologram shield: for how much longer to hold it up, and until it may think of raising it again */
  guardT: number; guardCd: number;
  /** the portal gun (for the one who carries it): until it thinks of it again, where it is aiming and for how long before it fires, which way it tried last, when it last opened one; and for every bot: no portals as a short cut until then, and since when it has been making for one */
  portT: number; portAim: number; portFire: number; portN: number; portLast: number; portBan: number; portSince: number;
  /** on your own side: 0 a guard (stays with you, at its place in the line: slot px ahead of or behind you), 1 a hunter (goes after whatever the squad has seen); escort: on its way to that place right now */
  role: number; slot: number; escort: boolean;
  seen: { x: number; y: number; t: number } | null;
}
/** one part of a ragdoll: where it is and was (Verlet), its size and weight; how fast it was going this step before the bones and the ground had their say; what it is touching - floor, roof, a wall (and on which side) */
interface RagNode { x: number; y: number; ox: number; oy: number; r: number; invM: number; vx0: number; vy0: number; cf: boolean; cc: boolean; cw: number }
interface Ragdoll {
  team: number; skin: number; face: number; headless: boolean;
  life: number; maxLife: number; ownerId: number;
  /** 0:head, 1:chest, 2:hip, 3:handL, 4:handR, 5:footL, 6:footR */
  nodes: RagNode[];
  scarf: number[];
  burn: number; jetFail: number; thudCd: number; bloodT: number;
  /** asleep once it has come to rest (a push wakes it), and for how long it has lain still; the pool of blood under it 0..1; a spurt from the wound; its last twitches; no blood at all (a lightsaber, fire) */
  sleep: boolean; still: number; pool: number; spurt: number; twitch: number; dry: boolean;
}
interface SlashArc {
  x: number; y: number; ang: number; dir: number;
  plane: "vert" | "horiz" | "spin";
  r: number; col: string; hot: string; katana: boolean; chain?: boolean;
  life: number; max: number;
}
interface VaporTrail {
  x0: number; y0: number; x1: number; y1: number;
  w: number; col: string; hot: string; life: number; max: number;
}
interface Ghost { x: number; y: number; face: number; team: number; skin: number; col: string; life: number; max: number }
/** a portal: where it is on the face of the rock and which way that face looks, whose it is and which of their two, how long it has been open, the flare of something going through */
interface Portal { x: number; y: number; nx: number; ny: number; team: number; slot: number; t: number; fx: number }
/** an arc of lightning between two points */
interface Bolt { x0: number; y0: number; x1: number; y1: number; life: number; max: number }
/** falling rock: a stalactite that has worked loose (kind 0, h long: it trembles for 'wait' before it lets go) or a piece of roof that has been shot away (kind 1) - and who brought it down */
interface Rock { x: number; y: number; vx: number; vy: number; rot: number; vr: number; kind: number; h: number; col: string; wait: number; by: Sol | null; hit: number[] }
interface Bat { x: number; y: number; a: number; sp: number; t: number; life: number }
/** a geyser: its vent, how tall its column is, where it is in its cycle (ph), how hard it is blowing 0..1, its state: 0 quiet, 1 about to let go, 2 erupting */
interface Geyser { x: number; y: number; h: number; ph: number; on: number; st: number; big: boolean }
/** the burst of shards where a critical hit landed */
interface CritFx { x: number; y: number; ang: number; life: number; max: number; col: string; seed: number }
interface Sol {
  id: number; name: string; team: number; skin: number; me: boolean; bot: Bot | null;
  x: number; y: number; vx: number; vy: number; ground: boolean; face: number; aim: number;
  hp: number; alive: boolean; respawn: number; shield: number; hurtT: number;
  fuel: number; jet: boolean; wasJet: boolean; fuelWait: number; jetK: number; burst: number; sputT: number;
  slots: (Slot | null)[]; cur: number; prevCur: number; nades: number; nadeCd: number;
  fireCd: number; reload: number; reloadMax: number; trig: boolean; recoil: number; bloom: number; loud: number; smokeT: number;
  melee: number; meleeCd: number;
  /** blades (katana & lightsaber): 4-hit combo with vertical overhead, 2.5D horizontal side-sweeps, & finishers */
  swingT: number; swingDur: number; swingKind: number; swingDir: number; swingPlane: "vert" | "horiz" | "spin"; swingZ: number; swingScale: number;
  combo: number; lastSwing: number; swingHit: number[];
  saberOn: number; blade: number; bladePrev: number; trail: number[]; tip: number[] | null;
  kills: number; deaths: number; dmg: number; streak: number; multi: number; lastKill: number;
  /** how the body moves: stride, running, squash on landing, tilt from a hit; muzzle flash and its shape; the shotgun's pump */
  walkT: number; runK: number; squash: number; tilt: number; flash: number; flashT: number; seed: number; pump: number;
  burn: number; burnBy: Sol | null; burnT: number; lastBy: Sol | null; lastByT: number;
  drop: number; rot: number; vrot: number; headless: boolean; stepT: number; scarf: number[];
  ragdoll: Ragdoll | null;
  /** tucked in behind the cover of a hiding place (and for how long); ducked - by choice or in a rat-tunnel - and how far down, 0..1 */
  hide: HideSpot | null; hideT: number; crouch: boolean; duck: number; duckT: number;
  /** NOS: what is left in the tank 0..1, sprinting on it right now (and how hot it burns, 0..1), until the next kick, until it refills; after-images; the last footfall counted; skidding 0..1 */
  nos: number; sprint: boolean; nosK: number; nosCd: number; nosWait: number; ghostT: number; stepI: number; skid: number;
  /** the hologram shield (right mouse button): raised right now, how far it has unfolded 0..1, the energy it has left, the seconds until it can be raised again once broken, how long since it was last struck, the flare of a blow 0..1 and where along the wall it landed, the button as it was last frame */
  holo: boolean; holoK: number; holoHp: number; holoCd: number; holoHitT: number; holoFx: number; holoAt: number; holoWas: boolean;
  /** the armour that is left (100 standard, 220 ceramite for Astartes), max stats, flare 0..1, stun & shove */
  maxHp: number; maxArmor: number; maxHolo: number;
  armor: number; armorFx: number; stun: number; shove: number;
  /** flight & landing physics: seconds spent airborne, actively diving ([S] in mid-air for Meteor Slam), and chainsword engine rev 0..1 */
  airT: number; dive: boolean; chainRev: number;
  /** stunned by lightning (seconds left) and safe from another charge (seconds left); carries the portal gun, and which of the two portals the next shot opens; just through a portal (seconds until the next one) */
  zap: number; zapImm: number; carrier: boolean; pnext: number; portCd: number;
  /** sent flying by a critical hit (seconds left of it), how often they have struck the rock on the way, how far they have tumbled round and how fast; safe from another one (seconds left); lifted by a geyser (seconds since) */
  launch: number; bounces: number; spin: number; spinV: number; critImm: number; lift: number;
  /** what shows on the face and over the head, and what they shout */
  ouch: number; joy: number; alert: number; dizzy: number; mad: number; say: string; sayT: number; sayCd: number; lowSaid: boolean;
  ctl: Ctl;
}
interface Shot { x: number; y: number; px: number; py: number; sx: number; sy: number; vx: number; vy: number; life: number; by: Sol; w: AW; kind: AWDef["kind"]; dmg: number; hit: number[]; tried: number[]; bounce: number; r: number; spin: number; dist: number; slot: number; wz: boolean; crit: boolean }
interface Nade { x: number; y: number; vx: number; vy: number; fuse: number; by: Sol; rot: number; beep: boolean }
interface Pick { x: number; y: number; vx: number; vy: number; kind: PickKind; spot: boolean; t: number; mag: number; ammo: number; life: number; bob: number }
interface Part { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; col: string; grav: number; drag: number; kind: number; rot: number; vr: number; spr: HTMLCanvasElement | null; n: number }
interface Txt { x: number; y: number; text: string; col: string; life: number; vy: number; big?: number }
interface Flash { x: number; y: number; r: number; life: number; max: number; col: string }
interface Ring { x: number; y: number; r: number; life: number; max: number; col: string }
interface Star { x: number; y: number; life: number; col: string }
interface HitFx { x: number; y: number; ang: number; r: number; kind: number; life: number; max: number; col: string }
interface Burst { x: number; y: number; ang: number; r: number; life: number; max: number; seed: number }
interface Scorch { x: number; y: number; life: number; col: string }
interface Tumble { x: number; y: number; vx: number; vy: number; rot: number; life: number; s: number }

const GRAV = 700, JET = 1640, MAXUP = 262, MAXFALL = 465, WALK = 134, AIRSPD = 166, CRAWL = 72;
/** a soldier's box: half its width, its height standing, its height ducked (low enough for the two-tile rat-tunnels) */
const HW = 4, HH = 19, CH = 11, RESPAWN = 3.5, SHIELD = 2.2, NADE_V = 310, NADE_G = 640, SABER_R = 37;
/** how much faster a sprint on NOS is; how fast the legs turn over (radians of stride per unit of walkT: one footfall every PI) */
const SPRINT = 1.45, GAIT = 18;
const NOSC = ["#ffffff", "#bff2ff", "#5fd8ff", "#3a8cff"];
/** the hologram shield: the energy it has (165 on an Astartes Iron Halo), the seconds it stays down once broken, recharge, radius & arc */
const HOLO_HP = 120, TANK_HOLO = 165, HOLO_CD = 5, HOLO_WAIT = 1, HOLO_REGEN = 32, HOLO_R = 14, HOLO_ARC = 1.05;
const HOLOC = [{ col: "#4fc8ff", hot: "#d8f6ff", dim: "#1f6fc8" }, { col: "#ff6a4a", hot: "#ffe2d6", dim: "#b82a2a" }];
/** armour: 100 standard steel, 220 thick Adeptus Astartes ceramite (+135 HP & 22% ceramite deflection) */
const ARMOR = 100, TANK_ARMOR = 220, TANK_HP = 135, ARMOR_WAIT = 4.2, ARMOR_REGEN = 25, TANK_ARMOR_REGEN = 36;
const ARMC = ["#ffffff", "#fff3a0", "#ffd23a", "#ffb04a", "#bfe0ff"];
const BOLTC = ["#ffffff", "#fff6b8", "#ffd24a", "#ff8a24", "#e83e18"];
const CHAINC = ["#ffffff", "#fff2a8", "#ffd23a", "#ff7a1e", "#e02838"];
/** the tesla gun: its light; how long its bolt stuns whoever it strikes - and each of the (up to three) of their side nearest to them that the charge leaps on to, and how far it can leap */
const ELEC = { col: "#5fd8ff", hot: "#e6fbff" };
const ELC = ["#ffffff", "#e6fbff", "#8fe8ff", "#5fd8ff"];
const ZAP_T = 1, ZAP_CHAIN = 0.3, ZAP_N = 3, ZAP_R = 170;
/** the argent axe: the fire it is made of */
const AXC = ["#ffffff", "#ffe9a0", "#ffb03a", "#ff6a1e", "#e03a12"];
/** portals: half the length of the opening, and the light of the two that each side can have open ([team][which]) */
const PH = 11;
const PORTC = [["#3aa8ff", "#ff9a2a"], ["#ff4a9a", "#a866ff"]];
/**
 * Breakable ground: what a tile stands up to (earth, hard rock), what one round of each weapon does to it (a blast does far more),
 * the size of whatever stands on it - half its width and its height, 0 = as tall as it was built - and what hangs from a roof instead.
 */
const TILE_HP = [0, 160, 340];
const TPOW: Partial<Record<AW, number>> = { bolter: 38, pistol: 7, uzi: 4, shotgun: 5, rifle: 8, e11: 9, magnum: 28, sniper: 48, saw: 16, tesla: 10 };
const DECOR_BOX: Record<string, number[]> = {
  crystal: [14, 30], bigcrystal: [40, 100], ceilcrystal: [40, 100], mycotree: [76, 140], cavefern: [14, 28], runepillar: [10, 46], gotharch: [22, 62], monolith: [12, 56], glowlily: [7, 11], censer: [7, 0],
  canopytree: [122, 245], banyantree: [110, 210], treefern: [17, 36], bamboo: [11, 38], rafflesia: [12, 12], heliconia: [10, 21], orchid: [7, 16], bromeliad: [7, 11],
  wildfern: [8, 14], jungleshroom: [8, 15], lotuspad: [8, 13], mossrock: [7, 9], flowervine: [5, 0], shaperrelic: [10, 45],
  shroom: [9, 15], stalagmite: [4, 15], stalag: [4, 17], vine: [4, 0], rock: [6, 7],
  rail: [4, 5], beam: [12, 0], ratsign: [7, 18], cactus: [7, 20], bones: [8, 8], tuft: [4, 7], palm: [18, 40], sandbag: [11, 10], crate: [8, 13], barrel: [6, 13], pillar: [7, 30],
  rubble: [6, 5], cone: [5, 9], tire: [6, 7], weed: [3, 6], lamp: [9, 34], cart: [13, 24],
};
const HANGS: Record<string, number> = { stalag: 1, vine: 1, ceilcrystal: 1, censer: 1, flowervine: 1 };
const JFLORA: Record<string, number> = { canopytree: 1, banyantree: 1, treefern: 1, bamboo: 1, rafflesia: 2, heliconia: 2, orchid: 2, bromeliad: 2, wildfern: 1, lotuspad: 2, flowervine: 2 };
const GEMS = ["#5ff0e0", "#d57dff", "#6bffb0", "#ffd05a", "#ff72c0"];
const D4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
/**
 * Critical hits: the chance that one round, pellet or blow of each weapon is one (the last blow of a combo, a blow in the back,
 * a direct hit by a rocket and anything that lands on somebody stunned by lightning always is) - and how much of that chance the enemy's bots get.
 */
const CRIT: Partial<Record<AW, number>> = { bolter: 0.14, chainsword: 0.2, pistol: 0.09, uzi: 0.02, shotgun: 0.03, rifle: 0.04, e11: 0.045, magnum: 0.2, sniper: 0.3, saw: 0.15, katana: 0.14, saber: 0.14, axe: 0.18 };
const CRIT_MUL: Record<DiffId, number> = { easy: 0.25, normal: 0.5, hard: 0.8 };
/** geysers: how long one goes from eruption to eruption (the last 2.1 s of it erupting, the 0.9 s before that bubbling); the colours of water and steam */
const GEY_T = 7.4;
const GEYC = ["#ffffff", "#c8f8ff", "#6fdcf0", "#9ae8ff"];
/** the bones of a ragdoll, in the proportions of a living soldier: [from, to, length, 1 = a limb, which folds but never stretches] */
const RAG: number[][] = [[1, 2, 4.6, 0], [0, 1, 6, 0], [1, 3, 4.6, 1], [1, 4, 4.6, 1], [2, 5, 3.5, 1], [2, 6, 3.5, 1]];
const rand = Math.random;
const PI2 = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angDiff = (a: number, b: number) => { let d = (b - a) % PI2; if (d > Math.PI) d -= PI2; if (d < -Math.PI) d += PI2; return d; };
const smooth = (k: number) => { const q = clamp(k, 0, 1); return q * q * (3 - 2 * q); };
const easeOut = (k: number) => { const q = clamp(k, 0, 1); return 1 - (1 - q) * (1 - q); };
const pickOne = <T>(a: T[]): T => a[(rand() * a.length) | 0];
const NAMES = ["RAJAWALI", "GARUDA", "KOBRA", "MACAN", "ELANG", "BADAK", "HIU", "SERIGALA", "KOMODO", "BANTENG", "PETIR", "TOPAN", "BAJA", "GERHANA", "KILAT", "BADAI", "RAZOR", "MAMBA", "HYENA", "JACKAL"];
const BOT_FAVS: AW[] = ["rifle", "e11", "shotgun", "uzi", "magnum", "sniper", "katana", "saber", "saw", "rpg", "axe", "tesla"];
export const PICK_NAME: Record<PickKind, string> = { uzi: "UZI", shotgun: "SHOTGUN", rifle: "AK-47", sniper: "SNIPER", rpg: "BAZOOKA", flame: "PENYEMBUR API", saw: "GERGAJI", magnum: "DEAGLE EMAS", e11: "BLASTER E-11", katana: "KATANA", saber: "LIGHTSABER", axe: "KAPAK ARGENT", tesla: "SENAPAN TESLA", portal: "PISTOL PORTAL", health: "MEDKIT +60", nades: "GRANAT +2" };
const RESPAWN_T: Partial<Record<PickKind, number>> = { health: 14, nades: 12, saber: 24, katana: 24 };
const SLOT_CODES = ["KeyB", "KeyV", "Digit1", "Digit2", "Digit3", "Digit4", "Digit5", "Digit6", "Digit7", "Digit8", "Digit9", "Digit0", "Minus", "Equal", "KeyK", "KeyT", "KeyP"];
const BLOOD = ["#a8202c", "#7a1420", "#d04a4a"];
const FIRE = ["#fff3a0", "#ffd23a", "#ff9a2a", "#ff5a2a"];
const SMOKE = ["#5a5660", "#77727c", "#45414b"];
const DMG_MUL: Record<DiffId, number> = { easy: 0.55, normal: 0.8, hard: 1 };
const LINES: Record<string, string[]> = {
  kill: ["MAMPUS!", "SATU LAGI!", "GG!", "EZ!", "HAHA!", "KENA KAU!", "TUMBANG!"],
  trooper: ["UNTUK KEKAISARAN!", "TARGET HANCUR!", "HAHAHA!"],
  astartes: ["DEMI KAISAR!", "TIADA AMPUN!", "BIDAH MUSNAH!", "MAJU ASTARTES!", "BAJA CERAMITE!"],
  chainsaw: ["ROBEK BAJANYA!", "VRRRRAAAH!", "DARAH & BAJA!", "GERGAJI KAISAR!"],
  hurt: ["ADUH!", "SAKIT!", "ARGH!", "UGH!"],
  nade: ["GRANAT!", "AWAS!", "TIARAP!"],
  reload: ["RELOAD!", "TUTUP AKU!"],
  low: ["TOLONG!", "BUTUH MEDIS!", "SEKARAT!"],
  saber: ["WUSSS!", "MAY THE FORCE...", "RASAKAN INI!"],
  deflect: ["TANGKIS!", "HA!", "PERCUMA!"],
  back: ["AKU KEMBALI!", "BALAS DENDAM!", "AYO LAGI!"],
  spot: ["MUSUH!", "KONTAK!", "DI SANA!", "KULIHAT DIA!"],
  help: ["AKU BANTU!", "LINDUNGI KAPTEN!", "BERTAHAN, KAPTEN!"],
};

export class ArenaGame {
  W = 480;
  H = 270;
  scale = 2;
  joyL = { x: 0, y: 0, on: false };
  joyR = { x: 0, y: 0, on: false };
  touch = false;
  paused = false;
  private cv: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: ArenaCb;
  private map!: ArenaMap;
  private environment: ForestScene | HollowScene | null = null;
  private terr!: HTMLCanvasElement;
  private tg!: CanvasRenderingContext2D;
  private emis: HTMLCanvasElement | null = null;
  private mini!: HTMLCanvasElement;
  private back!: Backdrop;
  private dark: HTMLCanvasElement;
  private dg: CanvasRenderingContext2D;
  /** a screen-sized buffer for what glows by itself: the outlines of the soldiers are cut out of it, so the glow of a crystal does not shine through whoever stands in front of it */
  private eb: HTMLCanvasElement;
  private ebg: CanvasRenderingContext2D;
  private glow: HTMLCanvasElement;
  private glowC: Record<string, HTMLCanvasElement> = {};
  private cfg: ArenaConfig | null = null;
  private sol: Sol[] = [];
  private me!: Sol;
  private shots: Shot[] = [];
  private nades: Nade[] = [];
  private picks: Pick[] = [];
  private parts: Part[] = [];
  private texts: Txt[] = [];
  private flashes: Flash[] = [];
  private rings: Ring[] = [];
  private stars: Star[] = [];
  private hitfx: HitFx[] = [];
  private bursts: Burst[] = [];
  private scorch: Scorch[] = [];
  private tumbles: Tumble[] = [];
  private corpses: Ragdoll[] = [];
  private slashArcs: SlashArc[] = [];
  private trails: VaporTrail[] = [];
  private ghosts: Ghost[] = [];
  private stalags: Decor[] = [];
  private crystals: Decor[] = [];
  private sand: number[] = [];
  private dust: number[] = [];
  private spores: number[] = [];
  private fireflies: number[] = [];
  private butterflies: number[] = [];
  private petals: number[] = [];
  private coolTipT = 0;
  private birdT = 4;
  private gust = 0.5;
  private tumbleT = 2;
  private dripT = 0.5;
  private glintT = 0.2;
  /** how hard the cover of each hiding place is shaking; the hiding place within the player's reach; how far the camera runs ahead */
  private hideShake: number[] = [];
  private hint: HideSpot | null = null;
  private camLead = 0;
  /** the sprint button of the touch screen is held down */
  touchSprint = false;
  /** the shield button of the touch screen is held down */
  touchGuard = false;
  /** what your side knows: where each enemy was last seen, by you or by anybody on your team (the squad shares it); whom you last hit, and when */
  private intel = new Map<number, { x: number; y: number; t: number }>();
  private intelT = 0;
  private focusE: Sol | null = null;
  private focusT = -9;
  /** for how long you have neither moved nor fired: a squad whose captain stands still goes hunting by itself */
  private meIdle = 0;
  /** portals: the two that each side can have open ([team][which]); lightning in the air */
  private portals: (Portal | null)[][] = [[null, null], [null, null]];
  private bolts: Bolt[] = [];
  /** breakable ground: the arena as it was built; the damage each tile has taken; the tiles that cannot be broken; what stands on (or hangs from) each tile; the bare arena under everything, to paint back in; how many chunks may still fly this frame */
  private grid0: Uint8Array = new Uint8Array(0);
  private tdmg = new Float32Array(0);
  private tsafe = new Uint8Array(0);
  private decorOn = new Map<number, Decor[]>();
  private base!: HTMLCanvasElement;
  private bg0!: CanvasRenderingContext2D;
  private ebase: HTMLCanvasElement | null = null;
  private eg: CanvasRenderingContext2D | null = null;
  private eg0: CanvasRenderingContext2D | null = null;
  private mg!: CanvasRenderingContext2D;
  private scratch!: CanvasRenderingContext2D;
  private debris = 0;
  /** the colour of the back of a hollow dug out of the rock */
  private hollowCol = "#0c0a14";
  /** the camera's zoom (it comes in close with a blade in hand) and the punch a blow adds to it; its roll, on a spring; where a critical hit pulls its window to, and for how long; and the view as it was last drawn: zoom, roll, the middle of its window */
  private zoom = 1;
  private zoomKick = 0;
  private roll = 0;
  private rollV = 0;
  private zfx = 0;
  private zfy = 0;
  private zfT = 0;
  private vwZ = 1;
  private vwR = 0;
  private vwX = 240;
  private vwY = 135;
  /** speed lines across the picture (0..1) and the way they run; the bursts of shards where critical hits landed */
  private rush = 0;
  private rushA = 0;
  /** whoever you have just sent flying with a critical hit, and for how much longer the camera swings out to keep them in the picture */
  private track: Sol | null = null;
  private trackT = 0;
  private crits: CritFx[] = [];
  /** the living cave: falling rock, bats, geysers; the tiles a stalactite hangs in; who is to blame for what comes down next; the waterfall [x, y, height]; the shaking (how hard, how long is left of it, when the next one comes, when the next stalactite goes); the swing of the lanterns and the flare of every light */
  private rocks: Rock[] = [];
  private bats: Bat[] = [];
  private geysers: Geyser[] = [];
  private stalagAt = new Map<number, Decor>();
  private blame: Sol | null = null;
  private falls: number[][] = [];
  private quake = 0;
  private qk = 0;
  private quakeT = 20;
  private rkT = 0;
  private sway = 0;
  private flare = 0;
  private score: [number, number] = [0, 0];
  private phase: "count" | "live" | "end" = "count";
  private phaseT = 3.2;
  private timeLeft = 300;
  private t = 0;
  private endT = 0;
  private slow = 0;
  private hitStop = 0;
  private cam = { x: 0, y: 0, shake: 0, kx: 0, ky: 0 };
  private cl = 0;
  private ct = 0;
  private mouse = { x: 240, y: 135, down: false, right: false };
  private keys = new Set<string>();
  private once = { nade: false, melee: false, reload: false, swap: false, pick: false, slot: -1, cycle: 0 };
  private feed: FeedItem[] = [];
  private banner: ArenaHud["banner"] = null;
  private bannerT = 0;
  private ids = 1;
  private hitMark = 0;
  private killMark = 0;
  private hurtFx = 0;
  /** the pale flash round the edge of the picture when your armour takes a blow */
  private plateFx = 0;
  private hudT = 0;
  private lastSec = 99;
  private warned = false;
  private killer: Sol | null = null;
  private tension = 0;
  private combat = 0;
  private humRate = 0;
  private sawRate = 0;
  private rain: number[] = [];
  private raf = 0;
  private last = 0;
  private abort = new AbortController();
  private ended = false;
  private shellT = 0;

  constructor(cv: HTMLCanvasElement, cb: ArenaCb) {
    this.cv = cv;
    this.cb = cb;
    this.ctx = cv.getContext("2d")!;
    initSprites();
    const [d, dg] = mk(8, 8);
    this.dark = d;
    this.dg = dg;
    const [e2, e2g] = mk(8, 8);
    this.eb = e2;
    this.ebg = e2g;
    const [gc, gg] = mk(64, 64), grd = gg.createRadialGradient(32, 32, 0, 32, 32, 32);
    grd.addColorStop(0, "rgba(255,255,255,1)");
    grd.addColorStop(0.45, "rgba(255,255,255,0.65)");
    grd.addColorStop(1, "rgba(255,255,255,0)");
    gg.fillStyle = grd;
    gg.fillRect(0, 0, 64, 64);
    this.glow = gc;
    const o = { signal: this.abort.signal };
    window.addEventListener("resize", () => this.resize(), o);
    window.addEventListener("keydown", (e) => this.onKey(e, true), o);
    window.addEventListener("keyup", (e) => this.onKey(e, false), o);
    window.addEventListener("blur", () => { this.keys.clear(); this.mouse.down = false; this.mouse.right = false; }, o);
    window.addEventListener("mousemove", (e) => this.onMouse(e), o);
    window.addEventListener("mousedown", (e) => {
      if (this.touch || (e.target as HTMLElement | null)?.tagName !== "CANVAS") return;
      this.onMouse(e);
      if (e.button === 0) this.mouse.down = true;
      if (e.button === 2) this.mouse.right = true; // (the right button holds up the hologram shield; grenades are on G)
    }, o);
    window.addEventListener("mouseup", (e) => { if (e.button === 0) this.mouse.down = false; if (e.button === 2) this.mouse.right = false; }, o);
    window.addEventListener("contextmenu", (e) => { if ((e.target as HTMLElement | null)?.tagName === "CANVAS") e.preventDefault(); }, o);
    window.addEventListener("wheel", (e) => {
      if (!this.touch && (e.target as HTMLElement | null)?.tagName === "CANVAS" && Math.abs(e.deltaY) > 4) {
        this.once.cycle += e.deltaY > 0 ? 1 : -1;
      }
    }, { ...o, passive: true });
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    this.abort.abort();
    cancelAnimationFrame(this.raf);
    audio.hush();
    for (const id of ["jet", "flame", "saber", "chainsaw"] as const) audio.loop(id, 0);
  }

  resize() {
    const iw = window.innerWidth, ih = window.innerHeight;
    const scenic = this.cfg?.map === 3 || this.cfg?.map === 2;
    let s = Math.min(Math.max(iw, ih) / (scenic ? 560 : 420), Math.min(iw, ih) / (scenic ? 315 : 236));
    s = s >= 2 ? Math.floor(s) : Math.max(1, s);
    this.scale = s;
    this.W = Math.ceil(iw / s);
    this.H = Math.ceil(ih / s);
    this.cv.width = this.W;
    this.cv.height = this.H;
    this.cv.style.width = `${this.W * s}px`;
    this.cv.style.height = `${this.H * s}px`;
    this.ctx.imageSmoothingEnabled = false;
    this.dark.width = this.W;
    this.dark.height = this.H;
    this.eb.width = this.W;
    this.eb.height = this.H;
  }

  private onKey(e: KeyboardEvent, down: boolean) {
    const c = e.code;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(c)) e.preventDefault();
    if (!down) { this.keys.delete(c); return; }
    if (e.repeat) return;
    this.keys.add(c);
    const si = SLOT_CODES.indexOf(c);
    if (si >= 0) this.once.slot = si;
    else if (c === "KeyG") this.once.nade = true;
    else if (c === "KeyF") this.once.melee = true;
    else if (c === "KeyR") this.once.reload = true;
    else if (c === "KeyQ") this.once.swap = true;
    else if (c === "BracketLeft" || c === "KeyZ") this.once.cycle -= 1;
    else if (c === "BracketRight" || c === "KeyX") this.once.cycle += 1;
    else if (c === "KeyE") this.once.pick = true;
    else if (c === "KeyN") audio.setMusic(!audio.musicOn);
  }
  private onMouse(e: MouseEvent) {
    if (this.touch) return;
    const r = this.cv.getBoundingClientRect();
    this.mouse.x = ((e.clientX - r.left) / Math.max(1, r.width)) * this.W;
    this.mouse.y = ((e.clientY - r.top) / Math.max(1, r.height)) * this.H;
  }
  /** a button on the touch screen or HUD */
  act(a: "nade" | "melee" | "reload" | "swap" | "pick") { this.once[a] = true; }
  selectSlot(idx: number) { if (idx >= 0 && idx < AW_ORDER.length) this.once.slot = idx; }
  cycleSlot(dir: number) { this.once.cycle += dir; }

  // ───────────── the match ─────────────
  start(cfg: ArenaConfig) {
    this.cfg = cfg;
    // (a copy of the arena for this match: its ground can be shot to pieces)
    const M = getMap(cfg.map);
    this.grid0 = M.grid;
    this.map = { ...M, grid: M.grid.slice(), nav: M.nav.slice(), lights: M.lights.slice(), decor: M.decor.slice() };
    this.environment = this.map.theme.decor === "jungle" ? new ForestScene(this.map) : this.map.theme.decor === "cave" ? new HollowScene(this.map) : null;
    this.resize();
    const P = paintTerrain(this.map);
    this.terr = P.terr;
    this.emis = P.emis;
    this.tg = this.terr.getContext("2d")!;
    this.base = P.base; this.bg0 = P.base.getContext("2d")!; this.ebase = P.ebase;
    this.eg = P.emis ? P.emis.getContext("2d") : null; this.eg0 = P.ebase ? P.ebase.getContext("2d") : null;
    this.scratch = mk(1, 1)[1];
    this.terrainInit();
    this.caveInit();
    this.mini = paintMini(this.map);
    this.mg = this.mini.getContext("2d")!;
    this.back = paintBackdrop(this.map.theme);
    this.stalags = this.map.decor.filter((d) => d.k === "stalag");
    this.hideShake = this.map.hides.map(() => 0); this.hint = null; this.camLead = 0;
    this.crystals = this.map.decor.filter((d) => d.k === "crystal" || d.k === "bigcrystal" || d.k === "ceilcrystal");
    this.sol = []; this.shots = []; this.nades = []; this.parts = []; this.texts = []; this.flashes = []; this.feed = [];
    this.rings = []; this.stars = []; this.hitfx = []; this.bursts = []; this.scorch = []; this.tumbles = [];
    this.corpses = []; this.slashArcs = []; this.trails = []; this.ghosts = []; this.bolts = []; this.portals = [[null, null], [null, null]];
    this.score = [0, 0]; this.phase = "count"; this.phaseT = 3.2; this.timeLeft = cfg.time * 60; this.t = 0; this.endT = 0; this.slow = 0; this.hitStop = 0;
    this.ended = false; this.warned = false; this.lastSec = 99; this.killer = null; this.banner = null;
    this.picks = this.map.picks.map((p) => ({ x: p.x, y: p.y, vx: 0, vy: 0, kind: p.kind, spot: true, t: 0, mag: 0, ammo: 0, life: 0, bob: rand() * 6 }));
    const names = NAMES.slice().sort(() => rand() - 0.5);
    for (let team = 0; team < 2; team++)
      for (let i = 0; i < cfg.size; i++) {
        const me = team === 0 && i === 0;
        // each squad can field an Adeptus Astartes tanker (always 1 on the enemy squad in 2v2+, and 1 brother-marine on yours in 3v3+ if you aren't one, or 4v4+)
        const botTank = !me && ((team === 1 && cfg.size >= 2 && i === cfg.size - 1) || (team === 0 && cfg.size >= (cfg.skin === ASTARTES ? 4 : 3) && i === cfg.size - 1));
        const skin = me ? cfg.skin : botTank ? ASTARTES : rand() < 0.2 ? TROOPER : (rand() * 5) | 0;
        const s = this.mkSol(me ? ARENA_SKINS[cfg.skin] ?? "KAMU" : skin === ASTARTES ? (team ? "KHÂRN" : "TITUS") : names.pop() ?? `BOT${team}${i}`, team, skin, me);
        this.sol.push(s);
        if (me) this.me = s;
        // (one on each side carries the portal gun: on yours it is you - unless you left it to a bot)
        s.carrier = team === 0 ? (cfg.portalMe === false && cfg.size > 1 ? i === 1 : me) : i === 0;
      }
    for (const s of this.sol) this.respawn(s, true);
    // your squad: the first is your guard, who stays with you a little ahead (in a squad of five a second one keeps behind you); the rest are hunters, who go after whatever the team has seen
    let ally = 0;
    for (const s of this.sol) if (s.bot && s.team === this.me.team) { s.bot.role = ally % 3 === 0 ? 0 : 1; s.bot.slot = ally === 0 ? 44 : -52; ally++; }
    this.intel.clear(); this.focusE = null; this.focusT = -9; this.touchSprint = false; this.touchGuard = false; this.mouse.right = false; this.meIdle = 0;
    this.rain = [];
    for (let i = 0; i < 160; i++) this.rain.push(rand() * 2000, rand() * 1200);
    this.sand = [];
    for (let i = 0; i < 170; i++) this.sand.push(rand() * 2000, rand() * 1200, 0.5 + rand(), 2 + rand() * 7);
    this.dust = [];
    for (let i = 0; i < 7; i++) this.dust.push(rand() * 1000, rand() * 700, 50 + rand() * 80, rand() * 6);
    this.spores = [];
    for (let i = 0; i < 155; i++) this.spores.push(rand() * 2400, rand() * 1400, rand() * 6, (rand() * 5) | 0);
    this.fireflies = [];
    for (let i = 0; i < 68; i++) this.fireflies.push(rand() * this.map.w * AT, rand() * this.map.h * AT, rand() * PI2, 0.7 + rand() * 1.1, (rand() * 5) | 0);
    this.butterflies = [];
    for (let i = 0; i < 38; i++) this.butterflies.push(rand() * this.map.w * AT, (16 + rand() * 64) * AT, rand() * PI2, 0.9 + rand() * 1.1, (rand() * 5) | 0);
    this.petals = [];
    for (let i = 0; i < 95; i++) this.petals.push(rand() * 2200, rand() * 1200, rand() * PI2, (rand() * 6) | 0);
    this.coolTipT = 0; this.birdT = 3;
    this.gust = 0.5; this.tumbleT = 2; this.dripT = 0.5; this.glintT = 0.15;
    this.cam.x = this.me.x;
    this.cam.y = this.me.y - (this.environment ? 64 : 30);
    this.cam.kx = this.cam.ky = 0;
    audio.unlock();
  }

  private mkSol(name: string, team: number, skin: number, me: boolean): Sol {
    const bot: Bot | null = me ? null : {
      path: [], pi: 0, pathT: 0, pgx: 0, pgy: 0, gx: 0, gy: 0, target: null, react: 0, lock: 0, err: 0, errT: 0,
      firing: false, burstT: 0, strafe: 1, strafeT: 0, hop: 0, hopT: rand() * 2, lx: 0, ly: 0, stuckT: 1, unstuck: 0, nadeCd: 3 + rand() * 5, think: rand() * 0.2, swapCd: 0,
      fav: skin === ASTARTES ? (rand() < 0.62 ? "bolter" : "chainsword") : skin === TROOPER ? "e11" : pickOne(BOT_FAVS), hideGo: false, role: 1, slot: 0, escort: false, guardT: 0, guardCd: 1 + rand() * 2, portT: 0.6 + rand() * 0.8, portAim: 0, portFire: 0, portN: 0, portLast: -99, portBan: 0, portSince: -1,
      seen: null,
    };
    const tank = skin === ASTARTES, mHp = tank ? TANK_HP : 100, mArm = tank ? TANK_ARMOR : ARMOR, mHolo = tank ? TANK_HOLO : HOLO_HP;
    return {
      id: this.ids++, name, team, skin, me, bot, x: 0, y: 0, vx: 0, vy: 0, ground: false, face: team ? -1 : 1, aim: team ? Math.PI : 0,
      hp: mHp, alive: true, respawn: 0, shield: 0, hurtT: 9,
      fuel: 1, jet: false, wasJet: false, fuelWait: 0, jetK: 0, burst: 0, sputT: 0,
      slots: AW_ORDER.map((id) => (isTankWep(id) && !tank ? null : this.slot(id))), cur: tank ? 0 : 5, prevCur: tank ? 1 : 12, nades: 2, nadeCd: 0, fireCd: 0, reload: 0, reloadMax: 1, trig: false, recoil: 0, bloom: 0, loud: 0, smokeT: 0, melee: 0, meleeCd: 0,
      swingT: 0, swingDur: 0.3, swingKind: 0, swingDir: 1, swingPlane: "vert", swingZ: 0, swingScale: 1,
      combo: 0, lastSwing: -9, swingHit: [], saberOn: 0, blade: 0, bladePrev: 0, trail: [], tip: null,
      kills: 0, deaths: 0, dmg: 0, streak: 0, multi: 0, lastKill: -9,
      walkT: 0, runK: 0, squash: 0, tilt: 0, flash: 0, flashT: 0, seed: 0.5, pump: 0,
      burn: 0, burnBy: null, burnT: 0, lastBy: null, lastByT: -9, drop: 0, rot: 0, vrot: 0, headless: false, stepT: 0, scarf: [0, 0, 0, 0, 0, 0],
      ragdoll: null, hide: null, hideT: 0, crouch: false, duck: 0, duckT: 0,
      nos: 1, sprint: false, nosK: 0, nosCd: 0, nosWait: 0, ghostT: 0, stepI: 0, skid: 0,
      holo: false, holoK: 0, holoHp: mHolo, holoCd: 0, holoHitT: 9, holoFx: 0, holoAt: 0, holoWas: false,
      maxHp: mHp, maxArmor: mArm, maxHolo: mHolo,
      armor: mArm, armorFx: 0, stun: 0, shove: 0, airT: 0, dive: false, chainRev: 0,
      zap: 0, zapImm: 0, carrier: false, pnext: 0, portCd: 0,
      launch: 0, bounces: 0, spin: 0, spinV: 0, critImm: 0, lift: 0,
      ouch: 0, joy: 0, alert: 0, dizzy: 0, mad: 0, say: "", sayT: 0, sayCd: 0, lowSaid: false,
      ctl: { mx: 0, jet: false, drop: false, fire: false, aim: team ? Math.PI : 0, nade: false, melee: false, reload: false, swap: false, pick: false, sprint: false, guard: false },
    };
  }
  private slot(id: AW): Slot { return { id, mag: AWEP[id].mag, ammo: AWEP[id].ammo }; }

  /** back in: at the team's spawn that is furthest from the enemy — with ALL 12 weapons ready! */
  private respawn(s: Sol, first = false) {
    const pts = this.map.spawns[s.team];
    let best = pts[0], bs = -1e9;
    for (const p of pts) {
      let near = 600;
      for (const e of this.sol) if (e.alive && e.team !== s.team && !first) near = Math.min(near, Math.hypot(e.x - p.x, e.y - p.y));
      let busy = 0;
      for (const o of this.sol) if (o !== s && o.alive && (o.x || o.y) && Math.abs(o.x - p.x) < 9 && Math.abs(o.y - p.y) < 14) busy++;
      const sc = near - busy * 220 + rand() * 50;
      if (sc > bs) { bs = sc; best = p; }
    }
    const tank = s.skin === ASTARTES;
    s.maxHp = tank ? TANK_HP : 100;
    s.maxArmor = tank ? TANK_ARMOR : ARMOR;
    s.maxHolo = tank ? TANK_HOLO : HOLO_HP;
    s.x = best.x; s.y = best.y;
    s.vx = s.vy = 0; s.alive = true; s.hp = s.maxHp; s.fuel = 1; s.fuelWait = 0; s.shield = first ? 0 : SHIELD; s.hurtT = 9;
    // Bolter Rifle & Chainsword belong exclusively to the Adeptus Astartes Space Marine tanker; Portal Gun to each side's carrier
    s.slots = AW_ORDER.map((id) => ((id === "portal" && !s.carrier) || (isTankWep(id) && !tank) ? null : this.slot(id)));
    const defWep: AW = tank ? "bolter" : s.skin === TROOPER ? "e11" : "rifle";
    const startId: AW = s.me ? (this.cfg?.startWep ?? defWep) : (s.bot?.fav ?? defWep);
    const startIdx = s.slots[AW_ORDER.indexOf(startId)] ? AW_ORDER.indexOf(startId) : AW_ORDER.indexOf(defWep);
    s.cur = first || !s.me ? startIdx : clamp(s.cur, 0, s.slots.length - 1);
    if (!s.slots[s.cur]) s.cur = startIdx;
    s.prevCur = tank
      ? (s.cur === AW_ORDER.indexOf("chainsword") ? AW_ORDER.indexOf("bolter") : AW_ORDER.indexOf("chainsword"))
      : (s.cur === AW_ORDER.indexOf("katana") ? AW_ORDER.indexOf("rifle") : AW_ORDER.indexOf("katana"));
    s.nades = tank ? 3 : 2; s.nadeCd = 0;
    s.fireCd = 0.28; s.reload = 0; s.recoil = 0; s.bloom = 0; s.smokeT = 0; s.melee = 0; s.burn = 0; s.rot = 0; s.vrot = 0; s.headless = false; s.lastBy = null;
    s.ragdoll = null; s.hide = null; s.hideT = 0; s.crouch = false; s.duck = 0; s.duckT = 0;
    s.nos = 1; s.sprint = false; s.nosK = 0; s.nosCd = 0; s.nosWait = 0; s.skid = 0;
    s.holo = false; s.holoK = 0; s.holoHp = s.maxHolo; s.holoCd = 0; s.holoHitT = 9; s.holoFx = 0;
    s.armor = s.maxArmor; s.armorFx = 0; s.stun = 0; s.shove = 0; s.airT = 0; s.dive = false; s.chainRev = 0;
    s.zap = 0; s.zapImm = 0; s.portCd = 0; s.launch = 0; s.bounces = 0; s.spin = 0; s.spinV = 0; s.critImm = 0; s.lift = 0;
    s.swingT = 0; s.swingPlane = "vert"; s.swingZ = 0; s.swingScale = 1; s.combo = 0; s.saberOn = 0; s.trail = []; s.tip = null; s.jet = s.wasJet = false; s.jetK = 0; s.burst = 0; s.squash = 0; s.tilt = 0;
    s.ouch = s.joy = s.alert = s.dizzy = s.mad = 0; s.sayT = 0; s.lowSaid = false;
    s.face = s.team ? -1 : 1; s.aim = s.team ? Math.PI : 0; s.ctl.aim = s.aim; s.ground = false; s.drop = 0;
    s.scarf = [s.x, s.y - 11, s.x, s.y - 11, s.x, s.y - 11];
    if (s.bot) { s.bot.path = []; s.bot.target = null; s.bot.seen = null; s.bot.pathT = 0; }
    if (!first) {
      for (let i = 0; i < 12; i++) this.part(s.x + (rand() - 0.5) * 12, s.y - rand() * 20, (rand() - 0.5) * 45, -35 - rand() * 55, 0.5, 2, TEAMS[s.team].color, -40, 2, 5);
      this.rings.push({ x: s.x, y: s.y - 9, r: 20, life: 0, max: 0.42, col: TEAMS[s.team].color });
      if (s.me) { this.sfx("ping", s.x, s.y, 0.6); this.killer = null; }
      if (rand() < 0.3) this.callout(s, "back");
    }
  }

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const rdt = clamp((now - this.last) / 1000, 0, 0.05);
    this.last = now;
    if (!this.cfg) return;
    if (!this.paused) this.update(rdt);
    this.render();
    this.hudT -= rdt;
    if (this.hudT <= 0) { this.hudT = 0.1; this.cb.hud(this.hudState()); }
  };

  /** run the game by hand (tests): dt seconds at a time */
  step(dt: number) { if (this.cfg) { this.update(dt); this.render(); } }

  private say(text: string, sub: string, color: string, dur: number) {
    this.banner = { id: this.ids++, text, sub, color };
    this.bannerT = dur;
  }
  /** a speech bubble over somebody's head */
  private callout(s: Sol, key: string) {
    if (s.sayCd > 0 || !s.alive) return;
    let n = 0;
    for (const q of this.sol) if (q.sayT > 0) n++;
    if (n >= 4) return;
    s.say = pickOne(key === "kill" && s.skin === ASTARTES ? LINES.astartes : key === "kill" && s.skin === TROOPER ? LINES.trooper : LINES[key]);
    s.sayT = 1.7;
    s.sayCd = 3.5 + rand() * 3;
  }

  private update(rdt: number) {
    if (this.hitStop > 0) { this.hitStop -= rdt; this.camera(rdt); return; }
    const dt = rdt * (this.slow > 0 ? 0.3 : 1), cfg = this.cfg!;
    this.debris = 40;
    this.slow -= rdt;
    this.t += dt;
    if (this.phase === "count") {
      this.phaseT -= rdt;
      const n = Math.ceil(this.phaseT);
      if (n !== this.lastSec && n > 0 && n <= 3) { this.lastSec = n; this.say(String(n), "BERSIAP...", "#f5c542", 0.9); audio.play("tick", 0.8); }
      if (this.phaseT <= 0) { this.phase = "live"; this.say("SERBU!", `${cfg.kills} KILL UNTUK MENANG`, "#7dff9a", 1.6); audio.play("start", 0.8); }
    } else if (this.phase === "live") {
      this.timeLeft -= dt;
      if (!this.warned && this.timeLeft <= 60 && cfg.time > 1) { this.warned = true; this.say("1 MENIT LAGI!", "Kejar skornya!", "#ffb347", 2); audio.play("alarm", 0.4); }
      if (this.timeLeft <= 0) { this.timeLeft = 0; this.finish(); }
    } else {
      this.endT += rdt;
      if (this.endT > 2.4 && !this.ended) { this.ended = true; this.cb.end(this.result()); }
    }
    this.ambient(dt);
    this.playerCtl();
    for (const s of this.sol) if (s.bot && s.alive && s.zap <= 0) this.botThink(s, dt);
    // what you can see yourself, the squad knows too
    if ((this.intelT -= dt) <= 0) {
      this.intelT = 0.15;
      const me = this.me;
      if (me.alive) for (const e of this.sol) if (e.alive && e.team !== me.team && !e.hide && Math.abs(e.x - me.x) < 330 && Math.abs(e.y - me.y) < 200 && this.clear(me.x, me.y - 10, e.x, e.y - 10)) this.spot(e);
    }
    for (const s of this.sol) this.tickSol(s, dt);
    this.stepRagdolls(dt);
    this.updPortals(dt);
    this.updCave(dt, rdt);
    this.updRocks(dt);
    this.updBats(dt);
    this.updShots(dt);
    this.updNades(dt);
    this.updPicks(dt);
    this.updParts(dt);
    for (let i = this.texts.length - 1; i >= 0; i--) { const q = this.texts[i]; q.life -= rdt; q.y += q.vy * rdt; if (q.life <= 0) this.texts.splice(i, 1); }
    for (let i = this.flashes.length - 1; i >= 0; i--) if ((this.flashes[i].life -= rdt) <= 0) this.flashes.splice(i, 1);
    for (let i = this.rings.length - 1; i >= 0; i--) if ((this.rings[i].life += rdt) >= this.rings[i].max) this.rings.splice(i, 1);
    for (let i = this.stars.length - 1; i >= 0; i--) if ((this.stars[i].life -= rdt) <= 0) this.stars.splice(i, 1);
    for (let i = this.hitfx.length - 1; i >= 0; i--) if ((this.hitfx[i].life += rdt) >= this.hitfx[i].max) this.hitfx.splice(i, 1);
    for (let i = this.bursts.length - 1; i >= 0; i--) if ((this.bursts[i].life += rdt) >= this.bursts[i].max) this.bursts.splice(i, 1);
    for (let i = this.scorch.length - 1; i >= 0; i--) if ((this.scorch[i].life -= rdt) <= 0) this.scorch.splice(i, 1);
    for (let i = this.slashArcs.length - 1; i >= 0; i--) if ((this.slashArcs[i].life += dt) >= this.slashArcs[i].max) this.slashArcs.splice(i, 1);
    for (let i = this.trails.length - 1; i >= 0; i--) if ((this.trails[i].life += dt) >= this.trails[i].max) this.trails.splice(i, 1);
    for (let i = this.ghosts.length - 1; i >= 0; i--) if ((this.ghosts[i].life += dt) >= this.ghosts[i].max) this.ghosts.splice(i, 1);
    for (let i = this.bolts.length - 1; i >= 0; i--) if ((this.bolts[i].life += dt) >= this.bolts[i].max) this.bolts.splice(i, 1);
    for (let i = this.crits.length - 1; i >= 0; i--) if ((this.crits[i].life += rdt) >= this.crits[i].max) this.crits.splice(i, 1);
    for (let i = 0; i < this.hideShake.length; i++) if (this.hideShake[i] > 0) this.hideShake[i] -= rdt;
    this.feed = this.feed.filter((f) => this.t - f.t < 7);
    if ((this.bannerT -= rdt) <= 0) this.banner = null;
    this.hitMark -= rdt; this.killMark -= rdt; this.hurtFx = Math.max(0, this.hurtFx - rdt * 1.4); this.plateFx = Math.max(0, this.plateFx - rdt * 2.4); this.shellT -= rdt;
    if (this.map.theme.rain) for (let i = 0; i < this.rain.length; i += 2) { this.rain[i] -= 70 * rdt; this.rain[i + 1] += 430 * rdt; }
    this.camera(rdt);
    this.sound(rdt);
  }

  /** the weather of each arena: a sandstorm with tumbleweeds, spores drifting in the cave, water dripping */
  private ambient(dt: number) {
    this.environment?.update(dt);
    const T = this.map.theme, W = this.W, H = this.H;
    if (T.weather === "sand") {
      const t = this.t;
      this.gust = clamp(0.45 + 0.28 * Math.sin(t * 0.23) + 0.2 * Math.sin(t * 0.61 + 2) + 0.1 * Math.sin(t * 1.7), 0, 1);
      const sp = 180 + this.gust * 320;
      for (let i = 0; i < this.sand.length; i += 4) { this.sand[i] += sp * this.sand[i + 2] * dt; this.sand[i + 1] += Math.sin(t * 2 + i) * 9 * dt; }
      for (let i = 0; i < this.dust.length; i += 4) this.dust[i] += (40 + this.gust * 120) * dt;
      if ((this.tumbleT -= dt) <= 0 && this.tumbles.length < 3) {
        this.tumbleT = 3 + rand() * 6;
        const x = this.cl - 16, y0 = this.ct + 20 + rand() * H * 0.5;
        for (let y = y0; y < y0 + 260; y += 4) if (solidPx(this.map, x + 8, y)) { if (y > y0 + 4) this.tumbles.push({ x, y: y - 7, vx: 40 + this.gust * 60, vy: 0, rot: 0, life: 0, s: 0.8 + rand() * 0.5 }); break; }
      }
      for (let i = this.tumbles.length - 1; i >= 0; i--) {
        const q = this.tumbles[i];
        q.life += dt;
        q.vx += (50 + this.gust * 120 - q.vx) * Math.min(1, dt * 1.2);
        q.vy = Math.min(300, q.vy + 500 * dt);
        const nx = q.x + q.vx * dt;
        if (solidPx(this.map, nx + 6, q.y)) { q.vy = -150 - rand() * 60; q.vx *= 0.5; } else q.x = nx;
        const ny = q.y + q.vy * dt;
        if (solidPx(this.map, q.x, ny + 6)) q.vy = q.vy > 90 ? -q.vy * 0.45 : -50 - rand() * 90 * this.gust;
        else q.y = ny;
        q.rot += (q.vx * dt) / 7;
        if (q.x > this.cl + W + 40 || q.life > 30 || q.y > this.map.h * AT) this.tumbles.splice(i, 1);
      }
    } else if (T.weather === "spores") {
      for (let i = 0; i < this.spores.length; i += 4) { this.spores[i] += Math.sin(this.t * 0.55 + this.spores[i + 2]) * 8 * dt; this.spores[i + 1] -= (3.5 + (i % 7)) * dt; }
      // glowing crystal fireflies weaving gracefully through the cathedral cavern
      const mw = this.map.w * AT, mh = this.map.h * AT;
      for (let i = 0; i < this.fireflies.length; i += 5) {
        const ph = this.fireflies[i + 2], sp = this.fireflies[i + 3];
        this.fireflies[i] = (this.fireflies[i] + Math.cos(this.t * sp + ph) * 14 * dt + mw) % mw;
        this.fireflies[i + 1] = (this.fireflies[i + 1] + Math.sin(this.t * sp * 0.8 + ph * 1.7) * 10 * dt + mh) % mh;
      }
      if ((this.dripT -= dt) <= 0 && this.stalags.length) {
        this.dripT = 0.16 + rand() * 0.36;
        const d = this.stalags[(rand() * this.stalags.length) | 0];
        if (Math.abs(d.x - this.cam.x) < W * 0.72 && Math.abs(d.y - this.cam.y) < H * 0.72) this.part(d.x, d.y + 8, 0, 12, 4, 1, "#9ee8ff", 400, 0, 8);
      }
      // periodic crystal sparkle glints twinkling on nearby crystal clusters
      if ((this.glintT -= dt) <= 0 && this.crystals.length) {
        this.glintT = 0.12 + rand() * 0.22;
        const d = this.crystals[(rand() * this.crystals.length) | 0];
        if (Math.abs(d.x - this.cam.x) < W * 0.65 && Math.abs(d.y - this.cam.y) < H * 0.65) {
          const gy = d.k === "ceilcrystal" ? d.y + 4 + rand() * 10 : d.y - 4 - rand() * (d.k === "bigcrystal" ? 18 : 10);
          this.stars.push({ x: d.x + (rand() - 0.5) * 12, y: gy, life: 0.09, col: pickOne(["#ffffff", "#b8fff8", "#f4d4ff", "#ffeaa0"]) });
        }
      }
    } else if (T.weather === "jungle") {
      // Living Anthem Bastion rainforest: fluttering morpho/monarch butterflies, drifting leaves & flower petals, golden pollen & tropical birds!
      if (this.coolTipT > 0) this.coolTipT -= dt;
      const mw = this.map.w * AT;
      for (let i = 0; i < this.butterflies.length; i += 5) {
        const ph = this.butterflies[i + 2], sp = this.butterflies[i + 3];
        this.butterflies[i] = (this.butterflies[i] + Math.cos(this.t * sp * 0.85 + ph) * 22 * dt + 6 * dt + mw) % mw;
        this.butterflies[i + 1] = clamp(this.butterflies[i + 1] + Math.sin(this.t * sp * 1.4 + ph * 1.6) * 14 * dt, 70, 74 * AT);
      }
      for (let i = 0; i < this.petals.length; i += 4) {
        const ph = this.petals[i + 2], pollen = this.petals[i + 3] >= 4;
        this.petals[i] += (pollen ? Math.sin(this.t * 0.8 + ph) * 9 : 14 + Math.sin(this.t * 1.6 + ph) * 16) * dt;
        this.petals[i + 1] += (pollen ? -4.5 + Math.cos(this.t * 0.9 + ph) * 4 : 15 + (i % 5) * 2.5) * dt;
      }
      // occasional colorful tropical macaw pairs soaring across the sunlit Bastion canopy!
      if ((this.birdT -= dt) <= 0 && this.bats.length < 18) {
        this.birdT = 5.5 + rand() * 6;
        const dir = rand() < 0.5 ? 1 : -1, bx = this.cl + (dir > 0 ? -12 : W + 12), by = clamp(this.ct + 18 + rand() * 75, 40, 48 * AT);
        for (let k = 0; k < 2 + ((rand() * 2) | 0); k++) {
          this.bats.push({ x: bx - dir * k * 9, y: by + k * 5, a: dir > 0 ? -0.06 : Math.PI + 0.06, sp: 88 + rand() * 32, t: rand() * 6, life: 7 });
        }
      }
    }
  }

  private equipSlot(s: Sol, idx: number, playSfx = true) {
    if (idx < 0 || idx >= s.slots.length || !s.slots[idx] || idx === s.cur) return;
    s.prevCur = s.cur;
    s.cur = idx;
    s.reload = 0;
    s.swingT = 0;
    s.fireCd = Math.max(s.fireCd, 0.12);
    if (playSfx && s.me) {
      const id = s.slots[idx]!.id;
      this.sfx(
        id === "chainsword" ? "chainrev" : id === "bolter" ? "rack" : id === "katana" ? "slash" : id === "saber" ? "saberon" : id === "axe" ? "axeswing" : id === "portal" ? "portalopen" : "rack",
        s.x, s.y, id === "chainsword" ? 0.68 : 0.48, id === "katana" ? 1.35 : id === "bolter" ? 0.74 : 1,
      );
    }
  }

  private playerCtl() {
    const s = this.me, c = s.ctl, k = this.keys, o = this.once;
    c.nade = o.nade; c.melee = o.melee; c.reload = o.reload; c.swap = o.swap; c.pick = o.pick;
    if (s.alive) {
      if (o.slot >= 0) this.equipSlot(s, o.slot);
      else if (o.cycle !== 0) {
        const len = s.slots.length;
        // (on to the next weapon they carry: the place of the portal gun is empty for all but one on each side)
        let next = s.cur;
        for (let i = 0; i < len; i++) { next = ((next + Math.sign(o.cycle)) % len + len) % len; if (s.slots[next]) break; }
        this.equipSlot(s, next);
      }
    }
    this.once = { nade: false, melee: false, reload: false, swap: false, pick: false, slot: -1, cycle: 0 };
    let mx = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0);
    let jet = k.has("KeyW") || k.has("ArrowUp") || k.has("Space"), drop = k.has("KeyS") || k.has("ArrowDown"), fire = this.mouse.down;
    // (where the mouse points in the world: through the camera's zoom and roll)
    const mw = this.toWorld(this.mouse.x, this.mouse.y);
    let aim = Math.atan2(mw[1] - (s.y - 5), mw[0] - s.x);
    if (this.joyL.on) {
      mx = Math.abs(this.joyL.x) > 0.22 ? Math.sign(this.joyL.x) * Math.min(1, Math.abs(this.joyL.x) * 1.4) : 0;
      jet = this.joyL.y < -0.42;
      drop = this.joyL.y > 0.6;
    }
    if (this.touch) {
      const m = Math.hypot(this.joyR.x, this.joyR.y);
      if (this.joyR.on && m > 0.18) { aim = Math.atan2(this.joyR.y, this.joyR.x); fire = m > 0.62; }
      else { aim = s.aim; fire = false; }
    }
    c.mx = mx; c.jet = jet; c.drop = drop; c.fire = fire; c.aim = aim;
    c.sprint = k.has("ShiftLeft") || k.has("ShiftRight") || this.touchSprint;
    c.guard = this.mouse.right || k.has("KeyC") || this.touchGuard;
    this.meIdle = c.mx || c.jet || c.fire ? 0 : this.meIdle + 1 / 60;
  }

  // ───────────── soldiers ─────────────
  private hit(s: Sol, x: number, y: number, down: boolean, hh = s.crouch ? CH : HH): boolean {
    const m = this.map, x0 = Math.floor((x - HW) / AT), x1 = Math.floor((x + HW - 0.01) / AT), y0 = Math.floor((y - hh) / AT), y1 = Math.floor((y - 0.01) / AT);
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (solidT(tileAt(m, tx, ty))) return true;
    if (down && s.drop <= 0) {
      const r = Math.floor((y - 0.01) / AT);
      if (y - r * AT <= 1.01) for (let tx = x0; tx <= x1; tx++) if (tileAt(m, tx, r) === PLAT) return true;
    }
    return false;
  }
  private onPlat(s: Sol) { return tileAt(this.map, Math.floor(s.x / AT), Math.floor((s.y + 1) / AT)) === PLAT; }
  private blockedAhead(s: Sol, dir: number) { return this.hit(s, s.x + dir * 5, s.y - 9, false); }
  private dustCol() {
    return this.map.theme.decor === "desert" ? pickOne(["#e8c08a", "#d8a868", "#f2d4a0"])
      : this.map.theme.decor === "jungle" ? pickOne(["#7e583b", "#4cb858", "#96e86c"])
        : this.map.theme.decor === "cave" ? pickOne(["#637e83", "#435d69", "#7a9e99"]) : pickOne(["#9a96a0", "#7a7680"]);
  }

  private move(s: Sol, dx: number, dy: number) {
    const was = s.ground;
    let vault = false;
    let n = Math.ceil(Math.abs(dx));
    const sx = n ? dx / n : 0;
    for (let i = 0; i < n; i++) {
      const nx = s.x + sx;
      if (!this.hit(s, nx, s.y, false)) { s.x = nx; continue; }
      // a step, a slope, the lip of a ledge: walk up it - and in the air, slip onto a ledge that is already nearly underfoot
      const fly = s.launch > 0 && Math.abs(s.vx) > 190;
      let up = 0;
      for (let k = 1, lim = was || s.ground ? 9 : 5; k <= lim; k++) if (!this.hit(s, nx, s.y - k, false)) { up = k; break; }
      if (up) { s.x = nx; s.y -= up; continue; }
      // (sent flying by a critical hit: they do not duck or vault - they hit it)
      if (fly) { this.launchSlam(s, 1); break; }
      // a low gap - a rat-tunnel, the underside of a ledge: duck into it
      if (!s.crouch) {
        let fit = -1;
        for (let k = 0; k <= 5; k++) if (!this.hit(s, nx, s.y - k, false, CH)) { fit = k; break; }
        if (fit >= 0) { s.crouch = true; s.duckT = 0.25; s.x = nx; s.y -= fit; continue; }
      }
      // a ledge up to two tiles high: vault it with a little hop (in the air, the steps above carry the feet over its lip)
      if ((was || s.ground) && !s.crouch && !this.hit(s, nx, s.y - 17, false) && !this.hit(s, s.x, s.y - 17, false)) { vault = true; break; }
      // (thrown against it by a blow: that hurts)
      if (s.stun > 0.1 && Math.abs(s.vx) > 150) this.wallSlam(s);
      s.vx = 0;
      break;
    }
    n = Math.ceil(Math.abs(dy));
    const sy = n ? dy / n : 0;
    s.ground = false;
    for (let i = 0; i < n; i++) {
      const ny = s.y + sy;
      if (!this.hit(s, s.x, ny, sy > 0)) { s.y = ny; continue; }
      if (s.launch > 0 && Math.abs(s.vy) > 200) { this.launchSlam(s, 2); break; }
      if (sy > 0) {
        s.ground = true;
        if (!was && s.airT > 0.09 && s.vy > 110) this.touchdown(s, s.vy, s.dive);
        s.dive = false;
        s.airT = 0;
      }
      s.vy = 0;
      break;
    }
    if (!s.ground && s.vy >= 0) {
      if (this.hit(s, s.x, s.y + 1, true)) {
        if (!was && s.airT > 0.09 && s.vy > 110) this.touchdown(s, s.vy, s.dive);
        s.ground = true; s.dive = false; s.airT = 0;
      } else if (was && !s.jet) for (let k = 1; k <= 8; k++) if (this.hit(s, s.x, s.y + k + 1, true)) { s.y += k; s.ground = true; break; }
    }
    if (vault && s.ground) { s.vy = -178; s.ground = false; }
  }

  /**
   * Three-tier dynamic landing feedback: crisp boot-plant on soft hops, springy dust-wave compression on medium drops,
   * and an earth-shaking Superhero / Adeptus Astartes Meteor Ground-Slam on high falls or [S] mid-air power-dives!
   */
  private touchdown(s: Sol, imp: number, wasDive: boolean) {
    const tank = s.skin === ASTARTES, focus = s === this.focus(), x = s.x, y = s.y;
    const slam = (wasDive && imp > 240) || imp >= (tank ? 285 : 355);
    const med = !slam && imp >= (tank ? 185 : 225);
    if (slam) {
      const pwr = clamp((imp - 220) / 280 + (wasDive ? 0.35 : 0), 0.45, 1.35);
      s.squash = tank ? 0.24 : 0.19;
      // wide twin rolling shockwave dust curtains + bouncing rock/crystal chips
      const dn = Math.round((tank ? 18 : 11) * pwr);
      for (let k = 0; k < dn; k++) {
        const sd = k % 2 ? 1 : -1, sp = (75 + rand() * 145) * pwr;
        this.part(x + sd * (2 + rand() * 5), y - 1, sd * sp, -12 - rand() * 52 * pwr, 0.48 + rand() * 0.36, 2 + ((rand() * 2) | 0), this.dustCol(), 55, 2.6, 1);
      }
      const isCave = this.map.theme.decor === "cave", isJungle = this.map.theme.decor === "jungle";
      for (let k = 0; k < (tank ? 12 : 6); k++) {
        const sd = k % 2 ? 1 : -1, gem = isCave && k % 3 === 0, leaf = isJungle && k % 2 === 0;
        this.part(
          x + (rand() - 0.5) * 10, y - 2, sd * (45 + rand() * 135) * pwr, -55 - rand() * 115 * pwr, 0.65 + rand() * 0.45, 1 + (rand() < 0.45 ? 1 : 0),
          gem ? pickOne(["#5ff0e0", "#d57dff", "#ffe07a"]) : leaf ? pickOne(["#28b850", "#96f86c", "#ff68a8", "#ffe252"]) : this.map.theme.rock[1],
          leaf ? 220 : 540, leaf ? 1.5 : 0.6, gem ? 5 : 6,
        );
      }
      if (tank) this.sparkBurst(x, y - 2, Math.PI / 2, wasDive ? 14 : 8, wasDive ? BOLTC : ARMC, pwr);
      this.rings.push({ x, y: y - 2, r: (tank ? 34 : 20) * pwr, life: 0, max: tank ? 0.32 : 0.24, col: tank ? (wasDive ? "#ffd24a" : "#9ec8ff") : "#e8e2d8" });
      if (tank) {
        this.rings.push({ x, y: y - 2, r: 18 * pwr, life: 0, max: 0.18, col: "#ffffff" });
        this.flashes.push({ x, y: y - 3, r: (wasDive ? 64 : 38) * pwr, life: 0.14, max: 0.14, col: wasDive ? "#ffb03a" : "#8fc4ff" });
      }
      // spiderweb cracks etched permanently into the stone under heavy boots!
      if (solidPx(this.map, x, y + 2)) this.crack(x, y + 2, tank ? (wasDive ? 6 : 4) : 2, tank ? 11 : 6);
      this.sway = Math.max(this.sway, tank ? 0.55 * pwr : 0.22);
      this.sfx(tank || wasDive ? "slamland" : "thunk", x, y, clamp((s.me ? 0.85 : 0.55) * pwr, 0.4, 1.1), tank ? 0.92 : 0.72);
      if (focus) {
        this.cam.ky += (tank ? 6.2 : 4.2) * pwr;
        this.cam.shake = Math.max(this.cam.shake, (tank ? 6.4 : 3.4) * pwr);
        this.zoomKick = Math.min(0.28, this.zoomKick + (tank ? 0.075 : 0.035) * pwr);
        if (s.me && (wasDive || tank)) this.hitStop = Math.max(this.hitStop, wasDive && tank ? 0.046 : 0.024);
      }
      // Adeptus Astartes Ceramite Shockwave: blasts nearby enemies skyward, tosses ragdolls & shakes loose stalactites!
      if (tank && this.phase === "live" && (wasDive || imp >= 325)) {
        const rad = wasDive ? 62 : 44, maxD = wasDive ? 56 : 30;
        if (wasDive && s.me) this.texts.push({ x, y: y - 30, text: "METEOR SLAM!", col: "#ffd75e", life: 1.0, vy: -16, big: 2 });
        this.pushRagdolls(x, y, rad * 1.15, 310 * pwr, true);
        if (wasDive) {
          this.blame = s;
          this.blastTerrain(x, y + 3, 22, 68);
          if (this.map.theme.decor === "cave") {
            for (const d of this.stalags) if (Math.abs(d.x - x) < 58 && d.y < y && d.y > y - 160 && rand() < 0.55) this.breakDecor(d, 0.12 + rand() * 0.3);
          }
        }
        for (const e of this.sol) {
          if (!e.alive || e.team === s.team || e.shield > 0) continue;
          const d = Math.hypot(e.x - x, e.y - 8 - y);
          if (d > rad || !this.clear(x, y - 6, e.x, e.y - 9)) continue;
          const f = 1 - d / rad, dir = e.x >= x ? 1 : -1;
          e.vy = Math.min(e.vy, -(150 + 140 * f));
          this.hurt(e, maxD * (0.35 + 0.65 * f), s, "melee", Math.atan2(-0.65, dir), (160 + 150 * f) * pwr, false, wasDive && f > 0.62);
        }
      }
    } else if (med) {
      s.squash = tank ? 0.16 : 0.13;
      for (let k = 0; k < (tank ? 9 : 6); k++) {
        const sd = k % 2 ? 1 : -1;
        this.part(x + sd * (2 + rand() * 3), y - 1, sd * (45 + rand() * 65), -8 - rand() * 28, 0.36 + rand() * 0.2, 2, this.dustCol(), 60, 3, 1);
      }
      this.rings.push({ x, y: y - 1, r: tank ? 15 : 10, life: 0, max: 0.18, col: tank ? "#cfe2ff" : "rgba(255,255,255,0.65)" });
      this.sfx(tank ? "heavystep" : "thunk", x, y, s.me ? (tank ? 0.65 : 0.34) : 0.22, tank ? 0.78 : 0.92);
      if (focus) { this.cam.ky += tank ? 3.2 : 2.1; this.cam.shake = Math.max(this.cam.shake, tank ? 2.1 : 1.1); }
    } else {
      // crisp soft boot-plant
      s.squash = tank ? 0.1 : 0.075;
      for (const sd of [-1, 1]) this.part(x + sd * 3, y - 1, sd * (24 + rand() * 28), -5 - rand() * 14, 0.26, 1 + (tank ? 1 : 0), this.dustCol(), 55, 3, 1);
      if (s.me) this.sfx(tank ? "heavystep" : "step", x, y, tank ? 0.42 : 0.24, tank ? 0.92 : 0.85);
      if (focus) this.cam.ky += tank ? 1.5 : 0.9;
    }
  }

  private tickSol(s: Sol, dt: number) {
    if (!s.alive) { this.ragdoll(s, dt); return; }
    const c = s.ctl, frozen = this.phase !== "live" || s.zap > 0 || s.launch > 0; // (stunned by a tesla bolt, or sent flying by a critical hit: nothing answers)
    s.fireCd -= dt; s.recoil = Math.max(0, s.recoil - dt * 7); s.bloom = Math.max(0, s.bloom - dt * 2.2); s.loud -= dt;
    s.meleeCd -= dt; s.flash -= dt; s.flashT -= dt; s.shield -= dt; s.hurtT += dt; s.nadeCd -= dt; s.drop = c.drop ? 0.2 : Math.max(0, s.drop - dt);
    s.ouch -= dt; s.joy -= dt; s.alert -= dt; s.dizzy -= dt; s.mad -= dt; s.sayT -= dt; s.sayCd -= dt;
    s.burst = Math.max(0, s.burst - dt); s.squash = Math.max(0, s.squash - dt); s.pump = Math.max(0, s.pump - dt);
    s.tilt *= Math.exp(-dt * 8);
    if (s.zap <= 0) { s.aim = c.aim; s.face = Math.cos(s.aim) >= 0 ? 1 : -1; }
    const tank = s.skin === ASTARTES;
    if (s.hurtT > 5 && s.hp < s.maxHp) s.hp = Math.min(s.maxHp, s.hp + (tank ? 18 : 14) * dt);
    // armour: left alone for a while, its plates lock back into place (Astartes ceramite seals faster & tougher)
    if (s.armor < s.maxArmor) {
      if (s.hurtT > ARMOR_WAIT) { s.armor = Math.min(s.maxArmor, s.armor + (tank ? TANK_ARMOR_REGEN : ARMOR_REGEN) * dt); if (s.armor >= s.maxArmor) this.armorUp(s); }
      else if (s.armor <= 0 && rand() < dt * 3.5) this.part(s.x + (rand() - 0.5) * 8, s.y - 5 - rand() * 9, (rand() - 0.5) * 70, -30 - rand() * 50, 0.18 + rand() * 0.16, 1, pickOne(ARMC), 320, 1, 9);
    }
    s.stun = Math.max(0, s.stun - dt); s.shove *= Math.exp(-dt * 10); s.armorFx = Math.max(0, s.armorFx - dt * 5);
    // stunned by lightning: it crackles over them until it wears off - and for a moment after that, another charge cannot take hold
    // sent flying by a critical hit: they tumble through the air trailing after-images and smoke, until they hit something or it wears off
    if (s.critImm > 0) s.critImm -= dt;
    if (s.lift > 0) s.lift -= dt;
    if (s.launch > 0) {
      s.launch -= dt; s.spin += s.spinV * dt;
      if ((s.ghostT -= dt) <= 0) { s.ghostT = 0.035; this.ghosts.push({ x: s.x, y: s.y, face: s.face, team: s.team, skin: s.skin, col: "#ffe9a0", life: 0, max: 0.24 }); }
      if (rand() < dt * 45) this.part(s.x, s.y - 9, -s.vx * 0.1 + (rand() - 0.5) * 30, -s.vy * 0.1 + (rand() - 0.5) * 30, 0.3 + rand() * 0.25, 2 + ((rand() * 2) | 0), pickOne(SMOKE), -20, 2, 1);
      // (it wears off in the air: they tumble out of it, most of the speed gone - nobody coasts on across the whole cave)
      if (s.launch <= 0) { s.stun = Math.max(s.stun, 0.22); s.vx *= 0.45; if (s.vy < 0) s.vy *= 0.5; }
    } else if (s.spin) {
      // (back on their feet: the tumble unwinds)
      s.spin = angDiff(0, s.spin) * Math.exp(-dt * 16);
      if (Math.abs(s.spin) < 0.03) s.spin = 0;
    }
    if (s.zapImm > 0) s.zapImm -= dt;
    if (s.zap > 0) {
      s.zap -= dt;
      if (rand() < dt * 22) this.part(s.x + (rand() - 0.5) * 12, s.y - 2 - rand() * 17, (rand() - 0.5) * 90, -20 - rand() * 60, 0.14 + rand() * 0.14, 1, pickOne(ELC), 300, 1, 9);
    }
    if (s.hp < 30 && !s.lowSaid) { s.lowSaid = true; if (rand() < 0.6) this.callout(s, "low"); }
    if (s.hp > 60) s.lowSaid = false;
    if (s.burn > 0) {
      s.burn -= dt;
      if ((s.burnT -= dt) <= 0) { s.burnT = 0.25; this.hurt(s, 2, s.burnBy, "flame", -Math.PI / 2, 0, false); }
      if (rand() < dt * 30) this.part(s.x + (rand() - 0.5) * 8, s.y - rand() * 17, (rand() - 0.5) * 20, -30 - rand() * 30, 0.35, 3, pickOne(FIRE), -60, 1, 5);
      if (!s.alive) return;
    }
    // tucked in behind cover: catching your breath - and any step, shot or throw brings you back out
    if (s.hide) {
      s.hideT += dt;
      s.x += (s.hide.x - s.x) * Math.min(1, dt * 14);
      if (s.hurtT > 1.2 && s.hp < s.maxHp) s.hp = Math.min(s.maxHp, s.hp + 18 * dt);
      if (s.hurtT > 1.2 && s.armor < s.maxArmor) { s.armor = Math.min(s.maxArmor, s.armor + (tank ? 45 : 30) * dt); if (s.armor >= s.maxArmor) this.armorUp(s); }
      if (!frozen && (c.mx || c.jet || c.fire || c.nade || c.melee)) this.unhide(s);
    }
    // ducking: S on solid ground - and by itself in a rat-tunnel, for as long as there is no room to stand up
    if (s.hide || (!frozen && c.drop && s.ground && !this.onPlat(s))) { s.crouch = true; s.duckT = 0.12; }
    else if (s.crouch && (s.duckT -= dt) <= 0 && !this.hit(s, s.x, s.y, false, HH)) s.crouch = false;
    s.duck += ((s.crouch ? 1 : 0) - s.duck) * Math.min(1, dt * 20);
    // the hologram shield (right mouse button): up for as long as it is held and has energy; left alone it recharges; broken, it stays down for five seconds
    s.holoHitT += dt; s.holoFx = Math.max(0, s.holoFx - dt * 4.5);
    if (s.holoCd > 0) {
      if ((s.holoCd -= dt) <= 0) {
        s.holoCd = 0; s.holoHp = s.maxHolo;
        if (s.me) { this.texts.push({ x: s.x, y: s.y - 30, text: "PERISAI SIAP", col: HOLOC[s.team].col, life: 0.9, vy: -16 }); audio.play("holoon", 0.35, { pitch: 1.5 }); }
      }
    } else if (!s.holo && s.holoHp < s.maxHolo && s.holoHitT > HOLO_WAIT) s.holoHp = Math.min(s.maxHolo, s.holoHp + (tank ? HOLO_REGEN * 1.25 : HOLO_REGEN) * dt);
    const holoWant = !frozen && !s.hide && c.guard && s.holoCd <= 0 && s.holoHp > 0;
    if (holoWant && !s.holo) { s.holo = true; s.holoFx = 0.5; s.holoAt = 0; s.swingT = 0; this.sfx("holoon", s.x, s.y, s.me ? 0.6 : 0.35); }
    else if (!holoWant && s.holo) { s.holo = false; s.fireCd = Math.max(s.fireCd, 0.14); this.sfx("holooff", s.x, s.y, s.me ? 0.5 : 0.3); }
    // (asked for while it is still broken: a click, and how long there is left to wait)
    if (s.me && c.guard && !s.holoWas && s.holoCd > 0) { audio.play("click", 0.5); this.texts.push({ x: s.x, y: s.y - 30, text: `PERISAI ${Math.ceil(s.holoCd)}S`, col: "#ff6b7a", life: 0.7, vy: -14 }); }
    s.holoWas = c.guard;
    s.holoK += ((s.holo ? 1 : 0) - s.holoK) * Math.min(1, dt * 16);
    // walking and flying: quick off the mark, quicker still to turn round, and it stops on the spot
    const mx = frozen || s.hide ? 0 : c.mx, want = !frozen && !s.hide && c.jet;
    // SHIFT: a sprint on NOS - a kick in the back as it lights, then blue fire for as long as the tank lasts (left alone, it refills)
    const nosWant = !frozen && !s.hide && !s.crouch && !s.holo && s.stun < 0.12 && c.sprint && (mx !== 0 || want);
    s.nosCd -= dt;
    if (nosWant && !s.sprint && s.nos > 0.18) { s.sprint = true; if (s.nosCd <= 0) this.nosKick(s, mx); }
    else if (s.sprint && (!nosWant || s.nos <= 0)) s.sprint = false;
    if (s.sprint) { s.nos = Math.max(0, s.nos - (s.ground ? 0.2 : 0.4) * dt); s.nosWait = 0.7; this.nosFx(s, dt); }
    else if ((s.nosWait -= dt) <= 0) s.nos = Math.min(1, s.nos + (s.ground ? 0.36 : 0.2) * dt);
    s.nosK += ((s.sprint ? 1 : 0) - s.nosK) * Math.min(1, dt * 12);
    const sp = (!s.ground ? AIRSPD * (tank ? 1.04 : 1) : s.crouch ? CRAWL : WALK * (tank ? 0.96 : 1)) * (s.sprint ? SPRINT : 1) * (s.holo ? 0.62 : 1), turn = mx !== 0 && s.vx * mx < 0;
    // responsive air vectoring: crisp mid-air directional acceleration + sharper turn-around so flying feels effortless & athletic
    const rate = s.ground ? (mx ? (turn ? 2600 : s.sprint ? 1950 : 1520) : 2050) : mx ? (turn ? 1480 : s.sprint ? 1320 : 960) : 170;
    s.skid = s.ground && Math.abs(s.vx) > 70 && (turn || (!mx && Math.abs(s.vx) > 110)) ? Math.min(1, s.skid + dt * 10) : Math.max(0, s.skid - dt * 6);
    if (s.skid > 0.3 && rand() < dt * 55) this.part(s.x + Math.sign(s.vx) * 4, s.y - 1, s.vx * 0.35 + (rand() - 0.5) * 20, -18 - rand() * 26, 0.3 + rand() * 0.15, 2, this.dustCol(), 60, 3, 1);
    const grip = s.launch > 0 ? (s.ground ? 0.1 : 0) : s.stun > 0 ? (mx || !s.ground ? 1 - 0.75 * clamp(s.stun / 0.25, 0, 1) : 0.21) : 1;
    s.vx += clamp(mx * sp - s.vx, -rate * grip * dt, rate * grip * dt);
    if (!s.ground) s.airT += dt; else { s.airT = 0; s.dive = false; }
    s.jet = false;
    if (want && s.fuel > 0.01 && s.fuelWait <= 0) {
      s.jet = true; s.dive = false;
      if (!s.wasJet) this.ignite(s);
      // extra retro-rocket braking authority when catching a fall -> instant, buttery-smooth hover cushions!
      const brake = s.vy > 70 ? 1 + clamp(s.vy / 420, 0, 0.42) : 1;
      let thrust = JET * (tank ? 1.06 : 1) * (s.sprint ? 1.32 : 1) * brake;
      if (s.fuel < 0.14) {
        thrust *= 0.58 + 0.42 * Math.abs(Math.sin(this.t * 31 + s.id));
        if ((s.sputT -= dt) <= 0) { s.sputT = 0.12 + rand() * 0.2; this.sparks(s.x - s.face * 8, s.y, 3, ["#ffd23a", "#ff7a2a"]); if (s.me || rand() < 0.3) this.sfx("sputter", s.x, s.y, s.me ? 0.55 : 0.3); }
      }
      s.vy -= thrust * dt;
      s.fuel = Math.max(0, s.fuel - (tank ? 0.34 : 0.37) * dt);
      if (s.fuel <= 0.01) s.fuelWait = 0.48;
      this.jetFx(s, dt);
    } else {
      if (s.fuelWait > 0) s.fuelWait -= dt;
      s.fuel = Math.min(1, s.fuel + (s.ground ? 0.96 : 0.17) * dt);
    }
    // mid-air [S] power-dive (Meteor Ground-Slam for Astartes!): plummet like a comet onto whoever stands below
    const wantDive = !frozen && !s.ground && !s.jet && c.drop && s.airT > 0.16 && s.launch <= 0 && this.groundBelow(s.x, s.y, 24) < 0;
    if (wantDive) {
      if (!s.dive && tank && s.me) this.sfx("jumpboost", s.x, s.y, 0.65, 1.3);
      s.dive = true;
      s.vy += (tank ? 1150 : 760) * dt;
      if (tank) {
        if (rand() < dt * 65) this.part(s.x + (rand() - 0.5) * 10, s.y - 12, (rand() - 0.5) * 40, -80 - rand() * 90, 0.18 + rand() * 0.12, 2, pickOne(BOLTC), 0, 2, 5);
        if ((s.ghostT -= dt) <= 0) { s.ghostT = 0.045; this.ghosts.push({ x: s.x, y: s.y, face: s.face, team: s.team, skin: s.skin, col: "#ffb03a", life: 0, max: 0.2 }); }
      }
    } else if (!c.drop) s.dive = false;
    s.wasJet = s.jet;
    s.jetK += ((s.jet ? 1 : 0) - s.jetK) * Math.min(1, dt * (s.jet ? 24 : 11));
    // gentle apex hang-time near zero vertical velocity makes aerial gunplay & chainsaw air-slashes feel silky smooth
    const apex = !s.ground && !s.jet && !s.dive && s.launch <= 0 && Math.abs(s.vy) < 68 ? 0.8 : 1;
    s.vy += GRAV * apex * dt * (s.launch > 0 ? 0.4 : 1);
    if (s.jet && s.lift <= 0 && s.vy < -MAXUP * (s.sprint ? 1.28 : 1)) s.vy = -MAXUP * (s.sprint ? 1.28 : 1);
    const fallCap = s.dive ? (tank ? 565 : 510) : MAXFALL;
    if (s.vy > fallCap) s.vy = fallCap;
    if (!s.ground && !mx && s.launch <= 0) s.vx *= Math.exp(-dt * 0.58);
    if (!s.ground && this.map.theme.weather === "sand") s.vx += this.gust * 14 * dt;
    // slipstream wind streaks when soaring fast through the cavern
    if (!s.ground && !s.dive && Math.hypot(s.vx, s.vy) > 225 && rand() < dt * 26) {
      this.part(s.x + (rand() - 0.5) * 12, s.y - 4 - rand() * 14, -s.vx * 0.25, -s.vy * 0.25, 0.14, 1, "rgba(220,248,255,0.65)", 0, 2, 2);
    }
    // under any waterfall: puts out flames, sprays sparkling mist — AND in Hutan Bastion (like Anthem!), cools & rapidly refills your Jetpack + NOS!
    for (const fl of this.falls) {
      if (Math.abs(s.x - fl[0]) < (fl[3] ?? 11) && s.y > fl[1] && s.y - 14 < fl[1] + fl[2]) {
        const isJungle = this.map.theme.decor === "jungle";
        if (isJungle) {
          const hadLow = s.fuel < 0.82;
          s.fuel = Math.min(1, s.fuel + 0.68 * dt);
          s.nos = Math.min(1, s.nos + 0.38 * dt);
          s.fuelWait = 0;
          if (s.me && hadLow && this.coolTipT <= 0) {
            this.coolTipT = 2.4;
            this.texts.push({ x: s.x, y: s.y - 28, text: "JET DINGIN +FUEL!", col: "#72f8ff", life: 0.95, vy: -18 });
            this.rings.push({ x: s.x, y: s.y - 9, r: 16, life: 0, max: 0.24, col: "#72f8ff" });
          }
        } else if (s.lift <= 0) s.vy += 220 * dt;
        if (s.burn > 0) { s.burn = 0; for (let i = 0; i < 5; i++) this.part(s.x, s.y - 9, (rand() - 0.5) * 40, -30 - rand() * 30, 0.6, 3, "#c9d6e0", -20, 2, 1); }
        if (rand() < dt * 34) this.part(s.x + (rand() - 0.5) * 10, s.y - 14 - rand() * 4, (rand() - 0.5) * 120, -40 - rand() * 60, 0.35 + rand() * 0.2, 1, pickOne(GEYC), 420, 0.8, 0);
        break;
      }
    }
    const water = this.environment?.waterAt(s.x, s.y);
    if (water && !s.jet) {
      // A damped buoyancy spring keeps river crossings responsive, including for bots.
      if (s.dive) { s.dive = false; s.vy = Math.min(s.vy, 130); }
      const target = water.y + 7;
      s.vy += (-GRAV + (target - s.y) * 78 - s.vy * 9) * dt;
      s.vx *= Math.exp(-dt * 0.42);
      s.fuel = Math.min(1, s.fuel + dt * 0.24);
      s.burn = 0;
    }
    const impactVy = s.vy;
    this.move(s, s.vx * dt, s.vy * dt);
    const enteredWater = this.environment?.contact(s.id, s.x, s.y, s.vx, impactVy, dt);
    if (enteredWater) {
      const strength = clamp(Math.abs(impactVy) / 150, 0.6, 2.7);
      for (let i = 0; i < Math.ceil(strength * 7); i++) this.part(s.x, enteredWater.y, (rand() - 0.5) * 90 * strength, -35 - rand() * 40 * strength, 0.35 + rand() * 0.2, 1, pickOne(GEYC), 350, 1, 8);
      if (s.me && strength > 1) this.sfx("drip", s.x, enteredWater.y, 0.5, 0.65);
      s.dive = false;
    }
    if (!s.alive) return;
    if (s.portCd > 0) s.portCd -= dt; else this.portalWalk(s);
    if (s.y > this.map.h * AT + 40) { this.hurt(s, 999, null, "fall", 0, 0, false); return; }
    const moving = s.ground && Math.abs(s.vx) > 12;
    if (moving) {
      s.walkT += dt * clamp(Math.abs(s.vx) / (tank ? 112 : 104), 0.55, 1.8);
      const fi = Math.floor((s.walkT * GAIT) / Math.PI);
      if (fi !== s.stepI) {
        s.stepI = fi;
        const dir = Math.sign(s.vx), fast = Math.abs(s.vx) > 95;
        if (tank) {
          // weighty ceramite power-armour sabatons clomping across the cavern floor
          if (s.me || rand() < 0.35) this.sfx("heavystep", s.x, s.y, s.crouch ? 0.22 : s.sprint ? 0.62 : 0.44, s.sprint ? 1.08 : 0.92 + rand() * 0.1);
          if (s.me && s.sprint) this.cam.ky += 0.55;
        } else if (s.me && (!fast || fi % 2 === 0)) this.sfx("step", s.x, s.y, s.crouch ? 0.18 : s.sprint ? 0.5 : 0.35, s.sprint ? 1.2 : 1);
        if (!s.crouch && (fast || tank)) for (let i = 0; i < (s.sprint ? (tank ? 4 : 3) : 1); i++) this.part(s.x - dir * (2 + rand() * 4), s.y - 1, -dir * (22 + rand() * 42) * (s.sprint ? 1.6 : 1), -14 - rand() * 24, 0.3 + rand() * 0.18, 1 + ((rand() * 2) | 0), this.dustCol(), 50, 3, 1);
      }
    }
    s.runK += ((moving && Math.abs(s.vx) > 94 ? 1 : 0) - s.runK) * Math.min(1, dt * 8);
    this.scarfTick(s, dt);
    if (frozen) return;
    // weapons
    if (c.swap) this.swap(s);
    if (c.reload) this.reloadStart(s);
    if (c.pick && !this.toggleHide(s)) this.tryPick(s, true);
    if (c.nade && !s.holo) this.throwNade(s);
    if (c.melee && !s.holo) this.meleeStart(s);
    this.tryPick(s, false);
    const sl = s.slots[s.cur], saber = !!sl && sl.id === "saber", katana = !!sl && sl.id === "katana", chain = !!sl && sl.id === "chainsword";
    const bladeWep = saber || katana || chain || (!!sl && sl.id === "axe");
    // Astartes chainsword motor: puffs oily two-stroke exhaust & throws hot grinding sparks off the spinning teeth!
    if (chain && !s.hide && !s.holo) {
      s.chainRev += ((s.swingT > 0 ? 1 : 0.28) - s.chainRev) * Math.min(1, dt * 14);
      const pv = this.pivot(s), ba = this.bladeAng(s), ca = Math.cos(ba), sa = Math.sin(ba);
      if (rand() < dt * (s.swingT > 0 ? 34 : 11)) this.part(pv.x + ca * 5, pv.y + sa * 5 - 3, -ca * 14 + (rand() - 0.5) * 16, -22 - rand() * 20, 0.38 + rand() * 0.22, 2, pickOne(["#7a7888", "#9ea0b2"]), -24, 2.2, 1);
      if (rand() < dt * (s.swingT > 0 ? 85 : 16)) {
        const d2 = 8 + rand() * 18;
        this.part(pv.x + ca * d2, pv.y + sa * d2, -ca * (55 + rand() * 95) + (rand() - 0.5) * 55, -sa * (55 + rand() * 95) - 18 + (rand() - 0.5) * 45, 0.14 + rand() * 0.14, 1, pickOne(CHAINC), 280, 1.4, 9);
      }
    } else s.chainRev = 0;
    if (s.smokeT > 0) {
      s.smokeT -= dt;
      if (sl && !bladeWep && rand() < dt * 16) {
        const mz = this.muzzle(s);
        this.part(mz.x, mz.y, (rand() - 0.5) * 10, -14 - rand() * 14, 0.45 + rand() * 0.25, 1 + (rand() < 0.35 ? 1 : 0), pickOne(["#d8d4cc", "#a6a2a8"]), -18, 2.5, 1);
      }
    }
    if (saber) {
      if (s.saberOn <= 0) this.sfx("saberon", s.x, s.y, s.me ? 0.7 : 0.4);
      s.saberOn = Math.min(1, s.saberOn + dt / 0.18);
    } else if (s.saberOn > 0) { this.sfx("saberoff", s.x, s.y, s.me ? 0.6 : 0.3); s.saberOn = 0; s.swingT = 0; }
    this.swingTick(s, dt);
    if (s.reload > 0 && sl && !bladeWep) {
      const w = AWEP[sl.id], before = s.reload;
      s.reload -= dt;
      const k0 = 1 - before / s.reloadMax, k1 = 1 - s.reload / s.reloadMax;
      if (k0 < 0.55 && k1 >= 0.55) this.sfx(w.id === "shotgun" ? "shellin" : "magin", s.x, s.y, s.me ? 0.6 : 0.3);
      if (s.reload <= 0) {
        const take = Math.min(w.mag - sl.mag, sl.ammo);
        sl.mag += take;
        sl.ammo -= take;
        this.sfx(w.id === "shotgun" ? "pump" : "rack", s.x, s.y, s.me ? 0.6 : 0.3);
        if (w.id === "shotgun") s.pump = 0.34;
      }
    }
    if (sl) {
      const w = AWEP[sl.id];
      if (c.fire && !s.holo && s.melee <= 0 && (w.auto || !s.trig)) this.fire(s, sl, w);
      if (!bladeWep && sl.mag <= 0 && sl.ammo > 0 && s.reload <= 0 && !c.fire) this.reloadStart(s);
    }
    s.trig = c.fire;
    if (s.melee > 0) {
      const before = s.melee;
      s.melee -= dt;
      if (before > 0.14 && s.melee <= 0.14) this.meleeHit(s);
    }
  }

  /** the scarf trails out behind: three links that follow each other with a little lag, fluttering in the wind */
  private scarfTick(s: Sol, dt: number) {
    let qx = s.x - s.face * 3, qy = s.y - 11;
    const wind = this.map.theme.weather === "sand" ? this.gust * 2.2 : 0, fast = Math.abs(s.vx) + Math.abs(s.vy) > 60;
    for (let i = 0; i < 6; i += 2) {
      const tx = qx - s.face * 3.2 - s.vx * 0.018 + wind, ty = qy + 1.3 - s.vy * 0.012 + Math.sin(this.t * 13 + s.id + i) * (fast ? 1 : 0.35);
      s.scarf[i] += (tx - s.scarf[i]) * Math.min(1, dt * 16);
      s.scarf[i + 1] += (ty - s.scarf[i + 1]) * Math.min(1, dt * 16);
      const dx = s.scarf[i] - qx, dy = s.scarf[i + 1] - qy, l = Math.hypot(dx, dy);
      if (l > 4.2) { s.scarf[i] = qx + (dx / l) * 4.2; s.scarf[i + 1] = qy + (dy / l) * 4.2; }
      qx = s.scarf[i]; qy = s.scarf[i + 1];
    }
  }

  private groundBelow(x: number, y: number, max: number) {
    for (let d = 0; d <= max; d += 2) {
      const yy = y + d;
      if (solidPx(this.map, x, yy) || tileAt(this.map, Math.floor(x / AT), Math.floor(yy / AT)) === PLAT) return yy;
    }
    return -1;
  }
  /** NOS lights: a kick in the back, a flash and a ring of blue fire, dust blasted off the ground */
  private nosKick(s: Sol, mx: number) {
    const dir = mx ? Math.sign(mx) : s.face, bx = s.x - dir * 7, by = s.y - 7;
    s.nosCd = 0.9;
    s.nos = Math.max(0, s.nos - 0.1);
    s.vx += dir * (s.ground ? 110 : 140);
    if (!s.ground) s.vy = Math.min(s.vy, 30) - 30;
    s.squash = Math.max(s.squash, 0.07);
    this.flashes.push({ x: bx, y: by, r: 30, life: 0.12, max: 0.12, col: "#5fd8ff" });
    this.rings.push({ x: bx, y: by, r: 15, life: 0, max: 0.24, col: "#8fe8ff" });
    for (let i = 0; i < 12; i++) this.part(bx, by + (rand() - 0.5) * 6, -dir * (90 + rand() * 150), (rand() - 0.5) * 60, 0.16 + rand() * 0.16, 2, pickOne(NOSC), 0, 3, 5);
    if (s.ground) for (let i = 0; i < 6; i++) this.part(s.x - dir * 4, s.y - 1, -dir * (60 + rand() * 110), -10 - rand() * 40, 0.4 + rand() * 0.25, 2, this.dustCol(), 50, 3, 1);
    this.sfx("jetburst", s.x, s.y, s.me ? 0.7 : 0.4, 1.55);
    if (s === this.focus()) { this.cam.kx -= dir * 3; this.cam.shake = Math.max(this.cam.shake, 1.6); }
  }
  /** while the NOS burns: blue fire streaming out behind, and a ghost of the runner left hanging in the air every few steps */
  private nosFx(s: Sol, dt: number) {
    const dir = Math.abs(s.vx) > 20 ? Math.sign(s.vx) : s.face;
    if (rand() < dt * 70) this.part(s.x - dir * 8, s.y - 7 + (rand() - 0.5) * 4, -dir * (50 + rand() * 90), (rand() - 0.5) * 30 - 8, 0.12 + rand() * 0.12, 2, pickOne(NOSC), 0, 2, 5);
    if ((s.ghostT -= dt) <= 0) { s.ghostT = 0.06; this.ghosts.push({ x: s.x, y: s.y, face: s.face, team: s.team, skin: s.skin, col: "#5fd8ff", life: 0, max: 0.2 }); }
  }
  /** the squad learns where an enemy is */
  private spot(e: Sol) { this.intel.set(e.id, { x: e.x, y: e.y, t: this.t }); }

  // ───────────── the hologram shield ─────────────
  /** the height of the middle of a soldier's body: the hologram shield is an arc around it */
  private holoY(e: Sol) { return e.y - 10 + e.duck * 4; }
  /** is the hologram shield of e up, and turned towards (x, y)? */
  private holoFacing(e: Sol, x: number, y: number) {
    return e.holoK > 0.5 && Math.abs(angDiff(e.aim, Math.atan2(y - this.holoY(e), x - e.x))) < HOLO_ARC + 0.08;
  }
  /** does the hologram shield of e stop something at (x, y) that is moving by (vx, vy)? - it is at the wall or just inside it, in front of e, and coming inwards */
  private holoBlocks(e: Sol, x: number, y: number, vx: number, vy: number) {
    const dx = x - e.x, dy = y - this.holoY(e), d = Math.hypot(dx, dy);
    return d <= HOLO_R + 2.5 && d > 1 && vx * dx + vy * dy < 0 && this.holoFacing(e, x, y);
  }
  /**
   * The hologram shield takes a blow at (x, y): its panels flare from there outwards, sparks of hard light fly - and when its
   * energy is gone it shatters, and cannot be raised again for five seconds. (The blow that breaks it goes no further.)
   */
  private holoHit(e: Sol, dmg: number, by: Sol | null, x: number, y: number) {
    if (this.phase === "end" || e.holoHp <= 0) return;
    if (by && by.bot && by.team !== this.me.team) dmg *= DMG_MUL[this.cfg!.diff];
    const C = HOLOC[e.team], out = Math.atan2(y - this.holoY(e), x - e.x), big = dmg >= 6;
    e.holoHp -= dmg; e.holoHitT = 0; e.holoFx = 1; e.holoAt = angDiff(e.aim, out);
    if (big || rand() < 0.3)
      for (let i = 0; i < (big ? 4 : 1); i++) { const a = out + (rand() - 0.5) * 1.6, v = 50 + rand() * 110; this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 20, 0.2 + rand() * 0.2, 1, pickOne([C.col, C.hot, "#ffffff"]), 160, 2, 5); }
    if (big) {
      if (this.hitfx.length < 44) this.hitfx.push({ x, y, ang: out, r: 6 + Math.min(5, dmg / 14), kind: 2, life: 0, max: 0.13, col: C.col });
      this.rings.push({ x, y, r: 7 + Math.min(7, dmg / 10), life: 0, max: 0.18, col: C.col });
      this.sfx("holohit", x, y, Math.min(0.9, 0.35 + dmg / 90), 0.9 + rand() * 0.25);
    }
    if (by && by.me && by !== e) {
      this.hitMark = 0.1; this.spot(e);
      if (big) this.texts.push({ x: x + (rand() - 0.5) * 6, y: y - 8, text: String(Math.max(1, Math.round(dmg))), col: C.hot, life: 0.6, vy: -22 });
    }
    if (e.me) { this.cam.shake = Math.max(this.cam.shake, 1 + dmg / 30); this.combat = 1; }
    if (e.bot && by && by !== e && !e.bot.target) e.bot.seen = { x: by.x, y: by.y, t: this.t };
    if (e.holoHp <= 0) this.holoBreak(e, by, out);
  }
  /** the hologram shield shatters: every panel flies off as a shard of light, and it stays down for five seconds */
  private holoBreak(e: Sol, by: Sol | null, out: number) {
    const C = HOLOC[e.team], cx = e.x, cy = this.holoY(e), fx = cx + Math.cos(e.aim) * HOLO_R, fy = cy + Math.sin(e.aim) * HOLO_R;
    e.holo = false; e.holoK = 0; e.holoHp = 0; e.holoCd = HOLO_CD; e.holoFx = 0; e.ouch = 0.3;
    if (e.bot) e.bot.guardT = 0;
    for (let j = -4; j <= 4; j++) {
      const a = e.aim + j * 0.26, px = cx + Math.cos(a) * (HOLO_R + 1), py = cy + Math.sin(a) * (HOLO_R + 1);
      for (let i = 0; i < 2; i++) {
        // (half of them fly on outwards, half are driven in by the blow that broke it)
        const q = (rand() < 0.5 ? a : out + Math.PI) + (rand() - 0.5) * 1.2, v = 60 + rand() * 150;
        this.part(px, py, Math.cos(q) * v, Math.sin(q) * v - 30, 0.35 + rand() * 0.45, 1 + ((rand() * 2) | 0), pickOne([C.col, C.col, C.hot, "#ffffff"]), 260, 1.2, 5);
      }
    }
    this.flashes.push({ x: fx, y: fy, r: 50, life: 0.16, max: 0.16, col: C.col });
    this.rings.push({ x: fx, y: fy, r: 24, life: 0, max: 0.3, col: C.col });
    this.rings.push({ x: fx, y: fy, r: 14, life: 0, max: 0.18, col: "#ffffff" });
    this.hitfx.push({ x: fx, y: fy, ang: out, r: 14, kind: 2, life: 0, max: 0.17, col: C.col });
    this.sparks(fx, fy, 8, ["#ffffff", C.hot, C.col]);
    this.sfx("holobreak", fx, fy, 1);
    e.vx -= Math.cos(out) * 50;
    if (e.me) { this.texts.push({ x: e.x, y: e.y - 32, text: "PERISAI HANCUR!", col: "#ff6b7a", life: 1.1, vy: -14 }); this.cam.shake = Math.max(this.cam.shake, 4); this.hitStop = Math.max(this.hitStop, 0.045); }
    else if (by && by.me) { this.texts.push({ x: e.x, y: e.y - 32, text: "PERISAI PECAH!", col: C.hot, life: 1, vy: -14 }); this.hitStop = Math.max(this.hitStop, 0.03); }
  }

  /** the jetpack / Astartes twin jump-pack lights: snappy upward launch, plasma shock-ring & ground blast wave */
  private ignite(s: Sol) {
    const tank = s.skin === ASTARTES, fromGround = s.ground;
    s.burst = tank ? 0.28 : 0.24;
    s.vy = Math.min(s.vy * 0.25, 0) - (fromGround ? (tank ? 162 : 148) : (tank ? 98 : 86));
    if (s.ctl.mx) s.vx += Math.sign(s.ctl.mx) * (fromGround ? 34 : 24);
    const nx = s.x - s.face * (tank ? 9 : 8), ny = s.y - 2;
    this.flashes.push({ x: nx, y: ny + 4, r: tank ? 48 : 36, life: 0.14, max: 0.14, col: tank ? "#6ad8ff" : "#ffb35a" });
    this.rings.push({ x: nx, y: ny + 3, r: tank ? 24 : 17, life: 0, max: 0.28, col: tank ? "#9eeeff" : "#ffd27a" });
    if (tank || fromGround) this.rings.push({ x: s.x, y: s.y - 1, r: tank ? 18 : 12, life: 0, max: 0.2, col: "#ffffff" });
    for (let i = 0; i < (tank ? 12 : 9); i++) { const a = Math.PI * 0.5 + (rand() - 0.5) * 2.4; this.part(nx, ny + 2, Math.cos(a) * (65 + rand() * 90), Math.sin(a) * (40 + rand() * 65), 0.5 + rand() * 0.4, 3 + ((rand() * 2) | 0), pickOne(SMOKE), -30, 2.2, 1); }
    for (let i = 0; i < (tank ? 13 : 8); i++) this.part(nx + (rand() - 0.5) * (tank ? 6 : 2), ny + 2, (rand() - 0.5) * 140, 75 + rand() * 135, 0.26, 2, pickOne(tank ? ["#ffffff", "#bff6ff", "#ffd868", "#ff8a28"] : FIRE), 0, 2, 5);
    const gy = this.groundBelow(s.x, ny, 38);
    if (gy >= 0) for (let i = 0; i < (tank ? 16 : 12); i++) { const sd = i % 2 ? 1 : -1; this.part(s.x + sd * rand() * 5, gy - 1, sd * (90 + rand() * 135), -12 - rand() * 55, 0.58 + rand() * 0.38, 2 + ((rand() * 2) | 0), this.dustCol(), 45, 2.5, 1); }
    this.sfx(tank ? "jumpboost" : "jetburst", nx, ny, s.me ? 0.85 : 0.48, 0.92 + rand() * 0.16);
    if (s === this.focus()) {
      this.cam.ky -= fromGround ? (tank ? 3.2 : 2.2) : 1.3;
      this.cam.shake = Math.max(this.cam.shake, fromGround ? (tank ? 2.4 : 1.3) : 0.8);
    }
  }
  /** while the jet burns: twin plasma exhaust on Astartes, Mach shock rings, smoke & ground-wash dust vortex */
  private jetFx(s: Sol, dt: number) {
    const tank = s.skin === ASTARTES, nx = s.x - s.face * (tank ? 9 : 8), ny = s.y - 1, k = s.fuel < 0.14 ? 0.5 : 1;
    const rate = (tank ? 95 : 74) * k;
    if (rand() < dt * rate) {
      const off = tank ? (rand() < 0.5 ? -2.5 : 2.5) : (rand() - 0.5) * 2;
      this.part(nx + off, ny + 2, -s.vx * 0.28 + (rand() - 0.5) * 32, 95 + rand() * 85, 0.16 + rand() * 0.11, 2, pickOne(s.sprint ? NOSC : tank ? ["#ffffff", "#d6fbff", "#ffd25a", "#ff7a24"] : FIRE), 0, 1.2, 5);
    }
    if (tank && rand() < dt * 7.5) this.rings.push({ x: nx, y: ny + 4, r: 9, life: 0, max: 0.16, col: s.sprint ? "#8fe8ff" : "#ffd27a" });
    if (rand() < dt * 36) this.part(nx, ny + 5, -s.vx * 0.15 + (rand() - 0.5) * 26, 42 + rand() * 32, 0.68 + rand() * 0.45, 2, pickOne(SMOKE), -36, 2, 1);
    const gy = this.groundBelow(s.x, ny, 52);
    if (gy >= 0 && rand() < dt * 65 * (1 - (gy - ny) / 52)) { const sd = rand() < 0.5 ? -1 : 1; this.part(s.x + sd * (3 + rand() * 4), gy - 1, sd * (75 + rand() * 105), -6 - rand() * 38, 0.42 + rand() * 0.28, 2, this.dustCol(), 50, 3, 1); }
  }

  private ragdoll(s: Sol, dt: number) {
    s.respawn -= dt;
    if (s.ragdoll) {
      // keep soldier camera anchor synced with chest of the articulated Verlet ragdoll
      s.x = s.ragdoll.nodes[1].x;
      s.y = s.ragdoll.nodes[2].y + 4;
    }
    if (s.respawn <= 0 && this.phase !== "end") this.respawn(s);
  }

  /**
   * A ragdoll for whoever has just been killed: seven parts - head, chest, hips, two hands, two feet - on bones that do not
   * stretch, in the proportions of the living soldier, so the body never comes apart. It starts in their pose, moving as they
   * moved, and takes the blow where it landed: a shot in the head whips the head back and flips the body over after it, a blast
   * throws every limb, a blade drags the body along its cut, a bullet in the chest folds it over the wound.
   */
  private spawnRagdoll(v: Sol, ang: number, force: number, hitZone: "head" | "body" | "blast" | "slash", w: string): Ragdoll {
    const dt0 = 1 / 180, f = v.face, low = v.duck * 4;
    const ivx = clamp(v.vx, -280, 280) * dt0, ivy = clamp(v.vy, -260, 240) * dt0;
    const mkN = (x: number, y: number, r: number, invM: number): RagNode => ({ x, y, ox: x - ivx, oy: y - ivy, r, invM, vx0: 0, vy0: 0, cf: false, cc: false, cw: 0 });
    const N: RagNode[] = [
      mkN(v.x + f * (0.5 + low), v.y - 14.5 + low * 0.7, 5, 1), // 0 head
      mkN(v.x + f * low * 0.4, v.y - 8.5 + low * 0.3, 3.4, 0.7), // 1 chest
      mkN(v.x, v.y - 3.9, 3, 0.8), // 2 hips
      mkN(v.x - f * 3.8, v.y - 6, 1.4, 1.5), // 3 far hand
      mkN(v.x + f * 4.2, v.y - 6.2, 1.4, 1.5), // 4 near hand
      mkN(v.x - f * 2, v.y - 1.6, 1.5, 1.3), // 5 far foot
      mkN(v.x + f * 2, v.y - 1.6, 1.5, 1.3), // 6 near foot
    ];
    const kick = (i: number, ix: number, iy: number) => { N[i].ox -= ix * dt0; N[i].oy -= iy * dt0; };
    const ca = Math.cos(ang), sa = Math.sin(ang), imp = clamp(force, 110, 640), sd = rand() < 0.5 ? -1 : 1;
    if (hitZone === "head") {
      // the head is whipped back and the body flipped over after it: the feet kick out the other way
      kick(0, ca * imp * 1.7, sa * imp * 1.2 - 130); kick(1, ca * imp * 0.9, sa * imp * 0.6 - 70); kick(2, ca * imp * 0.25, -30);
      kick(3, ca * imp * 0.5 + (rand() - 0.5) * 90, -80 - rand() * 50); kick(4, ca * imp * 0.6 + (rand() - 0.5) * 90, -70 - rand() * 50);
      kick(5, -ca * imp * 0.35, 20); kick(6, -ca * imp * 0.25, 10);
    } else if (hitZone === "blast") {
      // a blast throws the whole body, every part a little differently - and sets it spinning
      for (let i = 0; i < 7; i++) { const sp = 0.85 + rand() * 0.5; kick(i, ca * imp * sp + (rand() - 0.5) * 120, sa * imp * sp - 130 - rand() * 110); }
      kick(0, -sa * 130 * sd, ca * 130 * sd); kick(5, sa * 130 * sd, -ca * 130 * sd); kick(6, sa * 130 * sd, -ca * 130 * sd);
    } else if (hitZone === "slash") {
      // a blade drags the body along its cut
      kick(0, ca * imp * 1.2, sa * imp * 0.9 - 110); kick(1, ca * imp * 1.3, sa * imp * 0.95 - 95); kick(2, ca * imp * 0.7, -45);
      kick(3, ca * imp * 1.1 - sa * 90, -100); kick(4, ca * imp * 1.1 + sa * 90, -90); kick(5, -ca * 55, -20); kick(6, ca * 65, -40);
    } else {
      // a bullet in the body: the chest is punched back, the head and the feet lag behind - it folds over the wound
      kick(1, ca * imp * 1.3, sa * imp * 0.7 - 85); kick(2, ca * imp * 0.95, sa * imp * 0.5 - 50); kick(0, ca * imp * 0.45, -90);
      kick(3, ca * imp * 0.7 + (rand() - 0.5) * 70, -70 - rand() * 40); kick(4, ca * imp * 0.7 + (rand() - 0.5) * 70, -60 - rand() * 40);
      kick(5, ca * imp * 0.3 + (rand() - 0.5) * 50, -20); kick(6, ca * imp * 0.4 + (rand() - 0.5) * 50, -35);
    }
    const dry = w === "saber" || w === "flame" || w === "tesla";
    const rag: Ragdoll = {
      team: v.team, skin: v.skin, face: v.face, headless: false, life: 7, maxLife: 7, ownerId: v.id, nodes: N, scarf: v.scarf.slice(),
      burn: w === "flame" ? 2.4 : v.burn > 0 ? 1.5 : 0, jetFail: !v.ground && rand() < 0.28 ? 0.5 + rand() * 0.4 : 0, thudCd: 0, bloodT: dry ? 0 : 0.9,
      sleep: false, still: 0, pool: 0, spurt: dry ? 0 : hitZone === "head" ? 0.55 : w === "katana" || w === "axe" ? 0.4 : 0, twitch: w === "tesla" ? 1.5 : 0.45, dry,
    };
    this.corpses.push(rag);
    if (this.corpses.length > 14) this.corpses.shift();
    return rag;
  }

  /** a blast, a bullet or a blade reaches the fallen as well: they are thrown, nudged or dragged (and woken, if they had come to rest) */
  private pushRagdolls(x: number, y: number, r: number, force: number, radial = true, ang = 0) {
    const dt0 = 1 / 180;
    for (const c of this.corpses) {
      const ch = c.nodes[1], d = Math.hypot(ch.x - x, ch.y - y);
      if (d > r) continue;
      const k = 1 - d / r;
      c.sleep = false; c.still = 0;
      for (const n of c.nodes) {
        const a = radial ? Math.atan2(n.y - y, n.x - x) : ang, f = force * (0.45 + 0.55 * k) * (0.75 + rand() * 0.5);
        n.ox -= Math.cos(a) * f * dt0;
        n.oy -= (Math.sin(a) * f - (radial ? 95 * k : 35)) * dt0;
      }
      if (radial && force > 180) this.part(ch.x, ch.y, (rand() - 0.5) * 80, -40 - rand() * 50, 0.4, 2, this.dustCol(), 80, 2, 1);
    }
  }

  /**
   * The ragdolls: Verlet parts on bones. Spine and neck are rigid, arms and legs fold but never stretch, the neck and the legs only
   * bend so far - and every step the last word goes to the bones, leaning on whichever end rests on something, so nothing comes
   * apart. Each part is kept out of the rock and on top of the planks it lands on; what the ground does to its speed - the bounce
   * off a hard landing, the drag of sliding - is settled afterwards. A body that has come to rest goes to sleep until it is pushed.
   */
  private stepRagdolls(dt: number) {
    const m = this.map, SUB = 3, sdt = dt / SUB, grav = GRAV * 0.95 * sdt * sdt, wind = m.theme.weather === "sand" ? this.gust * 45 * sdt * sdt : 0;
    for (let ci = this.corpses.length - 1; ci >= 0; ci--) {
      const c = this.corpses[ci], N = c.nodes;
      c.life -= dt;
      if (c.life <= 0 || N[1].y > m.h * AT + 70) { this.corpses.splice(ci, 1); continue; }
      c.thudCd = Math.max(0, c.thudCd - dt);
      this.ragFx(c, dt);
      if (c.sleep) continue;
      for (let st = 0; st < SUB; st++) {
        for (const n of N) {
          const vx = clamp((n.x - n.ox) * 0.996, -5, 5), vy = clamp((n.y - n.oy) * 0.996, -5, 5);
          n.ox = n.x; n.oy = n.y;
          n.x += vx + wind; n.y += vy + grav;
          n.vx0 = vx; n.vy0 = vy + grav; n.cf = n.cc = false; n.cw = 0;
        }
        for (let it = 0; it < 5; it++) { this.ragBones(N, false); for (const n of N) this.ragProject(n); }
        this.ragBones(N, true); this.ragBones(N, true);
        for (const n of N) this.ragProject(n);
        // what the ground does to the speed of whatever touches it: a hard landing bounces, sliding drags
        for (const n of N) {
          let vx = n.x - n.ox, vy = n.y - n.oy;
          if (n.cf) {
            if (vy > 0) vy = 0;
            if (n.vy0 > 1.25) { vy = Math.min(vy, -n.vy0 * 0.34); this.ragThud(c, n, n.vy0); }
            vx *= 0.9;
          }
          if (n.cc && vy < 0) vy = 0;
          if (n.cw && vx * n.cw > 0) vx = 0;
          if (n.cw && n.vx0 * n.cw > 1.4) { vx = -n.vx0 * 0.3; this.ragThud(c, n, Math.abs(n.vx0)); }
          n.ox = n.x - vx; n.oy = n.y - vy;
        }
      }
      // lying down, it settles face down with the jetpack uppermost (never driven into the ground underneath it)
      const lie = N[1].x - N[2].x;
      if (N[1].cf && N[2].cf && Math.abs(lie) > 2.8) c.face = lie > 0 ? 1 : -1;
      let fast = 0, down = 0;
      for (const n of N) { fast = Math.max(fast, Math.abs(n.x - n.ox) + Math.abs(n.y - n.oy)); if (n.cf) down++; }
      if (fast < 0.06 && down >= 3 && (N[0].cf || N[1].cf)) { if ((c.still += dt) > 0.45) { c.sleep = true; for (const n of N) { n.ox = n.x; n.oy = n.y; } } }
      else c.still = Math.max(0, c.still - dt * 2);
    }
  }
  /** the bones of a ragdoll are brought to their length (in the final pass an end that rests on something stays put, and the other end comes to it) */
  private ragBones(N: RagNode[], final: boolean) {
    for (const [a, b, len, rope] of RAG) {
      const na = N[a], nb = N[b], dx = nb.x - na.x, dy = nb.y - na.y, d = Math.hypot(dx, dy) || 0.001;
      if (rope && d <= len && d >= len * 0.45) continue;
      const diff = (d - (rope && d < len ? len * 0.45 : len)) / d;
      let wa = na.invM, wb = nb.invM;
      if (final) { const pa = na.cf || na.cw !== 0, pb = nb.cf || nb.cw !== 0; if (pa && !pb) wa = 0; else if (pb && !pa) wb = 0; }
      const sum = wa + wb || 1;
      na.x += dx * diff * (wa / sum); na.y += dy * diff * (wa / sum);
      nb.x -= dx * diff * (wb / sum); nb.y -= dy * diff * (wb / sum);
    }
    if (final) return;
    // the neck bends no further than about 55° from the line of the spine; a leg does not fold up over the chest; feet and hands keep clear of each other and of the head
    this.ragApart(N[0], N[2], 9.4); this.ragApart(N[1], N[5], 4.7); this.ragApart(N[1], N[6], 4.7);
    this.ragApart(N[5], N[6], 2); this.ragApart(N[3], N[0], 4.4); this.ragApart(N[4], N[0], 4.4);
  }
  private ragApart(a: RagNode, b: RagNode, min: number) {
    const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 0.001;
    if (d >= min) return;
    const diff = ((min - d) / d) * 0.6, s = a.invM + b.invM;
    a.x -= dx * diff * (a.invM / s); a.y -= dy * diff * (a.invM / s);
    b.x += dx * diff * (b.invM / s); b.y += dy * diff * (b.invM / s);
  }
  /** one part of a ragdoll is kept out of the rock, and on top of the planks it comes down onto (its place only: its speed is settled afterwards) */
  private ragProject(n: RagNode) {
    const m = this.map, fy = n.y + n.r, top = Math.floor(fy / AT) * AT;
    // the floor: solid ground - or a platform, when it comes down onto it from above
    if (solidPx(m, n.x, fy)) { if (!solidPx(m, n.x, top - 1)) { n.y = top - n.r; n.cf = true; } }
    else if (n.vy0 >= 0 && tileAt(m, Math.floor(n.x / AT), Math.floor(fy / AT)) === PLAT && n.oy + n.r <= top + 2) { n.y = top - n.r; n.cf = true; }
    // the roof
    if (solidPx(m, n.x, n.y - n.r)) { const bot = (Math.floor((n.y - n.r) / AT) + 1) * AT; if (!solidPx(m, n.x, bot + 1)) { n.y = bot + n.r; n.cc = true; } }
    // the walls
    if (solidPx(m, n.x + n.r, n.y)) { const e = Math.floor((n.x + n.r) / AT) * AT; if (!solidPx(m, e - 1, n.y)) { n.x = e - n.r; n.cw = 1; } }
    else if (solidPx(m, n.x - n.r, n.y)) { const e = (Math.floor((n.x - n.r) / AT) + 1) * AT; if (!solidPx(m, e + 1, n.y)) { n.x = e + n.r; n.cw = -1; } }
    // squeezed right into the rock (a corner, a bone pulling it in): straight up and out
    if (solidPx(m, n.x, n.y)) for (let k = 1; k <= 12; k++) if (!solidPx(m, n.x, n.y - k)) { n.y -= k + n.r * 0.5; n.cf = true; break; }
  }
  /** a part of a ragdoll strikes something hard: a thud, dust - and, while the wound is fresh, blood left where it struck */
  private ragThud(c: Ragdoll, n: RagNode, speed: number) {
    if (c.thudCd > 0) return;
    c.thudCd = 0.12;
    this.sfx("thunk", n.x, n.y, Math.min(0.5, speed * 0.16), 0.75 + rand() * 0.35);
    for (let k = 0; k < 3; k++) this.part(n.x + (rand() - 0.5) * 5, n.y + n.r, (rand() - 0.5) * 50, -15 - rand() * 28, 0.38, 2, this.dustCol(), 70, 2.5, 1);
    if (c.dry || c.life < c.maxLife - 3.5) return;
    this.splat(n.x + n.cw * n.r, n.y + (n.cf ? n.r : 0), 2 + ((rand() * 3) | 0));
    for (let k = 0; k < 4; k++) this.part(n.x, n.y, (rand() - 0.5) * 100, -30 - rand() * 70, 0.6, 1, pickOne(BLOOD), 520, 0.5, 4);
  }
  /** what a ragdoll does besides fall: it bleeds - a trail through the air, a spurt from the wound, a pool where it comes to rest -, burns, twitches, is flung about by a jetpack that has not gone out; and its scarf settles after it */
  private ragFx(c: Ragdoll, dt: number) {
    const N = c.nodes, ch = N[1], hd = N[0], hp = N[2];
    if (!c.dry) {
      const sp = Math.hypot(ch.x - ch.ox, ch.y - ch.oy);
      if (c.bloodT > 0) {
        c.bloodT -= dt;
        if (rand() < dt * (8 + sp * 28)) this.part(ch.x + (rand() - 0.5) * 4, ch.y, (rand() - 0.5) * 35, -15 - rand() * 25, 0.6, 1, pickOne(BLOOD), 480, 0.6, 4);
      }
      if (c.spurt > 0) {
        // a spurt out of the wound, along the line of the neck, in pulses
        c.spurt -= dt;
        if (Math.sin(c.spurt * 42) > -0.2) {
          let ux = hd.x - ch.x, uy = hd.y - ch.y;
          const ul = Math.hypot(ux, uy) || 1;
          ux /= ul; uy /= ul;
          for (let i = 0; i < 2; i++) this.part(hd.x + ux * 2, hd.y + uy * 2, ux * (70 + rand() * 80) + (rand() - 0.5) * 40, uy * (70 + rand() * 80) - 40 + (rand() - 0.5) * 40, 0.7, 1 + (rand() < 0.3 ? 1 : 0), pickOne(BLOOD), 520, 0.5, 4);
        }
      }
      // lying still: a pool spreads out from under the body
      if ((c.sleep || c.still > 0.15) && c.pool < 1) { c.pool = Math.min(1, c.pool + dt * 0.45); this.splat(ch.x + (rand() - 0.5) * 2, ch.y + ch.r, 1 + Math.round(c.pool * 7)); }
    }
    if (c.burn > 0) {
      c.burn -= dt;
      if (rand() < dt * 20) this.part(ch.x + (rand() - 0.5) * 6, ch.y + (rand() - 0.5) * 6, (rand() - 0.5) * 20, -30 - rand() * 30, 0.32, 2, pickOne(FIRE), -55, 1, 5);
    }
    if (!c.sleep) {
      // nobody dies sitting up: a body balanced on its hips is tipped over, the way it was leaning (or forwards)
      if (hp.cf && !ch.cf && ch.y < hp.y && Math.abs(ch.x - hp.x) < 3.2) { const sd = Math.abs(ch.x - hp.x) < 0.3 ? c.face : Math.sign(ch.x - hp.x); ch.ox -= sd * 0.035; hd.ox -= sd * 0.05; }
      if (c.jetFail > 0) {
        // the jetpack has not gone out: it drives the body head first, sputtering
        c.jetFail -= dt;
        const a = Math.atan2(hp.y - ch.y, hp.x - ch.x), th = 900 * dt * (1 / 180);
        ch.ox += Math.cos(a) * th; ch.oy += Math.sin(a) * th;
        if (rand() < dt * 55) {
          this.part(ch.x + Math.cos(a) * 5, ch.y + Math.sin(a) * 5, Math.cos(a) * 120 + (rand() - 0.5) * 50, Math.sin(a) * 120 + (rand() - 0.5) * 50, 0.22, 2, pickOne(FIRE), 0, 2, 5);
          this.part(ch.x + Math.cos(a) * 6, ch.y + Math.sin(a) * 6, (rand() - 0.5) * 25, -20, 0.55, 2, pickOne(SMOKE), -30, 2, 1);
        }
      }
      if (c.twitch > 0) {
        // the last twitches of hands and feet
        c.twitch -= dt;
        if (rand() < dt * 30) { const n = N[3 + ((rand() * 4) | 0)]; n.ox += (rand() - 0.5) * 0.7; n.oy += (rand() - 0.5) * 0.7; }
      }
    }
    let qx = ch.x, qy = ch.y - 1;
    for (let i = 0; i < 6; i += 2) {
      c.scarf[i] += (qx - c.scarf[i]) * Math.min(1, dt * 11);
      c.scarf[i + 1] += (qy + 2.2 - c.scarf[i + 1]) * Math.min(1, dt * 11);
      const dx = c.scarf[i] - qx, dy = c.scarf[i + 1] - qy, l = Math.hypot(dx, dy);
      if (l > 4) { c.scarf[i] = qx + (dx / l) * 4; c.scarf[i + 1] = qy + (dy / l) * 4; }
      qx = c.scarf[i]; qy = c.scarf[i + 1];
    }
  }

  // ───────────── blood ─────────────
  /**
   * Blood, to suit the duel: a burst of fat pixel drops at the wound, a fine red mist, and a spray flung on the way the blow was
   * going - which lands, and stays, as puddles on the floor and streaks down the walls. A kill or a headshot (big) gives more of everything.
   */
  private gore(x: number, y: number, ang: number, power: number, big: boolean) {
    const ca = Math.cos(ang), sa = Math.sin(ang), n = Math.round(4 + power * 9) + (big ? 8 : 0);
    if (this.bursts.length < 44) this.bursts.push({ x, y, ang, r: (big ? 15 : 8) + Math.min(8, power * 8), life: 0, max: big ? 0.26 : 0.2, seed: rand() * 100 });
    // the spray: out of the far side of the wound, in a cone
    for (let i = 0; i < n; i++) {
      const a = ang + (rand() - 0.5) * (big ? 1.5 : 1.1), v = 60 + rand() * (120 + power * 140);
      this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 30 - rand() * 60, 0.9, 1 + (rand() < 0.35 ? 1 : 0), pickOne(BLOOD), 520, 0.5, 4);
    }
    // a little comes back out of the near side; and a mist hangs in the air for a moment
    for (let i = 0; i < (big ? 4 : 2); i++) this.part(x, y, -ca * (40 + rand() * 70) + (rand() - 0.5) * 50, -sa * (40 + rand() * 70) - 30 - rand() * 50, 0.7, 1, pickOne(BLOOD), 520, 0.5, 4);
    for (let i = 0; i < (big ? 4 : 2); i++) this.part(x + ca * 3, y + sa * 3, ca * (20 + rand() * 30) + (rand() - 0.5) * 20, sa * (20 + rand() * 30) - 8, 0.28 + rand() * 0.16, 2 + ((rand() * 2) | 0), pickOne(["#a8202c", "#c2303a", "#7a1420"]), -10, 3, 1);
  }
  /** blood left on the arena where it landed: a little puddle on a floor (w its half-width), a streak running down a wall */
  private splat(x: number, y: number, w: number) {
    const m = this.map, g = this.tg, px = Math.floor(x), py0 = Math.floor(y);
    for (let d = 0; d <= 4; d++) {
      const py = py0 + d;
      if (!solidPx(m, px, py)) continue;
      if (d === 0 && solidPx(m, px, py - 1)) break;
      for (let i = -w; i <= w; i++) {
        if (!solidPx(m, px + i, py) || solidPx(m, px + i, py - 1)) continue;
        g.fillStyle = w > 0 && Math.abs(i) >= w ? "#5e0f18" : (i + px) % 3 === 0 ? "#c2303a" : "#96202a";
        g.fillRect(px + i, py, 1, Math.abs(i) < w - 1 ? 2 : 1);
      }
      return;
    }
    for (const sx of [1, -1, 2, -2]) {
      if (!solidPx(m, px + sx, py0)) continue;
      const len = 2 + w + ((rand() * 3) | 0);
      for (let j = 0; j < len; j++) {
        if (!solidPx(m, px + sx, py0 + j)) break;
        g.fillStyle = j === 0 ? "#c2303a" : j > len - 2 ? "#5e0f18" : "#96202a";
        g.fillRect(px + sx, py0 + j, 1, 1);
      }
      return;
    }
  }

  /** where the hands hold the weapon: waist high, a little forward, like the survivors */
  private pivot(s: Sol) { return { x: s.x + Math.round(Math.cos(s.aim) * 2), y: s.y - 5 + Math.round(s.duck * 2) }; }
  private muzzle(s: Sol) {
    const sl = s.slots[s.cur], W = wspr(s.team, sl ? sl.id : "pistol"), ca = Math.cos(s.aim), sa = Math.sin(s.aim), p = this.pivot(s), fy = ca < 0 ? -1 : 1;
    const m = W.c.width - W.px + 2, by = (W.bar + 0.5) * fy;
    return { x: p.x + ca * m - sa * by, y: p.y + sa * m + ca * by };
  }
  private clear(x0: number, y0: number, x1: number, y1: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 4);
    for (let i = 1; i < n; i++) if (solidPx(this.map, x0 + ((x1 - x0) * i) / n, y0 + ((y1 - y0) * i) / n)) return false;
    return true;
  }

  private fire(s: Sol, sl: Slot, w: AWDef) {
    if (isBlade(w.kind)) { this.startSwing(s, false); return; }
    if (w.kind === "portal") { this.firePortal(s, w); return; }
    if (s.fireCd > 0 || s.reload > 0) return;
    if (sl.mag <= 0) {
      if (sl.ammo > 0) this.reloadStart(s);
      else { s.fireCd = 0.35; if (s.me) audio.play("click", 0.6); }
      return;
    }
    sl.mag--;
    s.fireCd = w.cd;
    s.shield = 0;
    s.loud = 1.45;
    s.flashT = w.id === "sniper" || w.id === "shotgun" ? 0.085 : 0.068;
    s.smokeT = w.kind === "laser" || w.kind === "flame" ? 0 : Math.min(1.6, s.smokeT + (w.id === "shotgun" || w.id === "sniper" ? 0.9 : 0.32));
    s.seed = rand();
    const a0 = s.aim, ca = Math.cos(a0), sa = Math.sin(a0), pv = this.pivot(s), mz = this.muzzle(s);
    const ok = this.clear(pv.x, pv.y, mz.x, mz.y), ox = ok ? mz.x : pv.x, oy = ok ? mz.y : pv.y;
    const spread = w.spread * (s.ground ? 1 : 1.28) * (1 + s.bloom) * (s.bot ? 1.12 : 1) * (s.sprint ? 1.35 : 1), laser = w.kind === "laser" || w.kind === "shock", B = w.kind === "shock" ? ELEC : BEAM[s.team];
    if (w.kind === "flame") {
      for (let i = 0; i < 2; i++) this.shots.push(this.mkShot(s, w, ox, oy, a0 + (rand() - 0.5) * 2 * spread, w.speed * (0.8 + rand() * 0.4), w.life * (0.7 + rand() * 0.5)));
      if (rand() < 0.45) this.flashes.push({ x: mz.x + ca * 4, y: mz.y + sa * 4, r: 24, life: 0.05, max: 0.05, col: "#ff9a3c" });
    } else {
      for (let p = 0; p < w.pellets; p++) {
        const a = a0 + (w.pellets > 1 ? (rand() - 0.5) * 2 * spread : (rand() + rand() - 1) * spread);
        this.shots.push(this.mkShot(s, w, ox, oy, a, w.speed * (w.pellets > 1 ? 0.85 + rand() * 0.3 : 1), w.life));
      }
      // rich weapon-specific muzzle flash light, shock rings, muzzle brake sparks & barrel blast smoke!
      const flR = w.kind === "rocket" ? 56 : w.id === "bolter" ? 44 : w.id === "sniper" ? 46 : w.id === "shotgun" ? 44 : w.id === "magnum" ? 38 : laser ? 32 : w.id === "pistol" ? 24 : 32;
      this.flashes.push({ x: mz.x + ca * 2, y: mz.y + sa * 2, r: flR * 1.3, life: 0.085, max: 0.085, col: laser ? B.col : w.id === "bolter" ? "#ffb83a" : w.id === "magnum" ? "#ffe470" : "#ffd27a" });
      this.rings.push({ x: mz.x + ca * 5, y: mz.y + sa * 5, r: w.id === "shotgun" ? 26 : w.id === "sniper" || w.id === "bolter" ? 21 : w.id === "magnum" ? 17 : laser ? 13 : 13, life: 0, max: 0.22, col: laser ? B.col : w.id === "sniper" ? "#ffffff" : w.id === "bolter" ? "#ffd24a" : "#ffb347" });
      if (w.id === "shotgun" || w.id === "sniper" || w.id === "magnum" || w.id === "bolter") {
        this.rings.push({ x: mz.x + ca * 9, y: mz.y + sa * 9, r: w.id === "shotgun" ? 16 : 12, life: 0, max: 0.15, col: "#ffffff" });
      }
      this.stars.push({ x: mz.x + ca * 2, y: mz.y + sa * 2, life: 0.07, col: laser ? B.hot : "#ffffff" });
      const spN = w.id === "shotgun" ? 13 : w.id === "bolter" ? 11 : w.id === "sniper" ? 10 : w.id === "magnum" ? 10 : laser ? 7 : 6;
      for (let i = 0; i < spN; i++) {
        const cone = w.id === "shotgun" ? 0.55 : w.id === "bolter" ? 0.36 : 0.28, sa2 = a0 + (rand() - 0.5) * cone, spd = 150 + rand() * 220;
        this.part(mz.x, mz.y, Math.cos(sa2) * spd, Math.sin(sa2) * spd, 0.12 + rand() * 0.1, 1, laser ? pickOne([B.col, B.hot, "#ffffff"]) : pickOne(w.id === "bolter" ? BOLTC : ["#ffffff", "#ffe868", "#ff9e38"]), 60, 6, i % 2 === 0 ? 2 : 5);
      }
      // muzzle-brake cross-vents for Bolter, Sniper & AK-47!
      if (w.id === "sniper" || w.id === "rifle" || w.id === "bolter") {
        const px2 = -sa, py2 = ca;
        for (const sd of [-1, 1]) {
          for (let i = 0; i < (w.id === "bolter" || w.id === "sniper" ? 4 : 2); i++) {
            this.part(mz.x - ca * 2, mz.y - sa * 2, px2 * sd * (75 + rand() * 95) - ca * 20, py2 * sd * (75 + rand() * 95) - sa * 20, 0.11 + rand() * 0.06, 1, pickOne(["#ffffff", "#ffe45c", "#ff8a28"]), 0, 7, 5);
          }
        }
      }
      if (!laser) for (let i = 0; i < (w.id === "shotgun" ? 7 : w.id === "sniper" || w.id === "bolter" ? 5 : 3); i++) this.part(mz.x + ca * 4, mz.y + sa * 4, ca * (32 + rand() * 28) + (rand() - 0.5) * 24, sa * (32 + rand() * 28) - 10 + (rand() - 0.5) * 16, 0.65 + rand() * 0.45, 2 + (w.id === "shotgun" || w.id === "bolter" ? 1 : 0), pickOne(["#ebe4d6", "#bfb8ae", "#8e887e"]), -20, 3, 1);
      if (w.id === "magnum") for (let i = 0; i < 10; i++) this.part(mz.x, mz.y, ca * (110 + rand() * 70) + (rand() - 0.5) * 95, sa * (110 + rand() * 70) - 20 + (rand() - 0.5) * 95, 0.48, 1, pickOne(["#fff8cc", "#ffd700", "#f5c542"]), 75, 3.8, 5);
      if (w.kind === "rocket") {
        this.flashes.push({ x: pv.x - ca * 10, y: pv.y - sa * 10, r: 34, life: 0.1, max: 0.1, col: "#ff9a3c" });
        for (let i = 0; i < 14; i++) this.part(pv.x - ca * 10, pv.y - sa * 10, -ca * (100 + rand() * 80) + (rand() - 0.5) * 55, -sa * (100 + rand() * 80) + (rand() - 0.5) * 55, 0.55 + rand() * 0.25, 3, pickOne(["#ffffff", "#ffd27a", "#ff9a3c", "#b9b3a8"]), -14, 3, i < 6 ? 5 : 1);
      }
    }
    if (w.kind === "bullet" || w.kind === "bolt") this.shell(s, w.id === "bolter" ? "#ffd748" : w.id === "shotgun" ? "#e0524a" : w.id === "sniper" || w.id === "magnum" ? "#ffe066" : "#f1cf6a");
    s.bloom = Math.min(1.5, s.bloom + w.bloom);
    s.recoil = 1;
    const kickScale = s.skin === ASTARTES ? 0.55 : 1;
    s.vx -= ca * w.kick * kickScale * (s.ground ? 0.28 : 0.85);
    if (!s.ground) s.vy -= sa * w.kick * kickScale * 0.55;
    if (w.snd) this.sfx(w.snd, mz.x, mz.y, w.vol, w.pitch * (0.96 + rand() * 0.08));
    if (w.kind === "bullet" || w.kind === "bolt" || w.kind === "laser" || w.kind === "shock") this.sfx("kick", mz.x, mz.y, (s.me ? 0.85 : 0.45) * clamp(0.4 + w.dmg / 50, 0.4, 1.05), w.kind === "bolt" ? 0.78 : 0.9 + rand() * 0.2);
    if (s === this.focus()) {
      this.cam.kx -= ca * Math.min(8, w.kick * 0.08 + 1.5);
      this.cam.ky -= sa * Math.min(8, w.kick * 0.08 + 1.5);
      this.cam.shake = Math.max(this.cam.shake, w.shake);
    }
    if (s.me) {
      this.combat = 1;
      if (w.id === "shotgun" || w.id === "sniper" || w.id === "magnum") this.hitStop = Math.max(this.hitStop, w.id === "sniper" ? 0.032 : 0.018);
    }
  }
  private mkShot(s: Sol, w: AWDef, x: number, y: number, a: number, v: number, life: number): Shot {
    return { x, y, px: x, py: y, sx: x, sy: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life, by: s, w: w.id, kind: w.kind, dmg: w.dmg, hit: [], tried: [], bounce: w.kind === "saw" ? 3 : 0, r: w.kind === "flame" ? 2 : 3, spin: 0, dist: 0, slot: 0, wz: false, crit: rand() < (CRIT[w.id] ?? 0) * this.critMul(s) };
  }
  /** a spent case spins out of the gun, glinting, and bounces on the ground */
  private shell(s: Sol, col: string) {
    const pv = this.pivot(s);
    this.part(pv.x + Math.cos(s.aim) * 4, pv.y + Math.sin(s.aim) * 4 - 1, -s.face * (35 + rand() * 45), -95 - rand() * 65, 2.6, 2, col, 520, 0.5, 3);
  }

  // ───────────── katana & lightsaber: 4-hit combo with vertical AND 2.5D horizontal side-sweeps! ─────────────
  private startSwing(s: Sol, forceHoriz = false) {
    const sl = s.slots[s.cur];
    if (!sl || !isBlade(AWEP[sl.id].kind)) return;
    const isKatana = sl.id === "katana", isAxe = sl.id === "axe", isChain = sl.id === "chainsword";
    if (s.swingT > 0 || s.fireCd > 0 || (sl.id === "saber" && s.saberOn < 0.55)) return;
    if (forceHoriz) s.combo = s.swingKind === 1 ? 2 : 1;
    else s.combo = this.t - s.lastSwing < 0.78 ? (s.combo + 1) % 4 : (Math.abs(s.vx) > 45 && rand() < 0.5 ? 1 : 0);
    if (isAxe) s.combo = forceHoriz ? 1 : s.combo === 2 ? 3 : s.combo;
    s.swingKind = s.combo;
    s.swingPlane = s.combo === 0 ? "vert" : s.combo === 1 || s.combo === 2 ? "horiz" : (isKatana || isChain) ? "horiz" : isAxe ? "vert" : "spin";
    s.swingDur = isAxe ? (s.combo === 3 ? 0.5 : 0.36) : isChain ? (s.combo === 3 ? 0.38 : 0.29) : s.combo === 3 ? (isKatana ? 0.34 : 0.44) : isKatana ? 0.25 : 0.29;
    s.swingT = s.swingDur;
    s.swingDir = s.face;
    s.swingZ = 0;
    s.swingScale = 1;
    s.swingHit = [];
    s.fireCd = s.swingDur + 0.025;
    s.lastSwing = this.t + s.swingDur;
    s.shield = 0;
    if (isChain) s.chainRev = 1;
    // powerful forward assault lunge (Execution Jet-Lunge on Chainsword 4th strike!)
    const lunge = s.combo === 3 && isChain ? (s.ground ? 225 : 165) : s.combo === 3 && isKatana ? (s.ground ? 195 : 135) : s.swingPlane === "horiz" ? (s.ground ? (isChain ? 120 : 100) : 72) : (s.ground ? (isChain ? 88 : 70) : 45);
    s.vx += Math.cos(s.aim) * lunge * 0.75 + s.face * lunge * 0.35;
    if (s.combo === 3 && !s.ground) s.vy = Math.min(s.vy, -34) + Math.sin(s.aim) * 62;
    const pv = this.pivot(s), ca = Math.cos(s.aim), sa = Math.sin(s.aim);
    const B = BEAM[s.team];
    const col = isChain ? (s.combo === 3 ? "#ff3828" : "#ff9e24") : isAxe ? "#ff5a1e" : isKatana ? (s.combo === 3 ? TEAMS[s.team].color : "#9ee8ff") : B.col;
    const hot = isChain ? "#fff6b8" : isAxe ? "#ffe9a0" : isKatana ? "#ffffff" : B.hot;
    this.slashArcs.push({
      x: pv.x + ca * (s.swingPlane === "horiz" ? 7 : 3),
      y: pv.y + sa * (s.swingPlane === "horiz" ? 7 : 3),
      ang: s.aim,
      dir: s.combo === 2 ? -s.face : s.face,
      plane: s.swingPlane,
      r: isChain ? (s.combo === 3 ? 38 : 33) : s.combo === 3 ? 34 : s.swingPlane === "horiz" ? 30 : 27,
      col, hot, katana: isKatana, chain: isChain,
      life: 0, max: s.swingDur * 0.94,
    });
    if (isChain) {
      // ferocious shower of grinding adamantium chain-sparks & exhaust blast!
      this.sparkBurst(pv.x + ca * 14, pv.y + sa * 14, s.aim + Math.PI, s.combo === 3 ? 14 : 8, CHAINC, 1.05);
      if (s.combo === 3) {
        this.rings.push({ x: pv.x + ca * 16, y: pv.y + sa * 16, r: 28, life: 0, max: 0.26, col: "#ffd24a" });
        this.flashes.push({ x: pv.x + ca * 16, y: pv.y + sa * 16, r: 48, life: 0.12, max: 0.12, col: "#ff7a1e" });
        if (rand() < 0.45) this.callout(s, "chainsaw");
      }
    }
    if (s.swingPlane === "horiz") {
      const cnt = s.combo === 3 ? 12 : 6;
      for (let i = 0; i < cnt; i++) {
        const sp = 110 + rand() * 140;
        this.part(pv.x + ca * (8 + rand() * 16), pv.y + sa * (8 + rand() * 16) + (rand() - 0.5) * 6, ca * sp + (rand() - 0.5) * 50, sa * sp + (rand() - 0.5) * 22, 0.16 + rand() * 0.1, 1, pickOne([col, hot, "#ffffff"]), 20, 5, 5);
      }
      if (isKatana && s.combo === 3) {
        this.rings.push({ x: pv.x + ca * 14, y: pv.y + sa * 14, r: 22, life: 0, max: 0.24, col: "#ffffff" });
        this.flashes.push({ x: pv.x + ca * 14, y: pv.y + sa * 14, r: 36, life: 0.1, max: 0.1, col });
      }
    }
    if (isChain) this.sfx("chainrev", s.x, s.y, s.me ? 0.95 : 0.58, s.combo === 3 ? 0.84 : s.combo === 2 ? 1.14 : 0.96 + rand() * 0.14);
    else if (isAxe) this.sfx("axeswing", s.x, s.y, s.me ? 0.9 : 0.5, s.combo === 3 ? 0.75 : 0.95 + rand() * 0.15);
    else if (isKatana) {
      this.sfx(s.combo === 3 ? "swoosh" : "slash", s.x, s.y, s.me ? 0.85 : 0.5, s.combo === 3 ? 0.85 : s.swingPlane === "horiz" ? 1.18 + rand() * 0.12 : 0.95 + rand() * 0.12);
    } else {
      this.sfx("saberswing", s.x, s.y, s.me ? 0.8 : 0.45, s.combo === 3 ? 0.84 : s.swingPlane === "horiz" ? 1.12 + rand() * 0.12 : 0.94 + rand() * 0.12);
    }
    if (s.me) {
      this.combat = 1;
      this.rollV += (s.combo === 2 ? -s.face : s.face) * (s.combo === 3 ? 1.25 : 0.65) * (s.swingPlane === "horiz" ? 0.72 : 1);
      this.cam.kx += ca * (isChain ? 4.2 : 3); this.cam.ky += sa * (isChain ? 2.8 : 2);
      if (isChain) this.cam.shake = Math.max(this.cam.shake, s.combo === 3 ? 3.8 : 2.1);
      if ((isKatana || isChain) && s.combo === 3) { this.rush = 0.85; this.rushA = s.aim; }
    }
  }

  /** blade angle + 2.5D horizontal foreshortening (swingZ & swingScale) for Katana, Lightsaber, Argent Axe & Chainsword */
  private bladePose(s: Sol): { ang: number; z: number; scale: number } {
    const f = s.face, sl = s.slots[s.cur], isKatana = !!sl && sl.id === "katana", isAxe = !!sl && sl.id === "axe", isChain = !!sl && sl.id === "chainsword";
    const g0 = s.aim - f * ((isAxe ? 1.25 : isChain ? 0.98 : isKatana ? 1.05 : 0.95) + s.holoK * 0.9);
    // (the chainsword vibrates menacingly in the gauntlet with the roar of its two-stroke motor)
    const vib = isChain ? Math.sin(this.t * 95 + s.id) * 0.032 : Math.sin(this.t * 2.4 + s.id) * 0.05;
    if (s.swingT <= 0) return { ang: g0 + vib, z: 0.2, scale: 1 };
    const p = 1 - s.swingT / s.swingDur;
    if (s.swingKind === 0 || (s.swingKind === 3 && isAxe)) {
      const sw = p < 0.25 ? -1.35 * easeOut(p / 0.25) : p < 0.72 ? -1.35 + 4.05 * smooth((p - 0.25) / 0.47) : 2.7 * (1 - smooth((p - 0.72) / 0.28));
      return { ang: g0 + f * sw + (isChain ? vib * 0.8 : 0), z: 0.5, scale: 1 };
    }
    if (s.swingKind === 1 || s.swingKind === 2 || (s.swingKind === 3 && (isKatana || isChain))) {
      // TRUE 2.5D HORIZONTAL SIDE-SWEEP! Sweeps horizontally across Z-depth (behind body -> whips wide across front -> opposite side)
      const rev = s.swingKind === 2 ? -1 : 1;
      const phi = p < 0.18
        ? (-Math.PI * 0.82 * easeOut(p / 0.18)) * rev
        : p < 0.72
          ? ((-Math.PI * 0.82) + Math.PI * 1.66 * smooth((p - 0.18) / 0.54)) * rev
          : (Math.PI * 0.84 * (1 - smooth((p - 0.72) / 0.28))) * rev;
      // cos(phi) controls horizontal projection forward/backward; sin(phi) sweeps across foreground/background Z-plane!
      const z = Math.sin(phi);
      const proj = Math.cos(phi);
      const tilt = (s.swingKind === 2 ? -0.14 : 0.12) * Math.sin(phi) + (s.swingKind === 3 ? 0.04 : 0);
      // blade points forward during peak strike (proj > 0) and whips cleanly to rear follow-through (proj < 0)
      const ang = s.aim + f * tilt + (proj < 0 ? Math.PI : 0);
      const scale = clamp(0.28 + Math.abs(proj) * 0.92 + (s.swingKind === 3 ? 0.18 : 0), 0.28, 1.32);
      return { ang, z, scale };
    }
    // Lightsaber 360° full spin finisher
    return { ang: g0 + f * PI2 * smooth(p), z: 0.7, scale: 1.08 };
  }
  private bladeAng(s: Sol) { return this.bladePose(s).ang; }

  private swingTick(s: Sol, dt: number) {
    const sl = s.slots[s.cur], isKatana = !!sl && sl.id === "katana", isSaber = !!sl && sl.id === "saber", isAxe = !!sl && sl.id === "axe", isChain = !!sl && sl.id === "chainsword";
    if (!isKatana && !isAxe && !isChain && (!isSaber || s.saberOn <= 0)) { s.trail.length = 0; s.swingZ = 0; s.swingScale = 1; return; }
    if (s.swingT > 0) s.swingT -= dt;
    s.bladePrev = s.blade;
    const pose = this.bladePose(s);
    s.blade = pose.ang;
    s.swingZ = pose.z;
    s.swingScale = pose.scale;
    s.trail.unshift(s.blade);
    if (s.trail.length > 8) s.trail.length = 8;
    if (s.swingT > 0 && s.swingKind === 3 && rand() < dt * 40) {
      this.ghosts.push({ x: s.x, y: s.y, face: s.face, team: s.team, skin: s.skin, col: isChain ? "#ffd24a" : isAxe ? "#ff6a1e" : isKatana ? "#9ee8ff" : BEAM[s.team].col, life: 0, max: 0.24 });
    }
    if (s.swingT <= 0) return;
    const p = 1 - s.swingT / s.swingDur, k = s.swingKind;
    if (isAxe) {
      if (rand() < dt * 70) this.part(s.x + Math.cos(s.blade) * 20, s.y - 5 + Math.sin(s.blade) * 20, (rand() - 0.5) * 50, -20 - rand() * 50, 0.2 + rand() * 0.25, 1 + ((rand() * 2) | 0), pickOne(AXC), -40, 2, 5);
      if (k === 3 && p > 0.58 && !s.swingHit.includes(-1)) { s.swingHit.push(-1); this.axeSlam(s); }
    }
    if (isChain && p > 0.42 && !s.swingHit.includes(-2)) {
      // roaring adamantium teeth chew right into nearby rock faces!
      s.swingHit.push(-2);
      const rx = s.x + Math.cos(s.aim) * 20, ry = s.y - 6 + Math.sin(s.aim) * 20;
      if (solidPx(this.map, rx, ry)) {
        this.blame = s;
        this.hitTerrain(rx, ry, 58, s.aim);
        this.sparkBurst(rx, ry, s.aim, 12, CHAINC, 1.15);
      }
    }
    const cut = s.swingPlane === "horiz" ? (p > 0.15 && p < 0.8) : k === 0 ? (p > 0.2 && p < 0.76) : (p > 0.08 && p < 0.94);
    if (!cut) return;
    const pv = this.pivot(s);
    const reach = SABER_R + (isChain ? 5 : 0) + (k === 3 ? 9 : s.swingPlane === "horiz" ? 4 : 0);
    if (p > 0.35 && p < 0.5) this.pushRagdolls(pv.x + Math.cos(s.aim) * 16, pv.y + Math.sin(s.aim) * 16, 28, isChain ? 270 : 210, false, s.aim);
    for (const e of this.sol) {
      if (!e.alive || e.team === s.team) continue;
      // the chainsword bites TWICE on a clean pass (initial bite + brutal follow-through rip at p > 0.54)!
      const secondTag = -1000 - e.id;
      const already = s.swingHit.includes(e.id);
      if (already && (!isChain || p < 0.54 || s.swingHit.includes(secondTag))) continue;
      const ex = e.x, ey = e.y - 9, d = Math.hypot(ex - pv.x, ey - pv.y);
      if (d > reach) continue;
      const ea = Math.atan2(ey - pv.y, ex - pv.x);
      if (s.swingPlane === "horiz") {
        if (Math.abs(angDiff(s.aim, ea)) > 1.28 && d > 15) continue;
      } else {
        const d0 = angDiff(s.bladePrev, ea), d1 = angDiff(s.blade, ea);
        const crossed = ((d0 <= 0 && d1 >= 0) || (d0 >= 0 && d1 <= 0)) && Math.abs(d0) + Math.abs(d1) < Math.PI;
        if (!crossed && Math.abs(d1) > 0.5 && d > 14) continue;
      }
      s.swingHit.push(already ? secondTag : e.id);
      const es = e.slots[e.cur];
      if (!already && es && isBlade(AWEP[es.id].kind) && (es.id !== "saber" || e.saberOn > 0.6) && e.swingT > 0 && rand() < 0.6) { this.clash(s, e); continue; }
      if (e.shield > 0) continue;
      const hitAng = s.swingPlane === "horiz" ? s.aim + (k === 2 ? -0.15 : 0.15) : s.blade + s.swingDir * Math.PI * 0.5;
      const baseDmg = isChain ? (already ? 26 : AWEP.chainsword.dmg) : isAxe ? AWEP.axe.dmg : isKatana ? AWEP.katana.dmg : AWEP.saber.dmg;
      const mul = k === 3 ? (isChain ? 1.32 : isAxe ? 1.3 : isKatana ? 1.25 : 0.9) : s.swingPlane === "horiz" ? 1.06 : 1;
      const knock = (already ? 175 : (k === 3 ? 310 : s.swingPlane === "horiz" ? 255 : 225)) * (isAxe || isChain ? 1.22 : 1);
      // chainsword teeth tear straight through hologram shields (+75% shield shred!)
      if (this.holoFacing(e, pv.x, pv.y)) {
        const a = Math.atan2(pv.y - this.holoY(e), pv.x - e.x);
        this.holoHit(e, baseDmg * mul * (isChain ? 1.75 : 1), s, e.x + Math.cos(a) * HOLO_R, this.holoY(e) + Math.sin(a) * HOLO_R);
        s.vx += Math.cos(a) * (isChain ? 40 : 70);
        if (isChain) this.sfx("chainrip", ex, ey, 0.85, 1.1);
        if (s.me) this.hitStop = Math.max(this.hitStop, 0.032);
        continue;
      }
      const crit = (!already && k === 3) || e.face === Math.sign(e.x - s.x) || rand() < (CRIT[sl.id] ?? 0) * this.critMul(s);
      this.hurt(e, baseDmg * mul, s, sl.id, crit ? Math.atan2(Math.sin(s.aim) * 0.6, Math.cos(s.aim)) : hitAng, knock, false, crit);
      if (isChain) this.sfx("chainrip", ex, ey, already ? 0.8 : 1, already ? 1.15 : 0.9 + rand() * 0.2);
      else if (isAxe) this.sfx("axehit", ex, ey, 0.9, 0.9 + rand() * 0.2);
      else this.sfx(isKatana ? "deflect" : "saberclash", ex, ey, 0.7, isKatana ? 1.15 : 0.72);
      if (s.me) {
        this.hitStop = Math.max(this.hitStop, isChain ? (already ? 0.036 : 0.062) : isAxe ? 0.06 : k === 3 ? 0.048 : 0.032);
        this.zoomKick = Math.min(0.32, this.zoomKick + (isChain ? 0.075 : 0.06)); this.rollV += s.swingDir * (isChain ? 0.95 : 0.8);
        this.cam.kx += Math.cos(s.aim) * (isChain ? 5 : 4); this.cam.ky += Math.sin(s.aim) * 3;
        this.cam.shake = Math.max(this.cam.shake, isChain ? 5.2 : isAxe ? 4.5 : 3);
      }
    }
  }
  /** two blades meet: they lock, flash and throw each other apart */
  private clash(a: Sol, b: Sol) {
    const x = (a.x + b.x) / 2, y = (a.y + b.y) / 2 - 10, dir = b.x >= a.x ? 1 : -1;
    a.vx -= dir * 180; b.vx += dir * 180; a.swingT = 0; b.swingT = 0; a.fireCd = b.fireCd = 0.28;
    this.flashes.push({ x, y, r: 66, life: 0.16, max: 0.16, col: "#ffffff" });
    this.rings.push({ x, y, r: 28, life: 0, max: 0.3, col: "#ffffff" });
    this.hitfx.push({ x, y, ang: rand() * PI2, r: 18, kind: 1, life: 0, max: 0.18, col: "" });
    for (const s of [a, b]) for (let i = 0; i < 10; i++) this.part(x, y, (rand() - 0.5) * 260, (rand() - 0.5) * 210 - 40, 0.3 + rand() * 0.3, 1, pickOne([BEAM[s.team].col, BEAM[s.team].hot, "#ffffff", "#ffe45c"]), 260, 1.5, 5);
    this.sfx("saberclash", x, y, 1, 0.92);
    this.cam.shake = Math.max(this.cam.shake, 4.5);
    if (a.me || b.me) this.hitStop = Math.max(this.hitStop, 0.05);
  }
  /** a bullet or a bolt meets a Katana or Lightsaber held towards it: deflected right back! */
  private deflect(b: Shot, e: Sol) {
    const sp = Math.hypot(b.vx, b.vy);
    let a: number;
    if (e.me) a = e.aim + (rand() - 0.5) * 0.07;
    else { const o = b.by; a = Math.atan2(o.y - 9 - b.y, o.x - b.x) + (rand() - 0.5) * 0.28; }
    b.vx = Math.cos(a) * sp; b.vy = Math.sin(a) * sp; b.by = e; b.hit = []; b.tried = []; b.life = Math.max(b.life, 0.65); b.dist = 0; b.px = b.x; b.py = b.y; b.sx = b.x; b.sy = b.y;
    const isKatana = e.slots[e.cur]?.id === "katana";
    const B = BEAM[e.team];
    const col = isKatana ? "#ffe470" : B.col;
    const hot = isKatana ? "#ffffff" : B.hot;
    this.hitfx.push({ x: b.x, y: b.y, ang: a, r: 11, kind: 2, life: 0, max: 0.15, col });
    this.rings.push({ x: b.x, y: b.y, r: 16, life: 0, max: 0.18, col });
    this.flashes.push({ x: b.x, y: b.y, r: 34, life: 0.1, max: 0.1, col });
    for (let i = 0; i < 9; i++) this.part(b.x, b.y, Math.cos(a) * 65 + (rand() - 0.5) * 180, Math.sin(a) * 65 + (rand() - 0.5) * 180 - 30, 0.25 + rand() * 0.2, 1, pickOne([col, hot, "#ffffff"]), 260, 1.5, 5);
    this.sfx(isKatana ? "deflect" : "saberclash", b.x, b.y, 0.78, 1.12 + rand() * 0.2);
    e.recoil = 0.6;
    if (e.me) this.texts.push({ x: e.x, y: e.y - 30, text: isKatana ? "PARRY!" : "TANGKIS!", col, life: 0.85, vy: -22 });
    else if (rand() < 0.15) this.callout(e, "deflect");
  }

  private reloadStart(s: Sol) {
    const sl = s.slots[s.cur];
    if (!sl || s.reload > 0 || isBlade(AWEP[sl.id].kind) || sl.mag >= AWEP[sl.id].mag || sl.ammo <= 0) return;
    s.reload = s.reloadMax = AWEP[sl.id].reload;
    this.sfx("magout", s.x, s.y, s.me ? 0.6 : 0.3);
    if (s.bot && rand() < 0.25) this.callout(s, "reload");
  }
  private swap(s: Sol) {
    const target = s.prevCur >= 0 && s.prevCur < s.slots.length && s.prevCur !== s.cur && s.slots[s.prevCur]
      ? s.prevCur
      : (s.cur + 1) % s.slots.length;
    this.equipSlot(s, target);
  }
  private throwNade(s: Sol) {
    if (s.nades <= 0 || s.nadeCd > 0) return;
    s.nades--;
    s.nadeCd = 0.7;
    const a = s.aim, pv = this.pivot(s);
    this.nades.push({ x: pv.x + Math.cos(a) * 4, y: pv.y - 4 + Math.sin(a) * 4, vx: Math.cos(a) * NADE_V + s.vx * 0.4, vy: Math.sin(a) * NADE_V + s.vy * 0.3, fuse: 2.2, by: s, rot: 0, beep: false });
    this.sfx("whoosh", s.x, s.y, 0.6);
    if (rand() < 0.5) this.callout(s, "nade");
  }
  private meleeStart(s: Sol) {
    const sl = s.slots[s.cur];
    // when holding Katana or Lightsaber, F triggers an instant crisp HORIZONTAL SIDE-SWEEP!
    if (sl && isBlade(AWEP[sl.id].kind)) { this.startSwing(s, true); return; }
    if (s.meleeCd > 0 || s.reload > 0) return;
    s.melee = 0.28;
    s.meleeCd = 0.55;
    this.sfx("whoosh", s.x, s.y, 0.5, 1.3);
  }
  private meleeHit(s: Sol) {
    let hit = false;
    this.pushRagdolls(s.x + s.face * 12, s.y - 8, 22, 180, false, s.face > 0 ? -0.35 : Math.PI + 0.35);
    for (const e of this.sol) {
      if (!e.alive || e.team === s.team || e.shield > 0) continue;
      const dx = e.x - s.x, dy = e.y - s.y;
      if (Math.abs(dy) < 16 && dx * s.face > -3 && Math.abs(dx) < 20) {
        if (this.holoFacing(e, s.x, s.y - 9)) { const a = Math.atan2(s.y - 9 - this.holoY(e), s.x - e.x); this.holoHit(e, 45, s, e.x + Math.cos(a) * HOLO_R, this.holoY(e) + Math.sin(a) * HOLO_R); }
        else this.hurt(e, e.face === s.face ? 70 : 45, s, "melee", s.face > 0 ? -0.35 : Math.PI + 0.35, 260, false, e.face === s.face); // (a punch in the back is a critical hit)
        hit = true;
      }
    }
    if (hit) this.sfx("thunk", s.x, s.y, 0.8);
  }

  // ───────────── breakable ground ─────────────
  /** at the start of a match nothing is damaged yet - and what must keep the ground under it (the edges of the world, hiding places, things to pick up, flags, braziers, pools, lanterns, trapdoors) cannot be broken at all */
  private terrainInit() {
    const m = this.map, W = m.w, H = m.h, safe = (this.tsafe = new Uint8Array(W * H));
    this.tdmg = new Float32Array(W * H);
    const cv = m.theme.cave[0], ch = (i: number) => Math.round(parseInt(cv.slice(i, i + 2), 16) * 0.58 + 3);
    this.hollowCol = `rgb(${ch(1)},${ch(3)},${ch(5)})`;
    const keep = (tx: number, ty: number) => { if (tx >= 0 && ty >= 0 && tx < W && ty < H) safe[ty * W + tx] = 1; };
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (x < 2 || x >= W - 2 || y < 1 || y >= H - 5) safe[y * W + x] = 1;
    for (const h of m.hides) for (let x = Math.floor((h.x - h.w - 3) / AT); x <= Math.floor((h.x + h.w + 3) / AT); x++) keep(x, Math.floor(h.y / AT));
    for (const p of m.picks) for (let i = -1; i <= 1; i++) keep(Math.floor(p.x / AT) + i, Math.floor(p.y / AT));
    for (const q of m.hatches) { keep(Math.floor(q.x / AT) - 2, Math.floor(q.y / AT)); keep(Math.floor(q.x / AT) + 1, Math.floor(q.y / AT)); }
    for (const d of m.dyn) {
      const tx = Math.floor(d.x / AT), ty = Math.floor(d.y / AT);
      if (d.k === "pool") for (let x = Math.floor((d.x - d.h / 2) / AT) - 1; x <= Math.floor((d.x + d.h / 2) / AT) + 1; x++) keep(x, ty);
      else if (d.k === "lantern") { for (let y = ty - 1; y > ty - 6; y--) if (solidT(tileAt(m, tx, y))) { keep(tx, y); break; } }
      else if (d.k === "flag" || d.k === "brazier" || d.k === "geyser") for (let i = -1; i <= 1; i++) keep(tx + i, ty);
    }
    // what stands on each piece of ground (or hangs from it): it goes when the ground goes
    this.decorOn.clear();
    for (const d of m.decor) {
      if (d.k === "none") continue;
      const ti = (Math.floor(d.y / AT) - (HANGS[d.k] ? 1 : 0)) * W + Math.floor(d.x / AT), a = this.decorOn.get(ti);
      if (a) a.push(d); else this.decorOn.set(ti, [d]);
    }
  }
  /** something strikes the rock at (x, y), travelling along ang, with a force that depends on what it was: the rock chips, cracks - and gives way once it has had enough (a heavy round shakes the rock around it as well) */
  private hitTerrain(x: number, y: number, pow: number, ang: number) {
    const tx = Math.floor(x / AT), ty = Math.floor(y / AT);
    if (pow <= 0 || !solidT(tileAt(this.map, tx, ty))) return;
    this.dmgTile(tx, ty, pow, x, y, ang + Math.PI);
    if (pow >= 20) for (const [dx, dy] of D4) this.dmgTile(tx + dx, ty + dy, pow * 0.3, x, y, ang + Math.PI);
  }
  /** a blast against the rock: it tears a crater out of whatever is close and cracks what is further off (hard rock stands up to more) */
  private blastTerrain(x: number, y: number, r: number, dmg: number) {
    const m = this.map, R = r * 0.95;
    for (let ty = Math.floor((y - R) / AT); ty <= Math.floor((y + R) / AT); ty++)
      for (let tx = Math.floor((x - R) / AT); tx <= Math.floor((x + R) / AT); tx++) {
        if (!solidT(tileAt(m, tx, ty))) continue;
        const cx = tx * AT + 4, cy = ty * AT + 4, f = 1 - Math.hypot(cx - x, cy - y) / R;
        if (f > 0) this.dmgTile(tx, ty, dmg * 2.8 * f * f, cx, cy, Math.atan2(y - cy, x - cx));
      }
  }
  /** one tile takes damage (out: the way its chips fly): at a quarter, a half and three quarters of what it can take another crack runs through it - then it breaks */
  private dmgTile(tx: number, ty: number, pow: number, x: number, y: number, out: number) {
    const m = this.map;
    if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return;
    const ti = ty * m.w + tx, t = m.grid[ti];
    if (!solidT(t) || this.tsafe[ti]) return;
    const hp = TILE_HP[t], was = this.tdmg[ti], now = (this.tdmg[ti] = was + pow);
    if (now >= hp) { this.breakTile(tx, ty, out, pow); return; }
    const s0 = Math.floor((was / hp) * 4), s1 = Math.floor((now / hp) * 4);
    if (s1 <= s0) return;
    // (from where it was struck - or from the middle of the tile, when it was only shaken)
    this.crack(clamp(x, tx * AT + 1, tx * AT + 6.9), clamp(y, ty * AT + 1, ty * AT + 6.9), s1, 4 + s1 * 2);
    if (this.debris > 0) { this.debris--; this.part(tx * AT + 4, ty * AT + 4, Math.cos(out) * 30 + (rand() - 0.5) * 30, Math.sin(out) * 30 - 20, 0.4 + rand() * 0.3, 2, this.dustCol(), 20, 2.5, 1); }
    if (s1 >= 2) this.sfx("rockcrack", tx * AT + 4, ty * AT + 4, 0.3 + s1 * 0.1, 0.8 + rand() * 0.5);
  }
  /** cracks: thin dark lines that wander out from a point through the rock (and on into the rock next to it), each with a faint light edge */
  private crack(x: number, y: number, n: number, len: number) {
    const m = this.map;
    // (each one runs straight for a few pixels, turns sharply, and now and then throws off a side branch - like split rock)
    const run = (cx: number, cy: number, a: number, steps: number, depth: number) => {
      let seg = 0;
      for (let j = 0; j < steps; j++) {
        if (seg-- <= 0) { a += (rand() - 0.5) * 1.4; seg = 1 + ((rand() * 3) | 0); }
        cx += Math.cos(a); cy += Math.sin(a);
        const px = Math.floor(cx), py = Math.floor(cy);
        if (!solidPx(m, px, py)) return;
        for (const g of [this.tg, this.bg0]) {
          g.fillStyle = "rgba(6,4,10,0.85)"; g.fillRect(px, py, 1, 1);
          if (solidPx(m, px + 1, py + 1)) { g.fillStyle = "rgba(255,255,255,0.1)"; g.fillRect(px + 1, py + 1, 1, 1); }
        }
        if (depth < 1 && j > 1 && rand() < 0.16) run(cx, cy, a + (rand() < 0.5 ? 1 : -1) * (0.7 + rand() * 0.5), 2 + ((steps - j) >> 1), depth + 1);
      }
    };
    for (let i = 0; i < n; i++) run(x, y, rand() * PI2, len, 0);
  }
  /**
   * A piece of ground gives way. Where it was: a dark hollow, if it was dug out of the mass of the rock - a gap you can see
   * through, if it stood in a thin wall, a roof, a ledge. Broken edges on what is left around it, chunks and dust in the air;
   * whatever stood on it (or hung from it) goes with it, a portal on it closes, the fallen lying on it fall again - and the
   * bots learn that there is a way through.
   */
  private breakTile(tx: number, ty: number, out: number, pow: number) {
    const m = this.map, W = m.w, ti = ty * W + tx, t = m.grid[ti], T = m.theme, px = tx * AT, py = ty * AT, cx = px + 4, cy = py + 4;
    let mass = 0;
    for (let j = -2; j <= 2; j++) for (let i = -2; i <= 2; i++) { const x = tx + i, y = ty + j; if (x < 0 || y < 0 || x >= W || y >= m.h || solidT(this.grid0[y * W + x])) mass++; }
    const top = !solidT(tileAt(m, tx, ty - 1));
    m.grid[ti] = AIR; this.tdmg[ti] = 0;
    const hollow = mass >= 13;
    for (const g of [this.tg, this.bg0]) {
      g.clearRect(px, py, AT, AT);
      if (hollow) {
        g.fillStyle = T.cave[0]; g.fillRect(px, py, AT, AT);
        g.fillStyle = T.cave[1];
        for (let k = 0; k < 7; k++) g.fillRect(px + ((rand() * 7) | 0), py + ((rand() * 7) | 0), 1 + ((rand() * 2) | 0), 1);
        g.fillStyle = "rgba(4,3,10,0.42)"; g.fillRect(px, py, AT, AT);
        if (solidT(tileAt(m, tx, ty - 1))) { g.fillStyle = "rgba(0,0,0,0.3)"; g.fillRect(px, py, AT, 2); }
      }
      // the broken edge of what still stands around it: bitten into unevenly, with a dark rim along the bite
      for (const [dx, dy] of D4) {
        if (!solidT(tileAt(m, tx + dx, ty + dy))) continue;
        for (let k = 0; k < AT; k++) {
          const bite = rand() < 0.5 ? (rand() < 0.3 ? 2 : 1) : 0;
          // (a strip d deep into the neighbour, starting o in from the edge they share)
          const strip = (o: number, d: number): number[] => (dx ? [dx > 0 ? px + AT + o : px - o - d, py + k, d, 1] : [px + k, dy > 0 ? py + AT + o : py - o - d, 1, d]);
          if (bite) { const r = strip(0, bite); g.clearRect(r[0], r[1], r[2], r[3]); if (hollow) { g.fillStyle = this.hollowCol; g.fillRect(r[0], r[1], r[2], r[3]); } }
          const r = strip(bite, 1);
          g.fillStyle = "rgba(4,3,10,0.55)"; g.fillRect(r[0], r[1], r[2], r[3]);
        }
      }
    }
    for (const g of [this.eg, this.eg0]) if (g) g.clearRect(px, py, AT, AT);
    // the way through, for the bots; and the minimap
    const nx = tx >> 1, ny = ty >> 1;
    const open = (x: number, y: number) => { if (x < 0 || y < 0 || x >= m.nw || y >= m.nh) return false; for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) if (solidT(tileAt(m, x * 2 + i, y * 2 + j))) return false; return true; };
    for (const y of [ny, ny + 1]) if (y >= 1 && y < m.nh) m.nav[y * m.nw + nx] = open(nx, y) && open(nx, y - 1) ? 1 : 0;
    if (!solidT(tileAt(m, nx * 2, ny * 2)) && !solidT(tileAt(m, nx * 2 + 1, ny * 2 + 1))) { this.mg.clearRect(nx, ny, 1, 1); this.mg.fillStyle = "rgba(10,10,18,0.72)"; this.mg.fillRect(nx, ny, 1, 1); }
    const ds = this.decorOn.get(ti);
    if (ds) { this.decorOn.delete(ti); for (const d of ds) this.breakDecor(d); }
    // a piece of a roof or an overhang does not just vanish: it comes down, on whoever stands under it
    if (!solidT(tileAt(m, tx, ty + 1)) && tileAt(m, tx, ty + 1) !== PLAT && this.rocks.length < 18 && rand() < 0.7)
      this.rocks.push({ x: cx, y: cy, vx: Math.cos(out) * 16, vy: 10, rot: 0, vr: (rand() - 0.5) * 10, kind: 1, h: 4, col: (t === ROCK ? T.rock : T.dirt)[1], wait: 0, by: this.blame, hit: [] });
    for (const pair of this.portals) for (const p of pair) if (p && Math.abs(cx - (p.x - p.nx * 4)) <= (p.nx ? 5 : PH + 4) && Math.abs(cy - (p.y - p.ny * 4)) <= (p.ny ? 5 : PH + 4)) this.portalClose(p);
    for (const c of this.corpses) if (Math.abs(c.nodes[1].x - cx) < 34 && Math.abs(c.nodes[1].y - cy) < 34) { c.sleep = false; c.still = 0; }
    const cols = t === ROCK ? T.rock : T.dirt, n = this.debris > 0 ? 4 + ((rand() * 3) | 0) : 1;
    this.debris -= n;
    for (let k = 0; k < n; k++) {
      const a = out + (rand() - 0.5) * 2.2, v = 40 + rand() * 130;
      this.part(cx + (rand() - 0.5) * 6, cy + (rand() - 0.5) * 6, Math.cos(a) * v, Math.sin(a) * v - 50 - rand() * 60, 1 + rand() * 0.9, 2 + ((rand() * 2) | 0), top && k < 2 ? T.top[0] : cols[(rand() * 3) | 0], 600, 0.4, 6);
    }
    for (let k = 0; k < 2; k++) this.part(cx + (rand() - 0.5) * 8, cy + (rand() - 0.5) * 8, (rand() - 0.5) * 50, -15 - rand() * 30, 0.6 + rand() * 0.5, 3 + ((rand() * 2) | 0), this.dustCol(), -10, 2, 1);
    this.sfx("crumble", cx, cy, clamp(0.35 + pow / 250, 0.35, 0.9), 0.8 + rand() * 0.4);
  }
  /** what stood on a piece of ground that has just been shot away (or hung from it) goes with it: the bare rock shows again where it was, its light goes out, and its pieces fly */
  private breakDecor(d: Decor, wait = 0) {
    const m = this.map, i = m.decor.indexOf(d);
    if (i < 0) return;
    m.decor.splice(i, 1);
    const up = !!HANGS[d.k], box = DECOR_BOX[d.k] ?? [8, 16], hw = box[0], h = box[1] || (d.h || 16) + 6;
    const x0 = Math.max(0, Math.round(d.x) - hw), y0 = Math.max(0, up ? Math.round(d.y) - 1 : Math.round(d.y) - h), w = hw * 2 + 1;
    this.stalags = this.stalags.filter((q) => q !== d);
    this.crystals = this.crystals.filter((q) => q !== d);
    m.lights = m.lights.filter((l) => !(Math.abs(l.x - d.x) < 7 && l.y > (up ? d.y - 6 : d.y - h - 4) && l.y < (up ? d.y + h : d.y + 6)));
    // the bare rock again - and whatever else stands in that patch, painted back in
    const near = m.decor.filter((o) => Math.abs(o.x - d.x) < hw + 60 && Math.abs(o.y - d.y) < h + 80), g = this.tg;
    g.clearRect(x0, y0, w, h + 1);
    g.drawImage(this.base, x0, y0, w, h + 1, x0, y0, w, h + 1);
    g.save(); g.beginPath(); g.rect(x0, y0, w, h + 1); g.clip();
    for (const o of near) decorDraw(g, null, o, m.theme);
    g.restore();
    if (this.eg && this.ebase) {
      const e = this.eg, ex = Math.max(0, x0 - 30), ey = Math.max(0, y0 - 30), ew = w + 60, eh = h + 61;
      e.clearRect(ex, ey, ew, eh);
      e.drawImage(this.ebase, ex, ey, ew, eh, ex, ey, ew, eh);
      e.save(); e.beginPath(); e.rect(ex, ey, ew, eh); e.clip();
      for (const o of near) decorDraw(this.scratch, e, o, m.theme);
      e.restore();
    }
    if (d.k === "stalag") {
      // a stalactite does not shatter where it hangs: it falls (after trembling for 'wait') - and whoever brought it down gets the credit for what it does
      this.stalagAt.forEach((q, key) => { if (q === d) this.stalagAt.delete(key); });
      this.rocks.push({ x: d.x, y: d.y, vx: 0, vy: 0, rot: 0, vr: 0, kind: 0, h: 5 + Math.round(d.v * 9), col: "#3e5866", wait, by: this.blame, hit: [] });
      return;
    }
    const gem = d.k === "crystal" || d.k === "bigcrystal" || d.k === "ceilcrystal" || d.k === "shaperrelic", flora = JFLORA[d.k] ?? 0;
    const wood = d.k === "beam" || d.k === "crate" || d.k === "ratsign" || d.k === "palm" || d.k === "barrel" || d.k === "canopytree" || d.k === "banyantree";
    const col = d.k === "shaperrelic" ? "#5ef8ff" : m.theme.decor === "cave" ? hollowAccent(d.v) : GEMS[(d.v * 5) | 0] ?? GEMS[0], cy = up ? d.y + h / 2 : d.y - h / 2, n = Math.min(16, 4 + (((hw * h) / 40) | 0));
    for (let k = 0; k < n; k++)
      this.part(d.x + (rand() - 0.5) * hw * 1.6, cy + (rand() - 0.5) * h * 0.8, (rand() - 0.5) * 150, -40 - rand() * 120, 0.8 + rand() * 0.7, 1 + ((rand() * 2) | 0),
        gem ? pickOne([col, "#ffffff", col])
          : flora === 2 ? pickOne(["#28b850", "#96f86c", "#ff5e9a", "#ffd84a", "#4ee8ff"])
            : flora === 1 ? pickOne(["#1f9646", "#48dc62", "#a8ff78", "#68432b"])
              : wood ? pickOne(["#a67546", "#5e3e22", "#c8965a"]) : this.dustCol(),
        flora ? 240 : 560, flora ? 1.6 : 0.5, gem ? 9 : 6);
    if (gem) { this.flashes.push({ x: d.x, y: cy, r: 30, life: 0.12, max: 0.12, col }); this.sfx("shatter", d.x, cy, 0.7, 0.85 + rand() * 0.4); }
  }
  /** the argent axe brought down on the ground with both hands: a burst of fire that throws back whoever is close - and splits the rock */
  private axeSlam(s: Sol) {
    const pv = this.pivot(s), x = pv.x + Math.cos(s.aim) * 17, gy = this.groundBelow(x, s.y - 8, 22), y = gy >= 0 ? gy : s.y - 4;
    this.flashes.push({ x, y, r: 62, life: 0.16, max: 0.16, col: "#ff8a2a" });
    this.rings.push({ x, y, r: 30, life: 0, max: 0.3, col: "#ffb03a" });
    this.rings.push({ x, y, r: 16, life: 0, max: 0.18, col: "#ffffff" });
    for (let i = 0; i < 16; i++) { const a = -Math.PI * rand(), v = 60 + rand() * 170; this.part(x, y - 1, Math.cos(a) * v, Math.sin(a) * v, 0.3 + rand() * 0.35, 2 + ((rand() * 2) | 0), pickOne(AXC), -30, 2.4, 5); }
    this.sparkBurst(x, y - 2, Math.PI / 2, 12, AXC, 1.1);
    for (let i = 0; i < 8; i++) { const sd = i % 2 ? 1 : -1; this.part(x + sd * rand() * 6, y - 1, sd * (70 + rand() * 120), -10 - rand() * 40, 0.5 + rand() * 0.3, 2 + ((rand() * 2) | 0), this.dustCol(), 40, 2.5, 1); }
    for (const e of this.sol) {
      if (!e.alive || e.team === s.team || e.shield > 0 || s.swingHit.includes(e.id)) continue;
      const d = Math.hypot(e.x - x, e.y - 9 - y);
      if (d > 36 || !this.clear(x, y - 6, e.x, e.y - 9)) continue;
      const ang = Math.atan2(e.y - 9 - y, e.x - x);
      if (this.holoFacing(e, x, y)) { this.holoHit(e, 40, s, e.x - Math.cos(ang) * HOLO_R, this.holoY(e) - Math.sin(ang) * HOLO_R); continue; }
      this.hurt(e, 40 * (1 - d / 70), s, "axe", Math.atan2(-0.7, e.x >= x ? 1 : -1), 250, false);
    }
    this.pushRagdolls(x, y, 44, 300, true);
    this.blame = s;
    this.blastTerrain(x, y + 2, 24, 105);
    this.sfx("slam", x, y, 1);
    if (Math.abs(x - this.cam.x) < 260) this.cam.shake = Math.max(this.cam.shake, 6);
    if (s.me) { this.hitStop = Math.max(this.hitStop, 0.05); this.zoomKick = Math.min(0.3, this.zoomKick + 0.1); this.cam.ky += 6; }
  }

  // ───────────── the tesla gun ─────────────
  /** a tesla bolt has struck e: stunned for a second - and the charge leaps on to the three of their side who are nearest, each of them stunned for 0.3 s */
  private electrocute(e: Sol, by: Sol) {
    const ex = e.x, ey = e.y - 9;
    this.zap(e, ZAP_T);
    const near = this.sol.filter((o) => o !== e && o.alive && o.team === e.team && o.shield <= 0 && !o.hide && Math.hypot(o.x - ex, o.y - 9 - ey) < ZAP_R)
      .sort((a, b) => Math.hypot(a.x - ex, a.y - 9 - ey) - Math.hypot(b.x - ex, b.y - 9 - ey)).slice(0, ZAP_N);
    for (const o of near) {
      this.bolts.push({ x0: ex, y0: ey, x1: o.x, y1: o.y - 9, life: 0, max: 0.34 });
      this.zap(o, ZAP_CHAIN);
      this.hurt(o, 5, by, "tesla", Math.atan2(o.y - 9 - ey, o.x - ex), 0, false);
    }
    this.flashes.push({ x: ex, y: ey, r: 44, life: 0.14, max: 0.14, col: ELEC.col });
    this.rings.push({ x: ex, y: ey, r: 20, life: 0, max: 0.26, col: ELEC.col });
    this.sfx("shock", ex, ey, 0.9);
    if (by.me) { this.hitStop = Math.max(this.hitStop, 0.03); this.texts.push({ x: ex, y: ey - 28, text: near.length ? `SETRUM X${near.length + 1}` : "SETRUM!", col: ELEC.col, life: 0.9, vy: -16 }); }
  }
  /** stunned by lightning for a while: nothing answers - not the legs, not the jetpack, not the trigger (a charge on top of a charge, or just after one, cannot take hold: they only flinch) */
  private zap(e: Sol, dur: number) {
    if (!e.alive) return;
    if (e.zap > 0 || e.zapImm > 0) { e.stun = Math.max(e.stun, 0.15); return; }
    e.zap = dur; e.zapImm = dur + 1.3; e.dizzy = Math.max(e.dizzy, dur); e.sprint = false;
    if (e.me) { this.texts.push({ x: e.x, y: e.y - 32, text: "TERSETRUM!", col: ELEC.col, life: 0.9, vy: -14 }); this.cam.shake = Math.max(this.cam.shake, 3); }
  }
  /** a tesla bolt bursts on the rock (ang: the way it was going): sparks thrown back, and little arcs that crawl over the surface */
  private zapBurst(x: number, y: number, ang: number) {
    this.sparkBurst(x, y, ang, 8, ELC, 0.9);
    this.flashes.push({ x, y, r: 28, life: 0.1, max: 0.1, col: ELEC.col });
    this.rings.push({ x, y, r: 10, life: 0, max: 0.16, col: ELEC.col });
    for (let i = 0; i < 2; i++) { const a = rand() * PI2, r = 10 + rand() * 12; this.bolts.push({ x0: x, y0: y, x1: x + Math.cos(a) * r, y1: y + Math.sin(a) * r, life: 0, max: 0.14 }); }
    this.sfx("shock", x, y, 0.35, 1.3);
  }

  // ───────────── portals ─────────────
  /** the portal gun: a ball of light that opens a portal where it strikes a flat face of rock - first one, then the other, turn about */
  private firePortal(s: Sol, w: AWDef) {
    if (s.fireCd > 0) return;
    s.fireCd = w.cd; s.shield = 0; s.recoil = 1; s.flashT = 0.07; s.seed = rand(); s.loud = 1;
    const pv = this.pivot(s), mz = this.muzzle(s), ok = this.clear(pv.x, pv.y, mz.x, mz.y), col = PORTC[s.team][s.pnext];
    const b = this.mkShot(s, w, ok ? mz.x : pv.x, ok ? mz.y : pv.y, s.aim, w.speed, w.life);
    b.slot = s.pnext;
    this.shots.push(b);
    this.flashes.push({ x: mz.x, y: mz.y, r: 30, life: 0.09, max: 0.09, col });
    this.rings.push({ x: mz.x, y: mz.y, r: 11, life: 0, max: 0.2, col });
    for (let i = 0; i < 6; i++) this.part(mz.x, mz.y, Math.cos(s.aim) * (60 + rand() * 120) + (rand() - 0.5) * 60, Math.sin(s.aim) * (60 + rand() * 120) + (rand() - 0.5) * 60, 0.15 + rand() * 0.15, 1, pickOne([col, "#ffffff"]), 0, 3, 5);
    this.sfx("portalshot", mz.x, mz.y, s.me ? 0.8 : 0.45);
    if (s === this.focus()) { this.cam.kx -= Math.cos(s.aim) * 2; this.cam.ky -= Math.sin(s.aim) * 2; }
  }
  /** the ball of light has struck the rock at (hx, hy): a portal opens there, if the face it struck is flat and big enough - else it fizzles */
  private placePortal(b: Shot, hx: number, hy: number) {
    const m = this.map, s = b.by, col = PORTC[s.team][b.slot];
    // which way the face looks: back along the axis the ball was stopped on
    const wx = solidPx(m, hx, b.y), wy = solidPx(m, b.x, hy);
    let nx = 0, ny = 0;
    if (wx && !wy) nx = b.vx > 0 ? -1 : 1;
    else if (wy && !wx) ny = b.vy > 0 ? -1 : 1;
    else if (Math.abs(b.vx) > Math.abs(b.vy)) nx = b.vx > 0 ? -1 : 1;
    else ny = b.vy > 0 ? -1 : 1;
    const fx = nx ? (nx < 0 ? Math.floor(hx / AT) * AT : (Math.floor(hx / AT) + 1) * AT) : hx, fy = ny ? (ny < 0 ? Math.floor(hy / AT) * AT : (Math.floor(hy / AT) + 1) * AT) : hy;
    const at = this.portalFit(fx, fy, nx, ny, s.team, b.slot);
    if (!at) {
      for (let i = 0; i < 8; i++) this.part(b.x, b.y, (rand() - 0.5) * 140, (rand() - 0.5) * 140, 0.2 + rand() * 0.2, 1, pickOne([col, "#ffffff"]), 100, 2, 5);
      this.sfx("portalopen", b.x, b.y, 0.35, 0.5);
      if (s.me) this.texts.push({ x: b.x, y: b.y - 10, text: "PERMUKAAN TIDAK RATA", col: "#ff6b7a", life: 0.9, vy: -14 });
      return;
    }
    const old = this.portals[s.team][b.slot];
    if (old) this.portalClose(old);
    const p: Portal = { x: at[0], y: at[1], nx, ny, team: s.team, slot: b.slot, t: 0, fx: 1 };
    this.portals[s.team][b.slot] = p;
    s.pnext = 1 - b.slot;
    const linked = !!this.portals[s.team][1 - b.slot];
    this.flashes.push({ x: p.x, y: p.y, r: 44, life: 0.16, max: 0.16, col });
    this.rings.push({ x: p.x, y: p.y, r: 20, life: 0, max: 0.3, col });
    for (let i = 0; i < 12; i++) this.part(p.x - ny * (rand() - 0.5) * PH * 2, p.y + nx * (rand() - 0.5) * PH * 2, nx * (40 + rand() * 90) + (rand() - 0.5) * 50, ny * (40 + rand() * 90) + (rand() - 0.5) * 50, 0.25 + rand() * 0.3, 1, pickOne([col, "#ffffff"]), 0, 2.5, 5);
    this.sfx("portalopen", p.x, p.y, s.me ? 0.9 : 0.6, linked ? 1.15 : 0.9);
    if (s.me) this.texts.push({ x: p.x + nx * 10, y: p.y - 14, text: linked ? "PORTAL TERHUBUNG!" : `PORTAL ${b.slot ? "B" : "A"}`, col, life: 1.1, vy: -14 });
  }
  /** a place for a portal on the face of the rock through (x, y) that looks along (nx, ny): rock behind it all along its length and open space in front, shifted along the face until it fits - and clear of the other portals */
  private portalFit(x: number, y: number, nx: number, ny: number, team: number, slot: number): number[] | null {
    const m = this.map, tx = -ny, ty = nx;
    for (const sh of [0, 3, -3, 6, -6, 9, -9, 12, -12]) {
      const cx = x + tx * sh, cy = y + ty * sh;
      let back = 0, open = true;
      for (const t of [-10, -5, 0, 5, 10]) {
        const qx = cx + tx * t, qy = cy + ty * t;
        if (solidPx(m, qx - nx * 2, qy - ny * 2)) back++;
        if (solidPx(m, qx + nx * 2, qy + ny * 2) || solidPx(m, qx + nx * 7, qy + ny * 7)) { open = false; break; }
      }
      if (!open || back < 4) continue;
      let clash = false;
      for (const pair of this.portals) for (const q of pair) if (q && !(q.team === team && q.slot === slot) && Math.abs(q.x - cx) < PH * 2 + 3 && Math.abs(q.y - cy) < PH * 2 + 3) clash = true;
      if (!clash) return [cx, cy];
    }
    return null;
  }
  /** a portal comes to nothing: a puff of its light */
  private portalClose(p: Portal) {
    const pair = this.portals[p.team];
    if (pair[p.slot] !== p) return;
    pair[p.slot] = null;
    const col = PORTC[p.team][p.slot];
    for (let i = 0; i < 12; i++) this.part(p.x - p.ny * (rand() - 0.5) * PH * 2, p.y + p.nx * (rand() - 0.5) * PH * 2, p.nx * (30 + rand() * 80) + (rand() - 0.5) * 60, p.ny * (30 + rand() * 80) + (rand() - 0.5) * 60, 0.3 + rand() * 0.3, 1, pickOne([col, "#ffffff"]), 0, 2, 5);
    this.rings.push({ x: p.x, y: p.y, r: 14, life: 0, max: 0.25, col });
    this.sfx("portalopen", p.x, p.y, 0.4, 0.6);
  }
  /** the open portal (with its twin) that something at (x, y), moving by (vx, vy), is going into - and how far along the opening it is */
  private portalAt(x: number, y: number, vx: number, vy: number): [Portal, Portal, number] | null {
    for (const pair of this.portals) {
      if (!pair[0] || !pair[1]) continue;
      for (let i = 0; i < 2; i++) {
        const p = pair[i]!, d = (x - p.x) * p.nx + (y - p.y) * p.ny, t = (y - p.y) * p.nx - (x - p.x) * p.ny;
        if (d <= 3 && d >= -5 && Math.abs(t) <= PH && vx * p.nx + vy * p.ny < 0) return [p, pair[1 - i]!, t];
      }
    }
    return null;
  }
  /** through p and out of its twin q: turned so that "into p" becomes "out of q" (the place along the opening is mirrored, like the turn), at no less than min px/s outwards, off px in front of the face → [x, y, vx, vy] */
  private portalOut(p: Portal, q: Portal, t: number, vx: number, vy: number, min: number, off: number): number[] {
    const a = Math.atan2(q.ny, q.nx) - Math.atan2(-p.ny, -p.nx), ca = Math.cos(a), sa = Math.sin(a);
    let ox = vx * ca - vy * sa, oy = vx * sa + vy * ca;
    const vn = ox * q.nx + oy * q.ny;
    if (vn < min) { ox += q.nx * (min - vn); oy += q.ny * (min - vn); }
    return [q.x + q.nx * off + q.ny * t, q.y + q.ny * off - q.nx * t, ox, oy];
  }
  /** a soldier who walks into a portal in a wall, drops into one in the floor or flies up into one in the roof comes out of its twin - as fast as they went in */
  private portalWalk(s: Sol) {
    const hh = s.crouch ? CH : HH, c = s.ctl;
    for (const pair of this.portals) {
      if (!pair[0] || !pair[1]) continue;
      for (let i = 0; i < 2; i++) {
        const p = pair[i]!;
        let into = false;
        if (p.nx) { const d = (s.x - p.x) * p.nx; into = d > 0 && d <= HW + 2.5 && Math.abs(s.y - hh / 2 - p.y) <= PH - hh / 2 + 5 && (c.mx * p.nx < 0 || s.vx * p.nx < -30); }
        else if (p.ny < 0) into = Math.abs(s.x - p.x) <= PH - 3 && s.y >= p.y - 2.5 && s.y <= p.y + 3 && s.vy >= 0;
        else into = Math.abs(s.x - p.x) <= PH - 3 && Math.abs(s.y - hh - p.y) <= 3 && (s.vy < -10 || s.jet);
        if (into && this.portalGo(s, p, pair[1 - i]!)) return;
      }
    }
  }
  private portalGo(s: Sol, p: Portal, q: Portal): boolean {
    const hh = s.crouch ? CH : HH, o = this.portalOut(p, q, 0, s.vx, s.vy, 130, 0);
    const x0 = q.nx ? q.x + q.nx * (HW + 1.5) : q.x, y0 = q.nx ? q.y + hh / 2 : q.ny < 0 ? q.y - 0.5 : q.y + hh + 0.5;
    let at: number[] | null = null;
    for (const dy of [0, -1, -2, 1, 2, -4, 4, -6, 6]) { for (const dx of [0, q.nx * 2, q.nx * 4]) if (!this.hit(s, x0 + dx, y0 + dy, false)) { at = [x0 + dx, y0 + dy]; break; } if (at) break; }
    if (!at) return false;
    const fx = s.x, fy = s.y;
    this.ghosts.push({ x: fx, y: fy, face: s.face, team: s.team, skin: s.skin, col: PORTC[p.team][p.slot], life: 0, max: 0.25 });
    s.x = at[0]; s.y = at[1]; s.vx = clamp(o[2], -520, 520); s.vy = clamp(o[3], -520, 520); s.ground = false; s.portCd = 0.35; s.drop = 0;
    s.scarf = [s.x, s.y - 11, s.x, s.y - 11, s.x, s.y - 11];
    if (s.bot) { s.bot.pathT = 0; s.bot.portSince = -1; }
    p.fx = 1; q.fx = 1;
    for (const e of [p, q]) {
      const col = PORTC[e.team][e.slot];
      this.rings.push({ x: e.x, y: e.y, r: 18, life: 0, max: 0.25, col });
      this.flashes.push({ x: e.x, y: e.y, r: 36, life: 0.12, max: 0.12, col });
      for (let i = 0; i < 8; i++) this.part(e.x - e.ny * (rand() - 0.5) * PH * 2, e.y + e.nx * (rand() - 0.5) * PH * 2, e.nx * (40 + rand() * 110) + (rand() - 0.5) * 50, e.ny * (40 + rand() * 110) + (rand() - 0.5) * 50, 0.2 + rand() * 0.25, 1, pickOne([col, "#ffffff"]), 0, 2.5, 5);
    }
    this.sfx("portalgo", q.x, q.y, s.me ? 0.9 : 0.55, 0.9 + rand() * 0.2);
    if (s.me) this.cam.shake = Math.max(this.cam.shake, 2.5);
    return true;
  }
  /** a shot goes into a portal and comes out of its twin, still flying */
  private shotVia(b: Shot, via: [Portal, Portal, number]) {
    const o = this.portalOut(via[0], via[1], via[2], b.vx, b.vy, 0, 3);
    via[0].fx = Math.max(via[0].fx, 0.6); via[1].fx = Math.max(via[1].fx, 0.6);
    b.x = o[0]; b.y = o[1]; b.vx = o[2]; b.vy = o[3]; b.px = b.x; b.py = b.y; b.sx = b.x; b.sy = b.y;
  }
  /** a way through the portals that is much shorter than going round: the portal to make for (not one in a roof) */
  private portalRoute(s: Sol, gx: number, gy: number): Portal | null {
    const d0 = Math.hypot(gx - s.x, gy - s.y);
    if (d0 < 260) return null;
    let best: Portal | null = null, bd = d0 * 0.6;
    for (const pair of this.portals) {
      if (!pair[0] || !pair[1]) continue;
      for (let i = 0; i < 2; i++) {
        const p = pair[i]!, q = pair[1 - i]!;
        if (p.ny > 0) continue;
        const d = Math.hypot(p.x - s.x, p.y - s.y) + Math.hypot(gx - q.x, gy - q.y);
        if (d < bd) { bd = d; best = p; }
      }
    }
    return best;
  }
  /** the one on each side who carries the portal gun: in a quiet moment they open a way from behind their own lines to wherever the fight has got to */
  private botPortal(s: Sol, dt: number): boolean {
    const b = s.bot!, c = s.ctl, pi = AW_ORDER.indexOf("portal"), pair = this.portals[s.team];
    if (b.portFire > 0) {
      // lining the shot up, then letting it go
      b.portFire -= dt;
      if (s.cur !== pi) this.equipSlot(s, pi, false);
      s.aim += clamp(angDiff(s.aim, b.portAim), -16 * dt, 16 * dt);
      c.aim = s.aim;
      c.fire = b.portFire < 0.25 && Math.abs(angDiff(s.aim, b.portAim)) < 0.1 && !s.trig;
      if (b.portFire <= 0) { b.swapCd = 0; b.think = 0; }
      return true;
    }
    if ((b.portT -= dt) > 0) return false;
    b.portT = 0.5;
    if (b.target || s.hide || !s.slots[pi]) return false;
    // the first one not far from where their side comes back in, the second a long way from the first
    const home = this.map.spawns[s.team][0];
    const slot = !pair[0] ? (Math.abs(s.x - home.x) < 420 ? 0 : -1) : (!pair[1] || this.t - b.portLast > 50) && Math.hypot(s.x - pair[0].x, s.y - pair[0].y) > 330 ? 1 : -1;
    if (slot < 0) { b.portT = 1.5; return false; }
    // a flat face of rock close by that they can see: a wall for choice, the floor if there is nothing else
    s.pnext = slot;
    const spot = this.portalSpot(s);
    if (!spot) return false;
    b.portLast = this.t; b.portN++; b.portT = 3 + rand() * 3;
    b.portAim = Math.atan2(spot[1] - (s.y - 5), spot[0] - s.x);
    b.portFire = 0.6;
    return true;
  }
  /** the nearest flat face of rock that a portal fits on and that s can see from where they stand (walls before floors) */
  private portalSpot(s: Sol): number[] | null {
    const m = this.map, pv = this.pivot(s), tx0 = Math.floor(s.x / AT), ty0 = Math.floor(s.y / AT);
    let best: number[] | null = null, bd = 1e9;
    for (let ty = ty0 - 12; ty <= ty0 + 5; ty++)
      for (let tx = tx0 - 16; tx <= tx0 + 16; tx++) {
        if (!solidT(tileAt(m, tx, ty))) continue;
        for (const [nx, ny] of [[-1, 0], [1, 0], [0, -1]]) {
          if (solidT(tileAt(m, tx + nx, ty + ny))) continue;
          const fx = nx ? (nx < 0 ? tx * AT : (tx + 1) * AT) : tx * AT + 4, fy = ny ? ty * AT : ty * AT + 4;
          const d = Math.hypot(fx - s.x, fy - (s.y - 8)) + (ny ? 70 : 0);
          if (d < 34 || d > 190 || d >= bd) continue;
          const at = this.portalFit(fx, fy, nx, ny, s.team, s.pnext);
          if (!at || !this.clear(pv.x, pv.y, at[0] + nx * 4, at[1] + ny * 4)) continue;
          bd = d; best = [at[0] + nx, at[1] + ny];
        }
      }
    return best;
  }
  private updPortals(dt: number) {
    for (const pair of this.portals) for (const p of pair) {
      if (!p) continue;
      p.t += dt; p.fx = Math.max(0, p.fx - dt * 3);
      // motes of its light drift in towards it
      if (rand() < dt * 9 && Math.abs(p.x - this.cam.x) < this.W && Math.abs(p.y - this.cam.y) < this.H) {
        const t = (rand() - 0.5) * 2 * PH, d = 8 + rand() * 8;
        this.part(p.x + p.nx * d - p.ny * t, p.y + p.ny * d + p.nx * t, -p.nx * 34, -p.ny * 34, 0.26, 1, PORTC[p.team][p.slot], 0, 0, 5);
      }
    }
  }
  /** portals: an oval of light on the face of the rock, seen edge on - a dark gap inside it once its twin is open, sparks running round its rim (drawn twice: its shape with the arena, its light over the dark) */
  private drawPortals(lit: boolean) {
    const ctx = this.ctx, t = this.t;
    for (const pair of this.portals) for (const p of pair) {
      if (!p) continue;
      const x = p.x - this.cl, y = p.y - this.ct;
      if (x < -30 || x > this.W + 30 || y < -30 || y > this.H + 30) continue;
      const col = PORTC[p.team][p.slot], open = !!pair[1 - p.slot], L = PH * easeOut(Math.min(1, p.t / 0.25)), w = 2.8 + p.fx * 2.5 + 0.4 * Math.sin(t * 6 + p.x);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.atan2(p.ny, p.nx));
      if (!lit) {
        ctx.fillStyle = open ? "#05030c" : col; ctx.globalAlpha = open ? 0.95 : 0.4;
        ctx.beginPath(); ctx.ellipse(0.5, 0, w, L, 0, 0, PI2); ctx.fill();
        ctx.globalAlpha = 1; ctx.strokeStyle = col; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.ellipse(0.5, 0, w + 0.8, L, 0, 0, PI2); ctx.stroke();
      } else {
        ctx.globalAlpha = (open ? 0.55 : 0.3) + p.fx * 0.4;
        ctx.drawImage(this.glowCol(col), -9 - p.fx * 4, -L - 7, 18 + p.fx * 8, L * 2 + 14);
        ctx.strokeStyle = "#ffffff"; ctx.globalAlpha = 0.5 + p.fx * 0.5; ctx.lineWidth = 0.8;
        ctx.beginPath(); ctx.ellipse(0.5, 0, w, Math.max(1, L - 1), 0, 0, PI2); ctx.stroke();
        ctx.fillStyle = "#ffffff"; ctx.globalAlpha = 0.9;
        const n = open ? 4 : 2;
        for (let i = 0; i < n; i++) { const a = t * (open ? 5 : 2) + (i * PI2) / n; ctx.fillRect(Math.cos(a) * (w + 0.8), Math.sin(a) * L - 0.5, 1, 1); }
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }
  /** lightning - between those the charge leapt to, and crawling over whoever is stunned by it: jagged lines drawn afresh every frame, so that they crackle */
  private drawBolts() {
    const ctx = this.ctx, cl = this.cl, ct = this.ct;
    const arc = (x0: number, y0: number, x1: number, y1: number, amp: number, a: number) => {
      const d = Math.hypot(x1 - x0, y1 - y0) || 1, n = Math.max(2, Math.round(d / 8)), px = -(y1 - y0) / d, py = (x1 - x0) / d;
      ctx.beginPath(); ctx.moveTo(x0, y0);
      for (let i = 1; i < n; i++) { const k = i / n, o = (rand() - 0.5) * 2 * amp; ctx.lineTo(x0 + (x1 - x0) * k + px * o, y0 + (y1 - y0) * k + py * o); }
      ctx.lineTo(x1, y1);
      ctx.strokeStyle = ELEC.col; ctx.globalAlpha = a * 0.7; ctx.lineWidth = 3; ctx.stroke();
      ctx.strokeStyle = "#ffffff"; ctx.globalAlpha = a; ctx.lineWidth = 1; ctx.stroke();
    };
    for (const b of this.bolts) { const a = 1 - b.life / b.max; arc(b.x0 - cl, b.y0 - ct, b.x1 - cl, b.y1 - ct, 7, a); if (a > 0.5) arc(b.x0 - cl, b.y0 - ct, b.x1 - cl, b.y1 - ct, 11, a * 0.5); }
    for (const s of this.sol) {
      if (!s.alive || s.zap <= 0) continue;
      const x = s.x - cl, y = s.y - ct;
      for (let i = 0; i < 2; i++) arc(x + (rand() - 0.5) * 14, y - 1 - rand() * 18, x + (rand() - 0.5) * 14, y - 1 - rand() * 18, 3, 0.9);
      ctx.globalAlpha = 0.35; ctx.drawImage(this.glowCol(ELEC.col), x - 15, y - 26, 30, 32);
    }
    ctx.globalAlpha = 1;
  }
  /** a ball of lightning from the tesla gun, or the ball of light that opens a portal */
  private drawOrb(b: Shot, x: number, y: number) {
    const ctx = this.ctx, shock = b.kind === "shock", col = shock ? ELEC.col : PORTC[b.by.team][b.slot], sp = Math.hypot(b.vx, b.vy) || 1, L = Math.min(24, b.dist + 2);
    ctx.globalAlpha = 0.7; ctx.drawImage(this.glowCol(col), x - 13, y - 13, 26, 26);
    ctx.strokeStyle = col; ctx.lineWidth = 3; ctx.globalAlpha = 0.5;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - (b.vx / sp) * L, y - (b.vy / sp) * L); ctx.stroke();
    ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 1; ctx.globalAlpha = 0.95;
    if (shock)
      for (let i = 0; i < 3; i++) {
        const a = rand() * PI2, r = 5 + rand() * 6;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * r * 0.5 + (rand() - 0.5) * 4, y + Math.sin(a) * r * 0.5 + (rand() - 0.5) * 4); ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); ctx.stroke();
      }
    else { ctx.beginPath(); ctx.arc(x, y, 3.5 + Math.sin(this.t * 30) * 0.8, 0, PI2); ctx.stroke(); }
    ctx.globalAlpha = 1; ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3);
  }
  /** an arm: a sleeve two pixels thick (three on an Astartes vambrace) with a dark outline, from the shoulder to the hand */
  private arm(x0: number, y0: number, x1: number, y1: number, col: string, K: string, cuff: string, thick = false) {
    const ctx = this.ctx, n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, y1 - y0))), s = thick ? 3 : 2;
    ctx.fillStyle = K;
    for (let i = 0; i <= n; i++) ctx.fillRect(Math.round(x0 + ((x1 - x0) * i) / n) - 2, Math.round(y0 + ((y1 - y0) * i) / n) - 2, s + 2, s + 2);
    for (let i = 0; i <= n; i++) { ctx.fillStyle = i > n * 0.58 ? cuff : col; ctx.fillRect(Math.round(x0 + ((x1 - x0) * i) / n) - 1, Math.round(y0 + ((y1 - y0) * i) / n) - 1, s, s); }
  }

  // ───────────── critical hits ─────────────
  private critMul(s: Sol) { return s.me ? 1 : s.team === this.me.team ? 0.7 : CRIT_MUL[this.cfg!.diff]; }
  private launchSol(v: Sol, by: Sol | null, ang: number, knock: number) {
    const worn = 1 - clamp((v.hp + v.armor) / (v.maxHp + v.maxArmor), 0, 1), K = Math.min(700, clamp(440 + knock * 0.45, 440, 590) * (1 + 0.35 * worn) * (v.skin === ASTARTES ? 0.82 : 1));
    let ax = Math.cos(ang), ay = Math.sin(ang);
    // (a blow straight down or straight up still sends them away from whoever dealt it)
    if (Math.abs(ax) < 0.3 && by && by !== v) { ax = (v.x >= by.x ? 1 : -1) * 0.5; const l = Math.hypot(ax, ay); ax /= l; ay /= l; }
    v.vx = ax * K; v.vy = ay * K * 0.75 - 130;
    v.launch = 0.5 + 0.2 * worn; v.bounces = 0; v.critImm = 1.7; v.stun = 0.3; v.shove = 400; v.spinV = (v.vx >= 0 ? 1 : -1) * 17; v.dizzy = 1.2;
    v.sprint = false; v.swingT = 0; v.melee = 0;
    const x = v.x, y = v.y - 9 + v.duck * 3, col = by ? TEAMS[by.team].color : "#ffffff", mine = v.me || (!!by && by.me);
    this.crits.push({ x, y, ang: Math.atan2(v.vy, v.vx), life: 0, max: 0.2, col, seed: rand() * 100 });
    this.texts.push({ x, y: v.y - 38, text: "CRITICAL!", col: "#ffd75e", life: 1.1, vy: -12, big: 2 });
    this.flashes.push({ x, y, r: 72, life: 0.14, max: 0.14, col: "#ffffff" });
    this.rings.push({ x, y, r: 34, life: 0, max: 0.3, col: "#ffffff" });
    this.rings.push({ x, y, r: 20, life: 0, max: 0.2, col });
    this.sparkBurst(x, y, ang, 16, ["#ffffff", "#fff3a0", "#ffd23a", col], 1.3);
    this.sfx("crit", x, y, mine ? 1 : 0.6);
    this.flare = Math.max(this.flare, 0.5);
    if (mine) {
      // the moment hangs: a freeze, then slow motion, the camera thrown in towards it and knocked askew, streaks across the picture
      this.hitStop = Math.max(this.hitStop, 0.085); this.slow = Math.max(this.slow, 0.2);
      this.zoomKick = Math.min(0.34, this.zoomKick + 0.24); this.rollV += (ax >= 0 ? 1 : -1) * 1.5;
      this.zfx = x; this.zfy = y; this.zfT = 0.5;
      this.cam.shake = Math.max(this.cam.shake, 7); this.cam.kx += ax * 6; this.cam.ky += ay * 4;
      this.rush = 1; this.rushA = Math.atan2(v.vy, v.vx);
      if (by && by.me && v !== by) { this.track = v; this.trackT = 1.3; }
    }
  }
  /**
   * Flying from a critical hit, they strike the rock - a wall (axis 1), or a floor or a roof (axis 2). The rock cracks, they
   * bounce off it, and it hurts; after the second time (or a soft one) they have their feet again.
   */
  private launchSlam(s: Sol, axis: number) {
    const sp = axis === 1 ? Math.abs(s.vx) : Math.abs(s.vy), dx = axis === 1 ? Math.sign(s.vx) : 0, dy = axis === 2 ? Math.sign(s.vy) : 0, hh = s.crouch ? CH : HH;
    const x = s.x + dx * (HW + 1.5), y = axis === 1 ? s.y - hh / 2 : dy > 0 ? s.y + 1.5 : s.y - hh - 1.5, by = s.lastBy && this.t - s.lastByT < 4 ? s.lastBy : null;
    if (axis === 1) { s.vx = -s.vx * 0.36; s.vy = s.vy * 0.85 - 50; } else { s.vy = -s.vy * 0.42; s.vx *= 0.8; }
    s.bounces++; s.spinV = -s.spinV * 0.6; s.squash = 0.12; s.dizzy = Math.max(s.dizzy, 1);
    if (s.bounces >= 2 || sp < 280) { s.launch = 0; s.stun = Math.max(s.stun, 0.25); } else s.launch = Math.min(s.launch, 0.2);
    for (let i = 0; i < 12; i++) { const a = Math.atan2(-dy, -dx) + (rand() - 0.5) * 2.4, v = 40 + rand() * 130; this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 20, 0.4 + rand() * 0.3, 2 + ((rand() * 2) | 0), this.dustCol(), 60, 2.5, 1); }
    this.sparkBurst(x, y, Math.atan2(dy, dx), 8, ["#ffffff", "#fff3a0", "#ffd23a"], 1);
    this.rings.push({ x, y, r: 26, life: 0, max: 0.26, col: "#ffffff" });
    this.flashes.push({ x, y, r: 46, life: 0.12, max: 0.12, col: "#ffe9a0" });
    if (this.hitfx.length < 44) this.hitfx.push({ x, y, ang: rand() * PI2, r: 15, kind: 1, life: 0, max: 0.17, col: "" });
    this.sfx("bodyslam", x, y, s.me ? 1 : 0.7, 0.85 + rand() * 0.3);
    // (the rock takes it too: cracked - and, slammed often enough, broken through)
    this.blame = by;
    this.hitTerrain(x + dx, y + dy, clamp(sp * 0.15, 35, 90), Math.atan2(dy, dx));
    // (and where they struck it, the rock is left cracked - whether or not it can be broken)
    if (solidPx(this.map, x + dx * 2.5, y + dy * 2.5)) this.crack(x + dx * 2.5, y + dy * 2.5, 4, 10);
    if (s.me || (by && by.me)) {
      this.hitStop = Math.max(this.hitStop, 0.05); this.cam.shake = Math.max(this.cam.shake, 6.5); this.zoomKick = Math.min(0.3, this.zoomKick + 0.07);
      this.rollV += (dx || (s.vx >= 0 ? -1 : 1)) * 0.9; this.cam.kx += dx * 5; this.cam.ky += dy * 5;
    }
    if (by && by.me) this.texts.push({ x, y: s.y - 30, text: "BANTING!", col: "#ffb347", life: 0.8, vy: -14 });
    if (this.track === s) this.trackT = Math.max(this.trackT, 0.7); // (the camera stays to watch them hit)
    this.hurt(s, clamp((sp - 200) * 0.05, 6, 20), by, "wall", Math.atan2(dy, dx), 0, false);
  }
  /** a critical hit, the instant it lands: the picture dims, and a burst of shards stands where it struck - white over the colour of whoever dealt it, longest the way the blow is sending them */
  private drawCrits() {
    const ctx = this.ctx, n = 9;
    for (const c of this.crits) {
      const k = c.life / c.max, x = c.x - this.cl, y = c.y - this.ct, grow = 9 + 19 * easeOut(Math.min(1, k * 1.6));
      if (k < 0.5) { ctx.fillStyle = `rgba(6,3,12,${(0.36 * (1 - k / 0.5)).toFixed(3)})`; ctx.fillRect(0, 0, this.W, this.H); }
      const hv = (i: number) => Math.abs(Math.sin(c.seed + i * 12.9898) * 43758.5453) % 1;
      for (let pass = 0; pass < 2; pass++) {
        ctx.fillStyle = pass ? "#ffffff" : c.col;
        ctx.globalAlpha = k < 0.55 ? 1 : (1 - k) / 0.45;
        ctx.beginPath();
        for (let i = 0; i < n * 2; i++) {
          const a = c.ang + (i * Math.PI) / n + (hv(i) - 0.5) * 0.2, along = Math.max(0, Math.cos(a - c.ang));
          const r = i % 2 ? grow * 0.24 : grow * (0.55 + hv(i + 40) * 0.6) * (1 + along * 0.8) * (pass ? 0.72 : 1);
          if (i) ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); else ctx.moveTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
        }
        ctx.closePath(); ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }
  /** text twice (or three times) the size, outlined: for the moments that deserve it */
  private bigText(text: string, cx: number, y: number, col: string, s: number) {
    const ctx = this.ctx, x = Math.round(cx - ((text.length * 4 - 1) * s) / 2);
    ctx.fillStyle = "#0a0a0f";
    for (const [ox, oy] of [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [1, 1], [-1, 1], [1, -1]]) glyphs(ctx, text, x + ox, y + oy, s);
    ctx.fillStyle = col;
    glyphs(ctx, text, x, y, s);
  }

  // ───────────── the camera's zoom and roll ─────────────
  /**
   * The finished picture of the world is magnified and tilted as the camera has it: a window of it - its middle, drawn for a
   * moment towards a critical hit, but never without whoever the camera follows - is blown up to fill the screen.
   */
  private applyView() {
    const W = this.W, H = this.H, ctx = this.ctx, roll = this.roll, sn = Math.abs(Math.sin(roll)), cs = Math.cos(roll);
    const need = Math.abs(roll) > 0.0008 ? cs + Math.max(W / H, H / W) * sn + 0.006 : 1, z = Math.max(this.zoom + this.zoomKick, need);
    if (z < 1.004) { this.vwZ = 1; this.vwR = 0; this.vwX = W / 2; this.vwY = H / 2; return; }
    const f = this.focus(), px = f.x - this.cl, py = f.y - 10 - this.ct, hw = W / (2 * z), hh = H / (2 * z), k = clamp(this.zfT * 2, 0, 0.7);
    let cx = W / 2 + (this.zfx - this.cl - W / 2) * k, cy = H / 2 + (this.zfy - this.ct - H / 2) * k;
    const mx = Math.min(64, hw * 0.55), my = Math.min(40, hh * 0.5), ex = (W * cs + H * sn) / (2 * z), ey = (W * sn + H * cs) / (2 * z);
    cx = Math.round(clamp(clamp(cx, px + mx - hw, px - mx + hw), ex, W - ex));
    cy = Math.round(clamp(clamp(cy, py + my - hh, py - my + hh), ey, H - ey));
    const eg = this.ebg;
    eg.globalAlpha = 1; eg.globalCompositeOperation = "copy"; eg.drawImage(this.cv, 0, 0); eg.globalCompositeOperation = "source-over";
    ctx.save();
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over";
    ctx.translate(W / 2, H / 2); ctx.rotate(roll); ctx.scale(z, z); ctx.translate(-cx, -cy);
    ctx.drawImage(this.eb, 0, 0);
    ctx.restore();
    this.vwZ = z; this.vwR = roll; this.vwX = cx; this.vwY = cy;
  }
  /** where a point of the screen is in the world, through the camera's zoom and roll */
  private toWorld(sx: number, sy: number): number[] {
    const dx = sx - this.W / 2, dy = sy - this.H / 2, c = Math.cos(this.vwR), s = Math.sin(this.vwR);
    return [this.cl + this.vwX + (dx * c + dy * s) / this.vwZ, this.ct + this.vwY + (-dx * s + dy * c) / this.vwZ];
  }
  /** where a point of the world is on the screen, through the camera's zoom and roll */
  private toScreen(wx: number, wy: number): number[] {
    const qx = wx - this.cl - this.vwX, qy = wy - this.ct - this.vwY, c = Math.cos(this.vwR), s = Math.sin(this.vwR);
    return [this.W / 2 + (qx * c - qy * s) * this.vwZ, this.H / 2 + (qx * s + qy * c) * this.vwZ];
  }

  // ───────────── the living cave ─────────────
  /** at the start of a match: where the stalactites hang, where the waterfall comes down, the geysers - and when the cave next shakes */
  private caveInit() {
    const m = this.map;
    this.rocks = []; this.bats = []; this.crits = []; this.quake = 0; this.qk = 0; this.quakeT = 16 + rand() * 8; this.rkT = 0; this.sway = 0; this.flare = 0;
    this.zoom = 1; this.zoomKick = 0; this.roll = 0; this.rollV = 0; this.zfT = 0; this.rush = 0; this.track = null; this.trackT = 0; this.vwZ = 1; this.vwR = 0; this.vwX = this.W / 2; this.vwY = this.H / 2;
    this.stalagAt.clear();
    for (const d of m.decor) if (d.k === "stalag") this.hang(d);
    this.falls = m.dyn.filter((d) => d.k === "fall").map((d) => [d.x, d.y, d.h, (d.width ?? 22) / 2]);
    this.geysers = m.dyn.filter((d) => d.k === "geyser").map((d) => ({ x: d.x, y: d.y, h: d.h || 100, ph: (Math.min(d.x, m.w * AT - d.x) * 0.013) % GEY_T, on: 0, st: 0, big: d.v > 1.5 }));
  }
  /** a stalactite hangs in these tiles: a shot that passes through them brings it down */
  private hang(d: Decor) {
    const m = this.map, tx = Math.floor(d.x / AT), ty = Math.floor(d.y / AT);
    this.stalagAt.set(ty * m.w + tx, d);
    if (5 + Math.round(d.v * 9) > 8) this.stalagAt.set((ty + 1) * m.w + tx, d);
  }
  /** an explosion: every light flares, the lanterns swing - and in the cave the stalactites near it are shaken loose, and bats take fright */
  private caveBlast(x: number, y: number) {
    this.flare = Math.max(this.flare, 0.8); this.sway = Math.max(this.sway, 0.8);
    if (this.map.theme.decor === "jungle") {
      // explosions startle colorful tropical macaws & paradise birds up out of the jungle canopy!
      if (rand() < 0.55 && this.bats.length < 28) {
        for (let i = 0; i < 4 + ((rand() * 3) | 0); i++)
          this.bats.push({ x: x + (rand() - 0.5) * 28, y: y - 14 - rand() * 12, a: -Math.PI * 0.5 + (rand() - 0.5) * 1.8, sp: 105 + rand() * 55, t: rand() * 6, life: 3.6 + rand() * 2 });
      }
      return;
    }
    if (this.map.theme.decor !== "cave") return;
    for (const d of this.stalags) if (Math.abs(d.x - x) < 64 && Math.abs(d.y - y) < 96 && rand() < 0.75) this.breakDecor(d, 0.08 + rand() * 0.35);
    if (rand() < 0.4) this.batsFrom(x, y - 10, 5 + ((rand() * 4) | 0));
  }
  /** geysers, the shaking of the cave, and what dies away by itself: the flare of the lights, the swing of the lanterns, the streaks across the picture */
  private updCave(dt: number, rdt: number) {
    this.flare *= Math.exp(-rdt * 4); this.sway *= Math.exp(-rdt * 1.2); this.rush = Math.max(0, this.rush - rdt * 3.4);
    const m = this.map, W = this.W, H = this.H;
    for (const g of this.geysers) {
      // each in its own time: quiet - then it bubbles and trembles - then it lets go
      const c = (this.t + g.ph) % GEY_T, st = c < GEY_T - 3 ? 0 : c < GEY_T - 2.1 ? 1 : 2, vis = Math.abs(g.x - this.cam.x) < W * 0.7 && Math.abs(g.y - this.cam.y) < H;
      if (st !== g.st) {
        g.st = st;
        if (st === 1) this.sfx("gurgle", g.x, g.y, 0.55, 1.3);
        else if (st === 2) {
          this.sfx("geyser", g.x, g.y, 1, g.big ? 0.8 : 1);
          this.rings.push({ x: g.x, y: g.y - 4, r: 16, life: 0, max: 0.3, col: "#c8f8ff" });
          for (let i = 0; i < 12; i++) this.part(g.x + (rand() - 0.5) * 8, g.y - 3, (rand() - 0.5) * 150, -60 - rand() * 160, 0.5 + rand() * 0.4, 1 + ((rand() * 2) | 0), pickOne(GEYC), 420, 0.6, 0);
        }
      }
      g.on += ((st === 2 ? 1 : 0) - g.on) * Math.min(1, dt * (st === 2 ? 10 : 5));
      if (vis && st === 1 && rand() < dt * 30) this.part(g.x + (rand() - 0.5) * 8, g.y - 2, (rand() - 0.5) * 26, -30 - rand() * 60, 0.3 + rand() * 0.3, 1, pickOne(GEYC), 160, 1, 0);
      if (vis && st === 0 && rand() < dt * 1.5) this.part(g.x + (rand() - 0.5) * 4, g.y - 3, (rand() - 0.5) * 8, -14 - rand() * 10, 0.9, 2, "#9adfe8", -14, 1.5, 1);
      if (g.on < 0.2) continue;
      const top = g.y - g.h * g.on, vmax = g.big ? 400 : 330;
      if (vis && rand() < dt * 70) this.part(g.x + (rand() - 0.5) * 8, top + rand() * 12, (rand() - 0.5) * 120, -30 - rand() * 100, 0.5 + rand() * 0.4, 1 + ((rand() * 2) | 0), pickOne(GEYC), 420, 0.6, 0);
      // whoever stands in it is thrown up the height of the column and beyond (and whoever was burning is put out); grenades and the fallen go up with it
      for (const s of this.sol) {
        if (!s.alive || s.hide || Math.abs(s.x - g.x) > 9 || s.y > g.y + 3 || s.y < top - 4) continue;
        s.vy = Math.max(-vmax, s.vy - 2100 * g.on * dt); s.lift = 0.25;
        if (s.burn > 0) s.burn = 0;
      }
      for (const n of this.nades) if (Math.abs(n.x - g.x) < 8 && n.y < g.y + 3 && n.y > top) n.vy = Math.max(-300, n.vy - 1900 * dt);
      for (const c2 of this.corpses) {
        const ch = c2.nodes[1];
        if (Math.abs(ch.x - g.x) > 10 || ch.y > g.y + 4 || ch.y < top) continue;
        c2.sleep = false; c2.still = 0;
        for (const n of c2.nodes) n.oy += (2800 * dt) / 180;
      }
    }
    if (m.theme.decor !== "cave") return;
    if (this.phase !== "live") { this.quake *= Math.exp(-dt * 3); return; }
    if (this.qk > 0) {
      // a warning rumble, then the shaking itself
      const was = this.qk;
      this.qk -= dt;
      if (was >= 2.6 && this.qk < 2.6) audio.play("rumble", 0.9);
      this.quake += ((this.qk < 2.6 ? Math.min(1, this.qk / 0.7) : 0.22) - this.quake) * Math.min(1, dt * 5);
      if (this.qk <= 0) this.quakeT = 26 + rand() * 16;
    } else {
      this.quake *= Math.exp(-dt * 3);
      if ((this.quakeT -= dt) <= 0) {
        this.qk = 4; this.rkT = 0;
        audio.play("rumble", 0.6);
        if (this.me.alive) this.texts.push({ x: this.me.x, y: this.me.y - 44, text: "GEMPA! AWAS STALAKTIT", col: "#ffb347", life: 1.6, vy: -8 });
        this.batsFrom(this.cam.x + (rand() - 0.5) * W * 0.6, this.cam.y, 8);
      }
    }
    if (this.quake < 0.02) return;
    this.cam.shake = Math.max(this.cam.shake, 1 + 4 * this.quake);
    this.sway = Math.max(this.sway, this.quake);
    this.flare = Math.max(this.flare, 0.25 * this.quake * (0.5 + 0.5 * Math.sin(this.t * 41)));
    // grit is shaken out of every roof in sight
    for (let k = 0; k < 3; k++) {
      if (rand() > dt * 45 * this.quake) continue;
      const tx = Math.floor((this.cl + rand() * W) / AT), ty = Math.floor((this.ct + rand() * H) / AT);
      if (solidT(tileAt(m, tx, ty)) && !solidT(tileAt(m, tx, ty + 1))) this.part(tx * AT + rand() * AT, (ty + 1) * AT, (rand() - 0.5) * 14, 20 + rand() * 40, 0.6 + rand() * 0.5, 1 + ((rand() * 2) | 0), this.dustCol(), 300, 1, rand() < 0.3 ? 6 : 1);
    }
    if (this.qk <= 0 || this.qk >= 2.6 || (this.rkT -= dt) > 0) return;
    this.rkT = 0.3 + rand() * 0.3;
    this.blame = null;
    // a stalactite works loose - over somebody's head, for choice
    const alive = this.sol.filter((s) => s.alive), who = alive.length ? pickOne(alive) : null;
    const near = who ? this.stalags.filter((d) => Math.abs(d.x - who.x) < 150 && d.y < who.y - 16 && d.y > who.y - 230) : [];
    if (near.length) this.breakDecor(pickOne(near), 0.45 + rand() * 0.6);
    // and a crack runs through a roof somewhere in sight
    for (let k = 0; k < 6; k++) {
      const tx = Math.floor((this.cl + rand() * W) / AT), ty = Math.floor((this.ct + rand() * H) / AT);
      if (!solidT(tileAt(m, tx, ty)) || solidT(tileAt(m, tx, ty + 1))) continue;
      this.dmgTile(tx, ty, 45, tx * AT + 4, ty * AT + 7, Math.PI / 2);
      break;
    }
  }
  /** falling rock: stalactites that have worked loose (they tremble first), and pieces of roof that have been shot away - they hurt whoever is under them, and whoever brought them down gets the credit */
  private updRocks(dt: number) {
    const m = this.map;
    for (let i = this.rocks.length - 1; i >= 0; i--) {
      const r = this.rocks[i], len = r.kind ? 4 : r.h;
      if (r.wait > 0) {
        r.wait -= dt;
        if (rand() < dt * 30) this.part(r.x + (rand() - 0.5) * 4, r.y + len, (rand() - 0.5) * 10, 20 + rand() * 30, 0.4 + rand() * 0.3, 1, this.dustCol(), 300, 1, 1);
        if (r.wait <= 0) this.sfx("rockcrack", r.x, r.y, 0.5, 0.7 + rand() * 0.3);
        continue;
      }
      r.vy = Math.min(540, r.vy + 780 * dt); r.x += r.vx * dt; r.rot += r.vr * dt;
      const ny = r.y + r.vy * dt, tip = ny + len;
      let done = ny > m.h * AT + 40;
      for (const e of this.sol) {
        if (done || !e.alive || e.shield > 0 || e.hide || r.hit.includes(e.id) || (r.by && r.by !== e && r.by.team === e.team)) continue;
        const top = e.y - (e.crouch ? CH : HH);
        if (Math.abs(e.x - r.x) > 7 || tip < top || r.y > e.y) continue;
        r.hit.push(e.id);
        const dmg = (r.kind ? 14 : 26) + Math.min(r.kind ? 12 : 22, r.vy * (r.kind ? 0.03 : 0.045));
        if (this.holoFacing(e, r.x, r.y)) this.holoHit(e, dmg, r.by, e.x, top - 4);
        else this.hurt(e, dmg, r.by, "rock", Math.atan2(1, (e.x - r.x) * 0.3), 140, false);
        done = true;
      }
      const row = Math.floor(tip / AT);
      if (!done && (solidPx(m, r.x, tip) || (tileAt(m, Math.floor(r.x / AT), row) === PLAT && r.y + len <= row * AT + 1))) done = true;
      if (!done) { r.y = ny; continue; }
      // it bursts: pieces, dust, a chip out of what it landed on
      for (let k = 0; k < (r.kind ? 5 : 8); k++) this.part(r.x + (rand() - 0.5) * 4, tip - 2, (rand() - 0.5) * 150, -40 - rand() * 110, 0.6 + rand() * 0.6, 1 + ((rand() * 2) | 0), r.kind ? r.col : pickOne(["#3e5866", "#263c49", "#7c9299"]), 560, 0.5, 6);
      for (let k = 0; k < 3; k++) this.part(r.x + (rand() - 0.5) * 6, tip - 2, (rand() - 0.5) * 50, -15 - rand() * 25, 0.5 + rand() * 0.3, 2 + ((rand() * 2) | 0), this.dustCol(), -10, 2, 1);
      this.sfx("crumble", r.x, tip, r.kind ? 0.4 : 0.6, 0.9 + rand() * 0.4);
      this.blame = r.by;
      this.hitTerrain(r.x, tip + 1, r.kind ? 8 : 14, Math.PI / 2);
      this.rocks.splice(i, 1);
    }
  }
  /** bats burst out of the nearest roof above (x, y) */
  private batsFrom(x: number, y: number, n: number) {
    if (this.map.theme.decor !== "cave" || this.bats.length > 36) return;
    let ry = y;
    for (let k = 0; k < 14 && !solidPx(this.map, x, ry - 8); k++) ry -= 8;
    for (let i = 0; i < n; i++) this.bats.push({ x: x + (rand() - 0.5) * 14, y: ry + rand() * 6, a: -Math.PI / 2 + (rand() - 0.5) * 2.8, sp: 95 + rand() * 70, t: rand() * 6, life: 3.5 + rand() * 2.5 });
    this.sfx("bats", x, ry, 0.6, 0.9 + rand() * 0.3);
  }
  private updBats(dt: number) {
    const m = this.map;
    for (let i = this.bats.length - 1; i >= 0; i--) {
      const b = this.bats[i];
      b.t += dt;
      if ((b.life -= dt) <= 0) { this.bats.splice(i, 1); continue; }
      b.a += Math.sin(b.t * 5 + i) * 3 * dt;
      const vx = Math.cos(b.a) * b.sp, vy = Math.sin(b.a) * b.sp * 0.7 + Math.sin(b.t * 16) * 26;
      if (solidPx(m, b.x + vx * dt * 3, b.y)) b.a = Math.PI - b.a; else b.x += vx * dt;
      if (solidPx(m, b.x, b.y + vy * dt * 3)) b.a = -b.a; else b.y += vy * dt;
    }
  }
  /** falling rock: a stalactite as it hung, or a tumbling piece of roof */
  private drawRocks() {
    const ctx = this.ctx;
    for (const r of this.rocks) {
      const x = Math.round(r.x) - this.cl + (r.wait > 0 ? Math.round(Math.sin(this.t * 70 + r.x)) : 0), y = Math.round(r.y) - this.ct;
      if (x < -12 || x > this.W + 12 || y < -24 || y > this.H + 12) continue;
      if (r.kind === 0) {
        for (let i = 0; i < r.h; i++) {
          const w = Math.max(1, 5 - (((i * 5) / r.h) | 0)), sx = x - (w >> 1);
          this.R("#140e22", sx - 1, y + i, w + 2, 1); this.R(i < r.h * 0.45 ? "#3e5866" : "#263c49", sx, y + i, w, 1);
          if (w >= 2) this.R("#7c9299", sx, y + i, 1, 1);
        }
      } else {
        ctx.save(); ctx.translate(x, y); ctx.rotate(r.rot);
        this.R("#0e0a16", -4, -4, 8, 8); this.R(r.col, -3, -3, 6, 6); this.R("rgba(255,255,255,0.22)", -3, -3, 6, 1); this.R("rgba(0,0,0,0.3)", -3, 2, 6, 1);
        ctx.restore();
      }
    }
  }
  /** cave bats in Goa Kristal — or vibrant scarlet, turquoise & golden tropical macaws soaring across Hutan Bastion! */
  private drawBats() {
    const jungle = this.map.theme.decor === "jungle";
    const macaws = [["#ff3848", "#ffd84a"], ["#28d8ff", "#fff06a"], ["#38e878", "#ff68b8"]];
    this.bats.forEach((b, idx) => {
      const x = Math.round(b.x) - this.cl, y = Math.round(b.y) - this.ct, wy = Math.sin(b.t * (jungle ? 22 : 34)) > 0 ? -2 : 1;
      if (x < -8 || x > this.W + 8 || y < -8 || y > this.H + 8) return;
      if (jungle) {
        const [body, wing] = macaws[idx % 3], dir = Math.cos(b.a) >= 0 ? 1 : -1;
        this.R("#0e1a16", x - 3, y - 1, 6, 3);
        this.R(body, x - 2, y, 4, 1);
        this.R(wing, x - 1, y + wy, 3, 2);
        this.R(body, x - dir * 4, y, 2, 1);       // long trailing macaw tail feather
        this.R("#ffe85a", x + dir * 2, y, 1, 1);   // golden beak
        return;
      }
      this.R("#150f22", x - 2, y - 1, 4, 1); this.R("#150f22", x - 1, y - 1, 2, 2);
      this.R("#150f22", x - 3, y + wy, 2, 1); this.R("#150f22", x + 1, y + wy, 2, 1);
      this.R("#ffb070", x - 1, y - 1, 1, 1); this.R("#ffb070", x, y - 1, 1, 1);
    });
  }
  /** geysers: a vent in the floor with a rim of light - and, when it lets go, a column of water and steam racing upward under a crown of foam (drawn twice: its shape with the arena, its light over the dark) */
  private drawGeysers(lit: boolean) {
    const ctx = this.ctx, t = this.t;
    for (const g of this.geysers) {
      const x = Math.round(g.x) - this.cl, y = Math.round(g.y) - this.ct, hgt = g.h * g.on * (0.94 + 0.06 * Math.sin(t * 23)), top = y - 3 - hgt;
      if (x < -30 || x > this.W + 30 || y < -10 || top > this.H + 10) continue;
      if (lit) {
        ctx.globalAlpha = g.st ? 0.5 : 0.3; ctx.drawImage(this.glowCol("#7fe8ff"), x - 9, y - 10, 18, 14);
        if (g.on > 0.05) { ctx.globalAlpha = 0.32 * g.on; ctx.drawImage(this.glowCol("#9aeaff"), x - 18, top - 12, 36, hgt + 24); }
        continue;
      }
      const sh = g.st === 1 ? Math.round(Math.sin(t * 60)) : 0;
      this.R("#0e0a16", x - 8 + sh, y - 3, 16, 3); this.R("#3c3d58", x - 7 + sh, y - 2, 14, 2); this.R("#6a7096", x - 7 + sh, y - 3, 5, 1); this.R("#6a7096", x + 2 + sh, y - 3, 5, 1);
      this.R(g.st ? "#e6fdff" : "#5fd0e8", x - 2 + sh, y - 3, 4, 1); this.R("#0b3040", x - 2 + sh, y - 2, 4, 1);
      if (g.on <= 0.05) continue;
      for (let i = -4; i <= 3; i++) {
        ctx.globalAlpha = (0.92 - (Math.abs(i + 0.5) / 4.5) * 0.5) * Math.min(1, g.on * 1.5);
        for (let yy = Math.floor(top); yy < y - 3; yy += 2) {
          const ph = (((yy + t * 260 + i * 11 + i * i * 5) % 20) + 20) % 20;
          ctx.fillStyle = ph < 3 ? "#ffffff" : ph < 9 ? "#c8f8ff" : ph < 15 ? "#6fdcf0" : "#3aa0d0";
          ctx.fillRect(x + i, yy, 1, 2);
        }
      }
      ctx.globalAlpha = 1;
      for (let i = 0; i < 7; i++) { const a = (i / 6) * Math.PI, r = 4 + ((t * 30 + i * 7) % 5); this.R("#ffffff", Math.round(x + Math.cos(a) * r) - 1, Math.round(top + 2 - Math.sin(a) * 3), 2, 2); }
    }
    ctx.globalAlpha = 1;
  }

  // ───────────── hiding places ─────────────
  /** the hiding place within reach of a soldier - if nobody is in it already */
  private hideNear(s: Sol): HideSpot | null {
    let best: HideSpot | null = null, bd = 16;
    for (const h of this.map.hides) {
      const d = Math.abs(h.x - s.x);
      if (d >= bd || Math.abs(h.y - s.y) > 9) continue;
      if (this.sol.some((o) => o !== s && o.alive && o.hide === h)) continue;
      bd = d; best = h;
    }
    return best;
  }
  /** the cover shivers and sheds a few leaves, flower petals, splinters or chips */
  private rustle(h: HideSpot, n: number) {
    const i = this.map.hides.indexOf(h), leafy = h.k === "grove" || h.k === "fern" || h.k === "monstera" || h.k === "blossom" || h.k === "banyan", wood = h.k === "crates";
    if (i >= 0) this.hideShake[i] = 0.3;
    for (let k = 0; k < n; k++)
      this.part(h.x + (rand() - 0.5) * h.w * 1.6, h.y - 2 - rand() * h.h, (rand() - 0.5) * 60, -20 - rand() * 40, 0.42 + rand() * 0.3, 1 + ((rand() * 2) | 0),
        h.k === "blossom" ? pickOne(["#ff5eb8", "#ffd84a", "#4ee8ff", "#48dc62"])
          : h.k === "monstera" || h.k === "banyan" ? pickOne(["#28b850", "#96f86c", "#ff6b4a", "#ffe05a"])
            : leafy ? pickOne(["#36b889", "#8ef8d2", "#2d8f68"]) : wood ? pickOne(["#a67546", "#c8965a"]) : this.dustCol(), 150, 2, leafy || wood ? 0 : 1);
  }
  /** E: slip in behind the cover of a hiding place - or step back out of it */
  private toggleHide(s: Sol): boolean {
    if (s.hide) { this.unhide(s); return true; }
    const h = s.ground ? this.hideNear(s) : null;
    if (!h) return false;
    s.hide = h; s.hideT = 0; s.crouch = true; s.duckT = 0.12; s.vx = 0; s.swingT = 0;
    this.rustle(h, 7);
    this.sfx("swoosh", s.x, s.y, s.me ? 0.4 : 0.2, 1.3);
    if (s.me) this.texts.push({ x: s.x, y: s.y - 30, text: "SEMBUNYI", col: "#7dff9a", life: 0.9, vy: -16 });
    return true;
  }
  private unhide(s: Sol) {
    if (!s.hide) return;
    this.rustle(s.hide, 5);
    s.hide = null;
    s.fireCd = Math.max(s.fireCd, 0.14);
    this.sfx("swoosh", s.x, s.y, s.me ? 0.35 : 0.2, 1.6);
  }
  /** a bullet stopped by the cover of a hiding place: splinters, chips and a spark */
  private coverFx(b: Shot, q: HideSpot) {
    const back = Math.atan2(-b.vy, -b.vx), wood = q.k === "crates" || q.k === "banyan", leafy = q.k === "grove" || q.k === "fern" || q.k === "monstera" || q.k === "blossom";
    this.stars.push({ x: b.x, y: b.y, life: 0.06, col: "#ffffff" });
    this.hitfx.push({ x: b.x, y: b.y, ang: back, r: 5, kind: 0, life: 0, max: 0.1, col: "" });
    for (let i = 0; i < 5; i++) {
      const a = back + (rand() - 0.5) * 1.6, v = 50 + rand() * 90;
      this.part(b.x, b.y, Math.cos(a) * v, Math.sin(a) * v - 25, 0.35 + rand() * 0.2, 1 + ((rand() * 2) | 0), wood ? pickOne(["#a67546", "#5e3e22", "#c8965a"]) : leafy ? pickOne(["#36b889", "#8ef8d2", "#e86cb8"]) : pickOne(["#7b84ad", "#525878", "#5ff0e0"]), 320, 1.5, 6);
    }
    if (!leafy) this.sparks(b.x, b.y, 3);
    const i = this.map.hides.indexOf(q);
    if (i >= 0) this.hideShake[i] = Math.max(this.hideShake[i], 0.12);
    if (rand() < 0.5) this.sfx(wood ? "thunk" : "wall", b.x, b.y, 0.35, wood ? 1.5 : 1);
  }

  private tryPick(s: Sol, manual: boolean) {
    let best: Pick | null = null, bd = 1e9;
    for (const p of this.picks) {
      if (p.spot && p.t > 0) continue;
      const dx = Math.abs(p.x - s.x), dy = Math.abs(p.y - 4 - (s.y - 9));
      if (dx > 13 || dy > 16) continue;
      const util = p.kind === "health" || p.kind === "nades";
      if (manual && util) continue;
      if (!manual) {
        if (p.kind === "health") { if (s.hp >= s.maxHp && s.armor >= s.maxArmor) continue; }
        else if (p.kind === "nades") { if (s.nades >= 4) continue; }
        else {
          const id = p.kind as AW, d = AWEP[id];
          const q = s.slots.find((z) => z && z.id === id);
          if (!q || isBlade(d.kind) || (q.mag >= d.mag && q.ammo >= d.ammo * 2)) continue;
        }
      }
      if (dx + dy < bd) { bd = dx + dy; best = p; }
    }
    if (!best) return;
    const p = best;
    // (a medkit patches the body up, and restores half the armour — +110 ceramite on an Astartes, plus topping up Bolter reserves!)
    if (p.kind === "health") {
      const tank = s.skin === ASTARTES, addH = tank ? 75 : 60, addA = tank ? 110 : 50;
      s.hp = Math.min(s.maxHp, s.hp + addH); s.armor = Math.min(s.maxArmor, s.armor + addA); s.armorFx = 1;
      if (tank && s.slots[0]?.id === "bolter") s.slots[0].ammo = Math.min(AWEP.bolter.ammo * 2, s.slots[0].ammo + 40);
      if (s.me) this.texts.push({ x: s.x, y: s.y - 30, text: `+${addH} HP +${addA} ${tank ? "CERAMITE" : "ARMOR"}`, col: tank ? "#ffe26a" : "#7dff9a", life: 1.05, vy: -18 });
    }
    else if (p.kind === "nades") { s.nades = Math.min(4, s.nades + 2); if (s.me) this.texts.push({ x: s.x, y: s.y - 30, text: "+2 GRANAT", col: "#7dff9a", life: 1, vy: -18 }); }
    else {
      const id = p.kind as AW, d = AWEP[id], mag = p.spot ? d.mag : p.mag, ammo = p.spot ? d.ammo : p.ammo;
      const own = s.slots.findIndex((q) => q && q.id === id);
      if (own >= 0) {
        const q = s.slots[own]!;
        if (!isBlade(d.kind)) {
          q.mag = d.mag;
          q.ammo = Math.min(d.ammo * 2, q.ammo + Math.max(d.mag, mag + ammo));
        }
        if (manual) this.equipSlot(s, own, false);
      }
      if (id === "saber" || id === "katana") this.callout(s, "saber");
      if (s.me) this.texts.push({ x: s.x, y: s.y - 30, text: isBlade(d.kind) ? PICK_NAME[p.kind] : `+AMMO ${PICK_NAME[p.kind]}`, col: "#7dff9a", life: 1, vy: -18 });
    }
    if (p.spot) p.t = RESPAWN_T[p.kind] ?? 18;
    else this.picks.splice(this.picks.indexOf(p), 1);
    this.sfx("pick", s.x, s.y, s.me ? 0.7 : 0.25);
  }

  // ───────────── damage ─────────────
  /** a shower of sparks where a blow lands: white-hot streaks thrown back the way it came (every fourth one on past it), which bounce where they fall */
  private sparkBurst(x: number, y: number, ang: number, n: number, cols: string[], speed = 1) {
    for (let i = 0; i < n; i++) {
      const back = i % 4 !== 3, a = (back ? ang + Math.PI : ang) + (rand() - 0.5) * (back ? 1.8 : 1), v = (80 + rand() * 200) * speed;
      this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 45, 0.22 + rand() * 0.32, 1, pickOne(cols), 460, 1.1, 9);
    }
  }
  /** the armour gives way: its plates fly off in pieces in a burst of sparks - from here on, every blow draws blood */
  private armorBreak(v: Sol, by: Sol | null, ang: number) {
    const x = v.x, y = v.y - 9 + v.duck * 3, tc = TEAMS[v.team].color;
    v.armor = 0; v.armorFx = 1;
    for (let i = 0; i < 12; i++) {
      const a = rand() * PI2, sp = 50 + rand() * 150;
      this.part(x, y, Math.cos(a) * sp + Math.cos(ang) * 60, Math.sin(a) * sp - 80, 1 + rand() * 0.8, 1 + ((rand() * 2) | 0), pickOne(["#eef3fa", "#aab3c8", "#6b7388", tc]), 560, 0.5, 6);
    }
    this.sparkBurst(x, y, ang, 14, ARMC, 1.15);
    this.rings.push({ x, y, r: 21, life: 0, max: 0.28, col: "#cfe2ff" });
    this.rings.push({ x, y, r: 12, life: 0, max: 0.16, col: "#ffffff" });
    this.flashes.push({ x, y, r: 42, life: 0.12, max: 0.12, col: "#cfe2ff" });
    if (this.hitfx.length < 44) this.hitfx.push({ x, y, ang: rand() * PI2, r: 13, kind: 1, life: 0, max: 0.16, col: "" });
    this.sfx("armorbreak", x, y, v.me ? 1 : 0.7);
    if (v.me) { this.texts.push({ x, y: v.y - 32, text: "ARMOR PECAH!", col: "#ff9a5a", life: 1.1, vy: -14 }); this.cam.shake = Math.max(this.cam.shake, 4); this.hitStop = Math.max(this.hitStop, 0.04); }
    else if (by && by.me) { this.texts.push({ x, y: v.y - 32, text: "ARMOR PECAH!", col: "#cfe2ff", life: 1, vy: -14 }); this.hitStop = Math.max(this.hitStop, 0.03); }
  }
  /** the armour is whole again: its plates lock back into place */
  private armorUp(s: Sol) {
    const tank = s.skin === ASTARTES;
    s.armor = s.maxArmor; s.armorFx = 1;
    this.rings.push({ x: s.x, y: s.y - 9, r: tank ? 17 : 13, life: 0, max: 0.27, col: tank ? "#ffe26a" : "#cfe2ff" });
    for (let i = 0; i < (tank ? 9 : 6); i++) this.part(s.x + (rand() - 0.5) * 12, s.y - 2 - rand() * 14, (rand() - 0.5) * 20, -30 - rand() * 30, 0.35 + rand() * 0.2, 1, pickOne(tank ? ["#ffffff", "#ffe26a", "#78b4ff"] : ["#ffffff", "#cfe2ff", "#9fc4ff"]), -20, 2, 5);
    if (s.me) { audio.play("armorup", 0.55); this.texts.push({ x: s.x, y: s.y - 30, text: tank ? "CERAMITE PENUH" : "ARMOR PULIH", col: tank ? "#ffe26a" : "#cfe2ff", life: 0.95, vy: -16 }); }
  }
  /** thrown against a wall by a blow: a thud, dust off the wall, stars round the head - and a moment longer off balance */
  private wallSlam(s: Sol) {
    const dir = Math.sign(s.vx), x = s.x + dir * (HW + 1), y = s.y - 9;
    for (let i = 0; i < 7; i++) this.part(x, y + (rand() - 0.5) * 14, -dir * (20 + rand() * 70), -20 - rand() * 40, 0.35 + rand() * 0.2, 2, this.dustCol(), 70, 2.5, 1);
    this.stars.push({ x, y, life: 0.07, col: "#ffffff" });
    this.sfx("thunk", x, y, 0.6, 0.85);
    s.stun = Math.max(s.stun, 0.24); s.squash = Math.max(s.squash, 0.09); s.tilt = -dir * 0.35; s.dizzy = Math.max(s.dizzy, 0.5);
    if (s.me) this.cam.shake = Math.max(this.cam.shake, 3);
  }

  /**
   * A blow lands. The armour takes it first - sparks, splinters of plate, the clank of struck steel - and only what the armour
   * cannot take any more goes on into the body, and draws blood. Either way it throws them back: the harder the blow the further,
   * clean off the ground if it is hard enough - and for a moment they are off balance, with little say over their feet and a wilder aim.
   */
  private hurt(v: Sol, dmg: number, by: Sol | null, w: string, ang: number, knock: number, head: boolean, crit = false) {
    if (!v.alive || this.phase === "end" || v.shield > 0) return;
    if (by && by !== v && by.team === v.team) return;
    // fire, a fist, a bolter blast or a blade drives whoever is hiding out of their cover
    const vTank = v.skin === ASTARTES, isChain = w === "chainsword";
    if (v.hide && (w === "flame" || w === "melee" || w === "saber" || w === "katana" || w === "axe" || isChain)) this.unhide(v);
    if (by && by.bot && by.team !== this.me.team) dmg *= DMG_MUL[this.cfg!.diff];
    // thick sloped Adeptus Astartes ceramite absorbs 22% of incoming fire while intact (unless chewed by an enemy chainsword!)
    if (vTank && v.armor > 0 && w !== "fall" && !isChain) dmg *= 0.78;
    if (v.zap > 0 && knock > 0 && dmg >= 15 && w !== "tesla") crit = true;
    if (crit && (v.hide || v.launch > 0 || v.critImm > 0 || v === by)) crit = false;
    if (crit) dmg = Math.min(dmg * 1.3, 185);
    dmg = Math.max(1, Math.round(dmg));
    // Chainsword's roaring adamantium saw-teeth shred enemy armour plates +65% faster AND bite through into flesh!
    const armDmg = isChain ? Math.round(dmg * 1.65) : dmg;
    const plate = w === "fall" ? 0 : Math.min(v.armor, armDmg);
    const flesh = w === "fall" ? dmg : Math.max(0, Math.round(dmg - plate / (isChain ? 1.65 : 1)));
    const broke = plate > 0 && v.armor - plate <= 0;
    v.armor -= plate;
    v.hp -= flesh;
    const shownDmg = plate + flesh;
    v.hurtT = 0;
    v.flash = dmg >= 30 ? 0.07 : 0.04;
    v.ouch = 0.35;
    const kbResist = vTank ? 0.55 : 1;
    v.tilt = clamp(v.tilt + (Math.cos(ang) >= 0 ? 1 : -1) * (0.2 + Math.min(0.45, dmg / 90)) * kbResist, -0.9, 0.9);
    if (by && by !== v) { v.lastBy = by; v.lastByT = this.t; by.dmg += shownDmg; }
    if (by && by !== v && by.team !== v.team) { if (v.team === this.me.team) this.spot(by); if (by.me) { this.focusE = v; this.focusT = this.t; this.spot(v); } }
    const effKnock = knock * kbResist;
    if (crit) this.launchSol(v, by, ang, vTank ? knock * 0.78 : knock);
    else if (effKnock && !v.hide) {
      v.vx = clamp(v.vx + Math.cos(ang) * effKnock, -380, 380); v.vy += Math.sin(ang) * effKnock * 0.5;
      v.shove += effKnock;
      v.stun = Math.max(v.stun, clamp(v.shove / (vTank ? 950 : 700), 0.04, vTank ? 0.25 : 0.38));
      v.bloom = Math.min(1.5, v.bloom + knock / 450);
      if (v.ground && v.shove >= 150) v.vy = Math.min(v.vy, -clamp(v.shove * 0.3, 50, 100));
    }
    const hy = v.y - (head ? 14 : 8) + v.duck * 3, hx = v.x - Math.cos(ang) * 3, heavy = dmg >= 30;
    if (w === "tesla") {
      // lightning: no blood - a burst of blue-white sparks, whatever it lands on
      this.sparkBurst(hx, hy, ang, 9, ELC, 0.9);
      this.rings.push({ x: v.x, y: hy, r: 14, life: 0, max: 0.2, col: ELEC.col });
      this.flashes.push({ x: v.x, y: hy, r: 30, life: 0.1, max: 0.1, col: ELEC.col });
      if (plate > 0) v.armorFx = 1;
      if (broke) this.armorBreak(v, by, ang);
    } else if (w !== "flame" && w !== "fall") {
      if (plate > 0) {
        // on the armour: a shower of sparks, a splinter or two of plate, the flash and the clank of struck steel
        this.sparkBurst(hx, hy, ang, 6 + Math.min(11, (plate / 5) | 0), ARMC);
        for (let i = heavy ? 3 : rand() < 0.4 ? 1 : 0; i > 0; i--) this.part(hx, hy, -Math.cos(ang) * (30 + rand() * 80) + (rand() - 0.5) * 60, -Math.sin(ang) * (30 + rand() * 80) - 50 - rand() * 50, 0.8 + rand() * 0.5, 1, pickOne(["#eef3fa", "#aab3c8", "#6b7388"]), 560, 0.5, 6);
        if (this.hitfx.length < 44) this.hitfx.push({ x: hx, y: hy, ang: ang + Math.PI, r: heavy ? 11 : 6, kind: 2, life: 0, max: heavy ? 0.14 : 0.1, col: "#ffe9a0" });
        if (heavy) { this.rings.push({ x: hx, y: hy, r: 14, life: 0, max: 0.2, col: "#cfe2ff" }); this.flashes.push({ x: hx, y: hy, r: 26, life: 0.08, max: 0.08, col: "#ffe9a0" }); }
        if (head && flesh <= 0) this.rings.push({ x: v.x, y: hy, r: 12, life: 0, max: 0.2, col: "#ffe9a0" });
        this.sfx("armorhit", hx, hy, Math.min(0.9, 0.32 + plate / 80), 0.9 + rand() * 0.25);
        v.armorFx = 1;
      }
      if (broke) this.armorBreak(v, by, ang);
      if (w === "saber") {
        // a lightsaber cauterises: no blood - sparks, embers and a wisp of smoke
        const B = BEAM[by ? by.team : 0];
        for (let i = 0; i < 12; i++) this.part(v.x, hy, Math.cos(ang) * (50 + rand() * 130) + (rand() - 0.5) * 85, Math.sin(ang) * (50 + rand() * 130) - 40 - rand() * 65, 0.32 + rand() * 0.28, 1, pickOne([B.col, B.hot, "#ffffff", "#ff9a3c"]), 300, 1.5, 5);
        this.part(v.x, hy, 0, -20, 0.9, 3, pickOne(SMOKE), -30, 2, 1);
        this.hitfx.push({ x: v.x, y: hy, ang, r: 14, kind: 2, life: 0, max: 0.16, col: B.col });
        this.rings.push({ x: v.x, y: hy, r: 16, life: 0, max: 0.2, col: B.col });
      } else if (w === "chainsword") {
        // roaring Astartes chainsword chewing through plate & flesh: rooster-tail of molten ceramite sparks, steel splinters & crimson spray!
        this.sparkBurst(hx, hy, ang, 16, CHAINC, 1.25);
        this.hitfx.push({ x: v.x, y: hy, ang, r: 18, kind: 1, life: 0, max: 0.18, col: "#ffd24a" });
        this.rings.push({ x: v.x, y: hy, r: 22, life: 0, max: 0.22, col: "#ff9a2a" });
        this.flashes.push({ x: v.x, y: hy, r: 36, life: 0.1, max: 0.1, col: "#ff7a1e" });
        if (plate > 0 && by && by.me && !broke) this.texts.push({ x: v.x, y: v.y - 33, text: "ROBEK BAJA!", col: "#ffd24a", life: 0.72, vy: -18 });
        if (flesh > 0) {
          this.gore(v.x, hy, ang, Math.min(1.4, flesh / 38), true);
          for (let i = 0; i < 12; i++) { const q = (i / 11 - 0.5) * 16; this.part(v.x - Math.sin(ang) * q, hy + Math.cos(ang) * q, Math.cos(ang) * (105 + rand() * 85), Math.sin(ang) * (105 + rand() * 85) - 45, 0.85, 1 + (i % 3 === 0 ? 1 : 0), pickOne(BLOOD), 520, 0.5, 4); }
        }
      } else if (w === "katana" || w === "axe") {
        if (w === "axe") this.sparkBurst(hx, hy, ang, 9, AXC, 1.1);
        this.hitfx.push({ x: v.x, y: hy, ang, r: 15, kind: 2, life: 0, max: 0.16, col: "#9ee8ff" });
        this.rings.push({ x: v.x, y: hy, r: 18, life: 0, max: 0.2, col: "#ffffff" });
        if (flesh > 0) {
          this.sparkBurst(hx, hy, ang, 6, ["#ffffff", "#9ee8ff", "#ffe45c"], 0.9);
          this.gore(v.x, hy, ang, Math.min(1, flesh / 50), false);
          for (let i = 0; i < 8; i++) { const q = (i / 7 - 0.5) * 14; this.part(v.x - Math.sin(ang) * q, hy + Math.cos(ang) * q, Math.cos(ang) * (90 + rand() * 60), Math.sin(ang) * (90 + rand() * 60) - 40, 0.8, 1, pickOne(BLOOD), 520, 0.5, 4); }
        }
      } else if (flesh > 0) {
        // into the body: blood - and sparks all the same
        this.gore(v.x, hy, ang, Math.min(1.2, flesh / 60), head);
        this.sparkBurst(hx, hy, ang, head ? 8 : 5, ["#ffffff", "#ffe45c", "#ff9a3c"], 0.85);
        if (this.hitfx.length < 44) this.hitfx.push({ x: v.x - Math.cos(ang) * 2, y: hy, ang: ang + Math.PI, r: head ? 13 : 8, kind: head ? 1 : 0, life: 0, max: head ? 0.15 : 0.11, col: "" });
        if (head) {
          this.rings.push({ x: v.x, y: hy, r: 16, life: 0, max: 0.22, col: "#ff5a6a" });
          this.flashes.push({ x: v.x, y: hy, r: 28, life: 0.08, max: 0.08, col: "#ffe45c" });
        }
      }
    }
    if (w === "nade" || w === "rpg") v.dizzy = 0.9;
    if (by && by.me && v !== by) {
      this.hitMark = 0.16;
      this.texts.push({ x: v.x + (rand() - 0.5) * 6, y: v.y - 24, text: String(shownDmg), col: head ? "#ff5a6a" : isChain ? "#ffd24a" : flesh > 0 ? "#fff3b0" : "#bfe0ff", life: 0.8, vy: -26 });
      if (head) {
        this.texts.push({ x: v.x, y: v.y - 34, text: "HEADSHOT!", col: "#ff5a6a", life: 1, vy: -14 });
        audio.play("headshot", 0.75);
        this.hitStop = Math.max(this.hitStop, 0.025);
      } else audio.play("hit", 0.34);
      if (knock >= 150) this.hitStop = Math.max(this.hitStop, 0.028);
    }
    if (v.me) {
      // your armour took it: a pale flash; it got through: the red one, and a grunt. Either way the picture is knocked the way the blow was going
      if (plate > 0) this.plateFx = Math.min(1, this.plateFx + plate / 40);
      if (flesh > 0) { this.hurtFx = Math.min(1, this.hurtFx + flesh / 40); audio.play("hurt", 0.45); }
      this.cam.shake = Math.max(this.cam.shake, 2 + dmg / 20);
      this.cam.kx += Math.cos(ang) * Math.min(5, knock * 0.02); this.cam.ky += Math.sin(ang) * Math.min(4, knock * 0.012);
      if (knock >= 150) this.hitStop = Math.max(this.hitStop, 0.03);
      this.combat = 1;
    }
    if (v.bot && by && by !== v && !v.bot.target) v.bot.seen = { x: by.x, y: by.y, t: this.t };
    if (v.hp <= 0) this.kill(v, by, w, head, crit ? Math.atan2(v.vy, v.vx) : ang, crit ? 640 : Math.max(knock, dmg * 3.1));
    else if (dmg >= 30 && rand() < 0.4) this.callout(v, "hurt");
  }

  private kill(v: Sol, by: Sol | null, w: string, head: boolean, ang = 0, force = 180) {
    v.alive = false; v.hide = null; v.holo = false; v.holoK = 0; v.launch = 0; v.spin = 0; v.hp = 0; v.respawn = RESPAWN; v.deaths++; v.streak = 0; v.burn = 0; v.reload = 0; v.jet = false; v.melee = 0; v.swingT = 0; v.sayT = 0;
    v.vrot = (rand() - 0.5) * 12 + v.face * 3;
    v.rot = 0;
    // (nobody comes apart: the ragdoll takes the whole blow, in one piece)
    v.headless = false;
    // spawn articulated 7-node Verlet ragdoll with authentic hit-zone impulse!
    const hitZone: "head" | "body" | "blast" | "slash" =
      w === "rpg" || w === "nade" || w === "bolter" ? "blast"
        : w === "katana" || w === "saber" || w === "axe" || w === "chainsword" || w === "melee" ? "slash"
          : head ? "head" : "body";
    const ragForce = hitZone === "blast" ? Math.max(295, force * 1.15) : w === "chainsword" ? Math.max(320, force * 1.2) : w === "shotgun" || w === "sniper" || w === "magnum" ? Math.max(250, force) : Math.max(155, force);
    v.ragdoll = this.spawnRagdoll(v, ang, ragForce, hitZone, w);
    if (w === "chainsword" && v.ragdoll) v.ragdoll.spurt = 0.7;
    if (w === "saber") for (let i = 0; i < 7; i++) this.part(v.x, v.y - 9, (rand() - 0.5) * 65, -20 - rand() * 45, 1 + rand(), 3, pickOne(SMOKE), -30, 2, 1);
    else if (w !== "flame" && w !== "fall" && w !== "tesla") this.gore(v.x, v.y - (head ? 14 : 9), ang, w === "chainsword" || w === "bolter" ? 1.5 : 1.2, true);
    const sl = v.slots[v.cur];
    // (Astartes Bolter & Chainsword are gene-locked relics: never dropped onto the ground for ordinary operators)
    if (sl && sl.id !== "pistol" && sl.id !== "portal" && !isTankWep(sl.id) && !isBlade(AWEP[sl.id].kind) && (sl.mag > 0 || sl.ammo > 0)) this.picks.push({ x: v.x, y: v.y - 6, vx: v.vx * 0.3, vy: -80, kind: sl.id as PickKind, spot: false, t: 0, mag: sl.mag, ammo: sl.ammo, life: 14, bob: 0 });
    v.saberOn = 0;
    this.sfx("hurt", v.x, v.y, 0.8, 0.7);
    let k = by && by !== v ? by : null;
    if (!k && v.lastBy && v.lastBy !== v && this.t - v.lastByT < 4) k = v.lastBy;
    if (k && k.team !== v.team) {
      this.score[k.team]++;
      k.kills++;
      k.streak++;
      k.multi = this.t - k.lastKill < 3.5 ? k.multi + 1 : 1;
      k.lastKill = this.t;
      k.joy = 1.4;
      if (rand() < 0.5) this.callout(k, "kill");
      if (k.me) { this.killMark = 0.3; this.announce(k); }
      if (k.me) audio.play("killding", 0.55);
      if (k.me && (w === "katana" || w === "saber" || w === "axe" || w === "chainsword")) { this.zoomKick = Math.min(0.34, this.zoomKick + (w === "chainsword" ? 0.15 : 0.12)); this.slow = Math.max(this.slow, w === "chainsword" ? 0.15 : 0.12); this.zfx = v.x; this.zfy = v.y - 9; this.zfT = 0.44; }
    }
    for (const o of this.sol) if (o !== v && o.alive && o.team === v.team && Math.hypot(o.x - v.x, o.y - v.y) < 160) o.mad = 2.5;
    this.feed.push({ id: this.ids++, k: k ? k.name : "", kt: k ? k.team : -1, v: v.name, vt: v.team, w: k ? w : "suicide", head, me: !!(k && k.me) || v.me, t: this.t });
    if (this.feed.length > 5) this.feed.shift();
    if (v.me) {
      this.killer = k;
      this.say("TUMBANG!", k ? `Dihabisi ${k.name}` : "Kecelakaan kerja...", "#ff4d5e", 2.2);
      audio.play("ko", 0.7);
    }
    if (k && this.score[k.team] >= this.cfg!.kills) this.finish();
  }
  private announce(k: Sol) {
    const multi = ["", "", "DOUBLE KILL!", "TRIPLE KILL!", "MULTI KILL!"][Math.min(4, k.multi)];
    const streak = k.streak === 5 ? "MEMBANTAI!" : k.streak === 8 ? "TAK TERHENTIKAN!" : k.streak === 12 ? "DEWA PERANG!" : "";
    if (streak) { this.say(streak, `${k.streak} kill tanpa mati`, "#ff9df0", 2); audio.play("jingle", 0.6); }
    else if (multi) { this.say(multi, "", "#ffe14a", 1.6); audio.play("chime", 0.6); }
  }

  private finish() {
    if (this.phase === "end") return;
    this.phase = "end";
    this.endT = 0;
    this.slow = 1.3;
    const win = this.score[0] === this.score[1] ? -1 : this.score[0] > this.score[1] ? 0 : 1, mine = win === this.me.team;
    this.say(win < 0 ? "SERI!" : mine ? "MENANG!" : "KALAH!", win < 0 ? "Skor imbang" : `TIM ${TEAMS[win].name} JUARA`, win < 0 ? "#ffffff" : TEAMS[win].color, 4);
    audio.stinger(win < 0 ? "found" : mine ? "win" : "lose");
  }
  private rows(): ArenaRow[] {
    return this.sol.map((s) => ({ name: s.name, team: s.team, k: s.kills, d: s.deaths, dmg: Math.round(s.dmg), me: s.me })).sort((a, b) => b.k - a.k || a.d - b.d || b.dmg - a.dmg);
  }
  private result(): ArenaResult {
    const win = this.score[0] === this.score[1] ? -1 : this.score[0] > this.score[1] ? 0 : 1;
    const mvp = this.sol.slice().sort((a, b) => b.kills * 100 + b.dmg - b.deaths * 30 - (a.kills * 100 + a.dmg - a.deaths * 30))[0];
    return { win, myTeam: this.me.team, score: [this.score[0], this.score[1]], rows: this.rows(), mvp: mvp.name, mvpTeam: mvp.team };
  }

  // ───────────── projectiles ─────────────
  private emitTrail(b: Shot) {
    if (b.kind !== "bullet" && b.kind !== "laser" && b.kind !== "bolt") return;
    const dist = Math.hypot(b.x - b.sx, b.y - b.sy);
    if (dist < 10) return;
    const B = BEAM[b.by.team];
    if (b.kind === "bolt") {
      this.trails.push({ x0: b.sx, y0: b.sy, x1: b.x, y1: b.y, w: 2.3, col: "#ff9e28", hot: "#fff6c2", life: 0, max: 0.24 });
      return;
    }
    if (b.w === "sniper") {
      // dramatic persistent supersonic contrail + spaced Mach shock rings!
      this.trails.push({ x0: b.sx, y0: b.sy, x1: b.x, y1: b.y, w: 2.6, col: TEAMS[b.by.team].bullet, hot: "#ffffff", life: 0, max: 0.48 });
      const rings = Math.min(4, Math.floor(dist / 65));
      for (let k = 1; k <= rings; k++) {
        const f = k / (rings + 1);
        this.rings.push({ x: b.sx + (b.x - b.sx) * f, y: b.sy + (b.y - b.sy) * f, r: 9, life: 0, max: 0.22, col: "#ffffff" });
      }
    } else if (b.w === "magnum") {
      this.trails.push({ x0: b.sx, y0: b.sy, x1: b.x, y1: b.y, w: 2.0, col: "#ffd84a", hot: "#fff9d2", life: 0, max: 0.26 });
    } else if (b.kind === "laser") {
      this.trails.push({ x0: b.sx, y0: b.sy, x1: b.x, y1: b.y, w: 1.8, col: B.col, hot: B.hot, life: 0, max: 0.16 });
    } else if (b.w === "rifle" || b.w === "shotgun" || b.w === "pistol") {
      if (this.trails.length < 48) this.trails.push({ x0: b.sx, y0: b.sy, x1: b.x, y1: b.y, w: 1.1, col: TEAMS[b.by.team].bullet, hot: "#fff8dc", life: 0, max: b.w === "shotgun" ? 0.13 : 0.15 });
    }
  }
  /** Mass-reactive detonation of an Adeptus Astartes .75 cal Bolter shell: erupts inside its target or blows chunks out of stone! */
  private boltDetonate(x: number, y: number, by: Sol, direct: Sol | null) {
    this.blame = by;
    this.flashes.push({ x, y, r: 44, life: 0.14, max: 0.14, col: "#ff9e28" });
    this.flashes.push({ x, y, r: 20, life: 0.06, max: 0.06, col: "#ffffff" });
    this.rings.push({ x, y, r: 24, life: 0, max: 0.24, col: "#ffd24a" });
    this.rings.push({ x, y, r: 13, life: 0, max: 0.14, col: "#ffffff" });
    if (this.hitfx.length < 44) this.hitfx.push({ x, y, ang: rand() * Math.PI, r: 13, kind: 1, life: 0, max: 0.14, col: "#ffd24a" });
    for (let i = 0; i < 10; i++) { const a = rand() * PI2, v = 35 + rand() * 135; this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 25, 0.18 + rand() * 0.18, 2, pickOne(BOLTC), 120, 2.5, i < 7 ? 5 : 9); }
    for (let i = 0; i < 4; i++) this.part(x, y, (rand() - 0.5) * 45, -18 - rand() * 30, 0.55 + rand() * 0.35, 2 + (i & 1), pickOne(SMOKE), -24, 1.8, 1);
    this.pushRagdolls(x, y, 36, 220, true);
    if (!direct) this.blastTerrain(x, y, 16, 48);
    if (this.map.theme.decor === "cave") {
      for (const d of this.stalags) if (Math.abs(d.x - x) < 28 && Math.abs(d.y - y) < 42 && rand() < 0.6) this.breakDecor(d, 0.06 + rand() * 0.2);
    }
    // splash blast wounds clustered enemies (and finishes off the internal mass-reactive shock)
    for (const e of this.sol) {
      if (!e.alive || e === direct || e === by || e.team === by.team || e.shield > 0) continue;
      const d = Math.hypot(e.x - x, e.y - 9 - y);
      if (d > 28 || !this.clear(x, y, e.x, e.y - 9)) continue;
      const f = 1 - d / 28, ang = Math.atan2(e.y - 9 - y, e.x - x);
      if (this.holoFacing(e, x, y)) { this.holoHit(e, 18 * f, by, e.x - Math.cos(ang) * HOLO_R, this.holoY(e) - Math.sin(ang) * HOLO_R); continue; }
      this.hurt(e, Math.max(4, 18 * f * (e.hide ? 0.5 : 1)), by, "bolter", ang, 110 * f, false);
    }
    this.sfx("boltboom", x, y, by.me ? 0.72 : 0.45, 0.92 + rand() * 0.18);
    const cd = Math.hypot(x - this.cam.x, y - this.cam.y);
    if (cd < 220) this.cam.shake = Math.max(this.cam.shake, clamp(4.2 - cd / 65, 0, 4.2));
  }

  private updShots(dt: number) {
    const m = this.map;
    const parriers = this.sol.filter((e) => e.alive && !e.holo && ((e.slots[e.cur]?.id === "saber" && e.saberOn > 0.7) || e.slots[e.cur]?.id === "katana" || (e.slots[e.cur]?.id === "chainsword" && e.swingT > 0)));
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const b = this.shots[i];
      this.blame = b.by;
      b.px = b.x; b.py = b.y;
      b.life -= dt;
      if (!b.wz && b.kind !== "flame" && b.kind !== "portal" && b.by.team !== this.me.team && this.me.alive && Math.abs(b.x - this.me.x) < 34 && Math.abs(b.y - (this.me.y - 9)) < 26) { b.wz = true; audio.play("whiz", 0.5, { pan: clamp((b.x - this.me.x) / 30, -1, 1), pitch: 0.8 + rand() * 0.5 }); }
      let dead = b.life <= 0;
      if (b.kind === "bolt") {
        // .75 cal Astartes mass-reactive gyrojet bolt: second-stage micro-rocket acceleration + smart mini-guided homing lock!
        const sp = Math.hypot(b.vx, b.vy) || 1, ns = Math.min(1320, sp + 920 * dt);
        let ang = Math.atan2(b.vy, b.vx);
        if (b.dist > 18) {
          let lockE: Sol | null = null, bestSc = 165;
          for (const e of this.sol) {
            if (!e.alive || e.hide || e.team === b.by.team) continue;
            const tx = e.x, ty = e.y - (e.crouch ? 6 : 10), d = Math.hypot(tx - b.x, ty - b.y);
            if (d > 165 || d < 6) continue;
            const da = Math.abs(angDiff(ang, Math.atan2(ty - b.y, tx - b.x)));
            if (da > 0.45) continue;
            const sc = d + da * 120;
            if (sc < bestSc && this.clear(b.x, b.y, tx, ty)) { bestSc = sc; lockE = e; }
          }
          if (lockE) {
            const ta = Math.atan2(lockE.y - (lockE.crouch ? 6 : 10) - b.y, lockE.x - b.x);
            ang += clamp(angDiff(ang, ta), -4.6 * dt, 4.6 * dt);
          }
        }
        b.vx = Math.cos(ang) * ns; b.vy = Math.sin(ang) * ns;
        if (rand() < dt * 95) this.part(b.x - Math.cos(ang) * 4, b.y - Math.sin(ang) * 4, -b.vx * 0.08 + (rand() - 0.5) * 22, -b.vy * 0.08 + (rand() - 0.5) * 22, 0.13, 2, pickOne(BOLTC), 0, 2, 5);
        if (rand() < dt * 55) this.part(b.x - Math.cos(ang) * 5, b.y - Math.sin(ang) * 5, (rand() - 0.5) * 14, -8 + (rand() - 0.5) * 14, 0.34, 2, pickOne(["#c8c2b8", "#7a747e"]), -18, 2, 1);
      } else if (b.kind === "rocket") {
        const sp = Math.hypot(b.vx, b.vy), ns = Math.min(800, sp + 760 * dt);
        b.vx *= ns / sp; b.vy *= ns / sp;
        const perp = Math.atan2(b.vy, b.vx) + Math.PI * 0.5;
        const wob = Math.sin(this.t * 36 + i) * 18;
        if (rand() < dt * 85) this.part(b.x, b.y, Math.cos(perp) * wob + (rand() - 0.5) * 18, Math.sin(perp) * wob - 10, 0.78, 2 + (rand() < 0.4 ? 1 : 0), pickOne(SMOKE), -26, 1.9, 1);
        if (rand() < dt * 65) this.part(b.x, b.y, -b.vx * 0.14 + (rand() - 0.5) * 20, -b.vy * 0.14 + (rand() - 0.5) * 20, 0.14, 2, pickOne(FIRE), 0, 2, 5);
      } else if (b.kind === "flame") {
        b.vx *= Math.exp(-dt * 2.5);
        b.vy = b.vy * Math.exp(-dt * 2.5) - 72 * dt;
        b.r = Math.min(9.5, b.r + dt * 18);
        if (rand() < dt * 14) this.part(b.x, b.y, (rand() - 0.5) * 24, -22 - rand() * 20, 0.42, 2, pickOne(["#4a4450", "#ff9a3c"]), -32, 2, rand() < 0.4 ? 5 : 1);
      } else if (b.kind === "saw") {
        b.spin += dt * 36;
        if (rand() < dt * 45) this.part(b.x, b.y, -b.vx * 0.2 + (rand() - 0.5) * 50, -b.vy * 0.2 - 20 + (rand() - 0.5) * 50, 0.18, 1, pickOne(["#ffffff", "#ffe45c", "#ff7a2a"]), 180, 1.5, 5);
      } else if (b.kind === "shock") {
        if (rand() < dt * 60) this.part(b.x, b.y, (rand() - 0.5) * 90, (rand() - 0.5) * 90, 0.1 + rand() * 0.12, 1, pickOne(ELC), 0, 3, 9);
      } else if (b.kind === "portal") {
        if (rand() < dt * 40) this.part(b.x, b.y, (rand() - 0.5) * 30, (rand() - 0.5) * 30, 0.2, 1, PORTC[b.by.team][b.slot], 0, 3, 5);
      } else if (b.kind === "laser" && rand() < dt * 32) {
        const B = BEAM[b.by.team];
        this.part(b.x, b.y, (rand() - 0.5) * 35, (rand() - 0.5) * 35, 0.14, 1, pickOne([B.col, B.hot]), 0, 4, 5);
      }
      if (dead) {
        if (b.kind === "rocket") this.explode(b.x, b.y, 50, AWEP.rpg.dmg, b.by, "rpg");
        else this.emitTrail(b);
        this.shots.splice(i, 1);
        continue;
      }
      const steps = Math.max(1, Math.ceil((Math.hypot(b.vx, b.vy) * dt) / 3)), sx = (b.vx * dt) / steps, sy = (b.vy * dt) / steps;
      const turnable = parriers.length > 0 && (b.kind === "bullet" || b.kind === "laser" || b.kind === "saw");
      for (let k = 0; k < steps && !dead; k++) {
        const nx = b.x + sx, ny = b.y + sy;
        if (solidPx(m, nx, ny)) {
          // into an open portal: out of its twin, still flying; the ball of the portal gun: a portal opens where it strikes
          const via = b.kind === "portal" ? null : this.portalAt(nx, ny, b.vx, b.vy);
          if (via) { this.emitTrail(b); this.shotVia(b, via); break; }
          if (b.kind === "portal") { this.placePortal(b, nx, ny); dead = true; break; }
          if (b.kind === "saw" && b.bounce > 0) {
            b.bounce--;
            const hx = solidPx(m, nx, b.y), hy = solidPx(m, b.x, ny);
            if (hx || !hy) b.vx = -b.vx;
            if (hy || !hx) b.vy = -b.vy;
            this.sparks(b.x, b.y, 10, ["#ffffff", "#ffe45c", "#ff8a30"]);
            this.hitfx.push({ x: b.x, y: b.y, ang: Math.atan2(b.vy, b.vx), r: 9, kind: 0, life: 0, max: 0.12, col: "" });
            this.hitTerrain(nx, ny, TPOW.saw ?? 16, Math.atan2(-b.vy, -b.vx));
            this.sfx("wall", b.x, b.y, 0.55, 1.45);
            break;
          }
          this.emitTrail(b);
          this.impact(b, nx, ny);
          // the rock takes it too: chipped, cracked - broken, once it has had enough (or the round is heavy enough)
          if (b.kind !== "rocket" && b.kind !== "flame") this.hitTerrain(nx, ny, TPOW[b.w] ?? 6, Math.atan2(b.vy, b.vx));
          dead = true;
          break;
        }
        b.x = nx; b.y = ny; b.dist += 3;
        // (a shot through a stalactite brings it down - on whoever is under it)
        if (this.stalagAt.size && b.kind !== "flame" && b.kind !== "portal") { const sd = this.stalagAt.get(Math.floor(b.y / AT) * m.w + Math.floor(b.x / AT)); if (sd && Math.abs(b.x - sd.x) < 4) { this.breakDecor(sd); this.sparks(b.x, b.y, 3); } }
        if (turnable) {
          let turned = false;
          for (const e of parriers) {
            if (e.team === b.by.team || b.tried.includes(e.id)) continue;
            if (Math.abs(b.x - e.x) > 16 || Math.abs(b.y - (e.y - 8)) > 16) continue;
            b.tried.push(e.id);
            const inc = Math.atan2(-b.vy, -b.vx);
            const isKatana = e.slots[e.cur]?.id === "katana";
            // Katana parries cleanly during active swing (or facing shots directly); Lightsaber also auto-guards!
            const cone = e.swingT > 0 ? 2.2 : isKatana ? 0.78 : 1.25;
            const chance = e.me ? 1 : isKatana ? (e.swingT > 0 ? 0.85 : 0.35) : 0.62;
            if (Math.abs(angDiff(e.aim, inc)) > cone || rand() > chance) continue;
            this.emitTrail(b);
            this.deflect(b, e);
            turned = true;
            break;
          }
          if (turned) break;
        }
        // reactive shots nudging fallen ragdolls!
        if (b.kind !== "flame" && b.dist > 8 && k % 3 === 0) {
          for (const c of this.corpses) {
            const ch = c.nodes[1];
            if (Math.abs(b.x - ch.x) < 7 && Math.abs(b.y - ch.y) < 7) {
              this.pushRagdolls(b.x, b.y, 18, b.w === "shotgun" || b.w === "sniper" || b.w === "magnum" ? 150 : 65, false, Math.atan2(b.vy, b.vx));
              if (!c.dry) this.gore(b.x, b.y, Math.atan2(b.vy, b.vx), 0.25, false);
              break;
            }
          }
        }
        for (const e of this.sol) {
          if (b.kind === "portal") break; // (the ball of the portal gun goes through anybody)
          if (!e.alive || e === b.by || e.team === b.by.team || b.hit.includes(e.id)) continue;
          // a hologram shield raised towards it: the shield takes it (fire washes over it, and wears it down more slowly)
          if (e.holoK > 0.5 && this.holoBlocks(e, b.x, b.y, b.vx, b.vy)) {
            b.hit.push(e.id);
            if (b.kind === "rocket") this.explode(b.x, b.y, 50, AWEP.rpg.dmg, b.by, "rpg");
            else {
              const wd = AWEP[b.w];
              this.holoHit(e, b.kind === "flame" ? b.dmg * 0.6 : b.kind === "shock" ? b.dmg * 2.5 : b.kind === "bolt" ? b.dmg * 1.25 : b.dmg * (wd.pellets > 1 || wd.id === "uzi" ? clamp(1.15 - (b.dist / wd.range) * 0.6, 0.45, 1.1) : 1), b.by, b.x, b.y);
              if (b.kind === "bolt") this.boltDetonate(b.x, b.y, b.by, e);
              if (b.kind !== "flame") this.emitTrail(b);
            }
            dead = true;
            break;
          }
          if (b.kind === "flame") {
            if (Math.abs(b.x - e.x) < b.r + 4 && b.y > e.y - HH - b.r && b.y < e.y + b.r) {
              b.hit.push(e.id);
              if (e.shield > 0) continue;
              this.hurt(e, b.dmg, b.by, "flame", Math.atan2(b.vy, b.vx), 10, false);
              e.burn = 2.8; e.burnBy = b.by;
            }
            continue;
          }
          if (e.hide) {
            // tucked in behind cover: the cover takes the bullet
            const q = e.hide;
            if (Math.abs(b.x - q.x) > q.w || b.y < q.y - q.h || b.y > q.y + 1) continue;
            b.hit.push(e.id);
            if (b.kind === "rocket") this.explode(b.x, b.y, 50, AWEP.rpg.dmg, b.by, "rpg");
            else if (b.kind === "bolt") { this.emitTrail(b); this.boltDetonate(b.x, b.y, b.by, null); this.coverFx(b, q); }
            else { this.emitTrail(b); this.coverFx(b, q); }
            dead = true;
            break;
          }
          const dk = e.duck > 0.5, dx = b.x - e.x, hy = b.y - (e.y - (dk ? 8 : 14)), head = dx * dx + hy * hy < (dk ? 22 : 28), body = Math.abs(dx) < (e.skin === ASTARTES ? 6 : 5) && b.y > e.y - (dk ? 4 : 11) && b.y < e.y + 1;
          if (!head && !body) continue;
          b.hit.push(e.id);
          if (e.shield > 0) { this.sparks(b.x, b.y, 6); this.rings.push({ x: b.x, y: b.y, r: 10, life: 0, max: 0.16, col: TEAMS[e.team].color }); if (!AWEP[b.w].pierce) { this.emitTrail(b); dead = true; break; } continue; }
          if (b.kind === "rocket") { this.explode(b.x, b.y, 50, AWEP.rpg.dmg, b.by, "rpg"); dead = true; break; }
          const w = AWEP[b.w];
          let dmg = b.dmg * (head ? w.head : 1);
          if (w.pellets > 1 || w.id === "uzi") dmg *= clamp(1.15 - (b.dist / w.range) * 0.6, 0.45, 1.1);
          const kb = b.kind === "bolt" ? 195 : w.kind === "saw" ? 210 : w.id === "sniper" ? 250 : w.id === "magnum" ? 180 : w.pellets > 1 ? 42 : 30 + dmg * 1.3;
          this.hurt(e, dmg, b.by, b.w, Math.atan2(b.vy, b.vx), kb, head, b.crit);
          if (b.kind === "bolt") this.boltDetonate(b.x, b.y, b.by, e);
          if (b.kind === "shock") this.electrocute(e, b.by);
          if (b.kind === "laser") { const B = BEAM[b.by.team]; for (let q = 0; q < 6; q++) this.part(b.x, b.y, (rand() - 0.5) * 130, -rand() * 90, 0.28, 1, pickOne([B.col, B.hot, "#ffffff"]), 300, 1, 5); }
          if (!w.pierce) { this.emitTrail(b); dead = true; break; }
        }
      }
      if (dead) this.shots.splice(i, 1);
    }
  }
  private impact(b: Shot, x: number, y: number) {
    if (b.kind === "rocket") { this.explode(b.px, b.py, 50, AWEP.rpg.dmg, b.by, "rpg"); return; }
    if (b.kind === "bolt") { this.boltDetonate(b.px, b.py, b.by, null); return; }
    if (b.kind === "flame") { if (rand() < 0.35) this.part(b.x, b.y, 0, -22, 0.55, 3, pickOne(SMOKE), -30, 2, 1); return; }
    if (b.kind === "shock") { this.zapBurst(b.x, b.y, Math.atan2(b.vy, b.vx)); return; }
    const back = Math.atan2(-b.vy, -b.vx), heavy = b.w === "sniper" || b.w === "magnum" || b.w === "saw";
    if (b.kind === "laser") {
      // a blaster bolt burns a sizzling glowing scar + ion flash into whatever it hits!
      const B = BEAM[b.by.team];
      if (this.scorch.length < 70) this.scorch.push({ x, y, life: 1.6, col: B.col });
      this.flashes.push({ x: b.x, y: b.y, r: 22, life: 0.08, max: 0.08, col: B.col });
      this.rings.push({ x: b.x, y: b.y, r: 10, life: 0, max: 0.16, col: B.col });
      this.hitfx.push({ x: b.x, y: b.y, ang: back, r: 8, kind: 2, life: 0, max: 0.14, col: B.col });
      for (let i = 0; i < 8; i++) this.part(b.x, b.y, Math.cos(back) * (65 + rand() * 55) + (rand() - 0.5) * 120, Math.sin(back) * (65 + rand() * 55) - rand() * 75, 0.32, 1, pickOne([B.col, B.hot, "#ffffff"]), 300, 1, 5);
      this.part(b.x, b.y, 0, -18, 0.85, 2, pickOne(SMOKE), -22, 2, 1);
      this.tg.fillStyle = "rgba(14,8,6,0.7)";
      this.tg.fillRect(Math.floor(x) - 1, Math.floor(y) - 1, 3, 2);
      if (rand() < 0.45) this.sfx("wall", x, y, 0.28, 1.65);
      return;
    }
    this.stars.push({ x: b.x, y: b.y, life: heavy ? 0.09 : 0.07, col: "#ffffff" });
    this.hitfx.push({ x: b.x, y: b.y, ang: back, r: heavy ? 10 : 6, kind: heavy ? 1 : 0, life: 0, max: heavy ? 0.14 : 0.1, col: "" });
    if (heavy) {
      this.flashes.push({ x: b.x, y: b.y, r: 24, life: 0.08, max: 0.08, col: "#ffe470" });
      this.rings.push({ x: b.x, y: b.y, r: 12, life: 0, max: 0.18, col: "#ffd27a" });
    }
    // directional ricochet sparks
    const spCount = b.kind === "saw" ? 10 : heavy ? 8 : 5;
    for (let i = 0; i < spCount; i++) {
      const a = back + (rand() - 0.5) * 1.4, sp = 70 + rand() * 140;
      this.part(b.x, b.y, Math.cos(a) * sp, Math.sin(a) * sp - 20, 0.18 + rand() * 0.16, 1, pickOne(["#ffffff", "#ffe868", "#ff9a3c"]), 260, 1.2, i % 2 ? 2 : 5);
    }
    // material-aware chips (emerald moss & petals in Hutan Bastion, glowing crystal dust in Goa Kristal, golden sand in Gurun, rubble in Kota!)
    const isCave = this.map.theme.decor === "cave", isJungle = this.map.theme.decor === "jungle";
    for (let i = 0; i < (heavy ? 5 : 3); i++) {
      const col = isCave && rand() < 0.45 ? pickOne(["#5ff0e0", "#d57dff", "#8ef8d2"]) : isJungle && rand() < 0.5 ? pickOne(["#28b850", "#96f86c", "#ff6ca8", "#ffe25a"]) : this.dustCol();
      this.part(b.x, b.y, Math.cos(back) * (35 + rand() * 55) + (rand() - 0.5) * 45, Math.sin(back) * (35 + rand() * 55) - 25 - rand() * 40, 0.4 + rand() * 0.2, isCave && col.startsWith("#5") ? 1 : 2, col, isJungle ? 240 : 320, 1.8, isCave && col !== this.dustCol() ? 5 : 6);
    }
    this.tg.fillStyle = "rgba(16,12,18,0.62)";
    this.tg.fillRect(Math.floor(x) - 1, Math.floor(y) - 1, heavy ? 3 : 2, heavy ? 3 : 2);
    if (rand() < 0.4) this.sfx("wall", x, y, heavy ? 0.45 : 0.35);
    else if (rand() < 0.3) this.sfx("ricochet", x, y, 0.32, 0.8 + rand() * 0.6);
  }
  private sparks(x: number, y: number, n: number, cols = ["#fff3a0", "#ffd23a"]) {
    for (let i = 0; i < n; i++) this.part(x, y, (rand() - 0.5) * 180, (rand() - 0.5) * 180 - 30, 0.16 + rand() * 0.16, 1, pickOne(cols), 220, 1, 2);
  }
  private explode(x: number, y: number, r: number, dmg: number, by: Sol, w: string) {
    this.blame = by;
    this.caveBlast(x, y);
    // epic multi-stage detonation: blinding flash + double expanding shockwave + fireball + glowing shrapnel + crater!
    this.flashes.push({ x, y, r: r * 3.0, life: 0.32, max: 0.32, col: "#ffb35a" });
    this.flashes.push({ x, y, r: r * 1.4, life: 0.1, max: 0.1, col: "#ffffff" });
    this.rings.push({ x, y, r: r * 1.3, life: 0, max: 0.38, col: "#ffb347" });
    this.rings.push({ x, y, r: r * 0.85, life: 0, max: 0.22, col: "#ffffff" });
    this.hitfx.push({ x, y, ang: rand() * Math.PI, r: 22, kind: 1, life: 0, max: 0.18, col: "" });
    for (let i = 0; i < 24; i++) { const a = rand() * PI2, v = 35 + rand() * 170; this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 45, 0.32 + rand() * 0.38, 3 + ((rand() * 3) | 0), pickOne(FIRE), -60, 2.8, 5); }
    for (let i = 0; i < 16; i++) { const a = rand() * PI2, v = 12 + rand() * 72; this.part(x + Math.cos(a) * 6, y + Math.sin(a) * 6, Math.cos(a) * v, Math.sin(a) * v - 35, 1.1 + rand() * 1.2, 3 + ((rand() * 4) | 0), pickOne(SMOKE), -32, 1.4, 1); }
    for (let i = 0; i < 14; i++) this.part(x, y, (rand() - 0.5) * 300, -rand() * 250, 1.5, 2, pickOne([this.map.theme.dirt[0], this.map.theme.rock[0], "#3a3236"]), 620, 0.35, 6);
    this.sparks(x, y, 16, ["#ffffff", "#fff3a0", "#ff9a3c"]);
    this.tg.fillStyle = "rgba(14,10,12,0.38)";
    for (let k = 0; k < 56; k++) {
      const a = rand() * PI2, d = Math.sqrt(rand()) * r * 0.65, px = x + Math.cos(a) * d, py = y + Math.sin(a) * d;
      if (solidPx(this.map, px, py)) this.tg.fillRect(Math.floor(px), Math.floor(py), 2, 2);
    }
    // toss nearby fallen ragdolls sky-high with blast waves!
    this.pushRagdolls(x, y, r * 1.55, 380, true);
    this.blastTerrain(x, y, r, dmg);
    for (const e of this.sol) {
      if (!e.alive || (e !== by && e.team === by.team)) continue;
      const cx = e.x, cy = e.y - 9, d = Math.hypot(cx - x, cy - y);
      if (d > r + 10 || !this.clear(x, y, cx, cy)) continue;
      const f = clamp(1 - d / (r + 10), 0, 1), ang = Math.atan2(cy - y, cx - x), kb = 140 + 380 * f;
      // a hologram shield raised towards the blast takes it, and most of the push
      if (e.shield <= 0 && this.holoFacing(e, x, y)) {
        this.holoHit(e, dmg * (0.2 + 0.8 * f), by, e.x - Math.cos(ang) * HOLO_R, this.holoY(e) - Math.sin(ang) * HOLO_R);
        e.vx += Math.cos(ang) * kb * 0.25;
        continue;
      }
      if (e.shield <= 0 && !e.hide) { e.vx += Math.cos(ang) * kb; e.vy += Math.sin(ang) * kb - 95 * f; e.stun = Math.max(e.stun, 0.12 + 0.3 * f); }
      // (cover takes the worst of a blast)
      this.hurt(e, dmg * (0.2 + 0.8 * f) * (e === by ? 0.45 : 1) * (e.hide ? 0.4 : 1), by, w, ang, 0, false, f > 0.72 && e !== by); // (a direct hit is a critical one)
    }
    const d = Math.hypot(x - this.cam.x, y - this.cam.y);
    this.cam.shake = Math.max(this.cam.shake, clamp(10.5 - d / 48, 0, 10.5));
    if (d < 130) this.hitStop = Math.max(this.hitStop, 0.028);
    this.sfx("boom", x, y, 1.15);
  }
  private updNades(dt: number) {
    const m = this.map;
    for (let i = this.nades.length - 1; i >= 0; i--) {
      const n = this.nades[i];
      n.fuse -= dt;
      n.vy += NADE_G * dt;
      if (m.theme.weather === "sand") n.vx += this.gust * 10 * dt;
      const steps = Math.max(1, Math.ceil((Math.hypot(n.vx, n.vy) * dt) / 2));
      for (let k = 0; k < steps; k++) {
        // (into an open portal: out of its twin)
        const via = this.portalAt(n.x + (n.vx * dt) / steps, n.y - 2 + (n.vy * dt) / steps, n.vx, n.vy);
        if (via) { const o = this.portalOut(via[0], via[1], via[2], n.vx, n.vy, 60, 4); n.x = o[0]; n.y = o[1] + 2; n.vx = o[2]; n.vy = o[3]; via[0].fx = via[1].fx = 0.7; this.sfx("portalgo", n.x, n.y, 0.4, 1.4); continue; }
        const nx = n.x + (n.vx * dt) / steps;
        if (solidPx(m, nx, n.y - 2)) { if (Math.abs(n.vx) > 60) this.sfx("thunk", n.x, n.y, 0.25, 1.6); n.vx = -n.vx * 0.5; } else n.x = nx;
        const ny = n.y + (n.vy * dt) / steps, r = Math.floor(ny / AT);
        const plat = n.vy > 0 && tileAt(m, Math.floor(n.x / AT), r) === PLAT && n.y <= r * AT + 0.5;
        if (solidPx(m, n.x, ny) || plat) {
          if (n.vy > 0) { if (n.vy > 90) this.sfx("thunk", n.x, n.y, 0.25, 1.6); n.vy = -n.vy * 0.42; n.vx *= 0.75; if (Math.abs(n.vy) < 30) n.vy = 0; }
          else n.vy = -n.vy * 0.5;
        } else n.y = ny;
      }
      n.rot += n.vx * dt * 0.25;
      if (!n.beep && n.fuse < 0.5) { n.beep = true; this.sfx("beep", n.x, n.y, 0.7); }
      if (n.fuse <= 0) { this.explode(n.x, n.y - 3, 54, 105, n.by, "nade"); this.nades.splice(i, 1); }
    }
  }
  private updPicks(dt: number) {
    for (let i = this.picks.length - 1; i >= 0; i--) {
      const p = this.picks[i];
      p.bob += dt;
      if (p.spot) { if (p.t > 0) p.t -= dt; continue; }
      if ((p.life -= dt) <= 0) { this.picks.splice(i, 1); continue; }
      p.vy = Math.min(400, p.vy + GRAV * dt);
      const nx = p.x + p.vx * dt;
      if (!solidPx(this.map, nx, p.y - 3)) p.x = nx; else p.vx = 0;
      const ny = p.y + p.vy * dt, r = Math.floor(ny / AT);
      if (p.vy > 0 && (solidPx(this.map, p.x, ny) || (tileAt(this.map, Math.floor(p.x / AT), r) === PLAT && p.y <= r * AT + 0.5))) { p.y = r * AT; p.vy = 0; p.vx *= 0.5; }
      else p.y = ny;
    }
  }

  // ───────────── particles ─────────────
  /** kinds: 0 plain, 1 smoke, 2 spark streak, 3 spent case, 4 blood, 5 fire and glowing embers, 6 debris, 7 a head, 8 a drop of water, 9 a hot spark: a glowing streak that bounces where it lands */
  private part(x: number, y: number, vx: number, vy: number, life: number, size: number, col: string, grav: number, drag: number, kind: number) {
    if (this.parts.length > 1800) return;
    this.parts.push({ x, y, vx, vy, life, max: life, size, col, grav, drag, kind, rot: 0, vr: kind === 3 ? (rand() - 0.5) * 30 : 0, spr: null, n: 0 });
  }
  private updParts(dt: number) {
    const m = this.map;
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) { this.parts.splice(i, 1); continue; }
      p.vy += p.grav * dt;
      const k = Math.exp(-p.drag * dt);
      p.vx *= k; p.vy *= k;
      const nx = p.x + p.vx * dt, ny = p.y + p.vy * dt;
      if (p.kind === 3 || p.kind === 6 || p.kind === 7 || p.kind === 9) {
        if (solidPx(m, nx, p.y)) p.vx = -p.vx * 0.4; else p.x = nx;
        if (solidPx(m, p.x, ny)) {
          if (p.kind === 3 && p.n === 0 && this.shellT <= 0 && Math.abs(p.vy) > 80) { this.shellT = 0.07; this.sfx("shell", p.x, p.y, 0.25); }
          p.n++;
          p.vy = Math.abs(p.vy) > 60 ? -p.vy * 0.35 : 0;
          p.vx *= 0.6;
          p.vr *= 0.6;
        } else p.y = ny;
        p.rot += p.vr * dt;
      } else if (p.kind === 4) {
        // (a drop of blood lands: a puddle on the floor, a streak down a wall - and it stays)
        if (solidPx(m, nx, ny)) { this.splat(p.x, p.y, p.size > 1 ? 2 : rand() < 0.4 ? 1 : 0); this.parts.splice(i, 1); continue; }
        p.x = nx; p.y = ny;
      } else if (p.kind === 8) {
        if (solidPx(m, nx, ny) || tileAt(m, Math.floor(nx / AT), Math.floor(ny / AT)) === PLAT) {
          for (let q = 0; q < 3; q++) this.part(nx, ny - 1, (rand() - 0.5) * 40, -30 - rand() * 40, 0.3, 1, "#bfe8ff", 300, 1, 0);
          if (Math.abs(nx - this.cam.x) < 200 && Math.abs(ny - this.cam.y) < 150) this.sfx("drip", nx, ny, 0.35, 0.9 + rand() * 0.3);
          this.parts.splice(i, 1);
          continue;
        }
        p.x = nx; p.y = ny;
      } else { p.x = nx; p.y = ny; }
    }
  }

  // ───────────── the bots ─────────────
  private prm(s: Sol) {
    // your own side fights like veterans: quick to react, a steady aim, light on their feet (the enemy is as good as the difficulty says)
    if (s.team === this.me.team) return { react: 0.24, err: 0.08, dodge: 0.95, turn: 10.5 };
    const d = DIFFS[this.cfg!.diff];
    return { react: d.react, err: d.aimErr, dodge: d.dodge, turn: d.id === "hard" ? 11 : d.id === "easy" ? 5.5 : 8 };
  }
  private lob(s: Sol, tx: number, ty: number) {
    const pv = this.pivot(s), sy0 = pv.y - 4, dx = tx - pv.x, X = Math.max(8, Math.abs(dx)), Y = -(ty - sy0), v2 = NADE_V * NADE_V, g = NADE_G;
    const disc = v2 * v2 - g * (g * X * X + 2 * Y * v2);
    const th = disc < 0 ? Math.PI / 4 : Math.atan((v2 - Math.sqrt(disc)) / (g * X));
    return dx >= 0 ? -th : Math.PI + th;
  }
  private botThink(s: Sol, dt: number) {
    const b = s.bot!, c = s.ctl, P = this.prm(s), me = this.me, ally = s.team === me.team;
    c.fire = false; c.nade = false; c.melee = false; c.reload = false; c.swap = false; c.pick = false; c.drop = false; c.jet = false; c.mx = 0; c.sprint = false; c.guard = false;
    b.react -= dt; b.errT -= dt; b.burstT -= dt; b.strafeT -= dt; b.hopT -= dt; b.pathT -= dt; b.nadeCd -= dt; b.swapCd -= dt; b.unstuck -= dt;
    if (this.phase !== "live") { c.aim = s.aim; return; }
    if (s.hide) {
      // lying low: until patched up or tired of waiting - or until somebody walks close enough to ambush
      c.aim = s.aim;
      let out = s.hp >= 92 || s.hideT > 9;
      for (const e of this.sol) if (e.alive && e.team !== s.team && !e.hide && Math.hypot(e.x - s.x, e.y - s.y) < 44) out = true;
      if (out) { c.pick = true; b.pathT = 0; b.think = 0; }
      return;
    }
    if (s.carrier && this.botPortal(s, dt)) return;
    const sl = s.slots[s.cur], w = AWEP[sl ? sl.id : "pistol"], sab = isBlade(w.kind);
    if ((b.think -= dt) <= 0) {
      b.think = 0.12 + rand() * 0.1;
      b.hideGo = false; b.escort = false;
      let best: Sol | null = null, bd = 1e9;
      for (const e of this.sol) {
        if (!e.alive || e.team === s.team) continue;
        const d = Math.hypot(e.x - s.x, e.y - s.y);
        // (whoever is tucked away in a hiding place goes unseen unless you nearly trip over them; whoever ducks behind a low wall is out of sight from beyond it)
        if (d > 440 || (e.hide && d > 24) || !this.clear(s.x, s.y - 10, e.x, e.y - (e.crouch ? 5 : 10))) continue;
        let sc = d - (e === b.target ? 80 : 0) + (e.shield > 0 ? 200 : 0);
        // your side tells the squad what it sees - and goes first for whoever you are fighting, whoever is shooting at you, and whoever is nearly down
        if (ally) { this.spot(e); sc -= (e === this.focusE && this.t - this.focusT < 2.5 ? 90 : 0) + (me.alive && me.lastBy === e && this.t - me.lastByT < 2.5 ? 80 : 0) + (e.hp < 40 ? 45 : 0); }
        if (sc < bd) { bd = sc; best = e; }
      }
      if (best && best !== b.target) { b.react = P.react * (0.6 + rand() * 0.8); b.lock = 0; s.alert = 0.7; if (ally && rand() < 0.2) this.callout(s, "spot"); }
      b.target = best;
      if (best) b.seen = { x: best.x, y: best.y, t: this.t };
      // Bots intelligently pick from ALL 12 weapons based on distance, ammo & personality!
      if (b.swapCd <= 0) {
        const d = best ? Math.hypot(best.x - s.x, best.y - s.y) : 200;
        const val = (q: Slot | null) => {
          if (!q) return -999;
          const wd = AWEP[q.id], blade = isBlade(wd.kind);
          if (wd.kind === "portal") return -500; // (not a weapon to fight with)
          if (!blade && q.mag <= 0 && q.ammo <= 0) return -99;
          let sc = wd.rank * 7 + (q.id === b.fav ? 24 : 0);
          // an Adeptus Astartes fights with his sacred Bolter Rifle at range and his roaring Chainsword up close!
          if (wd.id === "bolter") sc += d >= 80 ? 52 : 12;
          else if (wd.id === "chainsword") sc += d < 105 ? 68 : d < 165 ? 24 : -26;
          else if (blade) sc += d < 95 ? 48 : d < 160 ? 15 : -30;
          else if (wd.id === "sniper") sc += d > 220 ? 32 : -22;
          else if (wd.id === "shotgun" || wd.id === "flame") sc += d < 120 ? 30 : -35;
          else if (wd.id === "rpg") sc += d > 110 && d < 320 ? 22 : -55;
          else sc -= Math.max(0, d - wd.range) * 0.35;
          if (!blade && q.mag <= 0) sc -= 18;
          return sc;
        };
        let bestIdx = s.cur, bestSc = val(sl) + 12;
        for (let i = 0; i < s.slots.length; i++) {
          const sc = val(s.slots[i]);
          if (sc > bestSc) { bestSc = sc; bestIdx = i; }
        }
        if (bestIdx !== s.cur) { this.equipSlot(s, bestIdx, false); b.swapCd = 2.0 + rand() * 1.4; }
      }
      if (!best) {
        let gx = this.map.w * AT * 0.5, gy = s.y, set = false, pd = 380;
        for (const p of this.picks) {
          if (p.spot && p.t > 0) continue;
          const want = p.kind === "health" ? s.hp < 55 : p.kind === "nades" ? s.nades < 2 : false;
          if (!want) continue;
          const d = Math.hypot(p.x - s.x, p.y - s.y) - (p.kind === "health" ? 150 : 0);
          if (d < pd) { pd = d; gx = p.x; gy = p.y; set = true; }
        }
        // badly hurt and nobody in sight: make for the nearest free hiding place, to patch up
        if (s.hp < 55 && s.hurtT > 0.6) {
          // (rather than a medkit, when the hiding place is the nearer of the two)
          let hd = Math.min(260, set ? pd + 150 : 260);
          for (const h of this.map.hides) {
            const d = Math.hypot(h.x - s.x, h.y - s.y);
            if (d < hd && !this.sol.some((o) => o !== s && o.alive && o.hide === h)) { hd = d; gx = h.x; gy = h.y; set = true; b.hideGo = true; }
          }
        }
        if (!set && ally) {
          // your side works as a squad. First: you are under fire - everybody goes for whoever is shooting at you
          // (a guard whose captain is down, or has stood still for a while, hunts like the others)
          const hunter = b.role === 1 || this.meIdle > 4 || !me.alive;
          const foe = me.alive && me.lastBy && me.lastBy.alive && me.lastBy.team !== s.team && this.t - me.lastByT < 3 ? me.lastBy : null;
          if (foe) { const k = this.intel.get(foe.id); gx = k ? k.x : foe.x; gy = k ? k.y : foe.y; set = true; if (rand() < 0.1) this.callout(s, "help"); }
          // then: an enemy somebody on the team has just seen - the hunters go for the nearest one, the guards only for one that is close to you
          if (!set) {
            let nd = hunter ? 560 : 220;
            for (const e of this.sol) {
              const k = e.alive && e.team !== s.team ? this.intel.get(e.id) : undefined;
              if (!k || this.t - k.t > 4) continue;
              const d = hunter ? Math.hypot(k.x - s.x, k.y - s.y) : Math.hypot(k.x - me.x, k.y - me.y);
              if (d < nd) { nd = d; gx = k.x; gy = k.y; set = true; }
            }
          }
          // nothing known: the guards stay with you, each at its place in the line - one ahead of you, towards the enemy, one behind
          if (!set && !hunter && !me.hide) { gx = clamp(me.x + b.slot * (me.team ? -1 : 1), 24, this.map.w * AT - 24); gy = me.y; set = true; b.escort = true; }
        }
        if (!set && b.seen && this.t - b.seen.t < 6) { gx = b.seen.x; gy = b.seen.y; set = true; if (Math.hypot(gx - s.x, gy - s.y) < 24) b.seen = null; }
        if (!set) {
          let ed = 1e9;
          for (const e of this.sol) if (e.alive && e.team !== s.team) { const d = Math.hypot(e.x - s.x, e.y - s.y); if (d < ed) { ed = d; gx = e.x; gy = e.y; } }
        }
        b.gx = gx; b.gy = gy;
        if (sl && !sab && sl.mag < AWEP[sl.id].mag * 0.5 && sl.ammo > 0) c.reload = true;
      }
    }
    const t = b.target && b.target.alive ? b.target : null;
    let want = s.aim;
    if (t) {
      const d = Math.hypot(t.x - s.x, t.y - s.y), lead = w.kind === "bullet" || w.kind === "laser" || w.kind === "shock" ? d / w.speed : w.kind === "bolt" ? d / 1080 : w.kind === "rocket" ? d / 580 : 0.1;
      const tx = t.x + t.vx * lead * (ally ? 1 : 0.8), ty = t.y - (t.crouch ? 5 : 9) + t.vy * lead * 0.4 + (w.kind === "rocket" ? 9 : 0);
      if (b.errT <= 0) { b.errT = 0.25 + rand() * 0.35; b.err = (rand() * 2 - 1) * P.err * (1 + Math.min(1, Math.hypot(t.vx, t.vy) / 150)); }
      want = Math.atan2(ty - (s.y - 5), tx - s.x) + (sab ? 0 : b.err * Math.max(0.3, 1 - b.lock * 0.5));
      b.lock += dt;
    } else if (b.seen && this.t - b.seen.t < 3) want = Math.atan2(b.seen.y - s.y, b.seen.x - s.x);
    else if (Math.abs(s.vx) > 20) want = s.vx > 0 ? 0.12 : Math.PI - 0.12;
    s.aim += clamp(angDiff(s.aim, want), -P.turn * dt, P.turn * dt);
    c.aim = s.aim;
    if (t) {
      const dx = t.x - s.x, d = Math.hypot(dx, t.y - s.y), off = Math.abs(angDiff(s.aim, want));
      if (sab) {
        // with Katana or Lightsaber: rush in and chain overhead + horizontal side-sweeps!
        if (d < SABER_R && b.react <= 0) {
          if (rand() < 0.35) c.melee = true; // trigger horizontal side-sweep!
          else c.fire = true;
        }
        if (d > 22) this.follow(s, t.x, t.y);
        else c.mx = Math.sign(dx);
        if (t.y < s.y - 24 && s.fuel > 0.2) c.jet = true;
      } else {
        if (b.react <= 0 && d < w.range * 1.1) {
          let ok = off < (w.pellets > 1 || w.kind === "flame" ? 0.28 : 0.12);
          if (w.id === "sniper" && b.lock < 0.45) ok = false;
          if (w.kind === "rocket" && d < 55) ok = false;
          if (ok) {
            if (w.auto) {
              if (b.burstT <= 0) { b.firing = !b.firing; b.burstT = b.firing ? 0.3 + rand() * 0.6 : (0.12 + rand() * 0.3) * (1.4 - P.dodge * 0.6); }
              c.fire = b.firing;
            } else c.fire = !s.trig && s.fireCd <= 0 && rand() < 0.7;
          }
        }
        if (d < 20) c.melee = true;
        if (s.nades > 0 && b.nadeCd <= 0 && d > 70 && d < 230 && rand() < dt * (t.holo ? 2.5 : 0.5)) { c.aim = s.aim = this.lob(s, t.x, t.y - 4); c.nade = true; b.nadeCd = 5 + rand() * 6; }
        const pref = w.kind === "flame" ? 45 : w.pellets > 1 ? 70 : w.id === "sniper" ? 260 : w.kind === "rocket" ? 170 : w.id === "uzi" ? 110 : 150;
        if (b.strafeT <= 0) { b.strafeT = 0.5 + rand() * 1.1; b.strafe = rand() < 0.5 ? -1 : 1; }
        if (d > pref + 60) { this.follow(s, t.x, t.y); if (d > pref + 120 && s.nos > 0.35 && (ally || P.dodge >= 1)) c.sprint = true; }
        else {
          // (too close - or, on your side, badly hurt: give ground while shooting)
          c.mx = d < pref - 40 || (ally && s.hp < 35 && d < 200) ? (dx >= 0 ? -1 : 1) : b.strafe * 0.8;
          if (c.mx && this.blockedAhead(s, Math.sign(c.mx))) c.mx = -c.mx;
        }
        if (b.hopT <= 0) { b.hopT = (1.7 - P.dodge * 0.9) * (0.5 + rand()); b.hop = rand() < 0.35 + P.dodge * 0.5 ? 0.15 + rand() * 0.35 : 0; }
        if (b.hop > 0) { b.hop -= dt; if (s.fuel > 0.25) c.jet = true; }
        if (t.y < s.y - 48 && s.fuel > 0.3) c.jet = true;
      }
    } else {
      this.follow(s, b.gx, b.gy);
      // in place beside you: stand watch. A long way to go: on NOS
      const gd = Math.hypot(b.gx - s.x, b.gy - s.y);
      if (b.escort && gd < 18 && s.ground) { c.mx = 0; c.jet = false; }
      else if (gd > 170 && s.nos > 0.3 && (ally || P.dodge >= 0.5)) c.sprint = true;
      if (b.hideGo && s.ground && Math.abs(b.gx - s.x) < 9 && Math.abs(b.gy - s.y) < 9) { c.pick = true; c.mx = 0; c.jet = false; b.hideGo = false; }
    }
    // a live grenade close by: your side (and a brutal enemy) gets clear of it - at a sprint, and off the ground if it is very near
    if (ally || P.dodge >= 1) for (const n of this.nades) {
      const dx = s.x - n.x, d = Math.hypot(dx, s.y - 9 - n.y);
      if (d > 64 || n.fuse > 1.4) continue;
      c.mx = dx >= 0 ? 1 : -1; c.sprint = true;
      if (s.fuel > 0.15 && (d < 40 || this.blockedAhead(s, c.mx))) c.jet = true;
      if (rand() < dt * 2) this.callout(s, "nade");
      break;
    }
    // the hologram shield: up while reloading in somebody's sights, or for a moment when hit with not much left - never on the easiest setting, never with a blade in hand
    b.guardT -= dt; b.guardCd -= dt;
    if (t && P.dodge > 0 && !sab && b.guardT <= 0 && b.guardCd <= 0 && s.holoCd <= 0 && s.holoHp > HOLO_HP * 0.35 && (s.reload > 0.3 || (s.hurtT < 0.2 && s.hp < 85))) {
      if (rand() < 0.3 + 0.5 * P.dodge) { b.guardT = s.reload > 0.3 ? s.reload : 0.6 + rand() * 0.8; b.guardCd = b.guardT + 1.5 + rand() * 2; }
      else b.guardCd = 1.2;
    }
    if (b.guardT > 0 && t && s.holoCd <= 0) { c.guard = true; c.fire = false; c.melee = false; c.nade = false; c.sprint = false; }
    if (!s.ground && s.vy > 230 && s.fuel > 0.08) c.jet = true;
    if ((b.stuckT -= dt) <= 0) {
      b.stuckT = 1.1;
      if (Math.abs(s.x - b.lx) + Math.abs(s.y - b.ly) < 6 && (c.mx !== 0 || c.jet)) { b.pathT = 0; b.unstuck = 0.5; b.strafe = -b.strafe; }
      b.lx = s.x; b.ly = s.y;
    }
    if (b.unstuck > 0) { c.mx = b.strafe; c.jet = s.fuel > 0.15; }
  }
  private follow(s: Sol, gx: number, gy: number) {
    const b = s.bot!, c = s.ctl;
    // a way through the portals, when it is much the shorter one: to the mouth of the portal, and in
    const via = this.t > b.portBan ? this.portalRoute(s, gx, gy) : null;
    if (via) {
      if (b.portSince < 0) b.portSince = this.t;
      else if (this.t - b.portSince > 6) { b.portBan = this.t + 10; b.portSince = -1; }
      gx = via.x + via.nx * 9; gy = via.nx ? via.y + 9 : via.y;
      if (Math.abs(s.x - gx) < 13 && Math.abs(s.y - gy) < 16) { c.mx = via.nx ? -via.nx : Math.sign(via.x - s.x); c.jet = false; return; }
    } else b.portSince = -1;
    if (b.pathT <= 0 || Math.abs(b.pgx - gx) + Math.abs(b.pgy - gy) > 64 || b.pi >= b.path.length) {
      b.path = findPath(this.map, s.x, s.y, gx, gy);
      b.pi = 0; b.pathT = 0.7 + rand() * 0.5; b.pgx = gx; b.pgy = gy;
    }
    while (b.pi < b.path.length && Math.abs(b.path[b.pi] - s.x) < 7 && Math.abs(b.path[b.pi + 1] - s.y) < 12) b.pi += 2;
    const wx = b.pi < b.path.length ? b.path[b.pi] : gx, wy = b.pi < b.path.length ? b.path[b.pi + 1] : gy;
    const dx = wx - s.x, dy = wy - s.y;
    c.mx = Math.abs(dx) > 4 ? Math.sign(dx) : 0;
    c.jet = dy < -6 || (c.mx !== 0 && this.blockedAhead(s, c.mx)) || (!s.ground && dy < 4 && s.vy > 60);
    if (dy > 10 && s.ground && this.onPlat(s)) c.drop = true;
    if (s.ground && dy < -30 && s.fuel < 0.3 && !b.target) { c.jet = false; c.mx = 0; }
    if (c.jet && s.fuel < 0.05) c.jet = false;
  }

  // ───────────── camera, sound ─────────────
  private focus(): Sol {
    if (this.me.alive || this.me.respawn > RESPAWN - 1.25) return this.me;
    if (this.killer && this.killer.alive) return this.killer;
    return this.me;
  }
  private camera(rdt: number) {
    const f = this.focus(), W = this.W, H = this.H, me = this.me;
    const sl = me.alive ? me.slots[me.cur] : null, blade = f === me && me.alive && !me.hide && !!sl && isBlade(AWEP[sl.id].kind);
    let lx = 0, ly = 0, zt = 1;
    if (f === me && me.alive) {
      const k = sl && sl.id === "sniper" ? 0.62 : blade ? 0.18 : 0.3;
      if (this.touch) { if (this.joyR.on) { lx = this.joyR.x * W * k * 0.8; ly = this.joyR.y * H * k * 0.8; } }
      else { lx = (this.mouse.x - W / 2) * k; ly = (this.mouse.y - H / 2) * k; }
    }
    if (blade) {
      // with a blade in hand the camera fights alongside you: it comes in close, frames you together with whoever is within reach - closer the nearer they are - and leans into every swing
      let duel: Sol | null = null, bd = 190;
      for (const e of this.sol) { if (!e.alive || e.team === me.team || e.hide) continue; const d = Math.hypot(e.x - me.x, e.y - me.y); if (d < bd) { bd = d; duel = e; } }
      zt = duel ? 1.12 + 0.12 * (1 - bd / 190) : 1.08;
      if (duel) { lx += (duel.x - me.x) * 0.4; ly += (duel.y - me.y) * 0.3; }
      if (me.swingT > 0) { zt += 0.03; lx += Math.cos(me.aim) * 12; ly += Math.sin(me.aim) * 7; }
    }
    if (f === me && me.alive && !me.ground && me.dive) { zt = 1.05; ly += 26; }
    if (f === me && me.launch > 0) zt = Math.max(zt, 1.06);
    if (this.trackT > 0) {
      this.trackT -= rdt;
      const q = this.track;
      if (q && f === me && me.alive) { zt = 1; lx = clamp((q.x - me.x) * 0.5, -(W / 2 - 70), W / 2 - 70); ly = clamp((q.y - me.y) * 0.5, -(H / 2 - 50), H / 2 - 50); }
      else this.trackT = 0;
    }
    // smooth flight lookahead: peeks upward while boosting on jetpack and looks down toward your landing zone while descending!
    const airVy = f.alive && !f.ground ? clamp(f.vy * 0.085, -22, 30) : 0;
    const a = 1 - Math.exp(-rdt * 9.2);
    this.camLead += ((f.alive ? clamp(f.vx * 0.22, -32, 32) : 0) - this.camLead) * (1 - Math.exp(-rdt * 3.6));
    this.cam.x += (f.x + lx + this.camLead - this.cam.x) * a;
    this.cam.y += (f.y - (this.environment ? 63 : 16) + ly + airVy - this.cam.y) * a;
    const mw = this.map.w * AT, mh = this.map.h * AT;
    this.cam.x = clamp(this.cam.x, W / 2, Math.max(W / 2, mw - W / 2));
    this.cam.y = clamp(this.cam.y, H / 2, Math.max(H / 2, mh - H / 2));
    this.cam.shake = Math.max(0, this.cam.shake - rdt * 18);
    this.cam.kx *= Math.exp(-rdt * 12);
    this.cam.ky *= Math.exp(-rdt * 12);
    // its zoom eases towards what the moment asks for, the punch of a blow dies away, and its roll swings back level on a spring
    this.zoom += (zt - this.zoom) * (1 - Math.exp(-rdt * (zt > this.zoom ? 6 : 3)));
    this.zoomKick *= Math.exp(-rdt * 4.5);
    this.zfT = Math.max(0, this.zfT - rdt);
    this.rollV += (-this.roll * 150 - this.rollV * 13) * rdt;
    this.roll = clamp(this.roll + this.rollV * rdt, -0.09, 0.09);
    const sh = this.cam.shake;
    this.cl = Math.round(this.cam.x - W / 2 + (rand() - 0.5) * sh + this.cam.kx);
    this.ct = Math.round(this.cam.y - H / 2 + (rand() - 0.5) * sh + this.cam.ky);
  }
  private sfx(n: SfxName, x: number, y: number, v = 1, pitch = 1) {
    const dx = x - this.cam.x, d = Math.hypot(dx, y - this.cam.y), vol = v * clamp(1.25 - d / 520, 0, 1);
    if (vol < 0.03) return;
    audio.play(n, vol, { pan: clamp(dx / (this.W * 0.6), -1, 1), far: clamp((d - 100) / 320, 0, 1), pitch });
  }
  private sound(rdt: number) {
    const me = this.me, T = this.map.theme;
    let jet = me.alive && me.jet ? (me.skin === ASTARTES ? 0.9 : 0.8) : 0, flame = 0, near = 0, hum = 0, rate = 0, saw = 0, srate = 0;
    for (const s of this.sol) {
      if (!s.alive) continue;
      const d = Math.hypot(s.x - this.cam.x, s.y - this.cam.y);
      if (s.saberOn > 0) { const v = s.saberOn * (s.me ? 0.6 : 0.45) * clamp(1.2 - d / 300, 0, 1); if (v > hum) { hum = v; rate = clamp(Math.abs(angDiff(s.bladePrev, s.blade)) * 6, 0, 1); } }
      if (s.chainRev > 0.05) {
        const rev = s.swingT > 0 ? 1 : 0.14;
        const v = (s.me ? (s.swingT > 0 ? 0.85 : 0.36) : 0.32) * clamp(1.2 - d / 320, 0, 1);
        if (v > saw) { saw = v; srate = rev; }
      }
      if (s === me) continue;
      if (s.jet && d < 280) jet = Math.max(jet, 0.42 * (1 - d / 280));
      if (s.team !== me.team && d < 320) near++;
    }
    for (const b of this.shots) if (b.kind === "flame" && Math.abs(b.x - this.cam.x) < 240 && Math.abs(b.y - this.cam.y) < 160) flame = Math.min(0.9, flame + 0.03);
    this.humRate += (rate - this.humRate) * Math.min(1, rdt * 12);
    this.sawRate += (srate - this.sawRate) * Math.min(1, rdt * 14);
    audio.loop("jet", this.paused ? 0 : Math.max(jet, me.alive && me.sprint ? 0.52 : 0), me.alive && me.sprint ? 1.05 : me.jet ? (me.skin === ASTARTES ? 0.25 : 0.4) + me.fuel * 0.55 : 0.3);
    audio.loop("flame", this.paused ? 0 : flame, 0.5);
    audio.loop("saber", this.paused ? 0 : Math.min(0.9, hum + this.humRate * 0.25), this.humRate * 0.5);
    audio.loop("chainsaw", this.paused ? 0 : Math.min(0.95, saw + this.sawRate * 0.22), this.sawRate);
    const want = this.phase === "live" ? clamp(0.18 + near * 0.16 + this.combat * 0.45, 0, 1) : 0.08;
    this.tension += (want - this.tension) * Math.min(1, rdt * 1.4);
    this.combat = Math.max(0, this.combat - rdt * 0.25);
    audio.music(this.paused ? 0 : this.tension);
    audio.city({ wind: T.amb.wind * (T.weather === "sand" ? 0.45 + this.gust * 0.8 : 1), birds: T.amb.birds, night: T.amb.night, drone: T.amb.drone, water: T.amb.water, rain: T.rain });
  }

  // ───────────── HUD ─────────────
  private hudState(): ArenaHud {
    const me = this.me, cfg = this.cfg!;
    let near = "";
    if (me.alive) {
      let bd = 1e9;
      for (const p of this.picks) {
        if ((p.spot && p.t > 0) || p.kind === "health" || p.kind === "nades") continue;
        const dx = Math.abs(p.x - me.x), dy = Math.abs(p.y - 4 - (me.y - 9));
        if (dx <= 12 && dy <= 16 && dx + dy < bd) { bd = dx + dy; near = PICK_NAME[p.kind]; }
      }
    }
    // the hiding place within reach, and a line of advice: over a trapdoor, crawling a rat-tunnel, ducked behind something
    const hs = me.alive && !me.hide && me.ground ? this.hideNear(me) : null;
    let tip = "";
    if (me.alive && !me.hide) {
      for (const q of this.map.hatches) if (Math.abs(q.x - me.x) < 11 && Math.abs(q.y - me.y) < 5) tip = "[S] TURUN KE JALAN TIKUS";
      for (const g of this.geysers) if (!tip && g.st < 2 && Math.abs(g.x - me.x) < 12 && Math.abs(g.y - me.y) < 8) tip = "GEYSER - TUNGGU SEMBURANNYA, KAMU TERLEMPAR KE ATAS!";
      if (!tip && this.map.theme.decor === "jungle") {
        for (const fl of this.falls) if (Math.abs(me.x - fl[0]) < 26 && me.y > fl[1] && me.y < fl[1] + fl[2] + 8) { tip = "AIR TERJUN BASTION — TERBANG MENEMBUSNYA UNTUK ISI JETPACK & NOS!"; break; }
      }
      if (!tip && me.skin === ASTARTES && !me.ground && me.airT > 0.35 && !me.dive) tip = "TAHAN [S] DI UDARA = METEOR SLAM ASTARTES!";
      if (!tip && me.dive && me.skin === ASTARTES) tip = "☄ METEOR SLAM — HANTAM MUSUH DI BAWAH!";
      if (!tip && me.crouch) tip = this.hit(me, me.x, me.y, false, HH) ? "JALAN TIKUS - MERAYAP" : "MERUNDUK - TARGET LEBIH KECIL";
    }
    return {
      phase: this.phase, time: Math.max(0, Math.ceil(this.timeLeft)), score: [this.score[0], this.score[1]], target: cfg.kills, myTeam: me.team,
      hp: Math.max(0, Math.ceil(me.hp)), fuel: me.fuel, nades: me.nades, alive: me.alive, respawn: Math.max(0, Math.ceil(me.respawn)), shield: me.alive && me.shield > 0,
      slots: me.slots.map((q) => (q ? { id: q.id, name: AWEP[q.id].name, mag: q.mag, ammo: q.ammo, max: AWEP[q.id].mag } : null)), cur: me.cur,
      reload: me.reload > 0 ? 1 - me.reload / me.reloadMax : -1,
      feed: this.feed.slice(), banner: this.banner, near, rows: this.rows(), killer: this.killer ? this.killer.name : "", streak: me.streak, music: audio.musicOn,
      hide: hs ? hs.name : "", hidden: me.alive && !!me.hide, tip, nos: me.nos, sprint: me.alive && me.sprint,
      holo: clamp(me.holoHp / me.maxHolo, 0, 1), holoUp: me.alive && me.holo, holoCd: Math.max(0, me.holoCd),
      armor: Math.max(0, Math.ceil(me.armor)), maxArmor: me.maxArmor, maxHp: me.maxHp, isTank: me.skin === ASTARTES, dive: me.alive && me.dive,
      zap: Math.max(0, me.zap), portal: me.carrier ? [this.portals[me.team][0] ? 1 : 0, this.portals[me.team][1] ? 1 : 0] : null, pnext: me.pnext,
    };
  }

  // ───────────── drawing ─────────────
  private glowCol(col: string) {
    if (!this.glowC[col]) {
      const [c, g] = mk(64, 64), grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      grd.addColorStop(0, col);
      grd.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grd;
      g.fillRect(0, 0, 64, 64);
      this.glowC[col] = c;
    }
    return this.glowC[col];
  }
  /**
   * The hologram shield: a curved wall of hard light held out in front, towards the aim - a honeycomb of hexagonal panels behind
   * a bright rim, thrown by a projector on the wrist, unfolding from the middle outwards as it is raised. The panels flare where
   * it is struck, in a ring that spreads along the wall; the less energy is left, the more of them have gone dark, and nearly
   * spent it stutters. Drawn twice: as tinted glass with the soldier (so that it shows against a bright sky), and again as light.
   */
  private drawHolo(s: Sol, lit: boolean) {
    const k = s.holoK, X = Math.round(s.x) - this.cl, Y = Math.round(this.holoY(s)) - this.ct;
    if (k < 0.04 || X < -40 || X > this.W + 40 || Y < -40 || Y > this.H + 40) return;
    const ctx = this.ctx, C = s.skin === ASTARTES ? { col: "#ffd24a", hot: "#fff9d6", dim: "#9e6814" } : HOLOC[s.team], t = this.t, e = clamp(s.holoHp / s.maxHolo, 0, 1), fx = s.holoFx;
    const half = HOLO_ARC * easeOut(k), weak = e < 0.3;
    // (against a bright sky the light must not wash out to white: there the tinted glass carries the colour)
    const day = this.map.theme.dark <= 0, add = day ? 0.45 : 1;
    const flick = (weak ? (Math.sin(t * 46 + s.id) > -0.3 ? 1 : 0.45) : 0.9 + 0.1 * Math.sin(t * 31 + s.id)) * Math.min(1, k * 1.5);
    const hex = (r: number, th: number, a: number) => {
      const px = Math.cos(th) * r, py = Math.sin(th) * r;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) { const q = th + (i * Math.PI) / 3, vx = px + Math.cos(q) * a, vy = py + Math.sin(q) * a; if (i) ctx.lineTo(vx, vy); else ctx.moveTo(vx, vy); }
      ctx.closePath();
    };
    ctx.save();
    ctx.translate(X, Y);
    // (standing on the ground, the wall ends at the ground: it does not sink into the floor)
    if (s.ground) { ctx.beginPath(); ctx.rect(-40, -60, 80, 71 - s.duck * 4); ctx.clip(); }
    ctx.rotate(s.aim);
    ctx.lineJoin = "round"; ctx.lineCap = "round";
    if (!lit) {
      // the cone of projection, from the wrist to the wall
      ctx.globalAlpha = 0.08 * flick; ctx.fillStyle = C.col;
      ctx.beginPath(); ctx.moveTo(4, 0); ctx.arc(0, 0, HOLO_R - 2, -half, half); ctx.closePath(); ctx.fill();
    }
    // the honeycomb: a row of panels along the wall, and a second, shorter row behind it
    for (let row = 0; row < 2; row++) {
      const r = row ? HOLO_R - 4 : HOLO_R + 0.4, a = row ? 2.1 : 2.9, n = row ? 2 : 3, D = 0.335;
      for (let j = -n; j <= (row ? n - 1 : n); j++) {
        const th = (j + row * 0.5) * D;
        if (Math.abs(th) > half + 0.06) continue;
        const h = Math.abs(Math.sin(j * 7.13 + row * 3.7 + s.id * 1.93) * 43758.5453) % 1;
        // a panel that has gone dark (the less energy, the more of them) - it stutters back now and then
        const gone = h > e * 1.2 + 0.04;
        if (gone && Math.sin(t * 21 + h * 40) < 0.8) continue;
        // struck: a ring of white spreading along the wall from where the blow landed; and a slow shimmer that wanders up and down it
        const ring = fx > 0.05 && Math.abs(Math.abs(th - s.holoAt) - (1 - fx) * 1.2) < 0.22, sweep = Math.abs(th - Math.sin(t * 2.3 + s.id) * HOLO_ARC) < 0.18;
        hex(r, th, a);
        if (lit) {
          ctx.globalAlpha = (ring ? 0.95 : sweep ? 0.55 : 0.2 + fx * 0.35) * flick * (row ? 0.7 : 1) * add;
          ctx.strokeStyle = ring ? "#ffffff" : sweep ? C.hot : C.col; ctx.lineWidth = 0.9; ctx.stroke();
          if (ring) { ctx.globalAlpha = 0.35 * flick * add; ctx.fillStyle = C.hot; ctx.fill(); }
        } else {
          ctx.globalAlpha = ((day ? 0.5 : 0.3) + fx * 0.3) * flick * (row ? 0.7 : 1); ctx.fillStyle = gone ? "#0a0a0f" : C.dim; ctx.fill();
          ctx.globalAlpha = 0.9 * flick * (row ? 0.75 : 1); ctx.strokeStyle = ring ? "#ffffff" : C.col; ctx.lineWidth = 0.9; ctx.stroke();
        }
      }
    }
    // the rim: a bright line along the outer edge of the wall (blinking a warning when it is nearly spent), a node of light at either end - and the projector on the wrist
    const rim = HOLO_R + 3.4, warn = weak && Math.sin(t * 18 + s.id) > 0;
    ctx.globalAlpha = (lit ? 0.7 * add : 0.95) * Math.max(flick, weak ? 0.8 : 0);
    ctx.strokeStyle = fx > 0.55 ? "#ffffff" : warn ? (s.team ? "#ffe9a0" : "#ffb070") : lit ? C.hot : C.col; ctx.lineWidth = lit ? 1.5 : 1;
    ctx.beginPath(); ctx.arc(0, 0, rim, -half, half); ctx.stroke();
    ctx.fillStyle = lit ? "#ffffff" : C.hot;
    for (const sg of [-1, 1]) ctx.fillRect(Math.cos(half * sg) * rim - 1, Math.sin(half * sg) * rim - 1, 2, 2);
    ctx.fillRect(3, -1, 2, 2);
    if (lit) { ctx.globalAlpha = (0.2 + fx * 0.45) * flick * add; ctx.drawImage(this.glowCol(C.col), HOLO_R - 16, -20, 30, 40); }
    ctx.restore();
  }
  private R(c: string, x: number, y: number, w: number, h: number) { this.ctx.fillStyle = c; this.ctx.fillRect(x, y, w, h); }
  private tintC: Record<string, HTMLCanvasElement> = {};
  /** a silhouette in one colour: the after-images left behind by a sprint on NOS, a dash, a spin */
  private tint(img: HTMLCanvasElement, col: string, key: string): HTMLCanvasElement {
    const k = key + col;
    if (!this.tintC[k]) {
      const [c, g] = mk(img.width, img.height);
      g.drawImage(img, 0, 0);
      g.globalCompositeOperation = "source-in";
      g.fillStyle = col;
      g.fillRect(0, 0, c.width, c.height);
      this.tintC[k] = c;
    }
    return this.tintC[k];
  }

  private render() {
    const ctx = this.ctx, W = this.W, H = this.H, cl = this.cl, ct = this.ct, T = this.map.theme;
    this.sky();
    this.waterfall();
    ctx.drawImage(this.terr, cl, ct, W, H, 0, 0, W, H);
    this.environment?.drawRivers(ctx, this.terr, cl, ct, W, H, this.t);
    this.dynDecor();
    this.drawGeysers(false);
    // pickups
    for (const p of this.picks) {
      const x = Math.round(p.x) - cl, y = Math.round(p.y) - ct;
      if (x < -20 || x > W + 20 || y < -20 || y > H + 20) continue;
      if (p.spot && p.t > 0) { this.R("rgba(255,255,255,0.18)", x - 5, y - 1, 10, 1); continue; }
      const bob = p.spot ? Math.round(Math.sin(p.bob * 3) * 1.5) : 0;
      if (p.spot) {
        const special = p.kind === "saber" || p.kind === "katana";
        ctx.globalAlpha = special ? 0.55 + 0.25 * Math.sin(this.t * 4) : 0.35;
        ctx.drawImage(this.glowCol(special ? "#9ae8ff" : p.kind === "health" ? "#ff5a6a" : p.kind === "nades" ? "#7dff9a" : "#ffe14a"), x - (special ? 18 : 12), y - (special ? 24 : 18), special ? 36 : 24, special ? 36 : 24);
        ctx.globalAlpha = 1;
      }
      if (!p.spot && p.life < 3 && Math.sin(this.t * 20) > 0) continue;
      this.R("rgba(0,0,0,0.3)", x - 5, y - 1, 10, 2);
      if (p.kind === "health") ctx.drawImage(medSpr(), x - 5, y - 10 + bob);
      else if (p.kind === "nades") { const n = nadeSpr(); ctx.drawImage(n, x - 6, y - 7 + bob); ctx.drawImage(n, x + 1, y - 7 + bob); }
      else { const s = wspr(0, p.kind as AW); ctx.drawImage(s.c, x - (s.c.width >> 1), y - s.c.height - 2 + bob); }
    }
    const ns = nadeSpr();
    for (const n of this.nades) {
      const x = Math.round(n.x) - cl, y = Math.round(n.y) - ct;
      ctx.save(); ctx.translate(x, y - 3); ctx.rotate(n.rot); ctx.drawImage(ns, -2, -3); ctx.restore();
      if (n.fuse < 0.6 && Math.sin(this.t * 40) > 0) this.R("#ff4d5e", x - 1, y - 7, 2, 2);
    }
    if (this.tumbles.length) {
      const ts = tumbleSpr();
      for (const q of this.tumbles) { ctx.save(); ctx.translate(Math.round(q.x - cl), Math.round(q.y - ct)); ctx.rotate(q.rot); ctx.scale(q.s, q.s); ctx.drawImage(ts, -7, -7); ctx.restore(); }
    }
    // articulated Verlet ragdolls first, then dash afterimages, then live soldiers (you last)
    this.drawPortals(false);
    for (const c of this.corpses) this.drawRagdoll(c);
    for (const g of this.ghosts) {
      const gx = Math.round(g.x) - cl, gy = Math.round(g.y) - ct, k = 1 - g.life / g.max, tk = g.skin === ASTARTES;
      ctx.save();
      ctx.globalAlpha = k * 0.52;
      ctx.translate(gx, gy);
      ctx.scale(g.face * (tk ? 1.1 : 1), tk ? 1.1 : 1);
      ctx.drawImage(this.tint(opTorso(g.team, g.skin, true), g.col, "t" + g.skin), tk ? -7 : -5, tk ? -11 : -9);
      ctx.drawImage(this.tint(opHead(g.team, g.skin, true), g.col, "h" + g.skin), tk ? -8 : -7, tk ? -21 : -19);
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    for (const s of this.sol) if (s.alive && !s.me) this.drawSol(s);
    if (this.me.alive) this.drawSol(this.me);
    this.drawRocks();
    this.environment?.drawRivers(ctx, this.terr, cl, ct, W, H, this.t, true);
    // the cover of the hiding places stands in front of whoever is tucked in behind it (it shivers when somebody slips in, or a bullet strikes it)
    this.hint = this.me.alive && !this.me.hide && this.me.ground && this.phase === "live" ? this.hideNear(this.me) : null;
    this.map.hides.forEach((q, i) => {
      const x = Math.round(q.x) - cl, y = Math.round(q.y) - ct;
      if (x < -30 || x > W + 30 || y < -8 || y > H + 40) return;
      const sp = hideSprite(q.k, T), sh = this.hideShake[i] > 0 ? Math.round(Math.sin(this.t * 60) * this.hideShake[i] * 5) : 0;
      ctx.drawImage(sp.c, x - sp.ox + sh, y - sp.oy);
    });
    // rockets, saws, flames
    for (const b of this.shots) {
      const x = b.x - cl, y = b.y - ct;
      if (x < -30 || x > W + 30 || y < -30 || y > H + 30) continue;
      if (b.kind === "bolt") {
        // .75 cal Astartes mass-reactive gyrojet bolt: golden-brass casing, diamond-tipped crimson warhead & blazing micro-rocket tail!
        ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(Math.atan2(b.vy, b.vx));
        this.R(Math.sin(this.t * 95 + b.x) > 0 ? "#ffffff" : "#ffe46a", -9, -1, 5, 2);
        this.R("#ff7a1e", -11, 0, 3, 1);
        this.R("#0a0a0f", -4, -2, 9, 5);
        this.R("#f5c542", -3, -1, 5, 3);
        this.R("#fff6c2", -3, -1, 4, 1);
        this.R("#e03238", 2, -1, 2, 3);
        this.R("#ffffff", 3, -1, 1, 1);
        ctx.restore();
      } else if (b.kind === "rocket") {
        ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(Math.atan2(b.vy, b.vx));
        this.R(Math.sin(this.t * 80) > 0 ? "#ffffff" : "#ffe45c", -13, -1, 7, 3);
        this.R("#ff7a2a", -15, 0, 4, 1);
        this.R("#0a0a0f", -6, -3, 12, 7); this.R("#d9dee8", -5, -2, 7, 5); this.R("#9aa3b5", -5, 1, 7, 2);
        this.R(TEAMS[b.by.team].color, -2, -2, 2, 5); this.R("#e0483e", 2, -2, 3, 5); this.R("#ff8a80", 2, -2, 2, 1);
        ctx.restore();
      } else if (b.kind === "saw") {
        ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(b.spin);
        this.R("#0a0a0f", -4, -4, 8, 8); this.R("#c9d6e0", -3, -3, 6, 6); this.R("#ffe45c", -4, -1, 1, 2); this.R("#ffe45c", 3, -1, 1, 2); this.R("#ffe45c", -1, -4, 2, 1); this.R("#ffe45c", -1, 3, 2, 1); this.R("#ff5a2a", -1, -1, 2, 2);
        ctx.restore();
      } else if (b.kind === "flame") {
        const k = b.life / 0.45, sz = Math.ceil(b.r);
        ctx.globalAlpha = clamp(k, 0, 0.92);
        ctx.fillStyle = k > 0.72 ? "#ffffff" : k > 0.5 ? "#fff3a0" : k > 0.28 ? "#ff9e2a" : "#e84420";
        ctx.fillRect(Math.round(x - sz / 2), Math.round(y - sz / 2), sz, sz);
        if (sz > 4 && k > 0.35) { ctx.fillStyle = "#fff8dc"; ctx.fillRect(Math.round(x - 1), Math.round(y - 1), 2, 2); }
        ctx.globalAlpha = 1;
      }
    }
    // particles (the glowing ones come later, over the dark)
    for (const p of this.parts) {
      if (p.kind === 5 || p.kind === 9) continue;
      const x = p.x - cl, y = p.y - ct;
      if (x < -10 || x > W + 10 || y < -10 || y > H + 10) continue;
      const k = p.life / p.max;
      if (p.kind === 7 && p.spr) { ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(p.rot); ctx.drawImage(p.spr, -7, -5); ctx.restore(); continue; }
      if (p.kind === 1) { ctx.globalAlpha = k * 0.6; const s = Math.round(p.size + (1 - k) * 5); this.R(p.col, Math.round(x - s / 2), Math.round(y - s / 2), s, s); ctx.globalAlpha = 1; continue; }
      if (p.kind === 2) { ctx.strokeStyle = p.col; ctx.globalAlpha = k; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - p.vx * 0.02, y - p.vy * 0.02); ctx.stroke(); ctx.globalAlpha = 1; continue; }
      if (p.kind === 3) {
        // a case tumbling through the air: it glints as it turns
        const fl = ((p.life * 22) | 0) & 1, px = Math.round(x), py = Math.round(y);
        if (p.life < 0.6) ctx.globalAlpha = p.life / 0.6;
        this.R(p.col, px - 1, py, p.n > 1 ? 2 : fl ? 3 : 1, p.n > 1 ? 1 : fl ? 1 : 3);
        if (fl && p.n < 2) this.R("#ffffff", px, py, 1, 1);
        ctx.globalAlpha = 1;
        continue;
      }
      if (p.kind === 8) { this.R(p.col, Math.round(x), Math.round(y) - 1, 1, 2); continue; }
      this.R(p.col, Math.round(x), Math.round(y), p.size, p.size);
    }
    this.drawBursts();
    this.lights();
    this.drawBats();
    if (this.emis) {
      // what glows by itself shines through the dark
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = this.map.theme.decor === "cave" ? 0.54 + Math.sin(this.t * 1.4) * 0.08 : this.environment ? 0.28 : 0.72 + 0.28 * Math.sin(this.t * 1.7);
      // (but not through whoever stands in front of it: the soldiers are cut out of the glow first)
      const eg = this.ebg;
      eg.globalCompositeOperation = "copy";
      eg.drawImage(this.emis, cl, ct, W, H, 0, 0, W, H);
      eg.globalCompositeOperation = "destination-out";
      for (const s of this.sol) {
        if (!s.alive || s.hide) continue;
        const x = s.x - cl, y = s.y - ct;
        if (x > -20 && x < W + 20 && y > -10 && y < H + 40) eg.drawImage(this.glow, x - 9, y - 24 + s.duck * 6, 18, 28);
      }
      eg.globalCompositeOperation = "source-over";
      ctx.drawImage(this.eb, 0, 0);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
    this.glowPass();
    this.weather();
    this.environment?.drawAtmosphere(ctx, cl, ct, W, H, this.t);
    if (T.fog) { const fg = ctx.createLinearGradient(0, H * 0.4, 0, H); fg.addColorStop(0, "rgba(120,100,130,0)"); fg.addColorStop(1, `rgba(120,100,130,${T.fog})`); ctx.fillStyle = fg; ctx.fillRect(0, 0, W, H); }
    // names, health, speech, what is over their heads
    for (const s of this.sol) {
      if (!s.alive) continue;
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct;
      if (x < -30 || x > W + 30 || y < -50 || y > H + 10) continue;
      if (s.hide && s.team !== this.me.team) continue; // (whoever hides from you has no name tag to give them away)
      const tkTop = s.skin === ASTARTES ? 3 : 0;
      if (s.me) { const b = Math.round(Math.sin(this.t * 5) * 1); this.R("#0a0a0f", x - 2, y - 29 - tkTop + b, 5, 3); this.R(s.skin === ASTARTES ? "#ffe26a" : "#ffffff", x - 1, y - 29 - tkTop + b, 3, 2); }
      else {
        const isTk = s.skin === ASTARTES, bars = isTk || s.hp < s.maxHp || s.armor < s.maxArmor;
        drawText(ctx, s.name, x, y - tkTop - (bars ? 35 : 31), isTk ? "#ffe26a" : TEAMS[s.team].color);
        if (s.carrier) { const rx = x - s.name.length * 2 - 7, ry = y - tkTop - (bars ? 35 : 31); this.R(PORTC[s.team][0], rx, ry + 1, 1, 3); this.R(PORTC[s.team][0], rx + 1, ry, 2, 1); this.R(PORTC[s.team][1], rx + 3, ry + 1, 1, 3); this.R(PORTC[s.team][1], rx + 1, ry + 4, 2, 1); }
        if (bars) {
          const bw = isTk ? 18 : 12;
          this.R("#0a0a0f", x - (bw >> 1) - 1, y - tkTop - (isTk ? 28 : 27), bw + 2, isTk ? 6 : 5);
          if (s.armor > 0) this.R(s.armorFx > 0.4 ? "#ffffff" : isTk ? "#ffe26a" : "#b9d6ff", x - (bw >> 1), y - tkTop - (isTk ? 27 : 26), Math.max(1, Math.round((s.armor / s.maxArmor) * bw)), isTk ? 2 : 1);
          this.R(s.team === this.me.team ? "#7dff9a" : "#ff4d5e", x - (bw >> 1), y - tkTop - 24, Math.max(1, Math.round((s.hp / s.maxHp) * bw)), 1);
        }
      }
      this.emotes(s, x, y);
      if (s.sayT > 0 && s.say) {
        const by = y - (s.me ? 40 : 48), w = s.say.length * 4 + 5, bx = clamp(x - (w >> 1), 1, W - w - 1);
        this.R("#0a0a0f", bx - 1, by - 1, w + 2, 9); this.R("#ffffff", bx, by, w, 7); this.R("#0a0a0f", x - 1, by + 7, 3, 2); this.R("#ffffff", x, by + 7, 1, 1);
        drawText(ctx, s.say, bx + w / 2, by + 1, "#1b1b26", "#ffffff");
      }
    }
    if (this.hint) {
      // the key to press, bobbing over the hiding place within reach
      const q = this.hint, x = Math.round(q.x) - cl, y = Math.round(q.y) - ct - q.h - 16 + Math.round(Math.sin(this.t * 5) * 1.5);
      this.R("#0a0a0f", x - 4, y - 1, 9, 9); this.R("#7dff9a", x - 3, y, 7, 7); this.R("#0a0a0f", x - 2, y + 1, 5, 5);
      drawText(ctx, "E", x + 1, y + 1, "#7dff9a");
      drawText(ctx, "SEMBUNYI", x + 1, y - 8, "#7dff9a");
    }
    for (const q of this.texts) {
      ctx.globalAlpha = Math.min(1, q.life * 2.5);
      if (q.big) this.bigText(q.text, Math.round(q.x - cl), Math.round(q.y - ct), q.col, q.big); else drawText(ctx, q.text, Math.round(q.x - cl), Math.round(q.y - ct), q.col);
      ctx.globalAlpha = 1;
    }
    // laser sights
    for (const s of this.sol) {
      const sl = s.slots[s.cur];
      if (!s.alive || !sl || sl.id !== "sniper" || s.reload > 0) continue;
      const m = this.muzzle(s), ca = Math.cos(s.aim), sa = Math.sin(s.aim);
      let ex = m.x, ey = m.y;
      for (let d = 0; d < 520; d += 4) {
        ex = m.x + ca * d; ey = m.y + sa * d;
        if (solidPx(this.map, ex, ey)) break;
        let hitS = false;
        for (const e of this.sol) if (e !== s && e.alive && Math.abs(ex - e.x) < 5 && ey > e.y - 19 && ey < e.y) { hitS = true; break; }
        if (hitS) break;
      }
      ctx.strokeStyle = s.team === this.me.team ? "rgba(255,80,96,0.45)" : "rgba(255,40,60,0.6)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(m.x - cl, m.y - ct); ctx.lineTo(ex - cl, ey - ct); ctx.stroke();
      this.R("#ff3a4a", Math.round(ex - cl) - 1, Math.round(ey - ct) - 1, 2, 2);
    }
    // critical hits; then the camera's zoom and roll: everything of the world is in the picture now - what follows is drawn on the glass
    this.drawCrits();
    this.applyView();
    if (this.rush > 0.02) {
      // speed lines: streaks along the way of the blow, out towards the edges of the picture
      const ca = Math.cos(this.rushA), sa = Math.sin(this.rushA), fr = Math.floor(this.t * 40);
      ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 1;
      for (let i = 0; i < 14; i++) {
        const q = (n: number) => Math.abs(Math.sin(i * 12.9898 + fr * 78.233 + n * 37.719) * 43758.5453) % 1;
        const o = (i % 2 ? 1 : -1) * (0.2 + 0.34 * q(1)) * H, al = (q(2) - 0.5) * W, len = 24 + q(3) * 60, x0 = W / 2 + ca * al - sa * o, y0 = H / 2 + sa * al + ca * o;
        ctx.globalAlpha = 0.34 * this.rush;
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + ca * len, y0 + sa * len); ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    this.drawMini();
    const me = this.me;
    if (me.alive && this.phase !== "end") {
      let cx = this.mouse.x, cy = this.mouse.y;
      if (this.touch) { const p = this.toScreen(me.x + Math.cos(me.aim) * 46, me.y - 5 + Math.sin(me.aim) * 46); cx = p[0]; cy = p[1]; }
      const cw = this.toWorld(cx, cy);
      const sl = me.slots[me.cur], w = AWEP[sl ? sl.id : "pistol"], gap = Math.round(3 + me.bloom * 3 + w.spread * 30 + me.recoil * 2);
      let over = false;
      for (const e of this.sol) if (e.alive && !e.hide && e.team !== me.team && Math.abs(cw[0] - e.x) < 7 && cw[1] > e.y - 21 && cw[1] < e.y + 2) over = true;
      const col = over ? "#ff4d5e" : "#ffffff";
      for (const [dx, dy, w2, h2] of [[-gap - 3, 0, 3, 1], [gap + 1, 0, 3, 1], [0, -gap - 3, 1, 3], [0, gap + 1, 1, 3]]) { this.R("#0a0a0f", Math.round(cx + dx) - 1, Math.round(cy + dy) - 1, w2 + 2, h2 + 2); this.R(col, Math.round(cx + dx), Math.round(cy + dy), w2, h2); }
      this.R(col, Math.round(cx), Math.round(cy), 1, 1);
      if (this.hitMark > 0) {
        const c2 = this.killMark > 0 ? "#ff4d5e" : "#ffffff";
        for (let i = 2; i < 5; i++) { this.R(c2, Math.round(cx) - i, Math.round(cy) - i, 1, 1); this.R(c2, Math.round(cx) + i, Math.round(cy) - i, 1, 1); this.R(c2, Math.round(cx) - i, Math.round(cy) + i, 1, 1); this.R(c2, Math.round(cx) + i, Math.round(cy) + i, 1, 1); }
      }
    }
    if (this.plateFx > 0.01) {
      // (your armour took it: a pale flash round the edge of the picture, not the red one)
      ctx.strokeStyle = `rgba(200,224,255,${(this.plateFx * 0.38).toFixed(3)})`;
      for (let i = 0; i < 3; i++) { ctx.lineWidth = 8 - i * 2; ctx.strokeRect(5 + i * 3, 5 + i * 3, W - 10 - i * 6, H - 10 - i * 6); }
    }
    const low = me.alive && me.hp < 30 ? 0.18 + Math.sin(this.t * 6) * 0.08 : 0;
    const red = Math.max(this.hurtFx * 0.45, low);
    if (red > 0.01) {
      ctx.strokeStyle = `rgba(210,20,40,${red.toFixed(3)})`;
      for (let i = 0; i < 4; i++) { ctx.lineWidth = 10 - i * 2; ctx.strokeRect(5 + i * 3, 5 + i * 3, W - 10 - i * 6, H - 10 - i * 6); }
    }
    if (!me.alive && this.phase !== "end") { ctx.fillStyle = "rgba(20,0,8,0.22)"; ctx.fillRect(0, 0, W, H); }
    if (me.alive && me.hide) {
      // in hiding: the world closes in around the edges of the picture
      const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.8);
      vg.addColorStop(0, "rgba(4,12,10,0)");
      vg.addColorStop(1, "rgba(4,12,10,0.6)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);
    }
  }

  /** the sky, the sun through the haze, and the parallax layers of whatever lies behind the arena */
  private sky() {
    const ctx = this.ctx, W = this.W, H = this.H, cl = this.cl, ct = this.ct, T = this.map.theme, B = this.back;
    if (this.environment) { this.environment.drawBackground(ctx, cl, ct, W, H, this.t); return; }
    const grd = ctx.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, T.sky[0]); grd.addColorStop(0.55, T.sky[1]); grd.addColorStop(1, T.sky[2]);
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, W, H);
    if (T.sun) {
      const sx = W * 0.74 - cl * 0.02, sy = 38 - ct * 0.03;
      ctx.globalAlpha = 0.35; ctx.drawImage(this.glowCol("#fff0c8"), sx - 90, sy - 90, 180, 180);
      ctx.globalAlpha = 0.6; ctx.drawImage(this.glowCol("#fff6dc"), sx - 34, sy - 34, 68, 68); ctx.globalAlpha = 1;
      ctx.fillStyle = "#fff8e4"; ctx.beginPath(); ctx.arc(sx, sy, 12, 0, PI2); ctx.fill();
    }
    if (B.tile) {
      for (const [img, p] of [[B.far, 0.16], [B.mid, 0.34], [B.near, 0.54]] as [HTMLCanvasElement | null, number][]) {
        if (!img) continue;
        const iw = img.width, ih = img.height, ox = ((-cl * p) % iw + iw) % iw, oy = ((-ct * p) % ih + ih) % ih;
        for (let y = oy - ih; y < H; y += ih) for (let x = ox - iw; x < W; x += iw) ctx.drawImage(img, Math.round(x), Math.round(y));
      }
      return;
    }
    const horizon = (T.decor === "jungle" ? 72 : T.decor === "city" ? 64 : 60) * AT;
    const strip = (img: HTMLCanvasElement | null, p: number, baseCol: string) => {
      if (!img) return;
      const yb = Math.round(H * 0.84 + (horizon - ct - H * 0.84) * p), off = (((-cl * p) % 960) + 960) % 960;
      for (let x = off - 960; x < W; x += 960) ctx.drawImage(img, Math.round(x), yb - img.height);
      if (yb < H) { ctx.fillStyle = baseCol; ctx.fillRect(0, yb, W, H - yb); }
    };
    B.clouds.forEach((c, i) => {
      const sp = T.weather === "sand" ? 14 + i * 5 + this.gust * 20 : 4.5 + i * 1.8;
      const x = ((((i * 250 + this.t * sp - cl * 0.08) % (W + 180)) + W + 180) % (W + 180)) - 140;
      ctx.drawImage(c, Math.round(x), Math.round(12 + i * 14 - ct * 0.04));
    });
    strip(B.far, 0.15, T.far);
    if (T.decor === "jungle") {
      // dreamy sunlit golden-aqua Anthem valley mist drifting between the distant tepuis and mid-canopy!
      const vm = ctx.createLinearGradient(0, H * 0.38, 0, H);
      vm.addColorStop(0, "rgba(255,248,205,0)");
      vm.addColorStop(1, "rgba(210,252,226,0.22)");
      ctx.fillStyle = vm; ctx.fillRect(0, 0, W, H);
    }
    strip(B.mid, 0.3, T.mid);
    strip(B.near, 0.48, T.near);
    if (T.weather === "sand") {
      // the storm thickens towards the horizon
      const hz = ctx.createLinearGradient(0, H * 0.35, 0, H);
      hz.addColorStop(0, "rgba(232,176,112,0)");
      hz.addColorStop(1, `rgba(232,176,112,${(0.18 + this.gust * 0.22).toFixed(3)})`);
      ctx.fillStyle = hz;
      ctx.fillRect(0, 0, W, H);
    }
  }

  /** the luminous cathedral waterfall & volumetric crystal light shafts behind the terrain */
  private waterfall() {
    const ctx = this.ctx, W = this.W, H = this.H, t = this.t;
    // diagonal volumetric crystal light beams slanting down from cracks in the cavern roof
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const d of this.map.dyn) {
      if (d.k !== "beamlight") continue;
      const x = d.x - this.cl, y0 = d.y - this.ct, h = d.h || 160;
      if (x < -110 || x > W + 110 || y0 + h < -20 || y0 > H + 20) continue;
      // warm golden morning canopy god-rays in Hutan Bastion; sapphire/amethyst/gold crystal rays in Goa Kristal!
      const jng = this.map.theme.decor === "jungle";
      const hue = jng ? 2 : d.v < 0.45 ? 0 : d.v < 0.78 ? 1 : 2;
      const cTop = jng ? "255,248,185" : hue === 0 ? "150,255,244" : hue === 1 ? "222,168,255" : "255,232,155";
      const cMid = jng ? "215,255,175" : hue === 0 ? "115,205,255" : hue === 1 ? "170,130,255" : "255,198,110";
      const pulse = (jng ? 0.055 : 0.072) + 0.028 * Math.sin(t * 1.35 + d.v * 9);
      const gr = ctx.createLinearGradient(x, y0, x + 38, y0 + h);
      gr.addColorStop(0, `rgba(${cTop},${(pulse * 1.85).toFixed(3)})`);
      gr.addColorStop(0.58, `rgba(${cMid},${pulse.toFixed(3)})`);
      gr.addColorStop(1, `rgba(${cMid},0)`);
      ctx.fillStyle = gr;
      ctx.beginPath();
      ctx.moveTo(x - 13, y0);
      ctx.lineTo(x + 13, y0);
      ctx.lineTo(x + 56, y0 + h);
      ctx.lineTo(x + 2, y0 + h);
      ctx.closePath();
      ctx.fill();
      const gr2 = ctx.createLinearGradient(x, y0, x + 28, y0 + h);
      gr2.addColorStop(0, `rgba(245,255,252,${(pulse * 1.55).toFixed(3)})`);
      gr2.addColorStop(0.6, `rgba(${cTop},${(pulse * 0.72).toFixed(3)})`);
      gr2.addColorStop(1, `rgba(${cTop},0)`);
      ctx.fillStyle = gr2;
      ctx.beginPath();
      ctx.moveTo(x - 4, y0);
      ctx.lineTo(x + 5, y0);
      ctx.lineTo(x + 36, y0 + h);
      ctx.lineTo(x + 18, y0 + h);
      ctx.closePath();
      ctx.fill();
      // shimmering dust motes floating inside the cathedral light beam
      for (let i = 0; i < 4; i++) {
        const mk3 = ((t * 0.14 + i * 0.27 + d.v) % 1), my = y0 + mk3 * h * 0.85, mx2 = x + mk3 * 28 + Math.sin(t * 1.5 + i * 2) * 5;
        ctx.fillStyle = "#ffffff";
        ctx.globalAlpha = Math.sin(mk3 * Math.PI) * 0.55;
        ctx.fillRect(Math.round(mx2), Math.round(my), 1, 1);
      }
      ctx.globalAlpha = 1;
    }
    ctx.restore();
    // grand central waterfall + twin flanking cathedral veil cascades + luminous splash mist
    for (const d of this.map.dyn) {
      if (d.k !== "fall") continue;
      if (this.environment) { this.environment.drawWaterfall(ctx, d, this.cl, this.ct, W, H, t); continue; }
      const veil = d.v > 0.4, hw = veil ? 5 : 9;
      const x = d.x - this.cl, y0 = d.y - this.ct, y1 = y0 + d.h;
      if (x < -36 || x > W + 36 || y1 < 0 || y0 > H) continue;
      const top = Math.max(0, Math.floor(y0)), bot = Math.min(H, Math.ceil(y1));
      for (let i = -hw; i < hw; i++) {
        const edge = Math.abs(i + 0.5) / hw;
        for (let yy = top; yy < bot; yy += 2) {
          const ph = (((yy - y0 + t * (veil ? 148 : 176) + i * 13 + i * i * 7) % 24) + 24) % 24;
          ctx.fillStyle = ph < 3 ? "#ffffff" : ph < 9 ? "#c4fbff" : ph < 16 ? "#5fe8f4" : "#3484d0";
          ctx.globalAlpha = (veil ? 0.68 : 0.88) - edge * (veil ? 0.42 : 0.5);
          ctx.fillRect(Math.round(x + i), yy, 1, 2);
        }
      }
      ctx.globalAlpha = 1;
      for (let i = 0; i < (veil ? 7 : 12); i++) {
        const k = (t * 2.2 + i * 0.37) % 1;
        this.R("#ffffff", Math.round(x - hw + ((i * 5) % (hw * 2 + 1))), Math.round(y0 + k * 5), 1, 1);
        const mk2 = (t * 1.9 + i * 0.29) % 1;
        ctx.globalAlpha = (1 - mk2) * 0.72;
        this.R("#e4ffff", Math.round(x + Math.sin(i * 2.4 + t * 4) * (4 + mk2 * (hw + 7))), Math.round(y1 - 2 - mk2 * 14), mk2 < 0.45 ? 2 : 1, 1);
      }
      ctx.globalAlpha = veil ? 0.28 : 0.42;
      ctx.drawImage(this.glowCol("#6fe8ff"), x - (veil ? 20 : 34), y1 - 24, veil ? 40 : 68, 32);
      ctx.globalAlpha = 1;
    }
  }

  /** flags in the wind, lanterns on chains, shimmering crystal pools, flickering crystal braziers */
  private dynDecor() {
    const ctx = this.ctx, W = this.W, H = this.H, t = this.t;
    for (const d of this.map.dyn) {
      const x = Math.round(d.x - this.cl), y = Math.round(d.y - this.ct);
      if (d.k === "pool") {
        if (this.environment) continue;
        const pw = d.h || 44, x0 = x - (pw >> 1);
        if (x0 + pw < -10 || x0 > W + 10 || y < -10 || y > H + 10) continue;
        // shimmering bioluminescent turquoise cave pool resting on the basin floor
        ctx.globalAlpha = 0.72;
        this.R("#1b6c80", x0, y - 2, pw, 3);
        this.R("#4de6dc", x0 + 2, y - 2, pw - 4, 1);
        ctx.globalAlpha = 0.9;
        for (let i = 2; i < pw - 3; i += 4) {
          const sh = Math.sin(t * 3.2 + i * 0.6 + d.v * 9);
          if (sh > 0.25) this.R(sh > 0.75 ? "#ffffff" : "#b8fff8", x0 + i, y - 2, sh > 0.65 ? 3 : 2, 1);
        }
        ctx.globalAlpha = 0.25;
        ctx.drawImage(this.glowCol("#5ff0e0"), x0 - 6, y - 14, pw + 12, 22);
        ctx.globalAlpha = 1;
        continue;
      }
      if (x < -30 || x > W + 30 || y < -40 || y > H + 20) continue;
      if (d.k === "flag") {
        const wind = this.map.theme.weather === "sand" ? 0.6 + this.gust : 0.7, team = TEAMS[d.t];
        this.R("#0a0a0f", x - 1, y - 25, 3, 25); this.R("#c9cdd9", x, y - 25, 1, 25); this.R("#f5c542", x - 1, y - 27, 3, 2);
        for (let i = 0; i < 14; i++) {
          const k = i / 13, wave = Math.round(Math.sin(t * (5 + wind * 4) - i * 0.6 + d.x) * (0.6 + k * 2) * Math.min(1.2, wind));
          this.R("#0a0a0f", x + 1 + i, y - 25 + wave, 1, 10);
          this.R(i % 5 === 2 ? team.dark : team.color, x + 1 + i, y - 24 + wave, 1, 8);
          if (i >= 5 && i <= 7) this.R("#ffffff", x + 1 + i, y - 21 + wave, 1, 2);
        }
      } else if (d.k === "lantern") {
        // (an explosion or a tremor sets it swinging hard)
        const sw = Math.sin(t * 1.6 + d.v * 6) * (1.5 + this.sway * 4.5) + Math.sin(t * 9 + d.v * 4) * this.sway * 1.5, fl = Math.sin(t * 13 + d.v * 9) > 0.65;
        for (let k = 0; k < 5; k++) this.R("#3a3a44", x + Math.round((sw * k) / 5), y - 13 + k * 2, 1, 1);
        const bx = x + Math.round(sw) - 2, by = y - 4;
        this.R("#0a0a0f", bx - 1, by - 1, 6, 8); this.R("#6e5832", bx, by, 4, 1); this.R(fl ? "#fff0b0" : "#ffd27a", bx, by + 1, 4, 4); this.R("#ffffff", bx + 1, by + 2, 1, 2); this.R("#5a4a2a", bx, by + 5, 4, 1);
      } else if (d.k === "shaperring") {
        // Iconic Anthem Ancient SHAPER RING Gyroscope hovering over the Central Sky-Sanctuary:
        // counter-rotating bronze-obsidian segmented rings + radiant cyan Anthem energy runes + golden core!
        const R0 = d.h || 22, bob = Math.sin(t * 1.6) * 2.2, cy = y + bob;
        ctx.save();
        ctx.translate(x, cy);
        ctx.globalAlpha = 0.34 + 0.1 * Math.sin(t * 3.2);
        ctx.drawImage(this.glowCol("#48f4ff"), -R0 * 1.5, -R0 * 1.5, R0 * 3, R0 * 3);
        // outer rotating ancient bronze Shaper ring
        ctx.save(); ctx.rotate(t * 0.45);
        ctx.globalAlpha = 1;
        ctx.strokeStyle = "#161d22"; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(0, 0, R0, 0, PI2); ctx.stroke();
        ctx.strokeStyle = "#9c7838"; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(0, 0, R0, 0, PI2); ctx.stroke();
        ctx.strokeStyle = "#f2ce6e"; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(0, 0, R0 + 1, 0, PI2); ctx.stroke();
        // 6 glowing cyan Shaper circuit segments inlaid round the outer ring
        ctx.strokeStyle = "#5ef8ff"; ctx.lineWidth = 2;
        for (let i = 0; i < 6; i++) {
          const a = (i * PI2) / 6;
          ctx.beginPath(); ctx.arc(0, 0, R0, a, a + 0.42); ctx.stroke();
        }
        ctx.restore();
        // inner counter-rotating Shaper harmonic ring
        ctx.save(); ctx.rotate(-t * 0.9);
        ctx.strokeStyle = "#263238"; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.arc(0, 0, R0 * 0.62, 0.3, Math.PI * 1.65); ctx.stroke();
        ctx.strokeStyle = "#e8c260"; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(0, 0, R0 * 0.62, 0.35, Math.PI * 1.6); ctx.stroke();
        ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 1.2;
        for (let i = 0; i < 3; i++) { const a = (i * PI2) / 3; ctx.beginPath(); ctx.arc(0, 0, R0 * 0.62, a, a + 0.35); ctx.stroke(); }
        ctx.restore();
        // levitating Anthem Anthem-of-Creation core star
        const cr = 3 + Math.sin(t * 5) * 0.7;
        ctx.fillStyle = "#5ef8ff"; ctx.beginPath(); ctx.arc(0, 0, cr + 1.5, 0, PI2); ctx.fill();
        ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.arc(0, 0, cr * 0.75, 0, PI2); ctx.fill();
        ctx.restore();
      } else if (d.k === "brazier") {
        const jng = this.map.theme.decor === "jungle";
        const col = jng ? "#48f4ff" : d.v > 0.5 ? "#d57dff" : "#5ff0e0", hot = jng ? "#e0ffff" : d.v > 0.5 ? "#f8dcff" : "#dcfffb";
        const fl = Math.round(Math.sin(t * 11 + d.x) * 1.5);
        this.R("#0e0a16", x - 5, y - 9, 11, 9);
        this.R(jng ? "#8e6c32" : "#464860", x - 4, y - 8, 9, 3); this.R(jng ? "#f0ca68" : "#7a82a6", x - 4, y - 8, 9, 1);
        this.R(jng ? "#2c383a" : "#323348", x - 2, y - 5, 5, 5); this.R(jng ? "#28b850" : "#5c6282", x - 1, y - 5, 2, 4);
        this.R(col, x - 3, y - 12 - Math.max(0, fl), 7, 4 + Math.max(0, fl));
        this.R(hot, x - 2, y - 14 - fl, 5, 4);
        this.R("#ffffff", x - 1, y - 12, 3, 2);
      }
    }
  }

  /**
   * Blood bursts, in the chunky pixels of the game: a wet flash at the wound, then fat drops flung out in tongues - most of them
   * the way the blow was going, a couple back at whoever dealt it - that shrink and begin to fall as they fly.
   */
  private drawBursts() {
    const ctx = this.ctx;
    for (const b of this.bursts) {
      const k = b.life / b.max, x = b.x - this.cl, y = b.y - this.ct, e = 1 - (1 - k) * (1 - k), big = b.r > 14, n = big ? 11 : 8;
      const hv = (i: number) => Math.abs(Math.sin(b.seed + i * 12.9898) * 43758.5453) % 1;
      ctx.globalAlpha = k > 0.7 ? (1 - k) / 0.3 : 1;
      for (let i = 0; i < n; i++) {
        const back = i >= n - 2, a = b.ang + (back ? Math.PI : 0) + (hv(i) - 0.5) * (back ? 1.3 : 1.5);
        const L = b.r * (back ? 0.5 : 0.6 + hv(i + 20) * 0.9) * e, ca = Math.cos(a), sa = Math.sin(a) * 0.85;
        // a tongue: three drops in a line, the fattest at the tip
        for (let j = k > 0.6 ? 0 : 2; j >= 0; j--) {
          const q = 1 - j * 0.3, s = Math.max(1, Math.round((j === 0 ? 3 : j === 1 ? 2 : 1) * (1 - k * 0.6) * (big ? 1.3 : 1)));
          const px = Math.round(x + ca * L * q - s / 2), py = Math.round(y + sa * L * q + k * k * b.r * 0.5 - s / 2);
          ctx.fillStyle = "#5e0f18"; ctx.fillRect(px - 1, py - 1, s + 2, s + 2);
          ctx.fillStyle = j === 0 ? (i % 3 === 0 ? "#f0525a" : "#d0303a") : j === 1 ? "#b01c2a" : "#8a1420"; ctx.fillRect(px, py, s, s);
          if (j === 0 && s > 1 && k < 0.5) { ctx.fillStyle = "#ff9a9a"; ctx.fillRect(px, py, 1, 1); }
        }
      }
      if (k < 0.4) {
        // the wet flash at the wound itself
        const s = big ? 3 : 2;
        ctx.fillStyle = "#d0303a"; ctx.fillRect(Math.round(x) - s - 1, Math.round(y) - 1, s * 2 + 3, 3); ctx.fillRect(Math.round(x) - 1, Math.round(y) - s - 1, 3, s * 2 + 3);
        ctx.fillStyle = "#ff8a8a"; ctx.fillRect(Math.round(x) - s, Math.round(y), s * 2 + 1, 1); ctx.fillRect(Math.round(x), Math.round(y) - s, 1, s * 2 + 1);
        if (k < 0.18) { ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); }
      }
    }
    ctx.globalAlpha = 1;
  }

  /** darkness with holes for every light, then the coloured glow of the lights on top */
  private lights() {
    const T = this.map.theme, ctx = this.ctx, W = this.W, H = this.H, cl = this.cl, ct = this.ct, t = this.t;
    if (T.dark > 0) {
      const dg = this.dg;
      dg.globalCompositeOperation = "source-over";
      dg.clearRect(0, 0, W, H);
      dg.fillStyle = `rgba(4,3,12,${T.dark})`;
      dg.fillRect(0, 0, W, H);
      dg.globalCompositeOperation = "destination-out";
      const hole = (x: number, y: number, r: number, a: number) => {
        if (x + r < 0 || x - r > W || y + r < 0 || y - r > H) return;
        dg.globalAlpha = a;
        dg.drawImage(this.glow, x - r, y - r, r * 2, r * 2);
      };
      for (const l of this.map.lights) hole(l.x - cl, l.y - ct, l.r * (1 + l.pulse * Math.sin(t * 2.2 + l.x * 0.05) + this.flare * 0.28), 1);
      for (const s of this.sol) {
        if (!s.alive) continue;
        hole(s.x - cl, s.y - 10 - ct, s.me ? 70 : s.hide ? 16 : 40, s.me ? 0.9 : s.hide ? 0.3 : 0.7);
        if (s.jetK > 0.2) hole(s.x - s.face * 8 - cl, s.y + 4 - ct, 34 * s.jetK, 0.8);
        if (s.nosK > 0.2) hole(s.x - cl, s.y - 8 - ct, 32 * s.nosK, 0.8);
        if (s.holoK > 0.2) hole(s.x + Math.cos(s.aim) * 12 - cl, s.y - 10 + Math.sin(s.aim) * 12 - ct, 36 * s.holoK, 0.8);
        if (s.tip && s.slots[s.cur]?.id === "axe") hole(s.tip[0] + Math.cos(s.tip[2]) * (s.tip[3] - 5), s.tip[1] + Math.sin(s.tip[2]) * (s.tip[3] - 5), 46, 1);
        if (s.saberOn > 0 && s.tip) hole(s.tip[0] + Math.cos(s.tip[2]) * (s.tip[3] + 10), s.tip[1] + Math.sin(s.tip[2]) * (s.tip[3] + 10), 62 * s.saberOn, 1);
      }
      for (const pair of this.portals) for (const p of pair) if (p) hole(p.x - cl, p.y - ct, 30 + p.fx * 14, 0.85);
      for (const g of this.geysers) if (g.on > 0.1) hole(g.x - cl, g.y - g.h * g.on * 0.5 - ct, 30 + g.h * g.on * 0.5, 0.8);
      for (const b of this.bolts) hole((b.x0 + b.x1) / 2 - cl, (b.y0 + b.y1) / 2 - ct, 44, 0.8);
      for (const s of this.sol) if (s.alive && s.zap > 0) hole(s.x - cl, s.y - 10 - ct, 34, 0.9);
      for (const s of this.sol) if (s.alive && s.chainRev > 0.4 && s.tip) hole(s.tip[0] + Math.cos(s.tip[2]) * (s.tip[3] + 8), s.tip[1] + Math.sin(s.tip[2]) * (s.tip[3] + 8), 34, 0.75);
      for (const f of this.flashes) hole(f.x - cl, f.y - ct, f.r * (f.life / f.max) * 1.4, 1);
      for (const b of this.shots) if (b.kind !== "bullet") hole(b.x - cl, b.y - ct, b.kind === "flame" ? 24 : b.kind === "laser" || b.kind === "bolt" ? 30 : 34, 0.7);
      for (const s of this.scorch) hole(s.x - cl, s.y - ct, 12, s.life / 1.4);
      for (const ar of this.slashArcs) hole(ar.x - cl, ar.y - ct, ar.r * 1.4, (1 - ar.life / ar.max) * 0.85);
      for (const c of this.corpses) if (c.burn > 0 || c.jetFail > 0) hole(c.nodes[1].x - cl, c.nodes[1].y - ct, 26, 0.7);
      for (let i = 0; i < this.parts.length; i += 3) { const p = this.parts[i]; if (p.kind === 5 || p.kind === 9) hole(p.x - cl, p.y - ct, 12, 0.5); }
      dg.globalAlpha = 1;
      dg.globalCompositeOperation = "source-over";
      ctx.drawImage(this.dark, 0, 0);
      ctx.globalCompositeOperation = "lighter";
      for (const l of this.map.lights) {
        const x = l.x - cl, y = l.y - ct, r = l.r * (1 + l.pulse * Math.sin(t * 2.2 + l.x * 0.05) + this.flare * 0.28);
        if (x < -r || x > W + r || y < -r || y > H + r) continue;
        ctx.globalAlpha = this.map.theme.decor === "cave" ? 0.11 : this.environment ? 0.065 : 0.17;
        ctx.drawImage(this.glowCol(l.col), x - r * 0.7, y - r * 0.7, r * 1.4, r * 1.4);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
    ctx.globalCompositeOperation = "lighter";
    for (const f of this.flashes) {
      const k = f.life / f.max, r = f.r * (0.6 + 0.4 * k);
      ctx.globalAlpha = 0.55 * k;
      ctx.drawImage(this.glowCol(f.col), f.x - cl - r, f.y - ct - r, r * 2, r * 2);
    }
    for (const s of this.sol) if (s.alive && s.nosK > 0.2) { ctx.globalAlpha = 0.4 * s.nosK; ctx.drawImage(this.glowCol("#5fd8ff"), s.x - s.face * 6 - cl - 14, s.y - 8 - ct - 14, 28, 28); }
    for (const s of this.sol) if (s.alive && s.jetK > 0.2) {
      const r = 16 + s.burst * 60;
      ctx.globalAlpha = 0.45 * s.jetK; ctx.drawImage(this.glowCol("#ff9a3c"), s.x - s.face * 8 - cl - r, s.y + 5 - ct - r, r * 2, r * 2);
      ctx.globalAlpha = 0.5 * s.jetK; ctx.drawImage(this.glowCol("#fff2c0"), s.x - s.face * 8 - cl - 5, s.y + 2 - ct - 5, 10, 10);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  /** what burns bright, drawn over the dark: tracers, blaster bolts, lightsabers, embers, scorch marks, impact flashes */
  private glowPass() {
    const ctx = this.ctx, cl = this.cl, ct = this.ct, W = this.W, H = this.H;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";
    const seg = (x0: number, y0: number, x1: number, y1: number, w: number, col: string, a: number) => { ctx.strokeStyle = col; ctx.globalAlpha = a; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); };
    // persistent fading bullet vapor contrails (sniper Mach trails, magnum gold lines, rifle/shotgun streaks!)
    for (const tr of this.trails) {
      const k = 1 - tr.life / tr.max;
      seg(tr.x0 - cl, tr.y0 - ct, tr.x1 - cl, tr.y1 - ct, tr.w * (1.2 + (1 - k) * 0.8), tr.col, k * 0.32);
      seg(tr.x0 - cl, tr.y0 - ct, tr.x1 - cl, tr.y1 - ct, Math.max(0.7, tr.w * 0.55 * k), tr.hot, k * 0.72);
    }
    for (const b of this.shots) {
      if (b.kind !== "bullet" && b.kind !== "bolt" && b.kind !== "laser" && b.kind !== "shock" && b.kind !== "portal") continue;
      const x = b.x - cl, y = b.y - ct;
      if (x < -60 || x > W + 60 || y < -60 || y > H + 60) continue;
      if (b.kind === "shock" || b.kind === "portal") { this.drawOrb(b, x, y); continue; }
      const sp = Math.hypot(b.vx, b.vy) || 1, dx = b.vx / sp, dy = b.vy / sp;
      if (b.kind === "bolt") {
        // glowing Astartes gyrojet micro-rocket plume & golden mass-reactive aura!
        const L = Math.min(26, b.dist + 4);
        seg(x - dx * L, y - dy * L, x - dx * 2, y - dy * 2, 7.5, "#ff7a1e", 0.28);
        seg(x - dx * L * 0.85, y - dy * L * 0.85, x - dx * 2, y - dy * 2, 3.6, "#ffd24a", 0.82);
        seg(x - dx * L * 0.5, y - dy * L * 0.5, x, y, 1.5, "#ffffff", 1);
        ctx.globalAlpha = 0.48; ctx.drawImage(this.glowCol("#ff9e28"), x - 14, y - 14, 28, 28);
        continue;
      }
      if (b.kind === "bullet") {
        // hot velocity-stretched tracer with glowing bloom aura, golden core & white-hot nose!
        const wd = AWEP[b.w], heavy = wd.id === "sniper" || wd.id === "magnum";
        const L = Math.min(wd.id === "sniper" ? 58 : wd.id === "magnum" ? 34 : wd.id === "shotgun" ? 17 : 28, b.dist + 3);
        const tc = wd.id === "magnum" ? "#ffd84a" : TEAMS[b.by.team].bullet;
        seg(x - dx * L, y - dy * L, x, y, heavy ? 7.5 : 4.6, tc, 0.26);
        seg(x - dx * L, y - dy * L, x, y, heavy ? 3.4 : 2.3, tc, 0.76);
        seg(x - dx * L * 0.62, y - dy * L * 0.62, x, y, heavy ? 1.3 : 1, "#fffbe8", 1);
        ctx.globalAlpha = 1; ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 2, 2);
        // (a critical round: it flies with a star of gold on its nose)
        if (b.crit) { ctx.globalAlpha = 0.75; ctx.drawImage(this.glowCol("#ffd75e"), x - 9, y - 9, 18, 18); ctx.globalAlpha = 1; ctx.fillStyle = "#fff3a0"; ctx.fillRect(Math.round(x) - 3, Math.round(y), 7, 1); ctx.fillRect(Math.round(x), Math.round(y) - 3, 1, 7); }
        if (heavy) { ctx.globalAlpha = 0.28; ctx.drawImage(this.glowCol(tc), x - 9, y - 9, 18, 18); }
      } else {
        // blaster plasma bolt: vivid multi-layered beam streak + bright plasma head glow
        const B = BEAM[b.by.team], L = Math.min(36, b.dist + 4);
        seg(x - dx * L, y - dy * L, x, y, 11, B.col, 0.22);
        seg(x - dx * L, y - dy * L, x, y, 5.2, B.col, 0.76);
        seg(x - dx * L * 0.85, y - dy * L * 0.85, x, y, 2.8, B.hot, 0.97);
        seg(x - dx * L * 0.7, y - dy * L * 0.7, x, y, 1.4, "#ffffff", 1);
        ctx.globalAlpha = 0.5; ctx.drawImage(this.glowCol(B.col), x - 18, y - 18, 36, 36);
        if (b.crit) { ctx.globalAlpha = 1; ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x) - 3, Math.round(y), 7, 1); ctx.fillRect(Math.round(x), Math.round(y) - 3, 1, 7); }
      }
    }
    this.drawSlashArcs();
    this.blades();
    for (const s of this.sol) if (s.alive && s.holoK > 0.04) this.drawHolo(s, true);
    this.drawPortals(true);
    this.drawBolts();
    this.drawGeysers(true);
    // visors, the sockets of the skull and the eyes behind the veil smoulder in the dark
    for (const s of this.sol) {
      if (!s.alive || (s.hide && s.team !== this.me.team)) continue;
      const P = opPal(s.team, s.skin);
      if (!P.aura) continue;
      ctx.globalAlpha = 0.3 + 0.08 * Math.sin(this.t * 5 + s.id);
      ctx.drawImage(this.glowCol(P.glow), s.x - cl + s.face - 7, s.y - ct - 20 + s.duck * 5, 14, 14);
    }
    for (const p of this.parts) {
      if (p.kind !== 5 && p.kind !== 9) continue;
      const x = p.x - cl, y = p.y - ct;
      if (x < -10 || x > W + 10 || y < -10 || y > H + 10) continue;
      ctx.globalAlpha = Math.min(1, (p.life / p.max) * 1.5);
      if (p.kind === 9) {
        // a spark: a bright streak along its flight, with a white-hot head that shrinks as it cools
        const k = p.life / p.max, hot = k > 0.45;
        ctx.strokeStyle = p.col; ctx.lineWidth = hot ? 1.6 : 1;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - p.vx * 0.04, y - p.vy * 0.04); ctx.stroke();
        ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x) - (hot ? 1 : 0), Math.round(y) - (hot ? 1 : 0), hot ? 2 : 1, hot ? 2 : 1);
        continue;
      }
      ctx.fillStyle = p.col;
      ctx.fillRect(Math.round(x), Math.round(y), p.size, p.size);
    }
    for (const s of this.scorch) {
      const k = s.life / 1.4, x = s.x - cl, y = s.y - ct;
      ctx.globalAlpha = k * 0.75; ctx.drawImage(this.glowCol(s.col), x - 6, y - 6, 12, 12);
      if (k > 0.6) { ctx.globalAlpha = (k - 0.6) * 2.5; ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); }
    }
    for (const h of this.hitfx) {
      // impact flashes: a diamond of white light and rays, burnt onto the picture
      const k = h.life / h.max, x = h.x - cl, y = h.y - ct, r = h.r * (0.55 + 0.75 * k), n = h.kind === 1 ? 8 : h.kind === 2 ? 5 : 4;
      ctx.globalAlpha = 1 - k;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath(); ctx.moveTo(x - r * 0.45, y); ctx.lineTo(x, y - r * 0.45); ctx.lineTo(x + r * 0.45, y); ctx.lineTo(x, y + r * 0.45); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = h.kind === 2 ? h.col || "#8af0ff" : h.kind === 1 ? "#ffe45c" : "#ffd27a";
      ctx.lineWidth = h.kind === 1 ? 2 : 1;
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const a = h.ang + (i * PI2) / n, L = r * (h.kind === 2 ? 2.2 : i % 2 ? 1 : 1.8);
        ctx.moveTo(x + Math.cos(a) * r * 0.3, y + Math.sin(a) * r * 0.3);
        ctx.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L);
      }
      ctx.stroke();
    }
    for (const r of this.rings) {
      const p = r.life / r.max;
      ctx.globalAlpha = 1 - p;
      ctx.strokeStyle = p < 0.35 ? "#ffffff" : r.col;
      ctx.lineWidth = Math.max(1, (r.r > 20 ? 3 : 2) - p * 2);
      ctx.beginPath();
      ctx.arc(r.x - cl, r.y - ct, r.r * (0.2 + p * 0.9), 0, PI2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    for (const s of this.stars) {
      // a little white cross of light
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct, n = s.life > 0.04 ? 4 : 2;
      ctx.fillStyle = s.col;
      ctx.fillRect(x - n, y, n * 2 + 1, 1);
      ctx.fillRect(x, y - n, 1, n * 2 + 1);
      ctx.fillRect(x - 1, y - 1, 3, 3);
    }
    ctx.restore();
  }

  /** 2.5D crescent slash waves: unmistakable wide horizontal side-sweeps + crisp vertical/spin fans for Katana & Lightsaber! */
  private drawSlashArcs() {
    const ctx = this.ctx, cl = this.cl, ct = this.ct;
    for (const ar of this.slashArcs) {
      const p = ar.life / ar.max, fade = Math.pow(1 - p, 1.35);
      const x = ar.x - cl, y = ar.y - ct;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(ar.ang);
      if (ar.plane === "horiz") {
        // 2.5D FORESHORTENED HORIZONTAL SIDE-SWEEP CRESCENT!
        // Animated wipe-in sweeps visibly from one side across the front to the opposite side!
        const dir = ar.dir >= 0 ? 1 : -1;
        const headP = easeOut(clamp(p / 0.48, 0, 1));
        const tailP = smooth(clamp((p - 0.14) / 0.86, 0, 1));
        const rx = ar.r * (0.85 + 0.38 * headP);
        const ry = ar.r * 0.32 * (1 - p * 0.22);
        const aMin = -Math.PI * 0.82, aMax = Math.PI * 0.78;
        const aTail = (aMin + (aMax - aMin) * tailP * 0.62) * dir;
        const aHead = (aMin + (aMax - aMin) * headP) * dir;
        const ccw = dir < 0;
        // soft outer horizontal ribbon glow
        ctx.strokeStyle = ar.col;
        ctx.globalAlpha = fade * 0.34;
        ctx.lineWidth = 9 * (1 - p * 0.45);
        ctx.beginPath();
        ctx.ellipse(2, 1, rx, ry, 0, aTail, aHead, ccw);
        ctx.stroke();
        // vivid crescent body
        ctx.strokeStyle = ar.col;
        ctx.globalAlpha = fade * 0.82;
        ctx.lineWidth = 4.4 * (1 - p * 0.38);
        ctx.beginPath();
        ctx.ellipse(3, 1, rx, ry, 0, aTail, aHead, ccw);
        ctx.stroke();
        // razor white-hot leading steel/plasma edge
        ctx.strokeStyle = ar.hot;
        ctx.globalAlpha = fade * 0.98;
        ctx.lineWidth = 1.9 * (1 - p * 0.28);
        ctx.beginPath();
        ctx.ellipse(4, 1, rx * 1.03, ry * 0.96, 0, aTail, aHead, ccw);
        ctx.stroke();
        // crisp horizontal speed-cut line slicing sideways through center!
        ctx.strokeStyle = "#ffffff";
        ctx.globalAlpha = fade * (ar.katana ? 0.92 : 0.78);
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(-rx * 0.45 + rx * tailP * 0.5, -ry * 0.22 * dir);
        ctx.lineTo(-rx * 0.45 + rx * 1.65 * headP, ry * 0.16 * dir);
        ctx.stroke();
        // jagged roaring adamantium saw-teeth glints along the Chainsword's arc!
        if (ar.chain) {
          ctx.fillStyle = "#ffffff";
          ctx.globalAlpha = fade * 0.95;
          for (let ti = 0; ti < 7; ti++) {
            const ta = aTail + (aHead - aTail) * (ti / 6);
            ctx.fillRect(Math.round(4 + Math.cos(ta) * (rx + 2)) - 1, Math.round(1 + Math.sin(ta) * (ry + 1)) - 1, 2, 2);
          }
        }
      } else if (ar.plane === "vert") {
        // classic crisp overhead downward diagonal crescent arc
        const dir = ar.dir >= 0 ? 1 : -1;
        const rad = ar.r * (0.85 + 0.25 * easeOut(p));
        const a0 = -1.45 * dir, a1 = 1.35 * dir;
        const ccw = dir < 0;
        ctx.strokeStyle = ar.col;
        ctx.globalAlpha = fade * 0.35;
        ctx.lineWidth = 7 * (1 - p * 0.4);
        ctx.beginPath(); ctx.arc(0, 0, rad, a0, a1, ccw); ctx.stroke();
        ctx.strokeStyle = ar.hot;
        ctx.globalAlpha = fade * 0.95;
        ctx.lineWidth = 2 * (1 - p * 0.35);
        ctx.beginPath(); ctx.arc(0, 0, rad + 1, a0, a1, ccw); ctx.stroke();
      } else {
        // 360° full spin ring wave
        const rad = ar.r * (0.78 + 0.35 * easeOut(p));
        ctx.strokeStyle = ar.col;
        ctx.globalAlpha = fade * 0.45;
        ctx.lineWidth = 6 * (1 - p * 0.45);
        ctx.beginPath(); ctx.arc(0, 0, rad, 0, PI2); ctx.stroke();
        ctx.strokeStyle = ar.hot;
        ctx.globalAlpha = fade * 0.9;
        ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(0, 0, rad + 1, p * 4, p * 4 + Math.PI * 1.4); ctx.stroke();
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  /** lightsabers & katana glowing blade trails: foreshortened dynamically during 2.5D horizontal side-sweeps! */
  private blades() {
    const ctx = this.ctx;
    for (const s of this.sol) {
      if (!s.alive || !s.tip) continue;
      const sl = s.slots[s.cur];
      if (!sl) continue;
      if (sl.id === "axe") {
        // the argent axe: its edge burns - a fan of fire behind every swing, a white-hot line along the blade, a glow that breathes
        const [hx, hy, a, u] = s.tip, sg = Math.cos(s.aim) < 0 ? -1 : 1, ca = Math.cos(a), sa = Math.sin(a), pulse = 0.75 + 0.25 * Math.sin(this.t * 9 + s.id);
        if (s.swingT > 0 && s.swingPlane !== "horiz") {
          const tr = s.trail, r0 = u - 13, r1 = u + 1;
          for (let i = 0; i < tr.length - 1; i++) {
            const a0 = tr[i], a1 = tr[i + 1];
            if (Math.abs(angDiff(a0, a1)) < 0.04) continue;
            ctx.globalAlpha = 0.36 * (1 - i / tr.length); ctx.fillStyle = i < 2 ? "#ffd27a" : "#ff5a1e";
            ctx.beginPath();
            ctx.moveTo(hx + Math.cos(a0) * r0, hy + Math.sin(a0) * r0); ctx.lineTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1);
            ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.lineTo(hx + Math.cos(a1) * r0, hy + Math.sin(a1) * r0);
            ctx.closePath(); ctx.fill();
          }
        }
        // (the edge is on the under side of the head)
        const ex = hx + ca * (u - 5) - sa * 5 * sg, ey = hy + sa * (u - 5) + ca * 5 * sg;
        ctx.globalAlpha = 0.55 * pulse; ctx.drawImage(this.glowCol("#ff5a1e"), ex - 14, ey - 14, 28, 28);
        ctx.globalAlpha = 0.5 * pulse; ctx.drawImage(this.glowCol("#ffd27a"), ex - 6, ey - 6, 12, 12);
        ctx.strokeStyle = "#ffe9a0"; ctx.globalAlpha = 0.9 * pulse; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(ex - ca * 4, ey - sa * 4); ctx.lineTo(ex + ca * 4, ey + sa * 4); ctx.stroke();
        continue;
      }
      if (sl.id === "chainsword") {
        // roaring Astartes chainsword: fiery golden-crimson saw-tooth friction ribbon during swings + hot engine ember glow!
        const [hx, hy, a, u] = s.tip, L = CHAIN_L * s.swingScale, x0 = hx + Math.cos(a) * u, y0 = hy + Math.sin(a) * u, x1 = hx + Math.cos(a) * (u + L), y1 = hy + Math.sin(a) * (u + L);
        if (s.swingT > 0 && s.swingPlane !== "horiz") {
          const tr = s.trail, r0 = u, r1 = u + L;
          for (let i = 0; i < tr.length - 1; i++) {
            const a0 = tr[i], a1 = tr[i + 1];
            if (Math.abs(angDiff(a0, a1)) < 0.03) continue;
            const k = 1 - i / tr.length;
            ctx.globalAlpha = 0.36 * k; ctx.fillStyle = i < 2 ? "#ffd24a" : "#e03824";
            ctx.beginPath();
            ctx.moveTo(hx + Math.cos(a0) * r0, hy + Math.sin(a0) * r0); ctx.lineTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1);
            ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.lineTo(hx + Math.cos(a1) * r0, hy + Math.sin(a1) * r0);
            ctx.closePath(); ctx.fill();
            ctx.globalAlpha = 0.85 * k; ctx.strokeStyle = "#fff6b8"; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1); ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.stroke();
          }
        }
        ctx.globalAlpha = s.swingT > 0 ? 0.52 : 0.22;
        ctx.drawImage(this.glowCol("#ff8a24"), (x0 + x1) / 2 - 18, (y0 + y1) / 2 - 18, 36, 36);
        continue;
      }
      if (sl.id === "katana") {
        // katana subtle metallic gleam ribbon during active swings
        if (s.swingT <= 0 || s.swingPlane === "horiz") continue;
        const [hx, hy, a, u] = s.tip, L = KATANA_L * s.swingScale;
        const tr = s.trail, r0 = u, r1 = u + L;
        for (let i = 0; i < tr.length - 1; i++) {
          const a0 = tr[i], a1 = tr[i + 1];
          if (Math.abs(angDiff(a0, a1)) < 0.04) continue;
          const k = 1 - i / tr.length;
          ctx.globalAlpha = 0.28 * k;
          ctx.fillStyle = "#9ee8ff";
          ctx.beginPath();
          ctx.moveTo(hx + Math.cos(a0) * r0, hy + Math.sin(a0) * r0); ctx.lineTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1);
          ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.lineTo(hx + Math.cos(a1) * r0, hy + Math.sin(a1) * r0);
          ctx.closePath();
          ctx.fill();
          ctx.globalAlpha = 0.72 * k;
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1); ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.stroke();
        }
        const x0 = hx + Math.cos(a) * u, y0 = hy + Math.sin(a) * u, x1 = hx + Math.cos(a) * (u + L), y1 = hy + Math.sin(a) * (u + L);
        ctx.strokeStyle = "#ffffff"; ctx.globalAlpha = 0.65; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
        continue;
      }
      if (sl.id !== "saber" || s.saberOn <= 0) continue;
      const B = BEAM[s.team], [hx, hy, a, u] = s.tip;
      const L = SABER_L * s.saberOn * s.swingScale * (0.97 + 0.03 * Math.sin(this.t * 60 + s.id));
      const x0 = hx + Math.cos(a) * u, y0 = hy + Math.sin(a) * u, x1 = hx + Math.cos(a) * (u + L), y1 = hy + Math.sin(a) * (u + L);
      if (s.swingPlane !== "horiz") {
        const tr = s.trail, r0 = u, r1 = u + L;
        for (let i = 0; i < tr.length - 1; i++) {
          const a0 = tr[i], a1 = tr[i + 1];
          if (Math.abs(angDiff(a0, a1)) < 0.03) continue;
          const k = 1 - i / tr.length;
          ctx.globalAlpha = 0.34 * k;
          ctx.fillStyle = B.col;
          ctx.beginPath();
          ctx.moveTo(hx + Math.cos(a0) * r0, hy + Math.sin(a0) * r0); ctx.lineTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1);
          ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.lineTo(hx + Math.cos(a1) * r0, hy + Math.sin(a1) * r0);
          ctx.closePath();
          ctx.fill();
          ctx.globalAlpha = 0.55 * k;
          ctx.strokeStyle = B.hot;
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1); ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.stroke();
        }
      }
      const line = (w: number, col: string, al: number) => { ctx.strokeStyle = col; ctx.globalAlpha = al; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); };
      line(13, B.col, 0.08); line(9, B.col, 0.14); line(5.5, B.col, 0.32); line(3.2, B.col, 0.78); line(1.8, B.hot, 0.96); line(0.9, "#ffffff", 1);
      const g = this.glowCol(B.col);
      ctx.globalAlpha = 0.32; ctx.drawImage(g, (x0 + x1) / 2 - 36, (y0 + y1) / 2 - 36, 72, 72);
      ctx.globalAlpha = 0.62; ctx.drawImage(g, x0 - 5, y0 - 5, 10, 10);
      ctx.globalAlpha = 0.52; ctx.drawImage(this.glowCol(B.hot), x1 - 3, y1 - 3, 6, 6);
    }
    ctx.globalAlpha = 1;
  }

  /** sand blowing through in a storm, the rain of the ruined city, spores drifting in the cave */
  private weather() {
    const ctx = this.ctx, T = this.map.theme, W = this.W, H = this.H, cl = this.cl, ct = this.ct;
    if (T.rain) {
      ctx.strokeStyle = "rgba(180,196,236,0.42)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < this.rain.length; i += 2) {
        const x = ((((this.rain[i] - cl * 0.6) % (W + 40)) + W + 40) % (W + 40)) - 20, y = ((((this.rain[i + 1] - ct * 0.6) % (H + 40)) + H + 40) % (H + 40)) - 20;
        ctx.moveTo(x, y); ctx.lineTo(x - 2, y + 7);
      }
      ctx.stroke();
    }
    if (T.weather === "sand") {
      const g = this.gust, blob = blobSpr();
      ctx.fillStyle = `rgba(226,170,104,${(0.04 + g * 0.1).toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
      for (let i = 0; i < this.dust.length; i += 4) {
        const span = W + 300, x = ((((this.dust[i] - cl * 0.7) % span) + span) % span) - 150, y = ((((this.dust[i + 1] - ct * 0.5) % (H + 120)) + H + 120) % (H + 120)) - 60, s = this.dust[i + 2];
        ctx.globalAlpha = 0.1 + g * 0.24;
        ctx.drawImage(blob, x - s, y - s * 0.55, s * 2, s * 1.1);
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = `rgba(255,228,176,${(0.35 + g * 0.35).toFixed(3)})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < this.sand.length; i += 4) {
        const x = ((((this.sand[i] - cl) % (W + 60)) + W + 60) % (W + 60)) - 30, y = ((((this.sand[i + 1] - ct) % (H + 40)) + H + 40) % (H + 40)) - 20, L = this.sand[i + 3] * (0.6 + g);
        ctx.moveTo(x, y); ctx.lineTo(x - L, y - L * 0.1);
      }
      ctx.stroke();
    } else if (T.weather === "spores") {
      const cols = ["#89bcbc", "#a0cdd0", "#b4b3cf", "#d5c99c", "#a5ccbc"];
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < this.spores.length; i += 4) {
        const x = ((((this.spores[i] - cl * 0.9) % (W + 40)) + W + 40) % (W + 40)) - 20, y = ((((this.spores[i + 1] - ct * 0.9) % (H + 40)) + H + 40) % (H + 40)) - 20;
        const fl = 0.4 + 0.6 * Math.abs(Math.sin(this.t * 2.1 + this.spores[i + 2]));
        ctx.fillStyle = cols[this.spores[i + 3] % 5];
        ctx.globalAlpha = fl * 0.88;
        ctx.fillRect(Math.round(x), Math.round(y), 1, 1);
        if (fl > 0.82) { ctx.globalAlpha = 0.26; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); }
      }
      // bioluminescent cave fireflies gliding with soft glowing halos across the grand cathedral
      for (let i = 0; i < this.fireflies.length; i += 5) {
        const fx = this.fireflies[i] - cl, fy = this.fireflies[i + 1] - ct;
        if (fx < -20 || fx > W + 20 || fy < -20 || fy > H + 20) continue;
        const pulse = 0.35 + 0.65 * Math.pow(Math.sin(this.t * 2.8 + this.fireflies[i + 2]) * 0.5 + 0.5, 1.5);
        const col = cols[this.fireflies[i + 4] % 5];
        ctx.globalAlpha = pulse * 0.42;
        ctx.drawImage(this.glowCol(col), fx - 8, fy - 8, 16, 16);
        ctx.globalAlpha = pulse;
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(Math.round(fx), Math.round(fy), 1, 1);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    } else if (T.weather === "jungle") {
      // Drifting emerald canopy leaves, coral/orchid flower petals & shimmering golden Bastion sun-pollen!
      const pCols = ["#52e264", "#a8ff74", "#ff68a8", "#ff9e38", "#fff088", "#dcfff4"];
      for (let i = 0; i < this.petals.length; i += 4) {
        const x = ((((this.petals[i] - cl * 0.88) % (W + 40)) + W + 40) % (W + 40)) - 20;
        const y = ((((this.petals[i + 1] - ct * 0.88) % (H + 40)) + H + 40) % (H + 40)) - 20;
        const kind = this.petals[i + 3], pollen = kind >= 4;
        ctx.fillStyle = pCols[kind % 6];
        ctx.globalAlpha = pollen ? 0.55 + 0.4 * Math.abs(Math.sin(this.t * 2.4 + this.petals[i + 2])) : 0.9;
        const tw = !pollen && Math.sin(this.t * 5 + this.petals[i + 2]) > 0 ? 2 : 1;
        ctx.fillRect(Math.round(x), Math.round(y), tw, 1);
      }
      // Colorful tropical butterflies (Blue Morpho, Golden Monarch, Emerald Birdwing, Magenta Orchid, Sunburst) flapping over the flora!
      const bCols = [["#2ecbff", "#c8f8ff"], ["#ff9e22", "#fff06a"], ["#3eff8e", "#d8ffe6"], ["#ff58c0", "#ffd8f4"], ["#ffe448", "#ffffff"]];
      for (let i = 0; i < this.butterflies.length; i += 5) {
        const bx = Math.round(this.butterflies[i] - cl), by = Math.round(this.butterflies[i + 1] - ct);
        if (bx < -12 || bx > W + 12 || by < -12 || by > H + 12) continue;
        const [c0, hi] = bCols[this.butterflies[i + 4] % 5];
        const open = Math.sin(this.t * 17 + this.butterflies[i + 2] * 3) > -0.15;
        ctx.globalAlpha = 0.95;
        if (open) {
          this.R(c0, bx - 2, by - 1, 2, 2); this.R(c0, bx + 1, by - 1, 2, 2);
          this.R(hi, bx - 2, by - 1, 1, 1); this.R(hi, bx + 2, by - 1, 1, 1);
        } else {
          this.R(c0, bx, by - 2, 2, 2); this.R(hi, bx, by - 2, 1, 1);
        }
        this.R("#141a18", bx, by, 1, 1);
      }
      ctx.globalAlpha = 1;
    }
  }

  private drawMini() {
    const ctx = this.ctx, m = this.mini, x0 = 5, y0 = this.H - m.height - 5, me = this.me;
    ctx.globalAlpha = 0.88;
    this.R("#0a0a0f", x0 - 1, y0 - 1, m.width + 2, m.height + 2);
    ctx.drawImage(m, x0, y0);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 1;
    ctx.strokeRect(x0 + Math.round(this.cl / 16) + 0.5, y0 + Math.round(this.ct / 16) + 0.5, Math.round(this.W / 16), Math.round(this.H / 16));
    for (const q of this.map.hides) this.R("#4ee08a", x0 + Math.floor(q.x / 16), y0 + Math.floor(q.y / 16) - 1, 1, 1);
    for (const g of this.geysers) this.R(g.st === 2 ? "#ffffff" : "#5fd0e8", x0 + Math.floor(g.x / 16), y0 + Math.floor(g.y / 16) - (g.st === 2 ? 3 : 1), 1, g.st === 2 ? 4 : 2);
    for (const pair of this.portals) for (const p of pair) if (p && Math.sin(this.t * 7) > -0.5) this.R(PORTC[p.team][p.slot], x0 + Math.floor(p.x / 16) - 1, y0 + Math.floor(p.y / 16) - 1, 2, 2);
    for (const p of this.picks) if (p.kind === "saber" && !(p.spot && p.t > 0) && Math.sin(this.t * 6) > 0) this.R("#9ae8ff", x0 + Math.floor(p.x / 16), y0 + Math.floor(p.y / 16) - 1, 1, 1);
    for (const s of this.sol) {
      if (!s.alive || s.me) continue;
      if (s.team !== me.team && s.loud <= 0 && s.saberOn <= 0) continue;
      this.R(s.team === me.team ? TEAMS[s.team].color : "#ff4d5e", x0 + Math.floor(s.x / 16) - 1, y0 + Math.floor((s.y - 9) / 16) - 1, 2, 2);
    }
    if (me.alive && Math.sin(this.t * 8) > -0.4) this.R("#ffffff", x0 + Math.floor(me.x / 16) - 1, y0 + Math.floor((me.y - 9) / 16) - 1, 3, 3);
  }

  // ───────────── the fallen ─────────────
  /**
   * A ragdoll, drawn from the hips outwards on bones of fixed length - spine, neck, arms, legs - in the proportions of the living
   * soldier: whatever the physics is doing, the body is in one piece. Far arm and leg, jetpack and body, near leg and arm, head.
   */
  private drawRagdoll(c: Ragdoll) {
    const ctx = this.ctx, cl = this.cl, ct = this.ct, N = c.nodes, hp = N[2];
    if (hp.x - cl < -45 || hp.x - cl > this.W + 45 || hp.y - ct < -45 || hp.y - ct > this.H + 45) return;
    const P = opPal(c.team, c.skin), f = c.face;
    // the spine from the hips to the chest, and the neck - bent no further than about 55° from the line of the spine
    let ax = N[1].x - hp.x, ay = N[1].y - hp.y;
    const al = Math.hypot(ax, ay) || 1;
    ax /= al; ay /= al;
    const chx = hp.x + ax * 4.6, chy = hp.y + ay * 4.6;
    let nx = N[0].x - N[1].x, ny = N[0].y - N[1].y;
    const nl = Math.hypot(nx, ny) || 1;
    nx /= nl; ny /= nl;
    if (nx * ax + ny * ay < 0.57) { const sg = ax * ny - ay * nx >= 0 ? 1 : -1; nx = ax * 0.57 - ay * 0.82 * sg; ny = ay * 0.57 + ax * 0.82 * sg; }
    const hdx = chx + nx * 5.6, hdy = chy + ny * 5.6, ox = -ay * f, oy = ax * f; // (ox, oy: across the body, towards its front)
    ctx.save();
    ctx.globalAlpha = c.life < 0.85 ? clamp(c.life / 0.85, 0, 1) : 1;
    // its shadow on the ground
    const low = Math.max(chy, hp.y), gy = this.groundBelow((chx + hp.x) * 0.5, low, 12);
    if (gy >= 0) { ctx.fillStyle = `rgba(0,0,0,${((1 - (gy - low) / 12) * 0.3).toFixed(3)})`; ctx.fillRect(Math.round((chx + hp.x) * 0.5 - cl) - 7, Math.round(gy - ct) - 1, 14, 2); }
    // what trailed from the neck still does
    if (P.scarf) {
      const sc = c.scarf, pts: number[] = [], o = P.cape === 2 ? 3 : 2, n = P.cape === 2 ? 2 : 1;
      let qx = chx, qy = chy;
      for (let i = 0; i < 6; i += 2) {
        for (let k = 1; k <= 3; k++) pts.push(Math.round(qx + ((sc[i] - qx) * k) / 3) - cl, Math.round(qy + ((sc[i + 1] - qy) * k) / 3) - ct);
        qx = sc[i]; qy = sc[i + 1];
      }
      ctx.fillStyle = "#0a0a0f";
      for (let i = 0; i < pts.length; i += 2) ctx.fillRect(pts[i] - o, pts[i + 1] - o, o * 2, o * 2);
      for (let i = pts.length - 2; i >= 0; i -= 2) { ctx.fillStyle = i >= 12 ? P.scarf2 : P.scarf; ctx.fillRect(pts[i] - n, pts[i + 1] - n, n * 2, n * 2); }
    }
    /** a limb: from where it is rooted on the body towards its hand or foot - never longer than its bones */
    const limb = (rx: number, ry: number, n: RagNode, root: RagNode, len: number, col: string, tip: string, w: number) => {
      let dx = n.x - root.x, dy = n.y - root.y;
      const d = Math.hypot(dx, dy) || 1, L = Math.min(len, Math.max(len * 0.5, d));
      dx /= d; dy /= d;
      const x0 = rx - cl, y0 = ry - ct, x1 = x0 + dx * L, y1 = y0 + dy * L;
      ctx.lineCap = "round";
      ctx.strokeStyle = P.K; ctx.lineWidth = w + 2; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      ctx.fillStyle = P.K; ctx.fillRect(Math.round(x1) - 2, Math.round(y1) - 2, 4, 4);
      ctx.fillStyle = tip; ctx.fillRect(Math.round(x1) - 1, Math.round(y1) - 1, 2, 2);
    };
    limb(chx - ox * 2, chy - oy * 2, N[3], N[1], 4.6, P.arm, P.hand, 2);
    limb(hp.x - ox * 1.2, hp.y - oy * 1.2, N[5], hp, 3.5, P.legs2, P.boots, 2.2);
    // the jetpack on its back, and the body (without the arms that hang at the sides of the living sprite: here the arms are limbs)
    ctx.save();
    ctx.translate((hp.x + chx) / 2 - cl, (hp.y + chy) / 2 - ct);
    ctx.rotate(Math.atan2(ay, ax) + Math.PI / 2);
    ctx.scale(f, 1);
    ctx.fillStyle = P.K; ctx.fillRect(-10, -6, 6, 10);
    ctx.fillStyle = "#6b7388"; ctx.fillRect(-9, -5, 4, 8);
    ctx.fillStyle = "#aab3c8"; ctx.fillRect(-9, -5, 1, 7);
    ctx.fillStyle = P.accent; ctx.fillRect(-9, -2, 4, 1);
    ctx.drawImage(opTorso(c.team, c.skin, false), c.skin === ASTARTES ? -7 : -5, c.skin === ASTARTES ? -4 : -3);
    ctx.restore();
    limb(hp.x + ox * 1.2, hp.y + oy * 1.2, N[6], hp, 3.5, P.legs, P.boots, c.skin === ASTARTES ? 3 : 2.2);
    limb(chx + ox * 2, chy + oy * 2, N[4], N[1], 4.6, P.arm, P.hand, c.skin === ASTARTES ? 2.8 : 2);
    ctx.save();
    ctx.translate(hdx - cl, hdy - ct);
    ctx.rotate(Math.atan2(ny, nx) + Math.PI / 2);
    ctx.scale(f, 1);
    ctx.drawImage(opHead(c.team, c.skin, false), c.skin === ASTARTES ? -8 : -7, -5);
    const E = EYES[c.skin] ?? EYES[0], dark = "#1a1014";
    const Px = (col: string, x: number, y: number, w = 1, h = 1) => { ctx.fillStyle = col; ctx.fillRect(-7 + x, -5 + y, w, h); };
    E.e.forEach((e) => {
      const ex = e[0], ey = e[1], ew = e[2] ?? 2;
      if (E.kind === 0) { Px(P.lid, ex, ey, 2, 1); Px(dark, ex - 1, ey - 1); Px(dark, ex + 1, ey - 1); Px(dark, ex, ey); Px(dark, ex - 1, ey + 1); Px(dark, ex + 1, ey + 1); }
      else if (E.kind === 1) Px(P.lid, ex, ey, ew, 1);
      else if (E.kind === 2) { Px(P.skull, ex, ey); Px(P.skull, ex + 1, ey + 1); }
      else { Px("#ffffff", ex + 2, ey); Px("#ffffff", ex + 1, ey + 1); Px("#ffffff", ex, ey + 2); }
    });
    ctx.restore();
    ctx.restore();
  }

  // ───────────── a soldier ─────────────
  private drawSol(s: Sol) {
    const ctx = this.ctx, X0 = Math.round(s.x) - this.cl, Y0 = Math.round(s.y) - this.ct;
    if (X0 < -40 || X0 > this.W + 40 || Y0 < -50 || Y0 > this.H + 50) { s.tip = null; return; }
    // the gait: every body moves its own way - a bouncy jog, a heavy stomp, a low prowl, an easy swagger
    const moving = s.ground && Math.abs(s.vx) > 12, GP = s.walkT * GAIT, step = moving ? Math.sin(GP) : 0;
    let bob = moving ? (Math.abs(step) > 0.6 ? 1 : 0) : Math.sin(this.t * 2.6 + s.id) > 0.55 ? 1 : 0;
    let rot = s.tilt, hop = 0, lx = 0, ly = 0, sx = 1, sy = 1;
    if (moving) {
      // a bounding run: the body flies between footfalls and sinks onto each one - stretched in the air, squashed as the boot lands -
      // and leans into it, further still at a sprint; braking hard throws it back on its heels
      const fl = Math.abs(Math.cos(GP)), st = 1 - fl, gait = s.id % 4, rk = s.runK, nk = s.nosK, dir = s.vx >= 0 ? 1 : -1;
      hop += fl * (1.1 + rk * 1.5 + nk * 0.9);
      rot += dir * (0.06 + 0.1 * rk + 0.13 * nk) - dir * s.skid * 0.32;
      sy *= 1 + (0.08 * fl - 0.1 * st * st) * (0.4 + 0.6 * rk);
      sx *= 1 - (0.05 * fl - 0.08 * st * st) * (0.4 + 0.6 * rk);
      if (gait === 1) { ly += st * 0.8; rot += Math.sin(GP) * 0.04; }
      else if (gait === 2) { ly += 0.6; sy *= 0.97; }
      else if (gait === 3) rot += Math.sin(GP) * 0.05;
    } else if (!s.ground) {
      // expressive aerial banking: leans cleanly into horizontal flight, stretches on jet boost & tucks forward into a Meteor Dive!
      rot += clamp(s.vx / AIRSPD, -1, 1) * (0.25 + s.nosK * 0.34) + (s.dive ? s.face * 0.24 : 0);
      if (s.jet) { sy *= 1.06; sx *= 0.95; }
      else if (s.dive) { sy *= 1.12; sx *= 0.92; }
      else if (s.vy > 220) { const fk = clamp((s.vy - 220) / 260, 0, 1); sy *= 1 + 0.08 * fk; sx *= 1 - 0.05 * fk; }
      bob = 0;
    } else {
      sy *= 1 + Math.sin(this.t * 2.6 + s.id) * 0.018;
      const idle = (this.t * 0.31 + s.id * 0.77) % 6;
      if (idle < 0.5) { const k = Math.sin((idle / 0.5) * Math.PI); sy *= 1 + 0.06 * k; hop += k * 1.1; }
    }
    const tkScale = s.skin === ASTARTES ? 1.1 : 1;
    if (s.squash > 0) { const k = Math.min(1, s.squash / 0.16); sy *= 1 - 0.27 * k; sx *= 1 + 0.24 * k; }
    if (s.burst > 0.1) { sy *= 1.11; sx *= 0.92; }
    if (s.duck > 0.02) { sy *= 1 - 0.34 * s.duck; sx *= 1 + 0.08 * s.duck; }
    if (s.zap > 0) { lx += (rand() - 0.5) * 2.4; rot += (rand() - 0.5) * 0.16; }
    lx -= Math.cos(s.aim) * s.recoil * 1.4;
    ly -= Math.sin(s.aim) * s.recoil * 0.9;
    if (s.swingT > 0) {
      const p = 1 - s.swingT / s.swingDur;
      if (s.swingPlane === "horiz") {
        lx += s.face * (3.5 + (s.swingKind === 3 ? 2.5 : 0)) * Math.sin(p * Math.PI);
        rot += s.face * 0.18 * Math.sin(p * Math.PI) * (s.swingKind === 2 ? -1 : 1);
        sx *= 1 + 0.1 * Math.sin(p * Math.PI);
      } else {
        lx += s.face * 2.5 * Math.sin(p * Math.PI);
        rot += s.face * 0.14 * Math.sin(p * Math.PI) * (s.swingKind === 1 ? -1 : 1);
      }
    }
    if (s.ground) this.R("rgba(0,0,0,0.32)", X0 - (s.skin === ASTARTES ? 7 : 5), Y0 - 1, s.skin === ASTARTES ? 15 : 10, 2);
    this.scarfDraw(s);
    const X = X0 + Math.round(lx), Y = Y0 - Math.round(hop) + Math.round(ly), white = s.flash > 0 || (s.zap > 0 && Math.sin(this.t * 70 + s.id) > 0.25);
    const behindBlade = s.swingT > 0 && s.swingPlane === "horiz" && s.swingZ < -0.15;
    const spin = s.spin;
    if (spin) { ctx.save(); ctx.translate(X, Y - 9); ctx.rotate(spin); ctx.translate(-X, -(Y - 9)); }
    if (behindBlade) this.gun(s, X, Y, white);
    ctx.save();
    ctx.translate(X, Y);
    if (rot) ctx.rotate(rot);
    ctx.scale(s.face * sx * tkScale, sy * tkScale);
    this.body(s, bob, step, white, false);
    ctx.restore();
    // glowing golden meteor shock-cone around an Astartes plummeting in a Meteor Slam!
    if (s.dive && s.skin === ASTARTES) {
      ctx.save();
      ctx.strokeStyle = Math.sin(this.t * 60) > 0 ? "#ffffff" : "#ffd24a";
      ctx.globalAlpha = 0.78;
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(X, Y + 1, 11, 0.25, Math.PI - 0.25); ctx.stroke();
      ctx.restore();
    }
    if (s.hide) s.tip = null; // (tucked away, the weapon is held out of sight)
    else if (!behindBlade) this.gun(s, X, Y, white);
    if (spin) { ctx.restore(); s.tip = null; }
    this.drawHolo(s, false);
    if (s.shield > 0) {
      ctx.strokeStyle = TEAMS[s.team].color;
      ctx.globalAlpha = 0.35 + 0.3 * Math.sin(this.t * 12);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(X0 + 0.5, Y0 - 9.5, 14, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  /** the scarf: links that trail out behind the neck - a ribbon of dark squares with colour on top */
  private scarfDraw(s: Sol) {
    const P = opPal(s.team, s.skin);
    if (!P.scarf) return;
    const ctx = this.ctx, sc = s.scarf, pts: number[] = [];
    let qx = s.x - s.face * 3, qy = s.y - 11;
    for (let i = 0; i < 6; i += 2) {
      for (let k = 1; k <= 3; k++) pts.push(Math.round(qx + ((sc[i] - qx) * k) / 3) - this.cl, Math.round(qy + ((sc[i + 1] - qy) * k) / 3) - this.ct);
      qx = sc[i]; qy = sc[i + 1];
    }
    // a scarf is a thin ribbon; the capes of the skull and the shade are wide, with a hem of another colour
    const o = P.cape === 2 ? 3 : 2, n = P.cape === 2 ? 2 : 1;
    ctx.fillStyle = "#0a0a0f";
    for (let i = 0; i < pts.length; i += 2) ctx.fillRect(pts[i] - o, pts[i + 1] - o, o * 2, o * 2);
    for (let i = pts.length - 2; i >= 0; i -= 2) { ctx.fillStyle = i >= 12 ? P.scarf2 : P.scarf; ctx.fillRect(pts[i] - n, pts[i + 1] - n, n * 2, n * 2); }
  }

  /** the body in a frame whose origin is the feet (already flipped to face the aim): jetpack / Astartes Assault Jump-Pack, legs, cuirass, pauldrons & helm */
  private body(s: Sol, bob: number, step: number, white: boolean, dead: boolean) {
    const ctx = this.ctx, P = opPal(s.team, s.skin), tank = s.skin === ASTARTES;
    const R = (c: string, x: number, y: number, w: number, h: number) => { ctx.fillStyle = white ? "#ffffff" : c; ctx.fillRect(x, y, w, h); };
    if (tank) {
      // Iconic Warhammer Adeptus Astartes Twin-Turbine Assault Jump-Pack: towering ceramite intakes with Imperial gold trim & twin plasma nozzles!
      R(P.K, -14, -18 + bob, 9, 16);
      R(P.plate!, -13, -17 + bob, 7, 13);
      R(P.plateHi!, -13, -17 + bob, 2, 11);
      R(P.plateSh!, -8, -16 + bob, 2, 12);
      R(P.trim!, -13, -17 + bob, 7, 1);           // golden turbine crown
      R("#151822", -12, -15 + bob, 5, 2);          // upper turbine intake grille
      R(P.trim!, -13, -11 + bob, 7, 1);           // golden Imperial band
      R("#2a2e3c", -12, -8 + bob, 5, 2);           // reactor exhaust vents
      R(s.nosK > 0.3 ? "#8fe8ff" : s.fuel < 0.18 ? (Math.sin(this.t * 18) > 0 ? "#ff4d5e" : "#5a1a22") : "#7dff9a", -10, -10 + bob, 2, 1);
      // twin flared jump-pack nozzles
      R(P.K, -14, -3 + bob, 4, 3); R("#6b7388", -13, -2 + bob, 2, 2);
      R(P.K, -9, -3 + bob, 4, 3); R("#6b7388", -8, -2 + bob, 2, 2);
      if (!dead && s.jetK > 0.05) { this.flame(s, -12, bob); this.flame(s, -7, bob); }
      else if (!dead && !white && s.nosK > 0.15) this.nosFlame(s, bob);
    } else {
      R(P.K, -12, -14 + bob, 7, 12); R("#59617a", -11, -13 + bob, 5, 10); R("#8892ac", -11, -13 + bob, 2, 9); R("#c3cbe0", -11, -13 + bob, 1, 6); R("#3d4357", -7, -12 + bob, 1, 9);
      R(P.accent, -11, -9 + bob, 5, 1); R("#2a2e38", -11, -6 + bob, 5, 1);
      R(s.nosK > 0.3 ? "#8fe8ff" : s.fuel < 0.2 ? (Math.sin(this.t * 18) > 0 ? "#ff4d5e" : "#5a1a22") : "#7dff9a", -9, -12 + bob, 1, 1);
      R(P.K, -11, -3 + bob, 5, 3); R("#3a3f4a", -10, -3 + bob, 3, 1); R("#6b7388", -10, -2 + bob, 3, 1);
      if (!dead && s.jetK > 0.05) this.flame(s, -8, bob);
      else if (!dead && !white && s.nosK > 0.15) this.nosFlame(s, bob);
    }
    const moving = s.ground && Math.abs(s.vx) > 12, run = s.runK, nk = s.nosK;
    let f1x = 0, f1y = 0, f2x = 0, f2y = 0;
    if (!s.ground) {
      if (nk > 0.3) { f1x = -4; f1y = -1; f2x = -3; }
      else if (s.jet) { f1x = -1; f1y = -1; f2x = 1; f2y = -2; } // heroic assault jump-pack knee-tuck!
      else if (s.dive) { f1x = -2; f1y = -2; f2x = 2; f2y = 0; } // leading boot poised to crush the floor!
      else { f1x = -2; f2x = 2; f2y = -1; }
    } else if (s.skid > 0.3) { f1x = 3; f2x = 4; }
    else if (moving) {
      const ph = s.walkT * GAIT * (s.vx >= 0 ? 1 : -1) * s.face, S = 2 + 1.7 * run + 1.3 * nk, H = 1 + 1.5 * run + nk;
      f1x = Math.cos(ph) * S; f1y = -Math.max(0, -Math.sin(ph)) * H;
      f2x = -Math.cos(ph) * S; f2y = -Math.max(0, Math.sin(ph)) * H;
    } else if (s.duck > 0.5) { f1x = -1; f2x = 1; }
    const leg = (hx: number, fx: number, fy: number, far: boolean) => {
      const bx = Math.round(hx + fx), by = -1 + Math.round(fy), sx = Math.round(hx + fx * 0.6), sy = Math.min(-2, by - 1), tx = Math.round(hx + fx * 0.25), col = far ? P.legs2 : P.legs;
      if (tank) {
        // thick ceramite greaves, golden knee-cop & wide power-armoured sabaton boot
        R(P.K, tx - 2, -5, 6, 3); R(P.K, sx - 2, sy - 2, 6, 4); R(P.K, bx - 2, by - 1, 7, 3);
        R(col, tx - 1, -4, 4, 2); R(col, sx - 1, sy - 1, 4, 2);
        if (!far) { R(P.plateHi!, sx - 1, sy - 1, 1, 2); R(P.knee, sx + 1, sy - 1, 2, 1); }
        R(P.boots, bx - 1, by, 5, 1); R(P.toe, bx + 2, by, 2, 1);
        return;
      }
      R(P.K, tx - 1, -4, 4, 2); R(P.K, sx - 1, sy - 1, 4, 3); R(P.K, bx - 1, by - 1, 5, 2);
      R(col, tx, -3, 2, 1); R(col, sx, sy, 2, 1);
      if (!far) R(P.knee, sx + 1, sy, 1, 1);
      R(P.boots, bx, by, 3, 1); R(P.toe, bx + 2, by, 1, 1);
    };
    leg(tank ? -4 : -3, f1x, f1y, true); leg(tank ? 2 : 1, f2x, f2y, false);
    if (s.hide) for (const ax of tank ? [-9, 6] : [-7, 4]) { R(P.K, ax, -10 + bob, 4, 7); R(ax < 0 ? P.arm2 : P.arm, ax + 1, -9 + bob, 2, 5); }
    ctx.drawImage(opTorso(s.team, s.skin, white), tank ? -7 : -5, (tank ? -11 : -9) + bob);
    if (tank) {
      // colossal rounded Warhammer Space Marine ceramite pauldrons bordered in gleaming Imperial gold!
      const intact = !dead && s.armor > 0, flash = s.armorFx > 0.35;
      const rim = flash ? "#ffffff" : intact ? P.trim! : "#7a8298", bodyC = flash ? "#fff6c2" : P.plate!, hiC = flash ? "#ffffff" : P.plateHi!;
      for (const px of [-9, 4]) {
        R(P.K, px - 1, -13 + bob, 7, 6);
        R(rim, px, -12 + bob, 5, 4);
        R(bodyC, px, -12 + bob, 5, 3);
        R(hiC, px + 1, -12 + bob, 2, 2);
        if (intact) R("#ffffff", px + 2, -9 + bob, 1, 1); // gleaming golden pauldron stud
      }
    } else if (!dead && s.armor > 0) {
      const hi = s.armorFx > 0.4 ? "#ffffff" : "#e6edf7";
      for (const px of [-6, 3]) { R(P.K, px - 1, -10 + bob, 5, 3); R("#8e98b0", px, -9 + bob, 3, 2); R(hi, px, -9 + bob, 2, 1); R("#565d70", px + 2, -8 + bob, 1, 1); }
    }
    if (!s.headless) {
      const hx = s.recoil > 0.5 ? -1 : 0, hy = (tank ? -21 : -19) + bob + (s.reload > 0 ? 1 : 0) + (s.ouch > 0.2 ? 1 : 0) + (moving && run > 0.5 && Math.abs(step) > 0.93 ? 1 : 0);
      const ox = (tank ? -8 : -7) + hx;
      ctx.drawImage(opHead(s.team, s.skin, white), ox, hy);
      if (!white) this.face(s, ox, hy, dead);
    } else { R("#7a1420", -2, -10 + bob, 4, 2); R("#d04a4a", -1, -10 + bob, 2, 1); }
  }


  /** NOS on the ground: a flickering blade of blue fire straight out of the back of the pack */
  private nosFlame(s: Sol, bob: number) {
    if ((s.vx >= 0 ? 1 : -1) * s.face < 0) return; // (running backwards: only the sparks show)
    const ctx = this.ctx, L = Math.round((5 + (Math.sin(this.t * 53 + s.id) * 0.5 + 0.5) * 6) * s.nosK);
    for (let i = 0; i < L; i++) {
      const q = i / L, h = Math.max(1, Math.round(4 * (1 - q)));
      ctx.fillStyle = q < 0.3 ? "#ffffff" : q < 0.6 ? "#bff2ff" : q < 0.85 ? "#5fd8ff" : "#3a8cff";
      ctx.fillRect(-12 - i, -8 + bob - (h >> 1), 1, h);
    }
  }

  /** the jet: a flickering cone of fire out of the nozzle - white at the root, then yellow, then orange (blue and longer on NOS) - huge for a moment as it lights */
  private flame(s: Sol, nx: number, bob: number) {
    const ctx = this.ctx, fl = Math.sin(this.t * 47 + s.id * 3) * 0.5 + 0.5, sput = s.fuel < 0.16 && Math.sin(this.t * 31 + s.id) < 0 ? 0.35 : 1, nos = s.nosK > 0.3;
    const L = Math.round((8 + fl * 4 + s.burst * 30 + (nos ? 7 : 0)) * s.jetK * sput);
    const y0 = bob, big = s.burst > 0.05 || nos;
    const C = nos ? ["#3a8cff", "#2a5ad0", "#5fd8ff", "#4aa8ff", "#bff2ff", "#ffffff"] : ["#ff5a1e", "#b8361a", "#ffc23a", "#ff9a2a", "#ffe98a", "#fffaf0"];
    // vectored jet trail sweeps subtly back opposite your horizontal velocity!
    const vec = clamp((-s.vx * s.face) / 260, -0.45, 0.45);
    for (let i = 0; i < L; i++) {
      const q = i / L, w = Math.max(1, Math.round((big ? 7 : 5) * (1 - q * 0.8))), wob = Math.round(i * vec) + (q > 0.5 && Math.sin(this.t * 60 + i + s.id) > 0.6 ? 1 : 0);
      ctx.fillStyle = q < 0.65 ? C[0] : C[1];
      ctx.fillRect(nx - (w >> 1) + wob, y0 + i, w, 1);
      if (w > 2) { ctx.fillStyle = q < 0.5 ? C[2] : C[3]; ctx.fillRect(nx - ((w - 2) >> 1) + wob, y0 + i, w - 2, 1); }
      if (w > 4) { ctx.fillStyle = C[4]; ctx.fillRect(nx - ((w - 4) >> 1) + wob, y0 + i, w - 4, 1); }
      if (q < 0.45) { ctx.fillStyle = C[5]; ctx.fillRect(nx + wob, y0 + i, 1, 1); }
    }
    // shock diamonds: little white-hot knots strung down the core of the jet
    if (L > 6) for (const k of [0.22, 0.44, 0.66]) if (Math.sin(this.t * 38 + k * 20 + s.id) > -0.2) { ctx.fillStyle = "#ffffff"; ctx.fillRect(nx - 1, y0 + Math.round(L * k), 2, 1); ctx.fillRect(nx, y0 + Math.round(L * k) - 1, 1, 3); }
  }

  /**
   * Faces: eyes shut when hurt, narrowed when firing, wide when nearly dead, squeezed into a grin after a kill,
   * spinning when dizzy, X'd out when dead - and on visors, skulls and trooper lenses, the light does it instead.
   */
  private face(s: Sol, ox: number, oy: number, dead: boolean) {
    const E = EYES[s.skin] ?? EYES[0], P = opPal(s.team, s.skin), ctx = this.ctx, t = this.t, dark = "#1a1014";
    const Px = (c: string, x: number, y: number, w = 1, h = 1) => { ctx.fillStyle = c; ctx.fillRect(ox + x, oy + y, w, h); };
    // 7 dead, 1 hurt, 8 dizzy, 4 happy, 2 effort, 3 scared, 6 angry
    const mood = dead ? 7 : s.ouch > 0 ? 1 : s.dizzy > 0 ? 8 : s.joy > 0.3 ? 4 : s.recoil > 0.25 || s.swingT > 0 ? 2 : s.hp < 35 ? 3 : s.mad > 0 ? 6 : 0;
    const blink = mood === 0 && (t * 0.6 + s.id * 0.37) % 1 > 0.955;
    E.e.forEach((e, idx) => {
      const ex = e[0], ey = e[1], ew = e[2] ?? 2;
      if (E.kind === 0) {
        if (mood === 7) { Px(P.lid, ex, ey, 2, 1); Px(dark, ex - 1, ey - 1); Px(dark, ex + 1, ey - 1); Px(dark, ex, ey); Px(dark, ex - 1, ey + 1); Px(dark, ex + 1, ey + 1); }
        else if (mood === 1 || blink) { Px(P.lid, ex, ey, 2, 1); Px(dark, ex, ey, 2, 1); if (mood === 1) Px(dark, idx ? ex : ex + 1, ey - 1); }
        else if (mood === 4) { Px(P.lid, ex, ey, 2, 1); Px(dark, idx ? ex : ex + 1, ey - 1); Px(dark, idx ? ex + 1 : ex, ey); }
        else if (mood === 2 || mood === 6) { Px(P.lid, ex, ey); Px(dark, idx ? ex + 1 : ex - 1, ey - 1); Px(dark, ex, ey - 1); }
        else if (mood === 3) { Px("#ffffff", ex, ey, 2, 1); Px(dark, ex + (Math.sin(t * 20 + s.id) > 0 ? 1 : 0), ey); }
        else if (mood === 8) { Px("#ffffff", ex, ey, 2, 1); Px(dark, ex + (((t * 12) | 0) % 2), ey); }
      } else if (E.kind === 1) {
        if (mood === 7 || blink) Px(P.lid, ex, ey, ew, 1);
        else if (mood === 1) Px(Math.sin(t * 50) > 0 ? P.lid : "#ff6b6b", ex, ey, ew, 1);
        else if (mood === 4) { Px(P.lid, ex, ey, ew, 1); Px(P.glow, ex, ey - 1, ew, 1); }
        else if (mood === 2 || mood === 6) { Px("#ffffff", ex, ey, ew, 1); Px(P.accent, idx === 0 ? ex : ex + ew - 1, ey); }
        else if (mood === 3) { Px(P.lid, ex, ey, ew, 1); Px("#ffffff", ex + (ew >> 1), ey); }
        else if (mood === 8) { Px(P.lid, ex, ey, ew, 1); Px(P.glow, ex + (((t * 10) | 0) % ew), ey); }
      } else if (E.kind === 2) {
        if (mood === 7) { Px(P.skull, ex, ey); Px(P.skull, ex + 1, ey + 1); }
        else if (mood === 1) Px("#ff3a4a", ex, ey, 2, 2);
        else if (mood === 4) Px(P.skull, ex, ey + 1, 2, 1);
        else if (mood === 2 || mood === 6) Px(P.accent, idx ? ex : ex + 1, ey + 1);
        else if (mood === 3) Px("#ffffff", ex + 1, ey);
        else if (mood === 8) Px(P.accent, ex + (((t * 10) | 0) % 2), ey + (((t * 10 + 1) | 0) % 2));
      } else {
        if (mood === 7) { Px("#ffffff", ex + 2, ey); Px("#ffffff", ex + 1, ey + 1); Px("#ffffff", ex, ey + 2); }
        else if (mood === 1) Px("#ffffff", ex, ey, 3, 1);
        else if (mood === 2 || mood === 6) Px(P.accent, ex, ey + 1, 3, 1);
        else if (mood === 4) Px("#9fb4cc", ex, ey, 3, 1);
        else if (mood === 3) Px("#ffffff", ex + 1, ey + 1);
        else Px("#3c4860", ex + 1, ey);
      }
    });
    if (mood === 3 && !dead) {
      // a drop of sweat runs down the temple
      const k = (t * 1.6 + s.id * 0.3) % 1;
      Px("#8fd0ff", 12, 2 + Math.round(k * 5), 1, 2);
      Px("#ffffff", 12, 2 + Math.round(k * 5));
    }
  }

  /** the weapon in the hands: recoil & muzzle climb, visible reload, forged curved katana blade, lightsaber & upgraded muzzle flashes */
  private gun(s: Sol, X: number, Y: number, white: boolean) {
    const sl = s.slots[s.cur];
    if (!sl) return;
    const ctx = this.ctx, w = AWEP[sl.id], W = wspr(s.team, sl.id), img = white ? W.w : W.c, P = opPal(s.team, s.skin);
    const left = Math.cos(s.aim) < 0, sgn = left ? -1 : 1, saber = w.kind === "saber", katana = w.kind === "katana", chain = w.kind === "chainsword", blade = saber || katana || chain || w.kind === "axe";
    const small = sl.id === "pistol" || sl.id === "magnum";
    let ang = s.aim, ext = 0, magX = 0, magY = 0, magK = 0;
    let rc = Math.round(s.recoil * (w.kind === "rocket" ? 7 : sl.id === "sniper" ? 6 : sl.id === "shotgun" ? 7 : sl.id === "bolter" || sl.id === "magnum" ? 5 : 3));
    if (blade) {
      ang = this.bladeAng(s);
      ext = s.swingT > 0
        ? (s.swingPlane === "horiz" ? 3 + 6 * Math.abs(s.swingZ) : 2 + 5 * Math.sin((1 - s.swingT / s.swingDur) * Math.PI))
        : 2;
      rc = 0;
    } else if (s.reload > 0) {
      const p = 1 - s.reload / s.reloadMax, k = p < 0.15 ? p / 0.15 : p > 0.85 ? (1 - p) / 0.15 : 1;
      ang += sgn * (small ? -0.6 : 0.7) * k;
      if (sl.id === "magnum" && p > 0.86) ang += ((p - 0.86) / 0.14) * PI2 * sgn;
      if (sl.id === "shotgun") { if (p < 0.9) { magX = 6; magY = 3 + (1 - Math.min(1, ((p * 6.6) % 1) * 2.4)) * 5; magK = 1; } else rc += Math.round(3 * Math.sin(((p - 0.9) / 0.1) * Math.PI)); }
      else if (w.kind === "rocket") { if (p > 0.2 && p < 0.75) { magX = -4 - (1 - Math.min(1, (p - 0.2) / 0.4)) * 10; magY = -2; magK = 2; } }
      else {
        if (p > 0.3 && p < 0.72) { magX = sl.id === "bolter" ? 9 : sl.id === "rifle" ? 6 : sl.id === "e11" ? 7 : sl.id === "sniper" ? 5 : 1; magY = 3 + (1 - Math.min(1, (p - 0.3) / 0.3)) * 7; magK = sl.id === "bolter" ? 6 : sl.id === "rifle" ? 4 : sl.id === "e11" ? 5 : 3; }
        if (p > 0.72 && p < 0.8) rc -= 1;
        if (p > 0.86) rc += Math.round(3 * Math.sin(((p - 0.86) / 0.14) * Math.PI));
      }
    } else ang -= sgn * s.recoil * (small ? 0.5 : sl.id === "shotgun" ? 0.34 : 0.22);
    if (!blade && s.reload <= 0) ang -= sgn * 1.25 * s.holoK; // (behind the hologram shield the weapon is held upright against the chest)
    const horizDepthY = blade && s.swingT > 0 && s.swingPlane === "horiz" ? Math.round(s.swingZ * 2.6) : 0;
    const px = X + Math.round(Math.cos(s.aim) * 2), py = Y - 5 + horizDepthY + Math.round(s.duck * 2);
    // the arms: from the shoulders to the hands on the weapon - the far one to the hand that steadies it, the near one to the grip
    {
      const ca = Math.cos(ang), sa = Math.sin(ang), e2 = blade ? ext : 0, sy = Y - 8 + Math.round(s.duck * 3);
      const hand = (lx: number, ly: number): number[] => [px + ca * (lx + e2) - sa * ly * sgn, py + sa * (lx + e2) + ca * ly * sgn];
      const sup = blade ? hand(5, 1) : small || s.reload > 0 ? hand(4 - rc, 2) : hand(10 - rc, 0), grip = hand(2 - rc, 1);
      const tk = s.skin === ASTARTES;
      this.arm(X - s.face * (tk ? 4 : 3), sy, sup[0], sup[1], white ? "#ffffff" : P.arm2, P.K, white ? "#ffffff" : P.cuff, tk);
      this.arm(X + s.face * (tk ? 4 : 3), sy, grip[0], grip[1], white ? "#ffffff" : P.arm, P.K, white ? "#ffffff" : P.cuff, tk);
    }
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(ang);
    if (blade) {
      // the arm reaches out to the hilt: the blade never floats away from the body
      const al = Math.round(ext) + 1;
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(-1, -2, al + 2, 4);
      ctx.fillStyle = white ? "#ffffff" : P.arm; ctx.fillRect(0, -1, al, 2);
      ctx.translate(Math.round(ext), 0);
      s.tip = [px, py, ang, Math.round(ext) + W.c.width - W.px + 2];
    } else s.tip = null;
    if (left) ctx.scale(1, -1);
    ctx.drawImage(img, -W.px + 2 - rc, -W.py);
    // Adeptus Astartes CHAINSWORD: armoured crimson-gold blade shroud + hazard stripes + LIVE 60FPS SPINNING ADAMANTIUM SAW-TEETH!
    if (chain) {
      const bx = W.c.width - W.px + 1, bLen = Math.max(7, Math.round(CHAIN_L * s.swingScale));
      const rpm = s.swingT > 0 ? 78 : 34, phase = Math.floor(this.t * rpm + s.id) % 3;
      // chunky monomolecular blade housing & Imperial hazard stripes
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(bx - 1, -3, bLen + 3, 6);
      ctx.fillStyle = white ? "#ffffff" : (s.team ? "#b81e2c" : "#d83832"); ctx.fillRect(bx, -2, bLen, 3);
      ctx.fillStyle = white ? "#ffffff" : "#ffe26a"; ctx.fillRect(bx, -2, Math.max(2, bLen - 2), 1);
      if (!white) {
        for (let i = 1; i < bLen - 3; i += 4) {
          ctx.fillStyle = "#f5c542"; ctx.fillRect(bx + i, -1, 2, 1);
          ctx.fillStyle = "#161822"; ctx.fillRect(bx + i + 2, -1, 2, 1);
        }
        ctx.fillStyle = "#9aa4b8"; ctx.fillRect(bx, 0, bLen + 1, 1);
      }
      // live revolving jagged adamantium saw-teeth ripping around cutting edge, nose sprocket & spine!
      for (let i = 0; i < bLen; i++) {
        const toothOn = (i + phase) % 3 !== 2;
        if (toothOn) {
          ctx.fillStyle = "#0a0a0f"; ctx.fillRect(bx + i, 2, 2, 2);
          ctx.fillStyle = white || (s.swingT > 0 && (i + phase) % 2 === 0) ? "#ffffff" : (i + phase) % 3 === 0 ? "#fff6c2" : "#dfe6f0";
          ctx.fillRect(bx + i, 1, 1, 2);
        }
        if (i > bLen - 8 && ((bLen - i + phase) % 3 === 0)) {
          ctx.fillStyle = "#0a0a0f"; ctx.fillRect(bx + i, -4, 2, 1);
          ctx.fillStyle = "#ffffff"; ctx.fillRect(bx + i, -3, 1, 1);
        }
      }
      // spinning nose sprocket tip
      ctx.fillStyle = s.swingT > 0 || phase === 0 ? "#ffffff" : "#dfe6f0";
      ctx.fillRect(bx + bLen, phase === 1 ? -2 : -1, 2, 2);
    }
    // forged curved Katana steel blade (with 2.5D foreshortening during horizontal side-sweeps!)
    if (katana) {
      const bx = W.c.width - W.px + 1;
      const bLen = Math.max(6, Math.round(KATANA_L * s.swingScale));
      for (let i = 0; i < bLen; i++) {
        const q = i / bLen, curve = q > 0.7 ? -2 : q > 0.38 ? -1 : 0;
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(bx + i, curve - 2, 2, q > 0.86 ? 3 : 4);
      }
      for (let i = 0; i < bLen; i++) {
        const q = i / bLen, curve = q > 0.7 ? -2 : q > 0.38 ? -1 : 0;
        ctx.fillStyle = white ? "#ffffff" : "#8b9ab4";
        ctx.fillRect(bx + i, curve - 1, 1, 1);
        ctx.fillStyle = white ? "#ffffff" : (i % 4 === 0 || s.swingT > 0 ? "#ffffff" : "#e2f0ff");
        ctx.fillRect(bx + i, curve, 1, 1);
      }
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(bx + bLen, -2, 1, 1);
    }
    const hand = white ? "#ffffff" : P.hand;
    ctx.fillStyle = "#0a0a0f"; ctx.fillRect(-rc, -1, 4, 4);
    ctx.fillStyle = hand; ctx.fillRect(1 - rc, 0, 2, 2);
    if (blade) { ctx.fillStyle = "#0a0a0f"; ctx.fillRect(3, -1, 4, 4); ctx.fillStyle = hand; ctx.fillRect(4, 0, 2, 2); }
    if (magK) {
      const mx = Math.round(magX) - rc, my = Math.round(magY), hy = magK === 2 || magK === 1 ? 2 : 4;
      ctx.fillStyle = "#0a0a0f";
      if (magK === 1) { ctx.fillRect(mx - 1, my - 1, 5, 4); ctx.fillStyle = "#e0524a"; ctx.fillRect(mx, my, 3, 2); ctx.fillStyle = "#f1cf6a"; ctx.fillRect(mx, my, 1, 2); }
      else if (magK === 2) { ctx.fillRect(mx - 1, my - 1, 9, 5); ctx.fillStyle = "#566b3e"; ctx.fillRect(mx, my, 6, 3); ctx.fillStyle = "#e0483e"; ctx.fillRect(mx + 5, my, 2, 3); }
      else if (magK === 6) { ctx.fillRect(mx - 1, my - 1, 6, 8); ctx.fillStyle = "#2a2d38"; ctx.fillRect(mx, my, 4, 6); ctx.fillStyle = "#ffd24a"; ctx.fillRect(mx + 1, my, 3, 2); ctx.fillRect(mx + 2, my + 2, 2, 3); }
      else if (magK === 5) { ctx.fillRect(mx - 1, my - 1, 5, 7); ctx.fillStyle = "#2a2d38"; ctx.fillRect(mx, my, 3, 5); ctx.fillStyle = BEAM[s.team].col; ctx.fillRect(mx + 1, my + 1, 1, 3); }
      else { ctx.fillRect(mx - 1, my - 1, 5, 7); ctx.fillStyle = magK === 4 ? "#7a4a28" : "#3a3f4a"; ctx.fillRect(mx, my, 3, 5); ctx.fillStyle = "#f1cf6a"; ctx.fillRect(mx, my, 3, 1); }
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(mx - 1, my + hy, 4, 3);
      ctx.fillStyle = hand; ctx.fillRect(mx, my + hy, 2, 2);
    }
    if (!magK && !blade && !small) {
      const hx = s.reload > 0 ? 4 : 8 - (sl.id === "shotgun" && s.pump > 0 ? Math.round(Math.sin((1 - s.pump / 0.34) * Math.PI) * 3) : 0), hy = s.reload > 0 ? 1 : -1;
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(hx - rc, hy, 4, 3);
      ctx.fillStyle = hand; ctx.fillRect(hx + 1 - rc, hy, 2, 2);
    }
    if (w.kind === "flame" && !white) {
      // superheated blue pilot flame at nozzle
      const m = W.c.width - W.px + 2 - rc;
      ctx.fillStyle = Math.sin(this.t * 34 + s.id) > 0 ? "#5fb8ff" : "#b8eeff";
      ctx.fillRect(m, W.bar, 2, 1);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(m, W.bar, 1, 1);
    }
    if (s.flashT > 0 && !blade && w.kind !== "flame") {
      // upgraded weapon-specific muzzle flash star + muzzle-brake cross-vents!
      const m = W.c.width - W.px + 2 - rc, by = W.bar + 0.5, k = clamp(s.flashT / 0.07, 0, 1), sd = s.seed, laser = w.kind === "laser" || w.kind === "shock", B = w.kind === "shock" ? ELEC : BEAM[s.team];
      const L = (sl.id === "sniper" ? 28 : sl.id === "shotgun" ? 24 : sl.id === "bolter" ? 22 : w.kind === "rocket" || sl.id === "rifle" ? 16 : sl.id === "magnum" ? 19 : laser ? 14 : 11) * (0.78 + 0.45 * sd) * (0.45 + 0.55 * k);
      const Wd = (sl.id === "shotgun" ? 16 : sl.id === "bolter" ? 11 : sl.id === "sniper" ? 9 : sl.id === "magnum" ? 8 : w.kind === "rocket" ? 10 : 5.5) * (1.2 - 0.35 * sd);
      const star = (l: number, wd: number) => {
        ctx.beginPath();
        ctx.moveTo(m, by - wd * 0.32); ctx.lineTo(m + l * 0.28, by - wd); ctx.lineTo(m + l * 0.42, by - wd * 0.28); ctx.lineTo(m + l, by);
        ctx.lineTo(m + l * 0.42, by + wd * 0.28); ctx.lineTo(m + l * 0.28, by + wd); ctx.lineTo(m, by + wd * 0.32);
        ctx.closePath();
        ctx.fill();
      };
      ctx.fillStyle = laser ? B.col : "#ff8828"; star(L, Wd);
      ctx.fillStyle = laser ? B.hot : "#ffe868"; star(L * 0.78, Wd * 0.72);
      ctx.fillStyle = "#ffffff"; star(L * 0.5, Wd * 0.42);
      // muzzle-brake side gas jets on Bolter, Sniper & AK-47
      if (sl.id === "sniper" || sl.id === "rifle" || sl.id === "bolter") {
        const vL = (sl.id === "sniper" || sl.id === "bolter" ? 10 : 6) * k;
        ctx.fillStyle = "#ffe868"; ctx.fillRect(m - 1, by - vL, 2, vL * 2);
        ctx.fillStyle = "#ffffff"; ctx.fillRect(m - 1, by - vL * 0.55, 1, vL * 1.1);
      }
      if (w.kind === "rocket") { ctx.fillStyle = "#ffd75e"; ctx.fillRect(-W.px - 8 - rc, by - 4, 10, 8); ctx.fillStyle = "#ffffff"; ctx.fillRect(-W.px - 5 - rc, by - 2, 5, 4); }
    }
    ctx.restore();
  }

  /** over the head: "!" when they spot you, stars when dazed, sparkles after a kill, an angry vein, a panting breath, speed lines */
  private emotes(s: Sol, x: number, y: number) {
    const ctx = this.ctx, t = this.t;
    const P = (c: string, px: number, py: number, w = 1, h = 1) => this.R(c, px, py, w, h);
    const top = y - 38;
    if (s.alert > 0) { const b = Math.round(Math.abs(Math.sin(t * 14)) * 2); P("#0a0a0f", x - 2, top - 3 - b, 4, 9); P("#ffe45c", x - 1, top - 2 - b, 2, 4); P("#ffe45c", x - 1, top + 3 - b, 2, 2); }
    else if (s.dizzy > 0) for (let i = 0; i < 3; i++) { const a = t * 7 + i * 2.094; P(i ? "#ffe45c" : "#ffffff", x + Math.round(Math.cos(a) * 7), y - 21 + Math.round(Math.sin(a) * 2.5), 2, 2); }
    else if (s.joy > 0.3)
      for (let i = 0; i < 2; i++) {
        const k = (t * 2.2 + i * 0.5) % 1, sd = i ? 1 : -1;
        ctx.globalAlpha = 1 - k;
        P("#ffe45c", x + sd * (9 + Math.round(k * 4)), y - 16 - Math.round(k * 6), 2, 1);
        P("#ffe45c", x + sd * (10 + Math.round(k * 4)) - (sd > 0 ? 1 : 0), y - 17 - Math.round(k * 6), 1, 3);
        ctx.globalAlpha = 1;
      }
    if (s.mad > 0 && Math.sin(t * 14) > -0.3) { P("#ff3040", x + 5, y - 22, 1, 3); P("#ff3040", x + 4, y - 21, 3, 1); }
    if (s.hp < 30) { const k = (t * 1.5 + s.id * 0.37) % 1; ctx.globalAlpha = (1 - k) * 0.7; P("#ffffff", x + s.face * (7 + Math.round(k * 5)), y - 9 - Math.round(k * 3), 2 + Math.round(k * 2), 2); ctx.globalAlpha = 1; }
    if ((!s.ground && Math.hypot(s.vx, s.vy) > 150) || s.nosK > 0.5) {
      ctx.globalAlpha = 0.45;
      const dir = s.vx >= 0 ? -1 : 1;
      for (let i = 0; i < 2; i++) { const k = (t * 5 + i * 0.5) % 1; P("#ffffff", x + dir * (8 + Math.round(k * 8)), y - 12 + i * 6, 4 - Math.round(k * 3), 1); }
      ctx.globalAlpha = 1;
    }
  }
}
