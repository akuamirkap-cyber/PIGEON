import { SKINS } from "../game/defs";
import { LOOK_PAL, TEAM_PAL, fromMap, initSprites, mk, whiten } from "../game/sprites";
import { hsh } from "./maps";

/**
 * The operators of the duel arena. Every one of them has a head and a trunk of their own - the ninja's steel forehead plate and
 * studded gi, the tank's helmet and plate carrier, the horned oni with a glowing core, the skull's rib-cage, the veiled shade's
 * jewelled robe, the stormtrooper's white armour. The trunk is drawn without arms: the game draws those itself, from the shoulders
 * to the hands on whatever weapon is held - as it does the legs, the boots, the capes and the jetpacks.
 */
export const TROOPER = 5;
export const ASTARTES = 6;
export const ARENA_SKINS = [...SKINS, "TROOPER", "ASTARTES"];
export const SKIN_TAGS = ["NINJA", "TANK", "ONI", "TENGKORAK", "BAYANGAN", "IMPERIAL", "TANKER 40K"];

/** 14x10 heads, facing right (the eyes stay exactly where EYES says they are: the game animates them) */
const A_HEADS: string[][] = [
  // VIPER - a ninja's hood, a steel forehead protector with the team's emblem, a masked face
  [
    "....KKKKKK....", "..KKhhhHHHKK..", ".KhhhhHHHHHdK.", ".KhHHHHHHHHdK.", "KALLLLAALLLLaK",
    "KHMMMMMMMMMMdK", "KHMFFWKFFWKMdK", "KHMMMmmmmMMMdK", ".KdMMmmmmMMdK.", "..KKKKKKKKKK..",
  ],
  // BRICK - a steel helmet with the team's stripe, ear cups, a grinning bandana
  [
    "....KKKKKK....", "..KKllLLLlKK..", ".KlLLLLAALllK.", ".KGGGGGAAGGGK.", "KgGFFFFFFFFGgK",
    "KGFFWKFFFWKFGK", "KGFMMMMMMMMFGK", ".KMMAMMMMAMMK.", ".KMMMAAAAMMMK.", "..KKKKKKKKKK..",
  ],
  // ONI - a helmet with two horns, a glowing many-eyed visor, fangs on the mouth guard
  [
    "T...KKKKKK...T", "AAKKhhhHHHKKAA", ".KAHhhHHHHHAK.", ".KHhHHHAAHHdK.", "KHHHHHHAAHHHdK",
    "KHDDDDDDDDDDdK", "KHDVVDVVVDVVdK", "KHDDDDDDDDDDdK", ".KdHSGGGGSHdK.", "..KKKKKKKKKK..",
  ],
  // GHOST - a skull under a hood, the hood trimmed in the team's colour
  [
    "....KKKKKK....", "..KKhhHHHHKK..", ".KhhhhHHHHHdK.", ".KhHAAAAAAAdK.", "KHASSSSSSSSAdK",
    "KHSSKKSSSKKSdK", "KHSSKKSsSKKSdK", "KHdSsSSSSsSddK", ".KddSKSKSKSdK.", "..KKKKKKKKKK..",
  ],
  // SHADE - an ornate veil with a jewel at the brow, eyes of light
  [
    "....KKTTKK....", "..KKATVVTAKK..", ".KAaHHHHHHaAK.", ".KAHHhhHHHHAK.", "KTHHHHHHHHHHAK",
    "KAHDDDDDDDDHaK", "KAHDVVDDVVDHaK", "KAHDDDDDDDDHaK", ".KAaHDDDDHaAK.", "..KKKKKKKKKK..",
  ],
];
/**
 * 10x6 trunks (no arms): broad at the shoulders, narrow at the waist. A gi with steel studs and a sash; a plate carrier with
 * steel shoulder guards and a leather belt; a cuirass with a glowing core; a vest with a rib-cage on it; a robe with a gem clasp.
 */
const A_TORSOS: string[][] = [
  ["KHhbAAbhHK", "KhBbaAbBhK", ".KBLBBLBK.", ".KBbaAbBK.", ".KAAAAAAK.", ".KDBKKBDK."],
  ["KlLLllLLlK", "KLlGAAGlLK", ".KGgAAgGK.", ".KGGggGGK.", ".KRaAAaRK.", ".KDGKKGDK."],
  ["KAHhHHhHAK", "KaHhVVhHaK", ".KHDVVDHK.", ".KHAaaAHK.", ".KaAAAAaK.", ".KDHKKHDK."],
  ["KHHBSSBHHK", "KHhSsSsShK", ".KBSsSsBK.", ".KBsSSsBK.", ".KaAAAAaK.", ".KDBKKBDK."],
  ["KAAHHHHAAK", "KTaHVVHaTK", ".KHAHHAHK.", ".KHHAAHHK.", ".KTAAAATK.", ".KDHKKHDK."],
];
const T_HEAD = [
  "....KKKKKK....",
  "..KKWWWWWWKK..",
  ".KWWWWWWWWWSK.",
  ".KWWWAAAAWWSK.",
  "KWWWWWWWWWWWSK",
  "KWMMMWWWWMMMSK",
  "KWMMMMWWMMMMSK",
  "KSWMMSGGSMMWsK",
  ".KSWGMGGMGWsK.",
  "..KKKKKKKKKK..",
];
const T_TORSO = ["KAAWWWWWSK", "KAaWMMWWSK", ".KWMWWMSK.", ".KSWBBWSK.", ".KGGWWGGK.", ".KWBKKBWK."];
/** Adeptus Astartes Space Marine (16x11 Mk X/VII ceramite helm with golden skull crest, glowing visor lenses & vox-grille; 14x8 Imperial Aquila plastron + purity seal) */
const M_HEAD = [
  ".....KKKKKK.....",
  "...KKyYccCCKK...",
  "..KccCCCCCCCdK..",
  ".KccCCyYYyCCcdK.",
  "KccCCCCCCCCCCcdK",
  "KCCDDDDCCDDDDdGK",
  "KCCDVVDCCDVVDdGK",
  "KCcCCLLLLLLCCdGK",
  "KGGCLGKGGKGLCdGK",
  ".KdCCGKGGKGCddK.",
  "..KKKKKKKKKKKK..",
];
const M_TORSO = [
  "KKYccCCCCccYKK",
  "KCYyYWWYyYYCdK",
  "KCCyYYYYYYyCdK",
  "KcCCCyYYyCCCdK",
  ".KCCGMGGMGCCK.",
  ".KyyYYWWYYyyK.",
  ".KCCRKCCKCCdK.",
  ".KdCPK..KCCdK.",
];
const tpal = (team: number): Record<string, string> => ({
  K: "#0a0a0f", W: "#f2f5f9", S: "#cdd5df", s: "#98a2b0", M: "#15171e", G: "#5c6473", B: "#1c1f27", A: TEAM_PAL[team].A, a: TEAM_PAL[team].a,
});
/** Ultramarines cobalt-blue & Imperial gold for team 0; Blood Angels crimson & Imperial gold for team 1 */
const mpal = (team: number): Record<string, string> => (
  team
    ? { K: "#0a0a0f", C: "#c42032", c: "#ff5868", d: "#74101c", Y: "#ffe26a", y: "#c89020", W: "#f6f4ec", D: "#121a14", V: "#56ff96", L: "#9aa4b8", G: "#4c5468", M: "#1c202a", R: "#ffd24a", P: "#efe6cc" }
    : { K: "#0a0a0f", C: "#2258c8", c: "#5a96ff", d: "#123074", Y: "#ffe26a", y: "#c89020", W: "#f6f4ec", D: "#200b10", V: "#ff3348", L: "#9aa4b8", G: "#4c5468", M: "#1c202a", R: "#e02838", P: "#efe6cc" }
);
/** the team's colours, with steel (L, l) and a bright edge of the accent (T) for the duel skins */
const apal = (team: number): Record<string, string> => ({
  ...TEAM_PAL[team], L: team ? "#ecdcdd" : "#d5dcea", l: team ? "#b0949a" : "#8e98b0", T: team ? "#ffa3ad" : "#ffe9a0",
});
const cache: Record<string, HTMLCanvasElement> = {};
function part(kind: "h" | "t", team: number, skin: number, white: boolean): HTMLCanvasElement {
  const sk = skin >= 0 && skin <= ASTARTES ? skin : 0, key = `${kind}${team}${sk}${white ? "w" : ""}`;
  if (!cache[key]) {
    const rows = sk === ASTARTES ? (kind === "h" ? M_HEAD : M_TORSO) : sk === TROOPER ? (kind === "h" ? T_HEAD : T_TORSO) : (kind === "h" ? A_HEADS : A_TORSOS)[sk];
    const c = fromMap(rows, sk === ASTARTES ? mpal(team) : sk === TROOPER ? tpal(team) : apal(team));
    cache[key] = white ? whiten(c) : c;
  }
  return cache[key];
}
/** the head of an operator: 14x10 */
export function opHead(team: number, skin: number, white = false): HTMLCanvasElement { return part("h", team, skin, white); }
/** the trunk of an operator, without arms: 10x6 */
export function opTorso(team: number, skin: number, white = false): HTMLCanvasElement { return part("t", team, skin, white); }

/**
 * The colours a body is drawn with: trousers (near and far leg), knees, boots with a toe-cap, sleeves (near and far arm), hands;
 * what trails behind the neck (cape 0 nothing, 1 a scarf, 2 a wide cloak) and its two colours; what the face is made of; whether
 * the eyes glow in the dark.
 */
export interface OpPal {
  K: string; legs: string; legs2: string; knee: string; boots: string; toe: string; arm: string; arm2: string; cuff: string; hand: string;
  scarf: string; scarf2: string; cape: number; lid: string; glow: string; skull: string; accent: string; aura: boolean;
  /** heavy ceramite pauldron colours for Adeptus Astartes */
  plate?: string; plateHi?: string; plateSh?: string; trim?: string;
}
const palCache: Record<string, OpPal> = {};
export function opPal(team: number, skin: number): OpPal {
  const key = `${team}${skin}`;
  if (palCache[key]) return palCache[key];
  initSprites();
  const tp = TEAM_PAL[team], lp = LOOK_PAL[team][Math.min(skin, 4)];
  let p: OpPal;
  if (skin === ASTARTES)
    p = team
      ? { K: "#0a0a0f", legs: "#c42032", legs2: "#7c1220", knee: "#ffe26a", boots: "#8e1422", toe: "#ffe26a", arm: "#d6283c", arm2: "#861422", cuff: "#ffe26a", hand: "#c42032", scarf: "#1e1a26", scarf2: "#f5c542", cape: 2, lid: "#121a14", glow: "#56ff96", skull: "#f6f4ec", accent: "#ffe26a", aura: true, plate: "#c42032", plateHi: "#ff5e6e", plateSh: "#6e0e1a", trim: "#ffe26a" }
      : { K: "#0a0a0f", legs: "#2258c8", legs2: "#14347c", knee: "#ffe26a", boots: "#183e92", toe: "#ffe26a", arm: "#2e68de", arm2: "#163882", cuff: "#ffe26a", hand: "#2258c8", scarf: "#b81e2e", scarf2: "#ffe26a", cape: 2, lid: "#200b10", glow: "#ff3348", skull: "#f6f4ec", accent: "#ffe26a", aura: true, plate: "#2258c8", plateHi: "#66a0ff", plateSh: "#122e6e", trim: "#ffe26a" };
  else if (skin === TROOPER)
    p = { K: "#0a0a0f", legs: "#e6ebf1", legs2: "#bcc6d3", knee: "#ffffff", boots: "#1c1f27", toe: "#4a5060", arm: "#eef2f7", arm2: "#bcc6d3", cuff: "#2a2e3a", hand: "#1c1f27", scarf: "", scarf2: "", cape: 0, lid: "#15171e", glow: "#ffffff", skull: "#f2f5f9", accent: tp.A, aura: false };
  else {
    // the ninja and the oni trail a scarf, the tank nothing, the skull a tattered cape, the shade a cloak with a hem in the team's colour
    const cape = [1, 0, 1, 2, 2][skin] ?? 1;
    p = {
      K: lp.K, legs: skin === 1 ? tp.g : tp.b, legs2: skin === 1 ? tp.G : tp.B, knee: skin === 1 ? "#8a90a6" : tp.h, boots: tp.D, toe: tp.a,
      // (sleeves lighter than the trunk, so that the arms read against it - the tank's are bare steel - and at the wrist a cuff:
      // the ninja's steel bracers, a band in the team's colour for the tank, the oni and the shade, bone for the skull)
      arm: skin === 1 ? "#8e98b0" : team ? tp.h : "#666c8c", arm2: skin === 1 ? tp.g : team ? tp.b : tp.h,
      cuff: skin === 0 ? (team ? "#ecdcdd" : "#d5dcea") : skin === 3 ? tp.S : tp.A, hand: lp.F,
      scarf: cape === 0 ? "" : cape === 2 ? tp.H : lp.A, scarf2: cape === 2 ? (skin === 4 ? tp.A : tp.d) : lp.a, cape,
      lid: skin <= 1 ? tp.F : skin === 3 ? tp.S : tp.D, glow: tp.V, skull: tp.S, accent: tp.A, aura: skin >= 2,
    };
  }
  palCache[key] = p;
  return p;
}

/**
 * Where the eyes are on each head (top-left of a 14x10 head, facing right) and what they are made of:
 * 0 eyes with whites (a white pixel, then the pupil), 1 a glowing visor, 2 the sockets of a skull, 3 a trooper's lenses.
 * [x, y, width]
 */
export interface EyeDef { kind: 0 | 1 | 2 | 3; e: number[][] }
export const EYES: EyeDef[] = [
  { kind: 0, e: [[5, 6], [9, 6]] },
  { kind: 0, e: [[4, 5], [9, 5]] },
  { kind: 1, e: [[3, 6, 2], [10, 6, 2], [6, 6, 3]] },
  { kind: 2, e: [[4, 5], [9, 5]] },
  { kind: 1, e: [[4, 6, 2], [8, 6, 2]] },
  { kind: 3, e: [[2, 5], [9, 5]] },
  { kind: 1, e: [[4, 6, 2], [10, 6, 2]] },
];

const urls: Record<number, string> = {};
/** a portrait of an operator as they look in the duel (16x24, or 20x26 for the towering Astartes), for the menus */
export function opPortrait(skin: number): string {
  if (!urls[skin]) {
    if (skin === ASTARTES) {
      const [c, x] = mk(20, 26), P = opPal(0, ASTARTES);
      const R = (col: string, px: number, py: number, w: number, h: number) => { x.fillStyle = col; x.fillRect(px, py, w, h); };
      R("rgba(0,0,0,0.42)", 2, 24, 16, 2);
      // twin Astartes Assault Jump-Pack turbines rising over the shoulders
      for (const jx of [2, 14]) {
        R(P.K, jx, 6, 4, 8); R(P.plate!, jx + 1, 7, 2, 6); R(P.trim!, jx + 1, 7, 2, 1); R("#151822", jx + 1, 8, 2, 2); R(P.plateHi!, jx + 1, 10, 1, 2);
      }
      // crimson & gold commander cape
      R(P.K, 0, 13, 5, 11); R(P.scarf, 1, 14, 3, 9); R(P.scarf2, 1, 22, 3, 1);
      // heavy ceramite greaves, golden knee-guards & wide sabaton boots
      for (const lx of [5, 11]) {
        R(P.K, lx - 1, 19, 6, 6); R(P.legs, lx, 20, 4, 3); R(P.plateHi!, lx, 20, 1, 3); R(P.knee, lx + 1, 20, 2, 1);
        R(P.boots, lx, 23, 5, 1); R(P.toe, lx + 3, 23, 2, 1);
      }
      // power-armoured gauntlets
      for (const ax of [0, 16]) { R(P.K, ax, 14, 4, 8); R(ax < 8 ? P.arm2 : P.arm, ax + 1, 15, 2, 4); R(P.cuff, ax + 1, 19, 2, 1); R(P.hand, ax + 1, 20, 2, 1); }
      // broad Imperial Aquila cuirass
      x.drawImage(opTorso(0, ASTARTES), 3, 12);
      // colossal rounded ceramite pauldrons rimmed in Imperial gold
      for (const px of [0, 14]) {
        R(P.K, px, 10, 6, 6); R(P.trim!, px + 1, 11, 4, 4); R(P.plate!, px + 1, 11, 4, 3); R(P.plateHi!, px + 1, 11, 2, 2);
      }
      // Mk X Space Marine helmet
      x.drawImage(opHead(0, ASTARTES), 2, 1);
      urls[skin] = c.toDataURL();
      return urls[skin];
    }
    const [c, x] = mk(16, 24), P = opPal(0, skin);
    const R = (col: string, px: number, py: number, w: number, h: number) => { x.fillStyle = col; x.fillRect(px, py, w, h); };
    R("rgba(0,0,0,0.35)", 3, 22, 10, 2);
    // what trails behind the neck
    if (P.cape === 2) { R(P.K, 0, 12, 5, 10); R(P.scarf, 1, 13, 3, 8); R(P.scarf2, 1, 20, 3, 1); }
    else if (P.cape === 1) { R(P.K, 0, 12, 4, 6); R(P.scarf, 1, 13, 2, 2); R(P.scarf2, 0, 15, 2, 2); }
    // legs and boots
    for (const lx of [5, 9]) { R(P.K, lx - 1, 18, 4, 5); R(P.legs, lx, 19, 2, 2); R(P.knee, lx + 1, 19, 1, 1); R(P.K, lx + 2, 21, 2, 1); R(P.boots, lx, 21, 3, 1); R(P.toe, lx + 2, 21, 1, 1); }
    // the arms at the sides, the trunk between them, the head on top
    for (const ax of [1, 12]) { R(P.K, ax, 14, 3, 7); R(ax < 8 ? P.arm2 : P.arm, ax + 1, 15, 1, 3); R(P.cuff, ax + 1, 18, 1, 1); R(P.hand, ax + 1, 19, 1, 1); }
    x.drawImage(opTorso(0, skin), 3, 13);
    x.drawImage(opHead(0, skin), 1, 3);
    urls[skin] = c.toDataURL();
  }
  return urls[skin];
}

let tumble: HTMLCanvasElement | null = null, blob: HTMLCanvasElement | null = null;
/** a tumbleweed: a ball of dry tangled twigs */
export function tumbleSpr(): HTMLCanvasElement {
  if (!tumble) {
    const [c, g] = mk(15, 15);
    const cols = ["#8a6a3a", "#a8844a", "#6a4e2a", "#c4a060"];
    for (let i = 0; i < 90; i++) {
      const a = hsh(i, 1, 21) * Math.PI * 2, r = 2 + hsh(i, 2, 21) * 5;
      g.fillStyle = cols[i % 4];
      g.fillRect(Math.round(7 + Math.cos(a) * r), Math.round(7 + Math.sin(a) * r), 1, 1);
    }
    g.strokeStyle = "#7a5a30";
    g.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const a = hsh(i, 3, 21) * Math.PI * 2, b = a + 1.5 + hsh(i, 4, 21) * 2;
      g.beginPath(); g.moveTo(7.5 + Math.cos(a) * 6, 7.5 + Math.sin(a) * 6); g.lineTo(7.5 + Math.cos(b) * 6, 7.5 + Math.sin(b) * 6); g.stroke();
    }
    tumble = c;
  }
  return tumble;
}
/** a soft cloud of blowing sand */
export function blobSpr(): HTMLCanvasElement {
  if (!blob) {
    const [c, g] = mk(64, 64), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, "rgba(232,182,118,0.9)");
    gr.addColorStop(0.5, "rgba(222,168,104,0.45)");
    gr.addColorStop(1, "rgba(210,150,90,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    blob = c;
  }
  return blob;
}
