import type { ArenaMap, Decor } from "./maps";
import { forestRockAtlas } from "./forest";
import { WaterScene } from "./water";

type Ctx = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const hash = (x: number, y: number, seed = 0) => {
  let n = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 1442695041);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
};
const noise = (x: number, y: number, s: number) => {
  const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  return hash(ix, iy, s) * (1 - u) * (1 - v) + hash(ix + 1, iy, s) * u * (1 - v)
    + hash(ix, iy + 1, s) * (1 - u) * v + hash(ix + 1, iy + 1, s) * u * v;
};
const canvas = (w: number, h: number) => {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  return [c, c.getContext("2d")!] as const;
};
const rect = (g: Ctx, c: string, x: number, y: number, w: number, h: number) => {
  g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
};
function polygon(g: Ctx, c: string, points: number[][]) {
  g.fillStyle = c; g.beginPath();
  points.forEach(([x, y], i) => i ? g.lineTo(Math.round(x), Math.round(y)) : g.moveTo(Math.round(x), Math.round(y)));
  g.closePath(); g.fill();
}

let vista: HTMLImageElement | null = null;
export const crystalVistaUrl = () => new URL("images/crystal-sanctum.jpg", document.baseURI).href;
export function preloadHollow() {
  if (!vista && typeof Image !== "undefined") {
    vista = new Image(); vista.src = crystalVistaUrl();
  }
  return vista;
}

const mineral = [
  ["#244d66", "#398aa8", "#79cbdc", "#bce8ee", "#e5f8f7"],
  ["#403154", "#745697", "#b38ed9", "#dfc7ee", "#f0e8fa"],
  ["#62543b", "#9a8856", "#d3bc76", "#e9d6a3", "#f6ebc4"],
  ["#254d49", "#398b78", "#7ccdad", "#bce7ce", "#e4f8e7"],
];
const palette = (v: number) => mineral[v < 0.43 ? 0 : v < 0.82 ? 1 : v < 0.94 ? 3 : 2];
export const hollowAccent = (v: number) => palette(v)[2];

let atlas: { rgb: Uint8ClampedArray; glow: Uint8ClampedArray; veins: Uint8ClampedArray } | null = null;
export function hollowRockAtlas() {
  if (atlas) return atlas;
  const src = forestRockAtlas(), rgb = new Uint8ClampedArray(src.length), glow = new Uint8ClampedArray(512 * 256), veins = new Uint8ClampedArray(src.length);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 512; x++) {
    const p = y * 512 + x, i = p * 3;
    const n = noise(x / 43, y / 37, 41), grain = hash(x, y, 21) * 4;
    const shade = src[i] * 0.54 + grain;
    const lamina = Math.abs(Math.sin(y * 0.09 + x * 0.018 + n * 3.5));
    const geode = noise(x / 89, y / 71, 58);
    rgb[i] = 32 + shade * 0.96 + geode * 13;
    rgb[i + 1] = 25 + shade * 0.99 + n * 8;
    rgb[i + 2] = 48 + shade * 1.14 + geode * 8;
    if (lamina < 0.035 && n > 0.36) {
      rgb[i] += 16; rgb[i + 1] += 20; rgb[i + 2] += 24;
    }
    const seam = Math.abs(Math.sin(x * 0.032 - y * 0.052 + noise(x / 94, y / 87, 56) * 8));
    if (seam < 0.042 && noise(x / 48, y / 54, 92) > 0.55) {
      const violet = geode > 0.51;
      rgb[i] = violet ? 143 : 76; rgb[i + 1] = violet ? 104 : 160; rgb[i + 2] = violet ? 188 : 177;
      veins[i] = violet ? 189 : 109; veins[i + 1] = violet ? 139 : 217; veins[i + 2] = violet ? 242 : 226;
      glow[p] = seam < 0.014 ? 135 : 61;
    }
  }
  atlas = { rgb, glow, veins };
  return atlas;
}

function crystal(g: Ctx, x: number, y: number, h: number, w: number, lean: number, pal: string[], seed: number) {
  g.save(); g.translate(x, y); g.rotate(lean);
  polygon(g, "#172d37", [[-w * 0.52, 1], [-w * 0.62, -h * 0.73], [-w * 0.05, -h - 1], [w * 0.53, -h * 0.81], [w * 0.5, 1]]);
  polygon(g, pal[1], [[-w * 0.47, 0], [-w * 0.51, -h * 0.73], [0, -h], [w * 0.46, -h * 0.8], [w * 0.44, 0]]);
  polygon(g, pal[2], [[-w * 0.4, -1], [-w * 0.46, -h * 0.73], [0, -h + 1], [w * 0.02, -h * 0.72], [-w * 0.06, -1]]);
  polygon(g, pal[0], [[w * 0.02, -1], [w * 0.02, -h * 0.72], [w * 0.46, -h * 0.8], [w * 0.44, 0]]);
  polygon(g, pal[3], [[-w * 0.46, -h * 0.73], [0, -h], [w * 0.46, -h * 0.8], [w * 0.02, -h * 0.72]]);
  g.save();
  polygon(g, "rgba(221,247,235,0.12)", [[-w * 0.37, -h * 0.17], [-w * 0.42, -h * 0.64], [-w * 0.09, -h * 0.7], [-w * 0.14, -h * 0.21]]);
  polygon(g, "rgba(23,61,84,0.2)", [[-w * 0.44, -h * 0.54], [-w * 0.02, -h * 0.47], [-w * 0.05, -h * 0.36], [-w * 0.43, -h * 0.44]]);
  for (let j = 5; j < h * 0.73; j++) {
    const hue = hash(j, seed, 19), x0 = -w * 0.43 + hue * w * 0.4;
    g.globalAlpha = hue * 0.16;
    rect(g, hue > 0.48 ? pal[4] : pal[0], x0, -j, 1 + hash(j, seed, 18) * 3, 1);
  }
  g.restore();
  g.strokeStyle = pal[4]; g.lineWidth = 0.7; g.globalAlpha = 0.73;
  g.beginPath(); g.moveTo(-w * 0.06, -3); g.lineTo(w * 0.02, -h * 0.72); g.lineTo(0, -h + 1); g.stroke();
  g.globalAlpha = 0.25; g.lineWidth = 0.5;
  for (let i = 0; i < Math.floor(h / 10); i++) {
    const cy = -h * (0.1 + hash(i, seed, 4) * 0.7), cx = -w * 0.4 + hash(i, seed, 5) * w * 0.75;
    g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + w * 0.35, cy - 3); g.lineTo(cx + w * 0.48, cy - 9); g.stroke();
  }
  g.globalAlpha = 0.75;
  for (let i = 0; i < h / 6; i++) {
    const cy = -3 - hash(i, seed, 8) * h * 0.75, cx = -w * 0.36 + hash(i, seed, 9) * w * 0.25;
    rect(g, pal[3], cx, cy, 1, 1);
  }
  g.restore();
}

function crystalCluster(g: Ctx, x: number, y: number, h: number, seed: number, v: number, hanging = false) {
  const pal = palette(v), w = h * 0.24;
  g.save(); g.translate(x, y); if (hanging) g.scale(1, -1);
  crystal(g, -w * 0.7, 0, h * 0.56, w * 0.64, -0.31, pal, seed);
  crystal(g, w * 0.7, 0, h * 0.63, w * 0.73, 0.3, pal, seed + 13);
  crystal(g, -w * 0.3, 0, h * 0.8, w * 0.7, -0.12, pal, seed + 37);
  crystal(g, w * 0.26, 0, h, w, 0.06, pal, seed + 71);
  for (let i = 0; i < 9; i++) {
    const bx = (hash(i, seed, 20) - 0.5) * w * 3.2, sh = 2 + hash(i, seed, 21) * 4;
    polygon(g, i % 2 ? "#344d50" : "#253c43", [[bx - 4, 1], [bx - 2, -sh], [bx + 3, -sh * 0.7], [bx + 5, 1]]);
    if (i % 3 === 0) rect(g, "#577967", bx - 2, -sh, 4, 1);
  }
  g.restore();
}

// Short, bevel-tipped geodes echo the original pixel-art cave between larger quartz spires.
function classicCluster(g: Ctx, x: number, y: number, h: number, seed: number, v: number) {
  const pal = palette(v), scale = h / 23;
  g.save(); g.translate(x, y); g.scale(scale, scale);
  for (const [ox, height, width, lean] of [[-7, 10, 4, -0.22], [7, 11, 4, 0.2], [-3, 17, 5, -0.1], [3, 18, 5, 0.1], [0, 23, 6, 0]]) {
    const p = Math.abs(ox) === 7 && seed % 2 === 0 ? mineral[v < 0.43 ? 1 : 0] : pal;
    g.save(); g.translate(ox, 0); g.rotate(lean);
    polygon(g, "#232239", [[-width * 0.5 - 0.7, 1], [-width * 0.5 - 0.7, -height + 3], [-1, -height - 0.6], [1, -height - 0.6], [width * 0.5 + 0.7, -height + 3], [width * 0.5 + 0.7, 1]]);
    polygon(g, p[1], [[-width * 0.5, 0], [-width * 0.5, -height + 3], [-1, -height], [1, -height], [width * 0.5, -height + 3], [width * 0.5, 0]]);
    rect(g, p[3], -width * 0.5, -height + 3, 1.2, height - 3);
    rect(g, p[0], width * 0.5 - 1, -height + 3, 1, height - 3);
    rect(g, p[4], -1, -height, 2, 1);
    g.restore();
  }
  g.restore();
}

function glow(g: Ctx | null, x: number, y: number, r: number, color: string, alpha: number) {
  if (!g) return;
  g.save();
  const gr = g.createRadialGradient(x, y, 0, x, y, r);
  gr.addColorStop(0, color); gr.addColorStop(1, "rgba(80,160,180,0)");
  g.globalAlpha = alpha; g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  g.restore();
}

function fern(g: Ctx, x: number, y: number, h: number, seed: number) {
  for (let f = -3; f <= 3; f++) {
    const len = h * (1 - Math.abs(f) * 0.12), spread = f * 0.34;
    for (let j = 0; j < len; j++) {
      const q = j / len, px = x + spread * j, py = y - j + q * q * Math.abs(f) * 2;
      rect(g, f < 0 ? "#426f63" : "#31574f", px, py, 1, 1);
      if (j > 3 && j % 2 === 0) {
        const wing = Math.sin(q * Math.PI) * (1.5 + h * 0.07);
        rect(g, "#699c84", px - wing, py - 1, wing, 1);
        rect(g, "#3d756b", px + 1, py, wing, 1);
      }
      if (j > len - 2 && hash(f, seed, 10) > 0.6) rect(g, "#a7cbb6", px, py, 1, 1);
    }
  }
}

function mushroom(g: Ctx, x: number, y: number, h: number, seed: number, giant: boolean) {
  const w = giant ? h * 0.57 : h * 0.65;
  const violet = seed % 4 === 0;
  const cap = violet ? ["#433553", "#665579", "#9c83af", "#d8bfe3"] : ["#244755", "#376779", "#76aaba", "#bddbdc"];
  g.save();
  for (let j = 0; j < h; j++) {
    const bend = Math.sin(j / h * 3.8 + seed) * h * 0.035, thick = giant ? 4 + (1 - j / h) * h * 0.045 : 1;
    rect(g, "#314d50", x + bend - thick * 0.5, y - j, thick + 1, 1);
    rect(g, "#6f9991", x + bend - thick * 0.4, y - j, Math.max(1, thick * 0.4), 1);
    if (j % 11 === 0) rect(g, "#526f5e", x + bend, y - j, 2, 1);
  }
  if (giant) {
    for (const sd of [-1, 1]) {
      g.strokeStyle = "#41666a"; g.lineWidth = 2;
      g.beginPath(); g.moveTo(x, y - 11); g.quadraticCurveTo(x + sd * 5, y - 2, x + sd * 14, y); g.stroke();
      fern(g, x + sd * 11, y, 7, seed + sd);
    }
  }
  const cy = y - h;
  g.fillStyle = cap[0]; g.beginPath(); g.moveTo(x - w, cy + 2);
  g.bezierCurveTo(x - w * 0.85, cy - w * 0.55, x + w * 0.65, cy - w * 0.8, x + w, cy + 1);
  g.bezierCurveTo(x + w * 0.7, cy + w * 0.15, x - w * 0.6, cy + w * 0.2, x - w, cy + 2); g.fill();
  for (let j = -Math.floor(w); j < w; j++) {
    const q = j / w, top = Math.sqrt(Math.max(0, 1 - q * q)) * w * 0.43;
    for (let k = 0; k < top; k += 2) {
      const shade = hash(j, k, seed), col = k > top * 0.74 ? cap[2] : shade > 0.65 ? cap[1] : cap[0];
      rect(g, col, x + j, cy - k, 1, 2);
    }
    if (j % (giant ? 3 : 2) === 0) {
      g.strokeStyle = cap[3]; g.globalAlpha = 0.56; g.lineWidth = 0.6;
      g.beginPath(); g.moveTo(x + j, cy + 1); g.lineTo(x, cy + Math.abs(j) * 0.07 + 3); g.stroke(); g.globalAlpha = 1;
    }
  }
  for (let i = 0; i < (giant ? 28 : 4); i++) {
    const px = x + (hash(i, seed, 70) - 0.5) * w * 1.7, py = cy - hash(i, seed, 71) * w * 0.3;
    rect(g, i % 4 ? cap[2] : cap[3], px, py, giant ? 2 : 1, 1);
  }
  if (giant) {
    g.strokeStyle = "rgba(159,202,194,0.24)"; g.lineWidth = 0.7;
    for (let i = -5; i <= 5; i++) {
      g.beginPath(); g.moveTo(x + i * w * 0.08, cy - w * 0.4);
      g.quadraticCurveTo(x + i * w * 0.14, cy - w * 0.23, x + i * w * 0.18, cy); g.stroke();
    }
  }
  g.restore();
}

function runes(g: Ctx, x: number, y: number, seed: number, color: string, count: number) {
  g.save(); g.strokeStyle = color; g.lineWidth = 0.8;
  for (let i = 0; i < count; i++) {
    const yy = y + i * 6, rev = hash(i, seed, 33) > 0.5 ? 1 : -1;
    g.beginPath(); g.moveTo(x, yy); g.lineTo(x, yy + 4);
    g.moveTo(x - 2, yy + (rev > 0 ? 2 : 0)); g.lineTo(x, yy + (rev > 0 ? 0 : 2)); g.lineTo(x + 2, yy + (rev > 0 ? 2 : 0));
    if (i % 2) { g.moveTo(x, yy + 3); g.lineTo(x + rev * 2, yy + 4); }
    g.stroke();
  }
  g.restore();
}

function sanctuaryArch(g: Ctx, eg: Ctx | null, x: number, y: number, v: number, seed: number) {
  const accent = hollowAccent(v);
  for (const side of [-1, 1]) {
    const px = x + side * 17;
    rect(g, "#242039", px - 4, y - 4, 9, 4);
    rect(g, "#666078", px - 3, y - 3, 7, 3);
    rect(g, "#a397a9", px - 3, y - 3, 6, 1);
    rect(g, "#29253f", px - 3, y - 29, 7, 26);
    rect(g, "#625b78", px - 2, y - 28, 5, 25);
    rect(g, "#95899e", px - 2, y - 28, 1, 24);
    rect(g, "#a38a5b", px - 3, y - 30, 7, 2);
    rect(g, "#bda579", px - 2, y - 30, 5, 1);
    runes(g, px + 1, y - 25, seed, accent, 3);
    if (eg) runes(eg, px + 1, y - 25, seed, accent, 3);
    g.save(); g.strokeStyle = "#29243d"; g.lineWidth = 7;
    g.beginPath(); g.moveTo(px, y - 27); g.quadraticCurveTo(x + side * 17, y - 43, x, y - 54); g.stroke();
    g.strokeStyle = "#6a607d"; g.lineWidth = 5; g.stroke();
    g.strokeStyle = "#af9970"; g.lineWidth = 0.9; g.stroke();
    g.restore();
    for (let i = 0; i < 6; i++) {
      const t = i / 6, ax = x + side * 17 * (1 - t * t), ay = y - 30 - 23 * t;
      g.save(); g.translate(ax, ay); g.rotate(side * (0.1 + t * 0.6));
      rect(g, i % 2 ? "#91849b" : "#756a86", -2.5, -1, 5, 1); g.restore();
    }
    fern(g, px - side * 2, y, 7 + v * 3, seed);
  }
  polygon(g, "#b09a6e", [[x - 4, y - 54], [x, y - 59], [x + 4, y - 54], [x, y - 49]]);
  polygon(g, accent, [[x - 2, y - 54], [x, y - 57], [x + 2, y - 54], [x, y - 51]]);
  glow(eg, x, y - 54, 14, accent, 0.42);
}

const hollowKinds = new Set(["crystal", "bigcrystal", "ceilcrystal", "mycotree", "shroom", "cavefern", "vine", "glowlily", "stalag", "stalagmite", "gotharch", "runepillar", "monolith"]);
export function paintHollowDecor(g: Ctx, eg: Ctx | null, d: Decor): boolean {
  if (!hollowKinds.has(d.k)) return false;
  const x = d.x, y = d.y, seed = Math.floor(d.v * 4096), pal = palette(d.v);
  if (["crystal", "bigcrystal", "ceilcrystal"].includes(d.k)) {
    const hang = d.k === "ceilcrystal";
    const h = d.h || (d.k === "bigcrystal" ? 68 + d.v * 26 : hang ? 48 + d.v * 24 : 14 + d.v * 13);
    if (d.k === "crystal") classicCluster(g, x, y, h, seed, d.v);
    else {
      crystalCluster(g, x, y, h, seed, d.v, hang);
      if (!hang) classicCluster(g, x - h * 0.18, y, h * 0.27, seed + 7, d.v < 0.43 ? 0.65 : 0.2);
    }
    glow(eg, x, y + (hang ? 1 : -1) * h * 0.47, h * 0.62, pal[2], 0.36);
  } else if (d.k === "mycotree" || d.k === "shroom") {
    const giant = d.k === "mycotree", h = d.h || (giant ? 67 + d.v * 35 : 6 + d.v * 8);
    mushroom(g, x, y, h, seed, giant);
    if (giant) { mushroom(g, x - h * 0.3, y, h * 0.47, seed + 12, true); fern(g, x + h * 0.25, y, 17, seed); }
    glow(eg, x, y - h + 2, giant ? h * 0.5 : 12, "#67c7c6", giant ? 0.24 : 0.2);
  } else if (d.k === "cavefern" || d.k === "glowlily") {
    fern(g, x, y, 11 + d.v * 12, seed);
    if (d.k === "glowlily") {
      for (const sd of [-1, 1]) {
        g.strokeStyle = "#77917c"; g.lineWidth = 0.8; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + sd * 4, y - 10, x + sd * 5, y - 12); g.stroke();
        rect(g, "#afd4cf", x + sd * 5 - 1, y - 14, 3, 2);
        glow(eg, x + sd * 5, y - 13, 7, "#83d1cc", 0.22);
      }
    }
  } else if (d.k === "vine") {
    const h = d.h || 22;
    for (let j = 0; j < h; j++) {
      const px = x + Math.sin(j * 0.13 + d.v * 3) * 1.7;
      rect(g, "#3a6155", px, y + j, 1, 1);
      if (j % 5 === 0) { rect(g, "#4d8576", px - 1, y + j, 3, 1); rect(g, "#719c86", px + 1, y + j + 1, 2, 1); }
    }
    rect(g, "#a1d3cd", x, y + h, 1, 2); glow(eg, x, y + h, 9, "#80cecb", 0.18);
  } else if (d.k === "stalag" || d.k === "stalagmite") {
    const hang = d.k === "stalag", h = 5 + Math.round(d.v * (hang ? 9 : 8)), dir = hang ? 1 : -1;
    polygon(g, "#263b46", [[x - 4, y], [x + 4, y], [x + 1, y + h * dir]]);
    polygon(g, "#5c7278", [[x - 3, y], [x, y], [x + 1, y + h * dir]]);
    if (hang && d.v > 0.5) rect(g, "#a6d4d7", x + 1, y + h, 1, 1);
  } else if (d.k === "gotharch") {
    sanctuaryArch(g, eg, x, y, d.v, seed);
  } else {
    const h = d.k === "monolith" ? 42 : 33;
    rect(g, "#27233b", x - 7, y - 4, 15, 4);
    rect(g, "#80748e", x - 6, y - 3, 13, 1);
    polygon(g, "#383049", [[x - 5, y - 3], [x - 5, y - h + 3], [x - 2, y - h], [x + 4, y - h], [x + 5, y - h + 4], [x + 4, y - 3]]);
    rect(g, "#6f6382", x - 4, y - h + 3, 2, h - 7);
    rect(g, "#a18b5b", x - 5, y - h + 2, 11, 2);
    rect(g, "#a18b5b", x - 5, y - 7, 10, 1);
    runes(g, x + 1, y - h + 7, seed, pal[2], d.k === "monolith" ? 5 : 3);
    if (eg) runes(eg, x + 1, y - h + 7, seed, pal[2], d.k === "monolith" ? 5 : 3);
    crystal(g, x, y - h - 2, 8, 4, 0, pal, seed);
    glow(eg, x, y - h - 6, 18, pal[2], 0.34);
    fern(g, x - 3, y, 7, seed);
  }
  return true;
}

export function paintHollowCover(g: Ctx | null, eg: Ctx | null, k: string, x: number, y: number, part: number): boolean {
  if (!["boulder", "fern", "grove", "niche"].includes(k)) return false;
  if (!g) { if (part === 1) glow(eg, x, y - 10, 17, "#78bfc2", 0.22); return true; }
  if (part === 0) {
    if (k === "niche") { g.fillStyle = "#152b32"; g.beginPath(); g.ellipse(x, y - 7, 12, 13, 0, Math.PI, TAU); g.fill(); }
    else fern(g, x - 4, y, 17, 42);
  } else if (k === "boulder") {
    polygon(g, "#304c55", [[x - 12, y], [x - 11, y - 10], [x - 3, y - 14], [x + 9, y - 11], [x + 12, y]]);
    crystalCluster(g, x, y - 4, 14, 71, 0.2);
  } else if (k === "grove") {
    mushroom(g, x, y, 11, 12, false); mushroom(g, x - 8, y, 7, 42, false); mushroom(g, x + 8, y, 8, 23, false);
    fern(g, x - 8, y, 7, 14); fern(g, x + 7, y, 8, 15);
  } else {
    fern(g, x - 5, y, 13, 42); fern(g, x + 5, y, 12, 12); fern(g, x, y, 16, 17);
  }
  return true;
}

export class HollowScene extends WaterScene {
  private layers: HTMLCanvasElement;

  constructor(map: ArenaMap) {
    super(map, true);
    preloadHollow();
    const [layer, g] = canvas(map.w * 8, map.h * 8);
    for (let i = 0; i < 16; i++) {
      const x = i * 146 + hash(i, 1, 8) * 66, y = 520 + Math.sin(i * 1.2) * 35;
      g.globalAlpha = 0.25;
      crystalCluster(g, x, y, 80 + hash(i, 4, 12) * 90, i * 77, i % 5 === 0 ? 0.8 : 0.2);
      if (i % 5 === 0) mushroom(g, x - 40, y, 95, i + 3, true);
    }
    g.globalAlpha = 1;
    this.layers = layer;
  }

  drawBackground(g: Ctx, cl: number, ct: number, W: number, H: number, t: number) {
    const image = preloadHollow();
    g.fillStyle = "#202139"; g.fillRect(0, 0, W, H);
    if (image?.complete && image.naturalWidth > 0) {
      const s = Math.max(W / image.naturalWidth, H / image.naturalHeight) * 1.32;
      const dw = image.naturalWidth * s, dh = image.naturalHeight * s;
      const px = clamp(cl / Math.max(1, this.map.w * 8 - W), 0, 1);
      const py = clamp(0.17 + ct / 1400, 0, 1);
      g.save(); g.imageSmoothingEnabled = true;
      g.drawImage(image, -(dw - W) * (0.1 + px * 0.8), -(dh - H) * py, dw, dh); g.restore();
    }
    g.drawImage(this.layers, Math.round(-cl * 0.61), Math.round(164 - ct * 0.63));
    for (let i = 0; i < 4; i++) {
      const x = ((i * 183 + t * (2 + i * 0.5) - cl * 0.24) % (W + 300) + W + 300) % (W + 300) - 190;
      g.globalAlpha = 0.27;
      g.drawImage(this.mist, x, H * (0.45 + i * 0.11) + Math.sin(t * 0.25 + i) * 7, 310, 76);
    }
    g.globalAlpha = 1;
  }

  drawAtmosphere(g: Ctx, cl: number, ct: number, W: number, H: number, t: number) {
    g.save();
    g.globalCompositeOperation = "screen";
    for (const d of this.map.decor) {
      if (!["bigcrystal", "ceilcrystal", "mycotree"].includes(d.k)) continue;
      const h = d.h || 70, dir = d.k === "ceilcrystal" ? 1 : -1;
      const x = d.x - cl, y = d.y + dir * h * 0.72 - ct;
      if (x < -45 || x > W + 45 || y < -60 || y > H + 60) continue;
      const pulse = Math.pow(Math.max(0, Math.sin(t * 1.3 + d.x * 0.013)), 15);
      g.globalAlpha = pulse * 0.7;
      const col = hollowAccent(d.v);
      rect(g, col, x - 3, y, 7, 1); rect(g, "#e8e4f4", x, y - 3, 1, 7);
      glow(g, x, y, 17, col, pulse * 0.16);
    }
    for (const d of this.map.decor) {
      if (!["gotharch", "runepillar", "monolith"].includes(d.k)) continue;
      const x = d.x - cl, y = d.y - (d.k === "gotharch" ? 54 : d.k === "monolith" ? 48 : 39) - ct;
      if (x < -35 || x > W + 35 || y < -35 || y > H + 35) continue;
      const pulse = 0.45 + Math.sin(t * 1.5 + d.x * 0.023) * 0.18;
      glow(g, x, y, d.k === "gotharch" ? 21 : 17, hollowAccent(d.v), pulse * 0.18);
    }
    g.restore();
    g.save();
    const edgeShade = g.createRadialGradient(W * 0.5, H * 0.5, H * 0.27, W * 0.5, H * 0.5, Math.max(W, H) * 0.7);
    edgeShade.addColorStop(0, "rgba(13,10,30,0)"); edgeShade.addColorStop(1, "rgba(13,10,30,0.2)");
    g.fillStyle = edgeShade; g.fillRect(0, 0, W, H); g.restore();
    // Slow drifting mist and mineral motes are tied to world space, not HUD overlays.
    for (let i = 0; i < 22; i++) {
      const x = ((hash(i, 3, 17) * 1800 - cl * 0.86 + Math.sin(t * 0.5 + i) * 9) % (W + 40) + W + 40) % (W + 40) - 20;
      const y = ((hash(i, 8, 19) * 900 - ct * 0.86 - t * 2) % (H + 40) + H + 40) % (H + 40) - 20;
      g.globalAlpha = 0.2 + Math.max(0, Math.sin(t + i)) * 0.3;
      rect(g, i % 5 ? "#b1dedb" : "#e2d6a6", x, y, 1, 1);
    }
    g.globalAlpha = 1;
  }
}