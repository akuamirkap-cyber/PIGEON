import * as THREE from "three";

export const globalUniforms = {
  uTime: { value: 0 },
  uWind: { value: 1 },
  uTransl: { value: 1 },
};

interface WindOpts {
  bend: number; // trunk/crown sway factor (per m^2 of height)
  flutter: number; // leaf flutter amplitude
  grass?: boolean; // grass: sway weighted by uv.y
  transl?: number; // translucency
  ao?: boolean;
}

const RE_LINE = "RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );";

function windVertex(o: WindOpts) {
  return /* glsl */ `
    #include <begin_vertex>
    {
      vec3 instOrigin = vec3(0.0);
      #ifdef USE_INSTANCING
        instOrigin = instanceMatrix[3].xyz;
      #endif
      vec4 wo = modelMatrix * vec4(instOrigin, 1.0);
      float ph = dot(wo.xz, vec2(0.11, 0.073));
      float gust = 0.65 + 0.35 * sin(uTime * 0.31 + wo.x * 0.02) * sin(uTime * 0.17 + wo.z * 0.015);
      ${o.grass
        ? `float hgt = uv.y * uv.y;
           vec2 sway = vec2(sin(uTime * 1.6 + ph * 3.0 + wo.x * 0.4), cos(uTime * 1.3 + ph * 2.0 + wo.z * 0.4)) * 0.12 * hgt;
           transformed.xz += sway * uWind * gust;`
        : `float hgt = max(position.y, 0.0);
           float bend = hgt * hgt * ${o.bend.toFixed(6)};
           vec2 sway = vec2(sin(uTime * 0.9 + ph) + 0.4 * sin(uTime * 2.1 + ph * 2.3), cos(uTime * 0.7 + ph * 1.3)) * bend;
           transformed.xz += sway * uWind * gust;`}
      ${o.flutter > 0
        ? `float fl = sin(uTime * 7.0 + dot(position, vec3(2.1, 1.7, 2.9)) + ph * 4.0) * ${o.flutter.toFixed(4)};
           transformed += normal * fl * uWind * gust * (0.5 + 0.5 * sin(uTime*1.3 + position.x));`
        : ""}
    }
  `;
}

export function patchMaterial<T extends THREE.Material>(mat: T, o: WindOpts, extraUniforms?: Record<string, THREE.IUniform>) {
  const useAO = o.ao !== false;
  mat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, globalUniforms, extraUniforms || {});
    shader.vertexShader =
      `uniform float uTime;\nuniform float uWind;\n${useAO ? "attribute float aAO;\nvarying float vAO;\n" : ""}` +
      shader.vertexShader.replace("#include <begin_vertex>", windVertex(o) + (useAO ? "\nvAO = aAO;\n" : ""));
    if (shader.fragmentShader.includes("#include <map_fragment>")) {
      shader.fragmentShader =
        `uniform float uTransl;\n${useAO ? "varying float vAO;\n" : ""}` +
        shader.fragmentShader.replace(
          "#include <map_fragment>",
          `#include <map_fragment>\n${useAO ? "diffuseColor.rgb *= vAO;" : ""}`,
        );
      if (o.transl && o.transl > 0) {
        shader.fragmentShader = shader.fragmentShader.split(RE_LINE).join(
          `${RE_LINE}
          {
            float backL = saturate(-dot(geometryViewDir, directLight.direction));
            float tr = pow(backL, 4.0) * 1.6 + 0.35 * saturate(dot(-geometryNormal, directLight.direction)) + 0.08;
            reflectedLight.directDiffuse += directLight.color * diffuseColor.rgb * tr * uTransl * ${o.transl.toFixed(3)};
          }`,
        );
      }
    }
  };
  mat.customProgramCacheKey = () => `wind-${o.bend}-${o.flutter}-${o.grass ? 1 : 0}-${o.transl || 0}-${useAO}`;
  return mat;
}

export function foliageMaterial(map: THREE.Texture, o: { bend: number; flutter: number; transl: number; color?: THREE.ColorRepresentation; rough?: number }) {
  const m = new THREE.MeshStandardMaterial({
    map,
    color: o.color ?? 0xffffff,
    alphaTest: 0.42,
    side: THREE.DoubleSide,
    roughness: o.rough ?? 0.72,
    metalness: 0,
    alphaToCoverage: true,
    envMapIntensity: 0.55,
  });
  patchMaterial(m, { bend: o.bend, flutter: o.flutter, transl: o.transl });
  const depth = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map, alphaTest: 0.42, side: THREE.DoubleSide });
  patchMaterial(depth, { bend: o.bend, flutter: o.flutter, ao: false });
  return { mat: m, depth };
}

export function barkMaterial(map: THREE.Texture, normal: THREE.Texture, bend: number) {
  const m = new THREE.MeshStandardMaterial({
    map,
    normalMap: normal,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughness: 0.93,
    metalness: 0,
    envMapIntensity: 0.4,
  });
  patchMaterial(m, { bend, flutter: 0 });
  const depth = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking });
  patchMaterial(depth, { bend, flutter: 0, ao: false });
  return { mat: m, depth };
}

export function grassMaterial() {
  const m = new THREE.MeshStandardMaterial({
    vertexColors: true,
    side: THREE.DoubleSide,
    roughness: 0.62,
    metalness: 0,
    envMapIntensity: 0.6,
  });
  patchMaterial(m, { bend: 0, flutter: 0, grass: true, transl: 1.6, ao: true });
  return m;
}
