import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { mulberry32, rand } from "./noise";

export type GrassKind = "short" | "tall" | "meadow";

/**
 * Real 3D grass clump: individual tapered, curved blades with vertex colour gradient
 * (dark base -> sunlit tip), soft normals and AO.
 */
export function makeGrassClump(seed: number, kind: GrassKind): THREE.BufferGeometry {
  const r = mulberry32(seed);
  const P =
    kind === "short"
      ? { n: 30, h: [0.16, 0.42], w: [0.022, 0.036], lean: [0.15, 0.55], rad: 0.24 }
      : kind === "tall"
        ? { n: 22, h: [0.5, 1.0], w: [0.02, 0.032], lean: [0.45, 0.95], rad: 0.16 }
        : { n: 34, h: [0.22, 0.6], w: [0.016, 0.026], lean: [0.2, 0.7], rad: 0.28 };
  const segs = 3;
  const pos: number[] = [], nor: number[] = [], uv: number[] = [], col: number[] = [], ao: number[] = [], idx: number[] = [];
  const up = new THREE.Vector3(0, 1, 0);
  const baseC = new THREE.Color(0.025, 0.05, 0.012);
  const tips = [
    new THREE.Color(0.15, 0.3, 0.045),
    new THREE.Color(0.22, 0.36, 0.06),
    new THREE.Color(0.3, 0.36, 0.08),
    new THREE.Color(0.11, 0.24, 0.04),
  ];
  const dry = new THREE.Color(0.36, 0.27, 0.12);
  const c = new THREE.Vector3(), tan = new THREE.Vector3(), n = new THREE.Vector3(), p = new THREE.Vector3();
  for (let b = 0; b < P.n; b++) {
    const ang = rand(r, 0, Math.PI * 2);
    const d = Math.sqrt(r()) * P.rad;
    const base = new THREE.Vector3(Math.cos(ang) * d, -0.02, Math.sin(ang) * d);
    const la = ang + rand(r, -0.7, 0.7);
    const dirH = new THREE.Vector3(Math.cos(la), 0, Math.sin(la));
    const h = rand(r, P.h[0], P.h[1]) * (1 - (d / P.rad) * 0.35);
    const lean = rand(r, P.lean[0], P.lean[1]);
    const w = rand(r, P.w[0], P.w[1]);
    const tw = rand(r, -0.6, 0.6);
    const side = new THREE.Vector3(-dirH.z, 0, dirH.x).multiplyScalar(Math.cos(tw)).addScaledVector(dirH, Math.sin(tw)).normalize();
    const tip = tips[Math.floor(r() * tips.length)].clone();
    if (r() < 0.12) tip.lerp(dry, rand(r, 0.5, 1));
    tip.multiplyScalar(rand(r, 0.8, 1.2));
    const start = pos.length / 3;
    for (let s = 0; s <= segs; s++) {
      const t = s / segs;
      const bt = t * t;
      c.copy(base).addScaledVector(dirH, lean * h * bt).addScaledVector(up, h * t * (1 - 0.4 * lean * bt));
      tan.copy(dirH).multiplyScalar(2 * lean * h * t).addScaledVector(up, h * (1 - 1.2 * lean * t)).normalize();
      n.crossVectors(side, tan).normalize();
      if (n.y < 0) n.negate();
      n.addScaledVector(up, 0.6).normalize();
      const width = s === segs ? w * 0.06 : w * (1 - t * 0.7);
      const cc = baseC.clone().lerp(tip, Math.pow(t, 0.6));
      for (let k = 0; k < 2; k++) {
        p.copy(c).addScaledVector(side, (k - 0.5) * width);
        pos.push(p.x, p.y, p.z);
        nor.push(n.x, n.y, n.z);
        uv.push(k, t);
        col.push(cc.r, cc.g, cc.b);
        ao.push(0.3 + 0.7 * Math.pow(t, 0.8));
      }
    }
    for (let s = 0; s < segs; s++) {
      const a = start + s * 2;
      idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
  g.setAttribute("aAO", new THREE.Float32BufferAttribute(ao, 1));
  g.setIndex(idx);
  g.computeBoundingSphere();
  return g;
}

/** A small patch of several clumps (used in the asset viewer). */
export function makeGrassPatch(seed: number, kind: GrassKind, radius = 1.6, count = 40) {
  const r = mulberry32(seed + 99);
  const parts: THREE.BufferGeometry[] = [];
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  for (let i = 0; i < count; i++) {
    const g = makeGrassClump(seed * 31 + i, kind);
    const a = rand(r, 0, Math.PI * 2), d = Math.sqrt(r()) * radius;
    q.setFromEuler(new THREE.Euler(0, rand(r, 0, 6.28), 0));
    const sc = rand(r, 0.8, 1.4);
    s.set(sc, sc * rand(r, 0.85, 1.25), sc);
    m.compose(new THREE.Vector3(Math.cos(a) * d, 0, Math.sin(a) * d), q, s);
    g.applyMatrix4(m);
    parts.push(g);
  }
  return mergeGeometries(parts)!;
}
