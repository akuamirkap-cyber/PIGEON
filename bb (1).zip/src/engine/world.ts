import * as THREE from "three";
import type { TextureSet } from "./textures";
import type { AssetDef } from "./library";
import { createNoise2D, fbm, mulberry32, rand, smoothstep, lerp } from "./noise";
import { grassMaterial, globalUniforms } from "./materials";
import { makeGrassClump, type GrassKind } from "./grass";
import { createPropMaterials, buildBarrier, buildChevron, buildCurveMirror, type BarrierKind } from "./roadprops";

const V = THREE.Vector3;
export const ROAD_W = 7.2;

export interface WorldOptions {
  density: number; // trees multiplier
  grass: number; // grass multiplier
  shadowsOnBushes: boolean;
}

export interface RoadInfo {
  sd: number;
  y: number;
  idx: number;
}

export function createGroundMaterial(tex: TextureSet) {
  const tMat = new THREE.MeshStandardMaterial({
    map: tex.litter.map,
    normalMap: tex.litter.normal,
    normalScale: new THREE.Vector2(1.3, 1.3),
    roughness: 0.96,
    envMapIntensity: 0.35,
  });
  tMat.onBeforeCompile = (sh) => {
    sh.uniforms.mossMap = { value: tex.moss.map };
    sh.uniforms.mossNormal = { value: tex.moss.normal };
    sh.vertexShader = "attribute float aMoss;\nattribute float aAO;\nvarying float vMoss;\nvarying float vAO;\nvarying vec3 vWp;\n" +
      sh.vertexShader.replace("#include <begin_vertex>", "#include <begin_vertex>\nvMoss = aMoss; vAO = aAO; vWp = (modelMatrix * vec4(position,1.0)).xyz;");
    sh.fragmentShader = "uniform sampler2D mossMap;\nuniform sampler2D mossNormal;\nvarying float vMoss;\nvarying float vAO;\nvarying vec3 vWp;\n" +
      sh.fragmentShader
        .replace("#include <map_fragment>", `
          vec4 cL = texture2D(map, vMapUv);
          vec4 cL2 = texture2D(map, vMapUv * 0.27 + 0.31);
          vec4 cM = texture2D(mossMap, vMapUv * 0.8);
          float breakup = texture2D(mossMap, vWp.xz * 0.013).g;
          float m = smoothstep(0.25, 0.75, vMoss + (breakup - 0.22) * 1.6);
          vec4 lit = mix(cL, cL2, 0.35);
          diffuseColor *= mix(lit, cM, m);
          diffuseColor.rgb *= vAO;
        `)
        .replace("#include <normal_fragment_maps>", `
          vec3 mapN = mix(texture2D(normalMap, vNormalMapUv).xyz, texture2D(mossNormal, vNormalMapUv * 0.8).xyz, m) * 2.0 - 1.0;
          mapN.xy *= normalScale;
          normal = normalize(tbn * mapN);
        `);
  };
  return tMat;
}

export function buildWorld(scene: THREE.Scene, tex: TextureSet, lib: AssetDef[], opts: WorldOptions) {
  const group = new THREE.Group();
  scene.add(group);
  const noise = createNoise2D(7);
  const noise2 = createNoise2D(19);

  // ---------------- ROAD CURVE ----------------
  const ctrl: [number, number, number][] = [
    [2, 150, 2.5], [3, 100, 1.6], [0, 50, 0.6], [0, 0, 0], [-9, -48, -0.6], [5, -96, -1.4], [27, -138, -2],
    [27, -188, -1.2], [0, -236, 0.4], [-27, -284, 1.8], [-22, -342, 3], [8, -394, 3.2], [18, -452, 2.4], [14, -500, 2],
  ];
  const curve = new THREE.CatmullRomCurve3(ctrl.map(([x, z, y]) => new V(x, y, z)), false, "catmullrom", 0.5);
  const N = 1000;
  const S = curve.getSpacedPoints(N);
  const T = S.map((_, i) => curve.getTangentAt(i / N).normalize());
  const R = T.map((t) => new V(-t.z, 0, t.x).normalize()); // right vector (horizontal)
  const roadLen = curve.getLength();

  const pointAtRaw = (i: number, lat: number) => S[i].clone().addScaledVector(R[i], lat);
  const findIdx = (z: number) => {
    // samples have monotonically decreasing z
    let lo = 0, hi = N;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (S[mid].z > z) lo = mid; else hi = mid;
    }
    return lo;
  };
  const roadInfo = (x: number, z: number): RoadInfo => {
    const c = findIdx(z);
    let best = 0, bd = Infinity;
    for (let i = Math.max(0, c - 200); i <= Math.min(N, c + 200); i += 6) {
      const dx = x - S[i].x, dz = z - S[i].z;
      const d = dx * dx + dz * dz;
      if (d < bd) { bd = d; best = i; }
    }
    for (let i = Math.max(0, best - 7); i <= Math.min(N, best + 7); i++) {
      const dx = x - S[i].x, dz = z - S[i].z;
      const d = dx * dx + dz * dz;
      if (d < bd) { bd = d; best = i; }
    }
    const s = S[best], r = R[best];
    return { sd: (x - s.x) * r.x + (z - s.z) * r.z, y: s.y, idx: best };
  };

  const heightFromInfo = (x: number, z: number, info: RoadInfo) => {
    const a = Math.abs(info.sd);
    const side = info.sd > 0 ? info.sd * 0.4 * smoothstep(3, 14, a) : info.sd * 0.14 * smoothstep(3, 14, a);
    const hills = (fbm(noise, x * 0.009, z * 0.009, 4) * 11 + fbm(noise2, x * 0.05, z * 0.05, 3) * 1.6) * smoothstep(4, 28, a);
    const bumps = noise2(x * 0.35, z * 0.35) * 0.14 * smoothstep(4.5, 8, a);
    const natural = info.y + side + hills + bumps;
    return lerp(info.y - 0.1, natural, smoothstep(ROAD_W / 2 + 0.25, ROAD_W / 2 + 3.5, a));
  };
  const groundHeight = (x: number, z: number) => heightFromInfo(x, z, roadInfo(x, z));

  // ---------------- TERRAIN ----------------
  const TW = 380, TD = 700, segX = 220, segZ = 400;
  const tGeo = new THREE.PlaneGeometry(TW, TD, segX, segZ);
  tGeo.rotateX(-Math.PI / 2);
  tGeo.translate(0, 0, -175);
  const tp = tGeo.attributes.position as THREE.BufferAttribute;
  const tuv = tGeo.attributes.uv as THREE.BufferAttribute;
  const moss = new Float32Array(tp.count);
  const aoT = new Float32Array(tp.count);
  for (let i = 0; i < tp.count; i++) {
    const x = tp.getX(i), z = tp.getZ(i);
    const info = roadInfo(x, z);
    const h = heightFromInfo(x, z, info);
    tp.setY(i, h);
    tuv.setXY(i, x / 4, z / 4);
    const a = Math.abs(info.sd);
    const n = fbm(noise2, x * 0.04, z * 0.04, 3) * 0.5 + 0.5;
    moss[i] = Math.min(1, smoothstep(6, 20, a) * (0.25 + n * 0.9));
    aoT[i] = 0.75 + 0.25 * smoothstep(4, 12, a);
  }
  tGeo.setAttribute("aMoss", new THREE.BufferAttribute(moss, 1));
  tGeo.setAttribute("aAO", new THREE.BufferAttribute(aoT, 1));
  tGeo.computeVertexNormals();
  const tMat = createGroundMaterial(tex);
  tMat.color.set("#c8b8a6");
  const terrain = new THREE.Mesh(tGeo, tMat);
  terrain.receiveShadow = true;
  group.add(terrain);

  // ---------------- ROAD ----------------
  const across = 10;
  const rPos: number[] = [], rUv: number[] = [], rIdx: number[] = [];
  let dist = 0;
  for (let i = 0; i <= N; i++) {
    if (i > 0) dist += S[i].distanceTo(S[i - 1]);
    for (let j = 0; j <= across; j++) {
      const u = j / across;
      const off = (u - 0.5) * ROAD_W;
      const crown = 0.06 * (1 - Math.pow(2 * u - 1, 2));
      const p = S[i].clone().addScaledVector(R[i], off);
      p.y += crown + 0.02;
      rPos.push(p.x, p.y, p.z);
      rUv.push(u, dist / 14);
    }
  }
  for (let i = 0; i < N; i++) for (let j = 0; j < across; j++) {
    const a = i * (across + 1) + j, b = a + across + 1;
    rIdx.push(a, a + 1, b, a + 1, b + 1, b);
  }
  const rGeo = new THREE.BufferGeometry();
  rGeo.setAttribute("position", new THREE.Float32BufferAttribute(rPos, 3));
  rGeo.setAttribute("uv", new THREE.Float32BufferAttribute(rUv, 2));
  rGeo.setIndex(rIdx);
  rGeo.computeVertexNormals();
  const rMat = new THREE.MeshStandardMaterial({
    map: tex.asphalt.map,
    normalMap: tex.asphalt.normal,
    normalScale: new THREE.Vector2(0.9, 0.9),
    roughnessMap: tex.asphalt.rough,
    roughness: 1,
    metalness: 0,
    envMapIntensity: 0.8,
    color: "#d8d8d8",
  });
  const road = new THREE.Mesh(rGeo, rMat);
  road.receiveShadow = true;
  group.add(road);

  // concrete U-gutter on uphill (right) side
  const prof: [number, number][] = [[0, 0.02], [0.1, 0.02], [0.18, -0.2], [0.46, -0.2], [0.54, 0.06], [0.72, 0.06]];
  const gPos: number[] = [], gIdx: number[] = [], gUv: number[] = [];
  for (let i = 0; i <= N; i++) {
    for (let j = 0; j < prof.length; j++) {
      const p = S[i].clone().addScaledVector(R[i], ROAD_W / 2 + prof[j][0]);
      p.y += prof[j][1];
      gPos.push(p.x, p.y, p.z);
      gUv.push(j / prof.length, i * 0.05);
    }
  }
  for (let i = 0; i < N; i++) for (let j = 0; j < prof.length - 1; j++) {
    const a = i * prof.length + j, b = a + prof.length;
    gIdx.push(a, a + 1, b, a + 1, b + 1, b);
  }
  const gGeo = new THREE.BufferGeometry();
  gGeo.setAttribute("position", new THREE.Float32BufferAttribute(gPos, 3));
  gGeo.setAttribute("uv", new THREE.Float32BufferAttribute(gUv, 2));
  gGeo.setIndex(gIdx);
  gGeo.computeVertexNormals();
  const gutter = new THREE.Mesh(gGeo, new THREE.MeshStandardMaterial({ color: "#8f8c82", roughness: 0.95, map: tex.moss.map, normalMap: tex.asphalt.normal }));
  (gutter.material as THREE.MeshStandardMaterial).color.set("#c9c6bc");
  gutter.receiveShadow = true;
  group.add(gutter);

  // ---------------- VEGETATION PLACEMENT ----------------
  const rng = mulberry32(2024);
  const CHUNKS = 10;
  const chunkOf = (idx: number) => Math.min(CHUNKS - 1, Math.floor((idx / (N + 1)) * CHUNKS));
  type Inst = { m: THREE.Matrix4; c: THREE.Color };
  const buckets = new Map<string, Inst[]>(); // key def|variant|chunk
  const push = (def: string, v: number, chunk: number, inst: Inst) => {
    const k = `${def}|${v}|${chunk}`;
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k)!.push(inst);
  };
  const defMap = new Map(lib.map((d) => [d.id, d]));
  const pick = (w: [string, number][]) => {
    const tot = w.reduce((s, x) => s + x[1], 0);
    let t = rng() * tot;
    for (const [id, p] of w) { if ((t -= p) <= 0) return id; }
    return w[0][0];
  };
  const q = new THREE.Quaternion(), sc = new V(), pos = new V(), e = new THREE.Euler();
  const qLean = new THREE.Quaternion();
  const place = (id: string, x: number, z: number, info: RoadInfo, scale: number, tilt = 0.04, lean = 0) => {
    const def = defMap.get(id)!;
    const v = Math.floor(rng() * def.variants);
    pos.set(x, heightFromInfo(x, z, info) - 0.05, z);
    e.set(rand(rng, -tilt, tilt), rand(rng, 0, Math.PI * 2), rand(rng, -tilt, tilt));
    q.setFromEuler(e);
    if (lean > 0) {
      // lean toward the road -> canopy closes over the asphalt like the reference
      const toRoad = R[info.idx].clone().multiplyScalar(-Math.sign(info.sd));
      const axis = new V(0, 1, 0).cross(toRoad).normalize();
      qLean.setFromAxisAngle(axis, lean);
      q.premultiply(qLean);
    }
    sc.setScalar(scale);
    const m = new THREE.Matrix4().compose(pos, q, sc);
    const c = new THREE.Color(rand(rng, 0.86, 1.06), rand(rng, 0.9, 1.08), rand(rng, 0.8, 1.0));
    push(id, v, chunkOf(info.idx), { m, c });
  };

  const camSpots = [pointAtRaw(212, -4.4), pointAtRaw(228, -4.9), pointAtRaw(250, 0)];
  const inside = (x: number, z: number) =>
    Math.abs(x) < TW / 2 - 4 && z < 170 - 4 && z > -525 + 4 && camSpots.every((c) => (c.x - x) ** 2 + (c.z - z) ** 2 > 56);

  // canopy trees
  const cell = 5.6 / Math.sqrt(opts.density);
  for (let z = 168; z > -522; z -= cell) {
    for (let x = -TW / 2; x < TW / 2; x += cell) {
      const px = x + rand(rng, 0, cell), pz = z - rand(rng, 0, cell);
      if (!inside(px, pz)) continue;
      const info = roadInfo(px, pz);
      const a = Math.abs(info.sd);
      if (a < ROAD_W / 2 + 2.0 || a > 64) continue;
      if (rng() > (a > 40 ? 0.6 : 0.78)) continue;
      const n = noise(px * 0.018, pz * 0.018);
      let id: string;
      if (a < 15) id = pick([["maple", 0.26 + n * 0.1], ["sapling", 0.18], ["beech", 0.14], ["cedar", 0.24], ["pole", 0.18]]);
      else if (n > 0.35) id = pick([["beech", 0.35], ["maple", 0.25], ["cedar", 0.25], ["cypress", 0.15]]);
      else id = pick([["cedar", 0.4], ["pole", 0.32], ["cypress", 0.16], ["beech", 0.06], ["maple", 0.06]]);
      place(id, px, pz, info, rand(rng, 0.82, 1.15), 0.04, a < 12 ? rand(rng, 0.02, 0.07) : 0);
    }
  }
  // roadside canopy row: big broadleaf trees hugging both edges, leaning in
  for (let i = 0; i <= N; i += Math.max(4, Math.round(8 / Math.sqrt(opts.density)))) {
    for (const side of [-1, 1]) {
      if (rng() < 0.18) continue;
      const a = ROAD_W / 2 + rand(rng, 2.0, 5.5);
      const j = Math.min(N, i + Math.floor(rand(rng, 0, 4)));
      const px = S[j].x + R[j].x * a * side, pz = S[j].z + R[j].z * a * side;
      if (!inside(px, pz)) continue;
      const info = roadInfo(px, pz);
      const id = pick([["maple", 0.38], ["beech", 0.42], ["sapling", 0.2]]);
      place(id, px, pz, info, rand(rng, 0.95, 1.3), 0.03, rand(rng, 0.04, 0.13));
    }
  }
  // far band: sparse conifers on distant slopes
  const cellF = 9 / Math.sqrt(opts.density);
  for (let z = 168; z > -522; z -= cellF) {
    for (let x = -TW / 2; x < TW / 2; x += cellF) {
      const px = x + rand(rng, 0, cellF), pz = z - rand(rng, 0, cellF);
      if (!inside(px, pz)) continue;
      const info = roadInfo(px, pz);
      const a = Math.abs(info.sd);
      if (a <= 64 || a > 150 || rng() > 0.75) continue;
      place(pick([["cedar", 0.5], ["pole", 0.3], ["cypress", 0.2]]), px, pz, info, rand(rng, 0.9, 1.2));
    }
  }
  // understory saplings near road
  const cell2 = 7 / Math.sqrt(opts.density);
  for (let z = 168; z > -522; z -= cell2) {
    for (let x = -60; x < 60; x += cell2) {
      const px = x + rand(rng, 0, cell2), pz = z - rand(rng, 0, cell2);
      if (!inside(px, pz)) continue;
      const info = roadInfo(px, pz);
      const a = Math.abs(info.sd);
      if (a < ROAD_W / 2 + 1.6 || a > 26 || rng() > 0.55) continue;
      place(rng() < 0.6 ? "sapling" : "maple", px, pz, info, rand(rng, 0.6, 1.0), 0.08);
    }
  }
  // bushes
  const cell3 = 2.6 / Math.sqrt(opts.density);
  for (let z = 168; z > -522; z -= cell3) {
    for (let x = -70; x < 70; x += cell3) {
      const px = x + rand(rng, 0, cell3), pz = z - rand(rng, 0, cell3);
      if (!inside(px, pz)) continue;
      const info = roadInfo(px, pz);
      const a = Math.abs(info.sd);
      if (a < ROAD_W / 2 + 1.1 || a > 50) continue;
      const pr = a < 9 ? 0.4 : 0.26;
      if (rng() > pr) continue;
      const n = noise2(px * 0.05, pz * 0.05);
      const id = n > 0.2 ? pick([["sasa", 0.7], ["fern", 0.3]]) : pick([["sasa", 0.35], ["shrub", 0.35], ["fern", 0.3]]);
      place(id, px, pz, info, rand(rng, 0.7, 1.3), 0.12);
    }
  }

  // build instanced meshes
  const geoCache = new Map<string, ReturnType<AssetDef["make"]>>();
  const getAsset = (def: AssetDef, v: number) => {
    const k = `${def.id}|${v}`;
    if (!geoCache.has(k)) geoCache.set(k, def.make(1000 + v * 97 + def.id.length * 13));
    return geoCache.get(k)!;
  };
  let treeCount = 0;
  for (const [key, list] of buckets) {
    const [id, vs] = key.split("|");
    const def = defMap.get(id)!;
    const asset = getAsset(def, Number(vs));
    const isBush = def.category === "Semak & Tanaman Bawah";
    if (!isBush) treeCount += list.length;
    const lm = new THREE.InstancedMesh(asset.leaves, def.leaf.mat, list.length);
    lm.customDepthMaterial = def.leaf.depth;
    lm.castShadow = !isBush || (opts.shadowsOnBushes && id !== "fern");
    lm.receiveShadow = true;
    list.forEach((it, i) => { lm.setMatrixAt(i, it.m); lm.setColorAt(i, it.c); });
    lm.computeBoundingSphere();
    group.add(lm);
    if (asset.bark && def.bark) {
      const bm = new THREE.InstancedMesh(asset.bark, def.bark.mat, list.length);
      bm.customDepthMaterial = def.bark.depth;
      bm.castShadow = true;
      bm.receiveShadow = true;
      list.forEach((it, i) => bm.setMatrixAt(i, it.m));
      bm.computeBoundingSphere();
      group.add(bm);
    }
  }

  // ---------------- GRASS (real 3D blades) ----------------
  const gm = grassMaterial();
  const kinds: GrassKind[] = ["short", "meadow", "tall"];
  const clumpGeos = kinds.map((k, ki) => [makeGrassClump(11 + ki * 7, k), makeGrassClump(57 + ki * 5, k)]);
  const gB = new Map<string, Inst[]>();
  const addGrass = (px: number, pz: number, info: RoadInfo, kind: number, scale: number) => {
    pos.set(px, heightFromInfo(px, pz, info) - 0.02, pz);
    e.set(rand(rng, -0.12, 0.12), rand(rng, 0, 6.28), rand(rng, -0.12, 0.12));
    q.setFromEuler(e);
    sc.set(scale, scale * rand(rng, 0.8, 1.3), scale);
    const key = `${kind}|${Math.floor(rng() * 2)}|${chunkOf(info.idx)}`;
    if (!gB.has(key)) gB.set(key, []);
    gB.get(key)!.push({
      m: new THREE.Matrix4().compose(pos, q, sc),
      c: new THREE.Color().setRGB(rand(rng, 0.82, 1.08), rand(rng, 0.86, 1.08), rand(rng, 0.75, 0.95)),
    });
  };
  const grassN = Math.floor(27000 * opts.grass);
  for (let k = 0; k < grassN; k++) {
    const i = Math.floor(rng() * N);
    const side = rng() < 0.5 ? -1 : 1;
    const strip = rng() < 0.62;
    const a = strip ? ROAD_W / 2 + 0.7 + Math.pow(rng(), 1.4) * 3.2 : ROAD_W / 2 + 3 + Math.pow(rng(), 1.6) * 20;
    const along = rand(rng, -0.6, 0.6);
    const px = S[i].x + R[i].x * a * side + T[i].x * along;
    const pz = S[i].z + R[i].z * a * side + T[i].z * along;
    if (!inside(px, pz)) continue;
    const info = roadInfo(px, pz);
    const n = noise2(px * 0.07, pz * 0.07);
    if (!strip && n < -0.1) continue; // patchy in the forest
    const kind = strip ? (rng() < 0.6 ? 0 : 1) : rng() < 0.3 ? 2 : rng() < 0.6 ? 1 : 0;
    addGrass(px, pz, info, kind, rand(rng, 0.85, 1.5));
  }
  for (const [key, list] of gB) {
    const [kind, v] = key.split("|").map(Number);
    const im = new THREE.InstancedMesh(clumpGeos[kind][v], gm, list.length);
    list.forEach((it, i) => { im.setMatrixAt(i, it.m); im.setColorAt(i, it.c); });
    im.receiveShadow = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // ---------------- JAPANESE TOUGE BARRIERS / SIGNS ----------------
  const props = createPropMaterials();
  const sections: { from: number; to: number; side: number; kind: BarrierKind; a: number }[] = [
    { from: 140, to: 186, side: -1, kind: "pipe", a: ROAD_W / 2 + 0.42 },
    { from: 262, to: 352, side: -1, kind: "wbeam", a: ROAD_W / 2 + 0.38 },
    { from: 425, to: 515, side: -1, kind: "pipe", a: ROAD_W / 2 + 0.42 },
    { from: 522, to: 592, side: 1, kind: "wbeam", a: ROAD_W / 2 + 0.98 },
    { from: 610, to: 706, side: -1, kind: "wbeam", a: ROAD_W / 2 + 0.38 },
    { from: 790, to: 884, side: -1, kind: "wbeam", a: ROAD_W / 2 + 0.38 },
  ];
  sections.forEach((sec, si) => {
    const path: THREE.Vector3[] = [], outs: THREE.Vector3[] = [];
    for (let i = sec.from; i <= Math.min(N, sec.to); i++) {
      const p = S[i].clone().addScaledVector(R[i], sec.a * sec.side);
      p.y = Math.max(S[i].y - 0.08, groundHeight(p.x, p.z));
      path.push(p);
      outs.push(R[i].clone().multiplyScalar(sec.side));
    }
    const b = buildBarrier(path, outs, sec.kind, si + 5);
    const rail = new THREE.Mesh(b.rail, props.rail);
    const posts = new THREE.Mesh(b.posts, props.post);
    for (const m of [rail, posts]) { m.castShadow = true; m.receiveShadow = true; group.add(m); }
  });
  // curve apexes -> chevron boards + curve mirrors on the outside of bends
  const apexes: { i: number; turnRight: boolean }[] = [];
  let lastApex = -999;
  const turnAt = (i: number) => {
    const t1 = T[Math.max(0, i - 25)], t2 = T[Math.min(N, i + 25)];
    return Math.atan2(t1.z * t2.x - t1.x * t2.z, t1.x * t2.x + t1.z * t2.z);
  };
  for (let i = 60; i < N - 60; i++) {
    const a0 = Math.abs(turnAt(i));
    if (a0 > 0.42 && a0 >= Math.abs(turnAt(i - 3)) && a0 >= Math.abs(turnAt(i + 3)) && i - lastApex > 90) {
      apexes.push({ i, turnRight: turnAt(i) < 0 });
      lastApex = i;
    }
  }
  const chevL = buildChevron(false), chevR = buildChevron(true);
  const mirrorGeo = buildCurveMirror();
  apexes.forEach((ap, k) => {
    const outer = ap.turnRight ? -1 : 1;
    for (const di of [-14, 0, 14]) {
      const i = Math.max(0, Math.min(N, ap.i + di));
      const p = S[i].clone().addScaledVector(R[i], (ROAD_W / 2 + 1.25) * outer);
      p.y = groundHeight(p.x, p.z) - 0.05;
      const g = ap.turnRight ? chevL : chevR;
      const grp = new THREE.Group();
      const board = new THREE.Mesh(g.board, props.chevron);
      const post = new THREE.Mesh(g.post, props.post);
      board.castShadow = post.castShadow = true;
      grp.add(board, post);
      grp.position.copy(p);
      grp.lookAt(p.clone().sub(T[i]));
      group.add(grp);
    }
    if (k % 2 === 0) {
      const i = Math.max(0, ap.i - 6);
      const p = S[i].clone().addScaledVector(R[i], (ROAD_W / 2 + 1.6) * outer);
      p.y = groundHeight(p.x, p.z) - 0.05;
      const grp = new THREE.Group();
      const frame = new THREE.Mesh(mirrorGeo.frame, props.post);
      const mir = new THREE.Mesh(mirrorGeo.mirror, props.mirror);
      frame.castShadow = true;
      grp.add(frame, mir);
      grp.position.copy(p);
      grp.lookAt(p.clone().sub(T[i].clone().multiplyScalar(0.8)).addScaledVector(R[i], -outer * 0.9));
      group.add(grp);
    }
  });

  // ---------------- ROCKS ----------------
  const rockGeo = new THREE.IcosahedronGeometry(1, 3);
  {
    const p = rockGeo.attributes.position as THREE.BufferAttribute;
    const rn = createNoise2D(3);
    for (let i = 0; i < p.count; i++) {
      const v = new V(p.getX(i), p.getY(i), p.getZ(i));
      const d = 1 + rn(v.x * 1.7 + v.z, v.y * 1.7) * 0.22 + rn(v.x * 4, v.z * 4 + v.y) * 0.06;
      v.multiplyScalar(d);
      v.y *= 0.6;
      p.setXYZ(i, v.x, v.y, v.z);
    }
    rockGeo.computeVertexNormals();
    const uv = new Float32Array(p.count * 2);
    for (let i = 0; i < p.count; i++) { uv[i * 2] = p.getX(i) * 0.5 + p.getZ(i) * 0.3; uv[i * 2 + 1] = p.getY(i) * 0.5; }
    rockGeo.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
  }
  const rockMat = new THREE.MeshStandardMaterial({ color: "#8a877d", map: tex.barkBroad.map, normalMap: tex.barkBroad.normal, roughness: 0.92 });
  const rockList: THREE.Matrix4[] = [];
  for (let k = 0; k < 260; k++) {
    const i = Math.floor(rng() * N);
    const side = rng() < 0.7 ? 1 : -1;
    const a = ROAD_W / 2 + 1.2 + rng() * 22;
    const px = S[i].x + R[i].x * a * side, pz = S[i].z + R[i].z * a * side;
    if (!inside(px, pz)) continue;
    const s = rand(rng, 0.15, 0.7) * (rng() < 0.08 ? 2.2 : 1);
    pos.set(px, groundHeight(px, pz) - s * 0.2, pz);
    e.set(rand(rng, -0.4, 0.4), rand(rng, 0, 6.28), rand(rng, -0.4, 0.4));
    q.setFromEuler(e);
    sc.set(s * rand(rng, 0.8, 1.4), s, s * rand(rng, 0.8, 1.3));
    rockList.push(new THREE.Matrix4().compose(pos, q, sc));
  }
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, rockList.length);
  rockList.forEach((m, i) => rocks.setMatrixAt(i, m));
  rocks.castShadow = true;
  rocks.receiveShadow = true;
  rocks.computeBoundingSphere();
  group.add(rocks);

  // ---------------- DRIFT SMOKE / ROAD HAZE ----------------
  const smokeUniforms = {
    uTime: globalUniforms.uTime,
    uMap: { value: tex.smoke },
    uSun: { value: new THREE.Color(1, 0.95, 0.85) },
    uAmb: { value: new THREE.Color(0.62, 0.7, 0.72) },
    uFogColor: { value: new THREE.Color() },
    uFogDensity: { value: 0.01 },
    uOpacity: { value: 1 },
  };
  const smokeMat = new THREE.ShaderMaterial({
    uniforms: smokeUniforms,
    transparent: true,
    depthWrite: false,
    vertexShader: /* glsl */ `
      attribute vec4 aData;
      uniform float uTime;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vFogDepth;
      varying float vRot;
      void main() {
        vec3 c = (instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        float life = fract(uTime * aData.y + aData.x);
        float ang = aData.w * 6.2831;
        c += vec3(cos(ang) * life * 3.5 + life * 2.5, life * life * 3.5 + 0.3, sin(ang) * life * 3.5);
        float size = aData.z * (0.6 + life * 2.2);
        vec4 mv = viewMatrix * vec4(c, 1.0);
        float rot = aData.w * 6.28 + uTime * 0.08 * (aData.w - 0.5);
        vec2 p = mat2(cos(rot), -sin(rot), sin(rot), cos(rot)) * position.xy;
        mv.xy += p * size;
        vAlpha = smoothstep(0.0, 0.12, life) * pow(1.0 - life, 1.4);
        vUv = uv;
        vFogDepth = -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uMap;
      uniform vec3 uSun;
      uniform vec3 uAmb;
      uniform vec3 uFogColor;
      uniform float uFogDensity;
      uniform float uOpacity;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vFogDepth;
      void main() {
        vec4 t = texture2D(uMap, vUv);
        vec3 col = mix(uAmb, uSun, 0.35 + 0.3 * vUv.y) * 1.05;
        float f = 1.0 - exp(-uFogDensity * uFogDensity * vFogDepth * vFogDepth);
        col = mix(col, uFogColor, f * 0.6);
        gl_FragColor = vec4(col, t.a * vAlpha * 0.2 * uOpacity);
        #include <colorspace_fragment>
      }`,
  });
  const plane = new THREE.PlaneGeometry(1, 1);
  const smokeSpots = [
    { idx: 262, spread: 22, count: 70 },
    { idx: 290, spread: 30, count: 70 },
    { idx: 330, spread: 30, count: 40 },
  ];
  const smokeTotal = smokeSpots.reduce((s, x) => s + x.count, 0);
  const smoke = new THREE.InstancedMesh(plane, smokeMat, smokeTotal);
  const aData = new Float32Array(smokeTotal * 4);
  let si = 0;
  for (const sp of smokeSpots) {
    for (let k = 0; k < sp.count; k++) {
      const i = Math.min(N, sp.idx + Math.floor(rand(rng, 0, sp.spread)));
      const off = rand(rng, -2.8, 2.8);
      pos.copy(S[i]).addScaledVector(R[i], off);
      pos.y += 0.2;
      smoke.setMatrixAt(si, new THREE.Matrix4().makeTranslation(pos.x, pos.y, pos.z));
      aData.set([rng(), rand(rng, 0.025, 0.05), rand(rng, 2.2, 4.2), rng()], si * 4);
      si++;
    }
  }
  plane.setAttribute("aData", new THREE.InstancedBufferAttribute(aData, 4));
  smoke.frustumCulled = false;
  smoke.renderOrder = 10;
  group.add(smoke);

  // ---------------- DUST MOTES ----------------
  const dustN = 2200;
  const dPos = new Float32Array(dustN * 3);
  for (let k = 0; k < dustN; k++) {
    const i = Math.floor(rand(rng, 160, 420));
    const p = S[i].clone().addScaledVector(R[i], rand(rng, -14, 14));
    dPos.set([p.x, p.y + rand(rng, 0.3, 9), p.z], k * 3);
  }
  const dGeo = new THREE.BufferGeometry();
  dGeo.setAttribute("position", new THREE.BufferAttribute(dPos, 3));
  const dustMat = new THREE.ShaderMaterial({
    uniforms: { uTime: globalUniforms.uTime },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      uniform float uTime;
      varying float vA;
      void main() {
        vec3 p = position;
        float s = fract(sin(dot(p.xz, vec2(12.9, 78.2))) * 437.5);
        p += vec3(sin(uTime * 0.3 + s * 20.0) * 0.6, sin(uTime * 0.21 + s * 9.0) * 0.4, cos(uTime * 0.27 + s * 14.0) * 0.6);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = clamp(26.0 / -mv.z, 1.0, 5.0);
        vA = (0.4 + 0.6 * sin(uTime * 1.5 + s * 30.0)) * smoothstep(40.0, 4.0, -mv.z);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vA;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.0, d) * vA * 0.35;
        gl_FragColor = vec4(vec3(1.0, 0.95, 0.8) * a, a);
      }`,
  });
  const dust = new THREE.Points(dGeo, dustMat);
  dust.frustumCulled = false;
  group.add(dust);

  // ---------------- CAMERA HELPERS ----------------
  const pointAt = (idx: number, lateral: number, up: number) =>
    S[Math.max(0, Math.min(N, Math.round(idx)))].clone().addScaledVector(R[Math.max(0, Math.min(N, Math.round(idx)))], lateral).add(new V(0, up, 0));

  return {
    group,
    curve,
    samples: S,
    tangents: T,
    rights: R,
    N,
    roadLen,
    roadInfo,
    groundHeight,
    pointAt,
    smokeUniforms,
    smoke,
    treeCount,
  };
}

export type World = ReturnType<typeof buildWorld>;
