import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { mulberry32, rand } from "./noise";

type V3 = THREE.Vector3;
const V = THREE.Vector3;
const UP = new V(0, 1, 0);

// ---------------- textures ----------------
function paintedGrimeTexture() {
  const W = 512, H = 256;
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const ctx = c.getContext("2d")!;
  const r = mulberry32(808);
  ctx.fillStyle = "#f4f4ef";
  ctx.fillRect(0, 0, W, H);
  // bottom dirt gradient (canvas bottom == v 0 == bottom of rail/post)
  const g = ctx.createLinearGradient(0, H, 0, 0);
  g.addColorStop(0, "rgba(92,78,58,0.55)");
  g.addColorStop(0.35, "rgba(110,98,78,0.18)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  // vertical rain streaks + rust drips
  for (let i = 0; i < 260; i++) {
    const x = rand(r, 0, W), y = rand(r, 0, H * 0.6), l = rand(r, 20, 160);
    ctx.strokeStyle = r() < 0.15 ? `rgba(140,80,40,${rand(r, 0.1, 0.3)})` : `rgba(80,76,66,${rand(r, 0.04, 0.14)})`;
    ctx.lineWidth = rand(r, 1, 4);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + rand(r, -2, 2), y + l);
    ctx.stroke();
  }
  // moss/lichen specks
  for (let i = 0; i < 500; i++) {
    ctx.fillStyle = `rgba(${rand(r, 70, 110)},${rand(r, 95, 125)},${rand(r, 50, 70)},${rand(r, 0.1, 0.35)})`;
    ctx.fillRect(rand(r, 0, W), H - Math.pow(r(), 2) * H * 0.5, rand(r, 1, 4), rand(r, 1, 3));
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  return t;
}

function chevronTexture() {
  const W = 256, H = 320;
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#f3c300";
  ctx.fillRect(0, 0, W, H);
  ctx.strokeStyle = "#151515";
  ctx.lineWidth = 6;
  ctx.strokeRect(8, 8, W - 16, H - 16);
  ctx.fillStyle = "#151515";
  for (const ox of [-46, 46]) {
    ctx.beginPath();
    ctx.moveTo(70 + ox, 60);
    ctx.lineTo(150 + ox, 160);
    ctx.lineTo(70 + ox, 260);
    ctx.lineTo(108 + ox, 260);
    ctx.lineTo(188 + ox, 160);
    ctx.lineTo(108 + ox, 60);
    ctx.closePath();
    ctx.fill();
  }
  // dirt
  const g = ctx.createLinearGradient(0, H, 0, 0);
  g.addColorStop(0, "rgba(60,50,30,0.35)");
  g.addColorStop(0.5, "rgba(60,50,30,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

export function createPropMaterials() {
  const grime = paintedGrimeTexture();
  return {
    rail: new THREE.MeshStandardMaterial({ color: "#d6d6d0", map: grime, metalness: 0.22, roughness: 0.5, side: THREE.DoubleSide, envMapIntensity: 0.7 }),
    post: new THREE.MeshStandardMaterial({ vertexColors: true, map: grime, metalness: 0.2, roughness: 0.5, envMapIntensity: 0.7, color: "#dcdcd6" }),
    chevron: new THREE.MeshStandardMaterial({ map: chevronTexture(), roughness: 0.45, metalness: 0.1, side: THREE.DoubleSide }),
    mirror: new THREE.MeshStandardMaterial({ color: "#ffffff", metalness: 1, roughness: 0.03, envMapIntensity: 1.4 }),
    depth: new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking }),
  };
}
export type PropMaterials = ReturnType<typeof createPropMaterials>;

// ---------------- geometry helpers ----------------
function colored(g: THREE.BufferGeometry, color: THREE.ColorRepresentation) {
  const c = new THREE.Color(color);
  const n = g.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) a.set([c.r, c.g, c.b], i * 3);
  g.setAttribute("color", new THREE.BufferAttribute(a, 3));
  if (!g.index) {
    const idx: number[] = [];
    for (let i = 0; i < n; i++) idx.push(i);
    g.setIndex(idx);
  }
  return g;
}

/** Sweep a 2D profile (out, up) along a path. */
function sweep(path: V3[], outs: V3[], profile: [number, number][], base: number[], uScale = 1.5) {
  const pos: number[] = [], uv: number[] = [], idx: number[] = [];
  let dist = 0;
  const P = profile.length;
  for (let i = 0; i < path.length; i++) {
    if (i > 0) dist += path[i].distanceTo(path[i - 1]);
    for (let j = 0; j < P; j++) {
      const p = path[i].clone().addScaledVector(outs[i], profile[j][0]).addScaledVector(UP, base[i] + profile[j][1]);
      pos.push(p.x, p.y, p.z);
      uv.push(dist / uScale, 0.15 + (j / (P - 1)) * 0.5);
    }
  }
  for (let i = 0; i < path.length - 1; i++) {
    for (let j = 0; j < P - 1; j++) {
      const a = i * P + j, b = a + P;
      idx.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

// W-beam cross-section (out = away from road; negative bulges toward traffic)
const WBEAM: [number, number][] = [
  [0, 0], [-0.03, 0.02], [-0.068, 0.06], [-0.072, 0.095], [-0.05, 0.13], [-0.028, 0.155],
  [-0.05, 0.18], [-0.072, 0.215], [-0.068, 0.25], [-0.03, 0.29], [0, 0.31],
];
const PIPE: [number, number][] = Array.from({ length: 9 }, (_, i) => {
  const a = (i / 8) * Math.PI * 2;
  return [Math.cos(a) * 0.035, Math.sin(a) * 0.035] as [number, number];
});

export type BarrierKind = "wbeam" | "pipe";

/**
 * Builds a Japanese roadside barrier along `path` (points on the ground at barrier line)
 * with `outs` pointing away from the road.
 */
export function buildBarrier(path: V3[], outs: V3[], kind: BarrierKind, seed = 1) {
  const r = mulberry32(seed);
  const n = path.length;
  const p2 = path.map((p) => p.clone());
  const flareBase = new Array(n).fill(0);
  // flared / dipped terminal ends (like real guardrail end sections)
  const k = Math.min(6, Math.floor(n / 4));
  for (let i = 0; i < k; i++) {
    const t = (k - i) / k;
    p2[i].addScaledVector(outs[i], 0.45 * t * t);
    p2[n - 1 - i].addScaledVector(outs[n - 1 - i], 0.45 * t * t);
    flareBase[i] -= 0.18 * t;
    flareBase[n - 1 - i] -= 0.18 * t;
  }
  const rails: THREE.BufferGeometry[] = [];
  if (kind === "wbeam") {
    rails.push(sweep(p2, outs, WBEAM, flareBase.map((b) => 0.44 + b)));
  } else {
    for (const h of [0.42, 0.66, 0.9]) rails.push(sweep(p2, outs, PIPE, flareBase.map((b) => h + b * 0.4)));
  }
  const rail = rails.length > 1 ? mergeGeometries(rails)! : rails[0];

  // posts + delineators
  const parts: THREE.BufferGeometry[] = [];
  const step = 3; // ~2 m
  const postH = kind === "wbeam" ? 1.3 : 1.42;
  const postR = kind === "wbeam" ? 0.07 : 0.048;
  const off = kind === "wbeam" ? 0.11 : 0;
  let count = 0;
  for (let i = 0; i < n; i += step) {
    const tanV = new V().subVectors(path[Math.min(n - 1, i + 1)], path[Math.max(0, i - 1)]).normalize();
    const base = p2[i].clone().addScaledVector(outs[i], off);
    const shade = rand(r, 0.86, 1);
    const post = colored(new THREE.CylinderGeometry(postR, postR, postH, 12, 1), new THREE.Color(shade, shade, shade * 0.98));
    post.translate(base.x, base.y + postH / 2 - 0.5 + flareBase[i] * 0.5, base.z);
    parts.push(post);
    // cap
    const cap = colored(new THREE.SphereGeometry(postR, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.Color(shade, shade, shade));
    cap.translate(base.x, base.y + postH - 0.5 + flareBase[i] * 0.5, base.z);
    parts.push(cap);
    if (kind === "wbeam") {
      // spacer block between post and beam
      const blk = colored(new THREE.BoxGeometry(0.06, 0.2, 0.06), "#d8d8d2");
      blk.translate(0, 0.6, 0);
      const m = new THREE.Matrix4().makeBasis(outs[i], UP, tanV).setPosition(base.clone().addScaledVector(outs[i], -0.07));
      blk.applyMatrix4(m);
      parts.push(blk);
    }
    // round orange reflector facing traffic every 2nd post
    if (count % 2 === 0) {
      const stem = colored(new THREE.CylinderGeometry(0.008, 0.008, 0.12, 6), "#bbbbbb");
      stem.translate(base.x, base.y + postH - 0.5 + 0.06, base.z);
      parts.push(stem);
      for (const dir of [1, -1]) {
        const disc = colored(new THREE.CylinderGeometry(0.05, 0.05, 0.014, 18), dir > 0 ? "#ff7a10" : "#ffffff");
        disc.rotateX(Math.PI / 2);
        const q = new THREE.Quaternion().setFromUnitVectors(new V(0, 0, 1), tanV.clone().multiplyScalar(dir));
        disc.applyQuaternion(q);
        disc.translate(base.x + tanV.x * 0.008 * dir, base.y + postH - 0.5 + 0.17, base.z + tanV.z * 0.008 * dir);
        parts.push(disc);
      }
    }
    count++;
  }
  return { rail, posts: mergeGeometries(parts)! };
}

/** Yellow/black chevron curve warning sign on a post. */
export function buildChevron(flip: boolean) {
  const board = new THREE.PlaneGeometry(0.55, 0.7);
  if (flip) {
    const uv = board.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < uv.count; i++) uv.setX(i, 1 - uv.getX(i));
  }
  board.translate(0, 1.55, 0.05);
  const post = colored(new THREE.CylinderGeometry(0.035, 0.035, 2.3, 10), "#d9d9d4");
  post.translate(0, 0.75, 0);
  return { board, post };
}

/** Classic orange Japanese curve mirror (カーブミラー). */
export function buildCurveMirror() {
  const parts: THREE.BufferGeometry[] = [];
  const orange = "#ff7a2a";
  const pole = colored(new THREE.CylinderGeometry(0.045, 0.05, 3.3, 12), orange);
  pole.translate(0, 1.15, 0);
  parts.push(pole);
  const ring = colored(new THREE.TorusGeometry(0.43, 0.04, 10, 40), orange);
  ring.translate(0, 2.75, 0.09);
  parts.push(ring);
  const back = colored(new THREE.CylinderGeometry(0.44, 0.44, 0.05, 40), orange);
  back.rotateX(Math.PI / 2);
  back.translate(0, 2.75, 0.04);
  parts.push(back);
  const arm = colored(new THREE.BoxGeometry(0.08, 0.5, 0.06), orange);
  arm.translate(0, 2.55, 0.02);
  parts.push(arm);
  const frame = mergeGeometries(parts)!;
  // convex mirror cap
  const mirror = new THREE.SphereGeometry(1.25, 32, 8, 0, Math.PI * 2, 0, 0.35);
  mirror.rotateX(Math.PI / 2);
  mirror.translate(0, 2.75, 0.07 - 1.25 * Math.cos(0.35));
  return { frame, mirror };
}

/** Straight demo section used by the asset viewer. */
export function straightBarrier(kind: BarrierKind, length = 14) {
  const n = Math.round(length / 0.66);
  const path: V3[] = [], outs: V3[] = [];
  for (let i = 0; i <= n; i++) {
    path.push(new V(-length / 2 + (i / n) * length, 0, 0));
    outs.push(new V(0, 0, -1));
  }
  return buildBarrier(path, outs, kind, 3);
}
