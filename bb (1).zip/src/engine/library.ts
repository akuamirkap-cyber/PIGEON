import * as THREE from "three";
import type { TextureSet } from "./textures";
import { barkMaterial, foliageMaterial, grassMaterial } from "./materials";
import { makeGrassPatch } from "./grass";
import { createPropMaterials, straightBarrier, buildCurveMirror } from "./roadprops";
import {
  makeConifer, makeMaple, makeBeech, makeSapling, makeSasa, makeShrub, makeFern, type TreeAsset,
} from "./trees";

export interface MatPair {
  mat: THREE.Material;
  depth: THREE.Material;
}

export interface AssetDef {
  id: string;
  name: string;
  latin: string;
  category: "Pohon Konifer" | "Pohon Daun Lebar" | "Semak & Tanaman Bawah" | "Rumput" | "Pagar & Properti Touge";
  desc: string;
  height: string;
  make: (seed: number) => TreeAsset;
  bark?: MatPair;
  leaf: MatPair;
  variants: number;
}

export function createLibrary(tex: TextureSet) {
  const cedarBark = barkMaterial(tex.barkCedar.map, tex.barkCedar.normal, 0.00028);
  (cedarBark.mat as THREE.MeshStandardMaterial).color.set("#86766c");
  const cypressBark = barkMaterial(tex.barkCedar.map, tex.barkCedar.normal, 0.0003);
  (cypressBark.mat as THREE.MeshStandardMaterial).color.set("#a08c7e");
  const poleBark = barkMaterial(tex.barkCedar.map, tex.barkCedar.normal, 0.00026);
  (poleBark.mat as THREE.MeshStandardMaterial).color.set("#665a52");
  const broadBark = barkMaterial(tex.barkBroad.map, tex.barkBroad.normal, 0.0012);
  const mapleBark = barkMaterial(tex.barkBroad.map, tex.barkBroad.normal, 0.002);
  (mapleBark.mat as THREE.MeshStandardMaterial).color.set("#8c8478");
  const saplingBark = barkMaterial(tex.barkBroad.map, tex.barkBroad.normal, 0.006);
  (saplingBark.mat as THREE.MeshStandardMaterial).color.set("#9a8d76");

  const cedarLeaf = foliageMaterial(tex.cedar, { bend: 0.00028, flutter: 0.012, transl: 0.55, color: "#e6eedc" });
  const poleLeaf = foliageMaterial(tex.cedar, { bend: 0.00026, flutter: 0.012, transl: 0.5, color: "#d2dec8" });
  const cypressLeaf = foliageMaterial(tex.cypress, { bend: 0.0003, flutter: 0.014, transl: 0.65 });
  const mapleLeaf = foliageMaterial(tex.maple, { bend: 0.002, flutter: 0.03, transl: 1.9, color: "#f4ffd6" });
  const beechLeaf = foliageMaterial(tex.beech, { bend: 0.0012, flutter: 0.03, transl: 1.6, color: "#eefcd2" });
  const saplingLeaf = foliageMaterial(tex.maple, { bend: 0.006, flutter: 0.035, transl: 1.9, color: "#f6ffd0" });
  const sasaLeaf = foliageMaterial(tex.sasa, { bend: 0.03, flutter: 0.02, transl: 0.85 });
  const shrubLeaf = foliageMaterial(tex.shrub, { bend: 0.02, flutter: 0.02, transl: 0.8 });
  const fernLeaf = foliageMaterial(tex.fern, { bend: 0.05, flutter: 0.02, transl: 1.0 });

  const grassMat = grassMaterial();
  const plainDepth = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking });
  const grassPair = { mat: grassMat, depth: plainDepth };
  const props = createPropMaterials();
  const defs: AssetDef[] = [
    {
      id: "cedar", name: "Sugi — Japanese Cedar", latin: "Cryptomeria japonica", category: "Pohon Konifer",
      desc: "Batang lurus menjulang dengan kulit merah-coklat berserat, tajuk kerucut padat warna hijau tua. Pohon dominan di hutan pegunungan Jepang.",
      height: "22–29 m", make: (s) => makeConifer(s, "cedar"), bark: cedarBark, leaf: cedarLeaf, variants: 3,
    },
    {
      id: "pole", name: "Sugi Plantation Pole", latin: "Cryptomeria japonica (tegakan rapat)", category: "Pohon Konifer",
      desc: "Varian tegakan tanaman rapat: batang kurus tinggi, cabang mati di bawah, tajuk kecil di puncak — persis siluet batang-batang gelap di referensi.",
      height: "24–31 m", make: (s) => makeConifer(s, "pole"), bark: poleBark, leaf: poleLeaf, variants: 2,
    },
    {
      id: "cypress", name: "Hinoki Cypress", latin: "Chamaecyparis obtusa", category: "Pohon Konifer",
      desc: "Daun sisik pipih seperti kipas, tajuk lebih bulat dan rapat, kulit kayu lebih terang kemerahan.",
      height: "17–23 m", make: (s) => makeConifer(s, "cypress"), bark: cypressBark, leaf: cypressLeaf, variants: 2,
    },
    {
      id: "maple", name: "Momiji — Japanese Maple", latin: "Acer palmatum", category: "Pohon Daun Lebar",
      desc: "Daun menjari 5–7 lobus hijau segar yang tembus cahaya, tajuk berlapis horizontal. Memberi kilau hijau-kuning saat backlight matahari.",
      height: "8–11 m", make: makeMaple, bark: mapleBark, leaf: mapleLeaf, variants: 2,
    },
    {
      id: "beech", name: "Buna / Konara", latin: "Fagus crenata / Quercus serrata", category: "Pohon Daun Lebar",
      desc: "Pohon daun lebar dengan kulit abu-abu halus berlumut, daun bergerigi oval, tajuk membulat tinggi.",
      height: "14–19 m", make: makeBeech, bark: broadBark, leaf: beechLeaf, variants: 2,
    },
    {
      id: "sapling", name: "Young Broadleaf", latin: "Acer sp. (anakan)", category: "Pohon Daun Lebar",
      desc: "Anakan pohon ramping di tepi jalan dengan daun hijau limau terang — mengisi lapisan tengah hutan.",
      height: "4–6.5 m", make: makeSapling, bark: saplingBark, leaf: saplingLeaf, variants: 2,
    },
    {
      id: "sasa", name: "Kumazasa Bamboo Grass", latin: "Sasa veitchii", category: "Semak & Tanaman Bawah",
      desc: "Rumpun bambu kerdil berdaun lanset dengan tepi pucat. Semak paling umum di lantai hutan Jepang.",
      height: "0.9–1.5 m", make: makeSasa, leaf: sasaLeaf, variants: 2,
    },
    {
      id: "shrub", name: "Broadleaf Shrub", latin: "Aucuba / Pieris sp.", category: "Semak & Tanaman Bawah",
      desc: "Semak membulat padat dengan daun kecil mengkilap, cocok untuk tepi jalan dan tebing.",
      height: "1.2–1.9 m", make: makeShrub, leaf: shrubLeaf, variants: 2,
    },
    {
      id: "fern", name: "Forest Fern", latin: "Dryopteris sp.", category: "Semak & Tanaman Bawah",
      desc: "Pakis daun menyirip yang melengkung keluar, tumbuh di area lembab dan teduh.",
      height: "0.6–0.9 m", make: makeFern, leaf: fernLeaf, variants: 2,
    },
    {
      id: "grass_short", name: "Rumput Pendek Tepi Jalan", latin: "Zoysia / Poa sp.", category: "Rumput",
      desc: "Rumpun rumput pendek dengan bilah 3D asli (bukan billboard): pangkal gelap, ujung hijau terang tembus cahaya, sebagian ujung mengering. Tumbuh rapat di bahu jalan.",
      height: "0.2–0.5 m", make: (s) => ({ leaves: makeGrassPatch(s, "short", 1.5, 50), height: 0.4 }), leaf: grassPair, variants: 2,
    },
    {
      id: "grass_meadow", name: "Rumput Liar", latin: "Imperata / Miscanthus muda", category: "Rumput",
      desc: "Rumput liar bilah halus yang lebih rimbun dan bergoyang lembut tertiup angin — mengisi celah serasah di lantai hutan.",
      height: "0.3–0.7 m", make: (s) => ({ leaves: makeGrassPatch(s, "meadow", 1.6, 45), height: 0.6 }), leaf: grassPair, variants: 2,
    },
    {
      id: "grass_tall", name: "Rumput Tinggi Melengkung", latin: "Carex sp. (sedge)", category: "Rumput",
      desc: "Rumpun sedge berbilah panjang yang melengkung keluar, khas tebing lembab pegunungan Jepang.",
      height: "0.6–1.1 m", make: (s) => ({ leaves: makeGrassPatch(s, "tall", 1.4, 34), height: 1 }), leaf: grassPair, variants: 2,
    },
    {
      id: "guardrail", name: "Guardrail W-Beam Putih", latin: "ガードレール (gādorēru)", category: "Pagar & Properti Touge",
      desc: "Pagar baja W-beam cat putih khas jalan gunung Jepang, tiang bulat dengan blok spacer, ujung melengkung menukik, reflektor bulat oranye, noda karat & lumut di bawah.",
      height: "0.75 m", make: () => { const b = straightBarrier("wbeam"); return { bark: b.posts, leaves: b.rail, height: 1 }; },
      bark: { mat: props.post, depth: plainDepth }, leaf: { mat: props.rail, depth: plainDepth }, variants: 1,
    },
    {
      id: "guardpipe", name: "Guard Pipe 3 Pipa", latin: "ガードパイプ (gādo paipu)", category: "Pagar & Properti Touge",
      desc: "Pagar pipa baja putih tiga baris yang sering terlihat di tikungan sempit dan tepi jurang touge.",
      height: "0.9 m", make: () => { const b = straightBarrier("pipe"); return { bark: b.posts, leaves: b.rail, height: 1 }; },
      bark: { mat: props.post, depth: plainDepth }, leaf: { mat: props.rail, depth: plainDepth }, variants: 1,
    },
    {
      id: "mirror", name: "Curve Mirror Oranye", latin: "カーブミラー (kābu mirā)", category: "Pagar & Properti Touge",
      desc: "Cermin cembung bertiang oranye di tikungan buta — ikon jalan touge Jepang. Cermin memantulkan lingkungan secara real-time (environment map).",
      height: "3.2 m", make: () => { const m = buildCurveMirror(); return { bark: m.frame, leaves: m.mirror, height: 3.2 }; },
      bark: { mat: props.post, depth: plainDepth }, leaf: { mat: props.mirror, depth: plainDepth }, variants: 1,
    },
  ];
  return defs;
}
