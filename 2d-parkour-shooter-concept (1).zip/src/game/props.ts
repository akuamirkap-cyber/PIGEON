import { drawGun, type GunKind } from './character';
import type { PropDef, PropType } from './level';
import { TAU } from './math';

export interface Prop {
  id: number;
  type: PropType;
  section: number;
  x: number;
  y: number;
  w: number;
  h: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
  alive: boolean;
  onGround: boolean;
  state: 'idle' | 'flying' | 'broken' | 'open' | 'resting';
  fuse: number;
  t: number;
  kickedAt: number;
  bounces: number;
  hp: number;
  ax: number;
  ay: number;
  hitIds: number[];
  noCol: number;
  hist: number[];
  tags: string[];
  gun: GunKind;
  crack: number;
  crackY: number;
}

let PID = 1;

export function createProp(def: PropDef): Prop {
  const p: Prop = {
    id: PID++,
    type: def.type,
    section: def.section,
    x: def.x,
    y: def.y,
    w: def.w ?? 0,
    h: def.h ?? 0,
    vx: 0,
    vy: 0,
    rot: 0,
    vr: 0,
    alive: true,
    onGround: true,
    state: 'idle',
    fuse: -1,
    t: Math.random() * 10,
    kickedAt: -10,
    bounces: 0,
    hp: 1,
    ax: def.x,
    ay: def.y,
    hitIds: [],
    noCol: 0,
    hist: [],
    tags: [],
    gun: null,
    crack: 0,
    crackY: 0,
  };
  if (def.type === 'barrel') {
    p.w = 26;
    p.h = 36;
  } else if (def.type === 'pan') {
    p.w = 22;
    p.h = 6;
    p.y = def.y - 3;
  } else if (def.type === 'banana' || def.type === 'uzi') {
    p.w = 26;
    p.h = 26;
  } else if (def.type === 'shotgun') {
    p.w = 40;
    p.h = 26;
  } else if (def.type === 'weapon') {
    p.w = 44;
    p.h = 26;
    p.gun = (def.gun ?? 'ak47') as GunKind;
  } else if (def.type === 'gundrop') {
    p.w = 24;
    p.h = 10;
  } else if (def.type === 'door') {
    p.hp = 6;
  } else if (def.type === 'lamp' || def.type === 'chandelier') {
    p.h = def.h ?? 40;
    p.rot = (Math.random() - 0.5) * 0.08;
    p.x = def.x;
    p.y = def.y + p.h + 7;
  } else if (def.type === 'streetlamp') {
    p.h = def.h ?? 240;
  }
  return p;
}

const OUT = '#1b1410';

export function drawBarrel(ctx: CanvasRenderingContext2D, p: Prop) {
  const x = p.x;
  const y = p.y;
  ctx.save();
  ctx.translate(x, y - p.h / 2);
  ctx.rotate(p.rot);
  const w = p.w;
  const h = p.h;
  ctx.lineWidth = 2.6;
  ctx.strokeStyle = OUT;
  ctx.fillStyle = p.fuse >= 0 && Math.floor(p.t * 30) % 2 === 0 ? '#ff6b4a' : '#cf2e22';
  ctx.beginPath();
  ctx.roundRect(-w / 2, -h / 2, w, h, 4);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.fillRect(-w / 2 + 1, -h / 2 + 1, w * 0.3, h - 2);
  ctx.fillStyle = 'rgba(255,255,255,0.28)';
  ctx.fillRect(w * 0.12, -h / 2 + 2, 3, h - 4);
  ctx.strokeStyle = '#7d1810';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-w / 2, -h / 2 + 7);
  ctx.lineTo(w / 2, -h / 2 + 7);
  ctx.moveTo(-w / 2, h / 2 - 7);
  ctx.lineTo(w / 2, h / 2 - 7);
  ctx.stroke();
  // hazard label
  ctx.fillStyle = '#ffd23f';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(0, -6);
  ctx.lineTo(6.5, 5);
  ctx.lineTo(-6.5, 5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = OUT;
  ctx.fillRect(-0.8, -2.5, 1.6, 4);
  ctx.fillRect(-0.8, 2.6, 1.6, 1.4);
  ctx.restore();
}

export function drawPan(ctx: CanvasRenderingContext2D, p: Prop) {
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(p.rot);
  ctx.lineWidth = 1.8;
  ctx.strokeStyle = OUT;
  // handle
  ctx.fillStyle = '#3b2416';
  ctx.beginPath();
  ctx.roundRect(9, -1.6, 14, 3.4, 1.6);
  ctx.fill();
  ctx.stroke();
  // body
  ctx.fillStyle = '#2d2f33';
  ctx.beginPath();
  ctx.moveTo(-12, -3);
  ctx.lineTo(12, -3);
  ctx.lineTo(10, 3.5);
  ctx.lineTo(-10, 3.5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#9aa3ad';
  ctx.fillRect(-11, -3, 22, 1.6);
  if (p.state === 'flying') {
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = 'rgba(255,220,120,0.15)';
    ctx.beginPath();
    ctx.arc(0, 0, 18, 0, TAU);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();
}

export function drawGlass(ctx: CanvasRenderingContext2D, p: Prop) {
  if (p.state === 'broken') {
    // jagged leftovers
    ctx.fillStyle = 'rgba(170,215,240,0.6)';
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + p.w, p.y);
    ctx.lineTo(p.x + p.w * 0.3, p.y + 14);
    ctx.lineTo(p.x, p.y + 22);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(p.x, p.y + p.h);
    ctx.lineTo(p.x + p.w, p.y + p.h);
    ctx.lineTo(p.x + p.w, p.y + p.h - 18);
    ctx.lineTo(p.x + p.w * 0.4, p.y + p.h - 9);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    return;
  }
  ctx.fillStyle = 'rgba(160,210,240,0.45)';
  ctx.fillRect(p.x, p.y, p.w, p.h);
  ctx.strokeStyle = '#2a3440';
  ctx.lineWidth = 2;
  ctx.strokeRect(p.x, p.y, p.w, p.h);
  ctx.strokeStyle = 'rgba(255,255,255,0.75)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(p.x + 3, p.y + p.h * 0.25);
  ctx.lineTo(p.x + p.w - 3, p.y + p.h * 0.1);
  ctx.moveTo(p.x + 3, p.y + p.h * 0.55);
  ctx.lineTo(p.x + p.w - 3, p.y + p.h * 0.42);
  ctx.stroke();
}

export function drawDoor(ctx: CanvasRenderingContext2D, p: Prop) {
  // motion ghosts while flying
  if (p.state === 'flying' && p.hist.length >= 3) {
    for (let i = 0; i + 2 < p.hist.length; i += 3) {
      const a = 0.1 + (i / p.hist.length) * 0.22;
      ctx.save();
      ctx.globalAlpha = a;
      ctx.translate(p.hist[i], p.hist[i + 1]);
      ctx.rotate(p.hist[i + 2]);
      ctx.fillStyle = '#c99a6a';
      ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      ctx.restore();
    }
  }
  ctx.save();
  ctx.translate(p.x + p.w / 2, p.y + p.h / 2);
  ctx.rotate(p.rot);
  const w = p.w;
  const h = p.h;
  ctx.fillStyle = '#8a5a34';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  ctx.rect(-w / 2, -h / 2, w, h);
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = '#5c3a1f';
  ctx.lineWidth = 2;
  ctx.strokeRect(-w / 2 + 5, -h / 2 + 8, w - 10, h * 0.38);
  ctx.strokeRect(-w / 2 + 5, h * 0.02, w - 10, h * 0.38);
  ctx.fillStyle = '#e0b84a';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.arc(-w / 2 + 6, 4, 3, 0, TAU);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  ctx.fillRect(-w / 2 + 2, -h / 2 + 2, 4, h - 4);
  if (p.crack) {
    // splintered hole where the heel connected
    const cy = Math.max(-h / 2 + 14, Math.min(h / 2 - 14, p.crackY));
    ctx.fillStyle = '#1b1006';
    ctx.beginPath();
    const n = 12;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU;
      const r = (i % 2 === 0 ? 10 : 4.5) * (1 + ((i * 37) % 5) * 0.06);
      const px = Math.cos(a) * r * 0.75;
      const py = cy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#c99a6a';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU + 0.3;
      ctx.moveTo(Math.cos(a) * 6, cy + Math.sin(a) * 8);
      ctx.lineTo(Math.cos(a) * (w * 0.45), cy + Math.sin(a) * (16 + (i % 3) * 7));
    }
    ctx.stroke();
  }
  ctx.restore();
}

export function drawBanana(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  rot: number,
  face = true,
  talk = 0,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  // body crescent
  ctx.beginPath();
  ctx.moveTo(-12, -14);
  ctx.quadraticCurveTo(-20, 6, 2, 16);
  ctx.quadraticCurveTo(14, 20, 20, 12);
  ctx.quadraticCurveTo(6, 10, -2, 2);
  ctx.quadraticCurveTo(-8, -6, -7, -15);
  ctx.closePath();
  ctx.fillStyle = '#ffd93b';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2.4;
  ctx.fill();
  ctx.stroke();
  // shade
  ctx.beginPath();
  ctx.moveTo(-9, -12);
  ctx.quadraticCurveTo(-14, 6, 4, 13);
  ctx.quadraticCurveTo(-6, 4, -9, -12);
  ctx.fillStyle = '#f2b81c';
  ctx.fill();
  // tips
  ctx.fillStyle = '#5a3a1a';
  ctx.beginPath();
  ctx.moveTo(-12, -14);
  ctx.lineTo(-11, -19);
  ctx.lineTo(-6.5, -18);
  ctx.lineTo(-7, -15);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(19.5, 12, 2, 0, TAU);
  ctx.fill();
  if (face) {
    ctx.fillStyle = '#fff';
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.ellipse(-9, -2, 2.6, 3.2, 0, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(-3.5, 0, 2.4, 3, 0, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#111';
    ctx.beginPath();
    ctx.arc(-8.2, -1.6, 1.3, 0, TAU);
    ctx.arc(-2.8, 0.4, 1.2, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    if (talk > 0.5) {
      ctx.fillStyle = '#7a1c1c';
      ctx.ellipse(-6, 6.5, 2.4, 2, 0.3, 0, TAU);
      ctx.fill();
      ctx.stroke();
    } else {
      ctx.moveTo(-9, 5.5);
      ctx.quadraticCurveTo(-5.5, 8.5, -2, 6.5);
      ctx.stroke();
    }
  }
  ctx.restore();
}

export function drawUziPickup(ctx: CanvasRenderingContext2D, p: Prop) {
  const bob = Math.sin(p.t * 3) * 3;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(p.x, p.y - 16, 0, p.x, p.y - 16, 30);
  g.addColorStop(0, 'rgba(120,220,255,0.45)');
  g.addColorStop(1, 'rgba(120,220,255,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(p.x, p.y - 16, 30, 0, TAU);
  ctx.fill();
  ctx.restore();
  drawGun(ctx, 'uzi', p.x - 9, p.y - 18 + bob, -0.25, 0);
  drawGun(ctx, 'uzi', p.x + 3, p.y - 12 + bob, -0.1, 0);
  ctx.fillStyle = '#3a3f46';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(p.x - 16, p.y - 5, 32, 5, 2);
  ctx.fill();
  ctx.stroke();
}

export function isGlass(p: Prop) {
  return p.type === 'glass' || p.type === 'glassdoor';
}

export function drawGlassDoor(ctx: CanvasRenderingContext2D, p: Prop) {
  const { x, y, w, h } = p;
  ctx.lineJoin = 'round';
  if (p.state !== 'broken') {
    ctx.fillStyle = 'rgba(165,215,240,0.42)';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = 'rgba(255,255,255,0.7)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + 3, y + h * 0.2);
    ctx.lineTo(x + w - 3, y + h * 0.08);
    ctx.moveTo(x + 3, y + h * 0.45);
    ctx.lineTo(x + w - 3, y + h * 0.33);
    ctx.stroke();
    // push bar
    ctx.fillStyle = '#c9d1d8';
    ctx.fillRect(x - 3, y + h * 0.52, w + 6, 5);
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 3, y + h * 0.52, w + 6, 5);
  } else {
    ctx.fillStyle = 'rgba(170,215,240,0.6)';
    ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + w, y);
    ctx.lineTo(x + w * 0.6, y + 16);
    ctx.lineTo(x, y + 26);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y + h);
    ctx.lineTo(x + w, y + h);
    ctx.lineTo(x + w, y + h - 22);
    ctx.lineTo(x + w * 0.3, y + h - 10);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  // frame
  ctx.strokeStyle = '#2a3038';
  ctx.lineWidth = 4;
  ctx.strokeRect(x - 1, y, w + 2, h);
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 1.2;
  ctx.strokeRect(x - 3, y - 2, w + 6, h + 2);
}

/** hanging lamp (pendulum) or fallen lamp */
export function drawLamp(ctx: CanvasRenderingContext2D, p: Prop, time: number) {
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (p.type === 'streetlamp') {
    const h = p.h;
    const x = p.ax;
    const y = p.ay;
    ctx.fillStyle = '#23272e';
    ctx.fillRect(x - 4, y - h, 8, h);
    ctx.beginPath();
    ctx.moveTo(x, y - h);
    ctx.quadraticCurveTo(x + 10, y - h - 30, x + 44, y - h - 22);
    ctx.lineTo(x + 44, y - h - 16);
    ctx.quadraticCurveTo(x + 12, y - h - 22, x + 4, y - h + 6);
    ctx.fill();
    const on = p.state === 'idle';
    ctx.fillStyle = on ? '#fff1b8' : '#3a3d44';
    ctx.beginPath();
    ctx.ellipse(x + 44, y - h - 13, 12, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    if (!on) {
      ctx.strokeStyle = 'rgba(200,220,235,0.6)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + 36, y - h - 12);
      ctx.lineTo(x + 40, y - h - 7);
      ctx.lineTo(x + 46, y - h - 11);
      ctx.lineTo(x + 51, y - h - 6);
      ctx.stroke();
    }
    return;
  }
  const chand = p.type === 'chandelier';
  const drawShade = (on: boolean, broken: boolean) => {
    if (chand) {
      drawChandelier(ctx, on, broken, time);
      return;
    }
    ctx.fillStyle = '#2d3a33';
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-6, -7);
    ctx.lineTo(6, -7);
    ctx.lineTo(18, 7);
    ctx.lineTo(-18, 7);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.fillRect(-4, -6, 3, 11);
    if (on) {
      const fl = 0.85 + Math.sin(time * 37 + p.ax) * 0.1;
      ctx.fillStyle = `rgba(255,246,200,${fl})`;
      ctx.beginPath();
      ctx.ellipse(0, 8, 9, 4, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (broken) {
      ctx.fillStyle = '#3a3a40';
      ctx.beginPath();
      ctx.moveTo(-7, 7);
      ctx.lineTo(-4, 11);
      ctx.lineTo(-1, 8);
      ctx.lineTo(2, 12);
      ctx.lineTo(5, 8);
      ctx.lineTo(7, 7);
      ctx.closePath();
      ctx.fill();
    }
  };
  if (p.state === 'flying' || p.state === 'resting') {
    // stub of cord left hanging
    ctx.strokeStyle = '#111';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(p.ax, p.ay);
    ctx.lineTo(p.ax + Math.sin(time * 2 + p.ax) * 3, p.ay + 14);
    ctx.stroke();
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot);
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(Math.sin(time * 6) * 3, -20);
    ctx.stroke();
    drawShade(false, true);
    ctx.restore();
    return;
  }
  const L = p.h;
  const ex = p.ax + Math.sin(p.rot) * L;
  const ey = p.ay + Math.cos(p.rot) * L;
  ctx.strokeStyle = '#111';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(p.ax, p.ay);
  ctx.lineTo(ex, ey);
  ctx.stroke();
  ctx.save();
  ctx.translate(ex + Math.sin(p.rot) * 7, ey + Math.cos(p.rot) * 7);
  ctx.rotate(-p.rot);
  drawShade(p.state === 'idle', p.state === 'broken');
  ctx.restore();
}

/** bulb position & light direction of a lamp (null when off) */
export function lampLight(p: Prop): { x: number; y: number; a: number; street: boolean; big?: boolean } | null {
  if (p.type !== 'lamp' && p.type !== 'streetlamp' && p.type !== 'chandelier') return null;
  if (p.state !== 'idle' || !p.alive) return null;
  if (p.type === 'streetlamp') return { x: p.ax + 44, y: p.ay - p.h - 10, a: 0, street: true };
  const big = p.type === 'chandelier';
  const L = p.h + (big ? 26 : 15);
  return { x: p.ax + Math.sin(p.rot) * L, y: p.ay + Math.cos(p.rot) * L, a: p.rot, street: false, big };
}

/** crystal chandelier (shoot twice to drop it) */
export function drawChandelier(ctx: CanvasRenderingContext2D, on: boolean, broken: boolean, time: number) {
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  const gold = '#d9a93a';
  const goldDark = '#9c7420';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  // stem
  ctx.fillStyle = gold;
  ctx.fillRect(-3, -8, 6, 16);
  ctx.strokeRect(-3, -8, 6, 16);
  // arms
  ctx.strokeStyle = goldDark;
  ctx.lineWidth = 3;
  for (let i = -2; i <= 2; i++) {
    ctx.beginPath();
    ctx.moveTo(0, 8);
    ctx.quadraticCurveTo(i * 10, 22, i * 15, 8);
    ctx.stroke();
  }
  // ring
  ctx.fillStyle = gold;
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, 20, 36, 7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,240,180,0.5)';
  ctx.fillRect(-28, 17, 56, 2);
  // candles + flames
  for (let i = -2; i <= 2; i++) {
    const x = i * 15;
    ctx.fillStyle = '#f4eedc';
    ctx.fillRect(x - 2.5, 0, 5, 9);
    ctx.strokeStyle = OUT;
    ctx.lineWidth = 1.2;
    ctx.strokeRect(x - 2.5, 0, 5, 9);
    if (on) {
      const fl = 1 + Math.sin(time * 18 + i * 2) * 0.18;
      ctx.fillStyle = '#ffb02e';
      ctx.beginPath();
      ctx.ellipse(x, -4, 2.6 * fl, 5 * fl, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fff6c8';
      ctx.beginPath();
      ctx.ellipse(x, -3, 1.2, 2.6, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  // crystals
  const n = broken ? 5 : 9;
  for (let i = 0; i < n; i++) {
    const k = broken ? [0, 2, 3, 6, 8][i] : i;
    const x = -32 + k * 8;
    const len = 10 + ((k * 7) % 5) * 3 + Math.sin(time * 2 + k) * 0.8;
    ctx.strokeStyle = 'rgba(220,235,255,0.8)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, 24);
    ctx.lineTo(x, 24 + len);
    ctx.stroke();
    ctx.fillStyle = on ? 'rgba(210,240,255,0.95)' : 'rgba(150,170,190,0.85)';
    ctx.beginPath();
    ctx.moveTo(x, 24 + len);
    ctx.lineTo(x + 3, 28 + len);
    ctx.lineTo(x, 34 + len);
    ctx.lineTo(x - 3, 28 + len);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = OUT;
    ctx.stroke();
  }
}

export function drawShotgunPickup(ctx: CanvasRenderingContext2D, p: Prop) {
  const bob = Math.sin(p.t * 3) * 3;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(p.x, p.y - 16, 0, p.x, p.y - 16, 36);
  g.addColorStop(0, 'rgba(255,150,80,0.55)');
  g.addColorStop(1, 'rgba(255,150,80,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(p.x, p.y - 16, 36, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGun(ctx, 'shotgun', p.x - 6, p.y - 18 + bob, -0.12, 0);
  ctx.fillStyle = '#3a3f46';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(p.x - 20, p.y - 5, 40, 5, 2);
  ctx.fill();
  ctx.stroke();
}

export function drawGunDrop(ctx: CanvasRenderingContext2D, p: Prop, time: number) {
  if (p.state === 'resting') {
    const pulse = 0.5 + Math.sin(time * 6 + p.id) * 0.5;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(p.x, p.y - 2, 0, p.x, p.y - 2, 26);
    g.addColorStop(0, `rgba(140,220,255,${0.22 + pulse * 0.25})`);
    g.addColorStop(1, 'rgba(140,220,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(p.x - 26, p.y - 28, 52, 52);
    ctx.restore();
  }
  drawGun(ctx, p.gun, p.x, p.y - 2, p.rot, 0);
}

const PICKUP_STYLE: Record<string, { rgb: string; label: string; ang: number; dx: number }> = {
  ak47: { rgb: '255,170,70', label: 'AK-47', ang: -0.12, dx: -6 },
  sniper: { rgb: '120,255,140', label: 'SNIPER', ang: -0.08, dx: -14 },
  bat: { rgb: '255,210,140', label: 'PEMUKUL', ang: -0.45, dx: -22 },
  sling: { rgb: '190,255,110', label: 'KETAPEL', ang: 0, dx: 0 },
  cricket: { rgb: '130,215,255', label: 'NOISY CRICKET', ang: 0, dx: -4 },
  katana: { rgb: '175,230,255', label: 'KATANA', ang: -0.55, dx: -24 },
};

/** generic floating weapon pickup with glow + label */
export function drawWeaponPickup(ctx: CanvasRenderingContext2D, p: Prop) {
  const st = PICKUP_STYLE[p.gun ?? 'ak47'] ?? PICKUP_STYLE.ak47;
  const bob = Math.sin(p.t * 3) * 3.5;
  const pulse = 0.5 + Math.sin(p.t * 5) * 0.5;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(p.x, p.y - 18, 0, p.x, p.y - 18, 46);
  g.addColorStop(0, `rgba(${st.rgb},${0.38 + pulse * 0.2})`);
  g.addColorStop(1, `rgba(${st.rgb},0)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(p.x, p.y - 18, 46, 0, Math.PI * 2);
  ctx.fill();
  // light beam
  const bg = ctx.createLinearGradient(0, p.y - 110, 0, p.y);
  bg.addColorStop(0, `rgba(${st.rgb},0)`);
  bg.addColorStop(1, `rgba(${st.rgb},${0.18 + pulse * 0.1})`);
  ctx.fillStyle = bg;
  ctx.fillRect(p.x - 16, p.y - 110, 32, 110);
  ctx.restore();
  ctx.save();
  ctx.translate(0, bob);
  if (p.gun === 'cricket' || p.gun === 'sling') {
    // tiny guns: show them a bit bigger on the pedestal
    ctx.translate(p.x + st.dx, p.y - 22);
    ctx.scale(1.7, 1.7);
    drawGun(ctx, p.gun, 0, 0, st.ang, 0, '#141414', p.gun === 'cricket' ? 0.4 + Math.sin(p.t * 6) * 0.3 : 0);
  } else drawGun(ctx, p.gun, p.x + st.dx, p.y - 20, st.ang, 0);
  ctx.restore();
  ctx.fillStyle = '#3a3f46';
  ctx.strokeStyle = OUT;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.roundRect(p.x - 22, p.y - 5, 44, 5, 2);
  ctx.fill();
  ctx.stroke();
  ctx.font = '16px Bangers, Impact, sans-serif';
  ctx.textAlign = 'center';
  ctx.lineJoin = 'round';
  ctx.lineWidth = 4;
  ctx.strokeStyle = OUT;
  ctx.strokeText(st.label, p.x, p.y - 52 + bob);
  ctx.fillStyle = `rgb(${st.rgb})`;
  ctx.fillText(st.label, p.x, p.y - 52 + bob);
}
