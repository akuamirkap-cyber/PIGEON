import type { Bat3 } from './character';

/**
 * 3D melee system shared by the katana and the baseball bat.
 * A blade pose is expressed in the character's local frame (facing right):
 *  th = azimuth around the body (0 = toward the target, PI = behind, +PI/2 = toward the camera)
 *  el = elevation (up)   gx/gy = grip offset from the front shoulder   gz = grip depth (toward camera)
 *  sx = torso twist (horizontal squash)   spin = whole-body rotation around the vertical axis
 */
export type MeleeId = 'katana' | 'bat' | 'fist';

export interface MKey {
  t: number;
  th: number;
  el: number;
  gx: number;
  gy: number;
  gz: number;
  sx: number;
  torso: number;
  spin?: number;
  /** [fx, fy, bx, by, py] footwork; omit for aerial keys */
  legs?: number[];
  /** easing into this key: 0 smooth, 1 accelerate (whip), 2 linear, 3 decelerate (follow-through) */
  e?: number;
}

export interface BladePose {
  th: number;
  el: number;
  gx: number;
  gy: number;
  gz: number;
  sx: number;
  torso: number;
  spin: number;
  legs: number[];
  hasLegs: boolean;
}

export interface MeleeMove {
  id: string;
  w: MeleeId;
  keys: MKey[];
  hit: [number, number];
  chain: number;
  end: number;
  dmg: number;
  boss: number;
  /** kill impulse direction [forward, up(-)/down(+)] and strength */
  dir: [number, number];
  power: number;
  /** local hit box relative to the feet: [x0, x1, y0, y1], +x = forward */
  zone: [number, number, number, number];
  next?: string;
  auto?: string;
  lunge?: [number, number, number];
  hover?: [number, number];
  hop?: [number, number];
  spin?: boolean;
  launch?: number;
  sever?: number;
  slam?: boolean;
  plunge?: boolean;
  air?: boolean;
  heavy?: boolean;
  shake: number;
  stop: number;
  tag: string;
  trail: number;
  /** fists: 0 lead hand, 1 rear hand, 2 kick (legs keyframes), 3 both hands */
  hand?: number;
  knock?: number;
  struct?: number;
}

export const KATANA = { pommel: 7, handle: 10, blade: 54, reach: 64, chargeT: 0.55, holdT: 0.24 };

const PI = Math.PI;
const TAU = PI * 2;

function wrap(a: number) {
  while (a > PI) a -= TAU;
  while (a < -PI) a += TAU;
  return a;
}

export function newBladePose(): BladePose {
  return { th: 0, el: 0, gx: 0, gy: 0, gz: 0, sx: 1, torso: 0, spin: 0, legs: [0, 0, 0, 0, 0], hasLegs: false };
}

export function copyPose(src: BladePose, dst: BladePose) {
  dst.th = src.th;
  dst.el = src.el;
  dst.gx = src.gx;
  dst.gy = src.gy;
  dst.gz = src.gz;
  dst.sx = src.sx;
  dst.torso = src.torso;
  dst.spin = src.spin;
  dst.hasLegs = src.hasLegs;
  for (let i = 0; i < 5; i++) dst.legs[i] = src.legs[i];
  return dst;
}

/** fold any (th, el) into the canonical hemisphere so blends take the short way round */
export function normalizePose(p: BladePose) {
  let el = wrap(p.el);
  let th = p.th;
  if (el > PI / 2) {
    el = PI - el;
    th += PI;
  } else if (el < -PI / 2) {
    el = -PI - el;
    th += PI;
  }
  p.el = el;
  p.th = wrap(th);
  p.spin = wrap(p.spin);
  return p;
}

function ease(e: number, u: number) {
  if (e === 1) return u * u;
  if (e === 2) return u;
  if (e === 3) return 1 - (1 - u) * (1 - u);
  return u * u * (3 - 2 * u);
}

export function sampleMove(m: MeleeMove, t: number, out: BladePose): BladePose {
  const K = m.keys;
  let a = K[0];
  let b = K[0];
  let u = 0;
  if (t >= K[K.length - 1].t) {
    a = b = K[K.length - 1];
  } else if (t > K[0].t) {
    for (let i = 1; i < K.length; i++) {
      if (t <= K[i].t) {
        a = K[i - 1];
        b = K[i];
        u = ease(b.e ?? 0, (t - a.t) / (b.t - a.t));
        break;
      }
    }
  }
  out.th = a.th + (b.th - a.th) * u;
  out.el = a.el + (b.el - a.el) * u;
  out.gx = a.gx + (b.gx - a.gx) * u;
  out.gy = a.gy + (b.gy - a.gy) * u;
  out.gz = a.gz + (b.gz - a.gz) * u;
  out.sx = a.sx + (b.sx - a.sx) * u;
  out.torso = a.torso + (b.torso - a.torso) * u;
  out.spin = (a.spin ?? 0) + ((b.spin ?? 0) - (a.spin ?? 0)) * u;
  if (a.legs && b.legs) {
    for (let i = 0; i < 5; i++) out.legs[i] = a.legs[i] + (b.legs[i] - a.legs[i]) * u;
    out.hasLegs = true;
  } else out.hasLegs = false;
  return out;
}

export function blendPose(from: BladePose, to: BladePose, k: number, out: BladePose) {
  out.th = from.th + wrap(to.th - from.th) * k;
  out.el = from.el + (to.el - from.el) * k;
  out.gx = from.gx + (to.gx - from.gx) * k;
  out.gy = from.gy + (to.gy - from.gy) * k;
  out.gz = from.gz + (to.gz - from.gz) * k;
  out.sx = from.sx + (to.sx - from.sx) * k;
  out.torso = from.torso + (to.torso - from.torso) * k;
  out.spin = from.spin + (to.spin - from.spin) * k;
  if (to.hasLegs) {
    for (let i = 0; i < 5; i++) out.legs[i] = from.hasLegs ? from.legs[i] + (to.legs[i] - from.legs[i]) * k : to.legs[i];
    out.hasLegs = true;
  } else out.hasLegs = false;
  return out;
}

function P(th: number, el: number, gx: number, gy: number, gz: number, sx: number, torso: number, legs?: number[]) {
  const p = newBladePose();
  Object.assign(p, { th, el, gx, gy, gz, sx, torso });
  if (legs) {
    for (let i = 0; i < 5; i++) p.legs[i] = legs[i];
    p.hasLegs = true;
  }
  return p;
}

/** resting poses (between moves) */
export const POSES = {
  katanaStance: P(0.22, 0.4, 11, 9, 3, 0.96, 0.04, [10, -3, -12, -3, -46.5]),
  katanaRun: P(PI - 0.1, -0.36, -3, 16, -2, 1, 0.1),
  katanaGuard: P(0.3, 1.32, 12, -1, 6, 0.95, 0, [11, -3, -12, -3, -45.5]),
  katanaCharge: P(PI - 0.25, -0.55, -6, 14, -3, 0.78, 0.25, [14, -3, -14, -3, -41]),
  batStance: P(PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5]),
  batCarry: P(PI + 0.62, 0.52, -1, 2, -3, 1, 0.08),
  batCharge: P(PI + 0.95, 0.42, -8, 1, -4, 0.74, -0.16, [6, -12, -11, -3, -47.5]),
  fistStance: P(0, 0, 13, -6, 2, 1, 0.08, [11, -3, -12, -3, -46]),
  fistRun: P(0, 0, 13, -4, 2, 1, 0.12),
  fistGuard: P(0, 0, 11, -13, 2, 1, 0.02, [12, -3, -13, -3, -45]),
  fistCharge: P(0, 0, -4, 4, 2, 0.8, -0.18, [9, -3, -15, -3, -42]),
};

const K = (t: number, th: number, el: number, gx: number, gy: number, gz: number, sx: number, torso: number, legs?: number[], e = 0, spin?: number): MKey => ({
  t,
  th,
  el,
  gx,
  gy,
  gz,
  sx,
  torso,
  legs,
  e,
  spin,
});

const KSTANCE = [10, -3, -12, -3, -46.5];

export const MOVES: Record<string, MeleeMove> = {
  // =========================================================== KATANA
  // 1) KESA-GIRI: diagonal cut from high behind, sweeping through the front of the body (toward the camera)
  k1: {
    id: 'k1',
    w: 'katana',
    keys: [
      K(0, 2.5, 1.05, -1, -6, -2, 0.82, -0.06, [9, -3, -12, -3, -46.5]),
      K(0.055, 2.75, 1.22, -4, -9, -3, 0.74, -0.13, [8, -6, -12, -3, -47.5]),
      K(0.095, 1.5, 0.6, 6, 1, 8, 0.95, 0.08, [17, -3, -12, -3, -45.5], 1),
      K(0.13, 0.12, -0.35, 18, 11, 4, 1, 0.3, [19, -3, -12, -4, -44], 2),
      K(0.18, -0.95, -0.78, 14, 16, -2, 0.9, 0.32, [19, -3, -11, -5, -44], 3),
      K(0.34, -1.25, -0.52, 11, 13, -2, 0.92, 0.18, [17, -3, -11, -3, -45]),
    ],
    hit: [0.085, 0.165],
    chain: 0.18,
    end: 0.4,
    dmg: 2,
    boss: 5,
    dir: [1, -0.45],
    power: 650,
    zone: [-4, 96, -128, -6],
    next: 'k2',
    lunge: [190, 0.06, 0.13],
    shake: 4,
    stop: 0.045,
    tag: 'KATANA',
    trail: 1,
  },
  // 2) GYAKU-KESA: rising reverse diagonal from low on the far side up to high near the camera
  k2: {
    id: 'k2',
    w: 'katana',
    keys: [
      K(0, -1.25, -0.52, 11, 13, -2, 0.92, 0.18, [17, -3, -11, -3, -45]),
      K(0.05, -1.7, -0.75, 8, 15, -3, 0.84, 0.22, [15, -3, -12, -3, -44.5]),
      K(0.09, -0.55, -0.2, 15, 8, 2, 1, 0.14, [18, -3, -12, -3, -45], 1),
      K(0.12, 0.08, 0.5, 19, -1, 4, 1, 0, [18, -3, -12, -3, -46.5], 2),
      K(0.165, 0.95, 1.08, 10, -10, 6, 0.9, -0.12, [16, -3, -13, -3, -47.5], 3),
      K(0.32, 1.55, 1.18, 5, -11, 4, 0.86, -0.08, [13, -3, -13, -3, -47]),
    ],
    hit: [0.075, 0.15],
    chain: 0.17,
    end: 0.38,
    dmg: 2,
    boss: 5,
    dir: [0.8, -0.8],
    power: 620,
    zone: [-4, 94, -132, -6],
    next: 'k3',
    lunge: [150, 0.05, 0.12],
    shake: 4,
    stop: 0.045,
    tag: 'KATANA',
    trail: 1,
  },
  // 3) YOKO-GIRI: horizontal sweep with a big step — the tip comes straight at the viewer
  k3: {
    id: 'k3',
    w: 'katana',
    keys: [
      K(0, 1.55, 1.18, 5, -11, 4, 0.86, -0.08, [13, -3, -13, -3, -47]),
      K(0.06, 2.85, 0.18, -4, 2, 2, 0.74, -0.1, [8, -3, -15, -3, -44]),
      K(0.105, 1.5, 0.06, 8, 6, 10, 0.95, 0.1, [20, -3, -14, -3, -42.5], 1),
      K(0.14, 0, 0, 21, 8, 4, 1, 0.28, [21, -3, -13, -4, -42], 2),
      K(0.185, -1.5, 0.1, 16, 6, -4, 0.9, 0.3, [21, -3, -12, -5, -42.5], 3),
      K(0.33, -2.2, 0.42, 9, 0, -4, 0.86, 0.15, [18, -3, -12, -3, -44.5]),
    ],
    hit: [0.095, 0.17],
    chain: 0.19,
    end: 0.4,
    dmg: 2.5,
    boss: 6,
    dir: [1, -0.35],
    power: 760,
    zone: [-4, 102, -118, -6],
    next: 'k4',
    lunge: [300, 0.05, 0.15],
    shake: 6,
    stop: 0.06,
    tag: 'KATANA',
    trail: 1.1,
  },
  // 4) TATSUMAKI: full 360° spinning slash, hits both sides
  k4: {
    id: 'k4',
    w: 'katana',
    keys: [
      K(0, -2.2, 0.42, 9, 0, -4, 0.86, 0.15, [18, -3, -12, -3, -44.5], 0, 0),
      K(0.05, 0, 0.02, 15, 6, 0, 1, 0.05, [9, -14, -9, -3, -50], 0, 0),
      K(0.21, 0, 0.05, 16, 6, 0, 1, 0.05, [9, -6, -9, -3, -49], 2, TAU),
      K(0.37, -0.6, -0.32, 12, 10, -2, 0.95, 0.15, [15, -3, -12, -3, -45.5], 3, TAU),
    ],
    hit: [0.05, 0.21],
    chain: 0.23,
    end: 0.42,
    dmg: 2,
    boss: 4,
    dir: [1, -0.55],
    power: 700,
    zone: [-98, 98, -122, -6],
    next: 'k5',
    spin: true,
    hop: [-260, 0.05],
    shake: 5,
    stop: 0.05,
    tag: 'TATSUMAKI',
    trail: 1,
  },
  // 5) KABUTO-WARI: leaping overhead cleave in the screen plane — the finisher, always cuts in half
  k5: {
    id: 'k5',
    w: 'katana',
    keys: [
      K(0, -0.6, -0.32, 12, 10, -2, 0.95, 0.15, [15, -3, -12, -3, -45.5]),
      K(0.08, PI, 1.38, 0, -15, 0, 0.95, -0.18, [9, -9, -10, -3, -49.5]),
      K(0.125, PI, 1.48, -1, -17, 0, 0.95, -0.2, [10, -10, -10, -3, -50]),
      K(0.17, PI, PI + 0.85, 20, 16, 2, 1, 0.46, [23, -3, -16, -3, -38], 1),
      K(0.27, PI, PI + 0.92, 19, 18, 2, 1, 0.42, [23, -3, -16, -3, -38], 3),
      K(0.5, PI, PI - 0.4, 11, 8, 3, 1, 0.04, KSTANCE),
    ],
    hit: [0.145, 0.22],
    chain: 0.5,
    end: 0.52,
    dmg: 6,
    boss: 12,
    dir: [0.7, -0.5],
    power: 900,
    zone: [-4, 106, -138, 4],
    lunge: [380, 0.09, 0.17],
    sever: 1,
    slam: true,
    heavy: true,
    shake: 12,
    stop: 0.12,
    tag: 'KABUTO-WARI',
    trail: 1.35,
  },
  // W + attack: TEBASAN NAGA — rising launcher, the ninja follows the enemy into the air
  kRise: {
    id: 'kRise',
    w: 'katana',
    keys: [
      K(0, 0.1, -0.9, 14, 16, 2, 1, 0.3, [14, -3, -14, -3, -40]),
      K(0.06, 0.1, -1.0, 13, 17, 2, 1, 0.34, [14, -3, -14, -3, -38.5]),
      K(0.11, 0.1, 0.55, 18, -2, 3, 1, 0.02, [14, -3, -12, -3, -49], 1),
      K(0.16, 0.2, 1.42, 8, -17, 3, 0.95, -0.15, undefined, 3),
      K(0.34, 0.2, 1.3, 7, -14, 3, 0.95, -0.1),
    ],
    hit: [0.08, 0.16],
    chain: 0.2,
    end: 0.36,
    dmg: 1.5,
    boss: 4,
    dir: [0.2, -1],
    power: 700,
    zone: [-6, 94, -152, -4],
    launch: 820,
    hop: [-780, 0.1],
    shake: 5,
    stop: 0.06,
    tag: 'TEBASAN NAGA',
    trail: 1.1,
  },
  // in the air: KAZE-GURUMA — a whirlwind spin slash that hangs in the air (chains up to 3x)
  kAir: {
    id: 'kAir',
    w: 'katana',
    keys: [
      K(0, 2.6, 0.5, 2, 0, -2, 0.9, 0, undefined, 0, 0),
      K(0.04, 0, 0.05, 14, 4, 0, 1, 0.05, undefined, 0, 0),
      K(0.19, 0, 0.08, 15, 4, 0, 1, 0.05, undefined, 2, TAU),
      K(0.3, -0.4, -0.2, 12, 8, -2, 1, 0.1, undefined, 3, TAU),
    ],
    hit: [0.04, 0.19],
    chain: 0.2,
    end: 0.32,
    dmg: 2,
    boss: 5,
    dir: [1, -0.6],
    power: 650,
    zone: [-92, 92, -120, 12],
    next: 'kAir',
    spin: true,
    air: true,
    hover: [60, 0.22],
    shake: 4,
    stop: 0.045,
    tag: 'KAZE-GURUMA',
    trail: 1,
  },
  // in the air + S: falling stab
  kPlunge: {
    id: 'kPlunge',
    w: 'katana',
    keys: [K(0, 0, 0.9, 6, -8, 2, 1, -0.1), K(0.07, 0, -1.45, 6, 18, 2, 1, 0.15, undefined, 1), K(3, 0, -1.5, 6, 19, 2, 1, 0.15)],
    hit: [0.07, 3],
    chain: 99,
    end: 3,
    dmg: 6,
    boss: 12,
    dir: [0.2, 1],
    power: 600,
    zone: [-28, 28, -34, 30],
    plunge: true,
    air: true,
    shake: 10,
    stop: 0.1,
    tag: 'TUSUKAN',
    trail: 0,
  },
  kLand: {
    id: 'kLand',
    w: 'katana',
    keys: [K(0, 0, -1.5, 6, 20, 2, 1, 0.3, [12, -3, -12, -3, -34]), K(0.26, 0, -1.4, 7, 18, 2, 1, 0.25, [11, -3, -12, -3, -40]), K(0.42, 0.22, 0.4, 11, 9, 3, 0.96, 0.04, KSTANCE)],
    hit: [9, 9],
    chain: 0.3,
    end: 0.44,
    dmg: 0,
    boss: 0,
    dir: [0, 0],
    power: 0,
    zone: [0, 0, 0, 0],
    shake: 0,
    stop: 0,
    tag: '',
    trail: 0,
  },
  // flying swallow pose (movement + contact handled by the game)
  kSwallow: {
    id: 'kSwallow',
    w: 'katana',
    keys: [K(0, 2.6, 0.9, 0, -6, -2, 0.9, 0), K(0.08, 0, -0.1, 18, 8, 3, 1, 0.2, undefined, 1), K(2, 0, -0.1, 18, 8, 3, 1, 0.2)],
    hit: [9, 9],
    chain: 99,
    end: 2,
    dmg: 0,
    boss: 0,
    dir: [1, -0.4],
    power: 0,
    zone: [0, 0, 0, 0],
    air: true,
    shake: 0,
    stop: 0,
    tag: 'TERBANG WALET',
    trail: 0,
  },
  // IAI: the dash (movement handled by the player)
  kIaiDash: {
    id: 'kIaiDash',
    w: 'katana',
    keys: [
      K(0, PI - 0.25, -0.55, -6, 14, -3, 0.78, 0.25, [14, -3, -14, -3, -41]),
      K(0.05, 0, -0.1, 20, 9, 3, 1, 0.3, [24, -3, -18, -6, -40], 1),
      K(0.14, -0.5, -0.45, 18, 12, -2, 1, 0.36, [24, -3, -18, -6, -39], 3),
    ],
    hit: [9, 9],
    chain: 99,
    end: 0.14,
    auto: 'kIaiHold',
    dmg: 0,
    boss: 0,
    dir: [1, -0.4],
    power: 900,
    zone: [0, 0, 0, 0],
    shake: 0,
    stop: 0,
    tag: 'IAI',
    trail: 0,
  },
  // IAI: zanshin — frozen stillness, the enemies fall apart, then a twirl and the sheath click
  kIaiHold: {
    id: 'kIaiHold',
    w: 'katana',
    keys: [
      K(0, -0.5, -0.45, 18, 12, -2, 1, 0.36, [24, -3, -18, -6, -39]),
      K(0.42, -0.62, -0.55, 18, 13, -2, 1, 0.38, [24, -3, -18, -6, -39]),
      K(0.62, -0.62, -0.55 + TAU, 12, 8, 2, 1, 0.1, [12, -3, -12, -3, -45], 2),
      K(0.9, PI - 0.2, -0.4, -4, 14, -3, 0.9, 0.05, KSTANCE, 3),
    ],
    hit: [9, 9],
    chain: 99,
    end: 0.95,
    dmg: 0,
    boss: 0,
    dir: [1, -0.4],
    power: 0,
    zone: [0, 0, 0, 0],
    shake: 0,
    stop: 0,
    tag: 'IAI',
    trail: 0,
  },

  // =========================================================== BASEBALL BAT
  // 1) HOME RUN: load, stride, whip around in front of the chest, full extension, wrap
  b1: {
    id: 'b1',
    w: 'bat',
    keys: [
      K(0, PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5]),
      K(0.085, PI + 0.55, 0.8, -7, -7, -3, 0.8, -0.1, [4, -13, -10, -3, -48]),
      K(0.12, PI + 1.05, 0.3, -3, 4, -4, 0.84, -0.06, [19, -3, -12, -3, -45]),
      K(0.16, 1.5, 0.12, 9, 10, 8, 0.95, 0.12, [19, -3, -11, -5, -44.5], 1),
      K(0.19, 0, -0.05, 20, 11, 6, 1, 0.28, [19, -3, -10, -7, -44], 2),
      K(0.225, -1.4, 0.15, 18, 5, 2, 0.92, 0.3, [19, -3, -8, -8, -44.5], 2),
      K(0.31, -2.55, 0.65, 6, -8, -4, 0.86, 0.18, [18, -3, -6, -9, -45.5], 3),
      K(0.47, -PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5]),
    ],
    hit: [0.15, 0.235],
    chain: 0.27,
    end: 0.49,
    dmg: 99,
    boss: 14,
    dir: [1, -0.68],
    power: 1750,
    zone: [-8, 98, -118, -6],
    next: 'b2',
    shake: 13,
    stop: 0.1,
    tag: 'HOME RUN',
    trail: 1,
  },
  // 2) BACKHAND: the return swing from the finish, sweeping the other way round
  b2: {
    id: 'b2',
    w: 'bat',
    keys: [
      K(0, -2.55, 0.65, 6, -8, -4, 0.86, 0.18, [18, -3, -6, -9, -45.5]),
      K(0.06, -2.85, 0.55, 3, -6, -5, 0.8, 0.26, [16, -3, -9, -5, -45]),
      K(0.1, -1.3, 0.15, 14, 4, -2, 0.92, 0.1, [17, -3, -12, -3, -44.5], 1),
      K(0.13, 0, 0, 20, 8, 2, 1, -0.02, [18, -3, -13, -3, -44.5], 2),
      K(0.17, 1.4, 0.2, 12, 6, 8, 0.9, -0.12, [16, -3, -14, -3, -45], 2),
      K(0.27, 2.6, 0.7, 1, -4, 3, 0.85, -0.04, [12, -3, -13, -3, -46], 3),
      K(0.42, PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5]),
    ],
    hit: [0.09, 0.17],
    chain: 0.24,
    end: 0.44,
    dmg: 99,
    boss: 10,
    dir: [1, -0.5],
    power: 1500,
    zone: [-8, 96, -118, -6],
    next: 'b3',
    shake: 10,
    stop: 0.08,
    tag: 'BACKHAND',
    trail: 1,
  },
  // 3) OVERHEAD SMASH: bat straight up, then slammed down into the floor (shockwave)
  b3: {
    id: 'b3',
    w: 'bat',
    keys: [
      K(0, 2.9, 1.2, -1, -8, -1, 0.95, -0.05, [11, -3, -12, -3, -47]),
      K(0.09, PI, 1.5, -1, -16, 0, 0.95, -0.2, [9, -9, -11, -3, -50]),
      K(0.13, PI, 1.62, -2, -18, 0, 0.95, -0.24, [9, -11, -11, -3, -50.5]),
      K(0.18, PI, PI + 0.95, 19, 15, 1, 1, 0.5, [23, -3, -16, -3, -37], 1),
      K(0.3, PI, PI + 1.0, 19, 17, 1, 1, 0.46, [23, -3, -16, -3, -37], 3),
      K(0.52, PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5]),
    ],
    hit: [0.155, 0.23],
    chain: 0.52,
    end: 0.54,
    dmg: 99,
    boss: 20,
    dir: [0.35, 0.7],
    power: 1700,
    zone: [-8, 104, -140, 6],
    slam: true,
    heavy: true,
    lunge: [220, 0.1, 0.17],
    shake: 16,
    stop: 0.12,
    tag: 'HANTAMAN',
    trail: 1.3,
  },
  // charged: GRAND SLAM
  bSlam: {
    id: 'bSlam',
    w: 'bat',
    keys: [
      K(0, PI + 0.95, 0.42, -8, 1, -4, 0.74, -0.16, [6, -12, -11, -3, -47.5]),
      K(0.05, PI + 1.1, 0.3, -4, 4, -4, 0.8, -0.08, [20, -3, -13, -3, -44.5]),
      K(0.085, 1.5, 0.1, 9, 10, 8, 0.95, 0.14, [21, -3, -12, -5, -43.5], 1),
      K(0.11, 0, -0.04, 21, 11, 6, 1, 0.32, [21, -3, -10, -7, -43], 2),
      K(0.15, -1.5, 0.2, 18, 4, 2, 0.9, 0.34, [21, -3, -8, -9, -43.5], 2),
      K(0.26, -2.7, 0.75, 5, -9, -4, 0.84, 0.2, [19, -3, -6, -10, -45], 3),
      K(0.5, -PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5]),
    ],
    hit: [0.075, 0.16],
    chain: 0.5,
    end: 0.52,
    dmg: 99,
    boss: 30,
    dir: [1, -0.75],
    power: 2600,
    zone: [-8, 108, -125, -4],
    heavy: true,
    lunge: [260, 0.04, 0.1],
    shake: 18,
    stop: 0.16,
    tag: 'GRAND SLAM',
    trail: 1.5,
  },
  // in the air: overhead smash that dives to the floor
  bAir: {
    id: 'bAir',
    w: 'bat',
    keys: [K(0, PI, 1.3, 0, -12, 0, 1, -0.15), K(0.08, PI, PI + 0.9, 16, 14, 1, 1, 0.4, undefined, 1), K(3, PI, PI + 1.0, 16, 15, 1, 1, 0.4)],
    hit: [0.05, 3],
    chain: 99,
    end: 3,
    dmg: 99,
    boss: 16,
    dir: [0.4, 0.7],
    power: 1500,
    zone: [-20, 72, -104, 30],
    plunge: true,
    air: true,
    heavy: true,
    shake: 12,
    stop: 0.1,
    tag: 'HANTAMAN UDARA',
    trail: 0,
  },
  bLand: {
    id: 'bLand',
    w: 'bat',
    keys: [K(0, PI, PI + 1.0, 16, 16, 1, 1, 0.45, [22, -3, -16, -3, -37]), K(0.24, PI, PI + 0.95, 16, 15, 1, 1, 0.4, [20, -3, -15, -3, -40]), K(0.46, PI + 0.25, 1.0, -2, -5, -2, 1, 0.06, [9, -3, -11, -3, -46.5])],
    hit: [9, 9],
    chain: 0.32,
    end: 0.48,
    dmg: 0,
    boss: 0,
    dir: [0, 0],
    power: 0,
    zone: [0, 0, 0, 0],
    shake: 0,
    stop: 0,
    tag: '',
    trail: 0,
  },
};

/** katana drawn as a projected 3D blade: curved, foreshortened, with a guard disc seen at the right angle */
export function drawKatana3D(ctx: CanvasRenderingContext2D, b: Bat3, glow = 0, shine = -1, outline = '#1b1410') {
  const pl = Math.hypot(b.dx, b.dy);
  let ux = 1;
  let uy = 0;
  if (pl > 0.02) {
    ux = b.dx / pl;
    uy = b.dy / pl;
  }
  const nx = -uy;
  const ny = ux;
  const near = Math.max(0, b.dz);
  const persp = 1 + 0.3 * near;
  const D = (d: number) => ({ x: b.gx + b.dx * d, y: b.gy + b.dy * d });
  const pom = D(-KATANA.pommel);
  const tsu = D(KATANA.handle);
  const tip = D(KATANA.reach);
  const mid = D(KATANA.handle + KATANA.blade * 0.55);
  const curve = 3.4 * pl;
  const cx = mid.x + nx * curve;
  const cy = mid.y + ny * curve;
  const w0 = 2.5;
  const w1 = 1.8 * persp;
  const ang = Math.atan2(uy, ux);
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const blade = () => {
    ctx.beginPath();
    ctx.moveTo(tsu.x + nx * w0, tsu.y + ny * w0);
    ctx.quadraticCurveTo(cx + nx * w1, cy + ny * w1, tip.x + nx * 0.4, tip.y + ny * 0.4);
    ctx.quadraticCurveTo(cx - nx * w1 * 0.85, cy - ny * w1 * 0.85, tsu.x - nx * w0, tsu.y - ny * w0);
    ctx.closePath();
  };
  const drawBlade = () => {
    if (glow > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = `rgba(120,215,255,${0.35 * glow})`;
      ctx.lineWidth = 9 + 6 * glow;
      ctx.beginPath();
      ctx.moveTo(tsu.x, tsu.y);
      ctx.quadraticCurveTo(cx, cy, tip.x, tip.y);
      ctx.stroke();
      ctx.restore();
    }
    blade();
    ctx.lineWidth = 2.6;
    ctx.strokeStyle = outline;
    ctx.stroke();
    const g = ctx.createLinearGradient(mid.x + nx * 4, mid.y + ny * 4, mid.x - nx * 4, mid.y - ny * 4);
    g.addColorStop(0, '#6e7a86');
    g.addColorStop(0.42, '#dfe7ee');
    g.addColorStop(0.62, '#ffffff');
    g.addColorStop(1, '#a3afbb');
    ctx.fillStyle = g;
    ctx.fill();
    // hamon (temper line) along the edge
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(tsu.x - nx * 1.2, tsu.y - ny * 1.2);
    ctx.quadraticCurveTo(cx - nx * 0.6, cy - ny * 0.6, tip.x - ux * 3, tip.y - uy * 3);
    ctx.stroke();
    if (shine >= 0 && shine <= 1) {
      const s = D(KATANA.handle + KATANA.blade * shine);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const sg = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, 9);
      sg.addColorStop(0, 'rgba(255,255,255,0.95)');
      sg.addColorStop(1, 'rgba(200,235,255,0)');
      ctx.fillStyle = sg;
      ctx.beginPath();
      ctx.arc(s.x, s.y, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    // tip glint when the point faces the camera
    if (b.dz > 0.55 || glow > 0.5) {
      const k = Math.max(glow, (b.dz - 0.55) / 0.45);
      const r = 3 + 6 * k;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = `rgba(255,255,255,${0.6 + 0.4 * k})`;
      ctx.beginPath();
      ctx.moveTo(tip.x - r, tip.y);
      ctx.lineTo(tip.x, tip.y - r * 0.25);
      ctx.lineTo(tip.x + r, tip.y);
      ctx.lineTo(tip.x, tip.y + r * 0.25);
      ctx.closePath();
      ctx.moveTo(tip.x, tip.y - r);
      ctx.lineTo(tip.x + r * 0.25, tip.y);
      ctx.lineTo(tip.x, tip.y + r);
      ctx.lineTo(tip.x - r * 0.25, tip.y);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  };
  const drawHilt = () => {
    // tsuka: black cord wrap over white ray skin
    ctx.strokeStyle = outline;
    ctx.lineWidth = 6.6;
    ctx.beginPath();
    ctx.moveTo(pom.x, pom.y);
    ctx.lineTo(tsu.x, tsu.y);
    ctx.stroke();
    ctx.strokeStyle = '#efe9dc';
    ctx.lineWidth = 4.2;
    ctx.stroke();
    ctx.strokeStyle = '#1f1a17';
    ctx.lineWidth = 2.4;
    const n = 4;
    for (let i = 0; i < n; i++) {
      const a = D(-KATANA.pommel + ((KATANA.pommel + KATANA.handle) * (i + 0.15)) / n);
      const c = D(-KATANA.pommel + ((KATANA.pommel + KATANA.handle) * (i + 0.85)) / n);
      ctx.beginPath();
      ctx.moveTo(a.x + nx * 2, a.y + ny * 2);
      ctx.lineTo(c.x - nx * 2, c.y - ny * 2);
      ctx.moveTo(a.x - nx * 2, a.y - ny * 2);
      ctx.lineTo(c.x + nx * 2, c.y + ny * 2);
      ctx.stroke();
    }
    ctx.fillStyle = '#c9a14a';
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.arc(pom.x, pom.y, 2.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  };
  const drawGuard = () => {
    // tsuba: a disc perpendicular to the blade — circle when the blade points at us, a sliver side-on
    const rx = Math.max(1.3, 5.2 * Math.abs(b.dz));
    ctx.fillStyle = '#2f2618';
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(tsu.x, tsu.y, rx, 5.2, ang, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = '#c9a14a';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.ellipse(tsu.x, tsu.y, Math.max(0.6, rx - 1.2), 4, ang, 0, Math.PI * 2);
    ctx.stroke();
  };
  if (b.dz > 0.1) {
    drawHilt();
    drawGuard();
    drawBlade();
  } else {
    drawBlade();
    drawHilt();
    drawGuard();
  }
  ctx.restore();
}

// =========================================================== FISTS (kung fu)
const FK = (t: number, gx: number, gy: number, sx: number, torso: number, legs?: number[], e = 0) => K(t, 0, 0, gx, gy, 2, sx, torso, legs, e);
const FS = [11, -3, -12, -3, -46];
const FIST_MOVES: Record<string, MeleeMove> = {
  f1: {
    id: 'f1', w: 'fist', hand: 0,
    keys: [FK(0, 13, -6, 1, 0.08, FS), FK(0.05, 33, -4, 1, 0.16, [15, -3, -12, -3, -45], 1), FK(0.11, 31, -4, 1, 0.15, [15, -3, -12, -3, -45]), FK(0.22, 13, -6, 1, 0.08, FS)],
    hit: [0.035, 0.1], chain: 0.1, end: 0.24, dmg: 1, boss: 2, struct: 1, dir: [1, -0.3], power: 420,
    zone: [0, 64, -104, -46], next: 'f2', lunge: [150, 0.02, 0.07], shake: 2, stop: 0.035, tag: 'TINJU', trail: 0,
  },
  f2: {
    id: 'f2', w: 'fist', hand: 1,
    keys: [FK(0, 9, -2, 1, 0.08, FS), FK(0.06, 35, -4, 0.8, 0.26, [16, -3, -9, -6, -45], 1), FK(0.12, 33, -4, 0.82, 0.25, [16, -3, -9, -6, -45]), FK(0.26, 9, -2, 1, 0.1, FS)],
    hit: [0.04, 0.11], chain: 0.11, end: 0.27, dmg: 1, boss: 2, struct: 1.5, dir: [1, -0.3], power: 480,
    zone: [0, 66, -104, -46], next: 'f3', lunge: [130, 0.03, 0.08], shake: 3, stop: 0.04, tag: 'TINJU', trail: 0,
  },
  f3: {
    id: 'f3', w: 'fist', hand: 0,
    keys: [FK(0, 13, -6, 1, 0.1, FS), FK(0.05, 6, -10, 0.85, -0.05, [13, -3, -12, -3, -46]), FK(0.1, 28, -8, 0.78, 0.3, [17, -3, -11, -5, -44.5], 1), FK(0.15, 24, -6, 0.8, 0.32, [17, -3, -11, -5, -44.5]), FK(0.3, 13, -6, 1, 0.1, FS)],
    hit: [0.08, 0.15], chain: 0.15, end: 0.31, dmg: 1.25, boss: 2.5, struct: 2, dir: [1, -0.45], power: 560,
    zone: [0, 62, -108, -48], next: 'f4', lunge: [120, 0.05, 0.1], shake: 4, stop: 0.05, tag: 'HOOK', trail: 0,
  },
  f4: {
    id: 'f4', w: 'fist', hand: 2,
    keys: [FK(0, 13, -6, 1, 0.08, FS), FK(0.07, 13, -8, 1, -0.05, [12, -32, -11, -3, -47]), FK(0.12, 13, -8, 1, -0.4, [48, -60, -12, -3, -49.5], 1), FK(0.19, 13, -8, 1, -0.38, [46, -58, -12, -3, -49.5]), FK(0.28, 13, -6, 1, -0.05, [14, -16, -12, -3, -47]), FK(0.38, 13, -6, 1, 0.08, FS)],
    hit: [0.1, 0.2], chain: 0.21, end: 0.4, dmg: 1.5, boss: 3, struct: 2.5, dir: [1, -0.5], power: 760, knock: 380,
    zone: [8, 86, -124, -60], next: 'f5', shake: 6, stop: 0.06, tag: 'TENDANGAN MEMUTAR', trail: 0,
  },
  f5: {
    id: 'f5', w: 'fist', hand: 3,
    keys: [FK(0, 13, -6, 1, 0.08, FS), FK(0.08, -2, 2, 0.85, -0.15, [9, -3, -14, -3, -44]), FK(0.13, 34, 4, 1, 0.34, [23, -3, -15, -3, -40], 1), FK(0.21, 32, 4, 1, 0.32, [23, -3, -15, -3, -40]), FK(0.42, 13, -6, 1, 0.08, FS)],
    hit: [0.11, 0.2], chain: 0.42, end: 0.44, dmg: 2, boss: 4, struct: 5, dir: [1, -0.55], power: 1150, knock: 720,
    heavy: true, zone: [0, 74, -110, -38], lunge: [260, 0.08, 0.14], shake: 10, stop: 0.1, tag: 'TELAPAK GANDA', trail: 0,
  },
  fUpper: {
    id: 'fUpper', w: 'fist', hand: 1,
    keys: [FK(0, 9, -2, 1, 0.1, FS), FK(0.06, 10, 14, 0.85, 0.4, [15, -3, -13, -3, -38]), FK(0.12, 22, -30, 0.95, -0.15, [14, -3, -12, -3, -49], 1), FK(0.18, 20, -34, 1, -0.18, [14, -3, -12, -3, -49]), FK(0.34, 9, -2, 1, 0.08, FS)],
    hit: [0.09, 0.17], chain: 0.18, end: 0.36, dmg: 1.5, boss: 3, struct: 2, dir: [0.2, -1], power: 700, launch: 760,
    hop: [-430, 0.11], zone: [0, 66, -130, -40], shake: 6, stop: 0.06, tag: 'UPPERCUT', trail: 0,
  },
  fSweep: {
    id: 'fSweep', w: 'fist', hand: 2,
    keys: [FK(0, 13, -6, 1, 0.1, FS), FK(0.07, 10, 4, 1, 0.55, [10, -3, -12, -3, -30]), FK(0.13, 10, 6, 1, 0.6, [46, -4, -12, -3, -28], 1), FK(0.2, 10, 6, 1, 0.58, [44, -4, -12, -3, -28]), FK(0.4, 13, -6, 1, 0.08, FS)],
    hit: [0.1, 0.2], chain: 0.22, end: 0.42, dmg: 1, boss: 2, struct: 3, dir: [1, -0.6], power: 500,
    zone: [4, 88, -44, 6], shake: 4, stop: 0.05, tag: 'SAPUAN', trail: 0,
  },
  fAir: {
    id: 'fAir', w: 'fist', hand: 2,
    keys: [FK(0, 13, -8, 1, 0.05, [12, -26, -10, -12, -48]), FK(0.06, 13, -8, 1, -0.32, [46, -40, -12, -18, -48], 1), FK(0.36, 13, -8, 1, -0.3, [44, -38, -12, -18, -48])],
    hit: [0.05, 0.3], chain: 0.32, end: 0.38, dmg: 2, boss: 4, struct: 3, dir: [1, -0.4], power: 800, knock: 420,
    air: true, zone: [6, 84, -112, -30], shake: 6, stop: 0.06, tag: 'TENDANGAN UDARA', trail: 0,
  },
  fPalm: {
    id: 'fPalm', w: 'fist', hand: 3,
    keys: [FK(0, -4, 4, 0.78, -0.2, [8, -3, -15, -3, -42]), FK(0.05, 36, 2, 1, 0.38, [24, -3, -16, -3, -39], 1), FK(0.14, 34, 2, 1, 0.36, [24, -3, -16, -3, -39]), FK(0.46, 13, -6, 1, 0.08, FS)],
    hit: [0.035, 0.13], chain: 0.46, end: 0.48, dmg: 3, boss: 6, struct: 10, dir: [1, -0.6], power: 1500, knock: 900,
    heavy: true, lunge: [320, 0.02, 0.09], zone: [0, 78, -112, -36], shake: 14, stop: 0.13, tag: 'SATU INCI', trail: 0,
  },
};
Object.assign(MOVES, FIST_MOVES);
