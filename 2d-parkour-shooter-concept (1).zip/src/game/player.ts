import {
  aimArm,
  buildBody,
  lerpPose,
  newPose,
  newWorldPose,
  PLAYER_DIMS,
  reachArm,
  snapshotPose,
  type Pose,
  type WorldPose,
  type Xform,
} from './character';
import type { ZiplineDef } from './level';
import { angleLerp, approach, clamp, easeInOut, lerp, rand, sign, smooth, smoothstep, TAU } from './math';
import type { Particles } from './particles';
import type { Sound } from './audio';
import type { DynSolid, MoveResult, Solid, World } from './world';
import { BAT, CRICKET, SLING, WEAPON_INFO, WEAPON_ORDER, type WeaponId } from './weapons';
import type { Bat3 } from './character';
import {
  blendPose,
  copyPose,
  KATANA,
  MOVES,
  newBladePose,
  normalizePose,
  POSES,
  sampleMove,
  type BladePose,
  type MeleeMove,
} from './melee';

const PI = Math.PI;

export interface PlayerInput {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  jumpPressed: boolean;
  downPressed: boolean;
  spinPressed: boolean;
  spinHeld: boolean;
  kickPressed: boolean;
  fireHeld: boolean;
  splitHeld: boolean;
  walk: boolean;
  aimX: number;
  aimY: number;
}

export interface PlayerHost {
  world: World;
  sfx: Sound;
  particles: Particles;
  ziplines: ZiplineDef[];
  time: number;
  breakGlass(d: DynSolid, vx: number, vy: number): void;
  kickAt(x: number, y: number, w: number, h: number, dir: number): boolean;
  shake(a: number): void;
  popup(text: string, x: number, y: number, color: string): void;
  breach(d: DynSolid, dir: number, footY: number): void;
  wallSplat(x: number, y: number, dir: number): void;
  kickAt(x: number, y: number, w: number, h: number, dir: number): boolean;
  groundPound(x: number, y: number, power: number): void;
  camKick(x: number, y: number): void;
}

export type FlipKind = 'front' | 'wall' | 'back' | 'layout' | 'double' | 'aerial' | 'superman';

export const FLIP_TAG: Record<FlipKind, string> = {
  front: 'FRONT FLIP',
  wall: 'WALL FLIP',
  back: 'BACKFLIP',
  layout: 'BACKFLIP',
  double: 'DOUBLE FLIP',
  aerial: 'AERIAL',
  superman: 'SUPERMAN',
};

/** stunts that rotate the whole body head-over-heels */
const ROT_KINDS: FlipKind[] = ['front', 'wall', 'back', 'layout', 'double', 'aerial'];
export const ROLL_T = 0.46;

// ---- door kick (right leg) timeline, in game seconds
const DK_CHAMBER = 0.13;
const DK_IMPACT = 0.17;
const DK_RETRACT = 0.27;
const DK_STEP = 0.35;
const DK_END = 0.48;

const RUN = 410;
const WALK_SPEED = 165;
const CROUCH_SPEED = 170;
const ACC_GROUND = 3300;
const ACC_AIR = 1800;
const FRICTION = 2800;
const GRAV = 2200;
const JUMP_V = 820;
const DOUBLE_V = 770;
const WALL_VX = 440;
const WALL_VY = 800;
const MAX_FALL = 1500;
const WALL_SLIDE = 170;
export const RELOAD_T = 0.85;

export const PLAYER_W = 26;
export const H_STAND = 94;
export const H_CROUCH = 52;
export const H_SLIDE = 46;

export interface Ghost {
  pts: Float32Array;
  life: number;
}

export class Player {
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  w = PLAYER_W;
  h = H_STAND;
  facing = 1;
  onGround = false;
  groundOneWay = false;
  hp = 100;
  maxHp = 100;
  noRegen = false;
  dazed = 0;
  guardStruct = 0;
  focus = 100;
  alive = true;

  crouch = false;
  slide = 0;
  roll = 0;
  rollDir = 1;
  flipping = false;
  flipRot = 0;
  flipDir = 1;
  flipSpeed = TAU / 0.55;
  flipTotal = TAU;
  flipKind: FlipKind = 'front';
  flipKeepFacing = false;
  spin = 0;
  spinAngle = 0;
  spinCd = 0;
  wallSide = 0;
  lastWallSide = 0;
  wallCoyote = 0;
  wallJumpLock = -1;
  wallFlipAt = -10;
  coyote = 0;
  jumpBuffer = 0;
  jumpHeld = false;
  dropThrough = 0;
  airJumps = 1;
  stuntIdx = 0;
  backIdx = 0;
  usedStunt = false;
  downHeld = false;
  flipTime = 0;
  flipDur = 0.55;
  flipSwish = 0;
  flipRate = 1;
  dkOn = false;
  dkT = 0;
  dkRef = -1;
  dkDir = 1;
  dkHit = false;
  dkAir = false;
  dkStandX = 0;
  rollFrom = 0;
  trail: number[] = [];
  trail2: number[] = [];
  kick = 0;
  kickHitDone = false;
  vault = 0;
  vaultHX = 0;
  vaultHY = 0;
  vaultX0 = 0;
  vaultX1 = 0;
  vaultGlide = false;
  visOff = 0;
  heavyLand = 0;
  skid = 0;
  backBusy = false;
  zip: ZiplineDef | null = null;
  zipT = 0;
  zipSpeed = 0;
  zipCd = 0;
  airTime = 0;
  maxFall = 0;
  landT = 0;
  landPower = 0;
  runPhase = 0;
  animT = 0;
  blinkT = 2;
  prevSpeed = 0;
  accelLean = 0;
  landSpring = 0;
  landVel = 0;
  landStyle: 'kneel' | 'slam' = 'kneel';
  gunRunBlend = 0;
  walkMode = false;

  weapon: WeaponId = 'pistol';
  inv: Partial<Record<WeaponId, [number, number]>> = { pistol: [12, 12], fist: [1, 0] };
  pumpT = 0;
  pumpEvent = false;
  boltT = 0;
  boltEvent = false;
  heat = 0;
  swapT = 0;
  emptyT = 0;
  scoping = false;
  // ---- melee (katana / bat): keyframed 3D moves
  mv: MeleeMove | null = null;
  mvT = 0;
  mvHit: number[] = [];
  mvQueued: string | null = null;
  mvFrom: BladePose = newBladePose();
  mvBlend = 0.05;
  mvLast: string | null = null;
  mvLastEndT = -9;
  mvAir = 0;
  mvSwish = false;
  mvSlam = false;
  mvCount = 0;
  meleeHeld = 0;
  meleeCharge = 0;
  guard = false;
  iaiX0 = 0;
  iaiX1 = 0;
  swallowT = -1;
  swallowX = 0;
  swallowY = 0;
  swallowId = -1;
  plungeLand = false;
  bladePose: BladePose = newBladePose();
  private poseTmp: BladePose = newBladePose();
  private poseTmp2: BladePose = newBladePose();
  grip = { x: 0, y: 0 };
  blade3: Bat3 = { gx: 0, gy: 0, dx: 0, dy: -1, dz: 0, L: BAT.len };
  bladeFront = false;
  bladeShine = -1;
  lastRot = 0;
  slingCharge = 0;
  slingHeld = false;
  slingPower = 0;
  slingFork = { x: 0, y: 0 };
  slingTips = [0, 0, 0, 0];
  slingPouch = { x: 0, y: 0 };
  cricketCharge = 0;
  cricketFire = false;
  cricketFly = 0;
  dive = false;
  diveT = 0;
  diveVx = 700;
  mag: [number, number] = this.inv.pistol as [number, number];
  reload = 0;
  reloadStarted = false;
  fireCd = 0;
  nextGun = 0;
  recoil: [number, number] = [0, 0];
  flash: [number, number] = [0, 0];
  lastShot = -10;
  aimBlend = 1;
  aimF = 0;
  aimB = 0;

  regenDelay = 0;
  hurtT = 0;
  invuln = 0;

  pose: Pose = newPose();
  target: Pose = newPose();
  wp: WorldPose = newWorldPose();
  xf: Xform = { ox: 0, oy: 0, facing: 1, rot: 0, cx: 0, cy: -50, sx: 1 };
  ghosts: Ghost[] = [];
  ghostT = 0;
  private res: MoveResult = { hitX: 0, hitY: 0, onGround: false, ground: null, wallSolid: null, dynHit: null };

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.pose.py = -49;
  }

  get dims() {
    return PLAYER_DIMS;
  }

  get centerY() {
    return this.y - this.h * 0.55;
  }

  get dodging() {
    return this.spin > 0 || this.roll > 0;
  }

  /** 0..1 progress of the current stunt */
  get stuntK() {
    if (this.flipping) return clamp(this.flipTime / this.flipDur, 0, 1);
    return clamp(Math.abs(this.flipRot) / this.flipTotal, 0, 1);
  }

  reset(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.hp = this.maxHp;
    this.dazed = 0;
    this.guardStruct = 0;
    this.focus = Math.max(this.focus, 60);
    this.alive = true;
    this.slide = 0;
    this.roll = 0;
    this.flipping = false;
    this.flipRot = 0;
    this.spin = 0;
    this.zip = null;
    this.kick = 0;
    this.vault = 0;
    this.heavyLand = 0;
    this.skid = 0;
    this.crouch = false;
    this.h = H_STAND;
    this.reload = 0;
    this.mv = null;
    this.swallowT = -1;
    this.meleeCharge = 0;
    this.guard = false;
    const pm = this.inv.pistol;
    if (pm) {
      pm[0] = 12;
      pm[1] = 12;
    }
    this.invuln = 1.2;
    this.boltT = 0;
    this.swapT = 0;
    this.emptyT = 0;
    this.heat = 0;
    this.scoping = false;
    this.slingCharge = 0;
    this.cricketCharge = 0;
    this.cricketFire = false;
    this.cricketFly = 0;
    this.ghosts.length = 0;
    this.onGround = false;
    this.hurtT = 0;
    this.regenDelay = 0;
    this.airJumps = 1;
    this.dive = false;
    this.pumpT = 0;
    this.landSpring = 0;
    this.landVel = 0;
    this.dkOn = false;
  }

  /** true while winding up the door kick (before the foot connects) */
  get dkPre() {
    return this.dkOn && this.dkT < DK_IMPACT;
  }

  /** nearest wooden door in front of the body within reach */
  private findDoor(w: World, dir: number, reach: number): DynSolid | null {
    let best: DynSolid | null = null;
    let bd = 1e9;
    for (const d of w.dyn) {
      if (d.kind !== 'door') continue;
      if (d.y >= this.y - 6 || d.y + d.h <= this.y - this.h + 10) continue;
      const dist = dir > 0 ? d.x - (this.x + this.w / 2) : this.x - this.w / 2 - (d.x + d.w);
      if (dist < -4 || dist > reach) continue;
      if (dist < bd) {
        bd = dist;
        best = d;
      }
    }
    return best;
  }

  private startDoorKick(d: DynSolid, dir: number, host: PlayerHost) {
    this.dkOn = true;
    this.dkT = 0;
    this.dkRef = d.ref;
    this.dkDir = dir;
    this.dkHit = false;
    this.dkAir = false;
    this.facing = dir;
    const face = dir > 0 ? d.x : d.x + d.w;
    this.dkStandX = face - dir * 47;
    this.kick = 0;
    this.slide = 0;
    this.skid = 0;
    this.spin = 0;
    this.vault = 0;
    host.sfx.whoosh(0.3);
  }

  startStunt(kind: FlipKind) {
    this.flipping = true;
    this.flipRot = 0;
    this.flipKind = kind;
    this.flipKeepFacing = true;
    this.flipTime = 0;
    this.flipSwish = 0;
    this.flipRate = 1;
    let dur = 0.55;
    this.flipTotal = TAU;
    this.flipDir = 1;
    switch (kind) {
      case 'wall':
        this.flipDir = -1;
        dur = 0.5;
        break;
      case 'back':
        this.flipDir = -1;
        dur = 0.56;
        break;
      case 'layout':
        this.flipDir = -1;
        dur = 0.62;
        break;
      case 'double':
        this.flipTotal = TAU * 2;
        dur = 0.72;
        break;
      case 'aerial':
        dur = 0.54;
        break;
      case 'superman':
        dur = 0.72;
        break;
      default:
        break;
    }
    this.flipDur = dur;
    this.flipSpeed = this.flipTotal / dur;
  }

  get magSize() {
    return WEAPON_INFO[this.weapon].max;
  }

  has(id: WeaponId) {
    return !!this.inv[id];
  }

  owned(): WeaponId[] {
    return WEAPON_ORDER.filter((id) => !!this.inv[id]);
  }

  /** can this weapon still take more ammo? */
  canTake(id: WeaponId) {
    const cur = this.inv[id];
    if (!cur) return true;
    return cur[0] < WEAPON_INFO[id].max || (WEAPON_INFO[id].dual && cur[1] < WEAPON_INFO[id].max);
  }

  give(id: WeaponId, amount: number) {
    if (id === 'pistol') return;
    const info = WEAPON_INFO[id];
    const cur = this.inv[id];
    if (cur) {
      cur[0] = Math.min(info.max, cur[0] + amount);
      if (info.dual) cur[1] = Math.min(info.max, cur[1] + amount);
    } else {
      this.inv[id] = [Math.min(info.max, amount), info.dual ? Math.min(info.max, amount) : 0];
    }
  }

  private equip(id: WeaponId) {
    const m = this.inv[id];
    if (!m) return;
    this.weapon = id;
    this.mag = m;
    this.reload = 0;
    this.pumpT = 0;
    this.boltT = 0;
    this.emptyT = 0;
    this.heat = 0;
    this.nextGun = 0;
    this.slingCharge = 0;
    this.cricketCharge = 0;
    this.cricketFire = false;
    this.mv = null;
    this.mvQueued = null;
    this.swallowT = -1;
    this.meleeCharge = 0;
    this.meleeHeld = 0;
    this.guard = false;
  }

  switchTo(id: WeaponId, anim = true) {
    if (!this.inv[id] || id === this.weapon) return false;
    this.equip(id);
    if (anim) this.swapT = 0.22;
    return true;
  }

  cycleWeapon(dir: number) {
    const list = this.owned();
    if (list.length < 2) return false;
    const i = list.indexOf(this.weapon);
    const next = list[(i + dir + list.length) % list.length];
    return this.switchTo(next);
  }

  /** current special weapon ran dry / broke: drop it and fall back to the next one */
  dropCurrent() {
    if (this.weapon === 'pistol' || this.weapon === 'fist') return;
    delete this.inv[this.weapon];
    const list = this.owned().filter((w) => w !== 'pistol');
    this.equip(list.length ? list[list.length - 1] : 'pistol');
    this.swapT = 0.22;
  }

  setPistol() {
    this.equip('pistol');
  }

  get melee() {
    return WEAPON_INFO[this.weapon].melee;
  }

  get mvStrike() {
    return !!this.mv && this.mvT >= this.mv.hit[0] && this.mvT <= this.mv.hit[1];
  }

  startMove(id: string) {
    const m = MOVES[id];
    if (!m) return;
    copyPose(this.bladePose, this.mvFrom);
    normalizePose(this.mvFrom);
    this.mv = m;
    this.mvT = 0;
    this.mvHit = [];
    this.mvQueued = null;
    this.mvSwish = false;
    this.mvSlam = false;
    this.mvBlend = id === 'kIaiHold' || id === 'kLand' || id === 'bLand' ? 0.02 : 0.05;
    this.meleeCharge = 0;
    this.guard = false;
    this.mvCount++;
  }

  endMove() {
    if (this.mv) {
      this.mvLast = this.mv.id;
      this.mvLastEndT = this.animT;
    }
    this.mv = null;
    this.mvQueued = null;
    normalizePose(this.bladePose);
  }

  startSwallow(x: number, y: number, id: number) {
    this.startMove('kSwallow');
    this.swallowT = 0;
    this.swallowX = x;
    this.swallowY = y;
    this.swallowId = id;
    this.startStunt('front');
    this.usedStunt = true;
  }

  endSwallow(bounce: boolean) {
    this.swallowT = -1;
    this.endMove();
    if (bounce) {
      this.vy = -640;
      this.vx = this.facing * 300;
      this.airJumps = 1;
      this.mvAir = 0;
    }
  }

  startIai(x1: number) {
    this.iaiX0 = this.x;
    this.iaiX1 = x1;
    this.startMove('kIaiDash');
  }

  /** world-space blade at move time t (for trails / ghost blades) */
  bladeAt(t: number) {
    const m = this.mv;
    if (!m) return null;
    sampleMove(m, t, this.poseTmp2);
    const B = t < this.mvBlend ? blendPose(this.mvFrom, this.poseTmp2, smoothstep(0, this.mvBlend, t), this.poseTmp) : this.poseTmp2;
    return this.projectBlade(B);
  }

  private projectBlade(B: BladePose) {
    const f = this.facing;
    const r = this.lastRot;
    const spin = B.spin;
    const th = B.th + spin;
    let gx = B.gx;
    let gz = B.gz;
    if (spin !== 0) {
      const cs = Math.cos(spin);
      const sn = Math.sin(spin);
      const g2 = gx * cs - gz * sn;
      gz = gx * sn + gz * cs;
      gx = g2;
    }
    const ce = Math.cos(B.el);
    let lx = ce * Math.cos(th);
    let ly = -Math.sin(B.el);
    const dz = ce * Math.sin(th);
    let ox = gx;
    let oy = B.gy;
    if (r !== 0) {
      const c = Math.cos(r);
      const sn = Math.sin(r);
      const l2 = lx * c - ly * sn;
      ly = lx * sn + ly * c;
      lx = l2;
      const o2 = ox * c - oy * sn;
      oy = ox * sn + oy * c;
      ox = o2;
    }
    const sh = this.wp.shF;
    return { gx: sh.x + f * ox, gy: sh.y + oy, gz, dx: f * lx, dy: ly, dz };
  }

  /** updates the displayed blade pose: sampled moves, or smoothed resting poses */
  private updateBladePose(dt: number, running: boolean) {
    const P = this.bladePose;
    if (this.mv) {
      sampleMove(this.mv, this.mvT, this.poseTmp2);
      if (this.mvT < this.mvBlend) blendPose(this.mvFrom, this.poseTmp2, smoothstep(0, this.mvBlend, this.mvT), P);
      else copyPose(this.poseTmp2, P);
      return P;
    }
    const kat = this.weapon === 'katana';
    let tgt: BladePose;
    if (this.weapon === 'fist') {
      tgt = this.meleeCharge > 0 ? POSES.fistCharge : this.guard ? POSES.fistGuard : running && this.onGround ? POSES.fistRun : POSES.fistStance;
    } else if (this.meleeCharge > 0) tgt = kat ? POSES.katanaCharge : POSES.batCharge;
    else if (this.guard) tgt = POSES.katanaGuard;
    else if (running && this.onGround) tgt = kat ? POSES.katanaRun : POSES.batCarry;
    else tgt = kat ? POSES.katanaStance : POSES.batStance;
    const T = copyPose(tgt, this.poseTmp);
    if (!this.meleeCharge && !this.guard) {
      const wag = Math.sin(this.animT * (kat ? 2.2 : 3.1));
      T.th += wag * (kat ? 0.05 : 0.07);
      T.el += Math.sin(this.animT * (kat ? 2.2 : 3.1) + 0.8) * 0.05;
      if (running) T.gy += Math.sin(this.runPhase * Math.PI * 4) * 1.2;
    }
    blendPose(P, T, smooth(this.meleeCharge > 0 || this.guard ? 22 : 14, dt), P);
    P.spin = 0;
    return P;
  }

  /** noisy cricket: the charge finished — consume a round and fire */
  releaseCricket(time: number) {
    this.mag[0]--;
    this.fireCd = 0.95;
    this.recoil[0] = 1;
    this.flash[0] = 0.14;
    this.lastShot = time;
    this.aimBlend = 1;
    if (this.mag[0] <= 0) this.emptyT = 0.9;
  }

  /** bounce off an enemy (stomp / dive kick) */
  bounceOff(vy: number, flip: FlipKind | null) {
    this.vy = vy;
    this.onGround = false;
    this.dive = false;
    this.vault = 0;
    this.jumpHeld = false;
    this.airJumps = 1;
    this.heavyLand = 0;
    if (flip) {
      this.startStunt(flip);
      this.usedStunt = true;
    }
  }

  /** returns which gun fires (0 front / 1 back) or -1 */
  tryFire(fireHeld: boolean, time: number, sfx: Sound): number {
    if (this.weapon === 'sling') {
      // hold to draw the band, release to shoot
      this.slingHeld = fireHeld && this.alive && this.swapT <= 0 && this.fireCd <= 0 && this.mag[0] > 0;
      if (this.slingHeld) {
        if (this.slingCharge <= 0.001) sfx.slingStretch();
        return -1;
      }
      if (!fireHeld && this.slingCharge > 0.05 && this.alive) {
        this.slingPower = Math.min(1, this.slingCharge / SLING.max);
        this.slingCharge = 0;
        this.mag[0]--;
        this.fireCd = 0.2;
        this.recoil[0] = 0.45;
        this.lastShot = time;
        this.aimBlend = 1;
        if (this.mag[0] <= 0) this.emptyT = 0.35;
        return 0;
      }
      if (!fireHeld) this.slingCharge = 0;
      return -1;
    }
    if (!this.alive || this.reload > 0 || this.swapT > 0) return -1;
    if (!fireHeld || this.fireCd > 0) return -1;
    const w = this.weapon;
    if (w === 'cricket') {
      if (this.cricketCharge > 0 || this.emptyT > 0) return -1;
      if (this.mag[0] <= 0) {
        this.dropCurrent();
        return -1;
      }
      this.cricketCharge = CRICKET.charge;
      this.lastShot = time;
      sfx.cricketCharge();
      return -1;
    }
    if (WEAPON_INFO[w].melee) return -1;
    if (!WEAPON_INFO[w].dual) {
      // single two-handed weapons
      if (this.pumpT > 0 || this.boltT > 0 || this.emptyT > 0) return -1;
      if (this.mag[0] <= 0) {
        this.dropCurrent();
        return -1;
      }
      this.mag[0]--;
      if (w === 'shotgun') {
        this.fireCd = 0.62;
        this.pumpT = 0.55;
      } else if (w === 'ak47') {
        this.fireCd = 0.088;
        this.heat = Math.min(1, this.heat + 0.11);
      } else if (w === 'sniper') {
        this.fireCd = 1.05;
        this.boltT = 0.95;
      }
      this.recoil[0] = 1;
      this.flash[0] = w === 'sniper' ? 0.08 : 0.06;
      this.lastShot = time;
      this.aimBlend = 1;
      if (this.mag[0] <= 0) this.emptyT = w === 'shotgun' ? 0.56 : w === 'sniper' ? 0.9 : 0.3;
      return 0;
    }
    let gun = this.nextGun;
    if (this.backBusy && gun === 1 && this.mag[0] > 0) gun = 0;
    if (this.mag[gun] <= 0) gun = 1 - gun;
    if (this.mag[gun] <= 0) {
      if (w === 'uzi') this.dropCurrent();
      else this.startReload(sfx);
      return -1;
    }
    this.mag[gun]--;
    this.fireCd = w === 'uzi' ? 0.052 : 0.1;
    this.nextGun = 1 - gun;
    this.recoil[gun] = 1;
    this.flash[gun] = 0.05;
    this.lastShot = time;
    this.aimBlend = 1;
    if (this.mag[0] <= 0 && this.mag[1] <= 0) {
      if (w === 'uzi') this.emptyT = 0.2;
      else this.startReload(sfx);
    }
    return gun;
  }

  startReload(sfx: Sound) {
    if (this.reload > 0) return;
    this.reload = RELOAD_T;
    this.reloadStarted = true;
    sfx.reload();
  }

  manualReload(sfx: Sound) {
    if (this.weapon === 'pistol' && (this.mag[0] < this.magSize || this.mag[1] < this.magSize)) this.startReload(sfx);
  }

  update(dt: number, inp: PlayerInput, host: PlayerHost, fireDt: number) {
    const w = host.world;
    this.animT += dt;
    this.timers(dt, fireDt);

    if (!this.alive) return;

    if (this.zip) {
      this.updateZip(dt, inp, host);
      this.animate(dt, inp, host);
      return;
    }

    const dir = (inp.right ? 1 : 0) - (inp.left ? 1 : 0);
    this.downHeld = inp.down;
    this.walkMode = inp.walk;
    if (inp.jumpPressed) this.jumpBuffer = 0.14;

    // drop through one-way platforms (S + W)
    if (this.jumpBuffer > 0 && inp.down && this.onGround && this.groundOneWay) {
      this.dropThrough = 0.25;
      this.jumpBuffer = 0;
      this.onGround = false;
      this.y += 2;
    }

    // slide
    if (
      inp.downPressed &&
      this.onGround &&
      Math.abs(this.vx) > 200 &&
      this.slide <= 0 &&
      this.roll <= 0 &&
      this.heavyLand <= 0
    ) {
      this.slide = 0.72;
      const d = sign(this.vx);
      this.vx = d * Math.max(Math.abs(this.vx) * 1.15, 580);
      this.facing = d;
      host.sfx.whoosh(0.18);
      host.particles.dust(this.x, this.y, 6, -d);
    }

    this.crouch = inp.down && this.onGround && this.slide <= 0 && this.roll <= 0;

    // spin dodge
    if (inp.spinPressed && this.spinCd <= 0 && this.spin <= 0 && this.slide <= 0 && !this.dkPre) {
      this.spin = 0.6;
      this.spinAngle = 0;
      host.sfx.whoosh(0.3);
      if (!this.onGround && this.vy > -100) this.vy = Math.min(this.vy, -160);
    }

    // door kick: F near a door, or sprinting straight at it (auto)
    if (!this.dkOn && !this.mv && (this.onGround || this.airTime <= 0.06) && this.slide <= 0 && this.roll <= 0 && this.heavyLand <= 0) {
      let door: DynSolid | null = null;
      let kd = this.facing;
      if (inp.kickPressed) {
        kd = dir !== 0 ? dir : this.facing;
        door = this.findDoor(w, kd, 74);
      } else if (dir !== 0 && Math.abs(this.vx) > 200 && sign(this.vx) === dir && this.vault <= 0 && this.kick <= 0) {
        kd = dir;
        door = this.findDoor(w, dir, 30 + Math.abs(this.vx) * 0.13);
      }
      if (door) this.startDoorKick(door, kd, host);
    }

    // flying dive kick (air) / kick (ground)
    if (this.dkOn) {
      // busy kicking the door
    } else if (inp.kickPressed && !this.onGround && this.airTime > 0.06 && !this.dive && this.vault <= 0 && !this.zip) {
      if (dir !== 0) this.facing = dir;
      this.dive = true;
      this.diveT = 0;
      this.flipping = false;
      this.flipRot = 0;
      this.spin = 0;
      this.kick = 0;
      this.diveVx = 700;
      this.vx = this.facing * this.diveVx;
      this.vy = Math.max(this.vy, 820);
      host.sfx.diveKick();
      host.popup('TENDANGAN TERBANG!', this.x, this.y - 125, '#ffb36b');
    } else if (
      inp.kickPressed &&
      (this.onGround || this.airTime <= 0.06) &&
      this.kick <= 0 &&
      this.slide <= 0 &&
      this.roll <= 0
    ) {
      this.kick = 0.32;
      this.kickHitDone = false;
      host.sfx.whoosh(0.15);
    }

    // horizontal movement
    if (this.slide > 0) {
      this.vx = approach(this.vx, 0, 560 * dt);
      if (this.onGround && Math.random() < 0.5) host.particles.dust(this.x - this.facing * 10, this.y, 1, -this.facing);
      if (Math.abs(this.vx) < 150) this.slide = 0;
    } else if (this.swallowT >= 0) {
      // velocity set by the homing below
    } else if (this.mv && this.mv.id === 'kIaiDash') {
      this.vx = (this.iaiX1 - this.iaiX0) / this.mv.end;
    } else if (this.mv && this.mv.id === 'kIaiHold') {
      this.vx = 0;
    } else if (this.mv && !this.mv.air && this.onGround) {
      const m = this.mv;
      if (m.lunge && this.mvT >= m.lunge[1] && this.mvT <= m.lunge[2]) this.vx = this.facing * m.lunge[0];
      else this.vx = approach(this.vx, 0, 2600 * dt);
    } else if (this.mv && !this.onGround && !this.mv.plunge) {
      this.vx = approach(this.vx, dir * RUN * 0.7, ACC_AIR * 0.45 * dt);
    } else if (this.dkOn && this.dkT < DK_RETRACT) {
      if (this.dkT < DK_IMPACT) {
        // glide/step into kicking distance, plant, then snap the kick
        const rem = Math.max(0.03, DK_IMPACT - 0.02 - this.dkT);
        this.vx = clamp((this.dkStandX - this.x) / rem, -520, 520);
        if (this.dkAir) this.vx = this.dkDir * 120;
      } else {
        this.vx = approach(this.vx, 0, 2600 * dt);
      }
    } else if (this.dkOn) {
      if (dir !== 0) {
        this.dkOn = false;
        this.vx = approach(this.vx, dir * RUN, ACC_GROUND * dt);
      } else if (this.dkT >= DK_STEP) {
        this.vx = approach(this.vx, this.dkDir * 150, 1600 * dt);
      } else this.vx = approach(this.vx, 0, 2000 * dt);
    } else if (this.dive) {
      this.vx = this.facing * this.diveVx;
      this.diveT += dt;
    } else if (this.roll > 0) {
      this.vx = this.rollDir * Math.max(330, Math.abs(this.vx) - 420 * dt);
    } else if (this.vault > 0 && !this.onGround && dir !== -sign(this.vx)) {
      // keep vault momentum so the arc clears the obstacle
    } else {
      const slow = (inp.walk || this.guard || this.meleeCharge > 0) && this.onGround;
      const max = this.crouch ? CROUCH_SPEED : slow ? WALK_SPEED * (this.meleeCharge > 0 ? 0.45 : 1) : RUN;
      const target = dir * max;
      let acc = this.onGround ? ACC_GROUND : ACC_AIR;
      if (this.wallJumpLock > 0) acc *= 0.2;
      if (this.kick > 0 && this.onGround) acc *= 0.3;
      if (this.heavyLand > 0) acc *= 0.12;
      if (dir !== 0) {
        if (Math.abs(this.vx) > max && sign(this.vx) === dir) this.vx = approach(this.vx, target, 600 * dt);
        else this.vx = approach(this.vx, target, acc * dt);
      } else {
        this.vx = approach(this.vx, 0, (this.onGround ? FRICTION : 350) * dt);
      }
    }

    // skid when reversing at speed
    if (
      this.onGround &&
      dir !== 0 &&
      Math.abs(this.vx) > 220 &&
      sign(this.vx) !== dir &&
      this.slide <= 0 &&
      this.roll <= 0
    ) {
      if (this.skid <= 0) host.sfx.skid();
      this.skid = 0.16;
      if (Math.random() < 0.6) host.particles.dust(this.x + sign(this.vx) * 8, this.y, 1, sign(this.vx));
    }

    // parkour auto-vault
    this.tryVault(dir, host);

    // jumping (locked during the wind-up of a door kick; cancels the follow-through)
    if (this.jumpBuffer > 0 && this.dkOn) {
      if (this.dkT > DK_IMPACT + 0.08) this.dkOn = false;
      else this.jumpBuffer = Math.max(this.jumpBuffer, 0.02);
    }
    if (this.jumpBuffer > 0 && this.mv) {
      const m = this.mv;
      if (!m.air && !m.plunge && m.id !== 'kIaiDash' && m.id !== 'kIaiHold' && this.mvT > m.hit[1]) this.endMove();
    }
    if (this.jumpBuffer > 0 && !this.dkOn && !this.mv && this.swallowT < 0) {
      if (this.onGround || this.coyote > 0) this.doJump(host);
      else if (this.wallSide !== 0 || this.wallCoyote > 0) this.doWallJump(host);
      else if (this.airJumps > 0) this.doDoubleJump(dir, host);
    }
    if (this.jumpHeld && !inp.up && this.vy < -300) {
      this.vy *= 0.55;
      this.jumpHeld = false;
    }
    if (this.vy >= 0) this.jumpHeld = false;

    // gravity
    this.vy += GRAV * dt;
    if (!this.onGround && this.wallSide !== 0 && dir === this.wallSide && this.vy > 0 && !this.flipping && !this.dive) {
      this.vy = Math.min(this.vy, WALL_SLIDE);
      if (Math.random() < 0.25) host.particles.dust(this.x + this.wallSide * 12, this.y - 40, 1, -this.wallSide);
    }
    if (this.spin > 0 && !this.onGround && this.vy > 110) this.vy = approach(this.vy, 110, 5000 * dt);
    if (this.dive) this.vy = Math.max(this.vy, 860);
    if (this.swallowT >= 0) {
      const sdx = this.swallowX - this.x;
      const sdy = this.swallowY - (this.y - 48);
      const sl = Math.hypot(sdx, sdy) || 1;
      this.vx = (sdx / sl) * 1250;
      this.vy = (sdy / sl) * 1250;
    } else if (this.mv) {
      const m = this.mv;
      if (m.id === 'kIaiDash') this.vy = 0;
      if (m.hover && this.mvT < m.hover[1] && !this.onGround) this.vy = Math.min(this.vy, m.hover[0]);
      if (m.plunge) this.vy = this.mvT < 0.07 ? Math.min(this.vy, -40) : 1350;
    }
    if (this.vy > MAX_FALL) this.vy = MAX_FALL;

    // vault glide: skim across the obstacle top with the palm planted
    this.vaultGlide = false;
    if (this.vault > 0 && !this.onGround && Math.abs(this.vx) > 150) {
      const over = this.x + this.w / 2 > this.vaultX0 + 2 && this.x - this.w / 2 < this.vaultX1 - 2;
      if (over) {
        const limit = this.vaultHY - 7;
        if (this.y + this.vy * dt > limit) {
          this.vy = clamp((limit - this.y) / dt, -250, 0);
          this.vault = Math.max(this.vault, 0.1);
          this.vaultGlide = true;
        }
      }
    }

    // hitbox height
    let targetH = this.slide > 0 ? H_SLIDE : this.crouch || this.roll > 0 ? H_CROUCH : H_STAND;
    if (targetH > this.h) {
      if (w.rectFree(this.x - this.w / 2 + 1, this.y - targetH, this.w - 2, targetH - this.h + 0.5)) this.h = targetH;
      else {
        if (this.slide <= 0 && this.roll <= 0) this.crouch = true;
        targetH = this.h;
      }
    } else this.h = targetH;

    // move
    const body = { x: this.x - this.w / 2, y: this.y - this.h, w: this.w, h: this.h, vx: this.vx, vy: this.vy };
    const wasGround = this.onGround;
    const preVx = this.vx;
    const res = this.res;
    w.moveBody(body, dt, this.dropThrough > 0, res);

    let assisted = false;
    if (res.dynHit && res.dynHit.kind === 'glass' && Math.hypot(preVx, this.vy) > 140) {
      host.breakGlass(res.dynHit, preVx, this.vy);
    } else if (res.dynHit && res.dynHit.kind === 'door' && Math.abs(preVx) > 250 && !this.dkOn) {
      // slammed into a door (airborne / dive kick): instant flying right-foot kick
      const d = res.dynHit;
      const kd = sign(preVx);
      this.dkOn = true;
      this.dkT = DK_IMPACT;
      this.dkHit = true;
      this.dkAir = !this.onGround;
      this.dkDir = kd;
      this.dkRef = d.ref;
      this.facing = kd;
      if (this.dive) {
        this.dive = false;
        this.vy = Math.min(this.vy, -220);
      }
      this.vx = kd * 60;
      host.breach(d, kd, this.y - 52);
    } else if (res.hitX !== 0 && this.cricketFly > 0 && Math.abs(preVx) > 420) {
      // flung into a wall by the noisy cricket's recoil
      this.cricketFly = 0;
      this.vx = 0;
      this.vy = Math.min(this.vy, 120);
      this.flipping = false;
      this.flipRot = 0;
      host.wallSplat(this.x + sign(preVx) * this.w * 0.5, this.y - this.h * 0.55, sign(preVx));
    } else if (res.hitX !== 0) {
      if (this.dive) {
        // dive kick slammed into a wall
        this.dive = false;
        this.vx = -this.facing * 160;
        this.vy = Math.min(this.vy, -260);
        host.camKick(this.facing * 6, 0);
        host.sfx.thud();
      }
      // ledge assist
      const s = res.wallSolid;
      if (s && !wasGround && this.vy > -260 && !s.oneWay) {
        const feet = body.y + body.h;
        const diff = feet - s.y;
        if (diff > 0 && diff < 34 && w.rectFree(body.x + res.hitX * 6, s.y - body.h - 1, body.w, body.h)) {
          body.y = s.y - body.h - 0.5;
          body.x += res.hitX * 6;
          this.vy = Math.min(this.vy, 0);
          assisted = true;
        }
      }
      if (!assisted) {
        if (this.slide > 0) this.slide = 0;
        this.vx = 0;
      }
    }
    if (res.hitY === -1) this.vy = Math.max(this.vy, 30);

    this.x = body.x + this.w / 2;
    this.y = body.y + this.h;

    const landed = res.onGround && !wasGround;
    this.onGround = res.onGround;
    this.groundOneWay = !!(res.ground && res.ground.oneWay);
    if (res.onGround) {
      if (landed) this.onLand(host);
      this.vy = 0;
    }

    // walls
    this.wallSide = 0;
    if (!this.onGround && !assisted) {
      if (!w.rectFree(this.x - this.w / 2 - 4, this.y - this.h + 14, 4, this.h - 34)) this.wallSide = -1;
      else if (!w.rectFree(this.x + this.w / 2, this.y - this.h + 14, 4, this.h - 34)) this.wallSide = 1;
    }
    if (this.wallSide !== 0) {
      this.wallCoyote = 0.12;
      this.lastWallSide = this.wallSide;
    }
    if (this.onGround) {
      this.coyote = 0.1;
      this.airTime = 0;
      this.maxFall = 0;
    } else {
      this.airTime += dt;
      this.maxFall = Math.max(this.maxFall, this.vy);
    }

    // zipline attach
    if (!this.onGround && this.zipCd <= 0) {
      for (const z of host.ziplines) {
        const minX = Math.min(z.x1, z.x2);
        const maxX = Math.max(z.x1, z.x2);
        if (this.x < minX || this.x > maxX - 40) continue;
        const t = (this.x - z.x1) / (z.x2 - z.x1);
        const ly = z.y1 + (z.y2 - z.y1) * t;
        const top = this.y - this.h;
        if (ly > top - 30 && ly < top + 28) {
          this.zip = z;
          this.zipT = t;
          this.zipSpeed = Math.max(260, Math.abs(this.vx) * 0.7 + Math.max(0, this.vy) * 0.3);
          this.flipping = false;
          this.flipRot = 0;
          this.spin = 0;
          this.vault = 0;
          this.dive = false;
          this.airJumps = 1;
          this.facing = sign(z.x2 - z.x1);
          host.sfx.whoosh(0.3);
          host.particles.sparks(this.x, ly, 0, -1, 8);
          break;
        }
      }
    }

    // door kick: the heel connects
    if (this.dkOn && !this.dkHit && this.dkT >= DK_IMPACT) {
      this.dkHit = true;
      const d = w.dyn.find((q) => q.kind === 'door' && q.ref === this.dkRef);
      if (d) host.breach(d, this.dkDir, this.y - 52);
      const kx = this.dkDir > 0 ? this.x + 4 : this.x - 66;
      host.kickAt(kx, this.y - 80, 62, 60, this.dkDir);
    }
    if (this.dkOn && this.dkT >= DK_END) this.dkOn = false;

    // kick active frames
    if (this.kick > 0 && !this.kickHitDone && this.kick < 0.25) {
      this.kickHitDone = true;
      const kx = this.facing > 0 ? this.x + 4 : this.x - 62;
      const ky = this.y - 84;
      if (host.kickAt(kx, ky, 58, 80, this.facing)) host.sfx.kick();
    }

    // stick the landing: speed the flip up if the ground is coming too soon
    if (this.flipping && !this.onGround && ROT_KINDS.includes(this.flipKind)) {
      const remain = this.flipDur - this.flipTime;
      const hit = w.raycast(this.x, this.y, this.x + this.vx * 0.12, this.y + 700, true, true);
      if (hit && remain > 0) {
        const dy = Math.max(0, hit.y - this.y);
        const vy = this.vy;
        const tl = (-vy + Math.sqrt(Math.max(0, vy * vy + 2 * GRAV * dy))) / GRAV;
        this.flipRate = tl > 0.02 && remain > tl * 0.9 ? clamp(remain / (tl * 0.9), 1, 2.4) : 1;
      } else this.flipRate = 1;
    }

    // whoosh on the fast (tucked) part of every rotation
    if (this.flipping && ROT_KINDS.includes(this.flipKind)) {
      const marks = this.flipKind === 'double' ? [0.3, 0.64] : [0.4];
      if (this.flipSwish < marks.length && this.stuntK >= marks[this.flipSwish]) {
        this.flipSwish++;
        host.sfx.whoosh(0.22);
      }
    }

    // facing
    if (this.mv || this.swallowT >= 0) {
      // locked while attacking
    } else if (this.flipping && this.flipKeepFacing) {
      // keep
    } else if (this.dkOn) {
      this.facing = this.dkDir;
    } else if (this.slide > 0 || this.roll > 0 || this.vault > 0 || this.dive) {
      // keep
    } else if (dir !== 0 && this.kick <= 0) {
      this.facing = dir;
    } else if (this.onGround && Math.abs(this.vx) < 60 && this.kick <= 0 && this.heavyLand <= 0) {
      this.facing = inp.aimX >= this.x ? 1 : -1;
    } else if (!this.onGround && !this.flipping && dir === 0) {
      this.facing = inp.aimX >= this.x ? 1 : -1;
    }

    this.animate(dt, inp, host);
  }

  private timers(dt: number, fireDt: number) {
    this.jumpBuffer -= dt;
    this.coyote -= dt;
    this.wallCoyote -= dt;
    this.wallJumpLock -= dt;
    this.dropThrough -= dt;
    this.zipCd -= dt;
    this.spinCd -= dt;
    this.invuln -= dt;
    this.hurtT -= dt;
    this.landT -= dt;
    this.fireCd -= fireDt;
    if (this.kick > 0) this.kick -= dt;
    if (this.slide > 0) this.slide -= dt;
    if (this.roll > 0) this.roll -= dt;
    if (this.vault > 0) this.vault -= dt;
    if (this.heavyLand > 0) this.heavyLand -= dt;
    if (this.dkOn) this.dkT += dt;
    if (this.dazed > 0) this.dazed -= dt;
    this.guardStruct = Math.max(0, this.guardStruct - dt * (this.guard ? 8 : 26));
    if (this.pumpT > 0) {
      const prev = this.pumpT;
      this.pumpT -= fireDt;
      if (prev > 0.3 && this.pumpT <= 0.3) this.pumpEvent = true;
      if (this.pumpT <= 0) this.pumpT = 0;
    }
    if (this.boltT > 0) {
      const prev = this.boltT;
      this.boltT -= fireDt;
      if (prev > 0.5 && this.boltT <= 0.5) this.boltEvent = true;
      if (this.boltT <= 0) this.boltT = 0;
    }
    if (this.emptyT > 0) {
      this.emptyT -= fireDt;
      if (this.emptyT <= 0) {
        this.emptyT = 0;
        this.dropCurrent();
      }
    }
    this.heat = Math.max(0, this.heat - fireDt * (this.fireCd > -0.12 ? 0.55 : 1.8));
    if (this.slingHeld && this.weapon === 'sling') this.slingCharge = Math.min(SLING.max, this.slingCharge + fireDt);
    if (this.cricketCharge > 0) {
      this.cricketCharge -= fireDt;
      if (this.cricketCharge <= 0) {
        this.cricketCharge = 0;
        if (this.weapon === 'cricket' && this.alive) this.cricketFire = true;
      }
    }
    if (this.cricketFly > 0) this.cricketFly -= dt;
    if (this.swapT > 0) this.swapT = Math.max(0, this.swapT - fireDt);
    if (this.swallowT >= 0) this.swallowT += dt;
    if (this.mv) {
      const m = this.mv;
      const prev = this.mvT;
      this.mvT += dt;
      if (m.hop && prev < m.hop[1] && this.mvT >= m.hop[1] && this.onGround) {
        this.vy = m.hop[0];
        this.onGround = false;
      }
      if (this.mvQueued && this.mvT >= m.chain) {
        const q = this.mvQueued;
        this.endMove();
        this.startMove(q);
      } else if (this.mvT >= m.end && !m.plunge) {
        const auto = m.auto;
        this.endMove();
        if (auto) this.startMove(auto);
      }
    }
    if (this.skid > 0) this.skid -= dt;
    if (this.spin > 0) {
      this.spin -= dt;
      this.spinAngle += (dt * (TAU * 2)) / 0.6;
      if (this.spin <= 0) {
        this.spinCd = 0.15;
        this.spinAngle = 0;
      }
    }
    if (this.reload > 0) {
      this.reload -= fireDt;
      if (this.reload <= 0) {
        this.mag[0] = this.magSize;
        this.mag[1] = this.magSize;
        this.reload = 0;
      }
    }
    for (let i = 0; i < 2; i++) {
      this.recoil[i] = Math.max(0, this.recoil[i] - fireDt * 9);
      this.flash[i] = Math.max(0, this.flash[i] - fireDt);
    }
    if (this.flipping) {
      this.flipTime += dt * this.flipRate;
      const u = this.flipTime / this.flipDur;
      if (u >= 1) {
        this.flipping = false;
        this.flipRot = 0;
      } else {
        // slow takeoff -> fast tucked rotation -> slow open to spot the landing
        const e = u - (0.62 * Math.sin(TAU * u)) / TAU;
        this.flipRot = this.flipDir * this.flipTotal * e;
      }
    } else if (this.flipRot !== 0) {
      const tgt = Math.round(this.flipRot / TAU) * TAU;
      this.flipRot = approach(this.flipRot, tgt, dt * 20);
      if (Math.abs(this.flipRot - tgt) < 0.01) this.flipRot = 0;
    }
    this.regenDelay -= dt;
    if (this.alive && !this.noRegen && this.regenDelay <= 0 && this.hp < this.maxHp) this.hp = Math.min(this.maxHp, this.hp + 14 * dt);
    for (let i = this.ghosts.length - 1; i >= 0; i--) {
      this.ghosts[i].life -= dt;
      if (this.ghosts[i].life <= 0) this.ghosts.splice(i, 1);
    }
  }

  /** automatic parkour vault over low obstacles while sprinting */
  private tryVault(dir: number, host: PlayerHost) {
    if (this.dive || this.dkOn || this.mv || this.swallowT >= 0) return;
    if (this.vault > 0 || this.slide > 0 || this.roll > 0 || this.kick > 0) return;
    if (this.heavyLand > 0 || this.crouch || dir === 0) return;
    // airborne: only chain into a vault while descending / near apex
    if (!this.onGround && this.vy < -120) return;
    const spdAbs = Math.abs(this.vx);
    const moving = spdAbs >= 200 && sign(this.vx) === dir;
    if (!moving && !this.onGround) return;
    const w = host.world;
    const front = dir > 0 ? this.x + this.w / 2 : this.x - this.w / 2;
    const reach = moving ? 26 + spdAbs * 0.06 : 4;
    const qx = dir > 0 ? front : front - reach;
    const list = w.query(qx, this.y - 106, reach, 102);
    let best: Solid | null = null;
    let bestDist = 1e9;
    for (const s of list) {
      if (s.oneWay) continue;
      const hgt = this.y - s.y;
      if (hgt < 14 || hgt > 104) continue;
      if (s.y + s.h < this.y - 4) continue;
      const face = dir > 0 ? s.x : s.x + s.w;
      const d = (face - front) * dir;
      if (d < -2 || d > reach) continue;
      if (d < bestDist) {
        bestDist = d;
        best = s;
      }
    }
    if (!best) return;
    const top = best.y;
    const face = dir > 0 ? best.x : best.x + best.w;
    const cx = dir > 0 ? face : face - this.w - 10;
    if (!w.rectFree(cx, top - this.h - 10, this.w + 10, this.h + 4, false)) return;
    const hgt = this.y - top;
    const spd = Math.max(spdAbs, moving ? 450 : 330);
    // low hop just over the top; the glide phase carries us across
    this.vy = -Math.sqrt(2 * GRAV * (hgt + 14));
    this.vx = dir * spd;
    this.onGround = false;
    this.coyote = 0;
    this.jumpBuffer = 0;
    this.jumpHeld = false;
    this.vault = 0.42;
    this.vaultHX = face + dir * 12;
    this.vaultHY = top;
    this.vaultX0 = best.x;
    this.vaultX1 = best.x + best.w;
    this.facing = dir;
    host.sfx.whoosh(0.24);
    host.particles.dust(this.x, this.y, 4, -dir);
  }

  private doJump(host: PlayerHost) {
    const sliding = this.slide > 0;
    this.vy = -JUMP_V;
    this.onGround = false;
    this.coyote = 0;
    this.jumpBuffer = 0;
    this.jumpHeld = true;
    this.heavyLand = 0;
    if (sliding) {
      this.slide = 0;
      this.vx *= 1.05;
    }
    if (this.roll > 0) this.roll = 0;
    if (Math.abs(this.vx) > 250) {
      this.facing = sign(this.vx);
      this.startStunt('front');
    }
    host.sfx.whoosh(0.2);
    host.particles.dust(this.x, this.y, 5, 0);
  }

  private doWallJump(host: PlayerHost) {
    const side = this.wallSide || this.lastWallSide;
    if (!side) return;
    this.vx = -side * WALL_VX;
    this.vy = -WALL_VY;
    this.wallJumpLock = 0.17;
    this.jumpBuffer = 0;
    this.wallCoyote = 0;
    this.jumpHeld = true;
    this.airJumps = 1;
    this.facing = side;
    this.startStunt('wall');
    this.wallFlipAt = host.time;
    host.sfx.whoosh(0.3);
    host.sfx.land();
    host.particles.dust(this.x + side * 12, this.y - 30, 7, -side);
  }

  private doDoubleJump(dir: number, host: PlayerHost) {
    this.airJumps--;
    this.jumpBuffer = 0;
    // stunt jump is always full height so the flip has room to finish
    this.jumpHeld = false;
    this.vy = -DOUBLE_V;
    this.vault = 0;
    this.dive = false;
    const prevVx = this.vx;
    const reversing = dir !== 0 && Math.abs(prevVx) > 150 && sign(prevVx) !== dir;
    if (dir !== 0) {
      this.vx = reversing ? dir * 260 : dir * Math.max(Math.abs(this.vx), 360);
    }
    const moving = Math.abs(this.vx) > 180;
    let kind: FlipKind;
    if (reversing) {
      // backflip away while still facing (and aiming) where we came from
      kind = 'back';
      this.facing = sign(prevVx);
    } else if (!moving) {
      // standing: backflip (alternates layout / tuck style)
      kind = this.backIdx++ % 2 === 0 ? 'layout' : 'back';
      if (dir === 0) this.vx = -this.facing * 80;
    } else if (this.downHeld) {
      kind = 'superman';
      this.facing = sign(this.vx);
    } else {
      // running: front flips (single / double / aerial)
      const cycle: FlipKind[] = ['front', 'double', 'front', 'aerial'];
      kind = cycle[this.stuntIdx % cycle.length];
      this.stuntIdx++;
      this.facing = sign(this.vx);
    }
    if (kind === 'superman') {
      // long forward dive
      this.vx = this.facing * Math.max(Math.abs(this.vx), 540);
      this.vy = -600;
    }
    this.usedStunt = true;
    this.startStunt(kind);
    host.particles.spawn({ kind: 'ring', x: this.x, y: this.y - 4, life: 0.3, size: 46, color: '#dff6ff' });
    host.particles.dust(this.x, this.y, 6, 0);
    host.sfx.doubleJump();
    host.popup(FLIP_TAG[kind] + '!', this.x, this.y - 125, '#9fe8ff');
  }

  private startRoll(dir: number, host: PlayerHost, from: number) {
    this.roll = ROLL_T;
    this.rollDir = dir;
    this.facing = dir;
    this.rollFrom = from;
    this.vx = dir * clamp(Math.abs(this.vx), 380, 540);
    this.landT = 0;
    this.heavyLand = 0;
    host.sfx.roll();
    host.sfx.land();
    host.camKick(dir * 4, 3);
    host.particles.dust(this.x, this.y, 7, -dir);
  }

  private onLand(host: PlayerHost) {
    this.mvAir = 0;
    if (this.mv && this.mv.plunge) {
      const kat = this.mv.w === 'katana';
      this.landT = 0;
      this.vx *= 0.2;
      this.airJumps = 1;
      this.flipping = false;
      this.flipRot = 0;
      host.groundPound(this.x + this.facing * (kat ? 6 : 40), this.y, kat ? 0.55 : 0.7);
      this.plungeLand = true;
      this.endMove();
      this.startMove(kat ? 'kLand' : 'bLand');
      return;
    }
    const fall = this.maxFall;
    this.landPower = clamp((fall - 300) / 900, 0, 1);
    this.landT = 0.1 + this.landPower * 0.16;
    this.airJumps = 1;
    this.vault = 0;
    if (this.dive) {
      // dive kick into the floor = superhero ground pound
      this.dive = false;
      this.flipping = false;
      this.flipRot = 0;
      this.usedStunt = false;
      this.heavyLand = 0.4;
      this.landStyle = 'slam';
      this.vx *= 0.15;
      this.landT = 0;
      host.groundPound(this.x, this.y, 1);
      return;
    }
    const wasFlipping = this.flipping;
    const kind = this.flipKind;
    const k = this.stuntK;
    const stunted = this.usedStunt;
    this.usedStunt = false;
    this.spin = Math.min(this.spin, 0.12);
    if (wasFlipping) {
      this.flipping = false;
      if (!ROT_KINDS.includes(kind)) this.flipRot = 0;
    }
    // ---- roll out of the landing (sometimes / after stunts / holding S)
    const speed = Math.abs(this.vx);
    if (speed > 150 && this.slide <= 0) {
      const dir = sign(this.vx);
      const midFlip = wasFlipping && ROT_KINDS.includes(kind) && k < 0.82;
      let roll = false;
      if (this.downHeld) roll = true;
      else if (wasFlipping && kind === 'superman') roll = true;
      else if (midFlip && fall > 250) roll = true;
      else if (fall > 880) roll = true;
      else if (stunted && fall > 420) roll = Math.random() < 0.7;
      else if (fall > 560) roll = Math.random() < 0.38;
      if (roll) {
        let from = 0;
        if (midFlip && this.flipDir > 0 && dir === this.facing) from = ((this.flipRot % TAU) + TAU) % TAU;
        this.flipRot = 0;
        this.startRoll(dir, host, from);
        return;
      }
    }
    if (fall > 820 && this.slide <= 0) {
      // tactical kneel landing (shockwave knocks nearby enemies off balance)
      this.heavyLand = 0.42;
      this.landStyle = 'kneel';
      this.landVel = 0;
      this.vx *= 0.2;
      this.landT = 0;
      host.groundPound(this.x, this.y, 0.3 + clamp((fall - 820) / 600, 0, 0.5));
      host.sfx.land();
      return;
    }
    // knees absorb the impact like a spring (torso stays upright)
    this.landVel += Math.min(fall, 1300) * (Math.abs(this.vx) > 150 ? 0.2 : 0.36);
    if (fall > 250) {
      host.sfx.land();
      const n = Math.ceil((3 + this.landPower * 9) / 2);
      host.particles.dust(this.x - 8, this.y, n, -1);
      host.particles.dust(this.x + 8, this.y, n, 1);
      host.camKick(0, 2 + this.landPower * 7);
      if (this.landPower > 0.4) host.shake(2 + this.landPower * 4);
    }
  }

  private updateZip(dt: number, inp: PlayerInput, host: PlayerHost) {
    const z = this.zip as ZiplineDef;
    const dx = z.x2 - z.x1;
    const dy = z.y2 - z.y1;
    const len = Math.hypot(dx, dy);
    const ux = dx / len;
    const uy = dy / len;
    this.zipSpeed = Math.min(760, this.zipSpeed + (260 + 1500 * uy) * dt);
    this.zipT += (this.zipSpeed * dt) / len;
    const lx = z.x1 + dx * this.zipT;
    const ly = z.y1 + dy * this.zipT;
    this.x = lx;
    this.y = ly + 100;
    this.vx = ux * this.zipSpeed;
    this.vy = uy * this.zipSpeed;
    this.onGround = false;
    this.h = H_STAND;
    if (Math.random() < 0.4) host.particles.sparks(lx, ly, -ux, -uy - 0.3, 1);
    const w = host.world;
    for (const d of w.dyn) {
      if (d.kind !== 'glass') continue;
      if (d.x < this.x + 20 && d.x + d.w > this.x - 20 && d.y < this.y && d.y + d.h > this.y - this.h) {
        host.breakGlass(d, this.vx, this.vy);
      }
    }
    let detach = false;
    if (!w.rectFree(this.x - this.w / 2, this.y - this.h + 10, this.w, this.h - 10, true)) detach = true;
    if (this.zipT >= 1) detach = true;
    if (inp.jumpPressed) {
      detach = true;
      this.vy = -650;
      this.facing = sign(this.vx);
      this.startStunt('front');
      host.sfx.whoosh(0.25);
    }
    if (inp.downPressed) detach = true;
    if (detach) {
      this.zip = null;
      this.zipCd = 0.4;
      this.airJumps = 1;
      let guard = 0;
      while (!w.rectFree(this.x - this.w / 2, this.y - this.h, this.w, this.h, true) && guard < 40) {
        this.y -= 2;
        guard++;
      }
    }
  }

  private animate(dt: number, inp: PlayerInput, host: PlayerHost) {
    const T = this.target;
    const speed = Math.abs(this.vx);
    const t = this.animT;
    let rate = 20;
    let rot = 0;
    let cy = -50;
    const breathe = Math.sin(t * 2.4);
    const sinceShot = host.time - this.lastShot;
    const aimingNow = inp.fireHeld || inp.splitHeld || sinceShot < 1.1;

    // acceleration lean
    const accel = dt > 0 ? (speed - this.prevSpeed) / dt : 0;
    this.prevSpeed = speed;
    this.accelLean += (clamp(accel / 3200, -1, 1) * 0.09 - this.accelLean) * smooth(10, dt);
    // landing spring (hip dip) — damped oscillator
    {
      const w0 = 16;
      this.landVel += (-w0 * w0 * this.landSpring - 2 * 0.5 * w0 * this.landVel) * dt;
      this.landSpring = clamp(this.landSpring + this.landVel * dt, -5, 22);
    }

    // defaults (idle)
    T.px = 0;
    T.py = -48.4 + breathe * 0.6;
    T.torso = 0.03;
    T.head = -0.03;
    T.fx = 7;
    T.fy = -3;
    T.bx = -7.5;
    T.by = -3;
    T.aFu = 0.25 + breathe * 0.04;
    T.aFe = 0.5;
    T.aBu = -0.15;
    T.aBe = 0.45;

    let running = false;

    if (this.zip) {
      const sway = Math.sin(t * 5) * 4;
      T.py = -49;
      T.torso = 0.1;
      T.head = -0.1;
      T.fx = 12 + sway;
      T.fy = -9;
      T.bx = -3 - sway;
      T.by = -4;
    } else if (this.slide > 0) {
      rate = 30;
      T.py = -15;
      T.torso = -0.95;
      T.head = 0.55;
      T.fx = 36;
      T.fy = -4;
      T.bx = 7;
      T.by = -3;
      T.aFu = 1.4;
      T.aBu = -0.6;
    } else if (this.roll > 0) {
      // shoulder roll: tucked ball that opens up into a run
      rate = 46;
      const k = clamp(1 - this.roll / ROLL_T, 0, 1);
      const span = (this.rollFrom > 4.2 ? 2 * TAU : TAU) - this.rollFrom;
      const e = 1 - Math.pow(1 - k, 1.7);
      rot = this.rollFrom + span * e;
      cy = -27;
      const open = smoothstep(0.7, 1, k);
      T.py = lerp(-31, -46, open);
      T.torso = lerp(1.2, 0.3, open);
      T.head = lerp(0.6, -0.15, open);
      T.fx = lerp(10, 12, open);
      T.fy = lerp(-25, -3, open);
      T.bx = lerp(3, -10, open);
      T.by = lerp(-21, -3, open);
      T.aFu = lerp(2.2, 0.6, open);
      T.aFe = 1.2;
      T.aBu = lerp(1.6, -0.3, open);
      T.aBe = 1.3;
    } else if (this.heavyLand > 0 && this.onGround && this.landStyle === 'kneel') {
      // John Wick kneel: drop straight into a kneeling firing stance, back upright, guns on target
      rate = 30;
      const k = clamp(this.heavyLand / 0.42, 0, 1);
      const deep = Math.min(1, k * 1.7);
      T.py = lerp(-48, -26, deep);
      T.torso = 0.04;
      T.head = -0.02;
      T.fx = lerp(7, 22, deep);
      T.fy = -3;
      T.bx = lerp(-8, -24, deep);
      T.by = lerp(-3, -6, deep);
    } else if (this.heavyLand > 0 && this.onGround) {
      // dive-kick slam: superhero three-point landing, hand planted
      rate = 26;
      const k = clamp(this.heavyLand / 0.4, 0, 1);
      const deep = Math.min(1, k * 1.6);
      T.py = -49 + 27 * deep;
      T.torso = 0.15 + 0.6 * deep;
      T.head = -0.55 * deep;
      T.fx = 17;
      T.fy = -3;
      T.bx = -16;
      T.by = -3 + 1 * deep;
      T.aFu = 1.0;
      T.aBu = 0.6;
    } else if (!this.onGround) {
      if (this.dive) {
        // flying kick: lead leg spears down-forward, trail leg tucked
        rate = 42;
        T.py = -42;
        T.torso = -0.32;
        T.head = 0.22;
        T.fx = 36;
        T.fy = -4;
        T.bx = -4;
        T.by = -30;
        T.aFu = -0.4;
        T.aBu = 2.4;
      } else if (this.vault > 0) {
        // speed vault: legs tucked to the side, hand planted
        rate = 34;
        if (this.vaultGlide) {
          T.py = -34;
          T.torso = 0.78;
          T.head = -0.7;
          T.fx = 21;
          T.fy = -14;
          T.bx = 9;
          T.by = -10;
        } else {
          const k = clamp(1 - this.vault / 0.42, 0, 1);
          T.py = -46;
          T.torso = 0.6 - k * 0.25;
          T.head = -0.5;
          T.fx = 19 - k * 4;
          T.fy = -26 + k * 12;
          T.bx = 10 - k * 8;
          T.by = -20 + k * 10;
        }
      } else if (this.flipping) {
        rate = 40;
        const k = this.stuntK;
        const kind = this.flipKind;
        if (kind === 'layout') {
          // layout backflip: long straight body, chest arched, pike to land
          const arch = Math.sin(k * Math.PI);
          const pike = smoothstep(0.74, 1, k);
          T.py = -51;
          T.torso = -0.22 * arch + 0.3 * pike;
          T.head = -0.42 * arch;
          T.fx = 6 + 7 * pike;
          T.fy = -4 - 9 * pike;
          T.bx = -1 + 5 * pike;
          T.by = -3 - 7 * pike;
          T.aFu = 2.8;
          T.aBu = 2.6;
        } else if (kind === 'aerial') {
          // straddle split at the top
          const sp = Math.sin(k * Math.PI);
          T.py = -51;
          T.torso = 0.3;
          T.head = 0.1;
          T.fx = 10 + 26 * sp;
          T.fy = -8 - 14 * sp;
          T.bx = -8 - 26 * sp;
          T.by = -6 - 12 * sp;
        } else if (kind === 'superman') {
          // dive: legs straight back, head up (body tilt comes from rot)
          const s2 = Math.sin(k * Math.PI);
          T.py = -50;
          T.torso = -0.1;
          T.head = -0.95 * s2;
          T.fx = 2 + 4 * (1 - s2);
          T.fy = -5;
          T.bx = -5;
          T.by = -2;
        } else {
          // tuck flips (front / back / wall / double): takeoff -> tight tuck -> open & spot the landing
          const back = this.flipDir < 0;
          const dbl = kind === 'double';
          const tIn = dbl ? 0.1 : 0.16;
          const tuck = smoothstep(0.02, tIn, k) * (1 - smoothstep(dbl ? 0.84 : 0.72, 0.97, k));
          const pre = 1 - smoothstep(0, tIn, k);
          T.py = -50 - 2 * tuck;
          T.torso = 0.05 + 0.78 * tuck + (back ? -0.28 : 0.18) * pre;
          T.head = 0.34 * tuck + (back ? -0.45 : 0.1) * pre;
          T.fx = 8 + 6 * tuck;
          T.fy = -8 - 34 * tuck;
          T.bx = -6 + 15 * tuck;
          T.by = -5 - 30 * tuck;
          T.aFu = 1.4 + 1.2 * tuck;
          T.aBu = 1.2 + 1.4 * tuck;
        }
      } else if (this.wallSide !== 0 && this.vy > 0) {
        T.px = -3;
        T.torso = -0.15;
        T.fx = 16;
        T.fy = -30;
        T.bx = 2;
        T.by = -8;
      } else if (this.vy < 0) {
        T.torso = 0.06;
        T.head = -0.06;
        T.fx = 13;
        T.fy = -24;
        T.bx = -15;
        T.by = -8;
        T.aFu = 2.2;
        T.aBu = -0.6;
      } else {
        // falling: legs reach for the ground as it nears
        const fl = Math.sin(t * 9);
        const reachDown = clamp(this.vy / 900, 0, 1);
        T.torso = 0.02;
        T.fx = 10;
        T.fy = -13 + fl * 3 + reachDown * 6;
        T.bx = -8;
        T.by = -6 - fl * 3;
        T.aFu = 2.5;
        T.aFe = 0.3;
        T.aBu = 2.0;
        T.aBe = 0.3;
      }
      if (this.spin > 0) {
        T.torso = 0;
        T.fx = 4;
        T.fy = -10;
        T.bx = -3;
        T.by = -7;
      }
    } else if (this.skid > 0 && this.kick <= 0) {
      rate = 30;
      T.py = -44;
      T.torso = 0.28;
      T.head = -0.24;
      T.fx = 19;
      T.fy = -3;
      T.bx = -11;
      T.by = -3;
      T.aFu = 1.3;
      T.aBu = -0.9;
    } else if (this.crouch) {
      T.py = -24;
      T.torso = 0.9;
      T.head = -0.65;
      T.fx = 12;
      T.fy = -3;
      T.bx = -10;
      T.by = -3;
      if (speed > 20) {
        this.runPhase += (dt * speed) / 60;
        const s = Math.sin(this.runPhase * TAU);
        T.fx = 8 + s * 9;
        T.bx = -8 - s * 9;
        T.fy = -3 - Math.max(0, Math.cos(this.runPhase * TAU)) * 5;
        T.by = -3 - Math.max(0, -Math.cos(this.runPhase * TAU)) * 5;
      }
    } else if (speed > 25) {
      // ---- John Wick gait: upright chest, level head, knees drive forward, low smooth hips
      running = true;
      rate = 36;
      const r = clamp(speed / RUN, 0, 1.4);
      const rr = Math.min(1, r);
      this.gunRunBlend = approach(this.gunRunBlend, aimingNow ? 1 : 0, dt * 6);
      const gr = this.gunRunBlend;
      const wk = 1 - smoothstep(130, 230, speed);
      const wl = clamp(speed / WALK_SPEED, 0, 1);
      // sprint (guns at chest) <-> gun-run (shooting while moving) <-> tactical walk
      const travel = lerp(lerp(24 + 30 * rr, 22 + 26 * rr, gr), 18 + 12 * wl, wk);
      const duty = lerp(lerp(0.52 - 0.18 * rr, 0.54 - 0.15 * rr, gr), 0.62, wk);
      const lift = lerp(lerp(12 + 15 * rr, 10 + 9 * rr, gr), 7, wk);
      const freq = (duty * speed) / travel;
      const prev = this.runPhase;
      this.runPhase = (this.runPhase + freq * dt) % 1;
      // footstep events
      const crossedF = this.runPhase < prev;
      const crossedB = prev < 0.5 && this.runPhase >= 0.5;
      if ((crossedF || crossedB) && speed > 120) {
        host.sfx.step();
        if (speed > 300 && Math.random() < 0.7) {
          host.particles.dust(this.x - this.facing * 10, this.y, 1, -this.facing, 'rgba(200,190,175,1)');
        }
      }
      const toeOff = (2 + 3 * rr) * (1 - wk);
      const tuck = 5 * rr * (1 - wk) * (1 - 0.5 * gr);
      const leg = (s: number) => {
        if (s < duty) {
          const u = s / duty;
          let fy = -3;
          if (u > 0.78) fy -= ((u - 0.78) / 0.22) * toeOff;
          return [travel * (0.4 - u), fy];
        }
        const u = (s - duty) / (1 - duty);
        // knee drive: the foot swings forward early, lift peaks before mid-swing
        const fwd = 1 - Math.pow(1 - u, 1.8);
        const fx = travel * (-0.6 + fwd) - tuck * Math.sin(Math.PI * u) * (1 - u);
        const fy = -3 - lift * Math.pow(Math.sin(Math.PI * u), 0.85);
        return [fx, fy];
      };
      const sf = this.runPhase;
      const sb = (this.runPhase + 0.5) % 1;
      const [ffx, ffy] = leg(sf);
      const [bfx, bfy] = leg(sb);
      T.fx = ffx + 2;
      T.fy = ffy;
      T.bx = bfx + 2;
      T.by = bfy;
      const cyc = Math.cos(4 * Math.PI * (sf - duty / 2));
      // run: hips compress at mid-stance · walk: hips rise at mid-stance (pendulum)
      const runPy = lerp(-47.6 + 0.6 * rr + 1.7 * rr * cyc, -46.3 + 0.8 * rr * cyc, gr);
      const walkPy = -47.8 - 1.0 * cyc;
      T.py = lerp(runPy, walkPy, wk);
      const sprintTorso = 0.07 + 0.1 * rr + this.accelLean + 0.022 * cyc;
      const gunTorso = 0.03 + 0.04 * rr + this.accelLean * 0.4;
      const walkTorso = 0.02 + 0.012 * Math.sin(4 * Math.PI * sf);
      T.torso = lerp(lerp(sprintTorso, gunTorso, gr), walkTorso, wk);
      // keep the head level (eyes on target)
      T.head = -T.torso * 0.85;
      T.aFu = 0.55;
      T.aFe = 1.7;
      T.aBu = 0.45;
      T.aBe = 1.8;
    }

    // ---- melee (katana / bat): keyframed 3D moves drive the hips, legs and torso
    if (this.melee) {
      const B = this.updateBladePose(dt, running);
      if (this.slide <= 0 && this.roll <= 0 && !this.dkOn && !this.zip) {
        const acting = !!this.mv || this.meleeCharge > 0 || this.guard;
        if (acting || (!running && this.onGround && this.heavyLand <= 0 && this.kick <= 0)) {
          rate = acting ? 72 : 24;
          T.torso = B.torso;
          T.head = -T.torso * 0.85;
          if (B.hasLegs && (this.onGround || (this.mv !== null && this.mv.w === 'fist')) && this.heavyLand <= 0 && this.kick <= 0 && (acting || !running)) {
            T.fx = B.legs[0];
            T.fy = B.legs[1];
            T.bx = B.legs[2];
            T.by = B.legs[3];
            T.py = B.legs[4] + (acting ? 0 : Math.sin(this.animT * 3.1 + 1) * 0.5);
          }
          if (this.meleeCharge > 0) {
            T.py += 1.5 * this.meleeCharge;
          }
        }
      }
    }

    // ---- door kick with the RIGHT leg: chamber -> heel snap -> hold -> retract -> step through
    if (this.dkOn) {
      const t = this.dkT;
      let kx: number;
      let ky: number;
      let sx = -4;
      let sy = -3;
      if (t < DK_CHAMBER) {
        // anticipation: knee drives up to the chest, chin down, eyes on the lock
        const k = smoothstep(0, DK_CHAMBER, t);
        rate = 48;
        kx = lerp(6, 12, k);
        ky = lerp(-3, -41, k);
        T.py = -47.2 + 1.2 * k;
        T.torso = lerp(0.05, -0.08, k);
        T.head = lerp(-0.03, 0.06, k);
        sx = lerp(-3, -6, k);
      } else if (t < DK_RETRACT) {
        // explosive extension: straight leg at hip height, torso counter-leans
        rate = 90;
        kx = 54;
        ky = -50;
        T.py = -49.5;
        T.px = 2.5;
        T.torso = -0.44;
        T.head = 0.36;
        sx = -7;
      } else if (t < DK_STEP) {
        const k = smoothstep(DK_RETRACT, DK_STEP, t);
        rate = 36;
        kx = lerp(32, 18, k);
        ky = lerp(-34, -8, k);
        T.py = -48;
        T.torso = lerp(-0.26, 0.03, k);
        T.head = lerp(0.24, -0.03, k);
        sx = -6;
      } else {
        // step through the doorway into a firing stance
        const k = smoothstep(DK_STEP, DK_END, t);
        rate = 30;
        kx = lerp(18, 12, k);
        ky = -3;
        T.py = -48;
        T.torso = 0.04;
        T.head = -0.03;
        sx = lerp(-6, -10, k);
      }
      if (this.dkAir) {
        sx = -12;
        sy = -24;
        T.py -= 2;
      }
      // right leg = near leg when facing right, far leg when facing left
      if (this.facing > 0) {
        T.fx = kx;
        T.fy = ky;
        T.bx = sx;
        T.by = sy;
      } else {
        T.bx = kx;
        T.by = ky;
        T.fx = sx;
        T.fy = sy;
      }
    }

    // kick: chamber -> snap -> hold -> recover
    if (this.kick > 0) {
      const k = 1 - this.kick / 0.32;
      rate = 55;
      const a = smoothstep(0, 0.2, k);
      const b = smoothstep(0.2, 0.3, k);
      const c = smoothstep(0.62, 0.95, k);
      let fx = lerp(6, 17, a);
      let fy = lerp(-3, -45, a);
      fx = lerp(fx, 53, b);
      fy = lerp(fy, -53, b);
      fx = lerp(fx, 10, c);
      fy = lerp(fy, -6, c);
      T.fx = fx;
      T.fy = fy;
      T.torso = lerp(lerp(0.05, -0.06, a) + (-0.5 + 0.06) * b, 0.05, c);
      T.head = 0.32 * b * (1 - c);
      T.aBu = lerp(-0.2, -1.3, b * (1 - c));
      if (this.onGround) {
        T.bx = -9;
        T.by = -3;
        T.py = -48 + 2 * b * (1 - c);
      } else {
        T.bx = -12;
        T.by = -18;
      }
    }

    // landing squash
    if (this.landT > 0 && this.onGround && this.slide <= 0 && this.roll <= 0 && this.heavyLand <= 0 && !running) {
      // staggered stance on touchdown: feet split for balance, chest stays up
      const k = this.landT / (0.1 + this.landPower * 0.16);
      const e = Math.sin(Math.min(1, k) * Math.PI * 0.5);
      T.fx += (4 + 4 * this.landPower) * e;
      T.bx -= (4 + 4 * this.landPower) * e;
    }

    // spin legs on ground
    if (this.spin > 0 && this.onGround && !running) {
      T.fx = 3;
      T.bx = -3;
    }

    // guard broken: dazed wobble
    if (this.dazed > 0 && this.onGround) {
      T.torso = -0.15 + Math.sin(this.animT * 9) * 0.14;
      T.head = 0.3;
      T.py = -45;
    }

    // shooting recoil pushes the torso back
    const rec = this.recoil[0] + this.recoil[1];
    if (rec > 0 && this.slide <= 0 && this.roll <= 0) {
      const fwd = Math.cos(this.aimF) * this.facing >= 0 ? 1 : -1;
      T.torso -= 0.075 * rec * fwd;
      T.head -= 0.05 * rec * fwd;
    }

    lerpPose(this.pose, T, smooth(rate, dt));

    if (this.flipping || (this.flipRot !== 0 && this.roll <= 0)) {
      const k = this.stuntK;
      if (!this.flipping || ROT_KINDS.includes(this.flipKind)) rot = this.flipRot;
      else if (this.flipKind === 'superman') rot = Math.pow(Math.sin(k * Math.PI), 0.45) * 1.3;
      else rot = 0;
      cy = -50;
    }

    this.visOff = approach(this.visOff, this.vaultGlide ? 16 : 0, dt * 160);
    const xf = this.xf;
    xf.ox = this.x;
    xf.oy = this.y + this.visOff;
    xf.facing = this.facing;
    xf.rot = rot;
    this.lastRot = rot;
    xf.cx = 0;
    xf.cy = cy;
    let sx = 1;
    if (this.spin > 0) sx = Math.cos(this.spinAngle);
    if (this.melee && this.mv && this.bladePose.spin !== 0) sx = Math.cos(this.bladePose.spin);
    if (Math.abs(sx) < 0.08) sx = sx < 0 ? -0.08 : 0.08;
    xf.sx = sx;
    const wp = this.wp;
    const dip = this.onGround && this.heavyLand <= 0 && this.slide <= 0 ? this.landSpring : 0;
    this.pose.py += dip;
    this.pose.torso += dip * 0.004;
    this.pose.head -= dip * 0.004;
    buildBody(this.pose, PLAYER_DIMS, xf, wp);
    this.pose.py -= dip;
    this.pose.torso -= dip * 0.004;
    this.pose.head += dip * 0.004;

    // arms
    const dkPre = this.dkPre;
    const wantAim =
      aimingNow ||
      (!dkPre &&
        (((!running || this.zip !== null || this.slide > 0 || speed < 190 || this.walkMode) && this.roll <= 0) ||
          (this.roll > 0 && this.roll < ROLL_T * 0.32)));
    this.aimBlend = approach(this.aimBlend, wantAim ? 1 : 0, dt * (wantAim ? 14 : 3));
    const readyOn =
      this.weapon !== 'fist' && (running || dkPre) && !this.zip && this.slide <= 0 && this.roll <= 0 && this.kick <= 0 && (this.onGround || dkPre);
    let readyA = 0;
    if (readyOn) {
      // guns held tight at the chest, muzzles forward — bob with every step
      const f = this.facing;
      const ph = this.runPhase;
      const bob = Math.sin(ph * TAU * 2);
      const sw = Math.cos(ph * TAU);
      reachArm(wp.shF, wp.shF.x + f * (15.5 + 1.3 * sw), wp.shF.y + 6.5 - 1.3 * bob, PLAYER_DIMS, f, wp.elF, wp.haF);
      reachArm(wp.shB, wp.shB.x + f * (13 - 1.3 * sw), wp.shB.y + 9.5 - 1.3 * bob, PLAYER_DIMS, f, wp.elB, wp.haB);
      readyA = (f > 0 ? 0.12 : Math.PI - 0.12) + f * bob * 0.035;
    }
    const fForeA = readyOn ? readyA - this.facing * 0.6 : Math.atan2(wp.haF.y - wp.elF.y, wp.haF.x - wp.elF.x);
    const bForeA = readyOn ? readyA - this.facing * 0.6 : Math.atan2(wp.haB.y - wp.elB.y, wp.haB.x - wp.elB.x);
    aimArm(wp.shF, this.aimF, PLAYER_DIMS, this.recoil[0], this.aimBlend, wp.elF, wp.haF);
    this.backBusy = false;
    wp.gunB = this.weapon;
    if (this.zip) {
      const z = this.zip;
      const gx = this.x - this.facing * 2;
      const tt = (gx - z.x1) / (z.x2 - z.x1);
      const gy = z.y1 + (z.y2 - z.y1) * tt;
      reachArm(wp.shB, gx, gy + 2, PLAYER_DIMS, this.facing, wp.elB, wp.haB);
      wp.gunB = null;
    } else if (
      this.vault > 0.12 &&
      !this.onGround &&
      this.x > this.vaultX0 - 30 &&
      this.x < this.vaultX1 + 30 &&
      this.vaultHY - this.y < 70
    ) {
      // palm plants on the obstacle right under the body
      const hx = clamp(this.x + this.facing * 4, this.vaultX0 + 6, this.vaultX1 - 6);
      reachArm(wp.shB, hx, this.vaultHY - 1, PLAYER_DIMS, this.facing, wp.elB, wp.haB);
      this.backBusy = true;
    } else if (this.heavyLand > 0.1 && this.onGround && this.landStyle === 'slam') {
      reachArm(wp.shB, this.x + this.facing * 22, this.y - 2, PLAYER_DIMS, this.facing, wp.elB, wp.haB);
      this.backBusy = true;
    } else {
      aimArm(wp.shB, this.aimB, PLAYER_DIMS, this.recoil[1], this.aimBlend, wp.elB, wp.haB, 0.86);
    }
    wp.gunF = this.weapon;
    const recF = this.recoil[0] * 0.5 * (Math.cos(this.aimF) >= 0 ? -1 : 1);
    const recB = this.recoil[1] * 0.5 * (Math.cos(this.aimB) >= 0 ? -1 : 1);
    wp.aimF = angleLerp(fForeA + this.facing * 0.6, this.aimF + recF, this.aimBlend);
    if (this.backBusy) {
      wp.aimB = Math.atan2(wp.haB.y - wp.elB.y, wp.haB.x - wp.elB.x) + this.facing * 0.4;
    } else {
      wp.aimB = angleLerp(bForeA + this.facing * 0.6, this.aimB + recB, this.aimBlend);
    }
    // stylish gun twirl while reloading
    if (this.reload > 0) {
      const k = 1 - this.reload / RELOAD_T;
      const tw = easeInOut(k) * TAU * 2 * this.facing;
      wp.aimF += tw;
      wp.aimB += tw;
    }
    wp.tsx = 1;
    wp.flashF = this.flash[0];
    wp.flashB = this.zip ? 0 : this.flash[1];
    wp.slideF = this.weapon === 'pistol' ? this.recoil[0] : 0;
    wp.slideB = this.weapon === 'pistol' ? this.recoil[1] : 0;
    const info = WEAPON_INFO[this.weapon];
    if (info.twoHanded && !info.melee) {
      // two-handed long gun: rear hand on the grip near the shoulder, support hand on the forend
      const lowReady = readyOn && !aimingNow;
      const a = lowReady ? (this.facing > 0 ? 0.32 : Math.PI - 0.32) : this.aimF;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      const sg = ca >= 0 ? 1 : -1;
      const pdx = -sa * sg;
      const pdy = ca * sg;
      const kick = this.weapon === 'sniper' ? 9 : this.weapon === 'shotgun' ? 6 : 3.5;
      const kb = this.recoil[0] * kick;
      const reach = this.weapon === 'sniper' ? 10 : 12;
      const lift = this.weapon === 'sniper' ? 1.5 : 3;
      reachArm(
        wp.shF,
        wp.shF.x + ca * (reach - kb) + pdx * lift,
        wp.shF.y + sa * (reach - kb) + pdy * lift,
        PLAYER_DIMS,
        sg,
        wp.elF,
        wp.haF,
      );
      wp.gunF = this.weapon;
      wp.gunB = null;
      const climb = this.weapon === 'ak47' ? this.heat * 0.08 : 0;
      const recRot = this.weapon === 'sniper' ? 0.55 : this.weapon === 'shotgun' ? 0.38 : 0.16;
      wp.aimF = a - (this.recoil[0] * recRot + climb) * sg;
      wp.flashB = 0;
      wp.slideF = 0;
      if (!this.backBusy && !this.zip) {
        let along = this.weapon === 'sniper' ? 24 : this.weapon === 'ak47' ? 19 : 16;
        let up = 1.5;
        if (this.weapon === 'shotgun') {
          const pump = this.pumpT > 0.08 && this.pumpT < 0.42 ? Math.sin(((0.42 - this.pumpT) / 0.34) * Math.PI) : 0;
          along -= pump * 7;
        } else if (this.weapon === 'sniper' && this.boltT > 0.12 && this.boltT < 0.85) {
          // work the bolt: support hand travels back to the handle and racks it
          const bk = Math.sin(((0.85 - this.boltT) / 0.73) * Math.PI);
          along = lerp(24, 3, bk);
          up = lerp(1.5, -3.5, bk);
          wp.slideF = clamp((0.62 - Math.abs(this.boltT - 0.5)) * 3, 0, 1);
        }
        const fa = wp.aimF;
        reachArm(
          wp.shB,
          wp.haF.x + Math.cos(fa) * along + pdx * up,
          wp.haF.y + Math.sin(fa) * along + pdy * up,
          PLAYER_DIMS,
          sg,
          wp.elB,
          wp.haB,
        );
      }
    } else if (this.weapon === 'fist') {
      // ---- kung fu: lead hand guards the chin, rear hand guards the body; strikes reach the keyed target
      const f = this.facing;
      const B = this.bladePose;
      const m = this.mv;
      const hand = m ? (m.hand ?? 0) : -1;
      const bob = m ? 0 : Math.sin(this.animT * 3.2) * 0.8;
      const sh = wp.shF;
      const sb = wp.shB;
      const restF = { x: sh.x + f * 13, y: sh.y - 6 + bob };
      const restB = { x: sb.x + f * 9, y: sb.y - 2 + bob };
      if (this.guard) {
        restF.x = sh.x + f * 11;
        restF.y = sh.y - 13;
        restB.x = sb.x + f * 13;
        restB.y = sb.y - 9;
      } else if (this.meleeCharge > 0) {
        restF.x = sh.x - f * 3;
        restF.y = sh.y + 4;
        restB.x = sb.x - f * 5;
        restB.y = sb.y + 6;
      } else if (this.dazed > 0) {
        restF.y = sh.y + 22;
        restB.y = sb.y + 24;
      }
      const tF = hand === 0 || hand === 3 ? { x: sh.x + f * B.gx, y: sh.y + B.gy } : restF;
      const tB = hand === 1 || hand === 3 ? { x: sb.x + f * B.gx, y: sb.y + B.gy + (hand === 3 ? 4 : 0) } : restB;
      reachArm(sh, tF.x, tF.y, PLAYER_DIMS, f, wp.elF, wp.haF);
      reachArm(sb, tB.x, tB.y, PLAYER_DIMS, f, wp.elB, wp.haB);
      wp.gunF = null;
      wp.gunB = null;
      wp.flashF = 0;
      wp.flashB = 0;
      wp.slideF = 0;
      wp.tsx = m ? B.sx : 1;
    } else if (info.melee) {
      // ---- 3D blade: project the pose, put both hands on the handle (one hand for the ninja run)
      const f = this.facing;
      const kat = this.weapon === 'katana';
      const B = this.bladePose;
      const acting = !!this.mv || this.meleeCharge > 0 || this.guard;
      const oneHand = this.zip !== null || this.backBusy || (kat && running && !acting && this.onGround);
      const q = this.projectBlade(B);
      let gxw = q.gx;
      let gyw = q.gy;
      if (this.meleeCharge > 0) {
        const j = 0.6 + this.meleeCharge * 1.4;
        gxw += rand(-j, j);
        gyw += rand(-j, j);
      }
      if (!oneHand) {
        reachArm(wp.shB, gxw, gyw, PLAYER_DIMS, f, wp.elB, wp.haB);
        const grip = { x: wp.haB.x, y: wp.haB.y };
        const hs = kat ? 6.5 : 5;
        reachArm(wp.shF, grip.x + q.dx * hs, grip.y + q.dy * hs, PLAYER_DIMS, f, wp.elF, wp.haF);
        this.grip = grip;
      } else {
        reachArm(wp.shF, gxw, gyw, PLAYER_DIMS, f, wp.elF, wp.haF);
        this.grip = { x: wp.haF.x - q.dx * 4, y: wp.haF.y - q.dy * 4 };
      }
      const L = kat ? KATANA.reach : BAT.len;
      this.blade3 = { gx: this.grip.x, gy: this.grip.y, dx: q.dx, dy: q.dy, dz: q.dz, L };
      this.bladeFront = q.gz + q.dz * L * 0.65 >= 0;
      const sh = kat && !acting ? (this.animT % 2.8) / 0.45 : -1;
      this.bladeShine = sh <= 1 ? sh : -1;
      wp.gunF = null;
      wp.gunB = null;
      wp.flashF = 0;
      wp.flashB = 0;
      wp.slideF = 0;
      wp.tsx = acting && B.spin === 0 ? B.sx : 1;
    } else if (this.weapon === 'cricket' || this.weapon === 'sling') {
      // ---- one small gun in the front hand; the back hand supports / pulls the band
      const f = this.facing;
      const lowReady = readyOn && !aimingNow && this.slingCharge <= 0 && this.cricketCharge <= 0;
      const a = lowReady ? (f > 0 ? 0.35 : PI - 0.35) : this.aimF;
      const ca = Math.cos(a);
      const sa = Math.sin(a);
      aimArm(wp.shF, a, PLAYER_DIMS, this.recoil[0], 1, wp.elF, wp.haF);
      wp.gunF = this.weapon;
      wp.gunB = null;
      wp.flashB = 0;
      wp.aimF = a - this.recoil[0] * (this.weapon === 'cricket' ? 0.9 : 0.15) * (ca >= 0 ? 1 : -1);
      if (this.weapon === 'cricket') {
        const ch = this.cricketCharge > 0 ? 1 - this.cricketCharge / CRICKET.charge : 0;
        wp.slideF = ch;
        if (ch > 0) {
          const j = ch * 1.6;
          wp.haF.x += rand(-j, j);
          wp.haF.y += rand(-j, j);
        }
        if (!this.backBusy && !this.zip) {
          // cup-and-saucer grip under the shooting hand
          reachArm(wp.shB, wp.haF.x - ca * 3, wp.haF.y - sa * 3 + 4, PLAYER_DIMS, f, wp.elB, wp.haB);
        }
      } else {
        wp.slideF = 0;
        const sg = ca >= 0 ? 1 : -1;
        const fa = wp.aimF;
        const cf = Math.cos(fa);
        const sf = Math.sin(fa);
        const toW = (lx: number, ly: number) => ({ x: wp.haF.x + lx * cf - ly * sg * sf, y: wp.haF.y + lx * sf + ly * sg * cf });
        const fork = toW(0.6, -12);
        const tA = toW(-3, -12);
        const tB = toW(4.2, -12.5);
        this.slingFork = fork;
        this.slingTips = [tA.x, tA.y, tB.x, tB.y];
        const k = Math.min(1, this.slingCharge / SLING.max);
        // pouch rest -> drawn back to the cheek
        const rest = { x: fork.x - cf * 6, y: fork.y - sf * 6 };
        const anchor = { x: wp.head.x - f * 2, y: wp.head.y + 6 };
        const back = { x: lerp(rest.x, anchor.x - cf * 6, k), y: lerp(rest.y, anchor.y - sf * 6, k) };
        if (!this.backBusy && !this.zip) {
          reachArm(wp.shB, back.x, back.y, PLAYER_DIMS, f, wp.elB, wp.haB);
          this.slingPouch = { x: wp.haB.x, y: wp.haB.y };
        } else this.slingPouch = rest;
      }
    }
    if (this.swapT > 0) {
      // quick weapon swap flourish: guns dip and flip back up
      const k = Math.sin((this.swapT / 0.22) * Math.PI);
      wp.aimF += this.facing * k * 1.1;
      wp.aimB += this.facing * k * 1.1;
      wp.haF.y += k * 7;
      wp.haB.y += k * 7;
      wp.elF.y += k * 4;
      wp.elB.y += k * 4;
    }
    wp.hit = this.hurtT > 0 ? this.hurtT * 3 : 0;
    this.blinkT -= dt;
    if (this.blinkT < -0.12) this.blinkT = rand(2, 4.5);
    wp.blink = this.blinkT < 0;
    wp.angry = sinceShot < 1.5;
    wp.dead = false;

    // foot swoosh trails
    const trailOn = this.flipping || this.kick > 0 || this.roll > 0 || this.vault > 0 || this.dive;
    if (this.dkOn && this.dkT > DK_CHAMBER * 0.6 && this.dkT < DK_STEP) {
      const toe = this.facing > 0 ? wp.toeF : wp.toeB;
      this.trail.push(toe.x, toe.y, this.animT);
    } else if (trailOn) {
      this.trail.push(wp.toeF.x, wp.toeF.y, this.animT);
      if (this.flipping || this.roll > 0) this.trail2.push(wp.toeB.x, wp.toeB.y, this.animT);
    }
    while (this.trail.length && this.animT - this.trail[2] > 0.15) this.trail.splice(0, 3);
    while (this.trail2.length && this.animT - this.trail2[2] > 0.15) this.trail2.splice(0, 3);

    // ghosts
    this.ghostT -= dt;
    const fast =
      this.swallowT >= 0 ||
      (!!this.mv && (this.mv.id === 'kIaiDash' || (this.mv.w === 'katana' && this.mvStrike && this.mv.spin === true))) ||
      (this.dkOn && this.dkT > DK_CHAMBER && this.dkT < DK_RETRACT) ||
      this.dive ||
      this.flipping ||
      this.spin > 0 ||
      this.slide > 0 ||
      this.roll > 0 ||
      this.vault > 0 ||
      this.wallJumpLock > -0.2;
    if (fast && this.ghostT <= 0) {
      this.ghostT = 0.04;
      const g: Ghost = { pts: new Float32Array(24), life: 0.2 };
      snapshotPose(wp, g.pts);
      this.ghosts.push(g);
      if (this.ghosts.length > 7) this.ghosts.shift();
    }
  }

  /** returns world muzzle position & angle for gun index */
  muzzle(gun: number, len: number) {
    const wp = this.wp;
    const h = gun === 0 ? wp.haF : wp.haB;
    const a = gun === 0 ? this.aimF : this.aimB;
    const ly = Math.cos(a) >= 0 ? -2.4 : 2.4;
    const c = Math.cos(a);
    const s = Math.sin(a);
    return { x: h.x + len * c - ly * s, y: h.y + len * s + ly * c, a };
  }
}
