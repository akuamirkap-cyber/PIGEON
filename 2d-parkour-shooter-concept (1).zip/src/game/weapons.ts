export type WeaponId = 'pistol' | 'uzi' | 'shotgun' | 'ak47' | 'sniper' | 'bat' | 'sling' | 'cricket' | 'katana' | 'fist';

export interface WeaponInfo {
  name: string;
  max: number;
  dual: boolean;
  twoHanded: boolean;
  melee: boolean;
  color: string;
  pickup: number;
  drop: number;
}

/** slot order = number keys 1..8 */
export const WEAPON_ORDER: WeaponId[] = ['pistol', 'uzi', 'shotgun', 'ak47', 'sniper', 'bat', 'sling', 'cricket', 'katana', 'fist'];

export const WEAPON_INFO: Record<WeaponId, WeaponInfo> = {
  pistol: { name: 'PISTOL GANDA', max: 12, dual: true, twoHanded: false, melee: false, color: '#f2c14e', pickup: 12, drop: 0 },
  uzi: { name: 'UZI GANDA', max: 50, dual: true, twoHanded: false, melee: false, color: '#7fe0ff', pickup: 50, drop: 25 },
  shotgun: { name: 'SHOTGUN', max: 8, dual: false, twoHanded: true, melee: false, color: '#ff9a5a', pickup: 6, drop: 4 },
  ak47: { name: 'AK-47', max: 30, dual: false, twoHanded: true, melee: false, color: '#ffb347', pickup: 30, drop: 18 },
  sniper: { name: 'SNIPER', max: 5, dual: false, twoHanded: true, melee: false, color: '#8dff8a', pickup: 5, drop: 3 },
  bat: { name: 'PEMUKUL BISBOL', max: 16, dual: false, twoHanded: true, melee: true, color: '#e8b46a', pickup: 16, drop: 16 },
  sling: { name: 'KETAPEL', max: 30, dual: false, twoHanded: false, melee: false, color: '#b5e86a', pickup: 30, drop: 0 },
  cricket: { name: 'NOISY CRICKET', max: 4, dual: false, twoHanded: false, melee: false, color: '#8fe3ff', pickup: 4, drop: 0 },
  katana: { name: 'KATANA', max: 1, dual: false, twoHanded: true, melee: true, color: '#c7f0ff', pickup: 1, drop: 1 },
  fist: { name: 'TANGAN KOSONG', max: 1, dual: false, twoHanded: false, melee: true, color: '#ffd23f', pickup: 1, drop: 0 },
};

export function isWeaponId(s: unknown): s is WeaponId {
  return typeof s === 'string' && s in WEAPON_INFO;
}

/** bat swing timeline (seconds): stance -> load -> launch -> contact -> follow-through -> recover */
export const BAT = {
  load: 0.085,
  launch: 0.12,
  contact: 0.19,
  hit0: 0.15,
  hit1: 0.235,
  chain: 0.31,
  end: 0.47,
  cd: 0,
  len: 50,
};

/** slingshot: max draw time & stone speeds */
export const SLING = { max: 0.55, vmin: 640, vmax: 1560, g: 1300 };

/** noisy cricket: charge time */
export const CRICKET = { charge: 0.3 };
