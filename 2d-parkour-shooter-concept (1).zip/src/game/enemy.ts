import {
  aimArm,
  muzzleLen,
  BOSS_DIMS,
  buildBody,
  ENEMY_DIMS,
  lerpPose,
  mafiaLook,
  newPose,
  newWorldPose,
  reachArm,
  type Dims,
  type GunKind,
  type Look,
  type Pose,
  type WorldPose,
  type Xform,
} from './character';
import type { EnemyDef, EnemyType } from './level';
import { approach, clamp, rand, segRect, sign, smooth, TAU, wrapAngle } from './math';
import type { Player } from './player';
import type { Sound } from './audio';
import type { MoveResult, World } from './world';

export interface EnemyHost {
  world: World;
  time: number;
  player: Player;
  sfx: Sound;
  enemyFire(e: Enemy, gun: GunKind, x: number, y: number, angle: number): void;
}

let EID = 1;

export class Enemy {
  id = EID++;
  type: EnemyType;
  section: number;
  def: EnemyDef;
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  w = 28;
  h: number;
  facing: number;
  hp: number;
  maxHp: number;
  alive = true;
  state: 'idle' | 'alert' | 'stunned' = 'idle';
  reaction = 0;
  fireCd = 0;
  burst = 0;
  burstCd = 0;
  aim: number;
  seen = false;
  lastSeenT = -100;
  losT = Math.random() * 0.1;
  lastKnownX = 0;
  lastKnownY = 0;
  walkPhase = Math.random();
  hitT = 0;
  hitDir = 1;
  stun = 0;
  noticeT = 0;
  onGround = false;
  patrolDir: number;
  idleT = rand(0, 3);
  recoil = 0;
  flash = 0;
  animT = Math.random() * 10;
  look: Look;
  dims: Dims;
  gun: GunKind;
  pose: Pose = newPose();
  target: Pose = newPose();
  wp: WorldPose = newWorldPose();
  xf: Xform = { ox: 0, oy: 0, facing: 1, rot: 0, cx: 0, cy: -50, sx: 1 };
  lastHitHead = false;
  snipe = 0;
  snipeBeep = 0;
  // posture (kung-fu): fill it up to break the enemy -> takedown
  struct = 0;
  structMax = 5;
  flung = 0;
  wallHit = false;
  wallDir = 1;
  // ---- boss-mode extras (used by boss subclasses)
  isBossMode = false;
  bossName = '';
  bossTitle = '';
  phaseMarks: number[] = [];
  invuln = 0;
  bodyRot = 0;
  bodySx = 1;
  hpShown = 0;
  protected res: MoveResult = { hitX: 0, hitY: 0, onGround: false, ground: null, wallSolid: null, dynHit: null };

  constructor(def: EnemyDef) {
    this.def = def;
    this.type = def.type;
    this.section = def.section;
    this.x = def.x;
    this.y = def.y;
    this.facing = def.facing;
    this.patrolDir = def.facing;
    this.look = mafiaLook(def.type, def.variant ?? 0);
    this.dims = def.type === 'boss' ? BOSS_DIMS : ENEMY_DIMS;
    this.h = def.type === 'boss' ? 106 : 99;
    this.w = def.type === 'boss' ? 34 : 28;
    this.maxHp = def.type === 'boss' ? 24 : def.type === 'gunner' || def.type === 'rifleman' ? 4 : 3;
    this.hp = this.maxHp;
    this.structMax = def.type === 'boss' ? 12 : 5;
    this.gun =
      def.type === 'boss'
        ? 'shotgun'
        : def.type === 'gunner'
          ? 'uzi'
          : def.type === 'rifleman'
            ? 'ak47'
            : def.type === 'sniper'
              ? 'sniper'
              : 'pistol';
    this.aim = def.facing > 0 ? 0.6 : Math.PI - 0.6;
    this.pose.py = -51;
    this.lastKnownX = def.x;
    this.lastKnownY = def.y;
  }

  get headX() {
    return this.wp.head.x;
  }
  get headY() {
    return this.wp.head.y;
  }

  shoulder() {
    return this.wp.shF;
  }

  alert(time: number, sfx: Sound, quick = false) {
    if (this.state === 'alert' || !this.alive) return;
    this.state = 'alert';
    this.reaction = quick ? rand(0.2, 0.35) : this.type === 'boss' ? rand(0.5, 0.7) : rand(0.5, 0.85);
    this.noticeT = 1.1;
    this.lastSeenT = time;
    sfx.alert();
  }

  hearNoise(x: number, y: number, radius: number, time: number, sfx: Sound) {
    if (!this.alive || this.state !== 'idle') return;
    const d = Math.hypot(x - this.x, y - (this.y - 50));
    if (d < radius) {
      this.lastKnownX = x;
      this.lastKnownY = y;
      this.alert(time, sfx);
      this.facing = x >= this.x ? 1 : -1;
    }
  }

  hurt(dmg: number, dirx: number, head: boolean, time: number, sfx: Sound) {
    this.hp -= dmg;
    this.hitT = 0.22;
    this.hitDir = sign(dirx);
    this.lastHitHead = head;
    if (this.type !== 'boss') {
      this.vx += sign(dirx) * 70;
      this.aim += rand(-0.5, 0.5);
      this.fireCd = Math.max(this.fireCd, 0.25);
    } else {
      this.aim += rand(-0.15, 0.15);
    }
    if (this.state === 'idle') {
      this.alert(time, sfx, true);
      this.facing = dirx > 0 ? -1 : 1;
    }
    return this.hp <= 0;
  }

  stunFor(t: number, vx: number, vy: number) {
    this.state = 'stunned';
    this.stun = t;
    this.vx = vx;
    this.vy = vy;
    this.onGround = false;
    this.burst = 0;
  }

  protected canSee(world: World, x1: number, y1: number, x2: number, y2: number) {
    if (world.raycast(x1, y1, x2, y2, false, false)) return false;
    for (const d of world.dyn) {
      if (d.kind !== 'door') continue;
      if (segRect(x1, y1, x2, y2, d)) return false;
    }
    return true;
  }

  protected groundAhead(world: World, dir: number) {
    const fx = this.x + dir * (this.w / 2 + 10);
    return !!world.solidAt(fx, this.y + 6, true) && world.rectFree(fx - 4, this.y - this.h + 10, 8, this.h - 20, true);
  }

  /** subclasses can take over the whole update (boss AI). Return true when handled. */
  protected bossUpdate(_dt: number, _host: EnemyHost): boolean {
    return false;
  }

  /** shared gravity + collision step */
  protected physics(dt: number, world: World) {
    this.vy += 2200 * dt;
    if (this.vy > 1500) this.vy = 1500;
    const body = { x: this.x - this.w / 2, y: this.y - this.h, w: this.w, h: this.h, vx: this.vx, vy: this.vy };
    world.moveBody(body, dt, false, this.res);
    this.x = body.x + this.w / 2;
    this.y = body.y + this.h;
    if (this.res.hitX !== 0 && this.flung > 0 && Math.abs(this.vx) > 260) {
      this.wallHit = true;
      this.wallDir = sign(this.vx);
    }
    this.onGround = this.res.onGround;
    if (this.onGround) this.vy = 0;
  }

  /** pose override hook (return a custom blend rate, or 0) */
  protected poseHook(_T: Pose, _dt: number): number {
    return 0;
  }

  /** arm / weapon override hook (after the skeleton is built) */
  protected armHook(_wp: WorldPose): void {}

  /** non-humanoid bosses draw themselves; return true when handled */
  drawSelf(_ctx: CanvasRenderingContext2D, _t: number): boolean {
    return false;
  }

  /** extra effects drawn on top of the character */
  drawOverlay(ctx: CanvasRenderingContext2D, t: number): void {
    if (this.state !== 'stunned' || this.stun < 0.12) return;
    const hx = this.wp.head.x;
    const hy = this.wp.head.y - 16;
    for (let i = 0; i < 3; i++) {
      const a = t * 6 + (i * TAU) / 3;
      ctx.save();
      ctx.translate(hx + Math.cos(a) * 15, hy + Math.sin(a) * 5);
      ctx.rotate(t * 4 + i);
      ctx.fillStyle = '#ffd23f';
      ctx.strokeStyle = '#1b1410';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      for (let k = 0; k < 10; k++) {
        const r = k % 2 === 0 ? 5 : 2.2;
        const aa = (k / 10) * TAU - Math.PI / 2;
        if (k === 0) ctx.moveTo(Math.cos(aa) * r, Math.sin(aa) * r);
        else ctx.lineTo(Math.cos(aa) * r, Math.sin(aa) * r);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  }

  /** custom bullet hit-test (undefined = use the skeleton test) */
  hitTestCustom(_x1: number, _y1: number, _x2: number, _y2: number): { t: number; head: boolean } | null | undefined {
    return undefined;
  }

  get customDeath() {
    return false;
  }

  onCustomDeath(_host: EnemyHost): void {}

  update(dt: number, host: EnemyHost) {
    if (!this.alive) return;
    if (this.bossUpdate(dt, host)) return;
    const world = host.world;
    const p = host.player;
    this.animT += dt;
    this.hitT -= dt;
    this.noticeT -= dt;
    this.fireCd -= dt;
    this.burstCd -= dt;
    this.recoil = Math.max(0, this.recoil - dt * 7);
    this.flash = Math.max(0, this.flash - dt);
    this.flung -= dt;
    if (this.state !== 'stunned') this.struct = Math.max(0, this.struct - dt * 0.8);

    const eyeX = this.x;
    const eyeY = this.y - this.h + 16;
    const px = p.x;
    const py = p.y - p.h * 0.6;
    const dx = px - eyeX;
    const dy = py - eyeY;
    const d = Math.hypot(dx, dy);

    this.losT -= dt;
    if (this.losT <= 0) {
      this.losT = 0.1;
      let can = false;
      const range = this.type === 'boss' ? 1150 : this.type === 'sniper' ? 1500 : 950;
      if (p.alive && d < range && Math.abs(dy) < 560) {
        const inFront = sign(dx) === this.facing || Math.abs(dx) < 110 || this.state === 'alert';
        if (inFront && this.canSee(world, eyeX, eyeY, px, py)) can = true;
      }
      this.seen = can;
      if (can) {
        this.lastSeenT = host.time;
        this.lastKnownX = px;
        this.lastKnownY = py;
      }
    }
    if (this.seen && this.state === 'idle') this.alert(host.time, host.sfx);

    let move = 0;
    let speed = this.type === 'boss' ? 120 : 150;
    if (this.state === 'stunned') {
      this.stun -= dt;
      if (this.onGround) this.vx = approach(this.vx, 0, 900 * dt);
      if (this.stun <= 0) {
        this.state = 'alert';
        this.reaction = 0.3;
        if (this.struct >= this.structMax) this.struct = 0;
      }
    } else if (this.state === 'alert') {
      const tx = this.seen ? px : this.lastKnownX;
      if (Math.abs(tx - this.x) > 6) this.facing = tx >= this.x ? 1 : -1;
      // aim with lead
      const sh = this.wp.shF;
      const travel = d / 1500;
      const lead = this.type === 'boss' ? 0.25 : this.type === 'sniper' ? 0 : 0.45;
      const ax = (this.seen ? px + p.vx * travel * lead : this.lastKnownX) - sh.x;
      const ay = (this.seen ? py + p.vy * travel * lead * 0.5 : this.lastKnownY) - sh.y;
      const want = Math.atan2(ay, ax);
      const turn = (this.type === 'boss' ? 3.2 : this.type === 'sniper' ? 2.3 : 4.5) * dt;
      const diff = wrapAngle(want - this.aim);
      this.aim += clamp(diff, -turn, turn);

      // movement
      const prefMin = this.type === 'boss' ? 160 : this.type === 'sniper' ? 320 : 220;
      const prefMax =
        this.type === 'boss' ? 380 : this.type === 'gunner' ? 520 : this.type === 'sniper' ? 1400 : 600;
      const adx = Math.abs(px - this.x);
      if (this.seen) {
        const above = p.y < this.y - 70;
        if (adx > prefMax) move = sign(px - this.x);
        else if (adx < prefMin && !above) move = -sign(px - this.x);
      } else if (host.time - this.lastSeenT < 4 && Math.abs(this.lastKnownX - this.x) > 80) {
        move = sign(this.lastKnownX - this.x);
        speed *= 1.2;
      }
      if (this.hitT > 0 && this.type !== 'boss') move = 0;
      if (move !== 0 && !this.groundAhead(world, move)) move = 0;

      // shooting
      this.reaction -= dt;
      const aimed = Math.abs(diff) < 0.3;
      if (this.type === 'sniper') {
        // laser lock: charge while the dot sits on the target, then one lethal round
        if (this.seen && this.reaction <= 0 && this.fireCd <= 0 && p.alive && Math.abs(diff) < 0.14) {
          this.snipe += dt;
          this.snipeBeep -= dt;
          if (this.snipe > 0.55 && this.snipeBeep <= 0) {
            host.sfx.sniperBeep(false);
            this.snipeBeep = this.snipe > 0.95 ? 0.08 : 0.18;
          }
          if (this.snipe >= 1.25) {
            host.sfx.sniperBeep(true);
            this.fire(host);
            this.snipe = 0;
            this.fireCd = rand(2.0, 2.6);
          }
        } else this.snipe = Math.max(0, this.snipe - dt * 1.5);
      } else if (this.burst > 0) {
        if (this.burstCd <= 0) {
          this.fire(host);
          this.burst--;
          this.burstCd = this.gun === 'ak47' ? 0.11 : 0.085;
          if (this.burst <= 0) this.fireCd = rand(1.2, 1.7);
        }
      } else if (this.seen && this.reaction <= 0 && this.fireCd <= 0 && aimed && p.alive) {
        if (this.type === 'gunner' || this.type === 'rifleman') {
          this.burst = this.type === 'rifleman' ? 3 : 5;
          this.burstCd = 0;
        } else {
          this.fire(host);
          const enraged = this.type === 'boss' && this.hp < this.maxHp * 0.5;
          this.fireCd = this.type === 'boss' ? (enraged ? rand(0.75, 1.0) : rand(1.1, 1.45)) : rand(0.9, 1.35);
        }
      }
      if (!this.seen && host.time - this.lastSeenT > 6) this.state = 'idle';
    } else {
      // idle / patrol
      this.idleT -= dt;
      if (this.def.patrol) {
        const [a, b] = this.def.patrol;
        if (this.x < a) this.patrolDir = 1;
        else if (this.x > b) this.patrolDir = -1;
        if (this.idleT < 0) {
          move = this.patrolDir;
          speed = 70;
          if (this.idleT < -3.5) this.idleT = rand(1.2, 2.5);
        }
        if (move !== 0) this.facing = move;
        if (move !== 0 && !this.groundAhead(world, move)) {
          this.patrolDir *= -1;
          move = 0;
        }
      }
      const rest = this.facing > 0 ? 1.1 : Math.PI - 1.1;
      this.aim = this.aim + wrapAngle(rest - this.aim) * smooth(4, dt);
    }

    if (this.state !== 'stunned') this.vx = approach(this.vx, move * speed, 1100 * dt);
    this.vy += 2200 * dt;
    if (this.vy > 1500) this.vy = 1500;
    const body = { x: this.x - this.w / 2, y: this.y - this.h, w: this.w, h: this.h, vx: this.vx, vy: this.vy };
    world.moveBody(body, dt, false, this.res);
    this.x = body.x + this.w / 2;
    this.y = body.y + this.h;
    if (this.res.hitX !== 0) {
      if (this.flung > 0 && Math.abs(this.vx) > 260) {
        this.wallHit = true;
        this.wallDir = sign(this.vx);
      }
      this.vx = 0;
    }
    this.onGround = this.res.onGround;
    if (this.onGround) this.vy = 0;

    this.animate(dt, move);
  }

  protected fire(host: EnemyHost) {
    const len = muzzleLen(this.gun);
    const h = this.wp.haF;
    const a = this.aim;
    const ly = Math.cos(a) >= 0 ? -2.4 : 2.4;
    const x = h.x + Math.cos(a) * len - ly * Math.sin(a);
    const y = h.y + Math.sin(a) * len + ly * Math.cos(a);
    this.recoil = 1;
    this.flash = 0.06;
    host.enemyFire(this, this.gun, x, y, a);
  }

  protected animate(dt: number, move: number) {
    const T = this.target;
    const t = this.animT;
    const breathe = Math.sin(t * 2.1);
    const speed = Math.abs(this.vx);
    let rate = 16;
    T.px = 0;
    T.py = -51 + breathe * 0.6;
    T.torso = 0.03;
    T.head = 0;
    T.fx = 6;
    T.fy = -3;
    T.bx = -6;
    T.by = -3;
    T.aFu = 0.12;
    T.aFe = 0.35;
    T.aBu = -0.08;
    T.aBe = 0.25;
    if (this.type === 'boss') {
      T.fx = 8;
      T.bx = -8;
    }
    if (this.state === 'stunned') {
      const s = Math.sin(t * 14);
      T.torso = -0.35 + s * 0.1;
      T.head = 0.3;
      T.fx = 10 + s * 6;
      T.bx = -10 - s * 6;
      T.fy = -3 - Math.max(0, s) * 8;
      T.by = -3 - Math.max(0, -s) * 8;
      T.aFu = 2.4 + s * 0.5;
      T.aBu = 2.0 - s * 0.5;
      rate = 22;
    } else if (!this.onGround) {
      T.fx = 10;
      T.fy = -14;
      T.bx = -8;
      T.by = -8;
      T.aBu = 2.2;
    } else if (speed > 15) {
      // confident mafia walk: chest up, heel-to-toe, hips rise over the planted leg
      const r = clamp(speed / 160, 0, 1.2);
      const travel = 22 + 15 * r;
      const duty = 0.62 - 0.05 * r;
      const freq = (duty * speed) / travel;
      this.walkPhase = (this.walkPhase + freq * dt) % 1;
      const lift = 6 + 7 * r;
      const leg = (s: number) => {
        if (s < duty) {
          const u = s / duty;
          return [travel * (0.45 - u), u > 0.8 ? -3 - ((u - 0.8) / 0.2) * 2.5 : -3];
        }
        const u = (s - duty) / (1 - duty);
        const fwd = 1 - Math.pow(1 - u, 1.6);
        return [travel * (-0.55 + fwd), -3 - lift * Math.sin(Math.PI * u)];
      };
      const back = move !== 0 && move !== this.facing;
      const sf = back ? 1 - this.walkPhase : this.walkPhase;
      const [a, b] = leg(sf);
      const [c, e] = leg((sf + 0.5) % 1);
      T.fx = a + 2;
      T.fy = b;
      T.bx = c + 2;
      T.by = e;
      const cyc = Math.cos(4 * Math.PI * (sf - duty / 2));
      T.py = r > 1 ? -50.2 + 1.2 * cyc : -50.8 - 1.1 * cyc;
      T.torso = (back ? -0.05 : 0.025) + 0.02 * Math.sin(4 * Math.PI * sf);
      T.head = -T.torso * 0.8;
      const sw = Math.cos(sf * TAU);
      T.aBu = sw * 0.45;
      T.aBe = 0.3 + 0.35 * Math.max(0, sw);
      rate = 24;
    }
    if (this.hitT > 0) {
      const k = this.hitT / 0.22;
      T.torso -= 0.35 * k * this.hitDir * this.facing;
      T.head -= 0.4 * k * this.hitDir * this.facing;
    }
    const hookRate = this.poseHook(T, dt);
    if (hookRate > 0) rate = hookRate;
    lerpPose(this.pose, T, smooth(rate, dt));
    const xf = this.xf;
    xf.ox = this.x;
    xf.oy = this.y;
    xf.facing = this.facing;
    xf.rot = this.bodyRot;
    xf.sx = this.bodySx;
    buildBody(this.pose, this.dims, xf, this.wp);
    const wp = this.wp;
    const aiming = this.state === 'alert';
    wp.gunF = this.gun;
    wp.gunB = null;
    if (aiming) {
      aimArm(wp.shF, this.aim, this.dims, this.recoil, 1, wp.elF, wp.haF);
      const rec = this.recoil * 0.45 * (Math.cos(this.aim) >= 0 ? -1 : 1);
      wp.aimF = this.aim + rec;
      if (this.type === 'boss' || this.gun === 'ak47' || this.gun === 'sniper') {
        const along = this.gun === 'sniper' ? 24 : this.gun === 'ak47' ? 19 : 15;
        const gx = wp.haF.x + Math.cos(wp.aimF) * along;
        const gy = wp.haF.y + Math.sin(wp.aimF) * along;
        reachArm(wp.shB, gx, gy, this.dims, this.facing, wp.elB, wp.haB);
      }
    } else {
      const fa = Math.atan2(wp.haF.y - wp.elF.y, wp.haF.x - wp.elF.x);
      wp.aimF = fa + this.facing * 0.9;
      if (this.type === 'boss') {
        wp.aimF = this.facing > 0 ? 0.5 : Math.PI - 0.5;
        const gx = wp.haF.x + Math.cos(wp.aimF) * 15;
        const gy = wp.haF.y + Math.sin(wp.aimF) * 15;
        reachArm(wp.shB, gx, gy, this.dims, this.facing, wp.elB, wp.haB);
      }
    }
    wp.flashF = this.flash;
    wp.flashB = 0;
    wp.slideF = this.gun === 'pistol' ? this.recoil : 0;
    wp.hit = this.hitT > 0 ? this.hitT * 4 : 0;
    wp.blink = Math.sin(t * 1.3 + this.id) > 0.985;
    wp.angry = aiming;
    wp.dead = false;
    this.armHook(wp);
  }
}
