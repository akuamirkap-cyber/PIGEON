import { ik2, type Vec2 } from './math';
import type { World, AnySolid } from './world';

export type GunKind =
  | 'pistol'
  | 'uzi'
  | 'shotgun'
  | 'cleaver'
  | 'tommy'
  | 'ak47'
  | 'sniper'
  | 'bat'
  | 'sling'
  | 'cricket'
  | 'katana'
  | 'fist'
  | null;

export interface Look {
  kid: boolean;
  boss: boolean;
  skin: string;
  skinShade: string;
  hair: string;
  shirt: string;
  shirtShade: string;
  jacket: string | null;
  jacketShade: string;
  tie: string;
  pants: string;
  pantsShade: string;
  shoe: string;
  shoeShade: string;
  sole: string;
  hat: boolean;
  hatColor: string;
  hatBand: string;
  glasses: boolean;
  mustache: 0 | 1 | 2;
  outline: string;
  bald?: boolean;
  beard?: boolean;
  apron?: boolean;
  noTie?: boolean;
  tankTop?: boolean;
}

export interface Dims {
  thigh: number;
  shin: number;
  torso: number;
  neck: number;
  headR: number;
  upper: number;
  fore: number;
  wThigh: number;
  wShin: number;
  wUpper: number;
  wFore: number;
  torsoTop: number;
  torsoBot: number;
  foot: number;
}

export const PLAYER_DIMS: Dims = {
  thigh: 24.5,
  shin: 24,
  torso: 26.5,
  neck: 3,
  headR: 10,
  upper: 16,
  fore: 15,
  wThigh: 9.5,
  wShin: 7.5,
  wUpper: 6.5,
  wFore: 5.6,
  torsoTop: 17,
  torsoBot: 15,
  foot: 11,
};

export const ENEMY_DIMS: Dims = {
  thigh: 25,
  shin: 24.5,
  torso: 28.5,
  neck: 3.5,
  headR: 9.7,
  upper: 17,
  fore: 16,
  wThigh: 10.5,
  wShin: 8.5,
  wUpper: 7.5,
  wFore: 6.6,
  torsoTop: 19.5,
  torsoBot: 16,
  foot: 12,
};

export const BOSS_DIMS: Dims = {
  thigh: 26,
  shin: 25,
  torso: 31,
  neck: 4,
  headR: 10.5,
  upper: 18,
  fore: 17,
  wThigh: 13,
  wShin: 10,
  wUpper: 9.5,
  wFore: 8,
  torsoTop: 26,
  torsoBot: 25,
  foot: 13,
};

export const PLAYER_LOOK: Look = {
  kid: true,
  boss: false,
  skin: '#f7c9a1',
  skinShade: '#dfa67a',
  hair: '#7a4421',
  shirt: '#ffc21a',
  shirtShade: '#e39a0c',
  jacket: null,
  jacketShade: '',
  tie: '',
  pants: '#55912e',
  pantsShade: '#3f7020',
  shoe: '#e23b2e',
  shoeShade: '#b42a20',
  sole: '#f6f6f2',
  hat: false,
  hatColor: '',
  hatBand: '',
  glasses: false,
  mustache: 0,
  outline: '#1b1410',
};

const SUITS: [string, string][] = [
  ['#272a31', '#181a1f'],
  ['#3d4049', '#2a2c33'],
  ['#1f2a3d', '#151c2a'],
  ['#4b3b2f', '#352920'],
  ['#2e2e2e', '#1d1d1d'],
  ['#3a2b45', '#271c30'],
];
const SKINS: [string, string][] = [
  ['#f1c27d', '#d9a35c'],
  ['#e8b48a', '#cc956a'],
  ['#d9a066', '#bd844b'],
  ['#c68642', '#a66c2f'],
  ['#f5cfa5', '#dcae82'],
  ['#e0ac69', '#c38f4f'],
];
const HAIRS = ['#2b1d14', '#161616', '#4a2c17', '#3b2a20', '#1e1410', '#5a3a22'];
const TIES = ['#c0392b', '#141414', '#8e44ad', '#c0392b', '#16a085', '#d35400'];

export function mafiaLook(type: 'thug' | 'gunner' | 'rifleman' | 'sniper' | 'boss', variant: number): Look {
  const v = Math.abs(variant) % 6;
  if (type === 'boss') {
    return {
      kid: false,
      boss: true,
      skin: '#e8b48a',
      skinShade: '#c8946a',
      hair: '#1e1410',
      shirt: '#2a1a1a',
      shirtShade: '#1a1010',
      jacket: '#efe8d6',
      jacketShade: '#cfc5ad',
      tie: '#d62828',
      pants: '#e6dfcb',
      pantsShade: '#c7bea6',
      shoe: '#5b3a24',
      shoeShade: '#3f2716',
      sole: '#1b120c',
      hat: true,
      hatColor: '#f2ecdc',
      hatBand: '#1a1a1a',
      glasses: false,
      mustache: 2,
      outline: '#1b1410',
    };
  }
  const suit: [string, string] =
    type === 'rifleman'
      ? ['#3b4232', '#2a2f24']
      : type === 'sniper'
        ? ['#4a4038', '#352d27']
        : SUITS[(v + (type === 'gunner' ? 1 : 0)) % SUITS.length];
  const skin = SKINS[v];
  return {
    kid: false,
    boss: false,
    skin: skin[0],
    skinShade: skin[1],
    hair: HAIRS[v],
    shirt: '#f3f3f0',
    shirtShade: '#cfcfca',
    jacket: suit[0],
    jacketShade: suit[1],
    tie: TIES[v],
    pants: suit[0],
    pantsShade: suit[1],
    shoe: '#141414',
    shoeShade: '#0a0a0a',
    sole: '#050505',
    hat: type === 'gunner' || type === 'sniper' || type === 'rifleman' ? true : v % 2 === 1,
    hatColor: type === 'gunner' ? '#55585f' : type === 'rifleman' ? '#2f3a28' : type === 'sniper' ? '#5a4632' : '#1c1c1c',
    hatBand: type === 'gunner' || type === 'rifleman' ? '#1a1a1a' : type === 'sniper' ? '#2a1a10' : '#7a1c1c',
    glasses: type === 'gunner' || type === 'rifleman' ? true : type === 'sniper' ? false : v % 3 === 0,
    mustache: v % 2 === 0 ? 1 : 0,
    outline: '#1b1410',
  };
}

/** Local pose (character facing right, feet origin at 0,0, y down) */
export interface Pose {
  px: number;
  py: number;
  torso: number;
  head: number;
  fx: number;
  fy: number;
  bx: number;
  by: number;
  aFu: number;
  aFe: number;
  aBu: number;
  aBe: number;
}

export function newPose(): Pose {
  return { px: 0, py: -46, torso: 0, head: 0, fx: 6, fy: -3, bx: -6, by: -3, aFu: 0.2, aFe: 0.4, aBu: -0.1, aBe: 0.3 };
}

export function lerpPose(p: Pose, t: Pose, k: number) {
  p.px += (t.px - p.px) * k;
  p.py += (t.py - p.py) * k;
  p.torso += (t.torso - p.torso) * k;
  p.head += (t.head - p.head) * k;
  p.fx += (t.fx - p.fx) * k;
  p.fy += (t.fy - p.fy) * k;
  p.bx += (t.bx - p.bx) * k;
  p.by += (t.by - p.by) * k;
  p.aFu += (t.aFu - p.aFu) * k;
  p.aFe += (t.aFe - p.aFe) * k;
  p.aBu += (t.aBu - p.aBu) * k;
  p.aBe += (t.aBe - p.aBe) * k;
}

export interface Xform {
  ox: number;
  oy: number;
  facing: number;
  rot: number;
  cx: number;
  cy: number;
  sx: number;
}

export interface WorldPose {
  pelvis: Vec2;
  neck: Vec2;
  head: Vec2;
  shF: Vec2;
  shB: Vec2;
  elF: Vec2;
  haF: Vec2;
  elB: Vec2;
  haB: Vec2;
  knF: Vec2;
  ftF: Vec2;
  knB: Vec2;
  ftB: Vec2;
  toeF: Vec2;
  toeB: Vec2;
  facing: number;
  sx: number;
  swap: boolean;
  gunF: GunKind;
  gunB: GunKind;
  aimF: number;
  aimB: number;
  flashF: number;
  flashB: number;
  slideF: number;
  slideB: number;
  tsx: number;
  part: number;
  hit: number;
  dead: boolean;
  blink: boolean;
  angry: boolean;
}

const v2 = (): Vec2 => ({ x: 0, y: 0 });

export function newWorldPose(): WorldPose {
  return {
    pelvis: v2(),
    neck: v2(),
    head: v2(),
    shF: v2(),
    shB: v2(),
    elF: v2(),
    haF: v2(),
    elB: v2(),
    haB: v2(),
    knF: v2(),
    ftF: v2(),
    knB: v2(),
    ftB: v2(),
    toeF: v2(),
    toeB: v2(),
    facing: 1,
    sx: 1,
    swap: false,
    gunF: null,
    gunB: null,
    aimF: 0,
    aimB: 0,
    flashF: 0,
    flashB: 0,
    slideF: 0,
    slideB: 0,
    tsx: 1,
    part: 0,
    hit: 0,
    dead: false,
    blink: false,
    angry: false,
  };
}

function xfPoint(xf: Xform, lx: number, ly: number, out: Vec2) {
  const rx = lx - xf.cx;
  const ry = ly - xf.cy;
  const c = Math.cos(xf.rot);
  const s = Math.sin(xf.rot);
  const x = (xf.cx + rx * c - ry * s) * xf.sx;
  const y = xf.cy + rx * s + ry * c;
  out.x = xf.ox + x * xf.facing;
  out.y = xf.oy + y;
}

function toeFrom(knee: Vec2, foot: Vec2, facing: number, len: number, out: Vec2) {
  let dx = foot.x - knee.x;
  let dy = foot.y - knee.y;
  const l = Math.hypot(dx, dy) || 1;
  dx /= l;
  dy /= l;
  if (facing > 0) {
    out.x = foot.x + dy * len;
    out.y = foot.y - dx * len;
  } else {
    out.x = foot.x - dy * len;
    out.y = foot.y + dx * len;
  }
}

const L = { x: 0, y: 0 };

/** local-space toe point: flat on the ground, follows the shin when lifted */
function localToe(kx: number, ky: number, fx: number, fy: number, len: number, out: Vec2) {
  let sx = fx - kx;
  let sy = fy - ky;
  const l = Math.hypot(sx, sy) || 1;
  sx /= l;
  sy /= l;
  const px = sy;
  const py = -sx;
  const k = Math.min(1, Math.max(0, (-fy - 4) / 12));
  let dx = 1 + (px - 1) * k;
  let dy = py * k;
  const dl = Math.hypot(dx, dy) || 1;
  dx /= dl;
  dy /= dl;
  out.x = fx + dx * len;
  out.y = fy + dy * len;
}

/** Builds world-space skeleton from a local pose. Arms use local FK (overridable by aimArm). */
export function buildBody(pose: Pose, d: Dims, xf: Xform, out: WorldPose) {
  const px = pose.px;
  const py = pose.py;
  const tdx = Math.sin(pose.torso);
  const tdy = -Math.cos(pose.torso);
  const nx = px + tdx * d.torso;
  const ny = py + tdy * d.torso;
  const ha = pose.torso + pose.head;
  const hx = nx + Math.sin(ha) * (d.neck + d.headR);
  const hy = ny - Math.cos(ha) * (d.neck + d.headR);
  const sx = nx - tdx * 3.5;
  const sy = ny - tdy * 3.5;

  const lf = ik2(px, py, pose.fx, pose.fy, d.thigh, d.shin, -1);
  const lb = ik2(px, py, pose.bx, pose.by, d.thigh, d.shin, -1);

  xfPoint(xf, px, py, out.pelvis);
  xfPoint(xf, nx, ny, out.neck);
  xfPoint(xf, hx, hy, out.head);
  xfPoint(xf, sx, sy, out.shF);
  // far shoulder sits slightly behind & above so both guns read in akimbo
  xfPoint(xf, sx + tdy * 2.2 + tdx * 2.6, sy - tdx * 2.2 + tdy * 2.6, out.shB);
  xfPoint(xf, lf.jx, lf.jy, out.knF);
  xfPoint(xf, lf.ex, lf.ey, out.ftF);
  xfPoint(xf, lb.jx, lb.jy, out.knB);
  xfPoint(xf, lb.ex, lb.ey, out.ftB);

  // arms local FK
  const efx = sx + Math.sin(pose.aFu) * d.upper;
  const efy = sy + Math.cos(pose.aFu) * d.upper;
  xfPoint(xf, efx, efy, out.elF);
  L.x = efx + Math.sin(pose.aFu + pose.aFe) * d.fore;
  L.y = efy + Math.cos(pose.aFu + pose.aFe) * d.fore;
  xfPoint(xf, L.x, L.y, out.haF);
  const ebx = sx + Math.sin(pose.aBu) * d.upper;
  const eby = sy + Math.cos(pose.aBu) * d.upper;
  xfPoint(xf, ebx, eby, out.elB);
  L.x = ebx + Math.sin(pose.aBu + pose.aBe) * d.fore;
  L.y = eby + Math.cos(pose.aBu + pose.aBe) * d.fore;
  xfPoint(xf, L.x, L.y, out.haB);

  const effFacing = xf.facing * (xf.sx < 0 ? -1 : 1);
  out.facing = effFacing;
  out.sx = Math.abs(xf.sx);
  out.swap = xf.sx < 0;
  localToe(lf.jx, lf.jy, lf.ex, lf.ey, d.foot, L);
  xfPoint(xf, L.x, L.y, out.toeF);
  localToe(lb.jx, lb.jy, lb.ex, lb.ey, d.foot, L);
  xfPoint(xf, L.x, L.y, out.toeB);
}

/** Straight-ish aiming arm in world space; blends with existing (FK) elbow/hand by w */
export function aimArm(
  sh: Vec2,
  angle: number,
  d: Dims,
  recoil: number,
  w: number,
  el: Vec2,
  ha: Vec2,
  reachMul = 1,
) {
  const bd = Math.cos(angle) >= 0 ? 1 : -1;
  const reach = (1 - recoil * 0.22) * reachMul;
  const ua = angle + 0.2 * bd + recoil * 0.25 * -bd;
  const ex = sh.x + Math.cos(ua) * d.upper * reach;
  const ey = sh.y + Math.sin(ua) * d.upper * reach;
  const fa = angle - 0.12 * bd - recoil * 0.55 * bd;
  const hx = ex + Math.cos(fa) * d.fore;
  const hy = ey + Math.sin(fa) * d.fore;
  if (w >= 0.999) {
    el.x = ex;
    el.y = ey;
    ha.x = hx;
    ha.y = hy;
  } else {
    el.x += (ex - el.x) * w;
    el.y += (ey - el.y) * w;
    ha.x += (hx - ha.x) * w;
    ha.y += (hy - ha.y) * w;
  }
}

/** world-space IK arm reaching to a target point */
export function reachArm(sh: Vec2, tx: number, ty: number, d: Dims, bend: number, el: Vec2, ha: Vec2) {
  const r = ik2(sh.x, sh.y, tx, ty, d.upper, d.fore, bend);
  el.x = r.jx;
  el.y = r.jy;
  ha.x = r.ex;
  ha.y = r.ey;
}

export function muzzleLen(kind: GunKind) {
  if (kind === 'uzi') return 17;
  if (kind === 'shotgun') return 31;
  if (kind === 'tommy') return 30;
  if (kind === 'ak47') return 37;
  if (kind === 'sniper') return 55;
  if (kind === 'cricket') return 13;
  if (kind === 'sling') return 6;
  return 15;
}

// ------------------------------------------------------------------ drawing
const OUT = 1.6;

function line(ctx: CanvasRenderingContext2D, ax: number, ay: number, bx: number, by: number, w: number, col: string) {
  ctx.lineWidth = w;
  ctx.strokeStyle = col;
  ctx.beginPath();
  ctx.moveTo(ax, ay);
  ctx.lineTo(bx, by);
  ctx.stroke();
}

function seg(
  ctx: CanvasRenderingContext2D,
  a: Vec2,
  b: Vec2,
  w: number,
  fill: string,
  outline: string,
  t0 = 0,
  t1 = 1,
) {
  const ax = a.x + (b.x - a.x) * t0;
  const ay = a.y + (b.y - a.y) * t0;
  const bx = a.x + (b.x - a.x) * t1;
  const by = a.y + (b.y - a.y) * t1;
  line(ctx, ax, ay, bx, by, w + OUT * 2, outline);
  line(ctx, ax, ay, bx, by, w, fill);
}

function circle(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, fill: string, outline: string) {
  ctx.beginPath();
  ctx.arc(x, y, r + OUT, 0, Math.PI * 2);
  ctx.fillStyle = outline;
  ctx.fill();
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = fill;
  ctx.fill();
}

export function drawGun(
  ctx: CanvasRenderingContext2D,
  kind: GunKind,
  x: number,
  y: number,
  angle: number,
  flash: number,
  outline = '#141414',
  slide = 0,
) {
  if (!kind) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  if (Math.cos(angle) < 0) ctx.scale(1, -1);
  ctx.lineJoin = 'round';
  ctx.lineWidth = 1.3;
  ctx.strokeStyle = outline;
  if (kind === 'pistol') {
    ctx.fillStyle = '#3a3d42';
    ctx.beginPath();
    ctx.moveTo(-2.2, -0.5);
    ctx.lineTo(2, -0.5);
    ctx.lineTo(0.8, 7);
    ctx.lineTo(-3.4, 6.6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // slide racks back on every shot, exposing the barrel
    const so = -Math.min(1, slide) * 5;
    if (so < -0.3) {
      ctx.fillStyle = '#2a2c30';
      ctx.fillRect(10 + so, -3.7, 4.5 - so, 2.6);
    }
    ctx.fillStyle = '#5b6068';
    ctx.beginPath();
    ctx.rect(-3.5 + so, -4.6, 17.5, 4.4);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#7d838c';
    ctx.fillRect(-2.5 + so, -4.2, 15, 1.2);
  } else if (kind === 'uzi') {
    ctx.fillStyle = '#2c2f33';
    ctx.beginPath();
    ctx.rect(1.5, -0.5, 3.6, 10);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#3d4146';
    ctx.beginPath();
    ctx.rect(-4, -5.5, 16, 6);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#2c2f33';
    ctx.beginPath();
    ctx.rect(12, -4, 5, 2.6);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#6c7178';
    ctx.fillRect(-3, -5, 14, 1.3);
  } else if (kind === 'shotgun') {
    ctx.fillStyle = '#5a3b22';
    ctx.beginPath();
    ctx.moveTo(-6, -3.5);
    ctx.lineTo(-20, -1);
    ctx.lineTo(-20, 5);
    ctx.lineTo(-5, 2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#34373c';
    ctx.beginPath();
    ctx.rect(-6, -4.5, 37, 3.6);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#6b4a2c';
    ctx.beginPath();
    ctx.rect(12, -1.2, 11, 3.6);
    ctx.fill();
    ctx.stroke();
  } else if (kind === 'ak47') {
    // wooden stock
    ctx.fillStyle = '#9c5a2b';
    ctx.beginPath();
    ctx.moveTo(-5, -4);
    ctx.lineTo(-24, -1.5);
    ctx.lineTo(-25, 5);
    ctx.lineTo(-6, 2.4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.fillRect(-22, -1.2, 14, 1.2);
    // pistol grip
    ctx.fillStyle = '#6e3c1c';
    ctx.beginPath();
    ctx.moveTo(-3, 0);
    ctx.lineTo(1.5, 0);
    ctx.lineTo(-0.5, 7.5);
    ctx.lineTo(-4.5, 7);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // curved magazine
    ctx.fillStyle = '#b5561c';
    ctx.beginPath();
    ctx.moveTo(4, 0.5);
    ctx.lineTo(10.5, 0.5);
    ctx.quadraticCurveTo(12, 6, 16, 11);
    ctx.lineTo(10.5, 13);
    ctx.quadraticCurveTo(6.5, 7, 4, 0.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // receiver
    ctx.fillStyle = '#3a3d42';
    ctx.beginPath();
    ctx.rect(-6, -5.2, 21, 6);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#6c7178';
    ctx.fillRect(-5, -4.7, 19, 1.3);
    // wooden handguard + gas tube
    ctx.fillStyle = '#9c5a2b';
    ctx.beginPath();
    ctx.rect(15, -4.6, 11, 5.2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#2c2f33';
    ctx.beginPath();
    ctx.rect(15, -7.2, 13, 2.4);
    ctx.fill();
    ctx.stroke();
    // barrel, front sight, muzzle
    ctx.beginPath();
    ctx.rect(26, -3.4, 10, 2.4);
    ctx.fill();
    ctx.stroke();
    ctx.fillRect(31, -8, 2, 4.5);
    ctx.beginPath();
    ctx.rect(35, -3.9, 2.6, 3.4);
    ctx.fill();
    ctx.stroke();
  } else if (kind === 'sniper') {
    // polymer stock with cheek rest
    ctx.fillStyle = '#3d4a33';
    ctx.beginPath();
    ctx.moveTo(-5, -4.4);
    ctx.lineTo(-17, -6.5);
    ctx.lineTo(-29, -4);
    ctx.lineTo(-29, 4.5);
    ctx.lineTo(-17, 3);
    ctx.lineTo(-5, 2.6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#1b1d20';
    ctx.fillRect(-29.5, -4, 2.6, 8.5);
    // grip
    ctx.fillStyle = '#2f3a28';
    ctx.beginPath();
    ctx.moveTo(-3, 0);
    ctx.lineTo(1.5, 0);
    ctx.lineTo(-1, 7.5);
    ctx.lineTo(-5, 7);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // receiver
    ctx.fillStyle = '#2c2f33';
    ctx.beginPath();
    ctx.rect(-6, -5, 23, 6);
    ctx.fill();
    ctx.stroke();
    // bolt handle
    ctx.fillStyle = '#9aa3ad';
    ctx.beginPath();
    ctx.rect(1 - slide * 7, -2.2, 2, 6.5);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(2 - slide * 7, 5, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // long barrel + muzzle brake
    ctx.fillStyle = '#2c2f33';
    ctx.beginPath();
    ctx.rect(17, -3.6, 33, 2.6);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.rect(49, -4.6, 6, 4.4);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#5a5f66';
    ctx.fillRect(50, -3.6, 1, 2.4);
    ctx.fillRect(52.5, -3.6, 1, 2.4);
    // folded bipod
    ctx.strokeStyle = '#1b1d20';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(25, -1);
    ctx.lineTo(36, 1.5);
    ctx.stroke();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.3;
    // scope
    ctx.fillStyle = '#1e2124';
    ctx.beginPath();
    ctx.rect(0, -11.5, 18, 4.6);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.rect(-3, -12.6, 4, 6.8);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.rect(16, -13, 5, 7.6);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#8fd3ff';
    ctx.fillRect(20, -12, 1.2, 5.6);
    ctx.fillStyle = '#3a3d42';
    ctx.fillRect(4, -7, 2, 2.2);
    ctx.fillRect(12, -7, 2, 2.2);
  } else if (kind === 'fist') {
    ctx.fillStyle = '#f7c9a1';
    ctx.beginPath();
    ctx.roundRect(-4, -7, 15, 13, 4);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    for (let i = 1; i < 4; i++) {
      ctx.moveTo(6, -7 + i * 3.3);
      ctx.lineTo(11, -7 + i * 3.3);
    }
    ctx.stroke();
    ctx.beginPath();
    ctx.roundRect(-3, 0, 9, 4.5, 2);
    ctx.fill();
    ctx.stroke();
  } else if (kind === 'katana') {
    // flat katana sprite (pickups, HUD, drops)
    ctx.fillStyle = '#efe9dc';
    ctx.beginPath();
    ctx.roundRect(-8, -2.4, 18, 4.8, 1.6);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = '#1f1a17';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      ctx.moveTo(-7 + i * 4.2, -2.2);
      ctx.lineTo(-4.5 + i * 4.2, 2.2);
      ctx.moveTo(-7 + i * 4.2, 2.2);
      ctx.lineTo(-4.5 + i * 4.2, -2.2);
    }
    ctx.stroke();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.3;
    ctx.fillStyle = '#c9a14a';
    ctx.beginPath();
    ctx.arc(-8.5, 0, 2.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    const kg = ctx.createLinearGradient(0, -4, 0, 2);
    kg.addColorStop(0, '#8f9aa6');
    kg.addColorStop(0.55, '#ffffff');
    kg.addColorStop(1, '#c3ccd5');
    ctx.fillStyle = kg;
    ctx.beginPath();
    ctx.moveTo(12, -2.1);
    ctx.quadraticCurveTo(38, -3.6, 64, -4.2);
    ctx.quadraticCurveTo(61, -0.6, 54, 0.3);
    ctx.lineTo(12, 2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(14, 0.9);
    ctx.quadraticCurveTo(38, -0.6, 58, -1.4);
    ctx.stroke();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.3;
    ctx.fillStyle = '#2f2618';
    ctx.beginPath();
    ctx.ellipse(11, 0, 1.8, 5.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (kind === 'cricket') {
    // tiny chrome Noisy Cricket
    const g = ctx.createLinearGradient(0, -5, 0, 1);
    g.addColorStop(0, '#f4f7fa');
    g.addColorStop(0.5, '#a9b4bf');
    g.addColorStop(1, '#6d7884');
    ctx.fillStyle = '#5c6670';
    ctx.beginPath();
    ctx.moveTo(-1.6, 0);
    ctx.lineTo(1.6, 0);
    ctx.lineTo(0.6, 4.6);
    ctx.lineTo(-2.4, 4.3);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(-3, -4.4, 11, 4.6, 1.6);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(9.4, -2.1, 3.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#e9eef2';
    ctx.beginPath();
    ctx.moveTo(1, -4.4);
    ctx.lineTo(4, -6.6);
    ctx.lineTo(5.5, -4.4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#4cc9ff';
    ctx.fillRect(3.2, -4, 1.1, 3.8);
    ctx.fillRect(5.6, -4, 1.1, 3.8);
    const ch = Math.min(1, slide);
    const gl = ctx.createRadialGradient(9.4, -2.1, 0, 9.4, -2.1, 4 + ch * 9);
    gl.addColorStop(0, `rgba(230,250,255,${0.55 + ch * 0.45})`);
    gl.addColorStop(1, 'rgba(76,201,255,0)');
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = gl;
    ctx.beginPath();
    ctx.arc(9.4, -2.1, 4 + ch * 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else if (kind === 'sling') {
    // wooden Y-frame slingshot (bands are drawn by the game)
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    const wood = '#8a5a34';
    const path = () => {
      ctx.beginPath();
      ctx.moveTo(0, 8);
      ctx.lineTo(0, -4);
      ctx.moveTo(0, -3);
      ctx.quadraticCurveTo(-3.4, -5, -3, -12);
      ctx.moveTo(0, -3);
      ctx.quadraticCurveTo(4.2, -5, 4.2, -12.5);
    };
    path();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 5.4;
    ctx.stroke();
    path();
    ctx.strokeStyle = wood;
    ctx.lineWidth = 2.8;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.28)';
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(-0.6, 7);
    ctx.lineTo(-0.6, -3);
    ctx.stroke();
    ctx.fillStyle = '#3a2a1a';
    ctx.fillRect(-1.8, 1, 3.6, 4);
    ctx.lineWidth = 1.3;
    ctx.strokeStyle = outline;
  } else if (kind === 'bat') {
    // wooden baseball bat, knob at the hands
    ctx.fillStyle = '#d39a5c';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-4, -1.6);
    ctx.lineTo(16, -1.9);
    ctx.quadraticCurveTo(26, -2.4, 32, -4.3);
    ctx.lineTo(45, -4.6);
    ctx.quadraticCurveTo(49, -4.4, 49, 0);
    ctx.quadraticCurveTo(49, 4.4, 45, 4.6);
    ctx.lineTo(32, 4.3);
    ctx.quadraticCurveTo(26, 2.4, 16, 1.9);
    ctx.lineTo(-4, 1.6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.beginPath();
    ctx.moveTo(18, -1.2);
    ctx.quadraticCurveTo(28, -2, 33, -3.2);
    ctx.lineTo(45, -3.4);
    ctx.lineTo(45, -2.2);
    ctx.lineTo(33, -2);
    ctx.quadraticCurveTo(26, -0.8, 18, -0.4);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = 'rgba(120,60,20,0.35)';
    ctx.fillRect(37, -1, 6, 4);
    // grip tape + knob
    ctx.fillStyle = '#2a2a2e';
    ctx.fillRect(-3, -1.9, 12, 3.8);
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      ctx.moveTo(-2 + i * 3, -1.9);
      ctx.lineTo(0 + i * 3, 1.9);
    }
    ctx.stroke();
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.4;
    ctx.fillStyle = '#c08a4e';
    ctx.beginPath();
    ctx.ellipse(-5, 0, 2.2, 3.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (kind === 'cleaver') {
    ctx.fillStyle = '#5a3a1f';
    ctx.beginPath();
    ctx.roundRect(-5, -2.2, 13, 4.4, 1.5);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#c9ced4';
    ctx.beginPath();
    ctx.moveTo(7, -3.5);
    ctx.lineTo(31, -5.5);
    ctx.lineTo(32, 9.5);
    ctx.lineTo(7, 7.5);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#eef2f5';
    ctx.fillRect(9, 5.2, 22, 2.2);
    ctx.fillStyle = '#8a1414';
    ctx.beginPath();
    ctx.ellipse(21, 2.5, 5, 2.2, 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#3a3f46';
    ctx.beginPath();
    ctx.arc(27, -1.2, 1.8, 0, Math.PI * 2);
    ctx.fill();
  } else if (kind === 'tommy') {
    ctx.fillStyle = '#6b4423';
    ctx.beginPath();
    ctx.moveTo(-6, -4);
    ctx.lineTo(-22, -2);
    ctx.lineTo(-22, 5);
    ctx.lineTo(-6, 2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#34373c';
    ctx.beginPath();
    ctx.rect(-6, -5, 22, 6);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.rect(16, -4, 15, 3);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#5a5f66';
    for (let i = 0; i < 4; i++) ctx.fillRect(18 + i * 3, -4.6, 1.4, 4.2);
    ctx.fillStyle = '#6b4423';
    ctx.beginPath();
    ctx.rect(13, 1, 3.6, 7);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#2a2c30';
    ctx.beginPath();
    ctx.arc(4, 5.5, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#5a5f66';
    ctx.beginPath();
    ctx.arc(4, 5.5, 2.2, 0, Math.PI * 2);
    ctx.fill();
  }
  if (flash > 0) {
    const m = muzzleLen(kind);
    const k = Math.min(1, flash / 0.05);
    const big = kind === 'shotgun' ? 1.7 : kind === 'sniper' ? 2.1 : kind === 'ak47' ? 1.25 : kind === 'uzi' ? 0.85 : 1;
    const s = (0.75 + 0.55 * k) * big * (0.85 + Math.random() * 0.35);
    ctx.translate(m, -2.5);
    ctx.rotate((Math.random() - 0.5) * 0.25);
    ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 22 * s);
    g.addColorStop(0, 'rgba(255,250,215,1)');
    g.addColorStop(0.35, 'rgba(255,195,70,0.6)');
    g.addColorStop(1, 'rgba(255,120,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(4 * s, 0, 22 * s, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fff6c8';
    // long forward tongue
    ctx.beginPath();
    ctx.moveTo(0, -3.4 * s);
    ctx.lineTo((17 + Math.random() * 7) * s, 0);
    ctx.lineTo(0, 3.4 * s);
    ctx.lineTo(4 * s, 0);
    ctx.closePath();
    ctx.fill();
    // side spikes
    ctx.beginPath();
    ctx.moveTo(1, 0);
    ctx.lineTo(6 * s, -(7 + Math.random() * 4) * s);
    ctx.lineTo(4.5 * s, 0);
    ctx.lineTo(6 * s, (7 + Math.random() * 4) * s);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(3 * s, 0);
    ctx.lineTo(11 * s, -4.5 * s);
    ctx.lineTo(9 * s, 0);
    ctx.lineTo(11 * s, 4.5 * s);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(1.5 * s, 0, 3.2 * s, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();
}

function drawShoe(ctx: CanvasRenderingContext2D, ft: Vec2, toe: Vec2, kn: Vec2, look: Look, back: boolean) {
  const dx = toe.x - ft.x;
  const dy = toe.y - ft.y;
  const l = Math.hypot(dx, dy) || 1;
  const ux = dx / l;
  const uy = dy / l;
  // downward (sole side) = along shin direction
  let sx = ft.x - kn.x;
  let sy = ft.y - kn.y;
  const sl = Math.hypot(sx, sy) || 1;
  sx /= sl;
  sy /= sl;
  const hx = ft.x - ux * 3.2 + sx * 1.2;
  const hy = ft.y - uy * 3.2 + sy * 1.2;
  const tx = toe.x + sx * 1.6;
  const ty = toe.y + sy * 1.6;
  const col = back ? look.shoeShade : look.shoe;
  line(ctx, hx, hy, tx, ty, 6.6 + OUT * 2, look.outline);
  line(ctx, hx, hy, tx, ty, 6.6, col);
  line(ctx, hx + sx * 2.6, hy + sy * 2.6, tx + sx * 2.4, ty + sy * 2.4, 2.2, look.sole);
  if (look.kid) {
    // laces
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(ft.x + ux * 3 - sx * 1.5, ft.y + uy * 3 - sy * 1.5, 1.1, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawLeg(
  ctx: CanvasRenderingContext2D,
  wp: WorldPose,
  front: boolean,
  look: Look,
  d: Dims,
  part: 'all' | 'thigh' | 'lower' = 'all',
) {
  const kn = front ? wp.knF : wp.knB;
  const ft = front ? wp.ftF : wp.ftB;
  const toe = front ? wp.toeF : wp.toeB;
  const back = !front;
  const p = wp.pelvis;
  const doThigh = part !== 'lower';
  const doLower = part !== 'thigh';
  if (look.kid) {
    const skin = back ? look.skinShade : look.skin;
    if (doThigh) {
      seg(ctx, p, kn, d.wThigh - 1, skin, look.outline);
      seg(ctx, p, kn, d.wThigh + 3, back ? look.pantsShade : look.pants, look.outline, 0, 0.62);
    }
    if (doLower) {
      seg(ctx, kn, ft, d.wShin, skin, look.outline);
      seg(ctx, kn, ft, d.wShin + 0.8, back ? '#dcdcd4' : '#fbfbf6', look.outline, 0.84, 1);
      drawShoe(ctx, ft, toe, kn, look, back);
      // knee cap blend over thigh end
      ctx.fillStyle = skin;
      ctx.beginPath();
      ctx.arc(kn.x, kn.y, d.wShin * 0.5, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    const col = back ? look.pantsShade : look.pants;
    if (doThigh) seg(ctx, p, kn, d.wThigh, col, look.outline);
    if (doLower) {
      seg(ctx, kn, ft, d.wShin, col, look.outline);
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.arc(kn.x, kn.y, d.wShin * 0.55, 0, Math.PI * 2);
      ctx.fill();
      drawShoe(ctx, ft, toe, kn, look, back);
    }
  }
}

function drawArm(ctx: CanvasRenderingContext2D, wp: WorldPose, front: boolean, look: Look, d: Dims) {
  const sh = front ? wp.shF : wp.shB;
  const el = front ? wp.elF : wp.elB;
  const ha = front ? wp.haF : wp.haB;
  const gun = front ? wp.gunF : wp.gunB;
  const aim = front ? wp.aimF : wp.aimB;
  const flash = front ? wp.flashF : wp.flashB;
  const back = !front;
  const skin = back ? look.skinShade : look.skin;
  if (look.kid || look.tankTop) {
    seg(ctx, sh, el, d.wUpper, skin, look.outline);
    seg(ctx, el, ha, d.wFore, skin, look.outline);
    if (look.kid) seg(ctx, sh, el, d.wUpper + 4, back ? look.shirtShade : look.shirt, look.outline, 0, 0.55);
    else seg(ctx, sh, el, d.wUpper + 3, (back ? look.jacketShade : look.jacket) || '#ddd', look.outline, 0, 0.22);
  } else {
    const jc = (back ? look.jacketShade : look.jacket) || '#222';
    seg(ctx, sh, el, d.wUpper, jc, look.outline);
    seg(ctx, el, ha, d.wFore, jc, look.outline, 0, 0.8);
    seg(ctx, el, ha, d.wFore + 0.5, back ? '#cfcfca' : '#f4f4f0', look.outline, 0.74, 0.86);
    ctx.fillStyle = jc;
    ctx.beginPath();
    ctx.arc(el.x, el.y, d.wFore * 0.5, 0, Math.PI * 2);
    ctx.fill();
  }
  if (gun) drawGun(ctx, gun, ha.x, ha.y, aim, flash, look.outline, front ? wp.slideF : wp.slideB);
  circle(ctx, ha.x, ha.y, look.boss ? 4.4 : 3.5, skin, look.outline);
}

function drawTorso(ctx: CanvasRenderingContext2D, wp: WorldPose, look: Look, d: Dims, cut = 0) {
  const a = wp.pelvis;
  const b = wp.neck;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  const th = Math.atan2(dx / len, -dy / len);
  ctx.save();
  ctx.translate(a.x, a.y);
  ctx.rotate(th);
  ctx.scale(wp.facing * Math.max(0.45, wp.sx * wp.tsx), 1);
  const wt = d.torsoTop / 2;
  const wb = d.torsoBot / 2;
  const bottom = cut === 1 ? 0 : look.kid ? 4 : 8;
  const main = look.kid ? look.shirt : look.jacket || '#222';
  const shade = look.kid ? look.shirtShade : look.jacketShade;
  ctx.lineJoin = 'round';
  // body path
  const path = () => {
    ctx.beginPath();
    ctx.moveTo(-wb - 0.5, bottom);
    ctx.lineTo(wb + (look.kid ? 0.5 : 1.5), bottom);
    if (cut === 2) {
      // severed at the top: a flat cut instead of shoulders
      ctx.quadraticCurveTo(wt + 2.2, -len * 0.45, wt, -len);
      ctx.lineTo(-wt - 0.5, -len);
    } else {
      ctx.quadraticCurveTo(wt + 2.2, -len * 0.45, wt, -len + 3);
      ctx.quadraticCurveTo(wt - 1, -len - 3.5, 0, -len - 3);
      ctx.quadraticCurveTo(-wt - 1, -len - 2.5, -wt - 0.5, -len + 4);
    }
    ctx.quadraticCurveTo(-wb - 2, -len * 0.4, -wb - 0.5, bottom);
    ctx.closePath();
  };
  if (look.kid) {
    // shorts waist band under shirt
    ctx.fillStyle = look.pants;
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = OUT * 2;
    ctx.beginPath();
    ctx.rect(-wb - 1, -3, wb * 2 + 2, 9);
    ctx.stroke();
    ctx.fill();
  }
  path();
  ctx.lineWidth = OUT * 2;
  ctx.strokeStyle = look.outline;
  ctx.stroke();
  ctx.fillStyle = main;
  ctx.fill();
  // back shade
  ctx.save();
  path();
  ctx.clip();
  ctx.fillStyle = shade;
  ctx.fillRect(-wt - 6, -len - 6, wt * 0.75 + 6, len + 16);
  if (look.kid) {
    // stripe on shirt
    ctx.fillStyle = 'rgba(255,255,255,0.22)';
    ctx.fillRect(-wt - 4, -len * 0.62, wt * 2 + 8, 3);
    ctx.fillStyle = '#e8541f';
    ctx.fillRect(-wt - 4, -len * 0.55, wt * 2 + 8, 2.5);
    // hem
    ctx.fillStyle = shade;
    ctx.fillRect(-wb - 4, bottom - 3, wb * 2 + 8, 3);
  } else {
    if (!look.noTie) {
    // shirt V + tie on front edge
    ctx.fillStyle = look.shirt;
    ctx.beginPath();
    ctx.moveTo(wt - 7.5, -len - 4);
    ctx.lineTo(wt + 3, -len - 4);
    ctx.lineTo(wt + 3, -len * 0.42);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = look.tie;
    ctx.beginPath();
    ctx.moveTo(wt - 1.8, -len + 1);
    ctx.lineTo(wt + 0.6, -len + 1);
    ctx.lineTo(wt + 1.8, -len * 0.38);
    ctx.lineTo(wt - 0.6, -len * 0.32);
    ctx.closePath();
    ctx.fill();
    // lapel
    ctx.strokeStyle = 'rgba(0,0,0,0.45)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(wt - 8, -len - 2);
    ctx.lineTo(wt - 0.5, -len * 0.4);
    ctx.stroke();
    // buttons
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.beginPath();
    ctx.arc(wt - 1.5, -len * 0.28, 1, 0, Math.PI * 2);
    ctx.arc(wt - 1.2, -len * 0.12, 1, 0, Math.PI * 2);
    ctx.fill();
    }
    if (look.apron) {
      ctx.fillStyle = '#f3efe4';
      ctx.beginPath();
      ctx.moveTo(-wb * 0.1, bottom + 2);
      ctx.lineTo(wb + 4, bottom + 2);
      ctx.lineTo(wt + 4, -len * 0.72);
      ctx.lineTo(wt * 0.25, -len * 0.72);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.35)';
      ctx.lineWidth = 1.2;
      ctx.stroke();
      ctx.strokeStyle = '#d8d2c4';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(wt * 0.3, -len * 0.72);
      ctx.lineTo(wt * 0.05, -len - 2);
      ctx.stroke();
      ctx.fillStyle = '#a3111b';
      ctx.beginPath();
      ctx.ellipse(wt * 0.6, -len * 0.4, 3.2, 4.4, 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(wt * 0.2, -len * 0.15, 2.4, 1.8, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(wb * 0.75, -2, 2, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(163,17,27,0.6)';
      ctx.fillRect(wt * 0.45, -len * 0.38, 1.6, 9);
    }
    // pocket square for boss
    if (look.boss) {
      ctx.fillStyle = '#d62828';
      ctx.fillRect(-2, -len * 0.7, 5, 2.5);
      ctx.fillStyle = '#e0b84a';
      ctx.fillRect(-wb, -2, wb * 2, 2.2);
    }
  }
  ctx.restore();
  if (cut) {
    // flesh cap where the blade went through
    const cy = cut === 1 ? 0 : -len;
    const rw = (cut === 1 ? wb : wt) + 1;
    ctx.fillStyle = '#6d0a17';
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.ellipse(0, cy, rw, 3.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#c8233a';
    ctx.beginPath();
    ctx.ellipse(0, cy + (cut === 1 ? 0.4 : -0.4), rw - 2, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f2e6d8';
    ctx.strokeStyle = 'rgba(0,0,0,0.45)';
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.roundRect(-rw * 0.45, cy - 1.4, 3.6, 2.8, 1);
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}

function drawHead(ctx: CanvasRenderingContext2D, wp: WorldPose, look: Look, d: Dims) {
  const n = wp.neck;
  const h = wp.head;
  const dx = h.x - n.x;
  const dy = h.y - n.y;
  const len = Math.hypot(dx, dy) || 1;
  // neck
  const nk = { x: n.x + (dx / len) * (d.neck + 2), y: n.y + (dy / len) * (d.neck + 2) };
  seg(ctx, n, nk, look.boss ? 9 : 6.5, look.skinShade, look.outline);
  const th = Math.atan2(dx / len, -dy / len);
  const R = d.headR;
  ctx.save();
  ctx.translate(h.x, h.y);
  ctx.rotate(th);
  ctx.scale(wp.facing * Math.max(0.42, wp.sx), 1);
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // head shape
  const headPath = () => {
    ctx.beginPath();
    ctx.moveTo(-R * 0.95, -R * 0.1);
    ctx.quadraticCurveTo(-R * 1.0, -R * 1.05, 0, -R * 1.06);
    ctx.quadraticCurveTo(R * 0.95, -R * 1.02, R * 0.98, -R * 0.15);
    ctx.lineTo(R * 0.95, R * 0.45);
    ctx.quadraticCurveTo(R * 0.85, R * (look.kid ? 0.95 : 1.05), R * 0.25, R * (look.kid ? 0.98 : 1.06));
    ctx.quadraticCurveTo(-R * 0.6, R * 1.0, -R * 0.9, R * 0.45);
    ctx.closePath();
  };
  headPath();
  ctx.lineWidth = OUT * 2;
  ctx.strokeStyle = look.outline;
  ctx.stroke();
  ctx.fillStyle = look.skin;
  ctx.fill();
  // cheek shading
  ctx.save();
  headPath();
  ctx.clip();
  ctx.fillStyle = look.skinShade;
  ctx.globalAlpha = 0.55;
  ctx.beginPath();
  ctx.ellipse(-R * 0.75, R * 0.3, R * 0.55, R * 0.9, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  if (wp.hit > 0) {
    ctx.fillStyle = `rgba(255,255,255,${Math.min(0.8, wp.hit)})`;
    ctx.fillRect(-R * 2, -R * 2, R * 4, R * 4);
  }
  ctx.restore();

  // nose
  ctx.fillStyle = look.skin;
  ctx.strokeStyle = look.outline;
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  const nl = look.kid ? 0.22 : 0.36;
  ctx.moveTo(R * 0.9, -R * 0.2);
  ctx.quadraticCurveTo(R * (1.12 + nl), R * 0.18, R * (1.0 + nl * 0.6), R * 0.3);
  ctx.lineTo(R * 0.88, R * 0.3);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // ear
  ctx.fillStyle = look.skinShade;
  ctx.beginPath();
  ctx.ellipse(-R * 0.18, R * 0.08, R * 0.2, R * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // eye
  const ex = R * 0.46;
  const ey = -R * 0.12;
  if (wp.dead) {
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(ex - 2.2, ey - 2.2);
    ctx.lineTo(ex + 2.2, ey + 2.2);
    ctx.moveTo(ex + 2.2, ey - 2.2);
    ctx.lineTo(ex - 2.2, ey + 2.2);
    ctx.stroke();
  } else if (wp.blink) {
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(ex - 2.5, ey);
    ctx.lineTo(ex + 2.5, ey);
    ctx.stroke();
  } else {
    ctx.fillStyle = '#fff';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.ellipse(ex, ey, look.kid ? 2.8 : 2.4, look.kid ? 3.3 : 2.6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#111';
    ctx.beginPath();
    ctx.arc(ex + 1, ey + 0.2, look.kid ? 1.5 : 1.3, 0, Math.PI * 2);
    ctx.fill();
  }
  // brow
  ctx.strokeStyle = look.kid ? look.hair : '#1a120c';
  ctx.lineWidth = look.boss ? 2.6 : 1.8;
  ctx.beginPath();
  if (wp.angry || !look.kid) {
    ctx.moveTo(ex - 3.2, ey - 4.6);
    ctx.lineTo(ex + 3, ey - 3.0);
  } else {
    ctx.moveTo(ex - 3, ey - 4.4);
    ctx.quadraticCurveTo(ex, ey - 5.6, ex + 3, ey - 4.6);
  }
  ctx.stroke();

  // mouth
  ctx.strokeStyle = look.outline;
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  if (wp.dead) {
    ctx.moveTo(R * 0.45, R * 0.62);
    ctx.quadraticCurveTo(R * 0.65, R * 0.5, R * 0.85, R * 0.66);
  } else if (look.kid) {
    ctx.moveTo(R * 0.52, R * 0.58);
    ctx.quadraticCurveTo(R * 0.7, R * (wp.angry ? 0.5 : 0.7), R * 0.86, R * 0.56);
  } else {
    ctx.moveTo(R * 0.5, R * 0.66);
    ctx.lineTo(R * 0.86, R * 0.62);
  }
  ctx.stroke();

  // mustache
  if (look.mustache) {
    ctx.fillStyle = look.mustache === 2 ? '#1a120c' : '#3a2516';
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = 1;
    ctx.beginPath();
    if (look.mustache === 2) {
      ctx.moveTo(R * 0.35, R * 0.42);
      ctx.quadraticCurveTo(R * 0.8, R * 0.25, R * 1.25, R * 0.42);
      ctx.quadraticCurveTo(R * 1.35, R * 0.75, R * 1.0, R * 0.62);
      ctx.quadraticCurveTo(R * 0.7, R * 0.55, R * 0.3, R * 0.75);
      ctx.closePath();
    } else {
      ctx.moveTo(R * 0.55, R * 0.42);
      ctx.quadraticCurveTo(R * 0.85, R * 0.32, R * 1.1, R * 0.42);
      ctx.lineTo(R * 1.05, R * 0.52);
      ctx.quadraticCurveTo(R * 0.8, R * 0.47, R * 0.5, R * 0.56);
      ctx.closePath();
    }
    ctx.fill();
    ctx.stroke();
  }

  if (look.beard) {
    ctx.fillStyle = look.hair;
    ctx.globalAlpha = 0.88;
    ctx.beginPath();
    ctx.moveTo(-R * 0.55, R * 0.1);
    ctx.quadraticCurveTo(-R * 0.4, R * 1.15, R * 0.35, R * 1.14);
    ctx.quadraticCurveTo(R * 0.95, R * 1.05, R * 1.0, R * 0.55);
    ctx.lineTo(R * 0.86, R * 0.48);
    ctx.quadraticCurveTo(R * 0.7, R * 0.85, R * 0.4, R * 0.78);
    ctx.quadraticCurveTo(-R * 0.1, R * 0.75, -R * 0.3, R * 0.05);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  // hair
  ctx.fillStyle = look.hair;
  ctx.strokeStyle = look.outline;
  ctx.lineWidth = OUT * 1.6;
  if (look.kid) {
    ctx.beginPath();
    ctx.moveTo(R * 0.85, -R * 0.42);
    ctx.lineTo(R * 0.55, -R * 0.62);
    ctx.lineTo(R * 0.62, -R * 0.38);
    ctx.lineTo(R * 0.25, -R * 0.6);
    ctx.lineTo(R * 0.1, -R * 0.42);
    ctx.quadraticCurveTo(-R * 0.4, -R * 0.35, -R * 0.55, R * 0.42);
    ctx.lineTo(-R * 1.02, R * 0.25);
    ctx.quadraticCurveTo(-R * 1.25, -R * 0.9, -R * 0.2, -R * 1.2);
    ctx.quadraticCurveTo(R * 0.7, -R * 1.35, R * 1.05, -R * 0.75);
    ctx.quadraticCurveTo(R * 1.1, -R * 0.55, R * 0.85, -R * 0.42);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(-R * 0.6, -R * 0.9);
    ctx.quadraticCurveTo(-R * 0.1, -R * 1.1, R * 0.4, -R * 1.0);
    ctx.stroke();
  } else if (look.bald) {
    ctx.beginPath();
    ctx.moveTo(-R * 0.25, -R * 0.15);
    ctx.quadraticCurveTo(-R * 1.05, -R * 0.2, -R * 0.95, R * 0.35);
    ctx.lineTo(-R * 0.6, R * 0.3);
    ctx.quadraticCurveTo(-R * 0.7, 0, -R * 0.25, -R * 0.15);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.beginPath();
    ctx.ellipse(-R * 0.15, -R * 0.75, R * 0.35, R * 0.13, -0.3, 0, Math.PI * 2);
    ctx.fill();
  } else if (!look.hat) {
    ctx.beginPath();
    ctx.moveTo(R * 0.8, -R * 0.6);
    ctx.quadraticCurveTo(R * 0.4, -R * 1.25, -R * 0.4, -R * 1.12);
    ctx.quadraticCurveTo(-R * 1.15, -R * 0.85, -R * 0.98, R * 0.15);
    ctx.lineTo(-R * 0.55, R * 0.2);
    ctx.quadraticCurveTo(-R * 0.55, -R * 0.55, R * 0.1, -R * 0.66);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-R * 0.7, -R * 0.75);
    ctx.quadraticCurveTo(-R * 0.1, -R * 1.05, R * 0.5, -R * 0.85);
    ctx.stroke();
  } else {
    // short hair under the hat (back)
    ctx.beginPath();
    ctx.moveTo(-R * 0.2, -R * 0.6);
    ctx.quadraticCurveTo(-R * 1.1, -R * 0.6, -R * 0.98, R * 0.2);
    ctx.lineTo(-R * 0.6, R * 0.2);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // glasses
  if (look.glasses && !wp.dead) {
    ctx.fillStyle = '#0d0d0d';
    ctx.beginPath();
    ctx.moveTo(R * 0.15, -R * 0.35);
    ctx.lineTo(R * 0.95, -R * 0.35);
    ctx.lineTo(R * 0.88, R * 0.08);
    ctx.quadraticCurveTo(R * 0.5, R * 0.18, R * 0.2, R * 0.05);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#0d0d0d';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(R * 0.15, -R * 0.3);
    ctx.lineTo(-R * 0.15, -R * 0.15);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.fillRect(R * 0.35, -R * 0.3, R * 0.15, R * 0.2);
  }

  // hat
  if (look.hat) {
    ctx.fillStyle = look.hatColor;
    ctx.strokeStyle = look.outline;
    ctx.lineWidth = OUT * 1.6;
    ctx.beginPath();
    ctx.moveTo(-R * 0.85, -R * 0.62);
    ctx.lineTo(-R * 0.72, -R * 1.42);
    ctx.quadraticCurveTo(-R * 0.1, -R * 1.62, R * 0.15, -R * 1.38);
    ctx.quadraticCurveTo(R * 0.4, -R * 1.62, R * 0.75, -R * 1.45);
    ctx.lineTo(R * 0.9, -R * 0.62);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = look.hatBand;
    ctx.fillRect(-R * 0.82, -R * 0.92, R * 1.7, R * 0.26);
    // brim
    ctx.fillStyle = look.hatColor;
    ctx.beginPath();
    ctx.moveTo(-R * 1.35, -R * 0.55);
    ctx.quadraticCurveTo(0, -R * 0.82, R * 1.5, -R * 0.7);
    ctx.quadraticCurveTo(R * 1.55, -R * 0.5, R * 1.3, -R * 0.48);
    ctx.quadraticCurveTo(0, -R * 0.5, -R * 1.3, -R * 0.38);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}

export function drawCharacter(ctx: CanvasRenderingContext2D, wp: WorldPose, look: Look, d: Dims) {
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const fF = !wp.swap;
  const part = wp.part || 0;
  // far side first (part 1 = severed upper half, 2 = severed lower half)
  if (part !== 2) drawArm(ctx, wp, !fF, look, d);
  if (part !== 1) {
    drawLeg(ctx, wp, !fF, look, d);
    drawLeg(ctx, wp, fF, look, d, 'thigh');
  }
  drawTorso(ctx, wp, look, d, part);
  if (part !== 1) drawLeg(ctx, wp, fF, look, d, 'lower');
  if (part !== 2) {
    drawHead(ctx, wp, look, d);
    drawArm(ctx, wp, fF, look, d);
  }
}

/** a loose fedora (knocked off by headshots) */
export function drawHatShape(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rot: number,
  R: number,
  color: string,
  band: string,
  outline = '#1b1410',
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.translate(0, R * 0.95);
  ctx.lineJoin = 'round';
  ctx.fillStyle = color;
  ctx.strokeStyle = outline;
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  ctx.moveTo(-R * 0.85, -R * 0.62);
  ctx.lineTo(-R * 0.72, -R * 1.42);
  ctx.quadraticCurveTo(-R * 0.1, -R * 1.62, R * 0.15, -R * 1.38);
  ctx.quadraticCurveTo(R * 0.4, -R * 1.62, R * 0.75, -R * 1.45);
  ctx.lineTo(R * 0.9, -R * 0.62);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = band;
  ctx.fillRect(-R * 0.82, -R * 0.92, R * 1.7, R * 0.26);
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(-R * 1.35, -R * 0.55);
  ctx.quadraticCurveTo(0, -R * 0.82, R * 1.5, -R * 0.7);
  ctx.quadraticCurveTo(R * 1.55, -R * 0.5, R * 1.3, -R * 0.48);
  ctx.quadraticCurveTo(0, -R * 0.5, -R * 1.3, -R * 0.38);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

/** a fist (used to keep the near hand on top of a bat drawn in front of the body) */
export function drawFist(ctx: CanvasRenderingContext2D, x: number, y: number, look: Look) {
  circle(ctx, x, y, look.boss ? 4.4 : 3.5, look.skin, look.outline);
}

export interface Bat3 {
  gx: number;
  gy: number;
  dx: number;
  dy: number;
  dz: number;
  L: number;
}

/** a baseball bat as a projected 3D cylinder: foreshortens and shows its end cap toward the camera */
export function drawBat3D(ctx: CanvasRenderingContext2D, b: Bat3, outline = '#1b1410') {
  const pl = Math.hypot(b.dx, b.dy);
  let ux = 0;
  let uy = -1;
  if (pl > 0.015) {
    ux = b.dx / pl;
    uy = b.dy / pl;
  }
  const nx = -uy;
  const ny = ux;
  const near = Math.max(0, b.dz);
  const persp = 1 + 0.32 * near;
  const total = b.L + 6;
  const kx = b.gx - b.dx * 6;
  const ky = b.gy - b.dy * 6;
  const tx = b.gx + b.dx * b.L;
  const ty = b.gy + b.dy * b.L;
  const prof: [number, number][] = [
    [0, 2.0],
    [0.3, 1.9],
    [0.5, 2.7],
    [0.68, 4.0],
    [0.97, 4.5],
  ];
  const rAt = (f: number, r: number) => r * (1 + (persp - 1) * f);
  const L: [number, number][] = [];
  const R: [number, number][] = [];
  for (const [f, r] of prof) {
    const d = f * total;
    const px = kx + b.dx * d;
    const py = ky + b.dy * d;
    const rr = rAt(f, r);
    L.push([px + nx * rr, py + ny * rr]);
    R.push([px - nx * rr, py - ny * rr]);
  }
  const rTip = rAt(1, 4.5);
  const r0 = 2.0;
  const a0 = Math.atan2(ny, nx);
  ctx.save();
  ctx.lineJoin = 'round';
  const body = () => {
    ctx.beginPath();
    ctx.moveTo(L[0][0], L[0][1]);
    for (let i = 1; i < L.length; i++) ctx.lineTo(L[i][0], L[i][1]);
    ctx.arc(tx, ty, rTip, a0, a0 - Math.PI, true);
    for (let i = R.length - 1; i >= 0; i--) ctx.lineTo(R[i][0], R[i][1]);
    ctx.arc(kx, ky, r0, a0 + Math.PI, a0, true);
    ctx.closePath();
  };
  body();
  ctx.lineWidth = 3.2;
  ctx.strokeStyle = outline;
  ctx.stroke();
  ctx.fillStyle = '#d39a5c';
  ctx.fill();
  ctx.save();
  body();
  ctx.clip();
  // shading: dark underside, bright highlight on top
  ctx.fillStyle = 'rgba(110,60,20,0.32)';
  ctx.beginPath();
  for (let i = 0; i < R.length; i++) {
    const [f] = prof[i];
    const d = f * total;
    const px = kx + b.dx * d;
    const py = ky + b.dy * d;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.lineTo(tx, ty);
  for (let i = R.length - 1; i >= 0; i--) ctx.lineTo(R[i][0] - nx * 3, R[i][1] - ny * 3);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,236,200,0.75)';
  ctx.lineWidth = 1.6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  for (let i = 2; i < prof.length; i++) {
    const [f, r] = prof[i];
    const d = f * total;
    const rr = rAt(f, r) * 0.45;
    const px = kx + b.dx * d + nx * rr;
    const py = ky + b.dy * d + ny * rr;
    if (i === 2) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
  // grip tape
  ctx.fillStyle = '#26262b';
  ctx.beginPath();
  ctx.moveTo(L[0][0], L[0][1]);
  ctx.lineTo(L[1][0], L[1][1]);
  ctx.lineTo(R[1][0], R[1][1]);
  ctx.lineTo(R[0][0], R[0][1]);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  // knob
  ctx.fillStyle = '#c08a4e';
  ctx.strokeStyle = outline;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.ellipse(kx, ky, 2.9, 2.9 * Math.max(0.35, Math.abs(b.dz) + pl * 0.4), Math.atan2(uy, ux), 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  // end grain cap when the barrel points at the camera
  if (b.dz > 0.25) {
    const k = Math.min(1, (b.dz - 0.25) / 0.5);
    ctx.globalAlpha = k;
    ctx.fillStyle = '#efc88f';
    ctx.beginPath();
    ctx.ellipse(tx, ty, rTip * Math.abs(b.dz), rTip, Math.atan2(uy, ux), 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = 'rgba(150,95,45,0.7)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(tx, ty, rTip * Math.abs(b.dz) * 0.55, rTip * 0.55, Math.atan2(uy, ux), 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

/** flat silhouette used for after-images */
export function drawGhost(ctx: CanvasRenderingContext2D, pts: Float32Array, color: string, alpha: number, d: Dims) {
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineCap = 'round';
  // indices: 0 pelvis,1 neck,2 head,3 sh,4 elF,5 haF,6 elB,7 haB,8 knF,9 ftF,10 knB,11 ftB
  const P = (i: number) => [pts[i * 2], pts[i * 2 + 1]] as const;
  const segs: [number, number, number][] = [
    [0, 1, d.torsoTop],
    [0, 8, d.wThigh],
    [8, 9, d.wShin],
    [0, 10, d.wThigh],
    [10, 11, d.wShin],
    [3, 4, d.wUpper],
    [4, 5, d.wFore],
    [3, 6, d.wUpper],
    [6, 7, d.wFore],
  ];
  for (const [a, b, w] of segs) {
    const [ax, ay] = P(a);
    const [bx, by] = P(b);
    ctx.lineWidth = w;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(bx, by);
    ctx.stroke();
  }
  const [hx, hy] = P(2);
  ctx.beginPath();
  ctx.arc(hx, hy, d.headR + 1, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

export function snapshotPose(wp: WorldPose, out: Float32Array) {
  const list = [wp.pelvis, wp.neck, wp.head, wp.shF, wp.elF, wp.haF, wp.elB, wp.haB, wp.knF, wp.ftF, wp.knB, wp.ftB];
  for (let i = 0; i < list.length; i++) {
    out[i * 2] = list[i].x;
    out[i * 2 + 1] = list[i].y;
  }
}

// ------------------------------------------------------------------ ragdoll
// point indices
export const RP = { head: 0, neck: 1, pelvis: 2, elF: 3, haF: 4, elB: 5, haB: 6, knF: 7, ftF: 8, knB: 9, ftB: 10 };
const RADII = [8, 4, 5, 3.5, 3, 3.5, 3, 4, 3.2, 4, 3.2];

export class Ragdoll {
  p = new Float64Array(22);
  o = new Float64Array(22);
  sticks: number[] = [];
  mins: number[] = [];
  lastDt = 1 / 120;
  asleep = false;
  still = 0;
  age = 0;
  bleed = 0;
  cutBleed = 0;
  part = 0;
  facing: number;
  look: Look;
  dims: Dims;
  isPlayer: boolean;
  section: number;
  wp: WorldPose = newWorldPose();
  private tmpList: AnySolid[] = [];

  constructor(
    src: WorldPose,
    look: Look,
    dims: Dims,
    vx: number,
    vy: number,
    dt: number,
    isPlayer: boolean,
    section: number,
  ) {
    this.look = look;
    this.dims = dims;
    this.facing = src.facing;
    this.isPlayer = isPlayer;
    this.section = section;
    const pts = [src.head, src.neck, src.pelvis, src.elF, src.haF, src.elB, src.haB, src.knF, src.ftF, src.knB, src.ftB];
    for (let i = 0; i < pts.length; i++) {
      this.p[i * 2] = pts[i].x;
      this.p[i * 2 + 1] = pts[i].y;
      this.o[i * 2] = pts[i].x - vx * dt;
      this.o[i * 2 + 1] = pts[i].y - vy * dt;
    }
    this.lastDt = dt;
    const st = (a: number, b: number, len: number) => this.sticks.push(a, b, len);
    const mn = (a: number, b: number, len: number) => this.mins.push(a, b, len);
    st(0, 1, dims.neck + dims.headR);
    st(1, 2, dims.torso);
    st(1, 3, dims.upper + 2);
    st(3, 4, dims.fore);
    st(1, 5, dims.upper + 2);
    st(5, 6, dims.fore);
    st(2, 7, dims.thigh);
    st(7, 8, dims.shin);
    st(2, 9, dims.thigh);
    st(9, 10, dims.shin);
    mn(0, 2, dims.torso + dims.neck + dims.headR * 0.75);
    mn(2, 8, (dims.thigh + dims.shin) * 0.42);
    mn(2, 10, (dims.thigh + dims.shin) * 0.42);
    mn(1, 4, (dims.upper + dims.fore) * 0.4);
    mn(1, 6, (dims.upper + dims.fore) * 0.4);
    mn(0, 4, 8);
    mn(0, 6, 8);
    mn(8, 10, 4);
  }

  wake() {
    this.asleep = false;
    this.still = 0;
  }

  /** turn this ragdoll into one half of a body cut through the waist (1 = upper, 2 = lower) */
  makeHalf(part: 1 | 2) {
    this.part = part;
    const p = this.p;
    const o = this.o;
    const cx = (p[2] + p[4]) / 2;
    const cy = (p[3] + p[5]) / 2;
    const cvx = (p[2] - o[2] + (p[4] - o[4])) / 2;
    const cvy = (p[3] - o[3] + (p[5] - o[5])) / 2;
    const setPt = (i: number) => {
      p[i * 2] = cx;
      p[i * 2 + 1] = cy;
      o[i * 2] = cx - cvx;
      o[i * 2 + 1] = cy - cvy;
    };
    // sticks: 0 head-neck, 1 neck-pelvis, 2/3 front arm, 4/5 back arm, 6/7 front leg, 8/9 back leg
    const s = this.sticks;
    s[1 * 3 + 2] = this.dims.torso * 0.5;
    if (part === 1) {
      setPt(2);
      for (const i of [7, 8, 9, 10]) setPt(i);
      for (const k of [6, 7, 8, 9]) s[k * 3 + 2] = 0;
    } else {
      setPt(1);
      for (const i of [0, 3, 4, 5, 6]) setPt(i);
      for (const k of [0, 2, 3, 4, 5]) s[k * 3 + 2] = 0;
    }
    this.mins.length = 0;
    this.cutBleed = 1.8;
    this.wake();
  }

  impulse(i: number, vx: number, vy: number) {
    this.o[i * 2] -= vx * this.lastDt;
    this.o[i * 2 + 1] -= vy * this.lastDt;
    this.wake();
  }

  impulseAll(vx: number, vy: number) {
    for (let i = 0; i < 11; i++) this.impulse(i, vx, vy);
  }

  center() {
    return { x: this.p[4], y: this.p[5] };
  }

  /** returns point index hit by segment or -1 and param */
  hitTest(x1: number, y1: number, x2: number, y2: number): { i: number; t: number } | null {
    let best: { i: number; t: number } | null = null;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const a = dx * dx + dy * dy;
    if (a < 1e-6) return null;
    for (let i = 0; i < 11; i++) {
      const cx = this.p[i * 2];
      const cy = this.p[i * 2 + 1];
      const r = i === 0 ? 10 : 7;
      const fx = x1 - cx;
      const fy = y1 - cy;
      const b = 2 * (fx * dx + fy * dy);
      const c = fx * fx + fy * fy - r * r;
      const disc = b * b - 4 * a * c;
      if (disc < 0) continue;
      const t = (-b - Math.sqrt(disc)) / (2 * a);
      if (t >= 0 && t <= 1 && (!best || t < best.t)) best = { i, t };
    }
    return best;
  }

  update(dt: number, world: World) {
    this.age += dt;
    if (this.bleed > 0) this.bleed -= dt;
    if (this.cutBleed > 0) this.cutBleed -= dt;
    if (this.asleep || dt <= 0) return;
    const ratio = dt / this.lastDt;
    this.lastDt = dt;
    const p = this.p;
    const o = this.o;
    const g = 2100 * dt * dt;
    let maxMove = 0;
    for (let i = 0; i < 22; i += 2) {
      const vx = (p[i] - o[i]) * ratio * 0.998;
      const vy = (p[i + 1] - o[i + 1]) * ratio * 0.998;
      o[i] = p[i];
      o[i + 1] = p[i + 1];
      p[i] += vx;
      p[i + 1] += vy + g;
      const m = Math.abs(vx) + Math.abs(vy);
      if (m > maxMove) maxMove = m;
    }
    for (let it = 0; it < 6; it++) {
      this.solveSticks();
      if (it === 2 || it === 5) this.collide(world);
    }
    if (maxMove < 0.12) {
      this.still += dt;
      if (this.still > 0.8) this.asleep = true;
    } else this.still = 0;
  }

  private solveSticks() {
    const p = this.p;
    const s = this.sticks;
    for (let k = 0; k < s.length; k += 3) {
      const a = s[k] * 2;
      const b = s[k + 1] * 2;
      const len = s[k + 2];
      const dx = p[b] - p[a];
      const dy = p[b + 1] - p[a + 1];
      const d = Math.hypot(dx, dy) || 0.0001;
      const diff = ((d - len) / d) * 0.5;
      p[a] += dx * diff;
      p[a + 1] += dy * diff;
      p[b] -= dx * diff;
      p[b + 1] -= dy * diff;
    }
    const m = this.mins;
    for (let k = 0; k < m.length; k += 3) {
      const a = m[k] * 2;
      const b = m[k + 1] * 2;
      const len = m[k + 2];
      const dx = p[b] - p[a];
      const dy = p[b + 1] - p[a + 1];
      const d = Math.hypot(dx, dy) || 0.0001;
      if (d >= len) continue;
      const diff = ((d - len) / d) * 0.5 * 0.6;
      p[a] += dx * diff;
      p[a + 1] += dy * diff;
      p[b] -= dx * diff;
      p[b + 1] -= dy * diff;
    }
  }

  private collide(world: World) {
    const p = this.p;
    const o = this.o;
    for (let i = 0; i < 11; i++) {
      const r = RADII[i];
      const ix = i * 2;
      const x = p[ix];
      const y = p[ix + 1];
      const list = this.tmpList;
      list.length = 0;
      const q = world.query(x - r, y - r, r * 2, r * 2);
      for (const s of q) list.push(s as AnySolid);
      for (const d of world.dyn) {
        if (d.x < x + r && d.x + d.w > x - r && d.y < y + r && d.y + d.h > y - r) list.push(d as AnySolid);
      }
      for (const s of list) {
        const px = p[ix];
        const py = p[ix + 1];
        let nx = 0;
        let ny = 0;
        if (s.oneWay) {
          if (o[ix + 1] + r <= s.y + 1.5 && py + r > s.y && px > s.x && px < s.x + s.w) {
            p[ix + 1] = s.y - r;
            ny = -1;
          } else continue;
        } else {
          const ox1 = px + r - s.x;
          const ox2 = s.x + s.w - (px - r);
          const oy1 = py + r - s.y;
          const oy2 = s.y + s.h - (py - r);
          if (ox1 <= 0 || ox2 <= 0 || oy1 <= 0 || oy2 <= 0) continue;
          const mx = Math.min(ox1, ox2);
          const my = Math.min(oy1, oy2);
          if (mx < my) {
            if (ox1 < ox2) {
              p[ix] = s.x - r;
              nx = -1;
            } else {
              p[ix] = s.x + s.w + r;
              nx = 1;
            }
          } else {
            if (oy1 < oy2) {
              p[ix + 1] = s.y - r;
              ny = -1;
            } else {
              p[ix + 1] = s.y + s.h + r;
              ny = 1;
            }
          }
        }
        // velocity response
        let vx = px - o[ix];
        let vy = py - o[ix + 1];
        const vn = vx * nx + vy * ny;
        if (vn < 0) {
          vx -= nx * vn * 1.18;
          vy -= ny * vn * 1.18;
        }
        const vn2 = vx * nx + vy * ny;
        const tx = vx - nx * vn2;
        const ty = vy - ny * vn2;
        vx = nx * vn2 + tx * 0.78;
        vy = ny * vn2 + ty * 0.78;
        o[ix] = p[ix] - vx;
        o[ix + 1] = p[ix + 1] - vy;
      }
    }
  }

  toWorldPose(): WorldPose {
    const wp = this.wp;
    const p = this.p;
    const set = (v: Vec2, i: number) => {
      v.x = p[i * 2];
      v.y = p[i * 2 + 1];
    };
    set(wp.head, 0);
    set(wp.neck, 1);
    set(wp.pelvis, 2);
    set(wp.elF, 3);
    set(wp.haF, 4);
    set(wp.elB, 5);
    set(wp.haB, 6);
    set(wp.knF, 7);
    set(wp.ftF, 8);
    set(wp.knB, 9);
    set(wp.ftB, 10);
    const dx = wp.pelvis.x - wp.neck.x;
    const dy = wp.pelvis.y - wp.neck.y;
    const l = Math.hypot(dx, dy) || 1;
    wp.shF.x = wp.neck.x + (dx / l) * 3.5;
    wp.shF.y = wp.neck.y + (dy / l) * 3.5;
    wp.shB.x = wp.shF.x;
    wp.shB.y = wp.shF.y;
    wp.facing = this.facing;
    wp.sx = 1;
    wp.swap = false;
    wp.gunF = null;
    wp.gunB = null;
    wp.flashF = 0;
    wp.flashB = 0;
    wp.hit = 0;
    wp.dead = true;
    wp.blink = false;
    wp.part = this.part;
    toeFrom(wp.knF, wp.ftF, this.facing, this.dims.foot, wp.toeF);
    toeFrom(wp.knB, wp.ftB, this.facing, this.dims.foot, wp.toeB);
    return wp;
  }
}
