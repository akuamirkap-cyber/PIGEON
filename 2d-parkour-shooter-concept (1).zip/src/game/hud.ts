import { drawBanana } from './props';
import { drawGun } from './character';
import { WEAPON_INFO, WEAPON_ORDER, type WeaponId } from './weapons';
import { clamp, formatNum, TAU } from './math';

export interface StyleTag {
  text: string;
  pts: number;
  t: number;
  big: boolean;
}

export interface HudState {
  hp: number;
  focus: number;
  focusing: boolean;
  weapon: WeaponId;
  inv: { id: WeaponId; ammo: number }[];
  bolt: number;
  heat: number;
  charge: number;
  hits: number;
  hitsT: number;
  scorePulse: number;
  mag: [number, number];
  magSize: number;
  reload: number;
  score: number;
  combo: number;
  comboT: number;
  tags: StyleTag[];
  kills: number;
  totalEnemies: number;
  bananas: number;
  totalBananas: number;
  hintText: string;
  hintChars: number;
  hintAlpha: number;
  titleT: number;
  levelName: string;
  levelSub: string;
  time: number;
  hurt: number;
  centerMsg: string;
  centerT: number;
  boss: { hp: number; max: number; name: string; title: string; marks: number[]; shown: number; phase: number } | null;
  mode: 'story' | 'boss' | 'fist';
  age: number;
  maxHp: number;
  guard: number;
  wave: number;
  waves: number;
  realTime: number;
  splitActive: boolean;
}

const FONT_D = 'Bangers, Impact, "Arial Black", sans-serif';
const FONT_B = 'Rubik, "Segoe UI", Arial, sans-serif';

function outlinedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  size: number,
  fill: string,
  align: CanvasTextAlign = 'left',
  stroke = '#120d0a',
  font = FONT_D,
) {
  ctx.font = `${size}px ${font}`;
  ctx.textAlign = align;
  ctx.textBaseline = 'alphabetic';
  ctx.lineJoin = 'round';
  ctx.lineWidth = Math.max(3, size * 0.16);
  ctx.strokeStyle = stroke;
  ctx.strokeText(text, x, y);
  ctx.fillStyle = fill;
  ctx.fillText(text, x, y);
}

function bar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  v: number,
  c1: string,
  c2: string,
) {
  ctx.fillStyle = '#120d0a';
  ctx.beginPath();
  ctx.roundRect(x - 3, y - 3, w + 6, h + 6, h / 2 + 3);
  ctx.fill();
  ctx.fillStyle = '#3a2e2a';
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, h / 2);
  ctx.fill();
  v = clamp(v, 0, 1);
  if (v > 0.001) {
    const g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, c1);
    g.addColorStop(1, c2);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(x, y, Math.max(h, w * v), h, h / 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.beginPath();
    ctx.roundRect(x + 3, y + 2, Math.max(0, w * v - 6), h * 0.3, h * 0.15);
    ctx.fill();
  }
}

function heart(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, pulse: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s * (1 + pulse * 0.15), s * (1 + pulse * 0.15));
  ctx.beginPath();
  ctx.moveTo(0, 6);
  ctx.bezierCurveTo(-12, -2, -8, -12, 0, -6);
  ctx.bezierCurveTo(8, -12, 12, -2, 0, 6);
  ctx.closePath();
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#120d0a';
  ctx.stroke();
  ctx.fillStyle = '#ff3b4a';
  ctx.fill();
  ctx.restore();
}

function wrap(ctx: CanvasRenderingContext2D, text: string, maxW: number) {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? cur + ' ' + w : w;
    if (ctx.measureText(test).width > maxW && cur) {
      lines.push(cur);
      cur = w;
    } else cur = test;
  }
  if (cur) lines.push(cur);
  return lines;
}

export function drawHud(ctx: CanvasRenderingContext2D, W: number, H: number, s: HudState) {
  const u = clamp(Math.min(W / 1280, H / 760), 0.62, 1.5);
  ctx.save();
  ctx.lineCap = 'round';

  // --------- top-left: health / focus / ammo
  const x0 = 22 * u;
  const y0 = 22 * u;
  const low = s.hp < 35;
  heart(ctx, x0 + 12 * u, y0 + 11 * u, u * 1.25, low ? Math.max(0, Math.sin(s.realTime * 10)) : 0);
  bar(ctx, x0 + 32 * u, y0, 230 * u, 20 * u, s.hp / s.maxHp, low ? '#ff6b6b' : '#ff5a5f', low ? '#a8141f' : '#c81d2a');
  outlinedText(ctx, `${Math.ceil(s.hp)}`, x0 + 40 * u, y0 + 16 * u, 17 * u, '#fff');
  if (s.age > 0) outlinedText(ctx, `UMUR ${s.age}`, x0 + 272 * u, y0 + 18 * u, 22 * u, s.age >= 50 ? '#ff6b6b' : '#e0c3ff', 'left');

  // focus
  const fy = y0 + 32 * u;
  ctx.save();
  ctx.translate(x0 + 12 * u, fy + 7 * u);
  ctx.strokeStyle = '#120d0a';
  ctx.lineWidth = 5 * u;
  ctx.beginPath();
  ctx.arc(0, 0, 8 * u, 0, TAU);
  ctx.stroke();
  ctx.strokeStyle = s.focusing ? '#fff3a0' : '#ffd23f';
  ctx.lineWidth = 2.5 * u;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -5 * u);
  ctx.moveTo(0, 0);
  ctx.lineTo(4 * u, 2 * u);
  ctx.stroke();
  ctx.restore();
  const fpulse = s.focusing ? 0.15 + Math.sin(s.realTime * 12) * 0.1 : 0;
  bar(ctx, x0 + 32 * u, fy, 190 * u, 13 * u, s.focus / 100, s.focusing ? '#fff6b0' : '#ffd23f', s.focusing ? '#ffb000' : '#e08a00');
  if (fpulse > 0) {
    ctx.fillStyle = `rgba(255,240,160,${fpulse})`;
    ctx.beginPath();
    ctx.roundRect(x0 + 29 * u, fy - 3 * u, 196 * u, 19 * u, 9 * u);
    ctx.fill();
  }
  outlinedText(ctx, 'FOKUS', x0 + 230 * u, fy + 12 * u, 14 * u, s.focusing ? '#fff3a0' : '#ffd23f');

  // ammo
  const ay = fy + 26 * u;
  const wi = WEAPON_INFO[s.weapon];
  if (s.weapon === 'shotgun') {
    outlinedText(ctx, 'SHOTGUN', x0, ay + 15 * u, 19 * u, wi.color);
    for (let i = 0; i < s.mag[0]; i++) {
      const bx = x0 + 88 * u + i * 13 * u;
      ctx.fillStyle = '#120d0a';
      ctx.fillRect(bx - 1.5 * u, ay - 1.5 * u, 10 * u, 18 * u);
      ctx.fillStyle = '#d63a2f';
      ctx.fillRect(bx, ay, 7 * u, 11 * u);
      ctx.fillStyle = '#d8a62a';
      ctx.fillRect(bx, ay + 11 * u, 7 * u, 4 * u);
    }
  } else if (s.weapon === 'ak47') {
    outlinedText(ctx, 'AK-47', x0, ay + 15 * u, 19 * u, wi.color);
    for (let i = 0; i < wi.max; i++) {
      const bx = x0 + 62 * u + i * 6 * u;
      const full = i < s.mag[0];
      ctx.fillStyle = '#120d0a';
      ctx.fillRect(bx - 1 * u, ay - 1 * u, 5 * u, 15 * u);
      ctx.fillStyle = full ? '#e8b04a' : '#4a3d33';
      ctx.fillRect(bx, ay, 3 * u, 13 * u);
    }
    if (s.heat > 0.05) bar(ctx, x0 + 62 * u, ay + 19 * u, 178 * u, 5 * u, s.heat, '#ffb347', '#ff5a1f');
  } else if (s.weapon === 'sniper') {
    outlinedText(ctx, 'SNIPER', x0, ay + 15 * u, 19 * u, wi.color);
    for (let i = 0; i < wi.max; i++) {
      const bx = x0 + 74 * u + i * 16 * u;
      const full = i < s.mag[0];
      ctx.fillStyle = '#120d0a';
      ctx.fillRect(bx - 1.5 * u, ay - 3 * u, 9 * u, 21 * u);
      ctx.fillStyle = full ? '#d8a62a' : '#4a3d33';
      ctx.fillRect(bx, ay + 2 * u, 6 * u, 14 * u);
      ctx.fillStyle = full ? '#c0c6cc' : '#3a3330';
      ctx.beginPath();
      ctx.moveTo(bx, ay + 2 * u);
      ctx.lineTo(bx + 3 * u, ay - 2 * u);
      ctx.lineTo(bx + 6 * u, ay + 2 * u);
      ctx.fill();
    }
    if (s.bolt > 0) outlinedText(ctx, 'KOKANG...', x0 + 160 * u, ay + 14 * u, 14 * u, '#ffffff');
  } else if (s.weapon === 'bat') {
    outlinedText(ctx, 'PEMUKUL', x0, ay + 15 * u, 19 * u, wi.color);
    bar(ctx, x0 + 92 * u, ay + 2 * u, 140 * u, 11 * u, s.mag[0] / wi.max, '#f1c98a', '#b8783a');
    if (s.charge > 0) bar(ctx, x0 + 92 * u, ay + 18 * u, 140 * u, 6 * u, s.charge, '#ffe0b0', '#ff7b3a');
  } else if (s.weapon === 'fist') {
    outlinedText(ctx, 'TANGAN KOSONG', x0, ay + 15 * u, 19 * u, wi.color);
    bar(ctx, x0 + 150 * u, ay + 3 * u, 110 * u, 9 * u, s.guard, '#ffd6a0', '#ff7b3a');
    outlinedText(ctx, 'KUDA-KUDA', x0 + 268 * u, ay + 13 * u, 12 * u, '#ffd6a0');
    if (s.charge > 0) bar(ctx, x0 + 150 * u, ay + 17 * u, 110 * u, 6 * u, s.charge, '#ffffff', '#ffd23f');
  } else if (s.weapon === 'katana') {
    outlinedText(ctx, 'KATANA', x0, ay + 15 * u, 19 * u, wi.color);
    outlinedText(ctx, '∞', x0 + 84 * u, ay + 17 * u, 22 * u, '#ffffff');
    if (s.charge > 0) {
      bar(ctx, x0 + 108 * u, ay + 3 * u, 130 * u, 9 * u, s.charge, '#ffffff', '#4cc9ff');
      outlinedText(ctx, s.charge >= 1 ? 'IAI SIAP!' : 'IAI...', x0 + 246 * u, ay + 13 * u, 14 * u, s.charge >= 1 ? '#c7f0ff' : '#ffffff');
    }
  } else if (s.weapon === 'sling') {
    outlinedText(ctx, 'KETAPEL', x0, ay + 15 * u, 19 * u, wi.color);
    const n = Math.min(15, s.mag[0]);
    for (let i = 0; i < n; i++) {
      const bx = x0 + 82 * u + i * 9 * u;
      ctx.fillStyle = '#120d0a';
      ctx.beginPath();
      ctx.arc(bx, ay + 7 * u, 4.4 * u, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = i % 2 ? '#9a948c' : '#b8b2a8';
      ctx.beginPath();
      ctx.arc(bx, ay + 7 * u, 3 * u, 0, Math.PI * 2);
      ctx.fill();
    }
    outlinedText(ctx, `x${s.mag[0]}`, x0 + 82 * u + n * 9 * u + 4 * u, ay + 13 * u, 14 * u, '#ffffff');
    if (s.charge > 0) bar(ctx, x0 + 82 * u, ay + 19 * u, 140 * u, 6 * u, s.charge, '#e8ffb0', '#7ac93a');
  } else if (s.weapon === 'cricket') {
    outlinedText(ctx, 'NOISY CRICKET', x0, ay + 15 * u, 19 * u, wi.color);
    for (let i = 0; i < wi.max; i++) {
      const bx = x0 + 132 * u + i * 22 * u;
      const full = i < s.mag[0];
      ctx.fillStyle = '#120d0a';
      ctx.beginPath();
      ctx.roundRect(bx - 2 * u, ay - 2 * u, 20 * u, 18 * u, 5 * u);
      ctx.fill();
      const g = ctx.createLinearGradient(0, ay, 0, ay + 14 * u);
      g.addColorStop(0, full ? '#dff6ff' : '#3a3d44');
      g.addColorStop(1, full ? '#3fa8ff' : '#26282e');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.roundRect(bx, ay, 16 * u, 14 * u, 4 * u);
      ctx.fill();
    }
    if (s.charge > 0) bar(ctx, x0 + 132 * u, ay + 20 * u, 84 * u, 6 * u, s.charge, '#ffffff', '#4cc9ff');
  } else if (s.weapon === 'uzi') {
    outlinedText(ctx, `UZI GANDA  ${s.mag[0]} | ${s.mag[1]}`, x0, ay + 16 * u, 18 * u, wi.color);
  } else {
    for (let g = 0; g < 2; g++) {
      for (let i = 0; i < s.magSize; i++) {
        const bx = x0 + i * 9 * u + g * (s.magSize * 9 + 14) * u;
        const full = i < s.mag[g];
        ctx.fillStyle = '#120d0a';
        ctx.fillRect(bx - 1.5 * u, ay - 1.5 * u, 7 * u, 15 * u);
        ctx.fillStyle = full ? '#f2c14e' : '#4a3d33';
        ctx.fillRect(bx, ay, 4 * u, 12 * u);
        if (full) {
          ctx.fillStyle = '#b87333';
          ctx.fillRect(bx, ay, 4 * u, 4 * u);
        }
      }
    }
    if (s.reload > 0) {
      bar(ctx, x0, ay + 22 * u, 120 * u, 8 * u, 1 - s.reload, '#ffffff', '#bbbbbb');
      outlinedText(ctx, 'RELOAD', x0 + 130 * u, ay + 31 * u, 14 * u, '#fff');
    }
  }

  // weapon slots (number keys 1-6)
  if (s.inv.length > 1) {
    const sy = ay + 40 * u;
    const bw = 50 * u;
    const bh = 30 * u;
    let sx = x0;
    for (const it of s.inv) {
      const cur = it.id === s.weapon;
      const key = (WEAPON_ORDER.indexOf(it.id) + 1) % 10;
      ctx.fillStyle = cur ? 'rgba(255,210,63,0.95)' : 'rgba(18,13,10,0.78)';
      ctx.strokeStyle = '#120d0a';
      ctx.lineWidth = 3 * u;
      ctx.beginPath();
      ctx.roundRect(sx, sy, bw, bh, 7 * u);
      ctx.fill();
      ctx.stroke();
      ctx.save();
      ctx.beginPath();
      ctx.rect(sx + 2 * u, sy + 2 * u, bw - 4 * u, bh - 4 * u);
      ctx.clip();
      ctx.translate(sx + bw * 0.5, sy + bh * 0.56);
      const sc =
        it.id === 'sniper'
          ? 0.5
          : it.id === 'bat'
            ? 0.62
            : it.id === 'ak47'
              ? 0.62
              : it.id === 'shotgun'
                ? 0.6
                : it.id === 'katana'
                  ? 0.56
                : it.id === 'cricket'
                  ? 1.6
                  : it.id === 'sling'
                    ? 1.15
                    : 0.95;
      ctx.scale(sc * u, sc * u);
      const off =
        it.id === 'sniper'
          ? -12
          : it.id === 'bat'
            ? -22
            : it.id === 'katana'
              ? -27
              : it.id === 'ak47'
                ? -6
                : it.id === 'shotgun'
                  ? -6
                  : it.id === 'cricket'
                    ? -3
                    : it.id === 'sling'
                      ? 0
                      : -5;
      drawGun(ctx, it.id, off, it.id === 'sling' ? 2 : 0, it.id === 'bat' ? -0.25 : it.id === 'katana' ? -0.32 : 0, 0);
      ctx.restore();
      outlinedText(ctx, `${key}`, sx + 4 * u, sy + 12 * u, 12 * u, cur ? '#120d0a' : '#ffd23f', 'left', cur ? '#ffd23f' : '#120d0a');
      if (it.id !== 'pistol') {
        outlinedText(ctx, `${it.ammo}`, sx + bw - 4 * u, sy + bh - 3 * u, 12 * u, '#ffffff', 'right');
      }
      sx += bw + 6 * u;
    }
  }

  // --------- melee hit counter (Ninja Gaiden style)
  if (s.hits >= 2 && s.hitsT > 0) {
    const a = clamp(s.hitsT / 0.4, 0, 1);
    const hx = 26 * u;
    const hy = H * 0.44;
    const pop = 1 + Math.max(0, s.hitsT - 1.25) * 1.6;
    ctx.save();
    ctx.globalAlpha = a;
    ctx.translate(hx, hy);
    ctx.scale(pop, pop);
    outlinedText(ctx, `${s.hits}`, 0, 0, 58 * u, s.hits >= 10 ? '#ff4d4d' : s.hits >= 5 ? '#ffd23f' : '#ffffff', 'left');
    ctx.font = `${58 * u}px ${FONT_D}`;
    const w = ctx.measureText(`${s.hits}`).width;
    outlinedText(ctx, 'HIT!', w + 8 * u, -6 * u, 26 * u, '#c7f0ff', 'left');
    ctx.fillStyle = '#c81d2a';
    ctx.beginPath();
    ctx.moveTo(0, 8 * u);
    ctx.lineTo(w + 70 * u, 4 * u);
    ctx.lineTo(w + 64 * u, 10 * u);
    ctx.lineTo(0, 13 * u);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // --------- top-center: enemies & bananas
  const cx = W / 2;
  if (s.mode === 'fist') {
    outlinedText(ctx, `MODE KUNGFU · GELOMBANG ${Math.max(1, s.wave)}/${s.waves}`, cx, y0 + 20 * u, 22 * u, '#ffd23f', 'center');
  } else if (s.mode === 'boss') {
    outlinedText(ctx, 'BOSS MODE', cx, y0 + 20 * u, 24 * u, '#ff6b6b', 'center');
  } else {
    outlinedText(ctx, `MUSUH ${s.kills}/${s.totalEnemies}`, cx - 20 * u, y0 + 20 * u, 22 * u, '#ffffff', 'right');
    drawBanana(ctx, cx + 10 * u, y0 + 10 * u, 0.6 * u, 0.3, false);
    outlinedText(ctx, `${s.bananas}/${s.totalBananas}`, cx + 26 * u, y0 + 20 * u, 22 * u, '#ffd93b', 'left');
  }
  const mm = Math.floor(s.time / 60);
  const ss = Math.floor(s.time % 60);
  outlinedText(ctx, `${mm}:${ss.toString().padStart(2, '0')}`, cx, y0 + 44 * u, 16 * u, '#d9d2c6', 'center');

  // --------- top-right: score & combo
  const rx = W - 24 * u;
  outlinedText(ctx, formatNum(s.score), rx, y0 + 40 * u, 46 * u * (1 + s.scorePulse * 0.22), s.scorePulse > 0.05 ? '#fff3a0' : '#ffffff', 'right');
  outlinedText(ctx, 'SKOR', rx, y0 + 2 * u, 14 * u, '#ffd23f', 'right');
  let ty = y0 + 66 * u;
  if (s.combo > 1) {
    const pulse = 1 + Math.max(0, 0.25 - (1 - s.comboT) * 2) * 0.3;
    outlinedText(ctx, `x${s.combo} COMBO`, rx, ty + 4 * u, 30 * u * pulse, s.combo >= 5 ? '#ff7b3a' : '#ffd23f', 'right');
    bar(ctx, rx - 150 * u, ty + 12 * u, 150 * u, 7 * u, s.comboT, '#ffe28a', '#ff9a1f');
    ty += 34 * u;
  }
  for (let i = 0; i < s.tags.length; i++) {
    const tag = s.tags[i];
    const a = clamp(tag.t / 0.4, 0, 1);
    const slide = (1 - clamp((1.8 - tag.t) / 0.15, 0, 1)) * 60 * u;
    ctx.globalAlpha = a;
    outlinedText(
      ctx,
      tag.pts > 0 ? `${tag.text} +${tag.pts}` : tag.text,
      rx + slide,
      ty + 18 * u + i * 24 * u,
      (tag.big ? 22 : 18) * u,
      tag.big ? '#ffffff' : '#ffe9a8',
      'right',
    );
    ctx.globalAlpha = 1;
  }

  // --------- boss bar
  if (s.boss) {
    const b = s.boss;
    const bw = Math.min(640 * u, W * 0.62);
    const bx = W / 2 - bw / 2;
    const bh = 18 * u;
    const by = H - 42 * u;
    outlinedText(ctx, b.name, bx, by - 12 * u, 30 * u, '#ffffff', 'left');
    if (b.title) outlinedText(ctx, b.title, bx + bw, by - 12 * u, 16 * u, '#ffd23f', 'right');
    ctx.fillStyle = '#120d0a';
    ctx.beginPath();
    ctx.roundRect(bx - 4 * u, by - 4 * u, bw + 8 * u, bh + 8 * u, 6 * u);
    ctx.fill();
    ctx.fillStyle = '#3a2e2a';
    ctx.fillRect(bx, by, bw, bh);
    const ks = clamp(b.shown / b.max, 0, 1);
    const k = clamp(b.hp / b.max, 0, 1);
    ctx.fillStyle = '#fff3c4';
    ctx.fillRect(bx, by, bw * ks, bh);
    const g = ctx.createLinearGradient(0, by, 0, by + bh);
    g.addColorStop(0, '#ff6060');
    g.addColorStop(1, '#a8141f');
    ctx.fillStyle = g;
    ctx.fillRect(bx, by, bw * k, bh);
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.fillRect(bx, by + 2 * u, bw * k, bh * 0.28);
    for (const m of b.marks) {
      ctx.fillStyle = '#120d0a';
      ctx.fillRect(bx + bw * m - 2 * u, by - 4 * u, 4 * u, bh + 8 * u);
    }
    if (b.marks.length) outlinedText(ctx, `FASE ${b.phase}`, bx + bw + 12 * u, by + bh - 1 * u, 19 * u, '#ff6b6b', 'left');
  }

  // --------- Pedro dialog
  if (s.hintAlpha > 0.01 && s.hintText) {
    ctx.globalAlpha = s.hintAlpha;
    const bw = Math.min(600 * u, W - 40 * u);
    const bx = 20 * u;
    const by = H - (s.boss ? 200 : 140) * u;
    const bh = 96 * u;
    ctx.fillStyle = 'rgba(18,13,10,0.92)';
    ctx.beginPath();
    ctx.roundRect(bx, by, bw, bh, 16 * u);
    ctx.fill();
    ctx.strokeStyle = '#ffd93b';
    ctx.lineWidth = 3 * u;
    ctx.stroke();
    // portrait
    ctx.fillStyle = '#3a2c12';
    ctx.beginPath();
    ctx.arc(bx + 50 * u, by + bh / 2, 36 * u, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = '#ffd93b';
    ctx.stroke();
    const talking = s.hintChars < s.hintText.length && Math.sin(s.realTime * 30) > 0 ? 1 : 0;
    drawBanana(ctx, bx + 52 * u, by + bh / 2, 1.45 * u, Math.sin(s.realTime * 3) * 0.12, true, talking);
    outlinedText(ctx, 'PEDRO', bx + 100 * u, by + 26 * u, 20 * u, '#ffd93b');
    ctx.font = `500 ${16 * u}px ${FONT_B}`;
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'left';
    const shown = s.hintText.slice(0, Math.floor(s.hintChars));
    const lines = wrap(ctx, shown, bw - 120 * u);
    lines.slice(0, 3).forEach((l, i) => ctx.fillText(l, bx + 100 * u, by + 50 * u + i * 20 * u));
    ctx.globalAlpha = 1;
  }

  // --------- level title
  if (s.titleT > 0) {
    const a = clamp(s.titleT, 0, 1);
    ctx.globalAlpha = a;
    const sc = 1 + (1 - clamp((4.2 - s.titleT) * 3, 0, 1)) * 0.6;
    outlinedText(ctx, s.levelName, W / 2, H * 0.36, 84 * u * sc, '#ffd23f', 'center');
    outlinedText(ctx, s.levelSub, W / 2, H * 0.36 + 46 * u, 32 * u, '#ffffff', 'center');
    ctx.globalAlpha = 1;
  }

  if (s.centerT > 0 && s.centerMsg) {
    ctx.globalAlpha = clamp(s.centerT, 0, 1);
    outlinedText(ctx, s.centerMsg, W / 2, H * 0.24, 40 * u, '#7dffa0', 'center');
    ctx.globalAlpha = 1;
  }

  if (s.splitActive) {
    outlinedText(ctx, 'SPLIT AIM', W / 2, H - 20 * u, 18 * u, '#ff6b6b', 'center');
  }
  ctx.restore();
}

export function drawCrosshair(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  color: string,
  spin: number,
  kind: 'main' | 'split',
  bloom = 0,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(spin);
  ctx.lineCap = 'round';
  const r = 11 * s * (1 + bloom * 0.7);
  for (const [lw, col] of [
    [5 * s, 'rgba(0,0,0,0.75)'],
    [2.2 * s, color],
  ] as [number, string][]) {
    ctx.lineWidth = lw;
    ctx.strokeStyle = col;
    ctx.beginPath();
    if (kind === 'main') {
      ctx.arc(0, 0, r, 0, TAU);
      ctx.moveTo(r + 3 * s, 0);
      ctx.lineTo(r + 9 * s, 0);
      ctx.moveTo(-r - 3 * s, 0);
      ctx.lineTo(-r - 9 * s, 0);
      ctx.moveTo(0, r + 3 * s);
      ctx.lineTo(0, r + 9 * s);
      ctx.moveTo(0, -r - 3 * s);
      ctx.lineTo(0, -r - 9 * s);
    } else {
      ctx.moveTo(0, -r);
      ctx.lineTo(r, 0);
      ctx.lineTo(0, r);
      ctx.lineTo(-r, 0);
      ctx.closePath();
    }
    ctx.stroke();
  }
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(0, 0, 2.2 * s, 0, TAU);
  ctx.fill();
  ctx.restore();
}

export function drawHitMarker(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, t: number, kind: number) {
  const max = kind === 0 ? 0.22 : 0.42;
  const k = clamp(t / max, 0, 1);
  const col = kind === 2 ? '#ffd23f' : kind === 1 ? '#ff4d4d' : '#ffffff';
  const r1 = (7 + (1 - k) * 5) * s;
  const r2 = r1 + (kind === 0 ? 7 : 12) * s;
  ctx.save();
  ctx.translate(x, y);
  ctx.globalAlpha = k;
  ctx.lineCap = 'round';
  for (const [lw, c] of [
    [5.5 * s, 'rgba(0,0,0,0.7)'],
    [2.6 * s, col],
  ] as [number, string][]) {
    ctx.lineWidth = lw;
    ctx.strokeStyle = c;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      const a = Math.PI / 4 + (i * Math.PI) / 2;
      ctx.moveTo(Math.cos(a) * r1, Math.sin(a) * r1);
      ctx.lineTo(Math.cos(a) * r2, Math.sin(a) * r2);
    }
    ctx.stroke();
  }
  ctx.restore();
}

export function drawBossIntro(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  o: { name: string; title: string; tip: string; color: string; el: number; rem: number; t: number },
) {
  const u = clamp(Math.min(W / 1280, H / 760), 0.6, 1.5);
  const inK = 1 - Math.pow(1 - clamp(o.el / 0.5, 0, 1), 3);
  const outK = clamp(o.rem / 0.35, 0, 1);
  const k = Math.min(inK, outK);
  const lb = 80 * u * k;
  ctx.save();
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, W, lb);
  ctx.fillRect(0, H - lb, W, lb);
  const cy = H * 0.8;
  ctx.globalAlpha = outK;
  const slide = (1 - inK) * W * 1.1;
  ctx.translate(-slide, 0);
  ctx.fillStyle = '#120d0a';
  ctx.beginPath();
  ctx.moveTo(-20, cy - 74 * u);
  ctx.lineTo(W + 20, cy - 118 * u);
  ctx.lineTo(W + 20, cy + 46 * u);
  ctx.lineTo(-20, cy + 90 * u);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-20, cy - 62 * u);
  ctx.lineTo(W + 20, cy - 106 * u);
  ctx.lineTo(W + 20, cy + 34 * u);
  ctx.lineTo(-20, cy + 78 * u);
  ctx.closePath();
  ctx.fillStyle = o.color;
  ctx.fill();
  ctx.clip();
  ctx.fillStyle = 'rgba(0,0,0,0.13)';
  const off = (o.t * 80) % 46;
  for (let x = -260; x < W + 260; x += 46) {
    ctx.beginPath();
    ctx.moveTo(x + off, cy - 150 * u);
    ctx.lineTo(x + off + 22, cy - 150 * u);
    ctx.lineTo(x + off - 58, cy + 130 * u);
    ctx.lineTo(x + off - 80, cy + 130 * u);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
  const nameIn = 1 - Math.pow(1 - clamp((o.el - 0.15) / 0.45, 0, 1), 3);
  const shake = o.el > 0.55 && o.el < 0.95 ? (Math.random() - 0.5) * 8 * u : 0;
  ctx.save();
  ctx.globalAlpha = outK * nameIn;
  ctx.translate(W * 0.5 + (1 - nameIn) * W * 0.7 + shake, cy - 18 * u + shake * 0.5);
  ctx.rotate(-0.04);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.font = `${120 * u}px ${FONT_D}`;
  ctx.lineWidth = 14 * u;
  ctx.strokeStyle = '#120d0a';
  ctx.strokeText(o.name, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillText(o.name, 0, 0);
  ctx.font = `${34 * u}px ${FONT_D}`;
  ctx.lineWidth = 8 * u;
  ctx.strokeText(o.title, 0, 70 * u);
  ctx.fillText(o.title, 0, 70 * u);
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = k;
  outlinedText(ctx, 'BOSS', 34 * u, cy - 92 * u, 40 * u, '#ffffff', 'left');
  if (k > 0.6 && o.tip) {
    ctx.globalAlpha = (k - 0.6) / 0.4;
    ctx.font = `600 ${15 * u}px ${FONT_B}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('TIPS: ' + o.tip, W / 2, H - lb / 2);
  }
  ctx.restore();
}
