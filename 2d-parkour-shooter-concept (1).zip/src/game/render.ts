import type { DecoDef, RoomDef, ZiplineDef } from './level';
import { drawBanana } from './props';
import { TAU } from './math';
import type { Solid } from './world';

// polyfill for older browsers without CanvasRenderingContext2D.roundRect
if (typeof CanvasRenderingContext2D !== 'undefined' && !CanvasRenderingContext2D.prototype.roundRect) {
  const proto = CanvasRenderingContext2D.prototype as unknown as {
    roundRect: (x: number, y: number, w: number, h: number, r?: number) => void;
  };
  proto.roundRect = function (this: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r = 0) {
    const rr = Math.max(0, Math.min(typeof r === 'number' ? r : 0, Math.abs(w) / 2, Math.abs(h) / 2));
    this.moveTo(x + rr, y);
    this.lineTo(x + w - rr, y);
    this.arcTo(x + w, y, x + w, y + rr, rr);
    this.lineTo(x + w, y + h - rr);
    this.arcTo(x + w, y + h, x + w - rr, y + h, rr);
    this.lineTo(x + rr, y + h);
    this.arcTo(x, y + h, x, y + h - rr, rr);
    this.lineTo(x, y + rr);
    this.arcTo(x, y, x + rr, y, rr);
    this.closePath();
  };
}

export type Patterns = Record<string, CanvasPattern | string>;

function mk(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d') as CanvasRenderingContext2D;
  return { c, g };
}

function seeded(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function createPatterns(ctx: CanvasRenderingContext2D): Patterns {
  const P: Patterns = {};
  const pat = (c: HTMLCanvasElement, fallback: string) => ctx.createPattern(c, 'repeat') || fallback;
  const R = seeded(7);

  // brick
  {
    const { c, g } = mk(64, 32);
    g.fillStyle = '#5e3324';
    g.fillRect(0, 0, 64, 32);
    const cols = ['#9a5139', '#8d4a35', '#a3583e', '#87452f'];
    for (let row = 0; row < 2; row++) {
      for (let i = -1; i < 3; i++) {
        const x = i * 32 + (row % 2) * 16;
        g.fillStyle = cols[Math.floor(R() * cols.length)];
        g.fillRect(x + 1.5, row * 16 + 1.5, 29, 13);
        g.fillStyle = 'rgba(255,255,255,0.12)';
        g.fillRect(x + 1.5, row * 16 + 1.5, 29, 2.5);
      }
    }
    P.brick = pat(c, '#8d4a35');
  }
  // dark brick (facades)
  {
    const { c, g } = mk(48, 24);
    g.fillStyle = '#2e1c1a';
    g.fillRect(0, 0, 48, 24);
    const cols = ['#4a2c27', '#52302a', '#442823'];
    for (let row = 0; row < 2; row++) {
      for (let i = -1; i < 3; i++) {
        const x = i * 24 + (row % 2) * 12;
        g.fillStyle = cols[Math.floor(R() * cols.length)];
        g.fillRect(x + 1, row * 12 + 1, 22, 10);
      }
    }
    P.darkBrick = pat(c, '#4a2c27');
  }
  // concrete
  {
    const { c, g } = mk(96, 96);
    g.fillStyle = '#8f8b83';
    g.fillRect(0, 0, 96, 96);
    for (let i = 0; i < 160; i++) {
      g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.08)';
      const s = 1 + R() * 3;
      g.fillRect(R() * 96, R() * 96, s, s);
    }
    g.strokeStyle = 'rgba(0,0,0,0.12)';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(10, 60);
    g.lineTo(30, 52);
    g.lineTo(38, 70);
    g.stroke();
    P.concrete = pat(c, '#8f8b83');
  }
  // roof (darker concrete)
  {
    const { c, g } = mk(64, 64);
    g.fillStyle = '#4c4a4f';
    g.fillRect(0, 0, 64, 64);
    for (let i = 0; i < 90; i++) {
      g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.06)';
      g.fillRect(R() * 64, R() * 64, 2, 2);
    }
    P.roof = pat(c, '#4c4a4f');
  }
  // cinder blocks (basement bg)
  {
    const { c, g } = mk(80, 40);
    g.fillStyle = '#2c2926';
    g.fillRect(0, 0, 80, 40);
    for (let row = 0; row < 2; row++) {
      for (let i = -1; i < 2; i++) {
        const x = i * 40 + (row % 2) * 20;
        g.fillStyle = R() < 0.5 ? '#45413b' : '#3f3b36';
        g.fillRect(x + 2, row * 20 + 2, 36, 16);
      }
    }
    P.cinder = pat(c, '#45413b');
  }
  // floor tile (light)
  {
    const { c, g } = mk(32, 32);
    g.fillStyle = '#8d9aa0';
    g.fillRect(0, 0, 32, 32);
    g.fillStyle = '#c9d3d6';
    g.fillRect(1, 1, 30, 30);
    g.fillStyle = 'rgba(255,255,255,0.4)';
    g.fillRect(1, 1, 30, 4);
    P.tile = pat(c, '#c9d3d6');
  }
  // freezer bg
  {
    const { c, g } = mk(40, 40);
    g.fillStyle = '#7f9aa6';
    g.fillRect(0, 0, 40, 40);
    g.fillStyle = '#a7c0cb';
    g.fillRect(1.5, 1.5, 37, 37);
    g.fillStyle = 'rgba(255,255,255,0.18)';
    g.fillRect(1.5, 1.5, 37, 6);
    P.freezer = pat(c, '#a7c0cb');
  }
  // subway tile (kitchen)
  {
    const { c, g } = mk(40, 20);
    g.fillStyle = '#bdb6a3';
    g.fillRect(0, 0, 40, 20);
    for (let row = 0; row < 2; row++) {
      for (let i = -1; i < 2; i++) {
        const x = i * 20 + (row % 2) * 10;
        g.fillStyle = '#e6e1d2';
        g.fillRect(x + 1, row * 10 + 1, 18, 8);
        g.fillStyle = 'rgba(255,255,255,0.5)';
        g.fillRect(x + 1, row * 10 + 1, 18, 2);
      }
    }
    P.subway = pat(c, '#e6e1d2');
  }
  // checker
  {
    const { c, g } = mk(40, 40);
    g.fillStyle = '#e9e6dc';
    g.fillRect(0, 0, 40, 40);
    g.fillStyle = '#2c2c30';
    g.fillRect(0, 0, 20, 20);
    g.fillRect(20, 20, 20, 20);
    P.checker = pat(c, '#888');
  }
  // corrugated metal
  {
    const { c, g } = mk(24, 8);
    const gr = g.createLinearGradient(0, 0, 24, 0);
    gr.addColorStop(0, '#46505a');
    gr.addColorStop(0.5, '#5f6b77');
    gr.addColorStop(1, '#46505a');
    g.fillStyle = gr;
    g.fillRect(0, 0, 24, 8);
    P.corrugated = pat(c, '#56606a');
  }
  // steel plate
  {
    const { c, g } = mk(48, 48);
    g.fillStyle = '#69727c';
    g.fillRect(0, 0, 48, 48);
    g.strokeStyle = 'rgba(0,0,0,0.3)';
    g.lineWidth = 1;
    g.strokeRect(0.5, 0.5, 47, 47);
    g.fillStyle = 'rgba(255,255,255,0.08)';
    g.fillRect(1, 1, 46, 8);
    g.fillStyle = '#3d444b';
    for (const [x, y] of [
      [5, 5],
      [43, 5],
      [5, 43],
      [43, 43],
    ]) {
      g.beginPath();
      g.arc(x, y, 1.8, 0, TAU);
      g.fill();
    }
    P.steel = pat(c, '#69727c');
  }
  // wood planks
  {
    const { c, g } = mk(64, 16);
    g.fillStyle = '#7a4f2c';
    g.fillRect(0, 0, 64, 16);
    g.fillStyle = '#8f5f36';
    g.fillRect(0, 1, 64, 6);
    g.fillStyle = 'rgba(0,0,0,0.25)';
    g.fillRect(31, 0, 2, 16);
    P.wood = pat(c, '#7a4f2c');
  }
  // stair bg
  {
    const { c, g } = mk(64, 64);
    g.fillStyle = '#56645a';
    g.fillRect(0, 0, 64, 64);
    for (let i = 0; i < 70; i++) {
      g.fillStyle = 'rgba(0,0,0,0.07)';
      g.fillRect(R() * 64, R() * 64, 3, 3);
    }
    P.stair = pat(c, '#56645a');
  }
  // penthouse wallpaper
  {
    const { c, g } = mk(48, 48);
    g.fillStyle = '#5a1a22';
    g.fillRect(0, 0, 48, 48);
    g.fillStyle = '#651f28';
    g.fillRect(0, 0, 24, 48);
    g.strokeStyle = 'rgba(217,169,58,0.35)';
    g.lineWidth = 1.4;
    g.beginPath();
    g.moveTo(24, 6);
    g.lineTo(34, 24);
    g.lineTo(24, 42);
    g.lineTo(14, 24);
    g.closePath();
    g.stroke();
    g.beginPath();
    g.arc(24, 24, 4, 0, TAU);
    g.stroke();
    P.wallpaper = pat(c, '#5a1a22');
  }
  // dream checker
  {
    const { c, g } = mk(64, 64);
    g.fillStyle = '#2a1546';
    g.fillRect(0, 0, 64, 64);
    g.fillStyle = '#3d2163';
    g.fillRect(0, 0, 32, 32);
    g.fillRect(32, 32, 32, 32);
    for (let i = 0; i < 14; i++) {
      g.fillStyle = `rgba(255,255,255,${0.15 + R() * 0.35})`;
      g.fillRect(R() * 64, R() * 64, 1.5, 1.5);
    }
    P.dream = pat(c, '#2a1546');
  }
  return P;
}

// --------------------------------------------------------------- skyline
export interface Skyline {
  far: HTMLCanvasElement;
  near: HTMLCanvasElement;
}

export function createSkyline(): Skyline {
  const make = (w: number, h: number, seed: number, col: string, winCol: string, minH: number, maxH: number) => {
    const { c, g } = mk(w, h);
    const R = seeded(seed);
    let x = 0;
    while (x < w) {
      const bw = 50 + R() * 110;
      const bh = minH + R() * (maxH - minH);
      g.fillStyle = col;
      g.fillRect(x, h - bh, bw, bh);
      if (R() < 0.3) g.fillRect(x + bw * 0.4, h - bh - 30, 4, 30);
      if (R() < 0.25) {
        g.fillRect(x + 10, h - bh - 14, bw - 20, 14);
      }
      for (let wy = h - bh + 10; wy < h - 8; wy += 14) {
        for (let wx = x + 7; wx < x + bw - 8; wx += 12) {
          if (R() < 0.33) {
            g.fillStyle = winCol;
            g.globalAlpha = 0.4 + R() * 0.6;
            g.fillRect(wx, wy, 5, 7);
            g.globalAlpha = 1;
          }
        }
      }
      x += bw + R() * 6;
    }
    return c;
  };
  return {
    far: make(2400, 420, 11, '#2b2550', '#ffd98a', 120, 380),
    near: make(2400, 360, 23, '#191630', '#ffc966', 80, 300),
  };
}

export function drawSky(
  ctx: CanvasRenderingContext2D,
  W: number,
  H: number,
  camX: number,
  camY: number,
  zoom: number,
  sky: Skyline,
) {
  const shift = (-camY - 400) * 0.06 * zoom;
  const g = ctx.createLinearGradient(0, -H * 0.2 + shift, 0, H * 1.1 + shift);
  g.addColorStop(0, '#0f1433');
  g.addColorStop(0.45, '#3c2a63');
  g.addColorStop(0.75, '#b8586a');
  g.addColorStop(1, '#f39a5b');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  // stars
  ctx.fillStyle = 'rgba(255,255,255,0.7)';
  const R = seeded(99);
  for (let i = 0; i < 70; i++) {
    const sx = (R() * 3000 - camX * 0.02 * zoom) % W;
    const sy = R() * H * 0.45 + shift * 0.5;
    ctx.fillRect(sx < 0 ? sx + W : sx, sy, 1.5, 1.5);
  }
  // moon
  const mx = W * 0.78 - camX * 0.01 * zoom;
  const my = H * 0.18 + shift * 0.4;
  const mg = ctx.createRadialGradient(mx, my, 0, mx, my, 120 * zoom);
  mg.addColorStop(0, 'rgba(255,240,210,0.35)');
  mg.addColorStop(1, 'rgba(255,240,210,0)');
  ctx.fillStyle = mg;
  ctx.fillRect(mx - 130 * zoom, my - 130 * zoom, 260 * zoom, 260 * zoom);
  ctx.fillStyle = '#fff3d6';
  ctx.beginPath();
  ctx.arc(mx, my, 34 * zoom, 0, TAU);
  ctx.fill();
  ctx.fillStyle = 'rgba(200,180,150,0.35)';
  ctx.beginPath();
  ctx.arc(mx - 9 * zoom, my - 6 * zoom, 7 * zoom, 0, TAU);
  ctx.arc(mx + 10 * zoom, my + 9 * zoom, 5 * zoom, 0, TAU);
  ctx.fill();
  // skyline layers
  const layer = (img: HTMLCanvasElement, par: number, yOff: number, scale: number) => {
    const iw = img.width * scale * zoom;
    const ih = img.height * scale * zoom;
    let x0 = -((camX * par * zoom) % iw);
    if (x0 > 0) x0 -= iw;
    const y = H - ih + yOff * zoom + (-camY - 300) * par * 0.25 * zoom;
    for (let x = x0; x < W; x += iw) ctx.drawImage(img, x, y, iw, ih);
    ctx.fillStyle = '#120f22';
    if (y + ih < H) ctx.fillRect(0, y + ih - 1, W, H - y - ih + 2);
  };
  layer(sky.far, 0.12, 40, 1);
  layer(sky.near, 0.28, 90, 1.1);
}

// --------------------------------------------------------------- rooms
export function drawRoom(ctx: CanvasRenderingContext2D, r: RoomDef, P: Patterns, time: number) {
  ctx.save();
  if (r.style === 'dream') {
    ctx.restore();
    return;
  }
  if (r.style === 'dojo') {
    ctx.fillStyle = '#eadfc4';
    ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.strokeStyle = 'rgba(95,62,32,0.5)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = r.x; x <= r.x + r.w; x += 56) {
      ctx.moveTo(x, r.y + 30);
      ctx.lineTo(x, r.y + r.h - 150);
    }
    for (let y = r.y + 30; y <= r.y + r.h - 150; y += 74) {
      ctx.moveTo(r.x, y);
      ctx.lineTo(r.x + r.w, y);
    }
    ctx.stroke();
    ctx.fillStyle = '#4a2c17';
    for (let x = r.x; x <= r.x + r.w; x += 336) ctx.fillRect(x - 8, r.y, 16, r.h);
    ctx.fillRect(r.x, r.y, r.w, 30);
    ctx.fillStyle = '#6b4423';
    ctx.fillRect(r.x, r.y + r.h - 150, r.w, 150);
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    for (let x = r.x; x < r.x + r.w; x += 112) ctx.fillRect(x, r.y + r.h - 150, 3, 150);
    // red sun scroll
    const cx = r.x + r.w / 2;
    ctx.fillStyle = '#f6eedb';
    ctx.strokeStyle = OUTLINE;
    ctx.lineWidth = 2;
    ctx.fillRect(cx - 95, r.y + 70, 190, 250);
    ctx.strokeRect(cx - 95, r.y + 70, 190, 250);
    ctx.fillStyle = '#3a2412';
    ctx.fillRect(cx - 105, r.y + 62, 210, 10);
    ctx.fillRect(cx - 105, r.y + 318, 210, 10);
    ctx.fillStyle = '#c81d2a';
    ctx.beginPath();
    ctx.arc(cx, r.y + 165, 52, 0, TAU);
    ctx.fill();
    ctx.strokeStyle = '#1b1410';
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx - 30, r.y + 245);
    ctx.lineTo(cx + 30, r.y + 245);
    ctx.moveTo(cx, r.y + 232);
    ctx.lineTo(cx, r.y + 300);
    ctx.moveTo(cx - 24, r.y + 268);
    ctx.lineTo(cx - 6, r.y + 286);
    ctx.moveTo(cx + 24, r.y + 268);
    ctx.lineTo(cx + 6, r.y + 286);
    ctx.stroke();
    const g = ctx.createLinearGradient(0, r.y, 0, r.y + r.h);
    g.addColorStop(0, 'rgba(0,0,0,0.3)');
    g.addColorStop(0.3, 'rgba(0,0,0,0)');
    g.addColorStop(1, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = g;
    ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.restore();
    return;
  }
  if (r.style === 'penthouse') {
    ctx.fillStyle = P.wallpaper;
    ctx.fillRect(r.x, r.y, r.w, r.h);
    const wy = r.y + 70;
    const wh = r.h - 330;
    const wins = [r.x + 290, r.x + r.w - 290 - 280];
    for (let i = 0; i < wins.length; i++) {
      const wx = wins[i];
      const ww = 280;
      ctx.fillStyle = '#2a1810';
      ctx.fillRect(wx - 12, wy - 12, ww + 24, wh + 24);
      const g = ctx.createLinearGradient(0, wy, 0, wy + wh);
      g.addColorStop(0, '#0b1030');
      g.addColorStop(0.7, '#3a2a5c');
      g.addColorStop(1, '#a8506a');
      ctx.fillStyle = g;
      ctx.fillRect(wx, wy, ww, wh);
      if (i === 0) {
        ctx.fillStyle = '#fff3d6';
        ctx.beginPath();
        ctx.arc(wx + 70, wy + 70, 24, 0, TAU);
        ctx.fill();
      }
      const R = seeded(wx + 3);
      let bx = wx;
      while (bx < wx + ww) {
        const bw2 = Math.min(24 + R() * 40, wx + ww - bx);
        const bh2 = 60 + R() * (wh * 0.55);
        ctx.fillStyle = '#141029';
        ctx.fillRect(bx, wy + wh - bh2, bw2, bh2);
        ctx.fillStyle = '#ffd98a';
        for (let yy = wy + wh - bh2 + 8; yy < wy + wh - 6; yy += 12) {
          for (let xx = bx + 4; xx < bx + bw2 - 5; xx += 9) if (R() < 0.3) ctx.fillRect(xx, yy, 4, 6);
        }
        bx += bw2 + 2;
      }
      ctx.fillStyle = '#2a1810';
      ctx.fillRect(wx + ww / 2 - 4, wy, 8, wh);
      ctx.fillRect(wx, wy + wh * 0.45, ww, 8);
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.beginPath();
      ctx.moveTo(wx + 20, wy);
      ctx.lineTo(wx + 80, wy);
      ctx.lineTo(wx + 20, wy + 90);
      ctx.closePath();
      ctx.fill();
    }
    const wsy = r.y + r.h - 150;
    ctx.fillStyle = '#3b2216';
    ctx.fillRect(r.x, wsy, r.w, 150);
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.lineWidth = 3;
    for (let x = r.x + 20; x < r.x + r.w - 60; x += 130) ctx.strokeRect(x, wsy + 22, 110, 106);
    ctx.fillStyle = '#d9a93a';
    ctx.fillRect(r.x, wsy - 6, r.w, 6);
    ctx.fillStyle = '#2a1810';
    ctx.fillRect(r.x, r.y, r.w, 26);
    ctx.fillStyle = '#d9a93a';
    ctx.fillRect(r.x, r.y + 26, r.w, 4);
    const vg = ctx.createLinearGradient(0, r.y, 0, r.y + r.h);
    vg.addColorStop(0, 'rgba(0,0,0,0.3)');
    vg.addColorStop(0.3, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.25)');
    ctx.fillStyle = vg;
    ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.restore();
    return;
  }
  if (r.style === 'alley') {
    // building facades with uneven tops
    const segs: [number, number, number][] = [
      [3180, 3570, -940],
      [3570, 3990, -1080],
      [3990, 4600, -860],
    ];
    for (const [x0, x1, top] of segs) {
      ctx.fillStyle = P.darkBrick;
      ctx.fillRect(x0, top, x1 - x0, -220 - top);
      ctx.fillStyle = '#221514';
      ctx.fillRect(x0 - 6, top - 12, x1 - x0 + 12, 14);
      // windows grid
      const R = seeded(x0);
      for (let wy = top + 40; wy < -360; wy += 120) {
        for (let wx = x0 + 40; wx < x1 - 70; wx += 130) {
          const lit = R() < 0.6;
          ctx.fillStyle = '#1b1210';
          ctx.fillRect(wx - 4, wy - 4, 68, 88);
          ctx.fillStyle = lit ? '#ffcf73' : '#2a2f45';
          ctx.fillRect(wx, wy, 60, 80);
          if (lit) {
            ctx.fillStyle = 'rgba(180,90,40,0.35)';
            ctx.fillRect(wx, wy + 50, 60, 30);
            if (R() < 0.5) {
              // silhouette
              ctx.fillStyle = 'rgba(60,30,20,0.7)';
              ctx.beginPath();
              ctx.arc(wx + 20 + R() * 20, wy + 42, 8, 0, TAU);
              ctx.fill();
              ctx.fillRect(wx + 12 + R() * 20, wy + 50, 22, 30);
            }
          }
          ctx.fillStyle = '#1b1210';
          ctx.fillRect(wx + 28, wy, 4, 80);
          ctx.fillRect(wx, wy + 38, 60, 4);
          ctx.fillStyle = '#3a2420';
          ctx.fillRect(wx - 8, wy + 84, 76, 6);
        }
      }
    }
    // darker gradient near ground
    const g = ctx.createLinearGradient(0, -600, 0, -220);
    g.addColorStop(0, 'rgba(10,6,14,0)');
    g.addColorStop(1, 'rgba(10,6,14,0.55)');
    ctx.fillStyle = g;
    ctx.fillRect(r.x, -600, r.w, 380);
    ctx.restore();
    return;
  }
  let fill: CanvasPattern | string = '#333';
  let tint = 'rgba(0,0,0,0.25)';
  switch (r.style) {
    case 'basement':
      fill = P.cinder;
      tint = 'rgba(10,8,5,0.3)';
      break;
    case 'freezer':
      fill = P.freezer;
      tint = 'rgba(20,50,80,0.28)';
      break;
    case 'kitchen':
      fill = P.subway;
      tint = 'rgba(40,25,10,0.18)';
      break;
    case 'stair':
      fill = P.stair;
      tint = 'rgba(0,0,0,0.25)';
      break;
    case 'warehouse':
      fill = P.corrugated;
      tint = 'rgba(10,15,25,0.3)';
      break;
  }
  ctx.fillStyle = fill;
  ctx.fillRect(r.x, r.y, r.w, r.h);
  if (r.style === 'kitchen') {
    ctx.fillStyle = P.checker;
    ctx.fillRect(r.x, r.y + r.h - 120, r.w, 120);
    ctx.fillStyle = '#7a2e2e';
    ctx.fillRect(r.x, r.y + r.h - 126, r.w, 8);
  }
  if (r.style === 'stair') {
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.fillRect(r.x, r.y + r.h * 0.5, r.w, r.h * 0.5);
    ctx.fillStyle = '#d9b33f';
    for (let y = r.y + 40; y < r.y + r.h; y += 130) ctx.fillRect(r.x, y, r.w, 5);
  }
  if (r.style === 'warehouse') {
    // high windows
    for (let x = r.x + 80; x < r.x + r.w - 120; x += 220) {
      ctx.fillStyle = '#1c2230';
      ctx.fillRect(x - 4, r.y + 56, 148, 78);
      const wg = ctx.createLinearGradient(0, r.y + 60, 0, r.y + 130);
      wg.addColorStop(0, '#2c3a6a');
      wg.addColorStop(1, '#7a4f78');
      ctx.fillStyle = wg;
      ctx.fillRect(x, r.y + 60, 140, 70);
      ctx.fillStyle = '#1c2230';
      for (let k = 1; k < 4; k++) ctx.fillRect(x + k * 35 - 2, r.y + 60, 4, 70);
    }
    // columns
    ctx.fillStyle = 'rgba(20,24,30,0.55)';
    for (let x = r.x + 300; x < r.x + r.w; x += 440) ctx.fillRect(x, r.y, 26, r.h);
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    for (let x = r.x + 300; x < r.x + r.w; x += 440) ctx.fillRect(x + 4, r.y, 5, r.h);
  }
  if (r.style === 'freezer') {
    // frost at top
    const g = ctx.createLinearGradient(0, r.y, 0, r.y + 90);
    g.addColorStop(0, 'rgba(235,250,255,0.55)');
    g.addColorStop(1, 'rgba(235,250,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(r.x, r.y, r.w, 90);
    // cold mist drifting
    ctx.fillStyle = 'rgba(230,245,255,0.08)';
    for (let i = 0; i < 6; i++) {
      const mx = r.x + ((i * 340 + time * 18) % r.w);
      ctx.beginPath();
      ctx.ellipse(mx, r.y + r.h - 30, 120, 26, 0, 0, TAU);
      ctx.fill();
    }
  }
  // depth tint + vignette inside room
  ctx.fillStyle = tint;
  ctx.fillRect(r.x, r.y, r.w, r.h);
  const g = ctx.createLinearGradient(0, r.y, 0, r.y + r.h);
  g.addColorStop(0, 'rgba(0,0,0,0.35)');
  g.addColorStop(0.25, 'rgba(0,0,0,0)');
  g.addColorStop(0.8, 'rgba(0,0,0,0)');
  g.addColorStop(1, 'rgba(0,0,0,0.3)');
  ctx.fillStyle = g;
  ctx.fillRect(r.x, r.y, r.w, r.h);
  ctx.restore();
}

// --------------------------------------------------------------- solids
const OUTLINE = '#17120f';

export function drawSolid(ctx: CanvasRenderingContext2D, s: Solid, P: Patterns) {
  const { x, y, w, h } = s;
  ctx.lineJoin = 'round';
  switch (s.kind) {
    case 'crate': {
      ctx.fillStyle = '#b07a43';
      ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = '#6b4523';
      ctx.lineWidth = 5;
      ctx.strokeRect(x + 4, y + 4, w - 8, h - 8);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(x + 6, y + 6);
      ctx.lineTo(x + w - 6, y + h - 6);
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.fillRect(x + 2, y + 2, w - 4, 3);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2.5;
      ctx.strokeRect(x, y, w, h);
      return;
    }
    case 'dumpster': {
      ctx.fillStyle = '#2f6b3a';
      ctx.beginPath();
      ctx.moveTo(x + 4, y + 8);
      ctx.lineTo(x + w - 4, y + 8);
      ctx.lineTo(x + w - 8, y + h - 8);
      ctx.lineTo(x + 8, y + h - 8);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.fillStyle = '#245530';
      ctx.fillRect(x + 14, y + 16, w - 28, h - 32);
      ctx.fillStyle = '#3d8049';
      ctx.fillRect(x, y, w, 9);
      ctx.strokeRect(x, y, w, 9);
      ctx.fillStyle = '#1c1c1c';
      ctx.beginPath();
      ctx.arc(x + 16, y + h - 5, 5, 0, TAU);
      ctx.arc(x + w - 16, y + h - 5, 5, 0, TAU);
      ctx.fill();
      ctx.fillStyle = '#f2f2f2';
      ctx.font = 'bold 11px Rubik, Arial';
      ctx.textAlign = 'center';
      ctx.fillText('SAMPAH', x + w / 2, y + h / 2 + 4);
      return;
    }
    case 'counter': {
      ctx.fillStyle = '#d8d2c4';
      ctx.fillRect(x, y + 8, w, h - 8);
      ctx.fillStyle = '#b9b1a0';
      const doorW = Math.min(46, w / 2 - 4);
      for (let dx = x + 6; dx + doorW <= x + w - 4; dx += doorW + 6) {
        ctx.fillRect(dx, y + 16, doorW, h - 22);
        ctx.fillStyle = '#6d6a63';
        ctx.fillRect(dx + doorW - 9, y + 26, 3, 12);
        ctx.fillStyle = '#b9b1a0';
      }
      ctx.fillStyle = '#c7ccd2';
      ctx.fillRect(x - 3, y, w + 6, 9);
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.fillRect(x - 3, y, w + 6, 2.5);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2.5;
      ctx.strokeRect(x - 3, y, w + 6, 9);
      ctx.strokeRect(x, y + 9, w, h - 9);
      return;
    }
    case 'table':
    case 'steeltable': {
      const steel = s.kind === 'steeltable';
      const top = steel ? '#c3cbd2' : '#a8713f';
      const leg = steel ? '#7d868f' : '#6b4423';
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.fillRect(x + 6, y + h - 4, w - 12, 4);
      ctx.fillStyle = leg;
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      for (const lx of [x + 8, x + w - 17]) {
        ctx.fillRect(lx, y + 8, 9, h - 8);
        ctx.strokeRect(lx, y + 8, 9, h - 8);
      }
      ctx.fillRect(x + 14, y + h - 16, w - 28, 5);
      ctx.strokeRect(x + 14, y + h - 16, w - 28, 5);
      ctx.fillStyle = top;
      ctx.fillRect(x - 5, y, w + 10, 11);
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.fillRect(x - 5, y, w + 10, 3);
      ctx.strokeRect(x - 5, y, w + 10, 11);
      if (steel) {
        // meat slab + cleaver on butcher table
        ctx.fillStyle = '#c44d4d';
        ctx.beginPath();
        ctx.ellipse(x + w * 0.4, y - 5, 20, 7, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#f0d9c8';
        ctx.fillRect(x + w * 0.4 - 12, y - 7, 6, 4);
        ctx.fillStyle = '#9aa3ad';
        ctx.fillRect(x + w * 0.72, y - 10, 16, 9);
        ctx.strokeRect(x + w * 0.72, y - 10, 16, 9);
        ctx.fillStyle = '#3b2416';
        ctx.fillRect(x + w * 0.72 + 16, y - 7, 12, 4);
      } else {
        // bottle + plate
        ctx.fillStyle = '#2f7a3a';
        ctx.fillRect(x + w * 0.25, y - 16, 6, 16);
        ctx.fillRect(x + w * 0.25 + 1.5, y - 22, 3, 6);
        ctx.strokeRect(x + w * 0.25, y - 16, 6, 16);
        ctx.fillStyle = '#f2efe6';
        ctx.beginPath();
        ctx.ellipse(x + w * 0.62, y - 2, 12, 3, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      return;
    }
    case 'duct': {
      ctx.fillStyle = '#8f9ba6';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      ctx.fillRect(x + 8, y, 10, h);
      ctx.fillStyle = 'rgba(0,0,0,0.18)';
      ctx.fillRect(x + w - 22, y, 14, h);
      ctx.strokeStyle = 'rgba(30,35,40,0.6)';
      ctx.lineWidth = 3;
      for (let yy = y + 40; yy < y + h; yy += 70) {
        ctx.beginPath();
        ctx.moveTo(x, yy);
        ctx.lineTo(x + w, yy);
        ctx.stroke();
      }
      // bottom flange
      ctx.fillStyle = '#6d7782';
      ctx.fillRect(x - 6, y + h - 14, w + 12, 14);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2.5;
      ctx.strokeRect(x - 6, y + h - 14, w + 12, 14);
      ctx.strokeRect(x, y, w, h - 14);
      // warning stripes on bottom
      ctx.save();
      ctx.beginPath();
      ctx.rect(x - 6, y + h - 14, w + 12, 14);
      ctx.clip();
      ctx.fillStyle = '#f2c230';
      for (let sx = x - 20; sx < x + w + 20; sx += 18) {
        ctx.beginPath();
        ctx.moveTo(sx, y + h);
        ctx.lineTo(sx + 9, y + h);
        ctx.lineTo(sx + 19, y + h - 14);
        ctx.lineTo(sx + 10, y + h - 14);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      return;
    }
  }
  if (s.kind === 'dream') {
    if (s.oneWay) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const gl = ctx.createRadialGradient(x + w / 2, y + 8, 0, x + w / 2, y + 8, w * 0.6);
      gl.addColorStop(0, 'rgba(255,150,230,0.25)');
      gl.addColorStop(1, 'rgba(255,150,230,0)');
      ctx.fillStyle = gl;
      ctx.fillRect(x - w * 0.1, y - 40, w * 1.2, 100);
      ctx.restore();
      const g = ctx.createLinearGradient(x, y, x, y + h + 8);
      g.addColorStop(0, '#ffb3ec');
      g.addColorStop(1, '#8a5cff');
      ctx.fillStyle = g;
      ctx.strokeStyle = '#1b0f2e';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.roundRect(x, y, w, h + 6, 8);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.fillRect(x + 8, y + 2, w - 16, 3);
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      for (const cx2 of [x + 14, x + w - 14]) {
        ctx.beginPath();
        ctx.arc(cx2, y + h + 6, 10, 0, TAU);
        ctx.arc(cx2 + (cx2 < x + w / 2 ? 12 : -12), y + h + 9, 8, 0, TAU);
        ctx.fill();
      }
    } else {
      ctx.fillStyle = P.dream;
      ctx.fillRect(x, y, w, h);
      const g = ctx.createLinearGradient(0, y, 0, y + 12);
      g.addColorStop(0, '#ff9de2');
      g.addColorStop(1, 'rgba(255,157,226,0)');
      ctx.fillStyle = g;
      ctx.fillRect(x, y, w, 12);
      ctx.fillStyle = '#7df9ff';
      ctx.fillRect(x, y, w, 2.5);
      ctx.fillRect(x, y, 2.5, h);
      ctx.fillRect(x + w - 2.5, y, 2.5, h);
      ctx.strokeStyle = '#120a20';
      ctx.lineWidth = 3;
      ctx.strokeRect(x, y, w, h);
    }
    return;
  }
  if (s.oneWay) {
    if (s.kind === 'wood') {
      ctx.fillStyle = P.wood;
      ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);
      // brackets
      ctx.fillStyle = '#4a3020';
      for (let bx = x + 20; bx < x + w - 10; bx += 120) {
        ctx.beginPath();
        ctx.moveTo(bx, y + h);
        ctx.lineTo(bx + 16, y + h);
        ctx.lineTo(bx, y + h + 22);
        ctx.closePath();
        ctx.fill();
      }
    } else {
      // metal catwalk with railing
      ctx.strokeStyle = '#2d3238';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let px = x + 8; px < x + w; px += 32) {
        ctx.moveTo(px, y);
        ctx.lineTo(px, y - 34);
      }
      ctx.moveTo(x + 4, y - 34);
      ctx.lineTo(x + w - 4, y - 34);
      ctx.moveTo(x + 4, y - 18);
      ctx.lineTo(x + w - 4, y - 18);
      ctx.stroke();
      ctx.fillStyle = '#5f6871';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      for (let gx = x + 4; gx < x + w - 4; gx += 8) ctx.fillRect(gx, y + 4, 4, h - 7);
      ctx.fillStyle = '#e0b03a';
      ctx.fillRect(x, y, w, 3);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);
    }
    return;
  }
  let fill: CanvasPattern | string = '#777';
  let top = 'rgba(255,255,255,0.18)';
  switch (s.kind) {
    case 'concrete':
      fill = P.concrete;
      break;
    case 'brick':
      fill = P.brick;
      top = 'rgba(255,220,200,0.15)';
      break;
    case 'tile':
      fill = P.tile;
      top = 'rgba(255,255,255,0.35)';
      break;
    case 'metal':
      fill = P.steel;
      top = '#e0b03a';
      break;
    case 'wood':
      fill = P.wood;
      break;
    case 'roof':
      fill = P.roof;
      top = '#8a8790';
      break;
  }
  ctx.fillStyle = fill;
  ctx.fillRect(x, y, w, h);
  if (s.kind === 'roof' && h > 300) {
    // building facade windows below the roofline
    for (let wy = y + 90; wy < y + h - 60; wy += 110) {
      for (let wx = x + 220; wx < x + w - 70; wx += 95) {
        const lit = ((wx * 7 + wy * 13) % 5) === 0;
        ctx.fillStyle = '#1d1a22';
        ctx.fillRect(wx - 3, wy - 3, 50, 64);
        ctx.fillStyle = lit ? '#e8b65a' : '#2b3048';
        ctx.fillRect(wx, wy, 44, 58);
        ctx.fillStyle = '#1d1a22';
        ctx.fillRect(wx + 20, wy, 4, 58);
      }
    }
    ctx.fillStyle = '#3a383e';
    ctx.fillRect(x, y + 8, w, 10);
  }
  // inner shading
  ctx.fillStyle = 'rgba(0,0,0,0.12)';
  ctx.fillRect(x, y + h * 0.6, w, h * 0.4);
  ctx.fillStyle = top;
  ctx.fillRect(x, y, w, s.kind === 'metal' ? 3 : 5);
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 3;
  ctx.strokeRect(x, y, w, h);
}

// --------------------------------------------------------------- decos
export function drawDeco(ctx: CanvasRenderingContext2D, d: DecoDef, time: number) {
  const { x, y } = d;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  switch (d.type) {
    case 'pipe': {
      const w = d.w ?? 100;
      const h = d.h ?? 10;
      ctx.fillStyle = '#5f6d63';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      if (w > h) ctx.fillRect(x, y + 2, w, h * 0.25);
      else ctx.fillRect(x + 2, y, w * 0.25, h);
      ctx.fillStyle = '#4a564e';
      if (w > h) for (let px = x + 60; px < x + w; px += 140) ctx.fillRect(px, y - 2, 8, h + 4);
      else for (let py = y + 60; py < y + h; py += 140) ctx.fillRect(x - 2, py, w + 4, 8);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x, y, w, h);
      return;
    }
    case 'lamp': {
      const len = d.len ?? 40;
      ctx.strokeStyle = '#111';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y + len);
      ctx.stroke();
      ctx.fillStyle = '#2d3a33';
      ctx.beginPath();
      ctx.moveTo(x - 6, y + len);
      ctx.lineTo(x + 6, y + len);
      ctx.lineTo(x + 18, y + len + 14);
      ctx.lineTo(x - 18, y + len + 14);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.fillStyle = '#fff6c8';
      ctx.beginPath();
      ctx.ellipse(x, y + len + 14, 9, 3.5, 0, 0, TAU);
      ctx.fill();
      return;
    }
    case 'meat': {
      const len = d.len ?? 120;
      const sw = Math.sin(time * 1.3 + x * 0.01) * 0.05;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(sw);
      ctx.strokeStyle = '#3a3d42';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, len - 70);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, len - 64, 6, -Math.PI / 2, Math.PI * 0.9);
      ctx.stroke();
      ctx.translate(0, len - 58);
      ctx.fillStyle = '#c44d4d';
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-6, 0);
      ctx.quadraticCurveTo(-26, 20, -20, 60);
      ctx.quadraticCurveTo(-12, 82, 0, 84);
      ctx.quadraticCurveTo(14, 82, 20, 60);
      ctx.quadraticCurveTo(24, 22, 6, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#f0d9c8';
      ctx.beginPath();
      ctx.ellipse(-8, 34, 5, 20, 0.15, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = '#e8b9a8';
      ctx.lineWidth = 2.5;
      for (let k = 0; k < 4; k++) {
        ctx.beginPath();
        ctx.moveTo(-14, 18 + k * 14);
        ctx.quadraticCurveTo(0, 22 + k * 14, 15, 18 + k * 14);
        ctx.stroke();
      }
      ctx.restore();
      return;
    }
    case 'rail': {
      ctx.fillStyle = '#3a3f45';
      ctx.fillRect(x, y - 3, d.w ?? 100, 6);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x, y - 3, d.w ?? 100, 6);
      return;
    }
    case 'poster': {
      const w = d.w ?? 60;
      const h = d.h ?? 80;
      ctx.save();
      ctx.translate(x + w / 2, y + h / 2);
      ctx.rotate(-0.04);
      ctx.fillStyle = '#e9dfc4';
      ctx.fillRect(-w / 2, -h / 2, w, h);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(-w / 2, -h / 2, w, h);
      ctx.fillStyle = '#7a1c1c';
      ctx.font = 'bold 13px Bangers, Impact, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(d.text ?? '', 0, -h / 2 + 18);
      if (d.text === 'MENU') {
        ctx.fillStyle = '#333';
        ctx.font = '8px Rubik, Arial';
        ['PIZZA ..... 25', 'PASTA ..... 30', 'STEAK ..... 60', 'PISANG ..... 5'].forEach((l, i) =>
          ctx.fillText(l, 0, -h / 2 + 38 + i * 15),
        );
      } else {
        // wanted face (kid)
        ctx.fillStyle = '#f7c9a1';
        ctx.beginPath();
        ctx.arc(0, 4, 14, 0, TAU);
        ctx.fill();
        ctx.fillStyle = '#7a4421';
        ctx.beginPath();
        ctx.arc(0, 0, 14, Math.PI, TAU);
        ctx.fill();
        ctx.fillStyle = '#ffc21a';
        ctx.fillRect(-16, 19, 32, 14);
        ctx.fillStyle = '#7a1c1c';
        ctx.font = 'bold 9px Rubik, Arial';
        ctx.fillText('$5.000', 0, h / 2 - 5);
      }
      ctx.restore();
      return;
    }
    case 'sign': {
      const txt = d.text ?? '';
      ctx.font = 'bold 26px Bangers, Impact, sans-serif';
      const tw = ctx.measureText(txt).width;
      ctx.fillStyle = '#15121c';
      ctx.fillRect(x - 12, y - 30, tw + 24, 42);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x - 12, y - 30, tw + 24, 42);
      const flicker = Math.sin(time * 23 + x) > -0.92 ? 1 : 0.3;
      ctx.save();
      ctx.shadowColor = d.color ?? '#ff4d6d';
      ctx.shadowBlur = 14 * flicker;
      ctx.fillStyle = d.color ?? '#ff4d6d';
      ctx.globalAlpha = flicker;
      ctx.textAlign = 'left';
      ctx.fillText(txt, x, y);
      ctx.restore();
      return;
    }
    case 'graffiti': {
      ctx.save();
      ctx.font = 'bold 34px Bangers, Impact, sans-serif';
      ctx.fillStyle = d.color ?? '#e94f37';
      ctx.globalAlpha = 0.75;
      ctx.translate(x, y);
      ctx.rotate(-0.08);
      ctx.strokeStyle = 'rgba(0,0,0,0.5)';
      ctx.lineWidth = 4;
      ctx.strokeText(d.text ?? '', 0, 0);
      ctx.fillText(d.text ?? '', 0, 0);
      ctx.restore();
      return;
    }
    case 'boxes': {
      const w = d.w ?? 80;
      const h = d.h ?? 60;
      ctx.fillStyle = '#7d5a3a';
      ctx.fillRect(x, y - h, w, h);
      ctx.fillStyle = '#6a4b30';
      ctx.fillRect(x + w * 0.15, y - h - h * 0.6, w * 0.6, h * 0.6);
      ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y - h, w, h);
      ctx.strokeRect(x + w * 0.15, y - h - h * 0.6, w * 0.6, h * 0.6);
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.fillRect(x + w / 2 - 6, y - h, 12, h);
      return;
    }
    case 'vent': {
      const w = d.w ?? 60;
      const h = d.h ?? 40;
      ctx.fillStyle = '#5a6168';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#2a2e33';
      for (let k = 6; k < h - 4; k += 7) ctx.fillRect(x + 5, y + k, w - 10, 3);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(x, y, w, h);
      return;
    }
    case 'fan': {
      const r = d.w ?? 30;
      ctx.fillStyle = '#2a2e33';
      ctx.beginPath();
      ctx.arc(x, y, r, 0, TAU);
      ctx.fill();
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(time * 6);
      ctx.fillStyle = '#6a737c';
      for (let k = 0; k < 3; k++) {
        ctx.rotate(TAU / 3);
        ctx.beginPath();
        ctx.ellipse(r * 0.45, 0, r * 0.45, r * 0.18, 0, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, TAU);
      ctx.stroke();
      return;
    }
    case 'hazard': {
      const w = d.w ?? 100;
      const h = d.h ?? 14;
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, y, w, h);
      ctx.clip();
      ctx.fillStyle = '#1d1d1d';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#f2c230';
      for (let sx = x - h; sx < x + w + h; sx += 20) {
        ctx.beginPath();
        ctx.moveTo(sx, y + h);
        ctx.lineTo(sx + 10, y + h);
        ctx.lineTo(sx + 10 + h, y);
        ctx.lineTo(sx + h, y);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      return;
    }
    case 'chain': {
      const len = d.len ?? 100;
      ctx.strokeStyle = '#4b5057';
      ctx.lineWidth = 2;
      for (let k = 0; k < len; k += 8) {
        ctx.beginPath();
        ctx.ellipse(x, y + k + 4, 2.5, 4, 0, 0, TAU);
        ctx.stroke();
      }
      return;
    }
    case 'bgdoor': {
      const w = d.w ?? 100;
      const h = d.h ?? 160;
      ctx.fillStyle = '#c3ced4';
      ctx.fillRect(x, y - h, w, h);
      ctx.fillStyle = '#9fb0b8';
      ctx.fillRect(x + 8, y - h + 8, w - 16, h - 8);
      ctx.fillStyle = '#5a6670';
      ctx.fillRect(x + w - 26, y - h * 0.55, 14, 30);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y - h, w, h);
      ctx.fillStyle = '#2b6cb0';
      ctx.font = 'bold 12px Rubik, Arial';
      ctx.textAlign = 'center';
      ctx.fillText('-18°C', x + w / 2 - 6, y - h + 30);
      return;
    }
    case 'streetlamp': {
      const h = d.h ?? 240;
      ctx.fillStyle = '#23272e';
      ctx.fillRect(x - 4, y - h, 8, h);
      ctx.beginPath();
      ctx.moveTo(x, y - h);
      ctx.quadraticCurveTo(x + 10, y - h - 30, x + 44, y - h - 22);
      ctx.lineTo(x + 44, y - h - 16);
      ctx.quadraticCurveTo(x + 12, y - h - 22, x + 4, y - h + 6);
      ctx.fill();
      ctx.fillStyle = '#fff1b8';
      ctx.beginPath();
      ctx.ellipse(x + 44, y - h - 13, 12, 5, 0, 0, TAU);
      ctx.fill();
      return;
    }
    case 'trash': {
      ctx.fillStyle = '#1f2326';
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(x, y - 14, 18, 15, 0, 0, TAU);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(x + 22, y - 11, 14, 12, 0, 0, TAU);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      ctx.beginPath();
      ctx.ellipse(x - 5, y - 20, 5, 3, -0.5, 0, TAU);
      ctx.fill();
      return;
    }
    case 'ladder': {
      const h = d.h ?? 200;
      ctx.strokeStyle = '#2d3238';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y + h);
      ctx.moveTo(x + 24, y);
      ctx.lineTo(x + 24, y + h);
      for (let k = 12; k < h; k += 18) {
        ctx.moveTo(x, y + k);
        ctx.lineTo(x + 24, y + k);
      }
      ctx.stroke();
      return;
    }
    case 'fence': {
      const w = d.w ?? 120;
      const h = d.h ?? 120;
      ctx.strokeStyle = 'rgba(160,170,180,0.6)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      for (let k = -h; k < w; k += 10) {
        ctx.moveTo(x + k, y);
        ctx.lineTo(x + k + h, y - h);
        ctx.moveTo(x + k + h, y);
        ctx.lineTo(x + k, y - h);
      }
      ctx.save();
      ctx.rect(x, y - h, w, h);
      ctx.clip();
      ctx.stroke();
      ctx.restore();
      ctx.fillStyle = '#4b5058';
      ctx.fillRect(x - 3, y - h - 4, 6, h + 4);
      ctx.fillRect(x + w - 3, y - h - 4, 6, h + 4);
      ctx.fillRect(x, y - h - 4, w, 4);
      return;
    }
    case 'stove': {
      const w = d.w ?? 160;
      ctx.fillStyle = '#5b6168';
      ctx.fillRect(x, y - 70, w, 70);
      ctx.fillStyle = '#2b2f34';
      ctx.fillRect(x + 10, y - 56, w - 20, 40);
      ctx.fillStyle = '#ff7b2e';
      ctx.globalAlpha = 0.6 + Math.sin(time * 9) * 0.15;
      ctx.fillRect(x + 14, y - 32, w - 28, 10);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#1b1d20';
      ctx.fillRect(x - 3, y - 76, w + 6, 8);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y - 70, w, 70);
      // pot
      ctx.fillStyle = '#8b939c';
      ctx.fillRect(x + 20, y - 98, 44, 22);
      ctx.strokeRect(x + 20, y - 98, 44, 22);
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      for (let k = 0; k < 3; k++) {
        const sy = y - 104 - ((time * 30 + k * 20) % 60);
        ctx.beginPath();
        ctx.arc(x + 32 + k * 9 + Math.sin(time * 2 + k) * 4, sy, 6, 0, TAU);
        ctx.fill();
      }
      return;
    }
    case 'hood': {
      const w = d.w ?? 160;
      ctx.fillStyle = '#9aa3ad';
      ctx.beginPath();
      ctx.moveTo(x + 30, y);
      ctx.lineTo(x + w - 30, y);
      ctx.lineTo(x + w, y + 60);
      ctx.lineTo(x, y + 60);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      ctx.fillRect(x + 6, y + 52, w - 12, 4);
      return;
    }
    case 'fridge': {
      const w = d.w ?? 80;
      const h = d.h ?? 160;
      ctx.fillStyle = '#dfe4e8';
      ctx.fillRect(x, y - h, w, h);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y - h, w, h);
      ctx.beginPath();
      ctx.moveTo(x, y - h * 0.62);
      ctx.lineTo(x + w, y - h * 0.62);
      ctx.stroke();
      ctx.fillStyle = '#8b939c';
      ctx.fillRect(x + w - 12, y - h + 16, 5, 30);
      ctx.fillRect(x + w - 12, y - h * 0.55, 5, 40);
      return;
    }
    case 'panrack': {
      const w = d.w ?? 140;
      ctx.fillStyle = '#3a3f45';
      ctx.fillRect(x, y, w, 5);
      for (let k = 0; k < 4; k++) {
        const px = x + 18 + k * (w / 4);
        const sw = Math.sin(time * 1.5 + k) * 0.06;
        ctx.save();
        ctx.translate(px, y + 5);
        ctx.rotate(sw);
        ctx.strokeStyle = '#3a3f45';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, 10);
        ctx.stroke();
        ctx.fillStyle = k % 2 ? '#b87333' : '#30343a';
        ctx.beginPath();
        ctx.ellipse(0, 26 + k * 2, 11, 14, 0, 0, TAU);
        ctx.fill();
        ctx.strokeStyle = OUTLINE;
        ctx.stroke();
        ctx.restore();
      }
      return;
    }
    case 'watertower': {
      ctx.fillStyle = '#2a2420';
      ctx.fillRect(x - 46, y - 110, 6, 110);
      ctx.fillRect(x + 40, y - 110, 6, 110);
      ctx.strokeStyle = '#2a2420';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x - 43, y - 10);
      ctx.lineTo(x + 43, y - 100);
      ctx.moveTo(x + 43, y - 10);
      ctx.lineTo(x - 43, y - 100);
      ctx.stroke();
      ctx.fillStyle = '#6b4a32';
      ctx.fillRect(x - 55, y - 220, 110, 112);
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      for (let k = 0; k < 110; k += 14) ctx.fillRect(x - 55 + k, y - 220, 3, 112);
      ctx.fillStyle = '#3d2b1e';
      ctx.beginPath();
      ctx.moveTo(x - 62, y - 218);
      ctx.lineTo(x, y - 262);
      ctx.lineTo(x + 62, y - 218);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.strokeRect(x - 55, y - 220, 110, 112);
      return;
    }
    case 'antenna': {
      const h = d.h ?? 180;
      ctx.strokeStyle = '#1e1b26';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x, y - h);
      for (let k = 30; k < h; k += 40) {
        ctx.moveTo(x - 20 + k * 0.05, y - k);
        ctx.lineTo(x + 20 - k * 0.05, y - k);
      }
      ctx.stroke();
      ctx.fillStyle = Math.sin(time * 4) > 0 ? '#ff3b3b' : '#5a1010';
      ctx.beginPath();
      ctx.arc(x, y - h, 4, 0, TAU);
      ctx.fill();
      return;
    }
    case 'pole': {
      const h = d.h ?? 140;
      ctx.fillStyle = '#3b3f46';
      ctx.fillRect(x - 5, y - h, 10, h);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x - 5, y - h, 10, h);
      ctx.fillStyle = '#e0b03a';
      ctx.fillRect(x - 5, y - 30, 10, 8);
      return;
    }
    case 'forklift': {
      ctx.fillStyle = '#e0a526';
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.roundRect(x, y - 70, 90, 50, 6);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#2b2b2b';
      ctx.fillRect(x + 10, y - 120, 6, 50);
      ctx.fillRect(x + 60, y - 120, 6, 50);
      ctx.fillRect(x + 10, y - 122, 56, 6);
      ctx.fillStyle = '#3b3b3b';
      ctx.fillRect(x + 90, y - 110, 8, 100);
      ctx.fillRect(x + 98, y - 18, 40, 6);
      ctx.fillStyle = '#1b1b1b';
      ctx.beginPath();
      ctx.arc(x + 20, y - 14, 14, 0, TAU);
      ctx.arc(x + 74, y - 14, 14, 0, TAU);
      ctx.fill();
      ctx.fillStyle = '#777';
      ctx.beginPath();
      ctx.arc(x + 20, y - 14, 5, 0, TAU);
      ctx.arc(x + 74, y - 14, 5, 0, TAU);
      ctx.fill();
      return;
    }
    case 'exitsign': {
      ctx.fillStyle = '#0e3d1e';
      ctx.fillRect(x - 34, y - 16, 68, 26);
      ctx.save();
      ctx.shadowColor = '#3dff7a';
      ctx.shadowBlur = 12;
      ctx.fillStyle = '#3dff7a';
      ctx.font = 'bold 18px Bangers, Impact, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('KELUAR', x, y + 4);
      ctx.restore();
      return;
    }
    case 'beam': {
      const w = d.w ?? 300;
      ctx.fillStyle = '#2c3138';
      ctx.fillRect(x, y, w, 14);
      ctx.strokeStyle = '#2c3138';
      ctx.lineWidth = 3;
      ctx.beginPath();
      for (let k = 0; k < w; k += 40) {
        ctx.moveTo(x + k, y + 14);
        ctx.lineTo(x + k + 20, y + 40);
        ctx.lineTo(x + k + 40, y + 14);
      }
      ctx.moveTo(x, y + 40);
      ctx.lineTo(x + w, y + 40);
      ctx.stroke();
      return;
    }
    case 'desk': {
      const w = d.w ?? 170;
      ctx.fillStyle = '#5a2f1b';
      ctx.fillRect(x, y - 62, w, 62);
      ctx.fillStyle = '#6e3a22';
      ctx.fillRect(x + 10, y - 52, w / 2 - 15, 40);
      ctx.fillRect(x + w / 2 + 5, y - 52, w / 2 - 15, 40);
      ctx.fillStyle = '#d9a93a';
      ctx.fillRect(x + w / 4 - 6, y - 34, 12, 3);
      ctx.fillRect(x + (3 * w) / 4 - 6, y - 34, 12, 3);
      ctx.fillStyle = '#3b1f12';
      ctx.fillRect(x - 8, y - 70, w + 16, 10);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y - 62, w, 62);
      ctx.strokeRect(x - 8, y - 70, w + 16, 10);
      ctx.fillStyle = '#5fae55';
      for (let i = 0; i < 3; i++) {
        const hh = 8 + i * 4;
        ctx.fillRect(x + 18 + i * 19, y - 70 - hh, 16, hh);
        ctx.strokeRect(x + 18 + i * 19, y - 70 - hh, 16, hh);
      }
      const lx = x + w - 34;
      ctx.fillStyle = '#d9a93a';
      ctx.fillRect(lx - 9, y - 74, 18, 4);
      ctx.fillRect(lx - 1.5, y - 98, 3, 24);
      ctx.fillStyle = '#2f6b3a';
      ctx.beginPath();
      ctx.ellipse(lx, y - 100, 16, 7, 0, Math.PI, TAU);
      ctx.fill();
      ctx.stroke();
      return;
    }
    case 'painting': {
      const w = d.w ?? 90;
      const h = d.h ?? 110;
      ctx.fillStyle = '#d9a93a';
      ctx.fillRect(x - 8, y - 8, w + 16, h + 16);
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.strokeRect(x - 8, y - 8, w + 16, h + 16);
      ctx.fillStyle = '#1f3a2a';
      ctx.fillRect(x, y, w, h);
      const cx = x + w / 2;
      ctx.fillStyle = '#efe8d6';
      ctx.fillRect(cx - 26, y + h - 30, 52, 30);
      ctx.fillStyle = '#d62828';
      ctx.fillRect(cx - 3, y + h - 28, 6, 22);
      ctx.fillStyle = '#e8b48a';
      ctx.beginPath();
      ctx.arc(cx, y + h * 0.45, 20, 0, TAU);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#1a120c';
      ctx.beginPath();
      ctx.moveTo(cx - 16, y + h * 0.52);
      ctx.quadraticCurveTo(cx, y + h * 0.44, cx + 16, y + h * 0.52);
      ctx.quadraticCurveTo(cx + 18, y + h * 0.6, cx + 9, y + h * 0.57);
      ctx.quadraticCurveTo(cx, y + h * 0.54, cx - 9, y + h * 0.57);
      ctx.quadraticCurveTo(cx - 18, y + h * 0.6, cx - 16, y + h * 0.52);
      ctx.fill();
      ctx.fillStyle = '#f2ecdc';
      ctx.fillRect(cx - 17, y + h * 0.18, 34, 14);
      ctx.fillRect(cx - 26, y + h * 0.3, 52, 5);
      ctx.fillStyle = '#1a1a1a';
      ctx.fillRect(cx - 17, y + h * 0.27, 34, 3);
      ctx.fillStyle = '#111';
      ctx.beginPath();
      ctx.arc(cx - 7, y + h * 0.43, 2, 0, TAU);
      ctx.arc(cx + 7, y + h * 0.43, 2, 0, TAU);
      ctx.fill();
      return;
    }
    case 'plant': {
      ctx.fillStyle = '#b5532c';
      ctx.beginPath();
      ctx.moveTo(x - 16, y - 34);
      ctx.lineTo(x + 16, y - 34);
      ctx.lineTo(x + 12, y);
      ctx.lineTo(x - 12, y);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = '#2f7a3a';
      for (let i = 0; i < 7; i++) {
        const a = -Math.PI / 2 + (i - 3) * 0.38 + Math.sin(time * 1.2 + i) * 0.03;
        ctx.save();
        ctx.translate(x, y - 34);
        ctx.rotate(a + Math.PI / 2);
        ctx.beginPath();
        ctx.ellipse(0, -26, 7, 26, 0, 0, TAU);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
      return;
    }
    case 'curtain': {
      const w = d.w ?? 54;
      const h = d.h ?? 380;
      ctx.fillStyle = '#d9a93a';
      ctx.fillRect(x - 6, y - 6, w + 12, 6);
      const g = ctx.createLinearGradient(x, 0, x + w, 0);
      g.addColorStop(0, '#5e0f17');
      g.addColorStop(0.3, '#9b1c27');
      g.addColorStop(0.55, '#6e121b');
      g.addColorStop(0.8, '#a8212d');
      g.addColorStop(1, '#5e0f17');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + w, y);
      ctx.lineTo(x + w * 0.9, y + h);
      ctx.quadraticCurveTo(x + w / 2, y + h + 10, x + w * 0.1, y + h);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = OUTLINE;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = '#d9a93a';
      ctx.fillRect(x + 4, y + h * 0.6, w - 8, 6);
      return;
    }
    case 'window': {
      const w = d.w ?? 80;
      const h = d.h ?? 100;
      ctx.fillStyle = '#1b1210';
      ctx.fillRect(x - 4, y - 4, w + 8, h + 8);
      ctx.fillStyle = '#ffcf73';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#1b1210';
      ctx.fillRect(x + w / 2 - 2, y, 4, h);
      return;
    }
  }
}

export function drawLampLight(ctx: CanvasRenderingContext2D, d: DecoDef, time: number) {
  const len = d.len ?? 40;
  const x = d.x;
  const y = d.y + len + 14;
  const flick = 0.92 + Math.sin(time * 37 + x) * 0.04 + (Math.sin(time * 3.1 + x) > 0.995 ? -0.5 : 0);
  const g = ctx.createLinearGradient(0, y, 0, y + 340);
  g.addColorStop(0, `rgba(255,214,140,${0.22 * flick})`);
  g.addColorStop(1, 'rgba(255,214,140,0)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x - 12, y);
  ctx.lineTo(x + 12, y);
  ctx.lineTo(x + 170, y + 340);
  ctx.lineTo(x - 170, y + 340);
  ctx.closePath();
  ctx.fill();
  const rg = ctx.createRadialGradient(x, y, 0, x, y, 60);
  rg.addColorStop(0, `rgba(255,236,180,${0.35 * flick})`);
  rg.addColorStop(1, 'rgba(255,236,180,0)');
  ctx.fillStyle = rg;
  ctx.fillRect(x - 60, y - 60, 120, 120);
}

export function drawStreetLight(ctx: CanvasRenderingContext2D, d: DecoDef) {
  const h = d.h ?? 240;
  const x = d.x + 44;
  const y = d.y - h - 10;
  const g = ctx.createLinearGradient(0, y, 0, d.y);
  g.addColorStop(0, 'rgba(255,230,160,0.28)');
  g.addColorStop(1, 'rgba(255,230,160,0.02)');
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x - 10, y);
  ctx.lineTo(x + 10, y);
  ctx.lineTo(x + 120, d.y);
  ctx.lineTo(x - 120, d.y);
  ctx.closePath();
  ctx.fill();
}

export function drawZipline(ctx: CanvasRenderingContext2D, z: ZiplineDef) {
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(z.x1, z.y1);
  ctx.lineTo(z.x2, z.y2);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.25)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(z.x1, z.y1 - 1);
  ctx.lineTo(z.x2, z.y2 - 1);
  ctx.stroke();
}

/** psychedelic dream-world backdrop for Pedro's arena */
export function drawDreamSky(ctx: CanvasRenderingContext2D, W: number, H: number, t: number, phase: number, camX: number) {
  const cols =
    phase === 1 ? ['#1f0b3a', '#6a2280', '#ff7eb6'] : phase === 2 ? ['#2a0820', '#a02a5c', '#ffb347'] : ['#120204', '#6a0a14', '#ff4d2e'];
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, cols[0]);
  g.addColorStop(0.62, cols[1]);
  g.addColorStop(1, cols[2]);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  const R = Math.hypot(W, H);
  ctx.save();
  ctx.translate(W / 2, H * 0.42);
  ctx.rotate(t * 0.06 * phase);
  ctx.fillStyle = `rgba(255,255,255,${0.035 + 0.02 * phase})`;
  for (let i = 0; i < 18; i++) {
    ctx.rotate(TAU / 18);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(R, -R * 0.09);
    ctx.lineTo(R, R * 0.09);
    ctx.closePath();
    ctx.fill();
  }
  const sg = ctx.createRadialGradient(0, 0, 0, 0, 0, H * 0.24);
  sg.addColorStop(0, 'rgba(255,240,200,0.55)');
  sg.addColorStop(1, 'rgba(255,240,200,0)');
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.arc(0, 0, H * 0.24, 0, TAU);
  ctx.fill();
  ctx.restore();
  const R2 = seeded(42);
  for (let i = 0; i < 60; i++) {
    const sx = R2() * W;
    const sy = R2() * H * 0.7;
    const sp = 1 + R2() * 2;
    const tw = 0.4 + 0.6 * Math.abs(Math.sin(t * sp + i));
    ctx.fillStyle = `rgba(255,255,255,${tw * 0.8})`;
    ctx.fillRect(sx, sy, 2, 2);
  }
  for (let i = 0; i < 7; i++) {
    const sp = 14 + (i % 3) * 10;
    const span = W + 400;
    const bx = ((((i * 397 + t * sp - camX * 0.05 * (1 + (i % 3))) % span) + span) % span) - 200;
    const by = H * (0.12 + ((i * 0.137) % 0.6));
    ctx.globalAlpha = 0.12 + (i % 3) * 0.05;
    drawBanana(ctx, bx, by + Math.sin(t * 0.8 + i) * 14, 2.2 + (i % 3) * 1.1, t * 0.25 + i, i % 2 === 0);
  }
  ctx.globalAlpha = 1;
}
