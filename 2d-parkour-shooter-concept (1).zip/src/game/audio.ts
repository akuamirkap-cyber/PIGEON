type Bus = 'sfx' | 'music';

export class Sound {
  ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private slowFilter: BiquadFilterNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private last: Record<string, number> = {};
  private musicTimer: number | null = null;
  private nextNote = 0;
  private seqStep = 0;
  muted = false;
  musicOn = true;
  private track: 'story' | 'boss' | 'pedro' = 'story';
  private hum: { o1: OscillatorNode; o2: OscillatorNode; g: GainNode } | null = null;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    try {
      const W = window as unknown as { webkitAudioContext?: typeof AudioContext };
      const AC = window.AudioContext || W.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
    } catch {
      this.ctx = null;
      return;
    }
    const c = this.ctx;
    this.master = c.createGain();
    this.master.gain.value = this.muted ? 0 : 0.75;
    this.master.connect(c.destination);
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.ratio.value = 5;
    comp.attack.value = 0.003;
    comp.release.value = 0.15;
    comp.connect(this.master);
    this.slowFilter = c.createBiquadFilter();
    this.slowFilter.type = 'lowpass';
    this.slowFilter.frequency.value = 18000;
    this.slowFilter.Q.value = 0.8;
    this.slowFilter.connect(comp);
    this.sfxBus = c.createGain();
    this.sfxBus.gain.value = 0.9;
    this.sfxBus.connect(this.slowFilter);
    // room reverb send: makes every shot / impact feel heavier
    try {
      const conv = c.createConvolver();
      const irLen = Math.floor(c.sampleRate * 1.5);
      const ir = c.createBuffer(2, irLen, c.sampleRate);
      for (let ch = 0; ch < 2; ch++) {
        const d = ir.getChannelData(ch);
        for (let i = 0; i < irLen; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / irLen, 3.4);
      }
      conv.buffer = ir;
      const wet = c.createGain();
      wet.gain.value = 0.2;
      this.sfxBus.connect(conv);
      conv.connect(wet);
      wet.connect(this.slowFilter);
    } catch {
      /* reverb is optional */
    }
    this.musicBus = c.createGain();
    this.musicBus.gain.value = 0.3;
    this.musicBus.connect(this.slowFilter);
    const len = c.sampleRate * 2;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const data = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.75, this.ctx.currentTime, 0.05);
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (this.musicBus && this.ctx) this.musicBus.gain.setTargetAtTime(on ? 0.3 : 0, this.ctx.currentTime, 0.1);
  }

  setSlowmo(amount: number) {
    if (!this.ctx || !this.slowFilter || !this.musicBus) return;
    const f = 18000 * Math.pow(700 / 18000, amount);
    this.slowFilter.frequency.setTargetAtTime(f, this.ctx.currentTime, 0.04);
  }

  private throttle(key: string, ms: number) {
    const now = performance.now();
    if (this.last[key] && now - this.last[key] < ms) return false;
    this.last[key] = now;
    return true;
  }

  private bus(b: Bus) {
    return b === 'music' ? this.musicBus : this.sfxBus;
  }

  private noise(
    t: number,
    dur: number,
    type: BiquadFilterType,
    freq: number,
    q: number,
    gain: number,
    freqEnd = 0,
    bus: Bus = 'sfx',
    attack = 0.002,
  ) {
    const c = this.ctx;
    const out = this.bus(bus);
    if (!c || !this.noiseBuf || !out) return;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd > 0) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gain, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(out);
    src.start(t, Math.random() * 1.5, dur + 0.05);
    src.stop(t + dur + 0.06);
  }

  private osc(
    t: number,
    type: OscillatorType,
    f0: number,
    f1: number,
    dur: number,
    gain: number,
    bus: Bus = 'sfx',
    lp = 0,
  ) {
    const c = this.ctx;
    const out = this.bus(bus);
    if (!c || !out) return;
    const o = c.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    if (lp > 0) {
      const f = c.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = lp;
      o.connect(f);
      f.connect(g);
    } else o.connect(g);
    g.connect(out);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private get now() {
    return this.ctx ? this.ctx.currentTime : 0;
  }

  shoot(
    kind: 'pistol' | 'uzi' | 'shotgun' | 'ak47' | 'sniper' | 'bat' | 'enemy' | 'enemyUzi' | 'enemyShotgun' | 'enemyAk' | 'enemySniper',
    vol = 1,
  ) {
    if (!this.ctx) return;
    const t = this.now;
    const r = 0.9 + Math.random() * 0.2;
    switch (kind) {
      case 'pistol':
        this.noise(t, 0.22, 'bandpass', 1900 * r, 0.7, 0.95);
        this.noise(t, 0.14, 'lowpass', 800, 0.5, 0.8);
        this.noise(t, 0.03, 'highpass', 5200, 0.7, 0.45);
        this.osc(t, 'sine', 170 * r, 45, 0.14, 0.9);
        this.osc(t, 'sine', 72, 32, 0.13, 0.6);
        break;
      case 'uzi':
        this.noise(t, 0.09, 'bandpass', 2600 * r, 0.8, 0.6);
        this.osc(t, 'square', 220 * r, 70, 0.05, 0.2, 'sfx', 1200);
        this.osc(t, 'sine', 190, 60, 0.06, 0.45);
        break;
      case 'shotgun':
        this.osc(t, 'sine', 64, 24, 0.4, 1.1);
        this.noise(t, 0.05, 'highpass', 4200, 0.7, 0.6);
        this.noise(t, 0.45, 'lowpass', 1500, 0.5, 1.0 * vol, 200);
        this.noise(t, 0.12, 'bandpass', 2400, 0.7, 0.6 * vol);
        this.osc(t, 'sine', 110, 32, 0.3, 1.0 * vol);
        break;
      case 'enemyShotgun':
        this.noise(t, 0.45, 'lowpass', 1500, 0.5, 1.0 * vol, 200);
        this.noise(t, 0.12, 'bandpass', 2400, 0.7, 0.6 * vol);
        this.osc(t, 'sine', 110, 32, 0.3, 1.0 * vol);
        break;
      case 'ak47':
      case 'enemyAk': {
        const v = kind === 'ak47' ? 1 : 0.55 * vol;
        this.noise(t, 0.16, 'bandpass', 1500 * r, 0.8, 0.85 * v);
        this.noise(t, 0.1, 'lowpass', 650, 0.6, 0.75 * v);
        this.noise(t, 0.025, 'highpass', 4800, 0.7, 0.45 * v);
        this.osc(t, 'sine', 135 * r, 40, 0.12, 0.85 * v);
        break;
      }
      case 'sniper':
      case 'enemySniper': {
        const v = kind === 'sniper' ? 1 : 0.85 * vol;
        this.noise(t, 0.05, 'highpass', 5200, 0.7, 0.95 * v);
        this.noise(t, 0.9, 'lowpass', 2400, 0.5, 1.2 * v, 140, 'sfx', 0.003);
        this.osc(t, 'sine', 95, 24, 0.9, 1.25 * v);
        this.osc(t, 'triangle', 60, 22, 0.7, 0.5 * v);
        this.noise(t + 0.22, 0.5, 'lowpass', 900, 0.6, 0.3 * v, 120, 'sfx', 0.02);
        break;
      }
      case 'bat':
        break;
      case 'enemy':
        this.noise(t, 0.17, 'bandpass', 1350 * r, 0.8, 0.55 * vol);
        this.osc(t, 'sine', 140 * r, 50, 0.11, 0.45 * vol);
        break;
      case 'enemyUzi':
        this.noise(t, 0.08, 'bandpass', 1900 * r, 0.9, 0.4 * vol);
        this.osc(t, 'sine', 170, 60, 0.05, 0.3 * vol);
        break;
    }
  }

  shell() {
    if (!this.ctx || !this.throttle('shell', 45)) return;
    const t = this.now + 0.02;
    const f = 3000 + Math.random() * 2500;
    this.osc(t, 'sine', f, f * 0.98, 0.07, 0.06);
    this.osc(t + 0.05, 'sine', f * 1.2, f * 1.15, 0.05, 0.04);
  }

  ricochet() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'triangle', 1900, 1300, 0.55, 0.28);
    this.osc(t, 'sine', 2800, 2700, 0.4, 0.14);
    this.osc(t, 'sine', 4100, 4000, 0.25, 0.08);
    this.noise(t, 0.06, 'highpass', 4000, 0.7, 0.4);
  }

  hit(head = false) {
    if (!this.ctx || !this.throttle('hit', 25)) return;
    const t = this.now;
    this.noise(t, 0.1, 'lowpass', 900, 0.8, 0.75);
    this.osc(t, 'sine', 95, 45, 0.09, 0.55);
    if (head) {
      this.noise(t, 0.07, 'bandpass', 3200, 1.2, 0.5);
      this.osc(t + 0.01, 'square', 600, 200, 0.05, 0.08, 'sfx', 2000);
    }
  }

  wallHit() {
    if (!this.ctx || !this.throttle('wall', 35)) return;
    const t = this.now;
    this.noise(t, 0.06, 'bandpass', 2800 + Math.random() * 1500, 1.5, 0.22);
  }

  explosion() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 1.4, 'lowpass', 900, 0.7, 1.3, 90, 'sfx', 0.005);
    this.noise(t, 0.5, 'bandpass', 500, 0.6, 0.6);
    this.osc(t, 'sine', 75, 24, 0.9, 1.1);
    this.osc(t, 'triangle', 50, 20, 1.0, 0.5);
  }

  glass() {
    if (!this.ctx || !this.throttle('glass', 80)) return;
    const t = this.now;
    this.noise(t, 0.35, 'highpass', 3000, 0.7, 0.55);
    for (let i = 0; i < 9; i++) {
      const f = 2500 + Math.random() * 4500;
      const d = Math.random() * 0.3;
      this.osc(t + d, 'sine', f, f * 0.97, 0.12, 0.07);
    }
  }

  whoosh(gain = 0.22) {
    if (!this.ctx || !this.throttle('whoosh', 90)) return;
    const t = this.now;
    this.noise(t, 0.28, 'bandpass', 350, 1.4, gain, 1700, 'sfx', 0.08);
  }

  slowIn() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 320, 55, 0.7, 0.4);
    this.noise(t, 0.6, 'lowpass', 2000, 0.8, 0.3, 120, 'sfx', 0.02);
  }

  slowOut() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 70, 330, 0.35, 0.25);
  }

  kick() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.12, 'lowpass', 600, 0.8, 0.55);
    this.osc(t, 'sine', 140, 55, 0.11, 0.5);
  }

  door() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.35, 'lowpass', 450, 0.6, 1.0);
    this.noise(t, 0.12, 'bandpass', 1400, 1.0, 0.5);
    this.osc(t, 'sine', 80, 38, 0.3, 0.8);
  }

  thud() {
    if (!this.ctx || !this.throttle('thud', 60)) return;
    const t = this.now;
    this.noise(t, 0.14, 'lowpass', 380, 0.6, 0.45);
    this.osc(t, 'sine', 70, 40, 0.12, 0.35);
  }

  breach() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.75, 'lowpass', 420, 0.6, 1.4, 70, 'sfx', 0.003);
    this.osc(t, 'sine', 110, 28, 0.55, 1.2);
    this.osc(t, 'triangle', 70, 30, 0.4, 0.5);
    this.noise(t, 0.16, 'bandpass', 1500, 0.9, 0.9);
    this.noise(t + 0.03, 0.22, 'bandpass', 800, 1.2, 0.6, 300);
    for (let i = 0; i < 7; i++) {
      const d = 0.02 + Math.random() * 0.3;
      this.noise(t + d, 0.04, 'bandpass', 1800 + Math.random() * 2600, 3, 0.22);
    }
  }

  roll() {
    if (!this.ctx || !this.throttle('roll', 200)) return;
    const t = this.now;
    this.noise(t, 0.1, 'lowpass', 420, 0.7, 0.4);
    this.noise(t + 0.06, 0.28, 'bandpass', 700, 1.1, 0.22, 1600, 'sfx', 0.05);
    this.noise(t + 0.22, 0.08, 'lowpass', 500, 0.7, 0.3);
  }

  duck(level = 0.35, hold = 0.8) {
    if (!this.ctx || !this.musicBus || !this.musicOn) return;
    const t = this.ctx.currentTime;
    const g = this.musicBus.gain;
    g.cancelScheduledValues(t);
    g.setTargetAtTime(0.3 * level, t, 0.03);
    g.setTargetAtTime(0.3, t + hold, 0.35);
  }

  stomp() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.2, 'lowpass', 650, 0.7, 1.0);
    this.osc(t, 'sine', 170, 42, 0.22, 1.0);
    this.noise(t, 0.06, 'bandpass', 2600, 1.5, 0.45);
    this.osc(t + 0.03, 'triangle', 260, 720, 0.2, 0.16);
  }

  slam() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.9, 'lowpass', 520, 0.6, 1.35, 60, 'sfx', 0.004);
    this.osc(t, 'sine', 95, 24, 0.75, 1.25);
    this.osc(t, 'triangle', 56, 22, 0.8, 0.5);
    this.noise(t, 0.28, 'bandpass', 900, 0.8, 0.55, 280);
    for (let i = 0; i < 6; i++) {
      this.noise(t + 0.05 + Math.random() * 0.3, 0.04, 'bandpass', 1200 + Math.random() * 2400, 3, 0.18);
    }
  }

  diveKick() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.38, 'bandpass', 380, 1.3, 0.45, 2600, 'sfx', 0.03);
    this.osc(t, 'sawtooth', 230, 90, 0.26, 0.06, 'sfx', 900);
  }

  marker(kind: number) {
    if (!this.ctx) return;
    const t = this.now;
    if (kind === 0) {
      this.osc(t, 'square', 1900, 1900, 0.03, 0.045, 'sfx', 5000);
      return;
    }
    this.osc(t, 'sine', 230, 85, 0.13, 0.4);
    this.osc(t, 'square', 1500, 1500, 0.05, 0.07, 'sfx', 4200);
    if (kind === 2) this.osc(t + 0.035, 'sine', 2700, 2600, 0.14, 0.14);
  }

  pump() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.05, 'bandpass', 1500, 2, 0.5);
    this.noise(t + 0.13, 0.06, 'bandpass', 1050, 2, 0.6);
    this.osc(t + 0.13, 'square', 520, 300, 0.04, 0.07, 'sfx', 2200);
  }

  shatter() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.45, 'bandpass', 900, 0.8, 0.95, 280);
    this.osc(t, 'sine', 120, 38, 0.32, 0.65);
    for (let i = 0; i < 10; i++) {
      this.noise(t + Math.random() * 0.35, 0.05, 'bandpass', 1500 + Math.random() * 2600, 3, 0.26);
    }
  }

  setTrack(t: 'story' | 'boss' | 'pedro') {
    this.track = t;
  }

  roar() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sawtooth', 120, 70, 1.1, 0.35, 'sfx', 700);
    this.osc(t, 'sawtooth', 127, 62, 1.1, 0.3, 'sfx', 520);
    this.noise(t, 1.0, 'bandpass', 420, 1.2, 0.55, 220, 'sfx', 0.08);
  }

  whistle() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 1900, 2600, 0.18, 0.18);
    this.osc(t + 0.22, 'sine', 2100, 1500, 0.32, 0.18);
  }

  bossIntro() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 1.6, 'lowpass', 900, 0.6, 1.1, 60, 'sfx', 0.005);
    this.osc(t, 'sine', 70, 30, 1.6, 1.1);
    for (const f of [220, 261.6, 311.1]) {
      this.osc(t, 'sawtooth', f, f, 1.2, 0.07, 'sfx', 1600);
      this.osc(t, 'square', f / 2, f / 2, 1.2, 0.05, 'sfx', 900);
    }
    this.osc(t + 0.05, 'triangle', 880, 860, 1.4, 0.1);
  }

  cleaver() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.3, 'bandpass', 600, 1.5, 0.3, 1800, 'sfx', 0.03);
    this.osc(t, 'triangle', 1400, 1300, 0.25, 0.06);
  }

  clang() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'square', 1600, 1500, 0.18, 0.12, 'sfx', 5000);
    this.osc(t, 'sine', 2400, 2300, 0.45, 0.18);
    this.osc(t, 'sine', 3700, 3650, 0.3, 0.1);
    this.noise(t, 0.05, 'highpass', 4000, 0.7, 0.5);
  }

  bananaPop() {
    if (!this.ctx || !this.throttle('bpop', 40)) return;
    const t = this.now;
    this.osc(t, 'sine', 300, 900, 0.12, 0.3);
    this.noise(t, 0.08, 'bandpass', 1800, 1.2, 0.35);
  }

  stampede() {
    if (!this.ctx || !this.throttle('stampede', 110)) return;
    const t = this.now;
    this.noise(t, 0.08, 'lowpass', 300, 0.7, 0.55);
    this.osc(t, 'sine', 90, 50, 0.08, 0.35);
  }

  laserCharge() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 300, 1600, 0.8, 0.12);
    this.osc(t, 'square', 150, 800, 0.8, 0.04, 'sfx', 2000);
  }

  laserHum(on: boolean) {
    const c = this.ctx;
    if (!c || !this.sfxBus) return;
    if (on && !this.hum) {
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, c.currentTime);
      g.gain.linearRampToValueAtTime(0.16, c.currentTime + 0.05);
      const f = c.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = 1800;
      const o1 = c.createOscillator();
      o1.type = 'sawtooth';
      o1.frequency.value = 96;
      const o2 = c.createOscillator();
      o2.type = 'square';
      o2.frequency.value = 193;
      o1.connect(f);
      o2.connect(f);
      f.connect(g);
      g.connect(this.sfxBus);
      o1.start();
      o2.start();
      this.hum = { o1, o2, g };
    } else if (!on && this.hum) {
      const h = this.hum;
      this.hum = null;
      const t = c.currentTime;
      h.g.gain.cancelScheduledValues(t);
      h.g.gain.setTargetAtTime(0.0001, t, 0.05);
      h.o1.stop(t + 0.3);
      h.o2.stop(t + 0.3);
    }
  }

  slash(w: 'katana' | 'bat', heavy: boolean) {
    if (!this.ctx) return;
    const t = this.now;
    if (w === 'katana') {
      this.noise(t, heavy ? 0.28 : 0.17, 'bandpass', heavy ? 2500 : 3400, 1.6, heavy ? 0.6 : 0.45, 650, 'sfx', 0.012);
      this.osc(t + 0.01, 'sine', heavy ? 2100 : 2900, heavy ? 1450 : 2250, heavy ? 0.26 : 0.16, 0.05);
      this.noise(t, 0.05, 'highpass', 6200, 0.7, 0.2);
    } else {
      this.noise(t, heavy ? 0.42 : 0.3, 'bandpass', 360, 1.4, heavy ? 0.65 : 0.48, 1900, 'sfx', 0.06);
    }
  }

  cut() {
    if (!this.ctx || !this.throttle('cut', 30)) return;
    const t = this.now;
    this.noise(t, 0.12, 'lowpass', 950, 0.8, 0.75);
    this.noise(t, 0.08, 'bandpass', 2600, 2, 0.42);
    this.osc(t, 'sine', 3300, 2600, 0.22, 0.08);
    this.osc(t, 'sine', 150, 58, 0.1, 0.5);
  }

  ting() {
    if (!this.ctx || !this.throttle('ting', 50)) return;
    const t = this.now;
    this.osc(t, 'sine', 3100, 3050, 0.5, 0.17);
    this.osc(t, 'sine', 4650, 4600, 0.35, 0.08);
    this.osc(t, 'square', 2200, 1800, 0.05, 0.05, 'sfx', 5000);
    this.noise(t, 0.04, 'highpass', 5000, 0.7, 0.4);
  }

  unsheath() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.36, 'bandpass', 1800, 2.2, 0.3, 7200, 'sfx', 0.05);
    this.osc(t + 0.05, 'sine', 2500, 3400, 0.4, 0.06);
  }

  sheath() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.2, 'bandpass', 5200, 2, 0.25, 1500, 'sfx', 0.03);
    this.osc(t + 0.19, 'square', 1500, 900, 0.035, 0.13, 'sfx', 4000);
    this.noise(t + 0.19, 0.04, 'highpass', 3000, 0.8, 0.45);
  }

  chargeUp(kat: boolean) {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 220, kat ? 1500 : 520, 0.55, 0.1);
    this.noise(t, 0.55, 'bandpass', kat ? 900 : 300, 2, 0.1, kat ? 5000 : 1200, 'sfx', 0.3);
  }

  chargeFull() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 1760, 1760, 0.3, 0.13);
    this.osc(t, 'sine', 2640, 2640, 0.24, 0.07);
  }

  zan() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 1.1, 'lowpass', 1300, 0.6, 1.25, 80, 'sfx', 0.004);
    this.osc(t, 'sine', 85, 24, 0.9, 1.1);
    this.osc(t, 'sine', 3000, 2200, 1.3, 0.11);
    this.noise(t, 0.07, 'highpass', 5000, 0.7, 0.7);
  }

  punch(heavy: boolean) {
    if (!this.ctx || !this.throttle('punch', 25)) return;
    const t = this.now;
    this.noise(t, heavy ? 0.16 : 0.09, 'lowpass', heavy ? 900 : 1300, 0.8, heavy ? 1.0 : 0.75);
    this.osc(t, 'sine', heavy ? 120 : 170, 45, heavy ? 0.16 : 0.08, heavy ? 0.9 : 0.6);
    this.noise(t, 0.025, 'highpass', 3500, 0.8, heavy ? 0.5 : 0.3);
  }

  block() {
    if (!this.ctx || !this.throttle('block', 40)) return;
    const t = this.now;
    this.noise(t, 0.08, 'bandpass', 700, 1.2, 0.6);
    this.osc(t, 'sine', 210, 120, 0.07, 0.35);
  }

  parry() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.05, 'highpass', 4200, 0.8, 0.7);
    this.osc(t, 'triangle', 1300, 900, 0.18, 0.2);
    this.osc(t, 'sine', 2600, 2500, 0.4, 0.12);
    this.osc(t, 'sine', 160, 60, 0.12, 0.6);
  }

  cricketCharge() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 280, 2600, 0.32, 0.16);
    this.osc(t, 'square', 140, 1300, 0.32, 0.04, 'sfx', 3000);
    this.noise(t, 0.32, 'highpass', 1500, 1, 0.12, 6000, 'sfx', 0.2);
  }

  cricketBoom() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 1.5, 'lowpass', 1700, 0.6, 1.5, 70, 'sfx', 0.003);
    this.osc(t, 'sine', 95, 20, 1.3, 1.45);
    this.osc(t, 'square', 1500, 60, 0.35, 0.22, 'sfx', 4000);
    this.osc(t, 'sawtooth', 600, 40, 0.5, 0.18, 'sfx', 2000);
    this.noise(t, 0.2, 'bandpass', 3200, 0.9, 0.7);
  }

  slingStretch() {
    if (!this.ctx || !this.throttle('stretch', 300)) return;
    const t = this.now;
    this.osc(t, 'sawtooth', 95, 150, 0.35, 0.05, 'sfx', 700);
    this.noise(t, 0.3, 'bandpass', 900, 3, 0.08, 1400, 'sfx', 0.1);
  }

  thwip(power: number) {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.13, 'bandpass', 1900, 1.2, 0.35 + power * 0.4, 380);
    this.osc(t, 'triangle', 560, 150, 0.11, 0.18 + power * 0.12);
  }

  tok() {
    if (!this.ctx || !this.throttle('tok', 40)) return;
    const t = this.now;
    this.osc(t, 'square', 1500, 900, 0.035, 0.12, 'sfx', 4000);
    this.noise(t, 0.05, 'bandpass', 2600, 2, 0.35);
    this.osc(t, 'sine', 260, 120, 0.06, 0.25);
  }

  bolt() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.05, 'bandpass', 2200, 2, 0.5);
    this.osc(t, 'square', 760, 420, 0.04, 0.07, 'sfx', 2600);
    this.noise(t + 0.16, 0.06, 'bandpass', 1500, 2, 0.6);
    this.osc(t + 0.16, 'square', 520, 300, 0.05, 0.08, 'sfx', 2200);
  }

  swap() {
    if (!this.ctx || !this.throttle('swap', 80)) return;
    const t = this.now;
    this.noise(t, 0.035, 'bandpass', 2600, 2, 0.32);
    this.noise(t + 0.07, 0.04, 'bandpass', 1700, 2, 0.38);
  }

  batHit() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.035, 'highpass', 3000, 0.8, 0.85);
    this.noise(t, 0.22, 'bandpass', 950, 1.1, 1.1);
    this.osc(t, 'triangle', 190, 70, 0.16, 0.7);
    this.osc(t, 'sine', 110, 40, 0.2, 0.8);
  }

  batBreak() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.08, 'highpass', 2600, 0.8, 0.9);
    for (let i = 0; i < 7; i++) {
      this.noise(t + Math.random() * 0.25, 0.04, 'bandpass', 900 + Math.random() * 2400, 3, 0.3);
    }
    this.osc(t, 'triangle', 240, 90, 0.2, 0.4);
  }

  sniperBeep(final: boolean) {
    if (!this.ctx || !this.throttle('sbeep', final ? 0 : 120)) return;
    const t = this.now;
    this.osc(t, 'square', final ? 1760 : 1320, final ? 1760 : 1320, final ? 0.12 : 0.05, 0.05, 'sfx', 4000);
  }

  skid() {
    if (!this.ctx || !this.throttle('skid', 180)) return;
    const t = this.now;
    this.noise(t, 0.2, 'bandpass', 1500, 2, 0.22, 500, 'sfx', 0.01);
  }

  pop() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sine', 2200, 900, 0.08, 0.2);
    this.noise(t, 0.12, 'highpass', 3500, 0.8, 0.5);
    for (let i = 0; i < 4; i++) {
      const f = 3000 + Math.random() * 3000;
      this.osc(t + 0.02 + Math.random() * 0.12, 'sine', f, f * 0.97, 0.08, 0.06);
    }
  }

  doubleJump() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.3, 'bandpass', 500, 1.2, 0.35, 2200, 'sfx', 0.02);
    this.osc(t, 'triangle', 300, 600, 0.15, 0.08);
  }

  pickup() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'square', 660, 660, 0.08, 0.12, 'sfx', 3000);
    this.osc(t + 0.08, 'square', 990, 990, 0.12, 0.12, 'sfx', 3000);
  }

  banana() {
    if (!this.ctx) return;
    const t = this.now;
    [523, 659, 784, 1047].forEach((f, i) => this.osc(t + i * 0.07, 'triangle', f, f, 0.16, 0.18));
  }

  hurt() {
    if (!this.ctx || !this.throttle('hurt', 90)) return;
    const t = this.now;
    this.osc(t, 'sawtooth', 240, 110, 0.16, 0.16, 'sfx', 1500);
    this.noise(t, 0.08, 'lowpass', 800, 0.7, 0.5);
  }

  death() {
    if (!this.ctx) return;
    const t = this.now;
    this.osc(t, 'sawtooth', 330, 55, 1.0, 0.25, 'sfx', 1200);
    this.osc(t, 'sine', 160, 40, 1.2, 0.4);
  }

  reload() {
    if (!this.ctx) return;
    const t = this.now;
    this.noise(t, 0.04, 'highpass', 2500, 1, 0.35);
    this.noise(t + 0.28, 0.05, 'highpass', 1800, 1, 0.4);
    this.osc(t + 0.28, 'square', 900, 500, 0.04, 0.06, 'sfx', 2500);
  }

  land() {
    if (!this.ctx || !this.throttle('land', 120)) return;
    this.noise(this.now, 0.09, 'lowpass', 350, 0.7, 0.35);
  }

  step() {
    if (!this.ctx || !this.throttle('step', 110)) return;
    this.noise(this.now, 0.04, 'lowpass', 900, 0.8, 0.09);
  }

  dodge() {
    if (!this.ctx || !this.throttle('dodge', 70)) return;
    const t = this.now;
    this.noise(t, 0.12, 'bandpass', 2500, 2, 0.18, 900);
  }

  alert() {
    if (!this.ctx || !this.throttle('alert', 150)) return;
    const t = this.now;
    this.osc(t, 'square', 880, 1100, 0.06, 0.05, 'sfx', 3000);
  }

  combo(n: number) {
    if (!this.ctx) return;
    const f = 440 * Math.pow(2, Math.min(n, 12) / 12);
    this.osc(this.now, 'triangle', f, f * 1.5, 0.12, 0.12);
  }

  click() {
    if (!this.ctx) return;
    this.osc(this.now, 'square', 700, 700, 0.04, 0.06, 'sfx', 2500);
  }

  // ------------------------------------------------------------- music
  startMusic() {
    if (!this.ctx || this.musicTimer !== null) return;
    this.nextNote = this.ctx.currentTime + 0.1;
    this.seqStep = 0;
    this.musicTimer = window.setInterval(() => this.schedule(), 25);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  private schedule() {
    if (!this.ctx) return;
    const bpm = this.track === 'story' ? 126 : this.track === 'boss' ? 140 : 132;
    const stepDur = 60 / bpm / 4;
    while (this.nextNote < this.ctx.currentTime + 0.14) {
      this.playStep(this.seqStep, this.nextNote);
      this.nextNote += stepDur;
      this.seqStep = (this.seqStep + 1) % 128;
    }
  }

  private playStep(s: number, t: number) {
    if (!this.musicOn) return;
    const bar = Math.floor(s / 16) % 4;
    const st = s % 16;
    const section = Math.floor(s / 64);
    // drums
    if (st % 4 === 0) {
      this.osc(t, 'sine', 155, 42, 0.22, 0.95, 'music');
      this.noise(t, 0.02, 'lowpass', 3000, 0.7, 0.2, 0, 'music');
    }
    if (st === 4 || st === 12) {
      this.noise(t, 0.16, 'bandpass', 1700, 0.9, 0.42, 0, 'music');
      this.noise(t + 0.012, 0.12, 'bandpass', 1300, 0.9, 0.25, 0, 'music');
    }
    if (st % 2 === 1) this.noise(t, 0.035, 'highpass', 8000, 0.7, 0.14, 0, 'music');
    if (st % 4 === 2) this.noise(t, 0.12, 'highpass', 7000, 0.7, 0.12, 0, 'music');
    // bass (A minor progression: Am F C G)
    const roots = this.track === 'pedro' ? [0, 5, 3, -2] : this.track === 'boss' ? [0, 1, -2, -4] : [0, -4, 3, -2];
    if (this.track === 'boss' && (st === 7 || st === 14)) this.osc(t, 'sine', 150, 42, 0.18, 0.7, 'music');
    if (this.track === 'pedro' && st % 4 === 3) {
      const fb = 880 * Math.pow(2, (roots[bar] + [0, 7, 12, 7][(st >> 2) % 4]) / 12);
      this.osc(t, 'triangle', fb, fb, 0.22, 0.05, 'music');
    }
    const pat = [0, -99, 0, 12, -99, 0, 10, -99, 0, -99, 0, 12, 7, -99, 5, 3];
    const n = pat[st];
    if (n !== -99) {
      const f = 55 * Math.pow(2, (roots[bar] + n) / 12);
      this.osc(t, 'sawtooth', f, f, 0.18, 0.22, 'music', 520);
      this.osc(t, 'square', f / 2, f / 2, 0.16, 0.1, 'music', 300);
    }
    // arp
    if (this.track !== 'story' || section === 1 || bar >= 2) {
      const chord = [0, 3, 7, 12, 7, 3, 0, 7];
      const third = roots[bar] === -4 || roots[bar] === 3 ? 4 : 3;
      const off = chord[st % 8] === 3 ? third : chord[st % 8];
      if (st % 2 === 0) {
        const f = 220 * Math.pow(2, (roots[bar] + off) / 12);
        this.osc(t, 'square', f, f, 0.11, 0.045, 'music', 2600);
      }
    }
    // stab
    if (st === 0 && (section === 1 || this.track === 'boss')) {
      const f = 440 * Math.pow(2, roots[bar] / 12);
      this.osc(t, 'sawtooth', f, f, 0.4, 0.05, 'music', 1800);
      this.osc(t, 'sawtooth', f * 1.5, f * 1.5, 0.4, 0.04, 'music', 1800);
    }
  }

  destroy() {
    this.laserHum(false);
    this.stopMusic();
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
