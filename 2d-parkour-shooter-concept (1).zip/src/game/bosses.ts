import { drawCharacter, reachArm, type Dims, type Look, type Pose, type WorldPose } from './character';
import { Enemy, type EnemyHost } from './enemy';
import type { Hazards } from './hazards';
import type { EnemyDef, LevelDef } from './level';
import { approach, clamp, rand, sign, TAU, weightedPick, wrapAngle, type Rect } from './math';
import type { Particles } from './particles';
import type { Sound } from './audio';
import { drawPedroBoss, PedroBoss } from './pedro';

export type BossId = 'jagal' | 'kumis' | 'pedro';

export interface BossHost extends EnemyHost {
  particles: Particles;
  hazards: Hazards;
  bossIntro: number;
  readonly arenaRect: Rect;
  shake(a: number): void;
  camKick(x: number, y: number): void;
  stamp(text: string, x: number, y: number, color: string, size?: number, burst?: string): void;
  popup(text: string, x: number, y: number, color: string): void;
  hurtPlayer(dmg: number, dirx: number, knock: number): boolean;
  spawnGoon(x: number, dir: number): void;
  goonCount(): number;
  say(e: Enemy, text: string, dur: number): void;
  finishBoss(e: Enemy): void;
  setDreamPhase(n: number): void;
  enemyShoot(x: number, y: number, angle: number, speed: number, dmg: number): void;
}

export interface BossInfo {
  id: BossId;
  name: string;
  title: string;
  arena: string;
  desc: string;
  attacks: string[];
  tip: string;
  stars: number;
  color: string;
  par: number;
}

export const BOSS_ORDER: BossId[] = ['jagal', 'kumis', 'pedro'];

export const BOSS_INFO: Record<BossId, BossInfo> = {
  jagal: {
    id: 'jagal',
    name: 'SI JAGAL',
    title: 'TUKANG DAGING GILA',
    arena: 'RUANG PENDINGIN',
    desc: 'Raksasa bercelemek berdarah yang mengamuk dengan golok raksasa.',
    attacks: ['Lempar golok berputar', 'Seruduk banteng', 'Hantaman gempa (fase 2)'],
    tip: 'Tembak goloknya di udara! Biarkan dia menyeruduk dinding, lalu hajar saat dia pusing.',
    stars: 1,
    color: '#ff4d4d',
    par: 80,
  },
  kumis: {
    id: 'kumis',
    name: 'DON KUMIS',
    title: 'RAJA MAFIA',
    arena: 'PENTHOUSE MEWAH',
    desc: 'Bos mafia licik: shotgun, dinamit, tommy gun, dan pasukan anak buah.',
    attacks: ['Shotgun & tommy gun', 'Lempar dinamit', 'Panggil anak buah'],
    tip: 'Tembak dinamitnya di udara. Jatuhkan LAMPU KRISTAL tepat ke kepalanya!',
    stars: 2,
    color: '#ffd23f',
    par: 100,
  },
  pedro: {
    id: 'pedro',
    name: 'PEDRO',
    title: 'PISANG DARI ALAM MIMPI',
    arena: 'ALAM MIMPI',
    desc: 'Sahabatmu sendiri... atau bukan? Pedro raksasa dengan laser mata dan hujan pisang.',
    attacks: ['Laser mata', 'Hujan pisang & mini Pedro', 'Seruduk raksasa'],
    tip: 'Tekan SPACE (berputar) untuk menembus laser. Tembak MATANYA untuk damage besar!',
    stars: 3,
    color: '#c77dff',
    par: 120,
  },
};

// ------------------------------------------------------------------ records
export interface BossRecord {
  wins: number;
  bestTime: number;
  bestRank: string;
  bestScore: number;
}

const REC_KEY = 'sobatku-pedro-boss-v1';
const RANKS = ['D', 'C', 'B', 'A', 'S'];

export function loadBossRecords(): Partial<Record<BossId, BossRecord>> {
  try {
    const raw = localStorage.getItem(REC_KEY);
    return raw ? (JSON.parse(raw) as Partial<Record<BossId, BossRecord>>) : {};
  } catch {
    return {};
  }
}

export function saveBossRecord(id: BossId, time: number, rank: string, score: number) {
  try {
    const all = loadBossRecords();
    const r = all[id] ?? { wins: 0, bestTime: 0, bestRank: 'D', bestScore: 0 };
    r.wins++;
    if (!r.bestTime || time < r.bestTime) r.bestTime = time;
    if (RANKS.indexOf(rank) > RANKS.indexOf(r.bestRank)) r.bestRank = rank;
    if (score > r.bestScore) r.bestScore = score;
    all[id] = r;
    localStorage.setItem(REC_KEY, JSON.stringify(all));
  } catch {
    /* storage unavailable */
  }
}

// ------------------------------------------------------------------ shared fx
function drawStars(ctx: CanvasRenderingContext2D, x: number, y: number, t: number) {
  for (let i = 0; i < 3; i++) {
    const a = t * 5 + (i * TAU) / 3;
    const sx = x + Math.cos(a) * 18;
    const sy = y + Math.sin(a) * 6;
    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(t * 4 + i);
    ctx.fillStyle = '#ffd23f';
    ctx.strokeStyle = '#1b1410';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    for (let k = 0; k < 10; k++) {
      const r = k % 2 === 0 ? 6 : 2.6;
      const aa = (k / 10) * TAU - Math.PI / 2;
      if (k === 0) ctx.moveTo(Math.cos(aa) * r, Math.sin(aa) * r);
      else ctx.lineTo(Math.cos(aa) * r, Math.sin(aa) * r);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
}

function glow(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, rgb: string, a: number) {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, `rgba(${rgb},${a})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
  ctx.restore();
}

// ================================================================== SI JAGAL
export const JAGAL_LOOK: Look = {
  kid: false,
  boss: false,
  skin: '#e2a878',
  skinShade: '#c58856',
  hair: '#2b1d14',
  shirt: '#e9e4d6',
  shirtShade: '#c9c1ad',
  jacket: '#e9e4d6',
  jacketShade: '#c9c1ad',
  tie: '#e9e4d6',
  pants: '#3b3d45',
  pantsShade: '#2a2c33',
  shoe: '#3a2717',
  shoeShade: '#2a1c10',
  sole: '#140d08',
  hat: false,
  hatColor: '',
  hatBand: '',
  glasses: false,
  mustache: 2,
  outline: '#1b1410',
  bald: true,
  beard: true,
  apron: true,
  noTie: true,
  tankTop: true,
};

export const JAGAL_DIMS: Dims = {
  thigh: 26,
  shin: 25,
  torso: 33,
  neck: 4,
  headR: 11,
  upper: 19,
  fore: 18,
  wThigh: 14,
  wShin: 11,
  wUpper: 11.5,
  wFore: 9.5,
  torsoTop: 29,
  torsoBot: 33,
  foot: 14,
};

type JAct = 'intro' | 'walk' | 'throw' | 'chargeWind' | 'charge' | 'dizzy' | 'slamUp' | 'slamFall' | 'recover' | 'roar';

export class JagalBoss extends Enemy {
  act: JAct = 'intro';
  actT = 0;
  phase = 1;
  pendingPhase = 0;
  nextAtk = 1.2;
  last: JAct[] = [];
  thrown = false;
  chargeDir = 1;
  chargeHit = false;
  chargesLeft = 0;
  dizzyDur = 2;
  stunImmune = 0;
  shoveCd = 0;
  stepAcc = 0;

  constructor(def: EnemyDef) {
    super(def);
    this.isBossMode = true;
    this.look = JAGAL_LOOK;
    this.dims = JAGAL_DIMS;
    this.maxHp = 170;
    this.hp = 170;
    this.hpShown = 170;
    this.w = 40;
    this.h = 114;
    this.gun = 'cleaver';
    this.bossName = BOSS_INFO.jagal.name;
    this.bossTitle = BOSS_INFO.jagal.title;
    this.phaseMarks = [0.55, 0.25];
    this.state = 'alert';
    this.pose.py = -50;
  }

  get spd() {
    return this.phase === 1 ? 1 : this.phase === 2 ? 1.18 : 1.34;
  }

  private setAct(a: JAct) {
    this.act = a;
    this.actT = 0;
    this.thrown = false;
  }

  private endAttack() {
    this.setAct('walk');
    this.nextAtk = rand(0.9, 1.7) / this.spd;
  }

  portraitPose() {
    this.act = 'intro';
    for (let i = 0; i < 45; i++) this.animate(1 / 30, 0);
  }

  hurt(dmg: number, dirx: number, head: boolean, time: number, sfx: Sound) {
    if (this.act === 'intro') return false;
    const dead = super.hurt(this.act === 'dizzy' ? dmg * 1.6 : dmg, dirx, head, time, sfx);
    const k = this.hp / this.maxHp;
    if (!dead) {
      if (this.phase === 1 && k <= this.phaseMarks[0]) this.pendingPhase = 2;
      else if (this.phase === 2 && k <= this.phaseMarks[1]) this.pendingPhase = 3;
    }
    return dead;
  }

  stunFor(t: number, _vx: number, _vy: number) {
    if (this.stunImmune > 0 || this.act === 'dizzy' || this.act === 'intro') return;
    this.dizzyDur = clamp(t, 0.5, 1.3);
    this.chargesLeft = 0;
    this.setAct('dizzy');
  }

  protected bossUpdate(dt: number, hostE: EnemyHost): boolean {
    const host = hostE as BossHost;
    const p = host.player;
    this.animT += dt;
    this.hitT -= dt;
    this.actT += dt;
    this.shoveCd -= dt;
    this.stunImmune -= dt;
    this.recoil = Math.max(0, this.recoil - dt * 7);
    this.hpShown = approach(this.hpShown, this.hp, dt * 18);
    const dx = p.x - this.x;
    let move = 0;
    let speed = 0;
    if (host.bossIntro > 0 && this.act !== 'intro') this.setAct('intro');
    if (this.pendingPhase && this.act !== 'charge' && this.act !== 'slamUp' && this.act !== 'slamFall') {
      this.phase = this.pendingPhase;
      this.pendingPhase = 0;
      this.chargesLeft = 0;
      this.setAct('roar');
      this.stunImmune = 2;
      host.sfx.roar();
      host.shake(12);
      host.stamp(this.phase === 2 ? 'MARAH!' : 'MENGAMUK!', this.x, this.y - this.h - 40, '#ffffff', 46, '#ff4d4d');
      host.say(this, this.phase === 2 ? 'KUCINCANG KAU, BOCAH!' : 'GRAAAAHHH!!', 1.8);
    }
    switch (this.act) {
      case 'intro':
        this.facing = dx >= 0 ? 1 : -1;
        if (host.bossIntro <= 0) {
          this.endAttack();
          host.say(this, 'Daging segar... HAHAHA!', 1.8);
        }
        break;
      case 'walk': {
        this.facing = dx >= 0 ? 1 : -1;
        const adx = Math.abs(dx);
        move = adx > 260 ? sign(dx) : adx < 110 ? -sign(dx) : 0;
        speed = 140 * this.spd;
        if (this.actT > this.nextAtk && p.alive) this.pickAttack(host);
        break;
      }
      case 'throw': {
        const wind = 0.5 / this.spd;
        if (!this.thrown && this.actT >= wind) {
          this.thrown = true;
          this.throwCleavers(host);
        }
        if (this.actT > wind + 0.45) this.endAttack();
        break;
      }
      case 'chargeWind': {
        const wind = 0.85 / Math.sqrt(this.spd);
        if (this.actT < wind * 0.5) this.facing = dx >= 0 ? 1 : -1;
        if (Math.random() < 0.3) host.particles.dust(this.x - this.facing * 16, this.y, 1, -this.facing);
        if (this.actT > wind) {
          this.setAct('charge');
          this.chargeDir = this.facing;
          this.chargeHit = false;
          host.sfx.roar();
          host.shake(5);
        }
        break;
      }
      case 'charge': {
        move = this.chargeDir;
        speed = 780 + 300 * (this.spd - 1);
        if (Math.random() < 0.7) host.particles.dust(this.x - this.chargeDir * 18, this.y, 1, -this.chargeDir);
        this.stepAcc += dt;
        if (this.stepAcc > 0.13) {
          this.stepAcc = 0;
          host.sfx.stampede();
          host.shake(2.5);
        }
        if (
          !this.chargeHit &&
          p.alive &&
          Math.abs(p.x - this.x) < this.w / 2 + p.w / 2 + 6 &&
          p.y > this.y - this.h &&
          p.y - p.h < this.y
        ) {
          this.chargeHit = true;
          if (host.hurtPlayer(26, this.chargeDir, 640)) {
            host.camKick(this.chargeDir * 12, -4);
            host.shake(10);
            host.stamp('BRUAKK!', p.x, p.y - 110, '#ffffff', 40, '#ff4d4d');
            host.sfx.hit(false);
          } else if (p.dodging) host.popup('MELESET!', p.x, p.y - 110, '#9fe8ff');
        }
        if (this.actT > 2.6) this.endAttack();
        break;
      }
      case 'dizzy':
        if (this.actT > this.dizzyDur) {
          this.stunImmune = 1.5;
          if (this.chargesLeft > 0) {
            this.chargesLeft--;
            this.setAct('chargeWind');
          } else this.endAttack();
        }
        break;
      case 'slamUp':
        if (this.vy > 0) this.act = 'slamFall';
        break;
      case 'slamFall':
        break;
      case 'recover':
        if (this.actT > 0.55 / this.spd) this.endAttack();
        break;
      case 'roar':
        if (this.actT > 1.1) this.endAttack();
        break;
    }
    if (this.act === 'charge') this.vx = move * speed;
    else if (this.act === 'slamUp' || this.act === 'slamFall') {
      /* ballistic */
    } else if (this.act === 'dizzy') this.vx = approach(this.vx, 0, 1600 * dt);
    else this.vx = approach(this.vx, move * speed, 1300 * dt);
    const wasAir = !this.onGround;
    this.physics(dt, host.world);
    if (this.act === 'charge' && this.res.hitX !== 0) this.wallImpact(host);
    else if (this.act === 'walk' && this.res.hitX !== 0 && this.onGround && move !== 0) {
      if (host.world.rectFree(this.x + move * 34 - 10, this.y - this.h - 20, 20, this.h - 50)) this.vy = -720;
    }
    if ((this.act === 'slamFall' || this.act === 'slamUp') && this.onGround && wasAir) this.slamLand(host);
    if (
      this.act !== 'charge' &&
      this.act !== 'intro' &&
      this.shoveCd <= 0 &&
      p.alive &&
      Math.abs(p.x - this.x) < this.w / 2 + p.w / 2 - 2 &&
      p.y > this.y - this.h + 10 &&
      p.y - p.h < this.y - 10
    ) {
      this.shoveCd = 0.9;
      if (host.hurtPlayer(8, sign(p.x - this.x) || 1, 380)) host.sfx.thud();
    }
    this.animate(dt, move);
    return true;
  }

  private pickAttack(host: BossHost) {
    const p = host.player;
    const above = p.y < this.y - 90;
    const opts: [JAct, number][] = [
      ['throw', above ? 2.2 : 1],
      ['chargeWind', above ? 0.25 : 1.2],
    ];
    if (this.phase >= 2) opts.push(['slamUp', above ? 0.6 : 1]);
    const pick = weightedPick(opts, this.last);
    this.last.unshift(pick);
    if (this.last.length > 3) this.last.pop();
    if (pick === 'slamUp') {
      this.startSlam(host);
      return;
    }
    if (pick === 'chargeWind') {
      this.chargesLeft = this.phase === 3 ? 1 : 0;
      host.stamp('!!', this.x, this.y - this.h - 30, '#ffffff', 36, '#ff4d4d');
      host.sfx.alert();
    }
    this.setAct(pick);
  }

  private throwCleavers(host: BossHost) {
    const p = host.player;
    const h = this.wp.haF;
    const sx = h.x;
    const sy = h.y - 10;
    const n = this.phase === 1 ? 1 : 3;
    const tx0 = p.x + p.vx * 0.35;
    const ty0 = p.y - p.h * 0.55;
    const G = 1500;
    for (let i = 0; i < n; i++) {
      const tx = tx0 + (n > 1 ? (i - 1) * 110 : 0);
      const T = clamp(Math.abs(tx - sx) / 720, 0.42, 1.05) * (n > 1 ? [0.85, 1, 1.18][i] : 1);
      const vx = (tx - sx) / T;
      const vy = (ty0 - sy - 0.5 * G * T * T) / T;
      host.hazards.add({ kind: 'cleaver', x: sx, y: sy, vx, vy, vr: (sign(vx) || 1) * 18, dmg: 18, life: 3 });
    }
    host.sfx.cleaver();
  }

  private wallImpact(host: BossHost) {
    const fx = this.x + this.chargeDir * (this.w / 2 + 4);
    const fy = this.y - this.h * 0.6;
    host.shake(16);
    host.camKick(this.chargeDir * 10, 0);
    host.particles.debris(fx, fy, 18, '#77736c', 1.2, true);
    host.particles.dust(fx, this.y, 10, -this.chargeDir);
    host.particles.spawn({ kind: 'ring', x: fx, y: fy, life: 0.35, size: 90, color: '#ffffff' });
    host.sfx.slam();
    host.stamp('DUAKK!', fx - this.chargeDir * 30, fy - 30, '#ffffff', 44, '#ff7b3a');
    this.vx = -this.chargeDir * 160;
    this.vy = -260;
    this.dizzyDur = this.phase === 3 && this.chargesLeft > 0 ? 0.7 : 2.0;
    this.setAct('dizzy');
    host.popup('PUSING! TEMBAK!', this.x, this.y - this.h - 50, '#ffd23f');
  }

  private startSlam(host: BossHost) {
    const p = host.player;
    const A = host.arenaRect;
    this.setAct('slamUp');
    const T = 0.85;
    const tx = clamp(p.x, A.x + 80, A.x + A.w - 80);
    this.vx = (tx - this.x) / T;
    this.vy = -950;
    this.onGround = false;
    this.facing = sign(tx - this.x) || this.facing;
    host.sfx.whoosh(0.4);
    host.particles.dust(this.x, this.y, 10, 0);
    host.say(this, 'HYAAAH!', 1);
  }

  private slamLand(host: BossHost) {
    const p = host.player;
    this.vx = 0;
    host.shake(18);
    host.camKick(0, 14);
    host.sfx.slam();
    host.particles.spawn({ kind: 'shock', x: this.x, y: this.y, life: 0.5, size: 260, color: '#ffffff' });
    host.particles.spawn({ kind: 'ring', x: this.x, y: this.y - 6, life: 0.35, size: 110, color: '#ffffff' });
    host.particles.addDecal({ x: this.x, y: this.y - 1, w: 60, h: 8, rot: Math.floor(Math.random() * 1e6) + 1, color: '#000', kind: 'crack' });
    host.particles.dust(this.x - 14, this.y, 12, -1);
    host.particles.dust(this.x + 14, this.y, 12, 1);
    host.particles.debris(this.x, this.y - 4, 14, '#77736c', 0.9);
    host.stamp('GEMPA!', this.x, this.y - this.h - 50, '#ffffff', 42, '#3a9bff');
    for (const d of [-1, 1]) host.hazards.add({ kind: 'wave', x: this.x + d * 30, y: this.y, dir: d, dmg: 20, life: 2.4 });
    if (p.alive && p.onGround && Math.abs(p.x - this.x) < 70 && Math.abs(p.y - this.y) < 30) {
      host.hurtPlayer(22, sign(p.x - this.x) || 1, 520);
    }
    this.setAct('recover');
  }

  protected poseHook(T: Pose, _dt: number): number {
    const t = this.animT;
    T.py += 2;
    switch (this.act) {
      case 'intro':
      case 'roar': {
        const k = this.act === 'roar' ? Math.min(1, this.actT * 4) : 0.6 + Math.sin(t * 3) * 0.1;
        T.torso = -0.25 * k;
        T.head = -0.35 * k;
        T.fx = 12;
        T.bx = -12;
        return 18;
      }
      case 'throw': {
        if (this.actT < 0.5 / this.spd) {
          T.torso = -0.3;
          T.head = 0.1;
        } else {
          T.torso = 0.45;
          T.head = -0.2;
        }
        T.fx = 16;
        T.bx = -12;
        return 26;
      }
      case 'chargeWind': {
        const st = Math.sin(this.actT * 22);
        T.py += 10;
        T.torso = 0.75;
        T.head = -0.6;
        T.fx = 14 + st * 4;
        T.bx = -16;
        T.fy = -3 - Math.max(0, st) * 8;
        return 30;
      }
      case 'charge':
        T.torso = 0.85;
        T.head = -0.7;
        T.py += 4;
        return 30;
      case 'dizzy': {
        const s = Math.sin(t * 6);
        T.torso = 0.25 + s * 0.25;
        T.head = 0.5 * Math.sin(t * 4.3);
        T.fx = 10 + s * 5;
        T.bx = -10 + s * 5;
        T.py += 6;
        return 14;
      }
      case 'slamUp':
      case 'slamFall':
        T.torso = -0.15;
        T.head = -0.2;
        T.fx = 14;
        T.fy = -26;
        T.bx = -6;
        T.by = -22;
        return 24;
      case 'recover':
        T.py += 16;
        T.torso = 0.7;
        T.head = -0.5;
        T.fx = 18;
        T.bx = -18;
        return 30;
      default:
        return 0;
    }
  }

  protected armHook(wp: WorldPose) {
    const f = this.facing;
    const d = this.dims;
    const sh = wp.shF;
    const sb = wp.shB;
    wp.gunF = 'cleaver';
    wp.gunB = null;
    wp.angry = true;
    wp.flashF = 0;
    wp.slideF = 0;
    let ang: number;
    switch (this.act) {
      case 'throw': {
        if (this.actT < 0.5 / this.spd) {
          reachArm(sh, sh.x - f * 12, sh.y - 26, d, -f, wp.elF, wp.haF);
          ang = f > 0 ? -2.3 : -0.84;
        } else {
          reachArm(sh, sh.x + f * 30, sh.y + 6, d, f, wp.elF, wp.haF);
          ang = f > 0 ? 0.3 : Math.PI - 0.3;
          if (this.thrown) wp.gunF = null;
        }
        reachArm(sb, sb.x + f * 20, sb.y + 10, d, f, wp.elB, wp.haB);
        break;
      }
      case 'intro':
      case 'roar':
        reachArm(sh, sh.x + f * 18, sh.y - 30, d, f, wp.elF, wp.haF);
        reachArm(sb, sb.x - f * 18, sb.y - 26, d, -f, wp.elB, wp.haB);
        ang = f > 0 ? -1.2 : Math.PI + 1.2;
        break;
      case 'slamUp':
      case 'slamFall':
        reachArm(sh, sh.x + f * 6, sh.y - 32, d, f, wp.elF, wp.haF);
        reachArm(sb, sb.x + f * 2, sb.y - 32, d, -f, wp.elB, wp.haB);
        ang = f > 0 ? -1.4 : Math.PI + 1.4;
        break;
      case 'charge':
      case 'chargeWind':
        reachArm(sh, sh.x - f * 14, sh.y + 24, d, f, wp.elF, wp.haF);
        reachArm(sb, sb.x - f * 20, sb.y + 18, d, f, wp.elB, wp.haB);
        ang = f > 0 ? 2.3 : Math.PI - 2.3;
        break;
      case 'dizzy': {
        const s = Math.sin(this.animT * 7);
        reachArm(sh, sh.x + f * (10 + s * 8), sh.y + 20 - s * 10, d, f, wp.elF, wp.haF);
        reachArm(sb, sb.x - f * (8 - s * 8), sb.y + 18 + s * 10, d, f, wp.elB, wp.haB);
        ang = f > 0 ? 1.2 + s * 0.4 : Math.PI - 1.2 - s * 0.4;
        break;
      }
      default: {
        const sway = Math.sin(this.animT * 3) * 4;
        reachArm(sh, sh.x + f * 16, sh.y + 26 + sway, d, f, wp.elF, wp.haF);
        reachArm(sb, sb.x - f * 6, sb.y + 30 - sway, d, f, wp.elB, wp.haB);
        ang = f > 0 ? 0.55 : Math.PI - 0.55;
      }
    }
    wp.aimF = ang;
  }

  drawOverlay(ctx: CanvasRenderingContext2D, t: number): void {
    const hx = this.wp.head.x;
    const hy = this.wp.head.y;
    if (this.act === 'dizzy') drawStars(ctx, hx, hy - 18, t);
    if (this.act === 'chargeWind') glow(ctx, this.x, this.y - 57, 85, '255,40,40', 0.25 + Math.abs(Math.sin(t * 12)) * 0.25);
    if (this.act === 'charge') {
      ctx.strokeStyle = 'rgba(255,255,255,0.55)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const yy = this.y - 20 - i * 24;
        ctx.moveTo(this.x - this.chargeDir * 30, yy);
        ctx.lineTo(this.x - this.chargeDir * (80 + ((i * 37) % 40)), yy);
      }
      ctx.stroke();
    }
    if (this.phase >= 2 && this.act !== 'dizzy') {
      // anger vein on the bald head
      const vx = hx - this.facing * 2;
      const vy = hy - 9;
      ctx.strokeStyle = '#d62828';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(vx - 3, vy - 1);
      ctx.quadraticCurveTo(vx, vy - 4, vx + 3, vy - 1);
      ctx.moveTo(vx - 3, vy + 2);
      ctx.quadraticCurveTo(vx, vy + 5, vx + 3, vy + 2);
      ctx.stroke();
    }
  }
}

// ================================================================== DON KUMIS
type KAct = 'intro' | 'move' | 'shotgun' | 'grenade' | 'summon' | 'tommy' | 'roll' | 'stagger' | 'roar';

export class KumisBoss extends Enemy {
  act: KAct = 'intro';
  actT = 0;
  phase = 1;
  pendingPhase = 0;
  nextAtk = 1.4;
  last: KAct[] = [];
  shots = 0;
  shotT = 0;
  thrown = false;
  summonCd = 7;
  rollCd = 2;
  rollDir = 1;
  sprayA = 0;
  sprayDir = 1;
  danger = 0;
  staggerDur = 0.8;

  constructor(def: EnemyDef) {
    super(def);
    this.isBossMode = true;
    this.maxHp = 190;
    this.hp = 190;
    this.hpShown = 190;
    this.bossName = BOSS_INFO.kumis.name;
    this.bossTitle = BOSS_INFO.kumis.title;
    this.phaseMarks = [0.6, 0.3];
    this.state = 'alert';
    this.gun = 'shotgun';
  }

  get spd() {
    return this.phase === 1 ? 1 : this.phase === 2 ? 1.15 : 1.3;
  }

  private setAct(a: KAct) {
    this.act = a;
    this.actT = 0;
    this.thrown = false;
  }

  private endAttack() {
    this.bodyRot = 0;
    this.gun = 'shotgun';
    this.setAct('move');
    this.nextAtk = rand(0.8, 1.5) / this.spd;
  }

  portraitPose() {
    this.act = 'intro';
    this.aim = -0.3;
    for (let i = 0; i < 45; i++) this.animate(1 / 30, 0);
  }

  hurt(dmg: number, dirx: number, head: boolean, time: number, sfx: Sound) {
    if (this.invuln > 0 || this.act === 'intro') return false;
    const dead = super.hurt(dmg, dirx, head, time, sfx);
    this.danger += 0.25;
    const k = this.hp / this.maxHp;
    if (!dead) {
      if (this.phase === 1 && k <= this.phaseMarks[0]) this.pendingPhase = 2;
      else if (this.phase === 2 && k <= this.phaseMarks[1]) this.pendingPhase = 3;
    }
    return dead;
  }

  stunFor(t: number, _vx: number, _vy: number) {
    if (this.act === 'roll' || this.act === 'intro' || this.act === 'stagger') return;
    this.staggerDur = clamp(t, 0.4, 1.0);
    this.gun = 'shotgun';
    this.bodyRot = 0;
    this.setAct('stagger');
  }

  protected bossUpdate(dt: number, hostE: EnemyHost): boolean {
    const host = hostE as BossHost;
    const p = host.player;
    this.animT += dt;
    this.hitT -= dt;
    this.actT += dt;
    this.summonCd -= dt;
    this.rollCd -= dt;
    this.invuln -= dt;
    this.danger = Math.max(0, this.danger - dt * 0.6);
    this.recoil = Math.max(0, this.recoil - dt * 7);
    this.flash = Math.max(0, this.flash - dt);
    this.hpShown = approach(this.hpShown, this.hp, dt * 20);
    const dx = p.x - this.x;
    const sh = this.wp.shF;
    const want = Math.atan2(p.y - p.h * 0.6 - sh.y, p.x - sh.x);
    if (this.act !== 'tommy') this.aim += clamp(wrapAngle(want - this.aim), -3.4 * dt, 3.4 * dt);
    this.seen = false;
    this.reaction = 1;
    this.fireCd = 1;
    if (host.bossIntro > 0 && this.act !== 'intro') this.setAct('intro');
    if (this.pendingPhase && (this.act === 'move' || this.act === 'stagger')) {
      this.phase = this.pendingPhase;
      this.pendingPhase = 0;
      this.setAct('roar');
      host.sfx.roar();
      host.shake(10);
      host.stamp(this.phase === 2 ? 'DON MURKA!' : 'HABISI DIA!', this.x, this.y - this.h - 40, '#ffffff', 42, '#ffd23f');
      host.say(this, this.phase === 2 ? 'Cukup main-mainnya, bocah!' : 'Kalian semua, HABISI DIA!', 2);
      if (this.phase === 3) this.summonCd = 0;
    }
    let move = 0;
    let speed = 0;
    switch (this.act) {
      case 'intro':
        this.facing = dx >= 0 ? 1 : -1;
        if (host.bossIntro <= 0) {
          this.endAttack();
          host.say(this, 'Selamat datang di rumahku... bocah.', 2);
        }
        break;
      case 'move': {
        this.facing = dx >= 0 ? 1 : -1;
        const adx = Math.abs(dx);
        move = adx > 500 ? sign(dx) : adx < 270 ? -sign(dx) : 0;
        if (move !== 0 && !this.groundAhead(host.world, move)) move = 0;
        speed = 150 * this.spd;
        if (this.danger > 0.7 && this.rollCd <= 0) {
          this.startRoll(host);
          break;
        }
        if (this.actT > this.nextAtk && p.alive) this.pickAttack(host);
        break;
      }
      case 'shotgun': {
        this.facing = dx >= 0 ? 1 : -1;
        this.seen = true;
        this.reaction = 0;
        this.shotT -= dt;
        this.fireCd = Math.max(0, this.shotT);
        if (this.shotT <= 0) {
          this.fire(host);
          host.shake(3);
          this.shots--;
          if (this.shots <= 0) {
            this.endAttack();
            break;
          }
          this.shotT = this.phase === 3 ? 0.55 : 0.72;
        }
        break;
      }
      case 'grenade':
        this.facing = dx >= 0 ? 1 : -1;
        if (!this.thrown && this.actT >= 0.45) {
          this.thrown = true;
          this.throwDynamite(host);
        }
        if (this.actT > 0.9) this.endAttack();
        break;
      case 'summon': {
        if (!this.thrown && this.actT >= 0.55) {
          this.thrown = true;
          host.sfx.whistle();
          const A = host.arenaRect;
          host.spawnGoon(A.x + 50, 1);
          host.spawnGoon(A.x + A.w - 50, -1);
          host.stamp('ANAK BUAH!', this.x, this.y - this.h - 40, '#ffffff', 36, '#3a9bff');
          this.summonCd = this.phase === 1 ? 18 : 13;
        }
        if (this.actT > 1.1) this.endAttack();
        break;
      }
      case 'tommy': {
        this.gun = 'tommy';
        if (this.actT < 0.55) {
          this.aim = this.sprayA;
          this.seen = true;
          this.reaction = 0;
          this.fireCd = 0.1;
        } else {
          this.sprayA += this.sprayDir * 0.95 * dt;
          this.aim = this.sprayA;
          this.shotT -= dt;
          if (this.shotT <= 0) {
            this.fire(host);
            this.shotT = 0.075;
          }
        }
        if (this.actT > 0.55 + 1.5) this.endAttack();
        break;
      }
      case 'roll':
        move = this.rollDir;
        speed = 540;
        this.bodyRot = clamp(this.actT / 0.5, 0, 1) * TAU * (this.rollDir === this.facing ? 1 : -1);
        if (this.actT > 0.5) this.endAttack();
        break;
      case 'stagger':
        if (this.actT > this.staggerDur) this.endAttack();
        break;
      case 'roar':
        if (this.actT > 1.1) this.endAttack();
        break;
    }
    if (this.act === 'roll') this.vx = move * speed;
    else if (this.act === 'stagger') this.vx = approach(this.vx, 0, 1500 * dt);
    else this.vx = approach(this.vx, move * speed, 1200 * dt);
    this.physics(dt, host.world);
    if (this.act === 'roll' && this.res.hitX !== 0) this.endAttack();
    this.animate(dt, move);
    return true;
  }

  private startRoll(host: BossHost) {
    const dx = host.player.x - this.x;
    let dir = Math.random() < 0.75 ? -sign(dx) || 1 : sign(dx) || 1;
    if (!this.groundAhead(host.world, dir)) dir = -dir;
    this.rollDir = dir;
    this.invuln = 0.5;
    this.rollCd = this.phase === 1 ? 3.2 : 2.4;
    this.danger = 0;
    this.setAct('roll');
    host.sfx.whoosh(0.3);
    host.particles.dust(this.x, this.y, 6, -dir);
  }

  private pickAttack(host: BossHost) {
    const opts: [KAct, number][] = [
      ['shotgun', 1.4],
      ['grenade', 0.9],
    ];
    if (this.summonCd <= 0 && host.goonCount() < 2) opts.push(['summon', 2.0]);
    if (this.phase >= 2) opts.push(['tommy', 1.2]);
    const pick = weightedPick(opts, this.last);
    this.last.unshift(pick);
    if (this.last.length > 3) this.last.pop();
    this.setAct(pick);
    const p = host.player;
    if (pick === 'shotgun') {
      this.shots = this.phase === 1 ? 2 : 3;
      this.shotT = 0.62;
    } else if (pick === 'tommy') {
      const sh = this.wp.shF;
      const want = Math.atan2(p.y - p.h * 0.6 - sh.y, p.x - sh.x);
      this.facing = p.x >= this.x ? 1 : -1;
      this.sprayA = want + 0.5 * this.facing;
      this.sprayDir = -this.facing;
      this.shotT = 0;
      host.say(this, 'Rasakan TOMMY GUN-ku!', 1.4);
    } else if (pick === 'summon') host.say(this, 'Anak-anak, kemari!', 1.4);
  }

  private throwDynamite(host: BossHost) {
    const p = host.player;
    const h = this.wp.haF;
    const n = this.phase === 1 ? 1 : this.phase === 2 ? 2 : 3;
    for (let i = 0; i < n; i++) {
      const tx = p.x + p.vx * 0.3 + (i - (n - 1) / 2) * 130;
      const ty = p.y - 10;
      const T = clamp(Math.abs(tx - h.x) / 620, 0.55, 1.1);
      const vx = (tx - h.x) / T;
      const vy = (ty - h.y - 0.5 * 1500 * T * T) / T;
      host.hazards.add({ kind: 'dynamite', x: h.x, y: h.y - 6, vx, vy, vr: (sign(vx) || 1) * rand(7, 11), life: 1.55 + i * 0.12 });
    }
    host.sfx.whoosh(0.25);
  }

  protected poseHook(T: Pose, _dt: number): number {
    switch (this.act) {
      case 'roll':
        T.py = -30;
        T.torso = 0.9;
        T.head = 0.4;
        T.fx = 10;
        T.fy = -24;
        T.bx = 6;
        T.by = -20;
        return 40;
      case 'grenade':
        T.torso = this.actT < 0.45 ? -0.25 : 0.35;
        T.fx = 14;
        T.bx = -11;
        return 26;
      case 'summon':
        T.torso = -0.12;
        T.head = -0.35;
        return 16;
      case 'tommy':
        T.fx = 13;
        T.bx = -13;
        T.torso = -0.12 - this.recoil * 0.06;
        return 22;
      case 'stagger': {
        const s = Math.sin(this.animT * 12);
        T.torso = -0.3 + s * 0.12;
        T.head = 0.3;
        T.fx = 10 + s * 6;
        T.bx = -10 - s * 6;
        return 22;
      }
      case 'roar':
      case 'intro': {
        const k = this.act === 'roar' ? Math.min(1, this.actT * 4) : 1;
        T.torso = -0.2 * k;
        T.head = -0.3 * k;
        T.fx = 10;
        T.bx = -10;
        return 18;
      }
      default:
        return 0;
    }
  }

  protected armHook(wp: WorldPose) {
    const f = this.facing;
    const d = this.dims;
    wp.angry = true;
    switch (this.act) {
      case 'grenade':
      case 'summon': {
        wp.gunF = null;
        wp.flashF = 0;
        if (this.act === 'summon') reachArm(wp.shF, wp.head.x + f * 7, wp.head.y + 7, d, f, wp.elF, wp.haF);
        else if (this.actT < 0.45) reachArm(wp.shF, wp.shF.x - f * 14, wp.shF.y - 22, d, -f, wp.elF, wp.haF);
        else reachArm(wp.shF, wp.shF.x + f * 28, wp.shF.y + 4, d, f, wp.elF, wp.haF);
        reachArm(wp.shB, wp.shB.x + f * 8, wp.shB.y + 30, d, f, wp.elB, wp.haB);
        wp.gunB = 'shotgun';
        wp.aimB = f > 0 ? 1.25 : Math.PI - 1.25;
        break;
      }
      case 'intro':
      case 'roar':
        reachArm(wp.shF, wp.shF.x + f * 4, wp.shF.y - 14, d, f, wp.elF, wp.haF);
        wp.aimF = f > 0 ? -2.0 : -1.14;
        wp.flashF = 0;
        reachArm(wp.shB, wp.shB.x + f * 24, wp.shB.y - 8, d, f, wp.elB, wp.haB);
        wp.gunB = null;
        break;
      default:
        break;
    }
  }

  drawOverlay(ctx: CanvasRenderingContext2D, t: number): void {
    if (this.act === 'grenade' && !this.thrown) {
      const h = this.wp.haF;
      ctx.save();
      ctx.translate(h.x, h.y - 6);
      ctx.rotate(0.3 * this.facing);
      ctx.fillStyle = '#c0392b';
      ctx.strokeStyle = '#1b1410';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(-4, -9, 8, 18, 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      glow(ctx, h.x + 2 * this.facing, h.y - 22, 10, '255,200,80', 0.9);
    }
    if (this.act === 'stagger') drawStars(ctx, this.wp.head.x, this.wp.head.y - 18, t);
    if (this.act === 'roll') glow(ctx, this.x, this.y - 30, 60, '160,220,255', 0.2);
  }
}

// ================================================================== ARENAS
const NOEXIT = { x: -99999, y: -99999, w: 1, h: 1 };

const JAGAL_ARENA: LevelDef = {
  name: 'BOSS',
  subtitle: 'SI JAGAL',
  mode: 'boss',
  bounds: { x: -70, y: -800, w: 1640, h: 1060 },
  arena: { x: 0, y: -700, w: 1500, h: 700 },
  killY: 400,
  spawn: { x: 230, y: 0 },
  solids: [
    { x: -300, y: 0, w: 2100, h: 400, kind: 'tile' },
    { x: -300, y: -1100, w: 300, h: 1100, kind: 'brick' },
    { x: 1500, y: -1100, w: 300, h: 1100, kind: 'brick' },
    { x: -300, y: -1100, w: 2100, h: 400, kind: 'concrete' },
    { x: 110, y: -235, w: 290, h: 14, kind: 'metal', oneWay: true },
    { x: 1100, y: -235, w: 290, h: 14, kind: 'metal', oneWay: true },
    { x: 600, y: -420, w: 300, h: 14, kind: 'metal', oneWay: true },
    { x: 690, y: -44, w: 120, h: 44, kind: 'steeltable' },
  ],
  rooms: [{ x: 0, y: -700, w: 1500, h: 700, style: 'freezer' }],
  enemies: [{ x: 1220, y: 0, type: 'boss', facing: -1, section: 1 }],
  props: [
    { type: 'barrel', x: 60, y: 0, section: 1 },
    { type: 'barrel', x: 1440, y: 0, section: 1 },
    { type: 'weapon', gun: 'bat', x: 750, y: -420, section: 1 },
    { type: 'weapon', gun: 'katana', x: 400, y: 0, section: 1 },
    { type: 'weapon', gun: 'sling', x: 255, y: -235, section: 1 },
    { type: 'lamp', x: 380, y: -700, h: 60, section: 1 },
    { type: 'lamp', x: 750, y: -700, h: 100, section: 1 },
    { type: 'lamp', x: 1120, y: -700, h: 60, section: 1 },
  ],
  ziplines: [],
  hints: [],
  checkpoints: [],
  decos: [
    { type: 'pipe', x: 0, y: -690, w: 1500, h: 12 },
    { type: 'rail', x: 40, y: -672, w: 1420 },
    { type: 'meat', x: 130, y: -672, len: 130 },
    { type: 'meat', x: 240, y: -672, len: 150 },
    { type: 'meat', x: 540, y: -672, len: 120 },
    { type: 'meat', x: 960, y: -672, len: 120 },
    { type: 'meat', x: 1260, y: -672, len: 150 },
    { type: 'meat', x: 1370, y: -672, len: 130 },
    { type: 'sign', x: 655, y: -560, text: 'SI JAGAL', color: '#ff4d6d' },
    { type: 'bgdoor', x: 190, y: 0, w: 110, h: 170 },
    { type: 'bgdoor', x: 1200, y: 0, w: 110, h: 170 },
    { type: 'chain', x: 520, y: -700, len: 160 },
    { type: 'chain', x: 985, y: -700, len: 200 },
    { type: 'hazard', x: 0, y: -16, w: 110, h: 16 },
    { type: 'hazard', x: 1390, y: -16, w: 110, h: 16 },
  ],
  exit: NOEXIT,
  bossHint: '',
};

const KUMIS_ARENA: LevelDef = {
  name: 'BOSS',
  subtitle: 'DON KUMIS',
  mode: 'boss',
  bounds: { x: -70, y: -820, w: 1740, h: 1080 },
  arena: { x: 0, y: -720, w: 1600, h: 720 },
  killY: 400,
  spawn: { x: 220, y: 0 },
  solids: [
    { x: -300, y: 0, w: 2200, h: 400, kind: 'wood' },
    { x: -300, y: -1100, w: 300, h: 1100, kind: 'concrete' },
    { x: 1600, y: -1100, w: 300, h: 1100, kind: 'concrete' },
    { x: -300, y: -1100, w: 2200, h: 380, kind: 'concrete' },
    { x: 90, y: -250, w: 280, h: 16, kind: 'wood', oneWay: true },
    { x: 1230, y: -250, w: 280, h: 16, kind: 'wood', oneWay: true },
    { x: 620, y: -450, w: 360, h: 16, kind: 'wood', oneWay: true },
  ],
  rooms: [{ x: 0, y: -720, w: 1600, h: 720, style: 'penthouse' }],
  enemies: [{ x: 1300, y: 0, type: 'boss', facing: -1, section: 1 }],
  props: [
    { type: 'chandelier', x: 500, y: -720, h: 150, section: 1 },
    { type: 'chandelier', x: 1100, y: -720, h: 150, section: 1 },
    { type: 'barrel', x: 800, y: 0, section: 1 },
    { type: 'weapon', gun: 'ak47', x: 800, y: -450, section: 1 },
    { type: 'weapon', gun: 'katana', x: 380, y: 0, section: 1 },
  ],
  ziplines: [],
  hints: [],
  checkpoints: [],
  decos: [
    { type: 'curtain', x: 236, y: -650, w: 54, h: 400 },
    { type: 'curtain', x: 560, y: -650, w: 54, h: 400 },
    { type: 'curtain', x: 986, y: -650, w: 54, h: 400 },
    { type: 'curtain', x: 1310, y: -650, w: 54, h: 400 },
    { type: 'painting', x: 755, y: -665, w: 90, h: 110 },
    { type: 'desk', x: 1310, y: 0, w: 180 },
    { type: 'plant', x: 50, y: 0 },
    { type: 'plant', x: 1550, y: 0 },
    { type: 'plant', x: 640, y: -450 },
    { type: 'plant', x: 960, y: -450 },
  ],
  exit: NOEXIT,
  bossHint: '',
};

const PEDRO_ARENA: LevelDef = {
  name: 'BOSS',
  subtitle: 'PEDRO',
  mode: 'boss',
  sky: 'dream',
  bounds: { x: -70, y: -900, w: 1840, h: 1160 },
  arena: { x: 0, y: -820, w: 1700, h: 820 },
  killY: 400,
  spawn: { x: 260, y: 0 },
  solids: [
    { x: -300, y: 0, w: 2300, h: 400, kind: 'dream' },
    { x: -300, y: -1400, w: 300, h: 1400, kind: 'dream' },
    { x: 1700, y: -1400, w: 300, h: 1400, kind: 'dream' },
    { x: 140, y: -220, w: 240, h: 16, kind: 'dream', oneWay: true },
    { x: 1320, y: -220, w: 240, h: 16, kind: 'dream', oneWay: true },
    { x: 520, y: -390, w: 220, h: 16, kind: 'dream', oneWay: true },
    { x: 960, y: -390, w: 220, h: 16, kind: 'dream', oneWay: true },
    { x: 740, y: -560, w: 220, h: 16, kind: 'dream', oneWay: true },
  ],
  rooms: [{ x: 0, y: -820, w: 1700, h: 820, style: 'dream' }],
  enemies: [{ x: 1200, y: -430, type: 'boss', facing: -1, section: 1 }],
  props: [
    { type: 'uzi', x: 850, y: -560, section: 1 },
    { type: 'weapon', gun: 'sniper', x: 1440, y: -220, section: 1 },
    { type: 'weapon', gun: 'cricket', x: 260, y: -220, section: 1 },
    { type: 'weapon', gun: 'katana', x: 430, y: 0, section: 1 },
  ],
  ziplines: [],
  hints: [],
  checkpoints: [],
  decos: [],
  exit: NOEXIT,
  bossHint: '',
};

export const ARENAS: Record<BossId, LevelDef> = {
  jagal: JAGAL_ARENA,
  kumis: KUMIS_ARENA,
  pedro: PEDRO_ARENA,
};

export function makeBoss(def: EnemyDef, id: BossId): Enemy {
  if (id === 'jagal') return new JagalBoss(def);
  if (id === 'kumis') return new KumisBoss(def);
  return new PedroBoss(def);
}

/** draws a boss portrait for the selection cards */
export function renderBossPortrait(canvas: HTMLCanvasElement, id: BossId) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  const info = BOSS_INFO[id];
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, W, H);
  const g = ctx.createRadialGradient(W / 2, H * 0.62, 10, W / 2, H * 0.62, W * 0.75);
  g.addColorStop(0, info.color);
  g.addColorStop(1, '#120d0a');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.translate(W / 2, H * 0.62);
  ctx.fillStyle = 'rgba(255,255,255,0.08)';
  for (let i = 0; i < 12; i++) {
    ctx.rotate(TAU / 12);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(W, -W * 0.12);
    ctx.lineTo(W, W * 0.12);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
  if (id === 'pedro') {
    drawPedroBoss(ctx, W * 0.5, H * 0.5, H / 46, -0.12, -1, {
      talk: 0,
      angry: true,
      glow: 0.7,
      flash: 0,
      phase: 1,
      dying: 0,
      lx: -0.6,
      ly: 0.4,
      t: 0,
    });
    return;
  }
  const def: EnemyDef = { x: 0, y: 0, type: 'boss', facing: 1, section: 1 };
  const e = id === 'jagal' ? new JagalBoss(def) : new KumisBoss(def);
  e.portraitPose();
  const sc = H / 168;
  ctx.save();
  ctx.translate(W / 2 - 4 * sc, H - 12);
  ctx.scale(sc, sc);
  drawCharacter(ctx, e.wp, e.look, e.dims);
  ctx.restore();
}
