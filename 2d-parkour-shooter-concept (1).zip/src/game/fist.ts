import { BOSS_DIMS, ENEMY_DIMS, mafiaLook, reachArm, type Look, type Pose, type WorldPose } from './character';
import { Enemy, type EnemyHost } from './enemy';
import type { EnemyDef, LevelDef } from './level';
import { approach, clamp, rand, sign, TAU } from './math';
import type { Particles } from './particles';
import type { Sound } from './audio';

export type AtkKind = 'hit' | 'unblock' | 'low';

export interface FistHost extends EnemyHost {
  particles: Particles;
  bossIntro: number;
  brawlerHit(e: Enemy, dmg: number, dir: number, kind: AtkKind): 'parry' | 'block' | 'hit' | 'miss';
}

interface Atk {
  wind: number;
  dur: number;
  dmg: number;
  kind: AtkKind;
  hand: number;
  kick?: boolean;
  sweep?: boolean;
  reach: number;
  lunge?: number;
}

const JAB: Atk = { wind: 0.36, dur: 0.17, dmg: 8, kind: 'hit', hand: 0, reach: 64 };
const CROSS: Atk = { wind: 0.22, dur: 0.18, dmg: 9, kind: 'hit', hand: 1, reach: 66 };
const KICK: Atk = { wind: 0.52, dur: 0.24, dmg: 14, kind: 'unblock', hand: 2, kick: true, reach: 80, lunge: 170 };
const SWEEP: Atk = { wind: 0.46, dur: 0.22, dmg: 10, kind: 'low', hand: 2, sweep: true, reach: 82 };
const PALM: Atk = { wind: 0.44, dur: 0.2, dmg: 16, kind: 'unblock', hand: 3, reach: 76, lunge: 330 };

export const FIST_WAVES: string[][] = [['b', 'b'], ['b', 'b', 'b'], ['b', 'E', 'b'], ['b', 'b', 'E', 'b'], ['G', 'b', 'b']];
export const FIST_MAX_AGE = 70;
export const GURU_INFO = {
  name: 'GURU NAGA',
  title: 'MAHAGURU DOJO',
  tip: 'Cahaya MERAH tidak bisa ditangkis — menghindar! PARRY tepat waktu untuk merusak kuda-kudanya.',
  color: '#e63946',
};

export function brawlerLook(v: number, elite: number): Look {
  const L = mafiaLook('thug', v);
  const tops = ['#2b2b2b', '#7a1c1c', '#1f3a5a', '#3d5a2a', '#5a3a1f', '#3a2b45'];
  L.tankTop = true;
  L.noTie = true;
  L.hat = false;
  L.glasses = false;
  L.jacket = tops[Math.abs(v) % tops.length];
  L.jacketShade = '#141414';
  L.pants = '#24242a';
  L.pantsShade = '#18181c';
  L.shoe = '#151515';
  L.shoeShade = '#0b0b0b';
  if (elite === 1) {
    L.bald = true;
    L.jacket = '#141414';
    L.mustache = 2;
  }
  if (elite === 2) {
    L.hair = '#ececec';
    L.beard = true;
    L.mustache = 2;
    L.jacket = '#8c1d24';
    L.jacketShade = '#5e1218';
    L.pants = '#141414';
    L.pantsShade = '#0d0d0d';
  }
  return L;
}

/** kung-fu street fighter: approaches, telegraphs attacks (white = blockable, red = dodge), blocks, has posture */
export class Brawler extends Enemy {
  act: 'fight' | 'windup' | 'strike' | 'recover' | 'hurt' | 'broken' = 'fight';
  actT = 0;
  atkCd: number;
  pattern: Atk[] = [JAB];
  step = 0;
  elite: number;
  blockT = 0;
  stunLeft = 0;
  brokenT = 0;
  struck = false;

  constructor(def: EnemyDef, elite: number) {
    super(def);
    this.elite = elite;
    this.gun = null;
    this.state = 'alert';
    this.look = brawlerLook(def.variant ?? 0, elite);
    if (elite === 1) {
      this.dims = BOSS_DIMS;
      this.h = 106;
      this.w = 34;
    } else {
      this.dims = ENEMY_DIMS;
      this.h = 99;
      this.w = 28;
    }
    this.maxHp = elite === 2 ? 40 : elite === 1 ? 9 : 5;
    this.hp = this.maxHp;
    this.hpShown = this.maxHp;
    this.structMax = elite === 2 ? 16 : elite === 1 ? 9 : 6;
    this.atkCd = rand(0.6, 1.4);
    if (elite === 2) {
      this.isBossMode = true;
      this.bossName = GURU_INFO.name;
      this.bossTitle = GURU_INFO.title;
      this.phaseMarks = [0.5];
    }
  }

  get spd() {
    return 1 + this.elite * 0.18 + (this.elite === 2 && this.hp < this.maxHp * 0.5 ? 0.15 : 0);
  }

  get atk() {
    return this.pattern[Math.min(this.step, this.pattern.length - 1)];
  }

  addStruct(n: number) {
    if (this.act === 'broken') return true;
    this.struct += n;
    if (this.struct >= this.structMax) {
      this.struct = this.structMax;
      this.act = 'broken';
      this.actT = 0;
      this.brokenT = this.elite === 2 ? 1.7 : 2.4;
      this.vx = 0;
      return true;
    }
    return false;
  }

  tryBlock(heavy: boolean) {
    if (heavy || this.act === 'broken' || this.act === 'hurt' || this.act === 'strike' || this.act === 'windup') return false;
    if (Math.random() < 0.28 + this.elite * 0.14) {
      this.blockT = 0.28;
      this.act = 'fight';
      return true;
    }
    return false;
  }

  hurt(dmg: number, dirx: number, head: boolean, _time: number, _sfx: Sound) {
    this.hp -= dmg;
    this.hitT = 0.22;
    this.hitDir = sign(dirx);
    this.lastHitHead = head;
    // hits interrupt attacks (the guru keeps his armour while striking)
    if (!(this.elite === 2 && this.act === 'strike') && this.act !== 'broken') {
      this.act = 'hurt';
      this.actT = 0;
      this.stunLeft = Math.max(this.stunLeft, 0.26);
    }
    return this.hp <= 0;
  }

  stunFor(t: number, vx: number, vy: number) {
    if (this.act === 'broken') {
      this.vx = vx * 0.5;
      return;
    }
    this.act = 'hurt';
    this.actT = 0;
    this.stunLeft = t;
    this.vx = vx;
    this.vy = vy;
    if (vy < 0) this.onGround = false;
  }

  private startAttack() {
    const r = Math.random();
    let pat: Atk[];
    if (this.elite === 2) {
      pat = r < 0.25 ? [JAB, CROSS, KICK] : r < 0.45 ? [PALM] : r < 0.65 ? [JAB, CROSS, CROSS, SWEEP] : r < 0.85 ? [KICK, JAB] : [SWEEP, PALM];
    } else if (this.elite === 1) pat = r < 0.35 ? [JAB, CROSS] : r < 0.6 ? [PALM] : r < 0.8 ? [KICK] : [SWEEP];
    else pat = r < 0.42 ? [JAB] : r < 0.68 ? [JAB, CROSS] : r < 0.86 ? [KICK] : [SWEEP];
    this.pattern = pat;
    this.step = 0;
    this.act = 'windup';
    this.actT = 0;
    this.struck = false;
  }

  protected bossUpdate(dt: number, hostE: EnemyHost): boolean {
    const host = hostE as FistHost;
    const p = host.player;
    this.animT += dt;
    this.actT += dt;
    this.hitT -= dt;
    this.atkCd -= dt;
    this.blockT -= dt;
    this.flung -= dt;
    this.hpShown = approach(this.hpShown, this.hp, dt * 20);
    if (this.act !== 'broken') this.struct = Math.max(0, this.struct - dt * (0.55 + this.elite * 0.25));
    const dx = p.x - this.x;
    const adx = Math.abs(dx);
    const spd = this.spd;
    let move = 0;
    if (this.act === 'fight' || this.act === 'recover') this.facing = dx >= 0 ? 1 : -1;
    if (host.bossIntro > 0) {
      this.act = 'fight';
      this.actT = 0;
    } else {
      switch (this.act) {
        case 'fight': {
          const reach = 58 + this.elite * 6;
          if (adx > reach - 4) move = sign(dx);
          else if (adx < 30) move = -sign(dx);
          if (move !== 0 && !this.groundAhead(host.world, move)) move = 0;
          if (this.atkCd <= 0 && adx < reach + 26 && Math.abs(p.y - this.y) < 70 && p.alive) this.startAttack();
          break;
        }
        case 'windup': {
          const a = this.atk;
          const w = (this.step === 0 ? a.wind : a.wind * 0.6) / spd;
          if (this.actT >= w) {
            this.act = 'strike';
            this.actT = 0;
            this.struck = false;
            host.sfx.whoosh(a.kick || a.sweep ? 0.3 : 0.2);
          }
          break;
        }
        case 'strike': {
          const a = this.atk;
          if (!this.struck && this.actT >= 0.05) {
            this.struck = true;
            const pdx = p.x - this.x;
            const dy = p.y - p.h * 0.5 - (this.y - this.h * 0.5);
            if (pdx * this.facing > -8 && Math.abs(pdx) < a.reach + p.w / 2 && Math.abs(dy) < 70) {
              const res = host.brawlerHit(this, a.dmg, this.facing, a.kind);
              if (res === 'parry') {
                this.stunFor(0.75, -this.facing * 160, 0);
                this.addStruct(4 + this.elite);
                break;
              }
            }
          }
          if (this.actT >= a.dur) {
            this.step++;
            this.actT = 0;
            this.act = this.step < this.pattern.length ? 'windup' : 'recover';
          }
          break;
        }
        case 'recover':
          if (this.actT > 0.32 / spd) {
            this.act = 'fight';
            this.atkCd = rand(0.7, 1.5) / (1 + 0.4 * this.elite);
          }
          break;
        case 'hurt':
          if (this.actT >= this.stunLeft && this.onGround) {
            this.act = 'fight';
            this.stunLeft = 0;
            this.atkCd = Math.max(this.atkCd, 0.35);
          }
          break;
        case 'broken':
          this.brokenT -= dt;
          if (this.brokenT <= 0) {
            this.act = 'fight';
            this.struct = 0;
            this.atkCd = 0.4;
          }
          break;
      }
    }
    const a = this.act === 'strike' ? this.atk : null;
    if (a && a.lunge && this.actT < 0.12) this.vx = this.facing * a.lunge;
    else if (this.act === 'fight') this.vx = approach(this.vx, move * 150 * spd, 1400 * dt);
    else if (this.onGround) this.vx = approach(this.vx, 0, (this.act === 'hurt' ? 700 : 1600) * dt);
    this.physics(dt, host.world);
    if (this.res.hitX !== 0) this.vx = 0;
    this.animate(dt, move);
    return true;
  }

  protected poseHook(T: Pose): number {
    switch (this.act) {
      case 'fight':
      case 'recover':
        if (Math.abs(this.vx) < 15) {
          T.fx = 13;
          T.bx = -12;
          T.py = -46.5 + Math.sin(this.animT * 4) * 0.6;
        }
        T.torso = 0.1;
        T.head = -0.08;
        return 0;
      case 'windup': {
        const a = this.atk;
        if (a.kick) {
          T.fx = 12;
          T.fy = -28;
          T.torso = -0.12;
        } else if (a.sweep) {
          T.py = -36;
          T.torso = 0.35;
          T.fx = 16;
          T.bx = -14;
        } else {
          T.torso = -0.12;
          T.fx = 12;
          T.bx = -14;
        }
        return 30;
      }
      case 'strike': {
        const a = this.atk;
        if (a.kick) {
          T.fx = 48;
          T.fy = -52;
          T.torso = -0.38;
          T.head = 0.25;
          T.bx = -10;
        } else if (a.sweep) {
          T.py = -28;
          T.torso = 0.55;
          T.fx = 46;
          T.fy = -4;
          T.bx = -10;
        } else {
          T.torso = 0.3;
          T.fx = 18;
          T.bx = -14;
          T.py = -45;
        }
        return 60;
      }
      case 'hurt':
        T.torso = -0.3;
        T.head = 0.3;
        return 26;
      case 'broken': {
        const s = Math.sin(this.animT * 5);
        T.torso = 0.25 + s * 0.15;
        T.head = 0.45;
        T.py = -44;
        T.fx = 10 + s * 4;
        T.bx = -10 + s * 4;
        return 14;
      }
    }
    return 0;
  }

  protected armHook(wp: WorldPose) {
    const f = this.facing;
    const d = this.dims;
    const sh = wp.shF;
    const sb = wp.shB;
    wp.gunF = null;
    wp.gunB = null;
    wp.flashF = 0;
    wp.angry = true;
    const bob = Math.sin(this.animT * 4);
    let tF = { x: sh.x + f * 13, y: sh.y - 5 + bob };
    let tB = { x: sb.x + f * 9, y: sb.y - 1 + bob };
    if (this.blockT > 0) {
      tF = { x: sh.x + f * 11, y: sh.y - 13 };
      tB = { x: sb.x + f * 13, y: sb.y - 9 };
    }
    const a = this.atk;
    if (this.act === 'windup') {
      if (a.hand === 0) tF = { x: sh.x - f * 2, y: sh.y - 3 };
      else if (a.hand === 1) tB = { x: sb.x - f * 6, y: sb.y };
      else if (a.hand === 3) {
        tF = { x: sh.x - f * 4, y: sh.y + 4 };
        tB = { x: sb.x - f * 6, y: sb.y + 6 };
      }
    } else if (this.act === 'strike') {
      const ext = this.actT < 0.13 ? 1 : 0.6;
      if (a.hand === 0) tF = { x: sh.x + f * 33 * ext, y: sh.y - 2 };
      else if (a.hand === 1) tB = { x: sb.x + f * 35 * ext, y: sb.y - 1 };
      else if (a.hand === 3) {
        tF = { x: sh.x + f * 32 * ext, y: sh.y + 4 };
        tB = { x: sb.x + f * 32 * ext, y: sb.y + 8 };
      }
    } else if (this.act === 'broken') {
      const s = Math.sin(this.animT * 5);
      tF = { x: sh.x + f * (4 + s * 3), y: sh.y + 26 };
      tB = { x: sb.x - f * 3, y: sb.y + 27 };
    } else if (this.act === 'hurt') {
      tF = { x: sh.x - f * 4, y: sh.y - 10 };
      tB = { x: sb.x + f * 4, y: sb.y + 14 };
    }
    reachArm(sh, tF.x, tF.y, d, f, wp.elF, wp.haF);
    reachArm(sb, tB.x, tB.y, d, f, wp.elB, wp.haB);
  }

  drawOverlay(ctx: CanvasRenderingContext2D, t: number): void {
    const wp = this.wp;
    if (this.act === 'windup') {
      // Sifu-style telegraph: white glint = blockable, red glow = dodge / jump
      const a = this.atk;
      const red = a.kind !== 'hit';
      const k = clamp(this.actT / (a.wind / this.spd), 0, 1);
      const hx = a.hand === 1 ? wp.haB.x : a.hand === 2 ? wp.ftF.x : wp.haF.x;
      const hy = a.hand === 1 ? wp.haB.y : a.hand === 2 ? wp.ftF.y - 10 : wp.haF.y;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const r = 10 + 24 * k;
      const g = ctx.createRadialGradient(hx, hy, 0, hx, hy, r);
      g.addColorStop(0, red ? 'rgba(255,50,50,0.95)' : 'rgba(255,255,255,0.95)');
      g.addColorStop(1, red ? 'rgba(255,0,0,0)' : 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(hx, hy, r, 0, TAU);
      ctx.fill();
      if (k > 0.55) {
        const s = 6 + 12 * k;
        ctx.fillStyle = red ? '#ff6b6b' : '#ffffff';
        ctx.beginPath();
        ctx.moveTo(hx - s, hy);
        ctx.lineTo(hx, hy - s * 0.22);
        ctx.lineTo(hx + s, hy);
        ctx.lineTo(hx, hy + s * 0.22);
        ctx.closePath();
        ctx.moveTo(hx, hy - s);
        ctx.lineTo(hx + s * 0.22, hy);
        ctx.lineTo(hx, hy + s);
        ctx.lineTo(hx - s * 0.22, hy);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      if (red) {
        ctx.save();
        ctx.font = '28px Bangers, Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.lineWidth = 5;
        ctx.strokeStyle = '#120d0a';
        ctx.fillStyle = '#ff4d4d';
        ctx.strokeText('!', wp.head.x, wp.head.y - 30);
        ctx.fillText('!', wp.head.x, wp.head.y - 30);
        ctx.restore();
      }
    }
    // posture bar
    if (this.struct > 0.05 || this.act === 'broken') {
      const w = 46;
      const x = wp.head.x - w / 2;
      const y = wp.head.y - this.dims.headR - 20;
      const broken = this.act === 'broken';
      ctx.fillStyle = '#120d0a';
      ctx.fillRect(x - 2, y - 2, w + 4, 8);
      const k = clamp(this.struct / this.structMax, 0, 1);
      ctx.fillStyle = broken ? (Math.sin(t * 16) > 0 ? '#fff3a0' : '#ffb347') : '#ff8c2e';
      ctx.fillRect(x, y, w * k, 4);
      if (broken) {
        ctx.save();
        ctx.font = '16px Bangers, Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#120d0a';
        ctx.fillStyle = '#fff3a0';
        ctx.strokeText('TAKEDOWN!', wp.head.x, y - 6);
        ctx.fillText('TAKEDOWN!', wp.head.x, y - 6);
        ctx.restore();
        for (let i = 0; i < 3; i++) {
          const an = t * 6 + (i * TAU) / 3;
          ctx.fillStyle = '#ffd23f';
          ctx.beginPath();
          ctx.arc(wp.head.x + Math.cos(an) * 15, wp.head.y - 12 + Math.sin(an) * 5, 3, 0, TAU);
          ctx.fill();
        }
      }
    }
  }
}

export function makeBrawler(code: string, x: number, y: number, facing: number, variant: number) {
  const elite = code === 'G' ? 2 : code === 'E' ? 1 : 0;
  const def: EnemyDef = { x, y, type: elite === 2 ? 'boss' : 'thug', facing: facing >= 0 ? 1 : -1, section: 1, variant };
  return new Brawler(def, elite);
}

export const DOJO: LevelDef = {
  name: 'DOJO',
  subtitle: 'MODE KUNGFU',
  bounds: { x: -70, y: -800, w: 1840, h: 1060 },
  arena: { x: 0, y: -700, w: 1700, h: 700 },
  killY: 400,
  spawn: { x: 850, y: 0 },
  solids: [
    { x: -300, y: 0, w: 2300, h: 400, kind: 'wood' },
    { x: -300, y: -1100, w: 300, h: 1100, kind: 'wood' },
    { x: 1700, y: -1100, w: 300, h: 1100, kind: 'wood' },
    { x: -300, y: -1100, w: 2300, h: 400, kind: 'wood' },
    { x: 150, y: -210, w: 230, h: 16, kind: 'wood', oneWay: true },
    { x: 1320, y: -210, w: 230, h: 16, kind: 'wood', oneWay: true },
  ],
  rooms: [{ x: 0, y: -700, w: 1700, h: 700, style: 'dojo' }],
  enemies: [],
  props: [
    { type: 'lamp', x: 250, y: -700, h: 70, section: 1 },
    { type: 'lamp', x: 650, y: -700, h: 70, section: 1 },
    { type: 'lamp', x: 1050, y: -700, h: 70, section: 1 },
    { type: 'lamp', x: 1450, y: -700, h: 70, section: 1 },
  ],
  ziplines: [],
  hints: [],
  checkpoints: [],
  decos: [
    { type: 'plant', x: 60, y: 0 },
    { type: 'plant', x: 1640, y: 0 },
  ],
  exit: { x: -99999, y: -99999, w: 1, h: 1 },
  bossHint: '',
};
