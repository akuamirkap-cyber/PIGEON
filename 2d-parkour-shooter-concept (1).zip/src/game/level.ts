import type { Rect } from './math';

export type SolidKind =
  | 'concrete'
  | 'brick'
  | 'tile'
  | 'metal'
  | 'wood'
  | 'crate'
  | 'dumpster'
  | 'counter'
  | 'roof'
  | 'duct'
  | 'table'
  | 'steeltable'
  | 'dream';

export interface SolidDef extends Rect {
  kind: SolidKind;
  oneWay?: boolean;
}

export type RoomStyle = 'basement' | 'freezer' | 'alley' | 'kitchen' | 'stair' | 'warehouse' | 'penthouse' | 'dream' | 'dojo';

export interface RoomDef extends Rect {
  style: RoomStyle;
}

export type EnemyType = 'thug' | 'gunner' | 'rifleman' | 'sniper' | 'boss';

export interface EnemyDef {
  x: number;
  y: number;
  type: EnemyType;
  facing: 1 | -1;
  section: number;
  patrol?: [number, number];
  variant?: number;
}

export type PropType =
  | 'barrel'
  | 'pan'
  | 'glass'
  | 'glassdoor'
  | 'door'
  | 'banana'
  | 'uzi'
  | 'shotgun'
  | 'weapon'
  | 'gundrop'
  | 'lamp'
  | 'streetlamp'
  | 'chandelier';

export interface PropDef {
  type: PropType;
  x: number;
  y: number;
  w?: number;
  h?: number;
  section: number;
  gun?: string;
}

export interface ZiplineDef {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export interface HintDef {
  id: string;
  trigger: Rect;
  text: string;
}

export interface CheckpointDef {
  id: number;
  trigger: Rect;
  spawn: { x: number; y: number };
  section: number;
}

export type DecoType =
  | 'lamp'
  | 'pipe'
  | 'meat'
  | 'poster'
  | 'sign'
  | 'window'
  | 'fan'
  | 'boxes'
  | 'fence'
  | 'streetlamp'
  | 'trash'
  | 'ladder'
  | 'stove'
  | 'fridge'
  | 'hood'
  | 'panrack'
  | 'watertower'
  | 'antenna'
  | 'pole'
  | 'forklift'
  | 'exitsign'
  | 'graffiti'
  | 'chain'
  | 'beam'
  | 'vent'
  | 'bgdoor'
  | 'hazard'
  | 'rail'
  | 'desk'
  | 'painting'
  | 'plant'
  | 'curtain';

export interface DecoDef {
  type: DecoType;
  x: number;
  y: number;
  w?: number;
  h?: number;
  len?: number;
  text?: string;
  color?: string;
  flip?: boolean;
}

export interface LevelDef {
  name: string;
  subtitle: string;
  bounds: Rect;
  killY: number;
  spawn: { x: number; y: number };
  solids: SolidDef[];
  rooms: RoomDef[];
  enemies: EnemyDef[];
  props: PropDef[];
  ziplines: ZiplineDef[];
  hints: HintDef[];
  checkpoints: CheckpointDef[];
  decos: DecoDef[];
  exit: Rect;
  bossHint: string;
  mode?: 'story' | 'boss';
  sky?: 'city' | 'dream';
  arena?: Rect;
}

export const LEVEL1: LevelDef = {
  name: 'LEVEL 1',
  subtitle: 'GUDANG DAGING SI KUMIS',
  bounds: { x: -60, y: -1500, w: 9760, h: 1880 },
  killY: 420,
  spawn: { x: 110, y: 0 },
  solids: [
    // ---------------- SECTION 1 : BASEMENT ----------------
    { x: -300, y: 0, w: 2000, h: 520, kind: 'concrete' },
    { x: -300, y: -1100, w: 300, h: 1100, kind: 'brick' },
    { x: -300, y: -700, w: 1600, h: 300, kind: 'concrete' },
    { x: 200, y: -44, w: 110, h: 44, kind: 'table' },
    { x: 380, y: -56, w: 60, h: 56, kind: 'crate' },
    { x: 640, y: -400, w: 150, h: 338, kind: 'duct' },
    { x: 872, y: -400, w: 32, h: 250, kind: 'metal' },
    { x: 1390, y: -72, w: 90, h: 72, kind: 'crate' },
    { x: 1240, y: -1500, w: 60, h: 800, kind: 'brick' },
    { x: 1240, y: -400, w: 60, h: 280, kind: 'brick' },
    { x: 1480, y: -660, w: 130, h: 660, kind: 'brick' },

    // ---------------- SECTION 2 : FREEZER ----------------
    { x: 1610, y: -660, w: 1570, h: 26, kind: 'tile' },
    { x: 1610, y: -634, w: 1570, h: 1154, kind: 'brick' },
    { x: 1240, y: -1500, w: 1940, h: 350, kind: 'concrete' },
    { x: 1660, y: -1150, w: 30, h: 340, kind: 'brick' },
    { x: 2160, y: -740, w: 80, h: 80, kind: 'crate' },
    { x: 2420, y: -704, w: 130, h: 44, kind: 'steeltable' },
    { x: 2250, y: -860, w: 460, h: 16, kind: 'metal', oneWay: true },
    { x: 3100, y: -760, w: 80, h: 100, kind: 'brick' },
    { x: 3100, y: -1150, w: 80, h: 230, kind: 'brick' },

    // ---------------- SECTION 3 : ALLEY ----------------
    { x: 3180, y: -220, w: 1480, h: 740, kind: 'concrete' },
    { x: 3700, y: -292, w: 112, h: 72, kind: 'dumpster' },
    { x: 3900, y: -350, w: 130, h: 14, kind: 'metal', oneWay: true },
    { x: 4040, y: -480, w: 260, h: 14, kind: 'metal', oneWay: true },
    { x: 4600, y: -1500, w: 60, h: 1140, kind: 'brick' },

    // ---------------- SECTION 4 : KITCHEN ----------------
    { x: 4660, y: -220, w: 1600, h: 24, kind: 'tile' },
    { x: 4660, y: -196, w: 1600, h: 716, kind: 'concrete' },
    { x: 4600, y: -840, w: 1300, h: 220, kind: 'roof' },
    { x: 4880, y: -264, w: 110, h: 44, kind: 'table' },
    { x: 5040, y: -292, w: 200, h: 72, kind: 'counter' },
    { x: 5872, y: -620, w: 28, h: 270, kind: 'metal' },
    { x: 5470, y: -300, w: 80, h: 80, kind: 'counter' },
    { x: 5330, y: -420, w: 260, h: 16, kind: 'wood', oneWay: true },

    // stairwell
    { x: 5900, y: -335, w: 160, h: 14, kind: 'metal', oneWay: true },
    { x: 6100, y: -460, w: 160, h: 14, kind: 'metal', oneWay: true },
    { x: 5900, y: -585, w: 160, h: 14, kind: 'metal', oneWay: true },
    { x: 6100, y: -710, w: 160, h: 14, kind: 'metal', oneWay: true },

    // ---------------- SECTION 5 : ROOFTOP ----------------
    { x: 6260, y: -840, w: 900, h: 1360, kind: 'roof' },
    { x: 6620, y: -905, w: 100, h: 65, kind: 'metal' },

    // ---------------- SECTION 6 : WAREHOUSE ----------------
    { x: 7700, y: -200, w: 2200, h: 720, kind: 'concrete' },
    { x: 7700, y: -600, w: 60, h: 400, kind: 'metal' },
    { x: 7700, y: -1500, w: 60, h: 640, kind: 'metal' },
    { x: 7700, y: -1500, w: 2200, h: 500, kind: 'metal' },
    { x: 9640, y: -1500, w: 260, h: 2020, kind: 'metal' },
    { x: 8050, y: -300, w: 100, h: 100, kind: 'crate' },
    { x: 8150, y: -260, w: 60, h: 60, kind: 'crate' },
    { x: 8500, y: -290, w: 90, h: 90, kind: 'crate' },
    { x: 8560, y: -420, w: 420, h: 16, kind: 'wood', oneWay: true },
    { x: 8700, y: -244, w: 120, h: 44, kind: 'table' },
    { x: 9100, y: -1000, w: 40, h: 660, kind: 'metal' },
    { x: 9180, y: -280, w: 80, h: 80, kind: 'crate' },
  ],
  rooms: [
    { x: 0, y: -400, w: 1480, h: 400, style: 'basement' },
    { x: 1300, y: -700, w: 180, h: 320, style: 'basement' },
    { x: 1300, y: -1150, w: 1800, h: 490, style: 'freezer' },
    { x: 3180, y: -1500, w: 1420, h: 1280, style: 'alley' },
    { x: 4660, y: -620, w: 1240, h: 400, style: 'kitchen' },
    { x: 5900, y: -840, w: 360, h: 620, style: 'stair' },
    { x: 7760, y: -1000, w: 1880, h: 800, style: 'warehouse' },
  ],
  enemies: [
    // basement
    { x: 1060, y: 0, type: 'thug', facing: -1, section: 1, variant: 0 },
    // freezer
    { x: 1790, y: -660, type: 'thug', facing: -1, section: 2, variant: 5 },
    { x: 1960, y: -660, type: 'thug', facing: -1, section: 2, patrol: [1900, 2100], variant: 1 },
    { x: 2500, y: -860, type: 'thug', facing: -1, section: 2, variant: 2 },
    { x: 2930, y: -660, type: 'rifleman', facing: -1, section: 2, variant: 3 },
    // alley
    { x: 3480, y: -220, type: 'thug', facing: -1, section: 3, variant: 4 },
    { x: 3870, y: -220, type: 'gunner', facing: -1, section: 3, variant: 0 },
    { x: 4200, y: -480, type: 'thug', facing: -1, section: 3, variant: 5 },
    // kitchen
    { x: 4740, y: -220, type: 'thug', facing: -1, section: 4, variant: 1 },
    { x: 5440, y: -420, type: 'thug', facing: -1, section: 4, variant: 2 },
    { x: 5640, y: -220, type: 'thug', facing: -1, section: 4, variant: 3 },
    { x: 5820, y: -220, type: 'gunner', facing: -1, section: 4, variant: 1 },
    { x: 6190, y: -710, type: 'thug', facing: -1, section: 4, variant: 4 },
    // rooftop
    { x: 5250, y: -840, type: 'thug', facing: 1, section: 5, variant: 5 },
    { x: 6900, y: -840, type: 'gunner', facing: -1, section: 5, variant: 2 },
    { x: 7080, y: -840, type: 'sniper', facing: -1, section: 5, variant: 0 },
    // warehouse
    { x: 8300, y: -200, type: 'rifleman', facing: -1, section: 6, variant: 1 },
    { x: 8760, y: -420, type: 'sniper', facing: -1, section: 6, variant: 0 },
    { x: 9000, y: -200, type: 'thug', facing: -1, section: 6, variant: 3 },
    { x: 9235, y: -200, type: 'thug', facing: -1, section: 6, variant: 2 },
    { x: 9420, y: -200, type: 'boss', facing: -1, section: 6, variant: 0 },
    { x: 9560, y: -200, type: 'gunner', facing: -1, section: 6, variant: 1 },
  ],
  props: [
    { type: 'banana', x: 410, y: -236, section: 1 },
    { type: 'glassdoor', x: 878, y: -150, w: 20, h: 150, section: 1 },
    { type: 'lamp', x: 230, y: -400, h: 40, section: 1 },
    { type: 'lamp', x: 1060, y: -400, h: 46, section: 1 },
    { type: 'door', x: 1662, y: -810, w: 26, h: 150, section: 2 },
    { type: 'lamp', x: 2050, y: -1150, h: 70, section: 2 },
    { type: 'lamp', x: 2480, y: -1150, h: 30, section: 2 },
    { type: 'lamp', x: 2890, y: -1150, h: 70, section: 2 },
    { type: 'streetlamp', x: 3330, y: -220, h: 260, section: 3 },
    { type: 'streetlamp', x: 4420, y: -220, h: 260, section: 3 },
    { type: 'lamp', x: 5150, y: -620, h: 50, section: 4 },
    { type: 'lamp', x: 5650, y: -620, h: 50, section: 4 },
    { type: 'lamp', x: 6080, y: -840, h: 30, section: 4 },
    { type: 'glassdoor', x: 5877, y: -350, w: 18, h: 130, section: 4 },
    { type: 'lamp', x: 8150, y: -1000, h: 90, section: 6 },
    { type: 'lamp', x: 8780, y: -1000, h: 140, section: 6 },
    { type: 'lamp', x: 9350, y: -1000, h: 90, section: 6 },
    { type: 'door', x: 9104, y: -340, w: 32, h: 140, section: 6 },
    { type: 'shotgun', x: 8100, y: -300, section: 6 },
    { type: 'weapon', gun: 'ak47', x: 2740, y: -660, section: 2 },
    { type: 'weapon', gun: 'bat', x: 3395, y: -220, section: 3 },
    { type: 'weapon', gun: 'katana', x: 1185, y: 0, section: 1 },
    { type: 'weapon', gun: 'sling', x: 2300, y: -860, section: 2 },
    { type: 'weapon', gun: 'cricket', x: 4090, y: -480, section: 3 },
    { type: 'weapon', gun: 'sniper', x: 6420, y: -840, section: 5 },
    { type: 'barrel', x: 2110, y: -660, section: 2 },
    { type: 'barrel', x: 2840, y: -660, section: 2 },
    { type: 'glass', x: 3132, y: -920, w: 16, h: 160, section: 2 },
    { type: 'banana', x: 2480, y: -1080, section: 2 },
    { type: 'door', x: 4614, y: -360, w: 32, h: 140, section: 3 },
    { type: 'barrel', x: 3640, y: -220, section: 3 },
    { type: 'pan', x: 5075, y: -292, section: 4 },
    { type: 'uzi', x: 5790, y: -220, section: 4 },
    { type: 'barrel', x: 6480, y: -840, section: 5 },
    { type: 'glass', x: 7722, y: -860, w: 16, h: 260, section: 6 },
    { type: 'barrel', x: 8420, y: -200, section: 6 },
    { type: 'barrel', x: 8900, y: -200, section: 6 },
    { type: 'barrel', x: 9330, y: -200, section: 6 },
    { type: 'banana', x: 8770, y: -640, section: 6 },
  ],
  ziplines: [{ x1: 7080, y1: -955, x2: 8360, y2: -560 }],
  hints: [
    {
      id: 'move',
      trigger: { x: 0, y: -400, w: 300, h: 400 },
      text: 'Hai, aku Pedro si pisang! A / D lari, W lompat. Lari ke arah meja atau peti = AUTO PARKOUR!',
    },
    {
      id: 'double',
      trigger: { x: 330, y: -400, w: 140, h: 400 },
      text: 'W lagi di udara = DOUBLE JUMP! Sambil lari = FRONT FLIP, diam / balik arah = BACKFLIP. Tahan S saat mendarat = ROLL!',
    },
    {
      id: 'slide',
      trigger: { x: 470, y: -400, w: 160, h: 400 },
      text: 'Ada pipa rendah! Tekan S sambil berlari untuk SLIDE ke bawahnya.',
    },
    {
      id: 'shoot',
      trigger: { x: 800, y: -400, w: 150, h: 400 },
      text: 'Bidik pakai MOUSE, KLIK KIRI untuk menembak. Pintu KACA dan LAMPU juga bisa ditembak!',
    },
    {
      id: 'wall',
      trigger: { x: 1190, y: -400, w: 290, h: 400 },
      text: 'Lompat ke dinding lalu tekan W lagi untuk WALL-FLIP. Panjat lorong ini!',
    },
    {
      id: 'focus',
      trigger: { x: 1480, y: -1150, w: 260, h: 490 },
      text: 'Pintu kayu? Sprint ke arahnya = TENDANG DOBRAK otomatis! Tekan SHIFT untuk FOKUS, tembak BAREL MERAH!',
    },
    {
      id: 'window',
      trigger: { x: 2950, y: -1150, w: 150, h: 490 },
      text: 'Sprint terus ke jendela — auto-parkour menembus kaca! Menerobos jendela = slow-motion otomatis.',
    },
    {
      id: 'spin',
      trigger: { x: 3180, y: -700, w: 220, h: 480 },
      text: 'Ada yang bawa UZI! Tekan SPACE untuk BERPUTAR — selama berputar, peluru akan meleset.',
    },
    {
      id: 'stomp',
      trigger: { x: 3560, y: -700, w: 140, h: 480 },
      text: 'Di udara tekan F = TENDANGAN TERBANG! Jatuh tepat di KEPALA musuh = INJAK, lalu memantul lagi!',
    },
    {
      id: 'door',
      trigger: { x: 4380, y: -560, w: 220, h: 340 },
      text: 'Pintu terkunci? SPRINT ke pintu atau tekan F = TENDANG DOBRAK pakai kaki kanan! Pintunya terpental menghantam musuh.',
    },
    {
      id: 'pan',
      trigger: { x: 4880, y: -620, w: 150, h: 400 },
      text: 'Lihat wajan itu! TENDANG (F) ke udara, lalu TEMBAK wajannya — peluru memantul otomatis ke musuh!',
    },
    {
      id: 'stairs',
      trigger: { x: 5900, y: -460, w: 360, h: 240 },
      text: 'Naik ke atap! Tips: tekan S + W di atas platform tipis untuk turun lagi.',
    },
    {
      id: 'split',
      trigger: { x: 5900, y: -1000, w: 400, h: 200 },
      text: 'Musuh di KIRI dan KANAN! Tahan KLIK KANAN untuk SPLIT AIM: satu tangan mengunci target, tangan lain bebas.',
    },
    {
      id: 'zip',
      trigger: { x: 6880, y: -1000, w: 280, h: 170 },
      text: 'Lompat ke ZIPLINE! Kamu tetap bisa menembak sambil meluncur. W untuk lompat lepas.',
    },
    {
      id: 'boss',
      trigger: { x: 8850, y: -1000, w: 200, h: 800 },
      text: 'Don Kumis ada di balik pintu VIP itu! Terobos pintunya, lalu kalahkan dia untuk membuka pintu keluar!',
    },
    {
      id: 'lamp',
      trigger: { x: 7770, y: -1000, w: 400, h: 800 },
      text: 'Tembak LAMPU: tembakan 1 pecahkan bohlam, tembakan 2 putuskan talinya — jatuhkan ke kepala musuh!',
    },
  ],
  checkpoints: [
    { id: 1, trigger: { x: 3190, y: -700, w: 320, h: 480 }, spawn: { x: 3260, y: -220 }, section: 3 },
    { id: 2, trigger: { x: 5900, y: -1000, w: 400, h: 190 }, spawn: { x: 6330, y: -840 }, section: 5 },
    { id: 3, trigger: { x: 7770, y: -720, w: 520, h: 520 }, spawn: { x: 7840, y: -200 }, section: 6 },
  ],
  decos: [
    // basement
    { type: 'pipe', x: 0, y: -392, w: 640, h: 10 },
    { type: 'pipe', x: 790, y: -380, w: 690, h: 14 },
    { type: 'poster', x: 120, y: -300, w: 70, h: 90, text: 'DICARI' },
    { type: 'graffiti', x: 470, y: -190, text: 'PEDRO?', color: '#e94f37' },
    { type: 'boxes', x: 1150, y: 0, w: 90, h: 70 },
    { type: 'vent', x: 1010, y: -330, w: 70, h: 40 },
    { type: 'fan', x: 300, y: -260, w: 32 },
    { type: 'pipe', x: 1460, y: -660, w: 12, h: 600 },
    { type: 'hazard', x: 1300, y: -18, w: 180, h: 18 },
    // freezer
    { type: 'rail', x: 1650, y: -1120, w: 1400 },
    { type: 'meat', x: 1720, y: -1120, len: 120 },
    { type: 'meat', x: 1830, y: -1120, len: 140 },
    { type: 'meat', x: 1945, y: -1120, len: 115 },
    { type: 'meat', x: 2620, y: -1120, len: 130 },
    { type: 'meat', x: 2760, y: -1120, len: 118 },
    { type: 'meat', x: 2985, y: -1120, len: 135 },
    { type: 'sign', x: 1560, y: -1000, text: 'DAGING SEGAR', color: '#ff4d6d' },
    { type: 'bgdoor', x: 2300, y: -660, w: 110, h: 170 },
    { type: 'chain', x: 1600, y: -1150, len: 220 },
    // alley
    { type: 'graffiti', x: 3560, y: -420, text: 'KUMIS = RAJA', color: '#3ad1e8' },
    { type: 'trash', x: 3830, y: -220 },
    { type: 'trash', x: 3240, y: -220 },
    { type: 'ladder', x: 4250, y: -480, h: 260 },
    { type: 'sign', x: 4390, y: -620, text: 'RESTO', color: '#ffd23f' },
    { type: 'fence', x: 4440, y: -220, w: 140, h: 120 },
    // kitchen
    { type: 'hood', x: 4760, y: -620, w: 180 },
    { type: 'stove', x: 4760, y: -220, w: 180 },
    { type: 'fridge', x: 5280, y: -220, w: 80, h: 160 },
    { type: 'panrack', x: 5060, y: -560, w: 160 },
    { type: 'poster', x: 5720, y: -540, w: 90, h: 110, text: 'MENU' },
    // rooftop
    { type: 'watertower', x: 6880, y: -840 },
    { type: 'antenna', x: 5000, y: -840, h: 200 },
    { type: 'vent', x: 5500, y: -880, w: 60, h: 40 },
    { type: 'pole', x: 7080, y: -840, h: 140 },
    { type: 'pole', x: 6420, y: -840, h: 190 },
    { type: 'pole', x: 6560, y: -840, h: 190 },
    { type: 'sign', x: 6400, y: -1060, text: 'SI KUMIS & CO', color: '#ff4d6d' },
    // warehouse
    { type: 'beam', x: 7760, y: -980, w: 1880 },
    { type: 'forklift', x: 7880, y: -200 },
    { type: 'boxes', x: 8650, y: -200, w: 120, h: 110 },
    { type: 'boxes', x: 9450, y: -200, w: 100, h: 140 },
    { type: 'exitsign', x: 9600, y: -420 },
    { type: 'hazard', x: 9440, y: -200, w: 200, h: 14 },
    { type: 'chain', x: 8360, y: -1000, len: 440 },
  ],
  exit: { x: 9560, y: -360, w: 80, h: 160 },
  bossHint: 'Mantap! Don Kumis tumbang. Pintu KELUAR di ujung kanan sudah terbuka — ayo kabur!',
};
