import { useEffect, useRef, useState } from 'react';
import { startAbyssalGarden, type EngineHandle, type HudState } from './game/engine';

let bootLock = false;

const CAM_NAMES = ['Standar', 'Megalophobia', 'POV / Kokpit'];

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const barRef = useRef<HTMLElement | null>(null);
  const diveBtnRef = useRef<HTMLButtonElement | null>(null);
  const engineRef = useRef<EngineHandle | null>(null);
  const toastTimerRef = useRef<number>(0);
  const lastSeqRef = useRef<number>(0);
  const labelRefs = useRef<(HTMLDivElement | null)[]>([]);

  const [statusText, setStatusText] = useState('Diving…');
  const [browserHint, setBrowserHint] = useState(false);
  const [hasDived, setHasDived] = useState(false);
  const [detailLv, setDetailLv] = useState<number>(0);
  const [statsText, setStatsText] = useState('');
  const [toast, setToast] = useState('');
  const [hud, setHud] = useState<HudState>({
    inSub: false,
    miniMode: false,
    midnightMode: false,
    nearSub: true,
    subDist: 3.1,
    depth: 42,
    speed: 0,
    lightsOn: true,
    viewMode: 0,
    botsAboard: 0,
    summoning: false,
    mantaFlyby: false,
    mantaDist: 45,
    fishCount: 0,
    fishInventory: [0, 0, 0, 0],
    harpoonPhase: 'ready',
    harpoonTargetVisible: false,
    harpoonTargetX: 0.5,
    harpoonTargetY: 0.5,
    harpoonRecoil: 0,
    toastEvent: '',
    toastSeq: 0,
  });

  const showToast = (msg: string, ms = 2800) => {
    setToast(msg);
    window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(''), ms);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || bootLock) return;
    bootLock = true;
    document.body.className = 'l';

    startAbyssalGarden(canvas, barRef.current, {
      onProgress: (msg) => setStatusText(msg),
      onBrowserHint: (show) => setBrowserHint(show),
      onError: (msg) => setStatusText(msg),
      onMenuChange: (inMenu) => {
        if (inMenu) {
          window.setTimeout(() => diveBtnRef.current?.focus(), 100);
        } else {
          setHasDived(true);
          (document.activeElement as HTMLElement | null)?.blur?.();
        }
      },
      onHud: (next) => {
        if (next.toastSeq !== lastSeqRef.current && next.toastEvent) {
          lastSeqRef.current = next.toastSeq;
          showToast(next.toastEvent, next.mantaFlyby ? 3800 : 2400);
        }
        setHud(next);
      },
      onStats: (s) => setStatsText(s),
      onViewpoint: (idx, name) => showToast(`${idx + 1} · ${name}`),
      onMute: (m) => showToast(m ? 'Suara Mati' : 'Suara Aktif', 1400),
    })
      .then((handle) => {
        engineRef.current = handle;
        setDetailLv(handle.level);
      })
      .catch((e: Error & { userFacing?: boolean }) => {
        console.error(e);
        document.body.className = 'l e';
        setStatusText((e.userFacing ? '' : 'Gagal memulai: ') + e.message);
      });

    return () => {
      window.clearTimeout(toastTimerRef.current);
    };
  }, []);

  // Crew name tags follow heads every frame (direct DOM writes, no React re-render)
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      const eng = engineRef.current;
      if (!eng || !eng.getLabels) return;
      const ls = eng.getLabels();
      for (const l of ls) {
        const el = labelRefs.current[l.i];
        if (!el) continue;
        if (!l.show || document.body.classList.contains('m')) { el.style.opacity = '0'; continue; }
        el.style.opacity = String(l.a);
        el.style.transform = `translate(${l.x.toFixed(1)}px, ${l.y.toFixed(1)}px) translate(-50%, -100%) scale(${(l.s ?? 1).toFixed(3)})`;
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const CREW_TAGS = [
    { name: 'Captain Ashford', role: 'Commander' },
    { name: 'Nathaniel', role: 'Co-Pilot' },
    { name: 'Beatrice', role: 'Navigator' },
    { name: 'Theodore', role: 'Harpooner' },
    { name: 'Eleanor', role: 'Marine Biologist' },
    { name: 'Percival', role: 'Engineer' },
  ];

  const handleDive = () => {
    setHasDived(true);
    engineRef.current?.diveIn();
  };

  const detailLabels = ['Low', 'Medium', 'High'];
  const camBadge = hud.viewMode === 1
    ? 'Megalophobia'
    : hud.viewMode === 3
      ? 'Luar Kapal 3D'
      : hud.viewMode === 2
        ? (hud.inSub ? (hud.inside === 'pilot' ? 'Mode POV Kemudi' : 'Mode POV Kabin') : 'POV Helm 1.4x')
        : (hud.inSub ? 'Kabin 3rd Person' : '3rd Person');

  return (
    <>
      <canvas id="c" ref={canvasRef} />

      {/* Minimal Diegetic In-Game HUD */}
      <div className="hud-layer">
        {/* Camera-specific subtle optical framing */}
        {hud.viewMode === 1 && <div className="mega-frame" />}
        {/* Helmet porthole, fisheye glass & cockpit glass are rendered in 3D/post-FX by the engine. */}
        {hud.midnightMode && <div className="midnight-grain" />}

        {/* Harpoon reticle (diver only) */}
        {!hud.inSub && (
          <div className={`reticle ${hud.aimLock ? 'lock' : ''} ${hud.harpoonPhase !== 'ready' ? 'busy' : ''}`}
            style={{ transform: `translate(-50%, -50%) scale(${1 + hud.harpoonRecoil * 0.35})` }}>
            <i className="r-t" /><i className="r-b" /><i className="r-l" /><i className="r-r" /><b />
          </div>
        )}
        {!hud.inSub && hud.harpoonTargetVisible && (hud.harpoonPhase === 'tethered' || hud.harpoonPhase === 'reeling') && (
          <div className="spear-marker" style={{ left: `${hud.harpoonTargetX * 100}%`, top: `${hud.harpoonTargetY * 100}%` }} />
        )}

        {/* Harpoon status + fish inventory */}
        {!hud.inSub && (
          <div className="harpoon-panel">
            <div className={`hp-state hp-${hud.harpoonPhase}`}>
              <svg viewBox="0 0 64 20" className="hp-icon">
                <rect x="2" y="8" width="16" height="5" rx="2" fill="#6b3416" />
                <rect x="10" y="12" width="4" height="7" rx="1.5" fill="#5a2a10" />
                <rect x="17" y="8.6" width="30" height="3.6" rx="1.6" fill="#d9a24a" />
                {hud.harpoonPhase === 'ready' && <><rect x="12" y="6.2" width="44" height="1.4" fill="#cfd8de" /><path d="M56 4.8 L62 6.9 L56 9 Z" fill="#e6eef2" /></>}
                <circle cx="22" cy="15" r="3.4" fill="none" stroke="#d9a24a" strokeWidth="1.4" />
              </svg>
              <span>
                {hud.harpoonPhase === 'ready' && (hud.aimLock ? 'Ikan terkunci! Klik Kiri' : 'Harpoon siap · Klik Kiri')}
                {hud.harpoonPhase === 'flying' && 'Tombak meluncur…'}
                {hud.harpoonPhase === 'tethered' && 'Ikan tertancap! Klik Kanan tarik'}
                {hud.harpoonPhase === 'reeling' && 'Menggulung tali…'}
                {hud.harpoonPhase === 'miss' && 'Meleset · menarik tombak'}
              </span>
            </div>
            <div className="inv-row">
              {(hud.fishNames ?? ['Badut', 'Kupu-kupu', 'Singa', 'Tang Biru', 'Sarden']).map((n, i) => (
                <div key={n} className={`inv-slot k${i} ${hud.fishInventory[i] ? 'has' : ''}`} title={n}>
                  <svg viewBox="0 0 30 16"><path d="M3 8 Q11 0 21 4 L28 1 L26 8 L28 15 L21 12 Q11 16 3 8 Z" /><circle cx="8" cy="7" r="1.2" fill="#111" /></svg>
                  <b>{hud.fishInventory[i] ?? 0}</b>
                </div>
              ))}
            </div>
            <div className="inv-total">
              Inventori {hud.fishCount} ikan{hud.teamCount ? ` · Kru menangkap ${hud.teamCount}` : ''}
            </div>
          </div>
        )}

        {/* Elegant crew name tags */}
        <div className="name-tags">
          {CREW_TAGS.map((c, i) => (
            <div key={c.name} className="name-tag" ref={(el) => { labelRefs.current[i] = el; }} style={{ opacity: 0 }}>
              <span className="nt-name">{c.name}</span>
              <span className="nt-role">{c.role}</span>
            </div>
          ))}
        </div>

        {hud.megaActive && (hud.megaDist ?? 999) < 60 && (
          <div className={`mega-warn ${(hud.megaDist ?? 99) < 22 ? 'close' : ''}`}>
            <b>MEGALODON</b>
            <span>{hud.megaPhase === 'charge' ? 'MENYERANG!' : hud.megaPhase === 'observe' ? 'sedang mengamati…' : hud.megaPhase === 'leave' ? 'menjauh' : 'mendekat'} · {hud.megaDist}m</span>
          </div>
        )}

        {toast && <div className="scenic-toast">{toast}</div>}

        {/* Contextual interaction prompt (airlock, helm, chairs, bunks, repair) */}
        {hud.interactLabel && !hud.proc && (
          <button type="button" className="board-prompt" onClick={() => engineRef.current?.toggleSubmarine()}>
            <i className="kbd kbd-brass">F</i>
            <span>{hud.interactLabel}</span>
          </button>
        )}

        {/* Airlock procedure: fade to black + professional checklist */}
        {(hud.fade ?? 0) > 0.01 && <div className="airlock-fade" style={{ opacity: hud.fade }} />}
        {hud.proc && (
          <div className="airlock-panel">
            <div className="al-title">{hud.proc.kind === 'enter' ? 'PROSEDUR MASUK · AIRLOCK' : 'PROSEDUR KELUAR · AIRLOCK'}</div>
            {hud.proc.steps.map((st, i) => (
              <div key={st} className={`al-step ${i < hud.proc!.idx ? 'done' : i === hud.proc!.idx ? 'now' : ''}`}>
                <b>{i < hud.proc!.idx ? '✔' : i === hud.proc!.idx ? '▶' : '○'}</b>
                <span>{st}</span>
                {i === hud.proc!.idx && <i className="al-bar"><em style={{ width: `${hud.proc!.progress * 100}%` }} /></i>}
              </div>
            ))}
          </div>
        )}

        {/* Hull integrity */}
        {(hud.inSub || (hud.hull ?? 100) < 100) && (
          <div className={`hull-meter ${(hud.hull ?? 100) < 30 ? 'crit' : ''}`}>
            <span>LAMBUNG</span>
            <i><em style={{ width: `${hud.hull ?? 100}%` }} /></i>
            <b>{hud.hull ?? 100}%</b>
            {hud.repairing && <small>memperbaiki…</small>}
          </div>
        )}

        {/* Compact bottom-left status capsule */}
        {hud.inSub ? (
          <div className="crew-pill sub-mode">
            <span className={hud.viewMode === 1 ? 'crew-dot mega' : 'crew-dot'} />
            <span>Kapal Selam · Kru {1 + hud.botsAboard}/6 · Helm di Rak</span>
            <span className="mini-badge">{hud.inside === 'walk' ? 'Jalan Bebas' : 'Berdiri di Kemudi'}</span>
            {hud.miniMode && <span className="mini-badge">Mungil -60%</span>}
            <span className="pill-sep">·</span>
            <span>-{hud.depth}m · {(hud.speed * 1.94).toFixed(0)} kt</span>
            <span className="pill-sep">·</span>
            <span>{camBadge}</span>
            <span className="pill-sep pill-hint">·</span>
            <span className="pill-hint" onClick={() => engineRef.current?.toggleCockpit()} style={{ cursor: 'pointer' }}>
              <i className="kbd kbd-cyan">K</i> {hud.viewMode === 2 ? 'Kembali 3rd Person' : 'Opsi POV'}
            </span>
            <span className="pill-hint" onClick={() => engineRef.current?.cycleView()} style={{ cursor: 'pointer' }}>
              <i className="kbd">V</i> Kamera
            </span>
            <span className="pill-hint"><i className="kbd">J</i> Megalo</span>
            <span className="pill-hint"><i className="kbd">B</i> Megalodon</span>
            <span className="pill-hint"><i className="kbd kbd-brass">G</i> -60%</span>
            <span className="pill-hint"><i className="kbd">C</i> Manta 10x</span>
            <span className="pill-hint"><i className="kbd">N</i> {hud.midnightMode ? 'Siang' : 'Midnight'}</span>
            <span className="pill-hint"><i className="kbd kbd-brass">F</i> {hud.inside === 'walk' ? 'Interaksi' : 'Lepas Kemudi'}</span>
          </div>
        ) : (
          <div className="crew-pill">
            <span className={hud.viewMode === 1 ? 'crew-dot mega' : 'crew-dot'} />
            <span>Kru 6 Penyelam · Helm 1.4x</span>
            {hud.midnightMode && <span className="mini-badge night">Midnight</span>}
            {hud.miniMode && <span className="mini-badge">Mungil -60%</span>}
            <span className="pill-sep">·</span>
            <span>-{hud.depth}m</span>
            <span className="pill-sep">·</span>
            <span>{camBadge}</span>
            <span className="pill-sep pill-hint">·</span>
            <span className="pill-hint"><i className="kbd kbd-brass">G</i> -60%</span>
            <span className="pill-hint"><i className="kbd">J</i> Megalo</span>
            <span className="pill-hint"><i className="kbd kbd-cyan">K</i> POV</span>
            <span className="pill-hint"><i className="kbd">B</i> Megalodon</span>
            <span className="pill-hint"><i className="kbd">N</i> {hud.midnightMode ? 'Siang' : 'Midnight'}</span>
            {hud.subDist > 8 && (
              <span className="pill-hint">
                <i className="kbd kbd-brass">R</i> {hud.summoning ? 'Datang…' : `Kapal (${Math.round(hud.subDist)}m)`}
              </span>
            )}
          </div>
        )}

        {/* Touch action buttons for mobile/tablet */}
        <div className="touch-bar">
          <button
            type="button"
            className="touch-btn gold"
            onClick={() => engineRef.current?.toggleSubmarine()}
          >
            {hud.inSub ? (hud.inside === 'pilot' ? 'Lepas Kemudi (F)' : 'Interaksi (F)') : (hud.hatchDist ?? 99) < 14 ? 'Airlock (F)' : 'Panggil Kapal'}
          </button>
          <button
            type="button"
            className={`touch-btn ${hud.viewMode === 2 ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleCockpit()}
          >
            {hud.inSub ? (hud.viewMode === 2 ? '3rd Person' : 'Opsi POV (K)') : 'POV'}
          </button>
          {hud.inSub && (
            <button
              type="button"
              className="touch-btn"
              onClick={() => engineRef.current?.cycleView()}
            >
              Kamera (V)
            </button>
          )}
          <button
            type="button"
            className={`touch-btn ${hud.viewMode === 1 ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMegalophobia()}
          >
            Megalo
          </button>
          <button
            type="button"
            className={`touch-btn gold ${hud.miniMode ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMiniMode()}
          >
            -60%
          </button>
          <button
            type="button"
            className="touch-btn"
            onClick={() => engineRef.current?.toggleLights()}
          >
            Lampu
          </button>
          <button
            type="button"
            className={`touch-btn ${hud.midnightMode ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMidnight()}
          >
            Midnight
          </button>
          <button type="button" className="touch-btn" onClick={() => engineRef.current?.spawnMegalodon()}>Megalodon</button>
          {!hud.inSub && (
            <>
              <button type="button" className="touch-btn gold" onClick={() => engineRef.current?.fireHarpoon()}>Tembak</button>
              <button type="button" className="touch-btn" onClick={() => engineRef.current?.reelHarpoon()}>Tarik</button>
            </>
          )}
        </div>
      </div>

      {/* Abyssal Garden Start & Pause Menu (with Size -60% & Camera Mode Selectors) */}
      <div id="m">
        <h1>Abyssal Garden</h1>
        <p className="sub-tag">Scuba Klasik · Harpoon Gun · Midnight & Megalodon · Kru Hidup · Kokpit Kabin</p>

        <div id="a">
          <div id="l">
            <div id="p"><i id="b" ref={barRef} /></div>
            <p id="s">{statusText}</p>
            <p id="w" hidden={!browserHint}>Use Google Chrome for optimal experience</p>
          </div>

          <div id="g">
            <button id="d" ref={diveBtnRef} className="ag-btn" type="button" onClick={handleDive}>
              {hasDived ? 'Resume' : 'Dive in'}
            </button>

            {/* Size mode selector: Standard vs 60% Smaller Miniature Diver + Submarine */}
            <p className="opt-row">
              <span>Ukuran</span>
              <button
                type="button"
                className={!hud.miniMode ? 'ag-btn on' : 'ag-btn'}
                onClick={() => engineRef.current?.toggleMiniMode(false)}
              >
                Standar
              </button>
              <button
                type="button"
                className={hud.miniMode ? 'ag-btn on-brass' : 'ag-btn'}
                onClick={() => engineRef.current?.toggleMiniMode(true)}
              >
                Mungil -60%
              </button>
            </p>

            {/* Camera mode selector: Standar / Megalophobia / POV & 3D Cockpit */}
            <p className="opt-row">
              <span>Kamera</span>
              {CAM_NAMES.map((name, idx) => (
                <button
                  key={name}
                  type="button"
                  className={hud.viewMode === idx ? 'ag-btn on' : 'ag-btn'}
                  onClick={() => engineRef.current?.setViewMode(idx)}
                >
                  {name}
                </button>
              ))}
            </p>

            {/* Time of day: Siang vs Midnight (only personal lamps) */}
            <p className="opt-row">
              <span>Waktu</span>
              <button type="button" className={!hud.midnightMode ? 'ag-btn on' : 'ag-btn'} onClick={() => engineRef.current?.toggleMidnight(false)}>
                Siang
              </button>
              <button type="button" className={hud.midnightMode ? 'ag-btn on-night' : 'ag-btn'} onClick={() => engineRef.current?.toggleMidnight(true)}>
                Midnight
              </button>
            </p>

            {/* Original Quality / Detail selector */}
            <p className="opt-row">
              <span>Detail</span>
              {detailLabels.map((label, i) => {
                const lv = 2 - i;
                return (
                  <button
                    key={label}
                    type="button"
                    className={lv === detailLv ? 'ag-btn on' : 'ag-btn'}
                    onClick={() => engineRef.current?.setDetail(lv)}
                  >
                    {label}
                  </button>
                );
              })}
            </p>

            <div id="k">
              <p>
                <i><b>W</b><b>A</b><b>S</b><b>D</b></i><span>Renang / Kemudi</span>
                <i><b>Q</b><b>E</b></i><span>Turun / Naik</span>
                <i><b>Shift</b></i><span>Lebih Cepat</span>
                <i><b className="kbd-brass">F</b></i><span>Airlock · Kemudi · Duduk · Ranjang · Perbaiki</span>
                <i><b>R</b></i><span>Panggil Kapal · <b>L</b> Lampu</span>
                <i><b className="kbd-brass">Klik Kiri</b></i><span>Tembak Harpoon</span>
              </p>
              <p>
                <i><b className="kbd-brass">G</b></i><span>Mode Mungil -60%</span>
                <i><b className="kbd-cyan">K</b></i><span>Kokpit 3D / POV Helm</span>
                <i><b>J</b></i><span>Kamera Megalophobia · <b>B</b> Panggil Megalodon</span>
                <i><b>V</b></i><span>Ganti Kamera · <b>C</b> Sapa/Manta</span>
                <i><b>1</b>–<b>6</b></i><span>Lokasi · <b>M</b> Suara · <b>H</b> FPS</span>
                <i><b className="kbd-cyan">Klik Kanan</b></i><span>Tarik Tali · <b>N</b> Midnight</span>
              </p>
            </div>

            <p id="h">Tahan untuk berenang/mengemudi · geser untuk belok · 2 jari lebih cepat</p>
          </div>
        </div>

        <p id="f">
          <a href="https://github.com/Noniv/abyssal-garden" target="_blank" rel="noreferrer">
            <svg viewBox="0 0 16 16">
              <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z" />
            </svg>
            GitHub
          </a>
          <a href="https://ko-fi.com/noniv" target="_blank" rel="noreferrer">
            <svg viewBox="0 0 24 24">
              <path fillRule="evenodd" d="M2 5h16.5a4.5 4.5 0 0 1 0 9H17a6 6 0 0 1-6 5H8a6 6 0 0 1-6-6zM17 8v3h1.5a1.5 1.5 0 0 0 0-3zM9.5 15.5 5.9 12a2.2 2.2 0 0 1 3.6-2.5 2.2 2.2 0 0 1 3.6 2.5z" />
            </svg>
            Support
          </a>
        </p>
      </div>

      <button
        id="o"
        className="ag-btn"
        type="button"
        aria-label="Menu"
        onClick={() => engineRef.current?.openMenu()}
      >
        ≡
      </button>
      <pre id="i">{statsText}</pre>
    </>
  );
}

export default App;
