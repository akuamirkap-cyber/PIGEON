// Software pixel framebuffer + primitives. Everything in the game is drawn here, pixel by pixel.
export const W = 384;
export const H = 216;
export const HZ = 100; // horizon row

/** '#rrggbb' -> packed ABGR (little endian RGBA) */
export function hex(s: string): number {
  const n = parseInt(s.charAt(0) === '#' ? s.slice(1) : s, 16);
  return (0xff000000 | ((n & 0xff) << 16) | (n & 0xff00) | ((n >> 16) & 0xff)) >>> 0;
}

export function mix(a: number, b: number, t: number): number {
  if (t <= 0) return a;
  if (t >= 1) return b;
  const ar = a & 255, ag = (a >> 8) & 255, ab = (a >> 16) & 255;
  const r = ar + ((b & 255) - ar) * t;
  const g = ag + (((b >> 8) & 255) - ag) * t;
  const bl = ab + (((b >> 16) & 255) - ab) * t;
  return (0xff000000 | ((bl & 255) << 16) | ((g & 255) << 8) | (r & 255)) >>> 0;
}

export function mul(c: number, r: number, g: number, b: number): number {
  let cr = (c & 255) * r, cg = ((c >> 8) & 255) * g, cb = ((c >> 16) & 255) * b;
  if (cr > 255) cr = 255;
  if (cg > 255) cg = 255;
  if (cb > 255) cb = 255;
  return (0xff000000 | ((cb & 255) << 16) | ((cg & 255) << 8) | (cr & 255)) >>> 0;
}

export function shade(c: number, f: number): number {
  return mul(c, f, f, f);
}

export const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map((v) => (v + 0.5) / 16);
export function bayer(x: number, y: number): number {
  return BAYER[((y & 3) << 2) | (x & 3)];
}

export function rng(seed: number): () => number {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13; s >>>= 0;
    s ^= s >>> 17;
    s ^= s << 5; s >>>= 0;
    return s / 4294967296;
  };
}

export function hash2(x: number, y: number): number {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

const SL = new Float32Array(4096);
for (let i = 0; i < 4096; i++) SL[i] = Math.sin((i / 4096) * Math.PI * 2);
/** fast sine lookup */
export function fsin(a: number): number {
  return SL[((a * 651.89864) | 0) & 4095];
}

export function clamp(v: number, a: number, b: number): number {
  return v < a ? a : v > b ? b : v;
}

export class Surface {
  w: number;
  h: number;
  d: Uint32Array;
  /** optional anchors (fish: mouth x/y and belly row) */
  ax = 0;
  ay = 0;
  ab = 0;
  constructor(w: number, h: number) {
    this.w = Math.max(1, w | 0);
    this.h = Math.max(1, h | 0);
    this.d = new Uint32Array(this.w * this.h);
  }
  px(x: number, y: number, c: number) {
    x = Math.round(x); y = Math.round(y);
    if (x >= 0 && y >= 0 && x < this.w && y < this.h) this.d[y * this.w + x] = c;
  }
  get(x: number, y: number): number {
    x = Math.round(x); y = Math.round(y);
    return x >= 0 && y >= 0 && x < this.w && y < this.h ? this.d[y * this.w + x] : 0;
  }
  blend(x: number, y: number, c: number, a: number) {
    x = Math.round(x); y = Math.round(y);
    if (x >= 0 && y >= 0 && x < this.w && y < this.h) {
      const i = y * this.w + x;
      this.d[i] = mix(this.d[i], c, a);
    }
  }
  rect(x: number, y: number, w: number, h: number, c: number) {
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    const x1 = Math.min(this.w, x + w), y1 = Math.min(this.h, y + h);
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x1 <= x) return;
    for (let yy = y; yy < y1; yy++) this.d.fill(c, yy * this.w + x, yy * this.w + x1);
  }
  rectA(x: number, y: number, w: number, h: number, c: number, a: number) {
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    const x1 = Math.min(this.w, x + w), y1 = Math.min(this.h, y + h);
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    for (let yy = y; yy < y1; yy++) {
      const r = yy * this.w;
      for (let xx = x; xx < x1; xx++) this.d[r + xx] = mix(this.d[r + xx], c, a);
    }
  }
  /** ordered-dither fill */
  rectD(x: number, y: number, w: number, h: number, c: number, lvl: number) {
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    const x1 = Math.min(this.w, x + w), y1 = Math.min(this.h, y + h);
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    for (let yy = y; yy < y1; yy++) {
      const r = yy * this.w;
      for (let xx = x; xx < x1; xx++) if (BAYER[((yy & 3) << 2) | (xx & 3)] < lvl) this.d[r + xx] = c;
    }
  }
  line(x0: number, y0: number, x1: number, y1: number, c: number) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    let e = dx + dy, n = 0;
    for (;;) {
      if (x0 >= 0 && y0 >= 0 && x0 < this.w && y0 < this.h) this.d[y0 * this.w + x0] = c;
      if ((x0 === x1 && y0 === y1) || ++n > 1200) break;
      const e2 = 2 * e;
      if (e2 >= dy) { e += dy; x0 += sx; }
      if (e2 <= dx) { e += dx; y0 += sy; }
    }
  }
  disc(cx: number, cy: number, r: number, c: number) {
    cx = Math.round(cx); cy = Math.round(cy);
    const rr = r * r + r * 0.8;
    for (let dy = -Math.ceil(r); dy <= Math.ceil(r); dy++) {
      const q = rr - dy * dy;
      if (q < 0) continue;
      const w = Math.floor(Math.sqrt(q));
      this.rect(cx - w, cy + dy, 2 * w + 1, 1, c);
    }
  }
  ell(cx: number, cy: number, rx: number, ry: number, c: number) {
    cx = Math.round(cx); cy = Math.round(cy);
    for (let dy = -Math.ceil(ry); dy <= Math.ceil(ry); dy++) {
      const q = 1 - (dy * dy) / (ry * ry + ry * 0.6 + 0.01);
      if (q < 0) continue;
      const w = Math.floor(Math.sqrt(q) * rx);
      this.rect(cx - w, cy + dy, 2 * w + 1, 1, c);
    }
  }
  /** ellipse outline; skip>0 breaks it into dashes */
  ring(cx: number, cy: number, rx: number, ry: number, c: number, skip = 0, ph = 0) {
    const n = Math.max(10, ((rx + ry) * 3.2) | 0);
    for (let i = 0; i < n; i++) {
      if (skip && (((i + ph) / skip) | 0) & 1) continue;
      const a = (i / n) * Math.PI * 2;
      this.px(cx + Math.cos(a) * rx, cy + Math.sin(a) * ry, c);
    }
  }
  blit(s: Surface, x: number, y: number, flip = false, l: number[] | null = null, clipY = 99999, sh = 0) {
    x = Math.round(x); y = Math.round(y);
    const TW = this.w, TH = this.h, d = this.d, sd = s.d, sw = s.w, shh = s.h;
    for (let r = 0; r < shh; r++) {
      const yy = y + r;
      if (yy < 0 || yy >= TH || yy > clipY) continue;
      const xo = x + (sh ? Math.round((shh - 1 - r) * sh) : 0);
      const ro = r * sw, row = yy * TW;
      for (let c = 0; c < sw; c++) {
        const v = sd[ro + (flip ? sw - 1 - c : c)];
        if (!v) continue;
        const xx = xo + c;
        if (xx < 0 || xx >= TW) continue;
        d[row + xx] = l ? mul(v, l[0], l[1], l[2]) : v;
      }
    }
  }
  /** indexed sprite (values 1..n) drawn through a palette */
  blitPal(s: Surface, x: number, y: number, pal: number[], flip = false) {
    x = Math.round(x); y = Math.round(y);
    const TW = this.w, TH = this.h, d = this.d, sd = s.d, sw = s.w;
    for (let r = 0; r < s.h; r++) {
      const yy = y + r;
      if (yy < 0 || yy >= TH) continue;
      for (let c = 0; c < sw; c++) {
        const v = sd[r * sw + (flip ? sw - 1 - c : c)];
        if (!v) continue;
        const xx = x + c;
        if (xx < 0 || xx >= TW) continue;
        d[yy * TW + xx] = pal[v];
      }
    }
  }
  blitTint(s: Surface, x: number, y: number, col: number, flip = false, a = 1) {
    x = Math.round(x); y = Math.round(y);
    const TW = this.w, TH = this.h, d = this.d, sd = s.d, sw = s.w;
    for (let r = 0; r < s.h; r++) {
      const yy = y + r;
      if (yy < 0 || yy >= TH) continue;
      for (let c = 0; c < sw; c++) {
        if (!sd[r * sw + (flip ? sw - 1 - c : c)]) continue;
        const xx = x + c;
        if (xx < 0 || xx >= TW) continue;
        const i = yy * TW + xx;
        d[i] = a >= 1 ? col : mix(d[i], col, a);
      }
    }
  }
  /** rotated + scaled nearest-neighbour blit around centre; wA/wP = body wave amplitude/phase (tail flaps) */
  blitRot(s: Surface, cx: number, cy: number, ang: number, sc = 1, flip = false, l: number[] | null = null, clipY = 99999, flash = 0, flashA = 0, wA = 0, wP = 0) {
    const cs = Math.cos(ang), sn = Math.sin(ang);
    const rad = Math.ceil((Math.sqrt(s.w * s.w + s.h * s.h) / 2) * sc) + 2 + Math.ceil(wA);
    const x0 = Math.max(0, Math.floor(cx - rad)), x1 = Math.min(this.w - 1, Math.ceil(cx + rad));
    const y0 = Math.max(0, Math.floor(cy - rad)), y1 = Math.min(this.h - 1, Math.min(clipY, Math.ceil(cy + rad)));
    const inv = 1 / sc, hw = s.w / 2, hh = s.h / 2, sd = s.d, sw = s.w, shh = s.h, d = this.d, TW = this.w;
    const wK = 7 / sw;
    for (let y = y0; y <= y1; y++) {
      const dy = y + 0.5 - cy;
      for (let x = x0; x <= x1; x++) {
        const dx = x + 0.5 - cx;
        let u = Math.floor((dx * cs + dy * sn) * inv + hw);
        if (u < 0 || u >= sw) continue;
        if (flip) u = sw - 1 - u;
        let vf = (-dx * sn + dy * cs) * inv + hh;
        if (wA) { const tp = u / sw; vf += wA * fsin(u * wK + wP) * tp * tp; }
        const v = Math.floor(vf);
        if (v < 0 || v >= shh) continue;
        let c = sd[v * sw + u];
        if (!c) continue;
        if (l) c = mul(c, l[0], l[1], l[2]);
        if (flashA > 0) c = mix(c, flash, flashA);
        d[y * TW + x] = c;
      }
    }
  }
  /** integer up-scaled blit */
  blitScale(s: Surface, x: number, y: number, k: number, flip = false, l: number[] | null = null) {
    for (let r = 0; r < s.h; r++)
      for (let c = 0; c < s.w; c++) {
        const v = s.d[r * s.w + (flip ? s.w - 1 - c : c)];
        if (v) this.rect(x + c * k, y + r * k, k, k, l ? mul(v, l[0], l[1], l[2]) : v);
      }
  }
  /** thick segment made of w*w stamps (limbs) */
  limb(x0: number, y0: number, x1: number, y1: number, w: number, c: number) {
    const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
    const o = (w - 1) / 2;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      this.rect(Math.round(x0 + (x1 - x0) * t - o), Math.round(y0 + (y1 - y0) * t - o), w, w, c);
    }
  }
}

export function fromStrings(rows: string[], pal: Record<string, number>): Surface {
  const w = rows.reduce((m, r) => Math.max(m, r.length), 0);
  const s = new Surface(w, rows.length);
  for (let y = 0; y < rows.length; y++)
    for (let x = 0; x < rows[y].length; x++) {
      const c = pal[rows[y][x]];
      if (c) s.d[y * w + x] = c;
    }
  return s;
}

/** adds a 1px outline around every opaque shape */
export function outlined(s: Surface, col: number): Surface {
  const o = new Surface(s.w + 2, s.h + 2);
  for (let y = 0; y < o.h; y++)
    for (let x = 0; x < o.w; x++) {
      const c = s.get(x - 1, y - 1);
      if (c) o.d[y * o.w + x] = c;
      else if (s.get(x - 2, y - 1) || s.get(x, y - 1) || s.get(x - 1, y - 2) || s.get(x - 1, y)) o.d[y * o.w + x] = col;
    }
  return o;
}
