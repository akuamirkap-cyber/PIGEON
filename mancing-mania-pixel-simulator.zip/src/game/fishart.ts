// Procedural pixel-art fish generator. Every species is a parameter set -> a shaded, outlined sprite.
import { Surface, hex, mix, shade, bayer, hash2, outlined } from './gfx';

export type FinShape = 'tri' | 'sickle' | 'spiny' | 'sail' | 'long' | 'round' | 'finlets' | 'marlin';
export interface Fin {
  side: 1 | -1;
  a: number;
  b: number;
  h: number;
  shape: FinShape;
  sweep?: number;
  col?: string;
}
export interface FishLook {
  len: number; // body length px (nose -> tail base)
  depth: number; // max body height / len
  peak: number; // where the body is deepest (0..1)
  nose: number; // head profile exponent (small = blunt)
  taper: number; // tail taper exponent
  ped: number; // tail-stalk thickness (fraction of depth)
  up: number; // share of depth above the mid line
  back: string;
  side: string;
  belly: string;
  fin: string;
  accent: string;
  pattern: 'none' | 'bars' | 'spots' | 'stripes' | 'wavy' | 'dots' | 'tiger';
  tail: 'fork' | 'lunate' | 'round' | 'shark';
  tailLen: number;
  tailSpread: number;
  fins: Fin[];
  bill?: number;
  eye?: number;
  tailCol?: string;
  band?: string;
  shine?: boolean;
  gills?: boolean;
}

export function makeFish(k: FishLook): Surface {
  const L = Math.round(k.len);
  const hb = Math.max(5, Math.round(L * k.depth));
  const bill = Math.round(L * (k.bill || 0));
  const tl = Math.max(4, Math.round(L * k.tailLen));
  const ts = Math.max(3, Math.round(hb * k.tailSpread));
  let finUp = 0, finDn = 0;
  for (const f of k.fins) {
    const fh = Math.round(hb * f.h) + 2;
    if (f.side > 0) finUp = Math.max(finUp, fh);
    else finDn = Math.max(finDn, fh);
  }
  const upH = Math.round(hb * k.up), dnH = hb - upH;
  const top = Math.max(upH + finUp, ts) + 5;
  const bot = Math.max(dnH + finDn, ts) + 5;
  const w = bill + L + tl + 4, h = top + bot + 1;
  const s = new Surface(w, h);
  const cy = top, x0 = 2 + bill;

  const prof = (t: number) => {
    if (t < k.peak) return Math.pow(Math.sin(((t / k.peak) * Math.PI) / 2), k.nose);
    const u = (t - k.peak) / (1 - k.peak);
    return k.ped + (1 - k.ped) * Math.pow(0.5 + 0.5 * Math.cos(Math.PI * u), k.taper);
  };
  const topY: number[] = [], botY: number[] = [];
  for (let i = 0; i < L; i++) {
    const p = prof(i / (L - 1));
    topY.push(Math.round(cy - upH * p));
    botY.push(Math.round(cy + dnH * p));
  }

  const cBack = hex(k.back), cSide = hex(k.side), cBelly = hex(k.belly), cFin = hex(k.fin), cAcc = hex(k.accent);
  const cBackD = shade(cBack, 0.74);
  const cBellyD = mix(cBelly, cSide, 0.55);
  const cHi = mix(cSide, 0xffffffff, 0.55);
  const cOut = mix(shade(cBack, 0.3), hex('#0a0d24'), 0.55);
  const cTail = hex(k.tailCol || k.fin);

  // ---- tail
  const pedH = Math.max(1, Math.round((hb * k.ped) / 2));
  const tx0 = x0 + L - 2;
  for (let i = 0; i <= tl; i++) {
    const u = i / tl;
    let uo = 0, ui = 0, lo = 0, li = 0;
    if (k.tail === 'fork') {
      uo = lo = pedH + (ts - pedH) * Math.pow(u, 0.75);
      ui = li = u > 0.38 ? ts * Math.pow((u - 0.38) / 0.62, 1.1) * 0.9 : 0;
    } else if (k.tail === 'lunate') {
      uo = lo = pedH * (1 - u) + ts * Math.pow(u, 0.55);
      ui = li = u > 0.2 ? ts * Math.pow((u - 0.2) / 0.8, 0.7) * 0.92 : 0;
    } else if (k.tail === 'round') {
      const e = pedH + (ts - pedH) * Math.sin((Math.min(1, u * 1.3) * Math.PI) / 2);
      uo = lo = u > 0.72 ? e * (1 - Math.pow((u - 0.72) / 0.28, 2) * 0.55) : e;
    } else {
      uo = pedH + (ts - pedH) * Math.pow(u, 0.9);
      ui = u > 0.28 ? ts * Math.pow((u - 0.28) / 0.72, 1.15) * 0.86 : 0;
      lo = u < 0.6 ? pedH + (ts * 0.6 - pedH) * Math.pow(u / 0.6, 0.8) : 0;
      li = u > 0.2 && u < 0.6 ? ts * 0.6 * Math.pow((u - 0.2) / 0.4, 1.2) * 0.8 : 0;
    }
    const x = tx0 + i;
    const put = (y: number, ext: number) => {
      const band = ((Math.abs(y - cy) * 5) / Math.max(1, ext)) | 0;
      s.px(x, y, band % 2 === 1 ? shade(cTail, 0.82) : cTail);
    };
    if (ui <= 0.5 && li <= 0.5) {
      for (let y = Math.round(cy - uo); y <= Math.round(cy + lo); y++) put(y, Math.max(uo, lo));
    } else {
      for (let y = Math.round(cy - uo); y <= Math.round(cy - ui); y++) put(y, uo);
      if (lo > 0) for (let y = Math.round(cy + li); y <= Math.round(cy + lo); y++) put(y, lo);
    }
  }

  // ---- fins (behind the body)
  for (const f of k.fins) {
    const xa = Math.round(f.a * (L - 1)), xb = Math.round(f.b * (L - 1));
    const n = Math.max(1, xb - xa);
    const fh = hb * f.h;
    const col = hex(f.col || k.fin);
    for (let i = 0; i <= n; i++) {
      const u = i / n;
      let hh = 0;
      switch (f.shape) {
        case 'tri': hh = u < 0.3 ? u / 0.3 : 1 - (u - 0.3) / 0.7; break;
        case 'sickle': hh = u < 0.28 ? Math.pow(u / 0.28, 0.7) : Math.max(0.15, 1 - (u - 0.28) * 3.2); break;
        case 'spiny': hh = Math.pow(Math.sin(Math.PI * Math.min(1, u * 1.06)), 0.55) * (1 - 0.25 * u) * (i % 3 === 0 ? 0.7 : 1); break;
        case 'sail': hh = (0.5 + 0.5 * Math.sin(Math.PI * Math.pow(u, 0.8))) * Math.min(1, u / 0.07) * Math.min(1, (1 - u) / 0.1) * (i % 4 === 0 ? 0.9 : 1); break;
        case 'marlin': hh = u < 0.12 ? u / 0.12 : Math.max(0.16, 1 - (u - 0.12) * 2.6); break;
        case 'long': hh = Math.min(1, u / 0.07) * (1 - 0.72 * u) * Math.min(1, (1 - u) / 0.05); break;
        case 'round': hh = Math.pow(Math.sin(Math.PI * u), 0.7); break;
        case 'finlets': hh = i % 3 === 0 ? 1 : i % 3 === 1 ? 0.5 : 0; break;
      }
      const bi = Math.min(L - 1, xa + i);
      const baseY = f.side > 0 ? topY[bi] : botY[bi];
      const hp = Math.round(hh * fh);
      for (let j = 0; j <= hp; j++) {
        const sx = x0 + xa + i + Math.round(j * (f.sweep || 0));
        const sy = f.side > 0 ? baseY - j : baseY + j;
        let c = i % 3 === 0 ? shade(col, 0.8) : col;
        if (j === hp && hp > 1) c = mix(col, 0xffffffff, 0.25);
        if (f.shape === 'sail' && j < hp - 1 && j > 1 && hash2(i >> 1, j >> 1) < 0.1) c = shade(col, 0.5);
        s.px(sx, sy, c);
      }
    }
  }

  // ---- body
  const spot = L > 90 ? 3 : 2;
  const nb = Math.max(6, Math.round(L / 9));
  const cBand = k.band ? hex(k.band) : 0;
  for (let i = 0; i < L; i++) {
    const t = i / (L - 1), x = x0 + i;
    const y0 = topY[i], y1 = botY[i], span = Math.max(1, y1 - y0);
    for (let y = y0; y <= y1; y++) {
      const v = (y - y0) / span;
      const vd = v + (bayer(x, y) - 0.5) * 0.14;
      let c = vd < 0.15 ? cBackD : vd < 0.42 ? cBack : vd < 0.5 && t > 0.12 && t < 0.82 ? cHi : vd < 0.7 ? cSide : vd < 0.9 ? cBelly : cBellyD;
      switch (k.pattern) {
        case 'bars': if (vd < 0.64 && t > 0.2 && t < 0.95 && (t * nb + 0.25 * v) % 1 < 0.36) c = mix(c, cAcc, 0.75); break;
        case 'tiger': if (t > 0.2 && t < 0.96 && v < 0.62 && (t * nb) % 1 < 0.34 * (1 - v) + 0.06) c = mix(c, cAcc, 0.7); break;
        case 'spots': if (t > 0.14 && vd < 0.82 && hash2((i / spot) | 0, ((y - cy + 99) / spot) | 0) < 0.26) c = mix(c, cAcc, 0.8); break;
        case 'stripes': if (v > 0.52 && v < 0.94 && t > 0.3 && t < 0.92 && (y - cy + 60) % 3 === 1) c = cAcc; break;
        case 'wavy': if (vd < 0.42 && t > 0.2 && Math.sin(i * 1.1 + y * 0.9) > 0.3) c = cAcc; break;
        case 'dots': if (t > 0.1 && v < 0.8 && hash2(i, y) < 0.07) c = cAcc; break;
      }
      if (cBand && v > 0.44 && v < 0.57 && t > 0.2 && t < 0.93) c = cBand;
      s.px(x, y, c);
    }
  }

  // ---- head details
  const gi = Math.round(L * Math.min(0.24, k.peak * 0.72 + 0.03));
  if (k.gills) {
    for (let g = 0; g < 4; g++) {
      const gx = x0 + gi + g * 3;
      for (let y = cy - Math.round(hb * 0.14); y <= cy + Math.round(hb * 0.12); y++) s.px(gx, y, shade(s.get(gx, y), 0.66));
    }
  } else {
    const ya = cy - Math.round(upH * 0.6), yb = cy + Math.round(dnH * 0.6);
    for (let y = ya; y <= yb; y++) {
      const xx = x0 + gi + Math.round(Math.sin(((y - ya) / Math.max(1, yb - ya)) * Math.PI) * Math.max(1, hb * 0.07));
      const cur = s.get(xx, y);
      if (cur) s.px(xx, y, shade(cur, 0.72));
    }
  }
  // mouth
  const ml = Math.max(2, Math.round(L * 0.085));
  for (let i = 0; i < ml; i++) {
    const mx = x0 + i, my = cy + 1 + Math.round((i / ml) * dnH * 0.22);
    if (s.get(mx, my)) s.px(mx, my, cOut);
  }
  // eye
  const er = Math.max(1, Math.min(4, Math.round(hb * 0.085 * (k.eye || 1))));
  const ex = x0 + Math.max(er + 2, Math.round(L * 0.105)), ey = cy - Math.round(upH * 0.24);
  s.disc(ex, ey, er, hex(k.shine ? '#fff6c0' : '#fdf6dc'));
  s.disc(ex, ey, Math.max(0, er - 1), hex('#10101c'));
  if (er >= 2) s.px(ex - 1, ey - 1, 0xffffffff);
  // bill
  for (let i = 1; i <= bill; i++) {
    s.px(x0 - i, cy - 1, cBackD);
    if (i < bill * 0.45) s.px(x0 - i, cy, cBack);
    if (i < bill * 0.16) s.px(x0 - i, cy + 1, cSide);
  }
  // pectoral fin
  const pl = Math.round(L * (k.gills ? 0.2 : 0.13));
  const px0 = x0 + Math.round(L * Math.min(0.34, k.peak * 0.8 + 0.07)), py0 = cy + Math.round(dnH * 0.28);
  for (let i = 0; i < pl; i++) {
    const wv = Math.max(1, Math.round(Math.sin((Math.PI * i) / pl) * Math.max(1.5, hb * 0.1)));
    const yy = py0 + Math.round(i * (k.gills ? 0.75 : 0.42));
    for (let j = 0; j < wv; j++) s.px(px0 + i, yy + j, j === 0 ? shade(cFin, 0.62) : cFin);
  }
  // golden sparkle
  if (k.shine) {
    const spk = [[0.3, -0.5], [0.52, -0.2], [0.7, -0.35], [0.42, 0.3], [0.85, 0]];
    for (const [fx, fy] of spk) {
      const sx = x0 + Math.round(L * fx), sy = cy + Math.round(hb * 0.5 * fy);
      s.px(sx, sy, 0xffffffff); s.px(sx - 1, sy, hex('#fff8c8')); s.px(sx + 1, sy, hex('#fff8c8'));
      s.px(sx, sy - 1, hex('#fff8c8')); s.px(sx, sy + 1, hex('#fff8c8'));
    }
  }
  const o = outlined(s, cOut);
  o.ax = x0 + 2; // mouth (line attaches here, behind the bill)
  o.ay = cy + 2;
  o.ab = cy + dnH + 1; // belly row
  return o;
}

/** flat-colour copy (used for "unknown fish" silhouettes) */
export function silhouette(s: Surface, col: number): Surface {
  const o = new Surface(s.w, s.h);
  for (let i = 0; i < s.d.length; i++) if (s.d[i]) o.d[i] = col;
  return o;
}
