// MANCING MANIA — game engine: world simulation + software pixel renderer.
import { Surface, W, H, HZ, hex, mix, mul, shade, bayer, BAYER, rng, hash2, fsin, clamp } from './gfx';
import { makeFish } from './fishart';
import { SPECIES, LURES, ZONES, ROD, LINE, REEL, BOAT, THEMES, FISH_STR, DOLPHIN, baitAff, newSave } from './data';
import type { Species, Save, ThemeRaw } from './data';
import { EXCL, ARROW, makeBoat, makeCloud, makeHeads, PALM, PINISI } from './sprites';
import type { BoatSpr } from './sprites';

export type Phase = 'title' | 'sail' | 'pick' | 'aim' | 'fly' | 'sink' | 'wait' | 'bite' | 'fight' | 'landing' | 'pamer' | 'caught' | 'fail';
export interface AudioAPI {
  play(n: string, v?: number): void;
  loop(n: string, lvl: number): void;
  music(k: string): void;
}
export interface CatchInfo { sp: Species; kg: number; cm: number; secs: number; prev: number; value: number; record: boolean; first: boolean; monster: boolean; q: number }
export interface Spot { id: number; x: number; zone: number; left: number; gold: boolean; hot: number; birds: { a: number; r: number; h: number; sp: number; ph: number }[] }
interface Part { x: number; y: number; vx: number; vy: number; life: number; max: number; col: number; g: number; by: number; kind: number }
interface Rip { x: number; y: number; max: number; life: number; dur: number; col: number }
interface Isle { lx: number; w: number; hgt: number[]; kind: number; far: boolean; p: number; palms: number[]; seed: number; light: boolean }
interface TC {
  sky: number[]; sun: number; glow: number; sunX: number; sunY: number; sunR: number;
  cl: number; cm: number; cs: number; isl: number; lit: number; far: number; sand: number; rock: number;
  seaA: number; seaB: number; seaC: number; hi: number; glint: number; l: number[]; stars: number;
}
export interface Fight {
  ci: CatchInfo; spr: Surface; sc: number; ratio: number; k: number; stam: number; dist: number; tension: number; strain: number; slack: number; omega: number;
  state: 'pull' | 'run' | 'tired' | 'jump'; stT: number; lat: number; latT: number; latTimer: number; ex: number; ey: number; sweetT: number; combo: number;
  jump: null | { t: number; dur: number; dir: number; x0: number; y0: number; apex: number; hit: boolean; travel: number; sub: number };
  tick: number; sprT: number; cap: number; gain: number; jumps: number; fx: number; fy: number; fa: number; mx: number; my: number; hitFlash: number; time: number;
}

const BOAT_Y = 150;
const FISH_SX = 84;
const rowScale = (y: number) => 0.25 + (0.75 * (y - HZ)) / 50;
const K = {
  dark: hex('#141126'), navy: hex('#101a38'), gold: hex('#f2c14e'), white: 0xffffffff, red: hex('#e8483a'), green: hex('#4fd65a'),
  z0: hex('#3f7fd8'), z1: hex('#2fb8a0'), z2: hex('#5fe06a'), z3: hex('#f2b82e'), z4: hex('#e8483a'),
};
const toTC = (r: ThemeRaw): TC => ({
  sky: r.sky.map(hex), sun: hex(r.sun), glow: hex(r.glow), sunX: r.sunX, sunY: r.sunY, sunR: r.sunR,
  cl: hex(r.cl), cm: hex(r.cm), cs: hex(r.cs), isl: hex(r.isl), lit: hex(r.lit), far: hex(r.far), sand: hex(r.sand), rock: hex(r.rock),
  seaA: hex(r.seaA), seaB: hex(r.seaB), seaC: hex(r.seaC), hi: hex(r.hi), glint: hex(r.glint), l: r.l.slice(), stars: r.stars,
});
function blendTC(a: TC, b: TC, f: number): TC {
  if (f <= 0) return a;
  if (f >= 1) return b;
  const m = (x: number, y: number) => mix(x, y, f);
  const n = (x: number, y: number) => x + (y - x) * f;
  return {
    sky: a.sky.map((c, i) => m(c, b.sky[i])), sun: m(a.sun, b.sun), glow: m(a.glow, b.glow), sunX: n(a.sunX, b.sunX), sunY: n(a.sunY, b.sunY), sunR: n(a.sunR, b.sunR),
    cl: m(a.cl, b.cl), cm: m(a.cm, b.cm), cs: m(a.cs, b.cs), isl: m(a.isl, b.isl), lit: m(a.lit, b.lit), far: m(a.far, b.far), sand: m(a.sand, b.sand), rock: m(a.rock, b.rock),
    seaA: m(a.seaA, b.seaA), seaB: m(a.seaB, b.seaB), seaC: m(a.seaC, b.seaC), hi: m(a.hi, b.hi), glint: m(a.glint, b.glint),
    l: a.l.map((v, i) => n(v, b.l[i])), stars: n(a.stars, b.stars),
  };
}
export function zoneAt(x: number): number {
  let z = 0;
  while (z < ZONES.length - 1 && x >= ZONES[z].x1) z++;
  return z;
}

/** two-bone IK: returns [jointX, jointY, endX, endY] */
function ik(sx: number, sy: number, tx: number, ty: number, l1: number, l2: number, bend: number): number[] {
  let dx = tx - sx, dy = ty - sy;
  let d = Math.hypot(dx, dy) || 0.001;
  const mx = l1 + l2 - 0.05;
  if (d > mx) { dx *= mx / d; dy *= mx / d; d = mx; }
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  const ux = dx / d, uy = dy / d;
  return [sx + ux * a - uy * h * bend, sy + uy * a + ux * h * bend, sx + dx, sy + dy];
}

export class Game {
  fb = new Surface(W, H);
  au: AudioAPI = { play() {}, loop() {}, music() {} };
  onUI: () => void = () => {};
  onPop: (text: string, x: number, y: number, kind: string) => void = () => {};
  onBanner: (text: string, kind: string, sub?: string) => void = () => {};
  onSave: () => void = () => {};
  onBuzz: (ms: number | number[]) => void = () => {};

  t = 0;
  pt = 0;
  phase: Phase = 'title';
  sv: Save = newSave();
  boat = { x: 118, v: 0, dir: 1, fm: 0 };
  cam = 214;
  input = { dir: 0, reel: false };
  zone = 0;
  near: Spot | null = null;
  spot: Spot | null = null;
  spots: Spot[] = [];
  guideDx = 0;
  lure: { kind: 'l' | 'b'; id: string } = { kind: 'l', id: 'cacing' };
  power = 0; charging = false; chargeT = 0; perfect = false; castM = 0;
  lureP = { x: 0, y: 0, sx: 0, sy: 0, tx: 0, ty: 0, u: 0, dur: 1, arc: 40 };
  ent = { x: 200, y: 163 };
  depth = 0; depthQ = 0; attract = 0; jigCd = 0; twitch = 0; nib = 0; nibT = 0; nibbling = false; nibGrace = 0; biteT = 0; biteMax = 1;
  pending: CatchInfo | null = null;
  fight: Fight | null = null;
  ci: CatchInfo | null = null;
  cSpr: Surface | null = null;
  cSc = 1;
  failMsg = '';
  land = { wx: 0, wy: 0, mx: 0, my: 0, th: 0, hx: 0, hy: 0 };
  shake = 0; flash = 0; freeze = 0; slow = 1;
  reelAng = 0; reelAcc = 0;
  hudWarn = 0;
  rodA = 1.35; bend = 0;
  tip = { x: 100, y: 110 };
  /** current facial expression of the angler */
  expr = 'neutral';
  private ps = { hipX: 0, hipY: 7.5, lean: 0, st: 2.5, gx: 3, gy: -4, up: 0, br: 0 };
  private pump = 0;
  private yank = 0;
  private crank = 0;
  private cranking = false;
  private blinkT = 2;
  private emoT = 0;
  private head = { x: 0, y: 0 };
  private heads: Record<string, Surface>;
  fishSpr: Record<string, Surface> = {};

  private th!: TC;
  private TH: TC[];
  private themeKey = '';
  private sky = new Surface(W, HZ);
  private rowA: number[] = []; private rowB: number[] = []; private rowF: number[] = []; private rowH1: number[] = []; private rowH2: number[] = []; private rowLo: number[] = [];
  private clouds: { s: Surface; x: number; y: number; p: number; v: number; far: boolean }[] = [];
  private isles: Isle[] = [];
  private stars: { x: number; y: number; b: number; ph: number; sp: number }[] = [];
  private gulls: { x: number; y: number; v: number; ph: number }[] = [];
  private leaps: { spr: Surface; x: number; y: number; t: number; dur: number; dir: number; sc: number; h: number; trav: number; big: number }[] = [];
  private leapT = 1.2;
  private dolT = 5;
  private shoot = { x: 0, y: 0, t: 9 };
  private parts: Part[] = [];
  private rips: Rip[] = [];
  private boats: BoatSpr[] = [];
  private dolphin: Surface;
  private vig: number[] = [];
  private rayA: Float32Array | null = null;
  private wakeT = 0;
  private blockT = -9;
  private palF: number[] = []; private palN: number[] = [];

  constructor() {
    for (const sp of SPECIES) this.fishSpr[sp.id] = makeFish(sp.look);
    this.dolphin = makeFish(DOLPHIN);
    this.heads = makeHeads();
    for (let i = 1; i <= 4; i++) this.boats.push(makeBoat(i));
    this.TH = THEMES.map(toTC);
    this.genWorld();
    this.updateTheme();
  }

  // ================================================================= world generation
  private genWorld() {
    const r = rng(7);
    for (let i = 0; i < 7; i++) this.clouds.push({ s: makeCloud(r, (44 + r() * 60) | 0, (14 + r() * 15) | 0), x: i * 112 + r() * 40, y: 6 + r() * 40, p: 0.07, v: 2 + r() * 2, far: false });
    for (let i = 0; i < 9; i++) {
      const h = (6 + r() * 6) | 0;
      this.clouds.push({ s: makeCloud(r, (22 + r() * 44) | 0, h), x: i * 88 + r() * 40, y: 93 - h - r() * 16, p: 0.03, v: 0.7, far: true });
    }
    const mk = (lx: number, w: number, hmax: number, kind: number, far: boolean, seed: number, light = false) => {
      const q = rng(seed * 977 + 13);
      const ph = q() * 6;
      const hgt: number[] = [];
      for (let i = 0; i < w; i++) {
        const u = i / (w - 1);
        let h = 0;
        if (kind === 0) h = hmax * Math.pow(Math.sin(Math.PI * u), 0.75) * (0.78 + 0.22 * Math.sin(u * 9 + ph));
        else if (kind === 1) h = hmax * (0.72 + 0.28 * Math.sin(u * 6 + ph)) * Math.pow(Math.min(1, (Math.min(u, 1 - u) * w) / 3), 0.4);
        else if (kind === 2) h = hmax * (1 - Math.abs(2 * u - 1)) * (0.6 + 0.4 * Math.abs(Math.sin(u * 13 + ph)));
        else { h = hmax * (1 - Math.pow(Math.abs(2 * u - 1), 1.35)); if (Math.abs(u - 0.5) < 0.05) h -= 3; }
        hgt.push(Math.max(0, Math.round(h)));
      }
      const palms: number[] = [];
      if (kind === 0 && !far) for (let i = 0; i < w / 13; i++) palms.push((w * (0.15 + 0.7 * q())) | 0);
      this.isles.push({ lx, w, hgt, kind, far, p: far ? 0.16 : 0.3, palms, seed, light });
    };
    mk(70, 170, 46, 3, true, 21); mk(290, 120, 20, 0, true, 22); mk(460, 90, 14, 0, true, 23); mk(770, 70, 32, 3, true, 24);
    mk(-80, 124, 22, 0, false, 11, true); mk(118, 90, 16, 0, false, 12); mk(250, 70, 12, 0, false, 13); mk(360, 110, 20, 0, false, 14);
    mk(520, 34, 26, 1, false, 31); mk(575, 22, 18, 1, false, 32); mk(640, 46, 30, 1, false, 33); mk(730, 26, 20, 1, false, 34); mk(790, 38, 24, 1, false, 35); mk(880, 20, 15, 1, false, 36); mk(940, 30, 22, 1, false, 37);
    mk(1180, 44, 6, 0, false, 41);
    mk(1330, 20, 26, 2, false, 51); mk(1365, 14, 16, 2, false, 52); mk(1500, 26, 34, 2, false, 53); mk(1540, 16, 20, 2, false, 54); mk(1640, 22, 24, 2, false, 55);
    for (let i = 0; i < 90; i++) this.stars.push({ x: (r() * W) | 0, y: (r() * (HZ - 8)) | 0, b: 0.35 + r() * 0.65, ph: r() * 6, sp: 1 + r() * 3 });
    for (let i = 0; i < 4; i++) this.gulls.push({ x: r() * 520, y: 30 + r() * 40, v: 9 + r() * 8, ph: r() * 6 });
    let id = 0;
    for (let zi = 0; zi < ZONES.length; zi++) {
      const z = ZONES[zi];
      for (let k = 0; k < 4; k++) this.spots.push(this.newSpot(id++, zi, z.x0 + 150 + ((z.x1 - z.x0 - 300) * (k + 0.5)) / 4 + (r() - 0.5) * 80));
    }
    this.spots[0].x = 262; this.spots[0].gold = false; this.spots[0].left = 4;
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        const nx = (x - W / 2) / (W / 2), ny = (y - H / 2) / (H / 2);
        const dd = nx * nx * 0.8 + ny * ny * 0.9;
        if (dd > 0.74 && bayer(x, y) < (dd - 0.74) * 1.5) this.vig.push(y * W + x);
      }
  }
  private newSpot(id: number, zone: number, x: number): Spot {
    const gold = Math.random() < 0.16;
    const birds = [];
    for (let i = 0; i < (gold ? 5 : 3); i++) birds.push({ a: Math.random() * 6.28, r: 10 + Math.random() * 14, h: 24 + Math.random() * 22, sp: (0.7 + Math.random() * 0.7) * (i & 1 ? 1 : -1), ph: Math.random() * 6 });
    return { id, x, zone, left: 3 + ((Math.random() * 3) | 0), gold, hot: 0.18 + Math.random() * 0.66, birds };
  }
  private relocate(s: Spot) {
    const z = ZONES[s.zone];
    for (let i = 0; i < 30; i++) {
      const x = z.x0 + 130 + Math.random() * (z.x1 - z.x0 - 260);
      if (Math.abs(x - this.boat.x) < 170 || this.spots.some((o) => o !== s && Math.abs(o.x - x) < 130)) continue;
      s.x = x;
      break;
    }
    const n = this.newSpot(s.id, s.zone, s.x);
    s.left = n.left; s.gold = n.gold; s.hot = n.hot; s.birds = n.birds;
  }

  // ================================================================= theme
  private updateTheme() {
    const x = this.cam;
    const zi = zoneAt(x);
    let a = zi, b = zi, f = 0;
    const z = ZONES[zi];
    if (zi < ZONES.length - 1 && x > z.x1 - 170) { b = zi + 1; f = (x - (z.x1 - 170)) / 340; }
    else if (zi > 0 && x < z.x0 + 170) { a = zi - 1; f = 0.5 + (x - z.x0) / 340; }
    f = Math.round(f * 28) / 28;
    const key = a + ':' + b + ':' + f;
    if (key === this.themeKey) return;
    this.themeKey = key;
    const th = (this.th = blendTC(this.TH[a], this.TH[b], f));
    // sky
    const bands = 22, cols: number[] = [];
    for (let i = 0; i <= bands; i++) { const g = (i / bands) * 4, k = Math.min(3, g | 0); cols.push(mix(th.sky[k], th.sky[k + 1], g - k)); }
    for (let y = 0; y < HZ; y++) {
      const fbv = (y / (HZ - 1)) * bands, b0 = Math.min(bands - 1, fbv | 0);
      let fr = fbv - b0;
      fr = fr < 0.32 ? 0 : fr > 0.68 ? 1 : (fr - 0.32) / 0.36;
      for (let xx = 0; xx < W; xx++) this.sky.d[y * W + xx] = fr > bayer(xx, y) ? cols[b0 + 1] : cols[b0];
    }
    // sea rows
    const N = H - HZ, sb = 14, sc: number[] = [];
    for (let i = 0; i <= sb; i++) { const u = i / sb; sc.push(u < 0.3 ? mix(th.seaA, th.seaB, u / 0.3) : mix(th.seaB, th.seaC, (u - 0.3) / 0.7)); }
    for (let dy = 0; dy < N; dy++) {
      const fbv = Math.pow(dy / (N - 1), 0.8) * sb, b0 = Math.min(sb - 1, fbv | 0);
      let fr = fbv - b0;
      fr = fr < 0.2 ? 0 : fr > 0.8 ? 1 : (fr - 0.2) / 0.6;
      let cA = sc[b0], cB = sc[b0 + 1];
      if (dy < 3) { cA = mix(cA, th.sky[4], (3 - dy) * 0.2); cB = mix(cB, th.sky[4], (3 - dy) * 0.2); }
      const base = mix(cA, cB, fr);
      this.rowA[dy] = cA; this.rowB[dy] = cB; this.rowF[dy] = fr;
      this.rowH1[dy] = mix(base, th.hi, 0.42); this.rowH2[dy] = mix(base, th.hi, 0.86); this.rowLo[dy] = shade(base, 0.87);
    }
    this.palN = [0, th.cl, th.cm, th.cs];
    this.palF = [0, mix(th.cl, th.sky[3], 0.4), mix(th.cm, th.sky[3], 0.4), mix(th.cs, th.sky[3], 0.45)];
  }

  // ================================================================= helpers
  private emit() { this.onUI(); }
  private pop(text: string, x: number, y: number, kind = '') { this.onPop(text, clamp(x, 48, W - 48), clamp(y, 30, H - 20), kind); }
  load(s: Partial<Save>) { this.sv = { ...newSave(), ...s }; }
  get boatSpr() { return this.boats[this.sv.boat - 1]; }
  private bowSX() { const b = this.boatSpr; return FISH_SX - (b.s.w >> 1) + b.bow; }
  private ppm() { return (296 - (this.bowSX() + 12)) / 40; }
  private addPart(x: number, y: number, vx: number, vy: number, life: number, col: number, g: number, by: number, kind = 0) {
    if (this.parts.length < 400) this.parts.push({ x, y, vx, vy, life, max: life, col, g, by, kind });
  }
  private addRip(x: number, y: number, max: number, dur: number, col = 0) {
    if (this.rips.length < 80) this.rips.push({ x, y, max, life: dur, dur, col });
  }
  private splash(x: number, y: number, size: number) {
    const n = 8 + size * 9;
    for (let i = 0; i < n; i++) {
      const a = -Math.PI * (0.12 + 0.76 * Math.random());
      const sp = (28 + Math.random() * 52) * (0.7 + size * 0.38);
      this.addPart(x + (Math.random() - 0.5) * 7 * size, y, Math.cos(a) * sp * 0.8, Math.sin(a) * sp, 0.5 + Math.random() * 0.4 * size, i % 3 ? this.th.hi : K.white, 200, y + 1, size > 1 && i % 2 ? 3 : 0);
    }
    for (let k = 0; k <= size; k++) this.addRip(x, y, 5 + size * 5 + k * 6, 0.6 + k * 0.28);
  }
  lureAff(kind: 'l' | 'b' = this.lure.kind, id: string = this.lure.id): Record<number, number> {
    if (kind === 'b') { const sp = SPECIES.find((s) => s.id === id); return baitAff(sp ? sp.tier : 1); }
    const l = LURES.find((q) => q.id === id);
    return l ? l.aff : {};
  }
  /** 0..1 how well a lure suits a zone */
  match(kind: 'l' | 'b', id: string, zone: number): number {
    const aff = this.lureAff(kind, id);
    let a = 0, b = 0, any = false;
    for (const sp of SPECIES) {
      if (sp.zone !== zone) continue;
      if ((aff[sp.tier] || 0) > 0) any = true;
      if (sp.tier === 6) continue;
      b += sp.w;
      a += sp.w * Math.min(1, aff[sp.tier] || 0);
    }
    const m = b ? a / b : 0;
    return m > 0 ? m : any ? 0.3 : 0;
  }

  // ================================================================= public actions
  start() {
    if (this.phase !== 'title') return;
    this.phase = 'sail';
    this.au.music('calm');
    this.onBanner(ZONES[this.zone].name, 'zone', ZONES[this.zone].sub);
    this.emit();
  }
  openPick() {
    if (this.phase !== 'sail' || !this.near) return;
    this.spot = this.near;
    this.phase = 'pick';
    this.boat.dir = 1;
    this.input.dir = 0;
    this.au.play('ui');
    this.emit();
  }
  choose(kind: 'l' | 'b', id: string) {
    if (this.phase !== 'pick') return;
    this.lure = { kind, id };
    this.sv.last = kind + ':' + id;
    this.phase = 'aim';
    this.power = 0;
    this.charging = false;
    this.au.play('ui');
    this.emit();
  }
  back() {
    if (this.phase === 'aim') { this.phase = 'pick'; this.charging = false; }
    else if (this.phase === 'pick') { this.phase = 'sail'; this.spot = null; }
    else if (this.phase === 'sink' || this.phase === 'wait') { this.phase = 'aim'; this.power = 0; this.charging = false; this.nibbling = false; }
    else return;
    this.au.play('ui');
    this.emit();
  }
  press() {
    if (this.phase === 'aim' && !this.charging) { this.charging = true; this.chargeT = 0; this.power = 0; }
  }
  release() {
    if (this.phase === 'aim' && this.charging) this.cast();
  }
  act() {
    if (this.phase === 'sink') this.lockDepth();
    else if (this.phase === 'wait') this.jig();
    else if (this.phase === 'bite') this.strike();
    else if (this.phase === 'fight') this.sentak();
    else if (this.phase === 'pamer' && this.pt > 0.6) this.showStats();
  }
  /** d = clockwise angle delta (rad); abs = absolute handle angle so the crank follows the finger */
  reelBy(d: number, abs?: number) {
    if (this.phase !== 'fight') return;
    if (abs !== undefined) this.reelAng = abs;
    else if (d > 0) this.reelAng += d;
    if (d > 0) this.reelAcc += Math.min(d, 1.2);
  }
  sell() {
    if (this.phase !== 'caught' || !this.ci) return;
    this.sv.coins += this.ci.value;
    this.pop('+' + this.ci.value + ' KOIN', 286, 34, 'crit');
    this.au.play('coin');
    this.afterCatch();
  }
  keep() {
    if (this.phase !== 'caught' || !this.ci) return;
    const id = this.ci.sp.id;
    this.sv.bait[id] = (this.sv.bait[id] || 0) + 1;
    this.au.play('buy');
    this.afterCatch();
  }
  private afterCatch() {
    const sp = this.spot;
    this.fight = null; this.ci = null; this.cSpr = null;
    if (sp) {
      sp.left--;
      if (sp.left <= 0) {
        this.relocate(sp);
        this.spot = null; this.near = null;
        this.phase = 'sail';
        this.onBanner('Spot habis!', 'info', 'Cari kawanan burung berikutnya');
      } else this.phase = 'pick';
    } else this.phase = 'sail';
    this.au.music('calm');
    this.onSave();
    this.emit();
  }
  buy(kind: 'lure' | 'rod' | 'line' | 'reel' | 'boat', id = ''): boolean {
    const sv = this.sv;
    let price = 0;
    if (kind === 'lure') {
      const l = LURES.find((q) => q.id === id);
      if (!l || sv.lures.includes(id)) return false;
      price = l.price;
    } else {
      const tab = kind === 'rod' ? ROD : kind === 'line' ? LINE : kind === 'reel' ? REEL : BOAT;
      if (sv[kind] >= tab.length) return false;
      price = tab[sv[kind]].price;
    }
    if (sv.coins < price) { this.au.play('deny'); return false; }
    sv.coins -= price;
    if (kind === 'lure') sv.lures.push(id);
    else sv[kind]++;
    this.au.play('buy');
    this.onSave();
    this.emit();
    return true;
  }

  // ================================================================= fishing logic
  private cast() {
    this.charging = false;
    const p = Math.max(0.12, this.power);
    this.perfect = p >= 0.8 && p <= 0.94;
    this.castM = 8 + 30 * p;
    const lp = this.lureP;
    lp.sx = this.tip.x; lp.sy = this.tip.y;
    lp.tx = this.bowSX() + 12 + this.castM * this.ppm(); lp.ty = 163;
    lp.u = 0; lp.dur = 0.55 + 0.5 * p; lp.arc = 26 + 44 * p;
    lp.x = lp.sx; lp.y = lp.sy;
    this.phase = 'fly'; this.pt = 0;
    this.au.play('cast');
    this.emit();
  }
  private lockDepth() {
    const md = ZONES[this.spot!.zone].maxDepth;
    const diff = Math.abs(this.depth / md - this.spot!.hot);
    this.depthQ = diff < 0.09 ? 1 : diff < 0.2 ? 0.6 : 0.3;
    this.pop(diff < 0.09 ? 'PAS DI KAWANAN!' : diff < 0.2 ? 'Lumayan dekat' : 'Kurang pas…', 60, 96, diff < 0.09 ? 'good' : '');
    this.au.play(diff < 0.09 ? 'perfect' : 'lock');
    this.phase = 'wait'; this.pt = 0;
    this.attract = 0; this.nibbling = false; this.jigCd = 0.25; this.pending = null;
    this.emit();
  }
  private jig() {
    if (this.nibbling) {
      if (this.nibGrace > 0) return;
      this.nibbling = false; this.pending = null; this.attract = 0.35;
      this.pop('Terlalu cepat! Ikan kaget…', this.ent.x, this.ent.y - 22, 'bad');
      this.au.play('deny');
      this.emit();
      return;
    }
    if (this.jigCd > 0) return;
    this.jigCd = 0.4;
    this.attract += 0.05 + 0.05 * this.depthQ;
    this.twitch = 1;
    this.addRip(this.ent.x, this.ent.y, 7, 0.5);
    this.au.play('jig');
  }
  private pickFish(): CatchInfo | null {
    const sp0 = this.spot!;
    const aff = this.lureAff();
    let tot = 0, maxT = 0;
    for (const sp of SPECIES) if (sp.zone === sp0.zone && sp.tier < 6) maxT = Math.max(maxT, sp.tier);
    const c: [Species, number][] = [];
    for (const sp of SPECIES) {
      if (sp.zone !== sp0.zone) continue;
      let w = sp.w * (aff[sp.tier] || 0);
      if (sp0.gold && sp.tier >= maxT) w *= 1.8;
      if (w > 0) { c.push([sp, w]); tot += w; }
    }
    if (!tot) return null;
    let r = Math.random() * tot;
    let sp = c[0][0];
    for (const [s, w] of c) { r -= w; if (r <= 0) { sp = s; break; } }
    let q = Math.pow(Math.random(), 2) + (this.lure.kind === 'b' ? 0.15 : 0) + (sp0.gold ? 0.15 : 0) + (this.perfect ? 0.1 : 0) + (this.depthQ >= 1 ? 0.1 : 0);
    q = clamp(q, 0, 1);
    const kg = sp.minKg + (sp.maxKg - sp.minKg) * q;
    return { sp, kg: Math.round(kg * 10) / 10, cm: Math.round(43.7 * Math.cbrt(kg) * Math.pow(0.27 / sp.look.depth, 0.33)), secs: 0, prev: 0, value: Math.round(sp.value * (0.7 + 1.1 * q)), record: false, first: false, monster: q > 0.85, q };
  }
  private strike() {
    const ci = this.pending;
    if (!ci) return;
    if (this.lure.kind === 'b') {
      const id = this.lure.id;
      this.sv.bait[id] = (this.sv.bait[id] || 1) - 1;
      if (this.sv.bait[id] <= 0) delete this.sv.bait[id];
    }
    const sv = this.sv, spr = this.fishSpr[ci.sp.id];
    const gear = (ROD[sv.rod - 1].pow + LINE[sv.line - 1].pow) / 2;
    const ratio = (FISH_STR[ci.sp.tier] * (0.85 + 0.3 * ci.q)) / gear;
    this.fight = {
      ci, spr, sc: Math.min(1, 236 / spr.w), ratio, k: Math.min(1.6, 0.6 + 0.4 * ratio), stam: 1, dist: this.castM, tension: 0.55, strain: 0, slack: 0, omega: 0,
      state: 'run', stT: 1 + Math.random() * 0.5, lat: 0, latT: Math.random() * 2 - 1, latTimer: 0.8, ex: this.ent.x, ey: this.ent.y, sweetT: 0, combo: 0, jump: null,
      tick: 0, sprT: 0, cap: REEL[sv.reel - 1].cap, gain: REEL[sv.reel - 1].gain, jumps: 0, fx: 0, fy: 0, fa: 0, mx: 0, my: 0, hitFlash: 0, time: 0,
    };
    this.phase = 'fight'; this.pt = 0;
    this.freeze = 0.14; this.flash = 0.8; this.shake = 6; this.hudWarn = 0;
    this.yank = 1; this.pump = 0;
    this.splash(this.ent.x, this.ent.y, 2);
    this.au.play('strike'); this.au.music('fight');
    this.onBuzz(120);
    this.onBanner('STRIKE!', 'strike');
    this.onSave();
    this.emit();
  }
  private nextFightState() {
    const f = this.fight!;
    if (f.state === 'run') {
      const ch = f.jumps === 0 ? 1 : f.ci.sp.jump * (0.45 + 0.4 * f.stam);
      if (Math.random() < ch) { this.startJump(); return; }
      f.state = 'tired'; f.stT = 0.9 + Math.random() * 1.2;
    } else if (f.state === 'tired') { f.state = 'pull'; f.stT = 1.4 + Math.random() * 2; }
    else if (Math.random() < 0.3 + 0.55 * f.stam) {
      f.state = 'run'; f.stT = (1 + Math.random() * 1.2) * (0.55 + 0.45 * f.stam);
      f.stam = Math.max(0, f.stam - 0.02);
      this.au.play('run'); this.onBuzz(60);
      this.splash(f.ex, f.ey, 1);
    } else { f.state = 'tired'; f.stT = 0.8 + Math.random(); }
    this.emit();
  }
  private startJump() {
    const f = this.fight!;
    const sw = f.spr.w * f.sc, sh = f.spr.h * f.sc;
    let travel = Math.min(150, 30 + sw * 0.55);
    let dir = Math.random() < 0.5 ? -1 : 1;
    if (f.ex + travel > 304) dir = -1;
    else if (f.ex - travel < 128) dir = 1;
    if (dir < 0 && f.ex - travel < 120) travel = Math.max(30, f.ex - 120);
    const apex = clamp(18 + sh * 0.35, 20, 48);
    f.jump = { t: 0, dur: 1.15 + sw * 0.002, dir, x0: f.ex, y0: Math.round(f.ey), apex, hit: false, travel, sub: sh * 0.3 };
    f.state = 'jump'; f.jumps++;
    f.fx = f.ex; f.fy = f.ey + sh; f.mx = f.ex; f.my = f.ey;
    this.splash(f.ex, f.ey, 2);
    this.au.play('splash');
    this.shake = Math.max(this.shake, 3);
    this.emit();
  }
  private sentak() {
    const f = this.fight;
    if (!f || !f.jump || f.jump.hit) return;
    const u = f.jump.t / f.jump.dur;
    if (u < 0.06 || u > 0.94) return;
    f.jump.hit = true;
    f.stam = Math.max(0, f.stam - 0.16);
    f.hitFlash = 1;
    this.yank = 1;
    this.freeze = 0.09; this.flash = Math.max(this.flash, 0.35); this.shake = 5; this.slow = 1;
    this.au.play('crit'); this.onBuzz(80);
    this.pop('KRITIS!', f.fx, f.fy - 18, 'crit');
    for (let i = 0; i < 14; i++) { const a = Math.random() * 6.28; this.addPart(f.fx, f.fy, Math.cos(a) * 60, Math.sin(a) * 60, 0.4, i & 1 ? K.gold : K.white, 0, 999, 2); }
    this.emit();
  }
  private fail(msg: string, snd: string) {
    this.failMsg = msg;
    this.fight = null;
    this.phase = 'fail'; this.pt = 0; this.slow = 1; this.hudWarn = 0;
    this.au.loop('drag', 0);
    this.au.music('calm');
    this.au.play(snd);
    this.shake = 4;
    this.onBuzz(200);
    this.onSave();
    this.emit();
  }
  private updFight(dt: number) {
    const f = this.fight!;
    const sp = f.ci.sp;
    f.time += dt;
    let dA = this.reelAcc;
    this.reelAcc = 0;
    if (this.input.reel) { dA += 12 * dt; this.reelAng += 12 * dt; }
    f.omega += (dA / Math.max(dt, 0.004) - f.omega) * Math.min(1, dt * 9);
    if (f.omega < 0.05) f.omega = 0;
    f.tick += dA;
    while (f.tick > 0.52) { f.tick -= 0.52; this.au.play('click', f.tension); }
    const wn = Math.min(1.6, f.omega / 11);
    f.hitFlash = Math.max(0, f.hitFlash - dt * 5);

    // ---- angler technique: crank while lowering the rod, then heave it back up ("pump & reel")
    const reeling = dA > 0.0001 || f.omega > 2;
    if (this.pump >= 0.72) {
      this.pump += (dt / 0.34) * 0.28;
      if (this.pump >= 1) this.pump = 0;
    } else if (reeling && f.state !== 'run' && f.state !== 'jump') {
      this.pump += (dA / (Math.PI * 3)) * 0.72;
      if (this.pump >= 0.72) {
        this.shake = Math.max(this.shake, 1.2);
        this.addRip(f.ex, f.ey, 9, 0.5);
        f.dist -= f.state === 'tired' ? 0.6 : 0.35;
      }
    } else if (!reeling) this.pump = Math.max(0, this.pump - dt * 0.8);
    this.cranking = reeling && this.pump < 0.72;
    if (this.cranking) this.crank += dA;

    if (f.jump) {
      const j = f.jump;
      j.t += dt;
      const u = j.t / j.dur;
      if (u >= 1) {
        const lx = j.x0 + j.dir * j.travel;
        this.splash(lx, j.y0, f.spr.w > 100 ? 3 : 2);
        this.au.play('splash');
        this.shake = Math.max(this.shake, 3.5);
        f.ex = clamp(lx, 126, 300);
        f.jump = null; f.state = 'tired'; f.stT = 0.8 + Math.random() * 0.8;
        this.slow = 1;
        this.emit();
      } else {
        const hg = j.apex + j.sub;
        f.fx = j.x0 + j.dir * j.travel * u;
        f.fy = j.y0 + j.sub - hg * 4 * u * (1 - u);
        const pitch = Math.atan2(-hg * 4 * (1 - 2 * u), j.travel) * 0.75;
        f.fa = (j.dir > 0 ? pitch : -pitch) + fsin(this.t * 24) * 0.09;
        // the line is tied to the MOUTH (not the tip of the bill)
        const s0 = f.spr, ox = (j.dir > 0 ? s0.w / 2 - s0.ax : s0.ax - s0.w / 2) * f.sc, oy = (s0.ay - s0.h / 2) * f.sc;
        const ca = Math.cos(f.fa), sa = Math.sin(f.fa);
        f.mx = f.fx + ox * ca - oy * sa;
        f.my = Math.min(j.y0, f.fy + ox * sa + oy * ca);
        this.slow = u > 0.18 && u < 0.82 && !j.hit ? 0.5 : 1;
        if (Math.random() < dt * 50) this.addPart(f.fx + (Math.random() - 0.5) * f.spr.w * f.sc * 0.7, f.fy, (Math.random() - 0.5) * 20, 10, 0.6, this.th.hi, 220, j.y0 + 1, 0);
      }
    } else {
      f.stT -= dt;
      if (f.stam <= 0) { if (f.state !== 'tired') { f.state = 'tired'; this.emit(); } f.stT = 9; }
      else if (f.stT <= 0) this.nextFightState();
    }

    let base = 0.36 + 0.08 * fsin(this.t * 5), eff = 0.65, out = 0;
    if (f.state === 'run') { base = 0.82; eff = 0.1; out = (2 + 1.6 * Math.min(2, f.ratio)) * (0.45 + 0.55 * f.stam); }
    else if (f.state === 'tired') { base = 0.12; eff = 1; }
    else if (f.state === 'jump') { base = 0.3; eff = 0.4; }
    else out = wn < 0.15 ? 0.6 * f.k * f.stam : 0;
    const target = base * f.k * (0.6 + 0.4 * f.stam) + wn * (0.24 + 0.42 * base) * f.k;
    f.tension += (target - f.tension) * Math.min(1, dt * (target > f.tension ? 5.5 : 3));
    const inRate = (f.omega * f.gain * clamp(1.2 - f.tension * 0.5, 0.35, 1) * eff * (f.stam <= 0 ? 1.5 : 1)) / Math.max(0.6, Math.pow(f.ratio, 0.8));
    f.dist += (out - inRate) * dt;

    const sweet = f.tension >= 0.45 && f.tension <= 0.9;
    const drain = (0.028 + (sweet ? 0.1 : f.tension > 0.9 ? 0.07 : 0.008)) / (1 + (sp.tier - 1) * 0.3) / Math.max(0.75, Math.sqrt(f.ratio));
    f.stam = Math.max(0, f.stam - drain * dt);
    if (sweet && wn > 0.2) {
      f.sweetT += dt;
      if (f.sweetT > 1) {
        f.sweetT = 0; f.combo++;
        this.au.play('sweet', f.combo);
        for (let i = 0; i < 5; i++) this.addPart(338 + (Math.random() - 0.5) * 50, 164 + (Math.random() - 0.5) * 40, 0, -20, 0.6, K.gold, 0, 999, 2);
        if (f.combo % 2 === 0) this.pop('MANTAP x' + f.combo, 300, 120, 'good');
      }
    } else if (!sweet) { f.sweetT = 0; if (f.tension > 1 || f.tension < 0.2) f.combo = 0; }

    if (f.tension > 1) { f.strain += (f.tension - 1) * 4 * dt + 0.12 * dt; this.shake = Math.max(this.shake, 1); }
    else f.strain = Math.max(0, f.strain - 0.25 * dt);
    if (f.tension < 0.2 && f.state !== 'jump') f.slack += dt;
    else f.slack = Math.max(0, f.slack - 2 * dt);
    const warn = f.tension > 1 ? 2 : f.slack > 1.1 ? 1 : 0;
    if (warn !== this.hudWarn) { this.hudWarn = warn; if (warn === 2) this.onBuzz(40); }
    this.au.loop('drag', f.state === 'run' ? 0.5 + 0.5 * f.stam : 0);

    // fish position on the surface
    f.latTimer -= dt;
    if (f.latTimer <= 0) { f.latTimer = f.state === 'run' ? 0.7 : 1.2 + Math.random() * 1.6; f.latT = (Math.random() * 2 - 1) * (f.state === 'tired' ? 0.4 : 1); }
    f.lat += (f.latT - f.lat) * Math.min(1, dt * (f.state === 'run' ? 2.6 : 1.1));
    if (!f.jump) {
      const m = Math.min(f.dist, 40);
      const tx = this.bowSX() + 12 + m * this.ppm(), ty = 163 + f.lat * (5 + m * 0.65);
      const ox = f.ex, oy = f.ey;
      f.ex += (tx - f.ex) * Math.min(1, dt * 6);
      f.ey += (ty - f.ey) * Math.min(1, dt * 6);
      const spd = Math.hypot(f.ex - ox, f.ey - oy) / Math.max(dt, 0.004);
      f.sprT -= dt * (0.4 + spd * 0.06);
      if (f.sprT <= 0) {
        f.sprT = 0.09;
        this.addRip(f.ex, f.ey, 5 + Math.random() * 6, 0.6);
        if (spd > 10 || f.state === 'run')
          for (let i = 0; i < 3; i++) this.addPart(f.ex, f.ey, (ox - f.ex) * 30 + (Math.random() - 0.5) * 30, -24 - Math.random() * 34, 0.5, i ? this.th.hi : K.white, 190, f.ey + 1, 0);
      }
      // thrashing at the surface once it is dragged close to the boat
      if (f.dist < 9 && Math.random() < dt * 26) this.addPart(f.ex + (Math.random() - 0.25) * 30, f.ey, (Math.random() - 0.5) * 60, -30 - Math.random() * 55, 0.5, Math.random() < 0.5 ? K.white : this.th.hi, 210, f.ey + 1, 0);
    }

    if (f.strain >= 1) this.fail('SENAR PUTUS! Tegangan terlalu tinggi.', 'snap');
    else if (f.slack > 3.2) this.fail('IKAN LEPAS! Senar terlalu kendor.', 'fail');
    else if (f.dist > f.cap) this.fail('SENAR HABIS! Ikan kabur membawa senar.', 'snap');
    else if (f.dist <= 2.5 && !f.jump) {
      // hoist it out of the water
      this.phase = 'landing'; this.pt = 0; this.slow = 1; this.hudWarn = 0;
      this.au.loop('drag', 0); this.au.music('off');
      this.splash(f.ex, f.ey, 3);
      this.au.play('splash');
      this.shake = 6; this.yank = 1;
      this.cSpr = f.spr;
      this.cSc = Math.max(1, Math.min(3, Math.round((190 / f.spr.w) * 2) / 2));
      this.land = { wx: f.ex, wy: Math.round(f.ey), mx: f.ex, my: f.ey + 6, th: -Math.PI / 2, hx: f.ex, hy: f.ey - 30 };
      this.emit();
    }
  }
  /** centre of the fish while the angler holds it over his head (real size, never zoomed) */
  private holdPos(f: Fight) {
    const g = this.boatGeom(), s0 = f.spr, sw = s0.w * f.sc;
    const heavy = f.ci.sp.tier >= 3;
    const hop = !heavy && this.phase !== 'landing' ? Math.round(Math.abs(fsin(this.t * 8)) * 2) : 0;
    const handsY = g.my - hop - (heavy ? 6.3 : 7.4) - 18.9;
    const shk = heavy && ((this.t * 30) | 0) & 1 ? 1 : 0;
    return { x: clamp(g.mx, sw / 2 + 3, W - sw / 2 - 3), y: handsY - (s0.ab - s0.h / 2) * f.sc - 1 + shk };
  }
  private holdMouth(f: Fight) {
    const c = this.holdPos(f), s0 = f.spr;
    return { x: c.x + (s0.w / 2 - s0.ax) * f.sc, y: c.y + (s0.ay - s0.h / 2) * f.sc };
  }
  /** the fish is on board: the angler shows it off first… */
  private startPamer() {
    const f = this.fight!;
    const ci = f.ci;
    const rec = this.sv.rec[ci.sp.id];
    ci.first = !rec;
    ci.record = !!rec && ci.kg > rec.best;
    ci.prev = rec ? rec.best : 0;
    ci.secs = Math.max(1, Math.round(f.time));
    this.sv.rec[ci.sp.id] = { n: (rec ? rec.n : 0) + 1, best: Math.max(rec ? rec.best : 0, ci.kg) };
    this.sv.total++;
    if (ci.sp.tier === 6) this.sv.legend = true;
    this.ci = ci;
    this.phase = 'pamer'; this.pt = 0;
    this.flash = 0.5;
    this.au.play('fanfare');
    this.onBuzz([60, 40, 60, 40, 140]);
    this.onBanner('MANTAP!', 'mantap');
    this.onSave();
    this.emit();
  }
  /** …then the stat / introduction card (the only place the fish is drawn enlarged) */
  private showStats() {
    if (this.phase !== 'pamer') return;
    this.phase = 'caught'; this.pt = 0;
    this.flash = 0.35;
    this.au.play('perfect');
    this.emit();
  }

  // ================================================================= update
  update(dtReal: number) {
    if (this.freeze > 0) { this.freeze -= dtReal; return; }
    const dt = dtReal * this.slow;
    this.t += dt; this.pt += dt;
    const camPrev = this.cam;
    this.shake = Math.max(0, this.shake - dtReal * 14);
    this.flash = Math.max(0, this.flash - dtReal * 3);
    const fishing = this.phase !== 'sail' && this.phase !== 'title';
    this.boat.fm += ((fishing ? 1 : 0) - this.boat.fm) * Math.min(1, dt * 4);
    if (this.phase !== 'sail') { this.boat.v *= Math.max(0, 1 - dt * 4); this.au.loop('engine', 0); }

    switch (this.phase) {
      case 'sail': this.updSail(dt); break;
      case 'aim':
        if (this.charging) { this.chargeT += dt; this.power = 1 - Math.abs(((this.chargeT * 1.1) % 2) - 1); }
        break;
      case 'fly': {
        const lp = this.lureP;
        lp.u += dt / lp.dur;
        const u = Math.min(1, lp.u);
        lp.x = lp.sx + (lp.tx - lp.sx) * u;
        lp.y = lp.sy + (lp.ty - lp.sy) * u - lp.arc * 4 * u * (1 - u);
        if (Math.random() < dt * 40) this.addPart(lp.x, lp.y, 0, 0, 0.3, this.perfect ? K.gold : K.white, 0, 999, 0);
        if (u >= 1) {
          this.ent.x = lp.tx; this.ent.y = lp.ty;
          this.splash(lp.tx, lp.ty, 1);
          this.au.play('plop');
          this.shake = 1.6;
          if (this.perfect) { this.onBanner('LEMPARAN SEMPURNA!', 'perfect'); this.au.play('perfect'); this.addRip(lp.tx, lp.ty, 26, 0.9, K.gold); }
          this.phase = 'sink'; this.pt = 0; this.depth = 0;
          this.emit();
        }
        break;
      }
      case 'sink': {
        const md = ZONES[this.spot!.zone].maxDepth;
        this.depth += (md / 4.2) * dt;
        if (((this.pt * 6) | 0) !== (((this.pt - dt) * 6) | 0)) this.au.play('tick');
        if (this.depth >= md) { this.depth = md; this.lockDepth(); }
        break;
      }
      case 'wait': {
        this.jigCd -= dt;
        this.twitch = Math.max(0, this.twitch - dt * 4);
        if (!this.nibbling) {
          const m = this.match(this.lure.kind, this.lure.id, this.spot!.zone);
          this.attract += dt * 0.085 * (0.5 + this.depthQ) * (this.spot!.gold ? 1.3 : 1) * (this.perfect ? 1.25 : 1) * (0.6 + 0.4 * Math.min(1, m * 1.5));
          if (Math.random() < dt * (1 + this.attract * 5)) this.addRip(this.ent.x + (Math.random() - 0.5) * 16, this.ent.y + (Math.random() - 0.5) * 5, 2 + Math.random() * 3, 0.5);
          if (this.attract >= 1) {
            const c = this.pickFish();
            if (!c) { this.attract = 0.4; this.pop('Ikan tidak tertarik… ganti umpan!', this.ent.x, this.ent.y - 22, 'bad'); }
            else { this.pending = c; this.nibbling = true; this.nib = (Math.random() * 3) | 0; this.nibT = 0.5 + Math.random() * 0.5; this.nibGrace = 0.3; this.emit(); }
          }
        } else {
          this.nibGrace -= dt; this.nibT -= dt;
          if (this.nibT <= 0) {
            if (this.nib > 0) {
              this.nib--; this.nibT = 0.45 + Math.random() * 0.6; this.twitch = 0.6;
              this.addRip(this.ent.x, this.ent.y, 6, 0.45);
              this.au.play('nibble'); this.onBuzz(15);
            } else {
              this.phase = 'bite'; this.pt = 0;
              this.biteMax = this.biteT = 0.95 + this.sv.rod * 0.05;
              this.splash(this.ent.x, this.ent.y, 1);
              this.au.play('bite'); this.onBuzz([40, 30, 40]);
              this.shake = 2;
              this.emit();
            }
          }
        }
        break;
      }
      case 'bite':
        this.biteT -= dt;
        if (Math.random() < dt * 14) this.addRip(this.ent.x + (Math.random() - 0.5) * 8, this.ent.y, 5 + Math.random() * 5, 0.4);
        if (this.biteT <= 0) {
          if (this.lure.kind === 'b') { const id = this.lure.id; this.sv.bait[id] = (this.sv.bait[id] || 1) - 1; if (this.sv.bait[id] <= 0) delete this.sv.bait[id]; }
          this.fail(this.lure.kind === 'b' ? 'TERLAMBAT! Umpan hidup dimakan ikan…' : 'TERLAMBAT! Ikan keburu kabur…', 'fail');
        }
        break;
      case 'fight': this.updFight(dt); break;
      case 'landing': {
        // phase A: the fish is lifted out hanging from the line by its mouth; phase B: swung up over the head
        const f = this.fight!, L = this.land, T1 = 0.75, T2 = 0.5;
        if (this.pt < T1) {
          const u = this.pt / T1, e = 1 - (1 - u) * (1 - u);
          // big fish come up beside the bow so they do not hide the angler
          L.hx = Math.max(this.tip.x + 1, this.boatGeom().mx + 12 + f.spr.h * f.sc * 0.45); L.hy = this.tip.y + 9;
          L.mx = L.wx + (L.hx - L.wx) * e + fsin(this.pt * 13) * 2 * (1 - u);
          L.my = L.wy + 6 + (L.hy - L.wy - 6) * e;
          L.th = -Math.PI / 2 + fsin(this.pt * 12) * 0.32 * (1 - u * 0.6);
        } else {
          const u = Math.min(1, (this.pt - T1) / T2), e = u * u * (3 - 2 * u), hm = this.holdMouth(f);
          L.mx = L.hx + (hm.x - L.hx) * e;
          L.my = L.hy + (hm.y - L.hy) * e - Math.sin(Math.PI * u) * 6;
          L.th = (-Math.PI / 2) * (1 - e);
          if (u >= 1) this.startPamer();
        }
        if (Math.random() < dt * 60) this.addPart(L.mx + (Math.random() - 0.5) * 14, L.my + Math.random() * 20, (Math.random() - 0.5) * 20, 20, 0.7, this.th.hi, 200, L.wy, 0);
        break;
      }
      case 'pamer':
      case 'caught': {
        const f = this.fight;
        if (f && Math.random() < dt * 10) { const c = this.holdPos(f); this.addPart(c.x + (Math.random() - 0.5) * f.spr.w * f.sc * 0.8, c.y + 4, 0, 16, 0.8, this.th.hi, 160, 999, 0); }
        if (this.phase === 'caught') {
          if (Math.random() < dt * 8) this.addPart(192 + (Math.random() - 0.5) * 240, 72 + (Math.random() - 0.5) * 110, 0, -6, 0.7, Math.random() < 0.5 ? K.gold : K.white, 0, 999, 2);
        } else {
          if (Math.random() < dt * 16) this.addPart(Math.random() * W, -2, (Math.random() - 0.5) * 30, 30 + Math.random() * 30, 2.4, [K.red, K.gold, K.green, K.white, K.z0][(Math.random() * 5) | 0], 18, 999, 3);
          if (this.pt > 2.8) this.showStats();
        }
        break;
      }
      case 'fail':
        if (this.pt > 2) { this.phase = this.spot ? 'pick' : 'sail'; this.emit(); }
        break;
    }

    const target = fishing ? this.boat.x + (192 - FISH_SX) : this.phase === 'title' ? this.boat.x + 96 : this.boat.x + this.boat.dir * 34 + this.boat.v * 0.3;
    this.cam += (target - this.cam) * Math.min(1, dt * (fishing ? 3.5 : 2.2));
    if (this.cam < 150) this.cam = 150;
    const dc = this.cam - camPrev;

    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      p.x += p.vx * dt - dc * (p.by < 900 ? rowScale(p.by) : 0);
      p.y += p.vy * dt;
      p.vy += p.g * dt;
      if (p.life <= 0 || (p.g > 0 && p.vy > 0 && p.y > p.by)) {
        if (p.kind === 3 && p.life > 0) this.addRip(p.x, p.by, 4, 0.4);
        this.parts[i] = this.parts[this.parts.length - 1];
        this.parts.pop();
      }
    }
    for (let i = this.rips.length - 1; i >= 0; i--) {
      const r = this.rips[i];
      r.life -= dt;
      r.x -= dc * rowScale(r.y);
      if (r.life <= 0) { this.rips[i] = this.rips[this.rips.length - 1]; this.rips.pop(); }
    }
    this.updAmbient(dt, dc);
    this.updPose(dt);
    this.updateTheme();
  }

  private updSail(dt: number) {
    const b = this.boat, bs = this.boatSpr;
    const maxV = BOAT[this.sv.boat - 1].speed;
    b.v += (this.input.dir * maxV - b.v) * Math.min(1, dt * (this.input.dir ? 1.8 : 2.6));
    if (this.input.dir) b.dir = this.input.dir;
    b.x += b.v * dt;
    const lim = ZONES[this.sv.boat - 1].x1 - 40;
    if (b.x > lim) {
      b.x = lim;
      if (b.v > 5 && this.t - this.blockT > 2.5) {
        this.blockT = this.t;
        const more = this.sv.boat < 4;
        this.onBanner(more ? 'Ombak terlalu besar!' : 'Ujung samudra', 'info', more ? 'Upgrade perahu di TOKO untuk lanjut' : 'Tak ada lagi laut di depan');
        this.au.play('deny');
      }
      b.v = Math.min(0, b.v);
    }
    const minX = 74 + (bs.s.w >> 1);
    if (b.x < minX) { b.x = minX; b.v = Math.max(0, b.v); }
    const sp = Math.abs(b.v);
    this.au.loop('engine', Math.min(1, sp / maxV));
    if (sp > 6) {
      this.wakeT -= dt * sp * 0.14;
      if (this.wakeT <= 0) {
        this.wakeT = 1;
        const sx = b.x - this.cam + 192, dir = b.v > 0 ? 1 : -1, half = bs.s.w >> 1;
        this.addPart(sx - dir * (half - 2) + (Math.random() - 0.5) * 4, BOAT_Y + 1 + Math.random() * 4, -dir * 5, 0, 1.4, K.white, 0, BOAT_Y, 1);
        this.addPart(sx - dir * (half - 8) + (Math.random() - 0.5) * 4, BOAT_Y + 2 + Math.random() * 5, -dir * 3, 0, 1.0, this.th.hi, 0, BOAT_Y, 1);
        if (sp > maxV * 0.45) this.addPart(sx + dir * (half - 4), BOAT_Y - 1, dir * (10 + Math.random() * 24), -(18 + Math.random() * 30), 0.5, K.white, 170, BOAT_Y + 1, 0);
      }
    }
    const zi = zoneAt(b.x);
    if (zi !== this.zone) { this.zone = zi; this.onBanner(ZONES[zi].name, 'zone', ZONES[zi].sub); this.au.play('zone'); this.emit(); }
    let near: Spot | null = null, best = 36, gd = 1e9, gdx = 0;
    for (const s of this.spots) {
      const d = Math.abs(s.x - b.x);
      if (d < best) { best = d; near = s; }
      if (d < gd && s.x < lim + 30) { gd = d; gdx = s.x - b.x; }
    }
    this.guideDx = gdx;
    if (near !== this.near) { this.near = near; if (near) this.au.play('ui'); this.emit(); }
  }

  private updAmbient(dt: number, dc: number) {
    for (const s of this.spots) {
      for (const bd of s.birds) bd.a += bd.sp * dt;
      const sx = s.x - this.cam + 192;
      if (sx < -30 || sx > W + 30) continue;
      if (Math.random() < dt * (s.gold ? 9 : 6)) {
        const ox = (Math.random() - 0.5) * 34, oy = BOAT_Y + 2 + (Math.random() - 0.5) * 8;
        if (Math.random() < 0.6) this.addRip(sx + ox, oy, 3 + Math.random() * 4, 0.7);
        else this.addPart(sx + ox, oy, (Math.random() - 0.5) * 30, -30 - Math.random() * 30, 0.6, Math.random() < 0.5 ? K.white : this.th.hi, 200, oy, 0);
        if (s.gold && Math.random() < 0.6) this.addPart(sx + ox, oy - 4, 0, -14, 0.9, K.gold, 0, oy, 2);
      }
    }
    this.dolT -= dt;
    if (this.dolT <= 0) {
      this.dolT = 9 + Math.random() * 10;
      const n = 1 + ((Math.random() * 3) | 0), x = 60 + Math.random() * 250, dir = Math.random() < 0.5 ? -1 : 1;
      for (let i = 0; i < n; i++) this.leaps.push({ spr: this.dolphin, x: x - dir * i * 16, y: 111 + Math.random() * 7, t: -i * 0.28, dur: 1.1, dir, sc: 0.5, h: 20, trav: 24, big: 0 });
    }
    // teaser leaps: giants on the title screen, zone fish at spots while sailing
    this.leapT -= dt;
    if (this.leapT <= 0) {
      this.leapT = 2;
      if (this.phase === 'title') {
        this.leapT = 3.2 + Math.random() * 2.4;
        const pool = ['gt', 'lemadang', 'tuna', 'layaran', 'marlin', 'tenggiri', 'kakap', 'hiu'];
        const spr = this.fishSpr[pool[(Math.random() * pool.length) | 0]];
        const dir = Math.random() < 0.5 ? -1 : 1, trav = 30 + spr.w * 0.5;
        this.leaps.push({ spr, x: dir > 0 ? 180 + Math.random() * 40 : 340 - Math.random() * 30, y: 160 + Math.random() * 14, t: 0, dur: 1.5, dir, sc: 1, h: 26 + spr.h * 0.45, trav, big: 2 });
      } else if (this.phase === 'sail') {
        this.leapT = 4 + Math.random() * 5;
        const sp0 = this.spots.find((q) => Math.abs(q.x - this.cam) < 170 && q !== this.near);
        if (sp0) {
          const c = SPECIES.filter((q) => q.zone === sp0.zone && q.tier < 6);
          const spr = this.fishSpr[c[(Math.random() * c.length) | 0].id];
          const dir = Math.random() < 0.5 ? -1 : 1, trav = 16 + spr.w * 0.3;
          this.leaps.push({ spr, x: sp0.x - this.cam + 192 - (dir * trav) / 2, y: BOAT_Y + 4, t: 0, dur: 1.1, dir, sc: 0.6, h: 12 + spr.h * 0.3, trav, big: 1 });
        }
      }
    }
    for (let i = this.leaps.length - 1; i >= 0; i--) {
      const o = this.leaps[i], pt = o.t;
      o.t += dt;
      o.x -= dc * rowScale(o.y);
      if (pt <= 0 && o.t > 0) { if (o.big) this.splash(o.x, o.y, o.big); else this.addRip(o.x, o.y, 5, 0.6); }
      if (o.t >= o.dur) {
        const ex = o.x + o.dir * o.trav;
        if (o.big) this.splash(ex, o.y, o.big); else this.addRip(ex, o.y, 6, 0.7);
        this.leaps.splice(i, 1);
      }
    }
    this.shoot.t += dt;
    if (this.shoot.t > 6 && Math.random() < dt * 0.25) this.shoot = { x: 40 + Math.random() * 280, y: 6 + Math.random() * 30, t: 0 };
  }

  /** body pose + rod angle + facial expression of the angler */
  private updPose(dt: number) {
    const P = this.ps, f = this.fight;
    let hipX = 0, hipY = 7.5, lean = 0.02, st = 2.5, gx = 3, gy = -4, ta = 1.4, tb = 0, up = 0, br = 0, rate = 10;
    this.yank = Math.max(0, this.yank - dt * 3.2);
    if (this.phase !== 'fight') this.cranking = false;
    switch (this.phase) {
      case 'sail': lean = 0.02 + Math.min(0.12, Math.abs(this.boat.v) * 0.0009); break;
      case 'aim': {
        // wind-up: weight on the back foot, rod swept back over the shoulder
        const p = this.power;
        hipX = -1.6 * p; hipY = 7.3 - 0.9 * p; lean = -0.04 - 0.32 * p; st = 3 + p; gx = 3 - 5 * p; gy = -5 - 4.5 * p; ta = 1.0 + 1.45 * p; rate = 16;
        break;
      }
      case 'fly':
        this.crank += dt * 26;
        if (this.pt < 0.3) { hipX = 2; hipY = 6.7; lean = 0.4; st = 4; gx = 6; gy = -7.5; ta = 0.3; rate = 26; }
        else { hipX = 0.5; hipY = 7.2; lean = 0.1; st = 3; gx = 4; gy = -5; ta = 0.5; }
        break;
      case 'sink': this.crank += dt * 18; hipX = 0.3; hipY = 7.3; lean = 0.06; st = 3; gx = 4; gy = -5; ta = 0.55; break;
      case 'wait': hipY = this.nibbling ? 6.9 : 7.4; lean = this.nibbling ? 0.16 : 0.04; st = 3; gx = 4; gy = -5; ta = 0.5 + this.twitch * 0.45; rate = 18; break;
      case 'bite': hipY = 6.8; lean = 0.2; st = 3.5; gx = 4.5; gy = -5; ta = 0.4; tb = 0.6; rate = 18; break;
      case 'fight':
        if (f) {
          const T = Math.min(1.25, f.tension), p = this.pump;
          const lift = p < 0.72 ? 1 - p / 0.72 : (p - 0.72) / 0.28;
          const heave = p >= 0.72 ? Math.sin(((p - 0.72) / 0.28) * Math.PI) : 0;
          st = 5; gx = 2.6; gy = -4; rate = 14; br = 1;
          ta = 0.74 + 0.5 * lift; lean = -0.14 - 0.2 * lift - 0.2 * heave - 0.1 * T; hipY = 6.5 - 0.8 * heave - 0.35 * T; hipX = -0.8 - 1.1 * heave;
          if (f.state === 'run') { ta = 0.86; lean = -0.3 - 0.1 * T; hipY = 5.9; hipX = 1.3; }
          else if (f.state === 'jump') { ta = 1.3; lean = -0.38; hipY = 6.1; hipX = -1; }
          tb = T * 0.8 + (f.state === 'run' ? 0.15 : 0);
          ta += 0.5 * this.yank; lean -= 0.42 * this.yank; hipY -= 0.9 * this.yank;
        }
        break;
      case 'landing':
        if (this.pt < 0.75) { br = 1; hipX = -1.2; hipY = 6; lean = -0.42; st = 4.5; gx = 2.4; gy = -4; ta = 0.9 + 0.3 * Math.min(1, this.pt / 0.5); tb = 0.75; rate = 14; }
        else { up = 1; hipY = 6.8; st = 3.2; }
        break;
      case 'pamer':
      case 'caught': {
        const heavy = !!f && f.ci.sp.tier >= 3;
        up = 1; hipY = heavy ? 6.3 : 7.4; st = heavy ? 4.2 : 3; lean = heavy ? -0.06 : 0;
        break;
      }
      case 'fail': hipY = 7.1; lean = 0.24; gx = 3.4; gy = -3.4; ta = 0.75; break;
    }
    const k = Math.min(1, dt * rate);
    P.hipX += (hipX - P.hipX) * k; P.hipY += (hipY - P.hipY) * k; P.lean += (lean - P.lean) * k; P.st += (st - P.st) * k;
    P.gx += (gx - P.gx) * k; P.gy += (gy - P.gy) * k; P.br += (br - P.br) * k; P.up += (up - P.up) * Math.min(1, dt * 14);
    this.rodA += (ta - this.rodA) * Math.min(1, dt * rate * 1.2);
    this.bend += (tb - this.bend) * Math.min(1, dt * 12);

    // ---- face
    let ex = 'neutral';
    switch (this.phase) {
      case 'sail': ex = Math.abs(this.boat.v) > 45 ? 'happy' : 'neutral'; break;
      case 'aim': ex = 'focus'; break;
      case 'fly': ex = 'alert'; break;
      case 'wait': ex = this.nibbling ? 'alert' : 'neutral'; break;
      case 'bite': ex = 'excited'; break;
      case 'fight': ex = !f ? 'focus' : f.tension > 0.95 ? 'strain' : f.state === 'jump' ? 'excited' : f.slack > 1.1 ? 'alert' : 'focus'; break;
      case 'landing': ex = 'excited'; break;
      case 'pamer': case 'caught': ex = ((this.t * 3.5) | 0) & 1 ? 'happy2' : 'happy'; break;
      case 'fail': ex = ((this.t * 2.5) | 0) & 1 ? 'sad2' : 'sad'; break;
    }
    this.blinkT -= dt;
    if (this.blinkT < -0.12) this.blinkT = 2 + Math.random() * 3;
    if (this.blinkT < 0 && (ex === 'neutral' || ex === 'focus')) ex = 'blink';
    this.expr = ex;
    this.emoT -= dt;
    if (this.emoT <= 0) {
      this.emoT = 0.16;
      const hx = this.head.x, hy = this.head.y;
      if (ex === 'strain') this.addPart(hx + (Math.random() - 0.5) * 10, hy - 3, (Math.random() - 0.5) * 44 - 12, -26 - Math.random() * 20, 0.5, hex('#9fe6ff'), 150, 999, 0);
      else if (ex === 'sad' || ex === 'sad2') this.addPart(hx + (Math.random() - 0.5) * 8, hy + 3, 0, 12, 0.7, hex('#7fc8ff'), 50, 999, 0);
      else if ((ex === 'happy' || ex === 'happy2') && this.phase !== 'sail') this.addPart(hx + (Math.random() - 0.5) * 24, hy - 4 - Math.random() * 8, 0, -8, 0.6, K.gold, 0, 999, 2);
      else if (ex === 'excited') this.addPart(hx + (Math.random() - 0.5) * 16, hy - 8, 0, -10, 0.4, K.white, 0, 999, 2);
    }
  }

  // ================================================================= render
  private boatGeom() {
    const b = this.boatSpr, f = this.fight;
    const sx = Math.round(this.boat.x - this.cam + 192);
    const bob = Math.round(fsin(this.t * 1.7 + this.boat.x * 0.02) * 1.2 + fsin(this.t * 2.9) * 0.5 + (f && this.phase === 'fight' ? fsin(this.t * 7) * f.tension * 0.8 : 0));
    const left = sx - (b.s.w >> 1), top = BOAT_Y - b.wl + bob;
    const flip = this.boat.dir < 0;
    const lx = b.manSail + (b.manFish - b.manSail) * this.boat.fm;
    const dk = b.deck + (b.deckF - b.deck) * this.boat.fm;
    return { b, left, top, flip, mx: Math.round(left + (flip ? b.s.w - 1 - lx : lx)), my: Math.round(top + dk) };
  }
  private lineTarget() {
    const f = this.fight;
    if (this.phase === 'fight' && f) return f.jump ? { x: f.mx, y: f.my } : { x: f.ex, y: f.ey };
    if (this.phase === 'landing') return { x: this.land.mx, y: this.land.my };
    return this.ent;
  }
  /** draw a fish with its MOUTH at (mx,my) and its nose pointing along theta (body trails behind) */
  private fishAt(s0: Surface, mx: number, my: number, theta: number, sc: number, l: number[] | null, clipY: number, wA: number, wP: number, right = Math.cos(theta) >= 0) {
    const rot = right ? theta : theta - Math.PI;
    const ox = (s0.w / 2 - s0.ax) * (right ? -1 : 1), oy = s0.h / 2 - s0.ay;
    const cs = Math.cos(rot), sn = Math.sin(rot);
    this.fb.blitRot(s0, mx + (ox * cs - oy * sn) * sc, my + (ox * sn + oy * cs) * sc, rot, sc, right, l, clipY, 0, 0, wA, wP);
  }

  render() {
    const fb = this.fb;
    fb.d.set(this.sky.d, 0);
    this.drawSky();
    this.drawClouds(true); this.drawIsles(true); this.drawClouds(false); this.drawIsles(false);
    this.renderSea();
    this.drawSeaDecor();
    this.drawPier();
    this.drawRips();
    this.drawSpots();
    this.drawBoat();
    this.drawLeaps(true);
    this.drawFishing();
    this.drawParts();
    this.drawBirds();
    if (this.phase === 'caught') this.drawCatch();
    this.drawHud();
    const d = fb.d;
    for (let i = 0; i < this.vig.length; i++) { const k = this.vig[i]; d[k] = shade(d[k], 0.8); }
    if (this.flash > 0.03) { const a = Math.min(0.7, this.flash * 0.7); for (let i = 0; i < d.length; i++) d[i] = mix(d[i], K.white, a); }
    if (this.shake > 0.4) {
      const dx = Math.round((Math.random() - 0.5) * this.shake), dy = Math.round((Math.random() - 0.5) * this.shake);
      if (dy > 0) d.copyWithin(dy * W, 0, (H - dy) * W);
      else if (dy < 0) d.copyWithin(0, -dy * W);
      if (dx) for (let y = 0; y < H; y++) { const r = y * W; if (dx > 0) d.copyWithin(r + dx, r, r + W - dx); else d.copyWithin(r, r - dx, r + W); }
    }
  }

  private drawSky() {
    const fb = this.fb, th = this.th, d = fb.d;
    if (th.stars > 0.03) {
      for (const s of this.stars) {
        const a = th.stars * s.b * (0.6 + 0.4 * fsin(this.t * s.sp + s.ph));
        fb.blend(s.x, s.y, K.white, a);
        if (s.b > 0.9) { fb.blend(s.x - 1, s.y, K.white, a * 0.4); fb.blend(s.x + 1, s.y, K.white, a * 0.4); fb.blend(s.x, s.y - 1, K.white, a * 0.4); fb.blend(s.x, s.y + 1, K.white, a * 0.4); }
      }
      if (this.shoot.t < 0.5) for (let i = 0; i < 9; i++) fb.blend(this.shoot.x + this.shoot.t * 160 - i * 2, this.shoot.y + this.shoot.t * 70 - i, K.white, th.stars * (1 - i / 9) * (1 - this.shoot.t * 2));
    }
    const body = (sx: number, sy: number, R: number, col: number, glow: number, moon: boolean) => {
      for (let y = Math.max(0, sy - R - 18); y < Math.min(HZ, sy + R + 18); y++)
        for (let x = Math.max(0, sx - R - 18); x <= Math.min(W - 1, sx + R + 18); x++) {
          const dd = Math.hypot(x - sx, y - sy), i = y * W + x;
          if (dd <= R) d[i] = moon ? (Math.hypot(x - sx - 4, y - sy + 3) < R * 0.9 ? col : shade(col, 0.82)) : mix(col, glow, clamp((y - sy) / R, 0, 1) * 0.45);
          else if (dd < R + 5) { if (bayer(x, y) < 0.8) d[i] = mix(d[i], glow, 0.55); }
          else if (dd < R + 18) { if (bayer(x, y) < (1 - (dd - R - 5) / 13) * 0.6) d[i] = mix(d[i], glow, 0.3); }
        }
    };
    body(Math.round(th.sunX), Math.round(th.sunY), Math.round(th.sunR), th.sun, th.glow, false);
    if (th.stars > 0.03) {
      const my = Math.round(120 - 86 * th.stars);
      body(300, my, 10, hex('#f4f6ff'), hex('#8fb0e8'), true);
      fb.px(297, my + 3, hex('#c4cdea')); fb.px(303, my - 2, hex('#c4cdea')); fb.px(302, my + 5, hex('#c4cdea'));
    }
  }

  private drawClouds(far: boolean) {
    for (const c of this.clouds) {
      if (c.far !== far) continue;
      const x = ((((c.x + c.v * this.t - this.cam * c.p) % 800) + 800) % 800) - 130;
      if (x > W) continue;
      this.fb.blitPal(c.s, x, c.y, far ? this.palF : this.palN);
    }
  }

  private drawIsles(far: boolean) {
    const fb = this.fb, th = this.th, d = fb.d;
    const palm = [0, mix(th.isl, hex('#3a2416'), 0.6), shade(th.isl, 0.8), th.lit];
    for (const is of this.isles) {
      if (is.far !== far) continue;
      const sx = Math.round(is.lx - this.cam * is.p + 192);
      if (sx > W || sx + is.w < 0) continue;
      const base = far ? th.far : th.isl;
      const lit = far ? mix(th.far, th.sky[4], 0.35) : th.lit;
      if (is.kind === 3) {
        const cx = sx + (is.w >> 1), ty = HZ - is.hgt[is.w >> 1];
        for (let k = 0; k < 5; k++) fb.disc(cx + k * 3 + fsin(this.t * 0.5 + k) * 2, ty - 4 - k * 4, 2 + k * 0.7, mix(th.cm, th.sky[2], 0.35 + k * 0.12));
      }
      for (let c = 0; c < is.w; c++) {
        const x = sx + c;
        if (x < 0 || x >= W) continue;
        const h = is.hgt[c];
        if (h <= 0) continue;
        const top = HZ - h;
        for (let y = top; y < HZ; y++) {
          const rel = y - top;
          let col = base;
          if (far) {
            if (rel === 0) col = lit;
            else if (is.kind === 3 && rel < h * 0.5 && hash2(c >> 1, y >> 1) < 0.2) col = mix(base, lit, 0.4);
            if (is.kind === 3 && th.stars > 0.4 && rel < 3 && Math.abs(c - is.w / 2) < is.w * 0.08) col = hex('#ff8a3a');
          } else if (is.kind === 0) {
            const hs = hash2(c + is.seed * 57, y);
            col = rel < 1 || hs < 0.2 ? lit : hs < 0.38 ? shade(base, 0.84) : base;
            if (y === HZ - 1) col = th.sand;
          } else if (is.kind === 1) {
            if (y >= HZ - 2 && (c < 2 || c > is.w - 3)) continue;
            const hs = hash2(c + is.seed * 57, y);
            if (rel > h * 0.45) col = hash2((c >> 1) + is.seed, 3) < 0.35 ? shade(th.rock, 0.76) : c < is.w * 0.3 ? mix(th.rock, K.white, 0.2) : th.rock;
            else col = rel < 1 || hs < 0.24 ? lit : hs < 0.42 ? shade(base, 0.84) : base;
          } else col = hash2((c >> 1) + is.seed, y >> 1) < 0.28 || rel < 1 ? th.lit : base;
          d[y * W + x] = col;
        }
      }
      if (!far && is.kind === 0) for (const p of is.palms) fb.blitPal(PALM, sx + p - 6, HZ - is.hgt[p] - 12, palm, (p & 1) === 1);
      if (is.light) {
        const lx = sx + 40, ty = HZ - is.hgt[40] - 15, l = th.l;
        fb.rect(lx, ty, 4, 16, mul(hex('#f6f3e8'), l[0], l[1], l[2]));
        fb.rect(lx, ty + 3, 4, 3, mul(hex('#e8483a'), l[0], l[1], l[2]));
        fb.rect(lx, ty + 10, 4, 3, mul(hex('#e8483a'), l[0], l[1], l[2]));
        fb.rect(lx - 1, ty - 3, 6, 3, hex('#2a2438'));
        fb.rect(lx, ty - 2, 4, 1, fsin(this.t * 2.2) > 0 ? hex('#fff6a8') : hex('#8a7a48'));
        fb.rect(lx, ty - 5, 4, 2, mul(hex('#e8483a'), l[0], l[1], l[2]));
      }
    }
  }

  private renderSea() {
    const d = this.fb.d, th = this.th, t = this.t, cam = this.cam;
    const night = th.stars > 0.5;
    const gX = night ? 300 : Math.round(th.sunX);
    const gS = night ? 0.75 : clamp((th.sunY - 10) / 70, 0.3, 1);
    const glint = th.glint, bio = hex('#5fffe0');
    const tf = (t * 6) | 0;
    for (let y = HZ; y < H; y++) {
      const dy = y - HZ, row = y * W;
      const inv = 1 / (0.25 + (0.75 * dy) / 50);
      const ph = 5 * Math.pow(dy + 3, 0.55) - t * 1.3;
      const thr = 0.8 + (0.12 * dy) / 116, thr2 = thr + (1 - thr) * 0.55;
      const cA = this.rowA[dy], cB = this.rowB[dy], fr = this.rowF[dy], h1 = this.rowH1[dy], h2 = this.rowH2[dy], lo = this.rowLo[dy];
      const gw = (2.5 + dy * 0.3) * (0.6 + gS * 0.6);
      const by = (y & 3) << 2, rowWob = dy * 0.31, gy = y * 1.9 + t * 2.6, gOff = 0.1 + (1 - gS) * 0.5;
      let wx = cam - 192 * inv;
      for (let x = 0; x < W; x++, wx += inv) {
        let c = fr > BAYER[by | (x & 3)] ? cB : cA;
        const v = fsin(ph + fsin(wx * 0.023 + rowWob) * 1.1 + fsin(wx * 0.0071 - t * 0.2) * 0.8);
        if (v > thr) {
          if (fsin(wx * 0.05 + ph * 0.6 + t * 0.35) > -0.35) {
            c = v > thr2 ? h2 : h1;
            if (v > thr2 && (x * 7 + y * 13 + tf * 5) % 23 === 0) c = night ? bio : K.white;
          }
        } else if (v < -0.9) c = lo;
        const gx = x - gX, ax = gx < 0 ? -gx : gx;
        if (ax < gw && fsin(gy + fsin(x * 0.35 + y * 0.8 + t) * 2.2) > gOff + (ax / gw) * 0.85) c = glint;
        d[row + x] = c;
      }
    }
  }

  /** island reflections, distant ships, dolphins */
  private drawSeaDecor() {
    const fb = this.fb, th = this.th;
    for (const is of this.isles) {
      if (is.far) continue;
      const sx = Math.round(is.lx - this.cam * is.p + 192);
      if (sx > W || sx + is.w < 0) continue;
      for (let c = 0; c < is.w; c++) {
        const h = is.hgt[c];
        if (h <= 0) continue;
        const n = Math.min(9, 2 + (h >> 2));
        for (let j = 0; j < n; j++) {
          if ((sx + c + j * 3 + ((this.t * 2) | 0)) % 4 === 0) continue;
          fb.blend(sx + c + Math.round(fsin(j * 1.2 + this.t * 2 + c * 0.1)), HZ + j, th.isl, 0.5 - j * 0.05);
        }
      }
    }
    const shipCol = mix(th.far, th.isl, 0.55);
    for (const lx of [300, 690]) {
      const sx = Math.round(lx + this.t * 0.6 - this.cam * 0.22 + 192);
      if (sx < -30 || sx > W) continue;
      fb.blitTint(PINISI, sx, HZ - 12, shipCol);
      for (let j = 0; j < 4; j++) for (let i = 2; i < 24; i += 1 + (j & 1)) fb.blend(sx + i + Math.round(fsin(j + this.t * 2)), HZ + 1 + j, shipCol, 0.4 - j * 0.08);
    }
    this.drawLeaps(false);
  }

  private drawLeaps(near: boolean) {
    const l = this.th.l.map((v) => (near ? v + (1 - v) * 0.5 : v * 0.9));
    for (const o of this.leaps) {
      if (o.t < 0 || o.y >= 140 !== near) continue;
      const u = o.t / o.dur, sub = o.spr.h * o.sc * 0.3, hg = o.h + sub;
      const x = o.x + o.dir * o.trav * u, y = o.y + sub - hg * 4 * u * (1 - u);
      const pitch = Math.atan2(-hg * 4 * (1 - 2 * u), o.trav) * 0.62;
      this.fb.blitRot(o.spr, x, y, o.dir > 0 ? pitch : -pitch, o.sc, o.dir > 0, l, Math.round(o.y), 0, 0, 2.2, this.t * 22 + o.x);
    }
  }

  private drawPier() {
    const ox = Math.round(-this.cam + 192);
    if (ox + 80 < 0) return;
    const fb = this.fb, l = this.th.l;
    const C = (h: string) => mul(hex(h), l[0], l[1], l[2]);
    const wood = C('#b98a52'), woodD = C('#7a5630'), woodL = C('#e6c080'), red = C('#e8483a'), white = C('#fbf6e6'), yel = C('#ffd23e');
    for (let px = -30; px <= 66; px += 16) {
      fb.rect(ox + px, 141, 2, 11, woodD);
      for (let j = 0; j < 5; j++) fb.blend(ox + px + (j & 1), 152 + j, woodD, 0.42 - j * 0.07);
    }
    fb.rect(ox - 60, 138, 132, 1, woodL);
    fb.rect(ox - 60, 139, 132, 2, wood);
    fb.rect(ox - 60, 141, 132, 1, woodD);
    for (let px = -58; px < 72; px += 6) fb.px(ox + px, 139, woodD);
    const hx = ox + 8;
    fb.rect(hx, 121, 32, 17, C('#ecd0a0'));
    for (let i = 4; i < 32; i += 5) fb.rect(hx + i, 121, 1, 17, C('#cba872'));
    fb.rect(hx + 3, 127, 8, 11, C('#6a4428'));
    fb.px(hx + 9, 133, yel);
    fb.rect(hx + 15, 126, 13, 7, C('#3a2a1c'));
    fb.rect(hx + 14, 133, 15, 1, woodL);
    for (let i = 0; i < 15; i++) fb.rect(hx + 14 + i, 123, 1, 3, (i >> 1) & 1 ? red : white);
    for (let j = 0; j < 10; j++) {
      const w = 42 - (9 - j) * 3;
      fb.rect(hx + 16 - (w >> 1), 111 + j, w, 1, j % 3 === 2 ? C('#a87830') : C('#dcae50'));
    }
    fb.rect(ox + 66, 114, 1, 24, woodD);
    fb.rect(ox + 65, 112, 3, 2, fsin(this.t * 3) > -0.5 ? hex('#fff6a8') : yel);
    for (let i = 0; i <= 12; i++) {
      const u = i / 12, x = hx + 34 + (ox + 66 - hx - 34) * u, y = 115 + Math.sin(u * Math.PI) * 5;
      fb.px(x, y, woodD);
      if (i > 0 && i < 12) { const col = [red, white, yel][i % 3]; fb.rect(x - 1, y + 1, 3, 1, col); fb.px(x, y + 2 + (fsin(this.t * 5 + i) > 0.3 ? 1 : 0), col); }
    }
    fb.rect(ox + 46, 133, 6, 5, wood); fb.rect(ox + 46, 133, 6, 1, woodL); fb.rect(ox + 48, 134, 1, 4, woodD);
    fb.rect(ox + 53, 134, 5, 4, C('#3f7fd8')); fb.rect(ox + 53, 134, 5, 1, C('#8fc0f8'));
    fb.rect(ox - 20, 132, 5, 6, C('#c85a3a')); fb.rect(ox - 20, 134, 5, 1, woodD);
  }

  private drawRips() {
    const fb = this.fb, th = this.th;
    for (const r of this.rips) {
      const u = 1 - r.life / r.dur, rad = r.max * (0.25 + 0.75 * u);
      const col = r.col || (u < 0.5 ? K.white : th.hi);
      fb.ring(r.x, r.y, rad, Math.max(1, rad * 0.32), col, u > 0.55 ? 2 : 0, (this.t * 10) | 0);
    }
  }

  private drawSpots() {
    const fb = this.fb, th = this.th;
    for (const s of this.spots) {
      const sx = Math.round(s.x - this.cam + 192);
      if (sx < -40 || sx > W + 40) continue;
      const col = s.gold ? K.gold : th.hi;
      fb.ring(sx, BOAT_Y + 3, 21 + fsin(this.t * 3) * 2, 5, col, 3, (this.t * 8) | 0);
      if (s.gold) fb.ring(sx, BOAT_Y + 3, 15 + fsin(this.t * 3 + 1) * 2, 3.5, K.white, 2, (this.t * 6) | 0);
      if (this.phase === 'sail' && s !== this.near) fb.blit(ARROW, sx - 4, 134 + Math.round(fsin(this.t * 5) * 2));
    }
  }

  private drawBoat() {
    const fb = this.fb, th = this.th, l = th.l, g = this.boatGeom();
    const { b, left, top, flip } = g;
    const dir = flip ? -1 : 1, sw = b.s.w;
    for (let j = 1; j <= 7; j++) {
      const src = b.wl - 1 - Math.round(j * 1.4);
      if (src < 0) break;
      const xo = Math.round(fsin(j * 1.3 + this.t * 3.5) * 1.3), a = 0.42 - j * 0.05;
      for (let c = 0; c < sw; c++) {
        const v = b.s.d[src * sw + (flip ? sw - 1 - c : c)];
        if (v) fb.blend(left + c + xo, BOAT_Y + 1 + j, shade(v, 0.5), a);
      }
    }
    this.drawMan(g);
    fb.blit(b.s, left, top, flip, l);
    const fx = left + (flip ? sw - 1 - b.flagX : b.flagX), fy = top + b.flagY;
    const fr = mul(hex('#e8483a'), l[0], l[1], l[2]), fw = mul(hex('#fbf6e6'), l[0], l[1], l[2]);
    for (let i = 0; i < 8; i++) {
      const yy = fy + Math.round(fsin(this.t * 6 - i * 0.8) * (i / 8) * 1.6);
      fb.rect(fx - dir * (i + 1), yy, 1, 2, fr);
      fb.rect(fx - dir * (i + 1), yy + 2, 1, 2, fw);
    }
    const tfm = ((this.t * 7) | 0) * 31;
    for (let c = 2; c < sw - 2; c++) {
      if (!b.s.d[b.wl * sw + (flip ? sw - 1 - c : c)]) continue;
      const hs = hash2(c + tfm, 5);
      if (hs < 0.55) fb.px(left + c, BOAT_Y + 1, hs < 0.25 ? K.white : th.hi);
    }
  }

  /** the angler: a little articulated rig (legs/arms with IK, leaning torso, expression head, rod + reel) */
  private drawMan(g: { mx: number; my: number; flip: boolean }) {
    const fb = this.fb, l = this.th.l, P = this.ps, f = this.fight;
    const dir = g.flip ? -1 : 1;
    const C = (c: string) => mul(hex(c), l[0], l[1], l[2]);
    const skin = C('#f0b488'), skinD = C('#c98a5e'), vest = C('#f59a22'), vestD = C('#c86a14'), tape = C('#ffe9a0'), sleeve = C('#2f6fd0'), sleeveD = C('#2459ad'), pants = C('#34406a'), shoe = C('#1b1b26'), ol = K.dark;
    const T = f && this.phase === 'fight' ? f.tension : 0;
    const tick = ((this.t * 34) | 0) & 1;
    const sh = T > 0.85 ? (tick ? 1 : -1) * (T > 1 ? 1 : 0.5) : 0;
    const up = P.up > 0.5;
    const heavy = !!f && f.ci.sp.tier >= 3;
    const hop = up && !heavy && this.phase !== 'landing' ? Math.round(Math.abs(fsin(this.t * 8)) * 2) : 0;
    const cx = g.mx, fy = g.my - hop;
    const hx = cx + dir * P.hipX, hy = fy - P.hipY - 1.4;
    const nx = hx + dir * Math.sin(P.lean) * 7, ny = hy - Math.cos(P.lean) * 7;

    // legs (knees bend forward; braced wide while fighting)
    for (const sd of [-1, 1]) {
      const br = sd > 0 ? P.br : 0; // front foot braced up on the gunwale while fighting
      const k = ik(hx + sd * dir, hy, cx + sd * dir * (P.st + br), fy - 1 - br * 3, 5.3, 5.3, -dir);
      fb.limb(hx + sd * dir, hy, k[0], k[1], 5, ol); fb.limb(k[0], k[1], k[2], k[3], 4, ol);
      fb.limb(hx + sd * dir, hy, k[0], k[1], 3, pants); fb.limb(k[0], k[1], k[2], k[3], 2, sd < 0 ? skinD : skin);
      fb.rect(Math.round(k[2]) - (dir > 0 ? 1 : 2), Math.round(k[3]), 4, 2, shoe);
    }

    // rod geometry
    const ca = Math.cos(this.rodA), sa = Math.sin(this.rodA);
    const dx = dir * ca, dy = -sa;
    const gx = hx + dir * P.gx + (nx - hx) * 0.5 + sh, gy = hy + P.gy + (ny + 7 - hy) * 0.5;
    const rx = gx + dx * 2 - dir * sa * 1.6, ry = gy + dy * 2 - ca * 1.6; // reel sits on top of the rod
    const kx = rx + Math.cos(this.crank) * 2 * dir, ky = ry + Math.sin(this.crank) * 2; // crank knob

    // hand targets
    let fhx: number, fhy: number, nhx: number, nhy: number;
    const al = up ? 5.6 : 4.6, shy = ny + (up ? 1 : 2);
    if (up) { fhx = nx - dir * 4; nhx = nx + dir * 4; fhy = nhy = ny - 10 + (heavy && tick ? 1 : 0); }
    else {
      fhx = gx + dx * 5.5; fhy = gy + dy * 5.5;
      if (this.cranking) { nhx = kx; nhy = ky; } else { nhx = gx - dx * 1.2; nhy = gy - dy * 1.2 + 1; }
    }

    // far arm (foregrip) — behind the torso
    const fa = ik(nx - dir, shy, fhx, fhy, al, al, up ? -dir : dir);
    fb.limb(nx - dir, shy, fa[0], fa[1], 4, ol); fb.limb(fa[0], fa[1], fa[2], fa[3], 4, ol);
    fb.limb(nx - dir, shy, fa[0], fa[1], 2, sleeveD); fb.limb(fa[0], fa[1], fa[2], fa[3], 2, skinD);

    // torso (life vest)
    for (let pass = 0; pass < 2; pass++)
      for (let i = 0; i <= 8; i++) {
        const t = i / 8, x = Math.round(hx + (nx - hx) * t), y = Math.round(hy + (ny + 2 - hy) * t);
        if (!pass) fb.rect(x - 4, y - 2, 8, 4, ol);
        else {
          fb.rect(x - 3, y - 1, 6, 2, i < 2 ? pants : i === 5 ? tape : vest);
          if (i >= 2 && i !== 5) fb.rect(dir > 0 ? x - 3 : x + 2, y - 1, 1, 2, vestD);
        }
      }

    // head
    const ex = this.expr, hs = this.heads[ex] || this.heads.neutral;
    const droop = this.phase === 'fail' ? 1 : 0;
    const hl = ex === 'strain' ? [l[0] * 1.12, l[1] * 0.84, l[2] * 0.82] : l;
    fb.blit(hs, nx - 7 + (dir < 0 ? 1 : 0) + dir * droop + (ex === 'strain' ? sh : 0), ny - 10 + droop, g.flip, hl);
    this.head.x = nx; this.head.y = ny - 6;

    // rod + reel
    const RL = 30 + this.sv.rod * 2;
    const rc = C(ROD[this.sv.rod - 1].col), grip = C('#2a2030');
    if (up) {
      // rod parked upright in the boat while both hands hold the fish
      const sx0 = cx - dir * 11;
      fb.rect(sx0, fy - 2 - RL, 1, RL, rc);
      fb.rect(sx0, fy - 11, 2, 9, grip);
      this.tip.x = sx0; this.tip.y = fy - 2 - RL;
    } else {
      const ux = gx + dx * RL, uy = gy + dy * RL;
      let tx = ux, ty = uy;
      if (this.bend > 0.01) {
        const lt = this.lineTarget();
        let bx = lt.x - ux, by = lt.y - uy;
        const dd = Math.hypot(bx, by) || 1;
        bx /= dd; by /= dd;
        tx = ux + bx * this.bend * RL * 0.55; ty = uy + by * this.bend * RL * 0.55;
      }
      const mx2 = gx + dx * RL * 0.6, my2 = gy + dy * RL * 0.6;
      let px = gx - dx * 4, py = gy - dy * 4;
      for (let i = 0; i <= 14; i++) {
        const u = i / 14, a = (1 - u) * (1 - u), b2 = 2 * u * (1 - u), c2 = u * u;
        const x = a * gx + b2 * mx2 + c2 * tx, y = a * gy + b2 * my2 + c2 * ty;
        fb.line(px, py, x, y, i < 4 ? grip : rc);
        if (i < 5) fb.line(px, py + 1, x, y + 1, i < 4 ? grip : shade(rc, 0.7));
        px = x; py = y;
      }
      fb.px(tx, ty, K.white);
      fb.rect(Math.round(rx) - 2, Math.round(ry) - 2, 4, 4, ol);
      fb.rect(Math.round(rx) - 1, Math.round(ry) - 1, 3, 3, C(this.sv.reel > 3 ? '#f2c14e' : '#c4cede'));
      fb.px(rx, ry, ol);
      fb.px(kx, ky, C('#e8483a'));
      this.tip.x = tx; this.tip.y = ty;
    }

    // far hand on the foregrip, then the near arm (the one that cranks the reel)
    fb.rect(Math.round(fa[2]) - 1, Math.round(fa[3]) - 1, 2, 2, skinD);
    const na = ik(nx + dir, shy, nhx, nhy, al, al, dir);
    fb.limb(nx + dir, shy, na[0], na[1], 4, ol); fb.limb(na[0], na[1], na[2], na[3], 4, ol);
    fb.limb(nx + dir, shy, na[0], na[1], 2, sleeve); fb.limb(na[0], na[1], na[2], na[3], 2, skin);
  }

  private curve(x0: number, y0: number, x1: number, y1: number, sag: number, col: number) {
    const fb = this.fb;
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2 + sag;
    let px = x0, py = y0;
    for (let i = 1; i <= 12; i++) {
      const u = i / 12, a = (1 - u) * (1 - u), b = 2 * u * (1 - u), c = u * u;
      const x = a * x0 + b * cx + c * x1, y = a * y0 + b * cy + c * y1;
      fb.line(px, py, x, y, col);
      px = x; py = y;
    }
  }

  private drawFishing() {
    const fb = this.fb, th = this.th, tip = this.tip, f = this.fight;
    const lc = mix(K.white, th.sky[1], 0.12);
    const lf = th.l.map((v) => v + (1 - v) * 0.65);
    const lcol = this.lure.kind === 'b' ? hex('#bfe0d6') : hex((LURES.find((q) => q.id === this.lure.id) || LURES[0]).col);
    switch (this.phase) {
      case 'fly': {
        const lp = this.lureP;
        this.curve(tip.x, tip.y, lp.x, lp.y, 8 * (1 - lp.u), lc);
        fb.rect(lp.x - 1, lp.y - 1, 3, 3, K.dark);
        fb.rect(lp.x - 1, lp.y - 1, 2, 2, lcol);
        break;
      }
      case 'sink': case 'wait': case 'bite': {
        const ex = this.ent.x, ey = this.ent.y;
        this.curve(tip.x, tip.y, ex, ey, this.phase === 'bite' ? 0 : Math.max(0, 6 - this.twitch * 6), lc);
        fb.ring(ex, ey, 3.5 + fsin(this.t * 4), 1.3, th.hi);
        fb.px(ex, ey, K.white);
        if (this.phase === 'bite') {
          fb.ring(ex, ey, 9 + fsin(this.t * 20) * 2, 3, K.red);
          fb.blit(EXCL, ex - 3, ey - 30 - Math.round(Math.abs(fsin(this.t * 14)) * 4));
        }
        break;
      }
      case 'fight': {
        if (!f) break;
        const tg = this.lineTarget();
        const col = f.tension > 1 && (this.t * 16) & 1 ? K.red : lc;
        this.curve(tip.x, tip.y, tg.x, tg.y, Math.max(0, 0.3 - f.tension) * 24 + (f.tension > 0.8 ? fsin(this.t * 40) * 0.8 : 0), col);
        if (f.jump) fb.blitRot(f.spr, f.fx, f.fy, f.fa, f.sc, f.jump.dir > 0, lf, f.jump.y0, K.white, f.hitFlash, 2.4, this.t * 24);
        else {
          // dragged close: the fish breaks the surface, pulled by the mouth towards the rod (or diving away on a run)
          const near = clamp((11 - f.dist) / 5, 0, 1);
          if (near > 0.03) {
            if (f.state === 'run') {
              // diving away on a run: only the thrashing tail sticks out of the water
              const sw = f.spr.w * f.sc, a = 0.9 + 0.08 * fsin(this.t * 19), dp = sw * (0.55 + (1 - near) * 0.4);
              this.fishAt(f.spr, f.ex + Math.cos(a) * dp, f.ey + Math.sin(a) * dp, a, f.sc, lf, Math.round(f.ey), 3, this.t * 30, true);
            } else {
              // head pulled up towards the rod, body trailing behind and below the surface
              const th0 = Math.PI + 0.2 + 0.32 * near + 0.13 * fsin(this.t * 16);
              this.fishAt(f.spr, f.ex, f.ey + (1 - near) * 6 - near * 3.5, th0, f.sc, lf, Math.round(f.ey), 2.6, this.t * 20);
            }
          }
          fb.ring(f.ex, f.ey, 4, 1.5, K.white, 2, (this.t * 12) | 0);
          fb.px(f.ex, f.ey, K.white); fb.px(f.ex + 1, f.ey, th.hi); fb.px(f.ex - 1, f.ey, th.hi);
        }
        break;
      }
      case 'landing': {
        if (!f) break;
        const L = this.land;
        if (this.pt < 0.75) this.curve(tip.x, tip.y, L.mx, L.my, 0, lc);
        this.fishAt(f.spr, L.mx, L.my, L.th, f.sc, lf, L.wy, 2.8, this.t * 26, true);
        break;
      }
      case 'pamer': case 'caught': {
        // held over the head at its real size, tail still flapping
        if (f) { const c = this.holdPos(f); fb.blitRot(f.spr, c.x, c.y, fsin(this.t * 3) * 0.035, f.sc, true, lf, 99999, 0, 0, 1.6, this.t * 10); }
        break;
      }
      default: {
        const lx = tip.x + fsin(this.t * 2.2) * 2 - this.boat.v * 0.04, ly = tip.y + 8;
        fb.line(tip.x, tip.y, lx, ly, lc);
        fb.rect(lx - 1, ly, 2, 2, lcol);
        fb.px(lx, ly + 2, hex('#aeb9cc'));
      }
    }
  }

  private drawParts() {
    const fb = this.fb, th = this.th;
    for (const p of this.parts) {
      const u = p.life / p.max;
      if (p.kind === 1) fb.rect(p.x, p.y, 1 + ((u * 3) | 0), 1, u > 0.5 ? p.col : th.hi);
      else if (p.kind === 2) {
        fb.px(p.x, p.y, p.col);
        if (u > 0.35) { fb.px(p.x - 1, p.y, p.col); fb.px(p.x + 1, p.y, p.col); fb.px(p.x, p.y - 1, p.col); fb.px(p.x, p.y + 1, p.col); }
      } else if (p.kind === 3) fb.rect(p.x, p.y, 2, 2, p.col);
      else fb.px(p.x, p.y, p.col);
    }
  }

  private drawBirds() {
    const fb = this.fb, l = this.th.l;
    const body = mul(K.white, Math.min(1, l[0] + 0.15), Math.min(1, l[1] + 0.15), Math.min(1, l[2] + 0.1)), tipc = mul(hex('#7a8494'), l[0], l[1], l[2]);
    const bird = (x: number, y: number, flap: number) => {
      const wy = Math.round(-1 - flap * 2);
      fb.line(x, y, x - 3, y + wy, body); fb.line(x + 1, y, x + 4, y + wy, body);
      fb.px(x - 3, y + wy, tipc); fb.px(x + 4, y + wy, tipc);
      fb.px(x, y, body); fb.px(x + 1, y, body);
    };
    for (const s of this.spots) {
      const sx = s.x - this.cam + 192;
      if (sx < -50 || sx > W + 50) continue;
      for (const b of s.birds) bird(Math.round(sx + Math.cos(b.a) * b.r), Math.round(BOAT_Y - b.h + Math.sin(b.a) * b.r * 0.25), fsin(this.t * 9 + b.ph));
    }
    for (const g of this.gulls) {
      const x = ((((g.x + g.v * this.t - this.cam * 0.2) % 520) + 520) % 520) - 60;
      bird(Math.round(x), Math.round(g.y + fsin(this.t * 0.7 + g.ph) * 6), fsin(this.t * 6 + g.ph) * 0.8);
    }
  }

  /** stat / introduction screen: sunburst + the fish enlarged */
  private drawCatch() {
    const fb = this.fb, d = fb.d, spr = this.cSpr;
    if (!spr) return;
    if (!this.rayA) {
      this.rayA = new Float32Array(W * H);
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) this.rayA[y * W + x] = Math.atan2(y - 72, x - 192) + Math.PI * 8;
    }
    const ra = this.rayA, rot = this.t * 0.35, gold = hex('#ffe9a0');
    const fade = Math.min(1, this.pt * 3);
    for (let i = 0; i < d.length; i++) d[i] = (((ra[i] + rot) * 3.8197) | 0) & 1 ? mix(d[i], gold, 0.5 * fade) : mix(d[i], K.navy, 0.55 * fade);
    fb.blitRot(spr, 192, 72 + fsin(this.t * 2) * 2, fsin(this.t * 2.6) * 0.05, this.cSc, false, null, 99999, 0, 0, 1.2, this.t * 6);
  }

  /** big face of the angler reacting to what is going on */
  private drawPortrait() {
    const ph = this.phase;
    if (ph === 'title' || ph === 'sail' || ph === 'pick') return;
    const fb = this.fb, ex = this.expr, w = 44, h = 36, y = 4;
    const x = 336 + (ex === 'strain' ? (((this.t * 30) | 0) & 1 ? 1 : -1) : 0);
    const bg = ex === 'strain' ? (((this.t * 12) | 0) & 1 ? hex('#a02828') : hex('#7a1c2a')) : ex === 'excited' ? hex('#c8861e') : ex === 'happy' || ex === 'happy2' ? hex('#2f9a52') : ex === 'sad' || ex === 'sad2' ? hex('#39425c') : hex('#2a4a8c');
    fb.rect(x - 3, y - 3, w + 6, h + 6, K.dark); fb.rect(x - 2, y - 2, w + 4, h + 4, K.gold); fb.rect(x - 1, y - 1, w + 2, h + 2, K.dark);
    fb.rect(x, y, w, h, bg);
    fb.rectD(x, y + h - 14, w, 14, shade(bg, 0.72), 0.5);
    const hs = this.heads[ex] || this.heads.neutral;
    fb.blitScale(hs, x + ((w - hs.w * 3) >> 1), y + 2 + (ex === 'happy2' ? -1 : 0), 3);
  }

  // ================================================================= HUD (drawn in-canvas)
  private drawHud() {
    const fb = this.fb;
    this.drawPortrait();
    if (this.phase === 'aim') {
      const x = 18, y = 50, h = 98, w = 9;
      fb.rect(x - 3, y - 3, w + 6, h + 6, K.dark); fb.rect(x - 2, y - 2, w + 4, h + 4, K.gold); fb.rect(x - 1, y - 1, w + 2, h + 2, K.dark);
      for (let i = 0; i < h; i++) {
        const u = 1 - i / (h - 1);
        let c = u < 0.5 ? mix(K.z0, K.z2, u * 2) : u < 0.8 ? mix(K.z2, K.z3, (u - 0.5) / 0.3) : u <= 0.94 ? K.gold : K.z4;
        if (u > this.power) c = shade(c, 0.3);
        fb.rect(x, y + i, w, 1, c);
        if (u <= this.power) fb.px(x, y + i, mix(c, K.white, 0.5));
      }
      const ya = y + Math.round((1 - 0.94) * (h - 1)), yb = y + Math.round((1 - 0.8) * (h - 1));
      const blink = (this.t * 6) & 1 ? K.white : K.gold;
      fb.rect(x - 2, ya, w + 4, 1, blink); fb.rect(x - 2, yb, w + 4, 1, blink);
      const py = y + Math.round((1 - this.power) * (h - 1));
      for (let i = 0; i < 4; i++) fb.rect(x + w + 3 + i, py - i, 1, i * 2 + 1, i === 3 ? K.dark : K.white);
    } else if (this.phase === 'sink' || this.phase === 'wait' || this.phase === 'bite') {
      const x = 14, y = 42, w = 16, h = 112, sp = this.spot;
      fb.rect(x - 3, y - 3, w + 6, h + 6, K.dark); fb.rect(x - 2, y - 2, w + 4, h + 4, K.gold); fb.rect(x - 1, y - 1, w + 2, h + 2, K.dark);
      fb.rect(x, y, w, h, hex('#0b1e3a'));
      for (let i = 8; i < h; i += 8) fb.rect(x, y + i, w, 1, hex('#14305c'));
      const scan = y + ((this.t * 60) % h | 0);
      fb.rect(x, scan, w, 1, hex('#1f4a8a'));
      if (sp) {
        const hy = y + 2 + sp.hot * (h - 8), hh = 0.09 * (h - 8);
        fb.rectD(x, hy - hh, w, hh * 2, hex('#2fd67a'), 0.5 + 0.25 * fsin(this.t * 5));
        fb.rect(x, hy - hh, w, 1, hex('#8fffb0')); fb.rect(x, hy + hh, w, 1, hex('#8fffb0'));
        for (let k = 0; k < 2; k++) {
          const fxp = x + 3 + (((this.t * 6 + k * 7) | 0) % (w - 6)), fyp = hy - 3 + k * 6;
          fb.rect(fxp, fyp, 3, 2, hex('#eaffea')); fb.px(fxp + 3, fyp - 1, hex('#eaffea')); fb.px(fxp + 3, fyp + 2, hex('#eaffea'));
        }
        for (let i = 0; i < w; i++) fb.rect(x + i, y + h - 3 + ((i * 7) % 3 === 0 ? 0 : 1), 1, 3, hex('#7a5a30'));
        const md = ZONES[sp.zone].maxDepth, ly = y + 2 + (this.depth / md) * (h - 8);
        fb.rect(x + (w >> 1), y, 1, ly - y, hex('#cfe8ff'));
        fb.rect(x + (w >> 1) - 2, ly - 1, 5, 3, K.dark);
        fb.rect(x + (w >> 1) - 1, ly - 1, 3, 3, K.gold); fb.px(x + (w >> 1), ly, K.white);
      }
      if (this.phase !== 'sink') {
        const bx = 132, by = 15, bw = 120;
        fb.rect(bx - 3, by - 3, bw + 6, 11, K.dark); fb.rect(bx - 2, by - 2, bw + 4, 9, K.gold); fb.rect(bx - 1, by - 1, bw + 2, 7, K.dark);
        fb.rect(bx, by, bw, 5, hex('#0b1e3a'));
        const a = this.phase === 'bite' || this.nibbling ? 1 : clamp(this.attract, 0, 1);
        const c = this.nibbling || this.phase === 'bite' ? ((this.t * 12) & 1 ? K.red : K.gold) : hex('#3fc8f0');
        fb.rect(bx, by, Math.round(bw * a), 5, c); fb.rect(bx, by, Math.round(bw * a), 1, mix(c, K.white, 0.5));
        const fxp = bx + Math.round((bw - 8) * a);
        fb.rect(fxp, by - 1, 6, 7, K.dark); fb.rect(fxp + 1, by, 4, 5, K.white); fb.px(fxp + 2, by + 1, K.dark);
        if (this.phase === 'bite') {
          const u = clamp(this.biteT / this.biteMax, 0, 1);
          fb.rect(this.ent.x - 14, this.ent.y - 40, 28, 4, K.dark);
          fb.rect(this.ent.x - 13, this.ent.y - 39, Math.round(26 * u), 2, u > 0.4 ? K.gold : K.red);
        }
      }
    } else if (this.phase === 'fight' && this.fight) this.hudFight(this.fight);
  }

  private hudFight(f: Fight) {
    const fb = this.fb, x0 = 92, w = 200, h = 8;
    const y0 = 13 + (f.tension > 1 ? Math.round((Math.random() - 0.5) * 2.4) : 0);
    fb.rect(x0 - 3, y0 - 3, w + 6, h + 6, K.dark);
    fb.rect(x0 - 2, y0 - 2, w + 4, h + 4, f.tension > 1 && (this.t * 14) & 1 ? K.red : K.gold);
    fb.rect(x0 - 1, y0 - 1, w + 2, h + 2, K.dark);
    for (let i = 0; i < w; i++) {
      const v = (i / w) * 1.25;
      let c = v < 0.2 ? K.z0 : v < 0.45 ? K.z1 : v < 0.9 ? K.z2 : v < 1 ? K.z3 : K.z4;
      const on = v <= f.tension;
      if (!on) c = shade(c, 0.5);
      fb.rect(x0 + i, y0, 1, h, c);
      if (on) { fb.px(x0 + i, y0, mix(c, K.white, 0.5)); fb.px(x0 + i, y0 + h - 1, shade(c, 0.75)); }
    }
    for (const v of [0.45, 0.9]) fb.rect(x0 + Math.round((v / 1.25) * w), y0 - 1, 1, h + 2, K.white);
    const nx = x0 + Math.round((clamp(f.tension, 0, 1.25) / 1.25) * w);
    fb.rect(nx - 2, y0 - 5, 5, 4, K.dark); fb.rect(nx - 1, y0 - 5, 3, 3, K.white); fb.rect(nx, y0 - 2, 1, h + 4, K.white);
    if (f.strain > 0.02) fb.rect(x0, y0 + h + 1, Math.round(w * Math.min(1, f.strain)), 1, (this.t * 10) & 1 ? K.red : K.gold);
    const sy = 28;
    fb.rect(x0 - 1, sy - 1, w + 2, 5, K.dark); fb.rect(x0, sy, w, 3, hex('#3a2038'));
    fb.rect(x0, sy, Math.round(w * f.stam), 3, hex('#ff5a8a')); fb.rect(x0, sy, Math.round(w * f.stam), 1, hex('#ffa8c0'));
    const ty = 36;
    for (let i = 0; i < w; i += 3) fb.px(x0 + i, ty + 1, K.white);
    fb.rect(x0 - 3, ty - 1, 7, 4, K.dark); fb.rect(x0 - 2, ty, 5, 2, K.gold);
    const fxp = x0 + Math.round(w * clamp(f.dist / f.cap, 0, 1));
    fb.rect(fxp - 3, ty - 2, 7, 6, K.dark); fb.rect(fxp - 2, ty - 1, 5, 4, hex('#7fe0ff')); fb.px(fxp - 1, ty, K.dark);

    // ---- the big reel
    const cx = 338, cy = 164, R = 24, a = this.reelAng;
    const sweet = f.tension >= 0.45 && f.tension <= 0.9;
    for (let y = -R - 4; y <= R + 6; y++) for (let x = -R - 5; x <= R + 5; x++) if (x * x + (y - 2) * (y - 2) <= (R + 5) * (R + 5) && bayer(cx + x, cy + y) < 0.5) fb.px(cx + x, cy + y, K.dark);
    fb.disc(cx, cy, R + 3, f.tension > 1 ? ((this.t * 14) & 1 ? K.red : K.dark) : sweet ? K.gold : K.dark);
    fb.disc(cx, cy, R + 1, K.dark);
    fb.disc(cx, cy, R, hex('#5a667c'));
    fb.disc(cx, cy, R - 2, hex('#b4bfd2'));
    fb.disc(cx, cy, R - 4, hex('#8b97ac'));
    for (let y = -R + 4; y < -R + 9; y++) for (let x = -10; x <= 2; x++) if (x * x + y * y < (R - 4) * (R - 4) && bayer(cx + x, cy + y) < 0.5) fb.px(cx + x, cy + y, hex('#c8d2e2'));
    for (let k = 0; k < 6; k++) {
      const an = a + (k * Math.PI) / 3, hx = cx + Math.cos(an) * 13, hy = cy + Math.sin(an) * 13;
      fb.disc(hx, hy, 3, hex('#232b40'));
      fb.px(hx - 1, hy - 2, hex('#4a5670'));
    }
    const spool = hex(this.sv.line > 3 ? '#ffd86a' : '#eaf4ff');
    fb.ring(cx, cy, 8, 8, spool); fb.ring(cx, cy, 7, 7, shade(spool, 0.8));
    const hx = cx + Math.cos(a) * (R + 3), hy = cy + Math.sin(a) * (R + 3);
    const nxn = -Math.sin(a), nyn = Math.cos(a);
    fb.line(cx + nxn * 2, cy + nyn * 2, hx + nxn * 2, hy + nyn * 2, K.dark); fb.line(cx - nxn * 2, cy - nyn * 2, hx - nxn * 2, hy - nyn * 2, K.dark);
    fb.line(cx + nxn, cy + nyn, hx + nxn, hy + nyn, hex('#eef2f8')); fb.line(cx, cy, hx, hy, hex('#d4dbe6')); fb.line(cx - nxn, cy - nyn, hx - nxn, hy - nyn, hex('#9aa6b8'));
    fb.disc(cx - Math.cos(a) * 11, cy - Math.sin(a) * 11, 3, K.dark); fb.disc(cx - Math.cos(a) * 11, cy - Math.sin(a) * 11, 2, hex('#5a667c'));
    fb.disc(cx, cy, 5, K.dark); fb.disc(cx, cy, 4, K.gold); fb.disc(cx, cy, 2, hex('#b8862a')); fb.px(cx - 1, cy - 2, hex('#fff6c0'));
    fb.disc(hx, hy, 7, K.dark); fb.disc(hx, hy, 6, hex('#e8483a')); fb.disc(hx, hy, 4, hex('#f86a58')); fb.disc(hx - 2, hy - 2, 1, hex('#ffc0b0'));
    if (sweet && f.omega > 2) for (let k = 0; k < 8; k++) { const an = -this.t * 3 + (k * Math.PI) / 4; fb.px(cx + Math.cos(an) * (R + 6), cy + Math.sin(an) * (R + 6), k & 1 ? K.white : K.gold); }
  }
}
