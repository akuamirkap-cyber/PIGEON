import type { FishLook } from './fishart';

export interface Species {
  id: string;
  name: string;
  tier: number;
  zone: number;
  minKg: number;
  maxKg: number;
  value: number;
  w: number;
  jump: number;
  desc: string;
  look: FishLook;
}

export const SPECIES: Species[] = [
  {
    id: 'kembung', name: 'Kembung', tier: 1, zone: 0, minKg: 0.4, maxKg: 1.8, value: 14, w: 1.2, jump: 0.5,
    desc: 'Ikan umpan favorit para pemancing. Simpan sebagai umpan hidup!',
    look: { len: 44, depth: 0.27, peak: 0.36, nose: 0.8, taper: 1.1, ped: 0.12, up: 0.5, back: '#2d8a8e', side: '#bfe0d6', belly: '#f4f8ee', fin: '#d9c66a', accent: '#1c5a66', pattern: 'wavy', tail: 'fork', tailLen: 0.2, tailSpread: 0.72,
      fins: [{ side: 1, a: 0.3, b: 0.46, h: 0.42, shape: 'tri' }, { side: 1, a: 0.6, b: 0.74, h: 0.3, shape: 'tri' }, { side: 1, a: 0.76, b: 0.94, h: 0.14, shape: 'finlets' }, { side: -1, a: 0.6, b: 0.74, h: 0.28, shape: 'tri' }, { side: -1, a: 0.76, b: 0.94, h: 0.14, shape: 'finlets' }, { side: -1, a: 0.34, b: 0.44, h: 0.22, shape: 'tri' }] },
  },
  {
    id: 'baronang', name: 'Baronang', tier: 1, zone: 0, minKg: 0.8, maxKg: 3, value: 22, w: 1, jump: 0.4,
    desc: 'Si pipih bertotol penghuni karang dangkal.',
    look: { len: 48, depth: 0.44, peak: 0.4, nose: 0.7, taper: 1.0, ped: 0.16, up: 0.5, back: '#7d8c3a', side: '#cdbf5a', belly: '#f1eaa6', fin: '#a89a3a', accent: '#f6f3c8', pattern: 'spots', tail: 'fork', tailLen: 0.2, tailSpread: 0.6, eye: 1.2,
      fins: [{ side: 1, a: 0.2, b: 0.9, h: 0.26, shape: 'spiny' }, { side: -1, a: 0.5, b: 0.9, h: 0.22, shape: 'spiny' }, { side: -1, a: 0.3, b: 0.42, h: 0.2, shape: 'tri' }] },
  },
  {
    id: 'kakap', name: 'Kakap Merah', tier: 2, zone: 0, minKg: 2, maxKg: 9, value: 70, w: 1, jump: 0.5,
    desc: 'Primadona dasar laut. Tarikannya bikin deg-degan!',
    look: { len: 64, depth: 0.38, peak: 0.36, nose: 0.75, taper: 1.0, ped: 0.2, up: 0.56, back: '#c6362f', side: '#ee6e52', belly: '#fcd3c0', fin: '#d84a3a', accent: '#9c2420', pattern: 'none', tail: 'fork', tailLen: 0.2, tailSpread: 0.62, eye: 1.3,
      fins: [{ side: 1, a: 0.26, b: 0.84, h: 0.3, shape: 'spiny' }, { side: -1, a: 0.58, b: 0.82, h: 0.24, shape: 'round' }, { side: -1, a: 0.32, b: 0.46, h: 0.26, shape: 'tri' }] },
  },
  {
    id: 'kerapu', name: 'Kerapu Macan', tier: 2, zone: 0, minKg: 3, maxKg: 14, value: 95, w: 0.8, jump: 0.35,
    desc: 'Bermulut lebar, bertenaga badak. Suka ngumpet di karang.',
    look: { len: 70, depth: 0.36, peak: 0.38, nose: 0.6, taper: 0.9, ped: 0.26, up: 0.52, back: '#6e4c30', side: '#a8804e', belly: '#e6cfa0', fin: '#7a5a38', accent: '#3d2a1c', pattern: 'spots', tail: 'round', tailLen: 0.17, tailSpread: 0.6, eye: 1.1,
      fins: [{ side: 1, a: 0.24, b: 0.86, h: 0.26, shape: 'spiny' }, { side: -1, a: 0.6, b: 0.84, h: 0.24, shape: 'round' }, { side: -1, a: 0.3, b: 0.44, h: 0.22, shape: 'tri' }] },
  },
  {
    id: 'cakalang', name: 'Cakalang', tier: 2, zone: 1, minKg: 4, maxKg: 16, value: 120, w: 1.1, jump: 0.6,
    desc: 'Torpedo bergaris. Umpan hidup idaman ikan raksasa.',
    look: { len: 66, depth: 0.31, peak: 0.36, nose: 0.95, taper: 1.25, ped: 0.08, up: 0.5, back: '#262f6e', side: '#93a6c9', belly: '#eef2f6', fin: '#3a4580', accent: '#2a3358', pattern: 'stripes', tail: 'lunate', tailLen: 0.17, tailSpread: 0.95,
      fins: [{ side: 1, a: 0.28, b: 0.46, h: 0.5, shape: 'sickle' }, { side: 1, a: 0.6, b: 0.72, h: 0.26, shape: 'tri' }, { side: 1, a: 0.74, b: 0.94, h: 0.1, shape: 'finlets' }, { side: -1, a: 0.6, b: 0.72, h: 0.26, shape: 'tri' }, { side: -1, a: 0.74, b: 0.94, h: 0.1, shape: 'finlets' }] },
  },
  {
    id: 'barakuda', name: 'Barakuda', tier: 2, zone: 1, minKg: 6, maxKg: 22, value: 150, w: 1, jump: 0.8,
    desc: 'Panah perak bergigi tajam. Sambarannya kilat!',
    look: { len: 92, depth: 0.15, peak: 0.42, nose: 1.3, taper: 0.8, ped: 0.3, up: 0.5, back: '#4b6474', side: '#b1c2c8', belly: '#eff4f3', fin: '#5a6a70', accent: '#2f424e', pattern: 'bars', tail: 'fork', tailLen: 0.14, tailSpread: 1.15, eye: 1.4,
      fins: [{ side: 1, a: 0.42, b: 0.52, h: 0.6, shape: 'tri' }, { side: 1, a: 0.72, b: 0.82, h: 0.6, shape: 'tri' }, { side: -1, a: 0.72, b: 0.82, h: 0.55, shape: 'tri' }, { side: -1, a: 0.44, b: 0.52, h: 0.4, shape: 'tri' }] },
  },
  {
    id: 'tenggiri', name: 'Tenggiri', tier: 3, zone: 1, minKg: 10, maxKg: 38, value: 340, w: 1, jump: 0.8,
    desc: 'Pelari kencang berloreng. Reel bisa menjerit!',
    look: { len: 100, depth: 0.2, peak: 0.36, nose: 1.1, taper: 1.0, ped: 0.1, up: 0.5, back: '#2b5d7e', side: '#b6cbd5', belly: '#f3f7f7', fin: '#3d6a84', accent: '#1e4560', pattern: 'bars', tail: 'lunate', tailLen: 0.16, tailSpread: 1.1,
      fins: [{ side: 1, a: 0.26, b: 0.52, h: 0.4, shape: 'sickle' }, { side: 1, a: 0.56, b: 0.68, h: 0.5, shape: 'tri', sweep: 0.3 }, { side: 1, a: 0.7, b: 0.94, h: 0.14, shape: 'finlets' }, { side: -1, a: 0.58, b: 0.7, h: 0.5, shape: 'tri', sweep: 0.3 }, { side: -1, a: 0.72, b: 0.94, h: 0.14, shape: 'finlets' }] },
  },
  {
    id: 'gt', name: 'Giant Trevally', tier: 3, zone: 1, minKg: 18, maxKg: 65, value: 480, w: 0.8, jump: 0.55,
    desc: 'Si GT! Petarung karang legendaris Mancing Mania.',
    look: { len: 96, depth: 0.44, peak: 0.3, nose: 0.5, taper: 1.2, ped: 0.07, up: 0.58, back: '#5e6c7a', side: '#c8d1d7', belly: '#f5f7f8', fin: '#3b4550', accent: '#e8d070', pattern: 'none', tail: 'fork', tailLen: 0.22, tailSpread: 0.85, eye: 1.1,
      fins: [{ side: 1, a: 0.3, b: 0.42, h: 0.2, shape: 'tri' }, { side: 1, a: 0.44, b: 0.92, h: 0.36, shape: 'sickle' }, { side: -1, a: 0.5, b: 0.92, h: 0.3, shape: 'sickle' }, { side: -1, a: 0.36, b: 0.46, h: 0.14, shape: 'tri' }] },
  },
  {
    id: 'lemadang', name: 'Lemadang', tier: 3, zone: 2, minKg: 12, maxKg: 40, value: 560, w: 1.1, jump: 1,
    desc: 'Mahi-mahi emas kehijauan. Akrobat laut lepas!',
    look: { len: 108, depth: 0.3, peak: 0.14, nose: 0.35, taper: 0.75, ped: 0.1, up: 0.55, back: '#1f9a72', side: '#ecd53a', belly: '#f8f2a0', fin: '#2565c8', accent: '#2a86d8', pattern: 'dots', tail: 'fork', tailLen: 0.18, tailSpread: 0.95, tailCol: '#e8c82e',
      fins: [{ side: 1, a: 0.07, b: 0.93, h: 0.34, shape: 'long' }, { side: -1, a: 0.5, b: 0.92, h: 0.14, shape: 'long', col: '#e8c82e' }] },
  },
  {
    id: 'tuna', name: 'Tuna Sirip Kuning', tier: 4, zone: 2, minKg: 45, maxKg: 160, value: 1500, w: 1, jump: 0.5,
    desc: 'Otot murni! Tarikannya ke dasar tanpa ampun.',
    look: { len: 120, depth: 0.32, peak: 0.38, nose: 0.9, taper: 1.3, ped: 0.06, up: 0.5, back: '#1c2f60', side: '#a1b3ca', belly: '#eef2f5', fin: '#f2c81e', accent: '#f2c81e', pattern: 'none', band: '#f0d040', tail: 'lunate', tailLen: 0.16, tailSpread: 1.0, tailCol: '#3a4a78',
      fins: [{ side: 1, a: 0.3, b: 0.5, h: 0.34, shape: 'sickle', col: '#3a4a78' }, { side: 1, a: 0.56, b: 0.66, h: 0.6, shape: 'tri', sweep: 0.7 }, { side: 1, a: 0.7, b: 0.94, h: 0.08, shape: 'finlets' }, { side: -1, a: 0.58, b: 0.68, h: 0.6, shape: 'tri', sweep: 0.7 }, { side: -1, a: 0.72, b: 0.94, h: 0.08, shape: 'finlets' }] },
  },
  {
    id: 'layaran', name: 'Ikan Layaran', tier: 4, zone: 2, minKg: 40, maxKg: 110, value: 1900, w: 0.8, jump: 1,
    desc: 'Ikan tercepat di samudra dengan layar megah.',
    look: { len: 136, depth: 0.17, peak: 0.3, nose: 1.0, taper: 0.9, ped: 0.1, up: 0.5, back: '#24407e', side: '#90a8cc', belly: '#eef2f6', fin: '#2c4cae', accent: '#b9cbee', pattern: 'tiger', tail: 'lunate', tailLen: 0.15, tailSpread: 1.35, bill: 0.2,
      fins: [{ side: 1, a: 0.1, b: 0.72, h: 1.5, shape: 'sail' }, { side: 1, a: 0.78, b: 0.86, h: 0.3, shape: 'tri' }, { side: -1, a: 0.66, b: 0.78, h: 0.5, shape: 'tri' }] },
  },
  {
    id: 'kertang', name: 'Kerapu Kertang', tier: 5, zone: 3, minKg: 150, maxKg: 380, value: 5200, w: 1, jump: 0.3,
    desc: 'Raksasa palung seberat motor. Pelan tapi brutal.',
    look: { len: 130, depth: 0.4, peak: 0.38, nose: 0.55, taper: 0.9, ped: 0.26, up: 0.54, back: '#4c4b33', side: '#807949', belly: '#cfc18c', fin: '#5a5638', accent: '#c9b85a', pattern: 'spots', tail: 'round', tailLen: 0.16, tailSpread: 0.6,
      fins: [{ side: 1, a: 0.24, b: 0.86, h: 0.22, shape: 'spiny' }, { side: -1, a: 0.6, b: 0.84, h: 0.22, shape: 'round' }, { side: -1, a: 0.3, b: 0.42, h: 0.2, shape: 'tri' }] },
  },
  {
    id: 'hiu', name: 'Hiu Macan', tier: 5, zone: 3, minKg: 220, maxKg: 600, value: 6500, w: 0.9, jump: 0.5,
    desc: 'Penguasa malam berloreng. Jangan sampai senar putus!',
    look: { len: 150, depth: 0.22, peak: 0.32, nose: 0.7, taper: 1.0, ped: 0.1, up: 0.5, back: '#5b6b73', side: '#8f9ca0', belly: '#eef0ec', fin: '#4a5860', accent: '#39444a', pattern: 'tiger', tail: 'shark', tailLen: 0.24, tailSpread: 1.5, gills: true,
      fins: [{ side: 1, a: 0.34, b: 0.5, h: 0.85, shape: 'tri', sweep: 0.5 }, { side: 1, a: 0.76, b: 0.83, h: 0.22, shape: 'tri', sweep: 0.4 }, { side: -1, a: 0.6, b: 0.68, h: 0.3, shape: 'tri', sweep: 0.4 }, { side: -1, a: 0.78, b: 0.84, h: 0.2, shape: 'tri' }] },
  },
  {
    id: 'marlin', name: 'Marlin Biru', tier: 5, zone: 3, minKg: 180, maxKg: 520, value: 8000, w: 0.8, jump: 1,
    desc: 'Raja game fishing. Lompatannya bikin merinding!',
    look: { len: 150, depth: 0.22, peak: 0.3, nose: 0.95, taper: 1.0, ped: 0.08, up: 0.52, back: '#17347e', side: '#84a3d4', belly: '#f0f4f8', fin: '#1a3a8a', accent: '#5f88d2', pattern: 'tiger', tail: 'lunate', tailLen: 0.16, tailSpread: 1.2, bill: 0.2,
      fins: [{ side: 1, a: 0.14, b: 0.74, h: 0.75, shape: 'marlin' }, { side: 1, a: 0.8, b: 0.87, h: 0.22, shape: 'tri' }, { side: -1, a: 0.62, b: 0.76, h: 0.4, shape: 'tri', sweep: 0.4 }, { side: -1, a: 0.8, b: 0.87, h: 0.2, shape: 'tri' }] },
  },
  {
    id: 'emas', name: 'Marlin Emas 100 Tahun', tier: 6, zone: 3, minKg: 777, maxKg: 1000, value: 100000, w: 0.4, jump: 1,
    desc: 'Legenda seabad Mancing Mania. Hanya muncul untuk sang juara.',
    look: { len: 165, depth: 0.23, peak: 0.3, nose: 0.95, taper: 1.0, ped: 0.08, up: 0.52, back: '#b86c0a', side: '#f8c624', belly: '#fff4b4', fin: '#e28c14', accent: '#fff0a0', pattern: 'tiger', tail: 'lunate', tailLen: 0.16, tailSpread: 1.2, bill: 0.2, shine: true,
      fins: [{ side: 1, a: 0.14, b: 0.74, h: 0.8, shape: 'marlin' }, { side: 1, a: 0.8, b: 0.87, h: 0.22, shape: 'tri' }, { side: -1, a: 0.62, b: 0.76, h: 0.4, shape: 'tri', sweep: 0.4 }, { side: -1, a: 0.8, b: 0.87, h: 0.2, shape: 'tri' }] },
  },
];

export const DOLPHIN: FishLook = {
  len: 44, depth: 0.25, peak: 0.34, nose: 0.75, taper: 1.0, ped: 0.1, up: 0.5, back: '#4a5f7a', side: '#7f95ac', belly: '#dfe8ee', fin: '#42566e', accent: '#42566e', pattern: 'none', tail: 'lunate', tailLen: 0.16, tailSpread: 1.0, bill: 0.07,
  fins: [{ side: 1, a: 0.42, b: 0.56, h: 0.6, shape: 'tri', sweep: 0.5 }],
};

export const FISH_STR = [0, 1.0, 1.9, 3.6, 6.5, 11, 17];
export const TIER_NAME = ['', 'Kecil', 'Sedang', 'Besar', 'Jumbo', 'Raksasa', 'LEGENDA'];

export interface Lure {
  id: string;
  name: string;
  price: number;
  aff: Record<number, number>;
  desc: string;
  col: string;
}
export const LURES: Lure[] = [
  { id: 'cacing', name: 'Cacing', price: 0, aff: { 1: 1, 2: 0.12 }, desc: 'Umpan sejuta umat. Gratis & tak pernah habis.', col: '#e77a8a' },
  { id: 'spinner', name: 'Spinner Perak', price: 80, aff: { 1: 0.7, 2: 0.8 }, desc: 'Bilah berkilau yang berputar memancing ikan sedang.', col: '#e3e9ef' },
  { id: 'minnow', name: 'Minnow Biru', price: 450, aff: { 2: 1, 3: 0.4 }, desc: 'Ikan tiruan mungil. Predator karang pasti nyambar.', col: '#2f7fe0' },
  { id: 'popper', name: 'Popper Merah', price: 1800, aff: { 2: 0.3, 3: 1, 4: 0.15 }, desc: 'Cipratan di permukaan bikin GT & lemadang ngamuk.', col: '#e23b2e' },
  { id: 'jig', name: 'Jig Besi', price: 5500, aff: { 3: 0.6, 4: 1 }, desc: 'Meluncur dalam untuk tuna dan layaran.', col: '#f07aa8' },
  { id: 'cumi', name: 'Cumi Neon', price: 15000, aff: { 4: 0.8, 5: 0.7 }, desc: 'Rumbai menyala untuk monster laut dalam.', col: '#5cf06a' },
  { id: 'swim', name: 'Swimbait Raksasa', price: 40000, aff: { 4: 0.3, 5: 1, 6: 0.04 }, desc: 'Ikan tiruan super besar. Khusus para raksasa.', col: '#f09030' },
  { id: 'emas', name: 'Lure Emas 100 Th', price: 150000, aff: { 5: 0.7, 6: 0.6 }, desc: 'Edisi peringatan seabad. Memanggil sang legenda.', col: '#f8c624' },
];

/** live bait: a caught fish attracts the next size class */
export function baitAff(tier: number): Record<number, number> {
  const a: Record<number, number> = {};
  if (tier >= 5) { a[6] = 0.6; a[5] = 0.5; return a; }
  a[tier + 1] = 1.3;
  a[tier + 2] = 0.3;
  return a;
}

export interface Zone {
  name: string;
  sub: string;
  x0: number;
  x1: number;
  maxDepth: number;
  boat: number;
}
export const ZONES: Zone[] = [
  { name: 'Teluk Nyiur', sub: 'Pagi yang tenang', x0: 0, x1: 1150, maxDepth: 20, boat: 1 },
  { name: 'Karang Biru', sub: 'Surga terumbu', x0: 1150, x1: 2350, maxDepth: 40, boat: 2 },
  { name: 'Laut Lepas', sub: 'Senja di samudra', x0: 2350, x1: 3600, maxDepth: 80, boat: 3 },
  { name: 'Palung Naga', sub: 'Malam para raksasa', x0: 3600, x1: 4900, maxDepth: 150, boat: 4 },
];

export const ROD = [
  { name: 'Joran Bambu', price: 0, pow: 1.2, col: '#d8b45a' },
  { name: 'Joran Fiber', price: 250, pow: 2.2, col: '#4fae5a' },
  { name: 'Joran Karbon', price: 1500, pow: 4, col: '#3f8fe8' },
  { name: 'Joran Pro Tuna', price: 7000, pow: 7, col: '#e8483a' },
  { name: 'Joran Monster', price: 25000, pow: 12, col: '#8a5ad8' },
  { name: 'Joran Emas 100', price: 60000, pow: 18, col: '#f8c624' },
];
export const LINE = [
  { name: 'Senar Nilon 10lb', price: 0, pow: 1.2 },
  { name: 'Senar Nilon 20lb', price: 200, pow: 2.2 },
  { name: 'Senar PE 40lb', price: 1200, pow: 4 },
  { name: 'Senar PE 80lb', price: 6000, pow: 7 },
  { name: 'Senar Baja 130lb', price: 22000, pow: 12 },
  { name: 'Senar Titanium', price: 50000, pow: 18 },
];
export const REEL = [
  { name: 'Reel Kayu', price: 0, gain: 0.17, cap: 50 },
  { name: 'Reel Spinning', price: 300, gain: 0.2, cap: 58 },
  { name: 'Reel Baitcast', price: 1800, gain: 0.23, cap: 66 },
  { name: 'Reel Jigging', price: 8000, gain: 0.27, cap: 75 },
  { name: 'Reel Game Besar', price: 28000, gain: 0.31, cap: 85 },
  { name: 'Reel Emas 100', price: 60000, gain: 0.36, cap: 95 },
];
export const BOAT = [
  { name: 'Sampan Kayu', price: 0, speed: 58 },
  { name: 'Perahu Motor', price: 600, speed: 88 },
  { name: 'Speedboat', price: 6000, speed: 128 },
  { name: 'Kapal Pancing', price: 30000, speed: 175 },
];

export interface ThemeRaw {
  sky: string[];
  sun: string; glow: string; sunX: number; sunY: number; sunR: number;
  cl: string; cm: string; cs: string;
  isl: string; lit: string; far: string; sand: string; rock: string;
  seaA: string; seaB: string; seaC: string; hi: string; glint: string;
  l: number[];
  stars: number;
}
export const THEMES: ThemeRaw[] = [
  { // pagi — Teluk Nyiur
    sky: ['#2f97e6', '#58b8f2', '#93d8f8', '#cdeff6', '#fdf2cf'],
    sun: '#fffbe0', glow: '#fff3b0', sunX: 96, sunY: 34, sunR: 9,
    cl: '#ffffff', cm: '#e2f2fc', cs: '#a8d0ee',
    isl: '#2f8f58', lit: '#6fcf6a', far: '#86bfd0', sand: '#f6e6a8', rock: '#8f948a',
    seaA: '#86dbe8', seaB: '#2ba3d8', seaC: '#1763ad', hi: '#d4f8fc', glint: '#ffffff',
    l: [1, 1, 1], stars: 0,
  },
  { // siang — Karang Biru
    sky: ['#176fe0', '#3391f2', '#6ab9f8', '#a8defa', '#e0f6fb'],
    sun: '#ffffff', glow: '#fffbd8', sunX: 250, sunY: 22, sunR: 8,
    cl: '#ffffff', cm: '#e6f6ff', cs: '#9fd0f2',
    isl: '#249262', lit: '#66d87a', far: '#7cc0d8', sand: '#fbf0c0', rock: '#9aa096',
    seaA: '#9aeee2', seaB: '#22c0c6', seaC: '#0c82aa', hi: '#e2fff6', glint: '#ffffff',
    l: [1.04, 1.04, 1], stars: 0,
  },
  { // senja — Laut Lepas
    sky: ['#3a2b70', '#8c3f80', '#e2606a', '#f89a48', '#ffdc70'],
    sun: '#fff2b0', glow: '#ffb050', sunX: 262, sunY: 90, sunR: 17,
    cl: '#ffcc8c', cm: '#ea787a', cs: '#7c3f7c',
    isl: '#4a2a5c', lit: '#b8506e', far: '#8a4674', sand: '#e89a6a', rock: '#6a3a5a',
    seaA: '#f8a858', seaB: '#b44c70', seaC: '#38265e', hi: '#ffe490', glint: '#fff6c8',
    l: [1.1, 0.86, 0.78], stars: 0,
  },
  { // malam — Palung Naga
    sky: ['#060a22', '#0c143c', '#182660', '#284284', '#3c66a4'],
    sun: '#fff2b0', glow: '#5a3a80', sunX: 262, sunY: 132, sunR: 14,
    cl: '#5c78b4', cm: '#364c84', cs: '#1c2852',
    isl: '#101a3c', lit: '#2c4a84', far: '#1e3468', sand: '#2c4a84', rock: '#1a2850',
    seaA: '#2e5e9a', seaB: '#152e68', seaC: '#080f32', hi: '#90d2ff', glint: '#ecf8ff',
    l: [0.6, 0.7, 0.98], stars: 1,
  },
];

export interface Save {
  coins: number;
  rod: number;
  line: number;
  reel: number;
  boat: number;
  lures: string[];
  bait: Record<string, number>;
  rec: Record<string, { n: number; best: number }>;
  total: number;
  legend: boolean;
  last: string;
}
export function newSave(): Save {
  return { coins: 60, rod: 1, line: 1, reel: 1, boat: 1, lures: ['cacing'], bait: {}, rec: {}, total: 0, legend: false, last: 'l:cacing' };
}
