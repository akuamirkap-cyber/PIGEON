// Hand-built & procedural pixel sprites for the scene (boats, fisherman, clouds, lures…)
import { Surface, hex, bayer, outlined, fromStrings } from './gfx';

const P = (o: Record<string, string>) => {
  const r: Record<string, number> = {};
  for (const k in o) r[k] = hex(o[k]);
  return r;
};
export const OUT = hex('#161228');

// ------------------------------------------------------------------ fisherman (faces right)
// The body is a procedural rig (see game.ts); only the head is a sprite, one per expression.
// Eyes are always two dots; brows / mouth / tears / blush carry the emotion.
const HEAD = [
  '...hhhhhh...',
  '..hhhhhhhh..',
  '.hhhhhhwhhhH',
  '.rsssssssHHH',
  '.rsssssssss.',
  '.rsssssssss.',
  '.rSssssssss.',
  '..sssssssss.',
  '...sssssss..',
];
const FD = '#1a1426', FW = '#ffffff', FR = '#c0392b', FP = '#f58a8a', FB = '#7fd0ff';
const FACES: Record<string, [number, number, string][]> = {
  neutral: [[5, 5, FD], [5, 6, FD], [8, 5, FD], [8, 6, FD], [6, 7, FD], [7, 7, FD]],
  blink: [[5, 6, FD], [8, 6, FD], [6, 7, FD], [7, 7, FD]],
  focus: [[5, 5, FD], [5, 6, FD], [8, 5, FD], [8, 6, FD], [4, 4, FD], [5, 4, FD], [8, 4, FD], [9, 4, FD], [6, 7, FD], [7, 7, FD], [8, 7, FD]],
  strain: [[4, 4, FD], [5, 5, FD], [4, 6, FD], [9, 4, FD], [8, 5, FD], [9, 6, FD], [5, 7, FW], [6, 7, FW], [7, 7, FW], [8, 7, FW], [6, 8, FD], [7, 8, FD]],
  excited: [[4, 5, FW], [5, 5, FD], [4, 6, FD], [5, 6, FD], [8, 5, FW], [9, 5, FD], [8, 6, FD], [9, 6, FD], [6, 7, FD], [7, 7, FD], [6, 8, FR], [7, 8, FR]],
  alert: [[5, 5, FD], [5, 6, FD], [8, 5, FD], [8, 6, FD], [7, 7, FD], [7, 8, FD]],
  happy: [[5, 5, FD], [5, 6, FD], [8, 5, FD], [8, 6, FD], [5, 7, FD], [8, 7, FD], [6, 8, FD], [7, 8, FD], [3, 7, FP], [10, 7, FP]],
  happy2: [[4, 6, FD], [5, 5, FD], [6, 6, FD], [7, 6, FD], [8, 5, FD], [9, 6, FD], [5, 7, FD], [6, 7, FD], [7, 7, FD], [8, 7, FD], [6, 8, FR], [7, 8, FR], [3, 7, FP], [10, 7, FP]],
  sad: [[5, 6, FD], [8, 6, FD], [4, 5, FD], [9, 5, FD], [6, 7, FD], [7, 7, FD], [5, 8, FD], [8, 8, FD], [4, 7, FB]],
  sad2: [[5, 6, FD], [8, 6, FD], [4, 5, FD], [9, 5, FD], [6, 7, FD], [7, 7, FD], [5, 8, FD], [8, 8, FD], [4, 8, FB], [9, 7, FB]],
};
export function makeHeads(): Record<string, Surface> {
  const pal = P({ h: '#e23b2e', H: '#b02a22', w: '#ffffff', r: '#2a1c14', s: '#f0b488', S: '#c98a5e' });
  const out: Record<string, Surface> = {};
  for (const k in FACES) {
    const hd = fromStrings(HEAD, pal);
    for (const [x, y, c] of FACES[k]) hd.px(x, y, hex(c));
    out[k] = outlined(hd, OUT);
  }
  return out;
}

export const EXCL = outlined(
  fromStrings(['.yyy.', 'yyyyy', 'yyyyy', 'yyyyy', '.yyy.', '.yyy.', '.ooo.', '.....', '.ooo.', 'ooooo', '.ooo.'], P({ y: '#ffe14a', o: '#ff9a2e' })),
  OUT
);
export const ARROW = outlined(fromStrings(['yyyyyyy', 'yyyyyyy', '.ooooo.', '..ooo..', '...o...'], P({ y: '#ffe14a', o: '#ffb52e' })), OUT);
export const COIN = fromStrings(
  ['..oooo..', '.oyyyyo.', 'oyywyyyd', 'oywyyyyd', 'oywyyyyd', 'oyyyyyyd', '.oyyyyd.', '..dddd..'],
  P({ o: '#7a4a10', y: '#ffd23e', w: '#fff6c0', d: '#b8741a' })
);

// ------------------------------------------------------------------ boats
export interface BoatSpr {
  s: Surface;
  wl: number; // waterline row inside sprite
  deck: number; // row where feet stand (stern)
  deckF: number; // row where feet stand (bow, fishing)
  manSail: number;
  manFish: number;
  stern: number;
  bow: number;
  flagX: number;
  flagY: number;
}
interface HullO {
  bow: number; stern: number; rake: number; sternRake: number;
  gun: number; a: number; b: number; stripe: number; stripeAt: number; bottom: number; plank: number;
}
function hull(s: Surface, x0: number, L: number, yTop: number, dep: number, o: HullO) {
  for (let i = 0; i < L; i++) {
    const u = i / (L - 1);
    const rise = Math.round(o.bow * Math.pow(Math.max(0, (u - 0.5) / 0.5), 2.2) + o.stern * Math.pow(Math.max(0, (0.25 - u) / 0.25), 2));
    const top = yTop - rise;
    let bot = yTop + dep;
    if (u > 1 - o.rake) bot -= Math.round((dep + rise) * Math.pow((u - (1 - o.rake)) / o.rake, 1.5));
    if (u < o.sternRake) bot -= Math.round((dep + rise * 0.5) * Math.pow((o.sternRake - u) / o.sternRake, 1.8));
    for (let y = top; y <= bot; y++) {
      const rel = y - top;
      let c: number;
      if (rel === 0) c = o.gun;
      else if (y >= yTop + dep - 1) c = o.bottom;
      else if (y - yTop === o.stripeAt || y - yTop === o.stripeAt + 1) c = o.stripe;
      else c = y - yTop < dep * 0.5 ? o.a : o.b;
      if (o.plank && rel > 0 && (y - yTop + 30) % 3 === 1 && c !== o.stripe && c !== o.bottom) c = o.plank;
      s.px(x0 + i, y, c);
    }
  }
}

export function makeBoat(tier: number): BoatSpr {
  const pole = hex('#6a4a30');
  if (tier === 1) {
    const L = 54, yTop = 10, dep = 6, x0 = 4;
    const s = new Surface(L + 8, yTop + dep + 5);
    hull(s, x0, L, yTop, dep, { bow: 4, stern: 3, rake: 0.3, sternRake: 0.22, gun: hex('#f0c684'), a: hex('#c4864a'), b: hex('#a46a36'), stripe: hex('#3fa7d8'), stripeAt: 2, bottom: hex('#70401f'), plank: 0 });
    const bam = hex('#f0dc98'), bamD = hex('#b89a50');
    s.line(19, yTop, 17, yTop + dep + 3, bamD);
    s.line(41, yTop, 39, yTop + dep + 3, bamD);
    s.rect(9, yTop + dep + 3, 41, 1, bam);
    s.rect(9, yTop + dep + 4, 41, 1, bamD);
    s.rect(9, yTop - 9, 1, 9, pole);
    return { s: outlined(s, OUT), wl: yTop + dep + 1, deck: yTop + 2, deckF: yTop + 2, manSail: x0 + 18, manFish: x0 + 33, stern: x0 + 1, bow: x0 + L + 1, flagX: 11, flagY: yTop - 8 };
  }
  if (tier === 2) {
    const L = 66, yTop = 31, dep = 7, x0 = 5;
    const s = new Surface(L + 10, yTop + dep + 2);
    hull(s, x0, L, yTop, dep, { bow: 4, stern: 0, rake: 0.26, sternRake: 0.06, gun: hex('#f2c14e'), a: hex('#f6f3e8'), b: hex('#e6e2d2'), stripe: hex('#2f7fd8'), stripeAt: 3, bottom: hex('#d8453a'), plank: 0 });
    // canopy
    s.rect(13, yTop - 26, 1, 26, hex('#8a5a30'));
    s.rect(38, yTop - 26, 1, 26, hex('#8a5a30'));
    s.rect(10, yTop - 28, 32, 2, hex('#2a6fc0'));
    s.rect(10, yTop - 29, 32, 1, hex('#f6f3e8'));
    for (let x = 10; x < 42; x += 3) s.px(x, yTop - 26, hex('#f6f3e8'));
    // motor
    s.rect(1, yTop - 3, 4, 6, hex('#30343c'));
    s.rect(1, yTop - 3, 4, 1, hex('#e8483a'));
    s.rect(2, yTop + 3, 1, 4, hex('#1b1e24'));
    // crate
    s.rect(47, yTop - 3, 5, 3, hex('#b9793f'));
    s.rect(47, yTop - 3, 5, 1, hex('#e0a868'));
    s.rect(8, yTop - 12, 1, 12, pole);
    return { s: outlined(s, OUT), wl: yTop + dep + 1, deck: yTop + 2, deckF: yTop + 2, manSail: x0 + 20, manFish: x0 + 52, stern: x0 - 2, bow: x0 + L + 1, flagX: 10, flagY: yTop - 11 };
  }
  if (tier === 3) {
    const L = 80, yTop = 13, dep = 7, x0 = 6;
    const s = new Surface(L + 10, yTop + dep + 2);
    hull(s, x0, L, yTop, dep, { bow: 3, stern: 0, rake: 0.3, sternRake: 0.05, gun: hex('#dfe6ea'), a: hex('#fcfcf8'), b: hex('#e8eeee'), stripe: hex('#12b5a6'), stripeAt: 2, bottom: hex('#1f3a5c'), plank: 0 });
    for (let i = 0; i < 8; i++) {
      const h = 8 - i, x = x0 + 42 + i;
      s.rect(x, yTop - h, 1, h, hex('#9fe6f4'));
      s.px(x, yTop - h, hex('#44586a'));
    }
    s.rect(x0 + 42, yTop - 8, 1, 8, hex('#44586a'));
    s.rect(x0 + 35, yTop - 4, 6, 4, hex('#cfd8dc'));
    s.px(x0 + 37, yTop - 5, hex('#30343c'));
    s.rect(x0 + 24, yTop - 3, 7, 3, hex('#e8573f'));
    s.rect(x0 + 24, yTop - 6, 2, 3, hex('#c8402a'));
    s.rect(0, yTop - 4, 5, 8, hex('#22262e'));
    s.rect(0, yTop - 4, 5, 1, hex('#e8483a'));
    s.rect(1, yTop - 1, 3, 1, hex('#dfe6ea'));
    s.rect(2, yTop + 4, 1, 4, hex('#14161c'));
    s.line(x0 + 56, yTop - 3, x0 + 77, yTop - 6, hex('#aab8c0'));
    for (const rx of [58, 66, 74]) s.rect(x0 + rx, yTop - 3, 1, 3, hex('#aab8c0'));
    s.rect(10, yTop - 12, 1, 12, pole);
    return { s: outlined(s, OUT), wl: yTop + dep + 1, deck: yTop + 2, deckF: yTop + 2, manSail: x0 + 32, manFish: x0 + 60, stern: x0 - 3, bow: x0 + L + 1, flagX: 12, flagY: yTop - 11 };
  }
  const L = 104, yTop = 31, dep = 9, x0 = 5;
  const s = new Surface(L + 10, yTop + dep + 2);
  hull(s, x0, L, yTop, dep, { bow: 5, stern: 0, rake: 0.28, sternRake: 0.04, gun: hex('#e8eef0'), a: hex('#ffffff'), b: hex('#eef2f2'), stripe: hex('#1c3f8a'), stripeAt: 3, bottom: hex('#12264a'), plank: 0 });
  for (let x = x0; x < x0 + L; x++) if (s.get(x, yTop + 6)) s.px(x, yTop + 6, hex('#f2c14e'));
  // cabin
  s.rect(33, yTop - 13, 38, 13, hex('#f6f8f8'));
  for (let j = 0; j < 13; j++) s.rect(71, yTop - 13 + j, Math.round(j * 0.55), 1, hex('#f6f8f8'));
  s.rect(33, yTop - 3, 44, 3, hex('#dfe6ea'));
  for (const wx of [36, 47, 58]) {
    s.rect(wx, yTop - 10, 9, 5, hex('#1c3f6a'));
    s.px(wx + 1, yTop - 9, hex('#6fb8e8'));
    s.px(wx + 2, yTop - 10, hex('#6fb8e8'));
  }
  s.rect(31, yTop - 14, 42, 1, hex('#1c3f8a'));
  // flybridge
  s.rect(37, yTop - 21, 24, 7, hex('#f6f8f8'));
  s.rect(52, yTop - 21, 9, 4, hex('#6fb8e8'));
  s.rect(36, yTop - 23, 1, 2, hex('#8a96a0'));
  s.rect(61, yTop - 23, 1, 2, hex('#8a96a0'));
  s.rect(34, yTop - 25, 30, 2, hex('#1c3f8a'));
  s.rect(46, yTop - 30, 1, 5, hex('#8a96a0'));
  s.rect(50, yTop - 27, 5, 2, hex('#dfe6ea'));
  s.line(38, yTop - 20, 15, yTop - 28, hex('#8a96a0'));
  // cockpit
  s.rect(6, yTop - 4, 1, 4, hex('#aab8c0'));
  s.rect(6, yTop - 4, 26, 1, hex('#aab8c0'));
  s.rect(17, yTop - 5, 5, 5, hex('#b9793f'));
  s.rect(17, yTop - 8, 2, 3, hex('#8a5a30'));
  s.line(x0 + 73, yTop - 4, x0 + 101, yTop - 9, hex('#aab8c0'));
  for (const rx of [76, 84, 92, 99]) s.rect(x0 + rx, yTop - 5, 1, 4, hex('#aab8c0'));
  s.rect(9, yTop - 15, 1, 15, pole);
  return { s: outlined(s, OUT), wl: yTop + dep + 1, deck: yTop + 2, deckF: yTop, manSail: x0 + 21, manFish: x0 + 86, stern: x0, bow: x0 + L + 1, flagX: 11, flagY: yTop - 14 };
}

// ------------------------------------------------------------------ clouds (indexed 1 light / 2 mid / 3 shadow)
export function makeCloud(r: () => number, w: number, h: number): Surface {
  const s = new Surface(w, h);
  const base = h - 1;
  const blobs: number[][] = [];
  const n = 4 + ((w / 9) | 0);
  for (let i = 0; i < n; i++) {
    const cx = 5 + r() * (w - 10);
    const edge = 1 - Math.abs(cx / w - 0.5) * 1.5;
    const rad = Math.max(2.5, (0.3 + 0.6 * r()) * h * 0.62 * Math.max(0.35, edge));
    blobs.push([cx, base - rad * (0.55 + r() * 0.5), rad]);
  }
  for (const [cx, cy, rad] of blobs)
    for (let y = Math.floor(cy - rad); y <= Math.min(base, Math.ceil(cy + rad)); y++)
      for (let x = Math.floor(cx - rad); x <= Math.ceil(cx + rad); x++) if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= rad * rad) s.px(x, y, 2);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      if (!s.get(x, y)) continue;
      const v = (y - (base - h * 0.36)) / (h * 0.36);
      if (v > bayer(x, y) * 0.9 + 0.05) s.px(x, y, 3);
    }
  for (const [cx, cy, rad] of blobs)
    for (let a = 3.5; a < 5.9; a += 0.4 / rad)
      for (const rr of [rad, rad - 1]) {
        const x = Math.round(cx + Math.cos(a) * rr), y = Math.round(cy + Math.sin(a) * rr);
        if (s.get(x, y) === 2) s.px(x, y, 1);
      }
  for (let x = 0; x < w; x++)
    for (let y = 0; y < h; y++)
      if (s.get(x, y)) {
        s.px(x, y, 1);
        break;
      }
  return s;
}

export const PALM = fromStrings(
  [
    '....22...22..',
    '..2223222322.',
    '.223322233322',
    '223..2232..22',
    '2...22122...2',
    '....2.1.2....',
    '......1......',
    '......1......',
    '.....1.......',
    '.....1.......',
    '.....1.......',
    '....11.......',
    '....1........',
    '....1........',
  ],
  { '1': 1, '2': 2, '3': 3 }
);

export const PINISI = fromStrings(
  [
    '..........1...............',
    '.........11......1........',
    '........111.....11........',
    '.......1111....111........',
    '......11111...1111........',
    '.....111111..11111...1....',
    '....1111111.111111..11....',
    '...11111111.111111.111....',
    '..111111111.111111.111....',
    '....1.....1.....1....1....',
    '1111111111111111111111111.',
    '.11111111111111111111111..',
    '..11111111111111111111....',
  ],
  { '1': 1 }
);

// ------------------------------------------------------------------ lure icons (UI)
function hook(s: Surface, x: number, y: number) {
  const m = hex('#d4dce4'), d = hex('#6a7480');
  s.px(x, y, m); s.px(x, y + 1, m); s.px(x, y + 2, m); s.px(x, y + 3, d);
  s.px(x + 1, y + 4, d); s.px(x + 2, y + 4, m); s.px(x + 3, y + 3, m); s.px(x + 3, y + 2, d);
}
function fishBody(s: Surface, cx: number, cy: number, rx: number, ry: number, top: string, bot: string, tail: string) {
  for (let x = -rx; x <= rx; x++) {
    const hh = Math.round(ry * Math.sqrt(Math.max(0, 1 - (x * x) / (rx * rx + rx))));
    for (let y = -hh; y <= hh; y++) s.px(cx + x, cy + y, hex(y <= 0 ? top : bot));
  }
  for (let i = 0; i < 3; i++) s.rect(cx + rx + i, cy - 1 - i, 1, 3 + i * 2, hex(tail));
  s.px(cx - rx + 2, cy - 1, hex('#ffffff'));
  s.px(cx - rx + 2, cy, hex('#10101c'));
}
export function makeLureIcon(id: string): Surface {
  const s = new Surface(20, 14);
  switch (id) {
    case 'cacing': {
      hook(s, 13, 1);
      for (let i = 0; i < 12; i++) {
        const y = 9 + Math.round(Math.sin(i * 0.9) * 1.6);
        s.px(4 + i, y, hex(i % 3 === 2 ? '#b84f63' : '#f08a9a'));
        s.px(4 + i, y + 1, hex(i % 3 === 2 ? '#a04456' : '#d86a7c'));
      }
      s.px(15, 6, hex('#f08a9a')); s.px(15, 7, hex('#f08a9a'));
      break;
    }
    case 'spinner': {
      s.rect(2, 7, 14, 1, hex('#9aa6b4'));
      s.ell(7, 4, 4, 2, hex('#e3e9ef'));
      s.px(5, 3, 0xffffffff); s.px(6, 3, 0xffffffff); s.rect(7, 5, 3, 1, hex('#9aa6b4'));
      s.rect(11, 6, 2, 3, hex('#e03a3a'));
      s.rect(13, 6, 3, 3, hex('#e8b840')); s.px(13, 6, hex('#fff0a0'));
      hook(s, 16, 7); s.px(17, 9, hex('#d4dce4'));
      break;
    }
    case 'minnow': {
      fishBody(s, 9, 6, 6, 2, '#2f7fe0', '#f0f4f8', '#2a5fb0');
      s.rect(5, 6, 8, 1, hex('#8fd0ff'));
      s.px(2, 8, hex('#bfe6f0')); s.px(1, 9, hex('#bfe6f0'));
      hook(s, 8, 8); hook(s, 14, 8);
      break;
    }
    case 'popper': {
      for (let x = 3; x <= 15; x++) {
        const hh = Math.round(4 - ((x - 3) / 12) * 2.6);
        for (let y = -hh; y <= hh; y++) s.px(x, 6 + y, hex(y <= 0 ? '#e23b2e' : '#fbfbf6'));
      }
      s.rect(3, 2, 1, 9, hex('#ffd23e')); s.rect(2, 3, 1, 7, hex('#ffb52e'));
      s.rect(5, 4, 2, 2, 0xffffffff); s.px(6, 5, hex('#10101c'));
      s.rect(8, 3, 5, 1, hex('#ff8a70'));
      hook(s, 15, 6);
      break;
    }
    case 'jig': {
      for (let x = 2; x <= 16; x++) {
        const u = (x - 2) / 14;
        const hh = Math.round(3 * Math.sin(Math.PI * Math.pow(u, 0.7)));
        for (let y = -hh; y <= hh; y++) s.px(x, 7 + y, hex(y < 0 ? '#dfe8f2' : y === 0 ? '#8fd0ff' : '#f07aa8'));
      }
      s.px(5, 5, 0xffffffff); s.px(6, 5, 0xffffffff); s.px(9, 6, 0xffffffff);
      s.px(13, 7, hex('#10101c'));
      hook(s, 16, 7);
      break;
    }
    case 'cumi': {
      s.ell(6, 6, 4, 3, hex('#5cf06a'));
      s.rect(3, 4, 3, 1, hex('#c8ffb0'));
      s.rect(4, 6, 2, 2, 0xffffffff); s.px(5, 7, hex('#10101c'));
      for (let k = 0; k < 5; k++)
        for (let i = 0; i < 9; i++) s.px(10 + i, 3 + k * 1.6 + Math.round(Math.sin(i * 0.9 + k) * 0.8), hex(k % 2 ? '#ff5fb0' : '#5cf06a'));
      hook(s, 15, 8);
      break;
    }
    case 'swim': {
      fishBody(s, 8, 7, 7, 3, '#7a9a3a', '#f09030', '#c86a14');
      for (const x of [9, 12]) s.rect(x, 5, 1, 5, hex('#4a6a20'));
      s.rect(3, 6, 5, 1, hex('#c8d870'));
      s.rect(17, 3, 2, 9, hex('#c86a14'));
      hook(s, 7, 0);
      break;
    }
    default: {
      fishBody(s, 9, 7, 7, 3, '#f8c624', '#fff4b4', '#e28c14');
      s.rect(4, 6, 8, 1, hex('#fff8d0'));
      s.px(4, 6, hex('#e03a3a'));
      for (const [x, y] of [[13, 2], [3, 11], [17, 10]]) {
        s.px(x, y, 0xffffffff); s.px(x - 1, y, hex('#fff0a0')); s.px(x + 1, y, hex('#fff0a0')); s.px(x, y - 1, hex('#fff0a0')); s.px(x, y + 1, hex('#fff0a0'));
      }
      hook(s, 9, 9);
    }
  }
  return outlined(s, OUT);
}
