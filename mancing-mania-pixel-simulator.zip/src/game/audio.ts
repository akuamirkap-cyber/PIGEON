// Tiny WebAudio chiptune synth: every sound in the game is generated here.
import type { AudioAPI } from './game';

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);
const CH = [[48, 52, 55], [45, 48, 52], [41, 45, 48], [43, 47, 50]];
const MA = [76, 0, 79, 0, 81, 79, 76, 0, 72, 0, 76, 0, 74, 72, 69, 0, 69, 0, 72, 0, 77, 76, 72, 0, 74, 0, 79, 0, 71, 74, 79, 0];
const MB = [84, 0, 83, 81, 79, 0, 76, 0, 81, 0, 79, 76, 72, 0, 69, 0, 77, 0, 76, 72, 69, 0, 72, 0, 74, 76, 79, 0, 74, 0, 71, 0];
const FC = [[45, 48, 52], [41, 45, 48], [43, 47, 50], [40, 43, 47]];
const FA = [0, 1, 2, 1, 0, 1, 2, 1, 2, 1, 0, 1, 2, 2, 1, 0];

export class Sfx implements AudioAPI {
  ctx: AudioContext | null = null;
  muted = false;
  private master!: GainNode;
  private sfx!: GainNode;
  private mus!: GainNode;
  private nbuf!: AudioBuffer;
  private dragG!: GainNode;
  private dragO!: OscillatorNode;
  private engG!: GainNode;
  private engO!: OscillatorNode;
  private lv: Record<string, number> = {};
  private song = 'off';
  private step = 0;
  private nextT = 0;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC: typeof AudioContext | undefined = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    let c: AudioContext;
    try { c = new AC(); } catch { return; }
    this.ctx = c;
    if (c.state === 'suspended') c.resume();
    this.master = c.createGain(); this.master.gain.value = this.muted ? 0 : 0.9; this.master.connect(c.destination);
    this.sfx = c.createGain(); this.sfx.gain.value = 0.9; this.sfx.connect(this.master);
    this.mus = c.createGain(); this.mus.gain.value = 0.55; this.mus.connect(this.master);
    this.nbuf = c.createBuffer(1, c.sampleRate, c.sampleRate);
    const d = this.nbuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    // ocean ambience
    const amb = c.createBufferSource(); amb.buffer = this.nbuf; amb.loop = true;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 520;
    const ag = c.createGain(); ag.gain.value = 0.05;
    const lfo = c.createOscillator(); lfo.frequency.value = 0.13;
    const lg = c.createGain(); lg.gain.value = 0.03;
    lfo.connect(lg); lg.connect(ag.gain); amb.connect(lp); lp.connect(ag); ag.connect(this.master);
    amb.start(); lfo.start();
    // screaming drag
    this.dragO = c.createOscillator(); this.dragO.type = 'sawtooth'; this.dragO.frequency.value = 620;
    const dm = c.createOscillator(); dm.type = 'square'; dm.frequency.value = 38;
    const dmg = c.createGain(); dmg.gain.value = 240;
    dm.connect(dmg); dmg.connect(this.dragO.frequency);
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1800; bp.Q.value = 0.8;
    this.dragG = c.createGain(); this.dragG.gain.value = 0;
    this.dragO.connect(bp); bp.connect(this.dragG); this.dragG.connect(this.sfx);
    this.dragO.start(); dm.start();
    // boat engine
    this.engO = c.createOscillator(); this.engO.type = 'square'; this.engO.frequency.value = 36;
    const elp = c.createBiquadFilter(); elp.type = 'lowpass'; elp.frequency.value = 240;
    this.engG = c.createGain(); this.engG.gain.value = 0;
    this.engO.connect(elp); elp.connect(this.engG); this.engG.connect(this.sfx);
    this.engO.start();
    window.setInterval(() => this.sched(), 60);
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05);
  }

  loop(n: string, lvl: number) {
    const c = this.ctx;
    if (!c) return;
    if (Math.abs((this.lv[n] ?? -1) - lvl) < 0.04) return;
    this.lv[n] = lvl;
    if (n === 'drag') {
      this.dragG.gain.setTargetAtTime(lvl * 0.1, c.currentTime, 0.04);
      this.dragO.frequency.setTargetAtTime(520 + lvl * 380, c.currentTime, 0.05);
    } else {
      this.engG.gain.setTargetAtTime(lvl > 0.02 ? 0.05 + lvl * 0.08 : 0, c.currentTime, 0.12);
      this.engO.frequency.setTargetAtTime(30 + lvl * 30, c.currentTime, 0.15);
    }
  }

  music(k: string) {
    if (k === this.song) return;
    this.song = k;
    this.step = 0;
    if (this.ctx) this.nextT = this.ctx.currentTime + 0.08;
  }

  private tone(f: number, dur: number, type: OscillatorType, vol: number, f2 = 0, delay = 0, at = 0, bus: GainNode | null = null) {
    const c = this.ctx;
    if (!c) return;
    const t = (at || c.currentTime) + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus || this.sfx);
    o.start(t); o.stop(t + dur + 0.03);
  }
  private noise(dur: number, vol: number, f1: number, f2 = 0, type: BiquadFilterType = 'lowpass', delay = 0, at = 0, bus: GainNode | null = null) {
    const c = this.ctx;
    if (!c) return;
    const t = (at || c.currentTime) + delay;
    const s = c.createBufferSource(); s.buffer = this.nbuf; s.loop = true;
    const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f1, t);
    if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(fl); fl.connect(g); g.connect(bus || this.sfx);
    s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.03);
  }
  private arp(notes: number[], gap: number, dur: number, type: OscillatorType, vol: number) {
    notes.forEach((n, i) => this.tone(mtof(n), dur, type, vol, 0, i * gap));
  }

  play(n: string, v = 1) {
    if (!this.ctx) return;
    switch (n) {
      case 'click': this.tone(1500 + v * 1100, 0.028, 'square', 0.05); this.noise(0.018, 0.05, 5000, 0, 'highpass'); break;
      case 'tick': this.tone(900, 0.02, 'square', 0.03); break;
      case 'ui': this.tone(660, 0.05, 'square', 0.06, 880); break;
      case 'cast': this.noise(0.4, 0.24, 500, 3800, 'bandpass'); this.tone(300, 0.3, 'triangle', 0.08, 900); break;
      case 'plop': this.tone(520, 0.18, 'sine', 0.3, 100); this.noise(0.25, 0.2, 2600, 400); break;
      case 'splash': this.noise(0.8, 0.42, 3200, 260); this.tone(170, 0.35, 'sine', 0.25, 55); break;
      case 'jig': this.tone(700, 0.07, 'triangle', 0.13, 940); break;
      case 'nibble': this.tone(280, 0.06, 'square', 0.09); this.tone(240, 0.06, 'square', 0.07, 0, 0.07); break;
      case 'bite': this.tone(880, 0.09, 'square', 0.15); this.tone(1320, 0.14, 'square', 0.15, 0, 0.09); this.tone(1760, 0.16, 'square', 0.12, 0, 0.18); break;
      case 'strike': this.noise(0.25, 0.36, 1400, 180); this.arp([72, 76, 79, 84], 0.06, 0.14, 'square', 0.13); break;
      case 'crit': this.tone(1200, 0.12, 'square', 0.15, 2400); this.noise(0.12, 0.28, 3000, 800); break;
      case 'run': this.tone(380, 0.28, 'sawtooth', 0.09, 950); break;
      case 'snap': this.tone(900, 0.28, 'sawtooth', 0.2, 70); this.noise(0.09, 0.3, 5000, 0, 'highpass'); this.arp([64, 60, 55], 0.14, 0.2, 'triangle', 0.14); break;
      case 'fail': this.arp([67, 64, 60, 55], 0.14, 0.22, 'triangle', 0.16); break;
      case 'fanfare': this.arp([72, 76, 79, 84, 79, 84, 88], 0.1, 0.22, 'square', 0.12); this.arp([48, 55, 60, 64, 60, 64, 72], 0.1, 0.3, 'triangle', 0.16); this.noise(0.5, 0.12, 6000, 2000, 'highpass', 0.6); break;
      case 'coin': this.tone(988, 0.07, 'square', 0.12); this.tone(1319, 0.2, 'square', 0.12, 0, 0.07); break;
      case 'buy': this.arp([72, 76, 79, 84], 0.05, 0.12, 'square', 0.11); break;
      case 'deny': this.tone(170, 0.16, 'square', 0.12, 110); break;
      case 'lock': this.tone(440, 0.09, 'triangle', 0.16, 660); break;
      case 'perfect': this.arp([84, 88, 91, 96], 0.045, 0.14, 'square', 0.1); break;
      case 'sweet': this.tone(mtof(76 + Math.min(12, v)), 0.1, 'square', 0.07); this.tone(mtof(83 + Math.min(12, v)), 0.14, 'square', 0.06, 0, 0.06); break;
      case 'zone': this.arp([60, 67, 72, 76], 0.09, 0.3, 'triangle', 0.15); break;
    }
  }

  private sched() {
    const c = this.ctx;
    if (!c || this.song === 'off' || c.state !== 'running') return;
    if (this.nextT < c.currentTime) this.nextT = c.currentTime + 0.05;
    while (this.nextT < c.currentTime + 0.25) {
      const t = this.nextT, s = this.step++;
      if (this.song === 'calm') {
        const i = s % 64, ch = CH[(i >> 3) % 4], k = i & 7;
        if (k === 0 || k === 4 || k === 6) this.tone(mtof(ch[k === 4 ? 2 : 0] - 12), 0.36, 'triangle', 0.17, 0, 0, t, this.mus);
        this.tone(mtof(ch[[0, 1, 2, 1, 0, 2, 1, 2][k]] + 12), 0.16, 'square', 0.022, 0, 0, t, this.mus);
        const m = (i < 32 ? MA : MB)[i % 32];
        if (m) { this.tone(mtof(m), 0.3, 'square', 0.04, 0, 0, t, this.mus); this.tone(mtof(m), 0.32, 'triangle', 0.08, 0, 0, t, this.mus); }
        if (k === 2 || k === 6) this.noise(0.03, 0.03, 7000, 0, 'highpass', 0, t, this.mus);
        this.nextT += 0.27;
      } else {
        const i = s % 64, ch = FC[(i >> 4) % 4], k = i & 15;
        if ((k & 1) === 0) this.tone(mtof(ch[0] - 12 + ((k & 7) === 6 ? 12 : 0)), 0.13, 'sawtooth', 0.075, 0, 0, t, this.mus);
        this.tone(mtof(ch[FA[k]] + 24), 0.09, 'square', 0.028, 0, 0, t, this.mus);
        if (k % 4 === 0) this.tone(130, 0.12, 'sine', 0.26, 45, 0, t, this.mus);
        this.noise(0.03, k % 4 === 2 ? 0.07 : 0.025, 7000, 0, 'highpass', 0, t, this.mus);
        this.nextT += 0.125;
      }
    }
  }
}
