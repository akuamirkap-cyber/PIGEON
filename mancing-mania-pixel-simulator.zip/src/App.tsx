import { useEffect, useReducer, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as RPE, ReactNode } from 'react';
import '@fontsource/press-start-2p/latin-400.css';
import '@fontsource/vt323/latin-400.css';
import { Game } from './game/game';
import { Sfx } from './game/audio';
import { W, H, Surface, hex, fromStrings } from './game/gfx';
import { silhouette } from './game/fishart';
import { SPECIES, LURES, ZONES, ROD, LINE, REEL, BOAT, TIER_NAME } from './game/data';
import { makeLureIcon, makeBoat, COIN } from './game/sprites';

const SAVE_KEY = 'mancing-mania-100-v1';
const fmt = (n: number) => Math.round(n).toLocaleString('id-ID');
const pos = (x: number, y: number): CSSProperties => ({ left: `calc(var(--u) * ${x})`, top: `calc(var(--u) * ${y})` });

// ---------------------------------------------------------------- pixel sprites -> <img>
interface Img { url: string; w: number; h: number }
const cache = new Map<string, Img>();
function img(key: string, make: () => Surface): Img {
  let v = cache.get(key);
  if (!v) {
    const s = make();
    const c = document.createElement('canvas');
    c.width = s.w; c.height = s.h;
    const ctx = c.getContext('2d')!;
    const im = ctx.createImageData(s.w, s.h);
    new Uint32Array(im.data.buffer).set(s.d);
    ctx.putImageData(im, 0, 0);
    v = { url: c.toDataURL(), w: s.w, h: s.h };
    cache.set(key, v);
  }
  return v;
}
function Spr({ i, s = 1, max, className = '' }: { i: Img; s?: number; max?: [number, number]; className?: string }) {
  const k = max ? Math.min(max[0] / i.w, max[1] / i.h, s) : s;
  return <img src={i.url} alt="" draggable={false} className={'pix ' + className} style={{ width: `calc(var(--u) * ${i.w * k})`, height: `calc(var(--u) * ${i.h * k})` }} />;
}
const ICON: Record<string, string[]> = {
  arrow: ['#....', '##...', '###..', '####.', '#####', '####.', '###..', '##...', '#....'],
  sound: ['...#..#.', '..##...#', '####.#.#', '####.#.#', '####.#.#', '..##...#', '...#..#.'],
  mute: ['...#....', '..##.#.#', '####..#.', '####.#.#', '####....', '..##....', '...#....'],
};
const icon = (n: string, col = '#141126') => img('ic:' + n + col, () => fromStrings(ICON[n], { '#': hex(col) }));
const fishImg = (g: Game, id: string, known = true) => img((known ? 'f:' : 's:') + id, () => (known ? g.fishSpr[id] : silhouette(g.fishSpr[id], hex('#0a1430'))));
const lureImg = (id: string) => img('l:' + id, () => makeLureIcon(id));
const coinImg = () => img('coin', () => COIN);
const Stars = ({ n, of = 3 }: { n: number; of?: number }) => (
  <span className="stars">{Array.from({ length: of }, (_, i) => <i key={i} className={i < n ? 'on' : ''}>★</i>)}</span>
);

function Hold({ className, onDown, onUp, children }: { className: string; onDown: () => void; onUp: () => void; children: ReactNode }) {
  return (
    <button
      className={className}
      onPointerDown={(e) => { e.preventDefault(); try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* noop */ } onDown(); }}
      onPointerUp={onUp} onPointerCancel={onUp} onLostPointerCapture={onUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

// ---------------------------------------------------------------- shop
function Shop({ g, onClose }: { g: Game; onClose: () => void }) {
  const [tab, setTab] = useState(0);
  const sv = g.sv;
  const price = (p: number, buy: () => void) => (
    <button className={'btn sm ' + (sv.coins >= p ? 'green' : 'off')} onClick={buy}><Spr i={coinImg()} s={0.75} /> {fmt(p)}</button>
  );
  const gear = (title: string, kind: 'rod' | 'reel' | 'line', tab_: { name: string; price: number }[], eff: string) => {
    const lv = sv[kind], next = tab_[lv];
    return (
      <div className="card row" key={kind}>
        <div className="grow">
          <div className="ct px">{title} <span className="pips">{tab_.map((_, i) => <i key={i} className={i < lv ? 'on' : ''} />)}</span></div>
          <div className="cn">{tab_[lv - 1].name}</div>
          <div className="cd">{next ? <>Berikutnya: <b>{next.name}</b> — {eff}</> : 'Sudah level maksimal. MANTAP!'}</div>
        </div>
        {next ? price(next.price, () => g.buy(kind)) : <span className="own px">MAKS</span>}
      </div>
    );
  };
  return (
    <div className="modal">
      <div className="panel shop">
        <div className="phead">
          <span className="px ptitle">TOKO PANCING</span>
          <div className="tabs">{['UMPAN', 'ALAT', 'PERAHU'].map((t, i) => <button key={t} className={'tab px' + (tab === i ? ' on' : '')} onClick={() => { setTab(i); g.au.play('ui'); }}>{t}</button>)}</div>
          <span className="chip in"><Spr i={coinImg()} /> <b className="px">{fmt(sv.coins)}</b></span>
          <button className="btn sm red" onClick={onClose}>X</button>
        </div>
        <div className="scroll">
          {tab === 0 && (
            <>
              <div className="tip">Tip: ikan hasil tangkapan bisa dijadikan <b>UMPAN HIDUP</b> untuk memancing ikan yang lebih besar!</div>
              {LURES.slice(1).map((l) => (
                <div className="card row" key={l.id}>
                  <div className="ico"><Spr i={lureImg(l.id)} s={1.6} /></div>
                  <div className="grow">
                    <div className="cn">{l.name}</div>
                    <div className="cd">{l.desc}</div>
                    <div className="cd tgt">Target: {Object.keys(l.aff).filter((k) => l.aff[+k] >= 0.3).map((k) => TIER_NAME[+k]).join(' · ')}</div>
                  </div>
                  {sv.lures.includes(l.id) ? <span className="own px">PUNYA</span> : price(l.price, () => g.buy('lure', l.id))}
                </div>
              ))}
            </>
          )}
          {tab === 1 && (
            <>
              {gear('JORAN', 'rod', ROD, 'kuat menahan ikan lebih besar')}
              {gear('SENAR', 'line', LINE, 'tidak gampang putus')}
              {gear('REEL', 'reel', REEL, 'gulungan lebih cepat & senar lebih panjang')}
            </>
          )}
          {tab === 2 &&
            BOAT.map((b, i) => (
              <div className={'card row' + (i + 1 === sv.boat ? ' cur' : '')} key={b.name}>
                <div className="ico wide"><Spr i={img('boat' + i, () => makeBoat(i + 1).s)} max={[62, 30]} /></div>
                <div className="grow">
                  <div className="cn">{b.name}</div>
                  <div className="cd">Kecepatan {b.speed} · Menjangkau <b>{ZONES[i].name}</b></div>
                </div>
                {i < sv.boat ? <span className="own px">{i + 1 === sv.boat ? 'DIPAKAI' : 'PUNYA'}</span> : i === sv.boat ? price(b.price, () => g.buy('boat')) : <span className="own px dim">TERKUNCI</span>}
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- fish book
function Book({ g, onClose }: { g: Game; onClose: () => void }) {
  const n = SPECIES.filter((s) => g.sv.rec[s.id]).length;
  return (
    <div className="modal">
      <div className="panel shop">
        <div className="phead">
          <span className="px ptitle">BUKU IKAN</span>
          <span className="grow sub">Koleksi {n}/{SPECIES.length} · Total tangkapan {g.sv.total}</span>
          <button className="btn sm red" onClick={onClose}>X</button>
        </div>
        <div className="scroll grid5">
          {SPECIES.map((s) => {
            const r = g.sv.rec[s.id];
            return (
              <div className={'fcard' + (r ? '' : ' unk') + (s.tier === 6 ? ' leg' : '')} key={s.id}>
                <div className="fimg"><Spr i={fishImg(g, s.id, !!r)} max={[60, 26]} /></div>
                <div className="fn">{r ? s.name : '???'}</div>
                <div className="fz">{ZONES[s.zone].name}</div>
                <div className="fr">{r ? `Rekor ${r.best} kg · ${r.n}x` : TIER_NAME[s.tier]}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- app
interface Pop { id: number; text: string; x: number; y: number; kind: string }
interface Banner { id: number; text: string; kind: string; sub?: string }
let uid = 0;

export default function App() {
  const gRef = useRef<Game | null>(null);
  const sRef = useRef<Sfx | null>(null);
  if (!gRef.current) {
    const g0 = new Game(), s0 = new Sfx();
    g0.au = s0;
    try { const raw = localStorage.getItem(SAVE_KEY); if (raw) g0.load(JSON.parse(raw)); } catch { /* ignore */ }
    gRef.current = g0; sRef.current = s0;
  }
  const g = gRef.current, sfx = sRef.current!;
  const [, force] = useReducer((x: number) => x + 1, 0);
  const [dim, setDim] = useState({ w: 960, rot: false });
  const [modal, setModal] = useState('');
  const [pops, setPops] = useState<Pop[]>([]);
  const [banner, setBanner] = useState<Banner | null>(null);
  const [muted, setMuted] = useState(false);
  const [sel, setSel] = useState('');
  const cvs = useRef<HTMLCanvasElement>(null);
  const distRef = useRef<HTMLSpanElement>(null), depthRef = useRef<HTMLSpanElement>(null), guideRef = useRef<HTMLSpanElement>(null), warnRef = useRef<HTMLDivElement>(null);
  const reel = useRef({ on: false, last: 0, id: -1, dir: 0, rev: 0 });
  const keyFn = useRef<{ confirm: () => void; sell: () => void; modal: string }>({ confirm: () => {}, sell: () => {}, modal: '' });

  useEffect(() => {
    g.onUI = force;
    g.onPop = (text, x, y, kind) => {
      const id = ++uid;
      setPops((p) => [...p.slice(-7), { id, text, x, y, kind }]);
      setTimeout(() => setPops((p) => p.filter((q) => q.id !== id)), 1150);
    };
    g.onBanner = (text, kind, sub) => {
      const id = ++uid;
      setBanner({ id, text, kind, sub });
      setTimeout(() => setBanner((b) => (b && b.id === id ? null : b)), kind === 'zone' || kind === 'info' ? 2600 : 1500);
    };
    g.onSave = () => { try { localStorage.setItem(SAVE_KEY, JSON.stringify(g.sv)); } catch { /* ignore */ } };
    g.onBuzz = (ms) => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch { /* ignore */ } };
  }, [g]);

  useEffect(() => {
    const f = () => {
      let vw = window.innerWidth, vh = window.innerHeight;
      const rot = vh > vw && window.matchMedia('(pointer: coarse)').matches;
      if (rot) [vw, vh] = [vh, vw];
      setDim({ w: Math.min(vw, (vh * 16) / 9), rot });
    };
    f();
    window.addEventListener('resize', f);
    return () => window.removeEventListener('resize', f);
  }, []);

  useEffect(() => {
    const cv = cvs.current;
    const ctx = cv && cv.getContext('2d');
    if (!ctx) return;
    const im = ctx.createImageData(W, H);
    const buf = new Uint32Array(im.data.buffer);
    let last = performance.now(), raf = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - last) / 1000));
      last = now;
      g.update(dt);
      g.render();
      buf.set(g.fb.d);
      ctx.putImageData(im, 0, 0);
      if (g.phase === 'fight' && g.fight) {
        if (distRef.current) distRef.current.textContent = g.fight.dist.toFixed(1) + ' m';
        if (warnRef.current) {
          const w = g.hudWarn;
          warnRef.current.textContent = w === 2 ? 'AWAS PUTUS! KENDURKAN!' : w === 1 ? 'SENAR KENDOR! PUTAR REEL!' : '';
          warnRef.current.dataset.w = String(w);
        }
      } else if (depthRef.current && (g.phase === 'sink' || g.phase === 'wait' || g.phase === 'bite')) depthRef.current.textContent = g.depth.toFixed(1) + ' m';
      else if (guideRef.current && g.phase === 'sail') {
        const m = Math.round(Math.abs(g.guideDx) / 4);
        guideRef.current.textContent = g.guideDx < 0 ? `« ${m} m` : `${m} m »`;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [g]);

  useEffect(() => {
    const dn = (e: KeyboardEvent) => {
      if (e.repeat) { if (e.key === ' ') e.preventDefault(); return; }
      sfx.init();
      const k = e.key.toLowerCase();
      if (k === 'escape') { if (keyFn.current.modal) setModal(''); else g.back(); return; }
      if (keyFn.current.modal) return;
      if (k === 'arrowleft' || k === 'a') g.input.dir = -1;
      else if (k === 'arrowright' || k === 'd') g.input.dir = 1;
      else if (k === ' ' || k === 'enter') {
        e.preventDefault();
        const p = g.phase;
        if (p === 'title') g.start();
        else if (p === 'sail') g.openPick();
        else if (p === 'pick') keyFn.current.confirm();
        else if (p === 'aim') g.press();
        else if (p === 'fight') { if (k === ' ') g.input.reel = true; if (k === 'enter' || (g.fight && g.fight.jump)) g.act(); }
        else if (p === 'caught') { if (g.pt > 0.8) keyFn.current.sell(); }
        else g.act();
      } else if (k === 'x' || k === 'arrowup' || k === 'w') g.act();
    };
    const up = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if ((k === 'arrowleft' || k === 'a') && g.input.dir < 0) g.input.dir = 0;
      if ((k === 'arrowright' || k === 'd') && g.input.dir > 0) g.input.dir = 0;
      if (k === ' ' || k === 'enter') { g.input.reel = false; g.release(); }
    };
    window.addEventListener('keydown', dn);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', dn); window.removeEventListener('keyup', up); };
  }, [g, sfx]);

  // ---- reel crank (drag in circles)
  const reelAngle = (e: RPE<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    return { a: Math.atan2(dy, dx), far: dx * dx + dy * dy > (r.width * 0.05) ** 2 };
  };
  const reelDown = (e: RPE<HTMLDivElement>) => {
    sfx.init();
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* noop */ }
    const { a } = reelAngle(e);
    reel.current = { on: true, last: a, id: e.pointerId, dir: 0, rev: 0 };
    g.reelBy(0, a - (dim.rot ? Math.PI / 2 : 0));
  };
  const reelMove = (e: RPE<HTMLDivElement>) => {
    const s = reel.current;
    if (!s.on || e.pointerId !== s.id) return;
    const { a, far } = reelAngle(e);
    if (!far) return;
    let d = a - s.last;
    if (d > Math.PI) d -= Math.PI * 2;
    else if (d < -Math.PI) d += Math.PI * 2;
    s.last = a;
    // either direction reels, but it has to be a steady circle (no back-and-forth wiggling)
    const sg = d < 0 ? -1 : 1, abs = a - (dim.rot ? Math.PI / 2 : 0);
    if (!s.dir) s.dir = sg;
    if (sg === s.dir) { s.rev = 0; g.reelBy(Math.abs(d), abs); }
    else { s.rev += Math.abs(d); g.reelBy(0, abs); if (s.rev > 0.7) { s.dir = sg; s.rev = 0; } }
  };
  const reelUp = () => { reel.current.on = false; };

  const p = g.phase, sv = g.sv, zone = ZONES[g.zone];
  const open = (m: string) => { sfx.init(); g.input.dir = 0; g.au.play('ui'); setModal(m); };
  const afterCatch = (fn: () => void) => { const legend = !!g.ci && g.ci.sp.tier === 6; fn(); if (legend) setModal('end'); };

  // ---- lure picker options
  const zi = g.spot ? g.spot.zone : g.zone;
  const opts = p === 'pick'
    ? [
        ...LURES.filter((l) => sv.lures.includes(l.id)).map((l) => ({ key: 'l:' + l.id, kind: 'l' as const, id: l.id, name: l.name, desc: l.desc, count: -1, m: g.match('l', l.id, zi) })),
        ...SPECIES.filter((s) => (sv.bait[s.id] || 0) > 0).map((s) => ({ key: 'b:' + s.id, kind: 'b' as const, id: s.id, name: s.name, desc: 'UMPAN HIDUP! Memikat ikan yang lebih besar dengan bobot ekstra. Habis sekali pakai.', count: sv.bait[s.id], m: g.match('b', s.id, zi) })),
      ]
    : [];
  const cur = opts.find((o) => o.key === sel) || opts.find((o) => o.key === sv.last && o.m > 0) || opts.slice().sort((a, b) => b.m - a.m)[0];
  const starOf = (m: number) => (m >= 0.6 ? 3 : m >= 0.25 ? 2 : m > 0 ? 1 : 0);
  const curAff = cur ? g.lureAff(cur.kind, cur.id) : {};
  keyFn.current = {
    modal,
    confirm: () => { if (cur && cur.m > 0) g.choose(cur.kind, cur.id); },
    sell: () => afterCatch(() => g.sell()),
  };
  const f = g.fight;
  const stTxt = f ? (f.state === 'run' ? 'IKAN KABUR! TAHAN, JANGAN DIPUTAR!' : f.state === 'tired' ? 'IKAN LELAH — PUTAR CEPAT!' : f.state === 'jump' ? 'LOMPAT! SENTAK SEKARANG!' : 'TARIK! JAGA DI ZONA HIJAU') : '';

  const stageStyle = {
    width: dim.w, height: (dim.w * 9) / 16, left: '50%', top: '50%',
    transform: `translate(-50%, -50%)${dim.rot ? ' rotate(90deg)' : ''}`,
    '--u': dim.w / W + 'px',
  } as CSSProperties;

  return (
    <div className="wrap">
      <div className="stage" style={stageStyle} onPointerDown={() => sfx.init()} onContextMenu={(e) => e.preventDefault()}>
        <canvas ref={cvs} width={W} height={H} />
        <div className="ui">
          {p === 'title' && (
            <div className="title">
              <div className="ribbon px">★ EDISI SPESIAL 100 TAHUN ★</div>
              <h1 className="logo px"><span data-t="MANCING">MANCING</span><span data-t="MANIA" className="l2">MANIA</span></h1>
              <div className="mantap px">MANTAP!</div>
              <button className="btn big green start" onClick={() => { sfx.init(); g.start(); }}>{sv.total > 0 ? 'LANJUT MANCING' : 'MULAI MANCING'}</button>
              <div className="foot">Lomba Game Peringatan 100 Tahun Acara TV Mancing Mania</div>
            </div>
          )}

          {p === 'sail' && (
            <>
              <div className="topbar">
                <span className="chip"><Spr i={coinImg()} /> <b className="px">{fmt(sv.coins)}</b></span>
                <span className="chip zn">{zone.name}</span>
                <span className="grow" />
                <button className="btn sm blue" onClick={() => open('shop')}>TOKO</button>
                <button className="btn sm" onClick={() => open('book')}>BUKU IKAN</button>
                <button className="btn sm dark" onClick={() => { sfx.init(); sfx.setMuted(!muted); setMuted(!muted); }}><Spr i={icon(muted ? 'mute' : 'sound', '#ffffff')} /></button>
              </div>
              <div className="dpad">
                <Hold className="btn dir" onDown={() => { sfx.init(); g.input.dir = -1; }} onUp={() => { if (g.input.dir < 0) g.input.dir = 0; }}><Spr i={icon('arrow')} s={1.6} className="flipx" /></Hold>
                <Hold className="btn dir" onDown={() => { sfx.init(); g.input.dir = 1; }} onUp={() => { if (g.input.dir > 0) g.input.dir = 0; }}><Spr i={icon('arrow')} s={1.6} /></Hold>
              </div>
              {g.near ? (
                <button className={'btn big green fishbtn' + (g.near.gold ? ' goldspot' : '')} onClick={() => g.openPick()}>
                  MANCING!<small>{g.near.gold ? '★ SPOT EMAS ★' : `kawanan: ${g.near.left} ikan`}</small>
                </button>
              ) : (
                <div className="guide chip">Kawanan burung = spot ikan <b className="px" ref={guideRef} /></div>
              )}
            </>
          )}

          {p === 'pick' && cur && g.spot && (
            <div className="modal clear">
              <div className="panel pick">
                <div className="phead">
                  <span className="px ptitle">PILIH UMPAN</span>
                  <span className="grow sub">{ZONES[zi].name}{g.spot.gold ? ' · ★ SPOT EMAS' : ''} · kedalaman {ZONES[zi].maxDepth} m</span>
                  <span className="chip in"><Spr i={coinImg()} /> <b className="px">{fmt(sv.coins)}</b></span>
                  <button className="btn sm blue" onClick={() => open('shop')}>TOKO</button>
                </div>
                <div className="pbody">
                  <div className="lures scroll">
                    {opts.map((o) => (
                      <button key={o.key} className={'lure' + (o.key === cur.key ? ' on' : '') + (o.m <= 0 ? ' bad' : '')} onClick={() => { setSel(o.key); g.au.play('ui'); }}>
                        <span className="li">{o.kind === 'l' ? <Spr i={lureImg(o.id)} s={1.5} /> : <Spr i={fishImg(g, o.id)} max={[38, 22]} />}</span>
                        <span className="ln">{o.name}</span>
                        <Stars n={starOf(o.m)} />
                        {o.kind === 'b' && <span className="cnt px">x{o.count}</span>}
                        {o.kind === 'b' && <span className="live px">HIDUP</span>}
                      </button>
                    ))}
                    {LURES.filter((l) => !sv.lures.includes(l.id)).map((l) => (
                      <button key={l.id} className="lure lock" onClick={() => open('shop')}>
                        <span className="li"><Spr i={lureImg(l.id)} s={1.5} /></span>
                        <span className="ln">{l.name}</span>
                        <span className="lp px"><Spr i={coinImg()} s={0.6} /> {fmt(l.price)}</span>
                      </button>
                    ))}
                  </div>
                  <div className="pinfo">
                    <div className="cn big">{cur.name}{cur.kind === 'b' ? ' (hidup)' : ''}</div>
                    <div className="cd">{cur.desc}</div>
                    <div className={'fit f' + starOf(cur.m)}><Stars n={starOf(cur.m)} /> {['TIDAK COCOK DI SINI', 'Kurang cocok', 'Lumayan cocok', 'COCOK BANGET!'][starOf(cur.m)]}</div>
                    <div className="cd lbl2">Ikan di perairan ini:</div>
                    <div className="targets">
                      {SPECIES.filter((s) => s.zone === zi).map((s) => {
                        const known = !!sv.rec[s.id];
                        return (
                          <div key={s.id} className={'tg' + ((curAff[s.tier] || 0) > 0 ? ' hit' : '')}>
                            <Spr i={fishImg(g, s.id, known)} max={[40, 15]} />
                            <span>{known ? s.name : '???'}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
                <div className="pfoot">
                  <button className="btn dark" onClick={() => g.back()}>KEMBALI</button>
                  <button className={'btn big ' + (cur.m > 0 ? 'green' : 'off')} onClick={() => keyFn.current.confirm()}>PASANG &amp; LEMPAR!</button>
                </div>
              </div>
            </div>
          )}

          {p === 'aim' && (
            <>
              <div className="lbl px ol" style={pos(6, 36)}>TENAGA</div>
              <button className="btn sm dark backbtn" onClick={() => g.back()}>GANTI UMPAN</button>
              <div className="hint ol">TAHAN tombol <b>LEMPAR</b>, lepaskan tepat di <b>garis emas</b> untuk lemparan sempurna!</div>
              <Hold className="btn big actbtn" onDown={() => { sfx.init(); g.press(); }} onUp={() => g.release()}>LEMPAR</Hold>
            </>
          )}
          {(p === 'sink' || p === 'wait' || p === 'bite') && (
            <>
              <div className="lbl px ol" style={pos(34, 44)}>DALAM<br /><span ref={depthRef}>0 m</span></div>
              {p !== 'sink' && <div className="lbl px ol" style={pos(132, 3)}>MINAT IKAN</div>}
              {p !== 'bite' && <button className="btn sm dark backbtn" onClick={() => g.back()}>LEMPAR ULANG</button>}
              <div className="hint ol">
                {p === 'sink' ? <>Umpan dicelupkan… tekan <b>TAHAN</b> saat tepat di <b>zona hijau</b> (kawanan ikan)!</>
                  : p === 'bite' ? <b className="now">SEKARANG!!!</b>
                  : g.nibbling ? <>Umpan dicicipi… <b>JANGAN digoyang!</b> Tunggu tanda <b>!</b></>
                  : <>Ketuk <b>GOYANG</b> berirama untuk memikat ikan mendekat</>}
              </div>
              <button
                className={'btn big actbtn ' + (p === 'sink' ? 'blue' : p === 'bite' ? 'red strike' : g.nibbling ? 'dark' : '')}
                onPointerDown={(e) => { e.preventDefault(); sfx.init(); g.act(); }}
              >
                {p === 'sink' ? 'TAHAN!' : p === 'bite' ? 'STRIKE!' : g.nibbling ? 'TUNGGU…' : 'GOYANG'}
              </button>
            </>
          )}

          {p === 'fight' && f && (
            <>
              <div className="lbl r px ol" style={pos(4, 14)}>TEGANGAN</div>
              <div className="lbl r px ol" style={pos(4, 27)}>TENAGA IKAN</div>
              <div className="lbl r px ol" style={pos(-1, 35)}>JARAK <span ref={distRef} className="gold" /></div>
              <div className={'fstate ol px s-' + f.state}>{stTxt}</div>
              <div className="fwarn ol px" ref={warnRef} />
              <div className="turn ol px">PUTAR ↻</div>
              <div className="reelzone" onPointerDown={reelDown} onPointerMove={reelMove} onPointerUp={reelUp} onPointerCancel={reelUp} />
              {f.jump && !f.jump.hit && (
                <button className="btn big red sentak" onPointerDown={(e) => { e.preventDefault(); g.act(); }}>SENTAK!</button>
              )}
              <div className="hint ol left">Putar gagang reel melingkar terus-menerus (atau tahan SPASI)</div>
            </>
          )}

          {p === 'caught' && g.ci && (
            <div className={'catch' + (g.ci.sp.tier === 6 ? ' leg' : '')}>
              <div className="tags px">
                {g.ci.first && <span className="tag new">IKAN BARU!</span>}
                {g.ci.record && <span className="tag rec">REKOR BARU!</span>}
                {g.ci.monster && <span className="tag mon">MONSTER!</span>}
              </div>
              <div className="crow">
                <div className="grow">
                  <div className="cname px">{g.ci.sp.name}</div>
                  <div className="cd"><Stars n={g.ci.sp.tier} of={6} /> Kelas {TIER_NAME[g.ci.sp.tier]} · {ZONES[g.ci.sp.zone].name}</div>
                  <div className="cd">{g.ci.sp.desc}</div>
                </div>
                <div className="stats">
                  <div className="st hl"><small>BERAT</small><b className="px">{g.ci.kg} kg</b></div>
                  <div className="st"><small>PANJANG</small><b className="px">{g.ci.cm} cm</b></div>
                  <div className="st"><small>WAKTU TARIK</small><b className="px">{g.ci.secs} dtk</b></div>
                  <div className="st"><small>REKOR</small><b className="px">{g.ci.first ? 'BARU!' : Math.max(g.ci.prev, g.ci.kg) + ' kg'}</b></div>
                </div>
              </div>
              <div className="crow btns">
                <button className="btn green" onClick={() => afterCatch(() => g.sell())}>JUAL <Spr i={coinImg()} s={0.9} /> {fmt(g.ci.value)}</button>
                <button className="btn blue" onClick={() => afterCatch(() => g.keep())}>JADIKAN UMPAN HIDUP</button>
              </div>
            </div>
          )}

          {p === 'pamer' && (
            <div className="tapskip" onPointerDown={() => g.act()}>
              <span className="ol">Ketuk untuk lihat statistik ikan</span>
            </div>
          )}

          {p === 'fail' && <div className="fail px ol">{g.failMsg}<small>Coba lagi, jangan menyerah!</small></div>}

          {modal === 'shop' && <Shop g={g} onClose={() => setModal('')} />}
          {modal === 'book' && <Book g={g} onClose={() => setModal('')} />}
          {modal === 'end' && (
            <div className="modal">
              <div className="panel end">
                <div className="ribbon px">★ 100 TAHUN MANCING MANIA ★</div>
                <div className="px etitle">JUARA LOMBA!</div>
                <Spr i={fishImg(g, 'emas')} max={[200, 70]} />
                <p>Kamu menaklukkan <b>Marlin Emas 100 Tahun</b>, legenda yang dikejar para pemancing selama seabad. Total tangkapan: <b>{sv.total}</b> ikan.</p>
                <div className="px mantap2">MANTAP!</div>
                <button className="btn big green" onClick={() => setModal('')}>LANJUT MANCING</button>
              </div>
            </div>
          )}

          {banner && (
            <div key={banner.id} className={'banner px b-' + banner.kind}>
              <span data-t={banner.text}>{banner.text}</span>
              {banner.sub && <small>{banner.sub}</small>}
            </div>
          )}
          {pops.map((q) => <div key={q.id} className={'pop px ol k-' + q.kind} style={pos(q.x, q.y)}>{q.text}</div>)}
        </div>
      </div>
    </div>
  );
}
