import type * as Three from 'three';
import { createDriftScore } from './drift-score.js';
import type { DriftScore } from './drift-score.js';
import { createTrack } from './rally-road.js';
import type { RoadFrame } from './rally-road.js';
import { courseMarkerInterval } from './speed-cues.js';
import { createDriveLighting } from './drive-lighting';

export type RunMode = 'attack' | 'practice';
export type DriftZone = { path: string; start: number; end: number; side: number };

export type Telemetry = {
  lap: number;
  time: number;
  best: number | null;
  last: number | null;
  speed: number;
  gear: string;
  rev: number;
  shifting: boolean;
  coasting: boolean;
  throttle: number;
  mapX: number;
  mapY: number;
  heading: number;
  distance: number;
  driftAngle: number;
  controlPhase: 'grip' | 'entry' | 'slide' | 'link' | 'exit';
  drift: DriftScore;
  mode: RunMode;
  finished: boolean;
};

export const emptyTelemetry: Telemetry = { lap:1,time:0,best:null,last:null,speed:0,gear:'1',rev:.16,shifting:false,coasting:false,throttle:0,mapX:0,mapY:0,
  heading:0,distance:0,driftAngle:0,controlPhase:'grip',drift:createDriftScore().snapshot(),mode:'attack',finished:false };

export function createRallyCourse(T: typeof Three) {
  const scene = new T.Scene();
  const track=createTrack(T);
  const {length,segments,start,roadWidth,barrier,frames,at,route,origin,startMarker,zones}=track;
  // Dense sampler for the 5 rival AI bots (position, heading and signed curvature at any arc length, incl. before the start line)
  const botGap=length/segments;
  const botCurv=new Float32Array(segments);
  for(let i=0;i<segments;i++){
    const a=frames[(i-4+segments)%segments], b=frames[(i+4)%segments];
    botCurv[i]=Math.atan2(a.tz*b.tx-a.tx*b.tz, a.tx*b.tx+a.tz*b.tz)/(8*botGap);
  }
  const botTrack={
    length, loop:true,
    at(s:number) {
      const a=T.MathUtils.euclideanModulo(s,length)/botGap, i=Math.floor(a)%segments, f=a-Math.floor(a);
      const p=frames[i], q=frames[(i+1)%segments];
      const tx=p.tx+(q.tx-p.tx)*f, tz=p.tz+(q.tz-p.tz)*f, len=Math.hypot(tx,tz)||1;
      return { x:p.x+(q.x-p.x)*f, y:0, z:p.z+(q.z-p.z)*f, tx:tx/len, tz:tz/len,
        curv:botCurv[i]*(1-f)+botCurv[(i+1)%segments]*f };
    },
  };
  // World scale follows the RMX-proportioned circuit (scenery objects keep real sizes)
  const S=track.scale, LS=track.laneScale;
  const movingFrame = { x:0,z:0,tx:0,tz:1 };
  const bannerFrame=at(start+14,{...movingFrame}), bannerLane=-barrier-1.45;
  const bannerAt={x:bannerFrame.x+bannerFrame.tz*bannerLane,z:bannerFrame.z-bannerFrame.tx*bannerLane};

  let seed=77423;
  const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  const standard=(color:number, params:Three.MeshStandardMaterialParameters={}) => new T.MeshStandardMaterial({ color, flatShading:true, roughness:.94, ...params });
  const land=standard(0xffffff,{vertexColors:true});
  const groundGeometry=new T.PlaneGeometry(730*S,730*S,Math.round(58*S),Math.round(58*S));
  groundGeometry.rotateX(-Math.PI/2);
  const terrain=groundGeometry.attributes.position;
  const moss=new T.Color(0x689966), meadow=new T.Color(0x8ca75d), greens:number[]=[];
  for(let i=0;i<terrain.count;i++) {
    const x=terrain.getX(i), z=terrain.getZ(i);
    const t=.47+.22*Math.sin(x*.068+z*.013)+.21*Math.cos(z*.095-x*.025);
    const color=moss.clone().lerp(meadow,t).multiplyScalar(.92+random()*.125);
    greens.push(color.r,color.g,color.b);
  }
  groundGeometry.setAttribute('color',new T.Float32BufferAttribute(greens,3));
  const ground=new T.Mesh(groundGeometry,land);
  ground.position.y=-.084; scene.add(ground);
  // Default drive lighting = HDR hemisphere/directional rig from the three.js lighting example (HSL sun & sky,
  // gradient dome, white haze). Fully adjustable 0–100% from the PENCAHAYAAN panel group.
  const lighting = createDriveLighting(T, scene, { radius: 500 * S, fogNear: 1, fogFar: 4200 });
  const trackPaint=standard(0xffffff,{vertexColors:true,side:T.DoubleSide});

  type Rail = [offset: number, height: number];
  const railsPoint=(point:RoadFrame,rail:Rail)=>[point.x+point.tz*rail[0],rail[1],point.z-point.tx*rail[0]];
  const chunkSize=48, roadChunks=new Map<Three.Material,{points:number[];colors:number[];uv:number[]}[]>();
  function ribbon(rails: Rail[], color: (segment:number, band:number)=>Three.Color, material:Three.Material=trackPaint) {
    let chunks=roadChunks.get(material);
    if(!chunks) {
      chunks=Array.from({length:Math.ceil(segments/chunkSize)},()=>({points:[],colors:[],uv:[]}));
      roadChunks.set(material,chunks);
    }
    for(let i=0;i<segments;i++) for(let j=0;j<rails.length-1;j++) {
      const {points,colors,uv}=chunks[Math.floor(i/chunkSize)];
      const a=frames[i], b=frames[(i+1)%segments], r=rails[j], s=rails[j+1];
      const p=railsPoint(a,r),q=railsPoint(b,r),u=railsPoint(b,s),v=railsPoint(a,s);
      points.push(...p,...u,...q,...p,...v,...u);
      const ra=r[0]*.45, rb=s[0]*.45, sa=i*length/segments*.24, sb=(i+1)*length/segments*.24;
      uv.push(ra,sa,rb,sb,ra,sb,ra,sa,rb,sa,rb,sb);
      const c=color(i,j);
      for(let k=0;k<6;k++) colors.push(c.r,c.g,c.b);
    }
  }
  const gritCanvas=document.createElement('canvas');gritCanvas.width=gritCanvas.height=128;
  const gritInk=gritCanvas.getContext('2d')!, grain=gritInk.createImageData(128,128);
  for(let i=0;i<grain.data.length;i+=4) {
    const value=200+random()*55;
    grain.data[i]=grain.data[i+1]=grain.data[i+2]=value;grain.data[i+3]=255;
  }
  gritInk.putImageData(grain,0,0);
  const grit=new T.CanvasTexture(gritCanvas);grit.colorSpace=T.SRGBColorSpace;grit.wrapS=grit.wrapT=T.RepeatWrapping;grit.anisotropy=4;
  const roadMat=standard(0xffffff,{vertexColors:true,side:T.DoubleSide,map:grit});
  const asphalt=new T.Color(0x454b50), tar=new T.Color(0x505455), variation=asphalt.clone();
  ribbon([[-roadWidth,-.019],[-4.3,-.013],[-2.08,-.012],[.08,-.01],[2.25,-.012],[4.25,-.016],[roadWidth,-.019]],(i,j)=>{
    return variation.copy(asphalt).lerp(tar,[.37,.10,.23,.32,.15,.40][j]+.12*(Math.sin(i*.065)*.5+.5)+random()*.045);
  },roadMat);
  const border=new T.Color(0xdaddcd), curbs=[new T.Color(0xf0ac47),new T.Color(0xe4dfcb),new T.Color(0xca5637)];
  const wallTones=[0x4a524a,0x7c8981,0x9fa7a0,0xcbd0bc,0x8d9897,0x717b72].map(h=>new T.Color(h));
  const curbLip=new T.Color(0x807766), dry=new T.Color(0xa98e6a), grass=new T.Color(0x83a368);
  const vergePaint=new T.Color(0x3f7f52), runoffTone=new T.Color(0x5d6468);
  for(const sign of [-1,1]) {
    const signed=(k:number,y:number):Rail=>[sign*k,y];
    ribbon([signed(roadWidth-.13,-.005),signed(roadWidth-.035,-.005)],(i)=>variation.copy(border).multiplyScalar(.89+.11*Math.sin(i*.44)**2));
    ribbon([signed(roadWidth,-.008),signed(roadWidth+.17,.025),signed(roadWidth+.45,.047),signed(roadWidth+.53,-.024)],(i,j)=>{
      const time=i/segments*length;
      if(j===2) return curbLip;
      return curbs[Math.floor(time/1.8)%2===0?1:((time>46&&time<102)||(time>189&&time<258))?0:2];
    });
    ribbon([signed(barrier,-.06),signed(barrier,.12),signed(barrier+.12,.24),signed(barrier+.18,.61),signed(barrier+.27,.657),signed(barrier+.52,.657),signed(barrier+.66,-.055)],(i,j)=>{
      const c=wallTones[j];
      return variation.copy(c).multiplyScalar(i%12===0?.77:.94+.07*Math.sin(i*.31)**2);
    });
    // Modern-circuit verge: painted green band after the kerb, paved run-off, then a gravel strip at the barrier
    const runoff=track.runoff??barrier;
    ribbon([signed(roadWidth+.5,-.021),signed(roadWidth+2.1,-.021)],(i)=>variation.copy(vergePaint).multiplyScalar(.92+.08*Math.sin(i*.37)**2),roadMat);
    ribbon([signed(roadWidth+2.1,-.021),signed(runoff,-.024)],(i)=>variation.copy(runoffTone).lerp(tar,.12+.10*(Math.sin(i*.045)*.5+.5)+random()*.04),roadMat);
    ribbon([signed(runoff,-.028),signed(runoff+.31,-.042),signed(barrier,-.06),signed(barrier+.38,-.067)],(i,j)=>{
      return variation.copy(dry).lerp(grass,[.04,.18,.26][j]+.07*Math.sin(i*.31));
    },roadMat);
  }
  for(const [material,chunks] of roadChunks) for(const {points,colors,uv} of chunks) {
    const geometry=new T.BufferGeometry();
    geometry.setAttribute('position',new T.Float32BufferAttribute(points,3));
    geometry.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
    geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3));geometry.computeVertexNormals();
    const mesh=new T.Mesh(geometry,material);mesh.name='Track section';scene.add(mesh);
  }

  const glowZone:number[]=[], lineZone:number[]=[], edgeTick:number[]=[];
  function mark(target:number[],from:number,to:number,inner:number,outer:number) {
    const a=at(start+from,{...movingFrame}), b=at(start+to,{...movingFrame});
    const p=railsPoint(a,[inner,.004]),q=railsPoint(a,[outer,.004]),r=railsPoint(b,[outer,.004]),s=railsPoint(b,[inner,.004]);
    target.push(...p,...q,...r,...p,...r,...s);
  }
  for(const zone of zones) {
    const u=zone.side;
    for(let t=zone.start;t<zone.end;t+=1.15) mark(glowZone,t,Math.min(t+1.15,zone.end),3.40*LS*u,6.91*LS*u);
    for(let t=zone.start;t+1<zone.end;t+=3.1) {
      mark(lineZone,t,t+1.19,3.40*LS*u,3.40*LS*u+.14*u);
      mark(lineZone,t,t+1.60,6.81*LS*u,6.81*LS*u+.17*u);
      mark(edgeTick,t+.41,t+.56,6.38*LS*u,6.83*LS*u);
    }
  }
  for(const [points,opacity,order] of [[glowZone,.105,0],[lineZone,.72,1],[edgeTick,.47,1]] as const) {
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(points,3));
    const mesh=new T.Mesh(geo,new T.MeshBasicMaterial({color:0x8cddc6,side:T.DoubleSide,transparent:true,depthWrite:false,opacity,toneMapped:false}));
    mesh.name='Zona luar drift';mesh.renderOrder=order;scene.add(mesh);
  }

  // The same physical intervals remain visible at 50 km/h and 100 km/h.
  const joint:number[]=[], exposed:number[]=[], seams:number[]=[], studSpacing=courseMarkerInterval*.5;
  const studCount=Math.floor(length/studSpacing),postCount=Math.floor(length/courseMarkerInterval),placement=new T.Object3D();
  const stud=new T.InstancedMesh(new T.BoxGeometry(.16,.028,.23),standard(0xe5ad63,{emissive:0xae6131,emissiveIntensity:.18}),studCount*2);
  const post=new T.InstancedMesh(new T.BoxGeometry(.115,.66,.14),standard(0xc1c8b9),postCount*2);
  const postHead=new T.InstancedMesh(new T.BoxGeometry(.139,.28,.162),standard(0x263d3a),postCount*2);
  const lens=new T.InstancedMesh(new T.BoxGeometry(.10,.112,.176),standard(0xf3bf76,{emissive:0xf09343,emissiveIntensity:.25}),postCount*2);
  const frame={...movingFrame};
  function put(mesh:Three.InstancedMesh,index:number,lane:number,y:number) {
    placement.position.set(frame.x+frame.tz*lane,y,frame.z-frame.tx*lane);
    placement.rotation.y=Math.atan2(frame.tx,frame.tz);placement.updateMatrix();mesh.setMatrixAt(index,placement.matrix);
  }
  for(const [s,side] of [-1,1].entries()) {
    for(let i=0;i<studCount;i++) {
      const distance=(i+.42)*studSpacing;
      at(start+distance,frame);put(stud,s*studCount+i,(roadWidth-.27)*side,.016);
      mark(seams,distance-.27,distance-.12,(roadWidth-.14)*side,(roadWidth-.96)*side);
    }
    for(let i=0;i<postCount;i++) {
      at(start+(i+.21)*courseMarkerInterval,frame);
      const index=s*postCount+i, lane=(barrier+.32)*side;
      put(post,index,lane,.97);put(postHead,index,lane,1.17);put(lens,index,lane,1.19);
    }
  }
  for(const [mesh,name] of [[stud,'Asphalt reflectors'],[post,'Barrier guideposts'],[postHead,'Guidepost trim'],[lens,'Guidepost reflectors']] as const) {
    mesh.name=name;mesh.instanceMatrix.needsUpdate=true;scene.add(mesh);
  }
  const seamGeo=new T.BufferGeometry();seamGeo.setAttribute('position',new T.Float32BufferAttribute(seams,3));
  scene.add(new T.Mesh(seamGeo,new T.MeshBasicMaterial({color:0xd7cba5,side:T.DoubleSide,transparent:true,opacity:.65,depthWrite:false})));
  for(let i=0;i<postCount;i++) {
    const d=(i+.67)*courseMarkerInterval+Math.sin(i*2.77)*1.56;
    const left=Math.sin(i*1.19)*2.15-1.87,right=left+3.8+Math.cos(i*1.03)*1.38;
    mark(exposed,d-.40,d+.34,left,right);
    mark(joint,d+.35,d+.46,left-.28,right+.35);
  }
  for(const [points,color,opacity] of [[exposed,0x8a8a7c,.20],[joint,0x171e21,.46]] as const) {
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(points,3));
    const mesh=new T.Mesh(geo,new T.MeshBasicMaterial({color,opacity,side:T.DoubleSide,transparent:true,depthWrite:false}));
    mesh.name='Stationary asphalt repairs';scene.add(mesh);
  }

  const markPoints:number[]=[], startFrame=at(start-3.6,{...movingFrame});
  for(let row=0;row<2;row++) for(let col=0;col<26;col++) if((row+col)%2===0) {
    const right=roadWidth-.15-col*(roadWidth-.15)/13,left=right-(roadWidth-.15)/13;
    const point=(u:number,v:number)=>[startFrame.x+startFrame.tz*u+startFrame.tx*v,.005,startFrame.z-startFrame.tx*u+startFrame.tz*v];
    const a=point(left,row*.43), b=point(right,row*.43), c=point(right,(row+1)*.43), d=point(left,(row+1)*.43);
    markPoints.push(...a,...b,...c,...a,...c,...d);
  }
  const startGeo=new T.BufferGeometry(); startGeo.setAttribute('position',new T.Float32BufferAttribute(markPoints,3)); startGeo.computeVertexNormals();
  scene.add(new T.Mesh(startGeo,standard(0xd2d3bf,{side:T.DoubleSide})));

  const oldTracks:number[]=[], oldInk:number[]=[];
  for(const [begin,finish,offset,ink] of [[start+10,start+64,.85,.34],[start+20,start+79,-1.16,.25],[start+27,start+52,2.25,.19],
    [113*S,164*S,.36,.31],[190*S,232*S,-.78,.27],[279*S,337*S,-1.45,.29],[394*S,443*S,.65,.24],[491*S,532*S,1.12,.31],[602*S,647*S,-.76,.30]]) {
    const frame={...movingFrame};
    for(const side of [-1,1]) {
      const rows=Array.from({length:Math.ceil((finish-begin)/.86)},(_,i)=>{
        const t=i/Math.ceil((finish-begin)/.86), f=at(begin+i*.86,frame);
        const radius=offset+side*.98+Math.sin(t*Math.PI*1.28)*1.0+.34*Math.sin(i*.11+offset);
        const half=.080+ink*.22+.022*Math.cos(i*.17), shade=Math.sin(Math.PI*t)**.52*ink*(.88+.12*Math.cos(i*.46));
        return { a:railsPoint(f,[radius-half,-.002]), b:railsPoint(f,[radius+half,-.002]), shade };
      });
      for(let j=1;j<rows.length;j++) {
        const p=rows[j-1],q=rows[j];oldTracks.push(...p.a,...q.b,...q.a,...p.a,...p.b,...q.b);
        oldInk.push(p.shade,q.shade,q.shade,p.shade,p.shade,q.shade);
      }
    }
  }
  const oldGeo=new T.BufferGeometry();oldGeo.setAttribute('position',new T.Float32BufferAttribute(oldTracks,3));oldGeo.setAttribute('ink',new T.Float32BufferAttribute(oldInk,1));
  const oldRubber=new T.Mesh(oldGeo,new T.ShaderMaterial({transparent:true,depthWrite:false,side:T.DoubleSide,
    vertexShader:`attribute float ink; varying float shade; void main(){shade=ink;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`varying float shade; void main(){gl_FragColor=vec4(.12,.13,.135,shade);}`,
  }));oldRubber.renderOrder=1;scene.add(oldRubber);

  const ridgeTones=[0xa6bdc6,0x91adbc,0x819faa];
  for(let ring=0;ring<3;ring++) {
    const pts:number[]=[], colors:number[]=[], count=44, radius=(265-ring*39)*S;
    const hill=(angle:number)=>[Math.sin(angle)*radius, S*(8+Math.pow(Math.max(0,.68+.26*Math.sin(angle*3+ring)+.34*Math.cos(angle*7+ring*1.5)),1.47)*
      (ring===0?55:ring===1?45:29)+random()*7),Math.cos(angle)*radius+23*S];
    const tone=new T.Color(ridgeTones[ring]);
    const row=Array.from({length:count},(_,i)=>hill(i/count*Math.PI*2));
    for(let i=0;i<count;i++) {
      const p=row[i],q=row[(i+1)%count],a=[p[0]*.89,-.08,p[2]*.89],b=[q[0]*.89,-.08,q[2]*.89];
      const ledge=[(p[0]*.36+q[0]*.64)*.91,(p[1]+q[1])*.145,(p[2]*.36+q[2]*.64)*.91];
      pts.push(...a,...p,...ledge,...p,...q,...ledge,...ledge,...q,...b,...a,...ledge,...b);
      for(const scale of [.95,1.035,.89,.92]) {
        const color=tone.clone().multiplyScalar(scale+.066*random());
        for(let k=0;k<3;k++) colors.push(color.r,color.g,color.b);
      }
    }
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pts,3));
    geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));
    scene.add(new T.Mesh(geo,new T.MeshBasicMaterial({ vertexColors:true,side:T.DoubleSide,toneMapped:false,fog:false })));
  }

  const prop=new T.Object3D(), colour=new T.Color();
  type Tree = { x:number; z:number; h:number; w:number; yaw:number; hue:number };
  const trees:Tree[]=[];
  const sightX=origin.x-origin.tx*11, sightZ=origin.z-origin.tz*11, boardX=bannerAt.x-sightX, boardZ=bannerAt.z-sightZ;
  function pine(x:number,z:number,h:number) {
    const style={w:.76+random()*.47,yaw:random()*Math.PI,hue:Math.floor(random()*8)};
    const depth=((x-sightX)*boardX+(z-sightZ)*boardZ)/(boardX**2+boardZ**2);
    if(depth>.67&&depth<1.17&&Math.hypot(x-sightX-boardX*depth,z-sightZ-boardZ*depth)<3.65) return;
    trees.push({x,z,h,...style});
  }
  for(const side of [-1,1]) for(let i=0;i<segments;i+=11) {
    const p=frames[(i+Math.floor(random()*8))%segments], offset=side*(barrier+.85+random()*6.5);
    pine(p.x+p.tz*offset,p.z-p.tx*offset,4.5+random()*6.1);
    if(i%22===0) {
      const width=offset+side*(5.2+random()*7.7);
      pine(p.x+p.tz*width-p.tx*2.7,p.z-p.tx*width-p.tz*2.7,4.8+random()*4.5);
    }
  }
  for(let i=0;i<Math.round(490*S);i++) {
    const x=(random()-.5)*355*S,z=(random()-.48)*350*S;
    let free=true;
    for(let j=0;j<segments;j+=4) {
      const p=frames[j];
      if((x-p.x)**2+(z-p.z)**2<(barrier+4.95)**2) {free=false;break;}
    }
    if(free) pine(x,z,3.2+random()*7.2);
  }
  const bark=standard(0xffffff), needles=standard(0xffffff);
  const trunks=new T.InstancedMesh(new T.CylinderGeometry(.51,1,1,5),bark,trees.length);
  const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=64;
  const shadowInk=shadowCanvas.getContext('2d')!;
  const contactShade=shadowInk.createRadialGradient(32,32,1,32,32,31);
  contactShade.addColorStop(0,'#142f1869');contactShade.addColorStop(.57,'#1a382333');contactShade.addColorStop(1,'#162d1700');
  shadowInk.fillStyle=contactShade;shadowInk.fillRect(0,0,64,64);
  const treeShadowMap=new T.CanvasTexture(shadowCanvas);treeShadowMap.colorSpace=T.SRGBColorSpace;
  const shadowGeo=new T.PlaneGeometry(1,1);shadowGeo.rotateX(-Math.PI/2);
  const treeContact=new T.InstancedMesh(shadowGeo,new T.MeshBasicMaterial({map:treeShadowMap,transparent:true,depthWrite:false,opacity:.74}),trees.length);
  const longCanvas=document.createElement('canvas');longCanvas.width=128;longCanvas.height=64;
  const longInk=longCanvas.getContext('2d')!;
  const longFade=longInk.createLinearGradient(13,0,126,0);longFade.addColorStop(0,'#17283a9f');longFade.addColorStop(.59,'#172c37ad');longFade.addColorStop(1,'#172e3300');
  longInk.fillStyle=longFade;longInk.filter='blur(2px)';longInk.beginPath();
  for(const [i,p] of [[9,31],[40,25],[43,11],[71,22],[73,15],[96,27],[119,32],[96,39],[74,49],[71,42],[44,53],[40,36]].entries()) {
    if(i===0) longInk.moveTo(p[0],p[1]); else longInk.lineTo(p[0],p[1]);
  }
  longInk.closePath();longInk.fill();
  const longMap=new T.CanvasTexture(longCanvas);longMap.colorSpace=T.SRGBColorSpace;
  const pineShadows=new T.InstancedMesh(shadowGeo,new T.MeshBasicMaterial({map:longMap,transparent:true,depthWrite:false,opacity:.52}),trees.length);
  const pineColors=[0x236651,0x39845e,0x537f44,0x638a47,0x287759,0x437f58,0x789f4a,0x286c55];
  const crowns=[new T.InstancedMesh(new T.CylinderGeometry(.095,1,1,7,1),needles,trees.length),
    new T.InstancedMesh(new T.CylinderGeometry(.064,1,1,6,1),needles,trees.length),
    new T.InstancedMesh(new T.ConeGeometry(1,1,6),needles,trees.length)];
  for(const [i,{x,z,h,w,yaw,hue}] of trees.entries()) {
    prop.position.set(x+.10*h,-.064,z-.095*h);prop.scale.set(h*.51,1,h*.64);prop.rotation.set(0,-.42,0);prop.updateMatrix();
    treeContact.setMatrixAt(i,prop.matrix);
    prop.position.set(x+h*.45,.004,z-h*.30);prop.scale.set(h*1.32,1,h*.58);prop.rotation.set(0,.59,0);prop.updateMatrix();
    pineShadows.setMatrixAt(i,prop.matrix);
    prop.position.set(x,h*.188-.03,z);prop.scale.set(h*.031,h*.40,h*.029);prop.rotation.set(0,yaw,0);prop.updateMatrix();
    trunks.setMatrixAt(i,prop.matrix);trunks.setColorAt(i,colour.setHex(i%2?0xaf8059:0x947057));
    for(let j=0;j<3;j++) {
      const r=h*[.216,.171,.116][j]*w;
      prop.position.set(x+.055*j,h*[.442,.625,.800][j],z-.021*j);
      prop.scale.set(r,h*[.403,.394,.394][j],r*w*.92);
      prop.rotation.set(.014*Math.sin(i),yaw+j*.471,.016*Math.cos(i));prop.updateMatrix();
      const mesh=crowns[j]; mesh.setMatrixAt(i,prop.matrix);
      mesh.setColorAt(i,colour.setHex(pineColors[hue]).multiplyScalar(.90+.075*j+.15*random()));
    }
  }
  for(const item of [treeContact,pineShadows,trunks,...crowns]) {item.instanceMatrix.needsUpdate=true; if(item.instanceColor)item.instanceColor.needsUpdate=true; scene.add(item);}
  trunks.name='Instanced cedar trunks'; crowns[0].name='Instanced low-poly conifers';

  const bushCount=Math.round(312*S), rockCount=Math.round(104*S);
  const undergrowth=new T.InstancedMesh(new T.IcosahedronGeometry(1,0),standard(0xffffff),bushCount);
  const groundRocks=new T.InstancedMesh(new T.IcosahedronGeometry(1,0),standard(0xffffff),rockCount);
  for(let i=0;i<bushCount;i++) {
    const p=frames[(i*37)%segments], side=i%2?1:-1, offset=side*(barrier+.7+random()*12.8), h=.16+random()**2*.78;
    prop.position.set(p.x+p.tz*offset,h*.40-.07,p.z-p.tx*offset);prop.rotation.set(.1,random()*4,.1);
    prop.scale.set(h*1.25,h*.72,h*.95);prop.updateMatrix();undergrowth.setMatrixAt(i,prop.matrix);
    undergrowth.setColorAt(i,colour.setHex([0x718b40,0x426947,0x819b4c,0x5c7b42][i%4]));
    if(i<rockCount) {
      const w=.23+random()**2*.96, off=side*(barrier+.65+random()*4);
      prop.position.set(p.x+p.tz*off+(random()-.5),w*.36-.07,p.z-p.tx*off);prop.scale.set(w*1.2,w*.62,w*.82);prop.updateMatrix();
      groundRocks.setMatrixAt(i,prop.matrix);groundRocks.setColorAt(i,colour.setHex(i%3?0xa39a82:0x828d7e));
    }
  }
  scene.add(undergrowth,groundRocks);

  const cloudShape=new T.IcosahedronGeometry(1,1), clouds=standard(0xf1f0e6,{roughness:1,fog:false,emissive:0xc8d3dc,emissiveIntensity:.30});
  const cloudPuffs=new T.InstancedMesh(cloudShape,clouds,48);
  for(let i=0;i<48;i++) {
    const group=Math.floor(i/8), a=group*1.06+.20,j=i%8, peak=Math.sin((j+.5)/8*Math.PI);
    prop.position.set((Math.sin(a)*190+(j-3.5)*6.2)*S,(34+group%3*9+peak*3.5+random()*3)*S,(Math.cos(a)*175+20+random()*8)*S);
    prop.scale.set((8.4+random()*6.1)*S,(2.1+peak*5.1+random()*1.5)*S,(5+random()*5.5)*S); prop.rotation.set(.11,random()*2,0);prop.updateMatrix();cloudPuffs.setMatrixAt(i,prop.matrix);
  }
  scene.add(cloudPuffs);

  const signCanvas=document.createElement('canvas');signCanvas.width=512;signCanvas.height=128;
  const signInk=signCanvas.getContext('2d')!;
  signInk.fillStyle='#252927';signInk.fillRect(0,0,512,128);
  signInk.fillStyle='#f6c165';signInk.fillRect(6,6,500,116);
  signInk.fillStyle='#252621';
  for(let x=42;x<460;x+=106) {
    signInk.beginPath(); signInk.moveTo(x,19);signInk.lineTo(x+33,19);signInk.lineTo(x+69,64);signInk.lineTo(x+33,109);
    signInk.lineTo(x,109);signInk.lineTo(x+34,64);signInk.closePath();signInk.fill();
  }
  const signMap=new T.CanvasTexture(signCanvas); signMap.colorSpace=T.SRGBColorSpace;
  const leftMap=signMap.clone();leftMap.repeat.x=-1;leftMap.offset.x=1;leftMap.needsUpdate=true;
  const signFace=standard(0xffffff,{map:signMap,roughness:.74,emissive:0x584625,emissiveIntensity:.12});
  const leftFace=signFace.clone();leftFace.map=leftMap;
  const pole=standard(0xadb3ae,{metalness:.10}), plate=standard(0x4f565a), lamp=standard(0xdcddcb,{emissive:0xeee3af,emissiveIntensity:.14});
  function part(parent:Three.Object3D,geometry:Three.BufferGeometry,mat:Three.Material,x:number,y:number,z:number) {
    const obj=new T.Mesh(geometry,mat);obj.position.set(x,y,z);parent.add(obj);return obj;
  }
  const tallTube=new T.CylinderGeometry(.044,.072,5.35,7), lampCase=new T.BoxGeometry(.49,.25,.31), lampLens=new T.BoxGeometry(.387,.158,.035);
  for(const [i,s] of [start+12,start+35,start+49,109*S,168*S,234*S,298*S,362*S].entries()) {
    const f=at(s,{...movingFrame}), side=i<2?(i===0?1:-1):i%2===0?1:-1, u=side*(barrier+1.17);
    const stand=new T.Group();stand.position.set(f.x+f.tz*u,-.05,f.z-f.tx*u);stand.rotation.y=Math.atan2(f.tx,f.tz)+Math.PI*.81;scene.add(stand);
    part(stand,tallTube,pole,0,2.67,0);
    part(stand,new T.BoxGeometry(1.04,.064,.066),pole,0,5.1,0);
    for(const x of [-.293,.293]) {
      part(stand,lampCase,plate,x,5.14,0).rotation.x=.29;
      part(stand,lampLens,lamp,x,5.18,.15).rotation.x=.29;
    }
  }
  const signBack=new T.BoxGeometry(3.1,.72,.048), signFront=new T.PlaneGeometry(3.03,.681), signPole=new T.BoxGeometry(.056,1.6,.062);
  const posts=zones.flatMap((zone,i)=>(i<2?[zone.start+8,zone.start+18]:[zone.start+8]).map(d=>({distance:d,side:zone.side})));
  for(const {distance,side} of posts) {
    const f=at(start+distance,{...movingFrame}), d=side*(barrier+.83), p=new T.Group();
    p.position.set(f.x+f.tz*d,0,f.z-f.tx*d);p.rotation.y=Math.atan2(-f.tx,-f.tz)+.18*Math.sign(d);scene.add(p);
    part(p,signBack,plate,0,1.48,0);part(p,signFront,side>0?signFace:leftFace,0,1.48,.028);
    for(const x of [-.97,.97])part(p,signPole,pole,x,.80,-.040);
  }

  const banner=document.createElement('canvas');banner.width=768;banner.height=240;
  const paint=banner.getContext('2d')!;
  paint.fillStyle='#1e2526';paint.fillRect(0,0,768,240);
  paint.fillStyle='#eaae60';paint.fillRect(0,0,13,240);paint.fillRect(0,228,768,12);
  paint.fillStyle='#ffbd6f';paint.font='bold 25px monospace';paint.fillText('PRODRIFT   /   01',45,62);
  paint.fillStyle='#fff5dc';paint.font='bold 81px sans-serif';paint.fillText('SIRKUIT PINUS',43,158);
  paint.fillStyle='#a7aba3';paint.font='bold 22px monospace';paint.fillText('DRIFT COURSE',46,202);
  const bannerMap=new T.CanvasTexture(banner);bannerMap.colorSpace=T.SRGBColorSpace;
  const board=new T.Group();
  board.position.set(bannerAt.x,0,bannerAt.z);board.rotation.y=Math.atan2(-bannerFrame.tx,-bannerFrame.tz)+.14;scene.add(board);
  part(board,new T.BoxGeometry(5.05,1.57,.097),plate,0,2.14,0);
  part(board,new T.PlaneGeometry(5,1.53),new T.MeshBasicMaterial({map:bannerMap,toneMapped:false}),0,2.14,.052);
  for(const d of [-1.87,1.87]) part(board,new T.BoxGeometry(.088,2.18,.082),pole,d,1.08,-.115);

  scene.updateMatrixWorld(true);
  scene.traverse(object=>{if(object!==scene){object.matrixAutoUpdate=false;object.matrixWorldAutoUpdate=false;}});
  return Object.assign(track.createRun(),{scene,route,startMarker,length,zones,track,lighting,botTrack});
}