import type * as Three from 'three';
import { createDriftScore } from './drift-score.js';
import { createDriftCar as createRmxCar } from './rmx-drift-adapter';
import { toKmh } from './speed-cues.js';
import type { DriftZone, RunMode, Telemetry } from './rally-course';
import { buildTrack } from '../../haruna-downhill/game/trackLayout';
import {
  OX,
  OZ,
  RoadField,
  baseHeight,
  buildFarTerrain,
  buildLake,
  buildNearTerrain,
  type NearBounds,
  type Platform,
} from '../../haruna-downhill/game/terrain';
import { buildRoad, roadFrame } from '../../haruna-downhill/game/roadMesh';
import { buildScenery } from '../../haruna-downhill/game/scenery';
import { Petals } from '../../haruna-downhill/game/effects';
import { createDriveLighting } from './drive-lighting';

const DRIFT_SIM_SCORE_RULES = {
  minAngle: (12 * Math.PI) / 180,
  comboAngle: 0.175,
  maxAngle: (115 * Math.PI) / 180,
  spinAngle: (118 * Math.PI) / 180,
  minSlip: -1,
};

const HARUNA_ASPHALT_HALF = 4.6;
const HARUNA_BARRIER = 5.15;

const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export function createHarunaRallyCourse(T: typeof Three, _renderer?: Three.WebGLRenderer) {
  const scene = new T.Scene();
  // Default drive lighting = hemisphere/directional rig from the three.js lighting example.
  // Fully adjustable 0–100% from the PENCAHAYAAN panel group (affects both courses).
  const lighting = createDriveLighting(T, scene, { radius: 8200, fogNear: 1600, fogFar: 9200 });

  const track = buildTrack(baseHeight, OX, OZ);
  // Dense sampler for the 5 rival AI bots (position, heading and curvature at any arc length)
  const botTrack={
    length: track.length, loop:false,
    at(s:number) {
      const clamped=T.MathUtils.clamp(s,0,track.length-track.ds-1e-4);
      const i=Math.floor(clamped/track.ds), f=(clamped-i*track.ds)/track.ds;
      const psi=track.psi[i]+(track.psi[i+1]-track.psi[i])*f;
      return {
        x: track.x[i]+(track.x[i+1]-track.x[i])*f,
        y: track.y[i]+(track.y[i+1]-track.y[i])*f,
        z: track.z[i]+(track.z[i+1]-track.z[i])*f,
        tx: Math.sin(psi), tz: Math.cos(psi), curv: track.kappa[i],
      };
    },
  };
  const sF = Math.floor(track.startS);
  const lotC = roadFrame(track, sF - 36, 31);
  const startLot: Platform = { x: lotC.x, z: lotC.z, r: 22, y: track.y[sF - 36] };
  const endI = track.n - 1;
  const endF = roadFrame(track, endI, 0);
  const finishPlaza: Platform = {
    x: endF.x + endF.f.x * 44,
    z: endF.z + endF.f.z * 44,
    r: 46,
    y: track.y[endI] - 0.2,
  };
  const field = new RoadField(track, [startLot, finishPlaza], 3);

  let minX = 1e9;
  let maxX = -1e9;
  let minZ = 1e9;
  let maxZ = -1e9;
  for (let i = 0; i < track.n; i++) {
    minX = Math.min(minX, track.x[i]);
    maxX = Math.max(maxX, track.x[i]);
    minZ = Math.min(minZ, track.z[i]);
    maxZ = Math.max(maxZ, track.z[i]);
  }
  const g = 4;
  const margin = 185;
  const near: NearBounds = {
    x0: Math.floor((minX - margin) / g) * g,
    x1: Math.ceil((maxX + margin) / g) * g,
    z0: Math.floor((minZ - margin - 40) / g) * g,
    z1: Math.ceil((maxZ + margin + 60) / g) * g,
  };

  scene.add(buildNearTerrain(field, near, g));
  scene.add(buildFarTerrain(near));
  scene.add(buildLake());
  const road = buildRoad(track, field);

  // Replace Mt. Haruna's flat-shaded, jittered 2m asphalt strips with a Sirkuit-Pinus-grade
  // smooth-shaded, grit-textured 1m asphalt ribbon so low rally cameras see zero stair/rib artifacts.
  {
    const oldAsphalt = road.group.children[0] as Three.Mesh | undefined;
    if (oldAsphalt) {
      oldAsphalt.geometry.dispose();
      (oldAsphalt.material as Three.Material).dispose();
      road.group.remove(oldAsphalt);
    }

    let gSeed = 77423;
    const gRand = () => {
      gSeed = (gSeed * 1664525 + 1013904223) >>> 0;
      return gSeed / 4294967296;
    };
    const gritCanvas = document.createElement('canvas');
    gritCanvas.width = gritCanvas.height = 128;
    const gritCtx = gritCanvas.getContext('2d')!;
    const grain = gritCtx.createImageData(128, 128);
    for (let i = 0; i < grain.data.length; i += 4) {
      const v = 212 + gRand() * 43;
      grain.data[i] = grain.data[i + 1] = grain.data[i + 2] = v;
      grain.data[i + 3] = 255;
    }
    gritCtx.putImageData(grain, 0, 0);
    const gritTex = new T.CanvasTexture(gritCanvas);
    gritTex.colorSpace = T.SRGBColorSpace;
    gritTex.wrapS = gritTex.wrapT = T.RepeatWrapping;
    gritTex.anisotropy = 4;

    const aLat = [-4.6, -4.25, -1.95, -0.85, 0, 0.85, 1.95, 4.25, 4.6];
    const aDy = [0.015, 0.025, 0.055, 0.065, 0.066, 0.065, 0.055, 0.025, 0.015];
    const cAsphalt = new T.Color(0x4b5158);
    const cWear = new T.Color(0x3f454c);
    const cTar = new T.Color(0x555b62);
    const tmpCol = new T.Color();

    const cols = aLat.length;
    const rows = track.n;
    const posArr = new Float32Array(rows * cols * 3);
    const colArr = new Float32Array(rows * cols * 3);
    const uvArr = new Float32Array(rows * cols * 2);
    const idxArr: number[] = [];

    for (let i = 0; i < rows; i++) {
      const ps = track.psi[i];
      const cs = Math.cos(ps);
      const sn = Math.sin(ps);
      const wave = 0.5 + 0.5 * Math.sin(i * 0.065);
      for (let j = 0; j < cols; j++) {
        const lat = aLat[j];
        const vIdx = i * cols + j;
        posArr[vIdx * 3] = track.x[i] + lat * cs;
        posArr[vIdx * 3 + 1] = track.y[i] + aDy[j];
        posArr[vIdx * 3 + 2] = track.z[i] - lat * sn;

        const aL = Math.abs(lat);
        tmpCol.copy(cAsphalt).lerp(cTar, wave * 0.28);
        if (aL > 0.8 && aL < 2.15) tmpCol.lerp(cWear, 0.35);
        else if (aL > 4.0) tmpCol.lerp(cTar, 0.35);
        colArr[vIdx * 3] = tmpCol.r;
        colArr[vIdx * 3 + 1] = tmpCol.g;
        colArr[vIdx * 3 + 2] = tmpCol.b;

        uvArr[vIdx * 2] = lat * 0.45;
        uvArr[vIdx * 2 + 1] = i * 0.24;
      }
      if (i + 1 < rows) {
        for (let j = 0; j < cols - 1; j++) {
          const a = i * cols + j;
          const b = (i + 1) * cols + j;
          const c = (i + 1) * cols + (j + 1);
          const d = i * cols + (j + 1);
          idxArr.push(a, b, c, a, c, d);
        }
      }
    }

    const smoothGeo = new T.BufferGeometry();
    smoothGeo.setAttribute('position', new T.BufferAttribute(posArr, 3));
    smoothGeo.setAttribute('color', new T.BufferAttribute(colArr, 3));
    smoothGeo.setAttribute('uv', new T.BufferAttribute(uvArr, 2));
    smoothGeo.setIndex(idxArr);
    smoothGeo.computeVertexNormals();

    const smoothMat = new T.MeshStandardMaterial({
      vertexColors: true,
      map: gritTex,
      roughness: 0.92,
      metalness: 0.02,
      side: T.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    const smoothAsphalt = new T.Mesh(smoothGeo, smoothMat);
    smoothAsphalt.name = 'Haruna smooth asphalt';
    road.group.add(smoothAsphalt);
  }

  scene.add(road.group);
  const scenery = buildScenery({ field, track, road, near, startLot, finishPlaza });
  scene.add(scenery.group);
  const petals = new Petals(scene);

  // Minimap SVG inside viewBox="15 8 70 85" (safe box x:[20..80], y:[12..88])
  const rangeX = Math.max(1, maxX - minX);
  const rangeZ = Math.max(1, maxZ - minZ);
  const mapScale = Math.min(58 / rangeX, 74 / rangeZ);
  const mapOffX = (100 - rangeX * mapScale) * 0.5;
  const mapOffY = 88 - (74 - rangeZ * mapScale) * 0.5;
  const toMapX = (x: number) => 100 - mapOffX - (x - minX) * mapScale;
  const toMapY = (z: number) => mapOffY - (z - minZ) * mapScale;

  const startIdx = Math.floor(track.startS);
  const finishIdx = Math.floor(track.finishS);
  const routePts: string[] = [];
  for (let i = startIdx; i <= finishIdx; i += 14) {
    routePts.push(`${toMapX(track.x[i]).toFixed(2)},${toMapY(track.z[i]).toFixed(2)}`);
  }
  routePts.push(`${toMapX(track.x[finishIdx]).toFixed(2)},${toMapY(track.z[finishIdx]).toFixed(2)}`);
  const route = `M${routePts.join(' ')}`;
  const startMarker = { x: toMapX(track.x[startIdx]), y: toMapY(track.z[startIdx]) };
  const length = Math.max(100, track.finishS - track.startS);

  // Drift outer zones along Haruna corners
  const zones: DriftZone[] = [];
  let zoneStart = -1;
  let zoneSide = 0;
  for (let i = startIdx + 20; i <= finishIdx - 20; i += 2) {
    const k = track.kappa[i];
    const side = Math.abs(k) > 1 / 125 ? -Math.sign(k) : 0; // left bend (k>0) -> outer is right (-1)
    if (side === zoneSide) continue;
    if (zoneSide !== 0 && zoneStart >= 0 && i - zoneStart >= 22) {
      const pts: string[] = [];
      for (let j = zoneStart; j <= i; j += 4) {
        pts.push(`${toMapX(track.x[j]).toFixed(2)},${toMapY(track.z[j]).toFixed(2)}`);
      }
      zones.push({
        start: zoneStart - track.startS,
        end: i - track.startS,
        side: zoneSide,
        path: `M${pts.join(' ')}`,
      });
    }
    zoneSide = side;
    zoneStart = i;
  }

  // Track spatial query helper (clamped open-course)
  const n = track.n;
  function closestIdx(wx: number, wz: number, around: number, look: number) {
    let bestI = clamp(around, 0, n - 1);
    let bestD = Infinity;
    const lo = Math.max(0, bestI - look);
    const hi = Math.min(n - 1, bestI + look);
    for (let i = lo; i <= hi; i++) {
      const dx = wx - track.x[i];
      const dz = wz - track.z[i];
      const d = dx * dx + dz * dz;
      if (d < bestD) {
        bestD = d;
        bestI = i;
      }
    }
    if (bestD > 1600) {
      for (let i = 0; i < n; i += 8) {
        const dx = wx - track.x[i];
        const dz = wz - track.z[i];
        const d = dx * dx + dz * dz;
        if (d < bestD) {
          bestD = d;
          bestI = i;
        }
      }
      const lo2 = Math.max(0, bestI - 10);
      const hi2 = Math.min(n - 1, bestI + 10);
      for (let i = lo2; i <= hi2; i++) {
        const dx = wx - track.x[i];
        const dz = wz - track.z[i];
        const d = dx * dx + dz * dz;
        if (d < bestD) {
          bestD = d;
          bestI = i;
        }
      }
    }
    return bestI;
  }

  let surfHint = startIdx;
  function sampleAt(wx: number, wz: number, hint?: number) {
    const nearI = closestIdx(wx, wz, hint ?? surfHint, 18);
    if (hint === undefined) surfHint = nearI;
    let i0 = clamp(nearI, 0, n - 2);
    let sx = track.x[i0 + 1] - track.x[i0];
    let sz = track.z[i0 + 1] - track.z[i0];
    let sl2 = sx * sx + sz * sz || 1;
    let proj = ((wx - track.x[i0]) * sx + (wz - track.z[i0]) * sz) / sl2;
    if (proj < 0 && i0 > 0) {
      i0 -= 1;
      sx = track.x[i0 + 1] - track.x[i0];
      sz = track.z[i0 + 1] - track.z[i0];
      sl2 = sx * sx + sz * sz || 1;
      proj = ((wx - track.x[i0]) * sx + (wz - track.z[i0]) * sz) / sl2;
    } else if (proj > 1 && i0 < n - 2) {
      i0 += 1;
      sx = track.x[i0 + 1] - track.x[i0];
      sz = track.z[i0 + 1] - track.z[i0];
      sl2 = sx * sx + sz * sz || 1;
      proj = ((wx - track.x[i0]) * sx + (wz - track.z[i0]) * sz) / sl2;
    }
    proj = clamp(proj, 0, 1);
    const i1 = i0 + 1;
    const cx = track.x[i0] + sx * proj;
    const cz = track.z[i0] + sz * proj;
    const cy = track.y[i0] + (track.y[i1] - track.y[i0]) * proj;
    const dPsi = Math.atan2(Math.sin(track.psi[i1] - track.psi[i0]), Math.cos(track.psi[i1] - track.psi[i0]));
    const psi = track.psi[i0] + dPsi * proj;
    const tx = Math.sin(psi);
    const tz = Math.cos(psi);
    const lx = tz; // cos(psi)
    const lz = -tx; // -sin(psi)
    const lane = (wx - cx) * lx + (wz - cz) * lz;
    const s = i0 + proj;
    return { i: nearI, s, cx, cy, cz, tx, tz, lx, lz, lane };
  }

  function surfaceHeight(wx: number, wz: number, hint?: number) {
    const q = sampleAt(wx, wz, hint);
    const aLane = Math.abs(q.lane);
    let dy = 0.015;
    if (aLane <= HARUNA_ASPHALT_HALF) {
      dy = 0.015 + 0.05 * (1 - Math.pow(Math.min(1, aLane / HARUNA_ASPHALT_HALF), 1.5));
    } else if (aLane <= 5.6) {
      dy = lerp(0.015, -0.02, clamp((aLane - HARUNA_ASPHALT_HALF) / 1.0, 0, 1));
    }
    return { y: q.cy + dy, ...q };
  }

  function heightAt(wx: number, wz: number) {
    return surfaceHeight(wx, wz).y;
  }

  function slopeAt(wx: number, wz: number, yaw: number) {
    const center = surfaceHeight(wx, wz);
    const sinY = Math.sin(yaw);
    const cosY = Math.cos(yaw);
    const yFwd = surfaceHeight(wx + sinY * 2.6, wz + cosY * 2.6, center.i).y;
    const yBack = surfaceHeight(wx - sinY * 2.6, wz - cosY * 2.6, center.i).y;
    const yLeft = surfaceHeight(wx + cosY * 1.4, wz - sinY * 1.4, center.i).y;
    const yRight = surfaceHeight(wx - cosY * 1.4, wz + sinY * 1.4, center.i).y;
    const gradFwd = clamp((yFwd - yBack) / 5.2, -0.32, 0.32);
    const gradLeft = clamp((yLeft - yRight) / 2.8, -0.22, 0.22);
    return {
      y: center.y,
      pitch: -Math.atan(gradFwd),
      roll: Math.atan(gradLeft) * 0.55,
    };
  }

  // Create player run API (1:1 interface with rally-course.ts)
  let colHint = startIdx;
  const laneAt = (wx: number, wz: number) => {
    const q = sampleAt(wx, wz, colHint);
    colHint = q.i;
    return { off: q.lane, nx: q.lx, nz: q.lz };
  };

  let nearest = startIdx;
  let trackYaw = track.psi[startIdx];
  let strike = 0;
  let lane = 0;

  const drive = createRmxCar(
    (wx, wz) => {
      const sh = surfaceHeight(wx, wz, nearest);
      const off = Math.abs(sh.lane);
      const isShoulder = off >= HARUNA_ASPHALT_HALF;
      return {
        grip: 1,
        roughness: isShoulder ? 0.18 : 0,
        height: isShoulder ? -0.008 : 0,
        worldY: sh.y,
      };
    },
    {
      isolated: false,
      touge: true,
      barrier: { halfWidth: HARUNA_BARRIER, laneAt, carRadius: 1.15 },
    },
  );

  const state = drive.state;
  const score = createDriftScore(DRIFT_SIM_SCORE_RULES);
  const cue = 1;
  const thr = 1;

  let elapsed = 0;
  let lap = 1;
  let best: number | null = null;
  let last: number | null = null;
  let started = false;
  let travel = 0;
  let highwater = 0;
  let mode: RunMode = 'attack';
  let finished = false;
  let scoringZone = -1;
  let totalVisualTime = 0;

  function reset(next: RunMode = mode) {
    const sx = track.x[startIdx];
    const sz = track.z[startIdx];
    const syaw = track.psi[startIdx];
    drive.reset(sx, sz, syaw);
    nearest = colHint = surfHint = startIdx;
    trackYaw = syaw;
    strike = lane = 0;
    elapsed = travel = highwater = 0;
    lap = 1;
    started = finished = false;
    mode = next;
    scoringZone = -1;
    score.reset();
    // Initialize wheel worldY at spawn
    for (const w of Object.values(state.wheels)) {
      w.worldY = heightAt(w.x, w.z);
    }
  }

  function step(dt: number, input: Parameters<typeof drive.step>[1]) {
    if (finished) return;
    drive.step(dt, input);

    const q = sampleAt(state.x, state.z, nearest);
    nearest = q.i;
    lane = q.lane;
    trackYaw = track.psi[nearest];

    // Soft rear boundary behind start gate so driver cannot reverse off the mountain edge
    if (q.s < track.startS - 18) {
      const back = track.startS - 18 - q.s;
      state.x += q.tx * back;
      state.z += q.tz * back;
      const vn = state.vx * q.tx + state.vz * q.tz;
      if (vn < 0) {
        state.vx -= q.tx * vn * 1.25;
        state.vz -= q.tz * vn * 1.25;
      }
      drive.refresh();
    }

    strike = Math.max(0, strike - dt * 9);
    if (drive.lastImpact > 0) {
      strike = Math.max(strike, drive.lastImpact * (1.45 / 4.5));
    }

    const sRel = Math.max(0, q.s - track.startS);
    travel = sRel;
    highwater = Math.max(highwater, travel);
    if (state.speed > 0.28) started = true;
    if (started) elapsed += dt;

    const zoneIndex = zones.findIndex((item) => sRel >= item.start && sRel < item.end);
    const outer = zones[zoneIndex];
    const alignment = state.vx * q.tx + state.vz * q.tz;
    const backwards = state.gear === 'R' || travel < highwater - 12;
    score.step(dt, {
      speed: state.speed / thr,
      beta: state.beta,
      forward: state.forwardSpeed / thr,
      along: backwards ? 0 : alignment / thr,
      pointsAlong: backwards ? 0 : alignment / cue,
      slip: state.rearSlip,
      roughness: state.roughness,
      impact: strike,
      linking: state.driftPhase === 'link',
      outside: !!outer && lane * outer.side > 2.2 && Math.sign(state.beta) === outer.side && Math.abs(lane) < HARUNA_ASPHALT_HALF,
    });
    scoringZone = score.inBonus ? zoneIndex : -1;

    if (q.s >= track.finishS) {
      last = elapsed;
      best = best === null ? elapsed : Math.min(last, best);
      if (mode === 'attack') {
        score.finish();
        finished = true;
      } else {
        lap++;
        elapsed = 0;
        const sx = track.x[startIdx];
        const sz = track.z[startIdx];
        drive.reset(sx, sz, track.psi[startIdx]);
        nearest = colHint = surfHint = startIdx;
        travel = highwater = 0;
      }
    }
  }

  const snapshot = (): Telemetry => ({
    lap,
    time: elapsed,
    best,
    last,
    speed: toKmh(state.rcSpeed ?? state.speed),
    gear: state.gear,
    rev: state.rev,
    shifting: state.shifting,
    coasting: state.coasting,
    throttle: state.throttle,
    mapX: toMapX(state.x),
    mapY: toMapY(state.z),
    heading: state.yaw,
    distance: clamp(highwater, 0, length),
    driftAngle: Math.round(T.MathUtils.radToDeg(Math.abs(state.beta))),
    controlPhase: state.driftPhase,
    drift: score.snapshot(),
    mode,
    finished,
  });

  function tickVisuals(dt: number, carPos: Three.Vector3, camPos: Three.Vector3, viewHeightPx = 720) {
    totalVisualTime += dt;
    petals.setScale(viewHeightPx);
    petals.update(dt, camPos, totalVisualTime, 1);
  }

  reset();

  return {
    courseId: 'haruna' as const,
    courseName: 'MT. HARUNA',
    scene,
    route,
    startMarker,
    length,
    zones,
    track: null,
    state,
    step,
    reset,
    snapshot,
    setFeintMode: (enabled: boolean) => drive.setFeintMode(enabled),
    heightAt,
    slopeAt,
    tickVisuals,
    get time() {
      return elapsed;
    },
    get lap() {
      return lap;
    },
    get heading() {
      return trackYaw;
    },
    get impact() {
      return strike;
    },
    get finished() {
      return finished;
    },
    get progress() {
      return travel;
    },
    lighting,
    botTrack,
    get lane() {
      return lane;
    },
    get scoringZone() {
      return scoringZone;
    },
  };
}
