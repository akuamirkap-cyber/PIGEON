import type * as Three from 'three';
import { createRallyCarModel } from './rally-model.js';
import { CAR_SCALE } from './rmx-drift-adapter';
import { defaultBuild } from './rally-config';
import type { RallyBuild } from './rally-config';

/**
 * 5 AI rivals for PRODRIFT's Rally Group B Lab.
 * Track positions are kinematic (follow the racing line, corner-speed limited by upcoming curvature,
 * light rubber-banding vs the player's lap distance) and the full Group B model is animated through
 * its own tick() for wheels, body roll and brake lights. Bots start behind the player, race to the
 * finish, and either loop the circuit or re-grid themselves automatically; a player restart (R)
 * resets the whole grid.
 */
export type BotTrackSample = { x: number; y: number; z: number; tx: number; tz: number; curv: number };
export type BotTrack = {
  length: number;
  /** loop = circuit, odometer wraps; otherwise point-to-point (bots re-grid at the finish) */
  loop: boolean;
  at(s: number): BotTrackSample;
};

export type BotGrid = {
  group: Three.Group;
  setTrack(next: BotTrack): void;
  update(dt: number, playerDistance: number, playerLane: number, active: boolean): void;
  /** Put every bot back on the start grid, behind the player's start line. */
  placeAtStart(): void;
  dispose(): void;
};

/** Five liveries clearly distinct from the player's usual build. */
const BOT_BUILDS: RallyBuild[] = [
  { ...defaultBuild, theme: 'blue', nose: 'evo', wing: 'works', vinyl: 'rally', skin: 'peach' },
  { ...defaultBuild, theme: 'green', nose: 'evo', wing: 'high', vinyl: 'rally', skin: 'asian' },
  { ...defaultBuild, theme: 'black', nose: 'classic', wing: 'high', vinyl: 'rally', skin: 'ethiopian' },
  { ...defaultBuild, theme: 'blue', nose: 'classic', wing: 'works', vinyl: 'heritage', skin: 'ethiopian' },
  { ...defaultBuild, theme: 'green', nose: 'evo', wing: 'works', vinyl: 'heritage', skin: 'peach' },
];
/** Grid slots behind the start line: two abreast, then a staggered single file. */
const GRID_SLOTS = [
  { back: 6.1, lane: -1.5 },
  { back: 6.1, lane: 1.5 },
  { back: 10.2, lane: -0.35 },
  { back: 14.6, lane: 1.8 },
  { back: 14.6, lane: -2.0 },
] as const;
/** Personal pace per bot so the field spreads out and they genuinely duel each other (and the player). */
const PACE = [1.0, 0.952, 1.046, 0.976, 1.02] as const;

export function createBotGrid(T: typeof Three, track: BotTrack): BotGrid {
  const group = new T.Group();
  group.name = 'Rival Bot Grid';

  const bots = BOT_BUILDS.map((build, index) => {
    const car = createRallyCarModel({ THREE: T, build, headlights: false });
    car.name = `Rival Bot ${index + 1}`;
    car.scale.setScalar(CAR_SCALE);
    car.rotation.order = 'YXZ';
    group.add(car);
    return {
      car,
      index,
      dist: -GRID_SLOTS[index].back,
      v: 0,
      lane: GRID_SLOTS[index].lane,
      phase: index * 2.13 + 0.7,
      steerVis: 0,
      betaVis: 0,
      prevV: 0,
      braking: false,
    };
  });

  let current = track;
  const clamp = T.MathUtils.clamp;
  const euclidModulo = T.MathUtils.euclideanModulo;

  function sampleWorld(s: number): BotTrackSample {
    if (current.loop) return current.at(euclidModulo(s, current.length));
    if (s < 0) { // before the start: extrapolate straight back from the line
      const p0 = current.at(0), back = -s;
      return { ...p0, x: p0.x - p0.tx * back, z: p0.z - p0.tz * back };
    }
    return current.at(clamp(s, 0, current.length - 1e-3));
  }
  function lapPosition(s: number): number {
    return current.loop ? euclidModulo(s, current.length) : clamp(s, 0, current.length - 1e-3);
  }

  function placeAtStart() {
    for (const bot of bots) {
      const slot = GRID_SLOTS[bot.index];
      bot.dist = -slot.back; bot.v = 0; bot.prevV = 0;
      bot.lane = slot.lane; bot.steerVis = 0; bot.betaVis = 0; bot.braking = false;
      poseCar(bot);
    }
  }

  function poseCar(bot: (typeof bots)[number]) {
    const s = lapPosition(bot.dist);
    const here = sampleWorld(s);
    const aheadS = lapPosition(bot.dist + 1.6), behindS = lapPosition(bot.dist - 1.6);
    const ahead = sampleWorld(aheadS), behind = sampleWorld(behindS);
    // right of the path: (tz, -tx) — same convention as the course's lane math
    const rx = here.tz, rz = -here.tx;
    const x = here.x + rx * bot.lane, z = here.z + rz * bot.lane;
    const rise = ahead.y - behind.y;
    const run = Math.hypot(ahead.x - behind.x, ahead.z - behind.z) || 1;
    bot.car.position.set(x, here.y, z);
    // Nose-up when climbing, nose-down downhill (matches model: +rotation.x drops the nose).
    bot.car.rotation.x = -Math.atan2(rise, run);
    bot.car.rotation.y = Math.atan2(here.tx, here.tz) + bot.betaVis * 0.55;
    bot.car.rotation.z = 0;
    bot.car.visible = true;
  }

  function botCurvatureAhead(s: number, from: number, to: number): number {
    let max = 0;
    for (let d = from; d < to; d += 3) max = Math.max(max, Math.abs(sampleWorld(lapPosition(s + d)).curv));
    return max;
  }

  function update(dt: number, playerDistance: number, playerLane: number, active: boolean) {
    if (!(dt > 0)) return;
    for (const bot of bots) {
      const sNow = lapPosition(bot.dist);
      // Corner speed from the sharpest upcoming bend (mirrors the Ghost AI's planning distance)
      const look = clamp(11 + bot.v * 0.36, 12, 34);
      const maxCurv = Math.max(botCurvatureAhead(bot.dist, 3, look), 0.0042);
      const cornerSpeed = clamp(Math.sqrt(30 / maxCurv), 19.5, 46);
      // Gentle rubber-band vs the human's lap (neutral pre-start / in ghost watch): trailing bots claw back, leaders back off
      const gapToPlayer = bot.dist - playerDistance;
      let rubber = 1;
      if (playerDistance > 1) {
        if (gapToPlayer < -55) rubber = 1.10; else if (gapToPlayer < -28) rubber = 1.05;
        else if (gapToPlayer > 60) rubber = 0.90; else if (gapToPlayer > 32) rubber = 0.96;
      }
      const target = active ? clamp(cornerSpeed * rubber * PACE[bot.index], 4, 46) : 0;
      if (target >= bot.v) bot.v = Math.min(target, bot.v + 11.4 * dt);
      else bot.v = Math.max(target, bot.v - 17.5 * dt);
      bot.braking = target < bot.v - 2.2;
      bot.dist += bot.v * dt;

      // Finished the point-to-point stage → automatically re-grid for the next run
      if (!current.loop && bot.dist >= current.length) {
        bot.dist = -GRID_SLOTS[bot.index].back; bot.v = 0; bot.prevV = 0; bot.lane = GRID_SLOTS[bot.index].lane;
        poseCar(bot);
        continue;
      }

      // Racing line: clip the inside of the upcoming bend + a light wander, and slip around the player
      const bendHere = sampleWorld(lapPosition(bot.dist + 5)).curv;
      let targetLane = -Math.sign(bendHere) * clamp(Math.abs(bendHere) * 125, 0, 1.85);
      targetLane += Math.sin(bot.phase + sNow * 0.018) * 0.42;
      const alongside = Math.abs(sNow - playerDistance) < 3.6;
      const sideGap = bot.lane - playerLane;
      if (alongside && Math.abs(sideGap) < 1.5) targetLane = clamp(bot.lane + (sideGap >= 0 ? 1.2 : -1.2), -4.3, 4.3);
      bot.lane += (clamp(targetLane, -4.3, 4.3) - bot.lane) * (1 - Math.exp(-dt * 2.1));

      // Visual drift attitude & steer (cosmetic only)
      const steer = clamp(bendHere * 36 + (targetLane - bot.lane) * 0.24, -1, 1);
      const beta = Math.abs(bot.v) > 16 ? clamp(bot.v * bot.v * bendHere * 0.0034, -0.4, 0.4) : 0;
      bot.steerVis += (steer - bot.steerVis) * (1 - Math.exp(-dt * 8.5));
      bot.betaVis += (beta - bot.betaVis) * (1 - Math.exp(-dt * 6));
      poseCar(bot);

      const accelLong = (bot.v - bot.prevV) / Math.max(dt, 1e-3);
      bot.prevV = bot.v;
      const accelLat = bot.v * bot.v * bendHere;
      bot.car.userData.tick(dt, {
        speed: bot.v, steer: bot.steerVis, steerAngle: bot.steerVis * 0.43,
        accelLong, accelLat, serviceBrake: bot.braking, handbrake: false,
      });
    }
  }

  return {
    group,
    setTrack(next) { current = next; placeAtStart(); },
    update,
    placeAtStart,
    dispose() {
      group.removeFromParent();
      group.traverse(object => {
        const mesh = object as Three.Mesh;
        if (!mesh.isMesh) return;
        mesh.geometry?.dispose();
        const material = mesh.material as Three.Material | Three.Material[] | undefined;
        if (Array.isArray(material)) for (const entry of material) entry.dispose();
        else material?.dispose();
      });
    },
  };
}
