import { useEffect, useRef, useState } from 'react';
import {
  ChevronRight, ChevronLeft, ChevronsUp, Compass, Flag, Gauge, Car, CarFront, Home, Info, Mountain, Pencil, Settings, Trophy, X,
  Users, Gamepad2, Sticker, Layers, Lock, Check, Disc, Disc3, DiscAlbum, Plus, Wind,
} from 'lucide-react';
import MenuScene from './MenuScene';
import { readBuild, writeBuild } from '../arenas/rc-drift/pigeon/rally-config';
import type { RallyBuild } from '../arenas/rc-drift/pigeon/rally-config';

export type MenuArenaId = 'drift-sim' | 'rc-arena' | 'haruna-route33' | 'haruna-downhill';

const GARAGE_SECTIONS: {
  key: 'nose' | 'wing' | 'rear' | 'vinyl' | 'theme';
  title: string;
  icon: typeof CarFront;
  options: { id: string; label: string; icon: typeof CarFront; big?: boolean }[];
}[] = [
  { key: 'nose', title: 'Bodykit', icon: CarFront, options: [
    { id: 'evo', label: 'Wide Body', icon: CarFront, big: true },
    { id: 'classic', label: 'Stock', icon: Car },
  ]},
  { key: 'wing', title: 'Spoiler', icon: ChevronsUp, options: [
    { id: 'works', label: 'Ducktail', icon: ChevronsUp, big: true },
    { id: 'high', label: 'Standard', icon: Wind },
  ]},
  { key: 'rear', title: 'Skirt', icon: Layers, options: [
    { id: 's1', label: 'Wide Skirt', icon: Layers, big: true },
    { id: 'standard', label: 'High Mount', icon: Layers },
  ]},
  { key: 'vinyl', title: 'Sticker Vinyl', icon: Sticker, options: [
    { id: 'heritage', label: 'Heritage', icon: Flag, big: true },
    { id: 'rally', label: 'Rally 12', icon: Trophy },
  ]},
  { key: 'theme', title: 'Wheels', icon: Disc, options: [
    { id: 'black', label: 'Racing', icon: Disc, big: true },
    { id: 'blue', label: 'Biru', icon: Disc3 },
    { id: 'green', label: 'Hijau', icon: DiscAlbum },
  ]},
];

const OTHER_ARENAS: { id: MenuArenaId; index: string; title: string; subtitle: string; icon: typeof Gauge }[] = [
  { id: 'drift-sim', index: '01', title: 'Drift Park 8 Manuver', subtitle: 'Arena latihan & kombo trik real-time', icon: Gauge },
  { id: 'rc-arena', index: '02', title: 'RMX 2.5 RC Arena', subtitle: 'MST RMX 2.5 · Indoor P-Tile', icon: Car },
  { id: 'haruna-route33', index: '04', title: 'Haruna Touge Route 33', subtitle: 'Mt. Haruna · gunma prefecture', icon: Compass },
  { id: 'haruna-downhill', index: '05', title: 'Mt. Haruna Downhill', subtitle: 'Akina · 2 laps · time attack', icon: Mountain },
];

function useLocalStorage(key: string, fallback: string) {
  const [value, setValue] = useState(() => {
    try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; }
  });
  const save = (next: string) => {
    setValue(next);
    try { localStorage.setItem(key, next); } catch { /* storage optional */ }
  };
  return [value, save] as const;
}

export default function ProdriftMenu({ onPlay, onGarage, onArena }: {
  onPlay: () => void;
  onGarage: () => void;
  onArena: (id: MenuArenaId) => void;
}) {
  const [username, setUsername] = useLocalStorage('prodrift.username', '0xDRIFTER');
  const [draft, setDraft] = useState(username);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [garageOpen, setGarageOpen] = useState(false);
  const [appliedFlash, setAppliedFlash] = useState(false);
  const [build, setBuild] = useState<RallyBuild>(() => readBuild());
  const [nameSaved, setNameSaved] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setDraft(username); }, [username]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape') { setSettingsOpen(false); setAboutOpen(false); setGarageOpen(false); }
      if (e.code === 'Enter' && !settingsOpen && !aboutOpen) onPlay();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onPlay, settingsOpen, aboutOpen, garageOpen]);

  const commitName = () => {
    const next = draft.trim().slice(0, 16) || '0xDRIFTER';
    setUsername(next);
    setNameSaved(true);
    window.setTimeout(() => setNameSaved(false), 1600);
  };

  return (
    <div className="fixed inset-0 overflow-hidden bg-slate-900 font-[Barlow,system-ui,sans-serif] text-white select-none">
      {/* 3D diorama backdrop */}
      <MenuScene className="absolute inset-0" build={build} />

      {/* giant title behind the car */}
      {!garageOpen && <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-[6%] flex justify-center md:top-[4%]">
        <h1 className="menu-title">PRODRIFT</h1>
      </div>}

      {/* top-right username card */}
      {!garageOpen && <div className="absolute right-3 top-3 z-20 w-[210px] rounded-2xl bg-white/95 p-3 text-slate-900 shadow-2xl backdrop-blur-sm sm:w-[230px]">
        <label htmlFor="pd-username" className="block text-[10px] font-black uppercase tracking-[0.18em] text-slate-500">Username</label>
        <div className="mt-1 flex items-center gap-1.5">
          <input
            id="pd-username"
            ref={inputRef}
            value={draft}
            maxLength={16}
            onChange={e => setDraft(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') commitName(); }}
            autoComplete="off"
            spellCheck={false}
            className="h-9 w-full rounded-lg border-2 border-orange-500 bg-slate-100 px-2.5 text-[13px] font-bold outline-none focus:border-orange-600"
          />
          <button type="button" onClick={commitName} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-slate-900 text-[10px] font-black text-white transition hover:bg-slate-700" aria-label="Simpan username">
            {nameSaved ? 'OK' : 'OK'}
          </button>
        </div>
        <p className="mt-1.5 text-[10px] leading-snug text-slate-500">Choose the username that will show on leaderboards.</p>
        <div className="mt-2">
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-900 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-amber-400"><Flag size={10} /> Mt. Haruna · Touge</span>
        </div>
      </div>}

      {/* left column: SOLO / GARASI / PENGATURAN */}
      {!garageOpen && <nav className="absolute bottom-[9%] left-4 z-20 flex flex-col gap-1 sm:left-8 md:bottom-[12%]" aria-label="Menu utama PRODRIFT">
        <button type="button" onClick={onPlay} className="menu-btn menu-btn-solo" style={{ animationDelay: '0.15s' }}>
          SOLO
        </button>
        <button type="button" onClick={() => setGarageOpen(true)} className="menu-btn menu-btn-white" style={{ animationDelay: '0.28s' }}>
          GARASI
        </button>
        <button type="button" onClick={() => setSettingsOpen(true)} className="menu-btn menu-btn-white" style={{ animationDelay: '0.41s' }}>
          PENGATURAN
        </button>
      </nav>}

      {/* right column: GARAGE card + settings + icon row */}
      {!garageOpen && <div className="absolute bottom-[10%] right-4 z-20 flex flex-col items-end gap-2 sm:right-8 md:bottom-[12.5%]">
        <button type="button" onClick={() => setGarageOpen(true)} className="garage-card" style={{ animationDelay: '0.3s' }} aria-label="Buka garasi">
          <span className="garage-card-icon"><Home size={26} strokeWidth={2.6} /></span>
          <span className="garage-card-text">GARAGE</span>
        </button>
        <button type="button" onClick={() => setSettingsOpen(true)} className="settings-chip" style={{ animationDelay: '0.42s' }}>
          <span className="settings-chip-icon"><Settings size={22} strokeWidth={2.4} /></span>
          <span className="flex flex-col items-start leading-tight">
            <b>Pengaturan</b>
            <small>Arena lainnya</small>
          </span>
          <ChevronRight size={16} strokeWidth={3} className="ml-auto text-slate-400" />
        </button>
        <div className="flex gap-2" style={{ animationDelay: '0.52s' }}>
          <button type="button" className="icon-btn" onClick={() => inputRef.current?.focus()} aria-label="Ubah username"><Pencil size={19} strokeWidth={2.2} /></button>
          <button type="button" className="icon-btn" onClick={() => setSettingsOpen(true)} aria-label="Pengaturan"><Settings size={19} strokeWidth={2.2} /></button>
          <button type="button" className="icon-btn" onClick={() => setAboutOpen(true)} aria-label="Tentang & kredensial"><Info size={19} strokeWidth={2.2} /></button>
        </div>
      </div>}

      {/* bottom-right credit strip */}
      {!garageOpen && <div className="pointer-events-none absolute bottom-2 right-3 z-20 flex items-center gap-3 text-[9px] font-semibold text-white/70 drop-shadow md:text-[10px]">
        <span className="inline-flex items-center gap-1"><span className="inline-block h-2 w-2 rounded-full bg-emerald-400" /> <Users size={11} /> 70 players online</span>
        <span>·</span>
        <span>Support the game</span>
        <span className="hidden sm:inline">· Discord</span>
        <span className="hidden sm:inline">· Legal notice · Credits</span>
      </div>}

      {/* ============ GARAGE OVERLAY — body part & livery (pre-game) ============ */}
      {garageOpen && (
        <div className="absolute inset-0 z-40" role="dialog" aria-modal="true" aria-label="Garasi — body part dan livery">
          <button type="button" className="absolute inset-0 cursor-default bg-transparent" aria-label="Tutup garasi" onClick={() => setGarageOpen(false)} />

          {/* top-left back */}
          <button type="button" className="garage-back" onClick={() => setGarageOpen(false)} aria-label="Kembali ke menu"><ChevronLeft size={22} strokeWidth={3} /><span>Garage</span></button>

          {/* top-right coins */}
          <div className="coin-pill" aria-label="Koin garasi"><span className="coin-disc">$</span><b>12,500</b><button type="button" className="coin-plus" aria-label="Tambah koin" tabIndex={-1}><Plus size={18} strokeWidth={3} /></button></div>

          {/* left car list */}
          <div className="garage-carlist" aria-label="Daftar mobil">
            <button type="button" className="car-item car-item-active" aria-pressed="true">
              <span className="car-item-bar" aria-hidden="true" />
              <span className="car-item-name">RALLY GROUP B</span>
              <span className="car-item-year">1986 · IMPRESA LEGACY</span>
            </button>
            {['BMW E30', 'LANCIA FULVIA', 'VOLKSWAGEN GOLF', 'CUPRA LEON WTCC', 'FORD ESCORT RS COSWORTH', 'MITSUBISHI LANCER EVO VIII', 'ALPINE A110'].map(name => (
              <button type="button" key={name} className="car-item car-item-locked" disabled aria-label={`${name} — terkunci`}>
                <span className="car-item-name">{name}</span>
                <Lock size={13} strokeWidth={2.6} className="car-item-lock" aria-hidden="true" />
              </button>
            ))}
          </div>

          {/* right parts panel */}
          <div className="garage-panel" role="group" aria-label="Body part dan livery">
            <div className="garage-panel-chip"><CarFront size={19} strokeWidth={2.4} /><b>BODY PART &amp; LIVERY</b></div>
            <div className="garage-panel-body">
              {GARAGE_SECTIONS.map(section => (
                <div key={section.key} className="garage-section">
                  <div className="garage-section-title"><section.icon size={14} strokeWidth={2.6} /><span>{section.title}</span></div>
                  <div className="garage-section-options">
                    {section.options.map(option => {
                      const active = build[section.key] === option.id;
                      return (
                        <button
                          key={option.id}
                          type="button"
                          role="radio"
                          aria-checked={active}
                          className={`garage-option${active ? ' option-active' : ''}`}
                          onClick={() => setBuild(b => ({ ...b, [section.key]: option.id }))}
                        >
                          <option.icon size={option.big ? 34 : 26} strokeWidth={1.8} />
                          <span>{option.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* bottom-left big title */}
          <div className="garage-bigname" aria-hidden="true"><i />GARAGE</div>

          {/* bottom-right apply */}
          <button
            type="button"
            className={`garage-apply${appliedFlash ? ' apply-flash' : ''}`}
            onClick={() => { writeBuild(build); setAppliedFlash(true); window.setTimeout(() => { setAppliedFlash(false); setGarageOpen(false); }, 720); }}
          >
            <Check size={26} strokeWidth={3.4} /><span>{appliedFlash ? 'Tersimpan!' : 'Apply'}</span>
          </button>
        </div>
      )}

      {/* ============ SETTINGS OVERLAY — arena lain & opsi ============ */}
      {settingsOpen && (
        <div className="absolute inset-0 z-30 grid place-items-center p-4" role="dialog" aria-modal="true" aria-label="Pengaturan dan arena lainnya">
          <button type="button" className="absolute inset-0 cursor-default bg-slate-950/60 backdrop-blur-[3px]" aria-label="Tutup pengaturan" onClick={() => setSettingsOpen(false)} />
          <div className="menu-panel relative w-full max-w-2xl">
            <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.22em] text-amber-400">PRODRIFT — Pengaturan</p>
                <h2 className="font-racing text-2xl font-black italic text-white">ARENA LAINNYA</h2>
              </div>
              <button type="button" onClick={() => setSettingsOpen(false)} className="grid h-10 w-10 place-items-center rounded-lg bg-white/10 text-white transition hover:bg-white/20" aria-label="Tutup"><X size={20} /></button>
            </div>
            <p className="mt-2 text-[11px] text-white/55">PRODRIFT (Rally Group B Lab, Mt. Haruna) adalah menu utama. Arena lain masuk lewat sini.</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {OTHER_ARENAS.map(arena => (
                <button
                  key={arena.id}
                  type="button"
                  onClick={() => onArena(arena.id)}
                  className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3 text-left transition hover:border-amber-400/60 hover:bg-white/10"
                >
                  <arena.icon size={30} strokeWidth={1.8} className="shrink-0 text-amber-400 transition group-hover:scale-110" />
                  <span className="min-w-0">
                    <span className="block text-[9px] font-black uppercase tracking-[0.2em] text-white/40">Arena {arena.index}</span>
                    <span className="block truncate text-sm font-black text-white">{arena.title}</span>
                    <span className="block truncate text-[10px] text-white/55">{arena.subtitle}</span>
                  </span>
                  <ChevronRight size={17} strokeWidth={3} className="ml-auto shrink-0 text-white/35 transition group-hover:translate-x-0.5 group-hover:text-amber-400" />
                </button>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 pt-3">
              <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-white/45"><Gamepad2 size={13} /> PRODRIFT · Fisika 3D Car Drift Simulator · Rally Group B</span>
              <span className="inline-flex items-center gap-1.5 text-[10px] font-bold text-white/45"><Trophy size={12} /> REKOR TERSIMPAN LOKAL</span>
            </div>
          </div>
        </div>
      )}

      {/* ============ ABOUT / CREDITS MODAL ============ */}
      {aboutOpen && (
        <div className="absolute inset-0 z-30 grid place-items-center p-4" role="dialog" aria-modal="true" aria-label="Tentang PRODRIFT">
          <button type="button" className="absolute inset-0 cursor-default bg-slate-950/60 backdrop-blur-[3px]" aria-label="Tutup" onClick={() => setAboutOpen(false)} />
          <div className="menu-panel relative w-full max-w-md">
            <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3">
              <h2 className="font-racing text-2xl font-black italic text-white">TENTANG</h2>
              <button type="button" onClick={() => setAboutOpen(false)} className="grid h-10 w-10 place-items-center rounded-lg bg-white/10 text-white transition hover:bg-white/20" aria-label="Tutup"><X size={20} /></button>
            </div>
            <div className="mt-3 space-y-2 text-[13px] leading-snug text-white/75">
              <p><strong className="text-amber-400">PRODRIFT</strong> — Rally Group B di Mt. Haruna. Fisika 100% meniru 3D Car Drift Simulator: power-over, E-brake, feint, manji, 360° spin.</p>
              <p>Menu, UI &amp; scene dibuat dengan React + Three.js. Model mobil Rally Group B adalah model prosedural asli game ini.</p>
              <div className="rounded-lg bg-white/5 p-2 text-[11px] text-white/55">
                <b className="text-white/75">KREDIT</b><br />
                3D Car Drift Simulator · MST RMX 2.5 · Mt. Haruna Touge · Group B Heritage — fan-made tribute.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
