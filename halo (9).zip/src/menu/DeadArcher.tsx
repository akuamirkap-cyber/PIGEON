import { useEffect, useRef } from 'react';
import { V, v } from '../game/util';
import { BowId, Slab2, angLerp, drawArrow, drawBow, impulse, makeStick, stepStick } from '../game/ragdoll/stick';
import { HeadStyle, makeHair, stepHair } from '../game/ragdoll/head';
import { drawSkinFigure } from '../SkinModal';

/* The real in-game archer on a transparent canvas, replaying his defeat as a NATURAL, elegant fall.

   He is a true ragdoll the whole way down: gravity, ground contact, fixed bone lengths and joints that only
   bend the human way all come from the game's own physics (stepStick). On top of that, soft "dying muscles"
   guide his core through a choreography - the blow snaps him back, he staggers a step, his knees give,
   he sinks onto his seat bracing with a hand behind him, then lowers onto his back, face to the sky.
   The limbs are only lightly guided so arms and legs swing with their own weight. */

const STEP = 1 / 120;
const SLAB: Slab2[] = [{ x0: -500, x1: 500, top: 0, bot: 60 }];

// bone lengths (match stick.ts)
const NECK = 14, TORSO = 36, UARM = 18, FARM = 18, THIGH = 23, SHIN = 23;
const JRAD = [11, 4, 5, 3, 3, 3, 3, 3.5, 3, 3.5, 3];
const PI = Math.PI;

/** a pose as angles: hip x, torso, head, bow arm (upper/fore), draw arm, back leg (thigh/shin), front leg */
interface Pose { hx: number; torso: number; head: number; bu: number; bf: number; du: number; df: number; kt: number; ks: number; ft: number; fs: number }

/** the blow lands: chest punched back, chin up, arms thrown open, a stagger step back */
const RECOIL: Pose = { hx: -7, torso: -PI / 2 - 0.36, head: -PI / 2 - 0.95, bu: -0.45, bf: -0.75, du: PI - 0.3, df: PI - 0.6, kt: PI / 2 + 0.36, ks: PI / 2 + 0.16, ft: PI / 2 - 0.26, fs: PI / 2 - 0.02 };
/** knees give way, the head drops, the arms hang loose */
const BUCKLE: Pose = { hx: -11, torso: -PI / 2 - 0.5, head: -PI / 2 - 0.55, bu: 0.75, bf: 1.05, du: PI / 2 + 0.35, df: PI / 2 + 0.15, kt: 0.55, ks: PI / 2 + 0.55, ft: 0.2, fs: PI / 2 + 0.45 };
/** sinks onto his seat, one hand resting on his thigh */
const SIT: Pose = { hx: -14, torso: -PI / 2 - 0.82, head: -PI / 2 - 0.95, bu: 0.3, bf: 0.05, du: 0.75, df: 0.35, kt: -0.12, ks: 0.28, ft: -0.5, fs: 0.62 };
/** lowered onto his back, face to the sky, a hand resting on his chest, one knee softly raised */
const LIE: Pose = { hx: -15, torso: PI - 0.02, head: PI + 0.5, bu: -0.5, bf: 0.32, du: 0.25, df: 0.0, kt: 0.05, ks: 0.0, ft: -0.45, fs: 0.5 };

const KEYS: { t: number; p: Pose; ease: (x: number) => number }[] = [
  { t: 0.26, p: RECOIL, ease: (x) => 1 - Math.pow(1 - x, 3) },
  { t: 0.72, p: BUCKLE, ease: (x) => 0.5 - 0.5 * Math.cos(PI * x) },
  { t: 1.18, p: SIT, ease: (x) => 0.5 - 0.5 * Math.cos(PI * x) },
  { t: 2.05, p: LIE, ease: (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2) },
];
const END = KEYS[KEYS.length - 1].t;

/** how strongly each joint is guided: the core firmly, the limbs only lightly so they swing with their weight */
const GUIDE = [0.07, 0.11, 0.13, 0.016, 0.028, 0.016, 0.028, 0.045, 0.07, 0.045, 0.07];
/** how much of the guidance becomes momentum (low = smooth, no springy wobble) */
const CARRY = 0.28;

const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const smooth = (a: number, b: number, x: number) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

function lerpPose(a: Pose, b: Pose, u: number): Pose {
  const out = {} as Pose;
  for (const key of Object.keys(a) as (keyof Pose)[]) out[key] = key === 'hx' ? a.hx + (b.hx - a.hx) * u : angLerp(a[key], b[key], u);
  return out;
}

const dirOf = (a: number, l: number): V => v(Math.cos(a) * l, Math.sin(a) * l);
const ang = (a: V, b: V) => Math.atan2(b.y - a.y, b.x - a.x);

/** read the angles of the body exactly as it stands right now */
function measure(P: V[]): Pose {
  return {
    hx: P[2].x, torso: ang(P[2], P[1]), head: ang(P[1], P[0]),
    bu: ang(P[1], P[3]), bf: ang(P[3], P[4]), du: ang(P[1], P[5]), df: ang(P[5], P[6]),
    kt: ang(P[2], P[7]), ks: ang(P[7], P[8]), ft: ang(P[2], P[9]), fs: ang(P[9], P[10]),
  };
}

/** forward kinematics, resting the body on the grass (the lowest main joint just touches it) */
function build(p: Pose): V[] {
  const add = (a: V, b: V) => v(a.x + b.x, a.y + b.y);
  const hip = v(p.hx, 0);
  const neck = add(hip, dirOf(p.torso, TORSO));
  const head = add(neck, dirOf(p.head, NECK));
  const be = add(neck, dirOf(p.bu, UARM)); const bh = add(be, dirOf(p.bf, FARM));
  const de = add(neck, dirOf(p.du, UARM)); const dh = add(de, dirOf(p.df, FARM));
  const bk = add(hip, dirOf(p.kt, THIGH)); const ba = add(bk, dirOf(p.ks, SHIN));
  const fk = add(hip, dirOf(p.ft, THIGH)); const fa = add(fk, dirOf(p.fs, SHIN));
  const P = [head, neck, hip, be, bh, de, dh, bk, ba, fk, fa];
  let low = -Infinity;
  for (const i of [0, 1, 2, 7, 8, 9, 10]) low = Math.max(low, P[i].y + JRAD[i]);
  for (const q of P) q.y -= low;
  return P;
}

function poseAt(t: number, start: Pose): Pose {
  let from = start; let t0 = 0;
  for (const key of KEYS) {
    if (t < key.t) return lerpPose(from, key.p, key.ease(clamp01((t - t0) / (key.t - t0))));
    from = key.p; t0 = key.t;
  }
  // a last soft exhale once he has come to rest
  const p = { ...LIE };
  const b = Math.exp(-(t - END) * 1.4) * Math.sin((t - END) * 4.5) * 0.03;
  p.head += b; p.torso -= b * 0.25;
  return p;
}

interface Props {
  skin: HeadStyle;
  bow: BowId;
  /** seconds before the fatal hit lands */
  delay?: number;
  /** world units that fit in the canvas height */
  units?: number;
  ox?: number;
  oy?: number;
  className?: string;
}

const BOW_REST = v(104, -5);
const BOW_REST_ANG = -0.2;

export default function DeadArcher({ skin, bow, delay = 0.7, units = 84, ox = 0.5, oy = 0.96, className }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const live = useRef({ skin, bow, units, ox, oy });
  live.current = { skin, bow, units, ox, oy };

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const k = makeStick(v(0, 0), 1, 1, false, true);
    const hair = makeHair(live.current.skin, k);
    let t = 0; let dead = false; let dt0 = 0; let acc = 0; let prev = 0; let raf = 0;
    let start: Pose | null = null;
    // the bow leaving his hand
    let bowP = v(0, 0); let bowA = 0; let bowFrom = v(0, 0); let bowFromA = 0;

    const step = () => {
      t += STEP;
      if (!dead) {
        k.base = v(0, 0); k.vigor = 1; k.muscle = Math.min(1, k.muscle + STEP * 1.1);
        k.aiming = Math.min(1, k.aiming + STEP * 2.2); k.aim = -0.2;
        if (t > delay) {
          dead = true; dt0 = t;
          start = measure(k.p);
          bowFrom = { ...k.p[4] }; bowFromA = k.bowAng;
          k.alive = false; k.muscle = 0; k.pull = 0; k.hasBow = false; k.fade = 0; k.hurt = 1;
          // the arrow strikes his chest: a real push that the guidance then rides with
          impulse(k, 1, v(-95, -25)); impulse(k, 0, v(-120, -55));
          impulse(k, 4, v(-30, -90)); impulse(k, 6, v(-60, -40));
        }
      }
      k.lookAt = null;
      stepStick(k, SLAB);

      if (dead && start) {
        const ft = t - dt0;
        const T = build(poseAt(ft, start));
        // the first instant belongs to the impact; the dying muscles take over a moment later
        const ramp = 0.25 + 0.75 * smooth(0.04, 0.22, ft);
        // once at rest, the hand on his chest and the raised knee hold their place a little more firmly
        const hold = smooth(END - 0.2, END + 0.6, ft);
        for (let i = 0; i < T.length; i++) {
          const limb = i >= 3 && i <= 6;
          const st = GUIDE[i] * ramp * (limb ? 1 + hold * 2.4 : 1 + hold * 0.5);
          const dx = (T[i].x - k.p[i].x) * st; const dy = (T[i].y - k.p[i].y) * st;
          k.p[i].x += dx; k.p[i].y += dy;
          // keep most of the correction out of the velocity so it glides instead of bouncing
          k.o[i].x += dx * (1 - CARRY); k.o[i].y += dy * (1 - CARRY);
          // a little air drag: heavy cloth-and-bone, not a rubber toy
          const drag = limb ? 0.993 : 0.988;
          k.o[i].x = k.p[i].x - (k.p[i].x - k.o[i].x) * drag;
          k.o[i].y = k.p[i].y - (k.p[i].y - k.o[i].y) * drag;
          // nothing sinks into the grass
          if (k.p[i].y > -JRAD[i]) k.p[i].y = -JRAD[i];
        }

        // bow: tossed up and away, spinning twice, comes to rest on the grass beside him
        const bu = clamp01(ft / 1.15);
        const e = 1 - Math.pow(1 - bu, 3);
        bowP = v(bowFrom.x + (BOW_REST.x - bowFrom.x) * e, bowFrom.y + (BOW_REST.y - bowFrom.y) * e - Math.sin(PI * bu) * 34);
        bowA = angLerp(bowFromA, BOW_REST_ANG, e) - (1 - e) * PI * 4;
      }
      if (hair) stepHair(k, hair);
    };
    // let him settle into his stance before the first frame
    for (let i = 0; i < 70; i++) { t = 0; step(); }
    t = 0;

    const paint = (rt: number) => {
      const o = live.current;
      const r = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(8, r.width); const h = Math.max(8, r.height);
      const cw = Math.round(w * dpr); const ch = Math.round(h * dpr);
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const Z = h / o.units;
      ctx.translate(w * o.ox, h * o.oy);
      ctx.scale(Z, Z);
      ctx.lineCap = 'round';
      // the arrows he planted, either side of where he comes to rest
      drawArrow(ctx, v(-98, 3), Math.PI / 2 + 0.22, 1, true, o.bow, rt, false);
      drawArrow(ctx, v(-80, 3), Math.PI / 2 - 0.12, 1, true, o.bow, rt, false);
      drawArrow(ctx, v(62, 3), Math.PI / 2 - 0.2, 1, true, o.bow, rt, false);
      // a soft shadow beneath him that stretches as he lies down
      const sx = (k.p[2].x + k.p[1].x) / 2;
      const flat = Math.min(1, Math.abs(k.p[1].x - k.p[2].x) / 34);
      ctx.save(); ctx.globalAlpha = 0.18; ctx.fillStyle = '#0a3a12';
      ctx.beginPath(); ctx.ellipse(sx, 1, 24 + 30 * flat, 3.2, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      if (dead) drawBow(ctx, bowP, bowA, 1, null, 0, false, o.bow, rt);
      drawSkinFigure(ctx, k, o.skin, hair, rt, dead ? null : o.bow);
    };

    let rt = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, prev ? (now - prev) / 1000 : 0.016);
      prev = now; rt += dt; acc += dt;
      let guard = 0;
      while (acc >= STEP && guard++ < 10) { step(); acc -= STEP; }
      if (guard >= 10) acc = 0;
      paint(rt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [delay]);

  return <canvas ref={ref} className={className} aria-hidden="true" />;
}
