import { ReactNode } from 'react';
import foesSheet from './assets/images/codex_foes_icons.webp';
import uiSheet from './assets/images/codex_ui_icons.webp';
import { audioInit, snd } from './game/ragdoll/audio';
import { tx } from './i18n';
import './codex-book.css';

/* ---------- AI-painted symbols (two 4×4 sheets, cropped with CSS - no emoji anywhere) ---------- */

const FOE_ICONS = ['bow', 'helm', 'ogre', 'shield', 'bat', 'vampire', 'chains', 'fort', 'guard', 'dragon', 'axe', 'trident', 'magma', 'scythe', 'mace', 'book'] as const;
const UI_ICONS = ['heart', 'swords', 'coin', 'map', 'target', 'star', 'crown', 'skull', 'bulb', 'replay', 'bolt', 'demon', 'eye', 'sparkle', 'throw', 'arrow'] as const;
export type FoeIcon = (typeof FOE_ICONS)[number];
export type UiIcon = (typeof UI_ICONS)[number];

/** one icon from a symbol atlas: every icon was cut out of the AI sheet (transparent, whole, centred) */
export function Sym({ icon, size = 22, tile = false, className = '' }: { icon: FoeIcon | UiIcon; size?: number; tile?: boolean; className?: string }) {
  const fi = (FOE_ICONS as readonly string[]).indexOf(icon);
  const i = fi >= 0 ? fi : (UI_ICONS as readonly string[]).indexOf(icon);
  return (
    <span
      aria-hidden="true"
      className={`cx-sym ${tile ? 'tile' : ''} ${className}`}
      style={{ width: size, height: size, backgroundImage: `url(${fi >= 0 ? foesSheet : uiSheet})`, backgroundPosition: `${(i % 4) * (100 / 3)}% ${Math.floor(i / 4) * (100 / 3)}%` }}
    />
  );
}

/** strips any emoji left in the codex texts */
export const clean = (s: string) => s.replace(/(\p{Extended_Pictographic}|\p{Regional_Indicator})\uFE0F?\u20E3?\s*/gu, '').trim();

/** dictionary flavour: split a word into syllables, /pe·ma·nah/ */
export const syllables = (word: string) => word.toLowerCase().split(' ').map((w) => w.replace(/([aiueo])([^aiueo\s])(?=[aiueo])/gi, '$1·$2')).join(' ');

/* ---------- pieces of a dictionary entry ---------- */

export function EntryHead({ num, name, accent, icon, cls, clsColor, tag, danger }: {
  num: number | string; name: string; accent: string; icon: FoeIcon; cls: string; clsColor: string; tag: string; danger?: number;
}) {
  return (
    <>
      <div className="cx-head">
        <span className="cx-portrait" style={{ ['--ac' as string]: accent }}><Sym icon={icon} size={54} /><b>{num}</b></span>
        <div className="cx-word">
          <h2>{name}</h2>
          <div className="cx-pron">/{syllables(name)}/ <em style={{ background: clsColor }}>{cls}</em></div>
        </div>
      </div>
      <div className="cx-tagrow">
        <span className="cx-tag" style={{ background: accent }}>{tag}</span>
        {danger !== undefined && danger > 0 && (
          <span className="cx-danger" title={tx('Danger', 'Bahaya')}>
            {[1, 2, 3, 4, 5].map((n) => <Sym key={n} icon="skull" size={15} className={n <= danger ? '' : 'off'} />)}
          </span>
        )}
      </div>
    </>
  );
}

export function StatGrid({ items }: { items: { icon: UiIcon; label: string; value: string }[] }) {
  return (
    <dl className="cx-stats">
      {items.map((s) => (
        <div className="cx-stat" key={s.label}>
          <Sym icon={s.icon} size={28} tile />
          <div><dt>{s.label}</dt><dd>{s.value}</dd></div>
        </div>
      ))}
    </dl>
  );
}

export function Note({ kind, icon, label, children }: { kind: 'weak' | 'tip'; icon: UiIcon; label: string; children: ReactNode }) {
  return (
    <div className={`cx-note ${kind}`}>
      <Sym icon={icon} size={26} tile />
      <div><small>{label}</small>{children}</div>
    </div>
  );
}

export function SectionTitle({ children }: { children: ReactNode }) { return <div className="cx-h">{children}</div>; }

export function CxButton({ color, icon, onClick, children }: { color: 'blue' | 'green' | 'red' | 'gold'; icon: UiIcon; onClick: () => void; children: ReactNode }) {
  return <button className={`cx-btn ${color}`} onClick={onClick}><Sym icon={icon} size={20} />{children}</button>;
}

/* ---------- the book itself ---------- */

export interface IndexTab { key: string; icon: FoeIcon; accent: string; on: boolean; title: string; onClick: () => void; boss?: boolean }

interface BookProps {
  mode: 'enemies' | 'bosses';
  onSwitch?: () => void;
  onClose: () => void;
  plate: { label: string; canvas: ReactNode; stamp?: string; caption: ReactNode; actions: ReactNode; live: string };
  entryKey: string | number;
  entry: ReactNode;
  page: number;
  total: number;
  onPrev: () => void;
  onNext: () => void;
  index: IndexTab[];
}

const Corner = () => (
  <svg viewBox="0 0 22 22" aria-hidden="true"><path d="M2 20V8a6 6 0 0 1 6-6h12" fill="none" stroke="#e9b949" strokeWidth="3" strokeLinecap="round" /><circle cx="6.5" cy="6.5" r="2.4" fill="#ffd23a" stroke="#0a1a52" strokeWidth="1.2" /></svg>
);

export default function CodexBook({ mode, onSwitch, onClose, plate, entryKey, entry, page, total, onPrev, onNext, index }: BookProps) {
  const sw = () => { audioInit(); snd.tap(); onSwitch?.(); };
  return (
    <div className="cx-overlay">
      <div className="cx-book g-pop">
        <div className="cx-plaque">
          <Sym icon="book" size={30} />
          <b>{mode === 'enemies' ? tx('ENEMY DICTIONARY', 'KAMUS MUSUH') : tx('BOSS DICTIONARY', 'KAMUS BOS')}</b>
        </div>
        {onSwitch && (
          <div className="cx-tabs">
            <button className={`cx-tab ${mode === 'enemies' ? 'on' : ''}`} onClick={mode === 'enemies' ? undefined : sw}><Sym icon="demon" size={18} />{tx('ENEMIES', 'MUSUH')}</button>
            <button className={`cx-tab ${mode === 'bosses' ? 'on' : ''}`} onClick={mode === 'bosses' ? undefined : sw}><Sym icon="crown" size={18} />{tx('5 BOSSES', '5 BOS')}</button>
          </div>
        )}
        <button className="cx-close" onClick={() => { audioInit(); snd.tap(); onClose(); }} aria-label={tx('Close', 'Tutup')}>
          <svg viewBox="0 0 20 20" fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round"><path d="m4.5 4.5 11 11M15.5 4.5l-11 11" /></svg>
        </button>

        <div className="cx-spread">
          <div className="cx-page left">
            <div className="cx-runner"><span>{plate.label}</span><span>{tx('Field study', 'Studi lapangan')}</span></div>
            <div className="cx-plate">
              {plate.canvas}
              <span className="cx-corner tl"><Corner /></span><span className="cx-corner tr"><Corner /></span>
              <span className="cx-corner bl"><Corner /></span><span className="cx-corner br"><Corner /></span>
              <div className="cx-live"><i />{plate.live}</div>
              {plate.stamp && <div className="cx-stamp">{plate.stamp}</div>}
            </div>
            <div className="cx-caption">{plate.caption}</div>
            <div className="cx-actions">{plate.actions}</div>
          </div>

          <div className="cx-gutter" aria-hidden="true" />

          <div className="cx-page right">
            <div className="cx-ribbon" aria-hidden="true" />
            <div className="cx-runner"><span>{tx('Entry', 'Entri')} {page} / {total}</span></div>
            <div className="cx-entry" key={entryKey}>{entry}</div>
            <div className="cx-foot">
              <button className="cx-arrow" onClick={onPrev} disabled={page <= 1} aria-label={tx('Previous page', 'Halaman sebelumnya')}>
                <svg viewBox="0 0 20 20"><path d="M13 4 6 10l7 6" fill="none" stroke="#fff" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </button>
              <span className="cx-pg">— {page} —</span>
              <button className="cx-arrow" onClick={onNext} disabled={page >= total} aria-label={tx('Next page', 'Halaman berikutnya')}>
                <svg viewBox="0 0 20 20"><path d="m7 4 7 6-7 6" fill="none" stroke="#fff" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </button>
            </div>
          </div>
        </div>

        <nav className="cx-index" aria-label={tx('Index', 'Indeks')}>
          {index.map((t) => (
            <button key={t.key} onClick={t.onClick} title={t.title} aria-pressed={t.on}
              className={`cx-thumb ${t.on ? 'on' : ''} ${t.boss ? 'boss' : ''}`} style={{ ['--ac' as string]: t.accent }}>
              <Sym icon={t.icon} size={30} />
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
