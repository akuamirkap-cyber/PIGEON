import * as THREE from 'three';

// 2D track (x right, y up seen from above). World mapping: X = x, Z = -y.
export interface TrackPoint {
  x: number;
  y: number;
  tx: number;
  ty: number;
  nx: number; // left normal (points to infield for CCW loop)
  ny: number;
  s: number;
}

export interface NearestResult {
  i: number;
  t: number;
  cx: number;
  cy: number;
  tx: number;
  ty: number;
  nx: number;
  ny: number;
  offset: number; // signed lateral offset (+ = left / infield)
  s: number; // distance along track
}

// Simple flowing loop: long main straight, two wide sweepers and a gentle S.
export const TRACK_CONTROL: [number, number][] = [
  [0, -7.6],
  [11, -7.2],
  [16.2, -4.2],
  [17.2, 1.0],
  [14.0, 5.8],
  [7.5, 7.4],
  [2.5, 5.4],
  [-2.5, 4.6],
  [-7.5, 7.2],
  [-14.0, 6.2],
  [-17.2, 1.2],
  [-16.2, -4.2],
  [-11, -7.2],
];

export class Track {
  pts: TrackPoint[] = [];
  length = 0;
  readonly halfWidth = 1.8;
  readonly curve: THREE.CatmullRomCurve3;

  constructor(ctrl: [number, number][] = TRACK_CONTROL, n = 720) {
    this.curve = new THREE.CatmullRomCurve3(
      ctrl.map(([x, y]) => new THREE.Vector3(x, y, 0)),
      true,
      'centripetal',
    );
    const sp = this.curve.getSpacedPoints(n);
    let s = 0;
    for (let i = 0; i < n; i++) {
      const p = sp[i];
      const next = sp[(i + 1) % n];
      const prev = sp[(i - 1 + n) % n];
      let tx = next.x - prev.x;
      let ty = next.y - prev.y;
      const l = Math.hypot(tx, ty) || 1;
      tx /= l;
      ty /= l;
      if (i > 0) s += Math.hypot(p.x - sp[i - 1].x, p.y - sp[i - 1].y);
      this.pts.push({ x: p.x, y: p.y, tx, ty, nx: -ty, ny: tx, s });
    }
    this.length = s + Math.hypot(sp[0].x - sp[n - 1].x, sp[0].y - sp[n - 1].y);
  }

  get count() {
    return this.pts.length;
  }

  nearest(x: number, y: number, hint = -1, window = 40): NearestResult {
    const P = this.pts;
    const N = P.length;
    let best = Infinity;
    let bi = 0;
    let bt = 0;
    const check = (i: number) => {
      const p = P[i];
      const q = P[(i + 1) % N];
      const dx = q.x - p.x;
      const dy = q.y - p.y;
      const l2 = dx * dx + dy * dy || 1e-9;
      let t = ((x - p.x) * dx + (y - p.y) * dy) / l2;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const cx = p.x + dx * t;
      const cy = p.y + dy * t;
      const d2 = (x - cx) * (x - cx) + (y - cy) * (y - cy);
      if (d2 < best) {
        best = d2;
        bi = i;
        bt = t;
      }
    };
    if (hint < 0) for (let i = 0; i < N; i++) check(i);
    else for (let k = -window; k <= window; k++) check((((hint + k) % N) + N) % N);

    const p = P[bi];
    const q = P[(bi + 1) % N];
    const cx = p.x + (q.x - p.x) * bt;
    const cy = p.y + (q.y - p.y) * bt;
    let tx = p.tx + (q.tx - p.tx) * bt;
    let ty = p.ty + (q.ty - p.ty) * bt;
    const l = Math.hypot(tx, ty) || 1;
    tx /= l;
    ty /= l;
    const nx = -ty;
    const ny = tx;
    const offset = (x - cx) * nx + (y - cy) * ny;
    const segLen = Math.hypot(q.x - p.x, q.y - p.y);
    return { i: bi, t: bt, cx, cy, tx, ty, nx, ny, offset, s: p.s + segLen * bt };
  }

  /** Points offset laterally from the centerline (closed loop). */
  edge(offset: number, height = 0): THREE.Vector3[] {
    return this.pts.map((p) => new THREE.Vector3(p.x + p.nx * offset, height, -(p.y + p.ny * offset)));
  }

  /** Signed curvature at index (positive = left turn). */
  curvature(i: number) {
    const N = this.pts.length;
    const a = this.pts[(i - 3 + N) % N];
    const b = this.pts[(i + 3) % N];
    const ang = Math.atan2(a.tx * b.ty - a.ty * b.tx, a.tx * b.tx + a.ty * b.ty);
    return ang / Math.max(1e-3, Math.abs(b.s - a.s) || 0.6);
  }
}
