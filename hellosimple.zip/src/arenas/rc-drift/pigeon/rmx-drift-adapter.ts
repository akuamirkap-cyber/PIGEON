// ============================================================================
//  RMX 2.5 drift system for Rally Lab (PIGEON) — 1:1 RC feel
//  Drop-in replacement for `createDriftCar()` from drift-physics.js.
//
//  The Group B car runs the *exact* RMX 2.5 RC simulation in real time
//  (same time base): identical response, yaw rate, drift angle, gyro, servo,
//  full-propo ramps and every setup option.  Only the geometry is scaled to
//  the Rally Lab car size (K ≈ 12.05 = 3.098 m / 0.257 m wheelbase), so on
//  screen it moves exactly like the RC car in car-lengths per second.
//  The speedometer shows the RC speed (same km/h as RC mode).
// ============================================================================
import { CarPhysics } from '../game/physics';
import { settingsStore, DEFAULT_SETTINGS, PRESETS, type Settings } from '../game/settings';
import { ManeuverDetector, type ManeuverEvent } from '../game/maneuvers';
import { physicsStep as classicStep, wheelRadius as classicWheelRadius } from './drift-physics.js';
import type { DriftState, DriftWheel, DriverInput, Surface, WheelId } from './drift-physics.js';

export const wheelRadius = classicWheelRadius;
export const physicsStep = classicStep;

// Rally Lab's Group B model is oversized (body 2.736 m wide, 5.96 m long, wheelbase 3.10 m).
// It is shown at REAL size: body width 1.90 m (drift / touring cars: 1.8–2.0 m) → 4.14 m long,
// wheelbase 2.15 m, wheels Ø0.67 m — practically the real Audi Sport quattro S1 E2.
const MODEL_BODY_WIDTH = 2.736;
export const CAR_WIDTH = 1.9;
export const CAR_SCALE = CAR_WIDTH / MODEL_BODY_WIDTH; // ≈ 0.694
const HALF_TRACK = 1.038 * CAR_SCALE;
const FRONT_Z = 1.665 * CAR_SCALE;
const REAR_Z = -1.433 * CAR_SCALE;
/** Size ratio real car : RMX 2.5 (wheelbase 2.15 m : 0.257 m). */
export const RALLY_SCALE = (FRONT_Z - REAR_Z) / 0.257; // ≈ 8.37
const K = RALLY_SCALE;
/** Presentation speed divisor: Rally Lab cameras / audio / score were tuned for ≈ √K slower speeds. */
export const CUE_SCALE = Math.sqrt(K);
const MASS_SCALE = 1220 / 1.75;
const RC_STEP = 0.001; // RMX physics step (same as RC mode)
const RC_WHEEL_R = 0.0325;
const DEG = Math.PI / 180;
const TAU = Math.PI * 2;
const UPSHIFT = [0, 9.2, 16.8, 25.2, 34.5, Infinity];
const DOWNSHIFT = [0, 0, 6.1, 12.4, 19.6, 27.4];
// RMX barrier response (same as RC arena)
const WALL_E = 0.32;
const WALL_MU = 0.22;
const pavement: Surface = { grip: 1, roughness: 0, height: 0 };

const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);
const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const damp = (x: number, y: number, rate: number, dt: number) => mix(x, y, 1 - Math.exp(-rate * dt));
const fade = (x: number, lo: number, hi: number) => {
  const t = clamp((x - lo) / (hi - lo), 0, 1);
  return t * t * (3 - 2 * t);
};
const moveToward = (v: number, target: number, step: number) => (v < target ? Math.min(target, v + step) : Math.max(target, v - step));

// SHIFT = "gas halus" (feathering) exactly like in RMX 2.5 Drift Sim.
const held = { shift: false };
if (typeof window !== 'undefined') {
  const track = (e: KeyboardEvent) => {
    if (e.key === 'Shift') held.shift = e.type === 'keydown';
  };
  window.addEventListener('keydown', track, true);
  window.addEventListener('keyup', track, true);
  window.addEventListener('blur', () => {
    held.shift = false;
  });
}

/** Ghost AI drives a fixed qualifying setup (RTR), like the original Rally Lab reference lap. */
export const GHOST_SETTINGS: Settings = { ...DEFAULT_SETTINGS, ...PRESETS.find((p) => p.id === 'rtr')!.values };

/** Live RMX telemetry for the Rally overlay (transmitter / gyro readout). */
export const rmxLive = {
  active: false,
  steerInput: 0,
  userSteer: 0,
  gyroCorr: 0,
  servo: 0,
  throttle: 0,
  feather: false,
  driftDeg: 0,
  yawRate: 0,
  speedKmh: 0, // RC speed (identical to RC mode)
  scaleKmh: 0, // world speed at Rally Lab size
  events: [] as ManeuverEvent[],
  donuts: 0,
  eights: 0,
  loopProgress: 0,
  loopDir: 0,
  tcCut: 0,
  driftBtn: false,
};

/** Track barrier for the RC-arena collision model: half width in RC metres + lane query in world metres. */
export type RmxBarrier = { halfWidth: number; laneAt: (wx: number, wz: number) => { off: number; nx: number; nz: number } };

export function createDriftCar(
  surfaceAt: (x: number, z: number) => Surface = () => pavement,
  opts: { isolated?: boolean; settings?: Settings; barrier?: RmxBarrier; worldScale?: number; driveGain?: number; touge?: boolean } = {},
) {
  const isolated = !!opts.isolated; // Ghost AI: no keyboard SHIFT, no live HUD
  const fixed = opts.settings;
  const barrier = opts.barrier;
  const courseK = RALLY_SCALE * (opts.worldScale ?? 1);
  const courseCueScale = Math.sqrt(courseK);
  const touge = !!opts.touge;
  let lastImpact = 0; // max RC wall impact speed (m/s, RC units) during the last step
  const car = new CarPhysics();
  if (opts.driveGain) car.driveGain = opts.driveGain;
  const det = new ManeuverDetector();
  const ids: WheelId[] = ['FL', 'FR', 'RL', 'RR'];
  const wheels = Object.fromEntries(
    ids.map((id) => [
      id,
      {
        front: id[0] === 'F',
        side: id[1] === 'L' ? 1 : -1,
        x: 0,
        z: 0,
        angle: 0,
        omega: 0,
        spin: 0,
        along: 0,
        across: 0,
        slip: 0,
        load: 0,
        roughness: 0,
        height: 0,
      } as DriftWheel,
    ]),
  ) as Record<WheelId, DriftWheel>;
  const list = ids.map((id) => wheels[id]);
  const state: DriftState = {
    x: 0,
    z: 0,
    yaw: 0,
    vx: 0,
    vz: 0,
    yawRate: 0,
    speed: 0,
    forwardSpeed: 0,
    lateralSpeed: 0,
    beta: 0,
    steer: 0,
    steerAngle: 0,
    accelLong: 0,
    accelLat: 0,
    throttle: 0,
    brake: 0,
    rearLock: 0,
    rev: 0.16,
    gear: '1',
    shifting: false,
    handbrake: false,
    serviceBrake: false,
    rearSlip: 0,
    tireNoise: 0,
    roughness: 0,
    wheels,
    driftBlend: 0,
    driftPhase: 'grip',
    driftDirection: 0,
    coasting: false,
    cueSpeed: 0,
    cueScale: courseCueScale,
    rcSpeed: 0,
    bodyRoll: 0,
    bodyPitch: 0,
    wheelTurn: 0,
  };
  const ctrl = { steer: 0, throttle: 0, brake: 0, handbrake: false, drift: false };
  let acc = 0;
  let gear = 1;
  let shiftT = 0;
  let lastSign = 0;
  let linkT = 0;
  let holdT = 0; // gearbox holds the gear while drifting (hands stay on the wheel)

  function refresh() {
    const s = Math.sin(state.yaw);
    const c = Math.cos(state.yaw);
    state.speed = Math.hypot(state.vx, state.vz);
    state.forwardSpeed = state.vx * s + state.vz * c;
    state.lateralSpeed = state.vx * c - state.vz * s;
    // identical rule to the RC HUD (RC m/s thresholds)
    state.beta = state.speed / courseK > 0.6 && state.forwardSpeed / courseK > -0.1 ? Math.atan2(state.lateralSpeed, Math.max(state.forwardSpeed, 1e-3 * courseK)) : 0;
    state.cueSpeed = state.speed / courseCueScale;
    state.rcSpeed = state.speed / courseK;
    for (const w of list) {
      const x = w.side * HALF_TRACK;
      const z = w.front ? FRONT_Z : REAR_Z;
      w.x = state.x + x * c + z * s;
      w.z = state.z - x * s + z * c;
    }
  }

  function reset(x = 0, z = 0, yaw = 0) {
    car.setPose(z / courseK, x / courseK, yaw);
    Object.assign(state, {
      x,
      z,
      yaw,
      vx: 0,
      vz: 0,
      yawRate: 0,
      steer: 0,
      steerAngle: 0,
      accelLong: 0,
      accelLat: 0,
      throttle: 0,
      brake: 0,
      rearLock: 0,
      rev: 0.16,
      gear: '1',
      shifting: false,
      handbrake: false,
      serviceBrake: false,
      rearSlip: 0,
      tireNoise: 0,
      roughness: 0,
      driftBlend: 0,
      driftPhase: 'grip',
      driftDirection: 0,
      coasting: false,
    });
    for (const w of list) Object.assign(w, { angle: 0, omega: 0, spin: 0, along: 0, across: 0, slip: 0, load: (1220 * 9.81) / 4, roughness: 0, height: 0 });
    ctrl.steer = ctrl.throttle = ctrl.brake = 0;
    ctrl.handbrake = false;
    ctrl.drift = false;
    acc = 0;
    gear = 1;
    shiftT = 0;
    lastSign = 0;
    linkT = 0;
    holdT = 0;
    state.bodyRoll = state.bodyPitch = state.wheelTurn = 0;
    det.reset();
    if (!isolated) rmxLive.events.length = 0;
    refresh();
  }

  /** Exact copy of the RC arena collision (GameEngine.collide), run in RC units after every 1 ms RC step. */
  function rcCollide(): number {
    if (!barrier) return 0;
    const c = Math.cos(car.heading);
    const sn = Math.sin(car.heading);
    const rad = touge ? 0.88 / courseK : 0.1;
    const lim = barrier.halfWidth + 0.003 - rad;
    let impact = 0;
    for (const lx of [0.125, -0.115]) {
      const px = car.x + c * lx;
      const py = car.y + sn * lx;
      const q = barrier.laneAt(py * courseK, px * courseK); // RC (x, y) -> world (x = y·courseK, z = x·courseK)
      const off = q.off / courseK;
      const qnx = q.nz; // world normal -> RC frame (= RC left normal)
      const qny = q.nx;
      let pen = 0;
      let nx = 0;
      let ny = 0;
      if (off > lim) {
        pen = off - lim;
        nx = -qnx;
        ny = -qny;
      } else if (off < -lim) {
        pen = -lim - off;
        nx = qnx;
        ny = qny;
      }
      if (pen <= 0) continue;
      car.x += nx * pen;
      car.y += ny * pen;
      const cpx = px + nx * pen - nx * rad;
      const cpy = py + ny * pen - ny * rad;
      const rx = cpx - car.x;
      const ry = cpy - car.y;
      const vcx = car.vx - car.r * ry;
      const vcy = car.vy + car.r * rx;
      const vn = vcx * nx + vcy * ny;
      if (vn >= 0) continue;
      const rn = rx * ny - ry * nx;
      const kn = 1 / car.mass + (rn * rn) / car.Iz;
      const jn = (-(1 + WALL_E) * vn) / kn;
      const tx = -ny;
      const ty = nx;
      const vt = vcx * tx + vcy * ty;
      const rt = rx * ty - ry * tx;
      const kt = 1 / car.mass + (rt * rt) / car.Iz;
      const jt = clamp(-vt / kt, -WALL_MU * jn, WALL_MU * jn);
      car.applyImpulse(cpx, cpy, jn * nx + jt * tx, jn * ny + jt * ty);
      impact = Math.max(impact, -vn);
    }
    return impact;
  }

  function step(dt: number, input: DriverInput) {
    const s = fixed ?? settingsStore.get();

    // ---------- Relaxed car-like steering + natural wheel-release counter-steer ----------
    const rawSteer = clamp(input.steer || 0, -1, 1);
    const rcSpdNow = Math.hypot(car.vx, car.vy);
    const effSteerResp = isolated ? s.steerResponse : clamp(s.steerResponse, 0.12, 0.26);
    const rise = dt / effSteerResp;
    // Gentle speed sensitivity in straight cruising, full lock availability while drifting
    const driftActive = Math.abs(state.beta) > 0.1 || ctrl.drift;
    const speedCalm = isolated || driftActive ? 1 : mix(1, touge ? 0.92 : 0.78, fade(rcSpdNow, 2.2, 6.2));
    // Natural caster self-alignment when driver lets go of the wheel mid-drift
    const handsFreeDrift = !isolated && Math.abs(rawSteer) < 0.04 && s.gyroOn && state.forwardSpeed > 1.8 && Math.abs(state.beta) > 0.08;
    const recoverEase = s.tractionControl > 0 && !ctrl.drift ? 0.45 : 1;
    const casterStick = handsFreeDrift ? clamp(-state.beta * 0.52 * recoverEase, -0.58, 0.58) * fade(Math.abs(state.beta), 0.08, 0.28) : 0;
    const steerT = Math.abs(rawSteer) >= 0.04 ? rawSteer * speedCalm : casterStick;

    if (Math.abs(rawSteer) < 1e-3 && !handsFreeDrift) {
      ctrl.steer = moveToward(ctrl.steer, 0, rise * 0.85);
    } else if (ctrl.steer * steerT < 0) {
      ctrl.steer = moveToward(ctrl.steer, steerT, rise * 1.55);
    } else {
      ctrl.steer = moveToward(ctrl.steer, steerT, handsFreeDrift ? rise * 1.15 : rise);
    }
    const gas = clamp(Number(input.gas), 0, 1);
    const pedal = clamp(Number(input.brake), 0, 1);
    const feather = !isolated && held.shift;
    // Rally Lab: SPACE = balanced e-brake drift (initiates slide + trims entry speed cleanly without stalling)
    ctrl.handbrake = false;
    ctrl.drift = !!input.handbrake;
    const thrScale = !isolated && ctrl.drift ? (gas > 0.2 ? 0.72 : 0.25) : 1;
    const thrT = gas * (feather ? s.featherLevel / 100 : 1) * (s.throttleEPA / 100) * thrScale;
    const tr = dt / s.throttleResponse;
    ctrl.throttle = ctrl.throttle < thrT ? Math.min(thrT, ctrl.throttle + tr) : Math.max(thrT, ctrl.throttle - tr * (!isolated && ctrl.drift ? 2.0 : 1.8));
    ctrl.brake = moveToward(ctrl.brake, pedal, dt / 0.12);

    // ---------- surface (asphalt / kerb / gravel) per wheel ----------
    let rough = 0;
    for (let i = 0; i < 4; i++) {
      const w = list[i];
      const t = surfaceAt(w.x, w.z);
      car.wheelGrip[i] = t.grip;
      w.roughness = t.roughness;
      w.height = t.height;
      w.worldY = t.worldY ?? t.height;
      rough += t.roughness * 0.25;
    }
    state.roughness = rough;

    // ---------- RMX physics, real time 1:1 (state stays the source of truth) ----------
    car.x = state.z / courseK;
    car.y = state.x / courseK;
    car.heading = state.yaw;
    car.vx = state.vz / courseK;
    car.vy = state.vx / courseK;
    car.r = state.yawRate;
    acc += dt;
    lastImpact = 0;
    while (acc >= RC_STEP * 0.999) {
      car.step(RC_STEP, ctrl, s);
      if (!isolated && ctrl.drift) {
        const spdRc = Math.hypot(car.vx, car.vy);
        // Preserve forward momentum mid-drift when W is held; trim excess entry speed smoothly above 3.4 m/s RC
        const minSpd = gas > 0.2 ? 3.2 : 1.8;
        if (spdRc > minSpd) {
          const entryBias = gas > 0.2 ? 0.65 : 1.0;
          const scrub = (0.75 + 0.22 * spdRc) * entryBias * fade(spdRc, minSpd, minSpd + 1.5);
          const scale = Math.max(minSpd, spdRc - scrub * RC_STEP) / spdRc;
          car.vx *= scale;
          car.vy *= scale;
        }
      }
      if (barrier) lastImpact = Math.max(lastImpact, rcCollide());
      acc -= RC_STEP;
    }
    state.x = car.y * courseK;
    state.z = car.x * courseK;
    state.yaw = car.heading;
    state.vx = car.vy * courseK;
    state.vz = car.vx * courseK;
    state.yawRate = car.r;
    refresh();

    // ---------- steering & wheels for the model / driver hands ----------
    const maxSteer = Math.max(0.3, s.steerAngle * DEG);
    state.steerAngle = car.servo;
    state.steer = clamp(car.servo / maxSteer, -1, 1);
    // exact RC body motion (sprung-mass spring/damper: roll + pitch) + authentic counter-steer wheel spin
    state.bodyRoll = car.roll;
    state.bodyPitch = -car.pitch;
    const counterVisual = clamp((-state.beta * 1.18) / maxSteer, -1, 1) * fade(Math.abs(state.beta), 0.06, 0.24) * fade(state.rcSpeed ?? 0, 0.6, 1.8);
    const visualTarget = clamp(state.steer * (handsFreeDrift ? 0.55 : 0.85) + counterVisual * (handsFreeDrift ? 0.82 : 0.42), -1, 1);
    state.wheelTurn = damp(state.wheelTurn ?? state.steer, visualTarget, 12, dt);
    let rearSlip = 0;
    let noise = 0;
    const cue = state.cueSpeed ?? 0;
    for (let i = 0; i < 4; i++) {
      const w = list[i];
      const rc = car.wheels[i];
      w.angle = rc.steer;
      w.along = rc.vLong * courseK;
      w.across = rc.vLat * courseK;
      w.omega = clamp((rc.omega * RC_WHEEL_R * courseK) / (wheelRadius * CAR_SCALE), -260, 260);
      w.spin = (w.spin + w.omega * dt) % TAU;
      // RC skid-mark intensity (GameEngine.updateEffects); Rally Lab draws rubber above 0.31 -> RC threshold 0.22
      const eff = rc.slide * Math.min(1, car.speed / 0.8 + (i >= 2 ? Math.abs(car.omegaR * car.R) / 2.5 : 0));
      w.slip = clamp(eff * (0.31 / 0.22), 0, 1);
      w.load = rc.load * MASS_SCALE;
      if (!w.front) rearSlip = Math.max(rearSlip, w.slip);
      noise = Math.max(noise, w.slip);
    }
    state.rearSlip = rearSlip;
    state.tireNoise = noise;
    // g-forces exactly as felt by the RC chassis (body roll / camera / driver)
    state.accelLong = car.axF;
    state.accelLat = car.ayF;

    // ---------- pedals ----------
    state.throttle = Math.max(0, car.motorThr);
    state.brake = car.braking ? ctrl.brake : !isolated && ctrl.drift && car.speed > 1.8 ? 0.35 : 0;
    state.serviceBrake = car.braking || (!isolated && ctrl.drift && car.speed > 1.8);
    state.handbrake = false; // hands stay on the steering wheel while Space gently trims entry speed
    state.rearLock = 0;
    state.coasting = ctrl.throttle < 0.02 && !car.braking && !ctrl.handbrake && cue > 2;

    // ---------- cosmetic automatic gearbox (gear hands, revs, HUD) ----------
    const fwdCue = state.forwardSpeed / courseCueScale;
    shiftT = Math.max(0, shiftT - dt);
    const sliding = Math.abs(state.beta) > 0.14 || state.driftBlend > 0.12 || ctrl.drift || Math.abs(state.yawRate) > 1.2;
    holdT = sliding ? 0.9 : Math.max(0, holdT - dt);
    if (car.reversing) gear = 1;
    else if (shiftT === 0 && holdT === 0) {
      const v = Math.max(0, fwdCue) * 0.62 + cue * 0.38;
      const prev = gear;
      if (gear < 5 && v >= UPSHIFT[gear]) gear++;
      else if (gear > 1 && v < DOWNSHIFT[gear]) gear--;
      if (gear !== prev) shiftT = 0.38;
    }
    state.gear = car.reversing ? 'R' : String(gear);
    state.shifting = shiftT > 0.26;
    const nominal = car.reversing ? 8.1 : UPSHIFT[Math.min(gear, 4)] * (gear === 5 ? 1.34 : 1);
    const rearSurface = (Math.abs(car.omegaR) * RC_WHEEL_R * courseK) / courseCueScale;
    const engine = mix(Math.abs(fwdCue), Math.min(rearSurface, Math.abs(fwdCue) + 14), 0.45);
    const revT = clamp(0.16 + (engine / nominal) * 0.65 + state.throttle * 0.13 - (state.shifting ? 0.18 : 0), 0.13, 0.995);
    state.rev = damp(state.rev, revT, state.shifting ? 14 : 7, dt);

    // ---------- drift phase for HUD / score / audio ----------
    const ab = Math.abs(state.beta);
    const moving = cue > 4 && fwdCue > 1;
    const target = moving ? fade(ab, 0.12, 0.45) : 0;
    state.driftBlend = damp(state.driftBlend, target, target > state.driftBlend ? 6.6 : 4.8, dt);
    const sign = moving && ab > 0.12 ? Math.sign(state.beta) : 0;
    if (sign && lastSign && sign !== lastSign) linkT = 0.58;
    if (sign) lastSign = sign;
    else if (ab < 0.06) lastSign = 0;
    linkT = Math.max(0, linkT - dt);
    state.driftDirection = sign;
    state.driftPhase = !sign ? 'grip' : linkT > 0 ? 'link' : ctrl.throttle < 0.08 ? 'exit' : ab > 0.19 ? 'slide' : 'entry';

    // ---------- live readout ----------
    if (isolated) return;
    rmxLive.active = true;
    rmxLive.steerInput = ctrl.steer;
    rmxLive.userSteer = car.userSteer / maxSteer;
    rmxLive.gyroCorr = car.gyroCorr / maxSteer;
    rmxLive.servo = car.servo / maxSteer;
    rmxLive.throttle = state.throttle;
    rmxLive.feather = feather && gas > 0;
    rmxLive.driftDeg = (state.beta * 180) / Math.PI;
    rmxLive.yawRate = (state.yawRate * 180) / Math.PI;
    rmxLive.speedKmh = car.speed * 3.6;
    rmxLive.scaleKmh = state.speed * 3.6;
    // donut & figure-8 detection (same detector as RC mode)
    const mv = det.step(dt, car);
    if (mv) {
      rmxLive.events.push(mv);
      if (rmxLive.events.length > 6) rmxLive.events.shift();
    }
    rmxLive.donuts = det.donuts;
    rmxLive.eights = det.eights;
    rmxLive.loopProgress = det.progress;
    rmxLive.loopDir = det.dir;
    rmxLive.tcCut = car.tcCut;
    rmxLive.driftBtn = ctrl.drift;
  }

  reset();
  return {
    state,
    step,
    reset,
    refresh,
    get lastImpact() {
      return lastImpact;
    },
  };
}
