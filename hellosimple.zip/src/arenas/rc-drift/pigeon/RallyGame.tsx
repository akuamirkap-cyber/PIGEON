import { useState } from 'react';
import './index.css';
import PigeonApp from './App';
import { rcDefaultSetup, settingsStore } from '../game/settings';

/** Rally Lab (PIGEON): Group B car, driver rig, cockpit & garage — driven by the RMX 2.5 drift system. */
export default function RallyGame({ onExit }: { onExit: () => void }) {
  // Every Rally Lab session starts with the RC factory default (RTR Standar on P-Tile),
  // exactly what a fresh RC game uses. 1–5 / TAB change it during the session.
  useState(() => {
    settingsStore.set(rcDefaultSetup(settingsStore.get()));
    return true;
  });
  return (
    <div className="fixed inset-0 overflow-hidden">
      <PigeonApp onExit={onExit} />
    </div>
  );
}
