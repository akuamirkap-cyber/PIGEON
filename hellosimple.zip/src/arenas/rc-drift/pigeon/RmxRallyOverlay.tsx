import { useEffect, useRef, useState } from 'react';
import SetupPanel from '../components/SetupPanel';
import { useSettings, useTicker } from '../components/useGame';
import { matchPreset, PRESETS, settingsStore } from '../game/settings';
import { rmxLive } from './rmx-drift-adapter';

type Props = {
  hud: boolean;
  garage?: boolean;
  canHotkey: boolean;
  panelOpen: boolean;
  onOpenPanel: () => void;
  onClosePanel: () => void;
  onRestart: () => void;
  onExit: () => void;
};

function Bar({ label, value, color, right }: { label: string; value: number; color: string; right: string }) {
  const v = Math.max(-1, Math.min(1, value));
  return (
    <div className="mb-1">
      <div className="flex justify-between text-[9px] font-bold uppercase tracking-[0.16em] text-white/55">
        <span>{label}</span>
        <span className="tabular-nums text-white/80">{right}</span>
      </div>
      <div className="relative h-1.5 overflow-hidden rounded-full bg-white/10">
        <div className="absolute left-1/2 top-0 h-full w-px bg-white/30" />
        <div className="absolute top-0 h-full rounded-full" style={{ left: `${50 + Math.min(0, -v) * 50}%`, width: `${Math.abs(v) * 50}%`, background: color }} />
      </div>
    </div>
  );
}

export default function RmxRallyOverlay(p: Props) {
  const s = useSettings();
  useTicker(p.hud ? 24 : 4);
  const [toast, setToast] = useState<{ id: number; text: string; tone: 'good' | 'warn' | 'info' } | null>(null);
  const idRef = useRef(0);
  const [mv, setMv] = useState<{ id: number; title: string; sub: string } | null>(null);
  useEffect(() => {
    const id = ++idRef.current;
    setToast({ id, text: 'SETELAN DEFAULT RC: RTR STANDAR • P-TILE', tone: 'good' });
    const t = window.setTimeout(() => setToast((x) => (x && x.id === id ? null : x)), 3200);
    return () => window.clearTimeout(t);
  }, []);
  useEffect(() => {
    const id = window.setInterval(() => {
      const e = rmxLive.events.shift();
      if (!e) return;
      const key = ++idRef.current;
      setMv(
        e.type === 'donut'
          ? { id: key, title: `DONUT x${e.streak}`, sub: e.dir > 0 ? 'putar kiri ↺' : 'putar kanan ↻' }
          : { id: key, title: `ANGKA 8! #${e.count}`, sub: 'transisi bersih' },
      );
      window.setTimeout(() => setMv((t) => (t && t.id === key ? null : t)), 2200);
    }, 100);
    return () => window.clearInterval(id);
  }, []);
  const propsRef = useRef(p);
  propsRef.current = p;

  useEffect(() => {
    const say = (text: string, tone: 'good' | 'warn' | 'info' = 'info') => {
      const id = ++idRef.current;
      setToast({ id, text, tone });
      window.setTimeout(() => setToast((t) => (t && t.id === id ? null : t)), 1500);
    };
    const onKey = (e: KeyboardEvent) => {
      const P = propsRef.current;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.code === 'F2') {
        e.preventDefault();
        P.onExit();
        return;
      }
      if (P.panelOpen) return;
      if (e.code === 'Tab') {
        e.preventDefault();
        if (!e.repeat) P.onOpenPanel();
        return;
      }
      if (!P.canHotkey || e.repeat) return;
      const st = settingsStore.get();
      switch (e.code) {
        case 'KeyG':
        case 'KeyY':
          settingsStore.set({ gyroOn: !st.gyroOn });
          say(!st.gyroOn ? `GYRO MGX AKTIF • ${st.gyroGain}%` : 'GYRO MATI — HARDCORE!', !st.gyroOn ? 'good' : 'warn');
          break;
        case 'KeyQ':
        case 'KeyE':
        case 'BracketLeft':
        case 'BracketRight': {
          const g = Math.max(0, Math.min(100, st.gyroGain + (e.code === 'BracketRight' || e.code === 'KeyE' ? 5 : -5)));
          settingsStore.set({ gyroGain: g });
          say(`GAIN GYRO ${g}%`);
          break;
        }
        case 'KeyT': {
          const d = st.drivetrain === 'RWD' ? 'AWD' : 'RWD';
          settingsStore.set({ drivetrain: d });
          say(d === 'AWD' ? 'PENGGERAK: AWD (MUDAH)' : 'PENGGERAK: RWD (REALISTIS)', 'good');
          break;
        }
        case 'KeyZ':
        case 'KeyX': {
          const v = Math.max(30, Math.min(100, st.throttleEPA + (e.code === 'KeyX' ? 5 : -5)));
          settingsStore.set({ throttleEPA: v });
          say(`THROTTLE EPA ${v}%`);
          break;
        }
        case 'KeyF':
          settingsStore.set({ steerAssist: !st.steerAssist });
          say(!st.steerAssist ? 'ASISTEN SETIR AKTIF' : 'ASISTEN SETIR MATI (MURNI)', !st.steerAssist ? 'good' : 'warn');
          break;
        case 'Digit1':
        case 'Digit2':
        case 'Digit3':
        case 'Digit4':
        case 'Digit5': {
          const pr = PRESETS[Number(e.code.slice(5)) - 1];
          settingsStore.set(pr.values);
          say(`PRESET RMX: ${pr.name.toUpperCase()}`, 'good');
          break;
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const L = rmxLive;
  return (
    <>
      {p.hud && (
        <div className="font-game pointer-events-none fixed left-[38px] top-[300px] z-[40] flex w-[244px] flex-col items-start gap-1.5 text-white select-none max-sm:left-2 max-sm:top-auto max-sm:bottom-[210px] max-sm:scale-90 max-sm:origin-bottom-left">
          <div className="flex flex-wrap items-center gap-1 text-[11px] font-black tracking-wider">
            <span className="rounded-md bg-amber-500/90 px-2 py-0.5 text-black">RMX 2.5 DRIFT</span>
            <span className="rounded-md bg-white/90 px-2 py-0.5 text-black">SETELAN: {matchPreset(s)?.name ?? 'Kustom'}</span>
            <span className={`rounded-md px-2 py-0.5 ${s.drivetrain === 'RWD' ? 'bg-red-600/85' : 'bg-emerald-600/85'}`}>{s.drivetrain}</span>
            <span className={`rounded-md px-2 py-0.5 ${s.gyroOn ? 'bg-sky-600/85' : 'bg-zinc-700/90 text-red-300'}`}>GYRO {s.gyroOn ? `${s.gyroGain}%` : 'OFF'}</span>
            <span className="rounded-md bg-zinc-900/80 px-2 py-0.5">EPA {s.throttleEPA}%</span>
            <span className={`rounded-md px-2 py-0.5 ${s.steerAssist ? 'bg-violet-600/80' : 'bg-zinc-700/90'}`}>ASISTEN {s.steerAssist ? 'ON' : 'OFF'}</span>
            {s.tractionControl > 0 && (
              <span className={`rounded-md px-2 py-0.5 ${L.tcCut > 0.15 ? 'bg-lime-400 text-black' : 'bg-lime-700/85'}`}>TC {s.tractionControl}%</span>
            )}
            {s.speedLimit > 0 && <span className="rounded-md bg-amber-600/90 px-2 py-0.5">MAKS {s.speedLimit} km/j</span>}
            {L.feather && <span className="rounded-md bg-lime-500/90 px-2 py-0.5 text-black">GAS HALUS</span>}
            {L.driftBtn && <span className="rounded-md bg-fuchsia-500 px-2 py-0.5 text-white">DRIFT!</span>}
          </div>
          <div className="w-full rounded-xl border border-white/10 bg-black/55 px-3 py-2">
            <Bar label="Input setir (propo)" value={L.userSteer} color="#e5e7eb" right={`${Math.round(L.steerInput * 100)}%`} />
            <Bar label="Koreksi gyro" value={L.gyroCorr} color="#38bdf8" right={`${Math.round(L.gyroCorr * s.steerAngle)}°`} />
            <Bar label="Sudut roda" value={L.servo} color="#f59e0b" right={`${Math.round(L.servo * s.steerAngle)}°`} />
            <div className="mt-1 flex justify-between text-[10px] font-bold text-white/70">
              <span>
                RC <b className="text-white">{Math.round(L.speedKmh)}</b> km/j
              </span>
              <span>
                ukuran asli ≈ <b className="text-amber-300">{Math.round(L.scaleKmh)}</b> km/j
              </span>
            </div>
            <div className="mt-1 flex items-center justify-between text-[10px] font-bold text-white/70">
              <span>
                Donut <b className="text-fuchsia-300">{L.donuts}</b> • Angka 8 <b className="text-fuchsia-300">{L.eights}</b>
              </span>
              {L.loopProgress > 0.05 && (
                <span className="h-1.5 w-14 overflow-hidden rounded-full bg-white/10">
                  <span className="block h-full bg-fuchsia-400" style={{ width: `${L.loopProgress * 100}%` }} />
                </span>
              )}
            </div>
          </div>
          <div className="w-full rounded-lg bg-black/45 px-2.5 py-1 text-[10px] font-semibold leading-snug text-white/70 [@media(max-height:720px)]:hidden">
            <b className="text-fuchsia-300">SPASI</b> drift + rem halus • <b className="text-lime-300">SHIFT</b> gas halus • <b>G</b> gyro • <b>Q/E</b> gain • <b>T</b> RWD/AWD • <b>Z/X</b> EPA • <b>1–5</b> preset •{' '}
            <b className="text-amber-300">TAB</b> setelan RMX • <b>F2</b> pilih mode
          </div>
        </div>
      )}
      {p.garage && !p.panelOpen && (
        <div className="font-game pointer-events-none fixed bottom-4 left-1/2 z-[40] -translate-x-1/2 rounded-full border border-amber-400/40 bg-black/70 px-4 py-1.5 text-xs font-bold text-white/85">
          <b className="text-amber-300">TAB</b> Setelan drift RMX 2.5 • <b>F2</b> Pilih mode
        </div>
      )}
      {mv && (
        <div
          key={mv.id}
          className="font-game pointer-events-none fixed left-1/2 top-[240px] z-[45] -translate-x-1/2 animate-[toastIn_0.25s_ease-out] text-center text-white"
        >
          <div className="text-5xl font-black italic tracking-tight text-fuchsia-300 drop-shadow-[0_3px_0_rgba(0,0,0,0.6)]">{mv.title}</div>
          <div className="text-base font-black tracking-widest drop-shadow-[0_2px_0_rgba(0,0,0,0.6)]">{mv.sub}</div>
        </div>
      )}
      {toast && (
        <div
          key={toast.id}
          className={`font-game pointer-events-none fixed left-1/2 top-[110px] z-[45] -translate-x-1/2 animate-[toastIn_0.25s_ease-out] rounded-full px-4 py-1.5 text-sm font-black tracking-widest text-white ${
            toast.tone === 'warn' ? 'bg-red-600/85' : toast.tone === 'good' ? 'bg-emerald-600/85' : 'bg-black/70'
          }`}
        >
          {toast.text}
        </div>
      )}
      {p.panelOpen && (
        <div className="fixed inset-0 z-[90] bg-black/35">
          <SetupPanel variant="rally" onClose={p.onClosePanel} onResetCar={p.onRestart} onMenu={p.onExit} />
        </div>
      )}
    </>
  );
}
