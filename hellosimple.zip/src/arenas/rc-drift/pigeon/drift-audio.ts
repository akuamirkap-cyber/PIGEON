import type { DriftState } from './drift-physics.js';
import { windRush } from './speed-cues.js';

function createSynth(context:AudioContext) {
  const master=context.createGain();master.gain.value=0;master.connect(context.destination);
  const motor=context.createGain(), filter=context.createBiquadFilter(), sub=context.createGain();
  const oscillator=context.createOscillator(), second=context.createOscillator();
  const harmonics=new Float32Array([0,1,.46,.69,.22,.31,.09,.11,.065,.072]);
  oscillator.setPeriodicWave(context.createPeriodicWave(new Float32Array(harmonics.length),harmonics));
  second.type='triangle';sub.gain.value=.38;
  motor.gain.value=0;
  filter.type='lowpass';filter.Q.value=.67;
  oscillator.connect(filter);second.connect(sub);sub.connect(filter);filter.connect(motor);motor.connect(master);
  oscillator.start();second.start();
  const noise=context.createBuffer(1,context.sampleRate*2,context.sampleRate);
  const samples=noise.getChannelData(0);
  for(let i=0;i<samples.length;i++) samples[i]=Math.random()*2-1;
  const noiseSource=context.createBufferSource(), tyreBand=context.createBiquadFilter(), tyre=context.createGain(), road=context.createGain(), gravel=context.createBiquadFilter();
  const windCut=context.createBiquadFilter(), windTone=context.createBiquadFilter(), wind=context.createGain();
  tyreBand.type='bandpass';tyreBand.Q.value=2.4;
  road.gain.value=tyre.gain.value=0;
  gravel.type='lowpass';gravel.Q.value=.3;
  noiseSource.buffer=noise;noiseSource.loop=true;noiseSource.start();
  noiseSource.connect(tyreBand);tyreBand.connect(tyre);tyre.connect(master);
  noiseSource.connect(gravel);gravel.connect(road);road.connect(master);
  windCut.type='highpass';windTone.type='lowpass';windCut.Q.value=.38;windTone.Q.value=.55;wind.gain.value=0;
  noiseSource.connect(windCut);windCut.connect(windTone);windTone.connect(wind);wind.connect(master);
  return {master,motor,filter,oscillator,second,tyreBand,tyre,road,gravel,wind,windCut,windTone};
}

export function createDriveAudio() {
  let context:AudioContext|undefined, sound:ReturnType<typeof createSynth>|undefined, enabled=true;
  function unlock() {
    if(!enabled||typeof AudioContext==='undefined') return;
    try {
      if(!context) {context=new AudioContext();sound=createSynth(context);}
      if(context.state==='suspended') void context.resume().catch(()=>{});
    } catch { /* Driving remains available when the browser denies audio. */ }
  }
  function silence() {if(context&&sound) sound.master.gain.setTargetAtTime(0,context.currentTime,.048);}
  function setEnabled(value:boolean) {enabled=value;if(!value)silence();}
  function sample(state:DriftState,interior:boolean,nearRoad=false) {
    if(!context||!sound||!enabled||context.state!=='running') return;
    const t=context.currentTime;
    const pitch=31+135*state.rev;
    sound.master.gain.setTargetAtTime(.36,t,.12);
    sound.oscillator.frequency.setTargetAtTime(pitch,t,.045);
    sound.second.frequency.setTargetAtTime(pitch*.507,t,.04);
    sound.filter.frequency.setTargetAtTime(135+state.rev*710+state.throttle*670,t,.06);
    sound.motor.gain.setTargetAtTime(.065+.11*state.throttle+.043*state.rev,t,.058);
    const angle=Math.min(1,Math.abs(state.beta)*1.85), rub=(state.rcSpeed!==undefined?Math.min(1,state.tireNoise/1.41)*Math.min(1,state.rcSpeed/1.5):state.tireNoise**1.6*Math.min(1,(state.cueSpeed??state.speed)/12))*(1-.66*state.roughness);
    sound.tyreBand.frequency.setTargetAtTime(560+(state.cueSpeed??state.speed)*24+state.tireNoise*850,t,.07);
    sound.tyreBand.Q.setTargetAtTime(2.6+angle*4.1,t,.085);
    sound.tyre.gain.setTargetAtTime(rub*(.21+angle*.07),t,.056);
    sound.gravel.frequency.setTargetAtTime(140+(state.cueSpeed??state.speed)*11,t,.12);
    const rush=windRush((state.cueSpeed??state.speed));
    sound.road.gain.setTargetAtTime(Math.min(1,(state.cueSpeed??state.speed)/23)*(.045+rush*(nearRoad?.125:.082)+state.roughness*.13),t,.09);
    sound.windCut.frequency.setTargetAtTime(168+rush*195,t,.13);
    sound.windTone.frequency.setTargetAtTime((480+rush*2190)*(interior?.67:1),t,.13);
    sound.wind.gain.setTargetAtTime(rush*(interior?.21:nearRoad?.42:.36),t,.13);
  }
  function feedback(type:'link'|'bank'|'lost') {
    if(!context||!enabled||context.state!=='running') return;
    const level=context.createGain(), tone=context.createOscillator(), t=context.currentTime;
    const notes=type==='bank'?[489,734]:type==='link'?[371,557]:[194,146];
    tone.type='triangle';tone.frequency.setValueAtTime(notes[0],t);tone.frequency.setValueAtTime(notes[1],t+.07);
    level.gain.setValueAtTime(.001,t);level.gain.exponentialRampToValueAtTime(type==='lost'?.039:.052,t+.024);
    level.gain.exponentialRampToValueAtTime(.001,t+.194);
    tone.connect(level);level.connect(context.destination);tone.start(t);tone.stop(t+.206);tone.onended=()=>level.disconnect();
  }
  return {unlock,setEnabled,sample,silence,feedback,dispose:()=>{if(context)void context.close().catch(()=>{});}};
}