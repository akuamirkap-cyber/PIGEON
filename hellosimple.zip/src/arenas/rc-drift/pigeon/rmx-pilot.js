// Ghost AI pilot for the RMX 2.5 drift system.
// Drives like a keyboard player (digital A/D, W, S, SHIFT = feather) with the
// same physics and setup as the player: curvature-aware speed, look-ahead
// steering, feathering when the drift angle grows past ~38°.
import { settingsStore } from '../game/settings';
import { SURFACE_MU, TIRE_MU } from '../game/physics';
import { RALLY_SCALE } from './rmx-drift-adapter';

const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));

export function createRmxPilot(track, tune = {}) {
  const K = RALLY_SCALE, F = track.frames, N = F.length, gap = track.length / N;
  const lookM = (tune.look ?? 10.4) * 0.257 * K; // wheelbases → metres
  const look = Math.max(1, Math.round(lookM / gap));
  // RC-arena distances (m) × K
  const j0 = Math.round((0.98 * K) / gap), j1 = Math.round((7.22 * K) / gap), js = Math.max(1, Math.round((0.48 * K) / gap)), kc = Math.max(1, Math.round((0.365 * K) / gap));
  const curv = F.map((_, i) => {
    const a = F[(i - kc + N) % N], b = F[(i + kc) % N];
    return Math.abs(Math.atan2(a.tx * b.tz - a.tz * b.tx, a.tx * b.tx + a.tz * b.tz)) / (2 * kc * gap);
  });
  const grip = tune.grip ?? 1.15;
  let near = -1;
  return function pilot(run) {
    const st = run.state, s = tune.settings ?? settingsStore.get();
    if (near < 0) {
      let best = Infinity;
      for (let i = 0; i < N; i++) { const d = (F[i].x - st.x) ** 2 + (F[i].z - st.z) ** 2; if (d < best) { best = d; near = i; } }
    } else {
      let bi = near, bd = Infinity;
      for (let k = -40; k <= 40; k++) { const q = (near + k + N) % N, d = (F[q].x - st.x) ** 2 + (F[q].z - st.z) ** 2; if (d < bd) { bd = d; bi = q; } }
      near = bi;
    }
    const tp = F[(near + look) % N];
    const e = wrap(Math.atan2(tp.x - st.x, tp.z - st.z) - st.yaw);
    let km = 0;
    for (let j = j0; j < j1; j += js) km = Math.max(km, curv[(near + j) % N]);
    const mu = (SURFACE_MU[s.surface] ?? 0.62) * (TIRE_MU[s.tire] ?? 1);
    const vmax = Math.sqrt((K * mu * 9.81 * grip) / Math.max(km, 0.02 / K));
    const beta = Math.abs(st.beta) * 57.3;
    const gas = st.speed < vmax + 0.6 * K ? (beta > 38 ? s.featherLevel / 100 : 1) : 0;
    return {
      gas,
      brake: st.speed > vmax + 2.2 * K ? 1 : 0,
      steer: e > 0.15 ? 1 : e < -0.15 ? -1 : 0,
      handbrake: false,
      response: 'smooth',
    };
  };
}
