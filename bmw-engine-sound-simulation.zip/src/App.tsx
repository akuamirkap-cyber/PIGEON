import { useCallback, useEffect, useState } from "react";
import { sound, type Cfg } from "./audio/engine";
import { cancelMacro, macroActive, onFrame, runMacro, setInput, clearInputs, useSim } from "./lib/bus";
import { getTrack, Race, raceRT, RACE_LEN } from "./lib/race";
import RaceMap from "./components/RaceMap";
import { DriftRun } from "./lib/drift";
import { ENGINE_INFO } from "./lib/layers";
import Cluster from "./components/Cluster";
import Spectro from "./components/Spectro";
import Road from "./components/Road";
import Layers from "./components/Layers";
import Controls from "./components/Controls";

type Step = [number, () => void];
const cmd = (c: string) => () => sound.post({ t: "cmd", c });
const macro = (v: Parameters<typeof setInput>[1]) => () => setInput("macro", v);

function Panel({ title, aside, children, className = "" }: { title: string; aside?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={`rounded-xl border border-line bg-ink-900 p-3 sm:p-4 ${className}`}>
      <div className="mb-3 flex min-h-5 items-center justify-between gap-3">
        <h2 className="label">{title}</h2>
        {aside}
      </div>
      {children}
    </section>
  );
}

function Seg<T extends string | number>({ label, value, options, onChange, disabled }: { label: string; value: T; options: { v: T; l: string }[]; onChange: (v: T) => void; disabled?: boolean }) {
  return (
    <div className={`min-w-0 ${disabled ? "opacity-40" : ""}`}>
      <div className="label mb-1.5">{label}</div>
      <div role="group" aria-label={label} className="inline-flex max-w-full rounded-lg border border-line bg-ink-850 p-0.5">
        {options.map((o) => (
          <button key={String(o.v)} type="button" disabled={disabled} aria-pressed={o.v === value} onClick={() => onChange(o.v)}
            className={`h-9 whitespace-nowrap rounded-md px-3 text-[0.82rem] font-medium transition-colors sm:h-8 ${o.v === value ? "bg-fg text-ink-950" : "text-mute hover:text-fg"}`}>
            {o.l}
          </button>
        ))}
      </div>
    </div>
  );
}

const KEYS: [string, string][] = [
  ["Enter", "Start / stop mesin"], ["W / ↑", "Gas penuh"], ["Shift + W", "Gas 30 %"], ["S / ↓", "Rem"],
  ["A · D", "Setir"], ["E · Q", "Naik / turun gigi"], ["N", "Netral"], ["Space", "Handbrake"],
  ["K", "Lindas kerb (tahan)"], ["B", "Gundukan"], ["T", "DSC on / off"], ["M", "Mode exhaust"],
  ["C", "Kamera luar / kokpit"], ["Esc", "Hentikan balapan / showcase"],
];

export default function App() {
  const [cfg, setCfg] = useState<Cfg>({ engine: "s55", trans: "dct", auto: 1, mode: 2, dsc: 1, bumpy: 0, view: 0 });
  const [gains, setGains] = useState<number[]>(() => new Array(15).fill(1));
  const [mutes, setMutes] = useState<boolean[]>(() => new Array(15).fill(false));
  const [vol, setVol] = useState(1);
  const [wet, setWet] = useState(0.14);
  const [ready, setReady] = useState(false);
  const [demo, setDemo] = useState<string | null>(null);
  const [showcase, setShowcase] = useState(false);
  const [racing, setRacing] = useState(false);
  const [drifting, setDrifting] = useState(false);
  const es = useSim((s) => s.es);
  const info = ENGINE_INFO[cfg.engine];
  const patch = useCallback((p: Partial<Cfg>) => setCfg((c) => ({ ...c, ...p })), []);

  useEffect(() => sound.setCfg(cfg), [cfg]);
  useEffect(() => sound.setLayerGains(gains.map((g, i) => (mutes[i] ? 0 : g))), [gains, mutes]);
  useEffect(() => sound.setVolume(vol), [vol]);
  useEffect(() => sound.setWet(wet), [wet]);
  useEffect(() => sound.onReady(() => setReady(true)), []);

  const endDemo = useCallback(() => { setDemo(null); setShowcase(false); setRacing(false); setDrifting(false); }, []);
  /** setiap interaksi manual: bangunkan audio & hentikan makro yang berjalan */
  const wake = useCallback(() => { if (macroActive()) cancelMacro(); void sound.init(); }, []);
  const doCmd = useCallback((c: string) => { wake(); sound.cmd(c); }, [wake]);

  /* ---------------- audisi per layer ---------------- */
  const audition = useCallback((id: number, name: string) => {
    void sound.init().then(() => {
      const direct: Record<number, string> = { 7: "bov", 9: "crack", 10: "shifter", 14: "bump" };
      if (direct[id]) { sound.post({ t: "cmd", c: direct[id] }); return; }
      const st = sound.state, steps: Step[] = [];
      let t = 0;
      const need = (neutral: boolean) => {
        if (st.es !== 3) { steps.push([0, cmd("start")]); t = 2.7; }
        if (neutral && st.gear !== 0 && st.v < 1) steps.push([t, cmd("neutral")]);
      };
      const rev = (amt: number, hold: number, tail: number) => { need(true); steps.push([t + 0.1, macro({ throttle: amt })], [t + 0.1 + hold, macro({ throttle: 0 })]); t += hold + tail; };
      switch (id) {
        case 0: steps.push([0, cmd("stop")], [0.05, cmd("cold")], [st.es === 0 ? 0.15 : 1.3, cmd("start")]); t = (st.es === 0 ? 0.15 : 1.3) + 5; break;
        case 1: need(true); t += 2.5; break;
        case 2: rev(0.17, 2.6, 0.8); break;
        case 3: rev(0.42, 2.8, 1.4); break;
        case 4: rev(1, 0.62, 2.6); break;
        case 5: rev(1, 2.5, 2); break;
        case 12: steps.push([0, macro({ skid: 0.9 })], [1.7, macro({ skid: 0 })]); t = 2.2; break;
        case 13: steps.push([0, macro({ kerb: 2 })], [1.5, macro({ kerb: 0 })]); t = 1.9; break;
        default: // 6, 8, 11 — tarikan penuh lalu deselerasi
          need(false);
          if (st.gear === 0) steps.push([t, cmd("up")]);
          steps.push([t + 0.15, macro({ throttle: 1 })], [t + 5.2, macro({ throttle: 0 })], [t + 7.4, macro({ brake: 0.7 })], [t + 10.4, macro({ brake: 0 })]);
          t += 10.6;
      }
      setShowcase(false); setDemo(`Audisi · ${name}`);
      runMacro(steps, t, endDemo);
    });
  }, [endDemo]);

  /* ---------------- showcase otomatis ---------------- */
  const playShowcase = useCallback(() => {
    if (showcase) { cancelMacro(); return; }
    void sound.init().then(() => {
      const wasOn = sound.state.es !== 0;
      const t0 = wasOn ? 1.3 : 0.2;
      const cap = (s: string) => () => setDemo(s);
      const blip = (t: number): Step[] => [[t, macro({ throttle: 1 })], [t + 0.26, macro({ throttle: 0 })]];
      const steps: Step[] = [
        [0, () => { raceRT.race = null; patch({ trans: "dct", auto: 1, mode: 2, dsc: 1, bumpy: 0 }); sound.post({ t: "cmd", c: "stop" }); sound.post({ t: "cmd", c: "cold" }); }],
        [0, cap("Cold start — starter, raungan awal, fast-idle")],
        [t0, cmd("start")],
        [t0 + 5.2, cap("Blip gas — geraman low-mid + burble")],
        ...blip(t0 + 5.4), ...blip(t0 + 6.5), ...blip(t0 + 7.6),
        [t0 + 8.8, cap("High RPM → rev limiter")],
        [t0 + 8.9, macro({ throttle: 1 })], [t0 + 11.1, macro({ throttle: 0 })],
        [t0 + 11.2, cap("Lepas gas — diverter valve + pops & bangs")],
        [t0 + 13.4, cap("Launch control — rem + gas penuh")],
        [t0 + 13.4, cmd("up")], [t0 + 13.5, macro({ brake: 1, throttle: 1 })],
        [t0 + 15.3, macro({ brake: 0 })],
        [t0 + 15.4, cap("Tarikan penuh — twin-turbo spool, intake roar, DCT crack")],
        [t0 + 22.6, macro({ throttle: 0 })],
        [t0 + 22.7, cap("Overrun — burble, dengung transmisi")],
        [t0 + 24.8, cap("Engine brake — downshift blip")],
        [t0 + 24.8, macro({ brake: 0.8 })], [t0 + 27.0, macro({ brake: 0 })],
        [t0 + 27.1, cap("Kerb sirkuit + hentakan suspensi")],
        [t0 + 27.1, macro({ kerb: 1, throttle: 0.4 })], [t0 + 27.8, cmd("bump")], [t0 + 28.7, macro({ kerb: 0 })],
        [t0 + 28.8, () => patch({ dsc: 0 })],
        [t0 + 28.8, cap("DSC off — power oversteer, decit ban")],
        [t0 + 28.9, macro({ throttle: 1, steer: 0.8 })],
        [t0 + 32.6, macro({ throttle: 0, steer: 0, brake: 0.85 })],
        [t0 + 32.7, cap("Pengereman → berhenti")],
        [t0 + 36.2, () => { patch({ dsc: 1 }); setInput("macro", { brake: 0 }); sound.post({ t: "cmd", c: "neutral" }); }],
        [t0 + 36.6, cap("Engine off — knalpot mendingin")],
        [t0 + 36.8, cmd("stop")],
      ];
      setShowcase(true);
      runMacro(steps, t0 + 40, endDemo);
    });
  }, [showcase, patch, endDemo]);

  /* ---------------- balapan 1 menit ---------------- */
  const playRace = useCallback(() => {
    if (racing) { cancelMacro(); return; }
    void sound.init().then(() => {
      cancelMacro();
      patch({ trans: "dct", auto: 1, mode: 2, dsc: 1, bumpy: 0 });
      const race = new Race(getTrack(), sound.state.es === 3);
      raceRT.race = race;
      let lastDsc = 1, lastCap = "";
      const off = onFrame((s, dt) => {
        const o = race.step(s, dt);
        setInput("macro", { throttle: o.throttle, brake: o.brake, steer: o.steer, kerb: o.kerb });
        for (const c of o.cmds) sound.post({ t: "cmd", c });
        if (o.dsc !== lastDsc) { lastDsc = o.dsc; patch({ dsc: o.dsc }); }
        if (o.caption !== lastCap) { lastCap = o.caption; setDemo(o.caption); }
        if (race.phase === "done" && race.t > RACE_LEN + 2) cancelMacro();
      });
      setShowcase(false); setRacing(true);
      runMacro([], RACE_LEN + 30, () => {
        off();
        if (race.phase !== "done") raceRT.race = null; // dibatalkan di tengah jalan
        patch({ dsc: 1 });
        endDemo();
      });
    });
  }, [racing, patch, endDemo]);

  /* ---------------- sesi drift otomatis ---------------- */
  const playDrift = useCallback(() => {
    if (drifting) { cancelMacro(); return; }
    void sound.init().then(() => {
      cancelMacro();
      raceRT.race = null;
      patch({ trans: "dct", auto: 0, mode: 2, dsc: 0, bumpy: 0 });
      const run = new DriftRun(sound.state.es === 3, ENGINE_INFO[cfg.engine].limiter);
      let lastCap = "";
      const off = onFrame((s, dt) => {
        const o = run.step({ v: s.v, rpm: s.rpm, gear: s.gear, es: s.es, sr: s.sr, beta: s.beta }, dt);
        setInput("macro", { throttle: o.throttle, brake: o.brake, steer: o.steer, handbrake: o.handbrake });
        for (const c of o.cmds) sound.post({ t: "cmd", c });
        if (o.caption !== lastCap) { lastCap = o.caption; setDemo(o.caption); }
        if (run.done && s.v < 0.5) cancelMacro();
      });
      setShowcase(false); setRacing(false); setDrifting(true);
      runMacro([], 45, () => { off(); patch({ dsc: 1, auto: 1 }); endDemo(); });
    });
  }, [drifting, patch, endDemo, cfg.engine]);

  // tab disembunyikan → rAF berhenti; jangan biarkan mobil melaju tanpa kendali
  useEffect(() => {
    const vis = () => { if (document.hidden && macroActive()) cancelMacro(); };
    document.addEventListener("visibilitychange", vis);
    return () => document.removeEventListener("visibilitychange", vis);
  }, []);

  /* ---------------- keyboard ---------------- */
  useEffect(() => {
    const held = new Set<string>();
    const sync = () => {
      const part = held.has("ShiftLeft") || held.has("ShiftRight");
      setInput("key", {
        throttle: held.has("KeyW") || held.has("ArrowUp") ? (part ? 0.3 : 1) : 0,
        brake: held.has("KeyS") || held.has("ArrowDown") ? (part ? 0.5 : 1) : 0,
        steer: ((held.has("KeyD") || held.has("ArrowRight") ? 1 : 0) - (held.has("KeyA") || held.has("ArrowLeft") ? 1 : 0)) * 0.85,
        handbrake: held.has("Space") ? 1 : 0,
        kerb: held.has("KeyK") ? 1 : 0,
      });
    };
    const DRIVE = ["KeyW", "KeyS", "KeyA", "KeyD", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space", "KeyK"];
    const down = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const tgt = e.target as HTMLElement | null;
      const inField = !!tgt?.closest?.("button, input, select, textarea, a");
      if (inField && (e.code === "Enter" || e.code === "Space" || e.code.startsWith("Arrow"))) return;
      if (e.code === "ShiftLeft" || e.code === "ShiftRight") { held.add(e.code); sync(); return; }
      if (DRIVE.includes(e.code)) { e.preventDefault(); if (!e.repeat) { wake(); held.add(e.code); sync(); } return; }
      if (e.repeat) return;
      switch (e.code) {
        case "Enter": e.preventDefault(); doCmd("toggle"); break;
        case "KeyE": doCmd("up"); break;
        case "KeyQ": doCmd("down"); break;
        case "KeyN": doCmd("neutral"); break;
        case "KeyB": doCmd("bump"); break;
        case "KeyT": setCfg((c) => ({ ...c, dsc: c.dsc ? 0 : 1 })); break;
        case "KeyM": setCfg((c) => ({ ...c, mode: (c.mode + 1) % 3 })); break;
        case "KeyC": setCfg((c) => ({ ...c, view: c.view ? 0 : 1 })); break;
        case "Escape": cancelMacro(); break;
      }
    };
    const up = (e: KeyboardEvent) => { if (held.delete(e.code)) sync(); };
    const blur = () => { held.clear(); clearInputs("key"); clearInputs("ptr"); };
    // setelah klik mouse, kembalikan fokus keyboard ke simulasi
    const unfocus = (e: PointerEvent) => { if (e.pointerType === "mouse" && document.activeElement instanceof HTMLButtonElement) document.activeElement.blur(); };
    window.addEventListener("keydown", down); window.addEventListener("keyup", up);
    window.addEventListener("blur", blur); window.addEventListener("pointerup", unfocus);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); window.removeEventListener("blur", blur); window.removeEventListener("pointerup", unfocus); };
  }, [wake, doCmd]);

  const engineOn = es === 3;
  return (
    <div className="mx-auto max-w-[1480px] px-3 pb-10 sm:px-5">
      <header className="flex flex-wrap items-center gap-x-8 gap-y-3 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-8 -skew-x-[18deg] gap-[3px]" aria-hidden="true">
            <span className="w-[7px] bg-ice" /><span className="w-[7px] bg-mblue" /><span className="w-[7px] bg-mred" />
          </div>
          <div>
            <h1 className="font-display text-[1.6rem] font-bold italic leading-none tracking-wide">M ACOUSTIC LAB</h1>
            <p className="mt-0.5 text-xs text-dim">Simulasi suara BMW M · 100% sintesis prosedural, tanpa sampel</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:ml-4">
          <button type="button" onClick={playRace}
            className={`flex h-10 items-center gap-2.5 rounded-lg px-4 text-sm font-semibold transition-colors ${racing ? "border border-mred text-mred hover:bg-mred/10" : "bg-glow text-ink-950 hover:bg-[#ff9d4d]"}`}>
            {racing ? <span className="h-2.5 w-2.5 bg-current" aria-hidden="true" /> : <span className="h-3.5 w-5 rounded-[2px]" aria-hidden="true" style={{ background: "repeating-conic-gradient(#07080a 0% 25%, transparent 0% 50%) 0 0 / 7px 7px" }} />}
            {racing ? "Hentikan balapan" : "Balapan 1 menit"}
          </button>
          <button type="button" onClick={playDrift}
            className={`flex h-10 items-center gap-2.5 rounded-lg border px-4 text-sm font-semibold transition-colors ${drifting ? "border-mred text-mred hover:bg-mred/10" : "border-glow/70 text-glow hover:bg-glow/10"}`}>
            {drifting ? <span className="h-2.5 w-2.5 bg-current" aria-hidden="true" /> : <svg width="16" height="12" viewBox="0 0 16 12" fill="none" aria-hidden="true"><path d="M1 10c3-1 4-7 8-7s3 5 6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>}
            {drifting ? "Hentikan drift" : "Drift · 26 dtk"}
          </button>
          <button type="button" onClick={playShowcase}
            className={`flex h-10 items-center gap-2.5 rounded-lg border px-4 text-sm font-medium transition-colors ${showcase ? "border-mred text-mred hover:bg-mred/10" : "border-line text-fg hover:border-fg/40"}`}>
            {showcase ? <span className="h-2.5 w-2.5 bg-current" aria-hidden="true" /> : <svg width="10" height="12" viewBox="0 0 10 12" aria-hidden="true"><path d="M0 0l10 6-10 6z" fill="currentColor" /></svg>}
            {showcase ? "Hentikan" : "Tur suara · 40 dtk"}
          </button>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-x-6 gap-y-2">
          <label className="flex items-center gap-2.5"><span className="label">Volume</span>
            <input className="thin w-24 sm:w-28" type="range" min={0} max={1.2} step={0.01} value={vol} onChange={(e) => setVol(Number(e.target.value))} />
          </label>
          <label className="flex items-center gap-2.5"><span className="label">Gema pit</span>
            <input className="thin w-20 sm:w-24" type="range" min={0} max={0.5} step={0.01} value={wet} onChange={(e) => setWet(Number(e.target.value))} />
          </label>
          <span className="num flex items-center gap-1.5 text-[11px] text-dim">
            <span className={`h-1.5 w-1.5 rounded-full ${ready ? "bg-glow" : "bg-dim"}`} />
            {ready ? `${sound.backend === "worklet" ? "AudioWorklet" : "ScriptProcessor"} · ${Math.round((sound.ctx?.sampleRate ?? 48000) / 100) / 10} kHz` : "audio belum aktif"}
          </span>
        </div>
      </header>

      <main className="grid grid-cols-1 gap-3 lg:grid-cols-12 lg:gap-4">
        {/* setup */}
        <section className="order-3 flex min-w-0 flex-wrap items-end gap-x-6 gap-y-3 rounded-xl border border-line bg-ink-900 p-3 sm:p-4 lg:order-1 lg:col-span-12">
          <Seg label="Mesin" value={cfg.engine} onChange={(v) => patch({ engine: v })} options={[{ v: "s55", l: "S55 · I6 turbo" }, { v: "s54", l: "S54 · I6 NA" }, { v: "s63", l: "S63 · V8 turbo" }]} />
          <Seg label="Transmisi" value={cfg.trans} onChange={(v) => patch({ trans: v })} options={[{ v: "dct", l: "M-DCT 7" }, { v: "mt", l: "Manual 6" }]} />
          <Seg label="Mode DCT" value={cfg.auto} disabled={cfg.trans !== "dct"} onChange={(v) => patch({ auto: v })} options={[{ v: 1, l: "D · Auto" }, { v: 0, l: "S · Paddle" }]} />
          <Seg label="Exhaust" value={cfg.mode} onChange={(v) => patch({ mode: v })} options={[{ v: 0, l: "Comfort" }, { v: 1, l: "Sport" }, { v: 2, l: "Sport+" }]} />
          <Seg label="Kamera suara" value={cfg.view} onChange={(v) => patch({ view: v })} options={[{ v: 0, l: "Luar · knalpot" }, { v: 1, l: "Kokpit" }]} />
          <Seg label="DSC" value={cfg.dsc} onChange={(v) => patch({ dsc: v })} options={[{ v: 1, l: "On" }, { v: 0, l: "Off" }]} />
          <Seg label="Permukaan jalan" value={cfg.bumpy} onChange={(v) => patch({ bumpy: v })} options={[{ v: 0, l: "Mulus" }, { v: 1, l: "Bergelombang" }]} />
        </section>

        {/* cluster + kontrol */}
        <div className="order-1 min-w-0 space-y-3 lg:order-2 lg:col-span-5 lg:space-y-4 xl:col-span-4">
          <Panel title={`${info.long} · ${info.car}`} aside={<span className="num text-[11px] text-dim">{cfg.trans === "dct" ? (cfg.auto ? "M-DCT · D" : "M-DCT · S") : "6MT"}</span>}>
            <div className="mb-2 flex min-h-8 items-center justify-center rounded-md border border-line/70 bg-ink-850 px-3 py-1.5 text-center text-[0.82rem]" aria-live="polite">
              {demo ? <span className="rise text-glow" key={demo}>{demo}</span>
                : !ready ? <span className="text-mute">Tekan <strong className="font-semibold text-fg">START</strong> atau <kbd className="num rounded border border-line px-1 text-[11px]">Enter</kbd> untuk menyalakan mesin &amp; audio</span>
                : !engineOn ? <span className="text-mute">Mesin mati — tekan START / Enter</span>
                : <span className="text-dim">Tahan <kbd className="num rounded border border-line px-1 text-[11px] text-mute">W</kbd> untuk gas · <kbd className="num rounded border border-line px-1 text-[11px] text-mute">E</kbd> masuk gigi</span>}
            </div>
            <Cluster cfg={cfg} />
          </Panel>
          <Panel title="Kontrol">
            <Controls wake={wake} manual={cfg.trans === "mt"} onStart={() => doCmd("toggle")} onUp={() => doCmd("up")} onDown={() => doCmd("down")} onNeutral={() => doCmd("neutral")} onBump={() => doCmd("bump")} />
          </Panel>
          <Panel title="Pintasan keyboard" className="hidden sm:block">
            <dl className="grid grid-cols-2 gap-x-5 gap-y-1.5 text-[0.82rem]">
              {KEYS.map(([k, d]) => (
                <div key={k} className="flex items-baseline justify-between gap-3 border-b border-line/60 pb-1.5">
                  <dt className="text-mute">{d}</dt>
                  <dd className="num shrink-0 text-[11px] text-fg">{k}</dd>
                </div>
              ))}
            </dl>
          </Panel>
        </div>

        {/* visual */}
        <div className="order-2 min-w-0 space-y-3 lg:order-3 lg:col-span-7 lg:space-y-4 xl:col-span-4">
          <Panel title="Spektrogram · keluaran audio langsung" aside={<span className="num text-[11px] text-dim">30 Hz – 14 kHz · log</span>}>
            <Spectro cfg={cfg} />
          </Panel>
          <Panel title="Balapan · sprint 60 detik" aside={<span className="num hidden text-[11px] text-dim sm:inline">{racing ? "auto-pilot · Esc untuk berhenti" : "4 mobil · mulai dari P4"}</span>}>
            <RaceMap />
          </Panel>
          <Panel title="Lintasan · tampak atas" aside={<span className="num text-[11px] text-dim">drift manual: T (DSC off) + W + A/D</span>}>
            <Road />
          </Panel>
        </div>

        {/* mixer layer */}
        <Panel title="15 layer suara · meter aktivitas & level" className="order-4 min-w-0 lg:col-span-12 xl:col-span-4"
          aside={<button type="button" className="text-xs text-mute underline decoration-line underline-offset-4 hover:text-fg" onClick={() => { setGains(new Array(15).fill(1)); setMutes(new Array(15).fill(false)); }}>Reset</button>}>
          <Layers gains={gains} mutes={mutes}
            onGain={(id, v) => setGains((g) => g.map((x, i) => (i === id ? v : x)))}
            onMute={(id) => setMutes((m) => m.map((x, i) => (i === id ? !x : x)))}
            onAudition={(id) => { const n = ["Cold Start", "Engine Idle", "Low – Mid RPM", "High RPM", "Exhaust Burble", "Rev Limiter", "Twin-Turbo Spool", "Diverter", "Carbon Intake", "DCT Crack", "Manual Shift", "Transmission Whine", "Tire Screech", "Tire Roll / Curb", "Suspension Thud"][id]; audition(id, n); }} />
        </Panel>
      </main>

      <footer className="mt-6 max-w-3xl text-xs leading-relaxed text-dim">
        Setiap suara dihitung per-sampel: pulsa buang tiap silinder → dua pipa knalpot (waveguide) → resonansi muffler; turbo, intake, transmisi, ban, dan suspensi
        digerakkan oleh model fisika yang sama (torsi, kopling, traksi, selip). Proyek penggemar — tidak berafiliasi dengan BMW AG.
      </footer>
    </div>
  );
}
