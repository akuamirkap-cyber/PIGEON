import coreSrc from "./core.worklet.js?raw";

export interface SimState {
  rpm: number; v: number; gear: number; sh: number; cl: number;
  thr: number; brk: number; steer: number; boost: number; spool: number;
  load: number; cold: number; es: number; lim: number; launch: number;
  tc: number; sr: number; sf: number; beta: number; ax: number; ay: number;
  tq: number; fire: number; m: number[]; deny: number; bump: number; vw: number; burble: number; dist: number;
}

export interface Cfg {
  engine: "s55" | "s54" | "s63";
  trans: "dct" | "mt";
  auto: number;
  mode: number;
  dsc: number;
  bumpy: number;
  /** 0 = kamera luar (dekat knalpot), 1 = kokpit */
  view: number;
}

export const blankState = (): SimState => ({
  rpm: 0, v: 0, gear: 0, sh: 0, cl: 0, thr: 0, brk: 0, steer: 0, boost: 0, spool: 0,
  load: 0, cold: 1, es: 0, lim: 0, launch: 0, tc: 0, sr: 0, sf: 0, beta: 0, ax: 0, ay: 0,
  tq: 0, fire: 0, m: new Array(15).fill(0), deny: 0, bump: 0, vw: 0, burble: 0, dist: 0,
});

type Msg = Record<string, unknown>;
interface CoreLike { onMessage(m: Msg): void; render(l: Float32Array, r: Float32Array, n: number): void; post: ((m: SimState) => void) | null }

/** Gema pendek ala pit-wall: beberapa pantulan awal + ekor redup yang makin gelap. */
function makeImpulse(ctx: AudioContext): AudioBuffer {
  const sr = ctx.sampleRate;
  const len = Math.floor(sr * 1.5);
  const buf = ctx.createBuffer(2, len, sr);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let lp = 0;
    for (let i = Math.floor(sr * 0.012); i < len; i++) {
      const t = i / sr;
      lp += (Math.random() * 2 - 1 - lp) * (0.45 * Math.exp(-t * 3.5) + 0.06);
      d[i] = lp * Math.exp(-t * 4.4) * 0.6;
    }
    const taps = ch === 0 ? [[0.021, 0.7], [0.043, 0.45], [0.071, 0.3]] : [[0.027, 0.65], [0.049, 0.5], [0.083, 0.28]];
    for (const [t, a] of taps) { const i = Math.floor(t * sr); d[i] += a; d[i + 1] -= a * 0.4; }
  }
  return buf;
}

class SoundEngine {
  ctx: AudioContext | null = null;
  analyser: AnalyserNode | null = null;
  state: SimState = blankState();
  /** mask pengapian yang terakumulasi — dibaca & dibersihkan oleh visual */
  fire = 0;
  backend: "worklet" | "script" | "none" = "none";
  ready = false;
  private port: MessagePort | null = null;
  private core: CoreLike | null = null;
  private initP: Promise<void> | null = null;
  private cfg: Partial<Cfg> = {};
  private lg: number[] | null = null;
  private vol = 1;
  private wet = 0.14;
  private outGain: GainNode | null = null;
  private wetGain: GainNode | null = null;
  private listeners = new Set<() => void>();

  onReady(fn: () => void) { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }

  /** Harus dipanggil dari gesture pengguna (klik / tombol). */
  init(): Promise<void> {
    if (this.ctx) {
      if (this.ctx.state !== "running") void this.ctx.resume();
      return this.initP ?? Promise.resolve();
    }
    this.initP = this.build();
    return this.initP;
  }

  private async build() {
    const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC({ latencyHint: "interactive" });
    this.ctx = ctx;
    void ctx.resume();

    const out = ctx.createGain(); out.gain.value = this.vol;
    const wet = ctx.createGain(); wet.gain.value = this.wet;
    const conv = ctx.createConvolver(); conv.buffer = makeImpulse(ctx);
    const an = ctx.createAnalyser(); an.fftSize = 8192; an.smoothingTimeConstant = 0.55; an.minDecibels = -96; an.maxDecibels = -14;
    conv.connect(wet); wet.connect(out); out.connect(an); an.connect(ctx.destination);
    this.outGain = out; this.wetGain = wet; this.analyser = an;

    let node: AudioNode;
    try {
      if (!ctx.audioWorklet) throw new Error("AudioWorklet tidak tersedia");
      const url = URL.createObjectURL(new Blob([coreSrc], { type: "application/javascript" }));
      await ctx.audioWorklet.addModule(url);
      const wn = new AudioWorkletNode(ctx, "bmw-core", { numberOfInputs: 0, numberOfOutputs: 1, outputChannelCount: [2] });
      wn.port.onmessage = (e) => this.onState(e.data as SimState);
      this.port = wn.port; node = wn; this.backend = "worklet";
    } catch {
      // cadangan: jalankan inti DSP yang sama di main thread
      const Core = new Function(coreSrc + "\nreturn BMWCore;")() as new (sr: number) => CoreLike;
      const core = new Core(ctx.sampleRate);
      core.post = (m) => this.onState(m);
      const sp = ctx.createScriptProcessor(1024, 1, 2);
      sp.onaudioprocess = (e) => { const ob = e.outputBuffer; core.render(ob.getChannelData(0), ob.getChannelData(1), ob.length); };
      this.core = core; node = sp; this.backend = "script";
    }
    node.connect(out); node.connect(conv);

    this.ready = true;
    this.post({ t: "master", v: 1.15 });
    if (Object.keys(this.cfg).length) this.post({ t: "cfg", v: this.cfg });
    if (this.lg) this.post({ t: "lg", v: this.lg });
    this.listeners.forEach((f) => f());
  }

  private onState(m: SimState) { this.state = m; this.fire |= m.fire; }

  post(msg: Msg) {
    if (this.port) this.port.postMessage(msg);
    else if (this.core) this.core.onMessage(msg);
  }
  cmd(c: string) { void this.init().then(() => this.post({ t: "cmd", c })); }
  setCfg(c: Partial<Cfg>) { this.cfg = { ...this.cfg, ...c }; this.post({ t: "cfg", v: c }); }
  setLayerGains(g: number[]) { this.lg = g; this.post({ t: "lg", v: g }); }
  setVolume(v: number) { this.vol = v; if (this.outGain && this.ctx) this.outGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02); }
  setWet(v: number) { this.wet = v; if (this.wetGain && this.ctx) this.wetGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05); }
}

export const sound = new SoundEngine();
