import { useEffect, useRef } from "react";
import { onFrame } from "../lib/bus";
import { sound, type Cfg } from "../audio/engine";
import { ENGINE_INFO } from "../lib/layers";

const FMIN = 30, FMAX = 14000;
const yOf = (f: number) => 1 - Math.log(f / FMIN) / Math.log(FMAX / FMIN);

// peta warna: gelap → merah bata → amber → putih hangat
const LUT = new Uint8Array(256 * 3);
(() => {
  const stops: [number, number, number, number][] = [[0, 12, 14, 17], [0.22, 34, 16, 14], [0.45, 122, 38, 12], [0.68, 255, 138, 43], [0.88, 255, 214, 150], [1, 255, 250, 240]];
  for (let i = 0; i < 256; i++) {
    const t = i / 255;
    let k = 0;
    while (k < stops.length - 2 && t > stops[k + 1][0]) k++;
    const a = stops[k], b = stops[k + 1];
    const u = Math.min(1, Math.max(0, (t - a[0]) / (b[0] - a[0])));
    for (let c = 0; c < 3; c++) LUT[i * 3 + c] = Math.round(a[c + 1] + (b[c + 1] - a[c + 1]) * u);
  }
})();

export default function Spectro({ cfg }: { cfg: Cfg }) {
  const info = ENGINE_INFO[cfg.engine];
  const wrap = useRef<HTMLDivElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const scope = useRef<HTMLCanvasElement>(null);
  const marker = useRef<HTMLDivElement>(null);
  const markerTxt = useRef<HTMLSpanElement>(null);
  const dots = useRef<HTMLDivElement>(null);
  const cyl = info.cyl;

  useEffect(() => {
    const c = cv.current!, sc = scope.current!, w = wrap.current!;
    const g = c.getContext("2d", { alpha: false })!;
    const sg = sc.getContext("2d")!;
    let W = 0, H = 0, col: ImageData | null = null, rows: Float32Array | null = null;
    let freq: Uint8Array<ArrayBuffer> | null = null, time: Float32Array<ArrayBuffer> | null = null;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const dx = Math.max(1, Math.round(dpr * 1.5));
    const resize = () => {
      const r = c.getBoundingClientRect();
      W = Math.max(50, Math.round(r.width * dpr)); H = Math.max(50, Math.round(r.height * dpr));
      c.width = W; c.height = H;
      g.fillStyle = "#0c0e11"; g.fillRect(0, 0, W, H);
      col = g.createImageData(dx, H); rows = null;
      const r2 = sc.getBoundingClientRect();
      sc.width = Math.round(r2.width * dpr); sc.height = Math.round(r2.height * dpr);
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(w);
    const glowv = new Float32Array(8);

    const off = onFrame((s, dt) => {
      const an = sound.analyser;
      // --- indikator pengapian
      const mask = sound.fire; sound.fire = 0;
      if (dots.current) {
        const ch = dots.current.children;
        for (let i = 0; i < ch.length; i++) {
          const cylIdx = Number((ch[i] as HTMLElement).dataset.c);
          if (mask & (1 << cylIdx)) glowv[i] = 1; else glowv[i] *= Math.exp(-dt / 0.07);
          const el = ch[i] as HTMLElement;
          el.style.opacity = (0.25 + 0.75 * glowv[i]).toFixed(2);
          el.style.color = glowv[i] > 0.4 ? "#ff8a2b" : "#7d838e";
          el.style.borderColor = glowv[i] > 0.4 ? "#ff8a2b" : "#272c34";
        }
      }
      // --- penanda frekuensi pengapian
      const f0 = (s.rpm / 120) * cyl;
      if (marker.current) {
        const vis = f0 > FMIN;
        marker.current.style.opacity = vis ? "1" : "0";
        if (vis) marker.current.style.top = `${(yOf(f0) * 100).toFixed(2)}%`;
        if (markerTxt.current) markerTxt.current.textContent = `ƒ₀ ${f0.toFixed(0)} Hz`;
      }
      if (!an || !col) return;
      if (!freq || freq.length !== an.frequencyBinCount) { freq = new Uint8Array(an.frequencyBinCount); time = new Float32Array(2048); }
      if (!rows) {
        rows = new Float32Array(H + 1);
        const binHz = (sound.ctx?.sampleRate ?? 48000) / an.fftSize;
        for (let y = 0; y <= H; y++) rows[y] = (FMIN * Math.pow(FMAX / FMIN, 1 - y / H)) / binHz;
      }
      an.getByteFrequencyData(freq);
      // --- geser & tulis kolom baru
      g.drawImage(c, -dx, 0);
      const d = col.data, nb = freq.length;
      for (let y = 0; y < H; y++) {
        const hi = rows[y], lo = rows[y + 1];
        let v: number;
        if (hi - lo < 1) { const i = Math.min(nb - 2, Math.floor(lo)), fr = lo - i; v = freq[i] * (1 - fr) + freq[i + 1] * fr; }
        else { v = 0; const e = Math.min(nb - 1, Math.ceil(hi)); for (let i = Math.floor(lo); i <= e; i++) if (freq[i] > v) v = freq[i]; }
        const li = (v | 0) * 3;
        for (let x = 0; x < dx; x++) { const o = (y * dx + x) * 4; d[o] = LUT[li]; d[o + 1] = LUT[li + 1]; d[o + 2] = LUT[li + 2]; d[o + 3] = 255; }
      }
      g.putImageData(col, W - dx, 0);
      // --- osiloskop (trigger di zero-crossing naik)
      an.getFloatTimeDomainData(time!);
      const sw = sc.width, sh = sc.height, t = time!;
      sg.clearRect(0, 0, sw, sh);
      let st = 0;
      for (let i = 1; i < 900; i++) if (t[i - 1] < 0 && t[i] >= 0) { st = i; break; }
      const span = 1100;
      sg.beginPath();
      for (let x = 0; x < sw; x += 2) {
        const v = t[st + Math.floor((x / sw) * span)] || 0;
        const y = sh / 2 - v * sh * 0.95;
        if (x === 0) sg.moveTo(x, y); else sg.lineTo(x, y);
      }
      sg.strokeStyle = "#ff8a2b"; sg.lineWidth = dpr * 1.3; sg.lineJoin = "round"; sg.stroke();
    });
    return () => { off(); ro.disconnect(); };
  }, [cyl]);

  return (
    <div ref={wrap}>
      <div className="relative h-[190px] overflow-hidden rounded-md border border-line bg-ink-900 sm:h-[230px]">
        <canvas ref={cv} className="absolute inset-0 h-full w-full" aria-label="Spektrogram keluaran audio" role="img" />
        {[100, 1000, 10000].map((f) => (
          <div key={f} className="pointer-events-none absolute left-0 right-0 border-t border-white/[0.07]" style={{ top: `${yOf(f) * 100}%` }}>
            <span className="num absolute left-1.5 -top-[15px] text-[10px] text-white/45">{f >= 1000 ? `${f / 1000} kHz` : `${f} Hz`}</span>
          </div>
        ))}
        <div ref={marker} className="pointer-events-none absolute right-0 flex -translate-y-1/2 items-center gap-1 opacity-0 transition-opacity">
          <span ref={markerTxt} className="num rounded-sm bg-ink-950/85 px-1 py-px text-[10px] text-ice">ƒ₀</span>
          <span className="h-px w-3 bg-ice" />
        </div>
      </div>
      <div className="mt-2 flex items-stretch gap-3">
        <div className="relative h-14 min-w-0 flex-1 overflow-hidden rounded-md border border-line bg-ink-900">
          <canvas ref={scope} className="absolute inset-0 h-full w-full" aria-hidden="true" />
          <span className="label absolute left-1.5 top-1 !text-[0.6rem]">Gelombang</span>
        </div>
        <div className="shrink-0">
          <div className="label mb-1 !text-[0.6rem]">Urutan pengapian</div>
          <div ref={dots} className="flex gap-1">
            {info.order.map((n) => (
              <span key={n} data-c={n - 1} className="num flex h-7 w-6 items-center justify-center rounded-sm border border-line text-[11px] text-dim sm:w-7" style={{ opacity: 0.25 }}>{n}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
