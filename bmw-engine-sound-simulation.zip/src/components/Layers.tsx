import { useEffect, useRef } from "react";
import { onFrame } from "../lib/bus";
import { GROUPS } from "../lib/layers";

interface Props {
  gains: number[];
  mutes: boolean[];
  onGain: (id: number, v: number) => void;
  onMute: (id: number) => void;
  onAudition: (id: number) => void;
}

export default function Layers({ gains, mutes, onGain, onMute, onAudition }: Props) {
  const meters = useRef<(HTMLDivElement | null)[]>([]);
  const lamps = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    const sm = new Float32Array(15);
    return onFrame((s, dt) => {
      const k = Math.min(1, dt * 22), rel = Math.exp(-dt / 0.16);
      for (let i = 0; i < 15; i++) {
        const t = s.m[i] || 0;
        sm[i] = t > sm[i] ? sm[i] + (t - sm[i]) * k : Math.max(t, sm[i] * rel);
        const el = meters.current[i];
        if (el) el.style.transform = `scaleX(${Math.min(1, sm[i]).toFixed(3)})`;
        const lamp = lamps.current[i];
        if (lamp) lamp.style.opacity = sm[i] > 0.06 ? "1" : "0.22";
      }
    });
  }, []);

  return (
    <div className="gap-x-6 md:columns-2 xl:columns-1">
      {GROUPS.map((g) => (
        <div key={g.title} className="mb-4 break-inside-avoid last:mb-0">
          <div className="mb-1 flex items-center gap-2">
            <span className="h-3 w-[3px] rounded-full" style={{ background: g.color }} />
            <h3 className="label !text-mute">{g.title}</h3>
          </div>
          <ul>
            {g.layers.map((l) => {
              const muted = mutes[l.id];
              return (
                <li key={l.id} className={`border-t border-line/70 py-2 transition-opacity ${muted ? "opacity-45" : ""}`}>
                  <div className="flex items-center gap-2.5">
                    <span ref={(el) => { lamps.current[l.id] = el; }} className="num w-5 shrink-0 text-[11px]" style={{ color: g.color, opacity: 0.22 }}>{String(l.id + 1).padStart(2, "0")}</span>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[0.9rem] font-medium leading-tight text-fg">{l.name}</div>
                      <div className="truncate text-xs leading-snug text-dim" title={l.desc}>{l.desc}</div>
                    </div>
                    <button type="button" onClick={() => onAudition(l.id)} aria-label={`Dengarkan ${l.name}`} title="Dengarkan layer ini"
                      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-line text-mute transition-colors hover:border-fg/40 hover:text-fg active:bg-ink-700">
                      <svg width="10" height="12" viewBox="0 0 10 12" aria-hidden="true"><path d="M0 0l10 6-10 6z" fill="currentColor" /></svg>
                    </button>
                    <button type="button" onClick={() => onMute(l.id)} aria-pressed={muted} aria-label={`Bisukan ${l.name}`} title="Bisukan"
                      className={`num flex h-8 w-8 shrink-0 items-center justify-center rounded-md border text-[11px] font-medium transition-colors ${muted ? "border-mred bg-mred/15 text-mred" : "border-line text-mute hover:border-fg/40 hover:text-fg"}`}>
                      M
                    </button>
                  </div>
                  <div className="mt-1.5 flex items-center gap-2.5 pl-[30px]">
                    <div className="relative h-4 flex-1 overflow-hidden rounded-[3px] bg-ink-800">
                      <div ref={(el) => { meters.current[l.id] = el; }} className="absolute inset-0 origin-left" style={{ background: g.color, opacity: 0.6, transform: "scaleX(0)" }} />
                      <div className="absolute inset-y-0 w-px bg-white/25" style={{ left: "66.67%" }} />
                      <div className="absolute inset-y-0 w-[3px] -translate-x-1/2 rounded-full bg-fg shadow-[0_0_0_2px_rgba(7,8,10,0.7)]" style={{ left: `${(gains[l.id] / 1.5) * 100}%` }} />
                      <input type="range" min={0} max={1.5} step={0.01} value={gains[l.id]} onChange={(e) => onGain(l.id, Number(e.target.value))}
                        aria-label={`Level ${l.name}`} className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0" />
                    </div>
                    <span className="num w-9 shrink-0 text-right text-[11px] text-dim">{Math.round(gains[l.id] * 100)}%</span>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </div>
  );
}
