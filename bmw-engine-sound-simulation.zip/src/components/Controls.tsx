import { useEffect, useRef } from "react";
import { onFrame, setInput, useSim, type Inputs } from "../lib/bus";

const Kbd = ({ children }: { children: React.ReactNode }) => (
  <kbd className="num hidden rounded border border-line bg-ink-950 px-1.5 py-px text-[10px] leading-4 text-mute sm:inline-block">{children}</kbd>
);

function Pedal({ field, label, k, color, wake }: { field: "throttle" | "brake"; label: string; k: string; color: string; wake: () => void }) {
  const box = useRef<HTMLDivElement>(null);
  const fill = useRef<HTMLDivElement>(null);
  const pct = useRef<HTMLSpanElement>(null);
  const active = useRef(false);
  useEffect(() => onFrame((s) => {
    const v = field === "throttle" ? s.thr : s.brk;
    if (fill.current) fill.current.style.transform = `scaleY(${v.toFixed(3)})`;
    if (pct.current) pct.current.textContent = `${Math.round(v * 100)}`;
  }), [field]);
  const set = (e: React.PointerEvent) => {
    const r = box.current!.getBoundingClientRect();
    const v = Math.max(0, Math.min(1, (1 - (e.clientY - r.top) / r.height) * 1.2));
    setInput("ptr", { [field]: v } as Partial<Inputs>);
  };
  const end = () => { active.current = false; setInput("ptr", { [field]: 0 } as Partial<Inputs>); };
  return (
    <div ref={box} role="slider" tabIndex={-1} aria-label={`${label} (tahan & geser vertikal)`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={0}
      onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); active.current = true; wake(); set(e); }}
      onPointerMove={(e) => { if (active.current) set(e); }} onPointerUp={end} onPointerCancel={end} onContextMenu={(e) => e.preventDefault()}
      className="notouch relative flex h-full min-h-32 cursor-pointer flex-col justify-between overflow-hidden rounded-lg border border-line bg-ink-850 p-2.5 transition-colors hover:border-fg/30">
      <div ref={fill} className="absolute inset-0 origin-bottom" style={{ background: `linear-gradient(to top, ${color}55, ${color}22)`, transform: "scaleY(0)" }} />
      <div className="pointer-events-none absolute inset-x-0 top-[16.6%] border-t border-dashed border-white/10" />
      <div className="relative flex items-start justify-between">
        <span className="label !text-fg">{label}</span><Kbd>{k}</Kbd>
      </div>
      <div className="relative flex items-baseline gap-0.5">
        <span ref={pct} className="num text-xl font-medium text-fg">0</span><span className="text-xs text-dim">%</span>
      </div>
    </div>
  );
}

function Steer({ wake }: { wake: () => void }) {
  const box = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLDivElement>(null);
  const active = useRef(false);
  useEffect(() => onFrame((s) => { if (knob.current) knob.current.style.left = `${50 + s.steer * 44}%`; }), []);
  const set = (e: React.PointerEvent) => {
    const r = box.current!.getBoundingClientRect();
    setInput("ptr", { steer: Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - 0.5) * 2.3)) });
  };
  const end = () => { active.current = false; setInput("ptr", { steer: 0 }); };
  return (
    <div ref={box} role="slider" tabIndex={-1} aria-label="Setir (tahan & geser horizontal)" aria-valuemin={-100} aria-valuemax={100} aria-valuenow={0}
      onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); active.current = true; wake(); set(e); }}
      onPointerMove={(e) => { if (active.current) set(e); }} onPointerUp={end} onPointerCancel={end}
      className="notouch relative h-12 cursor-ew-resize rounded-lg border border-line bg-ink-850 transition-colors hover:border-fg/30">
      <div className="absolute inset-y-2 left-1/2 w-px bg-white/15" />
      <div className="pointer-events-none absolute inset-x-2.5 top-1/2 flex -translate-y-1/2 items-center justify-between">
        <Kbd>A</Kbd><span className="label">Setir</span><Kbd>D</Kbd>
      </div>
      <div ref={knob} className="absolute top-1/2 h-8 w-[5px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-fg shadow-[0_0_10px_rgba(236,233,227,0.5)]" style={{ left: "50%" }} />
    </div>
  );
}

function Hold({ label, k, field, value = 1, wake, tone = "fg" }: { label: string; k: string; field: keyof Inputs; value?: number; wake: () => void; tone?: "fg" | "red" }) {
  const on = () => { wake(); setInput("ptr", { [field]: value } as Partial<Inputs>); };
  const off = () => setInput("ptr", { [field]: 0 } as Partial<Inputs>);
  return (
    <button type="button" onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); on(); }} onPointerUp={off} onPointerCancel={off} onContextMenu={(e) => e.preventDefault()}
      onKeyDown={(e) => { if ((e.key === " " || e.key === "Enter") && !e.repeat) on(); }} onKeyUp={(e) => { if (e.key === " " || e.key === "Enter") off(); }}
      className={`notouch flex h-11 min-w-0 flex-1 items-center justify-center gap-2 rounded-lg border border-line bg-ink-850 px-2 text-[0.82rem] font-medium transition-colors hover:border-fg/30 ${tone === "red" ? "active:border-mred active:bg-mred/15 active:text-mred" : "active:border-glow active:bg-glow/15 active:text-glow"}`}>
      <span className="truncate">{label}</span><Kbd>{k}</Kbd>
    </button>
  );
}

interface Props { wake: () => void; onStart: () => void; onUp: () => void; onDown: () => void; onNeutral: () => void; onBump: () => void; manual: boolean }

export default function Controls({ wake, onStart, onUp, onDown, onNeutral, onBump, manual }: Props) {
  const es = useSim((s) => s.es);
  const running = es === 3, busy = es === 1 || es === 2;
  const tap = "flex h-12 items-center justify-center gap-2 rounded-lg border border-line bg-ink-850 font-display text-lg font-semibold tracking-wide transition-colors hover:border-fg/30 active:border-glow active:bg-glow/15 active:text-glow";
  return (
    <div className="space-y-2.5">
      <div className="flex items-center gap-3">
        <button type="button" onClick={onStart} aria-label={running ? "Matikan mesin" : "Nyalakan mesin"}
          className={`group relative flex h-[76px] w-[76px] shrink-0 flex-col items-center justify-center rounded-full border-2 bg-ink-850 font-display leading-none transition-all active:scale-95 ${running ? "border-glow shadow-[0_0_22px_-4px_rgba(255,138,43,0.7)]" : busy ? "border-glow/60" : "border-line hover:border-fg/50"}`}>
          <span className={`text-[0.95rem] font-bold tracking-[0.08em] ${running || busy ? "text-glow" : "text-fg"}`}>START</span>
          <span className="my-[3px] h-px w-8 bg-current opacity-30" />
          <span className="text-[0.95rem] font-bold tracking-[0.08em] text-mute">STOP</span>
          <span className="mt-1 text-[0.55rem] font-semibold tracking-[0.2em] text-dim">ENGINE</span>
        </button>
        <div className="grid min-w-0 flex-1 grid-cols-[1fr_auto_1fr] gap-2">
          <button type="button" onClick={onDown} className={tap} aria-label="Turun gigi"><span aria-hidden="true">−</span><Kbd>Q</Kbd></button>
          <button type="button" onClick={onNeutral} className={`${tap} w-14`} aria-label="Netral">N</button>
          <button type="button" onClick={onUp} className={tap} aria-label="Naik gigi"><span aria-hidden="true">+</span><Kbd>E</Kbd></button>
          <p className="col-span-3 text-xs leading-snug text-dim">
            {manual ? "6MT: kopling otomatis, tuas klik–gate–thunk, auto rev-match saat turun gigi." : "M-DCT: + dari N untuk masuk gigi. Rem + gas penuh saat diam = launch control."}
          </p>
        </div>
      </div>
      <div className="grid grid-cols-[1fr_1.7fr_1fr] gap-2.5">
        <Pedal field="brake" label="Rem" k="S" color="#ef3340" wake={wake} />
        <div className="flex min-w-0 flex-col justify-between gap-2">
          <Steer wake={wake} />
          <div className="flex gap-2">
            <Hold label="Handbrake" k="Space" field="handbrake" wake={wake} tone="red" />
          </div>
          <div className="flex gap-2">
            <Hold label="Kerb" k="K" field="kerb" wake={wake} />
            <button type="button" onClick={onBump} className="flex h-11 min-w-0 flex-1 items-center justify-center gap-2 rounded-lg border border-line bg-ink-850 px-2 text-[0.82rem] font-medium transition-colors hover:border-fg/30 active:border-glow active:bg-glow/15 active:text-glow">
              <span className="truncate">Bump</span><Kbd>B</Kbd>
            </button>
          </div>
        </div>
        <Pedal field="throttle" label="Gas" k="W" color="#ff8a2b" wake={wake} />
      </div>
    </div>
  );
}
