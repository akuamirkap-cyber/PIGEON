import { useEffect, useRef } from "react";
import { getInputs, onFrame } from "../lib/bus";

const PPM = 15; // piksel per meter

export default function Road() {
  const cv = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = cv.current!;
    const g = c.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let W = 0, H = 0;
    const resize = () => { const r = c.getBoundingClientRect(); W = r.width; H = r.height; c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(c);

    let dash = 0, kerbA = 0, lastBump = -1;
    const smoke: { x: number; y: number; r: number; a: number; vy: number }[] = [];
    const skid: { x: number; y: number; a: number }[] = [];
    const bumps: number[] = [];
    const trail: [number, number][] = [];

    const off = onFrame((s, dt) => {
      const sp = s.v * PPM;
      const narrow = W < 520;
      const gR = narrow ? 30 : 40;
      const roadW = W - (gR * 2 + 34);
      const carX = roadW * 0.34, laneY = H * 0.5;
      kerbA += ((getInputs().kerb > 0 ? 1 : 0) - kerbA) * Math.min(1, dt * 9);
      const carY = laneY + kerbA * (H * 0.5 - 30);
      dash = (dash + sp * dt) % 150;
      if (lastBump < 0) lastBump = s.bump;
      if (s.bump !== lastBump) { lastBump = s.bump; bumps.push(carX + 34); }

      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, W, H);
      // aspal
      g.save();
      g.beginPath(); g.rect(0, 0, roadW, H); g.clip();
      g.fillStyle = "#101216"; g.fillRect(0, 0, roadW, H);
      g.fillStyle = "rgba(236,233,227,0.5)"; g.fillRect(0, 9, roadW, 1.5);
      g.fillRect(0, H - 10.5, roadW, 1.5);
      g.fillStyle = "rgba(236,233,227,0.22)";
      for (let x = -dash; x < roadW; x += 150) g.fillRect(x, laneY - 34, 54, 2);
      // kerb merah-putih di sisi bawah
      const kOff = (dash * 2) % 44;
      for (let x = -kOff, i = 0; x < roadW; x += 22, i++) {
        g.fillStyle = i % 2 ? "#ece9e3" : "#ef3340";
        g.globalAlpha = 0.18 + 0.8 * kerbA;
        g.fillRect(x, H - 9, 22, 9);
      }
      g.globalAlpha = 1;
      // gundukan
      for (let i = bumps.length - 1; i >= 0; i--) {
        bumps[i] -= Math.max(sp, 90) * dt;
        if (bumps[i] < -10) { bumps.splice(i, 1); continue; }
        g.fillStyle = "rgba(255,138,43,0.55)"; g.fillRect(bumps[i], 12, 3, H - 24);
      }
      // bekas ban
      const cb = Math.cos(s.beta), sb = Math.sin(s.beta);
      const rear = [[-24, -13], [-24, 13]].map(([x, y]) => [carX + x * cb - y * sb, carY + x * sb + y * cb]);
      const slip = s.sr;
      if (slip > 0.15 && (sp > 20 || s.vw > 2)) for (const [x, y] of rear) skid.push({ x, y, a: Math.min(0.75, slip) });
      const move = Math.max(sp, slip > 0.15 ? 40 : 0) * dt;
      g.fillStyle = "#000";
      for (let i = skid.length - 1; i >= 0; i--) {
        const k = skid[i]; k.x -= move;
        if (k.x < -8) { skid.splice(i, 1); continue; }
        g.globalAlpha = k.a * 0.8; g.fillRect(k.x, k.y - 2.5, Math.max(3, move + 1.5), 5);
      }
      if (skid.length > 900) skid.splice(0, skid.length - 900);
      g.globalAlpha = 1;
      // asap ban
      if (slip > 0.22) for (const [x, y] of rear) for (let n = 0; n < 2; n++) smoke.push({ x: x - 4, y: y + (Math.random() - 0.5) * 6, r: 4 + Math.random() * 4, a: 0.5 * slip, vy: (Math.random() - 0.5) * 26 });
      for (let i = smoke.length - 1; i >= 0; i--) {
        const p = smoke[i];
        p.x -= (sp * 0.75 + 46) * dt; p.y += p.vy * dt; p.r += 34 * dt; p.a -= dt * 0.55;
        if (p.a <= 0 || p.x < -40) { smoke.splice(i, 1); continue; }
        g.fillStyle = `rgba(214,216,222,${(p.a * 0.2).toFixed(3)})`;
        g.beginPath(); g.arc(p.x, p.y, p.r, 0, 6.283); g.fill();
      }
      // mobil (garis-luar sederhana, tampak atas)
      g.save();
      g.translate(carX, carY); g.rotate(s.beta);
      const tire = (x: number, y: number, rot: number, heat: number) => {
        g.save(); g.translate(x, y); g.rotate(rot);
        g.fillStyle = heat > 0.12 ? `rgb(${Math.round(120 + 135 * heat)},${Math.round(70 - 20 * heat)},${Math.round(40)})` : "#3a3f48";
        g.fillRect(-6.5, -3, 13, 6); g.restore();
      };
      tire(-24, -14, 0, slip); tire(-24, 14, 0, slip);
      tire(23, -14, s.steer * 0.5, s.sf); tire(23, 14, s.steer * 0.5, s.sf);
      g.beginPath(); g.roundRect(-36, -13, 72, 26, 7);
      g.fillStyle = "#181b20"; g.fill(); g.strokeStyle = "rgba(236,233,227,0.75)"; g.lineWidth = 1.2; g.stroke();
      g.beginPath(); g.roundRect(-18, -10, 26, 20, 4); g.strokeStyle = "rgba(236,233,227,0.3)"; g.stroke();
      // tiga garis M di kap
      ["#81c4ff", "#2f6fd0", "#ef3340"].forEach((col, i) => { g.fillStyle = col; g.fillRect(14, -3.6 + i * 2.6, 18, 2); });
      // lampu rem
      if (s.brk > 0.05) { g.fillStyle = "#ef3340"; g.shadowColor = "#ef3340"; g.shadowBlur = 8; g.fillRect(-37.5, -11, 2.5, 6); g.fillRect(-37.5, 5, 2.5, 6); g.shadowBlur = 0; }
      g.restore();
      g.restore();

      // lingkaran-G
      const gx = W - gR - 12, gy = H * 0.5;
      g.strokeStyle = "#272c34"; g.lineWidth = 1;
      g.beginPath(); g.arc(gx, gy, gR, 0, 6.283); g.stroke();
      g.beginPath(); g.arc(gx, gy, gR / 2, 0, 6.283); g.stroke();
      g.beginPath(); g.moveTo(gx - gR, gy); g.lineTo(gx + gR, gy); g.moveTo(gx, gy - gR); g.lineTo(gx, gy + gR); g.stroke();
      const sc = gR / 12;
      const px = gx + Math.max(-12, Math.min(12, s.ay)) * sc, py = gy - Math.max(-12, Math.min(12, s.ax)) * sc;
      trail.push([px, py]); if (trail.length > 22) trail.shift();
      trail.forEach(([x, y], i) => { g.fillStyle = `rgba(255,138,43,${((i / trail.length) * 0.35).toFixed(3)})`; g.beginPath(); g.arc(x, y, 2, 0, 6.283); g.fill(); });
      g.fillStyle = "#ff8a2b"; g.beginPath(); g.arc(px, py, 3.5, 0, 6.283); g.fill();
      g.font = "500 10px 'JetBrains Mono', ui-monospace, monospace"; g.textAlign = "center";
      g.fillStyle = "#7d838e"; g.fillText("G", gx, gy - gR - 6);
      const gTot = Math.hypot(s.ax, s.ay) / 9.81;
      g.fillStyle = "#a3a8b1"; g.fillText(gTot.toFixed(2), gx, gy + gR + 14);
      // teks status di lintasan
      g.textAlign = "left";
      const deg = Math.abs(s.beta) * 57.3;
      if (deg > 3) { g.fillStyle = "#ef3340"; g.fillText(`DRIFT ${deg.toFixed(0)}°`, 10, 26); }
      else if (slip > 0.2) { g.fillStyle = "#ff8a2b"; g.fillText(`WHEELSPIN ${(slip * 100).toFixed(0)}%`, 10, 26); }
      else if (s.sf > 0.2) { g.fillStyle = "#ff8a2b"; g.fillText("UNDERSTEER", 10, 26); }
    });
    return () => { off(); ro.disconnect(); };
  }, []);

  return <canvas ref={cv} className="block h-[132px] w-full rounded-md border border-line bg-ink-900 sm:h-[150px]" role="img" aria-label="Tampak atas lintasan: posisi mobil, selip ban, dan gaya-G" />;
}
