import { useEffect, useRef } from "react";
import { onFrame } from "../lib/bus";
import { getTrack, raceRT, RACE_LEN } from "../lib/race";

const fmt = (t: number) => { const c = Math.max(0, Math.min(RACE_LEN, t)); return `${Math.floor(c / 60)}:${(c % 60).toFixed(1).padStart(4, "0")}`; };

export default function RaceMap() {
  const cv = useRef<HTMLCanvasElement>(null);
  const timeEl = useRef<HTMLSpanElement>(null);
  const posEl = useRef<HTMLSpanElement>(null);
  const infoEl = useRef<HTMLSpanElement>(null);
  const lightsEl = useRef<HTMLDivElement>(null);
  const flagEl = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const T = getTrack();
    const c = cv.current!, g = c.getContext("2d")!;
    const bg = document.createElement("canvas"), bgc = bg.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let W = 0, H = 0, sc = 1, ox = 0, oy = 0;
    const X = (x: number) => ox + (x - T.minX) * sc, Y = (y: number) => oy + (y - T.minY) * sc;

    const drawStatic = () => {
      bg.width = Math.round(W * dpr); bg.height = Math.round(H * dpr);
      bgc.setTransform(dpr, 0, 0, dpr, 0, 0);
      bgc.clearRect(0, 0, W, H);
      bgc.lineJoin = "round"; bgc.lineCap = "butt";
      const road = Math.max(7, 11 * sc * 1.25);
      // kerb merah-putih di zona apex / keluar tikungan
      for (const [col, offs] of [["#ef3340", 0], ["#ece9e3", 5]] as const) {
        bgc.strokeStyle = col; bgc.lineWidth = road + 5; bgc.setLineDash([5, 5]); bgc.lineDashOffset = offs;
        let open = false;
        bgc.beginPath();
        for (let i = 0; i <= T.n; i++) {
          const k = i % T.n;
          if (T.kerb[k]) { if (!open) { bgc.moveTo(X(T.x[k]), Y(T.y[k])); open = true; } else bgc.lineTo(X(T.x[k]), Y(T.y[k])); } else open = false;
        }
        bgc.stroke();
      }
      bgc.setLineDash([]);
      // aspal
      bgc.beginPath();
      for (let i = 0; i < T.n; i++) { if (i === 0) bgc.moveTo(X(T.x[i]), Y(T.y[i])); else bgc.lineTo(X(T.x[i]), Y(T.y[i])); }
      bgc.closePath();
      bgc.strokeStyle = "#272c34"; bgc.lineWidth = road; bgc.stroke();
      bgc.strokeStyle = "rgba(236,233,227,0.08)"; bgc.lineWidth = 1; bgc.stroke();
      // garis start
      const nx = -T.hy[0], ny = T.hx[0], sx = X(T.x[0]), sy = Y(T.y[0]);
      bgc.strokeStyle = "#ece9e3"; bgc.lineWidth = 2.5;
      bgc.beginPath(); bgc.moveTo(sx - nx * (road / 2 + 3), sy - ny * (road / 2 + 3)); bgc.lineTo(sx + nx * (road / 2 + 3), sy + ny * (road / 2 + 3)); bgc.stroke();
      bgc.font = "500 9px 'JetBrains Mono', ui-monospace, monospace"; bgc.fillStyle = "#7d838e"; bgc.textAlign = "center";
      bgc.fillText("START", sx + 4, sy - road / 2 - 8);
      // nomor tikungan utama
      const major = T.apex.filter((a) => Math.abs(T.kappa[a]) > 0.0155);
      major.forEach((a, i) => {
        const side = T.kappa[a] > 0 ? -1 : 1;
        bgc.fillText(`T${i + 1}`, X(T.x[a]) + -T.hy[a] * side * (road / 2 + 11), Y(T.y[a]) + T.hx[a] * side * (road / 2 + 11) + 3);
      });
    };
    const resize = () => {
      const r = c.getBoundingClientRect(); W = r.width; H = r.height;
      c.width = Math.round(W * dpr); c.height = Math.round(H * dpr);
      const padX = 24, padT = 46, padB = 38;
      sc = Math.min((W - padX * 2) / (T.maxX - T.minX), (H - padT - padB) / (T.maxY - T.minY));
      ox = (W - (T.maxX - T.minX) * sc) / 2; oy = padT + (H - padT - padB - (T.maxY - T.minY) * sc) / 2;
      drawStatic();
    };
    resize();
    const ro = new ResizeObserver(resize); ro.observe(c);

    const at = (s: number): [number, number, number, number] => {
      let f = (s / T.ds) % T.n; if (f < 0) f += T.n;
      const i = Math.floor(f), j = (i + 1) % T.n, u = f - i;
      return [X(T.x[i] + (T.x[j] - T.x[i]) * u), Y(T.y[i] + (T.y[j] - T.y[i]) * u), T.hx[i], T.hy[i]];
    };
    const trail: { x: number; y: number; m: number }[] = [];
    let lastRace: unknown = null;

    const off = onFrame((sim) => {
      const race = raceRT.race;
      if (race !== lastRace) { lastRace = race; trail.length = 0; }
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, W, H);
      g.drawImage(bg, 0, 0, W, H);
      const s = race ? race.dist : 0;
      const [px, py, hx, hy] = at(s);
      if (race && (race.phase === "race" || race.phase === "flag")) {
        const o = race.out;
        trail.push({ x: px, y: py, m: o.brake > 0.05 ? 2 : o.throttle > 0.5 ? 1 : 0 });
        if (trail.length > 150) trail.shift();
      }
      // jejak: amber = gas, merah = rem
      g.lineWidth = 2.5; g.lineCap = "round";
      for (let i = 1; i < trail.length; i++) {
        const a = trail[i - 1], b = trail[i];
        g.strokeStyle = b.m === 2 ? "#ef3340" : b.m === 1 ? "#ff8a2b" : "#7d838e";
        g.globalAlpha = (i / trail.length) * 0.9;
        g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
      }
      g.globalAlpha = 1;
      // lawan
      if (race) for (const gh of race.ghosts) {
        const [gx, gy] = at(gh.s);
        g.fillStyle = "#0c0e11"; g.beginPath(); g.arc(gx, gy, 5.5, 0, 6.283); g.fill();
        g.fillStyle = gh.color; g.beginPath(); g.arc(gx, gy, 3.6, 0, 6.283); g.fill();
      }
      // mobil pemain
      g.shadowColor = "#ff8a2b"; g.shadowBlur = 12;
      g.fillStyle = "#ff8a2b"; g.beginPath(); g.arc(px, py, 5.5, 0, 6.283); g.fill();
      g.shadowBlur = 0;
      g.strokeStyle = "#ece9e3"; g.lineWidth = 1.5; g.beginPath(); g.arc(px, py, 5.5, 0, 6.283); g.stroke();
      g.beginPath(); g.moveTo(px + hx * 6, py + hy * 6); g.lineTo(px + hx * 12, py + hy * 12); g.stroke();

      // HUD
      const set = (el: HTMLElement | null, t: string) => { if (el && el.textContent !== t) el.textContent = t; };
      if (!race) {
        set(timeEl.current, "1:00.0"); set(posEl.current, "P4");
        set(infoEl.current, `Sprint 60 detik · ${(T.len / 1000).toFixed(2)} km · ${T.apex.length} tikungan`);
      } else {
        set(timeEl.current, race.phase === "pre" ? "GRID" : fmt(race.t));
        set(posEl.current, `P${race.pos}`);
        set(infoEl.current, `${(race.dist / 1000).toFixed(2)} km · ${Math.round(sim.v * 3.6)} km/h`);
      }
      if (lightsEl.current) {
        const show = !!race && (race.phase === "pre" || race.phase === "lights");
        lightsEl.current.style.opacity = show ? "1" : "0";
        const ch = lightsEl.current.children, n = race ? race.lights : 0;
        for (let i = 0; i < ch.length; i++) {
          const el = ch[i] as HTMLElement, on = i < n;
          el.style.background = on ? "#ef3340" : "#20242b";
          el.style.boxShadow = on ? "0 0 12px 2px rgba(239,51,64,0.7)" : "none";
        }
      }
      if (flagEl.current) flagEl.current.style.opacity = race && (race.phase === "flag" || race.phase === "done") ? "1" : "0";
    });
    return () => { off(); ro.disconnect(); };
  }, []);

  return (
    <div className="relative h-[230px] overflow-hidden rounded-md border border-line bg-ink-900 sm:h-[270px]">
      <canvas ref={cv} className="absolute inset-0 h-full w-full" role="img" aria-label="Peta sirkuit dengan posisi mobil dan lawan" />
      <div className="pointer-events-none absolute left-3 top-2 flex items-baseline gap-1.5">
        <span ref={timeEl} className="num text-lg font-medium text-fg">1:00.0</span>
        <span className="num text-[11px] text-dim">/ 1:00</span>
      </div>
      <div className="pointer-events-none absolute right-3 top-2 flex items-baseline gap-1">
        <span ref={posEl} className="font-display text-2xl font-bold italic leading-none text-glow">P4</span>
        <span className="num text-[11px] text-dim">/ 4</span>
      </div>
      <div ref={lightsEl} className="pointer-events-none absolute left-1/2 top-2.5 flex -translate-x-1/2 gap-1.5 rounded-md border border-line bg-ink-950/80 px-2 py-1.5 opacity-0 transition-opacity duration-300" aria-hidden="true">
        {[0, 1, 2, 3, 4].map((i) => <span key={i} className="h-3.5 w-3.5 rounded-full bg-ink-700" />)}
      </div>
      <div ref={flagEl} className="pointer-events-none absolute left-1/2 top-2 flex -translate-x-1/2 items-center gap-2 rounded-md border border-line bg-ink-950/85 px-2.5 py-1 opacity-0 transition-opacity duration-300" aria-hidden="true">
        <span className="h-4 w-6 rounded-[2px]" style={{ background: "repeating-conic-gradient(#ece9e3 0% 25%, #0c0e11 0% 50%) 0 0 / 8px 8px" }} />
        <span className="label !text-fg">Finis</span>
      </div>
      <span ref={infoEl} className="num pointer-events-none absolute bottom-2 left-3 text-[11px] text-mute" />
      <div className="pointer-events-none absolute bottom-2 right-3 flex items-center gap-3 text-[10px] text-dim">
        <span className="flex items-center gap-1"><i className="h-[3px] w-3 rounded bg-glow" />gas</span>
        <span className="flex items-center gap-1"><i className="h-[3px] w-3 rounded bg-mred" />rem</span>
      </div>
    </div>
  );
}
