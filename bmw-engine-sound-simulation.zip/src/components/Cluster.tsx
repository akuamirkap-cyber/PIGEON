import { useEffect, useRef } from "react";
import { onFrame, useSim } from "../lib/bus";
import { ENGINE_INFO } from "../lib/layers";
import type { Cfg } from "../audio/engine";

const CX = 200, CY = 204, R = 168, MAXR = 8000;
const A0 = 135, SWEEP = 270;
const ang = (rpm: number) => A0 + SWEEP * Math.min(1, Math.max(0, rpm / MAXR));
const pt = (deg: number, r: number) => { const a = (deg * Math.PI) / 180; return [CX + r * Math.cos(a), CY + r * Math.sin(a)]; };
const arc = (a0: number, a1: number, r: number) => {
  const [x0, y0] = pt(a0, r), [x1, y1] = pt(a1, r);
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
};
const ARC_LEN = (R * SWEEP * Math.PI) / 180;
const LEDS = ["#ffb347", "#ffb347", "#ffb347", "#ff8a2b", "#ff8a2b", "#ff8a2b", "#ef3340", "#ef3340", "#ef3340"];

const STATUS: Record<string, { text: string; cls: string }> = {
  off: { text: "ENGINE OFF", cls: "text-dim" },
  prime: { text: "IGNITION", cls: "text-mute" },
  crank: { text: "STARTER", cls: "text-glow" },
  cold: { text: "COLD START · FAST IDLE", cls: "text-ice" },
  launch: { text: "LAUNCH CONTROL", cls: "text-glow" },
  limit: { text: "REV LIMITER", cls: "text-mred" },
  tc: { text: "DSC AKTIF", cls: "text-glow" },
  drift: { text: "OVERSTEER", cls: "text-mred" },
  burble: { text: "OVERRUN BURBLE", cls: "text-glow" },
  run: { text: "", cls: "text-dim" },
};

function Stat({ label, unit, r, bar, color }: { label: string; unit: string; r: React.RefObject<HTMLSpanElement | null>; bar?: React.RefObject<HTMLDivElement | null>; color?: string }) {
  return (
    <div className="min-w-0 border-l border-line pl-3 first:border-l-0 first:pl-0 [&:nth-child(4)]:border-l-0 [&:nth-child(4)]:pl-0 sm:[&:nth-child(4)]:border-l sm:[&:nth-child(4)]:pl-3">
      <div className="label">{label}</div>
      <div className="mt-0.5 flex items-baseline gap-1">
        <span ref={r} className="num text-[1.05rem] font-medium text-fg">0</span>
        <span className="text-xs text-dim">{unit}</span>
      </div>
      {bar && (
        <div className="mt-1.5 h-[3px] overflow-hidden rounded-full bg-ink-700">
          <div ref={bar} className="h-full w-full origin-left" style={{ background: color, transform: "scaleX(0)" }} />
        </div>
      )}
    </div>
  );
}

export default function Cluster({ cfg }: { cfg: Cfg }) {
  const info = ENGINE_INFO[cfg.engine];
  const needle = useRef<SVGGElement>(null);
  const prog = useRef<SVGPathElement>(null);
  const rpmTxt = useRef<SVGTextElement>(null);
  const spdTxt = useRef<SVGTextElement>(null);
  const leds = useRef<SVGGElement>(null);
  const boostV = useRef<HTMLSpanElement>(null), boostB = useRef<HTMLDivElement>(null);
  const thrV = useRef<HTMLSpanElement>(null), thrB = useRef<HTMLDivElement>(null);
  const brkV = useRef<HTMLSpanElement>(null), brkB = useRef<HTMLDivElement>(null);
  const oilV = useRef<HTMLSpanElement>(null), oilB = useRef<HTMLDivElement>(null);
  const tqV = useRef<HTMLSpanElement>(null), hpV = useRef<HTMLSpanElement>(null);
  const redline = info.redline;

  const gear = useSim((s) => s.gear);
  const shifting = useSim((s) => s.sh > 0);
  const status = useSim((s) =>
    s.es === 0 ? "off" : s.es === 1 ? "prime" : s.es === 2 ? "crank" : s.es === 4 ? "off"
      : s.lim ? "limit" : s.launch ? "launch" : Math.abs(s.beta) > 0.2 ? "drift" : s.tc ? "tc" : s.burble ? "burble" : s.cold > 0.4 ? "cold" : "run");
  const deny = useSim((s) => s.deny);
  const st = STATUS[status];

  useEffect(() => {
    let shown = 0;
    return onFrame((s, dt) => {
      shown += (s.rpm - shown) * Math.min(1, dt * 30);
      const a = ang(shown);
      needle.current?.setAttribute("transform", `rotate(${a.toFixed(2)} ${CX} ${CY})`);
      const hot = s.lim ? "#ef3340" : "#ff8a2b";
      if (prog.current) { prog.current.style.strokeDasharray = `${(ARC_LEN * (a - A0)) / SWEEP} ${ARC_LEN}`; prog.current.style.stroke = hot; }
      if (rpmTxt.current) rpmTxt.current.textContent = String(Math.round(shown / 10) * 10);
      if (spdTxt.current) spdTxt.current.textContent = String(Math.round(s.v * 3.6));
      if (leds.current) {
        const f = (s.rpm - redline * 0.68) / (redline * 0.3);
        const n = s.lim ? 9 : Math.floor(Math.max(0, Math.min(1, f)) * 9);
        const ch = leds.current.children;
        for (let i = 0; i < ch.length; i++) (ch[i] as SVGElement).style.opacity = i < n ? "1" : "0.12";
        leds.current.classList.toggle("flash", !!s.lim);
      }
      const set = (el: HTMLElement | null, t: string) => { if (el && el.textContent !== t) el.textContent = t; };
      const bar = (el: HTMLElement | null, v: number) => { if (el) el.style.transform = `scaleX(${Math.max(0, Math.min(1, v)).toFixed(3)})`; };
      set(boostV.current, s.boost.toFixed(2)); bar(boostB.current, s.boost / 1.5);
      set(thrV.current, String(Math.round(s.thr * 100))); bar(thrB.current, s.thr);
      set(brkV.current, String(Math.round(s.brk * 100))); bar(brkB.current, s.brk);
      const oil = 18 + 77 * Math.pow(1 - s.cold, 0.8);
      set(oilV.current, String(Math.round(oil))); bar(oilB.current, (oil - 18) / 77);
      set(tqV.current, String(Math.round(s.tq)));
      set(hpV.current, String(Math.round((s.tq * s.rpm) / 7023)));
    });
  }, [redline]);

  const ticks = [];
  for (let i = 0; i <= 32; i++) {
    const rpm = i * 250, major = i % 4 === 0, half = i % 2 === 0;
    const a = ang(rpm);
    const [x0, y0] = pt(a, R - (major ? 20 : half ? 12 : 7));
    const [x1, y1] = pt(a, R - 2);
    const red = rpm >= redline;
    ticks.push(<line key={i} x1={x0} y1={y0} x2={x1} y2={y1} stroke={red ? "#ef3340" : major ? "#ece9e3" : "#5a606a"} strokeWidth={major ? 2.2 : 1.2} />);
    if (major) {
      const [tx, ty] = pt(a, R - 38);
      ticks.push(<text key={`t${i}`} x={tx} y={ty + 8} textAnchor="middle" fontSize="23" fontWeight="600" fill={red ? "#ef3340" : "#a3a8b1"} style={{ fontFamily: "var(--font-display)" }}>{i / 4}</text>);
    }
  }

  return (
    <div>
      <div className="relative mx-auto w-full max-w-[400px]">
        <svg viewBox="0 0 400 372" className="block w-full" role="img" aria-label="Takometer, gigi, dan kecepatan">
          <defs>
            <filter id="glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="4" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
            <radialGradient id="face" cx="50%" cy="50%" r="50%"><stop offset="60%" stopColor="#0c0e11" /><stop offset="100%" stopColor="#14171c" /></radialGradient>
          </defs>
          <circle cx={CX} cy={CY} r={R + 12} fill="url(#face)" stroke="#272c34" />
          <path d={arc(A0, A0 + SWEEP, R)} fill="none" stroke="#20242b" strokeWidth="5" strokeLinecap="round" />
          <path d={arc(ang(redline), A0 + SWEEP, R)} fill="none" stroke="#ef3340" strokeWidth="5" strokeLinecap="round" opacity="0.85" />
          <path ref={prog} d={arc(A0, A0 + SWEEP, R)} fill="none" stroke="#ff8a2b" strokeWidth="5" strokeLinecap="round" filter="url(#glow)" style={{ strokeDasharray: `0 ${ARC_LEN}` }} />
          {ticks}
          <g ref={leds}>
            {LEDS.map((c, i) => <rect key={i} x={CX - 76 + i * 17.4} y={104} width="13" height="5" rx="1.5" fill={c} style={{ opacity: 0.12 }} />)}
          </g>
          <text x={CX} y={136} textAnchor="middle" fontSize="12" letterSpacing="2.2" fontWeight="600" className={`${st.cls} ${status === "limit" ? "flash" : ""}`} fill="currentColor" style={{ fontFamily: "var(--font-display)" }}>{deny ? "DOWNSHIFT DITOLAK · OVER-REV" : st.text}</text>
          <text x={CX} y={248} textAnchor="middle" fontSize="128" fontWeight="700" fontStyle="italic" fill={shifting ? "#ff8a2b" : "#ece9e3"} style={{ fontFamily: "var(--font-display)" }}>{gear === 0 ? "N" : gear}</text>
          <text ref={spdTxt} x={CX} y={296} textAnchor="middle" fontSize="38" fontWeight="600" fill="#ece9e3" style={{ fontFamily: "var(--font-display)" }}>0</text>
          <text x={CX} y={313} textAnchor="middle" fontSize="11" letterSpacing="2" fill="#7d838e" style={{ fontFamily: "var(--font-display)" }}>KM/H</text>
          <text ref={rpmTxt} x={CX} y={350} textAnchor="middle" fontSize="17" fill="#a3a8b1" style={{ fontFamily: "var(--font-mono)" }}>0</text>
          <text x={CX} y={365} textAnchor="middle" fontSize="10" letterSpacing="2" fill="#7d838e" style={{ fontFamily: "var(--font-display)" }}>RPM</text>
          <text x={CX - 104} y={352} textAnchor="middle" fontSize="10" letterSpacing="1.6" fill="#7d838e" style={{ fontFamily: "var(--font-display)" }}>×1000</text>
          <g ref={needle} transform={`rotate(${A0} ${CX} ${CY})`}>
            <line x1={CX + 92} y1={CY} x2={CX + R + 4} y2={CY} stroke="#ff8a2b" strokeWidth="3.2" strokeLinecap="round" filter="url(#glow)" />
          </g>
        </svg>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-x-3 gap-y-3 border-t border-line pt-3 sm:grid-cols-6">
        <Stat label="Boost" unit="bar" r={boostV} bar={boostB} color="#81c4ff" />
        <Stat label="Gas" unit="%" r={thrV} bar={thrB} color="#ff8a2b" />
        <Stat label="Rem" unit="%" r={brkV} bar={brkB} color="#ef3340" />
        <Stat label="Oli" unit="°C" r={oilV} bar={oilB} color="#ece9e3" />
        <Stat label="Torsi" unit="Nm" r={tqV} />
        <Stat label="Daya" unit="hp" r={hpV} />
      </div>
    </div>
  );
}
