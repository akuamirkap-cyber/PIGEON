/*
 * Sirkuit + pembalap otomatis untuk "Balapan 1 menit".
 * Logika murni (tanpa DOM) — bisa disimulasikan di Node bersama inti audio.
 */

export interface Track {
  n: number; ds: number; len: number;
  x: Float32Array; y: Float32Array; hx: Float32Array; hy: Float32Array;
  kappa: Float32Array; prof: Float32Array; kerb: Uint8Array; slide: Uint8Array;
  bumps: number[]; apex: number[];
  minX: number; maxX: number; minY: number; maxY: number;
}

// titik kontrol sirkuit (meter). Lurus utama → T1 → hairpin → T3 → esses → sweeper → T7 → T8
const CTRL: [number, number][] = [
  [120, 420], [260, 420], [400, 420], [540, 420], [640, 420],
  [712, 404], [748, 352],
  [752, 290], [752, 245],
  [744, 212], [722, 196], [700, 212], [692, 245],
  [692, 292],
  [682, 330], [648, 346],
  [590, 346], [530, 346],
  [478, 338], [446, 308], [414, 272], [370, 256],
  [310, 256], [255, 256],
  [196, 242], [156, 196], [142, 140],
  [132, 92], [92, 74], [52, 92], [42, 140],
  [42, 210], [42, 290], [42, 345],
  [54, 392], [84, 416],
];

const A_LAT = 0.9 * 1.15 * 9.81; // pakai 90% grip → ban berdecit halus di tikungan
const A_BRAKE = 8.4;
const V_MAX = 83;

export function buildTrack(): Track {
  const P = CTRL, m = P.length;
  const dx: number[] = [], dy: number[] = [];
  for (let i = 0; i < m; i++) {
    const p0 = P[(i - 1 + m) % m], p1 = P[i], p2 = P[(i + 1) % m], p3 = P[(i + 2) % m];
    for (let k = 0; k < 28; k++) {
      const t = k / 28, t2 = t * t, t3 = t2 * t;
      dx.push(0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3));
      dy.push(0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3));
    }
  }
  // resample per panjang busur
  const D = dx.length, cum = new Float64Array(D + 1);
  for (let i = 0; i < D; i++) { const j = (i + 1) % D; cum[i + 1] = cum[i] + Math.hypot(dx[j] - dx[i], dy[j] - dy[i]); }
  const len = cum[D], n = Math.round(len / 2), ds = len / n;
  const x = new Float32Array(n), y = new Float32Array(n);
  for (let i = 0, k = 0; i < n; i++) {
    const s = i * ds;
    while (cum[k + 1] < s) k++;
    const f = (s - cum[k]) / (cum[k + 1] - cum[k] || 1), j = (k + 1) % D;
    x[i] = dx[k] + (dx[j] - dx[k]) * f; y[i] = dy[k] + (dy[j] - dy[k]) * f;
  }
  // arah & kelengkungan
  const hx = new Float32Array(n), hy = new Float32Array(n), th = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const a = (i - 1 + n) % n, b = (i + 1) % n;
    const tx = x[b] - x[a], ty = y[b] - y[a], l = Math.hypot(tx, ty) || 1;
    hx[i] = tx / l; hy[i] = ty / l; th[i] = Math.atan2(ty, tx);
  }
  let kap = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let d = th[(i + 2) % n] - th[(i - 2 + n) % n];
    while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
    kap[i] = d / (4 * ds);
  }
  for (let pass = 0; pass < 2; pass++) {
    const o = new Float32Array(n);
    for (let i = 0; i < n; i++) { let a = 0; for (let k = -3; k <= 3; k++) a += kap[(i + k + n) % n]; o[i] = a / 7; }
    kap = o;
  }
  // profil kecepatan: batas tikungan lalu sapuan mundur untuk pengereman
  const prof = new Float32Array(n);
  for (let i = 0; i < n; i++) prof[i] = Math.min(V_MAX, Math.sqrt(A_LAT / Math.max(1e-4, Math.abs(kap[i]))));
  for (let pass = 0; pass < 2; pass++) for (let i = n - 1; i >= 0; i--) {
    const nx = prof[(i + 1) % n];
    prof[i] = Math.min(prof[i], Math.sqrt(nx * nx + 2 * A_BRAKE * ds));
  }
  // apex → zona kerb; hairpin → zona power-slide
  const kerb = new Uint8Array(n), slide = new Uint8Array(n), apex: number[] = [];
  let worst = 0, worstK = 0;
  for (let i = 0; i < n; i++) {
    const k0 = Math.abs(kap[i]);
    if (k0 > 0.011 && k0 >= Math.abs(kap[(i - 1 + n) % n]) && k0 > Math.abs(kap[(i + 1) % n])) {
      if (apex.length && i - apex[apex.length - 1] < 12) continue;
      apex.push(i);
      if (k0 > worstK) { worstK = k0; worst = i; }
    }
  }
  apex.forEach((a, idx) => {
    for (let k = -5; k <= 7; k++) kerb[(a + k + n) % n] = 1;
    if (idx % 2 === 0) for (let k = 13; k <= 24; k++) kerb[(a + k) % n] = 1; // kerb keluar tikungan
  });
  for (let k = 4; k <= 24; k++) { slide[(worst + k) % n] = 1; kerb[(worst + k) % n] = 0; }
  let minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
  for (let i = 0; i < n; i++) { minX = Math.min(minX, x[i]); maxX = Math.max(maxX, x[i]); minY = Math.min(minY, y[i]); maxY = Math.max(maxY, y[i]); }
  return { n, ds, len, x, y, hx, hy, kappa: kap, prof, kerb, slide, bumps: [300, 1560], apex, minX, maxX, minY, maxY };
}

export interface SimIn { v: number; dist: number; es: number; gear: number }
export interface RaceOut {
  throttle: number; brake: number; steer: number; kerb: number;
  cmds: string[]; dsc: number; caption: string;
}
export interface Ghost { s: number; v: number; pf: number; cf: number; delay: number; color: string; name: string }
export type Phase = "pre" | "lights" | "race" | "flag" | "done";

export const RACE_LEN = 60;
const LIGHTS_OUT = 4.6;

export class Race {
  track: Track;
  /** waktu balapan (detik); negatif = persiapan */
  t: number;
  phase: Phase = "pre";
  lights = 0;
  pos = 4;
  s = 0;
  dist = 0;
  lap = 1;
  ghosts: Ghost[];
  private done = new Set<string>();
  private cap = ""; private capT = 0;
  out: RaceOut = { throttle: 0, brake: 0, steer: 0, kerb: 0, cmds: [], dsc: 1, caption: "" };

  constructor(track: Track, engineRunning: boolean) {
    this.track = track;
    this.t = engineRunning ? -0.8 : -3.4;
    this.ghosts = [
      { s: 24, v: 0, pf: 0.78, cf: 0.935, delay: 0.16, color: "#81c4ff", name: "P1" },
      { s: 16, v: 0, pf: 0.74, cf: 0.91, delay: 0.24, color: "#ece9e3", name: "P2" },
      { s: 8, v: 0, pf: 0.7, cf: 0.89, delay: 0.3, color: "#a3a8b1", name: "P3" },
    ];
  }

  private once(key: string, at: number, cmd: string, cmds: string[]) {
    if (this.t >= at && !this.done.has(key)) { this.done.add(key); cmds.push(cmd); }
  }
  private at(arr: Float32Array, s: number) {
    const T = this.track; let i = Math.floor(s / T.ds) % T.n; if (i < 0) i += T.n;
    return arr[i];
  }
  private setCap(c: string, dt: number) {
    this.capT += dt;
    if (c !== this.cap && (this.capT > 0.9 || !this.cap)) { this.cap = c; this.capT = 0; }
    return this.cap;
  }

  step(sim: SimIn, dt: number): RaceOut {
    const T = this.track, o = this.out, cmds: string[] = [];
    this.t += dt;
    const t = this.t;
    o.throttle = 0; o.brake = 0; o.steer = 0; o.kerb = 0; o.dsc = 1;

    if (!this.done.has("grid")) { this.done.add("grid"); cmds.push("grid"); if (sim.es === 0 || sim.es === 4) cmds.push("start"); }
    // odometer baru dipercaya setelah reset grid terlihat di state simulasi
    else if (!this.done.has("gridSeen") && sim.dist < 0.5) this.done.add("gridSeen");
    this.dist = this.done.has("gridSeen") ? sim.dist : 0;
    this.s = this.dist % T.len;
    this.lap = 1 + Math.floor(this.dist / T.len);

    if (t < 0) {
      this.phase = "pre"; o.brake = 1;
      o.caption = sim.es === 3 ? "Grid start — bersiap" : "Menyalakan mesin…";
    } else if (t < LIGHTS_OUT) {
      this.phase = "lights";
      this.lights = Math.max(0, Math.min(5, Math.floor((t - 0.6) / 0.75) + 1));
      this.once("gear", 0.3, "up", cmds);
      o.brake = 1; o.throttle = t > 1.3 ? 1 : 0;
      o.caption = t > 1.3 ? "Lampu merah — launch control menahan 3.400 rpm" : "Lampu start";
    } else if (t < RACE_LEN) {
      this.phase = "race"; this.lights = 0;
      const v = sim.v, s = this.s;
      const vT = this.at(T.prof, s + v * 0.22 + 4);
      const kap = this.at(T.kappa, s + v * 0.12);
      const idx = Math.floor(s / T.ds) % T.n;
      const sliding = T.slide[idx] === 1;
      let cap: string;
      if (v > vT + 0.8) { o.brake = Math.min(1, 0.25 + (v - vT) * 0.22); cap = "Rem keras — downshift blip + burble"; }
      else {
        o.throttle = Math.min(1, Math.max(0, (vT - v) * 0.6 + 0.15));
        cap = Math.abs(kap) > 0.006 ? "Menikung di batas grip — ban berdecit" : o.throttle > 0.9 ? "Gas penuh — turbo spool, DCT upshift crack" : "Keluar tikungan";
      }
      o.steer = Math.max(-1, Math.min(1, (5.5 + 0.05 * v * v) * kap));
      o.kerb = t > LIGHTS_OUT + 4 ? T.kerb[idx] : 0;
      if (o.kerb) cap = "Lindas kerb";
      if (sliding) { o.dsc = 0; o.throttle = 1; o.brake = 0; cap = "Hairpin — power slide, DSC off"; }
      if (t < LIGHTS_OUT + 1.6) cap = "START! Launch";
      for (let b = 0; b < T.bumps.length; b++) {
        const key = `bump${b}-${this.lap}`;
        if (s >= T.bumps[b] && s < T.bumps[b] + 30 && !this.done.has(key)) { this.done.add(key); cmds.push("bump"); }
      }
      o.caption = this.setCap(cap, dt);
    } else {
      this.phase = sim.v > 1 ? "flag" : "done";
      o.brake = sim.v > 1 ? 0.55 : 0.3;
      const kap = this.at(T.kappa, this.s + sim.v * 0.12);
      o.steer = Math.max(-1, Math.min(1, (5.5 + 0.05 * sim.v * sim.v) * kap));
      if (sim.v <= 1) this.once("neutral", RACE_LEN, "neutral", cmds);
      o.caption = `Bendera finis — P${this.pos} · ${(this.dist / 1000).toFixed(2)} km`;
    }

    // lawan (visual): mengikuti profil yang sama dengan tenaga & kecepatan tikung sedikit lebih rendah
    if (t >= 0) for (const g of this.ghosts) {
      if (t < LIGHTS_OUT + g.delay) continue;
      const target = t < RACE_LEN ? this.at(T.prof, g.s + g.v * 0.22 + 4) * g.cf : 0;
      if (g.v > target) g.v = Math.max(target, g.v - (t < RACE_LEN ? 9 : 6) * dt);
      else g.v = Math.min(target, g.v + (Math.min(6.6, (178 * g.pf) / Math.max(g.v, 5)) - 0.000256 * g.v * g.v) * dt);
      g.s += g.v * dt;
    }
    if (t < RACE_LEN) this.pos = 1 + this.ghosts.filter((g) => g.s > this.dist).length;

    o.cmds = cmds;
    return o;
  }
}

/** state runtime bersama antara App (yang menjalankan) dan peta (yang menggambar) */
export const raceRT: { race: Race | null; track: Track | null } = { race: null, track: null };
export function getTrack(): Track { return (raceRT.track ??= buildTrack()); }
