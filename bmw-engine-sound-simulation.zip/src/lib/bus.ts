import { useEffect, useRef, useState } from "react";
import { sound, type SimState } from "../audio/engine";

/* ---------- satu loop rAF untuk semua visual ---------- */
type Sub = (s: SimState, dt: number, t: number) => void;
const subs = new Set<Sub>();
let raf = 0;
let last = 0;
function loop(t: number) {
  const dt = Math.min(0.05, last ? (t - last) / 1000 : 0.016);
  last = t;
  const s = sound.state;
  subs.forEach((f) => f(s, dt, t / 1000));
  raf = subs.size ? requestAnimationFrame(loop) : 0;
}
export function onFrame(fn: Sub) {
  subs.add(fn);
  if (!raf) { last = 0; raf = requestAnimationFrame(loop); }
  return () => { subs.delete(fn); };
}

/** Ambil nilai diskret dari state simulasi; re-render hanya saat berubah. */
export function useSim<T>(sel: (s: SimState) => T): T {
  const selRef = useRef(sel);
  selRef.current = sel;
  const [v, setV] = useState<T>(() => sel(sound.state));
  useEffect(() => onFrame((s) => { const n = selRef.current(s); setV((p) => (Object.is(p, n) ? p : n)); }), []);
  return v;
}

/* ---------- input gabungan: keyboard + pointer + makro ---------- */
export interface Inputs { throttle: number; brake: number; steer: number; handbrake: number; kerb: number; skid: number }
const zero = (): Inputs => ({ throttle: 0, brake: 0, steer: 0, handbrake: 0, kerb: 0, skid: 0 });
const sources: Record<"key" | "ptr" | "macro", Inputs> = { key: zero(), ptr: zero(), macro: zero() };
let sent = zero();

export function setInput(src: "key" | "ptr" | "macro", patch: Partial<Inputs>) {
  Object.assign(sources[src], patch);
  const { key, ptr, macro } = sources;
  const m: Inputs = {
    throttle: Math.max(key.throttle, ptr.throttle, macro.throttle),
    brake: Math.max(key.brake, ptr.brake, macro.brake),
    steer: Math.max(-1, Math.min(1, key.steer + ptr.steer + macro.steer)),
    handbrake: Math.max(key.handbrake, ptr.handbrake, macro.handbrake),
    kerb: Math.max(key.kerb, ptr.kerb, macro.kerb),
    skid: Math.max(key.skid, ptr.skid, macro.skid),
  };
  const diff: Partial<Inputs> = {};
  let any = false;
  (Object.keys(m) as (keyof Inputs)[]).forEach((k) => { if (m[k] !== sent[k]) { diff[k] = m[k]; any = true; } });
  if (any) { sent = m; sound.post({ t: "in", v: diff }); }
}
export const getInputs = () => sent;
export function clearInputs(src: "key" | "ptr" | "macro") { setInput(src, zero()); }
sound.onReady(() => sound.post({ t: "in", v: sent }));

/* ---------- makro berjadwal (showcase & audisi layer) ---------- */
let timers: number[] = [];
let endCb: (() => void) | null = null;
export function cancelMacro() {
  timers.forEach((t) => window.clearTimeout(t));
  timers = [];
  clearInputs("macro");
  const cb = endCb; endCb = null; cb?.();
}
export function runMacro(steps: [number, () => void][], total: number, onEnd?: () => void) {
  cancelMacro();
  endCb = onEnd ?? null;
  for (const [at, fn] of steps) timers.push(window.setTimeout(fn, at * 1000));
  timers.push(window.setTimeout(cancelMacro, total * 1000));
}
export const macroActive = () => timers.length > 0;
