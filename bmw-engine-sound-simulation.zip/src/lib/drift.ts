/*
 * Sesi drift otomatis (~26 detik): burnout launch → inisiasi handbrake + clutch kick →
 * tahan drift dengan modulasi gas → transisi kiri/kanan → keluar.
 * Logika murni agar bisa disimulasikan di Node bersama inti audio.
 */
export interface DriftIn { v: number; rpm: number; gear: number; es: number; sr: number; beta: number }
export interface DriftOut { throttle: number; brake: number; steer: number; handbrake: number; cmds: string[]; caption: string }

export class DriftRun {
  t: number;
  st = 0;
  stT = 0;
  done = false;
  out: DriftOut = { throttle: 0, brake: 0, steer: 0, handbrake: 0, cmds: [], caption: "" };
  private lim: number;
  private sentGrid = false;
  private shiftCd = 0;
  private steer = 0;

  constructor(engineRunning: boolean, limiter: number) {
    this.t = engineRunning ? -0.7 : -3.3;
    this.lim = limiter;
  }

  private go(n: number) { this.st = n; this.stT = 0; }

  /** modulasi gas: jaga roda tetap berputar liar, sesekali angkat gas → rpm naik-turun khas drift */
  private mod(sim: DriftIn, ride: boolean) {
    if (ride || sim.sr < 0.45) return 1;
    if (sim.rpm > this.lim - 380) return 0.3;
    if (sim.rpm < this.lim - 2400) return 1;
    return (this.stT * 1.2) % 1 < 0.6 ? 1 : 0.45;
  }

  step(sim: DriftIn, dt: number): DriftOut {
    const o = this.out, cmds: string[] = [];
    this.t += dt; this.stT += dt; this.shiftCd -= dt;
    o.throttle = 0; o.brake = 0; o.handbrake = 0;
    let target = 0;
    if (!this.sentGrid) { this.sentGrid = true; cmds.push("grid"); if (sim.es === 0 || sim.es === 4) cmds.push("start"); }

    switch (this.st) {
      case 0:
        o.brake = 1; o.caption = sim.es === 3 ? "Bersiap — DSC off" : "Menyalakan mesin…";
        if (this.t >= 0 && sim.es === 3) { cmds.push("up"); this.go(1); }
        break;
      case 1: // tahan rem + gas (launch control) lalu lepas → burnout launch sampai gigi 3
        o.throttle = 1;
        if (this.stT < 1.2) { o.brake = 1; o.caption = "Rem + gas penuh — putaran ditahan, knalpot meletup"; break; }
        o.caption = "Burnout launch — roda belakang spin";
        if (sim.gear > 0 && sim.gear < 3 && sim.rpm > this.lim - 650 && this.shiftCd <= 0) { cmds.push("up"); this.shiftCd = 0.55; }
        if ((sim.gear >= 3 && sim.v > 23) || this.stT > 12) this.go(2);
        break;
      case 2: // inisiasi
        o.throttle = 1; target = 0.9; o.handbrake = this.stT < 0.4 ? 1 : 0;
        o.caption = "Inisiasi — handbrake + clutch kick";
        if (this.stT > 0.6) this.go(3);
        break;
      case 3: // tahan kiri
        target = 0.8; o.throttle = this.mod(sim, false);
        o.caption = "Tahan drift — modulasi gas, ban melengking";
        if (this.stT > 5.2) this.go(4);
        break;
      case 4: // transisi → kanan
      case 6: { // transisi → kiri
        const dir = this.st === 4 ? -1 : 1;
        target = 0.85 * dir;
        if (this.stT < 0.32) { o.throttle = 0; o.caption = "Transisi — angkat gas, ban menggigit lalu lepas lagi"; }
        else { o.throttle = 1; o.handbrake = this.stT < 0.52 ? 1 : 0; }
        if (this.stT > 0.8) this.go(this.st + 1);
        break;
      }
      case 5: // tahan kanan, sempat mentok limiter
        target = -0.8; o.throttle = this.mod(sim, this.stT > 1.8 && this.stT < 3.5);
        o.caption = this.stT > 1.8 && this.stT < 3.5 ? "Gas penuh — mentok rev limiter sambil sliding" : "Tahan drift kanan";
        if (this.stT > 5.4) this.go(6);
        break;
      case 7: // tahan kiri terakhir
        target = 0.8; o.throttle = this.mod(sim, false);
        o.caption = "Drift terakhir";
        if (this.stT > 3.6) this.go(8);
        break;
      default: // keluar
        target = 0;
        o.throttle = this.stT < 0.5 ? 0.4 : 0;
        o.brake = this.stT > 1 ? 0.7 : 0;
        o.caption = "Keluar drift — ban menggigit kembali";
        if (this.stT > 1.1 && sim.gear > 2 && sim.rpm < 3900 && this.shiftCd <= 0) { cmds.push("down"); this.shiftCd = 0.7; }
        if (this.stT > 1.2 && sim.v < 1 && !this.done) { cmds.push("neutral"); this.done = true; }
    }
    // setir bergerak cepat tapi tidak instan
    this.steer += Math.max(-dt * 6, Math.min(dt * 6, target - this.steer));
    o.steer = this.steer;
    o.cmds = cmds;
    return o;
  }
}
