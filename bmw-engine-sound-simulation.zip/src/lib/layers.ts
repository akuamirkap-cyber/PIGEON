export interface LayerDef { id: number; name: string; desc: string }
export interface GroupDef { title: string; color: string; layers: LayerDef[] }

export const GROUPS: GroupDef[] = [
  {
    title: "Mesin & Knalpot", color: "#ff8a2b",
    layers: [
      { id: 0, name: "Cold Start / Ignition", desc: "Gong start, starter, raungan awal & fast-idle dingin" },
      { id: 1, name: "Engine Idle", desc: "Deep rumble stasioner + tik injektor" },
      { id: 2, name: "Low – Mid RPM", desc: "Geraman berat & padat 1.200 – 4.500 rpm" },
      { id: 3, name: "High RPM · Raspy Scream", desc: "Lengkingan logam M-Series menuju redline" },
      { id: 4, name: "Exhaust Burble", desc: "Crackle kering bergerombol + bang sesekali saat gas dilepas" },
      { id: 5, name: "Rev Limiter", desc: "Hard-cut rat-tat-tat di putaran maksimal" },
    ],
  },
  {
    title: "Turbo & Intake", color: "#81c4ff",
    layers: [
      { id: 6, name: "Twin-Turbo Spool", desc: "Desing dua turbin yang sedikit berbeda nada" },
      { id: 7, name: "Diverter / Blow-Off", desc: "Desis buang tekanan saat lepas gas & pindah gigi" },
      { id: 8, name: "Carbon Air Intake", desc: "Induction roar dari ruang mesin depan" },
    ],
  },
  {
    title: "Transmisi", color: "#ece9e3",
    layers: [
      { id: 9, name: "DCT Upshift Crack", desc: "Ignition-cut lalu ledakan padat di knalpot" },
      { id: 10, name: "Manual Gear Shift", desc: "Klik – gate – thunk tuas yang notchy" },
      { id: 11, name: "Transmission Whine", desc: "Dengung gigi & gardan saat tarik / deselerasi" },
    ],
  },
  {
    title: "Ban & Fisika Jalan", color: "#ef3340",
    layers: [
      { id: 12, name: "Tire Screech / Drift", desc: "Lengking + roar karet + desis asap; nada ikut kecepatan selip" },
      { id: 13, name: "Tire Roll · Asphalt / Curb", desc: "Gesekan aspal, angin, kampas rem, getaran kerb" },
      { id: 14, name: "Suspension Thud", desc: "Pukulan padat bodi + ban + top-mount, depan → belakang" },
    ],
  },
];

export const ENGINE_INFO = {
  s55: { label: "S55 · I6 3.0", long: "Inline-6 3.0 L Twin-Turbo", order: [1, 5, 3, 6, 2, 4], redline: 7600, cyl: 6, car: "M4 F82", limiter: 7550 },
  s54: { label: "S54 · I6 3.2", long: "Inline-6 3.2 L NA · Airbox Karbon", order: [1, 5, 3, 6, 2, 4], redline: 7900, cyl: 6, car: "M3 CSL E46", limiter: 7900 },
  s63: { label: "S63 · V8 4.4", long: "V8 4.4 L Twin-Turbo Hot-V", order: [1, 5, 4, 8, 6, 3, 7, 2], redline: 7200, cyl: 8, car: "M5 F10", limiter: 7150 },
} as const;
