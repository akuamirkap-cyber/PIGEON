import { mk, SR } from './sim.mjs';
import { buildTrack, Race } from '/tmp/race.mjs';
const T = buildTrack();
// rekam jejak pemain sekali, lalu uji beberapa set lawan terhadap jejak itu
const sets = JSON.parse(process.argv[2]);
const c = mk(); c.onMessage({ t: 'cfg', v: { trans: 'dct', auto: 1, mode: 2, dsc: 1 } });
const races = sets.map((g) => { const r = new Race(T, false); g.forEach((p, i) => { r.ghosts[i].pf = p[0]; r.ghosts[i].cf = p[1]; }); return r; });
const N = SR / 60; const L = new Float32Array(N), R = new Float32Array(N);
const logs = sets.map(() => []); let gears = '';
for (let f = 0; f < 60 * 64; f++) {
  let o;
  races.forEach((r, i) => { const out = r.step({ v: c.v, dist: c.dist, es: c.estate, gear: c.gear }, 1 / 60); if (i === 0) o = { ...out, cmds: [...out.cmds] }; if (f % 300 === 0 && r.t > 4) logs[i].push(`T${Math.round(r.t)}:P${r.pos}[${r.ghosts.map((g) => (g.s - r.dist).toFixed(0)).join(',')}]`); });
  Object.assign(c.inp, { throttle: o.throttle, brake: o.brake, steer: o.steer, kerb: o.kerb }); for (const k of o.cmds) c.cmd(k); c.cfg.dsc = o.dsc;
  for (let k = 0; k < N; k += 128) c.render(L.subarray(k, Math.min(N, k + 128)), R.subarray(k, Math.min(N, k + 128)), Math.min(128, N - k));
  if (f % 120 === 0 && races[0].t > 5) gears += c.gear;
}
console.log('dist', c.dist.toFixed(0), 'gears/2s', gears);
logs.forEach((l, i) => console.log(JSON.stringify(sets[i]), '\n  ', l.join(' ')));
