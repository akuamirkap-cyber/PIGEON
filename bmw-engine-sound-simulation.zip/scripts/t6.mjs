import { mk, run, fftBands, SR } from './sim.mjs';
import { report } from './harm.mjs';
function ev(label, sec, f) { const c = mk(); f(c); const r = run(c, sec, label, { every: sec + 1 }); console.log('   ', fftBands(r.L, SR)); }
ev('skid 0.9 (drift)', 1.2, (c) => (c.inp.skid = 0.9));
ev('skid 0.3 (ringan)', 1.2, (c) => (c.inp.skid = 0.3));
ev('start gong', 0.35, (c) => c.cmd('start'));
report('s54 idle', 's54', 880, 0.06);
report('s54 3800 WOT', 's54', 3800, 1);
report('s54 7600 WOT', 's54', 7600, 1);
report('s55 3800 WOT', 's55', 3800, 1);
report('s55 7000 WOT', 's55', 7000, 1);
