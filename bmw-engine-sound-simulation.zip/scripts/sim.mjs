import fs from 'fs';
const code = fs.readFileSync('src/audio/core.worklet.js', 'utf8');
export const BMWCore = new Function(code + '\nreturn BMWCore;')();
export const SR = 48000;
export function mk() { const c = new BMWCore(SR); c.last = null; c.post = (m) => (c.last = m); return c; }
const db = (x) => (x > 0 ? (20 * Math.log10(x)).toFixed(1) : '-inf');
export function run(c, sec, label, opt = {}) {
  const n = Math.round(sec * SR);
  const L = new Float32Array(n), R = new Float32Array(n);
  const every = opt.every || 0;
  let o = 0, rows = [];
  const chunk = every ? Math.round(every * SR / 128) * 128 : n;
  while (o < n) {
    const m = Math.min(chunk, n - o);
    const l = L.subarray(o, o + m), r = R.subarray(o, o + m);
    // render in 128 blocks
    for (let k = 0; k < m; k += 128) c.render(l.subarray(k, Math.min(m, k + 128)), r.subarray(k, Math.min(m, k + 128)), Math.min(128, m - k));
    let pk = 0, ss = 0, bad = 0;
    for (let i = 0; i < m; i++) { const x = l[i]; if (!Number.isFinite(x)) bad++; const a = Math.abs(x); if (a > pk) pk = a; ss += x * x; }
    rows.push(`${label.padEnd(14)} t=${((o + m) / SR).toFixed(2).padStart(5)} rpm=${c.rpm.toFixed(0).padStart(5)} g=${c.gear} kmh=${(c.v * 3.6).toFixed(0).padStart(3)} spool=${c.spool.toFixed(2)} load=${c.load.toFixed(2)} cl=${c.clutch.toFixed(2)}${c.locked ? 'L' : ' '} slip=${c.slipR.toFixed(2)} pk=${db(pk)} rms=${db(Math.sqrt(ss / m))}${bad ? ' NAN!' + bad : ''}${c.cut ? ' CUT' : ''}`);
    o += m;
  }
  if (!opt.quiet) console.log(rows.join('\n'));
  return { L, R };
}
export function spectrumPeaks(x, sr, fmax = 600, top = 6) {
  // naive DFT at 1 Hz steps (enough for check)
  const n = Math.min(x.length, sr * 2); const res = [];
  for (let f = 10; f <= fmax; f += 1) { let re = 0, im = 0; const w = 2 * Math.PI * f / sr; for (let i = 0; i < n; i += 2) { re += x[i] * Math.cos(w * i); im += x[i] * Math.sin(w * i); } res.push([f, Math.hypot(re, im) / n * 4]); }
  const pk = []; for (let i = 1; i < res.length - 1; i++) if (res[i][1] > res[i - 1][1] && res[i][1] >= res[i + 1][1]) pk.push(res[i]);
  return pk.sort((a, b) => b[1] - a[1]).slice(0, top).map(([f, a]) => `${f}Hz:${db(a)}`).join('  ');
}
export function band(x, sr, f1, f2) { // crude band energy via DFT sampling
  const n = Math.min(x.length, 16384); let e = 0; const st = (f2 - f1) / 40;
  for (let f = f1; f < f2; f += st) { let re = 0, im = 0; const w = 2 * Math.PI * f / sr; for (let i = 0; i < n; i++) { re += x[i] * Math.cos(w * i); im += x[i] * Math.sin(w * i); } e += (re * re + im * im) / n / n; }
  return db(Math.sqrt(e / 40) * 2);
}
export function fftBands(x, sr, edges = [20, 80, 160, 320, 640, 1280, 2560, 5120, 12000]) {
  const N = 32768; const re = new Float64Array(N), im = new Float64Array(N);
  const st = Math.max(0, x.length - N);
  for (let i = 0; i < N; i++) re[i] = (x[st + i] || 0) * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / N));
  for (let i = 1, j = 0; i < N; i++) { let b = N >> 1; for (; j & b; b >>= 1) j ^= b; j ^= b; if (i < j) { const t = re[i]; re[i] = re[j]; re[j] = t; } }
  for (let len = 2; len <= N; len <<= 1) { const ang = -2 * Math.PI / len; const wr = Math.cos(ang), wi = Math.sin(ang);
    for (let i = 0; i < N; i += len) { let cr = 1, ci = 0; for (let k = 0; k < len / 2; k++) { const a = i + k, b = a + len / 2; const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr; re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti; const t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t; } } }
  const out = [];
  for (let e = 0; e < edges.length - 1; e++) { let p = 0; const a = Math.round(edges[e] * N / sr), b = Math.round(edges[e + 1] * N / sr); for (let k = a; k < b; k++) p += re[k] * re[k] + im[k] * im[k]; out.push(`${edges[e]}-${edges[e + 1]}:${(10 * Math.log10(p * 2 / (N * N * 0.375) + 1e-20)).toFixed(0)}`); }
  return out.join(' ');
}
