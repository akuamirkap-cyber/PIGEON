import { mk, run, fftBands, SR } from './sim.mjs';
export function pinned(eng, rpm, load, cfgv = {}) {
  const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng, ...cfgv } });
  c.cmd('start'); run(c, 2.2, 's', { quiet: true }); c.cold = 0;
  const orig = c.step.bind(c);
  c.step = function (dt) { orig(dt); this.rpm = rpm; this.load = load; this.spool = load; this.cut = false; };
  run(c, 0.6, 's', { quiet: true });
  return c;
}
export function spectrum(x, sr) {
  const N = 32768; const re = new Float64Array(N), im = new Float64Array(N); const st = Math.max(0, x.length - N);
  for (let i = 0; i < N; i++) re[i] = (x[st + i] || 0) * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / N));
  for (let i = 1, j = 0; i < N; i++) { let b = N >> 1; for (; j & b; b >>= 1) j ^= b; j ^= b; if (i < j) { const t = re[i]; re[i] = re[j]; re[j] = t; } }
  for (let len = 2; len <= N; len <<= 1) { const ang = -2 * Math.PI / len; const wr = Math.cos(ang), wi = Math.sin(ang); for (let i = 0; i < N; i += len) { let cr = 1, ci = 0; for (let k = 0; k < len / 2; k++) { const a = i + k, b = a + len / 2; const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr; re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti; const t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t; } } }
  const mag = new Float64Array(N / 2); for (let k = 0; k < N / 2; k++) mag[k] = Math.hypot(re[k], im[k]) * 4 / N;
  return { mag, binHz: sr / N };
}
export function report(label, eng, rpm, load, cfgv) {
  const c = pinned(eng, rpm, load, cfgv); const r = run(c, 0.9, label, { quiet: true });
  const { mag, binHz } = spectrum(r.L, SR); const f0 = rpm / 120 * c.E.cyl;
  const lv = (f) => { const k = Math.round(f / binHz); let m = 0; for (let i = k - 3; i <= k + 3; i++) if (mag[i] > m) m = mag[i]; return 20 * Math.log10(m + 1e-12); };
  const h = []; for (let k = 1; k <= 10; k++) h.push(lv(f0 * k).toFixed(0));
  const half = [0.5, 1.5, 2.5].map((k) => lv(f0 * k).toFixed(0));
  let ss = 0, pk = 0; for (const x of r.L) { ss += x * x; if (Math.abs(x) > pk) pk = Math.abs(x); }
  // noise floor between harmonics around 1-3k (tonal vs noisy)
  let num = 0, den = 0; for (let k = 0; k < mag.length; k++) { const f = k * binHz; num += f * mag[k] * mag[k]; den += mag[k] * mag[k]; }
  console.log(`${label.padEnd(22)} f0=${f0.toFixed(0).padStart(3)}Hz rms=${(10 * Math.log10(ss / r.L.length)).toFixed(1)} pk=${(20 * Math.log10(pk)).toFixed(1)} centroid=${(num / den).toFixed(0)}Hz\n   harmonics 1..10: ${h.join(' ')}   | half-orders: ${half.join(' ')}\n   ${fftBands(r.L, SR)}`);
}
if ((process.argv[1] || '').endsWith('harm.mjs')) {
  const t0 = Date.now();
  report('s55 idle', 's55', 720, 0.05);
  report('s55 2500 cruise', 's55', 2500, 0.25);
  report('s55 4000 WOT', 's55', 4000, 1);
  report('s55 7000 WOT', 's55', 7000, 1);
  report('s63 3500 WOT', 's63', 3500, 1);
  report('s63 6500 WOT', 's63', 6500, 1);
  console.log('ms', Date.now() - t0);
}
