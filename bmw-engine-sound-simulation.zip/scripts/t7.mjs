import { mk, run, fftBands, SR } from './sim.mjs';
function fresh(eng = 's55') { const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng } }); c.cmd('start'); run(c, 2.2, 's', { quiet: true }); c.cold = 0; run(c, 1.2, 's', { quiet: true }); return c; }
function crest(x) { let ss = 0, pk = 0; for (const v of x) { ss += v * v; pk = Math.max(pk, Math.abs(v)); } return (20 * Math.log10(pk / Math.sqrt(ss / x.length))).toFixed(1); }
// burble: catat waktu tiap letupan
for (const eng of ['s55', 's63']) {
  const c = fresh(eng); c.inp.throttle = 1; run(c, 0.75, 'x', { quiet: true }); c.inp.throttle = 0;
  const times = []; const orig = c.pop.bind(c); let t = 0; c.pop = (a, big, g) => { times.push((big ? 'B' : '') + Math.round(t * 1000)); orig(a, big, g); };
  const o2 = c.step.bind(c); c.step = (dt) => { t += dt; o2(dt); };
  const r = run(c, 2.2, 'burble ' + eng, { every: 3 });
  console.log('   ', fftBands(r.L, SR), ' crest', crest(r.L), 'dB');
  console.log('    letupan (ms):', times.join(' '));
}
// satu crackle & satu bang terisolasi (mesin mati)
for (const big of [false, true]) { const c = mk(); c.pop(0.8, big); const r = run(c, 0.25, big ? 'bang tunggal' : 'crackle tunggal', { every: 1 }); console.log('   ', fftBands(r.L, SR), ' crest', crest(r.L)); }
{ const c = mk(); c.cmd('bump'); const r = run(c, 0.4, 'bump', { every: 1 }); console.log('   ', fftBands(r.L, SR), ' crest', crest(r.L)); }
{ const c = mk(); c.inp.kerb = 2; const r = run(c, 0.5, 'kerb', { every: 1 }); console.log('   ', fftBands(r.L, SR), ' crest', crest(r.L)); }
