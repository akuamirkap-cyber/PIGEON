import { mk, run, fftBands, SR } from './sim.mjs';
const eng = process.argv[2] || 's55';
const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng } });
c.cmd('start'); run(c, 2.5, 'start', { quiet: true });
console.log('cold idle  ', fftBands(run(c, 1.5, 'cold', { every: 1.5 }).L, SR));
c.cold = 0; run(c, 1.5, 'settle', { quiet: true });
console.log('warm idle  ', fftBands(run(c, 1.5, 'idle', { every: 1.5 }).L, SR));
c.cmd('up'); c.inp.throttle = 1;
let t = 0, t100 = 0;
for (let k = 0; k < 28; k++) { run(c, 0.5, 'WOT', { every: 0.5, quiet: k % 2 == 1 && k > 8 }); t += 0.5; if (!t100 && c.v * 3.6 >= 100) { t100 = t; console.log('   >>> 100 km/h at ~', t, 's'); } if (k == 13) console.log('WOT bands ', fftBands(run(c, 0.7, 'x', { quiet: true }).L, SR)); }
c.inp.throttle = 0;
run(c, 3, 'lift', { every: 0.5 });
c.inp.brake = 0.6;
run(c, 6, 'brake', { every: 0.5 });
