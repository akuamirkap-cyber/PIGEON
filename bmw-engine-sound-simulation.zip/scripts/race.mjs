import { mk, SR } from './sim.mjs';
import { buildTrack, Race } from '/tmp/race.mjs';
const T = buildTrack();
console.log('track len', T.len.toFixed(0), 'm  n', T.n, 'ds', T.ds.toFixed(2));
console.log('apex:', T.apex.map((a) => `s=${(a * T.ds).toFixed(0)} R=${(1 / Math.abs(T.kappa[a])).toFixed(0)}m v=${(T.prof[a] * 3.6).toFixed(0)}`).join(' | '));
let mx = 0; for (let i = 0; i < T.n; i++) mx = Math.max(mx, T.prof[i]); console.log('prof max', (mx * 3.6).toFixed(0), 'km/h');
const view = Number(process.argv[2] || 0);
const c = mk(); c.onMessage({ t: 'cfg', v: { trans: 'dct', auto: 1, mode: 2, dsc: 1, view } });
const race = new Race(T, false);
const N = SR / 60; const L = new Float32Array(N), R = new Float32Array(N);
let lastSec = -99, ss = 0, pk = 0, bad = 0, cnt = 0, maxSq = 0, lastCap = '';
const t0 = Date.now();
for (let f = 0; f < 60 * 72; f++) {
  const o = race.step({ v: c.v, dist: c.dist, es: c.estate, gear: c.gear }, 1 / 60);
  Object.assign(c.inp, { throttle: o.throttle, brake: o.brake, steer: o.steer, kerb: o.kerb });
  for (const k of o.cmds) c.cmd(k);
  c.cfg.dsc = o.dsc;
  for (let k = 0; k < N; k += 128) c.render(L.subarray(k, Math.min(N, k + 128)), R.subarray(k, Math.min(N, k + 128)), Math.min(128, N - k));
  for (let i = 0; i < N; i++) { const x = L[i]; if (!Number.isFinite(x)) bad++; ss += x * x; cnt++; if (Math.abs(x) > pk) pk = Math.abs(x); }
  maxSq = Math.max(maxSq, c.slipR, c.slipF);
  const sec = Math.floor(race.t);
  if (sec !== lastSec) {
    lastSec = sec;
    console.log(`T=${String(sec).padStart(3)} ${race.phase.padEnd(6)} s=${race.s.toFixed(0).padStart(4)} lap${race.lap} ${(c.v * 3.6).toFixed(0).padStart(3)}km/h g${c.gear} rpm=${c.rpm.toFixed(0).padStart(4)} P${race.pos} gh=[${race.ghosts.map((g) => (g.s - race.dist).toFixed(0)).join(',')}] sq=${maxSq.toFixed(2)} beta=${c.beta.toFixed(2)} rms=${(10 * Math.log10(ss / cnt + 1e-12)).toFixed(1)} pk=${(20 * Math.log10(pk + 1e-9)).toFixed(1)} ${o.caption !== lastCap ? '· ' + o.caption : ''}${bad ? ' NAN' : ''}`);
    lastCap = o.caption; ss = 0; cnt = 0; pk = 0; maxSq = 0;
  }
  if (race.phase === 'done' && race.t > 64) break;
}
console.log('sim ms', Date.now() - t0);
