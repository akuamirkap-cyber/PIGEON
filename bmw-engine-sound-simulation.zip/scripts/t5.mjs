import { mk, run, fftBands, SR } from './sim.mjs';
function fresh(eng = 's55', runEngine = true) { const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng } }); if (runEngine) { c.cmd('start'); run(c, 2.2, 's', { quiet: true }); c.cold = 0; run(c, 1.2, 's', { quiet: true }); } return c; }
function ev(label, c, sec, f) { f && f(c); const r = run(c, sec, label, { every: sec + 1 }); console.log('   ', fftBands(r.L, SR)); }
ev('starter crank', (() => { const c = fresh('s55', false); c.cmd('start'); run(c, 0.45, 'x', { quiet: true }); return c; })(), 0.7);
ev('BOV', fresh('s55', false), 0.5, (c) => c.cmd('bov'));
ev('DCT crack', fresh('s55', false), 0.3, (c) => c.cmd('crack'));
ev('shifter', fresh('s55', false), 0.4, (c) => c.cmd('shifter'));
ev('thud', fresh('s55', false), 0.4, (c) => c.cmd('bump'));
ev('kerb', fresh('s55', false), 0.5, (c) => (c.inp.kerb = 2));
ev('screech rear', fresh('s55', false), 0.6, (c) => { c.step = function () { this.slipR = 0.9; this.slipF = 0; }; });
ev('screech front', fresh('s55', false), 0.6, (c) => { c.step = function () { this.slipR = 0; this.slipF = 0.8; }; });
// burble: rev in N then lift
{ const c = fresh(); c.inp.throttle = 1; run(c, 0.75, 'x', { quiet: true }); c.inp.throttle = 0; ev('burble S+', c, 1.2); }
{ const c = fresh(); c.cfg.mode = 0; c.inp.throttle = 1; run(c, 0.75, 'x', { quiet: true }); c.inp.throttle = 0; ev('lift comfort', c, 1.2); }
// limiter
{ const c = fresh(); c.inp.throttle = 1; run(c, 1.2, 'x', { quiet: true }); ev('limiter', c, 1.0); }
// idle both engines
for (const e of ['s55', 's63']) { const c = fresh(e); ev('idle ' + e, c, 1.5); }
{ const c = fresh('s55'); c.cfg.mode = 0; run(c, 0.5, 'x', { quiet: true }); ev('idle comfort', c, 1.5); }
// manual shift
{ const c = fresh(); c.onMessage({ t: 'cfg', v: { trans: 'mt' } }); c.cmd('up'); run(c, 0.6, 'x', { quiet: true }); c.inp.throttle = 1; run(c, 3.0, 'MT 1st', { every: 1 }); c.cmd('up'); run(c, 1.2, 'MT shift', { every: 0.1 }); c.inp.throttle = 0; c.cmd('down'); run(c, 1.0, 'MT down', { every: 0.1 }); }
// launch control
{ const c = fresh(); c.cmd('up'); c.inp.brake = 1; c.inp.throttle = 1; run(c, 1.5, 'LC hold', { every: 0.25 }); c.inp.brake = 0; let t = 0; while (c.v * 3.6 < 100 && t < 9) { run(c, 0.1, 'x', { quiet: true }); t += 0.1; } console.log('LC 0-100:', t.toFixed(1), 's gear', c.gear); }
// shutdown
{ const c = fresh(); c.cmd('stop'); run(c, 1.5, 'shutdown', { every: 0.25 }); }
