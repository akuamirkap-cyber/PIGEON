import { mk, run, SR } from './sim.mjs';
const db = (x) => (20 * Math.log10(x + 1e-12)).toFixed(1);
function win(x, ms = 30) { const n = Math.round(SR * ms / 1000); let best = 0; for (let i = 0; i + n < x.length; i += n >> 1) { let ss = 0; for (let k = 0; k < n; k++) ss += x[i + k] * x[i + k]; best = Math.max(best, Math.sqrt(ss / n)); } return db(best); }
function bandsOf(x) { // energi per pita via Goertzel kasar pada jendela penuh
  const out = []; for (const [a, b] of [[40, 120], [120, 300], [300, 800], [800, 2000], [2000, 5000]]) { let e = 0; const st = (b - a) / 24; for (let f = a; f < b; f += st) { let re = 0, im = 0; const w = 2 * Math.PI * f / SR; for (let i = 0; i < x.length; i++) { re += x[i] * Math.cos(w * i); im += x[i] * Math.sin(w * i); } e += (re * re + im * im); } out.push(`${a}-${b}:${(10 * Math.log10(e / 24 / x.length + 1e-20)).toFixed(0)}`); } return out.join(' '); }
for (const [label, f, sec] of [['crackle', (c) => c.pop(0.8, false), 0.06], ['bang', (c) => c.pop(0.8, true), 0.12], ['bump (depan+belakang)', (c) => c.cmd('bump'), 0.3]]) {
  const c = mk(); f(c); const r = run(c, sec, label, { quiet: true }); let pk = 0; for (const v of r.L) pk = Math.max(pk, Math.abs(v));
  console.log(label.padEnd(22), 'peak', db(pk), ' rms30ms', win(r.L), ' |', bandsOf(r.L));
}
// burble di dalam gigi (overrun dari 6500 rpm gigi 3)
const c = mk(); c.cmd('start'); run(c, 2.2, 's', { quiet: true }); c.cold = 0; c.heat = 1;
c.gear = 3; const k = 1.701 * c.E.final / 0.335 * 9.5493; c.v = c.vw = 6500 / k; c.clutch = 1; c.locked = true; c.spool = 1; c.inp.throttle = 1; c.cfg.auto = 0;
run(c, 0.5, 's', { quiet: true }); c.inp.throttle = 0;
let n = 0; const o = c.pop.bind(c); c.pop = (a, b, g) => { n++; o(a, b, g); };
const r = run(c, 2.4, 'x', { quiet: true }); let ss = 0, pk = 0; for (const v of r.L) { ss += v * v; pk = Math.max(pk, Math.abs(v)); }
console.log('overrun gigi 3 (2,4 dtk):', n, 'letupan, rms', db(Math.sqrt(ss / r.L.length)), 'peak', db(pk), 'rms30ms maks', win(r.L), 'rpm akhir', c.rpm.toFixed(0));
