import { mk, run, fftBands, spectrumPeaks, SR } from './sim.mjs';
const eng = process.argv[2] || 's55';
function steady(lgSet, label, rpmWant = 6000, thr = 1) {
  const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng } });
  c.cmd('start'); run(c, 2.2, 's', { quiet: true }); c.cold = 0;
  c.gear = 3; const k = 1.701 * c.E.final / 0.335 * 9.5493; c.v = c.vw = rpmWant / k; c.clutch = 1; c.locked = true; c.spool = thr; c.inp.throttle = thr; c.cfg.auto = 0;
  run(c, 0.4, 's', { quiet: true });
  if (lgSet) { const a = new Array(15).fill(0); lgSet.forEach((i) => (a[i] = 1)); c.onMessage({ t: 'lg', v: a }); }
  const r = run(c, 0.75, label, { every: 0.75 });
  console.log('   ', fftBands(r.L, SR));
  return r;
}
const r = steady(null, 'ALL 6000');
console.log('    peaks', spectrumPeaks(r.L, SR, 700, 8));
steady([1, 2, 3], 'engine only');
steady([6], 'turbo only');
steady([8], 'intake only');
steady([11], 'whine only');
steady([13], 'roll+wind');
steady(null, 'ALL 3000', 3000);
steady(null, 'ALL 3000 thr.3', 3000, 0.3);
// idle
const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng } }); c.cmd('start'); run(c, 2.2, 's', { quiet: true }); c.cold = 0; run(c, 1.5, 's', { quiet: true });
const i = run(c, 1.5, 'idle', { every: 1.5 }); console.log('   ', fftBands(i.L, SR)); console.log('    peaks', spectrumPeaks(i.L, SR, 400, 8));
