import { report } from './harm.mjs';
report('luar 4000 WOT', 's55', 4000, 1, { view: 0 });
report('kokpit 4000 WOT', 's55', 4000, 1, { view: 1 });
report('kokpit idle', 's55', 720, 0.05, { view: 1 });
