import { mk, SR } from './sim.mjs';
import { DriftRun } from '/tmp/drift.mjs';
const eng = process.argv[2] || 's55'; const lim = { s55: 7550, s63: 7150, s54: 7900 }[eng];
const c = mk(); c.onMessage({ t: 'cfg', v: { engine: eng, trans: 'dct', auto: 0, mode: 2, dsc: 0 } });
const d = new DriftRun(false, lim);
const N = SR / 60; const L = new Float32Array(N), R = new Float32Array(N);
let ss = 0, cnt = 0, pk = 0, bad = 0, last = -99, rmin = 1e9, rmax = 0, lastCap = '';
for (let f = 0; f < 60 * 40; f++) {
  const o = d.step({ v: c.v, rpm: c.rpm, gear: c.gear, es: c.estate, sr: c.slipR, beta: c.beta }, 1 / 60);
  Object.assign(c.inp, { throttle: o.throttle, brake: o.brake, steer: o.steer, handbrake: o.handbrake }); for (const k of o.cmds) c.cmd(k);
  for (let k = 0; k < N; k += 128) c.render(L.subarray(k, Math.min(N, k + 128)), R.subarray(k, Math.min(N, k + 128)), Math.min(128, N - k));
  for (let i = 0; i < N; i++) { const x = L[i]; if (!Number.isFinite(x)) bad++; ss += x * x; cnt++; if (Math.abs(x) > pk) pk = Math.abs(x); }
  rmin = Math.min(rmin, c.rpm); rmax = Math.max(rmax, c.rpm);
  const h = Math.floor(d.t * 2);
  if (h !== last) { last = h; console.log(`t=${d.t.toFixed(1).padStart(5)} st${d.st} ${(c.v * 3.6).toFixed(0).padStart(3)}km/h g${c.gear} rpm ${rmin.toFixed(0)}-${rmax.toFixed(0)} slip=${c.slipR.toFixed(2)} sv=${c.slipV.toFixed(0)} beta=${(c.beta * 57.3).toFixed(0).padStart(3)}° thr=${o.throttle.toFixed(2)} rms=${(10 * Math.log10(ss / cnt + 1e-12)).toFixed(1)} pk=${(20 * Math.log10(pk + 1e-9)).toFixed(1)}${c.cut ? ' LIM' : ''}${bad ? ' NAN' : ''} ${o.caption !== lastCap ? '· ' + o.caption : ''}`); lastCap = o.caption; ss = 0; cnt = 0; pk = 0; rmin = 1e9; rmax = 0; }
  if (d.done && c.v < 0.5) { console.log('selesai di t=', d.t.toFixed(1)); break; }
}
