// ============================================================
//  SFX + ENGINE SYNTH
//  Mesin disintesis dari model: RPM -> frekuensi pembakaran (cyl/2 * rpm/60),
//  gelombang pulsa kaya harmonik + "lope" orde non-firing, resonansi knalpot (formant),
//  distorsi knalpot, intake, gearbox 4-6 speed, rev limiter, backfire, turbo/NOS.
// ============================================================

import type { VoiceKey } from './carmodel';
export type VoiceId = VoiceKey | 'none';

export type EngineState = {
  on: boolean;       // mesin hidup (state play)
  crashed: boolean;  // lagi jatuh / respawn
  speed: number;     // m/s efektif
  drift: boolean;    // ban slip
  boost: boolean;    // NOS
  air: boolean;      // di udara (free rev)
  car: VoiceId;
};

type Voice = {
  cyl: number; idle: number; red: number; gears: number[];
  rough: number;   // ketidakrataan pembakaran (lope)
  rasp: number;    // agresivitas knalpot
  tone: number;    // kecerahan
  gain: number;
  harmP: number;   // roll-off harmonik (kecil = terang)
  even: number;    // penekanan harmonik genap
  sub: number;     // bobot bass
  turbo: number; whine: number; clat: number; pop: number;
  formants: [number, number, number][]; // [freq, dB, Q]
};

const VOICES: Record<Exclude<VoiceId, 'none'>, Voice> = {
  // Dodge Viper — V10 NA, rendah, garang, banyak backfire
  v10: { cyl: 10, idle: 780, red: 6200, gears: [11, 18, 26, 36, 46, 58], rough: 0.55, rasp: 1.0, tone: 1.1, gain: 1.0, harmP: 0.8, even: 0.4, sub: 0.75, turbo: 0, whine: 0, clat: 0.05, pop: 0.6, formants: [[95, 6, 1.2], [260, 5, 1.6], [820, 4, 2.0]] },
  // V8 — burble muscle/GT, dalam dan bergemuruh
  v8: { cyl: 8, idle: 740, red: 6600, gears: [11, 18, 26, 36, 47, 60], rough: 0.6, rasp: 0.85, tone: 0.95, gain: 1.0, harmP: 0.9, even: 0.35, sub: 0.8, turbo: 0, whine: 0, clat: 0.05, pop: 0.55, formants: [[100, 6, 1.2], [300, 5, 1.5], [900, 3, 2.0]] },
  // V12 — halus, tinggi, eksotis
  v12: { cyl: 12, idle: 720, red: 7400, gears: [11, 19, 28, 39, 51, 64], rough: 0.2, rasp: 0.7, tone: 1.3, gain: 0.95, harmP: 0.75, even: 0.5, sub: 0.5, turbo: 0, whine: 0, clat: 0.03, pop: 0.35, formants: [[110, 4, 1.2], [420, 5, 1.6], [1300, 4, 2.0]] },
  // Inline-6 turbo — mulus, desis turbo
  i6: { cyl: 6, idle: 800, red: 7000, gears: [10.5, 17, 25, 35, 46, 58], rough: 0.15, rasp: 0.6, tone: 1.0, gain: 0.95, harmP: 0.9, even: 0.35, sub: 0.55, turbo: 0.5, whine: 0, clat: 0.04, pop: 0.5, formants: [[130, 4, 1.2], [450, 5, 1.6], [1200, 3, 2.0]] },
  // Flat-6 — rumble boxer Porsche
  flat6: { cyl: 6, idle: 850, red: 7400, gears: [10.5, 17, 25, 35, 46, 58], rough: 0.5, rasp: 0.75, tone: 1.1, gain: 0.95, harmP: 0.85, even: 0.3, sub: 0.5, turbo: 0, whine: 0, clat: 0.06, pop: 0.4, formants: [[120, 5, 1.2], [400, 5, 1.6], [1100, 4, 2.0]] },
  // Rotary — melengking, buzzy, redline 9000
  rotary: { cyl: 4, idle: 1100, red: 9000, gears: [11, 18, 27, 38, 50, 62], rough: 0.1, rasp: 1.0, tone: 1.5, gain: 0.9, harmP: 0.6, even: 0.7, sub: 0.2, turbo: 0.3, whine: 0, clat: 0.02, pop: 0.6, formants: [[200, 3, 1.2], [900, 6, 1.8], [2200, 5, 2.2]] },
  // I4 turbo — rally/hot hatch
  i4t: { cyl: 4, idle: 860, red: 6800, gears: [10, 17, 25, 35, 46, 58], rough: 0.35, rasp: 0.7, tone: 1.0, gain: 0.95, harmP: 0.9, even: 0.3, sub: 0.35, turbo: 0.8, whine: 0, clat: 0.08, pop: 0.5, formants: [[160, 4, 1.2], [520, 5, 1.7], [1400, 4, 2.0]] },
  // Taxi — sedan 4 silinder biasa
  i4: { cyl: 4, idle: 820, red: 5400, gears: [10, 17, 25, 35, 48], rough: 0.3, rasp: 0.35, tone: 0.8, gain: 0.9, harmP: 1.0, even: 0.2, sub: 0.45, turbo: 0, whine: 0, clat: 0.12, pop: 0.05, formants: [[150, 4, 1.2], [480, 4, 1.6], [1200, 2, 2.0]] },
  // Panda 86 — 4A-GE high-rev, cempreng, crackle
  i4hi: { cyl: 4, idle: 950, red: 7800, gears: [10.5, 17, 25, 34, 44, 56], rough: 0.3, rasp: 0.9, tone: 1.3, gain: 0.95, harmP: 0.75, even: 0.6, sub: 0.3, turbo: 0, whine: 0, clat: 0.1, pop: 0.45, formants: [[180, 3, 1.2], [620, 5, 1.8], [1600, 4, 2.2]] },
  // Damkar — diesel turbo, berat, clatter
  diesel: { cyl: 6, idle: 640, red: 3300, gears: [8, 13, 19, 27, 38, 52], rough: 0.8, rasp: 0.35, tone: 0.55, gain: 1.0, harmP: 1.15, even: 0.1, sub: 0.9, turbo: 0.8, whine: 0, clat: 0.9, pop: 0, formants: [[80, 7, 1.2], [220, 5, 1.5], [700, 3, 1.8]] },
  // Tank — turbin + diesel besar
  turbine: { cyl: 12, idle: 560, red: 3000, gears: [9, 17, 28, 44], rough: 0.65, rasp: 0.25, tone: 0.5, gain: 1.05, harmP: 1.2, even: 0.1, sub: 1.0, turbo: 0.3, whine: 1, clat: 0.35, pop: 0, formants: [[60, 8, 1.1], [180, 5, 1.4], [520, 3, 1.6]] },
  // VW — boxer-4 air-cooled, putt-putt tidak rata
  boxer: { cyl: 4, idle: 800, red: 4900, gears: [9, 16, 24, 34], rough: 0.9, rasp: 0.5, tone: 0.7, gain: 0.9, harmP: 0.95, even: 0.15, sub: 0.35, turbo: 0, whine: 0, clat: 0.3, pop: 0.2, formants: [[140, 3, 1.2], [400, 5, 1.8], [1000, 3, 2.0]] },
};

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const satCurve = (k: number) => {
  const c = new Float32Array(1024);
  const n = Math.tanh(k);
  for (let i = 0; i < 1024; i++) c[i] = Math.tanh(k * (i / 511.5 - 1)) / n;
  return c;
};

export class Sfx {
  ctx: AudioContext | null = null;
  master!: GainNode;
  bus!: GainNode;
  noiseBuf!: AudioBuffer;
  lastRumble = 0;

  // ---- node engine ----
  private oFireA!: OscillatorNode; private oFireB!: OscillatorNode; private oCyc!: OscillatorNode;
  private oSub!: OscillatorNode; private oRasp!: OscillatorNode; private oClat!: OscillatorNode; private oWhine!: OscillatorNode;
  private gCyc!: GainNode; private gRasp!: GainNode; private gSub!: GainNode; private gIntake!: GainNode;
  private clatG!: GainNode; private clatDepth!: GainNode; private gWhine!: GainNode; private gNos!: GainNode;
  private drive!: GainNode; private engAmp!: GainNode;
  private lp!: BiquadFilterNode; private intakeBp!: BiquadFilterNode;
  private f1!: BiquadFilterNode; private f2!: BiquadFilterNode; private f3!: BiquadFilterNode;
  // ---- ban + angin ----
  private tbp!: BiquadFilterNode; private tG1!: GainNode; private tG2!: GainNode;
  private oSq1!: OscillatorNode; private oSq2!: OscillatorNode; private sqG!: GainNode;
  private wG!: GainNode; private wlp!: BiquadFilterNode;

  // ---- state mesin ----
  rpm = 0; rpmN = 0; gear = 0; gearNo = 0;
  private thr = 0; private running = false; private crank = 0; private shiftT = 0; private limT = 0;
  private lift = 0; private blip = 0; private prevHi = false; private prevBoost = false;
  private boostN = 0; private slip = 0; private jit = 0;
  private curVoice: VoiceId | '' = '';
  private waves = new Map<string, { fire: PeriodicWave; cyc: PeriodicWave }>();

  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = (this.ctx = new AC());
    this.master = ctx.createGain(); this.master.gain.value = 0.6;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16; comp.knee.value = 14; comp.ratio.value = 5; comp.attack.value = 0.004; comp.release.value = 0.2;
    this.master.connect(comp).connect(ctx.destination);

    this.noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

    // bus mesin/ban/angin + reverb ruang pendek
    this.bus = ctx.createGain(); this.bus.gain.value = 1;
    this.bus.connect(this.master);
    const len = Math.floor(ctx.sampleRate * 0.5);
    const ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const ch = ir.getChannelData(c);
      for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2);
    }
    const conv = ctx.createConvolver(); conv.buffer = ir;
    const wet = ctx.createGain(); wet.gain.value = 0.16;
    this.bus.connect(conv); conv.connect(wet).connect(this.master);

    this.buildEngine();
    this.buildTire();
  }

  private noiseSrc() {
    const s = this.ctx!.createBufferSource(); s.buffer = this.noiseBuf; s.loop = true;
    s.start(0, Math.random() * 1.5);
    return s;
  }

  private buildEngine() {
    const ctx = this.ctx!;
    const osc = (type: OscillatorType = 'sine') => { const o = ctx.createOscillator(); o.type = type; o.frequency.value = 40; o.start(); return o; };
    const gn = (v = 0) => { const g = ctx.createGain(); g.gain.value = v; return g; };
    const bq = (type: BiquadFilterType, f: number, q = 1, g = 0) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; b.gain.value = g; return b; };

    this.oFireA = osc(); this.oFireB = osc(); this.oCyc = osc(); this.oSub = osc('sine'); this.oRasp = osc('sawtooth');
    const mixer = gn(1);
    const gFA = gn(0.5), gFB = gn(0.4);
    this.gCyc = gn(0); this.gSub = gn(0); this.gRasp = gn(0);
    this.oFireA.connect(gFA).connect(mixer);
    this.oFireB.connect(gFB).connect(mixer);
    this.oCyc.connect(this.gCyc).connect(mixer);
    this.oSub.connect(this.gSub).connect(mixer);
    // distorsi knalpot (rasp)
    const hard = ctx.createWaveShaper(); hard.curve = satCurve(6); hard.oversample = '2x';
    const rhp = bq('highpass', 180, 0.7);
    this.oRasp.connect(this.gRasp).connect(hard).connect(rhp).connect(mixer);

    this.drive = gn(1.6);
    const soft = ctx.createWaveShaper(); soft.curve = satCurve(1.8); soft.oversample = '2x';
    this.lp = bq('lowpass', 900, 0.9);
    this.f1 = bq('peaking', 120, 1.2, 4); this.f2 = bq('peaking', 400, 1.6, 4); this.f3 = bq('peaking', 1000, 2, 3);
    this.engAmp = gn(0);
    mixer.connect(this.drive).connect(soft).connect(this.lp).connect(this.f1).connect(this.f2).connect(this.f3).connect(this.engAmp).connect(this.bus);

    // intake roar
    this.intakeBp = bq('bandpass', 600, 0.9);
    this.gIntake = gn(0);
    this.noiseSrc().connect(this.intakeBp).connect(this.gIntake).connect(this.engAmp);

    // clatter pembakaran (diesel / valve tick) — noise yang dipulsa sesuai firing
    this.oClat = osc('square');
    this.clatDepth = gn(0); this.clatG = gn(0);
    this.oClat.connect(this.clatDepth).connect(this.clatG.gain);
    const chp = bq('highpass', 1400, 0.7), cbp = bq('bandpass', 3200, 0.8);
    this.noiseSrc().connect(chp).connect(cbp).connect(this.clatG).connect(this.engAmp);

    // turbo / turbin whine
    this.oWhine = osc('sine'); this.gWhine = gn(0);
    this.oWhine.connect(this.gWhine).connect(this.bus);

    // NOS hiss
    const nhp = bq('highpass', 3500, 0.7);
    this.gNos = gn(0);
    this.noiseSrc().connect(nhp).connect(this.gNos).connect(this.bus);

    // angin
    this.wlp = bq('lowpass', 800, 0.7); this.wG = gn(0);
    this.noiseSrc().connect(this.wlp).connect(this.wG).connect(this.bus);
  }

  private buildTire() {
    const ctx = this.ctx!;
    const bq = (type: BiquadFilterType, f: number, q = 1) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; };
    this.tbp = bq('bandpass', 2100, 4);
    this.tG1 = ctx.createGain(); this.tG1.gain.value = 0;
    this.noiseSrc().connect(this.tbp).connect(this.tG1).connect(this.bus);
    const tlp = bq('lowpass', 380, 0.8);
    this.tG2 = ctx.createGain(); this.tG2.gain.value = 0;
    this.noiseSrc().connect(tlp).connect(this.tG2).connect(this.bus);
    // lengkingan ban (squeal) + vibrato
    this.oSq1 = ctx.createOscillator(); this.oSq1.type = 'triangle'; this.oSq1.frequency.value = 1200;
    this.oSq2 = ctx.createOscillator(); this.oSq2.type = 'triangle'; this.oSq2.frequency.value = 1780;
    this.sqG = ctx.createGain(); this.sqG.gain.value = 0;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 6.5;
    const lfoG = ctx.createGain(); lfoG.gain.value = 30;
    lfo.connect(lfoG); lfoG.connect(this.oSq1.frequency); lfoG.connect(this.oSq2.frequency);
    this.oSq1.connect(this.sqG); this.oSq2.connect(this.sqG); this.sqG.connect(this.bus);
    this.oSq1.start(); this.oSq2.start(); lfo.start();
  }

  // ---------- profil mesin per mobil ----------
  private waveFor(key: Exclude<VoiceId, 'none'>) {
    const hit = this.waves.get(key);
    if (hit) return hit;
    const ctx = this.ctx!; const V = VOICES[key];
    const N = 48;
    const re = new Float32Array(N + 1), im = new Float32Array(N + 1);
    for (let k = 1; k <= N; k++) {
      const a = Math.pow(k, -V.harmP) * (k % 2 === 0 ? 1 + V.even : 1);
      re[k] = a * Math.cos(k * 0.4); im[k] = a * Math.sin(k * 0.4);
    }
    const M = V.cyl * 3;
    const re2 = new Float32Array(M + 1), im2 = new Float32Array(M + 1);
    for (let k = 1; k <= M; k++) {
      if (k % V.cyl === 0) continue; // orde firing sudah di osc utama
      const a = Math.pow(k, -0.6);
      re2[k] = a * Math.cos(k * k * 0.7); im2[k] = a * Math.sin(k * k * 0.7);
    }
    const w = { fire: ctx.createPeriodicWave(re, im), cyc: ctx.createPeriodicWave(re2, im2) };
    this.waves.set(key, w);
    return w;
  }

  private pickGear(V: Voice, speed: number) {
    let g = 0;
    while (g < V.gears.length - 1 && speed > V.gears[g] * 0.9) g++;
    return g;
  }

  private applyVoice(key: Exclude<VoiceId, 'none'>, speed: number) {
    const V = VOICES[key]; const w = this.waveFor(key);
    this.oFireA.setPeriodicWave(w.fire); this.oFireB.setPeriodicWave(w.fire); this.oCyc.setPeriodicWave(w.cyc);
    const fs = [this.f1, this.f2, this.f3];
    V.formants.forEach(([f, db, q], i) => { fs[i].frequency.value = f; fs[i].gain.value = db; fs[i].Q.value = q; });
    this.curVoice = key;
    this.gear = this.pickGear(V, speed);
  }

  // ---------- update per frame ----------
  update(dt: number, s: EngineState) {
    const ctx = this.ctx; if (!ctx) return;
    dt = clamp(dt, 0.001, 0.05);
    const t = ctx.currentTime;
    const set = (p: AudioParam, v: number, tc = 0.03) => { if (Number.isFinite(v)) p.setTargetAtTime(v, t, tc); };
    const key = s.car === 'none' ? null : s.car;
    const V = key ? VOICES[key] : null;
    if (key && key !== this.curVoice) this.applyVoice(key, s.speed);
    const sp = Math.max(0, s.speed);

    if (V && key) {
      const wasRun = this.running;
      this.running = s.on;
      if (s.on && !wasRun) {
        // start mesin: starter + nyala
        this.crank = 0.4; this.rpm = 90; this.shiftT = 0; this.limT = 0; this.lift = 0; this.thr = 0.3;
        this.gear = this.pickGear(V, sp); this.prevHi = false; this.prevBoost = false;
        this.starter();
      }
      if (!s.on && wasRun) {
        this.crank = 0;
        if (s.crashed) this.crackle(2 + ((Math.random() * 3) | 0), 0.8);
      }

      let thrT = 0;
      if (this.running) {
        const gv = V.gears;
        let rpmT: number;
        if (this.crank > 0) {
          this.crank -= dt;
          rpmT = 240 + (1 - Math.max(0, this.crank) / 0.4) * 520; thrT = 0.3;
          if (this.crank <= 0) this.rpm = Math.max(this.rpm, V.idle * 1.7); // flare saat nyala
        } else {
          if (this.shiftT > 0) this.shiftT -= dt;
          else if (!s.air) {
            if (this.gear < gv.length - 1 && sp / gv[this.gear] > 0.94) {
              this.gear++; this.shiftT = 0.2;
              if (Math.random() < V.pop) this.crackle(1 + ((Math.random() * 2) | 0), 0.6);
              if (V.turbo > 0.4) this.bov(0.45);
            } else if (this.gear > 0 && sp / gv[this.gear - 1] < 0.8) {
              this.gear--; this.shiftT = 0.16; this.blip = 0.22; // rev-match blip
            }
          }
          let gr = clamp(sp / gv[this.gear], 0, 1.08);
          if (s.drift) gr += 0.09;
          if (s.boost) gr += 0.04;
          if (s.air) gr = 1.02;
          rpmT = V.idle + (V.red - V.idle) * Math.min(1.06, gr);
          thrT = s.boost || s.air ? 1 : s.drift ? 0.85 : 0.55;
          const hi = s.boost || s.air;
          if (this.prevHi && !hi) {
            this.lift = 0.5;
            if (this.rpm > V.idle + (V.red - V.idle) * 0.45) {
              if (Math.random() < V.pop + 0.15) this.crackle(2 + ((Math.random() * 4) | 0), 0.9);
            }
          }
          if (this.prevBoost && !s.boost) this.bov(V.turbo > 0 ? 0.8 : 0.55);
          this.prevHi = hi; this.prevBoost = s.boost;
          if (this.lift > 0) { this.lift -= dt; thrT = 0.03; }
          if (this.shiftT > 0) thrT = 0;
        }
        const k = this.shiftT > 0 ? 9 : rpmT > this.rpm ? 7 : 3.8;
        this.rpm += (rpmT - this.rpm) * (1 - Math.exp(-dt * k));
        if (this.blip > 0) { this.blip -= dt; this.rpm += (V.red - V.idle) * 0.55 * dt; }
        if (this.limT > 0) this.limT -= dt;
        else if (this.rpm > V.red * 0.975 && this.thr > 0.6) { this.limT = 0.07; this.rpm -= V.red * 0.05; }
      } else {
        this.rpm *= Math.exp(-dt * 4.5);
      }
      this.rpm = clamp(this.rpm, 0, V.red * 1.08);
      this.thr += (thrT - this.thr) * (1 - Math.exp(-dt * (thrT > this.thr ? 12 : 8)));

      const rpmN = clamp((this.rpm - V.idle) / (V.red - V.idle), 0, 1);
      this.rpmN = rpmN; this.gearNo = this.running && this.crank <= 0 ? this.gear + 1 : 0;
      const f = clamp((this.rpm / 60) * (V.cyl / 2), 8, 1500);
      const thr = this.thr;
      const run = this.running ? 1 : 0;

      set(this.oFireA.frequency, f, 0.02); set(this.oFireB.frequency, f * 1.004, 0.02);
      set(this.oCyc.frequency, f / V.cyl, 0.02); set(this.oSub.frequency, f * 0.5, 0.03);
      set(this.oRasp.frequency, f, 0.02); set(this.oClat.frequency, f, 0.03);
      this.jit += dt;
      if (this.jit > 0.05) {
        this.jit = 0;
        const j = (Math.random() - 0.5) * 18 * V.rough;
        set(this.oFireA.detune, j, 0.03); set(this.oFireB.detune, 6 - j, 0.03); set(this.oCyc.detune, j * 2, 0.04);
      }

      const cutG = this.limT > 0 ? 0.25 : 1;
      const chug = this.crank > 0 ? 0.6 + 0.4 * Math.sin(t * 80) : 1;
      const loud = V.gain * (0.4 + 0.6 * thr) * (0.65 + 0.55 * rpmN) * cutG * chug * run * (s.boost ? 1.25 : 1);
      set(this.engAmp.gain, 0.17 * loud, this.running ? 0.03 : 0.07);
      set(this.lp.frequency, clamp(V.tone * (380 + 3800 * Math.pow(rpmN, 0.85) * (0.28 + 0.72 * thr)), 220, 9000), 0.05);
      set(this.drive.gain, 1.2 + 1.8 * thr * V.rasp, 0.05);
      set(this.gCyc.gain, 0.5 * V.rough * (0.65 + 0.35 * thr), 0.05);
      set(this.gSub.gain, 0.3 * V.sub * (0.5 + 0.5 * (1 - rpmN * 0.6)), 0.05);
      set(this.gRasp.gain, 0.22 * V.rasp * (0.2 + 0.8 * thr) * (0.35 + 0.65 * rpmN), 0.04);
      set(this.gIntake.gain, V.gain * 0.5 * thr * (0.25 + rpmN), 0.05);
      set(this.intakeBp.frequency, 420 + 1800 * rpmN, 0.06);
      const cd = V.clat * 0.35 * (0.3 + 0.7 * thr);
      set(this.clatDepth.gain, cd, 0.05); set(this.clatG.gain, cd, 0.05);

      const wantBoost = V.turbo * thr * rpmN + (s.boost ? 0.7 : 0);
      this.boostN += (wantBoost - this.boostN) * (1 - Math.exp(-dt * 2.5));
      const whineAmp = 0.02 * (V.turbo + (s.boost ? 0.6 : 0)) * this.boostN + V.whine * 0.05 * (0.3 + rpmN);
      set(this.gWhine.gain, whineAmp * run, 0.05);
      set(this.oWhine.frequency, V.whine ? 600 + 2800 * rpmN : 1300 + 5200 * this.boostN, 0.06);
      set(this.gNos.gain, s.boost && this.running ? 0.07 : 0, 0.08);
    } else {
      // tanpa mesin (Spidey)
      this.running = false; this.rpmN = 0; this.gearNo = 0; this.rpm *= Math.exp(-dt * 6);
      set(this.engAmp.gain, 0, 0.05); set(this.gWhine.gain, 0, 0.05); set(this.gNos.gain, s.boost ? 0.05 : 0, 0.08);
    }

    // ---- ban: slip ----
    const slipT = V && s.drift && s.on ? 1 : 0;
    this.slip += (slipT - this.slip) * (1 - Math.exp(-dt * (slipT ? 18 : 7)));
    const fl = 0.7 + 0.3 * Math.random();
    set(this.tG1.gain, 0.11 * this.slip * fl, 0.02);
    set(this.tbp.frequency, 1700 + sp * 22 + Math.sin(t * 37) * 180, 0.02);
    set(this.tG2.gain, 0.16 * this.slip, 0.05);
    set(this.sqG.gain, 0.013 * this.slip * (0.6 + 0.4 * fl), 0.03);
    set(this.oSq1.frequency, 1180 + sp * 8, 0.05); set(this.oSq2.frequency, 1760 + sp * 10, 0.05);

    // ---- angin ----
    set(this.wG.gain, s.on ? 0.05 * Math.pow(clamp(sp / 45, 0, 1.2), 1.6) : 0, 0.15);
    set(this.wlp.frequency, 500 + sp * 20, 0.1);
  }

  // ---------- efek mesin sesaat ----------
  private pop(delay = 0, str = 1) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime + delay;
    const s = ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 500 + Math.random() * 1100; f.Q.value = 0.9;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.5 * str, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07 + Math.random() * 0.05);
    s.connect(f).connect(g).connect(this.bus);
    s.start(t, Math.random()); s.stop(t + 0.16);
    const o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(55, t + 0.08);
    const g2 = ctx.createGain();
    g2.gain.setValueAtTime(0.0001, t);
    g2.gain.exponentialRampToValueAtTime(0.28 * str, t + 0.004);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
    o.connect(g2).connect(this.bus); o.start(t); o.stop(t + 0.15);
  }
  crackle(n: number, str = 1) {
    for (let i = 0; i < n; i++) this.pop(i * (0.04 + Math.random() * 0.07), str * (0.5 + Math.random() * 0.5));
  }
  bov(str = 1) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.setValueAtTime(7000, t); f.frequency.exponentialRampToValueAtTime(2600, t + 0.35); f.Q.value = 0.8;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.14 * str, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.38);
    s.connect(f).connect(g).connect(this.bus); s.start(t, Math.random()); s.stop(t + 0.42);
  }
  private starter() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'sawtooth';
    o.frequency.setValueAtTime(110, t); o.frequency.linearRampToValueAtTime(190, t + 0.36);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 700;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.05, t + 0.06); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
    o.connect(f).connect(g).connect(this.bus); o.start(t); o.stop(t + 0.45);
    this.pop(0.38, 0.7);
  }

  // ---------- one-shot lama ----------
  tone(freq: number, dur: number, type: OscillatorType = 'square', vol = 0.15, slideTo?: number, delay = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t); o.stop(t + dur + 0.05);
  }

  noise(dur: number, freq: number, vol: number, type: BiquadFilterType = 'lowpass', delay = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const s = this.ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t, Math.random()); s.stop(t + dur);
  }

  attach() { this.tone(320, 0.09, 'triangle', 0.18, 160); this.noise(0.08, 3000, 0.08, 'highpass'); }
  release() { this.tone(500, 0.12, 'sine', 0.12, 900); }
  perfect(combo: number) {
    const base = 523 * Math.pow(2, Math.min(combo - 1, 12) / 12);
    [1, 1.26, 1.5, 2].forEach((m, i) => this.tone(base * m, 0.22, 'triangle', 0.16, undefined, i * 0.06));
    this.tone(base * 4, 0.4, 'sine', 0.06, undefined, 0.24);
  }
  nice() { this.tone(660, 0.12, 'triangle', 0.12); this.tone(880, 0.15, 'triangle', 0.1, undefined, 0.07); }
  tick() { this.tone(1200, 0.04, 'sine', 0.05); }
  crash() {
    this.noise(0.6, 900, 0.5);
    this.tone(300, 0.7, 'sawtooth', 0.15, 40);
    this.tone(120, 0.5, 'square', 0.1, 30, 0.1);
    this.noise(0.25, 3500, 0.18, 'bandpass', 0.02); // pecahan logam
  }
  rumble() {
    if (!this.ctx || this.ctx.currentTime - this.lastRumble < 0.25) return;
    this.lastRumble = this.ctx.currentTime;
    this.noise(0.35, 220, 0.12);
  }
  thud(strength = 8) {
    if (!this.ctx) return;
    this.noise(0.25, 170, Math.min(0.5, 0.15 + strength * 0.03));
    this.tone(95, 0.28, 'sine', 0.28, 35);
  }
  nos(big = false) {
    this.noise(0.55, 5200, 0.13, 'highpass');
    this.tone(170, 0.5, 'sawtooth', 0.07, 950);
    if (big) this.tone(85, 0.6, 'square', 0.07, 480, 0.05);
  }
  whoosh() {
    this.noise(0.5, 2500, 0.12, 'bandpass');
    this.tone(200, 0.45, 'sine', 0.1, 700);
  }
  land() {
    this.thud(10);
    this.noise(0.3, 500, 0.2);
  }
  coin(n = 0) {
    const k = (n % 8) / 2;
    this.tone(987 * Math.pow(2, k / 12), 0.08, 'square', 0.07);
    this.tone(1318 * Math.pow(2, k / 12), 0.22, 'square', 0.07, undefined, 0.07);
  }
  fanfare() {
    [523, 659, 784, 1046, 784, 1046].forEach((f, i) => this.tone(f, 0.18, 'square', 0.1, undefined, i * 0.12));
    this.tone(1318, 0.5, 'triangle', 0.12, undefined, 0.75);
  }
  start() { [392, 523, 784].forEach((f, i) => this.tone(f, 0.15, 'square', 0.1, undefined, i * 0.08)); }
  beep(n: number) { if (n > 0) this.tone(n === 1 ? 880 : 660, 0.14, 'square', 0.09); }
  go() { this.tone(1175, 0.45, 'square', 0.1); this.tone(1568, 0.55, 'triangle', 0.08, undefined, 0.05); }
  respawn() {
    this.tone(330, 0.28, 'triangle', 0.14, 990);
    this.tone(660, 0.36, 'sine', 0.1, 1980, 0.08);
    this.noise(0.4, 4000, 0.07, 'highpass');
  }
}
