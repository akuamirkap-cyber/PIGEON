import * as THREE from 'three';
import { Music, type MusicStyle } from './audio';
import { Sfx } from './sfx';
import { validCar, voiceOf, buildCarModel, makeMats, SHARED_MATS, tickSirens, animateParts, type CarModel, type CarMats, type WheelRig } from './carmodel';

const W = 4.4;
export const RESPAWN_T = 3; // detik sebelum respawn setelah jatuh
const FADE_NEAR = 46, FADE_FAR = 100; // jalan memudar (alpha) di rentang ini
const SPIRAL_TOP = new THREE.Color(0x5c5873);
const SPIRAL_LINE = new THREE.Color(0xffd23f);
// Kelonggaran jatuh: mobil sekarang lebih besar (setengah lebar ±0,85 m) dari batas jatuh lama (0,7 m di luar tepi),
// jadi tanpa ini mobil bisa jatuh saat badannya masih menyentuh aspal.
const FORGIVE = 0.5;
const CAR_UP = 1.4;                 // pembesaran mobil (1.4×)
const CAR_SCALE = 0.85 * CAR_UP;    // skala grup mobil di dunia
const FLOOR_H = 7.6;
const CLEAR_Y = 3.6; // jalan boleh bersilang hanya sebagai jembatan dengan selisih tinggi minimal ini // tinggi tiap lantai spiral
const TAU = Math.PI * 2;
const CHUNK = 1.25; // thin neat slices — satisfying collapse

export type SkinName = 'asphalt' | 'candy';
export type CamMode = 0 | 1 | 2;
export type FxName = 'V1' | 'V2';
export type RoadBuild = 'instant' | 'wave';
export type Mode = 'drift' | 'spidey' | 'free';
export type BotMode = 'off' | 'ghost' | 'solid' | 'ghost5';
export type NosColor = 'blue' | 'purple' | 'green';
export const NOS: Record<NosColor, { outer: number; mid: number; css: string }> = {
  blue: { outer: 0x2f9dff, mid: 0x9fdcff, css: '63,169,255' },
  purple: { outer: 0xa44dff, mid: 0xe3b8ff, css: '180,92,255' },
  green: { outer: 0x22ee8b, mid: 0xc2ffe2, css: '61,255,158' },
};
export type EdgeName = 'hidden' | 'flat' | 'rail';
export type SpeedName = 'santai' | 'normal' | 'kencang';
/** Model kecepatan: v0 awal, vMax batas, ramp tambahan per segmen, nos pengali NOS, ease pelan di tikungan, grip cengkeraman setelah lepas */
export type Tune = { v0: number; vMax: number; ramp: number; nos: number; ease: number; grip: number };
export const SPEEDS: Record<SpeedName, Tune> = {
  santai: { v0: 12, vMax: 17.5, ramp: 0.05, nos: 1.45, ease: 0.16, grip: 3.2 },
  normal: { v0: 13.2, vMax: 21.5, ramp: 0.085, nos: 1.7, ease: 0.12, grip: 3 },
  kencang: { v0: 13.5, vMax: 23, ramp: 0.1, nos: 1.9, ease: 0.06, grip: 2 },
};
export type CarName = string;
export const CAM_NAMES = ['KLASIK', 'FOLLOW', 'DRONE'] as const;

// ---- 5 bot ghost (mode balap hantu) ----
export const BOT_DEFS = [
  { name: 'NOVA', color: '#e2e8f0', car: 'ae86' },
  { name: 'BLAZE', color: '#fbbf24', car: 'fd3s' },
  { name: 'RIFT', color: '#fb7185', car: 'rx8' },
  { name: 'ECHO', color: '#a3e635', car: 'mrbean' },
  { name: 'VOLT', color: '#60a5fa', car: 'rally' },
] as const;

export type RaceRow = { id: number; name: string; color: string; p: number; me: boolean };
export type RaceInfo = { rem: number; place: number; total: number; rows: RaceRow[] };
export type RaceEnd = { win: boolean; score: number; place: number; total: number; finished: boolean; falls: number };
export type Telemetry = { kmh: number; rpm: number; gear: number; boost: boolean; drift: boolean };

type Step = { k: 's' | 'a' | 'j' | 'p'; len?: number; sweep?: number; R?: number; flip?: boolean; same?: boolean };
type BotCar = {
  car: THREE.Group; model: CarModel; mats: CarMats; rigs: WheelRig[]; tag: THREE.Sprite; name: string; color: string; active: boolean;
  dist: number; v: number; off: number; h: number; push: number; lane: number; skill: number;
  nosT: number; nosCD: number; phase: number; finished: boolean; turn: number; yaw: number; yawV: number;
  steer: number; steerV: number; spinA: number; inArc: boolean; arcSeg: Seg | null; arcS: number; crashT: number; crashP: number;
  blink: number; skidT: number; cpos: THREE.Vector3; cvel: THREE.Vector3;
};

type Seg = {
  type: 's' | 'a' | 'r';
  jmp?: number;
  launch?: number;
  spiral?: boolean;
  dR?: number;            // spiral keong: radius melebar per radian
  cum?: Float32Array;     // tabel panjang busur (agar kecepatan konstan)
  bld?: THREE.Group;
  y0: number; y1: number; len: number; d0: number;
  sx: number; sz: number; h: number;
  cx: number; cz: number; R: number; a0: number; s: number; sweep: number;
  poleTop?: THREE.Mesh;
};

type Chunk = { g: THREE.Group; d: number; falling: boolean; vy: number; t: number; spin: THREE.Vector3; geo?: THREE.BufferGeometry; by: number; spawned: boolean; spawnT: number; spawnDelay: number };

export type Callbacks = {
  onScore: (score: number, combo: number) => void;
  onPopup: (text: string, color: string) => void;
  onGameOver: (score: number, falls: number) => void;
  onRaceEnd?: (r: RaceEnd) => void;
  onRace?: (info: RaceInfo) => void;
  onHint?: (h: string) => void;
  onBoost?: (on: boolean) => void;
  onRespawn?: (n: number) => void; // 3,2,1 = hitung mundur, 0 = sudah respawn
  onGrid?: (n: number) => void; // lampu start 3,2,1 (0 = GO)
  onTelemetry?: (t: Telemetry) => void;
};

const wrap = (a: number) => {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
};
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const backOut = (x: number) => { const c = 1.70158; const u = x - 1; return 1 + (c + 1) * u * u * u + c * u * u; };

export function buildCum(R: number, dR: number, sweep: number, N = 240) {
  const cum = new Float32Array(N + 1);
  const dphi = sweep / N;
  let acc = 0, prev = Math.hypot(R, dR);
  for (let i = 1; i <= N; i++) {
    const f = Math.hypot(R + dR * dphi * i, dR);
    acc += 0.5 * (prev + f) * dphi; cum[i] = acc; prev = f;
  }
  for (let i = 1; i <= N; i++) cum[i] /= acc;
  return { cum, len: acc };
}
// fraksi panjang busur → fraksi sudut
function cumInv(cum: Float32Array, t: number) {
  const N = cum.length - 1;
  if (t <= 0) return 0;
  if (t >= 1) return 1;
  let lo = 0, hi = N;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (cum[m] <= t) lo = m; else hi = m; }
  return (lo + (t - cum[lo]) / Math.max(1e-9, cum[hi] - cum[lo])) / N;
}
// fraksi sudut → fraksi panjang busur
function cumFwd(cum: Float32Array, u: number) {
  const N = cum.length - 1, x = Math.min(1, Math.max(0, u)) * N, i = Math.min(N - 1, Math.floor(x));
  return cum[i] + (cum[i + 1] - cum[i]) * (x - i);
}
export function radiusAt(sg: Seg, t: number) {
  if (!sg.dR) return sg.R;
  const c = Math.min(1, Math.max(0, t));
  return sg.R + sg.dR * sg.sweep * (sg.cum ? cumInv(sg.cum, c) : c);
}
export function sample(sg: Seg, t: number) {
  if (sg.type === 'r') {
    return {
      x: sg.sx + Math.sin(sg.h) * sg.len * t,
      z: sg.sz + Math.cos(sg.h) * sg.len * t,
      y: sg.y0 + (sg.y1 - sg.y0) * t * t,
      h: sg.h,
    };
  }
  if (sg.type === 's') {
    return { x: sg.sx + Math.sin(sg.h) * sg.len * t, z: sg.sz + Math.cos(sg.h) * sg.len * t, y: sg.y0 + (sg.y1 - sg.y0) * t, h: sg.h };
  }
  const u = sg.cum ? cumInv(sg.cum, t) : t;
  const a = sg.a0 + sg.s * sg.sweep * u;
  const e = sg.spiral ? t : t * t * (3 - 2 * t);
  const r = sg.dR ? sg.R + sg.dR * sg.sweep * u : sg.R;
  let h = Math.PI / 2 - (a + sg.s * Math.PI / 2);
  if (sg.dR) h += sg.s * Math.atan(sg.dR / r);
  return { x: sg.cx + r * Math.cos(a), z: sg.cz + r * Math.sin(a), y: sg.y0 + (sg.y1 - sg.y0) * e, h };
}

export function project(sg: Seg, x: number, z: number, hint = 0) {
  if (sg.type === 's' || sg.type === 'r') {
    const dx = x - sg.sx, dz = z - sg.sz;
    const along = dx * Math.sin(sg.h) + dz * Math.cos(sg.h);
    const lat = dx * Math.cos(sg.h) - dz * Math.sin(sg.h);
    if (along < -0.4 || along > sg.len + 0.4) return { t: 0, lat: Infinity, slat: 0 };
    return { t: Math.min(1, Math.max(0, along / sg.len)), lat: Math.abs(lat), slat: lat };
  }
  const a = Math.atan2(z - sg.cz, x - sg.cx);
  let d = (((sg.s * (a - sg.a0)) % TAU) + TAU) % TAU;
  if (sg.sweep > TAU + 0.1) {
    // spiral multi-putaran: lap dipilih dari radius (tiap lap beda radius) + sedikit petunjuk progres
    const hyp = Math.hypot(x - sg.cx, z - sg.cz);
    const laps = Math.ceil(sg.sweep / TAU);
    const hu = sg.cum ? cumInv(sg.cum, hint) : hint;
    let best = -1, bc = Infinity, br = 0;
    for (let k = -1; k <= laps; k++) {
      let dk = d + k * TAU;
      if (dk < -0.08 || dk > sg.sweep + 0.08) continue;
      dk = Math.min(sg.sweep, Math.max(0, dk));
      const rk = sg.R + (sg.dR ?? 0) * dk;
      const cost = Math.abs(hyp - rk) + 0.15 * Math.abs(dk - hu * sg.sweep);
      if (cost < bc) { bc = cost; best = dk; br = rk; }
    }
    if (best < 0) return { t: 0, lat: Infinity, slat: 0 };
    const uu = best / sg.sweep, ll = hyp - br;
    return { t: sg.cum ? cumFwd(sg.cum, uu) : uu, lat: Math.abs(ll), slat: ll };
  } else if (d > sg.sweep) {
    if (d > TAU - 0.08) d = 0;
    else if (d < sg.sweep + 0.08) d = sg.sweep;
    else return { t: 0, lat: Infinity, slat: 0 };
  }
  const l = Math.hypot(x - sg.cx, z - sg.cz) - sg.R;
  return { t: d / sg.sweep, lat: Math.abs(l), slat: l };
}

type Skin = {
  fog: number; sky: [string, string, string];
  road: number; roadSide: number; roadBottom: number;
  line: number; dust: number[];
};

const SKINS: Record<SkinName, Skin> = {
  asphalt: {
    fog: 0xc9b8ff, sky: ['#8f7bff', '#c9b8ff', '#efe6ff'],
    road: 0x40404e, roadSide: 0x9aa0c2, roadBottom: 0x666a85,
    line: 0xf5f5f5, dust: [0x9aa0b8, 0xffffff, 0xe0606e],
  },
  candy: {
    fog: 0xcfe8ff, sky: ['#5fc8ff', '#bfe6ff', '#ffd3ec'],
    road: 0xfdf8ff, roadSide: 0xc4b3f2, roadBottom: 0x9d8ae0,
    line: 0xffd6e6, dust: [0xd9ccff, 0xffffff, 0xff8fb0],
  },
};

// soft edge palette (shared by both skins)
const EDGE = {
  flatA: new THREE.Color(0xe0606e), flatB: new THREE.Color(0xf6f1e7),
  flatSideA: new THREE.Color(0xb84a58), flatSideB: new THREE.Color(0xcfc8b8),
  rail: new THREE.Color(0xbf5570), railSide: new THREE.Color(0x9e4259),
};

export class Game {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  cb: Callbacks;
  sfx = new Sfx();
  music = new Music();
  musicStyle: MusicStyle = 'ceria';
  skin: SkinName = 'asphalt';
  fx: FxName = 'V2';
  roadBuild: RoadBuild = 'instant';
  mode: Mode = 'drift';
  nos: NosColor = 'blue';
  nosN = 0;
  nosKey = false;
  nosToggleMode = false; nosToggleOn = false; nosMul = 1; comboKey = false;
  boostFxOn = false;
  effV = 13;
  slope = 0;
  airborne = false; airVy = 0; airT = 0; airLaunchY = 0; lastJumpN = -99;
  freeDir = 0; freeSlide = 0; freeSX = 0; freeSZ = 0; driftAcc = 0;
  bot: BotMode = 'off';
  bumpX = 0; bumpZ = 0; bumpCD = 0; bumpSlow = 0;
  bots: BotCar[] = [];
  safeDist = 0; maxCur = 0; falls = 0; crashY0 = 0; respLast = 0; invuln = 0; crashWall = 0;
  lastSpiralN = -99; goal = 1100;
  pts: { x: number; z: number; y: number; d: number }[] = []; dry = false; dryList: Seg[] = [];
  holdD = -1; planSpiral = -1; plan: Step[] = []; lastArcS = 0;
  airSp = 13.5; airNos = false; airSeg: Seg | null = null;
  speedName: SpeedName = 'normal'; tune: Tune = { ...SPEEDS.normal }; cornerK = 0; gripT = 0;
  gridOn = false; gridEnd = 0; gridLast = 4; launchK = 1; crashX = 0; crashZ = 0; crashH = 0; camSnap = false;
  rsp = { i: 0, d: 0 }; rspP = { x: 0, y: 0, z: 0, h: 0 }; rspMark!: THREE.Group;
  models: Record<string, CarModel> = {}; model!: CarModel; wx = 0.55; wz = 0.6;
  steerA = 0; steerV = 0; driftAmt = 0; spinF = 0; spinR = 0; turnRate = 0;
  tele: Telemetry = { kmh: 0, rpm: 0, gear: 0, boost: false, drift: false };
  finishD = 1100; raceAcc = 0;
  coins: { m: THREE.Mesh; d: number; chunk: Chunk; got: boolean }[] = [];
  coinStreak = 0; coinT = 0;
  coinGeo = new THREE.BoxGeometry(0.45, 0.55, 0.14);
  coinMat = new THREE.MeshBasicMaterial({ color: 0xffc93c });
  checkerTex!: THREE.CanvasTexture;
  fovKick = 0;
  settled = false;
  overSent = false;
  edge: EdgeName = 'hidden';
  carName: CarName = 'viper';
  pal = { road: new THREE.Color(), roadSide: new THREE.Color(), roadBottom: new THREE.Color(), line: new THREE.Color() };
  segs: Seg[] = [];
  chunks: Chunk[] = [];
  base = 0; cur = 0; dist = 0;
  gen = { x: 0, z: 0, h: 0, y: 0, d: 0 };
  car!: THREE.Group; carBody!: THREE.Group;
  pos = new THREE.Vector3(); h = 0; v = 13;
  vis = { yaw: 0, yawV: 0, roll: 0, sq: 1, sqV: 0, pitch: 0, pitchV: 0 };
  attached: Seg | null = null; attachErr = 0;
  orbit = { r: 0, a: 0, s: 1 };
  holding = false;
  state: 'idle' | 'play' | 'crash' | 'done' = 'idle';
  crashT = 0; crashVel = new THREE.Vector3();
  score = 0; combo = 0; shake = 0;
  camMode: CamMode = 0;
  lastHint = '';
  ropeSegs: THREE.Mesh[] = [];
  ropeT = 0; ropeWob = 0; ropeSlack = 0;
  ropeB = new THREE.Vector3();
  ropeTmpA = new THREE.Vector3(); ropeTmpE = new THREE.Vector3();
  ropeTmp1 = new THREE.Vector3(); ropeTmp2 = new THREE.Vector3(); ropeTmp3 = new THREE.Vector3();
  flame!: THREE.Group;
  flameMeshes: THREE.Mesh[] = [];
  flameOuter!: THREE.MeshBasicMaterial;
  flameMid!: THREE.MeshBasicMaterial;
  flameGlow!: THREE.MeshBasicMaterial;
  light: THREE.DirectionalLight;
  parts: { m: THREE.Mesh; v: THREE.Vector3; life: number; max: number; grow: number; grav: boolean }[] = [];
  partIdx = 0;
  skids: { m: THREE.Mesh; life: number }[] = [];
  skidIdx = 0;
  boxGeo = new THREE.BoxGeometry(1, 1, 1);
  roadMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide, transparent: true });
  gateTex = new Map<string, THREE.CanvasTexture>();
  roadU = { uCam: { value: new THREE.Vector3() }, uCar: { value: new THREE.Vector3() }, uHole: { value: 4.2 } };
  poleMat = new THREE.MeshLambertMaterial({ color: 0xf2f2f5 });
  ringMat = new THREE.MeshLambertMaterial({ color: 0xe0606e });
  signPoleMat = new THREE.MeshLambertMaterial({ color: 0x4a4a5a });
  signBoardMat = new THREE.MeshLambertMaterial({ color: 0x23232e });
  signArrowMat = new THREE.MeshLambertMaterial({ color: 0xffd23f, emissive: 0x553f00 });
  coneMat = new THREE.MeshLambertMaterial({ color: 0xff7a1a });
  coneStripeMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
  camPos = new THREE.Vector3();
  raf = 0; last = performance.now();
  clouds: THREE.Group[] = [];

  constructor(el: HTMLElement, cb: Callbacks) {
    this.cb = cb;
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    el.appendChild(this.renderer.domElement);
    this.camera = new THREE.PerspectiveCamera(50, 1, 0.1, 400);
    this.applySkin(this.skin, true);
    // ujung jalan memudar halus (fade-out) sebelum potongan baru muncul
    this.roadMat.onBeforeCompile = (sh) => {
      Object.assign(sh.uniforms, this.roadU);
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nvarying vec3 vWPos;\nuniform vec3 uCam;\nuniform vec3 uCar;\nuniform float uHole;')
        .replace('#include <fog_fragment>', `#include <fog_fragment>
#ifdef USE_FOG
  gl_FragColor.a *= 1.0 - smoothstep(${FADE_NEAR.toFixed(1)}, ${FADE_FAR.toFixed(1)}, vFogDepth);
#endif
  {
    // x-ray: lantai jalan yang berada di antara kamera & mobil (dan lebih tinggi dari mobil) dibuat transparan
    vec3 cd = uCar - uCam; float cl = length(cd); vec3 cdir = cd / max(cl, 0.001);
    vec3 cw = vWPos - uCam; float ct = dot(cw, cdir);
    float perp = length(cw - cdir * ct);
    float inFront = (1.0 - smoothstep(cl - 1.4, cl - 0.2, ct)) * step(0.0, ct);
    float above = smoothstep(1.4, 2.4, vWPos.y - uCar.y);
    float hole = (1.0 - smoothstep(uHole * 0.5, uHole, perp)) * inFront * above;
    gl_FragColor.a *= 1.0 - 0.92 * hole;
  }`);
    };

    this.scene.add(new THREE.HemisphereLight(0xffffff, 0xb9a8ff, 1.7));
    this.light = new THREE.DirectionalLight(0xfff4e8, 1.5);
    this.light.castShadow = true;
    this.light.shadow.mapSize.set(1024, 1024);
    const sc = this.light.shadow.camera;
    sc.left = -22; sc.right = 22; sc.top = 22; sc.bottom = -22; sc.far = 90;
    this.scene.add(this.light, this.light.target);

    const ropeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    for (let i = 0; i < 12; i++) {
      const rm = new THREE.Mesh(this.boxGeo, ropeMat);
      rm.visible = false;
      this.scene.add(rm);
      this.ropeSegs.push(rm);
    }
    this.ropeB.set(0, 0, 0);

    for (let i = 0; i < 140; i++) {
      const m = new THREE.Mesh(this.boxGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, depthWrite: false }));
      m.visible = false; this.scene.add(m);
      this.parts.push({ m, v: new THREE.Vector3(), life: 0, max: 1, grow: 1, grav: false });
    }
    const skidGeo = new THREE.PlaneGeometry(0.3 * CAR_UP, 0.55 * CAR_UP); skidGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 260; i++) {
      const m = new THREE.Mesh(skidGeo, new THREE.MeshBasicMaterial({ color: 0x23232e, transparent: true, opacity: 0, depthWrite: false }));
      m.visible = false; this.scene.add(m);
      this.skids.push({ m, life: 0 });
    }
    const cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x333344 });
    for (let i = 0; i < 36; i++) {
      const g = new THREE.Group();
      for (let k = 0; k < 4; k++) {
        const b = new THREE.Mesh(this.boxGeo, cloudMat);
        b.scale.set(rand(2, 5), rand(1.5, 3), rand(2, 5));
        b.position.set(rand(-3, 3), rand(-0.5, 0.5), rand(-3, 3));
        g.add(b);
      }
      g.position.set(rand(-70, 70), rand(-40, -15), rand(-20, 140));
      this.scene.add(g); this.clouds.push(g);
    }

    this.buildCars();
    this.buildSpidey();
    this.buildBots();
    this.buildMarker();
    const ccv = document.createElement('canvas'); ccv.width = 64; ccv.height = 16;
    const ccx = ccv.getContext('2d')!;
    for (let yy = 0; yy < 2; yy++) for (let xx = 0; xx < 8; xx++) { ccx.fillStyle = (xx + yy) % 2 ? '#111116' : '#f5f5f5'; ccx.fillRect(xx * 8, yy * 8, 8, 8); }
    this.checkerTex = new THREE.CanvasTexture(ccv); this.checkerTex.colorSpace = THREE.SRGBColorSpace;
    this.buildFlame();
    this.bldMats = [0x8f93c9, 0x7d84c2, 0xa5a8d8, 0x6f76b8].map((c) => new THREE.MeshLambertMaterial({ color: c }));
    const streetGeo = new THREE.PlaneGeometry(500, 500); streetGeo.rotateX(-Math.PI / 2);
    this.street = new THREE.Mesh(streetGeo, new THREE.MeshLambertMaterial({ color: 0x35314a }));
    this.street.visible = false;
    this.scene.add(this.street);
    this.reset();
    window.addEventListener('resize', this.resize);
    this.resize();
    this.warmUp();
    this.loop();
  }

  // render sekali dengan semua objek terlihat → semua shader terkompilasi di muka (bukan saat main → tidak tersendat)
  warmUp() {
    const bv = this.bots.map((b) => b.car.visible), rv = this.rspMark.visible, fv = this.flame.visible;
    this.bots.forEach((b) => { b.car.visible = true; });
    this.rspMark.visible = true; this.flame.visible = true;
    try { this.renderer.compile(this.scene, this.camera); this.renderer.render(this.scene, this.camera); } catch { /* abaikan */ }
    this.bots.forEach((b, i) => { b.car.visible = bv[i]; });
    this.rspMark.visible = rv; this.flame.visible = fv;
  }

  applySkin(name: SkinName, first = false) {
    this.skin = name;
    const S = SKINS[name];
    this.pal.road.set(S.road); this.pal.roadSide.set(S.roadSide); this.pal.roadBottom.set(S.roadBottom);
    this.pal.line.set(S.line);
    const cv = document.createElement('canvas'); cv.width = 2; cv.height = 256;
    const cx = cv.getContext('2d')!;
    const gr = cx.createLinearGradient(0, 0, 0, 256);
    const fogC = new THREE.Color(S.sky[0]).lerp(new THREE.Color(S.sky[1]), 0.55);
    gr.addColorStop(0, S.sky[0]); gr.addColorStop(0.28, '#' + fogC.getHexString()); gr.addColorStop(0.55, S.sky[1]); gr.addColorStop(1, S.sky[2]);
    cx.fillStyle = gr; cx.fillRect(0, 0, 2, 256);
    const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
    const old = this.scene.background as THREE.Texture | null;
    this.scene.background = tex;
    if (old && (old as THREE.Texture).isTexture && !first) (old as THREE.Texture).dispose();
    this.scene.fog = new THREE.Fog(fogC, 42, 112);
  }

  setSkin(name: SkinName) {
    if (name === this.skin) return;
    this.applySkin(name);
    if (this.state !== 'play') this.reset();
  }
  setEdge(e: EdgeName) {
    if (e === this.edge) return;
    this.edge = e;
    if (this.state !== 'play') this.reset();
  }
  ensureModel(id: string) {
    let m = this.models[id];
    if (!m) { m = buildCarModel(id, SHARED_MATS); m.group.visible = false; this.car.add(m.group); this.models[id] = m; }
    return m;
  }
  setCar(name: CarName) {
    this.carName = validCar(name);
    if (this.mode === 'spidey') return;
    this.showCar();
  }
  showCar() {
    const m = this.ensureModel(this.carName);
    for (const k of Object.keys(this.models)) this.models[k].group.visible = k === this.carName;
    this.model = m; this.carBody = m.group; this.carBody.rotation.set(0, 0, 0);
    const a = m.asset;
    if (this.flame) this.flame.position.z = a.rearZ + 1.0; // api NOS keluar dari ujung belakang tiap mobil
    this.wx = a.rearWheel.x * CAR_SCALE; this.wz = -a.rearWheel.z * CAR_SCALE; // posisi roda belakang untuk asap & bekas ban
  }
  applyMode() {
    const sp = this.mode === 'spidey';
    if (sp) { for (const k of Object.keys(this.models)) this.models[k].group.visible = false; this.carBody = this.spideyBody; }
    else this.showCar();
    this.spideyRoot.visible = sp;
    this.carBody.rotation.set(0, 0, 0);
    this.street.visible = false;
  }
  setCam(m: CamMode) { this.camMode = m; }
  setSpeed(n: SpeedName) { this.speedName = n; this.tune = { ...(SPEEDS[n] ?? SPEEDS.normal) }; }
  setMode(m: Mode) { if (m === this.mode) return; this.mode = m; this.applyBots(); if (this.state !== 'play') this.reset(); }
  setBot(b: BotMode) {
    this.bot = b;
    this.applyBots();
    if (this.state !== 'play') this.reset();
  }
  nBots() { return this.mode === 'spidey' ? 0 : this.bot === 'ghost5' ? 5 : this.bot === 'off' ? 0 : 1; }
  applyBots() {
    const n = this.nBots();
    const ghost = this.bot === 'ghost' || this.bot === 'ghost5';
    this.bots.forEach((b, i) => {
      b.active = i < n;
      b.car.visible = b.active;
      b.tag.visible = b.active && this.bot === 'ghost5';
    });
    for (const b of this.bots) {
      for (const mt of b.mats.list) {
        const m = mt as THREE.MeshStandardMaterial;
        m.transparent = ghost;
        m.opacity = ghost ? 0.5 : 1;
        m.depthWrite = !ghost;
        if (m.emissive) m.emissive.setHex(ghost ? 0x16264f : 0x000000);
        m.needsUpdate = true;
      }
      for (const dm of b.model.decalMats) dm.opacity = ghost ? 0.5 : 1;
    }
  }
  raceOn() { return this.bot !== 'off' && this.mode !== 'spidey'; }
  finishOn() { return this.mode !== 'spidey' && (this.bot !== 'off' || this.goal > 0); }
  setGoal(m: number) { if (m === this.goal) return; this.goal = m; if (this.state !== 'play') this.reset(); }
  setFx(f: FxName) { const was = this.fx; this.fx = f; if (was !== f && this.state !== 'play') this.reset(); }
  setRoadBuild(b: RoadBuild) { if (b === this.roadBuild) return; this.roadBuild = b; if (this.state !== 'play') this.reset(); }
  setNos(c: NosColor) {
    this.nos = c;
    if (this.flameOuter) {
      this.flameOuter.color.set(NOS[c].outer);
      this.flameMid.color.set(NOS[c].mid);
      this.flameGlow.color.set(NOS[c].outer);
    }
  }
  setNosMode(toggle: boolean) { this.nosToggleMode = toggle; this.nosToggleOn = false; }
  setBoostFx(on: boolean) { if (on !== this.boostFxOn) { this.boostFxOn = on; this.cb.onBoost?.(on); } }
  nosActive() { return this.nosN > 0 || this.nosKey || this.nosToggleOn || this.comboKey; }
  nosDown() {
    if (this.nosToggleMode) {
      this.nosToggleOn = !this.nosToggleOn;
      if (this.nosToggleOn && this.state === 'play') this.sfx.nos(true);
    } else {
      this.nosN++;
      if (this.state === 'play') this.sfx.nos(true);
    }
  }
  nosUp() { if (!this.nosToggleMode) this.nosN = Math.max(0, this.nosN - 1); }
  nosKeyDown() { if (!this.nosKey) { this.nosKey = true; if (this.state === 'play') this.sfx.nos(true); } }
  nosKeyUp() { this.nosKey = false; }
  comboDown() { if (!this.comboKey) { this.comboKey = true; if (this.state === 'play') this.sfx.nos(true); } }
  comboUp() { this.comboKey = false; }
  hideRope() { for (const m of this.ropeSegs) m.visible = false; }
  ropeAY() { return this.mode === 'spidey' ? 1.3 : 0.8; }
  renderRope(A: THREE.Vector3, E: THREE.Vector3, time: number) {
    const N = this.ropeSegs.length;
    const dir = this.ropeTmp1.copy(E).sub(A);
    const L = Math.max(0.001, dir.length());
    const side = this.ropeTmp2.set(-dir.z, 0, dir.x);
    if (side.lengthSq() < 1e-6) side.set(1, 0, 0); else side.normalize();
    const sagAmt = (0.04 + this.ropeSlack) * L * 0.1;
    const wob = this.ropeWob * Math.min(1.4, 2 + L * 0.05);
    const th = (0.07 + this.ropeSlack * 0.06) * (this.mode === 'spidey' ? 0.55 : 1);
    let px = 0, py = 0, pz = 0;
    for (let i = 0; i <= N; i++) {
      const tt = i / N;
      const env = Math.sin(Math.PI * tt);
      const wx = A.x + (E.x - A.x) * tt + side.x * wob * env * Math.sin(time * 26 - tt * 7);
      const wy = A.y + (E.y - A.y) * tt - sagAmt * env + wob * 0.3 * env * Math.cos(time * 31 - tt * 5);
      const wz = A.z + (E.z - A.z) * tt + side.z * wob * env * Math.sin(time * 26 - tt * 7);
      if (i > 0) {
        const m = this.ropeSegs[i - 1];
        m.visible = true;
        m.position.set((px + wx) / 2, (py + wy) / 2, (pz + wz) / 2);
        this.ropeTmp3.set(wx, wy, wz);
        m.lookAt(this.ropeTmp3);
        m.scale.set(th, th, Math.hypot(wx - px, wy - py, wz - pz) * 1.2 + 0.02);
      }
      px = wx; py = wy; pz = wz;
    }
  }
  buildFlame() {
    const flame = new THREE.Group();
    this.flameOuter = new THREE.MeshBasicMaterial({ color: NOS[this.nos].outer, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false });
    this.flameMid = new THREE.MeshBasicMaterial({ color: NOS[this.nos].mid, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    const core = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false });
    const f1 = new THREE.Mesh(this.boxGeo, this.flameOuter); f1.scale.set(0.44, 0.44, 0.92); f1.position.set(0, 0.35, -1.32);
    const f2 = new THREE.Mesh(this.boxGeo, this.flameMid); f2.scale.set(0.27, 0.27, 0.72); f2.position.set(0, 0.35, -1.24);
    const f3 = new THREE.Mesh(this.boxGeo, core); f3.scale.set(0.14, 0.14, 0.5); f3.position.set(0, 0.35, -1.16);
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const cx2 = cv.getContext('2d')!;
    const grd = cx2.createRadialGradient(64, 64, 4, 64, 64, 64);
    grd.addColorStop(0, 'rgba(255,255,255,0.85)');
    grd.addColorStop(0.45, 'rgba(255,255,255,0.28)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    cx2.fillStyle = grd; cx2.fillRect(0, 0, 128, 128);
    this.flameGlow = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(cv), color: NOS[this.nos].outer, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
    const glowGeo = new THREE.PlaneGeometry(3.4, 5.2); glowGeo.rotateX(-Math.PI / 2);
    const glow = new THREE.Mesh(glowGeo, this.flameGlow);
    glow.position.set(0, 0.06, -0.6); glow.renderOrder = 5;
    flame.add(f1, f2, f3, glow);
    flame.visible = false;
    this.flame = flame;
    this.flameMeshes = [f1, f2, f3];
    this.car.add(flame);
  }
  animWheels(rigs: WheelRig[] | undefined, steer: number, spinF: number, spinR: number, drift: number) {
    if (!rigs) return;
    for (const w of rigs) {
      w.steer.rotation.y = w.front ? steer : 0;
      w.camber.rotation.z = w.side * (w.front ? 0.1 + drift * 0.1 : 0.14 + drift * 0.05);
      w.spin.rotation.x = w.front ? spinF : spinR;
    }
  }
  makeTag(name: string, color: string) {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 72;
    const c = cv.getContext('2d')!;
    c.fillStyle = 'rgba(12,10,34,0.78)'; c.beginPath(); c.roundRect(4, 8, 248, 56, 28); c.fill();
    c.strokeStyle = color; c.lineWidth = 3; c.stroke();
    c.fillStyle = color; c.beginPath(); c.arc(38, 36, 12, 0, TAU); c.fill();
    c.font = '700 30px "Lilita One", system-ui, sans-serif'; c.fillStyle = '#fff'; c.textBaseline = 'middle'; c.fillText(name, 64, 39);
    const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
    sp.scale.set(3.1, 0.87, 1); sp.renderOrder = 10; sp.visible = false;
    return sp;
  }
  buildBots() {
    BOT_DEFS.forEach((def) => {
      const car = new THREE.Group();
      const mats = makeMats(true);
      const model = buildCarModel(def.car, mats, false);
      car.add(model.group);
      const tag = this.makeTag(def.name, def.color);
      tag.position.set(0, model.asset.height + 1.1, 0);
      car.add(tag);
      car.scale.setScalar(CAR_SCALE);
      car.visible = false;
      this.scene.add(car);
      this.bots.push({
        car, model, mats, rigs: model.rigs, tag, name: def.name, color: def.color, active: false,
        dist: 0, v: 13, off: 0, h: 0, push: 0, lane: 0, skill: 1, nosT: 0, nosCD: 3, phase: 0, finished: false, turn: 0, yaw: 0, yawV: 0,
        steer: 0, steerV: 0, spinA: 0, inArc: false, arcSeg: null, arcS: 1, crashT: 0, crashP: 0, blink: 0, skidT: 0,
        cpos: new THREE.Vector3(), cvel: new THREE.Vector3(),
      });
    });
  }

  // penanda titik respawn (cincin + panah arah) supaya pemain tahu mobil akan muncul di mana & menghadap ke mana
  buildMarker() {
    const g = new THREE.Group();
    const mat = new THREE.MeshBasicMaterial({ color: 0x7cf0ff, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending });
    const ringGeo = new THREE.RingGeometry(1.05, 1.4, 40); ringGeo.rotateX(-Math.PI / 2);
    const arrowGeo = new THREE.ConeGeometry(0.42, 0.95, 3); arrowGeo.rotateX(Math.PI / 2);
    const arrow = new THREE.Mesh(arrowGeo, mat); arrow.position.set(0, 0.1, 2.1);
    g.add(new THREE.Mesh(ringGeo, mat), arrow);
    g.visible = false; g.renderOrder = 4;
    g.userData.k = CAR_UP;
    this.scene.add(g); this.rspMark = g;
  }
  // ---------- AI bot: garis balap, drift ala pembalap, NOS cerdas, jatuh jarang ----------
  resetBots() {
    const n = this.nBots();
    const grid = n === 1
      ? [{ d: -3.5, o: 0 }]
      : [{ d: 4, o: -1.2 }, { d: 4, o: 1.2 }, { d: 8, o: -0.6 }, { d: 8, o: 0.6 }, { d: 12, o: 0 }];
    this.bots.forEach((b, i) => {
      const g = grid[i] ?? grid[0];
      b.dist = 4 + g.d; b.lane = g.o; b.off = g.o; b.v = 13; b.push = 0; b.finished = false;
      b.skill = n > 1 ? 0.97 + rand(0, 0.09) : 1;
      b.nosT = 0; b.nosCD = rand(2, 5); b.phase = rand(0, TAU);
      b.turn = 0; b.yaw = 0; b.yawV = 0; b.steer = 0; b.steerV = 0; b.inArc = false; b.arcSeg = null; b.crashT = 0; b.blink = 0; b.skidT = 0;
      b.crashP = n > 1 ? 0.012 : 0;
      this.poseBot(b, undefined, 0.016, 0);
    });
  }
  segAtDist(d: number) {
    const end = this.base + this.segs.length;
    for (let i = Math.max(this.base, this.cur - 4); i < end; i++) { const sg = this.seg(i); if (d <= sg.d0 + sg.len) return sg; }
    return this.segs[this.segs.length - 1];
  }
  rampAhead(d: number) {
    for (let i = Math.max(this.base, this.cur - 1); i < this.base + this.segs.length; i++) {
      const sg = this.seg(i);
      if (sg.d0 - d > 24) break;
      if (sg.jmp === 2 && sg.d0 + sg.len > d - 1) return true;
    }
    return false;
  }
  poseBot(b: BotCar, sg: Seg | undefined, dt: number, t: number) {
    const isArc = !!sg && sg.type === 'a';
    const bp = this.posAtDist(b.dist);
    b.car.position.set(bp.x + Math.cos(bp.h) * b.off, bp.y, bp.z - Math.sin(bp.h) * b.off);
    b.h = bp.h;
    const turnA = isArc && sg ? (-sg.s * b.v) / radiusAt(sg, (b.dist - sg.d0) / Math.max(0.001, sg.len)) : 0;
    b.turn += (turnA - b.turn) * Math.min(1, dt * 6);
    const drift = Math.min(1, Math.abs(b.turn) / 1.1);
    const yawT = THREE.MathUtils.clamp(b.turn * 0.36, -0.62, 0.62) + Math.sin(t * 3.1 + b.phase) * 0.04 * drift;
    b.yawV += ((yawT - b.yaw) * 45 - b.yawV * 7) * dt;
    b.yaw += b.yawV * dt;
    b.car.rotation.set(0, bp.h + b.yaw, 0);
    const wob = Math.sin(t * 6.4 + b.phase) * 0.1 * drift;
    const steerT = THREE.MathUtils.lerp(b.turn * 0.1, THREE.MathUtils.clamp(-b.yaw * 1.3, -0.85, 0.85) + wob, drift);
    b.steerV += ((steerT - b.steer) * 260 - b.steerV * 15) * dt;
    b.steer = THREE.MathUtils.clamp(b.steer + b.steerV * dt, -0.9, 0.9);
    b.spinA += (9 + b.v * 0.45) * dt;
    this.animWheels(b.rigs, b.steer, b.spinA, b.spinA * (1 + drift * 0.9), drift);
    if (b.model.parts.length) animateParts(b.model.parts, dt, t, { open: true, boost: b.nosT > 0, drift: drift > 0.5 });
    return drift;
  }
  crashBot(b: BotCar, sg: Seg) {
    b.crashT = RESPAWN_T;
    b.cpos.copy(b.car.position);
    const ox = b.car.position.x - sg.cx, oz = b.car.position.z - sg.cz, ol = Math.hypot(ox, oz) || 1;
    b.cvel.set(Math.sin(b.h) * b.v * 0.7 + (ox / ol) * 4, 6, Math.cos(b.h) * b.v * 0.7 + (oz / ol) * 4);
    b.v = 0; b.inArc = false; b.arcSeg = null;
    if (Math.abs(b.dist - this.dist) < 30) this.burst(b.car.position, [0xffffff, 0x9aa0b8], 10);
  }
  driveBot(b: BotCar, i: number, n: number, dt: number, t: number, endD: number) {
    const sg = this.segAtDist(b.dist);
    const tIn = sg ? THREE.MathUtils.clamp((b.dist - sg.d0) / Math.max(0.001, sg.len), 0, 1) : 0;
    const isArc = !!sg && sg.type === 'a';
    const gap = this.dist - b.dist; // + = bot di belakang pemain
    // ---- bot jatuh: 3 detik lalu respawn, bot lain terus balapan ----
    if (b.crashT > 0) {
      b.crashT -= dt;
      b.cvel.y -= 30 * dt;
      b.cpos.addScaledVector(b.cvel, dt);
      b.car.position.copy(b.cpos);
      b.car.rotation.x += dt * 7; b.car.rotation.z += dt * 5;
      b.car.visible = gap < 11 && b.cpos.y > this.pos.y - 30;
      b.tag.visible = false;
      if (b.crashT <= 0) {
        b.crashT = 0; b.dist = Math.max(0, b.dist - 3); b.v = this.v * 0.6; b.off = 0;
        b.yaw = 0; b.yawV = 0; b.blink = 1.6; b.nosT = 0;
      }
      return;
    }
    // ---- kecepatan ----
    if (n === 1) {
      // buddy: mengikuti kecepatan efektif pemain + rubber band
      const diff = b.dist - this.dist;
      b.v = THREE.MathUtils.clamp(this.effV + THREE.MathUtils.clamp(-diff * 0.25, -4, 6), 6, 60);
      if (this.dist - b.dist > 40) b.dist = this.dist - 25;
    } else {
      // racer: NOS hanya di lurusan panjang atau sebelum ramp lompatan
      b.nosCD -= dt;
      if (b.nosT > 0) b.nosT -= dt;
      else if (b.nosCD <= 0 && sg) {
        const left = sg.type === 's' ? sg.d0 + sg.len - b.dist : 0;
        const ramp = this.rampAhead(b.dist);
        if ((ramp && Math.random() < dt * 8) || (!sg.jmp && left > 9 && Math.random() < dt * 0.9)) { b.nosT = ramp ? 1.9 : rand(1.1, 2); b.nosCD = rand(3, 6); }
      }
      const tgt = (this.v * b.skill * (isArc ? 0.97 : 1) * (b.nosT > 0 ? 1.5 : 1) + THREE.MathUtils.clamp(gap * 0.05, -2.5, 4)) * (0.25 + 0.75 * this.launchK);
      b.v += (tgt - b.v) * Math.min(1, dt * 2.5);
    }
    b.dist = Math.min(endD, b.dist + (b.v + b.push) * dt);
    if (!b.finished && b.dist >= this.finishD) b.finished = true;
    b.push *= Math.exp(-2.5 * dt);
    // ---- masuk / keluar tikungan: flick drift ----
    if (isArc && sg && sg !== b.arcSeg) {
      b.yawV += (b.arcSeg ? b.arcS * 2.2 : 0) - sg.s * 2.6; // flick; di S-curve: ganti arah drift
      b.arcSeg = sg; b.inArc = true; b.arcS = sg.s;
      if (b.crashP > 0 && !sg.spiral && Math.random() < b.crashP * (b.nosT > 0 ? 2.5 : 1)) { this.crashBot(b, sg); return; }
    } else if (!isArc && b.arcSeg) {
      b.arcSeg = null; b.inArc = false; b.yawV += b.arcS * 2.2;
    }
    // ---- garis balap: apex di dalam tikungan, jaga jarak antar bot, tetap di aspal ----
    let tgt = b.lane;
    if (isArc && sg) {
      const inside = -sg.s, apex = Math.sin(Math.PI * tIn);
      tgt = sg.spiral ? inside * 0.5 : b.lane * (1 - apex) + inside * 0.6 * apex;
    } else if (n > 1) tgt += Math.sin(t * 0.6 + b.phase) * 0.2;
    if (n > 1) {
      for (let j = 0; j < n; j++) {
        if (j === i) continue;
        const o = this.bots[j];
        if (o.crashT > 0 || Math.abs(o.dist - b.dist) > 4) continue;
        const dx = b.off - o.off;
        if (Math.abs(dx) < 1.7) tgt += (dx > 0 || (dx === 0 && i > j) ? 1 : -1) * 0.6 * (1 - Math.abs(dx) / 1.7);
      }
    }
    tgt = THREE.MathUtils.clamp(tgt, -1.1, 1.1);
    b.off += (tgt - b.off) * Math.min(1, dt * 2.2);
    // ---- tampil ----
    const hide = gap > 11 || (this.roadBuild === 'wave' && this.fx !== 'V1' && -gap > 90);
    b.blink = Math.max(0, b.blink - dt);
    b.car.visible = !hide && (b.blink <= 0 || Math.floor(b.blink * 14) % 2 === 0);
    b.tag.visible = !hide && this.bot === 'ghost5';
    const drift = this.poseBot(b, sg, dt, t);
    if (!hide && drift > 0.5 && Math.abs(gap) < 40) {
      const yw = b.h + b.yaw, fx = Math.sin(yw), fz = Math.cos(yw);
      if (Math.random() < 0.1) {
        this.spawn(new THREE.Vector3(b.car.position.x - fx * 0.9, b.car.position.y + 0.3, b.car.position.z - fz * 0.9), 0xffffff,
          new THREE.Vector3(rand(-1, 1) - fx, rand(1, 2), rand(-1, 1) - fz), 0.4, 0.6, 2);
      }
      b.skidT -= dt;
      if (b.skidT <= 0) { b.skidT = 0.1; this.skid(b.car.position.x - fx * 0.7, b.car.position.y, b.car.position.z - fz * 0.7, yw); }
    }
  }
  stepBots(dt: number, t: number) {
    const n = this.nBots();
    if (!n || this.gridOn || (this.state !== 'play' && this.state !== 'crash')) return;
    const last = this.segs[this.segs.length - 1];
    const endD = last ? last.d0 + last.len - 3 : 1e9;
    let fin = 0;
    for (let i = 0; i < n; i++) { const b = this.bots[i]; this.driveBot(b, i, n, dt, t, endD); if (b.finished) fin++; }
    if (this.state === 'play' && fin >= n && this.raceOn()) this.finishRace(false);
  }
  emitRace() {
    const n = this.nBots();
    const rows: RaceRow[] = [{ id: -1, name: 'KAMU', color: '#fde047', p: Math.min(1, this.dist / this.finishD), me: true }];
    for (let i = 0; i < n; i++) { const b = this.bots[i]; rows.push({ id: i, name: b.name, color: b.color, p: Math.min(1, b.dist / this.finishD), me: false }); }
    rows.sort((a, c) => c.p - a.p);
    this.cb.onRace?.({ rem: Math.max(0, Math.round(this.finishD - this.dist)), place: rows.findIndex((r) => r.me) + 1, total: n + 1, rows });
  }
  // senggolan realistis (mode Solid, 1 bot): dempetan sustained + transfer momentum
  solidCollide(dt: number, sp: number) {
    const b = this.bots[0];
    const dx = this.pos.x - b.car.position.x, dz = this.pos.z - b.car.position.z;
    const dy = this.pos.y - b.car.position.y;
    const d2 = dx * dx + dz * dz;
    const touching = d2 < 9 && Math.abs(dy) < 3;
    this.bumpSlow += ((touching ? 1 : 0) - this.bumpSlow) * Math.min(1, dt * 5);
    if (!touching) return;
    const d = Math.sqrt(Math.max(0.01, d2));
    const nx = dx / d, nz = dz / d;
    const sep = Math.min(3 - d, 4 * dt);
    this.pos.x += nx * sep * 0.65; this.pos.z += nz * sep * 0.65;
    const brx = Math.cos(b.h), brz = -Math.sin(b.h);
    b.off = THREE.MathUtils.clamp(b.off - (nx * brx + nz * brz) * sep * 0.6, -3.2, 3.2);
    const pvx = Math.sin(this.h) * sp + this.bumpX, pvz = Math.cos(this.h) * sp + this.bumpZ;
    const bvx = Math.sin(b.h) * b.v, bvz = Math.cos(b.h) * b.v;
    const rvn = (pvx - bvx) * nx + (pvz - bvz) * nz;
    if (rvn < 0) {
      const j = -(1 + 0.12) * rvn * 0.5;
      this.bumpX += nx * j; this.bumpZ += nz * j;
      const bm = Math.hypot(this.bumpX, this.bumpZ);
      if (bm > 8) { this.bumpX *= 8 / bm; this.bumpZ *= 8 / bm; }
      b.push += -(nx * Math.sin(b.h) + nz * Math.cos(b.h)) * j;
      if (this.bumpCD <= 0) {
        this.bumpCD = 0.5;
        this.shake = Math.max(this.shake, Math.min(0.35, -rvn * 0.03));
        this.sfx.thud(Math.min(14, 4 - rvn));
        this.burst(this.pos, [0xffd23f, 0xffffff], 8);
        navigator.vibrate?.(40);
      }
    }
    this.sfx.rumble();
    if (Math.random() < 0.35) {
      this.spawn(new THREE.Vector3((this.pos.x + b.car.position.x) / 2 + rand(-0.5, 0.5), this.pos.y + 0.5, (this.pos.z + b.car.position.z) / 2 + rand(-0.5, 0.5)), Math.random() < 0.5 ? 0xffd23f : 0xfff6d8, new THREE.Vector3(rand(-3, 3), rand(2, 6), rand(-3, 3)), 0.22, 0.4, 0.5);
    }
  }
  buildSpidey() {
    const L = (c: number) => new THREE.MeshLambertMaterial({ color: c });
    const red = L(0xd63a3a), blue = L(0x2f5fd0), white = L(0xffffff), dark = L(0x23232e);
    const root = new THREE.Group();
    const body = new THREE.Group();
    const bx = (w: number, h: number, d: number, x: number, y: number, z: number, m: THREE.Material) => {
      const b = new THREE.Mesh(this.boxGeo, m);
      b.scale.set(w, h, d); b.position.set(x, y, z); b.castShadow = true;
      body.add(b); return b;
    };
    bx(0.5, 0.35, 0.35, 0, 0.95, 0, blue);
    bx(0.55, 0.55, 0.38, 0, 1.35, 0, red);
    bx(0.2, 0.5, 0.1, 0, 1.35, 0.2, dark);
    bx(0.42, 0.42, 0.42, 0, 1.85, 0, red);
    bx(0.16, 0.12, 0.06, -0.12, 1.9, 0.2, white);
    bx(0.16, 0.12, 0.06, 0.12, 1.9, 0.2, white);
    const mkLimb = (x: number, y: number, w: number, l: number, m: THREE.Material, boot: boolean) => {
      const piv = new THREE.Group(); piv.position.set(x, y, 0);
      const a = new THREE.Mesh(this.boxGeo, m); a.scale.set(w, l, w); a.position.y = -l / 2; a.castShadow = true; piv.add(a);
      if (boot) { const bt = new THREE.Mesh(this.boxGeo, red); bt.scale.set(w + 0.04, 0.14, w + 0.12); bt.position.set(0, -l - 0.04, 0.03); bt.castShadow = true; piv.add(bt); }
      body.add(piv); return piv;
    };
    this.armL = mkLimb(-0.37, 1.55, 0.16, 0.55, red, false);
    this.armR = mkLimb(0.37, 1.55, 0.16, 0.55, red, false);
    this.legL = mkLimb(-0.15, 0.78, 0.18, 0.6, blue, true);
    this.legR = mkLimb(0.15, 0.78, 0.18, 0.6, blue, true);
    root.add(body);
    root.visible = false;
    root.scale.setScalar(1 / CAR_UP); // Spidey tidak ikut membesar
    this.spideyRoot = root; this.spideyBody = body;
    this.car.add(root);
  }
  updateSpidey(dt: number, t: number) {
    if (this.state === 'crash') {
      this.armL.rotation.x = Math.sin(t * 21) * 1.2;
      this.armR.rotation.x = Math.sin(t * 23 + 1) * 1.2;
      this.legL.rotation.x = Math.sin(t * 19 + 2) * 1.0;
      this.legR.rotation.x = Math.sin(t * 22 + 3) * 1.0;
      return;
    }
    const D = Math.min(1, dt * 14);
    let aL = 0, aR = 0, lL = 0, lR = 0;
    if (this.attached) { aR = -2.7; aL = 0.9; lL = 0.85; lR = -0.55; }
    else {
      this.runPhase += dt * (6 + this.effV * 0.12);
      const p = this.runPhase;
      lL = Math.sin(p) * 0.75; lR = Math.sin(p + Math.PI) * 0.75;
      aL = Math.sin(p + Math.PI) * 0.6; aR = Math.sin(p) * 0.6;
    }
    this.armL.rotation.x += (aL - this.armL.rotation.x) * D;
    this.armR.rotation.x += (aR - this.armR.rotation.x) * D;
    this.legL.rotation.x += (lL - this.legL.rotation.x) * D;
    this.legR.rotation.x += (lR - this.legR.rotation.x) * D;
  }
  buildBlds(seg: Seg) {
    const g = new THREE.Group();
    const n = Math.max(2, Math.round(seg.len / 4));
    for (let i = 0; i <= n; i++) {
      const sp = sample(seg, i / n);
      for (const sd of [-1, 1]) {
        if (Math.random() < 0.15) continue;
        const rx = Math.cos(sp.h), rz = -Math.sin(sp.h);
        const off = sd * (W / 2 + rand(3.5, 8));
        const w = rand(3, 6.5), dpt = rand(3, 6.5);
        const topY = sp.y + rand(-5, 7);
        const hgt = rand(25, 55);
        const b = new THREE.Mesh(this.boxGeo, this.bldMats[(Math.random() * this.bldMats.length) | 0]);
        b.position.set(sp.x + rx * off, topY - hgt / 2, sp.z + rz * off);
        b.scale.set(w, hgt, dpt);
        b.rotation.y = sp.h;
        g.add(b);
        const cap = new THREE.Mesh(this.boxGeo, this.bldCapMat);
        cap.position.set(b.position.x, topY + 0.15, b.position.z);
        cap.scale.set(w + 0.3, 0.3, dpt + 0.3);
        cap.rotation.y = sp.h;
        g.add(cap);
        if (Math.random() < 0.3) {
          const bc = new THREE.Mesh(this.boxGeo, this.bldBeaconMat);
          bc.position.set(b.position.x, topY + 0.7, b.position.z);
          bc.scale.setScalar(0.4);
          g.add(bc);
        }
      }
    }
    seg.bld = g;
    this.scene.add(g);
  }
  setMusicStyle(s2: MusicStyle) { this.musicStyle = s2; this.music.setStyle(s2); }
  cycleCam(): CamMode { this.camMode = ((this.camMode + 1) % 3) as CamMode; return this.camMode; }
  edgeTol() { return (this.edge === 'flat' ? W / 2 + 1.05 : this.edge === 'rail' ? W / 2 + 0.35 : W / 2 + 0.7) + FORGIVE; }
  spideyRoot!: THREE.Group; spideyBody!: THREE.Group;
  armL!: THREE.Group; armR!: THREE.Group; legL!: THREE.Group; legR!: THREE.Group;
  runPhase = 0;
  street!: THREE.Mesh;
  bldMats: THREE.MeshLambertMaterial[] = [];
  bldCapMat = new THREE.MeshLambertMaterial({ color: 0xe8e6f5 });
  bldBeaconMat = new THREE.MeshBasicMaterial({ color: 0xff4455 });
  tangentAtDist(d: number): number {
    for (let i = this.cur; i < this.base + this.segs.length; i++) {
      const sg = this.seg(i);
      if (!sg) break;
      if (d <= sg.d0 + sg.len) {
        const t = Math.min(1, Math.max(0, (d - sg.d0) / Math.max(0.001, sg.len)));
        return sg.type === 'r' || sg.type === 's' ? sg.h : sample(sg, t).h;
      }
    }
    return this.h;
  }

  freeUpdate(dt: number, sp: number) {
    const manual = this.mode === 'free' || (this.holding && !this.attached && this.nosActive());
    if (!this.holding || !manual) {
      this.freeDir *= Math.exp(-6 * dt);
      this.freeSlide *= Math.exp(-4 * dt);
      this.pos.x += this.freeSX * this.freeSlide * dt;
      this.pos.z += this.freeSZ * this.freeSlide * dt;
      this.driftAcc = 0;
      return;
    }
    let d = 0, R = 7, onArc = false, ox = 0, oz = 0;
    for (let i = this.cur; i < this.cur + 3; i++) {
      const sg = this.seg(i);
      if (!sg || sg.type !== 'a') continue;
      if (i === this.cur) {
        const p = this.proj(sg, this.pos.x, this.pos.z);
        if (p.lat < W / 2 + 3) {
          d = -sg.s; R = this.rad(sg);
          if (p.lat < W / 2 + 1.5) {
            onArc = true;
            const l = Math.hypot(this.pos.x - sg.cx, this.pos.z - sg.cz) || 1;
            ox = (this.pos.x - sg.cx) / l; oz = (this.pos.z - sg.cz) / l;
          }
          break;
        }
      } else if (sg.d0 - this.dist < (this.mode === 'free' ? 25 : 40)) { d = -sg.s; R = this.rad(sg); break; }
    }
    this.freeDir = d;
    if (d !== 0) {
      const rate = sp / Math.max(3, R * (onArc ? 0.95 : 1.4));
      this.h += d * rate * dt * (onArc ? 1 : 0.45);
    }
    const slideT = onArc ? sp * 0.3 : 0;
    this.freeSlide += (slideT - this.freeSlide) * Math.min(1, dt * 3);
    if (onArc) { this.freeSX = ox; this.freeSZ = oz; }
    this.pos.x += this.freeSX * this.freeSlide * dt;
    this.pos.z += this.freeSZ * this.freeSlide * dt;
    if (onArc) {
      this.driftAcc += dt;
      if (this.driftAcc >= 0.8) { this.driftAcc -= 0.8; this.score++; this.cb.onScore(this.score, this.combo); this.sfx.tick(); }
    } else this.driftAcc = 0;
  }
  freeLate(): boolean {
    const sg = this.seg(this.cur);
    if (!sg || sg.type !== 'a') return false;
    const p = this.proj(sg, this.pos.x, this.pos.z);
    return p.t > 0.6 && p.lat < W;
  }
  posAtDist(d: number) {
    const startI = Math.max(this.base, this.cur - 4);
    for (let i = startI; i < this.base + this.segs.length; i++) {
      const sg = this.seg(i);
      if (!sg) break;
      if (d >= sg.d0 && d <= sg.d0 + sg.len) {
        const p = sample(sg, (d - sg.d0) / Math.max(0.001, sg.len));
        return { x: p.x, y: p.y, z: p.z, h: p.h };
      }
      if (d < sg.d0 && i > startI) {
        const pv = this.seg(i - 1);
        if (pv) {
          const e0 = sample(pv, 1), e1 = sample(sg, 0);
          const gap = Math.max(0.01, sg.d0 - (pv.d0 + pv.len));
          const t = Math.min(1, Math.max(0, (d - (pv.d0 + pv.len)) / gap));
          const hop = Math.sin(t * Math.PI) * 2.2;
          return { x: e0.x + (e1.x - e0.x) * t, y: e0.y + (e1.y - e0.y) * t + hop, z: e0.z + (e1.z - e0.z) * t, h: Math.atan2(e1.x - e0.x, e1.z - e0.z) };
        }
      }
    }
    const fst = this.seg(startI);
    if (fst && d < fst.d0) {
      const p = sample(fst, 0);
      const back = fst.d0 - d;
      return { x: p.x - Math.sin(p.h) * back, y: p.y, z: p.z - Math.cos(p.h) * back, h: p.h };
    }
    const last = this.segs[this.segs.length - 1];
    if (last) { const p = sample(last, 1); return { x: p.x, y: p.y, z: p.z, h: p.h }; }
    return { x: 0, y: 0, z: 4, h: 0 };
  }
  finishRace(playerFinished: boolean) {
    if (this.state === 'done') return;
    this.state = 'done';
    this.attached = null; this.ropeT = 0; this.hideRope();
    this.setBoostFx(false); this.setHint('');
    this.cb.onRespawn?.(0);
    const active = this.bots.filter((b) => b.active);
    const place = playerFinished ? 1 + active.filter((b) => b.finished).length : 1 + active.filter((b) => b.dist > this.dist).length;
    const win = playerFinished && place === 1;
    if (playerFinished && place <= 3) {
      for (let k = 0; k < 3; k++) this.burst(this.pos.clone().add(new THREE.Vector3(rand(-3, 3), 2 + k, rand(-3, 3))), [0xffd23f, 0xff5c8a, 0x7cf0ff, 0xffffff], 20);
      this.sfx.fanfare();
      navigator.vibrate?.([30, 50, 30, 50, 60]);
    }
    this.cb.onRaceEnd?.({ win, score: this.score, place, total: active.length + 1, finished: playerFinished, falls: this.falls });
  }

  // ---------- jatuh → respawn 3 detik ----------
  beginCrash(vel: THREE.Vector3, ground: boolean) {
    this.state = 'crash'; this.crashT = 0; this.crashY0 = this.pos.y; this.crashWall = performance.now();
    this.crashX = this.pos.x; this.crashZ = this.pos.z; this.crashH = this.h;
    this.rsp = this.computeRespawn();
    this.rspP = this.posAtDist(this.rsp.d);
    this.rspMark.position.set(this.rspP.x, this.rspP.y + 0.1, this.rspP.z); this.rspMark.rotation.y = this.rspP.h; this.rspMark.visible = true;
    this.settled = false; this.overSent = false;
    this.attached = null; this.ropeT = 0; this.hideRope();
    this.nosN = 0; this.nosKey = false; this.comboKey = false; this.nosToggleOn = false; this.setBoostFx(false);
    this.airborne = false;
    this.crashVel.copy(vel);
    this.falls++;
    if (this.combo) { this.combo = 0; this.cb.onScore(this.score, 0); }
    this.shake = 0.35;
    if (ground) this.burst(this.pos, [0xffc93c, 0xffffff, 0x2b2b3a], 24);
    this.cb.onPopup('OOPS!', '#ff5c8a');
    this.sfx.crash();
    this.setHint('');
    navigator.vibrate?.(120);
    this.respLast = RESPAWN_T;
    this.cb.onRespawn?.(RESPAWN_T);
  }
  segIndexAt(d: number) {
    for (let i = this.base; i < this.base + this.segs.length; i++) {
      const sg = this.seg(i);
      if (d <= sg.d0 + sg.len) return { i, d: Math.max(d, sg.d0 + 0.8) };
    }
    const i = this.base + this.segs.length - 1;
    return { i, d };
  }
  // titik respawn dihitung saat jatuh: di aspal yang masih utuh, di lurusan dengan ruang cukup sebelum tikungan
  computeRespawn() {
    const refD = this.holdD >= 0 ? this.holdD : this.dist;
    let r = this.segIndexAt(Math.max(this.safeDist - 3.5, refD - 7));
    let sg = this.seg(r.i);
    if (sg && sg.jmp === 2) {
      // jatuh di ramp: balik ke jalan masuk kalau masih ada, kalau tidak → mendarat di seberang
      const back = sg.d0 - 3;
      if (back >= refD - 8.5) r = this.segIndexAt(back);
      else { const nx = this.seg(r.i + 1); if (nx) r = { i: r.i + 1, d: nx.d0 + 2 }; }
      sg = this.seg(r.i);
    }
    const st = sg && sg.type === 's' ? sg : this.seg(r.i - 1);
    if (st && st.type === 's' && !st.jmp) {
      const cand = Math.max(st.d0 + 1, refD - 8.5);
      const idx = this.segIndexAt(cand);
      if (st.d0 + st.len - cand >= 5 && this.seg(idx.i) === st) r = idx;
    }
    return r;
  }
  respawn() {
    const r = this.rsp, p = this.rspP;
    this.cur = r.i; this.dist = r.d; this.safeDist = r.d; this.holdD = -1;
    this.pos.set(p.x, p.y, p.z); this.h = p.h;
    this.ensureTrack();
    this.state = 'play'; this.crashT = 0; this.crashVel.set(0, 0, 0); this.settled = false;
    this.car.rotation.set(0, this.h, 0); this.car.visible = true;
    this.vis = { yaw: 0, yawV: 0, roll: 0, sq: 1, sqV: 0, pitch: 0, pitchV: 0 };
    this.airborne = false; this.attached = null; this.ropeT = 0; this.hideRope();
    this.nosMul = 1; this.effV = this.v; this.cornerK = 0; this.gripT = 0.6; this.bumpX = 0; this.bumpZ = 0; this.bumpSlow = 0;
    this.slope = 0; this.freeDir = 0; this.freeSlide = 0; this.driftAcc = 0; this.launchK = 1;
    this.steerA = 0; this.steerV = 0; this.turnRate = 0;
    this.invuln = 2.2; this.fovKick = 0; this.shake = 0; this.camSnap = true;
    this.rspMark.visible = false;
    this.burst(this.pos, [0x7cf0ff, 0xffffff, 0xffd23f], 22);
    this.cb.onRespawn?.(0);
    this.cb.onPopup('GO!', '#7cf0ff');
    this.sfx.respawn();
    navigator.vibrate?.(20);
  }
  advanceTo(i: number) {
    if (i > this.maxCur) { this.score += i - this.maxCur; this.maxCur = i; }
    this.cur = i;
  }
  // tombol keluar: akhiri run & tampilkan hasil
  endRun() {
    if (this.state !== 'play' && this.state !== 'crash') return;
    if (this.raceOn()) { this.finishRace(false); return; }
    this.state = 'done';
    this.attached = null; this.ropeT = 0; this.hideRope();
    this.setBoostFx(false); this.setHint('');
    this.cb.onRespawn?.(0);
    this.cb.onGameOver(this.score, this.falls);
  }
  jumpAhead(): boolean {
    for (let i = this.cur; i < this.cur + 3; i++) {
      const sg = this.seg(i);
      if (!sg || sg.jmp !== 2) continue;
      const gapD = sg.d0 + sg.len - this.dist;
      if (gapD > -2 && gapD < 22) return true;
    }
    return false;
  }
  launch(sp: number) {
    const nosing = this.nosActive();
    const sg = this.seg(this.cur);
    const lip = sg?.launch ?? 0.4;
    this.airborne = true;
    this.airT = 0;
    // lompatan SELALU berhasil: kecepatan vertikal dihitung supaya mobil tiba di atas jalan pendaratan.
    // NOS tidak lagi wajib — NOS memberi bonus skor & lompatan lebih cepat.
    const asp = Math.max(sp, 13.5);
    let vy = Math.min(sp * lip, 8) * (nosing ? 1 : 0.45);
    const nx = this.seg(this.cur + 1);
    if (nx && nx.jmp === 3) {
      const D = Math.hypot(nx.sx - this.pos.x, nx.sz - this.pos.z) + 1.5;
      const t = D / asp;
      vy = Math.max(vy, Math.min(18, (15 * t * t + nx.y0 + 1.0 - this.pos.y) / t), 5);
    }
    this.airSp = asp; this.airNos = nosing; this.airSeg = nx && nx.jmp === 3 ? nx : null;
    this.airVy = vy;
    this.airLaunchY = this.pos.y;
    this.holdD = this.dist; // jalan tidak runtuh selama di udara
    if (nosing) { this.sfx.whoosh(); this.shake = Math.max(this.shake, 0.25); }
  }
  updateAir(dt: number, sp: number) {
    sp = Math.max(sp, this.airSp); // kecepatan mendatar dijaga selama di udara (melepas NOS tidak membuat jatuh)
    this.airT += dt;
    this.airVy -= 30 * dt;
    if (this.airSeg) {
      // bantuan di udara: luruskan arah & geser ke tengah jalan pendaratan (lompat dari tepi ramp tetap mendarat di jalan)
      const a = this.airSeg;
      this.h += wrap(a.h - this.h) * Math.min(1, dt * 6);
      const lat = (this.pos.x - a.sx) * Math.cos(a.h) - (this.pos.z - a.sz) * Math.sin(a.h);
      const kk = Math.min(1, dt * 3.5) * lat;
      this.pos.x -= Math.cos(a.h) * kk; this.pos.z += Math.sin(a.h) * kk;
    }
    this.pos.x += Math.sin(this.h) * sp * dt;
    this.pos.z += Math.cos(this.h) * sp * dt;
    this.pos.y += this.airVy * dt;
    this.dist += sp * dt;
    if (Math.random() < 0.4) {
      this.spawn(new THREE.Vector3(this.pos.x, this.pos.y + 0.3, this.pos.z), 0xffffff,
        new THREE.Vector3(rand(-1, 1), rand(0, 1), rand(-1, 1)), 0.25, 0.4, 1.5);
    }
    if (this.airVy < 0) {
      for (let i = this.cur; i < this.cur + 6; i++) {
        const sg = this.seg(i);
        if (!sg) continue;
        const p = this.proj(sg, this.pos.x, this.pos.z);
        if (p.lat < this.edgeTol() && p.t > -0.02 && p.t < 1.02) {
          const ry = sample(sg, Math.min(1, Math.max(0, p.t))).y;
          if (this.pos.y <= ry + 0.15 && this.pos.y > ry - 1.6) {
            this.airborne = false;
            this.pos.y = ry;
            if (i > this.cur) { this.advanceTo(i); this.ensureTrack(); }
            this.dist = sg.d0 + p.t * sg.len; this.safeDist = this.dist; this.holdD = -1;
            const bonus = 2 + Math.floor(this.airT) + (this.airNos ? 3 : 0);
            this.score += bonus;
            this.cb.onScore(this.score, this.combo);
            this.cb.onPopup(`${this.airNos ? 'NOS ' : ''}AIR +${bonus}!`, '#7cf0ff');
            this.vis.sqV = -5;
            this.shake = Math.max(this.shake, 0.3);
            this.sfx.land();
            this.burst(this.pos, [0xffffff, 0x9aa0b8], 14);
            navigator.vibrate?.([20, 40, 20]);
            return;
          }
          break;
        }
      }
    }
    if (this.pos.y < this.airLaunchY - 12 || this.airT > 3) {
      this.beginCrash(new THREE.Vector3(Math.sin(this.h) * sp * 0.7, Math.min(0, this.airVy), Math.cos(this.h) * sp * 0.7), false);
    }
  }

  resize = () => {
    this.renderer.setSize(innerWidth, innerHeight);
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
  };

  // ---------- cute voxel cars ----------
  buildCars() {
    const car = new THREE.Group();
    car.scale.setScalar(CAR_SCALE);
    this.car = car;
    this.scene.add(car);
  }

  // ---------- road ----------
  buildChunk(seg: Seg, t0: number, t1: number, dEnd: number): Chunk {
    if (this.mode === 'spidey') {
      const midS = sample(seg, (t0 + t1) / 2);
      const g0 = new THREE.Group();
      g0.position.set(midS.x, midS.y, midS.z);
      g0.visible = false;
      this.scene.add(g0);
      const ch0: Chunk = { g: g0, d: dEnd, falling: false, vy: 0, t: 0, spin: new THREE.Vector3(), by: midS.y, spawned: false, spawnT: 0, spawnDelay: 0 };
      this.chunks.push(ch0);
      return ch0;
    }
    const hw = W / 2;
    const sliceLen = (t1 - t0) * seg.len;
    const n = Math.max(2, Math.ceil(sliceLen / 0.25));
    const pts = [] as ReturnType<typeof sample>[];
    for (let i = 0; i <= n; i++) pts.push(sample(seg, t0 + ((t1 - t0) * i) / n));
    const mid = sample(seg, (t0 + t1) / 2);
    const dStart = seg.d0 + t0 * seg.len;
    const pos: number[] = [], nor: number[] = [], col: number[] = [], idx: number[] = [];
    const P = this.pal;

    const quadTop = (A: typeof mid, B: typeof mid, lo: number, hi: number, y: number, c: THREE.Color) => {
      const rxA = Math.cos(A.h), rzA = -Math.sin(A.h), rxB = Math.cos(B.h), rzB = -Math.sin(B.h);
      const b = pos.length / 3;
      pos.push(A.x + rxA * lo - mid.x, A.y + y - mid.y, A.z + rzA * lo - mid.z);
      pos.push(A.x + rxA * hi - mid.x, A.y + y - mid.y, A.z + rzA * hi - mid.z);
      pos.push(B.x + rxB * lo - mid.x, B.y + y - mid.y, B.z + rzB * lo - mid.z);
      pos.push(B.x + rxB * hi - mid.x, B.y + y - mid.y, B.z + rzB * hi - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(0, 1, 0); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 2, b + 1, b + 1, b + 2, b + 3);
    };
    const quadDown = (A: typeof mid, B: typeof mid, lo: number, hi: number, y: number, c: THREE.Color) => {
      const rxA = Math.cos(A.h), rzA = -Math.sin(A.h), rxB = Math.cos(B.h), rzB = -Math.sin(B.h);
      const b = pos.length / 3;
      pos.push(A.x + rxA * lo - mid.x, A.y + y - mid.y, A.z + rzA * lo - mid.z);
      pos.push(A.x + rxA * hi - mid.x, A.y + y - mid.y, A.z + rzA * hi - mid.z);
      pos.push(B.x + rxB * lo - mid.x, B.y + y - mid.y, B.z + rzB * lo - mid.z);
      pos.push(B.x + rxB * hi - mid.x, B.y + y - mid.y, B.z + rzB * hi - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(0, -1, 0); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    };
    const quadSide = (A: typeof mid, B: typeof mid, off: number, yT: number, yB: number, nx: number, nz: number, c: THREE.Color) => {
      const rxA = Math.cos(A.h), rzA = -Math.sin(A.h), rxB = Math.cos(B.h), rzB = -Math.sin(B.h);
      const b = pos.length / 3;
      pos.push(A.x + rxA * off - mid.x, A.y + yT - mid.y, A.z + rzA * off - mid.z);
      pos.push(A.x + rxA * off - mid.x, A.y + yB - mid.y, A.z + rzA * off - mid.z);
      pos.push(B.x + rxB * off - mid.x, B.y + yT - mid.y, B.z + rzB * off - mid.z);
      pos.push(B.x + rxB * off - mid.x, B.y + yB - mid.y, B.z + rzB * off - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(nx, 0, nz); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    };
    const capRect = (sp: typeof mid, lo: number, hi: number, yT: number, yB: number, c: THREE.Color, sign: number) => {
      const fx = Math.sin(sp.h) * sign, fz = Math.cos(sp.h) * sign;
      const rx = Math.cos(sp.h), rz = -Math.sin(sp.h);
      const b = pos.length / 3;
      pos.push(sp.x + rx * lo - mid.x, sp.y + yT - mid.y, sp.z + rz * lo - mid.z);
      pos.push(sp.x + rx * hi - mid.x, sp.y + yT - mid.y, sp.z + rz * hi - mid.z);
      pos.push(sp.x + rx * lo - mid.x, sp.y + yB - mid.y, sp.z + rz * lo - mid.z);
      pos.push(sp.x + rx * hi - mid.x, sp.y + yB - mid.y, sp.z + rz * hi - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(fx, 0, fz); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    };

    const botLo = this.edge === 'hidden' ? -hw : this.edge === 'rail' ? -hw - 0.4 : -hw - 0.55;
    const botHi = -botLo;
    for (let j = 0; j < n; j++) {
      const A = pts[j], B = pts[j + 1];
      const dMid = dStart + (sliceLen * (j + 0.5)) / n;
      // asphalt slab
      quadTop(A, B, -hw, hw, 0, seg.spiral ? SPIRAL_TOP : P.road);
      quadDown(A, B, botLo, botHi, -1.1, P.roadBottom);
      quadSide(A, B, -hw, 0, -1.1, -Math.cos(A.h), Math.sin(A.h), P.roadSide);
      quadSide(A, B, hw, 0, -1.1, Math.cos(A.h), -Math.sin(A.h), P.roadSide);
      if (this.edge === 'flat') {
        // soft red-white stripes, flush with the road (drivable)
        const red = Math.floor(dMid / 1.0) % 2 === 0;
        const cTop = red ? EDGE.flatA : EDGE.flatB;
        const cSide = red ? EDGE.flatSideA : EDGE.flatSideB;
        quadTop(A, B, -hw - 0.55, -hw, 0.03, cTop);
        quadTop(A, B, hw, hw + 0.55, 0.03, cTop);
        quadSide(A, B, -hw - 0.55, 0.03, -1.1, -Math.cos(A.h), Math.sin(A.h), cSide);
        quadSide(A, B, hw + 0.55, 0.03, -1.1, Math.cos(A.h), -Math.sin(A.h), cSide);
      } else if (this.edge === 'rail') {
        // raised guard rails like the reference — soft solid maroon
        quadTop(A, B, -hw - 0.4, -hw, 0.55, EDGE.rail);
        quadTop(A, B, hw, hw + 0.4, 0.55, EDGE.rail);
        quadSide(A, B, -hw, 0.55, 0, Math.cos(A.h), -Math.sin(A.h), EDGE.rail);
        quadSide(A, B, hw, 0.55, 0, -Math.cos(A.h), Math.sin(A.h), EDGE.rail);
        quadSide(A, B, -hw - 0.4, 0.55, -1.1, -Math.cos(A.h), Math.sin(A.h), EDGE.railSide);
        quadSide(A, B, hw + 0.4, 0.55, -1.1, Math.cos(A.h), -Math.sin(A.h), EDGE.railSide);
      }
      if (Math.floor(dMid / 2.4) % 2 === 0) quadTop(A, B, -0.09, 0.09, 0.015, P.line);
      if (seg.spiral) { quadTop(A, B, -hw + 0.1, -hw + 0.3, 0.02, SPIRAL_LINE); quadTop(A, B, hw - 0.3, hw - 0.1, 0.02, SPIRAL_LINE); }
    }
    for (const [sp, sign] of [[pts[0], -1], [pts[n], 1]] as const) {
      capRect(sp, -hw, hw, 0, -1.1, P.roadSide, sign);
      if (this.edge === 'flat') {
        const dCap = sign < 0 ? dStart : dStart + sliceLen;
        const red = Math.floor(dCap / 1.0) % 2 === 0;
        const cSide = red ? EDGE.flatSideA : EDGE.flatSideB;
        capRect(sp, -hw - 0.55, -hw, 0.03, -1.1, cSide, sign);
        capRect(sp, hw, hw + 0.55, 0.03, -1.1, cSide, sign);
      } else if (this.edge === 'rail') {
        capRect(sp, -hw - 0.4, -hw, 0.55, -1.1, EDGE.railSide, sign);
        capRect(sp, hw, hw + 0.4, 0.55, -1.1, EDGE.railSide, sign);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    geo.setIndex(idx);
    const mesh = new THREE.Mesh(geo, this.roadMat);
    mesh.receiveShadow = true;
    const g = new THREE.Group();
    g.position.set(mid.x, mid.y, mid.z);
    g.add(mesh);
    if (seg.type === 's' && this.mode === 'drift' && Math.random() < 0.4) this.addCone(g, seg, (t0 + t1) / 2, mid);
    g.visible = false;
    this.scene.add(g);
    const chunk: Chunk = { g, d: dEnd, falling: false, vy: 0, t: 0, spin: new THREE.Vector3(), geo, by: mid.y, spawned: false, spawnT: 0, spawnDelay: 0 };
    this.chunks.push(chunk);
    return chunk;
  }

  addCone(g: THREE.Group, seg: Seg, tc: number, mid: ReturnType<typeof sample>) {
    const sp = sample(seg, tc);
    const side = (Math.random() < 0.5 ? -1 : 1) * (W / 2 - 0.6);
    const rx = Math.cos(sp.h), rz = -Math.sin(sp.h);
    const cone = new THREE.Group();
    const b1 = new THREE.Mesh(this.boxGeo, this.coneMat); b1.scale.set(0.34, 0.42, 0.34); b1.position.y = 0.21; b1.castShadow = true;
    const b2 = new THREE.Mesh(this.boxGeo, this.coneStripeMat); b2.scale.set(0.36, 0.1, 0.36); b2.position.y = 0.24;
    const b3 = new THREE.Mesh(this.boxGeo, this.coneMat); b3.scale.set(0.2, 0.22, 0.2); b3.position.y = 0.5; b3.castShadow = true;
    cone.add(b1, b2, b3);
    cone.position.set(sp.x + rx * side - mid.x, sp.y - mid.y, sp.z + rz * side - mid.z);
    cone.rotation.y = rand(0, 3);
    g.add(cone);
  }

  addChevron(seg: Seg, firstChunk: Chunk) {
    const p0 = sample(seg, 0);
    const ox = p0.x - seg.cx, oz = p0.z - seg.cz;
    const l = Math.hypot(ox, oz) || 1;
    const wx = p0.x + (ox / l) * (W / 2 + 1.6), wz = p0.z + (oz / l) * (W / 2 + 1.6);
    const g = new THREE.Group();
    const pole = new THREE.Mesh(this.boxGeo, this.signPoleMat); pole.scale.set(0.28, 2.2, 0.28); pole.position.y = 1.1; pole.castShadow = true;
    const board = new THREE.Mesh(this.boxGeo, this.signBoardMat); board.scale.set(1.9, 1.05, 0.18); board.position.y = 2.6; board.castShadow = true;
    g.add(pole, board);
    for (const k of [-0.42, 0.42]) {
      const a1 = new THREE.Mesh(this.boxGeo, this.signArrowMat); a1.scale.set(0.16, 0.62, 0.06);
      a1.position.set(k - 0.16 * seg.s, 2.6, 0.13); a1.rotation.z = 0.6 * seg.s;
      const a2 = new THREE.Mesh(this.boxGeo, this.signArrowMat); a2.scale.set(0.16, 0.62, 0.06);
      a2.position.set(k + 0.16 * seg.s, 2.6, 0.13); a2.rotation.z = -0.6 * seg.s;
      g.add(a1, a2);
    }
    g.position.set(wx - firstChunk.g.position.x, p0.y - firstChunk.g.position.y, wz - firstChunk.g.position.z);
    g.rotation.y = p0.h;
    firstChunk.g.add(g);
  }

  addSeg(seg: Seg) {
    if (this.dry) { this.dryList.push(seg); return; }
    this.pts.push(...this.segPts(seg));
    const nc = Math.max(1, Math.round(seg.len / CHUNK));
    let first: Chunk | null = null;
    const made: Chunk[] = [];
    for (let i = 0; i < nc; i++) {
      const c = this.buildChunk(seg, i / nc, (i + 1) / nc, seg.d0 + (seg.len * (i + 1)) / nc);
      made.push(c);
      if (!first) first = c;
    }
    if (seg.type === 'a' && first && this.mode !== 'spidey') this.addChevron(seg, first);
    const atD = (d: number) => made[Math.min(nc - 1, Math.max(0, Math.floor((d - seg.d0) / seg.len * nc)))];
    const put = (mesh: THREE.Object3D, x: number, y: number, z: number, d: number) => {
      const ch = atD(d);
      mesh.position.set(x - ch.g.position.x, y - ch.g.position.y, z - ch.g.position.z);
      ch.g.add(mesh);
      return ch;
    };
    if (seg.type === 's' && !seg.jmp && Math.floor(seg.d0 / 10) % 3 === 0) {
      const side = Math.floor(seg.d0 / 10) % 2 === 0 ? -1 : 1;
      for (let k = 0; k < 6; k++) {
        const cd = seg.d0 + 1.5 + k * 1.3;
        if (cd > seg.d0 + seg.len - 0.6) break;
        const cp = sample(seg, (cd - seg.d0) / seg.len);
        const m = new THREE.Mesh(this.coinGeo, this.coinMat);
        m.rotation.y = Math.random() * 3;
        const ch = put(m, cp.x + Math.cos(cp.h) * side * (W / 2 - 0.6), cp.y + 0.55, cp.z - Math.sin(cp.h) * side * (W / 2 - 0.6), cd);
        this.coins.push({ m, d: cd, chunk: ch, got: false });
      }
    }
    if (seg.d0 === 0 && this.mode !== 'spidey') {
      const sp0 = sample(seg, 22 / seg.len);
      const gate = this.makeGate('START', '#5cff9d'); gate.rotation.y = sp0.h;
      put(gate, sp0.x, sp0.y, sp0.z, 22);
    }
    if (this.finishOn() && seg.d0 < this.finishD && seg.d0 + seg.len >= this.finishD) {
      const fp = sample(seg, (this.finishD - seg.d0) / seg.len);
      const gate = this.makeGate('FINISH', '#ffd23f'); gate.rotation.y = fp.h;
      put(gate, fp.x, fp.y, fp.z, this.finishD);
    }
    if (seg.type === 'a' && this.mode !== 'free') {
      const ym = (seg.y0 + seg.y1) / 2;
      const g = new THREE.Group();
      g.position.set(seg.cx, ym, seg.cz);
      const pm = new THREE.Mesh(this.boxGeo, this.poleMat);
      if (seg.spiral) { pm.scale.set(0.9, seg.y1 - seg.y0 + 7, 0.9); pm.position.y = -0.5; } else { pm.scale.set(0.5, 30, 0.5); pm.position.y = -13; }
      pm.castShadow = true;
      const top = new THREE.Mesh(this.boxGeo, new THREE.MeshLambertMaterial({ color: 0xffd23f, emissive: 0x000000 }));
      top.scale.setScalar(1.1); top.position.y = seg.spiral ? (seg.y1 - seg.y0) / 2 + 2.4 : 2.4; top.castShadow = true;
      const ring = new THREE.Mesh(this.boxGeo, this.ringMat);
      ring.scale.set(0.85, 0.3, 0.85); ring.position.y = 1.6;
      g.add(pm, top, ring);
      if (seg.spiral) for (let k = 0; k <= Math.round((seg.y1 - seg.y0) / FLOOR_H); k++) {
        const fr = new THREE.Mesh(this.boxGeo, this.ringMat); fr.scale.set(1.4, 0.28, 1.4); fr.position.y = seg.y0 + k * FLOOR_H + 1.6 - ym; g.add(fr);
      }
      g.visible = false;
      this.scene.add(g);
      seg.poleTop = top;
      this.chunks.push({ g, d: seg.d0 + seg.len + 2, falling: false, vy: 0, t: 0, spin: new THREE.Vector3(), by: ym, spawned: false, spawnT: 0, spawnDelay: 0 });
    }
    this.segs.push(seg);
  }

  genStraight(len: number) {
    const g = this.gen;
    const y1 = g.y - len * 0.03;
    this.addSeg({ type: 's', y0: g.y, y1, len, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0 });
    g.x += Math.sin(g.h) * len; g.z += Math.cos(g.h) * len; g.y = y1; g.d += len;
  }

  canJump(n: number) { if (this.mode !== 'drift') return false; return n > 10 && (n - this.lastJumpN) > 10 && Math.random() < 0.26; }
  genJump(n: number) {
    this.lastJumpN = n;
    const g = this.gen;
    const fx = Math.sin(g.h), fz = Math.cos(g.h);
    const appLen = 9;
    const yA = g.y - appLen * 0.03;
    this.addSeg({ type: 's', y0: g.y, y1: yA, len: appLen, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 1 });
    g.x += fx * appLen; g.z += fz * appLen; g.y = yA; g.d += appLen;
    const rampLen = 6, rise = 1.3;
    const lip = (2 * rise / rampLen) / Math.hypot(1, 2 * rise / rampLen);
    this.addSeg({ type: 'r', y0: g.y, y1: g.y + rise, len: rampLen, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 2, launch: lip });
    g.x += fx * rampLen; g.z += fz * rampLen; g.y += rise; g.d += rampLen;
    const gap = 9, landLen = 17;
    const lx = g.x + fx * gap, lz = g.z + fz * gap;
    const ly0 = g.y - 0.6, ly1 = ly0 - landLen * 0.03;
    this.addSeg({ type: 's', y0: ly0, y1: ly1, len: landLen, d0: g.d + gap, sx: lx, sz: lz, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 3 });
    g.x = lx + fx * landLen; g.z = lz + fz * landLen; g.y = ly1; g.d += gap + landLen;
  }

  // titik tengah jalan tiap ±2.5 m (untuk cek jalan saling menabrak)
  segPts(seg: Seg) {
    const out: { x: number; z: number; y: number; d: number }[] = [];
    const n = Math.max(2, Math.ceil(seg.len / 2.5));
    for (let i = 0; i <= n; i++) { const t = i / n, q = sample(seg, t); out.push({ x: q.x, z: q.z, y: q.y, d: seg.d0 + seg.len * t }); }
    return out;
  }
  // jalan baru tidak boleh berimpit (XZ dekat) dengan jalan lama di ketinggian yang hampir sama
  overlaps(list: Seg[]) {
    for (const sg of list) {
      for (const p of this.segPts(sg)) {
        for (const q of this.pts) {
          if (p.d - q.d < 14) continue;
          const dx = p.x - q.x, dz = p.z - q.z;
          if (dx * dx + dz * dz < 5.8 * 5.8 && Math.abs(p.y - q.y) < CLEAR_Y) return true;
        }
      }
    }
    return false;
  }
  overlapCount() {
    let c = 0;
    for (let i = 0; i < this.pts.length; i++) for (let j = 0; j < i; j++) {
      const p = this.pts[i], q = this.pts[j];
      if (p.d - q.d < 14) continue;
      const dx = p.x - q.x, dz = p.z - q.z;
      if (dx * dx + dz * dz < 5.8 * 5.8 && Math.abs(p.y - q.y) < CLEAR_Y) c++;
    }
    return c;
  }
  genChecked(fn: () => void, force = false) {
    const g0 = { ...this.gen }, lj = this.lastJumpN, ls = this.lastSpiralN, la = this.lastArcS;
    this.dry = true; this.dryList = [];
    fn();
    this.dry = false;
    const list = this.dryList;
    if (!force && this.overlaps(list)) { this.gen = g0; this.lastJumpN = lj; this.lastSpiralN = ls; this.lastArcS = la; return false; }
    for (const sg of list) this.addSeg(sg);
    return true;
  }
  wantSpiral(n: number) { return n >= 6 && (this.lastSpiralN < 0 || (n - this.lastSpiralN > 14 && Math.random() < 0.25)); }
  // Lintasan dibangun per "seksi" acak supaya tidak monoton: klasik, S-curve, esses, hairpin, sweeper, lurusan NOS, lompatan, spiral
  planSection() {
    const n = this.base + this.segs.length;
    const diff = Math.min(1, n / 40);
    const P = (st: Step) => this.plan.push(st);
    const A = (sweep: number, R: number, dir?: 'flip' | 'same'): Step => ({ k: 'a', sweep, R, flip: dir === 'flip', same: dir === 'same' });
    const PI = Math.PI;
    if (n === 0) { P({ k: 's', len: 34 }); return; }
    if (this.wantSpiral(n)) { P({ k: 's', len: rand(26, 32) }); P({ k: 'p' }); return; }
    const jumpOK = this.mode === 'drift' && n > 10 && n - this.lastJumpN > 10;
    const items: [string, number][] = [['classic', 18]];
    if (n > 12) items.push(['long', 6]);
    if (n >= 5) items.push(['s', 20]);
    if (n >= 6) items.push(['fast', 8]);
    if (n >= 8) items.push(['hairpin', 10], ['sweeper', 8]);
    if (n >= 9) items.push(['esses', 12]);
    if (n >= 10) items.push(['double', 8]);
    if (n >= 12) items.push(['wiggle', 8]);
    if (jumpOK) items.push(['jump', 8]);
    let r = Math.random() * items.reduce((m, it) => m + it[1], 0), pick = 'classic';
    for (const [name, w] of items) { if ((r -= w) <= 0) { pick = name; break; } }
    const sw = () => { const q = Math.random(); return q < 0.45 ? PI / 2 : q < 0.65 ? PI / 3 : q < 0.8 ? (PI * 2) / 3 : PI; };
    switch (pick) {
      case 'long': P({ k: 's', len: rand(22, 30) }); P(A(sw(), rand(5.8, 8.5) - diff)); break;
      // S-curve: dua tikungan 90° berlawanan arah, langsung bersambung
      case 's': P({ k: 's', len: rand(4, 7) }); P(A(PI / 2, rand(6, 7.6))); P(A(PI / 2, rand(6, 7.6), 'flip')); break;
      // esses: zig-zag 3-4 tikungan beruntun
      case 'esses': {
        P({ k: 's', len: rand(4, 6) }); P(A(PI / 2, rand(6, 7.2)));
        for (let i = 0, c = 2 + (Math.random() < 0.5 ? 1 : 0); i < c; i++) P(A(PI / 2, rand(6, 7.2), 'flip'));
        break;
      }
      // tikungan cepat berradius besar
      case 'fast': P({ k: 's', len: rand(6, 9) }); P(A(Math.random() < 0.5 ? PI / 3 : PI / 2, rand(11, 14))); break;
      // hairpin: belok 90°, U-turn 180° ke arah sebaliknya, lalu belok 90° lagi
      case 'hairpin':
        if (Math.abs(this.gen.h) > 1.2) {
          // arah sudah miring ±90°: langsung U-turn 180° lalu luruskan
          P({ k: 's', len: rand(5, 8) }); P(A(PI, rand(5.2, 6)));
          P({ k: 's', len: rand(3, 5) }); P(A(PI / 2, rand(6.2, 7.2), 'flip'));
        } else {
          P({ k: 's', len: rand(5, 8) }); P(A(PI / 2, rand(6.2, 7.2)));
          P({ k: 's', len: rand(3, 5) }); P(A(PI, rand(5.2, 6), 'flip'));
          P({ k: 's', len: rand(3, 5) }); P(A(PI / 2, rand(6.2, 7.2), 'flip'));
        }
        break;
      case 'sweeper': P({ k: 's', len: rand(6, 10) }); P(A(PI * 1.5, rand(8, 10.5))); break;
      // double apex: dua tikungan searah dengan radius berbeda
      case 'double': P({ k: 's', len: rand(5, 8) }); P(A(PI / 3, rand(6, 7.5))); P(A(PI / 3, rand(9, 11), 'same')); break;
      // slalom landai
      case 'wiggle': {
        P({ k: 's', len: rand(5, 7) }); P(A(PI / 3, rand(8.5, 10.5)));
        for (let i = 0, c = 2 + (Math.random() < 0.5 ? 1 : 0); i < c; i++) P(A(PI / 3, rand(8.5, 10.5), 'flip'));
        break;
      }
      case 'jump': P({ k: 'j' }); break;
      default: P({ k: 's', len: rand(5, 10) - diff * 2 }); P(A(sw(), rand(5.8, 8.5) - diff));
    }
  }
  genStep(st: Step, n: number, attempt: number) {
    if (st.k === 's') this.genStraight(st.len ?? 8);
    else if (st.k === 'j') { if (attempt < 3) this.genJump(n); else this.genStraight(8); }
    else if (st.k === 'p') { if (attempt < 4) this.genSpiral(); else this.genArc(); }
    else this.genArc({ sweep: st.sweep, R: st.R, flip: st.flip, same: st.same, soft: attempt >= 3 });
  }
  // spiral ala Tokyo Drift versi "keong" yang ringkas: 1,25 putaran melebar ke luar sambil naik lantai (±80 m)
  genSpiral() {
    const g = this.gen;
    this.lastSpiralN = this.base + this.segs.length;
    const sweep = TAU * 1.25;
    const R0 = rand(5.8, 6.4);
    const dR = 7.2 / TAU;
    const after = (sd: number) => wrap(g.h - sd * sweep);
    const opts = [1, -1].filter((sd) => Math.abs(after(sd)) <= Math.PI / 2 + 0.05);
    const s = opts.length ? opts[Math.floor(Math.random() * opts.length)] : Math.abs(after(1)) < Math.abs(after(-1)) ? 1 : -1;
    this.lastArcS = s;
    const d0a = Math.atan(dR / R0);
    const hc0 = g.h - s * d0a;                         // tangent awal spiral = arah jalan masuk (tanpa patahan)
    const a0 = Math.PI / 2 - (s * Math.PI) / 2 - hc0;
    const cx = g.x - R0 * Math.cos(a0), cz = g.z - R0 * Math.sin(a0);
    const { cum, len } = buildCum(R0, dR, sweep);
    const y1 = g.y + 1.25 * FLOOR_H;
    this.addSeg({ type: 'a', y0: g.y, y1, len, d0: g.d, sx: 0, sz: 0, h: 0, cx, cz, R: R0, a0, s, sweep, spiral: true, dR, cum });
    const Rend = R0 + dR * sweep;
    g.x = cx + Rend * Math.cos(a0 + s * sweep); g.z = cz + Rend * Math.sin(a0 + s * sweep);
    g.h = wrap(g.h - s * sweep - s * d0a + s * Math.atan(dR / Rend));
    g.y = y1; g.d += len;
  }
  rad(sg: Seg, t = (this.dist - sg.d0) / Math.max(0.001, sg.len)) { return radiusAt(sg, t); }
  proj(sg: Seg, x: number, z: number) {
    return project(sg, x, z, THREE.MathUtils.clamp((this.dist - sg.d0) / Math.max(0.001, sg.len), 0, 1));
  }
  makeGate(label: string, color: string): THREE.Group {
    const g = new THREE.Group();
    let tex = this.gateTex.get(label);
    if (!tex) {
      const cv = document.createElement('canvas'); cv.width = 512; cv.height = 128;
      const c = cv.getContext('2d')!;
      c.fillStyle = '#16122e'; c.fillRect(0, 0, 512, 128);
      for (let i = 0; i < 32; i++) for (let j = 0; j < 2; j++) { c.fillStyle = (i + j) % 2 ? '#101018' : '#ffffff'; c.fillRect(i * 16, j * 8, 16, 8); c.fillRect(i * 16, 112 + j * 8, 16, 8); }
      c.font = '84px "Lilita One", "Arial Black", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.lineWidth = 12; c.lineJoin = 'round'; c.strokeStyle = '#16122e'; c.strokeText(label, 256, 68); c.fillStyle = color; c.fillText(label, 256, 68);
      tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
      this.gateTex.set(label, tex);
    }
    const ban = new THREE.Mesh(this.boxGeo, new THREE.MeshBasicMaterial({ map: tex }));
    ban.scale.set(W + 2.4, 1.5, 0.22); ban.position.y = 5.4;
    g.add(ban);
    for (const sd of [-1, 1]) {
      const post = new THREE.Mesh(this.boxGeo, this.poleMat);
      post.scale.set(0.4, 5.6, 0.4); post.position.set(sd * (W / 2 + 1.0), 2.8, 0); post.castShadow = true;
      g.add(post);
    }
    const stripeGeo = new THREE.PlaneGeometry(W, 1.2); stripeGeo.rotateX(-Math.PI / 2);
    const stripe = new THREE.Mesh(stripeGeo, new THREE.MeshBasicMaterial({ map: this.checkerTex }));
    stripe.position.y = 0.05; g.add(stripe);
    return g;
  }
  genArc(o: { sweep?: number; R?: number; flip?: boolean; same?: boolean; soft?: boolean } = {}) {
    const g = this.gen;
    const diff = Math.min(1, (this.base + this.segs.length) / 40);
    let sweep = o.sweep;
    if (sweep === undefined) { const r = Math.random(); sweep = r < 0.55 - diff * 0.2 ? Math.PI / 2 : r < 0.85 ? Math.PI : Math.PI * 1.5; }
    if (o.soft && sweep > Math.PI / 2) sweep = Math.PI / 2;
    const R = o.R ?? rand(5.8, 8.5) - diff;
    const ok = (s: number) => Math.abs(wrap(g.h - s * sweep!)) <= Math.PI / 2 + 0.01;
    let opts = [1, -1].filter(ok);
    if (!opts.length) { sweep = Math.PI / 2; opts = [1, -1].filter(ok); }
    let s = opts[Math.floor(Math.random() * opts.length)];
    if (o.flip && this.lastArcS !== 0 && opts.includes(-this.lastArcS)) s = -this.lastArcS;
    else if (o.same && this.lastArcS !== 0 && opts.includes(this.lastArcS)) s = this.lastArcS;
    else if (opts.length === 2 && Math.abs(g.x) > 25) {
      s = opts.find((o2) => Math.sign(Math.sin(wrap(g.h - o2 * sweep!))) === -Math.sign(g.x)) ?? s;
    }
    this.lastArcS = s;
    const fx = Math.sin(g.h), fz = Math.cos(g.h);
    const nx = s * -fz, nz = s * fx;
    const cx = g.x + nx * R, cz = g.z + nz * R;
    const a0 = Math.atan2(-nz, -nx);
    const y1 = g.y - sweep * 1.7;
    const len = R * sweep;
    this.addSeg({ type: 'a', y0: g.y, y1, len, d0: g.d, sx: 0, sz: 0, h: 0, cx, cz, R, a0, s, sweep });
    const a1 = a0 + s * sweep;
    g.x = cx + R * Math.cos(a1); g.z = cz + R * Math.sin(a1);
    g.h = wrap(g.h - s * sweep); g.y = y1; g.d += len;
  }

  ensureTrack() {
    const lead = this.state === 'play' || this.state === 'crash' ? this.bots.reduce((m, b) => (b.active ? Math.max(m, b.dist) : m), this.dist) : this.dist;
    while (this.base + this.segs.length < this.cur + 10 || this.gen.d < lead + 150) {
      if (!this.plan.length) this.planSection();
      const step = this.plan.shift()!;
      const n = this.base + this.segs.length;
      let ok = false;
      for (let attempt = 0; attempt < 8 && !ok; attempt++) ok = this.genChecked(() => this.genStep(step, n, attempt));
      if (!ok) this.genChecked(() => this.genStep(step, n, 99), true); // sangat jarang
    }
    while (this.cur - this.base > 4) { const old = this.segs.shift()!; if (old.bld) this.scene.remove(old.bld); this.base++; }
    const keepD = this.segs.length ? this.segs[0].d0 : 0;
    while (this.pts.length && this.pts[0].d < keepD) this.pts.shift();
  }

  seg(i: number) { return this.segs[i - this.base]; }
  removeChunk(c: Chunk) { this.scene.remove(c.g); c.geo?.dispose(); if (this.coins.length) this.coins = this.coins.filter((k) => k.chunk !== c); }

  reset() {
    for (const c of this.chunks) this.removeChunk(c);
    this.chunks = [];
    for (const sg of this.segs) if (sg.bld) this.scene.remove(sg.bld);
    this.segs = []; this.base = 0; this.cur = 0; this.dist = 0;
    this.gen = { x: 0, z: 0, h: 0, y: 0, d: 0 };
    this.state = 'idle'; this.lastSpiralN = -99; this.lastJumpN = -99; this.pts = []; this.dry = false; this.holdD = -1; this.planSpiral = -1; this.plan = []; this.lastArcS = 0;
    this.finishD = this.goal > 0 ? this.goal : 1100;
    this.ensureTrack();
    const ordered = [...this.chunks].sort((a, b) => a.d - b.d);
    ordered.forEach((c, i) => { c.spawnDelay = i * 0.035; c.spawned = false; c.spawnT = 0; });
    this.pos.set(0, 0, 4); this.h = 0; this.v = 13;
    this.attached = null; this.holding = false;
    this.airborne = false; this.airVy = 0; this.airT = 0;
    this.score = 0; this.combo = 0;
    this.car.rotation.set(0, 0, 0);
    this.vis = { yaw: 0, yawV: 0, roll: 0, sq: 1, sqV: 0, pitch: 0, pitchV: 0 };
    this.camPos.set(0, 20, -9);
    this.applyMode();
    this.fovKick = 0; this.slope = 0; this.settled = false; this.overSent = false; this.nosN = 0; this.nosKey = false; this.nosToggleOn = false; this.comboKey = false; this.nosMul = 1; this.effV = 13; this.cornerK = 0; this.gripT = 0; this.setBoostFx(false); this.bumpX = 0; this.bumpZ = 0; this.bumpCD = 0; this.bumpSlow = 0; this.raceAcc = 0; this.coins = []; this.coinStreak = 0;
    this.safeDist = 4; this.maxCur = 0; this.falls = 0; this.invuln = 0; this.crashY0 = 0; this.respLast = 0;
    this.steerA = 0; this.steerV = 0; this.driftAmt = 0; this.turnRate = 0;
    this.car.visible = true;
    this.cb.onRespawn?.(0); this.cb.onGrid?.(0);
    this.gridOn = false; this.launchK = 1; this.camSnap = false; this.rspMark.visible = false;
    this.applyBots();
    this.resetBots();
    this.state = 'idle';
    this.hideRope(); this.ropeT = 0; this.ropeWob = 0;
    this.setHint('');
  }

  start() {
    this.sfx.init();
    if (this.sfx.ctx) this.music.begin(this.sfx.ctx, this.sfx.master, this.sfx.noiseBuf);
    this.reset();
    this.bumpCD = 2.5;
    this.state = 'play';
    this.applyBots();
    // lampu start: mode balap bot menunggu 3-2-1-GO di garis start
    this.gridOn = this.raceOn();
    this.gridEnd = performance.now() + 3000; this.gridLast = 3; this.launchK = this.gridOn ? 0 : 1;
    if (this.gridOn) { for (const b of this.bots) b.v = 0; this.cb.onGrid?.(3); this.sfx.beep(3); } else this.sfx.start();
    this.cb.onScore(0, 0);
  }
  unlockAudio() { this.sfx.init(); if (this.sfx.ctx) this.music.begin(this.sfx.ctx, this.sfx.master, this.sfx.noiseBuf); }
  setHint(h: string) { if (h !== this.lastHint) { this.lastHint = h; this.cb.onHint?.(h); } }

  press() { this.holding = true; this.tryAttach(); }

  tryAttach() {
    if (this.mode === 'free') return;
    if (this.state !== 'play' || this.attached || this.gridOn) return;
    let best: Seg | null = null, bd = Infinity;
    for (let i = this.cur; i < this.cur + 3; i++) {
      const sg = this.seg(i);
      if (!sg || sg.type !== 'a') continue;
      if (sg.d0 + sg.len - this.dist < 1.5) continue;
      const d = Math.hypot(this.pos.x - sg.cx, this.pos.z - sg.cz);
      if (d < bd) { bd = d; best = sg; }
    }
    const nosing = this.nosActive();
    if (!best || bd > this.rad(best) + W * (nosing ? 2.2 : 1)) return;
    const rx = this.pos.x - best.cx, rz = this.pos.z - best.cz;
    const fx = Math.sin(this.h), fz = Math.cos(this.h);
    this.orbit = { r: bd, a: Math.atan2(rz, rx), s: rx * fz - rz * fx >= 0 ? 1 : -1 };
    this.attached = best;
    if (best.spiral) this.cb.onPopup('🌀 SPIRAL!', '#7cf0ff');
    this.attachErr = Math.abs(bd - this.rad(best));
    this.vis.sqV = -3.5;
    this.vis.yawV += -this.orbit.s * 2.2;
    this.vis.pitchV += -1.5; // nose dive — berat depan saat nyangkut
    this.ropeT = 0; this.ropeWob = 1; // tali melesat + bergetar
    this.shake = Math.max(this.shake, 0.2);
    this.sfx.attach();
    navigator.vibrate?.(10);
  }

  release() {
    this.holding = false;
    if (this.mode === 'free' && this.combo > 0 && this.state === 'play') { this.combo = 0; this.cb.onScore(this.score, 0); }
    if (this.state !== 'play' || !this.attached) return;
    const sDir = this.orbit.s;
    this.attached = null; this.gripT = 1;
    this.ropeWob = 1.6; // tali menyentak balik lentur
    const err = this.attachErr;
    if (err < 0.9) {
      this.combo++;
      this.score += this.combo;
      this.cb.onPopup(this.combo > 1 ? `PERFECT x${this.combo}` : 'PERFECT!', '#ffd23f');
      this.burst(this.pos, [0xffd23f, 0xff5c8a, 0x7cf0ff, 0xffffff], 30);
      this.shake = 0.4;
      this.fovKick = Math.min(7, this.fovKick + 2);
      this.sfx.perfect(this.combo);
      navigator.vibrate?.([15, 30, 15]);
    } else if (err < 1.8) {
      this.combo = 0;
      this.cb.onPopup('NICE', '#ffffff');
      this.sfx.nice();
    } else { this.combo = 0; this.sfx.release(); }
    this.vis.sqV = 3;
    this.vis.yawV += sDir * (this.nosActive() ? 3 : 2); // counter-steer flick
    this.vis.pitchV += 2; // squat ke belakang
    this.fovKick = Math.min(7, this.fovKick + 3.5);
    this.cb.onScore(this.score, this.combo);
  }

  spawn(p: THREE.Vector3, color: number, vel: THREE.Vector3, size: number, life: number, grow: number, grav = false) {
    const pt = this.parts[this.partIdx++ % this.parts.length];
    pt.m.visible = true; pt.m.position.copy(p); pt.m.scale.setScalar(size);
    (pt.m.material as THREE.MeshBasicMaterial).color.set(color);
    pt.m.rotation.set(Math.random() * 3, Math.random() * 3, 0);
    pt.v.copy(vel); pt.life = life; pt.max = life; pt.grow = grow; pt.grav = grav;
  }

  burst(p: THREE.Vector3, colors: number[], n: number) {
    for (let i = 0; i < n; i++) {
      this.spawn(p.clone().add(new THREE.Vector3(0, 1, 0)), colors[i % colors.length],
        new THREE.Vector3(rand(-8, 8), rand(5, 13), rand(-8, 8)), rand(0.25, 0.5), rand(0.6, 1.1), -0.3, true);
    }
  }

  skid(x: number, y: number, z: number, yaw: number) {
    const s = this.skids[this.skidIdx++ % this.skids.length];
    s.m.visible = true; s.m.position.set(x, y + 0.03, z); s.m.rotation.y = yaw; s.life = 2.5;
    (s.m.material as THREE.MeshBasicMaterial).opacity = 0.5;
  }

  update(dt: number) {
    const t = performance.now() / 1000;
    let yawTarget = 0;
    if (this.state === 'play') {
      const T = this.tune;
      this.v = Math.min(T.vMax, T.v0 + this.cur * T.ramp);
      this.gripT = Math.max(0, this.gripT - dt / 0.9);
      // pelan sedikit menjelang & di dalam tikungan (seperti mengerem), makin rapat tikungan makin pelan
      let wantK = 0;
      if (T.ease > 0 && !this.airborne) {
        for (let i = this.cur; i < this.cur + 2; i++) {
          const sg = this.seg(i); if (!sg || sg.type !== 'a' || sg.spiral) continue;
          if (i === this.cur && (this.dist - sg.d0) / Math.max(0.001, sg.len) > 0.9) continue;
          const ahead = i === this.cur ? 0 : sg.d0 - this.dist;
          if (ahead < 16) { const tight = THREE.MathUtils.clamp((9.5 - this.rad(sg, 0.5)) / 4, 0, 1); wantK = 0.35 + 0.65 * tight; break; }
        }
      }
      this.cornerK += (wantK - this.cornerK) * Math.min(1, dt * (wantK > this.cornerK ? 2.5 : 1.5));
      if (this.gridOn) {
        const left = (this.gridEnd - performance.now()) / 1000;
        if (left <= 0) { this.gridOn = false; this.cb.onGrid?.(0); this.cb.onPopup('GO!', '#5cff9d'); this.sfx.go(); this.fovKick = 5; }
        else { const gn = Math.ceil(left - 1e-6); if (gn !== this.gridLast) { this.gridLast = gn; this.cb.onGrid?.(gn); this.sfx.beep(gn); } }
      } else if (this.launchK < 1) this.launchK = Math.min(1, this.launchK + dt / 1.1);
      const nosTarget = this.nosActive() ? T.nos : 1;
      this.nosMul += (nosTarget - this.nosMul) * Math.min(1, dt * 2.4);
      if (Math.abs(this.nosMul - nosTarget) < 0.01) this.nosMul = nosTarget;
      const sp = this.gridOn ? 0 : this.v * (1 - T.ease * this.cornerK) * this.nosMul * (1 - 0.25 * this.bumpSlow) * (0.25 + 0.75 * this.launchK);
      this.effV = sp;
      if (this.holding && !this.attached) this.tryAttach();
      const prevH = this.h;
      if (this.attached) {
        const sg = this.attached;
        const o = this.orbit;
        const nosDrift = this.nosActive();
        o.r += ((this.rad(sg, (this.dist + 2.5 - sg.d0) / Math.max(0.001, sg.len)) + (nosDrift ? 2.0 : 0)) - o.r) * Math.min(1, dt * 2.0);
        o.a += (o.s * sp / o.r) * dt;
        this.pos.x = sg.cx + o.r * Math.cos(o.a);
        this.pos.z = sg.cz + o.r * Math.sin(o.a);
        const tangent = Math.PI / 2 - (o.a + o.s * Math.PI / 2) + (sg.dR ? sg.s * Math.atan(sg.dR / o.r) : 0);
        this.h += wrap(tangent - this.h) * Math.min(1, dt * (nosDrift ? 18 : 10));
        yawTarget = -o.s * (nosDrift ? 1.05 : 0.8);
        const top = new THREE.Vector3(sg.cx, sg.spiral ? this.pos.y + 1.6 : (sg.y0 + sg.y1) / 2 + 1.6, sg.cz);
        const a = new THREE.Vector3(this.pos.x, this.pos.y + this.ropeAY(), this.pos.z);
        this.ropeT = Math.min(1, this.ropeT + dt * 7);
        this.ropeB.copy(top);
        const slackT = THREE.MathUtils.clamp((this.rad(sg) - o.r) / Math.max(0.5, this.rad(sg)), 0, 1) * 0.9 + 0.03;
        this.ropeSlack += (slackT - this.ropeSlack) * Math.min(1, dt * 6);
        this.ropeTmpE.set(a.x + (top.x - a.x) * this.ropeT, a.y + (top.y - a.y) * this.ropeT, a.z + (top.z - a.z) * this.ropeT);
        this.renderRope(a, this.ropeTmpE, t);
        if (sg.poleTop) (sg.poleTop.material as THREE.MeshLambertMaterial).emissive.setHex(Math.sin(t * 30) > 0 ? 0x775500 : 0x332200);
      } else if (!this.airborne) {
        this.freeUpdate(dt, sp);
        this.pos.x += Math.sin(this.h) * sp * dt;
        this.pos.z += Math.cos(this.h) * sp * dt;
      }
      if (this.airborne) this.updateAir(dt, sp);

      const tol = this.edgeTol();
      let found = -1, ty = this.pos.y, pr = { t: 0, lat: 0, slat: 0 }, bestDy = Infinity;
      for (let i = this.cur; i < this.cur + 3; i++) {
        const sg = this.seg(i);
        if (!sg) continue;
        const p = this.proj(sg, this.pos.x, this.pos.z);
        if (p.lat < tol) {
          const yy = sample(sg, p.t).y, dy = Math.abs(yy - this.pos.y) + (i - this.cur) * 0.3;
          if (dy < bestDy) { bestDy = dy; found = i; pr = p; ty = yy; }
        }
      }
      if (!this.airborne && !this.attached && found < 0) {
        this.beginCrash(new THREE.Vector3(Math.sin(this.h) * this.v * 0.7, 7, Math.cos(this.h) * this.v * 0.7), true);
      } else if (!this.airborne && found >= 0) {
        const sg = this.seg(found);
        if (found > this.cur) {
          const exited = this.seg(this.cur);
          if (exited && exited.spiral) {
            const bonus = Math.round((exited.sweep / TAU) * 4);
            this.score += bonus;
            this.cb.onPopup(`SPIRAL +${bonus}!`, '#7cf0ff');
            this.burst(this.pos, [0x7cf0ff, 0xffd23f, 0xffffff], 22);
            this.sfx.perfect(3);
          }
          if (this.mode === 'free' && exited && exited.type === 'a' && this.holding) {
            this.combo++;
            this.score += this.combo;
            this.cb.onPopup(this.combo > 1 ? `DRIFT x${this.combo}!` : 'DRIFT!', '#ffd23f');
            this.burst(this.pos, [0xffd23f, 0xffffff, 0x7cf0ff], 16);
            this.sfx.perfect(this.combo);
          }
          this.advanceTo(found);
          this.cb.onScore(this.score, this.combo);
          this.sfx.tick();
          this.ensureTrack();
        }
        this.dist = sg.d0 + pr.t * sg.len; this.safeDist = this.dist;
        const aheadT = Math.min(1, pr.t + 2.5 / Math.max(1, sg.len));
        this.slope = THREE.MathUtils.clamp(Math.atan2(sample(sg, aheadT).y - ty, 2.5) * 0.45, -0.18, 0.18);
        this.pos.y += (ty - this.pos.y) * Math.min(1, dt * 20);
        if (!this.attached) {
          // mode bebas: tanpa ngepot mobil bablas lurus — tidak ada setir otomatis di tikungan!
          const free = this.mode === 'free';
          const assist = this.invuln > 0; // setelah respawn: autopilot singkat supaya mobil tidak lurus sendiri keluar jalan
          const target = (free && sg.type !== 's' && !assist) ? this.h : this.tangentAtDist(this.dist + 4.5);
          this.h += wrap(target - this.h) * Math.min(1, dt * (assist ? 6 : free ? 2.2 : 2.0 + this.tune.grip * this.gripT));
          if (sg.type === 's') {
            const k = Math.min(1, dt * (assist ? 4 : 1.9 + this.tune.grip * 0.5 * this.gripT)) * pr.slat; // penarikan ke tengah jalan di lurusan (lebih kuat = lebih mudah dikoreksi)
            this.pos.x -= Math.cos(sg.h) * k;
            this.pos.z += Math.sin(sg.h) * k;
          } else if (assist && sg.type === 'a') {
            const rr = Math.hypot(this.pos.x - sg.cx, this.pos.z - sg.cz) || 1;
            const k = (Math.min(1, dt * 3) * (rr - this.rad(sg))) / rr;
            this.pos.x -= (this.pos.x - sg.cx) * k; this.pos.z -= (this.pos.z - sg.cz) * k;
          }
        }
        if (sg.jmp === 2 && pr.t > 0.9 && !this.attached) this.launch(sp);
      }

      if (this.state === 'play' && !this.airborne) {
        if (this.attached) this.setHint(this.attached.spiral && (this.dist - this.attached.d0) / this.attached.len < 0.9 ? 'TAHAN!' : 'LEPAS!');
        else if (this.mode === 'free' && this.holding && this.freeLate()) this.setHint('LEPAS!');
        else if (this.jumpAhead()) this.setHint('LOMPAT!');
        else {
          let near = false;
          for (let i = this.cur; i < this.cur + 3; i++) {
            const sg = this.seg(i);
            if (!sg || sg.type !== 'a') continue;
            if (i === this.cur) { const p = this.proj(sg, this.pos.x, this.pos.z); if (p.lat < W / 2 + 2.5) { near = true; break; } }
            else if (sg.d0 - this.dist < 15) { near = true; break; }
          }
          this.setHint(near ? (this.mode === 'free' ? (this.holding ? '' : 'DRIFT!') : (this.mode === 'spidey' ? 'JARING!' : 'TAHAN!')) : '');
        }
      }

      this.pos.x += this.bumpX * dt; this.pos.z += this.bumpZ * dt;
      if (this.finishOn() && this.dist >= this.finishD) this.finishRace(true);
      this.stepBots(dt, t);
      this.bumpCD = Math.max(0, this.bumpCD - dt);
      this.bumpX *= Math.exp(-2.2 * dt); this.bumpZ *= Math.exp(-2.2 * dt);
      if (this.raceOn() && this.bot === 'solid' && this.state === 'play') this.solidCollide(dt, sp);
      if (this.coins.length) {
        this.coinT += dt;
        if (this.coinT > 3) { this.coinT = 0; this.coinStreak = 0; }
        for (const k of this.coins) {
          if (k.got) continue;
          if (Math.abs(k.d - this.dist) > 30) continue;
          k.m.rotation.y += dt * 4;
          if (Math.abs(k.d - this.dist) < 1.4 && k.chunk.spawned && !k.chunk.falling) {
            k.m.getWorldPosition(this.ropeTmp1);
            if (this.pos.distanceToSquared(this.ropeTmp1) < 1.7) {
              k.got = true; k.m.visible = false;
              this.score += 2;
              this.coinStreak++;
              this.coinT = 0;
              this.cb.onScore(this.score, this.combo);
              this.sfx.coin(this.coinStreak);
              this.burst(this.ropeTmp1, [0xffd23f, 0xffffff], 6);
            }
          }
        }
      }
      this.raceAcc += dt;
      if (this.finishOn() && this.state === 'play' && this.raceAcc > 0.25) { this.raceAcc = 0; this.emitRace(); }
      const bx = -Math.sin(this.h), bz = -Math.cos(this.h);
      const vy = this.h + this.vis.yaw;
      if (this.attached || (this.holding && this.freeDir !== 0)) {
        const ncol2 = NOS[this.nos].outer;
        const nosSmoke = this.nosActive();
        for (const side of [-this.wx, this.wx]) {
          const rx = Math.cos(vy) * side, rz = -Math.sin(vy) * side;
          const px = this.pos.x - Math.sin(vy) * this.wz + rx, pz = this.pos.z - Math.cos(vy) * this.wz + rz;
          if (this.mode === 'drift') this.skid(px, this.pos.y, pz, vy);
          if (Math.random() < 0.6)
            this.spawn(new THREE.Vector3(px, this.pos.y + 0.25, pz), (nosSmoke && Math.random() < 0.4 ? ncol2 : (Math.random() < 0.55 ? 0xffffff : (Math.random() < 0.5 ? 0xdde1ec : 0xb9c0d4))),
              new THREE.Vector3(rand(-1, 1) + bx, rand(1, 2.5), rand(-1, 1) + bz), 0.45, 0.7, 2.2);
        }
      } else if (Math.random() < 0.25) {
        this.spawn(new THREE.Vector3(this.pos.x + bx * 0.9, this.pos.y + 0.3, this.pos.z + bz * 0.9), 0xffffff, new THREE.Vector3(0, 1, 0), 0.2, 0.3, 1);
      }
      this.ropeWob *= Math.exp(-4.5 * dt);
      if (!this.attached && this.ropeT > 0 && this.state === 'play') {
        this.ropeT -= dt * 9;
        if (this.ropeT <= 0) { this.ropeT = 0; this.hideRope(); }
        else {
          const ax = this.pos.x, ay = this.pos.y + this.ropeAY(), az = this.pos.z;
          this.ropeTmpA.set(ax, ay, az);
          this.ropeTmpE.set(ax + (this.ropeB.x - ax) * this.ropeT, ay + (this.ropeB.y - ay) * this.ropeT, az + (this.ropeB.z - az) * this.ropeT);
          this.renderRope(this.ropeTmpA, this.ropeTmpE, t);
        }
      }
      const turnRate = wrap(this.h - prevH) / Math.max(dt, 1e-4);
      this.turnRate += (THREE.MathUtils.clamp(turnRate, -5, 5) - this.turnRate) * Math.min(1, dt * 10);
      this.vis.roll += (THREE.MathUtils.clamp(-turnRate * 0.05, -0.16, 0.16) - this.vis.roll) * Math.min(1, dt * 10);
    } else if (this.state === 'crash') {
      this.crashT += dt;
      this.stepBots(dt, t);
      this.raceAcc += dt;
      if (this.finishOn() && this.raceAcc > 0.25) { this.raceAcc = 0; this.emitRace(); }
      this.crashVel.y -= 32 * dt;
      this.pos.addScaledVector(this.crashVel, dt);
      // tabrakan dengan aspal — mobil memantul, tidak boleh nembus jalan
      let underY = -Infinity, onRoad = false;
      for (let i = this.cur; i < this.cur + 4; i++) {
        const sg2 = this.seg(i);
        if (!sg2) continue;
        const pp = this.proj(sg2, this.pos.x, this.pos.z);
        if (pp.lat < this.edgeTol() + 0.4 && pp.t > -0.05 && pp.t < 1.05) {
          underY = sample(sg2, Math.min(1, Math.max(0, pp.t))).y;
          onRoad = true;
          break;
        }
      }
      const clearance = 0.42 * CAR_UP;
      if (onRoad && this.pos.y < underY + clearance && this.crashVel.y < 0) {
        this.pos.y = underY + clearance;
        const impact = Math.abs(this.crashVel.y);
        if (impact > 3) {
          this.crashVel.y = impact * 0.42;
          this.crashVel.x *= 0.55; this.crashVel.z *= 0.55;
          this.car.rotation.x *= 0.6; this.car.rotation.z *= 0.6;
          this.shake = Math.max(this.shake, Math.min(0.5, impact * 0.04));
          this.sfx.thud(impact);
          this.burst(this.pos, [0x9aa0b8, 0xffffff], 8);
          navigator.vibrate?.(30);
        } else {
          this.crashVel.y = 0;
          this.settled = true;
        }
      }
      if (this.settled) {
        this.crashVel.x *= Math.exp(-4 * dt); this.crashVel.z *= Math.exp(-4 * dt);
        this.car.rotation.x *= Math.exp(-3 * dt); this.car.rotation.z *= Math.exp(-3 * dt);
      } else {
        this.car.rotation.x += dt * (6 + this.crashVel.length() * 0.15);
        this.car.rotation.z += dt * 4;
      }
      // hitung mundur 3 → 2 → 1 → respawn di aspal
      // pakai jam dinding: tepat 3 detik walau FPS rendah
      const wall = (performance.now() - this.crashWall) / 1000;
      const sec = Math.ceil(Math.max(0, RESPAWN_T - wall) - 1e-6);
      if (sec > 0 && sec !== this.respLast) { this.respLast = sec; this.cb.onRespawn?.(sec); this.sfx.beep(sec); }
      if (wall >= RESPAWN_T) this.respawn();
    } else {
      yawTarget = Math.sin(t * 2) * 0.2;
    }

    const nowS = performance.now() / 1000;
    // V2: jalan tersusun rapi — plank naik bergelombang dari bawah
    for (const c of this.chunks) {
      if (c.spawned) continue;
      if (this.fx === 'V1' || this.roadBuild === 'instant') { c.spawned = true; c.g.visible = true; continue; }
      if (this.state !== 'idle' && c.d - this.dist > 95) continue;
      if (!c.spawnT) { c.spawnT = nowS + (this.state === 'idle' ? c.spawnDelay : 0); c.spawnDelay = 0; }
      const a = (nowS - c.spawnT) / 0.45;
      if (a <= 0) continue;
      c.g.visible = true;
      if (a >= 1) {
        c.spawned = true;
        c.g.position.y = c.by;
        c.g.scale.setScalar(1);
      } else {
        c.g.position.y = c.by + (backOut(a) - 1) * 7;
        c.g.scale.setScalar(Math.min(1, 0.3 + a * 1.4));
      }
    }

    // runtuh ke belakang
    const collapseAt = (this.holdD >= 0 ? Math.min(this.dist, this.holdD) : this.dist) - 11;
    const dust = SKINS[this.skin].dust;
    for (let i = this.chunks.length - 1; i >= 0; i--) {
      const c = this.chunks[i];
      if (!c.falling) {
        if (this.state !== 'idle' && c.spawned && c.d < collapseAt) {
          c.falling = true;
          c.t = this.fx === 'V2' ? -Math.random() * 0.07 : 0;
          c.vy = this.fx === 'V2' ? 0 : -1;
          if (this.fx === 'V1') c.spin.set(rand(-0.5, 0.5), rand(-0.25, 0.25), rand(-0.5, 0.5));
          else c.spin.set(rand(-1, 1) * 1.4, 0, rand(-1, 1) * 1.4);
          if (this.state === 'play') this.sfx.rumble();
          for (let k = 0; k < 2; k++)
            this.spawn(c.g.position.clone().add(new THREE.Vector3(rand(-2, 2), -0.5, rand(-2, 2))), dust[k % dust.length],
              new THREE.Vector3(rand(-1.5, 1.5), rand(0, 2.5), rand(-1.5, 1.5)), rand(0.3, 0.55), 0.9, -0.2, true);
        }
        continue;
      }
      c.t += dt;
      if (this.fx === 'V2') {
        // V2: jatuh lurus + menyusut, rapi berurutan tanpa putaran
        if (c.t < 0) continue;
        c.vy -= 34 * dt;
        c.g.position.y += c.vy * dt;
        c.g.position.x += c.spin.x * c.t * dt;
        c.g.position.z += c.spin.z * c.t * dt;
        c.g.scale.setScalar(Math.max(0.001, 1 - c.t / 0.95));
        if (c.t > 1.0) { this.removeChunk(c); this.chunks.splice(i, 1); }
        continue;
      }
      if (c.t < 0.14) { c.g.position.x += (Math.random() - 0.5) * 0.1; continue; }
      c.vy -= 30 * dt;
      c.g.position.y += c.vy * dt;
      c.g.rotation.x += c.spin.x * dt; c.g.rotation.y += c.spin.y * dt; c.g.rotation.z += c.spin.z * dt;
      if (c.t > 2.6) { this.removeChunk(c); this.chunks.splice(i, 1); }
    }

    if (this.state === 'play' && !this.attached) yawTarget = this.freeDir * 0.55;
    this.vis.yawV += ((yawTarget - this.vis.yaw) * 45 - this.vis.yawV * 7) * dt;
    this.vis.yaw += this.vis.yawV * dt;
    const pitchTarget = this.state === 'play' ? -this.slope : 0;
    this.vis.pitchV += ((pitchTarget - this.vis.pitch) * 90 - this.vis.pitchV * 11) * dt;
    this.vis.pitch += this.vis.pitchV * dt;
    this.vis.sqV += (1 - this.vis.sq) * 200 * dt;
    this.vis.sqV *= Math.exp(-11 * dt);
    this.vis.sq += this.vis.sqV * dt;
    this.vis.sq = THREE.MathUtils.clamp(this.vis.sq, 0.82, 1.18);
    this.car.position.copy(this.pos);
    if (this.state !== 'crash') {
      this.car.rotation.y = this.h + this.vis.yaw;
      this.carBody.rotation.z = this.vis.roll;
      this.carBody.rotation.x = this.airborne ? THREE.MathUtils.clamp(-this.airVy * 0.05, -0.45, 0.55) : this.vis.pitch;
    }
    this.carBody.scale.set(1 / Math.sqrt(this.vis.sq), this.vis.sq, 1 / Math.sqrt(this.vis.sq));
    this.carBody.position.x = THREE.MathUtils.clamp(this.vis.roll * 0.4, -0.12, 0.12);
    this.carBody.position.y = this.state === 'play' ? Math.abs(Math.sin(t * 20)) * 0.03 : 0;
    // ---- roda ala mobil drift: counter-steer (setir berlawanan), camber negatif, putaran ----
    const driftOn = this.state === 'play' && (!!this.attached || (this.holding && this.freeDir !== 0));
    this.driftAmt += ((driftOn ? 1 : 0) - this.driftAmt) * Math.min(1, dt * 9);
    let steerT = 0;
    if (this.state === 'play') {
      const wob = Math.sin(t * 6.4) * 0.1 + Math.sin(t * 10.7 + 1) * 0.05; // sopir "menyetir bolak-balik"
      const norm = THREE.MathUtils.clamp(this.turnRate * 0.12, -0.45, 0.45);
      const counter = THREE.MathUtils.clamp(-this.vis.yaw * 1.3, -0.85, 0.85) + wob * this.driftAmt;
      steerT = THREE.MathUtils.lerp(norm, counter, this.driftAmt);
    }
    this.steerV += ((steerT - this.steerA) * 260 - this.steerV * 15) * dt;
    this.steerA = THREE.MathUtils.clamp(this.steerA + this.steerV * dt, -0.9, 0.9);
    const spinSp = this.state === 'play' ? 9 + this.effV * 0.45 : this.state === 'crash' ? 6 : 0;
    this.spinF += spinSp * dt; this.spinR += spinSp * (1 + this.driftAmt * 0.9) * dt;
    if (this.mode !== 'spidey' && this.model) {
      this.animWheels(this.model.rigs, this.steerA, this.spinF, this.spinR, this.driftAmt);
      animateParts(this.model.parts, dt, t, { open: this.state === 'play', boost: this.boostFxOn, drift: this.driftAmt > 0.5 });
      if (this.model.asset.siren) tickSirens(SHARED_MATS, t);
    }
    if (this.invuln > 0) this.invuln -= dt;
    if (this.rspMark.visible) { const sc = 1 + 0.12 * Math.sin(((performance.now() - this.crashWall) / 1000) * 9); this.rspMark.scale.set(sc * CAR_UP, 1, sc * CAR_UP); }
    this.car.visible = !(this.state === 'crash' && this.pos.y < this.crashY0 - 40) && (this.invuln <= 0 || Math.floor(this.invuln * 16) % 2 === 0);
    if (this.mode === 'spidey') this.updateSpidey(dt, t);
    // NOS plasma flame — manual: klik kanan / jari kedua / Shift
    const nosing = this.state === 'play' && this.nosActive();
    this.flame.visible = nosing && this.mode === 'drift';
    this.setBoostFx(nosing);
    if (nosing) {
      const fl = (0.9 + Math.sin(t * 55) * 0.1 + Math.random() * 0.07) * (0.45 + 0.55 * Math.min(1, Math.max(0, (this.nosMul - 1) / Math.max(0.2, this.tune.nos - 1))));
      this.flameMeshes[0].scale.set(0.44, 0.44, 0.92 * fl);
      this.flameMeshes[1].scale.set(0.27, 0.27, 0.72 * fl);
      this.flameMeshes[2].scale.set(0.14, 0.14, 0.5 * fl);
      this.flameGlow.opacity = 0.4;
      const fx0 = Math.sin(this.h), fz0 = Math.cos(this.h);
      const rx0 = Math.cos(this.h), rz0 = -Math.sin(this.h);
      const ncol = NOS[this.nos].outer;
      for (const sd of [-0.25, 0.25]) {
        if (Math.random() < 0.6) {
          this.spawn(new THREE.Vector3(this.pos.x - fx0 * 1.0 + rx0 * sd, this.pos.y + 0.35, this.pos.z - fz0 * 1.0 + rz0 * sd),
            Math.random() < 0.25 || this.mode === 'spidey' ? 0xffffff : ncol,
            new THREE.Vector3(-fx0 * 4 + rand(-1, 1), rand(1, 2.5), -fz0 * 4 + rand(-1, 1)), 0.27, 0.32, 1.6);
        }
      }
    } else {
      this.flameGlow.opacity = 0;
    }

    for (const p of this.parts) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.m.visible = false; continue; }
      p.m.position.addScaledVector(p.v, dt);
      if (p.grav) p.v.y -= 25 * dt;
      p.m.scale.multiplyScalar(1 + p.grow * dt);
      p.m.rotation.x += dt * 4;
      (p.m.material as THREE.MeshBasicMaterial).opacity = Math.min(1, (p.life / p.max) * 1.5);
    }
    for (const s of this.skids) {
      if (s.life <= 0) continue;
      s.life -= dt;
      (s.m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, Math.min(0.5, s.life * 0.32));
      if (s.life <= 0) s.m.visible = false;
    }

    // ---- 3 camera modes ----
    const portrait = innerWidth < innerHeight;
    const calm = this.state === 'crash';
    let cx = this.pos.x, cz = this.pos.z, py = this.pos.y, ch = this.h;
    if (calm) {
      // kamera tidak ikut mobil yang berguling; pelan-pelan bergeser ke titik respawn sehingga sudah siap saat mobil muncul
      const wall = (performance.now() - this.crashWall) / 1000;
      const u = THREE.MathUtils.clamp((wall - 0.3) / 1.9, 0, 1), k = u * u * (3 - 2 * u);
      cx = THREE.MathUtils.lerp(this.crashX, this.rspP.x, k); cz = THREE.MathUtils.lerp(this.crashZ, this.rspP.z, k);
      py = THREE.MathUtils.lerp(this.crashY0, this.rspP.y, k); ch = this.crashH + wrap(this.rspP.h - this.crashH) * k;
    }
    const fx = Math.sin(ch), fz = Math.cos(ch);
    let want: THREE.Vector3, look: THREE.Vector3, fovT: number, lerp: number;
    if (this.camMode === 1) {
      want = new THREE.Vector3(cx - fx * 10.5, py + 8.2, cz - fz * 10.5);
      look = new THREE.Vector3(cx + fx * 7, py + 1.4, cz + fz * 7);
      fovT = 62 + (this.attached ? 4 : 0);
      lerp = Math.min(1, dt * 5);
    } else if (this.camMode === 2) {
      want = new THREE.Vector3(cx, py + 34, cz - 9);
      look = new THREE.Vector3(cx, py, cz + 3);
      fovT = 55;
      lerp = Math.min(1, dt * 4);
    } else {
      const lead = this.state === 'play' || calm ? 5 : 2;
      const hgt = portrait ? 25 : 20;
      want = new THREE.Vector3(cx, py + hgt, cz - 13 + lead);
      look = new THREE.Vector3(cx, py - 0.5, cz + 1.5);
      fovT = (portrait ? 60 : 48) + (this.attached ? 5 : 0) + (this.holding && this.freeDir !== 0 ? 4 : 0) + ((this.attached && this.nosActive()) ? 3 : 0) + ((this.state === 'play' ? this.effV : 13) - 13) * 0.3;
      lerp = Math.min(1, dt * 4);
    }
    if (this.camSnap) { this.camPos.copy(want); this.camSnap = false; this.camera.fov = fovT; } // sehabis respawn: langsung siap, tanpa melayang
    else this.camPos.lerp(want, calm ? Math.min(1, dt * 3) : lerp);
    this.camera.position.copy(this.camPos);
    this.shake *= Math.exp(-6 * dt);
    this.camera.position.x += (Math.random() - 0.5) * this.shake;
    this.camera.position.y += (Math.random() - 0.5) * this.shake;
    this.fovKick *= Math.exp(-4 * dt);
    fovT += this.fovKick;
    this.camera.lookAt(look);
    this.camera.fov += (fovT - this.camera.fov) * Math.min(1, dt * 4);
    this.camera.updateProjectionMatrix();
    this.roadU.uCam.value.copy(this.camera.position);
    this.roadU.uCar.value.set(cx, py + 0.6, cz);

    this.light.position.set(cx + 10, py + 25, cz + 5);
    this.light.target.position.set(cx, py, cz);

    if (this.mode === 'spidey') this.street.position.set(this.pos.x, this.pos.y - 45, this.pos.z);
    for (const c of this.clouds) {
      if (c.position.z < this.pos.z - 40) { c.position.z += 180; c.position.x = this.pos.x + rand(-70, 70); }
      if (c.position.y > py - 12) c.position.y = py - rand(15, 40);
      if (c.position.y < py - 60) c.position.y = py - rand(15, 40);
    }
  }

  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.033, (now - this.last) / 1000);
    this.last = now;
    this.update(dt / 2); this.update(dt / 2);
    const play = this.state === 'play';
    this.sfx.update(dt, {
      on: play, crashed: this.state === 'crash', speed: play ? this.effV : 0,
      drift: !!this.attached || (this.holding && this.freeDir !== 0), boost: play && this.boostFxOn,
      air: this.airborne || (this.gridOn && this.gridEnd - performance.now() < 1500), car: this.mode === 'spidey' ? 'none' : voiceOf(this.carName),
    });
    const tl = this.tele;
    tl.kmh = play ? this.effV * 7.2 : 0; tl.rpm = this.sfx.rpmN; tl.gear = this.sfx.gearNo; tl.boost = this.boostFxOn; tl.drift = !!this.attached;
    this.cb.onTelemetry?.(tl);
    this.music.update(dt, this.state !== 'idle', this.state === 'play' ? 1 : 0.55, !!this.attached && this.state === 'play', this.combo);
    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize);
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
