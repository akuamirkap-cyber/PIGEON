import * as THREE from 'three';
import type { Game } from './Game';
import {

  MOVE_EXTRA, UNBLOCKABLE, TRACK,

  panjerLabel,

  PARRY_ACTIVE, meterGainFor,
  AIM_HEAD, AIM_BODY, AIM_DMG, AIM_STUN, AIM_POISE, AIM_STAM, AIM_DRAIN, AIM_KNOCK,
  chassisOf, chassisKnock, chassisLaunch, chassisLift, chassisPoise, chassisBraces,
  blockable,
  STAR_RANGE_ASSIST, STAR_GUARD_REGEN, STAR_SLIP_SLOW_T, STAR_SLIP_SLOW_SCALE,

  DODGE_WIN, DODGE_WIN_DMG,
  gasRegenMul, WHIFF_SLOW,
  REGEN_IDLE, REGEN_BLOCK, REGEN_AI, POISE_REGEN, POISE_DELAY, poiseCost, GRAVITY,
  ringCfg, ropeGive, ropeInwardStep, ropeHardStep, ropeSlingSpeed, ropeEnergyDamp, TIP_LEN,
  PACE, SPRINT_DRAIN,

  FREESTYLE,
  smooth, lerp, wrapAngle, isOD,
  type Fighter, type Move,
  FLEX, BODY_R, ROPE_K, ROPE_C, RING_BASE, ROUND_TIME,
} from './gameData';

export function perfectDodge(g: Game, d: Fighter, m?: Move) {
    if (d.isPlayer && g.phase === 'fight') g.stats.dodges++;
    const deadly = !!m && (isOD(m.id) || UNBLOCKABLE.includes(m.id) || m.power >= 0.6);
    const comeback = d.hp <= d.maxHp * 0.45;
    d.counterT = 2.4;
    d.dodgeWinT = Math.max(d.dodgeWinT, 1.2);
    d.counterCd = 0;
    d.stam = Math.min(100, d.stam + 22);
    const gain = m && isOD(m.id) ? 100 : deadly ? (comeback ? 100 : 45) : comeback ? 36 : 24;
    d.meter = Math.min(100, d.meter + gain);
    g.popup(
      new THREE.Vector3(d.pos.x, 6.1, d.pos.y),
      deadly ? '⚡ HINDARAN MAUT! [R / L COUNTER]' : '⚡ PERFECT SLIP! [COUNTER SIAP / L]',
      'pop-dodge',
    );
    if (d.isPlayer && d.meter >= 100 && !g.meterReadyShown) {
      g.meterReadyShown = true;
      g.sfx.ready();
      g.popup(new THREE.Vector3(d.pos.x, 6.9, d.pos.y), '🔥 OVERDRIVE COMEBACK SIAP! [R]', 'pop-crit');
    }

    g.slowT = 0;

    if (g.starMode && d.isPlayer) {
      g.slowT = STAR_SLIP_SLOW_T;
      g.slowScale = STAR_SLIP_SLOW_SCALE;
    }
    g.flashAmt = Math.max(g.flashAmt, 0.22);
    g.fovKick = 3.0;
    g.fx.ring(d.pos.x, d.pos.y, 0x5affc8, deadly ? 7.5 : 6, 0.5, 0.1);
    g.fx.spark(new THREE.Vector3(d.pos.x, 3 * d.scale, d.pos.y), deadly ? 36 : 24, 6.5, 0x5affc8, undefined, 1.2, 0.5, 3);
    g.sfx.dodge();
    g.sfx.cheer(deadly ? 0.75 : 0.5);
  }

export function parryCounter(g: Game, d: Fighter, a: Fighter, m: Move) {
    const od = isOD(m.id) || UNBLOCKABLE.includes(m.id);
    const comeback = d.hp <= d.maxHp * 0.45;
    const toA = new THREE.Vector2().subVectors(a.pos, d.pos).normalize();
    const hitPos = new THREE.Vector3(d.pos.x + toA.x * 1.1 * d.scale, 4.4 * d.scale, d.pos.y + toA.y * 1.1 * d.scale);

    d.counterT = 2.2;
    d.dodgeWinT = Math.max(d.dodgeWinT, 1.0);
    d.counterCd = 0;
    d.parryFor = -1;
    const gain = isOD(m.id) ? 100 : od ? (comeback ? 100 : 45) : comeback ? 38 : 26;
    d.meter = Math.min(100, d.meter + gain);
    d.stam = Math.min(100, d.stam + 22);
    if (comeback && d.isPlayer) {
      d.hp = Math.min(d.maxHp, d.hp + d.maxHp * 0.06);
    }
    d.queued = null;
    if (!d.impacted) {
      d.moveT = Math.max(d.moveT, PARRY_ACTIVE - 0.02);
    }
    d.invuln = Math.max(d.invuln, 0.45);
    d.handT = 0.7;

    d.attackDir.copy(toA);
    d.yaw = Math.atan2(toA.x, toA.y);
    d.vel.set(0, 0);
    const dist = d.pos.distanceTo(a.pos);
    const ideal = 3.25 * (d.scale + a.scale) * 0.5;
    if (dist > ideal) {
      d.dash.set(toA.x * Math.min(3.2, dist - ideal) * 6.2, toA.y * Math.min(3.2, dist - ideal) * 6.2);
    }

    a.move = null;
    a.queued = null;
    a.tellT = 0;
    a.tellTotal = 0;
    a.impacted = false;
    a.state = 'stagger';
    a.stunT = od ? 0.72 : 0.82;
    a.hit = 1;
    a.hitSign = Math.random() < 0.5 ? 1 : -1;
    a.vel.set(0, 0);
    a.dash.set(0, 0);
    a.kb.set(-toA.x * 0.6, -toA.y * 0.6);
    if (!a.isPlayer) {
      g.ai.blockT = 0;
      g.ai.reactT = -1;
      g.ai.punishT = 0;
      g.ai.queued = null;
      g.ai.defStreak = 0;
    }

    g.popup(
      new THREE.Vector3(d.pos.x, 6.2, d.pos.y),
      comeback ? '🔥 COMEBACK PARRY!' : od ? '⚡ DEADLY PARRY!' : 'COUNTER PARRY!',
      'pop-crit',
    );
    if (d.isPlayer && d.meter >= 100 && !g.meterReadyShown) {
      g.meterReadyShown = true;
      g.sfx.ready();
      g.popup(new THREE.Vector3(d.pos.x, 6.95, d.pos.y), '🔥 OVERDRIVE COMEBACK SIAP! [R]', 'pop-crit');
    }

    g.slowT = 0;
    g.flashAmt = Math.max(g.flashAmt, 0.26);
    g.freeze = 0.085;
    g.frozenFighter = a;
    g.trauma = Math.min(0.6, g.trauma + 0.26);
    g.camPush += 0.24;
    g.camBump = Math.max(g.camBump, 0.14);
    g.fovKick = 3.8;
    g.fx.ring(hitPos.x, hitPos.z, 0xffe6a8, 6.5, 0.45, 0.1);
    g.fx.ring(hitPos.x, hitPos.z, 0xffffff, 3.6, 0.3, 0.07);
    g.fx.spark(hitPos, 36, 9.5, 0xffd27a, new THREE.Vector3(toA.x, 0.3, toA.y), 1.1, 0.55, 9);
    g.fx.flash(hitPos, 1.8, 0xfff0c0, 0.14);
    g.sfx.block(0.75);
    g.sfx.crackle(0.75);
    g.sfx.cheer(0.7);
    g.hype = Math.max(g.hype, 0.8);
  }

export function tickTaunt(g: Game, f: Fighter, dt: number) {
    if (f.tauntT <= 0) return;
    if (f.state !== 'idle' || f.dodgeT > 0) {
      f.tauntT = 0;
      return;
    }
    const was = f.tauntT;
    const fs = FREESTYLE[THREE.MathUtils.clamp(f.tauntStyle, 0, FREESTYLE.length - 1)];
    f.tauntT -= dt;

    if (g.phase === 'fight') f.meter = Math.min(100, f.meter + fs.meter * dt);

    for (const c of fs.cues) if (was > (1 - c.p) * fs.dur && f.tauntT <= (1 - c.p) * fs.dur) g.fsCue(f, c.s);
    if (f.tauntT <= 0) f.softT = Math.max(f.softT, 0.35);
  }

export function updateFighter(g: Game, f: Fighter, o: Fighter, dt: number) {
    f.hit = Math.max(0, f.hit - dt * 2.4);
    f.recoilT = Math.max(0, f.recoilT - dt);

    if (f.emberT > 0) {

      f.emberT -= dt;
      const sy = Math.sin(f.yaw);
      const cy = Math.cos(f.yaw);
      f.emberP.set(f.pos.x + cy * f.emberLocal.x + sy * f.emberLocal.z, f.y + f.emberLocal.y, f.pos.y - sy * f.emberLocal.x + cy * f.emberLocal.z);
      if (Math.random() < Math.min(1, dt * 46)) g.fx.spark(f.emberP, 1 + Math.floor(Math.random() * 2), 1.6 + Math.random() * 2.2, Math.random() < 0.6 ? 0xffb050 : 0xffe0a0, new THREE.Vector3(0, -0.6, 0), 0.7, 0.45, 22);
    }

    const skid = f.kb.length();
    if (skid > 3.2 && f.state !== 'air' && f.state !== 'ko' && f.y < 0.05) {
      f.skidAcc += dt * (skid - 2.4) * 3.2;
      while (f.skidAcc > 1) {
        f.skidAcc -= 1;
        const side = Math.random() < 0.5 ? -1 : 1;
        const sx = f.pos.x + Math.cos(f.yaw) * side * 0.55 * f.scale - f.kb.x * 0.05;
        const sz = f.pos.y - Math.sin(f.yaw) * side * 0.55 * f.scale - f.kb.y * 0.05;
        g.fx.spark(new THREE.Vector3(sx, 0.12, sz), 2, 1.6 + skid * 0.12, 0x8d93a0, new THREE.Vector3(-f.kb.x, 1.6, -f.kb.y), 1.3, 0.55, 2);
      }
    } else {
      f.skidAcc = 0;
    }
    f.hitUp = f.hitUp > 0 ? Math.max(0, f.hitUp - dt * 2.6) : Math.min(0, f.hitUp + dt * 2.6);
    f.flash = Math.max(0, f.flash - dt * 7);
    f.dash.multiplyScalar(Math.exp(-7.5 * dt));
    f.dodgeCd -= dt;
    f.whiffT = Math.max(0, f.whiffT - dt);
    f.counterT -= dt;
    f.handT = Math.max(0, f.handT - dt);
    f.aimT = Math.max(0, f.aimT - dt);
    f.rageFlash = Math.max(0, f.rageFlash - dt);
    f.counterCd = Math.max(0, f.counterCd - dt);
    f.dodgeWinT = Math.max(0, f.dodgeWinT - dt);
    f.queuedT -= dt;
    f.wallT -= dt;
    f.wallCd -= dt;

    if (f.slingT > 0) {
      f.slingT -= dt;
      if (f.slingT <= 0 && f.state !== 'ko' && f.state !== 'down' && f.state !== 'air') {
        f.kb.x += f.slingX * f.slingV;
        f.kb.y += f.slingZ * f.slingV;

        const inW = f.kb.x * f.slingX + f.kb.y * f.slingZ;
        const k = ropeEnergyDamp(inW, f.slingIn);
        if (k < 1) {
          f.kb.x *= k;
          f.kb.y *= k;
        }
        f.hit = Math.max(f.hit, 0.45);
        f.hitF = 1;
        f.hitL = 0;
        f.hitSpin = 0;
        f.hitPt = 0.6;
        f.hitUp = 0;
        if (f.state === 'stagger') f.stunT = Math.max(f.stunT, 0.3);
        const px = f.pos.x + f.ropeNx * 1.4;
        const pz = f.pos.y + f.ropeNz * 1.4;
        g.arena.ropeHit(f.ropeNx ? f.ropeNx * 20 : f.pos.x, f.ropeNz ? f.ropeNz * 20 : f.pos.y, 0.5);
        g.fx.ring(px, pz, 0xffe0a0, 2.6 + f.slingV * 0.2, 0.3, 4.6 * f.scale);
        g.fx.spark(new THREE.Vector3(px, 4.9 * f.scale, pz), 10, 5, 0xffe0a0, new THREE.Vector3(f.slingX, 0.3, f.slingZ), 1.2, 0.45, 10);
        g.sfx.ropeCreak(1);
        g.popup(new THREE.Vector3(f.pos.x, 6.6 * f.scale, f.pos.y), 'TERPENTAL DARI TALI!', 'pop-info');
      }
    }

    {
      const tgtW = THREE.MathUtils.clamp(f.ropeDepth / (FLEX * 0.75), 0, 1);
      f.ropeW += (tgtW - f.ropeW) * (1 - Math.exp(-(tgtW > f.ropeW ? 22 : 5) * dt));
      if (f.ropeDepth > 0) {
        const facing = Math.sin(f.yaw) * f.ropeNx + Math.cos(f.yaw) * f.ropeNz;
        f.ropeBack += (-facing - f.ropeBack) * (1 - Math.exp(-8 * dt));
      }
    }
    f.wakeT -= dt;
    f.softT = Math.max(0, f.softT - dt);
    f.slipCd -= dt;

    f.poiseT -= dt;
    if (f.poiseT <= 0) f.poise = Math.min(f.poiseMax, f.poise + POISE_REGEN * dt);

    g.tickTaunt(f, dt);

    if (f.isPlayer && f.state !== 'attack') {
      if (f.ippo) f.rollCharge = Math.min(1, f.rollCharge + dt * (0.5 + (f.speed > 1 ? 0.2 : 0)));
      else f.rollCharge = Math.max(0, f.rollCharge - dt * 0.45);
    }
    f.glowBoost = Math.max(f.mode === 'victory' ? 1.5 : f.rage ? 1.9 + Math.sin(f.animT * 14) * 0.5 : 0, f.glowBoost - dt * 1.5);
    if (f.rage && dt > 0 && Math.random() < dt * 18) {
      g.fx.spark(
        new THREE.Vector3(f.pos.x + (Math.random() - 0.5) * 1.4, (2.6 + Math.random() * 2.2) * f.scale, f.pos.y + (Math.random() - 0.5) * 1.4),
        2,
        4.5,
        Math.random() < 0.5 ? 0xff4a2a : 0xffb830,
        new THREE.Vector3(0, 0.65, 0),
        0.9,
        0.32,
        2,
      );
    }
    if (f.state === 'idle') {
      f.comboTaken = 0;
      f.juggle = 0;
    }

    const gasReg = gasRegenMul(f.stam);
    if (f.sprinting) f.stam = Math.max(0, f.stam - SPRINT_DRAIN * dt);
    else if (f.state === 'idle' && !f.blocking) f.stam = Math.min(100, f.stam + (f.isPlayer ? REGEN_IDLE : REGEN_AI) * gasReg * dt);
    else if (f.blocking) {

      const rate = f.isPlayer ? (f.autoGuard ? STAR_GUARD_REGEN : REGEN_BLOCK) : REGEN_BLOCK * 0.7;
      f.stam = Math.min(100, f.stam + rate * gasReg * dt);
    }

    const fighting = g.phase === 'fight';
    if (f.state === 'attack' && f.move) {
      const m = f.move;
      if (f.tellT > 0) {

        f.tellT -= dt;
        const wind = m.strikeAt * 0.85;
        f.moveT = wind * (1 - Math.max(0, f.tellT) / Math.max(0.001, f.tellTotal));
        f.glowBoost = Math.max(f.glowBoost, 1.8);
        f.flash = Math.max(f.flash, 0.16 + 0.16 * Math.sin(f.animT * 32));
      } else {

        const tail = f.whiffT > 0 ? WHIFF_SLOW : 1;
        f.moveT += (dt * f.atkSpd * tail) / (f.tscale * PACE);
      }
      if (!f.whooshed && f.moveT >= m.strikeAt) {
        f.whooshed = true;
        g.beginStrike(f, o, m);
      }
      if (!f.impacted && f.moveT >= m.impact) {
        f.impacted = true;
        g.resolveHit(f, o);
      }
      if (f.state === 'attack' && f.move) {
        if (f.moveT >= m.dur) {
          f.state = 'idle';
          f.move = null;
          f.runStrike = false;
          f.ippoStrike = false;
        } else if (f.queued && f.queuedT > 0 && g.canCancel(f) && f.stam > 0 && f.isPlayer && fighting) {
          g.startMove(f, f.queued);
        }
      }
    } else if (f.state === 'idle' && f.queued && f.queuedT > 0 && f.isPlayer && fighting && f.dodgeT <= 0.1) {
      g.startMove(f, f.queued);
    } else if (f.state === 'stagger') {
      f.stunT -= dt;
      if (f.isPlayer && f.queued && f.queuedT > 0 && f.stunT <= 0.38 && fighting) {
        f.state = 'idle';
        f.stunT = 0;
        f.counterT = Math.max(f.counterT, 1.8);
        g.popup(new THREE.Vector3(f.pos.x, 6.8, f.pos.y), '⚡ BALAS PUKULAN!', 'pop-crit');
        g.startMove(f, f.queued);
      } else if (f.stunT <= 0) {
        f.state = 'idle';
        f.softT = 0.7;
      }
    } else if (f.state === 'down') {
      f.downT -= dt;

      const du = 1 - THREE.MathUtils.clamp(f.downT / Math.max(0.001, f.downDur), 0, 1);
      const RISE_AT = 0.28;
      f.riseU = THREE.MathUtils.clamp((du - RISE_AT) / (1 - RISE_AT), 0, 1);
      f.fallT = 1;
      if (f.riseU > 0.18 && !f.riseServoPlayed) {
        f.riseServoPlayed = true;
        g.sfx.servo();
      }
      if (f.downT <= 0) {
        f.state = 'idle';
        f.fallT = 0;
        f.fallS.set(0);
        f.fallS.v = 0;
        f.riseU = 1;
        f.riseOut = 1;
        f.wakeT = 0.3;
        f.softT = 1.0;
        f.riseServoPlayed = false;
      }
    }
    f.riseOut = Math.max(0, f.riseOut - dt / 0.55);
    const airborne = f.state === 'air' || (f.state === 'ko' && (f.y > 0.001 || f.vy !== 0));
    if (f.state === 'ko' && !airborne) f.fallT = 1;
    if (airborne) g.updateAir(f, dt);

    f.dodgeTail = f.dodgeT > 0 ? 0.24 : Math.max(0, f.dodgeTail - dt);
    if (f.dodgeT > 0) {
      f.dodgeT -= dt;
      const u = 1 - Math.max(0, f.dodgeT) / f.dodgeDur;
      f.invuln = Math.max(f.invuln - dt, f.dodgeInv && u > 0.03 && u < 0.92 ? 0.12 : 0);

      const toO = g.toward(f, o);
      const rightO = new THREE.Vector2(-toO.y, toO.x);
      const latComp = f.dodgeDir.dot(rightO);
      if (Math.abs(latComp) > 0.35) {
        const fwdComp = f.dodgeDir.dot(toO);

        const arcFwd = fwdComp + (1 - u) * 0.14;
        f.dodgeDir.set(toO.x * arcFwd + rightO.x * latComp, toO.y * arcFwd + rightO.y * latComp).normalize();
      }
      if (f.isPlayer && f.wish.lengthSq() > 0.1) {
        const wishDir = f.wish.clone().normalize();
        if (wishDir.dot(f.dodgeDir) > -0.35) {
          f.dodgeDir.lerp(wishDir, Math.min(1, dt * 4.5)).normalize();
        }
      }

      const pushOff = u < 0.18 ? 0.45 + 0.55 * smooth(u / 0.18) : 1;
      const decel = u < 0.38 ? 1 : Math.pow(Math.cos(((u - 0.38) / 0.62) * Math.PI * 0.5), 1.3);
      f.vel.copy(f.dodgeDir).multiplyScalar(f.dodgeSpeed * pushOff * decel);

      if (u > 0.52 && f.state === 'idle' && f.wish.lengthSq() > 0.05) {
        const handoff = smooth(THREE.MathUtils.clamp((u - 0.52) / 0.48, 0, 1));
        f.vel.lerp(f.wish, handoff * 0.88);
      }

      if (f.dodgeT <= 0 && f.state === 'idle') f.dodgeWinT = DODGE_WIN;
    } else {
      f.invuln = Math.max(0, f.invuln - dt);
      if (f.state === 'stagger' || f.state === 'ko' || f.state === 'air' || f.state === 'down') f.wish.set(0, 0);

      const moving = f.wish.lengthSq() > 0.01;
      const dx = f.wish.x - f.vel.x;
      const dy = f.wish.y - f.vel.y;
      const dl = Math.hypot(dx, dy);

      const fwGrip = f.isPlayer ? 0.88 + 0.16 * g.fwMul : 1;
      let acc = moving ? (f.sprinting ? 38 : 34) : f.speed > 7 ? 42 : 48;
      if (f.state === 'attack') acc = f.runStrike ? 7 : 14;
      if (f.isPlayer && f.state !== 'attack') acc *= fwGrip;
      if (moving && f.vel.x * f.wish.x + f.vel.y * f.wish.y < 0) acc *= 1.35;
      if (f.robot.isZeus) {

        acc *= 0.714;
      }
      const maxStep = acc * dt;
      if (dl <= maxStep) f.vel.copy(f.wish);
      else f.vel.addScaledVector(new THREE.Vector2(dx / dl, dy / dl), maxStep);
    }
    f.kb.multiplyScalar(Math.exp(-(airborne ? 1.7 : f.state === 'down' ? 7 : f.state === 'stagger' ? 3.5 : 4.4) * dt));
    let nx = f.pos.x + (f.vel.x + f.kb.x + f.dash.x) * dt;
    let nz = f.pos.y + (f.vel.y + f.kb.y + f.dash.y) * dt;

    if (g.phase !== 'walk' && o.state !== 'air' && f.state !== 'air') {
      const minBodyHull = (f.scale + o.scale) * 1.55;
      const cdx = nx - o.pos.x;
      const cdz = nz - o.pos.y;
      const curDist = Math.hypot(cdx, cdz);
      if (curDist < minBodyHull && curDist > 0.001) {
        const toF_x = cdx / curDist;
        const toF_z = cdz / curDist;
        const pen = minBodyHull - curDist;
        nx += toF_x * pen * 0.7;
        nz += toF_z * pen * 0.7;

        const vDot = (f.vel.x + f.dash.x) * -toF_x + (f.vel.y + f.dash.y) * -toF_z;
        if (vDot > 0) {
          f.vel.x += toF_x * vDot * 0.65;
          f.vel.y += toF_z * vDot * 0.65;
          f.dash.x += toF_x * vDot * 0.65;
          f.dash.y += toF_z * vDot * 0.65;
        }
      }
    }

    const touch = ringCfg.in - BODY_R * f.scale;
    f.ropeDepth = 0;

    if (g.phase !== 'walk' && (f.state === 'air' || f.state === 'down' || f.state === 'ko')) {
      const sy = Math.sin(f.yaw);
      const cy = Math.cos(f.yaw);
      const lieK = THREE.MathUtils.clamp(f.fallS.x, 0, 1);
      const lean = Math.sin(Math.min(1.3, f.tilt));
      const back = (lieK * 3.5 + lean * 3.3 * (1 - lieK) + 0.5) * f.scale;
      const front = (lieK * 3.9 + 1.0) * f.scale;
      const sideK = Math.sin(Math.min(1.2, Math.abs(f.tiltZ))) * 3.2 * f.scale + 1.0 * f.scale;
      const sgnZ = f.tiltZ >= 0 ? 1 : -1;
      const ends: [number, number][] = [
        [-sy * back, -cy * back],
        [sy * front, cy * front],
        [cy * sideK * sgnZ, -sy * sideK * sgnZ],
      ];

      const cap = ropeInwardStep(dt);
      let shX = 0;
      let shZ = 0;
      for (const [ox, oz] of ends) {
        const px = nx + ox;
        const pz = nz + oz;
        const lx = touch + ropeGive(pz);
        const lz = touch + ropeGive(px);
        if (Math.abs(px) > lx) {
          const o = Math.abs(px) - lx;
          if (o > Math.abs(shX)) shX = (px > 0 ? -1 : 1) * o;
        }
        if (Math.abs(pz) > lz) {
          const o = Math.abs(pz) - lz;
          if (o > Math.abs(shZ)) shZ = (pz > 0 ? -1 : 1) * o;
        }
      }

      if (shX !== 0) {
        nx += THREE.MathUtils.clamp(shX, -cap, cap);
        if (f.kb.x * shX < 0) f.kb.x *= 0.2;
        if (f.vel.x * shX < 0) f.vel.x = 0;
        g.arena.ropePress(shX < 0 ? 20 : -20, nz, Math.min(0.6, Math.abs(shX)));
      }
      if (shZ !== 0) {
        nz += THREE.MathUtils.clamp(shZ, -cap, cap);
        if (f.kb.y * shZ < 0) f.kb.y *= 0.2;
        if (f.vel.y * shZ < 0) f.vel.y = 0;
        g.arena.ropePress(nx, shZ < 0 ? 20 : -20, Math.min(0.6, Math.abs(shZ)));
      }
    }
    for (let ax = 0; ax < 2; ax++) {
      const pc = ax === 0 ? nx : nz;
      const sgn = pc >= 0 ? 1 : -1;
      const depth = Math.abs(pc) - touch;
      if (depth <= 0) {
        if (depth < -0.12) f.ropeIn[ax] = false;
        continue;
      }
      const fresh = !f.ropeIn[ax];
      f.ropeIn[ax] = true;
      if (depth > f.ropeDepth) {
        f.ropeDepth = depth;
        f.ropeNx = ax === 0 ? sgn : 0;
        f.ropeNz = ax === 1 ? sgn : 0;
      }
      const vTot = (ax === 0 ? f.vel.x + f.kb.x + f.dash.x : f.vel.y + f.kb.y + f.dash.y) * sgn;

      const give = ropeGive(ax === 0 ? nz : nx);
      const stiff = ROPE_K * (1 + 1.6 * (depth / give) * (depth / give));
      const damp = ROPE_C * lerp(1, 0.45, THREE.MathUtils.clamp((vTot - 4) / 9, 0, 1));

      const catchK = airborne ? 0.3 : 1;
      const accel = (stiff * depth + damp * Math.max(0, vTot)) * catchK;
      if (ax === 0) f.kb.x -= sgn * accel * dt;
      else f.kb.y -= sgn * accel * dt;
      if (airborne && vTot > 0) {
        const bleed = 1 - Math.exp(-7 * dt);
        if (ax === 0) f.kb.x -= f.kb.x * bleed;
        else f.kb.y -= f.kb.y * bleed;
      }

      const vv = (ax === 0 ? f.vel.x : f.vel.y) * sgn;
      if (vv > 0) {
        const cut = Math.min(vv, vv * Math.min(1, depth * 3 + 0.2) * 10 * dt);
        if (ax === 0) f.vel.x -= sgn * cut;
        else f.vel.y -= sgn * cut;
      }

      g.arena.ropePress(ax === 0 ? sgn * 20 : f.pos.x, ax === 1 ? sgn * 20 : f.pos.y, depth + f.hitV * 0.3);
      if (fresh && vTot > 2.5 && f.wallCd <= 0) g.ropeImpact(f, ax === 0 ? sgn : 0, ax === 1 ? sgn : 0, vTot);
    }

    const hardX = touch + ropeGive(nz);
    const hardZ = touch + ropeGive(nx);
    const stopCap = ropeHardStep(dt);
    const cx = Math.abs(nx) <= hardX ? nx : Math.sign(nx) * Math.max(hardX, Math.abs(nx) - stopCap);
    const cz = Math.abs(nz) <= hardZ ? nz : Math.sign(nz) * Math.max(hardZ, Math.abs(nz) - stopCap);
    if (cx !== nx) {
      if (f.kb.x * nx > 0) f.kb.x *= 0.2;
      if (f.vel.x * nx > 0) f.vel.x = 0;
      if (f.dash.x * nx > 0) f.dash.x = 0;
    }
    if (cz !== nz) {
      if (f.kb.y * nz > 0) f.kb.y *= 0.2;
      if (f.vel.y * nz > 0) f.vel.y = 0;
      if (f.dash.y * nz > 0) f.dash.y = 0;
    }
    f.pos.x = cx;
    f.pos.y = cz;

    const H_CORNER = 13.6 * (ringCfg.bound / RING_BASE);
    const cornerOffsets: [number, number][] = [
      [H_CORNER, H_CORNER],
      [-H_CORNER, H_CORNER],
      [H_CORNER, -H_CORNER],
      [-H_CORNER, -H_CORNER],
    ];
    for (let cIdx = 0; cIdx < 4; cIdx++) {
      const [cx0, cz0] = cornerOffsets[cIdx];
      const dx = f.pos.x - cx0;
      const dz = f.pos.y - cz0;
      const dist = Math.hypot(dx, dz);
      const PAD_RADIUS = 2.4 * f.scale;
      if (dist < PAD_RADIUS && dist > 0.001) {
        const pen = PAD_RADIUS - dist;
        const nx0 = dx / dist;
        const nz0 = dz / dist;
        f.pos.x += nx0 * pen;
        f.pos.y += nz0 * pen;

        const vTowardsCorner = -(f.vel.x * nx0 + f.vel.y * nz0 + f.kb.x * nx0 + f.kb.y * nz0);
        if (vTowardsCorner > 0.25) {
          f.vel.x *= 0.3;
          f.vel.y *= 0.3;
          f.kb.x *= 0.35;
          f.kb.y *= 0.35;
          g.arena.triggerCornerPad(cIdx, vTowardsCorner);
          if (vTowardsCorner > 2.0 && f.wallCd <= 0) {
            f.wallCd = 0.45;
            g.sfx.cornerPadHit(Math.min(1, vTowardsCorner / 5.5));
            g.fx.spark(new THREE.Vector3(f.pos.x, 3.8 * f.scale, f.pos.y), 12, 5.5, 0xffd27a, new THREE.Vector3(nx0, 0.4, nz0), 0.8, 0.45, 8);
            g.popup(new THREE.Vector3(f.pos.x, 6.2 * f.scale, f.pos.y), 'BANTALAN SUDUT!', 'pop-info');
          }
        }
      }
    }

    f.speed = f.state === 'ko' ? 0 : f.vel.length();

    if ((f.state === 'air' || (f.state === 'ko' && airborne)) && g.phase !== 'walk' && g.phase !== 'menu') {

      f.airSpin *= Math.exp(-1.6 * dt);
      f.yaw += f.airSpin * dt;
      if (dt > 0) f.yawRate = lerp(f.yawRate, f.airSpin, 1 - Math.exp(-14 * dt));
    } else if (f.state !== 'ko' && f.state !== 'down' && g.phase !== 'menu') {
      f.airSpin = 0;
      const target = Math.atan2(o.pos.x - f.pos.x, o.pos.y - f.pos.y);
      const locked = f.state === 'attack' && f.whooshed;
      const counterAim = f.isPlayer && (f.dodgeT > 0 || f.dodgeTail > 0 || (f.state === 'attack' && !f.whooshed));
      const rate = locked ? (f.move?.id === 'hook' || f.move?.id === 'counter' ? 4.5 : 0.8) : f.state === 'air' ? 3 : counterAim ? 18 : f.softT > 0 ? 4.5 : 10.5;
      const dyaw = wrapAngle(target - f.yaw) * (1 - Math.exp(-rate * dt));
      f.yaw += dyaw;
      if (dt > 0) f.yawRate = lerp(f.yawRate, dyaw / dt, 1 - Math.exp(-14 * dt));
    } else {
      f.yawRate = 0;
    }

    {
      const ang = Math.min(1.5, f.tilt + 1.5 * THREE.MathUtils.clamp(f.fallS.x, 0, 1));
      if (ang > 0.15) {
        const L = TIP_LEN * f.scale * Math.sin(ang);
        const tx = f.pos.x - Math.sin(f.yaw) * L;
        const tz = f.pos.y - Math.cos(f.yaw) * L;
        const lim = ringCfg.in - 0.8;
        if (Math.abs(tx) > lim || Math.abs(tz) > lim) {
          const tgt = Math.atan2(f.pos.x, f.pos.y);
          f.yaw += wrapAngle(tgt - f.yaw) * (1 - Math.exp(-4.5 * dt));
          const ox = Math.abs(tx) - lim;
          const oz = Math.abs(tz) - lim;
          if (ox > 0) f.pos.x -= Math.sign(tx) * Math.min(ox, 5 * dt);
          if (oz > 0) f.pos.y -= Math.sign(tz) * Math.min(oz, 5 * dt);
        }
      }
    }
  }

export function updateAir(g: Game, f: Fighter, dt: number) {
    f.vy -= GRAVITY * dt;
    f.y += f.vy * dt;
    if (f.y > 0) return;
    f.y = 0;
    const imp = -f.vy;
    if (imp > 14 && !f.bounced) {

      f.bounced = true;
      f.vy = imp * 0.14;
      g.landFx(f, imp);
      g.ragdollSlam(f, Math.min(1, imp / 18) * 0.85);
    } else {
      f.vy = 0;
      if (f.state === 'air') {
        f.state = 'down';
        if (g.phase === 'fight') g.stats.knockdowns[f.isPlayer ? 1 : 0]++;

        f.downDur = 2.0 * (f.isPlayer ? 1 : 1 / (1 + (g.iq - 1) * 0.06));
        f.downT = f.downDur;
        f.riseU = 0;
        f.riseOut = 0;
        f.riseSteps = 0;
        f.riseServoPlayed = false;
        f.canvasSlammed = false;

        const to = g.toward(f, g.foeOf(f));
        f.riseDir = to.x * Math.cos(f.yaw) - to.y * Math.sin(f.yaw) >= 0 ? 1 : -1;
        f.fallT = 1;

        f.fallS.set(0);
        f.fallS.v = Math.min(2.2, 1.35 + imp * 0.045);
        f.tiltLand = f.tilt;
        f.tiltZLand = f.tiltZ;
        if (Math.abs(f.tiltZ) > 0.15) f.riseDir = f.tiltZ > 0 ? 1 : -1;
        g.ragdollSlam(f, Math.min(1.15, imp / 16));
        f.juggle = 0;
        f.comboTaken = 0;
        f.kb.multiplyScalar(0.4);
      } else if (f.state === 'ko' && f.fallT === 0) {

        f.fallT = 1;
        f.fallS.set(0);
        f.fallS.v = Math.min(2.2, 1.35 + imp * 0.045);
        f.tiltLand = f.tilt;
        f.tiltZLand = f.tiltZ;
        f.canvasSlammed = false;
        if (Math.abs(f.tiltZ) > 0.15) f.riseDir = f.tiltZ > 0 ? 1 : -1;
        g.ragdollSlam(f, Math.min(1.2, imp / 15));
        f.kb.multiplyScalar(0.45);
      }
      if (imp > 2) g.landFx(f, imp);
    }
  }

export function ragdollKick(_g: Game, f: Fighter, mag: number, side: number) {
    for (let i = 0; i < 2; i++) {
      const sp = f.armS[i];
      const s = i === 0 ? 1 : -1;
      sp[0].v += (-4.2 - (s * side > 0 ? 2.0 : 0.5)) * mag;
      sp[2].v += (1.1 + (s * side > 0 ? 0.8 : 0.2)) * mag;
      sp[3].v += (2.4 + (s * side > 0 ? 1.0 : 0)) * mag;
    }
    f.bodyS.twist.v += side * 3.2 * mag;
    f.bodyS.roll.v += side * 1.4 * mag;
    f.robot.jolt(mag * 0.9, side);
  }

export function ragdollSlam(_g: Game, f: Fighter, mag: number) {
    const side = f.riseDir || 1;
    for (let i = 0; i < 2; i++) {
      const sp = f.armS[i];
      const s = i === 0 ? 1 : -1;

      sp[0].v += (-1.8 - (s * side > 0 ? 0.9 : 0.3)) * mag;
      sp[2].v += (1.15 + (s * side > 0 ? 0.55 : 0.2)) * mag;
      sp[3].v += (-1.5 - (s * side > 0 ? 0.35 : 0.75)) * mag;
    }
    f.bodyS.twist.v += side * 1.6 * mag;
    f.bodyS.roll.v += -side * 1.2 * mag;
    f.bodyS.dip.v += 2.0 * mag;
    f.robot.jolt(mag, side);
  }

export function landFx(g: Game, f: Fighter, imp: number) {
    const pw = Math.min(1, imp / 20);
    g.fx.ring(f.pos.x, f.pos.y, 0xc8d0e0, 4 + pw * 8, 0.55, 0.08);
    g.fx.spark(new THREE.Vector3(f.pos.x, 0.2, f.pos.y), 14 + Math.floor(pw * 44), 4 + pw * 8, 0xb4b4c4, undefined, 1.4, 0.7, 6);
    g.fx.spark(new THREE.Vector3(f.pos.x, 0.4, f.pos.y), 6 + Math.floor(pw * 20), 6 + pw * 6, 0xffb060, undefined, 1.2, 0.6, 14);
    g.sfx.hit(0.3 + pw * 0.55);
    g.trauma = Math.min(0.28, g.trauma + 0.06 + pw * 0.12);
    g.camBump = Math.max(g.camBump, 0.04 + pw * 0.08);
    g.hype = Math.min(1, g.hype + 0.15);

    if (g.phase === 'fight') g.crowdRoar(f.isPlayer ? 0.32 : 0.62, f.isPlayer ? 1.4 : 2.2);
  }

export function ropeImpact(g: Game, f: Fighter, wx: number, wz: number, vIn: number) {
    f.wallCd = 0.5;
    const p = Math.min(1, (vIn - 2.5) / 10);
    const strong = vIn > 6.0;
    if (strong) f.wallT = 1.0;
    f.dash.multiplyScalar(0.3);
    if (f.state === 'air') {

      f.vy = Math.min(f.vy, 1.0);
      f.kb.multiplyScalar(0.35);
      f.robot.jolt(0.5 + p * 0.5, f.riseDir || 1);
    }
    else if (strong && f.state !== 'ko' && f.state !== 'down') {
      f.state = 'stagger';
      f.move = null;
      f.queued = null;
      f.blocking = false;
      f.dodgeT = 0;
      f.stunT = Math.max(f.stunT, 0.45 + p * 0.25);
      f.hit = Math.max(f.hit, 0.3 + p * 0.3);
      f.hitF = -1;
      f.hitL = 0;
      f.hitSpin = 0;
      f.hitPt = 0.5;
      f.hitSign = Math.random() < 0.5 ? 1 : -1;
    }
    const px = f.pos.x + wx * 1.5;
    const pz = f.pos.y + wz * 1.5;
    g.arena.ropeHit(wx ? wx * 20 : f.pos.x, wz ? wz * 20 : f.pos.y, 0.3 + p * 0.9);
    g.fx.spark(new THREE.Vector3(px, 4.9 * f.scale, pz), 6 + Math.floor(p * 20), 4 + p * 5, 0xffe0a0, new THREE.Vector3(-wx, 0.2, -wz), 1.2, 0.5, 10);
    g.sfx.ropeCreak(p);
    g.trauma = Math.min(0.22, g.trauma + 0.03 + p * 0.07);
    g.camBump = Math.max(g.camBump, 0.02 + p * 0.05);
    if (strong) {
      g.sfx.cheer(0.5);
      g.hype = Math.max(g.hype, 0.8);
      g.popup(new THREE.Vector3(f.pos.x, 6.4 * f.scale, f.pos.y), 'ROPE BOUNCE!', 'pop-crit');

      f.slingT = 0.16 + p * 0.08;
      f.slingV = ropeSlingSpeed(p, vIn);
      f.slingIn = vIn;
      f.slingX = -wx;
      f.slingZ = -wz;

      g.sfx.ropeSlam(0.5 + p * 0.5);
      g.fx.ring(f.pos.x, f.pos.y, 0xffffff, 3 + p * 3, 0.3, 0.08);
      g.camPush += 0.08 + p * 0.14;
    }
  }

export function separate(g: Game) {
    const list = g.fighters();
    const w = (f: Fighter) => (f.state === 'ko' ? 0 : f.state === 'down' ? 0.15 : 1);
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const p = list[i];
        const e = list[j];
        if (p.state === 'air' || e.state === 'air' || p.state === 'legend' || e.state === 'legend' || p.state === 'legendHit' || e.state === 'legendHit') continue;
        const minD = 3.35 * (p.scale + e.scale) * 0.5;
        const d = p.pos.distanceTo(e.pos);
        if (d >= minD || d < 0.001) continue;
        const pw = w(p);
        const ew = w(e);
        const tot = pw + ew;
        if (tot === 0) continue;
        const dir = new THREE.Vector2().subVectors(p.pos, e.pos).multiplyScalar(1 / d);
        const push = minD - d;
        p.pos.addScaledVector(dir, (push * pw) / tot);
        e.pos.addScaledVector(dir, (-push * ew) / tot);
      }
    }
    for (const f of list) {

      const touch = ringCfg.in - BODY_R * f.scale;
      const hx = touch + ropeGive(f.pos.y);
      const hz = touch + ropeGive(f.pos.x);
      f.pos.x = THREE.MathUtils.clamp(f.pos.x, -hx, hx);
      f.pos.y = THREE.MathUtils.clamp(f.pos.y, -hz, hz);
    }
  }

export function beginStrike(g: Game, f: Fighter, o: Fighter, m: Move) {
    if (g.phase === 'fight' && m.id !== 'counter') g.stats.thrown[f.isPlayer ? 0 : 1]++;
    const dir = g.toward(f, o);
    const isPlayerCounter = f.isPlayer && (m.id === 'counter' || f.winStrike || f.counterT > 0);
    if (isPlayerCounter) {
      f.attackDir.copy(dir);
      f.yaw = Math.atan2(dir.x, dir.y);
      f.vel.set(0, 0);
    } else {
      f.attackDir.lerp(dir, TRACK[m.id]).normalize();
    }
    const d = f.pos.distanceTo(o.pos);
    const avg = (f.scale + o.scale) * 0.5;
    const idealStop = (isPlayerCounter ? 3.25 : 3.4) * avg;
    const allowed = o.state === 'ko' || o.state === 'down' ? 0 : Math.max(0, d - idealStop);
    const maxStep = m.step * f.scale * (isPlayerCounter ? 1.45 : 1.15) * (f.runStrike ? 1.45 : f.ippoStrike ? 1.35 : 1);
    const disp = Math.min(isPlayerCounter ? Math.max(maxStep, Math.min(allowed, 3.8 * f.scale)) : maxStep, allowed);
    if (f.runStrike) {

      g.fx.spark(new THREE.Vector3(f.pos.x, 0.2, f.pos.y), 22, 6, 0x9a9aaa, new THREE.Vector3(-dir.x, 0.1, -dir.y), 1.1, 0.5, 3);
    }
    f.dash.addScaledVector(dir, disp * 7.2);
    g.sfx.whoosh(m.power);
    g.sfx.step(0.55 + m.power * 0.8);
    const fx = f.pos.x + dir.x * 0.9;
    const fz = f.pos.y + dir.y * 0.9;
    g.fx.spark(new THREE.Vector3(fx, 0.15, fz), 6 + Math.floor(m.power * 22), 3 + m.power * 4, 0x9a9aaa, undefined, 1.2, 0.4, 3);
    g.fx.flash(new THREE.Vector3(fx, g.aimY(f, m) * 0.7 * f.scale, fz), 0.7 + m.power * 1.6, 0xbfe6ff, 0.09);

    const streak = new THREE.Vector3(dir.x, 0.06, dir.y);
    const hx = f.pos.x + dir.x * 1.7 * f.scale;
    const hz = f.pos.y + dir.y * 1.7 * f.scale;
    g.fx.spark(
      new THREE.Vector3(hx, g.aimY(f, m) * f.scale, hz),
      4 + Math.floor(m.power * 15),
      8 + m.power * 9,
      isOD(m.id) ? 0xffd27a : 0xbfe6ff,
      streak,
      0.55,
      0.26,
      5,
    );

    if (m.power >= 0.6) g.fovKick = Math.max(g.fovKick, 1.5 + 2.5 * m.power);
  }

export function resolveHit(g: Game, a: Fighter, d: Fighter) {
    const m = a.move!;
    const X = MOVE_EXTRA[m.id];
    const aim = a.aim;

    if (d.state === 'ko' || d.state === 'down' || d.state === 'legend' || d.state === 'legendHit' || a.state === 'legend' || a.state === 'legendHit' || (g.phase !== 'fight' && g.phase !== 'menu')) return;
    const dist = a.pos.distanceTo(d.pos);
    const toA = new THREE.Vector2().subVectors(a.pos, d.pos).normalize();
    const away = new THREE.Vector2(-toA.x, -toA.y);

    const chassis = chassisOf(d.robot.isZeus, d.robot.isAtlasChassis);
    const isHJ = m.id === 'jab' || m.id === 'hook';

    const aimP = g.aimPoint(d, aim, g.aimTmp);
    const hitPos = new THREE.Vector3(aimP.x + toA.x * 0.75 * d.scale, aimP.y, aimP.z + toA.y * 0.75 * d.scale);
    const dirAD = new THREE.Vector3(away.x, 0.2, away.y);

    if (m.id === 'bolt') {

      const fxp = new THREE.Vector3(a.pos.x - toA.x * 3.4, 3.5 * a.scale, a.pos.y - toA.y * 3.4);
      g.fx.ring(a.pos.x - toA.x * 2.4, a.pos.y - toA.y * 2.4, 0x9fe6ff, 9, 0.55);
      g.fx.spark(fxp, 16, 13, 0x9fe6ff, new THREE.Vector3(-toA.x, 0.05, -toA.y), 0.5, 0.6, 3);
    }
    if (m.id === 'windmill') {

      const fxp = new THREE.Vector3(a.pos.x - toA.x * 3.2, 3.8 * a.scale, a.pos.y - toA.y * 3.2);
      g.fx.ring(a.pos.x - toA.x * 2.2, a.pos.y - toA.y * 2.2, 0xffb830, 12.5, 0.65);
      g.fx.ring(a.pos.x - toA.x * 2.2, a.pos.y - toA.y * 2.2, 0x5fe2ff, 8.5, 0.48, 0.14);
      g.fx.spark(fxp, 20, 15, 0xffb830, new THREE.Vector3(-toA.x, 0.18, -toA.y), 0.75, 0.75, 6);
      g.fx.spark(fxp, 12, 12, 0x5fe2ff, new THREE.Vector3(-toA.x, 0.1, -toA.y), 0.65, 0.6, 4);
    }
    if (m.id === 'skyhook') {

      const fxp = new THREE.Vector3(a.pos.x - toA.x * 1.5, 4.1 * a.scale, a.pos.y - toA.y * 1.5);
      const up = new THREE.Vector3(-toA.x * 0.22, 1, -toA.y * 0.22).normalize();
      g.fx.impactWave(fxp, up, 0xffe6b0, 6.5, 0.3);
      g.fx.ring(a.pos.x - toA.x * 1.4, a.pos.y - toA.y * 1.4, 0xffd27a, 8.6, 0.5, 3.5 * a.scale);
      g.fx.ring(a.pos.x - toA.x * 1.2, a.pos.y - toA.y * 1.2, 0xfff6dc, 5.2, 0.42, 4.5 * a.scale);
      g.fx.spark(fxp, 18, 15, 0xffd27a, up, 0.8, 0.75, 9);
      g.fx.spark(fxp, 10, 12, 0xffffff, up, 0.6, 0.6, 7);
    }
    if (m.id === 'counter') {

      const fxp = new THREE.Vector3(a.pos.x - toA.x * 2.4, 3.5 * a.scale, a.pos.y - toA.y * 2.4);
      g.fx.ring(a.pos.x - toA.x * 1.8, a.pos.y - toA.y * 1.8, 0x9fe6ff, 5.5, 0.42);
      g.fx.spark(fxp, 12, 10, 0x9fe6ff, new THREE.Vector3(-toA.x, 0.05, -toA.y), 0.5, 0.5, 3);
    }
    if (m.id === 'finisher') {

      const fxp = new THREE.Vector3(a.pos.x - toA.x * 2.6, 3.6 * a.scale, a.pos.y - toA.y * 2.6);
      const line = new THREE.Vector3(-toA.x, 0.06, -toA.y);
      g.fx.ring(a.pos.x - toA.x * 2.0, a.pos.y - toA.y * 2.0, 0xffd27a, 15.5, 0.72);
      g.fx.ring(a.pos.x - toA.x * 1.6, a.pos.y - toA.y * 1.6, 0xfff6dc, 9.5, 0.5, 0.06);
      g.fx.spark(fxp, 30, 17, 0xffd268, line, 0.85, 0.85, 12);
      g.fx.spark(fxp, 18, 14, 0xffffff, line, 0.7, 0.6, 8);
      g.fx.ring(a.pos.x - toA.x * 1.0, a.pos.y - toA.y * 1.0, 0xffb040, 10.5, 0.55, 2.2 * a.scale);
    }
    if (m.id === 'slam') {
      g.fx.ring(a.pos.x - toA.x * 1.8, a.pos.y - toA.y * 1.8, 0xffb040, 14, 0.7);
      g.fx.ring(a.pos.x - toA.x * 1.8, a.pos.y - toA.y * 1.8, 0xffffff, 8, 0.45);
      g.fx.spark(new THREE.Vector3(a.pos.x - toA.x * 2.4, 0.3, a.pos.y - toA.y * 2.4), 22, 11, 0xffa040, undefined, 1.4, 1.0, 16);
    }

    if (d.dodgeFor === a.moveSeq) {
      d.dodgeFor = -1;
      a.whiffT = g.markWhiff(a, m);
      g.perfectDodge(d, m);
      if (!d.isPlayer) g.aiDefended('dodge', a.moveSeq);
      return;
    }

    const trueCounter = m.id === 'counter' || a.winStrike || a.counterT > 0;

    const starReach = g.starMode && a.isPlayer ? STAR_RANGE_ASSIST : 1;
    if (dist > (m.reach + (a.runStrike ? 1.0 : 0) + (trueCounter ? 0.65 : 0)) * a.scale * starReach) {
      a.whiffT = g.markWhiff(a, m);
      return;
    }

    if (d.state === 'attack' && d.move && d.move.id === 'counter' && (d.moveT <= PARRY_ACTIVE || d.parryFor === a.moveSeq)) {
      g.parryCounter(d, a, m);
      return;
    }

    const rel = new THREE.Vector2().subVectors(d.pos, a.pos);
    const lateral = Math.abs(rel.x * a.attackDir.y - rel.y * a.attackDir.x);
    const avg = (a.scale + d.scale) * 0.5;
    const hitWidth = X.width * (trueCounter ? 1.45 : 1) * avg;
    if (lateral > hitWidth) {
      a.whiffT = g.markWhiff(a, m);
      if (d.dodgeT > 0 || d.invuln > 0) {
        g.perfectDodge(d, m);
        if (!d.isPlayer) g.aiDefended('dodge', a.moveSeq);
      }
      return;
    }
    if (d.wakeT > 0) return;

    if (d.invuln > 0 && !trueCounter) {
      g.perfectDodge(d, m);
      if (!d.isPlayer) g.aiDefended('dodge', a.moveSeq);
      return;
    }

    if ((m.id === 'counter' || isOD(m.id)) && d.state === 'attack' && d.move && !d.impacted) {
      if (m.id === 'counter') {
        g.parryCounter(a, d, d.move);
      } else {
        d.move = null;
        d.queued = null;
        d.tellT = 0;
        d.tellTotal = 0;
        d.state = 'stagger';
        d.stunT = 0.75;
        a.counterT = Math.max(a.counterT, 1.8);
      }
    }

    let dmg = m.dmg * a.dmgMul;

    const panjerKb = a.panjer;
    if (a.panjer > 1) dmg *= a.panjer;
    if (a.robot.isZeus) {
      dmg *= 1.10;
    }
    let label = '';
    if (a.runStrike) {
      dmg *= 1.45;
      label = 'RUNNING PUNCH!';
    }
    if (a.counterT > 0) {
      dmg *= 1.6;
      a.counterT = 0;
      label = a.isPlayer ? 'COUNTER!' : '⚡ COUNTER MUSUH!';
    }
    if (d.state === 'attack' && d.move && d.moveT < d.move.impact && !label && !isOD(m.id)) {
      dmg *= d.isPlayer ? 1.15 : 1.35;
      label = 'CRITICAL!';
    }
    const crit = label !== '';

    if (a.winStrike) {
      dmg *= 1 + (DODGE_WIN_DMG - 1) * (a.isPlayer ? 1 : 0.5);
      label = label || 'DODGE STRIKE!';
    }

    const epicComeback = a.isPlayer && a.hp <= a.maxHp * 0.45 && (crit || a.winStrike || m.id === 'counter' || isOD(m.id));
    if (epicComeback) {
      dmg *= 1.28;
      label = isOD(m.id) ? '🔥 OVERDRIVE COMEBACK!' : '🔥 EPIC COMEBACK!';
    }

    if (a.rage) {
      dmg *= 1.22;
      if (!label && m.power >= 0.55) label = 'RAGE SMASH!';
    }

    if (a.ippoStrike) {
      dmg *= 1 + 0.85 * a.strikeCharge;
      label = label || (a.strikeCharge > 0.85 ? 'DEMPSEY SMASH!' : 'DEMPSEY ROLL!');
      g.fx.ring(d.pos.x, d.pos.y, 0x7fe0ff, 4 + a.strikeCharge * 5, 0.4, 0.09);
      g.trauma = Math.min(0.65, g.trauma + 0.14 + a.strikeCharge * 0.22);
    }
    if (d.wallT > 0) dmg *= 1.25;
    const wasAir = d.state === 'air';
    dmg *= wasAir ? Math.max(0.45, 1 - d.juggle * 0.15) : Math.max(0.45, 1 - d.comboTaken * 0.1);

    dmg *= AIM_DMG[aim];
    if (!label && aim === AIM_BODY) label = m.id === 'upper' ? 'LIVER SHOT!' : 'BODY BLOW!';

    if (m.id === 'finisher') label = '☠️ PUKULAN MEMATIKAN!';

    if (a.panjer > 1) {
      label = `💪 PANJER! ${panjerLabel(a.panjer)}`;
      g.fx.ring(d.pos.x, d.pos.y, 0xffd34a, 6.5, 0.45, 0.1);
      g.trauma = Math.min(0.7, g.trauma + 0.16);
    }

    // PEEK-A-BOO: the weaving head slips jabs and crosses completely (but not hooks, uppercuts, throws or Overdrive)
    if (d.ippo && d.state === 'idle' && d.slipCd <= 0 && (m.id === 'jab' || m.id === 'cross')) {
      d.slipCd = 0.4;
      d.rollCharge = Math.min(1, d.rollCharge + 0.28);
      d.meter = Math.min(100, d.meter + 6);
      g.popup(new THREE.Vector3(d.pos.x, 6.2 * d.scale, d.pos.y), 'SLIP!', 'pop-dodge');
      if (a.isPlayer) g.breakNCombo('KOMBO DIPUTAR!'); // slipped under the pea-a-boo: the link missed
      g.sfx.dodge();
      g.fx.spark(hitPos, 10, 5, 0x9fe6ff, dirAD, 1, 0.35);
      return;
    }

    // ---------- blocked (90% attack strength reduction -> only 10% damage gets through, with MASSIVE sparks & heavy punch impact feel!) ----------
    // (the finisher is deliberately NOT blockable — see `blockable`: like the throw, it is answered by not being
    // there. Only a slip or a step off the line beats it, which is exactly what its very long tell is for.)
    if (blockable(m.id) && d.blocking && (d.state === 'idle' || d.state === 'stagger')) {
      a.hitConfirmed = true;
      if (!d.isPlayer) g.aiDefended('block', a.moveSeq);
      const big = m.power;
      // A HELD guard (G) is a wall: only 10% of the damage gets through. The STAR MODE AUTO-GUARD is the light
      // barrier that comes up on its own — it still saves you, but 22% gets through and it drains under pressure,
      // which is what keeps "just stand there" from being the best strategy even in the comfort mode.
      if (a.isPlayer) g.breakNCombo('KOMBO DIBLOK!'); // the script does not punch through a guard
      const guardMul = d.autoGuard ? 0.22 : 0.10;
      const chip = dmg * guardMul;
      d.hp = Math.max(1, d.hp - chip);
      if (g.phase === 'fight') {
        g.stats.dmg[a.isPlayer ? 0 : 1] += chip;
      }
      // Stamina drain is reduced the same way by the guard
      d.stam = Math.max(0, d.stam - dmg * guardMul * AIM_STAM[aim] * (d.ippo ? 0.55 : 1));

      // Physical boot-skid pushback so the 2-ton punch force visibly shoves the defender's planted guard across the mat
      const blockPush = m.knock * (0.42 + big * 0.36) * (a.rage ? 1.25 : 1) * chassisKnock(chassis);
      d.kb.addScaledVector(away, blockPush);
      if (dist > 2.85 * avg) a.kb.addScaledVector(away, blockPush * 0.45);

      // Exact collision point on the raised forearm guard in front of the defender
      const guardPos = new THREE.Vector3(aimP.x + toA.x * 1.05 * d.scale, aimP.y, aimP.z + toA.y * 1.05 * d.scale);
      const sideVec = new THREE.Vector3(-away.y, 0.38, away.x).normalize();
      const sideVecR = new THREE.Vector3(away.y, 0.38, -away.x).normalize();
      const bounceBack = new THREE.Vector3(-away.x * 0.7, 0.55, -away.y * 0.7).normalize();

      // 1. MASSIVE STEEL-ON-STEEL WELDING SPARKS & LATERAL ANVIL SPRAY
      // Main golden-orange welding spark fountain erupting off the forearm shield
      g.fx.spark(guardPos, 28, 13.5 + big * 12, 0xffd268, bounceBack, 1.05, 0.78, 12);
      g.fx.spark(guardPos, 22, 11.5 + big * 10, 0xff9430, dirAD, 1.15, 0.85, 14);
      // White-hot core impact flash sparks
      g.fx.spark(guardPos, 20, 12.0 + big * 9, 0xffffff, bounceBack, 1.25, 0.48, 10);
      // Twin lateral spark jets squirting out left & right between the colliding glove and crossed steel forearms
      g.fx.spark(guardPos, 18, 13.0 + big * 10, 0xffdf80, sideVec, 0.72, 0.68, 12);
      g.fx.spark(guardPos, 18, 13.0 + big * 10, 0xffdf80, sideVecR, 0.72, 0.68, 12);
      // High-voltage cyan-blue kinetic shield / servo overload arcs
      g.fx.spark(guardPos, 16, 11.0 + big * 9, 0x7fe8ff, bounceBack, 0.95, 0.56, 9);
      // Heavy boot-skid friction sparks & canvas dust at the defender's planted feet
      g.fx.spark(new THREE.Vector3(d.pos.x, 0.14, d.pos.y), 12 + Math.floor(big * 10), 5.5 + big * 4.5, 0xffc868, new THREE.Vector3(-away.x, 0.35, -away.y), 1.15, 0.5, 10);
      g.fx.spark(new THREE.Vector3(d.pos.x, 0.18, d.pos.y), 8 + Math.floor(big * 6), 4.5 + big * 3.5, 0xb8c4d8, new THREE.Vector3(-away.x, 0.25, -away.y), 1.25, 0.45, 5);
      // Tumbling glowing armor shards chipped off the forearm guard
      g.fx.shards(guardPos, 6 + Math.floor(big * 12), bounceBack, d.robot.armorColor, 8 + big * 7, 0.75 + big * 0.55);

      // Hot embers dripping from the scorched forearm guard after impact
      d.emberT = Math.max(d.emberT, 0.26 + big * 0.32);
      {
        const sy = Math.sin(d.yaw);
        const cy = Math.cos(d.yaw);
        const lx = guardPos.x - d.pos.x;
        const lz = guardPos.z - d.pos.y;
        d.emberLocal.set(cy * lx - sy * lz, guardPos.y - d.y, sy * lx + cy * lz);
      }

      // 2. HEAVY MECHANICAL GUARD COMPRESSION & SUSPENSION JOLT ON DEFENDER
      // The defender stays in tight BLOCK stance, but the sheer force of the punch visibly compresses his forearms,
      // rocks his torso back on its springs, sinks his knees into the mat, and jolts the robot's pistons!
      const cyD = Math.cos(d.yaw);
      const syD = Math.sin(d.yaw);
      const hitL = away.x * cyD - away.y * syD;
      const hitSide = Math.abs(hitL) > 0.1 ? Math.sign(hitL) : (m.arm === 0 ? 1 : -1);
      const guardShove = 1.0 + big * 1.45;
      for (let i = 0; i < 2; i++) {
        const sp = d.armS[i];
        const s = i === 0 ? 1 : -1;
        sp[0].v += (2.4 + (s * hitSide > 0 ? 1.2 : 0.5)) * guardShove; // forearms driven back against chest/jaw
        sp[2].v += (1.1 + (s * hitSide > 0 ? 0.7 : 0.25)) * guardShove; // guard absorbs lateral shock
        sp[3].v -= (1.8 + big * 1.4) * guardShove; // elbows flex tightly under load
      }
      d.bodyS.lean.v -= (2.8 + big * 3.8); // torso rocks backward from the blow
      d.bodyS.lunge.v -= (2.5 + big * 3.2); // hips brace backward
      d.bodyS.dip.v += (2.6 + big * 3.4); // knees compress into the canvas to hold ground
      d.bodyS.twist.v += hitSide * (2.2 + big * 3.2); // shoulders torque with the punch side
      d.bodyS.roll.v -= hitSide * (1.2 + big * 1.8);
      d.robot.jolt(0.65 + big * 0.85, hitSide);
      d.flash = Math.max(d.flash, 0.85 + big * 0.35);
      d.glowBoost = Math.max(d.glowBoost, 1.6 + big * 1.4);

      // 3. ATTACKER FIST RECOIL OFF THE STEEL GUARD WALL
      a.recoilArm = g.armOf(a, m);
      a.recoilTot = 0.15 + big * 0.1;
      a.recoilT = a.recoilTot;
      a.recoilAmt = 0.95 + big * 1.15; // a guard is a solid wall of steel: the fist bounces off it hard!

      // 4. SHOCKWAVES, FLASH, STROBE, CAMERA PUNCH & THUNDEROUS STEEL CLANG AUDIO
      g.fx.flash(guardPos, 3.8 + big * 4.2, 0xffe4a8, 0.22);
      g.fx.impactWave(guardPos, dirAD, 0xffd27a, 2.8 + big * 2.8, 0.26, 0.36);
      g.fx.impactWave(guardPos, bounceBack, 0x8fe8ff, 2.2 + big * 2.2, 0.22, 0.3);
      g.fx.ring(guardPos.x, guardPos.z, 0xffe090, 2.8 + big * 2.8, 0.32, guardPos.y);
      g.fx.ring(d.pos.x, d.pos.y, 0x9fe6ff, 3.2 + big * 2.6, 0.3, 0.08);
      if (big >= 0.35) g.arena.strobe(0.28 + big * 0.55);

      g.sfx.block(Math.min(1, 0.65 + big * 0.5));
      g.sfx.hit(Math.min(1, 0.5 + big * 0.65)); // heavy low-end punch thud combined with metallic block clang
      g.sfx.crackle(0.65 + big * 0.65); // sizzling welding spark crackle
      if (g.allOverdrivePunch || isOD(m.id)) {
        g.sfx.overdriveHit(Math.min(1.1, 0.55 + big * 0.55));
      }

      g.freeze = 0.048 + big * 0.048; // crisp mechanical hitstop so the steel-on-steel impact feels heavy
      g.frozenFighter = d;
      g.shakePh = 0;
      g.trauma = Math.min(0.68, g.trauma + 0.22 + big * 0.32);
      g.camPush += 0.22 + big * 0.36;
      g.camBump = Math.max(g.camBump, 0.11 + big * 0.18);
      g.camRoll = hitSide * (0.012 + big * 0.024);
      g.fovKick = -(1.4 + big * 3.0);
      const bImp = 2.4 + big * 3.8;
      g.camImpVel.x += away.x * bImp;
      g.camImpVel.y -= 1.1 + big * 1.8;
      g.camImpVel.z += away.y * bImp;
      g.popup(guardPos, `🛡️ LINDUNG -90% (${Math.max(1, Math.round(chip))})`, 'pop-block');
      if (d.stam <= 0) {
        d.blocking = false;
        d.state = 'stagger';
        d.stunT = 1.0;
        d.hit = 1;
        d.hitF = away.x * Math.sin(d.yaw) + away.y * Math.cos(d.yaw);
        d.hitL = away.x * Math.cos(d.yaw) - away.y * Math.sin(d.yaw);
        d.hitSpin = d.hitL * 0.9;
        d.hitSign = Math.abs(d.hitL) > 0.1 ? Math.sign(d.hitL) : Math.random() < 0.5 ? 1 : -1;
        d.hitPt = aim === AIM_HEAD ? 1 : 0;
        d.hitKind = m.id === 'jab' ? 'jab' : (m.kind === 'side' || m.id === 'hook' ? 'hook' : (m.kind === 'up' || m.id === 'upper' ? 'upper' : (m.id === 'cross' ? 'cross' : 'standard')));
        d.hitArm = m.arm;
        d.hitPower = m.power;
        d.hitSeq++;
        g.ai.blockT = 0;
        g.sfx.guardBreak();
        g.popup(new THREE.Vector3(d.pos.x, 6.4 * d.scale, d.pos.y), 'GUARD BREAK!', 'pop-crit');
        g.freeze = 0.09;
        g.slowT = 0;
        g.trauma = Math.min(0.7, g.trauma + 0.32);
        g.camImpVel.y -= 2.4;
        d.stam = 25;
      }
      if (d.isPlayer) g.flashAmt = Math.max(g.flashAmt, 0.15);
      return;
    }
    d.blocking = false;

    // ---------- clean hit ----------
    const isOverdrive = isOD(m.id);
    const hp30Pct = d.maxHp * 0.30;
    const hpBeforeHit = d.hp;
    const hadHpAbove30 = isOverdrive && hpBeforeHit > hp30Pct;

    if (isOverdrive) {
      if (hadHpAbove30) {
        // OVERDRIVE JANGAN LANGSUNG MATI:
        // Jika sisa nyawa masih > 30%, Overdrive memberikan kekuatan pukulan dahsyat
        // (~25% HP bar atau nilai dmg murni), tetapi sisa nyawa dipertahankan minimal 30% (kritis).
        const odDmg = Math.max(dmg, d.maxHp * 0.25);
        d.hp = Math.max(Math.ceil(hp30Pct), d.hp - odDmg);
      } else {
        // OVERDRIVE HANYA BIKIN MATI KALO NYAWA SUDAH SISA 30% ATAU KURANG:
        // Menjadi eksekusi pemungkas fatal (Finisher KO)!
        d.hp = 0;
      }
    } else {
      d.hp = Math.max(0, d.hp - dmg);
    }
    d.hit = Math.min(1.4, 0.78 + dmg * 0.038);
    a.hitConfirmed = true;
    // ---- THE GEOMETRY OF THE HIT ----
    // The recoil is expressed in the DEFENDER's own frame, so the animation can be built from where the fist
    // really came from and where it landed: a straight snaps him back down the line, a hook turns his head off
    // the axis, an uppercut lifts him, a body shot folds him. `away` is the world push direction, rotated into
    // his local axes (the same convention the foot IK uses: local +z = his facing, local +x = his left).
    const cyD = Math.cos(d.yaw);
    const syD = Math.sin(d.yaw);
    d.hitF = away.x * syD + away.y * cyD;
    d.hitL = away.x * cyD - away.y * syD;
    d.hitPt = aim === AIM_HEAD ? 1 : 0;
    d.hitSpin = d.hitL * (m.kind === 'side' ? 1.7 : 0.9);
    d.hitSign = Math.abs(d.hitL) > 0.1 ? Math.sign(d.hitL) : Math.random() < 0.5 ? 1 : -1;
    d.hitKind = m.id === 'jab' ? 'jab' : (m.kind === 'side' || m.id === 'hook' ? 'hook' : (m.kind === 'up' || m.id === 'upper' ? 'upper' : (m.id === 'cross' ? 'cross' : 'standard')));
    d.hitArm = m.arm;
    d.hitPower = m.power;
    d.hitSeq++;
    // THE JAB IS HOW YOU CHARGE (see meterGainFor): measure with the jab, bank the meter, cash it in with R
    a.meter = Math.min(100, a.meter + meterGainFor(m.id, dmg, !a.isPlayer && g.ultra));
    d.meter = Math.min(100, d.meter + dmg * 0.55);
    if (a.isPlayer && a.meter >= 100 && !g.meterReadyShown) {
      g.meterReadyShown = true;
      g.sfx.ready();
      g.popup(new THREE.Vector3(a.pos.x, 6.4, a.pos.y), 'OVERDRIVE SIAP! [R]', 'pop-crit');
    }
    d.comboTaken++;
    const big = m.power;
    const armored = d.state === 'attack' && !!d.move && isOD(d.move.id) && !(a.isPlayer && (m.id === 'counter' || isOD(m.id)));
    // the target is what the punch does to him: the body tears down stamina and stability
    if (AIM_DRAIN[aim] > 0) d.stam = Math.max(0, d.stam - dmg * AIM_DRAIN[aim]);
    const isZeusDef = d.robot.isZeus;
    // drain stability; it only breaks after a sustained flurry of clean hits
    if (!wasAir && !armored) {
      const pCost = poiseCost(big) * AIM_POISE[aim] * (crit ? 1.6 : 1) * (epicComeback ? 1.45 : 1); // a counter-hit or comeback rocks much harder
      // chassis-aware: Zeus 55% (jab/hook 12%), ATLAS 80% (jab/hook 60%), a standard Titan the full price
      d.poise -= pCost * chassisPoise(chassis, isHJ);
      d.poiseT = POISE_DELAY;
    }
    // ---- WHEN DOES HE GO DOWN? Only when it is earned. A robot that falls over from every uppercut or every running
    // cross is not a fighter. He is "softened" when his stability is nearly gone, when he is already rocked by a
    // previous shot, or when he is nearly out of HP; only then do the launchers and the running cross take him off
    // his feet. The specials (Overdrive / throw) always do — that is what they are for. Breaking the stability bar
    // with a real punch (cross and up) is a knockdown; breaking it with a jab only ROCKS him and leaves the bar low.
    const poiseFrac = Math.max(0, d.poise) / d.poiseMax;
    const rocked = d.state === 'stagger' && d.stunT > 0.35;
    const softened = poiseFrac < 0.3 || rocked || d.hp <= d.maxHp * 0.22;
    const brokenRaw = d.poise <= 0;
    const broken = brokenRaw && big >= 0.5;
    if (broken) d.poise = d.poiseMax; // reset, so you cannot be chain-knocked-down
    else if (brokenRaw) {
      d.poise = d.poiseMax * 0.22; // rocked, not dropped — the next real punch can finish the job
      label = label || 'ROCKED!';
    }
    // Uppercut tidak mudah membuat robot terbang: hanya jika stabilitas/poise benar-benar pecah (broken) atau KO
    const upperLaunch = m.id === 'upper' && (broken || d.hp <= 0);
    const launcher = isOD(m.id) || m.id === 'grab' || upperLaunch;
    const runLaunch = a.runStrike && m.id === 'cross' && (softened || crit);
    const ippoLaunch = a.ippoStrike && a.strikeCharge > 0.85 && m.id !== 'jab' && (softened || big >= 0.6);
    let launched = false;
    if (wasAir) {
      if (isZeusDef && isHJ) {
        // Zeus tidak bisa dijuggling oleh pukulan ringan H/J — bobot 20% lebih berat membuatnya langsung menjejak tanah
        d.vy = Math.min(d.vy, -12);
      } else {
        d.juggle++;
        if (d.juggle >= 5 || isOD(m.id)) {
          d.vy = -17;
          label = 'SPIKE!'; // (no slow-mo: the body is in the air — the fall plays in real time)
        } else {
          // Uppercut di udara juga tidak melempar terlalu tinggi (pop rendah agar tidak terbang jauh)
          const pop = (m.id === 'jab' ? 7.5 : m.id === 'cross' ? 8.5 : m.id === 'hook' ? 9 : m.id === 'upper' ? 4.5 : 10) * (d.juggle >= 3 ? 0.75 : 1);
          d.vy = pop * chassisLift(chassis);
          d.kb.addScaledVector(away, (2.5 + big * 2) * chassisKnock(chassis));
          label = label || `JUGGLE x${d.juggle}`;
        }
      }
    // A LAUNCH (= being knocked down) now needs a real reason: a designated launcher, a fully committed special,
    // or a flurry that has emptied your stability. Ordinary jabs / crosses / hooks — even on a counter-hit — no
    // longer sweep you off your feet; they stagger you instead.
    } else if (!armored && (launcher || broken || runLaunch || ippoLaunch)) {
      // ZEUS LEBIH SULIT TERPENTAL. The 2-ton chassis digs its boots in: a jab or a hook never moves him at all, and
      // neither does any ordinary punch (a running cross, an uppercut, a flurry that empties his stability bar) until
      // he is genuinely SOFTENED — stability nearly gone, already rocked by the shot before, or nearly out of HP.
      // Only the designated launchers go through on a fresh Zeus: the Overdrive specials, the throw, the skyhook.
      // Everything that DOES take him off his feet throws him far less far and less high (see ZEUS_LAUNCH_*).
      const heavyBraced = chassisBraces(chassis, m.id, isHJ, softened);
      if (heavyBraced) {
        // Berdiri tegak tak tergoyahkan: tidak pernah mental terbang (state: air) ataupun tersungkur jatuh (state: down)
        d.state = 'stagger';
        d.move = null;
        d.queued = null;
        d.dodgeT = 0;
        d.stunT = Math.min(0.24, d.stunT);
        g.popup(new THREE.Vector3(d.pos.x, 7.0 * d.scale, d.pos.y), 'KEBAL TITAN!', 'pop-block');
      } else {
        launched = true;
        d.state = 'air';
        d.move = null;
        d.queued = null;
        d.dodgeT = 0;
        d.juggle = 0;
        d.bounced = false;
        // THE LAUNCH IS THE PUNCH. He is flung along the line the fist actually travelled — a straight drives him
        // back down its line, low and far; a hook throws him ACROSS and spins him; an uppercut lifts him — with a
        // speed that comes from the move's knock, its power, a running start, rage and a counter-hit. Then the
        // simulation (gravity, the lay-over with the travel, the ropes catching, the two-stage landing) does the rest.
        const fwdA = new THREE.Vector2(Math.sin(a.yaw), Math.cos(a.yaw));
        const leftA = new THREE.Vector2(Math.cos(a.yaw), -Math.sin(a.yaw));
        const pd = new THREE.Vector2();
        if (m.kind === 'side') pd.copy(leftA).multiplyScalar(m.arm === 0 ? -0.85 : 0.85).addScaledVector(fwdA, 0.5);
        else if (m.kind === 'up') pd.copy(fwdA).multiplyScalar(0.7);
        else pd.copy(fwdA);
        if (pd.lengthSq() < 1e-4) pd.copy(away);
        pd.normalize();
        const dir = new THREE.Vector2().addScaledVector(pd, 0.62).addScaledVector(away, 0.38).normalize();
        const force = m.knock * (0.72 + big * 0.5) * (a.runStrike ? 1.35 : 1) * (a.rage ? 1.2 : 1) * (crit ? 1.15 : 1) * panjerKb;
        // Zeus is thrown like a bag of anvils: much shorter across the canvas and a lower arc (ZEUS_LAUNCH_*)
        // ...and a PANJER is allowed to throw him past the ordinary ceiling: that is what the 2× is for.
        const horiz = THREE.MathUtils.clamp(force * 0.95, 4.5, 13.5 * panjerKb) * chassisLaunch(chassis);
        // the Overdrive uppercut is THE launcher: it throws him highest of anything in the book (a heavy uppercut that
        // was already a launcher, now with a meter behind it) — everything else keeps the standard profile
        // Uppercut biasa yang menembus pertahanan saat broken/KO tidak melempar ke angkasa (vertikal rendah & realistis)
        const vert = (m.id === 'skyhook' ? 16.5 + big * 5 : m.id === 'upper' ? 3.5 + big * 1.5 : m.kind === 'up' ? 12 + big * 4.5 : m.kind === 'side' ? 7.5 + big * 3 : 8 + big * 3.5) * chassisLift(chassis);
        d.vy = vert;
        d.kb.copy(dir).multiplyScalar(m.id === 'upper' ? Math.min(horiz, 6.5) : horiz);
        // a hook turns him round in the air (the head is thrown off the axis, the body follows); a straight barely does
        d.airSpin = m.kind === 'side' ? (m.arm === 0 ? -1 : 1) * (1.8 + big * 1.6) : (Math.random() - 0.5) * 0.5;
        // the limbs are thrown the way he is going (ragdoll kick side = the side the blow came across to)
        const sideL = dir.x * Math.cos(d.yaw) - dir.y * Math.sin(d.yaw); // + = driven to his left
        g.ragdollKick(d, 0.55 + big * 0.45, Math.abs(sideL) > 0.25 ? (sideL > 0 ? 1 : -1) : 1);
        label = m.id === 'grab' ? 'THROW!' : m.id === 'windmill' ? 'FREESTYLE SMASH!' : m.id === 'skyhook' ? 'SKYHOOK!' : broken && !launcher ? 'KNOCKDOWN!' : label || 'LAUNCH!';
      }
    } else if (!armored) {
      // BOXING HIT PUSHBACK & ringCfg.bound DOMINANCE:
      // Each landed strike noticeably drives the defender backward across the canvas while the attacker steps in to press the advantage!
      const heavyNoDrop = (m.id === 'upper' || (a.runStrike && m.id === 'cross') || brokenRaw) ? 1.35 : 1; // kept on his feet, but driven back hard — often into the ropes
      const pushMul = (1.85 + Math.min(4, d.comboTaken) * 0.3) * AIM_KNOCK[aim] * (a.runStrike ? 1.45 : 1) * (a.rage ? 1.35 : 1) * heavyNoDrop * panjerKb * chassisKnock(chassis);
      d.kb.addScaledVector(away, m.knock * pushMul);
      if (dist > 2.85 * avg) {
        a.kb.addScaledVector(away, m.knock * 0.62 * (a.rage ? 1.25 : 1));
      }
      // a smart AI shakes a hit off sooner, and where you hit him matters: head shots stun, body shots do not
      const sc = Math.max(0.35, 1 - d.comboTaken * 0.08) * (d.isPlayer ? 0.52 : 1 / (1 + (g.iq - 1) * 0.07));
      const stun = m.stun * sc * AIM_STUN[aim] * (brokenRaw ? 1.5 : 1);
      if (d.state === 'stagger') d.stunT = Math.max(d.stunT, stun);
      else {
        d.state = 'stagger';
        d.move = null;
        d.queued = null;
        d.dodgeT = 0;
        d.stunT = stun;
      }
    } else {
      d.kb.addScaledVector(away, m.knock * 0.4);
    }
    if (!d.isPlayer) {
      g.ai.blockT = 0;
      g.ai.reactT = -1;
      g.ai.defStreak = 0;
      g.ai.punishT = 0;
      g.ai.queued = null;
    }

    // feedback — heavy mechanical hitstop + 3D spring-damper camera punch so every 2-ton robot blow feels massive and solid!
    // Solid mechanical hitstop (freeze frames on contact): creates crushing punch weight without sluggish time-dilation!
    g.freeze = isOD(m.id) ? 0.038 : (0.055 + big * 0.075 + (launched ? 0.02 : 0));
    if (isOD(m.id)) {
      // OVERDRIVE: Keep at fluid, crisp 60 FPS (zero sluggish slow-mo drag or lag feeling!)
      g.slowT = 0;
      g.timeScale = 1.0;
    } else if (launched && d.hp <= 0) {
      // MATCH-ENDING KO KNOCKDOWN: Slow-motion impact punctuation
      g.slowT = 0.65;
      g.slowScale = 0.38;
    } else {
      // ALL NORMAL STRIKES (Jab, Cross, Hook, Uppercut, Counter, Crits, Dodge-Strikes):
      // NO awkward slow-mo hiccups! Keeps the fight fluid, crisp, and responsive at 100% full FPS!
      g.slowT = 0;
    }
    g.frozenFighter = d;
    g.trauma = Math.min(0.9, g.trauma + 0.28 + big * 0.44 + (crit ? 0.15 : 0) + (launched ? 0.16 : 0));
    g.shakePh = 0; // start shockwave at phase 0 right on impact for a clean, deterministic punch wave
    const impMag = (2.8 + big * 5.2) * (crit || launched ? 1.3 : 1);
    g.camImpVel.x += away.x * impMag;
    g.camImpVel.y -= 1.3 + big * 2.6;
    g.camImpVel.z += away.y * impMag;
    d.flash = 1;
    // THE JAB SNAP: its own little report, so a flurry of them reads as a machine gun instead of a mush of small
    // hits — a tight white crack at the point of contact, a thin shock ring, a dry crackle and a short lens kick
    if (m.id === 'jab') {
      g.fx.flash(hitPos, 2.4 + big * 2.2, 0xffffff, 0.09);
      g.fx.ring(hitPos.x, hitPos.z, 0xeaf4ff, 1.6 + big * 1.2, 0.2, hitPos.y);
      g.sfx.crackle(0.26 + big * 0.34);
      g.camBump = Math.max(g.camBump, 0.13 + big * 0.14);
      if (a.isPlayer) g.fovKick = Math.max(g.fovKick, 1.3);
    }
    // head shots snap his head back; body shots fold him over the punch (a negative hitUp drops the torso + head)
    d.hitUp = aim === AIM_BODY && !launched ? -(0.36 + big * 0.6) : m.kind === 'up' && !launched ? 0.45 + big * 0.75 : 0;
    d.dash.set(0, 0);
    g.camPush += 0.26 + big * 0.52;
    g.camBump = Math.max(g.camBump, 0.1 + big * 0.24);
    g.camRoll = d.hitSign * (0.015 + big * 0.032);
    g.fovKick = -(1.8 + big * 4.6);
    g.hype = Math.min(1, g.hype + 0.35 + big * 0.35);
    const hot = aim === AIM_BODY ? 0xff9840 : 0xffc458; // body shots burn warmer, head shots stay golden
    g.fx.spark(hitPos, 14 + Math.floor(big * 16), 11.5 + big * 14, hot, dirAD, 1.0, 0.9);
    g.fx.spark(hitPos, 6 + Math.floor(big * 6), 7.5 + big * 8, 0xffffff, dirAD, 1.25, 0.45);
    g.fx.spark(hitPos, 4 + Math.floor(big * 5), 9.5 + big * 10, 0x7fe0ff, dirAD, 0.85, 0.52); // high-voltage servo arc sparks
    g.fx.spark(new THREE.Vector3(d.pos.x, 0.2, d.pos.y), 5 + Math.floor(big * 5), 4.5 + big * 6, 0xb9c2d6, undefined, 1.4, 0.6, 7); // floor debris
    // ARMOUR CHIPS: real solid debris knocked off the plating, tinted to the armour that was hit, tumbling & bouncing
    g.fx.shards(hitPos, 5 + Math.floor(big * 14) + (crit ? 5 : 0), dirAD, d.robot.armorColor, 7 + big * 7, 0.8 + big * 0.7);
    // the dent keeps dripping embers for a moment (heavier blows bleed longer)
    d.emberT = Math.max(d.emberT, 0.22 + big * 0.3);
    {
      const sy = Math.sin(d.yaw);
      const cy = Math.cos(d.yaw);
      const lx = hitPos.x - d.pos.x;
      const lz = hitPos.z - d.pos.y;
      d.emberLocal.set(cy * lx - sy * lz, hitPos.y - d.y, sy * lx + cy * lz);
    }
    // the shock travels back up the attacker's arm: the fist recoils off the plate and the body rocks with it
    a.recoilArm = g.armOf(a, m);
    a.recoilTot = 0.14 + big * 0.12;
    a.recoilT = a.recoilTot;
    a.recoilAmt = 0.55 + big * 0.9 + (crit ? 0.3 : 0);
    g.fx.flash(hitPos, 3.2 + big * 5.6, 0xffe0a8, 0.25);
    if (big >= 0.4 || crit || launched) g.arena.strobe(0.3 + big * 0.7 + (launched ? 0.3 : 0)); // the rig kicks with the blow
    g.fx.impactWave(hitPos, dirAD, aim === AIM_BODY ? 0xff9c48 : 0xffdf88, 2.4 + big * 2.6, 0.24); // 3D sonic halo perpendicular to punch vector + 4-point starburst
    // Dynamic canvas shockwave ring on heavy impact / counter blow (eliminates redundant overlapping rings)
    if (big >= 0.45 || crit || launched) {
      g.fx.ring(d.pos.x, d.pos.y, aim === AIM_BODY ? 0xffa050 : 0xffdf90, 3.2 + big * 2.2, 0.32);
    }
    if (g.allOverdrivePunch || isOD(m.id)) {
      g.sfx.overdriveHit(Math.min(1.2, 0.7 + big * 0.7));
      g.sfx.crackle(0.45 + big * 0.6);
      g.sfx.cheer(0.35 + big * 0.7);
    } else {
      g.sfx.hit(Math.min(1, big * 1.15));
      g.sfx.crackle(0.25 + big * 0.55); // heavy steel armor crunch & electrical arc on every clean blow!
      g.sfx.cheer(0.3 + big * 0.7);
    }
    // an Overdrive that connects gets the director's punch-in on the point of impact — unless this is the
    // one that takes the head off, in which case the long HEAD RIP shot takes over instead
    const willRip = (a.isPlayer || a.robot.isZeus) && aim === AIM_HEAD && !d.decapitated && g.phase === 'fight' && !hadHpAbove30;
    if ((a.isPlayer || a.robot.isZeus) && isOD(m.id) && !willRip) g.startCine('hit', hitPos, m.id === 'bolt' || m.id === 'skyhook' ? toA : undefined);
    if (g.phase !== 'menu') {
      if (d.isPlayer) {
        g.flashAmt = Math.min(0.75, 0.22 + big * 0.35);
        g.flashEl.style.background = 'radial-gradient(ellipse at center, rgba(255,40,20,0) 35%, rgba(255,30,20,0.85) 100%)';
        g.combo = 0;
      } else {
        g.flashEl.style.background = 'radial-gradient(ellipse at center, rgba(255,255,255,0.0) 45%, rgba(255,255,255,0.3) 100%)';
        g.flashAmt = Math.max(g.flashAmt, 0.1 + big * 0.25);
        g.combo++;
        g.comboT = 2.3;
        g.stats.maxCombo = Math.max(g.stats.maxCombo, g.combo);
      }
      if (g.phase === 'fight') {
        const who = a.isPlayer ? 0 : 1;
        g.stats.landed[who]++;
        g.stats.dmg[who] += (isOverdrive && hadHpAbove30 ? hpBeforeHit - d.hp : dmg);
        if (crit && a.isPlayer) g.stats.counters++;
        g.stats.time = ROUND_TIME - g.roundTime;
      }
      if (isOD(m.id) && !launched) {
        g.slowT = 0;
        g.timeScale = 1.0;
      }
      if (isOD(m.id)) {
        g.flashEl.style.background = 'radial-gradient(ellipse at center, rgba(255,230,180,0.25) 0%, rgba(255,200,120,0.55) 100%)';
        g.flashAmt = 0.45;
      }
      const actualDmg = isOverdrive && hadHpAbove30 ? Math.round(hpBeforeHit - d.hp) : Math.round(dmg);
      g.popup(hitPos, actualDmg.toString(), big >= 0.6 ? 'pop-big' : 'pop-dmg');
      if (label) g.popup(new THREE.Vector3(hitPos.x, hitPos.y + 1.4, hitPos.z), label, 'pop-crit');
      else if (isOverdrive && hadHpAbove30) g.popup(new THREE.Vector3(hitPos.x, hitPos.y + 1.4, hitPos.z), '💥 OVERDRIVE IMPACT!', 'pop-crit');
      if (a.isPlayer && g.combo >= 3) g.popup(new THREE.Vector3(a.pos.x, 6.3, a.pos.y), `${g.combo} HIT COMBO`, 'pop-info');
    }

    // ------------------------------------------------------------------ HEAD RIP
    // An Overdrive that lands on a HEAD target does not just hurt: it tears the opponent's head clean off. The
    // helmet is launched away with the momentum of the blow and the neck is left as a stump with torn, sparking
    // cables hanging out of it. It is a finisher, so it ends the round on the spot.
    // Hanya memenggal dan membunuh langsung jika nyawa lawan sudah sisa 30% atau kurang!
    if ((a.isPlayer || a.robot.isZeus) && aim === AIM_HEAD && isOD(m.id) && g.phase === 'fight' && !d.decapitated && !hadHpAbove30) {
      g.ripVictim = d;
      d.decapitated = true;
      d.hp = 0;
      d.poise = 0;
      g.decap.pop(d.robot, away, d.scale, g.fx);
      g.startCine('rip', hitPos, away); // four angles: the cut, the head in flight, the sparking stump, the fall-out
      g.fx.flash(hitPos, 9, 0xffffff, 0.3);
      g.fx.ring(hitPos.x, hitPos.z, 0x9fe6ff, 12, 0.7, hitPos.y);
      g.fx.spark(hitPos, 28, 15, 0x9fe6ff, dirAD, 1.3, 0.9, 10);
      g.popup(new THREE.Vector3(d.pos.x, 7.4 * d.scale, d.pos.y), 'HEAD RIP!', 'pop-crit');
      g.popup(hitPos, 'KEPALA TERPENTAL!', 'pop-big');
      g.slowT = g.noSlowMoNormal ? 0 : 0.22;
      g.slowScale = 0.72;
      g.flashAmt = 0.8;
      g.flashEl.style.background = 'radial-gradient(ellipse at center, rgba(255,255,255,0.1) 20%, rgba(150,230,255,0.75) 100%)';
      g.freeze = 0.025;
      g.trauma = 0.85;
      g.camPush += 0.55;
      g.camBump = 0.45;
      g.fovKick = -6;
      g.hype = 1;
      g.sfx.hit(1);
      g.sfx.screech(1); // steel joints tearing apart
      g.sfx.guardBreak();
      g.sfx.crackle(1);
      g.sfx.ko();
      g.crowdRoar(1, 4.6);
    }

    if (d.hp <= 0) g.knockout(d, a);
  }

export function knockout(g: Game, d: Fighter, a: Fighter) {
    const away = new THREE.Vector2(d.pos.x - a.pos.x, d.pos.y - a.pos.y);
    if (away.lengthSq() < 1e-4) away.set(Math.sin(a.yaw), Math.cos(a.yaw));
    away.normalize();
    const sideL = away.x * Math.cos(d.yaw) - away.y * Math.sin(d.yaw);
    const koSide = Math.abs(sideL) > 0.15 ? (sideL > 0 ? 1 : -1) : (d.hitSign || 1);
    d.riseDir = koSide;
    if (d.state !== 'air') {
      d.airSpin = koSide * 1.35;
      g.ragdollKick(d, 0.95, koSide);
    }
    d.state = 'ko';
    d.move = null;
    d.blocking = false;
    d.fallT = 0;
    d.fallS.set(0);
    d.canvasSlammed = false;
    d.vy = Math.max(d.vy, 9);
    d.bounced = false;
    d.kb.copy(away).multiplyScalar(Math.max(d.kb.length(), 8));
    g.slowT = 0.95;
    g.slowScale = 0.32;
    g.freeze = 0.16;
    g.trauma = 0.85;
    g.fovKick = -6;
    g.flashAmt = 1;
    g.flashEl.style.background = 'radial-gradient(ellipse at center, rgba(255,255,255,0.35) 0%, rgba(255,255,255,0.6) 100%)';
    g.sfx.ko();
    g.sfx.say('K O!');
    g.endRound(a, 'ko');
    // a decapitation deserves its own card
    if (d.decapitated) g.showBanner('K.O.!', d.isPlayer ? 'KEPALAMU TERPENTAL!' : `${g.def.name} KEHILANGAN KEPALA`, 'ko', 3.8);
    g.fx.spark(new THREE.Vector3(d.pos.x, 3.5 * d.scale, d.pos.y), 26, 12, 0xffaa40, undefined, 1.4, 1.0, 12);
    g.fx.ring(d.pos.x, d.pos.y, 0xffffff, 14, 0.9);
  }

  // ------------------------------------------------------------ animation
