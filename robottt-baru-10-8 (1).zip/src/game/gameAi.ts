import * as THREE from 'three';
import type { Game } from './Game';
import {

  MOVES,

  panjerAiRate, PANJER_AI_STAM,

  ringCfg,

  isOD,
  type Fighter, type Move, type MoveId, type Plan,
  defenceAgainst,
} from './gameData';

export function makeAi(_g: Game) {
    return {
      cool: 0.45,
      combo: 0,
      strafeDir: 1,
      strafeT: 0,
      blockT: 0,
      reactT: -1,
      reactAct: '' as '' | 'block' | 'side' | 'back' | 'parry',
      habit: { jab: 0, cross: 0, hook: 0, upper: 0, slam: 0, bolt: 0, windmill: 0, skyhook: 0, grab: 0, counter: 0 } as Record<MoveId, number>,
      defStreak: 0,
      defT: 0,
      punishT: 0,
      punishSeq: -1,
      queued: null as MoveId | null,
      queuedT: 0,
      pressure: true,
      moodT: 2.5,
      lastId: '' as MoveId | '',

      plan: 'pressure' as Plan,
      planT: 0,

      scout: { time: 0, atk: 0, block: 0, dodge: 0, whiff: 0, rush: 0, taken: 0 },
      cond: 0,
      condId: '' as MoveId | '',
      holdOD: 0,
      zeusComboOD: false,
      zeusODStep: 0,
      panjerCd: 4,
    };
  }

export function strat(g: Game) {
    return g.iq >= 1;
  }

export function scoutPlayer(g: Game, dt: number) {
    const s = g.ai.scout;
    const p = g.foeOf(g.enemy);
    s.time += dt;
    if (p.blocking) s.block += dt;
    if (p.dodgeT > 0) s.dodge += dt * 3;
    if (p.speed > 6 && p.pos.distanceTo(g.enemy.pos) < 7) s.rush += dt;

    const k = Math.exp(-dt / 8);
    s.atk *= k;
    s.block *= k;
    s.dodge *= k;
    s.whiff *= k;
    s.rush *= k;
    s.taken *= k;
  }

export function updatePlan(g: Game, dt: number) {
    const ai = g.ai;
    ai.planT += dt;
    if (ai.planT < 0.85) return;
    const e = g.enemy;
    const p = g.foeOf(e);
    const s = ai.scout;
    const eHp = e.hp / e.maxHp;
    const pHp = p.hp / p.maxHp;
    const obs = Math.max(1, s.time);
    const aggr = s.atk / obs;
    const turtle = s.block / obs;
    const edgeP = Math.hypot(p.pos.x, p.pos.y);

    let plan: Plan = ai.plan;
    if (eHp < 0.22 && e.stam < 25) plan = 'recover';
    else if (pHp < 0.35 || p.stam < 25 || p.state === 'stagger') plan = 'finish';
    else if (edgeP > ringCfg.bound - 5.2) plan = 'trap';
    else if (aggr > 0.95) plan = 'counter';
    else if (turtle > 0.3 || aggr < 0.45) plan = 'pressure';
    else plan = Math.random() < 0.68 ? 'pressure' : 'counter';

    if (plan !== ai.plan) {
      ai.plan = plan;
      ai.planT = 0;
      ai.cond = 0;
      ai.pressure = plan === 'pressure' || plan === 'finish' || plan === 'trap';
      ai.moodT = 3.2;
    }
  }

export function planRange(g: Game, scale: number) {
    switch (g.ai.plan) {
      case 'pressure':
      case 'finish':
        return 2.85 * scale;
      case 'trap':
        return 3.05 * scale;
      case 'counter':
        return 3.65 * scale;
      case 'scout':
        return 3.5 * scale;
      case 'recover':
        return 5.4 * scale;
      default:
        return 6.2 * scale;
    }
  }

export function aiDefended(g: Game, kind: 'block' | 'dodge', seq: number) {
    const ai = g.ai;
    const e = g.enemy;
    const foe = g.foeOf(e);
    const dist = e.pos.distanceTo(foe.pos);
    ai.punishSeq = seq;
    ai.defStreak = Math.min(6, ai.defStreak + 1);
    ai.defT = 2.4;
    e.counterT = Math.max(e.counterT, 2.2);
    e.dodgeWinT = Math.max(e.dodgeWinT, 1.2);
    e.counterCd = 0;
    const p = Math.min(0.99, Math.max(0.88, g.def.punish) * (kind === 'dodge' ? 1.08 : 1.02));
    if (Math.random() < p) {
      ai.punishT = (kind === 'dodge' ? 0.95 : 0.85) * (1 + Math.max(0, g.iq - 1) * 0.05);
      ai.cool = 0;
      ai.blockT = kind === 'block' ? 0.06 : 0;
      ai.queued = dist > 3.7 * e.scale ? 'counter' : Math.random() < 0.55 ? 'counter' : Math.random() < 0.78 ? 'hook' : 'upper';
      ai.queuedT = 0.95;
    }
  }

export function enemyReact(g: Game, m: Move) {
    const e = g.enemy;
    const ai = g.ai;
    const def = g.def;
    ai.habit[m.id] = Math.min(8, ai.habit[m.id] + 1);
    ai.scout.atk += 1;
    const isZeusAI = e.robot.isZeus;
    const iq = Math.max(2, isZeusAI ? g.iq * 2 : g.iq);
    const sq = Math.sqrt(iq);
    if (e.dodgeT > 0 || ai.reactT >= 0) return;
    if (e.state !== 'idle') {

      const bail = e.state === 'attack' && !!e.move && (e.tellT > 0 || e.impacted || e.moveT < e.move.strikeAt * 0.85) && !isOD(e.move.id);
      if (!bail || Math.random() > Math.min(0.99, (isZeusAI ? 0.92 : 0.78) + iq * 0.05)) return;
      e.state = 'idle';
      e.move = null;
      e.tellT = 0;
      e.queued = null;
      e.runStrike = false;
      e.ippoStrike = false;
      ai.combo = 0;
    }
    const foe = g.foeOf(e);
    const d = foe.pos.distanceTo(e.pos);
    if (d > (m.reach + m.step * 0.5) * foe.scale + 3.4) return;

    const fatigue = isZeusAI ? 1 : Math.max(0.68, 1 - ai.defStreak * (0.06 / sq));
    const hab = 1 + Math.min(0.85, (ai.habit[m.id] - 1) * 0.18 * def.adapt);
    const cap = isZeusAI ? 0.995 : iq >= 10 ? 0.992 : iq >= 3 ? 0.98 : g.ultra ? 0.96 : 0.94;
    const baseReact = Math.max(0.86, def.react);
    const p = Math.min(cap, (isZeusAI ? Math.max(0.96, baseReact) : baseReact) * hab * fatigue);
    if (Math.random() > p) return;

    let act: 'block' | 'side' | 'back' | 'parry' = defenceAgainst(m.id, isZeusAI ? Math.max(0.72, def.dodge) : Math.max(0.58, def.dodge));
    const roll = Math.random();
    if (m.id === 'grab') {
      act = roll < 0.35 ? 'parry' : roll < 0.7 ? 'side' : 'back';
    } else if (roll < (isZeusAI ? 0.28 : 0.22) && e.counterCd <= 0 && d <= 4.6 * e.scale) {
      act = 'parry';
    } else if (roll < 0.56 && e.stam > 30) {
      act = 'block';
    } else if (act === 'block' && roll < 0.78 && e.dodgeCd <= 0) {
      act = Math.random() < 0.65 ? 'side' : 'back';
    }
    ai.reactAct = act;

    const rt = (isZeusAI ? 0.06 : 0.08) + Math.random() * 0.04 + (1 - baseReact) * 0.05;
    ai.reactT = Math.max(isZeusAI ? 0.05 : 0.065, rt / Math.pow(iq, 0.42));
  }

export function pickAiMove(g: Game, e: Fighter, chain: MoveId | null, dist: number): MoveId {
    const ai = g.ai;
    const pl = g.foeOf(e);
    const isZeusAI = e.robot.isZeus;

    if (isZeusAI && e.meter >= 100) {
      if (!chain) {

        ai.zeusComboOD = true;
        ai.zeusODStep = 0;
        ai.combo = 3 + Math.floor(Math.random() * 2);
        e.glowBoost = 1.35;
        g.popup(new THREE.Vector3(e.pos.x, 6.4 * e.scale, e.pos.y), '⚡ ZEUS COMBO OVERDRIVE!', 'pop-big');
        g.sfx.ready();

        const starter: MoveId = dist > 3.8 * e.scale ? 'counter' : Math.random() < 0.6 ? 'jab' : 'cross';
        ai.lastId = starter;
        return starter;
      } else if (ai.zeusComboOD) {
        ai.zeusODStep++;

        if (ai.combo > 1 && pl.state !== 'stagger' && pl.state !== 'air') {

          if (pl.blocking || pl.ippo) {
            if (dist <= 3.3 * e.scale && Math.random() < 0.35) return 'grab';
            return Math.random() < 0.6 ? 'upper' : 'hook';
          }
          if (dist > 3.8 * e.scale) {
            return Math.random() < 0.6 ? 'counter' : 'cross';
          }
          const zSeq: Partial<Record<MoveId, MoveId[]>> = {
            jab: ['cross', 'hook', 'counter'],
            cross: ['hook', 'upper', 'counter'],
            hook: ['upper', 'cross', 'counter'],
            upper: ['hook', 'cross', 'counter'],
            counter: ['hook', 'upper', 'cross'],
          };
          const nextOpts = zSeq[chain] || ['cross', 'hook', 'upper'];
          const nextPunch = nextOpts[Math.floor(Math.random() * nextOpts.length)];
          ai.lastId = nextPunch;
          return nextPunch;
        }

        e.meter = 0;
        ai.zeusComboOD = false;
        ai.holdOD = 0;
        e.glowBoost = 2.0;
        const odRoll = Math.random();
        const finisher: MoveId =
          odRoll < 0.38
            ? 'windmill'
            : odRoll < 0.70 && dist <= 4.3 * e.scale
              ? 'skyhook'
              : dist > 4.0 * e.scale || odRoll < 0.88
                ? 'bolt'
                : 'slam';
        ai.lastId = finisher;
        return finisher;
      }
    }

    if (g.def.slam && e.meter >= 100 && ai.combo <= 1) {
      if (g.strat && !e.robot.isZeus) {
        const cornered = Math.hypot(pl.pos.x, pl.pos.y) > ringCfg.bound - 4.0;
        const open = pl.state === 'stagger' || pl.state === 'air' || pl.tauntT > 0 || (pl.state === 'attack' && !pl.impacted);
        const kill = pl.hp / pl.maxHp < 0.38 || pl.stam < 32;
        if (!(open || kill || (cornered && ai.plan !== 'scout')) && ai.holdOD < 5.5) {
          return dist > 3.9 * e.scale ? 'counter' : 'cross';
        }
      }
      e.meter = 0;
      ai.holdOD = 0;
      const odRoll = Math.random();
      if (odRoll < 0.35) return 'windmill';
      if (odRoll < 0.65 && dist <= 4.3 * e.scale) return 'skyhook';
      return dist > 4.0 * e.scale || odRoll < 0.85 ? 'bolt' : 'slam';
    }
    if (chain) {

      if (pl.blocking || pl.ippo) {
        if (dist <= 3.3 * e.scale && Math.random() < 0.42) return 'grab';
        if (Math.random() < 0.45) return 'upper';
      }
      if (dist > 3.8 * e.scale) {
        return Math.random() < 0.55 ? 'counter' : 'cross';
      }
      const seq: Partial<Record<MoveId, MoveId[]>> = {
        jab: ['cross', 'hook', 'upper', 'counter'],
        cross: ['hook', 'upper', 'jab', 'counter'],
        hook: ['upper', 'cross', 'counter', 'jab'],
        upper: ['hook', 'cross', 'counter', 'jab'],
        counter: ['hook', 'upper', 'jab'],
      };
      const opts = seq[chain];
      if (opts) return opts[Math.floor(Math.random() * opts.length)];
    }

    if (g.strat && !chain) {
      const s = ai.scout;
      const obs = Math.max(1, s.time);

      if (ai.cond >= 2) {
        ai.cond = 0;
        const breaker: MoveId =
          pl.blocking || pl.ippo || s.block / obs > 0.3
            ? dist <= 3.4 * e.scale
              ? 'grab'
              : 'counter'
            : Math.random() < 0.55
              ? 'upper'
              : 'hook';
        ai.lastId = breaker;
        return breaker;
      }

      let pick: MoveId | null = null;
      if (pl.ippo || (pl.blocking && dist <= 3.35 * e.scale && Math.random() < 0.65)) pick = 'grab';
      else if (pl.stam < 32) pick = Math.random() < 0.5 ? 'counter' : 'cross';
      else if (pl.sprinting || pl.speed > 7.5) pick = Math.random() < 0.6 ? 'upper' : 'counter';
      else if (s.dodge / obs > 0.38 || pl.dodgeT > 0) pick = 'hook';
      else if (s.block / obs > 0.38 || pl.blocking) pick = Math.random() < 0.55 ? 'grab' : 'upper';
      else if (dist > 3.9 * e.scale) pick = Math.random() < 0.55 ? 'counter' : 'cross';
      if (pick && pick !== ai.lastId) {
        ai.lastId = pick;
        ai.cond = 0;
        return pick;
      }

      const roll = Math.random();
      const setup: MoveId = roll < 0.36 ? 'jab' : roll < 0.68 ? 'cross' : roll < 0.86 ? 'hook' : 'counter';
      ai.condId = setup;
      ai.cond++;
      ai.lastId = setup;
      return setup;
    }

    const far = dist > 3.7 * e.scale;
    const choose = (): MoveId => {
      const roll = Math.random();
      if (far) return roll < 0.45 ? 'cross' : roll < 0.75 ? 'counter' : 'jab';
      return roll < 0.28 ? 'jab' : roll < 0.52 ? 'cross' : roll < 0.78 ? 'hook' : 'upper';
    };
    let id = choose();
    if (id === g.ai.lastId && Math.random() < 0.7) id = choose();
    return id;
  }

export function updateEnemyAI(g: Game, dt: number) {
    const e = g.enemy;
    const p = g.foeOf(e);
    const ai = g.ai;
    const def = g.def;
    e.wish.set(0, 0);
    ai.blockT -= dt;
    ai.cool -= dt;
    ai.punishT -= dt;
    ai.queuedT -= dt;
    ai.moodT -= dt;
    ai.defT -= dt;
    if (ai.defT <= 0) ai.defStreak = 0;
    for (const k of Object.keys(ai.habit) as MoveId[]) ai.habit[k] = Math.max(0, ai.habit[k] - dt * 0.18);
    e.blocking = false;
    e.rage = false;
    e.rageFlash = 0;
    const pDown = p.state === 'down' || p.state === 'ko';

    if (g.strat) {
      g.scoutPlayer(dt);
      g.updatePlan(dt);
      ai.holdOD += dt;
    }

    if (e.robot.isZeus && g.phase === 'fight') {

      e.meter = Math.min(100, e.meter + dt * 10);
    }

    if (ai.moodT <= 0) {
      ai.pressure = e.robot.isZeus || Math.random() < 0.48 + def.aggro * 0.48;
      ai.moodT = 2.4 + Math.random() * 2.8;
    }

    const dist = e.pos.distanceTo(p.pos);

    if (p.state === 'attack' && p.move && !p.impacted && ai.reactT < 0 && e.dodgeT <= 0 && ai.punishSeq !== p.moveSeq) {
      if (dist <= (p.move.reach + 2.1) * p.scale) {
        g.enemyReact(p.move);
      }
    }

    if (e.state === 'attack' && e.move && e.impacted && !e.hitConfirmed && e.whiffT > 0) {
      ai.combo = 0;
      return;
    }
    if (e.state === 'attack' && e.move && ai.combo > 0 && e.impacted && g.canCancel(e) && !pDown && p.state !== 'air') {
      const zChainP = ai.zeusComboOD ? 1.0 : e.robot.isZeus ? 0.95 : (ai.pressure ? 0.8 : 0.65);
      if (e.hitConfirmed || (dist <= 4.5 * e.scale && Math.random() < zChainP)) {
        g.startMove(e, g.pickAiMove(e, e.move.id, dist), true);
        ai.combo--;
        if (ai.combo <= 0) ai.cool = (e.robot.isZeus ? 0.38 + Math.random() * 0.22 : Math.max(0.42, def.rest * (0.85 + Math.random() * 0.45)));
        return;
      }
    }

    if (e.state === 'idle' && e.dodgeT > 0 && e.dodgeT < e.dodgeDur * 0.45 && (ai.punishT > 0 || ai.queued) && !pDown && dist <= 4.6 * e.scale) {
      e.dodgeT = 0;
      const counterId: MoveId = ai.queued ?? (dist > 3.7 * e.scale ? 'counter' : Math.random() < 0.45 ? 'hook' : Math.random() < 0.75 ? 'upper' : 'cross');
      ai.queued = null;
      ai.punishT = 0;
      ai.combo = 1 + Math.floor(Math.random() * Math.max(2, def.combo - 1));
      g.startMove(e, counterId, true);
      return;
    }

    if (e.state !== 'idle' || e.dodgeT > 0) return;

    if (e.softT > 0.28 && ai.blockT <= 0 && Math.random() < dt * 14) ai.blockT = 0.35;

    if (p.state === 'attack' && p.move && p.impacted && !p.hitConfirmed && ai.punishSeq !== p.moveSeq) {
      ai.punishSeq = p.moveSeq;
      ai.scout.whiff += 1;
      ai.scout.atk += 1;
      if (Math.random() < Math.min(0.98, def.punish + 0.15)) {
        ai.punishT = 0.75;
        ai.cool = 0;
        ai.blockT = 0;
        ai.reactT = -1;
      }
    }

    const f = g.toward(e, p);
    const r = new THREE.Vector2(-f.y, f.x);

    if (ai.reactT >= 0) {
      ai.reactT -= dt;
      if (ai.reactT < 0) {

        const toCenter = new THREE.Vector2(-e.pos.x, -e.pos.y);
        let slipSign = Math.random() < 0.5 ? 1 : -1;
        if (Math.hypot(e.pos.x, e.pos.y) > ringCfg.bound - 4.2 && toCenter.lengthSq() > 0.01) {
          slipSign = Math.sign(r.dot(toCenter)) || slipSign;
        } else if (p.state === 'attack' && p.move) {
          const pArm = g.armOf(p, p.move);
          slipSign = pArm === 0 ? -1 : 1;
        }
        const side = r.clone().multiplyScalar(slipSign);

        const act = ai.reactAct === 'block' && e.stam < 25 && e.dodgeCd <= 0 ? 'side' : ai.reactAct;

        if (act === 'parry') {
          e.counterCd = 0;
          e.counterT = 2.2;
          e.dodgeWinT = 1.2;
          ai.punishSeq = p.moveSeq;
          ai.punishT = 0.95;
          ai.cool = 0;
          ai.blockT = 0;
          g.startMove(e, 'counter', true);
        } else if (act === 'block') {
          ai.blockT = 0.42 + Math.random() * 0.24;
          e.counterT = 2.0;
          ai.punishT = 0.95;
          ai.queued = dist > 3.6 * e.scale ? 'counter' : Math.random() < 0.55 ? 'counter' : 'hook';
          ai.queuedT = 0.95;
        } else if (act === 'side') {
          if (g.startDodge(e, side, 'side')) {
            if (p.state === 'attack' && p.move) {
              e.dodgeFor = p.moveSeq;
              ai.punishSeq = p.moveSeq;
            }
            e.counterT = 2.2;
            e.dodgeWinT = 1.2;
            ai.punishT = 0.95;
            ai.cool = 0;
            ai.blockT = 0;
            ai.queued = dist > 3.7 * e.scale ? 'counter' : Math.random() < 0.55 ? 'counter' : Math.random() < 0.78 ? 'hook' : 'upper';
            ai.queuedT = 0.95;
          } else {
            ai.blockT = 0.4;
          }
        } else if (act === 'back') {
          if (g.startDodge(e, f.clone().multiplyScalar(-1).addScaledVector(side, 0.38).normalize(), 'back')) {
            if (p.state === 'attack' && p.move) {
              e.dodgeFor = p.moveSeq;
              ai.punishSeq = p.moveSeq;
            }
            e.counterT = 2.2;
            e.dodgeWinT = 1.2;
            ai.punishT = 0.95;
            ai.cool = 0;
            ai.blockT = 0;
            ai.queued = Math.random() < 0.72 ? 'counter' : 'cross';
            ai.queuedT = 0.95;
          } else {
            ai.blockT = 0.4;
          }
        }
        ai.reactAct = '';
      }
    }

    if (ai.blockT > 0) {
      if (p.state !== 'attack' && ai.punishT > 0) {
        ai.blockT = 0;
      } else if (e.stam < 34 && e.dodgeCd <= 0) {
        ai.blockT = 0;
        const escSide = r.clone().multiplyScalar(ai.strafeDir);
        if (g.startDodge(e, escSide, 'side')) {
          ai.punishT = 0.7;
          ai.queued = 'hook';
          ai.queuedT = 0.75;
          return;
        }
      }
    }
    e.blocking = ai.blockT > 0 && e.stam > 0;

    const isZeusAI = e.robot.isZeus;
    const sp = def.speed * 1.25 * (e.blocking ? 0.48 : 1) * (e.rage ? 1.18 : 1) * (isZeusAI ? 0.90 : 1);

    if (ai.queued && ai.queuedT > 0 && !e.blocking && !pDown) {
      const qReach = (MOVES[ai.queued].reach + 0.6) * e.scale;
      if (dist <= qReach) {
        const id = ai.queued;
        ai.queued = null;
        ai.combo = 1 + Math.floor(Math.random() * Math.max(2, def.combo - 1));
        g.startMove(e, id, true);
        return;
      }
    } else if (ai.queuedT <= 0) {
      ai.queued = null;
    }

    ai.strafeT -= dt;
    if (ai.strafeT < 0) {
      ai.strafeDir = Math.random() < 0.5 ? 1 : -1;
      ai.strafeT = 0.45 + Math.random() * 0.95;
    }
    const edge = Math.hypot(e.pos.x, e.pos.y);
    const toC = new THREE.Vector2(-e.pos.x, -e.pos.y);
    if (edge > ringCfg.bound - 3.4 && toC.lengthSq() > 0.01) {
      toC.normalize();
      const sgn = Math.sign(r.dot(toC)) || 1;
      ai.strafeDir = sgn;
    }

    if (g.strat && (ai.plan === 'trap' || ai.plan === 'pressure' || ai.plan === 'finish') && p.pos.lengthSq() > 0.01) {
      const outward = p.pos.clone().normalize();
      ai.strafeDir = Math.sign(r.dot(outward)) || ai.strafeDir;
      e.wish.addScaledVector(outward, sp * 0.38);
    }
    const ideal = g.strat ? g.planRange(e.scale) : (ai.pressure ? 3.0 : 3.6) * e.scale;
    if (pDown) {
      if (dist > 7.5) e.wish.addScaledVector(f, sp * 0.6);
      else if (dist < 5.5) e.wish.addScaledVector(f, -sp * 0.5);
    } else if (dist > ideal + 0.25) e.wish.addScaledVector(f, sp * 1.08);
    else if (dist < ideal - 0.75 && ai.cool > 0.25) e.wish.addScaledVector(f, -sp * 0.65);
    e.wish.addScaledVector(r, ai.strafeDir * sp * (ai.pressure ? 0.38 : 0.55));
    if (edge > ringCfg.bound - 2.6 && toC.lengthSq() > 0.01) {
      const k = Math.min(1, (edge - (ringCfg.bound - 2.6)) / 2.4);
      e.wish.addScaledVector(toC.clone().normalize(), sp * 0.85 * k);
    }

    const zRush = e.robot.isZeus ? 4.8 : 2.6;
    const minRushDist = (e.robot.isZeus ? 4.2 : 5.2) * e.scale;
    if (dist > minRushDist && !pDown && e.dodgeCd <= 0 && Math.random() < dt * (ai.pressure ? zRush : 1.4)) {
      if (g.startDodge(e, f.clone(), 'fwd')) {
        ai.queued = Math.random() < 0.55 ? 'counter' : 'cross';
        ai.queuedT = 0.75;
        return;
      }
    }

    if (!ai.pressure && dist < 3.2 * e.scale && ai.cool > 0.18 && e.dodgeCd <= 0 && Math.random() < dt * 0.65 * def.punish) {
      if (g.startDodge(e, f.clone().multiplyScalar(-1), 'back')) {
        ai.punishT = 0.75;
        ai.queued = 'counter';
        ai.queuedT = 0.8;
        return;
      }
    }

    const reachNow = 4.1 * e.scale;
    const canAtk = !pDown && (p.state !== 'air' || (def.react > 0.5 && Math.random() < 0.65));
    const punishing = ai.punishT > 0 && !e.blocking && canAtk;

    if (punishing) {
      if (dist <= reachNow + 0.5 * e.scale) {
        const roll = Math.random();
        const id: MoveId =
          p.blocking || p.ippo
            ? dist <= 3.3 * e.scale
              ? 'grab'
              : 'upper'
            : dist > 3.7 * e.scale
              ? 'counter'
              : roll < 0.32
                ? 'counter'
                : roll < 0.65
                  ? 'hook'
                  : roll < 0.88
                    ? 'upper'
                    : 'cross';
        g.startMove(e, id, true);
        ai.combo = 1 + Math.floor(Math.random() * Math.max(2, def.combo));
        ai.punishT = 0;
        ai.cool = def.rest * 0.45 * (0.6 + Math.random() * 0.5);
        return;
      }
      if (dist < 8.5 && e.dodgeCd <= 0) {
        if (g.startDodge(e, f.clone(), 'fwd')) {
          ai.queued = Math.random() < 0.6 ? 'counter' : 'cross';
          ai.queuedT = 0.8;
          ai.punishT = 0;
          return;
        }
      }
    }

    if (g.strat && !pDown) {
      const pl = ai.plan;
      if (pl === 'recover' && dist < 4.5 * e.scale && e.stam < 30) {
        if (e.dodgeCd <= 0 && Math.random() < dt * 3.5) {
          g.startDodge(e, f.clone().multiplyScalar(-1), 'back');
          ai.queued = 'counter';
          ai.queuedT = 0.75;
        } else if (ai.blockT <= 0) {
          ai.blockT = 0.35;
        }
        return;
      }
      if (pl === 'counter' && dist < 3.4 * e.scale && e.dodgeCd <= 0 && ai.cool > 0.14 && Math.random() < dt * 2.4) {
        if (g.startDodge(e, f.clone().multiplyScalar(-1), 'back')) {
          ai.punishT = 0.8;
          ai.queued = 'counter';
          ai.queuedT = 0.85;
          return;
        }
      }
    }

    if (ai.panjerCd > 0) ai.panjerCd = Math.max(0, ai.panjerCd - dt);
    if (
      ai.cool <= 0 &&
      !e.panjerId &&
      ai.panjerCd <= 0 &&
      !pDown &&
      !e.blocking &&
      canAtk &&
      dist <= reachNow &&
      e.stam > PANJER_AI_STAM &&
      Math.random() < dt * panjerAiRate(def.react, p.poise < p.poiseMax * 0.45 || p.stam < 35 || p.hp <= p.maxHp * 0.3)
    ) {
      const loadId: MoveId = dist > 3.9 * e.scale ? 'cross' : Math.random() < 0.55 ? 'hook' : 'upper';
      g.beginPanjer(e, loadId, null);
      return;
    }

    if (ai.cool <= 0 && dist <= reachNow && !e.blocking && canAtk) {

      if ((p.blocking || p.ippo) && p.state === 'idle' && Math.random() < 0.52 + def.react * 0.35) {
        const breaker: MoveId = dist <= 3.35 * e.scale && Math.random() < 0.72 ? 'grab' : 'upper';
        g.startMove(e, breaker);
        ai.combo = breaker === 'upper' ? 2 : 0;
        ai.cool = def.rest * (0.55 + Math.random() * 0.5);
        return;
      }
      if (ai.combo <= 0) ai.combo = e.robot.isZeus ? (3 + Math.floor(Math.random() * 3)) : (2 + Math.floor(Math.random() * def.combo));
      const id = g.pickAiMove(e, null, dist);
      ai.lastId = id;
      g.startMove(e, id);
      ai.combo--;
      const rest = def.rest * (ai.pressure ? 0.38 : 0.72);
      ai.cool = ai.combo > 0 ? (e.robot.isZeus ? 0.05 + Math.random() * 0.04 : 0.06 + Math.random() * 0.06) : (e.robot.isZeus ? 0.38 + Math.random() * 0.22 : Math.max(0.45, rest * (0.85 + Math.random() * 0.45)));

      if (ai.combo <= 0) {
        if (e.dodgeCd <= 0 && Math.random() < 0.42) {
          const exitSide = r.clone().multiplyScalar(ai.strafeDir);
          g.startDodge(e, exitSide, 'side');
        } else if (Math.random() < 0.78) {
          ai.blockT = 0.35 + Math.random() * 0.25;
        }
      }
    }
  }
