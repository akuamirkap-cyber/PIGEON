import * as THREE from 'three';
import type { Game } from './Game';
import {

  MOVES, TELL, TELL_CHAIN,
  ALI_SPEED,

  PANJER_DMG, PANJER_KEYS, PANJER_AUTO_ORDER, TANK_POP_CD, PANJER_LOADABLE,
  panjerCharge, panjerLoaded, panjerShot, PANJER_AI_CD_MIN, PANJER_AI_CD_MAX,

  JAB_CHAIN_WIN, jabChainSpeed,
  AIM_HEAD, AIM_BODY, AIM_MIX, AIM_DROP, AIM_HEAD_LIFT,

  FINISHER_METER, COMBO_SCRIPT, COMBO_STEP_WIN, COMBO_BREAK_CD, comboCanFinish,
  STAR_DRIFT, STAR_QUEUE_WIN,
  starAutoStep, starShouldGuard,
  DODGE_WIN, DODGE_WIN_SPD, DODGE_CANCEL_AT, DODGE_CFG, dodgeAffordable, dodgeStaminaAfter,
  gasAtkMul, WHIFF_TAIL, whiffRecovery, whiffGates, canBailOut,
  STAM_SCALE,
  ringCfg,
  PACE, RUN_SPEED, IPPO_FWD, IPPO_SIDE, IPPO_BACK, WALK_FWD, WALK_BACK, WALK_SIDE,

  FREESTYLE, getupFoot,
  wrapAngle, isOD,
  type Fighter, type Move, type MoveId, type Pose,
  savePanjerMode, JAB_CHAIN_MAX,
} from './gameData';

export function beginPanjer(g: Game, f: Fighter, id: MoveId, key: string | null) {
    if (g.phase !== 'fight' || g.paused) return;
    if (f.state === 'legend' || f.state === 'legendHit' || f.state === 'ko') return;
    f.panjerId = id;
    f.panjerKey = key;
    f.panjerHold = 0;
    f.panjerReady = false;
    f.panjerSince = performance.now();
    f.pkTick = 0;
  }

export function firePanjer(g: Game, f: Fighter) {
    const id = f.panjerId;

    const held = f.panjerSince > 0 ? Math.max(f.panjerHold, (performance.now() - f.panjerSince) / 1000) : f.panjerHold;
    const shot = panjerShot(held);
    f.clearPanjer();
    if (!id || g.phase !== 'fight' || g.paused) return;
    f.panjerNext = id && PANJER_LOADABLE.includes(id) ? shot.dmgMul : 0;
    if (f.isPlayer) {
      g.tryAttack(f, id);
    } else {

      g.startMove(f, id);
      g.ai.panjerCd = PANJER_AI_CD_MIN + Math.random() * (PANJER_AI_CD_MAX - PANJER_AI_CD_MIN);
      g.ai.combo = 0;
      g.ai.cool = g.def.rest * (0.7 + Math.random() * 0.5);
      g.ai.lastId = id;
    }
  }

export function panjerReady(g: Game, f: Fighter) {
    const arm = f.panjerId ? g.armOf(f, MOVES[f.panjerId]) : 0;
    const fist = f.robot.fists[arm === 1 ? 1 : 0];
    fist.localToWorld(g.aimTmp.set(0, 0, 0));
    if (f.isPlayer) {
      g.popup(new THREE.Vector3(f.pos.x, 7.0 * f.scale, f.pos.y), '💪 PANJER SIAP!', 'pop-crit');
      g.sfx.ready();
      g.fx.ring(f.pos.x, f.pos.y, 0xffd34a, 3.2, 0.32, 0.1);
    } else {

      g.popup(new THREE.Vector3(f.pos.x, 7.2 * f.scale, f.pos.y), '⚠️ PANJER MUSUH!', 'pop-block');
      g.sfx.warn(true);
      g.fx.ring(f.pos.x, f.pos.y, 0xff5a3c, 3.2, 0.32, 0.1);
    }
    g.fx.spark(g.aimTmp, 10, 6, f.isPlayer ? 0xffd34a : 0xff5a3c, undefined, 1.4, 0.5, 8);
  }

export function panjerMax(g: Game, f: Fighter, id: MoveId) {
    f.panjerNext = PANJER_DMG;
    g.tryAttack(f, id);
  }

export function togglePanjerMode(g: Game) {
    g.setPanjerMode(!g.panjerMode);
  }

export function setPanjerMode(g: Game, on: boolean) {
    if (g.panjerMode === on) return;
    g.panjerMode = on;
    savePanjerMode(on);
    if (on) g.player?.clearPanjer();
    g.sfx.init();
    const p = g.player;
    if (on) {
      g.sfx.charge();
      g.sfx.ready();
      g.sfx.say('Panjer otomatis!');
    } else g.sfx.click();
    g.showBanner('PANJER OTOMATIS', on ? 'MAKS ×2 · TAHAN TOMBOLNYA BUAT SPAM PUKULAN' : 'KEMBALI KE CARA LAMA (TAHAN TOMBOLNYA BUAT NGISI KEKUATAN)', on ? 'fight' : 'round', 1.6);
    if (g.phase !== 'menu' && p) {
      g.flashAmt = Math.max(g.flashAmt, on ? 0.5 : 0.25);
      g.trauma = Math.min(0.5, g.trauma + (on ? 0.2 : 0.08));
      g.fx.ring(p.pos.x, p.pos.y, on ? 0xffd34a : 0x9fe3ff, on ? 7.5 : 4.5, 0.5, 0.1);
      g.fx.spark(new THREE.Vector3(p.pos.x, 4.6 * p.scale, p.pos.y), on ? 26 : 10, on ? 8.5 : 5, on ? 0xffd34a : 0x9fe3ff, undefined, 1.3, 0.5, 9);
      g.popup(new THREE.Vector3(p.pos.x, 7.0 * p.scale, p.pos.y), on ? '💪 PANJER OTOMATIS: MAKS!' : 'PANJER OTOMATIS MATI', on ? 'pop-crit' : 'pop-info');
    }
    g.emitHud(true);
  }

export function updatePanjer(g: Game, dt: number) {
    g.panjerStep(g.player, dt, true);
    g.panjerStep(g.enemy, dt, false);
    g.updateAutoFire();
  }

export function updateAutoFire(g: Game) {
    const p = g.player;
    if (!g.panjerMode || g.phase !== 'fight' || g.paused) return;
    if (p.state === 'ko' || p.state === 'down' || p.state === 'air' || p.state === 'legend' || p.state === 'legendHit') return;
    let code = p.autoFireKey && g.keys.has(p.autoFireKey) ? p.autoFireKey : null;
    if (!code) for (const c of PANJER_AUTO_ORDER) if (g.keys.has(c)) code = c;
    if (!code) return;
    p.autoFireKey = code;
    g.panjerMax(p, PANJER_KEYS[code]);
  }

export function panjerStep(g: Game, f: Fighter, dt: number, isPlayer: boolean) {
    if (f.tankPopT > 0) f.tankPopT = Math.max(0, f.tankPopT - dt);
    if (!f.panjerId) {
      f.panjerReady = false;
      return;
    }
    const dead =
      g.phase !== 'fight' ||
      g.paused ||
      f.blocking ||
      f.autoGuard ||
      f.state === 'ko' ||
      f.state === 'down' ||
      f.state === 'air' ||
      f.state === 'stagger' ||
      f.state === 'legend' ||
      f.state === 'legendHit';

    if (dead || (isPlayer && (!f.panjerKey || !g.keys.has(f.panjerKey)))) {
      f.clearPanjer();
      return;
    }
    f.panjerHold = f.panjerSince > 0 ? (performance.now() - f.panjerSince) / 1000 : f.panjerHold + dt;
    f.pkTick -= dt;
    if (f.pkTick <= 0) {
      f.pkTick = 0.15;
      if (f.isPlayer) g.sfx.tick(0.3 + 0.45 * panjerCharge(f.panjerHold));
    }
    if (!f.panjerReady && panjerLoaded(f.panjerHold)) {
      f.panjerReady = true;
      g.panjerReady(f);
    }
    if (!isPlayer && f.panjerReady) g.firePanjer(f);
  }

export function playerInput(g: Game) {
    const p = g.player;
    if (p.state === 'legend' || p.state === 'legendHit') return;
    const { fwd, lat } = g.dirKeys();
    const f = g.toward(p, g.enemy);
    const r = new THREE.Vector2(-f.y, f.x);
    p.wish.set(0, 0);
    p.blocking = false;
    p.sprinting = false;
    p.ippo = false;

    const wantBlockKey = g.keys.has('KeyG') && p.stam > 0;
    if (wantBlockKey && p.state === 'stagger' && p.stunT <= 0.45) {
      p.state = 'idle';
      p.stunT = 0;
      p.blocking = true;
    }
    if (wantBlockKey && p.state === 'attack' && p.move) {
      const incomingAtk = g.enemy.state === 'attack' && !!g.enemy.move && !g.enemy.impacted;
      if (p.impacted || (!isOD(p.move.id) && incomingAtk)) {
        p.state = 'idle';
        p.move = null;
        p.runStrike = false;
        p.ippoStrike = false;
        p.queued = null;
      }
    }

    p.autoGuard = false;

    if (g.starMode && !g.aliStyle && !wantBlockKey && starShouldGuard(p.state, p.dodgeT, p.tauntT, !!p.panjerId) && p.stam > 2) {
      p.autoGuard = true;
    }
    if (p.state === 'idle' && p.dodgeT <= 0) {
      p.blocking = wantBlockKey || p.autoGuard;
      const holdW = g.keys.has('KeyW') || g.keys.has('ArrowUp');

      if (p.stam <= 0.5) g.sprintLock = true;
      else if (p.stam > 25) g.sprintLock = false;
      const runKey = g.keys.has('KeyF');
      const moving = fwd !== 0 || lat !== 0;

      const ippoOn = g.keys.has('KeyE') && p.stam > 2;
      p.ippo = ippoOn;
      if (ippoOn) p.blocking = true;
      const wantRun = !p.blocking && moving && !g.sprintLock && (runKey || (g.runLatch && holdW && fwd > 0));
      const isZeusPlayer = p.robot.isZeus;
      const zeusSpeedMul = isZeusPlayer ? 0.90 : 1.0;
      const rageSpd = (p.rage ? 1.15 : 1) * zeusSpeedMul;

      const walkMul = (0.88 + 0.16 * g.fwMul) * (g.aliStyle ? ALI_SPEED : 1);
      const runMul = 0.85 + 0.25 * g.fwMul;
      if (ippoOn) {
        const im = walkMul * rageSpd;
        const dist = p.pos.distanceTo(g.enemy.pos);
        let fw = fwd;

        if (fwd === 0 && lat === 0 && dist > 3.5 * g.enemy.scale && g.enemy.state !== 'ko' && g.enemy.state !== 'down') fw = 0.85;
        p.wish.addScaledVector(f, fw * (fw > 0 ? IPPO_FWD : IPPO_BACK) * im).addScaledVector(r, lat * IPPO_SIDE * im);
        const lim = IPPO_FWD * im;
        if (p.wish.length() > lim) p.wish.setLength(lim);
      } else if (g.starMode && !moving && !p.blocking && g.enemy.state !== 'ko' && g.enemy.state !== 'down') {

        const dist = p.pos.distanceTo(g.enemy.pos);
        const step = starAutoStep(dist);
        const im = walkMul * rageSpd * STAR_DRIFT;
        if (step !== 0) p.wish.addScaledVector(f, step * im);

        const rad = Math.hypot(p.pos.x, p.pos.y);
        if (rad > ringCfg.bound - 3.4) {
          const inward = new THREE.Vector2(-p.pos.x, -p.pos.y).normalize();
          p.wish.addScaledVector(inward, im * 0.55);
        }
      } else if (wantRun) {
        p.sprinting = true;

        const rs = RUN_SPEED * runMul * rageSpd;
        p.wish.addScaledVector(f, fwd * (fwd > 0 ? rs : rs * 0.5)).addScaledVector(r, lat * rs * 0.72);
        if (p.wish.length() > rs) p.wish.setLength(rs);
      } else {
        const k = (p.blocking ? 0.5 : 1) * walkMul * rageSpd;
        p.wish.addScaledVector(f, fwd * (fwd > 0 ? WALK_FWD : WALK_BACK) * k).addScaledVector(r, lat * WALK_SIDE * k);
        const lim = (fwd > 0 ? WALK_FWD : fwd < 0 ? WALK_BACK : WALK_SIDE) * k;
        if (p.wish.length() > lim) p.wish.setLength(lim);
      }
    } else if (p.state === 'attack') {
      const isZeusPlayer = p.robot.isZeus;
      const zeusSpeedMul = isZeusPlayer ? 0.90 : 1.0;
      const rageSpd = (p.rage ? 1.15 : 1) * zeusSpeedMul;
      if (p.runStrike) {
        p.wish.addScaledVector(f, 3.4 * rageSpd);
      } else {
        const atkDrive = p.impacted ? 3.8 : 2.8;
        const driveSpeed = atkDrive * rageSpd;
        p.wish.addScaledVector(f, fwd * driveSpeed).addScaledVector(r, lat * driveSpeed * 1.05);
      }
    }
  }

export function toggleRage(g: Game) {
    if (g.phase !== 'fight' || g.paused) return;
    const p = g.player;
    if (p.state === 'ko' || p.state === 'down') return;
    p.rage = !p.rage;
    p.rageFlash = 1.1;
    g.sfx.init();
    if (p.rage) {
      p.glowBoost = Math.max(p.glowBoost, 3.4);
      g.sfx.charge();
      g.sfx.crackle(0.85);
      g.sfx.pyro(0.45);
      g.sfx.say('Rage mode!');
      g.trauma = Math.min(0.25, g.trauma + 0.08);
      g.fovKick = -1.5;
      g.fx.ring(p.pos.x, p.pos.y, 0xff3b2a, 6.8, 0.52, 0.12);
      g.fx.ring(p.pos.x, p.pos.y, 0xffb030, 4.0, 0.36, 0.08);
      g.fx.spark(new THREE.Vector3(p.pos.x, 3.8 * p.scale, p.pos.y), 40, 9.5, 0xff4a2a, new THREE.Vector3(0, 0.6, 0), 1.25, 0.55, 8);
      g.popup(new THREE.Vector3(p.pos.x, 6.8, p.pos.y), '🔥 RAGE MODE: AGRESIF!', 'pop-crit');
      g.crowdRoar(0.55, 1.4);
    } else {
      g.sfx.click();
      g.popup(new THREE.Vector3(p.pos.x, 6.5, p.pos.y), 'RAGE MATI', 'pop-info');
    }
    g.emitHud(true);
  }

export function playerDodge(g: Game) {
    const p = g.player;
    if (g.phase !== 'fight') return;
    const e = g.enemy;
    const incomingDeadly = e.state === 'attack' && !!e.move && !e.impacted;

    if (p.state === 'attack' && p.move && (p.impacted || !isOD(p.move.id) || incomingDeadly) && canBailOut(p.whiffT, incomingDeadly)) {
      p.state = 'idle';
      p.move = null;
      p.runStrike = false;
      p.ippoStrike = false;
      p.queued = null;
    }

    if (p.dodgeT > 0 && p.dodgeT <= p.dodgeDur * 0.42) {
      p.dodgeT = 0;
      p.dodgeCd = 0;
    }
    if (incomingDeadly) {
      p.dodgeCd = 0;
      p.stam = Math.max(p.stam, 10);
      if (p.dodgeT > 0) p.dodgeT = 0;
    }
    if (p.state === 'stagger' && p.stunT <= 0.48) {
      p.state = 'idle';
      p.stunT = 0;
    } else if (p.state !== 'idle' || p.dodgeT > 0) {
      return;
    }
    const { fwd, lat } = g.dirKeys();
    const f = g.toward(p, g.enemy);
    const r = new THREE.Vector2(-f.y, f.x);
    const d = new THREE.Vector2();
    const dist = p.pos.distanceTo(e.pos);
    const sweetDist = 3.25 * (p.scale + e.scale) * 0.5;
    let speedMul = 1.0;

    if (fwd === 0 && lat === 0) {

      if (incomingDeadly && e.move) {

        const slipSide = e.move.arm === 0 ? 1 : e.move.arm === 1 ? -1 : p.aliSign;
        const autoFwd = THREE.MathUtils.clamp((dist - sweetDist) * 0.55, -0.32, 0.72);
        d.addScaledVector(f, autoFwd).addScaledVector(r, slipSide).normalize();
        speedMul = THREE.MathUtils.clamp(0.75 + Math.abs(dist - sweetDist) * 0.15, 0.72, 1.05);
      } else if (dist > sweetDist + 0.45 && e.state !== 'ko' && e.state !== 'down') {

        const closeRatio = THREE.MathUtils.clamp((dist - sweetDist) / 2.4, 0.35, 1.0);
        d.addScaledVector(f, 0.94).addScaledVector(r, p.aliSign * 0.34).normalize();
        speedMul = 0.55 + 0.45 * closeRatio;
      } else {

        const pocketFwd = THREE.MathUtils.clamp((dist - sweetDist) * 0.6, -0.1, 0.35);
        d.addScaledVector(f, pocketFwd).addScaledVector(r, p.aliSign * 0.95).normalize();
        speedMul = 0.48;
      }
    } else if (fwd === 0 && lat !== 0) {

      const autoFwd = THREE.MathUtils.clamp((dist - sweetDist) * 0.45, -0.15, 0.55);
      d.addScaledVector(f, autoFwd).addScaledVector(r, lat).normalize();
    } else {
      d.addScaledVector(f, fwd).addScaledVector(r, lat).normalize();
    }

    if (!g.startDodge(p, d, 'evade')) {
      if (p.stam < 10) g.popup(new THREE.Vector3(p.pos.x, 5.8, p.pos.y), 'TENAGA HABIS', 'pop-info');
      return;
    }
    p.dodgeSpeed *= speedMul;

    const m = e.move;
    if (e.state === 'attack' && m && !e.impacted) {
      p.dodgeFor = e.moveSeq;
    }
  }

export function taunt(g: Game, f: Fighter, style = 0) {
    if (f.state !== 'idle' || f.dodgeT > 0 || f.tauntT > 0) return false;
    const fs = FREESTYLE[THREE.MathUtils.clamp(Math.round(style), 0, FREESTYLE.length - 1)];
    f.tauntStyle = fs.id;
    f.tauntT = fs.dur;
    f.tauntDur = fs.dur;
    f.blocking = false;
    f.ippo = false;
    f.glowBoost = Math.max(f.glowBoost, fs.glow);
    g.sfx.servo();
    g.sfx.say(f.isPlayer ? fs.say : g.tauntBack(fs));
    if (g.phase === 'fight' || g.phase === 'intro' || g.phase === 'walk') {
      g.popup(new THREE.Vector3(f.pos.x, f.y + 6.6 * f.scale, f.pos.y), f.isPlayer ? fs.tag : g.tauntBack(fs).toUpperCase(), 'pop-crit');
      if (g.phase === 'fight') g.crowdRoar(0.4 + fs.dur * 0.12, 1.4 + fs.dur * 0.35);
    }
    return true;
  }

export function tauntBack(_g: Game, fs: { id: number }) {
    switch (fs.id) {
      case 1:
        return 'Bow down!';
      case 2:
        return 'Missing me already?';
      case 4:
        return 'This is power.';
      case 5:
        return 'Hear that?';
      case 6:
        return 'Engine hot.';
      case 7:
        return 'Diagnostics complete.';
      case 8:
        return 'Feel the core.';
      case 9:
        return 'Spin cycle.';
      case 10:
        return 'Scrap metal.';
      default:
        return 'Is that all?';
    }
  }

export function fsCue(g: Game, f: Fighter, s: string) {
    const yaw = f.yaw;
    const side = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
    const at = (x: number, y: number, z: number) => new THREE.Vector3(f.pos.x + side.x * x, y * f.scale, f.pos.y + side.z * x + z);
    switch (s) {
      case 'beat':
        g.tauntBeat(f);
        break;
      case 'raise':
        g.tauntRaise(f);
        break;
      case 'clash':
        g.tauntClash(f);
        break;
      case 'chin': {

        g.sfx.servo();
        g.sfx.pyro(0.22);
        f.glowBoost = Math.max(f.glowBoost, 3.4);
        g.fx.spark(at(0, 0.25, 0), 10, 3.6, 0x9aa8c0, undefined, 1.0, 0.4, 5);
        if (f.isPlayer) g.fovKick = -1.5;
        break;
      }
      case 'roll': {

        g.sfx.servo();
        g.sfx.whoosh(0.28);
        g.fx.spark(at(0.5, 0.22, 0), 5, 2.4, 0xbfc9d8, new THREE.Vector3(0, 1, 0), 0.8, 0.35, 4);
        g.fx.spark(at(-0.5, 0.22, 0), 5, 2.4, 0xbfc9d8, new THREE.Vector3(0, 1, 0), 0.8, 0.35, 4);
        if (f.isPlayer) g.trauma = Math.min(1, g.trauma + 0.05);
        break;
      }
      case 'beckon': {

        g.sfx.tick();
        for (const sx of [1, -1]) g.fx.spark(at(sx * 0.85, 4.5, 0.5), 5, 2.6, 0x9fe6ff, new THREE.Vector3(0, 0.4, 0.6), 0.5, 0.3, 4);
        break;
      }
      case 'flex': {

        g.sfx.crackle(0.7);
        f.glowBoost = Math.max(f.glowBoost, 3.2);
        for (const sx of [1, -1]) {
          const p = at(sx * 1.15, 4.7, -0.1);
          g.fx.spark(p, 10, 4.5, 0x8fd0ff, new THREE.Vector3(0, 0.2, 0), 0.6, 0.4, 10);
        }
        if (f.isPlayer) g.fovKick = -2;
        break;
      }
      case 'clap': {

        g.sfx.hit(0.5);
        g.sfx.crackle(0.8);
        f.glowBoost = Math.max(f.glowBoost, 3.4);
        g.fx.spark(at(0, 4.6, 0.7), 22, 7, 0xffd27a, new THREE.Vector3(0, 0.3, 0.4), 1.1, 0.5, 12);
        if (f.isPlayer) {
          g.trauma = Math.min(1, g.trauma + 0.3);
          g.camBump = Math.max(g.camBump, 0.22);
          g.fovKick = -4;
        }
        break;
      }
      case 'rev': {

        g.sfx.pyro(0.3);
        g.sfx.crackle(0.5);
        f.glowBoost = Math.max(f.glowBoost, 3);
        for (const sx of [1, -1]) g.fx.spark(at(sx * 0.7, 2.6, -0.2), 9, 4, 0xffb45a, new THREE.Vector3(0, -0.3, 0), 0.7, 0.4, 6);
        if (f.isPlayer) g.trauma = Math.min(1, g.trauma + 0.12);
        break;
      }
      case 'check': {

        g.sfx.tick(1);
        g.sfx.servo();
        const side = s === 'check' ? (f.hand === 1 ? 1 : -1) : 1;
        g.fx.spark(at(side * 1.1, 4.4, 0.6), 6, 3, 0xbfe6ff, new THREE.Vector3(0, 0.3, 0.5), 0.5, 0.3, 4);
        break;
      }
      case 'charge': {

        g.sfx.charge();
        g.sfx.crackle(0.65);
        f.glowBoost = Math.max(f.glowBoost, 3.2);
        g.fx.spark(at(0, 3.6, 0.35), 12, 4.5, 0x8fd0ff, new THREE.Vector3(0, 0.2, 0.8), 0.7, 0.4, 8);
        if (f.isPlayer) g.trauma = Math.min(1, g.trauma + 0.06);
        break;
      }
      case 'spin': {

        g.sfx.servo();
        g.sfx.screech(0.4);
        for (const sx of [1, -1]) g.fx.spark(at(sx * 0.7, 3.9, 1.0), 7, 3.2, 0xffd27a, new THREE.Vector3(0, 0, 0.8), 0.6, 0.3, 5);
        f.glowBoost = Math.max(f.glowBoost, 2.2);
        break;
      }
      case 'roar': {

        g.sfx.hit(0.4);
        g.sfx.cheer(1);
        g.sfx.pyro(0.5);
        g.fx.spark(at(0, 0.3, 0), 18, 4.5, 0x9aa8c0, undefined, 1.2, 0.5, 7);
        g.crowdRoar(0.8, 2.2);
        break;
      }
    }
  }

export function tauntRaise(g: Game, f: Fighter) {
    g.sfx.hit(0.45);
    g.sfx.pyro(0.55);
    g.sfx.cheer(0.9);
    f.glowBoost = Math.max(f.glowBoost, 3);
    const up = new THREE.Vector3(0, 1, 0);

    for (const s of [1, -1]) {
      g.fx.spark(new THREE.Vector3(f.pos.x + s * 1.1 * f.scale, 8.4 * f.scale, f.pos.y), 16, 7, 0xffd27a, up, 0.5, 0.8, 11);
    }
    g.fx.spark(new THREE.Vector3(f.pos.x, 0.25, f.pos.y), 22, 5, 0x9aa8c0, undefined, 1.4, 0.6, 7);
    if (f.isPlayer) {
      g.trauma = Math.min(1, g.trauma + 0.25);
      g.camBump = Math.max(g.camBump, 0.2);
      g.fovKick = -3;
    }
  }

export function tauntBeat(g: Game, f: Fighter) {
    g.sfx.hit(0.42);
    g.sfx.crackle(0.6);
    f.glowBoost = Math.max(f.glowBoost, 2.8);
    const fwd = new THREE.Vector3(Math.sin(f.yaw), 0, Math.cos(f.yaw));
    const c = new THREE.Vector3(f.pos.x + fwd.x * 0.7 * f.scale, 5.1 * f.scale, f.pos.y + fwd.z * 0.7 * f.scale);
    g.fx.spark(c, 20, 7, 0xffd27a, new THREE.Vector3(fwd.x, 0.5, fwd.z), 1.3, 0.5, 14);
    g.fx.spark(c, 8, 4, 0xffffff, new THREE.Vector3(0, 1, 0), 0.6, 0.3, 6);
    g.trauma = Math.min(1, g.trauma + (f.isPlayer ? 0.14 : 0.08));
    if (f.isPlayer) g.camBump = Math.max(g.camBump, 0.12);
  }

export function tauntClash(g: Game, f: Fighter) {
    g.sfx.hit(0.55);
    g.sfx.crackle(0.75);
    g.sfx.tick(0.8);
    f.glowBoost = Math.max(f.glowBoost, 3.2);
    const fwd = new THREE.Vector3(Math.sin(f.yaw), 0, Math.cos(f.yaw));
    const c = new THREE.Vector3(f.pos.x + fwd.x * 2.1 * f.scale, 5.25 * f.scale, f.pos.y + fwd.z * 2.1 * f.scale);

    const side = new THREE.Vector3(Math.cos(f.yaw), 0, -Math.sin(f.yaw));
    g.fx.spark(c, 16, 7.5, 0xffd27a, new THREE.Vector3(side.x, 0.9, side.z), 1.2, 0.5, 12);
    g.fx.spark(c, 16, 7.5, 0xffd27a, new THREE.Vector3(-side.x, 0.9, -side.z), 1.2, 0.5, 12);
    g.fx.spark(c, 10, 5, 0xffffff, new THREE.Vector3(0, 1, 0), 0.7, 0.35, 8);
    g.trauma = Math.min(1, g.trauma + (f.isPlayer ? 0.16 : 0.1));
    if (f.isPlayer) {
      g.camBump = Math.max(g.camBump, 0.14);
      g.fovKick = -2;
    }
  }

export function setHand(g: Game, h: 0 | 1) {
    const p = g.player;
    if (p.hand === h) return;
    p.hand = h;
    p.handT = 0.7;
    g.sfx.tick(0.55);
    p.robot.root.updateMatrixWorld(true);
    const v = new THREE.Vector3();
    p.robot.shoulders[h].getWorldPosition(v);
    g.fx.spark(v, 5, 3, h === 1 ? 0xffb060 : 0x8fd0ff, new THREE.Vector3(0, 0.4, 0), 0.8, 0.3, 3);
  }

export function armOf(_g: Game, f: Fighter, m: Move): 0 | 1 | 2 {
    if (m.arm === 2 || !f.isPlayer) return m.arm;
    return f.hand;
  }

export function punchStepOf(g: Game, f: Fighter, o: Fighter) {
    const none = { foot: -1, z: 0, x: 0, dur: 0.18, seq: -1, lift: undefined as number | undefined };
    const m = f.move;

    if (f.state === 'down') {

      const g = getupFoot(f.riseU, f.riseSteps);
      if (!g) return none;
      f.riseSteps = g.steps;

      return { foot: g.foot, z: g.z, x: g.x, dur: g.dur, seq: g.seq, lift: g.lift };
    }
    if (f.state === 'stagger') {

      const foot = f.comboTaken % 2 === 0 ? 1 : 0;
      return {
        foot,
        z: -0.36 - Math.min(0.26, f.kb.length() * 0.028),
        x: foot === 0 ? -0.07 : 0.07,
        dur: 0.21,
        seq: 5000 + f.comboTaken + f.moveSeq * 10,
        lift: 0.18,
      };
    }
    if (f.state !== 'attack' || !m) return none;
    if (f.moveT < m.strikeAt * 0.4) return none;
    const foot = g.armOf(f, m) === 1 ? 1 : 0;
    const avg = Math.max(0.001, (f.scale + o.scale) * 0.5);
    const gap = f.pos.distanceTo(o.pos) / avg;
    const far = THREE.MathUtils.clamp((gap - 1.15) / 1.9, 0, 1);

    let fwd = 0;
    let lat = 0;
    if (f.isPlayer) {
      const keys = g.dirKeys();
      fwd = keys.fwd;
      lat = keys.lat;
    } else if (f.wish.lengthSq() > 0.05) {
      const toO = g.toward(f, o);
      const dot = f.wish.dot(toO);
      const cross = f.wish.x * -toO.y + f.wish.y * toO.x;
      fwd = dot > 0.35 ? 1 : dot < -0.35 ? -1 : 0;
      lat = cross > 0.35 ? 1 : cross < -0.35 ? -1 : 0;
    }

    if (gap < 1.15 && fwd === 0 && lat === 0 && !f.runStrike && !isOD(m.id)) return none;

    let z: number;
    if (fwd > 0) {

      z = (0.28 + far * 0.36) * (0.85 + m.power * 0.45) * (f.runStrike ? 1.35 : 1);
    } else if (fwd < 0) {

      z = -0.32 - far * 0.22;
    } else {

      z = (0.16 + far * 0.42) * (0.8 + m.power * 0.45) * (f.runStrike ? 1.25 : 1);
    }

    let x: number;
    if (lat < 0) {

      x = (foot === 0 ? -0.38 : -0.26) - far * 0.12;
    } else if (lat > 0) {

      x = (foot === 1 ? 0.38 : 0.26) + far * 0.12;
    } else {

      x = (foot === 0 ? -0.06 : 0.08) * (0.5 + far * 0.8);
    }

    const dur = THREE.MathUtils.clamp(((m.impact - m.strikeAt * 0.4) * PACE * f.tscale) / Math.max(1, f.atkSpd), 0.12, 0.34);
    const lift = 0.26 + Math.min(0.14, far * 0.16);
    return { foot, z, x, dur, seq: f.moveSeq, lift };
  }

export function toggleAim(g: Game) {
    if (g.phase !== 'fight' || g.paused) return;
    const p = g.player;

    p.aimMode = ((p.aimMode + 1) % 3) as 0 | 1 | 2;
    p.aim = p.aimMode === AIM_BODY ? AIM_BODY : AIM_HEAD;
    p.mixN = 0;
    p.aimT = 0.9;
    const body = p.aimMode === AIM_BODY;
    const mix = p.aimMode === AIM_MIX;
    g.sfx.click();
    g.popup(new THREE.Vector3(p.pos.x, 6.6, p.pos.y), mix ? 'TARGET: REMIX' : body ? 'TARGET: DADA' : 'TARGET: KEPALA', 'pop-info');
    if (mix) {

      g.fx.ring(p.pos.x, p.pos.y, 0xc89bff, 2.8, 0.35, 0.09);
      g.fx.spark(new THREE.Vector3(p.pos.x, 5.3 * p.scale, p.pos.y), 10, 4, 0x9fe6ff, undefined, 1, 0.35, 3);
      g.fx.spark(new THREE.Vector3(p.pos.x, 3.5 * p.scale, p.pos.y), 10, 4, 0xffa050, undefined, 1, 0.35, 3);
      p.robot.root.updateMatrixWorld(true);
      const v = new THREE.Vector3();
      p.robot.chest.getWorldPosition(v);
      g.fx.flash(v, 1.3, 0xd0a8ff, 0.16);
      return;
    }
    g.fx.ring(p.pos.x, p.pos.y, body ? 0xff9a4a : 0x8fd0ff, 2.8, 0.35, 0.09);
    g.fx.spark(new THREE.Vector3(p.pos.x, (body ? 3.5 : 5.3) * p.scale, p.pos.y), 14, 4, body ? 0xffa050 : 0x9fe6ff, undefined, 1, 0.35, 3);
    p.robot.root.updateMatrixWorld(true);
    const v = new THREE.Vector3();
    p.robot.chest.getWorldPosition(v);
    g.fx.flash(v, 1.3, body ? 0xffb070 : 0x9fd6ff, 0.16);
  }

export function pickMixAim(g: Game, f: Fighter, id: MoveId): 0 | 1 {
    const tgt = g.foeOf(f);
    const chained = f.spamCount > 0;
    if (!chained) f.mixN = 0;
    const n = f.mixN++;
    if (isOD(id) || id === 'counter') return AIM_HEAD;
    const guardHigh = tgt.blocking || tgt.ippo;

    const pattern = guardHigh ? [AIM_BODY, AIM_BODY, AIM_HEAD, AIM_BODY, AIM_HEAD] : [AIM_HEAD, AIM_BODY, AIM_HEAD, AIM_HEAD, AIM_BODY];
    let aim = pattern[n % pattern.length] as 0 | 1;
    if (id === 'upper' && guardHigh) aim = AIM_BODY;
    if (Math.random() < 0.18) aim = aim === AIM_HEAD ? AIM_BODY : AIM_HEAD;
    if (tgt.stam < 25) aim = AIM_HEAD;
    return aim;
  }

export function aimY(_g: Game, f: Fighter, m: Move) {
    return f.aim === AIM_BODY ? Math.max(2.5, m.hitY - AIM_DROP) : m.hitY;
  }

export function markWhiff(g: Game, a: Fighter, m: Move) {
    if (a.state !== 'attack') return 0;

    if (a.isPlayer) {
      if (m.id === 'finisher') {

        g.popup(new THREE.Vector3(a.pos.x, 6.6, a.pos.y), 'MEMATIKAN MELESET!', 'pop-block');
      } else {
        g.breakNCombo('KOMBO MELESET!');
      }
    }
    const tail = whiffRecovery(m.impact, m.dur);
    a.whiffT = Math.max(a.whiffT, Math.min(WHIFF_TAIL, tail));
    return a.whiffT;
  }

export function aimPoint(g: Game, d: Fighter, aim: number, out: THREE.Vector3) {
    const eyes = d.robot.eyeOptics;
    if (aim === AIM_HEAD && eyes.length >= 2) {
      out.set(0, 0, 0);
      for (const e of eyes) out.add(e.getWorldPosition(g.eyeTmp));
      out.multiplyScalar(1 / eyes.length);
      return out;
    }
    d.robot.chest.getWorldPosition(out);
    out.y -= 0.22 * d.scale;
    return out;
  }

export function aimsLow(_g: Game, f: Fighter, m: Move) {
    return f.aim === AIM_BODY && m.id !== 'grab' && m.id !== 'slam';
  }

export function aimPose(g: Game, f: Fighter, m: Move, p: Pose): Pose {
    if (g.aimsLow(f, m)) {
      const pitch = m.id === 'upper' || m.id === 'skyhook' ? 0.3 : 0.5;
      return { sx: p.sx + pitch, sy: p.sy, sz: Math.min(1.2, p.sz + 0.06), ex: p.ex - 0.06 };
    }

    if (f.aim === AIM_HEAD && (m.kind === 'front' || m.kind === 'side')) return { sx: p.sx - AIM_HEAD_LIFT, sy: p.sy, sz: p.sz, ex: p.ex };
    return p;
  }

export function playerDash(g: Game, kind: 'fwd' | 'back' | 'side', sign: number) {
    const p = g.player;
    const e = g.enemy;

    if (kind === 'side' && p.dodgeT > 0) return;
    const incomingDeadly = e.state === 'attack' && !!e.move && !e.impacted;

    if (p.state === 'attack' && p.move && (p.impacted || !isOD(p.move.id) || incomingDeadly) && canBailOut(p.whiffT, incomingDeadly)) {
      p.state = 'idle';
      p.move = null;
      p.runStrike = false;
      p.ippoStrike = false;
      p.queued = null;
    }
    if (p.dodgeT > 0 && p.dodgeT <= p.dodgeDur * 0.42) {
      p.dodgeT = 0;
      p.dodgeCd = 0;
    }
    if (incomingDeadly) {
      p.dodgeCd = 0;
      p.stam = Math.max(p.stam, 8);
      if (p.dodgeT > 0) p.dodgeT = 0;
    }
    if (p.state !== 'idle' || p.dodgeT > 0) return;
    const f = g.toward(p, g.enemy);
    const r = new THREE.Vector2(-f.y, f.x);
    const d = new THREE.Vector2();
    if (kind === 'fwd') d.copy(f);
    else if (kind === 'back') d.copy(f).multiplyScalar(-1);
    else d.copy(r).multiplyScalar(sign);
    if (g.startDodge(p, d, kind) && incomingDeadly) {
      p.dodgeFor = e.moveSeq;
    }
  }

export function startDodge(g: Game, f: Fighter, dir: THREE.Vector2, kind: 'evade' | 'fwd' | 'back' | 'side' = 'evade') {
    if (f.state === 'legend' || f.state === 'legendHit') return false;

    const cfg = DODGE_CFG[kind];

    const cost = (f.isPlayer ? cfg.cost : cfg.cost / Math.pow(g.iq, 0.15)) * STAM_SCALE;

    const desperate = g.foeOf(f).state === 'attack' && !!(g.foeOf(f).move);
    if (f.dodgeCd > 0 || f.state !== 'idle' || !dodgeAffordable(f.stam, cost, desperate)) return false;
    f.dodgeT = cfg.dur;
    f.dodgeDur = cfg.dur;
    f.dodgeTail = 0.14;
    const rageBoost = f.isPlayer && f.rage ? 1.15 : 1;

    const fwBoost = f.isPlayer ? (kind === 'side' ? 1 + (g.fwMul - 1) * 0.04 : 1 + (g.fwMul - 1) * 0.05) : 1;
    f.dodgeSpeed = cfg.speed * fwBoost * rageBoost;

    f.dodgeInv = cfg.inv || (f.isPlayer && kind !== 'fwd') || (!f.isPlayer && g.iq >= 3);
    f.dodgeKind = kind;
    f.dodgeDir.copy(dir);
    f.aliSign = (f.aliSign > 0 ? -1 : 1);

    f.dodgeCd = cfg.cd * (f.isPlayer ? (f.rage ? 0.78 : 1) : Math.max(0.7, 1.6 / Math.sqrt(g.iq)));
    f.stam = dodgeStaminaAfter(f.stam, cost);
    f.blocking = false;
    g.sfx.dodge();

    g.fx.spark(new THREE.Vector3(f.pos.x, 0.12, f.pos.y), 8, 3.2, 0xd0d8e8, undefined, 0.65, 0.22, 2);
    return true;
  }

export function tryOverdrive(g: Game, p: Fighter) {
    if (p.state === 'legend' || p.state === 'legendHit') return;
    if (p.meter < 100) {
      g.popup(new THREE.Vector3(p.pos.x, 5.8, p.pos.y), `OVERDRIVE ${Math.floor(p.meter)}%`, 'pop-info');
      return;
    }
    if (p.state === 'stagger') {
      p.state = 'idle';
      p.stunT = 0;
      g.popup(new THREE.Vector3(p.pos.x, 6.8, p.pos.y), '⚡ OVERDRIVE REVERSAL!', 'pop-crit');
    }
    if (p.state === 'ko' || p.state === 'air' || p.state === 'down') return;
    if (p.state === 'attack' && p.move && isOD(p.move.id)) return;
    const fromDodge = p.dodgeT > 0 || p.dodgeWinT > 0 || p.counterT > 0;
    p.dodgeT = 0; // cancel dodge velocity so Overdrive lunges straight into the enemy!
    p.queued = null;
    p.state = 'idle';
    p.meter = 0;
    g.meterReadyShown = false;
    // THE OVERDRIVE BOOK — every press of R (meter full) runs to the next one of the three heavy finishes, so a
    // comeback is never the same shape twice: the lunging straight, the rising uppercut and the slam. (The
    // arm-spinning windmill is OUT of the book — "muter-muter tangan" reads as gimmicky, not as a real finisher.)
    const odMoves: MoveId[] = ['bolt', 'skyhook', 'slam'];
    const pick = odMoves[p.moveSeq % odMoves.length];
    g.odToggle = !g.odToggle;
    if (fromDodge) {
      p.dodgeWinT = Math.max(p.dodgeWinT, DODGE_WIN);
      p.counterT = Math.max(p.counterT, 2.0);
    }
    g.startMove(p, pick);
    p.invuln = Math.max(p.invuln, fromDodge ? 0.95 : 0.7); // invincible startup so Overdrive after a dodge is unstoppable!
    if (fromDodge || p.hp <= p.maxHp * 0.45) {
      p.winStrike = true;
      const atlasSpd = p.robot.isAtlas ? 1.19 : 1.0;
      p.atkSpd = Math.max(p.atkSpd, 1.24 * atlasSpd);
      g.popup(new THREE.Vector3(p.pos.x, 7.1, p.pos.y), '🔥 OVERDRIVE COMEBACK!', 'pop-crit');
    }
  }

  /**
   * Y — ALI STYLE. A stance toggle, not a buff: it changes how the fighter stands, floats and dances (see the ALI
   * STYLE block) and stays on until it is pressed off again. Available in every mode, on the PLAYER only — the
   * opponent keeps its own stance, so the style is something you do, not something that happens to you.
   */
export function toggleAliStyle(g: Game) {
    g.aliStyle = !g.aliStyle;
    const on = g.aliStyle;
    // THE ANSWER: a banner across the screen, the crowd, and a burst on the fighter — so whether the button did
    // anything is never a mystery again (an arms-only stance change was too quiet to read).
    g.showBanner(on ? '🦋 ALI STYLE' : 'GUARD TINGGI', on ? 'FLOAT LIKE A BUTTERFLY · ALI SHUFFLE ON' : 'STANCE NORMAL', on ? 'crit' : 'info', 1.6);
    g.sfx.init();
    g.sfx.ready();
    g.sfx.cheer(on ? 0.85 : 0.3);
    g.flashAmt = Math.max(g.flashAmt, on ? 0.2 : 0.1);
    const p = g.player;
    if (p && g.phase !== 'menu') {
      g.popup(new THREE.Vector3(p.pos.x, 7.0, p.pos.y), on ? '🦋 ALI STYLE — FLOAT!' : 'ALI STYLE OFF', on ? 'pop-crit' : 'pop-info');
      g.fx.ring(p.pos.x, p.pos.y, on ? 0x8ff0ff : 0xffd27a, on ? 5.2 : 3.4, 0.5, 0.1);
      g.fx.spark(new THREE.Vector3(p.pos.x, 1.1, p.pos.y), on ? 26 : 12, 6.5, on ? 0x8ff0ff : 0xffd27a, new THREE.Vector3(0, 1, 0), 1.2, 0.6, 9);
      g.trauma = Math.min(1, g.trauma + 0.12);
    }
    g.emitHud(true);
  }

  /**
   * N — THE COMBO BUTTON. Press once and the script (COMBO_SCRIPT: jab-jab-hook-hook-upper → the finisher) throws
   * itself, link by link, as fast as the swings can cancel into each other. It is deliberately NOT a free win: the
   * script only ever presses the same buttons H/J/K press by hand, the punches pay their own stamina, and the whole
   * thing dies the instant a link is blocked, slipped, stepped off or whiffed (see breakNCombo). A clean five is the
   * price of the finisher, and the finisher then pays half a meter for itself.
   */
export function startNCombo(g: Game) {
    // the script owns the body: a loaded fist never rides into the automatic combo (the load is spent, not banked)
    g.player.clearPanjer();
    const p = g.player;
    if (p.state === 'legend' || p.state === 'legendHit' || p.state === 'ko' || p.state === 'air' || p.state === 'down') return;
    if (g.nComboIdx >= 0) return; // already running: N is not a speed-up
    if (g.nComboCd > 0) {
      g.popup(new THREE.Vector3(p.pos.x, 5.8, p.pos.y), 'KOMBO BELUM SIAP', 'pop-info');
      return;
    }
    if (p.state === 'attack' && !g.canCancel(p)) return; // mid-swing: let the swing finish, then press again
    g.nComboIdx = 0;
    g.nComboT = 0;
    g.nComboWait = COMBO_STEP_WIN;
    g.nComboSeq = -1;
    g.popup(new THREE.Vector3(p.pos.x, 6.9, p.pos.y), '⭐ KOMBO! H-H-J-J-K', 'pop-crit');
    g.sfx.tick(0.85);
  }

  /** stop the script where it is. `msg` is only shown for a break the player should know about (see the hooks). */
export function breakNCombo(g: Game, msg = '') {
    if (g.nComboIdx < 0) return;
    const p = g.player;
    g.nComboIdx = -1;
    g.nComboCd = COMBO_BREAK_CD;
    g.nComboSeq = -1;
    if (msg) {
      g.popup(new THREE.Vector3(p.pos.x, 6.5, p.pos.y), msg, 'pop-block');
      g.sfx.warn(false);
    }
  }

  /**
   * One link of the N combo. It throws the link if the beat is free (or if the current swing can already be cancelled
   * into it, which is what makes the five read as one combination instead of five separate punches), and otherwise
   * waits for the next frame. Returns true only if THIS link actually went out.
   */
export function nComboStep(g: Game, p: Fighter, id: MoveId): boolean {
    if (id === 'finisher') {
      // THE FINISHER IS PAID FOR BEFORE IT IS THROWN (and it is NOT thrown if the combo cannot pay): the five links
      // have just banked the meter for it, so this is the check that makes "land the combo, earn the finisher" true.
      if (!comboCanFinish(p.meter, p.stam)) {
        g.breakNCombo(p.meter < FINISHER_METER ? `METER ${Math.round(p.meter)}/${FINISHER_METER} — TANPA MEMATIKAN` : 'TENAGA HABIS — TANPA MEMATIKAN');
        return false;
      }
      return g.tryFinisher(p);
    }
    if (p.state !== 'idle' && !(p.state === 'attack' && g.canCancel(p))) return false;
    if (p.state === 'idle' && p.dodgeT > 0) return false;
    if (whiffGates(p.whiffT)) return false; // over-committed: the tail has to play out before the next link
    if (p.stam < Math.min(MOVES[id].cost * STAM_SCALE, 4)) {
      g.breakNCombo('TENAGA HABIS — KOMBO PUTUS');
      return false;
    }
    if (p.state === 'attack') {
      // cancel the live swing straight into the next link (the same cancel window the game gives a hand-thrown combo)
      p.state = 'idle';
      p.move = null;
      p.runStrike = false;
      p.ippoStrike = false;
      p.queued = null;
    }
    const seq = p.moveSeq; // startMove bumps this — the one reading TS cannot narrow away for us after the call
    g.startMove(p, id);
    return p.moveSeq !== seq;
  }

  /** the script's own clock. Runs every frame of the fight, before the AI moves. */
export function updateNCombo(g: Game, dt: number) {
    if (g.nComboCd > 0) g.nComboCd = Math.max(0, g.nComboCd - dt);
    if (g.nComboIdx < 0) return;
    const p = g.player;
    if (g.phase !== 'fight' || g.paused) {
      g.nComboIdx = -1;
      return;
    }
    // HIT: the script dies with the fighter — being staggered, launched or put down ends the combination outright
    if (p.state === 'ko' || p.state === 'air' || p.state === 'down' || p.state === 'stagger') {
      g.breakNCombo('KOMBO PUTUS!');
      return;
    }
    g.nComboT += dt;
    g.nComboWait -= dt;
    if (g.nComboWait <= 0 || g.nComboT > COMBO_SCRIPT.length * COMBO_STEP_WIN + 2) {
      g.breakNCombo('KOMBO PUTUS');
      return;
    }
    const id = COMBO_SCRIPT[g.nComboIdx];
    // THE LINK WE JUST THREW IS STILL COMMITTED: wait for its cancel window (that window is what makes the five read
    // as ONE combination — and because the script tracks the swing by its sequence number, a JAB-JAB pair cancels
    // into itself exactly like two jabs thrown by hand, instead of waiting the first one out).
    if (g.nComboSeq >= 0 && p.moveSeq === g.nComboSeq && p.state === 'attack' && !g.canCancel(p)) return;
    if (!g.nComboStep(p, id)) return;
    g.nComboSeq = p.moveSeq;
    g.nComboIdx++;
    g.nComboWait = COMBO_STEP_WIN;
    if (g.nComboIdx >= COMBO_SCRIPT.length) {
      g.nComboIdx = -1; // the finisher is away: the script is done, and the meter is already paid
      g.nComboCd = COMBO_BREAK_CD;
    }
  }

  /**
   * PUKULAN MEMATIKAN — the finisher itself (see MOVES.finisher). The price is half an Overdrive meter plus a real
   * bite of the tank, and it is only ever reachable through a clean N combo. It cannot be blocked or stuffed (the
   * Overdrive family's startup invincibility), but it telegraphs for the longest beat in the book — so the answer to
   * it is to not be there, and the player who throws it into a slip has burned the meter for nothing.
   */
export function tryFinisher(g: Game, f: Fighter): boolean {
    if (f.state === 'legend' || f.state === 'legendHit') return false;
    if (f.state === 'ko' || f.state === 'air' || f.state === 'down' || f.state === 'stagger') return false;
    if (f.dodgeT > 0) return false;
    if (f.state === 'attack') {
      if (!g.canCancel(f)) return false;
      f.state = 'idle';
      f.move = null;
      f.queued = null;
    }
    if (!comboCanFinish(f.meter, f.stam)) {
      if (f.isPlayer) {
        g.popup(
          new THREE.Vector3(f.pos.x, 5.9, f.pos.y),
          f.meter < FINISHER_METER ? `METER ${Math.round(f.meter)}/${FINISHER_METER} — BELUM CUKUP` : 'TENAGA HABIS',
          'pop-info',
        );
      }
      return false;
    }
    const seq = f.moveSeq;
    f.meter = Math.max(0, f.meter - FINISHER_METER);
    g.meterReadyShown = false;
    g.startMove(f, 'finisher');
    f.invuln = Math.max(f.invuln, 0.6); // the family's startup: a finisher cannot be stuffed out of its own wind-up
    f.winStrike = false; // it is already the heaviest thing in the book — no dodge bonus on top of it
    return f.moveSeq !== seq;
  }

export function tryAttack(g: Game, f: Fighter, id: MoveId) {
    if (f.state === 'legend' || f.state === 'legendHit') return;
    const m = MOVES[id];
    if (f.isPlayer && f.state === 'stagger') {
      // RESPONSIF MEMBALAS PUKULAN SETELAH KENA PUKULAN:
      // Pemain bisa membalas secara instan setelah fase impak awal (stunT <= 0.48s) atau dengan Counter (L)!
      const canRetaliateNow = id === 'counter' || f.stunT <= 0.48;
      if (canRetaliateNow) {
        f.state = 'idle';
        f.stunT = 0;
        f.counterT = Math.max(f.counterT, 1.8);
        g.popup(new THREE.Vector3(f.pos.x, 6.8, f.pos.y), '⚡ BALAS PUKULAN!', 'pop-crit');
        g.startMove(f, id);
        return;
      } else {
        f.queued = id;
        f.queuedT = 0.55;
        return;
      }
    }
    if (f.state === 'stagger' || f.state === 'ko' || f.state === 'air' || f.state === 'down') return;
    const e = g.enemy;
    const incoming = f.isPlayer && e.state === 'attack' && !!e.move && !e.impacted;
    // Reactive L Counter-Attack: if an enemy attack is incoming OR you are countering out of a dodge, L is ALWAYS ready!
    if (id === 'counter' && f.isPlayer && (incoming || f.dodgeT > 0 || f.dodgeWinT > 0 || f.counterT > 0)) {
      f.counterCd = 0;
      f.stam = Math.max(f.stam, m.cost * STAM_SCALE + 2);
      if (f.state === 'attack' && f.move && !isOD(f.move.id)) {
        f.state = 'idle';
        f.move = null;
      }
      if (f.dodgeT > 0) {
        f.dodgeT = 0;
        f.invuln = Math.max(f.invuln, 0.42);
        f.dodgeWinT = Math.max(f.dodgeWinT, DODGE_WIN);
        f.counterT = Math.max(f.counterT, 1.8);
      }
      g.startMove(f, id);
      return;
    }
    // the counter stance cannot be spammed in neutral: it stays on a short cooldown after an empty swing
    if (id === 'counter' && f.isPlayer && f.counterCd > 0) {
      g.popup(new THREE.Vector3(f.pos.x, 5.8, f.pos.y), 'COUNTER BELUM SIAP', 'pop-info');
      return;
    }
    if (f.dodgeT > 0 && f.state === 'idle') {
      // DODGE ADVANTAGE: once enough of the dodge has played you may cancel out of it straight into an attack —
      // the strike comes out faster and lands harder, so whoever reads the exchange first owns it.
      const played = 1 - Math.max(0, f.dodgeT) / f.dodgeDur;
      if (played >= DODGE_CANCEL_AT || f.counterT > 0) {
        f.dodgeT = 0;
        f.invuln = Math.max(f.invuln, 0.25); // i-frames cover the start-up out of a dodge
        f.dodgeWinT = DODGE_WIN;
        g.startMove(f, id);
      } else {
        f.queued = id;
        f.queuedT = 0.35;
      }
      return;
    }
    if (f.state === 'attack') {
      if (f.move && g.canCancel(f) && f.stam > 0) g.startMove(f, id);
      else {
        f.queued = id;
        // STAR MODE assist #4: a tap during a swing is remembered longer (and still fires the instant it is legal),
        // so chaining combos at speed never feels like the input was dropped.
        f.queuedT = g.starMode && f.isPlayer ? STAR_QUEUE_WIN : 0.34;
      }
      return;
    }
    // OVER-COMMITMENT GATE: a punch thrown into empty air cannot be followed by another until the swing has played
    // out (the Overdrive is exempt — spending a full meter to cover a mistake is a legitimate escape).
    // PANJER OTOMATIS = the spam switch: inside it a missed punch no longer locks the next one out for WHIFF_TAIL
    // (the slow tail still plays — the body still has to come back — you are simply allowed to keep swinging), and
    // the empty-tank shout is throttled below so a held button cannot fire it sixty times a second.
    const spam = g.panjerMode && f.isPlayer;
    if (whiffGates(f.whiffT) && !isOD(id) && !spam) return;
    if (f.stam < Math.min(m.cost * STAM_SCALE, 4)) {
      if (f.isPlayer && f.tankPopT <= 0) {
        f.tankPopT = TANK_POP_CD;
        g.popup(new THREE.Vector3(f.pos.x, 5.8, f.pos.y), 'TENAGA HABIS', 'pop-info');
      }
      return;
    }
    g.startMove(f, id);
  }

  /** how long the enemy telegraphs a move: readable wind-up so you can see the shoulders load up */
export function tellFor(g: Game, id: MoveId, chain: boolean) {
    if (chain || (g.ai && g.ai.punishT > 0) || (g.enemy && g.enemy.dodgeWinT > 0)) return TELL_CHAIN;
    return TELL[id] * Math.max(0.45, 0.82 - g.def.react * 0.32) * (g.ultra ? 0.88 : 1);
  }

export function startMove(g: Game, f: Fighter, id: MoveId, chain = false) {
    if (f.state === 'legend' || f.state === 'legendHit') return;
    const m = MOVES[id];
    const foe = g.foeOf(f);
    if (id === 'counter') {
      if (f.isPlayer) {
        if (f.counterCd > 0) return; // guarded again here: a queued follow-up must not sneak past the cooldown
        f.counterCd = 0.65; // short anti-spam cooldown in neutral (reset to 0 on any dodge or incoming attack!)
      } else {
        f.counterCd = 0.45;
      }
      if (foe.state === 'attack' && foe.move && !foe.impacted) {
        f.parryFor = foe.moveSeq; // lock onto the opponent's active attack so Counter catches & parries it!
        f.invuln = Math.max(f.invuln, 0.45);
      }
    }
    // Natural non-monotonous attack flow: track rapid consecutive attacks and cycle through 4 biomechanical
    // punch variations (angle, head-slip, level-change, hip-torque), plus auto-flow lead/rear hand on rapid spam!
    const sinceLast = f.animT - f.lastAtkAt;
    f.lastAtkAt = f.animT;
    if (sinceLast < 0.95) {
      f.spamCount = Math.min(8, f.spamCount + 1);
    } else {
      f.spamCount = 0;
    }
    f.strikeVar = (f.strikeVar + 1 + (f.spamCount >= 2 && (f.moveSeq & 1) === 1 ? 1 : 0)) % 4;
    if (!isOD(id) && id !== 'grab' && id !== 'counter' && f.spamCount >= 2 && f.strikeVar % 2 === 1) {
      f.hand = (1 - f.hand) as 0 | 1;
    }

    // a punch thrown at (near) full speed while sprinting is a RUNNING PUNCH
    f.runStrike = (f.isPlayer ? f.sprinting && f.speed > 6.2 : f.speed > 7.5) && !isOD(id) && id !== 'grab' && id !== 'counter';
    if (f.runStrike && f.isPlayer) g.fovKick = 3;
    // DEMPSEY ROLL: a punch thrown out of a charged weave carries all of that stored momentum
    f.ippoStrike = f.isPlayer && f.rollCharge > 0.25 && !f.runStrike && !isOD(id) && id !== 'grab';
    // the AI picks a target intelligently: digs into the body to shred stamina when you block/peek-a-boo, hunts the head when you're open
    if (!f.isPlayer) {
      if (isOD(id)) {
        f.aim = AIM_HEAD; // Overdrive selalu mengincar kepala untuk Head Rip!
      } else {
        const tgt = g.foeOf(f);
        const wantBody = tgt.blocking || tgt.ippo || (tgt.stam < 42 && id !== 'upper');
        f.aim = Math.random() < (wantBody ? 0.72 : 0.28) ? AIM_BODY : AIM_HEAD;
      }
    } else if (f.aimMode === AIM_MIX && id !== 'grab' && id !== 'slam') {
      f.aim = g.pickMixAim(f, id);
    }
    f.strikeCharge = f.ippoStrike ? f.rollCharge : 0;
    // PANJER: the load that was on the button when it was let go rides on THIS swing — and only on a punch that
    // can be loaded, and only for one swing (it is consumed here, so an ordinary punch after it is ordinary
    // again). Anything else that reaches for the arm — an Overdrive, a throw, a scripted combo link — takes the
    // load away with it instead of inheriting it: a 2× Overdrive is not a thing this game hands out.
    if (PANJER_LOADABLE.includes(id)) {
      f.panjer = f.panjerNext > 1 ? f.panjerNext : 1; // a flick (×1) is just the ordinary punch
      f.panjerNext = 0;
    } else {
      f.panjer = 1;
      f.clearPanjer();
    }
    if (f.ippoStrike) {
      f.rollCharge = 0;
      g.fovKick = 2.5;
    }
    f.state = 'attack';
    f.move = m;
    f.moveSeq++;
    f.moveT = 0;
    // DODGE ADVANTAGE & RAGE MODE: a strike thrown out of a dodge or during Rage Mode comes out faster and lands harder
    if (!f.isPlayer) f.rage = false; // enemy is strictly forbidden from using Rage Mode
    const isReactiveCounter =
      id === 'counter' &&
      (f.dodgeWinT > 0 || f.counterT > 0 || (foe.state === 'attack' && !!foe.move && !foe.impacted));
    f.winStrike = (f.dodgeWinT > 0 || isReactiveCounter) && !isOD(id);
    const dodgeSpd = isReactiveCounter ? 1.48 : f.winStrike ? DODGE_WIN_SPD : 1;
    const rageSpd = f.isPlayer && f.rage ? 1.2 : 1;
    // THE JAB RHYTHM. The jab is the one punch that is MEANT to be doubled up, so it gets a real rhythm instead
    // of the general spam jitter: every jab thrown inside the chain window tightens the next one (up to +30 %),
    // which turns a flurry into an escalating piston — 1-1-1-1 — rather than a mush of equal taps. Any other
    // punch, or a pause, drops the chain back to zero.
    if (id === 'jab') f.jabChain = f.animT - f.lastJabAt < JAB_CHAIN_WIN ? Math.min(JAB_CHAIN_MAX, f.jabChain + 1) : 0;
    else if (f.animT - f.lastJabAt >= JAB_CHAIN_WIN) f.jabChain = 0;
    if (id === 'jab') f.lastJabAt = f.animT;
    const jabSpd = id === 'jab' ? jabChainSpeed(f.jabChain) : 1;
    // a jab also keeps a metronome-steady cadence: the rhythm jitter that keeps the big punches from looking
    // copy-pasted would read as sloppy on the one punch you are supposed to be able to repeat on beat
    const spamRhythm = id === 'jab' ? 1 : f.spamCount >= 2 ? 1 + ((f.strikeVar % 3) - 1) * 0.05 : 1;
    const atlasSpd = f.robot.isAtlas ? 1.19 : 1.0; // GERAKAN PUKULAN ATLAS LEBIH CEPAT 19 PERSEN
    // GASSED: hands slow down 8% below the gas line — the price of a flurry (or a dodge) you could not afford
    const gasMul = gasAtkMul(f.stam);
    f.atkSpd = dodgeSpd * rageSpd * spamRhythm * jabSpd * atlasSpd * gasMul;
    if (f.isPlayer) {
      const tgtYaw = Math.atan2(g.enemy.pos.x - f.pos.x, g.enemy.pos.y - f.pos.y);
      f.yaw += wrapAngle(tgtYaw - f.yaw) * (id === 'counter' || f.winStrike ? 0.9 : 0.6);
      if (id === 'counter' || f.winStrike) {
        f.vel.multiplyScalar(0.2); // plant the feet cleanly so the counter-attack fires on a razor-straight line!
      }
    }
    if (f.winStrike) {
      f.dodgeWinT = 0; // one dodge buys one heavy strike
      if (f.isPlayer) {
        g.popup(new THREE.Vector3(f.pos.x, 7.0, f.pos.y), 'DODGE STRIKE!', 'pop-crit');
        g.fx.ring(f.pos.x, f.pos.y, 0x7fe0ff, 4, 0.3, 0.09);
      } else if (g.phase === 'fight') {
        g.popup(new THREE.Vector3(f.pos.x, 6.8 * f.scale, f.pos.y), '⚡ SLIP COUNTER!', 'pop-crit');
        g.fx.ring(f.pos.x, f.pos.y, 0xff5a36, 3.8, 0.28, 0.08);
      }
    }
    // enemy attacks announce themselves: wind-up pose + indicator, then the strike
    f.tellT = 0;
    f.tellTotal = 0;
    if (!f.isPlayer && g.phase === 'fight') {
      const tt = g.tellFor(id, chain);
      f.tellT = tt;
      f.tellTotal = tt;
    }
    f.impacted = false;
    f.whooshed = false;
    f.hitConfirmed = false;
    f.attackDir.copy(g.toward(f, g.foeOf(f)));
    f.queued = null;
    f.blocking = false;
    f.stam = Math.max(0, f.stam - m.cost * STAM_SCALE);
    g.sfx.servo();
    if (isOD(id)) {
      g.sfx.charge();
      f.glowBoost = 3;
      g.sfx.say(id === 'finisher' ? 'Finisher' : 'Overdrive');
      g.fovKick = 3;
      if (id === 'finisher') {
        // the last word of the N combo: a two-tone charge (the two fists loading together) and the loudest call-out
        g.sfx.whoosh(1);
        g.sfx.crackle(0.5);
        if (g.phase === 'fight') {
          g.popup(
            new THREE.Vector3(f.pos.x, 7.0 * f.scale, f.pos.y),
            f.isPlayer ? '☠️ PUKULAN MEMATIKAN!' : '☠️ MEMATIKAN MUSUH!',
            'pop-crit',
          );
        }
      }
      if (id === 'windmill') {
        g.sfx.whoosh(0.8);
        if (g.phase === 'fight') {
          g.popup(
            new THREE.Vector3(f.pos.x, 6.8 * f.scale, f.pos.y),
            f.isPlayer ? '🌪️ FREESTYLE OVERDRIVE!' : '⚠️ OVERDRIVE FREESTYLE MUSUH!',
            'pop-crit',
          );
        }
      } else if (id === 'skyhook') {
        // the launcher: the charge whistle drops a note as he sinks, and the call-out says which one is coming
        g.sfx.whoosh(0.9);
        g.sfx.crackle(0.35);
        if (g.phase === 'fight') {
          g.popup(
            new THREE.Vector3(f.pos.x, 6.8 * f.scale, f.pos.y),
            f.isPlayer ? '☄️ OVERDRIVE UPPERCUT!' : '⚠️ OVERDRIVE UPPERCUT MUSUH!',
            'pop-crit',
          );
        }
      }
      // the director steps in for the charge: a short low hero angle before the strike lands
      if (f.isPlayer) g.startCine('od');
    }
    if (f.isPlayer) g.enemyReact(m);
  }

export function canCancel(_g: Game, f: Fighter) {
    const m = f.move;
    if (!m) return false;
    const baseAt = f.hitConfirmed && f.impacted && m.cancel < 90 ? Math.min(m.cancel, m.impact + 0.05) : m.cancel;
    const at = f.rage && m.cancel < 90 ? baseAt * 0.78 : baseAt;
    return f.moveT >= at;
  }

  // ------------------------------------------------------------ enemy AI (GENIUS TACTICAL BRAIN)
  // A hyper-intelligent, adaptive champion AI:
  //   - DEFENSIVE GENIUS: reads startup frames & mid-flight lunges, bails out of unsafe swings to slip/parry,
  //     slips outside the player's punching arm & away from the ropes, and escapes guard-breaks before stamina empties.
  //   - OFFENSIVE GENIUS: dodge-cancels slips directly into lightning-fast counter-punches, chains 3–5 hit combinations
  //     with mid-combo guard-breakers (throws, uppercuts, body shots, lunging counters), and cuts off the ring.
