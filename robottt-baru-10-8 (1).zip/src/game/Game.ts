import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { MeterPass, makeGradePass, SAT_STEPS, DEFAULT_SAT } from './grade';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  Robot, type RobotStyle, Trail, mount100PercentZeus, freestyleByKey,
  FREESTYLE, buildArena, type Arena, buildHangar, type Hangar, Effects, Decap, Sfx, type SfxProfile,
  newFrame, type RipOut, CAM_MODES,
  OPPONENTS, PLAYER_NAME, PLAYER_STYLE, ULTRA_COLOR, FOOTWORK_STEPS, LS_FW, LS_CAM, LS_DIFF, IQ_STEPS, LS_IQ, LS_HELMET, LS_ARMOR, LS_GLOVE, loadPanjerMode, loadAllOverdrivePunch, loadFootwork, loadCamMode, loadDifficulty, loadDirectionalHeadSnap, saveDirectionalHeadSnap,
  loadNoSlowMoNormal, saveNoSlowMoNormal, smartDef, ultraDef, loadIq, loadSkinSet,
  ROUND_TIME, INTRO_T, INTRO_TAUNT_AT, INTRO_COUNT, WALK_T, entryShift, rampY, FLIP_IN, FLIP_SPAN, PACE, STRATEGIST, PLAN_LABEL, PARRY_ACTIVE,
  QUALITY_TIERS, loadGfxMode, loadBrightness, loadSaturation, loadTextureEnhance, loadBloomMode, loadBloomPercent,
  LS_GFX, LS_BRIGHT, LS_SAT, LS_TEX, LS_BLOOM, LS_BLOOM_PCT, DEFAULT_BLOOM_PCT, DEFAULT_BRIGHTNESS, NORMAL_SAT,
  UNBLOCKABLE, PANJER_KEYS, PANJER_MODE_KEYS, N_COMBO_TAKEOVER,
  freshStats, gfxTier, createCinematicVignetteTexture, hpThick, PLAYER_HP_BASE, Fighter, isOD, starShouldFireOd, isGassed, panjerCharge, panjerLabel, panjerPower,
  type HeroPose, type Pose, type OpponentDef, type Phase, type WalkTrack, type MatchStats, type HudState, type MoveId, type Move, type CineKind, type GfxMode, type BloomMode, type PyroPlacement
} from './gameData';
export * from './gameData';
export { SAT_STEPS, DEFAULT_SAT } from './grade';
export { type PyroPlacement, loadPyroPlacement, savePyroPlacement } from './arena';
export { loadAllOverdrivePunch, LS_ALL_OD_PUNCH, type SfxProfile } from './audio';
import { captureRobot as _captureRobot, grabCorner as _grabCorner, gameplayCam as _gameplayCam, cineCam as _cineCam, capturePortrait as _capturePortrait, captureOpponentPortrait as _captureOpponentPortrait, startCine as _startCine, updateCamera as _updateCamera } from './gameCam';
import { heroArms as _heroArms, animateMenuHero as _animateMenuHero, animateFighter as _animateFighter, walkAt as _walkAt, updateAnimations as _updateAnimations, heroAnimState as _heroAnimState } from './gameAnim';
import { aiDefended as _aiDefended, scoutPlayer as _scoutPlayer, updatePlan as _updatePlan, planRange as _planRange, pickAiMove as _pickAiMove, makeAi as _makeAi, strat as _strat, enemyReact as _enemyReact, updateEnemyAI as _updateEnemyAI } from './gameAi';
import { updateAir as _updateAir, ragdollKick as _ragdollKick, ragdollSlam as _ragdollSlam, landFx as _landFx, ropeImpact as _ropeImpact, knockout as _knockout, perfectDodge as _perfectDodge, parryCounter as _parryCounter, tickTaunt as _tickTaunt, updateFighter as _updateFighter, separate as _separate, beginStrike as _beginStrike, resolveHit as _resolveHit } from './gameStrike';
import {
  panjerMax as _panjerMax, panjerReady as _panjerReady, panjerStep as _panjerStep, armOf as _armOf, punchStepOf as _punchStepOf, aimY as _aimY, aimPoint as _aimPoint, aimsLow as _aimsLow, aimPose as _aimPose, pickMixAim as _pickMixAim, markWhiff as _markWhiff, tellFor as _tellFor, tryFinisher as _tryFinisher, nComboStep as _nComboStep,
  beginPanjer as _beginPanjer, firePanjer as _firePanjer, togglePanjerMode as _togglePanjerMode, setPanjerMode as _setPanjerMode,
  updatePanjer as _updatePanjer, updateAutoFire as _updateAutoFire, playerInput as _playerInput, toggleRage as _toggleRage,
  playerDodge as _playerDodge, taunt as _taunt, tauntBack as _tauntBack, fsCue as _fsCue, tauntRaise as _tauntRaise,
  tauntBeat as _tauntBeat, tauntClash as _tauntClash, setHand as _setHand, toggleAim as _toggleAim, playerDash as _playerDash,
  startDodge as _startDodge, tryOverdrive as _tryOverdrive, toggleAliStyle as _toggleAliStyle, startNCombo as _startNCombo,
  breakNCombo as _breakNCombo, updateNCombo as _updateNCombo, tryAttack as _tryAttack, startMove as _startMove, canCancel as _canCancel
} from './gameInput';

export class Game {
  container: HTMLElement;
  renderer: THREE.WebGLRenderer;
  composer: EffectComposer;
  bloom: UnrealBloomPass;
  grade: ReturnType<typeof makeGradePass>;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(58, 1, 0.1, 200);
  arena: Arena;
  fx: Effects;
  decap: Decap;
  readonly sfx = new Sfx();
  onHud: (h: HudState) => void;

  player!: Fighter;
  enemy!: Fighter;
  oppIndex = 0;
  ultra = loadDifficulty() === 'ultra';
  fwMul = loadFootwork();
  camMode = loadCamMode();

  starMode = false;
  camBeforeStar = -1;
  iq = loadIq();
  helmetSkin = loadSkinSet();
  gloveSkin = loadSkinSet();
  armorSkin = loadSkinSet();
  def: OpponentDef = OPPONENTS[0];

  phase: Phase = 'menu';
  phaseT = 0;
  introStep = 0;
  round = 1;
  wins: [number, number] = [0, 0];
  roundTime = ROUND_TIME;
  timeUp = false;
  result: 'win' | 'lose' | null = null;
  banner: HudState['banner'] = null;
  bannerT = 0;
  bannerId = 0;
  paused = false;

  keys = new Set<string>();
  time = 0;
  timeScale = 1;
  slowT = 0;
  slowScale = 1;
  freeze = 0;
  frozenFighter: Fighter | null = null;
  trauma = 0;
  fovKick = 0;
  camPush = 0;
  camBump = 0;
  camRoll = 0;
  camImp = new THREE.Vector3();
  camImpVel = new THREE.Vector3();
  shakePh = 0;
  dynOrbit = 0;
  smoothVelP = new THREE.Vector2();
  smoothVelE = new THREE.Vector2();
  fpsEma = 16;
  fpsT = 0;
  fps = 60;
  frames = 0;
  longFrames = 0;
  dprCap = 1.5;
  quality = 1.0;
  bloomScale = 0.5;

  qTier = 0;
  qAuto = true;
  qMode: GfxMode = 'auto';
  qTierFailed = -1;
  qSteady = 0;
  qCooldown = 0;
  qWarm = 1.4;

  meter: MeterPass;
  aeDead = false;
  aePending = false;
  aeFrames = 0;
  aeBuf = new Uint8Array(4);
  aeKey = 0.28;
  aeGain = 1;
  aeHold = 0;
  aePause = 0;
  bright = 1.0;
  sat = loadSaturation();
  textureEnhance = loadTextureEnhance();
  bloomMode: BloomMode = loadBloomMode();
  bloomPercent: number = loadBloomPercent();
  allOverdrivePunch: boolean = loadAllOverdrivePunch();
  smoothBloomStrength = 0.14;
  smoothBloomRadius = 0.55;
  enemyCache = new Map<number, Fighter>();
  flashAmt = 0;
  hype = 0;
  combo = 0;
  comboT = 0;

  nComboIdx = -1;
  nComboT = 0;
  nComboWait = 0;
  nComboCd = 0;
  nComboSeq = -1;

  aliStyle = false;
  stats: MatchStats = freshStats();
  walk: WalkTrack[] = [];
  walkPyroT = 0;
  camPos = new THREE.Vector3(0, 6, 14);
  camLook = new THREE.Vector3(0, 3, 0);
  camInit = false;
  lastHud = 0;
  raf = 0;
  last = performance.now();
  popupLayer: HTMLDivElement;

  popLanes: number[] = [0, 0, 0, 0, 0];
  flashEl: HTMLDivElement;
  warnEl: HTMLDivElement;
  warnTag: HTMLElement;
  warnSeq = -1;
  warnTotal = 1;
  warnOn = false;
  warnKind = '';
  ro: ResizeObserver;
  meterReadyShown = false;
  ripVictim: Fighter | null = null;
  lastTap: Record<string, number> = {};
  aimTmp = new THREE.Vector3();
  eyeTmp = new THREE.Vector3();

  cine: { kind: CineKind; t: number; dur: number } | null = null;
  cineFrom = new THREE.Vector3();
  cineFromLook = new THREE.Vector3();
  cineFocus = new THREE.Vector3();
  cineDir = new THREE.Vector2(0, 1);
  cineFov = 58;
  cineFovT = 58;
  camClose = 0;
  baseFov = 58;
  handPh = 0;
  runLatch = false;
  sprintLock = false;
  lastRoar = 0;
  runFov = 0;
  focus = new THREE.Vector3(0, 3.4, 0);
  odToggle = Math.random() < 0.5;

  ai = this.makeAi();

  // Foreground Hero Robot in main menu (standing front view)
  menuHero: Robot;
  hangar: Hangar;
  menuHeroPedestal: THREE.Group;
  menuHeroSpot: THREE.SpotLight;
  menuHeroRim: THREE.SpotLight;
  menuHeroFill: THREE.PointLight;
  menuScrimPlane: THREE.Mesh;
  heroPose: HeroPose = 'ready';
  heroYaw = 0;
  heroYawTarget = 0;
  heroMouseX = 0;
  heroMouseY = 0;
  directionalHeadSnap = loadDirectionalHeadSnap();
  noSlowMoNormal = loadNoSlowMoNormal();
  /** PANJER OTOMATIS (SHIFT): every punch comes out on the press, at the ceiling. Remembered between visits. */
  panjerMode = loadPanjerMode();
  /** true while a full-screen React overlay (the robot editor, the real-steel sim) owns the screen: the game must
   *  not read keys at all then — the editor uses SHIFT+click for multi-select and it must not toggle a fight mode */
  inputOff = false;

  constructor(container: HTMLElement, onHud: (h: HudState) => void) {
    this.container = container;
    this.onHud = onHud;
    this.qMode = loadGfxMode();
    this.qAuto = this.qMode === 'auto';
    this.bright = loadBrightness();
    this.sat = loadSaturation();
    this.textureEnhance = loadTextureEnhance();

    // anti-aliasing: a light 2× MSAA on the composer's HDR target for the long geometry edges, plus the compact
    // FXAA inside the grade pass for everything the samples miss. The HDR target is where the frame goes through
    // the grade, so the default framebuffer stays single-sampled — no second MSAA resolve every frame.
    this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', stencil: false, depth: true });
    this.dprCap = Game.bootDprCap();
    this.renderer.setPixelRatio(this.pixelRatio());
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap; // one map, plain PCF: half the shadow cost of the soft kernel
    // PBR-NEUTRAL TONE MAP: it preserves the hue of red and blue lighting while rolling bright highlights off softly.
    // The arena rig and exposure are deliberately restrained so this preserves colour instead of washing it out.
    this.renderer.toneMapping = THREE.NeutralToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.display = 'block';

    const pm = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.30; // retain metallic reflections while preserving darker armour and canvas contrast

    this.arena = buildArena(this.scene, this.camera);
    this.hangar = buildHangar(this.scene);
    this.fx = new Effects(this.scene);
    this.decap = new Decap(this.scene);

    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    // the first rung is chosen from the hardware (or from the mode the player pinned), so a weak GPU never has to
    // eat a few seconds of stutter before the governor has worked out how to save it
    this.applyTier(this.qAuto ? this.bootTier() : gfxTier(this.qMode), true);
    const rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: this.tierCfg().samples, depthBuffer: true, stencilBuffer: false });
    this.composer = new EffectComposer(this.renderer, rt);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    // CINEMATIC BLOOM — HIGHLIGHT-ONLY. The threshold sits well above diffuse white in the linear HDR buffer, so
    // the canvas, the steel and the crowd stay exactly as lit as they were and only the things that are genuinely
    // over-bright (a lamp lens, an LED strip, a jumbotron, a hot spark) bleed a soft glow into the dark of the
    // hall. Soft knee (smoothWidth = 0.55) ensures gradual light transition without flickering or strobing.
    const initialBloomStrength = this.bloomPercent <= 0 ? 0 : (this.bloomPercent / 100) * 0.9;
    this.bloom = new UnrealBloomPass(new THREE.Vector2(w, h), initialBloomStrength, 0.55, 1.3);
    this.bloom.enabled = this.bloomPercent > 0 && this.tierCfg().bloom;
    const hpUni = this.bloom.highPassUniforms as Record<string, { value: number }> | undefined;
    if (hpUni && hpUni.smoothWidth) {
      hpUni.smoothWidth.value = 0.55;
    }
    const baseBloomSize = UnrealBloomPass.prototype.setSize;
    const bloom = this.bloom;
    // the bloom pyramid is run at a FRACTION of the render size: the mips only carry the wide glow, so nothing
    // of value is lost and the pass costs a few tenths of a millisecond even at 1440p
    this.bloom.setSize = (bw: number, bh: number) => {
      const k = QUALITY_TIERS[this.qTier].bloomScale;
      baseBloomSize.call(bloom, Math.max(64, Math.round(bw * k)), Math.max(64, Math.round(bh * k)));
    };
    this.composer.addPass(this.bloom);
    this.grade = makeGradePass();
    this.grade.uniforms.sat.value = this.sat;
    this.composer.addPass(this.grade);
    // THE LIGHT METER: one pixel of the graded frame, for the auto-exposure. It sits between the grade and the
    // tone map and never touches the chain (see MeterPass).
    this.meter = new MeterPass();
    this.composer.addPass(this.meter);
    this.composer.addPass(new OutputPass());

    // Foreground menu hero robot (standing front view on illuminated platform)
    this.menuHero = new Robot({ ...PLAYER_STYLE, helmetSkin: this.helmetSkin, gloveSkin: this.gloveSkin, armorSkin: this.armorSkin }, 1.0);
    this.menuHero.setEnhancedTextures(this.textureEnhance);
    // Remove point lights from menuHero so it adds zero extra dynamic lights or shader recompilations
    for (const l of this.menuHero.eyeLights) l.removeFromParent();
    this.scene.add(this.menuHero.root);

    this.menuHeroPedestal = new THREE.Group();
    const platGeo = new THREE.CylinderGeometry(2.35, 2.55, 0.14, 36);
    const platMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.2,
    });
    const platMesh = new THREE.Mesh(platGeo, platMat);
    platMesh.position.y = 0.07;
    platMesh.receiveShadow = true;
    this.menuHeroPedestal.add(platMesh);

    const ringGeo = new THREE.RingGeometry(2.12, 2.28, 36);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      side: THREE.DoubleSide,
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.y = 0.145;
    this.menuHeroPedestal.add(ringMesh);

    const innerRingGeo = new THREE.RingGeometry(1.35, 1.43, 36);
    const innerRingMat = new THREE.MeshBasicMaterial({
      color: 0x1d4ed8,
      side: THREE.DoubleSide,
    });
    const innerRingMesh = new THREE.Mesh(innerRingGeo, innerRingMat);
    innerRingMesh.rotation.x = -Math.PI / 2;
    innerRingMesh.position.y = 0.146;
    this.menuHeroPedestal.add(innerRingMesh);

    // 8 glowing cyber node markers around the pedestal perimeter
    const nodeGeo = new THREE.BoxGeometry(0.28, 0.04, 0.1);
    const nodeMat = new THREE.MeshBasicMaterial({ color: 0x7dd3fc });
    for (let i = 0; i < 8; i++) {
      const ang = (i * Math.PI) / 4;
      const node = new THREE.Mesh(nodeGeo, nodeMat);
      node.position.set(Math.cos(ang) * 1.82, 0.15, Math.sin(ang) * 1.82);
      node.rotation.y = -ang;
      this.menuHeroPedestal.add(node);
    }
    this.scene.add(this.menuHeroPedestal);

    // Keep references detached from scene so they add zero GPU light/shadow overhead or shader recompilations
    this.menuHeroSpot = new THREE.SpotLight(0xd8eeff, 0, 30, Math.PI / 3.2, 0.45, 1.15);
    this.menuHeroRim = new THREE.SpotLight(0x3fd8ff, 0, 25, Math.PI / 3, 0.5, 1.15);
    this.menuHeroFill = new THREE.PointLight(0x60b0ff, 0, 12, 1.4);

    // Darkening Scrim Plane with Cinematic Vignette: placed between hero (z=6.0) and background ring (z<=0)
    // Applies a rich cinematic radial vignette solely to the background gameplay arena without darkening the front hero!
    const scrimGeo = new THREE.PlaneGeometry(120, 70);
    const scrimTex = createCinematicVignetteTexture();
    const scrimMat = new THREE.MeshBasicMaterial({
      map: scrimTex,
      transparent: true,
      depthWrite: false,
    });
    this.menuScrimPlane = new THREE.Mesh(scrimGeo, scrimMat);
    this.menuScrimPlane.position.set(0, 4.5, 3.0);
    this.scene.add(this.menuScrimPlane);

    // DOM layers
    this.popupLayer = document.createElement('div');
    this.popupLayer.className = 'popup-layer';
    container.appendChild(this.popupLayer);
    this.flashEl = document.createElement('div');
    this.flashEl.className = 'fx-flash';
    container.appendChild(this.flashEl);

    // attack indicator: clean non-intrusive top-left text prompt
    const touchUi = typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches;
    this.warnEl = document.createElement('div');
    this.warnEl.className = 'warn warn-yellow';
    this.warnEl.innerHTML = `<div class="warn-text">⚡ HINDAR [${touchUi ? '◎' : 'G'}] / LINDUNG [SPACE]</div>`;
    container.appendChild(this.warnEl);
    this.warnTag = this.warnEl.children[0] as HTMLElement;

    const initIsZeus = (this.helmetSkin === 1 && this.armorSkin === 1) || (typeof localStorage !== 'undefined' && localStorage.getItem('steel_titans_custom_robot_active') === '1');
    if (initIsZeus) {
      this.helmetSkin = 1;
      this.armorSkin = 1;
      this.gloveSkin = 1;
    }
    const initPlayerHp = initIsZeus ? hpThick(Math.round(PLAYER_HP_BASE * 1.6)) : hpThick(PLAYER_HP_BASE);
    this.player = this.makeFighter(true, { ...PLAYER_STYLE, helmetSkin: this.helmetSkin, gloveSkin: this.gloveSkin, armorSkin: this.armorSkin, isZeus100: initIsZeus }, 1, initPlayerHp, 1, 1);
    this.prepareEnemy(0);
    this.toMenu();

    this.resize();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('visibilitychange', this.onVisible);

    (window as unknown as { __game?: Game }).__game = this;
    this.raf = requestAnimationFrame(this.loop);
  }

  // ------------------------------------------------------------ setup
  makeFighter(isPlayer: boolean, style: RobotStyle, scale: number, hp: number, dmg: number, ts: number) {
    const robot = new Robot(style, scale);
    robot.setEnhancedTextures(this.textureEnhance);
    this.scene.add(robot.root);
    const f = new Fighter(robot, isPlayer, scale, hp, dmg, ts);
    const tc = isPlayer ? 0x6fd8ff : style.glow;
    f.trails = [new Trail(this.scene, tc), new Trail(this.scene, tc)];
    let lastStepSfx = 0;
    robot.onStep = (_foot, spd, wx, wz) => {
      const now = performance.now();
      const v = new THREE.Vector3(wx, 0.1, wz);
      const isZeusFighter = f.robot.isZeus;
      const light = Math.min(1, 0.35 + spd * 0.12);
      if (now - lastStepSfx > 110) {
        lastStepSfx = now;
        this.sfx.step(light * Math.min(1.7, 0.7 * scale + (isZeusFighter ? 0.38 : 0.25)));
      }
      v.y = f.y + 0.1;
      // BEKAS PIJAKAN KAKI: Tidak ada ripple efek cincin tanah (fx.ring dihilangkan), hanya partikel debu & percikan halus
      if (spd > 5.5 && f.y < 0.05) {
        this.fx.spark(v, 2 + Math.floor(spd * 0.7), 1.4 + spd * 0.15, 0x8a8a99, undefined, 1.1, 0.3, 2);
      } else if (spd > 2.0) {
        this.fx.spark(v, 1 + Math.floor(spd * 0.4), 1.0 + spd * 0.1, 0x8a8a99, undefined, 0.9, 0.25, 1);
      }
      // TONNAGE: a striding / sprinting machine makes the ring itself answer
      if (spd > 3.5 && f.y < 0.05 && this.phase !== 'walk' && this.phase !== 'menu') {
        this.arena.canvasSlam(wx, wz, Math.min(0.48, (isZeusFighter ? 0.14 : 0.08) + spd * 0.03));
      }
      if (spd > 6.5 && f.y < 0.05 && (this.phase === 'fight' || this.phase === 'walk')) {
        this.camImpVel.y -= 0.14 * Math.min(1, spd / 10) * Math.min(1.3, scale);
      }
      if (this.phase === 'walk' && f.sprinting) {
        // a sprinting machine on the steel runway: every footfall throws sparks and thumps through the camera
        this.fx.spark(v, 10, 5 + spd * 0.3, 0xffb860, new THREE.Vector3(0, 0.6, 0), 0.5, 0.5, 10);
        this.trauma = Math.min(1, this.trauma + 0.045);
        this.sfx.step(1.3);
      }
    };
    return f;
  }

  prepareEnemy(idx: number) {
    if (this.enemy) {
      this.scene.remove(this.enemy.robot.root);
      for (const tr of this.enemy.trails) this.scene.remove(tr.mesh);
    }
    this.oppIndex = idx;
    this.def = this.makeDef(idx);
    let cached = this.enemyCache.get(idx);
    if (!cached) {
      cached = this.makeFighter(false, this.def.style, this.def.scale, this.def.hp, this.def.dmg, this.def.tscale);
      this.enemyCache.set(idx, cached);
    } else {
      this.scene.add(cached.robot.root);
      for (const tr of cached.trails) this.scene.add(tr.mesh);
      cached.maxHp = this.def.hp;
      cached.hp = this.def.hp;
      cached.dmgMul = this.def.dmg;
      cached.tscale = this.def.tscale;
      cached.robot.head.visible = true;
    }
    this.enemy = cached;
    if (idx === 0) {
      mount100PercentZeus(this.enemy.robot, '#22ff44');
    } else if (idx === 3 || this.def.name === 'OMEGA ZEUS') {
      mount100PercentZeus(this.enemy.robot, '#c070ff');
    }
    // Ultra opponents burn crimson-red so you can tell at a glance that this is the hard version (except authentic green Zeus at idx 0)
    this.enemy.robot.setStyleGlow(this.ultra && idx !== 0 ? 0xff1a3a : this.def.style.glow);
    this.arena.setScreen(PLAYER_NAME, this.def.name, this.roundLabel(), '#4da3ff', this.ultra ? ULTRA_COLOR : this.def.color);
    this.arena.rimRed.color.setHex(this.ultra ? 0xff1a3a : this.def.style.glow);
  }

  getPlayerMaxHp(): number {
    const isZeus = !!(this.player?.robot?.isZeus || (this.helmetSkin === 1 && this.armorSkin === 1));
    const base = isZeus ? Math.round(PLAYER_HP_BASE * 1.6) : PLAYER_HP_BASE;
    return hpThick(base);
  }

  /** the opponent's tuning for the current difficulty AND IQ — and the 1.8× chassis (see HP_SCALE). The two HEAVY
   *  chassis (Zeus and, for the LAWAN ATLAS duel, the champion's own ATLAS PRIME) are plated 60% thicker; Zeus in
   *  addition is twice as smart (his 2× effective IQ). */
  makeDef(idx: number) {
    const raw = this.ultra ? ultraDef(OPPONENTS[idx]) : OPPONENTS[idx];
    const isZeusOpp = raw.name.includes('ZEUS') || !!raw.style.isZeus100;
    // ATLAS PRIME wears the champion's plating — the same 1.6× thickness as Zeus, so the LAWAN ATLAS duel is a real
    // main event instead of a mirror match that ends in three exchanges (the brain stays his own; no IQ doubling).
    const isHeavyChassis = isZeusOpp || raw.name.includes('ATLAS');
    const tunedHp = isHeavyChassis ? Math.round(raw.hp * 1.6) : raw.hp;
    // Khusus Zeus: 2x lebih cerdas (IQ efektif digandakan 2×)
    const effectiveIq = isZeusOpp ? this.iq * 2 : this.iq;
    const d = smartDef({ ...raw, hp: tunedHp }, effectiveIq);
    return { ...d, hp: hpThick(d.hp) };
  }

  get iqLevel() {
    return this.iq;
  }

  /** Enemy AI IQ: 1× / 2× / 3× / 10×. Works in the menu, in the pause screen and during a fight. Remembered. */
  setIq(n: number) {
    const v = (IQ_STEPS as readonly number[]).includes(n) ? n : 1;
    if (v === this.iq) return;
    this.iq = v;
    try {
      localStorage.setItem(LS_IQ, String(v));
    } catch {
      /* ignore */
    }
    this.def = this.makeDef(this.oppIndex); // only the brain changes: hp / damage / attack speed stay as they are
    this.sfx.init();
    if (v >= 10) this.sfx.charge();
    else this.sfx.click();
    this.emitHud(true);
  }

  roundLabel() {
    return `${this.ultra ? 'ULTRA HARD · ' : ''}ROUND ${this.round}`;
  }

  get isUltra() {
    return this.ultra;
  }

  get footwork() {
    return this.fwMul;
  }

  /** Footwork speed 1× / 1.5× / 2× / 3× (works in the menu, in the pause screen and during a fight). Remembered. */
  setFootwork(m: number) {
    const v = (FOOTWORK_STEPS as readonly number[]).includes(m) ? m : 1;
    if (v === this.fwMul) return;
    this.fwMul = v;
    try {
      localStorage.setItem(LS_FW, String(v));
    } catch {
      /* ignore */
    }
    this.sfx.init();
    this.sfx.click();
    this.emitHud(true);
  }

  get cameraMode() {
    return this.camMode;
  }

  get currentHelmetSkin() {
    return this.helmetSkin;
  }

  get currentGloveSkin() {
    return this.gloveSkin;
  }

  get currentArmorSkin() {
    return this.armorSkin;
  }

  equipZeus(active = true) {
    this.helmetSkin = active ? 1 : 0;
    this.armorSkin = active ? 1 : 0;
    this.gloveSkin = active ? 1 : 0;
    try {
      localStorage.setItem(LS_HELMET, String(this.helmetSkin));
      localStorage.setItem(LS_ARMOR, String(this.armorSkin));
      localStorage.setItem(LS_GLOVE, String(this.gloveSkin));
      localStorage.setItem('steel_titans_custom_robot_active', active ? '1' : '0');
    } catch {
      /* ignore */
    }
    this.menuHero.setSkins(this.helmetSkin, this.gloveSkin, this.armorSkin, active);
    this.player.robot.setSkins(this.helmetSkin, this.gloveSkin, this.armorSkin, active);
    this.player.maxHp = this.getPlayerMaxHp();
    this.player.hp = this.player.maxHp;
    if (active) {
      this.setHeroPose('sombong');
    }
    this.sfx.init();
    this.sfx.servo();
    this.sfx.click();
    this.emitHud(true);
  }

  /** Ganti skin = ganti satu set penuh (ATLAS atau ZEUS). id >= 1 = set ZEUS, selain itu = set ATLAS. */
  setArmorSkin(id: number) {
    this.equipZeus(id >= 1);
  }

  setHelmetSkin(id: number) {
    this.equipZeus(id >= 1);
  }

  setGloveSkin(id: number) {
    this.equipZeus(id >= 1);
  }

  /** Re-mount Zeus 100% on any active robots (lobby hero, player, enemy, VS cards) using current adjustments & groups */
  reloadZeus(forceEquipPlayer?: boolean) {
    let customActive = false;
    try {
      customActive = localStorage.getItem('steel_titans_custom_robot_active') === '1';
    } catch {}
    const isCustomActive = !!forceEquipPlayer || customActive || (this.helmetSkin === 1 && this.armorSkin === 1);
    if (isCustomActive) {
      this.helmetSkin = 1;
      this.armorSkin = 1;
      this.gloveSkin = 1;
      try {
        localStorage.setItem(LS_HELMET, '1');
        localStorage.setItem(LS_ARMOR, '1');
        localStorage.setItem(LS_GLOVE, '1');
        localStorage.setItem('steel_titans_custom_robot_active', '1');
      } catch {}
      if (this.menuHero) {
        this.menuHero.ctx.style.isZeus100 = true;
      }
      if (this.player?.robot) {
        this.player.robot.ctx.style.isZeus100 = true;
      }
    }

    if (this.menuHero && (this.menuHero.ctx.style.isZeus100 || isCustomActive)) {
      this.menuHero.ctx.style.isZeus100 = true;
      mount100PercentZeus(this.menuHero);
      for (const l of this.menuHero.eyeLights) l.removeFromParent();
    }
    if (this.player?.robot && (this.player.robot.ctx.style.isZeus100 || isCustomActive)) {
      this.player.robot.ctx.style.isZeus100 = true;
      mount100PercentZeus(this.player.robot);
      this.player.maxHp = this.getPlayerMaxHp();
      this.player.hp = this.player.maxHp;
    }
    const z0 = this.enemyCache.get(0);
    if (z0) mount100PercentZeus(z0.robot, '#22ff44');
    const z3 = this.enemyCache.get(3);
    if (z3) mount100PercentZeus(z3.robot, '#c070ff');
    if (this.enemy && (this.enemy.robot.ctx.style.isZeus100 || this.oppIndex === 0 || this.oppIndex === 3)) {
      mount100PercentZeus(this.enemy.robot, this.oppIndex === 3 ? '#c070ff' : '#22ff44');
    }
    this.emitHud(true);
  }

  get isStarMode() {
    return this.starMode;
  }

  /**
   * STAR MODE on/off. Turning it on moves the camera to the STAR shot (the Boxing Star look) and switches the
   * player's assists on; turning it off hands the camera back to whatever preset was active before, so a normal
   * fight is exactly the fight it was. Changing the camera lens by hand while STAR MODE runs is respected — the
   * mode only sets the shot when it starts.
   */
  setStarMode(on: boolean) {
    if (on === this.starMode) return;
    this.starMode = on;
    const starIdx = CAM_MODES.findIndex((m) => m.id === 'star');
    if (on) {
      if (starIdx >= 0 && this.camMode !== starIdx) {
        this.camBeforeStar = this.camMode;
        this.setCamMode(starIdx);
      }
      if (this.player) {
        this.player.autoGuard = false;
        this.popup(new THREE.Vector3(this.player.pos.x, 7.4, this.player.pos.y), '⭐ STAR MODE — AUTO-RANGE ON', 'pop-crit');
      }
      this.sfx.ready();
    } else {
      if (this.camBeforeStar >= 0) {
        this.setCamMode(this.camBeforeStar);
        this.camBeforeStar = -1;
      }
      if (this.player) this.player.autoGuard = false;
    }
    this.emitHud(true);
  }

  /** Camera preset (see CAM_MODES). Applies instantly, in the menu, the pause screen or mid-fight. Remembered. */
  setCamMode(i: number) {
    const v = Math.max(0, Math.min(CAM_MODES.length - 1, Math.round(i)));
    if (v === this.camMode) return;
    this.camMode = v;
    try {
      localStorage.setItem(LS_CAM, String(v));
    } catch {
      /* ignore */
    }
    this.sfx.init();
    this.sfx.click();
    this.emitHud(true);
  }

  setDirectionalHeadSnap(on: boolean) {
    if (this.directionalHeadSnap === on) return;
    this.directionalHeadSnap = on;
    saveDirectionalHeadSnap(on);
    this.sfx.init();
    this.sfx.click();
    if (this.player) {
      this.popup(
        new THREE.Vector3(this.player.pos.x, 6.2 * this.player.scale, this.player.pos.y),
        on ? 'HEAD SNAP: ON' : 'HEAD SNAP: OFF',
        on ? 'pop-crit' : 'pop-block'
      );
    }
    this.emitHud(true);
  }

  toggleDirectionalHeadSnap() {
    this.setDirectionalHeadSnap(!this.directionalHeadSnap);
  }

  setNoSlowMoNormal(on: boolean) {
    if (this.noSlowMoNormal === on) return;
    this.noSlowMoNormal = on;
    saveNoSlowMoNormal(on);
    this.sfx.init();
    this.sfx.click();
    if (on) {
      const curMove = this.player?.move || this.enemy?.move;
      const isODMove = curMove && isOD(curMove.id);
      if (!isODMove && this.phase !== 'ko') {
        this.slowT = 0;
        this.timeScale = 1;
      }
    }
    if (this.player) {
      this.popup(
        new THREE.Vector3(this.player.pos.x, 6.2 * this.player.scale, this.player.pos.y),
        on ? 'SLOW-MO: HANYA OVERDRIVE' : 'SLOW-MO: SEMUA SERANGAN',
        on ? 'pop-crit' : 'pop-block'
      );
    }
    this.emitHud(true);
  }

  toggleNoSlowMoNormal() {
    this.setNoSlowMoNormal(!this.noSlowMoNormal);
  }

  /** / and . change the camera preset in the middle of a fight */
  cycleCamMode(dir: number) {
    const n = (this.camMode + dir + CAM_MODES.length) % CAM_MODES.length;
    this.setCamMode(n);
    const p = this.player;
    const m = CAM_MODES[n];
    this.popup(new THREE.Vector3(p.pos.x, 6.6, p.pos.y), `KAMERA ${m.name}`, 'pop-info');
  }

  /** [ and ] change the footwork speed in the middle of a fight */
  cycleFootwork(dir: number) {
    const i = (FOOTWORK_STEPS as readonly number[]).indexOf(this.fwMul);
    const n = Math.max(0, Math.min(FOOTWORK_STEPS.length - 1, i + dir));
    if (n === i) return;
    this.setFootwork(FOOTWORK_STEPS[n]);
    const p = this.player;
    this.popup(new THREE.Vector3(p.pos.x, 6.6, p.pos.y), `FOOTWORK ${FOOTWORK_STEPS[n]}×`, 'pop-info');
  }

  /** Switch ULTRA HARD on/off (menu only). Remembered between visits. */
  setUltra(on: boolean) {
    if (this.ultra === on) return;
    this.ultra = on;
    this.hangar.setMood(on);
    try {
      localStorage.setItem(LS_DIFF, on ? 'ultra' : 'normal');
    } catch {
      /* ignore */
    }
    this.sfx.init();
    if (on) {
      this.sfx.charge();
      this.sfx.cheer(0.6);
    } else this.sfx.click();
    if (this.phase === 'menu') {
      this.prepareEnemy(this.oppIndex);
      this.placeMenu();
    }
    this.emitHud(true);
  }

  resize() {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.composer.setPixelRatio(this.renderer.getPixelRatio());
    this.composer.setSize(w, h);
    this.grade.uniforms.res.value.set(w * this.renderer.getPixelRatio(), h * this.renderer.getPixelRatio());
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('visibilitychange', this.onVisible);
    this.sfx.stopMusic();
    if (this.menuHero) {
      this.scene.remove(this.menuHero.root);
      this.scene.remove(this.menuHeroPedestal);
      this.scene.remove(this.menuHeroSpot);
      this.scene.remove(this.menuHeroRim);
      this.scene.remove(this.menuHeroFill);
      this.scene.remove(this.menuScrimPlane);
      this.menuScrimPlane.geometry.dispose();
      const mat = this.menuScrimPlane.material as THREE.MeshBasicMaterial;
      mat.map?.dispose();
      mat.dispose();
    }
    this.arena.dispose?.();
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    this.container.innerHTML = '';
  }

  // ------------------------------------------------------------ public api
  startMatch(idx: number) {
    if (this.hangar) this.hangar.g.visible = false;
    if (this.menuHero) {
      this.menuHero.root.visible = false;
      this.menuHeroPedestal.visible = false;
      this.menuHeroSpot.visible = false;
      this.menuHeroRim.visible = false;
      this.menuHeroFill.visible = false;
      this.menuScrimPlane.visible = false;
    }
    this.sfx.init();
    this.sfx.startMusic();
    this.sfx.click();
    this.prepareEnemy(idx);
    const isPlayerZeus = !!(
      this.player?.robot?.ctx?.style?.isZeus100 ||
      (this.helmetSkin === 1 && this.armorSkin === 1) ||
      (typeof localStorage !== 'undefined' && localStorage.getItem('steel_titans_custom_robot_active') === '1')
    );
    if (isPlayerZeus && this.player?.robot) {
      this.player.robot.ctx.style.isZeus100 = true;
      mount100PercentZeus(this.player.robot);
    }
    try {
      const me = this.capturePortrait(240, 320, 'bust', false);
      const foe = this.captureOpponentPortrait(idx, 240, 320, 'bust', false);
      this.arena.setFaces({ name: PLAYER_NAME, color: '#4da3ff', img: me }, { name: this.def.name, color: this.ultra ? ULTRA_COLOR : this.def.color, img: foe });
    } catch {
      /* the boards keep their last picture */
    }
    this.wins = [0, 0];
    this.round = 1;
    this.result = null;
    this.paused = false;
    this.startRound(true);
  }

  fighters(): Fighter[] {
    return [this.player, this.enemy];
  }
  foeOf(f: Fighter): Fighter {
    return f === this.player ? this.enemy : this.player;
  }
  camHero(): Fighter {
    return this.player;
  }
  standHOf(f: Fighter): number {
    const zm = f.robot?.root?.userData?.zeusMetrics as { STAND_Y: number } | undefined;
    if (zm?.STAND_Y) return zm.STAND_Y + 4.4;
    return 6.6;
  }
  portraitCam = new THREE.PerspectiveCamera(26, 3 / 4, 0.1, 60);
  portraitCanvas: HTMLCanvasElement | null = null;

  cutoutLayerReady = false;

  selectOpponent(idx: number) {
    if (this.phase !== 'menu') return;
    this.prepareEnemy(idx);
    this.placeMenu();
  }

  toMenu() {
    this.resetExposure();
    this.phase = 'menu';
    this.phaseT = 0;
    this.result = null;
    this.banner = null;
    this.paused = false;
    this.round = 1;
    this.wins = [0, 0];
    if (this.hangar) this.hangar.g.visible = true;
    if (this.menuHero) {
      this.menuHero.root.visible = true;
      this.menuHeroPedestal.visible = false;
      this.menuHeroSpot.visible = true;
      this.menuHeroRim.visible = true;
      this.menuHeroFill.visible = true;
      this.menuScrimPlane.visible = false;
      this.heroPose = 'ready';
      this.heroYaw = -0.16;
      this.heroYawTarget = -0.16;
    }
    this.placeMenu();
    this.sfx.musicIntensity = 0.7;
    this.emitHud(true);
  }

  setHeroPose(pose: HeroPose) {
    if (this.heroPose === pose) return;
    this.heroPose = pose;
    this.menuHero?.snapFeet();
    this.sfx.init();
    this.sfx.click();
    this.emitHud(true);
  }

  getHeroPose() {
    return this.heroPose;
  }

  rotateHero(deltaYaw: number) {
    this.heroYawTarget += deltaYaw;
  }

  resetHeroRotation() {
    this.heroYawTarget = -0.16;
  }

  setHeroMouse(nx: number, ny: number) {
    this.heroMouseX = nx;
    this.heroMouseY = ny;
  }

  resetExposure() {
    this.aeKey = 0.28;
    this.aeGain = 1;
    this.aeHold = 0;
    this.aePause = 0;
    if (this.grade) {
      this.grade.uniforms.exposure.value = 1.0 * this.bright;
      this.grade.uniforms.guard.value = 0;
    }
  }

  placeMenu() {
    this.player.reset(-2.0, -1.8, Math.atan2(4.0, -2.4));
    this.enemy.reset(2.0, -4.2, Math.atan2(-4.0, 2.4));
    this.player.mode = 'normal';
    this.enemy.mode = 'normal';
    this.player.glowBoost = 0.6;
    this.enemy.glowBoost = 0.6;
    if (this.hangar) this.hangar.g.visible = true;
    this.player.robot.root.visible = true;
    this.enemy.robot.root.visible = true;
    this.player.robot.root.position.y = -200;
    this.enemy.robot.root.position.y = -200;
    for (const tr of this.player.trails) tr.mesh.visible = false;
    for (const tr of this.enemy.trails) tr.mesh.visible = false;
    if (this.menuHero) {
      this.menuHero.root.visible = true;
      this.menuHeroPedestal.visible = false;
      this.menuScrimPlane.visible = false;
    }
  }

  togglePause() {
    if (this.phase === 'menu' || this.phase === 'matchEnd') return;
    this.paused = !this.paused;
    this.emitHud(true);
  }

  setMuted(m: boolean) {
    this.sfx.setMuted(m);
  }

  setSoundProfile(id: SfxProfile) {
    this.sfx.init();
    this.sfx.setProfile(id, true);
  }

  setAllOverdrivePunch(on: boolean) {
    this.allOverdrivePunch = on;
    this.sfx.setAllOverdrivePunch(on, true);
    this.emitHud(true);
  }

  /** the game steps out of the keyboard while another screen is in front of it (see openZeus / the real-steel sim) */
  setInputOff(off: boolean) {
    this.inputOff = off;
    if (off) this.keys.clear();
  }

  press(code: string) {
    if (this.inputOff) return;
    if (this.keys.has(code)) return;
    this.keys.add(code);
    // Space dodges on the press (instant). KeyG is held to guard/block (reduces incoming attack damage by 90%).
    if (code === 'Space' && this.phase === 'fight' && !this.paused) this.playerDodge();
    this.onEdge(code);
  }
  release(code: string) {
    if (code === 'KeyW' || code === 'ArrowUp') this.runLatch = false;
    this.keys.delete(code);
    if (this.inputOff) return;
    // PANJER: the loaded punch is thrown the moment the button is let go — release before PANJER_T and it is the
    // ordinary punch, hold it for the full second and it lands 2× as hard and drives him 2× as far.
    if (this.player && this.player.panjerKey === code) this.firePanjer(this.player);
    if (this.player && this.player.autoFireKey === code) this.player.autoFireKey = null; // the spam repeat stops
  }

  onKeyDown = (e: KeyboardEvent) => {
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
    if (e.repeat) return;
    this.sfx.init();
    this.press(e.code);
  };
  onKeyUp = (e: KeyboardEvent) => {
    this.release(e.code);
  };
  onBlur = () => {
    this.keys.clear();
    this.runLatch = false;
    // a lost focus must never throw a punch: the load is dropped, not released
    this.player?.clearPanjer();
  };

  /** coming back from another tab: the clock never counts the time we were away (one huge frameMs would upset the governor) */
  onVisible = () => {
    if (document.visibilityState === 'visible') this.last = performance.now();
  };

  onEdge(code: string) {
    if (code === 'Escape') {
      this.togglePause();
      return;
    }
    if (this.phase === 'walk') {
      if (code === 'Enter' || code === 'Space') this.finishWalk();
      return;
    }
    if (code === 'Slash' || code === 'Period') {
      // the camera can be changed anywhere: in the menu, while paused, mid-round
      if (!this.paused) this.cycleCamMode(code === 'Slash' ? 1 : -1);
      return;
    }
    if (code === 'KeyY') {
      // ALI STYLE works ANYWHERE: in the lobby (the hero starts dancing), on the ring walk, in the fight, while
      // paused. It has to be readable wherever it is pressed, so the toggle answers with a banner + a sound + a burst
      // on the fighter — not just a line of text somewhere off screen.
      this.toggleAliStyle();
      return;
    }
    if (PANJER_MODE_KEYS.includes(code)) {
      // PANJER OTOMATIS: one press of SHIFT and every punch is a full one (see the block above the strike keys).
      // Read anywhere, like Y — this is a way of fighting, not a mid-fight trick.
      this.togglePanjerMode();
      return;
    }
    if (this.phase !== 'fight' || this.paused) return;
    // THE PLAYER ALWAYS OUTRANKS THE SCRIPT: throwing a punch (or slipping) by hand while the N combo is running hands
    // the fight back to you on the spot — the script stops where it is, and the punch you just pressed is the punch
    // that comes out. The direction keys are NOT in this list: holding W/A/S/D mid-combo is footwork, not a takeover.
    if (this.nComboIdx >= 0 && (code === 'Space' || N_COMBO_TAKEOVER.includes(code))) this.breakNCombo('KOMBO DILEPAS');
    const p = this.player;
    const tapKind: Record<string, ['fwd' | 'back' | 'side', number]> = {
      KeyW: ['fwd', 0],
      ArrowUp: ['fwd', 0],
      KeyS: ['back', 0],
      ArrowDown: ['back', 0],
      KeyD: ['side', 1],
      ArrowRight: ['side', 1],
      KeyA: ['side', -1],
      ArrowLeft: ['side', -1],
    };
    const tk = tapKind[code];
    if (tk) {
      // HAND SELECTION: one tap to the right takes the right fist, one tap to the left takes the left one.
      // A tiny step is enough — the tap itself is the marker, no need to commit to a full sidestep.
      if (tk[0] === 'side') this.setHand(tk[1] > 0 ? 1 : 0);
      const now = performance.now();
      const prev = this.lastTap[code] ?? 0;
      this.lastTap[code] = now;
      if (now - prev < 260) {
        this.playerDash(tk[0], tk[1]);
        if (tk[0] === 'fwd') this.runLatch = true; // dash, then keep W held to break into a sprint
      }
    }
    switch (code) {
      case 'KeyP':
        this.tryAttack(p, 'grab');
        break;
      case 'KeyU':
        this.toggleRage();
        break;
      // ---------------- PANJER: HOLD A PUNCH TO LOAD IT ----------------
      // These keys stopped firing on the press. Pressing one starts a LOAD (the arm coils back into the pose the
      // punch is about to be thrown out of); the punch itself comes out on RELEASE, in `release()`. Held for a full
      // second it is a PANJER — 2× damage, 2× knockback. Everything that can take the arm away from the load is
      // checked every frame in updatePanjer.
      case 'KeyH':
      case 'KeyJ':
      case 'KeyC':
      case 'KeyK':
      case 'KeyV':
      case 'KeyX':
        // PANJER OTOMATIS: nothing to HOLD FOR — the punch comes out on the press, full, and keeping the button
        // down keeps it coming (see updateAutoFire). Without the mode the key loads instead.
        if (this.panjerMode) {
          p.autoFireKey = code; // the last punch button pressed is the one the spam repeat throws
          this.panjerMax(p, PANJER_KEYS[code]);
        } else this.beginPanjer(p, PANJER_KEYS[code], code);
        break;
      // L stays INSTANT — it is the reactive counter, the one punch that has to answer a fist already in flight.
      case 'KeyL':
        this.tryAttack(p, 'counter');
        break;
      case 'KeyQ': // TARGET SWITCH: head ↔ body (T does the same)
      case 'KeyT':
        this.toggleAim();
        break;
      case 'KeyR':
        // (KeyE is the Peek-a-Boo stance now, it is read in playerInput)
        this.tryOverdrive(p);
        break;
      case 'KeyN': // THE COMBO BUTTON: JAB-JAB-HOOK-HOOK-UPPERCUT → PUKULAN MEMATIKAN (see COMBO_SCRIPT)
        this.startNCombo();
        break;
      // ---------------- FREESTYLE ----------------
      // The show-off book (poses.ts) sits on its own keys: M B O Z 1 2 3 4 5 6 (N and Y are GAME buttons now — the
      // combo and the ALI STYLE stance — so their poses are reached by cycling the book with the GAYA button).
      case 'KeyM':
      case 'KeyB':
      case 'KeyO':
      case 'KeyZ':
      case 'Digit1':
      case 'Digit2':
      case 'Digit3':
      case 'Digit4':
      case 'Digit5':
      case 'Digit6': {
        const fs = freestyleByKey(code);
        if (fs) this.taunt(p, fs.id);
        break;
      }
      case 'Freestyle': // the touch button: cycle to the next move in the book
        this.taunt(p, (p.tauntStyle + 1) % FREESTYLE.length);
        break;
      case 'BracketRight':
        this.cycleFootwork(1);
        break;
      case 'BracketLeft':
        this.cycleFootwork(-1);
        break;
      case 'Digit0':
      case 'Backquote':
        this.toggleDirectionalHeadSnap();
        break;
      case 'Digit9':
        this.toggleNoSlowMoNormal();
        break;
    }
  }

  // ------------------------------------------------------------ round flow
  startRound(first = false) {
    if (this.hangar) this.hangar.g.visible = false;
    if (this.menuHero) {
      this.menuHero.root.visible = false;
      this.menuHeroPedestal.visible = false;
      this.menuScrimPlane.visible = false;
    }
    const p = this.player;
    const e = this.enemy;
    p.maxHp = this.getPlayerMaxHp();
    p.hp = p.maxHp;
    p.reset(0, 6.0, Math.PI);
    e.reset(0, -6.0, 0);
    for (const f of this.fighters()) {
      f.mode = 'taunt';
      f.robot.root.visible = true;
      f.robot.head.visible = true;
      for (const tr of f.trails) {
        tr.clear();
        tr.mesh.visible = true;
      }
    }
    this.roundTime = ROUND_TIME;
    this.timeUp = false;
    this.combo = 0;
    this.nComboIdx = -1;
    this.nComboT = 0;
    this.nComboCd = 0;
    this.nComboSeq = -1;
    this.stats = freshStats();
    this.decap.clear(); // any head torn off last round is bolted back on
    this.ripVictim = null;
    this.cine = null; // and the director hands the camera back to the operator
    this.meterReadyShown = false;
    this.ai = this.makeAi();
    this.timeScale = 1;
    this.slowT = 0;
    this.sfx.musicIntensity = 1;
    this.arena.setScreen(PLAYER_NAME, this.def.name, this.roundLabel(), '#4da3ff', this.ultra ? ULTRA_COLOR : this.def.color);
    if (first) this.beginWalk();
    else this.beginIntro(first);
  }

  // ------------------------------------------------------------------ ringCfg.bound WALK
  beginWalk() {
    this.phase = 'walk';
    this.phaseT = 0;
    this.walk = [];
    this.walkPyroT = 0;
    this.camInit = false;
    const mk = (f: Fighter, side: 1 | -1, lag: number, lateral: number, delay: number) => {
      const home = f.pos.clone();
      const homeYaw = f.yaw;
      const a = side > 0 ? 1.247 : 4.389; // the two aisles that face the corners (see arena.ts: aisles every 60° from 0.2 rad)
      const out = new THREE.Vector2(Math.cos(a), Math.sin(a));
      const perp = new THREE.Vector2(-out.y, out.x);
      const at = (r: number, l: number) => out.clone().multiplyScalar(r).addScaledVector(perp, l);
      const sh = entryShift();
      const from = at(34.0 + lag + sh, lateral); // in the mouth of the tunnel
      const mark = at(26.0 + lag * 0.5 + sh, lateral); // the end of the strut: from here he sprints
      const take = at(20.0 + sh, lateral * 0.8); // the lip of the launch wedge
      const land = at(10.2 + sh * 0.3, lateral * 0.6); // on the canvas, well inside the ropes
      f.reset(from.x, from.y, Math.atan2(-out.x, -out.y));
      f.y = -1.4; // the hall floor is 1.4 below the canvas
      f.mode = 'normal';
      f.tauntT = 0;
      f.swagger = -1;
      const d = delay;
      this.walk.push({
        f,
        from,
        mark,
        take,
        land,
        home,
        homeYaw,
        t: [0.6 + d, 3.7 + d, 4.55 + d, 5.75 + d, 6.3 + d, 7.6 + d, 8.9 + d],
        cue: 0,
        landed: false,
        raised: false,
        inward: out.clone().negate(),
        perp,
      });
    };
    mk(this.player, 1, 0, 0, 0);
    mk(this.enemy, -1, 0, 0, 0.35);
    this.showBanner('RING WALK', `${PLAYER_NAME}  VS  ${this.def.name}`, 'round', 2.4);
    // the announcer stays quiet at the gate: ATLAS is called ONCE, when he is actually IN the arena —
    // the pop is when he rises in the ring (see the beat below), not when the door first opens
    this.sfx.cheer(1);
    this.crowdRoar(1, 4.5);
    this.hype = 1;
    this.pyro(1);
    this.trauma = 0.2;
  }

  /** where a fighter is on its ring-walk track at time t: position, height, facing, flip and which beat it is in */
  updateWalk(dt: number) {
    const t = this.phaseT;
    this.hype = 1;
    const cur = { pos: new THREE.Vector2(), y: 0, yaw: 0, flip: 0, beat: 0, u: 0 };
    for (const w of this.walk) {
      const f = w.f;
      const prev = f.pos.clone();
      const prevY = f.y;
      this.walkAt(w, t, cur);
      f.pos.copy(cur.pos);
      f.y = cur.y;
      f.yaw = cur.yaw;
      f.flip = cur.flip;
      if (dt > 0) {
        f.vel.set((f.pos.x - prev.x) / dt, (f.pos.y - prev.y) / dt);
        f.vy = (f.y - prevY) / dt;
      }
      f.speed = f.vel.length();
      f.kb.set(0, 0);
      f.dash.set(0, 0);
      f.sprinting = cur.beat === 2;
      // THE STRUT is one continuous arm script driven by the walk's progress (see animateFighter): the gate pose
      // flows into it and it flows into the sprint — nothing ever snaps. `swagger` is its progress: 0 at the gate,
      // 1 at the end of the strut, then it fades out over the first strides of the sprint.
      if (cur.beat === 0) f.swagger = -1 + cur.u * 0.999; // the arms come up at the gate
      else if (cur.beat === 1) f.swagger = cur.u;
      else if (cur.beat === 2) f.swagger = 1 + Math.min(1, cur.u / 0.3);
      else f.swagger = 0;
      // the crowd cues of the strut: pyro + roar on each fist pump, sparks on the chest pound, a "look at him" on the point
      const cues = [0.2, 0.46, 0.7, 0.9];
      while (cur.beat === 1 && w.cue < cues.length && cur.u >= cues[w.cue]) {
        const k = w.cue++;
        if (k < 2) {
          const sgn = k === 0 ? 1 : -1;
          const px = f.pos.x + w.perp.x * sgn * 3.6;
          const pz = f.pos.y + w.perp.y * sgn * 3.6;
          this.fx.spark(new THREE.Vector3(px, f.y + 0.2, pz), 46, 13, 0xffd27a, new THREE.Vector3(0, 1, 0), 0.3, 1.6, 14);
          this.fx.spark(new THREE.Vector3(px, f.y + 0.2, pz), 20, 9, 0xffffff, new THREE.Vector3(0, 1, 0), 0.4, 1.2, 10);
          this.crowdRoar(0.9, 2.2);
          if (f === this.player || f === this.enemy) this.sfx.pyro(0.6);
        } else if (k === 2) {
          const cx = f.pos.x + Math.sin(f.yaw) * 0.9;
          const cz = f.pos.y + Math.cos(f.yaw) * 0.9;
          this.fx.spark(new THREE.Vector3(cx, f.y + 4.9, cz), 26, 7, 0xffd080, undefined, 0.8, 0.4, 12);
          this.sfx.hit(0.5);
          this.sfx.crackle(0.6);
          if (!f.isPlayer && f === this.enemy) this.sfx.say(`And the challenger... ${this.def.name}!`);
        } else {
          this.crowdRoar(1, 2.4); // the crowd pops on the point — but the announcer keeps his one clean call for the ring
        }
      }
      // THE FLIGHT: airborne, tucked for the flip; the lip of the wedge throws sparks as he leaves it
      if (cur.beat === 3) {
        if (f.state !== 'air') {
          f.state = 'air';
          f.tauntT = 0;
          // the push-off: the wedge takes the whole weight — sparks off the lip, a dust puff, a thud and a shake
          this.fx.spark(new THREE.Vector3(f.pos.x, f.y + 0.1, f.pos.y), 34, 9, 0xffd27a, new THREE.Vector3(-w.inward.x, 0.6, -w.inward.y), 0.5, 1.2, 12);
          this.fx.spark(new THREE.Vector3(f.pos.x, f.y + 0.1, f.pos.y), 22, 5, 0x9a9aa8, undefined, 1.2, 0.5, 4);
          this.sfx.step(2.0);
          this.sfx.servo();
          this.sfx.whoosh(1);
          this.crowdRoar(1, 2.2);
          if (f.isPlayer) {
            this.fovKick = 3;
            this.trauma = Math.min(1, this.trauma + 0.22);
          }
        }
        // the tuck follows the rotation: the knees come up as the turn whips and open out as it sheds speed —
        // one curve, so the shape of the body and the rate of the turn are the same thing (no floaty apex here,
        // the only slow motion in the entrance is the beat the landing takes)
        const fu = THREE.MathUtils.clamp((cur.u - FLIP_IN) / FLIP_SPAN, 0, 1);
        const sm = (a: number, b: number) => THREE.MathUtils.smoothstep(fu, a, b);
        f.pkTuck = Math.max(0.14, sm(0.0, 0.2) * (1 - sm(0.6, 0.96)));
      } else {
        if (f.state === 'air') f.state = 'idle';
        f.pkTuck += (0 - f.pkTuck) * (1 - Math.exp(-12 * dt));
      }
      // the last strides into the wedge: he loads up — hips drop, arms swing back — for the take-off
      const wantPre = cur.beat === 2 && cur.u > 0.78 ? 1 : 0;
      f.pkPre += (wantPre - f.pkPre) * (1 - Math.exp(-(wantPre > f.pkPre ? 12 : 16) * dt));
      if (cur.beat >= 4 && !w.landed) {
        // TONNES OF STEEL HIT THE CANVAS: the whole ring dips and every rope jolts, a shockwave and dust roll out
        // from under both boots, sparks jump, the camera takes the hit (a frame-freeze, then a beat of slow motion)
        w.landed = true;
        f.state = 'idle';
        f.vy = 0;
        f.pkLand = 1;
        f.pkTuck = 0;
        this.arena.canvasSlam(f.pos.x, f.pos.y, 3);
        const sy = Math.sin(f.yaw);
        const cy = Math.cos(f.yaw);
        for (const sgn of [-1, 1]) {
          const bx = f.pos.x + cy * sgn * 0.78 * f.scale;
          const bz = f.pos.y - sy * sgn * 0.78 * f.scale;
          this.fx.spark(new THREE.Vector3(bx, 0.15, bz), 30, 7, 0xb8bccb, undefined, 1.3, 0.6, 5);
          this.fx.spark(new THREE.Vector3(bx, 0.2, bz), 16, 10, 0xffc070, new THREE.Vector3(0, 0.7, 0), 0.6, 0.5, 12);
        }
        // both fists punch the canvas: a burst of hot sparks off each glove
        for (const sgn of [-1, 1]) {
          const fx0 = f.pos.x + sy * 1.0 * f.scale + cy * sgn * 1.05 * f.scale;
          const fz0 = f.pos.y + cy * 1.0 * f.scale - sy * sgn * 1.05 * f.scale;
          this.fx.spark(new THREE.Vector3(fx0, 0.25, fz0), 26, 11, 0xffb060, new THREE.Vector3(0, 0.8, 0), 0.8, 0.5, 14);
          this.fx.spark(new THREE.Vector3(fx0, 0.2, fz0), 14, 6, 0xffffff, undefined, 1.1, 0.35, 6);
        }
        this.fx.impactWave(new THREE.Vector3(f.pos.x, 0.35, f.pos.y), new THREE.Vector3(0, 1, 0), 0xdfe6ff, 5.2, 0.3);
        this.fx.spark(new THREE.Vector3(f.pos.x, 0.3, f.pos.y), 70, 8, 0x9ea3b4, undefined, 1.6, 0.9, 4); // the dust cloud
        this.sfx.hit(1.0);
        this.sfx.step(2.2);
        this.sfx.ropeSlam(0.9);
        this.crowdRoar(1, 3.2);
        this.hype = 1;
        if (f === this.player || f === this.enemy) this.pyro(0.7);
        if (f.isPlayer) {
          this.freeze = 0.04;
          this.slowScale = 0.36;
          this.slowT = 0.18;
          this.camBump = 0.5;
          this.fovKick = -5;
          this.trauma = Math.min(1, this.trauma + 0.6);
          this.showBanner(PLAYER_NAME, 'IS IN THE ringCfg.bound', 'round', 1.6);
        }
      }
      if (cur.beat === 4) {
        f.pkLand = 1; // the landing crouch is held dead still — planted, no wobble
      } else if (cur.beat >= 5) {
        f.pkLand += (0 - f.pkLand) * (1 - Math.exp(-(f.tauntT > 0 ? 12 : 7) * dt)); // one decisive drive up
      }
      if (cur.beat === 5 && !w.raised && cur.u > 0.12) {
        // up on his feet: arms up at the opponent
        w.raised = true;
        this.sfx.servo();
        this.taunt(f, 1);
        if (f.isPlayer) this.sfx.say(`${PLAYER_NAME}... is in the building!`);
      }
      if (cur.beat === 6 && f.tauntT > 0.15) f.tauntT = 0.15;
      this.tickTaunt(f, dt);
    }
    // a slow pyro trickle along the aisles keeps the entrance lit
    this.walkPyroT -= dt;
    if (this.walkPyroT <= 0 && t < this.walk[0].t[2]) {
      this.walkPyroT = 0.55;
      for (const w of this.walk) {
        if (w.f !== this.player && w.f !== this.enemy) continue;
        const r = 21 + Math.random() * 12 + entryShift();
        const sgn = Math.random() < 0.5 ? -1 : 1;
        const px = -w.inward.x * r + w.perp.x * sgn * 3.7;
        const pz = -w.inward.y * r + w.perp.y * sgn * 3.7;
        this.fx.spark(new THREE.Vector3(px, rampY(r) + 0.2, pz), 16, 9, 0xffc060, new THREE.Vector3(0, 1, 0), 0.25, 1.2, 10);
      }
    }
    if (t >= WALK_T) this.finishWalk();
  }

  /** end of the parade (or Enter/Space to skip it): everybody in his corner, the round intro takes over */
  finishWalk() {
    for (const w of this.walk) {
      w.f.reset(w.home.x, w.home.y, w.homeYaw);
      w.f.y = 0;
      w.f.tauntT = 0;
      w.f.swagger = 0;
      w.f.pkPre = 0;
      w.f.pkTuck = 0;
      w.f.pkLand = 0;
      w.f.flip = 0;
      w.f.sprinting = false;
      w.f.state = 'idle';
      w.f.mode = 'taunt';
    }
    this.walk = [];
    this.beginIntro(true);
  }

  beginIntro(first: boolean) {
    this.phase = 'intro';
    this.phaseT = 0;
    const tag = this.ultra ? 'ULTRA HARD · ' : '';
    const card = `${PLAYER_NAME}  VS  ${this.def.name}`;
    this.showBanner(`ROUND ${this.round}`, tag + (first ? card : `Skor ${this.wins[0]} - ${this.wins[1]}`), 'round', INTRO_COUNT[0] - 0.05);
    this.introStep = 0;
    this.sfx.bell(1);
    this.sfx.say(`Round ${['zero', 'one', 'two', 'three'][this.round] ?? this.round}`);
    this.sfx.cheer(0.5);
    this.camInit = false;
  }

  beginFight() {
    this.resetExposure(); // the walk-in lights are not the ring lights: start the ring shot neutral
    this.phase = 'fight';
    this.phaseT = 0;
    for (const f of this.fighters()) {
      f.mode = 'normal';
      f.tauntT = 0;
      f.glowBoost = 0;
    }
    this.showBanner('FIGHT!', '', 'fight', 1.0);
    this.sfx.say('Fight!');
    this.sfx.cheer(1);
    this.trauma = 0.55;
    this.fovKick = -4;
    this.hype = 0.65;
    this.pyro(0.8); // the corner towers fire as the fight starts

    // Pas "FIGHT!" apinya nyala besar dari keempat nozel sudut tiang arena!
    this.arena.fireCornerPyro(1.0, 1.8, 'blast');
    this.sfx.flameBlast(1.0);
    for (const p of this.arena.cornerNozzles) {
      this.fx.spark(p, 36, 12, 0xffd27a, new THREE.Vector3(0, 1.2, 0), 0.35, 1.7, 14);
      this.fx.spark(p, 18, 9, 0xffffff, new THREE.Vector3(0, 1.0, 0), 0.3, 1.1, 10);
    }
  }

  endRound(winner: Fighter, how: 'ko' | 'time') {
    this.phase = 'ko';
    this.phaseT = 0;
    const idx = winner.team;
    const youWon = winner.team === 0;
    this.wins[idx]++;
    winner.mode = 'victory';
    winner.glowBoost = 1.5;
    const who = youWon ? 'Kamu' : this.def.name;
    if (how === 'ko') {
      this.showBanner('K.O.!', `${who} menang ronde ini`, 'ko', 3.2);
    } else {
      this.timeUp = true;
      this.showBanner('WAKTU HABIS', `${who} unggul poin`, 'ko', 3.0);
      this.sfx.bell(3);
      this.sfx.say('Time');
    }
    this.sfx.cheer(1);
    this.hype = 1;
    this.sfx.musicIntensity = 0.5;
    // the arena erupts when a round ends: a huge roar when YOU win, a big "ohhh" when the champion wins
    this.crowdRoar(youWon ? 1 : 0.7, how === 'ko' ? 4.2 : 3.4);
    if (youWon) this.pyro(1); // victory fireworks
  }

  afterRound() {
    if (this.wins[0] >= 2 || this.wins[1] >= 2) {
      this.phase = 'matchEnd';
      this.phaseT = 0;
      this.result = this.wins[0] >= 2 ? 'win' : 'lose';
      this.banner = null;
      // the final result: a long, thunderous ovation for a win; a sympathetic, shorter one for a loss
      this.lastRoar = 0;
      this.crowdRoar(this.result === 'win' ? 1 : 0.55, this.result === 'win' ? 5.5 : 3.2);
      if (this.result === 'win') {
        this.pyro(1);
        window.setTimeout(() => this.pyro(0.9), 700);
        window.setTimeout(() => this.pyro(1), 1500);
      }
      this.sfx.say(this.result === 'win' ? 'Victory!' : 'Defeated');
      return;
    }
    this.round++;
    this.startRound();
  }

  /** PYRO: all four corner towers and four ring corner nozzles shoot flame jets & sparks into the air */
  pyro(level: number) {
    for (const t of this.arena.towers) {
      this.fx.spark(t, 28 + Math.floor(level * 40), 10 + level * 8, 0xffd27a, new THREE.Vector3(0, 1, 0), 0.3, 1.7, 14);
    }
    this.arena.fireCornerPyro(level, 1.4, 'blast');
    for (const p of this.arena.cornerNozzles) {
      this.fx.spark(p, 24 + Math.floor(level * 20), 8 + level * 6, 0xffbe50, new THREE.Vector3(0, 1.1, 0), 0.35, 1.4, 12);
    }
    this.sfx.pyro(level);
    this.trauma = Math.min(1, this.trauma + 0.1 * level);
  }

  /** the whole arena reacts: a roar + applause, the crowd jumps up, and the camera feels it a little */
  crowdRoar(level: number, dur = 2.6) {
    const now = performance.now();
    if (now - this.lastRoar < 700 && level < 0.95) return;
    this.lastRoar = now;
    this.sfx.roar(level, dur);
    this.hype = Math.max(this.hype, Math.min(1, 0.55 + level * 0.45));
  }

  showBanner(text: string, sub: string, kind: string, dur: number) {
    this.banner = { id: ++this.bannerId, text, sub, kind };
    this.bannerT = dur;
  }

  // ------------------------------------------------------------ main loop
  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const frameMs = now - this.last;
    const raw = Math.min(0.066, frameMs / 1000);
    this.last = now;
    this.fpsEma += (Math.min(frameMs, 250) - this.fpsEma) * 0.08;
    // Watch frame pacing, not just average FPS: sustained frames beyond 17.8 ms step a rung before the fight feels
    // uneven, while a few isolated browser-scheduler spikes are absorbed by the half-second window.
    this.fpsT += frameMs / 1000;
    this.frames++;
    if (frameMs > 17.8) this.longFrames++;
    if (this.fpsT >= 0.5) {
      this.fps = this.frames / Math.max(0.05, this.fpsT);
      if (this.qWarm > 0) {
        // the first couple of seconds are not representative: every material in the hall compiles on its first
        // frame and the arena uploads its textures. Judging the GPU on that would drop a rung for nothing.
        this.qWarm -= this.fpsT;
        this.qSteady = 0;
      } else {
        this.adaptQuality(this.longFrames / Math.max(1, this.frames));
      }
      this.fpsT = 0;
      this.frames = 0;
      this.longFrames = 0;
    }
    this.step(raw);
  };

  /**
   * THE 60 FPS GOVERNOR. Called twice a second with the share of frames that missed the beat in that window.
   * A bad window drops a rung immediately (a soft frame rate is always worse than a softer picture), a good one
   * slowly climbs back — never onto a rung that already failed on this machine.
   */
  adaptQuality(badFrameShare: number) {
    if (!this.qAuto) return;
    const ms = this.fpsEma;
    this.qCooldown = Math.max(0, this.qCooldown - 0.5);
    const last = this.qTier >= QUALITY_TIERS.length - 1;
    if (badFrameShare > 0.18 || ms > 19.2) {
      this.qSteady = 0;
      if (this.qCooldown > 0 || last) return;
      this.qTierFailed = this.qTier;
      this.applyTier(this.qTier + 1);
      // react quickly to a 60 Hz miss, but keep a short cooldown so one noisy window cannot cascade the ladder
      this.qCooldown = ms > 27 || badFrameShare > 0.45 ? 0.8 : 1.6;
      return;
    }
    if (badFrameShare < 0.05 && ms < 18.0 && this.qTier > 0 && this.qTier - 1 !== this.qTierFailed) {
      // near-60 pacing with real headroom for five seconds: climb one rung back up
      this.qSteady += 0.5;
      if (this.qSteady >= 5) {
        this.qSteady = 0;
        this.applyTier(this.qTier - 1);
        this.qCooldown = 5;
      }
    } else {
      this.qSteady = 0;
    }
  }

  applyTier(tier: number, force = false) {
    const next = THREE.MathUtils.clamp(Math.round(tier), 0, QUALITY_TIERS.length - 1);
    if (next === this.qTier && !force) return;
    this.qTier = next;
    const cfg = this.tierCfg();
    let needsResize = false;
    // 1 · HDR multisampling; the grade pass FXAA still cleans the edges when samples are off
    if (this.composer) {
      for (const rt of [this.composer.renderTarget1, this.composer.renderTarget2]) {
        if (rt.samples !== cfg.samples) {
          rt.samples = cfg.samples;
          rt.dispose();
        }
      }
    }
    // 3 · shadow detail comes down before the final rung touches HD render scale
    if (this.arena) {
      const sh = this.arena.keyLight.shadow;
      if (sh.mapSize.x !== cfg.shadow) {
        sh.mapSize.set(cfg.shadow, cfg.shadow);
        if (sh.map) {
          sh.map.dispose();
          sh.map = null;
        }
      }
    }
    // 4 · preserve full render scale through KINERJA; only RINGAN gives up a small amount of pixel density
    if (force || cfg.scale !== this.quality) {
      this.quality = cfg.scale;
      this.renderer.setPixelRatio(this.pixelRatio());
      needsResize = true;
    }
    // 5 · bloom never disappears; only its mip resolution steps down, and that change needs a pass resize too
    if (cfg.bloomScale !== this.bloomScale) {
      this.bloomScale = cfg.bloomScale;
      needsResize = true;
    }
    if (this.bloom) this.bloom.enabled = cfg.bloom && this.bloomMode !== 'off';
    if (needsResize && this.composer) this.resize();
  }

  /** the render scale this device is allowed to run at, on top of the current tier */
  pixelRatio() {
    return Math.min(window.devicePixelRatio || 1, this.dprCap) * this.quality;
  }

  tierCfg() {
    return QUALITY_TIERS[this.qTier];
  }

  /**
   * A 4K panel at dpr 2 can push eight million HDR pixels through the scene and post passes. Cap the initial pixel
   * budget near three million, then let the governor shed reflections and shadow cost before it ever lowers HD scale.
   */
  static bootDprCap() {
    try {
      const dpr = window.devicePixelRatio || 1;
      const w = window.innerWidth || 1280;
      const h = window.innerHeight || 720;
      const budget = 1.6e6; // ensure frame easily hits rock-solid 60 FPS even on integrated/mobile GPU
      return Math.max(0.75, Math.min(dpr, 1.35, Math.sqrt(budget / Math.max(1, w * h))));
    } catch {
      return 1.15;
    }
  }

  /**
   * WHICH RUNG TO START ON. Reading the GPU string is the only honest way to know before a single frame has been
   * drawn; software rasterizers go straight to the bottom, phone-class GPUs start low, and the governor takes it
   * from there in the first second of play.
   */
  bootTier(): number {
    let gpu = '';
    try {
      const gl = this.renderer.getContext();
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      if (ext) gpu = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '').toLowerCase();
    } catch {
      /* the string is a privilege, not a right */
    }
    if (/swiftshader|llvmpipe|software|basic render|mesa offscreen/.test(gpu)) return 4;
    if (/mali|adreno|powervr|videocore|vivante|tegra/.test(gpu)) return 3;
    const cores = navigator.hardwareConcurrency || 4;
    const px = (window.innerWidth || 1280) * (window.innerHeight || 720) * Math.min(window.devicePixelRatio || 1, 2) ** 2;
    if (/intel/.test(gpu) && /(hd|uhd|iris|graphics)/.test(gpu)) return px > 3.2e6 ? 2 : 1;
    if (cores <= 2) return 3;
    if (cores <= 4 && px > 3.2e6) return 2;
    // Auto mode starts one rung below maximum even on a known discrete GPU; it can promote after stable headroom,
    // but it never makes the first fight pay for two live reflections and full-resolution MSAA by default.
    if (/apple m[1-9]|nvidia|geforce|rtx|gtx|radeon|rx ?\d|arc a\d|quadro/.test(gpu)) return 1;
    return gpu ? 1 : cores > 6 ? 1 : 2;
  }

  /** the manual exposure step (0.50 … 1.60), remembered between visits */
  setBrightness(b: number) {
    const v = Math.max(0.5, Math.min(1.6, Number(b) || 1.0));
    if (Math.abs(v - this.bright) < 0.005) return;
    this.bright = v;
    try {
      localStorage.setItem(LS_BRIGHT, String(v));
    } catch {
      /* ignore */
    }
    if (this.grade) {
      this.grade.uniforms.exposure.value = 1.0 * this.aeGain * this.bright;
    }
    this.resetExposure();
    this.emitHud(true);
  }

  /** the graphics mode the player pinned (auto = the governor), remembered between visits */
  setGfxMode(m: GfxMode) {
    this.qMode = m;
    this.qAuto = m === 'auto';
    try {
      localStorage.setItem(LS_GFX, m);
    } catch {
      /* ignore */
    }
    if (!this.qAuto) this.applyTier(gfxTier(m));
    else this.applyTier(this.bootTier());
    this.emitHud(true);
  }

  /** the color vibrance & saturation step (0.95 … 1.70), remembered between visits */
  setSaturation(s: number) {
    const v = (SAT_STEPS as readonly number[]).includes(s as any) ? s : DEFAULT_SAT;
    this.sat = v;
    try {
      localStorage.setItem(LS_SAT, String(v));
    } catch {
      /* ignore */
    }
    if (this.grade) {
      this.grade.uniforms.sat.value = this.sat;
    }
    this.emitHud(true);
  }

  /** toggle enhanced high-definition PBR metallic/carbon textures on robot chassis */
  setTextureEnhance(enabled: boolean) {
    this.textureEnhance = enabled;
    try {
      localStorage.setItem(LS_TEX, String(enabled));
    } catch {
      /* ignore */
    }
    this.menuHero?.setEnhancedTextures(enabled);
    this.player?.robot.setEnhancedTextures(enabled);
    this.enemy?.robot.setEnhancedTextures(enabled);
    for (const cached of this.enemyCache.values()) {
      cached.robot.setEnhancedTextures(enabled);
    }
    this.emitHud(true);
  }

  /** set bloom intensity from 0 to 50 percent */
  setBloomPercent(pct: number) {
    const v = Math.max(0, Math.min(50, Math.round(Number(pct) || 0)));
    this.bloomPercent = v;
    this.bloomMode = v <= 0 ? 'off' : v <= 20 ? 'smooth' : 'normal';
    try {
      localStorage.setItem(LS_BLOOM_PCT, String(v));
      localStorage.setItem(LS_BLOOM, this.bloomMode);
    } catch {
      /* ignore */
    }
    if (this.bloom) {
      if (v <= 0) {
        this.bloom.enabled = false;
        this.bloom.strength = 0;
        this.smoothBloomStrength = 0;
      } else {
        this.bloom.enabled = this.tierCfg().bloom;
        const target = (v / 50) * 0.40;
        this.bloom.strength = target;
        this.smoothBloomStrength = target;
      }
    }
    this.emitHud(true);
  }

  setBloomMode(mode: BloomMode) {
    this.bloomMode = mode;
    const pct = mode === 'off' ? 0 : mode === 'smooth' ? 18 : 30;
    this.setBloomPercent(pct);
  }

  /**
   * Reset all visual configurations back to standard neutral defaults:
   * Normal Saturation (1.15), Preset Brightness (150% / 1.5), Standard Textures, Preset Bloom (2%), Auto 60 FPS
   */
  resetVisualsToNormal() {
    this.setBrightness(DEFAULT_BRIGHTNESS);
    this.setSaturation(NORMAL_SAT);
    this.setTextureEnhance(false);
    this.setBloomPercent(DEFAULT_BLOOM_PCT);
    this.setGfxMode('auto');
    this.emitHud(true);
  }

  /** set arena flame pyro nozzle placement: 'ring_posts' (tiang ring) or 'steel_platform' (ujung platform baja) */
  setPyroPlacement(p: PyroPlacement) {
    this.arena.setPyroPlacement(p);
    this.emitHud(true);
  }

  getPyroPlacement(): PyroPlacement {
    return this.arena.getPyroPlacement();
  }

  /** The one-pixel iris readback is asynchronous so it cannot stall the render thread on a GPU/CPU sync point. */
  sampleScene() {
    if (this.aeDead || this.aePending) return;
    this.aePending = true;
    void this.renderer.readRenderTargetPixelsAsync(this.meter.rt, 0, 0, 1, 1, this.aeBuf).then(() => {
      const lum = (0.2126 * this.aeBuf[0] + 0.7152 * this.aeBuf[1] + 0.0722 * this.aeBuf[2]) / 255;
      this.aeKey += (THREE.MathUtils.clamp(lum, 0.001, 1.2) - this.aeKey) * 0.4;
      this.aePending = false;
    }).catch(() => {
      this.aeDead = true; // no asynchronous readback on this driver — keep the fixed exposure
      this.aePending = false;
    });
  }

  /** the exposure the grade pass is told to use: the fixed base, times the gentle auto-exposure correction */
  updateAutoExposure(dt: number) {
    this.aeHold = Math.max(0, this.aeHold - dt);
    if (this.aeHold > 0) {
      // a cinematic flash or a white-out IS the point of the shot: do not let the iris fight it
      this.aePause = Math.min(1.4, this.aePause + dt * 3);
      return;
    }
    this.aePause = Math.max(0, this.aePause - dt * 0.9);
    if (this.aePause > 0) return;
    // Asymmetric ON PURPOSE: a hot frame gets pulled down, a dark one is left exactly as it was lit. An
    // auto-exposure that also brightens is how a night scene ends up looking like day.
    const key = this.aeKey / Math.max(0.001, this.bright); // normalised: the slider is not a lighting change
    const want = THREE.MathUtils.clamp(0.25 / Math.max(0.02, key), 0.78, 1.0);
    this.aeGain += (want - this.aeGain) * (1 - Math.exp(-1.6 * dt));
  }

  step(raw: number) {
    if (!this.paused) {
      if (this.freeze > 0) {
        this.freeze -= raw;
      } else if (this.slowT > 0) {
        this.slowT -= raw;
        this.timeScale = this.slowScale;
      } else {
        // ONE CLOCK FOR A FALL: a knock-down runs in REAL TIME. A launch no longer triggers slow-mo at all (see the
        // hit feedback), so the flight, the landing and the collapse are one continuous simulation at 1×; and if a
        // slow-mo from something else is still winding down, it eases out gently instead of snapping while a body
        // is still settling on the canvas.
        const inFight = this.phase === 'fight' || this.phase === 'ko';
        const settling = inFight && this.fighters().some((f) => f.state === 'air' || ((f.state === 'ko' || f.state === 'down') && f.fallS.x < 0.97));
        this.timeScale += (1 - this.timeScale) * (1 - Math.exp(-(settling ? 5 : 16) * raw));
      }
      const dt = this.freeze > 0 ? 0 : raw * this.timeScale;
      this.time += raw;
      if (this.phase === 'menu') {
        this.trauma = 0;
        this.camBump = 0;
        this.camPush = 0;
        this.fovKick = 0;
        this.camImp.set(0, 0, 0);
        this.camImpVel.set(0, 0, 0);
        this.flashAmt = 0;
      }
      if (dt > 0) {
        this.simulate(dt);
        this.decap.update(dt, this.fx); // torn heads tumble & cables keep shorting out
      }
      this.updateAnimations(dt);
      if (this.freeze > 0 && this.frozenFighter) {
        const f = this.frozenFighter;
        const wave = Math.sin(this.freeze * 78) * 0.042;
        f.robot.root.position.x += Math.sin(f.yaw) * f.hitF * wave + Math.cos(f.yaw) * f.hitL * wave;
        f.robot.root.position.z += Math.cos(f.yaw) * f.hitF * wave - Math.sin(f.yaw) * f.hitL * wave;
      }
      this.fx.update(raw * Math.max(0.35, this.timeScale), this.camera);
      this.updateCamera(raw, dt); // the cinematic beats run on world time, so they slow down with the action
      this.updateWarn();
      this.focus.set((this.player.pos.x + this.enemy.pos.x) / 2, 3.4, (this.player.pos.y + this.enemy.pos.y) / 2);
      if (this.phase !== 'menu') {
        // the hero followspots ride the fighters' feet — from the walk-in, through the fight, to the count
        this.arena.track(this.player.robot.root.position, this.enemy.robot.root.visible ? this.enemy.robot.root.position : null);
        this.arena.update(this.time, raw, this.hype, this.focus, this.camera);
      }
      this.hype = Math.max(0.15, this.hype - raw * 0.12);
      if (this.bannerT > 0) {
        this.bannerT -= raw;
        if (this.bannerT <= 0) this.banner = null;
      }
      this.flashAmt = Math.max(0, this.flashAmt - raw * 3.2);
      this.flashEl.style.opacity = String(Math.min(1, this.flashAmt));
    }
    this.grade.uniforms.time.value = this.time;
    this.grade.uniforms.sat.value = this.sat;
    // The 1×1 meter pass only runs when a fresh exposure sample is due outside intense combat
    const canSample = !this.aeDead && !this.aePending && this.phase !== 'fight';
    this.meter.enabled = canSample && this.aeFrames >= 23;
    this.composer.render();
    // the iris runs on world time so it never counts a paused frame, and the flash hold keeps a strobe a strobe
    this.aeHold = Math.max(this.aeHold, this.flashAmt * 0.5 + (this.phase === 'intro' || this.phase === 'matchEnd' ? 0.3 : 0));
    this.updateAutoExposure(Math.min(0.05, raw));
    this.aeFrames++;
    if (this.aeFrames >= 24) {
      this.aeFrames = 0;
      if (canSample) this.sampleScene();
    }
    this.grade.uniforms.exposure.value = 1.0 * this.aeGain * this.bright;
    // ...and the top-end limiter rides along with it: the hotter the frame, the harder the ceiling
    this.grade.uniforms.guard.value = THREE.MathUtils.clamp((this.aeKey / Math.max(0.001, this.bright) - 0.34) / 0.3, 0, 1);
    this.emitHud(false);
  }

  /**
   * ATTACK INDICATOR (the thing God of War calls an enemy attack indicator): while an enemy attack is winding up, a ring
   * shrinks onto a DODGE button prompt over its head. YELLOW = normal strike, RED = cannot be blocked (grab / Overdrive),
   * GREEN = you already dodged this one. Press the button before the ring closes.
   */
  updateWarn() {
    const e = this.enemy;
    const p = this.player;
    const m = e.move;
    let live = this.phase === 'fight' && e.state === 'attack' && !!m && !e.impacted && p.state !== 'ko' && p.state !== 'down';
    if (live && m && p.pos.distanceTo(e.pos) > (m.reach + 3.5) * e.scale) live = false;
    let v: THREE.Vector3 | null = null;
    if (live) {
      this.camera.updateMatrixWorld();
      v = new THREE.Vector3(e.pos.x, 6.7 * e.scale + e.y, e.pos.y).project(this.camera);
      if (v.z > 1) live = false;
    }
    if (!live || !m || !v) {
      if (this.warnOn) {
        this.warnOn = false;
        this.warnEl.style.display = 'none';
      }
      return;
    }
    // game-seconds until the strike lands = what is left of the warning + the travel of the strike itself
    const from = e.tellT > 0 ? m.strikeAt * 0.85 : e.moveT;
    const remain = Math.max(0, e.tellT) + Math.max(0, m.impact - from) * e.tscale * PACE;
    if (this.warnSeq !== e.moveSeq) {
      this.warnSeq = e.moveSeq;
      this.warnTotal = Math.max(0.25, remain);
      this.sfx.warn(UNBLOCKABLE.includes(m.id));
    }
    const ok = p.dodgeFor === e.moveSeq;
    const red = m.id === 'grab';
    const kind = ok ? 'warn-ok' : red ? 'warn-red' : 'warn-yellow';
    const touchUi = typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches;
    const keyName = touchUi ? '◎' : 'G';
    if (!this.warnOn || this.warnKind !== kind) {
      this.warnOn = true;
      this.warnKind = kind;
      this.warnEl.className = `warn ${kind}`;
      this.warnEl.style.display = 'block';
      this.warnTag.textContent = ok ? '✔ AMAN!' : red ? `⚠ BANTINGAN — HINDAR [${keyName}]!` : `⚡ HINDAR [${keyName}] / LINDUNG [SPACE]!`;
    }
    const u = Math.max(0, Math.min(1, remain / this.warnTotal)); // 1 → 0 as the strike approaches
    this.warnTag.style.opacity = String(0.85 + (1 - u) * 0.15);
  }

  simulate(dt: number) {
    this.phaseT += dt;
    for (const f of this.fighters()) f.animT += dt;
    this.trauma = Math.max(0, this.trauma - dt * 2.3);
    this.fovKick *= Math.exp(-9 * dt);

    switch (this.phase) {
      case 'menu':
        this.hype = Math.max(this.hype, 0.45);
        break;
      case 'walk':
        this.updateWalk(dt);
        break;
      case 'intro': {
        // PRE-FIGHT SHOW: both machines throw a cocky show-off move at each other, then settle into the guard for
        // the 3 · 2 · 1 — sparks, servo barks and the crowd are the same one-shots the in-fight taunts use.
        const p = this.player;
        const e = this.enemy;
        if (this.introStep === 0 && this.phaseT >= INTRO_TAUNT_AT) {
          this.introStep = 1;
          p.mode = 'normal';
          e.mode = 'normal';
          const book = [10, 0, 10, 1, 10, 4, 10, 6]; // the fist clash leads; the others keep the rematches fresh
          const ps = book[(this.round * 2) % book.length];
          const es = book[(this.round * 2 + 1 + this.oppIndex) % book.length];
          this.taunt(p, ps);
          this.taunt(e, es);
          this.crowdRoar(0.7, 2.0);
          this.hype = Math.max(this.hype, 0.5);
        }
        for (let k = 0; k < INTRO_COUNT.length; k++) {
          if (this.introStep === k + 1 && this.phaseT >= INTRO_COUNT[k]) {
            this.introStep = k + 2;
            const n = 3 - k;
            this.showBanner(String(n), k === 2 ? 'SIAP…' : '', 'count', 0.7);
            this.sfx.tick(1);
            this.sfx.say(String(n));
            this.fovKick = -1.2;

            // Nozel api pyro: letupan api dan percikan saat hitungan 3, 2, 1!
            const puffLevel = 0.5 + k * 0.2;
            this.arena.fireCornerPyro(puffLevel, 0.42, 'puff');
            this.sfx.pyroPuff(puffLevel);
            for (const p of this.arena.cornerNozzles) {
              this.fx.spark(p, 16 + k * 8, 8 + k * 2, 0xffbe50, new THREE.Vector3(0, 1, 0), 0.35, 0.6, 12);
            }

            if (k === 2) {
              // the last count: show over — every guard snaps up
              for (const f of this.fighters()) f.tauntT = Math.min(f.tauntT, 0.12);
            }
          }
        }
        for (const f of this.fighters()) this.tickTaunt(f, dt);
        if (this.phaseT > INTRO_T) this.beginFight();
        break;
      }
      case 'fight': {
        this.roundTime -= dt;
        if (this.roundTime <= 0) {
          const pr = this.player.hp / this.player.maxHp;
          const er = this.enemy.hp / this.enemy.maxHp;
          this.endRound(pr >= er ? this.player : this.enemy, 'time');
          break;
        }
        if (this.starMode) {
          const e = this.enemy;
          const p = this.player;
          const open = e.state === 'stagger' || (e.state === 'attack' && !!e.move && !e.impacted) || e.state === 'air' || e.state === 'down';
          if (starShouldFireOd(p.meter, open, p.stam) && p.state === 'idle' && p.dodgeT <= 0) this.tryOverdrive(p);
        }
        this.comboT -= dt;
        if (this.comboT <= 0) this.combo = 0;
        this.playerInput();
        this.updatePanjer(dt);
        this.updateNCombo(dt);
        this.updateEnemyAI(dt);
        for (const f of this.fighters()) this.updateFighter(f, this.foeOf(f), dt);
        this.separate();
        break;
      }
      case 'ko':
        for (const f of this.fighters()) {
          f.wish.set(0, 0);
          f.blocking = false;
        }
        this.player.ippo = false;
        this.player.queued = null;
        for (const f of this.fighters()) this.updateFighter(f, this.foeOf(f), dt);
        this.separate();
        if (this.phaseT > (this.timeUp ? 3.2 : 4.2)) this.afterRound();
        break;
      case 'matchEnd':
        break;
    }
  }

  // ------------------------------------------------------------ input -> player
  dirKeys() {
    const k = this.keys;
    const fwd = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
    const lat = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
    return { fwd, lat };
  }

  toward(a: Fighter, b: Fighter) {
    const v = new THREE.Vector2(b.pos.x - a.pos.x, b.pos.y - a.pos.y);
    const l = v.length() || 1;
    return v.multiplyScalar(1 / l);
  }

  /**
   * PANJER — a strike key went DOWN. Nothing is thrown yet: the load starts here, and the punch itself comes out of
   * `firePanjer` when the button is released. The newest key wins, so the button you are actually holding is the
   * one that is loading.
   */

  view = newFrame();
  spillDir = new THREE.Vector3();
  spillPts: number[] = [];
  spillPads: number[] = [];
  spillD = new THREE.Vector3();
  ripS: RipOut = {
    pos: new THREE.Vector3(),
    look: new THREE.Vector3(),
    dir: new THREE.Vector3(0, 0, 1),
    fov: 46,
    roll: 0,
    blend: 0,
    spill: 0,
    push: 0,
    phase: 'snap',
  };
  /**
   * How far outside the frame the fighters are: 1 = exactly at the edge, > 1 = spilling out. Head height and feet
   * of both robots are checked through the lens that is being aimed right now.
   */
  get aspect() {
    return this.container.clientWidth / Math.max(1, this.container.clientHeight);
  }

  /** call a cinematic beat. `at` is the point to shoot, `dir` the direction the blow travelled. */
  popup(p: THREE.Vector3, text: string, cls: string) {
    const v = p.clone().project(this.camera);
    if (v.z > 1 || v.z < -1) return;
    const h = this.container.clientHeight;
    const now = performance.now();
    let lane = this.popLanes.findIndex((t) => t <= now);
    if (lane < 0) lane = this.popLanes.indexOf(Math.min(...this.popLanes));
    this.popLanes[lane] = now + 1000;
    const el = document.createElement('div');
    el.className = `popup pop-left ${cls}`;
    el.textContent = text;
    // 232px clears the left HUD stack (the player plate and the TANGAN/TARGET/CTR panel); from there the lanes run
    // down the column in 40px steps. Five lanes is more than a full 4-hit combo + its damage number.
    el.style.top = `${Math.max(232, h * 0.33) + lane * 40}px`;
    this.popupLayer.appendChild(el);
    window.setTimeout(() => el.remove(), 1100);
  }

  emitHud(force: boolean) {
    const now = performance.now();
    if (!force && now - this.lastHud < 60) return;
    this.lastHud = now;
    this.onHud({
      phase: this.phase,
      round: this.round,
      timeLeft: Math.max(0, Math.ceil(this.roundTime)),
      pHp: this.player.hp,
      pMax: this.player.maxHp,
      eHp: this.enemy.hp,
      eMax: this.enemy.maxHp,
      stam: this.player.stam,
      gassed: isGassed(this.player.stam),
      eGassed: isGassed(this.enemy.stam),
      eWhiff: this.enemy.whiffT,
      star: this.starMode,
      autoGuard: this.player.autoGuard,
      meter: this.player.meter,
      ali: this.aliStyle,
      panjerMode: this.panjerMode,
      panjer: this.player.panjerId ? panjerCharge(this.player.panjerHold) : 0,
      panjerMul: panjerLabel(panjerPower(this.player.panjerHold)).slice(1),
      panjerReady: this.player.panjerReady && !!this.player.panjerId,
      nCombo: this.nComboIdx,
      nComboLocked: this.nComboCd > 0,
      combo: this.combo,
      stats: this.stats,
      wins: [...this.wins] as [number, number],
      eName: this.def.name,
      eTitle: this.def.title,
      eColor: this.def.color,
      banner: this.banner,
      paused: this.paused,
      result: this.result,
      oppIndex: this.oppIndex,
      ultra: this.ultra,
      fw: this.fwMul,
      cam: this.camMode,
      iq: this.iq,
      ePlan: this.iq >= STRATEGIST && this.phase === 'fight' ? PLAN_LABEL[this.ai.plan] : '',
      roll: this.player.rollCharge,
      ippo: this.player.ippo,
      hand: this.player.hand,
      handFlash: this.player.handT,
      parry: this.player.state === 'attack' && this.player.move?.id === 'counter' && this.player.moveT <= PARRY_ACTIVE,
      parryCd: this.player.counterCd,
      aim: this.player.aim,
      aimMode: this.player.aimMode,
      aimFlash: this.player.aimT,
      rage: this.player.rage,
      rageFlash: this.player.rageFlash,
      heroPose: this.heroPose,
      helmetSkin: this.helmetSkin,
      gloveSkin: this.gloveSkin,
      armorSkin: this.armorSkin,
      isZeus: !!(this.player.robot.isZeus || (this.helmetSkin === 1 && this.armorSkin === 1)),
      fps: this.fps,
      gfx: this.tierCfg().name,
      gfxMode: this.qMode,
      bright: this.bright,
      sat: this.sat,
      textureEnhance: this.textureEnhance,
      bloomMode: this.bloomMode,
      bloomPercent: this.bloomPercent,
      pyroPlacement: this.arena.getPyroPlacement(),
      directionalHeadSnap: this.directionalHeadSnap,
      noSlowMoNormal: this.noSlowMoNormal,
      allOverdrivePunch: this.allOverdrivePunch,
    });
  }

  capturePortrait(w = 240, h = 320, frame: 'bust' | 'torso' = 'bust', cutout = false) { return _capturePortrait(this, w, h, frame, cutout); }
  captureOpponentPortrait(idx: number, w = 420, h = 520, frame: 'bust' | 'torso' = 'torso', cutout = true) { return _captureOpponentPortrait(this, idx, w, h, frame, cutout); }
  walkAt(w: WalkTrack, t: number, out: { pos: THREE.Vector2; y: number; yaw: number; flip: number; beat: number; u: number }) { return _walkAt(this, w, t, out); }
  beginPanjer(f: Fighter, id: MoveId, key: string | null) { return _beginPanjer(this, f, id, key); }
  firePanjer(f: Fighter) { return _firePanjer(this, f); }
  togglePanjerMode() { return _togglePanjerMode(this); }
  setPanjerMode(on: boolean) { return _setPanjerMode(this, on); }
  updatePanjer(dt: number) { return _updatePanjer(this, dt); }
  updateAutoFire() { return _updateAutoFire(this); }
  playerInput() { return _playerInput(this); }
  toggleRage() { return _toggleRage(this); }
  playerDodge() { return _playerDodge(this); }
  taunt(f: Fighter, style = 0) { return _taunt(this, f, style); }
  tauntBack(fs: { id: number }) { return _tauntBack(this, fs); }
  fsCue(f: Fighter, s: string) { return _fsCue(this, f, s); }
  tauntRaise(f: Fighter) { return _tauntRaise(this, f); }
  tauntBeat(f: Fighter) { return _tauntBeat(this, f); }
  tauntClash(f: Fighter) { return _tauntClash(this, f); }
  perfectDodge(d: Fighter, m?: Move) { return _perfectDodge(this, d, m); }
  setHand(h: 0 | 1) { return _setHand(this, h); }
  toggleAim() { return _toggleAim(this); }
  parryCounter(d: Fighter, a: Fighter, m: Move) { return _parryCounter(this, d, a, m); }
  playerDash(kind: 'fwd' | 'back' | 'side', sign: number) { return _playerDash(this, kind, sign); }
  startDodge(f: Fighter, dir: THREE.Vector2, kind: 'evade' | 'fwd' | 'back' | 'side' = 'evade') { return _startDodge(this, f, dir, kind); }
  tryOverdrive(p: Fighter) { return _tryOverdrive(this, p); }
  toggleAliStyle() { return _toggleAliStyle(this); }
  startNCombo() { return _startNCombo(this); }
  breakNCombo(msg = '') { return _breakNCombo(this, msg); }
  updateNCombo(dt: number) { return _updateNCombo(this, dt); }
  tryAttack(f: Fighter, id: MoveId) { return _tryAttack(this, f, id); }
  startMove(f: Fighter, id: MoveId, chain = false) { return _startMove(this, f, id, chain); }
  canCancel(f: Fighter) { return _canCancel(this, f); }
  makeAi() { return _makeAi(this); }
  get strat() { return _strat(this); }
  enemyReact(m: Move) { return _enemyReact(this, m); }
  updateEnemyAI(dt: number) { return _updateEnemyAI(this, dt); }
  tickTaunt(f: Fighter, dt: number) { return _tickTaunt(this, f, dt); }
  updateFighter(f: Fighter, o: Fighter, dt: number) { return _updateFighter(this, f, o, dt); }
  separate() { return _separate(this); }
  beginStrike(f: Fighter, o: Fighter, m: Move) { return _beginStrike(this, f, o, m); }
  resolveHit(a: Fighter, d: Fighter) { return _resolveHit(this, a, d); }
  updateAnimations(dt: number) { return _updateAnimations(this, dt); }
  heroAnimState(pose: HeroPose, t: number, mx: number, my: number, mirror = false, staticPose = false) { return _heroAnimState(this, pose, t, mx, my, mirror, staticPose); }
  startCine(kind: CineKind, at?: THREE.Vector3, dir?: THREE.Vector2) { return _startCine(this, kind, at, dir); }
  updateCamera(raw: number, dt: number) { return _updateCamera(this, raw, dt); }

  panjerMax(f: Fighter, id: MoveId) { return _panjerMax(this, f, id); }
  panjerReady(f: Fighter) { return _panjerReady(this, f); }
  panjerStep(f: Fighter, dt: number, isPlayer: boolean) { return _panjerStep(this, f, dt, isPlayer); }
  armOf(f: Fighter, m: Move) { return _armOf(this, f, m); }
  punchStepOf(f: Fighter, o: Fighter) { return _punchStepOf(this, f, o); }
  aimY(f: Fighter, m: Move) { return _aimY(this, f, m); }
  aimPoint(d: Fighter, aim: number, out: THREE.Vector3) { return _aimPoint(this, d, aim, out); }
  aimsLow(f: Fighter, m: Move) { return _aimsLow(this, f, m); }
  pickMixAim(f: Fighter, id: MoveId) { return _pickMixAim(this, f, id); }
  markWhiff(a: Fighter, m: Move) { return _markWhiff(this, a, m); }
  tellFor(id: MoveId, chain: boolean) { return _tellFor(this, id, chain); }
  tryFinisher(f: Fighter) { return _tryFinisher(this, f); }
  nComboStep(p: Fighter, id: MoveId) { return _nComboStep(this, p, id); }
  aiDefended(kind: 'block' | 'dodge', seq: number) { return _aiDefended(this, kind, seq); }
  scoutPlayer(dt: number) { return _scoutPlayer(this, dt); }
  updatePlan(dt: number) { return _updatePlan(this, dt); }
  planRange(scale: number) { return _planRange(this, scale); }
  pickAiMove(e: Fighter, chain: MoveId | null, dist: number) { return _pickAiMove(this, e, chain, dist); }
  updateAir(f: Fighter, dt: number) { return _updateAir(this, f, dt); }
  ragdollKick(f: Fighter, mag: number, side: number) { return _ragdollKick(this, f, mag, side); }
  ragdollSlam(f: Fighter, mag: number) { return _ragdollSlam(this, f, mag); }
  landFx(f: Fighter, imp: number) { return _landFx(this, f, imp); }
  ropeImpact(f: Fighter, wx: number, wz: number, vIn: number) { return _ropeImpact(this, f, wx, wz, vIn); }
  knockout(d: Fighter, a: Fighter) { return _knockout(this, d, a); }
  captureRobot(robot: Robot, w: number, h: number, frame: 'bust' | 'torso', cutout: boolean, yaw: number) { return _captureRobot(this, robot, w, h, frame, cutout, yaw); }
  grabCorner(w: number, h: number, draw: () => void, read?: (ctx: CanvasRenderingContext2D) => void) { return _grabCorner(this, w, h, draw, read); }
  gameplayCam(gp: THREE.Vector3, gl: THREE.Vector3, raw: number) { return _gameplayCam(this, gp, gl, raw); }
  cineCam(tp: THREE.Vector3, tl: THREE.Vector3, dt: number) { return _cineCam(this, tp, tl, dt); }
  heroArms(pose: HeroPose, t: number, mx: number, my: number) { return _heroArms(this, pose, t, mx, my); }
  animateMenuHero(dt: number) { return _animateMenuHero(this, dt); }
  animateFighter(f: Fighter, o: Fighter, dt: number) { return _animateFighter(this, f, o, dt); }

  aimPose(f: Fighter, m: Move, p: Pose) { return _aimPose(this, f, m, p); }
}
