import * as THREE from 'three';

const STOPS: number[][] = [
  [0.0, 1.0, 0.97, 0.88],
  [0.12, 1.0, 0.92, 0.6],
  [0.36, 1.0, 0.74, 0.2],
  [0.68, 1.0, 0.4, 0.06],
  [1.0, 0.5, 0.07, 0.01],
];

function ramp(u: number, out: number[]) {
  for (let i = 1; i < STOPS.length; i++) {
    const b = STOPS[i];
    if (u <= b[0]) {
      const a = STOPS[i - 1];
      const t = (u - a[0]) / (b[0] - a[0]);
      out[0] = a[1] + (b[1] - a[1]) * t;
      out[1] = a[2] + (b[2] - a[2]) * t;
      out[2] = a[3] + (b[3] - a[3]) * t;
      return;
    }
  }
  const l = STOPS[STOPS.length - 1];
  out[0] = l[1];
  out[1] = l[2];
  out[2] = l[3];
}

export class SparkStreaks {
  private readonly N = 450;
  private p: Float32Array;
  private v: Float32Array;
  private life: Float32Array;
  private maxLife: Float32Array;
  private size: Float32Array;
  private grav: Float32Array;
  private pop: Float32Array;
  private tint: Float32Array;
  private weld: Uint8Array;
  private verts: Float32Array;
  private cols: Float32Array;
  private geo = new THREE.BufferGeometry();
  private aliveCount = 0;
  private rgb = [0, 0, 0];
  private wasActive = false;
  readonly mesh: THREE.Mesh;

  constructor(scene: THREE.Scene) {
    const N = this.N;
    this.p = new Float32Array(N * 3);
    this.v = new Float32Array(N * 3);
    this.life = new Float32Array(N);
    this.maxLife = new Float32Array(N).fill(1);
    this.size = new Float32Array(N);
    this.grav = new Float32Array(N);
    this.pop = new Float32Array(N);
    this.tint = new Float32Array(N * 3);
    this.weld = new Uint8Array(N);
    this.verts = new Float32Array(N * 12);
    this.cols = new Float32Array(N * 12);
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.verts, 3));
    this.geo.setAttribute('color', new THREE.BufferAttribute(this.cols, 3));
    const idx: number[] = [];
    for (let i = 0; i < N; i++) {
      const a = i * 4;
      idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
    this.geo.setIndex(idx);
    const mat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    this.mesh = new THREE.Mesh(this.geo, mat);
    this.mesh.frustumCulled = false;
    scene.add(this.mesh);
  }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, grav: number, weld: boolean, tr: number, tg: number, tb: number, pop: number) {
    let i: number;
    if (this.aliveCount < this.N) {
      i = this.aliveCount;
      this.aliveCount++;
    } else {

      i = Math.floor(Math.random() * this.N);
    }
    const i3 = i * 3;
    this.p[i3] = x;
    this.p[i3 + 1] = y;
    this.p[i3 + 2] = z;
    this.v[i3] = vx;
    this.v[i3 + 1] = vy;
    this.v[i3 + 2] = vz;
    this.life[i] = life;
    this.maxLife[i] = life;
    this.size[i] = size;
    this.grav[i] = grav;
    this.weld[i] = weld ? 1 : 0;
    this.tint[i3] = tr;
    this.tint[i3 + 1] = tg;
    this.tint[i3 + 2] = tb;
    this.pop[i] = pop;
  }

  private burst(i: number) {
    if (this.aliveCount >= this.N - 3) return;
    const i3 = i * 3;
    const n = 2;
    for (let k = 0; k < n; k++) {
      const a = Math.random() * Math.PI * 2;
      const b = Math.random() * 2 - 1;
      const r = Math.sqrt(1 - b * b);
      const s = 2.0 + Math.random() * 2.5;
      this.emit(
        this.p[i3],
        this.p[i3 + 1],
        this.p[i3 + 2],
        this.v[i3] * 0.3 + Math.cos(a) * r * s,
        this.v[i3 + 1] * 0.3 + b * s,
        this.v[i3 + 2] * 0.3 + Math.sin(a) * r * s,
        0.12 + Math.random() * 0.16,
        this.size[i] * 0.65,
        this.grav[i],
        this.weld[i] === 1,
        this.tint[i3],
        this.tint[i3 + 1],
        this.tint[i3 + 2],
        0,
      );
    }
  }

  update(dt: number, cam: THREE.Camera) {
    if (this.aliveCount === 0) {
      if (this.wasActive) {
        this.verts.fill(0);
        this.cols.fill(0);
        this.geo.attributes.position.needsUpdate = true;
        this.geo.attributes.color.needsUpdate = true;
        this.wasActive = false;
      }
      return;
    }

    const cx = cam.position.x;
    const cy = cam.position.y;
    const cz = cam.position.z;
    const rgb = this.rgb;
    let i = 0;

    while (i < this.aliveCount) {
      this.life[i] -= dt;
      if (this.life[i] <= 0) {

        const last = this.aliveCount - 1;
        const oLast = last * 12;
        this.verts.fill(0, oLast, oLast + 12);
        this.cols.fill(0, oLast, oLast + 12);

        if (i < last) {
          const i3 = i * 3;
          const l3 = last * 3;
          this.p[i3] = this.p[l3];
          this.p[i3 + 1] = this.p[l3 + 1];
          this.p[i3 + 2] = this.p[l3 + 2];
          this.v[i3] = this.v[l3];
          this.v[i3 + 1] = this.v[l3 + 1];
          this.v[i3 + 2] = this.v[l3 + 2];
          this.tint[i3] = this.tint[l3];
          this.tint[i3 + 1] = this.tint[l3 + 1];
          this.tint[i3 + 2] = this.tint[l3 + 2];
          this.life[i] = this.life[last];
          this.maxLife[i] = this.maxLife[last];
          this.size[i] = this.size[last];
          this.grav[i] = this.grav[last];
          this.pop[i] = this.pop[last];
          this.weld[i] = this.weld[last];
        }
        this.aliveCount--;
        continue;
      }

      const f = this.life[i] / this.maxLife[i];
      if (this.pop[i] > 0 && f < this.pop[i]) {
        this.pop[i] = 0;
        this.burst(i);
      }

      const o = i * 12;
      const i3 = i * 3;

      let vx = this.v[i3];
      let vy = this.v[i3 + 1];
      let vz = this.v[i3 + 2];
      vy -= this.grav[i] * dt;
      const drag = Math.max(0, 1 - 0.9 * dt);
      vx *= drag;
      vy *= drag;
      vz *= drag;
      let px = this.p[i3] + vx * dt;
      let py = this.p[i3 + 1] + vy * dt;
      let pz = this.p[i3 + 2] + vz * dt;
      const floor = Math.abs(px) < 15.6 && Math.abs(pz) < 15.6 ? 0.03 : -1.37;
      if (py < floor && vy < 0) {
        py = floor;
        if (-vy > 1.6) {
          vy *= -0.42;
          vx *= 0.8;
          vz *= 0.8;
        } else {
          vy = 0;
          vx *= 0.92;
          vz *= 0.92;
        }
      }
      this.p[i3] = px;
      this.p[i3 + 1] = py;
      this.p[i3 + 2] = pz;
      this.v[i3] = vx;
      this.v[i3 + 1] = vy;
      this.v[i3 + 2] = vz;

      const u = 1 - f;
      if (this.weld[i] === 1) ramp(u, rgb);
      else {
        const tr = this.tint[i3];
        const tg = this.tint[i3 + 1];
        const tb = this.tint[i3 + 2];
        if (u < 0.25) {
          const k = u / 0.25;
          rgb[0] = 1 + (tr - 1) * k;
          rgb[1] = 1 + (tg - 1) * k;
          rgb[2] = 1 + (tb - 1) * k;
        } else {
          const k = 1 - 0.8 * ((u - 0.25) / 0.75);
          rgb[0] = tr * k;
          rgb[1] = tg * k;
          rgb[2] = tb * k;
        }
      }
      const e = 1.9 * Math.pow(f, 0.45);
      const hr = rgb[0] * e;
      const hg = rgb[1] * e;
      const hb = rgb[2] * e;

      let spd = Math.sqrt(vx * vx + vy * vy + vz * vz);
      let dx = 0;
      let dy = 1;
      let dz = 0;
      if (spd > 0.01) {
        dx = vx / spd;
        dy = vy / spd;
        dz = vz / spd;
      } else spd = 0;
      const len = Math.min(1.5, Math.max(0.08, spd * 0.045));
      const tx = px - dx * len;
      const ty = py - dy * len;
      const tz = pz - dz * len;
      const wx = cx - px;
      const wy = cy - py;
      const wz = cz - pz;
      let sx = dy * wz - dz * wy;
      let sy = dz * wx - dx * wz;
      let sz = dx * wy - dy * wx;
      const sl = Math.sqrt(sx * sx + sy * sy + sz * sz) || 1;
      const w = this.size[i] * (0.55 + 0.45 * f);
      sx = (sx / sl) * w;
      sy = (sy / sl) * w;
      sz = (sz / sl) * w;
      const w2 = 0.18;
      const V = this.verts;
      V[o] = px + sx;
      V[o + 1] = py + sy;
      V[o + 2] = pz + sz;
      V[o + 3] = px - sx;
      V[o + 4] = py - sy;
      V[o + 5] = pz - sz;
      V[o + 6] = tx + sx * w2;
      V[o + 7] = ty + sy * w2;
      V[o + 8] = tz + sz * w2;
      V[o + 9] = tx - sx * w2;
      V[o + 10] = ty - sy * w2;
      V[o + 11] = tz - sz * w2;
      const C = this.cols;
      C[o] = C[o + 3] = hr;
      C[o + 1] = C[o + 4] = hg;
      C[o + 2] = C[o + 5] = hb;
      C[o + 6] = C[o + 9] = hr * 0.1;
      C[o + 7] = C[o + 10] = hg * 0.1;
      C[o + 8] = C[o + 11] = hb * 0.1;

      i++;
    }

    this.geo.setDrawRange(0, this.aliveCount * 6);
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
    this.wasActive = true;
  }
}
