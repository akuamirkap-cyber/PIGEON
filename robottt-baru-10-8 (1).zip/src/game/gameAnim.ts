import * as THREE from 'three';
import type { Game } from './Game';
import {

  MOVES, GUARD, BLOCK, STAGGER, TAUNT, VICTORY, RUNARM, WALKG,

  aliIdlePose, aliWeave, aliRoll, aliHead, aliFloat, aliStanceWeight,

  panjerCharge,
  swingPhase, swingStiff, offArmCounter, swingRoll, trailWidthFor,

  AIM_BODY,

  ringCfg,

  fallArms, fallStages, freestylePose, riseArms,
  sampleKeys, smooth, lerp, lerpPose, isOD,
  type Fighter, type HeroPose, type Pose, type WalkTrack,
  P, COM_H,
  rampY, FLIGHT_H, FLIP_IN, FLIP_SPAN, flipTurn, type AnimState,
} from './gameData';

export function walkAt(_g: Game, w: WalkTrack, t: number, out: { pos: THREE.Vector2; y: number; yaw: number; flip: number; beat: number; u: number }) {
    const [t0, t1, t2, t3, t4, t5, t6] = w.t;
    const ease = (u: number) => u * u * (3 - 2 * u);
    out.flip = 0;
    out.u = 0;
    if (t < t0) {
      out.pos.copy(w.from);
      out.beat = 0;
      out.u = t / t0;
    } else if (t < t1) {

      const u = (t - t0) / (t1 - t0);
      const k = u < 0.12 ? ease(u / 0.12) * 0.12 : u;
      out.pos.lerpVectors(w.from, w.mark, k);
      out.beat = 1;
      out.u = u;
    } else if (t < t2) {

      const u = (t - t1) / (t2 - t1);
      const sdist = u < 0.2 ? (u * u) / 0.4 : 0.1 + (u - 0.2);
      out.pos.lerpVectors(w.mark, w.take, sdist / 0.9);
      out.beat = 2;
      out.u = u;
    } else if (t < t3) {

      const u = (t - t2) / (t3 - t2);
      out.pos.lerpVectors(w.take, w.land, u);
      out.y = THREE.MathUtils.lerp(rampY(w.take.length()), 0, u) + FLIGHT_H * 4 * u * (1 - u);
      const fu = THREE.MathUtils.clamp((u - FLIP_IN) / FLIP_SPAN, 0, 1);
      out.flip = Math.PI * 2 * flipTurn(fu);
      out.beat = 3;
      out.u = u;
    } else if (t < t4) {
      out.pos.copy(w.land);
      out.beat = 4;
      out.u = (t - t3) / (t4 - t3);
    } else if (t < t5) {
      out.pos.copy(w.land);
      out.beat = 5;
      out.u = (t - t4) / (t5 - t4);
    } else if (t < t6) {
      const u = (t - t5) / (t6 - t5);
      const k = u < 0.15 ? ease(u / 0.15) * 0.15 : u > 0.85 ? 0.85 + ease((u - 0.85) / 0.15) * 0.15 : u;
      out.pos.lerpVectors(w.land, w.home, k);
      out.beat = 6;
      out.u = u;
    } else {
      out.pos.copy(w.home);
      out.beat = 7;
    }
    if (out.beat <= 2) out.y = rampY(out.pos.length());
    else if (out.beat >= 4) out.y = 0;

    const inYaw = Math.atan2(w.inward.x, w.inward.y);
    const turn = (a: number, b: number, u: number) => {
      let d = b - a;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      return a + d * ease(THREE.MathUtils.clamp(u, 0, 1));
    };
    if (out.beat <= 4) out.yaw = inYaw;
    else if (out.beat === 5) out.yaw = turn(inYaw, w.homeYaw, (t - t4) / 0.5);
    else out.yaw = w.homeYaw;
  }

export function updateAnimations(g: Game, dt: number) {
    if (g.phase === 'menu') {
      g.animateMenuHero(dt > 0 ? dt : 0.016);
      return;
    }
    for (const f of g.fighters()) g.animateFighter(f, g.foeOf(f), dt);
  }

export function heroArms(_g: Game, pose: HeroPose, t: number, mx: number, my: number) {
    let a0: Pose;
    let a1: Pose;
    const breathWave = Math.sin(t * 1.6);
    let dp = 0.12 + breathWave * 0.035;
    let tw = Math.sin(t * 0.8) * 0.02 + mx * 0.08;
    let ln = 0.06 + breathWave * 0.028 + my * 0.04;
    const rl = Math.sin(t * 1.2) * 0.015;
    switch (pose) {
      case 'ready': {

        const br = breathWave * 0.045;
        const roll = Math.sin(t * 0.7) * 0.03;
        a0 = { sx: -0.8 + br, sy: -0.1 + roll, sz: 0.25 - roll, ex: -2.4 - br * 1.2 };
        a1 = { sx: -0.55 + br * 0.75, sy: -0.4, sz: 0.0, ex: -1.8 - br };
        tw = 0.22 + Math.sin(t * 0.8) * 0.01 + mx * 0.08;
        ln = 0.1 + breathWave * 0.03 + my * 0.03;
        dp = 0.11 + breathWave * 0.036;
        break;
      }
      case 'menace': {

        const sway = Math.sin(t * 1.1) * 0.05;
        a0 = { sx: -0.42 + sway + breathWave * 0.035, sy: -0.1, sz: 0.16, ex: -1.25 };
        a1 = { sx: -0.42 - sway + breathWave * 0.035, sy: -0.1, sz: 0.16, ex: -1.25 };
        tw = Math.sin(t * 0.55) * 0.09 + mx * 0.05;
        ln = 0.24 + breathWave * 0.032 + my * 0.03;
        dp = 0.2 + breathWave * 0.038;
        break;
      }
      case 'guard': {
        const sw = Math.sin(t * 3.2) * 0.03;
        a0 = { sx: -0.74 + sw + breathWave * 0.035, sy: -0.45, sz: 0.06, ex: -1.98 };
        a1 = { sx: -0.74 - sw + breathWave * 0.035, sy: 0.45, sz: 0.06, ex: -1.98 };
        ln = 0.08 + breathWave * 0.025 + my * 0.03;
        dp = 0.14 + breathWave * 0.036;
        break;
      }
      case 'victory': {
        const pump = Math.sin(t * 3.5) * 0.08;
        a0 = { sx: -2.85 + pump, sy: -0.08, sz: 0.52, ex: -0.38 };
        a1 = { sx: -2.85 + pump, sy: 0.08, sz: 0.52, ex: -0.38 };
        ln = -0.08 + breathWave * 0.022;
        dp = 0.08 + breathWave * 0.03;
        break;
      }
      case 'taunt': {
        const p = Math.sin(t * 4.5) * 0.5 + 0.5;
        a0 = { sx: -0.4 - p * 0.42, sy: -0.18, sz: 1.1, ex: -2.1 + p * 0.4 };
        a1 = { sx: -0.4 - p * 0.42, sy: 0.18, sz: 1.1, ex: -2.1 + p * 0.4 };
        ln = 0.04 + breathWave * 0.025;
        dp = 0.14 + p * 0.03 + breathWave * 0.03;
        break;
      }
      case 'sombong': {

        const beckon = Math.sin(t * 1.5) > 0.05;
        const wave = Math.sin(t * 7.5) * 0.5 + 0.5;
        a0 = beckon
          ? { sx: -1.25, sy: -0.1, sz: 0.18, ex: -1.35 - wave * 0.7 }
          : { sx: 0.05, sy: -0.18, sz: 0.32, ex: -0.38 };
        a1 = { sx: 0.08, sy: 0.2, sz: 0.35, ex: -0.45 };
        tw = Math.sin(t * 0.5) * 0.08 + mx * 0.06;
        ln = -0.16 + breathWave * 0.035 + my * 0.02;
        dp = 0.02 + breathWave * 0.032;
        break;
      }
      case 'stand':
      default: {
        const breath = breathWave * 0.05;
        a0 = { sx: -0.22 + breath, sy: -0.14, sz: 0.24, ex: -0.92 - breath * 1.6 };
        a1 = { sx: -0.16 + breath, sy: 0.16, sz: 0.26, ex: -0.78 - breath * 1.6 };
        ln = 0.04 + breathWave * 0.028;
        dp = 0.04 + breathWave * 0.038;
        break;
      }
    }
    return { a0, a1, dp, tw, ln, rl };
  }

export function heroAnimState(g: Game, pose: HeroPose, t: number, mx: number, my: number, mirror = false, staticPose = false): AnimState {
    const poseT = staticPose ? 0 : t;
    const poseMx = staticPose ? 0 : mx;
    const poseMy = staticPose ? 0 : my;
    const { a0, a1, dp, tw, ln, rl } = g.heroArms(pose, poseT, poseMx, poseMy);

    return {
      arms: (mirror ? [a1, a0] : [a0, a1]) as [Pose, Pose],
      twist: mirror ? -tw : tw,
      lean: ln,
      lunge: 0,
      dip: dp,
      roll: mirror ? -rl : rl,
      vf: 0,
      vl: 0,
      af: 0,
      al: 0,
      yawRate: 0,
      air: 0,
      hit: 0,
      hitSign: 1,
      hitUp: 0,
      fall: 0,
      time: poseT,
      glow: 0.45 + Math.sin(poseT * 2.5) * 0.09,
      flash: 0,
      tilt: 0,
      dash: 0,
      dashF: 0,
      dashL: 0,
      idleBounce: staticPose ? 0 : undefined,
      lookX: mirror ? -poseMx : poseMx,
      lookY: pose === 'sombong' ? -0.38 : poseMy,
    };
  }

export function animateMenuHero(g: Game, dt: number) {
    if (!g.menuHero || g.phase !== 'menu') return;
    const t = g.time;
    g.hangar.update(t);
    g.heroYaw += (g.heroYawTarget - g.heroYaw) * Math.min(1, 10 * dt);
    g.menuHero.root.rotation.y = g.heroYaw;
    if (g.menuHeroPedestal) {
      g.menuHeroPedestal.rotation.y = t * 0.32;
    }
    const heroSt = g.heroAnimState(g.heroPose, t, g.heroMouseX, g.heroMouseY);

    if (g.aliStyle && (g.heroPose === 'ready' || g.heroPose === 'guard' || g.heroPose === 'stand')) {
      const ap = aliIdlePose(t);
      heroSt.arms = [lerpPose(heroSt.arms[0], ap, 0.8), lerpPose(heroSt.arms[1], ap, 0.8)];
      heroSt.twist += aliWeave(t) * 0.9;
      heroSt.roll += aliRoll(t) * 0.9;
      heroSt.dip += aliFloat(t) * 0.9;
      heroSt.headYaw = aliHead(t);
      heroSt.shuffle = 1;
      heroSt.idleBounce = 1;
    }
    g.menuHero.animate(heroSt, dt);
  }

export function animateFighter(g: Game, f: Fighter, o: Fighter, dt: number) {
    let a0: Pose = GUARD;
    let a1: Pose = GUARD;
    let tw = 0;
    let ln = 0.08;
    let lg = 0;
    let dp = 0.12;
    let rl = 0;
    let kk = 15;
    const t = f.animT;
    f.headYaw = 0;

    f.pkVis += ((f.panjerId ? 1 : 0) - f.pkVis) * Math.min(1, dt * 14);

    const isAirRagdoll = (f.state === 'air' || (f.state === 'ko' && (f.y > 0.02 || f.vy > 0))) && g.phase !== 'walk' && g.phase !== 'menu';

    if ((f.pkTuck > 0.01 || f.pkLand > 0.01 || f.pkPre > 0.01) && f.tauntT <= 0) {

      const pre = f.pkPre;
      const tk = f.pkTuck;
      const ld = f.pkLand;
      const loadA = P(0.95, 0.05, 0.35, -0.8);
      const tuckA = P(-1.35, -0.3, 0.25, -2.3);

      const landFist = P(-0.58, -0.06, 0.34, -0.1);

      const open = P(-1.85, -0.12, 0.42, -0.95);
      const inAir = f.state === 'air' ? 1 : 0;
      const from = f.sprinting ? RUNARM : GUARD;
      const base0 = lerpPose(lerpPose(lerpPose(from, loadA, pre), open, Math.min(1, (1 - tk) * 1.4) * inAir), tuckA, tk);
      a0 = lerpPose(base0, landFist, ld);
      a1 = lerpPose(base0, landFist, ld);
      ln = lerp(lerp(lerp(0.08, 0.34, pre), 0.7, tk), 0.5, ld);
      dp = lerp(lerp(lerp(0.12, 0.55, pre), 0.3, tk), 0.92, ld);
      tw = 0;
      rl = 0;
      kk = ld > 0.3 ? 70 : 34;
    } else if (isAirRagdoll || f.state === 'air') {

      const side = f.riseDir || f.hitSign || 1;
      const driftA = Math.sin(t * 3.4) * 0.08;
      const driftB = Math.cos(t * 2.9 + 0.8) * 0.08;
      const vyK = THREE.MathUtils.clamp(f.vy / 12, -1, 1);
      a0 = P(-0.52 + vyK * 0.2 + driftA, 0.08 + side * 0.06, 0.36 + (side > 0 ? 0.14 : 0.04), -0.7 - Math.max(0, vyK) * 0.22);
      a1 = P(-0.44 + vyK * 0.16 - driftB, -0.06 + side * 0.06, 0.32 + (side < 0 ? 0.14 : 0.04), -0.84 - Math.max(0, vyK) * 0.18);
      ln = -0.18 - Math.max(0, vyK) * 0.1;
      tw = -side * 0.15;
      rl = side * 0.1;
      dp = 0.05;
      kk = 5;
    } else if (f.state === 'ko') {

      const fb = fallArms(f.fallS.x, f.riseDir || f.hitSign || 1, t, true);
      a0 = fb.a0;
      a1 = fb.a1;
      tw = fb.tw;
      ln = fb.ln;
      lg = 0;
      dp = fb.dp;
      rl = fb.rl;
      kk = fb.kk;
    } else if (f.state === 'down') {

      const rb = f.riseU > 0.001 ? riseArms(f.riseU, f.riseDir) : fallArms(f.fallS.x, f.riseDir, t, false);
      a0 = rb.a0;
      a1 = rb.a1;
      tw = rb.tw;
      ln = rb.ln;
      lg = 0;
      dp = rb.dp;
      rl = rb.rl;
      kk = rb.kk;
      kk = rb.kk;
    } else if (f.state === 'stagger') {
      const fl = Math.sin(t * 22) * 0.14;
      const kbMag = Math.min(1, f.kb.length() / 12);
      a0 = { ...STAGGER, sz: STAGGER.sz + fl, sx: STAGGER.sx - fl - kbMag * 0.18 };
      a1 = { ...STAGGER, sz: STAGGER.sz - fl, sx: STAGGER.sx + fl - kbMag * 0.18 };
      ln = -0.34 - kbMag * 0.22;
      lg = -0.36 - kbMag * 0.25;
      tw = f.hitSign * (0.28 * kbMag + Math.sin(t * 18) * 0.12);
      rl = -f.hitL * 0.22 * kbMag;
      dp = 0.25 + kbMag * 0.08;
      kk = 32;
    } else if (f.state === 'attack' && f.move) {
      const m = f.move;
      const s = sampleKeys(m.keys, f.moveT);

      const phase = swingPhase(f.moveT, m.strikeAt, m.impact, m.dur);

      const arm = g.armOf(f, m);
      const mirrored = m.arm !== 2 && arm !== m.arm;
      if (m.id === 'windmill' && f.moveT < m.strikeAt * 0.94) {

        const spin = f.animT * 25;
        const windP = P(-spin, 0.34 + Math.sin(spin) * 0.18, 0.48, -0.3 + Math.cos(spin) * 0.15);
        const counterSpin = spin + Math.PI;
        const windOther = P(-counterSpin, 0.28, 0.4, -0.45);
        if (arm === 0) {
          a0 = windP;
          a1 = f.moveT < m.strikeAt * 0.72 ? windOther : GUARD;
        } else {
          a1 = windP;
          a0 = f.moveT < m.strikeAt * 0.72 ? windOther : GUARD;
        }
        tw = -0.82 + Math.sin(spin) * 0.38;
        ln = -0.18 + Math.cos(spin) * 0.1;
        lg = -0.38;
        dp = 0.28 + Math.sin(spin * 0.5) * 0.08;
        rl = Math.cos(spin) * 0.22;
        kk = 95;
      } else {
        const strike = g.aimPose(f, m, s.p);

        const canVar = !isOD(m.id) && m.id !== 'grab' && m.id !== 'counter';
        const varEnv = canVar ? Math.sin(Math.min(1, f.moveT / Math.max(0.25, m.dur * 0.82)) * Math.PI) : 0;
        const v = f.strikeVar;
        const sgn = arm === 0 ? -1 : 1;
        const variedStrike: Pose = { ...strike };
        let offGuard: Pose = { ...GUARD };
        if (varEnv > 0.01) {
          if (v === 1) {

            variedStrike.sx -= 0.14 * varEnv;
            variedStrike.sy += 0.16 * varEnv;
            variedStrike.sz += 0.24 * varEnv;
            offGuard = P(GUARD.sx - 0.16 * varEnv, GUARD.sy - 0.12 * varEnv, GUARD.sz + 0.18 * varEnv, GUARD.ex + 0.18 * varEnv);
            rl += sgn * 0.22 * varEnv;
            dp += 0.09 * varEnv;
          } else if (v === 2) {

            variedStrike.sx += 0.16 * varEnv;
            variedStrike.ex -= 0.14 * varEnv;
            offGuard = P(GUARD.sx - 0.24 * varEnv, GUARD.sy - 0.18 * varEnv, GUARD.sz, GUARD.ex - 0.15 * varEnv);
            dp += 0.18 * varEnv;
            ln += 0.14 * varEnv;
            rl -= sgn * 0.14 * varEnv;
          } else if (v === 3) {

            variedStrike.sy -= 0.18 * varEnv;
            variedStrike.sz -= 0.18 * varEnv;
            offGuard = P(GUARD.sx + 0.12 * varEnv, GUARD.sy + 0.14 * varEnv, GUARD.sz + 0.26 * varEnv, GUARD.ex + 0.25 * varEnv);
            rl += sgn * 0.18 * Math.cos(f.moveT * 10) * varEnv;
          } else {

            offGuard = P(GUARD.sx - 0.1 * varEnv, GUARD.sy - 0.08 * varEnv, GUARD.sz + 0.08 * varEnv, GUARD.ex - 0.08 * varEnv);
            rl -= sgn * 0.08 * varEnv;
          }
        }

        if (arm !== 2) {
          const off = offArmCounter(m.kind, phase);
          offGuard = P(offGuard.sx + off.sx, offGuard.sy + off.sy, offGuard.sz + off.sz, offGuard.ex + off.ex);
        }

        const distToFoe = f.pos.distanceTo(o.pos);
        const foeHull = (o.blocking ? 1.42 : 1.16) * o.scale;
        const maxReachWorld = Math.max(0.6 * f.scale, distToFoe - foeHull);
        const maxReachModel = maxReachWorld / f.scale;

        const minBodyDist = (f.scale + o.scale) * 1.35;
        const maxLungeAllowed = Math.max(0, (distToFoe - minBodyDist) / f.scale);

        if (maxReachModel < 2.95) {
          const dFist = Math.max(0.6, maxReachModel - 0.48);
          const cosElbow = THREE.MathUtils.clamp((2.90 - dFist * dFist) / 2.86, -0.999, 0.999);
          const exLimit = -(Math.PI - Math.acos(cosElbow));
          variedStrike.ex = Math.min(variedStrike.ex, exLimit);
          if (maxReachModel < 1.95) {
            variedStrike.sx += 0.36 * (1.95 - maxReachModel);
          }
        }

        if (arm === 0) {
          a0 = variedStrike;
          a1 = offGuard;
        } else if (arm === 1) {
          a1 = variedStrike;
          a0 = offGuard;
        } else {
          a0 = a1 = variedStrike;
        }
        const extraTw = varEnv > 0.01 ? (v === 3 ? -sgn * 0.26 : v === 1 ? -sgn * 0.15 : 0) * varEnv : 0;
        tw = s.twist * (mirrored ? -1 : 1) * (f.ippoStrike ? 1.35 : 1) + extraTw;
        if (f.tellT > 0) tw += Math.sin(f.animT * 46) * 0.03;
        rl += swingRoll(m.kind, phase, sgn);
        ln += s.lean + (f.runStrike ? 0.22 : f.ippoStrike ? 0.16 : f.rage ? 0.12 : 0);
        lg = Math.min((s.lunge + (v === 2 ? 0.18 * varEnv : 0)) * (f.runStrike ? 1.3 : 1) * (f.aim === AIM_BODY ? 0.94 : 1), maxLungeAllowed);
        dp += s.dip + (g.aimsLow(f, m) ? 0.1 : 0);

        kk = swingStiff(f.rage ? 92 : 75, phase, f.moveT > m.impact);
      }
    } else if (f.tauntT > 0) {

      const u = 1 - f.tauntT / Math.max(0.001, f.tauntDur);
      const fb = freestylePose(f.tauntStyle, u, t);
      a0 = fb.a0;
      a1 = fb.a1;
      tw = fb.tw;
      ln = fb.ln;
      dp = fb.dp;
      rl = fb.rl;
      kk = fb.kk;
    } else if (f.swagger !== 0 && g.phase === 'walk') {

      const sw = f.swagger;
      const g = f.robot.stride.arm;
      const gs = f.robot.stride.swing;
      const st = (a: number, b: number) => THREE.MathUtils.smoothstep(sw, a, b);
      const fwdL = Math.max(0, -g);
      const fwdR = Math.max(0, g);
      const armL = P(-0.78 + g * 0.42, -0.2, 0.2, -1.6 - fwdL * 0.4 + fwdR * 0.16);
      const armR = P(-0.78 - g * 0.42, -0.2, 0.2, -1.6 - fwdR * 0.4 + fwdL * 0.16);

      const bothUp = P(-2.5 - gs * 0.06, -0.14, 0.4, -0.85);
      const pumpL = P(-2.52 + g * 0.18, -0.16, 0.34, -0.95 + fwdR * 0.12);
      const pumpR = P(-2.52 - g * 0.18, -0.16, 0.34, -0.95 + fwdL * 0.12);
      const pound = P(-0.1, -1.0, -0.85, -1.9);
      const poundOpen = P(-1.35, -0.62, 0.85, -2.1);
      const point = P(-1.62 - g * 0.05, -0.15, 0.15, -0.35);
      const gateUp = st(-1, -0.45) * (1 - st(0.0, 0.17));
      const wL = st(0.18, 0.28) * (1 - st(0.38, 0.47));
      const wR = st(0.44, 0.54) * (1 - st(0.62, 0.71));
      const wP = st(0.67, 0.75) * (1 - st(0.84, 0.91));
      const thump = Math.max(0, Math.sin((sw - 0.71) * Math.PI * 12)) * wP;
      const wPt = st(0.87, 0.95) * (1 - st(1.02, 1.3));
      const toRun = st(1.0, 1.3);
      let l = lerpPose(armL, bothUp, gateUp);
      let r = lerpPose(armR, bothUp, gateUp);
      l = lerpPose(l, pumpL, wL);
      r = lerpPose(r, pumpR, wR);
      const poundPose = lerpPose(poundOpen, pound, thump);
      l = lerpPose(l, poundPose, wP);
      r = lerpPose(r, poundPose, wP);
      r = lerpPose(r, point, wPt);
      a0 = lerpPose(l, RUNARM, toRun);
      a1 = lerpPose(r, RUNARM, toRun);
      const show = 1 - toRun;

      tw = (-g * 0.26 + (wL - wR) * 0.2 - wPt * 0.14) * show;
      rl = (g * 0.085 + (wL - wR) * 0.05) * show;

      ln = lerp(0.03 - gateUp * 0.05 + thump * 0.2 + wPt * 0.06, 0.16, toRun);
      dp = lerp(0.19 + gs * gs * 0.05 + thump * 0.1, 0.2, toRun);
      kk = 24 + thump * 40;
      f.headYaw = ((wL - wR) * 0.85 - wPt * 0.12) * show;
    } else if (f.riseOut > 0 && !f.blocking) {

      const o = 1 - f.riseOut / 0.55;
      const shake = Math.sin(o * Math.PI * 3) * (1 - o);
      a0 = lerpPose(GUARD, P(-0.5, -0.62, 0.3, -1.7), (1 - o) * 0.7);
      a1 = lerpPose(GUARD, P(-0.5, -0.38, 0.3, -1.7), (1 - o) * 0.7);
      tw = shake * 0.22;
      ln = 0.08 + (1 - o) * 0.14 - shake * 0.05;
      dp = 0.12 + (1 - o) * 0.14;
      rl = shake * 0.09;
      kk = 26;
    } else if (f.mode === 'taunt') {
      const pump = Math.sin(t * 3.2) * 0.5 + 0.5;
      const tp: Pose = { ...TAUNT, sx: TAUNT.sx - pump * 0.4, ex: TAUNT.ex + pump * 0.5 };
      a0 = a1 = g.phase === 'menu' || (g.phase === 'intro' && g.phaseT < 2.0) ? tp : GUARD;
      ln = 0;
      dp = 0.15;
    } else if (f.mode === 'victory') {
      a0 = a1 = { ...VICTORY, sx: VICTORY.sx + Math.sin(t * 6) * 0.15 };
      ln = -0.15;
      dp = 0.1;
    } else if (f.ippo) {

      f.weavePh += dt * (2.6 + f.rollCharge * 2.2);
      const ph = f.weavePh;
      const amp = 0.75 + f.rollCharge * 0.55;
      const flick = Math.sin(ph * 2 + 0.6) * 0.06;
      a0 = P(-1.08 + flick, -0.8, 0.0, -2.35);
      a1 = P(-1.08 - flick, -0.8, 0.0, -2.35);
      tw = Math.sin(ph) * 0.34 * amp;
      rl = Math.sin(ph) * 0.2 * amp;
      dp = 0.36 + (1 - Math.cos(ph * 2)) * 0.06 * amp;
      ln = 0.22 + (1 - Math.cos(ph * 2)) * 0.04 * amp;
      kk = 22;
    } else if (f.blocking) {
      a0 = a1 = BLOCK;
      dp = 0.3;
      ln = 0.2;
    } else {

      const wk = THREE.MathUtils.clamp(f.speed / 3.5, 0, 1);
      const idle = 1 - wk;
      const stalk = wk * wk * (3 - 2 * wk);
      const sw = Math.sin(t * 4) * 0.06 * idle;
      a0 = lerpPose({ ...GUARD, sx: GUARD.sx + sw }, WALKG, stalk);
      a1 = lerpPose({ ...GUARD, sx: GUARD.sx - sw }, WALKG, stalk);

      if (g.aliStyle && f.isPlayer) {
        const aw = aliStanceWeight(f.state, f.blocking, wk > 0.15);
        if (aw > 0) {

          const ap = aliIdlePose(t);
          const carry = aw * (1 - 0.4 * stalk);
          a0 = lerpPose(a0, ap, carry);
          a1 = lerpPose(a1, ap, carry);
          const fl = aw * (1 - 0.55 * stalk);
          tw += aliWeave(t) * fl;
          rl += aliRoll(t) * fl;
          dp += aliFloat(t) * fl;
          f.headYaw = aliHead(t) * fl;
        }
      }

      if (f.panjerId && f.pkVis > 0.01) {
        const ld = MOVES[f.panjerId];
        const coil = ld.keys[1] ?? ld.keys[0];

        const ch = panjerCharge(f.panjerHold);
        const vis = f.pkVis * ch;
        const grow = 0.62 + 0.38 * ch;
        const strain = (0.015 + 0.03 * ch) * Math.sin(t * (26 + 20 * ch));
        const load = P(coil.p.sx - 0.16 * grow + strain, coil.p.sy + 0.14 * grow, coil.p.sz + 0.1 * grow, coil.p.ex - 0.18 * grow);
        const lm = g.armOf(f, ld);
        if (lm === 1) {
          a1 = lerpPose(a1, load, vis);
        } else if (lm === 2) {
          a0 = lerpPose(a0, load, vis);
          a1 = lerpPose(a1, load, vis);
        } else {
          a0 = lerpPose(a0, load, vis);
        }

        tw += coil.twist * 0.6 * grow * vis;
        ln += coil.lean * 0.55 * grow * vis;
        dp += coil.dip * 0.4 * grow * vis;
        kk = Math.max(kk, 34);
      }
      ln = lerp(ln, 0.1 + stalk * 0.05, stalk);
      dp = 0.15 + stalk * 0.08 + Math.sin(t * 5.2) * 0.035 * idle;
      rl = Math.sin(t * 2.6) * 0.03 * idle;

      const ru = f.sprinting ? THREE.MathUtils.clamp((f.speed / f.scale - 6.4) / 3.2, 0, 1) : 0;
      const run = ru * ru * (3 - 2 * ru);
      if (run > 0.01) {
        a0 = lerpPose(a0, RUNARM, run);
        a1 = lerpPose(a1, RUNARM, run);
        ln = lerp(ln, 0.16, run);
        dp = lerp(dp, 0.2, run);
      }
    }

    const canFlinch = (f.state === 'idle' || f.state === 'stagger') && !f.blocking && f.mode === 'normal';
    const wF = canFlinch ? THREE.MathUtils.clamp((f.hitV - 0.06) * 1.15, 0, 1) : 0;
    if (wF > 0.01) {
      const up = Math.max(0, f.hitUpV);
      const bodyK = THREE.MathUtils.clamp(1 - f.hitPt + Math.max(0, -f.hitUpV) * 0.7, 0, 1);
      const openNear = P(-1.5 - up * 0.3, 0.02, 0.55 + up * 0.12, -1.55);
      const openFar = P(-0.42 + up * 0.08, -0.12, 0.24, -1.85);
      const clutch = P(-0.55, -0.62, -0.14, -2.0);
      const nearIs0 = f.hitSign > 0;
      const r0 = lerpPose(nearIs0 ? openNear : openFar, clutch, bodyK);
      const r1 = lerpPose(nearIs0 ? openFar : openNear, clutch, bodyK);
      a0 = lerpPose(a0, r0, wF);
      a1 = lerpPose(a1, r1, wF);
      ln += (bodyK * 0.55 - (1 - bodyK) * (0.3 + up * 0.4)) * wF;
      dp += (bodyK * 0.34 + (1 - bodyK) * 0.05) * wF;
      tw += f.hitSign * (1 - bodyK) * 0.18 * wF;
      kk = Math.max(kk, 30);
    }

    if (f.ropeW > 0.01 && f.state !== 'air' && f.state !== 'ko' && f.state !== 'down' && f.mode === 'normal') {
      const w = f.ropeW * (f.state === 'attack' ? 0.3 : 1);
      const back = THREE.MathUtils.clamp(f.ropeBack, -1, 1);
      const bk = THREE.MathUtils.clamp(back * 0.5 + 0.5, 0, 1);
      const spread = Math.sin(t * 7 + f.animT) * 0.08;

      const drapeL = P(-0.35 + spread, 0.42, 1.25, -0.5);
      const drapeR = P(-0.35 - spread, 0.42, 1.25, -0.5);

      const catchL = P(-1.35, -0.15, 0.55, -0.9);
      const catchR = P(-1.35, -0.15, 0.55, -0.9);
      a0 = lerpPose(a0, lerpPose(catchL, drapeL, bk), w);
      a1 = lerpPose(a1, lerpPose(catchR, drapeR, bk), w);

      const capBack = -0.16;
      ln = lerp(ln, Math.max(ln, capBack) - 0.06, w * bk);
      ln += 0.38 * (1 - bk) * w;
      dp += (0.2 * bk + 0.08 * (1 - bk)) * w;
      lg -= 0.2 * bk * w;
      kk = Math.max(kk, 24);
    }

    const dodging = f.dodgeT > 0 && f.state === 'idle';
    const dodgeBlend = dodging ? 1 : f.state === 'idle' ? smooth(THREE.MathUtils.clamp(f.dodgeTail / 0.24, 0, 1)) : 0;
    if (dodging) {
      const fw = g.toward(f, o);
      const dot = f.dodgeDir.x * -fw.y + f.dodgeDir.y * fw.x;
      const back = -(f.dodgeDir.x * fw.x + f.dodgeDir.y * fw.y);
      const du = 1 - Math.max(0, f.dodgeT) / f.dodgeDur;

      const dipLoad = Math.sin(Math.PI * Math.pow(du, 0.78));
      const uCurve = Math.sin(Math.PI * du);
      const rollFollow = Math.sin(Math.PI * Math.pow(du, 1.15));
      const wave = Math.sin(Math.PI * 2 * du);
      if (back >= 0.35) {

        ln = -0.16 * uCurve;
        lg = -0.32 * rollFollow;
        tw = 0.08 * rollFollow;
        rl = 0.02 * uCurve;
        dp = 0.14 + 0.16 * dipLoad;
        const backLead = P(-0.52, -0.34, 0.26, -1.58);
        const backRear = P(-0.78, -0.56, 0.16, -2.06);
        a0 = lerpPose(a0, backLead, rollFollow * 0.85);
        a1 = lerpPose(a1, backRear, rollFollow * 0.85);
      } else if (Math.abs(dot) > 0.35) {

        const uDip = Math.sin(Math.PI * Math.min(1, du * 1.15));
        rl = dot * 0.48 * rollFollow + dot * 0.14 * wave;
        tw = -dot * 0.62 * rollFollow + dot * 0.16 * wave;
        ln = 0.12 + 0.22 * uDip - 0.1 * wave;
        lg = 0.22 * rollFollow;
        dp = 0.22 + 0.28 * dipLoad;
        const counterCoil = P(-0.46, -0.28, 0.36, -1.52);
        const templeGuard = P(-0.88, -0.64, 0.14, -2.14);
        a0 = lerpPose(a0, dot > 0 ? templeGuard : counterCoil, rollFollow * 0.86);
        a1 = lerpPose(a1, dot > 0 ? counterCoil : templeGuard, rollFollow * 0.86);
      } else {

        ln = 0.16 * uCurve;
        lg = 0.32 * rollFollow;
        tw = 0.06 * rollFollow;
        rl = 0;
        dp = 0.16 + 0.18 * dipLoad;
        const fwdLead = P(-0.58, -0.38, 0.26, -1.72);
        const fwdRear = P(-0.80, -0.60, 0.15, -2.12);
        a0 = lerpPose(a0, fwdLead, rollFollow * 0.85);
        a1 = lerpPose(a1, fwdRear, rollFollow * 0.85);
      }
      kk = 42;
    }

    if (f.recoilT > 0 && f.recoilTot > 0) {
      const u = f.recoilT / f.recoilTot;
      const jolt = Math.sin(u * Math.PI) * f.recoilAmt;
      const arms = f.recoilArm === 2 ? [0, 1] : [f.recoilArm];
      for (const i of arms) {
        const src = i === 0 ? a0 : a1;
        const rec = P(src.sx + 0.16 * jolt, src.sy, src.sz + (i === 0 ? -1 : 1) * 0.05 * jolt, src.ex - 0.36 * jolt);
        if (i === 0) a0 = rec;
        else a1 = rec;
      }
      ln -= 0.1 * jolt;
      dp += 0.07 * jolt;
      tw += (f.recoilArm === 0 ? -1 : 1) * 0.06 * jolt;
    }

    const atk = f.state === 'attack';
    const isWindmillSpin = atk && f.move?.id === 'windmill' && f.moveT < f.move.strikeAt * 0.94;
    const soft = f.softT > 0 ? Math.max(0.4, 0.45 + 0.55 * (1 - f.softT / 0.9)) : 1;
    const hzA = Math.sqrt(kk) * 1.9 * soft;
    const zA = atk ? 0.66 : lerp(0.82, 0.74, dodgeBlend);
    const tgt = [a0, a1];
    for (let i = 0; i < 2; i++) {
      const ps = tgt[i];
      const sp = f.armS[i];
      if (isWindmillSpin) {

        sp[0].set(ps.sx);
      } else if (atk && f.move?.id === 'windmill') {
        const tau = Math.PI * 2;
        if (sp[0].x < -tau) sp[0].x = ((sp[0].x % tau) + tau) % tau - tau;
      }
      let sxVal = isWindmillSpin ? ps.sx : sp[0].update(ps.sx, hzA, zA, dt);
      const syVal = sp[1].update(ps.sy, hzA, zA, dt);
      const szVal = sp[2].update(ps.sz, hzA, zA, dt);
      const exVal = sp[3].update(ps.ex, hzA, zA, dt);

      if ((f.state === 'down' || f.state === 'ko') && f.riseU < 0.12 && fallStages(f.fallS.x).lay > 0.45) {
        const maxSx = 0.16;
        if (sxVal > maxSx) {
          sxVal = maxSx;
          sp[0].x = maxSx;
          if (sp[0].v > 0) sp[0].v = -sp[0].v * 0.35;
        }
      }
      f.arms[i] = {
        sx: sxVal,
        sy: syVal,
        sz: szVal,
        ex: exVal,
      };
    }

    if (atk && f.move) {
      const armIdx = g.armOf(f, f.move);
      const dToFoe = f.pos.distanceTo(o.pos);
      const fHull = (o.blocking ? 1.42 : 1.16) * o.scale;
      const maxRMod = Math.max(0.6, (dToFoe - fHull) / f.scale);
      if (maxRMod < 2.95) {
        const dF = Math.max(0.6, maxRMod - 0.48);
        const cEl = THREE.MathUtils.clamp((2.90 - dF * dF) / 2.86, -0.999, 0.999);
        const exLim = -(Math.PI - Math.acos(cEl));
        const armsToClamp = armIdx === 2 ? [0, 1] : [armIdx];
        for (const ai of armsToClamp) {
          f.arms[ai].ex = Math.min(f.arms[ai].ex, exLim);
          if (maxRMod < 1.95) f.arms[ai].sx += 0.36 * (1.95 - maxRMod);
        }
      }
    }
    const hzB = (atk ? 10.5 : f.state === 'stagger' ? 9.5 : lerp(5.4, 11.2, dodgeBlend)) * soft;
    const zB = atk ? 0.74 : lerp(0.84, 0.76, dodgeBlend);
    f.twist = f.bodyS.twist.update(tw, hzB, zB, dt);
    const landSnap = g.phase === 'walk' && f.pkLand > 0.3;
    f.lean = f.bodyS.lean.update(ln, landSnap ? 20 : hzB, landSnap ? 0.95 : zB, dt);
    f.lunge = f.bodyS.lunge.update(lg, hzB, 0.8, dt);
    f.dip = f.bodyS.dip.update(dp, landSnap ? 22 : atk ? 10.5 : lerp(6.2, 10.8, dodgeBlend), landSnap ? 0.95 : 0.8, dt);
    f.roll = f.bodyS.roll.update(rl, lerp(6.8, 11.2, dodgeBlend), 0.78, dt);

    const fallTarget = f.state === 'ko' ? f.fallT : f.state === 'down' ? f.fallT : 0;
    const dropping = fallTarget > f.fallS.x;

    const e = THREE.MathUtils.clamp(f.fallS.update(fallTarget, f.state === 'ko' ? 2.05 : dropping ? 1.95 : 1.2, f.state === 'ko' ? 0.88 : dropping ? 0.86 : 1.0, dt), 0, 1.06);

    f.hitV += (f.hit - f.hitV) * (1 - Math.exp(-(f.hit > f.hitV ? 40 : 7) * dt));
    f.hitUpV += (f.hitUp - f.hitUpV) * (1 - Math.exp(-(Math.abs(f.hitUp) > Math.abs(f.hitUpV) ? 40 : 6) * dt));
    if (f.hit < 0.005 && f.hitV < 0.01) {
      f.hitKind = 'standard';
    }

    f.robot.floorY = f.state === 'legend' || f.state === 'legendHit' ? -40 : (g.phase === 'walk' ? (f.state === 'air' ? -1.4 : Math.min(0, f.y)) : 0);

    const safeY = Math.max(f.robot.floorY, f.y);
    f.robot.root.position.set(f.pos.x, safeY, f.pos.y);

    const syT = Math.sin(f.yaw);
    const cyT = Math.cos(f.yaw);
    const kbF = -(f.kb.x * syT + f.kb.y * cyT) / f.scale;
    const kbL = (f.kb.x * cyT - f.kb.y * syT) / f.scale;
    const hsp = THREE.MathUtils.clamp(Math.max(0, kbF) / 10, 0, 1);
    const lsp = THREE.MathUtils.clamp(kbL / 9, -1, 1);
    const inAir = isAirRagdoll;
    const tiltTarget = inAir ? (f.vy > 0 ? 0.22 + hsp * 0.28 : 0.36 + hsp * 0.34) : 0;
    const tiltZTarget = inAir ? lsp * (f.vy > 0 ? 0.3 : 0.52) : 0;
    if (f.state === 'down' || (f.state === 'ko' && f.fallT > 0 && !inAir)) {

      const lay = fallStages(f.fallS.x).lay;
      f.tilt = f.tiltLand * (1 - lay);
      f.tiltZ = f.tiltZLand * (1 - lay);
      if (!f.canvasSlammed && f.fallS.x >= 0.76 && f.riseU <= 0.001) {
        f.canvasSlammed = true;
        g.ragdollSlam(f, 0.95);
        g.landFx(f, 9.5);
        g.trauma = Math.min(0.85, g.trauma + 0.16);
      }
    } else {
      f.tilt = lerp(f.tilt, tiltTarget, 1 - Math.exp(-9 * dt));
      f.tiltZ = lerp(f.tiltZ, tiltZTarget, 1 - Math.exp(-(inAir ? 7 : 5) * dt));
      if (!inAir) {
        f.tiltLand = f.tilt;
        f.tiltZLand = f.tiltZ;
      }
    }
    f.robot.root.rotation.order = 'YXZ';
    f.robot.root.rotation.y = f.yaw;
    f.robot.root.rotation.x = f.flip;
    if (f.flip !== 0) {

      const c = COM_H * f.scale;
      const sn = Math.sin(f.flip);
      const cs = Math.cos(f.flip);
      const safeFlipY = Math.max(f.robot.floorY, f.y + c - c * cs);
      f.robot.root.position.set(f.pos.x - c * sn * Math.sin(f.yaw), safeFlipY, f.pos.y - c * sn * Math.cos(f.yaw));
    }
    const sy = Math.sin(f.yaw);
    const cy = Math.cos(f.yaw);
    const grounded = f.state !== 'ko' && f.state !== 'air' && f.state !== 'down';
    const mvx = !grounded ? 0 : f.vel.x + f.kb.x + f.dash.x;
    const mvz = !grounded ? 0 : f.vel.y + f.kb.y + f.dash.y;
    if (dt > 0) {
      const ax = (mvx - f.prevV.x) / dt;
      const az = (mvz - f.prevV.y) / dt;
      const k = 1 - Math.exp(-10 * dt);
      f.acc.x += (ax - f.acc.x) * k;
      f.acc.y += (az - f.acc.y) * k;
    }
    f.prevV.set(mvx, mvz);

    const burning = (f.panjerReady && !!f.panjerId) || (g.panjerMode && f.isPlayer);
    if (burning) {
      f.pkTick2 -= dt;
      if (f.pkTick2 <= 0) {
        f.pkTick2 = f.panjerReady && f.panjerId ? 0.07 : 0.15;
        const arm = f.panjerId ? g.armOf(f, MOVES[f.panjerId]) : f.hand;
        f.robot.fists[arm === 1 ? 1 : 0].localToWorld(g.aimTmp.set(0, 0, 0));
        g.fx.spark(g.aimTmp, f.panjerId ? 2 : 1, f.panjerId ? 3.4 : 2.6, 0xffd34a, undefined, 1.1, 0.28, 3);
      }
    }
    const pw = g.punchStepOf(f, o);

    const sm = f.state === 'attack' ? f.move : null;
    const strike = sm ? THREE.MathUtils.clamp(f.moveT / Math.max(0.001, sm.strikeAt), 0, 1) : 0;
    const strikePow = sm ? sm.power : 0.5;

    f.robot.floorY = f.state === 'legend' || f.state === 'legendHit' ? -40 : (g.phase === 'walk' ? (f.state === 'air' ? -1.4 : Math.min(0, f.y)) : 0);
    f.robot.footLimit = g.phase === 'walk' ? Infinity : ringCfg.in - 0.45;
    f.robot.animate(
      {
        arms: f.arms,
        twist: f.twist,
        lean: f.lean,
        lunge: f.lunge,
        dip: f.dip,
        roll: f.roll,
        vf: (mvx * sy + mvz * cy) / f.scale,
        vl: (mvx * cy - mvz * sy) / f.scale,
        af: (f.acc.x * sy + f.acc.y * cy) / f.scale,
        al: (f.acc.x * cy - f.acc.y * sy) / f.scale,
        yawRate: f.yawRate,
        air: f.state === 'air' || (f.state === 'ko' && (f.y > 0.02 || f.vy > 0)) ? 1 : 0,
        tuck: f.pkTuck,
        hit: f.hitV,
        hitSign: f.hitSign,
        hitUp: f.hitUpV,
        hitF: f.hitF,
        hitL: f.hitL,
        hitPt: f.hitPt,
        hitSpin: f.hitSpin,
        fall: e,
        time: f.animT,
        glow:
          f.glowBoost +
          (f.counterT > 0 ? 1.2 : 0) +

          (f.panjerId ? 0.4 + 0.9 * panjerCharge(f.panjerHold) : 0) +
          (g.panjerMode && f.isPlayer ? 1.0 : 0) +
          (f.isPlayer && f.meter >= 100 ? 1.0 + Math.sin(f.animT * 10) * 0.6 : 0),
        flash: f.flash,
        tilt: f.tilt,
        tiltZ: f.tiltZ,
        ragdoll: isAirRagdoll || ((f.state === 'down' || f.state === 'ko') && f.riseU <= 0.001 && e < 0.98) ? 1 : 0,
        dash: f.dodgeT > 0 && f.state === 'idle' ? 1 : 0,
        dashF: f.dodgeDir.x * sy + f.dodgeDir.y * cy,
        dashL: f.dodgeDir.x * cy - f.dodgeDir.y * sy,
        sprint: f.sprinting ? 1 : 0,
        headYaw: f.headYaw,
        lookX: THREE.MathUtils.clamp((o.pos.x - f.pos.x) * cy - (o.pos.y - f.pos.y) * sy, -1, 1),
        lookY: THREE.MathUtils.clamp((o.y - f.y) * 0.4, -1, 1),
        punchFoot: pw.foot,
        punchZ: pw.z,
        punchX: pw.x,
        punchDur: pw.dur,
        punchSeq: pw.seq,
        stepLift: pw.lift,

        rise: f.state === 'down' && f.riseU > 0.001 ? f.riseU : undefined,
        riseDir: f.riseDir,
        riseOut: f.riseOut,
        strike,
        strikePow,
        directionalHeadSnap: g.directionalHeadSnap,
        hitKind: f.hitKind,
        hitArm: f.hitArm,
        hitSeq: f.hitSeq,
        hitPower: f.hitPower,
        taunt: f.mode === 'taunt' || f.tauntT > 0 || (g.phase === 'intro' && g.phaseT < 2.0),
        idleBounce: f.mode === 'taunt' || f.tauntT > 0 || (g.phase === 'intro' && g.phaseT < 2.0) ? 0 : undefined,

        shuffle: g.aliStyle && f.isPlayer ? (f.state === 'idle' ? 1 : 0.35) : 0,
      },
      dt,
    );

    f.robot.root.updateMatrixWorld(true);
    const tmp = new THREE.Vector3();
    for (let i = 0; i < 2; i++) {
      const m = f.move;
      const arm = m ? g.armOf(f, m) : -1;
      const isWindmill = !!m && m.id === 'windmill';
      const mine = !!m && (arm === 2 || arm === i || (isWindmill && f.moveT < m.strikeAt * 0.72));

      const forwardStrike = !m ? false : isWindmill ? (f.moveT <= m.impact) : (f.moveT >= m.strikeAt - 0.06 && f.moveT <= m.impact + 0.015);
      const emit = dt > 0 && f.state === 'attack' && mine && forwardStrike;
      tmp.set(0, -1.0, 0.05);
      f.robot.fists[i].localToWorld(tmp);

      f.trails[i].width = m ? trailWidthFor(m.id, f.scale, f.rage) : 0.28 * f.scale * (f.rage ? 1.25 : 1);

      if (
        dt > 0 &&
        f.state === 'attack' &&
        mine &&
        m!.power > 0.45 &&
        !f.whooshed &&
        (f.moveT >= m!.strikeAt - 0.1 || isWindmill) &&
        Math.random() < (isWindmill ? 0.08 : 0.30)
      ) {
        g.fx.spark(
          tmp,
          1,
          2.5 + m!.power * 3.5,
          isWindmill ? 0xffb830 : f.isPlayer ? 0x8fd0ff : 0xffb040,
          new THREE.Vector3(0, 0.25, 0),
          0.6,
          0.22,
          1,
        );
      }
      f.trails[i].update(tmp, emit, dt, g.camera);
    }
  }
