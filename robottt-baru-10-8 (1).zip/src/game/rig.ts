export const L1 = 2.0;
export const L2 = 1.92;
export const HIP_Y = 2.85;
export const UP = 0.71;
export const CY = 0.35;
