import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { Robot, RobotStyle } from './robot';
import { L1, L2, HIP_Y, CY, UP } from './rig';

export interface Ctx {
  main: THREE.MeshStandardMaterial;
  sec: THREE.MeshStandardMaterial;
  dark: THREE.MeshStandardMaterial;
  steel: THREE.MeshStandardMaterial;
  accent: THREE.MeshStandardMaterial;
  glow: THREE.MeshStandardMaterial;
  joint: THREE.MeshStandardMaterial;
  rubber: THREE.MeshStandardMaterial;
  visor: THREE.MeshStandardMaterial;
  core: THREE.MeshStandardMaterial;
  style: RobotStyle;
}

export interface Opt {
  variant: 'atom' | 'brute';
  th: number;
  cw: number;
  fs: number;
  lt: number;
}

export interface SkinMeta {
  id: number;
  name: string;
  sub: string;
  rarity: 'SIGNATURE' | 'RARE' | 'EPIC' | 'ULTRA RARE' | 'LEGENDARY' | 'MYTHIC' | 'DIVINE' | 'APEX';
  color: string;
  accent: string;
}

export const HELMET_SKINS: SkinMeta[] = [
  { id: 0, name: 'ATLAS PRIME', sub: 'Helm Bawaan Robot ATLAS · G2 Sparring Mesh & Radiator Crown', rarity: 'SIGNATURE', color: '#45d6ff', accent: '#1e50a2' },
  { id: 1, name: 'ZEUS REAL STEEL 100%', sub: 'Model 3D Asli Zeus Dari Ujung Kepala Sampai Ujung Kaki', rarity: 'DIVINE', color: '#22ff44', accent: '#121314' },
];

export const ARMOR_SKINS: SkinMeta[] = [
  { id: 0, name: 'ATLAS TITANIUM', sub: 'Armor Bawaan Robot ATLAS · Carbon-Titanium & Arc Core', rarity: 'SIGNATURE', color: '#45d6ff', accent: '#1540a8' },
  { id: 1, name: 'ZEUS OBSIDIAN 100%', sub: 'Pelat Dada V-Shape & Inti Kristal Zamrud Asli Zeus', rarity: 'DIVINE', color: '#22ff44', accent: '#121314' },
];

export const GLOVE_SKINS: SkinMeta[] = [
  { id: 0, name: 'ATLAS PRO', sub: 'Sarung Tinju Bawaan Robot ATLAS · WRB Heavy Titanium & Arc Cuff', rarity: 'SIGNATURE', color: '#45d6ff', accent: '#1e50a2' },
  { id: 1, name: 'ZEUS HAMMER FIST 100%', sub: 'Tangan Palu & Ventilasi Sirip 5-Lubang Asli Zeus', rarity: 'DIVINE', color: '#22ff44', accent: '#50555a' },
];

export const ATOM_OPT: Opt = { variant: 'atom', th: 0.78, cw: 0.8, fs: 1.04, lt: 0.82 };
export const BRUTE_OPT: Opt = { variant: 'brute', th: 0.96, cw: 0.98, fs: 1.18, lt: 0.94 };

type V3 = [number, number, number];
type Pts = [number, number][];

const glarePts = (s: number, k = 1, dx = 0): Pts =>
  (
    [
      [-0.1, 0.012],
      [0.085, 0.09],
      [0.135, 0.05],
      [0.0, -0.05],
      [-0.09, -0.036],
    ] as Pts
  ).map(([x, y]) => [(x + dx) * s * k, y * k]);
const glareBrow = (s: number): Pts =>
  (
    [
      [-0.13, 0.02],
      [0.15, 0.1],
      [0.17, 0.06],
      [-0.11, -0.012],
    ] as Pts
  ).map(([x, y]) => [x * s, y]);

const RB = (w: number, h: number, d: number, r = 0.07) => new RoundedBoxGeometry(w, h, d, 3, Math.min(r, w / 2.2, h / 2.2, d / 2.2));
const tcyl = (rt: number, rb: number, h: number, seg = 20) => new THREE.CylinderGeometry(rt, rb, h, seg);
const sph = (r: number, ws = 20, hs = 14) => new THREE.SphereGeometry(r, ws, hs);
const torus = (r: number, t: number, seg = 28) => new THREE.TorusGeometry(r, t, 8, seg);

const lathe = (pts: Pts, k = 1, seg = 24) => new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r * k, y)), seg);

const plate = (pts: Pts, depth: number, bevel = 0.04) => {
  const sh = new THREE.Shape();
  pts.forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y)));
  sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, steps: 1 });
  g.translate(0, 0, -depth / 2);
  return g;
};

const sideSolid = (pts: Pts, width: number, bevel = 0.05) => {
  const g = plate(pts, width, bevel);
  g.rotateY(-Math.PI / 2);
  return g;
};

const arcPlate = (rIn: number, rOut: number, theta: number, h: number, bevel = 0.025) => {
  const sh = new THREE.Shape();
  const a0 = -theta / 2;
  const a1 = theta / 2;
  sh.moveTo(rOut * Math.cos(a0), rOut * Math.sin(a0));
  sh.absarc(0, 0, rOut, a0, a1, false);
  sh.absarc(0, 0, rIn, a1, a0, true);
  sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: h, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel * 0.8, bevelSegments: 2, curveSegments: 22 });
  g.translate(0, 0, -h / 2);
  g.rotateX(-Math.PI / 2);
  g.rotateY(-Math.PI / 2);
  return g;
};

const dome = (r: number, cover = 0.5) => new THREE.SphereGeometry(r, 26, 14, 0, Math.PI * 2, 0, Math.PI * cover);

class Batch {
  constructor(private tag = '') {}
  private map = new Map<string, { parent: THREE.Object3D; mat: THREE.Material; geos: THREE.BufferGeometry[] }>();
  private q = new THREE.Quaternion();
  private e = new THREE.Euler();
  private m4 = new THREE.Matrix4();

  add(parent: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0, rot: V3 = [0, 0, 0], scl: V3 = [1, 1, 1]) {
    this.e.set(rot[0], rot[1], rot[2], 'XYZ');
    this.q.setFromEuler(this.e);
    this.m4.compose(new THREE.Vector3(x, y, z), this.q, new THREE.Vector3(scl[0], scl[1], scl[2]));
    const g = geo.index ? geo.toNonIndexed() : geo;
    g.applyMatrix4(this.m4);
    const key = parent.uuid + '|' + mat.uuid;
    let ent = this.map.get(key);
    if (!ent) {
      ent = { parent, mat, geos: [] };
      this.map.set(key, ent);
    }
    ent.geos.push(g);
  }

  flush() {
    for (const { parent, mat, geos } of this.map.values()) {
      const merged = mergeGeometries(geos, false);
      if (!merged) continue;
      const mesh = new THREE.Mesh(merged, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      if (this.tag) mesh.userData.kit = this.tag;
      parent.add(mesh);
    }
    this.map.clear();
  }
}

export function applyArmorPalette(r: Robot, c: Ctx, o: Opt) {
  if (o.variant !== 'atom') return;
  c.main.color.setHex(c.style.main);
  r.armorColor = c.style.main;
  c.main.metalness = 0.5;
  c.main.roughness = 0.3;
  c.sec.color.setHex(c.style.secondary);
  c.accent.color.setHex(c.style.accent);
  c.accent.metalness = 0.65;
  c.accent.roughness = 0.28;
  c.glow.color.setHex(c.style.glow);
  c.glow.emissive.setHex(c.style.glow);
}

export function buildRobot(r: Robot, c: Ctx, o: Opt) {
  applyArmorPalette(r, c, o);
  const b = new Batch();
  r.pelvis.position.y = UP;
  buildPelvis(r, b, c);
  buildLegs(r, b, c, o);
  buildWaist(r, b, c);
  buildChest(r, b, c, o);
  buildNeckAndHead(r, b, c, o);
  buildArms(r, b, c, o);
  b.flush();
}

function buildPelvis(r: Robot, b: Batch, c: Ctx) {
  const P = r.pelvis;

  b.add(
    P,
    sideSolid([[-0.36, 0.34], [0.36, 0.34], [0.42, 0.0], [0.24, -0.26], [-0.24, -0.26], [-0.42, 0.0]], 0.96, 0.06),
    c.sec,
    0,
    3.04,
    0,
  );

  const vPlate = [
    [-0.48, 0.28],
    [0.48, 0.28],
    [0.36, 0.02],
    [0.16, -0.26],
    [-0.16, -0.26],
    [-0.36, 0.02],
  ] as Pts;
  b.add(P, plate(vPlate, 0.14, 0.04), c.main, 0, 3.04, 0.38);
  b.add(P, plate([[-0.22, 0.12], [0.22, 0.12], [0.14, -0.1], [-0.14, -0.1]], 0.06, 0.024), c.accent, 0, 3.08, 0.45);

  b.add(P, plate(vPlate, 0.14, 0.04), c.main, 0, 3.04, -0.38);

  b.add(P, RB(1.36, 0.11, 0.84, 0.05), c.steel, 0, 3.36, 0);
  b.add(P, RB(0.96, 0.026, 0.05, 0.01), c.glow, 0, 3.41, 0.41);

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    b.add(P, RB(0.06, 0.42, 0.05, 0.018), c.steel, s * 0.32, 3.08, 0.41, [0, 0, s * 0.44]);
    b.add(P, RB(0.06, 0.42, 0.05, 0.018), c.steel, s * 0.32, 3.08, -0.41, [0, 0, s * 0.44]);
  }

  b.add(P, sideSolid([[-0.34, 0.16], [0.34, 0.16], [0.22, -0.14], [-0.22, -0.14]], 0.36, 0.04), c.main, 0, 2.78, 0);
  b.add(P, RB(0.06, 0.24, 0.28, 0.018), c.joint, 0, 2.76, 0);

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    b.add(P, tcyl(0.24, 0.24, 0.28, 20).rotateZ(Math.PI / 2), c.joint, s * 0.58, 2.85, 0);
    b.add(P, tcyl(0.32, 0.32, 0.2, 22).rotateZ(Math.PI / 2), c.joint, s * 0.7, 2.85, 0);
  }
}

function buildLegs(r: Robot, b: Batch, c: Ctx, o: Opt) {
  const lt = o.lt;
  const sy1 = L1 / 1.5;
  const sy2 = L2 / 1.42;

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;

    const hip = new THREE.Group();
    hip.position.set(s * 0.74, HIP_Y, 0);
    hip.rotation.order = 'ZXY';
    r.pelvis.add(hip);
    r.hipJ.push(hip);

    b.add(hip, tcyl(0.31 * lt, 0.31 * lt, 0.38, 22).rotateZ(Math.PI / 2), c.steel);
    b.add(hip, tcyl(0.26 * lt, 0.26 * lt, 0.44, 20).rotateZ(Math.PI / 2), c.joint);

    const thigh = new THREE.Group();
    thigh.scale.set(1, sy1, 1);
    hip.add(thigh);

    b.add(
      thigh,
      lathe(
        [
          [0, -1.5],
          [0.25, -1.5],
          [0.28, -1.34],
          [0.33, -1.04],
          [0.41, -0.66],
          [0.47, -0.32],
          [0.45, -0.08],
          [0.36, 0.04],
          [0, 0.06],
        ],
        lt,
      ),
      c.sec,
    );

    b.add(thigh, arcPlate(0.44 * lt, 0.57 * lt, 2.45, 1.08), c.main, 0, -0.56, 0);

    b.add(thigh, arcPlate(0.575 * lt, 0.6 * lt, 1.9, 0.032), c.accent, 0, -0.34, 0);

    b.add(thigh, arcPlate(0.42 * lt, 0.55 * lt, 2.25, 1.04), c.main, 0, -0.58, 0, [0, Math.PI, 0]);
    b.add(thigh, RB(0.46 * lt, 0.045, 0.055, 0.018), c.steel, 0, -0.44, -0.49 * lt);

    b.add(thigh, arcPlate(0.34 * lt, 0.46 * lt, 2.0, 0.26), c.main, 0, -1.32, 0);

    const knee = new THREE.Group();
    knee.position.y = -L1;
    hip.add(knee);
    r.kneeJ.push(knee);

    b.add(knee, tcyl(0.3 * lt, 0.3 * lt, 0.54, 24).rotateZ(Math.PI / 2), c.steel);
    b.add(knee, tcyl(0.23 * lt, 0.23 * lt, 0.6, 20).rotateZ(Math.PI / 2), c.steel);

    b.add(knee, arcPlate(0.3 * lt, 0.4 * lt, 1.35, 0.34), c.main, 0, -0.04, 0, [0, Math.PI, 0]);
    for (let j = 0; j < 2; j++) {
      const ks = j === 0 ? 1 : -1;
      b.add(knee, tcyl(0.15 * lt, 0.15 * lt, 0.09, 20).rotateZ(Math.PI / 2), c.steel, ks * 0.33, 0, 0);
      b.add(knee, sph(0.06), c.dark, ks * 0.39, 0, 0);
    }

    const cap = new THREE.Group();
    cap.position.set(0, 0, 0.28 * lt);
    knee.add(cap);
    r.kneeCaps.push(cap);
    b.add(
      cap,
      sideSolid(
        [
          [-0.26, -0.3],
          [0.16, -0.24],
          [0.34, 0.02],
          [0.22, 0.28],
          [-0.18, 0.3],
          [-0.32, 0],
        ],
        0.6 * lt,
        0.045,
      ),
      c.main,
    );
    b.add(
      cap,
      plate(
        [
          [-0.06, 0.06],
          [0.06, 0.06],
          [0.09, 0.0],
          [0, -0.11],
          [-0.09, 0.0],
        ],
        0.05,
        0.012,
      ),
      c.glow,
      0,
      0.02,
      0.36 * lt,
    );

    const shin = new THREE.Group();
    shin.scale.set(1, sy2, 1);
    knee.add(shin);

    b.add(
      shin,
      lathe(
        [
          [0, -1.42],
          [0.29, -1.42],
          [0.32, -1.32],
          [0.33, -1.08],
          [0.26, -0.82],
          [0.31, -0.56],
          [0.38, -0.34],
          [0.35, -0.14],
          [0.33, -0.03],
          [0, 0],
        ],
        lt,
      ),
      c.sec,
    );

    b.add(shin, arcPlate(0.29 * lt, 0.4 * lt, 2.4, 0.8), c.main, 0, -0.42, 0, [0.04, 0, 0]);

    b.add(shin, arcPlate(0.31 * lt, 0.44 * lt, 2.25, 0.42), c.main, 0, -1.17, 0.02, [0.11, 0, 0]);

    b.add(shin, arcPlate(0.29 * lt, 0.4 * lt, 2.05, 0.64), c.main, 0, -0.46, -0.02, [0.08, Math.PI, 0]);

    b.add(shin, arcPlate(0.41 * lt, 0.44 * lt, 2.05, 0.048), c.accent, 0, -0.84, 0, [0.04, 0, 0]);
    b.add(shin, RB(0.03, 0.5, 0.03, 0.01), c.glow, 0, -0.6, 0.41 * lt);

    for (let j = 0; j < 2; j++) {
      const cs = j === 0 ? 1 : -1;
      b.add(shin, RB(0.065 * lt, 0.96, 0.11, 0.02), c.steel, cs * 0.13 * lt, -0.78, -0.28 * (lt / 0.82), [0.07, 0, 0]);
    }

    const ankle = new THREE.Group();
    ankle.position.y = -L2;
    knee.add(ankle);
    r.footJ.push(ankle);

    b.add(ankle, RB(0.48 * lt, 0.3, 0.44, 0.08), c.dark, 0, -0.03, 0.1);
    b.add(ankle, tcyl(0.19 * lt, 0.19 * lt, 0.44 * lt, 20).rotateZ(Math.PI / 2), c.steel, 0, 0.06, 0);
    b.add(ankle, tcyl(0.13 * lt, 0.13 * lt, 0.5 * lt, 18).rotateZ(Math.PI / 2), c.joint, 0, 0.06, 0);

    const bw = 0.74 + lt * 0.06;

    b.add(ankle, RB(bw, 0.07, 0.96, 0.03), c.rubber, 0, -0.175, -0.02);

    b.add(ankle, sideSolid([[-0.48, -0.14], [-0.52, 0.06], [-0.34, 0.18], [-0.08, 0.2], [-0.08, -0.14]], bw * 0.92, 0.05), c.main);
    b.add(ankle, RB(0.26, 0.1, 0.18, 0.03), c.steel, 0, 0.0, -0.52);

    b.add(ankle, sideSolid([[-0.1, 0.2], [0.3, 0.18], [0.6, 0.06], [0.64, -0.03], [-0.1, -0.03]], bw * 0.96, 0.05), c.main);
    b.add(ankle, RB(bw * 0.5, 0.035, 0.07, 0.012), c.accent, 0, 0.19, 0.34);

    b.add(ankle, sideSolid([[0.58, 0.06], [0.84, -0.02], [0.88, -0.1], [0.58, -0.12]], bw * 0.86, 0.04), c.dark);
    b.add(ankle, tcyl(0.045, 0.045, bw * 0.9, 14).rotateZ(Math.PI / 2), c.steel, 0, -0.07, 0.7);

    for (let j = 0; j < 3; j++) {
      const t = j - 1;
      const toe = new THREE.Group();
      toe.position.set(s * t * 0.22, -0.05, 0.66);
      toe.rotation.y = -s * t * 0.2;
      ankle.add(toe);
      b.add(toe, sideSolid([[-0.06, 0.05], [0.26, 0.02], [0.52, -0.05], [0.56, -0.09], [-0.06, -0.09]], 0.2, 0.03), c.main);
      b.add(toe, RB(0.19, 0.06, 0.42, 0.025), c.rubber, 0, -0.13, 0.3);
    }
  }
}

function buildWaist(r: Robot, b: Batch, c: Ctx) {
  const W = r.waist;
  W.position.set(0, 3.45, 0);
  r.pelvis.add(W);

  b.add(W, tcyl(0.52, 0.54, 0.26, 30), c.joint, 0, 0.06, 0.02, [0, 0, 0], [1, 1, 0.86]);
  b.add(W, torus(0.53, 0.05, 32), c.steel, 0, 0.2, 0.02, [Math.PI / 2, 0, 0]);
}

function buildChest(r: Robot, b: Batch, c: Ctx, o: Opt) {
  const C = r.chest;
  C.position.set(0, CY, 0);
  r.waist.add(C);
  buildChestMesh(C, b, c, o);
}

function buildChestMesh(C: THREE.Group, b: Batch, c: Ctx, o: Opt) {
  const W = o.cw;
  const atom = o.variant === 'atom';
  const X = (p: Pts): Pts => p.map(([x, y]) => [x * W, y]);
  const put = (g: THREE.BufferGeometry, m: THREE.Material, x: number, y: number, z: number, rot?: V3, scl?: V3) => b.add(C, g, m, x, y, z, rot, scl);

  const core = new THREE.Shape();
  const outline: Pts = X([[-0.48, 0.0], [0.48, 0.0], [0.82, 0.5], [1.14, 1.05], [1.22, 1.42], [1.02, 1.68], [0.44, 1.74], [-0.44, 1.74], [-1.02, 1.68], [-1.22, 1.42], [-1.14, 1.05], [-0.82, 0.5]]);
  outline.forEach(([x, y], i) => (i ? core.lineTo(x, y) : core.moveTo(x, y)));
  core.closePath();
  const coreG = new THREE.ExtrudeGeometry(core, { depth: 0.84, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 4, steps: 1 });
  coreG.translate(0, 0, -0.42);
  put(coreG, c.sec, 0, 0, 0);

  const tilt: V3 = [-0.08, 0, 0];
  const pecScale: V3 = [1.26, 1, 1];
  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    const px = s * 0.54 * W;

    put(arcPlate(0.49, 0.59, 2.15, 0.88), c.main, px, 1.17, 0, tilt, pecScale);

    put(arcPlate(0.595, 0.64, 2.12, 0.055), c.accent, px, 0.79, 0, tilt, pecScale);

    put(plate([[0.12 * W, 1.56], [0.84 * W, 1.52], [0.76 * W, 1.34], [0.16 * W, 1.38]].map(([x, y]) => [x * s, y]), 0.08, 0.022), c.steel, 0, 0, 0.51, [-0.12, s * -0.08, 0]);

    put(RB(0.96 * W, 0.38, 0.88, 0.16), c.main, s * 0.72 * W, 1.64, -0.07, [0, 0, s * -0.3]);
  }

  put(plate([[-0.16, 1.56], [0.16, 1.56], [0.22, 1.04], [0, 0.66], [-0.22, 1.04]], 0.1, 0.024), c.dark, 0, 0, 0.53);

  put(tcyl(0.25, 0.275, 0.08, 8).rotateX(Math.PI / 2), c.steel, 0, 1.06, 0.59);

  put(tcyl(0.2, 0.2, 0.036, 16).rotateX(Math.PI / 2), c.dark, 0, 1.06, 0.63);

  put(tcyl(0.165, 0.165, 0.032, 28).rotateX(Math.PI / 2), c.glow, 0, 1.06, 0.652);
  put(torus(0.185, 0.02, 24), c.accent, 0, 1.06, 0.655);

  put(tcyl(0.085, 0.095, 0.04, 20).rotateX(Math.PI / 2), c.core, 0, 1.06, 0.67);

  put(
    plate(X([[-0.68, 0.68], [0.68, 0.68], [0.56, 0.12], [0.34, -0.08], [-0.34, -0.08], [-0.56, 0.12]]), 0.1, 0.028),
    c.dark,
    0,
    0,
    0.45,
  );

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;

    put(
      plate([[0.05 * W, 0.64], [0.48 * W, 0.62], [0.42 * W, 0.38], [0.05 * W, 0.36]].map(([x, y]) => [x * s, y]), 0.08, 0.022),
      c.main,
      0,
      0,
      0.5,
      [0.04, s * -0.1, 0],
    );

    put(
      plate([[0.05 * W, 0.32], [0.4 * W, 0.32], [0.32 * W, 0.08], [0.05 * W, 0.06]].map(([x, y]) => [x * s, y]), 0.08, 0.02),
      c.main,
      0,
      0,
      0.48,
      [0.05, s * -0.1, 0],
    );

    put(
      plate([[0.46 * W, 0.68], [0.78 * W, 0.64], [0.66 * W, 0.16], [0.38 * W, 0.12]].map(([x, y]) => [x * s, y]), 0.09, 0.024),
      c.steel,
      0,
      0,
      0.38,
      [0, s * -0.32, 0],
    );
  }

  put(RB(0.036, 0.48, 0.04, 0.012), c.glow, 0, 0.35, 0.515);
  put(RB(0.52 * W, 0.06, 0.06, 0.02), c.accent, 0, 0.04, 0.5);

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    put(plate(X([[0.06, 1.68], [0.9, 1.66], [0.74, 1.46], [0.06, 1.5]]), 0.09, 0.028), c.steel, s, 0, 0.46);
  }

  put(plate(X([[-0.98, 1.62], [0.98, 1.62], [1.06, 1.1], [0.62, 0.1], [-0.62, 0.1], [-1.06, 1.1]]), 0.15, 0.045), c.main, 0, 0, -0.58);

  put(plate(X([[-0.3, 1.52], [0.3, 1.52], [0.34, 0.34], [0, 0.14], [-0.34, 0.34]]), 0.12, 0.04), c.dark, 0, 0, -0.74);
  put(RB(0.035, 1.15, 0.035, 0.015), c.glow, 0, 0.92, -0.9);
  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;

    const blade: Pts = [[0.1, 1.55], [0.95, 1.5], [0.98, 1.0], [0.55, 0.75], [0.1, 0.9]].map(([x, y]): [number, number] => [x * s * W, y]);
    put(plate(blade, 0.12, 0.038), c.main, 0, 0, -0.68, [0.06, s * 0.16, 0]);
  }
  if (atom) {

    put(RB(0.86, 0.58, 0.32, 0.14), c.dark, 0, 1.12, -0.94);
    put(RB(0.72, 0.05, 0.06, 0.02), c.accent, 0, 1.43, -1.1);
    put(RB(0.6, 0.035, 0.05, 0.014), c.glow, 0, 0.9, -1.12);
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      put(tcyl(0.11, 0.14, 0.1, 20).rotateX(-Math.PI / 2), c.steel, s * 0.3, 0.78, -1.02);
      put(tcyl(0.075, 0.075, 0.03, 20).rotateX(-Math.PI / 2), c.glow, s * 0.3, 0.75, -1.05);
    }
  } else {

    put(RB(1.12 * W, 0.5, 0.32, 0.12), c.dark, 0, 1.05, -0.88);
    put(RB(0.86 * W, 0.05, 0.06, 0.02), c.accent, 0, 1.31, -1.06);
    put(RB(0.7 * W, 0.035, 0.05, 0.014), c.glow, 0, 0.86, -1.06);
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      put(tcyl(0.16, 0.2, 1.0, 18), c.steel, s * 0.62, 1.5, -0.92, [0, 0, s * -0.14]);
      put(tcyl(0.105, 0.105, 0.05, 16), c.glow, s * 0.69, 2.0, -0.92);
    }
  }

  put(torus(0.42, 0.075, 30), c.steel, 0, 1.74, 0, [Math.PI / 2, 0, 0]);
  put(plate([[-0.5, 1.66], [0.5, 1.66], [0.44, 1.96], [-0.44, 1.96]], 0.11, 0.036), c.main, 0, 0, -0.38);
}

function buildNeckAndHead(r: Robot, b: Batch, c: Ctx, o: Opt) {
  const N = r.neck;
  N.position.set(0, 2.14 - CY, 0.08);
  r.chest.add(N);
  b.add(N, tcyl(0.27, 0.34, 0.5, 18), c.joint, 0, 0.02, -0.04);
  for (let k = 0; k < 3; k++) b.add(N, torus(0.3 - k * 0.01, 0.035, 20), c.rubber, 0, -0.1 + k * 0.1, -0.04, [Math.PI / 2, 0, 0]);
  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    b.add(N, tcyl(0.04, 0.04, 0.6, 6), c.glow, s * 0.2, 0.1, 0.16);
  }
  const H = r.head;
  H.position.set(0, 0.36, 0.06);
  H.scale.setScalar(1.04);
  N.add(H);
  buildHeadMesh(r, H, b, c, o);
}

function buildHeadMesh(r: Robot, H: THREE.Group, b: Batch, c: Ctx, o: Opt) {
  if (o.variant === 'atom') {
    atomHelmet(r, H, b, c);
  } else {
    bruteHelmet(r, H, b, c);
  }
}

function atomHelmet(r: Robot, H: THREE.Group, b: Batch, c: Ctx) {
  const put = (g: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0, rot?: V3, scl?: V3) => b.add(H, g, m, x, y, z, rot, scl);

  put(RB(0.72, 0.56, 0.76, 0.2), c.main, 0, 0.3, -0.02);
  put(RB(0.7, 0.26, 0.5, 0.14), c.main, 0, -0.02, -0.14);

  put(sideSolid([[0.3, 0.6], [0.44, 0.44], [0.46, 0.16], [0.3, 0.1]], 0.78, 0.03), c.main);
  put(RB(0.8, 0.035, 0.08, 0.012), c.steel, 0, 0.12, 0.43);
  put(RB(0.5, 0.025, 0.05, 0.01), c.accent, 0, 0.17, 0.45);
  for (let i = 0; i < 2; i++) {
    const s2 = i === 0 ? 1 : -1;
    put(RB(0.28, 0.03, 0.05, 0.012), c.accent, s2 * 0.15, 0.34, 0.42, [0, 0, -s2 * 0.5]);
  }

  const FINS = 11;
  for (let i = 0; i < FINS; i++) {
    const u = (i / (FINS - 1)) * 2 - 1;
    const h = 0.19 - u * u * 0.12;
    const d = 0.7 - u * u * 0.24;
    put(RB(0.028, h, d, 0.012), c.steel, u * 0.33, 0.58 + h / 2, -0.02);
  }

  put(RB(0.74, 0.05, 0.76, 0.025), c.main, 0, 0.585, -0.02);
  put(RB(0.4, 0.026, 0.03, 0.01), c.glow, 0, 0.6, 0.36);

  put(RB(0.52, 0.32, 0.1, 0.04), c.dark, 0, -0.24, 0.33);
  const MX = 9;
  const MY = 6;
  for (let i = 0; i < MX; i++) put(RB(0.012, 0.3, 0.012, 0.004), c.rubber, (i / (MX - 1) - 0.5) * 0.48, -0.24, 0.38);
  for (let j = 0; j < MY; j++) put(RB(0.49, 0.012, 0.012, 0.004), c.rubber, 0, -0.24 + (j / (MY - 1) - 0.5) * 0.28, 0.38);
  put(RB(0.56, 0.34, 0.03, 0.02), c.steel, 0, -0.24, 0.35, [0, 0, 0], [1, 1, 0.4]);

  put(sideSolid([[0.34, 0.28], [0.4, 0.1], [0.4, -0.06], [-0.02, -0.06]], 0.5, 0.03), c.dark, 0, 0.0, 0);

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    const x = s * 0.155;
    const y = -0.02;
    const tilt: V3 = [0, 0, s * 0.24];
    put(tcyl(0.135, 0.135, 0.04, 6).rotateX(Math.PI / 2), c.steel, x, y, 0.4, tilt);
    put(tcyl(0.11, 0.11, 0.03, 6).rotateX(Math.PI / 2), c.dark, x, y, 0.418, tilt);
    put(RB(0.18, 0.026, 0.022, 0.008), c.accent, x, y + 0.125, 0.43, [0, 0, s * 0.3]);

    const eye = new THREE.Group();
    eye.position.set(x, y, 0.43);
    eye.rotation.set(0, 0, s * 0.26);
    H.add(eye);
    r.eyeOptics.push(eye);

    const irisMat = new THREE.MeshBasicMaterial({ color: c.style.glow });
    const iris = new THREE.Mesh(tcyl(0.086, 0.086, 0.012, 6).rotateX(Math.PI / 2), irisMat);
    eye.add(iris);
    r.eyeIris.push(iris);

    const pupil = new THREE.Group();
    eye.add(pupil);
    r.eyePupils.push(pupil);

    const slit = new THREE.Mesh(RB(0.024, 0.095, 0.016, 0.006), c.core);
    slit.position.z = 0.01;
    pupil.add(slit);

    const cross = new THREE.Mesh(RB(0.05, 0.016, 0.016, 0.005), c.core);
    cross.position.z = 0.01;
    pupil.add(cross);

    const ringMat = new THREE.MeshBasicMaterial({ color: c.style.glow });
    const ring = new THREE.Mesh(torus(0.044, 0.006, 16), ringMat);
    ring.position.z = 0.008;
    pupil.add(ring);

    const scanMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.85,
    });
    const scanBar = new THREE.Mesh(RB(0.13, 0.008, 0.008, 0.002), scanMat);
    scanBar.position.z = 0.014;
    eye.add(scanBar);
    r.eyeScanners.push(scanBar);

    const flareGeo = new THREE.PlaneGeometry(0.36, 0.038);
    const flareMat = new THREE.MeshBasicMaterial({
      color: c.style.glow,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const flare = new THREE.Mesh(flareGeo, flareMat);
    flare.position.z = 0.02;
    eye.add(flare);
    r.eyeFlares.push(flare);

    const pulseMat = new THREE.MeshBasicMaterial({
      color: c.style.glow,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const pulse = new THREE.Mesh(torus(0.1, 0.012, 26), pulseMat);
    pulse.position.z = 0.03;
    eye.add(pulse);
    r.eyePulses.push(pulse);

    const beamMat = new THREE.MeshBasicMaterial({
      color: c.style.glow,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const beam = new THREE.Mesh(new THREE.PlaneGeometry(0.05, 0.5).rotateX(Math.PI / 2), beamMat);
    beam.position.set(0, 0, 0.3);
    eye.add(beam);
    r.eyeBeams.push(beam);

    const eyeLight = new THREE.PointLight(c.style.glow, 1.2, 1.4, 2.0);
    eyeLight.position.set(0, 0, 0.04);
    eye.add(eyeLight);
    r.eyeLights.push(eyeLight);
  }

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    put(RB(0.11, 0.38, 0.44, 0.06), c.main, s * 0.33, 0.06, -0.02);
    put(RB(0.02, 0.3, 0.16, 0.008), c.dark, s * 0.39, 0.06, 0.06);
    put(tcyl(0.095, 0.095, 0.07, 18).rotateZ(Math.PI / 2), c.steel, s * 0.4, 0.06, -0.08);
    put(torus(0.05, 0.013, 16).rotateY(Math.PI / 2), c.glow, s * 0.45, 0.06, -0.08);
    put(RB(0.07, 0.2, 0.26, 0.03), c.main, s * 0.34, -0.2, -0.08);
    put(RB(0.02, 0.14, 0.2, 0.008), c.dark, s * 0.38, -0.2, -0.08);
  }

  put(RB(0.62, 0.5, 0.12, 0.08), c.main, 0, 0.16, -0.37);
  put(RB(0.22, 0.44, 0.1, 0.04), c.dark, 0, 0.16, -0.42);
  for (let k = 0; k < 3; k++) put(RB(0.56, 0.035, 0.05, 0.012), c.steel, 0, 0.3 - k * 0.1, -0.44);
  put(RB(0.34, 0.2, 0.22, 0.06), c.joint, 0, -0.3, -0.12);

  put(sideSolid([[0.3, -0.36], [0.34, -0.42], [0.2, -0.5], [-0.04, -0.48], [0.02, -0.36]], 0.46, 0.03), c.main, 0, 0, 0);
  put(RB(0.3, 0.03, 0.06, 0.012), c.steel, 0, -0.46, 0.3);

  for (let i = 0; i < 2; i++) {
    const s2 = i === 0 ? 1 : -1;
    put(sideSolid([[0.44, 0.3], [0.46, 0.06], [0.36, -0.3], [0.08, -0.46], [-0.02, -0.46], [0.0, 0.3]], 0.09, 0.025), c.main, s2 * 0.34, 0, 0);
  }
}

function bruteHelmet(r: Robot, H: THREE.Group, b: Batch, c: Ctx) {
  const put = (g: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0, rot?: V3, scl?: V3) => b.add(H, g, m, x, y, z, rot, scl);

  put(
    sideSolid([[-0.5, -0.32], [-0.56, 0.22], [-0.44, 0.46], [0.0, 0.5], [0.34, 0.48], [0.56, 0.3], [0.62, 0.1], [0.6, -0.12], [0.66, -0.3], [0.4, -0.46], [-0.26, -0.42]], 0.9, 0.035),
    c.main,
  );
  put(sideSolid([[-0.3, 0.44], [0.4, 0.48], [0.7, 0.3], [0.72, 0.16], [0.5, 0.2], [-0.3, 0.26]], 1.0, 0.03), c.sec);

  put(plate([[-0.46, 0.14], [0.46, 0.14], [0.4, -0.12], [-0.4, -0.12]], 0.03, 0.01), c.steel, 0, 0, 0.652);
  put(plate([[-0.42, 0.11], [0.42, 0.11], [0.36, -0.09], [-0.36, -0.09]], 0.04, 0.01), c.dark, 0, 0, 0.664);
  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;
    const x0 = s * 0.2;
    put(plate(glarePts(s, 1.32), 0.02, 0.006), c.steel, x0, 0.02, 0.676);
    put(plate(glarePts(s, 1.2), 0.03, 0.006), c.dark, x0, 0.02, 0.682);
    put(plate(glarePts(s, 1.0), 0.04, 0.006), c.glow, x0, 0.02, 0.688);
    put(plate(glarePts(s, 0.5, s * 0.03), 0.05, 0.004), c.core, x0, 0.02, 0.694);

    const optic = new THREE.Group();
    optic.position.set(x0, 0.02, 0.69);
    H.add(optic);
    r.eyeOptics.push(optic);

    const flareGeo = new THREE.PlaneGeometry(0.32, 0.038);
    const flareMat = new THREE.MeshBasicMaterial({
      color: c.style.glow,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const flare = new THREE.Mesh(flareGeo, flareMat);
    flare.position.set(x0, 0.02, 0.706);
    H.add(flare);
    r.eyeFlares.push(flare);

    const pulseMat = new THREE.MeshBasicMaterial({
      color: c.style.glow,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const pulse = new THREE.Mesh(torus(0.11, 0.013, 26), pulseMat);
    pulse.position.set(x0, 0.02, 0.71);
    H.add(pulse);
    r.eyePulses.push(pulse);

    const beamMat = new THREE.MeshBasicMaterial({
      color: c.style.glow,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const beam = new THREE.Mesh(new THREE.PlaneGeometry(0.06, 0.5).rotateX(Math.PI / 2), beamMat);
    beam.position.set(x0, 0.02, 0.98);
    H.add(beam);
    r.eyeBeams.push(beam);

    const eyeLight = new THREE.PointLight(c.style.glow, 1.0, 1.3, 2.0);
    eyeLight.position.set(x0, 0.02, 0.72);
    H.add(eyeLight);
    r.eyeLights.push(eyeLight);

    put(plate(glareBrow(s), 0.05, 0.01), c.sec, x0, 0.16, 0.672);
    put(plate(glareBrow(s).map(([x, y]): [number, number] => [x * 0.94, y * 0.2 - 0.015]), 0.03, 0.004), c.accent, x0, 0.16, 0.7);

    put(RB(0.14, 0.4, 0.58, 0.05), c.sec, s * 0.5, -0.1, 0.02);
    put(tcyl(0.14, 0.14, 0.1, 22).rotateZ(Math.PI / 2), c.steel, s * 0.6, 0.02, -0.1);
    put(torus(0.07, 0.02, 20).rotateY(Math.PI / 2), c.glow, s * 0.66, 0.02, -0.1);
    put(new THREE.ConeGeometry(0.08, 0.28, 6), c.steel, s * 0.42, -0.34, 0.42, [Math.PI / 2 + 0.5, 0, 0]);

    put(sideSolid([[0.1, 0.46], [0.52, 0.8], [0.4, 0.44]], 0.07, 0.02), c.sec, s * 0.42, 0, 0);
  }

  put(RB(0.06, 0.22, 0.07, 0.02), c.steel, 0, 0.0, 0.69);
  put(plate([[-0.34, -0.14], [0.34, -0.14], [0.28, -0.42], [-0.28, -0.42]], 0.06, 0.02), c.dark, 0, 0, 0.67);
  for (let k = -2; k <= 3; k++) put(RB(0.04, 0.1, 0.03, 0.01), c.glow, (k - 0.5) * 0.07, -0.28, 0.725);

  put(sideSolid([[-0.5, 0.46], [-0.3, 0.74], [0.16, 0.78], [0.46, 0.5]], 0.14, 0.03), c.accent);
  put(plate([[-0.46, 0.14], [0.46, 0.14], [0.4, -0.36], [-0.4, -0.36]], 0.1, 0.03), c.dark, 0, 0, -0.58);
  for (let k = 0; k < 3; k++) put(RB(0.6, 0.03, 0.05, 0.01), c.steel, 0, 0.04 - k * 0.1, -0.66);
}

function buildArms(r: Robot, b: Batch, c: Ctx, o: Opt) {
  const th = o.th;
  const fa = th * (o.variant === 'atom' ? 0.88 : 0.94);

  for (let i = 0; i < 2; i++) {
    const s = i === 0 ? 1 : -1;

    const clav = new THREE.Group();
    clav.position.set(s * 0.88, 1.9 - CY, 0);
    r.chest.add(clav);
    r.clavs.push(clav);
    b.add(clav, RB(0.7, 0.24, 0.44, 0.1), c.joint, s * 0.3, 0, 0);

    const sh = new THREE.Group();
    sh.position.set(s * 0.8, -0.32, 0);
    sh.rotation.order = 'YXZ';
    clav.add(sh);
    r.shoulders.push(sh);

    const cap = new THREE.Group();
    cap.position.copy(sh.position);
    clav.add(cap);
    r.caps.push(cap);
    buildCapMesh(cap, b, c, o);

    b.add(sh, sph(0.38 * th), c.joint);

    b.add(
      sh,
      lathe(
        [
          [0, -1.12],
          [0.21, -1.12],
          [0.26, -1.0],
          [0.34, -0.78],
          [0.44, -0.5],
          [0.46, -0.28],
          [0.4, -0.1],
          [0.32, -0.02],
          [0, 0],
        ],
        th,
      ),
      c.sec,
    );

    b.add(sh, arcPlate(0.45 * th, 0.525 * th, 2.2, 0.46), c.main, 0, -0.56, 0.02);

    b.add(sh, arcPlate(0.46 * th, 0.515 * th, 1.9, 0.04), c.accent, 0, -0.36, 0.02);
    b.add(sh, arcPlate(0.43 * th, 0.49 * th, 1.8, 0.05), c.accent, 0, -0.75, 0.01);

    b.add(sh, arcPlate(0.44 * th, 0.515 * th, 2.1, 0.46), c.main, 0, -0.57, 0, [0, Math.PI, 0]);

    b.add(sh, RB(0.04, 0.38, 0.04, 0.012), c.dark, s * 0.46 * th, -0.56, 0);
    b.add(sh, RB(0.02, 0.28, 0.02, 0.006), c.glow, s * 0.48 * th, -0.56, 0);

    const el = new THREE.Group();
    el.position.y = -1.05;
    sh.add(el);
    r.elbows.push(el);

    b.add(el, sph(0.28 * th), c.joint);
    b.add(el, tcyl(0.23 * th, 0.23 * th, 0.09, 22).rotateZ(Math.PI / 2), c.steel, s * 0.28 * th, 0, 0);
    b.add(el, dome(0.19 * th, 0.5).rotateX(-Math.PI / 2), c.steel, 0, 0.0, -0.22 * th);

    b.add(
      el,
      lathe(
        [
          [0, -0.975],
          [0.25, -0.975],
          [0.29, -0.87],
          [0.35, -0.66],
          [0.42, -0.39],
          [0.45, -0.21],
          [0.38, -0.06],
          [0.3, -0.01],
          [0, 0],
        ],
        fa,
      ),
      c.sec,
    );

    b.add(el, arcPlate(0.42 * fa, 0.50 * fa, 2.5, 0.51), c.main, 0, -0.45, 0);
    b.add(el, arcPlate(0.40 * fa, 0.48 * fa, 2.2, 0.495), c.main, 0, -0.465, 0, [0, Math.PI, 0]);
    b.add(el, RB(0.028, 0.36, 0.028, 0.008), c.glow, s * 0.48 * fa, -0.465, 0);

    b.add(el, tcyl(0.30 * fa, 0.38 * fa, 0.12 * fa, 24), c.steel, 0, -0.855, 0);
    b.add(el, torus(0.36 * fa, 0.022 * fa, 24).rotateX(Math.PI / 2), c.accent, 0, -0.855, 0);

    b.add(el, sph(0.24 * fa, 22, 14), c.joint, 0, -0.96, 0);
    b.add(el, torus(0.25 * fa, 0.024 * fa, 24).rotateX(Math.PI / 2), c.steel, 0, -0.93, 0);

    const wr = new THREE.Group();
    wr.position.y = -0.975;
    el.add(wr);
    r.wrists.push(wr);

    const fist = new THREE.Group();
    wr.add(fist);
    r.fists.push(fist);

    buildFistMesh(fist, b, c, o, s);
  }
}

function buildCapMesh(cap: THREE.Group, b: Batch, c: Ctx, o: Opt) {
  const th = o.th;

  b.add(cap, dome(0.5 * th, 0.54), c.main, 0, 0.06, 0, [0, 0, 0], [1, 0.84, 1.06]);
  b.add(cap, arcPlate(0.5 * th, 0.575 * th, 1.9, 0.38), c.main, 0, -0.03, 0);
  b.add(cap, arcPlate(0.52 * th, 0.585 * th, 1.5, 0.055), c.accent, 0, -0.17, 0);
}

function buildFistMesh(fist: THREE.Group, b: Batch, c: Ctx, o: Opt, s: number) {
  const k = o.fs;

  b.add(fist, tcyl(0.31 * k, 0.40 * k, 0.22 * k, 26), c.steel, 0, -0.11 * k, 0);
  b.add(fist, torus(0.40 * k, 0.028 * k, 30), c.glow, 0, -0.20 * k, 0, [Math.PI / 2, 0, 0]);

  b.add(fist, RB(0.82 * k, 0.13 * k, 0.84 * k, 0.04 * k), c.rubber, 0, -0.27 * k, 0.02 * k);
  for (let lc = 0; lc < 3; lc++) b.add(fist, RB(0.28 * k, 0.022 * k, 0.028 * k, 0.006 * k), c.steel, 0, (-0.22 - lc * 0.05) * k, -0.42 * k);

  b.add(fist, RB(0.84 * k, 0.74 * k, 0.86 * k, 0.30 * k), c.dark, 0, -0.58 * k, 0.02 * k);

  b.add(fist, sph(0.41 * k, 26, 16), c.dark, 0, -0.86 * k, 0.12 * k, [0, 0, 0], [1.02, 0.68, 1.02]);

  b.add(fist, RB(0.66 * k, 0.14 * k, 0.24 * k, 0.06 * k), c.main, 0, -0.94 * k, 0.26 * k);
  for (let kn = 0; kn < 4; kn++) {
    const kx = (kn - 1.5) * 0.16 * k;
    b.add(fist, sph(0.038 * k, 12, 8), c.steel, kx, -0.94 * k, 0.36 * k);
  }

  b.add(fist, RB(0.62 * k, 0.46 * k, 0.06 * k, 0.025 * k), c.main, 0, -0.56 * k, 0.44 * k);
  b.add(fist, RB(0.32 * k, 0.035 * k, 0.03 * k, 0.01 * k), c.accent, 0, -0.56 * k, 0.48 * k);
  b.add(fist, RB(0.18 * k, 0.025 * k, 0.02 * k, 0.006 * k), c.glow, 0, -0.56 * k, 0.49 * k);

  b.add(fist, new THREE.CapsuleGeometry(0.13 * k, 0.28 * k, 8, 14), c.rubber, -s * 0.44 * k, -0.66 * k, 0.06 * k, [0.08, 0, -s * 0.16]);
  b.add(fist, RB(0.10 * k, 0.18 * k, 0.18 * k, 0.04 * k), c.main, -s * 0.48 * k, -0.60 * k, 0.12 * k, [0.08, 0, -s * 0.16]);
}

function clearMeshes(g: THREE.Object3D, groupsToo = false) {
  for (let i = g.children.length - 1; i >= 0; i--) {
    const ch = g.children[i];
    if (ch instanceof THREE.Mesh) {
      ch.geometry.dispose();
      g.remove(ch);
    } else if (groupsToo) {
      ch.traverse((n) => {
        if (n instanceof THREE.Mesh) n.geometry.dispose();
      });
      g.remove(ch);
    }
  }
}

export function rebuildHelmetAndGloves(r: Robot, c: Ctx, o: Opt) {

  applyArmorPalette(r, c, o);

  clearMeshes(r.head, true);
  r.eyeOptics.length = 0;
  r.eyeIris.length = 0;
  r.eyePupils.length = 0;
  r.eyeScanners.length = 0;
  r.eyeFlares.length = 0;
  r.eyePulses.length = 0;
  r.eyeBeams.length = 0;
  r.eyeLights.length = 0;

  for (const fist of r.fists) clearMeshes(fist);
  clearMeshes(r.chest);
  for (const cap of r.caps) clearMeshes(cap);

  const b = new Batch();
  buildHeadMesh(r, r.head, b, c, o);
  for (let i = 0; i < r.fists.length; i++) {
    buildFistMesh(r.fists[i] as THREE.Group, b, c, o, i === 0 ? 1 : -1);
  }
  buildChestMesh(r.chest, b, c, o);
  for (let i = 0; i < r.caps.length; i++) buildCapMesh(r.caps[i], b, c, o);
  b.flush();
}
