import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { ROWS_PER_TIER, STAND_ROW_SPACING, STAND_TIERS, standRowHeight, standTierInnerRadius } from './stadiumLayout';

type Upd = (t: number, dt: number, hype: number, focus: THREE.Vector3, camera?: THREE.Camera) => void;

export interface Props {
  update: Upd;
  towers: THREE.Vector3[];
}

const FLOOR = -1.4;
const RB = (w: number, h: number, d: number, r = 0.06) => new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 2.2, h / 2.2, d / 2.2));
const neon = (hex: number, k = 1) => new THREE.MeshBasicMaterial({ color: new THREE.Color(hex).multiplyScalar(k) });

export function buildProps(scene: THREE.Scene): Props {
  const updaters: Upd[] = [];
  const towers: THREE.Vector3[] = [];
  const metal = new THREE.MeshStandardMaterial({ color: 0x1b1f2a, metalness: 0.85, roughness: 0.4 });
  const metal2 = new THREE.MeshStandardMaterial({ color: 0x2a303f, metalness: 0.8, roughness: 0.35 });

  const TOWERS: [number, number, number][] = [
    [19.8, 19.8, 0x4f86e8],
    [-19.8, 19.8, 0x4f86e8],
    [19.8, -19.8, 0xe03a44],
    [-19.8, -19.8, 0xe03a44],
  ];
  const towerStrips: { m: THREE.MeshBasicMaterial; base: THREE.Color; ph: number }[] = [];
  TOWERS.forEach(([x, z, hex], idx) => {
    const g = new THREE.Group();
    g.position.set(x, FLOOR, z);
    scene.add(g);
    const mesh = (geo: THREE.BufferGeometry, m: THREE.Material, px: number, py: number, pz: number) => {
      const o = new THREE.Mesh(geo, m);
      o.position.set(px, py, pz);
      g.add(o);
    };
    mesh(RB(2.6, 1.2, 2.6, 0.15), metal, 0, 0.6, 0);
    mesh(RB(1.5, 11.4, 1.5, 0.12), metal2, 0, 6.9, 0);
    const stripMat = neon(hex, 1);
    towerStrips.push({ m: stripMat, base: new THREE.Color(hex), ph: idx * 1.3 });
    for (const [sx, sz] of [[0.78, 0], [-0.78, 0], [0, 0.78], [0, -0.78]] as [number, number][]) {
      mesh(RB(sz === 0 ? 0.06 : 0.22, 10.6, sx === 0 ? 0.06 : 0.22, 0.02), stripMat, sx, 6.9, sz);
    }
    for (const yy of [2.2, 5.0, 8.0]) mesh(new THREE.TorusGeometry(0.9, 0.05, 6, 24).rotateX(Math.PI / 2), neon(0xdfe8ff, 0.35), 0, yy, 0);
    mesh(new THREE.CylinderGeometry(1.0, 0.8, 0.5, 20), metal, 0, 12.8, 0);
    mesh(new THREE.ConeGeometry(0.45, 0.9, 16), metal2, 0, 13.5, 0);
    mesh(new THREE.TorusGeometry(0.62, 0.07, 6, 28).rotateX(Math.PI / 2), stripMat, 0, 12.6, 0);
    towers.push(new THREE.Vector3(x, FLOOR + 14, z));
  });
  updaters.push((t, _dt, hype) => {
    for (const s of towerStrips) s.m.color.copy(s.base).multiplyScalar(0.3 + hype * 0.4 + 0.06 * Math.sin(t * 4 + s.ph));
  });

  const rowBright = neon(0x9fb8e8, 0.28);
  const rowDim = neon(0x4a68b0, 0.12);
  const rowHot = neon(0xd8d0c8, 0.22);
  for (let k = 0; k < STAND_TIERS; k++) {
    for (let r = 0; r < ROWS_PER_TIER; r++) {
      const R = standTierInnerRadius(k) + r * STAND_ROW_SPACING + 0.04;
      const y = standRowHeight(k, r) + 0.03;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(R, 0.045, 5, 160), r === 0 ? (k % 2 ? rowHot : rowBright) : rowDim);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = y;
      scene.add(ring);
    }
  }

  return {
    update: (t, dt, hype, focus, camera) => {
      for (const u of updaters) u(t, dt, hype, focus, camera);
    },
    towers,
  };
}
