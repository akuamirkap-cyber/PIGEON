import * as THREE from 'three';
import { SAT_STEPS, DEFAULT_SAT } from './grade';
import { Robot, type Pose, type RobotStyle, type AnimState } from './robot';
import { ARMOR_SKINS, GLOVE_SKINS, HELMET_SKINS } from './build';
import { mount100PercentZeus } from './zeusModel';
import { FREESTYLE, fallArms, fallStages, freestyleByKey, freestylePose, getupFoot, riseArms } from './poses';
import { buildArena, type Arena, type PyroPlacement, loadPyroPlacement, savePyroPlacement } from './arena';
export { type PyroPlacement, loadPyroPlacement, savePyroPlacement };
import { HANGAR_POS, buildHangar, type Hangar } from './hangar';
import { Effects, Trail } from './fx';
import { Decap } from './decap';
import { Sfx, type SfxProfile, loadAllOverdrivePunch, LS_ALL_OD_PUNCH } from './audio';
export { loadAllOverdrivePunch, LS_ALL_OD_PUNCH, type SfxProfile };
import { Spring } from './spring';
import {
  CAM_MODES,
  type CamMode,
  fighterBox,
  fitShot,
  gameplayShot,
  newFrame,
  reachAlong,
  RIP_DUR,
  ripShot,
  type RipOut,
} from './cammath';
export { CAM_MODES, type CamMode, RIP_DUR, type RipOut, newFrame, gameplayShot, ripShot, fitShot, fighterBox, reachAlong };

export type HeroPose = 'ready' | 'stand' | 'guard' | 'victory' | 'taunt' | 'menace' | 'sombong';

export interface OpponentDef {
  name: string;
  title: string;
  hp: number;
  speed: number;
  dmg: number;
  react: number;
  dodge: number;
  punish: number;
  adapt: number;
  aggro: number;
  rest: number;
  tscale: number;
  scale: number;
  combo: number;
  slam: boolean;
  style: RobotStyle;
  color: string;
  iq?: number;
}

export const FOOTWORK_STEPS = [1, 1.5, 2, 3] as const;
export const LS_FW = 'steel-titans-footwork-v4';
export const loadFootwork = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_FW));
    return (FOOTWORK_STEPS as readonly number[]).includes(v) ? v : 3;
  } catch {
    return 3;
  }
};

export const LS_CAM = 'steel-titans-camera-v1';

export const loadCamMode = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_CAM));
    return Number.isFinite(v) ? Math.max(0, Math.min(CAM_MODES.length - 1, v)) : 0;
  } catch {
    return 0;
  }
};

export type Difficulty = 'normal' | 'ultra';
export const LS_DIFF = 'steel-titans-difficulty';
export const loadDifficulty = (): Difficulty => {
  try {
    return localStorage.getItem(LS_DIFF) === 'ultra' ? 'ultra' : 'normal';
  } catch {
    return 'normal';
  }
};

export const LS_DIRECTIONAL_HEAD_SNAP = 'steel-titans-directional-head-snap-v1';
export const loadDirectionalHeadSnap = (): boolean => {
  try {
    const v = localStorage.getItem(LS_DIRECTIONAL_HEAD_SNAP);
    return v === null ? true : v === 'true';
  } catch {
    return true;
  }
};
export const saveDirectionalHeadSnap = (on: boolean) => {
  try {
    localStorage.setItem(LS_DIRECTIONAL_HEAD_SNAP, String(on));
  } catch {

  }
};

export const LS_NO_SLOWMO_NORMAL = 'steel-titans-no-slowmo-normal-v1';
export const loadNoSlowMoNormal = (): boolean => {
  try {
    const v = localStorage.getItem(LS_NO_SLOWMO_NORMAL);
    return v === null ? true : v === 'true';
  } catch {
    return true;
  }
};
export const saveNoSlowMoNormal = (on: boolean) => {
  try {
    localStorage.setItem(LS_NO_SLOWMO_NORMAL, String(on));
  } catch {

  }
};

export const ultraDef = (d: OpponentDef): OpponentDef => ({
  ...d,
  title: d.title,
  hp: Math.round(d.hp * 1.4),
  speed: d.speed * 1.15,
  dmg: d.dmg * 1.3,
  react: Math.min(0.98, d.react + 0.16),
  dodge: Math.min(0.88, d.dodge + 0.16),
  punish: Math.min(0.98, d.punish + 0.18),
  adapt: d.adapt * 1.65 + 0.35,
  aggro: Math.min(0.96, d.aggro + 0.16),
  rest: d.rest * 0.55,
  tscale: d.tscale * 0.86,
  combo: d.combo + 1,
  slam: true,
});

export const STRATEGIST = 12;
export const IQ_STEPS = [1, 2, 3, 10, STRATEGIST] as const;

export type Plan = 'scout' | 'pressure' | 'counter' | 'trap' | 'finish' | 'recover' | 'stall';
export const PLAN_LABEL: Record<Plan, string> = {
  scout: 'MENGAMATI',
  pressure: 'MENEKAN',
  counter: 'MEMANCING',
  trap: 'MENYUDUTKAN',
  finish: 'MENGHABISI',
  recover: 'MEMULIHKAN',
  stall: 'MENGULUR WAKTU',
};
export const LS_IQ = 'steel-titans-iq-v2';
export const loadIq = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_IQ));
    return (IQ_STEPS as readonly number[]).includes(v) ? v : STRATEGIST;
  } catch {
    return STRATEGIST;
  }
};

export const smartDef = (d: OpponentDef, iq: number): OpponentDef => {
  const effIq = Math.max(2, iq);
  const k = 1 - 1 / effIq;
  const toward = (v: number, goal: number) => v + (goal - v) * k;
  return {
    ...d,
    iq,
    react: toward(d.react, 0.985),
    dodge: toward(d.dodge, 0.86),
    punish: toward(d.punish, 0.98),
    adapt: d.adapt * (1 + (effIq - 1) * 0.42),
    aggro: toward(d.aggro, 0.92),
    rest: d.rest / Math.pow(effIq, 0.58),
    combo: d.combo + (effIq >= 3 ? 1 : 0) + (effIq >= 10 ? 1 : 0),
    slam: true,
  };
};

export const ULTRA_COLOR = '#ff2a4a';

export const PLAYER_NAME = 'ATLAS';

export const PLAYER_STYLE: RobotStyle = { variant: 'atom', main: 0xc3c9d4, secondary: 0x262a33, accent: 0x1f66ff, glow: 0x3fd8ff, atlasChassis: true };

export const LS_HELMET = 'steel-titans-helmet-v1';
export const LS_GLOVE = 'steel-titans-glove-v1';
export const LS_ARMOR = 'steel-titans-armor-v1';
export const loadArmorSkin = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_ARMOR));
    if (Number.isFinite(v) && v >= 0 && v < ARMOR_SKINS.length) return Math.round(v);
  } catch {

  }
  return 0;
};
export const loadHelmetSkin = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_HELMET));
    return Number.isFinite(v) && v >= 0 && v < HELMET_SKINS.length ? Math.round(v) : 0;
  } catch {
    return 0;
  }
};
export const loadGloveSkin = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_GLOVE));
    return Number.isFinite(v) && v >= 0 && v < GLOVE_SKINS.length ? Math.round(v) : 0;
  } catch {
    return 0;
  }
};

export const loadSkinSet = (): 0 | 1 => {
  try {
    if (typeof localStorage !== 'undefined' && localStorage.getItem('steel_titans_custom_robot_active') === '1') return 1;
  } catch {

  }
  return loadHelmetSkin() === 1 && loadGloveSkin() === 1 && loadArmorSkin() === 1 ? 1 : 0;
};

export const OPPONENTS: OpponentDef[] = [
  { name: 'ZEUS', title: 'Raja Ring Real Steel (100% Asli)', hp: 160, speed: 4.05, dmg: 1.0, react: 0.98, dodge: 0.88, punish: 0.98, adapt: 2.8, aggro: 0.98, rest: 0.16, tscale: 0.94, scale: 1.0, combo: 5, slam: true, color: '#22ff44', style: { main: 0x050507, secondary: 0x0f1015, accent: 0x22ff44, glow: 0x22ff44, helmetSkin: 1, gloveSkin: 1, armorSkin: 1, isZeus100: true } },
  { name: 'CRIMSON FANG', title: 'Predator Ring Bawah Tanah', hp: 115, speed: 3.55, dmg: 0.98, react: 0.78, dodge: 0.62, punish: 0.82, adapt: 1.25, aggro: 0.82, rest: 0.54, tscale: 1.1, scale: 1.1, combo: 4, slam: true, color: '#ff3b3b', style: { main: 0x9c1c22, secondary: 0x2a2d36, accent: 0xe8e8e8, glow: 0xff2a2a } },
  { name: 'VOLT TITAN', title: 'Raksasa Bertenaga Petir', hp: 135, speed: 3.75, dmg: 1.04, react: 0.84, dodge: 0.66, punish: 0.86, adapt: 1.45, aggro: 0.86, rest: 0.48, tscale: 1.05, scale: 1.2, combo: 4, slam: true, color: '#d6ff2a', style: { main: 0xc2a826, secondary: 0x23262d, accent: 0x111111, glow: 0xd6ff2a } },
  { name: 'OMEGA ZEUS', title: 'Juara Dunia Tak Terkalahkan', hp: 150, speed: 3.95, dmg: 1.0, react: 0.9, dodge: 0.72, punish: 0.92, adapt: 1.7, aggro: 0.9, rest: 0.42, tscale: 1.0, scale: 1.22, combo: 5, slam: true, color: '#c070ff', style: { main: 0x3b2370, secondary: 0x15121f, accent: 0xffc83a, glow: 0xb050ff } },

  { name: 'ATLAS PRIME', title: 'Sang Juara Bertahan WRC · Chassis Atlas Titanium', hp: 150, speed: 4.1, dmg: 1.02, react: 0.96, dodge: 0.82, punish: 0.96, adapt: 2.4, aggro: 0.97, rest: 0.18, tscale: 0.95, scale: 1.0, combo: 5, slam: true, color: '#ffc63a', style: { variant: 'atom', main: 0xc3c9d4, secondary: 0x262a33, accent: 0xffb000, glow: 0xffc63a, atlasChassis: true } },
];

export const ATLAS_IDX = OPPONENTS.findIndex((o) => o.name === 'ATLAS PRIME');

export const HP_SCALE = 1.8;

export const hpThick = (base: number) => Math.round(base * HP_SCALE);
export const PLAYER_HP_BASE = 100;

export type Phase = 'menu' | 'walk' | 'intro' | 'fight' | 'ko' | 'matchEnd';

export interface WalkTrack {
  f: Fighter;
  from: THREE.Vector2;
  mark: THREE.Vector2;
  take: THREE.Vector2;
  land: THREE.Vector2;
  home: THREE.Vector2;
  homeYaw: number;
  t: [number, number, number, number, number, number, number];
  cue: number;
  landed: boolean;
  raised: boolean;
  inward: THREE.Vector2;
  perp: THREE.Vector2;
}
export const WALK_T = 9.4;
export const FLIGHT_H = 4.5;
export const COM_H = 3.5;

export const FLIP_RAMP = 0.16;
export const FLIP_HOLD = 0.6;
export const FLIP_END = 0.55;
export const FLIP_NORM = 1 / (FLIP_RAMP * 0.5 + (FLIP_HOLD - FLIP_RAMP) + (1 - FLIP_HOLD) * (1 - (1 - FLIP_END) / 3));
export const flipTurn = (p: number) => {
  if (p <= 0) return 0;
  if (p >= 1) return 1;
  if (p < FLIP_RAMP) {
    const s = p / FLIP_RAMP;
    return FLIP_RAMP * (s * s * s - s * s * s * s * 0.5) * FLIP_NORM;
  }
  if (p < FLIP_HOLD) return (FLIP_RAMP * 0.5 + (p - FLIP_RAMP)) * FLIP_NORM;

  const q = (p - FLIP_HOLD) / (1 - FLIP_HOLD);
  return (FLIP_RAMP * 0.5 + (FLIP_HOLD - FLIP_RAMP) + (1 - FLIP_HOLD) * (q - (1 - FLIP_END) * q * q * q / 3)) * FLIP_NORM;
};
export const FLIP_IN = 0.07;
export const FLIP_SPAN = 1 - FLIP_IN;

export const entryShift = () => (ringCfg.in / RING_IN_BASE - 1) * 15.5;

export const rampY = (r0: number) => {
  const r = r0 - entryShift();
  return r >= 23.5 ? -1.4 : r <= 19.8 ? -0.9 : THREE.MathUtils.lerp(-0.9, -1.4, (r - 19.8) / 3.7);
};

export interface MatchStats {
  thrown: [number, number];
  landed: [number, number];
  dmg: [number, number];
  maxCombo: number;
  dodges: number;
  counters: number;
  knockdowns: [number, number];
  time: number;
}
export const freshStats = (): MatchStats => ({ thrown: [0, 0], landed: [0, 0], dmg: [0, 0], maxCombo: 0, dodges: 0, counters: 0, knockdowns: [0, 0], time: 0 });
export interface HudState {
  phase: Phase;
  round: number;
  timeLeft: number;
  pHp: number;
  pMax: number;
  eHp: number;
  eMax: number;
  stam: number;

  gassed: boolean;

  eGassed: boolean;

  eWhiff: number;

  star: boolean;

  autoGuard: boolean;

  ali: boolean;

  panjerMode: boolean;

  panjer: number;

  panjerMul: string;

  panjerReady: boolean;

  nCombo: number;

  nComboLocked: boolean;
  meter: number;
  combo: number;
  wins: [number, number];
  eName: string;
  eTitle: string;
  eColor: string;
  banner: { id: number; text: string; sub: string; kind: string } | null;
  paused: boolean;
  result: 'win' | 'lose' | null;
  oppIndex: number;
  ultra: boolean;
  fw: number;
  cam: number;
  iq: number;
  ePlan: string;
  roll: number;
  ippo: boolean;
  hand: number;
  handFlash: number;
  parry: boolean;
  parryCd: number;
  aim: number;
  aimMode: number;
  aimFlash: number;
  rage?: boolean;
  rageFlash?: number;
  heroPose?: HeroPose;
  helmetSkin?: number;
  gloveSkin?: number;
  armorSkin?: number;
  isZeus?: boolean;

  fps?: number;

  gfx?: string;

  gfxMode?: GfxMode;

  bright?: number;

  sat?: number;

  textureEnhance?: boolean;

  bloomMode?: BloomMode;

  bloomPercent?: number;

  pyroPlacement?: PyroPlacement;

  directionalHeadSnap?: boolean;

  noSlowMoNormal?: boolean;

  allOverdrivePunch?: boolean;
  stats?: MatchStats;
}

export type MoveId = 'jab' | 'cross' | 'hook' | 'upper' | 'slam' | 'bolt' | 'windmill' | 'skyhook' | 'grab' | 'counter' | 'finisher';

export const isOD = (id: MoveId) => id === 'slam' || id === 'bolt' || id === 'windmill' || id === 'skyhook' || id === 'finisher';
export type Ease = 'in' | 'out' | 'io' | 'flow';
export interface Key {
  t: number;
  p: Pose;
  twist: number;
  lean: number;
  lunge: number;
  dip: number;
  e: Ease;
}
export interface Move {
  id: MoveId;
  arm: 0 | 1 | 2;
  dur: number;
  strikeAt: number;
  impact: number;
  cancel: number;
  dmg: number;
  reach: number;
  cost: number;
  stun: number;
  knock: number;
  blockMul: number;
  power: number;
  hitY: number;
  step: number;
  kind: 'front' | 'side' | 'up';
  keys: Key[];
}

export function createCinematicVignetteTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(512, 512, 140, 512, 512, 512);
  grad.addColorStop(0, 'rgba(2, 5, 14, 0.52)');
  grad.addColorStop(0.42, 'rgba(2, 5, 14, 0.68)');
  grad.addColorStop(0.72, 'rgba(1, 3, 10, 0.90)');
  grad.addColorStop(1, 'rgba(0, 1, 5, 0.99)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1024, 1024);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export const GUARD: Pose = { sx: -0.72, sy: -0.5, sz: 0.04, ex: -2.0 };
export const BLOCK: Pose = { sx: -1.0, sy: -0.75, sz: 0, ex: -2.2 };

export const STAGGER: Pose = { sx: -0.42, sy: -0.34, sz: 0.34, ex: -1.15 };
export const TAUNT: Pose = { sx: -0.3, sy: -0.1, sz: 1.3, ex: -2.3 };
export const VICTORY: Pose = { sx: -3.0, sy: 0, sz: 0.5, ex: -0.3 };

export const k = (t: number, p: Pose, twist = 0, lean = 0.08, lunge = 0, dip = 0.12, e: Ease = 'io'): Key => ({ t, p, twist, lean, lunge, dip, e });

export const P = (sx: number, sy: number, sz: number, ex: number): Pose => ({ sx, sy, sz, ex });

export const RUNARM = P(-0.45, -0.2, 0.06, -1.75);

export const WALKG = P(-0.7, -0.62, 0.03, -2.2);

export const MOVES: Record<MoveId, Move> = {

  jab: {

    id: 'jab', arm: 0, dur: 0.72, strikeAt: 0.13, impact: 0.24, cancel: 0.38, dmg: 7, reach: 4.4, cost: 4, stun: 0.55, knock: 4, blockMul: 0.1, power: 0.36, hitY: 4.5, step: 1.35, kind: 'front',
    keys: [
      k(0, GUARD),
      k(0.11, P(-0.34, -0.02, 0.14, -2.7), 0.42, -0.1, -0.34, 0.26, 'out'),
      k(0.24, P(-1.76, -0.36, 0, -0.02), -0.8, 0.42, 1.04, 0.06, 'in'),
      k(0.31, P(-1.83, -0.36, 0, 0.02), -0.9, 0.46, 1.14, 0.04),
      k(0.46, P(-1.15, -0.3, 0.12, -0.75), -0.15, 0.18, 0.35, 0.13),
      k(0.72, GUARD),
    ],
  },
  cross: {
    id: 'cross', arm: 1, dur: 0.86, strikeAt: 0.17, impact: 0.28, cancel: 0.46, dmg: 11, reach: 4.2, cost: 10, stun: 0.64, knock: 6, blockMul: 0.1, power: 0.55, hitY: 4.2, step: 1.9, kind: 'front',
    keys: [
      k(0, GUARD),
      k(0.17, P(-0.08, 0.85, 0.42, -2.6), -1.15, -0.26, -0.6, 0.36, 'out'),
      k(0.28, P(-1.66, -0.95, 0, -0.02), 1.3, 0.5, 1.35, 0.06, 'in'),
      k(0.36, P(-1.72, -0.9, 0, 0.02), 1.46, 0.54, 1.5, 0.04),
      k(0.54, P(-1.1, -0.5, 0.14, -0.95), 0.28, 0.2, 0.45, 0.15),
      k(0.86, GUARD),
    ],
  },
  hook: {
    id: 'hook', arm: 0, dur: 0.92, strikeAt: 0.2, impact: 0.33, cancel: 0.5, dmg: 13, reach: 3.9, cost: 12, stun: 0.66, knock: 7, blockMul: 0.1, power: 0.62, hitY: 4.5, step: 1.4, kind: 'side',
    keys: [
      k(0, GUARD),
      k(0.2, P(-0.25, 1.05, 1.5, -1.7), 1.15, -0.05, -0.5, 0.34, 'out'),
      k(0.33, P(-0.32, -1.35, 1.5, -1.3), -1.5, 0.2, 0.95, 0.08, 'in'),
      k(0.42, P(-0.36, -1.5, 1.45, -1.2), -1.7, 0.24, 1.05, 0.06),
      k(0.6, P(-0.62, -0.7, 0.8, -1.7), -0.45, 0.12, 0.3, 0.17),
      k(0.92, GUARD),
    ],
  },
  upper: {
    id: 'upper', arm: 1, dur: 0.95, strikeAt: 0.2, impact: 0.33, cancel: 0.52, dmg: 15, reach: 3.7, cost: 14, stun: 0.8, knock: 8, blockMul: 0.1, power: 0.72, hitY: 4.8, step: 1.2, kind: 'up',
    keys: [
      k(0, GUARD),
      k(0.2, P(-0.02, 0.2, 0.3, -0.5), -0.78, 0.62, -0.42, 0.82, 'out'),
      k(0.33, P(-2.18, -0.55, 0, -0.9), 0.98, -0.36, 1.02, -0.02, 'in'),
      k(0.4, P(-2.34, -0.5, 0, -0.72), 1.08, -0.42, 1.08, -0.06),
      k(0.56, P(-1.45, -0.4, 0.12, -1.3), 0.32, -0.04, 0.32, 0.2),
      k(0.95, GUARD),
    ],
  },
  slam: {
    id: 'slam', arm: 2, dur: 1.5, strikeAt: 0.52, impact: 0.64, cancel: 99, dmg: 34, reach: 4.4, cost: 0, stun: 1.2, knock: 12, blockMul: 0.1, power: 1, hitY: 4.2, step: 2.4, kind: 'up',
    keys: [
      k(0, GUARD),
      k(0.34, P(-2.95, -0.1, 0.3, -0.5), 0, -0.3, -0.1, 0.0, 'out'),
      k(0.52, P(-3.1, -0.1, 0.35, -0.4), 0, -0.6, -0.4, 0.0, 'io'),
      k(0.64, P(-1.4, -0.15, 0.1, -0.12), 0, 0.7, 1.1, 0.55, 'in'),
      k(1.0, P(-1.4, -0.15, 0.1, -0.12), 0, 0.7, 1.1, 0.55),
      k(1.5, GUARD),
    ],
  },

  bolt: {
    id: 'bolt', arm: 1, dur: 1.3, strikeAt: 0.44, impact: 0.54, cancel: 99, dmg: 32, reach: 5.2, cost: 0, stun: 1.2, knock: 12, blockMul: 0.1, power: 1, hitY: 4.1, step: 3.6, kind: 'front',
    keys: [
      k(0, GUARD),
      k(0.22, P(-0.1, 0.95, 0.42, -2.65), -1.3, -0.28, -0.6, 0.5, 'out'),
      k(0.42, P(-0.06, 1.02, 0.46, -2.72), -1.42, -0.32, -0.72, 0.56, 'io'),
      k(0.54, P(-1.66, -0.92, 0, -0.02), 1.38, 0.56, 1.55, 0.1, 'in'),
      k(0.9, P(-1.66, -0.92, 0, -0.02), 1.38, 0.56, 1.55, 0.1),
      k(1.3, GUARD),
    ],
  },

  windmill: {
    id: 'windmill', arm: 1, dur: 1.48, strikeAt: 0.56, impact: 0.68, cancel: 99, dmg: 35, reach: 5.1, cost: 0, stun: 1.25, knock: 13.5, blockMul: 0.1, power: 1, hitY: 4.3, step: 3.5, kind: 'front',
    keys: [
      k(0, GUARD),
      k(0.16, P(-1.8, 0.35, 0.55, -0.35), -0.75, -0.18, -0.35, 0.24, 'io'),
      k(0.34, P(-3.1, 0.45, 0.6, -0.3), -1.15, -0.25, -0.52, 0.38, 'io'),
      k(0.54, P(-0.08, 1.05, 0.48, -2.5), -1.48, -0.34, -0.75, 0.56, 'out'),
      k(0.68, P(-1.66, -0.92, 0, -0.02), 1.46, 0.58, 1.62, 0.08, 'in'),
      k(1.02, P(-1.66, -0.92, 0, -0.02), 1.46, 0.58, 1.62, 0.08),
      k(1.48, GUARD),
    ],
  },

  skyhook: {
    id: 'skyhook', arm: 1, dur: 1.36, strikeAt: 0.44, impact: 0.56, cancel: 99, dmg: 33, reach: 4.2, cost: 0, stun: 1.3, knock: 11, blockMul: 0.1, power: 1, hitY: 5.5, step: 2.8, kind: 'up',
    keys: [
      k(0, GUARD),

      k(0.26, P(-0.06, 0.5, 0.34, -0.55), -0.85, 0.52, -0.3, 0.98, 'out'),

      k(0.42, P(-0.03, 0.58, 0.3, -0.5), -1.0, 0.58, -0.36, 1.02, 'io'),

      k(0.56, P(-2.6, -0.45, 0.06, -0.8), 0.92, -0.46, 0.5, -0.14, 'in'),
      k(0.68, P(-2.78, -0.42, 0.0, -0.62), 1.08, -0.54, 0.6, -0.2),
      k(0.86, P(-1.72, -0.44, 0.14, -1.3), 0.52, -0.12, 0.38, 0.14),
      k(1.36, GUARD),
    ],
  },

  finisher: {
    id: 'finisher', arm: 2, dur: 1.5, strikeAt: 0.5, impact: 0.62, cancel: 99, dmg: 44, reach: 4.5, cost: 30, stun: 1.5, knock: 15, blockMul: 0.1, power: 1, hitY: 4.4, step: 3.4, kind: 'front',
    keys: [
      k(0, GUARD),

      k(0.3, P(-0.52, 0.62, -0.34, -2.72), 0, -0.44, -0.5, 0.74, 'out'),

      k(0.5, P(-0.46, 0.7, -0.4, -2.78), 0, -0.52, -0.62, 0.86, 'io'),

      k(0.62, P(-1.62, -0.3, 0.1, -0.06), 0, 0.66, 1.62, 0.1, 'in'),

      k(1.0, P(-1.62, -0.3, 0.1, -0.06), 0, 0.66, 1.62, 0.1),
      k(1.5, GUARD),
    ],
  },
  grab: {
    id: 'grab', arm: 2, dur: 1.25, strikeAt: 0.1, impact: 0.3, cancel: 99, dmg: 20, reach: 3.5, cost: 14, stun: 1, knock: 8, blockMul: 0.1, power: 0.85, hitY: 3.6, step: 1.4, kind: 'front',
    keys: [
      k(0, GUARD),
      k(0.1, P(-1.35, 0.35, 0.75, -0.55), 0, 0.1, -0.2, 0.3, 'out'),
      k(0.22, P(-1.55, -0.62, 0.08, -0.45), 0, 0.4, 0.6, 0.15, 'in'),
      k(0.34, P(-2.85, -0.4, 0.2, -0.3), 0, -0.25, 0.3, 0.0, 'out'),
      k(0.72, P(-2.9, -0.4, 0.2, -0.3), 0, -0.3, 0.2, 0.0),
      k(0.86, P(-0.9, -0.2, 0.1, -0.45), 0, 0.75, 0.9, 0.5, 'in'),
      k(1.25, GUARD),
    ],
  },

  counter: {
    id: 'counter', arm: 1, dur: 0.95, strikeAt: 0.3, impact: 0.4, cancel: 0.6, dmg: 16, reach: 4.6, cost: 10, stun: 0.6, knock: 6, blockMul: 0.1, power: 0.5, hitY: 4.3, step: 2.6, kind: 'front',
    keys: [
      k(0, GUARD),
      k(0.08, P(-0.44, -0.2, 0.42, -2.5), -0.5, -0.1, -0.28, 0.28, 'out'),
      k(0.18, P(-0.3, 0.92, 0.42, -2.55), -1.0, -0.22, -0.55, 0.42, 'io'),
      k(0.3, P(-1.66, -0.92, 0, -0.02), 1.3, 0.54, 1.5, 0.09, 'in'),

      k(0.42, P(-1.66, -0.9, 0, 0.0), 1.0, 0.42, 1.05, 0.1),
      k(0.62, P(-1.1, -0.5, 0.14, -0.95), 0.3, 0.2, 0.45, 0.15),
      k(0.95, GUARD),
    ],
  },
};

export const MOVE_EXTRA: Record<MoveId, { width: number; launch: boolean; unblock: boolean }> = {
  jab: { width: 1.5, launch: false, unblock: false },
  cross: { width: 1.6, launch: false, unblock: false },
  hook: { width: 3.6, launch: false, unblock: false },
  upper: { width: 2.2, launch: false, unblock: false },
  slam: { width: 5.0, launch: true, unblock: false },
  bolt: { width: 1.55, launch: true, unblock: false },
  windmill: { width: 2.2, launch: true, unblock: true },
  skyhook: { width: 2.4, launch: true, unblock: true },
  grab: { width: 2.4, launch: true, unblock: true },
  counter: { width: 1.7, launch: false, unblock: false },

  finisher: { width: 3.0, launch: true, unblock: true },
};

export const GRAVITY = 34;

export const POISE_MAX = 125;
export const POISE_REGEN = 38;
export const POISE_DELAY = 1.0;
export const poiseCost = (power: number) => 8 + power * 22;

export const TELL: Record<MoveId, number> = { jab: 0.48, cross: 0.55, hook: 0.6, upper: 0.62, grab: 0.68, slam: 0.9, bolt: 0.9, windmill: 0.92, skyhook: 0.92, counter: 0.5, finisher: 0.98 };
export const TELL_CHAIN = 0.2;
export const UNBLOCKABLE: MoveId[] = ['grab', 'slam', 'bolt', 'windmill', 'skyhook', 'finisher'];

export const TRACK: Record<MoveId, number> = { jab: 0.35, cross: 0.42, hook: 0.9, upper: 0.55, slam: 0.5, bolt: 0.25, windmill: 0.42, skyhook: 0.4, grab: 0.52, counter: 0.45, finisher: 0.3 };

export const defenceAgainst = (id: MoveId, dodge: number): 'block' | 'side' | 'back' => {
  if (id === 'grab') return Math.random() < 0.5 ? 'back' : 'side';
  if (id === 'slam') return Math.random() < 0.7 ? 'back' : 'side';
  if (id === 'bolt') return Math.random() < 0.65 ? 'side' : 'back';
  if (id === 'windmill') return Math.random() < 0.65 ? 'side' : 'back';
  if (id === 'skyhook') return Math.random() < 0.6 ? 'back' : 'side';
  if (id === 'finisher') return Math.random() < 0.55 ? 'side' : 'back';
  if (id === 'counter') return Math.random() < 0.7 ? 'side' : 'back';
  if (id === 'hook') return Math.random() < dodge ? 'back' : 'block';
  if (id === 'upper') return Math.random() < dodge * 0.8 ? 'back' : 'block';
  return Math.random() < dodge ? 'side' : 'block';
};

export const ALI_GUARD: Pose = P(-0.16, -0.2, 0.34, -1.34);
export const ALI_GUARD_DRIFT = 0.12;
export const ALI_SPEED = 1.08;
export const ALI_FLOAT_RATE = 5.2;
export const ALI_WEAVE = 0.17;
export const ALI_TILT = 0.12;
export const ALI_HEAD = 0.22;
export const ALI_FLOAT = 0.09;
export const ALI_CARRY = 0.55;

export const aliIdlePose = (t: number): Pose => P(ALI_GUARD.sx + (0.5 + 0.5 * Math.sin(t * ALI_FLOAT_RATE)) * ALI_GUARD_DRIFT, ALI_GUARD.sy, ALI_GUARD.sz, ALI_GUARD.ex);

export const aliWeave = (t: number) => Math.sin(t * ALI_FLOAT_RATE) * ALI_WEAVE;
export const aliRoll = (t: number) => Math.sin(t * ALI_FLOAT_RATE + 1.1) * ALI_TILT;
export const aliHead = (t: number) => Math.sin(t * ALI_FLOAT_RATE + 0.5) * ALI_HEAD;
export const aliFloat = (t: number) => (0.5 + 0.5 * Math.sin(t * ALI_FLOAT_RATE * 2 + 0.9)) * ALI_FLOAT;

export const aliStanceWeight = (state: string, blocking: boolean, moving: boolean) => (state === 'idle' && !blocking ? (moving ? ALI_CARRY : 1) : 0);

export const PANJER_FREE = 0.4;
export const PANJER_T = 1.0;
export const PANJER_DMG = 2.0;
export const PANJER_KNOCK = 2.0;

export const PANJER_MODE_KEYS: readonly string[] = ['ShiftLeft', 'ShiftRight'];
export const LS_PANJER_MODE = 'steel-titans-panjer-mode-v1';
export const loadPanjerMode = (): boolean => {
  try {
    return localStorage.getItem(LS_PANJER_MODE) === 'true';
  } catch {
    return false;
  }
};
export const savePanjerMode = (on: boolean) => {
  try {
    localStorage.setItem(LS_PANJER_MODE, String(on));
  } catch {

  }
};
export const PANJER_KEYS: Record<string, MoveId> = {
  KeyH: 'jab',
  KeyJ: 'hook',
  KeyC: 'hook',
  KeyK: 'upper',
  KeyV: 'upper',
  KeyX: 'cross',
};

export const PANJER_AUTO_ORDER: readonly string[] = ['KeyH', 'KeyJ', 'KeyC', 'KeyK', 'KeyV', 'KeyX'];

export const TANK_POP_CD = 0.7;

export const PANJER_LOADABLE: MoveId[] = ['jab', 'hook', 'upper', 'cross'];

export const panjerPower = (held: number) => {
  if (held <= PANJER_FREE) return 1;
  if (held >= PANJER_T) return PANJER_DMG;
  return 1 + (PANJER_DMG - 1) * ((held - PANJER_FREE) / (PANJER_T - PANJER_FREE));
};

export const panjerCharge = (held: number) => (panjerPower(held) - 1) / (PANJER_DMG - 1);
export const panjerLoaded = (held: number) => panjerPower(held) >= PANJER_DMG;

export const panjerShot = (held: number) => {
  const mul = panjerPower(held);
  return { armed: mul > 1, dmgMul: mul, knockMul: mul * (PANJER_KNOCK / PANJER_DMG) };
};

export const panjerLabel = (mul: number) => `×${mul.toFixed(1).replace('.', ',')}`;
/** the AI's appetite for a loaded punch, per second of opportunity. It grows with the difficulty and with how hurt
 *  the player looks, and it is CAPPED: a loaded fist has to stay an event you can read, never a rhythm. */
export const PANJER_AI_RATE = 0.3;
export const panjerAiRate = (react: number, foeSoft: boolean) => Math.min(0.85, PANJER_AI_RATE + react * 0.35 + (foeSoft ? 0.2 : 0));
export const PANJER_AI_STAM = 40; // he will not gamble the tank on a load
export const PANJER_AI_CD_MIN = 7; // ...and after one, this is how long before he even thinks about the next
export const PANJER_AI_CD_MAX = 13;

/**
 * ============================== SWING DYNAMICS — the boxer's kinetic chain ==============================
 * What makes a Boxing Star punch land is that the whole machine throws itself, not just the arm. The data in
 * `MOVES[*].keys` is the arm's own journey (coil → extension → overshoot → settle); this is the layer that rides on
 * top of it, and it is what turns a correct punch into a punch that READS. Four terms, all pure functions of the
 * swing's own clock, all four identical for the player and the AI (see `swingtest.mjs`):
 *
 *   swingPhase    — WHERE the swing is: 0 before the wind-up, 1 on the exact frame the fist lands, back to 0 as the
 *                   arm settles into the guard. Everything below is driven by this one clock, so they peak together.
 *   swingStiff    — the arm springs TIGHTEN through the release and go SOFT through the recoil. That asymmetry is the
 *                   whole trick: a piston going out (the fist is at full extension ON the impact frame, instead of
 *                   arriving a couple of frames late and hitting soft) and sprung steel coming back.
 *   offArmCounter — the off hand answers the punch: back and in to the chin on a straight, across the chest on an
 *                   arc, down to the ribs on an uppercut. A boxing punch is never one arm, and a static off hand is
 *                   exactly what makes a hand-animated punch look stiff.
 *   swingRoll     — the body rolls INTO the punch as it commits (hardest on the arcing punches), so the silhouette
 *                   leans across its own centre line instead of standing up straight behind the fist.
 *   trailWidthFor — how wide the fist's ribbon is drawn (see the fist-trail block): scaled by the punch's own power,
 *                   widened for the arcing punches, and capped so no punch can smear across the whole screen.
 */
export type SwingKind = 'front' | 'side' | 'up';

/** how far into the swing we are: 0 before the wind opens, 1 at the moment of contact, back to 0 at rest */
export const swingPhase = (moveT: number, strikeAt: number, impact: number, dur: number) => {
  // the envelope opens a beat BEFORE the punch leaves the coil (that is the last of the load) and takes as long to
  // close as the swing has left to recover in, so the terms above relax exactly as the arm comes home
  const lead = Math.max(0.04, (impact - strikeAt) * 0.5);
  if (moveT <= strikeAt - lead) return 0;
  if (moveT < impact) return (moveT - (strikeAt - lead)) / Math.max(0.001, impact - (strikeAt - lead));
  return Math.max(0, 1 - (moveT - impact) / Math.max(0.08, dur - impact));
};

export const SWING_LIFT = 0.45; // +45% arm spring through the release: the fist arrives ON the impact frame
export const SWING_SETTLE = 0.3; // −30% through the recoil: it comes back like sprung steel, not like a piston
/**
 * The arm-spring target during a strike. `passed` = the swing is already past its impact frame (the recoil half).
 * Relaxing the spring afterwards is what lets the arm visibly settle — a rigid return has no follow-through to read.
 */
export const swingStiff = (base: number, phase: number, passed: boolean) => base * (passed ? 1 - SWING_SETTLE * phase : 1 + SWING_LIFT * phase);

/** the off hand's counter-balance, at full commitment (Pose deltas are written in the rig's own mirrored space) */
export const offArmCounter = (kind: SwingKind, phase: number): Pose => {
  const a = Math.max(0, Math.min(1, phase));
  if (kind === 'side') return P(-0.1 * a, -0.3 * a, 0.06 * a, 0.1 * a); // arc: the off fist crosses to the far ear
  if (kind === 'up') return P(0.26 * a, -0.14 * a, -0.05 * a, -0.16 * a); // uppercut: it drops to the ribs and cinches
  return P(-0.14 * a, -0.22 * a, -0.08 * a, -0.2 * a); // straight: back to the chin, elbow cinched tight
};

export const SWING_ROLL = 0.12; // how far the body rolls into a straight...
export const SWING_ROLL_ARC = 1.6; // ...and how much harder it rolls on an arc (the hook is the rolling punch)
export const SWING_ROLL_UP = 0.7; // an uppercut rolls, but it is a vertical punch — most of its travel is the rise
export const swingRoll = (kind: SwingKind, phase: number, sgn: number) =>
  sgn * SWING_ROLL * (kind === 'side' ? SWING_ROLL_ARC : kind === 'up' ? SWING_ROLL_UP : 1) * Math.max(0, Math.min(1, phase));

/** the fist's ribbon width: by the punch's own power, wider on the arcs, capped so it can never smear the screen */
export const TRAIL_CAP = 0.8;
export const trailWidthFor = (id: MoveId, scale: number, rage = false) => {
  const m = MOVES[id];
  const arc = m.kind === 'side' ? 1.35 : 1;
  const heavy = isOD(id) ? 1.45 : rage ? 1.25 : 1;
  return Math.min(TRAIL_CAP, 0.3 * scale * (0.85 + 0.75 * m.power) * arc * heavy);
};

/**
 * COUNTER STRAIGHT (L). L is a punch — a lunging straight on the Overdrive's line at half its power, made to be
 * chained out of your own jab/cross/hook. On top of that, the first frames are a short read: a strike that reaches
 * the player inside this window is *caught* — no damage, the attacker is knocked out of the swing, time slows down
 * and the straight fires immediately with the 1.6× COUNTER bonus. The window is short because the move is now a
 * real strike that has to come out fast; you have to already be throwing it when the punch arrives.
 */
export const PARRY_ACTIVE = 0.3; // = the move's strikeAt: the whole wind-up is the catch window

/**
 * THE JAB RHYTHM (see startMove). A jab fired inside this window of the previous one is part of a chain: each
 * link makes the next jab up to JAB_CHAIN_STEP faster, capped at JAB_CHAIN_MAX links. It is the boxing 1-1-1-1:
 * the first jab measures the range, and by the fourth the machine gun is open — while any other punch, or a
 * beat of footwork longer than the window, resets it.
 */
export const JAB_CHAIN_WIN = 0.62; // s — the jab's own length plus a little; longer than this is not a chain
export const JAB_CHAIN_STEP = 0.075; // +7.5 % per link
export const JAB_CHAIN_MAX = 4; // ...up to +30 %
export const jabChainSpeed = (chain: number) => 1 + JAB_CHAIN_STEP * THREE.MathUtils.clamp(Math.round(chain), 0, JAB_CHAIN_MAX);

/**
 * Overdrive meter a clean hit banks for the attacker. Every punch charges it, but the JAB — the cheapest and
 * fastest punch in the book — charges it at close to double rate, so poking the guard IS how you fill the meter.
 * The coefficient keeps that lead intact now that the jab plays a readable 0.72 s beat instead of a 0.55 s blur:
 * same meter-per-second as before, but a punch you can actually SEE.
 * Exported (like defenceAgainst) so `striketest.mjs` can assert the economy instead of trusting the reader.
 */
export const meterGainFor = (id: MoveId, dmg: number, ultra = false) => dmg * 1.3 * (id === 'jab' ? 2.5 : 1) * (ultra ? 1.5 : 1);

/**
 * WHERE YOU AIM. A tap on SPACE (or T) switches the point of impact between the HEAD and the BODY, and every
 * punch then follows: the pose drops onto the target, the sparks / flash / shock ring happen AT that point of
 * impact, and the damage profile changes with it.
 *   HEAD — more damage, more stun (the fast KO road)
 *   BODY — less damage, but it drains stamina hard and rocks stability (breaks guards, sets up knockdowns)
 */
export const AIM_HEAD = 0;
export const AIM_BODY = 1;
export const AIM_MIX = 2; // REMIX: every punch picks its own target — head and body are mixed up like a real combination
export const AIM_DROP = 1.15; // how much lower the impact point sits when the body is the target (robot units)
export const AIM_HEAD_LIFT = 0.14; // straights/hooks pitch this much higher so the fist actually travels at the optics
export const AIM_DMG = [1.12, 0.82];
export const AIM_STUN = [1.06, 0.78];
export const AIM_POISE = [1.0, 1.5];
export const AIM_STAM = [1.0, 1.9]; // guard-chip stamina multiplier — body shots exhaust a guard
export const AIM_DRAIN = [0.0, 1.2]; // stamina torn off on a clean hit (body only, wear the opponent down)
export const AIM_KNOCK = [1.06, 0.78]; // body shots push less: they sit you down by draining you, not by shoving you

/**
 * THE HEAVY CHASSIS — knockback. Zeus holds his ground like a two-ton anvil: the shove that sends a standard Titan
 * skidding across the canvas barely rocks him. The champion's own ATLAS — the machine the player drives, and the
 * ATLAS PRIME he meets in the LAWAN ATLAS duel — is a heavyweight in the same class, just not a wall.
 * Every knockback that acts on a DEFENDER runs through these numbers: the boot-skid under a raised guard, the push
 * of a landed hit, the juggle pop in mid-air, and the throw of a launch.
 */
export type Chassis = 'standard' | 'atlas' | 'zeus';
export const ZEUS_KNOCK_RESIST = 0.4; // a landed hit or a blocked guard drives Zeus back 4/10 as far
export const ZEUS_LAUNCH_RESIST = 0.45; // when he IS swept off his feet he is thrown 45% of the usual distance...
export const ZEUS_LAUNCH_LIFT = 0.62; // ...and lifts off at 62% of the height — he comes straight back down on his boots
export const ZEUS_POISE_COST = 0.55; // his stability bank eats 55% of the punishment (≈ twice as many clean hits)
export const ZEUS_POISE_COST_HJ = 0.12; // and a jab / hook barely dents it at all
export const ATLAS_KNOCK_RESIST = 0.62; // ATLAS: 62% of the shove gets through — heavy, but still movable
export const ATLAS_LAUNCH_RESIST = 0.7; // thrown 70% of the distance...
export const ATLAS_LAUNCH_LIFT = 0.85; // ...and lifts 85% of the height
export const ATLAS_POISE_COST = 0.8; // his stability bank is 20% tougher than a standard Titan's
export const ATLAS_POISE_COST_HJ = 0.6; // a jab / hook dents it, but only just
/** the only strikes that still sweep a BRACED heavyweight off his feet: the Overdrive specials, the throw and the
 *  skyhook (everything else just rocks him — see the brace rule in resolveHit) */
export const HEAVY_LAUNCHERS: MoveId[] = ['slam', 'bolt', 'windmill', 'skyhook', 'grab'];

/** which chassis a robot is wearing (see RobotStyle.atlasChassis / isZeus100) */
export const chassisOf = (isZeus: boolean, hasAtlasChassis = false): Chassis => (isZeus ? 'zeus' : hasAtlasChassis ? 'atlas' : 'standard');
/** how far a landed hit / a blocked guard shoves that chassis */
export const chassisKnock = (c: Chassis) => (c === 'zeus' ? ZEUS_KNOCK_RESIST : c === 'atlas' ? ATLAS_KNOCK_RESIST : 1);
/** how far a launch throws it */
export const chassisLaunch = (c: Chassis) => (c === 'zeus' ? ZEUS_LAUNCH_RESIST : c === 'atlas' ? ATLAS_LAUNCH_RESIST : 1);
/** how high a launch / juggle lifts it */
export const chassisLift = (c: Chassis) => (c === 'zeus' ? ZEUS_LAUNCH_LIFT : c === 'atlas' ? ATLAS_LAUNCH_LIFT : 1);
/** what share of a clean hit's poise cost that chassis eats (a jab / hook is charged the softer rate) */
export const chassisPoise = (c: Chassis, isHJ: boolean) =>
  c === 'zeus' ? (isHJ ? ZEUS_POISE_COST_HJ : ZEUS_POISE_COST) : c === 'atlas' ? (isHJ ? ATLAS_POISE_COST_HJ : ATLAS_POISE_COST) : 1;

/**
 * DOES IT BRACE? True = the strike rocks him but cannot take him off his feet (he eats it standing, "KEBAL TITAN!").
 * Zeus is the wall: a jab or a hook never moves him, and an ordinary punch only gets through once he is SOFTENED —
 * his stability bar nearly empty, already rocked by the previous shot, or nearly out of HP. The ATLAS chassis is one
 * notch lighter: any punch can sit it down once it is softened, but never while it is still fresh. A standard Titan
 * braces at nothing. The designated launchers always go through, and then throw a heavyweight short and low.
 * Pure and exported so `zeustest.mjs` / `balancetest.mjs` assert the rule instead of trusting the reader.
 */
export const chassisBraces = (c: Chassis, id: MoveId, isHJ: boolean, softened: boolean) => {
  if (HEAVY_LAUNCHERS.includes(id)) return false; // the Overdrive specials, the throw and the skyhook always land
  // both heavy chassis share the rule's SHAPE — a jab / hook never sits them down, and an ordinary punch only does
  // once they are softened. What differs is everything around it: ATLAS softens 25% faster (its poise bank is 80%,
  // not 55%), is shoved 62% of the way instead of 40%, and flies at 70%/85% when it finally leaves the canvas.
  if (c === 'zeus' || c === 'atlas') return isHJ || !softened;
  return false;
};
/** the Zeus-only spelling of the rule above (kept for readability at the Zeus call sites and in the tests) */
export const zeusBraces = (id: MoveId, isHJ: boolean, softened: boolean) => chassisBraces('zeus', id, isHJ, softened);

/**
 * ======================================= THE N COMBO — the finisher button =======================================
 * ONE button (N) throws the whole sequence: JAB-JAB-HOOK-HOOK-UPPERCUT and then the PUKULAN MEMATIKAN (MOVES.finisher).
 * It is a script the fight plays for you, not a new move: every link is the same punch the same key throws by hand, so
 * the damage, the tells, the stamina and the over-commitment rules are all the ordinary ones.
 *
 * THE RULES THAT KEEP IT A PUNCH AND NOT A CHEAT:
 *   • IT BREAKS. Blocked, slipped, stepped off or whiffed — the very next frame the script stops on the spot and the
 *     control is yours again (plus a short cooldown, so N cannot be mashed). A clean five is the whole requirement.
 *   • THE FINISHER IS PAID FOR. It costs half an Overdrive meter (FINISHER_METER) and a real bite of the tank, and a
 *     landed jab chain is what charges that meter — so a CLEAN combo pays for its own ending, and the one you did not
 *     land does not happen. If the meter is not there, the combo simply stops after the uppercut.
 *   • IT CAN BE READ. The finisher's tell is the longest in the book (TELL.finisher), so an alert opponent can still
 *     slip the last punch — and then the meter is gone.
 */
export const FINISHER_METER = 50; // the finisher is priced at half an Overdrive meter, so R is never wasted on it
export const COMBO_MIN_STAM = 15; // ...and it needs this much left in the tank to even come out
export const COMBO_SCRIPT: MoveId[] = ['jab', 'jab', 'hook', 'hook', 'upper', 'finisher'];
export const COMBO_STEP_WIN = 1.1; // s — how long each link has to get itself thrown before the script gives up
export const COMBO_BREAK_CD = 1.4; // s — after a broken/finished combo, N is dead for this long (no mashing)
/**
 * CAN THIS STRIKE BE CAUGHT ON A GUARD? Everything can, except the two moves that are answered by NOT BEING THERE:
 * the throw (blocking a throw is not a thing) and the PUKULAN MEMATIKAN, whose entire counterplay is its long tell —
 * you slip it or you step off the line, and if you are still standing in front of it when it arrives, it lands.
 * Pure and exported so `combotest.mjs` can hold that line instead of trusting the reader (and so a future move can
 * never quietly become unblockable by accident).
 */
export const blockable = (id: MoveId) => id !== 'grab' && id !== 'finisher';

/** the keys that hand the fight back to the player mid-combo (footwork is deliberately NOT in here — see onEdge) */
export const N_COMBO_TAKEOVER: string[] = ['KeyH', 'KeyJ', 'KeyC', 'KeyK', 'KeyV', 'KeyX', 'KeyP', 'KeyL', 'KeyR', 'KeyE', 'KeyU', 'KeyG'];
/** can the finisher be paid for out of this fighter's meter and tank? (the runtime asks exactly this — see tryFinisher) */
export const comboCanFinish = (meter: number, stam: number) => meter >= FINISHER_METER && stam >= COMBO_MIN_STAM;

/**
 * ============================== STAR MODE — "Boxing Star" comfort, same buttons ==============================
 * The idea: in a Boxing Star-style fight you almost never wrestle the stick. The game walks you into range, keeps
 * the guard up, picks the slip direction for you and lets a tap chain into the next punch — your hands only ever
 * decide WHEN to hit and WHEN to slip. STAR MODE is exactly that layer on top of the fight that is already here:
 * NO new keys, no new moves. Every assist below rides the buttons that exist.
 *
 *   AUTO-RANGE      — with no direction key held you drift to the pocket (3.25 m) and stop: the punch you press
 *                     always comes out at the right distance, so you can play the whole round with H/J/K/X/SPACE.
 *   AUTO-GUARD      — standing still IS guarding (the guard comes up by itself) with a light recovery rate, so the
 *                     comfort player is never punished for not holding G. Holding G is still the strong block.
 *   RANGE ASSIST    — a committed punch reaches 18% further, which reads as the fighter stepping in with the punch.
 *   SMART SLIP      — SPACE with no direction key picks the slip the boxer would pick (off the punching arm, away
 *                     from the ropes) and a PERFECT slip gets a short, cinematic slow-mo beat.
 *   PUNCH BUFFER    — a tap during a swing is remembered almost twice as long and fires the instant it is legal,
 *                     so chaining combos never feels dropped.
 *   FINISHER ASSIST — the Overdrive (R) fires ITSELF the moment the meter is full and the opponent is open
 *                     (staggered, or committing to an attack = a reversal). R still works by hand at any time.
 *
 * Everything here is PLAYER-ONLY and lives behind one flag: `Game.setStarMode(true)`. The AI keeps its own brain,
 * and the ordinary fight (PLAY MATCH, RANK, TOURNAMENT…) is bit-for-bit what it was.
 */
export const STAR_POCKET = 3.25; // the distance auto-range holds — the pro-boxing pocket the game already uses
export const STAR_DEAD = 0.42; // ...and the dead zone around it where auto-range stops nudging (no jitter)
export const STAR_DRIFT = 0.72; // fraction of walking speed the auto-step uses (a shuffle, not a march)
export const STAR_RANGE_ASSIST = 1.18; // a committed punch reaches this much further (step-in assist)
export const STAR_QUEUE_WIN = 0.5; // input buffer while a swing is playing (the standard game remembers 0.34 s)
export const STAR_GUARD_REGEN = 22; // stamina/s while auto-guarding (holding G stays the slow, strong guard: 9/s)
export const STAR_SLIP_SLOW_T = 0.18; // the cinematic beat on a PERFECT slip...
export const STAR_SLIP_SLOW_SCALE = 0.55; // ...and how far the world slows inside it
export const STAR_OD_STAM = 20; // the finisher assist waits until the player has this much left (never empty it)

/** AUTO-RANGE: where should the auto-step push, given the gap? -1 = step in, +1 = step out, 0 = hold the pocket. */
export const starAutoStep = (dist: number) => (dist > STAR_POCKET + STAR_DEAD ? -1 : dist < STAR_POCKET - STAR_DEAD ? 1 : 0);
/** AUTO-GUARD: the guard is up whenever the fighter is standing there doing nothing else. */
export const starShouldGuard = (state: string, dodgeT: number, tauntT: number, loading = false) =>
  state === 'idle' && dodgeT <= 0 && tauntT <= 0 && !loading; // a fist being LOADED is not a resting fighter (PANJER)
/** FINISHER ASSIST: fire the Overdrive by itself? Only with a full meter, an open opponent and something left in the tank. */
export const starShouldFireOd = (meter: number, enemyOpen: boolean, stam: number) => meter >= 100 && enemyOpen && stam > STAR_OD_STAM;

/**
 * DODGE ADVANTAGE — the "whoever dodges first gets the hit" rule. A dodge (SPACE) can be cancelled straight into a
 * punch, and for a short window after a dodge your next strike comes out faster and lands harder. The fighter who
 * reads the exchange first owns the opening, while a dodge that leads nowhere just costs stamina.
 */
export const DODGE_WIN = 0.5; // how long after a dodge the advantage stays alive
export const DODGE_WIN_SPD = 1.20; // the next strike plays faster out of a dodge while staying readable
export const DODGE_WIN_DMG = 1.26; // ...and lands this much harder (the reward for READING the punch, not for hopping)
export const DODGE_CANCEL_AT = 0.6; // you may cancel out of a dodge once this much of it has played (its i-frames are spent)

/**
 * THE DODGE ECONOMY (balance pass). A dodge is a DECISION, not a habit: it is the one move that both negates the
 * opponent's committed punch and hands you the tempo, so it has to cost something the attacker can punish you for
 * wasting. The old numbers were free — 3.6–4.8 stamina out of 100 against 30/s of recovery, i.e. dodge-spam was
 * sustainable forever, and the game came down to whoever hopped first.
 *   - the step itself costs ~2.5× what it did (a dodge is a real slice of the tank now)
 *   - the recovery cooldown roughly doubles, so you cannot chain hops back to back
 *   - ONLY a read is cheap: a TIMED dodge (an attack already in flight) still refunds stamina and pays the meter
 *     (see perfectDodge), and it stays available on an empty tank — the "DESPERATE" dodge below — because being
 *     locked out of slipping a lethal blow is not a fight, it is a cutscene. It just leaves you GASSED.
 */
export interface DodgeCfg {
  dur: number; // the step itself
  speed: number; // m/s of the step
  inv: boolean; // i-frames over the step
  cost: number; // stamina, BEFORE STAM_SCALE
  cd: number; // recovery before another dodge
}
export const DODGE_CFG: Record<'evade' | 'fwd' | 'back' | 'side', DodgeCfg> = {
  evade: { dur: 0.28, speed: 5.6, inv: true, cost: 13, cd: 0.34 },
  fwd: { dur: 0.25, speed: 6.0, inv: false, cost: 10, cd: 0.30 },
  back: { dur: 0.28, speed: 5.2, inv: true, cost: 12, cd: 0.34 },
  side: { dur: 0.28, speed: 5.5, inv: true, cost: 11, cd: 0.32 },
};
/**
 * Can this dodge be paid for? A DESPERATE dodge — thrown while an attack is already in flight at you — is always
 * allowed (fairness: you may always try to slip a lethal blow), even on an empty tank. Everything else needs the
 * stamina. Exported so the balance harness asserts the rule instead of trusting the reader.
 */
export const dodgeAffordable = (stam: number, cost: number, desperate: boolean) => stam >= cost || desperate;
/** what the bank looks like after the step: a desperate dodge can empty it, it never goes into debt */
export const dodgeStaminaAfter = (stam: number, cost: number) => Math.max(0, stam - cost);

/**
 * GASSED (the other half of the economy). Below this line a fighter is out of gas: recovery crawls, so a dodge or a
 * flurry you could not afford is not a free reset — it is a debt you pay for the next several seconds, at 8% slower
 * hands, while the opponent reads you. Both corners run the same numbers.
 */
export const GAS_FLOOR = 25;
export const GAS_REGEN_MUL = 0.5;
export const GAS_ATK_MUL = 0.92;
export const isGassed = (stam: number) => stam < GAS_FLOOR;
export const gasAtkMul = (stam: number) => (isGassed(stam) ? GAS_ATK_MUL : 1);
export const gasRegenMul = (stam: number) => (isGassed(stam) ? GAS_REGEN_MUL : 1);

/**
 * OVER-COMMITMENT (the punch side of the balance). A punch that lands is safe — it opens its cancel window and hands
 * you the tempo. A punch that MISSES is not: the body has already thrown its weight down the line, so the tail of
 * the swing plays at a fraction of its speed and no new punch can come out of it until it is over. On top of the
 * recovery, the fighter cannot dodge-cancel out of the whiff, which is exactly the opening the AI has always been
 * coded to punish (see the WHIFF DETECTION block) — and now it is a real one on both sides.
 * The Overdrive is deliberately exempt from the gate: spending a full meter to cover a mistake is a legitimate
 * escape, and it is priced like one.
 */
export const WHIFF_TAIL = 0.42; // seconds of over-commitment after the miss
export const WHIFF_SLOW = 0.6; // the rest of the swing plays at 60% speed
/** the tail stretches the leftover animation of a whiffed move; the blow whiffed at `impact`, of `dur` total */
export const whiffRecovery = (impact: number, dur: number, atkSpd = 1) => Math.max(0, dur - impact) / Math.max(0.2, atkSpd * WHIFF_SLOW);
/** a new ordinary punch may not start inside the tail (the Overdrive is exempt — see above) */
export const whiffGates = (whiffT: number) => whiffT > 0;
/**
 * Can a fighter still DODGE-CANCEL out of his own swing? Normally yes (you may always bail out of a punch you
 * regret), but NOT inside a whiff tail — that is the whole punishment. The one exception is the fairness floor
 * above: if a strike is already in flight at him, he may always try to slip it (it just costs stamina and leaves
 * him gassed). Exported so `balancetest.mjs` audits the rule.
 */
export const canBailOut = (whiffT: number, incomingDeadly: boolean) => !whiffGates(whiffT) || incomingDeadly;

/**
 * CINEMATIC CAMERAS. The fight camera is a broadcast operator; these beats are the director stepping in to make
 * sure the big moments actually read on screen.
 *   od  — a short low hero angle as the Overdrive charges (then it hands back before the strike)
 *   hit — a punch-in on the point of impact the instant an Overdrive lands
 *   rip — a long four-angle shot for a decapitation: the cut, the head in flight, the sparking stump, then the
 *         fall back to the aftermath
 * Beats run on WORLD time, so when the game slows down for the impact the camera slows down with it.
 */
export type CineKind = 'od' | 'hit' | 'rip';
export const CINE_DUR: Record<CineKind, number> = { od: 0.35, hit: 0.28, rip: RIP_DUR };

/** STAMINA: a fight is about reading, not about running dry — strikes cost 40% less and everything recovers faster */
export const STAM_SCALE = 0.6;
export const REGEN_IDLE = 30; // per second, standing
export const REGEN_BLOCK = 9; // per second, behind the guard
export const REGEN_AI = 32; // per second, for the opponent (supports relentless offense + active slip defense)

// ------------------------------------------------------------------ helpers
export const smooth = (u: number) => u * u * (3 - 2 * u);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const wrapAngle = (a: number) => {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
};
export const lerpPose = (a: Pose, b: Pose, t: number): Pose => ({ sx: lerp(a.sx, b.sx, t), sy: lerp(a.sy, b.sy, t), sz: lerp(a.sz, b.sz, t), ex: lerp(a.ex, b.ex, t) });

// `flow` keeps half the linear velocity through intermediate clash keys and half the smoothstep ease, avoiding a
// stop-start whip while still softening the wind-up and the final contact.
export const applyEase = (u: number, e: Ease) => (e === 'in' ? Math.pow(u, 2.6) : e === 'out' ? 1 - Math.pow(1 - u, 2.4) : e === 'flow' ? 0.5 * u + 0.5 * smooth(u) : smooth(u));

export function sampleKeys(keys: Key[], t: number): Key {
  if (t <= keys[0].t) return keys[0];
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i];
    const b = keys[i + 1];
    if (t < b.t) {
      const u = applyEase((t - a.t) / (b.t - a.t), b.e);
      return { t, e: b.e, p: lerpPose(a.p, b.p, u), twist: lerp(a.twist, b.twist, u), lean: lerp(a.lean, b.lean, u), lunge: lerp(a.lunge, b.lunge, u), dip: lerp(a.dip, b.dip, u) };
    }
  }
  return keys[keys.length - 1];
}

export type FState = 'idle' | 'attack' | 'stagger' | 'ko' | 'air' | 'down' | 'legend' | 'legendHit';

export class Fighter {
  pos = new THREE.Vector2();
  vel = new THREE.Vector2();
  kb = new THREE.Vector2();
  wish = new THREE.Vector2();
  yaw = 0;
  state: FState = 'idle';
  move: Move | null = null;
  moveT = 0;
  impacted = false;
  whooshed = false;
  queued: MoveId | null = null;
  queuedT = 0;
  blocking = false;
  /** STAR MODE: the low guard is being held automatically by the assist (not by the player's key), so it recovers
   *  at the light STAR rate instead of the slow, strong manual-guard rate. */
  autoGuard = false;
  stunT = 0;
  stunImmune = 0;
  dodgeT = 0;
  dodgeCd = 0;
  dodgeDir = new THREE.Vector2();
  invuln = 0;
  counterT = 0;
  hp: number;
  stam = 100;
  meter = 0;
  hit = 0;
  hitSign = 1;
  hitUp = 0;
  // THE GEOMETRY OF THE LAST HIT, in the defender's own frame — the reaction is built from these (see resolveHit)
  hitF = -1; // + = the force drives him forward, minus = he is knocked backwards
  hitL = 0; // + = the force drives him across to his own left
  hitPt = 0.5; // 1 = the fist landed on the head, 0 = it landed on the chest plate
  hitSpin = 0; // yaw torque (an angled / hooking shot twists him round)
  hitV = 0; // smoothed copies used for the visuals
  hitUpV = 0;
  softT = 0; // time left in the 'easing back to normal' window
  ropeIn = [false, false];
  // ---- ROPE PHYSICS (the ropes are part of the fight: they stretch, hold him up, and throw him back)
  ropeDepth = 0; // how far the ropes are pushed out by him this frame (0 = not touching)
  ropeNx = 0; // outward normal of the rope he is against
  ropeNz = 0;
  ropeW = 0; // smoothed "on the ropes" weight for the pose (fast in, slow out)
  ropeBack = 1; // smoothed: +1 = the ropes are at his back (draped over them), -1 = he ran into them chest first
  slingT = 0; // ROPE CATAPULT: time until the stretched ropes fling him back into the ring
  slingV = 0; // ...and how hard they may throw him
  slingIn = 0; // the speed he actually hit them with: a rope can NEVER return more than it was given
  slingX = 0; // its direction (unit, towards the ring)
  slingZ = 0;
  fallS = new Spring();
  flash = 0;
  dash = new THREE.Vector2();
  attackDir = new THREE.Vector2(0, 1);
  y = 0;
  vy = 0;
  /** upright silhouette height for the camera framing (set each frame; 100% Zeus is far taller than the standard rig) */
  standH?: number;
  bounced = false;
  airSpin = 0; // yaw rate while knocked flying (a hook spins him; decays in the air, dies on the canvas)
  juggle = 0;
  comboTaken = 0;
  hitConfirmed = false;
  hitKind: 'jab' | 'hook' | 'upper' | 'cross' | 'standard' = 'standard';
  hitArm = 0;
  hitSeq = 0;
  hitPower = 0.5;
  moveSeq = 0;
  downT = 0;
  wallT = 0;
  wallCd = 0;
  wakeT = 0;
  tilt = 0;
  tiltZ = 0; // sideways lay-over in the air (+ = over his left shoulder)
  tiltLand = 0; // the lean he hit the canvas with (traded for the staged lie as the collapse plays)
  tiltZLand = 0;
  dodgeDur = 0.34;
  dodgeSpeed = 11;
  dodgeInv = true;
  dodgeKind: 'evade' | 'fwd' | 'back' | 'side' = 'evade';
  trails: Trail[] = [];
  fallT = 0;
  animT = Math.random() * 10;
  glowBoost = 0;
  mode: 'normal' | 'taunt' | 'victory' = 'normal';
  tauntT = 0; // FREESTYLE: time left of the show-off
  tauntDur = 0;
  tauntStyle = 0; // index into the freestyle book (poses.ts) — M N B U I Y O pick one each
  // GET-UP: the staged rise off the canvas (see riseStages in poses.ts)
  riseU = 0; // 0 = flat on the floor, 1 = back on his feet
  riseDir = 1; // the shoulder he rolls onto and pushes off
  riseOut = 0; // 1 → 0 over the beat after he stands (the loose settle)
  riseSteps = 0; // how many of the two re-plants have fired
  riseServoPlayed = false;
  downDur = 2.0; // total time on the floor, get-up included
  canvasSlammed = false; // true when torso impact and rebound have fired on canvas contact
  poise = POISE_MAX; // stability: how much punishment is left before a normal punch can knock you down
  poiseT = 0; // delay before the poise starts refilling
  poiseMax = POISE_MAX;
  hand: 0 | 1 = 0; // PLAYER: which fist the next strike is thrown with (0 = left, 1 = right) — set by the last step
  handT = 0; // how long the "hand switched" flash stays up (HUD)
  counterCd = 0; // PLAYER: cooldown before the counter straight can be thrown again (it is a hard puncher, so no spam)
  aim: 0 | 1 = 0; // 0 = the HEAD is the target, 1 = the BODY — the punch being thrown aims there (pose, impact point, damage)
  aimMode: 0 | 1 | 2 = 0; // PLAYER: the chosen target mode; 2 = REMIX — the target is re-picked for every punch
  mixN = 0; // REMIX: punches thrown so far in the current combination (drives the head/body pattern)
  aimT = 0; // how long the "target switched" flash stays up (HUD)
  dodgeWinT = 0; // DODGE ADVANTAGE: time left in which the next strike is faster & heavier (after a dodge)
  whiffT = 0; // OVER-COMMITMENT: seconds left of the recovery tail after a punch that missed (see WHIFF_TAIL)
  atkSpd = 1; // duration multiplier of the move being played (> 1 = thrown faster, out of a dodge)
  winStrike = false; // the move currently playing is a dodge-advantage strike
  rage = false; // RAGE MODE (G): hyper-aggressive fighting speed, movement, and heavy knockback
  rageFlash = 0; // > 0 while the Rage Mode badge flashes on HUD
  strikeVar = 0; // 0..3 biomechanical punch variation index so spam never looks monotonous
  spamCount = 0; // consecutive rapid attacks counter for natural flow & rhythm
  jabChain = 0; // JAB RHYTHM: how many jabs have been thrown inside the chain window (each one tightens the next)
  lastJabAt = -10; // animT of the previous jab
  lastAtkAt = -10; // animT of previous attack
  aliSign = 1; // alternating weave direction for Muhammad Ali pendulum dodges
  dodgeTail = 0; // smooth post-dodge follow-through timer so springs & poses never snap at dodge end
  decapitated = false; // HEAD RIP: this robot is fighting (or lying) without its head
  // ---- IMPACT FEEDBACK (attacker side): the fist RECOILS off a solid hit — the shock travels back up the arm
  recoilT = 0; // time left in the recoil
  recoilTot = 0.18;
  recoilArm: 0 | 1 | 2 = 1;
  recoilAmt = 0;
  // ---- IMPACT FEEDBACK (defender side): the wound keeps dripping embers for a moment after a heavy blow
  emberT = 0;
  emberP = new THREE.Vector3();
  emberLocal = new THREE.Vector3(); // the wound in the defender's own frame, so it travels with him
  skidAcc = 0; // dust accumulator while his feet are skidding under a knockback
  arms: Pose[] = [{ ...GUARD }, { ...GUARD }];
  twist = 0;
  lean = 0.08;
  lunge = 0;
  dip = 0.12;
  roll = 0;
  speed = 0;
  sprinting = false; // holding a sprint (drains stamina)
  ippo = false; // PEEK-A-BOO stance (hold E)
  rollCharge = 0; // DEMPSEY ROLL charge 0..1 (builds while weaving)
  ippoStrike = false; // the current punch is a charged Dempsey punch
  strikeCharge = 0; // how much charge that punch carries
  // ---- PANJER (hold a strike button to load it — see the PANJER block above the strike data) ----
  panjerId: MoveId | null = null; // the punch the held button is loading (null = nothing held)
  panjerKey: string | null = null; // PLAYER: which key is doing the holding — the RELEASE is what throws it
  panjerHold = 0; // seconds it has been held
  panjerReady = false; // the load is full: this punch will land 2× and drive him 2× as far
  panjerNext = 0; // ...and how hard it is (×1 = an ordinary punch), carried into the punch that comes out
  panjer = 1; // THIS swing's own multiplier from the load (1 = ordinary, 2 = a full PANJER) — read by resolveHit
  pkVis = 0; // smoothed 0..1 for the loading pose (see animateFighter)
  pkTick = 0; // the loading tick's own clock (the sound)
  pkTick2 = 0; // ...and the spark clock on a full load
  autoFireKey: string | null = null; // PANJER OTOMATIS: which punch button is being HELD (the spam repeat reads it)
  tankPopT = 0; // throttle on the empty-tank shout, so a held button cannot shout it 60 times a second
  panjerSince = 0; // performance.now() the button went down on: the load is timed on the clock, not on frames
  slipCd = 0; // short cooldown between two slips
  tellT = 0; // ENEMY wind-up warning left (the attack indicator is on screen while this runs)
  tellTotal = 0;
  dodgeFor = -1; // PLAYER: the enemy attack (moveSeq) this dodge was timed against → it cannot hit
  parryFor = -1; // PLAYER: the enemy attack (moveSeq) this L counter was timed against → caught & countered!
  weavePh = 0; // phase of the weaving animation
  swagger = 0; // ringCfg.bound WALK strut progress: −1..0 raising the arms at the gate, 0..1 down the runway, 1..2 fading into the sprint
  headYaw = 0; // extra head turn requested by the pose layer (the strut plays to the stands)
  pkPre = 0; // ringCfg.bound WALK (parkour entrance): 1 in the loaded crouch just before take-off
  pkTuck = 0; // ringCfg.bound WALK (parkour entrance): 1 while tucked in the flip
  pkLand = 0; // ringCfg.bound WALK: 1 in the landing crouch
  flip = 0; // ringCfg.bound WALK: pitch of the whole body (the front flip), radians
  runStrike = false; // the current punch was thrown at full run → heavier, longer, launches
  yawRate = 0;
  prevV = new THREE.Vector2();
  acc = new THREE.Vector2();
  armS: Spring[][] = [0, 1].map(() => [new Spring(), new Spring(), new Spring(), new Spring()]);
  bodyS = { twist: new Spring(), lean: new Spring(0.08), lunge: new Spring(), dip: new Spring(0.12), roll: new Spring() };

  team: 0 | 1; // 0 = the player's corner, 1 = the opposition (TEAM MATCH puts two robots in each)
  constructor(
    public robot: Robot,
    public isPlayer: boolean,
    public scale: number,
    public maxHp: number,
    public dmgMul: number,
    public tscale: number,
  ) {
    this.hp = maxHp;
    this.team = isPlayer ? 0 : 1;
    this.resetSprings();
  }

  /**
   * Drop the load without throwing it: the arm was taken away from the punch — he took a hit, he raised a guard,
   * the bell went, the window lost focus. A load is a commitment, never a buff you get to keep.
   */
  clearPanjer() {
    this.panjerId = null;
    this.panjerKey = null;
    this.panjerHold = 0;
    this.panjerReady = false;
    this.panjerNext = 0;
    this.panjerSince = 0;
  }

  resetSprings() {
    for (let i = 0; i < 2; i++) {
      const g = [GUARD.sx, GUARD.sy, GUARD.sz, GUARD.ex];
      this.armS[i].forEach((sp, k) => sp.set(g[k]));
    }
    this.bodyS.twist.set(0);
    this.bodyS.lean.set(0.08);
    this.bodyS.lunge.set(0);
    this.bodyS.dip.set(0.12);
    this.bodyS.roll.set(0);
    this.yawRate = 0;
    this.sprinting = false;
    this.runStrike = false;
    this.ippo = false;
    this.rollCharge = 0;
    this.ippoStrike = false;
    this.strikeCharge = 0;
    this.clearPanjer();
    this.panjer = 1;
    this.pkVis = 0;
    this.autoFireKey = null;
    this.tankPopT = 0;
    this.slipCd = 0;
    this.tellT = 0;
    this.tellTotal = 0;
    this.dodgeFor = -1;
    this.parryFor = -1;
    this.tauntT = 0;
    this.tauntDur = 0;
    this.tauntStyle = 0;
    this.swagger = 0;
    this.headYaw = 0;
    this.pkPre = 0;
    this.pkTuck = 0;
    this.pkLand = 0;
    this.flip = 0;
    this.riseU = 0;
    this.riseDir = 1;
    this.riseOut = 0;
    this.riseSteps = 0;
    this.riseServoPlayed = false;
    this.canvasSlammed = false;
    this.downDur = 1.8;
    this.poiseMax = POISE_MAX * (this.isPlayer ? 1.25 : 1); // you are a little sturdier than the opponents
    this.poise = this.poiseMax;
    this.poiseT = 0;
    this.weavePh = 0;
    this.fallS.set(0);
    this.hitV = 0;
    this.hitUpV = 0;
    this.softT = 0;
    this.ropeIn = [false, false];
    this.ropeDepth = 0;
    this.ropeW = 0;
    this.ropeBack = 1;
    this.slingT = 0;
    this.slingIn = 0;
    this.slingT = 0;
    this.slingV = 0;
    this.acc.set(0, 0);
    this.prevV.set(0, 0);
  }

  reset(x: number, z: number, yaw: number) {
    this.pos.set(x, z);
    this.vel.set(0, 0);
    this.kb.set(0, 0);
    this.wish.set(0, 0);
    this.yaw = yaw;
    this.state = 'idle';
    this.move = null;
    this.queued = null;
    this.blocking = false;
    this.stunT = 0;
    this.stunImmune = 0;
    this.dodgeT = 0;
    this.dodgeCd = 0;
    this.invuln = 0;
    this.counterT = 0;
    this.hp = this.maxHp;
    this.stam = 100;
    this.meter = 0;
    this.hit = 0;
    this.hitUp = 0;
    this.flash = 0;
    this.dash.set(0, 0);
    this.y = 0;
    this.vy = 0;
    this.bounced = false;
    this.airSpin = 0;
    this.juggle = 0;
    this.comboTaken = 0;
    this.hitConfirmed = false;
    this.downT = 0;
    this.wallT = 0;
    this.wallCd = 0;
    this.wakeT = 0;
    this.tilt = 0;
    this.tiltZ = 0;
    this.tiltLand = 0;
    this.tiltZLand = 0;
    this.fallT = 0;
    this.glowBoost = 0;
    this.mode = 'normal';
    this.handT = 0;
    this.counterCd = 0;
    this.aim = AIM_HEAD;
    this.aimMode = AIM_HEAD;
    this.mixN = 0;
    this.aimT = 0;
    this.dodgeWinT = 0;
    this.whiffT = 0;
    this.atkSpd = 1;
    this.winStrike = false;
    this.rage = false;
    this.rageFlash = 0;
    this.strikeVar = 0;
    this.spamCount = 0;
    this.jabChain = 0;
    this.lastJabAt = -10;
    this.lastAtkAt = -10;
    this.aliSign = 1;
    this.dodgeTail = 0;
    this.decapitated = false;
    this.arms = [{ ...GUARD }, { ...GUARD }];
    this.twist = 0;
    this.lean = 0.08;
    this.lunge = 0;
    this.dip = 0.12;
    this.roll = 0;
    this.resetSprings();
    this.robot.snapFeet();
  }
}

export const RING_IN_BASE = 13.45; // inner face of the ropes at rest (1v1 ring)
export const POST_H_BASE = 13.6; // the corner posts (where the ropes are tied off) sit on this square
/**
 * How much a rope can give at a point along it: the full FLEX mid-rope, almost nothing at the posts (the rope is
 * tied off there). `along` is the coordinate along the rope, scaled by the current ring size. Game logic and the
 * drawn rope use the same curve, so a body never ends up beyond the rope it is supposed to be leaning on.
 */
export const ropeGive = (along: number) => {
  const u = along / (POST_H_BASE * (ringCfg.in / RING_IN_BASE));
  return FLEX * THREE.MathUtils.clamp(1 - u * u, 0.06, 1);
};
export const RING_BASE = 11.9;
export const ringCfg = { in: RING_IN_BASE, bound: RING_BASE };
export const BODY_R = 0.9; // how far the back of the chest / upper back sits behind the body centre at top-rope height (per unit of scale) — measured on the rig
export const FLEX = 0.95; // how far the ropes can stretch before they hold
export const ROPE_K = 105; // rope stiffness
export const ROPE_C = 9.5; // rope damping (slightly under-damped → a soft, small rebound)
// HOW FAST THE ROPES MAY PUSH A BODY. The multi-point containment of a lying / flying machine used to apply its
// whole correction in one frame, so a body that fell near the ropes was SNAPPED up to three metres inwards (the
// "pindah" glitch). A rope pushes: the correction is now applied as motion at these speeds, never as a jump —
// it resolves in a few frames and reads as the body sliding off the rope instead of teleporting through the ring.
export const ROPE_SHOVE = 9; // m/s — how fast an end that is through the rope is eased back in
export const ROPE_STOP = 18; // m/s — the hard stop against a fully stretched rope, also spread over frames
// THE ROPE RULES, as pure numbers — the game applies these, and striketest.mjs §6 holds them to account.
// A body that is through the rope line is eased back in as MOTION: the most any single frame may move it is
// ropeInwardStep(dt), and a frame hitch cannot buy extra travel because dt itself is capped inside the step. That
// capped step is the whole fix for the "pindah" glitch: the old containment applied its entire correction at once,
// which is why a body lying near the ropes could be snapped metres across the ring in one frame.
export const ropeInwardStep = (dt: number) => ROPE_SHOVE * Math.min(dt, 1 / 30);
/** How far the absolute (fully stretched) rope may take back in ONE frame — same frame-hitch cap. */
export const ropeHardStep = (dt: number) => ROPE_STOP * Math.min(dt, 1 / 30);
/** The speed a rope sling may throw a body back into the ring at: at most what it arrived with, never a launcher. */
export const ropeSlingSpeed = (pull: number, vIn: number) => Math.min(5 + pull * 7.5, Math.max(3, vIn * 0.85));
/** Damping so a rebound may never leave the ropes faster (inwards) than it arrived — ropes give back, never add. */
export const ropeEnergyDamp = (inW: number, vIn: number) => (inW > vIn && inW > 0.001 ? vIn / inW : 1);
export const TIP_LEN = 6.0; // height of a robot, used for its fall footprint
export const PACE = 1.24; // global animation pace: heavier, well-timed, and clearly readable
export const RUN_SPEED = 11.2; // sprint speed (walking forward is 5.7)
// PEEK-A-BOO (hold E) movement speeds: slower than walking, but it closes the distance on its own
export const IPPO_FWD = 4.6;
export const IPPO_SIDE = 3.4;
export const IPPO_BACK = 2.6;
export const SPRINT_DRAIN = 2.0; // stamina per second while sprinting (it used to be 9, which ended a run after a few seconds)
export const WALK_FWD = 5.7;
export const WALK_BACK = 4.3;
export const WALK_SIDE = 4.9;
export const ROUND_TIME = 75;
export const INTRO_T = 3.4; // ROUND card → both machines taunt → 3 · 2 · 1 → FIGHT!
export const INTRO_TAUNT_AT = 0.45; // when both fighters kick off their pre-fight show-off
export const INTRO_COUNT = [0.95, 1.75, 2.55]; // when the 3 · 2 · 1 cards drop

// ------------------------------------------------------------------ THE GRAPHICS LADDER
/**
 * The auto ladder holds a 60 Hz target while keeping the render scale at full resolution on every rung but the last.
 * It sheds the expensive reflections, MSAA and shadow detail first; bloom stays present at a smaller mip scale so
 * the arena keeps its finish without forcing an early drop in image clarity.
 */
export interface QualityTier {
  key: string;
  name: string;
  samples: number;
  scale: number;
  shadow: number;
  bloom: boolean;
  bloomScale: number;
}
export const QUALITY_TIERS: QualityTier[] = [
  { key: 'max', name: 'MAKSIMAL', samples: 0, scale: 1.0, shadow: 1024, bloom: true, bloomScale: 0.38 },
  { key: 'high', name: 'TINGGI', samples: 0, scale: 0.95, shadow: 768, bloom: true, bloomScale: 0.35 },
  { key: 'balanced', name: 'SEIMBANG', samples: 0, scale: 0.90, shadow: 512, bloom: true, bloomScale: 0.30 },
  { key: 'performance', name: 'KINERJA', samples: 0, scale: 0.85, shadow: 512, bloom: true, bloomScale: 0.25 },
  { key: 'lite', name: 'RINGAN', samples: 0, scale: 0.80, shadow: 512, bloom: false, bloomScale: 0.22 },
];

export type GfxMode = 'auto' | 'max' | 'balanced' | 'performance';
export const GFX_MODES: { id: GfxMode; name: string; hint: string }[] = [
  { id: 'auto', name: 'OTOMATIS', hint: '60 fps dipegang otomatis' },
  { id: 'max', name: 'MAKSIMAL', hint: 'semua efek, paling indah' },
  { id: 'balanced', name: 'SEIMBANG', hint: 'cantik & ringan' },
  { id: 'performance', name: 'KINERJA', hint: 'paling lancar' },
];
export const LS_GFX = 'steel-titans-graphics-v1';
export const LS_BRIGHT = 'steel-titans-brightness-v1';
export const LS_SAT = 'steel-titans-saturation-v1';
export const LS_TEX = 'steel-titans-textures-v1';
export const LS_BLOOM = 'steel-titans-bloom-v1';
export const LS_BLOOM_PCT = 'steel-titans-bloom-percent-v3';

export const DEFAULT_BLOOM_PCT = 2; // 2% default bloom preset
export const DEFAULT_BRIGHTNESS = 1.50; // 150% default brightness preset

export type BloomMode = 'smooth' | 'normal' | 'off';
export const BLOOM_MODES: { id: BloomMode; name: string; hint: string }[] = [
  { id: 'smooth', name: 'HALUS & LEMBUT', hint: 'Glow sinematik lembut tanpa kelap-kelip' },
  { id: 'normal', name: 'STANDAR', hint: 'Glow minimal & tenang' },
  { id: 'off', name: 'NONAKTIF', hint: 'Tanpa bloom, pencahayaan tajam murni' },
];

export const loadBloomPercent = (): number => {
  try {
    const v = localStorage.getItem(LS_BLOOM_PCT);
    if (v !== null) {
      const num = Number(v);
      if (Number.isFinite(num)) return Math.max(0, Math.min(50, Math.round(num)));
    }
    const legacy = localStorage.getItem(LS_BLOOM) as BloomMode | null;
    if (legacy === 'off') return 0;
    if (legacy === 'normal') return 25;
    return DEFAULT_BLOOM_PCT;
  } catch {
    return DEFAULT_BLOOM_PCT;
  }
};

export const loadBloomMode = (): BloomMode => {
  const pct = loadBloomPercent();
  return pct === 0 ? 'off' : pct <= 20 ? 'smooth' : 'normal';
};

export const NORMAL_SAT = 1.15;
export const VIVID_SAT = 1.45;

export const loadSaturation = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_SAT));
    return (SAT_STEPS as readonly number[]).includes(v as any) ? v : DEFAULT_SAT;
  } catch {
    return DEFAULT_SAT;
  }
};

export const loadTextureEnhance = (): boolean => {
  try {
    const v = localStorage.getItem(LS_TEX);
    return v !== null ? v === 'true' : true;
  } catch {
    return true;
  }
};

/** the manual exposure steps. 1.0 is the tuned picture; range allows 0.50x to 1.60x. */
export const BRIGHTNESS_STEPS = [0.70, 0.85, 1.0, 1.15, 1.30, 1.50] as const;
export const loadBrightness = (): number => {
  try {
    const v = Number(localStorage.getItem(LS_BRIGHT));
    return Number.isFinite(v) && v >= 0.5 && v <= 1.6 ? v : DEFAULT_BRIGHTNESS;
  } catch {
    return DEFAULT_BRIGHTNESS;
  }
};
/** the pinned graphics mode from last time ('auto' = let the governor hold 60 by itself) */
export const loadGfxMode = (): GfxMode => {
  try {
    const v = localStorage.getItem(LS_GFX) as GfxMode | null;
    return v && GFX_MODES.some((m) => m.id === v) ? v : 'auto';
  } catch {
    return 'auto';
  }
};
export const gfxTier = (m: GfxMode): number => (m === 'max' ? 0 : m === 'balanced' ? 2 : m === 'performance' ? 3 : 0);

export { Robot, type Pose, type RobotStyle, type AnimState, ARMOR_SKINS, GLOVE_SKINS, HELMET_SKINS, mount100PercentZeus, FREESTYLE, fallArms, fallStages, freestyleByKey, freestylePose, getupFoot, riseArms, buildArena, type Arena, HANGAR_POS, buildHangar, type Hangar, Effects, Trail, Decap, Sfx, Spring };
