import type { Pose } from './robot';

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const sm = (u: number) => u * u * (3 - 2 * u);

export const S = (u: number, a: number, b: number) => sm(clamp((u - a) / Math.max(0.0001, b - a), 0, 1));

export const bump = (u: number, c: number, w: number) => Math.max(0, 1 - Math.abs(u - c) / w);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const P = (sx: number, sy: number, sz: number, ex: number): Pose => ({ sx, sy, sz, ex });
export const lerpPose = (a: Pose, b: Pose, t: number): Pose => ({
  sx: lerp(a.sx, b.sx, t),
  sy: lerp(a.sy, b.sy, t),
  sz: lerp(a.sz, b.sz, t),
  ex: lerp(a.ex, b.ex, t),
});

export const GUARD: Pose = P(-0.72, -0.5, 0.04, -2.0);

export interface Beat {
  a0: Pose;
  a1: Pose;
  tw: number;
  ln: number;
  dp: number;
  rl: number;
  kk: number;
}

export interface Freestyle {
  id: number;
  key: string;
  name: string;
  tag: string;
  say: string;
  dur: number;
  meter: number;
  glow: number;
  cues: { p: number; s: string }[];
}

export const FREESTYLE: Freestyle[] = [
  {

    id: 0,
    key: 'KeyM',
    name: 'pound dada',
    tag: 'TAUNT!',
    say: 'Come on!',
    dur: 1.35,
    meter: 18,
    glow: 1.9,
    cues: [
      { p: 0.2, s: 'beat' },
      { p: 0.42, s: 'beat' },
      { p: 0.64, s: 'beat' },
      { p: 0.8, s: 'chin' },
    ],
  },
  {

    id: 1,
    key: '',
    name: 'angkat sabuk',
    tag: 'SANG JUARA!',
    say: 'I am the champion!',
    dur: 2.2,
    meter: 14,
    glow: 2.4,
    cues: [{ p: 0.48, s: 'raise' }],
  },
  {

    id: 2,
    key: 'KeyB',
    name: 'gulir bahu',
    tag: 'GULIR BAHU!',
    say: 'Come on, then!',
    dur: 2.0,
    meter: 18,
    glow: 1.5,
    cues: [
      { p: 0.25, s: 'roll' },
      { p: 0.75, s: 'roll' },
    ],
  },
  {

    id: 3,
    key: 'Digit5',
    name: 'lambaikan tangan',
    tag: 'AYO SINI!',
    say: 'Bring it!',
    dur: 1.6,
    meter: 15,
    glow: 1.4,
    cues: [
      { p: 0.3, s: 'beckon' },
      { p: 0.6, s: 'beckon' },
    ],
  },
  {

    id: 4,
    key: 'Digit6',
    name: 'pamer kabel',
    tag: 'TEGANG!',
    say: 'Feel that?',
    dur: 2.4,
    meter: 17,
    glow: 2.2,
    cues: [
      { p: 0.3, s: 'flex' },
      { p: 0.5, s: 'flex' },
      { p: 0.7, s: 'flex' },
    ],
  },
  {

    id: 5,
    key: '',
    name: 'kincir tinju',
    tag: 'KINCIR LALU HENTAK!',
    say: 'Clang!',
    dur: 2.3,
    meter: 16,
    glow: 1.8,
    cues: [{ p: 0.78, s: 'clap' }],
  },
  {

    id: 6,
    key: 'KeyO',
    name: 'gas piston',
    tag: 'MESIN NYALA!',
    say: 'Ha! More!',
    dur: 2.5,
    meter: 19,
    glow: 2.6,
    cues: [
      { p: 0.34, s: 'rev' },
      { p: 0.5, s: 'rev' },
      { p: 0.66, s: 'rev' },
      { p: 0.88, s: 'roar' },
    ],
  },
  {

    id: 7,
    key: 'Digit1',
    name: 'cek servo',
    tag: 'SISTEM OK!',
    say: 'Calibrating.',
    dur: 2.1,
    meter: 15,
    glow: 1.7,
    cues: [
      { p: 0.2, s: 'check' },
      { p: 0.52, s: 'check' },
      { p: 0.86, s: 'check' },
    ],
  },
  {

    id: 8,
    key: 'Digit2',
    name: 'inti nyala',
    tag: 'INTI PENUH!',
    say: 'Reactor: hot.',
    dur: 2.4,
    meter: 20,
    glow: 3.0,
    cues: [
      { p: 0.3, s: 'charge' },
      { p: 0.56, s: 'charge' },
      { p: 0.76, s: 'roar' },
    ],
  },
  {

    id: 9,
    key: 'Digit3',
    name: 'bor tinju',
    tag: 'BOR MULAI!',
    say: 'Drilling.',
    dur: 2.3,
    meter: 17,
    glow: 2.0,
    cues: [
      { p: 0.24, s: 'spin' },
      { p: 0.46, s: 'spin' },
      { p: 0.68, s: 'spin' },
      { p: 0.9, s: 'clap' },
    ],
  },
  {

    id: 10,
    key: 'Digit4',
    name: 'adu tinju',
    tag: 'ADU TINJU!',
    say: "Let's go!",
    dur: 1.6,
    meter: 20,
    glow: 2.2,
    cues: [
      { p: 0.2, s: 'clash' },
      { p: 0.4, s: 'clash' },
      { p: 0.6, s: 'clash' },
      { p: 0.8, s: 'chin' },
    ],
  },
  {

    id: 11,
    key: 'KeyZ',
    name: 'pose sombong zeus',
    tag: 'SOMBONG ZEUS!',
    say: 'Come at me!',
    dur: 2.2,
    meter: 25,
    glow: 2.8,
    cues: [
      { p: 0.22, s: 'roll' },
      { p: 0.45, s: 'beckon' },
      { p: 0.75, s: 'chin' },
    ],
  },
];

export const freestyleOf = (style: number): Freestyle => FREESTYLE[clamp(Math.round(style), 0, FREESTYLE.length - 1)];
export const freestyleByKey = (key: string): Freestyle | undefined => FREESTYLE.find((f) => f.key === key);

export function freestylePose(style: number, u: number, t: number): Beat {
  const uc = clamp(u, 0, 1);
  const b: Beat = { a0: GUARD, a1: GUARD, tw: 0, ln: 0.08, dp: 0.12, rl: 0, kk: 30 };
  const back = S(uc, 0.88, 1);

  const base = freestyleOf(style).id === 5 ? Math.PI * 2 : 0;
  const rest = P(GUARD.sx - base, GUARD.sy, GUARD.sz, GUARD.ex);

  switch (freestyleOf(style).id) {

    case 0: {

      const hit = Math.max(bump(uc, 0.2, 0.11), bump(uc, 0.42, 0.11), bump(uc, 0.64, 0.11));
      const open = Math.max(bump(uc, 0.08, 0.1), bump(uc, 0.31, 0.09), bump(uc, 0.53, 0.09));
      const chin = S(uc, 0.7, 0.8) * (1 - S(uc, 0.86, 1));
      const sx = lerp(lerp(-0.55, -1.9, open) + hit * 0.55, -1.25, chin);
      const sz = lerp(lerp(0.35, 1.45, open) - hit * 1.25, 1.55, chin);
      const ex = lerp(lerp(-1.1, -2.0, open) - hit * 0.7, -0.5, chin);
      b.a0 = P(sx, -0.5 - hit * 0.5, sz, ex);
      b.a1 = P(sx, -0.5 - hit * 0.5, sz, ex);
      b.ln = -0.3 - open * 0.18 + hit * 0.32 - chin * 0.3;
      b.dp = 0.1 + hit * 0.16 - chin * 0.04;
      b.rl = Math.sin(uc * Math.PI * 6) * 0.05;
      b.tw = Math.sin(uc * Math.PI * 3) * 0.12;
      b.kk = 48;
      break;
    }

    case 1: {
      const up = S(uc, 0.2, 0.5) * (1 - S(uc, 0.86, 1));
      const grip = S(uc, 0, 0.16) * (1 - S(uc, 0.16, 0.34));
      const shake = Math.sin(uc * Math.PI * 7) * 0.05 * up;
      const sx = lerp(-0.25 + grip * 0.22, -2.92 + shake, up);
      const sz = lerp(0.22, 0.6, up);
      const ex = lerp(-1.95 - grip * 0.35, -0.3, up);
      b.a0 = P(sx, -0.25, sz, ex);
      b.a1 = P(sx, -0.25, sz, ex);
      b.ln = grip * 0.3 - up * 0.62;
      b.dp = 0.1 + grip * 0.26 - up * 0.08;
      b.tw = Math.sin(uc * Math.PI * 2) * 0.07 * up;
      b.rl = Math.sin(uc * Math.PI * 3.5) * 0.04 * up;
      b.kk = 30;
      break;
    }

    case 2: {

      const ph = uc * Math.PI * 2 * 1.6;
      const roll = Math.sin(ph);
      const fig8 = Math.sin(ph * 2);
      const loose = 0.5 + 0.5 * Math.sin(t * 6.5);
      b.a0 = P(0.3 - roll * 0.55 + loose * 0.06, -0.3 - fig8 * 0.3, 0.95 + roll * 0.35, -1.25 - loose * 0.2);
      b.a1 = P(0.3 + roll * 0.55 - loose * 0.06, -0.3 + fig8 * 0.3, 0.95 - roll * 0.35, -1.25 - (1 - loose) * 0.2);
      b.tw = roll * 0.42;
      b.rl = fig8 * 0.17;
      b.dp = 0.3 + Math.abs(roll) * 0.08;
      b.ln = 0.16 + fig8 * 0.05;
      b.kk = 24;
      break;
    }

    case 3: {
      const flick = Math.max(bump(uc, 0.3, 0.15), bump(uc, 0.6, 0.15));
      const rise = S(uc, 0.05, 0.24) * (1 - S(uc, 0.86, 1));
      const sx = lerp(0.1, -1.2 + flick * 0.42, rise);
      const sz = lerp(0.4, 0.5, rise) + flick * 0.1;
      const ex = lerp(-0.4, -1.45 + flick * 0.95, rise);
      b.a0 = P(sx, -0.55 + flick * 0.18, sz, ex);
      b.a1 = P(sx, -0.55 - flick * 0.18, sz, ex);
      b.ln = -0.14 + flick * 0.1 + rise * 0.06;
      b.dp = 0.14 + flick * 0.06;
      b.tw = -0.08 + flick * 0.12;
      b.rl = flick * 0.03;
      b.kk = 26;
      break;
    }

    case 4: {
      const up = S(uc, 0.12, 0.42);
      const flex = 0.5 + 0.5 * Math.sin(uc * Math.PI * 5);
      const hold = 1 - S(uc, 0.86, 1);
      const k = up * hold;
      b.a0 = P(lerp(0.1, -1.42 - flex * 0.12, k), lerp(0, 0.16, k), lerp(0.35, 1.06 + flex * 0.1, k), lerp(-0.3, -2.15 - flex * 0.3, k));
      b.a1 = P(lerp(0.1, -1.42 - (1 - flex) * 0.12, k), lerp(0, -0.16, k), lerp(0.35, 1.06 + (1 - flex) * 0.1, k), lerp(-0.3, -2.15 - (1 - flex) * 0.3, k));
      b.ln = -0.2 * k + 0.08 * (1 - k);
      b.dp = lerp(0.12, 0.1, k);
      b.tw = Math.sin(uc * Math.PI * 2) * 0.08 * k;
      b.rl = Math.sin(uc * Math.PI * 3) * 0.05 * k;
      b.kk = 34;
      break;
    }

    case 5: {
      const spin = S(uc, 0.03, 0.56);
      const clap = bump(uc, 0.8, 0.1);
      const ang = -Math.PI * 2 * spin;
      const sx = lerp(ang, -1.32 - Math.PI * 2, clap);
      const sz = lerp(0.85, 0.06, clap);
      const sy = lerp(0, -0.85, clap);
      const ex = lerp(-0.28, -2.45, clap);
      b.a0 = P(sx, sy, sz, ex);
      b.a1 = P(sx, -sy, sz, ex);
      b.ln = -0.1 + spin * 0.06 + clap * 0.34;
      b.dp = 0.12 + clap * 0.2;
      b.tw = lerp(0, Math.sin(uc * Math.PI * 3) * 0.06, 1 - clap);
      b.rl = Math.sin(uc * Math.PI * 4) * 0.06;
      b.kk = 26;
      break;
    }

    case 6: {
      const drop = S(uc, 0.05, 0.3) * (1 - S(uc, 0.55, 0.88));
      const rev = bump(uc, 0.34, 0.06) + bump(uc, 0.5, 0.06) + bump(uc, 0.66, 0.06);
      const sx = lerp(0.1, 0.72 - rev * 0.25, drop);
      const sz = lerp(0.35, 0.5 + rev * 0.35, drop);
      const ex = lerp(-0.3, -0.5 - rev * 1.15, drop);
      b.a0 = P(sx, -0.1, sz, ex);
      b.a1 = P(sx, 0.1, sz, ex);
      b.ln = 0.5 * drop + rev * 0.08;
      b.dp = 0.12 + drop * 0.55;
      b.tw = Math.sin(uc * Math.PI * 3) * 0.05 * drop;
      b.kk = 30 + rev * 40;
      break;
    }

    case 7: {

      const stairs = (x: number, n: number) => {
        const tt = clamp(x, 0, 1) * n;
        const i = Math.min(n - 1, Math.floor(tt));
        return (i + sm(clamp((tt - i) / 0.75, 0, 1))) / (n - 1);
      };
      const down = P(0.08, -0.1, 0.3, -0.5);
      const out = P(-0.25, -0.2, 1.45, -1.6);
      const fwd = P(-1.5, -0.15, 0.4, -0.12);
      const poseAt = (v: number): Pose => (v < 0.5 ? lerpPose(down, out, v * 2) : lerpPose(out, fwd, (v - 0.5) * 2));
      const l1 = S(uc, 0.06, 0.3);
      const r1 = S(uc, 0.4, 0.64);
      const enter = S(uc, 0.02, 0.12);
      const aL = poseAt(stairs(l1, 3));
      const aR = poseAt(stairs(r1, 3));
      b.a0 = lerpPose(GUARD, aL, enter);
      b.a1 = lerpPose(GUARD, aR, enter);
      const tick = S(uc, 0.74, 0.84);
      b.ln = 0.06 + enter * 0.04;
      b.dp = 0.14 + tick * 0.06;
      b.tw = Math.sin(uc * Math.PI * 4) * 0.05 * enter + tick * 0.1;
      b.rl = tick * 0.12;
      b.kk = 34;
      break;
    }

    case 8: {

      const wind = S(uc, 0.06, 0.36) * (1 - S(uc, 0.5, 0.6));
      const fire = S(uc, 0.58, 0.7) * (1 - S(uc, 0.86, 1));
      const shake = Math.sin(uc * Math.PI * 30) * 0.03 * wind;
      const sx = lerp(lerp(GUARD.sx, 0.72, wind), -1.28, fire) + shake;
      const sz = lerp(lerp(GUARD.sz, 0.42, wind), 0.3, fire);
      const ex = lerp(lerp(GUARD.ex, -0.55, wind), -0.22, fire);
      b.a0 = P(sx, -0.5 + fire * 0.2, sz, ex);
      b.a1 = P(sx, -0.5 - fire * 0.2, sz, ex);
      b.ln = lerp(lerp(0.08, -0.4, wind), 0.3, fire);
      b.dp = 0.12 + wind * 0.22 - fire * 0.06;
      b.tw = Math.sin(uc * Math.PI * 6) * 0.03 * wind;
      b.rl = shake;
      b.kk = 26 + fire * 30;
      break;
    }

    case 9: {

      const ph = uc * Math.PI * 6;
      const on = S(uc, 0.06, 0.2) * (1 - S(uc, 0.84, 0.94));
      const sx = -1.15 + Math.sin(ph) * 0.22 * on;
      const sz = 0.42 + Math.cos(ph) * 0.2 * on;
      const ex = -1.95 + Math.sin(ph * 1.5) * 0.16 * on;
      b.a0 = lerpPose(GUARD, P(sx, -0.45, sz, ex), on);
      b.a1 = lerpPose(GUARD, P(sx, -0.45, sz, ex), on);
      b.ln = 0.08 + on * 0.16;
      b.dp = 0.12 + on * 0.12 + Math.sin(ph * 2) * 0.03 * on;
      b.tw = Math.sin(ph) * 0.07 * on;
      b.rl = Math.cos(ph) * 0.05 * on;
      b.kk = 40;
      break;
    }

    case 10: {

      const hit = Math.max(bump(uc, 0.2, 0.09), bump(uc, 0.4, 0.085), bump(uc, 0.6, 0.08));
      const open = Math.max(bump(uc, 0.09, 0.1), bump(uc, 0.3, 0.09), bump(uc, 0.5, 0.085));
      const on = S(uc, 0, 0.08);
      const chin = S(uc, 0.66, 0.78) * (1 - S(uc, 0.86, 1));
      const READY = P(-1.0, -0.42, 0.55, -1.75);
      const WIDE = P(-1.25, -0.3, 1.05, -1.25);
      const MET = P(-0.85, -0.52, -0.3, -1.65);
      const CHIN = P(-1.3, -0.2, 1.6, -0.45);
      let arm = lerpPose(lerpPose(READY, WIDE, open), MET, hit);
      arm = lerpPose(arm, CHIN, chin);
      b.a0 = lerpPose(GUARD, arm, on);
      b.a1 = lerpPose(GUARD, arm, on);
      b.ln = 0.14 + open * 0.04 + hit * 0.24 - chin * 0.32;
      b.dp = 0.14 + hit * 0.14 - chin * 0.05;
      b.tw = Math.sin(uc * Math.PI * 6) * 0.05;
      b.rl = Math.sin(uc * Math.PI * 9) * 0.03 * (1 - chin);
      b.kk = 52;
      break;
    }

    case 11: {
      const beckon = S(uc, 0.12, 0.35) * (1 - S(uc, 0.82, 0.96));
      const wave = Math.sin(uc * Math.PI * 8) * 0.5 + 0.5;
      const target0 = P(0.08, -0.22, 0.35, -0.45);
      const target1 = P(-1.25, 0.12, 0.18, -1.35 - wave * 0.7);
      b.a0 = lerpPose(GUARD, target0, S(uc, 0.05, 0.2));
      b.a1 = lerpPose(GUARD, target1, beckon);
      b.ln = lerp(0.08, -0.16, beckon);
      b.dp = lerp(0.12, 0.02, beckon);
      b.tw = Math.sin(uc * Math.PI * 2) * 0.08;
      b.kk = 42;
      break;
    }
  }

  if (back > 0.001) {

    b.a0 = lerpPose(b.a0, rest, back);
    b.a1 = lerpPose(b.a1, rest, back);
    b.tw = lerp(b.tw, 0, back);
    b.ln = lerp(b.ln, 0.08, back);
    b.dp = lerp(b.dp, 0.12, back);
    b.rl = lerp(b.rl, 0, back);
  }
  return b;
}

export function fallStages(e: number) {
  const ec = clamp(e, 0, 1.06);

  const slam = Math.sin(Math.PI * clamp((ec - 0.76) / 0.26, 0, 1));
  const layBase = Math.pow(clamp((ec - 0.08) / 0.74, 0, 1), 1.95);
  return {
    buckle: Math.sin(Math.PI * S(ec, 0.0, 0.52)),
    lay: clamp(layBase + slam * 0.04, 0, 1.0),
    side: S(ec, 0.26, 0.94),
    slam,
  };
}

export function fallArms(e: number, dir: number, t = 0, isKo = false): Beat {
  const ec = clamp(e, 0, 1);
  const d = dir < 0 ? -1 : 1;
  const st = fallStages(ec);
  const flailW = Math.sin(Math.PI * S(ec, 0.0, 0.68));
  const settleW = S(ec, 0.48, 1.0);
  const bounce = st.slam * (1 - S(ec, 0.88, 1.0));
  const drift = Math.sin(t * 3.6) * 0.04 * (1 - settleW);

  const FLAIL_LEAD = P(-0.48 + drift, 0.12 * d, 0.58, -0.82);
  const FLAIL_TRAIL = P(-0.64 - drift, -0.22 * d, 0.34, -1.28);

  const BOUNCE_LEAD = P(-0.14, 0.08 * d, 0.64, -0.68);
  const BOUNCE_TRAIL = P(-0.26, -0.18 * d, 0.44, -1.04);

  const REST_DOWN = P(0.12, 0.02, 0.38, -0.32);
  const REST_KO_LEAD = P(0.08, 0.12, 0.64, -0.58);
  const REST_KO_TRAIL = P(-0.16, -0.34, 0.28, -1.18);

  const startLead = lerpPose(GUARD, FLAIL_LEAD, flailW);
  const startTrail = lerpPose(GUARD, FLAIL_TRAIL, flailW);

  const endLead = isKo ? REST_KO_LEAD : REST_DOWN;
  const endTrail = isKo ? REST_KO_TRAIL : REST_DOWN;

  const leadArm = lerpPose(lerpPose(startLead, endLead, settleW), BOUNCE_LEAD, bounce * 0.65);
  const trailArm = lerpPose(lerpPose(startTrail, endTrail, settleW), BOUNCE_TRAIL, bounce * 0.65);

  const a0 = d > 0 ? leadArm : trailArm;
  const a1 = d > 0 ? trailArm : leadArm;

  return {
    a0,
    a1,
    tw: (-d * 0.22 * st.buckle + d * 0.12 * bounce) * (1 - settleW) + (isKo ? d * 0.14 * settleW : 0),
    ln: lerp(0.08 + st.buckle * 0.18 - bounce * 0.12, 0.08, settleW),
    dp: lerp(0.12 + st.buckle * 0.26, 0.12, settleW),
    rl: (d * 0.16 * st.buckle - d * 0.08 * bounce) * (1 - settleW) + (isKo ? d * 0.12 * settleW : 0),
    kk: lerp(5.5, 9.5, settleW),
  };
}

export function riseStages(u: number) {
  const uc = clamp(u, 0, 1);
  return {

    side: Math.sin(Math.PI * clamp(uc / 0.46, 0, 1)),
    head: Math.sin(Math.PI * S(uc, 0.02, 0.44)),
    tuck: Math.sin(Math.PI * S(uc, 0.05, 0.62)),
    kneel: Math.sin(Math.PI * S(uc, 0.2, 0.74)),
    fold: Math.sin(Math.PI * S(uc, 0.26, 0.94)),
    reach: Math.sin(Math.PI * S(uc, 0.3, 0.68)),
    bounce: Math.sin(Math.PI * S(uc, 0.86, 1)),

    hipUp: S(uc, 0.12, 0.74),
    unroll: S(uc, 0.24, 0.88),
    legs: S(uc, 0.34, 0.86),
    tall: S(uc, 0.66, 0.98),
  };
}

export function getupFoot(riseU: number, steps: number) {
  const want = riseU > 0.42 ? 2 : riseU > 0.18 ? 1 : 0;
  if (want <= steps) return null;
  const foot = want === 1 ? 1 : 0;
  return { steps: want, foot, z: 0, x: 0, dur: 0.4, seq: 900 + want, lift: 0.26 };
}

export function riseArms(u: number, dir: number): Beat {
  const uc = clamp(u, 0, 1);
  const d = dir < 0 ? -1 : 1;
  const st = riseStages(uc);
  const plant = d > 0 ? 0 : 1;
  const slide = S(uc, 0.03, 0.18);
  const push = S(uc, 0.24, 0.46);
  const off = S(uc, 0.5, 0.7);
  const swing = Math.sin(Math.PI * S(uc, 0.06, 0.8));
  const drive = st.reach;
  const ribs = S(uc, 0.62, 0.88);
  const back = S(uc, 0.88, 1);

  const U = P(0.12, 0.02, 0.38, -0.32);
  const REACH = P(0.22, -0.05, 0.74, -0.8);
  const PRESS = P(0.36, 0.05, 1.0, -0.05);
  const OFF = P(0.06, -0.12, 0.42, -1.4);
  const HAUL = P(-0.8, -0.3, 0.42, -1.9);
  const DRIVE = P(-0.72, -0.2, -0.2, -0.85);
  const RIBS = P(-0.5, -0.3, 0.16, -1.6);
  const plantArm = lerpPose(lerpPose(lerpPose(U, REACH, slide), PRESS, push), OFF, off);
  const freeArm = lerpPose(lerpPose(lerpPose(U, HAUL, swing), DRIVE, drive), RIBS, ribs);
  let a0 = plant === 0 ? plantArm : freeArm;
  let a1 = plant === 0 ? freeArm : plantArm;
  a0 = lerpPose(a0, GUARD, back);
  a1 = lerpPose(a1, GUARD, back);

  const shake = Math.sin(uc * Math.PI * 7) * S(uc, 0.88, 1) * 0.07;
  a0 = { ...a0, sz: a0.sz + shake };
  a1 = { ...a1, sz: a1.sz - shake };

  return {
    a0,
    a1,

    tw: d * 0.22 * st.side * (1 - st.unroll) + shake * 0.4,
    ln: 0.08 + st.side * (0.26 * (1 - st.unroll) + 0.22 * st.fold),
    dp: 0.12 + st.tuck * 0.18 + st.bounce * 0.13,
    rl: d * 0.2 * st.side * (1 - st.unroll) + shake * 0.11,
    kk: 20 + 26 * (1 - st.unroll),
  };
}
