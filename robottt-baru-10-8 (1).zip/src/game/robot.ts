import * as THREE from 'three';
import { Spring } from './spring';
import { buildRobot, rebuildHelmetAndGloves, ATOM_OPT, BRUTE_OPT, type Ctx, type Opt } from './build';
import { L1, L2, HIP_Y, UP } from './rig';
import { fallStages, riseStages } from './poses';
import { getArmourNormalMap, getArmourRoughnessMap, getCarbonFiberTexture, getSteelNormalMap } from './textures';
import { mount100PercentZeus, unmount100PercentZeus, type ZeusRigMetrics } from './zeusModel';

const ALI_TAP_DUR = 0.15;

const ALI_TAP_PERIOD = 0.15;

const ALI_TAP_OUT = 0.52;

const ALI_BOUNCE_HZ = 2.2;

const ALI_TAP_LIFT = 0.15;

export interface Pose {
  sx: number;
  sy: number;
  sz: number;
  ex: number;
}

export interface RobotStyle {
  variant?: 'brute' | 'atom';
  main: number;
  secondary: number;
  accent: number;
  glow: number;
  helmetSkin?: number;
  gloveSkin?: number;
  armorSkin?: number;
  isZeus100?: boolean;

  atlasChassis?: boolean;
}

export interface AnimState {
  arms: Pose[];
  twist: number;
  lean: number;
  lunge: number;
  dip: number;
  roll: number;
  vf: number;
  vl: number;
  af: number;
  al: number;
  yawRate: number;
  hit: number;
  hitSign: number;
  hitUp: number;

  hitF?: number;
  hitL?: number;
  hitPt?: number;
  hitSpin?: number;
  fall: number;
  air: number;
  time: number;
  glow: number;
  flash: number;
  tilt: number;
  dash: number;
  dashF: number;
  dashL: number;
  idleBounce?: number;
  sprint?: number;
  headYaw?: number;

  shuffle?: number;
  tiltZ?: number;
  ragdoll?: number;
  tuck?: number;
  lookX?: number;
  lookY?: number;

  punchFoot?: number;
  punchZ?: number;
  punchX?: number;
  punchDur?: number;
  punchSeq?: number;
  strike?: number;
  strikePow?: number;

  rise?: number;
  riseDir?: number;
  riseOut?: number;
  stepLift?: number;

  directionalHeadSnap?: boolean;
  hitKind?: 'jab' | 'hook' | 'upper' | 'cross' | 'standard';
  hitArm?: number;
  hitSeq?: number;
  hitPower?: number;
  taunt?: boolean;
}

const ANKLE_H = 0.23;
const STAND_Y = 2.88 + UP * 0.95 + 0.56;

const SOLE = 0.21;
const TOE_Z = 1.24;
const HEEL_Z = 0.62;
const ankleLift = (p: number) => Math.max(0, Math.max(SOLE * Math.cos(p) + TOE_Z * Math.sin(p), SOLE * Math.cos(p) - HEEL_Z * Math.sin(p)) - SOLE);
const RUN_HIP_LOW = 3.54;
const RUN_HIP_BOB = 0.15;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const sm = (u: number) => u * u * (3 - 2 * u);

const swingArc = (u: number) => Math.pow(Math.max(0, Math.sin(Math.PI * Math.pow(u, 0.82))), 1.5);

const softMin = (a: number, b: number, k: number) => (a + b - Math.sqrt((a - b) * (a - b) + k * k)) * 0.5;
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

interface Foot {
  x: number;
  z: number;
  fx: number;
  fz: number;
  stepping: boolean;
  u: number;
  dur: number;
  lift: number;
  err: number;
  flx: number;
  flz: number;
  pitch: number;
  curX: number;
  curZ: number;
  lag: number;
  yawOff: number;
  stT: number;
  gaitStep: boolean;
  shuffle: boolean;
  aliStep: boolean;
  punchStep: boolean;
  tx: number;
  tz: number;
  p0: number;
  follow: number;
}

export class Robot {
  readonly root = new THREE.Group();

  footLimit = Infinity;
  floorY = 0;
  readonly body = new THREE.Group();
  readonly pelvis = new THREE.Group();
  readonly waist = new THREE.Group();
  readonly chest = new THREE.Group();
  readonly neck = new THREE.Group();
  readonly head = new THREE.Group();
  readonly clavs: THREE.Group[] = [];
  readonly caps: THREE.Group[] = [];
  readonly shoulders: THREE.Group[] = [];
  readonly elbows: THREE.Group[] = [];
  readonly wrists: THREE.Group[] = [];
  readonly hipJ: THREE.Group[] = [];
  readonly kneeJ: THREE.Group[] = [];
  readonly footJ: THREE.Group[] = [];
  readonly kneeCaps: THREE.Group[] = [];
  readonly faulds: THREE.Group[] = [];
  readonly fists: THREE.Object3D[] = [];
  readonly eyeOptics: THREE.Group[] = [];
  readonly eyePupils: THREE.Group[] = [];
  readonly eyeScanners: THREE.Mesh[] = [];
  readonly eyeFlares: THREE.Mesh[] = [];
  readonly eyeLights: THREE.PointLight[] = [];
  readonly eyeIris: THREE.Mesh[] = [];
  readonly eyePulses: THREE.Mesh[] = [];
  readonly eyeBeams: THREE.Mesh[] = [];
  private eyeLookX = 0;
  private eyeLookY = 0;
  private eyeFire = 0;
  private strikeCharge = 0;
  eyeBase = new THREE.Color(0xffffff);
  private eyeWhite = new THREE.Color(0xffffff);
  glowMats: THREE.MeshStandardMaterial[] = [];
  bodyMats: THREE.MeshStandardMaterial[] = [];
  onStep?: (foot: number, speed: number, x: number, z: number) => void;

  readonly stride = { arm: 0, swing: 0 };

  private feet: Foot[] = [0, 1].map(() => ({ x: 0, z: 0, fx: 0, fz: 0, flx: 0, flz: 0, stepping: false, u: 0, dur: 0.2, lift: 0, err: 0, pitch: 0, curX: 0, curZ: 0, lag: 0, yawOff: 0, stT: 0, gaitStep: false, shuffle: false, punchStep: false, aliStep: false, tx: 0, tz: 0, p0: 0, follow: 0 }));

  private aliT = 0;
  private aliSide = 0;
  private needSnap = true;
  private ikW = 1;
  private airW = 0;
  private ragW = 0;
  private bounce = 0;
  private sLand = new Spring();
  private sPsi = new Spring();
  private sGaitYaw = new Spring();
  private sGaitRoll = new Spring();
  private sArm = new Spring();
  private sHip = new Spring(2.6 + UP);
  private runW = 0;
  private runK = 0;
  private probes: { parent: THREE.Object3D; p: THREE.Vector3; foot: boolean }[] = [];
  private gait = false;
  private firstStep = false;
  private dashOn = false;
  private dashT = 0;
  private dashDirX = 0;
  private dashDirZ = 1;
  private dashGo = [false, false];
  private dashLead = 0;
  private postDashT = 0;
  private postGaitT = 0;
  private balanceCooldown = 0;
  private dashW = 0;
  private gaitW = 0;
  private back = false;
  private stepDist = 0;
  private nextFoot = 0;

  private moveT = 0;
  private movePeak = 0;
  private tapT = 0;
  private punchSeq = -1;
  private prevSpd = 0;
  private dipK = 0.12;
  private lungeK = 0;
  private punchYaw = 0;
  private feetL = [
    { x: 0, z: 0, y: 0 },
    { x: 0, z: 0, y: 0 },
  ];
  ikErr = [0, 0];

  private sLean = new Spring();
  private sMass = new Spring();
  private sRoll = new Spring();
  private sPelvisYaw = new Spring();
  private sWaistYaw = new Spring();
  private sChestYaw = new Spring();
  private sHeadX = new Spring();
  private sHeadY = new Spring();
  private sHeadZ = new Spring();
  private sSway = new Spring();
  private sWrist = [new Spring(), new Spring()];
  private sShoulderLag = [new Spring(), new Spring()];
  private prevEx = [-2, -2];

  private lastHitSeq = -1;
  private hookDelayTimer = 0;
  private hookSide = 1;
  private sDelayedTorsoYaw = new Spring();
  private sUpperLift = new Spring();
  private sLayLag = new Spring();

  private tv = new THREE.Vector3();
  private tgtW = new THREE.Vector3();
  private qk = new THREE.Quaternion();
  private qd = new THREE.Quaternion();
  private qf = new THREE.Quaternion();
  private eu = new THREE.Euler();
  ctx!: Ctx;
  private opt!: Opt;

  get isZeus() {
    return !!(this.ctx?.style?.isZeus100 || (this.ctx?.style?.helmetSkin === 1 && this.ctx?.style?.armorSkin === 1));
  }

  get isAtlas() {
    return !this.isZeus;
  }

  get isAtlasChassis() {
    return !this.isZeus && !!this.ctx?.style?.atlasChassis;
  }

  get isAtom() {
    return this.isAtlas;
  }

  armorColor = 0x8e949c;

  constructor(style: RobotStyle, scale = 1) {
    this.armorColor = style.main;
    const mk = (color: number, metalness: number, roughness: number) => {
      const m = new THREE.MeshStandardMaterial({ color, metalness, roughness, emissive: 0xffffff, emissiveIntensity: 0 });
      this.bodyMats.push(m);
      return m;
    };
    const atom = style.variant === 'atom';
    const main = mk(style.main, atom ? 0.5 : 0.8, atom ? 0.3 : 0.34);
    const sec = mk(style.secondary, 0.7, 0.5);
    const dark = mk(0x121317, 0.9, 0.5);
    const steel = mk(0xa4abb5, 1, 0.24);
    const accent = mk(style.accent, 0.55, 0.32);
    const joint = mk(atom ? 0x2c3038 : 0x1e2026, 0.75, 0.5);
    const rubber = mk(0x0c0d10, 0.15, 0.88);
    const visor = mk(0x04060a, 0.9, 0.1);
    visor.side = THREE.DoubleSide;
    const glow = new THREE.MeshStandardMaterial({ color: style.glow, emissive: style.glow, emissiveIntensity: 2, roughness: 0.4 });
    this.glowMats.push(glow);

    this.root.add(this.body);
    this.root.scale.setScalar(scale * 0.94);
    this.body.add(this.pelvis);

    const core = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 2.4, roughness: 0.3 });
    this.eyeBase.setHex(style.glow);

    this.ctx = { main, sec, dark, steel, accent, glow, joint, rubber, visor, core, style };
    this.opt = atom ? ATOM_OPT : BRUTE_OPT;
    buildRobot(this, this.ctx, this.opt);
    if (style.isZeus100 || (style.helmetSkin === 1 && style.armorSkin === 1)) {
      const hex = style.glow ? `#${style.glow.toString(16).padStart(6, '0')}` : '#22ff44';
      mount100PercentZeus(this, hex);
    }
    this.addProbes();
  }

  /** Dynamically swap the 3D helmet, boxing glove and body armor skins on this robot in real time */
  setSkins(helmetSkin: number, gloveSkin: number, armorSkin = this.ctx.style.armorSkin ?? 0, isZeus?: boolean) {
    this.ctx.style.helmetSkin = helmetSkin;
    this.ctx.style.gloveSkin = gloveSkin;
    this.ctx.style.armorSkin = armorSkin;
    const forceZeus = isZeus !== undefined ? isZeus : (armorSkin === 1 || helmetSkin === 1 || this.ctx.style.isZeus100 === true);
    if (forceZeus) {
      this.ctx.style.isZeus100 = true;
      mount100PercentZeus(this);
    } else {
      this.ctx.style.isZeus100 = false;
      unmount100PercentZeus(this);
      rebuildHelmetAndGloves(this, this.ctx, this.opt);
    }
    this.snapFeet();
    this.setEnhancedTextures(this.hasEnhancedTextures);
  }

  hasEnhancedTextures = false;

  /**
   * Toggle between HD Enhanced PBR Textures (brushed metal, carbon fiber weave, machined steel)
   * and Normal Clean Textures.
   */
  setEnhancedTextures(enabled: boolean) {
    this.hasEnhancedTextures = enabled;
    const c = this.ctx;
    if (enabled) {
      c.main.normalMap = getArmourNormalMap();
      c.main.roughnessMap = getArmourRoughnessMap();
      c.main.normalScale = new THREE.Vector2(0.65, 0.65);

      c.sec.normalMap = getCarbonFiberTexture();
      c.sec.roughness = 0.44;

      c.steel.normalMap = getSteelNormalMap();
      c.steel.normalScale = new THREE.Vector2(0.85, 0.85);
      c.steel.roughnessMap = getArmourRoughnessMap();

      c.joint.normalMap = getSteelNormalMap();
      c.joint.normalScale = new THREE.Vector2(0.6, 0.6);

      c.accent.normalMap = getArmourNormalMap();
      c.accent.normalScale = new THREE.Vector2(0.5, 0.5);
    } else {
      c.main.normalMap = null;
      c.main.roughnessMap = null;
      c.sec.normalMap = null;
      c.steel.normalMap = null;
      c.steel.roughnessMap = null;
      c.joint.normalMap = null;
      c.accent.normalMap = null;
    }
    c.main.needsUpdate = true;
    c.sec.needsUpdate = true;
    c.steel.needsUpdate = true;
    c.joint.needsUpdate = true;
    c.accent.needsUpdate = true;
  }

  private addProbe(parent: THREE.Object3D, x: number, y: number, z: number, foot = false) {
    this.probes.push({ parent, p: new THREE.Vector3(x, y, z), foot });
  }

  /** Points on the outermost surfaces of every body part (robot-local to the part). */
  private addProbes() {
    const P = (o: THREE.Object3D, pts: number[][], foot = false) => pts.forEach(([x, y, z]) => this.addProbe(o, x, y, z, foot));
    P(this.chest, [[0.9, 0.1, -1.0], [-0.9, 0.1, -1.0], [0.9, 1.5, -1.0], [-0.9, 1.5, -1.0], [0, 0.8, -1.05], [0.9, 1.2, 0.75], [-0.9, 1.2, 0.75], [0, 0.3, 0.6], [1.2, 1.4, 0], [-1.2, 1.4, 0]]);
    P(this.head, [[0, 0.72, -0.05], [0, -0.45, 0.35], [0.45, 0.1, 0], [-0.45, 0.1, 0], [0, 0.1, -0.5], [0, 0.1, 0.47]]);
    P(this.pelvis, [[1.09, 2.85, -0.52], [-1.09, 2.85, -0.52], [1.09, 2.85, 0.52], [-1.09, 2.85, 0.52], [0, 2.22, -0.42], [0, 2.22, 0.42], [0.66, 3.3, 0.44], [-0.66, 3.3, 0.44], [0.56, 2.9, -0.62], [-0.56, 2.9, -0.62]]);
    for (let i = 0; i < 2; i++) {
      P(this.caps[i], [[0, -0.5, 0], [0, 0.15, 0.78], [0, 0.15, -0.78], [0.72, 0.1, 0], [-0.72, 0.1, 0]]);
      P(this.shoulders[i], [[0.5, -0.6, 0], [-0.5, -0.6, 0], [0, -0.6, 0.5], [0, -0.6, -0.5]]);
      P(this.elbows[i], [[0.5, -0.55, 0], [-0.5, -0.55, 0], [0, -0.55, 0.5], [0, -0.55, -0.5], [0, 0, -0.36]]);
      P(this.fists[i], [[0.54, -0.5, 0], [-0.54, -0.5, 0], [0, -1.0, 0.55], [0, -1.0, -0.5], [0, -0.5, 0.6], [0, -0.5, -0.6], [0, -1.04, 0]]);
      P(this.hipJ[i], [[0.62, -0.6, 0], [-0.62, -0.6, 0], [0, -0.6, 0.64], [0, -0.6, -0.64]]);
      P(this.kneeJ[i], [[0, 0, 0.62], [0, 0, -0.5], [0.5, 0, 0], [-0.5, 0, 0], [0, -0.8, -0.58], [0, -0.9, 0.52]]);
      // boot: heel, toe tip and the four sole corners (only used when the legs are not IK-planted)
      P(this.footJ[i], [[0, -SOLE, -HEEL_Z], [0, -SOLE, TOE_Z], [0.45, -SOLE, 0.8], [-0.45, -SOLE, 0.8], [0.45, -SOLE, -0.3], [-0.45, -SOLE, -0.3]], true);
    }
  }

  /**
   * Floor contact: if any part of the body is below the floor, lift the whole body by exactly that much.
   * (Planted feet are handled by the IK; this catches falls, knock-downs, air poses and animation overshoot.)
   */
  /**
   * when a staged scene owns the body it carries its own floor handling (root-y keys drop the body to
   * the canvas on the sit-fall), so the floor-probe lift must NOT fight it — it used to shove the folded
   * body up and down every frame (the shivering "aneh pas bangkit" get-up).
   */
  bridgeOwned = false;
  private prevLay = 0; // last frame's collapse weight (for the head-hits-last whip)
  private groundLift = 0; // smoothed floor lift (robot units): kills the frame-to-frame hop of a body whose lowest point keeps changing
  private groundSolve(S: number, ik: number, floorPose = false, dt = 0, lying = false) {
    if (this.bridgeOwned) return;
    this.root.updateMatrixWorld(true);
    let minY = Infinity;
    for (const pr of this.probes) {
      // THE BOOTS NEVER PROP HIM UP. Once the IK owns the feet the ankles are placed on the canvas by the solve
      // itself, so a boot probe can only do harm: on the floor a single boot poking through the canvas used to
      // lift the WHOLE body until that boot cleared — the robot floated a full metre above the mat, lying flat,
      // standing on one heel. The body has to rest on its back, hip or shoulder there. (And while he is standing
      // the boot probes only ever asked for the 6 mm of mesh/probe slack the art has, tipping the soles off the
      // canvas — the IK already plants them flush.)
      if (pr.foot && (floorPose || lying || ik > 0.85)) continue;
      this.tv.copy(pr.p).applyMatrix4(pr.parent.matrixWorld);
      if (this.tv.y < minY) minY = this.tv.y;
    }
    const margin = this.floorY + 0.04;
    // Check boot soles so feet never penetrate or sink below the floor surface
    if (!floorPose && !lying) {
      const soleThick = S * (this.root.userData.zeusMetrics?.SOLE ?? SOLE);
      for (let i = 0; i < 2; i++) {
        this.footJ[i].getWorldPosition(this.tv);
        const bootBottomY = this.tv.y - soleThick;
        if (bootBottomY < minY) minY = bootBottomY;
      }
    }
    // The lift itself is filtered: it comes up instantly (nothing ever shows through the canvas) but it comes
    // DOWN slowly. A falling / lying body's lowest point jumps between a fist, an elbow, a shoulder and the
    // head as the limbs settle — applied raw, every one of those jumps hopped the whole machine up and down (the
    // "shivering" knock-down).
    const want = minY < margin ? (margin - minY) / S : 0;
    if (dt <= 0 || want > this.groundLift) this.groundLift = want; // up: hard (nothing ever goes through the canvas)
    else this.groundLift += (want - this.groundLift) * (1 - Math.exp(-(lying ? 16 : 10) * dt)); // down: eased, faster settle on canvas
    if (this.groundLift > 0.0005) this.body.position.y += this.groundLift;
  }

  /**
   * RAGDOLL JOLT: a blow / a landing shakes every part that hangs off the body — the head whips on its neck, the
   * shoulders are thrown, the hips sink on their suspension and the chest rocks — each on its own spring, so they
   * settle at their own rates instead of the whole machine moving as one block. `mag` ≈ 1 for a heavy landing.
   */
  jolt(mag: number, side = 1) {
    this.sHeadX.v += mag * 6.5;
    this.sHeadZ.v += mag * 2.4 * side;
    this.sHeadY.v += mag * 1.6 * side;
    for (const sp of this.sShoulderLag) sp.v += mag * 3.2;
    this.sMass.v += mag * 1.1;
    this.sLean.v += mag * 0.9;
    this.sRoll.v += mag * 0.5 * side;
  }

  setStyleGlow(color: number) {
    for (const m of this.glowMats) {
      m.color.setHex(color);
      m.emissive.setHex(color);
    }
    this.eyeBase.setHex(color);
    for (const f of this.eyeFlares) {
      if (f.material instanceof THREE.MeshBasicMaterial) f.material.color.setHex(color);
    }
    for (const m of this.eyeIris) {
      if (m.material instanceof THREE.MeshBasicMaterial) m.material.color.setHex(color);
    }
    for (const m of this.eyePulses) {
      if (m.material instanceof THREE.MeshBasicMaterial) m.material.color.setHex(color);
    }
    for (const m of this.eyeBeams) {
      if (m.material instanceof THREE.MeshBasicMaterial) m.material.color.setHex(color);
    }
    for (const l of this.eyeLights) {
      l.color.setHex(color);
    }
  }

  /** Re-plant feet under the body on the next frame (after teleports / resets). */
  snapFeet() {
    this.needSnap = true;
    this.ikW = 1;
    this.airW = 0;
    this.ragW = 0;
    for (const s of [this.sLean, this.sMass, this.sRoll, this.sPelvisYaw, this.sWaistYaw, this.sChestYaw, this.sHeadX, this.sHeadY, this.sHeadZ, this.sSway]) s.set(0);
    for (const s of this.sWrist) s.set(0);
    for (const s of this.sShoulderLag) s.set(0);
    this.sLand.set(0);
    this.sPsi.set(0);
    this.sGaitYaw.set(0);
    this.sGaitRoll.set(0);
    this.sArm.set(0);
    this.runW = 0;
    this.runK = 0;
    this.sHip.set(2.6 + UP);
    this.gait = false;
    this.gaitW = 0;
    this.stepDist = 0;
    this.dashOn = false;
    this.firstStep = false;
    this.postDashT = 0;
    this.dashW = 0;
    this.moveT = 0;
    this.movePeak = 0;
    this.tapT = 0;
    this.punchSeq = -1;
    this.prevSpd = 0;
    this.balanceCooldown = 0;
  }

  /** When a script slides the root (the VS clash lunge on the matchmaking screen), the planted feet must travel
   *  WITH it — otherwise the reach solver crushes the hips down and the balance steps shuffle the boots.
   *  Call with the root's world-space delta right after moving it. */
  shiftPlantedFeet(dx: number, dz: number) {
    if (dx === 0 && dz === 0) return;
    for (const f of this.feet) {
      f.x += dx;
      f.z += dz;
      f.curX += dx;
      f.curZ += dz;
      f.fx += dx;
      f.fz += dz;
    }
  }

  // ------------------------------------------------------------------ footwork
  // Walking = a real gait cycle (heel strike -> flat -> heel off -> toe off -> swing), driven by the distance
  // travelled so stride length follows speed. Hips & feet turn towards the direction of travel while the chest
  // keeps facing the opponent (no crab-walking). Standing still = boxer stance with a light bounce.
  private updateFeet(a: AnimState, dt: number, S: number, yaw: number, psi: number) {
    const rp = this.root.position;
    const c = Math.cos(yaw);
    const sn = Math.sin(yaw);
    const toW = (lx: number, lz: number) => ({ x: rp.x + S * (lx * c + lz * sn), z: rp.z + S * (-lx * sn + lz * c) });
    const toL = (wx: number, wz: number) => {
      const dx = (wx - rp.x) / S;
      const dz = (wz - rp.z) / S;
      return { x: dx * c - dz * sn, z: dx * sn + dz * c };
    };
    const spdRaw = Math.hypot(a.vf, a.vl);
    const spd = Math.min(spdRaw, 60);
    const sp01 = Math.min(1, spd / 4.5);
    const dirx = spdRaw > 0.3 ? a.vl / spdRaw : 0;
    const dirz = spdRaw > 0.3 ? a.vf / spdRaw : 0;
    const K = 1 / 0.94; // velocity (per f.scale) -> robot-local units
    // 0 = walking, 1 = full sprint (running has a flight phase, longer strides and a high knee drive)
    // The target comes from the speed, but it goes through a low-pass filter (~0.1 s) and an S-curve, so stride,
    // swing time, foot roll, lift and arm pose all morph together instead of snapping when the speed crosses a threshold.
    const runU = a.sprint !== undefined ? clamp(a.sprint * clamp((spdRaw - 4.5) / 4.0, 0, 1), 0, 1) : clamp((spdRaw - 6.4) / 3.2, 0, 1);
    this.runK += (runU * runU * (3 - 2 * runU) - this.runK) * (1 - Math.exp(-10 * dt));
    const run = this.runK;

    // Step length grows with speed — PRO BOXING FOOTWORK with a FLUENT cadence: roughly 2 steps/s while strolling
    // (the runway strut) and quick-but-never-frantic steps in the ring. The low end is kept long enough that a slow
    // walk never turns into a high-cadence twitch — that is what read as an ugly, stiff shuffle.
    // BIG CHASSIS (100% Zeus) strides LONGER to match: his legs are ~15% longer, so every step covers more ground
    // at the same confident cadence instead of a giant robot taking dainty little steps.
    const zm = this.root.userData.zeusMetrics as ZeusRigMetrics | undefined;
    const legK = zm ? (zm.L1 + zm.L2) / (L1 + L2) : 1;
    const walkStride = clamp((0.95 + 0.14 * spdRaw) * (this.back ? 0.9 : 1), 1.15, 1.85);
    const runCad = 2.7 + Math.max(0, spdRaw - 11.5) * 0.1;
    const strideL = lerp(walkStride, clamp(spdRaw / runCad, 2.0, 5.0), run) * legK;
    const HALF_MAX = 1.45 * legK;
    const duty = clamp(Math.min(lerp(0.6, 0.38, run) - clamp((spdRaw - 11.5) / 45, 0, 0.1), HALF_MAX / strideL), 0.2, 0.66);
    const half = duty * strideL;

    // boxing stance (used when standing still / skidding). dip and lunge are filtered first: a punch or a landing
    // spikes both of them, and letting that through would jerk the stance the planted feet are measured against.
    this.dipK += (a.dip - this.dipK) * (1 - Math.exp(-14 * dt));
    this.lungeK += (a.lunge - this.lungeK) * (1 - Math.exp(-12 * dt));
    const guardStance = zm ? clamp((this.dipK - 0.045) / 0.075, 0, 1) : 1;
    // ZEUS stands WIDE like Atlas at all times (boots apart, staggered fore/aft) — the old rest pose tucked the
    // boots nearly side-by-side whenever the guard relaxed ("dempet"), which read as dainty instead of a boxer.
    const wide = zm
      ? lerp(zm.hipX + 0.30, zm.hipX + 0.42 + this.dipK * 0.22, guardStance)
      : 1.18 + this.dipK * 0.3;
    const zLead = zm ? lerp(0.30, 0.52, guardStance) : 0.62;
    const zRear = zm ? lerp(-0.34, -0.58, guardStance) : -0.72;
    const ideal = [
      { x: wide, z: zLead + this.lungeK * 0.28 },
      { x: -wide, z: zRear + this.lungeK * 0.12 },
    ];
    const restP = zm ? [lerp(0.0, 0.02, guardStance), lerp(0.0, 0.04, guardStance)] : [0.01, 0.03];
    const restYaw = zm ? [lerp(0.1, 0.12, guardStance), lerp(-0.30, -0.44, guardStance)] : [0.1, -0.5];

    // THE ALI SHUFFLE amount: standing still, not mid-dash, not taking a blow, and it fades out with the walk (the
    // stride owns the feet the moment he is actually travelling). Everything below keys off this one number.
    const aliAmt = clamp(a.shuffle ?? 0, 0, 1) * (1 - this.gaitW) * (this.dashOn ? 0 : 1) * (a.hit < 0.2 ? 1 : 0);
    // the float: the whole body keeps a faster, lighter rhythm while the dance is running
    this.bounce += dt * Math.PI * 2 * (1.15 + sp01 * 0.4 + aliAmt * ALI_BOUNCE_HZ);
    const h = 0.5 + 0.5 * Math.sin(this.bounce);
    const bounceAmt = clamp(a.idleBounce ?? 1, 0, 1) * (1 - this.gaitW);
    // pro boxers PENDULUM lightly on the spot — a quiet weight shift, not a bouncy march. ALI STYLE turns that
    // pendulum up: the float has a real rise and fall in it (and the frequency follows the dance, see ALI_BOUNCE_HZ)
    const bob = (h - 0.5) * (0.045 + aliAmt * 0.085) * bounceAmt;

    if (this.needSnap) {
      for (let i = 0; i < 2; i++) {
        const f = this.feet[i];
        const w = toW(ideal[i].x, ideal[i].z);
        f.x = f.curX = w.x;
        f.z = f.curZ = w.z;
        f.flx = ideal[i].x;
        f.flz = ideal[i].z;
        f.stepping = false;
        f.lift = 0;
        f.pitch = restP[i];
        f.yawOff = restYaw[i];
        f.lag = 0;
        f.stT = 0;
        f.follow = 0;
        f.p0 = restP[i];
        f.punchStep = false;
        f.shuffle = false;
        f.gaitStep = false;
      }
      this.gait = false;
      if (this.ikW > 0.85) this.needSnap = false;
      this.storeFeetLocal(toL);
      return { sway: 0, roll: 0, yaw: 0, bob: 0, swing: 0, arm: 0, flight: 0, run: 0, depth: 0 };
    }

    // ---- taunt / showcase lock: feet stay solidly and cleanly planted on the canvas ----
    if (a.taunt) {
      this.gait = false;
      this.stepDist = 0;
      this.dashOn = false;
      for (let i = 0; i < 2; i++) {
        const f = this.feet[i];
        if (f.stepping) {
          f.x = f.curX;
          f.z = f.curZ;
          f.stepping = false;
        }
        f.pitch = lerp(f.pitch, restP[i], 1 - Math.exp(-20 * dt));
        f.yawOff = lerp(f.yawOff, restYaw[i], 1 - Math.exp(-14 * dt));
        f.curX = f.x;
        f.curZ = f.z;
        f.follow = 0;
      }
      this.storeFeetLocal(toL);
      return { sway: 0, roll: 0, yaw: 0, bob: 0, swing: 0, arm: 0, flight: 0, run: 0, depth: 0 };
    }

    // ---- boxing dash: a low, committed lead step followed by the rear foot ----
    // ---- boxing dash: a swift, athletic lead step followed by the rear foot ----
    const dashing = a.dash > 0.5 && this.ikW > 0.5;
    if (dashing && !this.dashOn) {
      this.dashOn = true;
      this.dashT = 0;
      const dn = Math.hypot(a.dashL, a.dashF) || 1;
      this.dashDirX = a.dashL / dn;
      this.dashDirZ = a.dashF / dn;
      const fwn = (i: number) => ideal[i].x * this.dashDirX + ideal[i].z * this.dashDirZ;
      this.dashLead = fwn(0) >= fwn(1) ? 0 : 1;
      this.dashGo = [false, false];
    } else if (!dashing && this.dashOn) {
      this.dashOn = false;
      this.postDashT = 0.12;
      if (spdRaw > 0.3) {
        this.gait = true;
        this.firstStep = true;
        this.stepDist = strideL * 0.9;
      }
    }
    if (this.dashOn) this.dashT += dt;
    this.postDashT = Math.max(0, this.postDashT - dt);
    this.postGaitT = Math.max(0, this.postGaitT - dt);

    // ---- movement-burst tracking: short taps stay agile and calm ----
    if (spdRaw > 0.8) {
      this.moveT += dt;
      this.movePeak = Math.max(this.movePeak, spdRaw);
    } else {
      if (this.moveT > 0.02 && this.moveT < 0.17 && this.movePeak > 0.8) this.tapT = 0.35;
      this.moveT = 0;
      this.movePeak = 0;
    }
    this.tapT = Math.max(0, this.tapT - dt);
    this.balanceCooldown = Math.max(0, this.balanceCooldown - dt);

    // ---- responsive gait mode hysteresis ----
    const wasGait = this.gait;
    const dv = dt > 0 ? (spdRaw - this.prevSpd) / dt : 0;
    this.prevSpd = spdRaw;
    const accAlong = (a.vf * a.af + a.vl * a.al) / Math.max(0.5, spdRaw);
    const braking = dv < -5.5 || (spdRaw < 1.6 && accAlong < -3.0);
    if (this.dashOn) this.gait = false;
    else if (!this.gait && !braking && spdRaw > 0.8 && this.moveT > 0.082) {
      this.gait = true;
      this.firstStep = true;
    } else if (this.gait && (spdRaw < 0.35 || braking)) {
      this.gait = false;
      this.postGaitT = 0.4; // just stopped walking — do NOT rush to "fix" the stance
    }
    this.gaitW += ((this.gait ? 1 : 0) - this.gaitW) * (1 - Math.exp(-9 * dt));

    if (this.gait && !wasGait) {
      // start walking: the foot that is further behind steps first
      const l0 = toL(this.feet[0].x, this.feet[0].z);
      const l1 = toL(this.feet[1].x, this.feet[1].z);
      this.nextFoot = l0.x * dirx + l0.z * dirz <= l1.x * dirx + l1.z * dirz ? 0 : 1;
      if (this.feet[this.nextFoot].stepping) this.nextFoot = 1 - this.nextFoot;
      // ECONOMICAL ENTRY: only stomp a step at once when a foot is genuinely left behind. A quick direction
      // change (retreat → hold → retreat) re-enters the gait WITHOUT a corrective stomp — the feet move only
      // when they really must.
      const ln = this.nextFoot === 0 ? l0 : l1;
      const behindN = -(ln.x * dirx + ln.z * dirz);
      const needNow = behindN > half * 0.85 + 0.22;
      this.stepDist = needNow ? strideL * 0.9 : strideL * 0.3;
      this.firstStep = needNow;
    }

    // Measure stance error on planted feet without artificially dragging them
    for (let i = 0; i < 2; i++) {
      const f = this.feet[i];
      if (f.stepping) continue;
      const l = toL(f.x, f.z);
      f.err = Math.hypot(l.x - ideal[i].x, l.z - ideal[i].z);
    }

    // ---- PUNCH FOOTWORK: striking foot re-plants on punch regardless of walk state ----
    const pf = this.dashOn ? -1 : Math.round(a.punchFoot ?? -1);
    const pSeq = a.punchSeq ?? -1;
    let planted = false;
    if (pf >= 0 && pf <= 1 && pSeq !== this.punchSeq) {
      this.punchSeq = pSeq;
      const f = this.feet[pf];
      if (!f.stepping) {
        const z = clamp(a.punchZ ?? 0.2, -0.25, 0.95);
        const x = clamp(a.punchX ?? 0, -0.5, 0.5);
        const curL = toL(f.x, f.z);
        f.flx = curL.x;
        f.flz = curL.z;
        f.punchStep = true;
        f.gaitStep = false;
        f.shuffle = false;
        f.stepping = true;
        f.u = 0;
        f.p0 = f.pitch;
        f.fx = f.x;
        f.fz = f.z;
        f.tx = ideal[pf].x + x;
        f.tz = ideal[pf].z + z;
        f.dur = clamp(a.punchDur ?? 0.19, 0.1, 0.32) * (1 + this.tapT * 0.35);
        f.lift = a.stepLift ?? (0.15 + Math.min(0.1, Math.abs(z) * 0.1));
        f.err = 0;
        this.punchYaw = clamp((a.punchX ?? 0) * 1.1, -0.28, 0.28);
        planted = true;
      }
    }

    // ---- start a new step ----
    if (planted) {
      // punch plant active
    } else if (this.dashOn) {
      this.stepDist = 0;
      for (const i of [this.dashLead, 1 - this.dashLead]) {
        const f = this.feet[i];
        if (this.dashGo[i] || this.dashT < (i === this.dashLead ? 0 : 0.05)) continue;
        this.dashGo[i] = true;
        const curL = toL(f.stepping ? f.curX : f.x, f.stepping ? f.curZ : f.z);
        f.flx = curL.x;
        f.flz = curL.z;
        f.fx = f.stepping ? f.curX : f.x;
        f.fz = f.stepping ? f.curZ : f.z;
        f.stepping = true;
        f.gaitStep = false;
        f.shuffle = true;
        f.u = 0;
        f.p0 = f.pitch;
        f.dur = i === this.dashLead ? 0.17 : 0.20;
        // Athletic foot clearance: just enough to clear the mat — pros shuffle, they don't march
        f.lift = 0.2;
      }
    } else if (this.gait) {
      this.stepDist += spdRaw * dt;
      let trigger = this.firstStep || this.stepDist >= strideL * 0.92;
      for (let i = 0; i < 2; i++) {
        const f = this.feet[i];
        if (f.stepping) continue;
        const l = toL(f.x, f.z);
        const behind = -(l.x * dirx + l.z * dirz);
        if (behind > half * 1.3 + 0.3) {
          this.nextFoot = i;
          trigger = true;
        }
      }
      const f = this.feet[this.nextFoot];
      if (trigger && !f.stepping) {
        this.stepDist = Math.max(0, this.stepDist - strideL * 0.95);
        this.firstStep = false;
        const curL = toL(f.x, f.z);
        f.flx = curL.x;
        f.flz = curL.z;
        f.stepping = true;
        f.gaitStep = true;
        f.u = 0;
        f.fx = f.x;
        f.fz = f.z;
        f.dur = clamp((2 * (1 - duty) * strideL) / Math.max(spdRaw, 3.5), 0.14, 0.38);
        // low, flat shuffle-step clearance — the boot stays close to the canvas like pro boxing footwork
        f.lift = lerp(clamp(0.15 + spd * 0.02, 0.16, 0.24), 0.5, run);
        f.p0 = f.pitch;
        f.follow = 0;
        this.nextFoot = 1 - this.nextFoot;
      }
    } else {
      this.stepDist = 0;
      // ---- THE ALI SHUFFLE (see ALI STYLE in Game.ts) ----
      // Ali's signature: standing on the spot he DANCES — a rapid alternation of light half-steps at the stance, the
      // weight rocking side to side over whichever boot has just landed. It rides the same foot solver as every other
      // step, so the feet plant and clear exactly like they do in a stride (no sliding, no floating).
      if (aliAmt > 0.05) {
        this.aliT -= dt;
        if (this.aliT <= 0) {
          this.aliT = ALI_TAP_PERIOD / Math.max(0.4, aliAmt);
          const i = this.aliSide;
          this.aliSide = 1 - this.aliSide;
          const f = this.feet[i];
          const o = this.feet[1 - i];
          if (!f.stepping && !o.stepping && this.balanceCooldown <= 0) {
            const curL = toL(f.x, f.z);
            f.flx = curL.x;
            f.flz = curL.z;
            f.fx = f.x;
            f.fz = f.z;
            f.punchStep = false;
            f.gaitStep = false;
            f.shuffle = false;
            f.aliStep = true;
            f.stepping = true;
            f.u = 0;
            f.p0 = f.pitch;
            // a light tap OUT of the stance and straight back: the lead foot reaches out, the rear foot closes in
            // behind it — the two never cross (the separation guard further down enforces that)
            const out = ALI_TAP_OUT * aliAmt * (i === 0 ? 1 : -1);
            f.tx = ideal[i].x + out;
            f.tz = ideal[i].z + (i === 0 ? 0.09 : -0.09) * aliAmt;
            f.dur = clamp(ALI_TAP_DUR / Math.max(0.5, aliAmt), 0.1, 0.3);
            f.lift = ALI_TAP_LIFT;
            this.balanceCooldown = 0.12; // the dance replaces the lazy balance corrections while it runs
          }
        }
      }
      let pick = -1;
      let best = 0;
      // Stance recovery threshold: calm, efficient, no fidgeting — pro feet only correct when they REALLY must.
      // When standing still (spdRaw < 0.6), stay firmly grounded unless stance error is genuinely large (> 0.95).
      // Right after a walk burst (postGaitT) corrections stay extra lazy — no rush to "fix" the stance.
      const thr = a.rise !== undefined || a.taunt ? 1e9 : (this.postDashT > 0 ? 0.32 : spdRaw > 0.6 ? 0.55 : 0.95) + this.tapT * 0.25 + (this.postGaitT > 0 ? 0.28 : 0);
      const messy = Math.max(this.feet[0].err, this.feet[1].err) > 1.35;
      // while a blow is landing the feet HOLD — no shuffling mid-exchange (hemat: hanya gerak saat perlu)
      if (this.balanceCooldown <= 0 && a.hit < 0.2) {
        for (let i = 0; i < 2; i++) {
          const f = this.feet[i];
          const o = this.feet[1 - i];
          if (f.stepping || f.err < thr) continue;
          if (o.stepping && f.err < 1.3) continue;
          const score = f.err + (i === 0 ? 0.05 : 0);
          if (score > best) {
            best = score;
            pick = i;
          }
        }
      }
      if (pick >= 0) {
        this.balanceCooldown = 0.34; // prevent rapid consecutive balance steps (quiet, efficient feet)
        const f = this.feet[pick];
        const curL = toL(f.x, f.z);
        f.flx = curL.x;
        f.flz = curL.z;
        f.punchStep = false;
        f.stepping = true;
        f.gaitStep = false;
        f.u = 0;
        f.p0 = f.pitch;
        f.fx = f.x;
        f.fz = f.z;
        const rec = messy ? 0.78 : 1;
        f.dur = clamp(0.24 - spd * 0.024, 0.14, 0.24) * (f.err > 1.2 ? 0.8 : 1) * (1 + this.tapT * 0.35) * rec;
        f.lift = (0.15 + sp01 * 0.1) * (1 - this.tapT * 0.25) * (messy ? 0.9 : 1);
      }
    }

    // ---- animate each foot ----
    let sway = 0;
    let roll = 0;
    let yawS = 0;
    let swingW = 0;
    const toeOut = [0.07, -0.07];
    // foot pitch at touch-down / toe-off: grounded robot boxing footwork keeps soles flat and solid (no excessive tiptoeing)
    const landP = lerp(-0.02, 0.01, run);
    const toeP = lerp(0.015, 0.035, run);
    const pr = { x: Math.cos(psi), z: -Math.sin(psi) };
    const stanceDur = (2 * duty * strideL) / Math.max(spdRaw, 1.2);
    for (let i = 0; i < 2; i++) {
      const f = this.feet[i];
      const s = i === 0 ? 1 : -1;
      if (!f.stepping) {
        if (this.gait) {
          // stance: heel touch -> solid foot flat on canvas -> subtle mechanical push-off roll
          f.stT += dt;
          const us = clamp(f.stT / stanceDur, 0, 1);
          let pit: number;
          if (us < 0.14) pit = lerp(landP, 0, sm(us / 0.14));
          else if (us < 0.58) pit = 0;
          else pit = toeP * sm((us - 0.58) / 0.42);
          // the first third of the stance rolls out of the pitch the foot ACTUALLY touched down with: a foot that
          // lands rolls flat smoothly instead of snapping into a heel-strike pose
          pit = lerp(f.p0, pit, sm(clamp(us / 0.3, 0, 1)));
          f.pitch = lerp(f.pitch, pit, 1 - Math.exp(-(20 + run * 14) * dt));
          f.yawOff = lerp(f.yawOff, psi + toeOut[i], 1 - Math.exp(-14 * dt));
        } else {
          const extra = (i === 0 ? 0.01 : 0.02) * h * bounceAmt;
          f.pitch = lerp(f.pitch, restP[i] + extra, 1 - Math.exp(-20 * dt));
          f.yawOff = lerp(f.yawOff, restYaw[i] * (1 - 0.75 * sp01), 1 - Math.exp(-7.5 * dt));
        }
        f.curX = f.x;
        f.curZ = f.z;
        continue;
      }
      f.u = Math.min(1, f.u + dt / f.dur);
      const u = f.u;
      const rem = (1 - u) * f.dur;
      let tl: { x: number; z: number };
      if (f.shuffle) {
        // land in the stance, offset along the dash: lead foot reaches out, rear foot closes the gap
        const reach = i === this.dashLead ? 0.90 : 0.50;
        const velK = i === this.dashLead ? 0.40 : 0.26;
        let ox = this.dashDirX * reach + a.vl * K * rem * velK;
        let oz = this.dashDirZ * reach + a.vf * K * rem * velK;
        const om = Math.hypot(ox, oz);
        const maxReach = 1.48;
        if (om > maxReach) {
          ox *= maxReach / om;
          oz *= maxReach / om;
        }
        tl = { x: ideal[i].x + ox, z: ideal[i].z + oz };
      } else if (f.gaitStep) {
        // land ahead of the hips by 0.6 of a stride: touch-down and toe-off are then symmetric about the hips,
        // so neither leg ever over-stretches. Step width stays close to hip width, like a person walking.
        // = half of the distance the hips travel while this foot is on the ground → symmetric about the hips for both walking and running
        const wW = lerp(0.84, 0.7, run) + a.dip * 0.12; // runners place their feet closer to the centre line
        tl = {
          x: dirx * half + pr.x * s * wW + a.vl * K * rem * 0.95,
          z: dirz * half + pr.z * s * wW + a.vf * K * rem * 0.95,
        };
        if (!this.gait) {
          // the gait ended mid-swing (the key was flicked): come down into the boxing stance instead of
          // finishing a full stride — this is what made a short tap look exaggerated
          const k = 0.78;
          tl.x = lerp(tl.x, ideal[i].x, k);
          tl.z = lerp(tl.z, ideal[i].z, k);
        }
      } else if (f.punchStep) {
        // strike re-plant: a short, flat, deliberate step onto the target the punch was thrown from
        tl = { x: f.tx, z: f.tz };
      } else if (f.aliStep) {
        // THE ALI SHUFFLE TAP: a light half-step out to the side of the stance and back — short, quick, low clearance
        tl = { x: f.tx, z: f.tz };
      } else {
        const moving = spdRaw > 0.45;
        // the slower the body travels, the smaller the shuffle: a light tap of A/D gets a nudge, not a lunge
        const over = moving ? clamp(0.14 + spd * 0.055, 0.14, 0.48) * (1 - this.tapT * 0.4) : 0;
        let ox = dirx * over + a.vl * rem * 0.8;
        let oz = dirz * over + a.vf * rem * 0.8;
        const om = Math.hypot(ox, oz);
        if (om > 1.2) {
          ox *= 1.2 / om;
          oz *= 1.2 / om;
        }
        tl = { x: ideal[i].x + ox, z: ideal[i].z + oz };
      }
      // keep daylight between the feet: a landing foot is pushed back to its own side of the stance, so the two
      // never cross or land on top of each other (that is what made the fast shuffles look sloppy)
      const other = this.feet[1 - i];
      if (!other.stepping) {
        const ol = toL(other.x, other.z);
        const sep = tl.x - ol.x;
        const minSep = 0.62;
        if (Math.abs(sep) < minSep) tl.x = ol.x + (i === 0 ? minSep : -minSep);
      }
      const tw = toW(tl.x, tl.z);
      // a foot cannot come down through the ropes: the plant stays inside the rope line
      tw.x = clamp(tw.x, -this.footLimit, this.footLimit);
      tw.z = clamp(tw.z, -this.footLimit, this.footLimit);
      // gait swings start and end with ~zero ground speed (no skidding on touch-down, no jerk at toe-off)
      const e = f.shuffle || f.aliStep ? sm(u) : f.gaitStep ? lerp(u, sm(u), 0.95) : lerp(sm(u), 1 - Math.pow(1 - u, 2), 0.55);
      // Interpolate in robot-local space so the foot moves actively WITH the moving body,
      // rather than lagging far behind at an old world coordinate stuck to the mat!
      const curLx = f.flx + (tl.x - f.flx) * e;
      const curLz = f.flz + (tl.z - f.flz) * e;
      const curW = toW(curLx, curLz);
      curW.x = clamp(curW.x, -this.footLimit, this.footLimit);
      curW.z = clamp(curW.z, -this.footLimit, this.footLimit);
      f.curX = curW.x;
      f.curZ = curW.z;
      const w = Math.sin(Math.PI * u);
      if (f.shuffle) {
        // Clean, athletic boxing shuffle with visible push-off and crisp clearance
        f.pitch = lerp(f.p0, restP[i] + 0.04 * w, sm(u));
        f.yawOff = lerp(f.yawOff, restYaw[i], 1 - Math.exp(-16 * dt));
        sway += -s * 0.05 * w;
      } else if (f.gaitStep) {
        // Dynamic boxing stride: push-off rolls onto the ball of the foot (heel up),
        // mid-swing clears the canvas cleanly, heel-strike lands softly into stance
        const swingPitch = u < 0.35 ? lerp(f.p0, toeP * 1.2, sm(u / 0.35)) : lerp(toeP * 1.2, landP, sm((u - 0.35) / 0.65));
        f.pitch = swingPitch;
        f.follow = u < 0.92 ? 0.30 * Math.pow(Math.sin(Math.PI * (u / 0.92)), 0.8) : 0;
        f.yawOff = lerp(f.yawOff, psi + toeOut[i], 1 - Math.exp(-16 * dt));
        sway += -s * 0.07 * w * (1 + run * 0.6); // quiet weight shift over the stance foot (no waddle)
        roll += -s * 0.028 * w * (1 + run * 0.8); // a whisper of pelvis drop on the swinging side
        swingW = Math.max(swingW, w);
      } else if (f.aliStep) {
        // the dance: a light toe-tap roll and a strong lateral weight rock (that rock is the shuffle's whole read)
        f.pitch = lerp(f.p0, restP[i] + 0.06 * w, sm(u));
        f.yawOff = lerp(f.yawOff, restYaw[i] * (1 - 0.3 * aliAmt), 1 - Math.exp(-18 * dt));
        // THE ROCK: the weight swings hard onto the foot that just landed and the hips swing with it. This is what
        // makes a shuffle read as a DANCE instead of as fidgeting, so it is deliberately not subtle.
        sway += -s * 0.22 * w;
        roll += s * 0.14 * w;
        yawS += -s * 0.1 * w;
      } else if (f.punchStep) {
        // Deliberate step-in: foot lifts with intent and plants authoritative power into the canvas
        f.pitch = lerp(f.p0, restP[i] + 0.05 * w, sm(u));
        f.yawOff = lerp(f.yawOff, restYaw[i] + (i === 1 ? -0.13 : 0.06) * w - this.punchYaw * w, 1 - Math.exp(-20 * dt));
        sway += -s * 0.05 * w;
      } else {
        f.pitch = lerp(f.p0, restP[i] + 0.04 * w, sm(u));
        f.yawOff = lerp(f.yawOff, restYaw[i] * (1 - 0.75 * sp01), 1 - Math.exp(-14 * dt));
        sway += -s * 0.055 * w;
        roll += s * 0.025 * w;
        yawS += -s * 0.04 * w * (a.vf >= 0 ? 1 : -1) * Math.min(1, Math.abs(a.vf) / 2);
      }
      if (u >= 1) {
        f.x = f.curX = tw.x;
        f.z = f.curZ = tw.z;
        f.stepping = false;
        f.stT = 0;
        f.follow = 0;
        // touch-down settles smoothly into flat grounded stance
        const settle = (target: number) => {
          f.pitch += clamp(target - f.pitch, -0.05, 0.05);
        };
        f.p0 = f.pitch; // the pitch this stance has to roll out of
        if (f.aliStep) {
          f.aliStep = false;
          settle(restP[i]);
          this.sLand.v -= 0.16; // a light tap, not a stamp — the canvas answers softly
        } else if (f.shuffle) {
          f.shuffle = false;
          settle(restP[i]);
          this.sLand.v -= 0.3;
        } else if (f.punchStep) {
          f.punchStep = false;
          settle(restP[i]);
          f.yawOff += i === 1 ? -0.05 : 0.02; // the pivot leaves a touch of turn behind; it eases out next stance
          this.sLand.v -= 0.24 + spd * 0.12; // the fist lands on the same beat as the foot
        } else if (f.gaitStep) {
          settle(landP); // heel strike (walk) / mid-foot strike (run)
          this.sLand.v -= 0.09 + spd * 0.05 + run * 0.3; // soft weight transfer; a sprint lands harder
        } else {
          settle(restP[i]);
          this.sLand.v -= 0.18 + spd * 0.12;
        }
        this.onStep?.(i, spd, f.x, f.z);
      }
    }
    this.storeFeetLocal(toL);
    // flight phase: both feet are in the air (only possible while running)
    let flight = 0;
    if (this.feet[0].stepping && this.feet[1].stepping) flight = Math.min(Math.sin(Math.PI * this.feet[0].u), Math.sin(Math.PI * this.feet[1].u));
    // Smooth, position-based gait signals. They are functions of where the feet actually are, so they stay clean sine-like
    // curves even while the two swings overlap (the old per-swing "humps" stacked up and made the arms / hips twitch).
    const l0 = toL(this.feet[0].curX, this.feet[0].curZ);
    const l1 = toL(this.feet[1].curX, this.feet[1].curZ);
    // +1 when foot 0 is a full stride ahead of foot 1, −1 the other way round; faded in with the gait mode
    const zD = clamp((l0.z - l1.z) / (2 * half), -1, 1) * this.gaitW;
    // the hip on the side whose foot is forward turns forward; the chest counter-rotates (see animate)
    const gaitYaw = -0.065 * (1 + run * 1.2) * zD;
    // how deep into its stance the planted foot is (0 at touch-down / toe-off, 1 in mid-stance): drives the run bob
    let depth = 0;
    if (this.gait && !this.dashOn) {
      for (let i = 0; i < 2; i++) {
        if (this.feet[i].stepping) continue;
        const li = i === 0 ? l0 : l1;
        const ahead = li.x * dirx + li.z * dirz;
        depth = Math.max(depth, Math.sin(Math.PI * clamp((half - ahead) / (2 * half), 0, 1)));
      }
    }
    return { sway, roll, yaw: yawS + gaitYaw, bob, swing: swingW, arm: zD, flight, run, depth };
  }

  private storeFeetLocal(toL: (wx: number, wz: number) => { x: number; z: number }) {
    const zm = this.root.userData.zeusMetrics as ZeusRigMetrics | undefined;
    const ankleH = zm ? zm.ANKLE_H : ANKLE_H;
    for (let i = 0; i < 2; i++) {
      const f = this.feet[i];
      const l = toL(f.curX, f.curZ);
      this.feetL[i].x = l.x;
      this.feetL[i].z = l.z;
      this.feetL[i].y = ankleH + ankleLift(f.pitch) + (f.stepping ? swingArc(f.u) * f.lift : 0);
    }
  }

  animate(a: AnimState, dt: number) {
    const t = a.time;
    const S = this.root.scale.x;
    const yaw = this.root.rotation.y;
    const e = clamp(a.fall, 0, 1.06);
    // ---- GET-UP STAGING (poses.ts owns the curves) ----
    // The knock-down is one solid pose; the rise is not. The legs come back under the body first (the hips lead
    // the push), the torso is the last part of the lie to leave the canvas, and the whole thing rolls onto one
    // shoulder on the way through — so `e` is no longer used raw, it is split into a leg weight and a torso
    // weight with the stage curves on top. Both weights are exactly zero at rise = 1, which is what lets the
    // game drop the get-up and hand the body straight back to the ordinary standing rig without a pop.
    const riseU = clamp(a.rise ?? 0, 0, 1);
    const riseDir = (a.riseDir ?? 1) < 0 ? -1 : 1;
    const rs = riseStages(riseU);
    const riseOut = clamp(a.riseOut ?? 0, 0, 1);
    // The legs are the LAST thing the standing rig gets back. While he is on the canvas they are posed by hand
    // (the knee tuck / the kneel below) and the IK only takes them over as he drives up out of the crouch, which
    // is what stops the old behaviour: boots snapped onto lying positions while the body climbed over them.
    const eIk = clamp(e * (1 - rs.legs), 0, 1.06);
    const eSpan = clamp(e * (1 - rs.unroll) * (1 - rs.hipUp * 0.3), 0, 1.06); // the torso unfolds late, and softly
    // the collapse is staged on the torso weight: knees first, hips, THEN the torso goes over (see poses.ts)
    const fs = fallStages(eSpan);
    const layE = fs.lay * 1.42; // the lie: 81° back and rolled onto one shoulder (not a flat 90° plank)
    const lieSide = fs.side * (1 - rs.side) * riseDir; // a little onto the shoulder he will get up over
    // THE ACCORDION (anti-plank): the hips go over first and the UPPER body trails them on a slower clock — the
    // chest is still a little upright while the pelvis is already past halfway. That articulated lag is what makes
    // a fall read as a body collapsing instead of a stiff log tipping about its hips. The term dies to zero the
    // moment the lay settles (and stays zero through the get-up), so nothing pops at the handover.
    const layLagS = this.sLayLag.update(fs.lay, 6.0, 0.72, dt);
    const layTrail = Math.max(0, fs.lay - layLagS) * (1 - rs.unroll);
    // the head is the last thing to hit: as the torso arrives on the canvas the neck whips and shoulders bounce
    if (this.prevLay < 0.75 && fs.lay >= 0.75 && (a.rise === undefined || riseU <= 0.001)) {
      // the head WHIPS DOWN into the canvas (negative = toward the mat) and the spring rebounds it back up —
      // a real neck snap, not the old "pop the chin up at the moment of impact"
      this.sHeadX.v += -11.5;
      this.sHeadZ.v += 3.2 * riseDir;
      this.sHeadY.v += 2.0 * riseDir;
      this.sMass.v += 1.1;
      this.sRoll.v += 1.4 * riseDir;
      this.sLean.v -= 1.6;
      for (const sp of this.sShoulderLag) sp.v += 4.5;
    }
    this.prevLay = fs.lay;
    // ...and it does not unwind straight to zero: it passes through a deep forward fold, chest over the knees,
    // which is the shape a real stand-up has. `fold` peaks around two thirds of the way up and is gone at both ends.
    const eFold = rs.fold * 0.62 * (0.55 + 0.45 * (1 - eSpan));
    // ON THE FLOOR THE LEGS GO BACK TO THE IK. The boots are sitting on the canvas, so solving the legs from them
    // is what gives a real knock-down pose: the knees fold exactly as far as the lie needs, the boots stay ON the
    // mat, and nothing has to be guessed by hand — the game's get-up footwork then just walks the feet back under
    // him and the legs follow their own bones. (FK is for the AIRBORNE flail, where nothing touches the floor.)
    const ikTarget = a.rise !== undefined ? 1 : (1 - clamp(a.air, 0, 1)) * (1 - sm(Math.min(1, eIk * 1.8)));
    this.ikW += (ikTarget - this.ikW) * (1 - Math.exp(-(ikTarget > this.ikW ? 5 : 14) * dt));
    const ik = this.ikW;
    this.airW += (clamp(a.air, 0, 1) - this.airW) * (1 - Math.exp(-11 * dt));
    if (ik < 0.4) this.needSnap = true;

    // direction of travel relative to the facing: legs/hips turn to it, chest stays on the opponent
    const spdNow = Math.hypot(a.vf, a.vl);
    const ang = Math.atan2(a.vl, a.vf);
    let psiT = 0;
    if (spdNow > 0.7 && ik > 0.6) {
      if (this.back) {
        if (Math.abs(ang) < 1.75) this.back = false;
      } else if (Math.abs(ang) > 2.05) this.back = true;
      psiT = this.back ? clamp(Math.atan2(-a.vl, -a.vf), -1.0, 1.0) : clamp(ang, -1.2, 1.2);
    }
    if (a.dash > 0.5) psiT *= 0.22; // pros keep the hips square while shuffling
    const psi = this.sPsi.update(psiT, a.dash > 0.5 ? 9 : 4.6, 0.9, dt);

    const fw = this.updateFeet(a, dt, S, yaw, psi);
    this.runW = fw.run; // already low-pass filtered in updateFeet — filtering twice only added lag
    const rw = this.runW;
    const land = this.sLand.update(0, 5.2, 0.38, dt);

    // ---------------- inertia springs ----------------
    // forward lean grows with speed → the body "leads" the legs like a person walking with intent
    // (the lean is shared between body, waist and chest, so each share must stay small: a sprint now leans ~24° in total,
    //  it used to add up to ~55°, which is what made the run look hunched and "wrong")
    // (the springs sit a touch under critical damping: tonnes of steel overshoot and SETTLE when they start, stop
    //  or cut — the position itself never lags, only the mass on top of it)
    const leanA = this.sLean.update(clamp(a.af * 0.011 + a.vf * 0.017 + rw * 0.05, -0.3, 0.34), 2.4, 0.6, dt);
    const rollA = this.sRoll.update(-clamp(a.al * 0.009 + a.vl * 0.01, -0.22, 0.22), 2.1, 0.6, dt);
    // the hips sink under any hard acceleration (a launch, a stop, a sidestep) and bounce back once — suspension
    const massDip = this.sMass.update(clamp(Math.abs(a.af) * 0.0055 + Math.abs(a.al) * 0.0035, 0, 0.13) * (1 - a.air), 3.2, 0.5, dt);
    const sway = this.sSway.update(fw.sway, 7, 0.8, dt);
    const lag = -clamp(a.yawRate * 0.07, -0.4, 0.4); // chest trails the turn

    // ---------------- HIT REACTION: built from the real geometry of the punch ----------------
    // Every link of the chain takes the blow from the same place, but each one takes a bigger share than the one
    // below it: the pelvis rotates a little, the chest turns more, the head snaps. `hitSnap` (0…1) is how much of
    // the blow landed on the head — a head shot whips the neck, a body shot folds the chest and lets the head
    // trail after it (the springs do the whiplash for free).
    const hMag = a.hit;
    const hF = clamp(a.hitF ?? -1, -1.4, 1.4);
    const hL = clamp(a.hitL ?? 0, -1.4, 1.4);
    const hPt = clamp(a.hitPt ?? 0.5, 0, 1);
    const hSp = clamp(a.hitSpin ?? hL, -2.4, 2.4);
    const hUp = a.hitUp;
    // one signed term per axis: knocked back / lifted / turned (HK keeps a full-power blow to a readable snap —
    // the chain below adds up, so a single link must stay small)
    const HK = 0.17;
    const stdPitch = (hF * 0.6 - hUp * 0.42) * hMag * HK;
    const stdRoll = -hL * 0.52 * hMag * HK;
    const stdYaw = hSp * 0.4 * hMag * HK;

    const snapOn = !!a.directionalHeadSnap;
    const kind = a.hitKind || 'standard';
    const isHitting = hMag > 0.005;
    const isJab = snapOn && isHitting && kind === 'jab';
    const isHook = snapOn && isHitting && kind === 'hook';
    const isUpper = snapOn && isHitting && kind === 'upper';

    // Track new punch hit sequence
    if (snapOn && a.hitSeq !== undefined && a.hitSeq !== this.lastHitSeq && a.hit > 0.05) {
      this.lastHitSeq = a.hitSeq;
      if (isHook) {
        this.hookDelayTimer = 0.075; // 75ms delayed torso follow-through
        const hookDir = (a.hitSpin && Math.abs(a.hitSpin) > 0.05) ? Math.sign(a.hitSpin) : (a.hitArm === 0 ? 1 : -1);
        this.hookSide = hookDir;
      } else if (isUpper) {
        this.sUpperLift.v = 2.4 + a.hit * 2.8; // Uppercut upward kinetic impulse
      }
    }

    // Delayed torso follow-through for hook
    let delayedTorsoYaw = 0;
    if (snapOn && isHook) {
      if (this.hookDelayTimer > 0) {
        this.hookDelayTimer -= dt;
      }
      const hookFollowTarget = (this.hookDelayTimer <= 0 && isHitting) ? this.hookSide * hMag * (0.42 + hMag * 0.35) * (0.3 + hPt * 0.7) : 0;
      delayedTorsoYaw = this.sDelayedTorsoYaw.update(hookFollowTarget, 9.5, 0.75, dt);
    } else {
      this.hookDelayTimer = 0;
      this.sDelayedTorsoYaw.update(0, 12, 0.8, dt);
    }

    let hPitch = stdPitch;
    let hRoll = stdRoll;
    let hYaw = stdYaw;
    let tw = a.twist + hYaw * 1.05;

    if (snapOn) {
      if (isJab) {
        // JAB: ZERO sideways rotation on head/torso, only straight recoil
        hYaw = 0;
        hRoll = 0;
        tw = a.twist;
      } else if (isHook) {
        // HOOK: Torso follows through after a slight delay
        tw = a.twist + delayedTorsoYaw;
      } else if (isUpper) {
        // UPPERCUT: Vertical impulse, no sideways twist
        hYaw = 0;
        hRoll = 0;
        tw = a.twist;
      }
    }

    const pY = this.sPelvisYaw.update(tw * 0.4, 12, 0.8, dt);
    // stride-driven pelvis motion goes through its own slow springs → rolling, continuous motion (no twitching)
    const gy = this.sGaitYaw.update(fw.yaw, 6.5, 0.85, dt);
    const gr = this.sGaitRoll.update(fw.roll, 7, 0.85, dt);
    const armW = this.sArm.update(fw.arm, 8, 0.8, dt);
    this.stride.arm = armW;
    this.stride.swing = fw.swing;
    const wY = this.sWaistYaw.update(tw * 0.3, 9, 0.75, dt);
    const cY = this.sChestYaw.update(tw * 0.3 + lag, 7.5, 0.62, dt);
    const pelvisYaw = pY + gy + psi;

    // ---------------- body & spine ----------------
    const gw = this.gaitW;
    const bodyX = sway;
    const bodyZ = a.lunge * 0.55 + hF * hMag * 0.5; // the hips ride back with the blow (or fold in on a body shot)
    // desired hip height: relaxed knees standing; walking is a touch taller and rises on single support
    // walking: the hips sink a little at double support (touch-down) and rise smoothly over the stance leg.
    // The height follows the stride phase directly, so it is a clean sine-like bob, not a reach-limited kink.
    const zm = this.root.userData.zeusMetrics as ZeusRigMetrics | undefined;
    const l1 = zm ? zm.L1 : L1;
    const l2 = zm ? zm.L2 : L2;
    const ankleH = zm ? zm.ANKLE_H : ANKLE_H;
    const standY = zm ? zm.STAND_Y : STAND_Y;
    const hipX = zm ? zm.hipX : 0.76;
    const sw2 = fw.swing * fw.swing;
    // running: the body sinks into each stride (knees absorb the landing) and springs up during the flight phase
    const walkBob = (-0.09 + 0.14 * sw2) * (zm ? (zm.L1 + zm.L2) / (L1 + L2) : 1); // fluent but quiet: enough weight transfer to read as a walk, never bouncy (scaled for big chassis)
    const baseHd = clamp(standY - a.dip * (zm ? 0.85 : 1.15), 1.6 + UP * 0.6, zm ? standY + 0.12 : 3.42 + UP);
    // running: the knees stay bent; the hips are lowest in mid-stance and rise gently towards touch-down / toe-off / flight.
    // `depth` is a smooth sine of the stance progress, so the bob is a clean ~6% wave (the old version spiked by 25%).
    const runHd = (zm ? standY - 0.62 : RUN_HIP_LOW) + RUN_HIP_BOB * (1 - fw.depth);
    const hd = lerp(baseHd + gw * walkBob, runHd, rw) - massDip - fs.buckle * 0.95; // the knees give way under a knock-down
    // never ask a leg to stretch further than it can reach
    let cap = 9;
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      const hx = bodyX + s * hipX * Math.cos(pelvisYaw);
      const hz = bodyZ - s * hipX * Math.sin(pelvisYaw);
      const hd2 = Math.hypot(this.feetL[i].x - hx, this.feetL[i].z - hz);
      const R = (l1 + l2) * (zm ? 0.992 : 0.972);
      cap = Math.min(cap, Math.sqrt(Math.max(0.01, R * R - hd2 * hd2)) + this.feetL[i].y);
    }
    // soft limit: the reach cap can no longer introduce a kink in the vertical motion
    const hipH = this.sHip.update(softMin(hd, cap, 0.12), rw > 0.3 ? 17 : this.dashOn || gw > 0.5 ? 10 : 15, 0.9, dt);
    const yIK = hipH - HIP_Y - UP + a.hitUp * 0.42 - Math.max(0, -hF) * hMag * 0.16;
    const tipE = clamp(fs.lay + a.tilt / 1.5, 0, 1.06);
    // Height of the body pivot while he is on the canvas. It is deliberately LOW: the floor solver (groundSolve)
    // then lifts the body by exactly the amount its lowest surface needs, so he really rests ON the canvas instead
    // of hanging above it. (It used to ask for 0.78, which left the whole torso floating ~0.7 above the floor,
    // propped up on one boot — that was a large part of why the knock-down and the get-up looked wrong.)
    const yFall = lerp(0.04, 0.2, sm(Math.min(1, tipE)));
    // ---- the staged rise, layered on top of the lie ----
    // `side` peaks about a third of the way in: he rolls off his back onto one shoulder, the hips slide across over
    // the planted hand, the body drifts forward over the knees, and the last beat dips so the rise LANDS.
    const riseX = riseDir * 0.34 * rs.side;
    // every staged term below is scaled to vanish at BOTH ends of the rise (a term that survived to rise = 1 would
    // pop out of the pose the instant the game hands the body back to the ordinary rig)
    const riseZ = rs.tuck * 0.12 + (rs.fold + rs.kneel) * 0.11 - rs.tall * 0.05 * (1 - riseU);
    const riseY = -rs.bounce * 0.18 - riseOut * 0.05;
    // turning a lying body about its own spine reads exactly as the log-roll onto the side; as the pitch unwinds
    // the very same channel becomes the twist that squares him back up to the enemy
    const riseYaw = riseDir * 1.0 * rs.side + Math.sin(t * 7) * 0.03 * riseOut;
    const riseRoll = riseDir * 0.24 * rs.side;
    // the pivot height while he is on the floor: the hips climb on their own stage curve (they lead the whole
    // move), and only once he is upright does the standing rig's height take over (heightW → ik).
    // KNOCKED FLYING (ragdoll): the hips stay up at standing height with the legs hanging under them, so the boots
    // reach the canvas first and the collapse starts from a body on its feet (knees give → hips drop → torso over).
    // Without this the pivot sat at the root and the whole machine arrived on the mat already flat.
    const ragW = clamp(a.ragdoll ?? 0, 0, 1);
    this.ragW += (ragW - this.ragW) * (1 - Math.exp(-(ragW > this.ragW ? 14 : 6) * dt));
    const heightW =
      a.rise !== undefined && riseU > 0.001
        ? rs.hipUp
        : a.rise !== undefined
          ? rs.hipUp * sm(fs.lay) + (1 - sm(fs.lay))
          : Math.max(ik, this.ragW, 1 - sm(fs.lay)) * (1 - sm(fs.lay));
    this.dashW += ((a.dash > 0.05 ? a.dash : 0) - this.dashW) * (1 - Math.exp(-14 * dt));
    const dodgeFlow = this.dashW;
    const slipRoll = a.rise === undefined && e < 0.05 ? a.roll : 0;
    const slipLean = a.rise === undefined && e < 0.05 ? a.lean - 0.08 : 0;

    let upperLiftY = 0;
    if (snapOn && isUpper) {
      const uLift = this.sUpperLift.update(0, 9.2, 0.72, dt);
      upperLiftY = clamp(uLift, 0, 0.55);
    } else {
      this.sUpperLift.update(0, 14, 0.85, dt);
    }

    this.body.position.set(
      bodyX + riseX + slipRoll * (0.28 + 0.16 * dodgeFlow),
      lerp(yFall, yIK + fw.bob + land, heightW) + riseY + upperLiftY,
      bodyZ + riseZ + slipLean * 0.16 * dodgeFlow,
    );
    this.body.rotation.set(
      a.lean * 0.3 + leanA * 0.4 + hPitch * 0.4 - layE + eFold - a.tilt - upperLiftY * 0.35 + fs.slam * 0.13 * (1 - rs.unroll),
      riseYaw + lieSide * 0.32 - riseDir * 0.16 * fs.buckle * (1 - rs.unroll), // fluid torsional rotation during buckle and roll
      (a.roll - slipRoll * 0.42) + rollA * 0.5 + hRoll * 0.45 + riseRoll - (a.tiltZ ?? 0) + lieSide * 0.22 * (1 - rs.unroll) + riseDir * 0.10 * fs.slam * (1 - rs.unroll),
    );
    // Living respiratory heave: rhythmic chest expansion & compression (~3.9s cycle)
    const breathe = Math.sin(t * 1.6) * 0.038;
    // Core spinal dynamics: kurvatura tulang belakang luwes saat jatuh (buckle & shock absorption) dan melengkung ke depan saat bangkit (eFold)
    const spineFallCurl = fs.buckle * 0.36 - fs.slam * 0.12;
    const spineImpactDecompress = fs.lay * 0.08 + fs.slam * 0.10;
    const spineFold = eFold * 0.28;
    const spineFallRoll = lieSide * 0.24 * (1 - rs.unroll);
    const spineFallYaw = riseDir * 0.16 * fs.side * (1 - rs.unroll);

    this.pelvis.rotation.set(
      a.lean * 0.06 - spineFallCurl * 0.25 + spineFold * 0.1,
      pelvisYaw + spineFallYaw * 0.45,
      gr - slipRoll * 0.14 + spineFallRoll * 0.35,
    );
    this.waist.rotation.set(
      a.lean * 0.3 + leanA * 0.3 + hPitch * 0.28 + spineFallCurl * 0.85 - spineImpactDecompress + spineFold + layTrail * 0.5,
      wY - psi * 0.5 - gy * 0.7 + hYaw * 0.3 - spineFallYaw * 0.35,
      -gr * 0.6 + hRoll * 0.3 + slipRoll * 0.36 + spineFallRoll * 0.55,
    );
    this.chest.rotation.set(
      a.lean * 0.38 + leanA * 0.25 + breathe + 0.04 + hPitch * (0.3 + (1 - hPt) * 0.3) + spineFallCurl * 1.25 - spineImpactDecompress * 1.2 + spineFold * 1.2 + layTrail * 0.95,
      cY - psi * 0.4 - gy * 0.8 + hYaw * 0.55 + spineFallYaw * 0.75,
      -rollA * 0.3 - gr * 0.4 + hRoll * 0.3 + slipRoll * 0.52 + spineFallRoll * 0.75,
    );

    // head: lags the chest and counter-rotates to keep eyes on the opponent, and flows smoothly with head-slips/weaves
    // ...and during the fall the heavy head HOLDS UP (the neck trails the collapsing torso — the accordion lag),
    // then WHIPS DOWN into the canvas at impact and rebounds off it. (The old signs did the opposite: the head
    // dived ahead of the body and popped its chin up at the slam — that was a big part of the "weird" read.)
    const headHold = layTrail * 0.9;
    const headWhip = -fs.slam * 0.34 * (1 - rs.unroll);
    // the neck stiffens through the impact beat so the whip is actually FELT instead of filtered out
    // by a soft spring — then it goes limp again for the settle
    const whipStiff = 1 + fs.slam * 1.7 * (1 - rs.unroll);
    const headFallRoll = riseDir * 0.22 * fs.side * (1 - rs.side);
    const headFallYaw = riseDir * 0.28 * fs.side * (1 - rs.side);

    // ...and during the get-up the head leads the whole move: chin tucked while he is flat, lifted early so he is
    // already looking at you before the torso arrives, then a small nod as he settles into the stance.
    const hRise =
      rs.head * 0.42 // the head comes up off the chest FIRST (before the hips, before the torso)
      + eSpan * 0.3 - rs.hipUp * 0.34 * (1 - rs.unroll) - eFold * 0.55 + rs.bounce * 0.1
      - riseOut * 0.06 * Math.sin(t * 11);

    const baseHeadX = 0.02 - a.lean * 0.52 + hRise - leanA * 0.28 + headHold + headWhip;
    let hx: number;
    let hy: number;
    let hz: number;
    let neckShare = 0.45;
    let headShare = 0.55;

    if (!snapOn || !isHitting) {
      // Standar atau Idle: gunakan animasi hit/head reaction standar yang natural
      const hSnap = 0.25 + hPt * 1.15;
      const headHz = lerp(4.8, 11.8, dodgeFlow) * whipStiff;
      hx = this.sHeadX.update(baseHeadX + hPitch * hSnap - hUp * 0.3 * hMag, headHz, 0.52, dt);
      hy = this.sHeadY.update(-a.twist * 0.72 - lag * 0.5 + hYaw * (0.6 + hPt * 0.9) + (a.headYaw ?? 0) + headFallYaw, headHz, 0.55, dt);
      hz = this.sHeadZ.update(-rollA * 0.4 + hRoll * (0.4 + hPt * 0.8) + slipRoll * 0.58 + headFallRoll, headHz, 0.55, dt);
    } else if (isJab) {
      // 1. JAB:
      // Kepala lawan terdorong/tersentak lurus ke belakang.
      // Gerakan harus cepat dan tajam.
      // Jangan membuat kepala berputar ke samping.
      // Setelah impact, kepala kembali secara natural ke posisi normal.
      const jabSnapPitch = - hMag * (0.38 + hMag * 0.36) * (0.5 + hPt * 0.5);
      const targetHeadX = baseHeadX + jabSnapPitch;
      const jabHz = 24.0;
      const jabDamp = 0.72;
      hx = this.sHeadX.update(targetHeadX, jabHz, jabDamp, dt);
      // Strictly zero sideways rotation:
      hy = this.sHeadY.update(-a.twist * 0.72 - lag * 0.5 + (a.headYaw ?? 0), jabHz, 0.75, dt);
      hz = this.sHeadZ.update(-rollA * 0.4 + slipRoll * 0.58, jabHz, 0.75, dt);
      neckShare = 0.48;
      headShare = 0.52;
    } else if (isHook) {
      // 2. HOOK:
      // Kepala lawan terpelintir cepat ke arah samping sesuai sisi hook.
      // Tambahkan sedikit delayed torso follow-through:
      // Kepala bergerak terlebih dahulu. Torso mengikuti sepersekian detik kemudian.
      // Efek harus terasa seperti leher terkena momentum pukulan, bukan seluruh tubuh bergerak bersamaan.
      const hookHeadYaw = this.hookSide * hMag * (0.72 + hMag * 0.54) * (0.45 + hPt * 0.55);
      const hookHeadRoll = -this.hookSide * hMag * (0.18 + hMag * 0.16) * (0.45 + hPt * 0.55);
      const hookSnapPitch = - hMag * (0.08 + hMag * 0.12);
      const hookHz = 22.0;
      const hookDamp = 0.68;
      hx = this.sHeadX.update(baseHeadX + hookSnapPitch, hookHz, hookDamp, dt);
      hy = this.sHeadY.update(-a.twist * 0.72 - lag * 0.5 + hookHeadYaw + (a.headYaw ?? 0), hookHz, hookDamp, dt);
      hz = this.sHeadZ.update(-rollA * 0.4 + hookHeadRoll + slipRoll * 0.58, hookHz, hookDamp, dt);
      neckShare = 0.40;
      headShare = 0.60;
    } else if (isUpper) {
      // 3. UPPERCUT:
      // Dagu/kepala lawan tersentak ke atas.
      // Kepala sedikit menengadah.
      // Badan ikut terdorong/terangkat sedikit mengikuti momentum uppercut.
      // Gerakan harus terasa seperti pukulan benar-benar mengangkat target.
      const upperSnapPitch = - hMag * (0.55 + hMag * 0.48) * (0.5 + hPt * 0.5);
      const upperHz = 20.0;
      const upperDamp = 0.68;
      hx = this.sHeadX.update(baseHeadX + upperSnapPitch, upperHz, upperDamp, dt);
      hy = this.sHeadY.update(-a.twist * 0.72 - lag * 0.5 + (a.headYaw ?? 0), upperHz, 0.75, dt);
      hz = this.sHeadZ.update(-rollA * 0.4 + slipRoll * 0.58, upperHz, 0.75, dt);
      neckShare = 0.42;
      headShare = 0.58;
    } else if (kind === 'cross') {
      const crossSnapPitch = - hMag * (0.36 + hMag * 0.40) * (0.45 + hPt * 0.55);
      const crossHz = 19.0;
      hx = this.sHeadX.update(baseHeadX + crossSnapPitch, crossHz, 0.70, dt);
      hy = this.sHeadY.update(-a.twist * 0.72 - lag * 0.5 + hYaw * 0.4 + (a.headYaw ?? 0), crossHz, 0.75, dt);
      hz = this.sHeadZ.update(-rollA * 0.4 + hRoll * 0.4 + slipRoll * 0.58, crossHz, 0.75, dt);
      neckShare = 0.45;
      headShare = 0.55;
    } else {
      const hSnap = 0.25 + hPt * 1.15;
      const headHz = lerp(4.8, 11.8, dodgeFlow) * whipStiff;
      hx = this.sHeadX.update(baseHeadX + hPitch * hSnap - hUp * 0.3 * hMag, headHz, 0.52, dt);
      hy = this.sHeadY.update(-a.twist * 0.72 - lag * 0.5 + hYaw * (0.6 + hPt * 0.9) + (a.headYaw ?? 0), headHz, 0.55, dt);
      hz = this.sHeadZ.update(-rollA * 0.4 + hRoll * (0.4 + hPt * 0.8) + slipRoll * 0.58, headHz, 0.55, dt);
    }

    this.neck.rotation.set(hx * neckShare, hy * neckShare, hz * neckShare);
    this.head.rotation.set(hx * headShare, hy * headShare, hz * headShare);

    // ---------------- ocular motion & eye effects ----------------
    if (this.eyePupils.length > 0 || this.eyePulses.length > 0) { // the brute head has the optics but no pupils
      // 0. STRIKE OPTICS. `strike` ramps 0 → 1 as the fist leaves the guard; the crossing fires a one-shot:
      //    the pupils snap narrow, the iris blows out white, a lock-on ring pops off the socket and a light
      //    streak stretches forward with the throw. Then everything settles back into the idle shimmer.
      const ch = clamp(a.strike ?? 0, 0, 1);
      const sp = clamp(a.strikePow ?? 0.5, 0, 1);
      if (ch >= 1 && this.strikeCharge < 1) this.eyeFire = 1;
      this.strikeCharge = ch;
      this.eyeFire = Math.max(0, this.eyeFire - dt / (0.22 + sp * 0.18));
      const fire = this.eyeFire * this.eyeFire * (3 - 2 * this.eyeFire); // smooth 1 → 0 envelope
      const heat = clamp(fire * (0.55 + sp * 0.8), 0, 1);
      const charge = ch * (1 - fire); // charging (wind-up) weight

      // 1. Target gaze tracking: if lookX/lookY provided, track towards target; otherwise autonomous cybernetic saccades
      const scanPhase = t * 1.5;
      const saccadeT = t * 2.4;
      const dartX = (Math.sin(saccadeT * 1.7) > 0.65 ? 0.016 : -0.012) * (Math.sin(saccadeT * 0.7) > 0.15 ? 1 : 0);
      const wanderX = Math.sin(scanPhase * 0.7) * 0.012 + Math.sin(scanPhase * 1.9) * 0.007;
      const wanderY = Math.cos(scanPhase * 0.5) * 0.006;
      // while a punch is being thrown the darting stops: the machine locks on
      const lock = 1 - clamp(charge + fire, 0, 1);

      const targetLookX = (a.lookX ?? 0) * 0.03 + (wanderX + dartX) * lock;
      const targetLookY = (a.lookY ?? 0) * 0.018 + wanderY * lock;

      // Spring-damped eye look position
      this.eyeLookX += (targetLookX - this.eyeLookX) * Math.min(1, 16 * dt);
      this.eyeLookY += (targetLookY - this.eyeLookY) * Math.min(1, 16 * dt);

      // 2. Scanline sweep: a slow ranging sweep at rest; at the release it snaps into a fast lock sweep
      const scanY = Math.sin(t * 4.5) * 0.035 * (1 - fire) + Math.sin(t * 52) * 0.026 * fire;

      // 3. Smooth ocular breathing: calm, steady optic luminescence (no rapid fluttering, strobe or twitching)
      const breathe = 0.94 + Math.sin(t * 1.5) * 0.06;
      let blink = 1.0;
      // Soft, occasional natural blink (every ~7 seconds, smoothly eased, not a sharp double strobe)
      const blinkCycle = (t * 0.14) % 1;
      if (blinkCycle < 0.02) {
        const u = blinkCycle / 0.02;
        blink = 0.4 + 0.6 * (0.5 - 0.5 * Math.cos(u * Math.PI * 2));
      }
      blink = lerp(blink, 1, clamp(charge + fire, 0, 1));

      const flareScaleX = (1.0 + Math.sin(t * 1.5) * 0.08 + Math.abs(this.eyeLookX) * 10) * blink * (1 + fire * (1.3 + sp * 2.8));
      const flareOpacity = clamp(0.55 + Math.sin(t * 1.5) * 0.1 + a.glow * 0.2 + heat * 0.5, 0.3, 1) * blink * breathe;

      for (let i = 0; i < this.eyePupils.length; i++) {
        const pupil = this.eyePupils[i];
        // a hard mechanical jitter right at the release, then dead still
        pupil.position.x = this.eyeLookX + Math.sin(t * 130) * 0.006 * fire;
        pupil.position.y = this.eyeLookY + Math.cos(t * 150) * 0.005 * fire;
        pupil.scale.set(1.0 - charge * 0.05 - fire * 0.12, blink * (1.0 - charge * 0.2 - fire * 0.42), 1.0);
      }

      for (let i = 0; i < this.eyeScanners.length; i++) {
        const scanner = this.eyeScanners[i];
        scanner.position.y = scanY;
        scanner.scale.set((0.9 + Math.sin(t * 8) * 0.1) * (1 + fire * 1.8), 1.0, 1.0);
        if (scanner.material instanceof THREE.MeshBasicMaterial) {
          scanner.material.opacity = clamp(0.32 + Math.sin(t * 5) * 0.22 + heat * 0.65, 0, 1);
        }
      }

      for (let i = 0; i < this.eyeFlares.length; i++) {
        const flare = this.eyeFlares[i];
        flare.scale.set(flareScaleX, blink * (1 + fire * 0.5), 1.0);
        if (flare.material instanceof THREE.MeshBasicMaterial) {
          flare.material.opacity = flareOpacity;
          flare.material.color.copy(this.eyeBase).lerp(this.eyeWhite, Math.min(1, heat * 0.85));
        }
      }

      // iris plate: dims while the punch charges, then flashes white on the release
      for (let i = 0; i < this.eyeIris.length; i++) {
        const iris = this.eyeIris[i];
        if (iris.material instanceof THREE.MeshBasicMaterial) {
          iris.material.color.copy(this.eyeBase).multiplyScalar(1 - charge * 0.4).lerp(this.eyeWhite, heat);
        }
      }

      // lock-on ring: pops out of the socket and fades on every punch
      for (let i = 0; i < this.eyePulses.length; i++) {
        const pulse = this.eyePulses[i];
        const u = 1 - this.eyeFire;
        pulse.scale.setScalar(0.5 + u * (1.6 + sp * 1.4));
        if (pulse.material instanceof THREE.MeshBasicMaterial) {
          pulse.material.opacity = fire * (0.3 + sp * 0.45);
          pulse.material.color.copy(this.eyeBase).lerp(this.eyeWhite, Math.min(1, heat * 1.1));
        }
      }

      // motion streak: a thin light ribbon off the socket that stretches forward with the throw
      for (let i = 0; i < this.eyeBeams.length; i++) {
        const beam = this.eyeBeams[i];
        if (beam.userData.z0 === undefined) beam.userData.z0 = beam.position.z;
        const len = 0.3 + fire * (0.7 + sp * 1.3);
        beam.scale.set(1, 1, len / 0.5);
        beam.position.z = (beam.userData.z0 as number) + len * 0.5;
        if (beam.material instanceof THREE.MeshBasicMaterial) {
          beam.material.opacity = fire * (0.22 + sp * 0.3);
          beam.material.color.copy(this.eyeBase).lerp(this.eyeWhite, Math.min(1, heat * 0.9));
        }
      }

      for (let i = 0; i < this.eyeLights.length; i++) {
        const light = this.eyeLights[i];
        light.intensity = (1.2 + Math.sin(t * 3.8) * 0.4 + a.glow * 0.4) * blink * (1 + heat * 2.6);
        if (heat > 0.01) light.color.copy(this.eyeBase).lerp(this.eyeWhite, Math.min(1, heat * 0.85));
        else light.color.copy(this.eyeBase);
      }
    }

    // ---------------- arms ----------------
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      const p = a.arms[i];
      const fwd = clamp(-p.sx / 1.7, 0, 1.2);
      const abd = clamp(p.sz, 0, 1.5);
      if (zm) {
        // On Zeus, the sculpted shoulder pauldron (cap) is anchored to the upper torso arch like ZeusViewer
        this.clavs[i].rotation.set(
          0,
          -s * (fwd * 0.05 + abd * 0.02) - slipRoll * 0.05 * dodgeFlow,
          s * (abd * 0.04 + fwd * 0.02) + slipRoll * 0.05 * dodgeFlow,
        );
        this.caps[i].rotation.set(0, 0, 0);
      } else {
        this.clavs[i].rotation.set(
          0,
          -s * (fwd * 0.32 + abd * 0.05) - slipRoll * 0.14 * dodgeFlow,
          s * (abd * 0.14 + fwd * 0.06) + slipRoll * 0.16 * dodgeFlow,
        );
        this.caps[i].rotation.set(p.sx * 0.38, 0, s * p.sz * 0.36);
      }
      const lagX = this.sShoulderLag[i].update(-leanA * 0.62, 4.2, 0.48, dt); // heavy arms trail the torso
      const swayA = Math.sin(t * 5.2 + i) * 0.025;
      // contralateral arm swing while walking (only when the arm is in its guard, so punches stay clean)
      const guardK = clamp((p.sx + 1.2) / 0.5, 0, 1);
      // Walking: the arm is carried, not hung — the shoulder drives it and the fist rides a touch higher as it comes
      // forward, so the swing reads as weight moving through him. Sprinting: big pumping arms (elbows bent ~100°).
      const swing = lerp(0.2, 0.95, rw) * s * armW * guardK;
      const drive = clamp(-s * armW * guardK, 0, 1); // how far forward this arm is in the stride
      const elbowDrive = -lerp(0.14, 0, rw) * drive; // ...the hand comes up on the forward half of the swing
      // the guard is knocked about by the blow: the arm on the side the fist lands on swings out, the other braces
      const flail = hMag * 0.1 * (0.35 + 0.65 * clamp(s * hL, 0, 1)) * (0.4 + hPt * 0.6);
      const zeusLatFlare = zm ? 0.05 : 0;
      this.shoulders[i].rotation.set(p.sx + swayA + lagX + swing - flail * 0.5, p.sy * s, (p.sz + zeusLatFlare + flail) * s);
      const ex = Math.min(0.02, p.ex + elbowDrive);
      this.elbows[i].rotation.x = ex;
      // wrist whips with forearm angular speed (follow-through)
      let target = 0;
      if (dt > 0) {
        const ev = (ex - this.prevEx[i]) / dt;
        target = clamp(-ev * 0.03, -0.6, 0.6);
        this.prevEx[i] = ex;
      }
      this.wrists[i].rotation.x = this.sWrist[i].update(target, 6, 0.35, dt);
    }

    // ---------------- legs: IK onto planted feet ----------------
    this.pelvis.updateWorldMatrix(true, false);
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      const f = this.feet[i];
      const hipPos = this.hipJ[i].position;
      const baseFootY = Math.max(this.floorY, this.root.position.y);
      this.tv.set(f.curX, baseFootY + S * (ankleH + ankleLift(f.pitch) + (f.stepping ? swingArc(f.u) * f.lift : 0)), f.curZ);
      this.tgtW.copy(this.tv);
      this.pelvis.worldToLocal(this.tv);
      const xt = this.tv.x - hipPos.x;
      const yt = this.tv.y - hipPos.y;
      const zt = this.tv.z - hipPos.z;
      const g = Math.atan2(xt, -yt);
      const y0 = -Math.hypot(xt, yt);
      const d = clamp(Math.hypot(zt, y0), Math.abs(l1 - l2) + 0.05, l1 + l2 - 0.015);
      const kx = Math.acos(clamp((d * d - l1 * l1 - l2 * l2) / (2 * l1 * l2), -1, 1));
      const phi = Math.atan2(-zt, -y0);
      const beta = Math.atan2(l2 * Math.sin(kx), l1 + l2 * Math.cos(kx));
      const ikHx = phi - beta;

      // FK pose used in the air / when knocked down
      const flail = Math.sin(t * 4.2 + i * Math.PI) * 0.14; // a slow drift of dead-weight legs, not a flap
      const am = this.airW;
      const flipTuck = clamp(a.tuck ?? 0, 0, 1) * am; // the flip: both knees up, both heels under the hips
      // A front flip is written with BOTH legs: as the knees come up, the dead-weight flail folds away with them, so
      // what the eye reads is one body turning over its own centre — never two legs doing their own thing mid-air.
      const airHx = lerp((i === 0 ? -0.58 : -0.18) + flail, -0.18 + flail * 0.35, flipTuck);
      const airKx = lerp((i === 0 ? 1.05 : 0.62) + flail * 0.5, 1.02 + flail * 0.35, flipTuck);
      // LYING LIMP: trigonometrically grounded for body pitch = -1.42 rad and y_hip ≈ 0.63 so neither knee nor boot
      // ever pokes below the canvas, while keeping an authentic asymmetric ragdoll posture (lead knee bent up with
      // its boot planted on the mat, trail leg relaxed and slightly bent on the canvas). During the knee-buckle phase
      // (fs.buckle), hip flexion (-0.62) and knee flexion (+1.24) follow the 1:2 kinematic ratio so the boots stay
      // right on the canvas as the hips drop!
      const lieLead = (riseDir > 0 ? 0 : 1) === i ? 1 : 0; // the leg on the side he lies towards
      const lieW = fs.side * (1 - rs.tuck) * (1 - rs.legs);
      const slamBounce = fs.slam * (1 - rs.tuck) * (1 - rs.legs);
      const buckleK = fs.buckle * 1.32 * (lieLead ? 1.12 : 0.88); // knees buckle dynamically under weight with organic asymmetry
      const buckleH = -fs.buckle * 0.66 * (lieLead ? 1.08 : 0.92); // hips sink in kinematic ratio with the knees
      const fallHx = 0.02 * s + buckleH - (0.68 * lieLead + 0.22 * (1 - lieLead) + 0.12 * slamBounce) * lieW;
      const fallKx = 0.14 + buckleK + (1.20 * lieLead + 0.20 * (1 - lieLead) + 0.18 * slamBounce) * lieW;
      // GET-UP: the legs are the load-bearing part of the whole move, and they are posed here by hand (the IK
      // does not get them back until he drives up out of the crouch). The LEAD leg — the one on the side he rolls
      // towards — folds hard, knee up over the boot, and stays under him; the TRAIL leg draws in behind it, its
      // shin lying on the canvas with him up on that knee. The `kneel` beat then rolls the weight onto the lead
      // foot: the trail hip extends, the lead hip drives over it — the push a real stand-up is built on.
      const tuckW = rs.tuck * (1 - ik);
      const kneelW = rs.kneel * (1 - ik);
      const lead = riseDir > 0 ? 0 : 1;
      const leadW = i === lead ? 1 : 0;
      const trailW = 1 - leadW;
      const fkHx = lerp(fallHx, airHx, am) - 1.25 * leadW * tuckW - 0.3 * leadW * kneelW + 0.4 * trailW * kneelW - (1.75 + airHx) * flipTuck;
      const fkKx = lerp(fallKx, airKx, am) + 2.0 * leadW * tuckW + 1.6 * trailW * tuckW + (2.25 - airKx) * flipTuck;
      const fkHz = lerp(s * (0.16 + 0.14 * lieLead * lieW + 0.08 * fs.buckle), s * 0.22, am) + s * 0.34 * tuckW;
      const hipFallYaw = s * (0.22 * lieLead + 0.12 * (1 - lieLead)) * (fs.buckle * 0.75 + lieW);
      const fkHy = lerp(hipFallYaw, 0, am);

      const hxF = lerp(fkHx, ikHx, ik);
      const kxF = lerp(fkKx, kx, ik);
      this.hipJ[i].rotation.set(hxF, lerp(fkHy, 0, ik), lerp(fkHz, g, ik));
      this.kneeJ[i].rotation.x = kxF;
      const fd = this.faulds[i];
      if (fd) fd.rotation.x = hxF * 0.55; // hip skirts are gone; keep working if one is ever added back
      this.kneeCaps[i].rotation.x = -kxF * 0.4;

      // keep the foot flat to the ground (with heel/toe roll while stepping)
      this.kneeJ[i].updateWorldMatrix(true, false);
      this.kneeJ[i].getWorldQuaternion(this.qk);
      this.qd.setFromEuler(this.eu.set(f.pitch, yaw + f.yawOff, 0, 'YXZ'));
      this.qf.copy(this.qk).invert().multiply(this.qd);
      if (f.follow > 0.001) {
        // mid-swing the foot stays level and natural with the shin
        this.qd.setFromEuler(this.eu.set(0.06, 0, 0, 'XYZ'));
        this.qf.slerp(this.qd, f.follow);
      }
      if (ik < 1) {
        // Off the feet (in the air, knocked down, getting up) the boot stops chasing the floor: it hangs off the
        // shin the way a relaxed foot does — toes up while he is down, pointed while he is in the air.
        this.qd.setFromEuler(this.eu.set(-0.22 + am * 0.48 + lieW * (lieLead ? 0.28 : 0.12), s * 0.12 * lieW, s * 0.16 * lieW, 'XYZ'));
        this.qf.slerp(this.qd, 1 - ik);
      }
      this.footJ[i].quaternion.copy(this.qf);
      this.footJ[i].updateWorldMatrix(true, false);
      this.footJ[i].getWorldPosition(this.tv);
      this.ikErr[i] = this.tv.distanceTo(this.tgtW) / S;
    }

    // last step: nothing may ever sink below the floor (falls, knock-downs, overshoot, odd poses)
    this.groundSolve(S, ik, a.rise !== undefined, dt, fs.lay > 0.15 || e > 0.22);

    const gl = (0.62 + Math.min(2.2, a.glow) * 0.42 + Math.sin(t * 3) * 0.08) * (1 - eSpan * 0.85);
    for (const m of this.glowMats) m.emissiveIntensity = gl;
    for (const m of this.bodyMats) m.emissiveIntensity = a.flash * 0.42;

    // Update Zeus group follower links if active (welded parts stay 100% matched to leader in real time)
    const zl = this.root.userData.zeusLinks as Array<{ f: THREE.Mesh; l: THREE.Mesh; off: THREE.Matrix4 }> | undefined;
    if (zl && zl.length > 0) {
      this.root.updateMatrixWorld(true);
      for (const lk of zl) {
        if (!lk.f.parent || !lk.l) continue;
        const M = lk.f.parent.matrixWorld.clone().invert().multiply(lk.l.matrixWorld).multiply(lk.off);
        const pos = new THREE.Vector3(), quat = new THREE.Quaternion(), scl = new THREE.Vector3();
        M.decompose(pos, quat, scl);
        lk.f.position.copy(pos);
        lk.f.quaternion.copy(quat);
        lk.f.scale.copy(scl);
      }
    }
  }
}
