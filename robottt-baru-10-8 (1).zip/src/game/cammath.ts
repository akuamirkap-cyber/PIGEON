import * as THREE from 'three';

export interface Frame {
  f: THREE.Vector3;
  r: THREE.Vector3;
  u: THREE.Vector3;
  tanV: number;
  aspect: number;
}

export function newFrame(): Frame {
  return { f: new THREE.Vector3(), r: new THREE.Vector3(), u: new THREE.Vector3(), tanV: 1, aspect: 1 };
}

export function aimFrame(frame: Frame, pos: THREE.Vector3, look: THREE.Vector3, fov: number, aspect: number) {
  frame.aspect = aspect;
  frame.tanV = Math.tan(THREE.MathUtils.degToRad(fov) * 0.5);
  frame.f.copy(look).sub(pos);
  const l = frame.f.length() || 1;
  frame.f.multiplyScalar(1 / l);
  frame.r.set(-frame.f.z, 0, frame.f.x).normalize();
  frame.u.crossVectors(frame.r, frame.f).normalize();
}

const pTmp = new THREE.Vector3();

export function spillPoint(frame: Frame, pos: THREE.Vector3, p: THREE.Vector3, pad: number) {
  pTmp.copy(p).sub(pos);
  const z = pTmp.dot(frame.f);
  if (z <= 0.25) return 3;
  const nx = (Math.abs(pTmp.dot(frame.r)) + pad) / (frame.tanV * z * frame.aspect);
  const ny = (Math.abs(pTmp.dot(frame.u)) + pad) / (frame.tanV * z);
  return Math.max(nx, ny);
}

export function spillMany(frame: Frame, pos: THREE.Vector3, pts: number[], pads: number[]) {
  let worst = 0;
  for (let i = 0; i < pads.length; i++) {
    pTmp.set(pts[i * 3], pts[i * 3 + 1], pts[i * 3 + 2]);
    const s = spillPoint(frame, pos, pTmp, pads[i]);
    if (s >= 3) return 3;
    if (s > worst) worst = s;
  }
  return worst;
}

export interface FighterLike {
  pos: { x: number; y: number };
  y: number;
  scale: number;
  state: string;

  fallS?: { x: number };

  vel?: { x: number; y: number };

  standH?: number;
}

const STAND_H = 6.6;
const FLOOR_H = 1.9;

export function fighterBox(pts: number[], pads: number[], fighters: FighterLike[]) {
  for (const f of fighters) {
    const s = f.scale;
    const standH = f.standH && f.standH > 0 ? f.standH : STAND_H;
    const flat = THREE.MathUtils.clamp(
      f.fallS ? f.fallS.x : f.state === 'ko' || f.state === 'down' ? 1 : 0,
      0,
      1,
    );
    const top = (standH - (standH - FLOOR_H) * flat) * s + f.y;
    pts.push(f.pos.x + 0.8 * s, top, f.pos.y, f.pos.x - 0.8 * s, top, f.pos.y);
    pads.push(0, 0);

    pts.push(f.pos.x, flat > 0.5 ? 0.12 : Math.max(0.12, f.y + 0.05), f.pos.y);
    pads.push(0);
  }
}

export function silhouetteSpill(
  frame: Frame,
  pos: THREE.Vector3,
  look: THREE.Vector3,
  fov: number,
  aspect: number,
  fighters: FighterLike[],
) {
  aimFrame(frame, pos, look, fov, aspect);
  const pts: number[] = [];
  const pads: number[] = [];
  fighterBox(pts, pads, fighters);
  return spillMany(frame, pos, pts, pads);
}

export function fitShot(
  frame: Frame,
  look: THREE.Vector3,
  dir: THREE.Vector3,
  fov: number,
  aspect: number,
  pts: number[],
  pads: number[],
  startD: number,
  maxD: number,
  out: THREE.Vector3,
): number {
  let d = startD;
  out.copy(dir).multiplyScalar(d).add(look);
  aimFrame(frame, out, look, fov, aspect);
  let spill = spillMany(frame, out, pts, pads);
  for (let i = 0; i < 8 && spill > 1 && d < maxD; i++) {
    d = Math.min(maxD, d * (1 + (spill - 1) * 0.85 + 0.05));
    out.copy(dir).multiplyScalar(d).add(look);
    aimFrame(frame, out, look, fov, aspect);
    spill = spillMany(frame, out, pts, pads);
  }
  return d;
}

export function reachAlong(look: THREE.Vector3, dir: THREE.Vector3, radius: number, yMin: number, yMax: number) {
  let limit = Infinity;
  const hx = look.x, hz = look.z;
  const dx = dir.x, dz = dir.z;
  const a = dx * dx + dz * dz;
  if (a > 1e-6) {
    const b = 2 * (hx * dx + hz * dz);
    const cq = hx * hx + hz * hz - radius * radius;
    const disc = b * b - 4 * a * cq;
    if (disc > 0) {
      const t1 = (-b + Math.sqrt(disc)) / (2 * a);
      if (t1 > 0) limit = Math.min(limit, t1);
    }
  }
  if (dir.y > 1e-4) limit = Math.min(limit, (yMax - look.y) / dir.y);
  if (dir.y < -1e-4) limit = Math.min(limit, (yMin - look.y) / dir.y);
  return Math.max(0.6, limit);
}

const UP = new THREE.Vector3(0, 1, 0);
const smooth = (t: number) => t * t * (3 - 2 * t);
const seg = (a: number, b: number, u: number) => smooth(THREE.MathUtils.clamp((u - a) / (b - a), 0, 1));

export const RIP_DUR = 3.9;

export interface RipOut {
  pos: THREE.Vector3;
  look: THREE.Vector3;
  dir: THREE.Vector3;
  fov: number;
  roll: number;

  blend: number;

  spill: number;

  push: number;
  phase: 'snap' | 'flight' | 'stump';
}

export function ripShot(
  out: RipOut,
  frame: Frame,
  t: number,
  head: THREE.Vector3,
  neck: THREE.Vector3,
  chest: THREE.Vector3,
  blow: THREE.Vector3,
  side: THREE.Vector3,
  scale: number,
  aspect: number,
  from: THREE.Vector3,
  fromLook: THREE.Vector3,
  reach: number,
  yMin: number,
  yMax: number,
) {
  const sc = THREE.MathUtils.clamp(scale, 0.6, 2);
  const gap = head.distanceTo(neck);
  const spread = Math.min(30, head.distanceTo(chest));
  const inA = seg(0, 0.3, t);
  const s12 = seg(0.3, 0.75, t);
  const s23 = seg(1.95, 2.5, t);
  const tail = seg(2.9, RIP_DUR, t);

  const f = flightShot(spread);
  const c = stumpShot(gap);

  const aLook = chest.clone().lerp(neck, 0.45).addScaledVector(UP, 0.25);
  const aDir = side.clone().multiplyScalar(0.8).addScaledVector(blow, -0.5).addScaledVector(UP, 0.22).normalize();
  const aD = 5.6 * sc;

  const bLook = head.clone().lerp(chest, 1 - f.wHead).addScaledVector(UP, 0.1);
  const bDir = side.clone().addScaledVector(blow, -f.back).addScaledVector(UP, f.rise / f.d).normalize();
  const bD = f.d;

  const cLook = neck.clone().lerp(head, c.wHead).addScaledVector(UP, 0.3);
  const cDir = side.clone().addScaledVector(blow, -c.back).addScaledVector(UP, c.rise / c.d).normalize();
  const cD = c.d;

  const look = aLook.lerp(bLook, s12).lerp(cLook, s23);
  const dir = aDir.lerp(bDir, s12).lerp(cDir, s23).normalize();
  out.fov = THREE.MathUtils.lerp(THREE.MathUtils.lerp(46, f.fov, s12), c.fov, s23);
  const wantD = THREE.MathUtils.lerp(THREE.MathUtils.lerp(aD, bD, s12), cD, s23);
  const ctl = 1 - inA;
  const wish = new THREE.Vector3()
    .copy(look)
    .addScaledVector(dir, wantD)
    .lerp(from, ctl);
  look.lerp(fromLook, ctl);
  dir.copy(wish).sub(look).normalize();

  const headW = 1 - s23;
  const full = [head.x, head.y + 0.15 * sc, head.z, neck.x, neck.y, neck.z, chest.x, chest.y, chest.z];
  const fullPads = [0.72 * sc, 0.78 * sc, 1.05 * sc];
  const body = [neck.x, neck.y, neck.z, chest.x, chest.y, chest.z];
  const bodyPads = [0.78 * sc, 1.05 * sc];
  const startD = Math.max(1.2, wish.distanceTo(look));
  const dMax = Math.min(26 * sc, reachAlong(look, dir, reach, yMin, yMax));
  const dFull = fitShot(frame, look, dir, out.fov, aspect, full, fullPads, startD, dMax, out.pos);
  const dBody = fitShot(frame, look, dir, out.fov, aspect, body, bodyPads, startD, dMax, out.pos);

  const d = THREE.MathUtils.lerp(dBody * 1.04, dFull * 1.09, headW);
  out.pos.copy(dir).multiplyScalar(d).add(look);
  out.push = d - startD;
  aimFrame(frame, out.pos, look, out.fov, aspect);
  out.spill = Math.max(spillMany(frame, out.pos, full, fullPads) * headW, spillMany(frame, out.pos, body, bodyPads));

  out.look.copy(look);
  out.dir.copy(dir);
  out.roll = 0.035 * (1 - tail) * Math.sin(t * 7.5);
  out.blend = tail;
  out.phase = s23 > 0.5 ? 'stump' : s12 > 0.5 ? 'flight' : 'snap';
}

export const CAM_MODES: CamMode[] = [
  {
    id: 'siaran',
    name: 'SIARAN',
    tag: 'TV',
    desc: 'Kamera siaran TV: jauh, tinggi, lensa panjang, sangat tenang. Kedua robot selalu kelihatan utuh dengan ruang lega — paling nyaman untuk membaca jarak.',
    fov: 46,
    dist: 12.6,
    minDist: 10.9,
    margin: 1.1,
    orbit: 0.22,
    height: 5.7,
    closeBias: 0.15,
    lookY: 3.0,
    down: 0.6,
    hand: 0.35,
    lead: 0.12,
    koScale: 1.35,
  },
  {
    id: 'aksi',
    name: 'AKSI',
    tag: 'CLASSIC',
    desc: 'Kamera aksi standar: ikut irama pertarungan, sedikit dari samping, dinamis — tapi tidak lagi mepet saat adu jotos jarak dekat.',
    fov: 56,
    dist: 10.6,
    minDist: 9.5,
    margin: 1.12,
    orbit: 0.44,
    height: 5.0,
    closeBias: 0.5,
    lookY: 3.05,
    down: 0.9,
    hand: 1.0,
    lead: 0.24,
    koScale: 1.05,
  },
  {
    id: 'dekat',
    name: 'DEKAT',
    tag: 'IMPACT',
    desc: 'Sedekat mungkin tanpa bikin pusing: setiap hantaman terasa di layar. Robot mengisi frame hampir penuh, kamera ikut goyang saat kena.',
    fov: 54,
    dist: 6.9,
    minDist: 6.4,
    margin: 1.05,
    orbit: 0.55,
    height: 4.5,
    closeBias: 0.55,
    lookY: 3.3,
    down: 1.1,
    hand: 1.35,
    lead: 0.3,
    koScale: 0.85,
  },
  {
    id: 'ring',
    name: 'RING LUAS',
    tag: 'TACTICAL',
    desc: 'Kamera luas dari atas ring: seluruh kanvas, tali, dan sudut terlihat. Paling enak untuk mengatur jarak dan melihat lawan bersiap.',
    fov: 68,
    dist: 17.5,
    minDist: 15.5,
    margin: 1.08,
    orbit: 0.34,
    height: 8.6,
    closeBias: 0,
    lookY: 2.7,
    down: 0.2,
    hand: 0.2,
    lead: 0.06,
    koScale: 1.6,
  },
  {
    id: 'pundak',
    name: 'PUNDAK',
    tag: 'IMMERSIVE',
    desc: 'Kamera di belakang pundak robotmu: melihat dari kacamata petarung, lawan tepat di depan mata. Paling seru untuk berburu kepala.',
    fov: 56,
    dist: 3.4,
    minDist: 3.0,
    margin: 1.1,
    orbit: 0.5,
    height: 5.2,
    closeBias: 0.35,
    lookY: 4.2,
    down: 0.9,
    hand: 0.8,
    lead: 0.2,
    koScale: 1.0,
    style: 'shoulder',
    ignoreSelf: true,
  },
  {

    id: 'star',
    name: 'STAR',
    tag: 'AUTO',
    desc: 'Kamera mode STAR: di belakang pundakmu, rendah dan dekat, lawan selalu di tengah frame. Paling nyaman untuk main cepat — dipakai otomatis oleh STAR MODE.',
    fov: 52,
    dist: 4.1,
    minDist: 3.4,
    margin: 1.06,
    orbit: 0.5,
    height: 4.5,
    closeBias: 0.22,
    lookY: 4.05,
    down: 0.75,
    hand: 0.6,
    lead: 0.16,
    koScale: 1.12,
    style: 'shoulder',
    ignoreSelf: true,
    shoulderBack: 2.0,
    shoulderLat: 3.45,
  },
];

export function flightShot(spread: number) {
  const s = THREE.MathUtils.clamp(spread, 0, 30);
  const wHead = THREE.MathUtils.clamp(0.5 - s * 0.009, 0.3, 0.5);
  return {
    wHead,
    fov: THREE.MathUtils.clamp(46 + s * 0.55, 46, 62),

    rise: THREE.MathUtils.clamp(1.95 + s * 0.055, 1.95, 3.1),
    back: 0.36,

    d: THREE.MathUtils.clamp(6.8 + s * 0.42, 7.6, 12),
  };
}

export function stumpShot(gap: number) {
  const g = THREE.MathUtils.clamp(gap, 0, 30);
  return {
    wHead: THREE.MathUtils.clamp(0.42 - g * 0.03, 0, 0.42),
    fov: THREE.MathUtils.clamp(44 + g * 0.5, 44, 58),
    d: THREE.MathUtils.clamp(5 + g * 0.35, 5.4, 13),
    rise: 1.35,
    back: 0.62,
  };
}

export interface CamMode {
  id: string;
  name: string;
  tag: string;
  desc: string;

  fov: number;

  dist: number;

  minDist: number;

  margin: number;

  orbit: number;

  height: number;

  closeBias: number;

  lookY: number;
  down: number;

  hand: number;
  lead: number;

  koScale: number;

  style?: 'axis' | 'shoulder';

  ignoreSelf?: boolean;

  shoulderBack?: number;
  shoulderLat?: number;
}

const MAX_CAM_D = 23;

const SHOULDER_BACK = 2.4;
const SHOULDER_LAT = 2.8;
const SHOULDER_BACK_K = 0.55;
const SHOULDER_LAT_K = 0.04;

const CAM_Y_MIN = 2.5;
const CAM_Y_MAX = 12.5;

export interface GameplayOut {

  camClose: number;

  d: number;

  spill: number;
}

const gF = new THREE.Vector2();
const gR = new THREE.Vector2();
const gDir = new THREE.Vector3();
const gAnchor = new THREE.Vector3();
const gPts: number[] = [];
const gPads: number[] = [];

export function gameplayShot(
  out: THREE.Vector3,
  look: THREE.Vector3,
  frame: Frame,
  a: FighterLike,
  b: FighterLike,
  mode: CamMode,
  fov: number,
  aspect: number,
  reach: number,
): GameplayOut {
  const f = gF.set(b.pos.x - a.pos.x, b.pos.y - a.pos.y);
  if (f.lengthSq() < 1e-6) f.set(0, 1);
  f.normalize();
  const r = gR.set(-f.y, f.x);
  const dist = Math.hypot(b.pos.x - a.pos.x, b.pos.y - a.pos.y);
  const midX = (a.pos.x + b.pos.x) * 0.5;
  const midZ = (a.pos.y + b.pos.y) * 0.5;
  const vx = ((a.vel?.x ?? 0) + (b.vel?.x ?? 0)) * 0.5;
  const vz = ((a.vel?.y ?? 0) + (b.vel?.y ?? 0)) * 0.5;

  const leadK = mode.lead * THREE.MathUtils.clamp(1 - (dist - 5) / 12, 0.22, 1);

  const close = THREE.MathUtils.clamp((5.4 - dist) / 2.6, 0, 1);
  const air = Math.max(b.y, a.y);

  const heroExtra = Math.max(0, ((a.standH && a.standH > 0 ? a.standH : STAND_H) - STAND_H) * a.scale);

  const downed = a.state === 'ko' || a.state === 'down' || b.state === 'ko' || b.state === 'down';
  const shoulder = mode.style === 'shoulder';

  const aimX = shoulder ? b.pos.x : midX;
  const aimZ = shoulder ? b.pos.y : midZ;
  const aimY = (downed ? 1.95 : mode.lookY) + close * 0.35 * mode.down + air * 0.6 + (downed ? 0 : heroExtra * 0.38);

  const place = (d: number, lx: number, lz: number) => {

    const py = (downed ? 3.15 : mode.height) + close * mode.down * 0.6 + Math.max(0, dist - 6) * 0.05 + air * 0.4 + heroExtra * 0.55;
    if (shoulder) {

      const back = ((mode.shoulderBack ?? SHOULDER_BACK) + d * SHOULDER_BACK_K) * (1 + heroExtra * 0.07);
      const lat = ((mode.shoulderLat ?? SHOULDER_LAT) + d * SHOULDER_LAT_K) * (1 + heroExtra * 0.05);
      out.set(a.pos.x - f.x * back + r.x * lat, py, a.pos.y - f.y * back + r.y * lat);
    } else {
      const orbit = mode.orbit + close * 0.12 * (1 - mode.closeBias * 0.5);
      out.set(lx - f.x * d * Math.cos(orbit) + r.x * d * Math.sin(orbit), py, lz - f.y * d * Math.cos(orbit) + r.y * d * Math.sin(orbit));
    }
  };

  const wantD = Math.max(mode.minDist, mode.dist - mode.closeBias * 2.4 * close);
  let spill = 0;

  const shoot = (k: number) => {
    const lx = shoulder ? aimX + vx * k * 0.5 : midX + vx * k;
    const lz = shoulder ? aimZ + vz * k * 0.5 : midZ + vz * k;
    look.set(lx, aimY, lz);

    let dMax: number;
    if (shoulder) {

      const sBack = mode.shoulderBack ?? SHOULDER_BACK;
      const sLat = mode.shoulderLat ?? SHOULDER_LAT;
      gAnchor.set(a.pos.x - f.x * sBack + r.x * sLat, 3.5, a.pos.y - f.y * sBack + r.y * sLat);
      gDir.set(-f.x * SHOULDER_BACK_K + r.x * SHOULDER_LAT_K, 0, -f.y * SHOULDER_BACK_K + r.y * SHOULDER_LAT_K);
      const scale = gDir.length() || 1;
      gDir.multiplyScalar(1 / scale);
      dMax = reachAlong(gAnchor, gDir, reach, CAM_Y_MIN, CAM_Y_MAX) / scale;
    } else {
      gDir.set(-f.x * Math.cos(mode.orbit) + r.x * Math.sin(mode.orbit), 0, -f.y * Math.cos(mode.orbit) + r.y * Math.sin(mode.orbit));
      gDir.normalize();
      gAnchor.set(lx, 3.5, lz);
      dMax = reachAlong(gAnchor, gDir, reach, CAM_Y_MIN, CAM_Y_MAX);
    }
    dMax = Math.min(MAX_CAM_D, Math.max(3, dMax));

    gPts.length = 0;
    gPads.length = 0;
    fighterBox(gPts, gPads, shoulder ? [b] : [a, b]);

    const want = Math.min(wantD, dMax);
    let d = want;
    place(d, lx, lz);
    aimFrame(frame, out, look, fov, aspect);
    spill = spillMany(frame, out, gPts, gPads);
    for (let i = 0; i < 7 && spill > 1 && d < dMax - 0.01; i++) {
      d = Math.min(dMax, d * (1 + (spill - 1) * 0.85 + 0.05));
      place(d, lx, lz);
      aimFrame(frame, out, look, fov, aspect);
      spill = spillMany(frame, out, gPts, gPads);
    }

    place(Math.min(dMax, Math.max(want, d * mode.margin)), lx, lz);
    return spill;
  };

  if (shoot(leadK) > 1) shoot(leadK * 0.25);
  aimFrame(frame, out, look, fov, aspect);
  return { camClose: close, d: out.distanceTo(look), spill };
}
