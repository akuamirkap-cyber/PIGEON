export const ACCOUNT_NAME = 'AMIRALBANI';
export const ACCOUNT_TAG = '#WRC-7731';
export const ACCOUNT_REGION = 'ID · YOGYAKARTA';

export type ModeId = 'play' | 'star' | 'atlas' | 'rank';

export interface ModeMeta {
  id: ModeId;
  name: string;
  sub: string;
  icon: string;
  color: string;
  desc: string;
  reward: string;
  equip?: 'zeus';
}

export const MODES: ModeMeta[] = [
  { id: 'play', name: 'PLAY MATCH', sub: 'Quick Fight · Best of 3', icon: '⚔', color: '#45d6ff', desc: 'Duel cepat lawan Titan pilihanmu dari roster.', reward: '+80 XP · +60 WRC' },
  { id: 'star', name: 'STAR MODE', sub: 'Boxing Star Style · Auto-Range', icon: '⭐', color: '#ffd34a', desc: 'Mode nyaman: kamera belakang pundak & auto-range.', reward: '+100 XP · +110 Pts' },
  { id: 'atlas', name: 'LAWAN ATLAS', sub: 'Duel Terkunci · ATLAS PRIME', icon: '⚡', color: '#7fe4ff', desc: 'Duel terkunci melawan sang juara bertahan ATLAS PRIME.', reward: '+120 XP · +140 Pts' },
  { id: 'rank', name: 'RANK MODE', sub: 'Competitive Ladder · RP', icon: '🏅', color: '#ffd34a', desc: 'Lawan otomatis sesuai tier rank. Menang +28 RP, kalah −16 RP.', reward: '+150 XP · ±RP' },
];

export const modeOf = (id: ModeId) => MODES.find((m) => m.id === id) ?? MODES[0];

export interface Profile {
  xp: number;
  wins: number;
  losses: number;
  streak: number;
  bestStreak: number;
  rp: number;
  rankWins: number;
  rankLosses: number;
  titles: number;
}

const LS_PROFILE = 'steel-titans-profile-v1';

const DEFAULT_PROFILE: Profile = {
  xp: 2650,
  wins: 0,
  losses: 0,
  streak: 0,
  bestStreak: 0,
  rp: 120,
  rankWins: 0,
  rankLosses: 0,
  titles: 0,
};

export const loadProfile = (): Profile => {
  try {
    const raw = localStorage.getItem(LS_PROFILE);
    if (raw) return { ...DEFAULT_PROFILE, ...(JSON.parse(raw) as Partial<Profile>) };
  } catch {
  }
  return { ...DEFAULT_PROFILE };
};

export const saveProfile = (p: Profile) => {
  try {
    localStorage.setItem(LS_PROFILE, JSON.stringify(p));
  } catch {
  }
};

export const levelOf = (xp: number) => {
  let lv = 1;
  let need = 490;
  let rest = xp;
  while (rest >= need && lv < 99) {
    rest -= need;
    lv++;
    need = 400 + 90 * lv;
  }
  return { level: lv, into: rest, need, frac: Math.min(1, rest / need) };
};

export interface RankTier {
  name: string;
  short: string;
  min: number;
  color: string;
  icon: string;
}

export const RANK_TIERS: RankTier[] = [
  { name: 'BRONZE', short: 'B', min: 0, color: '#d08a4a', icon: '🥉' },
  { name: 'SILVER', short: 'S', min: 150, color: '#c9d3df', icon: '🥈' },
  { name: 'GOLD', short: 'G', min: 320, color: '#ffd34a', icon: '🥇' },
  { name: 'PLATINUM', short: 'P', min: 520, color: '#5effd6', icon: '💠' },
  { name: 'DIAMOND', short: 'D', min: 760, color: '#7fb8ff', icon: '💎' },
  { name: 'TITAN', short: 'T', min: 1050, color: '#ff4d6d', icon: '👑' },
];

export const tierOf = (rp: number) => {
  let t = RANK_TIERS[0];
  for (const r of RANK_TIERS) if (rp >= r.min) t = r;
  const idx = RANK_TIERS.indexOf(t);
  const next = RANK_TIERS[idx + 1];
  const div = next ? 3 - Math.min(2, Math.floor(((rp - t.min) / (next.min - t.min)) * 3)) : 1;
  return { tier: t, next, division: div, frac: next ? (rp - t.min) / (next.min - t.min) : 1 };
};

export const rankOpponent = (rp: number, rosterSize: number) => {
  const { tier } = tierOf(rp);
  const i = RANK_TIERS.indexOf(tier);
  return Math.min(rosterSize - 1, Math.max(0, Math.round((i / (RANK_TIERS.length - 1)) * (rosterSize - 1))));
};

export const wrcPoints = (p: Profile) => 1250 + p.wins * 60 + p.rankWins * 80 + p.titles * 600;

export interface MatchOutcome {
  win: boolean;
  mode: ModeId;
  ultra: boolean;
}

export const applyOutcome = (p0: Profile, o: MatchOutcome): Profile => {
  const p = { ...p0 };
  const mult = o.ultra ? 1.4 : 1;
  const base = o.mode === 'rank' ? 150 : o.mode === 'atlas' ? 120 : o.mode === 'star' ? 100 : 80;
  if (o.win) {
    p.wins++;
    p.streak++;
    p.bestStreak = Math.max(p.bestStreak, p.streak);
    p.xp += Math.round(base * mult + Math.min(5, p.streak) * 10);
    if (o.mode === 'rank') {
      p.rankWins++;
      p.rp += 28;
    }
  } else {
    p.losses++;
    p.streak = 0;
    p.xp += Math.round(30 * mult);
    if (o.mode === 'rank') {
      p.rankLosses++;
      p.rp = Math.max(0, p.rp - 16);
    }
  }
  return p;
};

export interface Series {
  mode: ModeId;
  opp: number;
  done: boolean;
  won: boolean;
}

export const makeSeries = (mode: ModeId, rosterSize: number, rp: number, selected: number): Series => {
  const opp =
    mode === 'atlas'
      ? Math.max(0, rosterSize - 1)
      : mode === 'rank'
        ? rankOpponent(rp, rosterSize)
        : selected;
  return { mode, opp, done: false, won: false };
};

export const seriesLabel = (s: Series | null): string => {
  if (!s) return '';
  if (s.mode === 'atlas') return 'DUEL ZEUS vs ATLAS PRIME';
  if (s.mode === 'star') return 'STAR MODE · AUTO-RANGE';
  if (s.mode === 'rank') return 'RANK MODE · RANKED BOUT';
  return 'PLAY MATCH';
};
