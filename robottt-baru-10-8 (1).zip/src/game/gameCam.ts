import * as THREE from 'three';
import type { Game } from './Game';
import {
  OPPONENTS,

  CINE_DUR,
  ringCfg,

  CAM_MODES, gameplayShot, ripShot, fitShot, fighterBox, reachAlong,

  HANGAR_POS, mount100PercentZeus, smooth, lerp,
  type CineKind,
  Robot, WALK_T, INTRO_T, COM_H, DEFAULT_BLOOM_PCT,
} from './gameData';
const CUTOUT_LAYER = 7;

export function capturePortrait(g: Game, w = 240, h = 320, frame: 'bust' | 'torso' = 'bust', cutout = false): string | null {
    const hero = g.menuHero;
    if (!hero) return null;
    return g.captureRobot(hero, w, h, frame, cutout, -0.22);
  }

export function captureOpponentPortrait(g: Game, idx: number, w = 420, h = 520, frame: 'bust' | 'torso' = 'torso', cutout = true): string | null {
    if (idx < 0 || idx >= OPPONENTS.length) return null;
    let f = g.enemyCache.get(idx);
    if (!f) {
      const d = g.makeDef(idx);
      f = g.makeFighter(false, d.style, d.scale, d.hp, d.dmg, d.tscale);
      g.enemyCache.set(idx, f);
      if (f !== g.enemy) {
        g.scene.remove(f.robot.root);
        for (const tr of f.trails) g.scene.remove(tr.mesh);
      }
    }
    const robot = f.robot;
    const inScene = robot.root.parent === g.scene;
    if (!inScene) g.scene.add(robot.root);
    if (idx === 0) mount100PercentZeus(robot, '#22ff44');
    else if (idx === 3 || OPPONENTS[idx].name === 'OMEGA ZEUS') mount100PercentZeus(robot, '#c070ff');
    robot.setStyleGlow(g.ultra && idx !== 0 ? 0xff1a3a : OPPONENTS[idx].style.glow);
    robot.head.visible = true;

    const pos = robot.root.position.clone();
    robot.root.position.set(HANGAR_POS.x, 0, HANGAR_POS.z);
    const st = g.heroAnimState('guard', 1.0, 0, 0);
    for (let i = 0; i < 48; i++) robot.animate(st, 0.05);
    const url = g.captureRobot(robot, w, h, frame, cutout, 0.22);
    robot.root.position.copy(pos);
    if (!inScene) g.scene.remove(robot.root);
    return url;
  }

export function grabCorner(g: Game, w: number, h: number, draw: () => void, read?: (ctx: CanvasRenderingContext2D) => void): string | null {
    const r = g.renderer;
    const dpr = r.getPixelRatio();
    const vp = new THREE.Vector4();
    r.getViewport(vp);
    const sc = new THREE.Vector4();
    r.getScissor(sc);
    const scTest = r.getScissorTest();
    r.setScissorTest(true);
    r.setScissor(0, 0, w, h);
    r.setViewport(0, 0, w, h);
    r.setRenderTarget(null);
    r.clear();
    draw();
    r.setScissorTest(scTest);
    r.setScissor(sc);
    r.setViewport(vp);
    let url: string | null = null;
    try {
      if (!g.portraitCanvas) g.portraitCanvas = document.createElement('canvas');
      const c = g.portraitCanvas;
      c.width = w;
      c.height = h;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      if (ctx) {
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(r.domElement, 0, r.domElement.height - h * dpr, w * dpr, h * dpr, 0, 0, w, h);
        read?.(ctx);
        url = c.toDataURL('image/png');
      }
    } catch {
      url = null;
    }
    return url;
  }

export function captureRobot(g: Game, robot: Robot, w: number, h: number, frame: 'bust' | 'torso', cutout: boolean, yaw: number): string | null {
    const r = g.renderer;
    const dpr = r.getPixelRatio();
    const cw = r.domElement.width / dpr;
    const ch = r.domElement.height / dpr;
    if (cw < w || ch < h) return null;

    const wasVis = robot.root.visible;
    const pos = robot.root.position.clone();
    const rotY = robot.root.rotation.y;
    robot.root.visible = true;
    robot.root.position.set(HANGAR_POS.x, 0, HANGAR_POS.z);
    robot.root.rotation.y = yaw;
    const scrimVis = g.menuScrimPlane?.visible ?? false;
    if (g.menuScrimPlane) {
      g.menuScrimPlane.visible = !cutout;
      g.menuScrimPlane.position.set(HANGAR_POS.x, 4.5, HANGAR_POS.z - 3.0);
    }
    const pedVis = g.menuHeroPedestal?.visible ?? false;
    if (g.menuHeroPedestal) g.menuHeroPedestal.visible = false;
    robot.root.updateMatrixWorld(true);

    const headP = new THREE.Vector3();
    const chestP = new THREE.Vector3();
    const hipP = new THREE.Vector3();
    robot.head.getWorldPosition(headP);
    robot.chest.getWorldPosition(chestP);
    robot.pelvis.getWorldPosition(hipP);
    const top = headP.y + (frame === 'bust' ? 0.95 : 1.1);
    const bottom = frame === 'bust' ? chestP.y + 0.25 : hipP.y - 0.9;
    const mid = (top + bottom) / 2;
    const span = top - bottom;
    const cam = g.portraitCam;
    cam.fov = 26;
    cam.aspect = w / h;
    const dist = (span / 2 / Math.tan(THREE.MathUtils.degToRad(cam.fov / 2))) * 1.08;
    const fwd = new THREE.Vector3(Math.sin(robot.root.rotation.y), 0, Math.cos(robot.root.rotation.y));
    const lookAt = new THREE.Vector3(headP.x * 0.5 + chestP.x * 0.5, mid, HANGAR_POS.z + 0.35);
    cam.position.copy(lookAt).addScaledVector(fwd, dist).add(new THREE.Vector3(0.25 * Math.sign(-yaw || 1), 0.35, 0));
    cam.lookAt(lookAt);
    cam.updateProjectionMatrix();

    let url: string | null;
    if (!cutout) {
      cam.layers.set(0);
      url = g.grabCorner(w, h, () => r.render(g.scene, cam));
    } else {
      const L = CUTOUT_LAYER;
      if (!g.cutoutLayerReady) {
        g.cutoutLayerReady = true;
        g.scene.traverse((o) => {
          if ((o as THREE.Light).isLight) o.layers.enable(L);
        });
      }
      robot.root.traverse((o) => o.layers.enable(L));
      cam.layers.set(L);
      const clear = new THREE.Color();
      r.getClearColor(clear);
      const clearA = r.getClearAlpha();
      let black: ImageData | null = null;
      r.setClearColor(0x000000, 1);
      g.grabCorner(w, h, () => r.render(g.scene, cam), (ctx) => {
        black = ctx.getImageData(0, 0, w, h);
      });
      r.setClearColor(0xffffff, 1);
      url = g.grabCorner(
        w,
        h,
        () => r.render(g.scene, cam),
        (ctx) => {
          if (!black) return;
          const white = ctx.getImageData(0, 0, w, h);
          const bd = (black as ImageData).data;
          const wd = white.data;
          for (let i = 0; i < wd.length; i += 4) {

            const a = Math.max(0, Math.min(1, 1 - (wd[i] - bd[i] + wd[i + 1] - bd[i + 1] + wd[i + 2] - bd[i + 2]) / 765));
            if (a <= 0.004) {
              wd[i + 3] = 0;
              continue;
            }

            wd[i] = Math.min(255, bd[i] / a);
            wd[i + 1] = Math.min(255, bd[i + 1] / a);
            wd[i + 2] = Math.min(255, bd[i + 2] / a);
            wd[i + 3] = Math.round(a * 255);
          }
          ctx.putImageData(white, 0, 0);
        },
      );
      r.setClearColor(clear, clearA);
      cam.layers.set(0);
    }

    robot.root.visible = wasVis;
    robot.root.position.copy(pos);
    robot.root.rotation.y = rotY;
    if (g.menuScrimPlane) g.menuScrimPlane.visible = scrimVis;
    if (g.menuHeroPedestal) g.menuHeroPedestal.visible = pedVis;
    return url;
  }

export function gameplayCam(g: Game, gp: THREE.Vector3, gl: THREE.Vector3, raw: number) {
    const p = g.camHero();
    const e = g.enemy;

    const vk = 1 - Math.exp(-3.2 * raw);
    g.smoothVelP.lerp(p.vel, vk);
    g.smoothVelE.lerp(e.vel, vk);
    const savedVP = p.vel;
    const savedVE = e.vel;
    p.vel = g.smoothVelP;
    e.vel = g.smoothVelE;
    const mode = CAM_MODES[g.camMode];
    const res = gameplayShot(gp, gl, g.view, p, e, mode, g.baseFov, g.aspect, ringCfg.bound + 11);
    p.vel = savedVP;
    e.vel = savedVE;
    g.camClose = res.camClose;

    if (g.phase === 'fight' && mode.style !== 'shoulder') {
      let orbitTarget = Math.sin(g.time * 0.35) * 0.04;
      if (p.state === 'attack' && p.move) orbitTarget += (p.hand === 1 ? 0.08 : -0.08) * p.move.power;
      if (e.state === 'attack' && e.move) orbitTarget -= 0.07 * e.move.power;
      if (p.dodgeT > 0) orbitTarget += p.aliSign * 0.09;
      g.dynOrbit += (orbitTarget - g.dynOrbit) * (1 - Math.exp(-4.0 * raw));
      const ox = gp.x - gl.x;
      const oz = gp.z - gl.z;
      const ca = Math.cos(g.dynOrbit);
      const sa = Math.sin(g.dynOrbit);
      gp.x = gl.x + ox * ca - oz * sa;
      gp.z = gl.z + ox * sa + oz * ca;

      gp.y = Math.max(2.35, gp.y - g.camClose * 0.32);
      gl.y += g.camClose * 0.14;
    }
  }

export function startCine(g: Game, kind: CineKind, at?: THREE.Vector3, dir?: THREE.Vector2) {
    if (g.paused || g.phase === 'menu') return;
    const cur = g.cine;
    if (cur) {
      if (cur.kind === 'rip' && kind !== 'rip') return;
      if (cur.kind === kind && kind !== 'rip' && cur.t < cur.dur * 0.6) return;
    }
    g.cineFrom.copy(g.camPos);
    g.cineFromLook.copy(g.camLook);
    if (at) g.cineFocus.copy(at);
    if (dir && dir.lengthSq() > 0.0001) g.cineDir.copy(dir).normalize();
    g.cine = { kind, t: 0, dur: CINE_DUR[kind] };
    if (kind === 'od') g.cineFovT = 42;
    if (kind === 'hit') g.cineFovT = 46;
    if (kind === 'rip') g.cineFovT = 36;
  }

export function cineCam(g: Game, tp: THREE.Vector3, tl: THREE.Vector3, dt: number) {
    const c = g.cine!;
    c.t += Math.max(dt, 0);
    const u = THREE.MathUtils.clamp(c.t / c.dur, 0, 1);
    const seg = (a: number, b: number, x = u) => {
      const q = THREE.MathUtils.clamp((x - a) / (b - a), 0, 1);
      return q * q * (3 - 2 * q);
    };
    const p = g.camHero();
    const e = g.enemy;
    const up = new THREE.Vector3(0, 1, 0);

    if (c.kind === 'rip') {

      const neck = new THREE.Vector3();
      const head = new THREE.Vector3();
      const chest = new THREE.Vector3();
      const victim = g.ripVictim ?? (g.decap.isOff(g.player.robot) ? g.player : e);
      victim.robot.neck.getWorldPosition(neck);
      victim.robot.chest.getWorldPosition(chest);
      const fly = g.decap.headObj(victim.robot);
      if (fly) fly.getWorldPosition(head);
      else head.copy(neck);
      const blow = new THREE.Vector3(g.cineDir.x, 0, g.cineDir.y);
      if (blow.lengthSq() < 0.001) blow.set(0, 0, 1);
      blow.normalize();
      const side = new THREE.Vector3(-blow.z, 0, blow.x);

      const shot = g.ripS;
      ripShot(
        shot,
        g.view,
        c.t,
        head,
        neck,
        chest,
        blow,
        side,
        e.scale,
        g.container.clientWidth / Math.max(1, g.container.clientHeight),
        g.cineFrom,
        g.cineFromLook,
        ringCfg.bound + 8,
        2.0,
        10.5,
      );

      tp.copy(shot.pos).lerp(tp, shot.blend);
      tl.copy(shot.look).lerp(tl, shot.blend);
      g.cineFovT = shot.fov;
      g.camRoll = shot.roll;
      if (u >= 1) g.cine = null;
      return;
    }

    if (c.kind === 'hit') {

      const k = seg(0, 0.3);
      const midTarget = new THREE.Vector3((p.pos.x + e.pos.x) * 0.5, 3.4, (p.pos.y + e.pos.y) * 0.5);
      const target = g.cineFocus.clone().lerp(midTarget, 0.55).addScaledVector(up, 0.15);
      const from = g.cineFrom.clone();
      const d = from.distanceTo(target);
      const push = Math.min(0.22, 2.2 / Math.max(1.5, d));
      tp.copy(from).lerp(target, push * k);
      tl.copy(g.cineFromLook).lerp(target, seg(0, 0.45));
      g.cineFovT = THREE.MathUtils.lerp(56, 48, k);
      g.camRoll += 0.015 * k * Math.sign(g.cineDir.x + g.cineDir.y || 1);
      if (u >= 1) g.cine = null;
      return;
    }

    const k = seg(0, 0.32) * (1 - seg(0.62, 1));
    const f = g.toward(p, e);
    const r = new THREE.Vector2(-f.y, f.x);
    const gap = p.pos.distanceTo(e.pos);
    const dist = THREE.MathUtils.lerp(Math.max(9.2, gap + 5.8), Math.max(8.2, gap + 4.8), k);
    const orbit = 0.68;
    const midX = (p.pos.x + e.pos.x) * 0.5;
    const midZ = (p.pos.y + e.pos.y) * 0.5;
    const from = new THREE.Vector3(
      midX - f.x * dist * Math.cos(orbit) + r.x * dist * Math.sin(orbit),
      THREE.MathUtils.lerp(4.6, 3.2, k),
      midZ - f.y * dist * Math.cos(orbit) + r.y * dist * Math.sin(orbit),
    );
    tp.copy(g.camPos).lerp(from, k);
    tl.copy(g.camLook).lerp(new THREE.Vector3(midX, THREE.MathUtils.lerp(3.4, 3.6, k), midZ), k);
    g.cineFovT = THREE.MathUtils.lerp(g.cineFov, 48, k);
    g.camRoll += 0.014 * k;
    if (u >= 1) g.cine = null;
  }

export function updateCamera(g: Game, raw: number, dt: number) {
    const p = g.camHero();
    const e = g.enemy;

    p.standH = g.standHOf(p);
    e.standH = g.standHOf(e);
    const cam = g.camera;
    const f = g.toward(p, e);
    const gp = new THREE.Vector3();
    const gl = new THREE.Vector3();
    g.gameplayCam(gp, gl, raw);

    const camMode = CAM_MODES[g.camMode];
    let tp = gp;
    let tl = gl;
    let direct = false;
    const t = g.time;

    const fovGoal = camMode.fov - g.camClose * camMode.closeBias * 5;
    g.baseFov += (fovGoal - g.baseFov) * (1 - Math.exp(-2.6 * raw));

    if (g.phase === 'menu') {
      const aspect = g.container.clientWidth / Math.max(1, g.container.clientHeight);
      const heroX = HANGAR_POS.x;
      const heroZ = HANGAR_POS.z;
      const camCenterY = 3.5;

      g.player.robot.root.visible = true;
      g.enemy.robot.root.visible = true;
      g.player.robot.root.position.y = -200;
      g.enemy.robot.root.position.y = -200;
      if (g.menuHero) {
        g.menuHero.root.visible = true;
        g.menuHeroPedestal.visible = false;
        g.menuScrimPlane.visible = false;
        g.menuHero.root.position.set(heroX, 0, heroZ);
        g.menuHeroPedestal.position.set(heroX, 0, heroZ);
        g.menuScrimPlane.position.set(heroX, camCenterY + 1.0, heroZ - 3.0);
      }

      g.trauma = 0;
      g.camBump = 0;
      g.camPush = 0;
      g.camRoll = 0;
      g.fovKick = 0;
      const distScale = aspect < 0.75 ? Math.min(1.28, 0.75 / aspect) : 1.0;
      const zMul = g.menuHero?.isZeus ? 1.14 : 1.0;
      const camDist = 6.9 * distScale * zMul + Math.sin(t * 0.21) * 0.16;
      const drift = Math.sin(t * 0.3) * 0.14;
      const yOff = g.menuHero?.isZeus ? 0.36 : 0;
      tp = new THREE.Vector3(heroX + 0.15 + drift, 5.25 + yOff + Math.sin(t * 0.17) * 0.06, heroZ + camDist);
      tl = new THREE.Vector3(heroX + 0.15 + drift * 0.4, 5.65 + yOff, heroZ);
      direct = true;
    } else if (g.phase === 'matchEnd') {
      const ang = t * 0.22;
      const winner = g.result === 'win' ? p : e;
      tp = new THREE.Vector3(winner.pos.x + Math.cos(ang) * 11.5, 3.8 + Math.sin(t * 0.4) * 0.6, winner.pos.y + Math.sin(ang) * 11.5);
      tl = new THREE.Vector3(winner.pos.x, 3.2, winner.pos.y);
      direct = !g.camInit;
    } else if (g.phase === 'walk' && g.walk.length) {

      const w = g.walk[0];
      const tt = g.phaseT;
      const ix = w.inward.x;
      const iz = w.inward.y;
      const px = w.perp.x;
      const pz = w.perp.y;
      const fy = p.y;
      const mid = new THREE.Vector2().addVectors(w.take, w.land).multiplyScalar(0.5);
      const A = new THREE.Vector3(p.pos.x + ix * 10.5 + px * 3.4, fy + 3.2, p.pos.y + iz * 10.5 + pz * 3.4);

      const alongX = Math.abs(ix) < Math.abs(iz);
      const rs = alongX ? Math.sign(px) || 1 : Math.sign(pz) || 1;
      const rx = alongX ? rs : 0;
      const rz = alongX ? 0 : rs;
      const bx = THREE.MathUtils.lerp(p.pos.x, mid.x, 0.45);
      const bz = THREE.MathUtils.lerp(p.pos.y, mid.y, 0.45);
      const B = new THREE.Vector3(w.land.x + rx * 13 + ix * 1.5, 4.6, w.land.y + rz * 13 + iz * 1.5);
      const u4 = THREE.MathUtils.clamp((tt - w.t[3]) / (w.t[5] - w.t[3]), 0, 1);
      const cd = 10.0 - 1.2 * u4;
      const C = new THREE.Vector3(w.land.x + ix * cd + px * 2.8, 2.2 + u4 * 0.6, w.land.y + iz * cd + pz * 2.8);
      const E = new THREE.Vector3(ix * -3.5 + px * 12.5, 6.4, iz * -3.5 + pz * 12.5);
      const lookA = new THREE.Vector3(p.pos.x, fy + 3.6, p.pos.y);
      const lookB = new THREE.Vector3(bx, THREE.MathUtils.clamp(fy + 3.2, 2.5, 5.2), bz);
      const lookC = new THREE.Vector3(p.pos.x, 3.1 + (1 - p.pkLand) * 0.6, p.pos.y);
      const lookE = new THREE.Vector3(p.pos.x * 0.6, 3.0, p.pos.y * 0.6);
      const sw = (a: number, b: number) => smooth(THREE.MathUtils.clamp((tt - a) / (b - a), 0, 1));
      const wAB = sw(w.t[1] - 0.7, w.t[1] + 0.15);
      const wBC = tt >= w.t[3] - 0.1 ? 1 : 0;
      const wCE = sw(w.t[4] + 0.5, w.t[4] + 1.3);
      tp = A.lerp(B, wAB).lerp(C, wBC).lerp(E, wCE);
      tl = lookA.lerp(lookB, wAB).lerp(lookC, wBC).lerp(lookE, wCE);
      direct = !g.camInit || (tt >= w.t[3] - 0.1 && tt < w.t[3] + 0.04);
      if (tt > WALK_T - 0.6) direct = true;
    } else if (g.phase === 'intro') {
      const u = Math.min(1, g.phaseT / INTRO_T);
      const eu = smooth(u);
      const behind = Math.atan2(-f.y, -f.x);
      const az = behind + Math.PI * (1 - eu) * 0.95;
      const rad = lerp(11, 7.0, eu);
      const ip = new THREE.Vector3(Math.cos(az) * rad, lerp(2.0, 4.6, eu), Math.sin(az) * rad);
      const il = new THREE.Vector3(0, 3.8, 0);
      const w = smooth(Math.min(1, Math.max(0, (u - 0.72) / 0.28)));
      tp = ip.lerp(gp, w);
      tl = il.lerp(gl, w);
      direct = true;
    } else if (g.phase === 'ko' && !g.timeUp) {

      const loser = p.state === 'ko' ? p : e;
      let cx = loser.pos.x;
      let cz = loser.pos.y;
      let rad = 8.5;
      let lookY = 2.0;
      let lift = 0;
      const fly = g.decap.isOff(loser.robot) ? g.decap.headObj(loser.robot) : null;
      if (fly) {
        g.spillD.setFromMatrixPosition(fly.matrixWorld);
        const gap = Math.hypot(g.spillD.x - loser.pos.x, g.spillD.z - loser.pos.y);
        if (gap > 2) {
          cx = (loser.pos.x + g.spillD.x) * 0.5;
          cz = (loser.pos.y + g.spillD.z) * 0.5;
          rad = 8.5 + gap * 0.42;
          lookY = 1.7;
          lift = Math.min(1.4, gap * 0.06);
        }
      }
      rad *= camMode.koScale;

      const far = Math.hypot(cx, cz);
      rad = Math.max(4.5, Math.min(rad, ringCfg.bound + 10 - far));
      const ang = t * 0.3 + 1.2;
      tp = new THREE.Vector3(cx + Math.cos(ang) * rad, 3.3 + lift, cz + Math.sin(ang) * rad);
      tl = new THREE.Vector3(cx, lookY, cz);
    } else if (g.phase === 'ko') {
      tp = gp;
    }

    let cineK = 0;
    if (g.cine && (g.phase === 'fight' || g.phase === 'ko')) {
      g.cineCam(tp, tl, dt);

      tp.x = THREE.MathUtils.clamp(tp.x, -(ringCfg.bound + 9.5), ringCfg.bound + 9.5);
      tp.z = THREE.MathUtils.clamp(tp.z, -(ringCfg.bound + 9.5), ringCfg.bound + 9.5);
      tp.y = THREE.MathUtils.clamp(tp.y, 2.0, 10.5);
      cineK = 1;
    } else if (g.cine) {
      g.cine = null;
    }

    g.runFov += ((g.player.sprinting ? 4 : 0) - g.runFov) * (1 - Math.exp(-4 * raw));

    g.cineFov += (g.cineFovT - g.cineFov) * (1 - Math.exp(-7 * raw));
    if (!g.cine && Math.abs(g.cineFov - g.baseFov) < 0.2) g.cineFov = g.baseFov;
    const gameFov = cineK > 0 || g.cine ? g.cineFov : g.baseFov;
    const clampedKick = g.phase === 'fight' ? Math.max(-4.5, g.fovKick) : g.fovKick;
    cam.fov = (g.phase === 'menu' ? 38 : gameFov) + clampedKick + (cineK > 0 ? 0 : g.runFov);

    const safeFov = Math.max(28, cam.fov - 5.5);
    if (g.cine?.kind !== 'rip' && (g.phase === 'fight' || g.phase === 'ko' || g.phase === 'walk')) {
      g.spillPts.length = 0;
      g.spillPads.length = 0;

      const targets = g.phase === 'walk' ? [p] : camMode.ignoreSelf && g.phase === 'fight' ? [e] : [p, e];
      fighterBox(g.spillPts, g.spillPads, targets);
      if (g.phase === 'walk' && p.flip !== 0) {
        g.spillPts.push(p.pos.x, p.y + COM_H * p.scale, p.pos.y);
        g.spillPads.push(4.1 * p.scale);
      }
      for (const fgt of targets) {
        const sc = fgt.scale;
        const flat = THREE.MathUtils.clamp(fgt.fallS ? fgt.fallS.x : fgt.state === 'ko' || fgt.state === 'down' ? 1 : 0, 0, 1);

        const headH = (fgt.standH && fgt.standH > 0 ? fgt.standH : 6.6) + 0.55;
        const headY = (headH - (headH - 1.9) * flat) * sc + fgt.y;
        const chestY = (headH * 0.531 - 2.2 * flat) * sc + fgt.y;
        g.spillPts.push(fgt.pos.x, headY, fgt.pos.y);
        g.spillPads.push(1.08 * sc);
        g.spillPts.push(fgt.pos.x, chestY, fgt.pos.y);
        g.spillPads.push(1.28 * sc);
        g.spillPts.push(fgt.pos.x, Math.max(0.08, fgt.y), fgt.pos.y);
        g.spillPads.push(0.68 * sc);
      }
      const decapFgt = g.fighters().find((f) => g.decap.isOff(f.robot));
      const fly = decapFgt ? g.decap.headObj(decapFgt.robot) : null;
      if (fly) {
        g.spillD.setFromMatrixPosition(fly.matrixWorld);
        g.spillPts.push(g.spillD.x, g.spillD.y, g.spillD.z);
        g.spillPads.push(0.95 * (decapFgt?.scale ?? 1));
      }
      const dt0 = tp.distanceTo(tl);
      if (dt0 > 0.8) {
        g.spillDir.copy(tp).sub(tl).multiplyScalar(1 / dt0);

        const walkCam = g.phase === 'walk';
        const roomT = reachAlong(tl, g.spillDir, walkCam ? 40 : ringCfg.bound + 15, walkCam ? -1.2 : 2.2, 13.5);
        const dtFit = fitShot(
          g.view,
          tl,
          g.spillDir,
          safeFov,
          g.aspect,
          g.spillPts,
          g.spillPads,
          dt0,
          Math.min(dt0 * 1.85 + 10, roomT),
          tp,
        );
        if (dtFit > dt0) tp.copy(g.spillDir).multiplyScalar(dtFit).add(tl);
      }
    }

    if (direct) {
      g.camPos.copy(tp);
      g.camLook.copy(tl);
      if (g.phase !== 'intro') g.camInit = true;
    } else if (cineK > 0) {
      g.camPos.lerp(tp, 1 - Math.exp(-16 * raw));
      g.camLook.lerp(tl, 1 - Math.exp(-15 * raw));
    } else {

      const fk = 1 + (g.fwMul - 1) * 0.35;
      g.camPos.lerp(tp, 1 - Math.exp(-8.5 * fk * raw));
      g.camLook.lerp(tl, 1 - Math.exp(-12.5 * fk * raw));
    }

    if (g.cine?.kind !== 'rip' && (g.phase === 'fight' || g.phase === 'ko' || (g.phase === 'walk' && g.spillPts.length > 0))) {
      const d0 = g.camPos.distanceTo(g.camLook);
      if (d0 > 0.8) {
        g.spillDir.copy(g.camPos).sub(g.camLook).multiplyScalar(1 / d0);
        const walkCam2 = g.phase === 'walk';
        const room = reachAlong(g.camLook, g.spillDir, walkCam2 ? 40 : ringCfg.bound + 15, walkCam2 ? -1.2 : 2.2, 13.5);
        const d = fitShot(
          g.view,
          g.camLook,
          g.spillDir,
          safeFov + 1.5,
          g.aspect,
          g.spillPts,
          g.spillPads,
          d0,
          Math.min(d0 * 1.85 + 10, room),
          g.camPos,
        );
        if (d > d0) g.camPos.copy(g.spillDir).multiplyScalar(d).add(g.camLook);
      }
    }

    cam.position.copy(g.camPos);
    if (g.phase !== 'menu') {

      const stepDt = Math.min(0.033, raw);
      const springK = 185;
      const dampC = 16.5;
      g.camImpVel.x += (-springK * g.camImp.x - dampC * g.camImpVel.x) * stepDt;
      g.camImpVel.y += (-springK * g.camImp.y - dampC * g.camImpVel.y) * stepDt;
      g.camImpVel.z += (-springK * g.camImp.z - dampC * g.camImpVel.z) * stepDt;
      g.camImp.addScaledVector(g.camImpVel, stepDt);
      const maxImp = 0.42;
      if (g.camImp.length() > maxImp) g.camImp.setLength(maxImp);
      cam.position.add(g.camImp);

      g.camPush *= Math.exp(-9 * raw);
      g.camBump *= Math.exp(-10 * raw);
      g.camRoll *= Math.exp(-8 * raw);
      if (g.camPush > 0.001) {
        const dirv = g.camLook.clone().sub(cam.position).normalize();
        cam.position.addScaledVector(dirv, Math.min(0.34, g.camPush));
      }
      cam.position.y -= g.camBump * 0.42;

      g.handPh += raw;
      const hand = (0.012 + g.hype * 0.008 + g.camClose * 0.008) * camMode.hand * (cineK > 0 ? 0.25 : 1);
      cam.position.x += Math.sin(g.handPh * 0.85) * hand;
      cam.position.y += Math.sin(g.handPh * 1.21 + 1.3) * hand * 0.55;
      cam.position.z += Math.cos(g.handPh * 0.73 + 0.6) * hand * 0.6;

      g.shakePh += raw * 24;
      const s = g.trauma * g.trauma * (cineK > 0 ? 0.3 : 0.52);
      if (s > 0.0005) {
        const wave = Math.sin(g.shakePh);
        const wave2 = Math.cos(g.shakePh * 0.75);
        cam.position.x += wave * s * 0.22;
        cam.position.y -= Math.abs(wave) * s * 0.2;
        cam.position.z += wave2 * s * 0.22;
      }

      cam.lookAt(g.camLook);
      if (s > 0.0005) {
        cam.rotateZ(Math.sin(g.shakePh * 0.85) * s * 0.024);
        cam.rotateX(-Math.abs(Math.sin(g.shakePh)) * s * 0.014);
      }
      cam.rotateZ(g.camRoll + Math.sin(g.handPh * 0.61) * hand * 0.008);
    } else {

      g.camPush = 0;
      g.camBump = 0;
      g.camRoll = 0;
      g.trauma = 0;
      g.camImp.set(0, 0, 0);
      g.camImpVel.set(0, 0, 0);
      cam.lookAt(g.camLook);
    }
    cam.updateProjectionMatrix();

    if (g.bloom) {
      const hpUni = g.bloom.highPassUniforms as Record<string, { value: number }> | undefined;
      if (hpUni && hpUni.smoothWidth) {
        hpUni.smoothWidth.value = 0.55;
      }
      const pct = Math.max(0, Math.min(50, g.bloomPercent ?? DEFAULT_BLOOM_PCT));
      if (g.bloomMode === 'off' || pct <= 0) {
        g.bloom.enabled = false;
        g.bloom.strength = 0;
        g.smoothBloomStrength = 0;
      } else {
        g.bloom.enabled = g.tierCfg().bloom;
        const pctRatio = pct / 50;
        const isSmooth = g.bloomMode === 'smooth';
        const targetThreshold = isSmooth
          ? (g.phase === 'menu' ? 1.35 : 1.25)
          : (g.phase === 'menu' ? 1.55 : 1.5);

        const baseStrength = pctRatio * 0.40;
        const dynamicBoost = isSmooth
          ? (g.trauma * 0.02 + g.flashAmt * 0.025) * pctRatio
          : 0;
        const targetStrength = Math.min(0.48, baseStrength + dynamicBoost);
        const targetRadius = isSmooth ? (0.42 + 0.25 * pctRatio) : (0.35 + 0.2 * pctRatio);

        const lerpFactor = 1 - Math.exp(-8.0 * raw);
        g.smoothBloomStrength += (targetStrength - g.smoothBloomStrength) * lerpFactor;
        g.smoothBloomRadius += (targetRadius - g.smoothBloomRadius) * lerpFactor;

        g.bloom.threshold = targetThreshold;
        g.bloom.strength = g.smoothBloomStrength;
        g.bloom.radius = g.smoothBloomRadius;
      }
    }
  }
