export const STAND_TIERS = 4;
export const ROWS_PER_TIER = 3;
export const STAND_INNER_RADIUS = 28;
export const STAND_TIER_SPACING = 8.0;
export const STAND_ROW_SPACING = 2.0;

export const SPECTATOR_SEAT_SPACING = 1.0;

export const standTierInnerRadius = (tier: number) => STAND_INNER_RADIUS + tier * STAND_TIER_SPACING;
export const standRowInnerRadius = (tier: number, row: number) => standTierInnerRadius(tier) + row * STAND_ROW_SPACING;
export const standRowHeight = (tier: number, row: number) => 0.4 + (tier * ROWS_PER_TIER + row + 1) * 0.85;
