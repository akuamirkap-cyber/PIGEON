import { useEffect, useMemo, useRef, useState } from 'react';
import { ATLAS_IDX, CAM_MODES, DEFAULT_BLOOM_PCT, DEFAULT_BRIGHTNESS, Game, GFX_MODES, OPPONENTS, loadBloomPercent, loadBrightness, loadCamMode, loadDifficulty, loadDirectionalHeadSnap, loadFootwork, loadGfxMode, loadIq, loadNoSlowMoNormal, loadPyroPlacement, loadSaturation, loadTextureEnhance, NORMAL_SAT, type BloomMode, type GfxMode, type HudState, type PyroPlacement } from './game/Game';
import { loadSfxProfile, loadAllOverdrivePunch, type SfxProfile } from './game/audio';
import { Menu } from './ui/Menu';
import { Hud, TouchControls } from './ui/Hud';
import { MatchEnd, PauseMenu } from './ui/Overlays';
import { applyOutcome, loadProfile, makeSeries, modeOf, saveProfile, seriesLabel, type ModeId, type Profile, type Series } from './game/progress';

const LS_KEY = 'steel-titans-unlocked';

const IconPause = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" aria-hidden="true">
    <rect x="2" y="1" width="3.5" height="12" />
    <rect x="8.5" y="1" width="3.5" height="12" />
  </svg>
);

const IconSound = ({ off }: { off: boolean }) => (
  <svg width="18" height="16" viewBox="0 0 18 16" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
    <path d="M2 6h3l4-3.5v11L5 10H2z" fill="currentColor" />
    {off ? (
      <path d="M12 5l5 6M17 5l-5 6" />
    ) : (
      <>
        <path d="M12 5.5c1.3 1.3 1.3 3.7 0 5" />
        <path d="M14.5 3.5c2.4 2.4 2.4 6.6 0 9" />
      </>
    )}
  </svg>
);

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [muted, setMuted] = useState(false);
  const [sel, setSel] = useState(0);

  const [fwLocal, setFwLocal] = useState<number>(loadFootwork);
  const fwNow = hud?.fw ?? fwLocal;
  const pickFw = (m: number) => {
    setFwLocal(m);
    gameRef.current?.setFootwork(m);
  };

  const [camLocal, setCamLocal] = useState<number>(loadCamMode);
  const camNow = hud?.cam ?? camLocal;
  const pickCam = (i: number) => {
    setCamLocal(i);
    gameRef.current?.setCamMode(i);
  };

  const [iqLocal, setIqLocal] = useState<number>(loadIq);
  const iqNow = hud?.iq ?? iqLocal;
  const pickIq = (n: number) => {
    setIqLocal(n);
    gameRef.current?.setIq(n);
  };

  const [gfxLocal, setGfxLocal] = useState<GfxMode>(loadGfxMode);
  const gfxNow = hud?.gfxMode ?? gfxLocal;
  const pickGfx = (m: GfxMode) => {
    setGfxLocal(m);
    gameRef.current?.setGfxMode(m);
  };

  const [brightLocal, setBrightLocal] = useState<number>(loadBrightness);
  const brightNow = hud?.bright ?? brightLocal;
  const pickBright = (b: number) => {
    setBrightLocal(b);
    gameRef.current?.setBrightness(b);
  };

  const [satLocal, setSatLocal] = useState<number>(loadSaturation);
  const satNow = hud?.sat ?? satLocal;
  const pickSat = (s: number) => {
    setSatLocal(s);
    gameRef.current?.setSaturation(s);
  };

  const [texLocal, setTexLocal] = useState<boolean>(loadTextureEnhance);
  const texNow = hud?.textureEnhance ?? texLocal;
  const pickTex = (t: boolean) => {
    setTexLocal(t);
    gameRef.current?.setTextureEnhance(t);
  };

  const [bloomLocal, setBloomLocal] = useState<number>(loadBloomPercent);
  const bloomNow = hud?.bloomPercent ?? bloomLocal;
  const pickBloom = (p: number | BloomMode) => {
    const pct = typeof p === 'number' ? p : p === 'off' ? 0 : p === 'smooth' ? 18 : 28;
    setBloomLocal(pct);
    gameRef.current?.setBloomPercent(pct);
  };

  const [pyroLocal, setPyroLocal] = useState<PyroPlacement>(loadPyroPlacement);
  const pyroNow = hud?.pyroPlacement ?? pyroLocal;
  const pickPyro = (p: PyroPlacement) => {
    setPyroLocal(p);
    gameRef.current?.setPyroPlacement(p);
  };

  const resetVisuals = () => {
    gameRef.current?.resetVisualsToNormal();
    setBrightLocal(DEFAULT_BRIGHTNESS);
    setSatLocal(NORMAL_SAT);
    setTexLocal(false);
    setBloomLocal(DEFAULT_BLOOM_PCT);
    setGfxLocal('auto');
  };

  const [ultra, setUltraState] = useState<boolean>(() => loadDifficulty() === 'ultra');
  const pickUltra = (on: boolean) => {
    setUltraState(on);
    gameRef.current?.setUltra(on);
  };

  const [sfxId, setSfxId] = useState<SfxProfile>(loadSfxProfile);
  const pickSfx = (id: SfxProfile) => {
    setSfxId(id);
    gameRef.current?.setSoundProfile(id);
  };

  const [snapLocal, setSnapLocal] = useState<boolean>(loadDirectionalHeadSnap);
  const snapNow = hud?.directionalHeadSnap ?? snapLocal;
  const pickSnap = (on: boolean) => {
    setSnapLocal(on);
    gameRef.current?.setDirectionalHeadSnap(on);
  };

  const [noSlowMoNormalLocal, setNoSlowMoNormalLocal] = useState<boolean>(loadNoSlowMoNormal);
  const noSlowMoNormalNow = hud?.noSlowMoNormal ?? noSlowMoNormalLocal;
  const pickNoSlowMoNormal = (on: boolean) => {
    setNoSlowMoNormalLocal(on);
    gameRef.current?.setNoSlowMoNormal(on);
  };

  const [allOdLocal, setAllOdLocal] = useState<boolean>(loadAllOverdrivePunch);
  const allOdNow = hud?.allOverdrivePunch ?? allOdLocal;
  const pickAllOd = (on: boolean) => {
    setAllOdLocal(on);
    gameRef.current?.setAllOverdrivePunch(on);
  };

  const [unlocked, setUnlocked] = useState(() => {
    const v = Number(localStorage.getItem(LS_KEY));
    return Number.isFinite(v) ? Math.min(OPPONENTS.length - 1, Math.max(0, v)) : 0;
  });
  const touch = useMemo(() => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches, []);

  useEffect(() => {
    if (!mount.current) return;
    const g = new Game(mount.current, setHud);
    gameRef.current = g;
    setGame(g);
    return () => {
      g.dispose();
      gameRef.current = null;
    };
  }, []);

  const [profile, setProfile] = useState<Profile>(loadProfile);
  const [mode, setMode] = useState<ModeId>('play');
  const [series, setSeries] = useState<Series | null>(null);
  const seriesRef = useRef<Series | null>(null);
  seriesRef.current = series;

  const startMode = (m: ModeId) => {
    const s = makeSeries(m, OPPONENTS.length, profile.rp, sel);
    setMode(m);
    setSeries(s);

    gameRef.current?.setStarMode(m === 'star');

    if (modeOf(m).equip === 'zeus') {
      gameRef.current?.equipZeus(true);
      gameRef.current?.reloadZeus(true);
    }

    if (m === 'atlas') setSel(ATLAS_IDX);
    gameRef.current?.startMatch(s.opp);
  };

  const result = hud?.result;
  const oppIndex = hud?.oppIndex ?? 0;
  const ultraNow = hud?.ultra ?? false;
  useEffect(() => {
    if (result !== 'win' && result !== 'lose') return;
    const win = result === 'win';
    if (win) {
      const next = Math.min(OPPONENTS.length - 1, oppIndex + 1);
      setUnlocked((u) => {
        const v = Math.max(u, next);
        localStorage.setItem(LS_KEY, String(v));
        return v;
      });
    }
    const cur = seriesRef.current ?? { mode: 'play' as ModeId, opp: oppIndex, done: false, won: false };
    setSeries({ ...cur, done: true, won: win });
    setProfile((p) => {
      const n = applyOutcome(p, { win, mode: cur.mode, ultra: ultraNow });
      saveProfile(n);
      return n;
    });

  }, [result, oppIndex]);

  const phase = hud?.phase ?? 'menu';
  const inMatch = phase === 'walk' || phase === 'intro' || phase === 'fight' || phase === 'ko';

  const fpsNow = hud?.fps ?? 60;
  const fpsColor = fpsNow >= 57 ? '#7dffc4' : fpsNow >= 45 ? '#ffd34a' : '#ff7a7a';

  const gfxChip = () => (
    <button
      onClick={() => {
        const i = GFX_MODES.findIndex((m) => m.id === gfxNow);
        pickGfx(GFX_MODES[(i + 1) % GFX_MODES.length].id);
      }}
      className="ghost cut-sm pointer-events-auto flex h-9 items-center gap-1.5 px-2.5 font-tech text-[9px] font-bold tracking-[0.16em]"
      style={{ color: fpsColor }}
      title={`Grafis: ${GFX_MODES.find((m) => m.id === gfxNow)?.name ?? 'OTOMATIS'} · ${hud?.gfx ?? ''} — klik untuk ganti`}
    >
      <span className="font-display text-[13px] leading-none">{Math.round(hud?.fps ?? 60)}</span>
      <span className="opacity-75">FPS</span>
      <span className="hidden opacity-60 sm:inline">· {hud?.gfx ?? 'MAKSIMAL'}</span>
    </button>
  );

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      <div ref={mount} className="absolute inset-0" />

      {hud && inMatch && <Hud h={hud} touch={touch} onPanjerMode={() => gameRef.current?.togglePanjerMode()} />}
      {inMatch && touch && phase === 'fight' && <TouchControls game={game} />}

      {/* ---------- ALI STYLE: in the LOBBY it is a chip you can see AND tap (the hero dances behind it) ---------- */}
      {phase === 'menu' && hud && (
        <button
          onClick={(e) => {
            e.currentTarget.blur();
            gameRef.current?.toggleAliStyle();
          }}
          className={`ghost cut-sm pointer-events-auto absolute bottom-3 right-3 z-20 flex h-10 items-center gap-2 px-3 font-tech text-[10px] font-black tracking-[0.16em] sm:bottom-5 sm:right-5 ${
            hud.ali ? 'text-cyan-200' : 'text-white/55'
          }`}
          style={hud.ali ? { boxShadow: '0 0 22px rgba(120,240,255,0.45)' } : undefined}
          title="ALI STYLE (tombol Y): gaya bertarung Muhammad Ali — tangan turun, badan meliuk (float), dan ALI SHUFFLE: kaki berdansa di tempat."
        >
          <span className="text-[14px] leading-none">🦋</span>
          {hud.ali ? 'ALI STYLE ON · ALI SHUFFLE' : 'ALI STYLE OFF'}
        </button>
      )}

      {phase === 'menu' && (
        <Menu
          unlocked={unlocked}
          sel={sel}
          onSel={(i) => {
            setSel(i);
            game?.selectOpponent(i);
          }}
          onStart={() => startMode('play')}
          profile={profile}
          mode={mode}
          onMode={setMode}
          onStartMode={startMode}
          sfx={sfxId}
          onSfx={pickSfx}
          ultra={ultra}
          onUltra={pickUltra}
          fw={fwNow}
          onFw={pickFw}
          cam={camNow}
          onCam={pickCam}
          iq={iqNow}
          onIq={pickIq}
          muted={muted}
          onToggleMute={() => {
            const m = !muted;
            setMuted(m);
            gameRef.current?.setMuted(m);
          }}
          bright={brightNow}
          onBright={pickBright}
          sat={satNow}
          onSat={pickSat}
          tex={texNow}
          onTex={pickTex}
          bloom={bloomNow}
          onBloom={pickBloom}
          onResetVisuals={resetVisuals}
          gfx={gfxNow}
          onGfx={pickGfx}
          pyro={pyroNow}
          onPyro={pickPyro}
          directionalHeadSnap={snapNow}
          onDirectionalHeadSnap={pickSnap}
          noSlowMoNormal={noSlowMoNormalNow}
          onNoSlowMoNormal={pickNoSlowMoNormal}
          allOverdrivePunch={allOdNow}
          onAllOverdrivePunch={pickAllOd}
          game={game}
          hud={hud}
        />
      )}

      {hud && phase === 'matchEnd' && (
        <MatchEnd
          h={hud}
          series={series}
          label={seriesLabel(series)}
          onNext={
            (!series || series.mode === 'play' || series.mode === 'star') && hud.oppIndex < OPPONENTS.length - 1
              ? () => {
                  const idx = hud.oppIndex + 1;
                  const nextMode = series?.mode ?? 'play';
                  setSeries({ mode: nextMode, opp: idx, done: false, won: false });
                  setSel(idx);
                  game?.startMatch(idx);
                }
              : null
          }
          onRetry={() => {
            if (series && series.mode !== 'play') startMode(series.mode);
            else {
              setSeries({ mode: 'play', opp: hud.oppIndex, done: false, won: false });
              game?.startMatch(hud.oppIndex);
            }
          }}
          onMenu={() => {
            setSeries(null);
            gameRef.current?.setStarMode(false); // the lobby is not a star fight
            // never park the lobby on a Titan that is still locked (the LAWAN ATLAS bout can end on ATLAS PRIME)
            const back = Math.min(unlocked, hud.oppIndex);
            setSel(back);
            game?.toMenu();
            game?.selectOpponent(back);
          }}
        />
      )}

      {hud?.paused && (
        <PauseMenu
          sfx={sfxId}
          onSfx={pickSfx}
          fw={fwNow}
          onFw={pickFw}
          cam={camNow}
          onCam={pickCam}
          iq={iqNow}
          onIq={pickIq}
          gfx={gfxNow}
          onGfx={pickGfx}
          fps={hud.fps}
          tier={hud.gfx}
          bright={brightNow}
          onBright={pickBright}
          sat={satNow}
          onSat={pickSat}
          tex={texNow}
          onTex={pickTex}
          bloom={bloomNow}
          onBloom={pickBloom}
          onResetVisuals={resetVisuals}
          pyro={pyroNow}
          onPyro={pickPyro}
          directionalHeadSnap={snapNow}
          onDirectionalHeadSnap={pickSnap}
          noSlowMoNormal={noSlowMoNormalNow}
          onNoSlowMoNormal={pickNoSlowMoNormal}
          allOverdrivePunch={allOdNow}
          onAllOverdrivePunch={pickAllOd}
          onResume={() => game?.togglePause()}
          onMenu={() => {
            game?.togglePause();
            game?.toMenu();
            game?.selectOpponent(hud.oppIndex);
          }}
        />
      )}

      {/* ---------- the live FPS / graphics chip on the lobby screen ---------- */}
      {phase === 'menu' && <div className="absolute bottom-3 left-3 z-40 flex gap-2">{gfxChip()}</div>}

      {/* ---------- utility buttons (fps / graphics / pause / sound / directional head snap / overdrive sound during match) ---------- */}
      {phase !== 'menu' && (
        <div className="absolute right-3 z-30 flex gap-2" style={inMatch ? (touch ? { top: 78 } : { bottom: 12 }) : { top: 12 }}>
          {gfxChip()}
          {inMatch && (
            <button
              onClick={() => pickAllOd(!allOdNow)}
              className={`ghost cut-sm pointer-events-auto flex h-9 items-center gap-1.5 px-2.5 font-tech text-[9px] font-bold tracking-[0.16em] transition-all ${
                allOdNow
                  ? 'border-orange-400/80 bg-orange-500/25 text-amber-200 shadow-[0_0_14px_rgba(255,120,20,0.4)]'
                  : 'border-white/20 text-white/50'
              }`}
              title="Tombol Suara: Semua Pukulan Pakai Suara Pukulan Overdrive"
            >
              <span className="text-amber-400">⚡</span>
              <span className="hidden sm:inline">SUARA OD: {allOdNow ? 'ON' : 'OFF'}</span>
              <span className="sm:hidden">{allOdNow ? 'OD ON' : 'OD OFF'}</span>
            </button>
          )}
          {inMatch && (
            <button
              onClick={() => pickNoSlowMoNormal(!noSlowMoNormalNow)}
              className={`ghost cut-sm pointer-events-auto flex h-9 items-center gap-1.5 px-2.5 font-tech text-[9px] font-bold tracking-[0.16em] transition-all ${
                noSlowMoNormalNow
                  ? 'border-amber-400/60 bg-amber-500/20 text-amber-200 shadow-[0_0_12px_rgba(251,191,36,0.3)]'
                  : 'border-white/20 text-white/50'
              }`}
              title="Mode No Slow-Mo saat serangan biasa, kecuali Overdrive (Tekan O)"
            >
              <span>{noSlowMoNormalNow ? '⚡' : '⏱️'}</span>
              <span className="hidden sm:inline">SLOW-MO: {noSlowMoNormalNow ? 'HANYA OD' : 'SEMUA'}</span>
              <span className="sm:hidden">{noSlowMoNormalNow ? 'NO SLOW' : 'SLOW'}</span>
            </button>
          )}
          {inMatch && (
            <button
              onClick={() => pickSnap(!snapNow)}
              className={`ghost cut-sm pointer-events-auto flex h-9 items-center gap-1.5 px-2.5 font-tech text-[9px] font-bold tracking-[0.16em] transition-all ${
                snapNow
                  ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-200 shadow-[0_0_12px_rgba(52,211,153,0.3)]'
                  : 'border-white/20 text-white/50'
              }`}
              title="Toggle Directional Head Snap (Tekan 0)"
            >
              <span>{snapNow ? '⚡' : '⚪'}</span>
              <span className="hidden sm:inline">HEAD SNAP: {snapNow ? 'ON' : 'OFF'}</span>
            </button>
          )}
          {inMatch && (
            <button
              onClick={() => pickCam((camNow + 1) % CAM_MODES.length)}
              className="ghost cut-sm pointer-events-auto flex h-9 items-center gap-1.5 px-2.5 font-tech text-[9px] font-bold tracking-[0.16em] text-sky-200"
              title="Ganti mode kamera ( / dan . )"
            >
              <span>🎥</span>
              <span className="hidden sm:inline">{CAM_MODES[camNow]?.name ?? 'KAMERA'}</span>
            </button>
          )}
          {inMatch && (
            <button onClick={() => game?.togglePause()} className="ghost cut-sm pointer-events-auto grid h-9 w-9 place-items-center" title="Pause (Esc)">
              <IconPause />
            </button>
          )}
          <button
            onClick={() => {
              const m = !muted;
              setMuted(m);
              gameRef.current?.setMuted(m);
            }}
            className="ghost cut-sm pointer-events-auto grid h-9 w-11 place-items-center"
            title={muted ? 'Suara mati' : 'Suara menyala'}
          >
            <IconSound off={muted} />
          </button>
        </div>
      )}

    </div>
  );
}
