import { memo, useCallback, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { Game } from "./game/engine";
import type { BasicType } from "./game/engine";
import { CANNON_DEF, FACTIONS, FACTION_IDS, GOLD_MAX, H, HERO_COST, HERO_DEFS, MATCH_TIME, PHASE_NAME, SIEGE_MULT, SQUAD_TYPES, TYPE_NAME, UNIT_DEFS, UNIT_MODS, W, WAVE_TIME, unitCost } from "./game/constants";
import type { Difficulty, FactionId, HeroKind } from "./game/constants";
import { sfx } from "./game/audio";
import { matchup } from "./game/advisor";
import { LESSONS, SHAPE_NAME } from "./game/tutorial";
import type { Outcome, Verdict } from "./game/tutorial";
import type { Advice } from "./game/advisor";
import UnitIcon, { Emblem } from "./components/UnitIcon";

interface Snap {
  state: Game["state"];
  gold: number;
  hp: [number, number];
  max: [number, number];
  left: number;
  played: number;
  phase: number;
  reason: Game["endReason"];
  selected: BasicType;
  pendingHero: HeroKind | null;
  pendingCannon: boolean;
  heroCd: Record<string, number>;
  counts: number[];
  stats: Game["stats"];
  hint: number;
  phaseT: number;
  wave: number;
  ready: [Record<string, number>, Record<string, number>];
  income: number;
  lastIncome: number[];
  cannons: number;
  blood: boolean;
  fac: [FactionId, FactionId];
  advice: Advice | null;
  adviceN: number;
  adviceI: number;
  /** how well every card suits the battle right now (card key -> 0..3), while the advisor is open */
  adviceFit: Record<string, number>;
  /** command: squads selected, their soldiers, how many still wait for the horn, gold if those are called off */
  sel: number;
  selMen: number;
  selReady: number;
  selRefund: number;
  cmdMode: boolean;
  cmdHint: number;
  /** the tutorial lesson being played */
  tut: null | { i: number; n: number; phase: "plan" | "fight" | "result" | "done"; placed: number; shape: string; out: Outcome | null; verdict: Verdict | null; passed: boolean[] };
}

type Foe = FactionId | "random";
type QMode = "auto" | "low" | "high";
const SPEEDS = [1, 1.5, 2];
const INK = "#3b2a1a";
const TUT_KEY = "tinybanners.tutorial";
const QLABEL: Record<QMode, string> = { auto: "Auto", low: "Hemat", high: "Tinggi" };
const SHORT: Record<FactionId, string> = { crusader: "Salib", arab: "Arab", viking: "Viking", samurai: "Samurai" };

function fmtClock(t: number) {
  const s = Math.max(0, Math.ceil(t));
  return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
}

function snap(g: Game): Snap {
  let selMen = 0;
  let selReady = 0;
  let selRefund = 0;
  for (const s of g.selection) {
    selMen += s.alive;
    if (s.state === "ready") {
      selReady++;
      selRefund += g.refundOf(s);
    }
  }
  const adviceFit: Record<string, number> = {};
  if (g.advice) for (const a of g.adviceList) adviceFit[a.key] = a.fit;
  return {
    state: g.state,
    gold: Math.floor(g.gold[0]),
    hp: [g.castles[0].hp, g.castles[1].hp],
    max: [g.castles[0].max, g.castles[1].max],
    left: MATCH_TIME - g.matchT,
    played: g.matchT,
    phase: g.phase,
    reason: g.endReason,
    selected: g.selected,
    pendingHero: g.pendingHero,
    pendingCannon: g.pendingCannon,
    heroCd: { ...g.heroCd },
    counts: g.counts(),
    stats: { ...g.stats },
    hint: g.hint,
    phaseT: g.phaseT,
    wave: g.wave,
    ready: [g.readyCounts(0), g.readyCounts(1)],
    income: g.income(),
    lastIncome: [...g.lastIncome],
    cannons: g.cannonCount(0),
    blood: g.blood,
    fac: [g.factions[0], g.factions[1]],
    advice: g.advice,
    adviceN: g.adviceList.length,
    adviceI: g.adviceIdx,
    adviceFit,
    sel: g.selection.length,
    selMen,
    selReady,
    selRefund,
    cmdMode: g.cmdMode,
    cmdHint: g.cmdHint,
    tut: g.tut ? { i: g.tut.i, n: LESSONS.length, phase: g.tut.phase, placed: g.tut.placed.length, shape: g.tut.placed.length ? SHAPE_NAME[g.tut.placed[g.tut.placed.length - 1].shape] : "", out: g.tut.out, verdict: g.tut.verdict, passed: [...g.tut.passed] } : null,
  };
}

const randomOther = (f: FactionId) => {
  const o = FACTION_IDS.filter((x) => x !== f);
  return o[Math.floor(Math.random() * o.length)];
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  if (!gameRef.current) gameRef.current = new Game();
  const game = gameRef.current;

  const [stage, setStage] = useState({ w: 1280, h: 720 });
  const [ui, setUi] = useState<Snap>(() => snap(game));
  const [goldFx, setGoldFx] = useState<{ k: number; cls: string }>({ k: 0, cls: "" });
  const [diff, setDiff] = useState<Difficulty>("normal");
  const [pick, setPick] = useState<FactionId>("crusader");
  const [foe, setFoe] = useState<Foe>("random");
  const rolled = useRef<FactionId>("viking");
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(1);
  const speedRef = useRef(1);
  const [qmode, setQmode] = useState<QMode>("auto");
  const quality = useRef({ mode: "auto" as QMode, scale: 1, ema: 16.7, work: 3, base: 16.7, hold: 120, n: 0 });
  const applyRes = useRef<() => void>(() => {});
  const [hpFx, setHpFx] = useState([0, 0]);
  const [launchKey, setLaunchKey] = useState(0);
  const [phaseKey, setPhaseKey] = useState(0);
  const [tickKey, setTickKey] = useState(0);
  const lastHp = useRef([0, 0]);

  useEffect(() => {
    const onResize = () => {
      const w = Math.min(window.innerWidth, (window.innerHeight * 16) / 9);
      setStage({ w: Math.floor(w), h: Math.floor((w * 9) / 16) });
    };
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    const cv = canvasRef.current!;
    const ctx = cv.getContext("2d", { alpha: false })!;
    const q = quality.current;
    // internal resolution follows the quality setting; "auto" lowers it when frames get slow
    applyRes.current = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, q.mode === "high" ? 2 : 1.5);
      const s = dpr * (q.mode === "low" ? 0.62 : q.mode === "high" ? 1 : q.scale);
      cv.width = Math.max(320, Math.round(stage.w * s));
      cv.height = Math.max(180, Math.round(stage.h * s));
      game.pxScale = cv.width / W;
    };
    applyRes.current();
    let raf = 0;
    let last = performance.now();
    let uiT = 0;
    const loop = (now: number) => {
      const frame = now - last;
      const dt = Math.min(0.1, frame / 1000);
      last = now;
      // fixed sub-steps keep the battle identical at 1x, 1.5x and 2x speed
      let acc = dt * speedRef.current;
      let n = 0;
      while (acc > 0.0005 && n++ < 8) {
        const s = Math.min(acc, 1 / 30);
        game.update(s);
        acc -= s;
      }
      sfx.ambientTick(dt);
      game.render(ctx, cv.width / W);
      // ---- adaptive quality
      if (frame < 200) {
        q.n++;
        q.work += (performance.now() - now - q.work) * 0.06;
        if (q.n <= 40) {
          // warm-up: measure the display's own frame time (60 Hz, 30 Hz, ...)
          q.ema = q.n === 1 ? frame : q.ema + (frame - q.ema) / q.n;
          q.base = q.ema;
        } else {
          q.ema += (frame - q.ema) * 0.06;
          q.base = Math.min(q.base, q.ema);
        }
        if (q.mode === "auto" && q.n > 40 && --q.hold <= 0) {
          q.hold = 40;
          if ((q.ema > q.base * 1.45 + 2 || q.ema > 40) && q.scale > 0.55) {
            q.scale = Math.max(0.55, q.scale - 0.15);
            q.hold = 110;
            q.ema = q.base * 1.2;
            applyRes.current();
          } else if (q.ema < q.base * 1.12 + 1 && q.work < 6 && q.scale < 1) {
            q.scale = Math.min(1, q.scale + 0.1);
            q.hold = 320;
            applyRes.current();
          }
        }
      }
      uiT += dt;
      if (uiT > 0.16 || game.events.length) {
        uiT = 0;
        setUi(snap(game));
        for (const e of game.events) {
          if (e.type === "nogold") setGoldFx((g) => ({ k: g.k + 1, cls: "shake-x" }));
          if (e.type === "deploy" || e.type === "hero" || e.type === "refund") setGoldFx((g) => ({ k: g.k + 1, cls: "squish" }));
          if (e.type === "launch") {
            setLaunchKey((k) => k + 1);
            setGoldFx((g) => ({ k: g.k + 1, cls: "squish" }));
          }
          if (e.type === "phase") setPhaseKey((k) => k + 1);
          if (e.type === "tick") setTickKey((k) => k + 1);
        }
        game.events.length = 0;
        const hp = [game.castles[0].hp, game.castles[1].hp];
        if (hp[0] < lastHp.current[0] || hp[1] < lastHp.current[1]) {
          setHpFx((f) => [hp[0] < lastHp.current[0] ? f[0] + 1 : f[0], hp[1] < lastHp.current[1] ? f[1] + 1 : f[1]]);
        }
        lastHp.current = hp;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [stage, game]);

  // the menu backdrop shows the chosen factions: their castles, lands and soldiers
  useEffect(() => {
    if (foe === pick) {
      setFoe("random");
      return;
    }
    if (foe === "random" && rolled.current === pick) rolled.current = randomOther(pick);
    if (game.state !== "menu") return;
    game.setFactions(pick, foe === "random" ? rolled.current : foe);
    game.reset(game.diff);
    game.state = "menu";
    game.spawnDemo();
    setUi(snap(game));
  }, [pick, foe, game]);

  const toLogical = useCallback((e: { clientX: number; clientY: number }) => {
    const r = canvasRef.current!.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * W, y: ((e.clientY - r.top) / r.height) * H };
  }, []);

  useEffect(() => {
    const up = () => game.pointerUp();
    const move = (e: PointerEvent) => {
      const p = toLogical(e);
      game.pointerMove(p.x, p.y);
    };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointermove", move);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointermove", move);
    };
  }, [game, toLogical]);

  const selectType = useCallback(
    (t: BasicType) => {
      game.selected = t;
      game.pendingHero = null;
      game.pendingCannon = false;
      game.cmdMode = false;
      if (game.advice) game.showAdvice(t); // with the advisor open, a card shows its verdict
      sfx.ensure();
      sfx.click();
      setUi(snap(game));
    },
    [game]
  );
  const pickHero = useCallback(
    (h: HeroKind) => {
      sfx.ensure();
      game.selectHero(h);
      if (game.advice) game.showAdvice(h);
      setUi(snap(game));
    },
    [game]
  );
  const pickCannon = useCallback(() => {
    sfx.ensure();
    game.selectCannon();
    if (game.advice) game.showAdvice("cannon");
    setUi(snap(game));
  }, [game]);
  // the advisor: H asks (or shows the next idea), Enter deploys what it suggests
  const askHint = useCallback(() => {
    sfx.ensure();
    if (game.state !== "playing") return;
    if (game.advice) game.nextAdvice();
    else game.askAdvice();
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const applyHint = useCallback(() => {
    sfx.ensure();
    game.applyAdvice();
    setUi(snap(game));
  }, [game]);
  const closeHint = useCallback(() => {
    game.closeAdvice();
    sfx.click();
    setUi(snap(game));
  }, [game]);
  // command: orders for the squads the player has selected
  const giveOrder = useCallback(
    (kind: "hold" | "free" | "retreat") => {
      sfx.ensure();
      game.order(kind);
      setUi(snap(game));
    },
    [game]
  );
  const refundSel = useCallback(() => {
    game.refundSelected();
    setUi(snap(game));
  }, [game]);
  const clearSel = useCallback(() => {
    game.clearSelection();
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const selectAll = useCallback(() => {
    sfx.ensure();
    game.selectAll();
    setUi(snap(game));
  }, [game]);
  const toggleCmd = useCallback(() => {
    sfx.ensure();
    game.cmdMode = !game.cmdMode;
    game.drawing = null;
    game.pendingHero = null;
    game.pendingCannon = false;
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const togglePause = useCallback(() => {
    if (game.state === "playing") game.state = "paused";
    else if (game.state === "paused") game.state = "playing";
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const toggleMute = useCallback(() => {
    sfx.setMuted(!sfx.muted);
    setMuted(sfx.muted);
  }, []);
  const cycleSpeed = useCallback(() => {
    const next = SPEEDS[(SPEEDS.indexOf(speedRef.current) + 1) % SPEEDS.length];
    speedRef.current = next;
    setSpeed(next);
    sfx.click();
  }, []);
  const cycleQuality = useCallback(() => {
    const q = quality.current;
    q.mode = q.mode === "auto" ? "low" : q.mode === "low" ? "high" : "auto";
    q.scale = 1;
    q.hold = 120;
    applyRes.current();
    setQmode(q.mode);
    sfx.click();
  }, []);
  const toggleBlood = useCallback(() => {
    game.blood = !game.blood;
    if (!game.blood) {
      game.decals = game.decals.filter((d) => d.kind === "crater");
      game.clearGround();
    }
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const startGame = useCallback(
    (pf: FactionId, ef: FactionId) => {
      sfx.ensure();
      sfx.startAmbient();
      game.start(diff, pf, ef);
      setLaunchKey(0);
      setPhaseKey(0);
      lastHp.current = [game.castles[0].hp, game.castles[1].hp];
      setUi(snap(game));
    },
    [game, diff]
  );
  const toMenu = useCallback(() => {
    game.setFactions(pick, foe === "random" || foe === pick ? rolled.current : foe);
    game.reset(game.diff);
    game.state = "menu";
    game.spawnDemo();
    sfx.click();
    setUi(snap(game));
  }, [game, pick, foe]);

  // ---- tutorial: lessons passed are remembered on this device
  const [tutDone, setTutDone] = useState<boolean[]>(() => {
    try {
      const v = JSON.parse(localStorage.getItem(TUT_KEY) || "[]");
      return LESSONS.map((_, i) => !!v[i]);
    } catch {
      return LESSONS.map(() => false);
    }
  });
  const tutPassed = ui.tut ? ui.tut.passed.join() : "";
  useEffect(() => {
    if (!tutPassed || tutPassed === tutDone.join()) return;
    const p = tutPassed.split(",").map((x) => x === "true");
    setTutDone(p);
    try {
      localStorage.setItem(TUT_KEY, JSON.stringify(p));
    } catch {
      /* storage not available: progress lasts for this visit only */
    }
  }, [tutPassed, tutDone]);
  const startTutorial = useCallback(() => {
    sfx.ensure();
    sfx.startAmbient();
    const next = tutDone.findIndex((p) => !p);
    game.startTutorial(next < 0 ? 0 : next, pick, [...tutDone]);
    setLaunchKey(0);
    setPhaseKey(0);
    setUi(snap(game));
  }, [game, pick, tutDone]);
  const tutLaunch = useCallback(() => {
    sfx.ensure();
    game.tutLaunch();
    setUi(snap(game));
  }, [game]);
  const tutRetry = useCallback(() => {
    game.tutRetry();
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const tutNext = useCallback(() => {
    game.tutNext();
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const tutGoto = useCallback(
    (i: number) => {
      game.tutGoto(i);
      sfx.click();
      setUi(snap(game));
    },
    [game]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "escape" && game.selection.length) return clearSel();
      if (k === "escape" && game.advice) return closeHint();
      if (k === "escape" || k === "p") {
        if (game.pendingHero || game.drawing || game.pendingCannon) {
          game.pendingHero = null;
          game.drawing = null;
          game.pendingCannon = false;
        } else togglePause();
        return;
      }
      if (k === "m") return toggleMute();
      if (k === "f") return cycleSpeed();
      if (game.state !== "playing") return;
      const T = game.tut;
      if (T) {
        // in a lesson Enter does the obvious next thing
        if (k === "enter" || k === " ") {
          e.preventDefault();
          if (T.phase === "plan" && game.advice && game.advice.kind !== "wait" && T.placed.length < LESSONS[T.i].max) return applyHint();
          if (T.phase === "plan") return tutLaunch();
          if (T.phase === "result") return T.verdict && T.verdict.pass ? tutNext() : tutRetry();
          return;
        }
        if (k === "h" && !LESSONS[T.i].advisor) return;
        if (k === "c" && !LESSONS[T.i].command) return;
      }
      if (k === "h") return askHint();
      if (k === "c") return toggleCmd();
      if (k === "a") return selectAll();
      if (game.selection.length) {
        if (k === "t") return giveOrder("hold");
        if (k === "s") return giveOrder("free");
        if (k === "r") return giveOrder("retreat");
        if (k === "delete" || k === "backspace") return refundSel();
      }
      if ((k === "enter" || k === " ") && game.advice) {
        e.preventDefault();
        return applyHint();
      }
      const idx = "12345678".indexOf(k);
      if (k.length === 1 && idx >= 0) selectType(SQUAD_TYPES[idx]);
      if (k === "9") pickCannon();
      if (k === "q") pickHero(game.fac[0].heroes[0]);
      if (k === "w") pickHero(game.fac[0].heroes[1]);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [game, togglePause, toggleMute, cycleSpeed, selectType, pickHero, pickCannon, askHint, applyHint, closeHint, giveOrder, refundSel, clearSel, selectAll, toggleCmd, tutLaunch, tutNext, tutRetry]);

  const scale = stage.w / W;
  const playing = ui.state === "playing" || ui.state === "paused";
  const finalCount = ui.state === "playing" && ui.left <= 10 && ui.left > 0;

  return (
    <div className="app-bg w-full h-full flex items-center justify-center">
      <div className="relative overflow-hidden stage-frame" style={{ width: stage.w, height: stage.h }} onContextMenu={(e) => e.preventDefault()}>
        <canvas
          ref={canvasRef}
          className="absolute inset-0 block"
          style={{ width: stage.w, height: stage.h, cursor: "crosshair", touchAction: "none" }}
          onContextMenu={(e) => e.preventDefault()}
          onPointerDown={(e) => {
            const p = toLogical(e);
            game.pointerMove(p.x, p.y);
            game.pointerDown(p.x, p.y, e.button, e.shiftKey);
          }}
        />
        <div className="hud-root absolute top-0 left-0 pointer-events-none font-body" style={{ width: W, height: H, transform: `scale(${scale})`, transformOrigin: "top left" }}>
          {playing && (
            <>
              {ui.tut ? (
                <Tutorial ui={ui} onLaunch={tutLaunch} onRetry={tutRetry} onNext={tutNext} onGoto={tutGoto} onExit={toMenu} onPlay={() => startGame(pick, foe === "random" ? randomOther(pick) : foe)} />
              ) : (
                <TopHud ui={ui} hpFx={hpFx} tickKey={tickKey} />
              )}
              {(!ui.tut || LESSONS[ui.tut.i].advisor) && <Advisor ui={ui} onAsk={askHint} onApply={applyHint} onClose={closeHint} />}
              {(!ui.tut || LESSONS[ui.tut.i].command) && <Command ui={ui} onOrder={giveOrder} onRefund={refundSel} onClear={clearSel} onAll={selectAll} onMode={toggleCmd} />}
              {!ui.tut && ui.cmdHint > 0 && ui.wave >= 2 && ui.played < 70 && ui.counts[0] > 0 && ui.state === "playing" && (
                <div className="absolute left-1/2 top-[158px] -translate-x-1/2">
                  <div className="parch rounded-2xl px-5 py-2 text-center">
                    <div className="font-title text-[19px] leading-tight" style={{ color: "#a3242b" }}>
                      Kamu panglimanya!
                    </div>
                    <div className="text-[15px] ink-text leading-snug">
                      <span className="font-title">Klik kanan + seret</span> melewati pasukanmu untuk memilih, lalu <span className="font-title">klik kanan</span> tujuan atau musuh
                    </div>
                  </div>
                </div>
              )}
              {launchKey > 0 && <LaunchBanner key={"l" + launchKey} wave={ui.wave - 1} income={ui.lastIncome[0]} color={FACTIONS[ui.fac[0]]} />}
              {phaseKey > 0 && ui.phase > 0 && <PhaseBanner key={"p" + phaseKey} phase={ui.phase} />}
              {finalCount && (
                <div key={Math.ceil(ui.left)} className="absolute left-1/2 top-[168px] -translate-x-1/2 pop-in">
                  <span className="font-title text-[120px] leading-none text-[#fff4e0] big-stroke">{Math.ceil(ui.left)}</span>
                </div>
              )}
              <Dock
                ui={ui}
                goldFx={goldFx}
                onSelect={selectType}
                onHero={pickHero}
                onCannon={pickCannon}
                onPause={togglePause}
                onMute={toggleMute}
                onBlood={toggleBlood}
                onSpeed={cycleSpeed}
                onQuality={cycleQuality}
                speed={speed}
                muted={muted}
                qmode={qmode}
                allow={ui.tut ? LESSONS[ui.tut.i].allow : undefined}
              />
              {ui.hint > 0 && ui.state === "playing" && !ui.advice && (
                <div className="absolute left-[418px] top-[530px] -translate-x-1/2 floaty">
                  <div className="parch rounded-2xl px-6 py-3 text-center">
                    <div className="font-title text-[22px] ink-text leading-tight">Tahan &amp; seret di zonamu</div>
                    <div className="text-[15px] text-[#6b4a2c] leading-snug">
                      20 prajurit berbaris mengikuti garismu,
                      <br />
                      lalu menyerbu saat terompet tiap {WAVE_TIME} detik
                    </div>
                    <div className="text-[15px] leading-snug mt-1" style={{ color: "#a3242b" }}>
                      Bingung? Tekan <span className="font-title">H</span> — penasihat menyarankan pasukan &amp; posisinya
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          {ui.state === "menu" && (
            <Menu diff={diff} setDiff={setDiff} pick={pick} setPick={setPick} foe={foe} setFoe={setFoe} blood={ui.blood} onBlood={toggleBlood} onStart={() => startGame(pick, foe === "random" ? randomOther(pick) : foe)} onTutorial={startTutorial} tutDone={tutDone.filter(Boolean).length} />
          )}
          {ui.state === "paused" && <PauseOverlay onResume={togglePause} onMenu={toMenu} blood={ui.blood} onBlood={toggleBlood} />}
          {(ui.state === "won" || ui.state === "lost") && <EndOverlay ui={ui} onRetry={() => startGame(ui.fac[0], ui.fac[1])} onMenu={toMenu} />}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  small building blocks                                              */
/* ================================================================== */

function Ribbon({ children, color = "#e0444b", dark = "#9c2229", className = "" }: { children: ReactNode; color?: string; dark?: string; className?: string }) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <span className="absolute -left-3 top-[6px] w-5 h-[calc(100%-2px)]" style={{ background: dark, clipPath: "polygon(0 0,100% 0,100% 100%,0 100%,40% 50%)" }} />
      <span className="absolute -right-3 top-[6px] w-5 h-[calc(100%-2px)]" style={{ background: dark, clipPath: "polygon(0 0,100% 0,60% 50%,100% 100%,0 100%)" }} />
      <span
        className="relative px-4 py-0.5 font-title text-[#fff8ea] border-[3px] rounded-[6px] whitespace-nowrap"
        style={{ background: `linear-gradient(180deg, ${color}, ${dark})`, borderColor: INK, textShadow: `0 2px 0 ${INK}`, boxShadow: "inset 0 2px 0 rgba(255,255,255,0.3)" }}
      >
        {children}
      </span>
    </div>
  );
}

const svg = (children: ReactNode, size = 22) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);
const IcoPause = svg(
  <>
    <rect x="5" y="4" width="5" height="16" rx="1.5" fill="currentColor" stroke="none" />
    <rect x="14" y="4" width="5" height="16" rx="1.5" fill="currentColor" stroke="none" />
  </>
);
const IcoSound = (on: boolean) =>
  svg(
    <>
      <path d="M4 9v6h4l5 4V5L8 9z" fill="currentColor" />
      {on ? <path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12" /> : <path d="M17 9l5 6M22 9l-5 6" />}
    </>
  );
const IcoDrop = (on: boolean) => svg(<path d="M12 3c3 4.5 6 7.6 6 11a6 6 0 0 1-12 0c0-3.4 3-6.5 6-11z" fill={on ? "#c8323a" : "none"} />);
const IcoBolt = svg(<path d="M13 2 5 13h5l-1 9 8-12h-5z" fill="currentColor" stroke="none" />, 18);

const IcoBulb = svg(
  <>
    <path d="M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.3 1 2.2h5.2c0-.9.4-1.7 1-2.2A6 6 0 0 0 12 3z" fill="#ffe58f" />
    <path d="M9.5 19h5M10.5 21.5h3" />
  </>,
  24
);

/* ================================================================== */
/*  advisor                                                            */
/* ================================================================== */

const FIT_LABEL = ["Kurang cocok", "Bisa dipakai", "Cocok", "Sangat cocok"];
const FIT_COLOR = ["#c0392b", "#b7791f", "#5c9a1f", "#1f8a3b"];
const Tri = ({ up }: { up: boolean }) => (
  <svg viewBox="0 0 10 10" width="10" height="10" className="shrink-0 mt-[3px]">
    <path d={up ? "M5 1l4.5 8h-9z" : "M5 9L.5 1h9z"} fill={up ? "#1f8a3b" : "#c0392b"} stroke={INK} strokeWidth="1" strokeLinejoin="round" />
  </svg>
);
/** what a troop type beats and what beats it (compact: two names each, on one line when they fit) */
function Versus({ faction, type, compact = false }: { faction: FactionId; type: BasicType; compact?: boolean }) {
  const m = matchup(faction, type);
  const row = (up: boolean, list: BasicType[]) => (
    <div className="flex items-start gap-1">
      <Tri up={up} />
      <span>
        {!compact && <span className="text-[#8a5a2c]">{up ? "Menang: " : "Kalah: "}</span>}
        {list.length ? list.slice(0, compact ? 2 : 3).map((t) => TYPE_NAME[t]).join(", ") : "—"}
      </span>
    </div>
  );
  return (
    <div className={`ink-text leading-[1.25] ${compact ? "text-[12px] flex flex-wrap gap-x-3" : "text-[12.5px]"}`}>
      {row(true, m.strong)}
      {row(false, m.weak)}
    </div>
  );
}

/** "Penasihat": rates every card for the battle as it stands, and shows where the chosen one goes and why */
function Advisor({ ui, onAsk, onApply, onClose }: { ui: Snap; onAsk: () => void; onApply: () => void; onClose: () => void }) {
  const a = ui.advice;
  const fid = ui.fac[0];
  const f = FACTIONS[fid];
  if (ui.state !== "playing") return null;
  if (!a)
    return (
      <>
        <button onClick={onAsk} title="Minta saran penasihat: pasukan apa dan di mana (H)" className="menu-btn pointer-events-auto absolute left-[10px] top-[112px] h-[48px] pl-2.5 pr-3.5 rounded-2xl parch flex items-center gap-2 font-title text-[19px] ink-text">
          {IcoBulb} Saran
          <span className="text-[13px] px-1.5 rounded text-[#fff8ea] leading-[1.35]" style={{ background: INK }}>
            H
          </span>
        </button>
        {/* the troop type in hand: what it beats, what beats it */}
        <div className="absolute left-[10px] top-[170px] w-[198px] parch rounded-xl px-2.5 py-1.5 !shadow-[0_3px_0_#3b2a1a]">
          {ui.pendingHero ? (
            <>
              <div className="font-title text-[15px] leading-tight" style={{ color: f.dark }}>
                {HERO_DEFS[ui.pendingHero].name}
              </div>
              <div className="text-[12.5px] ink-text leading-[1.25]">{HERO_DEFS[ui.pendingHero].title}</div>
            </>
          ) : ui.pendingCannon ? (
            <>
              <div className="font-title text-[15px] leading-tight" style={{ color: f.dark }}>
                Meriam
              </div>
              <div className="text-[12.5px] ink-text leading-[1.25]">Menembus tembok istana. Rapuh: lindungi dengan garis depan.</div>
            </>
          ) : (
            <>
              <div className="font-title text-[15px] leading-tight" style={{ color: f.dark }}>
                {f.unitNames[ui.selected]} <span className="font-body text-[12px] text-[#8a5a2c]">· {TYPE_NAME[ui.selected]}</span>
              </div>
              <Versus faction={fid} type={ui.selected} />
            </>
          )}
        </div>
      </>
    );
  const can = a.ok && a.kind !== "wait";
  const big = a.kind === "cannon" || (a.kind === "squad" && !!a.type && !!UNIT_DEFS[a.type].mounted) || (a.kind === "hero" && !!a.hero && !!HERO_DEFS[a.hero].mounted);
  return (
    <div className="pointer-events-auto absolute left-[8px] top-[96px] w-[204px] parch rounded-2xl px-3 pt-2 pb-2">
      <button onClick={onClose} title="Tutup (Esc)" className="menu-btn absolute top-[6px] right-[6px] w-[24px] h-[24px] rounded-lg font-title text-[17px] leading-none text-[#fff8ea] flex items-center justify-center" style={{ background: INK }}>
        ×
      </button>
      {a.kind === "wait" ? (
        <span className="flex items-center gap-1 font-title text-[17px]" style={{ color: f.dark }}>
          {IcoBulb} Penasihat
        </span>
      ) : (
        <div className="flex items-center gap-2 pr-5">
          <div className="w-[50px] h-[50px] rounded-xl border-2 flex items-end justify-center overflow-hidden shrink-0" style={{ borderColor: INK, background: "linear-gradient(180deg,#d9f2ff,#b6ea78 75%)" }}>
            <UnitIcon faction={fid} type={a.kind === "squad" && a.type ? a.type : a.kind === "cannon" ? "cannon" : "hero"} hero={a.kind === "hero" ? a.hero : undefined} size={48} zoom={big ? 1.65 : 2.15} />
          </div>
          <div className="min-w-0">
            <div className="font-title text-[17px] ink-text leading-[1.05]">{a.name}</div>
            <div className="text-[12px] text-[#8a5a2c] leading-tight mb-[3px]">
              {a.kind === "squad" ? `20 × ${a.role}` : a.role}
              {a.star ? " · andalan" : ""}
            </div>
            <CoinBadge cost={a.cost} ok={ui.gold >= a.cost} />
          </div>
        </div>
      )}
      <div className="font-title text-[15px] leading-[1.22] mt-1.5" style={{ color: f.dark }}>
        {a.kind !== "wait" && (
          <span className="inline-block align-[1px] mr-1.5 text-[11.5px] leading-[1.4] px-1.5 rounded text-white whitespace-nowrap" style={{ background: FIT_COLOR[a.fit] }}>
            {FIT_LABEL[a.fit]}
          </span>
        )}
        {a.title}
      </div>
      <div className="text-[12.5px] text-[#4a3320] leading-[1.2] mt-0.5">{a.reason}</div>
      {a.kind === "squad" && a.type && (
        <div className="mt-1.5 pt-1" style={{ borderTop: "2px solid rgba(59,42,26,0.18)" }} title="Segitiga hijau: jenis yang dikalahkannya. Merah: jenis yang mengalahkannya.">
          <Versus faction={fid} type={a.type} compact />
        </div>
      )}
      <div className="flex gap-1.5 mt-2">
        {a.kind !== "wait" && (
          <button
            onClick={onApply}
            title={can ? "Pasang sesuai saran (Enter)" : a.blocked}
            className={`menu-btn flex-1 h-[36px] rounded-xl border-[3px] font-title text-[#fff8ea] whitespace-nowrap ${can ? "text-[17px]" : "text-[13px] card-off"}`}
            style={{ borderColor: INK, background: `linear-gradient(180deg, ${f.main}, ${f.dark})`, boxShadow: `0 3px 0 ${INK}`, textShadow: `0 2px 0 ${INK}` }}
          >
            {can ? "Pasang" : a.blocked ?? "Pasang"}
          </button>
        )}
        {ui.adviceN > 1 && (
          <button onClick={onAsk} title="Lihat saran untuk kartu berikutnya (H)" className="menu-btn h-[36px] px-2.5 rounded-xl border-[3px] font-title text-[14px] whitespace-nowrap" style={pill(false)}>
            Lain {ui.adviceI + 1}/{ui.adviceN}
          </button>
        )}
      </div>
      <div className="text-[11.5px] text-[#8a5a2c] leading-tight mt-1.5 whitespace-nowrap">Klik kartu lain = lihat sarannya</div>
    </div>
  );
}

const IcoFlag = svg(
  <>
    <path d="M6 21V4" />
    <path d="M6 4.5c4-2 6 2 11 0v8c-5 2-7-2-11 0z" fill="#ffd04a" />
  </>,
  24
);
const Key = ({ k }: { k: string }) => (
  <span className="text-[12px] px-1.5 rounded text-[#fff8ea] leading-[1.4] font-title" style={{ background: INK }}>
    {k}
  </span>
);

/* ================================================================== */
/*  tutorial                                                           */
/* ================================================================== */
const SHAPE_PICS: [string, string, number[][]][] = [
  ["Tembok", "garis atas-bawah", [[18, 4], [18, 9.5], [18, 15], [18, 20.5], [18, 26], [18, 31.5], [18, 37]]],
  ["Kolom", "garis ke arah musuh", [[3, 20], [8.5, 20], [14, 20], [19.5, 20], [25, 20], [30.5, 20], [36, 20]]],
  ["Baji", "bentuk V", [[10, 5], [15, 10], [20, 15], [25, 20], [20, 25], [15, 30], [10, 35]]],
  ["Gerombol", "klik sekali", [[13, 14], [19, 14], [25, 14], [13, 20], [19, 20], [25, 20], [13, 26], [19, 26], [25, 26]]],
];

function TutBtn({ children, onClick, primary, disabled, color = "#e0444b", dark = "#9c2229", title }: { children: ReactNode; onClick: () => void; primary?: boolean; disabled?: boolean; color?: string; dark?: string; title?: string }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`menu-btn h-[40px] px-4 rounded-xl border-[3px] font-title text-[18px] whitespace-nowrap ${disabled ? "card-off" : ""}`}
      style={primary ? { borderColor: INK, background: `linear-gradient(180deg, ${color}, ${dark})`, color: "#fff8ea", boxShadow: `0 4px 0 ${INK}`, textShadow: `0 2px 0 ${INK}` } : pill(false)}
    >
      {children}
    </button>
  );
}

/** the lesson panel: the situation and the task, then what happened and WHY */
function Tutorial({ ui, onLaunch, onRetry, onNext, onGoto, onExit, onPlay }: { ui: Snap; onLaunch: () => void; onRetry: () => void; onNext: () => void; onGoto: (i: number) => void; onExit: () => void; onPlay: () => void }) {
  const T = ui.tut!;
  const L = LESSONS[T.i];
  const f = FACTIONS[ui.fac[0]];
  const v = T.verdict;
  const done = T.phase === "done";
  const acting = T.phase === "plan" || (T.phase === "fight" && !!L.live);
  const tag = "font-title text-[13px] leading-[1.5] px-2 rounded text-white whitespace-nowrap";
  return (
    <div className="pointer-events-auto absolute left-[632px] top-[10px] w-[762px] parch rounded-2xl px-4 pt-2.5 pb-3">
      <div className="flex items-center gap-2.5">
        <span className={tag} style={{ background: f.dark }}>
          TUTORIAL {done ? "SELESAI" : `${T.i + 1}/${T.n}`}
        </span>
        <span className="font-title text-[22px] ink-text leading-none whitespace-nowrap">{done ? "Kamu siap berperang" : L.title}</span>
        <div className="flex-1" />
        <div className="flex gap-[5px]">
          {T.passed.map((p, i) => (
            <button
              key={i}
              onClick={() => onGoto(i)}
              title={`Pelajaran ${i + 1}: ${LESSONS[i].title}`}
              className="menu-btn w-[19px] h-[19px] rounded-full border-2 font-title text-[10.5px] leading-none flex items-center justify-center"
              style={{ borderColor: INK, background: p ? "#35b45a" : i === T.i && !done ? "#ffd04a" : "#efe2c2", color: p ? "#fff" : INK }}
            >
              {i + 1}
            </button>
          ))}
        </div>
        <button onClick={onExit} title="Kembali ke menu" className="menu-btn ml-1 h-[26px] px-2.5 rounded-lg font-title text-[13px] text-[#fff8ea]" style={{ background: INK }}>
          Keluar
        </button>
      </div>

      {acting && (
        <>
          <p className="text-[15px] text-[#4a3320] leading-[1.3] mt-2">{L.story}</p>
          {L.shapes && (
            <div className="flex items-center gap-4 mt-1.5">
              {SHAPE_PICS.map(([name, how, pts]) => (
                <div key={name} className="flex items-center gap-1.5">
                  <svg viewBox="0 0 40 40" width="34" height="34" className="rounded-lg" style={{ background: "rgba(59,42,26,0.1)" }}>
                    {pts.map(([x, y], i) => (
                      <circle key={i} cx={x} cy={y} r="2.5" fill={f.main} stroke={INK} strokeWidth="0.9" />
                    ))}
                  </svg>
                  <div className="leading-[1.15]">
                    <div className="font-title text-[14px] ink-text">{name}</div>
                    <div className="text-[12px] text-[#8a5a2c]">{how}</div>
                  </div>
                </div>
              ))}
              <span className="text-[12px] text-[#8a5a2c]">(musuh di kanan)</span>
            </div>
          )}
          <div className="mt-2 rounded-xl border-2 px-3 py-1.5 text-[15px] leading-[1.3]" style={{ borderColor: f.main, background: "#fffaf0" }}>
            <span className="font-title" style={{ color: f.dark }}>
              Tugasmu:{" "}
            </span>
            <span className="ink-text">{L.task}</span>
          </div>
          {T.phase === "plan" && (
            <div className="flex items-center gap-2.5 mt-2.5">
              <TutBtn primary disabled={T.placed < L.min} onClick={onLaunch} color={f.main} dark={f.dark} title="Kedua pihak maju (Enter)">
                Bunyikan terompet
              </TutBtn>
              {T.placed > 0 && <TutBtn onClick={onRetry}>Ulangi</TutBtn>}
              <span className="text-[13.5px] text-[#6b4a2c] leading-tight">
                {T.placed === 0 ? "Pasang barisanmu dulu." : `${T.placed} barisan siap${L.shapes ? `, bentuk ${T.shape}` : ""}${T.placed < L.max ? " — boleh tambah satu lagi" : ""}. Tekan Enter.`}
              </span>
            </div>
          )}
        </>
      )}

      {T.phase === "fight" && !L.live && (
        <div className="flex items-center gap-3 mt-2">
          <span className="text-[15px] ink-text leading-[1.3]">
            <span className="font-title" style={{ color: f.dark }}>
              Perhatikan:{" "}
            </span>
            {L.watch}
          </span>
          <div className="flex-1" />
          <TutBtn onClick={onRetry}>Ulangi</TutBtn>
        </div>
      )}

      {T.phase === "result" && v && T.out && (
        <>
          <div className="flex items-start gap-4 mt-2">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className={tag} style={{ background: v.pass ? "#1f8a3b" : "#c0392b" }}>
                  {v.pass ? "BENAR" : "BELUM TEPAT"}
                </span>
                <span className="font-title text-[20px] ink-text leading-tight">{v.head}</span>
              </div>
              <p className="text-[15px] text-[#4a3320] leading-[1.32] mt-1.5">
                <span className="font-title" style={{ color: f.dark }}>
                  Kenapa?{" "}
                </span>
                {v.why}
              </p>
            </div>
            {L.chart && (
              <div className="w-[236px] shrink-0">
                <div className="text-[11.5px] text-[#8a5a2c] leading-tight mb-1">{L.chartNote}</div>
                {L.chart.map(([name, n]) => {
                  const mine = name === T.shape;
                  return (
                    <div key={name} className="flex items-center gap-1.5 h-[17px]">
                      <span className={`w-[64px] text-[12.5px] leading-none ${mine ? "font-title ink-text" : "text-[#6b4a2c]"}`}>{name}</span>
                      <div className="flex-1 h-[10px] rounded-full overflow-hidden" style={{ background: "rgba(59,42,26,0.14)" }}>
                        <div className="h-full rounded-full" style={{ width: `${Math.max(3, (n / 20) * 100)}%`, background: mine ? f.main : "#b99a6a" }} />
                      </div>
                      <span className="w-[18px] text-right font-title text-[12.5px] ink-text leading-none">{n}</span>
                    </div>
                  );
                })}
                <div className="font-title text-[12.5px] leading-tight mt-1" style={{ color: f.dark }}>
                  Kamu: {T.shape}, tersisa {T.out.own}
                </div>
              </div>
            )}
          </div>
          <div className="mt-2 rounded-xl px-3 py-1.5 text-[15px] leading-[1.3] text-[#fff8ea]" style={{ background: INK }}>
            <span className="font-title text-[#ffd04a]">Ingat: </span>
            {L.rule}
          </div>
          <div className="flex items-center gap-2.5 mt-2.5">
            {v.pass ? (
              <>
                <TutBtn primary onClick={onNext} color="#3fae5a" dark="#1f7a3b">
                  {T.i + 1 < T.n ? "Lanjut" : "Selesai"}
                </TutBtn>
                <TutBtn onClick={onRetry}>Coba pilihan lain</TutBtn>
              </>
            ) : (
              <>
                <TutBtn primary onClick={onRetry} color={f.main} dark={f.dark}>
                  Coba lagi
                </TutBtn>
                <TutBtn onClick={onNext}>Lewati</TutBtn>
              </>
            )}
            <span className="text-[13px] text-[#8a5a2c]">Enter = {v.pass ? "lanjut" : "coba lagi"}</span>
          </div>
        </>
      )}

      {done && (
        <>
          <p className="text-[15px] text-[#4a3320] leading-[1.3] mt-2">Delapan hal yang sekarang kamu pahami, lengkap dengan alasannya:</p>
          <ol className="mt-1.5 space-y-[4px]">
            {LESSONS.map((l, i) => (
              <li key={i} className="flex items-start gap-2 text-[14.5px] ink-text leading-[1.25]">
                <span className="mt-[1px] w-[18px] h-[18px] shrink-0 rounded-full font-title text-[10.5px] leading-none flex items-center justify-center text-white" style={{ background: T.passed[i] ? "#35b45a" : "#b99a6a" }}>
                  {i + 1}
                </span>
                {l.rule}
              </li>
            ))}
          </ol>
          <div className="flex items-center gap-2.5 mt-3">
            <TutBtn primary onClick={onPlay} color={f.main} dark={f.dark}>
              Mulai Perang
            </TutBtn>
            <TutBtn onClick={onExit}>Menu Utama</TutBtn>
            <span className="text-[13px] text-[#8a5a2c]">Di pertempuran sungguhan, tekan H kapan saja untuk saran Penasihat.</span>
          </div>
        </>
      )}
    </div>
  );
}

/* ================================================================== */
/*  command                                                            */
/* ================================================================== */

/** orders for the selected squads (right side, mirroring the advisor on the left) */
function Command({
  ui,
  onOrder,
  onRefund,
  onClear,
  onAll,
  onMode,
}: {
  ui: Snap;
  onOrder: (k: "hold" | "free" | "retreat") => void;
  onRefund: () => void;
  onClear: () => void;
  onAll: () => void;
  onMode: () => void;
}) {
  if (ui.state !== "playing") return null;
  const f = FACTIONS[ui.fac[0]];
  const click = ui.cmdMode ? "Klik" : "Klik kanan";
  if (!ui.sel)
    return (
      <div className="absolute right-[10px] top-[112px] flex flex-col items-end gap-1.5">
        <button
          onClick={onMode}
          title="Mode komando: tombol kiri / sentuhan dipakai untuk memilih & memerintah pasukan (C)"
          className="menu-btn pointer-events-auto h-[48px] pl-2.5 pr-3 rounded-2xl parch flex items-center gap-2 font-title text-[19px] ink-text"
          style={ui.cmdMode ? { background: "linear-gradient(180deg,#ffe58f,#f0b62f)" } : undefined}
        >
          {IcoFlag} Komando <Key k="C" />
        </button>
        {ui.counts[0] > 0 && (
          <button onClick={onAll} title="Pilih semua pasukanmu (A)" className="menu-btn pointer-events-auto h-[34px] px-3 rounded-xl parch !shadow-[0_3px_0_#3b2a1a] flex items-center gap-2 font-title text-[15px] ink-text">
            Pilih semua <Key k="A" />
          </button>
        )}
        {ui.cmdMode && <span className="chip">Seret: pilih · klik: perintah</span>}
      </div>
    );
  const btn = "menu-btn h-[38px] rounded-xl border-[3px] font-title text-[15px] flex items-center justify-center gap-1.5 whitespace-nowrap";
  return (
    <div className="pointer-events-auto absolute right-[8px] top-[104px] w-[204px] parch rounded-2xl px-3 pt-2 pb-2.5">
      <button onClick={onClear} title="Batal pilih (Esc)" className="menu-btn absolute top-[6px] right-[6px] w-[24px] h-[24px] rounded-lg font-title text-[17px] leading-none text-[#fff8ea] flex items-center justify-center" style={{ background: INK }}>
        ×
      </button>
      <span className="flex items-center gap-1 font-title text-[18px] leading-none" style={{ color: f.dark }}>
        {IcoFlag} Komando
      </span>
      <div className="text-[13.5px] ink-text leading-tight mt-1.5">
        <span className="font-title text-[16px]">{ui.sel}</span> barisan · <span className="font-title text-[16px]">{ui.selMen}</span> prajurit
      </div>
      {ui.selReady > 0 && <div className="text-[12.5px] text-[#8a5a2c] leading-tight">{ui.selReady} masih menunggu terompet</div>}
      <div className="grid grid-cols-2 gap-1.5 mt-2">
        <button onClick={() => onOrder("free")} title="Serbu bebas: maju dan pilih lawan sendiri (S)" className={btn} style={pill(false)}>
          Serbu <Key k="S" />
        </button>
        <button onClick={() => onOrder("hold")} title="Tahan posisi: menjaga tempat ini, tidak mengejar, 15% lebih tahan pukul. Pasukan yang belum berangkat jadi cadangan (T)" className={btn} style={pill(false)}>
          Tahan <Key k="T" />
        </button>
        <button onClick={() => onOrder("retreat")} title="Mundur ke depan istana lalu berjaga di sana (R)" className={btn} style={pill(false)}>
          Mundur <Key k="R" />
        </button>
        <button onClick={onRefund} title="Batalkan barisan yang belum berangkat, emas kembali (Del)" className={`${btn} ${ui.selReady ? "" : "card-off"}`} style={pill(false)}>
          Batal{ui.selReady ? ` +${ui.selRefund}` : ""}
        </button>
      </div>
      <div className="text-[12.5px] text-[#4a3320] leading-[1.3] mt-2">
        <span className="font-title ink-text">{click}</span> pada…
        <br />
        tanah → <span className="font-title ink-text">pindah</span>
        <br />
        musuh → <span className="font-title ink-text">serang</span>
        <br />
        istana lawan → <span className="font-title ink-text">kepung</span>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  top scoreboard                                                     */
/* ================================================================== */

function readyText(counts: Record<string, number>) {
  const keys = Object.keys(counts);
  if (!keys.length) return "belum ada";
  return keys.map((k) => `${TYPE_NAME[k]} ×${counts[k]}`).join("  ·  ");
}

const CastleBar = memo(function CastleBar({ side, faction, hp, max, fx, units, ready, lead }: { side: 0 | 1; faction: FactionId; hp: number; max: number; fx: number; units: number; ready: string; lead: boolean }) {
  const frac = Math.max(0, Math.min(1, hp / max));
  const f = FACTIONS[faction];
  const danger = frac < 0.3;
  const anchor = side === 0 ? "left" : "right";
  return (
    <div className={`flex-1 min-w-0 flex items-start ${side === 1 ? "flex-row-reverse" : ""}`}>
      <div className="relative shrink-0 z-10">
        <div
          className={`w-[66px] h-[66px] rounded-[18px] border-[3px] flex items-center justify-center ${danger ? "urgent" : ""}`}
          style={{ background: `linear-gradient(180deg, ${f.light}, ${f.main} 45%, ${f.dark})`, borderColor: INK, boxShadow: `0 4px 0 ${INK}, inset 0 3px 0 rgba(255,255,255,0.35)` }}
        >
          <Emblem faction={faction} size={40} />
        </div>
        {lead && (
          <svg viewBox="0 0 24 16" width="34" height="22" className="absolute -top-[17px] left-1/2 -ml-[17px] floaty">
            <path d="M2 14 1 4l6 4 5-7 5 7 6-4-1 10z" fill="#ffd04a" stroke={INK} strokeWidth="1.8" strokeLinejoin="round" />
          </svg>
        )}
      </div>
      <div className={`flex-1 min-w-0 pt-[7px] ${side === 0 ? "-ml-3" : "-mr-3"}`}>
        <div className={`relative h-[34px] border-[3px] overflow-hidden ${side === 0 ? "rounded-r-full" : "rounded-l-full"}`} style={{ borderColor: INK, background: "#4a321d", boxShadow: `0 4px 0 ${INK}` }}>
          <div className="absolute top-0 h-full bg-[#fff1cf] transition-[width] duration-700" style={{ width: `${frac * 100}%`, [anchor]: 0 }} />
          <div key={fx} className={`absolute top-0 h-full ${fx ? "bar-hit" : ""}`} style={{ width: `${frac * 100}%`, background: `linear-gradient(180deg, ${f.light}, ${f.main} 50%, ${f.dark})`, [anchor]: 0 }} />
          <div className="absolute inset-x-0 top-0 h-[36%] bg-white/25" />
          <div className={`absolute inset-0 flex items-center justify-between px-5 ${side === 1 ? "flex-row-reverse" : ""}`}>
            <span className="font-title text-[19px] leading-none text-[#fff8ea] small-stroke">{f.name}</span>
            <span className={`font-title text-[19px] leading-none small-stroke ${danger ? "text-[#ffd0c4]" : "text-[#fff8ea]"}`}>
              {Math.ceil(hp)} <span className="text-[13px] opacity-85">/ {max}</span>
            </span>
          </div>
        </div>
        <div className={`mt-[10px] flex items-center gap-2 ${side === 0 ? "pl-5" : "pr-5 flex-row-reverse"}`}>
          <span className="chip">
            Prajurit <b>{units}</b>
          </span>
          <span className="chip">
            {side === 0 ? "Siap maju" : "Musuh siapkan"}: <b>{ready}</b>
          </span>
        </div>
      </div>
    </div>
  );
});

function TopHud({ ui, hpFx, tickKey }: { ui: Snap; hpFx: number[]; tickKey: number }) {
  const frac = Math.max(0, ui.phaseT / WAVE_TIME);
  const urgent = ui.phaseT <= 3;
  const lastMinute = ui.left <= 30;
  const R = 50;
  const C = 2 * Math.PI * R;
  const a = ui.hp[0] / ui.max[0];
  const b = ui.hp[1] / ui.max[1];
  const lead = Math.abs(a - b) > 0.001 ? (a > b ? 0 : 1) : -1;
  return (
    <div className="absolute top-[12px] left-1/2 -translate-x-1/2 w-[1330px] flex items-start">
      <CastleBar side={0} faction={ui.fac[0]} hp={ui.hp[0]} max={ui.max[0]} fx={hpFx[0]} units={ui.counts[0]} ready={readyText(ui.ready[0])} lead={lead === 0} />
      <div className="relative shrink-0 w-[128px] -mx-[6px] z-20 flex flex-col items-center -mt-[6px]">
        <div key={urgent ? tickKey : -1} className={`relative w-[124px] h-[124px] ${urgent ? "squish" : ""}`}>
          <div className="absolute inset-0 rounded-full border-[3px]" style={{ borderColor: INK, background: "linear-gradient(180deg,#b07a44,#633f22)", boxShadow: `0 5px 0 ${INK}, inset 0 3px 0 rgba(255,225,180,0.35)` }} />
          <svg width="124" height="124" className="absolute inset-0 -rotate-90">
            <circle cx="62" cy="62" r={R} fill="none" stroke="rgba(30,18,8,0.45)" strokeWidth="9" />
            <circle cx="62" cy="62" r={R} fill="none" stroke={urgent ? "#ff5a4f" : "#ffd04a"} strokeWidth="9" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - frac)} style={{ transition: "stroke-dashoffset 0.18s linear" }} />
          </svg>
          <div className="absolute inset-[17px] rounded-full parch !shadow-none flex flex-col items-center justify-center">
            <span className="text-[10px] tracking-[0.16em] text-[#8a6a48] leading-none">WAKTU</span>
            <span className={`font-title text-[35px] leading-none mt-[3px] ${lastMinute ? "urgent" : ""}`} style={{ color: lastMinute ? "#c0282e" : INK }}>
              {fmtClock(ui.left)}
            </span>
            <span className="text-[11px] leading-none mt-[3px]" style={{ color: urgent ? "#c0282e" : "#8a6a48" }}>
              terompet {Math.max(0, Math.ceil(ui.phaseT))}
            </span>
          </div>
        </div>
        <Ribbon className="-mt-[14px] text-[16px]" color="#8a6a48" dark="#5a3f26">
          Gelombang {ui.wave}
        </Ribbon>
        {ui.phase > 0 && (
          <div
            className={`mt-2 px-3 py-[2px] rounded-full border-[3px] font-title text-[15px] text-[#fff8ea] whitespace-nowrap ${ui.phase === 2 ? "urgent" : ""}`}
            style={{ borderColor: INK, background: ui.phase === 2 ? "linear-gradient(180deg,#ff6a4a,#b3241c)" : "linear-gradient(180deg,#ffb23e,#c9701a)", textShadow: `0 2px 0 ${INK}`, boxShadow: `0 3px 0 ${INK}` }}
          >
            {PHASE_NAME[ui.phase]} · tembok ×{SIEGE_MULT[ui.phase]}
          </div>
        )}
      </div>
      <CastleBar side={1} faction={ui.fac[1]} hp={ui.hp[1]} max={ui.max[1]} fx={hpFx[1]} units={ui.counts[1]} ready={readyText(ui.ready[1])} lead={lead === 1} />
    </div>
  );
}

function Banner({ title, sub, color, dark, top, slow }: { title: string; sub: ReactNode; color: string; dark: string; top: number; slow?: boolean }) {
  const [show, setShow] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setShow(false), slow ? 2600 : 1500);
    return () => clearTimeout(t);
  }, [slow]);
  if (!show) return null;
  return (
    <div className={`absolute left-1/2 -translate-x-1/2 ${slow ? "fade-out-slow" : "fade-out"}`} style={{ top }}>
      <div className="slam flex flex-col items-center">
        <div className="px-10 py-1.5 border-[4px] rounded-xl" style={{ background: `linear-gradient(180deg, ${color}, ${dark})`, borderColor: INK, boxShadow: `0 7px 0 ${INK}, inset 0 3px 0 rgba(255,255,255,0.3)` }}>
          <div className="font-title text-[60px] leading-none text-[#fff8ea] whitespace-nowrap" style={{ textShadow: `0 4px 0 ${INK}` }}>
            {title}
          </div>
        </div>
        <div className="mt-3 parch rounded-full px-5 py-0.5 font-title text-[19px] ink-text whitespace-nowrap">{sub}</div>
      </div>
    </div>
  );
}
const LaunchBanner = ({ wave, income, color }: { wave: number; income: number; color: { main: string; dark: string } }) => (
  <Banner
    title="SERBU!"
    color={color.main}
    dark={color.dark}
    top={230}
    sub={
      <>
        Gelombang {wave} maju · <span className="text-[#b07a10]">+{income} emas</span>
      </>
    }
  />
);
const PhaseBanner = ({ phase }: { phase: number }) => (
  <Banner
    slow
    title={phase === 2 ? "SUDDEN DEATH" : "BABAK PENENTUAN"}
    color={phase === 2 ? "#ff6a4a" : "#ffb23e"}
    dark={phase === 2 ? "#a81f18" : "#c9701a"}
    top={330}
    sub={`Tembok istana ${SIEGE_MULT[phase]}× lebih rapuh · ${phase === 2 ? "satu menit terakhir!" : "dua menit tersisa"}`}
  />
);

/* ================================================================== */
/*  bottom dock                                                        */
/* ================================================================== */

function CoinBadge({ cost, ok }: { cost: number; ok: boolean }) {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-[1px] rounded-full border-2 font-title text-[14px] leading-tight" style={{ borderColor: INK, background: ok ? "linear-gradient(180deg,#ffe58f,#f0b62f)" : "#d9c5a2", color: ok ? INK : "#8a6a48" }}>
      <span className="coin-dot" /> {cost}
    </span>
  );
}
function Hotkey({ k }: { k: string }) {
  return (
    <span className="absolute -top-2.5 -left-2.5 w-[26px] h-[26px] rounded-full border-2 flex items-center justify-center font-title text-[14px] text-[#fff8ea] z-10" style={{ background: INK, borderColor: "#f6e4b8" }}>
      {k}
    </span>
  );
}

const UnitCard = memo(function UnitCard({
  faction,
  type,
  hero,
  name,
  desc,
  cost,
  hotkey,
  sel,
  afford,
  badge,
  cd,
  cdFrac,
  gold,
  star,
  fit = -1,
  pick = false,
  locked = false,
  onClick,
  title,
}: {
  faction: FactionId;
  type: BasicType | "cannon" | "hero";
  hero?: HeroKind;
  name: string;
  desc: string;
  cost: number;
  hotkey: string;
  sel: boolean;
  afford: boolean;
  badge: string;
  cd: number;
  cdFrac: number;
  gold?: boolean;
  star?: boolean;
  /** the advisor's rating (0..3), -1 while it is closed */
  fit?: number;
  /** this is the card the advisor is talking about */
  pick?: boolean;
  /** not part of the current tutorial lesson */
  locked?: boolean;
  onClick: () => void;
  title: string;
}) {
  const big = type === "cavalry" || type === "harcher" || type === "cannon" || (hero && HERO_DEFS[hero].mounted);
  return (
    <button
      onClick={onClick}
      title={title}
      className={`card-btn pointer-events-auto relative w-[88px] h-[120px] rounded-[14px] flex flex-col items-center pt-[2px] ${gold ? "border-[3px]" : "parch"} ${sel ? "card-sel" : ""} ${pick && !sel ? "card-pick" : ""} ${locked ? "card-lock" : afford || cd > 0 ? "" : "card-off"}`}
      style={gold ? { borderColor: INK, background: "linear-gradient(180deg,#fff6cf,#f0c95e)", boxShadow: `0 4px 0 ${INK}, inset 0 0 0 2px #fff9de, inset 0 0 0 4px #d4a12f` } : undefined}
    >
      <Hotkey k={hotkey} />
      {star && (
        <svg viewBox="0 0 24 24" width="15" height="15" className="absolute top-[21px] right-[4px]">
          <path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 17.5l-5.9 3.2 1.2-6.6L2.5 9.5l6.6-.9z" fill="#ffd04a" stroke={INK} strokeWidth="1.8" strokeLinejoin="round" />
        </svg>
      )}
      {badge && (
        <span className="absolute top-1 right-1.5 text-[11px] font-title text-white px-1 rounded leading-tight" style={{ background: INK }}>
          {badge}
        </span>
      )}
      <UnitIcon faction={faction} type={type} hero={hero} size={50} zoom={big ? 1.7 : 2.2} />
      <div className="font-title text-[13.5px] ink-text leading-[1.02] h-[28px] flex items-center text-center px-[3px]">{name}</div>
      {fit >= 0 ? (
        <div className="font-title text-[10.5px] leading-[1.3] mb-[3px] px-1.5 rounded text-white whitespace-nowrap" style={{ background: FIT_COLOR[fit] }}>
          {FIT_LABEL[fit]}
        </div>
      ) : (
        <div className="text-[10.5px] text-[#8a5a2c] leading-none mb-[4px] whitespace-nowrap tracking-[-0.01em]">{desc}</div>
      )}
      <CoinBadge cost={cost} ok={afford} />
      {cd > 0 && (
        <div className="absolute inset-0 rounded-[11px] flex items-center justify-center" style={{ background: `conic-gradient(rgba(40,25,10,0.76) ${cdFrac * 360}deg, rgba(40,25,10,0.24) 0deg)` }}>
          <span className="font-title text-[32px] text-[#fff8ea]" style={{ textShadow: `0 2px 0 ${INK}` }}>
            {cd}
          </span>
        </div>
      )}
    </button>
  );
});

function Dock({
  ui,
  goldFx,
  onSelect,
  onHero,
  onCannon,
  onPause,
  onMute,
  onBlood,
  onSpeed,
  onQuality,
  speed,
  muted,
  qmode,
  allow,
}: {
  ui: Snap;
  goldFx: { k: number; cls: string };
  onSelect: (t: BasicType) => void;
  onHero: (h: HeroKind) => void;
  onCannon: () => void;
  onPause: () => void;
  onMute: () => void;
  onBlood: () => void;
  onSpeed: () => void;
  onQuality: () => void;
  speed: number;
  muted: boolean;
  qmode: QMode;
  /** tutorial: only these cards are part of the lesson */
  allow?: string[];
}) {
  const fid = ui.fac[0];
  const f = FACTIONS[fid];
  const fitOf = (k: string) => (ui.advice ? ui.adviceFit[k] ?? -1 : -1);
  const pickKey = ui.advice ? ui.advice.key : "";
  const ctl = "menu-btn pointer-events-auto w-[46px] h-[56px] rounded-xl parch !shadow-[0_3px_0_#3b2a1a] ink-text flex flex-col items-center justify-center";
  return (
    <div className="absolute bottom-[10px] left-1/2 -translate-x-1/2 w-max wood rounded-[26px] px-4 pt-4 pb-3 flex items-stretch gap-[10px]">
      <div className="absolute top-2 left-3 nail" />
      <div className="absolute top-2 right-3 nail" />
      {/* treasury */}
      <div key={goldFx.k} className={`w-[146px] parch rounded-2xl px-3 py-2 flex flex-col justify-center ${goldFx.cls}`}>
        <div className="flex items-center gap-2">
          <div className="w-[44px] h-[44px] rounded-full border-[3px] shrink-0" style={{ borderColor: INK, background: "radial-gradient(circle at 35% 30%, #fff5bf, #f5c33b 55%, #b8860b)", boxShadow: `0 3px 0 ${INK}` }} />
          <div>
            <div className="font-title text-[33px] leading-none ink-text">{ui.gold}</div>
            <div className="text-[11px] tracking-wider text-[#8a6a48] leading-none mt-0.5">EMAS</div>
          </div>
        </div>
        <div className="mt-2 h-[10px] rounded-full border-2 overflow-hidden" style={{ borderColor: INK, background: "#5a3a22" }}>
          <div className="h-full" style={{ width: `${Math.min(100, (ui.gold / GOLD_MAX) * 100)}%`, background: "linear-gradient(90deg,#f0b62f,#ffe58f)" }} />
        </div>
        <div className="text-[12px] text-[#6b4a2c] mt-1.5 leading-none">{ui.tut ? "untuk pelajaran ini" : `+${ui.income} tiap terompet`}</div>
      </div>

      <div className="flex gap-[6px]">
        {SQUAD_TYPES.map((t) => {
          const d = UNIT_DEFS[t];
          const cost = unitCost(t, f);
          return (
            <UnitCard
              key={t}
              faction={fid}
              type={t}
              locked={!!allow && !allow.includes(t)}
              name={f.unitNames[t]}
              desc={d.desc}
              fit={fitOf(t)}
              pick={pickKey === t}
              cost={cost}
              hotkey={d.key}
              sel={ui.selected === t && !ui.pendingHero && !ui.pendingCannon}
              afford={ui.gold >= cost}
              badge="×20"
              cd={0}
              cdFrac={0}
              onClick={() => onSelect(t)}
              star={f.signature.includes(t)}
              title={`${f.unitNames[t]} (${d.name}) — ${d.skill}${f.signature.includes(t) && UNIT_MODS[fid][t] ? `. ANDALAN ${f.name}: ${UNIT_MODS[fid][t]!.note}` : ""}`}
            />
          );
        })}
        <UnitCard
          faction={fid}
          type="cannon"
          locked={!!allow}
          name={CANNON_DEF.name}
          desc={CANNON_DEF.desc}
          fit={fitOf("cannon")}
          pick={pickKey === "cannon"}
          cost={CANNON_DEF.cost}
          hotkey={CANNON_DEF.key}
          sel={ui.pendingCannon}
          afford={ui.gold >= CANNON_DEF.cost && ui.cannons < CANNON_DEF.max}
          badge={`${ui.cannons}/${CANNON_DEF.max}`}
          cd={0}
          cdFrac={0}
          onClick={onCannon}
          title="Meriam — ledakan area, satu-satunya yang benar-benar merobohkan tembok"
        />
      </div>

      <div className="w-[3px] my-1 rounded bg-black/30" />

      <div className="flex gap-[6px]">
        {f.heroes.map((h, i) => {
          const d = HERO_DEFS[h];
          const cd = Math.ceil(ui.heroCd[h] ?? 0);
          return (
            <UnitCard
              key={h}
              gold
              faction={fid}
              type="hero"
              locked={!!allow}
              hero={h}
              name={d.name}
              desc="Hero"
              fit={fitOf(h)}
              pick={pickKey === h}
              cost={HERO_COST}
              hotkey={i === 0 ? "Q" : "W"}
              sel={ui.pendingHero === h}
              afford={ui.gold >= HERO_COST}
              badge=""
              cd={cd}
              cdFrac={cd / d.cooldown}
              onClick={() => onHero(h)}
              title={`${d.name} — ${d.title}`}
            />
          );
        })}
      </div>

      <div className="w-[3px] my-1 rounded bg-black/30" />

      <div className="shrink-0 grid grid-cols-[46px_46px_46px] gap-[5px] content-center">
        <button className={ctl} onClick={onPause} title="Jeda (Esc)">
          {IcoPause}
        </button>
        <button className={ctl} onClick={onSpeed} title="Kecepatan permainan (F)" style={speed > 1 ? { background: "linear-gradient(180deg,#ffe58f,#f0b62f)" } : undefined}>
          <span className="font-title text-[19px] leading-none">{speed}×</span>
          <span className="text-[9.5px] leading-none mt-[3px]">Cepat</span>
        </button>
        <button className={ctl} onClick={onMute} title="Suara (M)">
          {IcoSound(!muted)}
        </button>
        <button className={ctl} onClick={onBlood} title="Darah on/off">
          {IcoDrop(ui.blood)}
        </button>
        <button className={`${ctl} col-span-2 !w-[97px]`} onClick={onQuality} title="Kualitas grafis: Auto menurunkan resolusi bila mulai lag">
          <span className="flex items-center gap-1 font-title text-[15px] leading-none">
            {IcoBolt} {QLABEL[qmode]}
          </span>
          <span className="text-[9.5px] leading-none mt-[3px]">Grafis</span>
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  overlays                                                           */
/* ================================================================== */

function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`pop-in pointer-events-auto parch rounded-[28px] ${className}`}>{children}</div>;
}

function BigBtn({ children, onClick, color = "#e0444b", dark = "#9c2229" }: { children: ReactNode; onClick: () => void; color?: string; dark?: string }) {
  return (
    <button
      onClick={onClick}
      className="menu-btn pointer-events-auto font-title text-[28px] text-[#fff8ea] px-10 py-2.5 rounded-2xl border-[3px] whitespace-nowrap"
      style={{ borderColor: INK, background: `linear-gradient(180deg, ${color}, ${dark})`, boxShadow: `0 6px 0 ${INK}, inset 0 3px 0 rgba(255,255,255,0.3)`, textShadow: `0 2px 0 ${INK}` }}
    >
      {children}
    </button>
  );
}

function Toggle({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} className="menu-btn pointer-events-auto flex items-center gap-2 font-title text-[17px] ink-text">
      <span className="relative w-11 h-6 rounded-full border-[3px]" style={{ borderColor: INK, background: on ? "#e0444b" : "#bba98a" }}>
        <span className="absolute top-[1px] w-4 h-4 rounded-full bg-[#fff8ea] border-2 transition-all" style={{ borderColor: INK, left: on ? 20 : 1 }} />
      </span>
      {label}
    </button>
  );
}

const pill = (active: boolean): React.CSSProperties => ({ borderColor: INK, background: active ? "linear-gradient(180deg,#ffe58f,#f0b62f)" : "#f3e6c8", boxShadow: `0 4px 0 ${INK}`, color: INK });

function Menu({
  diff,
  setDiff,
  pick,
  setPick,
  foe,
  setFoe,
  blood,
  onBlood,
  onStart,
  onTutorial,
  tutDone,
}: {
  diff: Difficulty;
  setDiff: (d: Difficulty) => void;
  pick: FactionId;
  setPick: (f: FactionId) => void;
  foe: Foe;
  setFoe: (f: Foe) => void;
  blood: boolean;
  onBlood: () => void;
  onStart: () => void;
  onTutorial: () => void;
  tutDone: number;
}) {
  const diffs: [Difficulty, string][] = [
    ["easy", "Mudah"],
    ["normal", "Normal"],
    ["hard", "Sulit"],
  ];
  const tap = (fn: () => void) => () => {
    sfx.ensure();
    sfx.click();
    fn();
  };
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center menu-veil">
      <div className="pop-in text-center mb-3">
        <div className="font-title text-[80px] leading-[0.85] text-[#fff8e8] title-stroke">Tiny Banners</div>
        <Ribbon className="mt-4 text-[22px]" color={FACTIONS[pick].main} dark={FACTIONS[pick].dark}>
          Perang Mini 5 Menit · Gambar Barisanmu
        </Ribbon>
      </div>

      <Panel className="px-7 pt-3 pb-4 w-[1120px]">
        <div className="font-title text-[23px] ink-text text-center mb-2.5">Pilih Faksimu</div>
        <div className="grid grid-cols-4 gap-[14px] mb-4">
          {FACTION_IDS.map((id) => {
            const f = FACTIONS[id];
            const sel = pick === id;
            return (
              <button
                key={id}
                onClick={tap(() => setPick(id))}
                className={`fac-card pointer-events-auto text-left rounded-[18px] border-[3px] overflow-hidden bg-[#fffaf0] flex flex-col items-stretch justify-start ${sel ? "fac-sel" : ""}`}
                style={{ borderColor: INK, boxShadow: sel ? `0 6px 0 ${INK}, 0 0 0 4px ${f.main}, 0 0 22px 6px ${f.light}` : `0 4px 0 ${INK}` }}
              >
                <div className="flex items-center gap-2.5 px-3 h-[52px]" style={{ background: `linear-gradient(180deg, ${f.light}, ${f.main} 55%, ${f.dark})`, borderBottom: `3px solid ${INK}` }}>
                  <Emblem faction={id} size={34} />
                  <span className="font-title text-[23px] leading-none text-[#fff8ea] small-stroke">{f.name}</span>
                </div>
                <div className="relative grid grid-cols-3 px-1 pt-2" style={{ background: "linear-gradient(180deg,#d9f2ff,#b6ea78 62%)" }}>
                  <span className="absolute top-1 left-1.5 text-[10.5px] tracking-wide px-1.5 rounded text-[#fff8ea] leading-[1.4]" style={{ background: INK }}>
                    PASUKAN ANDALAN
                  </span>
                  {f.signature.map((t) => (
                    <div key={t} className="flex flex-col items-center" title={`${f.unitNames[t]} (${UNIT_DEFS[t].name}): ${UNIT_MODS[id][t]?.note ?? ""}`}>
                      <UnitIcon faction={id} type={t} size={66} zoom={UNIT_DEFS[t].mounted ? 2.15 : 2.7} animate={sel} />
                      <span className="font-title text-[13.5px] leading-none text-[#fff8ea] small-stroke whitespace-nowrap -mt-[2px] mb-[6px]">{f.unitNames[t]}</span>
                    </div>
                  ))}
                </div>
                <div className="px-3 pt-2 pb-2.5" style={{ borderTop: `3px solid ${INK}` }}>
                  <div className="text-[13px] text-[#6b4a2c] leading-snug h-[36px]">{f.motto}</div>
                  <div className="font-title text-[17px] leading-none mt-1.5" style={{ color: f.dark }}>
                    {f.perk}
                  </div>
                  <ul className="mt-1.5 space-y-[3px]">
                    {f.perks.map((p) => (
                      <li key={p} className="flex gap-1.5 text-[13px] ink-text leading-[1.2]">
                        <span className="mt-[5px] w-[7px] h-[7px] rounded-full shrink-0" style={{ background: f.main }} />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-3 gap-3 mb-4">
          {FACTIONS[pick].signature.map((t) => (
            <div key={t} className="rounded-xl border-2 px-3 py-1.5 bg-[#fffaf0]" style={{ borderColor: "rgba(59,42,26,0.25)" }}>
              <span className="font-title text-[16px]" style={{ color: FACTIONS[pick].dark }}>
                {FACTIONS[pick].unitNames[t]}
              </span>
              <span className="text-[13px] text-[#8a6a48]"> · {UNIT_DEFS[t].name} andalan</span>
              <div className="text-[13px] ink-text leading-[1.2]">{UNIT_MODS[pick][t]?.note}</div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-center gap-7 mb-4">
          <div className="flex items-center gap-2">
            <span className="font-title text-[18px] ink-text mr-1">Lawan</span>
            <button onClick={tap(() => setFoe("random"))} className="menu-btn pointer-events-auto font-title text-[16px] px-4 h-[40px] rounded-xl border-[3px]" style={pill(foe === "random")}>
              Acak
            </button>
            {FACTION_IDS.filter((id) => id !== pick).map((id) => (
              <button key={id} onClick={tap(() => setFoe(id))} title={FACTIONS[id].name} className="menu-btn pointer-events-auto h-[40px] pl-1.5 pr-3 rounded-xl border-[3px] flex items-center gap-1.5 font-title text-[16px] whitespace-nowrap" style={pill(foe === id)}>
                <span className="w-[28px] h-[28px] rounded-lg border-2 flex items-center justify-center" style={{ background: FACTIONS[id].main, borderColor: INK }}>
                  <Emblem faction={id} size={18} />
                </span>
                {SHORT[id]}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="font-title text-[18px] ink-text mr-1">Tingkat</span>
            {diffs.map(([d, label]) => (
              <button key={d} onClick={tap(() => setDiff(d))} className="menu-btn pointer-events-auto font-title text-[16px] px-4 h-[40px] rounded-xl border-[3px]" style={pill(diff === d)}>
                {label}
              </button>
            ))}
          </div>
          <Toggle on={blood} onClick={onBlood} label="Darah" />
        </div>

        <div className="flex items-center justify-center gap-5">
          <div className="relative">
            <BigBtn onClick={tap(onTutorial)} color="#3d9a5e" dark="#1f5a36">
              Tutorial
            </BigBtn>
            <span className="absolute -top-3 -right-3 font-title text-[13px] leading-[1.55] px-2 rounded-full border-2 text-[#fff8ea]" style={{ background: tutDone >= LESSONS.length ? "#1f8a3b" : INK, borderColor: "#f6e4b8" }}>
              {tutDone}/{LESSONS.length}
            </span>
          </div>
          <BigBtn onClick={onStart} color={FACTIONS[pick].main} dark={FACTIONS[pick].dark}>
            Mulai Perang
          </BigBtn>
        </div>
        <div className="text-[13.5px] text-[#6b4a2c] text-center mt-3.5 leading-snug">
          Baru pertama kali? <span className="ink-text">Tutorial</span>: {LESSONS.length} pelajaran singkat tentang alasan di balik tiap pilihan pasukan dan bentuk barisan
          <br />
          <span className="ink-text">1–8</span> pasukan · <span className="ink-text">9</span> meriam · <span className="ink-text">Q W</span> hero · <span className="ink-text">H</span> saran untuk semua kartu · <span className="ink-text">klik kanan + seret</span> pilih pasukan, <span className="ink-text">klik kanan</span> beri perintah · <span className="ink-text">F</span> kecepatan ·{" "}
          <span className="ink-text">Esc</span> jeda · <span className="ink-text">M</span> suara
        </div>
      </Panel>
    </div>
  );
}

function PauseOverlay({ onResume, onMenu, blood, onBlood }: { onResume: () => void; onMenu: () => void; blood: boolean; onBlood: () => void }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center overlay-veil">
      <Panel className="px-14 pt-6 pb-9 text-center">
        <Ribbon className="text-[32px] mb-6" color="#8a6a48" dark="#5a3f26">
          Jeda
        </Ribbon>
        <div className="flex flex-col gap-5 items-center">
          <BigBtn onClick={onResume}>Lanjutkan</BigBtn>
          <BigBtn onClick={onMenu} color="#9a7650" dark="#5a3f26">
            Menu Utama
          </BigBtn>
          <Toggle on={blood} onClick={onBlood} label="Darah" />
        </div>
      </Panel>
    </div>
  );
}

function EndOverlay({ ui, onRetry, onMenu }: { ui: Snap; onRetry: () => void; onMenu: () => void }) {
  const won = ui.state === "won";
  const me = FACTIONS[ui.fac[0]];
  const them = FACTIONS[ui.fac[1]];
  const pct = [Math.round((ui.hp[0] / ui.max[0]) * 100), Math.round((ui.hp[1] / ui.max[1]) * 100)];
  const reason: Record<Game["endReason"], [string, string]> = {
    castle: [`Istana ${them.name} telah runtuh!`, "Istanamu telah jatuh."],
    hp: ["Waktu habis — istanamu lebih kokoh!", `Waktu habis — istana ${them.name} lebih kokoh.`],
    kills: ["Waktu habis & istana imbang — pasukanmu menumbangkan lebih banyak musuh!", "Waktu habis & istana imbang — musuh menumbangkan lebih banyak prajurit."],
    army: ["Waktu habis & semuanya imbang — pasukanmu lebih besar!", "Waktu habis & semuanya imbang — pasukan musuh lebih besar."],
  };
  const win = won ? me : them;
  return (
    <div className="absolute inset-0 flex items-center justify-center overlay-veil">
      <Panel className="px-12 pt-4 pb-8 text-center w-[720px]">
        <div className="flex justify-center -mt-24 mb-1">
          <div className="floaty">
            <UnitIcon faction={win.id} type="hero" hero={win.heroes[0]} size={130} zoom={4} animate />
          </div>
        </div>
        <Ribbon className="text-[46px]" color={won ? "#f5c33b" : "#6a7a9a"} dark={won ? "#b07a10" : "#2e3a55"}>
          {won ? "Kemenangan!" : "Kekalahan..."}
        </Ribbon>
        <div className="font-title text-[#6b4a2c] text-[21px] mt-3 mb-4 leading-tight">{reason[ui.reason][won ? 0 : 1]}</div>
        <div className="flex items-center gap-3 mb-5">
          {[me, them].map((f, s) => (
            <div key={s} className={`flex-1 flex items-center gap-2 ${s === 1 ? "flex-row-reverse" : ""}`}>
              <span className="font-title text-[20px] w-[62px]" style={{ color: f.dark }}>
                {pct[s]}%
              </span>
              <div className="flex-1 h-[20px] rounded-full border-[3px] overflow-hidden relative" style={{ borderColor: INK, background: "#4a321d" }}>
                <div className="absolute top-0 h-full" style={{ width: `${pct[s]}%`, [s === 0 ? "left" : "right"]: 0, background: `linear-gradient(180deg, ${f.light}, ${f.main})` }} />
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-3 mb-7">
          {[
            [fmtClock(ui.played), "Lama perang"],
            [ui.wave - 1, "Gelombang"],
            [ui.stats.squads, "Barisan dikerahkan"],
            [ui.stats.kills, "Musuh tumbang"],
            [ui.stats.lost, "Prajurit gugur"],
            [ui.stats.flung, "Musuh terpental"],
          ].map(([v, l]) => (
            <div key={l as string} className="rounded-2xl border-[3px] py-2.5 bg-[#fffaf0]" style={{ borderColor: INK, boxShadow: `0 3px 0 ${INK}` }}>
              <div className="font-title ink-text text-[30px] leading-none">{v}</div>
              <div className="text-[13px] text-[#8a6a48] mt-1.5">{l}</div>
            </div>
          ))}
        </div>
        <div className="flex justify-center gap-5">
          <BigBtn onClick={onRetry} color={me.main} dark={me.dark}>
            Main Lagi
          </BigBtn>
          <BigBtn onClick={onMenu} color="#9a7650" dark="#5a3f26">
            Menu Utama
          </BigBtn>
        </div>
      </Panel>
    </div>
  );
}
