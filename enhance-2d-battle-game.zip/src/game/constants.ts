export const W = 1600;
export const H = 900;

export const FIELD_TOP = 120;
/** the field ends where the command dock begins, so no soldier is ever hidden behind it */
export const FIELD_BOTTOM = 726;

export const SQUAD_SIZE = 20;

export type Team = 0 | 1; // 0 = player (left), 1 = enemy (right)
export type SquadType = "sword" | "spear" | "archer" | "cavalry" | "guard" | "axe" | "xbow" | "harcher";
export type UnitType = SquadType | "hero" | "cannon";
export const SQUAD_TYPES: SquadType[] = ["sword", "spear", "archer", "cavalry", "guard", "axe", "xbow", "harcher"];

export type FactionId = "crusader" | "arab" | "viking" | "samurai";
export const FACTION_IDS: FactionId[] = ["crusader", "arab", "viking", "samurai"];

export type HeroKind = "reynald" | "richard" | "saladin" | "zahir" | "ragnar" | "lagertha" | "takeda" | "tomoe";

export interface UnitDef {
  type: SquadType;
  /** battlefield role, the same for every faction */
  name: string;
  desc: string;
  skill: string;
  hp: number;
  atk: number;
  cd: number;
  range: number;
  speed: number;
  aggro: number;
  cost: number;
  radius: number;
  ranged?: boolean;
  mounted?: boolean;
  key: string;
}

export const UNIT_DEFS: Record<SquadType, UnitDef> = {
  sword: { type: "sword", name: "Pedang", desc: "Kuat vs Tombak", skill: "Menangkis lalu membalas; hantaman perisai membuat lawan terhuyung", hp: 36, atk: 8, cd: 0.75, range: 11, speed: 48, aggro: 110, cost: 65, radius: 4, key: "1" },
  spear: { type: "spear", name: "Tombak", desc: "Kuat vs Kuda", skill: "Pagar tombak menghentikan serbuan kuda; murah, juga ampuh lawan hero", hp: 32, atk: 8, cd: 0.95, range: 20, speed: 45, aggro: 110, cost: 65, radius: 4, key: "2" },
  archer: { type: "archer", name: "Pemanah", desc: "Kuat vs Gempur", skill: "Tembakan serentak yang disebar rata; ampuh lawan pasukan tanpa perisai, lemah bila diserbu", hp: 18, atk: 9.5, cd: 1.1, range: 260, speed: 43, aggro: 285, cost: 80, radius: 4, ranged: true, key: "3" },
  cavalry: { type: "cavalry", name: "Kavaleri", desc: "Kuat vs Panah", skill: "Serbuan menembus & melempar barisan", hp: 64, atk: 10, cd: 0.85, range: 13, speed: 88, aggro: 150, cost: 140, radius: 6.5, mounted: true, key: "4" },
  guard: { type: "guard", name: "Perisai", desc: "Tahan Panah", skill: "Tembok perisai: menahan panah & serbuan", hp: 78, atk: 5, cd: 1.0, range: 10, speed: 38, aggro: 100, cost: 85, radius: 4.6, key: "5" },
  axe: { type: "axe", name: "Gempur", desc: "Belah Perisai", skill: "Membelah perisai, tebasan menyapu, mengamuk saat menang", hp: 30, atk: 14, cd: 0.95, range: 12, speed: 56, aggro: 120, cost: 80, radius: 4, key: "6" },
  xbow: { type: "xbow", name: "Tembak", desc: "Tembus Perisai", skill: "Tembakan berat menembus perisai dan dua musuh sekaligus; menjatuhkan kuda dan hero", hp: 22, atk: 16, cd: 2.4, range: 255, speed: 40, aggro: 275, cost: 95, radius: 4, ranged: true, key: "7" },
  harcher: { type: "harcher", name: "Panah Kuda", desc: "Kuat vs Gempur", skill: "Menembak sambil berkuda, menjauh bila dikejar", hp: 38, atk: 6, cd: 1.2, range: 175, speed: 82, aggro: 230, cost: 130, radius: 6.5, ranged: true, mounted: true, key: "8" },
};

/** Cannon: a single siege piece with crew. Slow, long range, splash, crushes castles. */
export const CANNON_DEF = {
  name: "Meriam",
  desc: "Roboh Istana",
  hp: 140,
  atk: 34,
  cd: 4.6,
  range: 400,
  speed: 24,
  aggro: 420,
  radius: 9,
  splash: 40,
  castleMult: 3.6,
  cost: 170,
  max: 3,
  key: "9",
};

export interface HeroDef {
  kind: HeroKind;
  faction: FactionId;
  name: string;
  title: string;
  hp: number;
  atk: number;
  cd: number;
  range: number;
  speed: number;
  aggro: number;
  radius: number;
  cleave: number; // radius of splash damage, 0 = none
  ranged?: boolean;
  mounted?: boolean;
  cooldown: number;
}

export const HERO_DEFS: Record<HeroKind, HeroDef> = {
  reynald: { kind: "reynald", faction: "crusader", name: "Grand Master Reynald", title: "Ksatria berkuda, tombak penembus barisan", hp: 1130, atk: 40, cd: 0.85, range: 16, speed: 94, aggro: 180, radius: 8, cleave: 14, mounted: true, cooldown: 26 },
  richard: { kind: "richard", faction: "crusader", name: "Richard Hati Singa", title: "Pedang besar yang menyapu satu barisan", hp: 1250, atk: 54, cd: 1.15, range: 18, speed: 52, aggro: 150, radius: 6, cleave: 30, cooldown: 26 },
  saladin: { kind: "saladin", faction: "arab", name: "Sultan Saladin", title: "Pedang lengkung tercepat di atas kuda", hp: 1040, atk: 34, cd: 0.62, range: 15, speed: 104, aggro: 190, radius: 8, cleave: 16, mounted: true, cooldown: 26 },
  zahir: { kind: "zahir", faction: "arab", name: "Zahir al-Sahra", title: "Pemanah kuda legendaris, tak pernah tertangkap", hp: 750, atk: 22, cd: 0.42, range: 250, speed: 100, aggro: 300, radius: 8, cleave: 0, ranged: true, mounted: true, cooldown: 26 },
  ragnar: { kind: "ragnar", faction: "viking", name: "Jarl Ragnar", title: "Kapak raksasa pembelah perisai", hp: 1390, atk: 52, cd: 1.0, range: 15, speed: 54, aggro: 150, radius: 6, cleave: 28, cooldown: 26 },
  lagertha: { kind: "lagertha", faction: "viking", name: "Lagertha", title: "Gadis perisai, tombak secepat kilat", hp: 1300, atk: 38, cd: 0.68, range: 19, speed: 56, aggro: 150, radius: 6, cleave: 18, cooldown: 26 },
  takeda: { kind: "takeda", faction: "samurai", name: "Shogun Takeda", title: "Panglima berkuda, katana tanpa ampun", hp: 1070, atk: 43, cd: 0.65, range: 16, speed: 98, aggro: 180, radius: 8, cleave: 18, mounted: true, cooldown: 26 },
  tomoe: { kind: "tomoe", faction: "samurai", name: "Tomoe Gozen", title: "Pemanah yumi, dua anak panah sekali tarik", hp: 670, atk: 25, cd: 0.42, range: 300, speed: 54, aggro: 320, radius: 5, cleave: 0, ranged: true, cooldown: 26 },
};

/* ------------------------------------------------------------------ */
/*  factions                                                          */
/* ------------------------------------------------------------------ */
export interface FactionDef {
  id: FactionId;
  name: string;
  motto: string;
  main: string;
  dark: string;
  light: string;
  accent: string;
  perk: string;
  perks: string[];
  unitNames: Record<SquadType, string>;
  heroes: [HeroKind, HeroKind];
  /** the three troop types this faction is famous for: each has its own bonus (see UNIT_MODS) */
  signature: SquadType[];
  /* modifiers */
  hp: number; // health of every soldier
  melee: number; // melee damage
  ranged: number; // arrow / bolt damage
  rangeMul: number; // shooting range
  speed: number; // movement speed of everyone
  mountSpeed: number; // extra speed of mounted units
  mountCost: number; // price of mounted squads
  crit: number; // critical hit chance
  block: number; // added to shield block chance
  castleHp: number;
  bounty: number; // extra gold per kill
  berserk: boolean; // wounded soldiers strike faster
  noRetreat: boolean; // never regroups
}

export const FACTIONS: Record<FactionId, FactionDef> = {
  crusader: {
    id: "crusader",
    name: "Tentara Salib",
    motto: "Baja, perisai, dan tembok yang tak tergoyahkan",
    main: "#d23b3b",
    dark: "#8f2227",
    light: "#f58a8a",
    accent: "#f2c14e",
    perk: "Baja & Iman",
    perks: ["Semua prajurit +18% nyawa", "Perisai menangkis lebih sering", "Istana +15% lebih kokoh"],
    unitNames: { sword: "Templar", spear: "Sersan Tombak", archer: "Longbow", cavalry: "Chevalier", guard: "Pavise", axe: "Hospitaller", xbow: "Arbalest", harcher: "Turkopol" },
    heroes: ["reynald", "richard"],
    signature: ["cavalry", "guard", "xbow"],
    hp: 1.18, melee: 1, ranged: 1, rangeMul: 1, speed: 0.97, mountSpeed: 1, mountCost: 1, crit: 0.07, block: 0.12, castleHp: 1.15, bounty: 0, berserk: false, noRetreat: false,
  },
  arab: {
    id: "arab",
    name: "Kesultanan Arab",
    motto: "Secepat angin gurun, setajam pedang lengkung",
    main: "#1f9d6b",
    dark: "#12684a",
    light: "#6fdcae",
    accent: "#f2c14e",
    perk: "Angin Gurun",
    perks: ["Pasukan berkuda +15% lebih cepat", "Pasukan berkuda 15% lebih murah", "Semua prajurit +6% kecepatan"],
    unitNames: { sword: "Ghazi", spear: "Rammah", archer: "Rumat", cavalry: "Mamluk", guard: "Haras", axe: "Tabardar", xbow: "Naffatun", harcher: "Faris" },
    heroes: ["saladin", "zahir"],
    signature: ["harcher", "cavalry", "xbow"],
    hp: 1, melee: 1, ranged: 1, rangeMul: 1, speed: 1.06, mountSpeed: 1.15, mountCost: 0.85, crit: 0.07, block: 0, castleHp: 1, bounty: 0, berserk: false, noRetreat: false,
  },
  viking: {
    id: "viking",
    name: "Viking",
    motto: "Kapak, amukan, dan jarahan dari utara",
    main: "#2f73c2",
    dark: "#1d4b85",
    light: "#86b9f5",
    accent: "#f1e3bd",
    perk: "Amukan Utara",
    perks: ["Serangan jarak dekat +15%", "Prajurit terluka menyerang 30% lebih cepat", "+1 emas jarahan tiap musuh tumbang"],
    unitNames: { sword: "Huskarl", spear: "Hirdman", archer: "Bogmann", cavalry: "Rytter", guard: "Skjaldborg", axe: "Berserker", xbow: "Gaflak", harcher: "Veidimann" },
    heroes: ["ragnar", "lagertha"],
    signature: ["axe", "guard", "sword"],
    hp: 1, melee: 1.15, ranged: 1, rangeMul: 1, speed: 1, mountSpeed: 1, mountCost: 1, crit: 0.07, block: 0, castleHp: 1, bounty: 1, berserk: true, noRetreat: false,
  },
  samurai: {
    id: "samurai",
    name: "Samurai",
    motto: "Satu tebasan, satu nyawa. Pantang mundur",
    main: "#7a4fc0",
    dark: "#4c2f85",
    light: "#b99cf5",
    accent: "#f2c14e",
    perk: "Jalan Bushido",
    perks: ["Peluang serangan kritis 3× lipat", "Panah & peluru +15% kuat, jangkauan +8%", "Pantang mundur: bertarung sampai habis"],
    unitNames: { sword: "Kenshi", spear: "Ashigaru", archer: "Yumi", cavalry: "Kiba Musha", guard: "Tate", axe: "Sohei", xbow: "Teppo", harcher: "Yabusame" },
    heroes: ["takeda", "tomoe"],
    signature: ["sword", "xbow", "axe"],
    hp: 1, melee: 1, ranged: 1.15, rangeMul: 1.08, speed: 1, mountSpeed: 1, mountCost: 1, crit: 0.21, block: 0, castleHp: 1, bounty: 0, berserk: false, noRetreat: true,
  },
};

/** what makes a faction's own troops special (multipliers on the shared unit class) */
export interface UnitMod {
  hp?: number;
  atk?: number;
  speed?: number;
  range?: number;
  cd?: number;
  cost?: number;
  note: string;
}
export const UNIT_MODS: Record<FactionId, Partial<Record<SquadType, UnitMod>>> = {
  crusader: {
    cavalry: { hp: 1.2, atk: 1.15, cost: 1.1, note: "serbuan terberat: +20% nyawa, +15% serangan" },
    guard: { hp: 1.2, note: "pavise raksasa: +20% nyawa" },
    xbow: { atk: 1.3, range: 1.08, note: "busur baja: +30% serangan, jangkauan lebih jauh" },
  },
  arab: {
    harcher: { atk: 1.2, cd: 0.88, note: "pemanah kuda terbaik: menembak lebih cepat & kuat" },
    cavalry: { speed: 1.05, atk: 1.15, hp: 1.08, note: "lebih cepat, lebih tajam, lebih tangguh dari kavaleri lain" },
    xbow: { atk: 0.8, range: 0.8, cd: 0.9, note: "api naft membakar satu area, perisai tak menolong; lemah lawan kuda" },
  },
  viking: {
    axe: { hp: 1.15, note: "mengamuk: pulih 25% nyawa tiap membunuh" },
    guard: { hp: 1.1, atk: 1.3, note: "tembok perisai yang ikut menebas (+30% serangan)" },
    sword: { atk: 1.1, note: "pengawal elit: +10% serangan" },
    cavalry: { hp: 0.9, cost: 0.9, note: "Viking jago di darat: kuda lebih murah tapi rapuh" },
  },
  samurai: {
    sword: { cd: 0.9, note: "tebasan katana 10% lebih cepat" },
    xbow: { atk: 1.25, cd: 1.12, note: "senapan sumbu: tembakan terkuat, menembus perisai" },
    axe: { range: 1.4, note: "naginata: jangkauan panjang, menyapu tiga musuh" },
  },
};

export function unitCost(type: SquadType, f: FactionDef) {
  const d = UNIT_DEFS[type];
  return Math.round((d.cost * (d.mounted ? f.mountCost : 1) * (UNIT_MODS[f.id][type]?.cost ?? 1)) / 5) * 5;
}

export const CASTLE = [
  { cx: 115, baseY: 555, hw: 78, top: 330 },
  { cx: W - 115, baseY: 555, hw: 78, top: 330 },
];

export const ZONES = [
  { x0: 215, x1: 620 },
  { x0: W - 620, x1: W - 215 },
];

/* ---------------- match pacing: a full game is decided within 5 minutes ---------------- */
export const MATCH_TIME = 300;
/** seconds at which the match escalates: [decisive round, sudden death] */
export const PHASE_AT = [180, 240];
/** damage multiplier against castles for each phase */
export const SIEGE_MULT = [1, 1.6, 2.6];
/** income multiplier for each phase */
export const INCOME_MULT = [1, 1.1, 1.2];
/** thick walls: a full-health castle withstands at least this many seconds of all-out siege, per phase */
export const SIEGE_SECONDS = [60, 32, 16];
export const PHASE_NAME = ["Pertempuran", "Babak Penentuan", "Sudden Death"];

export const CASTLE_HP = 3000;
export const GOLD_MAX = 800;
export const GOLD_START = 320;
export const WAVE_TIME = 8;
export const WAVE_INCOME = 130;
export const WAVE_INCOME_GROWTH = 4; // per wave
export const WAVE_INCOME_MAX = 200;
export const KILL_BOUNTY = 1;
export const HERO_COST = 150;

/** Damage multiplier: COUNTER[attacker][defender] */
export const COUNTER: Record<string, Partial<Record<string, number>>> = {
  sword: { spear: 1.6, cannon: 1.6, xbow: 1.3, axe: 1.2 },
  spear: { cavalry: 2.4, harcher: 1.9, hero: 1.7 },
  cavalry: { archer: 2.3, xbow: 2.0, cannon: 2.6, axe: 1.4, harcher: 1.3 },
  archer: { sword: 1.3, spear: 1.6, axe: 1.8, harcher: 1.6, xbow: 1.4 },
  guard: { archer: 1.3 },
  axe: { guard: 2.1, spear: 1.5, sword: 1.15, cannon: 1.6 },
  xbow: { cavalry: 2.4, guard: 2.0, hero: 1.4, harcher: 1.3 },
  harcher: { sword: 1.2, guard: 1.2, spear: 1.15 },
};

export const TYPE_NAME: Record<string, string> = {
  sword: "Pedang",
  spear: "Tombak",
  archer: "Pemanah",
  cavalry: "Kavaleri",
  guard: "Perisai",
  axe: "Gempur",
  xbow: "Tembak",
  harcher: "Panah Kuda",
  hero: "Hero",
  cannon: "Meriam",
};

export type Difficulty = "easy" | "normal" | "hard";
export const DIFF_MULT: Record<Difficulty, number> = {
  easy: 0.75,
  normal: 1.0,
  hard: 1.3,
};
