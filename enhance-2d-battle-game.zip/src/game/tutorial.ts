/**
 * Tutorial: eight short lessons. In each one the player makes ONE decision (which troops,
 * which shape, where), watches the fight, and is told what happened and why.
 *
 * Nothing here is folklore: every lesson was tried in the game's own simulation for all
 * four factions (the right choice wins, the wrong ones lose), and the verdicts are worded
 * from what really happened in the player's own fight – how many soldiers are left, how
 * many arrows flew before the lines met, which shape was drawn.
 */
import { SQUAD_TYPES, TYPE_NAME, unitCost } from "./constants";
import type { FactionId, SquadType } from "./constants";
import type { Game } from "./engine";
import type { Squad } from "./types";
import { matchOf } from "./advisor";
import { sfx } from "./audio";

type Pt = { x: number; y: number };

/* ------------------------------------------------------------------ */
/*  formation shapes                                                  */
/* ------------------------------------------------------------------ */
export type Shape = "tembok" | "kolom" | "blok" | "baji" | "mangkuk" | "miring";
export const SHAPE_NAME: Record<Shape, string> = { tembok: "Tembok", kolom: "Kolom", blok: "Gerombol", baji: "Baji", mangkuk: "Mangkuk", miring: "Miring" };

/** name the shape of a formation from where its soldiers stand (the enemy is to the right) */
export function shapeOf(pts: Pt[]): Shape {
  let x0 = Infinity;
  let x1 = -Infinity;
  let y0 = Infinity;
  let y1 = -Infinity;
  for (const p of pts) {
    x0 = Math.min(x0, p.x);
    x1 = Math.max(x1, p.x);
    y0 = Math.min(y0, p.y);
    y1 = Math.max(y1, p.y);
  }
  const depth = x1 - x0; // along the direction of advance
  const width = y1 - y0; // across it
  if (depth < 75 && width < 95) return "blok";
  if (width >= depth * 2.2) return "tembok";
  if (depth >= width * 2.2) return "kolom";
  // bent or slanted: is the middle of the line ahead of its two ends, or behind them?
  const a = pts[0];
  const b = pts[pts.length - 1];
  const m = pts[pts.length >> 1];
  const bulge = m.x - (a.x + b.x) / 2;
  if (bulge > 22) return "baji";
  if (bulge < -22) return "mangkuk";
  return "miring";
}

/* ------------------------------------------------------------------ */
/*  lessons                                                           */
/* ------------------------------------------------------------------ */
export interface Outcome {
  win: boolean;
  own: number;
  own0: number;
  foe: number;
  foe0: number;
  t: number;
}
export interface Verdict {
  pass: boolean;
  head: string;
  why: string;
}
export interface Placed {
  type: SquadType;
  shape: Shape;
  x: number;
  y: number;
  sq: Squad;
}
export interface Lesson {
  title: string;
  /** the situation */
  story: string;
  /** what to do now */
  task: string;
  /** what to look at while the fight runs */
  watch: string;
  /** the one thing to remember */
  rule: string;
  /** cards the player may use, and how many formations to place before the horn */
  allow: SquadType[];
  min: number;
  max: number;
  gold: (g: Game) => number;
  /** the advisor / the command panel are part of this lesson */
  advisor?: boolean;
  command?: boolean;
  /** no horn: everything is already on the field */
  live?: boolean;
  /** show the little pictures of the shapes */
  shapes?: boolean;
  /** a stroke to copy, shown on the field (with its caption), and a spot to point at */
  guide?: Pt[];
  guideText?: string;
  mark?: { x: number; y: number; text: string };
  /** measured comparison shown with the verdict: [label, soldiers left out of 20] */
  chart?: [string, number][];
  chartNote?: string;
  setup: (g: Game, T: Tut) => void;
  judge: (g: Game, T: Tut, r: Outcome) => Verdict;
}
export interface Tut {
  i: number;
  phase: "plan" | "fight" | "result" | "done";
  /** seconds in the current phase */
  t: number;
  placed: Placed[];
  own0: number;
  foe0: number;
  /** when the front line struck its first blow (-1: not yet) */
  tContact: number;
  /** arrows loosed by our shooters before that moment, and in total */
  arrows0: number;
  arrows: number;
  check: number;
  out: Outcome | null;
  verdict: Verdict | null;
  passed: boolean[];
}

/** the tutorial enemy: always a different people from the player's */
export const foeFor = (p: FactionId): FactionId => (p === "viking" ? "crusader" : "viking");

const MID = 423;
/** a wall of n soldiers, evenly spread along a 180-long line */
function put(g: Game, team: 0 | 1, type: SquadType, x: number, y: number, n = 20): Squad {
  g.spawnSquad(team, type, [{ x, y: y - 90 }, { x, y: y + 90 }], true);
  const sq = g.squads[g.squads.length - 1];
  const total = sq.units.length;
  if (n < total) {
    sq.units.forEach((u, j) => {
      if (Math.floor(((j + 1) * n) / total) === Math.floor((j * n) / total)) u.dead = true;
    });
    g.units = g.units.filter((u) => !u.dead);
    sq.units = sq.units.filter((u) => !u.dead);
    sq.initial = n;
    sq.alive = n;
  }
  return sq;
}
const cost = (g: Game, t: SquadType) => unitCost(t, g.fac[0]);
const nm = (g: Game, t: SquadType) => g.fac[0].unitNames[t];
const left = (r: Outcome) => `${r.own} dari ${r.own0}`;
/** the good choice was made but the dice fell badly */
const unlucky = (what: string): Verdict => ({ pass: false, head: "Pilihanmu benar, tapi kali ini kalah tipis", why: `${what} Pertempuran selalu punya sedikit untung-untungan — coba sekali lagi.` });

const WALL_HINT = "Coba lagi dengan garis lurus dari atas ke bawah (tembok).";

export const LESSONS: Lesson[] = [
  /* 1 ─────────────────────────────────────────────────────────── */
  {
    title: "Barisan pertamamu",
    story: "Satu garis yang kamu gambar menjadi satu barisan berisi 20 prajurit. Mereka menunggu di tempat sampai terompet berbunyi, lalu maju dan bertarung sendiri.",
    task: "Tahan tombol kiri mouse dan seret dari atas ke bawah di zonamu (kotak putus-putus di kiri), mengikuti garis kuning.",
    watch: "Setelah terompet, prajurit maju, memilih lawan, dan bertarung sendiri.",
    rule: "Sebelum terompet kamu menentukan tiga hal: JENIS pasukan, BENTUK barisan, dan TEMPATNYA.",
    allow: ["sword"],
    min: 1,
    max: 1,
    gold: (g) => cost(g, "sword"),
    guide: [
      { x: 540, y: MID - 90 },
      { x: 540, y: MID + 90 },
    ],
    setup: (g) => {
      put(g, 1, "sword", 1040, MID, 8);
    },
    judge: (_g, _T, r) =>
      r.win
        ? { pass: true, head: "Barisan pertamamu menang!", why: `Tersisa ${left(r)} prajurit. Kamu tidak menggerakkan mereka satu per satu: tugas panglima adalah tiga keputusan sebelum terompet — jenis pasukan, bentuk barisan, dan tempatnya. Tiga hal itulah yang dilatih di pelajaran berikutnya.` }
        : { pass: false, head: "Belum berhasil", why: WALL_HINT },
  },
  /* 2 ─────────────────────────────────────────────────────────── */
  {
    title: "Bentuk barisan",
    story: "Musuh menyusun 15 pedang menjadi tembok. Kamu punya 20 pedang — lebih banyak. Tapi bentuk barisan menentukan berapa prajuritmu yang benar-benar bertarung pada saat yang sama.",
    task: "Gambar barisanmu dalam bentuk apa saja dan lihat akibatnya. Nama bentuknya muncul saat kamu menggambar.",
    watch: "Hitung: berapa prajuritmu yang memukul pada saat yang sama?",
    rule: "Barisan melintang (tembok) membuat semua prajurit bertarung bersamaan.",
    allow: ["sword"],
    min: 1,
    max: 1,
    gold: (g) => cost(g, "sword"),
    shapes: true,
    chart: [["Tembok", 16], ["Gerombol", 13], ["Baji", 9], ["Miring", 8], ["Mangkuk", 8], ["Kolom", 3]],
    chartNote: "Rata-rata prajurit tersisa dari 20, pedang lawan 15 pedang (hasil uji simulasi)",
    setup: (g) => {
      put(g, 1, "sword", 1040, MID, 15);
    },
    judge: (_g, T, r) => {
      const s = T.placed[0].shape;
      const res = r.win ? `Tersisa ${left(r)} prajurit.` : `Barisanmu habis; musuh masih ${r.foe} dari ${r.foe0}.`;
      if (s === "tembok") {
        if (!r.win) return unlucky("Tembok adalah bentuk terbaik di sini.");
        return { pass: true, head: "Tembok: semua bertarung bersamaan", why: `${res} Garis melintang membuat ke-20 prajuritmu bertemu musuh pada saat yang sama: 20 pedang memukul 15. Musuh cepat habis, jadi korbanmu sedikit.` };
      }
      const but = r.win ? " Kamu masih menang karena jumlahmu lebih banyak, tapi korbannya jauh lebih besar daripada tembok." : "";
      const why: Record<Shape, string> = {
        tembok: "",
        kolom: `${res} Hanya ujung kolom yang bertemu musuh: beberapa prajurit terdepan dikeroyok 15 pedang sementara sisanya masih berjalan. Jumlahmu lebih banyak, tapi tidak pernah dipakai bersamaan.${but}`,
        baji: `${res} Ujung V sampai lebih dulu dan menghadapi seluruh tembok musuh sendirian; kedua sayapnya datang belakangan, sedikit demi sedikit.${but}`,
        mangkuk: `${res} Kedua ujung sampai lebih dulu dan bertarung tanpa bagian tengah. Lebih baik dari kolom, tapi tetap tidak bersamaan.${but}`,
        miring: `${res} Satu ujung barisan sampai lebih dulu dan bertarung sendirian sampai ujung lainnya tiba.${but}`,
        blok: `${res} Barisan rapat sampai hampir bersamaan, tapi hanya sisi depannya yang bertarung dan musuh bisa melingkarinya. (Dan nanti kamu lihat: gerombol berbahaya sekali bila musuh punya meriam.)${but}`,
      };
      const head: Record<Shape, string> = { tembok: "", kolom: "Kolom: prajuritmu antre", baji: "Baji: ujungnya dikeroyok", mangkuk: "Mangkuk: sayap lebih dulu", miring: "Miring: satu ujung lebih dulu", blok: "Gerombol: hanya sisi depan yang bertarung" };
      return { pass: false, head: head[s], why: `${why[s]} ${WALL_HINT}` };
    },
  },
  /* 3 ─────────────────────────────────────────────────────────── */
  {
    title: "Penangkal: kuda datang!",
    story: "20 kavaleri musuh siap menyerbu. Kuda yang berlari kencang menabrak menembus barisan biasa dan melempar prajurit ke udara. Hanya satu dari tiga kartumu yang bisa menghentikannya.",
    task: "Pilih kartu Tombak, Pedang, atau Pemanah di bawah, lalu gambar barisanmu.",
    watch: "Perhatikan saat kuda menabrak barisanmu.",
    rule: "Setiap jenis pasukan punya penangkal. Pilih penangkalnya, bukan yang termahal.",
    allow: ["spear", "sword", "archer"],
    min: 1,
    max: 1,
    gold: (g) => Math.max(cost(g, "spear"), cost(g, "sword"), cost(g, "archer")),
    setup: (g) => {
      put(g, 1, "cavalry", 1040, MID);
    },
    judge: (g, T, r) => {
      const t = T.placed[0].type;
      if (t === "spear") {
        if (!r.win) return unlucky("Tombak adalah penangkal kuda.");
        return { pass: true, head: "Pagar tombak menghentikan kuda", why: `Tersisa ${left(r)} prajurit. Kuda yang menabrak tombak langsung terhenti dan tertusuk: tombak memberi +140% luka pada pasukan berkuda. ${nm(g, "spear")} seharga ${cost(g, "spear")} emas mengalahkan kavaleri seharga 140 emas — penangkal yang tepat lebih penting daripada pasukan mahal.` };
      }
      if (t === "sword") return { pass: false, head: "Pedang terinjak", why: `Pedang tidak bisa menghentikan kuda yang berlari kencang: sebagian terlempar, sebagian terdorong ke samping, dan barisan pecah sebelum sempat membalas. Musuh masih ${r.foe} dari ${r.foe0}. Coba kartu Tombak.` };
      return { pass: false, head: "Pemanah tersapu", why: `Kavaleri terlalu cepat: pemanahmu hanya sempat melepas ${T.arrows} anak panah, lalu diinjak (kuda memberi +130% luka pada pemanah). Musuh masih ${r.foe} dari ${r.foe0}. Coba kartu Tombak.` };
    },
  },
  /* 4 ─────────────────────────────────────────────────────────── */
  {
    title: "Hujan panah",
    story: "20 pemanah musuh menunggu di seberang. Mereka mulai menembak jauh sebelum kamu bisa memukul: siapa pun yang maju pelan tanpa pelindung akan habis di jalan.",
    task: "Pilih kartu Perisai, Kavaleri, atau Tombak, lalu gambar barisanmu.",
    watch: "Perhatikan berapa prajuritmu yang jatuh sebelum sampai ke pemanah.",
    rule: "Lawan penembak: tahan panahnya (Perisai) atau capai mereka secepat mungkin (Kavaleri).",
    allow: ["guard", "cavalry", "spear"],
    min: 1,
    max: 1,
    gold: (g) => Math.max(cost(g, "guard"), cost(g, "cavalry"), cost(g, "spear")),
    setup: (g) => {
      put(g, 1, "archer", 1040, MID);
    },
    judge: (g, T, r) => {
      const t = T.placed[0].type;
      if (t === "guard") {
        if (!r.win) return unlucky("Perisai adalah jawaban yang benar untuk pemanah.");
        return { pass: true, head: "Tembok perisai menahan panah", why: `Tersisa ${left(r)} prajurit. Perisai besar menangkis sebagian besar panah yang datang dari depan, lebih banyak lagi saat barisan merapat. ${nm(g, "guard")} memang lambat, tapi sampai dengan utuh — dan pemanah tak berdaya dalam jarak dekat. Kavaleri juga jawaban yang benar: coba kalau penasaran.` };
      }
      if (t === "cavalry") {
        if (!r.win) return unlucky("Kavaleri adalah jawaban yang benar untuk pemanah.");
        return { pass: true, head: "Kuda terlalu cepat untuk ditembak", why: `Tersisa ${left(r)} prajurit. Kavaleri menempuh jarak tembak hanya dalam beberapa detik: pemanah cuma sempat melepas satu-dua tembakan sebelum diinjak (+130% luka). Perisai juga jawaban yang benar, dengan cara lain: menahan panahnya.` };
      }
      return { pass: false, head: "Tombak habis ditembak", why: `Tombak berjalan pelan tanpa pelindung yang cukup, dan panah memberi +60% luka pada mereka. Barisanmu habis sebelum sampai; musuh masih ${r.foe} dari ${r.foe0}. Tombak adalah penangkal kuda, bukan penangkal panah. Coba Perisai atau Kavaleri.` };
    },
  },
  /* 5 ─────────────────────────────────────────────────────────── */
  {
    title: "Pasukan pendukung: jarak itu penting",
    story: "27 pedang musuh — terlalu banyak untuk 20 pedangmu yang sudah berdiri di depan. Kamu mendapat 20 pemanah. Jangkauan panah pendek (kira-kira seperenam lebar lapangan) dan pemanah berjalan lebih lambat dari pedang.",
    task: "Gambar barisan pemanahmu. Pikirkan dulu: sedekat apa dengan pedangmu?",
    watch: "Perhatikan kapan pemanahmu mulai menembak: sebelum atau sesudah pedang beradu?",
    rule: "Semua pasukanmu harus sudah bisa menyerang saat garis depan bertemu musuh.",
    allow: ["archer"],
    min: 1,
    max: 1,
    gold: (g) => cost(g, "archer"),
    setup: (g) => {
      put(g, 0, "sword", 580, MID);
      put(g, 1, "sword", 1040, MID);
      put(g, 1, "sword", 1090, MID, 7);
    },
    judge: (_g, T, r) => {
      const a = T.arrows0; // arrows loosed before the swords struck their first blow
      const gap = 580 - T.placed[0].x; // how far behind the swords the archers were placed
      if (gap <= NEAR) {
        const ahead = gap < -10;
        if (!r.win) return ahead ? { pass: false, head: "Pemanah di depan ikut diserbu", why: `Pemanahmu sempat melepas ${a} anak panah, tapi kali ini musuh mencapai mereka sebelum pedangmu tiba. Lebih aman tepat di belakang pedang.` } : unlucky("Pemanahmu sudah di tempat yang benar.");
        return {
          pass: true,
          head: "Tepat: pemanah ikut bertarung sejak awal",
          why: `Saat pedang mulai beradu, pemanahmu sudah melepas ${a} anak panah, lalu terus menembak selama pedangmu menahan. Tersisa ${left(r)} prajurit — padahal 20 pedang saja pasti kalah melawan 27.${ahead ? " Pemanah di depan pun bisa: mereka berhenti di jarak tembak dan pedangmu maju melewatinya. Yang penting semuanya siap pada saat yang sama." : ""}`,
        };
      }
      return {
        pass: false,
        head: a === 0 ? "Pemanah terlambat" : "Pemanah agak terlambat",
        why: `${a === 0 ? "Belum satu pun anak panah lepas ketika pedang mulai beradu: pemanahmu masih berjalan menuju jarak tembak." : `Baru ${a} anak panah yang lepas ketika pedang mulai beradu.`} Selama itu 20 pedangmu melawan 27 sendirian.${r.win ? ` Kamu masih menang dengan ${left(r)} prajurit, tapi nyaris.` : ""} Pasang pemanah tepat di belakang pedangmu.`,
      };
    },
  },
  /* 6 ─────────────────────────────────────────────────────────── */
  {
    title: "Meriam: jangan bergerombol",
    story: "Tiga meriam musuh dijaga 6 pedang. Peluru meriam meledak dan melukai semua yang berdiri berdekatan. Kamu punya 20 pedang.",
    task: "Gambar barisanmu. Bentuk mana yang membuat satu ledakan mengenai paling sedikit orang?",
    watch: "Perhatikan berapa prajurit yang terlempar oleh tiap ledakan.",
    rule: "Lawan ledakan (meriam, api naft), menyebarlah selebar mungkin.",
    allow: ["sword"],
    min: 1,
    max: 1,
    gold: (g) => cost(g, "sword"),
    shapes: true,
    chart: [["Tembok", 8], ["Miring", 4], ["Mangkuk", 2], ["Baji", 2], ["Gerombol", 1], ["Kolom", 0]],
    chartNote: "Rata-rata prajurit tersisa dari 20, lawan 3 meriam + 6 pedang (hasil uji simulasi)",
    setup: (g) => {
      for (const y of [300, MID, 546]) g.spawnCannon(1, 1210, y);
      put(g, 1, "sword", 1040, MID, 6);
    },
    judge: (_g, T, r) => {
      const s = T.placed[0].shape;
      if (s === "tembok") {
        if (!r.win) return unlucky("Tembok lebar adalah bentuk yang benar melawan meriam.");
        return { pass: true, head: "Menyebar: tiap ledakan hanya kena beberapa orang", why: `Tersisa ${left(r)} prajurit. Barisan lebar memaksa tiap peluru hanya mengenai beberapa prajurit; sisanya terus maju. Dan begitu ada yang sampai, meriam kalah — meriam berbahaya dari jauh tapi tak berdaya dari dekat.` };
      }
      const res = r.win ? `Kamu menang, tapi hanya tersisa ${left(r)}.` : `Barisanmu habis; musuh masih ${r.foe} dari ${r.foe0}.`;
      const why: Record<Shape, string> = {
        tembok: "",
        blok: "Semua prajuritmu berdiri di dalam satu lingkaran ledakan: tiap peluru melukai hampir seluruh barisan sekaligus.",
        kolom: "Kolom itu rapat ke belakang: ledakan di tengahnya mengenai banyak orang, dan yang selamat datang sedikit demi sedikit ke pedang pengawal.",
        baji: "Bentuk V lebih rapat daripada tembok dan sampai tidak bersamaan: hasil ujinya jauh di bawah tembok.",
        mangkuk: "Bentuk V lebih rapat daripada tembok dan sampai tidak bersamaan: hasil ujinya jauh di bawah tembok.",
        miring: "Barisan miring cukup menyebar, tapi satu ujungnya sampai lebih dulu dan bertarung sendirian: hasil ujinya di antara tembok dan baji.",
      };
      return { pass: false, head: s === "miring" ? "Miring: menyebar, tapi tidak bersamaan" : `${SHAPE_NAME[s]}: terlalu rapat untuk meriam`, why: `${res} ${why[s]} ${WALL_HINT}` };
    },
  },
  /* 7 ─────────────────────────────────────────────────────────── */
  {
    title: "Komando: pilih, lalu perintah",
    story: "Kavalerimu sedang berjaga dengan perintah Tahan: mereka tidak akan maju sendiri. Di kanan atas, satu meriam musuh berdiri tanpa pengawal.",
    task: "1. Tahan tombol KANAN mouse dan seret melewati kavalerimu (muncul cincin kuning).  2. Klik KANAN pada meriam.  Tanpa tombol kanan? Nyalakan tombol Komando (C) di kanan atas.",
    watch: "",
    rule: "Kamu panglimanya: pilih pasukan, lalu tunjuk tujuannya.",
    allow: [],
    min: 0,
    max: 0,
    gold: () => 0,
    command: true,
    live: true,
    guide: [
      { x: 392, y: 560 },
      { x: 548, y: 560 },
    ],
    guideText: "1. Seret dengan tombol KANAN",
    mark: { x: 1160, y: 318, text: "2. Klik KANAN meriam ini" },
    setup: (g) => {
      const cav = put(g, 0, "cavalry", 470, 560);
      cav.state = "march";
      cav.launchT = 1;
      cav.order = { kind: "hold", x: cav.cx, y: cav.cy, target: null };
      g.spawnCannon(1, 1160, 330);
      const gun = g.squads[g.squads.length - 1];
      gun.state = "march";
      gun.launchT = 1;
      gun.order = { kind: "hold", x: gun.cx, y: gun.cy, target: null };
    },
    judge: (_g, _T, r) =>
      r.win
        ? { pass: true, head: "Perintah dijalankan!", why: `Tersisa ${left(r)} kavaleri. Pasukan yang dipilih mengikuti perintahmu: klik kanan musuh = serang, klik kanan tanah = pindah ke sana, T = tahan, R = mundur, S = serbu bebas. Meriam berbahaya dari jauh, tapi kalah oleh apa pun yang mencapainya — dan kuda paling cepat sampai.` }
        : { pass: false, head: "Kavalerimu habis", why: "Coba lagi: pilih kavaleri dengan seret tombol kanan, lalu klik kanan meriam." },
  },
  /* 8 ─────────────────────────────────────────────────────────── */
  {
    title: "Ujian: baca musuh, pilih penangkal",
    story: "Musuh memasang tembok tombak di depan dan pemanah di belakangnya. Kamu punya 170 emas, cukup untuk dua barisan. Semua kartu pasukan boleh dipakai.",
    task: "Pasang barisanmu. Tekan H: Penasihat menilai tiap kartu dan memberi alasannya (segitiga hijau = jenis yang dikalahkannya, merah = yang mengalahkannya).",
    watch: "Lihat siapa mengalahkan siapa.",
    rule: "Baca dulu susunan musuh, baru pilih jenis, bentuk, dan tempatnya.",
    allow: SQUAD_TYPES,
    min: 1,
    max: 2,
    gold: () => 170,
    advisor: true,
    setup: (g) => {
      put(g, 1, "spear", 1000, MID);
      put(g, 1, "archer", 1100, MID);
    },
    judge: (g, T, r) => {
      const word = (v: number) => (v >= 0.2 ? "menang lawan" : v <= -0.2 ? "kalah lawan" : "seimbang lawan");
      const seen = new Set<string>();
      const picks: string[] = [];
      for (const p of T.placed) {
        if (seen.has(p.type)) continue;
        seen.add(p.type);
        picks.push(`${nm(g, p.type)} (${TYPE_NAME[p.type]}) ${word(matchOf(g.fac[0].id, p.type, "spear"))} Tombak dan ${word(matchOf(g.fac[0].id, p.type, "archer"))} Pemanah.`);
      }
      const why = picks.join(" ");
      return r.win
        ? { pass: true, head: "Lulus: kamu membaca musuh dengan benar", why: `Tersisa ${left(r)} prajurit. ${why} Itulah cara berpikirnya: lihat dulu apa yang musuh pasang, lalu cari kartu yang mengalahkan keduanya.` }
        : { pass: false, head: "Belum tepat", why: `${why} Musuh masih ${r.foe} dari ${r.foe0}. Buka Penasihat (H) dan cari kartu berlabel hijau: itu yang mengalahkan Tombak sekaligus tahan terhadap Pemanah.` };
    },
  },
];

/** lesson 5: archers placed no further than this behind the swords count as "close" */
const NEAR = 80;

/* ------------------------------------------------------------------ */
/*  running a lesson                                                  */
/* ------------------------------------------------------------------ */
function count(g: Game) {
  let own = 0;
  let foe = 0;
  for (const u of g.units) {
    if (u.team === 0) own++;
    else foe++;
  }
  return [own, foe];
}

export function tutStart(g: Game, i: number, passed?: boolean[]) {
  const L = LESSONS[i];
  const keep = [...(passed ?? g.tut?.passed ?? LESSONS.map(() => false))]; // a copy: the caller keeps its own list
  g.reset(g.diff);
  g.state = "playing";
  g.hint = 0;
  g.cmdHint = 0;
  g.heroCd = {}; // heroes and cannons are not part of the lessons
  g.gold = [L.gold(g), 0];
  g.selected = L.allow[0] ?? "sword";
  const T: Tut = { i, phase: L.live ? "fight" : "plan", t: 0, placed: [], own0: 0, foe0: 0, tContact: -1, arrows0: 0, arrows: 0, check: 0.5, out: null, verdict: null, passed: keep };
  g.tut = T;
  L.setup(g, T);
  [T.own0, T.foe0] = count(g);
  g.events.push({ type: "tut" });
}

/** may this card be placed right now? returns the reason if not */
export function tutCan(g: Game, type: SquadType): string | null {
  const T = g.tut;
  if (!T) return null;
  const L = LESSONS[T.i];
  if (T.phase !== "plan") return T.phase === "fight" && L.live ? "Pelajaran ini tanpa barisan baru" : "Tunggu: pertempuran sedang berjalan";
  if (!L.allow.includes(type)) return "Kartu ini tidak dipakai di pelajaran ini";
  if (T.placed.length >= L.max) return "Barisanmu sudah cukup: bunyikan terompet";
  return null;
}

/** the player put a formation down */
export function tutPlace(g: Game, sq: Squad) {
  const T = g.tut;
  if (!T || T.phase !== "plan") return;
  T.placed.push({ type: sq.type as SquadType, shape: shapeOf(sq.units.map((u) => ({ x: u.x, y: u.y }))), x: sq.cx, y: sq.cy, sq });
  g.events.push({ type: "tut" });
}

/** sound the horn: both sides advance */
export function tutLaunch(g: Game): boolean {
  const T = g.tut;
  if (!T || T.phase !== "plan" || T.placed.length < LESSONS[T.i].min) return false;
  for (const sq of g.squads) {
    if (sq.state !== "ready" || sq.dead) continue;
    sq.state = "march";
    sq.launchT = 0;
    g.ring(sq.bannerX, sq.bannerY, g.fac[sq.team].light, 50);
    for (const u of sq.units) u.cheerT = 1 + Math.random() * 0.5;
  }
  g.drawing = null;
  g.closeAdvice();
  T.phase = "fight";
  T.t = 0;
  T.check = 0.5;
  [T.own0, T.foe0] = count(g);
  g.zoomPunch = 1;
  g.shake = Math.max(g.shake, 4);
  sfx.horn();
  g.events.push({ type: "tut" });
  return true;
}

/** called every step while a lesson runs */
export function tutTick(g: Game, dt: number) {
  const T = g.tut;
  if (!T) return;
  T.t += dt;
  if (T.phase !== "fight") return;
  const L = LESSONS[T.i];
  // what the verdict will be built from: the first blow of the front line, the arrows loosed
  for (const u of g.units) {
    if (u.team !== 0 || u.atkT < 0.99) continue; // atkT is 1 only on the step of the attack
    if (u.ranged) {
      T.arrows++;
      if (T.tContact < 0) T.arrows0++;
    } else if (T.tContact < 0) T.tContact = T.t;
  }
  T.check -= dt;
  if (T.check > 0) return;
  T.check = 0.2;
  const [own, foe] = count(g);
  let win: boolean;
  if (foe === 0 && own > 0) win = true;
  else if (own === 0) win = false;
  else if (!L.live && T.t > 80) win = false; // nobody finished it: not a win
  else return;
  const out: Outcome = { win, own, own0: T.own0, foe, foe0: T.foe0, t: T.t };
  T.out = out;
  T.verdict = L.judge(g, T, out);
  if (T.verdict.pass) T.passed[T.i] = true;
  T.phase = "result";
  T.t = 0;
  // everyone stays where they stand; the winners cheer
  for (const sq of g.squads) {
    if (sq.dead) continue;
    sq.order = { kind: "hold", x: sq.cx, y: sq.cy, target: null };
    sq.charging = false;
  }
  for (const u of g.units) {
    u.target = null;
    u.mom = 0;
    if (u.team === (win ? 0 : 1)) u.cheerT = 0.6 + Math.random() * 0.8;
  }
  g.clearSelection();
  if (T.verdict.pass) sfx.win();
  else sfx.lose();
  g.events.push({ type: "tut" });
}
