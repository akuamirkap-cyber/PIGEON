/**
 * Sound engine.
 *
 * Every effect is synthesised ONCE into a short sample made of shaped noise (impacts, metal
 * clanks, whooshes, thuds, crowd roars) and then just played back. That gives dry, physical
 * battle sounds instead of musical tones, and playing a sound costs only two or three audio
 * nodes, so a big fight cannot stall the game.
 */
const FIELD_W = 1600;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const R = (a: number, b: number) => a + Math.random() * (b - a);

type F = Float32Array;
let SR = 44100;
const N = (s: number) => Math.max(8, Math.floor(s * SR));

function white(n: number): F {
  const a = new Float32Array(n);
  for (let i = 0; i < n; i++) a[i] = Math.random() * 2 - 1;
  return a;
}
/** biquad over a buffer; f1 = end frequency of an exponential sweep */
function filt(x: F, type: "lp" | "hp" | "bp", f0: number, q: number, f1 = f0): F {
  const n = x.length;
  const y = new Float32Array(n);
  let b0 = 0, b1 = 0, b2 = 0, a1 = 0, a2 = 0, x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  const sweep = f1 !== f0;
  for (let i = 0; i < n; i++) {
    if (i === 0 || (sweep && (i & 31) === 0)) {
      const f = sweep ? f0 * Math.pow(f1 / f0, i / n) : f0;
      const w = (2 * Math.PI * Math.min(f, SR * 0.45)) / SR;
      const cs = Math.cos(w);
      const al = Math.sin(w) / (2 * q);
      const a0 = 1 + al;
      if (type === "lp") {
        b0 = (1 - cs) / 2 / a0;
        b1 = (1 - cs) / a0;
        b2 = b0;
      } else if (type === "hp") {
        b0 = (1 + cs) / 2 / a0;
        b1 = -(1 + cs) / a0;
        b2 = b0;
      } else {
        b0 = al / a0;
        b1 = 0;
        b2 = -al / a0;
      }
      a1 = (-2 * cs) / a0;
      a2 = (1 - al) / a0;
    }
    const v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
    x2 = x1;
    x1 = x[i];
    y2 = y1;
    y1 = v;
    y[i] = v;
  }
  return y;
}
/** attack (s), then exponential decay with time constant d (s) */
function env(x: F, a: number, d: number): F {
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] *= t < a ? t / a : Math.exp(-(t - a) / d);
  }
  return x;
}
function bell(x: F, p = 1): F {
  const n = x.length;
  for (let i = 0; i < n; i++) x[i] *= Math.pow(Math.sin((Math.PI * i) / n), p);
  return x;
}
function norm(x: F, peak = 1): F {
  let m = 0;
  for (let i = 0; i < x.length; i++) m = Math.max(m, Math.abs(x[i]));
  const k = m > 0 ? peak / m : 0;
  const fade = Math.min(x.length, N(0.004));
  for (let i = 0; i < x.length; i++) x[i] *= k * Math.min(1, (x.length - i) / fade);
  return x;
}
function mix(dst: F, src: F, g = 1, at = 0): F {
  const o = Math.floor(at * SR);
  for (let i = 0; i < src.length && i + o < dst.length; i++) dst[i + o] += src[i] * g;
  return dst;
}
/** one shaped noise layer, normalised */
const layer = (type: "lp" | "hp" | "bp", f: number, q: number, dur: number, a: number, d: number, f1 = f) => norm(env(filt(white(N(dur)), type, f, q, f1), a, d));
const out = (dur: number) => new Float32Array(N(dur));

/* ---------------- recipes ---------------- */
/** steel on steel: a handful of very short, inharmonic resonances + a broadband tick */
function clank(big = 1): F {
  const o = out(0.16 * big);
  for (let k = 0; k < 5; k++) mix(o, layer("bp", (2000 / big) * Math.pow(4.4, Math.random()), 26, 0.14 * big, 0.0005, (0.01 + Math.random() * 0.028) * big), 0.5);
  mix(o, layer("hp", 3200, 0.7, 0.03, 0.0003, 0.005), 0.9);
  mix(o, layer("bp", 430 / big, 2, 0.07, 0.0005, 0.014 * big), 0.55);
  return norm(o, 0.9);
}
/** blade into leather and flesh */
function flesh(): F {
  const o = out(0.14);
  mix(o, layer("lp", R(360, 480), 0.8, 0.13, 0.001, 0.03, 110), 1);
  mix(o, layer("bp", R(1200, 1700), 1.2, 0.05, 0.0005, 0.008), 0.35);
  return norm(o, 0.9);
}
function swish(lo = 650, hi = 3200, dur = 0.14): F {
  return norm(bell(filt(white(N(dur)), "bp", lo, 1.3, hi), 1.6), 0.8);
}
/** wooden shield takes a blow */
function wood(): F {
  const o = out(0.13);
  mix(o, layer("lp", 620, 0.8, 0.1, 0.0006, 0.02), 1);
  mix(o, layer("bp", R(170, 210), 5, 0.12, 0.0006, 0.03), 0.9);
  mix(o, layer("bp", R(2300, 3000), 10, 0.05, 0.0004, 0.01), 0.3);
  return norm(o, 0.9);
}
function bowShot(): F {
  const o = out(0.22);
  mix(o, layer("bp", 900, 2, 0.06, 0.0005, 0.02, 300), 0.9);
  mix(o, swish(1500, 4200, 0.18), 0.5, 0.02);
  return norm(o, 0.85);
}
function arrowHit(): F {
  const o = out(0.09);
  mix(o, layer("hp", 3500, 0.8, 0.02, 0.0003, 0.004), 0.7);
  mix(o, layer("lp", 300, 0.9, 0.08, 0.0006, 0.018), 1);
  return norm(o, 0.85);
}
function gunShot(): F {
  const o = out(0.42);
  mix(o, layer("hp", 700, 0.7, 0.12, 0.0003, 0.03), 1);
  mix(o, layer("lp", 240, 0.8, 0.4, 0.001, 0.09, 70), 1);
  return norm(o, 0.95);
}
function thump(low = 150, d = 0.06): F {
  const o = out(0.3);
  mix(o, layer("lp", low, 0.9, 0.28, 0.001, d, low * 0.45), 1);
  for (let i = 0; i < 4; i++) mix(o, layer("hp", R(2500, 5000), 1, 0.02, 0.0003, 0.004), 0.12, R(0.01, 0.1));
  return norm(o, 0.9);
}
function crash(): F {
  const o = out(0.7);
  mix(o, layer("lp", 150, 0.8, 0.6, 0.002, 0.17, 55), 1.2);
  mix(o, layer("bp", 1800, 1, 0.1, 0.0005, 0.03), 0.6);
  for (let i = 0; i < 4; i++) mix(o, clank(1.2), 0.45, 0.01 + i * 0.045 + Math.random() * 0.02);
  mix(o, wood(), 0.6, 0.03);
  return norm(o, 0.95);
}
function hooves(): F {
  const o = out(0.95);
  for (let i = 0; i < 9; i++) {
    const t = i * 0.078 + Math.floor(i / 3) * 0.09;
    mix(o, layer("bp", R(330, 460), 3, 0.05, 0.0005, 0.012), 0.8, t);
    mix(o, layer("lp", 150, 0.9, 0.06, 0.0008, 0.02), 0.8, t);
  }
  return norm(o, 0.8);
}
/** a horse blowing and snorting */
function snort(): F {
  const n = N(0.42);
  const a = filt(white(n), "bp", 950, 1.4, 600);
  const b = filt(white(n), "bp", 2300, 2);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    a[i] = (a[i] + b[i] * 0.5) * (0.55 + 0.45 * Math.sin(2 * Math.PI * 27 * t));
  }
  return norm(bell(a, 0.8), 0.7);
}
function boom(): F {
  const o = out(1.5);
  mix(o, layer("hp", 1500, 0.7, 0.05, 0.0003, 0.012), 0.7);
  mix(o, layer("lp", 230, 0.8, 0.9, 0.002, 0.2, 55), 1.3);
  mix(o, layer("lp", 95, 0.9, 1.4, 0.01, 0.42), 1);
  for (let i = 0; i < 9; i++) mix(o, layer("hp", R(2500, 6000), 1, 0.03, 0.0003, 0.006), 0.12, R(0.12, 0.8));
  return norm(o, 0.97);
}
function stone(): F {
  const o = out(0.4);
  mix(o, layer("lp", 320, 0.8, 0.2, 0.001, 0.045, 120), 1);
  for (let i = 0; i < 6; i++) mix(o, layer("bp", R(1400, 3600), 2, 0.03, 0.0004, 0.007), 0.22, R(0.02, 0.3));
  return norm(o, 0.9);
}
function collapse(): F {
  const o = out(2.6);
  mix(o, layer("lp", 120, 0.8, 2.5, 0.05, 0.9), 1.4);
  for (let i = 0; i < 46; i++) {
    const t = Math.random() * 2.1;
    mix(o, layer("bp", R(700, 3400), 1.6, 0.05, 0.0005, 0.012), 0.3, t);
    if (i % 4 === 0) mix(o, layer("lp", 220, 0.8, 0.2, 0.001, 0.05), 0.7, t);
  }
  return norm(o, 0.97);
}
/** a crowd of men roaring: noise through moving vowel formants */
function roar(dur = 1.3, pitch = 1): F {
  const n = N(dur);
  const o = new Float32Array(n);
  for (const [f, q, g] of [[640, 4, 1], [1080, 5, 0.8], [2500, 4, 0.35]] as const) {
    const b = filt(white(n), "bp", f * pitch * 0.9, q, f * pitch * 1.12);
    const r1 = R(4, 9);
    const r2 = R(0, 6);
    for (let i = 0; i < n; i++) o[i] += b[i] * g * (0.6 + 0.4 * Math.sin((2 * Math.PI * r1 * i) / SR + r2));
  }
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    o[i] *= Math.min(1, t / 0.16) * Math.min(1, (dur - t) / (dur * 0.5));
  }
  return norm(o, 0.8);
}
/** a short breathy grunt */
function grunt(): F {
  const n = N(0.17);
  const p = R(0.85, 1.2);
  const o = filt(white(n), "bp", 700 * p, 5, 520 * p);
  mix(o, filt(white(n), "bp", 1150 * p, 6), 0.7);
  return norm(env(o, 0.012, 0.045), 0.8);
}
/** the war horn that sends the waves forward */
function horn(f: number, dur: number, glide = 0): F {
  const n = N(dur);
  const o = new Float32Array(n);
  let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const fr = f * (1 - 0.06 * Math.exp(-t * 9) + glide * (t / dur)) * (1 + 0.004 * Math.sin(2 * Math.PI * 5.2 * t));
    ph += (2 * Math.PI * fr) / SR;
    let s = 0;
    for (let k = 1; k <= 7; k++) s += (Math.sin(ph * k) / Math.pow(k, 1.15)) * (k % 2 ? 1 : 0.7);
    o[i] = s * Math.min(1, t / 0.09) * Math.min(1, (dur - t) / 0.24);
  }
  mix(o, bell(filt(white(n), "bp", 900, 0.8), 0.6), 0.06);
  return norm(filt(o, "lp", 1250, 0.7), 0.8);
}
function tick(f = 1500, q = 6, d = 0.006): F {
  const o = out(0.05);
  mix(o, layer("bp", f, q, 0.04, 0.0003, d), 1);
  mix(o, layer("lp", 500, 0.8, 0.03, 0.0005, 0.008), 0.5);
  return norm(o, 0.8);
}
function coins(): F {
  const o = out(0.3);
  for (let i = 0; i < 4; i++) mix(o, layer("bp", R(4500, 7500), 30, 0.1, 0.0004, 0.022), 0.8, i * 0.045 + Math.random() * 0.01);
  return norm(o, 0.7);
}
function chirp(): F {
  const o = out(0.5);
  const base = R(2500, 4000);
  const k = 2 + Math.floor(Math.random() * 4);
  for (let j = 0; j < k; j++) {
    const n = N(0.06);
    const a = new Float32Array(n);
    let ph = 0;
    for (let i = 0; i < n; i++) {
      ph += (2 * Math.PI * base * (1 + (0.3 * i) / n)) / SR;
      a[i] = Math.sin(ph) * Math.sin((Math.PI * i) / n);
    }
    mix(o, a, 1, j * R(0.08, 0.11));
  }
  return norm(o, 0.5);
}
function loopNoise(type: "lp" | "bp" | "hp", f: number, q: number): F {
  const n = N(3);
  const fade = N(0.25);
  const a = filt(white(n + fade), type, f, q);
  const o = new Float32Array(n);
  for (let i = 0; i < n; i++) o[i] = i < fade ? a[i] * (i / fade) + a[n + i] * (1 - i / fade) : a[i];
  return norm(o, 0.9);
}

/** name -> [how many variants, recipe] */
const RECIPES: Record<string, [number, () => F]> = {
  clank: [5, () => clank()],
  clankBig: [3, () => clank(1.6)],
  flesh: [4, flesh],
  swish: [3, () => swish()],
  swishBig: [2, () => swish(350, 1800, 0.22)],
  wood: [3, wood],
  bow: [3, bowShot],
  volley: [2, () => norm(mix(mix(mix(out(0.7), bowShot(), 1), bowShot(), 0.8, 0.04), swish(1600, 600, 0.6), 0.9, 0.06), 0.85)],
  xbow: [2, () => norm(mix(mix(out(0.2), wood(), 1), swish(2000, 5000, 0.12), 0.6, 0.01), 0.85)],
  gun: [2, gunShot],
  arrowHit: [3, arrowHit],
  thunk: [3, () => tick(700, 3, 0.012)],
  tink: [3, () => norm(mix(out(0.08), layer("bp", R(3800, 5600), 22, 0.07, 0.0004, 0.014), 1), 0.7)],
  thump: [3, () => thump()],
  slam: [2, () => thump(110, 0.1)],
  crash: [2, crash],
  hooves: [2, hooves],
  snort: [2, snort],
  boom: [2, boom],
  stone: [3, stone],
  collapse: [1, collapse],
  roar: [3, () => roar()],
  roarLow: [2, () => roar(1.4, 0.82)],
  huh: [2, () => roar(0.32, 0.9)],
  grunt: [5, grunt],
  horn: [1, () => horn(123, 1.5)],
  hornHi: [1, () => horn(185, 1.0, 0.02)],
  hornLow: [1, () => horn(92, 1.5, -0.12)],
  drum: [2, () => thump(95, 0.11)],
  click: [2, () => tick()],
  tock: [1, () => tick(1100, 8, 0.012)],
  coins: [2, coins],
  dull: [1, () => norm(mix(mix(out(0.3), thump(200, 0.04), 1), thump(170, 0.04), 1, 0.11), 0.8)],
  chirp: [5, chirp],
};

class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  muted = false;
  vol = 0.75;
  last: Record<string, number> = {};
  bank: Record<string, AudioBuffer[]> = {};
  active = 0;
  ambientOn = false;
  windGain: GainNode | null = null;
  dinGain: GainNode | null = null;
  intensity = 0;

  ensure() {
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const c = new AC();
        this.ctx = c;
        SR = c.sampleRate;
        this.master = c.createGain();
        this.master.gain.value = this.muted ? 0 : this.vol;
        const comp = c.createDynamicsCompressor();
        comp.threshold.value = -16;
        comp.knee.value = 10;
        comp.ratio.value = 5;
        comp.attack.value = 0.003;
        comp.release.value = 0.16;
        this.master.connect(comp);
        comp.connect(c.destination);
      } catch {
        this.ctx = null;
      }
    }
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : this.vol, this.ctx.currentTime, 0.05);
  }

  /** samples are built the first time they are needed (a few ms each) */
  private get(name: string): AudioBuffer[] {
    let list = this.bank[name];
    if (!list) {
      const c = this.ctx!;
      const [count, make] = RECIPES[name];
      list = [];
      for (let i = 0; i < count; i++) {
        const d = make();
        const b = c.createBuffer(1, d.length, SR);
        b.getChannelData(0).set(d);
        list.push(b);
      }
      this.bank[name] = list;
    }
    return list;
  }

  play(name: string, x: number | undefined, vol: number, gap = 0.05, rate = 1, delay = 0) {
    const c = this.ctx;
    if (!c || !this.master || this.muted) return;
    const now = c.currentTime;
    if (gap > 0 && now - (this.last[name] ?? -9) < gap) return;
    if (this.active >= 22 && vol < 0.5) return; // keep the mix clean in a huge melee
    this.last[name] = now;
    const list = this.get(name);
    const s = c.createBufferSource();
    s.buffer = list[(Math.random() * list.length) | 0];
    s.playbackRate.value = rate * (0.93 + Math.random() * 0.14);
    const g = c.createGain();
    g.gain.value = vol;
    s.connect(g);
    if (x !== undefined && typeof c.createStereoPanner === "function") {
      const p = c.createStereoPanner();
      p.pan.value = clamp((x / FIELD_W - 0.5) * 1.5, -0.8, 0.8);
      g.connect(p);
      p.connect(this.master);
    } else g.connect(this.master);
    this.active++;
    s.onended = () => {
      this.active--;
    };
    s.start(now + delay);
  }

  /* ---------------- weapons ---------------- */
  sword(x?: number) {
    this.play("swish", x, 0.16, 0.07);
    if (Math.random() < 0.55) this.play("clank", x, 0.3, 0.045);
    else this.play("flesh", x, 0.34, 0.05);
  }
  spear(x?: number) {
    this.play("swish", x, 0.14, 0.07, 1.5);
    if (Math.random() < 0.35) this.play("clank", x, 0.24, 0.045, 1.2);
    else this.play("flesh", x, 0.34, 0.05, 1.1);
  }
  /** two-handed axe, club, hero blade */
  heavy(x?: number) {
    this.play("swishBig", x, 0.24, 0.09);
    this.play("slam", x, 0.42, 0.08, 1.15);
    if (Math.random() < 0.5) this.play("clankBig", x, 0.3, 0.08);
  }
  clang(x?: number, big = false) {
    this.play(big ? "clankBig" : "clank", x, big ? 0.42 : 0.3, 0.045);
  }
  block(x?: number) {
    this.play("wood", x, 0.34, 0.05);
  }
  bash(x?: number) {
    this.play("wood", x, 0.42, 0.08, 0.75);
    this.play("thump", x, 0.3, 0.08);
  }
  arrowBlock(x?: number) {
    this.play("tink", x, 0.2, 0.05);
  }
  bow(x?: number) {
    this.play("bow", x, 0.2, 0.07);
  }
  volley(x?: number) {
    this.play("volley", x, 0.34, 0.4);
  }
  xbow(x?: number) {
    this.play("xbow", x, 0.3, 0.07);
  }
  gun(x?: number) {
    this.play("gun", x, 0.42, 0.06);
  }
  toss(x?: number) {
    this.play("swish", x, 0.2, 0.07, 0.8);
  }
  firepot(x?: number) {
    this.play("boom", x, 0.32, 0.08, 2.1);
    this.play("swishBig", x, 0.22, 0, 0.6);
  }
  arrowHit(x?: number) {
    this.play("arrowHit", x, 0.28, 0.05);
  }
  thunk(x?: number) {
    this.play("thunk", x, 0.14, 0.06);
  }
  die(x?: number) {
    this.play("grunt", x, 0.24, 0.07);
  }
  /* ---------------- collisions ---------------- */
  /** first crash of a cavalry charge */
  charge(x?: number) {
    this.play("crash", x, 0.8, 0.25);
    this.play("snort", x, 0.3, 0.6, 1, 0.08);
  }
  /** two infantry lines meet */
  impact(x?: number) {
    this.play("slam", x, 0.45, 0.12);
    this.play("clank", x, 0.3, 0, 0.9, 0.02);
    this.play("wood", x, 0.3, 0, 1, 0.04);
  }
  trample(x?: number) {
    this.play("thump", x, 0.4, 0.07);
  }
  /** a body hits the ground */
  land(x?: number, hard = 1) {
    this.play("thump", x, 0.3 * hard, 0.06, 1.15);
  }
  neigh(x?: number) {
    this.play("snort", x, 0.34, 0.8);
  }
  gallop(x?: number) {
    this.play("hooves", x, 0.36, 0.5);
  }
  brace(x?: number) {
    this.play("huh", x, 0.4, 0.6);
    this.play("wood", x, 0.3, 0, 0.8, 0.1);
  }
  impale(x?: number) {
    this.play("clankBig", x, 0.34, 0.1);
    this.play("flesh", x, 0.42, 0, 0.8);
  }
  /* ---------------- siege ---------------- */
  cannon(x?: number) {
    this.play("boom", x, 0.75, 0.15, 1.25);
  }
  explosion(x?: number) {
    this.play("boom", x, 0.85, 0.1);
  }
  castle(x?: number) {
    this.play("stone", x, 0.34, 0.12);
  }
  castleFall(x?: number) {
    this.play("collapse", x, 1, 1);
  }
  /* ---------------- voices & signals ---------------- */
  battleCry(team: number, x?: number) {
    this.play(team === 0 ? "roar" : "roarLow", x, 0.4, 1.4);
  }
  horn() {
    this.play("horn", undefined, 0.42, 1);
  }
  drum(v = 1) {
    this.play("drum", undefined, 0.34 * v, 0.16);
  }
  phase(n: number) {
    this.play("hornLow", undefined, 0.5, 1);
    if (n >= 2) this.play("hornLow", undefined, 0.5, 0, 1, 0.9);
    this.play("drum", undefined, 0.5, 0);
  }
  /* ---------------- ui ---------------- */
  pop(x?: number) {
    this.play("click", x, 0.12, 0.04, 0.8);
  }
  deploy() {
    this.play("thump", undefined, 0.34, 0.1, 1.3);
    this.play("swish", undefined, 0.14, 0, 0.7);
  }
  coin() {
    this.play("coins", undefined, 0.24, 0.3);
  }
  hero() {
    this.play("hornHi", undefined, 0.4, 0.3);
    this.play("roar", undefined, 0.3, 0, 1.1, 0.1);
  }
  error() {
    this.play("dull", undefined, 0.3, 0.2);
  }
  click() {
    this.play("click", undefined, 0.22, 0.03);
  }
  tick() {
    this.play("tock", undefined, 0.3, 0.3);
  }
  /** squads selected */
  select() {
    this.play("click", undefined, 0.24, 0.04, 1.35);
  }
  /** an order is given: the men answer */
  order() {
    this.play("drum", undefined, 0.3, 0.1, 1.5);
    this.play("huh", undefined, 0.3, 0.25, 1.1, 0.05);
  }
  win() {
    this.play("hornHi", undefined, 0.5, 1);
    this.play("roar", undefined, 0.5, 0, 1.05, 0.3);
    this.play("roar", undefined, 0.4, 0, 0.95, 0.9);
  }
  lose() {
    this.play("hornLow", undefined, 0.55, 1);
  }

  /* ---------------- ambience ---------------- */
  private loop(name: string, type: "lp" | "bp" | "hp", f: number, q: number, gain: number) {
    const c = this.ctx!;
    const d = loopNoise(type, f, q);
    const b = c.createBuffer(1, d.length, SR);
    b.getChannelData(0).set(d);
    this.bank[name] = [b];
    const s = c.createBufferSource();
    s.buffer = b;
    s.loop = true;
    const g = c.createGain();
    g.gain.value = gain;
    s.connect(g);
    g.connect(this.master!);
    s.start();
    return g;
  }
  startAmbient() {
    if (!this.ctx || this.ambientOn) return;
    this.ambientOn = true;
    this.windGain = this.loop("_wind", "lp", 420, 0.7, 0.035); // a light breeze
    this.dinGain = this.loop("_din", "bp", 700, 0.5, 0); // the distant roar of the melee
    this.prewarm();
  }
  /** build the remaining samples a few at a time, so no sound has to be made mid-battle */
  prewarm() {
    const names = Object.keys(RECIPES).filter((n) => !this.bank[n]);
    const step = () => {
      const n = names.shift();
      if (!n || !this.ctx) return;
      this.get(n);
      setTimeout(step, 30);
    };
    setTimeout(step, 150);
  }
  /** 0..1 — how much fighting is going on */
  setIntensity(k: number) {
    this.intensity = clamp(k, 0, 1);
    if (!this.ctx || !this.ambientOn) return;
    this.dinGain?.gain.setTargetAtTime(0.09 * this.intensity, this.ctx.currentTime, 0.4);
  }
  ambientTick(dt: number) {
    if (!this.ctx || this.muted || !this.ambientOn) return;
    // birdsong of a bright morning (it falls silent while the armies clash)
    if (Math.random() < dt * 0.4 * (1 - this.intensity)) this.play("chirp", R(0, FIELD_W), 0.07, 0.6);
  }
}

export const sfx = new Sfx();
