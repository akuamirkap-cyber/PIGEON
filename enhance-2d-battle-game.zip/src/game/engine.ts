import {
  CANNON_DEF,
  CASTLE,
  CASTLE_HP,
  DIFF_MULT,
  FACTIONS,
  FIELD_BOTTOM,
  FIELD_TOP,
  GOLD_MAX,
  GOLD_START,
  H,
  HERO_COST,
  HERO_DEFS,
  INCOME_MULT,
  SQUAD_SIZE,
  TYPE_NAME,
  UNIT_DEFS,
  UNIT_MODS,
  W,
  WAVE_INCOME,
  WAVE_INCOME_GROWTH,
  WAVE_INCOME_MAX,
  WAVE_TIME,
  ZONES,
  unitCost,
} from "./constants";
import type { Difficulty, FactionDef, FactionId, HeroKind, SquadType, Team, UnitType } from "./constants";
import type { Decal, FloatText, Order, Particle, Projectile, Rag, Squad, StuckArrow, Unit } from "./types";
import { getLook } from "./figure";
import { sfx } from "./audio";
import { buildBackground, buildSkySprites, pickScale } from "./scenery";
import type { SkySprites } from "./scenery";
import { GCOLS, GROWS, updateGame } from "./sim";
import { renderGame } from "./render";
import { ANSWERS, advise } from "./advisor";
import { LESSONS, foeFor, tutCan, tutLaunch, tutPlace, tutStart, tutTick } from "./tutorial";
import type { Tut } from "./tutorial";
import type { Advice } from "./advisor";

type Pt = { x: number; y: number };
export type BasicType = SquadType;
export type GameState = "menu" | "playing" | "paused" | "won" | "lost";

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export interface CastleState {
  hp: number;
  max: number;
  squash: number;
  sv: number;
  flash: number;
  shootCd: number;
  smokeT: number;
  /** masonry that can still be torn down right now (refills every second) */
  guard: number;
}

export interface GameEvent {
  type: "nogold" | "deploy" | "end" | "hero" | "cooldown" | "launch" | "tick" | "refund" | "phase" | "order" | "tut";
}

interface AiAction {
  at: number; // phaseT value (counting down) at which to act
  kind: "plan" | "react" | "final";
  ref?: Squad;
}

/** squared distance from a point to a segment */
function segDist2(px: number, py: number, a: Pt, b: Pt) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const l2 = dx * dx + dy * dy;
  const t = l2 ? clamp(((px - a.x) * dx + (py - a.y) * dy) / l2, 0, 1) : 0;
  const cx = a.x + dx * t - px;
  const cy = a.y + dy * t - py;
  return cx * cx + cy * cy;
}
/** is the point inside the closed stroke? */
function inside(px: number, py: number, poly: Pt[]) {
  let hit = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const b = poly[j];
    if (a.y > py !== b.y > py && px < ((b.x - a.x) * (py - a.y)) / (b.y - a.y) + a.x) hit = !hit;
  }
  return hit;
}
const ORDER_SAY = { move: "Pindah!", siege: "Kepung istana!", attack: "Serang!", hold: "Tahan posisi!", retreat: "Mundur!", free: "Serbu bebas!" };
const ORDER_TINT = { move: "#ffe45c", siege: "#ffe45c", attack: "#ff6a55", hold: "#ffffff", retreat: "#8fd4ff", free: "#ffe45c" };

/** global unit scale */
export const US = 1.3;

/** what beats what, as measured in equal-gold duels: the enemy commander's answer to a squad it sees */
const ANSWER = ANSWERS;
const FRONT: SquadType[] = ["sword", "spear", "guard", "axe"];
const PICK: [SquadType, number][] = [["sword", 3], ["spear", 2], ["archer", 2.2], ["cavalry", 1.5], ["guard", 1.5], ["axe", 2], ["xbow", 1.2], ["harcher", 1]];

export class Game {
  units: Unit[] = [];
  squads: Squad[] = [];
  rags: Rag[] = [];
  /** settled bodies waiting to be stamped into the ground layer */
  corpses: Rag[] = [];
  particles: Particle[] = [];
  pool: Particle[] = [];
  projectiles: Projectile[] = [];
  stuck: StuckArrow[] = [];
  texts: FloatText[] = [];
  decals: Decal[] = [];
  castles: CastleState[] = [];
  factions: [FactionId, FactionId] = ["crusader", "viking"];
  fac: [FactionDef, FactionDef] = [FACTIONS.crusader, FACTIONS.viking];
  gold = [GOLD_START, GOLD_START];
  time = 0;
  state: GameState = "menu";
  selected: BasicType = "sword";
  pendingHero: HeroKind | null = null;
  pendingCannon = false;
  heroCd: Record<string, number> = {};
  drawing: Pt[] | null = null;
  mouse: Pt & { inside: boolean } = { x: 0, y: 0, inside: false };
  shake = 0;
  diff: Difficulty = "normal";
  stats = { deployed: 0, kills: 0, lost: 0, squads: 0, flung: 0, spent: 0 };
  events: GameEvent[] = [];
  aiActions: AiAction[] = [];
  aiSeen = new Set<number>();
  aiHeroCd = 25;
  aiSaidAt = -9;
  /** the advisor's current suggestion (null: panel closed) and its alternatives */
  advice: Advice | null = null;
  adviceList: Advice[] = [];
  adviceIdx = 0;
  adviceSig = "";
  /** the card the player is looking at (null: follow the advisor's top pick) */
  adviceKey: string | null = null;
  adviceT = 0;
  /** command: the squads the player has selected, the stroke being drawn, squads it would pick */
  selection: Squad[] = [];
  selecting: Pt[] | null = null;
  selAdd = false;
  preview: Squad[] = [];
  /** command mode: the left button / a finger gives orders instead of deploying (for trackpads and touch) */
  cmdMode = false;
  cmdHint = 1;
  /** the tutorial lesson being played (null: a normal match) */
  tut: Tut | null = null;
  phaseT = WAVE_TIME;
  wave = 1;
  launchFx = 0;
  marchDrumT = 0;
  lastIncome = [0, 0];
  nextId = 1;
  grid: Unit[][] = [];
  bg!: HTMLCanvasElement;
  bgKey = "";
  endT = 0;
  hint = 1;
  blood = true;
  zoomPunch = 0;
  /** seconds played; the match is decided at MATCH_TIME at the latest */
  matchT = 0;
  /** 0 = battle, 1 = decisive round, 2 = sudden death */
  phase = 0;
  endReason: "castle" | "hp" | "kills" | "army" = "castle";
  hitStop = 0;
  intensity = 0;
  sndT = 0;
  sky: SkySprites;
  /** old blood, craters and the fallen are baked into this layer: constant cost per frame */
  ground: HTMLCanvasElement;
  gctx: CanvasRenderingContext2D;
  gscale: number;
  groundFadeAt = 0;
  groundStampAt = 0;
  /** dirty rectangle of the ground layer in field coordinates (x0 > x1: empty) */
  gbox = [1, 1, 0, 0];
  /** device pixels per logical pixel (set by the app) – sprites are cached at this sharpness */
  pxScale = 1;

  constructor() {
    this.sky = buildSkySprites();
    this.gscale = Math.min(1.5, pickScale());
    this.ground = document.createElement("canvas");
    this.ground.width = Math.round(W * this.gscale);
    this.ground.height = Math.round(H * this.gscale);
    this.gctx = this.ground.getContext("2d")!;
    this.gctx.scale(this.gscale, this.gscale);
    for (let i = 0; i < GCOLS * GROWS; i++) this.grid.push([]);
    this.setFactions("crusader", "viking");
    this.reset("normal");
    this.state = "menu";
    this.spawnDemo();
  }

  /** choose who fights whom; the landscape around each castle follows its owner */
  setFactions(player: FactionId, enemy: FactionId) {
    this.factions = [player, enemy];
    this.fac = [FACTIONS[player], FACTIONS[enemy]];
    const key = player + "/" + enemy;
    if (key !== this.bgKey) {
      this.bgKey = key;
      this.bg = buildBackground(11, this.factions);
    }
  }

  reset(diff: Difficulty) {
    this.diff = diff;
    this.units = [];
    this.squads = [];
    this.rags = [];
    this.corpses = [];
    this.particles = [];
    this.projectiles = [];
    this.stuck = [];
    this.texts = [];
    this.decals = [];
    this.pendingCannon = false;
    this.castles = [0, 1].map((t) => {
      const hp = Math.round(CASTLE_HP * this.fac[t].castleHp);
      return { hp, max: hp, squash: 0, sv: 0, flash: 0, shootCd: 0, smokeT: 0, guard: 0 };
    });
    this.time = 0;
    this.stats = { deployed: 0, kills: 0, lost: 0, squads: 0, flung: 0, spent: 0 };
    this.heroCd = {};
    this.fac[0].heroes.forEach((h) => (this.heroCd[h] = 10));
    this.phaseT = WAVE_TIME;
    this.wave = 1;
    this.aiSeen = new Set();
    this.aiActions = [];
    this.aiHeroCd = 25;
    this.gold = [GOLD_START, Math.round(GOLD_START * DIFF_MULT[diff])];
    this.lastIncome = [0, 0];
    this.planAI();
    this.drawing = null;
    this.pendingHero = null;
    this.endT = 0;
    this.hint = 1;
    this.matchT = 0;
    this.phase = 0;
    this.endReason = "castle";
    this.hitStop = 0;
    this.shake = 0;
    this.advice = null;
    this.adviceList = [];
    this.adviceKey = null;
    this.selection = [];
    this.selecting = null;
    this.preview = [];
    this.cmdMode = false;
    this.cmdHint = 1;
    this.tut = null;
    this.clearGround();
  }

  start(diff: Difficulty, player: FactionId, enemy: FactionId) {
    this.setFactions(player, enemy);
    this.reset(diff);
    this.state = "playing";
    sfx.deploy();
  }

  update(dt: number) {
    updateGame(this, dt);
    if (this.tut && this.state === "playing") tutTick(this, Math.min(dt, 1 / 30));
    if (this.selection.length) {
      let gone = false;
      for (const s of this.selection) if (s.dead) gone = true;
      if (gone) {
        this.selection = this.selection.filter((s) => !s.dead);
        this.events.push({ type: "order" });
      }
    }
    if (this.advice) {
      if (this.state !== "playing" && this.state !== "paused") this.closeAdvice();
      else if ((this.adviceT -= dt) <= 0) {
        // the situation changed (new wave, new formations, gold): think again
        this.adviceT = 0.4;
        if (this.situation() !== this.adviceSig) this.askAdvice();
      }
    }
  }

  /* ------------------------------------------------------------ */
  /*  Advisor                                                     */
  /* ------------------------------------------------------------ */
  /** what the advice depends on: when this changes the advisor thinks again */
  private situation() {
    let a = 0;
    let b = 0;
    let foes = 0;
    for (const s of this.squads) {
      if (s.dead) continue;
      if (s.team === 1) foes++;
      if (s.state !== "ready") continue;
      if (s.team === 0) a++;
      else b++;
    }
    // which cards can be paid for right now
    const g = this.gold[0];
    let mask = 0;
    let i = 0;
    for (const t in UNIT_DEFS) if (g >= unitCost(t as BasicType, this.fac[0])) mask |= 1 << i++;
    else i++;
    if (g >= HERO_COST) mask |= 1 << 9;
    if (g >= CANNON_DEF.cost) mask |= 1 << 10;
    let cd = 0;
    for (const h of this.fac[0].heroes) if ((this.heroCd[h] ?? 0) > 0) cd++;
    return `${this.wave}:${a}:${b}:${foes}:${mask}:${cd}:${this.phase}`;
  }
  /** ask the advisor: every card rated, the best one that can be deployed first */
  askAdvice() {
    this.adviceList = advise(this);
    let i = this.adviceKey ? this.adviceList.findIndex((x) => x.key === this.adviceKey) : 0;
    if (i < 0) {
      i = 0;
      this.adviceKey = null;
    }
    this.adviceIdx = i;
    this.advice = this.adviceList[i] ?? null;
    this.adviceSig = this.situation();
  }
  nextAdvice() {
    if (this.adviceList.length < 2) return this.askAdvice();
    this.adviceIdx = (this.adviceIdx + 1) % this.adviceList.length;
    this.advice = this.adviceList[this.adviceIdx];
    this.adviceKey = this.adviceIdx === 0 ? null : this.advice.key;
  }
  /** what does the advisor say about this particular card? */
  showAdvice(key: string) {
    if (!this.adviceList.length) this.adviceList = advise(this);
    const i = this.adviceList.findIndex((x) => x.key === key);
    if (i < 0) return;
    this.adviceIdx = i;
    this.advice = this.adviceList[i];
    this.adviceKey = key;
    this.adviceSig = this.situation();
  }
  closeAdvice() {
    this.advice = null;
    this.adviceList = [];
    this.adviceKey = null;
  }
  /** deploy exactly what the advisor suggests, then let it think about the next move */
  applyAdvice(): boolean {
    const a = this.advice;
    if (!a || a.kind === "wait" || this.state !== "playing") return false;
    if (this.tut) {
      const no = a.kind === "squad" && a.type ? tutCan(this, a.type) : "Tidak dipakai di pelajaran ini";
      if (no) {
        this.deny(a.x, a.y, no);
        return false;
      }
    }
    if (this.gold[0] < a.cost) {
      this.deny(a.x, a.y, "Emas kurang!", true);
      return false;
    }
    if (a.kind === "squad" && a.type) {
      this.gold[0] -= a.cost;
      this.stats.spent += a.cost;
      this.spawnSquad(0, a.type, a.path);
    } else if (a.kind === "hero" && a.hero) {
      if ((this.heroCd[a.hero] ?? 0) > 0) return false;
      this.gold[0] -= a.cost;
      this.stats.spent += a.cost;
      this.spawnHero(0, a.hero, a.x, a.y);
      this.heroCd[a.hero] = HERO_DEFS[a.hero].cooldown;
    } else if (a.kind === "cannon") {
      if (this.cannonCount(0) >= CANNON_DEF.max) return false;
      this.gold[0] -= a.cost;
      this.stats.spent += a.cost;
      this.spawnCannon(0, a.x, a.y);
    } else return false;
    this.hint = 0;
    this.events.push({ type: "deploy" });
    this.adviceKey = null;
    this.askAdvice();
    return true;
  }
  /** S = device pixels per logical pixel of the target canvas */
  render(ctx: CanvasRenderingContext2D, S: number) {
    renderGame(this, ctx, S);
  }

  clearGround() {
    const g = this.gctx;
    g.save();
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, this.ground.width, this.ground.height);
    g.restore();
    this.gbox = [1, 1, 0, 0];
    this.groundFadeAt = this.time;
    this.groundStampAt = this.time;
  }

  /** ambient demo armies for the menu backdrop */
  spawnDemo() {
    const shapes: [Team, BasicType, Pt[]][] = [
      [0, "sword", this.linePts(380, 300, 470, 420)],
      [0, "axe", this.linePts(330, 470, 450, 600)],
      [1, "spear", this.linePts(1200, 300, 1120, 440)],
      [1, "archer", this.linePts(1260, 480, 1260, 640)],
    ];
    shapes.forEach(([t, ty, p]) => this.spawnSquad(t, ty, p, true));
    this.squads.forEach((s) => {
      if (s.state === "ready") {
        s.state = "march";
        s.launchT = 0;
      }
    });
  }

  linePts(x0: number, y0: number, x1: number, y1: number): Pt[] {
    return [
      { x: x0, y: y0 },
      { x: x1, y: y1 },
    ];
  }

  /* ------------------------------------------------------------ */
  /*  Formation sampling                                          */
  /* ------------------------------------------------------------ */
  samplePath(pts: Pt[], team: Team, type: UnitType): Pt[] {
    const n = SQUAD_SIZE;
    const Z = ZONES[team];
    const cl = (p: Pt) => ({ x: clamp(p.x, Z.x0, Z.x1), y: clamp(p.y, FIELD_TOP + 10, FIELD_BOTTOM - 10) });
    let total = 0;
    const segs: number[] = [];
    for (let i = 1; i < pts.length; i++) {
      const d = Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
      segs.push(d);
      total += d;
    }
    const out: Pt[] = [];
    if (total < 26) {
      // compact block
      const c = pts[pts.length - 1];
      const sp = (type === "cavalry" || type === "harcher" ? 16 : 12) * US;
      const cols = 4;
      const rows = 5;
      for (let i = 0; i < n; i++) {
        const cx = i % cols;
        const ry = Math.floor(i / cols);
        out.push(cl({ x: c.x + (cx - (cols - 1) / 2) * sp + (ry % 2) * 3, y: c.y + (ry - (rows - 1) / 2) * sp }));
      }
      return out;
    }
    for (let i = 0; i < n; i++) {
      let target = (total * i) / (n - 1);
      let k = 0;
      while (k < segs.length - 1 && target > segs[k]) {
        target -= segs[k];
        k++;
      }
      const a = pts[k];
      const b = pts[k + 1] ?? pts[k];
      const t = segs[k] > 0 ? clamp(target / segs[k], 0, 1) : 0;
      out.push(cl({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }));
    }
    return out;
  }

  /* ------------------------------------------------------------ */
  /*  Spawning                                                    */
  /* ------------------------------------------------------------ */
  makeUnit(team: Team, type: UnitType, x: number, y: number, squad: Squad, delay: number, hero?: HeroKind): Unit {
    const f = this.fac[team];
    let hp, atk, cd, range, speed, aggro, radius;
    let cleave = 0;
    let ranged = false;
    let mounted = false;
    let scale = US;
    if (type === "cannon") {
      ({ hp, atk, cd, range, speed, aggro } = CANNON_DEF);
      radius = 7;
      ranged = true;
    } else if (hero) {
      const d = HERO_DEFS[hero];
      ({ hp, atk, cd, range, speed, aggro, radius, cleave } = d);
      ranged = !!d.ranged;
      mounted = !!d.mounted;
      scale = 1.5 * US;
    } else {
      const d = UNIT_DEFS[type as BasicType];
      ({ hp, atk, cd, range, speed, aggro, radius } = d);
      ranged = !!d.ranged;
      mounted = !!d.mounted;
    }
    // what this faction's own version of the unit is known for
    const mod = hero || type === "cannon" ? undefined : UNIT_MODS[f.id][type as BasicType];
    if (mod) {
      hp *= mod.hp ?? 1;
      atk *= mod.atk ?? 1;
      speed *= mod.speed ?? 1;
      cd *= mod.cd ?? 1;
      range *= mod.range ?? 1;
      if (ranged) aggro *= mod.range ?? 1;
    }
    // faction strengths
    hp *= f.hp;
    atk *= ranged ? f.ranged : f.melee;
    if (ranged) {
      range *= f.rangeMul;
      aggro *= f.rangeMul;
    }
    speed *= f.speed * (mounted ? f.mountSpeed : 1) * rand(0.94, 1.06);
    radius *= US;
    const look = getLook(f.id, type, hero);
    const shield = look.shield !== "";
    let bm = 0;
    let ba = 0;
    if (type === "sword") {
      bm = shield ? 0.3 : 0.22;
      ba = shield ? 0.42 : 0.06;
    } else if (type === "spear" || type === "cavalry") {
      bm = shield ? 0.18 : 0.08;
      ba = shield ? 0.14 : 0.03;
    } else if (type === "guard") {
      bm = 0.5;
      ba = 0.78;
    } else if (hero && shield) {
      bm = 0.25;
      ba = 0.3;
    }
    if (bm > 0.1) {
      bm += f.block;
      ba += f.block;
    }
    return {
      id: this.nextId++,
      team,
      type,
      hero,
      look,
      x,
      y,
      vx: 0,
      vy: 0,
      hp,
      maxHp: hp,
      atk,
      cd,
      cdT: rand(0, cd),
      range,
      speed,
      aggro,
      radius,
      cleave,
      ranged,
      mounted,
      charger: mounted && !ranged,
      skirmish: mounted && ranged,
      facing: team === 0 ? 1 : -1,
      walk: rand(0, 6),
      spawnT: -delay,
      hitT: 0,
      atkT: 0,
      showHpT: 0,
      target: null,
      attackingCastle: false,
      retarget: rand(0, 0.2),
      squad,
      offX: 0,
      offY: 0,
      dead: false,
      scale,
      seed: Math.random() * 100,
      shootDelay: -1,
      cheerT: 0,
      charged: false,
      recoil: 0,
      kvx: 0,
      kvy: 0,
      rag: null,
      stunT: 0,
      trampleT: 0,
      braceT: 0,
      mom: 0,
      attackers: 0,
      aimed: 0,
      combo: Math.floor(Math.random() * 4),
      value: hero ? 14 : type === "cannon" ? 4 : mounted ? 2.4 : type === "guard" ? 1.6 : 1,
      blockM: bm,
      blockA: ba,
      crit: f.crit,
      berserk: f.berserk && !ranged,
    };
  }

  private mkSquad(team: Team, type: UnitType, x: number, y: number, speed: number, n: number, cost: number, hero?: HeroKind): Squad {
    return {
      id: this.nextId++,
      team,
      type,
      hero,
      anchorX: x,
      anchorY: y,
      units: [],
      bannerX: x,
      bannerY: y,
      speed,
      spawnT: 0,
      dead: false,
      deadT: 0,
      engaged: 0,
      alive: n,
      state: "ready",
      walk: 0,
      volleyCd: 0,
      volleyWant: false,
      initial: n,
      launchT: 0,
      cost,
      charging: false,
      avgMom: 0,
      cx: x,
      cy: y,
      mox: 0,
      moy: 0,
      goalX: NaN, // no goal until the squad has thought once
      goalY: NaN,
      thinkT: Math.random() * 0.3,
      targetSq: null,
      fallT: 0,
      fallCd: 0,
      rallyX: 0,
      rallyY: 0,
      wheel: false,
      regrouped: false,
      braceT: 0,
      threatX: 0,
      arrowT: 0,
      stuckT: 0,
      crashed: false,
      shoutT: 0,
      orbit: Math.random() < 0.5 ? 1 : -1,
      orbitT: rand(3, 5),
      order: null,
      sel: false,
    };
  }

  spawnSquad(team: Team, type: BasicType, path: Pt[], silent = false) {
    const f = this.fac[team];
    const d = UNIT_DEFS[type];
    const pts = this.samplePath(path, team, type);
    const cx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
    const cy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
    const sq = this.mkSquad(team, type, cx, cy, d.speed * f.speed * (d.mounted ? f.mountSpeed : 1) * (UNIT_MODS[f.id][type]?.speed ?? 1), SQUAD_SIZE, unitCost(type, f));
    pts.forEach((p, i) => {
      const u = this.makeUnit(team, type, p.x, p.y, sq, silent ? 0 : i * 0.03);
      u.offX = p.x - cx;
      u.offY = p.y - cy;
      sq.units.push(u);
      this.units.push(u);
    });
    this.squads.push(sq);
    if (!silent) {
      this.ring(cx, cy, f.light, 60);
      if (team === 0) {
        sfx.deploy();
        this.stats.deployed += SQUAD_SIZE;
        this.stats.squads++;
      }
      if (this.tut && team === 0) tutPlace(this, sq);
    }
  }

  spawnHero(team: Team, kind: HeroKind, x: number, y: number) {
    const Z = ZONES[team];
    const d = HERO_DEFS[kind];
    const f = this.fac[team];
    x = clamp(x, Z.x0, Z.x1);
    y = clamp(y, FIELD_TOP + 10, FIELD_BOTTOM - 10);
    const sq = this.mkSquad(team, "hero", x, y, d.speed * f.speed * (d.mounted ? f.mountSpeed : 1), 1, HERO_COST, kind);
    const u = this.makeUnit(team, "hero", x, y, sq, 0, kind);
    sq.units.push(u);
    this.units.push(u);
    this.squads.push(sq);
    this.ring(x, y, "#f2c23a", 80);
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      this.addP(x, y, 4, Math.cos(a) * 90, Math.sin(a) * 45, rand(40, 90), "star", "#f2c23a", 0.8, rand(2, 3.5));
    }
    this.shake = Math.max(this.shake, 5);
    this.text(x, y - 46, d.name + "!", "#ffe08a", 1.8, 20);
    sfx.hero();
  }

  cannonCount(team: Team) {
    let n = 0;
    for (const u of this.units) if (u.team === team && u.type === "cannon") n++;
    return n;
  }

  spawnCannon(team: Team, x: number, y: number) {
    const Z = ZONES[team];
    x = clamp(x, Z.x0, Z.x1);
    y = clamp(y, FIELD_TOP + 10, FIELD_BOTTOM - 10);
    const sq = this.mkSquad(team, "cannon", x, y, CANNON_DEF.speed, 1, CANNON_DEF.cost);
    const u = this.makeUnit(team, "cannon", x, y, sq, 0);
    sq.units.push(u);
    this.units.push(u);
    this.squads.push(sq);
    this.ring(x, y, this.fac[team].light, 50);
    this.dust(x, y, 6, 40);
    sfx.deploy();
  }

  /* ------------------------------------------------------------ */
  /*  Particles / texts (particles are pooled: no garbage)         */
  /* ------------------------------------------------------------ */
  addP(x: number, y: number, z: number, vx: number, vy: number, vz: number, kind: Particle["kind"], color: string, life: number, size: number): Particle {
    let p = this.pool.pop();
    if (p) {
      p.x = x;
      p.y = y;
      p.z = z;
      p.vx = vx;
      p.vy = vy;
      p.vz = vz;
      p.life = life;
      p.max = life;
      p.size = size;
      p.color = color;
      p.kind = kind;
      p.rot = rand(0, 6);
      p.vr = rand(-10, 10);
    } else p = { x, y, z, vx, vy, vz, life, max: life, size, color, kind, rot: rand(0, 6), vr: rand(-10, 10) };
    this.particles.push(p);
    return p;
  }
  ring(x: number, y: number, color: string, size: number) {
    this.addP(x, y, 0, 0, 0, 0, "ring", color, 0.5, size);
  }
  dust(x: number, y: number, n: number, spread = 30) {
    if (this.particles.length > 420) n = Math.ceil(n / 3);
    for (let i = 0; i < n; i++) this.addP(x + rand(-3, 3), y + rand(-2, 2), 1, rand(-spread, spread), rand(-spread, spread) * 0.4, rand(5, 20), "dust", "", rand(0.4, 0.8), rand(2, 4));
  }
  text(x: number, y: number, text: string, color: string, max = 1, size = 16) {
    this.texts.push({ x, y, text, color, t: 0, max, size });
  }

  /* ------------------------------------------------------------ */
  /*  Input                                                       */
  /* ------------------------------------------------------------ */
  inZone(x: number, y: number) {
    const Z = ZONES[0];
    return x >= Z.x0 - 30 && x <= Z.x1 + 30 && y >= FIELD_TOP - 20 && y <= FIELD_BOTTOM + 20;
  }
  private deny(x: number, y: number, msg: string, gold = false) {
    this.text(x, y - 14, msg, gold ? "#ffd766" : "#ffc2b8", 1, 17);
    sfx.error();
    if (gold) this.events.push({ type: "nogold" });
  }

  pointerDown(x: number, y: number, button: number, shift = false) {
    if (this.state !== "playing") return;
    sfx.ensure();
    if (button === 0 && this.cmdMode) button = 2; // command mode: the left button gives orders
    if (button === 2) {
      if (this.drawing || this.pendingHero || this.pendingCannon) {
        this.drawing = null;
        this.pendingHero = null;
        this.pendingCannon = false;
        return;
      }
      // a stroke selects the squads it touches; a short tap is a click (select one / give an order)
      this.selecting = [{ x, y }];
      this.selAdd = shift;
      this.preview = [];
      return;
    }
    if (this.pendingCannon) {
      if (!this.inZone(x, y)) return this.deny(x, y, "Di luar zona!");
      if (this.gold[0] < CANNON_DEF.cost) return this.deny(x, y, "Emas kurang!", true);
      if (this.cannonCount(0) >= CANNON_DEF.max) return this.deny(x, y, "Maks " + CANNON_DEF.max + " meriam!");
      this.gold[0] -= CANNON_DEF.cost;
      this.stats.spent += CANNON_DEF.cost;
      this.spawnCannon(0, x, y);
      if (this.gold[0] < CANNON_DEF.cost || this.cannonCount(0) >= CANNON_DEF.max) this.pendingCannon = false;
      this.events.push({ type: "deploy" });
      return;
    }
    if (this.pendingHero) {
      if (!this.inZone(x, y)) return this.deny(x, y, "Di luar zona!");
      if (this.gold[0] < HERO_COST) return this.deny(x, y, "Emas kurang!", true);
      const h = this.pendingHero;
      this.gold[0] -= HERO_COST;
      this.stats.spent += HERO_COST;
      this.spawnHero(0, h, x, y);
      this.heroCd[h] = HERO_DEFS[h].cooldown;
      this.pendingHero = null;
      this.events.push({ type: "hero" });
      return;
    }
    if (!this.inZone(x, y)) return this.deny(x, y, "Gambar di zonamu!");
    if (this.tut) {
      const no = tutCan(this, this.selected);
      if (no) return this.deny(x, y, no);
    }
    this.drawing = [{ x, y }];
  }

  /* ------------------------------------------------------------ */
  /*  Command: select squads with a stroke, then give them orders  */
  /* ------------------------------------------------------------ */
  clearSelection() {
    for (const s of this.selection) s.sel = false;
    this.selection = [];
    this.events.push({ type: "order" });
  }
  select(list: Squad[], add: boolean) {
    if (!add) {
      for (const s of this.selection) s.sel = false;
      this.selection = [];
    }
    for (const s of list) {
      if (s.sel) continue;
      s.sel = true;
      this.selection.push(s);
    }
    if (list.length) {
      sfx.select();
      this.cmdHint = 0;
    }
    this.events.push({ type: "order" });
  }
  selectAll() {
    this.select(this.squads.filter((s) => s.team === 0 && !s.dead), false);
  }
  /** the squad of the given side whose soldier stands closest to the point */
  squadAt(x: number, y: number, team: Team, r: number): Squad | null {
    let best: Squad | null = null;
    let bd = r * r;
    for (const u of this.units) {
      if (u.team !== team || u.dead || u.spawnT < 0) continue;
      const d = (u.x - x) ** 2 + (u.y - 9 - y) ** 2;
      if (d < bd) {
        bd = d;
        best = u.squad;
      }
    }
    return best;
  }
  /** own squads touched by the stroke – or enclosed by it, when it is drawn as a loop */
  pickByStroke(path: Pt[]): Squad[] {
    let len = 0;
    for (let i = 1; i < path.length; i++) len += Math.hypot(path[i].x - path[i - 1].x, path[i].y - path[i - 1].y);
    const a = path[0];
    const b = path[path.length - 1];
    const loop = path.length > 8 && len > 170 && Math.hypot(a.x - b.x, a.y - b.y) < Math.max(50, len * 0.2);
    const out: Squad[] = [];
    for (const sq of this.squads) {
      if (sq.team !== 0 || sq.dead) continue;
      for (const u of sq.units) {
        if (u.dead) continue;
        let hit = false;
        for (let i = 1; i < path.length && !hit; i++) hit = segDist2(u.x, u.y - 8, path[i - 1], path[i]) < 24 * 24;
        if (!hit && loop) hit = inside(u.x, u.y - 8, path);
        if (hit) {
          out.push(sq);
          break;
        }
      }
    }
    return out;
  }
  private finishSelect() {
    const path = this.selecting!;
    this.selecting = null;
    this.preview = [];
    let len = 0;
    for (let i = 1; i < path.length; i++) len += Math.hypot(path[i].x - path[i - 1].x, path[i].y - path[i - 1].y);
    if (len < 14) return this.commandTap(path[0].x, path[0].y);
    const picked = this.pickByStroke(path);
    this.select(picked, this.selAdd);
    const end = path[path.length - 1];
    if (!picked.length) this.text(end.x, end.y - 14, "Tidak ada pasukanmu di garis itu", "#fff3d6", 1.2, 15);
  }
  /** a click with the command button: select the squad under it, or send the selection there */
  private commandTap(x: number, y: number) {
    const own = this.squadAt(x, y, 0, 24);
    if (own) {
      if (this.selAdd && own.sel) {
        // shift-click again drops it from the selection
        own.sel = false;
        this.selection = this.selection.filter((s) => s !== own);
        this.events.push({ type: "order" });
        sfx.click();
      } else this.select([own], this.selAdd);
      return;
    }
    if (!this.selection.length) {
      this.text(x, y - 14, "Pilih pasukan dulu: seret melewati mereka", "#fff3d6", 1.6, 15);
      return;
    }
    const foe = this.squadAt(x, y, 1, 28);
    if (foe) return this.order("attack", foe.cx, foe.cy, foe);
    const C = CASTLE[1];
    if (x > C.cx - C.hw - 16 && y > C.top - 10 && y < C.baseY + 24) return this.order("siege", C.cx - C.hw - 22, clamp(y, C.top + 96, C.baseY + 14));
    this.order("move", x, y);
  }
  /**
   * Give the selected squads an order. Squads already on the field obey at once;
   * squads still waiting for the horn carry it out when the horn sounds ("hold" keeps them in reserve).
   */
  order(kind: Order["kind"] | "free" | "siege", x = 0, y = 0, target: Squad | null = null) {
    const sel = this.selection.filter((s) => !s.dead);
    if (!sel.length || this.state !== "playing") return;
    let cx = 0;
    let cy = 0;
    for (const s of sel) {
      cx += s.cx / sel.length;
      cy += s.cy / sel.length;
    }
    const x0 = CASTLE[0].cx + 92;
    const x1 = CASTLE[1].cx - 92;
    let waiting = 0;
    sel.forEach((s, i) => {
      if (s.state === "ready") waiting++;
      if (kind === "free") s.order = null;
      else if (kind === "hold") s.order = { kind: "hold", x: s.cx, y: s.cy, target: null };
      else if (kind === "attack") s.order = { kind: "attack", x, y, target };
      else if (kind === "retreat") {
        // fall back to the castle gate, each squad in its own lane
        s.order = { kind: "retreat", x: ZONES[0].x0 + 36 + (i % 3) * 44, y: clamp(s.cy, FIELD_TOP + 60, FIELD_BOTTOM - 60), target: null };
        if (s.state === "march") {
          s.charging = false;
          for (const u of s.units) {
            u.target = null;
            u.mom = 0;
          }
        }
      } else {
        // the squads keep their places relative to each other
        let ox = (s.cx - cx) * 0.75;
        let oy = (s.cy - cy) * 0.75;
        const d = Math.hypot(ox, oy);
        if (d > 170) {
          ox *= 170 / d;
          oy *= 170 / d;
        }
        if (kind === "siege") ox = 0;
        s.order = { kind: "move", x: clamp(x + ox, x0, x1), y: clamp(y + oy, FIELD_TOP + 16, FIELD_BOTTOM - 16), target: null };
      }
      if (s.state === "fallback") {
        // the commander overrides the squad's own regroup
        s.state = "march";
        s.fallCd = 6;
      }
      s.thinkT = 0;
    });
    const own = kind === "hold" || kind === "free" || kind === "retreat";
    const fx = own ? cx : x;
    const fy = own ? cy : y;
    this.ring(fx, fy, ORDER_TINT[kind], 46);
    this.text(fx, fy - 34, ORDER_SAY[kind] + (waiting === sel.length && kind !== "hold" ? " (saat terompet)" : ""), ORDER_TINT[kind], 1.2, 18);
    sfx.order();
    this.cmdHint = 0;
    this.events.push({ type: "order" });
  }
  /** what a squad that has not marched yet is worth if it is called off */
  refundOf(sq: Squad) {
    return Math.round((sq.cost * sq.alive) / sq.initial);
  }
  /** call off the selected squads that are still waiting for the horn and get the gold back */
  refundSelected() {
    const off = this.selection.filter((s) => s.team === 0 && s.state === "ready" && !s.dead);
    if (!off.length) return;
    let sum = 0;
    for (const sq of off) {
      const back = this.refundOf(sq);
      sum += back;
      this.stats.spent -= back;
      if (sq.type !== "hero" && sq.type !== "cannon") this.stats.squads--;
      else if (sq.hero) this.heroCd[sq.hero] = 0;
      for (const u of sq.units) {
        if (u.dead) continue;
        u.dead = true;
        this.dust(u.x, u.y, 2, 20);
      }
      sq.sel = false;
      this.text(sq.bannerX, sq.bannerY - 50, "+" + back + " emas (batal)", "#ffe08a", 1.2, 16);
    }
    this.gold[0] = Math.min(GOLD_MAX, this.gold[0] + sum);
    this.units = this.units.filter((u) => !u.dead);
    this.squads = this.squads.filter((s) => !off.includes(s));
    this.selection = this.selection.filter((s) => !off.includes(s));
    sfx.click();
    this.events.push({ type: "refund" });
  }

  pointerMove(x: number, y: number) {
    this.mouse.x = x;
    this.mouse.y = y;
    this.mouse.inside = true;
    if (this.selecting) {
      const last = this.selecting[this.selecting.length - 1];
      if (Math.hypot(x - last.x, y - last.y) > 6) {
        this.selecting.push({ x, y });
        this.preview = this.pickByStroke(this.selecting);
      }
    } else if (this.drawing) {
      const last = this.drawing[this.drawing.length - 1];
      if (Math.hypot(x - last.x, y - last.y) > 5) this.drawing.push({ x, y });
    }
  }

  pointerUp() {
    if (this.selecting) return this.finishSelect();
    if (!this.drawing) return;
    const path = this.drawing;
    this.drawing = null;
    if (path.length < 3) {
      // a plain click on your own soldiers selects them instead of dropping a block on their heads
      const own = this.squadAt(path[0].x, path[0].y, 0, 20);
      if (own) return this.select([own], false);
    }
    const cost = unitCost(this.selected, this.fac[0]);
    if (this.gold[0] < cost) {
      const p = path[path.length - 1];
      return this.deny(p.x, p.y, "Emas kurang!", true);
    }
    this.gold[0] -= cost;
    this.stats.spent += cost;
    this.spawnSquad(0, this.selected, path);
    this.hint = 0;
    this.events.push({ type: "deploy" });
  }

  selectCannon() {
    if (this.tut) return this.deny(this.mouse.x, this.mouse.y, "Tidak dipakai di pelajaran ini");
    if (this.cannonCount(0) >= CANNON_DEF.max) return this.deny(this.mouse.x, this.mouse.y, "Maks " + CANNON_DEF.max + " meriam!");
    this.pendingCannon = !this.pendingCannon;
    this.pendingHero = null;
    sfx.click();
  }

  selectHero(h: HeroKind) {
    if (this.tut) return this.deny(this.mouse.x, this.mouse.y, "Tidak dipakai di pelajaran ini");
    this.pendingCannon = false;
    if ((this.heroCd[h] ?? 0) > 0) {
      sfx.error();
      this.events.push({ type: "cooldown" });
      return;
    }
    this.pendingHero = this.pendingHero === h ? null : h;
    sfx.click();
  }

  /* ------------------------------------------------------------ */
  /*  Waves                                                       */
  /* ------------------------------------------------------------ */
  income() {
    return Math.round(Math.min(WAVE_INCOME_MAX, WAVE_INCOME + (this.wave - 1) * WAVE_INCOME_GROWTH) * INCOME_MULT[this.phase]);
  }

  launchWave() {
    let n = 0;
    for (const sq of this.squads) {
      if (sq.state !== "ready" || sq.dead) continue;
      if (sq.order && sq.order.kind === "hold") continue; // ordered to stay behind as a reserve
      sq.state = "march";
      sq.launchT = 0;
      n++;
      this.ring(sq.bannerX, sq.bannerY, this.fac[sq.team].light, 50);
      for (const u of sq.units) u.cheerT = 1 + Math.random() * 0.5;
    }
    const inc = this.income();
    const m = DIFF_MULT[this.diff];
    this.lastIncome = [inc, Math.round(inc * m)];
    this.gold[0] = Math.min(GOLD_MAX, this.gold[0] + inc);
    this.gold[1] = Math.min(GOLD_MAX, this.gold[1] + inc * m);
    this.wave++;
    this.phaseT = WAVE_TIME;
    this.planAI();
    this.marchDrumT = n > 0 ? 2 : 0;
    this.launchFx = 1;
    this.shake = Math.max(this.shake, n > 0 ? 4 : 1.5);
    sfx.horn();
    sfx.coin();
    if (n > 0) {
      setTimeout(() => sfx.battleCry(0), 700);
      setTimeout(() => sfx.battleCry(1), 950);
    }
    this.zoomPunch = 1;
    this.events.push({ type: "launch" });
  }

  readyCounts(team: Team) {
    const c: Record<string, number> = {};
    for (const sq of this.squads) if (sq.team === team && sq.state === "ready" && !sq.dead) c[sq.type] = (c[sq.type] ?? 0) + 1;
    return c;
  }

  /* ------------------------------------------------------------ */
  /*  AI commander — watches your preparation and answers it       */
  /* ------------------------------------------------------------ */
  planAI() {
    const m = DIFF_MULT[this.diff];
    this.aiActions = [
      { at: WAVE_TIME - rand(0.6, 1.6), kind: "plan" },
      { at: WAVE_TIME * rand(0.42, 0.6), kind: "plan" },
      { at: m >= 1.2 ? rand(0.5, 0.9) : rand(1.0, 1.8), kind: "final" },
    ];
  }

  aiPlace(type: BasicType, laneY: number, reason?: string): boolean {
    const f = this.fac[1];
    const cost = unitCost(type, f);
    if (this.gold[1] < cost) return false;
    const Z = ZONES[1];
    let y = clamp(laneY, FIELD_TOP + 95, FIELD_BOTTOM - 95);
    let path: Pt[];
    const r = Math.random();
    if (type === "spear" || type === "guard") {
      // the wall goes in front
      const x = Z.x0 + rand(30, 95);
      path = r < 0.6 ? this.linePts(x, y - 95, x, y + 95) : [{ x: x + 40, y: y - 85 }, { x: x - 25, y }, { x: x + 40, y: y + 85 }];
    } else if (type === "sword" || type === "axe") {
      const x = Z.x0 + rand(45, 135);
      path = r < 0.5 ? [{ x: x + 55, y: y - 85 }, { x: x - 45, y }, { x: x + 55, y: y + 85 }] : r < 0.8 ? this.linePts(x, y - 90, x, y + 90) : this.linePts(x - 30, y - 85, x + 30, y + 85);
    } else if (type === "archer" || type === "xbow") {
      // shooters stand in an arc at the back
      const x = Z.x1 - rand(30, 110);
      path = [];
      for (let i = 0; i <= 8; i++) {
        const a = -1.0 + (2.0 * i) / 8;
        path.push({ x: x - Math.cos(a) * 40 + 40, y: y + Math.sin(a) * 100 });
      }
    } else if (type === "harcher") {
      // horse archers come round the flank
      y = Math.random() < 0.5 ? FIELD_TOP + rand(90, 150) : FIELD_BOTTOM - rand(90, 150);
      const x = rand(Z.x0 + 90, Z.x1 - 120);
      path = this.linePts(x - 70, y - 30, x + 70, y + 30);
    } else {
      const x = rand(Z.x0 + 120, Z.x1 - 60);
      path = r < 0.6 ? [{ x: x + 45, y: y - 75 }, { x: x - 40, y }, { x: x + 45, y: y + 75 }] : this.linePts(x - 50, y - 70, x + 50, y + 70);
    }
    this.gold[1] -= cost;
    this.spawnSquad(1, type, path);
    if (reason && Math.abs(this.time - this.aiSaidAt) > 1.8) {
      this.aiSaidAt = this.time;
      const c = path.reduce((a, p) => ({ x: a.x + p.x / path.length, y: a.y + p.y / path.length }), { x: 0, y: 0 });
      this.text(c.x, c.y - 62, reason, "#dce8ff", 2.2, 16);
    }
    return true;
  }

  aiLane(): number {
    const mine = this.squads.filter((s) => s.team === 0 && !s.dead);
    if (mine.length && Math.random() < 0.7) {
      const s = mine[Math.floor(Math.random() * mine.length)];
      return s.anchorY + rand(-40, 40);
    }
    return [270, 440, 610][Math.floor(Math.random() * 3)] + rand(-40, 40);
  }

  aiPickType(): { type: BasicType; reason?: string } {
    const m = DIFF_MULT[this.diff];
    const cnt: Record<string, number> = {};
    for (const u of this.units) if (u.team === 0) cnt[u.type] = (cnt[u.type] ?? 0) + (u.type === "hero" ? 12 : u.type === "cannon" ? 8 : 1);
    let top = "";
    for (const k in cnt) if (!top || cnt[k] > cnt[top]) top = k;
    if (top && cnt[top] > 8 && Math.random() < Math.min(0.9, 0.55 * m)) {
      const t = ANSWER[top];
      return { type: t, reason: `${this.fac[1].unitNames[t]} menangkal ${TYPE_NAME[top]}!` };
    }
    // balanced army: a front line first, then shooters, then whatever fits
    const ready = this.readyCounts(1);
    if (!FRONT.some((t) => ready[t])) return { type: FRONT[Math.floor(Math.random() * FRONT.length)] };
    if (!ready.archer && !ready.xbow && Math.random() < 0.7) return { type: Math.random() < 0.7 ? "archer" : "xbow" };
    let total = 0;
    for (const [, w] of PICK) total += w;
    let roll = Math.random() * total;
    for (const [t, w] of PICK) {
      roll -= w;
      if (roll <= 0) return { type: t };
    }
    return { type: "sword" };
  }

  private aiCannon(chance: number) {
    if (this.wave <= 1 || this.gold[1] < CANNON_DEF.cost || this.cannonCount(1) >= CANNON_DEF.max || Math.random() > chance) return false;
    this.gold[1] -= CANNON_DEF.cost;
    const cx = rand(ZONES[1].x1 - 90, ZONES[1].x1 - 20);
    const cy = clamp(this.aiLane(), FIELD_TOP + 95, FIELD_BOTTOM - 95);
    this.spawnCannon(1, cx, cy);
    return true;
  }

  updateAI(dt: number) {
    const m = DIFF_MULT[this.diff];
    this.aiHeroCd -= dt;
    // watch the player's preparation
    for (const sq of this.squads) {
      if (sq.team !== 0 || sq.state !== "ready" || this.aiSeen.has(sq.id)) continue;
      this.aiSeen.add(sq.id);
      if (Math.random() > 0.35 + 0.45 * m) continue; // an easy AI sometimes does not notice
      const at = this.phaseT - rand(0.7, 2.0) / m;
      if (at > 0.25) this.aiActions.push({ at, kind: "react", ref: sq });
    }
    let due = false;
    for (const a of this.aiActions) if (a.at >= this.phaseT) due = true;
    if (!due) return;
    const now = this.aiActions.filter((a) => a.at >= this.phaseT);
    this.aiActions = this.aiActions.filter((a) => a.at < this.phaseT);
    for (const a of now) {
      if (a.kind === "react" && a.ref) {
        const ref = a.ref;
        if (ref.dead || ref.state !== "ready") continue;
        const t = ANSWER[ref.type];
        this.aiPlace(t, ref.anchorY + rand(-20, 20), `${this.fac[1].unitNames[t]} menangkal ${TYPE_NAME[ref.type]}!`);
      } else if (a.kind === "plan") {
        const reserve = m >= 1.2 ? 0.35 : 0.15;
        if (this.gold[1] * (1 - reserve) < 60) continue;
        if (this.aiCannon(0.14 + 0.1 * m)) continue;
        const pick = this.aiPickType();
        this.aiPlace(pick.type, this.aiLane(), pick.reason);
      } else {
        // final: hero or spend the rest
        if (this.aiHeroCd <= 0 && this.gold[1] >= HERO_COST && Math.random() < 0.55) {
          const hs = this.fac[1].heroes;
          this.gold[1] -= HERO_COST;
          this.spawnHero(1, hs[Math.floor(Math.random() * hs.length)], rand(ZONES[1].x0 + 60, ZONES[1].x1 - 40), this.aiLane());
          this.aiHeroCd = rand(35, 50) / m;
        }
        this.aiCannon(0.18 + 0.08 * m);
        const keep = m < 0.9 ? this.gold[1] * 0.4 : 0;
        let guard = 0;
        while (this.gold[1] - keep >= 60 && guard++ < 4) {
          const pick = this.aiPickType();
          if (!this.aiPlace(pick.type, this.aiLane(), pick.reason) && !this.aiPlace("sword", this.aiLane())) break;
        }
      }
    }
  }

  /* ------------------------------------------------------------ */
  /*  Tutorial                                                    */
  /* ------------------------------------------------------------ */
  /** start lesson i as the given faction (passed: lessons already completed) */
  startTutorial(i: number, player: FactionId, passed?: boolean[]) {
    this.setFactions(player, foeFor(player));
    tutStart(this, Math.max(0, Math.min(LESSONS.length - 1, i)), passed);
  }
  tutLaunch() {
    return tutLaunch(this);
  }
  tutRetry() {
    if (this.tut) tutStart(this, this.tut.i);
  }
  tutGoto(i: number) {
    if (this.tut && i >= 0 && i < LESSONS.length) tutStart(this, i);
  }
  /** on to the next lesson; after the last one the summary is shown */
  tutNext() {
    const T = this.tut;
    if (!T) return;
    if (T.i + 1 < LESSONS.length) tutStart(this, T.i + 1);
    else {
      T.phase = "done";
      this.events.push({ type: "tut" });
    }
  }

  counts() {
    let a = 0;
    let b = 0;
    for (const u of this.units) {
      if (u.team === 0) a++;
      else b++;
    }
    return [a, b];
  }
}
