/**
 * The advisor ("Penasihat"): rates EVERY card – all eight troop types, both heroes and the
 * cannon – for the battle as it stands, and says where each would go and why.
 *
 * It does not guess. The tables below were measured with the game's own simulation: every troop
 * type fought every other with the same amount of gold – once with neutral troops, and once
 * for each faction with its own troops. For each card the advisor
 *   1. works out how much of every enemy formation is still unanswered by our own troops,
 *   2. scores the card by how it fares against exactly that enemy mix, adjusted for what
 *      our army is missing (a front line first, then shooters and riders) and for variety,
 *   3. places it in the lane where it is needed most, in the spot where that unit fights
 *      best (all measured): infantry as a wall across the advance, shooters close behind the
 *      front line, riders on a flank,
 *   4. and explains the verdict – including, for a poor fit, what to save it for.
 */
import { CANNON_DEF, CASTLE, FIELD_BOTTOM, FIELD_TOP, HERO_COST, HERO_DEFS, SQUAD_TYPES, TYPE_NAME, UNIT_DEFS, ZONES, unitCost } from "./constants";
import type { FactionId, HeroKind, SquadType } from "./constants";
import type { Game } from "./engine";
import type { Squad } from "./types";

type Pt = { x: number; y: number };

export interface Advice {
  /** the card this is about: a troop type, a hero, "cannon" – or "wait" */
  key: string;
  kind: "squad" | "hero" | "cannon" | "wait";
  type?: SquadType;
  hero?: HeroKind;
  /** the formation line to draw (squads only) */
  path: Pt[];
  x: number;
  y: number;
  name: string;
  role: string;
  cost: number;
  title: string;
  reason: string;
  /** one of the faction's signature troops */
  star?: boolean;
  /** the enemy formation this answers */
  tx?: number;
  ty?: number;
  /** how well it suits the battle right now: 3 sangat cocok, 2 cocok, 1 bisa dipakai, 0 kurang cocok */
  fit: number;
  score: number;
  /** can be deployed this very moment */
  ok: boolean;
  /** if not: why */
  blocked?: string;
}

/**
 * MATCH[a][b]: outcome of a duel between equal gold of a and b
 * (+1 = a wipes b out without a scratch, -1 = the reverse). Measured, not assumed.
 */
// prettier-ignore
export const MATCH: Record<string, Record<string, number>> = /*MATCH*/{"sword":{"sword":0,"spear":0.4,"archer":0.44,"cavalry":-0.13,"guard":0.37,"axe":-0.48,"xbow":0.41,"harcher":-0.08,"hero":-0.05,"cannon":0.82},"spear":{"sword":-0.4,"spear":0,"archer":-0.48,"cavalry":0.93,"guard":0.25,"axe":-0.37,"xbow":-0.09,"harcher":-0.5,"hero":0.31,"cannon":0.76},"archer":{"sword":-0.44,"spear":0.48,"archer":0,"cavalry":-0.83,"guard":-0.71,"axe":0.71,"xbow":0.04,"harcher":0.64,"hero":-0.16,"cannon":0.66},"cavalry":{"sword":0.13,"spear":-0.93,"archer":0.83,"cavalry":0,"guard":-0.42,"axe":0.38,"xbow":-0.35,"harcher":0.77,"hero":0.1,"cannon":0.96},"guard":{"sword":-0.37,"spear":-0.25,"archer":0.71,"cavalry":0.42,"guard":0,"axe":-0.79,"xbow":-0.45,"harcher":0.45,"hero":-0.22,"cannon":0.84},"axe":{"sword":0.48,"spear":0.37,"archer":-0.71,"cavalry":-0.38,"guard":0.79,"axe":0,"xbow":0.02,"harcher":-0.75,"hero":-0.05,"cannon":0.78},"xbow":{"sword":-0.41,"spear":0.09,"archer":-0.04,"cavalry":0.35,"guard":0.45,"axe":-0.02,"xbow":0,"harcher":0.88,"hero":0.9,"cannon":0.8},"harcher":{"sword":0.08,"spear":0.5,"archer":-0.64,"cavalry":-0.77,"guard":-0.45,"axe":0.75,"xbow":-0.88,"harcher":0,"hero":-0.22,"cannon":0.89},"hero":{"sword":0.05,"spear":-0.31,"archer":0.16,"cavalry":-0.1,"guard":0.22,"axe":0.05,"xbow":-0.9,"harcher":0.22,"hero":0,"cannon":1},"cannon":{"sword":-0.82,"spear":-0.76,"archer":-0.66,"cavalry":-0.96,"guard":-0.84,"axe":-0.78,"xbow":-0.8,"harcher":-0.89,"hero":-1,"cannon":0}}/*END*/;
/**
 * The same duels fought with each faction's OWN troops (their bonuses, shields and signature
 * units) against a neutral enemy. This is what the advice is based on: a Samurai swordsman has
 * no shield and loses to archers, a Crusader one wins; Ayyubid "crossbows" throw fire, and so on.
 */
// prettier-ignore
const MATCH_F: Record<string, Record<string, Record<string, number>>> = /*MATCHF*/{"crusader":{"sword":{"sword":0.24,"spear":0.53,"archer":0.53,"cavalry":0.14,"guard":0.54,"axe":-0.39,"xbow":0.45,"harcher":0.29,"hero":-0.5,"cannon":0.84},"spear":{"sword":-0.27,"spear":0.34,"archer":-0.31,"cavalry":0.92,"guard":0.43,"axe":-0.33,"xbow":0.26,"harcher":0.06,"hero":-0.19,"cannon":0.79},"archer":{"sword":-0.4,"spear":0.55,"archer":0.32,"cavalry":-0.84,"guard":-0.7,"axe":0.77,"xbow":0.13,"harcher":0.66,"hero":-0.21,"cannon":0.71},"cavalry":{"sword":0.43,"spear":-0.85,"archer":0.85,"cavalry":0.36,"guard":-0.26,"axe":0.56,"xbow":0.09,"harcher":0.87,"hero":0.07,"cannon":0.97},"guard":{"sword":0.07,"spear":0.28,"archer":0.82,"cavalry":0.67,"guard":0.43,"axe":-0.76,"xbow":0.19,"harcher":0.72,"hero":-0.42,"cannon":0.85},"axe":{"sword":0.54,"spear":0.45,"archer":-0.16,"cavalry":-0.28,"guard":0.83,"axe":0.11,"xbow":0.32,"harcher":-0.68,"hero":-0.45,"cannon":0.84},"xbow":{"sword":0.12,"spear":0.68,"archer":0.46,"cavalry":0.19,"guard":0.85,"axe":0.34,"xbow":0.17,"harcher":0.94,"hero":1,"cannon":0.82},"harcher":{"sword":0.32,"spear":0.31,"archer":-0.61,"cavalry":-0.83,"guard":-0.23,"axe":0.79,"xbow":-0.85,"harcher":0.22,"hero":0.78,"cannon":0.94},"hero":{"sword":0.14,"spear":-0.15,"archer":0.38,"cavalry":0,"guard":0.33,"axe":0.14,"xbow":-0.68,"harcher":0.43,"hero":0.13,"cannon":1}},"arab":{"sword":{"sword":0,"spear":0.42,"archer":0.44,"cavalry":-0.08,"guard":0.37,"axe":-0.46,"xbow":0.42,"harcher":0.08,"hero":-0.52,"cannon":0.78},"spear":{"sword":-0.37,"spear":0.03,"archer":-0.44,"cavalry":0.95,"guard":0.28,"axe":-0.36,"xbow":-0.09,"harcher":-0.22,"hero":-0.26,"cannon":0.74},"archer":{"sword":-0.41,"spear":0.5,"archer":0.07,"cavalry":-0.86,"guard":-0.72,"axe":0.73,"xbow":-0.06,"harcher":0.57,"hero":-0.3,"cannon":0.68},"cavalry":{"sword":0.57,"spear":-0.9,"archer":0.96,"cavalry":0.44,"guard":0.13,"axe":0.61,"xbow":0.34,"harcher":0.94,"hero":0.08,"cannon":0.97},"guard":{"sword":-0.4,"spear":-0.24,"archer":0.73,"cavalry":0.4,"guard":0.05,"axe":-0.81,"xbow":-0.46,"harcher":0.41,"hero":-0.59,"cannon":0.77},"axe":{"sword":0.46,"spear":0.33,"archer":-0.68,"cavalry":-0.36,"guard":0.79,"axe":-0.07,"xbow":0.18,"harcher":-0.65,"hero":-0.56,"cannon":0.82},"xbow":{"sword":0.12,"spear":0.09,"archer":-0.22,"cavalry":-0.75,"guard":0.85,"axe":-0.22,"xbow":-0.08,"harcher":0.42,"hero":-0.48,"cannon":0.65},"harcher":{"sword":0.74,"spear":0.98,"archer":-0.39,"cavalry":-0.64,"guard":0.29,"axe":1,"xbow":-0.73,"harcher":0.58,"hero":0.92,"cannon":0.96},"hero":{"sword":0.13,"spear":-0.57,"archer":0.43,"cavalry":0,"guard":-0.05,"axe":-0.18,"xbow":-0.79,"harcher":0.65,"hero":-0.3,"cannon":1}},"viking":{"sword":{"sword":0.31,"spear":0.5,"archer":0.44,"cavalry":0.12,"guard":0.55,"axe":-0.27,"xbow":0.4,"harcher":0.05,"hero":0.18,"cannon":0.78},"spear":{"sword":-0.31,"spear":0.24,"archer":-0.54,"cavalry":0.95,"guard":0.42,"axe":-0.26,"xbow":-0.04,"harcher":-0.37,"hero":0.33,"cannon":0.77},"archer":{"sword":-0.41,"spear":0.5,"archer":0.05,"cavalry":-0.85,"guard":-0.7,"axe":0.57,"xbow":-0.03,"harcher":0.62,"hero":-0.15,"cannon":0.61},"cavalry":{"sword":0.42,"spear":-0.93,"archer":0.81,"cavalry":0.22,"guard":-0.17,"axe":0.46,"xbow":-0.05,"harcher":0.84,"hero":0.19,"cannon":0.9},"guard":{"sword":0.26,"spear":0.36,"archer":0.8,"cavalry":0.67,"guard":0.52,"axe":-0.66,"xbow":-0.14,"harcher":0.67,"hero":0.23,"cannon":0.88},"axe":{"sword":0.63,"spear":0.61,"archer":-0.09,"cavalry":0,"guard":0.86,"axe":0.33,"xbow":0.4,"harcher":-0.64,"hero":0.1,"cannon":0.71},"xbow":{"sword":-0.41,"spear":0.1,"archer":0.03,"cavalry":0.13,"guard":0.53,"axe":-0.08,"xbow":0.04,"harcher":0.89,"hero":0.89,"cannon":0.81},"harcher":{"sword":-0.06,"spear":0.44,"archer":-0.61,"cavalry":-0.83,"guard":-0.4,"axe":0.76,"xbow":-0.9,"harcher":-0.1,"hero":-0.09,"cannon":0.95},"hero":{"sword":0.62,"spear":0.46,"archer":0.32,"cavalry":0.44,"guard":0.64,"axe":0.65,"xbow":-0.88,"harcher":-0.75,"hero":0.33,"cannon":0.98}},"samurai":{"sword":{"sword":0.24,"spear":0.43,"archer":-0.43,"cavalry":0.09,"guard":0.47,"axe":-0.4,"xbow":0.24,"harcher":-0.74,"hero":-0.51,"cannon":0.79},"spear":{"sword":-0.34,"spear":0.05,"archer":-0.61,"cavalry":0.94,"guard":0.32,"axe":-0.28,"xbow":-0.26,"harcher":-0.83,"hero":-0.26,"cannon":0.72},"archer":{"sword":-0.13,"spear":0.97,"archer":0.38,"cavalry":-0.74,"guard":-0.65,"axe":0.93,"xbow":0.13,"harcher":0.61,"hero":0.13,"cannon":0.75},"cavalry":{"sword":0.21,"spear":-0.94,"archer":0.8,"cavalry":-0.01,"guard":-0.34,"axe":0.28,"xbow":-0.45,"harcher":0.85,"hero":-0.31,"cannon":1},"guard":{"sword":-0.3,"spear":-0.19,"archer":0.72,"cavalry":0.49,"guard":0.2,"axe":-0.77,"xbow":-0.4,"harcher":0.39,"hero":-0.58,"cannon":0.81},"axe":{"sword":0.65,"spear":0.48,"archer":-0.74,"cavalry":0.1,"guard":0.89,"axe":0.54,"xbow":0.08,"harcher":-0.46,"hero":-0.52,"cannon":0.8},"xbow":{"sword":0.4,"spear":0.66,"archer":0.3,"cavalry":0.27,"guard":1,"axe":0.46,"xbow":0.24,"harcher":0.94,"hero":1,"cannon":0.79},"harcher":{"sword":0.37,"spear":0.89,"archer":-0.5,"cavalry":-0.78,"guard":-0.18,"axe":0.97,"xbow":-0.8,"harcher":0.37,"hero":0.88,"cannon":0.84},"hero":{"sword":-0.21,"spear":-0.46,"archer":0.34,"cavalry":-0.37,"guard":0.29,"axe":-0.29,"xbow":-0.71,"harcher":0.47,"hero":-0.39,"cannon":0.99}}}/*END*/;

const m = (a: string, b: string) => MATCH[a]?.[b] ?? 0;
/** how troop type t of faction f fares against enemy type e */
export const matchOf = (f: FactionId, t: string, e: string) => MATCH_F[f]?.[t]?.[e] ?? m(t, e);

const PRIORS = new Map<string, number>();
/** how a faction's troop type does against the field in general */
function priorOf(f: FactionId, t: string) {
  const key = f + ":" + t;
  let v = PRIORS.get(key);
  if (v === undefined) {
    v = 0;
    for (const b of SQUAD_TYPES) v += matchOf(f, t, b) / SQUAD_TYPES.length;
    PRIORS.set(key, v);
  }
  return v;
}

/** the unit that beats each type hardest for the same gold (the enemy commander uses this too) */
export const ANSWERS: Record<string, SquadType> = {};
for (const a of Object.keys(MATCH)) {
  let best: SquadType = "sword";
  for (const t of SQUAD_TYPES) if (m(t, a) > m(best, a)) best = t;
  ANSWERS[a] = best;
}

const MU = new Map<string, { strong: SquadType[]; weak: SquadType[] }>();
/** what a troop type clearly beats and what clearly beats it, strongest first */
export function matchup(f: FactionId, t: SquadType) {
  const key = f + ":" + t;
  let r = MU.get(key);
  if (!r) {
    const by = SQUAD_TYPES.filter((e) => e !== t).sort((a, b) => Math.abs(matchOf(f, t, b)) - Math.abs(matchOf(f, t, a)));
    r = { strong: by.filter((e) => matchOf(f, t, e) >= 0.2).slice(0, 3), weak: by.filter((e) => matchOf(f, t, e) <= -0.2).slice(0, 3) };
    MU.set(key, r);
  }
  return r;
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const FRONT: SquadType[] = ["sword", "spear", "guard", "axe"];
const SHOOT: SquadType[] = ["archer", "xbow"];
const DEFEND: SquadType[] = ["spear", "guard", "sword", "axe", "cavalry"];
/** what each troop type does, as the end of a sentence */
const CRAFT: Record<SquadType, string> = {
  sword: "menangkis lalu membalas tebasan",
  spear: "menghentikan serbuan kuda dengan pagar tombak",
  archer: "menghujani mereka sebelum sempat mendekat",
  cavalry: "menerjang dan melempar barisan mereka",
  guard: "menahan panah dan serbuan dengan tembok perisai",
  axe: "membelah perisai dan menyapu barisan",
  xbow: "tembakannya menembus perisai dan zirah",
  harcher: "menembak sambil berputar tanpa bisa ditangkap",
};
const lane = (y: number) => (y < 330 ? "atas" : y > 520 ? "bawah" : "tengah");
const verdict = (v: number) => (v >= 0.6 ? "menang telak atas" : v >= 0.3 ? "unggul atas" : "sedikit unggul atas");
const Y0 = FIELD_TOP + 108;
const Y1 = FIELD_BOTTOM - 112;

/** where a unit of this type fights best, and the formation to draw there */
function place(g: Game, t: SquadType, y: number, atGate: boolean, behind?: Squad) {
  const Z = ZONES[0];
  let cy = clamp(y, Y0, Y1);
  let cx: number;
  let where: string;
  if (atGate) {
    cx = Z.x0 + 55;
    where = "depan istana";
  } else if (t === "spear" || t === "guard") {
    cx = Z.x1 - 55; // the wall stands in front
    where = `paling depan, jalur ${lane(cy)}`;
  } else if (t === "sword" || t === "axe") {
    cx = Z.x1 - 115;
    where = `garis depan, jalur ${lane(cy)}`;
  } else if (t === "archer" || t === "xbow") {
    // shooters go right behind the line. Measured: placed far back they loose their first volley only
    // when the front line is already half gone; close behind it they shoot from the start.
    if (behind && behind.state === "ready") {
      cy = clamp(behind.cy, Y0, Y1);
      cx = behind.cx - 50;
    } else cx = Z.x1 - 140;
    where = "belakang garis depan, sedekat mungkin";
  } else if (t === "cavalry") {
    cy = clamp(cy + (cy > 420 ? -165 : 165), Y0, Y1); // hit them from the side
    cx = Z.x1 - 150;
    where = `sayap ${lane(cy)}, serang dari samping`;
  } else {
    cy = cy < 420 ? Y0 : Y1; // horse archers ride round the flank
    cx = Z.x1 - 200;
    where = `sayap ${lane(cy)}`;
  }
  // never stack on a formation that already stands there
  for (let k = 0; k < 4; k++) {
    let clash = false;
    for (const s of g.squads) if (s.team === 0 && !s.dead && s.state === "ready" && Math.abs(s.cx - cx) < 46 && Math.abs(s.cy - cy) < 150) clash = true;
    if (!clash) break;
    cx -= 52;
  }
  cx = clamp(cx, Z.x0 + 30, Z.x1 - 30);
  let path: Pt[];
  if (t === "cavalry" && !atGate) path = [{ x: cx - 42, y: cy - 82 }, { x: cx + 42, y: cy }, { x: cx - 42, y: cy + 82 }]; // riders: the shape makes no measurable difference, a wedge simply looks the part
  else if (t === "harcher") path = [{ x: cx - 60, y: cy - 26 }, { x: cx + 60, y: cy + 26 }];
  else if ((t === "archer" || t === "xbow") && !atGate) {
    path = []; // a gently curved wall: every archer comes into range at the same moment
    for (let i = 0; i <= 8; i++) {
      const a = -1 + (2 * i) / 8;
      path.push({ x: cx + Math.cos(a) * 40 - 40, y: cy + Math.sin(a) * 100 });
    }
  } else path = [{ x: cx, y: cy - 95 }, { x: cx, y: cy + 95 }]; // infantry: a wall across the advance. Measured: all 20 strike at once; a wedge or column loses far more men
  return { path, x: cx, y: cy, where };
}

/**
 * Every card rated for the battle as it stands. What can be deployed right now comes first,
 * best first; the first entry is the advisor's pick (or "wait" when nothing affordable is
 * worth buying).
 */
export function advise(g: Game): Advice[] {
  const f = g.fac[0];
  const ef = g.fac[1];
  const gold = g.gold[0];
  const Z = ZONES[0];
  const cost = (t: SquadType) => unitCost(t, f);
  const nm = (t: SquadType) => f.unitNames[t];
  const naft = (t: string) => f.id === "arab" && t === "xbow";
  const mm = (t: string, e: string) => matchOf(f.id, t, e);
  const prior = (t: string) => priorOf(f.id, t);
  const craft = (t: SquadType) => (naft(t) ? "membakar barisan rapat, perisai pun tak menolong" : CRAFT[t]);
  const foeName = (s: Squad) => (s.hero ? HERO_DEFS[s.hero].name : s.type === "cannon" ? "Meriam" : ef.unitNames[s.type as SquadType]);
  const val = (s: Squad) => (s.type === "hero" ? HERO_COST : s.type === "cannon" ? CANNON_DEF.cost : (UNIT_DEFS[s.type as SquadType].cost * s.alive) / 20);
  const own = g.squads.filter((s) => s.team === 0 && !s.dead && s.alive > 0);
  const foe = g.squads.filter((s) => s.team === 1 && !s.dead && s.alive > 0);

  // ---- how much of every enemy formation is still unanswered?
  const needs = foe.map((e) => {
    const v = val(e);
    let cover = 0;
    for (const s of own) {
      if (s.state !== "ready" && s.cx > e.cx + 60) continue; // already past it
      cover += val(s) * Math.max(0, mm(s.type, e.type) + 0.15) * (Math.abs(s.cy - e.cy) < 170 ? 1 : 0.45);
    }
    const close = 1 + Math.max(0, 1 - (e.cx - CASTLE[0].cx) / 1000) * (e.state === "ready" ? 0.2 : 0.8);
    return { e, need: v * close * clamp(1 - cover / (v * 0.9 + 1), 0.2, 1) };
  });
  let total = 0;
  for (const n of needs) total += n.need;
  const versus = (t: string) => {
    if (!total) return prior(t);
    let s = 0;
    for (const n of needs) s += n.need * mm(t, n.e.type);
    return (s / total) * 0.8 + prior(t) * 0.2;
  };
  /** the enemy formation where a unit of this type is needed most */
  const targetOf = (t: string) => {
    let best: Squad | undefined;
    let bv = 0;
    for (const n of needs) {
      const v = n.need * (mm(t, n.e.type) + 0.3);
      if (v > bv) {
        bv = v;
        best = n.e;
      }
    }
    return best;
  };
  /** the enemy formation that is most dangerous to a unit of this type */
  const baneOf = (t: string) => {
    let worst: Squad | undefined;
    let wv = 0;
    for (const n of needs) {
      const v = n.need * (0.1 - mm(t, n.e.type));
      if (v > wv) {
        wv = v;
        worst = n.e;
      }
    }
    return worst;
  };

  // ---- the shape of our own army
  const front = own.filter((s) => FRONT.includes(s.type as SquadType));
  const hasFront = front.length > 0;
  const hasShooter = own.some((s) => SHOOT.includes(s.type as SquadType));
  const hasRider = own.some((s) => s.type === "cavalry" || s.type === "harcher");
  /** the more of one type we already field, the less another one adds */
  const same = (t: string) => {
    let n = 0;
    for (const s of own) if (s.type === t) n += s.state === "ready" ? 0.1 : 0.04;
    return n;
  };
  let mine = 0;
  let theirs = 0;
  let pushing = false;
  for (const s of own) {
    mine += val(s);
    if (s.state !== "ready" && s.cx > 880) pushing = true;
  }
  for (const e of foe) theirs += val(e);
  const winning = mine > theirs * 1.2 + 60;
  /** the lane where our line is thinnest */
  const weakLane = () => {
    let weak = 420;
    let wv = Infinity;
    for (const ly of [420, 260, 580]) {
      let v = 0;
      for (const s of own) if (s.state === "ready" && Math.abs(s.cy - ly) < 90) v += val(s);
      for (const e of foe) if (Math.abs(e.cy - ly) < 90) v -= val(e) * 0.6;
      if (v < wv) {
        wv = v;
        weak = ly;
      }
    }
    return weak;
  };

  // ---- the enemy is at the gates: stop them right there
  let raid: Squad | null = null;
  for (const e of foe) if (e.state !== "ready" && e.cx < CASTLE[0].cx + 340 && (!raid || val(e) > val(raid))) raid = e;
  let gate: SquadType | null = null;
  if (raid) {
    const r = raid;
    gate = DEFEND.filter((t) => cost(t) <= gold).sort((a, b) => mm(b, r.type) - mm(a, r.type))[0] ?? null;
  }

  const tier = (s: number) => (s >= 0.28 ? 3 : s >= 0.08 ? 2 : s >= -0.12 ? 1 : 0);
  const out: Advice[] = [];

  // ---- the eight troop types
  for (const t of SQUAD_TYPES) {
    const c = cost(t);
    const shooter = SHOOT.includes(t);
    const rider = t === "cavalry" || t === "harcher";
    let s = versus(t) + (f.signature.includes(t) ? 0.06 : 0) - same(t);
    if (!hasFront) s += FRONT.includes(t) ? 0.25 : shooter ? -0.45 : -0.1;
    else if (shooter && !hasShooter) s += 0.06; // a line with archers behind it is worth more than the sum
    else if (rider && !hasRider) s += 0.03;
    const e = targetOf(t);
    const atGate = gate === t && raid !== null;
    if (atGate) s += 1;
    let behind: Squad | undefined;
    const wantY = atGate && raid ? raid.cy : e && mm(t, e.type) >= 0.1 ? e.cy : weakLane();
    for (const q of front) if (q.state === "ready" && (!behind || Math.abs(q.cy - wantY) < Math.abs(behind.cy - wantY))) behind = q;
    const p = place(g, t, wantY, atGate, behind);
    let title = `Pasang di ${p.where}`;
    let reason: string;
    let aim: Squad | undefined;
    let fit = tier(s);
    if (atGate && raid) {
      title = "Pertahankan istana!";
      reason = `${foeName(raid)} musuh sudah di depan istanamu! Hadang mereka dengan ${nm(t)}.`;
      aim = raid;
    } else if (shooter && !hasFront) {
      reason = `${nm(t)} butuh garis depan dulu: tanpa pelindung mereka cepat diserbu.`;
      fit = Math.min(fit, 1);
    } else if (e && mm(t, e.type) >= 0.1) {
      reason = `${foeName(e)} musuh ${e.state === "ready" ? "bersiap" : "maju"} di jalur ${lane(e.cy)}: ${nm(t)} ${verdict(mm(t, e.type))} mereka.`;
      aim = e;
    } else if (!foe.length) {
      reason = `Musuh belum terlihat. ${nm(t)} ${craft(t)}.`;
    } else {
      const b = baneOf(t);
      const prey = matchup(f.id, t).strong.map((x) => TYPE_NAME[x]);
      if (b && mm(t, b.type) <= -0.2) reason = `${foeName(b)} musuh unggul atas ${nm(t)}.${prey.length ? ` Simpan untuk melawan ${prey.slice(0, 2).join(" & ")}.` : ""}`;
      else reason = `${nm(t)} seimbang melawan pasukan musuh sekarang.`;
    }
    out.push({ key: t, kind: "squad", type: t, path: p.path, x: p.x, y: p.y, name: nm(t), role: TYPE_NAME[t], cost: c, title, reason, star: f.signature.includes(t), tx: aim?.cx, ty: aim?.cy, fit, score: s, ok: c <= gold, blocked: c <= gold ? undefined : `Butuh ${c} emas` });
  }

  // ---- heroes: strong behind a front line, vulnerable to massed shooters and pikes
  for (const h of f.heroes) {
    const d = HERO_DEFS[h];
    const cd = g.heroCd[h] ?? 0;
    const onField = own.some((q) => q.hero === h);
    const s = versus("hero") + (hasFront ? 0.1 : -0.2);
    const e = targetOf("hero");
    const b = baneOf("hero");
    const danger = b && mm("hero", b.type) <= -0.2 ? b : undefined;
    const hy = clamp((e ? e.cy : front.length ? front[0].cy : 420) + 34, FIELD_TOP + 60, FIELD_BOTTOM - 60);
    const reason = !hasFront ? "Panggil setelah ada garis depan, supaya ia tidak dikeroyok sendirian." : danger ? `Awas: ${foeName(danger)} musuh berbahaya bagi seorang hero.` : `${d.title}.`;
    const blocked = g.tut ? "Tidak dipakai di pelajaran ini" : onField ? "Sudah di medan" : cd > 0 ? `Siap ${Math.ceil(cd)} dtk lagi` : gold < HERO_COST ? `Butuh ${HERO_COST} emas` : undefined;
    out.push({ key: h, kind: "hero", hero: h, path: [], x: d.ranged ? Z.x0 + 150 : Z.x1 - 80, y: hy, name: d.name, role: "Hero", cost: HERO_COST, title: d.ranged ? "Panggil di belakang barisan" : "Panggil ke garis depan", reason, tx: e?.cx, ty: e?.cy, fit: tier(s), score: s, ok: !blocked, blocked });
  }

  // ---- the cannon: useless in a brawl, but its shot goes straight through castle walls
  {
    const n = g.cannonCount(0);
    const s = !hasFront ? -0.5 : (winning ? 0.12 : -0.14) + (pushing ? 0.1 : 0) + g.phase * 0.1;
    const reason = !hasFront ? "Meriam rapuh: butuh garis depan yang melindunginya dulu." : winning ? "Pasukanmu unggul: tembakan meriam menembus tembok istana, tak tertahan seperti pedang." : "Meriam kalah di pertempuran terbuka. Pasang saat pasukanmu sudah unggul.";
    const blocked = g.tut ? "Tidak dipakai di pelajaran ini" : n >= CANNON_DEF.max ? `Maks ${CANNON_DEF.max} meriam` : gold < CANNON_DEF.cost ? `Butuh ${CANNON_DEF.cost} emas` : undefined;
    out.push({ key: "cannon", kind: "cannon", path: [], x: Z.x1 - 190, y: [300, 540, 420][n % 3], name: CANNON_DEF.name, role: "Pengepung", cost: CANNON_DEF.cost, title: "Pasang di belakang garis depan", reason, fit: tier(s), score: s, ok: !blocked, blocked });
  }

  out.sort((a, b) => Number(b.ok) - Number(a.ok) || b.score - a.score);
  const top = out[0];
  let better: Advice | undefined;
  for (const a of out) if (!a.ok && a.fit >= 2 && a.cost > gold && (!better || a.score > better.score)) better = a;
  if (!top.ok || (top.fit === 0 && better)) {
    // nothing affordable is worth buying right now
    const horn = `terompet berikutnya (${Math.max(0, Math.ceil(g.phaseT))} detik lagi) memberi +${g.income()} emas`;
    out.unshift({
      key: "wait",
      kind: "wait",
      path: [],
      x: 0,
      y: 0,
      name: "",
      role: "",
      cost: 0,
      title: "Simpan emas dulu",
      reason: !top.ok ? `Emasmu belum cukup untuk apa pun: ${horn}.` : `Yang terjangkau sekarang kurang cocok. ${better!.name} jauh lebih baik: ${horn}.`,
      fit: 0,
      score: 0,
      ok: false,
    });
  }
  return out;
}
