/**
 * Faction heraldry and architecture: emblems, banners and the four castles.
 *   Crusader – stone keep with round towers and red spires
 *   Arab     – sandstone palace with a turquoise dome and two minarets
 *   Viking   – timber hall behind a palisade, dragon gables, snow on the roof
 *   Samurai  – white tenshu keep with tiered sweeping roofs on a stone base
 */
import { FACTIONS } from "./constants";
import type { FactionDef, FactionId } from "./constants";

type C = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
const INK = "#3b2a1a";
const GOLD = "#f2c14e";

function poly(c: C, p: number[], fill: string, stroke = true) {
  c.beginPath();
  c.moveTo(p[0], p[1]);
  for (let i = 2; i < p.length; i += 2) c.lineTo(p[i], p[i + 1]);
  c.closePath();
  c.fillStyle = fill;
  c.fill();
  if (stroke) c.stroke();
}
function box(c: C, x: number, y: number, w: number, h: number, fill: string) {
  c.fillStyle = fill;
  c.fillRect(x, y, w, h);
  c.strokeRect(x, y, w, h);
}
function shade(c: C, x: number, y: number, w: number, h: number, fill: string) {
  c.fillStyle = fill;
  c.fillRect(x, y, w, h);
}
function seg(c: C, x0: number, y0: number, x1: number, y1: number, col: string, w: number) {
  c.beginPath();
  c.moveTo(x0, y0);
  c.lineTo(x1, y1);
  c.strokeStyle = col;
  c.lineWidth = w;
  c.stroke();
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
}
function disc(c: C, x: number, y: number, r: number, fill: string, stroke = false) {
  c.beginPath();
  c.arc(x, y, r, 0, TAU);
  c.fillStyle = fill;
  c.fill();
  if (stroke) c.stroke();
}
function merlons(c: C, x0: number, x1: number, y: number, w: number, h: number, fill: string) {
  const n = Math.max(2, Math.round((x1 - x0) / (w * 1.9)));
  const gap = (x1 - x0 - w) / (n - 1);
  for (let i = 0; i < n; i++) box(c, x0 + i * gap, y - h, w, h, fill);
}

/* ------------------------------------------------------------------ */
/*  emblems                                                           */
/* ------------------------------------------------------------------ */
/** the faction's sign, about 2*s wide, centred on (x, y) */
export function drawEmblem(c: C, f: FactionId, x: number, y: number, s: number, col: string) {
  c.fillStyle = col;
  if (f === "crusader") {
    // cross pattée
    c.fillRect(x - 0.17 * s, y - s, 0.34 * s, 2 * s);
    c.fillRect(x - s, y - 0.17 * s, 2 * s, 0.34 * s);
    c.fillRect(x - 0.4 * s, y - s, 0.8 * s, 0.24 * s);
    c.fillRect(x - 0.4 * s, y + 0.76 * s, 0.8 * s, 0.24 * s);
    c.fillRect(x - s, y - 0.4 * s, 0.24 * s, 0.8 * s);
    c.fillRect(x + 0.76 * s, y - 0.4 * s, 0.24 * s, 0.8 * s);
  } else if (f === "arab") {
    // crescent and star
    c.beginPath();
    c.arc(x - 0.12 * s, y, 0.92 * s, 0, TAU);
    c.arc(x + 0.2 * s, y, 0.74 * s, 0, TAU);
    c.fill("evenodd");
    c.beginPath();
    for (let i = 0; i < 10; i++) {
      const r = (i % 2 ? 0.14 : 0.34) * s;
      const a = (i / 10) * TAU - Math.PI / 2;
      c.lineTo(x + 0.5 * s + Math.cos(a) * r, y + Math.sin(a) * r);
    }
    c.fill();
  } else if (f === "viking") {
    // the raven
    c.beginPath();
    c.ellipse(x, y + 0.12 * s, 0.58 * s, 0.3 * s, -0.3, 0, TAU);
    c.fill();
    disc(c, x + 0.5 * s, y - 0.26 * s, 0.24 * s, col);
    poly(c, [x + 0.66 * s, y - 0.36 * s, x + 1.02 * s, y - 0.2 * s, x + 0.66 * s, y - 0.12 * s], col, false);
    poly(c, [x - 0.1 * s, y - 0.02 * s, x - 0.56 * s, y - 0.98 * s, x + 0.3 * s, y - 0.2 * s], col, false);
    poly(c, [x - 0.4 * s, y + 0.2 * s, x - 1.02 * s, y + 0.5 * s, x - 0.46 * s, y + 0.5 * s], col, false);
    c.fillRect(x - 0.06 * s, y + 0.36 * s, 0.1 * s, 0.4 * s);
    c.fillRect(x + 0.18 * s, y + 0.32 * s, 0.1 * s, 0.4 * s);
  } else {
    // Takeda-bishi: four diamonds
    const d = 0.44 * s;
    for (const [dx, dy] of [[0, -0.5], [-0.5, 0], [0.5, 0], [0, 0.5]]) {
      const cx = x + dx * s;
      const cy = y + dy * s;
      poly(c, [cx, cy - d, cx + d, cy, cx, cy + d, cx - d, cy], col, false);
    }
  }
}

/* ------------------------------------------------------------------ */
/*  banners                                                           */
/* ------------------------------------------------------------------ */
/** a standard on a pole planted at (x, y); every faction flies its own shape */
export function drawBanner(c: C, f: FactionDef, x: number, y: number, t: number, scale: number, fall: number, alpha: number, seed: number) {
  c.save();
  c.globalAlpha = alpha;
  c.translate(x, y);
  c.rotate(fall * 1.35);
  c.scale(scale, scale);
  c.lineJoin = "round";
  c.strokeStyle = INK;
  c.lineWidth = 1.1;
  const w1 = Math.sin(t * 5 + seed) * 1.3;
  const w2 = Math.sin(t * 5 + seed + 1.3) * 1.3;
  c.fillStyle = "rgba(24,60,24,0.25)";
  c.beginPath();
  c.ellipse(1, 0, 4, 1.5, 0, 0, TAU);
  c.fill();
  seg(c, 0, 0, 0, -35, "#4a3526", 1.7);
  c.lineWidth = 1.1;
  if (f.id === "crusader") {
    poly(c, [0, -34, 16, -34 + w1, 11.5, -28.5 + w2, 16, -23 + w1, 0, -23], "#f8f4ea");
    shade(c, 4.4, -33.6 + w1 * 0.3, 2.2, 10.2, f.main);
    shade(c, 0.8, -29.6 + w1 * 0.3, 10.4, 2.2, f.main);
    disc(c, 0, -35.5, 1.4, GOLD, true);
  } else if (f.id === "arab") {
    poly(c, [0, -35, 17, -29 + w1, 0, -22], f.main);
    seg(c, 0.6, -22.6, 16.4, -29 + w1, GOLD, 0.9);
    c.lineWidth = 1.1;
    drawEmblem(c, "arab", 5, -28.6 + w1 * 0.25, 2.6, GOLD);
    drawEmblem(c, "arab", 0, -38.5, 2, GOLD);
  } else if (f.id === "viking") {
    c.beginPath();
    c.moveTo(0, -35);
    c.lineTo(14, -35 + w1);
    c.quadraticCurveTo(14 + w2 * 0.4, -24, 0, -21);
    c.closePath();
    c.fillStyle = "#f3e6c2";
    c.fill();
    c.strokeStyle = f.main;
    c.lineWidth = 1.6;
    c.stroke();
    c.strokeStyle = INK;
    c.lineWidth = 1.1;
    for (let i = 0; i < 3; i++) seg(c, 11.5 - i * 4, -24.6 + i * 1.3, 12.5 - i * 4, -21.2 + i * 1.3, f.main, 1);
    c.lineWidth = 1.1;
    drawEmblem(c, "viking", 5.4, -29 + w1 * 0.3, 3.3, "#2b1e15");
    poly(c, [-1.3, -35, 0, -39, 1.3, -35], "#dfe5ec");
  } else {
    // nobori: a tall vertical banner hung from a cross-bar
    seg(c, 0, -34.5, 7.6, -34.5, "#4a3526", 1.2);
    c.lineWidth = 1.1;
    poly(c, [0.8, -34, 7.2, -34, 7.2 + w1 * 0.5, -24, 7.2 + w2 * 0.5, -14, 0.8, -14], f.main);
    drawEmblem(c, "samurai", 4 + w1 * 0.2, -28.6, 2.3, "#ffffff");
    drawEmblem(c, "samurai", 4 + w2 * 0.2, -20.4, 2.3, "#ffffff");
    disc(c, 0, -35.6, 1.3, GOLD, true);
  }
  c.restore();
}

/* ------------------------------------------------------------------ */
/*  castles (drawn around the origin: base centre at 0,0, facing right) */
/* ------------------------------------------------------------------ */
/** Krak des Chevaliers: concentric walls on a sloped talus, round towers, a square donjon */
function crusader(c: C, f: FactionDef) {
  const st = "#e4decd";
  const sd = "#c6beaa";
  const sdd = "#9b927d";
  const slit = (x: number, y: number, h: number) => {
    shade(c, x - 1.5, y, 3, h, INK);
    shade(c, x - 4.5, y + h * 0.3, 9, 2.8, INK);
  };
  // inner ward: two tall round towers under red spires
  for (const s of [-1, 1]) {
    const x = s * 54;
    box(c, x - 15, -140, 30, 100, st);
    shade(c, x + 4, -139, 10, 98, sd);
    for (let i = 0; i < 5; i++) shade(c, x - 17 + i * 7.6, -146, 3.6, 6, sdd); // machicolation corbels
    box(c, x - 18, -153, 36, 8, st);
    merlons(c, x - 18, x + 18, -153, 6, 7, st);
    poly(c, [x - 13, -160, x, -190, x + 13, -160], f.main);
    poly(c, [x, -190, x + 13, -160, x + 4, -160], f.dark, false);
    slit(x, -128, 14);
    slit(x, -98, 12);
  }
  // the donjon
  box(c, -28, -170, 56, 120, st);
  shade(c, 12, -169, 15, 118, sd);
  for (let i = 0; i < 8; i++) shade(c, -31 + i * 8.3, -176, 3.8, 6, sdd);
  box(c, -32, -184, 64, 8, st);
  merlons(c, -32, 32, -184, 7.5, 8.5, st);
  for (const wx of [-18, 11]) {
    // pointed gothic windows
    c.beginPath();
    c.moveTo(wx, -130);
    c.lineTo(wx, -146);
    c.quadraticCurveTo(wx, -152, wx + 3.5, -156);
    c.quadraticCurveTo(wx + 7, -152, wx + 7, -146);
    c.lineTo(wx + 7, -130);
    c.closePath();
    c.fillStyle = INK;
    c.fill();
  }
  // outer ward: curtain wall standing on a sloped talus
  box(c, -74, -82, 148, 46, st);
  shade(c, -73, -52, 146, 15, sd);
  merlons(c, -74, 74, -82, 7.5, 8.5, st);
  poly(c, [-80, 0, -72, -40, 72, -40, 80, 0], sd);
  seg(c, -75, -26, 75, -26, sdd, 1);
  seg(c, -78, -12, 78, -12, sdd, 1);
  for (let x = -66; x < 70; x += 17) {
    seg(c, x, -40, x - 1, -26, sdd, 1);
    seg(c, x + 8, -26, x + 7, -12, sdd, 1);
    seg(c, x, -12, x - 1, 0, sdd, 1);
  }
  for (const s of [-1, 1]) {
    // round corner towers with a flared base and the order's banner
    const x = s * 88;
    box(c, x - 13, -104, 26, 72, st);
    shade(c, x + 3, -103, 9, 70, sd);
    poly(c, [x - 17, 0, x - 13, -34, x + 13, -34, x + 17, 0], sd);
    box(c, x - 16, -112, 32, 8, st);
    merlons(c, x - 16, x + 16, -112, 6, 7, st);
    slit(x, -96, 12);
    poly(c, [x - 5, -78, x + 5, -78, x + 5, -54, x, -48, x - 5, -54], f.main);
    shade(c, x - 1, -75, 2, 19, "#f8f4ea");
    shade(c, x - 3.6, -70, 7.2, 2, "#f8f4ea");
  }
  // gatehouse with a pointed arch and portcullis
  box(c, -24, -100, 48, 100, st);
  shade(c, 10, -99, 13, 98, sd);
  for (let i = 0; i < 6; i++) shade(c, -26 + i * 9, -106, 3.8, 6, sdd);
  box(c, -27, -114, 54, 8, st);
  merlons(c, -27, 27, -114, 7, 8, st);
  // the order's shield over the gate
  c.beginPath();
  c.moveTo(-10, -92);
  c.lineTo(10, -92);
  c.lineTo(10, -77);
  c.quadraticCurveTo(8, -68, 0, -63);
  c.quadraticCurveTo(-8, -68, -10, -77);
  c.closePath();
  c.fillStyle = "#f8f4ea";
  c.fill();
  c.stroke();
  shade(c, -2.2, -90.5, 4.4, 25, f.main);
  shade(c, -8.6, -84, 17.2, 4.4, f.main);
  c.beginPath();
  c.moveTo(-14, 0);
  c.lineTo(-14, -28);
  c.quadraticCurveTo(-13, -42, 0, -50);
  c.quadraticCurveTo(13, -42, 14, -28);
  c.lineTo(14, 0);
  c.closePath();
  c.fillStyle = "#33241a";
  c.fill();
  c.stroke();
  for (const x of [-9, -4.5, 0, 4.5, 9]) seg(c, x, Math.abs(x) > 6 ? -38 : -46, x, 0, "#8a7860", 1.5);
  seg(c, -14, -13, 14, -13, "#8a7860", 1.5);
  seg(c, -14, -27, 14, -27, "#8a7860", 1.5);
}

/** an Ayyubid citadel: striped ablaq masonry, a monumental gate, ribbed dome and minarets */
function arab(c: C, f: FactionDef) {
  const sa = "#f3dfae";
  const sb = "#e0c182";
  const sd = "#d3b678";
  const tile = "#2bb7ad";
  const tileD = "#1c8f88";
  const palm = (px: number, lean: number) => {
    c.beginPath();
    c.moveTo(px, 0);
    c.quadraticCurveTo(px - lean * 4, -44, px + lean * 6, -84);
    c.strokeStyle = INK;
    c.lineWidth = 7.5;
    c.stroke();
    c.strokeStyle = "#a9773f";
    c.lineWidth = 5;
    c.stroke();
    c.strokeStyle = INK;
    c.lineWidth = 1.3;
    const tx = px + lean * 6;
    for (let i = 0; i < 7; i++) {
      const a = -Math.PI + (i / 6) * Math.PI;
      c.beginPath();
      c.moveTo(tx, -84);
      c.quadraticCurveTo(tx + Math.cos(a) * 16, -98 + Math.sin(a) * 10, tx + Math.cos(a) * 30, -70 + Math.sin(a) * 16);
      c.quadraticCurveTo(tx + Math.cos(a) * 14, -88 + Math.sin(a) * 6, tx, -84);
      c.fillStyle = i % 2 ? "#3fae5a" : "#58c46c";
      c.fill();
      c.stroke();
    }
  };
  palm(-106, 1);
  for (const s of [-1, 1]) {
    // minarets with a muezzin's balcony
    const x = s * 76;
    box(c, x - 7.5, -138, 15, 138, sa);
    for (let y = -126; y < -8; y += 17) shade(c, x - 6.9, y, 13.8, 5, sb);
    shade(c, x + 2.6, -137, 4.3, 136, "rgba(150,110,50,0.22)");
    poly(c, [x - 8, -138, x - 12, -144, x + 12, -144, x + 8, -138], sd);
    box(c, x - 12.5, -150, 25, 6, sa);
    for (let i = -2; i <= 2; i++) shade(c, x + i * 5 - 0.8, -149, 1.6, 4, INK);
    box(c, x - 5.5, -170, 11, 20, sa);
    c.beginPath();
    c.moveTo(x - 2.2, -154);
    c.lineTo(x - 2.2, -161);
    c.arc(x, -161, 2.2, Math.PI, 0);
    c.lineTo(x + 2.2, -154);
    c.closePath();
    c.fillStyle = INK;
    c.fill();
    c.beginPath();
    c.moveTo(x - 7, -170);
    c.bezierCurveTo(x - 10, -181, x - 2, -183, x, -193);
    c.bezierCurveTo(x + 2, -183, x + 10, -181, x + 7, -170);
    c.closePath();
    c.fillStyle = tile;
    c.fill();
    c.stroke();
    seg(c, x, -193, x, -200, GOLD, 2);
  }
  // curtain wall: two-coloured ablaq courses and stepped merlons
  box(c, -64, -66, 128, 66, sa);
  for (let y = -57; y < -4; y += 17) shade(c, -63.4, y, 126.8, 8.5, sb);
  for (let x = -64; x < 58; x += 12.8) poly(c, [x, -66, x, -72, x + 3, -72, x + 3, -77, x + 7.6, -77, x + 7.6, -72, x + 10.6, -72, x + 10.6, -66], sa);
  for (const s of [-1, 1]) {
    // arched windows with wooden lattice
    const wx = s * 45;
    c.beginPath();
    c.moveTo(wx - 7, -14);
    c.lineTo(wx - 7, -34);
    c.arc(wx, -34, 7, Math.PI, 0);
    c.lineTo(wx + 7, -14);
    c.closePath();
    c.fillStyle = "#4a3320";
    c.fill();
    c.stroke();
    for (const dx of [-3.5, 0, 3.5]) seg(c, wx + dx, -39, wx + dx, -14.6, "#c9a45a", 0.8);
    for (const dy of [-20, -27, -34]) seg(c, wx - 6.4, dy, wx + 6.4, dy, "#c9a45a", 0.8);
  }
  // drum and ribbed dome
  box(c, -34, -104, 68, 38, sa);
  shade(c, 15, -103, 18, 36, sd);
  for (const wx of [-24, -5, 14]) {
    c.beginPath();
    c.moveTo(wx, -78);
    c.lineTo(wx, -89);
    c.arc(wx + 5, -89, 5, Math.PI, 0);
    c.lineTo(wx + 10, -78);
    c.closePath();
    c.fillStyle = "#3d2a1c";
    c.fill();
    c.stroke();
  }
  box(c, -36, -109, 72, 6, GOLD);
  c.beginPath();
  c.moveTo(-36, -109);
  c.bezierCurveTo(-56, -139, -22, -161, 0, -181);
  c.bezierCurveTo(22, -161, 56, -139, 36, -109);
  c.closePath();
  c.fillStyle = tile;
  c.fill();
  c.stroke();
  for (const k of [-0.6, 0, 0.6]) {
    c.beginPath();
    c.moveTo(k * 36, -110);
    c.quadraticCurveTo(k * 52, -146, 0, -180);
    c.strokeStyle = tileD;
    c.lineWidth = 1.3;
    c.stroke();
  }
  c.beginPath();
  c.moveTo(-26, -118);
  c.bezierCurveTo(-36, -137, -17, -155, -7, -166);
  c.strokeStyle = "#8eeee4";
  c.lineWidth = 3;
  c.stroke();
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
  seg(c, 0, -181, 0, -193, GOLD, 2.6);
  disc(c, 0, -186, 2.6, GOLD, true);
  drawEmblem(c, "arab", 0, -200, 6.5, GOLD);
  // the monumental gate
  box(c, -27, -90, 54, 90, sa);
  for (let y = -66; y < -4; y += 17) shade(c, -26.4, y, 52.8, 8.5, sb);
  shade(c, -26.4, -89.4, 52.8, 7, tile);
  for (let x = -22; x < 22; x += 9) poly(c, [x, -86, x + 2.4, -88.4, x + 4.8, -86, x + 2.4, -83.6], GOLD, false);
  box(c, -17, -78, 34, 13, f.main); // inscription panel
  c.beginPath();
  c.moveTo(-13, -70);
  c.bezierCurveTo(-9, -77, -5, -65, -1, -72);
  c.bezierCurveTo(3, -78, 7, -66, 13, -73);
  c.strokeStyle = GOLD;
  c.lineWidth = 1.6;
  c.stroke();
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
  for (let i = 0; i < 9; i++) {
    // striped arch stones
    const a0 = Math.PI + (i * Math.PI) / 9;
    const a1 = a0 + Math.PI / 9;
    c.beginPath();
    c.arc(0, -28, 22, a0, a1);
    c.arc(0, -28, 14, a1, a0, true);
    c.closePath();
    c.fillStyle = i % 2 ? "#f8f4ea" : "#c8503c";
    c.fill();
    c.stroke();
  }
  box(c, -22, -28, 8, 28, sa);
  box(c, 14, -28, 8, 28, sa);
  c.beginPath();
  c.moveTo(-14, 0);
  c.lineTo(-14, -28);
  c.arc(0, -28, 14, Math.PI, 0);
  c.lineTo(14, 0);
  c.closePath();
  c.fillStyle = "#6b4426";
  c.fill();
  c.stroke();
  seg(c, 0, -42, 0, 0, INK, 1.2);
  for (const [dx, dy] of [[-7, -10], [7, -10], [-7, -24], [7, -24]]) disc(c, dx, dy, 1.3, GOLD);
}

/** a jarl's great hall behind a palisade: dragon gables, turf-roofed hut, watch tower */
function viking(c: C, f: FactionDef) {
  const lg = "#b07d45";
  const ld = "#8a5e33";
  const ldd = "#5f3f22";
  const roof = "#7a5430";
  const roofD = "#5a3c22";
  const snow = "#f6fafc";
  const cream = "#f3e6c2";
  const shield = (x: number, y: number, r: number, a: string, b: string) => {
    disc(c, x, y, r, a, true);
    c.beginPath();
    c.arc(x, y, r, -Math.PI / 2, Math.PI / 2);
    c.closePath();
    c.fillStyle = b;
    c.fill();
    c.stroke();
    disc(c, x, y, r * 0.3, "#9da6b0", true);
  };
  // turf-roofed hut with a smoke hole
  poly(c, [-112, -40, -90, -78, -66, -40], "#6fae4e");
  poly(c, [-97, -66, -90, -78, -83, -66], "#8fd06a");
  shade(c, -92.5, -82, 5, 5, ldd);
  // watch tower
  seg(c, 60, 0, 62, -94, INK, 6);
  seg(c, 86, 0, 84, -94, INK, 6);
  seg(c, 60, 0, 62, -94, ld, 3.6);
  seg(c, 86, 0, 84, -94, ld, 3.6);
  seg(c, 61, -30, 85, -62, ld, 2.4);
  seg(c, 85, -30, 61, -62, ld, 2.4);
  box(c, 53, -108, 40, 15, lg);
  seg(c, 58, -108, 58, -122, ldd, 3);
  seg(c, 88, -108, 88, -122, ldd, 3);
  poly(c, [47, -120, 73, -152, 99, -120], roof);
  poly(c, [63, -140, 73, -152, 83, -140, 78, -137, 73, -143, 68, -137], snow);
  shield(73, -100, 6.5, f.main, cream);
  // the great hall
  poly(c, [-68, -46, 0, -154, 68, -46], roof);
  for (let y = -60; y > -140; y -= 15) {
    const hw = (68 * (y + 154)) / 108;
    seg(c, -hw + 4, y, hw - 4, y, roofD, 1.3);
  }
  poly(c, [-41, -46, 0, -113, 41, -46], "#c79b63");
  for (let x = -32; x <= 32; x += 8) seg(c, x, -46, x, -46 - (41 - Math.abs(x)) * 1.55, ld, 1);
  // carved knot-work over the door
  disc(c, 0, -82, 8, "#33241a", true);
  seg(c, -8, -82, 8, -82, lg, 1.6);
  seg(c, 0, -90, 0, -74, lg, 1.6);
  c.beginPath();
  c.arc(0, -82, 4, 0, TAU);
  c.strokeStyle = GOLD;
  c.lineWidth = 1.2;
  c.stroke();
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
  // crossed barge boards ending in dragon heads
  for (const s of [-1, 1]) {
    seg(c, s * 72, -42, s * -7, -162, INK, 7.5);
    seg(c, s * 72, -42, s * -7, -162, lg, 5);
    poly(c, [s * -7, -162, s * -13, -173, s * -9, -180, s * -18, -176, s * -17, -166], lg);
    disc(c, s * -13.5, -174, 1, INK);
  }
  poly(c, [-17, -128, 0, -154, 17, -128, 10, -123, 0, -136, -10, -123], snow);
  // palisade with hung shields
  for (let i = 0, x = -88; x < 50; x += 9, i++) {
    const top = -44 - (i % 2) * 4;
    poly(c, [x, 0, x, top, x + 4.5, top - 8, x + 9, top, x + 9, 0], i % 2 ? lg : ld);
  }
  seg(c, -88, -30, 50, -30, ldd, 2.2);
  seg(c, -88, -9, 50, -9, ldd, 2.2);
  shield(-72, -22, 7.5, f.main, cream);
  shield(-52, -22, 7.5, cream, f.main);
  shield(-33, -22, 7.5, "#c8503c", cream);
  shield(38, -22, 7.5, f.main, cream);
  // gate between carved posts
  box(c, -15, -46, 30, 46, "#6b4a2c");
  seg(c, 0, -46, 0, 0, INK, 1.2);
  seg(c, -15, -32, 15, -32, "#3d4046", 2.2);
  seg(c, -15, -12, 15, -12, "#3d4046", 2.2);
  box(c, -24, -62, 8, 62, lg);
  box(c, 16, -62, 8, 62, lg);
  box(c, -27, -57, 54, 8, lg);
  for (const s of [-1, 1]) poly(c, [s * 20, -62, s * 17, -72, s * 22, -78, s * 29, -74, s * 26, -66, s * 24, -62], lg);
  // a rune stone by the gate
  poly(c, [100, 0, 101, -18, 106, -24, 111, -18, 112, 0], "#a3a8ad");
  seg(c, 104, -16, 108, -11, "#c0392b", 1.4);
  seg(c, 108, -16, 104, -6, "#c0392b", 1.4);
}

/** a tenshu like Himeji: white plaster, sweeping tiled roofs, a curved stone base */
function samurai(c: C, f: FactionDef) {
  const stn = "#b9b7ae";
  const stD = "#8f8d86";
  const wall = "#f9f6ee";
  const wallD = "#ddd8ca";
  const rf = "#3b5a66";
  const rfD = "#263d47";
  const wd = "#4a3526";
  /** a tiled roof whose eaves sweep up at the corners */
  const roof = (y: number, hw: number, rw: number, rh: number) => {
    c.beginPath();
    c.moveTo(-rw - 11, y - 7);
    c.quadraticCurveTo(-rw, y + 3, -rw + 12, y + 3);
    c.lineTo(rw - 12, y + 3);
    c.quadraticCurveTo(rw, y + 3, rw + 11, y - 7);
    c.quadraticCurveTo(rw - 4, y - rh * 0.5, hw * 0.72, y - rh);
    c.lineTo(-hw * 0.72, y - rh);
    c.quadraticCurveTo(-rw + 4, y - rh * 0.5, -rw - 11, y - 7);
    c.closePath();
    c.fillStyle = rf;
    c.fill();
    c.stroke();
    for (let i = -3; i <= 3; i++) seg(c, i * hw * 0.2, y - rh + 1.5, i * rw * 0.3, y + 2, rfD, 1);
    seg(c, -rw + 10, y + 3, rw - 10, y + 3, GOLD, 1.4);
  };
  const storey = (y0: number, hw: number, h: number) => {
    box(c, -hw, y0 - h, hw * 2, h, wall);
    shade(c, hw * 0.45, y0 - h + 1, hw * 0.55 - 1, h - 2, wallD);
    shade(c, -hw + 0.6, y0 - 6, hw * 2 - 1.2, 5.4, wd);
    for (let x = -hw + 7; x < hw - 8; x += 12) shade(c, x, y0 - h + 7, 5, 7, INK);
  };
  // a pine beside the keep
  seg(c, 106, 0, 99, -36, INK, 5.5);
  seg(c, 106, 0, 99, -36, "#7a5230", 3.4);
  for (const [px, py, pr] of [[93, -38, 13], [108, -47, 11], [98, -58, 9]]) {
    c.beginPath();
    c.ellipse(px, py, pr, pr * 0.5, 0, 0, TAU);
    c.fillStyle = "#3f8f5a";
    c.fill();
    c.stroke();
  }
  // stone base with the classic concave sweep
  c.beginPath();
  c.moveTo(-90, 0);
  c.quadraticCurveTo(-76, -28, -69, -60);
  c.lineTo(69, -60);
  c.quadraticCurveTo(76, -28, 90, 0);
  c.closePath();
  c.fillStyle = stn;
  c.fill();
  c.stroke();
  for (const y of [-14, -29, -44]) {
    const hw = 70 + (60 + y) * 0.3;
    seg(c, -hw + 2, y, hw - 2, y, stD, 1.1);
    for (let x = -hw + 12 + (((y * 7) % 9) + 9) % 9; x < hw - 8; x += 19) seg(c, x, y, x + 3, y + 14, stD, 1.1);
  }
  // low wings with loopholes on either side of the keep
  for (const s of [-1, 1]) {
    box(c, s > 0 ? 54 : -68, -78, 14, 18, wall);
    disc(c, s * 61, -68, 1.7, INK);
    poly(c, [s * 52, -78, s * 54, -84, s * 70, -84, s * 74, -77], rf);
  }
  storey(-60, 56, 26);
  roof(-86, 56, 68, 13);
  poly(c, [-18, -85, 0, -109, 18, -85], rf); // chidori-hafu gable
  poly(c, [-11, -86, 0, -101, 11, -86], wall);
  disc(c, 0, -91, 2.2, GOLD, true);
  storey(-97, 40, 24);
  roof(-121, 40, 52, 12);
  box(c, -25, -153, 50, 20, wall);
  shade(c, 11, -152, 13, 18, wallD);
  shade(c, -24.4, -139, 48.8, 5.4, wd);
  for (let x = -18; x < 16; x += 12) shade(c, x, -148, 5, 6, INK);
  roof(-153, 20, 38, 30);
  poly(c, [-9, -160, 0, -174, 9, -160], wall);
  seg(c, -14, -183, 14, -183, rfD, 3);
  // golden shachi on the ridge
  for (const s of [-1, 1]) poly(c, [s * 14, -183, s * 19, -192, s * 13, -188, s * 11, -194, s * 8, -184], GOLD);
  // gate
  box(c, -16, -36, 32, 36, wd);
  seg(c, 0, -36, 0, 0, INK, 1.2);
  for (const [dx, dy] of [[-8, -10], [8, -10], [-8, -24], [8, -24]]) disc(c, dx, dy, 1.3, GOLD);
  poly(c, [-27, -43, -22, -36, 22, -36, 27, -43, 15, -49, -15, -49], rf);
  seg(c, -22, -36, 22, -36, GOLD, 1.2);
  drawEmblem(c, "samurai", 0, -70, 5.5, f.main);
}

const ART: Record<FactionId, (c: C, f: FactionDef) => void> = { crusader, arab, viking, samurai };
/** castle-local positions of the live banners: [x, y, scale] */
export const CASTLE_FLAGS: Record<FactionId, [number, number, number][]> = {
  crusader: [[0, -184, 1.05], [-54, -190, 0.8], [54, -190, 0.8]],
  arab: [[-76, -199, 0.8], [76, -199, 0.8]],
  viking: [[0, -158, 1], [73, -152, 0.8]],
  samurai: [[-104, 0, 1.05], [-88, -4, 0.85]],
};
const RUBBLE: Record<FactionId, [string, string]> = {
  crusader: ["#cfc8b8", "#a39c8a"],
  arab: ["#ecd6a4", "#c9ad74"],
  viking: ["#a8763f", "#7a5430"],
  samurai: ["#eeeade", "#8f8d86"],
};

export const CASTLE_BOX = { ox: 126, oy: 212, w: 252, h: 222 };

export function drawCastleArt(c: C, f: FactionDef) {
  c.lineJoin = "round";
  c.lineCap = "round";
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
  c.fillStyle = "rgba(24,60,24,0.3)";
  c.beginPath();
  c.ellipse(4, 3, 104, 15, 0, 0, TAU);
  c.fill();
  ART[f.id](c, f);
}

export function drawRuins(c: C, f: FactionDef) {
  const [a, b] = RUBBLE[f.id];
  c.lineJoin = "round";
  c.strokeStyle = INK;
  c.lineWidth = 1.3;
  c.fillStyle = "rgba(24,60,24,0.3)";
  c.beginPath();
  c.ellipse(2, 3, 100, 15, 0, 0, TAU);
  c.fill();
  poly(c, [-84, 0, -78, -40, -64, -30, -56, -48, -44, -22, -40, 0], a);
  poly(c, [44, 0, 48, -44, 60, -32, 66, -52, 80, -26, 82, 0], a);
  poly(c, [-36, 0, -30, -24, -12, -34, 0, -14, 14, -28, 28, -12, 34, 0], b);
  poly(c, [-18, -3, 6, -18, 26, -3], f.dark);
  for (let i = 0; i < 14; i++) {
    const x = -80 + i * 12.3 + ((i * 37) % 7);
    poly(c, [x, 2, x + 3, -5 - ((i * 13) % 6), x + 9, -3, x + 10, 2], i % 2 ? a : b);
  }
}

const sprites = new Map<string, HTMLCanvasElement>();
/** the castle as a bitmap (white = a blank silhouette for the hit flash) */
export function castleSprite(id: FactionId, res: number, white = false): HTMLCanvasElement {
  const r = Math.max(1, Math.min(2.5, Math.ceil(res * 4) / 4));
  const key = id + r + (white ? "w" : "");
  let cv = sprites.get(key);
  if (!cv) {
    cv = document.createElement("canvas");
    cv.width = Math.ceil(CASTLE_BOX.w * r);
    cv.height = Math.ceil(CASTLE_BOX.h * r);
    const c = cv.getContext("2d")!;
    c.setTransform(r, 0, 0, r, CASTLE_BOX.ox * r, CASTLE_BOX.oy * r);
    drawCastleArt(c, FACTIONS[id]);
    if (white) {
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.globalCompositeOperation = "source-in";
      c.fillStyle = "#ffffff";
      c.fillRect(0, 0, cv.width, cv.height);
    }
    if (sprites.size > 12) sprites.clear();
    sprites.set(key, cv);
  }
  return cv;
}
