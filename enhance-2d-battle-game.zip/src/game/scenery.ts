/**
 * Scenery: a bright midday in a blossom valley.
 * Blue sky and a high sun, snow-capped mountains, a turquoise lake behind the field,
 * a flower meadow with cherry trees, a cobbled road between the two castles.
 * The static part is baked once into two canvases; the living part (clouds, windmill,
 * sparkling water, butterflies, wind in the grass) is drawn every frame.
 */
import { CASTLE, FACTIONS, FIELD_BOTTOM, FIELD_TOP, H, W } from "./constants";
import type { FactionId } from "./constants";

export function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Ctx = CanvasRenderingContext2D;

function circle(ctx: Ctx, x: number, y: number, r: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}
function ellipse(ctx: Ctx, x: number, y: number, rx: number, ry: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
}
function line(ctx: Ctx, x0: number, y0: number, x1: number, y1: number, color: string, w: number) {
  ctx.strokeStyle = color;
  ctx.lineWidth = w;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.stroke();
}

/* layout of the far background (top strip of the screen) */
const HILL_Y = 62;
const LAKE_TOP = 66;
const LAKE_BOT = 97;
const MILL = { x: 1452, y: 41 };

const lakeEdge = (x: number) => LAKE_BOT + Math.sin(x * 0.011) * 3 + Math.sin(x * 0.037 + 1) * 1.5;

const PAL = {
  green: { main: ["#5fae4a", "#6ebd55", "#52a040"], hi: ["#8ed46a", "#9bdd74", "#80c85e"], dark: "#3f8433" },
  sakura: { main: ["#ffb3ce", "#ffa3c4", "#ffc2d8"], hi: ["#ffe0ec", "#ffd4e4", "#ffe9f1"], dark: "#e884ad" },
  gold: { main: ["#f0c552", "#f5cf63", "#e6b640"], hi: ["#ffe68f", "#ffeca2", "#f8d877"], dark: "#c9963a" },
};
type TreeKind = keyof typeof PAL;

function drawTree(ctx: Ctx, x: number, y: number, s: number, rnd: () => number, kind?: TreeKind) {
  const r0 = rnd();
  const k: TreeKind = kind ?? (r0 < 0.34 ? "sakura" : r0 < 0.46 ? "gold" : "green");
  const i = Math.floor(rnd() * 3);
  const pal = PAL[k];
  // midday sun: a short shadow right under the crown
  ellipse(ctx, x + 5 * s, y + 3 * s, 25 * s, 8 * s, "rgba(30,70,20,0.26)");
  ctx.fillStyle = k === "sakura" ? "#6a4636" : "#6b4a2c";
  ctx.fillRect(x - 2.5 * s, y - 15 * s, 5 * s, 16 * s);
  ctx.fillStyle = k === "sakura" ? "#523427" : "#553a22";
  ctx.fillRect(x + 0.5 * s, y - 15 * s, 2 * s, 16 * s);
  const blobs: [number, number, number][] = [];
  const n = 5 + Math.floor(rnd() * 4);
  for (let j = 0; j < n; j++) blobs.push([(rnd() - 0.5) * 34 * s, -26 * s - rnd() * 16 * s, (9 + rnd() * 8) * s]);
  blobs.forEach(([bx, by, r]) => circle(ctx, x + bx + 2 * s, y + by + 3.5 * s, r, pal.dark));
  blobs.forEach(([bx, by, r]) => circle(ctx, x + bx, y + by, r, pal.main[i]));
  blobs.forEach(([bx, by, r]) => circle(ctx, x + bx - r * 0.3, y + by - r * 0.35, r * 0.5, pal.hi[i]));
  if (k === "sakura") {
    for (let j = 0; j < 9; j++) {
      const b = blobs[Math.floor(rnd() * blobs.length)];
      circle(ctx, x + b[0] + (rnd() - 0.5) * b[2] * 1.6, y + b[1] + (rnd() - 0.5) * b[2] * 1.6, 1.3 * s, rnd() < 0.6 ? "#ffffff" : "#ff8fb8");
    }
    // fallen petals around the trunk
    for (let j = 0; j < 7; j++) ellipse(ctx, x + (rnd() - 0.5) * 44 * s, y + 2 * s + (rnd() - 0.5) * 9 * s, 1.5 * s, 0.9 * s, "#ffd0e0");
  } else if (k === "green" && rnd() < 0.4) {
    for (let j = 0; j < 5; j++) {
      const b = blobs[Math.floor(rnd() * blobs.length)];
      circle(ctx, x + b[0] + (rnd() - 0.5) * b[2], y + b[1] + (rnd() - 0.5) * b[2], 1.4 * s, rnd() < 0.5 ? "#ff7f6e" : "#fff2c2");
    }
  }
}

function drawBush(ctx: Ctx, x: number, y: number, s: number, rnd: () => number) {
  ellipse(ctx, x + 3 * s, y + 2 * s, 15 * s, 5 * s, "rgba(30,70,20,0.26)");
  const bl: [number, number, number][] = [];
  for (let i = 0; i < 4; i++) bl.push([(rnd() - 0.5) * 16 * s, -4 * s - rnd() * 5 * s, (5 + rnd() * 4) * s]);
  bl.forEach(([bx, by, r]) => circle(ctx, x + bx + 1.5, y + by + 2, r, "#3f8433"));
  bl.forEach(([bx, by, r]) => circle(ctx, x + bx, y + by, r, "#5aa843"));
  bl.forEach(([bx, by, r]) => circle(ctx, x + bx - r * 0.3, y + by - r * 0.35, r * 0.45, "#86d063"));
  const col = ["#fff6b0", "#ff9ec4", "#ffffff"][Math.floor(rnd() * 3)];
  for (let i = 0; i < 4; i++) circle(ctx, x + (rnd() - 0.5) * 14 * s, y - 2 - rnd() * 8 * s, 1.3, col);
}

function drawRock(ctx: Ctx, x: number, y: number, s: number) {
  ellipse(ctx, x + 2 * s, y + 1, 7 * s, 2.5 * s, "rgba(30,70,20,0.26)");
  ctx.fillStyle = "#a5a196";
  ctx.beginPath();
  ctx.moveTo(x - 6 * s, y);
  ctx.lineTo(x - 4 * s, y - 5 * s);
  ctx.lineTo(x + 1 * s, y - 7 * s);
  ctx.lineTo(x + 6 * s, y - 3 * s);
  ctx.lineTo(x + 6 * s, y);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#d2cec2";
  ctx.beginPath();
  ctx.moveTo(x - 4 * s, y - 5 * s);
  ctx.lineTo(x + 1 * s, y - 7 * s);
  ctx.lineTo(x + 2 * s, y - 3 * s);
  ctx.lineTo(x - 3 * s, y - 2 * s);
  ctx.closePath();
  ctx.fill();
}

function drawFence(ctx: Ctx, x0: number, y: number, n: number) {
  for (let i = 0; i < n; i++) {
    const x = x0 + i * 14;
    ellipse(ctx, x + 2, y + 1, 3, 1.2, "rgba(30,70,20,0.26)");
    ctx.fillStyle = "#96693d";
    ctx.fillRect(x - 1.5, y - 12, 3, 12);
    ctx.fillStyle = "#b8874f";
    ctx.fillRect(x - 1.5, y - 12, 1.2, 12);
  }
  ctx.fillStyle = "#a87641";
  ctx.fillRect(x0 - 2, y - 10, (n - 1) * 14 + 4, 2);
  ctx.fillRect(x0 - 2, y - 5, (n - 1) * 14 + 4, 2);
}

/** a jagged mountain range with sunlit faces and snow caps */
function ridge(ctx: Ctx, rnd: () => number, base: number, top: number, low: number, step: number, color: string, light: string, snowAbove: number) {
  const pts: [number, number][] = [];
  let x = -60;
  let up = rnd() < 0.5;
  while (x < W + 80) {
    const span = low - top;
    pts.push([x, up ? top + rnd() * span * 0.45 : low - rnd() * span * 0.3]);
    x += step * (0.6 + rnd() * 0.8);
    up = !up;
  }
  const path = () => {
    ctx.beginPath();
    ctx.moveTo(-60, base);
    pts.forEach(([px, py]) => ctx.lineTo(px, py));
    ctx.lineTo(W + 80, base);
    ctx.closePath();
  };
  path();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.save();
  path();
  ctx.clip();
  for (let i = 1; i < pts.length - 1; i++) {
    const [px, py] = pts[i];
    const [lx, ly] = pts[i - 1];
    const [rx, ry] = pts[i + 1];
    if (py > ly || py > ry) continue; // not a peak
    // the sun stands to the left: left faces glow
    ctx.fillStyle = light;
    ctx.beginPath();
    ctx.moveTo(lx, ly);
    ctx.lineTo(px, py);
    ctx.lineTo(px + (rx - px) * 0.18, base);
    ctx.lineTo(lx, base);
    ctx.closePath();
    ctx.fill();
    if (py < snowAbove) {
      const L: [number, number] = [px + (lx - px) * 0.34, py + (ly - py) * 0.34];
      const R: [number, number] = [px + (rx - px) * 0.34, py + (ry - py) * 0.34];
      const w = rx - lx;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.moveTo(L[0], L[1]);
      ctx.lineTo(px, py);
      ctx.lineTo(R[0], R[1]);
      ctx.lineTo(px + w * 0.09, R[1] - 2.5);
      ctx.lineTo(px + w * 0.02, Math.max(L[1], R[1]) + 1.5);
      ctx.lineTo(px - w * 0.07, L[1] - 2.5);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(170,200,235,0.55)";
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(R[0], R[1]);
      ctx.lineTo(px + w * 0.09, R[1] - 2.5);
      ctx.lineTo(px + w * 0.02, Math.max(L[1], R[1]) + 1.5);
      ctx.closePath();
      ctx.fill();
    }
  }
  ctx.restore();
}

function drawHouse(ctx: Ctx, x: number, y: number, s: number, roof: string) {
  ctx.fillStyle = "#fff6e2";
  ctx.fillRect(x - 4 * s, y - 5 * s, 8 * s, 5 * s);
  ctx.fillStyle = "#e9d9b8";
  ctx.fillRect(x + 1 * s, y - 5 * s, 3 * s, 5 * s);
  ctx.fillStyle = roof;
  ctx.beginPath();
  ctx.moveTo(x - 5.5 * s, y - 5 * s);
  ctx.lineTo(x, y - 10 * s);
  ctx.lineTo(x + 5.5 * s, y - 5 * s);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#7a5230";
  ctx.fillRect(x - 1 * s, y - 3 * s, 2 * s, 3 * s);
}

function drawBoat(ctx: Ctx, x: number, y: number, s: number, sail: string) {
  ellipse(ctx, x, y + 2 * s, 8 * s, 1.4 * s, "rgba(255,255,255,0.4)");
  ctx.fillStyle = "#8a5a34";
  ctx.beginPath();
  ctx.moveTo(x - 6 * s, y - 1 * s);
  ctx.lineTo(x + 6 * s, y - 1 * s);
  ctx.lineTo(x + 4 * s, y + 2 * s);
  ctx.lineTo(x - 4 * s, y + 2 * s);
  ctx.closePath();
  ctx.fill();
  line(ctx, x, y - 1 * s, x, y - 11 * s, "#5a3f26", 0.9 * s);
  ctx.fillStyle = sail;
  ctx.beginPath();
  ctx.moveTo(x + 0.8 * s, y - 11 * s);
  ctx.lineTo(x + 6 * s, y - 2.5 * s);
  ctx.lineTo(x + 0.8 * s, y - 2.5 * s);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.moveTo(x - 0.8 * s, y - 9.5 * s);
  ctx.lineTo(x - 4.5 * s, y - 2.5 * s);
  ctx.lineTo(x - 0.8 * s, y - 2.5 * s);
  ctx.closePath();
  ctx.fill();
}

/** a tree of the faction's homeland: oaks, date palms, snowy pines, cherry blossom */
function themeTree(ctx: Ctx, x: number, y: number, s: number, rnd: () => number, f: FactionId) {
  if (f === "crusader") return drawTree(ctx, x, y, s, rnd, rnd() < 0.25 ? "gold" : "green");
  if (f === "samurai") return drawTree(ctx, x, y, s, rnd, rnd() < 0.85 ? "sakura" : "green");
  ellipse(ctx, x + 5 * s, y + 3 * s, 22 * s, 7 * s, "rgba(30,70,20,0.26)");
  if (f === "arab") {
    const lean = (rnd() - 0.5) * 14 * s;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x - lean * 0.4, y - 24 * s, x + lean, y - 44 * s);
    ctx.strokeStyle = "#3b2a1a";
    ctx.lineWidth = 6 * s;
    ctx.stroke();
    ctx.strokeStyle = "#b07d45";
    ctx.lineWidth = 4 * s;
    ctx.stroke();
    const tx = x + lean;
    const ty = y - 44 * s;
    for (let i = 0; i < 7; i++) {
      const a = -Math.PI * 1.05 + (i / 6) * Math.PI * 1.1;
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.quadraticCurveTo(tx + Math.cos(a) * 12 * s, ty + Math.sin(a) * 10 * s - 6 * s, tx + Math.cos(a) * 24 * s, ty + Math.sin(a) * 12 * s + 8 * s);
      ctx.quadraticCurveTo(tx + Math.cos(a) * 10 * s, ty + Math.sin(a) * 5 * s, tx, ty);
      ctx.fillStyle = i % 2 ? "#3fae5a" : "#5cc970";
      ctx.fill();
    }
    circle(ctx, tx - 2 * s, ty + 2 * s, 2.2 * s, "#c9803a");
    circle(ctx, tx + 2 * s, ty + 3 * s, 2.2 * s, "#b56f2e");
    return;
  }
  // viking: a pine dusted with snow
  ctx.fillStyle = "#6b4a2c";
  ctx.fillRect(x - 2.5 * s, y - 10 * s, 5 * s, 11 * s);
  for (let i = 0; i < 3; i++) {
    const w = (20 - i * 5) * s;
    const top = y - (26 + i * 13) * s;
    const bot = y - (8 + i * 12) * s;
    const h = bot - top;
    ctx.beginPath();
    ctx.moveTo(x - w, bot);
    ctx.lineTo(x, top);
    ctx.lineTo(x + w, bot);
    ctx.closePath();
    ctx.fillStyle = i % 2 ? "#2f7d57" : "#3a8f63";
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(x - w * 0.42, top + h * 0.42);
    ctx.lineTo(x, top);
    ctx.lineTo(x + w * 0.42, top + h * 0.42);
    ctx.lineTo(x + w * 0.2, top + h * 0.34);
    ctx.lineTo(x, top + h * 0.46);
    ctx.lineTo(x - w * 0.2, top + h * 0.34);
    ctx.closePath();
    ctx.fillStyle = "#f6fafc";
    ctx.fill();
  }
}

const TINT: Record<FactionId, [string, number]> = {
  crusader: ["246,226,130", 0.3],
  arab: ["244,220,160", 0.9],
  viking: ["244,250,255", 0.8],
  samurai: ["255,206,224", 0.42],
};

/** the land around a castle: wheat and hay, desert sand, snow and rune stones, petals and lanterns */
function themeGround(ctx: Ctx, rnd: () => number, f: FactionId, cx: number, dir: number) {
  const [tint, strength] = TINT[f];
  const gx = cx - dir * 30;
  const g = ctx.createRadialGradient(gx, 450, 60, gx, 450, 330);
  g.addColorStop(0, `rgba(${tint},${strength})`);
  g.addColorStop(0.6, `rgba(${tint},${strength * 0.6})`);
  g.addColorStop(1, `rgba(${tint},0)`);
  ctx.fillStyle = g;
  ctx.fillRect(gx - 340, 110, 680, 680);
  // small things on the ground, kept low so soldiers can walk past them
  for (let i = 0; i < 30; i++) {
    const x = cx + (rnd() * 2 - 1) * 160 + dir * 20;
    const y = 132 + rnd() * 610;
    const sub = rnd();
    if (x < 14 || x > W - 14) continue;
    if (Math.abs(x - cx) < 104 && y > CASTLE[0].top - 24 && y < CASTLE[0].baseY + 28) continue;
    if (Math.abs(y - roadY(x)) < 32) continue;
    if (f === "crusader") {
      if (i % 3 === 0) {
        ellipse(ctx, x + 2, y + 2, 9, 3, "rgba(30,70,20,0.25)");
        ctx.beginPath();
        ctx.ellipse(x, y - 4, 8, 5.5, 0, 0, Math.PI * 2);
        ctx.fillStyle = "#ecc95e";
        ctx.fill();
        ctx.strokeStyle = "#8a6a2c";
        ctx.lineWidth = 1;
        ctx.stroke();
        line(ctx, x - 4, y - 8, x - 4, y, "#b8923a", 1);
        line(ctx, x + 3, y - 8.5, x + 3, y + 0.5, "#b8923a", 1);
      } else {
        for (let k = 0; k < 9; k++) {
          const wx = x + (((k * 37 + i * 11) % 26) - 13);
          const wy = y + (((k * 17 + i * 7) % 10) - 5);
          line(ctx, wx, wy, wx + 1, wy - 7, "#d9b445", 1.1);
          circle(ctx, wx + 1.2, wy - 7.5, 1.3, "#f4d568");
        }
      }
    } else if (f === "arab") {
      if (i % 4 === 0) {
        ellipse(ctx, x + 2, y + 1, 7, 2.4, "rgba(120,90,40,0.3)");
        ctx.fillStyle = "#4fae62";
        ctx.fillRect(x - 2, y - 11, 4, 11);
        ctx.fillRect(x - 6, y - 8, 4, 2.4);
        ctx.fillRect(x - 6, y - 10.5, 2.4, 5);
        ctx.fillRect(x + 2, y - 6, 4, 2.4);
        ctx.fillRect(x + 3.6, y - 9, 2.4, 5.4);
        circle(ctx, x, y - 11.5, 1.3, "#ff8fb8");
      } else if (i % 4 === 1) drawRock(ctx, x, y, 0.6 + sub * 0.5);
      else {
        ctx.strokeStyle = "rgba(196,160,96,0.75)";
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(x - 16, y);
        ctx.quadraticCurveTo(x - 4, y - 5, x + 14, y - 1);
        ctx.stroke();
      }
    } else if (f === "viking") {
      if (i % 4 === 0) {
        ellipse(ctx, x + 2, y + 1, 7, 2.4, "rgba(80,110,140,0.3)");
        ctx.fillStyle = "#9aa0a6";
        ctx.beginPath();
        ctx.moveTo(x - 5, y);
        ctx.lineTo(x - 4, y - 11);
        ctx.lineTo(x, y - 14);
        ctx.lineTo(x + 4, y - 11);
        ctx.lineTo(x + 5, y);
        ctx.closePath();
        ctx.fill();
        line(ctx, x - 1.5, y - 10, x + 1.5, y - 7, "#c0392b", 1);
        line(ctx, x + 1.5, y - 10, x - 1.5, y - 4, "#c0392b", 1);
      } else {
        ellipse(ctx, x + 1, y + 1.5, 13 + sub * 10, 4.5 + sub * 2, "rgba(170,200,225,0.55)");
        ellipse(ctx, x, y, 12 + sub * 9, 4 + sub * 2, "#fbfdff");
      }
    } else if (i % 5 === 0) {
      ellipse(ctx, x + 2, y + 1, 6, 2.2, "rgba(30,70,20,0.25)");
      ctx.fillStyle = "#a9a7a0";
      ctx.fillRect(x - 1.5, y - 8, 3, 8);
      ctx.fillRect(x - 4, y - 12, 8, 4);
      ctx.fillStyle = "#ffe08a";
      ctx.fillRect(x - 1.5, y - 11, 3, 2.2);
      ctx.fillStyle = "#6f6d66";
      ctx.beginPath();
      ctx.moveTo(x - 6, y - 12);
      ctx.lineTo(x, y - 17);
      ctx.lineTo(x + 6, y - 12);
      ctx.closePath();
      ctx.fill();
    } else if (i % 5 === 1) {
      for (let k = 0; k < 3; k++) ellipse(ctx, x + k * 9, y + (k % 2) * 3, 3.6, 1.8, "#bdbbb3");
    } else {
      for (let k = 0; k < 12; k++) ellipse(ctx, x + (((k * 29 + i * 13) % 30) - 15), y + (((k * 11 + i * 5) % 12) - 6), 1.6, 0.9, k % 2 ? "#ffd0e0" : "#ffb3ce");
    }
  }
}

/** each people sails its own ship on the lake behind its castle */
function themeShip(ctx: Ctx, f: FactionId, x: number, y: number, dir: number) {
  const m = FACTIONS[f].main;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(dir * 1.55, 1.55);
  ctx.lineJoin = "round";
  ctx.strokeStyle = "#3b2a1a";
  ctx.lineWidth = 0.8;
  const P = (p: number[], col: string) => {
    ctx.beginPath();
    ctx.moveTo(p[0], p[1]);
    for (let i = 2; i < p.length; i += 2) ctx.lineTo(p[i], p[i + 1]);
    ctx.closePath();
    ctx.fillStyle = col;
    ctx.fill();
    ctx.stroke();
  };
  ellipse(ctx, 0, 3.4, 16, 1.6, "rgba(255,255,255,0.5)");
  if (f === "viking") {
    // longship: dragon prow, striped sail, shields along the rail
    P([10.5, -1, 14.6, -8.4, 16.4, -7.6, 15, -5.6, 13, -1], "#8a5a34");
    P([-10.5, -1, -14.4, -6.8, -13, -7.6, -11, -1], "#8a5a34");
    P([-13, -1, -9, 3, 9, 3, 13, -1], "#8a5a34");
    line(ctx, 0, -1, 0, -16, "#5a3f26", 0.9);
    for (let i = 0; i < 5; i++) {
      ctx.fillStyle = i % 2 ? "#f8f4ea" : m;
      ctx.fillRect(-7 + i * 2.8, -15, 2.8, 9.5);
    }
    ctx.strokeRect(-7, -15, 14, 9.5);
    for (let i = 0; i < 5; i++) {
      circle(ctx, -6.4 + i * 3.2, 0.4, 1.5, i % 2 ? "#f1e3bd" : m);
      ctx.beginPath();
      ctx.arc(-6.4 + i * 3.2, 0.4, 1.5, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else if (f === "crusader") {
    // a cog with fighting castles and the cross on its sail
    P([-11, -1, -8, 3, 8, 3, 11, -1], "#8a5a34");
    P([-11.5, -5, -11.5, -1, -6, -1, -6, -5], "#a8763f");
    P([6, -5, 6, -1, 11.5, -1, 11.5, -5], "#a8763f");
    line(ctx, 0, -1, 0, -17, "#5a3f26", 0.9);
    P([-6.5, -15, 6.5, -15, 6.5, -5.5, -6.5, -5.5], "#f8f4ea");
    ctx.fillStyle = m;
    ctx.fillRect(-0.9, -14, 1.8, 7.6);
    ctx.fillRect(-4.2, -11.2, 8.4, 1.8);
    P([0, -17, 4.6, -18.4, 0, -19.8], m);
  } else if (f === "arab") {
    // a dhow under a lateen sail
    P([-12, -2.4, -8, 3, 9, 3, 13.6, -3.6], "#8a5a34");
    line(ctx, -1, -1.4, 2.6, -16.5, "#5a3f26", 0.9);
    P([-9.4, -3.4, 3.6, -17.6, 8, -2.6], "#fbf7ee");
    P([2.6, -16.5, 6.6, -17.6, 2.9, -19.4], m);
  } else {
    // a sekibune with a battened sail and the clan's mon
    P([-12, -1, -9, 3, 9, 3, 12, -1], "#5a3f2a");
    P([-7, -5, 7, -5, 7, -1, -7, -1], "#f9f6ee");
    P([-8.6, -5, -7, -7.4, 7, -7.4, 8.6, -5], "#3b5a66");
    line(ctx, 0, -7.4, 0, -19, "#3a2a1c", 0.9);
    P([-5, -18.4, 5, -18.4, 5, -8.4, -5, -8.4], "#fbf7ee");
    for (const yy of [-15.9, -13.4, -10.9]) line(ctx, -5, yy, 5, yy, "rgba(60,42,26,0.45)", 0.5);
    circle(ctx, 0, -13.4, 2, m);
  }
  ctx.restore();
}

/** something from home beside each castle: a pavilion, a tent and camel, a camp fire, a torii */
function themeLandmark(ctx: Ctx, f: FactionId, x: number, y: number, dir: number) {
  const m = FACTIONS[f].main;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(dir, 1);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.strokeStyle = "#3b2a1a";
  ctx.lineWidth = 1.2;
  const P = (p: number[], col: string) => {
    ctx.beginPath();
    ctx.moveTo(p[0], p[1]);
    for (let i = 2; i < p.length; i += 2) ctx.lineTo(p[i], p[i + 1]);
    ctx.closePath();
    ctx.fillStyle = col;
    ctx.fill();
    ctx.stroke();
  };
  if (f === "crusader") {
    // a striped campaign pavilion
    ellipse(ctx, 2, 2, 30, 6, "rgba(30,70,20,0.25)");
    P([-20, 0, -20, -17, 20, -17, 20, 0], "#f8f4ea");
    ctx.fillStyle = m;
    for (const sx of [-15, -3, 9]) ctx.fillRect(sx, -16.4, 6, 15.8);
    P([-25, -17, 0, -43, 25, -17], m);
    P([-9, -17, 0, -43, 9, -17], "#f8f4ea");
    P([-5, 0, 0, -13, 5, 0], "#4a3526");
    line(ctx, 0, -43, 0, -54, "#4a3526", 1.4);
    P([0, -54, 11, -51, 0, -48], m);
  } else if (f === "arab") {
    // a Bedouin tent and a resting camel
    ellipse(ctx, 6, 2, 46, 7, "rgba(120,90,40,0.25)");
    P([-32, 0, -23, -19, -5, -25, 13, -19, 22, 0], "#4a3a32");
    line(ctx, -27, -10, 17, -10, "#c8503c", 2.4);
    line(ctx, -25, -14, 15, -14, "#f3ead6", 1.2);
    P([-9, 0, -5, -15, -1, 0], "#2a211c");
    // camel
    for (const lx of [33, 37, 46, 50]) line(ctx, lx, -9, lx, 0, "#b98f52", 2.6);
    ctx.beginPath();
    ctx.ellipse(41.5, -14, 10.5, 6.2, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#d2a868";
    ctx.fill();
    ctx.stroke();
    P([37, -19, 41.5, -27, 46, -19], "#d2a868");
    P([49, -16, 53.5, -31, 57, -30, 53.5, -11], "#d2a868");
    ctx.beginPath();
    ctx.ellipse(57.4, -32.4, 4.2, 2.5, 0.3, 0, Math.PI * 2);
    ctx.fillStyle = "#d2a868";
    ctx.fill();
    ctx.stroke();
    circle(ctx, 58.4, -33.2, 0.7, "#3b2a1a");
    P([36.5, -19, 41.5, -22, 46.5, -19, 46.5, -13, 36.5, -13], m);
    line(ctx, 37, -14.4, 46, -14.4, "#f2c14e", 1);
  } else if (f === "viking") {
    // an upturned boat, a rack of shields and a camp fire
    ellipse(ctx, 6, 2, 44, 7, "rgba(80,110,140,0.28)");
    P([-34, 0, -27, -13, 3, -13, 10, 0], "#8a5a34");
    line(ctx, -30, -6, 6, -6, "#5f3f22", 1);
    line(ctx, -12, -13, -12, 0, "#5f3f22", 1);
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(-24 + i * 12, -18, 6, 0, Math.PI * 2);
      ctx.fillStyle = i % 2 ? "#f1e3bd" : m;
      ctx.fill();
      ctx.stroke();
      circle(ctx, -24 + i * 12, -18, 1.8, "#9da6b0");
    }
    line(ctx, 22, 0, 36, -4, "#5f3f22", 3);
    line(ctx, 36, 0, 22, -4, "#5f3f22", 3);
    P([23, -3, 26, -13, 29, -8, 31, -18, 34, -9, 36, -3], "#ff9a3c");
    P([27, -3, 29.5, -9, 31, -6, 33, -3], "#ffe08a");
  } else {
    // a vermilion torii
    ellipse(ctx, 2, 2, 30, 6, "rgba(30,70,20,0.25)");
    P([-19, 0, -17, -40, -13, -40, -14, 0], "#d8343a");
    P([14, 0, 13, -40, 17, -40, 19, 0], "#d8343a");
    P([-23, -30, 23, -30, 23, -26, -23, -26], "#d8343a");
    ctx.beginPath();
    ctx.moveTo(-29, -47);
    ctx.quadraticCurveTo(0, -42, 29, -47);
    ctx.lineTo(26, -39);
    ctx.lineTo(-26, -39);
    ctx.closePath();
    ctx.fillStyle = "#d8343a";
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-29, -47);
    ctx.quadraticCurveTo(0, -42, 29, -47);
    ctx.strokeStyle = "#2c2b36";
    ctx.lineWidth = 3;
    ctx.stroke();
    P([-3, -39, 3, -39, 3, -30, -3, -30], "#f2c14e");
  }
  ctx.restore();
}

export function roadY(x: number) {
  return 452 + Math.sin(x * 0.006) * 18 + Math.sin(x * 0.017 + 1) * 6;
}

export function pickScale() {
  if (typeof window === "undefined") return 1;
  const stage = Math.min(window.innerWidth, (window.innerHeight * 16) / 9);
  const want = ((window.devicePixelRatio || 1) * stage) / W;
  return Math.max(1, Math.min(2, Math.ceil(want * 4) / 4));
}

export function buildBackground(seed = 7, factions: [FactionId, FactionId] = ["crusader", "viking"], scale?: number) {
  const SC = scale ?? pickScale();
  const bg = document.createElement("canvas");
  bg.width = Math.round(W * SC);
  bg.height = Math.round(H * SC);
  const ctx = bg.getContext("2d")!;
  ctx.scale(SC, SC);
  const rnd = mulberry32(seed);

  /* ---------------- sky ---------------- */
  const sky = ctx.createLinearGradient(0, 0, 0, HILL_Y + 6);
  sky.addColorStop(0, "#3a9bee");
  sky.addColorStop(0.55, "#86cdfb");
  sky.addColorStop(1, "#e2f5ff");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, W, HILL_Y + 10);
  // the midday sun
  const SUN = { x: 118, y: 26 };
  const glow = ctx.createRadialGradient(SUN.x, SUN.y, 4, SUN.x, SUN.y, 120);
  glow.addColorStop(0, "rgba(255,252,220,0.95)");
  glow.addColorStop(0.25, "rgba(255,246,190,0.45)");
  glow.addColorStop(1, "rgba(255,246,190,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, 260, HILL_Y + 10);
  ctx.fillStyle = "rgba(255,250,210,0.5)";
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 + 0.2;
    const r1 = 20;
    const r2 = i % 2 ? 34 : 44;
    ctx.beginPath();
    ctx.moveTo(SUN.x + Math.cos(a - 0.07) * r1, SUN.y + Math.sin(a - 0.07) * r1);
    ctx.lineTo(SUN.x + Math.cos(a) * r2, SUN.y + Math.sin(a) * r2);
    ctx.lineTo(SUN.x + Math.cos(a + 0.07) * r1, SUN.y + Math.sin(a + 0.07) * r1);
    ctx.closePath();
    ctx.fill();
  }
  circle(ctx, SUN.x, SUN.y, 15, "#fff7c9");
  circle(ctx, SUN.x - 3, SUN.y - 3, 9, "#fffdf0");

  /* ---------------- mountains ---------------- */
  ridge(ctx, rnd, HILL_Y + 6, 10, 46, 86, "#a9c6ee", "#c4dbf8", 30);
  const haze = ctx.createLinearGradient(0, 30, 0, HILL_Y + 6);
  haze.addColorStop(0, "rgba(226,245,255,0)");
  haze.addColorStop(1, "rgba(226,245,255,0.75)");
  ctx.fillStyle = haze;
  ctx.fillRect(0, 30, W, HILL_Y - 24);
  ridge(ctx, rnd, HILL_Y + 6, 28, 56, 120, "#86aede", "#a7c8ee", 36);

  /* ---------------- far green hills, village, windmill ---------------- */
  const hill = (y0: number, amp: number, f: number, ph: number, color: string) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, LAKE_TOP + 6);
    for (let x = 0; x <= W; x += 16) ctx.lineTo(x, y0 + Math.sin(x * f + ph) * amp + Math.sin(x * f * 2.7 + ph * 2) * amp * 0.35);
    ctx.lineTo(W, LAKE_TOP + 6);
    ctx.closePath();
    ctx.fill();
  };
  hill(HILL_Y - 5, 5, 0.006, 0.6, "#a8dca0");
  hill(HILL_Y, 4, 0.011, 2.1, "#8fd27a");
  for (let i = 0; i < 90; i++) {
    const x = rnd() * W;
    const y = HILL_Y - 2 + rnd() * 6;
    const r = 1.6 + rnd() * 2.2;
    const pink = rnd() < 0.22;
    circle(ctx, x + 0.8, y + 0.8, r, pink ? "#e98db2" : "#4f9a45");
    circle(ctx, x, y, r, pink ? "#ffb9d2" : "#6dbb58");
  }
  // a little village under the windmill
  const roofs = ["#e2574c", "#f08a3c", "#d9463e", "#e2574c", "#c9503f"];
  [1318, 1344, 1372, 1398, 1494, 1524].forEach((hx, i) => drawHouse(ctx, hx, HILL_Y + 4 + (i % 2), 0.9 + (i % 3) * 0.12, roofs[i % roofs.length]));
  // (the windmill itself is drawn live, in front of the passing clouds)

  /* ---------------- lake ---------------- */
  const water = ctx.createLinearGradient(0, LAKE_TOP, 0, LAKE_BOT + 4);
  water.addColorStop(0, "#49b8ea");
  water.addColorStop(0.6, "#6fd3f0");
  water.addColorStop(1, "#a4ecf4");
  ctx.fillStyle = water;
  ctx.fillRect(0, LAKE_TOP, W, LAKE_BOT - LAKE_TOP + 12);
  // soft reflection of the hills
  const refl = ctx.createLinearGradient(0, LAKE_TOP, 0, LAKE_TOP + 12);
  refl.addColorStop(0, "rgba(96,176,120,0.5)");
  refl.addColorStop(1, "rgba(96,176,120,0)");
  ctx.fillStyle = refl;
  ctx.fillRect(0, LAKE_TOP, W, 12);
  ctx.strokeStyle = "rgba(255,255,255,0.6)";
  ctx.lineWidth = 1.3;
  ctx.lineCap = "round";
  for (let i = 0; i < 90; i++) {
    const x = rnd() * W;
    const y = LAKE_TOP + 4 + rnd() * (LAKE_BOT - LAKE_TOP - 8);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + 5, y - 1.6, x + 9 + rnd() * 10, y);
    ctx.stroke();
  }
  drawBoat(ctx, 560, LAKE_TOP + 12, 1, "#ff6f61");
  drawBoat(ctx, 1040, LAKE_TOP + 15, 1.15, "#ffd23a");
  drawBoat(ctx, 300, LAKE_TOP + 9, 0.8, "#7fd3ff");
  themeShip(ctx, factions[0], 168, LAKE_TOP + 15, 1);
  themeShip(ctx, factions[1], W - 168, LAKE_TOP + 15, -1);

  /* ---------------- shore + meadow ---------------- */
  const shore = (off: number, color: string) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, H);
    ctx.lineTo(0, lakeEdge(0) + off);
    for (let x = 0; x <= W; x += 14) ctx.lineTo(x, lakeEdge(x) + off);
    ctx.lineTo(W, H);
    ctx.closePath();
    ctx.fill();
  };
  shore(-2, "rgba(255,255,255,0.75)"); // foam
  shore(0, "#f6e7b6"); // sand
  shore(4, "#e9d59a");
  const base = ctx.createLinearGradient(0, LAKE_BOT, 0, H);
  base.addColorStop(0, "#b6ea78");
  base.addColorStop(0.35, "#a4e068");
  base.addColorStop(1, "#90d45a");
  shore(8, "#7cba4d");
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(0, H);
  ctx.lineTo(0, lakeEdge(0) + 9.5);
  for (let x = 0; x <= W; x += 14) ctx.lineTo(x, lakeEdge(x) + 9.5 + Math.sin(x * 0.21) * 0.8);
  ctx.lineTo(W, H);
  ctx.closePath();
  ctx.clip();
  ctx.fillStyle = base;
  ctx.fillRect(0, LAKE_BOT, W, H - LAKE_BOT);
  // sun-dappled rolling ground
  for (let i = 0; i < 60; i++) {
    const x = rnd() * W;
    const y = 110 + rnd() * (H - 110);
    const r = 60 + rnd() * 190;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, rnd() > 0.45 ? "rgba(232,252,156,0.36)" : "rgba(126,200,88,0.13)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }
  ctx.restore();
  // reeds on the shore
  for (let i = 0; i < 130; i++) {
    const x = rnd() * W;
    const y = lakeEdge(x) + 2 + rnd() * 5;
    line(ctx, x, y, x + (rnd() - 0.5) * 2, y - 4 - rnd() * 5, rnd() < 0.5 ? "#5fa446" : "#86c95e", 1);
    if (rnd() < 0.25) ellipse(ctx, x, y - 8, 0.9, 2, "#8a5a34");
  }

  /* ---------------- cobbled road between the castles ---------------- */
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const roadPath = () => {
    ctx.beginPath();
    for (let x = 0; x <= W; x += 10) {
      const y = roadY(x);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
  };
  roadPath();
  ctx.strokeStyle = "rgba(96,150,60,0.55)";
  ctx.lineWidth = 60;
  ctx.stroke();
  roadPath();
  ctx.strokeStyle = "#c9ae78";
  ctx.lineWidth = 52;
  ctx.stroke();
  roadPath();
  ctx.strokeStyle = "#ecdcae";
  ctx.lineWidth = 45;
  ctx.stroke();
  const stones = ["#f6ebc8", "#dfca97", "#e9d7a6", "#d6bf8a", "#f1e2b8"];
  for (let i = 0; i < 620; i++) {
    const x = rnd() * W;
    const y = roadY(x) + (rnd() - 0.5) * 40;
    const rx = 2.2 + rnd() * 3;
    ctx.fillStyle = "rgba(150,120,70,0.28)";
    ctx.beginPath();
    ctx.ellipse(x + 0.6, y + 0.8, rx, rx * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();
    ellipse(ctx, x, y, rx, rx * 0.6, stones[Math.floor(rnd() * stones.length)]);
  }
  // grass creeping over the kerb
  for (let i = 0; i < 380; i++) {
    const x = rnd() * W;
    const y = roadY(x) + (rnd() < 0.5 ? -1 : 1) * (24 + rnd() * 4);
    line(ctx, x, y, x + (rnd() - 0.5) * 3, y - 3 - rnd() * 3, rnd() < 0.5 ? "#6fb04c" : "#a6de72", 1.1);
  }

  /* ---------------- grass tufts ---------------- */
  for (let i = 0; i < 2300; i++) {
    const x = rnd() * W;
    const y = 112 + rnd() * (H - 112);
    if (Math.abs(y - roadY(x)) < 27) continue;
    ctx.strokeStyle = rnd() > 0.45 ? "rgba(88,156,58,0.9)" : "rgba(202,240,134,0.85)";
    ctx.lineWidth = 1.1;
    const n = 2 + Math.floor(rnd() * 3);
    ctx.beginPath();
    for (let k = 0; k < n; k++) {
      const dx = (k - n / 2) * 1.8;
      ctx.moveTo(x + dx, y);
      ctx.lineTo(x + dx * 1.8 + (rnd() - 0.5), y - 3 - rnd() * 3);
    }
    ctx.stroke();
  }

  /* ---------------- flower meadows ---------------- */
  const flowerSets: [string, string, string][] = [
    ["#ff5a4f", "#ff8474", "#3a2a1a"], // poppies
    ["#ffe066", "#ffd23a", "#f08a3c"], // buttercups
    ["#ffffff", "#fff6d6", "#ffd23a"], // daisies
    ["#b89cff", "#9f86f0", "#fff2a8"], // lavender
    ["#ff9ec4", "#ff7fb0", "#fff2a8"], // cosmos
    ["#8fc4ff", "#6fa8f5", "#ffffff"], // bluebells
  ];
  const flower = (fx: number, fy: number, set: [string, string, string], s: number) => {
    line(ctx, fx, fy + 2.4, fx, fy, "rgba(60,120,40,0.85)", 0.8);
    circle(ctx, fx, fy, 1.7 * s, rnd() < 0.5 ? set[0] : set[1]);
    circle(ctx, fx, fy, 0.65 * s, set[2]);
  };
  for (let i = 0; i < 26; i++) {
    const px = 30 + rnd() * (W - 60);
    const py = 135 + rnd() * (H - 200);
    if (Math.abs(py - roadY(px)) < 48) continue;
    let inCastle = false;
    for (const C of CASTLE) if (Math.abs(px - C.cx) < 120 && py > C.top - 10 && py < C.baseY + 30) inCastle = true;
    if (inCastle) continue;
    const set = flowerSets[Math.floor(rnd() * flowerSets.length)];
    const R = 34 + rnd() * 52;
    const tint = ctx.createRadialGradient(px, py, 0, px, py, R * 1.2);
    tint.addColorStop(0, set[0] + "30");
    tint.addColorStop(1, set[0] + "00");
    ctx.fillStyle = tint;
    ctx.fillRect(px - R * 1.2, py - R * 0.8, R * 2.4, R * 1.6);
    const n = 34 + Math.floor(rnd() * 40);
    for (let k = 0; k < n; k++) {
      const fx = px + (rnd() + rnd() - 1) * R;
      const fy = py + (rnd() + rnd() - 1) * R * 0.55;
      if (Math.abs(fy - roadY(fx)) < 27 || fy < 112) continue;
      flower(fx, fy, set, 0.85 + rnd() * 0.4);
    }
  }
  for (let i = 0; i < 520; i++) {
    const x = rnd() * W;
    const y = 112 + rnd() * (H - 112);
    if (Math.abs(y - roadY(x)) < 28) continue;
    flower(x, y, flowerSets[Math.floor(rnd() * flowerSets.length)], 0.8);
  }

  /* ---------------- rocks, bushes, fences ---------------- */
  for (let i = 0; i < 16; i++) {
    const x = rnd() * W;
    const y = FIELD_TOP + rnd() * (FIELD_BOTTOM - FIELD_TOP);
    if (Math.abs(y - roadY(x)) < 30) continue;
    drawRock(ctx, x, y, 0.6 + rnd() * 0.7);
  }
  for (let i = 0; i < 18; i++) {
    const x = 240 + rnd() * (W - 480);
    const y = FIELD_TOP + rnd() * (FIELD_BOTTOM - FIELD_TOP);
    if (Math.abs(y - roadY(x)) < 34) continue;
    drawBush(ctx, x, y, 0.7 + rnd() * 0.5, rnd);
  }
  drawFence(ctx, 22, 640, 13);
  drawFence(ctx, W - 200, 640, 13);
  drawFence(ctx, 22, 300, 6);
  drawFence(ctx, W - 100, 300, 6);

  /* ---------------- trees along the lake: each side grows its own homeland's trees ---------------- */
  const trees: [number, number, number, number][] = [];
  // groves with open views of the water between them
  const groves: [number, number][] = [
    [-10, 250],
    [440, 150],
    [700, 190],
    [1090, 170],
    [1370, 240],
  ];
  for (const [gx, gw] of groves) {
    const n = Math.round(gw / 34);
    for (let i = 0; i < n; i++) trees.push([gx + rnd() * gw, 104 + rnd() * 14, 0.62 + rnd() * 0.42, gx < 300 ? 0 : gx > 1300 ? 1 : 2]);
  }
  trees.sort((a, b) => a[1] - b[1]).forEach(([x, y, s, side]) => (side === 2 ? drawTree(ctx, x, y, s, rnd) : themeTree(ctx, x, y, s, rnd, factions[side])));

  /* ---------------- each castle stands in its own homeland ---------------- */
  for (let side = 0; side < 2; side++) themeGround(ctx, rnd, factions[side], CASTLE[side].cx, side === 0 ? 1 : -1);
  for (let side = 0; side < 2; side++) themeLandmark(ctx, factions[side], side === 0 ? 92 : W - 92, 704, side === 0 ? 1 : -1);

  // packed earth around the castles
  for (const C of CASTLE) {
    const g = ctx.createRadialGradient(C.cx, C.baseY - 30, 10, C.cx, C.baseY - 30, 150);
    g.addColorStop(0, "rgba(226,204,150,0.6)");
    g.addColorStop(1, "rgba(226,204,150,0)");
    ctx.fillStyle = g;
    ctx.fillRect(C.cx - 150, C.baseY - 180, 300, 300);
  }

  /* ---------------- near trees along the bottom edge ---------------- */
  const ft: [number, number, number][] = [];
  for (let i = 0; i < 24; i++) ft.push([rnd() * W, 805 + rnd() * 110, 0.9 + rnd() * 0.8]);
  ft.sort((a, b) => a[1] - b[1]).forEach(([x, y, s]) => (x < 330 ? themeTree(ctx, x, y, s, rnd, factions[0]) : x > W - 330 ? themeTree(ctx, x, y, s, rnd, factions[1]) : drawTree(ctx, x, y, s, rnd)));

  /* ---------------- bright morning light: soft sunbeams from the upper left ---------------- */
  const sun = ctx.createLinearGradient(0, 0, W * 0.7, H);
  sun.addColorStop(0, "rgba(255,250,214,0.26)");
  sun.addColorStop(0.5, "rgba(255,250,214,0.06)");
  sun.addColorStop(1, "rgba(255,250,214,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = 0; i < 5; i++) {
    const x0 = 120 + i * 210;
    const beam = ctx.createLinearGradient(x0, 100, x0 + 330, 760);
    beam.addColorStop(0, "rgba(255,246,190,0.055)");
    beam.addColorStop(1, "rgba(255,246,190,0)");
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(x0, 100);
    ctx.lineTo(x0 + 70, 100);
    ctx.lineTo(x0 + 470, 780);
    ctx.lineTo(x0 + 280, 780);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  return bg;
}

/** soft shadow of a cloud drifting over the meadow */
export function buildCloudShadow() {
  const cv = document.createElement("canvas");
  cv.width = 520;
  cv.height = 300;
  const ctx = cv.getContext("2d")!;
  const rnd = mulberry32(99);
  for (let i = 0; i < 9; i++) {
    const x = 120 + rnd() * 280;
    const y = 90 + rnd() * 120;
    const r = 60 + rnd() * 70;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, "rgba(20,60,40,0.075)");
    g.addColorStop(1, "rgba(20,60,40,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 520, 300);
  }
  return cv;
}

export interface SkySprites {
  clouds: HTMLCanvasElement[];
  /** pre-rendered radial flash (cheaper than a gradient per particle) */
  flash: HTMLCanvasElement;
}

export function buildSkySprites(): SkySprites {
  const clouds: HTMLCanvasElement[] = [];
  for (let v = 0; v < 3; v++) {
    const cv = document.createElement("canvas");
    cv.width = 240;
    cv.height = 100;
    const ctx = cv.getContext("2d")!;
    const rnd = mulberry32(41 + v * 7);
    const blobs: [number, number, number][] = [];
    const n = 6 + v;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      blobs.push([40 + t * 160 + (rnd() - 0.5) * 16, 62 - Math.sin(t * Math.PI) * (16 + rnd() * 14), 18 + Math.sin(t * Math.PI) * 14 + rnd() * 6]);
    }
    blobs.forEach(([x, y, r]) => circle(ctx, x + 2, y + 5, r, "#cfe6fb"));
    blobs.forEach(([x, y, r]) => circle(ctx, x, y, r, "#ffffff"));
    // flat belly
    ctx.globalCompositeOperation = "destination-out";
    ctx.fillRect(0, 76, 240, 30);
    ctx.globalCompositeOperation = "source-over";
    clouds.push(cv);
  }
  const flash = document.createElement("canvas");
  flash.width = 64;
  flash.height = 64;
  const fc = flash.getContext("2d")!;
  const g = fc.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, "rgba(255,255,240,1)");
  g.addColorStop(0.5, "rgba(255,220,120,0.6)");
  g.addColorStop(1, "rgba(255,200,100,0)");
  fc.fillStyle = g;
  fc.fillRect(0, 0, 64, 64);
  return { clouds, flash };
}

const WING = ["#ffe066", "#ffffff", "#ff9ec4", "#8fd0ff", "#ffb347"];

/** everything in the landscape that moves; cheap enough to run every frame */
export function drawSkyLife(ctx: Ctx, t: number, sky: SkySprites) {
  // fair-weather clouds sailing over the mountains
  for (let i = 0; i < 6; i++) {
    const s = 0.36 + (i % 3) * 0.1;
    const x = ((i * 331 + t * (5 + i * 1.7)) % (W + 420)) - 320;
    const y = 1 + ((i * 7) % 12);
    ctx.globalAlpha = 0.96;
    ctx.drawImage(sky.clouds[i % 3], x, y, 240 * s, 100 * s);
  }
  ctx.globalAlpha = 1;

  // windmill tower on the hill
  ctx.fillStyle = "#fff4dd";
  ctx.beginPath();
  ctx.moveTo(MILL.x - 7, HILL_Y + 6);
  ctx.lineTo(MILL.x - 4.5, MILL.y - 2);
  ctx.lineTo(MILL.x + 4.5, MILL.y - 2);
  ctx.lineTo(MILL.x + 7, HILL_Y + 6);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#e6d5b2";
  ctx.beginPath();
  ctx.moveTo(MILL.x + 1, MILL.y - 2);
  ctx.lineTo(MILL.x + 4.5, MILL.y - 2);
  ctx.lineTo(MILL.x + 7, HILL_Y + 6);
  ctx.lineTo(MILL.x + 2, HILL_Y + 6);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#d9463e";
  ctx.beginPath();
  ctx.moveTo(MILL.x - 6.5, MILL.y - 2);
  ctx.lineTo(MILL.x, MILL.y - 10);
  ctx.lineTo(MILL.x + 6.5, MILL.y - 2);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#7a5230";
  ctx.fillRect(MILL.x - 1.5, HILL_Y, 3, 6);

  // windmill sails
  ctx.save();
  ctx.translate(MILL.x, MILL.y);
  ctx.rotate(t * 0.8);
  for (let i = 0; i < 4; i++) {
    ctx.rotate(Math.PI / 2);
    ctx.strokeStyle = "#6b4a2c";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -17);
    ctx.stroke();
    ctx.fillStyle = "#fffaf0";
    ctx.fillRect(0.8, -17, 4.6, 12);
    ctx.strokeStyle = "rgba(107,74,44,0.45)";
    ctx.lineWidth = 0.6;
    ctx.strokeRect(0.8, -17, 4.6, 12);
  }
  ctx.restore();
  ctx.fillStyle = "#6b4a2c";
  ctx.beginPath();
  ctx.arc(MILL.x, MILL.y, 1.7, 0, Math.PI * 2);
  ctx.fill();

  // sunlight glittering on the lake
  ctx.strokeStyle = "#ffffff";
  ctx.lineCap = "round";
  for (let i = 0; i < 30; i++) {
    const a = Math.sin(t * (1.4 + (i % 5) * 0.45) + i * 1.7);
    if (a < 0.5) continue;
    const x = (i * 197.3) % W;
    const y = LAKE_TOP + 5 + ((i * 53.7) % (LAKE_BOT - LAKE_TOP - 10));
    const k = (a - 0.5) * 2;
    ctx.globalAlpha = k;
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(x - 3.5 * k, y);
    ctx.lineTo(x + 3.5 * k, y);
    ctx.moveTo(x, y - 2 * k);
    ctx.lineTo(x, y + 2 * k);
    ctx.stroke();
  }

  // a breath of wind running through the grass
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 1.6;
  for (let i = 0; i < 6; i++) {
    const p = ((t * 0.09 + i * 0.173) % 1 + 1) % 1;
    const x = -150 + p * (W + 300);
    const y = 170 + ((i * 101) % 540) + Math.sin(t * 0.7 + i) * 18;
    ctx.globalAlpha = 0.13 * Math.sin(p * Math.PI);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + 34, y - 7, x + 76, y - 1);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;

  // butterflies over the flowers
  for (let i = 0; i < 8; i++) {
    const hx = 250 + ((i * 331) % 1100);
    const hy = 165 + ((i * 173) % 540);
    const x = hx + Math.sin(t * 0.5 + i * 2.1) * 46 + Math.sin(t * 1.3 + i) * 14;
    const y = hy + Math.cos(t * 0.4 + i * 1.3) * 26 + Math.sin(t * 2.2 + i) * 5;
    const flap = Math.abs(Math.sin(t * 13 + i * 2));
    ctx.fillStyle = "rgba(30,70,20,0.16)";
    ctx.beginPath();
    ctx.ellipse(x + 1, y + 9, 2.4, 0.9, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = WING[i % WING.length];
    ctx.beginPath();
    ctx.ellipse(x - 1.6 * flap - 0.4, y, 2.2 * flap + 0.4, 2.4, -0.3, 0, Math.PI * 2);
    ctx.ellipse(x + 1.6 * flap + 0.4, y, 2.2 * flap + 0.4, 2.4, 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#3b2a1a";
    ctx.fillRect(x - 0.4, y - 1.6, 0.8, 3.2);
  }
}
