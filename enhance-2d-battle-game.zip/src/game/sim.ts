/**
 * Battle simulation: squad brains, soldier AI, ragdoll physics, collisions, projectiles.
 *
 * Rules of behaviour
 *  - nobody runs while the local fight can still be won; a fallback is one short, bounded
 *    regroup next to friends (never back to the castle), then the squad fights on
 *  - every troop type has its own craft:
 *      sword    blocks, ripostes, shield-bashes; raises shields under arrow fire
 *      spear    sets a pike wall that stops a charge dead; thrust reaches the second rank
 *      archer   volleys, aimed shots; slips behind friendly infantry when rushed
 *      cavalry  momentum charge: rides THROUGH swords/archers or sends them flying,
 *               wheels around for a fresh charge when bogged down
 *      guard    shield wall: shrugs off arrows, absorbs a charge, bashes
 *      axe      shock troop: ignores shields, sweeping blows, frenzy after a kill
 *      xbow     heavy shot that punches through two men; hunts cavalry and armour
 *      harcher  shoots on the move, circles the enemy and never lets infantry catch it
 *  - every death and every throw is a ragdoll: bodies arc, bounce, skid and settle
 */
import { CANNON_DEF, CASTLE, COUNTER, FIELD_BOTTOM, FIELD_TOP, GOLD_MAX, HERO_DEFS, KILL_BOUNTY, MATCH_TIME, PHASE_AT, SIEGE_MULT, SIEGE_SECONDS, W, ZONES } from "./constants";
import type { Particle, Rag, Squad, Unit } from "./types";
import type { Game } from "./engine";
import { sfx } from "./audio";

export const CELL = 40;
export const GCOLS = Math.ceil(W / CELL);
export const GROWS = Math.ceil(900 / CELL);

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
type Pt = { x: number; y: number };

export const counterMult = (atk: string, def: string) => COUNTER[atk]?.[def] ?? 1;
/** how much of a hand weapon's / an arrow's damage gets through castle walls */
const WALL_VS_BLADE = 0.45;
const WALL_VS_ARROW = 0.5;
const RAG_MAX = 46;

/** foot soldiers a galloping horse goes straight through */
const passable = (o: Unit) => o.trampleT > 0 || o.type === "sword" || o.type === "archer" || o.type === "xbow" || o.type === "axe";
const airborne = (o: Unit) => o.rag !== null && !o.rag.grounded;

function compact<T>(a: T[], keep: (v: T) => boolean) {
  let j = 0;
  for (let i = 0; i < a.length; i++) {
    const v = a[i];
    if (keep(v)) a[j++] = v;
  }
  a.length = j;
}
const alive = (u: Unit) => !u.dead;

/* ------------------------------------------------------------------ */
/*  spatial grid                                                      */
/* ------------------------------------------------------------------ */
function buildGrid(g: Game) {
  for (const cell of g.grid) cell.length = 0;
  for (const u of g.units) {
    if (u.dead || u.spawnT < 0) continue;
    const cx = clamp(Math.floor(u.x / CELL), 0, GCOLS - 1);
    const cy = clamp(Math.floor(u.y / CELL), 0, GROWS - 1);
    g.grid[cy * GCOLS + cx].push(u);
  }
}
function near(g: Game, x: number, y: number, r: number, fn: (o: Unit) => void) {
  const c0 = clamp(Math.floor((x - r) / CELL), 0, GCOLS - 1);
  const c1 = clamp(Math.floor((x + r) / CELL), 0, GCOLS - 1);
  const r0 = clamp(Math.floor((y - r) / CELL), 0, GROWS - 1);
  const r1 = clamp(Math.floor((y + r) / CELL), 0, GROWS - 1);
  for (let gy = r0; gy <= r1; gy++) {
    for (let gx = c0; gx <= c1; gx++) {
      const cell = g.grid[gy * GCOLS + gx];
      for (let i = 0; i < cell.length; i++) fn(cell[i]);
    }
  }
}

/* ------------------------------------------------------------------ */
/*  effect helpers                                                    */
/* ------------------------------------------------------------------ */
function fx(g: Game, x: number, y: number, z: number, vx: number, vy: number, vz: number, kind: Particle["kind"], color: string, life: number, size: number) {
  // in a huge melee the small stuff is thinned out so the frame rate stays smooth
  if (g.particles.length > 380 && (kind === "spark" || kind === "blood" || kind === "dust") && Math.random() < 0.65) return null;
  return g.addP(x, y, z, vx, vy, vz, kind, color, life, size);
}
function sparks(g: Game, x: number, y: number, z: number, n: number, nx: number, color = "#fff4d6") {
  for (let i = 0; i < n; i++) fx(g, x, y, z, rand(-60, 60) + nx * 50, rand(-28, 28), rand(30, 95), "spark", color, rand(0.18, 0.3), 2);
}
/** flat shock-wave on the ground; rgb is "r,g,b" */
function shock(g: Game, x: number, y: number, size: number, rgb = "255,255,255") {
  fx(g, x, y, 0, 0, 0, 0, "shock", rgb, 0.36, size);
}
function streaks(g: Game, x: number, y: number, n: number, color: string, speed = 170) {
  for (let i = 0; i < n; i++) {
    const a = rand(0, Math.PI * 2);
    fx(g, x, y, 7, Math.cos(a) * speed, Math.sin(a) * speed * 0.5, 0, "streak", color, rand(0.14, 0.24), rand(5, 9));
  }
}
const SHOUT_AT = [-9, -9];
function shout(g: Game, sq: Squad, text: string, size = 16) {
  if (sq.shoutT > 0) return;
  // not every squad yells at the same moment: one clear shout per side at a time
  if (g.time < SHOUT_AT[sq.team]) SHOUT_AT[sq.team] = -9;
  if (g.time - SHOUT_AT[sq.team] < 0.9) return;
  SHOUT_AT[sq.team] = g.time;
  sq.shoutT = 3;
  g.text(sq.cx, sq.cy - 44, text, sq.team === 0 ? "#fff3d6" : "#e3ecff", 1.2, size);
}
function bleed(g: Game, x: number, y: number, z: number, n: number, dirX: number, power = 1) {
  if (!g.blood) return;
  for (let i = 0; i < n; i++) {
    fx(g, x, y, z, (rand(-35, 35) + dirX * 45) * power, rand(-18, 18) * power, rand(40, 110) * power, "blood", Math.random() < 0.5 ? "#c42828" : "#9e1b1b", 1.2, rand(1, 2));
  }
}

/* ------------------------------------------------------------------ */
/*  ragdolls                                                          */
/* ------------------------------------------------------------------ */
function newRag(g: Game, u: Unit, vx: number, vy: number, up: number, living: boolean, horse = false): Rag {
  const sgn = vx >= 0 ? 1 : -1;
  const r: Rag = {
    x: u.x,
    y: u.y,
    z: u.mounted && !horse ? 7 : horse ? 4 : 1,
    vx,
    vy,
    vz: up,
    ang: 0,
    w: sgn * rand(5, 10) * (horse ? 0.4 : 1) * (0.45 + Math.min(1, up / 150)),
    lie: 0,
    l0: 0,
    l1: 0,
    l2: 0,
    l3: 0,
    v0: rand(-12, 12),
    v1: rand(-12, 12),
    v2: rand(-8, 8),
    v3: rand(-8, 8),
    t: 0,
    rest: 0,
    grounded: false,
    bounces: 0,
    look: u.look,
    facing: u.facing,
    scale: u.scale,
    horse,
    unit: living ? u : null,
    up: 0,
    done: false,
  };
  g.rags.push(r);
  if (g.rags.length > RAG_MAX) {
    // too many bodies in the air: the oldest dead one drops straight to the ground
    for (const o of g.rags) {
      if (!o.unit && !o.done) {
        o.done = true;
        o.z = 0;
        o.ang = o.w >= 0 ? Math.PI / 2 : -Math.PI / 2;
        g.corpses.push(o);
        break;
      }
    }
  }
  return r;
}

/** throw a living soldier through the air */
function fling(g: Game, u: Unit, vx: number, vy: number, up: number) {
  if (u.mounted || u.type === "hero" || u.type === "cannon") {
    // too heavy to fly: staggered and shoved instead
    u.kvx += vx;
    u.kvy += vy;
    u.stunT = Math.max(u.stunT, 0.35);
    return;
  }
  const r = u.rag;
  if (r) {
    r.vx += vx * 0.5;
    r.vy += vy * 0.5;
    if (r.grounded) {
      r.grounded = false;
      r.vz = up * 0.6;
      r.rest = 0;
      r.up = 0;
    }
    return;
  }
  u.rag = newRag(g, u, vx, vy, up, true);
  u.target = null;
  u.mom = 0;
  u.kvx = 0;
  u.kvy = 0;
}

function stepRags(g: Game, dt: number) {
  for (const r of g.rags) {
    if (r.done) continue;
    r.t += dt;
    if (!r.grounded) {
      r.vz -= 640 * dt;
      r.z += r.vz * dt;
      r.x += r.vx * dt;
      r.y += r.vy * dt;
      r.ang += r.w * dt;
      if (r.z <= 0) {
        r.z = 0;
        const hard = -r.vz;
        if (hard > 70 && r.bounces < 2) {
          // bounce: the body loses most of its energy and its limbs get a kick
          r.vz = hard * 0.3;
          r.vx *= 0.6;
          r.vy *= 0.6;
          r.w = r.w * 0.5 + rand(-2.5, 2.5);
          r.bounces++;
          r.v0 += rand(-14, 14);
          r.v1 += rand(-14, 14);
          r.v2 += rand(-10, 10);
          r.v3 += rand(-10, 10);
          g.dust(r.x, r.y, 3, 26);
          sfx.land(r.x, Math.min(1.3, hard / 150));
          if (hard > 130) g.shake = Math.max(g.shake, 1.2);
        } else {
          r.grounded = true;
          r.vz = 0;
          r.lie = Math.round((r.ang - Math.PI / 2) / Math.PI) * Math.PI + Math.PI / 2;
          g.dust(r.x, r.y, 2, 20);
          if (hard > 30) sfx.land(r.x, 0.6);
        }
      }
    } else {
      // skid to a halt and roll flat
      const f = Math.exp(-6.5 * dt);
      r.vx *= f;
      r.vy *= f;
      r.x += r.vx * dt;
      r.y += r.vy * dt;
      const d = r.lie - r.ang;
      r.w += (d * 70 - r.w * 11) * dt;
      r.ang += r.w * dt;
      const sp = Math.hypot(r.vx, r.vy);
      if (sp > 22 && Math.random() < dt * 14) g.dust(r.x, r.y, 1, 10);
      if (sp < 6 && Math.abs(d) < 0.15) r.rest += dt;
    }
    r.x = clamp(r.x, 14, W - 14);
    r.y = clamp(r.y, FIELD_TOP, FIELD_BOTTOM);
    // limp limbs trail the spin and flop when it changes
    const tg = clamp(-r.w * 0.11, -1.4, 1.4);
    const k = r.grounded ? 46 : 60;
    const cd = r.grounded ? 9 : 5;
    r.v0 += ((tg + 0.5 - r.l0) * k - r.v0 * cd) * dt;
    r.l0 += r.v0 * dt;
    r.v1 += ((tg - 0.6 - r.l1) * k - r.v1 * cd) * dt;
    r.l1 += r.v1 * dt;
    r.v2 += ((tg * 0.7 + 0.35 - r.l2) * k - r.v2 * cd) * dt;
    r.l2 += r.v2 * dt;
    r.v3 += ((tg * 0.7 - 0.35 - r.l3) * k - r.v3 * cd) * dt;
    r.l3 += r.v3 * dt;
    const u = r.unit;
    if (u) {
      if (u.dead) r.unit = null; // finished off on the ground: the body stays where it lies
      else {
        u.x = r.x;
        u.y = r.y;
        if (r.up > 0 || r.rest > 0.32) {
          // scrambles back on his feet
          if (r.up === 0) r.lie = Math.round(r.ang / (Math.PI * 2)) * Math.PI * 2;
          r.up += dt / 0.32;
          if (r.up >= 1) {
            u.rag = null;
            u.stunT = Math.max(u.stunT, 0.12);
            u.vx = 0;
            u.vy = 0;
            r.done = true;
          }
        }
      }
    } else if (r.rest > 0.3 || r.t > 4) {
      r.done = true;
      g.corpses.push(r);
    }
  }
  compact(g.rags, (r) => !r.done);
  if (g.corpses.length > 70) g.corpses.splice(0, g.corpses.length - 70);
}

/* ------------------------------------------------------------------ */
/*  combat primitives                                                 */
/* ------------------------------------------------------------------ */
export function castleDist(u: Pt, team: number) {
  const C = CASTLE[team];
  const nx = clamp(u.x, C.cx - C.hw, C.cx + C.hw);
  const ny = clamp(u.y, C.top + 60, C.baseY);
  return { d: Math.hypot(u.x - nx, u.y - ny), nx, ny };
}

const MELEE = 1;
const ARROW = 2;
const NOBLOCK = 4;
const HEAVY = 8;
const FLING = 16;
/** velocity for a FLING hit (set right before calling damage) */
const LV = { vx: 0, vy: 0, up: 0 };

/** returns true when the blow was blocked */
function damage(g: Game, t: Unit, dmg: number, fromX: number, fromY: number, kb = 30, flags = 0): boolean {
  if (t.dead) return false;
  // a formation ordered to hold its ground is harder to break
  const stance = t.squad.order;
  if (stance !== null && stance.kind === "hold" && t.squad.state === "march") dmg *= 0.85;
  // a hero's armour turns ordinary arrows; heavy bolts and bullets still punch through
  if (t.hero && flags & ARROW && !(flags & HEAVY)) dmg *= 0.6;
  const dx = t.x - fromX;
  const dy = t.y - fromY;
  const d = Math.hypot(dx, dy) || 1;
  const nx = dx / d;
  const ny = dy / d;
  let blocked = false;
  if (!(flags & NOBLOCK) && t.stunT <= 0 && !t.rag) {
    let chance = 0;
    if (flags & MELEE) chance = t.blockM;
    else if (flags & ARROW) {
      chance = nx * t.facing < 0 ? t.blockA : t.blockA * 0.25;
      if (t.braceT > 0 && chance > 0.25) chance = Math.min(0.9, chance + 0.3); // shields raised
      if (flags & HEAVY) chance *= 0.45;
    }
    if (chance > 0 && Math.random() < chance) {
      blocked = true;
      dmg *= flags & ARROW ? 0.15 : 0.4;
      kb *= 0.4;
      sparks(g, t.x - nx * 3, t.y, 7 * t.scale, 3, -nx, "#ffe9a0");
      if (flags & ARROW) sfx.arrowBlock(t.x);
      else sfx.block(t.x);
      // a good block opens the enemy up: the riposte comes faster
      if (t.type === "sword") t.cdT = Math.min(t.cdT, 0.22);
    }
  }
  t.hp -= dmg;
  t.hitT = 1;
  t.showHpT = 1.6;
  const kr = t.type === "hero" ? 0.35 : t.type === "cannon" ? 0 : t.braceT > 0 ? 0.3 : 1;
  t.kvx += nx * kb * kr;
  t.kvy += ny * kb * kr * 0.6;
  sparks(g, t.x, t.y, 8 * t.scale, blocked ? 1 : 2, nx);
  if (flags & MELEE && !blocked) {
    const p = fx(g, t.x - nx * 2, t.y, 8 * t.scale, 0, 0, 0, "slash", "#ffffff", 0.18, 9 * t.scale);
    if (p) p.rot = Math.atan2(dy, dx) + rand(-0.6, 0.6);
  }
  if (t.type === "cannon") {
    for (let i = 0; i < 3; i++) fx(g, t.x, t.y, 6, rand(-50, 50), rand(-20, 20), rand(40, 90), "debris", "#7a5230", 0.9, 2);
  } else if (!blocked) bleed(g, t.x, t.y, 8 * t.scale, 2, nx, 1);
  if (t.hp <= 0) {
    // the killing blow throws the body
    if (flags & FLING) kill(g, t, LV.vx, LV.vy, LV.up);
    else if (flags & HEAVY) kill(g, t, nx * 75, ny * 40, rand(80, 110));
    else if (flags & ARROW) kill(g, t, nx * 24, ny * 12, rand(40, 62));
    else kill(g, t, nx * (kb * 0.45 + 18), ny * (kb * 0.3 + 8), rand(56, 96));
  } else if (flags & FLING) fling(g, t, LV.vx, LV.vy, LV.up);
  return blocked;
}

function explode(g: Game, x: number, y: number, team: number, dmg: number, radius: number) {
  near(g, x, y, radius + 8, (o) => {
    if (o.dead || o.team === team || o.spawnT < 0 || dmg <= 0) return;
    const dx = o.x - x;
    const dy = (o.y - y) * 1.3;
    const d = Math.hypot(dx, dy);
    if (d > radius) return;
    const k = 1 - (d / radius) * 0.6;
    const mult = counterMult("cannon", o.type) * (o.hero ? 0.6 : 1);
    const nx = dx / (d || 1);
    const ny = (o.y - y) / (d || 1);
    LV.vx = nx * rand(30, 70) * k;
    LV.vy = ny * rand(16, 40) * k;
    LV.up = rand(115, 175) * k;
    damage(g, o, dmg * k * mult, x, y, 60 * k, NOBLOCK | FLING);
    if (team === 0) g.stats.flung++;
  });
  g.decals.push({ x, y, r: 9, t: 0, kind: "crater", seed: Math.random() });
  for (let i = 0; i < 12; i++) fx(g, x, y, 2, rand(-120, 120), rand(-60, 60), rand(80, 220), "dirt", Math.random() < 0.5 ? "#6b5232" : "#8a6c44", rand(0.8, 1.4), rand(1.5, 3.2));
  for (let i = 0; i < 6; i++) fx(g, x + rand(-10, 10), y + rand(-5, 5), rand(4, 20), rand(-25, 25), rand(-10, 10), rand(10, 40), "smoke", "", rand(1.2, 2), rand(8, 14));
  for (let i = 0; i < 7; i++) fx(g, x + rand(-8, 8), y + rand(-4, 4), rand(4, 14), rand(-45, 45), rand(-18, 18), rand(50, 120), "ember", "", rand(0.6, 1.2), rand(1.2, 2.4));
  fx(g, x, y, 6, 0, 0, 0, "flash", "#fff3c0", 0.22, radius * 0.95);
  shock(g, x, y, radius * 1.7, "255,236,190");
  streaks(g, x, y, 6, "#ffe9b0", 230);
  g.shake = Math.max(g.shake, 6.5);
  sfx.explosion(x);
}

/** a naphtha pot shatters: everything in a small circle burns (shields do not help) */
function fireBurst(g: Game, x: number, y: number, team: number, dmg: number, radius: number) {
  near(g, x, y, radius + 6, (o) => {
    if (o.dead || o.team === team || o.spawnT < 0) return;
    const dx = o.x - x;
    const dy = (o.y - y) * 1.3;
    const d = Math.hypot(dx, dy);
    if (d > radius) return;
    o.squad.arrowT = 2.5;
    damage(g, o, dmg * (1 - (d / radius) * 0.5) * counterMult("xbow", o.type), x, y, 14, NOBLOCK);
  });
  for (let i = 0; i < 7; i++) fx(g, x + rand(-radius, radius) * 0.6, y + rand(-radius, radius) * 0.3, rand(2, 10), rand(-14, 14), rand(-6, 6), rand(20, 50), "fire", "", rand(0.35, 0.7), rand(3, 5.5));
  for (let i = 0; i < 5; i++) fx(g, x, y, 6, rand(-50, 50), rand(-20, 20), rand(50, 110), "ember", "", rand(0.5, 1), rand(1.2, 2.2));
  for (let i = 0; i < 3; i++) fx(g, x + rand(-8, 8), y, rand(8, 18), rand(-12, 12), 0, rand(14, 30), "smoke", "", rand(0.9, 1.5), rand(5, 8));
  fx(g, x, y, 5, 0, 0, 0, "flash", "#ffd08a", 0.18, radius * 0.8);
  shock(g, x, y, radius * 1.3, "255,170,70");
  g.decals.push({ x, y, r: 4.5, t: 0, kind: "crater", seed: Math.random() });
  g.shake = Math.max(g.shake, 1.6);
  sfx.firepot(x);
}

function kill(g: Game, u: Unit, vx = 0, vy = 0, up = 60) {
  if (u.dead) return;
  u.dead = true;
  const f = g.fac[u.team];
  if (u.type === "cannon") {
    explode(g, u.x, u.y, u.team, 0, 1);
    for (let i = 0; i < 6; i++) fx(g, u.x, u.y, 8, rand(-70, 70), rand(-30, 30), rand(60, 150), "debris", "#7a5230", 1.2, rand(2, 3.5));
  } else if (u.rag) {
    // finished off while down or in the air: the body keeps its own momentum
    u.rag.unit = null;
    u.rag.vx += vx * 0.4;
    u.rag.vy += vy * 0.4;
  } else {
    newRag(g, u, vx + rand(-12, 12), vy + rand(-8, 8), up, false);
    if (u.mounted) newRag(g, u, vx * 0.45 + rand(-14, 14), vy * 0.45, up * 0.4 + 34, false, true);
  }
  u.rag = null;
  if (u.type !== "cannon") {
    // helmet and shield fly off
    fx(g, u.x, u.y, 13 * u.scale, vx * 0.4 + rand(-40, 40), rand(-20, 20), rand(80, 130), "gear", "#cfd6de", 1.5, 2.4 * u.scale);
    if (u.blockA > 0.1 && Math.random() < 0.6) fx(g, u.x, u.y, 8 * u.scale, vx * 0.5 + rand(-50, 50), rand(-25, 25), rand(60, 110), "gear", f.main, 1.6, 3 * u.scale);
    if (g.blood) {
      bleed(g, u.x, u.y, 9 * u.scale, 4, u.facing * -1, 1.2);
      g.decals.push({ x: u.x + rand(-2, 2), y: u.y + 1, r: (u.mounted ? 9 : 6) * u.scale, t: 0, kind: "pool", seed: Math.random() });
    }
  }
  if (g.decals.length > 120) g.decals.splice(0, g.decals.length - 120);
  sfx.die(u.x);
  if (u.team === 1) g.stats.kills++;
  else g.stats.lost++;
  if (u.hero) {
    g.shake = Math.max(g.shake, 8);
    g.text(u.x, u.y - 44, HERO_DEFS[u.hero].name + " gugur!", "#ffffff", 1.8, 18);
    shock(g, u.x, u.y, 60);
  }
  // war spoils for the side that scored the kill
  const k = 1 - u.team;
  g.gold[k] = Math.min(GOLD_MAX, g.gold[k] + (KILL_BOUNTY + g.fac[k].bounty) * (u.hero ? 25 : 1));
}

function finish(g: Game, won: boolean, reason: Game["endReason"]) {
  g.endReason = reason;
  g.state = won ? "won" : "lost";
  g.endT = 0;
  g.drawing = null;
  g.pendingHero = null;
  g.pendingCannon = false;
  if (won) sfx.win();
  else sfx.lose();
  for (const u of g.units) {
    u.target = null;
    if (u.team === (won ? 0 : 1)) u.cheerT = rand(0.6, 1.4);
  }
  g.events.push({ type: "end" });
}

/** siege = a cannon ball: it goes through the walls, the masonry limit does not apply */
function hitCastle(g: Game, team: number, dmg: number, x: number, y: number, siege = false) {
  const c = g.castles[team];
  if (c.hp <= 0 || g.state !== "playing" || g.tut) return;
  dmg *= SIEGE_MULT[g.phase];
  // thick walls: only so much masonry comes down per second, however many are hacking at it
  if (!siege) {
    const full = Math.min(dmg, Math.max(0, c.guard));
    c.guard -= full;
    dmg = full + (dmg - full) * 0.04;
  }
  c.hp = Math.max(0, c.hp - dmg);
  // feedback scales with the damage that really got through
  const heavy = Math.min(1, dmg / 8);
  c.sv += 0.9 * heavy;
  if (c.flash < -0.3 && heavy > 0.25) c.flash = 0.07;
  if (Math.random() < 0.3 + heavy * 0.6) fx(g, x, y, rand(5, 30), rand(-60, 60), rand(-30, 30), rand(40, 110), "debris", Math.random() < 0.5 ? "#c3bcad" : "#8a8377", 1.1, rand(1.5, 3));
  g.shake = Math.max(g.shake, (team === 0 ? 2.4 : 1.4) * heavy);
  sfx.castle(x);
  if (c.hp <= 0) castleDestroyed(g, team);
}

function castleDestroyed(g: Game, team: number) {
  const C = CASTLE[team];
  g.shake = 20;
  g.hitStop = 0.08;
  for (let i = 0; i < 70; i++) {
    fx(g, C.cx + rand(-80, 80), C.baseY - rand(0, 30), rand(10, 140), rand(-160, 160), rand(-80, 80), rand(60, 260), "debris", ["#c3bcad", "#8a8377", g.fac[team].main][i % 3], rand(1.5, 2.6), rand(2, 5));
  }
  for (let i = 0; i < 22; i++) fx(g, C.cx + rand(-80, 80), C.baseY - rand(0, 40), rand(10, 100), rand(-30, 30), rand(-15, 15), rand(10, 40), "smoke", "", rand(1.5, 3), rand(10, 22));
  shock(g, C.cx, C.baseY - 20, 230, "255,240,210");
  sfx.castleFall(C.cx);
  finish(g, team === 1, "castle");
}

/** time is up: the sturdier castle wins, then kills, then the bigger army */
function timeUp(g: Game) {
  const a = g.castles[0].hp / g.castles[0].max;
  const b = g.castles[1].hp / g.castles[1].max;
  if (Math.abs(a - b) > 0.0002) return finish(g, a > b, "hp");
  if (g.stats.kills !== g.stats.lost) return finish(g, g.stats.kills > g.stats.lost, "kills");
  const c = g.counts();
  finish(g, c[0] >= c[1], "army");
}

/* ------------------------------------------------------------------ */
/*  attacks                                                           */
/* ------------------------------------------------------------------ */
function meleeHit(g: Game, u: Unit, t: Unit) {
  const sq = u.squad;
  let dmg = u.atk * rand(0.85, 1.15) * counterMult(u.type, t.type);
  let kb = 34;
  let flags = MELEE;
  u.combo++;
  if (t.target !== null && t.target !== u && !t.rag && t.type !== "cannon" && (u.x - t.x) * t.facing < -4) {
    // struck from behind while busy with someone else: no shield, no guard
    dmg *= 1.35;
    flags |= NOBLOCK;
    if (Math.random() < 0.4) fx(g, t.x, t.y - 2, 13 * t.scale, 0, 0, 30, "star", "#ff9a5a", 0.4, 2.6);
    if (Math.random() < 0.2) shout(g, sq, "Serang dari belakang!");
  }
  if (!u.hero && Math.random() < u.crit) {
    // a perfect cut
    dmg *= 1.8;
    kb += 30;
    sparks(g, t.x, t.y, 9 * t.scale, 4, u.facing, "#fff1a8");
    fx(g, t.x, t.y - 2, 14 * t.scale, 0, 0, 30, "star", "#ffe36b", 0.45, 3.2);
  }
  if (u.charger && u.mom > 0.3) {
    // the weight of the horse behind the blade
    dmg *= 1 + u.mom * 0.8;
    kb += 90 * u.mom;
    g.dust(t.x, t.y, 3, 40);
    u.mom *= 0.4;
  }
  if (!u.charged && sq.charging) {
    // first clash of a charge
    u.charged = true;
    dmg *= 1.4;
    kb = Math.max(kb, 85);
    g.dust(t.x, t.y, 3, 45);
    fx(g, t.x, t.y, 6, 0, 0, 0, "flash", "#ffffff", 0.14, 11);
    g.shake = Math.max(g.shake, 2.2);
    sfx.impact(t.x);
  }
  let stun = 0;
  if ((u.type === "sword" && u.combo % 4 === 0) || (u.type === "guard" && u.combo % 3 === 0)) {
    // shield bash: staggers the enemy and breaks his guard
    stun = t.type === "hero" ? 0.12 : u.type === "guard" ? 0.55 : 0.42;
    kb += 70;
    dmg *= 1.15;
    flags |= NOBLOCK;
    shock(g, t.x, t.y, 15);
    sfx.bash(t.x);
  }
  if (u.type === "axe") flags |= NOBLOCK; // shields are split, not respected
  damage(g, t, dmg, u.x, u.y, kb, flags);
  if (stun > 0 && !t.dead) t.stunT = Math.max(t.stunT, stun);
  // weapon trail in the faction colour
  const tr = fx(g, u.x + u.facing * 5, u.y, 9 * u.scale, 0, 0, 0, "slash", g.fac[u.team].light, 0.16, (u.hero ? 13 : 8) * u.scale);
  if (tr) tr.rot = u.facing > 0 ? rand(-0.4, 0.4) : Math.PI + rand(-0.4, 0.4);

  if (u.type === "spear") {
    // the thrust carries through to the man behind
    const dx = t.x - u.x;
    const dy = t.y - u.y;
    const d = Math.hypot(dx, dy) || 1;
    const px = t.x + (dx / d) * 11;
    const py = t.y + (dy / d) * 11;
    const b = { u: null as Unit | null, d: 121 };
    near(g, px, py, 12, (o) => {
      if (o === t || o.dead || o.team === u.team || airborne(o)) return;
      const dd = (o.x - px) ** 2 + (o.y - py) ** 2;
      if (dd < b.d) {
        b.d = dd;
        b.u = o;
      }
    });
    if (b.u) damage(g, b.u, dmg * 0.5, u.x, u.y, 18, MELEE);
  } else if (u.type === "axe") {
    // sweeping blow: up to two more men beside the target
    let n = 0;
    const long = u.range > 15; // a naginata reaches further and catches three
    const sr = long ? 15 : 11;
    near(g, t.x, t.y, sr, (o) => {
      if (n >= (long ? 3 : 2) || o === t || o.dead || o.team === u.team || airborne(o)) return;
      if ((o.x - t.x) ** 2 + (o.y - t.y) ** 2 > sr * sr) return;
      n++;
      damage(g, o, dmg * 0.5, u.x, u.y, 26, MELEE | NOBLOCK);
    });
    if (t.dead) {
      u.cdT *= 0.35; // frenzy: a kill feeds the next blow
      if (u.berserk) {
        // the berserker's rage closes his wounds
        u.hp = Math.min(u.maxHp, u.hp + u.maxHp * 0.25);
        u.showHpT = 1.2;
        fx(g, u.x, u.y - 2, 16 * u.scale, 0, 0, 26, "star", "#8fe08a", 0.5, 2.6);
      }
    }
  }
  if (u.cleave > 0) {
    const r = u.cleave;
    near(g, t.x, t.y, r, (o) => {
      if (o === t || o.dead || o.team === u.team) return;
      const dx = o.x - t.x;
      const dy = o.y - t.y;
      if (dx * dx + dy * dy >= r * r) return;
      const toss = !o.rag && Math.random() < 0.35;
      if (toss) {
        LV.vx = dx * 2.2 + rand(-14, 14);
        LV.vy = dy * 1.4;
        LV.up = rand(90, 130);
        if (u.team === 0) g.stats.flung++;
      }
      damage(g, o, dmg * 0.6, u.x, u.y, 60, toss ? MELEE | FLING : MELEE);
    });
    shock(g, t.x, t.y, r * 1.5, "255,236,170");
    g.dust(t.x, t.y, 3, 40);
    g.shake = Math.max(g.shake, 2.2);
  }
  const cls = u.look.wp.cls;
  if (u.hero || u.type === "axe") sfx.heavy(u.x);
  else if (cls === "pole") sfx.spear(u.x);
  else sfx.sword(u.x);
}

function shoot(g: Game, u: Unit, tx: number, ty: number, target: Unit | null, castle: number) {
  const d = Math.hypot(tx - u.x, ty - u.y);
  const fire = u.look.wp.cls === "pot"; // a lobbed pot of burning naphtha
  const heavy = u.type === "xbow" && !fire;
  const dur = fire ? 0.55 + d / 430 : heavy ? 0.14 + d / 760 : 0.42 + d / 520;
  const lead = target && target.stunT <= 0 && !target.rag ? dur * 0.9 : 0;
  const ex = tx + (target ? target.vx * lead : 0) + rand(-4, 4);
  const ey = ty + (target ? target.vy * lead : 0) + rand(-3, 3);
  const crit = !u.hero && !!target && Math.random() < u.crit;
  g.projectiles.push({
    x0: u.x + u.facing * 4,
    y0: u.y,
    x1: ex,
    y1: ey,
    t: 0,
    dur,
    arc: fire ? 34 + d * 0.3 : heavy ? 5 + d * 0.03 : 24 + d * 0.3,
    z0: (u.mounted ? 15 : 9) * u.scale,
    team: u.team,
    dmg: u.atk * rand(0.85, 1.15) * (crit ? 2.2 : 1),
    target,
    castle,
    big: !!u.hero || heavy,
    atkType: u.hero ? "hero" : u.type,
    ball: false,
    crit,
    heavy,
    fire,
  });
  const cls = u.look.wp.cls;
  if (cls === "gun") {
    sfx.gun(u.x);
    const mx = u.x + u.facing * 14;
    fx(g, mx, u.y, 9 * u.scale, 0, 0, 0, "flash", "#fff0a0", 0.1, 7);
    for (let i = 0; i < 2; i++) fx(g, mx, u.y, 10, u.facing * rand(12, 40), rand(-8, 8), rand(6, 18), "smoke", "", rand(0.7, 1.2), rand(3.5, 6));
  } else if (cls === "xbow") sfx.xbow(u.x);
  else if (cls === "pot") sfx.toss(u.x);
  else sfx.bow(u.x);
}

function fireCannon(g: Game, u: Unit, tx: number, ty: number, castle: number) {
  const d = Math.hypot(tx - u.x, ty - u.y);
  g.projectiles.push({
    x0: u.x + u.facing * 14,
    y0: u.y,
    x1: tx + rand(-12, 12),
    y1: ty + rand(-7, 7),
    t: 0,
    dur: 0.85 + d / 520,
    arc: 60 + d * 0.35,
    z0: 14,
    team: u.team,
    dmg: CANNON_DEF.atk * rand(0.9, 1.1),
    target: null,
    castle,
    big: true,
    atkType: "cannon",
    ball: true,
    crit: false,
    heavy: false,
    fire: false,
  });
  u.recoil = 1;
  const mx = u.x + u.facing * 18;
  fx(g, mx, u.y, 14, 0, 0, 0, "flash", "#fff0a0", 0.12, 10);
  for (let i = 0; i < 5; i++) fx(g, mx, u.y, 14, u.facing * rand(20, 70), rand(-15, 15), rand(5, 20), "smoke", "", rand(0.9, 1.5), rand(5, 9));
  g.shake = Math.max(g.shake, 3);
  sfx.cannon(u.x);
}

/** the gunners aim for the middle of the crowd, leading its movement */
function clusterAim(g: Game, u: Unit, t: Unit): Pt {
  let sx = t.x;
  let sy = t.y;
  let n = 1;
  near(g, t.x, t.y, 46, (o) => {
    if (o === t || o.dead || o.team === u.team) return;
    if ((o.x - t.x) ** 2 + (o.y - t.y) ** 2 < 46 * 46) {
      sx += o.x;
      sy += o.y;
      n++;
    }
  });
  return { x: sx / n + t.vx * 0.8, y: sy / n + t.vy * 0.8 };
}

/** pick the smartest target in sight, not just the nearest */
function findTarget(g: Game, u: Unit, lx = 0, ly = 0, lr2 = Infinity): Unit | null {
  const r = u.aggro;
  const cur = u.target;
  // ordered to destroy one formation: its men come first
  const focus = u.squad.order !== null && u.squad.order.kind === "attack" ? u.squad.order.target : null;
  const b = { u: null as Unit | null, s: Infinity };
  near(g, u.x, u.y, r, (o) => {
    if (o.team === u.team || o.dead || airborne(o)) return;
    if (lr2 !== Infinity && (o.x - lx) ** 2 + (o.y - ly) ** 2 > lr2) return; // outside the ground we are guarding
    const dx = o.x - u.x;
    const dy = (o.y - u.y) * 1.15;
    const d2 = dx * dx + dy * dy;
    if (d2 > r * r) return;
    let s = Math.sqrt(d2);
    if (counterMult(u.type, o.type) >= 1.3) s *= 0.74; // go for the prey you beat
    if (u.charger && (o.type === "spear" || o.type === "guard")) s *= u.mom > 0.4 ? 2.0 : 1.3; // don't ride onto pikes
    if (u.ranged) {
      s *= 0.8 + 0.2 * (o.hp / o.maxHp); // finish the wounded
      if (o.type === "guard" && u.type !== "xbow") s *= 1.5; // don't waste arrows on a shield wall
      if (u.skirmish && !o.ranged && s < 110) s *= 0.5; // watch whoever is closing in
      // spread the volley: no more arrows at one man than it takes to bring him down
      // (one arrow to spare for men with shields, who turn some of them aside)
      const spare = o.aimed - (o === cur ? 1 : 0) - Math.ceil(o.hp / (u.atk * counterMult(u.type, o.type))) - (o.blockA > 0.1 ? 1 : 0);
      if (spare >= 0) s += 26 + spare * 10;
    } else {
      s += Math.max(0, o.attackers - 2) * 9; // spread out and surround
      if (o.stunT > 0 || o.rag) s *= 0.85; // punish the fallen
    }
    if (focus !== null && o.squad === focus) s *= 0.6;
    if (o === cur) s *= 0.75; // commit
    if (s < b.s) {
      b.s = s;
      b.u = o;
    }
  });
  return b.u;
}

/* ------------------------------------------------------------------ */
/*  cavalry charge: tembus (ride through) / terpental (sent flying)    */
/* ------------------------------------------------------------------ */
function resolveCharge(g: Game, u: Unit, o: Unit, ix: number, iy: number) {
  const sq = u.squad;
  const power = u.mom;
  o.trampleT = 0.75;
  if (!sq.crashed) {
    // the first crash of the whole wedge
    sq.crashed = true;
    shock(g, o.x, o.y, 44, "255,244,214");
    streaks(g, o.x, o.y, 7, "#fff6da", 200);
    fx(g, o.x, o.y, 8, 0, 0, 0, "flash", "#ffffff", 0.16, 18);
    g.shake = Math.max(g.shake, 5.5);
    sfx.charge(o.x);
    g.text(o.x, o.y - 36, "BRAAK!", "#fff1c9", 0.8, 19);
  }
  g.dust(o.x, o.y, 4, 50);
  const base = u.atk * (1.15 + power) * counterMult(u.type, o.type) * rand(0.9, 1.1);
  const mxp = (u.x + o.x) / 2;
  const myp = (u.y + o.y) / 2;

  // --- pikes: the charge dies on a spear wall
  if (o.type === "spear" && o.stunT <= 0 && !o.rag && (o.squad.braceT > 0 || o.facing * ix < 0)) {
    const dmg = o.atk * 2.1 * counterMult("spear", u.type) * (0.75 + power * 0.5);
    o.atkT = 1;
    o.braceT = 1;
    sparks(g, mxp, myp, 10, 5, -ix, "#ffe9a0");
    sfx.impale(o.x);
    shout(g, o.squad, "Tertahan!");
    damage(g, o, u.atk * 0.45, u.x, u.y, 22, MELEE);
    u.mom = 0;
    u.stunT = Math.max(u.stunT, 0.45);
    u.kvx = -ix * 95;
    u.kvy = -iy * 60;
    u.vx = 0;
    u.vy = 0;
    damage(g, u, dmg, o.x, o.y, 0, MELEE | NOBLOCK);
    g.shake = Math.max(g.shake, 3);
    return;
  }
  // --- shield wall: the horse is stopped but nobody is impaled
  if (o.type === "guard" && o.stunT <= 0 && !o.rag && (o.braceT > 0 || o.facing * ix < 0)) {
    damage(g, o, base * 0.4, u.x, u.y, 70, MELEE | NOBLOCK);
    u.mom *= 0.2;
    u.stunT = Math.max(u.stunT, 0.25);
    u.kvx = -ix * 60;
    u.kvy = -iy * 40;
    sparks(g, mxp, myp, 10, 5, -ix, "#ffe9a0");
    sfx.bash(o.x);
    shout(g, o.squad, "Tembok perisai!");
    return;
  }
  if (o.type === "hero") {
    damage(g, o, base * 0.8, u.x, u.y, 40, MELEE);
    u.mom = 0;
    u.kvx = -ix * 60;
    u.kvy = -iy * 40;
    sparks(g, mxp, myp, 10, 5, -ix);
    sfx.clang(o.x, true);
    return;
  }
  if (o.mounted) {
    // horse against horse
    damage(g, o, base * 0.75, u.x, u.y, 70, MELEE);
    if (o.mom > 0.45 && !u.dead) {
      damage(g, u, o.atk * (1.15 + o.mom) * 0.75, o.x, o.y, 70, MELEE);
      o.mom *= 0.25;
    }
    u.mom *= 0.25;
    sparks(g, mxp, myp, 11, 6, 0);
    sfx.clang(o.x, true);
    g.shake = Math.max(g.shake, 2.6);
    return;
  }
  if (o.type === "cannon") {
    damage(g, o, base, u.x, u.y, 0, MELEE);
    u.mom *= 0.35;
    sfx.bash(o.x);
    return;
  }
  // --- foot soldiers without pikes or a shield wall are ridden down
  const side = -iy * (o.x - u.x) + ix * (o.y - u.y) >= 0 ? 1 : -1;
  const lethal = o.hp <= base;
  if (lethal || Math.random() < 0.5 + power * 0.3) {
    // TERPENTAL: a short, heavy throw along the line of the charge
    const p = 0.65 + power * 0.45;
    LV.vx = ix * rand(45, 85) * p - iy * side * rand(8, 30);
    LV.vy = iy * rand(30, 60) * p + ix * side * rand(8, 24);
    LV.up = rand(120, 170) * (0.7 + power * 0.35);
    damage(g, o, base, u.x, u.y, 0, MELEE | NOBLOCK | FLING);
    streaks(g, o.x, o.y, 2, "#ffffff", 140);
    if (u.team === 0) g.stats.flung++;
    u.mom *= 0.84;
  } else {
    // TEMBUS: shouldered aside while the horse ploughs on through the line
    const blocked = damage(g, o, base, u.x, u.y, 0, o.type === "sword" ? MELEE : MELEE | NOBLOCK);
    o.kvx += -iy * side * rand(70, 110) + ix * 30;
    o.kvy += ix * side * rand(45, 70) + iy * 18;
    o.stunT = Math.max(o.stunT, blocked ? 0.3 : 0.55);
    u.mom *= blocked ? 0.8 : 0.9;
  }
  sfx.trample(o.x);
  g.shake = Math.max(g.shake, 2);
}

function chargeContacts(g: Game, u: Unit, sp: number) {
  const ix = u.vx / sp;
  const iy = u.vy / sp;
  near(g, u.x + ix * 4, u.y + iy * 4, u.radius + 16, (o) => {
    if (u.dead || u.mom <= 0.45) return;
    if (o.team === u.team || o.dead || o.trampleT > 0 || o.rag || o.spawnT < 0.3) return;
    const dx = o.x - u.x;
    const dy = (o.y - u.y) * 1.3;
    const rr = u.radius + o.radius + 2.5;
    if (dx * dx + dy * dy > rr * rr) return;
    if (dx * ix + dy * iy < -2) return; // already behind the horse
    resolveCharge(g, u, o, ix, iy);
  });
}

/* ------------------------------------------------------------------ */
/*  squad brain                                                       */
/* ------------------------------------------------------------------ */
const isCharger = (sq: Squad) => sq.type === "cavalry" || (!!sq.hero && !!HERO_DEFS[sq.hero].mounted && !HERO_DEFS[sq.hero].ranged);
const isSkirmish = (sq: Squad) => sq.type === "harcher" || sq.hero === "zahir";
const isRanged = (sq: Squad) => sq.type === "archer" || sq.type === "xbow" || sq.type === "cannon" || (!!sq.hero && !!HERO_DEFS[sq.hero].ranged);

function startCharge(g: Game, sq: Squad, mounted: boolean) {
  sq.charging = true;
  sq.crashed = false;
  for (const u of sq.units) u.charged = false;
  sfx.battleCry(sq.team, sq.cx);
  if (mounted) {
    sfx.gallop(sq.cx);
    sfx.neigh(sq.cx);
  }
  shout(g, sq, sq.team === 0 ? "Serbuuu!" : "Hyaaa!");
}

function startFallback(g: Game, sq: Squad, rx: number, ry: number, wheel: boolean, label: string) {
  sq.state = "fallback";
  sq.fallT = 0;
  sq.rallyX = rx;
  sq.rallyY = ry;
  sq.wheel = wheel;
  sq.charging = false;
  sq.stuckT = 0;
  sq.shoutT = 0;
  for (const u of sq.units) {
    u.target = null;
    u.mom = 0;
  }
  shout(g, sq, label);
}

function endFallback(g: Game, sq: Squad) {
  sq.state = "march";
  sq.fallCd = sq.wheel ? 4.5 : 10;
  sq.launchT = 1;
  sq.thinkT = 0;
  // re-form right where the men stand: nobody walks back to an old slot
  sq.anchorX = sq.cx - sq.mox;
  sq.anchorY = sq.cy - sq.moy;
  sq.shoutT = 0;
  if (sq.wheel) startCharge(g, sq, true);
  else {
    sq.regrouped = true; // one regroup per squad; after that it fights to the last man
    shout(g, sq, "Formasi ulang!");
  }
}

/** a friendly squad that can shelter / reinforce us */
function findSupport(g: Game, sq: Squad, wantMelee: boolean, maxD: number): Squad | null {
  const dir = sq.team === 0 ? 1 : -1;
  let best: Squad | null = null;
  let bd = maxD;
  for (const s of g.squads) {
    if (s === sq || s.team !== sq.team || s.dead || s.state === "fallback") continue;
    if (s.type !== "hero" && s.alive < 6) continue;
    if (wantMelee && (isRanged(s) || isSkirmish(s))) continue;
    const behind = (sq.cx - s.cx) * dir; // > 0: s stands behind us
    if (behind < (wantMelee ? -40 : 30)) continue;
    const d = Math.hypot(s.cx - sq.cx, s.cy - sq.cy);
    if (d < bd) {
      bd = d;
      best = s;
    }
  }
  return best;
}

/**
 * Morale. A squad only gives ground when it is hopelessly outmatched right here AND friends
 * are close enough to regroup with. Otherwise it stands and fights.
 */
function considerFallback(g: Game, sq: Squad, charger: boolean, think: number) {
  if (sq.type === "hero" || sq.type === "cannon") return;
  const dir = sq.team === 0 ? 1 : -1;
  const R = 180;
  let own = 0;
  let foe = 0;
  let foeN = 0;
  let closeMelee = 0;
  near(g, sq.cx, sq.cy, R, (o) => {
    if (o.dead || o.spawnT < 0) return;
    const d2 = (o.x - sq.cx) ** 2 + (o.y - sq.cy) ** 2;
    if (d2 > R * R) return;
    const v = o.value * (0.35 + (0.65 * Math.max(0, o.hp)) / o.maxHp);
    if (o.team === sq.team) own += v;
    else {
      foe += v * (0.6 + 0.4 * counterMult(o.type, sq.type));
      foeN++;
      if (!o.ranged && d2 < 110 * 110) closeMelee++;
    }
  });
  if (charger) {
    if (sq.engaged > sq.alive * 0.4 && sq.avgMom < 0.15) sq.stuckT += think;
    else sq.stuckT = Math.max(0, sq.stuckT - think);
  }
  if (sq.fallCd > 0 || foeN === 0) return;
  const ratio = foe / Math.max(0.5, own);
  const e = sq.targetSq;
  const xMin = ZONES[0].x0 + 30;
  const xMax = ZONES[1].x1 - 30;

  // cavalry bogged down in a brawl: ride out, wheel around and charge again
  if (charger) {
    if (sq.stuckT > 1.7 && foeN >= 4 && sq.alive >= 3 && e && !e.dead && e.type !== "spear" && e.type !== "guard") {
      let dx = sq.cx - e.cx;
      let dy = sq.cy - e.cy;
      const d = Math.hypot(dx, dy);
      if (d < 20) {
        dx = -dir;
        dy = 0;
      } else {
        dx /= d;
        dy /= d;
      }
      startFallback(g, sq, clamp(sq.cx + dx * 175, xMin, xMax), clamp(sq.cy + dy * 175, FIELD_TOP + 30, FIELD_BOTTOM - 30), true, "Putar, serbu ulang!");
    }
    return;
  }
  if (g.fac[sq.team].noRetreat) return; // bushido
  // shooters about to be overrun slip behind friendly infantry
  if (sq.type === "archer" || sq.type === "xbow") {
    if (sq.regrouped || closeMelee < 4) return;
    const s = findSupport(g, sq, true, 280);
    if (!s) return;
    const rx = clamp(s.cx - dir * 48, xMin, xMax);
    const ry = clamp(s.cy, FIELD_TOP + 30, FIELD_BOTTOM - 30);
    const d = Math.hypot(rx - sq.cx, ry - sq.cy);
    if (d < 45 || (rx - sq.cx) * dir > 40) return;
    startFallback(g, sq, rx, ry, false, "Berlindung!");
    return;
  }
  // infantry: only a shattered squad facing hopeless odds, with friends close behind
  // (as long as the fight can be won — odds better than 1:3 — nobody takes a step back)
  if (sq.regrouped || sq.alive > sq.initial * 0.3 || ratio < 3.2) return;
  const s = findSupport(g, sq, false, 430);
  if (!s) return; // nowhere to regroup: hold the line to the last man
  let rx = s.cx - dir * 18;
  let ry = s.cy + (sq.cy >= s.cy ? 28 : -28);
  const dx = rx - sq.cx;
  const dy = ry - sq.cy;
  const d = Math.hypot(dx, dy);
  if (d < 45) return;
  if (d > 260) {
    rx = sq.cx + (dx / d) * 260;
    ry = sq.cy + (dy / d) * 260;
  }
  startFallback(g, sq, clamp(rx, xMin, xMax), clamp(ry, FIELD_TOP + 30, FIELD_BOTTOM - 30), false, "Mundur teratur!");
}

/** spearmen set their pikes (and guards lock shields) when horses come thundering in */
function braceCheck(g: Game, sq: Squad) {
  if (sq.engaged > sq.alive * 0.5) return; // pinned in a brawl: cannot re-form the wall
  const h = { found: false, x: 0 };
  near(g, sq.cx, sq.cy, 190, (o) => {
    if (h.found || o.team === sq.team || o.dead || !o.charger) return;
    if ((o.x - sq.cx) ** 2 + (o.y - sq.cy) ** 2 > 190 * 190) return;
    if (o.mom > 0.2 || o.squad.charging) {
      h.found = true;
      h.x = o.x;
    }
  });
  if (!h.found) return;
  if (sq.braceT <= 0) {
    shout(g, sq, sq.type === "spear" ? "Pagar tombak!" : "Rapatkan perisai!");
    sfx.brace(sq.cx);
    for (const u of sq.units) if (!u.dead) u.cdT = Math.min(u.cdT, 0.25);
  }
  sq.braceT = 0.9;
  sq.threatX = h.x;
}

/** squads waiting for the horn spring to arms when the enemy is upon them */
function readyWatch(g: Game, sq: Squad) {
  const h = { foe: false };
  near(g, sq.cx, sq.cy, 175, (o) => {
    if (h.foe || o.team === sq.team || o.dead || o.spawnT < 0.3) return;
    if ((o.x - sq.cx) ** 2 + (o.y - sq.cy) ** 2 < 175 * 175) h.foe = true;
  });
  if (!h.foe) return;
  sq.state = "march";
  sq.launchT = 1;
  sq.thinkT = 0;
  shout(g, sq, "Siaga! Lawan!");
}

function think(g: Game, sq: Squad, dtThink: number) {
  const dir = sq.team === 0 ? 1 : -1;
  const charger = isCharger(sq);
  const skirm = isSkirmish(sq);
  const ranged = isRanged(sq) || skirm;
  const home = CASTLE[sq.team];
  const vision = charger || skirm ? 560 : sq.type === "cannon" ? 600 : ranged ? 470 : 410;
  const underFire = sq.arrowT > 0;

  // --- which enemy formation do we go for?
  let best: Squad | null = null;
  let bs = Infinity;
  let bd = 0;
  for (const e of g.squads) {
    if (e.team === sq.team || e.dead || e.alive === 0) continue;
    const d = Math.hypot(e.cx - sq.cx, e.cy - sq.cy);
    const homeThreat = Math.abs(e.cx - home.cx) < 320;
    if (d > vision && !(homeThreat && d < 820)) continue;
    let s = d;
    s /= 0.55 + 0.45 * counterMult(sq.type, e.type); // favour the match-ups we win
    s *= 0.7 + 0.3 * counterMult(e.type, sq.type); // be wary of the ones we lose
    const soft = isRanged(e);
    if (charger) {
      if (soft || e.type === "harcher") s *= 0.55; // run down the shooters
      else if (e.type === "spear" || e.type === "guard") s *= e.engaged > e.alive * 0.4 ? 1.05 : 2.3; // only hit a wall that is pinned
    }
    if (underFire && !ranged && soft) s *= 0.6; // being shot at: close with the shooters
    if (sq.type === "guard" && soft) s *= 0.8; // the shield wall walks into the arrows
    if (homeThreat) s *= 0.6; // defend the castle
    if (e === sq.targetSq) s *= 0.85; // stay committed
    if (s < bs) {
      bs = s;
      best = e;
      bd = d;
    }
  }
  // ---- the commander's orders come before the squad's own judgement
  let o = sq.order;
  if (o && o.kind === "attack") {
    const e = o.target;
    if (!e || e.dead || e.alive === 0) sq.order = o = null; // done: think for yourself again
    else {
      best = e;
      bd = Math.hypot(e.cx - sq.cx, e.cy - sq.cy);
    }
  }
  if (o && (o.kind === "move" || o.kind === "retreat")) {
    const far = Math.hypot(sq.cx - o.x, sq.cy - o.y);
    const slot = Math.hypot(sq.anchorX + sq.mox - o.x, sq.anchorY + sq.moy - o.y);
    if (far < 40 || (slot < 12 && sq.engaged === 0)) {
      // arrived: guard this ground until told otherwise
      o.kind = "hold";
      shout(g, sq, "Siap di posisi!");
    }
  }
  sq.targetSq = best;

  if (!ranged) {
    // a squad that holds only counter-charges what comes at its post; one that retreats never charges
    const may = !o || o.kind === "attack" || o.kind === "move" || (o.kind === "hold" && best !== null && Math.hypot(best.cx - o.x, best.cy - o.y) < 200);
    if (best && may && bd < (charger ? 320 : 235) && !sq.charging) startCharge(g, sq, charger);
    else if ((!best || !may) && sq.engaged === 0) sq.charging = false;
  }
  if (sq.type === "spear" || sq.type === "guard") braceCheck(g, sq);

  // --- where should the formation go?
  const reach = (sq.units[0]?.range ?? 200) * (skirm ? 0.9 : 0.82);
  if (o && o.kind !== "attack") {
    sq.goalX = o.x;
    sq.goalY = o.y;
  } else if (best) {
    if (ranged) {
      // close to shooting distance and hold there (horse archers do their dance man by man)
      if (bd > reach) {
        sq.goalX = sq.cx + ((best.cx - sq.cx) / bd) * (bd - reach);
        sq.goalY = sq.cy + ((best.cy - sq.cy) / bd) * (bd - reach);
      } else {
        sq.goalX = sq.cx;
        sq.goalY = sq.cy;
      }
    } else {
      sq.goalX = best.cx;
      sq.goalY = best.cy;
    }
  } else {
    // nothing in the way: on to the castle, converging on its walls
    const C = CASTLE[1 - sq.team];
    const gx = C.cx - dir * (C.hw + (ranged ? reach * 0.95 : 16));
    const fy = sq.anchorY + sq.moy;
    sq.goalX = gx;
    sq.goalY = Math.abs(gx - sq.cx) < 480 ? clamp(fy, C.top + 100, C.baseY + 25) : fy;
  }
  if (skirm) {
    // the circle turns now and then so the riders do not run out of field
    sq.orbitT -= dtThink;
    if (sq.orbitT <= 0 || (sq.cy < FIELD_TOP + 70 && sq.orbit * dir < 0) || (sq.cy > FIELD_BOTTOM - 70 && sq.orbit * dir > 0)) {
      sq.orbit = -sq.orbit;
      sq.orbitT = rand(3, 5);
    }
    return;
  }
  if (!o) considerFallback(g, sq, charger, dtThink); // under orders the commander decides when to fall back
}

function moveAnchor(sq: Squad, dt: number) {
  const fast = sq.type === "cavalry" || sq.type === "harcher" || (!!sq.hero && !!HERO_DEFS[sq.hero].mounted);
  const fx0 = sq.anchorX + sq.mox;
  const fy0 = sq.anchorY + sq.moy;
  const o = sq.order;
  const pinned = o !== null && (o.kind === "hold" || o.kind === "retreat"); // the post / the rally point does not wander
  if (!pinned && sq.engaged / sq.alive > 0.25) {
    // in the thick of it the formation follows the fight, so nobody trots back afterwards
    const k = Math.min(1, dt * 3);
    sq.anchorX += (sq.cx - fx0) * k;
    sq.anchorY += (sq.cy - fy0) * k;
  } else {
    const gx = sq.goalX - fx0;
    const gy = sq.goalY - fy0;
    const gd = Math.hypot(gx, gy);
    if (gd > 4) {
      const ramp = Math.min(1, 0.6 + sq.launchT * 0.5);
      const spd = sq.speed * 0.92 * ramp * (o !== null && o.kind === "retreat" ? 1.5 : 1) * (sq.charging ? 1.6 : 1) * (sq.arrowT > 0 && (sq.type === "sword" || sq.type === "guard") ? 0.88 : 1);
      const step = Math.min(gd, spd * dt);
      sq.anchorX += (gx / gd) * step;
      sq.anchorY += (gy / gd) * step;
    }
    // the banner never outruns the men
    const lx = sq.anchorX + sq.mox - sq.cx;
    const ly = sq.anchorY + sq.moy - sq.cy;
    const ld = Math.hypot(lx, ly);
    const leash = fast ? 60 : 38;
    if (ld > leash) {
      sq.anchorX = sq.cx - sq.mox + (lx / ld) * leash;
      sq.anchorY = sq.cy - sq.moy + (ly / ld) * leash;
    }
  }
  const cx = clamp(sq.anchorX + sq.mox, CASTLE[0].cx + 50, CASTLE[1].cx - 50);
  const cy = clamp(sq.anchorY + sq.moy, FIELD_TOP + 12, FIELD_BOTTOM - 12);
  sq.anchorX = cx - sq.mox;
  sq.anchorY = cy - sq.moy;
}

function updateSquads(g: Game, dt: number) {
  const ended = g.state === "won" || g.state === "lost";
  // pass 1: head-count and centre of every squad
  for (const sq of g.squads) {
    sq.spawnT += dt;
    let n = 0;
    let engaged = 0;
    let sx = 0;
    let sy = 0;
    let ox = 0;
    let oy = 0;
    let mom = 0;
    for (const u of sq.units) {
      if (u.dead) continue;
      n++;
      sx += u.x;
      sy += u.y;
      ox += u.offX;
      oy += u.offY;
      mom += u.mom;
      if (u.target || u.attackingCastle) engaged++;
    }
    sq.alive = n;
    sq.engaged = engaged;
    if (n === 0) {
      if (!sq.dead) {
        sq.dead = true;
        sq.deadT = 0;
      }
      sq.deadT += dt;
      continue;
    }
    sq.cx = sx / n;
    sq.cy = sy / n;
    sq.mox = ox / n;
    sq.moy = oy / n;
    sq.avgMom = mom / n;
  }
  // pass 2: decisions
  for (const sq of g.squads) {
    if (sq.alive === 0) continue;
    const dir = sq.team === 0 ? 1 : -1;
    sq.fallCd = Math.max(0, sq.fallCd - dt);
    sq.braceT = Math.max(0, sq.braceT - dt);
    sq.shoutT = Math.max(0, sq.shoutT - dt);
    sq.arrowT = Math.max(0, sq.arrowT - dt);
    sq.thinkT -= dt;
    if (!ended) {
      if (sq.state === "ready") {
        if (sq.thinkT <= 0) {
          sq.thinkT = 0.3;
          if (sq.type === "spear" || sq.type === "guard") braceCheck(g, sq);
          if (g.state === "playing") readyWatch(g, sq);
        }
      } else if (sq.state === "march") {
        sq.launchT += dt;
        sq.walk += dt * 11;
        if (sq.thinkT <= 0) {
          const iv = rand(0.22, 0.34);
          sq.thinkT = iv;
          think(g, sq, iv);
        }
        if (sq.state === "march") moveAnchor(sq, dt);
      } else {
        // short tactical regroup
        sq.fallT += dt;
        sq.walk += dt * 13;
        const tx = sq.rallyX - sq.mox - sq.anchorX;
        const ty = sq.rallyY - sq.moy - sq.anchorY;
        const td = Math.hypot(tx, ty);
        if (td > 2) {
          const step = Math.min(td, sq.speed * 1.45 * dt);
          sq.anchorX += (tx / td) * step;
          sq.anchorY += (ty / td) * step;
        }
        const far = Math.hypot(sq.cx - sq.rallyX, sq.cy - sq.rallyY);
        if (far < 34 || sq.fallT > (sq.wheel ? 2.6 : 3.6)) endFallback(g, sq);
      }
    }
    // archer volleys
    if (sq.type === "archer") {
      sq.volleyCd -= dt;
      if (sq.volleyWant && sq.volleyCd <= 0 && sq.state !== "fallback") {
        sq.volleyCd = (sq.units[0]?.cd ?? 1.4) * rand(0.95, 1.1);
        sfx.volley(sq.cx);
        for (const u of sq.units) {
          if (u.dead || !u.target) continue;
          const d = Math.hypot(u.target.x - u.x, u.target.y - u.y);
          if (d <= u.range + 4) u.shootDelay = rand(0, 0.22);
        }
      }
      sq.volleyWant = false;
    }
    const bx = sq.cx - dir * 4;
    const by = sq.cy + 1;
    sq.bannerX += (bx - sq.bannerX) * Math.min(1, dt * 4);
    sq.bannerY += (by - sq.bannerY) * Math.min(1, dt * 4);
  }
  compact(g.squads, (s) => !(s.dead && s.deadT > 2.6));
}

/* ------------------------------------------------------------------ */
/*  soldiers                                                          */
/* ------------------------------------------------------------------ */
function updateUnits(g: Game, dt: number) {
  const ended = g.state === "won" || g.state === "lost";
  const winner = g.state === "won" ? 0 : 1;
  const siege = g.state === "playing";
  let fighting = 0;
  for (const u of g.units) {
    u.attackers = 0;
    u.aimed = 0;
  }
  for (const u of g.units) {
    const t = u.target;
    if (u.dead || !t) continue;
    fighting++;
    if (t.dead) continue;
    if (u.ranged) t.aimed++;
    else t.attackers++;
  }
  const want = Math.min(1, fighting / 70) * (g.state === "playing" ? 1 : 0.35);
  g.intensity += (want - g.intensity) * Math.min(1, dt * 2);

  for (const u of g.units) {
    if (u.dead) continue;
    if (u.spawnT < 0) {
      u.spawnT += dt;
      if (u.spawnT >= 0) {
        sfx.pop(u.x);
        g.dust(u.x, u.y, 2, 20);
      }
      continue;
    }
    u.spawnT += dt;
    u.cdT -= dt;
    u.hitT = Math.max(0, u.hitT - dt * 4.5);
    u.atkT = Math.max(0, u.atkT - dt * (u.type === "xbow" ? 1.1 : 3.2));
    u.showHpT = Math.max(0, u.showHpT - dt);
    if (u.cheerT > 0) u.cheerT = Math.max(0, u.cheerT - dt * 2.2);
    u.recoil = Math.max(0, u.recoil - dt * 2.5);
    u.stunT = Math.max(0, u.stunT - dt);
    u.trampleT = Math.max(0, u.trampleT - dt);
    u.braceT = Math.max(0, u.braceT - dt * 1.6);
    if (u.rag) continue; // the ragdoll owns the body
    if (u.spawnT < 0.3) continue;

    const sq = u.squad;
    const dir = u.team === 0 ? 1 : -1;
    let mx = 0;
    let my = 0;
    let spd = u.speed;
    let synced = false;
    u.attackingCastle = false;

    if (ended) {
      // the battle is decided: winners cheer
      u.target = null;
      u.mom = 0;
      if (u.team === winner && u.cheerT <= 0 && Math.random() < dt * 1.6) u.cheerT = 1;
    } else if (u.stunT > 0) {
      u.mom = 0;
    } else if (sq.state === "fallback" || (sq.state === "march" && sq.order !== null && sq.order.kind === "retreat")) {
      // run to the rally slot (a regroup, or the commander's order to retreat), then face the enemy again
      u.target = null;
      const dx = sq.anchorX + u.offX - u.x;
      const dy = sq.anchorY + u.offY - u.y;
      const d = Math.hypot(dx, dy);
      if (d > 3) {
        mx = dx / d;
        my = dy / d;
        spd *= 1.42;
        u.facing = dx >= 0 ? 1 : -1;
      } else u.facing = dir;
    } else {
      u.retarget -= dt;
      let t = u.target;
      if (t && (t.dead || airborne(t) || (t.x - u.x) ** 2 + (t.y - u.y) ** 2 > (u.aggro * 1.5) ** 2)) t = u.target = null;
      // ordered to hold: guard the post, fight what comes close, never chase
      const post = sq.order !== null && sq.order.kind === "hold" && sq.state === "march" ? sq.order : null;
      if (post && t && (u.ranged ? (t.x - u.x) ** 2 + (t.y - u.y) ** 2 > (u.range + 40) ** 2 : (t.x - post.x) ** 2 + (t.y - post.y) ** 2 > 190 * 190)) t = u.target = null;
      if (u.retarget <= 0) {
        u.retarget = rand(0.16, 0.3);
        const n = !post ? findTarget(g, u) : u.ranged ? findTarget(g, u, u.x, u.y, (u.range + 12) ** 2) : findTarget(g, u, post.x, post.y, 150 * 150);
        // squads waiting for the horn only defend themselves (shooters may shoot)
        if (n && sq.state === "ready" && !u.ranged && Math.hypot(n.x - u.x, n.y - u.y) > 70) u.target = null;
        else if (n) u.target = n;
        t = u.target;
      }
      if (sq.braceT > 0 && (u.type === "spear" || u.type === "guard")) u.braceT = 1;
      const cdMul = u.berserk && u.hp < u.maxHp * 0.5 ? 0.72 : 1;

      if (t) {
        const dx = t.x - u.x;
        const dy = t.y - u.y;
        const d = Math.hypot(dx, dy) || 1;
        u.facing = dx >= 0 ? 1 : -1;
        const reach = u.range + (u.ranged ? 0 : t.radius + u.radius * 0.5);
        if (u.skirmish) {
          // horse archer: keep the distance, keep moving, keep shooting
          if (!t.ranged && d < 105) {
            // someone is closing in: ride away, but never off the field or past our own lines
            mx = -dx / d;
            my = -dy / d;
            const back = u.team === 0 ? u.x - (ZONES[0].x0 + 20) : ZONES[1].x1 - 20 - u.x;
            if (back < 40 && mx * dir < 0) {
              mx = 0;
              my = (u.y - t.y >= 0 ? 1 : -1) * (u.y < FIELD_TOP + 60 ? -1 : u.y > FIELD_BOTTOM - 60 ? -1 : 1);
              if (u.y < FIELD_TOP + 60) my = 1;
              else if (u.y > FIELD_BOTTOM - 60) my = -1;
            }
            spd *= 1.12;
          } else if (d > u.range * 0.94) {
            mx = dx / d;
            my = dy / d;
          } else {
            // ride across the enemy's front
            mx = (-dy / d) * sq.orbit;
            my = (dx / d) * sq.orbit;
            if (d < u.range * 0.6) {
              mx -= (dx / d) * 0.6;
              my -= (dy / d) * 0.6;
            }
            spd *= 0.72;
          }
          if ((u.y < FIELD_TOP + 24 && my < 0) || (u.y > FIELD_BOTTOM - 24 && my > 0)) my = 0;
          if (d <= u.range && u.cdT <= 0) {
            u.cdT = u.cd * rand(0.9, 1.12) * cdMul;
            u.atkT = 1;
            shoot(g, u, t.x, t.y, t, -1);
          }
          if (u.atkT < 0.45 && (mx !== 0 || my !== 0)) u.facing = mx >= 0 ? 1 : -1;
        } else if (u.charger && u.mom > 0.45) {
          // full gallop: do not stop to fence, ride on through the line
          const sp0 = Math.hypot(u.vx, u.vy);
          if (sp0 > 20) {
            const ix = u.vx / sp0;
            const iy = u.vy / sp0;
            const ax = ix * 0.7 + (dx / d) * 0.3;
            const ay = iy * 0.7 + (dy / d) * 0.3;
            const al = Math.hypot(ax, ay) || 1;
            mx = ax / al;
            my = ay / al;
            u.facing = ix >= 0 ? 1 : -1;
            if (ix * dx + iy * dy < 0) u.mom = Math.max(0, u.mom - dt * 3.2); // overshot: rein in and turn
          } else {
            mx = dx / d;
            my = dy / d;
          }
          spd *= 1.6;
        } else if (d > reach) {
          mx = dx / d;
          my = dy / d;
          if (!u.ranged) spd *= sq.charging ? 1.45 : 1.15;
          if (u.braceT > 0 && sq.braceT > 0) spd *= 0.2; // hold the wall
        } else if (u.type === "cannon") {
          if (u.cdT <= 0) {
            u.cdT = u.cd * rand(0.95, 1.1);
            const aim = clusterAim(g, u, t);
            fireCannon(g, u, aim.x, aim.y, -1);
          }
        } else if (u.type === "archer") {
          // volley fire: loose on the squad's command
          sq.volleyWant = true;
          if (u.shootDelay >= 0) {
            u.shootDelay -= dt;
            if (u.shootDelay < 0) {
              u.atkT = 1;
              shoot(g, u, t.x, t.y, t, -1);
              u.shootDelay = -1;
            }
          }
        } else if (u.cdT <= 0) {
          u.cdT = u.cd * rand(0.9, 1.12) * cdMul;
          u.atkT = 1;
          if (u.ranged) {
            shoot(g, u, t.x, t.y, t, -1);
            if (u.hero === "tomoe" && Math.random() < 0.6) shoot(g, u, t.x + rand(-12, 12), t.y + rand(-8, 8), null, -1);
          } else meleeHit(g, u, t);
        }
      } else {
        const enemyTeam = 1 - u.team;
        const cd = castleDist(u, enemyTeam);
        const nearC = siege && sq.state === "march" && g.castles[enemyTeam].hp > 0 && cd.d < (u.ranged ? u.range * 0.97 : 150);
        if (nearC) {
          u.attackingCastle = true;
          const dx = cd.nx - u.x;
          const dy = cd.ny - u.y;
          u.facing = dx >= 0 ? 1 : -1;
          if (cd.d > u.range + 3) {
            mx = dx / (cd.d || 1);
            my = dy / (cd.d || 1);
          } else if (u.cdT <= 0) {
            u.cdT = u.cd * rand(0.9, 1.15) * cdMul;
            if (u.type === "cannon") fireCannon(g, u, cd.nx, cd.ny, enemyTeam);
            else {
              u.atkT = 1;
              if (u.ranged) shoot(g, u, cd.nx + rand(-15, 15), cd.ny - rand(0, 40), null, enemyTeam);
              else {
                // stone walls shrug off blades: heroes and cannons are the real siege tools
                hitCastle(g, enemyTeam, u.atk * (u.hero ? 1.2 : WALL_VS_BLADE), cd.nx, cd.ny);
                if (u.hero) sfx.heavy(u.x);
                else sfx.clang(u.x);
              }
            }
          }
        } else if (u.braceT > 0 && sq.braceT > 0) {
          // weapons down, facing the horses
          u.facing = sq.threatX >= u.x ? 1 : -1;
        } else {
          const dx = sq.anchorX + u.offX - u.x;
          const dy = sq.anchorY + u.offY - u.y;
          const d = Math.hypot(dx, dy);
          if (d > 2.5) {
            mx = dx / d;
            my = dy / d;
            if (d > 25) spd *= 1.3;
            else spd *= Math.max(0.35, d / 25) * 1.1 + 0.2;
            if (sq.charging) spd *= 1.75;
          }
          u.facing = dir;
          if (Math.abs(dx) > 8 && sq.state !== "march") u.facing = dx > 0 ? 1 : -1;
          // arrows are falling: shields up while advancing
          if (sq.arrowT > 0 && u.blockA > 0.3) u.braceT = Math.max(u.braceT, 0.6);
          if (sq.state === "march" && d < 14 && !sq.charging) {
            // lock-step marching
            u.walk = sq.walk + (u.mounted ? (u.seed % 1) * 0.6 : 0);
            synced = true;
          }
        }
      }
    }

    // --- integrate: steering + smooth knock-back impulse
    const k = Math.min(1, dt * 7);
    u.vx += (mx * spd - u.vx) * k;
    u.vy += (my * spd - u.vy) * k;
    u.x += (u.vx + u.kvx) * dt;
    u.y += (u.vy + u.kvy) * dt;
    const damp = Math.exp(-7 * dt);
    u.kvx *= damp;
    u.kvy *= damp;
    const sp = Math.hypot(u.vx, u.vy);
    if (sp > 4) {
      if (!synced) u.walk += dt * (u.mounted ? 11 : 13) * Math.min(1.3, sp / 30 + 0.3);
      if (u.mounted) {
        if (Math.random() < dt * (u.mom > 0.4 ? 8 : 2)) g.dust(u.x - u.facing * 6, u.y, 1, 12);
      } else if (sq.charging && Math.random() < dt * 3) g.dust(u.x - u.facing * 4, u.y, 1, 14);
    }
    if (u.charger) {
      // momentum builds at a gallop and bleeds away when the horse is slowed
      if (sq.charging && sp > u.speed * 0.95 && u.stunT <= 0) u.mom = Math.min(1, u.mom + dt * 1.25);
      else if (sp < u.speed * 0.6) u.mom = Math.max(0, u.mom - dt * 2.2);
      if (u.mom > 0.45 && sp > 30 && !ended) chargeContacts(g, u, sp);
    }
    u.y = clamp(u.y, FIELD_TOP, FIELD_BOTTOM);
    u.x = clamp(u.x, 10, W - 10);
  }
  compact(g.units, alive);
}

function separate(g: Game) {
  buildGrid(g);
  for (const u of g.units) {
    if (u.dead || u.spawnT < 0) continue;
    if (!u.rag) {
      const gx = clamp(Math.floor(u.x / CELL), 0, GCOLS - 1);
      const gy = clamp(Math.floor(u.y / CELL), 0, GROWS - 1);
      for (let yy = Math.max(0, gy - 1); yy <= Math.min(GROWS - 1, gy + 1); yy++) {
        for (let xx = Math.max(0, gx - 1); xx <= Math.min(GCOLS - 1, gx + 1); xx++) {
          const cell = g.grid[yy * GCOLS + xx];
          for (let i = 0; i < cell.length; i++) {
            const o = cell[i];
            if (o.id <= u.id || o.rag) continue;
            // a horse at full gallop goes straight through foot soldiers
            if (u.team !== o.team && ((u.mom > 0.3 && passable(o)) || (o.mom > 0.3 && passable(u)))) continue;
            const dx = o.x - u.x;
            const dy = (o.y - u.y) * 1.5;
            const min = u.radius + o.radius;
            const d2 = dx * dx + dy * dy;
            if (d2 < min * min && d2 > 0.0001) {
              const d = Math.sqrt(d2);
              const push = (min - d) * 0.5;
              const nx = dx / d;
              const ny = dy / d;
              const wu = o.type === "hero" ? 0.85 : u.type === "hero" ? 0.15 : 0.5;
              u.x -= nx * push * wu * 2;
              u.y -= ny * push * wu * 1.2;
              o.x += nx * push * (1 - wu) * 2;
              o.y += ny * push * (1 - wu) * 1.2;
            }
          }
        }
      }
    }
    // nobody is shoved off the field (and so behind the command dock)
    if (u.y > FIELD_BOTTOM) u.y = FIELD_BOTTOM;
    else if (u.y < FIELD_TOP) u.y = FIELD_TOP;
    // castle walls
    for (let t = 0; t < 2; t++) {
      const C = CASTLE[t];
      if (u.x > C.cx - C.hw && u.x < C.cx + C.hw && u.y > C.top + 60 && u.y < C.baseY) {
        const left = u.x - (C.cx - C.hw);
        const right = C.cx + C.hw - u.x;
        const up = u.y - (C.top + 60);
        const down = C.baseY - u.y;
        const m = Math.min(left, right, up, down);
        if (m === left) u.x = C.cx - C.hw;
        else if (m === right) u.x = C.cx + C.hw;
        else if (m === up) u.y = C.top + 60;
        else u.y = C.baseY;
      }
    }
  }
}

/* ------------------------------------------------------------------ */
/*  castles, projectiles, world                                       */
/* ------------------------------------------------------------------ */
function updateCastles(g: Game, dt: number) {
  for (let t = 0; t < 2; t++) {
    const c = g.castles[t];
    const C = CASTLE[t];
    c.sv += (-170 * c.squash - 9 * c.sv) * dt;
    c.squash += c.sv * dt;
    c.flash = Math.max(-1, c.flash - dt);
    if (c.hp <= 0) continue;
    const rate = c.max / SIEGE_SECONDS[g.phase];
    c.guard = Math.min(rate * 0.75, c.guard + rate * dt);
    c.shootCd -= dt;
    if (c.shootCd <= 0 && g.state === "playing" && !g.tut) {
      let best: Unit | null = null;
      let bd = 300 * 300;
      for (const u of g.units) {
        if (u.team === t || u.spawnT < 0 || u.dead) continue;
        const dx = u.x - C.cx;
        const dy = u.y - (C.baseY - 60);
        const d = dx * dx + dy * dy;
        if (d < bd) {
          bd = d;
          best = u;
        }
      }
      if (best) {
        c.shootCd = 0.28;
        const tx = C.cx + (Math.random() < 0.5 ? -62 : 62);
        const d = Math.hypot(best.x - tx, best.y - C.baseY);
        g.projectiles.push({
          x0: tx,
          y0: C.baseY - 10,
          x1: best.x + best.vx * 0.3,
          y1: best.y + best.vy * 0.3,
          t: 0,
          dur: 0.35 + d / 600,
          arc: 30 + d * 0.15,
          z0: 110,
          team: t,
          dmg: 11,
          target: best,
          castle: -1,
          big: false,
          atkType: "castle",
          ball: false,
          crit: false,
          heavy: false,
          fire: false,
        });
        sfx.bow(tx);
      } else c.shootCd = 0.2;
    }
    const frac = c.hp / c.max;
    if (frac < 0.6) {
      c.smokeT -= dt;
      if (c.smokeT <= 0) {
        c.smokeT = frac < 0.3 ? 0.12 : 0.26;
        const sx = C.cx + rand(-60, 60);
        fx(g, sx, C.baseY - rand(5, 20), rand(60, 140), rand(-8, 8), rand(-4, 4), rand(18, 30), "smoke", "", rand(2, 3.2), rand(6, 12));
        if (frac < 0.3) fx(g, sx, C.baseY - 10, rand(60, 110), rand(-5, 5), 0, rand(20, 40), "fire", "", rand(0.4, 0.7), rand(3, 6));
      }
    }
  }
}

function updateProjectiles(g: Game, dt: number) {
  for (const p of g.projectiles) {
    p.t += dt / p.dur;
    if (p.t < 1) continue;
    if (p.fire) {
      fireBurst(g, p.x1, p.y1, p.team, p.dmg, 24);
    } else if (p.ball) {
      if (p.castle >= 0) hitCastle(g, p.castle, p.dmg * CANNON_DEF.castleMult, p.x1, p.y1, true);
      explode(g, p.x1, p.y1, p.team, p.castle >= 0 ? p.dmg * 0.5 : p.dmg, CANNON_DEF.splash);
    } else if (p.castle >= 0) {
      hitCastle(g, p.castle, p.dmg * WALL_VS_ARROW, p.x1, p.y1);
    } else {
      const b = { u: null as Unit | null, d: 64 };
      const tg = p.target;
      if (tg && !tg.dead && !airborne(tg) && Math.hypot(tg.x - p.x1, tg.y - p.y1) < 14 + tg.radius) b.u = tg;
      else {
        near(g, p.x1, p.y1, 9, (u) => {
          if (u.team === p.team || u.dead || airborne(u)) return;
          const d = (u.x - p.x1) ** 2 + (u.y - p.y1) ** 2;
          if (d < b.d) {
            b.d = d;
            b.u = u;
          }
        });
      }
      const hit = b.u;
      if (hit) {
        const cm = p.atkType !== "hero" ? counterMult(p.atkType, hit.type) : 1;
        hit.squad.arrowT = 2.5;
        const blocked = damage(g, hit, p.dmg * cm, p.x0, p.y0, p.big ? 44 : 16, p.heavy ? (g.fac[p.team].id === "samurai" ? ARROW | HEAVY | NOBLOCK : ARROW | HEAVY) : ARROW);
        if (!blocked) {
          sfx.arrowHit(hit.x);
          if (p.crit) fx(g, hit.x, hit.y - 2, 14, 0, 0, 30, "star", "#ffe36b", 0.45, 3.2);
          if (p.heavy) {
            // the bolt goes clean through to the man behind
            const dx = p.x1 - p.x0;
            const dy = p.y1 - p.y0;
            const d = Math.hypot(dx, dy) || 1;
            const qx = hit.x + (dx / d) * 14;
            const qy = hit.y + (dy / d) * 14;
            const s = { u: null as Unit | null, d: 196 };
            near(g, qx, qy, 15, (u) => {
              if (u === hit || u.team === p.team || u.dead || airborne(u)) return;
              const dd = (u.x - qx) ** 2 + (u.y - qy) ** 2;
              if (dd < s.d) {
                s.d = dd;
                s.u = u;
              }
            });
            if (s.u) damage(g, s.u, p.dmg * cm * 0.6, p.x0, p.y0, 30, ARROW | HEAVY);
          }
        }
      } else {
        g.stuck.push({ x: p.x1, y: p.y1, ang: Math.atan2(p.y1 - p.y0, p.x1 - p.x0), t: 0 });
        if (Math.random() < 0.3) sfx.thunk(p.x1);
        if (g.stuck.length > 110) g.stuck.shift();
      }
    }
  }
  compact(g.projectiles, (p) => p.t < 1);
}

function updateWorld(g: Game, dt: number) {
  for (const s of g.stuck) s.t += dt;
  compact(g.stuck, (s) => s.t < 6);
  for (const d of g.decals) d.t += dt;
  compact(g.decals, (d) => d.t < 10);
  compact(g.corpses, (c) => c.rest >= 0);
  if (Math.random() < dt * 1.3) {
    // blossom petals on the breeze
    const col = ["#ffd0e0", "#ffc2d6", "#fff0f5", "#ffe3ee", "#f6e3a0"][Math.floor(Math.random() * 5)];
    g.addP(rand(-40, W), rand(70, 780), rand(30, 80), rand(14, 34), rand(-3, 5), 0, "leaf", col, rand(6, 9), rand(1.5, 2.6));
  }
  g.zoomPunch = Math.max(0, g.zoomPunch - dt * 1.8);

  const ps = g.particles;
  let j = 0;
  for (let i = 0; i < ps.length; i++) {
    const p = ps[i];
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.z += p.vz * dt;
    p.rot += p.vr * dt;
    switch (p.kind) {
      case "blood":
        p.vz -= 380 * dt;
        if (p.z <= 0) {
          p.life = 0;
          if (g.decals.length < 120) g.decals.push({ x: p.x, y: p.y, r: p.size * 1.3, t: 0, kind: "blood", seed: Math.random() });
        }
        break;
      case "dirt":
        p.vz -= 400 * dt;
        if (p.z < 0) {
          p.z = 0;
          p.vz = 0;
          p.vx *= 0.3;
          p.vy *= 0.3;
        }
        break;
      case "leaf":
        p.vx += Math.sin(g.time * 2 + p.rot) * 10 * dt;
        p.vz = Math.sin(g.time * 3 + p.rot) * 6;
        break;
      case "debris":
      case "gear":
      case "spark":
      case "star":
        p.vz -= 320 * dt;
        if (p.z < 0) {
          p.z = 0;
          p.vz = -p.vz * 0.4;
          p.vx *= 0.55;
          p.vy *= 0.55;
          p.vr *= 0.4;
        }
        break;
      case "dust":
      case "streak": {
        const f = 1 - Math.min(1, dt * (p.kind === "dust" ? 3 : 5));
        p.vx *= f;
        p.vy *= f;
        break;
      }
      case "ember":
        p.vz -= 150 * dt;
        p.vx *= 1 - Math.min(1, dt * 1.5);
        if (p.z < 0) {
          p.z = 0;
          p.vz = 0;
        }
        break;
      case "smoke":
      case "fire":
        p.vx += 6 * dt;
        break;
    }
    if (p.life > 0) ps[j++] = p;
    else if (g.pool.length < 400) g.pool.push(p);
  }
  ps.length = j;
  if (ps.length > 600) ps.splice(0, ps.length - 600);

  for (const t of g.texts) t.t += dt;
  compact(g.texts, (t) => t.t < t.max);
  if (g.texts.length > 14) g.texts.splice(0, g.texts.length - 14);

  g.shake = Math.max(0, g.shake - dt * 30);
}

/* ------------------------------------------------------------------ */
/*  match clock                                                       */
/* ------------------------------------------------------------------ */
function updateMatch(g: Game, dt: number) {
  const before = MATCH_TIME - g.matchT;
  g.matchT += dt;
  const left = MATCH_TIME - g.matchT;
  const ph = g.matchT >= PHASE_AT[1] ? 2 : g.matchT >= PHASE_AT[0] ? 1 : 0;
  if (ph !== g.phase) {
    g.phase = ph;
    g.shake = Math.max(g.shake, 6);
    g.zoomPunch = 1;
    sfx.phase(ph);
    g.events.push({ type: "phase" });
  }
  if (left <= 10 && left > 0 && Math.ceil(left) !== Math.ceil(before)) {
    sfx.tick();
    g.events.push({ type: "tick" });
  }
  if (left <= 0) {
    g.matchT = MATCH_TIME;
    timeUp(g);
    return;
  }
  const prev = g.phaseT;
  g.phaseT -= dt;
  if (Math.ceil(g.phaseT) !== Math.ceil(prev) && g.phaseT <= 3 && g.phaseT > 0) {
    sfx.tick();
    g.events.push({ type: "tick" });
  }
  for (const k in g.heroCd) g.heroCd[k] = Math.max(0, g.heroCd[k] - dt);
  g.updateAI(dt);
  if (g.phaseT <= 0) g.launchWave();
  if (g.marchDrumT > 0) {
    const b = g.marchDrumT;
    g.marchDrumT -= dt;
    if (Math.floor(b / 0.5) !== Math.floor(g.marchDrumT / 0.5)) sfx.drum(0.8);
  }
}

export function updateGame(g: Game, rawDt: number) {
  let dt = Math.min(rawDt, 1 / 30);
  if (g.state === "paused") return;
  if (g.hitStop > 0) {
    g.hitStop -= dt;
    dt *= 0.12;
  }
  g.time += dt;
  if (g.state === "playing" && !g.tut) updateMatch(g, dt); // lessons have no clock, no horn timer, no enemy commander
  g.launchFx = Math.max(0, g.launchFx - dt);
  if (g.state === "won" || g.state === "lost") g.endT += dt;

  buildGrid(g);
  updateSquads(g, dt);
  updateUnits(g, dt);
  separate(g);
  stepRags(g, dt);
  compact(g.units, alive);
  updateCastles(g, dt);
  updateProjectiles(g, dt);
  updateWorld(g, dt);

  g.sndT -= dt;
  if (g.sndT <= 0) {
    g.sndT = 0.25;
    sfx.setIntensity(g.intensity);
  }
  // keep the menu backdrop alive
  if (g.state === "menu" && g.units.length < 40) g.spawnDemo();
}
