import type { HeroKind, Team, UnitType } from "./constants";
import type { Look } from "./figure";

/**
 * A tumbling body. Used for soldiers thrown through the air (alive: `unit` is set and the
 * man gets back on his feet) and for every death (dead: it settles and becomes a corpse).
 */
export interface Rag {
  x: number;
  y: number;
  /** height of the hips above the ground */
  z: number;
  vx: number;
  vy: number;
  vz: number;
  /** body angle (0 = upright) and spin */
  ang: number;
  w: number;
  /** angle the body comes to rest at (lying on its back or front) */
  lie: number;
  /** limb angles relative to the body: front arm, back arm, front leg, back leg */
  l0: number;
  l1: number;
  l2: number;
  l3: number;
  v0: number;
  v1: number;
  v2: number;
  v3: number;
  t: number;
  rest: number;
  grounded: boolean;
  bounces: number;
  look: Look;
  facing: number;
  scale: number;
  /** a riderless horse going down */
  horse: boolean;
  unit: Unit | null;
  /** 0..1 while a survivor climbs back on his feet */
  up: number;
  done: boolean;
}

export interface Unit {
  id: number;
  team: Team;
  type: UnitType;
  hero?: HeroKind;
  look: Look;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  atk: number;
  cd: number;
  cdT: number;
  range: number;
  speed: number;
  aggro: number;
  radius: number;
  cleave: number;
  ranged: boolean;
  mounted: boolean;
  /** mounted shock troops build charge momentum */
  charger: boolean;
  /** horse archers: shoot on the move and keep their distance */
  skirmish: boolean;
  facing: number;
  walk: number;
  spawnT: number; // counts up from negative (delay) -> anim
  hitT: number;
  atkT: number;
  showHpT: number;
  target: Unit | null;
  attackingCastle: boolean;
  retarget: number;
  squad: Squad;
  offX: number;
  offY: number;
  dead: boolean;
  scale: number;
  seed: number;
  shootDelay: number;
  cheerT: number;
  charged: boolean;
  recoil: number;
  /** smooth knock-back impulse (px/s), decays quickly */
  kvx: number;
  kvy: number;
  /** thrown through the air: the ragdoll owns the body until he is back on his feet */
  rag: Rag | null;
  /** staggered: cannot move or attack */
  stunT: number;
  /** short immunity after being ridden down, so one horse hits once */
  trampleT: number;
  /** shield / pike set (pose timer) */
  braceT: number;
  /** charge momentum, 0..1 */
  mom: number;
  /** number of melee enemies currently going for this unit */
  attackers: number;
  /** number of enemy shooters currently aiming at this unit */
  aimed: number;
  /** attack counter, drives special moves */
  combo: number;
  /** battle value used for morale maths */
  value: number;
  /** chance to block a melee blow / an arrow from the front */
  blockM: number;
  blockA: number;
  crit: number;
  berserk: boolean;
}

/** an order from the player; a squad without one uses its own judgement */
export interface Order {
  /**
   * move    – advance to the spot, fighting whatever is in the way, then guard it
   * hold    – guard this spot: fight what comes close, never chase
   * attack  – destroy that enemy formation, then think for yourself again
   * retreat – break off and run to the spot, then guard it
   */
  kind: "move" | "hold" | "attack" | "retreat";
  x: number;
  y: number;
  target: Squad | null;
}

export interface Squad {
  id: number;
  team: Team;
  type: UnitType;
  hero?: HeroKind;
  anchorX: number;
  anchorY: number;
  units: Unit[];
  bannerX: number;
  bannerY: number;
  speed: number;
  spawnT: number;
  dead: boolean;
  deadT: number;
  engaged: number;
  alive: number;
  /** ready = waiting for the horn, march = advancing / fighting, fallback = short tactical regroup */
  state: "ready" | "march" | "fallback";
  walk: number;
  volleyCd: number;
  volleyWant: boolean;
  initial: number;
  launchT: number;
  cost: number;
  charging: boolean;
  /** average charge momentum of the riders */
  avgMom: number;
  /* ---- squad brain ---- */
  cx: number;
  cy: number;
  mox: number;
  moy: number;
  goalX: number;
  goalY: number;
  thinkT: number;
  targetSq: Squad | null;
  fallT: number;
  fallCd: number;
  rallyX: number;
  rallyY: number;
  /** the fallback is a cavalry wheel-around for a fresh charge */
  wheel: boolean;
  /** this squad has already used its one regroup */
  regrouped: boolean;
  /** shield wall / pike wall is set while > 0 */
  braceT: number;
  threatX: number;
  /** seconds since arrows last fell on the squad (counts down) */
  arrowT: number;
  /** cavalry bogged down in melee */
  stuckT: number;
  /** first crash of the current charge already played its big effect */
  crashed: boolean;
  /** cooldown for floating shout texts */
  shoutT: number;
  /** horse archers circle: direction and time until they turn */
  orbit: number;
  orbitT: number;
  order: Order | null;
  /** selected by the player */
  sel: boolean;
}

export interface Decal {
  x: number;
  y: number;
  r: number;
  t: number;
  kind: "blood" | "crater" | "pool";
  seed: number;
}

export interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind:
    | "dust"
    | "spark"
    | "debris"
    | "gear"
    | "ring"
    | "smoke"
    | "fire"
    | "star"
    | "blood"
    | "slash"
    | "flash"
    | "leaf"
    | "dirt"
    | "shock"
    | "streak"
    | "ember";
  rot: number;
  vr: number;
}

export interface Projectile {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  t: number;
  dur: number;
  arc: number;
  z0: number;
  team: number;
  dmg: number;
  target: Unit | null;
  castle: number; // -1 none, else castle team index
  big: boolean;
  atkType: string;
  ball: boolean;
  crit: boolean;
  /** heavy bolt / bullet / javelin: flies flat and punches through to a second man */
  heavy: boolean;
  /** a naphtha pot: bursts into flame where it lands */
  fire: boolean;
}

export interface StuckArrow {
  x: number;
  y: number;
  ang: number;
  t: number;
}

export interface FloatText {
  x: number;
  y: number;
  text: string;
  color: string;
  t: number;
  max: number;
  size: number;
}
