/**
 * Renderer, built to stay fast in a 400-man melee:
 *  - one opaque blit for the whole landscape
 *  - every soldier is a cached sprite drawn with a single setTransform + drawImage
 *  - depth order comes from an in-place insertion sort (the list is almost sorted every frame)
 *  - arrows are batched into two paths, particles use tiny rects and soft sprites
 *  - settled blood and bodies live in a baked ground layer; only its dirty rectangle is drawn
 *  - nothing is allocated per frame
 */
import { CANNON_DEF, CASTLE, FIELD_BOTTOM, FIELD_TOP, H, HERO_COST, HERO_DEFS, TYPE_NAME, W, ZONES, unitCost } from "./constants";
import type { Game } from "./engine";
import type { Decal, Rag, Squad, Unit } from "./types";
import { drawHorseRag, drawRag, frameOf, getLook, setSpriteRes, sprite } from "./figure";
import { CASTLE_BOX, CASTLE_FLAGS, castleSprite, drawBanner, drawRuins } from "./castles";
import { drawSkyLife } from "./scenery";
import { LESSONS, SHAPE_NAME, shapeOf } from "./tutorial";

type C = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
const US = 1.3;
const FONT = "'Lilita One', 'Trebuchet MS', 'Segoe UI', sans-serif";
const INK = "rgba(34,22,12,0.92)";

const easeOutBack = (t: number) => 1 + 3.2 * Math.pow(t - 1, 3) + 2.2 * Math.pow(t - 1, 2);
const easeOutElastic = (t: number) => (t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (TAU / 3)) + 1);

const softCache = new Map<string, HTMLCanvasElement>();
/** a small blurry disc, used for dust, smoke and flashes */
function soft(rgb: string): HTMLCanvasElement {
  let cv = softCache.get(rgb);
  if (!cv) {
    cv = document.createElement("canvas");
    cv.width = cv.height = 32;
    const c = cv.getContext("2d")!;
    const g = c.createRadialGradient(16, 16, 0, 16, 16, 16);
    g.addColorStop(0, `rgba(${rgb},0.95)`);
    g.addColorStop(0.55, `rgba(${rgb},0.5)`);
    g.addColorStop(1, `rgba(${rgb},0)`);
    c.fillStyle = g;
    c.fillRect(0, 0, 32, 32);
    softCache.set(rgb, cv);
  }
  return cv;
}

function label(ctx: C, text: string, x: number, y: number, size: number, color: string, align: CanvasTextAlign = "center") {
  ctx.font = `${size}px ${FONT}`;
  ctx.textAlign = align;
  ctx.lineJoin = "round";
  ctx.lineWidth = Math.max(3, size * 0.26);
  ctx.strokeStyle = INK;
  ctx.strokeText(text, x, y);
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

function roundRect(ctx: C, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* ------------------------------------------------------------------ */
/*  ground layer                                                      */
/* ------------------------------------------------------------------ */
function drawDecal(c: C, d: Decal, k: number) {
  if (d.kind === "crater") {
    c.fillStyle = "rgba(70,52,30,0.5)";
    c.beginPath();
    c.ellipse(d.x, d.y, d.r * 1.5, d.r * 0.6, 0, 0, TAU);
    c.fill();
    c.fillStyle = "rgba(40,30,18,0.6)";
    c.beginPath();
    c.ellipse(d.x, d.y + 0.5, d.r, d.r * 0.38, 0, 0, TAU);
    c.fill();
    return;
  }
  const r = d.r * (0.3 + 0.7 * k);
  c.fillStyle = d.kind === "pool" ? "rgba(150,22,22,0.8)" : "rgba(172,30,30,0.78)";
  c.beginPath();
  c.ellipse(d.x, d.y, r, r * 0.42, 0, 0, TAU);
  c.fill();
  if (d.kind === "pool") {
    const a = d.seed * TAU;
    c.beginPath();
    c.ellipse(d.x + Math.cos(a) * r * 0.7, d.y + Math.sin(a) * r * 0.25, r * 0.5, r * 0.22, 0, 0, TAU);
    c.fill();
  }
}

const POSE = { ang: 0, l0: 0, l1: 0, l2: 0, l3: 0 };
function drawBody(ctx: C, r: Rag) {
  const s = r.scale;
  ctx.save();
  if (r.horse) {
    ctx.translate(r.x, r.y - r.z - (4.3 + 4.3 * Math.abs(Math.cos(r.ang))) * s);
    ctx.scale(r.facing * s, s);
    drawHorseRag(ctx, r.look, r.ang * r.facing);
  } else {
    ctx.translate(r.x, r.y - r.z - (1.7 + 3.1 * Math.abs(Math.cos(r.ang))) * s);
    ctx.scale(r.facing * s, s);
    POSE.ang = r.ang * r.facing;
    POSE.l0 = r.l0 * r.facing;
    POSE.l1 = r.l1 * r.facing;
    POSE.l2 = r.l2 * r.facing;
    POSE.l3 = r.l3 * r.facing;
    drawRag(ctx, r.look, POSE);
  }
  ctx.restore();
}

function grow(b: number[], x: number, y: number, r: number) {
  if (b[0] >= b[2]) {
    b[0] = x - r;
    b[1] = y - r;
    b[2] = x + r;
    b[3] = y + r;
  } else {
    b[0] = Math.min(b[0], x - r);
    b[1] = Math.min(b[1], y - r);
    b[2] = Math.max(b[2], x + r);
    b[3] = Math.max(b[3], y + r);
  }
}

/** stamp settled decals and bodies into the ground layer and let the layer fade slowly */
function bakeGround(g: Game) {
  const c = g.gctx;
  const b = g.gbox;
  if (b[0] < b[2]) {
    if (g.time - g.groundStampAt > 40) g.clearGround();
    else if (g.time - g.groundFadeAt > 0.9) {
      g.groundFadeAt = g.time;
      c.save();
      c.globalCompositeOperation = "destination-out";
      c.fillStyle = "rgba(0,0,0,0.07)";
      c.fillRect(b[0], b[1], b[2] - b[0], b[3] - b[1]);
      c.restore();
    }
  }
  let stamped = false;
  for (const d of g.decals) {
    if (d.t > 1e8 || d.t < (d.kind === "pool" ? 1.3 : d.kind === "blood" ? 0.15 : 0.3)) continue;
    drawDecal(c, d, 1);
    grow(b, d.x, d.y, d.r * 1.6 + 3);
    d.t = 1e9; // baked: the simulation drops it
    stamped = true;
  }
  for (const r of g.corpses) {
    if (r.rest < 0) continue;
    c.globalAlpha = 0.95;
    drawBody(c, r);
    c.globalAlpha = 1;
    grow(b, r.x, r.y - 8, r.horse ? 44 : 30);
    r.rest = -1;
    stamped = true;
  }
  if (stamped) {
    g.groundStampAt = g.time;
    b[0] = Math.max(0, b[0]);
    b[1] = Math.max(0, b[1]);
    b[2] = Math.min(W, b[2]);
    b[3] = Math.min(H, b[3]);
  }
}

/* ------------------------------------------------------------------ */
/*  zones, plans, previews                                            */
/* ------------------------------------------------------------------ */
function drawZones(g: Game, ctx: C) {
  const pulse = 0.5 + Math.sin(g.time * 3) * 0.5;
  for (let t = 0; t < 2; t++) {
    const Z = ZONES[t];
    const f = g.fac[t];
    const active = t === 0 && (!!g.drawing || !!g.pendingHero || g.pendingCannon || g.inZone(g.mouse.x, g.mouse.y) || g.hint > 0);
    roundRect(ctx, Z.x0, FIELD_TOP - 10, Z.x1 - Z.x0, FIELD_BOTTOM - FIELD_TOP + 20, 18);
    ctx.globalAlpha = t === 0 ? (active ? 0.13 + pulse * 0.05 : 0.07) : 0.07;
    ctx.fillStyle = f.main;
    ctx.fill();
    ctx.globalAlpha = t === 0 ? (active ? 0.9 : 0.5) : 0.5;
    ctx.setLineDash([9, 8]);
    ctx.lineDashOffset = (t === 0 ? -1 : 1) * g.time * 20;
    ctx.strokeStyle = f.main;
    ctx.lineWidth = 2.6;
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;
    label(ctx, t === 0 ? "ZONA PASUKANMU" : "PERSIAPAN MUSUH", (Z.x0 + Z.x1) / 2, FIELD_TOP + 12, 17, "#fff8ea");
  }
}

/** war-map arrows: where every waiting squad goes at the horn (the player's own orders are drawn by drawOrders) */
function drawPlans(g: Game, ctx: C) {
  const urgent = g.phaseT < 3 ? 1 : 0;
  for (const sq of g.squads) {
    if (sq.state !== "ready" || sq.dead || sq.spawnT < 0.3) continue;
    const dir = sq.team === 0 ? 1 : -1;
    let minY = Infinity;
    let maxY = -Infinity;
    let front = sq.team === 0 ? -Infinity : Infinity;
    for (const u of sq.units) {
      if (u.dead) continue;
      minY = Math.min(minY, u.y);
      maxY = Math.max(maxY, u.y);
      front = sq.team === 0 ? Math.max(front, u.x) : Math.min(front, u.x);
    }
    const cy = (minY + maxY) / 2;
    const half = Math.max(14, (maxY - minY) / 2);
    const w0 = Math.min(half, 60);
    const f = g.fac[sq.team];
    // in a lesson the label says what the troops ARE (Kavaleri ×20), not their faction name
    const name = g.tut ? (sq.type === "cannon" ? "Meriam" : `${TYPE_NAME[sq.type]} ×${sq.alive}`) : sq.hero ? HERO_DEFS[sq.hero].name : sq.type === "cannon" ? CANNON_DEF.name : f.unitNames[sq.type as keyof typeof f.unitNames];
    if (sq.order) {
      label(ctx, sq.order.kind === "hold" ? name + " · cadangan" : name, front + dir * 74, cy - w0 - 7, 14, "#fff8ea");
      continue;
    }
    const x0 = front + dir * 14;
    const fast = sq.type === "cavalry" || sq.type === "harcher" || (!!sq.hero && !!HERO_DEFS[sq.hero].mounted);
    const len = (fast ? 220 : sq.type === "archer" || sq.type === "xbow" ? 110 : 160) + Math.sin(g.time * 4 + sq.id) * 6 + urgent * 20;
    const x1 = x0 + dir * len;
    const w1 = Math.min(half * 0.55, 32);
    ctx.beginPath();
    ctx.moveTo(x0, cy - w0);
    ctx.lineTo(x1 - dir * 18, cy - w1);
    ctx.lineTo(x1 - dir * 18, cy - w1 - 12);
    ctx.lineTo(x1 + dir * 8, cy);
    ctx.lineTo(x1 - dir * 18, cy + w1 + 12);
    ctx.lineTo(x1 - dir * 18, cy + w1);
    ctx.lineTo(x0, cy + w0);
    ctx.closePath();
    ctx.globalAlpha = 0.16 + urgent * 0.1 * (0.5 + 0.5 * Math.sin(g.time * 10));
    ctx.fillStyle = f.main;
    ctx.fill();
    ctx.globalAlpha = 1;
    // in a lesson the label sits right at the formation (above it; below for the rear line, so two never overlap)
    if (g.tut) label(ctx, name, sq.cx, sq.team === 1 && sq.cx > 1060 ? maxY + 26 : minY - 16, 15, "#fff8ea");
    else label(ctx, name, (x0 + x1) / 2, cy - w0 - 7, 14, "#fff8ea");
  }
}

/* ------------------------------------------------------------------ */
/*  command: selection and orders                                     */
/* ------------------------------------------------------------------ */
const ORDER_COL = { move: "#ffe45c", attack: "#ff6a55", retreat: "#8fd4ff", hold: "#ffffff" } as const;

/** a small sign for each kind of order: flag, crossed blades, shield, chevrons */
function orderGlyph(ctx: C, kind: string, x: number, y: number, col: string) {
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();
  let fill = false;
  if (kind === "hold") {
    ctx.moveTo(x - 6, y - 7);
    ctx.lineTo(x + 6, y - 7);
    ctx.lineTo(x + 6, y);
    ctx.quadraticCurveTo(x + 5, y + 6, x, y + 8);
    ctx.quadraticCurveTo(x - 5, y + 6, x - 6, y);
    ctx.closePath();
    fill = true;
  } else if (kind === "attack") {
    ctx.moveTo(x - 6, y - 6);
    ctx.lineTo(x + 6, y + 6);
    ctx.moveTo(x + 6, y - 6);
    ctx.lineTo(x - 6, y + 6);
  } else if (kind === "retreat") {
    ctx.moveTo(x + 1, y - 6);
    ctx.lineTo(x - 5, y);
    ctx.lineTo(x + 1, y + 6);
    ctx.moveTo(x + 7, y - 6);
    ctx.lineTo(x + 1, y);
    ctx.lineTo(x + 7, y + 6);
  } else {
    ctx.moveTo(x - 4, y + 8);
    ctx.lineTo(x - 4, y - 8);
    ctx.lineTo(x + 7, y - 4);
    ctx.lineTo(x - 4, y);
    fill = true;
  }
  ctx.strokeStyle = INK;
  ctx.lineWidth = 4.4;
  ctx.stroke();
  if (fill) {
    ctx.fillStyle = col;
    ctx.fill();
  }
  ctx.strokeStyle = col;
  ctx.lineWidth = 1.9;
  ctx.stroke();
}

/** on the ground, under the soldiers: rings round selected men and the lines of their orders */
function drawOrders(g: Game, ctx: C) {
  const pulse = 0.5 + 0.5 * Math.sin(g.time * 6);
  ctx.lineCap = "round";
  for (let pass = 0; pass < 2; pass++) {
    const list = pass === 0 ? g.selection : g.preview;
    if (!list.length) continue;
    ctx.beginPath();
    for (const sq of list) {
      if (pass === 1 && sq.sel) continue;
      for (const u of sq.units) {
        if (u.dead || u.spawnT < 0) continue;
        const rx = u.mounted ? 13 : 8.4;
        ctx.moveTo(u.x + rx, u.y);
        ctx.ellipse(u.x, u.y, rx, rx * 0.46, 0, 0, TAU);
      }
    }
    ctx.fillStyle = pass === 0 ? `rgba(255,228,92,${(0.42 + pulse * 0.2).toFixed(2)})` : "rgba(255,255,255,0.45)";
    ctx.fill();
    ctx.strokeStyle = pass === 0 ? "#fff06a" : "#ffffff";
    ctx.lineWidth = 2.2;
    ctx.stroke();
  }
  for (const sq of g.squads) {
    const o = sq.order;
    if (!o || sq.team !== 0 || sq.dead) continue;
    const col = ORDER_COL[o.kind];
    ctx.globalAlpha = sq.sel ? 0.95 : 0.45;
    if (o.kind === "hold") {
      if (sq.sel) {
        // the ground it guards
        ctx.setLineDash([6, 7]);
        ctx.strokeStyle = col;
        ctx.lineWidth = 1.7;
        ctx.beginPath();
        ctx.ellipse(o.x, o.y, 150, 66, 0, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      continue;
    }
    let tx = o.x;
    let ty = o.y;
    if (o.kind === "attack" && o.target) {
      tx = o.target.cx;
      ty = o.target.cy;
    }
    const dx = tx - sq.cx;
    const dy = ty - sq.cy;
    const d = Math.hypot(dx, dy);
    if (d > 34) {
      const ux = dx / d;
      const uy = dy / d;
      const x1 = tx - ux * 18;
      const y1 = ty - uy * 18;
      ctx.setLineDash([9, 8]);
      ctx.lineDashOffset = -g.time * 36;
      ctx.strokeStyle = col;
      ctx.lineWidth = sq.sel ? 3 : 2.2;
      ctx.beginPath();
      ctx.moveTo(sq.cx + ux * 14, sq.cy + uy * 14);
      ctx.lineTo(x1, y1);
      ctx.stroke();
      ctx.setLineDash([]);
      const ang = Math.atan2(uy, ux);
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(x1 + ux * 11, y1 + uy * 11);
      ctx.lineTo(x1 + Math.cos(ang + 2.5) * 10, y1 + Math.sin(ang + 2.5) * 10);
      ctx.lineTo(x1 + Math.cos(ang - 2.5) * 10, y1 + Math.sin(ang - 2.5) * 10);
      ctx.fill();
    }
    ctx.strokeStyle = col;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    if (o.kind === "attack") ctx.ellipse(tx, ty, 34 + pulse * 4, 15 + pulse * 2, 0, 0, TAU);
    else ctx.ellipse(tx, ty, 15, 6.5, 0, 0, TAU);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

/** over the soldiers: a small sign above every squad that is under orders */
function drawOrderBadges(g: Game, ctx: C) {
  for (const sq of g.squads) {
    const o = sq.order;
    if (!o || sq.team !== 0 || sq.dead) continue;
    const solo = sq.type === "hero" || sq.type === "cannon";
    orderGlyph(ctx, o.kind, sq.bannerX + (solo ? 28 : 3), sq.bannerY - (solo ? 24 : 46), ORDER_COL[o.kind]);
  }
  // a bobbing marker over every selected squad
  const bob = Math.sin(g.time * 7) * 2.5;
  for (const sq of g.selection) {
    if (sq.dead) continue;
    const solo = sq.type === "hero" || sq.type === "cannon";
    const x = sq.bannerX + (solo ? 0 : 3);
    const y = sq.bannerY - (solo ? 84 : sq.order ? 64 : 46) + bob;
    ctx.beginPath();
    ctx.moveTo(x - 8, y - 9);
    ctx.lineTo(x + 8, y - 9);
    ctx.lineTo(x, y + 2);
    ctx.closePath();
    ctx.lineJoin = "round";
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3.4;
    ctx.stroke();
    ctx.fillStyle = "#ffe45c";
    ctx.fill();
  }
}

/** tutorial: a stroke to copy (with a dot that shows the dragging motion) and a spot to point at */
function drawGuide(g: Game, ctx: C) {
  const T = g.tut;
  if (!T) return;
  const L = LESSONS[T.i];
  const live = T.phase === "fight" && !!L.live;
  if (L.mark && live) {
    // "this one": a pulsing ring
    const k = 0.5 + 0.5 * Math.sin(g.time * 6);
    ctx.strokeStyle = "#ff5a4a";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(L.mark.x, L.mark.y, 40 + k * 6, 24 + k * 4, 0, 0, TAU);
    ctx.stroke();
    label(ctx, L.mark.text, L.mark.x, L.mark.y + 52, 17, "#ffd9d2");
  }
  const idle = T.phase === "plan" ? !T.placed.length && !g.drawing : live && !g.selection.length && !g.selecting;
  const p = L.guide;
  if (!p || !idle) return;
  const a = p[0];
  const b = p[p.length - 1];
  ctx.lineCap = "round";
  ctx.strokeStyle = "rgba(255,228,92,0.35)";
  ctx.lineWidth = 22;
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
  ctx.strokeStyle = "#ffe45c";
  ctx.lineWidth = 3.5;
  ctx.setLineDash([10, 9]);
  ctx.lineDashOffset = -g.time * 30;
  ctx.stroke();
  ctx.setLineDash([]);
  const k = (g.time * 0.55) % 1.3;
  const t = Math.min(1, k);
  ctx.fillStyle = "#fff8ea";
  ctx.strokeStyle = INK;
  ctx.lineWidth = 2.6;
  ctx.beginPath();
  ctx.arc(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, k < 1 ? 11 : 15, 0, TAU);
  ctx.fill();
  ctx.stroke();
  label(ctx, L.guideText ?? "Tahan & seret di sini", (a.x + b.x) / 2, Math.min(a.y, b.y) - 24, 18, "#ffe45c");
}

/** the stroke the player is drawing to pick squads */
function drawSelecting(g: Game, ctx: C) {
  const p = g.selecting;
  if (!p || p.length < 2) return;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(p[0].x, p[0].y);
  for (let i = 1; i < p.length; i++) ctx.lineTo(p[i].x, p[i].y);
  ctx.strokeStyle = "rgba(255,228,92,0.3)";
  ctx.lineWidth = 42;
  ctx.stroke();
  ctx.strokeStyle = "#fffbe0";
  ctx.lineWidth = 3;
  ctx.setLineDash([2, 9]);
  ctx.stroke();
  ctx.setLineDash([]);
  const n = g.preview.length;
  label(ctx, n ? `Lepas: pilih ${n} barisan` : "Seret melewati pasukanmu", g.mouse.x + 18, g.mouse.y - 18, 17, n ? "#ffe45c" : "#fff3d6", "left");
}

function drawPreview(g: Game, ctx: C, bs: number, btx: number, bty: number) {
  const f = g.fac[0];
  const ghost = (type: "cannon" | "hero" | typeof g.selected, x: number, y: number, a: number, hero = g.pendingHero ?? undefined) => {
    const k = getLook(f.id, type, type === "hero" ? hero : undefined);
    const s = bs * US * (type === "hero" ? 1.5 : 1);
    ctx.globalAlpha = a;
    ctx.setTransform(s, 0, 0, s, bs * x + btx, bs * y + bty);
    ctx.drawImage(sprite(k, 0), -k.ox, -k.oy, k.w, k.h);
    ctx.setTransform(bs, 0, 0, bs, btx, bty);
    ctx.globalAlpha = 1;
  };
  if (g.pendingCannon) {
    const ok = g.inZone(g.mouse.x, g.mouse.y) && g.gold[0] >= CANNON_DEF.cost;
    ghost("cannon", g.mouse.x, g.mouse.y - 3 + Math.sin(g.time * 6) * 2, ok ? 0.85 : 0.4);
    label(ctx, ok ? `Klik: pasang meriam · ${CANNON_DEF.cost} emas` : "Tidak bisa dipasang di sini", g.mouse.x, g.mouse.y - 40, 16, ok ? "#fff3d6" : "#ffc2b8");
    return;
  }
  if (g.pendingHero) {
    const ok = g.inZone(g.mouse.x, g.mouse.y) && g.gold[0] >= HERO_COST;
    ghost("hero", g.mouse.x, g.mouse.y - 4 + Math.sin(g.time * 6) * 2, ok ? 0.85 : 0.4);
    label(ctx, ok ? "Klik: panggil " + HERO_DEFS[g.pendingHero].name : "Tidak bisa dipanggil di sini", g.mouse.x, g.mouse.y - 62, 16, ok ? "#ffe08a" : "#ffc2b8");
    return;
  }
  if (!g.drawing) return;
  const pts = g.drawing;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
  ctx.lineTo(g.mouse.x, g.mouse.y);
  ctx.strokeStyle = "rgba(255,248,230,0.45)";
  ctx.lineWidth = 7;
  ctx.stroke();
  ctx.strokeStyle = f.main;
  ctx.lineWidth = 2.4;
  ctx.setLineDash([7, 6]);
  ctx.lineDashOffset = -g.time * 30;
  ctx.stroke();
  ctx.setLineDash([]);
  const cost = unitCost(g.selected, f);
  const enough = g.gold[0] >= cost;
  const samples = g.samplePath(pts.concat([{ x: g.mouse.x, y: g.mouse.y }]), 0, g.selected);
  for (let i = 0; i < samples.length; i++) ghost(g.selected, samples[i].x, samples[i].y - Math.abs(Math.sin(g.time * 9 + i * 0.5)) * 3, enough ? 0.78 : 0.4);
  label(ctx, `20 × ${f.unitNames[g.selected]} · ${SHAPE_NAME[shapeOf(samples)]} · ${cost} emas`, g.mouse.x + 16, g.mouse.y - 16, 17, enough ? "#fff3d6" : "#ffb0a2", "left");
}

/** the advisor's suggestion: a glowing ghost formation, and a line to the enemy it answers */
function drawAdvice(g: Game, ctx: C, bs: number, btx: number, bty: number) {
  const a = g.advice;
  if (!a || a.kind === "wait") return;
  const f = g.fac[0];
  const pulse = 0.5 + 0.5 * Math.sin(g.time * 5);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (a.tx !== undefined && a.ty !== undefined) {
    const dx = a.tx - a.x;
    const dy = a.ty - a.y;
    const d = Math.hypot(dx, dy) || 1;
    const x0 = a.x + (dx / d) * 46;
    const y0 = a.y + (dy / d) * 46;
    const x1 = a.tx - (dx / d) * 40;
    const y1 = a.ty - (dy / d) * 40;
    const ang = Math.atan2(dy, dx);
    ctx.globalAlpha = 0.8;
    ctx.strokeStyle = "#ffd04a";
    ctx.lineWidth = 3.2;
    ctx.setLineDash([10, 9]);
    ctx.lineDashOffset = -g.time * 40;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#ffd04a";
    ctx.beginPath();
    ctx.moveTo(x1 + Math.cos(ang) * 13, y1 + Math.sin(ang) * 13);
    ctx.lineTo(x1 + Math.cos(ang + 2.5) * 11, y1 + Math.sin(ang + 2.5) * 11);
    ctx.lineTo(x1 + Math.cos(ang - 2.5) * 11, y1 + Math.sin(ang - 2.5) * 11);
    ctx.fill();
    // the enemy this answers
    ctx.strokeStyle = "#ff5a4a";
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(a.tx, a.ty, 32 + pulse * 5, 14 + pulse * 2, 0, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
  const k = getLook(f.id, a.kind === "squad" && a.type ? a.type : a.kind === "cannon" ? "cannon" : "hero", a.kind === "hero" ? a.hero : undefined);
  const s = bs * US * (a.kind === "hero" ? 1.5 : 1);
  const img = sprite(k, 0);
  let top = a.y - (a.kind === "hero" ? 66 : 44);
  if (a.kind === "squad" && a.type) {
    ctx.beginPath();
    for (let i = 0; i < a.path.length; i++) {
      if (i) ctx.lineTo(a.path[i].x, a.path[i].y);
      else ctx.moveTo(a.path[i].x, a.path[i].y);
    }
    ctx.strokeStyle = "rgba(255,208,74,0.38)";
    ctx.lineWidth = 18;
    ctx.stroke();
    const pts = g.samplePath(a.path, 0, a.type);
    ctx.globalAlpha = 0.62 + pulse * 0.25;
    for (let i = 0; i < pts.length; i++) {
      ctx.setTransform(s, 0, 0, s, bs * pts[i].x + btx, bs * (pts[i].y - Math.abs(Math.sin(g.time * 6 + i * 0.5)) * 2) + bty);
      ctx.drawImage(img, -k.ox, -k.oy, k.w, k.h);
      top = Math.min(top, pts[i].y - 36);
    }
  } else {
    ctx.strokeStyle = "#ffd04a";
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.ellipse(a.x, a.y, 24 + pulse * 4, 10 + pulse * 2, 0, 0, TAU);
    ctx.stroke();
    ctx.globalAlpha = 0.62 + pulse * 0.25;
    ctx.setTransform(s, 0, 0, s, bs * a.x + btx, bs * a.y + bty);
    ctx.drawImage(img, -k.ox, -k.oy, k.w, k.h);
  }
  ctx.setTransform(bs, 0, 0, bs, btx, bty);
  ctx.globalAlpha = 1;
  label(ctx, "SARAN: " + (a.kind === "squad" ? "20 × " : "") + a.name, a.x, Math.max(top - 6, FIELD_TOP + 40), 17, "#ffe08a");
}

/* ------------------------------------------------------------------ */
/*  entities                                                          */
/* ------------------------------------------------------------------ */
interface Ent {
  y: number;
  k: number; // 0 castle, 1 banner, 2 ragdoll
  i: number;
}
const ENTS: Ent[] = [];

function sortUnits(a: Unit[]) {
  for (let i = 1; i < a.length; i++) {
    const v = a[i];
    const y = v.y;
    let j = i - 1;
    while (j >= 0 && a[j].y > y) {
      a[j + 1] = a[j];
      j--;
    }
    a[j + 1] = v;
  }
}

function drawCastle(g: Game, ctx: C, t: number, bs: number, btx: number, bty: number) {
  const c = g.castles[t];
  const C0 = CASTLE[t];
  const f = g.fac[t];
  const flip = t === 1 ? -1 : 1;
  if (c.hp <= 0 && (g.state === "won" || g.state === "lost")) {
    ctx.save();
    ctx.translate(C0.cx, C0.baseY);
    ctx.scale(flip, 1);
    drawRuins(ctx, f);
    ctx.restore();
    return;
  }
  const img = castleSprite(f.id, g.pxScale);
  const B = CASTLE_BOX;
  ctx.setTransform(bs * flip * (1 + c.squash * 0.07), 0, 0, bs * (1 - c.squash * 0.09), bs * C0.cx + btx, bs * C0.baseY + bty);
  ctx.drawImage(img, -B.ox, -B.oy, B.w, B.h);
  if (c.flash > 0) {
    ctx.globalAlpha = 0.6;
    ctx.drawImage(castleSprite(f.id, g.pxScale, true), -B.ox, -B.oy, B.w, B.h);
    ctx.globalAlpha = 1;
  }
  const frac = c.hp / c.max;
  if (frac < 0.66) {
    // battle damage: cracks crawl up the walls
    ctx.strokeStyle = "rgba(40,28,16,0.8)";
    ctx.lineWidth = 1.8;
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(-40, -2);
    ctx.lineTo(-33, -22);
    ctx.lineTo(-41, -38);
    ctx.lineTo(-30, -58);
    ctx.moveTo(36, -4);
    ctx.lineTo(30, -26);
    ctx.lineTo(40, -44);
    if (frac < 0.33) {
      ctx.moveTo(-6, -70);
      ctx.lineTo(4, -92);
      ctx.lineTo(-5, -112);
      ctx.lineTo(6, -132);
      ctx.moveTo(52, -60);
      ctx.lineTo(60, -84);
      ctx.lineTo(54, -104);
      ctx.moveTo(-58, -64);
      ctx.lineTo(-66, -90);
    }
    ctx.stroke();
  }
  ctx.setTransform(bs, 0, 0, bs, btx, bty);
  for (const [fx, fy, fs] of CASTLE_FLAGS[f.id]) drawBanner(ctx, f, C0.cx + flip * fx, C0.baseY + fy, g.time, fs, 0, 1, fx);
}

function drawSquadBanner(g: Game, ctx: C, sq: Squad) {
  const appear = easeOutElastic(Math.min(1, sq.spawnT / 0.9));
  let fall = 0;
  let alpha = 1;
  if (sq.dead) {
    fall = easeOutBack(Math.min(1, sq.deadT / 0.6));
    alpha = sq.deadT > 1.6 ? Math.max(0, 1 - (sq.deadT - 1.6)) : 1;
  }
  const lift = sq.state === "march" && sq.launchT < 0.8 ? Math.sin((sq.launchT / 0.8) * Math.PI) * 10 : 0;
  const drop = (1 - Math.min(1, sq.spawnT / 0.35)) * -60;
  drawBanner(ctx, g.fac[sq.team], sq.bannerX, sq.bannerY + drop - lift, g.time, 0.3 + appear * 0.52 + lift * 0.012, fall, alpha, sq.id);
}

function drawUnit(g: Game, ctx: C, u: Unit, bs: number, btx: number, bty: number) {
  const k = u.look;
  const sp = Math.min(1, u.spawnT / 0.4);
  const moving = u.vx * u.vx + u.vy * u.vy > 16;
  let sx = 1 + u.hitT * 0.3;
  let sy = 1 - u.hitT * 0.24;
  let hop = 0;
  let sc = u.scale;
  if (sp < 1) {
    // pops out of the ground: tall, then settles
    const b = Math.sin(sp * Math.PI);
    sy *= 1 + b * 0.35;
    sx *= 1 - b * 0.2;
    hop = b * 10;
    sc *= easeOutBack(sp);
  }
  if (u.cheerT > 0 && u.cheerT < 1) hop += Math.abs(Math.sin(u.cheerT * TAU)) * 6;
  if (u.braceT > 0) sy *= 0.93;
  let rot = 0;
  if (u.stunT > 0.05) rot = Math.sin(g.time * 30 + u.seed) * 0.13;
  else if (u.braceT > 0) rot = u.facing * 0.1;
  else if (moving && u.squad.charging && !u.target) rot = u.facing * 0.15;
  const img = sprite(k, frameOf(u.walk, moving, u.type === "cannon" ? u.recoil : u.atkT));
  const a = bs * sc * sx * u.facing;
  const d = bs * sc * sy;
  const ex = bs * u.x + btx;
  const ey = bs * (u.y - hop) + bty;
  if (rot === 0) ctx.setTransform(a, 0, 0, d, ex, ey);
  else {
    const cs = Math.cos(rot);
    const sn = Math.sin(rot);
    ctx.setTransform(cs * a, sn * a, -sn * d, cs * d, ex, ey);
  }
  ctx.drawImage(img, -k.ox, -k.oy, k.w, k.h);
  if (u.hitT > 0.62) {
    // hit flash
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.6;
    ctx.drawImage(img, -k.ox, -k.oy, k.w, k.h);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }
}

function drawOverlays(g: Game, ctx: C) {
  for (const u of g.units) {
    if (u.spawnT < 0) continue;
    if (u.mom > 0.45 && !u.rag) {
      // speed lines behind a horse at full gallop
      const sp = Math.hypot(u.vx, u.vy) || 1;
      const bx = -u.vx / sp;
      const by = -u.vy / sp;
      ctx.strokeStyle = "rgba(255,255,255,0.5)";
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      for (let i = 0; i < 3; i++) {
        const oy = -6 - i * 7;
        const l = 9 + u.mom * 12 + ((u.seed * (i + 1)) % 5);
        ctx.moveTo(u.x + bx * 12, u.y + by * 12 + oy);
        ctx.lineTo(u.x + bx * (12 + l), u.y + by * (12 + l) + oy);
      }
      ctx.stroke();
    }
    if (u.stunT > 0.08 && !u.rag) {
      // dizzy stars over a staggered soldier
      const yy = u.y - (u.mounted ? 31 : 26) * u.scale;
      ctx.fillStyle = "#ffe36b";
      for (let i = 0; i < 2; i++) {
        const a = g.time * 9 + i * Math.PI + u.seed;
        ctx.fillRect(u.x + Math.cos(a) * 5.5 - 1.2, yy + Math.sin(a) * 1.8 - 1.2, 2.4, 2.4);
      }
    }
    if (u.hero) {
      const y = u.y - (u.mounted ? 33 : 27) * u.scale - 5;
      ctx.strokeStyle = "rgba(255,205,70,0.9)";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.ellipse(u.x, u.y, 19 + Math.sin(g.time * 5) * 1.5, 7, 0, 0, TAU);
      ctx.stroke();
      ctx.fillStyle = "rgba(30,20,10,0.85)";
      ctx.fillRect(u.x - 18, y - 1, 36, 6);
      ctx.fillStyle = u.team === 0 ? "#6fe07a" : "#ff6b6b";
      ctx.fillRect(u.x - 17, y, (34 * Math.max(0, u.hp)) / u.maxHp, 4);
      label(ctx, HERO_DEFS[u.hero].name, u.x, y - 5, 13, u.team === 0 ? "#ffe9a8" : "#dbe6ff");
    } else if (u.showHpT > 0 && !u.rag) {
      const y = u.y - (u.mounted ? 32 : 26) * u.scale;
      ctx.globalAlpha = Math.min(1, u.showHpT * 2);
      ctx.fillStyle = "rgba(30,20,10,0.8)";
      ctx.fillRect(u.x - 7, y - 1, 14, 4);
      ctx.fillStyle = u.team === 0 ? "#6fe07a" : "#ff6b6b";
      ctx.fillRect(u.x - 6, y, (12 * Math.max(0, u.hp)) / u.maxHp, 2);
      ctx.globalAlpha = 1;
    }
  }
}

/* ------------------------------------------------------------------ */
/*  projectiles & particles                                           */
/* ------------------------------------------------------------------ */
function drawProjectiles(g: Game, ctx: C) {
  const ps = g.projectiles;
  if (!ps.length) return;
  ctx.lineCap = "round";
  // shafts in one path, heads in another
  for (let pass = 0; pass < 2; pass++) {
    ctx.beginPath();
    for (const p of ps) {
      if (p.ball || p.fire) continue;
      const t = p.t;
      const t0 = Math.max(0, t - 0.035);
      const x = p.x0 + (p.x1 - p.x0) * t;
      const y = p.y0 + (p.y1 - p.y0) * t - (p.z0 * (1 - t) + Math.sin(Math.PI * t) * p.arc);
      const xb = p.x0 + (p.x1 - p.x0) * t0;
      const yb = p.y0 + (p.y1 - p.y0) * t0 - (p.z0 * (1 - t0) + Math.sin(Math.PI * t0) * p.arc);
      const dx = x - xb;
      const dy = y - yb;
      const d = Math.hypot(dx, dy) || 1;
      const L = p.heavy ? 9 : p.big ? 9 : 7;
      if (pass === 0) {
        ctx.moveTo(x - (dx / d) * L, y - (dy / d) * L);
        ctx.lineTo(x, y);
      } else {
        ctx.moveTo(x - (dx / d) * 2.4, y - (dy / d) * 2.4);
        ctx.lineTo(x, y);
      }
    }
    ctx.strokeStyle = pass === 0 ? "#3a2a1c" : "#eef2f6";
    ctx.lineWidth = pass === 0 ? 1.3 : 2;
    ctx.stroke();
  }
  for (const p of ps) {
    if (!p.ball && !p.fire) continue;
    const t = p.t;
    const x = p.x0 + (p.x1 - p.x0) * t;
    const gy = p.y0 + (p.y1 - p.y0) * t;
    const z = p.z0 * (1 - t) + Math.sin(Math.PI * t) * p.arc;
    if (p.fire) {
      // a tumbling clay pot trailing flame
      ctx.fillStyle = "#8f4a1f";
      ctx.beginPath();
      ctx.arc(x, gy - z, 2.7, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#ffb03a";
      ctx.fillRect(x - 1.4 - (p.x1 > p.x0 ? 3 : -3), gy - z - 4.6, 2.8, 3.4);
      ctx.fillStyle = "#fff3a0";
      ctx.fillRect(x - 0.7, gy - z - 3.6, 1.4, 1.6);
      continue;
    }
    ctx.fillStyle = "rgba(24,60,24,0.3)";
    ctx.beginPath();
    ctx.ellipse(x, gy, 4 + t * 2, 1.8, 0, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "#24242a";
    ctx.beginPath();
    ctx.arc(x, gy - z, 3.8, 0, TAU);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ctx.fillRect(x - 2, gy - z - 2, 1.6, 1.6);
  }
}

function drawParticles(g: Game, ctx: C) {
  const DUST = soft("190,170,130");
  const SMOKE = soft("120,114,106");
  const FLASH = soft("255,236,170");
  for (const p of g.particles) {
    const k = p.life / p.max;
    const py = p.y - p.z;
    switch (p.kind) {
      case "dust": {
        const r = p.size * (2.6 - k);
        ctx.globalAlpha = k * 0.6;
        ctx.drawImage(DUST, p.x - r, py - r, r * 2, r * 2);
        break;
      }
      case "smoke": {
        const r = p.size * (2.7 - k * 1.4);
        ctx.globalAlpha = k * 0.55;
        ctx.drawImage(SMOKE, p.x - r, py - r, r * 2, r * 2);
        break;
      }
      case "flash": {
        const r = p.size * (0.7 + (1 - k) * 1.1);
        ctx.globalAlpha = k;
        ctx.drawImage(FLASH, p.x - r, py - r, r * 2, r * 2);
        break;
      }
      case "spark":
        ctx.globalAlpha = k;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(p.x, py);
        ctx.lineTo(p.x - p.vx * 0.03, py + p.vz * 0.03);
        ctx.stroke();
        break;
      case "streak": {
        const sp = Math.hypot(p.vx, p.vy) || 1;
        const len = p.size * (0.5 + k);
        ctx.globalAlpha = k;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(p.x, py);
        ctx.lineTo(p.x - (p.vx / sp) * len, py - (p.vy / sp) * len);
        ctx.stroke();
        break;
      }
      case "blood":
      case "dirt":
      case "debris":
        ctx.globalAlpha = Math.min(1, k * 3);
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - p.size / 2, py - p.size / 2, p.size, p.size);
        break;
      case "gear": {
        // a helmet or shield spinning away
        const cs = Math.cos(p.rot) * p.size;
        ctx.globalAlpha = Math.min(1, k * 3);
        ctx.fillStyle = "rgba(34,22,12,0.9)";
        ctx.beginPath();
        ctx.ellipse(p.x, py, Math.abs(cs) + 1.6, p.size + 0.6, 0, 0, TAU);
        ctx.fill();
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.ellipse(p.x, py, Math.abs(cs) + 0.8, p.size - 0.2, 0, 0, TAU);
        ctx.fill();
        break;
      }
      case "star": {
        const s = p.size;
        ctx.globalAlpha = Math.min(1, k * 2);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.moveTo(p.x, py - s);
        ctx.lineTo(p.x + s * 0.35, py - s * 0.35);
        ctx.lineTo(p.x + s, py);
        ctx.lineTo(p.x + s * 0.35, py + s * 0.35);
        ctx.lineTo(p.x, py + s);
        ctx.lineTo(p.x - s * 0.35, py + s * 0.35);
        ctx.lineTo(p.x - s, py);
        ctx.lineTo(p.x - s * 0.35, py - s * 0.35);
        ctx.fill();
        break;
      }
      case "ember":
        ctx.globalAlpha = Math.min(1, k * 2);
        ctx.fillStyle = k > 0.5 ? "#ffe08a" : "#ff8a3c";
        ctx.fillRect(p.x - p.size / 2, py - p.size / 2, p.size, p.size);
        break;
      case "fire":
        ctx.globalAlpha = 0.85;
        ctx.fillStyle = k > 0.5 ? "#ffd25a" : "#eb6e28";
        ctx.beginPath();
        ctx.arc(p.x, py, p.size * k, 0, TAU);
        ctx.fill();
        break;
      case "leaf":
        ctx.globalAlpha = Math.min(1, k * 3, (p.max - p.life) * 2);
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x - p.size, py - p.size * 0.5, p.size * 2, p.size);
        break;
      case "ring": {
        const r = p.size * easeOutBack(Math.min(1, (1 - k) * 1.2));
        ctx.globalAlpha = k;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 3 * k + 0.5;
        ctx.beginPath();
        ctx.ellipse(p.x, p.y, Math.max(0, r), Math.max(0, r * 0.4), 0, 0, TAU);
        ctx.stroke();
        break;
      }
      case "shock": {
        const r = p.size * (0.25 + 0.75 * Math.sqrt(1 - k));
        ctx.globalAlpha = 1;
        ctx.beginPath();
        ctx.ellipse(p.x, p.y, r, r * 0.42, 0, 0, TAU);
        ctx.fillStyle = `rgba(${p.color},${(k * 0.13).toFixed(3)})`;
        ctx.fill();
        ctx.strokeStyle = `rgba(${p.color},${(k * 0.85).toFixed(3)})`;
        ctx.lineWidth = 1 + 5 * k;
        ctx.stroke();
        break;
      }
      case "slash": {
        const e = 1 - k;
        ctx.globalAlpha = k;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 2.6 * k + 0.5;
        ctx.beginPath();
        ctx.arc(p.x, py, p.size * (0.6 + e * 0.5), p.rot - 1.1 + e * 0.6, p.rot + 1.1 + e * 0.6);
        ctx.stroke();
        break;
      }
    }
  }
  ctx.globalAlpha = 1;
}

/* ------------------------------------------------------------------ */
/*  frame                                                             */
/* ------------------------------------------------------------------ */
export function renderGame(g: Game, ctx: C, S: number) {
  setSpriteRes(US * g.pxScale);
  // base transform: device scale, plus screen shake and the little zoom punch at the horn
  let bs = S;
  let btx = 0;
  let bty = 0;
  if (g.zoomPunch > 0) {
    const z = 1 + Math.sin(g.zoomPunch * Math.PI) * 0.016;
    bs = S * z;
    btx = (W / 2) * S * (1 - z);
    bty = (H / 2) * S * (1 - z);
  }
  if (g.shake > 0) {
    btx += (Math.random() * 2 - 1) * g.shake * S;
    bty += (Math.random() * 2 - 1) * g.shake * S;
  }
  ctx.setTransform(bs, 0, 0, bs, btx, bty);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.drawImage(g.bg, 0, 0, W, H);
  drawSkyLife(ctx, g.time, g.sky);

  if (g.state === "playing") {
    drawZones(g, ctx);
    drawPlans(g, ctx);
  }

  // ---- the ground: baked layer + whatever is still animating
  bakeGround(g);
  const b = g.gbox;
  if (b[0] < b[2]) {
    const q = g.gscale;
    ctx.drawImage(g.ground, b[0] * q, b[1] * q, (b[2] - b[0]) * q, (b[3] - b[1]) * q, b[0], b[1], b[2] - b[0], b[3] - b[1]);
  }
  for (const d of g.decals) {
    if (d.t > 1e8) continue;
    drawDecal(ctx, d, d.kind === "pool" ? easeOutBack(Math.min(1, d.t / 1.2)) : 1);
  }
  if (g.state === "playing") drawOrders(g, ctx);
  if (g.stuck.length) {
    ctx.strokeStyle = "#3a2a1c";
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    for (const s of g.stuck) {
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(s.x - Math.cos(s.ang) * 5, s.y - 6);
    }
    ctx.stroke();
  }

  // ---- depth-sorted entities (no allocations: units sorted in place, the rest merged in)
  let n = 0;
  const ent = (y: number, k: number, i: number) => {
    let e = ENTS[n];
    if (!e) e = ENTS[n] = { y: 0, k: 0, i: 0 };
    e.y = y;
    e.k = k;
    e.i = i;
    n++;
  };
  ent(CASTLE[0].baseY, 0, 0);
  ent(CASTLE[1].baseY, 0, 1);
  for (let i = 0; i < g.squads.length; i++) {
    const sq = g.squads[i];
    if (sq.type !== "hero" && sq.type !== "cannon") ent(sq.bannerY + 0.5, 1, i);
  }
  for (let i = 0; i < g.rags.length; i++) ent(g.rags[i].y, 2, i);
  for (let i = 1; i < n; i++) {
    const v = ENTS[i];
    let j = i - 1;
    while (j >= 0 && ENTS[j].y > v.y) {
      ENTS[j + 1] = ENTS[j];
      j--;
    }
    ENTS[j + 1] = v;
  }
  const units = g.units;
  sortUnits(units);
  let ei = 0;
  for (let ui = 0; ui <= units.length; ui++) {
    const uy = ui < units.length ? units[ui].y : Infinity;
    while (ei < n && ENTS[ei].y <= uy) {
      const e = ENTS[ei++];
      ctx.setTransform(bs, 0, 0, bs, btx, bty);
      if (e.k === 0) drawCastle(g, ctx, e.i, bs, btx, bty);
      else if (e.k === 1) drawSquadBanner(g, ctx, g.squads[e.i]);
      else {
        const r = g.rags[e.i];
        // shadow shrinks as the body rises
        ctx.fillStyle = "rgba(24,60,24,0.22)";
        ctx.beginPath();
        ctx.ellipse(r.x, r.y, (r.horse ? 12 : 6) * Math.max(0.4, 1 - r.z / 70), 2.2, 0, 0, TAU);
        ctx.fill();
        drawBody(ctx, r);
      }
    }
    if (ui < units.length) {
      const u = units[ui];
      if (u.spawnT >= 0 && !u.rag) drawUnit(g, ctx, u, bs, btx, bty);
    }
  }
  ctx.setTransform(bs, 0, 0, bs, btx, bty);
  drawOverlays(g, ctx);
  if (g.state === "playing") drawOrderBadges(g, ctx);
  drawProjectiles(g, ctx);
  drawParticles(g, ctx);

  // ---- shouts
  for (const t of g.texts) {
    const k = t.t / t.max;
    const s = easeOutElastic(Math.min(1, t.t / 0.4));
    ctx.globalAlpha = k > 0.7 ? 1 - (k - 0.7) / 0.3 : 1;
    label(ctx, t.text, t.x, t.y - k * 24, t.size * (0.4 + 0.6 * s), t.color);
  }
  ctx.globalAlpha = 1;

  if (g.state === "playing") {
    drawGuide(g, ctx);
    drawSelecting(g, ctx);
    drawAdvice(g, ctx, bs, btx, bty);
    drawPreview(g, ctx, bs, btx, bty);
  }

  if (g.phase > 0 && g.state === "playing") {
    // the edges of the screen glow as time runs out
    const hot = g.phase === 2;
    const pulse = 0.5 + 0.5 * Math.sin(g.time * (hot ? 5 : 2.5));
    const a = (hot ? 0.14 : 0.06) + pulse * (hot ? 0.1 : 0.04);
    const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, H * 1.02);
    vg.addColorStop(0, "rgba(255,120,40,0)");
    vg.addColorStop(1, `rgba(${hot ? "225,45,30" : "255,160,50"},${a.toFixed(3)})`);
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);
  }
}

export { TYPE_NAME };
