/**
 * Soldier art, modelled on the real warriors of each culture (drawn in a chunky toy style):
 *   Crusader – Templar & Hospitaller great helms over mail, sergeants in kettle hats and
 *              black surcoats, quilted gambesons, heater / kite shields and the giant pavise
 *   Ayyubid  – turban-wrapped helmets with mail aventails, lamellar jawshan, kaftans with a
 *              sash, brass daraqa shields, sabres, the crescent tabar axe and naphtha pots
 *   Viking   – Gjermundbu "spectacle" helmets (no horns – that is a myth), mail byrnies,
 *              painted round shields, Dane axes and wolf-pelt berserkers
 *   Samurai  – kabuto with kuwagata crests and menpo masks, laced do armour with sode,
 *              ashigaru in jingasa, warrior monks with naginata, matchlocks, back banners
 * A figure is described by a `Look` and drawn from parts; the result is cached as sprites
 * (one per animation frame) so a whole army costs only a handful of image blits.
 */
import { FACTIONS } from "./constants";
import type { FactionDef, FactionId, HeroKind, UnitType } from "./constants";

type C = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
const OUT = "#2b1e15";
const LW = 0.55;
const STEEL = "#e3e8ee";
const STEEL_D = "#9da6b0";
const MAIL = "#aeb6c0";
const MAIL_TEX = "rgba(52,62,76,0.5)";
const GOLD = "#f2c14e";
const BRONZE = "#cfae62";
const WOOD = "#8f5f36";
const WOOD_D = "#5f3d22";
const LACQ = "#3a2a1c";
const DARK = "#2c2b36";
const CLOTH = "#f6f1e7";
const FUR = "#7b5a3c";
const RED = "#d8343a";

type Head = "great" | "kettle" | "chaperon" | "conical" | "turbanHelm" | "turban" | "litham" | "spectacle" | "nasal" | "furcap" | "pelt" | "braids" | "kabuto" | "jingasa" | "cowl" | "hachimaki" | "shingen";
type Body = "surcoat" | "gambeson" | "kaftan" | "lamellar" | "byrnie" | "tunic" | "bare" | "do" | "okegawa" | "kimono" | "monk";
type Shield = "" | "heater" | "kite" | "pavise" | "round" | "bigRound" | "daraqa" | "januwiyya" | "tate";
type Extra = "" | "sashimono" | "cape" | "quiver" | "furcloak";
type Weapon =
  | "none" | "sword" | "greatsword" | "scimitar" | "wakizashi" | "katana" | "axe1" | "daneaxe" | "tabar" | "mace" | "naginata"
  | "spear" | "yari" | "lance" | "longbow" | "recurve" | "shortbow" | "yumi" | "xbow" | "teppo" | "javelin" | "pot";

interface Wp {
  cls: "none" | "blade" | "axe" | "club" | "pole" | "glaive" | "bow" | "xbow" | "gun" | "jav" | "pot";
  len: number;
  w: number;
  curve: number;
  two: boolean;
}
const wp = (cls: Wp["cls"], len = 0, w = 1.3, curve = 0, two = false): Wp => ({ cls, len, w, curve, two });
const WP: Record<Weapon, Wp> = {
  none: wp("none"),
  sword: wp("blade", 8.6, 1.4),
  greatsword: wp("blade", 12, 1.8, 0, true),
  scimitar: wp("blade", 8.8, 1.5, 2.4),
  wakizashi: wp("blade", 6.8, 0.95, 0.9),
  katana: wp("blade", 10.2, 1, 1.3, true),
  axe1: wp("axe", 7.6, 2.7),
  daneaxe: wp("axe", 11.5, 4.2, 0, true),
  tabar: wp("axe", 12, 4.4, 0, true),
  mace: wp("club", 10, 1.9, 0, true),
  naginata: wp("glaive", 15, 1, 0, true),
  spear: wp("pole", 16),
  yari: wp("pole", 18),
  lance: wp("pole", 19),
  longbow: wp("bow", 6.8),
  recurve: wp("bow", 5.3, 1, 1),
  shortbow: wp("bow", 4.9),
  yumi: wp("bow", 7.6, 1, 2),
  xbow: wp("xbow"),
  teppo: wp("gun"),
  javelin: wp("jav", 11),
  pot: wp("pot"),
};

export interface Look {
  id: number;
  faction: FactionId;
  f: FactionDef;
  type: UnitType;
  hero: boolean;
  heroKind?: HeroKind;
  mounted: boolean;
  cannon: boolean;
  head: Head;
  body: Body;
  shield: Shield;
  weapon: Weapon;
  wp: Wp;
  extra: Extra;
  /** main cloth / armour colour, the device painted on it, secondary armour colour */
  coat: string;
  sign: string;
  armor: string;
  mail: boolean;
  gilt: boolean;
  crest: boolean;
  pennon: boolean;
  pattern: number;
  beard: string;
  hair: string;
  skin: string;
  pants: string;
  sleeve: string;
  boot: string;
  horse: string;
  mane: string;
  cloth: "" | "capar" | "blanket" | "tassel";
  /** sprite box in figure units: origin (feet) at (ox, oy) */
  ox: number;
  oy: number;
  w: number;
  h: number;
}

interface Opt {
  coat?: string;
  sign?: string;
  armor?: string;
  mail?: boolean;
  gilt?: boolean;
  crest?: boolean;
  pennon?: boolean;
  pattern?: number;
  sleeve?: string;
  pants?: string;
  beard?: string;
  horse?: string;
  mane?: string;
  cloth?: Look["cloth"];
}
type Row = [Head, Body, Shield, Weapon, Extra, Opt?];
const STYLE: Record<FactionId, Record<string, Row>> = {
  crusader: {
    sword: ["great", "surcoat", "heater", "sword", "", { mail: true }],
    spear: ["kettle", "surcoat", "kite", "spear", "", { mail: true, coat: "#3d3d49" }],
    archer: ["chaperon", "gambeson", "", "longbow", "quiver"],
    cavalry: ["great", "surcoat", "heater", "lance", "", { mail: true, crest: true, pennon: true }],
    guard: ["kettle", "gambeson", "pavise", "sword", "", { mail: true }],
    axe: ["great", "surcoat", "", "mace", "", { mail: true, coat: "#2f2f3a", sign: "#ffffff" }],
    xbow: ["kettle", "gambeson", "", "xbow", "quiver"],
    harcher: ["conical", "gambeson", "", "recurve", "quiver", { cloth: "blanket", horse: "#b98a5a", mane: "#5a4028" }],
    cannon: ["kettle", "gambeson", "", "none", ""],
    reynald: ["great", "surcoat", "heater", "lance", "cape", { mail: true, crest: true, gilt: true, pennon: true }],
    richard: ["great", "surcoat", "", "greatsword", "cape", { mail: true, gilt: true, coat: "main", sign: GOLD }],
  },
  arab: {
    sword: ["turbanHelm", "kaftan", "daraqa", "scimitar", ""],
    spear: ["turban", "lamellar", "daraqa", "spear", "", { pennon: true }],
    archer: ["litham", "kaftan", "", "recurve", "quiver"],
    cavalry: ["turbanHelm", "lamellar", "daraqa", "lance", "", { crest: true, pennon: true }],
    guard: ["turbanHelm", "lamellar", "januwiyya", "scimitar", ""],
    axe: ["turban", "kaftan", "", "tabar", ""],
    xbow: ["litham", "kaftan", "", "pot", "", { coat: "#7a5236", sign: "#e8b84a" }],
    harcher: ["litham", "kaftan", "", "recurve", "quiver"],
    cannon: ["turban", "kaftan", "", "none", ""],
    saladin: ["turbanHelm", "kaftan", "daraqa", "scimitar", "cape", { gilt: true, crest: true, coat: "#f0c95a", sign: "#ffffff", armor: "main", horse: "#f4f1ea", mane: "#d9d2c4" }],
    zahir: ["litham", "kaftan", "", "recurve", "cape", { gilt: true }],
  },
  viking: {
    sword: ["spectacle", "byrnie", "round", "sword", ""],
    spear: ["nasal", "byrnie", "round", "spear", "", { pattern: 1 }],
    archer: ["furcap", "tunic", "", "shortbow", "quiver", { beard: "" }],
    cavalry: ["nasal", "byrnie", "round", "spear", "", { pattern: 2 }],
    guard: ["spectacle", "byrnie", "bigRound", "axe1", "", { pattern: 1 }],
    axe: ["pelt", "bare", "", "daneaxe", "", { sleeve: "skin" }],
    xbow: ["furcap", "tunic", "", "javelin", "furcloak"],
    harcher: ["furcap", "tunic", "", "shortbow", "quiver"],
    cannon: ["furcap", "tunic", "", "none", ""],
    ragnar: ["spectacle", "byrnie", "", "daneaxe", "furcloak", { gilt: true }],
    lagertha: ["braids", "byrnie", "round", "spear", "cape", { beard: "", pattern: 1 }],
  },
  samurai: {
    sword: ["kabuto", "do", "", "katana", "sashimono"],
    spear: ["jingasa", "okegawa", "", "yari", "sashimono"],
    archer: ["jingasa", "kimono", "", "yumi", "quiver", { sleeve: CLOTH }],
    cavalry: ["kabuto", "do", "", "yari", "sashimono"],
    guard: ["jingasa", "okegawa", "tate", "wakizashi", ""],
    axe: ["cowl", "monk", "", "naginata", "", { sleeve: "#f3ead6", pants: "#f3ead6" }],
    xbow: ["jingasa", "okegawa", "", "teppo", ""],
    harcher: ["kabuto", "do", "", "yumi", "quiver"],
    cannon: ["jingasa", "kimono", "", "none", "", { sleeve: CLOTH }],
    takeda: ["shingen", "do", "", "katana", "cape", { coat: "#a8312f", sign: GOLD, horse: "#3a2a22" }],
    tomoe: ["hachimaki", "kimono", "", "yumi", "quiver", { sleeve: CLOTH }],
  },
};
const MOUNTED = new Set(["cavalry", "harcher", "reynald", "saladin", "zahir", "takeda"]);
interface Skin {
  skin: string;
  pants: string;
  sleeve: string;
  boot: string;
  beard: string;
  hair: string;
  horse: string;
  mane: string;
  cloth: Look["cloth"];
}
const SKIN: Record<FactionId, Skin> = {
  crusader: { skin: "#f0c6a0", pants: "#6f6a62", sleeve: "main", boot: "#4a3526", beard: "", hair: "#8a5a2c", horse: "#f4f1ea", mane: "#cfc8ba", cloth: "capar" },
  arab: { skin: "#d9a877", pants: "#f1e9d6", sleeve: "main", boot: "#7a4a2a", beard: "#3a2a20", hair: "#2a1d14", horse: "#a8683c", mane: "#3a2a20", cloth: "blanket" },
  viking: { skin: "#f5d2b0", pants: "#6b4a2f", sleeve: "main", boot: "#4a3526", beard: "#e08a2c", hair: "#e3b35c", horse: "#b89a6a", mane: "#5a4028", cloth: "" },
  samurai: { skin: "#f1c79e", pants: "#2f3350", sleeve: "main", boot: "#1f1a17", beard: "", hair: "#1f1a17", horse: "#34302f", mane: "#151212", cloth: "tassel" },
};

const LOOKS = new Map<string, Look>();
let nextLook = 1;

export function getLook(faction: FactionId, type: UnitType, hero?: HeroKind): Look {
  const key = faction + ":" + (hero ?? type);
  let k = LOOKS.get(key);
  if (k) return k;
  const f = FACTIONS[faction];
  const row = STYLE[faction][hero ?? type] ?? STYLE[faction].sword;
  const o: Opt = row[5] ?? {};
  const s = SKIN[faction];
  const col = (v: string | undefined, d: string) => (v === undefined ? d : v === "main" ? f.main : v === "skin" ? s.skin : v);
  const body = row[1];
  const mounted = MOUNTED.has(hero ?? type);
  const big = mounted || type === "cannon";
  const mail = !!o.mail;
  const coat = col(o.coat, body === "surcoat" ? CLOTH : body === "do" ? DARK : body === "okegawa" ? "#35353f" : f.main);
  k = {
    id: nextLook++,
    faction,
    f,
    type,
    hero: !!hero,
    heroKind: hero,
    mounted,
    cannon: type === "cannon",
    head: row[0],
    body,
    shield: row[2],
    weapon: row[3],
    wp: WP[row[3]],
    extra: row[4],
    coat,
    sign: col(o.sign, body === "surcoat" || body === "do" ? f.main : GOLD),
    armor: col(o.armor, body === "lamellar" ? BRONZE : "#e8b84a"),
    mail,
    gilt: !!o.gilt,
    crest: !!o.crest,
    pennon: !!o.pennon,
    pattern: o.pattern ?? 0,
    skin: s.skin,
    pants: mail ? MAIL : col(o.pants, s.pants),
    sleeve: mail ? MAIL : col(o.sleeve, body === "kaftan" ? coat : col(s.sleeve, f.main)),
    boot: s.boot,
    beard: o.beard ?? s.beard,
    hair: s.hair,
    horse: o.horse ?? s.horse,
    mane: o.mane ?? s.mane,
    cloth: o.cloth ?? s.cloth,
    ox: 15,
    oy: big ? 35 : 30,
    w: big ? 50 : 42,
    h: big ? 39 : 34,
  };
  LOOKS.set(key, k);
  return k;
}

/* ------------------------------------------------------------------ */
/*  drawing primitives (all outlined)                                 */
/* ------------------------------------------------------------------ */
function poly(c: C, p: number[], fill: string) {
  c.beginPath();
  c.moveTo(p[0], p[1]);
  for (let i = 2; i < p.length; i += 2) c.lineTo(p[i], p[i + 1]);
  c.closePath();
  c.fillStyle = fill;
  c.fill();
  c.stroke();
}
function rrect(c: C, x: number, y: number, w: number, h: number, r: number, fill: string) {
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
  c.fillStyle = fill;
  c.fill();
  c.stroke();
}
function oval(c: C, x: number, y: number, rx: number, ry: number, fill: string) {
  c.beginPath();
  c.ellipse(x, y, rx, ry, 0, 0, TAU);
  c.fillStyle = fill;
  c.fill();
  c.stroke();
}
function dome(c: C, x: number, y: number, r: number, fill: string) {
  c.beginPath();
  c.arc(x, y, r, Math.PI, 0);
  c.closePath();
  c.fillStyle = fill;
  c.fill();
  c.stroke();
}
function dot(c: C, x: number, y: number, r: number, fill: string) {
  c.beginPath();
  c.arc(x, y, r, 0, TAU);
  c.fillStyle = fill;
  c.fill();
}
function bar(c: C, x: number, y: number, w: number, h: number, fill: string) {
  c.fillStyle = fill;
  c.fillRect(x, y, w, h);
}
/** thick outlined line: limbs and shafts (mail = rows of rings drawn over it) */
function limb(c: C, x0: number, y0: number, x1: number, y1: number, col: string, w: number, mail = false) {
  c.beginPath();
  c.moveTo(x0, y0);
  c.lineTo(x1, y1);
  c.strokeStyle = OUT;
  c.lineWidth = w + LW * 2;
  c.stroke();
  c.strokeStyle = col;
  c.lineWidth = w;
  c.stroke();
  if (mail) {
    c.lineCap = "butt";
    c.setLineDash([0.4, 0.75]);
    c.strokeStyle = MAIL_TEX;
    c.lineWidth = w * 0.92;
    c.stroke();
    c.setLineDash([]);
    c.lineCap = "round";
  }
  c.strokeStyle = OUT;
  c.lineWidth = LW;
}
function seg(c: C, x0: number, y0: number, x1: number, y1: number, col: string, w: number) {
  c.beginPath();
  c.moveTo(x0, y0);
  c.lineTo(x1, y1);
  c.strokeStyle = col;
  c.lineWidth = w;
  c.stroke();
  c.strokeStyle = OUT;
  c.lineWidth = LW;
}
function crescent(c: C, x: number, y: number, s: number, col: string) {
  c.beginPath();
  c.arc(x - 0.1 * s, y, 0.9 * s, 0, TAU);
  c.arc(x + 0.24 * s, y, 0.72 * s, 0, TAU);
  c.fillStyle = col;
  c.fill("evenodd");
}

/* ------------------------------------------------------------------ */
/*  torsos                                                            */
/* ------------------------------------------------------------------ */
function drawBody(c: C, k: Look) {
  const m = k.f.main;
  switch (k.body) {
    case "surcoat":
      // sleeveless surcoat over mail, split for riding
      poly(c, [-3.3, -6.6, 3.3, -6.6, 3.9, -2.5, 0.7, -2.5, 0.2, -4.4, -0.3, -2.5, -3.7, -2.5], k.coat);
      rrect(c, -3.3, -12.3, 6.6, 7.2, 2.2, k.coat);
      if (k.heroKind === "richard") {
        // three golden lions passant
        for (const y of [-11.3, -9.7, -8.1]) {
          bar(c, -1.8, y, 3.4, 0.85, k.sign);
          dot(c, 2, y + 0.4, 0.6, k.sign);
        }
      } else {
        bar(c, -0.55, -11.5, 1.3, 6.4, k.sign);
        bar(c, -2.2, -9.8, 4.6, 1.3, k.sign);
      }
      seg(c, -3.2, -5.6, 3.2, -5.6, WOOD_D, 0.85);
      break;
    case "gambeson":
      // quilted padded jack
      rrect(c, -3.3, -12.3, 6.6, 8.8, 2, m);
      for (const x of [-1.9, -0.5, 0.9, 2.3]) seg(c, x, -11.7, x, -4.1, k.f.dark, 0.35);
      seg(c, -3.2, -6.3, 3.2, -6.3, WOOD_D, 0.9);
      rrect(c, 1.3, -6.1, 1.7, 1.9, 0.3, WOOD);
      break;
    case "kaftan":
      poly(c, [-3.3, -7.2, 3.3, -7.2, 4.3, -2.2, -4.1, -2.2], k.coat);
      rrect(c, -3.3, -12.3, 6.6, 7, 2.2, k.coat);
      seg(c, 1, -11.8, 1, -2.7, k.sign, 0.5);
      seg(c, -3.9, -2.9, 4.1, -2.9, k.sign, 0.5);
      rrect(c, -3.5, -7.5, 7, 1.7, 0.5, k.armor);
      poly(c, [-2.7, -6, -1.3, -6, -1.6, -3.5, -3, -3.4], k.armor);
      break;
    case "lamellar":
      // jawshan: rows of small laced plates over a robe
      poly(c, [-3.3, -6.6, 3.3, -6.6, 4.1, -2.3, -3.9, -2.3], k.coat);
      rrect(c, -3.5, -12.4, 7, 7.6, 1.4, k.armor);
      for (const y of [-10.9, -9.4, -7.9, -6.4]) seg(c, -3.3, y, 3.3, y, "rgba(70,50,20,0.6)", 0.35);
      for (const x of [-2.2, -0.7, 0.8, 2.3]) seg(c, x, -12.1, x, -5.1, "rgba(70,50,20,0.3)", 0.3);
      seg(c, -3.4, -5, 3.4, -5, m, 1.1);
      break;
    case "byrnie":
      // short mail shirt over a wool tunic
      poly(c, [-3.3, -5.6, 3.3, -5.6, 3.8, -2.9, -3.7, -2.9], m);
      seg(c, -3.5, -3.3, 3.6, -3.3, k.f.accent, 0.5);
      rrect(c, -3.4, -12.3, 6.8, 7.6, 2, MAIL);
      c.setLineDash([0.6, 0.6]);
      for (const y of [-11, -9.8, -8.6, -7.4, -6.2]) seg(c, -3, y, 3, y, MAIL_TEX, 0.45);
      c.setLineDash([]);
      seg(c, -3.3, -5.3, 3.3, -5.3, WOOD_D, 0.9);
      dot(c, 0.4, -5.3, 0.6, GOLD);
      break;
    case "tunic":
      rrect(c, -3.3, -12.3, 6.6, 8.8, 2.1, m);
      seg(c, -3.1, -4.1, 3.1, -4.1, k.f.accent, 0.7);
      seg(c, -0.6, -12, 1.2, -10.2, k.f.accent, 0.6);
      seg(c, -3.2, -6.4, 3.2, -6.4, WOOD_D, 0.9);
      rrect(c, -2.6, -6.2, 1.6, 1.9, 0.3, WOOD);
      break;
    case "bare":
      // woad war paint and a fur kilt
      rrect(c, -3.3, -12.3, 6.6, 8.4, 2.2, k.skin);
      seg(c, -1.6, -11, 2.2, -8.6, m, 0.8);
      seg(c, -2.1, -9.3, 1.6, -7.3, m, 0.8);
      seg(c, -2.8, -12, 2.6, -6.8, WOOD_D, 0.6);
      rrect(c, -3.4, -7, 6.8, 3, 1, FUR);
      break;
    case "do":
      // laced cuirass, tassets and big shoulder plates
      poly(c, [-3.6, -5.8, 3.6, -5.8, 4.5, -2.4, -4.3, -2.4], k.coat);
      bar(c, -3.95, -4.75, 8, 0.7, k.sign);
      bar(c, -4.15, -3.35, 8.4, 0.7, k.sign);
      rrect(c, -3.4, -12.3, 6.8, 7, 1.4, k.coat);
      for (const y of [-10.9, -9.3, -7.7]) bar(c, -3.1, y, 6.2, 0.75, k.sign);
      for (const x of [-4.7, 2]) {
        rrect(c, x, -12.7, 2.7, 3.9, 0.5, k.coat);
        bar(c, x + 0.2, -11.3, 2.3, 0.6, k.sign);
        bar(c, x + 0.2, -10, 2.3, 0.6, k.sign);
      }
      seg(c, -3.3, -5.9, 3.3, -5.9, "#f1e9d6", 0.8);
      break;
    case "okegawa":
      // the foot soldier's plain riveted cuirass with the clan's mon
      poly(c, [-3.4, -5.4, 3.4, -5.4, 4, -2.9, -3.9, -2.9], k.coat);
      seg(c, -3.7, -4, 3.8, -4, m, 0.6);
      rrect(c, -3.3, -12.3, 6.6, 7.2, 1.6, k.coat);
      oval(c, 0.3, -8.8, 1.3, 1.3, GOLD);
      seg(c, -3.3, -5.6, 3.3, -5.6, m, 1.1);
      break;
    case "kimono":
      rrect(c, -3.3, -12.3, 6.6, 6, 2, CLOTH);
      poly(c, [-3.3, -8.2, 3.3, -8.2, 4, -2.5, -3.8, -2.5], m);
      seg(c, -0.6, -12, 1.4, -8.4, m, 0.7);
      seg(c, 0.3, -7.8, 0.2, -2.9, k.f.dark, 0.45);
      break;
    case "monk":
      // warrior monk: white robes over armour, saffron sash
      poly(c, [-3.4, -8, 3.4, -8, 4.4, -2.2, -4.2, -2.2], "#f3ead6");
      rrect(c, -3.3, -12.3, 6.6, 6, 2, "#f3ead6");
      rrect(c, -2.3, -10.8, 4.8, 3.6, 0.6, DARK);
      bar(c, -2, -9.6, 4.2, 0.7, m);
      seg(c, -3.3, -6.7, 3.3, -6.7, "#e8a33a", 1.2);
      break;
  }
}

/* ------------------------------------------------------------------ */
/*  heads                                                             */
/* ------------------------------------------------------------------ */
function drawHead(c: C, k: Look, x: number, y: number) {
  const m = k.f.main;
  const h = k.head;
  const helm = k.gilt ? GOLD : STEEL;
  // ---- behind the face
  switch (h) {
    case "kettle":
      oval(c, x - 0.3, y + 0.5, 3.8, 3.7, MAIL); // mail coif
      break;
    case "conical":
      poly(c, [x - 2.8, y - 0.6, x - 4.8, y + 3.8, x - 2, y + 3.4], CLOTH);
      break;
    case "turbanHelm":
      poly(c, [x - 3.6, y - 1, x - 4.5, y + 3.9, x - 0.6, y + 4.1, x - 1.2, y - 0.4], MAIL); // aventail
      break;
    case "kabuto":
      poly(c, [x - 3.3, y - 1.2, x - 6.2, y + 3, x - 1.4, y + 2.8, x - 1, y - 0.4], k.coat); // shikoro neck guard
      seg(c, x - 5, y + 1.7, x - 1.7, y + 1.6, k.sign, 0.7);
      break;
    case "shingen":
      poly(c, [x - 2.8, y - 4.6, x - 7.4, y - 2.4, x - 7.8, y + 3.6, x - 5.1, y + 1.2, x - 4.3, y + 5.2, x - 2, y + 1.6], "#f6f3ea"); // yak-hair mane
      break;
    case "spectacle":
    case "nasal":
      poly(c, [x - 2.6, y - 0.6, x - 4.9, y + (k.hero ? 6.6 : 4), x - 2.4, y + 3.8], k.hair);
      break;
    case "pelt":
      poly(c, [x - 3.2, y - 2, x - 5.4, y + 5.8, x - 1.4, y + 4.4, x - 1.2, y - 0.6], FUR);
      break;
    case "braids":
      poly(c, [x - 2.4, y - 1.8, x - 4.6, y + 2, x - 3.8, y + 7.8, x - 2.2, y + 3], k.hair);
      seg(c, x - 4.2, y + 3.4, x - 2.8, y + 3, m, 0.6);
      seg(c, x - 4, y + 5.6, x - 2.9, y + 5.2, m, 0.6);
      break;
    case "hachimaki":
      poly(c, [x - 2.4, y - 2.4, x - 6.6, y + 1.4, x - 5.6, y + 7, x - 3, y + 2.4], k.hair);
      break;
    case "cowl":
      poly(c, [x - 3.6, y - 1.6, x - 4.9, y + 4.9, x + 0.8, y + 4.7, x + 0.2, y + 1], CLOTH);
      break;
  }
  // ---- face
  if (h !== "great") {
    c.beginPath();
    c.arc(x, y, 3.4, 0, TAU);
    c.fillStyle = k.skin;
    c.fill();
    c.stroke();
    if (h === "pelt") seg(c, x + 0.5, y - 1.2, x + 3.3, y + 0.5, m, 0.7); // war paint
    dot(c, x + 1.9, y - 0.1, 0.55, OUT);
    if (k.beard && h !== "litham" && h !== "cowl") {
      poly(c, [x - 0.4, y + 1.5, x + 3.4, y + 0.9, x + 2.7, y + 4.3, x + 0.4, y + 4.6], k.beard);
      if (k.faction === "viking") seg(c, x + 0.9, y + 3.7, x + 2.5, y + 3.5, GOLD, 0.5); // braided, with a ring
    }
  }
  switch (h) {
    case "great":
      rrect(c, x - 3.7, y - 4.3, 7.6, 7.8, 1.2, STEEL);
      bar(c, x - 3.2, y - 3.9, 6.6, 1, k.gilt ? GOLD : "#f6f9fb");
      bar(c, x + 0.1, y - 1.3, 3.7, 0.95, OUT);
      bar(c, x + 1.7, y - 1.3, 0.85, 3.5, OUT);
      dot(c, x - 1.6, y + 1.6, 0.35, OUT);
      dot(c, x - 0.4, y + 1.6, 0.35, OUT);
      if (k.heroKind === "richard") poly(c, [x - 3.6, y - 4.3, x - 3.6, y - 6.6, x - 2, y - 5.3, x - 0.4, y - 7, x + 1.2, y - 5.3, x + 2.7, y - 7, x + 3.8, y - 5.1, x + 3.8, y - 4.3], GOLD);
      else if (k.crest) poly(c, [x - 0.4, y - 4.6, x - 3.4, y - 10.2, x - 6.2, y - 7.2, x - 3.2, y - 4.8], m);
      break;
    case "kettle":
      dome(c, x, y - 1.3, 3.5, STEEL);
      oval(c, x, y - 1.3, 5.2, 1.1, STEEL_D);
      break;
    case "chaperon":
      poly(c, [x + 2.9, y - 1.7, x + 1.2, y - 4.3, x - 2.2, y - 4.3, x - 4.9, y + 1.2, x - 3, y + 3.7, x - 2.3, y - 0.4], k.f.dark);
      break;
    case "conical":
      c.beginPath();
      c.moveTo(x - 3.6, y - 1);
      c.quadraticCurveTo(x - 3, y - 5, x + 0.2, y - 6.6);
      c.quadraticCurveTo(x + 3.2, y - 5, x + 3.7, y - 1);
      c.closePath();
      c.fillStyle = STEEL;
      c.fill();
      c.stroke();
      rrect(c, x - 3.8, y - 1.7, 7.6, 1.1, 0.3, STEEL_D);
      rrect(c, x + 2.4, y - 1.3, 0.95, 2.9, 0.3, STEEL_D);
      break;
    case "turbanHelm":
      c.beginPath();
      c.moveTo(x - 3.5, y - 1.4);
      c.quadraticCurveTo(x - 3, y - 5.4, x, y - 6.9);
      c.quadraticCurveTo(x + 3, y - 5.4, x + 3.5, y - 1.4);
      c.closePath();
      c.fillStyle = helm;
      c.fill();
      c.stroke();
      oval(c, x - 0.1, y - 1.9, 4.3, 1.75, k.hero ? "#fff7da" : CLOTH); // turban wound round the brim
      seg(c, x - 3.2, y - 2.3, x - 0.6, y - 1.2, "#cfc6b4", 0.4);
      seg(c, x + 0.4, y - 2.9, x + 3.2, y - 1.6, "#cfc6b4", 0.4);
      seg(c, x, y - 6.9, x, y - 9, STEEL_D, 0.75);
      dot(c, x, y - 9.2, 0.6, GOLD);
      if (k.crest) poly(c, [x - 0.3, y - 8.6, x - 3.6, y - 11.6, x - 5.6, y - 8.2, x - 2.6, y - 7.6], m);
      break;
    case "turban":
      oval(c, x - 0.2, y - 2.4, 4.1, 2.8, "#f8f4ea");
      seg(c, x - 3.4, y - 2.1, x + 3.2, y - 3.6, "#cfc6b4", 0.4);
      seg(c, x - 3.3, y - 0.8, x + 3.6, y - 2.3, "#cfc6b4", 0.4);
      poly(c, [x - 3.3, y - 1.2, x - 5.3, y + 3, x - 3.6, y + 2.7], "#f8f4ea");
      dot(c, x + 2.5, y - 3, 0.9, m);
      break;
    case "litham": {
      const cl = k.gilt ? "#fff7da" : "#f3ead6";
      poly(c, [x + 3.3, y - 2.3, x + 1, y - 4.4, x - 2.6, y - 4.1, x - 4.3, y - 0.5, x - 4.7, y + 4.4, x - 1.6, y + 3.9, x - 1.8, y - 0.6], cl);
      poly(c, [x + 0.2, y + 0.7, x + 3.5, y + 0.5, x + 3.1, y + 3.5, x + 0.3, y + 3.8], cl); // veil over the mouth
      seg(c, x - 3.7, y - 2.6, x + 3.3, y - 2.6, k.gilt ? GOLD : OUT, 0.85);
      break;
    }
    case "spectacle":
      dome(c, x, y - 0.9, 3.6, helm);
      seg(c, x, y - 4.5, x, y - 1.6, OUT, 0.35);
      dot(c, x, y - 4.6, 0.5, STEEL_D);
      rrect(c, x - 3.8, y - 1.6, 7.6, 1, 0.3, STEEL_D);
      // the "spectacle" guard round the eyes
      c.beginPath();
      c.ellipse(x + 2.1, y - 0.2, 1.75, 1.3, 0, 0, TAU);
      c.fillStyle = STEEL_D;
      c.fill();
      c.stroke();
      dot(c, x + 2.2, y - 0.15, 0.62, OUT);
      break;
    case "nasal":
      c.beginPath();
      c.moveTo(x - 3.6, y - 1);
      c.quadraticCurveTo(x - 3.2, y - 4.6, x, y - 5.6);
      c.quadraticCurveTo(x + 3.2, y - 4.6, x + 3.6, y - 1);
      c.closePath();
      c.fillStyle = STEEL;
      c.fill();
      c.stroke();
      rrect(c, x - 3.8, y - 1.6, 7.6, 1, 0.3, STEEL_D);
      seg(c, x, y - 5.4, x, y - 1.6, OUT, 0.35);
      rrect(c, x + 2.4, y - 1.3, 0.95, 2.9, 0.3, STEEL_D);
      break;
    case "furcap":
      oval(c, x - 0.1, y - 2.5, 4.1, 2.7, FUR);
      seg(c, x - 2.4, y - 3.2, x - 2, y - 2.2, WOOD_D, 0.4);
      seg(c, x + 0.2, y - 3.6, x + 0.4, y - 2.6, WOOD_D, 0.4);
      seg(c, x + 2.4, y - 3, x + 2.2, y - 2, WOOD_D, 0.4);
      break;
    case "pelt":
      // a wolf's skin worn over the head (ulfhednar)
      dome(c, x - 0.1, y - 0.8, 3.9, FUR);
      poly(c, [x - 3.5, y - 3.2, x - 3.1, y - 6.4, x - 1.3, y - 4.3], FUR);
      poly(c, [x + 0.9, y - 4.4, x + 2.5, y - 6.5, x + 3.1, y - 3.4], FUR);
      poly(c, [x + 1.2, y - 2.7, x + 4.9, y - 1.9, x + 4.1, y - 0.8, x + 1.2, y - 0.9], FUR);
      dot(c, x + 4.5, y - 1.7, 0.45, OUT);
      dot(c, x + 1.1, y - 2.9, 0.4, OUT);
      poly(c, [x + 2.9, y - 0.9, x + 3.3, y + 0.1, x + 3.7, y - 0.9], "#ffffff");
      break;
    case "braids":
      c.beginPath();
      c.arc(x - 0.2, y - 0.6, 3.6, Math.PI * 1.02, -0.15);
      c.closePath();
      c.fillStyle = k.hair;
      c.fill();
      c.stroke();
      seg(c, x - 3.5, y - 1.5, x + 3.4, y - 1.9, STEEL, 0.95);
      dot(c, x + 1.5, y - 1.8, 0.55, GOLD);
      break;
    case "kabuto":
      dome(c, x, y - 0.8, 3.7, k.coat);
      poly(c, [x + 1.3, y - 1.5, x + 4.9, y - 0.9, x + 1.6, y - 0.2], k.coat); // visor
      if (k.type !== "harcher") poly(c, [x + 0.5, y + 0.5, x + 3.5, y + 0.1, x + 3, y + 3.1, x + 0.9, y + 3.2], "#8a2424"); // menpo mask
      // kuwagata crest
      poly(c, [x + 1.1, y - 3.9, x - 0.9, y - 9.2, x + 0.4, y - 4.5], GOLD);
      poly(c, [x + 2.4, y - 3.7, x + 5.2, y - 8.3, x + 3, y - 4.5], GOLD);
      dot(c, x + 1.8, y - 3.5, 0.75, GOLD);
      break;
    case "shingen":
      dome(c, x, y - 0.8, 3.7, "#7a2222");
      poly(c, [x + 1.3, y - 1.5, x + 4.9, y - 0.9, x + 1.6, y - 0.2], "#7a2222");
      poly(c, [x + 0.5, y + 0.5, x + 3.5, y + 0.1, x + 3, y + 3.1, x + 0.9, y + 3.2], "#8a2424");
      oval(c, x - 0.8, y - 3.9, 3.7, 1.9, "#f6f3ea");
      poly(c, [x + 0.9, y - 4.4, x - 1.8, y - 11.2, x + 0.4, y - 5.2], GOLD);
      poly(c, [x + 2.5, y - 4.2, x + 6, y - 10.4, x + 3.3, y - 5], GOLD);
      break;
    case "jingasa":
      poly(c, [x - 5.5, y - 1.3, x, y - 5.1, x + 5.5, y - 1.3], DARK);
      seg(c, x - 5.2, y - 1.3, x + 5.2, y - 1.3, GOLD, 0.6);
      dot(c, x + 0.5, y - 2.7, 0.75, GOLD);
      break;
    case "cowl":
      // the sohei's white head wrap: only the eyes show
      c.beginPath();
      c.moveTo(x - 3.9, y + 0.6);
      c.quadraticCurveTo(x - 4.2, y - 4.8, x + 0.2, y - 4.9);
      c.quadraticCurveTo(x + 4, y - 4.6, x + 3.9, y - 1.3);
      c.lineTo(x + 0.4, y - 1.5);
      c.lineTo(x - 0.8, y + 0.8);
      c.closePath();
      c.fillStyle = CLOTH;
      c.fill();
      c.stroke();
      poly(c, [x + 0.3, y + 1, x + 3.6, y + 0.7, x + 3.2, y + 3.5, x + 0.4, y + 3.9], CLOTH);
      seg(c, x - 2.6, y - 3.2, x + 1.6, y - 3.9, "#d9d0bd", 0.4);
      break;
    case "hachimaki":
      c.beginPath();
      c.arc(x - 0.2, y - 0.6, 3.6, Math.PI * 1.02, -0.15);
      c.closePath();
      c.fillStyle = k.hair;
      c.fill();
      c.stroke();
      seg(c, x - 3.5, y - 1.5, x + 3.4, y - 1.9, "#ffffff", 0.95);
      seg(c, x - 3.5, y - 1.5, x - 5.8, y - 0.3, "#ffffff", 0.7);
      dot(c, x + 1.6, y - 1.8, 0.5, m);
      break;
  }
}

/* ------------------------------------------------------------------ */
/*  shields                                                           */
/* ------------------------------------------------------------------ */
function drawShield(c: C, k: Look, x: number, y: number) {
  const m = k.f.main;
  switch (k.shield) {
    case "heater":
      c.beginPath();
      c.moveTo(x - 2.7, y - 3.3);
      c.lineTo(x + 2.7, y - 3.3);
      c.lineTo(x + 2.7, y + 0.6);
      c.quadraticCurveTo(x + 2.2, y + 3.4, x, y + 4.5);
      c.quadraticCurveTo(x - 2.2, y + 3.4, x - 2.7, y + 0.6);
      c.closePath();
      c.fillStyle = CLOTH;
      c.fill();
      c.stroke();
      bar(c, x - 0.65, y - 3, 1.3, 6.8, m);
      bar(c, x - 2.4, y - 1.5, 4.8, 1.3, m);
      break;
    case "kite":
      c.beginPath();
      c.moveTo(x - 2.5, y - 2.6);
      c.quadraticCurveTo(x, y - 4.7, x + 2.5, y - 2.6);
      c.quadraticCurveTo(x + 2.3, y + 2.5, x, y + 6.2);
      c.quadraticCurveTo(x - 2.3, y + 2.5, x - 2.5, y - 2.6);
      c.closePath();
      c.fillStyle = m;
      c.fill();
      c.stroke();
      bar(c, x - 0.55, y - 3.4, 1.1, 8.2, CLOTH);
      bar(c, x - 2.1, y - 1.6, 4.2, 1.1, CLOTH);
      break;
    case "pavise":
      rrect(c, x - 2.2, y - 5.6, 6.2, 12.8, 1.7, CLOTH);
      bar(c, x - 1.9, y - 5.3, 5.6, 1.1, m);
      bar(c, x - 1.9, y + 5.8, 5.6, 1.1, m);
      bar(c, x + 0.25, y - 3.6, 1.4, 8.8, m);
      bar(c, x - 1.6, y - 0.6, 5, 1.4, m);
      break;
    case "daraqa":
      // brass shield with a boss, rivets and a tassel
      oval(c, x, y, 3.8, 3.8, BRONZE);
      c.beginPath();
      c.arc(x, y, 2.5, 0, TAU);
      c.stroke();
      oval(c, x, y, 1.15, 1.15, GOLD);
      for (let i = 0; i < 4; i++) dot(c, x + Math.cos(i * 1.571 + 0.78) * 3.1, y + Math.sin(i * 1.571 + 0.78) * 3.1, 0.4, OUT);
      seg(c, x, y + 3.8, x, y + 5.6, m, 0.7);
      break;
    case "januwiyya":
      // tall kite shield with a flat foot that stands on the ground
      c.beginPath();
      c.moveTo(x - 2.2, y - 5.2);
      c.quadraticCurveTo(x + 1, y - 7, x + 4.2, y - 5.2);
      c.lineTo(x + 3.7, y + 6.8);
      c.lineTo(x - 1.7, y + 6.8);
      c.closePath();
      c.fillStyle = m;
      c.fill();
      c.stroke();
      bar(c, x - 1.9, y - 3.4, 5.9, 0.8, GOLD);
      bar(c, x - 1.6, y + 4.6, 5.2, 0.8, GOLD);
      crescent(c, x + 1, y + 0.6, 1.9, GOLD);
      break;
    case "round":
    case "bigRound": {
      const big = k.shield === "bigRound";
      const r = big ? 5.1 : 3.8;
      const cx = big ? x + 0.5 : x;
      const cy = big ? y + 0.6 : y;
      oval(c, cx, cy, r, r, m);
      c.fillStyle = "#f1e3bd";
      if (k.pattern === 1) {
        // quartered
        for (const a of [-Math.PI / 2, Math.PI / 2]) {
          c.beginPath();
          c.moveTo(cx, cy);
          c.arc(cx, cy, r - 0.3, a, a + Math.PI / 2);
          c.closePath();
          c.fill();
        }
      } else if (k.pattern === 2) {
        for (let i = 0; i < 4; i++) seg(c, cx, cy, cx + Math.cos(i * 1.571 + 0.5) * (r - 0.6), cy + Math.sin(i * 1.571 + 0.5) * (r - 0.6), "#f1e3bd", 1.1);
      } else {
        c.beginPath();
        c.arc(cx, cy, r - 0.3, -Math.PI / 2, Math.PI / 2);
        c.closePath();
        c.fill();
      }
      c.beginPath();
      c.arc(cx, cy, r, 0, TAU);
      c.stroke();
      oval(c, cx, cy, r * 0.3, r * 0.3, STEEL_D);
      break;
    }
    case "tate":
      rrect(c, x - 1.8, y - 5.8, 5.8, 13, 0.5, "#c19a63");
      bar(c, x - 1.8, y - 5.8, 5.8, 1.3, DARK);
      seg(c, x + 1.1, y - 4.4, x + 1.1, y + 7, WOOD_D, 0.35);
      dot(c, x + 1.1, y - 0.2, 1.9, m);
      dot(c, x + 1.1, y - 0.2, 0.8, "#ffffff");
      break;
  }
}

/* ------------------------------------------------------------------ */
/*  weapons (own frame: grip at the origin, business end towards -y)   */
/* ------------------------------------------------------------------ */
function drawWp(c: C, k: Look) {
  const w = k.wp;
  const L = w.len;
  switch (w.cls) {
    case "blade":
      seg(c, 0, w.two ? 3.3 : 2.1, 0, 0, WOOD_D, 1.15);
      if (k.weapon === "katana" || k.weapon === "wakizashi") oval(c, 0, -0.2, 1.15, 0.6, GOLD);
      else rrect(c, -1.6, -0.6, 3.2, 1, 0.3, GOLD);
      c.beginPath();
      if (w.curve === 0) {
        c.moveTo(-w.w / 2, -0.5);
        c.lineTo(w.w / 2, -0.5);
        c.lineTo(w.w / 2, -L + 1.5);
        c.lineTo(0, -L);
        c.lineTo(-w.w / 2, -L + 1.5);
      } else {
        c.moveTo(-w.w / 2, -0.5);
        c.quadraticCurveTo(-w.w / 2 + w.curve * 0.15, -L * 0.55, w.curve, -L);
        c.quadraticCurveTo(w.w * 0.75 + w.curve * 0.5, -L * 0.5, w.w / 2, -0.5);
      }
      c.closePath();
      c.fillStyle = STEEL;
      c.fill();
      c.stroke();
      if (w.curve === 0) seg(c, 0, -1.2, 0, -L + 2.2, STEEL_D, 0.35);
      break;
    case "axe":
      limb(c, 0, w.two ? 3.2 : 2.2, 0, -L, WOOD, 0.95);
      if (k.weapon === "tabar") {
        // crescent blade with a spike
        c.beginPath();
        c.moveTo(0.4, -L + 0.4);
        c.quadraticCurveTo(5.6, -L - 1.8, 4.4, -L + 4.8);
        c.quadraticCurveTo(2.8, -L + 2.6, 0.4, -L + 3.4);
        c.closePath();
        c.fillStyle = STEEL;
        c.fill();
        c.stroke();
        poly(c, [-0.5, -L + 0.2, 0, -L - 2.2, 0.5, -L + 0.2], STEEL_D);
      } else {
        // bearded axe / Dane axe
        const h = w.w;
        poly(c, [0.4, -L + 0.3, h, -L - 0.7, h + 0.5, -L + h * 0.85, 0.4, -L + h * 0.5 + 0.3], STEEL);
      }
      break;
    case "club":
      // flanged mace
      limb(c, 0, 3.2, 0, -L + 1, WOOD, 0.95);
      oval(c, 0, -L, w.w, w.w, STEEL_D);
      for (let i = 0; i < 6; i++) seg(c, Math.cos(i * 1.047) * w.w, -L + Math.sin(i * 1.047) * w.w, Math.cos(i * 1.047) * (w.w + 0.9), -L + Math.sin(i * 1.047) * (w.w + 0.9), OUT, 0.5);
      break;
    case "glaive":
      // naginata
      limb(c, 0, 3.4, 0, -L + 4.2, LACQ, 0.8);
      c.beginPath();
      c.moveTo(-0.6, -L + 4.2);
      c.quadraticCurveTo(-0.5, -L + 1.2, 1.7, -L - 1.2);
      c.quadraticCurveTo(1.7, -L + 2.2, 0.7, -L + 4.2);
      c.closePath();
      c.fillStyle = STEEL;
      c.fill();
      c.stroke();
      oval(c, 0, -L + 4.4, 1.15, 0.55, GOLD);
      break;
    case "pole":
    case "jav": {
      const up = L * (w.cls === "jav" ? 0.55 : 0.62);
      limb(c, 0, L - up, 0, -up, k.faction === "samurai" ? LACQ : WOOD, w.cls === "jav" ? 0.6 : 0.8);
      poly(c, [-0.95, -up, 0, -up - 2.9, 0.95, -up], STEEL);
      if (k.weapon === "yari") seg(c, -1.4, -up + 0.5, 1.4, -up + 0.5, STEEL_D, 0.6);
      if (k.pennon) poly(c, [0.5, -up + 0.8, 4.4, -up + 2, 0.5, -up + 3.4], k.f.main);
      break;
    }
    case "pot":
      // clay pot of naphtha with a burning fuse
      oval(c, 0, -1.8, 1.9, 1.8, "#b5652e");
      rrect(c, -0.7, -4.3, 1.4, 1.2, 0.2, "#8f4a1f");
      poly(c, [-0.8, -4.3, 0, -6.8, 0.8, -4.3], "#ffb03a");
      dot(c, 0, -4.8, 0.4, "#fff3a0");
      break;
  }
}

interface Hand {
  x: number;
  y: number;
  th: number;
}
const H = (x: number, y: number, th: number): Hand => ({ x, y, th });
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const ease = (t: number) => t * t * (3 - 2 * t);
const mixH = (a: Hand, b: Hand, t: number): Hand => H(lerp(a.x, b.x, t), lerp(a.y, b.y, t), lerp(a.th, b.th, t));
/** wind up, strike fast, recover */
function swing(u: number, rest: Hand, back: Hand, fwd: Hand): Hand {
  if (u <= 0 || u >= 1) return rest;
  if (u < 0.18) return mixH(rest, back, ease(u / 0.18));
  if (u < 0.36) return mixH(back, fwd, ((u - 0.18) / 0.18) ** 2);
  return mixH(fwd, rest, ease((u - 0.36) / 0.64));
}
function meleeHand(k: Look, u: number): Hand {
  const w = k.wp;
  if (w.cls === "pole") {
    if (k.mounted) return swing(u, H(2.2, -8.2, 1.42), H(0.8, -8.2, 1.42), H(5.6, -8.4, 1.5));
    return swing(u, H(2.6, -8.6, 1.32), H(0.5, -8.8, 1.32), H(7, -8.9, 1.5));
  }
  if (w.cls === "blade" && w.two) return swing(u, H(3.4, -9, 0.55), H(0.2, -13.2, -1.5), H(5.4, -8, 1.7));
  if (w.two) return swing(u, H(2.4, -9.6, -0.35), H(-0.2, -13.4, -1.3), H(5.2, -7.6, 1.9));
  return swing(u, H(3, -8.6, 0.3), H(0.4, -12.8, -1.8), H(5.2, -8.4, 1.5));
}

const SHX = 0.4;
const SHY = -10.9;
function armAndWeapon(c: C, k: Look, h: Hand) {
  if (k.wp.two) limb(c, SHX, SHY, h.x - Math.sin(h.th) * 2.4, h.y + Math.cos(h.th) * 2.4, k.sleeve, 1.6, k.mail);
  c.save();
  c.translate(h.x, h.y);
  c.rotate(h.th);
  drawWp(c, k);
  c.restore();
  limb(c, SHX, SHY, h.x, h.y, k.sleeve, 1.6, k.mail);
  dot(c, h.x, h.y, 0.95, k.skin);
}

function rangedArms(c: C, k: Look, u: number) {
  const w = k.wp;
  if (w.cls === "none") {
    limb(c, SHX, SHY, 1.7, -6.5, k.sleeve, 1.6);
    return;
  }
  if (w.cls === "bow") {
    const bx = 4.7;
    const by = -10.2;
    // string hand: loose -> reach for the quiver -> nock
    let sx = 2.4;
    let sy = -10.2;
    let arrow = true;
    if (u > 0 && u < 0.3) {
      sx = 0.7;
      sy = -10.6;
      arrow = false;
    } else if (u >= 0.3 && u < 0.7) {
      sx = -1.5;
      sy = -12.7;
      arrow = false;
    } else if (u >= 0.7) {
      const t = (u - 0.7) / 0.3;
      sx = lerp(-1.5, 2.4, t);
      sy = lerp(-12.7, -10.2, t);
    }
    limb(c, SHX, SHY, sx, sy, k.sleeve, 1.6);
    const top = -w.len;
    const bot = w.curve === 2 ? w.len * 0.55 : w.len; // the yumi is gripped below its middle
    const tipX = bx - 1.7;
    c.beginPath();
    c.moveTo(tipX, by + top);
    c.quadraticCurveTo(bx + 2.4, by + (top + bot) * 0.3, tipX, by + bot);
    c.strokeStyle = OUT;
    c.lineWidth = 1.5;
    c.stroke();
    c.strokeStyle = k.faction === "samurai" ? LACQ : WOOD;
    c.lineWidth = 0.85;
    c.stroke();
    c.strokeStyle = OUT;
    c.lineWidth = LW;
    if (w.curve === 1) {
      seg(c, tipX, by + top, tipX + 0.9, by + top - 0.8, WOOD, 0.7);
      seg(c, tipX, by + bot, tipX + 0.9, by + bot + 0.8, WOOD, 0.7);
    }
    c.beginPath();
    c.moveTo(tipX, by + top);
    c.lineTo(arrow ? sx : tipX, arrow ? sy : by);
    c.lineTo(tipX, by + bot);
    c.strokeStyle = "#fbf7ee";
    c.lineWidth = 0.3;
    c.stroke();
    c.strokeStyle = OUT;
    c.lineWidth = LW;
    if (arrow) {
      seg(c, sx, sy, sx + 7, sy, WOOD_D, 0.45);
      poly(c, [sx + 7, sy - 0.6, sx + 8.4, sy, sx + 7, sy + 0.6], STEEL);
    }
    limb(c, SHX, SHY, bx, by, k.sleeve, 1.6);
    dot(c, bx, by, 0.95, k.skin);
    dot(c, sx, sy, 0.85, k.skin);
    return;
  }
  if (w.cls === "jav" || w.cls === "pot") {
    // held high, thrown, a new one fetched
    let h = H(1.2, -13.6, 1.38);
    let has = true;
    if (u > 0 && u < 0.2) {
      h = H(5.6, -11, 1.6);
      has = false;
    } else if (u >= 0.2 && u < 0.7) {
      h = H(lerp(5.6, -1, (u - 0.2) / 0.5), lerp(-11, -12.4, (u - 0.2) / 0.5), 1.4);
      has = false;
    }
    if (has) {
      c.save();
      c.translate(h.x, h.y);
      if (w.cls === "jav") c.rotate(h.th);
      drawWp(c, k);
      c.restore();
    }
    limb(c, SHX, SHY, h.x, h.y, k.sleeve, 1.6);
    dot(c, h.x, h.y, 0.95, k.skin);
    limb(c, SHX, SHY, 2.8, -7.6, k.sleeve, 1.6);
    return;
  }
  // crossbow / matchlock: kick, reload pointing down, shoulder again
  let a = 0;
  let ox = 0;
  let loaded = true;
  if (u > 0 && u < 0.15) {
    a = -0.28;
    ox = -1.2;
    loaded = false;
  } else if (u >= 0.15 && u < 0.82) {
    a = 0.8;
    loaded = false;
  }
  limb(c, SHX, SHY, 1.6 + ox, -8.8, k.sleeve, 1.6);
  c.save();
  c.translate(3.4 + ox, -9.4);
  c.rotate(a);
  if (w.cls === "xbow") {
    rrect(c, -2.6, -0.6, 6.6, 1.3, 0.3, WOOD);
    c.beginPath();
    c.moveTo(3.3, -3.1);
    c.quadraticCurveTo(5.3, 0, 3.3, 3.1);
    c.strokeStyle = OUT;
    c.lineWidth = 1.4;
    c.stroke();
    c.strokeStyle = STEEL_D;
    c.lineWidth = 0.8;
    c.stroke();
    c.strokeStyle = "#fbf7ee";
    c.lineWidth = 0.3;
    c.beginPath();
    c.moveTo(3.3, -3.1);
    c.lineTo(loaded ? 0.4 : 3, 0);
    c.lineTo(3.3, 3.1);
    c.stroke();
    c.strokeStyle = OUT;
    c.lineWidth = LW;
    if (loaded) seg(c, 0.6, -0.1, 5.2, -0.1, STEEL, 0.5);
  } else {
    poly(c, [-3.8, 1.7, -1, -0.7, 1.6, -0.7, 1.6, 0.6, -1.2, 0.9, -2.7, 2.6], WOOD);
    limb(c, -1, -0.25, 8.8, -0.25, "#3c4049", 0.95);
    dot(c, 1.1, -1.2, 0.45, "#ff8a3c");
    if (u > 0 && u < 0.12) {
      poly(c, [9.2, -0.25, 12.4, -2.6, 11.6, -0.9, 15, -0.25, 11.6, 0.5, 12.4, 2.2], "#ffd75a");
      dot(c, 10.6, -0.25, 1.1, "#ffffff");
    } else if (u >= 0.12 && u < 0.3) {
      dot(c, 11.5, -1.4, 2.1, "rgba(235,235,235,0.75)");
      dot(c, 13.8, -2.8, 1.5, "rgba(235,235,235,0.55)");
    }
  }
  c.restore();
  limb(c, SHX, SHY, 4.2 + ox, -8.9 + Math.sin(a) * 0.8, k.sleeve, 1.6);
}

function drawMan(c: C, k: Look, p: Pose, mounted: boolean) {
  const g = p.moving ? p.walk : 0;
  const bob = mounted ? 0 : p.moving ? -Math.abs(Math.sin(g)) * 0.9 : 0;
  const u = p.atk > 0 ? 1 - p.atk : 0;
  const w = k.wp;
  const sway = p.moving ? Math.sin(g) * 0.9 : 0;
  if (!mounted) {
    for (let i = 1; i >= 0; i--) {
      const ph = g + i * Math.PI;
      const fx = (i ? -1.4 : 1.4) + (p.moving ? Math.sin(ph) * 2.3 : 0);
      const fy = p.moving ? -Math.max(0, Math.cos(ph)) * 1.4 : 0;
      limb(c, i ? -1.3 : 1.3, -4.9 + bob, fx, fy - 0.9, k.pants, 1.9, k.mail);
      oval(c, fx + 0.5, fy - 0.5, 1.5, 0.8, k.boot);
    }
  } else {
    limb(c, 0.6, -5, 2.4, -0.9, k.pants, 1.9, k.mail);
    oval(c, 3, -0.6, 1.4, 0.8, k.boot);
  }
  c.save();
  c.translate(0, bob);
  // ---- worn on the back
  if (k.extra === "cape") {
    const cc = k.heroKind === "reynald" || k.heroKind === "zahir" ? CLOTH : k.heroKind === "takeda" ? "#7a2222" : k.heroKind === "saladin" ? k.f.main : k.f.dark;
    poly(c, [-2.4, -12.2, -6.6 - sway, -4.6, -5 - sway, -1.8, -1.4, -5], cc);
  } else if (k.extra === "furcloak") poly(c, [-3.2, -12.4, -7.4 - sway, -5, -5.6 - sway, -1.6, -1.2, -5.2], FUR);
  else if (k.extra === "sashimono") {
    seg(c, -2.6, -10.5, -2.6, -27, LACQ, 0.55);
    poly(c, [-2.6, -26.6, -6.6, -26.6 + sway * 0.4, -6.6, -19 + sway * 0.4, -2.6, -19], k.f.main);
    dot(c, -4.6, -22.8, 1.15, "#ffffff");
  } else if (k.extra === "quiver") {
    poly(c, [-3.9, -12.6, -2.3, -13, -1.3, -6.4, -2.9, -6], WOOD);
    seg(c, -3.4, -13, -3.9, -14.7, CLOTH, 0.5);
    seg(c, -2.8, -13.1, -2.9, -15, CLOTH, 0.5);
  }
  const hasShield = k.shield !== "";
  const melee = w.cls === "blade" || w.cls === "axe" || w.cls === "club" || w.cls === "pole" || w.cls === "glaive";
  const hand = melee ? meleeHand(k, u) : null;
  const striking = u > 0.14 && u < 0.62;
  // the weapon arm passes behind the body while the shield is up, and swings over it to strike
  if (hand && hasShield && !striking) armAndWeapon(c, k, hand);
  drawBody(c, k);
  if (k.extra === "furcloak") {
    oval(c, 0.1, -11.4, 4.5, 1.9, FUR);
    seg(c, -2.6, -10.8, -2.1, -9.8, WOOD_D, 0.4);
    seg(c, 0, -10.4, 0.3, -9.4, WOOD_D, 0.4);
    seg(c, 2.5, -10.8, 2.2, -9.8, WOOD_D, 0.4);
  }
  drawHead(c, k, 0.4, -15.4);
  if (hasShield) {
    limb(c, SHX, SHY, 2.6, -8.6, k.sleeve, 1.6, k.mail);
    drawShield(c, k, mounted ? 2.3 : 3.1, -8.1);
  }
  if (hand && (!hasShield || striking)) armAndWeapon(c, k, hand);
  if (!melee) rangedArms(c, k, u);
  c.restore();
}

function drawHorse(c: C, k: Look, p: Pose) {
  const g = p.moving ? p.walk : 0;
  const bob = p.moving ? Math.sin(g * 2) * 0.5 : 0;
  const coat = k.horse;
  const m = k.f.main;
  c.beginPath();
  c.moveTo(-6.2, -10.8 + bob);
  c.quadraticCurveTo(-12.4, -10 + (p.moving ? Math.sin(g) * 1.2 : 0), -10.4, -3.6);
  c.quadraticCurveTo(-9, -7.2, -5.6, -8.4 + bob);
  c.closePath();
  c.fillStyle = k.mane;
  c.fill();
  c.stroke();
  const hips = [-5.2, 5.6, -3.8, 6.8];
  const phs = [0, Math.PI, Math.PI * 0.5, Math.PI * 1.5];
  for (let i = 0; i < 4; i++) {
    const sw = p.moving ? Math.sin(g + phs[i]) * 3 : 0;
    const lift = p.moving ? Math.max(0, Math.cos(g + phs[i])) * 2 : 0;
    limb(c, hips[i], -5.6 + bob, hips[i] + sw, -0.9 - lift, i < 2 ? k.mane : coat, 1.5);
    bar(c, hips[i] + sw - 0.95, -1 - lift, 1.9, 1, OUT);
  }
  oval(c, 1.2, -8.6 + bob, 8.1, 4.3, coat);
  poly(c, [5.4, -11.8 + bob, 9.4, -17.6 + bob, 12.6, -16 + bob, 9.6, -8 + bob], coat);
  c.save();
  c.translate(11.2, -16.8 + bob);
  c.rotate(0.6);
  rrect(c, -1.5, -1.6, 6.4, 3.2, 1.4, coat);
  dot(c, 1, -0.4, 0.5, OUT);
  seg(c, 2.6, -1.5, 2.6, 1.5, WOOD_D, 0.4); // bridle
  c.restore();
  poly(c, [9.2, -18.6 + bob, 9.9, -20.8 + bob, 10.9, -18.4 + bob], coat);
  poly(c, [5.6, -12.6 + bob, 9, -18 + bob, 10.2, -17.4 + bob, 7.2, -11.6 + bob], k.mane);
  if (k.cloth === "capar") {
    // full heraldic caparison
    poly(c, [-6.6, -11 + bob, 7.8, -11.4 + bob, 9.2, -4.4 + bob, 6, -3.2 + bob, -5.4, -3.4 + bob, -7.8, -5.2 + bob], CLOTH);
    bar(c, 0.2, -10.4 + bob, 1.3, 6.4, m);
    bar(c, -2.2, -8 + bob, 6.2, 1.3, m);
    seg(c, -5.6, -3.6 + bob, 6.2, -3.4 + bob, m, 0.7);
  } else if (k.cloth === "blanket") {
    rrect(c, -4.2, -11.8 + bob, 7.6, 5.8, 1, m);
    seg(c, -4, -6.7 + bob, 3.2, -6.7 + bob, GOLD, 0.6);
    seg(c, 6.4, -10.6 + bob, 8.4, -6.4 + bob, WOOD_D, 0.5); // breast strap
    dot(c, 7.6, -7.2 + bob, 0.9, GOLD);
    dot(c, 8.5, -5.6 + bob, 0.8, m);
  } else if (k.cloth === "tassel") {
    // lacquered saddle and red tassels
    rrect(c, -3.8, -11.9 + bob, 7, 4.6, 1, "#1f1a17");
    seg(c, -3.6, -7.9 + bob, 3, -7.9 + bob, GOLD, 0.6);
    seg(c, 6.4, -10.6 + bob, 8.2, -7.6 + bob, RED, 0.6);
    poly(c, [7.4, -8 + bob, 8.9, -8 + bob, 8.6, -5 + bob, 7.7, -5 + bob], RED);
    poly(c, [-6.9, -9.4 + bob, -5.4, -9.4 + bob, -5.7, -6.4 + bob, -6.6, -6.4 + bob], RED);
  } else oval(c, -0.4, -12.2 + bob, 3.7, 1.5, FUR); // a fur saddle
  seg(c, 11.6, -15.2 + bob, 1.6, -12.6 + bob, OUT, 0.35);
  return bob;
}

function drawCannon(c: C, k: Look, p: Pose) {
  const rc = p.atk; // recoil 1 -> 0
  const kx = -rc * 3.2;
  c.save();
  c.translate(-10.5, 0);
  drawMan(c, k, { walk: 0, moving: false, atk: 0 }, false);
  c.restore();
  limb(c, -7 + kx, -1.3, kx, -5.2, WOOD, 1.5);
  c.save();
  c.translate(1.5 + kx, -7.4);
  c.rotate(-0.2);
  rrect(c, -4, -2.2, 14.5, 4.4, 1.8, "#4d525c");
  bar(c, -1, -2.1, 1.3, 4.2, GOLD);
  bar(c, 5, -2.1, 1.3, 4.2, GOLD);
  rrect(c, 9.6, -2.7, 1.8, 5.4, 0.6, "#3a3e46");
  if (rc > 0.8) {
    poly(c, [11.8, 0, 15.4, -3.2, 14.4, -0.9, 18.6, 0, 14.4, 0.9, 15.4, 3.2], "#ffd75a");
    dot(c, 13, 0, 1.4, "#ffffff");
  }
  c.restore();
  oval(c, 0.4 + kx, -4.2, 4.3, 4.3, WOOD);
  for (let i = 0; i < 4; i++) seg(c, 0.4 + kx - Math.cos(i * 0.785) * 3.8, -4.2 - Math.sin(i * 0.785) * 3.8, 0.4 + kx + Math.cos(i * 0.785) * 3.8, -4.2 + Math.sin(i * 0.785) * 3.8, WOOD_D, 0.5);
  dot(c, 0.4 + kx, -4.2, 1.1, WOOD_D);
  poly(c, [-5.2 + kx, -6.4, -5.2 + kx, -12.4, -1.6 + kx, -11, -4.6 + kx, -9.8, -4.6 + kx, -6.2], k.f.main);
}

export interface Pose {
  walk: number;
  moving: boolean;
  /** attack animation 1 -> 0 (for the cannon: recoil) */
  atk: number;
}

export function drawFigure(c: C, k: Look, p: Pose, shadow = true) {
  c.lineJoin = "round";
  c.lineCap = "round";
  c.strokeStyle = OUT;
  c.lineWidth = LW;
  const big = k.mounted || k.cannon;
  if (shadow) {
    c.fillStyle = "rgba(24,60,24,0.26)";
    c.beginPath();
    c.ellipse(big ? 1.5 : 0.6, 0.2, big ? 10.8 : 4.8, big ? 2.7 : 1.8, 0, 0, TAU);
    c.fill();
  }
  if (k.cannon) drawCannon(c, k, p);
  else if (k.mounted) {
    const bob = drawHorse(c, k, p);
    c.save();
    c.translate(-0.5, -6.8 + bob);
    drawMan(c, k, p, true);
    c.restore();
  } else drawMan(c, k, p, false);
}

/* ------------------------------------------------------------------ */
/*  ragdolls                                                          */
/* ------------------------------------------------------------------ */
export interface RagPose {
  ang: number;
  l0: number;
  l1: number;
  l2: number;
  l3: number;
}
/** a limp body: origin at the hips, limbs swing freely */
export function drawRag(c: C, k: Look, r: RagPose) {
  c.lineJoin = "round";
  c.lineCap = "round";
  c.strokeStyle = OUT;
  c.lineWidth = LW;
  c.save();
  c.rotate(r.ang);
  limb(c, -1.2, 0, -1.2 + Math.sin(r.l3) * 4.7, Math.cos(r.l3) * 4.7, k.pants, 1.9);
  limb(c, 1.2, 0, 1.2 + Math.sin(r.l2) * 4.7, Math.cos(r.l2) * 4.7, k.pants, 1.9);
  limb(c, 0.2, -6, 0.2 + Math.sin(r.l1) * 4.5, -6 + Math.cos(r.l1) * 4.5, k.sleeve, 1.6);
  c.translate(0, 4.8);
  drawBody(c, k);
  drawHead(c, k, 0.4, -15.4);
  c.translate(0, -4.8);
  limb(c, 0.4, -6, 0.4 + Math.sin(r.l0) * 4.5, -6 + Math.cos(r.l0) * 4.5, k.sleeve, 1.6);
  c.restore();
}
/** a horse going down: origin at the middle of its body */
export function drawHorseRag(c: C, k: Look, ang: number) {
  c.lineJoin = "round";
  c.lineCap = "round";
  c.strokeStyle = OUT;
  c.lineWidth = LW;
  c.save();
  c.rotate(ang);
  c.translate(-1.2, 8.6);
  drawHorse(c, k, { walk: 0, moving: false, atk: 0 });
  c.restore();
}

/* ------------------------------------------------------------------ */
/*  sprite cache                                                      */
/* ------------------------------------------------------------------ */
/** 0 idle, 1..6 walk cycle, 7..11 attack */
export function frameOf(walk: number, moving: boolean, atk: number): number {
  if (atk > 0.02) return 7 + Math.min(4, Math.floor(atk * 5));
  if (moving) return 1 + (Math.floor(((((walk % TAU) + TAU) % TAU) / TAU) * 6) % 6);
  return 0;
}
function poseOf(frame: number): Pose {
  if (frame >= 7) return { walk: 0, moving: false, atk: (frame - 7 + 0.5) / 5 };
  if (frame >= 1) return { walk: ((frame - 1 + 0.5) * TAU) / 6, moving: true, atk: 0 };
  return { walk: 0, moving: false, atk: 0 };
}

let RES = 1.5;
const cache = new Map<number, HTMLCanvasElement>();
/** sprite sharpness in device pixels per figure unit */
export function setSpriteRes(r: number) {
  const q = Math.max(1, Math.min(3.25, Math.ceil(r * 4) / 4));
  if (q !== RES) {
    RES = q;
    cache.clear();
  }
}
export function sprite(k: Look, frame: number): HTMLCanvasElement {
  const key = k.id * 16 + frame;
  let cv = cache.get(key);
  if (!cv) {
    const r = RES * (k.hero ? 1.5 : 1);
    cv = document.createElement("canvas");
    cv.width = Math.ceil(k.w * r);
    cv.height = Math.ceil(k.h * r);
    const c = cv.getContext("2d")!;
    c.setTransform(r, 0, 0, r, k.ox * r, k.oy * r);
    drawFigure(c, k, poseOf(frame));
    cache.set(key, cv);
  }
  return cv;
}
