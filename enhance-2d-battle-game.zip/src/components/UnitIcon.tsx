import { memo, useEffect, useRef } from "react";
import { drawFigure, getLook } from "../game/figure";
import { drawEmblem } from "../game/castles";
import type { FactionId, HeroKind, UnitType } from "../game/constants";

interface Props {
  faction: FactionId;
  type: UnitType;
  hero?: HeroKind;
  size?: number;
  zoom?: number;
  flip?: boolean;
  /** play the walk + attack loop (menu only; icons in the HUD are static) */
  animate?: boolean;
}

/** a soldier drawn with the game's own art */
function UnitIconBase({ faction, type, hero, size = 56, zoom = 2.6, flip = false, animate = false }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(size * dpr);
    cv.height = Math.round(size * dpr);
    const ctx = cv.getContext("2d")!;
    const k = getLook(faction, type, hero);
    const big = k.mounted || k.cannon;
    const dir = flip ? -1 : 1;
    let raf = 0;
    const t0 = performance.now();
    const paint = () => {
      const t = (performance.now() - t0) / 1000;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);
      ctx.translate(size / 2 - dir * (big ? 5 : 3) * zoom * 0.55, size * 0.87);
      ctx.scale(dir * zoom, zoom);
      drawFigure(ctx, k, { walk: t * 9, moving: animate, atk: animate ? Math.max(0, 1 - ((t * 1.1) % 1.9)) : 0 });
      if (animate) raf = requestAnimationFrame(paint);
    };
    paint();
    return () => cancelAnimationFrame(raf);
  }, [faction, type, hero, size, zoom, flip, animate]);
  return <canvas ref={ref} style={{ width: size, height: size, display: "block" }} />;
}
const UnitIcon = memo(UnitIconBase);
export default UnitIcon;

/** the faction's heraldic sign */
export const Emblem = memo(function Emblem({ faction, size = 28, color = "#fff8ea" }: { faction: FactionId; size?: number; color?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(size * dpr);
    cv.height = Math.round(size * dpr);
    const ctx = cv.getContext("2d")!;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, size, size);
    drawEmblem(ctx, faction, size / 2, size / 2, size * 0.4, color);
  }, [faction, size, color]);
  return <canvas ref={ref} style={{ width: size, height: size, display: "block" }} />;
});
