import { Sparkles } from 'lucide-react';

interface Props {
  value: number; // 0..1
  onChange: (v: number) => void;
}

/** Adjustable 0–100% blend of the Shadertoy "Elephant" (iq, 4dKGWm) lighting */
export function IqLightingPanel({ value, onChange }: Props) {
  const pct = Math.round(value * 100);
  return (
    <div className="border-b border-white/10 pb-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-amber-200">
          <Sparkles className="h-3.5 w-3.5 text-amber-300" />
          Shader Cahaya iq
        </div>
        <span className="rounded bg-amber-400/20 px-1.5 py-0.5 font-mono text-[11px] font-black text-amber-200">
          {pct}%
        </span>
      </div>
      <div className="mt-0.5 text-[9px] leading-snug text-slate-400">
        Key (matahari) + Fill (langit) + Bounce (tanah) + soft-shadow & AO SDF — Shadertoy “Elephant” 4dKGWm
      </div>
      <input
        type="range"
        min={0}
        max={100}
        step={1}
        value={pct}
        onChange={(e) => onChange(parseInt(e.target.value, 10) / 100)}
        className="iq-range mt-2 w-full cursor-pointer"
      />
      <div className="mt-1.5 grid grid-cols-5 gap-1">
        {[0, 25, 50, 75, 100].map((p) => (
          <button
            key={p}
            onClick={() => onChange(p / 100)}
            className={`rounded-md border py-0.5 text-[10px] font-bold transition ${
              Math.abs(pct - p) < 3
                ? 'border-amber-300 bg-amber-400/25 text-amber-100'
                : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            {p}%
          </button>
        ))}
      </div>
      <div className="mt-1.5 flex justify-between font-mono text-[9px] text-slate-500">
        <span>0% = bawaan</span>
        <span>[ , ] [ . ] ±10% • [L] on/off</span>
        <span>100% = shader</span>
      </div>
    </div>
  );
}
