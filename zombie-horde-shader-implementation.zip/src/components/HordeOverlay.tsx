import { Biohazard, Heart, Skull, Users } from 'lucide-react';
import type { HudSnapshot } from '../game/types';

interface Props {
  hud: HudSnapshot;
  onRestart: () => void;
  onExit: () => void;
}

/**
 * Always-visible (even with [P] UI hidden) minimal Zombie Horde HUD:
 * wave banner, remaining counter, HP bar, zombie-tower meter and Game Over card.
 */
export function HordeOverlay({ hud, onRestart, onExit }: Props) {
  const h = hud.horde;
  if (!h.active) return null;

  const hpPct = Math.max(0, Math.min(100, hud.playerHp));
  const hpColor = hpPct < 30 ? 'bg-red-500' : hpPct < 60 ? 'bg-amber-400' : 'bg-emerald-400';
  const progress = h.waveTotal > 0 ? 1 - h.remaining / h.waveTotal : 0;
  const danger = Math.min(1, h.nearby / 28);

  return (
    <>
      {/* WAVE BANNER */}
      {h.bannerText && (
        <div className="pointer-events-none fixed inset-x-0 top-[17%] z-30 flex justify-center">
          <div
            key={`banner-${h.bannerId}`}
            className="animate-wave-banner rounded-lg bg-black/55 px-8 py-3 text-center backdrop-blur-sm"
          >
            <div className="flex items-center justify-center gap-3 text-2xl font-black uppercase tracking-[0.18em] text-red-400 drop-shadow-[0_0_14px_rgba(239,68,68,0.7)] sm:text-4xl">
              <Biohazard className="h-7 w-7 sm:h-9 sm:w-9" />
              {h.bannerText}
            </div>
            {h.phase === 'intermission' && h.intermissionLeft > 0 && (
              <div className="mt-1 font-mono text-xs font-bold tracking-widest text-amber-200">
                GELOMBANG BERIKUTNYA {h.intermissionLeft}s
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOP CENTER — wave + remaining */}
      <div className="pointer-events-none fixed left-1/2 top-3 z-30 flex -translate-x-1/2 flex-col items-center gap-1">
        <div className="flex items-center gap-3 whitespace-nowrap rounded-xl border border-red-500/40 bg-black/65 px-4 py-1.5 text-white shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-1.5 text-red-400">
            <Skull className="h-4 w-4" />
            <span className="whitespace-nowrap font-mono text-sm font-black tracking-wider">WAVE {Math.max(1, h.wave)}</span>
          </div>
          <div className="h-4 w-px bg-white/20" />
          <div className="flex items-center gap-1.5">
            <Users className="h-4 w-4 text-orange-300" />
            <span className="font-mono text-sm font-black text-orange-200">{h.remaining}</span>
            <span className="whitespace-nowrap text-[10px] font-bold uppercase tracking-wider text-slate-400">tersisa</span>
          </div>
          <div className="h-4 w-px bg-white/20" />
          <span className="font-mono text-sm font-black text-emerald-300">{h.kills}</span>
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">kill</span>
          <div className="h-4 w-px bg-white/20" />
          <span className="font-mono text-sm font-black text-amber-300">{hud.score.toLocaleString()}</span>
        </div>
        <div className="h-1 w-56 overflow-hidden rounded-full bg-black/60 ring-1 ring-white/10">
          <div
            style={{ width: `${Math.round(progress * 100)}%` }}
            className="h-full bg-gradient-to-r from-red-600 to-orange-400 transition-all duration-300"
          />
        </div>
        {h.tallestPile > 2.4 && (
          <div className="rounded-md bg-red-600/85 px-2.5 py-0.5 font-mono text-[10px] font-black tracking-widest text-white shadow">
            ⚠ MENARA ZOMBIE {h.tallestPile.toFixed(1)}m • {h.climbing} MEMANJAT
          </div>
        )}
      </div>

      {/* BOTTOM CENTER — HP */}
      <div className="pointer-events-none fixed bottom-5 left-1/2 z-30 flex -translate-x-1/2 items-center gap-2">
        <Heart className={`h-4 w-4 ${hpPct < 35 ? 'animate-pulse text-red-400' : 'text-emerald-300'}`} />
        <div className="h-2.5 w-52 overflow-hidden rounded-full bg-black/65 ring-1 ring-white/20">
          <div style={{ width: `${hpPct}%` }} className={`h-full transition-all duration-150 ${hpColor}`} />
        </div>
        <span className="w-8 font-mono text-xs font-black text-white drop-shadow">{hud.playerHp}</span>
      </div>

      {/* Swarm proximity red pulse */}
      {danger > 0.15 && h.phase !== 'gameover' && (
        <div
          className="pointer-events-none fixed inset-0 z-20"
          style={{ boxShadow: `inset 0 0 ${60 + danger * 140}px rgba(185,28,28,${0.12 + danger * 0.32})` }}
        />
      )}

      {/* GAME OVER */}
      {h.phase === 'gameover' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/72 backdrop-blur-[3px]">
          <div className="w-[min(92vw,30rem)] rounded-2xl border border-red-500/40 bg-slate-950/90 p-6 text-center text-white shadow-2xl">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-red-600/20 ring-1 ring-red-500/50">
              <Skull className="h-7 w-7 text-red-400" />
            </div>
            <h2 className="mt-3 text-3xl font-black uppercase tracking-[0.12em] text-red-400">Kamu Dikerumuni</h2>
            <p className="mt-1 text-xs text-slate-300">Gelombang zombie menenggelamkanmu di Gedung Geng Graffiti.</p>
            <div className="mt-4 grid grid-cols-4 gap-2 rounded-xl bg-white/5 p-3 font-mono">
              <div>
                <div className="text-[9px] text-slate-400">WAVE</div>
                <div className="text-xl font-black text-red-300">{h.wave}</div>
              </div>
              <div>
                <div className="text-[9px] text-slate-400">KILL</div>
                <div className="text-xl font-black text-emerald-300">{h.kills}</div>
              </div>
              <div>
                <div className="text-[9px] text-slate-400">HEADSHOT</div>
                <div className="text-xl font-black text-amber-300">{h.headshots}</div>
              </div>
              <div>
                <div className="text-[9px] text-slate-400">SKOR</div>
                <div className="text-xl font-black text-sky-300">{hud.score}</div>
              </div>
            </div>
            <div className="mt-5 flex items-center justify-center gap-2.5">
              <button
                onClick={onRestart}
                className="rounded-xl bg-red-500 px-5 py-2.5 text-sm font-black tracking-wide text-white shadow-lg shadow-red-900/40 transition hover:scale-[1.03] hover:bg-red-400 active:scale-95"
              >
                BERTAHAN LAGI
              </button>
              <button
                onClick={onExit}
                className="rounded-xl border border-white/20 bg-white/5 px-4 py-2.5 text-xs font-bold text-slate-200 transition hover:bg-white/15"
              >
                Keluar Mode Horde
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
