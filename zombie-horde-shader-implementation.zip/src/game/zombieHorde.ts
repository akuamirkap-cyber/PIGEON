import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { BoxCollider3D } from './compoundBuilder';
import { soundEngine } from './audio';

/**
 * =====================================================================================
 *  ZOMBIE HORDE MODE — "World War Z" style swarm
 * =====================================================================================
 *  - Up to ~340 low-poly zombies rendered with GPU instancing (7 InstancedMeshes)
 *  - Sprinting swarm AI w/ spatial-hash crowd separation
 *  - SWARM PHYSICS like WWZ:
 *      * Zombies that get jammed behind each other LEAP / CLAMBER OVER the crowd ("hop")
 *      * Zombies that hit a wall pile up into CLIMBING COLUMNS (zombie pyramids / towers)
 *        and the top of the pile vaults over the wall, streaming over as a living ladder
 *  - Waves: surge spawning from several directions, runners / walkers / brutes
 * =====================================================================================
 */

export type ZombieKind = 'walker' | 'runner' | 'brute';
export type ZombieState = 'run' | 'hop' | 'climb' | 'vault' | 'dead';
export type HordePhase = 'idle' | 'intermission' | 'combat' | 'gameover';

interface Column {
  col: BoxCollider3D;
  x: number;
  z: number;
  baseY: number;
  topY: number;
  faceYaw: number;
  members: Zombie[];
  /** seconds since the last zombie joined this column */
  idle: number;
  /** conveyor offset (in slots): once nobody new joins, the whole tower rises and spills over the wall */
  lift: number;
}

/** Verlet-bone ragdoll: 12 joints + distance constraints, driven by the bullet / blast impulse */
interface Ragdoll {
  p: Float32Array; // current joint positions (12 × xyz)
  q: Float32Array; // previous joint positions
  gy: Float32Array; // cached ground height under each joint
  acc: number;
  t: number;
  rest: number;
  asleep: boolean;
  written: boolean;
  near: BoxCollider3D[];
}

interface Impulse {
  dx: number; // horizontal push direction (unit)
  dz: number;
  force: number; // m/s
  up: number; // extra upward share (0..1)
  hitY: number; // world height of the hit (upper-body hits spin the body more)
}

interface Zombie {
  id: number;
  slot: number;
  kind: ZombieKind;
  state: ZombieState;
  x: number;
  y: number;
  z: number;
  vy: number;
  yaw: number;
  scale: number;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  damage: number;
  reach: number;

  phase: number;
  animRate: number;
  attackCd: number;
  stagger: number;
  hopT: number;
  hopY: number;
  jamTime: number;
  blockedTime: number;
  blockCol: BoxCollider3D | null;
  ignoreCol: BoxCollider3D | null;
  vaultT: number;
  column: Column | null;
  jx: number;
  jz: number;
  armAsym: number;
  headTilt: number;
  leanBase: number;
  seed: number;

  rag: Ragdoll | null;
  vx: number;
  vz: number;
  deadT: number;
  fallDir: number;
  fallAngle: number;
  attacking: boolean;
}

export interface ZombieHit {
  zombieId: number;
  hitbox: 'head' | 'body';
  dist: number;
  point: THREE.Vector3;
}

export interface HordeHud {
  active: boolean;
  phase: HordePhase;
  wave: number;
  alive: number;
  remaining: number;
  waveTotal: number;
  kills: number;
  headshots: number;
  intermissionLeft: number;
  tallestPile: number;
  climbing: number;
  nearby: number;
  bestWave: number;
  bannerId: number;
  bannerText: string;
}

export interface HordeArena {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface HordeUpdateContext {
  dt: number;
  playerPos: THREE.Vector3; // camera position
  playerFootY: number;
  playerAlive: boolean;
  onBite: (damage: number, from: THREE.Vector3, brute: boolean) => void;
}

const MAX_SLOTS = 340;

// ---------------------------------------------------------------- ragdoll skeleton
const R_PELVIS = 0;
const R_HIPL = 1;
const R_HIPR = 2;
const R_NECK = 3;
const R_SHL = 4;
const R_SHR = 5;
const R_HEAD = 6;
const R_HANDL = 7;
const R_HANDR = 8;
const R_FOOTL = 9;
const R_FOOTR = 10;
const R_CHEST = 11;
const RAG_N = 12;
const RAG_DT = 1 / 60;
// rest pose in zombie-local space (facing +z, feet on y=0, scale 1)
const RAG_REST: [number, number, number][] = [
  [0, 0.92, 0], // pelvis
  [-0.12, 0.92, 0], // hip L
  [0.12, 0.92, 0], // hip R
  [0, 1.6, 0.03], // neck
  [-0.31, 1.5, 0], // shoulder L
  [0.31, 1.5, 0], // shoulder R
  [0, 1.8, 0.04], // head
  [-0.31, 1.3, 0.61], // hand L (arms reaching forward)
  [0.31, 1.3, 0.61], // hand R
  [-0.12, 0.0, 0], // foot L
  [0.12, 0.0, 0], // foot R
  [0, 1.25, 0], // chest
];
const RAG_RADIUS = [0.17, 0.07, 0.07, 0.1, 0.1, 0.1, 0.15, 0.06, 0.06, 0.07, 0.07, 0.17];
const RAG_PAIRS: [number, number][] = [
  [R_PELVIS, R_HIPL], [R_PELVIS, R_HIPR], [R_HIPL, R_HIPR],
  [R_HIPL, R_FOOTL], [R_HIPR, R_FOOTR], [R_PELVIS, R_FOOTL], [R_PELVIS, R_FOOTR],
  [R_PELVIS, R_CHEST], [R_CHEST, R_NECK], [R_PELVIS, R_NECK],
  [R_CHEST, R_SHL], [R_CHEST, R_SHR], [R_NECK, R_SHL], [R_NECK, R_SHR], [R_SHL, R_SHR],
  [R_HIPL, R_CHEST], [R_HIPR, R_CHEST], [R_HIPL, R_SHR], [R_HIPR, R_SHL],
  [R_NECK, R_HEAD], [R_CHEST, R_HEAD],
  [R_SHL, R_HANDL], [R_SHR, R_HANDR],
];
const RAG_LINKS = RAG_PAIRS.map(([a, b]) => ({
  a,
  b,
  len: Math.hypot(
    RAG_REST[a][0] - RAG_REST[b][0],
    RAG_REST[a][1] - RAG_REST[b][1],
    RAG_REST[a][2] - RAG_REST[b][2]
  ),
}));
const CLIMB_STEP = 0.62;
const MAX_CLIMB_HEIGHT = 9.5;

const SKIN_PALETTE = [0x7d8f6a, 0x8a9a78, 0x6f7f66, 0x95a283, 0x7a8870, 0x8f8d78, 0x6d7b5e];
const SHIRT_PALETTE = [0x3a3f48, 0x4b3a3a, 0x2f4a3d, 0x57514a, 0x3d3550, 0x6a2e2a, 0x2d3a52, 0x5c5a3a, 0x24262b, 0x70645a];
const PANTS_PALETTE = [0x2b3445, 0x3a3a3f, 0x4d4636, 0x23262d, 0x363b2f, 0x3f3a45];

const _m = new THREE.Matrix4();
const _root = new THREE.Matrix4();
const _torso = new THREE.Matrix4();
const _local = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _q2 = new THREE.Quaternion();
const _e = new THREE.Euler();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
const _one = new THREE.Vector3(1, 1, 1);
const _yAxis = new THREE.Vector3(0, 1, 0);
const _xAxis = new THREE.Vector3(1, 0, 0);
const _col = new THREE.Color();
const _zero = new THREE.Matrix4().makeScale(0, 0, 0);
const _rp: THREE.Vector3[] = Array.from({ length: RAG_N }, () => new THREE.Vector3());
const _rUp = new THREE.Vector3();
const _rSide = new THREE.Vector3();
const _rFwd = new THREE.Vector3();
const _rhx = new THREE.Vector3();
const _rhy = new THREE.Vector3();
const _rhz = new THREE.Vector3();

function basisMatrix(
  out: THREE.Matrix4,
  x: THREE.Vector3,
  y: THREE.Vector3,
  z: THREE.Vector3,
  pos: THREE.Vector3,
  sc: number
) {
  out.makeBasis(x, y, z);
  const e = out.elements;
  for (let i = 0; i < 12; i++) e[i] *= sc;
  e[12] = pos.x;
  e[13] = pos.y;
  e[14] = pos.z;
  return out;
}

/** make `hint` perpendicular to unit vector `y` (fallback axis when they are parallel) */
function orthoTo(out: THREE.Vector3, hint: THREE.Vector3, y: THREE.Vector3) {
  out.copy(hint).addScaledVector(y, -hint.dot(y));
  if (out.lengthSq() < 1e-6) out.set(Math.abs(y.x) < 0.9 ? 1 : 0, Math.abs(y.x) < 0.9 ? 0 : 1, 0).addScaledVector(y, 0);
  return out.normalize();
}

function setLocal(out: THREE.Matrix4, px: number, py: number, pz: number, rx: number, ry: number, rz: number) {
  _e.set(rx, ry, rz, 'XYZ');
  _q.setFromEuler(_e);
  return out.compose(_p.set(px, py, pz), _q, _one);
}

function rnd(a: number, b: number) {
  return a + Math.random() * (b - a);
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export class ZombieHordeManager {
  private scene: THREE.Scene;
  private colliders: BoxCollider3D[];
  private getGround: (x: number, z: number, footY: number) => number;

  public active = false;
  public phase: HordePhase = 'idle';
  public wave = 0;
  public kills = 0;
  public headshots = 0;
  public bestWave = 0;

  private group = new THREE.Group();
  private zombies: Zombie[] = [];
  private slots: (Zombie | null)[] = new Array(MAX_SLOTS).fill(null);
  private highWater = 0;
  private columns: Column[] = [];
  private nextId = 1;

  private meshes: {
    torso: THREE.InstancedMesh;
    head: THREE.InstancedMesh;
    armL: THREE.InstancedMesh;
    armR: THREE.InstancedMesh;
    legL: THREE.InstancedMesh;
    legR: THREE.InstancedMesh;
    eyes: THREE.InstancedMesh;
  };

  private meshList: THREE.InstancedMesh[] = [];
  private arena: HordeArena = { minX: -60, maxX: 60, minZ: -60, maxZ: 60 };
  private waveTotal = 0;
  private spawnQueue = 0;
  private surgeTimer = 0;
  private waveDirs: number[] = [];
  private intermissionLeft = 0;
  private groanTimer = 1;
  private biteGlobalCd = 0;
  private time = 0;
  private tallestPile = 0;
  private climbingCount = 0;
  private nearbyCount = 0;
  /** zombies of the current surge still waiting to be created (max 4 per frame → no spawn hitches) */
  private pendingSpawn: { ax: number; az: number; left: number } | null = null;
  private bannerId = 0;
  private bannerText = '';

  private hash = new Map<number, Zombie[]>();
  private hashPool: Zombie[][] = [];

  constructor(
    scene: THREE.Scene,
    colliders: BoxCollider3D[],
    getGround: (x: number, z: number, footY: number) => number
  ) {
    this.scene = scene;
    this.colliders = colliders;
    this.getGround = getGround;

    // ---------------- Low-poly zombie body-part geometry ----------------
    const box = (w: number, h: number, d: number, x = 0, y = 0, z = 0) => {
      const g = new THREE.BoxGeometry(w, h, d).toNonIndexed();
      g.translate(x, y, z);
      return g;
    };
    const torsoGeo = box(0.46, 0.66, 0.26, 0, 0.33, 0);
    // taper the shoulders / hips a little for a hunched look
    {
      const pos = torsoGeo.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const y = pos.getY(i);
        const sx = y > 0.4 ? 1.12 : 0.9;
        pos.setX(i, pos.getX(i) * sx);
      }
      torsoGeo.computeVertexNormals();
    }
    const headGeo = new THREE.IcosahedronGeometry(0.15, 0).toNonIndexed();
    headGeo.scale(1.0, 1.18, 1.06);
    headGeo.translate(0, 0.15, 0);
    headGeo.computeVertexNormals();

    const armGeoL = box(0.12, 0.64, 0.12, 0, -0.3, 0);
    const legGeo = box(0.17, 0.92, 0.19, 0, -0.46, 0);

    const eyeGeoParts = [box(0.045, 0.028, 0.02, -0.055, 0.19, 0.152), box(0.045, 0.028, 0.02, 0.055, 0.19, 0.152)];
    const eyeGeo = mergeGeometries(eyeGeoParts, false) ?? eyeGeoParts[0];

    const flesh = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.92, metalness: 0.0, flatShading: true });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff4a1c });

    const mk = (geo: THREE.BufferGeometry, mat: THREE.Material, shadow: boolean) => {
      const mesh = new THREE.InstancedMesh(geo, mat, MAX_SLOTS);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.frustumCulled = false;
      mesh.castShadow = shadow;
      mesh.receiveShadow = true;
      mesh.userData.isFx = true;
      mesh.raycast = () => {};
      mesh.count = 0;
      for (let i = 0; i < MAX_SLOTS; i++) {
        mesh.setMatrixAt(i, _zero);
        mesh.setColorAt(i, _col.set(0xffffff));
      }
      this.group.add(mesh);
      return mesh;
    };

    this.meshes = {
      torso: mk(torsoGeo, flesh, true),
      head: mk(headGeo, flesh, true),
      armL: mk(armGeoL, flesh, true),
      armR: mk(armGeoL, flesh, true),
      legL: mk(legGeo, flesh, true),
      legR: mk(legGeo, flesh, true),
      eyes: mk(eyeGeo, eyeMat, false),
    };
    this.group.visible = false;
    this.meshList = Object.values(this.meshes);
    scene.add(this.group);
  }

  // =============================================================================
  //  PUBLIC API
  // =============================================================================
  public start(arena: HordeArena) {
    this.clearAll();
    this.arena = arena;
    this.active = true;
    this.group.visible = true;
    this.kills = 0;
    this.headshots = 0;
    this.wave = 0;
    this.biteGlobalCd = 0;
    this.beginIntermission(3.2, true);
  }

  public stop() {
    this.clearAll();
    this.active = false;
    this.phase = 'idle';
    this.group.visible = false;
  }

  /** compile the zombie shader programs up-front so the first wave does not hitch */
  public prewarm(renderer: THREE.WebGLRenderer, camera: THREE.Camera) {
    const prev = this.group.visible;
    this.group.visible = true;
    renderer.compile(this.scene, camera);
    this.group.visible = prev;
  }

  public setArena(arena: HordeArena) {
    this.arena = arena;
  }

  public dispose() {
    this.clearAll();
    this.scene.remove(this.group);
    for (const mesh of Object.values(this.meshes)) {
      mesh.geometry.dispose();
      mesh.dispose();
    }
  }

  public gameOver() {
    if (this.phase === 'gameover') return;
    this.phase = 'gameover';
    this.bestWave = Math.max(this.bestWave, this.wave);
    this.say('GAME OVER — KERUMUNAN MENGALAHKANMU');
  }

  public getAliveCount() {
    let n = 0;
    for (const z of this.zombies) if (z.state !== 'dead') n++;
    return n;
  }

  public getHud(): HordeHud {
    const alive = this.getAliveCount();
    return {
      active: this.active,
      phase: this.phase,
      wave: this.wave,
      alive,
      remaining: alive + this.spawnQueue,
      waveTotal: this.waveTotal,
      kills: this.kills,
      headshots: this.headshots,
      intermissionLeft: Math.ceil(this.intermissionLeft),
      tallestPile: this.tallestPile,
      climbing: this.climbingCount,
      nearby: this.nearbyCount,
      bestWave: Math.max(this.bestWave, this.wave),
      bannerId: this.bannerId,
      bannerText: this.bannerText,
    };
  }

  /** Ray vs all living zombies (head sphere + 3-sphere body chain). */
  public raycast(origin: THREE.Vector3, dir: THREE.Vector3, maxDist: number): ZombieHit | null {
    let best: ZombieHit | null = null;
    let bestT = maxDist;
    for (const z of this.zombies) {
      if (z.state === 'dead') continue;
      const s = z.scale;
      const cy = z.y + z.hopY + 0.9 * s;
      const cx = z.x - origin.x;
      const cyy = cy - origin.y;
      const cz = z.z - origin.z;
      const tc = cx * dir.x + cyy * dir.y + cz * dir.z;
      if (tc < -1.5 || tc > bestT + 1.5) continue;
      const d2 = cx * cx + cyy * cyy + cz * cz - tc * tc;
      if (d2 > 1.15 * s * 1.15 * s) continue;

      // head
      const fx = Math.sin(z.yaw);
      const fz = Math.cos(z.yaw);
      const lean = z.state === 'climb' ? 0.05 : 0.17;
      const hx = z.x + fx * lean * s;
      const hz = z.z + fz * lean * s;
      const hy = z.y + z.hopY + (z.state === 'climb' ? 1.68 : 1.6) * s;
      const th = this.raySphere(origin, dir, hx, hy, hz, 0.21 * s);
      // body chain
      let tb = Infinity;
      const b1 = this.raySphere(origin, dir, z.x, z.y + z.hopY + 0.45 * s, z.z, 0.3 * s);
      const b2 = this.raySphere(origin, dir, z.x + fx * 0.06 * s, z.y + z.hopY + 0.98 * s, z.z + fz * 0.06 * s, 0.36 * s);
      const b3 = this.raySphere(origin, dir, z.x + fx * 0.12 * s, z.y + z.hopY + 1.34 * s, z.z + fz * 0.12 * s, 0.32 * s);
      tb = Math.min(b1, b2, b3);

      const isHead = th < Infinity && th <= tb + 0.2;
      const t = isHead ? th : tb;
      if (t < bestT && t >= 0) {
        bestT = t;
        best = {
          zombieId: z.id,
          hitbox: isHead ? 'head' : 'body',
          dist: t,
          point: new THREE.Vector3().copy(origin).addScaledVector(dir, t),
        };
      }
    }
    return best;
  }

  private raySphere(o: THREE.Vector3, d: THREE.Vector3, cx: number, cy: number, cz: number, r: number): number {
    const ox = o.x - cx;
    const oy = o.y - cy;
    const oz = o.z - cz;
    const b = ox * d.x + oy * d.y + oz * d.z;
    const c = ox * ox + oy * oy + oz * oz - r * r;
    const disc = b * b - c;
    if (disc < 0) return Infinity;
    const t = -b - Math.sqrt(disc);
    if (t >= 0) return t;
    const t2 = -b + Math.sqrt(disc);
    return t2 >= 0 ? t2 : Infinity;
  }

  public applyDamage(
    id: number,
    damage: number,
    isHead: boolean,
    fromPos: THREE.Vector3,
    hitPoint?: THREE.Vector3
  ): { killed: boolean; pos: THREE.Vector3; isBrute: boolean } | null {
    const z = this.zombies.find((q) => q.id === id);
    if (!z || z.state === 'dead') return null;
    z.hp -= isHead ? Math.max(damage, z.kind === 'brute' ? damage * 1.8 : 140) : damage;
    z.stagger = z.kind === 'brute' ? 0.1 : 0.28;
    // knock-back
    const dx = z.x - fromPos.x;
    const dz = z.z - fromPos.z;
    const dl = Math.hypot(dx, dz) || 1;
    const kb = (z.kind === 'brute' ? 0.05 : 0.2) * Math.min(2.5, damage / 28);
    z.x += (dx / dl) * kb;
    z.z += (dz / dl) * kb;
    const pos = new THREE.Vector3(z.x, z.y + z.hopY + 1.0 * z.scale, z.z);
    if (z.hp <= 0) {
      // bullet impulse: stronger for big calibres & headshots, pushes the body away from the shooter
      const force = (6.5 + damage * 0.06 + (isHead ? 1.6 : 0)) * (z.kind === 'brute' ? 0.55 : 1);
      this.killZombie(z, isHead, {
        dx: dx / dl,
        dz: dz / dl,
        force,
        up: isHead ? 0.35 : 0.22,
        hitY: hitPoint ? hitPoint.y : z.y + (isHead ? 1.6 : 1.2) * z.scale,
      });
      return { killed: true, pos, isBrute: z.kind === 'brute' };
    }
    return { killed: false, pos, isBrute: z.kind === 'brute' };
  }

  /** Explosion: lethal inside inner radius, heavy damage up to radius. Returns kill count. */
  public applyExplosion(center: THREE.Vector3, radius: number): number {
    let kills = 0;
    for (const z of this.zombies) {
      if (z.state === 'dead') continue;
      const d = Math.hypot(z.x - center.x, z.z - center.z, (z.y + 0.9 - center.y) * 0.6);
      if (d > radius) continue;
      const fall = 1 - d / radius;
      const dmg = 40 + 520 * fall * fall;
      z.hp -= dmg;
      if (z.hp <= 0) {
        // blast throws the body away from the centre and up
        const dx = z.x - center.x;
        const dz = z.z - center.z;
        const dl = Math.hypot(dx, dz) || 1;
        this.killZombie(z, false, {
          dx: dx / dl,
          dz: dz / dl,
          force: 5 + 15 * fall,
          up: 0.9 + fall * 0.6,
          hitY: z.y + 0.5,
        });
        kills++;
      } else {
        z.stagger = 0.9;
      }
    }
    return kills;
  }

  // =============================================================================
  //  UPDATE
  // =============================================================================
  public update(ctx: HordeUpdateContext) {
    if (!this.active) return;
    const dt = Math.min(ctx.dt, 0.05);
    this.time += dt;
    this.biteGlobalCd = Math.max(0, this.biteGlobalCd - dt);

    // ------------- wave director -------------
    if (this.phase === 'intermission') {
      this.intermissionLeft -= dt;
      if (this.intermissionLeft <= 0) this.beginWave(this.wave + 1);
    } else if (this.phase === 'combat') {
      this.runSpawner(dt, ctx.playerPos);
      this.drainPending(ctx.playerPos);
      if (this.spawnQueue <= 0 && !this.pendingSpawn && this.getAliveCount() === 0) {
        this.say(`WAVE ${this.wave} SELESAI`);
        this.bestWave = Math.max(this.bestWave, this.wave);
        this.beginIntermission(7, false);
      }
    }

    // ------------- spatial hash -------------
    this.rebuildHash();

    // ------------- zombie sim -------------
    this.climbingCount = 0;
    this.nearbyCount = 0;
    const px = ctx.playerPos.x;
    const pz = ctx.playerPos.z;

    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      if (z.state === 'dead') {
        z.deadT += dt;
        if (z.rag) {
          this.stepRagdoll(z, dt);
        } else {
          z.fallAngle = Math.min(1, z.fallAngle + dt * 3.2);
          const g = this.groundAt(z.x, z.z, z.y);
          if (z.y > g + 0.01) {
            z.vy -= 22 * dt;
            z.y = Math.max(g, z.y + z.vy * dt);
          } else {
            z.y = g;
            z.vy = 0;
          }
        }
        if (z.deadT > 9) {
          this.releaseZombie(z, i);
        }
        continue;
      }
      const ox = z.x;
      const oz = z.z;
      this.simulateZombie(z, ctx, px, pz, dt);
      z.vx = (z.x - ox) / Math.max(dt, 1e-4);
      z.vz = (z.z - oz) / Math.max(dt, 1e-4);
      if (z.state === 'climb') this.climbingCount++;
    }

    // ------------- climbing columns upkeep -------------
    this.tallestPile = 0;
    for (let c = this.columns.length - 1; c >= 0; c--) {
      const col = this.columns[c];
      col.members = col.members.filter((m) => m.state === 'climb' && m.column === col);
      col.idle += dt;
      if (col.idle > 0.9) col.lift += dt * 1.5; // living-ladder conveyor: tower keeps rising & spilling over
      if (col.members.length === 0) {
        this.columns.splice(c, 1);
        continue;
      }
      let topY = col.baseY;
      for (const m of col.members) if (m.y > topY) topY = m.y;
      this.tallestPile = Math.max(this.tallestPile, topY - col.baseY + 1.7);
    }

    // ------------- ambience: groans -------------
    this.groanTimer -= dt;
    if (this.groanTimer <= 0) {
      const live = this.zombies.filter((z) => z.state !== 'dead');
      if (live.length > 0) {
        const z = pick(live);
        const d = Math.hypot(z.x - px, z.z - pz);
        soundEngine.playZombieGroan(d, z.kind === 'brute');
      }
      this.groanTimer = rnd(0.25, 0.9) * (this.zombies.length > 80 ? 0.6 : 1.0);
    }

    this.writeInstances(ctx);
  }

  // -----------------------------------------------------------------------------
  private rebuildHash() {
    for (const arr of this.hash.values()) {
      arr.length = 0;
      this.hashPool.push(arr);
    }
    this.hash.clear();
    for (const z of this.zombies) {
      if (z.state === 'dead') continue;
      const key = this.cellKey(z.x, z.z);
      let arr = this.hash.get(key);
      if (!arr) {
        arr = this.hashPool.pop() ?? [];
        this.hash.set(key, arr);
      }
      arr.push(z);
    }
  }

  private cellKey(x: number, z: number) {
    return (Math.floor(x / 1.6) + 2048) * 4096 + (Math.floor(z / 1.6) + 2048);
  }

  private groundAt(x: number, z: number, y: number): number {
    let g = this.getGround(x, z, Math.max(0, y));
    for (const c of this.colliders) {
      if (c.disabled) continue;
      if (c.maxY - c.minY > 40) continue;
      if (x > c.minX && x < c.maxX && z > c.minZ && z < c.maxZ) {
        if (c.maxY <= y + 0.7 && c.maxY > g) g = c.maxY;
      }
    }
    return g;
  }

  private insideSolid(x: number, z: number, y: number, margin: number): boolean {
    for (const c of this.colliders) {
      if (c.disabled) continue;
      if (y + 1.7 <= c.minY || y + 0.3 >= c.maxY) continue;
      if (x > c.minX - margin && x < c.maxX + margin && z > c.minZ - margin && z < c.maxZ + margin) return true;
    }
    return false;
  }

  private simulateZombie(z: Zombie, ctx: HordeUpdateContext, px: number, pz: number, dt: number) {
    const s = z.scale;
    z.stagger = Math.max(0, z.stagger - dt);
    z.attackCd = Math.max(0, z.attackCd - dt);
    z.attacking = false;

    let dx = px - z.x;
    let dz = pz - z.z;
    const dist = Math.hypot(dx, dz) || 0.0001;
    dx /= dist;
    dz /= dist;
    if (dist < 14) this.nearbyCount++;

    const staggerSlow = z.stagger > 0 ? 0.25 : 1.0;
    const pulse = 1 + 0.16 * Math.sin(this.time * 1.7 + z.seed * 6.28);

    // ---------------------------------------------------------- CLIMB (zombie pyramid)
    if (z.state === 'climb' && z.column) {
      const col = z.column;
      const idx = col.members.indexOf(z);
      const slotIdx = idx < 0 ? 0 : idx;
      const targetY = Math.min(col.topY + 0.3, col.baseY + (slotIdx + col.lift) * CLIMB_STEP);
      const tx = col.x + z.jx;
      const tz = col.z + z.jz;
      // converge on the column then rise
      const ex = tx - z.x;
      const ez = tz - z.z;
      const ed = Math.hypot(ex, ez);
      const mv = Math.min(ed, z.speed * 0.9 * dt);
      if (ed > 0.02) {
        z.x += (ex / ed) * mv;
        z.z += (ez / ed) * mv;
      }
      const rise = ed < 0.6 ? 2.6 : 0;
      if (z.y < targetY) z.y = Math.min(targetY, z.y + rise * dt);
      else z.y = Math.max(targetY, z.y - 4 * dt);
      z.yaw = this.lerpAngle(z.yaw, col.faceYaw, Math.min(1, dt * 8));
      z.phase += dt * 6.5;
      // reached the top of the wall → vault over it
      if (z.y >= col.topY - 0.55 && ed < 0.8) {
        z.state = 'vault';
        z.ignoreCol = col.col;
        z.vaultT = 0;
        z.vy = 0;
        z.column = null;
        z.blockedTime = 0;
      }
      // brute jam failsafe: member count shrinks while we climb → keep inside bounds
      return;
    }

    // ---------------------------------------------------------- VAULT over wall top
    if (z.state === 'vault') {
      z.vaultT += dt;
      const col = z.ignoreCol;
      const topY = col ? col.maxY : z.y;
      z.y = Math.min(topY, z.y + 4.2 * dt);
      const sp = z.speed * 0.9 * staggerSlow;
      this.moveWithCollision(z, z.x + dx * sp * dt, z.z + dz * sp * dt);
      z.yaw = this.lerpAngle(z.yaw, Math.atan2(dx, dz), Math.min(1, dt * 7));
      z.phase += dt * 8;
      if (z.vaultT > 0.95) {
        z.state = 'run';
        z.ignoreCol = null;
        z.vy = 0;
      }
      return;
    }

    // ---------------------------------------------------------- HOP over the crowd
    if (z.state === 'hop') {
      z.hopT += dt;
      const T = 1.15;
      const u = Math.min(1, z.hopT / T);
      z.hopY = Math.pow(Math.sin(Math.PI * u), 0.65) * 1.05 * s;
      const sp = z.speed * 0.95 * staggerSlow;
      this.moveWithCollision(z, z.x + dx * sp * dt, z.z + dz * sp * dt);
      z.yaw = this.lerpAngle(z.yaw, Math.atan2(dx, dz), Math.min(1, dt * 9));
      z.phase += dt * 9;
      if (u >= 1) {
        z.state = 'run';
        z.hopY = 0;
        z.jamTime = -1.4;
      }
      return;
    }

    // ---------------------------------------------------------- RUN / ATTACK
    // desired direction + wobble
    const wob = Math.sin(this.time * 0.9 + z.seed * 40) * 0.22;
    let dirx = dx + -dz * wob;
    let dirz = dz + dx * wob;

    // crowd separation
    let sepx = 0;
    let sepz = 0;
    const cx = Math.floor(z.x / 1.6);
    const cz = Math.floor(z.z / 1.6);
    for (let ox = -1; ox <= 1; ox++) {
      for (let oz = -1; oz <= 1; oz++) {
        const arr = this.hash.get((cx + ox + 2048) * 4096 + (cz + oz + 2048));
        if (!arr) continue;
        for (const o of arr) {
          if (o === z || o.state === 'climb') continue;
          if (Math.abs(o.y + o.hopY - z.y - z.hopY) > 0.7) continue;
          const sx = z.x - o.x;
          const sz = z.z - o.z;
          const d2 = sx * sx + sz * sz;
          const rr = (z.radius + o.radius) * 1.05;
          if (d2 < rr * rr && d2 > 1e-6) {
            const d = Math.sqrt(d2);
            const w = (rr - d) / rr;
            sepx += (sx / d) * w;
            sepz += (sz / d) * w;
          }
        }
      }
    }
    dirx += sepx * 1.9;
    dirz += sepz * 1.9;
    const dl = Math.hypot(dirx, dirz) || 1;
    dirx /= dl;
    dirz /= dl;

    const inReach = dist < z.reach && Math.abs(ctx.playerFootY + 0.9 - (z.y + 0.9 * s)) < 2.1;
    let moveSpeed = z.speed * pulse * staggerSlow;
    if (inReach && ctx.playerAlive) {
      moveSpeed = 0;
      z.attacking = true;
      if (z.attackCd <= 0 && this.biteGlobalCd <= 0) {
        z.attackCd = rnd(0.8, 1.15);
        this.biteGlobalCd = 0.16;
        ctx.onBite(z.damage, _p.set(z.x, z.y + 1.2 * s, z.z), z.kind === 'brute');
      }
    }

    const nx = z.x + dirx * moveSpeed * dt;
    const nz = z.z + dirz * moveSpeed * dt;
    const before = Math.hypot(px - z.x, pz - z.z);
    this.moveWithCollision(z, nx, nz);
    const after = Math.hypot(px - z.x, pz - z.z);

    // face the player (smooth)
    z.yaw = this.lerpAngle(z.yaw, Math.atan2(dx, dz), Math.min(1, dt * 7));
    z.phase += dt * moveSpeed * z.animRate / s + dt * (z.attacking ? 4 : 0.8);

    // progress monitoring → crowd hop / wall climb
    const progress = moveSpeed > 0.01 ? (before - after) / (moveSpeed * dt + 1e-5) : 1;
    if (!inReach && progress < 0.28 && dist < 16 && dist > z.reach * 1.2 && !z.blockCol) {
      z.jamTime += dt;
    } else {
      z.jamTime = Math.min(0, z.jamTime) < 0 ? Math.min(0, z.jamTime + dt) : Math.max(0, z.jamTime - dt * 2);
    }
    if (z.jamTime > 0.75 && z.stagger <= 0) {
      z.state = 'hop';
      z.hopT = 0;
      z.jamTime = 0;
    }

    if (z.blockCol) {
      z.blockedTime += dt;
      if (z.blockedTime > 0.28) this.tryStartClimb(z, z.blockCol);
    } else {
      z.blockedTime = Math.max(0, z.blockedTime - dt * 2);
    }

    // gravity / ground follow
    const g = this.groundAt(z.x, z.z, z.y);
    if (z.y > g + 0.02) {
      z.vy -= 22 * dt;
      z.y = Math.max(g, z.y + z.vy * dt);
    } else {
      z.y = g;
      z.vy = 0;
    }
  }

  private moveWithCollision(z: Zombie, nx: number, nz: number) {
    const r = z.radius;
    const low = z.y + 0.3;
    const high = z.y + 1.7 * z.scale;
    let blockedX = false;
    let blockedZ = false;
    let hitCol: BoxCollider3D | null = null;
    for (const c of this.colliders) {
      if (c.disabled || c === z.ignoreCol) continue;
      if (high <= c.minY || low >= c.maxY) continue;
      if (nx > c.minX - r && nx < c.maxX + r && z.z > c.minZ - r && z.z < c.maxZ + r) {
        blockedX = true;
        hitCol = c;
      }
      if (z.x > c.minX - r && z.x < c.maxX + r && nz > c.minZ - r && nz < c.maxZ + r) {
        blockedZ = true;
        hitCol = c;
      }
    }
    if (!blockedX) z.x = nx;
    if (!blockedZ) z.z = nz;
    z.blockCol = blockedX || blockedZ ? hitCol : null;

    // arena bounds
    const a = this.arena;
    z.x = THREE.MathUtils.clamp(z.x, a.minX, a.maxX);
    z.z = THREE.MathUtils.clamp(z.z, a.minZ, a.maxZ);
  }

  private tryStartClimb(z: Zombie, c: BoxCollider3D) {
    const topH = c.maxY - z.y;
    if (topH <= 0.2) return;
    if (topH <= 1.25) {
      // low obstacle: quick vault
      z.state = 'vault';
      z.ignoreCol = c;
      z.vaultT = 0.35;
      z.blockedTime = 0;
      return;
    }
    if (topH > MAX_CLIMB_HEIGHT) {
      z.blockedTime = 0;
      // too tall: slide along it
      return;
    }
    // find existing column on this collider nearby
    let best: Column | null = null;
    let bestD = 3.6;
    for (const col of this.columns) {
      if (col.col !== c) continue;
      const maxMembers = Math.floor((col.topY - col.baseY) / CLIMB_STEP) + 2;
      if (col.members.length >= maxMembers) continue;
      const d = Math.hypot(col.x - z.x, col.z - z.z);
      if (d < bestD) {
        bestD = d;
        best = col;
      }
    }
    if (!best) {
      // face direction = toward nearest point on the collider
      const qx = THREE.MathUtils.clamp(z.x, c.minX, c.maxX);
      const qz = THREE.MathUtils.clamp(z.z, c.minZ, c.maxZ);
      let fx = qx - z.x;
      let fz = qz - z.z;
      if (Math.abs(fx) + Math.abs(fz) < 0.01) {
        fx = (c.minX + c.maxX) * 0.5 - z.x;
        fz = (c.minZ + c.maxZ) * 0.5 - z.z;
      }
      best = {
        col: c,
        x: z.x,
        z: z.z,
        baseY: z.y,
        topY: c.maxY,
        faceYaw: Math.atan2(fx, fz),
        members: [],
        idle: 0,
        lift: 0,
      };
      this.columns.push(best);
    }
    z.state = 'climb';
    z.column = best;
    z.jx = rnd(-0.22, 0.22);
    z.jz = rnd(-0.22, 0.22);
    z.blockedTime = 0;
    best.members.push(z);
    best.idle = 0;
  }

  private lerpAngle(a: number, b: number, t: number) {
    let d = b - a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return a + d * t;
  }

  // =============================================================================
  //  WAVES / SPAWNING
  // =============================================================================
  private say(text: string) {
    this.bannerId++;
    this.bannerText = text;
  }

  private beginIntermission(seconds: number, first: boolean) {
    this.phase = 'intermission';
    this.intermissionLeft = seconds;
    if (first) this.say('BERSIAPLAH — KERUMUNAN DATANG');
  }

  private beginWave(n: number) {
    this.wave = n;
    this.phase = 'combat';
    this.waveTotal = 36 + (n - 1) * 26;
    this.spawnQueue = this.waveTotal;
    this.surgeTimer = 0.2;
    const dirCount = Math.min(4, 1 + Math.floor(n / 2));
    this.waveDirs = [];
    const base = Math.random() * Math.PI * 2;
    for (let i = 0; i < dirCount; i++) this.waveDirs.push(base + (i / dirCount) * Math.PI * 2 + rnd(-0.5, 0.5));
    this.say(`WAVE ${n} — ${this.waveTotal} ZOMBIE`);
    soundEngine.playHordeHorn(n >= 4);
  }

  private maxConcurrent() {
    return Math.min(250, 90 + this.wave * 16);
  }

  private runSpawner(dt: number, playerPos: THREE.Vector3) {
    if (this.spawnQueue <= 0) return;
    this.surgeTimer -= dt;
    if (this.surgeTimer > 0) return;
    const alive = this.getAliveCount();
    if (alive >= this.maxConcurrent()) {
      this.surgeTimer = 0.5;
      return;
    }
    const size = Math.min(this.spawnQueue, Math.floor(rnd(7, 15)));
    this.spawnCluster(size, playerPos);
    this.spawnQueue -= size;
    this.surgeTimer = Math.max(0.9, 3.2 - this.wave * 0.2) * rnd(0.7, 1.2);
  }

  private chooseKind(): ZombieKind {
    const w = this.wave;
    const r = Math.random();
    const bruteP = w >= 3 ? Math.min(0.1, 0.02 + w * 0.01) : 0;
    if (r < bruteP) return 'brute';
    const runnerP = Math.min(0.62, 0.3 + w * 0.05);
    return Math.random() < runnerP ? 'runner' : 'walker';
  }

  private spawnCluster(count: number, playerPos: THREE.Vector3) {
    const a = this.arena;
    // pick anchor
    let ax = 0;
    let az = 0;
    let ok = false;
    for (let attempt = 0; attempt < 24 && !ok; attempt++) {
      const ang = pick(this.waveDirs) + rnd(-0.45, 0.45);
      const R = rnd(40, 66) - attempt * 0.7;
      ax = playerPos.x + Math.sin(ang) * R;
      az = playerPos.z + Math.cos(ang) * R;
      if (ax < a.minX + 2 || ax > a.maxX - 2 || az < a.minZ + 2 || az > a.maxZ - 2) continue;
      if (this.insideSolid(ax, az, this.getGround(ax, az, 0), 1.2)) continue;
      ok = true;
    }
    if (!ok) {
      for (let attempt = 0; attempt < 40 && !ok; attempt++) {
        ax = rnd(a.minX + 2, a.maxX - 2);
        az = rnd(a.minZ + 2, a.maxZ - 2);
        if (Math.hypot(ax - playerPos.x, az - playerPos.z) < 24) continue;
        if (this.insideSolid(ax, az, this.getGround(ax, az, 0), 1.2)) continue;
        ok = true;
      }
    }
    if (!ok) return;

    this.pendingSpawn = { ax, az, left: count };
    this.drainPending(playerPos);
  }

  private drainPending(playerPos: THREE.Vector3) {
    const pend = this.pendingSpawn;
    if (!pend) return;
    const a = this.arena;
    const n = Math.min(4, pend.left);
    for (let i = 0; i < n; i++) {
      for (let attempt = 0; attempt < 6; attempt++) {
        const px = pend.ax + rnd(-4.5, 4.5);
        const pz = pend.az + rnd(-4.5, 4.5);
        if (px < a.minX || px > a.maxX || pz < a.minZ || pz > a.maxZ) continue;
        const gy = this.getGround(px, pz, 0);
        if (this.insideSolid(px, pz, gy, 0.5)) continue;
        this.spawnZombie(px, gy, pz, this.chooseKind(), playerPos);
        break;
      }
    }
    pend.left -= n;
    if (pend.left <= 0) this.pendingSpawn = null;
  }

  private allocSlot(): number {
    for (let i = 0; i < MAX_SLOTS; i++) {
      if (!this.slots[i]) return i;
    }
    // evict the oldest corpse
    let oldest: Zombie | null = null;
    let idx = -1;
    for (let i = 0; i < this.zombies.length; i++) {
      const z = this.zombies[i];
      if (z.state === 'dead' && (!oldest || z.deadT > oldest.deadT)) {
        oldest = z;
        idx = i;
      }
    }
    if (oldest) {
      const slot = oldest.slot;
      this.releaseZombie(oldest, idx);
      return slot;
    }
    return -1;
  }

  private spawnZombie(x: number, y: number, zPos: number, kind: ZombieKind, playerPos: THREE.Vector3) {
    const slot = this.allocSlot();
    if (slot < 0) return;
    const w = this.wave;
    let scale = rnd(0.95, 1.08);
    let hp = 55;
    let speed = rnd(3.0, 3.9);
    let damage = 5;
    let radius = 0.34;
    let animRate = 2.6;
    let lean = 0.3;
    if (kind === 'runner') {
      hp = 38;
      speed = rnd(5.0, 6.3) + Math.min(1.0, w * 0.08);
      damage = 4;
      animRate = 2.0;
      lean = 0.46;
      scale = rnd(0.92, 1.04);
    } else if (kind === 'brute') {
      hp = 420 + w * 20;
      speed = rnd(3.0, 3.6);
      damage = 16;
      scale = rnd(1.32, 1.46);
      radius = 0.5;
      animRate = 2.8;
      lean = 0.22;
    } else {
      hp = 55 + w * 2;
    }
    const z: Zombie = {
      id: this.nextId++,
      slot,
      kind,
      state: 'run',
      x,
      y,
      z: zPos,
      vy: 0,
      yaw: Math.atan2(playerPos.x - x, playerPos.z - zPos),
      scale,
      hp,
      maxHp: hp,
      speed,
      radius: radius * scale,
      damage,
      reach: 1.15 + 0.55 * scale,
      phase: Math.random() * 6.28,
      animRate,
      attackCd: rnd(0.2, 0.9),
      stagger: 0,
      hopT: 0,
      hopY: 0,
      jamTime: -0.5,
      blockedTime: 0,
      blockCol: null,
      ignoreCol: null,
      vaultT: 0,
      column: null,
      jx: 0,
      jz: 0,
      armAsym: Math.random(),
      headTilt: rnd(-0.35, 0.35),
      leanBase: lean,
      seed: Math.random(),
      rag: null,
      vx: 0,
      vz: 0,
      deadT: 0,
      fallDir: Math.random() < 0.7 ? -1 : 1,
      fallAngle: 0,
      attacking: false,
    };
    this.slots[slot] = z;
    this.zombies.push(z);
    this.highWater = Math.max(this.highWater, slot + 1);

    // per-instance colors
    const skin = _col.set(pick(SKIN_PALETTE)).clone();
    skin.offsetHSL(rnd(-0.02, 0.02), rnd(-0.05, 0.05), rnd(-0.06, 0.05));
    const shirt = new THREE.Color(pick(SHIRT_PALETTE));
    if (Math.random() < 0.28) shirt.lerp(new THREE.Color(0x7a1010), rnd(0.25, 0.6)); // blood-soaked
    const pants = new THREE.Color(pick(PANTS_PALETTE));
    const sleeved = Math.random() < 0.55;
    const armColor = sleeved ? shirt.clone().multiplyScalar(0.92) : skin;
    if (kind === 'brute') {
      shirt.lerp(new THREE.Color(0x3b1f1a), 0.5);
      skin.lerp(new THREE.Color(0x6a5a4a), 0.35);
    }
    this.meshes.torso.setColorAt(slot, shirt);
    this.meshes.head.setColorAt(slot, skin);
    this.meshes.armL.setColorAt(slot, armColor);
    this.meshes.armR.setColorAt(slot, armColor);
    this.meshes.legL.setColorAt(slot, pants);
    this.meshes.legR.setColorAt(slot, pants);
    this.meshes.eyes.setColorAt(slot, _col.set(0xffffff));
    this.colorsDirty = true;
  }

  private colorsDirty = false;

  private killZombie(z: Zombie, headshot: boolean, imp?: Impulse) {
    const wasClimbing = z.state === 'climb';
    z.state = 'dead';
    z.deadT = 0;
    z.fallAngle = 0;
    const hop = z.hopY;
    z.hopY = 0;
    z.attacking = false;
    if (z.column) {
      z.column.members = z.column.members.filter((m) => m !== z);
      z.column = null;
    }
    this.kills++;
    if (headshot) this.headshots++;
    this.createRagdoll(z, hop, wasClimbing, imp);
  }

  // =============================================================================
  //  RAGDOLL
  // =============================================================================
  private createRagdoll(z: Zombie, hopY: number, climbing: boolean, imp?: Impulse) {
    const s = z.scale;
    const lean = climbing ? 0.05 : z.leanBase;
    const cl = Math.cos(lean);
    const sl = Math.sin(lean);
    const cy = Math.cos(z.yaw);
    const sy = Math.sin(z.yaw);
    const p = new Float32Array(RAG_N * 3);
    const q = new Float32Array(RAG_N * 3);
    for (let i = 0; i < RAG_N; i++) {
      let [lx, ly, lz] = RAG_REST[i];
      // forward lean of the upper body about the pelvis
      if (i === R_NECK || i === R_SHL || i === R_SHR || i === R_HEAD || i === R_CHEST || i === R_HANDL || i === R_HANDR) {
        const dy = ly - 0.92;
        const ny = dy * cl - lz * sl + 0.92;
        const nz = dy * sl + lz * cl;
        ly = ny;
        lz = nz;
      }
      lx *= s;
      ly *= s;
      lz *= s;
      const wx = lx * cy + lz * sy;
      const wz = -lx * sy + lz * cy;
      p[i * 3] = z.x + wx;
      p[i * 3 + 1] = z.y + hopY + ly;
      p[i * 3 + 2] = z.z + wz;
    }
    // inherit the running momentum (m per fixed step)
    const ivx = z.vx * 0.45 * RAG_DT;
    const ivz = z.vz * 0.45 * RAG_DT;
    for (let i = 0; i < RAG_N; i++) {
      q[i * 3] = p[i * 3] - ivx;
      q[i * 3 + 1] = p[i * 3 + 1];
      q[i * 3 + 2] = p[i * 3 + 2] - ivz;
    }
    // static colliders near the body (walls, crates, wall tops)
    const near: BoxCollider3D[] = [];
    for (const c of this.colliders) {
      if (c.disabled) continue;
      if (z.x > c.minX - 7 && z.x < c.maxX + 7 && z.z > c.minZ - 7 && z.z < c.maxZ + 7) near.push(c);
    }
    const rag: Ragdoll = {
      p,
      q,
      gy: new Float32Array(RAG_N),
      acc: 0,
      t: 0,
      rest: 0,
      asleep: false,
      written: false,
      near,
    };
    z.rag = rag;

    // bullet / blast impulse, strongest around the hit height
    const f = imp ?? { dx: Math.sin(z.yaw), dz: Math.cos(z.yaw), force: 3.2, up: 0.2, hitY: z.y + 1.1 * s };
    for (let i = 0; i < RAG_N; i++) {
      const dyh = (p[i * 3 + 1] - f.hitY) / 0.6;
      const w = 0.35 + 0.65 * Math.exp(-dyh * dyh);
      const v = f.force * w * RAG_DT;
      q[i * 3] -= f.dx * v;
      q[i * 3 + 1] -= f.up * v * (0.6 + 0.4 * w);
      q[i * 3 + 2] -= f.dz * v;
    }
    // a little random spin so no two corpses fall alike
    for (let i = 0; i < RAG_N; i++) {
      q[i * 3] -= rnd(-0.004, 0.004);
      q[i * 3 + 2] -= rnd(-0.004, 0.004);
    }

    // cap the number of simulating ragdolls (oldest go to sleep first)
    let active = 0;
    for (const o of this.zombies) if (o.rag && !o.rag.asleep) active++;
    if (active > 36) {
      let oldest: Zombie | null = null;
      for (const o of this.zombies) {
        if (o.rag && !o.rag.asleep && o !== z && (!oldest || o.rag.t > oldest.rag!.t)) oldest = o;
      }
      if (oldest && oldest.rag) {
        oldest.rag.asleep = true;
        oldest.rag.written = false;
      }
    }
  }

  private ragGround(r: Ragdoll, x: number, zPos: number, y: number): number {
    let g = this.getGround(x, zPos, Math.max(0, y));
    for (const c of r.near) {
      if (x > c.minX && x < c.maxX && zPos > c.minZ && zPos < c.maxZ && c.maxY <= y + 0.55 && c.maxY > g && c.maxY - c.minY < 40) {
        g = c.maxY;
      }
    }
    return g;
  }

  private stepRagdoll(z: Zombie, dt: number) {
    const r = z.rag!;
    if (r.asleep) return;
    r.t += dt;
    r.acc += Math.min(dt, 0.05);
    let steps = 0;
    while (r.acc >= RAG_DT && steps < 3) {
      this.ragStep(z, r);
      r.acc -= RAG_DT;
      steps++;
    }
    if (r.t > 6) {
      r.asleep = true;
      r.written = false;
    }
  }

  private ragStep(z: Zombie, r: Ragdoll) {
    const p = r.p;
    const q = r.q;
    const s = z.scale;
    const grav = -24 * RAG_DT * RAG_DT;

    // --- Verlet integration
    let energy = 0;
    for (let i = 0; i < RAG_N; i++) {
      const k = i * 3;
      const vx = (p[k] - q[k]) * 0.993;
      const vy = (p[k + 1] - q[k + 1]) * 0.997;
      const vz = (p[k + 2] - q[k + 2]) * 0.993;
      q[k] = p[k];
      q[k + 1] = p[k + 1];
      q[k + 2] = p[k + 2];
      p[k] += vx;
      p[k + 1] += vy + grav;
      p[k + 2] += vz;
      energy += vx * vx + vz * vz + vy * vy;
      r.gy[i] = this.ragGround(r, p[k], p[k + 2], p[k + 1]);
    }

    // --- constraints + collisions
    for (let iter = 0; iter < 5; iter++) {
      for (const l of RAG_LINKS) {
        const a = l.a * 3;
        const b = l.b * 3;
        const dx = p[b] - p[a];
        const dy = p[b + 1] - p[a + 1];
        const dz = p[b + 2] - p[a + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-5;
        const diff = ((dist - l.len * s) / dist) * 0.5;
        p[a] += dx * diff;
        p[a + 1] += dy * diff;
        p[a + 2] += dz * diff;
        p[b] -= dx * diff;
        p[b + 1] -= dy * diff;
        p[b + 2] -= dz * diff;
      }
      // feet must not cross
      {
        const a = R_FOOTL * 3;
        const b = R_FOOTR * 3;
        const dx = p[b] - p[a];
        const dz = p[b + 2] - p[a + 2];
        const d = Math.hypot(dx, dz);
        const minD = 0.16 * s;
        if (d < minD && d > 1e-5) {
          const push = ((minD - d) / d) * 0.5;
          p[a] -= dx * push;
          p[a + 2] -= dz * push;
          p[b] += dx * push;
          p[b + 2] += dz * push;
        }
      }
      for (let i = 0; i < RAG_N; i++) {
        const k = i * 3;
        const rad = RAG_RADIUS[i] * s;
        // ground
        const floor = r.gy[i] + rad;
        if (p[k + 1] < floor) p[k + 1] = floor;
        // walls & props
        for (const c of r.near) {
          if (p[k + 1] + rad <= c.minY || p[k + 1] - rad >= c.maxY) continue;
          if (p[k] > c.minX - rad && p[k] < c.maxX + rad && p[k + 2] > c.minZ - rad && p[k + 2] < c.maxZ + rad) {
            const pxl = p[k] - (c.minX - rad);
            const pxr = c.maxX + rad - p[k];
            const pzl = p[k + 2] - (c.minZ - rad);
            const pzr = c.maxZ + rad - p[k + 2];
            const pyt = p[k + 1] > c.maxY - 0.35 ? c.maxY + rad - p[k + 1] : 1e9;
            const m = Math.min(pxl, pxr, pzl, pzr, pyt);
            if (m === pyt) p[k + 1] += pyt;
            else if (m === pxl) p[k] -= pxl;
            else if (m === pxr) p[k] += pxr;
            else if (m === pzl) p[k + 2] -= pzl;
            else p[k + 2] += pzr;
          }
        }
      }
    }

    // --- ground friction (once per step) so bodies slide to a stop instead of skating forever
    for (let i = 0; i < RAG_N; i++) {
      const k = i * 3;
      const rad = RAG_RADIUS[i] * s;
      if (p[k + 1] <= r.gy[i] + rad + 0.02) {
        q[k] = p[k] - (p[k] - q[k]) * 0.82;
        q[k + 2] = p[k + 2] - (p[k + 2] - q[k + 2]) * 0.82;
        q[k + 1] = p[k + 1] - (p[k + 1] - q[k + 1]) * 0.2; // tiny bounce
      }
    }

    // --- sleep when settled
    if (energy / RAG_N < 6e-6 && r.t > 0.5) r.rest += RAG_DT;
    else r.rest = 0;
    if (r.rest > 0.45) {
      r.asleep = true;
      r.written = false;
    }
  }

  /** write the 7 instance matrices of a ragdolled corpse from its joint positions */
  private writeRagdoll(z: Zombie, slot: number) {
    const r = z.rag!;
    if (r.asleep && r.written && z.deadT <= 7.8) return; // frozen pose already uploaded
    const m = this.meshes;
    const fadeT = Math.max(0, (z.deadT - 7.8) / 1.2);
    const sc = z.scale * (1 - fadeT);
    const yOff = -fadeT * 0.3;
    for (let i = 0; i < RAG_N; i++) {
      _rp[i].set(r.p[i * 3], r.p[i * 3 + 1] + yOff, r.p[i * 3 + 2]);
    }

    // torso frame: Y = pelvis→neck, X = shoulder L→R
    _rUp.subVectors(_rp[R_NECK], _rp[R_PELVIS]).normalize();
    orthoTo(_rSide, _rhx.subVectors(_rp[R_SHR], _rp[R_SHL]), _rUp);
    _rFwd.crossVectors(_rSide, _rUp);
    basisMatrix(_m, _rSide, _rUp, _rFwd, _rp[R_PELVIS], sc);
    m.torso.setMatrixAt(slot, _m);

    // head
    _rhy.subVectors(_rp[R_HEAD], _rp[R_NECK]).normalize();
    orthoTo(_rhx, _rSide, _rhy);
    _rhz.crossVectors(_rhx, _rhy);
    basisMatrix(_m, _rhx, _rhy, _rhz, _rp[R_NECK], sc);
    m.head.setMatrixAt(slot, _m);
    m.eyes.setMatrixAt(slot, z.deadT > 0.4 ? _zero : _m);

    // limbs: geometry hangs along −Y from its joint, so Y points from the free end back to the joint
    const limb = (mesh: THREE.InstancedMesh, joint: number, end: number) => {
      _rhy.subVectors(_rp[joint], _rp[end]).normalize();
      orthoTo(_rhx, _rSide, _rhy);
      _rhz.crossVectors(_rhx, _rhy);
      basisMatrix(_m, _rhx, _rhy, _rhz, _rp[joint], sc);
      mesh.setMatrixAt(slot, _m);
    };
    limb(m.armL, R_SHL, R_HANDL);
    limb(m.armR, R_SHR, R_HANDR);
    limb(m.legL, R_HIPL, R_FOOTL);
    limb(m.legR, R_HIPR, R_FOOTR);

    if (r.asleep) r.written = true;
  }

  private releaseZombie(z: Zombie, listIdx: number) {
    if (z.column) {
      z.column.members = z.column.members.filter((m) => m !== z);
    }
    this.slots[z.slot] = null;
    const m = this.meshes;
    m.torso.setMatrixAt(z.slot, _zero);
    m.head.setMatrixAt(z.slot, _zero);
    m.armL.setMatrixAt(z.slot, _zero);
    m.armR.setMatrixAt(z.slot, _zero);
    m.legL.setMatrixAt(z.slot, _zero);
    m.legR.setMatrixAt(z.slot, _zero);
    m.eyes.setMatrixAt(z.slot, _zero);
    if (listIdx >= 0) this.zombies.splice(listIdx, 1);
    else {
      const k = this.zombies.indexOf(z);
      if (k >= 0) this.zombies.splice(k, 1);
    }
  }

  private clearAll() {
    for (const z of [...this.zombies]) this.releaseZombie(z, -1);
    this.zombies.length = 0;
    this.columns.length = 0;
    this.slots.fill(null);
    this.highWater = 0;
    this.spawnQueue = 0;
    this.pendingSpawn = null;
    this.waveTotal = 0;
    this.tallestPile = 0;
    this.writeAllZero();
  }

  private writeAllZero() {
    const m = this.meshes;
    for (const mesh of Object.values(m)) {
      mesh.count = 0;
      mesh.instanceMatrix.needsUpdate = true;
    }
  }

  // =============================================================================
  //  RENDER — write instance matrices
  // =============================================================================
  private writeInstances(_ctx: HordeUpdateContext) {
    const m = this.meshes;
    const t = this.time;
    for (const z of this.zombies) {
      const s = z.scale;
      const slot = z.slot;
      const dead = z.state === 'dead';
      if (dead && z.rag) {
        this.writeRagdoll(z, slot);
        continue;
      }

      // ----- root transform -----
      let rootY = z.y + z.hopY;
      _q.setFromAxisAngle(_yAxis, z.yaw);
      let fall = 0;
      if (dead) {
        const e = 1 - Math.pow(1 - z.fallAngle, 3);
        fall = z.fallDir * e * (Math.PI / 2 - 0.08);
        _q2.setFromAxisAngle(_xAxis, fall);
        _q.multiply(_q2);
        rootY += 0.13 * s * e;
        // sink + shrink at end of life
        const fadeT = Math.max(0, (z.deadT - 7.8) / 1.2);
        const sc = s * (1 - fadeT);
        _s.set(sc, sc, sc);
        rootY -= fadeT * 0.25;
      } else {
        _s.set(s, s, s);
      }
      _root.compose(_p.set(z.x, rootY, z.z), _q, _s);

      // ----- animation pose -----
      let lean = z.leanBase;
      let legSwing = 0;
      let legLift = 0;
      let armL = -1.35;
      let armR = -1.15;
      let armSpread = 0.1;
      let bob = 0;
      let sway = 0;
      let headRx = 0.1;
      let headRz = z.headTilt;
      const ph = z.phase;

      if (dead) {
        lean = 0.05;
        armL = -0.4 - z.armAsym * 0.8;
        armR = -0.2 - (1 - z.armAsym) * 0.8;
        armSpread = 0.45;
        headRx = -0.2;
      } else if (z.state === 'climb') {
        lean = 0.08;
        armL = -2.7 + Math.sin(ph * 1.2) * 0.45;
        armR = -2.7 + Math.sin(ph * 1.2 + Math.PI) * 0.45;
        legSwing = Math.sin(ph * 1.2 + 1.0) * 0.75;
        legLift = -0.45;
        armSpread = 0.2;
        bob = Math.abs(Math.sin(ph * 0.6)) * 0.03;
        headRx = -0.5;
        headRz = 0;
      } else if (z.state === 'hop') {
        lean = 0.15;
        armL = -2.3 + Math.sin(ph * 1.4) * 0.4;
        armR = -2.1 + Math.sin(ph * 1.4 + 1.3) * 0.4;
        legSwing = Math.sin(ph * 1.6) * 0.5;
        legLift = -0.85;
        armSpread = 0.35;
        headRx = -0.25;
      } else if (z.state === 'vault') {
        lean = 0.35;
        armL = -2.0;
        armR = -1.8;
        legSwing = Math.sin(ph) * 0.9;
        legLift = -0.3;
        armSpread = 0.3;
      } else if (z.attacking) {
        const a = Math.sin(t * 9 + z.seed * 20);
        lean = 0.36 + a * 0.1;
        armL = -1.15 + a * 0.55;
        armR = -1.15 - a * 0.55;
        armSpread = 0.2;
        headRx = 0.35;
        legSwing = Math.sin(ph) * 0.12;
      } else {
        const sw = Math.sin(ph);
        const run = z.kind === 'runner' ? 1.15 : 0.85;
        legSwing = sw * run;
        bob = Math.abs(sw) * (z.kind === 'runner' ? 0.08 : 0.05);
        armL = (z.armAsym > 0.5 ? -1.55 : -1.2) + Math.sin(ph * 0.5 + 1) * 0.12;
        armR = (z.armAsym > 0.5 ? -1.1 : -1.5) + Math.sin(ph * 0.5) * 0.12;
        if (z.kind === 'runner') {
          // sprinters flail arms
          armL = -0.6 + Math.sin(ph + Math.PI) * 0.9;
          armR = -0.6 + Math.sin(ph) * 0.9;
        }
        sway = sw * 0.08;
        headRz = z.headTilt + Math.sin(ph * 0.5) * 0.12;
        if (z.stagger > 0) {
          lean = -0.15;
          armL = -2.2;
          armR = -2.0;
        }
      }

      const hipY = 0.92 + bob;

      // torso
      setLocal(_local, 0, hipY, 0, lean, 0, sway);
      _torso.multiplyMatrices(_root, _local);
      m.torso.setMatrixAt(slot, _torso);

      // head
      setLocal(_local, 0, 0.68, 0.03, headRx, 0, headRz);
      _m.multiplyMatrices(_torso, _local);
      m.head.setMatrixAt(slot, _m);
      m.eyes.setMatrixAt(slot, dead && z.deadT > 0.4 ? _zero : _m);

      // arms
      setLocal(_local, -0.31, 0.58, 0.0, armL, 0, -armSpread);
      _m.multiplyMatrices(_torso, _local);
      m.armL.setMatrixAt(slot, _m);
      setLocal(_local, 0.31, 0.58, 0.0, armR, 0, armSpread);
      _m.multiplyMatrices(_torso, _local);
      m.armR.setMatrixAt(slot, _m);

      // legs
      setLocal(_local, -0.12, hipY, 0, legLift + legSwing, 0, 0.02);
      _m.multiplyMatrices(_root, _local);
      m.legL.setMatrixAt(slot, _m);
      setLocal(_local, 0.12, hipY, 0, legLift - legSwing, 0, -0.02);
      _m.multiplyMatrices(_root, _local);
      m.legR.setMatrixAt(slot, _m);
    }

    const count = this.highWater;
    for (const mesh of this.meshList) {
      mesh.count = count;
      mesh.instanceMatrix.needsUpdate = true;
      if (this.colorsDirty && mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    }
    this.colorsDirty = false;
  }
}
