/**
 * =====================================================================================
 *  ADAPTIVE QUALITY GOVERNOR — keeps the game at a locked ~60 FPS, as sharp as possible
 * =====================================================================================
 *  Strategy: always START at the highest quality (native-resolution HD). If frame time
 *  rises above the 60 FPS budget the governor immediately steps down the cheapest-to-lose
 *  options first (render resolution, shadow refresh rate, shadow resolution, optional post
 *  effects). When there is spare time it carefully PROBES one level back up and keeps it
 *  only if 60 FPS holds (failed probes are blocked for a while — no flip-flopping).
 * =====================================================================================
 */

export interface QualityLevel {
  name: string;
  /** multiplier on the base pixel ratio (1 = native HD) */
  scale: number;
  /** re-render the sun shadow map every N frames */
  shadowEvery: number;
  shadowSize: number;
  /** 2 = full post (DoF + glare + CA + full iq SDF march) · 1 = lighter · 0 = minimal */
  post: 0 | 1 | 2;
}

export const QUALITY_LEVELS: QualityLevel[] = [
  { name: 'ULTRA', scale: 1.0, shadowEvery: 1, shadowSize: 4096, post: 2 },
  { name: 'TINGGI', scale: 0.92, shadowEvery: 1, shadowSize: 4096, post: 2 },
  { name: 'SEDANG', scale: 0.84, shadowEvery: 2, shadowSize: 3072, post: 1 },
  { name: 'RENDAH', scale: 0.76, shadowEvery: 2, shadowSize: 2048, post: 1 },
  { name: 'HEMAT', scale: 0.66, shadowEvery: 3, shadowSize: 2048, post: 0 },
];

export interface PerfSnapshot {
  fps: number;
  ms: number;
  level: number;
  levelName: string;
  scale: number;
  auto: boolean;
  draws: number;
  tris: number;
  showFps: boolean;
  /** user render scale (1 = native, >1 supersampling) */
  renderScale: number;
  sharpen: number;
  internalW: number;
  internalH: number;
  outW: number;
  outH: number;
}

const WINDOW = 30;
const DOWN_MS = 18.4; // < ~54 fps
const UP_MS = 17.5; // ≥ ~57 fps counts as "holding 60"

export class PerfGovernor {
  public level = 0;
  public auto = true;
  public fps = 60;
  public ms = 16.7;

  private samples: number[] = [];
  private t = 0;
  private lastChange = 0;
  private stable = 0;
  private upBlockUntil = 0;
  private failCount = 0;
  private lastUpTime = -999;

  public setManual(level: number | 'auto') {
    if (level === 'auto') {
      this.auto = true;
      this.stable = 0;
      return this.level;
    }
    this.auto = false;
    this.level = Math.max(0, Math.min(QUALITY_LEVELS.length - 1, level));
    return this.level;
  }

  /** @returns new level index if it changed, else null */
  public tick(dtSec: number): number | null {
    // a huge dt (tab switch / one-off shader hitch) is clamped, never ignored — otherwise a device that is
    // consistently very slow would never leave the warm-up phase.
    if (dtSec <= 0) return null;
    this.t += Math.min(dtSec, 0.25);
    const ms = Math.min(dtSec * 1000, 60);
    this.samples.push(ms);
    if (this.samples.length > WINDOW) this.samples.shift();

    let sum = 0;
    for (const s of this.samples) sum += s;
    const avg = sum / this.samples.length;
    this.ms += (avg - this.ms) * 0.2;
    this.fps = 1000 / Math.max(1, this.ms);

    if (!this.auto) return null;
    if (this.t < 2.0 || this.samples.length < 12) return null; // warm-up (shader compile hitches)

    // ---- step DOWN quickly -------------------------------------------------------
    if (avg > DOWN_MS && this.t - this.lastChange > 0.9 && this.level < QUALITY_LEVELS.length - 1) {
      const steps = avg > 45 ? 3 : avg > 28 ? 2 : 1;
      if (this.t - this.lastUpTime < 7) {
        // the probe upward failed → don't try again for a while
        this.failCount = Math.min(4, this.failCount + 1);
        this.upBlockUntil = this.t + 14 + this.failCount * 14;
      }
      this.level = Math.min(QUALITY_LEVELS.length - 1, this.level + steps);
      this.lastChange = this.t;
      this.stable = 0;
      this.samples.length = 0;
      return this.level;
    }

    // ---- probe UP carefully ------------------------------------------------------
    if (avg < UP_MS) this.stable += dtSec;
    else this.stable = 0;
    if (this.level > 0 && this.stable > 6 && this.t > this.upBlockUntil && this.t - this.lastChange > 6) {
      this.level -= 1;
      this.lastChange = this.t;
      this.lastUpTime = this.t;
      this.stable = 0;
      this.samples.length = 0;
      return this.level;
    }
    return null;
  }
}
