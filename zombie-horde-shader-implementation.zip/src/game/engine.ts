import * as THREE from 'three';
import {
  BodycamFilterSettings,
  buildFilterFromBlend,
  CalloutPin,
  DEFAULT_FILTER_SETTINGS,
  GameMode,
  HitFeedback,
  HudSnapshot,
  WEAPON_SPECS,
  WeaponAnimState,
  WeaponId,
  ZONES,
  ZoneId,
} from './types';
import { buildAllWeaponRigs, WeaponRig } from './weaponModels';
import { buildStylizedWorld, TargetEntity, WorldContext } from './worldBuilder';
import { BreakableGlassPane } from './compoundBuilder';
import { createCrackedGlassTexture } from './graffitiTextures';
import { FootstepStance, FootstepSurface, soundEngine } from './audio';
import { BodycamPostPipeline } from './bodycamPost';
import { BotSquadManager } from './botAI';
import { ZombieHordeManager, HordeArena } from './zombieHorde';
import { IQ } from './iqLighting';
import { batchGroupsLocal, batchStaticMeshes, GlassBatch, optimizeTransparentMaterials } from './staticBatcher';
import { PerfGovernor, QUALITY_LEVELS } from './perfGovernor';

interface Pose {
  pos: THREE.Vector3;
  rot: THREE.Euler;
}

interface ShellCasing {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  age: number;
  maxAge: number;
  bounces: number;
  weapon: WeaponId;
}

interface TracerBullet {
  mesh: THREE.Mesh;
  start: THREE.Vector3;
  end: THREE.Vector3;
  dir: THREE.Vector3;
  distTotal: number;
  distTraveled: number;
  speed: number;
  alive: boolean;
}

interface ContrailLine {
  mesh: THREE.Mesh;
  age: number;
  maxAge: number;
}

interface ParticleFx {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  gravity: number;
  age: number;
  maxAge: number;
  startScale: number;
  endScale: number;
  fadeOpacity: boolean;
}

interface ImpactMark {
  mesh: THREE.Mesh;
  age: number;
  maxAge: number;
}

interface GlassShardPhysics {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  age: number;
  maxAge: number;
  bounces: number;
  baseScale: number;
  makeBounceSound: boolean;
}

const CHEST_CAMERA_HEIGHT = 1.34; // Standing chest-mounted sternum bodycam height
const CROUCH_CAMERA_HEIGHT = 0.80; // Crouched chest height (clears waist-high walls & parapets cleanly!)
const BODYCAM_BASE_FOV = 98; // Ultra-wide chest bodycam lens FOV
const BODYCAM_VM_FOV = 60; // Balanced viewmodel FOV showing sculpted polygon hands & weapons cleanly

const WEAPON_POSES: Record<WeaponId, { ready: Pose; ads: Pose; reload: Pose; bolt: Pose; sprint: Pose }> = {
  // GAMBAR 2 = ready / ads (straight aimline); GAMBAR 1 = reload / inspect (diagonal canted pose)
  pistol: {
    ready: { pos: new THREE.Vector3(0.015, -0.115, -0.45), rot: new THREE.Euler(0.025, 0.0, -0.025) },
    ads: { pos: new THREE.Vector3(0.0, -0.068, -0.36), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(-0.005, -0.105, -0.42), rot: new THREE.Euler(0.16, 0.27, -0.21) },
    bolt: { pos: new THREE.Vector3(0.015, -0.115, -0.45), rot: new THREE.Euler(0.025, 0.0, -0.025) },
    // LOW-READY: pistol dropped to belly height, muzzle angled down (arms rest while running)
    sprint: { pos: new THREE.Vector3(0.0, -0.17, -0.43), rot: new THREE.Euler(-0.34, 0.12, -0.1) },
  },
  rifle: {
    ready: { pos: new THREE.Vector3(0.02, -0.125, -0.37), rot: new THREE.Euler(0.02, 0.0, -0.03) },
    ads: { pos: new THREE.Vector3(0.0, -0.118, -0.25), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(0.06, -0.135, -0.46), rot: new THREE.Euler(0.23, 0.56, -0.48) },
    bolt: { pos: new THREE.Vector3(0.02, -0.125, -0.37), rot: new THREE.Euler(0.02, 0.0, -0.03) },
    // LOW-READY: rifle lowered from chest height, muzzle pointing at the ground ahead, canted a little to the left
    sprint: { pos: new THREE.Vector3(0.03, -0.175, -0.38), rot: new THREE.Euler(-0.3, 0.26, -0.18) },
  },
  sniper: {
    ready: { pos: new THREE.Vector3(0.095, -0.14, -0.42), rot: new THREE.Euler(0.025, 0.055, -0.045) },
    // Aligns camera eye directly behind the 3D Sniper's Live 4.7x Magnifying Glass Lens (y=0.124, z=+0.173)!
    ads: { pos: new THREE.Vector3(0.0, -0.124, -0.285), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(0.065, -0.13, -0.46), rot: new THREE.Euler(0.2, 0.46, -0.34) },
    bolt: { pos: new THREE.Vector3(0.075, -0.135, -0.44), rot: new THREE.Euler(0.14, 0.3, -0.24) },
    // LOW-READY: long rifle carried low, muzzle down
    sprint: { pos: new THREE.Vector3(0.05, -0.19, -0.44), rot: new THREE.Euler(-0.28, 0.3, -0.16) },
  },
};

export class PolyBallisticsEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private bodycamPost: BodycamPostPipeline;
  private envRT: THREE.WebGLRenderTarget | null = null;
  private scopeRenderTarget: THREE.WebGLRenderTarget;
  private scopeMagnifierCamera: THREE.PerspectiveCamera;
  private sunScreenPos = new THREE.Vector2(0.5, 0.5);
  private sunFlareStrength = 0;
  private sunCheckAcc = 0;
  private sunUnobstructed = 0;
  private worldScene: THREE.Scene;
  private worldCamera: THREE.PerspectiveCamera;
  private vmScene: THREE.Scene;
  private vmCamera: THREE.PerspectiveCamera;
  private vmHemiLight: THREE.HemisphereLight;
  private vmSunLight: THREE.DirectionalLight;
  private vmMuzzleLight: THREE.PointLight;
  private world: WorldContext;
  private botSquad: BotSquadManager;
  private horde: ZombieHordeManager;
  private glassBatch!: GlassBatch;
  // ---- adaptive performance (locked-60 FPS governor) ----
  private perf = new PerfGovernor();
  /** canvas pixel ratio = the real display resolution (never lowered by the governor → always crisp) */
  private displayPixelRatio = 1;
  /** user render scale: 0.75 … 2.0 (>1 = supersampling). Internal res = display × this × governor level */
  private renderScale = 1.25;
  private sharpen = 0.6;
  private shadowEvery = 1;
  private shadowSize = 4096;
  private frameCounter = 0;
  private showFps = false;
  private lastDraws = 0;
  private lastTris = 0;
  private botsBeforeHorde = true;
  private prevHordePhase = 'idle';
  private rigs: Record<WeaponId, WeaponRig>;

  private onHudUpdate: (hud: HudSnapshot) => void;
  private rafId = 0;
  private lastTime = 0;
  private hudEmitAcc = 0;
  private elapsedTime = 0;
  private rawTime = 0;
  private disposed = false;

  // Player state (Chest-mounted bodycam rig + Crouch + Smooth Gimbal Sprint!)
  private playerPos = new THREE.Vector3(0, CHEST_CAMERA_HEIGHT, 9);
  private playerVel = new THREE.Vector3();
  private playerYaw = 0;
  private playerPitch = 0;
  private isGrounded = true;
  private wasGrounded = true;
  private keys = new Set<string>();
  private isPointerLocked = false;
  private mouseDownLeft = false;
  private mouseDownRight = false;
  private adsToggle = false;
  private crouchToggle = false;
  private crouchBlend = 0;
  private smoothCamHeight = CHEST_CAMERA_HEIGHT;
  private moveBobTime = 0;
  private lastFootstepIdx = 0;
  private moveSpeedNorm = 0;
  private sprintBlend = 0;
  /** 0..1 — holding the trigger brings the lowered sprint weapon back up to the aim position */
  private sprintRaise = 0;

  // Silky-Smooth Exponentially Filtered Gimbal Running Camera State!
  private smoothCamBobX = 0;
  private smoothCamBobY = 0;
  private smoothCamPitch = 0;
  private smoothRollZ = 0;

  // Free-Aim & Camera Sway (Gun moves FIRST inside deadzone before chest bodycam smoothly follows!)
  private freeAimYaw = 0;
  private freeAimPitch = 0;
  private freeAimScreenX = 0;
  private freeAimScreenY = 0;
  private turnRoll = 0;
  private swayX = 0;
  private swayY = 0;

  // Procedural Breathing, Adrenaline & Trauma
  private adrenaline = 0;
  private camTrauma = 0;
  private landJolt = 0;
  private landJoltVel = 0;

  // Bodycam Optics: Adjustable Sebelumnya <-> Setelahnya Filter, Aggressive Auto-Exposure & Dynamic DoF
  private showUi = false; // ZERO UI by default! Toggle with `P`
  private bodycamEnabled = true;
  private filterSettings: BodycamFilterSettings = { ...DEFAULT_FILTER_SETTINGS };
  private adaptedLuminance = 0.96;
  private exposureGain = 1.06;
  private glareStrength = 0.2;
  private indoorDarkness = 0;
  private currentFocusDist = 14.0;
  private targetFocusDist = 14.0;
  private focusSampleAcc = 0;

  // Player Combat Survival & Bot Feedback
  private playerHp = 100;
  private damagePulse = 0;
  private timeSinceDamaged = 10;

  // Weapon state (Default M4A1 Rifle ready for breaching the Abandoned Graffiti Gang Compound!)
  private weaponId: WeaponId = 'rifle';
  private ammoMap: Record<WeaponId, number> = {
    pistol: WEAPON_SPECS.pistol.magSize,
    rifle: WEAPON_SPECS.rifle.magSize,
    sniper: WEAPON_SPECS.sniper.magSize,
  };
  private animState: WeaponAnimState = 'ready';
  private fireCooldown = 0;
  private equipTimer = 0;
  private reloadTimer = 0;
  private reloadDuration = 1.75;
  private reloadStageTriggered = new Set<string>();
  private boltTimer = 0;
  private boltDuration = 1.05;
  private boltStageTriggered = new Set<string>();
  private inspectTimer = 0;
  private adsBlend = 0;
  private muzzleFlashTimer = 0;
  private triggerPullTimer = 0;

  // Weapon mechanical spring offsets
  private slideKick = 0;
  private rifleBoltKick = 0;
  private rifleDustCoverOpen = false;
  private recoilPosZ = 0;
  private recoilRotX = 0;
  private recoilRotY = 0;
  private recoilRotZ = 0;
  private camRecoilPitch = 0;
  private camRecoilVel = 0;
  private spreadBloom = 0;

  // Smoothed viewmodel root transform
  private curVmPos = new THREE.Vector3();
  private curVmRot = new THREE.Euler();

  // Simulation toggles & Telemetry pulses
  private slowMo = false;
  private showMechanics = false;
  private zoneId: ZoneId = 'compound';
  private gameMode: GameMode = 'range';
  private drillActive = false;
  private drillTimeLeft = 60;
  private drillFinished = false;

  private score = 0;
  private streak = 0;
  private shotsFired = 0;
  private shotsHit = 0;
  private headshots = 0;
  private lastEventText = 'Mode Siap Nembak — Klik untuk menembak, tekan R untuk Reload (Pose Gambar 1)';
  private hitFeedback: HitFeedback | null = null;
  private hitFeedbackCounter = 0;
  private hitFeedbackTimer = 0;

  // Callout live glow pulse timers
  private pulseMuzzle = 0;
  private pulseEjection = 0;
  private pulseAction = 0;
  private pulseMag = 0;
  private scopeRangeMeters: number | null = null;

  // Active physical FX pools
  private shells: ShellCasing[] = [];
  private tracers: TracerBullet[] = [];
  private contrails: ContrailLine[] = [];
  private particles: ParticleFx[] = [];
  private glassShards: GlassShardPhysics[] = [];
  private impactMarks: ImpactMark[] = [];

  // Shared FX geometries & materials
  private raycaster = new THREE.Raycaster();
  private brassMat = new THREE.MeshStandardMaterial({
    color: 0xe8b954,
    roughness: 0.25,
    metalness: 0.88,
    flatShading: true,
  });
  private shellGeos: Record<WeaponId, THREE.BufferGeometry>;
  private sparkMatCache = new Map<number, THREE.MeshBasicMaterial>();
  private matPools = new Map<THREE.Material, { items: THREE.Material[]; i: number }>();
  // shared tracer resources (no per-shot geometry / material allocation → no GC or GPU-upload hitches)
  private enemyTracerGeo = (() => {
    const g = new THREE.CylinderGeometry(0.012, 0.02, 2.2, 5);
    g.rotateX(Math.PI / 2);
    return g;
  })();
  private enemyTracerMat = new THREE.MeshBasicMaterial({ color: 0xff4e2a, transparent: true, opacity: 0.92 });
  private tracerGeoByWeapon: Record<WeaponId, THREE.BufferGeometry> = (() => {
    const mk = (len: number, rad: number) => {
      const g = new THREE.CylinderGeometry(rad * 0.5, rad, len, 5);
      g.rotateX(Math.PI / 2);
      return g;
    };
    return { pistol: mk(1.35, 0.015), rifle: mk(2.1, 0.015), sniper: mk(3.2, 0.024) };
  })();
  private tracerMatByWeapon: Record<WeaponId, THREE.MeshBasicMaterial> = {
    pistol: new THREE.MeshBasicMaterial({ color: 0xffd066, transparent: true, opacity: 0.95 }),
    rifle: new THREE.MeshBasicMaterial({ color: 0xffd066, transparent: true, opacity: 0.95 }),
    sniper: new THREE.MeshBasicMaterial({ color: 0xfff5ba, transparent: true, opacity: 0.95 }),
  };

  /** round-robin pool of cloned materials for fading particles (replaces a clone() per puff) */
  private acquireMat(base: THREE.Material): THREE.Material {
    let pool = this.matPools.get(base);
    if (!pool) {
      pool = { items: [], i: 0 };
      this.matPools.set(base, pool);
    }
    let m: THREE.Material;
    if (pool.items.length < 56) {
      m = base.clone();
      pool.items.push(m);
    } else {
      m = pool.items[pool.i++ % pool.items.length];
      m.opacity = base.opacity;
    }
    return m;
  }
  private smokeGeo = new THREE.IcosahedronGeometry(0.11, 0).toNonIndexed();
  private sparkGeo = new THREE.BoxGeometry(0.035, 0.035, 0.14).toNonIndexed();
  private woodPlankGeo = new THREE.BoxGeometry(0.45, 0.12, 0.08).toNonIndexed();
  private impactGeo = new THREE.CircleGeometry(0.065, 7);
  private impactMat = new THREE.MeshBasicMaterial({
    color: 0x16191e,
    polygonOffset: true,
    polygonOffsetFactor: -2,
  });
  private smokeMat = new THREE.MeshStandardMaterial({
    color: 0xeaeff2,
    roughness: 0.95,
    transparent: true,
    opacity: 0.58,
    flatShading: true,
    depthWrite: false,
  });
  private fireMat = new THREE.MeshBasicMaterial({
    color: 0xff7b1f,
    transparent: true,
    opacity: 0.92,
  });
  private fireCoreMat = new THREE.MeshBasicMaterial({
    color: 0xffe478,
    transparent: true,
    opacity: 0.95,
  });
  private woodMat = new THREE.MeshStandardMaterial({
    color: 0xb68652,
    roughness: 0.88,
    flatShading: true,
  });
  private glassShardGeos: THREE.BufferGeometry[] = [];
  private glassShardMat = new THREE.MeshStandardMaterial({
    color: 0xe6f8ff,
    emissive: 0x4b7f94,
    emissiveIntensity: 0.32,
    roughness: 0.08,
    metalness: 0.62,
    transparent: true,
    opacity: 0.76,
    side: THREE.DoubleSide,
    flatShading: true,
  });
  private glassDustMat = new THREE.MeshBasicMaterial({
    color: 0xeaf7ff,
    transparent: true,
    opacity: 0.55,
    depthWrite: false,
  });

  // Reusable scratch vectors to avoid GC churn
  private tmpV1 = new THREE.Vector3();
  private tmpV2 = new THREE.Vector3();
  private tmpV3 = new THREE.Vector3();
  private tmpEuler = new THREE.Euler();

  constructor(container: HTMLElement, onHudUpdate: (hud: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;

    // IQ "Elephant" (Shadertoy 4dKGWm) lighting — patched into every lit material BEFORE first compile.
    // Default = 100% shader lighting, adjustable 0–100% via slider / hotkeys.
    IQ.install();
    IQ.setMix(1.0);

    // Initialize shell geometries per caliber
    this.shellGeos = {
      pistol: new THREE.CylinderGeometry(0.0065, 0.0065, 0.024, 6).toNonIndexed(),
      rifle: new THREE.CylinderGeometry(0.0052, 0.0072, 0.044, 6).toNonIndexed(),
      sniper: new THREE.CylinderGeometry(0.0068, 0.0095, 0.068, 7).toNonIndexed(),
    };
    this.smokeGeo.computeVertexNormals();
    this.woodPlankGeo.computeVertexNormals();

    // Build 3 realistic thin flat jagged triangular glass shard geometries (authentic broken window splinters!)
    const makeFlatGlassTri = (pts: [number, number][]) => {
      const g = new THREE.BufferGeometry();
      const verts: number[] = [];
      for (let i = 1; i < pts.length - 1; i++) {
        verts.push(
          pts[0][0], pts[0][1], 0,
          pts[i][0], pts[i][1], 0,
          pts[i + 1][0], pts[i + 1][1], 0
        );
      }
      g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
      g.computeVertexNormals();
      return g;
    };
    this.glassShardGeos = [
      makeFlatGlassTri([[-0.08, -0.05], [0.11, -0.02], [-0.01, 0.12]]),
      makeFlatGlassTri([[-0.12, -0.04], [0.06, -0.06], [0.1, 0.05], [-0.04, 0.08]]),
      makeFlatGlassTri([[-0.05, -0.11], [0.07, -0.03], [0.02, 0.12], [-0.06, 0.04]]),
    ];

    // Renderer (linear pass into crisp MSAA/FXAA BodycamPostPipeline!)
    // Everything is rendered into offscreen targets and composited by ONE fullscreen post pass, so the
    // canvas itself needs no MSAA / depth / stencil / alpha (saves a lot of fill-rate & memory bandwidth).
    this.renderer = new THREE.WebGLRenderer({
      antialias: false,
      depth: false,
      stencil: false,
      alpha: false,
      powerPreference: 'high-performance',
    });
    {
      const cw0 = Math.max(1, container.clientWidth);
      const ch0 = Math.max(1, container.clientHeight);
      // NATIVE display resolution: full device DPR up to 2×, capped at ~8.5 megapixels (4K).
      this.displayPixelRatio = Math.max(0.75, Math.min(window.devicePixelRatio || 1, 2.0, Math.sqrt(8.5e6 / (cw0 * ch0))));
    }
    this.renderer.setPixelRatio(this.displayPixelRatio);
    this.renderer.info.autoReset = false;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    // shadow map is refreshed on demand (every frame at ULTRA, every 2–3 frames when the governor needs headroom)
    this.renderer.shadowMap.autoUpdate = false;
    this.renderer.shadowMap.needsUpdate = true;
    this.renderer.autoClear = false;
    this.renderer.toneMapping = THREE.NoToneMapping;
    container.appendChild(this.renderer.domElement);

    // Bodycam GPU Post-Processing Pipeline (Fisheye + Dynamic DoF + Chromatic Aberration + Aggressive Auto-Exposure + Grain + Vignette)
    this.bodycamPost = new BodycamPostPipeline(
      this.renderer,
      container.clientWidth,
      container.clientHeight,
      this.computeInternalPixelRatio(),
      this.displayPixelRatio
    );
    this.bodycamPost.sharpen = this.sharpen;

    const aspect = container.clientWidth / Math.max(1, container.clientHeight);

    // 1. World Scene & Wide-Angle Chest-Mounted Camera
    this.worldScene = new THREE.Scene();
    this.worldCamera = new THREE.PerspectiveCamera(BODYCAM_BASE_FOV, aspect, 0.1, 700);
    this.world = buildStylizedWorld(this.worldScene);
    this.world.sunLight.shadow.mapSize.set(this.shadowSize, this.shadowSize);

    // FPS FIX #1 — bake ~2 700 static meshes into a few hundred merged, culled chunks (hidden originals keep raycasts exact)
    // (doors / glass / targets are animated, so they get local-space batching below instead)
    batchStaticMeshes(this.worldScene, [
      this.world.compound.doors,
      this.world.compound.glassPanes,
      this.world.compound.targets,
      this.world.targets,
      this.world.compound.dustMotes,
      this.world.compound.doorHitMeshes,
      this.world.compound.glassHitMeshes,
      this.world.compound.hitMeshes,
      this.world.hitMeshes,
    ]);
    // FPS FIX #2 — animated rigid assemblies: merge inside their own pivot (door leaves, target dummies, crates…)
    for (const d of this.world.compound.doors) batchGroupsLocal(d.pivot);
    for (const t of this.world.targets) batchGroupsLocal(t.pivot);
    // FPS FIX #3 — flat double-sided glass was being drawn in 2 passes
    optimizeTransparentMaterials(this.worldScene);
    // FPS FIX #4 — ~220 intact window panes → a handful of merged chunks (cracked/shattered panes are released individually)
    this.glassBatch = new GlassBatch(this.worldScene, this.world.compound.glassPanes);
    this.botSquad = new BotSquadManager(this.worldScene, this.world.compound);
    this.horde = new ZombieHordeManager(this.worldScene, this.world.colliders3D, this.world.getGroundHeight);
    IQ.sunDirWorld.copy(this.world.sunDirection).normalize();

    // 1.25 AAA Procedural HDR Sky/Sun/Ground IBL Environment Map (PMREMGenerator)
    // Gives realistic sky reflections & warm bounce light to gunmetal, wood doors, window glass, concrete & smooth enemy jackets!
    this.buildProceduralHdrEnvironment();

    // 1.5 High-Definition 1024x1024 4x-MSAA Picture-in-Picture Magnifying Sniper Scope Target & 4.7x Camera (Exact PIGEON Technique!)
    const isWebGL2 = this.renderer.capabilities.isWebGL2;
    this.scopeRenderTarget = new THREE.WebGLRenderTarget(1024, 1024, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: isWebGL2 ? THREE.HalfFloatType : THREE.UnsignedByteType,
      depthBuffer: true,
      samples: isWebGL2 ? 4 : 0,
    });
    this.scopeMagnifierCamera = new THREE.PerspectiveCamera(14.5, 1.0, 0.2, 380);

    // 2. Dedicated Viewmodel Scene & Wider Chest-Perspective Camera (near=0.01 prevents scope bezel clipping!)
    this.vmScene = new THREE.Scene();
    this.vmCamera = new THREE.PerspectiveCamera(BODYCAM_VM_FOV, aspect, 0.01, 10);

    // Sculptural daylight lighting tuned specifically so every low-poly white hand facet shows crisp sunlit vs cool blue-grey planes!
    this.vmHemiLight = new THREE.HemisphereLight(0xd2e6fb, 0x677b93, 0.56);
    this.vmScene.add(this.vmHemiLight);

    this.vmSunLight = new THREE.DirectionalLight(0xfff9ee, 1.02);
    this.vmSunLight.position.set(2.8, 3.5, 1.2);
    this.vmScene.add(this.vmSunLight);
    IQ.sunDirVm.copy(this.vmSunLight.position).normalize();

    const vmRim = new THREE.DirectionalLight(0xa4c9ea, 0.24);
    vmRim.position.set(-2.8, 1.0, -1.8);
    this.vmScene.add(vmRim);

    this.vmMuzzleLight = new THREE.PointLight(0xffa73b, 0, 2.5);
    this.vmScene.add(this.vmMuzzleLight);

    // Apply crisp HDR sky IBL onto Viewmodel Scene too so metallic slides, holo optics & sniper scopes catch real daylight highlights!
    if (this.envRT) {
      this.vmScene.environment = this.envRT.texture;
      this.vmScene.environmentIntensity = 0.42;
    }

    // Build all 3 polygon weapon rigs with matte-white faceted hands + Live PiP Sniper Glass Scope!
    this.rigs = buildAllWeaponRigs(this.scopeRenderTarget.texture);
    // FPS FIX #5 — hands & guns are ~100+ tiny meshes: merge rigid parts inside each animated group
    // (animated parts are Groups → they keep moving; the reticle mesh & muzzle flash stay untouched)
    (Object.keys(this.rigs) as WeaponId[]).forEach((id) => {
      const r = this.rigs[id];
      const keep: THREE.Object3D[] = [r.muzzleFlash];
      if (r.holoReticle) keep.push(r.holoReticle);
      batchGroupsLocal(r.root, keep);
    });
    (Object.keys(this.rigs) as WeaponId[]).forEach((id) => {
      this.rigs[id].root.visible = id === this.weaponId;
      this.vmScene.add(this.rigs[id].root);
    });

    // Initialize default weapon pose cleanly
    const startPose = WEAPON_POSES[this.weaponId].ready;
    this.curVmPos.copy(startPose.pos);
    this.curVmRot.copy(startPose.rot);

    // SHADER PRE-WARM — compile every program (world, effects, zombies, viewmodel) now instead of mid-fight
    this.applyAnisotropy();
    this.prewarmShaders();

    this.teleportToZone('compound', false);
    this.bindEvents();
    this.lastTime = performance.now();
    this.emitHud();
    this.loop(this.lastTime);
  }

  private bindEvents() {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('mousemove', this.handleMouseMove);
    window.addEventListener('mousedown', this.handleMouseDown);
    window.addEventListener('mouseup', this.handleMouseUp);
    window.addEventListener('wheel', this.handleWheel, { passive: true });
    window.addEventListener('contextmenu', this.handleContextMenu);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('mousemove', this.handleMouseMove);
    window.removeEventListener('mousedown', this.handleMouseDown);
    window.removeEventListener('mouseup', this.handleMouseUp);
    window.removeEventListener('wheel', this.handleWheel);
    window.removeEventListener('contextmenu', this.handleContextMenu);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.horde.dispose();
    this.envRT?.dispose();
    this.scopeRenderTarget.dispose();
    this.bodycamPost.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }

  public toggleUi() {
    this.showUi = !this.showUi;
    this.emitHud();
  }

  public toggleBodycam() {
    this.bodycamEnabled = !this.bodycamEnabled;
    if (!this.bodycamEnabled) {
      this.freeAimYaw = 0;
      this.freeAimPitch = 0;
    }
    this.lastEventText = this.bodycamEnabled
      ? 'Kamera Bodycam (Fisheye + DoF + Auto-Exposure + Free-Aim) AKTIF'
      : 'Kamera Bodycam Dinonaktifkan (Mode FPS Standar)';
    this.emitHud();
  }

  public toggleCrouch() {
    this.crouchToggle = !this.crouchToggle;
    this.lastEventText = this.crouchToggle
      ? 'Posisi CROUCH (Jongkok) — Recoil lebih stabil & bisa berlindung di balik tembok rendah!'
      : 'Posisi Berdiri';
    this.emitHud();
  }

  // ===========================================================================
  //  PERFORMANCE / QUALITY GOVERNOR
  // ===========================================================================
  /** internal (render) pixel ratio = display DPR × user render-scale × governor level, clamped to ~16 MP */
  private computeInternalPixelRatio(): number {
    const q = QUALITY_LEVELS[this.perf.level];
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    const wanted = this.displayPixelRatio * this.renderScale * q.scale;
    const cap = Math.sqrt(16e6 / (w * h));
    return Math.max(0.5, Math.min(wanted, cap));
  }

  /** canvas stays at native display resolution; only the internal render targets change size */
  private applyResolution() {
    const w = this.container.clientWidth;
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setPixelRatio(this.displayPixelRatio);
    this.renderer.setSize(w, h);
    this.bodycamPost.setSize(w, h, this.computeInternalPixelRatio(), this.displayPixelRatio);
  }

  /** 0.75 … 2.0 — values above 1.0 supersample (sharper, smoother edges) */
  public setRenderScale(v: number) {
    this.renderScale = THREE.MathUtils.clamp(v, 0.5, 2.0);
    this.applyResolution();
    const r = this.bodycamPost.getResolutionInfo();
    this.lastEventText = `Resolusi render ${Math.round(this.renderScale * 100)}% — internal ${r.internalW}×${r.internalH} → layar ${r.outW}×${r.outH}`;
    this.emitHud();
  }

  /** 0..1 final-pass sharpening */
  public setSharpen(v: number) {
    this.sharpen = THREE.MathUtils.clamp(v, 0, 1);
    this.bodycamPost.sharpen = this.sharpen;
    this.lastEventText = `Ketajaman gambar ${Math.round(this.sharpen * 100)}%`;
    this.emitHud();
  }

  /** max anisotropic filtering on every texture → crisp ground / murals at grazing angles */
  private applyAnisotropy() {
    const maxA = Math.min(16, this.renderer.capabilities.getMaxAnisotropy());
    const seen = new Set<THREE.Texture>();
    const props = ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap', 'bumpMap', 'alphaMap'] as const;
    const visit = (obj: THREE.Object3D) => {
      obj.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (!mesh.isMesh) return;
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        for (const m of mats) {
          for (const p of props) {
            const t = (m as unknown as Record<string, THREE.Texture | null | undefined>)[p];
            if (t && !seen.has(t)) {
              seen.add(t);
              if (t.anisotropy < maxA) t.anisotropy = maxA;
            }
          }
        }
      });
    };
    visit(this.worldScene);
    visit(this.vmScene);
  }

  private applyQuality(idx: number) {
    const q = QUALITY_LEVELS[idx];
    this.applyResolution();
    this.bodycamPost.quality = q.post;
    this.shadowEvery = q.shadowEvery;
    if (q.shadowSize !== this.shadowSize) {
      this.shadowSize = q.shadowSize;
      const sh = this.world.sunLight.shadow;
      sh.mapSize.set(q.shadowSize, q.shadowSize);
      sh.map?.dispose();
      sh.map = null;
    }
    this.renderer.shadowMap.needsUpdate = true;
  }

  private prewarmShaders() {
    const warm = new THREE.Group();
    const fxMats: THREE.Material[] = [
      this.brassMat,
      this.impactMat,
      this.smokeMat,
      this.fireMat,
      this.fireCoreMat,
      this.woodMat,
      this.glassShardMat,
      this.glassDustMat,
      this.enemyTracerMat,
      ...Object.values(this.tracerMatByWeapon),
    ];
    for (const mat of fxMats) {
      const m = new THREE.Mesh(this.smokeGeo, mat);
      m.position.set(0, -500, 0);
      warm.add(m);
    }
    this.worldScene.add(warm);
    try {
      this.renderer.compile(this.worldScene, this.worldCamera);
      this.horde.prewarm(this.renderer, this.worldCamera);
      this.renderer.compile(this.vmScene, this.vmCamera);
    } catch (err) {
      console.warn('[perf] shader pre-warm skipped', err);
    }
    this.worldScene.remove(warm);
  }

  /** 'auto' = locked-60 governor; 0..4 = fixed ULTRA…HEMAT */
  public setQualityMode(mode: 'auto' | number) {
    const lvl = this.perf.setManual(mode);
    this.applyQuality(lvl);
    this.lastEventText =
      mode === 'auto'
        ? 'Kualitas OTOMATIS — menjaga 60 FPS stabil dengan resolusi setajam mungkin'
        : `Kualitas manual: ${QUALITY_LEVELS[lvl].name}`;
    this.emitHud();
  }

  // ===========================================================================
  //  IQ ELEPHANT LIGHTING (Shadertoy 4dKGWm) — 0..100% blend
  // ===========================================================================
  public setIqLighting(value: number) {
    const v = THREE.MathUtils.clamp(Math.round(value * 100) / 100, 0, 1);
    IQ.setMix(v);
    this.lastEventText = `Pencahayaan Shader iq (Elephant): ${Math.round(v * 100)}%  (0% = bawaan three.js • 100% = shader penuh)`;
    this.emitHud();
  }

  // ===========================================================================
  //  ZOMBIE HORDE MODE (World War Z style)
  // ===========================================================================
  private getHordeArena(): HordeArena {
    if (this.playerPos.x < 90) {
      return { minX: -62, maxX: 62, minZ: -62, maxZ: 62 };
    }
    return { minX: 180 - 82, maxX: 180 + 82, minZ: -232, maxZ: 28 };
  }

  public startHorde(zone: ZoneId = 'compound') {
    soundEngine.unlock();
    if (this.gameMode !== 'horde') this.botsBeforeHorde = this.botSquad.enabled;
    this.gameMode = 'horde';
    this.drillActive = false;
    this.drillFinished = false;
    this.botSquad.setEnabled(false);
    this.world.resetAllTargets();
    this.teleportToZone(zone, false, true);
    this.score = 0;
    this.streak = 0;
    this.shotsFired = 0;
    this.shotsHit = 0;
    this.headshots = 0;
    this.playerHp = 100;
    this.damagePulse = 0;
    this.refillAllAmmo();
    this.horde.start(this.getHordeArena());
    this.prevHordePhase = 'intermission';
    this.lastEventText = 'ZOMBIE HORDE MODE — Bertahanlah! Zombie memanjat tembok & saling menumpuk membentuk piramida!';
    this.emitHud();
  }

  public stopHorde() {
    if (this.gameMode !== 'horde') return;
    this.horde.stop();
    this.gameMode = 'range';
    this.botSquad.setEnabled(this.botsBeforeHorde);
    this.playerHp = 100;
    this.lastEventText = 'Mode Horde dihentikan — kembali ke Latihan Bebas';
    this.emitHud();
  }

  public toggleHorde() {
    if (this.gameMode === 'horde') this.stopHorde();
    else this.startHorde('compound');
  }

  private refillAllAmmo() {
    this.ammoMap = {
      pistol: WEAPON_SPECS.pistol.magSize,
      rifle: WEAPON_SPECS.rifle.magSize,
      sniper: WEAPON_SPECS.sniper.magSize,
    };
  }

  public setFilterPresetBlend(styleBlend: number) {
    const clamped = THREE.MathUtils.clamp(styleBlend, 0, 1);
    this.filterSettings = buildFilterFromBlend(
      clamped,
      this.filterSettings.brightness,
      this.filterSettings.cameraShake
    );
    this.lastEventText = `Filter Bodycam: ${Math.round(clamped * 100)}% (0% Versi 1 ↔ 100% Versi 2)`;
    this.emitHud();
  }

  public updateFilterSettings(patch: Partial<BodycamFilterSettings>) {
    this.filterSettings = { ...this.filterSettings, ...patch };
    this.emitHud();
  }

  public requestPointerLock() {
    soundEngine.unlock();
    if (document.pointerLockElement !== this.renderer.domElement) {
      this.renderer.domElement.requestPointerLock?.();
    }
  }

  public switchWeapon(id: WeaponId) {
    if (id === this.weaponId) return;
    soundEngine.unlock();
    this.rigs[this.weaponId].root.visible = false;
    this.resetRigAnimatedParts(this.rigs[this.weaponId]);

    this.weaponId = id;
    this.rigs[id].root.visible = true;
    this.animState = 'equipping';
    this.equipTimer = 0.28;
    this.reloadTimer = 0;
    this.boltTimer = 0;
    this.inspectTimer = 0;
    this.adsToggle = false;
    this.adsBlend = 0;
    this.muzzleFlashTimer = 0;
    this.rigs[id].muzzleFlash.visible = false;
    this.recoilPosZ = 0;
    this.recoilRotX = 0;
    this.recoilRotY = 0;
    this.recoilRotZ = 0;
    this.slideKick = 0;
    this.rifleBoltKick = 0;

    // Drop weapon slightly below frame so it snaps smoothly up on equip
    const ready = WEAPON_POSES[id].ready;
    this.curVmPos.set(ready.pos.x, ready.pos.y - 0.16, ready.pos.z + 0.08);
    this.curVmRot.set(-0.28, 0.15, -0.1);

    soundEngine.playReloadStep('bolt_down');
    this.lastEventText = `Senjata diganti ke ${WEAPON_SPECS[id].label} (${WEAPON_SPECS[id].caliber})`;
    this.emitHud();
  }

  public triggerReload() {
    if (this.animState === 'reloading' || this.animState === 'equipping') return;
    const spec = WEAPON_SPECS[this.weaponId];
    if (this.ammoMap[this.weaponId] >= spec.magSize) {
      // Even when full, let the player preview the iconic Gambar 1 Reload animation cleanly!
      this.lastEventText = `Reload Taktis ${spec.label} — Pose Pengisian Ammo (Gambar 1)`;
    } else {
      this.lastEventText = `Mengisi Ammo ${spec.label} (${spec.magSize} peluru) — Pose Gambar 1`;
    }
    this.animState = 'reloading';
    this.reloadDuration = spec.reloadDuration;
    this.reloadTimer = 0;
    this.reloadStageTriggered.clear();
    this.boltTimer = 0;
    this.inspectTimer = 0;
    this.adsToggle = false;
    this.pulseMag = 1.0;
    this.emitHud();
  }

  public triggerInspect() {
    if (this.animState === 'reloading' || this.animState === 'bolt_cycle' || this.animState === 'equipping') return;
    if (this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
      this.lastEventText = `Kembali ke Mode Siap Nembak (Gambar 2)`;
    } else {
      this.animState = 'inspecting';
      this.inspectTimer = 3.2;
      this.adsToggle = false;
      this.lastEventText = `Inspeksi Bentuk Polygon ${WEAPON_SPECS[this.weaponId].label} (Pose Gambar 1)`;
    }
    this.emitHud();
  }

  public toggleSlowMo() {
    this.slowMo = !this.slowMo;
    this.lastEventText = this.slowMo
      ? 'Slow-Motion 0.25x AKTIF — Amati slide, bolt, api muzzle, peluru & selongsong!'
      : 'Kecepatan Waktu Normal (1.0x)';
    this.emitHud();
  }

  public toggleMechanics() {
    this.showMechanics = !this.showMechanics;
    this.lastEventText = this.showMechanics
      ? 'Overlay Titik Peluru, Selongsong & Animasi Mekanik AKTIF'
      : 'Overlay Mekanik Disembunyikan';
    this.emitHud();
  }

  public toggleBots() {
    this.botSquad.setEnabled(!this.botSquad.enabled);
    this.lastEventText = this.botSquad.enabled
      ? 'Bot Cerdas AKTIF — Mereka berpatroli, berlindung & mengepung di Gedung Geng!'
      : 'Bot Cerdas Dinonaktifkan (Mode Eksplorasi Bebas)';
    this.emitHud();
  }

  public resetBotWave() {
    this.playerHp = 100;
    this.damagePulse = 0;
    this.world.compound.glassPanes.forEach((p) => {
      p.broken = false;
      p.stage = 0;
      p.mesh.visible = true;
      p.mesh.material = p.intactMat;
      p.edgeShardsGroup.visible = false;
    });
    this.glassBatch.resetAll();
    this.botSquad.setEnabled(true);
    this.botSquad.resetSquad();
    this.lastEventText = 'Gelombang Bot Cerdas & Kaca Gedung Di-reset (Wave 1)!';
    this.emitHud();
  }

  public teleportToZone(zone: ZoneId, autoEquipRecommended = false, fromHordeStart = false) {
    const info = ZONES[zone];
    this.zoneId = zone;
    this.playerPos.set(info.spawnPos[0], info.spawnPos[1], info.spawnPos[2]);
    this.playerVel.set(0, 0, 0);
    this.playerYaw = info.spawnYaw;
    this.playerPitch = zone === 'ridge' ? -0.05 : 0.0;
    this.playerHp = 100;
    this.damagePulse = 0;
    // Focus directional sun shadow map crisply on the active map!
    this.renderer.shadowMap.needsUpdate = true;
    if (zone === 'compound') {
      this.world.focusSunOnMap(0, 0);
    } else {
      this.world.focusSunOnMap(180, zone === 'ridge' ? -96 : zone === 'alpine' ? -45 : -6);
    }
    if (autoEquipRecommended && info.recommendedWeapon !== this.weaponId) {
      this.switchWeapon(info.recommendedWeapon);
    }
    this.lastEventText = `Zona: ${info.name} — ${info.subtitle}`;
    if (this.gameMode === 'horde' && !fromHordeStart) {
      // moving to another arena restarts the horde there
      this.horde.start(this.getHordeArena());
      this.prevHordePhase = 'intermission';
      this.playerHp = 100;
    }
    this.emitHud();
  }

  public setGameMode(mode: GameMode) {
    if (mode === 'horde') {
      this.startHorde('compound');
      return;
    }
    if (this.gameMode === 'horde') this.stopHorde();
    this.gameMode = mode;
    if (mode === 'drill') {
      this.startDrill();
    } else {
      this.drillActive = false;
      this.drillFinished = false;
      this.drillTimeLeft = 60;
      this.world.resetAllTargets();
      this.lastEventText = 'Mode Latihan Bebas — Eksplorasi 3 zona & uji animasi senjata!';
      this.emitHud();
    }
  }

  public startDrill() {
    this.gameMode = 'drill';
    this.drillActive = true;
    this.drillFinished = false;
    this.drillTimeLeft = 60;
    this.score = 0;
    this.streak = 0;
    this.shotsFired = 0;
    this.shotsHit = 0;
    this.headshots = 0;
    this.ammoMap = {
      pistol: WEAPON_SPECS.pistol.magSize,
      rifle: WEAPON_SPECS.rifle.magSize,
      sniper: WEAPON_SPECS.sniper.magSize,
    };
    this.world.resetAllTargets();
    this.lastEventText = 'TANTANGAN 60 DETIK DIMULAI! Hancurkan target sebanyak mungkin!';
    this.emitHud();
  }

  public fireDemoShot() {
    soundEngine.unlock();
    this.tryFire();
  }

  public toggleAds() {
    this.adsToggle = !this.adsToggle;
    if (this.adsToggle && this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
    }
    this.lastEventText = this.adsToggle
      ? `Mode Bidik Presisi (ADS) ${WEAPON_SPECS[this.weaponId].label} AKTIF`
      : `Mode Siap Nembak (Gambar 2) ${WEAPON_SPECS[this.weaponId].label}`;
    this.emitHud();
  }

  private resetRigAnimatedParts(rig: WeaponRig) {
    rig.leftArm.position.copy(rig.leftArmRestPos);
    rig.leftArm.rotation.copy(rig.leftArmRestRot);
    rig.rightArm.position.copy(rig.rightArmRestPos);
    rig.rightArm.rotation.copy(rig.rightArmRestRot);
    rig.mag.position.copy(rig.magRestPos);
    rig.mag.rotation.copy(rig.magRestRot);
    rig.mag.visible = true;
    if (rig.slide) rig.slide.position.set(0, 0, 0);
    if (rig.hammer) rig.hammer.rotation.set(0, 0, 0);
    if (rig.bolt) rig.bolt.position.set(0, rig.id === 'sniper' ? 0.036 : 0, rig.id === 'sniper' ? -0.02 : 0);
    if (rig.boltHandle) rig.boltHandle.rotation.set(0, 0, 0);
    if (rig.chargingHandle) rig.chargingHandle.position.set(0, 0.055, 0.095);
    if (rig.trigger) rig.trigger.rotation.set(0, 0, 0);
  }

  private handleResize = () => {
    const w = this.container.clientWidth;
    const h = Math.max(1, this.container.clientHeight);
    this.applyResolution();
    this.worldCamera.aspect = w / h;
    this.worldCamera.updateProjectionMatrix();
    this.vmCamera.aspect = w / h;
    this.vmCamera.updateProjectionMatrix();
  };

  private handleContextMenu = (e: MouseEvent) => {
    e.preventDefault();
  };

  private handlePointerLockChange = () => {
    this.isPointerLocked = document.pointerLockElement === this.renderer.domElement;
    if (!this.isPointerLocked) {
      this.mouseDownLeft = false;
      this.mouseDownRight = false;
      this.keys.clear();
    }
    this.emitHud();
  };

  private getCurrentFootSurface(): FootstepSurface {
    if (this.playerPos.x < 90) {
      // Abandoned Graffiti Building interior & balconies = gritty concrete; outdoor lot = asphalt
      return this.playerPos.z <= 10.6 && Math.abs(this.playerPos.x) <= 20.6 ? 'concrete' : 'asphalt';
    }
    if (this.playerPos.z > -27) return 'asphalt';
    return 'grass';
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    const code = e.code;
    this.keys.add(code);
    soundEngine.unlock();

    if (code === 'F3') {
      e.preventDefault();
      this.showFps = !this.showFps;
      this.emitHud();
      return;
    }
    if (code === 'KeyP') {
      this.toggleUi();
      return;
    }
    if (code === 'KeyO') {
      this.toggleBodycam();
      return;
    }
    if (code === 'BracketLeft') {
      this.setFilterPresetBlend(this.filterSettings.styleBlend - 0.15);
      return;
    }
    if (code === 'BracketRight') {
      this.setFilterPresetBlend(this.filterSettings.styleBlend + 0.15);
      return;
    }
    if (code === 'KeyC') {
      this.toggleCrouch();
      return;
    }
    if (code === 'KeyE') {
      this.tryToggleNearbyDoor();
      return;
    }
    if (code === 'Digit1') this.switchWeapon('pistol');
    else if (code === 'Digit2') this.switchWeapon('rifle');
    else if (code === 'Digit3') this.switchWeapon('sniper');
    else if (code === 'KeyR') this.triggerReload();
    else if (code === 'KeyF') this.triggerInspect();
    else if (code === 'KeyT') this.toggleSlowMo();
    else if (code === 'KeyB') {
      this.toggleMechanics();
      if (this.showMechanics && !this.showUi) this.showUi = true;
      this.emitHud();
    } else if (code === 'KeyQ') {
      this.adsToggle = !this.adsToggle;
      this.emitHud();
    } else if (code === 'KeyG') {
      this.toggleBots();
    } else if (code === 'KeyH') {
      this.toggleHorde();
    } else if (code === 'KeyL') {
      this.setIqLighting(IQ.mix > 0.01 ? 0 : 1);
    } else if (code === 'Comma') {
      this.setIqLighting(IQ.mix - 0.1);
    } else if (code === 'Period') {
      this.setIqLighting(IQ.mix + 0.1);
    } else if (code === 'KeyV') {
      const order: ZoneId[] = ['compound', 'courtyard', 'alpine', 'ridge'];
      const next = order[(order.indexOf(this.zoneId) + 1) % order.length];
      this.teleportToZone(next, false);
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private handleMouseMove = (e: MouseEvent) => {
    if (!this.isPointerLocked) return;
    const isScoped = this.weaponId === 'sniper' && this.adsBlend > 0.45;
    const sens = isScoped ? 0.00048 : this.adsBlend > 0.5 ? 0.00125 : 0.00215;
    const dYaw = -e.movementX * sens;
    const dPitch = -e.movementY * sens;

    if (this.bodycamEnabled && !isScoped) {
      // FREE-AIM DEADZONE: Weapon & white hands move FIRST inside a wide free-aim window;
      // overflow spins the chest camera immediately while the body smoothly follows behind!
      const maxYaw = THREE.MathUtils.lerp(0.22, 0.042, this.adsBlend);
      const maxPitch = THREE.MathUtils.lerp(0.16, 0.032, this.adsBlend);

      this.freeAimYaw += dYaw;
      if (this.freeAimYaw > maxYaw) {
        this.playerYaw += this.freeAimYaw - maxYaw;
        this.freeAimYaw = maxYaw;
      } else if (this.freeAimYaw < -maxYaw) {
        this.playerYaw += this.freeAimYaw + maxYaw;
        this.freeAimYaw = -maxYaw;
      }

      this.freeAimPitch += dPitch;
      if (this.freeAimPitch > maxPitch) {
        this.playerPitch = THREE.MathUtils.clamp(this.playerPitch + (this.freeAimPitch - maxPitch), -1.28, 1.28);
        this.freeAimPitch = maxPitch;
      } else if (this.freeAimPitch < -maxPitch) {
        this.playerPitch = THREE.MathUtils.clamp(this.playerPitch + (this.freeAimPitch + maxPitch), -1.28, 1.28);
        this.freeAimPitch = -maxPitch;
      }

      // Chest-rig inertia banking roll when whipping camera left/right
      this.turnRoll = THREE.MathUtils.clamp(this.turnRoll - e.movementX * 0.00048, -0.085, 0.085);
    } else {
      this.playerYaw += dYaw;
      this.playerPitch = THREE.MathUtils.clamp(this.playerPitch + dPitch, -1.32, 1.32);
      this.freeAimYaw = 0;
      this.freeAimPitch = 0;
    }

    this.swayX = THREE.MathUtils.clamp(this.swayX - e.movementX * 0.00055, -0.055, 0.055);
    this.swayY = THREE.MathUtils.clamp(this.swayY + e.movementY * 0.00055, -0.042, 0.042);
  };

  private handleMouseDown = (e: MouseEvent) => {
    if (!this.isPointerLocked) return;
    soundEngine.unlock();
    if (e.button === 0) {
      this.mouseDownLeft = true;
      this.tryFire();
    } else if (e.button === 2) {
      this.mouseDownRight = true;
    }
  };

  private handleMouseUp = (e: MouseEvent) => {
    if (e.button === 0) this.mouseDownLeft = false;
    else if (e.button === 2) this.mouseDownRight = false;
  };

  private handleWheel = (e: WheelEvent) => {
    if (!this.isPointerLocked) return;
    const order: WeaponId[] = ['pistol', 'rifle', 'sniper'];
    const cur = order.indexOf(this.weaponId);
    const next = (cur + (e.deltaY > 0 ? 1 : -1) + order.length) % order.length;
    this.switchWeapon(order[next]);
  };

  /**
   * Projects a viewmodel socket (in vmScene space) seamlessly into worldScene 3D coordinates
   * right in front of worldCamera so bullets, smoke, and brass shells spawn from the EXACT
   * visual muzzle and ejection port on screen!
   */
  private vmSocketToWorld(socket: THREE.Object3D, worldDistOverride?: number): THREE.Vector3 {
    socket.updateWorldMatrix(true, false);
    const vmPos = new THREE.Vector3();
    socket.getWorldPosition(vmPos);

    // Distance from vmCamera
    const dist = worldDistOverride ?? Math.max(0.28, vmPos.length());

    // Project vmPos to Normalized Device Coordinates via vmCamera
    const ndc = vmPos.clone().project(this.vmCamera);

    // Unproject NDC into worldCamera ray direction, then place at dist along that ray
    const worldPoint = new THREE.Vector3(ndc.x, ndc.y, 0.5).unproject(this.worldCamera);
    const dir = worldPoint.sub(this.worldCamera.position).normalize();
    return this.worldCamera.position.clone().addScaledVector(dir, dist);
  }

  private tryFire() {
    if (this.animState === 'reloading' || this.animState === 'bolt_cycle' || this.animState === 'equipping') return;
    if (this.fireCooldown > 0) return;
    if (this.gameMode === 'drill' && this.drillFinished) return;
    if (this.gameMode === 'horde' && this.horde.phase === 'gameover') return;

    const spec = WEAPON_SPECS[this.weaponId];
    const ammo = this.ammoMap[this.weaponId];
    if (ammo <= 0) {
      soundEngine.playDryFire();
      this.fireCooldown = 0.22;
      this.lastEventText = `Ammo ${spec.label} HABIS! Tekan R untuk mengisi ammo (Pose Gambar 1)`;
      this.emitHud();
      return;
    }

    // Cancel inspect instantly on shot!
    if (this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
    }

    // Consume 1 round
    this.ammoMap[this.weaponId] = ammo - 1;
    this.fireCooldown = 60 / spec.rpm;
    this.shotsFired++;
    this.triggerPullTimer = 0.09;

    // Visual Muzzle Flash & Lighting Pulse
    const rig = this.rigs[this.weaponId];
    this.muzzleFlashTimer = this.weaponId === 'sniper' ? 0.095 : this.weaponId === 'rifle' ? 0.058 : 0.052;
    rig.muzzleFlash.visible = true;
    rig.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
    const fScale = 0.88 + Math.random() * 0.26;
    rig.muzzleFlash.scale.set(fScale, fScale, fScale);
    this.vmMuzzleLight.intensity = this.weaponId === 'sniper' ? 8.5 : this.weaponId === 'rifle' ? 5.2 : 4.2;

    // Telemetry callout pulses
    this.pulseMuzzle = 1.0;
    this.pulseAction = 1.0;

    // Recoil Impulses (30% more stable when crouched + tighter ADS control!)
    const adsScale = this.adsBlend > 0.5 ? 0.58 : 1.0;
    const crouchScale = 1 - this.crouchBlend * 0.3;
    const stability = adsScale * crouchScale;
    this.recoilPosZ = Math.min(0.14, this.recoilPosZ + spec.recoilKickZ * stability);
    this.recoilRotX = Math.min(0.42, this.recoilRotX + spec.recoilPitch * stability);
    this.recoilRotY += (Math.random() - 0.5) * spec.recoilYaw * stability;
    this.recoilRotZ += (Math.random() - 0.5) * spec.recoilYaw * 1.35 * stability;
    this.camRecoilVel += spec.cameraPunch * (this.adsBlend > 0.5 ? 0.68 : 1.0) * crouchScale;
    this.spreadBloom = Math.min(1.0, this.spreadBloom + (this.weaponId === 'rifle' ? 0.22 : 0.42) * crouchScale);
    this.camTrauma = Math.min(
      1.0,
      this.camTrauma + (this.weaponId === 'sniper' ? 0.52 : this.weaponId === 'rifle' ? 0.18 : 0.24) * crouchScale
    );
    this.adrenaline = Math.min(1.0, this.adrenaline + 0.22);
    this.glareStrength = Math.min(1.8, this.glareStrength + (this.weaponId === 'sniper' ? 0.95 : 0.45));

    // Realistic Multi-Layer Bodycam Firearm Audio (with live indoor concrete slapback vs outdoor echo!)
    soundEngine.playShot(
      this.weaponId,
      this.slowMo,
      this.indoorDarkness,
      this.ammoMap[this.weaponId] === 0
    );

    // Weapon-specific Immediate Mechanical Blowback & Shell Ejection!
    const isSniperScoped = this.weaponId === 'sniper' && this.adsBlend > 0.68;
    const muzzleWorld = isSniperScoped
      ? this.worldCamera.position
          .clone()
          .addScaledVector(this.worldCamera.getWorldDirection(this.tmpV1), 0.9)
          .add(new THREE.Vector3(0, -0.06, 0))
      : this.vmSocketToWorld(rig.muzzleSocket, this.weaponId === 'sniper' ? 1.15 : this.weaponId === 'rifle' ? 0.9 : 0.62);

    if (this.weaponId === 'pistol') {
      // PISTOL: Top slide snaps backward immediately + hammer drops + .45 brass shell ejects NOW!
      this.slideKick = 1.0;
      this.spawnShellCasing('pistol');
      this.pulseEjection = 1.0;
      this.spawnMuzzleSmoke(muzzleWorld, 2, 0.7);
      this.lastEventText =
        this.ammoMap.pistol === 0
          ? 'PISTOL: Slide terkunci mundur (Ammo 0)! Selongsong terakhir keluar dari Ejection Port.'
          : 'PISTOL: Peluru keluar dari Muzzle • Slide blowback mundur • Selongsong kuningan keluar kanan-atas!';
    } else if (this.weaponId === 'rifle') {
      // RIFLE: Dust cover pops open + Bolt Carrier reciprocates rapidly + 5.56 brass shell deflects right NOW!
      this.rifleDustCoverOpen = true;
      this.rifleBoltKick = 1.0;
      this.spawnShellCasing('rifle');
      this.pulseEjection = 1.0;
      this.spawnMuzzleSmoke(muzzleWorld, 2, 0.9);
      this.lastEventText =
        'RIFLE M4A1: Peluru 5.56 dari Flash-Hider • Bolt Carrier bolak-balik • Selongsong memantul Brass Deflector!';
    } else {
      // SNIPER: Massive twin side-port muzzle-brake gas blast + NO shell yet (shell waits for Bolt Cycle!)
      this.spawnSniperBrakeBlast(muzzleWorld);
      this.lastEventText =
        this.ammoMap.sniper > 0
          ? 'SNIPER .338: Gas Muzzle Brake menyembur kiri-kanan + Contrail! Memulai kokang Bolt untuk buang selongsong...'
          : 'SNIPER .338: Tembakan terakhir! Tekan R untuk Reload & kokang Bolt (Pose Gambar 1).';
      if (this.ammoMap.sniper > 0) {
        this.animState = 'bolt_cycle';
        this.boltTimer = 0;
        this.boltDuration = spec.boltCycleDuration;
        this.boltStageTriggered.clear();
      }
    }

    // Alert smart bots acoustically when firing inside or near the Abandoned Graffiti Compound!
    const hearRadius = this.weaponId === 'sniper' ? 58 : this.weaponId === 'rifle' ? 42 : 28;
    this.botSquad.notifyPlayerGunshot(this.worldCamera.position, hearRadius);

    // Raycast Ballistic Hit Detection + Glowing Tracer Spawn
    this.performBallisticShot(muzzleWorld);
    this.emitHud();
  }

  private getTrueAimDirection(target: THREE.Vector3): THREE.Vector3 {
    // True ballistic barrel line = chest camera orientation + live Free-Aim weapon offset!
    const aimEuler = new THREE.Euler(
      this.worldCamera.rotation.x + this.freeAimPitch,
      this.worldCamera.rotation.y + this.freeAimYaw,
      0,
      'YXZ'
    );
    return target.set(0, 0, -1).applyEuler(aimEuler).normalize();
  }

  private performBallisticShot(muzzleWorld: THREE.Vector3) {
    const spec = WEAPON_SPECS[this.weaponId];
    const crouchSpreadScale = 1 - this.crouchBlend * 0.32;
    const spread =
      (THREE.MathUtils.lerp(spec.spreadHip, spec.spreadAds, this.adsBlend) + this.spreadBloom * 0.014) *
      crouchSpreadScale;
    const jitterPitch = (Math.random() - 0.5) * spread * 2.0;
    const jitterYaw = (Math.random() - 0.5) * spread * 2.0;

    const aimEuler = new THREE.Euler(
      this.worldCamera.rotation.x + this.freeAimPitch + jitterPitch,
      this.worldCamera.rotation.y + this.freeAimYaw + jitterYaw,
      0,
      'YXZ'
    );
    const shotDir = new THREE.Vector3(0, 0, -1).applyEuler(aimEuler).normalize();
    this.raycaster.set(this.worldCamera.position, shotDir);
    this.raycaster.far = 420;

    // 1. Check Smart Bot Hitboxes (Head & Body)
    const botHits = this.botSquad.enabled
      ? this.raycaster.intersectObjects(this.botSquad.hitMeshes, false)
      : [];
    const validBotHit = botHits.find((h) => Boolean(h.object.userData?.botId));

    // 2. Check interactive range/compound target hitboxes (crates, barrels, dummies, gongs)
    const targetHits = this.raycaster.intersectObjects(this.world.hitMeshes, false);
    const validTargetHit = targetHits.find((h) => {
      const tid = h.object.userData?.targetId as string | undefined;
      if (!tid) return false;
      const ent = this.world.targets.find((t) => t.id === tid);
      return ent ? ent.alive && ent.group.visible : false;
    });

    // 3. Check general solid environment geometry (ignoring breakable glass so bullets penetrate glass!)
    const envHits = this.raycaster.intersectObjects(this.worldScene.children, true);
    const validEnvHit = envHits.find((h) => {
      if (h.object.userData?.targetId || h.object.userData?.botId || h.object.userData?.glassId) return false;
      if (h.object.userData?.isFx) return false;
      return h.distance < 360 && h.distance > 0.45;
    });

    const zHit = this.horde.active && this.horde.phase !== 'idle'
      ? this.horde.raycast(this.raycaster.ray.origin, this.raycaster.ray.direction, 420)
      : null;

    const envDist = validEnvHit ? validEnvHit.distance : Infinity;
    const targetDist = validTargetHit ? validTargetHit.distance : Infinity;
    const botDist = validBotHit ? validBotHit.distance : Infinity;

    let endPoint = this.raycaster.ray.origin.clone().addScaledVector(this.raycaster.ray.direction, 260);
    let finalImpactDist = 260;
    let hitTarget: TargetEntity | null = null;
    let hitBot: { botId: string; hitbox: string; dist: number } | null = null;
    let hitZombie: { id: number; hitbox: 'head' | 'body'; dist: number } | null = null;
    let hitBoxType: string | null = null;
    let hitNormal: THREE.Vector3 | null = null;

    if (
      zHit &&
      zHit.dist <= envDist + 0.05 &&
      zHit.dist <= targetDist + 0.05 &&
      zHit.dist <= botDist + 0.05
    ) {
      endPoint.copy(zHit.point);
      finalImpactDist = zHit.dist;
      hitZombie = { id: zHit.zombieId, hitbox: zHit.hitbox, dist: Math.round(zHit.dist) };
      hitNormal = this.raycaster.ray.direction.clone().negate();
    } else if (validBotHit && botDist <= envDist + 0.05 && botDist <= targetDist + 0.05) {
      endPoint.copy(validBotHit.point);
      finalImpactDist = botDist;
      hitBot = {
        botId: validBotHit.object.userData.botId,
        hitbox: validBotHit.object.userData.hitbox || 'body',
        dist: Math.round(botDist),
      };
      hitNormal = validBotHit.face?.normal
        ? validBotHit.face.normal.clone().transformDirection(validBotHit.object.matrixWorld)
        : this.raycaster.ray.direction.clone().negate();
    } else if (validTargetHit && targetDist <= envDist + 0.08) {
      endPoint.copy(validTargetHit.point);
      finalImpactDist = targetDist;
      hitTarget = this.world.targets.find((t) => t.id === validTargetHit.object.userData.targetId) ?? null;
      hitBoxType = validTargetHit.object.userData.hitbox;
      hitNormal = validTargetHit.face?.normal
        ? validTargetHit.face.normal.clone().transformDirection(validTargetHit.object.matrixWorld)
        : this.raycaster.ray.direction.clone().negate();
    } else if (validEnvHit) {
      endPoint.copy(validEnvHit.point);
      finalImpactDist = envDist;
      hitNormal = validEnvHit.face?.normal
        ? validEnvHit.face.normal.clone().transformDirection(validEnvHit.object.matrixWorld)
        : this.raycaster.ray.direction.clone().negate();
    }

    // 4. Physical 2-Stage Glass Cracking & Shattering along the bullet trajectory (full penetration!)
    //    - 1st Pistol/Rifle hit: Exact UV-centered Spiderweb Crack + Bullet Hole + Glass Dust Spray!
    //    - 2nd Hit (OR 1st Sniper .338 round!): Full Explosive Glass Shatter + Bouncing 3D Shards + Jagged Frame Teeth!
    const glassHits = this.raycaster.intersectObjects(this.world.compound.glassHitMeshes, false);
    for (const gh of glassHits) {
      if (gh.distance > finalImpactDist + 0.12) break;
      const gid = gh.object.userData?.glassId as string | undefined;
      if (!gid) continue;
      const pane = this.world.compound.glassPanes.find((g) => g.id === gid);
      if (pane && !pane.broken) {
        const hitU = gh.uv ? gh.uv.x : 0.5;
        const hitV = gh.uv ? gh.uv.y : 0.5;
        this.damageGlassPane(pane, gh.point, hitU, hitV, shotDir, this.weaponId === 'sniper');
      }
    }

    // Spawn High-Velocity Visual Bullet Tracer from exact 3D muzzle tip to hit point!
    this.spawnTracer(muzzleWorld, endPoint, spec.muzzleVelocity);
    if (this.weaponId === 'sniper') {
      this.spawnSniperContrail(muzzleWorld, endPoint);
    }

    // Apply Hit Effects & Scoring
    if (hitZombie && hitNormal) {
      const isHead = hitZombie.hitbox === 'head';
      const dmg = isHead ? spec.damageHead : spec.damageBody;
      const res = this.horde.applyDamage(hitZombie.id, dmg, isHead, this.worldCamera.position, endPoint);
      if (res) {
        this.shotsHit++;
        this.spawnImpactSparks(endPoint, hitNormal, isHead ? 0xb3121a : 0x8a1016, isHead ? 16 : 9);
        soundEngine.playZombieHit(hitZombie.dist, isHead);
        if (res.killed) {
          this.streak++;
          if (isHead) this.headshots++;
          const pts = (isHead ? 160 : 90) + (res.isBrute ? 400 : 0) + Math.min(100, this.streak * 6);
          this.score += pts;
          this.pushHitFeedback(isHead, true, res.isBrute ? 'BRUTE DOWN' : isHead ? 'ZOMBIE HEADSHOT' : 'ZOMBIE DOWN', pts, hitZombie.dist);
        } else {
          this.score += 12;
          this.pushHitFeedback(isHead, false, res.isBrute ? 'BRUTE HIT' : isHead ? 'HEAD HIT' : 'HIT', 12, hitZombie.dist);
        }
      }
    } else if (hitBot && hitNormal) {
      const isHead = hitBot.hitbox === 'head';
      const dmg = isHead ? spec.damageHead : spec.damageBody;
      const res = this.botSquad.applyDamage(hitBot.botId, dmg, isHead, this.worldCamera.position);
      if (res) {
        this.shotsHit++;
        this.spawnImpactSparks(endPoint, hitNormal, isHead ? 0xffe066 : 0xff5a36, isHead ? 14 : 8);
        if (res.killed) {
          this.streak++;
          if (isHead) this.headshots++;
          const pts = (isHead ? 220 : 140) + Math.min(120, this.streak * 15);
          this.score += pts;
          soundEngine.playHit(isHead ? 'headshot' : 'steel', hitBot.dist);
          this.pushHitFeedback(isHead, true, res.label, pts, hitBot.dist);
        } else {
          this.score += 30;
          soundEngine.playHit('steel', hitBot.dist);
          this.pushHitFeedback(isHead, false, res.label, 30, hitBot.dist);
        }
      }
    } else if (hitTarget && hitNormal) {
      this.handleTargetHit(hitTarget, hitBoxType || 'body', endPoint, hitNormal);
    } else if (validEnvHit && hitNormal) {
      // Shooting an Interactive Steel/Wood Door blows it smoothly open!
      const hitDoorId = validEnvHit.object.userData?.doorId as string | undefined;
      if (hitDoorId) {
        const door = this.world.compound.doors.find((d) => d.id === hitDoorId);
        if (door && !door.isOpen) {
          door.isOpen = true;
          soundEngine.playDoorToggle(true, validEnvHit.distance);
          this.lastEventText = 'PINTU DIDOBRAK TEMBAKAN!';
        }
        this.spawnImpactSparks(endPoint, hitNormal, 0xffc66d, 9);
      } else {
        this.spawnImpactSparks(endPoint, hitNormal, 0xdbe4ea, 5);
        this.spawnImpactMark(endPoint, hitNormal);
      }
      this.streak = 0;
    }
  }

  private handleTargetHit(
    target: TargetEntity,
    hitbox: string,
    point: THREE.Vector3,
    normal: THREE.Vector3
  ) {
    const spec = WEAPON_SPECS[this.weaponId];
    const distMeters = Math.round(this.worldCamera.position.distanceTo(point));
    this.shotsHit++;

    const isHead = hitbox === 'head';
    const dmg = isHead ? spec.damageHead : spec.damageBody;

    if (target.kind === 'gong') {
      // Swinging Sniper Steel Gong!
      target.knockVel -= this.weaponId === 'sniper' ? 9.5 : 4.2;
      this.streak++;
      if (isHead) this.headshots++;
      const distBonus = Math.round(distMeters * 0.8);
      const pts = (isHead ? 200 : 120) + distBonus;
      this.score += pts;
      soundEngine.playHit(isHead ? 'headshot' : 'steel', distMeters);
      this.spawnImpactSparks(point, normal, isHead ? 0xffd24c : 0xffaa33, 12);
      this.pushHitFeedback(isHead, true, isHead ? 'BULLSEYE GONG' : 'STEEL GONG', pts, distMeters);
      return;
    }

    target.hp -= dmg;

    if (target.kind === 'crate') {
      soundEngine.playHit('wood', distMeters);
      this.spawnWoodSplinters(point, 5);
      if (target.hp <= 0) {
        target.alive = false;
        target.group.visible = false;
        target.respawnTimer = 6.5;
        this.spawnWoodSplinters(target.group.position.clone().add(new THREE.Vector3(0, 0.7, 0)), 14);
        this.streak++;
        const pts = 75;
        this.score += pts;
        this.pushHitFeedback(false, true, 'CRATE SHATTER', pts, distMeters);
      } else {
        this.pushHitFeedback(false, false, 'WOOD HIT', 15, distMeters);
        this.score += 15;
      }
      return;
    }

    if (target.kind === 'barrel') {
      this.spawnImpactSparks(point, normal, 0xff8c2b, 8);
      if (target.hp <= 0) {
        this.detonateBarrel(target, distMeters);
      } else {
        soundEngine.playHit('steel', distMeters);
        this.pushHitFeedback(false, false, 'FUEL BARREL', 20, distMeters);
        this.score += 20;
      }
      return;
    }

    // Standard Tactical Steel Humanoid Target
    this.spawnImpactSparks(point, normal, isHead ? 0xffe066 : 0xff9b3d, isHead ? 12 : 7);
    if (target.hp <= 0) {
      target.alive = false;
      target.knockVel = -10.5;
      target.respawnTimer = this.gameMode === 'drill' ? 2.1 : 3.2;
      this.streak++;
      if (isHead) this.headshots++;
      const pts = (isHead ? 150 : 100) + Math.min(100, this.streak * 10) + (distMeters > 90 ? 50 : 0);
      this.score += pts;
      soundEngine.playHit(isHead ? 'headshot' : 'steel', distMeters);
      this.pushHitFeedback(isHead, true, isHead ? 'HEADSHOT' : 'TARGET DOWN', pts, distMeters);
    } else {
      target.knockVel = -2.6;
      soundEngine.playHit('steel', distMeters);
      this.score += 25;
      this.pushHitFeedback(isHead, false, isHead ? 'HEAD HIT' : 'HIT', 25, distMeters);
    }
  }

  private detonateBarrel(barrel: TargetEntity, distMeters: number) {
    barrel.alive = false;
    barrel.group.visible = false;
    barrel.respawnTimer = 8.5;
    const barrelWorldPos = new THREE.Vector3();
    barrel.group.getWorldPosition(barrelWorldPos);
    const center = barrelWorldPos.clone().add(new THREE.Vector3(0, 0.65, 0));

    soundEngine.playHit('explosion', distMeters);
    this.spawnExplosion(center);
    this.camTrauma = Math.min(1.0, this.camTrauma + Math.max(0.25, 0.9 - distMeters * 0.025));
    this.glareStrength = Math.min(2.0, this.glareStrength + 1.15);

    // Blast any smart bots caught near the exploding barrel!
    const botKills = this.botSquad.applyExplosionDamage(center, 9.2) + (this.horde.active ? this.horde.applyExplosion(center, 11) : 0);

    // Overpressure shockwave violently shatters ALL intact/cracked windows within 11.5m!
    this.world.compound.glassPanes.forEach((pane) => {
      if (pane.broken) return;
      pane.mesh.updateWorldMatrix(true, false);
      const panePos = new THREE.Vector3();
      pane.mesh.getWorldPosition(panePos);
      const d = panePos.distanceTo(center);
      if (d < 11.5) {
        const blastDir = panePos.clone().sub(center).normalize();
        this.damageGlassPane(pane, panePos, 0.5, 0.5, blastDir, true);
      }
    });

    // Chain-reaction blast knocking down nearby targets within 9.5m!
    let chainCount = botKills;
    const tWorldPos = new THREE.Vector3();
    this.world.targets.forEach((t) => {
      if (!t.alive || t.id === barrel.id) return;
      t.group.getWorldPosition(tWorldPos);
      const d = tWorldPos.distanceTo(barrelWorldPos);
      if (d < 9.5) {
        if (t.kind === 'dummy') {
          t.alive = false;
          t.hp = 0;
          t.knockVel = -12.0;
          t.respawnTimer = 3.5;
          chainCount++;
        } else if (t.kind === 'crate') {
          t.alive = false;
          t.hp = 0;
          t.group.visible = false;
          t.respawnTimer = 7.0;
          this.spawnWoodSplinters(tWorldPos.clone().add(new THREE.Vector3(0, 0.7, 0)), 10);
          chainCount++;
        }
      }
    });

    this.streak += 1 + chainCount;
    const pts = 180 + chainCount * 140;
    this.score += pts;
    this.pushHitFeedback(
      true,
      true,
      chainCount > 0 ? `BOOM! +${chainCount} ELIM` : 'EXPLOSION',
      pts,
      distMeters
    );
  }

  private spawnEnemyTracer(start: THREE.Vector3, end: THREE.Vector3) {
    const dir = end.clone().sub(start);
    const distTotal = dir.length();
    if (distTotal < 0.3) return;
    dir.normalize();

    const mesh = new THREE.Mesh(this.enemyTracerGeo, this.enemyTracerMat);
    mesh.position.copy(start);
    mesh.lookAt(end);
    mesh.userData.isFx = true;
    this.worldScene.add(mesh);

    this.tracers.push({
      mesh,
      start: start.clone(),
      end: end.clone(),
      dir,
      distTotal,
      distTraveled: 0,
      speed: 145,
      alive: true,
    });
  }

  private pushHitFeedback(
    isHeadshot: boolean,
    isKill: boolean,
    label: string,
    points: number,
    distance: number
  ) {
    this.hitFeedbackCounter++;
    this.hitFeedback = {
      id: this.hitFeedbackCounter,
      isHeadshot,
      isKill,
      label,
      points,
      distance,
    };
    this.hitFeedbackTimer = 1.25;
  }

  private spawnShellCasing(weapon: WeaponId) {
    const rig = this.rigs[weapon];
    const startPos = this.vmSocketToWorld(rig.ejectionSocket, weapon === 'pistol' ? 0.44 : 0.48);

    const mesh = new THREE.Mesh(this.shellGeos[weapon], this.brassMat);
    mesh.position.copy(startPos);
    mesh.quaternion.copy(this.worldCamera.quaternion);
    mesh.rotateZ(Math.PI / 2);
    mesh.userData.isFx = true;
    this.worldScene.add(mesh);

    // Authentic caliber-specific ejection vectors in camera space!
    const localVel = new THREE.Vector3();
    if (weapon === 'pistol') {
      // Snappy upward-right arc from top-right slide window
      localVel.set(1.55 + Math.random() * 0.55, 1.85 + Math.random() * 0.55, 0.35 + Math.random() * 0.3);
    } else if (weapon === 'rifle') {
      // Brisk rightward arc bouncing off the brass deflector
      localVel.set(2.35 + Math.random() * 0.65, 1.35 + Math.random() * 0.45, 0.2 + Math.random() * 0.35);
    } else {
      // Heavier, graceful arc pulled cleanly out during Sniper bolt-back cycle
      localVel.set(1.65 + Math.random() * 0.45, 1.45 + Math.random() * 0.35, 0.45 + Math.random() * 0.25);
    }

    localVel.applyQuaternion(this.worldCamera.quaternion).add(this.playerVel);

    this.shells.push({
      mesh,
      vel: localVel,
      angVel: new THREE.Vector3(
        (Math.random() - 0.5) * 26,
        (Math.random() - 0.5) * 26,
        -18 - Math.random() * 14
      ),
      age: 0,
      maxAge: 6.5,
      bounces: 0,
      weapon,
    });
  }

  private spawnTracer(start: THREE.Vector3, end: THREE.Vector3, speed: number) {
    const dir = end.clone().sub(start);
    const distTotal = dir.length();
    if (distTotal < 0.2) return;
    dir.normalize();

    const mesh = new THREE.Mesh(this.tracerGeoByWeapon[this.weaponId], this.tracerMatByWeapon[this.weaponId]);
    mesh.position.copy(start);
    mesh.lookAt(end);
    mesh.userData.isFx = true;
    this.worldScene.add(mesh);

    this.tracers.push({
      mesh,
      start: start.clone(),
      end: end.clone(),
      dir,
      distTotal,
      distTraveled: 0,
      speed,
      alive: true,
    });
  }

  private spawnSniperContrail(start: THREE.Vector3, end: THREE.Vector3) {
    const dir = end.clone().sub(start);
    const len = Math.min(dir.length(), 280);
    if (len < 1) return;
    const mid = start.clone().addScaledVector(dir.normalize(), len * 0.5);

    const geo = new THREE.CylinderGeometry(0.016, 0.028, len, 5);
    geo.rotateX(Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(mid);
    mesh.lookAt(end);
    mesh.userData.isFx = true;
    this.worldScene.add(mesh);

    this.contrails.push({ mesh, age: 0, maxAge: 0.95 });
  }

  private spawnMuzzleSmoke(pos: THREE.Vector3, count: number, scale: number) {
    const forward = this.worldCamera.getWorldDirection(new THREE.Vector3());
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.smokeGeo, this.acquireMat(this.smokeMat));
      m.position.copy(pos);
      m.userData.isFx = true;
      this.worldScene.add(m);
      const vel = forward
        .clone()
        .multiplyScalar(1.4 + Math.random() * 1.4)
        .add(new THREE.Vector3((Math.random() - 0.5) * 0.7, 0.65 + Math.random() * 0.55, (Math.random() - 0.5) * 0.7));
      this.particles.push({
        mesh: m,
        vel,
        angVel: new THREE.Vector3(Math.random() * 2, Math.random() * 2, Math.random() * 2),
        gravity: -0.35, // gently rises upward
        age: 0,
        maxAge: 0.55 + Math.random() * 0.3,
        startScale: 0.35 * scale,
        endScale: 1.85 * scale,
        fadeOpacity: true,
      });
    }
  }

  private spawnSniperBrakeBlast(pos: THREE.Vector3) {
    // Dramatic twin lateral muzzle-brake gas clouds shooting LEFT (-X) and RIGHT (+X) + forward smoke!
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(this.worldCamera.quaternion);
    const forward = this.worldCamera.getWorldDirection(new THREE.Vector3());

    [-1, 1].forEach((side) => {
      for (let i = 0; i < 4; i++) {
        const m = new THREE.Mesh(this.smokeGeo, this.acquireMat(this.smokeMat));
        m.position.copy(pos);
        m.userData.isFx = true;
        this.worldScene.add(m);
        const vel = right
          .clone()
          .multiplyScalar(side * (3.2 + i * 1.1))
          .addScaledVector(forward, -0.4 + Math.random() * 0.6)
          .add(new THREE.Vector3(0, 0.35 + Math.random() * 0.4, 0));
        this.particles.push({
          mesh: m,
          vel,
          angVel: new THREE.Vector3(3, 3, 3),
          gravity: -0.25,
          age: 0,
          maxAge: 0.75 + Math.random() * 0.3,
          startScale: 0.5,
          endScale: 2.5,
          fadeOpacity: true,
        });
      }
    });
    this.spawnMuzzleSmoke(pos, 3, 1.3);
  }

  private spawnImpactSparks(pos: THREE.Vector3, normal: THREE.Vector3, colorHex: number, count: number) {
    let mat = this.sparkMatCache.get(colorHex);
    if (!mat) {
      mat = new THREE.MeshBasicMaterial({ color: colorHex });
      this.sparkMatCache.set(colorHex, mat);
    }
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.sparkGeo, mat);
      m.position.copy(pos).addScaledVector(normal, 0.05);
      m.userData.isFx = true;
      this.worldScene.add(m);
      const vel = normal
        .clone()
        .multiplyScalar(3.2 + Math.random() * 5.0)
        .add(new THREE.Vector3((Math.random() - 0.5) * 5.5, 1.2 + Math.random() * 3.8, (Math.random() - 0.5) * 5.5));
      this.particles.push({
        mesh: m,
        vel,
        angVel: new THREE.Vector3(12, 12, 12),
        gravity: 14,
        age: 0,
        maxAge: 0.25 + Math.random() * 0.22,
        startScale: 1.0,
        endScale: 0.05,
        fadeOpacity: false,
      });
    }
  }

  private spawnWoodSplinters(pos: THREE.Vector3, count: number) {
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.woodPlankGeo, this.woodMat);
      m.position.copy(pos);
      m.userData.isFx = true;
      this.worldScene.add(m);
      this.particles.push({
        mesh: m,
        vel: new THREE.Vector3((Math.random() - 0.5) * 8, 2.5 + Math.random() * 5.5, (Math.random() - 0.5) * 8),
        angVel: new THREE.Vector3((Math.random() - 0.5) * 14, (Math.random() - 0.5) * 14, (Math.random() - 0.5) * 14),
        gravity: 16,
        age: 0,
        maxAge: 0.9 + Math.random() * 0.5,
        startScale: 0.8 + Math.random() * 0.5,
        endScale: 0.1,
        fadeOpacity: false,
      });
    }
  }

  private damageGlassPane(
    pane: BreakableGlassPane,
    hitPoint: THREE.Vector3,
    hitU: number,
    hitV: number,
    shotDir: THREE.Vector3,
    forceFullShatter: boolean
  ) {
    if (pane.broken) return;
    this.glassBatch.release(pane);
    const dist = hitPoint.distanceTo(this.worldCamera.position);

    if (pane.stage === 0 && !forceFullShatter) {
      // STAGE 1: Realistic Spiderweb Glass Fracture centered at exact bullet UV impact point!
      pane.stage = 1;
      const crackTex = createCrackedGlassTexture(hitU, hitV);
      const crackedMat = new THREE.MeshStandardMaterial({
        map: crackTex,
        emissive: 0x2c4b59,
        emissiveIntensity: 0.22,
        roughness: 0.14,
        metalness: 0.4,
        transparent: true,
        opacity: 0.94,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      pane.crackedMat = crackedMat;
      pane.mesh.material = crackedMat;

      soundEngine.playGlassCrack(dist);
      this.spawnGlassDustPuff(hitPoint, shotDir, 4);
      this.spawnPhysicalGlassShards(hitPoint, shotDir, 0.22, 0.22, 9, 0.65);
    } else {
      // STAGE 2: Full Explosive Pane Shatter + Remaining Jagged Frame Teeth + Bouncing 3D Crystal Shards!
      pane.stage = 2;
      pane.broken = true;
      pane.mesh.visible = false;
      pane.edgeShardsGroup.visible = true;

      pane.mesh.updateWorldMatrix(true, false);
      const paneWorldCenter = new THREE.Vector3();
      pane.mesh.getWorldPosition(paneWorldCenter);

      soundEngine.playGlassShatter(dist);
      this.spawnGlassDustPuff(paneWorldCenter, shotDir, 7);
      this.spawnPhysicalGlassShards(
        paneWorldCenter,
        shotDir,
        pane.width,
        pane.height,
        26,
        1.15,
        pane.mesh.getWorldQuaternion(new THREE.Quaternion())
      );
    }
  }

  private spawnGlassDustPuff(pos: THREE.Vector3, shotDir: THREE.Vector3, count: number) {
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.smokeGeo, this.acquireMat(this.glassDustMat));
      m.position.copy(pos).add(
        new THREE.Vector3((Math.random() - 0.5) * 0.24, (Math.random() - 0.5) * 0.24, (Math.random() - 0.5) * 0.24)
      );
      m.userData.isFx = true;
      this.worldScene.add(m);
      const vel = shotDir
        .clone()
        .multiplyScalar(1.6 + Math.random() * 2.4)
        .add(new THREE.Vector3((Math.random() - 0.5) * 1.4, 0.4 + Math.random() * 0.9, (Math.random() - 0.5) * 1.4));
      this.particles.push({
        mesh: m,
        vel,
        angVel: new THREE.Vector3(2, 2, 2),
        gravity: 1.8,
        age: 0,
        maxAge: 0.34 + Math.random() * 0.22,
        startScale: 0.38,
        endScale: 1.65,
        fadeOpacity: true,
      });
    }
  }

  private spawnPhysicalGlassShards(
    center: THREE.Vector3,
    shotDir: THREE.Vector3,
    spreadW: number,
    spreadH: number,
    count: number,
    sizeScale: number,
    paneQuat?: THREE.Quaternion
  ) {
    for (let i = 0; i < count; i++) {
      const geo = this.glassShardGeos[i % this.glassShardGeos.length];
      const m = new THREE.Mesh(geo, this.glassShardMat);

      // Distribute shards organically across the broken glass sheet!
      const localOff = new THREE.Vector3(
        (Math.random() - 0.5) * spreadW * 0.9,
        (Math.random() - 0.5) * spreadH * 0.9,
        (Math.random() - 0.5) * 0.04
      );
      if (paneQuat) localOff.applyQuaternion(paneQuat);
      m.position.copy(center).add(localOff);
      m.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);

      const sc = sizeScale * (0.55 + Math.random() * 0.95);
      m.scale.setScalar(sc);
      m.userData.isFx = true;
      this.worldScene.add(m);

      // Outward exit momentum + radial shatter explosion cone!
      const radial = localOff.clone().multiplyScalar(2.4);
      const vel = shotDir
        .clone()
        .multiplyScalar(2.2 + Math.random() * 4.8)
        .add(radial)
        .add(new THREE.Vector3((Math.random() - 0.5) * 2.2, 0.65 + Math.random() * 2.6, (Math.random() - 0.5) * 2.2));

      this.glassShards.push({
        mesh: m,
        vel,
        angVel: new THREE.Vector3(
          (Math.random() - 0.5) * 24,
          (Math.random() - 0.5) * 24,
          (Math.random() - 0.5) * 24
        ),
        age: 0,
        maxAge: 10.5 + Math.random() * 3.5,
        bounces: 0,
        baseScale: sc,
        // Cap floor clink audio triggers to ~4 shards per shattered window for a realistic crisp chorus!
        makeBounceSound: i < 4,
      });

      // Keep active resting glass shard pool smoothly bounded
      if (this.glassShards.length > 180) {
        const old = this.glassShards.shift();
        if (old) this.worldScene.remove(old.mesh);
      }
    }
  }

  private tryToggleNearbyDoor() {
    let closest = null as (typeof this.world.compound.doors)[number] | null;
    let bestD = 3.1;
    for (const door of this.world.compound.doors) {
      const d = door.center.distanceTo(this.worldCamera.position);
      if (d < bestD) {
        bestD = d;
        closest = door;
      }
    }
    if (closest) {
      closest.isOpen = !closest.isOpen;
      soundEngine.playDoorToggle(closest.isOpen, bestD);
      this.lastEventText = closest.isOpen ? 'Pintu Dibuka [E]' : 'Pintu Ditutup [E]';
      this.emitHud();
    }
  }

  private updateInteractiveDoors(dt: number) {
    for (const door of this.world.compound.doors) {
      const target = door.isOpen ? 1.0 : 0.0;
      if (Math.abs(door.openProgress - target) > 0.002) {
        door.openProgress = THREE.MathUtils.lerp(door.openProgress, target, 1 - Math.exp(-9.0 * dt));
        door.pivot.rotation.y = THREE.MathUtils.lerp(door.closedAngle, door.openAngle, door.openProgress);
        door.collider.disabled = door.openProgress >= 0.42;
      }
    }
  }

  private spawnExplosion(pos: THREE.Vector3) {
    // Low-poly stylized fireball spheres + billowing smoke plumes
    for (let i = 0; i < 12; i++) {
      const mat = i < 5 ? this.acquireMat(this.fireCoreMat) : this.acquireMat(this.fireMat);
      const m = new THREE.Mesh(this.smokeGeo, mat);
      m.position.copy(pos);
      m.userData.isFx = true;
      this.worldScene.add(m);
      this.particles.push({
        mesh: m,
        vel: new THREE.Vector3((Math.random() - 0.5) * 9, 2.0 + Math.random() * 7.5, (Math.random() - 0.5) * 9),
        angVel: new THREE.Vector3(4, 4, 4),
        gravity: 2.5,
        age: 0,
        maxAge: 0.55 + Math.random() * 0.35,
        startScale: 2.5,
        endScale: 8.5,
        fadeOpacity: true,
      });
    }
    for (let i = 0; i < 10; i++) {
      const m = new THREE.Mesh(this.smokeGeo, this.acquireMat(this.smokeMat));
      m.position.copy(pos);
      m.userData.isFx = true;
      this.worldScene.add(m);
      this.particles.push({
        mesh: m,
        vel: new THREE.Vector3((Math.random() - 0.5) * 6, 3.0 + Math.random() * 5.5, (Math.random() - 0.5) * 6),
        angVel: new THREE.Vector3(2, 2, 2),
        gravity: -1.5,
        age: 0,
        maxAge: 1.4 + Math.random() * 0.5,
        startScale: 3.5,
        endScale: 12.0,
        fadeOpacity: true,
      });
    }
  }

  private spawnImpactMark(pos: THREE.Vector3, normal: THREE.Vector3) {
    const m = new THREE.Mesh(this.impactGeo, this.impactMat);
    m.position.copy(pos).addScaledVector(normal, 0.018);
    m.lookAt(pos.clone().add(normal));
    m.userData.isFx = true;
    this.worldScene.add(m);
    this.impactMarks.push({ mesh: m, age: 0, maxAge: 14 });
    if (this.impactMarks.length > 45) {
      const old = this.impactMarks.shift();
      if (old) this.worldScene.remove(old.mesh);
    }
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    this.rafId = requestAnimationFrame(this.loop);

    const frameDtRaw = (now - this.lastTime) / 1000;
    const rawDt = Math.min(0.05, frameDtRaw);
    this.lastTime = now;

    // Adaptive quality governor (locked-60 FPS target)
    this.frameCounter++;
    const newLevel = this.perf.tick(frameDtRaw);
    if (newLevel !== null) this.applyQuality(newLevel);
    this.renderer.info.reset();
    if (this.frameCounter % this.shadowEvery === 0) this.renderer.shadowMap.needsUpdate = true;
    this.rawTime += rawDt;

    // Apply Slow-Mo time dilation (0.25x) to weapon mechanics, shells, tracers, and target physics
    // while keeping mouse look & camera optics fluid!
    const simDt = rawDt * (this.slowMo ? 0.25 : 1.0);
    this.elapsedTime += simDt;

    this.updatePlayer(rawDt);
    this.updateWeaponStateAndAnimations(simDt, rawDt);
    this.updateTargets(simDt);
    this.updateFx(simDt);
    this.updateDrill(rawDt);

    // Smoothly animate all Interactive Doors + auto-disable their collider once swung open!
    this.updateInteractiveDoors(simDt);

    // Flicker warm gang burn-barrel firelight + abandoned interior fluorescent tubes + lazy sunlit dust motes!
    this.world.compound.burnLight.intensity =
      3.1 + Math.sin(this.rawTime * 11.4) * 0.45 + Math.cos(this.rawTime * 19.3) * 0.25;
    this.world.compound.flickerLights.forEach((fl, idx) => {
      const wave = Math.sin(this.rawTime * (13.5 + idx * 4.7)) * Math.sin(this.rawTime * (2.3 + idx * 1.1));
      fl.intensity = wave > 0.86 ? 0.55 : 2.15;
    });
    this.world.compound.dustMotes.position.y = Math.sin(this.rawTime * 0.35) * 0.28;
    this.world.compound.dustMotes.rotation.y = this.rawTime * 0.015;

    // Player health auto-regeneration & damage flash fade
    this.timeSinceDamaged += rawDt;
    if (this.timeSinceDamaged > 4.0 && this.playerHp < 100 && this.horde.phase !== 'gameover') {
      this.playerHp = Math.min(100, this.playerHp + rawDt * 18);
    }
    const lowHpPulse = this.playerHp < 38 ? ((38 - this.playerHp) / 38) * (0.35 + Math.sin(this.rawTime * 6.5) * 0.14) : 0;
    this.damagePulse = Math.max(lowHpPulse, this.damagePulse - rawDt * 1.9);

    // Update Smart Tactical Bot Squad (passes Player Crouch state so ducking behind waist-high cover genuinely hides you!)
    const playerInCompound = this.playerPos.x < 90;
    const playerCrouching = this.crouchBlend > 0.5;
    this.botSquad.update(
      simDt,
      this.worldCamera.position,
      this.playerHp > 0,
      playerInCompound,
      playerCrouching,
      (ev) => {
        this.spawnEnemyTracer(ev.muzzlePos, ev.targetPos);
        // Enemy bot shots can ALSO shatter breakable windows when bots fire through office glass!
        const bDir = ev.targetPos.clone().sub(ev.muzzlePos);
        const bDist = bDir.length();
        if (bDist > 0.5) {
          bDir.divideScalar(bDist);
          this.raycaster.set(ev.muzzlePos, bDir);
          this.raycaster.far = bDist;
          const bGlass = this.raycaster.intersectObjects(this.world.compound.glassHitMeshes, false);
          for (const gh of bGlass) {
            const gid = gh.object.userData?.glassId as string | undefined;
            const pane = gid ? this.world.compound.glassPanes.find((g) => g.id === gid) : undefined;
            if (pane && !pane.broken) {
              const hitU = gh.uv ? gh.uv.x : 0.5;
              const hitV = gh.uv ? gh.uv.y : 0.5;
              this.damageGlassPane(pane, gh.point, hitU, hitV, bDir, false);
            }
          }
        }
        if (ev.hitPlayer) {
          this.playerHp = Math.max(0, this.playerHp - ev.damage);
          this.timeSinceDamaged = 0;
          this.damagePulse = Math.min(1.0, this.damagePulse + 0.62);
          this.camTrauma = Math.min(1.0, this.camTrauma + 0.36);
          this.adrenaline = Math.min(1.0, this.adrenaline + 0.35);
          soundEngine.playPlayerHit();

          if (this.playerHp <= 0) {
            this.playerHp = 100;
            this.damagePulse = 0.95;
            this.streak = 0;
            this.ammoMap = {
              pistol: WEAPON_SPECS.pistol.magSize,
              rifle: WEAPON_SPECS.rifle.magSize,
              sniper: WEAPON_SPECS.sniper.magSize,
            };
            this.teleportToZone('compound', false);
            this.lastEventText = 'TERELIMINASI — Respawn Taktis di Halaman Gedung Geng!';
          }
        }
      }
    );

    // ZOMBIE HORDE (World War Z style swarm) — wave director, crowd AI, climbing pyramids
    this.updateHorde(simDt);

    this.updateBodycamOptics(rawDt);

    // =========================================================================
    // JITTER-FREE LIVE 4.7x MAGNIFYING GLASS SNIPER SCOPE RENDER PASS (PIGEON PiP Technique!)
    // Always renders inside the 3D Sniper's glass ocular lens — ZERO broken 2D black mask!
    // =========================================================================
    const sniperGlassAiming =
      this.weaponId === 'sniper' &&
      this.adsBlend > 0.55 &&
      this.animState !== 'bolt_cycle' &&
      this.animState !== 'reloading';

    if (this.weaponId === 'sniper' && this.rigs.sniper.scopeLensUniforms) {
      const lensUni = this.rigs.sniper.scopeLensUniforms;
      lensUni.uAdsBlend.value = this.adsBlend;
      // Subtle realistic optical eye-relief parallax (smooths to dead-center when ADSing!)
      lensUni.uEyeOffset.value.set(
        THREE.MathUtils.clamp(this.swayX * 1.35, -0.075, 0.075),
        THREE.MathUtils.clamp(this.swayY * 1.35, -0.075, 0.075)
      );

      // Stabilized optical axis aligned 100% with the true ballistic barrel (zero footstep bob jitter!)
      const scopeBreath =
        this.adsBlend > 0.4 ? Math.sin(this.rawTime * 1.65) * 0.0018 * (1 - this.crouchBlend * 0.45) : 0;
      this.scopeMagnifierCamera.position.set(
        this.playerPos.x,
        this.playerPos.y + this.landJolt * 0.25,
        this.playerPos.z
      );
      this.scopeMagnifierCamera.rotation.order = 'YXZ';
      this.scopeMagnifierCamera.rotation.y = this.playerYaw + this.freeAimYaw;
      this.scopeMagnifierCamera.rotation.x = THREE.MathUtils.clamp(
        this.playerPitch + this.freeAimPitch + this.camRecoilPitch + scopeBreath,
        -1.38,
        1.38
      );
      this.scopeMagnifierCamera.rotation.z = 0;

      // The PiP lens re-renders the WHOLE world, so only do it while the lens is actually visible (ADS)
      if (this.adsBlend > 0.04) {
        this.renderer.setRenderTarget(this.scopeRenderTarget);
        this.renderer.setClearColor(0xa6daf7, 1);
        this.renderer.clear(true, true, true);
        this.renderer.render(this.worldScene, this.scopeMagnifierCamera);
        this.renderer.setRenderTarget(null);
      }
    }

    // Compute AAA Live Screen-Space Sun Corona & Real Occlusion Check (blooms cleanly when sun peeks over roofs/windows!)
    this.updateSunFlareProjection(rawDt);

    // Unified Dual-Target GPU Bodycam Render Pass — 3D Sniper & Magnifying Glass ALWAYS stay visible!
    const fs = this.filterSettings;
    const adsDampOptics = THREE.MathUtils.lerp(1.0, sniperGlassAiming ? 0.25 : 0.48, this.adsBlend);
    this.bodycamPost.render(
      this.renderer,
      this.worldScene,
      this.worldCamera,
      this.vmScene,
      this.vmCamera,
      true,
      {
        enabled: this.bodycamEnabled,
        time: this.rawTime,
        exposure: this.exposureGain,
        brightness: fs.brightness,
        glareStrength: this.glareStrength,
        focusDistance: this.currentFocusDist,
        dofStrength: this.bodycamEnabled ? fs.blurDof * (sniperGlassAiming ? 0.25 : 1.0) : 0.0,
        fisheyeStrength: fs.fisheye * adsDampOptics,
        blackFrameStrength: fs.blackFrame * THREE.MathUtils.lerp(1.0, 0.55, this.adsBlend),
        chromaticStrength: fs.chromaticGrain * adsDampOptics,
        grainStrength: fs.chromaticGrain,
        vignetteStrength: fs.blackFrame,
        damagePulse: this.damagePulse,
        sunScreenPos: this.sunScreenPos,
        sunFlareStrength: sniperGlassAiming ? 0.0 : this.sunFlareStrength,
        cameraNear: this.worldCamera.near,
        cameraFar: this.worldCamera.far,
        sniperScoped: false,
      }
    );

    this.lastDraws = this.renderer.info.render.calls;
    this.lastTris = this.renderer.info.render.triangles;

    // Update live sniper laser rangefinder distance while aiming through the 3D glass scope
    if (sniperGlassAiming) {
      const aimDir = this.getTrueAimDirection(this.tmpV2);
      this.raycaster.set(this.worldCamera.position, aimDir);
      this.raycaster.far = 360;
      const bHits = this.botSquad.enabled ? this.raycaster.intersectObjects(this.botSquad.hitMeshes, false) : [];
      const tHits = this.raycaster.intersectObjects(this.world.hitMeshes, false);
      if (bHits.length > 0) {
        this.scopeRangeMeters = Math.round(bHits[0].distance);
      } else if (tHits.length > 0) {
        this.scopeRangeMeters = Math.round(tHits[0].distance);
      } else {
        const env = this.raycaster.intersectObjects(this.worldScene.children, true);
        const h = env.find((e) => e.distance > 2 && e.distance < 350 && !e.object.userData?.isFx);
        this.scopeRangeMeters = h ? Math.round(h.distance) : null;
      }
    } else {
      this.scopeRangeMeters = null;
    }

    this.hudEmitAcc += rawDt;
    const emitEvery = this.showUi ? (this.showMechanics ? 0.033 : 0.05) : this.horde.active || this.showFps ? 0.1 : 0.25;
    if (this.hudEmitAcc >= emitEvery) {
      this.hudEmitAcc = 0;
      this.emitHud();
    }
  };

  /**
   * Generates a real Physically-Based HDR Sky/Sun/Ground Studio IBL Cubemap via THREE.PMREMGenerator!
   * This is the #1 AAA lighting secret: gives authentic cool sky reflections, warm golden specular highlights,
   * and rich grounded ambient bounce on gunmetal, wooden doors, glass windows, concrete & smooth enemy jackets!
   */
  private buildProceduralHdrEnvironment() {
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    pmrem.compileEquirectangularShader();

    const envScene = new THREE.Scene();
    const sunDir = this.world.sunDirection.clone().normalize();
    const skyEnvMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      uniforms: {
        uSunDir: { value: sunDir },
      },
      vertexShader: /* glsl */ `
        varying vec3 vDir;
        void main() {
          vDir = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform vec3 uSunDir;
        varying vec3 vDir;
        void main() {
          vec3 d = normalize(vDir);
          float up = clamp(d.y, 0.0, 1.0);
          vec3 sky = mix(vec3(0.76, 0.84, 0.90), vec3(0.18, 0.48, 0.88), smoothstep(0.0, 0.72, up));
          vec3 ground = vec3(0.28, 0.25, 0.22);
          vec3 col = d.y >= 0.0 ? sky : mix(vec3(0.55, 0.54, 0.52), ground, smoothstep(0.0, -0.45, d.y));
          float s = max(0.0, dot(d, uSunDir));
          col += vec3(1.4, 1.15, 0.78) * pow(s, 8.0) * 0.65;
          col += vec3(4.5, 3.8, 2.7) * pow(s, 96.0);
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    const envDome = new THREE.Mesh(new THREE.SphereGeometry(40, 24, 16), skyEnvMat);
    envScene.add(envDome);

    this.envRT = pmrem.fromScene(envScene, 0.035);
    this.worldScene.environment = this.envRT.texture;
    this.worldScene.environmentIntensity = 0.58;

    envDome.geometry.dispose();
    skyEnvMat.dispose();
    pmrem.dispose();
  }

  private updateSunFlareProjection(dt: number) {
    const camDir = this.worldCamera.getWorldDirection(this.tmpV1);
    const sunDot = camDir.dot(this.world.sunDirection);

    if (sunDot > 0.25) {
      // Project distant sun point into screen UV [0..1]
      const farSun = this.worldCamera.position.clone().addScaledVector(this.world.sunDirection, 300);
      farSun.project(this.worldCamera);
      this.sunScreenPos.set(farSun.x * 0.5 + 0.5, farSun.y * 0.5 + 0.5);

      // Periodic real raycast check against building roof & walls so sun flare never shines through solid concrete!
      this.sunCheckAcc += dt;
      if (this.sunCheckAcc >= 0.12) {
        this.sunCheckAcc = 0;
        this.raycaster.set(this.worldCamera.position, this.world.sunDirection);
        this.raycaster.far = 160;
        const blockers = this.raycaster.intersectObjects(this.world.compound.losMeshes, false);
        this.sunUnobstructed = blockers.length === 0 ? 1.0 : 0.0;
      }

      const angleFactor = THREE.MathUtils.smoothstep(sunDot, 0.35, 0.92);
      const targetFlare = angleFactor * this.sunUnobstructed * (1 - this.indoorDarkness * 0.45);
      this.sunFlareStrength = THREE.MathUtils.lerp(this.sunFlareStrength, targetFlare, Math.min(1, dt * 8.5));
    } else {
      this.sunFlareStrength = THREE.MathUtils.lerp(this.sunFlareStrength, 0, Math.min(1, dt * 9.0));
    }
  }

  private updateBodycamOptics(dt: number) {
    // 1. AGGRESSIVE AUTO-EXPOSURE (Low-Dynamic-Range Bodycam Sensor Simulation)
    this.indoorDarkness = this.world.getIndoorDarkness(
      this.playerPos.x,
      this.playerPos.y - this.smoothCamHeight,
      this.playerPos.z
    );

    // Smoothly dim sculptural viewmodel lights & IBL inside dark concrete rooms while keeping outdoor sunlight crisp!
    const vmLightScale = THREE.MathUtils.lerp(1.0, 0.28, this.indoorDarkness);
    this.vmHemiLight.intensity = 0.56 * vmLightScale;
    this.vmSunLight.intensity = 1.02 * THREE.MathUtils.lerp(1.0, 0.14, this.indoorDarkness);
    this.vmScene.environmentIntensity = THREE.MathUtils.lerp(0.42, 0.12, this.indoorDarkness);

    const lookDir = this.worldCamera.getWorldDirection(this.tmpV1);
    const skyUp = THREE.MathUtils.smoothstep(lookDir.y, -0.06, 0.56);
    const sunDot = Math.max(0, lookDir.dot(this.world.sunDirection));
    const sunGlare = Math.pow(sunDot, 3.5);

    // Sample center ray every ~40ms for both Dynamic Autofocus DoF AND Doorway Brightness!
    this.focusSampleAcc += dt;
    let lookingOutBrightDoorway = 0;
    if (this.focusSampleAcc >= 0.09) {
      this.focusSampleAcc = 0;
      const aimDir = this.getTrueAimDirection(this.tmpV2);
      this.raycaster.set(this.worldCamera.position, aimDir);
      this.raycaster.far = 260;

      const tHits = this.raycaster.intersectObjects(this.world.hitMeshes, false);
      const validT = tHits.find((h) => {
        const tid = h.object.userData?.targetId as string | undefined;
        const ent = tid ? this.world.targets.find((t) => t.id === tid) : undefined;
        return ent ? ent.alive && ent.group.visible : false;
      });
      const envHits = this.raycaster.intersectObjects(this.worldScene.children, true);
      const validE = envHits.find((h) => !h.object.userData?.isFx && !h.object.userData?.targetId && h.distance > 0.35 && h.distance < 250);

      let dist = 160;
      if (validT && (!validE || validT.distance <= validE.distance)) {
        dist = validT.distance;
      } else if (validE) {
        dist = validE.distance;
      }

      // If reloading (Gambar 1) or inspecting weapon, camera autofocuses tightly onto the hands & gun!
      if (this.animState === 'reloading' || this.animState === 'inspecting') {
        this.targetFocusDist = 0.72;
      } else if (this.animState === 'bolt_cycle') {
        this.targetFocusDist = 1.15;
      } else {
        this.targetFocusDist = THREE.MathUtils.clamp(dist, 0.85, 190);
      }

      // Detect looking out of the dark room through the doorway into blazing sunlit courtyard!
      if (this.indoorDarkness > 0.35 && dist > 8.5) {
        lookingOutBrightDoorway = THREE.MathUtils.clamp((dist - 7.5) / 14, 0, 1);
      }
    }

    // Smooth camera autofocus motor with slight realistic focus travel
    const focusSpeed = this.animState === 'reloading' ? 9.0 : 5.4;
    this.currentFocusDist = THREE.MathUtils.lerp(
      this.currentFocusDist,
      this.targetFocusDist,
      Math.min(1, dt * focusSpeed)
    );

    // Combine ambient outdoor brightness + dark room drop + sky glare + doorway spill + muzzle flash!
    const outdoorBase = 1.06 + skyUp * 0.78 + sunGlare * 1.15;
    const indoorBase = 0.26 + lookingOutBrightDoorway * 1.3;
    const muzzleSpike = this.muzzleFlashTimer > 0 ? 1.55 : 0.0;
    const targetLuminance = THREE.MathUtils.lerp(outdoorBase, indoorBase, this.indoorDarkness) + muzzleSpike;

    // Asymmetric Iris Adaptation:
    // Moving bright -> dark takes ~0.75s (feels dark before ISO ramps up!)
    // Moving dark -> bright or looking at sun/sky takes ~0.4s (blinding silau glare before iris clamps down!)
    const adaptRate = targetLuminance > this.adaptedLuminance ? 2.5 : 1.35;
    this.adaptedLuminance = THREE.MathUtils.lerp(
      this.adaptedLuminance,
      targetLuminance,
      Math.min(1, dt * adaptRate)
    );

    // Bright sunlit daylight baseline matching previous brightness (~1.06) -> dark indoor ISO boost up to 2.55x -> sun clamp 0.62x!
    this.exposureGain = THREE.MathUtils.clamp(1.08 / Math.max(0.22, this.adaptedLuminance), 0.62, 2.55);

    // Clean halation glare ONLY when staring at sun/sky, doorway brightness transition, or firing muzzle flash!
    const suddenBright = Math.max(0, targetLuminance - this.adaptedLuminance) * 1.2;
    const targetGlare = Math.min(
      1.6,
      skyUp * 0.28 + sunGlare * 0.78 + lookingOutBrightDoorway * 0.9 + suddenBright
    );
    this.glareStrength = THREE.MathUtils.lerp(this.glareStrength, targetGlare, Math.min(1, dt * 5.2));
  }

  private updatePlayer(dt: number) {
    // Full-auto continuous fire check for Rifle!
    if (
      this.mouseDownLeft &&
      this.isPointerLocked &&
      WEAPON_SPECS[this.weaponId].fireMode === 'FULL-AUTO'
    ) {
      this.tryFire();
    }

    // Elastic Chest Body Follow behind Free-Aim Weapon Direction!
    // Keeps total world aim (playerYaw + freeAimYaw) 100% invariant while chest swings organically behind the hands!
    if (this.bodycamEnabled) {
      // Snap free-aim swiftly to optical axis when ADSing Sniper glass scope so eye stays dead-center!
      const isSniperGlass = this.weaponId === 'sniper' && this.adsBlend > 0.35;
      const followRate = isSniperGlass ? 18.0 : this.adsBlend > 0.5 ? 11.5 : 3.2 + this.moveSpeedNorm * 2.8;
      const chaseYaw = this.freeAimYaw * Math.min(1, dt * followRate);
      const chasePitch = this.freeAimPitch * Math.min(1, dt * followRate);
      this.playerYaw += chaseYaw;
      this.freeAimYaw -= chaseYaw;
      this.playerPitch = THREE.MathUtils.clamp(this.playerPitch + chasePitch, -1.28, 1.28);
      this.freeAimPitch -= chasePitch;
    }

    // Camera recoil, trauma, adrenaline & turn-banking decay
    this.camRecoilPitch += this.camRecoilVel;
    this.camRecoilVel *= Math.exp(-24 * dt);
    this.camRecoilPitch *= Math.exp(-9.0 * dt);
    this.camTrauma = Math.max(0, this.camTrauma - dt * 1.85);
    this.turnRoll *= Math.exp(-7.5 * dt);

    // WASD Movement aligned with chest body yaw
    const forward = new THREE.Vector3(-Math.sin(this.playerYaw), 0, -Math.cos(this.playerYaw));
    const right = new THREE.Vector3(Math.cos(this.playerYaw), 0, -Math.sin(this.playerYaw));
    const wish = new THREE.Vector3();

    if (this.isPointerLocked) {
      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) wish.add(forward);
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) wish.sub(forward);
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) wish.add(right);
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) wish.sub(right);
    }

    const isMoving = wish.lengthSq() > 0;
    const wantSprintRaw = isMoving && this.keys.has('ShiftLeft') && this.adsBlend < 0.25 && this.isGrounded;
    // Sprinting or jumping smoothly stands up from toggle-crouch (standard AAA tactical FPS feel!)
    if (wantSprintRaw && this.crouchToggle) {
      this.crouchToggle = false;
    }

    const isCrouching =
      (this.crouchToggle || (this.isPointerLocked && this.keys.has('ControlLeft'))) && !wantSprintRaw;
    this.crouchBlend = THREE.MathUtils.lerp(this.crouchBlend, isCrouching ? 1 : 0, 1 - Math.exp(-13.5 * dt));

    const isSprinting = wantSprintRaw && this.crouchBlend < 0.35;
    this.sprintBlend = THREE.MathUtils.lerp(this.sprintBlend, isSprinting ? 1 : 0, 1 - Math.exp(-8.5 * dt));

    if (isSprinting) {
      this.adrenaline = Math.min(1.0, this.adrenaline + dt * 0.32);
    } else {
      this.adrenaline = Math.max(0.0, this.adrenaline - dt * 0.26);
    }

    // Tactical speed tuning: Crouch = stealthy 3.55 m/s, Walk = 6.0 m/s, Sprint = crisp 9.2 m/s!
    const adsSlow = THREE.MathUtils.lerp(1.0, 0.56, this.adsBlend);
    const crouchSlow = THREE.MathUtils.lerp(1.0, 0.58, this.crouchBlend);
    const sprintBoost = THREE.MathUtils.lerp(1.0, 1.52, this.sprintBlend);
    const moveSpeed = 6.0 * adsSlow * crouchSlow * sprintBoost;

    if (isMoving) {
      wish.normalize().multiplyScalar(moveSpeed);
      this.playerVel.x = THREE.MathUtils.lerp(this.playerVel.x, wish.x, Math.min(1, dt * 11.5));
      this.playerVel.z = THREE.MathUtils.lerp(this.playerVel.z, wish.z, Math.min(1, dt * 11.5));
    } else {
      this.playerVel.x *= Math.exp(-11.5 * dt);
      this.playerVel.z *= Math.exp(-11.5 * dt);
    }

    // Jump (automatically uncrouches cleanly + crisp push-off audio!)
    if (this.isPointerLocked && this.keys.has('Space') && this.isGrounded) {
      this.crouchToggle = false;
      this.playerVel.y = 6.1;
      this.isGrounded = false;
      soundEngine.playJump(this.getCurrentFootSurface());
    }

    // Gravity
    this.playerVel.y -= 17.5 * dt;

    // Map-aware horizontal bounds (Compound around X=0 vs Classic Range around X=+180)
    const inCompound = this.playerPos.x < 90;
    const minBoundX = inCompound ? -25.1 : 154;
    const maxBoundX = inCompound ? 25.1 : 202;
    const minBoundZ = inCompound ? -17.3 : -101;
    const maxBoundZ = inCompound ? 29.1 : 14;

    const nextX = THREE.MathUtils.clamp(this.playerPos.x + this.playerVel.x * dt, minBoundX, maxBoundX);
    const nextZ = THREE.MathUtils.clamp(this.playerPos.z + this.playerVel.z * dt, minBoundZ, maxBoundZ);

    // Smooth chest-camera height interpolation between Standing (1.34m) & Crouched (0.80m)!
    const prevCamHeight = this.smoothCamHeight;
    const targetCamHeight = THREE.MathUtils.lerp(CHEST_CAMERA_HEIGHT, CROUCH_CAMERA_HEIGHT, this.crouchBlend);
    this.smoothCamHeight = THREE.MathUtils.lerp(this.smoothCamHeight, targetCamHeight, 1 - Math.exp(-14.0 * dt));

    // True 3D AABB Vertical & Horizontal Collision (crouch-aware body height!)
    const footY = this.playerPos.y - prevCamHeight;
    const bodyLowY = footY + 0.34;
    const bodyHighY = footY + THREE.MathUtils.lerp(1.56, 1.04, this.crouchBlend);

    // Auto-shoulder-push closed doors open smoothly when walking/sprinting right into them!
    if (isMoving && inCompound) {
      const pFloor: 0 | 1 = footY > 2.4 ? 1 : 0;
      for (const door of this.world.compound.doors) {
        if (door.isOpen || door.floor !== pFloor) continue;
        if (Math.hypot(nextX - door.center.x, nextZ - door.center.z) < 1.35) {
          door.isOpen = true;
          soundEngine.playDoorToggle(true, 0.8);
        }
      }
    }

    let blockedX = false;
    let blockedZ = false;
    for (const c of this.world.colliders3D) {
      if (c.disabled) continue;
      if (bodyHighY <= c.minY || bodyLowY >= c.maxY) continue;
      if (nextX > c.minX && nextX < c.maxX && this.playerPos.z > c.minZ && this.playerPos.z < c.maxZ) {
        blockedX = true;
      }
      if (this.playerPos.x > c.minX && this.playerPos.x < c.maxX && nextZ > c.minZ && nextZ < c.maxZ) {
        blockedZ = true;
      }
    }
    if (!blockedX) this.playerPos.x = nextX;
    if (!blockedZ) this.playerPos.z = nextZ;

    this.wasGrounded = this.isGrounded;
    const nextFootY = footY + this.playerVel.y * dt;
    const floorHeight = this.world.getGroundHeight(this.playerPos.x, this.playerPos.z, footY);
    if (nextFootY <= floorHeight && this.playerVel.y <= 0) {
      if (!this.wasGrounded && this.playerVel.y < -2.0) {
        // Cushioned knee-compression landing dip + realistic two-boot landing thud!
        const impact = Math.min(1.45, Math.abs(this.playerVel.y) / 6.2);
        this.landJoltVel = -2.2 * impact;
        this.camTrauma = Math.min(1.0, this.camTrauma + 0.22 * impact);
        soundEngine.playLand(impact, this.getCurrentFootSurface(), this.indoorDarkness);
      }
      this.playerPos.y = floorHeight + this.smoothCamHeight;
      this.playerVel.y = 0;
      this.isGrounded = true;
    } else {
      this.playerPos.y = nextFootY + this.smoothCamHeight;
      if (this.isGrounded && nextFootY - floorHeight > 0.28) {
        this.isGrounded = false;
      }
    }

    // Smooth knee-compression landing spring
    this.landJoltVel += (-68 * this.landJolt - 11.5 * this.landJoltVel) * dt;
    this.landJolt += this.landJoltVel * dt;

    // Active zone indicator
    if (inCompound) this.zoneId = 'compound';
    else if (this.playerPos.z > -27) this.zoneId = 'courtyard';
    else if (this.playerPos.z > -86) this.zoneId = 'alpine';
    else this.zoneId = 'ridge';

    // Distance-Driven Natural Long-Stride Cadence + Synchronized Left/Right Footstep Audio!
    const horizSpeed = Math.hypot(this.playerVel.x, this.playerVel.z);
    this.moveSpeedNorm = THREE.MathUtils.clamp(horizSpeed / 6.2, 0, 1.45);
    if (this.isGrounded && horizSpeed > 0.35) {
      const stepMeters = isCrouching ? 1.45 : THREE.MathUtils.lerp(1.95, 2.75, this.sprintBlend);
      this.moveBobTime += (horizSpeed * dt * Math.PI) / stepMeters;

      const stepIdx = Math.floor(this.moveBobTime / Math.PI);
      if (stepIdx > this.lastFootstepIdx) {
        this.lastFootstepIdx = stepIdx;
        const stance: FootstepStance = isCrouching
          ? 'crouch'
          : this.sprintBlend > 0.42
            ? 'sprint'
            : 'walk';
        soundEngine.playFootstep(
          stance,
          stepIdx % 2 === 0 ? 'left' : 'right',
          this.getCurrentFootSurface(),
          this.indoorDarkness
        );
      }
    } else if (this.isGrounded) {
      // Prime stride phase cleanly when stopped so the very first step on WASD triggers crisply!
      const curBase = Math.floor(this.moveBobTime / Math.PI);
      this.lastFootstepIdx = curBase;
      const primedPhase = curBase * Math.PI + Math.PI * 0.72;
      if (this.moveBobTime < primedPhase) {
        this.moveBobTime = THREE.MathUtils.lerp(this.moveBobTime, primedPhase, Math.min(1, dt * 8));
      }
    }

    // =========================================================================
    // SILKY-SMOOTH C-INFINITY GIMBAL RUNNING CAMERA (Default Comfortable & Perfect!)
    // Seamlessly scales up with `filterSettings.cameraShake` (0.14 default -> 1.0 Wild Panic)
    // =========================================================================
    const t = this.rawTime;
    const adsDamp = THREE.MathUtils.lerp(1.0, 0.16, this.adsBlend);
    const bcScale = this.bodycamEnabled ? 1.0 : 0.25;
    const shakeFactor = THREE.MathUtils.lerp(0.24, 1.0, this.filterSettings.cameraShake);
    const moveWeight = this.isGrounded ? THREE.MathUtils.clamp(horizSpeed / 5.2, 0, 1.15) : 0.08;

    // 1. Subtle Organic Chest Breathing (extra steady while crouched or ADSing!)
    const breathAmp = (1.0 + this.adrenaline * 0.55) * (1 - this.crouchBlend * 0.3) * adsDamp * bcScale * shakeFactor;
    const breathPitch = (Math.sin(t * 1.55) * 0.0028 + Math.cos(t * 2.4) * 0.0012) * breathAmp;
    const breathYaw = (Math.cos(t * 1.15) * 0.0024 + Math.sin(t * 1.9) * 0.001) * breathAmp;
    const breathRoll = Math.sin(t * 1.32) * Math.cos(t * 0.85) * 0.0052 * breathAmp;

    // 2. Silky C-Infinity Sinusoidal Stride Glide ((1 - cos(2*phase))*0.5 has zero sharp corners!)
    const smoothWaveY = (1 - Math.cos(this.moveBobTime * 2)) * 0.5;
    const rawBobY =
      -smoothWaveY *
      THREE.MathUtils.lerp(0.011, 0.022 + this.filterSettings.cameraShake * 0.042, this.sprintBlend) *
      moveWeight *
      adsDamp *
      bcScale;
    const rawBobX =
      Math.sin(this.moveBobTime) *
      THREE.MathUtils.lerp(0.007, 0.015 + this.filterSettings.cameraShake * 0.026, this.sprintBlend) *
      moveWeight *
      adsDamp *
      bcScale;
    const rawBobPitch =
      Math.sin(this.moveBobTime * 2 - 0.5) *
        THREE.MathUtils.lerp(0.0018, 0.0048 + this.filterSettings.cameraShake * 0.018, this.sprintBlend) *
        moveWeight *
        adsDamp *
        bcScale -
      this.sprintBlend * 0.01;

    const camSmoothAlpha = 1 - Math.exp(-14.5 * dt);
    this.smoothCamBobX = THREE.MathUtils.lerp(this.smoothCamBobX, rawBobX, camSmoothAlpha);
    this.smoothCamBobY = THREE.MathUtils.lerp(this.smoothCamBobY, rawBobY, camSmoothAlpha);
    this.smoothCamPitch = THREE.MathUtils.lerp(this.smoothCamPitch, rawBobPitch, camSmoothAlpha);

    const strideRoll =
      Math.sin(this.moveBobTime) *
      THREE.MathUtils.lerp(0.0035, 0.0085 + this.filterSettings.cameraShake * 0.032, this.sprintBlend) *
      moveWeight *
      adsDamp *
      bcScale;

    // Subtle crisp strafe lean & smoothed chest turn-banking roll
    const strafeInput =
      this.isPointerLocked
        ? (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) -
          (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0)
        : 0;
    const strafeLean = -strafeInput * 0.014 * adsDamp * bcScale;
    const targetRollZ =
      breathRoll + strideRoll + strafeLean + this.turnRoll * (0.45 + this.filterSettings.cameraShake * 0.55) * adsDamp;
    this.smoothRollZ = THREE.MathUtils.lerp(this.smoothRollZ, targetRollZ, 1 - Math.exp(-11.5 * dt));

    // 3. Controlled Firing & Impact Trauma (sharp punch without nausea)
    const traumaSq = this.camTrauma * this.camTrauma * bcScale * (0.45 + this.filterSettings.cameraShake * 0.55);
    const traumaPitch = Math.sin(t * 48.0) * 0.024 * traumaSq;
    const traumaYaw = Math.cos(t * 42.0) * 0.018 * traumaSq;
    const traumaRoll = Math.sin(t * 54.0) * 0.034 * traumaSq;

    const lateralOffsetX = Math.cos(this.playerYaw) * this.smoothCamBobX;
    const lateralOffsetZ = -Math.sin(this.playerYaw) * this.smoothCamBobX;

    this.worldCamera.position.set(
      this.playerPos.x + lateralOffsetX,
      this.playerPos.y + this.smoothCamBobY + this.landJolt * 0.065,
      this.playerPos.z + lateralOffsetZ
    );

    this.worldCamera.rotation.order = 'YXZ';
    this.worldCamera.rotation.y = this.playerYaw + breathYaw + traumaYaw;
    this.worldCamera.rotation.x = THREE.MathUtils.clamp(
      this.playerPitch + this.camRecoilPitch + breathPitch + this.smoothCamPitch + traumaPitch + this.landJolt * 0.055,
      -1.38,
      1.38
    );
    this.worldCamera.rotation.z = this.smoothRollZ + traumaRoll;

    // Project live Free-Aim point into screen space so optional HUD crosshair tracks true barrel angle!
    this.worldCamera.updateMatrixWorld();
    const aimPt = this.worldCamera.position
      .clone()
      .addScaledVector(this.getTrueAimDirection(this.tmpV3), 50);
    aimPt.project(this.worldCamera);
    this.freeAimScreenX = aimPt.x * (this.container.clientWidth * 0.5);
    this.freeAimScreenY = -aimPt.y * (this.container.clientHeight * 0.5);
  }

  private updateWeaponStateAndAnimations(simDt: number, rawDt: number) {
    const rig = this.rigs[this.weaponId];
    const spec = WEAPON_SPECS[this.weaponId];

    // Timers
    if (this.fireCooldown > 0) this.fireCooldown = Math.max(0, this.fireCooldown - simDt);
    if (this.triggerPullTimer > 0) this.triggerPullTimer = Math.max(0, this.triggerPullTimer - simDt);
    if (this.hitFeedbackTimer > 0) {
      this.hitFeedbackTimer -= rawDt;
      if (this.hitFeedbackTimer <= 0) this.hitFeedback = null;
    }

    // Telemetry glow pulses fade smoothly
    this.pulseMuzzle = Math.max(0, this.pulseMuzzle - rawDt * 2.2);
    this.pulseEjection = Math.max(0, this.pulseEjection - rawDt * 1.9);
    this.pulseAction = Math.max(0, this.pulseAction - rawDt * 1.9);
    this.pulseMag = Math.max(0, this.pulseMag - rawDt * 1.4);

    // Muzzle flash timer
    if (this.muzzleFlashTimer > 0) {
      this.muzzleFlashTimer -= simDt;
      if (this.muzzleFlashTimer <= 0) {
        rig.muzzleFlash.visible = false;
        this.vmMuzzleLight.intensity = 0;
      }
    }

    // Equip timer
    if (this.animState === 'equipping') {
      this.equipTimer -= simDt;
      if (this.equipTimer <= 0) {
        this.animState = 'ready';
      }
    }

    // Inspect timer (shows Gambar 1 showcase angle smoothly!)
    if (this.animState === 'inspecting') {
      this.inspectTimer -= simDt;
      if (this.inspectTimer <= 0) {
        this.animState = 'ready';
      }
    }

    // ADS blend (Right Click hold or Q toggle — paused during reload/bolt/inspect)
    const wantAds =
      (this.mouseDownRight || this.adsToggle) &&
      this.animState !== 'reloading' &&
      this.animState !== 'bolt_cycle' &&
      this.animState !== 'inspecting' &&
      this.animState !== 'equipping';
    const adsRate = this.weaponId === 'sniper' ? 9.5 : 12.0;
    this.adsBlend = THREE.MathUtils.lerp(this.adsBlend, wantAds ? 1 : 0, Math.min(1, rawDt * adsRate));

    if (this.animState === 'ready' || this.animState === 'ads') {
      this.animState = this.adsBlend > 0.55 ? 'ads' : 'ready';
    }

    // Smooth Wide-Angle Bodycam FOV + Silky Sprint FOV Surge (+8°) + Crisp ADS Peripheral Zoom!
    const baseFov = (this.bodycamEnabled ? BODYCAM_BASE_FOV : 72) + this.sprintBlend * 7.5;
    const targetFov = THREE.MathUtils.lerp(baseFov, spec.adsFov, this.adsBlend);
    if (Math.abs(this.worldCamera.fov - targetFov) > 0.04) {
      this.worldCamera.fov = THREE.MathUtils.lerp(
        this.worldCamera.fov,
        targetFov,
        1 - Math.exp(-12.5 * rawDt)
      );
      this.worldCamera.updateProjectionMatrix();
    }
    // Sniper narrows vmCamera slightly on ADS so the 3D live magnifying glass lens fills a generous crisp sight picture!
    const adsVmFov = this.weaponId === 'sniper' ? 46 : 54;
    const targetVmFov = THREE.MathUtils.lerp(this.bodycamEnabled ? BODYCAM_VM_FOV : 56, adsVmFov, this.adsBlend);
    if (Math.abs(this.vmCamera.fov - targetVmFov) > 0.04) {
      this.vmCamera.fov = THREE.MathUtils.lerp(this.vmCamera.fov, targetVmFov, 1 - Math.exp(-13 * rawDt));
      this.vmCamera.updateProjectionMatrix();
    }

    // Reset arm/mag/bolt local offsets before writing current frame's procedural pose
    this.resetRigAnimatedParts(rig);

    // =========================================================================
    // 1. RECOIL SPRING RECOVERY & MECHANICAL BLOWBACK (Slide / Bolt / Trigger)
    // =========================================================================
    const recDecay = this.weaponId === 'sniper' ? 6.2 : this.weaponId === 'rifle' ? 14.5 : 13.0;
    this.recoilPosZ *= Math.exp(-recDecay * simDt);
    this.recoilRotX *= Math.exp(-recDecay * simDt);
    this.recoilRotY *= Math.exp(-recDecay * 1.1 * simDt);
    this.recoilRotZ *= Math.exp(-recDecay * 1.1 * simDt);
    this.spreadBloom = Math.max(0, this.spreadBloom - simDt * 2.4);

    // Trigger finger squeeze animation
    if (rig.trigger) {
      rig.trigger.rotation.x = this.triggerPullTimer > 0 ? -0.55 : 0;
    }

    // PISTOL: Slide blowback + Hammer drop + Empty Mag Slide Lock-Back!
    if (this.weaponId === 'pistol' && rig.slide && rig.hammer) {
      this.slideKick = Math.max(0, this.slideKick - simDt * 12.5);
      const lockedBack = this.ammoMap.pistol === 0 && this.animState !== 'reloading';
      const slideBackAmount = lockedBack ? 0.92 : Math.sin(this.slideKick * Math.PI);
      rig.slide.position.z = slideBackAmount * 0.064;
      // Hammer snaps forward on ignition then cocks back as slide travels rearward
      rig.hammer.rotation.x = this.slideKick > 0.72 ? -0.65 : slideBackAmount * 0.42;
    }

    // RIFLE: Hinged Dust Cover flips open + Rapid Reciprocating Bolt Carrier!
    if (this.weaponId === 'rifle' && rig.bolt && rig.dustCover) {
      this.rifleBoltKick = Math.max(0, this.rifleBoltKick - simDt * 18.0);
      const boltTravel = Math.sin(this.rifleBoltKick * Math.PI);
      rig.bolt.position.z = boltTravel * 0.072;
      rig.dustCover.rotation.z = this.rifleDustCoverOpen ? -2.35 : 0;
    }

    // =========================================================================
    // 2. SNIPER AUTHENTIC BOLT-ACTION CYCLE (Right hand lifts, pulls back -> ejects .338 shell!)
    // =========================================================================
    if (this.animState === 'bolt_cycle' && this.weaponId === 'sniper' && rig.bolt && rig.boltHandle) {
      this.boltTimer += simDt;
      const p = THREE.MathUtils.clamp(this.boltTimer / this.boltDuration, 0, 1);
      this.pulseAction = 1.0;

      // Stage audio & EXACT shell ejection on bolt pull-back!
      if (p >= 0.06 && !this.boltStageTriggered.has('up')) {
        this.boltStageTriggered.add('up');
        soundEngine.playReloadStep('bolt_up');
      }
      if (p >= 0.24 && !this.boltStageTriggered.has('back')) {
        this.boltStageTriggered.add('back');
        soundEngine.playReloadStep('bolt_back');
      }
      if (p >= 0.43 && !this.boltStageTriggered.has('eject')) {
        this.boltStageTriggered.add('eject');
        // EXACT MOMENT THE .338 BRASS CASING FLIES OUT OF THE BOLT EJECTION PORT!
        this.spawnShellCasing('sniper');
        this.pulseEjection = 1.0;
        this.lastEventText =
          'SNIPER BOLT: Kokang ditarik penuh -> Selongsong panjang .338 keluar dari Ejection Port!';
      }
      if (p >= 0.56 && !this.boltStageTriggered.has('fwd')) {
        this.boltStageTriggered.add('fwd');
        soundEngine.playReloadStep('bolt_fwd');
      }
      if (p >= 0.8 && !this.boltStageTriggered.has('down')) {
        this.boltStageTriggered.add('down');
        soundEngine.playReloadStep('bolt_down');
      }

      // Compute exact Bolt Rotation (lift 62 deg) & Bolt Pull (+Z 0.11m)
      let lift = 0;
      let pull = 0;
      let handOnBolt = 0;
      if (p < 0.14) {
        handOnBolt = p / 0.14;
      } else if (p < 0.26) {
        handOnBolt = 1;
        lift = (p - 0.14) / 0.12;
      } else if (p < 0.48) {
        handOnBolt = 1;
        lift = 1;
        pull = (p - 0.26) / 0.22;
      } else if (p < 0.72) {
        handOnBolt = 1;
        lift = 1;
        pull = 1 - (p - 0.48) / 0.24;
      } else if (p < 0.86) {
        handOnBolt = 1;
        lift = 1 - (p - 0.72) / 0.14;
      } else {
        handOnBolt = 1 - (p - 0.86) / 0.14;
      }

      rig.boltHandle.rotation.z = lift * 1.08;
      rig.bolt.position.z = -0.02 + pull * 0.112;

      // Animate RIGHT Matte-White Faceted Hand off the pistol grip straight onto the moving Bolt Knob!
      const knobTargetPos = new THREE.Vector3(
        0.098 - lift * 0.022,
        0.012 + lift * 0.052,
        0.055 + pull * 0.112
      );
      const knobTargetRot = new THREE.Euler(0.2, -0.12, -1.05 + lift * 0.38);
      rig.rightArm.position.lerpVectors(rig.rightArmRestPos, knobTargetPos, handOnBolt);
      rig.rightArm.rotation.set(
        THREE.MathUtils.lerp(rig.rightArmRestRot.x, knobTargetRot.x, handOnBolt),
        THREE.MathUtils.lerp(rig.rightArmRestRot.y, knobTargetRot.y, handOnBolt),
        THREE.MathUtils.lerp(rig.rightArmRestRot.z, knobTargetRot.z, handOnBolt)
      );

      if (p >= 1) {
        this.animState = 'ready';
        this.lastEventText = 'SNIPER: Peluru baru masuk ruang bakar — Siap Tembak (Pose Gambar 2)!';
      }
    }

    // =========================================================================
    // 3. AUTHENTIC RELOAD ANIMATIONS IN EXACT GAMBAR 1 CANTED ANGLE!
    // =========================================================================
    if (this.animState === 'reloading') {
      this.reloadTimer += simDt;
      const p = THREE.MathUtils.clamp(this.reloadTimer / this.reloadDuration, 0, 1);
      this.animateWeaponReload(rig, p);
      if (p >= 1) {
        this.ammoMap[this.weaponId] = spec.magSize;
        this.animState = 'ready';
        this.lastEventText = `${spec.label} TERISI PENUH (${spec.magSize}/${spec.magSize}) — Mode Siap Nembak (Gambar 2)!`;
        this.emitHud();
      }
    }

    // =========================================================================
    // 4. TARGET POSE BLENDING (Gambar 2 Ready/ADS <-> Gambar 1 Reload/Inspect!)
    // =========================================================================
    const poses = WEAPON_POSES[this.weaponId];
    let targetPos = this.tmpV1;
    let targetRot = this.tmpEuler;

    if (this.animState === 'reloading' || this.animState === 'inspecting') {
      targetPos.copy(poses.reload.pos);
      targetRot.copy(poses.reload.rot);
      if (this.animState === 'inspecting') {
        // Gentle slow showcase tilt so the player can admire every low-poly polygon facet & white hands!
        const w = Math.sin(this.elapsedTime * 1.9);
        targetRot.y += w * 0.14;
        targetRot.z += w * 0.08;
      }
    } else if (this.animState === 'bolt_cycle') {
      targetPos.copy(poses.bolt.pos);
      targetRot.copy(poses.bolt.rot);
    } else {
      // Smoothly blend Ready (Gambar 2) -> Composed Tactical Sprint Pose -> Pinpoint ADS / 3D Glass Scope!
      this.sprintRaise = THREE.MathUtils.lerp(
        this.sprintRaise,
        this.mouseDownLeft && this.isPointerLocked ? 1 : 0,
        1 - Math.exp(-12 * rawDt)
      );
      const sp = this.sprintBlend * (1 - this.adsBlend) * (1 - this.sprintRaise);
      const basePosX = THREE.MathUtils.lerp(poses.ready.pos.x, poses.sprint.pos.x, sp);
      const basePosY = THREE.MathUtils.lerp(poses.ready.pos.y, poses.sprint.pos.y, sp);
      const basePosZ = THREE.MathUtils.lerp(poses.ready.pos.z, poses.sprint.pos.z, sp);

      const baseRotX = THREE.MathUtils.lerp(poses.ready.rot.x, poses.sprint.rot.x, sp);
      const baseRotY = THREE.MathUtils.lerp(poses.ready.rot.y, poses.sprint.rot.y, sp);
      const baseRotZ = THREE.MathUtils.lerp(poses.ready.rot.z, poses.sprint.rot.z, sp);

      targetPos.set(
        THREE.MathUtils.lerp(basePosX, poses.ads.pos.x, this.adsBlend),
        THREE.MathUtils.lerp(basePosY, poses.ads.pos.y, this.adsBlend),
        THREE.MathUtils.lerp(basePosZ, poses.ads.pos.z, this.adsBlend)
      );
      targetRot.set(
        THREE.MathUtils.lerp(baseRotX, poses.ads.rot.x, this.adsBlend),
        THREE.MathUtils.lerp(baseRotY, poses.ads.rot.y, this.adsBlend),
        THREE.MathUtils.lerp(baseRotZ, poses.ads.rot.z, this.adsBlend)
      );
    }

    const blendSpeed = this.animState === 'reloading' || this.animState === 'bolt_cycle' ? 9.5 : 14.0;
    const vmAlpha = 1 - Math.exp(-blendSpeed * rawDt);
    this.curVmPos.lerp(targetPos, vmAlpha);
    this.curVmRot.x = THREE.MathUtils.lerp(this.curVmRot.x, targetRot.x, vmAlpha);
    this.curVmRot.y = THREE.MathUtils.lerp(this.curVmRot.y, targetRot.y, vmAlpha);
    this.curVmRot.z = THREE.MathUtils.lerp(this.curVmRot.z, targetRot.z, vmAlpha);

    // Silky-Smooth Composed Weapon Sway, Subtle Crouch Tuck, & Rhythmic Tactical Sprint Glide!
    const swayScale = 1 - this.adsBlend * 0.88;
    const crouchSteady = 1 - this.crouchBlend * 0.35;
    this.swayX *= Math.exp(-9.5 * rawDt);
    this.swayY *= Math.exp(-9.5 * rawDt);

    const idleX = Math.cos(this.rawTime * 1.45) * 0.0026 * crouchSteady * swayScale;
    const idleY = Math.sin(this.rawTime * 2.15) * 0.003 * crouchSteady * swayScale;

    // C-infinity smooth figure-8 weapon glide while walking/sprinting (matches comfy running camera!)
    const sprintFactor = this.sprintBlend * (this.animState === 'reloading' ? 0.2 : 1.0);
    const waveY = (1 - Math.cos(this.moveBobTime * 2)) * 0.5;
    const bobX = Math.sin(this.moveBobTime) * (0.0085 + sprintFactor * 0.015) * this.moveSpeedNorm * crouchSteady * swayScale;
    const bobY = -waveY * (0.008 + sprintFactor * 0.013) * this.moveSpeedNorm * crouchSteady * swayScale;

    // Subtle tactical CQB weapon cant when crouched & not ADSing
    const crouchCantZ = -0.055 * this.crouchBlend * swayScale;
    const crouchDropY = -0.008 * this.crouchBlend * swayScale;

    // FREE-AIM DEADZONE: Weapon visibly leads smoothly before chest camera catches up!
    const faScale = 1 - this.adsBlend * 0.72;
    const faPosX = -this.freeAimYaw * 0.24 * faScale;
    const faPosY = this.freeAimPitch * 0.19 * faScale;
    const faRotY = this.freeAimYaw * 1.02 * faScale;
    const faRotX = this.freeAimPitch * 1.0 * faScale;
    const faRotZ = this.freeAimYaw * 0.38 * faScale;

    rig.root.position.set(
      this.curVmPos.x + idleX + bobX + faPosX + this.swayX * 0.52 * swayScale,
      this.curVmPos.y + idleY + bobY + crouchDropY + faPosY + this.swayY * 0.52 * swayScale + this.landJolt * 0.028,
      this.curVmPos.z + this.recoilPosZ
    );
    rig.root.rotation.set(
      this.curVmRot.x + this.recoilRotX + faRotX + this.landJolt * 0.055,
      this.curVmRot.y + this.recoilRotY + faRotY + this.swayX * 1.0 * swayScale,
      this.curVmRot.z + this.recoilRotZ + faRotZ + crouchCantZ - this.swayX * 1.05 * swayScale - Math.sin(this.moveBobTime) * 0.022 * sprintFactor
    );

    // Keep muzzle flash dynamic light right at the weapon's barrel tip
    if (this.vmMuzzleLight.intensity > 0.01) {
      rig.muzzleSocket.updateWorldMatrix(true, false);
      rig.muzzleSocket.getWorldPosition(this.tmpV2);
      this.vmMuzzleLight.position.copy(this.tmpV2);
    }
  }

  private animateWeaponReload(rig: WeaponRig, p: number) {
    if (rig.id === 'pistol') {
      // PISTOL RELOAD (Gambar 1 Canted Pose!):
      // 0.00-0.25: Left hand drops down grabbing mag, mag slides OUT
      // 0.25-0.55: Fresh mag rises smoothly INTO grip
      // 0.55-0.84: Left hand arcs over top of slide, racks slide back & releases!
      // 0.84-1.00: Left hand returns to symmetrical two-handed grip
      if (p >= 0.14 && !this.reloadStageTriggered.has('out')) {
        this.reloadStageTriggered.add('out');
        soundEngine.playReloadStep('mag_out');
        this.pulseMag = 1.0;
      }
      if (p >= 0.48 && !this.reloadStageTriggered.has('in')) {
        this.reloadStageTriggered.add('in');
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.06;
        this.pulseMag = 1.0;
      }
      if (p >= 0.68 && !this.reloadStageTriggered.has('rack')) {
        this.reloadStageTriggered.add('rack');
        soundEngine.playReloadStep('rack');
        this.pulseAction = 1.0;
      }

      if (p < 0.34) {
        const t = THREE.MathUtils.smoothstep(p, 0.0, 0.34);
        rig.mag.position.set(0, rig.magRestPos.y - t * 0.22, rig.magRestPos.z + t * 0.055);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, new THREE.Vector3(-0.06, -0.26, 0.09), t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.85, t);
      } else if (p < 0.58) {
        const t = THREE.MathUtils.smoothstep(p, 0.34, 0.58);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.22, rig.magRestPos.z + (1 - t) * 0.055);
        rig.leftArm.position.lerpVectors(new THREE.Vector3(-0.06, -0.26, 0.09), new THREE.Vector3(-0.032, -0.11, 0.06), t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(1.85, 1.48, t);
      } else if (p < 0.86) {
        // Left hand reaches over top of slide (palm facing down/inward) & racks slide back!
        const t = (p - 0.58) / 0.28;
        const rackCurve = Math.sin(t * Math.PI);
        if (rig.slide) rig.slide.position.z = rackCurve * 0.062;
        rig.leftArm.position.set(-0.042, 0.062, -0.02 + rackCurve * 0.062);
        rig.leftArm.rotation.set(0.12, -0.2, 0.85);
      } else {
        const t = (p - 0.86) / 0.14;
        rig.leftArm.position.lerpVectors(new THREE.Vector3(-0.042, 0.062, -0.02), rig.leftArmRestPos, t);
        rig.leftArm.rotation.set(
          THREE.MathUtils.lerp(0.12, rig.leftArmRestRot.x, t),
          THREE.MathUtils.lerp(-0.2, rig.leftArmRestRot.y, t),
          THREE.MathUtils.lerp(0.85, rig.leftArmRestRot.z, t)
        );
      }
    } else if (rig.id === 'rifle') {
      // RIFLE M4A1 RELOAD (Exact Gambar 1 Canted Angle exposing Curved Magazine!)
      if (p >= 0.22 && !this.reloadStageTriggered.has('out')) {
        this.reloadStageTriggered.add('out');
        soundEngine.playReloadStep('mag_out');
        this.pulseMag = 1.0;
      }
      if (p >= 0.62 && !this.reloadStageTriggered.has('in')) {
        this.reloadStageTriggered.add('in');
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.055;
        this.pulseMag = 1.0;
      }
      if (p >= 0.74 && !this.reloadStageTriggered.has('rack')) {
        this.reloadStageTriggered.add('rack');
        soundEngine.playReloadStep('rack');
        this.pulseAction = 1.0;
      }

      const magGripHand = new THREE.Vector3(-0.048, -0.16, -0.095);
      const magOutHand = new THREE.Vector3(-0.11, -0.36, -0.06);
      const chargeHand = new THREE.Vector3(-0.055, 0.065, 0.095);

      if (p < 0.2) {
        const t = THREE.MathUtils.smoothstep(p, 0, 0.2);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, magGripHand, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.52, t);
      } else if (p < 0.44) {
        const t = THREE.MathUtils.smoothstep(p, 0.2, 0.44);
        rig.mag.position.set(0, rig.magRestPos.y - t * 0.25, rig.magRestPos.z + t * 0.03);
        rig.mag.rotation.x = t * 0.22;
        rig.leftArm.position.lerpVectors(magGripHand, magOutHand, t);
        rig.leftArm.rotation.z = 1.52;
      } else if (p < 0.68) {
        const t = THREE.MathUtils.smoothstep(p, 0.44, 0.68);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.25, rig.magRestPos.z + (1 - t) * 0.03);
        rig.mag.rotation.x = (1 - t) * 0.22;
        rig.leftArm.position.lerpVectors(magOutHand, magGripHand, t);
        rig.leftArm.rotation.z = 1.52;
      } else if (p < 0.9) {
        // Pull T-Charging handle & Bolt Carrier rearward!
        const t = (p - 0.68) / 0.22;
        const pull = Math.sin(t * Math.PI);
        if (rig.chargingHandle) rig.chargingHandle.position.z = 0.095 + pull * 0.072;
        if (rig.bolt) rig.bolt.position.z = pull * 0.072;
        rig.leftArm.position.set(chargeHand.x, chargeHand.y, chargeHand.z + pull * 0.072);
        rig.leftArm.rotation.set(0.12, -0.18, 1.15);
      } else {
        const t = (p - 0.9) / 0.1;
        rig.leftArm.position.lerpVectors(chargeHand, rig.leftArmRestPos, t);
        rig.leftArm.rotation.set(
          THREE.MathUtils.lerp(0.12, rig.leftArmRestRot.x, t),
          THREE.MathUtils.lerp(-0.18, rig.leftArmRestRot.y, t),
          THREE.MathUtils.lerp(1.15, rig.leftArmRestRot.z, t)
        );
      }
    } else if (rig.id === 'sniper') {
      // SNIPER RELOAD (Exact Gambar 1 Canted Angle!)
      if (p >= 0.16 && !this.reloadStageTriggered.has('out')) {
        this.reloadStageTriggered.add('out');
        soundEngine.playReloadStep('mag_out');
        this.pulseMag = 1.0;
      }
      if (p >= 0.44 && !this.reloadStageTriggered.has('in')) {
        this.reloadStageTriggered.add('in');
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.06;
        this.pulseMag = 1.0;
      }
      if (p >= 0.62 && !this.reloadStageTriggered.has('bback')) {
        this.reloadStageTriggered.add('bback');
        soundEngine.playReloadStep('bolt_back');
        this.pulseAction = 1.0;
      }
      if (p >= 0.78 && !this.reloadStageTriggered.has('bfwd')) {
        this.reloadStageTriggered.add('bfwd');
        soundEngine.playReloadStep('bolt_fwd');
      }
      if (p >= 0.88 && !this.reloadStageTriggered.has('bdown')) {
        this.reloadStageTriggered.add('bdown');
        soundEngine.playReloadStep('bolt_down');
      }

      const magHandIn = new THREE.Vector3(-0.045, -0.14, -0.095);
      const magHandOut = new THREE.Vector3(-0.095, -0.34, -0.065);

      if (p < 0.28) {
        const t = THREE.MathUtils.smoothstep(p, 0.0, 0.28);
        const magT = THREE.MathUtils.smoothstep(p, 0.1, 0.28);
        rig.mag.position.set(0, rig.magRestPos.y - magT * 0.22, rig.magRestPos.z);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, magHandOut, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.55, t);
      } else if (p < 0.52) {
        const t = THREE.MathUtils.smoothstep(p, 0.28, 0.52);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.22, rig.magRestPos.z);
        rig.leftArm.position.lerpVectors(magHandOut, magHandIn, t);
        rig.leftArm.rotation.z = 1.55;
      } else if (p < 0.62) {
        const t = (p - 0.52) / 0.1;
        rig.leftArm.position.lerpVectors(magHandIn, rig.leftArmRestPos, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(1.55, rig.leftArmRestRot.z, t);
      }

      // Bolt cycle in second half of sniper reload!
      if (p >= 0.55 && rig.bolt && rig.boltHandle) {
        const bp = THREE.MathUtils.clamp((p - 0.55) / 0.4, 0, 1);
        const lift = bp < 0.2 ? bp / 0.2 : bp < 0.8 ? 1 : (1 - bp) / 0.2;
        const pull = bp < 0.2 ? 0 : bp < 0.5 ? (bp - 0.2) / 0.3 : bp < 0.8 ? 1 - (bp - 0.5) / 0.3 : 0;
        const handBlend = bp < 0.12 ? bp / 0.12 : bp > 0.88 ? (1 - bp) / 0.12 : 1;

        rig.boltHandle.rotation.z = lift * 1.08;
        rig.bolt.position.z = -0.02 + pull * 0.11;

        const knobPos = new THREE.Vector3(0.098 - lift * 0.022, 0.012 + lift * 0.052, 0.055 + pull * 0.11);
        rig.rightArm.position.lerpVectors(rig.rightArmRestPos, knobPos, handBlend);
        rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArmRestRot.z, -0.95 + lift * 0.3, handBlend);
      }
    }
  }

  private updateTargets(dt: number) {
    for (const t of this.world.targets) {
      // Strafing movement
      if (t.alive && t.moveAxis && t.moveAmp && t.moveSpeed) {
        const offset = Math.sin(this.elapsedTime * t.moveSpeed + (t.movePhase ?? 0)) * t.moveAmp;
        if (t.moveAxis === 'x') {
          t.group.position.x = t.basePos.x + offset;
          const worldX = t.zone === 'compound' ? t.group.position.x : t.group.position.x + 180;
          t.group.position.y = this.world.getGroundHeight(worldX, t.group.position.z, t.basePos.y);
        }
      }

      if (t.kind === 'gong') {
        // Spring-damped swinging steel gong pendulum!
        const spring = -22 * t.knockAngle - 3.6 * t.knockVel;
        t.knockVel += spring * dt;
        t.knockAngle += t.knockVel * dt;
        t.pivot.rotation.x = THREE.MathUtils.clamp(t.knockAngle, -1.45, 1.45);
        continue;
      }

      if (t.kind === 'dummy') {
        if (!t.alive) {
          // Fall backward cleanly to -Math.PI/2
          t.knockVel -= 18 * dt;
          t.knockAngle = Math.max(-Math.PI / 2, t.knockAngle + t.knockVel * dt);
          if (t.knockAngle <= -Math.PI / 2) t.knockVel = 0;
          t.pivot.rotation.x = t.knockAngle;

          t.respawnTimer -= dt;
          if (t.respawnTimer <= 0) {
            t.alive = true;
            t.hp = t.maxHp;
            t.knockVel = 6.0;
          }
        } else if (t.knockAngle < 0) {
          // Spring cleanly back upright!
          t.knockAngle = Math.min(0, t.knockAngle + 7.2 * dt);
          t.pivot.rotation.x = t.knockAngle;
        }
      } else if ((t.kind === 'crate' || t.kind === 'barrel') && !t.alive) {
        t.respawnTimer -= dt;
        if (t.respawnTimer <= 0) {
          t.alive = true;
          t.hp = t.maxHp;
          t.group.visible = true;
        }
      }
    }
  }

  private updateFx(dt: number) {
    // 1. Spinning, Bouncing Physical Brass Shell Casings!
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.age += dt;
      if (s.age >= s.maxAge) {
        this.worldScene.remove(s.mesh);
        this.shells.splice(i, 1);
        continue;
      }

      s.vel.y -= 9.8 * dt;
      s.mesh.position.addScaledVector(s.vel, dt);
      s.mesh.rotation.x += s.angVel.x * dt;
      s.mesh.rotation.y += s.angVel.y * dt;
      s.mesh.rotation.z += s.angVel.z * dt;

      const floorY = this.world.getGroundHeight(s.mesh.position.x, s.mesh.position.z, s.mesh.position.y) + 0.04;
      if (s.mesh.position.y < floorY) {
        s.mesh.position.y = floorY;
        if (Math.abs(s.vel.y) > 0.65 && s.bounces < 3) {
          s.vel.y = -s.vel.y * 0.42;
          s.vel.x *= 0.58;
          s.vel.z *= 0.58;
          s.angVel.multiplyScalar(0.55);
          s.bounces++;
          if (s.bounces === 1) soundEngine.playShellBounce(s.weapon);
        } else {
          s.vel.set(0, 0, 0);
          s.angVel.set(0, 0, 0);
        }
      }

      // Fade out gently in final second
      if (s.age > s.maxAge - 0.8) {
        const sc = Math.max(0.01, (s.maxAge - s.age) / 0.8);
        s.mesh.scale.setScalar(sc);
      }
    }

    // 2. High-Velocity Glowing Tracer Bullets
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const tr = this.tracers[i];
      tr.distTraveled += tr.speed * dt;
      if (tr.distTraveled >= tr.distTotal) {
        this.worldScene.remove(tr.mesh); // geometry / material are shared — never disposed
        this.tracers.splice(i, 1);
        continue;
      }
      tr.mesh.position.copy(tr.start).addScaledVector(tr.dir, tr.distTraveled);
    }

    // 3. Sniper Supersonic Vapor Contrails
    for (let i = this.contrails.length - 1; i >= 0; i--) {
      const c = this.contrails[i];
      c.age += dt;
      if (c.age >= c.maxAge) {
        this.worldScene.remove(c.mesh);
        c.mesh.geometry.dispose();
        (c.mesh.material as THREE.Material).dispose();
        this.contrails.splice(i, 1);
        continue;
      }
      const mat = c.mesh.material as THREE.MeshBasicMaterial;
      mat.opacity = 0.42 * (1 - c.age / c.maxAge);
    }

    // 4. Smoke, Sparks, Wood Splinters & Fireball Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;
      if (p.age >= p.maxAge) {
        this.worldScene.remove(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      const t = p.age / p.maxAge;
      p.vel.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      p.mesh.rotation.x += p.angVel.x * dt;
      p.mesh.rotation.y += p.angVel.y * dt;
      p.mesh.rotation.z += p.angVel.z * dt;
      const sc = THREE.MathUtils.lerp(p.startScale, p.endScale, t);
      p.mesh.scale.setScalar(sc);
      if (p.fadeOpacity) {
        const mat = p.mesh.material as THREE.Material & { opacity?: number };
        if (typeof mat.opacity === 'number') {
          mat.opacity = (1 - t) * 0.65;
        }
      }
    }

    // 4.5 Physical 3D Tumbling & Concrete-Bouncing Glass Shards!
    for (let i = this.glassShards.length - 1; i >= 0; i--) {
      const gs = this.glassShards[i];
      gs.age += dt;
      if (gs.age >= gs.maxAge) {
        this.worldScene.remove(gs.mesh);
        this.glassShards.splice(i, 1);
        continue;
      }

      if (gs.bounces < 3 || gs.vel.lengthSq() > 0.01) {
        gs.vel.y -= 14.5 * dt;
        gs.mesh.position.addScaledVector(gs.vel, dt);
        gs.mesh.rotation.x += gs.angVel.x * dt;
        gs.mesh.rotation.y += gs.angVel.y * dt;
        gs.mesh.rotation.z += gs.angVel.z * dt;

        const floorY = this.world.getGroundHeight(gs.mesh.position.x, gs.mesh.position.z, gs.mesh.position.y) + 0.018;
        if (gs.mesh.position.y <= floorY) {
          gs.mesh.position.y = floorY;
          if (Math.abs(gs.vel.y) > 0.7 && gs.bounces < 3) {
            gs.vel.y = -gs.vel.y * (0.28 + Math.random() * 0.14);
            gs.vel.x *= 0.54;
            gs.vel.z *= 0.54;
            gs.angVel.multiplyScalar(0.5);
            gs.bounces++;
            if (gs.bounces === 1 && gs.makeBounceSound) {
              soundEngine.playGlassShardBounce(gs.mesh.position.distanceTo(this.worldCamera.position));
            }
          } else {
            // Settle flat and glinting on the concrete floor!
            gs.vel.set(0, 0, 0);
            gs.angVel.set(0, 0, 0);
            gs.bounces = 3;
            gs.mesh.rotation.x = Math.PI / 2;
            gs.mesh.rotation.z = Math.random() * Math.PI * 2;
          }
        }
      }

      if (gs.age > gs.maxAge - 1.2) {
        const fade = Math.max(0.01, (gs.maxAge - gs.age) / 1.2);
        gs.mesh.scale.setScalar(gs.baseScale * fade);
      }
    }

    // 5. Bullet Impact Decals
    for (let i = this.impactMarks.length - 1; i >= 0; i--) {
      const m = this.impactMarks[i];
      m.age += dt;
      if (m.age >= m.maxAge) {
        this.worldScene.remove(m.mesh);
        this.impactMarks.splice(i, 1);
      }
    }
  }

  private updateHorde(dt: number) {
    if (!this.horde.active) return;
    const footY = this.playerPos.y - this.smoothCamHeight;
    this.horde.update({
      dt,
      playerPos: this.playerPos,
      playerFootY: footY,
      playerAlive: this.playerHp > 0 && this.horde.phase !== 'gameover',
      onBite: (damage, _from, brute) => {
        this.playerHp = Math.max(0, this.playerHp - damage);
        this.timeSinceDamaged = 0;
        this.damagePulse = Math.min(1.0, this.damagePulse + (brute ? 0.7 : 0.4));
        this.camTrauma = Math.min(1.0, this.camTrauma + (brute ? 0.45 : 0.24));
        this.adrenaline = Math.min(1.0, this.adrenaline + 0.3);
        soundEngine.playPlayerHit();
        if (this.playerHp <= 0 && this.horde.phase !== 'gameover') {
          this.horde.gameOver();
          this.mouseDownLeft = false;
          this.mouseDownRight = false;
          this.showUi = true;
          if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock();
          this.lastEventText = `GAME OVER — Bertahan sampai Wave ${this.horde.wave} • ${this.horde.kills} zombie terbunuh`;
        }
      },
    });

    // Between-wave resupply: heal + refill ammo
    const phase = this.horde.phase;
    if (this.prevHordePhase === 'combat' && phase === 'intermission') {
      this.playerHp = Math.min(100, this.playerHp + 60);
      this.refillAllAmmo();
      this.score += 250 * this.horde.wave;
      this.lastEventText = `WAVE ${this.horde.wave} SELESAI — +${250 * this.horde.wave} poin • HP & amunisi diisi ulang`;
    }
    this.prevHordePhase = phase;
  }

  private updateDrill(dt: number) {
    if (this.gameMode !== 'drill' || !this.drillActive || this.drillFinished) return;
    this.drillTimeLeft -= dt;
    if (this.drillTimeLeft <= 0) {
      this.drillTimeLeft = 0;
      this.drillActive = false;
      this.drillFinished = true;
      this.showUi = true;
      this.lastEventText = `TANTANGAN SELESAI! Skor Akhir: ${this.score} • Headshot: ${this.headshots}`;
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
      this.emitHud();
    }
  }

  private computeCalloutPins(): CalloutPin[] {
    if (!this.showMechanics) return [];
    const rig = this.rigs[this.weaponId];
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    const isScoped = this.weaponId === 'sniper' && this.adsBlend > 0.72 && this.animState !== 'bolt_cycle' && this.animState !== 'reloading';
    if (isScoped) return [];

    const projectSocket = (
      id: CalloutPin['id'],
      obj: THREE.Object3D,
      title: string,
      subtitle: string,
      active: boolean
    ): CalloutPin => {
      obj.updateWorldMatrix(true, false);
      const pos = this.tmpV3;
      obj.getWorldPosition(pos);
      pos.project(this.vmCamera);
      const visible = pos.z < 1 && pos.x > -1.05 && pos.x < 1.05 && pos.y > -1.05 && pos.y < 1.05;
      return {
        id,
        title,
        subtitle,
        x: (pos.x * 0.5 + 0.5) * w,
        y: (-pos.y * 0.5 + 0.5) * h,
        visible,
        active,
      };
    };

    const actionTitle =
      this.weaponId === 'pistol'
        ? 'SLIDE BLOWBACK'
        : this.weaponId === 'rifle'
          ? 'BOLT CARRIER'
          : 'BOLT HANDLE (KOKANG)';

    const actionSub =
      this.weaponId === 'pistol'
        ? 'Mundur + kunci saat ammo 0'
        : this.weaponId === 'rifle'
          ? 'Bolak-balik tiap tembakan'
          : 'Angkat 60° & tarik mundur';

    const muzzleSub =
      this.weaponId === 'sniper'
        ? 'Peluru .338 + Gas Muzzle Brake kiri-kanan'
        : this.weaponId === 'rifle'
          ? 'Peluru 5.56 + Api Flash-Hider'
          : 'Peluru .45 + Api Bintang 4 arah';

    const ejectSub =
      this.weaponId === 'sniper'
        ? 'Selongsong keluar SAAT bolt ditarik'
        : this.weaponId === 'rifle'
          ? 'Selongsong memantul Brass Deflector'
          : 'Selongsong keluar langsung kanan-atas';

    return [
      projectSocket('muzzle', rig.muzzleSocket, 'TITIK PELURU & API', muzzleSub, this.pulseMuzzle > 0.15),
      projectSocket('ejection', rig.ejectionSocket, 'TITIK SELONSONG', ejectSub, this.pulseEjection > 0.15),
      projectSocket('action', rig.actionSocket, actionTitle, actionSub, this.pulseAction > 0.15),
      projectSocket('mag', rig.magSocket, 'MAGASIN', 'Diganti di pose Gambar 1 (R)', this.pulseMag > 0.15),
    ];
  }

  private emitHud() {
    const spec = WEAPON_SPECS[this.weaponId];
    // Live 3D PiP Magnifying Glass Sniper Scope renders directly on the 3D weapon (no broken 2D blackout overlay!)
    const sniperGlassAds =
      this.weaponId === 'sniper' &&
      this.adsBlend > 0.58 &&
      this.animState !== 'bolt_cycle' &&
      this.animState !== 'reloading';

    this.onHudUpdate({
      weaponId: this.weaponId,
      ammo: this.ammoMap[this.weaponId],
      magSize: spec.magSize,
      animState: this.animState,
      isAds: this.adsBlend > 0.45,
      isCrouching: this.crouchBlend > 0.45,
      isSprinting: this.sprintBlend > 0.45,
      sniperScoped: sniperGlassAds,
      scopeRangeMeters: this.scopeRangeMeters,
      crosshairSpread: Math.max(
        0.15,
        (1 - this.adsBlend * 0.85) * (0.42 + this.moveSpeedNorm * 0.48 + this.spreadBloom * 1.1)
      ),
      isPointerLocked: this.isPointerLocked,
      showUi: this.showUi,
      bodycamEnabled: this.bodycamEnabled,
      filterSettings: { ...this.filterSettings },
      exposureGain: this.exposureGain,
      focusDistance: this.currentFocusDist,
      isIndoors: this.indoorDarkness > 0.35,
      freeAimScreenX: this.freeAimScreenX,
      freeAimScreenY: this.freeAimScreenY,
      slowMo: this.slowMo,
      showMechanics: this.showMechanics,
      zoneId: this.zoneId,
      gameMode: this.gameMode,
      drillActive: this.drillActive,
      drillTimeLeft: Math.ceil(this.drillTimeLeft),
      drillFinished: this.drillFinished,
      score: this.score,
      streak: this.streak,
      shotsFired: this.shotsFired,
      shotsHit: this.shotsHit,
      headshots: this.headshots,
      playerHp: Math.round(this.playerHp),
      botsAlive: this.botSquad.getAliveCount(),
      botKills: this.botSquad.totalKills,
      wave: this.botSquad.wave,
      botsEnabled: this.botSquad.enabled,
      lastEventText: this.lastEventText,
      reloadProgress:
        this.animState === 'reloading' ? THREE.MathUtils.clamp(this.reloadTimer / this.reloadDuration, 0, 1) : 0,
      boltProgress:
        this.animState === 'bolt_cycle' ? THREE.MathUtils.clamp(this.boltTimer / this.boltDuration, 0, 1) : 0,
      calloutPins: this.computeCalloutPins(),
      hitFeedback: this.hitFeedback,
      iqLighting: IQ.mix,
      horde: this.horde.getHud(),
      perf: {
        fps: Math.round(this.perf.fps),
        ms: Math.round(this.perf.ms * 10) / 10,
        level: this.perf.level,
        levelName: QUALITY_LEVELS[this.perf.level].name,
        scale: QUALITY_LEVELS[this.perf.level].scale,
        auto: this.perf.auto,
        draws: this.lastDraws,
        tris: this.lastTris,
        showFps: this.showFps,
        renderScale: this.renderScale,
        sharpen: this.sharpen,
        ...this.bodycamPost.getResolutionInfo(),
      },
    });
  }
}
