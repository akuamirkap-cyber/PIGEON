import * as THREE from 'three';

/**
 * =====================================================================================
 *  IQ "ELEPHANT" LIGHTING  (Shadertoy 4dKGWm — Inigo Quilez)
 * =====================================================================================
 *  Pencahayaan khas shader Elephant: "key (sun) + fill (sky) + bounce (ground)" triplet
 *  + back/rim light + fresnel + Blinn specular + soft-shadow + ambient-occlusion.
 *
 *  Di Shadertoy, shadow & AO dihitung dengan ray-marching SDF. Di sini ada 2 lapis:
 *   1) Per-material (patch global semua MeshStandard/Lambert/Phong): triplet cahaya iq
 *      memakai shadow-map matahari asli dari scene.
 *   2) Screen-space (bodycamPost.ts): soft-shadow `res = min(res, 8h/t)` dan AO iq
 *      yang di-march pada depth-buffer — padanan SDF dari depth buffer.
 *
 *  Slider 0..100% (IQ.setMix) meng-crossfade antara pencahayaan bawaan PBR three.js (0%)
 *  dan shader iq penuh (100%).  Lampu lokal (api, lampu ruangan, muzzle flash) tetap
 *  ditambahkan di atas hasil iq supaya tidak hilang.
 * =====================================================================================
 */

export type IqPass = 'world' | 'vm';

const uniforms = {
  uIqMix: { value: 1.0 },
  uIqSunDir: { value: new THREE.Vector3(0.6, 0.65, 0.45).normalize() },
  uIqScale: { value: 0.3 },
  uIqSunAtten: { value: 1.0 },
  uIqAmbAtten: { value: 1.0 },
};

class IqLightingController {
  public readonly uniforms = uniforms;
  public mix = 1.0;
  public readonly sunDirWorld = new THREE.Vector3(0.6, 0.65, 0.45).normalize();
  public readonly sunDirVm = new THREE.Vector3(2.8, 3.5, 1.2).normalize();
  public worldAmbAtten = 1.0;
  public vmSunAtten = 1.0;
  public vmAmbAtten = 1.0;
  private installed = false;

  /** 0..1 (UI shows 0–100%) */
  public setMix(m: number) {
    this.mix = THREE.MathUtils.clamp(m, 0, 1);
    uniforms.uIqMix.value = this.mix;
  }

  /** Called by the post pipeline right before each scene is rendered (world camera vs viewmodel camera) */
  public setPass(pass: IqPass) {
    if (pass === 'world') {
      uniforms.uIqSunDir.value.copy(this.sunDirWorld);
      uniforms.uIqSunAtten.value = 1.0;
      uniforms.uIqAmbAtten.value = this.worldAmbAtten;
    } else {
      uniforms.uIqSunDir.value.copy(this.sunDirVm);
      uniforms.uIqSunAtten.value = this.vmSunAtten;
      uniforms.uIqAmbAtten.value = this.vmAmbAtten;
    }
  }

  /** Install a global onBeforeCompile hook so EVERY lit material gets the iq relight. Safe to call twice. */
  public install() {
    if (this.installed) return;
    this.installed = true;

    const fragHeader = /* glsl */ `
#define IQ_RELIGHT
uniform float uIqMix;
uniform vec3  uIqSunDir;
uniform float uIqScale;
uniform float uIqSunAtten;
uniform float uIqAmbAtten;
`;

    // iq Elephant: key + fill + bounce + back + fresnel + specular  (world-space)
    const fragFunc = /* glsl */ `
vec3 iqElephantLight(vec3 alb, vec3 nor, vec3 rd, vec3 pos, float sunSha, float gloss, out vec3 specOut) {
  vec3  lig = normalize(uIqSunDir);
  vec3  ref = reflect(rd, nor);
  vec3  hal = normalize(lig - rd);
  float occ = clamp(0.55 + 0.45 * smoothstep(-0.6, 0.35, nor.y) + 0.0 * pos.x, 0.0, 1.0);
  float amb = sqrt(clamp(0.5 + 0.5 * nor.y, 0.0, 1.0));
  float dif = clamp(dot(nor, lig), 0.0, 1.0);
  float bac = clamp(dot(nor, normalize(vec3(-lig.x, 0.0, -lig.z))), 0.0, 1.0) * clamp(1.0 - pos.y * 0.2, 0.0, 1.0);
  float dom = smoothstep(-0.1, 0.1, ref.y);
  float fre = pow(clamp(1.0 + dot(nor, rd), 0.0, 1.0), 2.0);
  dif *= sunSha * uIqSunAtten;
  float spe = pow(clamp(dot(nor, hal), 0.0, 1.0), 16.0) * dif *
              (0.04 + 0.96 * pow(clamp(1.0 + dot(hal, rd), 0.0, 1.0), 5.0));

  vec3 lin = vec3(0.0);
  lin += 2.80 * dif * vec3(1.30, 1.00, 0.70);
  lin += uIqAmbAtten * (
        0.55 * amb * vec3(0.40, 0.60, 1.15) * occ
      + 0.55 * dom * vec3(0.40, 0.60, 1.30) * occ
      + 0.55 * bac * vec3(0.25, 0.25, 0.25) * occ
      + 0.25 * fre * vec3(1.00, 1.00, 1.00) * occ);
  specOut = 10.0 * spe * vec3(1.10, 0.90, 0.70) * gloss * uIqScale;
  return alb * lin * uIqScale;
}
`;

    const opaquePatch = /* glsl */ `
#ifdef IQ_RELIGHT
if (uIqMix > 0.001) {
  vec3 iqVd = inverseTransformDirection(-vViewPosition, viewMatrix);
  vec3 iqRd = normalize(iqVd);
  vec3 iqN  = normalize(inverseTransformDirection(normal, viewMatrix));
  vec3 iqPos = cameraPosition + iqVd;
  float iqMetal = 0.0;
  float iqGloss = 0.3;
  #ifdef STANDARD
    iqMetal = metalnessFactor;
    iqGloss = clamp(1.0 - roughnessFactor, 0.0, 1.0);
    iqGloss = 0.12 + 0.88 * iqGloss * iqGloss;
  #endif
  vec3 iqSpec;
  vec3 iqCol = iqElephantLight(diffuseColor.rgb, iqN, iqRd, iqPos, iqSunShadow, iqGloss, iqSpec);
  vec3 iqFinal = iqCol + iqSpec * (1.0 - iqMetal * 0.5) + iqLocal + totalEmissiveRadiance;
  float iqK = uIqMix * (1.0 - 0.8 * iqMetal);
  outgoingLight = mix(outgoingLight, iqFinal, iqK);
}
#endif
`;

    const prevHook = THREE.Material.prototype.onBeforeCompile;
    const chunks = THREE.ShaderChunk as unknown as Record<string, string>;

    // Pre-patch the lights_fragment_begin chunk once: capture sun shadow + sum of local (point/spot) lights
    let patchedLights = chunks.lights_fragment_begin as string;
    const marker1 = 'IncidentLight directLight;';
    const marker2 = '#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )';
    const shadowLine =
      'directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;';
    const canPatchLights =
      patchedLights.includes(marker1) && patchedLights.includes(marker2) && patchedLights.includes(shadowLine);

    if (canPatchLights) {
      patchedLights = patchedLights
        .replace(
          marker1,
          `${marker1}\n\tvec3 iqLocalPre = reflectedLight.directDiffuse + reflectedLight.directSpecular;\n\tfloat iqSunShadow = 1.0;\n\tvec3 iqLocal = vec3( 0.0 );`
        )
        .replace(
          marker2,
          `iqLocal = max( reflectedLight.directDiffuse + reflectedLight.directSpecular - iqLocalPre, vec3( 0.0 ) );\n\n${marker2}`
        )
        .replace(
          shadowLine,
          `{\n\t\tfloat iqSh = ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n\t\tdirectLight.color *= iqSh;\n\t\t#if ( UNROLLED_LOOP_INDEX == 0 )\n\t\tiqSunShadow = iqSh;\n\t\t#endif\n\t\t}`
        );
    } else {
      console.warn('[IQ] three.js lights chunk layout changed — iq per-material relight disabled (screen-space pass still works).');
    }

    THREE.Material.prototype.onBeforeCompile = function (
      this: THREE.Material,
      shader: THREE.WebGLProgramParametersWithUniforms,
      renderer: THREE.WebGLRenderer
    ) {
      if (prevHook) prevHook.call(this, shader, renderer);
      const m = this as THREE.Material & {
        isMeshStandardMaterial?: boolean;
        isMeshLambertMaterial?: boolean;
        isMeshPhongMaterial?: boolean;
      };
      if (!canPatchLights) return;
      if (!(m.isMeshStandardMaterial || m.isMeshLambertMaterial || m.isMeshPhongMaterial)) return;
      const frag = shader.fragmentShader;
      if (!frag.includes('#include <lights_fragment_begin>') || !frag.includes('#include <opaque_fragment>')) return;

      shader.uniforms.uIqMix = uniforms.uIqMix;
      shader.uniforms.uIqSunDir = uniforms.uIqSunDir;
      shader.uniforms.uIqScale = uniforms.uIqScale;
      shader.uniforms.uIqSunAtten = uniforms.uIqSunAtten;
      shader.uniforms.uIqAmbAtten = uniforms.uIqAmbAtten;

      shader.fragmentShader = frag
        .replace('#include <lights_fragment_begin>', patchedLights)
        .replace('#include <opaque_fragment>', `${opaquePatch}\n#include <opaque_fragment>`)
        .replace('void main() {', `${fragHeader}\n${fragFunc}\nvoid main() {`);
    };
  }
}

export const IQ = new IqLightingController();
