class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  suckGain: GainNode | null = null;
  suckFilter: BiquadFilterNode | null = null;
  muted = false;
  lastCoin = 0;
  lastPop = 0;
  musicTimer: number | null = null;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.35;
    this.master.connect(this.ctx.destination);
    // suction noise loop
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    this.suckFilter = this.ctx.createBiquadFilter();
    this.suckFilter.type = "bandpass";
    this.suckFilter.frequency.value = 600;
    this.suckFilter.Q.value = 2;
    this.suckGain = this.ctx.createGain();
    this.suckGain.gain.value = 0;
    src.connect(this.suckFilter);
    this.suckFilter.connect(this.suckGain);
    this.suckGain.connect(this.master);
    src.start();
    this.startMusic();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.35;
  }

  tone(type: OscillatorType, f0: number, f1: number, dur: number, vol = 0.3, delay = 0) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  gulp(size = 1) {
    const p = 1 / Math.max(0.6, Math.min(2.5, size));
    const j = 0.9 + Math.random() * 0.2;
    this.tone("square", 520 * p * j, 140 * p, 0.09, 0.22);
    this.tone("triangle", 260 * p * j, 60 * p, 0.14, 0.35, 0.03);
    this.tone("sine", 900 * j, 1400 * j, 0.05, 0.12, 0.08);
    // low belly "thump" so a big bite really lands
    if (size > 0.7) this.tone("sine", 170 * p, 46, 0.17, Math.min(0.5, 0.22 + size * 0.1), 0.01);
  }

  /** bubbly pop for every little fish slurped; the pitch climbs a pentatonic ladder with the chain */
  pop(n = 1) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (now - this.lastPop < 0.028) return;
    this.lastPop = now;
    const ladder = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24];
    const f = 494 * Math.pow(2, ladder[Math.min(ladder.length - 1, Math.max(0, n - 1))] / 12);
    this.tone("sine", f * 0.62, f * 1.3, 0.075, 0.2);
    this.tone("triangle", f * 2, f * 2.02, 0.035, 0.06, 0.012);
  }

  /** coin chime; consecutive coins step up a major scale ("ka-ching ka-ching kaCHING") */
  coin(step = 0) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (now - this.lastCoin < 0.04) return;
    this.lastCoin = now;
    const scale = [0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17];
    const f = 988 * Math.pow(2, scale[Math.min(scale.length - 1, Math.max(0, step))] / 12);
    this.tone("square", f, f, 0.05, 0.07);
    this.tone("square", f * 1.335, f * 1.335, 0.11, 0.07, 0.045);
    this.tone("sine", f * 2.67, f * 2.67, 0.18, 0.03, 0.045);
  }

  /** sparkling jingle for a clean-sweep bonus */
  bonus() {
    [0, 4, 7, 12, 16, 19, 24, 28].forEach((s, i) => this.tone("triangle", 659 * Math.pow(2, s / 12), 659 * Math.pow(2, s / 12), 0.14, 0.16, i * 0.045));
    this.tone("sine", 1318, 2637, 0.5, 0.07, 0.36);
  }

  combo(n: number) {
    const base = 440 * Math.pow(2, Math.min(n, 12) / 12);
    [0, 4, 7, 12].forEach((s, i) => this.tone("square", base * Math.pow(2, s / 12), base * Math.pow(2, s / 12), 0.08, 0.1, i * 0.06));
  }

  frenzy() {
    [0, 4, 7, 12, 16, 19, 24].forEach((s, i) => this.tone("square", 523 * Math.pow(2, s / 12), 523 * Math.pow(2, s / 12), 0.09, 0.1, i * 0.05));
  }

  levelUp() {
    [0, 7, 12, 19].forEach((s, i) => this.tone("triangle", 392 * Math.pow(2, s / 12), 392 * Math.pow(2, s / 12), 0.15, 0.25, i * 0.08));
  }

  die() {
    this.tone("square", 600, 60, 0.7, 0.2);
    this.tone("triangle", 300, 40, 0.9, 0.3, 0.1);
  }

  whoosh() {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime;
    const len = Math.floor(this.ctx.sampleRate * 0.35);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.5;
    f.frequency.setValueAtTime(400, t);
    f.frequency.exponentialRampToValueAtTime(2400, t + 0.3);
    const g = this.ctx.createGain();
    g.gain.value = 0.4;
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t);
    this.tone("square", 220, 660, 0.12, 0.06);
  }

  bubble() {
    this.tone("sine", 400 + Math.random() * 400, 1200, 0.06, 0.06);
  }

  setSuck(on: boolean) {
    if (!this.ctx || !this.suckGain || !this.suckFilter) return;
    const t = this.ctx.currentTime;
    this.suckGain.gain.setTargetAtTime(on ? 0.25 : 0, t, 0.05);
    this.suckFilter.frequency.setTargetAtTime(on ? 1400 : 500, t, 0.3);
  }

  startMusic() {
    if (!this.ctx) return;
    const notes = [0, 7, 12, 7, 3, 10, 15, 10, 5, 12, 17, 12, 7, 14, 19, 14];
    const bass = [0, 0, -4, -4, -7, -7, -5, -5];
    let step = 0;
    const tick = () => {
      if (!this.ctx || !this.master) return;
      const n = notes[step % notes.length];
      const chord = Math.floor(step / 4) % 4;
      const shift = [0, -4, -7, -5][chord];
      this.tone("triangle", 330 * Math.pow(2, (n + shift) / 12), 330 * Math.pow(2, (n + shift) / 12), 0.18, 0.05);
      if (step % 2 === 0) {
        const b = bass[Math.floor(step / 2) % bass.length];
        this.tone("square", 82 * Math.pow(2, b / 12), 82 * Math.pow(2, b / 12), 0.2, 0.035);
      }
      step++;
    };
    this.musicTimer = window.setInterval(tick, 190);
  }
}

export const sfx = new Sfx();
