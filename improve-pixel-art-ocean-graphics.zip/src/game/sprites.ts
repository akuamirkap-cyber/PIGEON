import type { Species } from "./species";

export type EyeExpr = "normal" | "happy" | "panic";
// jawState: -1 = puffed chomp/chew! 0 = closed, 1 = slightly open, 2 = half open, 3 = wide hinged gape!
export type JawState = -1 | 0 | 1 | 2 | 3;

export interface Sprite {
  canvas: HTMLCanvasElement;
  w: number;
  h: number;
}

function hexRgb(h: string): [number, number, number] {
  const s = h.startsWith("#") ? h.slice(1) : h;
  const n = parseInt(s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mixHex(a: string, b: string, t: number): string {
  const ca = hexRgb(a),
    cb = hexRgb(b);
  const r = Math.round(ca[0] + (cb[0] - ca[0]) * t);
  const g = Math.round(ca[1] + (cb[1] - ca[1]) * t);
  const bl = Math.round(ca[2] + (cb[2] - ca[2]) * t);
  return "#" + ((1 << 24) | (r << 16) | (g << 8) | bl).toString(16).slice(1);
}

function rgbaHex(h: string, alpha: number): string {
  const [r, g, b] = hexRgb(h);
  return `rgba(${r},${g},${b},${alpha})`;
}

const TAIL_FRAMES = 8;
const cache = new Map<string, HTMLCanvasElement>();

const isDisc = (sp: Species) => sp.style === "andy" || sp.style === "boris" || sp.style === "layla" || sp.style === "tang" || sp.style === "idol";
const isLong = (sp: Species) => sp.style === "orca" || sp.style === "shark" || sp.style === "barracuda" || sp.style === "sailfish";

export function fishMouthOffset(sp: Species, bodyLen: number): [number, number] {
  const rx = bodyLen * 0.41;
  const ry = rx * sp.hRatio * 1.05;
  const bx = bodyLen * 0.05;
  if (isDisc(sp)) return [bx + rx * 1.02, ry * 0.16];
  if (sp.style === "barracuda") return [bx + rx * 1.04, ry * 0.2];
  if (sp.style === "sailfish") return [bx + rx * 1.0, ry * 0.22];
  if (isLong(sp)) return [bx + rx * 0.94, ry * 0.18];
  return [bx + rx * 0.92, ry * 0.16];
}

const CACHE_MAX = 900;
let genBudget = 3;
/** number of fish sprites rasterised so far (diagnostics) */
export const spriteStats = { made: 0 };

/**
 * Call once per rendered frame. Caps how many NEW sprites may be rasterised during that frame, so a
 * burst of unseen fish / poses can never cause a hitch (they borrow a neighbouring frame meanwhile).
 */
/** how many new sprites may still be rasterised this frame */
export const spriteBudgetLeft = () => genBudget;

export function beginSpriteFrame(budget = 3) {
  genBudget = budget;
}

export function fishSprite(
  sp: Species,
  worldLen: number,
  jawState: JawState,
  tailPhase: number,
  key: string,
  pixelMode = false,
  expr: EyeExpr = "normal",
  urgent = false
): Sprite {
  const tf = (((Math.floor((tailPhase / (Math.PI * 2)) * TAIL_FRAMES) % TAIL_FRAMES) + TAIL_FRAMES) % TAIL_FRAMES);
  // sprite resolution tiers: school fry are tiny on screen, so they get a small (cheap & crisp) sprite
  const tierPx = pixelMode ? Math.max(26, Math.min(60, Math.round(worldLen * 1.45))) : worldLen < 13.5 ? 112 : worldLen < 26 ? 160 : 280;
  const base = key + "|" + tierPx + "|" + (pixelMode ? 1 : 0) + "|";
  const pose = jawState + "|" + expr + "|";
  const ck = base + pose + tf;
  let cv = cache.get(ck);
  if (cv) {
    // least-recently-used bookkeeping: a sprite that is still on screen is never the one evicted
    cache.delete(ck);
    cache.set(ck, cv);
  } else {
    if (genBudget <= 0 && !urgent) {
      // out of budget this frame: borrow the nearest tail frame of the same pose, or else the neutral pose
      for (let d = 1; d < TAIL_FRAMES && !cv; d++) cv = cache.get(base + pose + ((tf + d) % TAIL_FRAMES));
      for (let d = 0; d < TAIL_FRAMES && !cv; d++) cv = cache.get(base + "0|normal|" + ((tf + d) % TAIL_FRAMES));
    }
    if (!cv) {
      genBudget--;
      spriteStats.made++;
      cv = renderFishCanvas(sp, tierPx, jawState, tf, pixelMode, expr);
      cache.set(ck, cv);
      if (cache.size > CACHE_MAX) {
        const oldest = cache.keys().next().value;
        if (oldest !== undefined) cache.delete(oldest);
      }
    }
  }
  const aspect = cv.height / cv.width;
  const drawW = worldLen * 1.4;
  return { canvas: cv, w: drawW, h: drawW * aspect };
}

// ============================================================================
// BODY SILHOUETTES — true-to-life profiles per species, same plush cartoon style
//   disc family  : angelfish (andy), butterflyfish (boris), queen triggerfish (layla)
//   fusiform     : anchovy, grouper, lionfish, John Dory, anglerfish, clownfish
//   torpedo      : great barracuda (pike jaw + underbite), orca (blunt melon head)
// ============================================================================
function buildBodyPath(ctx: CanvasRenderingContext2D, sp: Species, bx: number, rx: number, ry: number, jawState: JawState) {
  const open = jawState > 0 ? jawState / 3 : 0;
  const puff = jawState === -1 ? 1 : 0;
  const st = sp.style;
  ctx.beginPath();

  if (isDisc(sp)) {
    // Laterally compressed reef-fish disc: convex back AND belly meeting at a narrow peduncle, small beak-like snout
    const stemX = bx - rx * 0.94;
    const stemH = ry * 0.13;
    const peakX = bx + rx * (st === "layla" || st === "tang" ? -0.02 : st === "boris" || st === "idol" ? -0.1 : -0.14);
    const peakY = -ry * (st === "andy" ? 1.0 : 0.98);
    const snoutLift = open * ry * 0.24;
    const snoutX = bx + rx * ((st === "boris" || st === "idol" ? 1.22 : st === "tang" ? 1.1 : 1.16) + puff * 0.03);
    const snoutY = ry * 0.03 - snoutLift;

    ctx.moveTo(stemX, -stemH);
    ctx.bezierCurveTo(bx - rx * 0.9, -ry * 0.62, peakX - rx * 0.46, peakY, peakX, peakY);
    ctx.bezierCurveTo(peakX + rx * 0.4, peakY, bx + rx * 0.58, -ry * 0.66 - snoutLift * 0.25, bx + rx * 0.82, -ry * 0.24 - snoutLift * 0.6);
    ctx.quadraticCurveTo(bx + rx * 0.96, -ry * 0.07 - snoutLift * 0.85, snoutX, snoutY);
    const upperLipX = bx + rx * (1.03 + puff * 0.02);
    const upperLipY = snoutY + ry * 0.11;
    ctx.quadraticCurveTo(snoutX + rx * 0.02, snoutY + ry * 0.08, upperLipX, upperLipY);

    if (open > 0) {
      const hingeX = bx + rx * (0.66 - open * 0.08);
      const hingeY = ry * 0.18;
      const jawDrop = open * ry * 0.46;
      const lowerTipX = bx + rx * (0.98 - open * 0.05);
      const lowerTipY = ry * 0.25 + jawDrop;
      ctx.quadraticCurveTo(bx + rx * 0.84, upperLipY + ry * 0.05, hingeX, hingeY);
      ctx.quadraticCurveTo(bx + rx * 0.8, lowerTipY - ry * 0.04, lowerTipX, lowerTipY);
      ctx.bezierCurveTo(lowerTipX - rx * 0.08, lowerTipY + ry * 0.26, peakX + rx * 0.44, ry * (1.0 + open * 0.1), peakX, ry * 0.98);
    } else {
      const chinPuff = puff * ry * 0.1;
      ctx.quadraticCurveTo(bx + rx * 0.92 + puff * rx * 0.04, ry * 0.19, bx + rx * 0.94 + puff * rx * 0.04, ry * 0.31 + chinPuff);
      ctx.bezierCurveTo(bx + rx * 0.8, ry * 0.86 + chinPuff, peakX + rx * 0.44, ry * 1.0 + chinPuff, peakX, ry * 0.98);
    }
    ctx.bezierCurveTo(peakX - rx * 0.46, ry * 0.98, bx - rx * 0.9, ry * 0.62, stemX, stemH);
  } else {
    const longBody = isLong(sp);
    const blunt = st === "orca";
    const pike = st === "barracuda";
    const slimHead = pike || st === "sailfish";
    const wy = ry * (pike ? 0.3 : st === "sailfish" ? 0.26 : st === "minnow" ? 0.24 : longBody ? 0.19 : 0.2);
    const upLift = open * ry * 0.3;
    // shark: conical snout overhanging an underslung mouth · puffer: short blunt beak
    const snoutX = bx + rx * (pike ? 1.2 : st === "shark" ? 1.18 : st === "sailfish" ? 1.14 : blunt ? 1.05 : longBody ? 1.12 : (st === "puffer" ? 1.03 : 1.09) + puff * 0.03);
    const snoutY = ry * (blunt ? 0.08 : st === "shark" ? -0.12 : 0.02) - upLift;

    ctx.moveTo(bx - rx, -wy);
    if (blunt) {
      // rounded melon forehead of a killer whale
      ctx.bezierCurveTo(bx - rx * 0.5, -ry * 0.9, bx + rx * 0.2, -ry * 1.04, bx + rx * 0.62, -ry * 0.86);
      ctx.bezierCurveTo(bx + rx * 0.92, -ry * 0.72, bx + rx * 1.08, -ry * 0.38 - upLift * 0.6, snoutX, snoutY);
    } else if (slimHead) {
      // long flat pike-like head
      ctx.bezierCurveTo(bx - rx * 0.5, -ry * 0.94, bx + rx * 0.1, -ry * 1.0, bx + rx * 0.5, -ry * 0.82);
      ctx.bezierCurveTo(bx + rx * 0.8, -ry * 0.64, bx + rx * 1.02, -ry * 0.3 - upLift * 0.6, snoutX, snoutY);
    } else if (longBody) {
      ctx.bezierCurveTo(bx - rx * 0.5, -ry * 0.86, bx + rx * 0.12, -ry * 1.02, bx + rx * 0.56, -ry * 0.76);
      ctx.bezierCurveTo(bx + rx * 0.84, -ry * 0.54, bx + rx * 1.02, -ry * 0.2 - upLift * 0.6, snoutX, snoutY);
    } else {
      ctx.bezierCurveTo(bx - rx * 0.52, -ry * 0.92, bx + rx * 0.14, -ry * 1.06, bx + rx * 0.58, -ry * 0.78);
      ctx.bezierCurveTo(bx + rx * 0.82, -ry * 0.54, bx + rx * 0.96, -ry * 0.16 - upLift * 0.6, snoutX, snoutY);
    }

    if (open > 0) {
      const hingeX = bx + rx * (longBody ? 0.46 : st === "eddy" || st === "pierre" ? 0.44 - open * 0.06 : 0.56 - open * 0.09);
      const hingeY = ry * 0.16;
      const jawDrop = open * ry * (st === "eddy" ? 0.66 : 0.54);
      const lowerTipX = bx + rx * (pike ? 1.16 - open * 0.05 : longBody ? 1.0 - open * 0.05 : 0.96 - open * 0.05);
      const lowerTipY = ry * 0.22 + jawDrop;
      ctx.quadraticCurveTo(bx + rx * 0.82, snoutY + ry * 0.08, hingeX, hingeY);
      ctx.quadraticCurveTo(bx + rx * 0.75, lowerTipY - ry * 0.05, lowerTipX, lowerTipY);
      ctx.bezierCurveTo(lowerTipX - rx * 0.08, lowerTipY + ry * 0.25, bx + rx * 0.44, ry * (0.98 + open * 0.15), bx - rx * 0.38, ry * 0.9);
      ctx.quadraticCurveTo(bx - rx * 0.74, ry * 0.74, bx - rx, wy);
    } else if (pike) {
      // barracuda underbite: the lower jaw juts out beyond the upper jaw
      ctx.quadraticCurveTo(snoutX - rx * 0.03, ry * 0.2, bx + rx * 1.25, ry * 0.3);
      ctx.quadraticCurveTo(bx + rx * 1.2, ry * 0.66, bx + rx * 0.86, ry * 0.76);
      ctx.bezierCurveTo(bx + rx * 0.5, ry * 1.0, bx - rx * 0.42, ry * 0.94, bx - rx, wy);
    } else {
      const chinPuff = puff * ry * 0.1;
      ctx.quadraticCurveTo(snoutX + rx * 0.01, ry * 0.12, bx + rx * 0.94 + puff * rx * 0.03, ry * 0.22);
      ctx.quadraticCurveTo(bx + rx * 0.96 + puff * rx * 0.03, ry * 0.36 + chinPuff, bx + rx * 0.82, ry * 0.54 + chinPuff);
      ctx.bezierCurveTo(bx + rx * 0.5, ry * 0.98 + chinPuff, bx - rx * 0.42, ry * 0.94, bx - rx, wy);
    }
  }
  ctx.closePath();
}

export function renderFishCanvas(
  sp: Species,
  W: number,
  jawState: JawState,
  tailFrame: number,
  pixelMode: boolean,
  expr: EyeExpr
): HTMLCanvasElement {
  const st = sp.style;
  const pal = sp.pal;
  const disc = isDisc(sp);
  const longBody = isLong(sp);
  const tall = !!(sp.lure || sp.spinyCrest || st === "orca" || st === "layla" || st === "barracuda" || st === "minnow" || st === "pierre" || st === "shark" || st === "puffer" || st === "tang" || st === "idol");
  const extraTop = st === "sailfish" ? 0.56 : tall ? 0.24 : 0.16; // the sailfish needs head-room for its sail
  const aspect = Math.max(0.62, Math.min(1.22, sp.hRatio * 1.16 + extraTop));
  const H = Math.max(20, Math.round(W * aspect));
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext("2d")!;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";

  const bodyLen = W * 0.7;
  const rx = bodyLen * 0.41;
  const ry = rx * sp.hRatio * 1.05;
  const cy = H * (st === "sailfish" ? 0.63 : sp.lure || sp.spinyCrest ? 0.58 : 0.53);
  const bx = W * 0.5 + bodyLen * 0.05;
  const X = (u: number) => bx + rx * u;
  const V = (v: number) => ry * v;
  const wy = ry * (disc ? 0.13 : st === "barracuda" ? 0.3 : st === "sailfish" ? 0.26 : st === "minnow" ? 0.24 : longBody ? 0.19 : 0.2);
  const rim = Math.max(1.1, W * 0.014);
  const detail = W >= 55;
  const out = (a: number) => rgbaHex(pal.outline, a);

  // swim cycle: tail beat + a lagging ripple that runs through the soft fins
  const wagAng = (tailFrame / TAIL_FRAMES) * Math.PI * 2;
  const wag = Math.sin(wagAng);
  const wag2 = Math.sin(wagAng - 1.0);
  const sw = wag2 * rx * 0.055;
  const open = jawState > 0 ? jawState / 3 : 0;
  const puff = jawState === -1 ? 1 : 0;

  const finBase = pal.fin;
  const finDark = mixHex(finBase, pal.dark, 0.55);
  const finLight = mixHex(finBase, "#ffffff", 0.35);
  const tailBase = pal.tail || finBase;
  const tailDark = mixHex(tailBase, pal.dark, 0.38);
  const tailLight = mixHex(tailBase, "#ffffff", 0.5);

  ctx.save();
  ctx.translate(0, cy);

  // generic soft rayed fin painter
  const fin = (
    build: () => void,
    c0: string,
    c1: string,
    g: [number, number, number, number],
    o: { rays?: number[][]; margin?: string; marginW?: number; alpha?: number } = {}
  ) => {
    ctx.save();
    if (o.alpha !== undefined) ctx.globalAlpha = o.alpha;
    ctx.beginPath();
    build();
    ctx.closePath();
    const gr = ctx.createLinearGradient(g[0], g[1], g[2], g[3]);
    gr.addColorStop(0, c0);
    gr.addColorStop(1, c1);
    ctx.fillStyle = gr;
    ctx.fill();
    if (detail && (o.rays || o.margin)) {
      ctx.save();
      ctx.clip();
      if (o.rays) {
        ctx.strokeStyle = out(0.28);
        ctx.lineWidth = Math.max(0.9, rim * 0.7);
        ctx.beginPath();
        for (const r of o.rays) {
          ctx.moveTo(r[0], r[1]);
          ctx.lineTo(r[2], r[3]);
        }
        ctx.stroke();
      }
      if (o.margin) {
        ctx.beginPath();
        build();
        ctx.closePath();
        ctx.strokeStyle = o.margin;
        ctx.lineWidth = rim * (o.marginW ?? 2.6);
        ctx.stroke();
      }
      ctx.restore();
    }
    ctx.beginPath();
    build();
    ctx.closePath();
    ctx.strokeStyle = out(0.55);
    ctx.lineWidth = rim;
    ctx.stroke();
    ctx.restore();
  };
  // fin rays fanning from a base segment to a tip segment
  const rays = (x0: number, y0: number, x1: number, y1: number, tx0: number, ty0: number, tx1: number, ty1: number, n: number) => {
    const r: number[][] = [];
    for (let i = 0; i < n; i++) {
      const f = (i + 0.5) / n;
      r.push([x0 + (x1 - x0) * f, y0 + (y1 - y0) * f, tx0 + (tx1 - tx0) * f, ty0 + (ty1 - ty0) * f]);
    }
    return r;
  };
  const BLK = "rgba(26, 18, 14, 0.9)";
  // paints a coloured patch (fin tip, band) clipped inside a fin shape
  const dip = (build: () => void, px: number, py: number, r: number, col: string) => {
    ctx.save();
    ctx.beginPath();
    build();
    ctx.closePath();
    ctx.clip();
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.arc(px, py, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  // ---------- 0. ANGLERFISH LURE (illicium growing from the snout, glowing esca) ----------
  if (sp.lure) {
    const lx0 = X(0.52),
      ly0 = V(-0.8);
    const bulbX = X(1.1),
      bulbY = V(-1.12) + wag * ry * 0.06;
    ctx.beginPath();
    ctx.moveTo(lx0, ly0);
    ctx.bezierCurveTo(X(0.46), V(-1.56), X(1.02), V(-1.52), bulbX, bulbY);
    ctx.strokeStyle = pal.dark;
    ctx.lineWidth = Math.max(2, W * 0.02);
    ctx.stroke();
    const lCol = pal.lure || "#d9ff42";
    const lg = ctx.createRadialGradient(bulbX, bulbY, 0.5, bulbX, bulbY, ry * 0.5);
    lg.addColorStop(0, "#ffffff");
    lg.addColorStop(0.28, lCol);
    lg.addColorStop(0.65, rgbaHex(lCol, 0.32));
    lg.addColorStop(1, rgbaHex(lCol, 0));
    ctx.fillStyle = lg;
    ctx.beginPath();
    ctx.arc(bulbX, bulbY, ry * 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // ---------- 1. CAUDAL FIN — the right tail type for each species, hinged at the peduncle ----------
  const tKind =
    st === "minnow" || st === "barracuda"
      ? "fork"
      : st === "layla" || st === "sailfish"
        ? "lunate"
        : st === "shark"
          ? "hetero"
          : st === "orca"
            ? "fluke"
            : st === "boris" || st === "peter" || st === "tang" || st === "idol"
              ? "trunc"
              : "round";
  const tl = rx * (tKind === "fork" ? 0.68 : tKind === "lunate" ? 0.64 : tKind === "hetero" ? 0.7 : tKind === "fluke" ? 0.62 : tKind === "trunc" ? 0.5 : st === "puffer" ? 0.46 : 0.58);
  const th =
    tKind === "fork"
      ? Math.max(ry * 0.95, rx * 0.34)
      : tKind === "lunate"
        ? st === "sailfish"
          ? rx * 0.52
          : ry * 0.92
        : tKind === "hetero"
          ? ry * 0.95
          : tKind === "fluke"
            ? ry * 0.66
            : tKind === "trunc"
              ? ry * 0.6
              : st === "puffer"
                ? ry * 0.42
                : ry * 0.64;
  ctx.save();
  ctx.translate(X(disc ? -0.9 : -0.95), 0);
  ctx.rotate(wag * (tKind === "fluke" ? 0.36 : 0.2));
  if (tKind !== "fluke") ctx.scale(1 - Math.abs(wag) * 0.1, 1);
  const tailPath = () => {
    if (tKind === "fork") {
      ctx.moveTo(0, -wy * 0.9);
      ctx.quadraticCurveTo(-tl * 0.5, -th * 0.72, -tl, -th);
      ctx.quadraticCurveTo(-tl * 0.66, -th * 0.3, -tl * 0.36, 0);
      ctx.quadraticCurveTo(-tl * 0.66, th * 0.3, -tl, th);
      ctx.quadraticCurveTo(-tl * 0.5, th * 0.72, 0, wy * 0.9);
    } else if (tKind === "lunate") {
      ctx.moveTo(0, -wy * 0.9);
      ctx.quadraticCurveTo(-tl * 0.5, -th * 0.8, -tl * 1.06, -th);
      ctx.quadraticCurveTo(-tl * 0.62, -th * 0.42, -tl * 0.56, 0);
      ctx.quadraticCurveTo(-tl * 0.62, th * 0.42, -tl * 1.06, th);
      ctx.quadraticCurveTo(-tl * 0.5, th * 0.8, 0, wy * 0.9);
    } else if (tKind === "hetero") {
      // heterocercal shark tail: long upper lobe, short lower lobe
      ctx.moveTo(0, -wy * 0.9);
      ctx.quadraticCurveTo(-tl * 0.5, -th * 0.7, -tl * 1.08, -th * 1.25);
      ctx.quadraticCurveTo(-tl * 0.74, -th * 0.5, -tl * 0.5, -th * 0.04);
      ctx.quadraticCurveTo(-tl * 0.62, th * 0.36, -tl * 0.74, th * 0.8);
      ctx.quadraticCurveTo(-tl * 0.4, th * 0.62, 0, wy * 0.9);
    } else if (tKind === "fluke") {
      // horizontal whale flukes seen in 3/4 view: near fluke large, far fluke foreshortened, median notch
      ctx.moveTo(0, -wy * 0.7);
      ctx.quadraticCurveTo(-tl * 0.5, -th * 0.42, -tl * 0.96, -th * 0.72);
      ctx.quadraticCurveTo(-tl * 0.8, -th * 0.2, -tl * 0.64, th * 0.04);
      ctx.quadraticCurveTo(-tl * 0.86, th * 0.32, -tl * 1.08, th);
      ctx.quadraticCurveTo(-tl * 0.5, th * 0.66, 0, wy * 0.7);
    } else if (tKind === "trunc") {
      ctx.moveTo(0, -wy * 0.95);
      ctx.quadraticCurveTo(-tl * 0.5, -th * 0.84, -tl, -th * 0.9);
      ctx.quadraticCurveTo(-tl * 1.07, 0, -tl, th * 0.9);
      ctx.quadraticCurveTo(-tl * 0.5, th * 0.84, 0, wy * 0.95);
    } else {
      ctx.moveTo(0, -wy * 0.95);
      ctx.bezierCurveTo(-tl * 0.3, -th * 0.98, -tl * 0.86, -th * 0.98, -tl, -th * 0.36);
      ctx.quadraticCurveTo(-tl * 1.13, 0, -tl, th * 0.36);
      ctx.bezierCurveTo(-tl * 0.86, th * 0.98, -tl * 0.3, th * 0.98, 0, wy * 0.95);
    }
  };
  ctx.beginPath();
  tailPath();
  ctx.closePath();
  const tg = ctx.createLinearGradient(0, 0, -tl * 1.08, 0);
  if (st === "andy") {
    tg.addColorStop(0, mixHex(pal.dark, "#ffae38", 0.5));
    tg.addColorStop(0.28, "#ffe794");
    tg.addColorStop(0.68, "#fffdf2");
    tg.addColorStop(1, "rgba(255, 255, 255, 0.88)");
  } else if (st === "orca") {
    tg.addColorStop(0, pal.body);
    tg.addColorStop(1, pal.dark);
  } else {
    tg.addColorStop(0, tailDark);
    tg.addColorStop(0.55, tailBase);
    tg.addColorStop(1, tailLight);
  }
  ctx.fillStyle = tg;
  ctx.fill();
  if (detail && st !== "orca") {
    ctx.save();
    ctx.clip();
    ctx.strokeStyle = st === "andy" ? "rgba(230, 155, 55, 0.32)" : out(0.25);
    ctx.lineWidth = Math.max(0.9, rim * 0.7);
    ctx.beginPath();
    for (const k of [-0.8, -0.52, -0.26, 0, 0.26, 0.52, 0.8]) {
      ctx.moveTo(0, k * wy);
      ctx.lineTo(-tl * 1.05, k * th);
    }
    ctx.stroke();
    if (st === "leon" || st === "pierre") {
      // rows of spots on the soft tail (lionfish) / reef-grouper speckles
      ctx.fillStyle = st === "leon" ? pal.spot || "#45190c" : pal.spot || "#ffffff";
      ctx.globalAlpha = st === "leon" ? 0.6 : 0.85;
      for (let i = 0; i < 9; i++) {
        ctx.beginPath();
        ctx.arc(-tl * (0.3 + (i % 3) * 0.26), th * (-0.5 + Math.floor(i / 3) * 0.5) * (0.5 + (i % 3) * 0.22), ry * 0.05, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    if (st === "shark") {
      // black tips on both tail lobes
      ctx.fillStyle = pal.spot || "#11151c";
      ctx.beginPath();
      ctx.arc(-tl * 1.08, -th * 1.25, tl * 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(-tl * 0.74, th * 0.8, tl * 0.2, 0, Math.PI * 2);
      ctx.fill();
    }
    if (st === "clown" || st === "layla" || st === "boris" || st === "tang" || st === "idol") {
      ctx.beginPath();
      tailPath();
      ctx.closePath();
      ctx.strokeStyle = st === "clown" || st === "tang" ? BLK : st === "layla" ? pal.fin : "rgba(255,255,255,0.85)";
      ctx.lineWidth = rim * (st === "clown" ? 2.2 : 2.6);
      ctx.stroke();
    }
    ctx.restore();
  }
  ctx.beginPath();
  tailPath();
  ctx.closePath();
  ctx.strokeStyle = out(0.5);
  ctx.lineWidth = rim * 0.9;
  ctx.stroke();
  if (st === "layla") {
    // trailing tail filaments of an adult queen triggerfish
    ctx.strokeStyle = tailBase;
    ctx.lineWidth = rim * 0.9;
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(-tl * 1.04, s * th * 0.98);
      ctx.quadraticCurveTo(-tl * 1.22, s * th * 1.04, -tl * 1.36, s * th * 1.0 + wag * th * 0.1);
      ctx.stroke();
    }
  }
  ctx.restore();

  // ---------- 2. DORSAL / ANAL / PELVIC FINS (behind the body) ----------
  const gUp: [number, number, number, number] = [bx, V(-1.5), bx, V(-0.7)];
  const gDn: [number, number, number, number] = [bx, V(1.45), bx, V(0.7)];

  if (st === "andy") {
    // Angelfish: continuous dorsal & anal fins ending in swept-back trailing lobes, electric-blue margins
    const edge = pal.stripe || "#5aa0ff";
    fin(
      () => {
        ctx.moveTo(X(0.44), V(-0.76));
        ctx.bezierCurveTo(X(0.12), V(-1.3), X(-0.52), V(-1.4), X(-1.04) + sw, V(-1.3));
        ctx.quadraticCurveTo(X(-0.9), V(-0.8), X(-0.86), V(-0.1));
        ctx.lineTo(X(-0.2), V(-0.5));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(0.3), V(-0.8), X(-0.8), V(-0.4), X(0.1), V(-1.3), X(-1.0), V(-1.2), 9), margin: edge, marginW: 2.4 }
    );
    fin(
      () => {
        ctx.moveTo(X(0.08), V(0.88));
        ctx.bezierCurveTo(X(-0.18), V(1.3), X(-0.58), V(1.38), X(-1.02) + sw, V(1.24));
        ctx.quadraticCurveTo(X(-0.9), V(0.76), X(-0.86), V(0.1));
        ctx.lineTo(X(-0.2), V(0.5));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(0.0), V(0.85), X(-0.8), V(0.4), X(-0.2), V(1.3), X(-1.0), V(1.15), 8), margin: edge, marginW: 2.4 }
    );
    fin(
      () => {
        ctx.moveTo(X(0.36), V(0.86));
        ctx.quadraticCurveTo(X(0.26), V(1.2), X(0.04) + sw * 0.5, V(1.42));
        ctx.quadraticCurveTo(X(0.1), V(1.08), X(0.14), V(0.92));
      },
      "#ffe37a",
      finBase,
      gDn
    );
  } else if (st === "boris") {
    // Butterflyfish: rounded continuous dorsal (spiny in front) & anal fin, pointed pelvic fin
    fin(
      () => {
        ctx.moveTo(X(0.52), V(-0.68));
        for (let i = 0; i < 5; i++) {
          ctx.lineTo(X(0.42 - i * 0.12), V(-1.02 - i * 0.055));
          ctx.lineTo(X(0.35 - i * 0.12), V(-0.94 - i * 0.055));
        }
        ctx.bezierCurveTo(X(-0.4), V(-1.34), X(-0.82), V(-1.24), X(-0.94) + sw, V(-0.9));
        ctx.quadraticCurveTo(X(-0.98), V(-0.5), X(-0.86), V(-0.1));
        ctx.lineTo(X(-0.2), V(-0.5));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(0.4), V(-0.75), X(-0.8), V(-0.4), X(0.3), V(-1.2), X(-0.95), V(-1.0), 10) }
    );
    fin(
      () => {
        ctx.moveTo(X(0.04), V(0.9));
        ctx.bezierCurveTo(X(-0.22), V(1.26), X(-0.66), V(1.3), X(-0.94) + sw, V(0.9));
        ctx.quadraticCurveTo(X(-0.98), V(0.5), X(-0.86), V(0.1));
        ctx.lineTo(X(-0.2), V(0.5));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(0.0), V(0.85), X(-0.8), V(0.4), X(-0.2), V(1.25), X(-0.95), V(0.95), 8) }
    );
    fin(
      () => {
        ctx.moveTo(X(0.36), V(0.86));
        ctx.quadraticCurveTo(X(0.28), V(1.18), X(0.08) + sw * 0.5, V(1.38));
        ctx.quadraticCurveTo(X(0.12), V(1.06), X(0.16), V(0.92));
      },
      finLight,
      finBase,
      gDn
    );
  } else if (st === "layla") {
    // Queen triggerfish: locking "trigger" spine + tall pointed second dorsal & anal fins set far back
    fin(
      () => {
        ctx.moveTo(X(0.34), V(-0.84));
        ctx.lineTo(X(0.16), V(-1.34));
        ctx.quadraticCurveTo(X(0.06), V(-1.04), X(-0.06), V(-0.92));
      },
      mixHex(pal.body, pal.dark, 0.3),
      pal.dark,
      gUp
    );
    fin(
      () => {
        ctx.moveTo(X(-0.1), V(-0.88));
        ctx.bezierCurveTo(X(-0.18), V(-1.5), X(-0.5), V(-1.66), X(-0.96) + sw * 1.6, V(-1.58));
        ctx.bezierCurveTo(X(-0.62), V(-1.2), X(-0.72), V(-0.7), X(-0.84), V(-0.2));
        ctx.lineTo(X(-0.3), V(-0.5));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(-0.15), V(-0.85), X(-0.8), V(-0.3), X(-0.3), V(-1.5), X(-0.95), V(-1.5), 8), margin: mixHex(finBase, "#1a5fd0", 0.6), marginW: 2.2 }
    );
    fin(
      () => {
        ctx.moveTo(X(-0.14), V(0.86));
        ctx.bezierCurveTo(X(-0.22), V(1.42), X(-0.5), V(1.54), X(-0.94) + sw * 1.6, V(1.46));
        ctx.bezierCurveTo(X(-0.62), V(1.1), X(-0.72), V(0.66), X(-0.84), V(0.2));
        ctx.lineTo(X(-0.3), V(0.5));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(-0.18), V(0.85), X(-0.8), V(0.3), X(-0.3), V(1.4), X(-0.95), V(1.4), 8), margin: mixHex(finBase, "#1a5fd0", 0.6), marginW: 2.2 }
    );
  } else if (st === "leon") {
    // Lionfish: 11 long venomous dorsal spines, each with its own membrane flag + banded shaft
    const n = 11;
    for (let i = 0; i < n; i++) {
      const f = i / (n - 1);
      const x0 = X(0.36 - f * 0.86),
        y0 = V(-0.84 + Math.abs(f - 0.4) * 0.14);
      const ang = -Math.PI * 0.55 - f * 0.5 + wag2 * 0.06;
      const len = ry * (1.18 - Math.abs(f - 0.35) * 0.75);
      const tx = x0 + Math.cos(ang) * len,
        ty = y0 + Math.sin(ang) * len;
      ctx.beginPath();
      ctx.moveTo(x0 - rx * 0.075, y0 + ry * 0.08);
      ctx.quadraticCurveTo((x0 + tx) / 2 - rx * 0.1, (y0 + ty) / 2, tx, ty);
      ctx.lineTo(x0 + rx * 0.02, y0 + ry * 0.08);
      ctx.closePath();
      ctx.fillStyle = rgbaHex(i % 2 ? "#fff5eb" : finBase, 0.82);
      ctx.fill();
      ctx.strokeStyle = out(0.4);
      ctx.lineWidth = rim * 0.7;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(x0, y0 + ry * 0.06);
      ctx.lineTo(tx, ty);
      ctx.lineWidth = Math.max(1.3, rx * 0.034);
      ctx.strokeStyle = "#fff5eb";
      ctx.stroke();
      ctx.setLineDash([len * 0.13, len * 0.15]);
      ctx.strokeStyle = pal.dark;
      ctx.stroke();
      ctx.setLineDash([]);
    }
    const spotFin = (pts: [number, number][]) => {
      ctx.fillStyle = rgbaHex(pal.spot || "#45190c", 0.6);
      for (const [u, v] of pts) {
        ctx.beginPath();
        ctx.arc(X(u), V(v), ry * 0.045, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    fin(
      () => {
        ctx.moveTo(X(-0.5), V(-0.78));
        ctx.bezierCurveTo(X(-0.55), V(-1.34), X(-0.94), V(-1.24), X(-0.94) + sw, V(-0.62));
        ctx.lineTo(X(-0.84), V(-0.18));
      },
      "#fff7ee",
      rgbaHex(finBase, 0.85),
      gUp
    );
    spotFin([[-0.64, -0.98], [-0.76, -0.82], [-0.8, -1.04], [-0.7, -0.62]]);
    fin(
      () => {
        ctx.moveTo(X(-0.42), V(0.82));
        ctx.bezierCurveTo(X(-0.5), V(1.34), X(-0.92), V(1.22), X(-0.92) + sw, V(0.6));
        ctx.lineTo(X(-0.84), V(0.18));
      },
      "#fff7ee",
      rgbaHex(finBase, 0.85),
      gDn
    );
    spotFin([[-0.6, 1.0], [-0.74, 0.84], [-0.78, 1.04], [-0.7, 0.62]]);
    fin(
      () => {
        ctx.moveTo(X(0.2), V(0.9));
        ctx.quadraticCurveTo(X(0.1), V(1.4), X(-0.22) + sw, V(1.62));
        ctx.quadraticCurveTo(X(-0.08), V(1.14), X(0.0), V(0.94));
      },
      pal.dark,
      finDark,
      gDn
    );
  } else if (st === "peter") {
    // John Dory: tall dorsal spines trailing long filaments, low soft dorsal & anal fins, long pelvic fins
    const n = 8;
    ctx.beginPath();
    ctx.moveTo(X(0.36), V(-0.8));
    for (let i = 0; i < n; i++) {
      ctx.lineTo(X(0.34 - i * 0.085), V(-1.34 + i * 0.03));
      ctx.lineTo(X(0.29 - i * 0.085), V(-1.06 + i * 0.02));
    }
    ctx.lineTo(X(-0.36), V(-0.84));
    ctx.closePath();
    ctx.fillStyle = rgbaHex(finBase, 0.85);
    ctx.fill();
    ctx.strokeStyle = out(0.5);
    ctx.lineWidth = rim * 0.8;
    ctx.stroke();
    for (let i = 0; i < n; i++) {
      const sx0 = X(0.34 - i * 0.085),
        sy0 = V(-1.34 + i * 0.03);
      ctx.beginPath();
      ctx.moveTo(sx0 + rx * 0.02, V(-0.84));
      ctx.lineTo(sx0, sy0);
      ctx.strokeStyle = "#ffe43b";
      ctx.lineWidth = Math.max(1.3, rx * 0.032);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(sx0, sy0);
      ctx.quadraticCurveTo(sx0 - rx * 0.2, sy0 - ry * 0.3, sx0 - rx * (0.5 + (i % 3) * 0.06) + sw * 2, sy0 - ry * (0.12 + (i % 2) * 0.1) + wag * ry * 0.05);
      ctx.strokeStyle = finLight;
      ctx.lineWidth = Math.max(1, rim * 0.8);
      ctx.stroke();
    }
    fin(
      () => {
        ctx.moveTo(X(-0.3), V(-0.86));
        ctx.quadraticCurveTo(X(-0.62), V(-1.16), X(-0.9) + sw, V(-0.62));
        ctx.lineTo(X(-0.82), V(-0.2));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(-0.35), V(-0.8), X(-0.82), V(-0.3), X(-0.5), V(-1.1), X(-0.9), V(-0.7), 6) }
    );
    fin(
      () => {
        ctx.moveTo(X(-0.1), V(0.9));
        ctx.lineTo(X(-0.16), V(1.2));
        ctx.lineTo(X(-0.24), V(1.0));
        ctx.lineTo(X(-0.3), V(1.22));
        ctx.quadraticCurveTo(X(-0.62), V(1.2), X(-0.9) + sw, V(0.62));
        ctx.lineTo(X(-0.82), V(0.2));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(-0.3), V(0.8), X(-0.82), V(0.3), X(-0.45), V(1.15), X(-0.9), V(0.7), 6) }
    );
    fin(
      () => {
        ctx.moveTo(X(0.36), V(0.86));
        ctx.quadraticCurveTo(X(0.32), V(1.44), X(-0.04) + sw, V(1.6));
        ctx.quadraticCurveTo(X(0.1), V(1.2), X(0.16), V(0.92));
      },
      finDark,
      finBase,
      gDn,
      { rays: rays(X(0.34), V(0.9), X(0.18), V(0.92), X(0.2), V(1.5), X(-0.02), V(1.56), 4) }
    );
  } else if (st === "orca") {
    // Killer whale: tall dorsal fin, no anal fin (it is a mammal!)
    fin(
      () => {
        ctx.moveTo(X(0.16), V(-0.88));
        ctx.quadraticCurveTo(X(0.0), V(-1.7), X(-0.3) + sw * 0.4, V(-1.8));
        ctx.quadraticCurveTo(X(-0.22), V(-1.2), X(-0.4), V(-0.8));
      },
      mixHex(pal.fin, "#5a6478", 0.35),
      pal.fin,
      gUp
    );
  } else if (st === "barracuda" || st === "minnow") {
    const pike = st === "barracuda";
    // first dorsal
    fin(
      () => {
        ctx.moveTo(X(pike ? 0.1 : 0.04), V(-0.94));
        ctx.lineTo(X(pike ? -0.06 : -0.14), V(pike ? -1.85 : -1.6));
        ctx.quadraticCurveTo(X(pike ? -0.12 : -0.22), V(-1.2), X(pike ? -0.2 : -0.36), V(-0.9));
      },
      finLight,
      finBase,
      gUp
    );
    if (pike) {
      // widely separated second dorsal, mirrored by the anal fin
      fin(
        () => {
          ctx.moveTo(X(-0.5), V(-0.8));
          ctx.lineTo(X(-0.66) + sw * 0.5, V(-1.7));
          ctx.quadraticCurveTo(X(-0.7), V(-1.1), X(-0.78), V(-0.6));
        },
        finLight,
        finBase,
        gUp
      );
    }
    fin(
      () => {
        ctx.moveTo(X(-0.5), V(0.8));
        ctx.lineTo(X(-0.66) + sw * 0.5, V(pike ? 1.66 : 1.34));
        ctx.quadraticCurveTo(X(-0.7), V(1.05), X(-0.78), V(0.6));
      },
      finLight,
      finBase,
      gDn
    );
    fin(
      () => {
        ctx.moveTo(X(0.04), V(0.92));
        ctx.lineTo(X(-0.14), V(pike ? 1.6 : 1.4));
        ctx.lineTo(X(-0.16), V(0.92));
      },
      finLight,
      finBase,
      gDn
    );
  } else if (st === "clown") {
    // Clownfish: two-lobed dorsal, rounded fins — all edged in black
    fin(
      () => {
        ctx.moveTo(X(0.26), V(-0.84));
        ctx.quadraticCurveTo(X(0.06), V(-1.34), X(-0.18), V(-1.1));
        ctx.quadraticCurveTo(X(-0.44), V(-1.38), X(-0.76) + sw, V(-1.0));
        ctx.quadraticCurveTo(X(-0.86), V(-0.72), X(-0.8), V(-0.16));
      },
      finLight,
      finBase,
      gUp,
      { margin: BLK, marginW: 2.1, rays: rays(X(0.2), V(-0.8), X(-0.78), V(-0.4), X(0.05), V(-1.3), X(-0.8), V(-1.05), 9) }
    );
    fin(
      () => {
        ctx.moveTo(X(-0.22), V(0.84));
        ctx.bezierCurveTo(X(-0.34), V(1.3), X(-0.78), V(1.22), X(-0.84) + sw, V(0.74));
        ctx.lineTo(X(-0.8), V(0.18));
      },
      finLight,
      finBase,
      gDn,
      { margin: BLK, marginW: 2.1 }
    );
    fin(
      () => {
        ctx.moveTo(X(0.3), V(0.88));
        ctx.quadraticCurveTo(X(0.3), V(1.34), X(0.02) + sw * 0.5, V(1.3));
        ctx.quadraticCurveTo(X(0.02), V(1.0), X(0.08), V(0.9));
      },
      finLight,
      finBase,
      gDn,
      { margin: BLK, marginW: 2.1 }
    );
  } else if (st === "shark") {
    // Blacktip reef shark: tall first dorsal, small second dorsal & anal fin, pelvic fin, each dipped in black
    const tip = pal.spot || "#11151c";
    const d1 = () => {
      ctx.moveTo(X(0.14), V(-0.9));
      ctx.quadraticCurveTo(X(0.0), V(-1.72), X(-0.26) + sw * 0.4, V(-1.86));
      ctx.quadraticCurveTo(X(-0.2), V(-1.25), X(-0.38), V(-0.8));
    };
    fin(d1, finLight, finBase, gUp);
    dip(d1, X(-0.26) + sw * 0.4, V(-1.86), ry * 0.44, tip);
    const d2 = () => {
      ctx.moveTo(X(-0.58), V(-0.62));
      ctx.lineTo(X(-0.7) + sw * 0.5, V(-1.04));
      ctx.quadraticCurveTo(X(-0.72), V(-0.7), X(-0.8), V(-0.46));
    };
    fin(d2, finLight, finBase, gUp);
    const an = () => {
      ctx.moveTo(X(-0.56), V(0.62));
      ctx.lineTo(X(-0.7) + sw * 0.5, V(1.02));
      ctx.quadraticCurveTo(X(-0.72), V(0.7), X(-0.8), V(0.46));
    };
    fin(an, finLight, finBase, gDn);
    dip(an, X(-0.7) + sw * 0.5, V(1.02), ry * 0.22, tip);
    const pv = () => {
      ctx.moveTo(X(-0.18), V(0.86));
      ctx.lineTo(X(-0.38), V(1.34));
      ctx.lineTo(X(-0.42), V(0.84));
    };
    fin(pv, finLight, finBase, gDn);
    dip(pv, X(-0.38), V(1.34), ry * 0.22, tip);
  } else if (st === "tang") {
    // Blue tang: low continuous dorsal & anal fins edged in black
    const edge = pal.stripe || "#0b1026";
    fin(
      () => {
        ctx.moveTo(X(0.5), V(-0.72));
        ctx.bezierCurveTo(X(0.2), V(-1.2), X(-0.5), V(-1.26), X(-0.93) + sw, V(-0.92));
        ctx.quadraticCurveTo(X(-0.97), V(-0.5), X(-0.86), V(-0.1));
        ctx.lineTo(X(-0.2), V(-0.5));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(0.4), V(-0.75), X(-0.8), V(-0.4), X(0.25), V(-1.18), X(-0.93), V(-1.0), 11), margin: edge, marginW: 2.2 }
    );
    fin(
      () => {
        ctx.moveTo(X(0.06), V(0.9));
        ctx.bezierCurveTo(X(-0.2), V(1.2), X(-0.6), V(1.26), X(-0.93) + sw, V(0.9));
        ctx.quadraticCurveTo(X(-0.97), V(0.5), X(-0.86), V(0.1));
        ctx.lineTo(X(-0.2), V(0.5));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(0.0), V(0.85), X(-0.8), V(0.4), X(-0.2), V(1.2), X(-0.93), V(0.98), 9), margin: edge, marginW: 2.2 }
    );
    fin(
      () => {
        ctx.moveTo(X(0.36), V(0.86));
        ctx.quadraticCurveTo(X(0.28), V(1.16), X(0.08) + sw * 0.5, V(1.34));
        ctx.quadraticCurveTo(X(0.12), V(1.05), X(0.16), V(0.92));
      },
      finLight,
      finBase,
      gDn
    );
  } else if (st === "idol") {
    // Moorish idol: sickle dorsal fin drawn out into a long trailing streamer
    const blk = pal.stripe || "#16181f";
    const dorsal = () => {
      ctx.moveTo(X(0.38), V(-0.78));
      ctx.bezierCurveTo(X(0.34), V(-1.5), X(0.0), V(-1.86), X(-0.62) + sw, V(-1.96));
      ctx.quadraticCurveTo(X(-0.28), V(-1.42), X(-0.46), V(-0.84));
      ctx.lineTo(X(-0.84), V(-0.2));
      ctx.lineTo(X(-0.2), V(-0.5));
    };
    fin(dorsal, "#ffffff", finBase, gUp, { rays: rays(X(0.3), V(-0.8), X(-0.5), V(-0.7), X(0.2), V(-1.5), X(-0.6), V(-1.9), 7) });
    dip(dorsal, X(0.36), V(-1.0), ry * 0.4, blk);
    dip(dorsal, X(-0.56), V(-0.9), ry * 0.46, blk);
    ctx.beginPath();
    ctx.moveTo(X(-0.56) + sw, V(-1.95));
    ctx.bezierCurveTo(X(-0.9) + sw * 1.5, V(-2.0), X(-1.25) + sw * 2.5, V(-1.9), X(-1.5) + sw * 3.5, V(-1.6) + wag * ry * 0.1);
    ctx.strokeStyle = out(0.6);
    ctx.lineWidth = Math.max(2, rx * 0.07);
    ctx.stroke();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = Math.max(1.2, rx * 0.04);
    ctx.stroke();
    const anal = () => {
      ctx.moveTo(X(0.02), V(0.9));
      ctx.bezierCurveTo(X(-0.2), V(1.4), X(-0.5), V(1.5), X(-0.68) + sw, V(1.38));
      ctx.quadraticCurveTo(X(-0.7), V(0.9), X(-0.86), V(0.12));
      ctx.lineTo(X(-0.2), V(0.5));
    };
    fin(anal, "#ffffff", finBase, gDn, { rays: rays(X(0.0), V(0.85), X(-0.8), V(0.4), X(-0.2), V(1.35), X(-0.7), V(1.3), 7) });
    dip(anal, X(-0.56), V(0.92), ry * 0.5, blk);
    fin(
      () => {
        ctx.moveTo(X(0.36), V(0.86));
        ctx.quadraticCurveTo(X(0.26), V(1.2), X(0.04) + sw * 0.5, V(1.4));
        ctx.quadraticCurveTo(X(0.1), V(1.08), X(0.14), V(0.92));
      },
      blk,
      blk,
      gDn
    );
  } else if (st === "sailfish") {
    // Sailfish: enormous sail-like dorsal, tiny second dorsal, twin anal fins, thread-like pelvic fins
    const sail = () => {
      ctx.moveTo(X(0.56), V(-0.72));
      const n = 10;
      for (let i = 0; i <= n; i++) {
        const f = i / n;
        const tx = X(0.46 - f * 0.92) + sw * (0.6 + f),
          ty = V(-(2.3 + Math.sin(f * Math.PI) * 0.95 - (i === 0 ? 0.5 : 0)));
        if (i === 0) ctx.lineTo(tx, ty);
        else ctx.quadraticCurveTo(X(0.46 - (f - 0.5 / n) * 0.92) + sw * (0.6 + f), ty + ry * 0.34, tx, ty);
      }
      ctx.quadraticCurveTo(X(-0.56), V(-1.6), X(-0.6), V(-0.66));
    };
    fin(sail, finLight, finBase, [bx, V(-3.2), bx, V(-0.7)], { rays: rays(X(0.5), V(-0.75), X(-0.55), V(-0.7), X(0.46), V(-2.6), X(-0.46), V(-2.6), 11) });
    ctx.save();
    ctx.beginPath();
    sail();
    ctx.closePath();
    ctx.clip();
    ctx.fillStyle = rgbaHex(pal.spot || "#0c1a4c", 0.75);
    for (let i = 0; i < 18; i++) {
      const u = 0.4 - ((i * 0.7548776662) % 1) * 0.86,
        v = -(1.1 + ((i * 0.5698402909 + 0.3) % 1) * 1.8);
      ctx.beginPath();
      ctx.arc(X(u), V(v), rx * 0.028, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    fin(
      () => {
        ctx.moveTo(X(-0.64), V(-0.62));
        ctx.lineTo(X(-0.76) + sw * 0.5, V(-1.34));
        ctx.lineTo(X(-0.82), V(-0.5));
      },
      finLight,
      finBase,
      gUp
    );
    fin(
      () => {
        ctx.moveTo(X(-0.3), V(0.84));
        ctx.lineTo(X(-0.48) + sw * 0.4, V(1.7));
        ctx.lineTo(X(-0.54), V(0.8));
      },
      finLight,
      finBase,
      gDn
    );
    fin(
      () => {
        ctx.moveTo(X(-0.64), V(0.62));
        ctx.lineTo(X(-0.76) + sw * 0.5, V(1.3));
        ctx.lineTo(X(-0.82), V(0.5));
      },
      finLight,
      finBase,
      gDn
    );
    ctx.beginPath();
    ctx.moveTo(X(0.22), V(0.88));
    ctx.quadraticCurveTo(X(0.05), V(1.6), X(-0.3) + sw, V(2.05));
    ctx.strokeStyle = out(0.6);
    ctx.lineWidth = Math.max(1.6, rx * 0.045);
    ctx.stroke();
    ctx.strokeStyle = finBase;
    ctx.lineWidth = Math.max(1, rx * 0.025);
    ctx.stroke();
  } else if (st === "puffer") {
    // Porcupine pufferfish: a ring of short spines around the body + small soft fins set far back
    ctx.fillStyle = "#fff6dc";
    ctx.strokeStyle = out(0.6);
    ctx.lineWidth = rim * 0.7;
    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * Math.PI * 2 + 0.14;
      const c = Math.cos(a),
        sn = Math.sin(a);
      if (c > 0.72 || c < -0.9) continue; // keep the face & the tail stalk clear
      const bx0 = X(c * 0.92 - 0.04),
        by0 = V(sn * 0.94);
      const len = ry * (0.2 + (i % 2) * 0.06) * (1 + wag2 * 0.05);
      const px = -sn * rx * 0.05,
        py = c * ry * 0.05;
      ctx.beginPath();
      ctx.moveTo(bx0 + px, by0 + py);
      ctx.lineTo(bx0 + c * len, by0 + sn * len);
      ctx.lineTo(bx0 - px, by0 - py);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
    fin(
      () => {
        ctx.moveTo(X(-0.42), V(-0.84));
        ctx.bezierCurveTo(X(-0.46), V(-1.2), X(-0.82), V(-1.14), X(-0.84) + sw, V(-0.62));
        ctx.lineTo(X(-0.74), V(-0.36));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(-0.46), V(-0.8), X(-0.76), V(-0.4), X(-0.52), V(-1.14), X(-0.84), V(-0.72), 5) }
    );
    fin(
      () => {
        ctx.moveTo(X(-0.44), V(0.82));
        ctx.bezierCurveTo(X(-0.48), V(1.16), X(-0.82), V(1.1), X(-0.84) + sw, V(0.6));
        ctx.lineTo(X(-0.74), V(0.36));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(-0.48), V(0.8), X(-0.76), V(0.4), X(-0.54), V(1.1), X(-0.84), V(0.7), 5) }
    );
  } else if (st === "eddy") {
    // Deep-sea anglerfish: small soft fins set far back near the tail
    fin(
      () => {
        ctx.moveTo(X(-0.44), V(-0.8));
        ctx.bezierCurveTo(X(-0.5), V(-1.2), X(-0.88), V(-1.14), X(-0.9) + sw, V(-0.58));
        ctx.lineTo(X(-0.82), V(-0.18));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(-0.48), V(-0.8), X(-0.82), V(-0.3), X(-0.55), V(-1.15), X(-0.9), V(-0.7), 5) }
    );
    fin(
      () => {
        ctx.moveTo(X(-0.46), V(0.8));
        ctx.bezierCurveTo(X(-0.52), V(1.16), X(-0.88), V(1.1), X(-0.9) + sw, V(0.58));
        ctx.lineTo(X(-0.82), V(0.18));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(-0.5), V(0.8), X(-0.82), V(0.3), X(-0.56), V(1.1), X(-0.9), V(0.7), 5) }
    );
  } else {
    // Grouper (and any other perch-like fish): spiny serrated front dorsal + rounded soft rear lobe
    fin(
      () => {
        ctx.moveTo(X(0.34), V(-0.78));
        for (let i = 0; i < 7; i++) {
          ctx.lineTo(X(0.28 - i * 0.1), V(-1.26 + Math.abs(i - 2) * 0.03));
          ctx.lineTo(X(0.22 - i * 0.1), V(-1.04));
        }
        ctx.bezierCurveTo(X(-0.56), V(-1.36), X(-0.88), V(-1.2), X(-0.9) + sw, V(-0.72));
        ctx.quadraticCurveTo(X(-0.9), V(-0.4), X(-0.82), V(-0.18));
        ctx.lineTo(X(-0.2), V(-0.6));
      },
      finLight,
      finBase,
      gUp,
      { rays: rays(X(0.3), V(-0.8), X(-0.82), V(-0.4), X(0.26), V(-1.25), X(-0.9), V(-1.0), 11) }
    );
    fin(
      () => {
        ctx.moveTo(X(-0.24), V(0.82));
        ctx.bezierCurveTo(X(-0.38), V(1.28), X(-0.82), V(1.22), X(-0.86) + sw, V(0.74));
        ctx.lineTo(X(-0.8), V(0.18));
      },
      finLight,
      finBase,
      gDn,
      { rays: rays(X(-0.28), V(0.8), X(-0.8), V(0.4), X(-0.4), V(1.2), X(-0.86), V(0.8), 6) }
    );
    fin(
      () => {
        ctx.moveTo(X(0.3), V(0.86));
        ctx.quadraticCurveTo(X(0.28), V(1.34), X(0.0) + sw * 0.5, V(1.26));
        ctx.quadraticCurveTo(X(0.02), V(1.0), X(0.08), V(0.9));
      },
      finLight,
      finBase,
      gDn
    );
  }

  // ---------- 3. HINGED OPEN MOUTH INTERIOR ----------
  if (open > 0) {
    const snoutLift = open * ry * (disc ? 0.24 : 0.3);
    const upperX = X(disc ? 1.01 : st === "barracuda" ? 1.12 : longBody ? 1.02 : 1.02);
    const upperY = ry * (disc ? 0.12 : 0.04) - snoutLift;
    const hingeX = X(disc ? 0.64 - open * 0.08 : longBody ? 0.44 : st === "eddy" || st === "pierre" ? 0.42 - open * 0.06 : 0.54 - open * 0.09);
    const hingeY = ry * 0.17;
    const jawDrop = open * ry * (disc ? 0.46 : st === "eddy" ? 0.66 : 0.54);
    const lowerX = X((st === "barracuda" ? 1.12 : 0.96) - open * 0.05);
    const lowerY = ry * 0.24 + jawDrop;

    ctx.beginPath();
    ctx.moveTo(upperX, upperY);
    ctx.quadraticCurveTo(X(0.86 - open * 0.05), (upperY + lowerY) * 0.5, lowerX, lowerY);
    ctx.lineTo(hingeX - rx * 0.07, hingeY + ry * 0.16);
    ctx.lineTo(hingeX - rx * 0.07, hingeY - ry * 0.16);
    ctx.closePath();
    const mg = ctx.createRadialGradient(hingeX + rx * 0.08, hingeY + jawDrop * 0.3, ry * 0.04, (upperX + lowerX) * 0.5, (upperY + lowerY) * 0.5, Math.max(ry * 0.55, rx * 0.2));
    mg.addColorStop(0, "#2b060f");
    mg.addColorStop(0.65, "#6b1528");
    mg.addColorStop(1, "#9c283e");
    ctx.fillStyle = mg;
    ctx.fill();

    ctx.save();
    ctx.clip();
    ctx.beginPath();
    ctx.ellipse((hingeX + lowerX) * 0.54, lowerY - ry * 0.04, rx * (0.18 + open * 0.06), ry * (0.1 + open * 0.08), 0.12, 0, Math.PI * 2);
    ctx.fillStyle = "#e85d88";
    ctx.fill();
    if (sp.teeth || sp.underbite) {
      ctx.fillStyle = "#fff8ee";
      const nT = st === "eddy" || st === "barracuda" || st === "shark" ? 5 : 3;
      const tw = rx * (nT === 5 ? 0.028 : 0.04),
        tlen = st === "eddy" ? 0.26 : 0.14;
      for (let i = 0; i < nT; i++) {
        const t = (i + 0.5) / nT;
        const k = 0.3 + t * 0.62;
        const ux = hingeX + (upperX - hingeX) * k,
          uy = upperY + (hingeY - upperY) * (1 - k);
        ctx.beginPath();
        ctx.moveTo(ux - tw, uy - ry * 0.02);
        ctx.lineTo(ux, uy + ry * tlen * open + ry * 0.03);
        ctx.lineTo(ux + tw, uy - ry * 0.02);
        ctx.closePath();
        ctx.fill();
        const lx = hingeX + (lowerX - hingeX) * k,
          ly = hingeY + (lowerY - hingeY) * k;
        ctx.beginPath();
        ctx.moveTo(lx - tw, ly + ry * 0.03);
        ctx.lineTo(lx, ly - ry * (tlen + 0.02) * open - ry * 0.03);
        ctx.lineTo(lx + tw, ly + ry * 0.03);
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.restore();
  }

  // ---------- 4. BODY: soft airbrushed volume + species markings ----------
  buildBodyPath(ctx, sp, bx, rx, ry, jawState);
  const baseGrad = ctx.createLinearGradient(bx, -ry * 1.05, bx, ry * 1.05);
  baseGrad.addColorStop(0, pal.dark);
  baseGrad.addColorStop(0.45, pal.body);
  baseGrad.addColorStop(0.85, mixHex(pal.body, pal.belly, 0.5));
  baseGrad.addColorStop(1, mixHex(pal.dark, pal.belly, 0.35));
  ctx.fillStyle = baseGrad;
  ctx.fill();

  ctx.save();
  ctx.clip();

  if (st !== "orca") {
    const coreGrad = ctx.createRadialGradient(X(-0.05), -ry * 0.05, ry * 0.08, X(-0.05), 0, Math.max(rx, ry) * 0.95);
    coreGrad.addColorStop(0, mixHex(pal.belly, "#ffffff", 0.25));
    coreGrad.addColorStop(0.52, rgbaHex(pal.body, 0.35));
    coreGrad.addColorStop(1, rgbaHex(pal.dark, 0.65));
    ctx.fillStyle = coreGrad;
    ctx.fillRect(X(-1.3), -ry * 1.3, rx * 2.7, ry * 2.6);
  }
  if (st === "minnow" || st === "barracuda" || st === "sailfish") {
    // counter-shading of open-water fish: dark blue-green back, mirror-silver flanks
    const cs = ctx.createLinearGradient(0, -ry, 0, ry * 0.2);
    cs.addColorStop(0, rgbaHex(pal.dark, 0.85));
    cs.addColorStop(1, rgbaHex(pal.dark, 0));
    ctx.fillStyle = cs;
    ctx.fillRect(X(-1.2), -ry * 1.2, rx * 2.6, ry * 1.4);
  }

  // overlapping scales on the flank (large sprites only)
  if (W >= 200 && st !== "orca" && st !== "eddy" && st !== "barracuda" && st !== "minnow" && st !== "shark" && st !== "puffer" && st !== "sailfish") {
    ctx.strokeStyle = rgbaHex(pal.dark, 0.2);
    ctx.lineWidth = Math.max(0.8, W * 0.004);
    const sr = rx * 0.085;
    for (let j = -6; j <= 6; j++)
      for (let i = -8; i <= 2; i++) {
        ctx.beginPath();
        ctx.arc(X(i * 0.15 + (j & 1 ? 0.075 : 0)), j * sr * 1.45, sr, Math.PI - 1.05, Math.PI + 1.05);
        ctx.stroke();
      }
  }

  const band = (u: number, w: number, bow: number, col: string, top = -1.2, bot = 1.2) => {
    ctx.beginPath();
    ctx.moveTo(X(u - w / 2 + 0.03), V(top));
    ctx.quadraticCurveTo(X(u - w / 2 - 0.06 + bow), V((top + bot) / 2), X(u - w / 2 + 0.03), V(bot));
    ctx.lineTo(X(u + w / 2 + 0.03), V(bot));
    ctx.quadraticCurveTo(X(u + w / 2 - 0.04 + bow * 1.6), V((top + bot) / 2), X(u + w / 2 + 0.03), V(top));
    ctx.closePath();
    ctx.fillStyle = col;
    ctx.fill();
  };

  if (st === "orca") {
    // white chin/belly with the flank lobe sweeping up behind the dorsal fin
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.moveTo(X(1.15), V(0.2));
    ctx.bezierCurveTo(X(0.55), V(0.24), X(0.1), V(0.5), X(-0.2), V(0.4));
    ctx.bezierCurveTo(X(-0.42), V(0.3), X(-0.56), V(-0.12), X(-0.78), V(0.06));
    ctx.quadraticCurveTo(X(-0.56), V(0.44), X(-1.05), V(0.5));
    ctx.lineTo(X(-1.05), V(1.3));
    ctx.lineTo(X(1.2), V(1.3));
    ctx.closePath();
    ctx.fill();
    // oval white eye patch above & behind the eye
    ctx.save();
    ctx.translate(X(0.47), V(-0.4));
    ctx.rotate(-0.2);
    ctx.beginPath();
    ctx.ellipse(0, 0, rx * 0.2, ry * 0.15, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    // grey saddle patch behind the dorsal fin
    ctx.fillStyle = "rgba(150, 160, 180, 0.55)";
    ctx.beginPath();
    ctx.moveTo(X(-0.34), V(-0.82));
    ctx.quadraticCurveTo(X(-0.5), V(-0.3), X(-0.24), V(-0.24));
    ctx.quadraticCurveTo(X(-0.56), V(-0.4), X(-0.72), V(-0.62));
    ctx.quadraticCurveTo(X(-0.5), V(-0.84), X(-0.34), V(-0.82));
    ctx.fill();
  } else if (st === "andy") {
    // curved vertical bars with dark edging (regal / flame angelfish pattern)
    const stCol = pal.stripe || "#df22ff";
    const stGlow = mixHex(stCol, "#ffffff", 0.42);
    for (const [u, k] of [[-0.68, 0.8], [-0.42, 1], [-0.15, 1.05], [0.12, 1], [0.38, 0.85]]) {
      const w = rx * 0.085 * k;
      ctx.beginPath();
      ctx.moveTo(X(u + 0.08), V(-1.15));
      ctx.quadraticCurveTo(X(u - 0.13), 0, X(u + 0.08), V(1.15));
      ctx.strokeStyle = rgbaHex(pal.dark, 0.6);
      ctx.lineWidth = w * 1.75;
      ctx.stroke();
      ctx.strokeStyle = stCol;
      ctx.lineWidth = w;
      ctx.stroke();
      ctx.strokeStyle = rgbaHex(stGlow, 0.7);
      ctx.lineWidth = w * 0.36;
      ctx.stroke();
    }
  } else if (st === "boris") {
    band(-0.5, 0.2, 0, pal.stripe || "#3562c9");
    band(-0.06, 0.22, 0, pal.stripe || "#3562c9");
    // black eye-bar that hides the real eye ...
    ctx.fillStyle = pal.spot || "#18294d";
    ctx.beginPath();
    ctx.moveTo(X(0.7), V(-1.1));
    ctx.quadraticCurveTo(X(0.92), V(-0.2), X(0.62), V(1.0));
    ctx.lineTo(X(0.46), V(1.0));
    ctx.quadraticCurveTo(X(0.72), V(-0.2), X(0.52), V(-1.1));
    ctx.closePath();
    ctx.fill();
    // ... and a false eye-spot near the tail to fool predators
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(X(-0.58), V(-0.5), ry * 0.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = pal.spot || "#18294d";
    ctx.beginPath();
    ctx.arc(X(-0.58), V(-0.5), ry * 0.14, 0, Math.PI * 2);
    ctx.fill();
  } else if (st === "layla") {
    const bl = pal.stripe || "#28b2d4";
    ctx.strokeStyle = bl;
    ctx.lineWidth = ry * 0.085;
    // two blue lines curving from the snout to the pectoral base
    ctx.beginPath();
    ctx.moveTo(X(1.02), V(0.0));
    ctx.quadraticCurveTo(X(0.6), V(0.26), X(0.2), V(0.4));
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(X(0.94), V(0.24));
    ctx.quadraticCurveTo(X(0.6), V(0.5), X(0.3), V(0.68));
    ctx.stroke();
    // streaks radiating from the high-set eye
    ctx.lineWidth = ry * 0.05;
    for (let i = 0; i < 6; i++) {
      const a = -2.9 + i * 0.5;
      ctx.beginPath();
      ctx.moveTo(X(0.48) + Math.cos(a) * ry * 0.34, V(-0.42) + Math.sin(a) * ry * 0.34);
      ctx.lineTo(X(0.48) + Math.cos(a) * ry * 0.56, V(-0.42) + Math.sin(a) * ry * 0.56);
      ctx.stroke();
    }
    band(-0.8, 0.1, 0, rgbaHex(bl, 0.9));
  } else if (st === "pierre") {
    // coral grouper: many small pale-blue spots with dark halos over head and body
    for (let i = 0; i < 30; i++) {
      const u = -0.9 + ((i * 0.7548776662 + 0.31) % 1) * 1.75,
        v = -0.85 + ((i * 0.5698402909 + 0.17) % 1) * 1.6,
        r = rx * (0.03 + (i % 3) * 0.008);
      ctx.fillStyle = rgbaHex(pal.dark, 0.45);
      ctx.beginPath();
      ctx.arc(X(u), V(v), r * 1.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = rgbaHex(pal.spot || "#ffffff", 0.92);
      ctx.beginPath();
      ctx.arc(X(u), V(v), r, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (st === "leon") {
    // zebra banding from snout to tail: white bars with thin dark pin-stripes between
    for (let i = 0; i < 11; i++) {
      const u = -0.9 + i * 0.18;
      band(u, i % 2 ? 0.05 : 0.085, 0, i % 2 ? rgbaHex(pal.dark, 0.7) : pal.stripe || "#fff5eb");
    }
  } else if (st === "peter") {
    ctx.strokeStyle = rgbaHex(pal.stripe || "#ffe43b", 0.6);
    ctx.lineWidth = ry * 0.05;
    for (const yy of [-0.56, -0.3, 0.3, 0.56]) {
      ctx.beginPath();
      ctx.moveTo(X(-0.9), V(yy));
      ctx.bezierCurveTo(X(-0.5), V(yy - 0.12), X(-0.1), V(yy + 0.1), X(0.4), V(yy * 0.9));
      ctx.stroke();
    }
    // "St Peter's thumbprint": black spot with a yellow halo
    ctx.fillStyle = "#ffe43b";
    ctx.beginPath();
    ctx.ellipse(X(-0.14), V(0.0), rx * 0.25, ry * 0.25, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#142416";
    ctx.beginPath();
    ctx.ellipse(X(-0.14), V(0.0), rx * 0.17, ry * 0.17, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (st === "eddy") {
    // flabby warty skin + rows of glowing photophores
    for (let i = 0; i < 16; i++) {
      const u = -0.85 + ((i * 0.7548776662 + 0.4) % 1) * 1.5,
        v = -0.8 + ((i * 0.5698402909 + 0.2) % 1) * 1.3;
      ctx.fillStyle = rgbaHex(pal.dark, 0.3);
      ctx.beginPath();
      ctx.ellipse(X(u), V(v), rx * 0.06, ry * 0.045, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    const lc = pal.lure || "#d9ff42";
    for (let i = 0; i < 6; i++) {
      const px = X(-0.7 + i * 0.2),
        py = V(0.42 - Math.sin(i * 0.6) * 0.08);
      ctx.fillStyle = rgbaHex(lc, 0.45);
      ctx.beginPath();
      ctx.arc(px, py, ry * 0.07, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(px, py, ry * 0.03, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (st === "barracuda") {
    // dark chevron bars along the back + inky blotches on the rear flank
    ctx.strokeStyle = rgbaHex(pal.stripe || "#2d5563", 0.55);
    ctx.lineWidth = rx * 0.05;
    for (let i = 0; i < 9; i++) {
      const u = -0.84 + i * 0.15;
      ctx.beginPath();
      ctx.moveTo(X(u + 0.07), V(-1.0));
      ctx.lineTo(X(u - 0.02), V(-0.2));
      ctx.lineTo(X(u + 0.03), V(0.08));
      ctx.stroke();
    }
    ctx.fillStyle = rgbaHex(pal.spot || "#1b3540", 0.8);
    for (const [u, v, r] of [[-0.78, 0.3, 0.035], [-0.6, 0.5, 0.045], [-0.42, 0.32, 0.03], [-0.24, 0.54, 0.04], [-0.02, 0.4, 0.028]]) {
      ctx.beginPath();
      ctx.ellipse(X(u), V(v), rx * r * 1.3, rx * r, 0.3, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = Math.max(1, ry * 0.06);
    ctx.beginPath();
    ctx.moveTo(X(-0.9), V(0.02));
    ctx.quadraticCurveTo(X(0), V(-0.06), X(0.5), V(0.0));
    ctx.stroke();
  } else if (st === "minnow") {
    // bright silver lateral band of an anchovy
    ctx.strokeStyle = pal.stripe ? rgbaHex(pal.stripe, 0.92) : "rgba(232, 255, 255, 0.85)";
    ctx.lineWidth = ry * 0.3;
    ctx.beginPath();
    ctx.moveTo(X(-0.9), V(0.04));
    ctx.quadraticCurveTo(X(0), V(-0.08), X(0.48), V(0.0));
    ctx.stroke();
  } else if (st === "shark") {
    // crisp countershading: slate back, white belly meeting along a wavy line + pale flank streak
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.moveTo(X(1.25), V(0.02));
    ctx.bezierCurveTo(X(0.7), V(0.16), X(0.3), V(0.5), X(-0.1), V(0.36));
    ctx.bezierCurveTo(X(-0.4), V(0.26), X(-0.7), V(0.2), X(-1.05), V(0.1));
    ctx.lineTo(X(-1.05), V(1.3));
    ctx.lineTo(X(1.25), V(1.3));
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.55)";
    ctx.lineWidth = ry * 0.12;
    ctx.beginPath();
    ctx.moveTo(X(-0.1), V(0.02));
    ctx.quadraticCurveTo(X(-0.5), V(-0.2), X(-0.86), V(-0.04));
    ctx.stroke();
    // five gill slits instead of a bony gill cover
    ctx.strokeStyle = out(0.55);
    ctx.lineWidth = Math.max(1, rim * 0.9);
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(X(0.44 - i * 0.055), V(-0.22));
      ctx.quadraticCurveTo(X(0.41 - i * 0.055), V(0.04), X(0.44 - i * 0.055), V(0.3));
      ctx.stroke();
    }
  } else if (st === "tang") {
    // the black "painter's palette" of a blue tang with its oval blue window + yellow tail wedge
    ctx.fillStyle = pal.stripe || "#0b1026";
    ctx.beginPath();
    ctx.moveTo(X(0.78), V(-0.2));
    ctx.bezierCurveTo(X(0.5), V(-0.86), X(-0.3), V(-0.9), X(-0.95), V(-0.2));
    ctx.lineTo(X(-0.95), V(0.12));
    ctx.bezierCurveTo(X(-0.6), V(0.22), X(-0.2), V(0.5), X(0.16), V(0.42));
    ctx.bezierCurveTo(X(0.4), V(0.36), X(0.42), V(0.0), X(0.2), V(-0.06));
    ctx.bezierCurveTo(X(0.5), V(-0.3), X(0.6), V(-0.2), X(0.78), V(-0.2));
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = pal.body;
    ctx.beginPath();
    ctx.ellipse(X(-0.22), V(-0.2), rx * 0.36, ry * 0.2, -0.08, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = pal.spot || "#ffd91f";
    ctx.beginPath();
    ctx.moveTo(X(-0.5), V(-0.02));
    ctx.lineTo(X(-1.0), V(-0.26));
    ctx.lineTo(X(-1.0), V(0.26));
    ctx.closePath();
    ctx.fill();
  } else if (st === "idol") {
    // two broad black bands, yellow wash toward the tail, orange saddle on the tube snout
    const blk = pal.stripe || "#16181f";
    const yg = ctx.createLinearGradient(X(0.1), 0, X(-0.9), 0);
    yg.addColorStop(0, "rgba(255, 214, 64, 0)");
    yg.addColorStop(1, "rgba(255, 205, 50, 0.85)");
    ctx.fillStyle = yg;
    ctx.fillRect(X(-1.1), V(-1.2), rx * 1.3, ry * 2.4);
    band(0.56, 0.44, 0.04, blk);
    band(-0.52, 0.3, 0, blk);
    band(-0.9, 0.12, 0, blk);
    ctx.strokeStyle = "rgba(190, 225, 255, 0.9)";
    ctx.lineWidth = Math.max(1, rim * 0.9);
    for (const u of [0.33, -0.7]) {
      ctx.beginPath();
      ctx.moveTo(X(u + 0.03), V(-1.2));
      ctx.quadraticCurveTo(X(u - 0.05), 0, X(u + 0.03), V(1.2));
      ctx.stroke();
    }
    ctx.fillStyle = pal.spot || "#ffb52e";
    ctx.beginPath();
    ctx.ellipse(X(1.0), V(-0.1), rx * 0.13, ry * 0.09, -0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = blk;
    ctx.beginPath();
    ctx.ellipse(X(1.2), V(0.06), rx * 0.07, ry * 0.1, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (st === "sailfish") {
    // rows of pale-blue dots forming vertical bars on the flank + lateral line
    ctx.fillStyle = rgbaHex(pal.stripe || "#a6d4ff", 0.85);
    ctx.beginPath();
    for (let i = 0; i < 12; i++)
      for (let j = 0; j < 3; j++) {
        const dr = Math.max(1, rx * 0.016);
        ctx.moveTo(X(0.4 - i * 0.11) + dr, V(-0.3 + j * 0.3));
        ctx.arc(X(0.4 - i * 0.11), V(-0.3 + j * 0.3), dr, 0, Math.PI * 2);
      }
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = Math.max(1, ry * 0.07);
    ctx.beginPath();
    ctx.moveTo(X(-0.9), V(0.05));
    ctx.quadraticCurveTo(X(0), V(-0.02), X(0.6), V(0.06));
    ctx.stroke();
  } else if (st === "puffer") {
    // brown saddle blotches + small spots over the back
    ctx.fillStyle = rgbaHex(pal.spot || "#6b4312", 0.55);
    for (const [u, v, r] of [[0.25, -0.62, 0.17], [-0.2, -0.7, 0.2], [-0.6, -0.5, 0.15]]) {
      ctx.beginPath();
      ctx.ellipse(X(u), V(v), rx * r, ry * r * 0.7, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = rgbaHex(pal.spot || "#6b4312", 0.8);
    for (let i = 0; i < 18; i++) {
      const u = -0.85 + ((i * 0.7548776662 + 0.2) % 1) * 1.5,
        v = -0.8 + ((i * 0.5698402909 + 0.4) % 1) * 1.0;
      ctx.beginPath();
      ctx.arc(X(u), V(v), rx * 0.028, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (st === "clown") {
    // three white bars edged in black; the middle bar bulges forward
    const white = pal.stripe || "#fff9eb";
    for (const [u, w, bow] of [[0.4, 0.17, 0], [-0.16, 0.2, 0.1], [-0.8, 0.13, 0]]) {
      band(u, w, bow, white);
      ctx.strokeStyle = BLK;
      ctx.lineWidth = Math.max(1.2, rim * 1.5);
      ctx.stroke();
    }
  }

  if (st !== "clown" && st !== "leon") {
    for (const s of sp.stripes) band(s, 0.19, 0, pal.stripe || "#ffffff");
  }

  // gill cover (operculum) crease — fish only
  if (W >= 48 && st !== "orca" && st !== "shark") {
    const gx = X(disc ? 0.5 : st === "barracuda" || st === "sailfish" ? 0.5 : 0.36);
    ctx.beginPath();
    ctx.moveTo(gx + rx * 0.04, -ry * 0.34);
    ctx.quadraticCurveTo(gx - rx * 0.08, ry * 0.12, gx - rx * 0.2, ry * 0.52);
    ctx.strokeStyle = out(0.45);
    ctx.lineWidth = Math.max(1.4, rim * 1.35);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(gx + rx * 0.07, -ry * 0.32);
    ctx.quadraticCurveTo(gx - rx * 0.05, ry * 0.12, gx - rx * 0.17, ry * 0.5);
    ctx.strokeStyle = "rgba(255, 240, 195, 0.32)";
    ctx.lineWidth = Math.max(1, rim * 0.85);
    ctx.stroke();
    if (st === "andy" && detail) {
      // the cheek spine that tells an angelfish from a butterflyfish
      ctx.beginPath();
      ctx.moveTo(gx - rx * 0.1, ry * 0.36);
      ctx.lineTo(gx - rx * 0.3, ry * 0.52);
      ctx.lineTo(gx - rx * 0.12, ry * 0.5);
      ctx.closePath();
      ctx.fillStyle = "#fff3c4";
      ctx.fill();
      ctx.strokeStyle = out(0.5);
      ctx.lineWidth = rim * 0.6;
      ctx.stroke();
    }
  }

  // inner shadow + satin sheen
  buildBodyPath(ctx, sp, bx, rx, ry, jawState);
  ctx.strokeStyle = rgbaHex(pal.dark, 0.45);
  ctx.lineWidth = rim * 2.8;
  ctx.stroke();
  const sheen = ctx.createRadialGradient(X(0.08), -ry * 0.48, ry * 0.02, X(0.08), -ry * 0.48, rx * 0.55);
  sheen.addColorStop(0, "rgba(255, 255, 255, 0.32)");
  sheen.addColorStop(1, "rgba(255, 255, 255, 0)");
  ctx.fillStyle = sheen;
  ctx.beginPath();
  ctx.ellipse(X(0.08), -ry * 0.48, rx * 0.52, ry * 0.22, -0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore(); // end body clip

  buildBodyPath(ctx, sp, bx, rx, ry, jawState);
  ctx.lineWidth = rim;
  ctx.strokeStyle = out(0.68);
  ctx.stroke();

  if (st === "leon" && detail) {
    // fleshy tentacles above the eyes
    ctx.strokeStyle = pal.dark;
    ctx.lineWidth = Math.max(1.4, rx * 0.04);
    for (const d of [0, 0.1]) {
      ctx.beginPath();
      ctx.moveTo(X(0.66 - d), V(-0.56));
      ctx.quadraticCurveTo(X(0.72 - d), V(-0.9), X(0.6 - d) + sw, V(-1.06));
      ctx.stroke();
    }
  }

  if (st === "sailfish") {
    // the bill: the upper jaw drawn out into a long spear
    const lift = open * ry * 0.3;
    ctx.beginPath();
    ctx.moveTo(X(0.98), V(-0.3) - lift * 0.7);
    ctx.lineTo(X(1.52), V(-0.02) - lift);
    ctx.lineTo(X(1.06), V(0.1) - lift);
    ctx.closePath();
    ctx.fillStyle = pal.dark;
    ctx.fill();
    ctx.strokeStyle = out(0.68);
    ctx.lineWidth = rim;
    ctx.stroke();
  }
  if (st === "puffer" && detail) {
    // little spines lying flat on the skin
    ctx.fillStyle = "#fff6dc";
    ctx.strokeStyle = out(0.45);
    ctx.lineWidth = rim * 0.5;
    for (let i = 0; i < 14; i++) {
      const u = -0.7 + ((i * 0.7548776662 + 0.1) % 1) * 1.15,
        v = -0.62 + ((i * 0.5698402909 + 0.6) % 1) * 1.2;
      ctx.beginPath();
      ctx.moveTo(X(u), V(v));
      ctx.lineTo(X(u - 0.1), V(v - 0.04));
      ctx.lineTo(X(u - 0.02), V(v + 0.07));
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  }
  if (st === "shark" && detail) {
    ctx.fillStyle = out(0.7);
    ctx.beginPath();
    ctx.arc(X(1.06), V(-0.04), Math.max(0.8, ry * 0.045), 0, Math.PI * 2);
    ctx.fill();
  }

  // ---------- 5. MOUTH DETAILS ----------
  if (open > 0) {
    const hingeX = X(disc ? 0.66 - open * 0.08 : longBody ? 0.46 : st === "eddy" || st === "pierre" ? 0.44 - open * 0.06 : 0.56 - open * 0.09);
    ctx.strokeStyle = out(0.6);
    ctx.lineWidth = Math.max(1.2, rim * 1.1);
    ctx.beginPath();
    ctx.arc(hingeX - rx * 0.03, ry * 0.17, ry * 0.085, Math.PI * 0.65, Math.PI * 1.38);
    ctx.stroke();
  } else if (puff > 0) {
    ctx.strokeStyle = out(0.72);
    ctx.lineWidth = Math.max(1.4, rim * 1.25);
    ctx.beginPath();
    ctx.moveTo(X(disc ? 1.04 : 1.0), ry * 0.16);
    ctx.quadraticCurveTo(X(0.86), ry * 0.28, X(0.72), ry * 0.17);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(X(0.7), ry * 0.17, ry * 0.09, Math.PI * 0.6, Math.PI * 1.42);
    ctx.stroke();
  } else {
    ctx.strokeStyle = out(0.68);
    ctx.lineWidth = Math.max(1.2, rim * 1.1);
    if (st === "barracuda") {
      // long jaw line with needle fangs showing
      ctx.beginPath();
      ctx.moveTo(X(1.18), ry * 0.18);
      ctx.quadraticCurveTo(X(0.9), ry * 0.3, X(0.6), ry * 0.2);
      ctx.stroke();
      if (detail) {
        ctx.fillStyle = "#fffaf0";
        for (const tx of [1.1, 1.0, 0.9, 0.8]) {
          ctx.beginPath();
          ctx.moveTo(X(tx - 0.022), ry * 0.26);
          ctx.lineTo(X(tx), ry * (tx > 1.05 ? -0.12 : 0.0));
          ctx.lineTo(X(tx + 0.022), ry * 0.26);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }
    } else if (sp.underbite) {
      // anglerfish: wide grim mouth with long translucent fangs
      ctx.beginPath();
      ctx.moveTo(X(1.0), ry * 0.14);
      ctx.quadraticCurveTo(X(0.8), ry * 0.3, X(0.5), ry * 0.12);
      ctx.stroke();
      if (detail) {
        ctx.fillStyle = "#fffaf0";
        ctx.lineWidth = Math.max(0.9, rim * 0.7);
        for (const [tx, up] of [[0.93, 0.8], [0.83, 1.2], [0.73, 1], [0.63, 0.7]]) {
          const by = ry * (0.19 + (0.96 - tx) * 0.16);
          ctx.beginPath();
          ctx.moveTo(X(tx - 0.026), by);
          ctx.lineTo(X(tx), by - ry * 0.2 * up);
          ctx.lineTo(X(tx + 0.026), by);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.beginPath();
          ctx.moveTo(X(tx - 0.076), by - ry * 0.05);
          ctx.lineTo(X(tx - 0.05), by + ry * 0.13 * up);
          ctx.lineTo(X(tx - 0.024), by - ry * 0.05);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }
    } else if (st === "puffer") {
      // fused beak: two white tooth plates under a little smile
      ctx.beginPath();
      ctx.moveTo(X(1.0), ry * 0.1);
      ctx.quadraticCurveTo(X(0.9), ry * 0.2, X(0.8), ry * 0.12);
      ctx.stroke();
      if (detail) {
        ctx.fillStyle = "#fffaf0";
        ctx.beginPath();
        ctx.rect(X(0.9), ry * 0.13, rx * 0.1, ry * 0.11);
        ctx.fill();
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(X(0.95), ry * 0.13);
        ctx.lineTo(X(0.95), ry * 0.24);
        ctx.stroke();
      }
    } else if (st === "shark") {
      // underslung crescent mouth set back under the snout
      ctx.beginPath();
      ctx.moveTo(X(1.0), ry * 0.2);
      ctx.quadraticCurveTo(X(0.82), ry * 0.2, X(0.66), ry * 0.36);
      ctx.stroke();
    } else {
      const big = st === "pierre" || st === "peter";
      ctx.beginPath();
      ctx.moveTo(X(disc ? 1.02 : 0.98), ry * 0.15);
      ctx.quadraticCurveTo(X(big ? 0.8 : 0.86), ry * (big ? 0.3 : 0.24), X(big ? 0.62 : 0.76), ry * (st === "peter" ? 0.3 : 0.16));
      ctx.stroke();
    }
  }

  // ---------- 6. PECTORAL FIN / FLIPPER (in front of the body) ----------
  const pFlutter = wag2 * 0.16;
  if (st === "orca") {
    // broad rounded paddle flipper
    ctx.save();
    ctx.translate(X(0.36), V(0.56));
    ctx.rotate(2.05 + pFlutter * 0.8);
    ctx.beginPath();
    ctx.moveTo(0, -ry * 0.17);
    ctx.bezierCurveTo(rx * 0.3, -ry * 0.34, rx * 0.56, -ry * 0.14, rx * 0.56, ry * 0.06);
    ctx.bezierCurveTo(rx * 0.5, ry * 0.3, rx * 0.16, ry * 0.26, 0, ry * 0.15);
    ctx.closePath();
    const fg = ctx.createLinearGradient(0, -ry * 0.2, rx * 0.5, ry * 0.2);
    fg.addColorStop(0, mixHex(pal.body, "#5a6478", 0.3));
    fg.addColorStop(1, pal.dark);
    ctx.fillStyle = fg;
    ctx.fill();
    ctx.strokeStyle = out(0.6);
    ctx.lineWidth = rim;
    ctx.stroke();
    ctx.restore();
  } else if (st === "shark") {
    // long swept-back pectoral fin with a black tip
    ctx.save();
    ctx.translate(X(0.3), V(0.5));
    ctx.rotate(2.25 + pFlutter * 0.7);
    const pf = () => {
      ctx.moveTo(0, -ry * 0.18);
      ctx.quadraticCurveTo(rx * 0.36, -ry * 0.3, rx * 0.68, ry * 0.04);
      ctx.quadraticCurveTo(rx * 0.3, ry * 0.2, 0, ry * 0.16);
    };
    ctx.beginPath();
    pf();
    ctx.closePath();
    const fg = ctx.createLinearGradient(0, -ry * 0.2, rx * 0.6, ry * 0.2);
    fg.addColorStop(0, finLight);
    fg.addColorStop(1, finBase);
    ctx.fillStyle = fg;
    ctx.fill();
    dip(pf, rx * 0.68, ry * 0.04, rx * 0.2, pal.spot || "#11151c");
    ctx.beginPath();
    pf();
    ctx.closePath();
    ctx.strokeStyle = out(0.6);
    ctx.lineWidth = rim;
    ctx.stroke();
    ctx.restore();
  } else if (st === "leon") {
    // the lionfish's huge fan: a banded membrane with long free ray tips reaching past the tail
    const ox = X(0.22),
      oy = V(0.2),
      nR = 9;
    const tip = (i: number, k: number): [number, number] => {
      const a = Math.PI * (0.6 + (i / (nR - 1)) * 0.64) + pFlutter * 0.5;
      const L = rx * (0.6 + Math.sin((i / (nR - 1)) * Math.PI) * 0.22) * k;
      return [ox + Math.cos(a) * L, oy + Math.sin(a) * L];
    };
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(ox, oy);
    for (let i = 0; i < nR; i++) ctx.lineTo(...tip(i, 1));
    ctx.closePath();
    ctx.fillStyle = rgbaHex(finBase, 0.62);
    ctx.fill();
    ctx.save();
    ctx.clip();
    ctx.strokeStyle = rgbaHex(pal.dark, 0.42);
    ctx.lineWidth = rx * 0.07;
    for (const k of [0.34, 0.62, 0.9]) {
      ctx.beginPath();
      ctx.arc(ox, oy, rx * 0.72 * k, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
    ctx.beginPath();
    ctx.moveTo(ox, oy);
    for (let i = 0; i < nR; i++) ctx.lineTo(...tip(i, 1));
    ctx.closePath();
    ctx.strokeStyle = out(0.4);
    ctx.lineWidth = rim * 0.7;
    ctx.stroke();
    for (let i = 0; i < nR; i++) {
      const [tx, ty] = tip(i, 1.42);
      ctx.beginPath();
      ctx.moveTo(ox, oy);
      ctx.lineTo(tx, ty);
      ctx.lineWidth = Math.max(1.2, rx * 0.028);
      ctx.strokeStyle = "#fff5eb";
      ctx.stroke();
      ctx.setLineDash([rx * 0.09, rx * 0.16]);
      ctx.strokeStyle = rgbaHex(pal.dark, 0.85);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.restore();
  } else {
    ctx.save();
    const slim = st === "barracuda" || st === "minnow" || st === "sailfish";
    ctx.translate(X(disc ? 0.24 : slim ? 0.3 : 0.08), ry * (disc ? 0.34 : slim ? 0.4 : 0.28));
    ctx.rotate(0.32 + pFlutter * (st === "puffer" ? 2.4 : 1)); // the puffer sculls with fast-fluttering fins
    const pk = slim ? 0.7 : st === "eddy" ? 0.75 : 1;
    const ph = slim ? Math.max(ry, rx * 0.22) : ry;
    ctx.beginPath();
    ctx.moveTo(0, -ph * 0.07);
    ctx.bezierCurveTo(-rx * 0.18 * pk, -ph * 0.2, -rx * 0.42 * pk, -ph * 0.12, -rx * 0.4 * pk, ph * 0.08);
    ctx.bezierCurveTo(-rx * 0.36 * pk, ph * 0.26, -rx * 0.14 * pk, ph * 0.22, 0, ph * 0.09);
    ctx.closePath();
    const pg = ctx.createLinearGradient(0, 0, -rx * 0.42, ry * 0.1);
    pg.addColorStop(0, rgbaHex(finDark, 0.85));
    pg.addColorStop(1, st === "tang" ? rgbaHex(pal.spot || "#ffd91f", 0.95) : rgbaHex(finLight, 0.52));
    ctx.fillStyle = pg;
    ctx.fill();
    if (detail) {
      ctx.save();
      ctx.clip();
      ctx.strokeStyle = out(0.25);
      ctx.lineWidth = Math.max(0.9, rim * 0.6);
      for (const k of [-0.12, -0.02, 0.08, 0.18]) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-rx * 0.42 * pk, ph * k);
        ctx.stroke();
      }
      if (st === "clown") {
        ctx.beginPath();
        ctx.moveTo(-rx * 0.4, -ph * 0.2);
        ctx.quadraticCurveTo(-rx * 0.48, ph * 0.06, -rx * 0.3, ph * 0.3);
        ctx.strokeStyle = BLK;
        ctx.lineWidth = rim * 3.2;
        ctx.stroke();
      }
      ctx.restore();
    }
    ctx.lineWidth = rim * 0.85;
    ctx.strokeStyle = out(0.48);
    ctx.stroke();
    ctx.restore();
  }

  // ---------- 7. EYE (kept in the game's signature glossy 3/4 cartoon style) ----------
  const ex = X(st === "layla" ? 0.5 : st === "idol" ? 0.72 : disc ? 0.75 : st === "orca" ? 0.68 : st === "barracuda" ? 0.72 : st === "shark" ? 0.74 : st === "sailfish" ? 0.78 : longBody ? 0.64 : 0.6);
  const ey =
    -ry *
    (st === "layla"
      ? 0.42 + open * 0.06
      : disc
        ? 0.14 + open * 0.1
        : st === "orca"
          ? 0.1 + open * 0.08
          : st === "shark"
            ? 0.3 + open * 0.08
            : st === "puffer"
              ? 0.24 + open * 0.1
              : 0.16 + open * 0.1);
  const er = ry * sp.eye * (st === "eddy" ? 0.72 : st === "barracuda" ? 1.25 : st === "sailfish" ? 1.5 : st === "minnow" ? 1.12 : st === "orca" ? 0.82 : 1);
  const eyeRx = er * 0.66;
  const eyeRy = er * 1.04;
  const eyeTilt = disc ? -0.28 : -0.18;

  if (jawState === -1) {
    const cg = ctx.createRadialGradient(ex - er * 0.15, ey + er * 1.15, 0, ex - er * 0.15, ey + er * 1.15, er * 0.95);
    cg.addColorStop(0, "rgba(255, 95, 135, 0.44)");
    cg.addColorStop(1, "rgba(255, 95, 135, 0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(ex - er * 0.15, ey + er * 1.15, er * 0.95, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.save();
  ctx.translate(ex, ey);
  ctx.rotate(eyeTilt);
  if (expr === "happy" && !sp.angry) {
    ctx.strokeStyle = out(0.82);
    ctx.lineWidth = Math.max(1.6, rim * 1.35);
    ctx.beginPath();
    ctx.arc(0, eyeRy * 0.22, eyeRx * 0.95, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
  } else {
    const browTopCol = st === "andy" ? rgbaHex(pal.stripe || "#df22ff", 0.5) : rgbaHex(pal.dark, 0.45);
    ctx.beginPath();
    ctx.ellipse(-eyeRx * 0.12, -eyeRy * 0.04, eyeRx * 1.18, eyeRy * 1.12, 0, Math.PI * 0.55, Math.PI * 1.72);
    ctx.strokeStyle = browTopCol;
    ctx.lineWidth = Math.max(1.5, rim * 1.6);
    ctx.stroke();

    ctx.beginPath();
    ctx.ellipse(eyeRx * 0.08, 0, eyeRx * (expr === "panic" ? 1.14 : 1), eyeRy * (expr === "panic" ? 1.08 : 1), 0, 0, Math.PI * 2);
    const sclGrad = ctx.createRadialGradient(eyeRx * 0.2, -eyeRy * 0.15, eyeRx * 0.08, 0, 0, eyeRy * 1.05);
    sclGrad.addColorStop(0, "#ffffff");
    sclGrad.addColorStop(0.72, "#f7faff");
    sclGrad.addColorStop(1, "#b6cae0");
    ctx.fillStyle = sclGrad;
    ctx.fill();

    ctx.save();
    ctx.clip();
    const pxOff = expr === "panic" ? eyeRx * 0.36 : eyeRx * 0.52;
    const pyOff = open > 0 ? eyeRy * 0.08 : eyeRy * 0.05;
    const pRx = eyeRx * (expr === "panic" ? 0.3 : 0.38);
    const pRy = eyeRy * (expr === "panic" ? 0.3 : 0.42);
    ctx.beginPath();
    ctx.ellipse(pxOff, pyOff, pRx * 1.18, pRy * 1.18, 0, 0, Math.PI * 2);
    ctx.fillStyle = pal.iris || "#2b1608";
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(pxOff + eyeRx * 0.04, pyOff, pRx, pRy, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#090812";
    ctx.fill();
    ctx.beginPath();
    ctx.arc(pxOff - pRx * 0.28, pyOff - pRy * 0.34, Math.max(0.8, pRx * 0.32), 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255, 255, 255, 0.95)";
    ctx.fill();
    if (sp.angry) {
      ctx.beginPath();
      ctx.moveTo(-eyeRx * 1.3, -eyeRy * 1.05);
      ctx.lineTo(eyeRx * 1.3, -eyeRy * 0.08);
      ctx.lineTo(eyeRx * 1.3, -eyeRy * 1.3);
      ctx.closePath();
      ctx.fillStyle = pal.dark;
      ctx.fill();
    }
    ctx.restore();

    ctx.beginPath();
    ctx.ellipse(eyeRx * 0.08, 0, eyeRx, eyeRy, 0, Math.PI * 0.35, Math.PI * 1.85);
    ctx.lineWidth = Math.max(1, rim * 0.9);
    ctx.strokeStyle = out(0.52);
    ctx.stroke();
  }
  ctx.restore(); // eye transform
  ctx.restore(); // translate(0, cy)

  if (!pixelMode) return cv;

  const pw = Math.max(24, Math.round(W * 0.65));
  const ph = Math.max(16, Math.round(H * 0.65));
  const pc = document.createElement("canvas");
  pc.width = pw;
  pc.height = ph;
  const pctx = pc.getContext("2d")!;
  pctx.imageSmoothingEnabled = true;
  pctx.drawImage(cv, 0, 0, pw, ph);
  return pc;
}

// ---------- Soft Glossy Spinning Gold Coin ----------
const coinFrames: HTMLCanvasElement[] = [];
export function coinSprite(frame: number): HTMLCanvasElement {
  if (!coinFrames.length) {
    const scales = [1, 0.82, 0.5, 0.22, 0.5, 0.82];
    for (const sx of scales) {
      const S = 40;
      const c = document.createElement("canvas");
      c.width = S;
      c.height = S;
      const ctx = c.getContext("2d")!;
      const cx = S / 2,
        cy = S / 2,
        r = 15;
      ctx.fillStyle = "#c97408";
      ctx.strokeStyle = "#4a2500";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.ellipse(cx + (sx < 0.9 ? 1.5 : 0), cy, Math.max(3, r * sx), r, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      g.addColorStop(0, "#fff8b8");
      g.addColorStop(0.45, "#ffd43b");
      g.addColorStop(1, "#f09400");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(cx, cy, Math.max(2.5, r * sx), r, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      if (sx > 0.45) {
        ctx.strokeStyle = "rgba(217, 128, 0, 0.7)";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.ellipse(cx, cy, r * 0.68 * sx, r * 0.68, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = "#fff9db";
        ctx.beginPath();
        ctx.roundRect(cx - 2 * sx, cy - 5, 4 * sx, 10, 2);
        ctx.fill();
      }
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(cx - r * 0.38 * sx, cy - r * 0.42, 2.3, 0, Math.PI * 2);
      ctx.fill();
      coinFrames.push(c);
    }
  }
  return coinFrames[((frame % coinFrames.length) + coinFrames.length) % coinFrames.length];
}

export function spriteDataURL(sp: Species, size = 200, jawState: JawState = 0): string {
  const c = renderFishCanvas(sp, size, jawState, 0, false, jawState === -1 ? "happy" : "normal");
  return c.toDataURL();
}
