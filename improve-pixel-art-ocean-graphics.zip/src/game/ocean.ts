// ============================================================================
// THE OCEAN — four depth levels rendered as 16-bit pixel art
//
//   0  ZONA CAHAYA    sunlit coral gardens on top of reef pinnacles
//   1  ZONA SENJA     twilight gorgonian walls
//   2  ZONA MALAM     midnight bioluminescent garden & crystals
//   3  PALUNG ABISAL  abyssal plain with black-smoker vents
//
// Nothing floats any more: every rock is the crown of a pinnacle whose stem runs
// down into the haze / the sea floor, and every coral is planted by scanning the
// real rock surface so its holdfast is embedded in solid rock.
// ============================================================================
import { Pix, C, P, rng, bayer, hash2, mixC } from "./pixel";
import type { Rnd } from "./pixel";
import { buildBiota, NF, genBranch, genTable, genFan, genKelp, genTubes, genWhip, genForegroundOutcrops } from "./reef";
import type { Bio, BioSet } from "./reef";

export const WORLD_W = 3800;
export const WORLD_H = 1950;
export const DEEP_START = 820;
export const FLOOR_TOP = WORLD_H - 330;
const WPAD = 60;
const TAU = Math.PI * 2;

export function floorY(x: number) {
  return WORLD_H - 82 + Math.sin(x * 0.0035) * 28 + Math.sin(x * 0.011 + 1.2) * 15 + Math.sin(x * 0.029) * 5;
}

function hexToRgb(h: string): [number, number, number] {
  const s = h.startsWith("#") ? h.slice(1) : h;
  const n = parseInt(s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function rgbaHex(h: string, a: number): string {
  const [r, g, b] = hexToRgb(h);
  return `rgba(${r},${g},${b},${a})`;
}

// Cached pre-rendered soft radial glow sprites
const glowCache = new Map<string, HTMLCanvasElement>();
export function glowOrb(color: string, whiteCore = true): HTMLCanvasElement {
  const key = color + (whiteCore ? "|w" : "|n");
  let cv = glowCache.get(key);
  if (cv) return cv;
  const S = 64;
  cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  let zeroCol = "rgba(190, 248, 255, 0)";
  if (color.startsWith("#")) zeroCol = rgbaHex(color, 0);
  else if (color.startsWith("rgba(")) zeroCol = color.replace(/,[^,]+\)$/, ", 0)");
  const rg = c.createRadialGradient(S / 2, S / 2, 0.5, S / 2, S / 2, S / 2);
  if (whiteCore) {
    rg.addColorStop(0, "#ffffff");
    rg.addColorStop(0.32, color);
    rg.addColorStop(0.68, color.startsWith("#") ? rgbaHex(color, 0.25) : "rgba(150, 238, 255, 0.2)");
    rg.addColorStop(1, zeroCol);
  } else {
    rg.addColorStop(0, color);
    rg.addColorStop(1, zeroCol);
  }
  c.fillStyle = rg;
  c.fillRect(0, 0, S, S);
  glowCache.set(key, cv);
  return cv;
}

type Ctx = CanvasRenderingContext2D;

export interface RockCollider {
  x: number;
  y: number;
  r: number;
}

// ---------------------------------------------------------------- depth levels
export const ZONES = [
  { y: 0, name: "ZONA CAHAYA", sub: "Taman Karang Dangkal", m0: 0, m1: 200, col: "#7af0ff" },
  { y: 700, name: "ZONA SENJA", sub: "Tebing Gorgonia", m0: 200, m1: 1000, col: "#8aa8ff" },
  { y: 1250, name: "ZONA MALAM", sub: "Taman Bioluminesens", m0: 1000, m1: 4000, col: "#d890ff" },
  { y: 1650, name: "PALUNG ABISAL", sub: "Ladang Cerobong Hidrotermal", m0: 4000, m1: 6000, col: "#ffa05c" },
];
export function zoneAt(y: number): number {
  return y < ZONES[1].y ? 0 : y < ZONES[2].y ? 1 : y < ZONES[3].y ? 2 : 3;
}
export function depthMeters(y: number): number {
  const yy = Math.max(0, Math.min(WORLD_H, y));
  const z = zoneAt(yy),
    Z = ZONES[z],
    y1 = z < 3 ? ZONES[z + 1].y : WORLD_H;
  return Math.round(Z.m0 + ((yy - Z.y) / (y1 - Z.y)) * (Z.m1 - Z.m0));
}

const WATER: [number, number][] = (
  [
    [-60, "#f4feff"],
    [-8, "#c4f9ff"],
    [0, "#6aeeff"],
    [80, "#34ccf2"],
    [230, "#1a9fe2"],
    [420, "#1376cc"],
    [640, "#0f55b0"],
    [860, "#0e3f96"],
    [1080, "#132f84"],
    [1280, "#17216c"],
    [1480, "#151752"],
    [1680, "#0e0d3a"],
    [1850, "#090825"],
    [2020, "#040414"],
  ] as [number, string][]
).map(([y, h]) => [y, C(h)]);

function waterC(y: number): number {
  for (let i = 1; i < WATER.length; i++)
    if (y <= WATER[i][0]) {
      const a = WATER[i - 1],
        b = WATER[i];
      return mixC(a[1], b[1], Math.max(0, (y - a[0]) / (b[0] - a[0])));
    }
  return WATER[WATER.length - 1][1];
}

// ---------------------------------------------------------------- pixel rock painter
interface RockStyle {
  ramp: number[]; // outline, deep shadow, shadow, base, light, highlight
  crust: number[]; // dark, mid, light  (living turf / sediment on every up-facing surface)
}
const ROCK: RockStyle[] = [
  { ramp: P("#0a1c3c", "#12305c", "#1a4a80", "#2a6ca4", "#4496c4", "#7cc8e0"), crust: P("#1c8a78", "#4cc89c", "#b6f4c0") },
  { ramp: P("#0a1238", "#141e58", "#1e3080", "#2c48a4", "#4868c4", "#7c98e4"), crust: P("#3a4cb0", "#6a84e0", "#b0c8ff") },
  { ramp: P("#070722", "#100e3a", "#1a1858", "#2a2678", "#3e3a9c", "#6460c4"), crust: P("#3a2a90", "#7a50c8", "#c89cf4") },
  { ramp: P("#04040f", "#0a0a22", "#12123a", "#1c1c54", "#2c2c74", "#48489c"), crust: P("#1c3c6c", "#2c6c98", "#62c0d8") },
];
const FAR_ROCK: RockStyle = { ramp: P("#0c2c62", "#113c7c", "#174e96", "#2064ae", "#2e7ec4", "#4ea4dc"), crust: P("#2c86b4", "#4cb0cc", "#90dce4") };
const DEEP_ROCK: RockStyle = { ramp: P("#080a2a", "#0e1242", "#161c5e", "#20287a", "#2e3a98", "#4a58bc"), crust: P("#2a3a9a", "#4a5cc0", "#8a9cf0") };

/**
 * Shades a rock mask as chiselled 16-bit boulders: Voronoi blocks lit from the upper-left,
 * strata bands, ordered dithering between tones, pores, a living crust on every up-facing
 * surface and a dark outline on walls & undersides.
 */
function* paintRock(p: Pix, m: Uint8Array, st: RockStyle, seed: number, cell: number, dim = 0, crustOn = true): Generator<void, void, void> {
  const w = p.w,
    h = p.h;
  const cellY = Math.max(6, Math.round(cell * 0.62)); // flat sedimentary slabs
  const gw = Math.ceil(w / cell) + 2,
    gh = Math.ceil(h / cellY) + 4;
  const sx = new Float32Array(gw * gh),
    sy = new Float32Array(gw * gh),
    tn = new Float32Array(gw * gh);
  for (let j = 0; j < gh; j++)
    for (let i = 0; i < gw; i++) {
      const k = j * gw + i;
      sx[k] = (i - 1 + hash2(i, j, seed)) * cell;
      sy[k] = (j - 2 + hash2(i, j, seed + 7)) * cellY;
      tn[k] = hash2(i, j, seed + 13);
    }
  // large-scale tone patches so the wall is not one uniform cobble pattern
  const big = cell * 3.4,
    bigY = big * 0.7;
  // value-noise lattice, precomputed once (was 4 hashes per pixel)
  const lw = Math.ceil(w / big) + 2,
    lh = Math.ceil(h / bigY) + 2;
  const lat = new Float64Array(lw * lh);
  for (let j = 0; j < lh; j++) for (let i = 0; i < lw; i++) lat[j * lw + i] = hash2(i, j, seed + 51);
  const dep = new Int32Array(h);
  for (let x = 0; x < w; x++) {
    if (x > 0 && (x & 31) === 0) yield; // let the page breathe: the caller resumes us on a later frame
    const fx = x / big,
      ix = fx | 0,
      ux = fx - ix,
      mx = ux * ux * (3 - 2 * ux);
    const cd = crustOn ? 2 + (hash2(x, 3, seed) < 0.3 ? 1 : 0) + (hash2(x >> 1, 5, seed) < 0.14 ? 2 : 0) : 0;
    let run = 0;
    for (let y = h - 1; y >= 0; y--) {
      run = m[y * w + x] ? run + 1 : 0;
      dep[y] = run;
    }
    let d = -1;
    for (let y = 0; y < h; y++) {
      const i = y * w + x;
      if (!m[i]) {
        d = -1;
        continue;
      }
      d++;
      const u = dep[y] - 1;
      const ci0 = Math.floor(x / cell) + 1,
        cj0 = Math.floor(y / cellY) + 2;
      let d1 = 1e9,
        d2 = 1e9,
        kk = 0;
      for (let dj = -2; dj <= 2; dj++)
        for (let di = -1; di <= 1; di++) {
          const k = (cj0 + dj) * gw + ci0 + di;
          const ex = sx[k] - x,
            ey = sy[k] - y;
          const dd = ex * ex + ey * ey;
          if (dd < d1) {
            d2 = d1;
            d1 = dd;
            kk = k;
          } else if (dd < d2) d2 = dd;
        }
      const edge = Math.sqrt(d2) - Math.sqrt(d1);
      const fy = y / bigY,
        iy = fy | 0,
        uy = fy - iy,
        my = uy * uy * (3 - 2 * uy),
        l0 = iy * lw + ix;
      const na = lat[l0],
        nb = lat[l0 + 1],
        nc = lat[l0 + lw],
        nd = lat[l0 + lw + 1];
      const vnv = na + (nb - na) * mx + (nc - na) * my + (na - nb - nc + nd) * mx * my;
      let v = 3 + (tn[kk] - 0.5) * 1.1 + (vnv - 0.5) * 2.0;
      v += Math.max(-1, Math.min(1, (sx[kk] - x) / cell + ((sy[kk] - y) / cellY) * 0.9)) * 0.75;
      v += 1.0 - (d / (d + u + 1)) * 2.4 - Math.min(1, d / 46) * 0.5;
      if (u < 6) v -= (6 - u) * 0.22;
      if (edge < 1.0) v -= 1.15;
      else if (edge < 2.1 && sx[kk] - x + (sy[kk] - y) * 1.4 > cell * 0.25) v += 0.55; // lit lip of each slab
      let ci = Math.floor(v + (bayer(x, y) - 0.5) * 0.8 + (hash2(x, y, seed + 3) - 0.5) * 0.45) - dim;
      ci = ci < 1 ? 1 : ci > 5 ? 5 : ci;
      let c = st.ramp[ci];
      if (crustOn) {
        if (d < cd) c = d === 0 ? st.crust[2] : d === 1 ? st.crust[1] : bayer(x, y) < 0.6 ? st.crust[0] : c;
      } else if (d === 0) c = st.ramp[Math.min(5, ci + 2)];
      if (d > 5 && hash2(x, y, seed + 31) < 0.008) c = st.ramp[1];
      else if (d > 6 && hash2(x, y - 1, seed + 31) < 0.008) c = st.ramp[Math.min(5, ci + 1)];
      if (d > 0 && ((u === 0 && y < h - 1) || (x > 0 && !m[i - 1]) || (x < w - 1 && !m[i + 1]))) c = st.ramp[0];
      p.d[i] = c;
    }
  }
}

/** flat 4-tone silhouette shading for the farthest planes */
function* paintFlat(p: Pix, m: Uint8Array, col: number[], seed: number): Generator<void, void, void> {
  const { w, h } = p;
  for (let x = 0; x < w; x++) {
    if (x > 0 && (x & 63) === 0) yield;
    let d = -1;
    for (let y = 0; y < h; y++) {
      const i = y * w + x;
      if (!m[i]) {
        d = -1;
        continue;
      }
      d++;
      const lit = !m[y * w + ((x + w - 1) % w)] || !m[y * w + ((x + w - 2) % w)];
      const shade = !m[y * w + ((x + 1) % w)] || !m[y * w + ((x + 3) % w)];
      let c = d < 2 ? col[0] : lit ? col[3] : shade ? col[2] : col[1];
      if (d >= 2 && !lit && bayer(x, y) < Math.min(0.8, d / 110)) c = col[2];
      if (d > 4 && (y + ((Math.sin(x * 0.04 + seed) * 5) | 0)) % 27 === 0 && hash2(x >> 2, y, seed) < 0.55) c = col[3];
      p.d[i] = c;
    }
  }
}

/** fills everything below a ridge line with banded/dithered silhouette tones and dithers the bottom away */
function* fillRidge(p: Pix, ridge: (x: number) => number, col: number[], seed: number, fade: number): Generator<void, void, void> {
  const { w, h } = p;
  for (let x = 0; x < w; x++) {
    if (x > 0 && (x & 127) === 0) yield;
    const ty = Math.round(ridge(x));
    for (let y = Math.max(0, ty); y < h; y++) {
      const d = y - ty;
      const fb = (y - (h - fade)) / fade;
      if (fb > 0 && bayer(x + 2, y + 1) < fb) {
        p.d[y * w + x] = 0;
        continue;
      }
      let c = d < 2 ? col[0] : col[1];
      if (d >= 2 && bayer(x, y) < Math.min(1, (d - 2) / 80)) c = col[2];
      if (d > 5 && (d + ((Math.sin(x * 0.03 + seed) * 6) | 0)) % 23 === 0 && hash2(x >> 2, d, seed) < 0.6) c = col[3];
      p.d[y * w + x] = c;
    }
  }
}

function fadeBottom(p: Pix, fade: number) {
  for (let y = p.h - fade; y < p.h; y++) {
    const fb = (y - (p.h - fade)) / fade;
    for (let x = 0; x < p.w; x++) if (bayer(x + 2, y + 1) < fb) p.d[y * p.w + x] = 0;
  }
}

/** silhouette mask of mushroom-capped pinnacles that rise from the bottom edge (tiles horizontally) */
function* spireMask(
  w: number,
  h: number,
  r: Rnd,
  n: number,
  topMin: number,
  topMax: number,
  capMin: number,
  capMax: number
): Generator<void, { m: Uint8Array; caps: [number, number, number, number][] }, void> {
  const m = new Uint8Array(w * h);
  const caps: [number, number, number, number][] = [];
  for (let i = 0; i < n; i++) {
    const cx = ((i + 0.3 + r() * 0.4) * w) / n,
      ty = topMin + r() * (topMax - topMin),
      R = capMin + r() * (capMax - capMin),
      ch = R * (0.3 + r() * 0.14),
      neck = R * (0.3 + r() * 0.1),
      s1 = r() * 9,
      lean = (r() - 0.5) * 40;
    caps.push([cx, ty, R, ch]);
    for (let y = Math.max(0, Math.floor(ty - ch)); y < h; y++) {
      const v = (y - ty) / ch;
      let hw = v < 0.9 ? R * Math.sqrt(Math.max(0, 1 - v * v)) : 0;
      if (v < 0) hw = Math.round(hw / 3) * 3;
      const t = Math.max(0, (y - ty) / (h - ty));
      if (y > ty) hw = Math.max(hw, neck * (1 + 0.9 * Math.pow(t, 1.3)) + Math.sin(y * 0.05 + s1) * 4 + (Math.floor(y / 37 + s1) & 1) * 3);
      const xc = cx + lean * t;
      for (let x = Math.round(xc - hw); x <= Math.round(xc + hw); x++) m[y * w + (((x % w) + w) % w)] = 1;
    }
    yield;
  }
  return { m, caps };
}

// ---------------------------------------------------------------- biota planting
type Tbl = [string, number][];
function pick(r: Rnd, t: Tbl): string {
  let tot = 0;
  for (const e of t) tot += e[1];
  let k = r() * tot;
  for (const e of t) {
    k -= e[1];
    if (k <= 0) return e[0];
  }
  return t[0][0];
}

// what grows at each depth level
const TOP_BIO: Tbl[] = [
  [["staghorn", 5], ["table", 4], ["brain", 3], ["pillar", 3], ["lettuce", 3], ["fan", 4], ["whip", 2], ["tubes", 3], ["barrel", 1.5], ["anemone", 3], ["clam", 2.5], ["worm", 3], ["grass", 3], ["kelp", 1.6], ["urchin", 1.5]],
  [["fan2", 5], ["whip2", 3], ["staghorn2", 3], ["brain2", 2], ["lettuce2", 3], ["barrel2", 2], ["anemone2", 3], ["crinoid", 3.5], ["tunicate", 3], ["worm", 2.5], ["tubes", 1.5], ["urchin2", 1]],
  [["crystal", 4], ["pen", 4], ["bamboo", 3], ["bubblegum", 3], ["crinoid2", 3], ["tunicate", 3], ["anemone2", 2.5], ["fan2", 2], ["urchin2", 1]],
  [["pen", 4], ["bamboo", 3.5], ["crystal", 3], ["bubblegum", 3], ["anemone2", 3], ["crinoid2", 3], ["tunicate", 2.5], ["riftia", 1.5], ["urchin2", 1.5], ["star2", 1.5]],
];
// small creatures that fill the gaps between the big corals
const FILL_BIO: Tbl[] = [
  [["grass", 4], ["worm", 3], ["urchin", 2], ["anemone", 2], ["clam", 1.5], ["brain", 1]],
  [["tunicate", 3], ["worm", 3], ["urchin2", 2], ["anemone2", 2], ["grass", 1]],
  [["tunicate", 3], ["urchin2", 2], ["anemone2", 2], ["pen", 2], ["star2", 1]],
  [["tunicate", 3], ["urchin2", 2], ["anemone2", 2], ["pen", 2.5], ["star2", 1.5], ["riftia", 1]],
];
const FAR_TBL: Tbl = [["kelp", 3], ["fan", 3], ["whip", 2], ["staghorn", 3], ["table", 2.5], ["tubes", 2], ["grass", 2], ["brain", 1.5], ["pillar", 1.5]];
const SIDE_BIO = ["shelf", "shelf2", "shelf2", "shelf2"];
const HANG_BIO = ["vine", "vine2", "vine2", "vine2"];
const STAR_BIO = ["star", "star", "star2", "star2"];

interface Inst {
  s: Bio;
  x: number;
  y: number;
  ph: number;
  flip: boolean;
  hide: number;
}

/**
 * Walks along a surface profile (top[x] = first solid row, -1 = no ground) and plants biota only where
 * the whole holdfast rests on solid, nearly level rock. The base is put on the LOWEST point under the
 * foot, so a coral can be slightly buried but never hover.
 */
function plant(r: Rnd, set: BioSet, tbl: Tbl, top: Int16Array, x0: number, x1: number, ox: number, oy: number, out: Inst[], tol: number, shade?: (x: number, y: number, f: number) => void, occ?: Uint8Array, filler = false) {
  let x = x0;
  while (x < x1) {
    const vs = set[pick(r, tbl)];
    if (!vs) {
      x += 3;
      continue;
    }
    const s = vs[(r() * vs.length) | 0],
      f = s.foot;
    let ok = -1,
      base = 0;
    for (let t = 0; t <= 12 && ok < 0; t += 2) {
      const xc = Math.round(x + f + t);
      let lo = -1e9,
        hi = 1e9,
        valid = xc + f < x1;
      for (let k = -f; k <= f && valid; k++) {
        const ty = top[xc + k];
        if (ty === undefined || ty < 0 || (occ && occ[xc + k])) valid = false;
        else {
          if (ty > lo) lo = ty;
          if (ty < hi) hi = ty;
        }
      }
      if (valid && lo - hi <= tol) {
        ok = xc;
        base = lo;
      }
    }
    if (ok < 0) {
      x += 8;
      continue;
    }
    out.push({ s, x: ox + ok, y: oy + base, ph: r() * NF, flip: r() < 0.5, hide: 0 });
    if (shade) shade(ok, base, f);
    if (occ) for (let k = -f - 1; k <= f + 1; k++) if (ok + k >= 0 && ok + k < occ.length) occ[ok + k] = 1;
    x = filler ? ok + f + 2 + r() * 9 : ok + Math.max(f + 2, s.w * 0.4) + r() * 5;
  }
}

interface Formation {
  x: number;
  y: number;
  w: number;
  h: number;
  cv: HTMLCanvasElement;
  col: HTMLCanvasElement;
  colX: number;
  colY: number;
  insts: Inst[];
  colliders: RockCollider[];
}
interface Crab {
  top: Int16Array;
  ox: number;
  oy: number;
  x0: number;
  range: number;
  sp: number;
  ph: number;
  v: number;
}
interface Jelly {
  s: Bio;
  x: number;
  y: number;
  p: number;
  ph: number;
}
interface DistantPelagic {
  x: number;
  y: number;
  scale: number;
  dir: number;
  speed: number;
  kind: "manta" | "whaleshark";
  ph: number;
}
interface Ray {
  x: number;
  w: number;
  len: number;
  ph: number;
  a: number;
  layer: number; // 0 = far behind the reef, 1 = between the distant ridges and the reef, 2 = in front
  v: number;
}

const SUN_X = WORLD_W * 0.56; // where the sun stands above the sea
const RAY_PERIOD = 1080;
const RAY_PAR = [0.3, 0.62, 1.0]; // parallax of the three planes of light shafts
const D1_Y = 880;
const D2_Y = 930;
const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

export class Ocean {
  bio!: BioSet;
  farBio!: BioSet;
  fgBio!: BioSet;
  water!: HTMLCanvasElement;
  far1!: HTMLCanvasElement;
  far2!: HTMLCanvasElement;
  far3!: HTMLCanvasElement;
  deep1!: HTMLCanvasElement;
  deep2!: HTMLCanvasElement;
  floor!: HTMLCanvasElement;

  /** false until the whole world has been generated — nothing may be drawn before that */
  ready = false;
  /** 0..1 generation progress */
  progress = 0;
  private gen: Generator<number | void, void, void> | null;
  // pre-rendered light art (nothing here is rebuilt per frame)
  private beams: HTMLCanvasElement[] = [];
  private caust: HTMLCanvasElement[] = [];
  private waves: HTMLCanvasElement[] = [];
  private mist: HTMLCanvasElement[] = [];
  private vig!: HTMLCanvasElement;
  private neb!: HTMLCanvasElement;
  private bloom!: HTMLCanvasElement;
  private lb: HTMLCanvasElement[] = []; // world-resolution light buffers
  private lbc: Ctx[] = [];
  private hudTxt = new Map<string, { cv: HTMLCanvasElement; w: number; h: number }>();

  formations: Formation[] = [];
  colliders: RockCollider[] = [];
  farInsts: Inst[] = [];
  floorInsts: Inst[] = [];
  fgInsts: Inst[] = [];
  fgDioramas: HTMLCanvasElement[] = [];
  crabs: Crab[] = [];
  deepGlows: { x: number; y: number; c: string; ph: number }[] = [];
  jellies: Jelly[] = [];
  pelagics: DistantPelagic[] = [];
  rays: Ray[] = [];
  vents: { x: number; y: number }[] = [];
  chestPos = { x: 0, y: 0 };
  schools: { x: number; y: number; dir: number; speed: number; n: number; p: number; seed: number; deep: boolean }[] = [];

  time = 0;
  pxs = 1; // device pixels per world unit (set by the engine) — used to snap pixel art to the device grid
  focusX = -9999; // player position: shy animals retract when it gets close
  focusY = -9999;
  private dt = 0;
  private lastT = 0;
  private hudZone = -1;
  private hudT = -99;

  constructor() {
    // Generating ~8 megapixels of pixel art takes a second or more. Doing it here would freeze the page,
    // so the constructor only prepares a generator; the engine runs it a few milliseconds per frame.
    this.gen = this.build();
  }

  /** Runs world generation for about `budgetMs`. Returns true once the ocean is complete. */
  step(budgetMs: number): boolean {
    if (this.ready || !this.gen) return true;
    const t0 = performance.now();
    do {
      const r = this.gen.next();
      if (r.done) {
        this.gen = null;
        this.ready = true;
        this.progress = 1;
        return true;
      }
      if (typeof r.value === "number") this.progress = r.value;
    } while (performance.now() - t0 < budgetMs);
    return false;
  }

  /** runs one generation stage while reporting progress from p0 to p1 (`est` = expected step count) */
  private *sub<T>(g: Generator<void, T, void>, p0: number, p1: number, est: number): Generator<number, T, void> {
    let n = 0;
    for (;;) {
      const r = g.next();
      if (r.done) return r.value;
      yield p0 + (p1 - p0) * Math.min(1, ++n / est);
    }
  }

  private *build(): Generator<number | void, void, void> {
    // each stage reports smooth progress between two checkpoints (weights follow measured cost)
    this.bio = yield* this.sub(buildBiota(), 0, 0.08, 46);
    this.farBio = yield* this.sub(buildBiota([C("#1b6ab4"), 0.45], ["kelp", "fan", "whip", "staghorn", "table", "tubes", "grass", "brain", "pillar"]), 0.08, 0.1, 9);
    this.fgBio = yield* this.sub(buildBiota([C("#030a1e"), 0.8], ["kelpBig", "fan2", "bamboo", "staghorn2", "whip2"]), 0.1, 0.12, 5);
    this.fgDioramas = yield* this.sub(genForegroundOutcrops(), 0.12, 0.14, 3);
    this.water = this.makeWater();
    this.makeLightArt();
    this.far1 = yield* this.sub(this.makeFar1(), 0.13, 0.15, 16);
    this.far2 = yield* this.sub(this.makeFar2(), 0.15, 0.18, 24);
    this.far3 = yield* this.sub(this.makeFar3(), 0.18, 0.24, 66);
    this.deep1 = yield* this.sub(this.makeDeep1(), 0.24, 0.3, 38);
    this.deep2 = yield* this.sub(this.makeDeep2(), 0.3, 0.44, 78);
    yield* this.buildFormations(0.44, 0.8);
    this.floor = yield* this.sub(this.makeFloor(), 0.8, 0.98, 120);

    const r = rng(99);
    // drifting pixel jellyfish: moon jellies up high, glowing ones in the dark
    for (let i = 0; i < 26; i++) {
      const deep = i >= 11;
      const vs = this.bio[deep ? "jelly2" : "jelly"];
      this.jellies.push({ s: vs[i % vs.length], x: r() * 3400, y: deep ? 980 + r() * 760 : 300 + r() * 540, p: 0.44 + (i % 3) * 0.12, ph: r() * 6.28 });
    }
    for (let i = 0; i < 7; i++)
      this.pelagics.push({ x: r() * 2600, y: 160 + r() * 580, scale: 0.75 + r() * 0.65, dir: i % 2 === 0 ? 1 : -1, speed: 7 + r() * 6, kind: i % 3 === 0 ? "whaleshark" : "manta", ph: r() * 6.28 });
    for (let i = 0; i < 20; i++) {
      const deep = i >= 10;
      this.schools.push({ x: r() * 3000, y: deep ? 950 + r() * 750 : 90 + r() * 620, dir: r() < 0.5 ? 1 : -1, speed: 9 + r() * 15, n: 9 + Math.floor(r() * 15), p: i % 2 === 0 ? 0.32 : 0.58, seed: r() * 100, deep });
    }
    // god rays on three depth planes: wide soft shafts far behind the reef, medium shafts in front of the
    // distant ridges, and a few thin ones in front of everything
    const RAY_N = [8, 8, 5];
    for (let L = 0; L < 3; L++)
      for (let i = 0; i < RAY_N[L]; i++)
        this.rays.push({
          x: ((i + 0.15 + r() * 0.7) * RAY_PERIOD) / RAY_N[L],
          w: [170, 104, 54][L] * (0.7 + r() * 0.7),
          len: [1220, 1060, 840][L] * (0.85 + r() * 0.3),
          ph: r() * 6.28,
          a: [0.62, 0.46, 0.26][L] * (0.75 + r() * 0.5),
          layer: L,
          v: (r() * 2) | 0,
        });
    // foreground silhouettes rooted below the bottom edge of the world (1.24x parallax)
    const span = WORLD_W * 1.24;
    for (let x = 30; x < span; x += 170 + r() * 260) {
      const big = r() < 0.45;
      const vs = this.fgBio[big ? "kelpBig" : (["fan2", "bamboo", "staghorn2", "whip2"] as const)[(r() * 4) | 0]];
      this.fgInsts.push({ s: vs[(r() * vs.length) | 0], x, y: big ? r() * 26 : -8 - r() * 10, ph: r() * NF, flip: r() < 0.5, hide: 0 });
    }
  }

  // ==========================================================================
  // WATER COLUMN — dithered 16-bit depth bands from sunlit aqua to abyssal black
  // ==========================================================================
  /** Builds the small sprites the lighting is made of: light shafts, caustic nets, surface waves, mist, vignette. */
  private makeLightArt() {
    const px = (a: number, r: number, g: number, b: number) => ((Math.max(0, Math.min(255, Math.round(a))) << 24) | (b << 16) | (g << 8) | r) >>> 0;
    // ---- light shafts: soft beams that widen with depth and carry finer streaks inside ----
    for (let v = 0; v < 2; v++) {
      const W = 96,
        H = 320,
        p = new Pix(W, H);
      const s1 = 1.3 + v * 2.1,
        s2 = 4.2 - v * 1.7;
      for (let y = 0; y < H; y++) {
        const t = y / (H - 1);
        const half = (0.15 + 0.35 * t) * W;
        const fall = Math.min(1, t / 0.025) * Math.pow(1 - t, 0.95);
        const cr = Math.round(244 - 92 * t),
          cg = Math.round(254 - 38 * t);
        for (let x = 0; x < W; x++) {
          const u = (x + 0.5 - W / 2) / half;
          if (u <= -1 || u >= 1) continue;
          const streak = (0.5 + 0.5 * Math.sin(u * 7.5 + s1)) * (0.5 + 0.5 * Math.sin(u * 17 + s2));
          const a = Math.pow(1 - u * u, 1.7) * (0.56 + 0.44 * Math.min(1, streak * (v ? 1.7 : 1.1))) * fall;
          if (a > 0.004) p.d[y * W + x] = px(255 * a, cr, cg, 255);
        }
      }
      this.beams.push(p.toCanvas());
    }
    // ---- caustic nets: wavering lines of focused sunlight just under the surface (tile horizontally) ----
    for (let v = 0; v < 2; v++) {
      const W = 384,
        H = 144,
        p = new Pix(W, H),
        K = TAU / W;
      const o1 = v * 1.9 + 0.4,
        o2 = v * 2.7 + 1.1;
      for (let y = 0; y < H; y++) {
        const fade = Math.pow(1 - y / H, 1.3) * Math.min(1, y / 5);
        for (let x = 0; x < W; x++) {
          const a1 = Math.sin(x * K * 3 + Math.sin(y * 0.073 + o1) * 1.6 + Math.sin(x * K * 5 + o2) * 0.9 + y * 0.033);
          const a2 = Math.sin(x * K * 4 - y * 0.057 + Math.sin(x * K * 2 + y * 0.047 + o2) * 1.8 + o1);
          const a = Math.min(1, Math.pow(1 - Math.abs(a1), 5) + Math.pow(1 - Math.abs(a2), 5) * 0.8) * fade;
          if (a > 0.012) p.d[y * W + x] = px(235 * a, 214, 252, 255);
        }
      }
      this.caust.push(p.toCanvas());
    }
    // ---- sea surface: two pixel-art wave strips that slide against each other ----
    for (let v = 0; v < 2; v++) {
      const W = 256,
        H = 16,
        p = new Pix(W, H),
        K = TAU / W;
      const FO = C("#ffffff"),
        L1 = C("#d6fcff"),
        L2 = C("#a2f2ff");
      for (let x = 0; x < W; x++) {
        const y0 = Math.round(4 + (v ? 1.6 * Math.sin(x * K * 5 + 1) + 1.1 * Math.sin(x * K * 11) : 2.2 * Math.sin(x * K * 3) + Math.sin(x * K * 8 + 2)));
        p.set(x, y0, FO);
        p.set(x, y0 + 1, FO);
        p.set(x, y0 + 2, L1);
        p.set(x, y0 + 3, L1);
        for (let d = 4; d < 10; d++) if (bayer(x, y0 + d) > (d - 3) / 7) p.set(x, y0 + d, L2);
        if (hash2(x, v, 7) < 0.05) p.set(x, y0 + 6 + ((hash2(x, v, 9) * 4) | 0), FO);
      }
      this.waves.push(p.toCanvas());
    }
    // ---- soft luminous mist bands that mark where one depth zone hands over to the next ----
    for (const col of ["150, 206, 255", "172, 134, 255", "255, 152, 96"]) {
      const cv = document.createElement("canvas");
      cv.width = 4;
      cv.height = 64;
      const c = cv.getContext("2d")!;
      const lg = c.createLinearGradient(0, 0, 0, 64);
      lg.addColorStop(0, `rgba(${col}, 0)`);
      lg.addColorStop(0.5, `rgba(${col}, 0.3)`);
      lg.addColorStop(1, `rgba(${col}, 0)`);
      c.fillStyle = lg;
      c.fillRect(0, 0, 4, 64);
      this.mist.push(cv);
    }
    // ---- vignette: deep-water darkness closing in from the edges ----
    // (drawn at about world resolution so it can be laid over the screen without smooth scaling)
    const vg = document.createElement("canvas");
    vg.width = 320;
    vg.height = 180;
    const vc = vg.getContext("2d")!;
    vc.setTransform(1, 0, 0, 180 / 320, 0, 0);
    const rg = vc.createRadialGradient(160, 150, 60, 160, 160, 236);
    rg.addColorStop(0, "rgba(3, 5, 26, 0)");
    rg.addColorStop(0.55, "rgba(3, 5, 26, 0.3)");
    rg.addColorStop(1, "rgba(3, 5, 26, 0.96)");
    vc.fillStyle = rg;
    vc.fillRect(0, 0, 320, 320);
    this.vig = vg;
    // ---- far-off clouds of bioluminescence behind the deep pinnacles (tiles horizontally, half resolution) ----
    const nb = document.createElement("canvas");
    nb.width = 920;
    nb.height = 460;
    const nc = nb.getContext("2d")!;
    const NEB = ["rgba(120, 92, 255, 0.5)", "rgba(44, 196, 255, 0.45)", "rgba(226, 92, 224, 0.42)"];
    const nr = rng(4242);
    for (let i = 0; i < 9; i++) {
      const x = (i + nr() * 0.8) * 102,
        y = 70 + nr() * 330,
        rx = 80 + nr() * 80,
        ry = 46 + nr() * 46;
      nc.globalAlpha = 0.5 + nr() * 0.4;
      for (const dx of [-920, 0, 920]) nc.drawImage(glowOrb(NEB[i % 3], false), x + dx - rx, y - ry, rx * 2, ry * 2);
    }
    this.neb = nb;
    // ---- the sun seen through the surface: a wide warm bloom with a hot core (pre-rendered at final size) ----
    const bl = document.createElement("canvas");
    bl.width = 460;
    bl.height = 300;
    const bc = bl.getContext("2d")!;
    const sunOrb = glowOrb("rgba(255, 252, 214, 0.6)", false);
    bc.globalCompositeOperation = "lighter";
    bc.globalAlpha = 0.8;
    bc.drawImage(sunOrb, 0, 0, 460, 300);
    bc.globalAlpha = 0.9;
    bc.drawImage(sunOrb, 140, 64, 180, 120);
    this.bloom = bl;
  }

  private makeWater(): HTMLCanvasElement {
    const w = 64,
      h = WORLD_H + WPAD * 2,
      p = new Pix(w, h),
      BAND = 16;
    for (let y = 0; y < h; y++) {
      const wy = y - WPAD,
        k = Math.floor(wy / BAND),
        f = (wy - k * BAND) / BAND;
      const c0 = waterC(k * BAND),
        c1 = waterC((k + 1) * BAND);
      const th = (f - 0.45) / 0.55;
      for (let x = 0; x < w; x++) p.d[y * w + x] = th > 0 && bayer(x, y) < th ? c1 : c0;
    }
    return p.toCanvas();
  }

  // ==========================================================================
  // LAYER 0 (0.12x): Ultra-Far Majestic Seamounts, Sunken Galleon & Ancient Temple Spires
  // Lightest, most sunlit cyan-turquoise tones, soaring high up into the water horizon!
  // ==========================================================================
  private *makeFar1(): Generator<void, HTMLCanvasElement, void> {
    const w = 1800,
      h = 640,
      p = new Pix(w, h);
    const ridge = (x: number) => {
      const t = (x / w) * TAU;
      return (
        260 -
        Math.sin(t * 2 + 0.5) * 82 -
        Math.cos(t * 3 - 1.1) * 44 -
        Math.pow(Math.max(0, Math.sin(t * 2 - 0.8)), 4) * 125 -
        Math.sin(t * 7 + 1.2) * 20
      );
    };
    // Ultra-pale, sunlit cyan-turquoise silhouette palette matching reference concept art!
    const K = P("#a2f2ff", "#72def5", "#48caea", "#2faed2"),
      D = K[2];

    // Distant Sunken Galleon Shipwreck resting on a seamount peak
    const gx = 540,
      gy = Math.round(ridge(gx)) + 12;
    p.poly([gx - 78, gy - 22, gx - 30, gy + 16, gx + 62, gy + 12, gx + 90, gy - 34, gx + 44, gy - 28, gx + 26, gy - 14, gx - 42, gy - 12, gx - 58, gy - 34], D);
    const spars = [
      [gx + 72, gy - 24, gx + 120, gy - 44, 3],
      [gx - 12, gy - 12, gx - 6, gy - 102, 3],
      [gx + 32, gy - 14, gx + 38, gy - 84, 3],
      [gx - 36, gy - 72, gx + 20, gy - 78, 2],
      [gx - 28, gy - 46, gx + 16, gy - 51, 2],
      [gx + 14, gy - 60, gx + 56, gy - 65, 2],
      [gx - 6, gy - 100, gx - 70, gy - 26, 1],
      [gx + 38, gy - 82, gx + 86, gy - 30, 1],
    ];
    for (const [x0, y0, x1, y1, th] of spars) p.line(x0, y0, x1, y1, D, th);
    for (let y = gy - 76; y < gy - 50; y++) for (let x = gx - 30; x < gx + 14; x++) if (bayer(x, y) < 0.62 - (y - (gy - 76)) * 0.014 && hash2(x >> 2, y >> 2, 3) < 0.8) p.set(x, y - (x - gx) * 0.1, D);

    // Distant Sunken Temple Columns & Broken Lintel
    const tx = 1360,
      ty = Math.round(ridge(tx)) + 10;
    for (const [cx, ch] of [[-52, 58], [-22, 74], [12, 46], [44, 68]]) {
      p.rect(tx + cx - 5, ty - ch, 10, ch + 15, D);
      p.rect(tx + cx - 8, ty - ch - 4, 16, 4, D);
      p.rect(tx + cx - 7, ty - 3, 14, 3, D);
    }
    p.poly([tx - 64, ty - 80, tx - 12, ty - 86, tx - 12, ty - 78, tx - 64, ty - 72], D);
    yield;
    yield* fillRidge(p, ridge, K, 5, 110);
    return p.toCanvas();
  }

  // ==========================================================================
  // LAYER 1 (0.25x): Far Midground Reef Ridge, Natural Stone Arches & Pagoda Shelves
  // Soft medium-pale oceanic teal-blue tones overlapping Layer 0
  // ==========================================================================
  private *makeFar2(): Generator<void, HTMLCanvasElement, void> {
    const w = 1900,
      h = 580,
      p = new Pix(w, h),
      r = rng(303);
    const ridge = (x: number) => {
      const t = (x / w) * TAU;
      return (
        310 -
        Math.sin(t * 2 + 1.4) * 64 -
        Math.sin(t * 5) * 32 -
        Math.pow(Math.max(0, Math.cos(t * 2 - 0.5)), 3) * 110 -
        Math.cos(t * 8) * 18
      );
    };
    const K = P("#4eb2e2", "#2c8cc2", "#1d72a8", "#12548a");
    const FP = [K[2], K[2], K[1], K[3], K[0]];
    let nCoral = 0;
    for (let x = 30; x < w - 30; x += 24 + r() * 28) {
      if ((++nCoral & 7) === 0) yield;
      const y = Math.round(ridge(x)) + 4,
        k = r(),
        sd = (r() * 999) | 0;
      const s = k < 0.3 ? genBranch(sd, FP, 0, 46, 46, 11, 3.2, 3) : k < 0.5 ? genTable(sd, FP, 0, 42, 30) : k < 0.68 ? genFan(sd, FP, 46, 46) : k < 0.82 ? genTubes(sd, FP, 0, 34, 42) : k < 0.92 ? genWhip(sd, FP, 44, 54) : genKelp(sd, FP, 50, 84);
      p.blit(s, x - (s.w >> 1), y - s.h + 2);
    }
    yield;
    yield* fillRidge(p, ridge, K, 9, 110);
    yield;
    for (const [ax, aw, ah] of [[380, 95, 68], [980, 115, 76], [1560, 92, 64]]) {
      const ay = Math.round(ridge(ax)) + 115;
      for (let y = ay - ah - 3; y <= ay + ah * 0.4; y++)
        for (let x = ax - aw - 3; x <= ax + aw + 3; x++) {
          const u = (x - ax) / aw,
            v = (y - ay) / ah;
          const inside = v <= 0 ? u * u + v * v < 1 : Math.abs(u) < 1 && v < 0.38 * (1 - u * u);
          if (inside) p.set(x, y, 0);
          else if (v <= 0 && u * u + v * v < 1.08 && p.get(x, y)) p.set(x, y, K[0]);
        }
    }
    return p.toCanvas();
  }

  // ==========================================================================
  // LAYER 2 (0.48x): Midground Coral Terraces with Silhouetted Sea Fans & Sponges
  // Rich deep oceanic blue tones
  // ==========================================================================
  private *makeFar3(): Generator<void, HTMLCanvasElement, void> {
    const w = 2100,
      h = 480,
      p = new Pix(w, h),
      m = new Uint8Array(w * h),
      r = rng(509);
    const top = new Int16Array(w);
    for (let x = 0; x < w; x++) {
      const t = (x / w) * TAU;
      const y = Math.round(
        (280 - Math.sin(t * 3 + 0.4) * 54 - Math.cos(t * 6 + 2) * 28 + Math.sin(t * 23) * 6) / 3
      ) * 3;
      top[x] = y;
      for (let yy = y; yy < h; yy++) m[yy * w + x] = 1;
    }
    yield* paintRock(p, m, FAR_ROCK, 509, 17);
    fadeBottom(p, 95);
    plant(r, this.farBio, FAR_TBL, top, 8, w - 8, 0, 0, this.farInsts, 4);
    this.farInsts.sort((a, b) => b.s.h - a.s.h);
    return p.toCanvas();
  }

  // ==========================================================================
  // DEEP LAYERS (0.24x / 0.48x): forests of rooted pinnacles, arches & glowing veins
  // ==========================================================================
  private *makeDeep1(): Generator<void, HTMLCanvasElement, void> {
    const w = 1800,
      h = 1010,
      p = new Pix(w, h);
    const { m } = yield* spireMask(w, h, rng(777), 9, 60, 540, 34, 80);
    yield* paintFlat(p, m, P("#3c4eb0", "#1d2a7c", "#151d5e", "#283890"), 3);
    return p.toCanvas();
  }

  private *makeDeep2(): Generator<void, HTMLCanvasElement, void> {
    const w = 2000,
      h = 980,
      r = rng(1414),
      p = new Pix(w, h);
    const { m, caps } = yield* spireMask(w, h, r, 7, 90, 560, 46, 96);
    // natural stone arches bridging neighbouring pinnacles
    for (const i of [1, 4]) {
      const a = caps[i],
        b = caps[i + 1];
      const x0 = Math.round(a[0] + a[2] * 0.4),
        x1 = Math.round(b[0] - b[2] * 0.4),
        y0 = a[1] + 8,
        y1 = b[1] + 8;
      for (let x = x0; x <= x1; x++) {
        const f = (x - x0) / (x1 - x0),
          yc = y0 + (y1 - y0) * f - Math.sin(f * Math.PI) * 44,
          th = 9 + Math.abs(f - 0.5) * 16 + Math.sin(x * 0.2) * 1.5;
        for (let y = Math.round(yc - th * 0.4); y <= yc + th * 0.6; y++) if (y >= 0 && y < h) m[y * w + x] = 1;
      }
    }
    // distant coral silhouettes rooted on every cap
    const DP = P("#0c1040", "#1a2068", "#2c3a98", "#4658c0", "#7ad8f0");
    for (const [cx, ty, R, ch] of caps) {
      for (let k = 0; k < 4; k++) {
        const x = Math.round(cx + (r() - 0.5) * R * 1.3),
          xi = ((x % w) + w) % w;
        let sy = Math.max(0, Math.floor(ty - ch - 2));
        while (sy < h - 1 && !m[sy * w + xi]) sy++;
        const sd = (r() * 999) | 0,
          q = r();
        const s = q < 0.35 ? genBranch(sd, DP, 0, 46, 46, 11, 3.2, 3) : q < 0.6 ? genFan(sd, DP, 46, 46) : q < 0.8 ? genWhip(sd, DP, 44, 58, true) : genTubes(sd, DP, 0, 34, 42);
        if (x > 30 && x < w - 30) p.blit(s, x - (s.w >> 1), sy - s.h + 2);
      }
      yield;
    }
    yield* paintRock(p, m, DEEP_ROCK, 1414, 17);
    p.tint(C("#171b5c"), 0.4); // heavy haze: these pinnacles are scenery far behind the playable reef
    yield;
    const veins = [C("#52e6ff"), C("#f07af6"), C("#9c8cff")],
      glows = ["rgba(60, 220, 255, 0.5)", "rgba(240, 110, 250, 0.5)", "rgba(150, 130, 255, 0.5)"];
    for (const [cx, ty, R] of caps) {
      for (let k = 0; k < 3; k++) {
        let x = cx + (r() - 0.5) * R * 1.2,
          y = ty - 4 + r() * 10;
        const vi = (r() * 3) | 0,
          len = 30 + r() * 100;
        for (let s = 0; s < len; s++) {
          x += (r() - 0.5) * 1.7;
          y += 0.6 + r() * 0.8;
          const xi = ((Math.round(x) % w) + w) % w;
          if (p.get(xi, Math.round(y)) && s % 5 !== 4) p.set(xi, Math.round(y), veins[vi]);
        }
        this.deepGlows.push({ x: cx + (r() - 0.5) * R, y: ty + r() * 30, c: glows[vi], ph: r() * 6 });
      }
    }
    return p.toCanvas();
  }

  // ==========================================================================
  // MAIN PLANE: reef pinnacles (collidable crown + rooted stem) at three depth levels
  // ==========================================================================
  private *buildFormations(p0: number, p1: number): Generator<number | void, void, void> {
    const r = rng(2026);
    const specs: [number, number, number, number, number][] = [
      [560, 460, 168, 74, 0],
      [1420, 525, 188, 80, 0],
      [2340, 455, 172, 75, 0],
      [3220, 515, 178, 78, 0],
      [380, 990, 212, 94, 1],
      [1020, 1065, 198, 90, 1],
      [1760, 980, 222, 96, 1],
      [2520, 1055, 208, 92, 1],
      [3320, 995, 216, 94, 1],
      [700, 1440, 184, 88, 2],
      [1420, 1500, 198, 94, 2],
      [2140, 1420, 188, 90, 2],
      [2920, 1490, 202, 94, 2],
    ];
    let done = 0;
    for (const [x, y, rx, ry, z] of specs) {
      this.formations.push(yield* this.makePinnacle(r, x, y, rx, ry, z));
      yield p0 + ((p1 - p0) * ++done) / specs.length;
    }
    for (const f of this.formations) this.colliders.push(...f.colliders);
  }

  private *makePinnacle(r: Rnd, wx: number, wy: number, rx: number, ry: number, zone: number): Generator<void, Formation, void> {
    const seed = (r() * 1e6) | 0;
    const padX = 12,
      padT = 6,
      padB = Math.round(ry * 0.5) + 8;
    const W = Math.round(rx * 2) + padX * 2,
      H = Math.round(ry * 1.72) + padT + padB;
    const cxl = W >> 1,
      cyl = padT + Math.round(ry * 0.84);
    const ox = Math.round(wx) - cxl,
      oy = Math.round(wy) - cyl;
    const p = new Pix(W, H),
      m = new Uint8Array(W * H);
    const top = new Int16Array(W).fill(-1),
      bot = new Int16Array(W).fill(-1);
    const s1 = r() * 9,
      s2 = r() * 9,
      s3 = r() * 9,
      s4 = r() * 9;
    let firstX = -1,
      lastX = 0;
    for (let x = 0; x < W; x++) {
      const u = (x - cxl) / rx;
      if (Math.abs(u) >= 1) continue;
      // stepped mesa top (4px terraces give corals level ledges to grow on)
      const ty = Math.max(1, Math.round((cyl - ry * 0.8 * Math.pow(1 - Math.pow(Math.abs(u), 2.6), 0.6) + Math.sin(x * 0.047 + s1) * 5 + Math.sin(x * 0.12 + s2) * 2.2) / 4) * 4);
      const drip = zone > 0 ? Math.pow(Math.max(0, Math.sin(x * 0.19 + s4)), 5) * ry * 0.34 : Math.pow(Math.max(0, Math.sin(x * 0.15 + s4)), 3) * ry * 0.12;
      const by = Math.min(H - 2, Math.round(cyl + ry * 0.84 * Math.sqrt(1 - u * u) * (0.82 + 0.18 * Math.sin(x * 0.06 + s3)) + drip));
      if (by - ty < 6) continue;
      top[x] = ty;
      bot[x] = by;
      if (firstX < 0) firstX = x;
      lastX = x;
      for (let y = ty; y <= by; y++) m[y * W + x] = 1;
    }
    const st = ROCK[zone];
    yield* paintRock(p, m, st, seed, 15);

    // shadowed grotto pockets in the cliff face
    for (let k = 0; k < 3; k++) {
      const gx = Math.round(cxl + (r() - 0.5) * rx * 1.1),
        gy = Math.round(cyl + ry * (0.05 + r() * 0.35)),
        grx = 6 + r() * 7,
        gry = 3 + r() * 3;
      for (let y = gy - gry - 1; y <= gy + gry + 1; y++)
        for (let x = gx - grx - 1; x <= gx + grx + 1; x++) {
          const xi = Math.round(x),
            yi = Math.round(y);
          if (xi < 1 || yi < 1 || xi >= W - 1 || yi >= H - 1 || !m[yi * W + xi] || yi - top[xi] < 8 || bot[xi] - yi < 5) continue;
          const dd = ((x - gx) / grx) ** 2 + ((y - gy) / gry) ** 2;
          if (dd < 0.7) p.d[yi * W + xi] = st.ramp[0];
          else if (dd < 1) p.d[yi * W + xi] = st.ramp[1];
          else if (dd < 1.5 && y > gy) p.d[yi * W + xi] = st.ramp[4];
        }
    }

    // ---- plant the crown: every holdfast is embedded in the rock + gets a contact shadow ----
    const insts: Inst[] = [];
    const shade = (x: number, y: number, f: number) => {
      for (let dx = -f - 2; dx <= f + 2; dx++) {
        const xi = x + dx;
        if (xi < 0 || xi >= W) continue;
        for (let dy = 0; dy < 3; dy++) {
          const yi = y + dy;
          if (yi < H && m[yi * W + xi] && (dy < 2 || bayer(xi, yi) < 0.55)) p.d[yi * W + xi] = dy === 0 ? st.crust[0] : st.ramp[2];
        }
      }
    };
    const occ = new Uint8Array(W);
    const px0 = Math.max(firstX + 5, Math.round(cxl - rx * 0.9)),
      px1 = Math.min(lastX - 5, Math.round(cxl + rx * 0.9));
    plant(r, this.bio, TOP_BIO[zone], top, px0, px1, ox, oy, insts, 4, shade, occ);
    plant(r, this.bio, FILL_BIO[zone], top, px0, px1, ox, oy, insts, 4, shade, occ, true);
    insts.sort((a, b) => b.s.h - a.s.h);

    // starfish clinging to the upper rock face
    const stars = this.bio[STAR_BIO[zone]];
    for (let k = 0; k < 2; k++) {
      const x = Math.round(firstX + 30 + r() * (lastX - firstX - 60));
      if (top[x] >= 0) insts.push({ s: stars[(r() * stars.length) | 0], x: ox + x, y: oy + top[x] + 10 + ((r() * 5) | 0), ph: r() * NF, flip: false, hide: 0 });
    }
    // bracket corals growing out of both cliff walls
    const shelf = this.bio[SIDE_BIO[zone]];
    for (const fy of [-0.3, 0.02, 0.3]) {
      const yy = Math.round(cyl + ry * fy);
      let xl = 0;
      while (xl < W && !m[yy * W + xl]) xl++;
      let xr = W - 1;
      while (xr > 0 && !m[yy * W + xr]) xr--;
      if (xl >= xr) continue;
      if (r() < 0.8) insts.push({ s: shelf[(r() * shelf.length) | 0], x: ox + xl + 3, y: oy + yy, ph: r() * NF, flip: true, hide: 0 });
      if (r() < 0.8) insts.push({ s: shelf[(r() * shelf.length) | 0], x: ox + xr - 3, y: oy + yy, ph: r() * NF, flip: false, hide: 0 });
    }
    // vines hanging from the overhang (anchored in the ceiling)
    const vines = this.bio[HANG_BIO[zone]];
    for (let x = firstX + 16 + r() * 20; x < lastX - 16; x += 24 + r() * 34) {
      const xi = Math.round(x);
      if (bot[xi] > 0 && Math.abs(xi - cxl) > rx * 0.3) insts.push({ s: vines[(r() * vines.length) | 0], x: ox + xi, y: oy + bot[xi], ph: r() * NF, flip: r() < 0.5, hide: 0 });
    }
    if (zone < 2) this.crabs.push({ top, ox, oy, x0: cxl + (r() - 0.5) * rx * 0.6, range: rx * 0.32, sp: 0.22 + r() * 0.15, ph: r() * 6, v: (r() * 2) | 0 });

    // ---- the stem: a rooted pinnacle column on the back plane ----
    const colTop = Math.round(wy + ry * 0.25);
    const rooted = zone === 2;
    const colBot = rooted ? Math.round(floorY(wx)) + 18 : Math.round(wy + ry + 330 + r() * 110);
    const col = yield* this.makeColumn(r, colTop, colBot, rx * 0.3, rooted, zone, seed + 5);

    const colliders: RockCollider[] = [
      { x: wx - rx * 0.46, y: wy, r: ry * 0.66 },
      { x: wx, y: wy, r: ry * 0.78 },
      { x: wx + rx * 0.46, y: wy, r: ry * 0.66 },
    ];
    return { x: ox, y: oy, w: W, h: H, cv: p.toCanvas(), col, colX: Math.round(wx) - (col.width >> 1), colY: colTop, insts, colliders };
  }

  private *makeColumn(r: Rnd, yTop: number, yBot: number, hw0: number, rooted: boolean, zone: number, seed: number): Generator<void, HTMLCanvasElement, void> {
    const H = Math.max(40, yBot - yTop),
      W = Math.round(hw0 * 3.4 + (rooted ? 140 : 54));
    const p = new Pix(W, H),
      m = new Uint8Array(W * H);
    const s1 = r() * 9,
      s2 = r() * 9,
      s3 = r() * 9,
      s4 = r() * 9,
      lean = (r() - 0.5) * 30;
    for (let y = 0; y < H; y++) {
      const t = y / H;
      let hw = hw0 * (0.92 + 0.5 * Math.pow(t, 1.4)) + Math.sin(y * 0.043 + s1) * 5 + Math.sin(y * 0.13 + s2) * 2.2 + (Math.floor(y / 41 + s3) & 1) * 4;
      if (rooted) hw += Math.pow(Math.max(0, (t - 0.7) / 0.3), 2) * 38;
      const cx = W / 2 + Math.sin(y * 0.017 + s4) * 7 + lean * t;
      const a = Math.max(0, Math.round(cx - hw)),
        b = Math.min(W - 1, Math.round(cx + hw));
      for (let x = a; x <= b; x++) m[y * W + x] = 1;
    }
    yield* paintRock(p, m, ROCK[zone], seed, 19, 1, false);
    // atmospheric haze: the stem recedes into the water colour and (if not rooted on screen) dithers away
    for (let y = 0; y < H; y++) {
      const t = y / H,
        wc = waterC(yTop + y),
        a = rooted ? 0.3 : Math.min(0.97, 0.3 + Math.pow(t, 0.75) * 0.7),
        cut = rooted ? -1 : (t - 0.58) / 0.42;
      for (let x = 0; x < W; x++) {
        const i = y * W + x;
        if (!p.d[i]) continue;
        if (cut > 0 && bayer(x, y) < cut) p.d[i] = 0;
        else p.d[i] = mixC(p.d[i], wc, a);
      }
    }
    return p.toCanvas();
  }

  // ==========================================================================
  // ABYSSAL FLOOR: boulders, sediment, black smokers, tube-worm colonies, treasure
  // ==========================================================================
  private *makeFloor(): Generator<void, HTMLCanvasElement, void> {
    const W = WORLD_W,
      H = WORLD_H + 75 - FLOOR_TOP,
      O = FLOOR_TOP;
    const p = new Pix(W, H),
      m = new Uint8Array(W * H),
      top = new Int16Array(W),
      r = rng(1234);
    for (let x = 0; x < W; x++) top[x] = Math.round(floorY(x)) - O;
    for (let i = 0; i < 46; i++) {
      const bx = (r() * W) | 0,
        brx = 9 + r() * 20,
        bry = 4 + r() * 9,
        b0 = floorY(bx) - O + 2;
      for (let x = Math.max(0, Math.floor(bx - brx)); x <= Math.min(W - 1, bx + brx); x++) {
        const u = (x - bx) / brx,
          yy = Math.round(b0 - bry * Math.sqrt(Math.max(0, 1 - u * u)));
        if (yy < top[x]) top[x] = yy;
      }
    }
    for (let x = 0; x < W; x++) for (let y = top[x]; y < H; y++) m[y * W + x] = 1;
    const st = ROCK[3];
    yield* paintRock(p, m, st, 77, 22);
    yield;
    // bioluminescent specks in the sediment
    const sp = [C("#62e8ff"), C("#f48af0"), C("#9c8cff")];
    for (let x = 2; x < W - 2; x++) if (hash2(x, 9, 4) < 0.035) p.set(x, top[x] + 1 + ((hash2(x, 2, 4) * 3) | 0), sp[(hash2(x, 5, 4) * 3) | 0]);

    const shade = (x: number, y: number, f: number) => {
      for (let dx = -f - 2; dx <= f + 2; dx++) {
        const xi = x + dx;
        if (xi < 0 || xi >= W) continue;
        for (let dy = 0; dy < 3; dy++) {
          const yi = y + dy;
          if (yi >= top[xi] && yi < H && (dy < 2 || bayer(xi, yi) < 0.55)) p.d[yi * W + xi] = dy === 0 ? st.crust[0] : st.ramp[2];
        }
      }
    };
    const ptop = top.slice(); // planting profile with reserved gaps for set pieces
    const reserve = (x: number, hw: number) => {
      for (let k = Math.max(0, x - hw); k <= Math.min(W - 1, x + hw); k++) ptop[k] = -1;
    };
    const lowest = (x: number, f: number) => {
      let lo = 0;
      for (let k = -f; k <= f; k++) lo = Math.max(lo, top[Math.max(0, Math.min(W - 1, x + k))]);
      return lo;
    };
    const chestX = Math.round(W * 0.62);
    // black-smoker vent field
    const vents = this.bio.vent,
      rift = this.bio.riftia;
    for (let i = 0; i < 9; i++) {
      const x = Math.round(190 + i * 415 + r() * 110);
      if (Math.abs(x - chestX) < 90) continue;
      const base = lowest(x, 10);
      this.floorInsts.push({ s: vents[i % vents.length], x, y: O + base, ph: r() * NF, flip: false, hide: 0 });
      shade(x, base, 12);
      this.vents.push({ x: x + 2, y: O + base - 30 });
      reserve(x, 20);
      for (const dx of [-34, 36, 62]) {
        if (r() < 0.25) continue;
        const rx = x + dx + ((r() * 8) | 0),
          rb = lowest(rx, 9);
        this.floorInsts.push({ s: rift[(r() * rift.length) | 0], x: rx, y: O + rb, ph: r() * NF, flip: r() < 0.5, hide: 0 });
        shade(rx, rb, 9);
        reserve(rx, 14);
      }
    }
    // treasure chest
    const cb = lowest(chestX, 12);
    this.floorInsts.push({ s: this.bio.chest[0], x: chestX, y: O + cb, ph: 0, flip: false, hide: 0 });
    shade(chestX, cb, 14);
    reserve(chestX, 24);
    this.chestPos = { x: chestX, y: O + cb - 14 };

    const occ = new Uint8Array(W);
    plant(r, this.bio, TOP_BIO[3], ptop, 6, W - 6, 0, O, this.floorInsts, 6, shade, occ);
    plant(r, this.bio, FILL_BIO[3], ptop, 6, W - 6, 0, O, this.floorInsts, 6, shade, occ, true);
    this.floorInsts.sort((a, b) => b.s.h - a.s.h);
    const wtop = new Int16Array(W);
    for (let x = 0; x < W; x++) wtop[x] = top[x];
    for (let i = 0; i < 9; i++) this.crabs.push({ top: wtop, ox: 0, oy: O, x0: 200 + r() * (W - 400), range: 60 + r() * 80, sp: 0.12 + r() * 0.12, ph: r() * 6, v: (r() * 2) | 0 });
    return p.toCanvas();
  }

  // ==========================================================================
  // PIXEL-PERFECT BLIT HELPERS (snap everything to the device pixel grid)
  // ==========================================================================
  private sn(v: number) {
    return Math.round(v * this.pxs) / this.pxs;
  }

  private blit(ctx: Ctx, cv: HTMLCanvasElement, sx: number, sy: number, sw: number, sh: number, dx: number, dy: number) {
    const s = this.pxs;
    const x0 = Math.round(dx * s) / s,
      y0 = Math.round(dy * s) / s,
      x1 = Math.round((dx + sw) * s) / s,
      y1 = Math.round((dy + sh) * s) / s;
    ctx.drawImage(cv, sx, sy, sw, sh, x0, y0, x1 - x0, y1 - y0);
  }

  private spr(ctx: Ctx, cv: HTMLCanvasElement, x: number, y: number, flip = false) {
    const s = this.pxs;
    const x0 = Math.round(x * s) / s,
      y0 = Math.round(y * s) / s,
      w = Math.round(cv.width * s) / s,
      h = Math.round(cv.height * s) / s;
    if (flip) {
      ctx.setTransform(-s, 0, 0, s, (x0 + w) * s, y0 * s);
      ctx.drawImage(cv, 0, 0, w, h);
      ctx.setTransform(s, 0, 0, s, 0, 0);
    } else ctx.drawImage(cv, x0, y0, w, h);
  }

  private tile(ctx: Ctx, cv: HTMLCanvasElement, scroll: number, dy: number, vw: number, vh: number): number {
    const W = cv.width,
      H = cv.height;
    dy = this.sn(dy);
    const off = (((this.sn(scroll) % W) + W) % W);
    if (dy > vh || dy + H < 0) return off;
    const sy0 = Math.max(0, -dy),
      sh = Math.min(H - sy0, vh + 1 - Math.max(0, dy));
    if (sh <= 0) return off;
    for (let dx = -off; dx < vw; dx += W) {
      const sx0 = Math.max(0, -dx),
        sw = Math.min(W - sx0, vw + 1 - (dx + sx0));
      if (sw > 0) this.blit(ctx, cv, sx0, sy0, sw, sh, dx + sx0, dy + sy0);
    }
    return off;
  }

  private drawInst(ctx: Ctx, b: Inst, sx: number, sy: number, t: number) {
    const s = b.s;
    let cv: HTMLCanvasElement;
    if (s.shy) {
      const near = Math.abs(b.x - this.focusX) < 44 && Math.abs(b.y - 12 - this.focusY) < 46;
      b.hide = clamp01(b.hide + (near ? 7 : -1.5) * this.dt);
    }
    if (s.shy && b.hide > 0.25) cv = b.hide > 0.7 ? s.shy[1] : s.shy[0];
    else cv = s.f[Math.floor(t * s.fps + b.ph) % NF];
    if (s.mode === 0) this.spr(ctx, cv, sx - (s.w >> 1), sy - s.h + 2, b.flip);
    else if (s.mode === 1) this.spr(ctx, cv, sx - (s.w >> 1), sy - 2, b.flip);
    else this.spr(ctx, cv, b.flip ? sx - s.w + 1 : sx, sy - (s.h >> 1), b.flip);
  }

  private glowInst(ctx: Ctx, b: Inst, sx: number, sy: number, t: number) {
    const s = b.s;
    if (!s.glow) return;
    const rad = Math.max(s.w, s.h) * 0.9;
    ctx.globalAlpha = (0.55 + 0.45 * Math.sin(t * 2.2 + b.ph * 1.7)) * (b.hide > 0.5 ? 0.3 : 1);
    const gy = s.mode === 1 ? sy + s.h * (s.gy ?? 0.5) : s.mode === 2 ? sy : sy - s.h * (s.gy ?? 0.5);
    ctx.drawImage(glowOrb(s.glow, false), sx - rad, gy - rad, rad * 2, rad * 2);
  }

  // ==========================================================================
  // RUNTIME RENDERING
  // ==========================================================================
  drawWater(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    this.dt = Math.min(0.05, Math.max(0, this.time - this.lastT));
    this.lastT = this.time;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    const T = this.water,
      TW = T.width;
    const sy = Math.max(0, Math.min(T.height - vh - 1, this.sn(camTop) + WPAD));
    const off = (((this.sn(camLeft) % TW) + TW) % TW);
    for (let dx = -off; dx < vw; dx += TW) this.blit(ctx, T, 0, sy, TW, vh + 1, dx, 0);
    ctx.imageSmoothingEnabled = sm;
  }

  /** a cleared off-screen buffer covering the view at world resolution (1 texel = 1 world unit) */
  private lightBuf(i: number, vw: number, vh: number): Ctx {
    const w = Math.ceil(vw) + 1,
      h = Math.ceil(vh) + 1;
    let cv = this.lb[i];
    if (!cv) {
      cv = this.lb[i] = document.createElement("canvas");
      this.lbc[i] = cv.getContext("2d")!;
    }
    const c = this.lbc[i];
    if (cv.width !== w || cv.height !== h) {
      cv.width = w; // (resizing also clears)
      cv.height = h;
    } else c.clearRect(0, 0, w, h);
    c.globalCompositeOperation = "lighter";
    c.imageSmoothingEnabled = true;
    return c;
  }

  /**
   * SUNLIGHT, composed at world resolution — the same texel grid as the pixel-art scenery — in a small
   * off-screen buffer, then laid over the scene with ONE unsmoothed blit:
   *   set 0 (behind the distant ridges): the sun's bloom, wide far shafts and caustic nets under the surface
   *   set 1 (in front of the reef and the fish): medium and thin shafts
   * The shafts fan out from the sun. No gradient is created per frame, and the soft blending only ever
   * touches about a seventh of the screen's pixels.
   */
  drawLight(ctx: Ctx, set: number, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    const fade = clamp01(1 - (camTop - 180) / 860); // sunlight dies away through the twilight zone
    if (fade <= 0.01) return;
    const c = this.lightBuf(set, vw, vh);
    const top = -camTop;
    const sunX = vw * 0.5 + (SUN_X - (camLeft + vw * 0.5)) * 0.14;
    let drawn = false;
    if (set === 0 && top > -230) {
      c.imageSmoothingEnabled = false; // 1:1 copies: no filtering needed
      c.globalAlpha = fade;
      c.drawImage(this.bloom, Math.round(sunX - 230), Math.round(top - 110));
      c.imageSmoothingEnabled = true;
      drawn = true;
    }
    for (const r of this.rays) {
      if ((r.layer === 0) !== (set === 0)) continue;
      const sx = ((((r.x - camLeft * RAY_PAR[r.layer]) % RAY_PERIOD) + RAY_PERIOD) % RAY_PERIOD) - 300;
      const ang = Math.max(-0.5, Math.min(0.5, (sx - sunX) / 950)) + Math.sin(t * 0.21 + r.ph) * 0.03;
      const xm = sx + Math.tan(ang) * Math.max(0, vh * 0.5 - top); // where the leaning shaft crosses mid-screen
      if ((sx < -r.w && xm < -r.w) || (sx > vw + r.w && xm > vw + r.w)) continue;
      const a = r.a * fade * (0.72 + 0.28 * Math.sin(t * 0.63 + r.ph * 2.3)) * (0.86 + 0.14 * Math.sin(t * 1.7 + r.ph));
      if (a < 0.01) continue;
      c.globalAlpha = a;
      const cs = Math.cos(ang),
        sn = Math.sin(ang);
      // only the stretch of the shaft that actually crosses the view is drawn
      const y0 = Math.max(0, (3 - top) / cs - r.w),
        y1 = Math.min(r.len, (vh + 3 - top) / cs + r.w);
      if (y1 - y0 < 2) continue;
      const beam = this.beams[r.v];
      c.setTransform(cs, -sn, sn, cs, sx, top - 3);
      c.drawImage(beam, 0, (y0 / r.len) * beam.height, beam.width, ((y1 - y0) / r.len) * beam.height, -r.w * 0.5, y0, r.w, y1 - y0);
      drawn = true;
    }
    c.setTransform(1, 0, 0, 1, 0, 0);
    if (set === 0 && camTop < 154) {
      // two caustic nets sliding against each other just under the surface
      const W = 384;
      c.imageSmoothingEnabled = false;
      for (let k = 0; k < 2; k++) {
        const scroll = camLeft * (k ? 0.92 : 0.8) + t * (k ? -9 : 13);
        const off = Math.round(((scroll % W) + W) % W);
        const y = Math.round(top + 3 + Math.sin(t * 0.9 + k * 2) * 2.5);
        c.globalAlpha = (k ? 0.36 : 0.44) * fade * (0.8 + 0.2 * Math.sin(t * 1.3 + k * 1.7));
        for (let dx = -off; dx < vw; dx += W) c.drawImage(this.caust[k], dx, y);
      }
      c.imageSmoothingEnabled = true;
      drawn = true;
    }
    if (!drawn) return;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(this.lb[set], 0, 0); // buffer texels are world units: the game's transform scales them up
    ctx.imageSmoothingEnabled = sm;
  }

  drawSurface(ctx: Ctx, camLeft: number, camTop: number, vw: number, t: number) {
    if (camTop > 18) return;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    const y = -camTop - 5;
    for (let k = 1; k >= 0; k--) {
      const cv = this.waves[k],
        W = cv.width;
      const off = (((this.sn(camLeft + t * (k ? -11 : 16)) % W) + W) % W);
      ctx.globalAlpha = k ? 0.55 : 1;
      for (let dx = -off; dx < vw; dx += W) this.spr(ctx, cv, dx, y + k * 2);
    }
    ctx.globalAlpha = 1;
    ctx.imageSmoothingEnabled = sm;
  }

  /** deep-water darkness closing in from the screen edges: absent in the shallows, heavy in the abyss */
  drawVignette(ctx: Ctx, camTop: number, vw: number, vh: number) {
    const a = clamp01((camTop + vh * 0.5 - 260) / 1450) * 0.78;
    if (a < 0.04) return;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    ctx.globalAlpha = a;
    ctx.drawImage(this.vig, 0, 0, vw + 1, vh + 1);
    ctx.globalAlpha = 1;
    ctx.imageSmoothingEnabled = sm;
  }

  /** cached text sprites must be rebuilt once the pixel font has loaded */
  clearText() {
    this.hudTxt.clear();
  }

  private drawDistantPelagics(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const t = this.time;
    ctx.fillStyle = "rgba(16, 72, 128, 0.42)";
    for (const m of this.pelagics) {
      const period = 2600;
      const sx = ((((m.x + m.dir * m.speed * t - camLeft * 0.18) % period) + period) % period) - 160;
      const sy = m.y - camTop * 0.48 + Math.sin(t * 0.7 + m.ph) * 12;
      if (sx < -120 || sx > vw + 120 || sy < -60 || sy > vh + 60) continue;
      ctx.save();
      ctx.translate(sx, sy);
      ctx.scale(m.dir * m.scale, m.scale);
      const flap = Math.sin(t * 2.1 + m.ph) * 6;
      ctx.beginPath();
      if (m.kind === "manta") {
        ctx.moveTo(22, 0);
        ctx.quadraticCurveTo(6, -16 - flap, -10, -22 - flap * 1.2);
        ctx.quadraticCurveTo(-8, -6, -18, -2);
        ctx.lineTo(-42, -1);
        ctx.lineTo(-18, 2);
        ctx.quadraticCurveTo(-8, 6, -10, 18 + flap * 0.9);
        ctx.quadraticCurveTo(6, 12 + flap * 0.7, 22, 0);
      } else {
        ctx.ellipse(0, 0, 38, 10, 0, 0, Math.PI * 2);
        ctx.moveTo(-4, -8);
        ctx.lineTo(-14, -20);
        ctx.lineTo(-18, -8);
        ctx.moveTo(-34, 0);
        ctx.lineTo(-50, -14 + flap * 0.3);
        ctx.lineTo(-44, 0);
        ctx.lineTo(-48, 11 + flap * 0.3);
      }
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  private drawJellyfish(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const t = this.time;
    for (const j of this.jellies) {
      const period = 3400;
      const sx = ((((j.x - camLeft * j.p + Math.sin(t * 0.4 + j.ph) * 24) % period) + period) % period) - 100;
      const sy = j.y - camTop * (0.72 + j.p * 0.28) - Math.sin(t * 0.88 + j.ph) * 9;
      const s = j.s;
      if (sx < -60 || sx > vw + 60 || sy < -70 || sy > vh + 60) continue;
      if (s.glow) {
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 1.76 + j.ph);
        const rad = s.h * 0.95;
        ctx.drawImage(glowOrb(s.glow, false), sx - rad, sy - s.h * 0.75 - rad, rad * 2, rad * 2);
        ctx.restore();
      }
      ctx.globalAlpha = 0.86;
      this.spr(ctx, s.f[Math.floor(t * s.fps + j.ph * 3) % NF], sx - (s.w >> 1), sy - s.h);
      ctx.globalAlpha = 1;
    }
  }

  drawLayers(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const t = this.time;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    const deepBlend = clamp01((camTop - 560) / 460);

    // ---------- sunlit & twilight planes (5-Layer Depth Stacking with Aerial Perspective!) ----------
    if (deepBlend < 1) {
      const fade = 1 - deepBlend * 0.85;
      ctx.save();

      // Layer 0 (Ultra-Far 0.12x Parallax): Towering pale cyan seamounts & spires merging into the water haze
      ctx.globalAlpha = 0.72 * fade;
      const yFar1 = this.sn(110 - camTop * 0.12 - this.far1.height * 0.38);
      this.tile(ctx, this.far1, camLeft * 0.12, yFar1, vw, vh);

      ctx.globalAlpha = fade;
      this.drawDistantPelagics(ctx, camLeft, camTop, vw, vh);

      // Atmospheric Depth Haze 1 (Soft turquoise wash between Layer 0 and Layer 1):
      ctx.fillStyle = "rgba(135, 228, 252, 0.15)";
      ctx.fillRect(0, 0, vw, vh);

      // Layer 1 (Far Midground 0.25x Parallax): Teal-blue arches & pagoda shelves
      ctx.globalAlpha = 0.88 * fade;
      const yFar2 = this.sn(220 - camTop * 0.25 - this.far2.height * 0.42);
      this.tile(ctx, this.far2, camLeft * 0.25, yFar2, vw, vh);

      ctx.globalAlpha = fade;
      this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.32, false);

      // Atmospheric Depth Haze 2 (Soft oceanic blue wash between Layer 1 and Layer 2):
      ctx.fillStyle = "rgba(75, 175, 228, 0.12)";
      ctx.fillRect(0, 0, vw, vh);

      // Layer 2 (Midground Terraces 0.48x Parallax): Deeper blue terraces with silhouetted fans
      const y3 = this.sn(350 - camTop * 0.48 - this.far3.height * 0.45);
      const W3 = this.far3.width;
      const off = this.tile(ctx, this.far3, camLeft * 0.48, y3, vw, vh);
      if (y3 < vh && y3 + 320 > -130) {
        for (const b of this.farInsts) {
          let sx = b.x - off;
          if (sx < -60) sx += W3;
          if (sx > vw + 60) continue;
          this.drawInst(ctx, b, sx, y3 + b.y, t);
        }
      }
      this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.58, false);
      ctx.restore();
    }

    // ---------- midnight & abyss planes: rooted pinnacle forests ----------
    if (camTop + vh > DEEP_START - 240) {
      const alpha = Math.max(0.18, Math.min(1, (camTop + vh - (DEEP_START - 140)) / 340));
      ctx.save();
      {
        // far-off clouds of bioluminescence, pulsing slowly behind everything
        const off = ((((camLeft * 0.16) % 1840) + 1840) % 1840);
        ctx.globalAlpha = alpha * (0.62 + 0.2 * Math.sin(t * 0.4));
        // only the visible part of each tile is blitted (source texels are 2 world units)
        const ny = 1040 - camTop,
          y0 = Math.max(0, -ny),
          y1 = Math.min(920, vh - ny);
        if (y1 - y0 > 2)
          for (let dx = -off; dx < vw; dx += 1840) {
            const x0 = Math.max(0, -dx),
              x1 = Math.min(1840, vw - dx);
            if (x1 - x0 > 2) ctx.drawImage(this.neb, x0 / 2, y0 / 2, (x1 - x0) / 2, (y1 - y0) / 2, dx + x0, ny + y0, x1 - x0, y1 - y0);
          }
      }
      ctx.globalAlpha = alpha * 0.5;
      this.tile(ctx, this.deep1, camLeft * 0.24, D1_Y - camTop, vw, vh);
      ctx.globalAlpha = alpha;
      this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.32, true);
      ctx.globalAlpha = alpha * 0.86;
      const off = this.tile(ctx, this.deep2, camLeft * 0.48, D2_Y - camTop, vw, vh);
      ctx.globalCompositeOperation = "lighter";
      const W2 = this.deep2.width;
      for (const g of this.deepGlows) {
        let sx = (((g.x - off) % W2) + W2) % W2;
        if (sx > vw + 60) sx -= W2;
        const sy = D2_Y + g.y - camTop;
        if (sx < -60 || sx > vw + 60 || sy < -60 || sy > vh + 60) continue;
        ctx.globalAlpha = alpha * (0.4 + 0.35 * Math.sin(t * 1.6 + g.ph));
        ctx.drawImage(glowOrb(g.c, false), sx - 34, sy - 34, 68, 68);
      }
      ctx.globalCompositeOperation = "source-over";
      ctx.globalAlpha = alpha;
      this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.58, true);
      ctx.restore();
    }

    // luminous mist where one depth zone gives way to the next
    for (let i = 1; i < 4; i++) {
      const y = ZONES[i].y - camTop;
      if (y < -70 || y > vh + 70) continue;
      ctx.globalAlpha = 0.55 + 0.25 * Math.sin(t * 0.8 + i * 2);
      ctx.drawImage(this.mist[i - 1], 0, y - 55 + Math.sin(t * 0.5 + i) * 4, vw + 1, 110);
    }
    ctx.globalAlpha = 1;

    this.drawJellyfish(ctx, camLeft, camTop, vw, vh);
    ctx.imageSmoothingEnabled = sm;
  }

  drawSchools(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, layer: number, deep: boolean) {
    const t = this.time;
    ctx.fillStyle = deep ? "rgba(68, 212, 248, 0.36)" : layer < 0.45 ? "rgba(24, 96, 156, 0.44)" : "rgba(32, 118, 182, 0.5)";
    for (const s of this.schools) {
      if (s.p !== layer || s.deep !== deep) continue;
      const period = 3000;
      const bx = ((((s.x + s.dir * s.speed * t - camLeft * s.p) % period) + period) % period) - 300;
      const by = s.y - camTop * (deep ? 0.95 : s.p * 0.85) + Math.sin(t * 0.5 + s.seed) * 10;
      if (bx < -120 || bx > vw + 120 || by < -60 || by > vh + 60) continue;
      const big = s.p > 0.45 ? 1.3 : 1;
      ctx.beginPath();
      for (let i = 0; i < s.n; i++) {
        const ox = Math.sin(s.seed + i * 12.9) * 42 + Math.sin(t * 1.3 + i) * 3;
        const oy = Math.cos(s.seed + i * 7.3) * 16 + Math.sin(t * 2 + i * 0.7) * 2;
        const x = bx + ox,
          y = by + oy;
        ctx.moveTo(x + 2.8 * big, y);
        ctx.ellipse(x, y, 2.8 * big, 1.4 * big, 0, 0, Math.PI * 2);
        const tx = x - s.dir * 3.2 * big;
        ctx.moveTo(x - s.dir * 1.8 * big, y);
        ctx.lineTo(tx - s.dir * 1.8 * big, y - 1.8 * big);
        ctx.lineTo(tx - s.dir * 1.8 * big, y + 1.8 * big);
        ctx.closePath();
      }
      ctx.fill();
    }
  }

  private drawCrabs(ctx: Ctx, floorOnly: boolean, cl: number, ct: number, vw: number, vh: number, t: number) {
    const cr = this.bio.crab;
    for (const c of this.crabs) {
      if ((c.oy === FLOOR_TOP) !== floorOnly) continue;
      const a = t * c.sp + c.ph,
        lx = c.x0 + Math.sin(a) * c.range,
        ty = c.top[Math.round(lx)];
      if (ty === undefined || ty < 0) continue;
      const sx = c.ox + lx - cl,
        sy = c.oy + ty - ct;
      if (sx < -20 || sx > vw + 20 || sy < -20 || sy > vh + 20) continue;
      const s = cr[c.v],
        v = Math.cos(a);
      this.spr(ctx, s.f[Math.abs(v) > 0.2 ? Math.floor(t * s.fps + c.ph) % NF : 0], sx - 9, sy - s.h + 1, v < 0);
    }
  }

  drawRockFormations(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    const cl = this.sn(camLeft),
      ct = this.sn(camTop);
    // rooted stems first (back plane) ...
    for (const f of this.formations) {
      const sx = f.colX - cl,
        sy = f.colY - ct;
      if (sx + f.col.width < 0 || sx > vw || sy + f.col.height < 0 || sy > vh) continue;
      this.spr(ctx, f.col, sx, sy);
    }
    // ... then the collidable crowns with their living reef
    const vis: Formation[] = [];
    for (const f of this.formations) {
      const sx = f.x - cl,
        sy = f.y - ct;
      if (sx + f.w < -70 || sx > vw + 70 || sy + f.h < -70 || sy - 130 > vh) continue;
      vis.push(f);
      this.spr(ctx, f.cv, sx, sy);
      for (const b of f.insts) this.drawInst(ctx, b, b.x - cl, b.y - ct, t);
    }
    this.drawCrabs(ctx, false, cl, ct, vw, vh, t);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const f of vis) for (const b of f.insts) this.glowInst(ctx, b, b.x - cl, b.y - ct, t);
    ctx.restore();
    ctx.imageSmoothingEnabled = sm;
  }

  drawFloor(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const cl = this.sn(camLeft),
      ct = this.sn(camTop);
    if (FLOOR_TOP - ct > vh) return;
    const sx = Math.max(0, cl),
      sw = Math.min(WORLD_W - sx, vw + 2);
    const sy = Math.max(0, ct - FLOOR_TOP),
      dy = FLOOR_TOP + sy - ct,
      sh = Math.min(this.floor.height - sy, vh + 1 - dy);
    if (sw <= 0 || sh <= 0) return;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    this.blit(ctx, this.floor, sx, sy, sw, sh, sx - cl, dy);
    ctx.imageSmoothingEnabled = sm;
  }

  drawBackDecor(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    const cl = this.sn(camLeft),
      ct = this.sn(camTop);
    if (FLOOR_TOP - 140 - ct > vh) return;
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    for (const b of this.floorInsts) {
      const sx = b.x - cl;
      if (sx < -60 || sx > vw + 60) continue;
      this.drawInst(ctx, b, sx, b.y - ct, t);
    }
    this.drawCrabs(ctx, true, cl, ct, vw, vh, t);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const b of this.floorInsts) {
      const sx = b.x - cl;
      if (sx < -80 || sx > vw + 80) continue;
      this.glowInst(ctx, b, sx, b.y - ct, t);
    }
    const cx = this.chestPos.x - cl,
      cy = this.chestPos.y - ct;
    if (cx > -70 && cx < vw + 70) {
      ctx.globalAlpha = 0.5 + Math.sin(t * 3) * 0.12;
      ctx.drawImage(glowOrb("rgba(255, 226, 110, 0.6)", false), cx - 46, cy - 46, 92, 92);
    }
    ctx.restore();
    ctx.imageSmoothingEnabled = sm;
  }

  // ==========================================================================
  // FOREGROUND (1.22x Parallax): Karang oranye dan batu besar di depan!
  // Massive dark rock boulders with saturated glowing orange staghorns & golden cups
  // framing the bottom and bottom corners, with streams of rising illuminated bubbles!
  // ==========================================================================
  drawForegroundParallax(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;

    // 1. Foreground Diorama Outcrops (Massive Dark Rocks + High-Contrast Orange Corals)
    if (this.fgDioramas.length > 0) {
      const period = 340;
      const off = this.sn(camLeft * 1.22);
      const baseY = vh - 48; // crowns the lower 48px of the viewport framing the diorama

      const deepAmt = clamp01((camTop - 620) / 400);
      if (deepAmt > 0) {
        ctx.save();
        ctx.globalAlpha = 1 - deepAmt * 0.45;
      }

      for (let i = 0; i < 5; i++) {
        const sx = ((((i * period - off) % (period * 3)) + (period * 3)) % (period * 3)) - 120;
        if (sx < -340 || sx > vw + 80) continue;
        const cv = this.fgDioramas[i % this.fgDioramas.length];
        this.spr(ctx, cv, sx, baseY);
      }

      if (deepAmt > 0) {
        ctx.restore();
      }

      // Streams of bright illuminated bubbles rising from the foreground crevices
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const bubOrb = glowOrb("rgba(215, 248, 255, 0.75)", true);
      for (let b = 0; b < 10; b++) {
        const bx = ((((b * 137 - off * 1.05) % (period * 2)) + (period * 2)) % (period * 2));
        if (bx < -20 || bx > vw + 20) continue;
        const prog = ((t * 1.15 + b * 0.37) % 1);
        const by = vh - 16 - prog * 110;
        const rad = 2 + (b % 3) * 1.3 + prog * 1.3;
        ctx.globalAlpha = Math.sin(prog * Math.PI) * 0.85;
        ctx.drawImage(bubOrb, bx - rad, by - rad, rad * 2, rad * 2);
      }
      ctx.restore();
    }

    // 2. Giant deep kelp silhouettes when down near the floor
    const baseY = this.sn(WORLD_H + 34 - camTop * 1.1);
    if (baseY - 215 <= vh) {
      const span = WORLD_W * 1.24,
        off = this.sn(camLeft * 1.24);
      for (const b of this.fgInsts) {
        const sx = ((((b.x - off) % span) + span) % span) - 60;
        if (sx > vw + 60) continue;
        this.drawInst(ctx, b, sx, baseY + b.y, t);
      }
    }

    ctx.imageSmoothingEnabled = sm;
  }

  // ==========================================================================
  // DEPTH-LEVEL HUD: gauge on the left + title card whenever a new zone is entered
  // ==========================================================================
  drawHud(ctx: Ctx, vw: number, vh: number, py: number, t: number) {
    const z = zoneAt(py);
    if (z !== this.hudZone) {
      this.hudZone = z;
      this.hudT = t;
    }
    const Z = ZONES[z];
    const gh = Math.min(92, vh * 0.34),
      gx = 6,
      gy = vh * 0.54 - gh / 2;
    ctx.fillStyle = "rgba(3, 8, 28, 0.62)";
    ctx.fillRect(gx - 1.5, gy - 1.5, 6, gh + 3);
    for (let i = 0; i < 4; i++) {
      const a = gy + (ZONES[i].y / WORLD_H) * gh,
        b = gy + ((i < 3 ? ZONES[i + 1].y : WORLD_H) / WORLD_H) * gh;
      ctx.globalAlpha = i === z ? 1 : 0.38;
      ctx.fillStyle = ZONES[i].col;
      ctx.fillRect(gx, a, 3, b - a - 0.8);
    }
    ctx.globalAlpha = 1;
    const my = gy + clamp01(py / WORLD_H) * gh;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(gx - 1.5, my - 0.8, 6, 1.6);
    const sm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = true;
    const D = this.hudLabel(String(depthMeters(py)).replace(/\B(?=(\d{3})+(?!\d))/g, ".") + " m", 4.5, Z.col);
    ctx.drawImage(D.cv, gx + 6, my - D.h / 2, D.w, D.h);
    const k = t - this.hudT;
    if (k < 3.8) {
      const cy = vh * 0.79 + (1 - Math.min(1, k / 0.35)) * 6;
      ctx.globalAlpha = Math.min(1, k / 0.35) * Math.min(1, (3.8 - k) / 0.9);
      const N = this.hudLabel(Z.name, 9, Z.col);
      ctx.drawImage(N.cv, vw / 2 - N.w / 2, cy - N.h / 2, N.w, N.h);
      ctx.fillStyle = Z.col;
      for (const sd of [-1, 1]) {
        ctx.fillRect(vw / 2 + sd * (N.w / 2 + 3) - (sd < 0 ? 14 : 0), cy - 0.6, 14, 1.2);
        ctx.fillRect(vw / 2 + sd * (N.w / 2 + 20) - 1, cy - 1.6, 2, 3.2);
      }
      const S = this.hudLabel(`${Z.sub} · ${Z.m0}-${Z.m1} m`, 4.5, "#eaf6ff");
      ctx.drawImage(S.cv, vw / 2 - S.w / 2, cy + 10 - S.h / 2, S.w, S.h);
      ctx.globalAlpha = 1;
    }
    ctx.imageSmoothingEnabled = sm;
  }

  /** HUD text drawn once into a small canvas (with a cheap offset-fill outline) and reused as a sprite */
  private hudLabel(text: string, size: number, col: string): { cv: HTMLCanvasElement; w: number; h: number } {
    const q = Math.min(5, Math.max(1, Math.ceil(this.pxs)));
    const key = text + "|" + size + "|" + col + "|" + q;
    let e = this.hudTxt.get(key);
    if (!e) {
      const font = `${size}px 'Press Start 2P', monospace`;
      const cv = document.createElement("canvas");
      const c = cv.getContext("2d")!;
      c.font = font;
      const o = size * 0.13,
        pad = o + 1;
      const w = c.measureText(text).width + pad * 2,
        h = size * 1.4 + pad * 2;
      cv.width = Math.max(2, Math.ceil(w * q));
      cv.height = Math.max(2, Math.ceil(h * q));
      c.setTransform(q, 0, 0, q, 0, 0);
      c.font = font;
      c.textAlign = "left";
      c.textBaseline = "middle";
      c.fillStyle = "rgba(4, 10, 34, 0.9)";
      for (const [dx, dy] of [[-o, -o], [o, -o], [-o, o], [o, o], [0, o * 1.7]]) c.fillText(text, pad + dx, h / 2 + dy);
      c.fillStyle = col;
      c.fillText(text, pad, h / 2);
      e = { cv, w: cv.width / q, h: cv.height / q };
      if (this.hudTxt.size > 90) this.hudTxt.clear();
      this.hudTxt.set(key, e);
    }
    return e;
  }
}
