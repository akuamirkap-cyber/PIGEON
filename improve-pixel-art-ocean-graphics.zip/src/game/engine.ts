import { SPECIES, SKINS, FRY, skinToSpecies, BOT_NAMES } from "./species";
import type { Species, Skin } from "./species";
import { fishSprite, fishMouthOffset, coinSprite, beginSpriteFrame, spriteBudgetLeft } from "./sprites";
import type { EyeExpr, JawState } from "./sprites";
import { Ocean, WORLD_W, WORLD_H, DEEP_START, floorY, glowOrb, zoneAt, depthMeters } from "./ocean";

let bubbleStamp: HTMLCanvasElement | null = null;
function getBubbleStamp(): HTMLCanvasElement {
  if (bubbleStamp) return bubbleStamp;
  const S = 36;
  const cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  const r = S * 0.44;
  const bg = c.createRadialGradient(S * 0.36, S * 0.36, r * 0.08, S * 0.5, S * 0.5, r);
  bg.addColorStop(0, "rgba(255, 255, 255, 0.85)");
  bg.addColorStop(0.35, "rgba(195, 245, 255, 0.2)");
  bg.addColorStop(0.82, "rgba(165, 238, 255, 0.35)");
  bg.addColorStop(1, "rgba(165, 238, 255, 0.65)");
  c.fillStyle = bg;
  c.beginPath();
  c.arc(S * 0.5, S * 0.5, r, 0, Math.PI * 2);
  c.fill();
  bubbleStamp = cv;
  return cv;
}
import { sfx } from "./audio";

export const fishLen = (r: number) => r * 2.55 + 3;

export interface Upgrades {
  suck: number;
  speed: number;
  size: number;
}
export interface StartOpts {
  name: string;
  skin: Skin;
  upgrades: Upgrades;
}
export interface LeaderRow {
  name: string;
  score: number;
  me: boolean;
  color: string;
}
export interface HudState {
  coins: number;
  score: number;
  mass: number;
  energy: number;
  combo: number;
  comboT: number;
  frenzyStage: number;
  level: number;
  growthPct: number;
  stageNum: number;
  zoneName: string;
  rank: number;
  total: number;
  leaderboard: LeaderRow[];
  alive: boolean;
  exhausted: boolean;
  boost: number;
  boostExhausted: boolean;
  sucking: boolean;
  boosting: boolean;
}
export interface DeathInfo {
  score: number;
  coins: number;
  killer: string;
  maxMass: number;
  eaten: number;
  time: number;
}
export type GameEvent =
  | { type: "combo"; n: number }
  | { type: "frenzy"; n: number }
  | { type: "levelup"; text: string }
  | { type: "feed"; text: string }
  | { type: "bonus"; title: string; text: string }
  | { type: "coinbump" };

type Kind = "npc" | "bot" | "player";
let NEXT_ID = 1;

class Fish {
  id = NEXT_ID++;
  kind: Kind;
  sp: Species;
  key: string;
  skinRef?: Skin;
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  mass: number;
  r: number;
  face = 1;
  tilt = 0;
  sq = 0;
  sqv = 0;
  tailPh = Math.random() * 6;
  jaw = 0;
  mouthOpenT = 0;
  chompT = 0;
  wantOpen = false;
  sucking = false;
  suckVis = 0; // smooth 0..1 visual fade for suction mist
  turnFlip = 1; // smooth -1..+1 horizontal turn flip (zero instant mirror snap!)
  exhausted = false;
  energy = 1;
  boosting = false;
  boost = 1;
  boostExhausted = false;
  boostTrail = 0;
  name = "";
  color = "#fff";
  eatenBy: Fish | null = null;
  eatT = 0;
  eatFromX = 0;
  eatFromY = 0;
  dead = false;
  combo = 0;
  comboT = 0;
  score = 0;
  invuln = 0;
  sucked = 0;
  speedMul = 1;
  suckMul = 1;
  maxR = 999;
  fry = false; // tiny schooling snack fish
  school: School | null = null;
  slotA = 0; // slot (angle / radius) inside the school formation
  slotR = 0;
  gulpT = 0; // 1 -> 0 while a swallowed bite travels down the body as a bulge
  gulpK = 0;
  munch = false; // chewing a big mouthful
  slurpCd = 0; // cooldown between two fry swallows (gives the slurp its rhythm)
  ai = { tx: 0, ty: 0, timer: 0, target: null as Fish | null, chase: 0, rest: 0, flee: false };

  constructor(kind: Kind, sp: Species, key: string, x: number, y: number, mass: number) {
    this.kind = kind;
    this.sp = sp;
    this.key = key;
    this.x = x;
    this.y = y;
    this.mass = mass;
    this.r = Math.sqrt(mass);
    this.ai.tx = x;
    this.ai.ty = y;
  }

  mouthOff(): [number, number] {
    return fishMouthOffset(this.sp, fishLen(this.r));
  }
  mouthX() {
    const [ox, oy] = this.mouthOff();
    return this.x + this.face * (ox * Math.cos(this.tilt) - oy * Math.sin(this.tilt));
  }
  mouthY() {
    const [ox, oy] = this.mouthOff();
    return this.y + ox * Math.sin(this.tilt) + oy * Math.cos(this.tilt);
  }
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  type: "bubble" | "bit" | "spark" | "suck" | "ring" | "star" | "streak" | "chomp" | "glint";
  color: string;
  size: number;
  dir?: number;
  target?: Fish;
}
interface Txt {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  max: number;
  size: number;
}
interface FlyCoin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number; // < 0 while waiting for its staggered pop
  value: number;
  sx: number; // where the swoop to the HUD starts
  sy: number;
  bend: number; // sideways bulge of the swoop
  trail: number;
}
interface School {
  x: number;
  y: number;
  vx: number;
  vy: number;
  tx: number;
  ty: number;
  timer: number;
  members: Fish[];
  sp: Species;
  pref: "upper" | "any" | "deep";
  panic: number; // 0 calm .. 1 bait-ball
  swirl: number;
  dir: number;
  size0: number;
  byPlayer: number;
  speed: number;
}
interface WorldCoin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number;
  value: number;
  settled: boolean;
}

export const EAT_RATIO = 0.88;
const SCHOOL_COUNT = 13;
const LOAD_BUDGET = 9; // ms of world generation per slice; slices run back-to-back between frames, so
// input and painting are never blocked for longer than about one frame
const SPRITE_BUDGET = 1;
const MAX_PIXELS = 1.6e6; // the canvas never renders more pixels than this (more only costs fill-rate) // new fish sprites rasterised per frame at most
const Q_SCALE = [1, 0.8, 0.64, 0.5]; // adaptive render resolution steps
const COIN_POP = 0.42; // seconds a coin spends popping out of the mouth
const COIN_FLY = 0.5; // seconds of the swoop to the coin counter
const ZONE_LABELS = ["Zona Cahaya", "Zona Senja", "Zona Malam", "Palung Abisal"];
const GAIN = 0.115;
const NPC_TARGET = 350;
const NPC_SPEED = 1.0;
const BOT_COUNT = 49; // 49 rival players + you = 50 players in the ocean
const WORDS = ["NYAM!", "HAP!", "GULP!", "CHOMP!", "YUMMY!", "MANTAP!", "SLURP!"];

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  ocean: Ocean;
  fish: Fish[] = [];
  player: Fish | null = null;
  particles: Particle[] = [];
  texts: Txt[] = [];
  flyCoins: FlyCoin[] = [];
  worldCoins: WorldCoin[] = [];
  motes: { x: number; y: number; s: number; col: string }[] = [];
  respawnQueue: { t: number; name: string; skin: Skin }[] = [];
  schools: School[] = [];
  schoolTimers: number[] = [];
  schoolSeq = 0;
  streamPts = 0; // running totals of the current slurp chain (shown as one summary pop)
  streamCoins = 0;
  streamN = 0;
  streamT = 0;
  chainPop = 0;
  coinChain = 0;
  lastCoinT = 0;
  cam = { x: WORLD_W / 2, y: 520 };
  camLeft = 0;
  camTop = 0;
  zoom = 2.5;
  dpr = 1;
  pixelMode = false;
  vw = 320;
  vh = 180;
  mouse = { x: 0, y: 0, sx: 0, sy: 0, active: false };
  camVel = { x: 0, y: 0 };
  suckInput = false;
  boostInput = false;
  t = 0;
  shake = 0;
  freeze = 0;
  sessionCoins = 0;
  arcadeScore = 0;
  eatenCount = 0;
  maxMass = 0;
  startMass = 58;
  startTime = 0;
  level = 0;
  deathTimer = -1;
  killerName = "";
  coinTimer = 0;
  hudTimer = 0;
  last = 0;
  raf = 0;
  minimap: HTMLCanvasElement | null = null;
  miniTimer = 0;
  spectate: Fish | null = null;
  leaderId = -1;
  onHud?: (h: HudState) => void;
  onDeath?: (d: DeathInfo) => void;
  onEvent?: (e: GameEvent) => void;
  /** loading progress 0..1; `ready` flips to true when the ocean is generated and populated */
  onLoad?: (pct: number, ready: boolean) => void;
  ready = false;
  loadPct = 0;
  private loadEmit = -1;
  private warm: (() => void)[] | null = null;
  private mc: MessageChannel | null = null;
  private disposed = false;
  private vis: Fish[] = []; // fish near the view this frame
  private labels = new Map<string, { cv: HTMLCanvasElement; w: number; h: number }>();
  private bg: (() => void)[] = []; // sprites still to be rasterised on idle frames
  private dtS = 1 / 60;
  private look = { x: 0, y: 0 }; // smoothed camera look-ahead
  private warmI = 0;
  // adaptive resolution: only engages on devices that cannot hold ~40 fps, and is kept only if it helps
  quality = 0;
  private qAcc = 0;
  private qN = 0;
  private qSlow = 0;
  private qBase = 0;
  private qTrying = false;
  private qLocked = false;
  private qHold = 3;
  coinHudPos = { x: 900, y: 26 };

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.ocean = new Ocean();
    // make sure the pixel font used by the depth-level HUD is loaded even if no DOM element uses it yet
    try {
      const fonts = (document as unknown as { fonts?: { load: (f: string) => unknown; addEventListener?: (e: string, cb: () => void) => void } }).fonts;
      fonts?.load("8px 'Press Start 2P'");
      // cached text sprites must be redrawn once the web fonts have arrived
      fonts?.addEventListener?.("loadingdone", () => {
        this.labels.clear();
        this.ocean.clearText();
      });
    } catch {
      /* font loading is best-effort */
    }
    const moteCols = ["#cffafe", "#a5f3fc", "#f5d0fe", "#fde68a"];
    for (let i = 0; i < 165; i++) {
      this.motes.push({
        x: Math.random() * 2000,
        y: Math.random() * 1400,
        s: Math.random(),
        col: moteCols[i % moteCols.length],
      });
    }
    // NOTE: the ocean is NOT generated here. loadStep() builds it a few milliseconds per frame (with a
    // progress bar) and then populates it, so opening the page never locks up the browser.
    this.resize(true);
    this.last = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
    this.pumpLoad();
  }

  /**
   * Schedules the next loading slice as its own task (MessageChannel = no 4 ms timer clamp). Between two
   * slices the browser is free to handle input and paint, so the menu stays fully responsive.
   */
  private pumpLoad() {
    if (this.ready || this.disposed) return;
    if (typeof MessageChannel !== "undefined") {
      if (!this.mc) {
        this.mc = new MessageChannel();
        this.mc.port1.onmessage = () => {
          if (this.ready || this.disposed) return;
          this.loadStep();
          this.pumpLoad();
        };
      }
      this.mc.port2.postMessage(0);
    } else {
      setTimeout(() => {
        if (this.ready || this.disposed) return;
        this.loadStep();
        this.pumpLoad();
      }, 0);
    }
  }

  /** One slice of loading: world generation, then a few essential sprites, then the fish population. */
  loadStep(budgetMs = LOAD_BUDGET) {
    if (this.ready) return;
    const t0 = performance.now();
    if (this.ocean.step(budgetMs)) {
      if (!this.warm) this.warm = this.warmList();
      beginSpriteFrame(1e9);
      while (this.warmI < this.warm.length && performance.now() - t0 < budgetMs) this.warm[this.warmI++]();
      if (this.warmI >= this.warm.length) this.finishInit();
    }
    const pct = this.ready ? 1 : this.ocean.progress * 0.95 + (this.warm ? (this.warmI / Math.max(1, this.warm.length)) * 0.05 : 0);
    this.loadPct = pct;
    const ip = Math.floor(pct * 100);
    if (ip !== this.loadEmit || this.ready) {
      this.loadEmit = ip;
      this.onLoad?.(pct, this.ready);
    }
  }

  /** one sprite per fish type & size tier, so the very first frame never has to draw them all at once */
  private warmList(): (() => void)[] {
    const jobs: (() => void)[] = [];
    const add = (sp: Species, key: string, r: number) => jobs.push(() => void fishSprite(sp, fishLen(r), 0, 0, key, this.pixelMode, "normal", true));
    for (const sp of SPECIES) {
      add(sp, sp.id, sp.minR);
      add(sp, sp.id, sp.maxR);
    }
    for (const sp of FRY) add(sp, sp.id, sp.minR);
    for (const sk of SKINS) {
      const sp = skinToSpecies(sk);
      add(sp, "bot-" + sk.id, 8);
      add(sp, "bot-" + sk.id, 14);
    }
    return jobs;
  }

  private finishInit() {
    while (this.fish.length < NPC_TARGET) this.spawnNPC(true);
    for (let i = 0; i < SCHOOL_COUNT; i++) this.spawnSchool(true);
    const names = [...BOT_NAMES].sort(() => Math.random() - 0.5);
    for (let i = 0; i < BOT_COUNT; i++) {
      const botSkin = SKINS[i % SKINS.length];
      // skewed toward small fry so a 50-player ocean is still fair to a fresh spawn
      this.spawnBot(names[i % names.length], botSkin, 56 + Math.pow(Math.random(), 2.4) * 640);
    }
    // background queue: every swim frame of every fish type, rasterised one per idle frame so that
    // meeting a new kind of fish during play never costs a hitch
    const q = (sp: Species, key: string, r: number) => {
      for (let tf = 0; tf < 8; tf++) this.bg.push(() => void fishSprite(sp, fishLen(r), 0, (tf + 0.5) * (Math.PI / 4), key, this.pixelMode, "normal", true));
    };
    for (const sk of SKINS) {
      const sp = skinToSpecies(sk);
      q(sp, "bot-" + sk.id, 14);
      q(sp, "bot-" + sk.id, 8);
    }
    for (const sp of SPECIES) {
      q(sp, sp.id, sp.maxR);
      q(sp, sp.id, sp.minR);
    }
    for (const sp of FRY) q(sp, sp.id, sp.minR);
    this.resize(true);
    this.ready = true;
    this.last = performance.now();
    this.mc?.port1.close();
    this.mc = null;
  }

  /** Simple loading screen drawn straight on the game canvas while the ocean is being generated. */
  drawLoading() {
    const ctx = this.ctx,
      W = this.canvas.width,
      H = this.canvas.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#49d6f5");
    g.addColorStop(0.45, "#1376cc");
    g.addColorStop(1, "#0b2a7a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    const p = this.loadPct;
    const u = Math.max(1, Math.round(H / 240));
    const bw = Math.min(W * 0.6, 150 * u * 2),
      bh = 6 * u,
      bx = Math.round((W - bw) / 2),
      by = Math.round(H * 0.93);
    ctx.fillStyle = "#06143c";
    ctx.fillRect(bx - 2 * u, by - 2 * u, bw + 4 * u, bh + 4 * u);
    ctx.fillStyle = "#123a86";
    ctx.fillRect(bx, by, bw, bh);
    ctx.fillStyle = "#ffe14a";
    ctx.fillRect(bx, by, Math.round(bw * p), bh);
    ctx.fillStyle = "#fff8c0";
    ctx.fillRect(bx, by, Math.round(bw * p), u);
    const label = p < 0.12 ? "Menumbuhkan karang" : p < 0.43 ? "Memahat tebing laut" : p < 0.8 ? "Menanam terumbu" : p < 0.95 ? "Menata dasar laut" : "Melepas ikan";
    ctx.font = `700 ${7 * u}px 'Fredoka', system-ui, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "rgba(4, 12, 40, 0.75)";
    ctx.fillText(`${label}… ${Math.floor(p * 100)}%`, W / 2 + u, by - 4 * u + u);
    ctx.fillStyle = "#eaf8ff";
    ctx.fillText(`${label}… ${Math.floor(p * 100)}%`, W / 2, by - 4 * u);
  }

  /**
   * Adaptive resolution. If the device averages under ~40 fps for a few seconds, render fewer pixels.
   * The step is kept only when it measurably helps (otherwise it is reverted and never tried again),
   * so capped / CPU-bound devices do not lose sharpness for nothing.
   */
  trackPerf(rawMs: number) {
    if (this.pixelMode || rawMs <= 0 || rawMs > 250) return; // pixel mode is already tiny; ignore tab switches
    if (this.qHold > 0) {
      this.qHold -= rawMs / 1000; // settle time after loading / after a change
      return;
    }
    this.qAcc += rawMs;
    this.qN++;
    if (this.qAcc < 1500) return;
    const avg = this.qAcc / this.qN;
    this.qAcc = 0;
    this.qN = 0;
    if (this.qTrying) {
      this.qTrying = false;
      if (avg > this.qBase * 0.87) {
        this.quality--; // it did not help: restore full sharpness and stop experimenting
        this.qLocked = true;
        this.qHold = 0.5;
      }
      return;
    }
    if (this.qLocked || this.quality >= Q_SCALE.length - 1) return;
    this.qSlow = avg > 25 ? this.qSlow + 1 : 0;
    if (this.qSlow >= 2) {
      this.qSlow = 0;
      this.qBase = avg;
      this.quality++;
      this.qTrying = true;
      this.qHold = 0.5;
    }
  }

  setPixelMode(pm: boolean) {
    this.pixelMode = pm;
    this.resize(true);
  }

  destroy() {
    this.disposed = true;
    this.mc?.port1.close();
    this.mc = null;
    cancelAnimationFrame(this.raf);
    sfx.setSuck(false);
  }

  isInsideRock(x: number, y: number, pad: number): boolean {
    for (const c of this.ocean.colliders) {
      const dx = x - c.x,
        dy = y - c.y;
      if (dx * dx + dy * dy < (c.r + pad) * (c.r + pad)) return true;
    }
    return false;
  }

  pickSpecies(): Species {
    const p = this.player;
    if (p && !p.dead && Math.random() < 0.52) {
      const r = p.r;
      const ok = SPECIES.filter((s) => s.maxR > r * 0.35 && s.minR < r * 1.1);
      if (ok.length) return ok[Math.floor(Math.random() * ok.length)];
    }
    const total = SPECIES.reduce((a, s) => a + s.weight, 0);
    let k = Math.random() * total;
    for (const s of SPECIES) {
      k -= s.weight;
      if (k <= 0) return s;
    }
    return SPECIES[0];
  }

  randomSpawnPos(margin: number, offscreen: boolean, pref: "upper" | "any" | "deep" = "any") {
    const near = offscreen && Math.random() < 0.55;
    for (let i = 0; i < 28; i++) {
      const x = near
        ? clamp(this.cam.x + (Math.random() < 0.5 ? -1 : 1) * (this.vw / 2 + 40 + Math.random() * 380), 50, WORLD_W - 50)
        : 50 + Math.random() * (WORLD_W - 100);
      const fy = floorY(x);
      let yMin = 50 + margin;
      let yMax = fy - 45 - margin;
      if (pref === "upper") yMax = Math.min(yMax, DEEP_START + 80);
      else if (pref === "deep") yMin = Math.max(yMin, DEEP_START + 60);
      if (yMax <= yMin) yMax = yMin + 40;
      const y = yMin + Math.random() * (yMax - yMin);

      if (this.isInsideRock(x, y, margin + 12)) continue;
      if (!offscreen) return { x, y };
      if (Math.abs(x - this.cam.x) > this.vw / 2 + 40 || Math.abs(y - this.cam.y) > this.vh / 2 + 40) return { x, y };
    }
    return { x: 180 + Math.random() * (WORLD_W - 360), y: 240 };
  }

  spawnNPC(initial = false) {
    const sp = this.pickSpecies();
    const r = sp.minR + Math.random() * (sp.maxR - sp.minR);
    const pos = this.randomSpawnPos(r, !initial, sp.deepPref || "any");
    const f = new Fish("npc", sp, sp.id, pos.x, pos.y, r * r);
    f.face = Math.random() < 0.5 ? 1 : -1;
    f.maxR = sp.maxR * 1.25;
    this.fish.push(f);

    const school =
      sp.id === "minnow"
        ? 4 + Math.floor(Math.random() * 6)
        : sp.id === "boris_npc" || sp.id === "andy_npc"
          ? Math.random() < 0.5
            ? 2 + Math.floor(Math.random() * 3)
            : 0
          : 0;
    if (school > 0) {
      for (let i = 0; i < school; i++) {
        const gr = r * (0.88 + Math.random() * 0.24);
        const gx = pos.x + (Math.random() - 0.5) * 42;
        const gy = pos.y + (Math.random() - 0.5) * 28;
        if (this.isInsideRock(gx, gy, gr + 6)) continue;
        const g = new Fish("npc", sp, sp.id, gx, gy, gr * gr);
        g.face = f.face;
        this.fish.push(g);
      }
    }
  }

  // ==========================================================================
  // SNACK SCHOOLS: tight shoals of tiny fish that swirl, flee as a bait-ball and can be vacuumed up
  // ==========================================================================
  spawnSchool(initial = false) {
    const sp = FRY[this.schoolSeq++ % FRY.length];
    const pref = sp.deepPref || "any";
    const pos = this.randomSpawnPos(46, !initial, pref);
    const n = 18 + Math.floor(Math.random() * 13);
    const s: School = {
      x: pos.x,
      y: pos.y,
      vx: (Math.random() < 0.5 ? -1 : 1) * 30,
      vy: 0,
      tx: pos.x,
      ty: pos.y,
      timer: 0,
      members: [],
      sp,
      pref,
      panic: 0,
      swirl: Math.random() * 6.28,
      dir: Math.random() < 0.5 ? 1 : -1,
      size0: n,
      byPlayer: 0,
      speed: sp.speed * 0.8,
    };
    for (let i = 0; i < n; i++) {
      const r = sp.minR + Math.random() * (sp.maxR - sp.minR);
      const a = i * 2.39996 + Math.random() * 0.4; // golden-angle disc
      const rad = 4 + Math.sqrt((i + 0.5) / n) * 27;
      const f = new Fish("npc", sp, sp.id, pos.x + Math.cos(a) * rad, pos.y + Math.sin(a) * rad * 0.6, r * r);
      f.fry = true;
      f.school = s;
      f.slotA = a;
      f.slotR = rad;
      f.face = s.vx > 0 ? 1 : -1;
      f.maxR = sp.maxR;
      s.members.push(f);
      this.fish.push(f);
    }
    this.schools.push(s);
  }

  updateSchools(dt: number, threats: Fish[]) {
    for (const s of this.schools) {
      s.members = s.members.filter((m) => !m.dead);
      if (!s.members.length) continue;
      // anything big enough to eat them makes the whole school bolt and ball up
      let fx = 0,
        fy = 0,
        danger = 0;
      for (const o of threats) {
        if (o.fry || o.r < 3.6) continue;
        const dx = s.x - o.x,
          dy = s.y - o.y;
        const R = 62 + o.r * 2.2;
        if (Math.abs(dx) > R || Math.abs(dy) > R) continue;
        const d = Math.hypot(dx, dy);
        if (d < R) {
          const k = 1 - d / R;
          fx += (dx / (d || 1)) * k;
          fy += (dy / (d || 1)) * k;
          if (k > danger) danger = k;
        }
      }
      const scared = danger > 0.05;
      s.panic += ((scared ? 1 : 0) - s.panic) * Math.min(1, dt * (scared ? 5 : 1.1));
      s.timer -= dt;
      if (scared) {
        const d = Math.hypot(fx, fy) || 1;
        s.tx = clamp(s.x + (fx / d) * 170, 60, WORLD_W - 60);
        s.ty = s.y + (fy / d) * 120;
        s.timer = 0.8;
      } else if (s.timer <= 0 || Math.hypot(s.tx - s.x, s.ty - s.y) < 26) {
        s.tx = clamp(s.x + (Math.random() - 0.5) * 560, 80, WORLD_W - 80);
        const yMin = s.pref === "deep" ? DEEP_START + 80 : 70;
        const yMax = s.pref === "upper" ? DEEP_START + 40 : floorY(s.tx) - 80;
        s.ty = clamp(s.y + (Math.random() - 0.5) * 240, yMin, Math.max(yMin + 10, Math.min(yMax, floorY(s.tx) - 80)));
        s.timer = 3.5 + Math.random() * 4;
      }
      const dx = s.tx - s.x,
        dy = s.ty - s.y,
        d = Math.hypot(dx, dy) || 1;
      const sp = s.speed * (1 + s.panic * 0.55);
      const k = Math.min(1, dt * 1.7);
      s.vx += ((dx / d) * sp - s.vx) * k;
      s.vy += ((dy / d) * sp * 0.75 - s.vy) * k;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      for (const c of this.ocean.colliders) {
        const ex = s.x - c.x,
          ey = s.y - c.y,
          min = c.r + 36;
        if (Math.abs(ex) > min || Math.abs(ey) > min) continue;
        const dd = Math.hypot(ex, ey) || 0.01;
        if (dd < min) {
          s.x += (ex / dd) * (min - dd);
          s.y += (ey / dd) * (min - dd);
        }
      }
      s.x = clamp(s.x, 50, WORLD_W - 50);
      s.y = clamp(s.y, 44, floorY(s.x) - 56);
      s.swirl += dt * (0.45 + s.panic * 2.4) * s.dir;
    }
    // emptied (or nearly emptied & far away) schools are replaced somewhere off-screen
    for (let i = this.schools.length - 1; i >= 0; i--) {
      const s = this.schools[i];
      const far = Math.abs(s.x - this.cam.x) > this.vw * 0.9 || Math.abs(s.y - this.cam.y) > this.vh * 0.9;
      if (s.members.length === 0 || (s.members.length < 5 && far)) {
        for (const m of s.members) m.dead = true;
        this.schools.splice(i, 1);
        this.schoolTimers.push(3 + Math.random() * 5);
      }
    }
    for (let i = this.schoolTimers.length - 1; i >= 0; i--) {
      this.schoolTimers[i] -= dt;
      if (this.schoolTimers[i] <= 0) {
        this.schoolTimers.splice(i, 1);
        this.spawnSchool();
      }
    }
  }

  /** Each fry holds a slot on a slowly swirling ellipse (stretched along the heading) around the school centre. */
  fryAI(f: Fish, dt: number) {
    const s = f.school;
    if (!s || f.sucked > 0) return; // being vacuumed: pure physics
    const hs = Math.hypot(s.vx, s.vy) || 1,
      ux = s.vx / hs,
      uy = s.vy / hs;
    const ang = f.slotA + s.swirl,
      spread = 1 + s.panic * 0.3;
    const lx = Math.cos(ang) * f.slotR * 1.45 * spread,
      ly = Math.sin(ang) * f.slotR * 0.72 * spread;
    const tx = s.x + ux * lx - uy * ly + s.vx * 0.25,
      ty = s.y + uy * lx + ux * ly + s.vy * 0.25 + Math.sin(this.t * 2.6 + f.id) * 1.5;
    const ax = tx - f.x,
      ay = ty - f.y,
      d = Math.hypot(ax, ay) || 1;
    const ms = s.speed * (1.05 + s.panic * 0.6) * Math.min(1.35, 0.45 + d / 22);
    const near = clamp(1 - d / 14, 0, 1);
    let vx = (ax / d) * ms * (1 - near) + s.vx * near,
      vy = (ay / d) * ms * (1 - near) + s.vy * near;
    // cheap stochastic separation so the shoal never clumps into one blob
    for (let k = 0; k < 2; k++) {
      const o = s.members[(Math.random() * s.members.length) | 0];
      if (!o || o === f) continue;
      const ex = f.x - o.x,
        ey = f.y - o.y,
        dd = ex * ex + ey * ey;
      if (dd < 30 && dd > 0.01) {
        const q = Math.sqrt(dd);
        vx += (ex / q) * (5.5 - q) * 10;
        vy += (ey / q) * (5.5 - q) * 10;
      }
    }
    const k2 = Math.min(1, dt * 4);
    f.vx += (vx - f.vx) * k2;
    f.vy += (vy - f.vy) * k2;
  }

  /** Clean sweep: the player vacuumed (almost) a whole school -> coin shower + banner */
  schoolBonus(s: School, x: number, y: number) {
    const bonus = 5 + Math.round(s.size0 * 0.3);
    const n = Math.min(bonus, 14);
    for (let i = 0; i < n; i++) this.addFlyCoin(x, y, Math.floor(bonus / n) + (i < bonus % n ? 1 : 0), 0.15 + i * 0.05, 0);
    this.arcadeScore += s.size0 * 60;
    this.texts.push({ x, y: y - 30, text: "SAPU BERSIH!", color: "#7dffb0", life: 1.6, max: 1.6, size: 13 });
    this.texts.push({ x, y: y - 16, text: "+" + bonus + " koin", color: "#ffe14a", life: 1.6, max: 1.6, size: 9 });
    this.spawnSparks(x, y, "#7dffb0", 20);
    this.spawnSparks(x, y, "#ffe14a", 14);
    this.spawnRing(x, y, "#ffffff", 26);
    this.shake = Math.min(3.5, this.shake + 2);
    sfx.bonus();
    this.onEvent?.({ type: "bonus", title: "SAPU BERSIH!", text: `Segerombolan ${s.sp.name} habis disedot · +${bonus} koin` });
  }

  spawnBot(name: string, skin: Skin, mass: number) {
    const sp = skinToSpecies(skin);
    const pos = this.randomSpawnPos(24, true, "any");
    const f = new Fish("bot", sp, "bot-" + skin.id, pos.x, pos.y, mass);
    f.skinRef = skin;
    f.name = name;
    f.color = skin.pal.body;
    f.speedMul = 0.9;
    f.maxR = 62;
    f.invuln = 2;
    this.fish.push(f);
  }

  start(opts: StartOpts) {
    if (!this.ready) return; // still generating the ocean
    if (this.player) this.player.dead = true;
    const sp = skinToSpecies(opts.skin);
    const pos = this.randomSpawnPos(65, false, "upper");
    pos.y = clamp(pos.y, 180, 660);
    if (this.isInsideRock(pos.x, pos.y, 65)) {
      pos.x = 980;
      pos.y = 320;
    }
    const mass = 58 + opts.upgrades.size * 14;
    const p = new Fish("player", sp, "player-" + opts.skin.id, pos.x, pos.y, mass);
    p.skinRef = opts.skin;
    p.name = opts.name || "Kamu";
    p.color = "#ffffff";
    p.speedMul = 1 + opts.upgrades.speed * 0.07;
    p.suckMul = 1 + opts.upgrades.suck * 0.16;
    p.invuln = 3.5;
    p.maxR = 68;
    this.player = p;
    p.turnFlip = p.face;
    this.fish.push(p);
    this.resize(true);
    this.camVel.x = 0;
    this.camVel.y = 0;
    if (this.mouse.active) {
      this.mouse.sx = this.mouse.x;
      this.mouse.sy = this.mouse.y;
      const W = Math.max(1, window.innerWidth);
      const H = Math.max(1, window.innerHeight);
      const initOffX = clamp((this.mouse.sx / W - 0.5) * this.vw, -this.vw * 0.35, this.vw * 0.35);
      const initOffY = clamp((this.mouse.sy / H - 0.5) * this.vh, -this.vh * 0.35, this.vh * 0.35);
      const minCamX = this.vw >= WORLD_W ? WORLD_W / 2 : this.vw / 2;
      const maxCamX = this.vw >= WORLD_W ? WORLD_W / 2 : WORLD_W - this.vw / 2;
      this.cam.x = clamp(p.x - initOffX, minCamX, maxCamX);
      this.cam.y = clamp(p.y - initOffY, -34 + this.vh / 2, WORLD_H + 35 - this.vh / 2);
    } else {
      this.cam.x = p.x;
      this.cam.y = p.y;
    }
    this.look.x = this.look.y = 0;
    this.sessionCoins = 0;
    this.arcadeScore = 0;
    this.eatenCount = 0;
    this.startMass = mass;
    this.maxMass = mass;
    this.startTime = this.t;
    this.deathTimer = -1;
    this.level = this.calcLevel(p.r);
    this.flyCoins = [];
    this.streamPts = this.streamCoins = this.streamN = 0;
    this.coinChain = 0;
    for (const f of this.fish) {
      if (f !== p && f.r > p.r && Math.hypot(f.x - p.x, f.y - p.y) < 480) {
        const np = this.randomSpawnPos(f.r, true);
        f.x = np.x;
        f.y = np.y;
      }
    }
    this.spawnRing(p.x, p.y, "#a5f3fc", 16);
    sfx.levelUp();
  }

  calcLevel(r: number) {
    return SPECIES.filter((s) => s.minR < r * EAT_RATIO).length;
  }

  calcGrowthPct(r: number): number {
    let prevR = 6.5;
    for (let i = 0; i < SPECIES.length; i++) {
      const needR = SPECIES[i].minR / EAT_RATIO;
      if (r < needR) {
        const prevMass = prevR * prevR;
        const needMass = needR * needR;
        const curMass = r * r;
        return clamp((curMass - prevMass) / Math.max(1, needMass - prevMass), 0, 1);
      }
      prevR = needR;
    }
    return 1;
  }

  setSuck(on: boolean) {
    this.suckInput = on;
  }

  setBoost(on: boolean) {
    this.boostInput = on;
  }

  applyBoost(f: Fish, want: boolean, dt: number) {
    const wasBoost = f.boosting;
    if (want && !f.boostExhausted && f.boost > 0) {
      f.boosting = true;
      f.boost -= dt * 0.55;
      if (f.boost <= 0) {
        f.boost = 0;
        f.boostExhausted = true;
        f.boosting = false;
      }
    } else {
      f.boosting = false;
      f.boost = Math.min(1, f.boost + dt * 0.24);
      if (f.boostExhausted && f.boost > 0.35) f.boostExhausted = false;
    }
    if (f.boosting && !wasBoost) {
      f.sqv -= 6;
      const onScreen = Math.abs(f.x - this.cam.x) < this.vw / 2 + 20 && Math.abs(f.y - this.cam.y) < this.vh / 2 + 20;
      if (onScreen) {
        sfx.whoosh();
        const bx = f.x - f.face * f.r;
        for (let i = 0; i < 8; i++) {
          this.particles.push(this.bubble(bx + (Math.random() - 0.5) * f.r, f.y + (Math.random() - 0.5) * f.r, 1 + Math.random() * 2));
        }
        this.spawnRing(bx, f.y, "#bff8ff", f.r * 0.65);
      }
    }
  }

  loop(now: number) {
    const raw = now - this.last;
    let dt = raw / 1000;
    this.last = now;
    if (!this.ready) {
      // the world is generated by pumpLoad() between frames; here we only paint the progress
      this.drawLoading();
      this.raf = requestAnimationFrame(this.loop);
      return;
    }
    this.trackPerf(raw);
    if (dt > 0.05) dt = 0.05;
    // frame-time smoothing: a few ms of timer jitter would otherwise show up as micro-stutter in motion
    this.dtS += (dt - this.dtS) * 0.25;
    dt = this.dtS;
    if (this.freeze > 0) {
      this.freeze -= dt;
    } else {
      this.update(dt);
    }
    this.render();
    // idle-time sprite warming: one per frame, and only when this frame did not have to draw a new one
    if (this.bg.length && spriteBudgetLeft() > 0) this.bg.pop()!();
    this.raf = requestAnimationFrame(this.loop);
  }

  resize(instant = false) {
    const focus = this.player && !this.player.dead ? this.player : this.spectate;
    const r = focus ? focus.r : 9;
    const viewH = clamp(275 + (r - 7.6) * 4.5, 275, 650);
    const W = Math.max(1, window.innerWidth);
    const H = Math.max(1, window.innerHeight);
    const targetZoom = Math.max(1, Math.min(H / viewH, W / (viewH * 1.25)));
    this.zoom = instant ? targetZoom : this.zoom + (targetZoom - this.zoom) * 0.06;

    this.coinHudPos = { x: Math.min(W - 38, W / 2 + 465), y: 26 };

    if (this.pixelMode) {
      const qps = Math.max(1, Math.round(this.zoom * 20) / 20);
      const cw = Math.ceil(W / qps);
      const ch = Math.ceil(H / qps);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.dpr = 1;
      this.vw = cw;
      this.vh = ch;
    } else {
      const dpr = Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(MAX_PIXELS / (W * H))) * Q_SCALE[this.quality];
      const cw = Math.round(W * dpr);
      const ch = Math.round(H * dpr);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.dpr = dpr;
      this.vw = W / this.zoom;
      this.vh = H / this.zoom;
    }
  }

  // Smooth sliding collision against rocky overhangs & cavern walls so swimming through crevices feels silky-smooth!
  resolveRockCollisions(f: Fish) {
    const fr = f.r * 0.68;
    for (const c of this.ocean.colliders) {
      const dx = f.x - c.x;
      const dy = f.y - c.y;
      const minD = c.r + fr;
      if (Math.abs(dx) > minD || Math.abs(dy) > minD) continue;
      const d = Math.hypot(dx, dy) || 0.01;
      if (d < minD) {
        const nx = dx / d,
          ny = dy / d;
        const pen = minD - d;
        f.x += nx * pen;
        f.y += ny * pen;
        const vn = f.vx * nx + f.vy * ny;
        if (vn < 0) {
          f.vx -= nx * vn * 1.1;
          f.vy -= ny * vn * 1.1;
        }
      }
    }
  }

  update(dt: number) {
    this.t += dt;
    this.resize();
    const p = this.player;

    if (!p || p.dead) {
      if (!this.spectate || this.spectate.dead) {
        const bots = this.fish.filter((f) => f.kind === "bot" && !f.dead);
        bots.sort((a, b) => b.mass - a.mass);
        this.spectate = bots[Math.floor(Math.random() * Math.min(3, bots.length))] || null;
      }
    }

    if (p && !p.dead && !p.eatenBy) {
      this.applyBoost(p, this.boostInput, dt);
      const W = Math.max(1, window.innerWidth);
      const H = Math.max(1, window.innerHeight);

      // Sub-frame low-pass filter on raw OS mouse pixels: removes hardware stair-step jitter while staying agile!
      if (this.mouse.active) {
        if (this.mouse.sx === 0 && this.mouse.sy === 0) {
          this.mouse.sx = this.mouse.x;
          this.mouse.sy = this.mouse.y;
        } else {
          const mAlpha = 1 - Math.exp(-38 * dt);
          this.mouse.sx += (this.mouse.x - this.mouse.sx) * mAlpha;
          this.mouse.sy += (this.mouse.y - this.mouse.sy) * mAlpha;
        }
      }

      const ms = this.maxSpeed(p);
      const minCamX = this.vw >= WORLD_W ? WORLD_W / 2 : this.vw / 2;
      const maxCamX = this.vw >= WORLD_W ? WORLD_W / 2 : WORLD_W - this.vw / 2;
      const minCamY = -34 + this.vh / 2;
      const maxCamY = WORLD_H + 35 - this.vh / 2;

      // 1. SMOOTH, SPEED-LIMITED SWIMMING. The fish steers toward the cursor: the farther the cursor, the
      //    faster it swims, up to its top speed, easing in and out. (It used to snap straight to the cursor,
      //    which measured up to ~4400 units/s — the "teleporting" feel.)
      if (this.mouse.active) {
        const baseCamLeft = this.vw >= WORLD_W ? (WORLD_W - this.vw) / 2 : clamp(this.cam.x - this.vw / 2, 0, WORLD_W - this.vw);
        const baseCamTop = clamp(this.cam.y - this.vh / 2, -34, WORLD_H + 35 - this.vh);
        const tx = clamp(baseCamLeft + (this.mouse.sx / W) * this.vw, p.r, WORLD_W - p.r);
        const ty = clamp(baseCamTop + (this.mouse.sy / H) * this.vh, 14 + p.r * 0.5, floorY(tx) - p.r * 0.6);
        const dx = tx - p.x,
          dy = ty - p.y;
        const dist = Math.hypot(dx, dy);
        const dead = p.r * 0.3 + 1.5; // resting zone: the cursor is on the fish
        const full = this.vw * 0.11; // cursor distance at which the fish reaches top speed
        const want = dist <= dead ? 0 : ms * Math.pow(Math.min(1, (dist - dead) / full), 0.7);
        const acc = 1 - Math.exp(-(p.boosting ? 8.5 : 6.5) * dt);
        p.vx += ((dist > 0.01 ? (dx / dist) * want : 0) - p.vx) * acc;
        p.vy += ((dist > 0.01 ? (dy / dist) * want : 0) - p.vy) * acc;

        const stepX = p.vx * dt,
          stepY = p.vy * dt;
        const steps = Math.min(8, Math.max(1, Math.ceil(Math.hypot(stepX, stepY) / 5)));
        for (let k = 0; k < steps; k++) {
          p.x += stepX / steps;
          p.y += stepY / steps;
          this.resolveRockCollisions(p);
          const fy = floorY(p.x) - p.r * 0.6;
          if (p.y > fy) p.y = fy;
          if (p.y < 14 + p.r * 0.5) p.y = 14 + p.r * 0.5;
          p.x = clamp(p.x, p.r, WORLD_W - p.r);
        }

        // hysteresis so tiny hand tremors never flip the fish left/right
        if (dx > 3.2 || (Math.abs(dx) > 1.2 && p.vx > 20)) p.face = 1;
        else if (dx < -3.2 || (Math.abs(dx) > 1.2 && p.vx < -20)) p.face = -1;
      } else if (p.boosting) {
        p.vx = p.face * ms;
        p.vy = 0;
        p.x = clamp(p.x + p.vx * dt, p.r, WORLD_W - p.r);
        this.resolveRockCollisions(p);
      } else {
        p.vx *= Math.exp(-4 * dt);
        p.vy *= Math.exp(-4 * dt);
      }

      // 2. CAMERA: eases after the fish and looks a little ahead of where it is swimming
      // (the look-ahead is smoothed on its own, so a sudden change of direction never jerks the view)
      const lk = 1 - Math.exp(-2.6 * dt);
      this.look.x += (p.vx * 0.34 - this.look.x) * lk;
      this.look.y += (p.vy * 0.26 - this.look.y) * lk;
      const follow = 1 - Math.exp(-5 * dt);
      // the TARGET is clamped to the world, so the view eases to a stop at the edges instead of hitting them
      this.cam.x += (clamp(p.x + this.look.x, minCamX, maxCamX) - this.cam.x) * follow;
      this.cam.y += (clamp(p.y + this.look.y, minCamY, maxCamY) - this.cam.y) * follow;

      this.applySuckState(p, this.suckInput, dt);
      sfx.setSuck(p.sucking);
    } else {
      sfx.setSuck(false);
    }

    const predators = this.fish.filter((f) => !f.dead && !f.eatenBy && (f.kind !== "npc" || f.sp.predator));
    this.updateSchools(dt, predators);
    for (const f of this.fish) {
      if (f.dead || f.eatenBy || f.kind === "player") continue;
      f.ai.timer -= dt;
      if (f.kind === "bot") this.botAI(f, dt);
      else if (f.fry) this.fryAI(f, dt);
      else this.npcAI(f, dt, predators);
    }

    for (const f of this.fish) {
      if (f.sucking && !f.dead && !f.eatenBy) this.doSuck(f, dt);
    }

    for (const f of this.fish) {
      if (f.dead) continue;
      if (f.eatenBy) {
        f.eatT += dt / (f.fry ? 0.085 : 0.14);
        if (f.eatT >= 1) this.finishEat(f.eatenBy, f);
        continue;
      }
      const isDirectPlayer = f === p && this.mouse.active;
      if (!isDirectPlayer) {
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        this.resolveRockCollisions(f);

        const fy = floorY(f.x) - f.r * 0.6;
        if (f.y > fy) {
          f.y = fy;
          f.vy = Math.min(0, f.vy);
        }
        if (f.y < 14 + f.r * 0.5) {
          f.y = 14 + f.r * 0.5;
          f.vy = Math.max(0, f.vy);
        }
        if (f.x < f.r) {
          f.x = f.r;
          f.vx = Math.abs(f.vx);
        }
        if (f.x > WORLD_W - f.r) {
          f.x = WORLD_W - f.r;
          f.vx = -Math.abs(f.vx);
        }
      }
      const sp = Math.hypot(f.vx, f.vy);
      if (!isDirectPlayer && Math.abs(f.vx) > 6 && !(f.kind === "npc" && f.sucked > 0)) f.face = f.vx > 0 ? 1 : -1;

      // Smooth 3D-like turn flip (-1 .. +1) & gentle damped pitch tilt (zero micro-jitter when hovering!)
      const flipRate = 1 - Math.exp(-(f.kind === "player" ? 14 : 9) * dt);
      f.turnFlip += (f.face - f.turnFlip) * flipRate;

      const speedFactor = clamp((sp - 6) / 38, 0, 1);
      const targTilt = clamp(Math.atan2(f.vy, Math.abs(f.vx) + 28) * 0.62, -0.42, 0.42) * speedFactor;
      const tiltRate = 1 - Math.exp(-(f.kind === "player" ? 7 : 5) * dt);
      f.tilt += (targTilt - f.tilt) * tiltRate;
      f.tailPh += dt * (3.4 + Math.min(sp, 200) * 0.05); // calm tail beat: ~0.5 Hz idling, ~1.5 Hz at full speed
      if (f.sucked > 0) f.tailPh += dt * 9; // faster tail beats while being vacuumed
      if (f.gulpT > 0) f.gulpT -= dt / 0.45;
      if (f.slurpCd > 0) f.slurpCd -= dt;

      // Gentle breathing suction squash (no 40Hz buzz!) + smooth suction mist fade
      const targetSq = f.sucking ? 0.1 + Math.sin(this.t * 9) * 0.02 : 0;
      f.sqv += (-220 * (f.sq - targetSq) - 15 * f.sqv) * dt;
      f.sq += f.sqv * dt;
      const suckFade = 1 - Math.exp(-(f.sucking ? 14 : 10) * dt);
      f.suckVis += ((f.sucking ? 1 : 0) - f.suckVis) * suckFade;

      f.mouthOpenT -= dt;
      f.chompT -= dt;
      f.invuln -= dt;
      f.sucked -= dt;
      f.comboT -= dt;
      if (f.comboT <= 0) f.combo = 0;

      let jawTarget = 0;
      if (f.chompT > 0.06) jawTarget = 0;
      else if (f.mouthOpenT > 0) jawTarget = 1;
      else if (f.sucking) jawTarget = 0.9;
      else if (f.wantOpen) jawTarget = 0.72;
      else if (Math.sin(this.t * 2.2 + f.id) > 0.9) jawTarget = 0.32;
      const jawSpeed = jawTarget > f.jaw ? 18 : 22;
      f.jaw += (jawTarget - f.jaw) * Math.min(1, dt * jawSpeed);

      const tr = Math.sqrt(f.mass);
      f.r += (tr - f.r) * Math.min(1, dt * 3.2);
      f.wantOpen = false;
      if (f.kind !== "player" && !f.sucking) {
        f.energy = Math.min(1, f.energy + dt * 0.3);
      }
      if (f.boosting) {
        f.boostTrail -= dt;
        if (f.boostTrail <= 0 && Math.abs(f.x - this.cam.x) < this.vw && Math.abs(f.y - this.cam.y) < this.vh) {
          f.boostTrail = 0.036;
          const bx = f.x - f.face * f.r * 1.1,
            by = f.y + (Math.random() - 0.5) * f.r * 0.75;
          this.particles.push(this.bubble(bx, by, 0.9 + Math.random() * 1.3));
        }
      }
      if (f.kind === "npc" && Math.random() < dt * 0.15) this.particles.push(this.bubble(f.mouthX(), f.mouthY(), 1));
    }

    this.checkEating();

    this.fish = this.fish.filter((f) => !f.dead || f === this.player);
    if (this.player && this.player.dead) this.fish = this.fish.filter((f) => f !== this.player);
    let npcCount = 0;
    for (const f of this.fish) if (f.kind === "npc" && !f.fry) npcCount++;
    if (npcCount < NPC_TARGET) for (let i = 0; i < Math.min(8, NPC_TARGET - npcCount); i++) this.spawnNPC();
    if (p && !p.dead && Math.random() < dt * 2) {
      const cand = this.fish[Math.floor(Math.random() * this.fish.length)];
      if (cand && cand.kind === "npc" && !cand.fry && cand.r < p.r * 0.25 && Math.abs(cand.x - p.x) > this.vw) cand.dead = true;
    }
    for (const q of this.respawnQueue) q.t -= dt;
    const ready = this.respawnQueue.filter((q) => q.t <= 0);
    this.respawnQueue = this.respawnQueue.filter((q) => q.t > 0);
    for (const q of ready) this.spawnBot(q.name, q.skin, 58 + Math.random() * 140);

    // Spawn coins both from surface and inside glowing deep crevices!
    this.coinTimer -= dt;
    if (this.coinTimer <= 0) {
      this.coinTimer = 1.1 + Math.random() * 1.3;
      const x = this.cam.x + (Math.random() - 0.5) * this.vw * 1.4;
      this.worldCoins.push({
        x: clamp(x, 20, WORLD_W - 20),
        y: Math.random() < 0.35 ? DEEP_START + 120 + Math.random() * 550 : -4,
        vx: 0,
        vy: 16 + Math.random() * 14,
        t: 0,
        value: Math.random() < 0.35 ? 3 : 1 + Math.floor(Math.random() * 2),
        settled: false,
      });
      if (Math.random() < 0.35) {
        const c = this.ocean.chestPos;
        this.worldCoins.push({
          x: c.x,
          y: c.y - 6,
          vx: (Math.random() - 0.5) * 45,
          vy: -45 - Math.random() * 30,
          t: 0,
          value: 3,
          settled: false,
        });
      }
    }
    for (const c of this.worldCoins) {
      c.t += dt;
      if (!c.settled) {
        c.vy += (24 - c.vy) * dt * 0.8;
        c.vx *= 1 - dt * 1.5;
        c.x += c.vx * dt + Math.sin(c.t * 3) * 0.3;
        c.y += c.vy * dt;
        if (c.y > floorY(c.x) - 3) {
          c.y = floorY(c.x) - 3;
          c.settled = true;
        }
      }
      if (p && !p.dead && !p.eatenBy) {
        const mx = p.mouthX(),
          my = p.mouthY();
        const d = Math.hypot(c.x - mx, c.y - my);
        const magnet = p.r * 2.4 + 26;
        if (d < magnet && d > 0.5) {
          // coin magnet: nearby coins curve into the mouth on their own
          const pull = (70 + 260 * (1 - d / magnet)) * dt;
          c.settled = false;
          c.vx = 0;
          c.vy = 0;
          c.x += ((mx - c.x) / d) * Math.min(d, pull);
          c.y += ((my - c.y) / d) * Math.min(d, pull);
        }
        if (d < p.r * 0.9 + 6) {
          c.t = 999;
          for (let i = 0; i < c.value; i++) this.addFlyCoin(c.x, c.y, 1, i * 0.05, 0);
          this.arcadeScore += c.value * 50;
          this.texts.push({ x: c.x, y: c.y - 6, text: "+" + c.value, color: "#ffe14a", life: 0.8, max: 0.8, size: 9 });
          this.spawnSparks(c.x, c.y, "#ffe14a", 8);
          this.spawnRing(c.x, c.y, "#fff3a1", 7);
          p.sqv += 2.5;
        }
      }
    }
    this.worldCoins = this.worldCoins.filter((c) => c.t < 24 && c.y < WORLD_H + 10);

    const hx = this.camLeft + (this.coinHudPos.x / Math.max(1, window.innerWidth)) * this.vw;
    const hy = this.camTop + (this.coinHudPos.y / Math.max(1, window.innerHeight)) * this.vh;
    for (const c of this.flyCoins) {
      c.t += dt;
      if (c.t < 0) continue; // staggered: this coin has not popped out yet
      if (c.t < COIN_POP) {
        // 1) pop out of the mouth in a little fountain arc
        c.vy += 260 * dt;
        c.vx *= 1 - dt * 3.2;
        c.x += c.vx * dt;
        c.y += c.vy * dt;
        c.sx = c.x;
        c.sy = c.y;
      } else {
        // 2) swoop to the coin counter along a curved, accelerating path, shedding gold glints
        const u = Math.min(1, (c.t - COIN_POP) / COIN_FLY),
          e = u * u * (1.6 - 0.6 * u);
        const ex = hx - c.sx,
          ey = hy - c.sy,
          L = Math.hypot(ex, ey) || 1;
        const arc = Math.sin(e * Math.PI) * c.bend;
        c.x = c.sx + ex * e + (-ey / L) * arc;
        c.y = c.sy + ey * e + (ex / L) * arc;
        c.trail -= dt;
        if (c.trail <= 0) {
          c.trail = 0.03;
          this.particles.push({ x: c.x, y: c.y, vx: (Math.random() - 0.5) * 10, vy: 6 + Math.random() * 8, life: 0.3, max: 0.3, type: "glint", color: "#ffe14a", size: 1 });
        }
        if (u >= 1) {
          c.t = 999;
          this.sessionCoins += c.value;
          if (this.t - this.lastCoinT > 0.7) this.coinChain = 0;
          this.lastCoinT = this.t;
          sfx.coin(this.coinChain++);
          this.onEvent?.({ type: "coinbump" });
        }
      }
    }
    this.flyCoins = this.flyCoins.filter((c) => c.t < 999);

    if (Math.random() < dt * 7) {
      const v = this.ocean.vents[Math.floor(Math.random() * this.ocean.vents.length)];
      if (Math.abs(v.x - this.cam.x) < this.vw) this.particles.push(this.bubble(v.x + (Math.random() - 0.5) * 8, v.y, 1.2 + Math.random() * 2.2));
    }

    for (const pt of this.particles) {
      pt.life -= dt;
      if (pt.type === "bubble") {
        pt.vy -= 28 * dt;
        pt.vx = Math.sin(pt.life * 5.5 + pt.size) * 6;
        if (pt.y < 4) pt.life = 0;
      } else if (pt.type === "bit") {
        pt.vy += 45 * dt;
        pt.vx *= 1 - dt * 2.2;
        pt.vy *= 1 - dt * 1.2;
      } else if (pt.type === "suck" && pt.target) {
        const tx = pt.target.mouthX(),
          ty = pt.target.mouthY();
        const dx = tx - pt.x,
          dy = ty - pt.y;
        const d = Math.hypot(dx, dy) || 1;
        // Soft curved inward spiral toward mouth!
        const tangX = -dy / d,
          tangY = dx / d;
        const s = 135 + (pt.max - pt.life) * 280;
        pt.vx = (dx / d) * s + tangX * 26 * Math.sin(pt.size * 5);
        pt.vy = (dy / d) * s + tangY * 26 * Math.sin(pt.size * 5);
        if (d < 4 || pt.target.suckVis < 0.05) pt.life = 0;
      } else if (pt.type === "spark" || pt.type === "star") {
        pt.vx *= 1 - dt * 4;
        pt.vy *= 1 - dt * 4;
      }
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
    }
    this.particles = this.particles.filter((pt) => pt.life > 0);
    if (this.particles.length > 900) this.particles.splice(0, this.particles.length - 900);
    for (const tx of this.texts) {
      tx.life -= dt;
      tx.y -= dt * 18;
    }
    this.texts = this.texts.filter((tx) => tx.life > 0);

    // one juicy summary pop when a slurp chain ends
    this.chainPop = Math.max(0, this.chainPop - dt * 5);
    if (this.streamN > 0) {
      this.streamT -= dt;
      if (this.streamT <= 0) {
        if (p && !p.dead) {
          this.texts.push({ x: p.x, y: p.y - p.r * 1.15 - 44, text: "+" + this.streamPts, color: "#fff3a1", life: 1.1, max: 1.1, size: 9 + Math.min(6, this.streamN * 0.35) });
          this.texts.push({ x: p.x, y: p.y - p.r * 1.15 - 33, text: this.streamN + " ikan  +" + this.streamCoins + " koin", color: "#ffe14a", life: 1.1, max: 1.1, size: 7 });
        }
        this.streamPts = this.streamCoins = this.streamN = 0;
      }
    }

    // Camera smooth-follow only when spectating or during death animation (live player camera is driven above!)
    if (!p || p.dead || p.eatenBy) {
      const focus = p && !p.dead ? p.eatenBy || p : this.deathTimer >= 0 ? null : this.spectate;
      if (focus) {
        const lead = focus.vx * 0.22;
        this.cam.x += (focus.x + lead - this.cam.x) * Math.min(1, dt * 4.5);
        this.cam.y += (focus.y + focus.vy * 0.14 - this.cam.y) * Math.min(1, dt * 4.5);
      }
    }
    this.shake *= Math.exp(-9 * dt);
    if (this.shake < 0.05) this.shake = 0;

    if (this.deathTimer >= 0) {
      this.deathTimer -= dt;
      if (this.deathTimer < 0) {
        this.deathTimer = -1;
        for (const c of this.flyCoins) this.sessionCoins += c.value;
        this.flyCoins = [];
        this.onDeath?.({
          score: this.arcadeScore,
          coins: this.sessionCoins,
          killer: this.killerName,
          maxMass: Math.round(this.maxMass),
          eaten: this.eatenCount,
          time: Math.round(this.t - this.startTime),
        });
      }
    }

    if (p && !p.dead) {
      this.maxMass = Math.max(this.maxMass, p.mass);
      const lv = this.calcLevel(p.r);
      if (lv > this.level) {
        this.level = lv;
        const sp = SPECIES[Math.min(lv - 1, SPECIES.length - 1)];
        this.onEvent?.({ type: "levelup", text: "Ukuran naik! Bisa makan " + sp.name + "!" });
        sfx.levelUp();
        this.spawnRing(p.x, p.y, "#fff6a0", p.r * 2.1);
        this.spawnSparks(p.x, p.y, "#ffffff", 18);
      }
    }

    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.12;
      this.emitHud();
    }
    this.miniTimer -= dt;
    if (this.miniTimer <= 0) {
      this.miniTimer = 0.3;
      this.drawMinimap();
    }
  }

  maxSpeed(f: Fish) {
    if (f.kind === "npc") return f.sp.speed * NPC_SPEED;
    return 124 * Math.pow(8 / Math.max(8, f.r), 0.14) * f.speedMul * (f.boosting ? 1.6 : 1);
  }

  applySuckState(f: Fish, want: boolean, dt: number) {
    if (want && !f.exhausted && f.energy > 0) {
      f.sucking = true;
      f.energy -= (dt * 0.42) / (0.85 + f.suckMul * 0.15);
      if (f.energy <= 0) {
        f.energy = 0;
        f.exhausted = true;
        f.sucking = false;
      }
    } else {
      f.sucking = false;
      f.energy = Math.min(1, f.energy + dt * 0.28);
      if (f.exhausted && f.energy > 0.3) f.exhausted = false;
    }
  }

  suckRange(f: Fish) {
    return (f.r * 3.2 + 28) * f.suckMul;
  }

  doSuck(f: Fish, dt: number) {
    const mx = f.mouthX(),
      my = f.mouthY();
    const dirx = f.face * Math.cos(f.tilt),
      diry = Math.sin(f.tilt);
    const range = this.suckRange(f);
    for (const o of this.fish) {
      if (o === f || o.dead || o.eatenBy || o.invuln > 0) continue;
      if (o.r >= f.r * EAT_RATIO) continue;
      const dx = o.x - mx,
        dy = o.y - my;
      if (Math.abs(dx) > range + o.r || Math.abs(dy) > range + o.r) continue;
      const d = Math.hypot(dx, dy);
      if (d > range + o.r || d < 0.1) continue;
      const cos = (dx * dirx + dy * diry) / d;
      if (cos < (o.fry ? 0.28 : 0.45)) continue;
      const strength = 350 * f.suckMul * (1.1 - d / (range + o.r)) * clamp((f.r / o.r) * 0.45, 0.35, 1.4);
      o.vx -= (dx / d) * strength * dt * 3;
      o.vy -= (dy / d) * strength * dt * 3;
      // whirlpool: prey spirals into the mouth instead of sliding in on a straight line
      const whirl = (o.id & 1 ? 1 : -1) * strength * dt * 1.5 * Math.min(1, d / (range * 0.6));
      o.vx += (-dy / d) * whirl;
      o.vy += (dx / d) * whirl;
      o.vx *= 1 - dt * 2;
      o.vy *= 1 - dt * 2;
      o.sucked = 0.18;
      if (o.kind === "npc") o.face = dx >= 0 ? 1 : -1; // dragged in tail-first, still trying to swim away
      f.wantOpen = true;
    }
    if (f.kind === "player") {
      for (const c of this.worldCoins) {
        const dx = c.x - mx,
          dy = c.y - my;
        const d = Math.hypot(dx, dy);
        if (d < range * 1.2 && (dx * dirx + dy * diry) / (d || 1) > 0.3) {
          c.settled = false;
          c.vx = (-dx / d) * 160;
          c.vy = (-dy / d) * 160;
        }
      }
    }
    const onScreen = Math.abs(mx - this.cam.x) < this.vw && Math.abs(my - this.cam.y) < this.vh;
    if (onScreen && Math.random() < 0.65) {
      const a = Math.atan2(diry, dirx) + (Math.random() - 0.5) * 1.05;
      const dd = range * (0.45 + Math.random() * 0.48);
      this.particles.push({
        x: mx + Math.cos(a) * dd,
        y: my + Math.sin(a) * dd,
        vx: 0,
        vy: 0,
        life: 0.72,
        max: 0.72,
        type: "suck",
        color: "#a5f3fc",
        size: 0.9 + Math.random() * 1.0,
        target: f,
      });
    }
  }

  botAI(f: Fish, dt: number) {
    if (f.ai.timer <= 0) {
      f.ai.timer = 0.2 + Math.random() * 0.15;
      let threat: Fish | null = null,
        td = 1e9;
      let best: Fish | null = null,
        bv = 0;
      for (const o of this.fish) {
        if (o === f || o.dead || o.eatenBy) continue;
        const dx = o.x - f.x,
          dy = o.y - f.y;
        if (Math.abs(dx) > 300 || Math.abs(dy) > 300) continue;
        const d = Math.hypot(dx, dy);
        if (o.r * EAT_RATIO > f.r && (o.kind !== "npc" || o.sp.predator)) {
          if (d < 80 + o.r * 2.2 && d < td) {
            td = d;
            threat = o;
          }
        } else if (o.r < f.r * EAT_RATIO && o.invuln <= 0 && d < 260) {
          const pw = o.kind === "player" ? (this.t - this.startTime < 12 ? 0.25 : o.mass < 160 ? 0.6 : 1.1) : 1;
          const v = (o.mass * pw) / (d + 40);
          if (v > bv) {
            bv = v;
            best = o;
          }
        }
      }
      f.ai.flee = !!threat;
      if (threat) {
        const dx = f.x - threat.x,
          dy = f.y - threat.y;
        const d = Math.hypot(dx, dy) || 1;
        f.ai.tx = f.x + (dx / d) * 200;
        f.ai.ty = f.y + (dy / d) * 200;
        f.ai.target = null;
      } else if (best) {
        f.ai.target = best;
      } else {
        f.ai.target = null;
        if (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 30 || Math.random() < 0.05) {
          const p = this.randomSpawnPos(f.r, false);
          f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 600, 40, WORLD_W - 40);
          f.ai.ty = p.y;
        }
      }
    }
    let tx = f.ai.tx,
      ty = f.ai.ty;
    const tgt = f.ai.target;
    if (tgt && !tgt.dead && !tgt.eatenBy) {
      tx = tgt.x + tgt.vx * 0.3;
      ty = tgt.y + tgt.vy * 0.3;
    }
    const dx = tx - f.x,
      dy = ty - f.y;
    const d = Math.hypot(dx, dy) || 1;
    let wantBoost = false;
    if (f.ai.flee && f.boost > 0.25) wantBoost = true;
    if (tgt && !tgt.dead && d < 90 && d > this.suckRange(f) * 0.5 && f.boost > 0.5 && Math.random() < 0.6) wantBoost = true;
    this.applyBoost(f, wantBoost, dt);
    const ms = this.maxSpeed(f) * (f.ai.flee || f.boosting ? 1 : 0.85);
    // softer steering: rivals turn in arcs instead of snapping onto a new heading
    f.vx += ((dx / d) * ms - f.vx) * Math.min(1, dt * 3.4);
    f.vy += ((dy / d) * ms - f.vy) * Math.min(1, dt * 3.4);
    const wantSuck = !!tgt && !tgt.dead && d < this.suckRange(f) * 0.9 && Math.sign(dx) === f.face && f.energy > 0.2;
    this.applySuckState(f, wantSuck, dt);
    if (f.mass > 3200) f.mass -= dt * 14;
  }

  npcAI(f: Fish, dt: number, predators: Fish[]) {
    if (f.ai.timer <= 0) {
      f.ai.timer = 0.25 + Math.random() * 0.25;
      f.ai.flee = false;
      let threat: Fish | null = null,
        td = 1e9;
      for (const o of predators) {
        if (o === f || o.r * EAT_RATIO <= f.r) continue;
        const dx = o.x - f.x,
          dy = o.y - f.y;
        if (Math.abs(dx) > 150 || Math.abs(dy) > 150) continue;
        const d = Math.hypot(dx, dy);
        if (d < 50 + o.r * 1.6 && d < td) {
          td = d;
          threat = o;
        }
      }
      if (threat && Math.random() < 0.85) {
        const dx = f.x - threat.x,
          dy = f.y - threat.y;
        const d = Math.hypot(dx, dy) || 1;
        f.ai.tx = f.x + (dx / d) * 120;
        f.ai.ty = f.y + (dy / d) * 120;
        f.ai.flee = true;
      } else if (f.sp.predator) {
        f.ai.rest -= 0.3;
        if (f.ai.chase > 0) f.ai.chase -= 0.3;
        if (f.ai.target && (f.ai.target.dead || f.ai.target.eatenBy || f.ai.chase <= 0)) {
          f.ai.target = null;
          f.ai.rest = 3;
        }
        if (!f.ai.target && f.ai.rest <= 0) {
          let best: Fish | null = null,
            bd = 170;
          for (const o of this.fish) {
            if (o === f || o.dead || o.r >= f.r * EAT_RATIO || o.invuln > 0) continue;
            if (o.kind === "npc" && o.r < f.r * 0.25) continue;
            const d = Math.hypot(o.x - f.x, o.y - f.y);
            const w = o.kind === "npc" ? d * 1.5 : d;
            if (w < bd) {
              bd = w;
              best = o;
            }
          }
          if (best) {
            f.ai.target = best;
            f.ai.chase = 3.5;
          }
        }
        if (!f.ai.target && (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 20 || Math.random() < 0.04)) {
          f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 500, 40, WORLD_W - 40);
          f.ai.ty = clamp(f.y + (Math.random() - 0.5) * 240, 80, floorY(f.x) - 50);
        }
      } else if (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 15 || Math.random() < 0.06) {
        f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 260, 20, WORLD_W - 20);
        f.ai.ty = clamp(f.y + (Math.random() - 0.5) * 140, 30, floorY(f.x) - 25);
      }
    }
    if (f.sucked > 0) return;
    let tx = f.ai.tx,
      ty = f.ai.ty;
    const tgt = f.ai.target;
    let boost = f.ai.flee ? 1.3 : 0.55;
    if (tgt && !tgt.dead) {
      tx = tgt.x;
      ty = tgt.y;
      boost = 1.2;
    }
    const dx = tx - f.x,
      dy = ty - f.y;
    const d = Math.hypot(dx, dy) || 1;
    // glide: never brake to a dead stop at a waypoint, and steer in wide, soft arcs
    const ms = f.sp.speed * NPC_SPEED * boost * (d < 14 ? 0.4 + (d / 14) * 0.6 : 1);
    const steer = Math.min(1, dt * (f.ai.flee ? 3.6 : 2.3));
    f.vx += ((dx / d) * ms - f.vx) * steer;
    f.vy += ((dy / d) * ms - f.vy) * steer;
  }

  checkEating() {
    const list = this.fish;
    for (const e of list) {
      if (e.dead || e.eatenBy) continue;
      if (e.kind === "npc" && !e.sp.predator) continue;
      const busy = e.chompT > (e.munch ? 0.26 : 0.08);
      const mx = e.mouthX(),
        my = e.mouthY();
      for (const o of list) {
        if (o === e || o.dead || o.eatenBy || o.invuln > 0) continue;
        if (o.r >= e.r * EAT_RATIO) continue;
        if (e.kind === "npc" && o.kind === "npc" && o.r < e.r * 0.25) continue;
        if (o.fry ? e.slurpCd > 0 : busy) continue;
        const dx = o.x - mx,
          dy = o.y - my;
        const reach = o.r + e.r * 0.5;
        if (Math.abs(dx) > reach * 3.0 || Math.abs(dy) > reach * 3.0) continue;
        const d = Math.hypot(dx, dy);
        if (d < reach * 2.8) e.wantOpen = true;
        if (d < reach || Math.hypot(o.x - e.x, o.y - e.y) < e.r * 0.55) {
          this.startEat(e, o);
          if (!o.fry) break;
          e.slurpCd = 0.065; // fry are slurped in a quick rhythmic stream, even mid-chew
        }
      }
    }
  }

  startEat(e: Fish, o: Fish) {
    o.eatenBy = e;
    o.eatT = 0;
    o.eatFromX = o.x;
    o.eatFromY = o.y;
    o.sucking = false;
    o.boosting = false;
    e.jaw = 1;
    e.mouthOpenT = 0.14;
    if (o === this.player) {
      sfx.setSuck(false);
    }
  }

  finishEat(e: Fish, o: Fish) {
    o.dead = true;
    o.eatenBy = null;
    const mx = e.mouthX(),
      my = e.mouthY();
    const tiny = o.fry;

    if (e.kind === "npc") {
      e.mass += o.mass * 0.025;
    } else {
      const taper = 1 / (1 + Math.max(0, e.r - 8) * 0.04);
      const rawGain = o.mass * GAIN * taper;
      const maxStep = e.mass * 0.055 + 2.0;
      e.mass += Math.min(rawGain, maxStep);
    }
    if (e.r > e.maxR) e.mass = e.maxR * e.maxR;

    if (tiny) {
      // rapid slurp: the mouth stays open while vacuuming and every fry is a quick gulp pulse
      e.sqv += 3.4;
      e.gulpK = Math.max(e.gulpT > 0 ? e.gulpK : 0, 0.1);
      e.gulpT = Math.max(e.gulpT, 0.6);
      if (!e.sucking) {
        e.jaw = 0;
        e.chompT = 0.14;
        e.munch = false;
      }
    } else {
      const big = o.r > e.r * 0.4;
      e.jaw = 0;
      e.munch = big; // big mouthfuls get chewed
      e.chompT = big ? 0.44 : 0.26;
      e.sqv += 9.5 + Math.min(6, o.r / e.r) * 4.5;
      e.vx += e.face * Math.cos(e.tilt) * 18;
      e.vy += Math.sin(e.tilt) * 18;
      // the swallowed prey travels down the body as a visible bulge
      e.gulpT = 1;
      e.gulpK = 0.1 + Math.min(0.15, (o.r / e.r) * 0.25);
    }
    e.score += Math.round(o.mass * 12);

    const onScreen = Math.abs(mx - this.cam.x) < this.vw && Math.abs(my - this.cam.y) < this.vh;
    if (onScreen) {
      const cols = [o.sp.pal.body, o.sp.pal.belly, o.sp.pal.fin];
      if (tiny) {
        this.spawnRing(mx, my, o.sp.pal.fin, 3.4);
        for (let i = 0; i < 3; i++) {
          const a = Math.random() * Math.PI * 2;
          const s = 16 + Math.random() * 34;
          this.particles.push({
            x: mx,
            y: my,
            vx: Math.cos(a) * s + e.face * 12,
            vy: Math.sin(a) * s - 10,
            life: 0.3 + Math.random() * 0.25,
            max: 0.55,
            type: "bit",
            color: cols[i],
            size: 1.1 + Math.random() * 0.8,
          });
        }
        if (Math.random() < 0.5) this.particles.push(this.bubble(mx, my, 0.9 + Math.random() * 1.2));
      } else {
        this.particles.push({
          x: mx + e.face * e.r * 0.15,
          y: my,
          vx: e.face * 10,
          vy: 0,
          life: 0.22,
          max: 0.22,
          type: "chomp",
          color: "#e0f7ff",
          size: Math.max(6, e.r * 0.65),
          dir: e.face,
        });
        const n = 7 + Math.min(12, Math.round(o.r));
        for (let i = 0; i < n; i++) {
          const a = Math.random() * Math.PI * 2;
          const s = 20 + Math.random() * 58;
          this.particles.push({
            x: mx,
            y: my,
            vx: Math.cos(a) * s + e.face * 18,
            vy: Math.sin(a) * s - 16,
            life: 0.5 + Math.random() * 0.4,
            max: 0.9,
            type: "bit",
            color: cols[i % 3],
            size: 1.6 + Math.random() * 1.6,
          });
        }
        for (let i = 0; i < 4; i++) this.particles.push(this.bubble(mx + (Math.random() - 0.5) * 8, my, 1.2 + Math.random() * 2.2));
        this.spawnRing(mx, my, "#bae6fd", Math.max(5, o.r));
        // impact speed-lines + a second, wider shock ring
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2 + Math.random() * 0.5;
          const s = 95 + Math.random() * 75;
          this.particles.push({ x: mx + Math.cos(a) * 3, y: my + Math.sin(a) * 3, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.2, max: 0.2, type: "streak", color: "#ffffff", size: 1 });
        }
        this.spawnRing(mx, my, "#ffffff", Math.max(8, o.r * 1.7));
      }
    }

    if (e === this.player) {
      e.combo++;
      e.comboT = 2.6;
      this.chainPop = 1;
      const mult = e.combo >= 10 ? 3 : e.combo >= 5 ? 2 : 1;
      const pts = Math.round((45 + o.mass * 3.5 + (o.kind === "bot" ? 500 : 0)) * mult);
      this.arcadeScore += pts;

      let coins = tiny ? 1 : Math.max(1, Math.round(o.r / 2.6)) * mult;
      if (o.kind === "bot") coins += 15;
      const n = Math.min(coins, 10);
      for (let i = 0; i < n; i++) {
        const v = Math.floor(coins / n) + (i < coins % n ? 1 : 0);
        this.addFlyCoin(mx, my, v, i * 0.045, e.face);
      }
      this.eatenCount++;
      if (tiny) {
        // no text spam per fry: pops climb in pitch and the chain is summed up when it ends
        this.streamPts += pts;
        this.streamCoins += coins;
        this.streamN++;
        this.streamT = 0.5;
        sfx.pop(e.combo);
        this.shake = Math.min(1.2, this.shake + 0.18);
        const s = o.school;
        if (s) {
          s.byPlayer++;
          if (!s.members.some((m) => !m.dead) && s.byPlayer >= s.size0 * 0.7) this.schoolBonus(s, mx, my);
        }
      } else {
        this.texts.push({ x: mx, y: my - e.r * 0.8, text: "+" + pts, color: "#fff3a1", life: 0.85, max: 0.85, size: 8 });
        if (Math.random() < 0.55 || o.r > e.r * 0.5) {
          this.texts.push({
            x: mx + (Math.random() - 0.5) * 10,
            y: my - e.r * 1.4 - 8,
            text: WORDS[Math.floor(Math.random() * WORDS.length)],
            color: "#ffffff",
            life: 0.7,
            max: 0.7,
            size: 9,
          });
        }
        this.spawnSparks(mx, my - e.r * 0.3, "#fff7c2", 5);
        sfx.gulp(o.r / 6);
        this.shake = Math.min(3, this.shake + 0.5 + o.r / 10);
        // hit-stop: a few frozen frames sell the weight of a big bite
        // hit-stop only for genuinely big bites (it used to fire on almost every bite of a small fish,
        // which read as stutter rather than impact)
        this.freeze = o.kind === "bot" ? 0.045 : 0;
      }
      if (e.combo === 7 || e.combo === 14 || e.combo === 22) {
        this.onEvent?.({ type: "frenzy", n: e.combo });
        sfx.frenzy();
        this.spawnSparks(e.x, e.y, "#ffe14a", 22);
      } else if (e.combo >= 3) {
        this.onEvent?.({ type: "combo", n: e.combo });
        if (!tiny) sfx.combo(e.combo);
      }
      if (o.kind === "bot") this.onEvent?.({ type: "feed", text: `${e.name} memakan ${o.name}!` });
    } else if (onScreen && !tiny && Math.abs(mx - this.cam.x) < this.vw / 2) {
      sfx.gulp(o.r / 6);
    }

    if (o.kind === "bot") {
      this.respawnQueue.push({ t: 1.5 + Math.random() * 2.5, name: o.name, skin: o.skinRef || SKINS[0] });
      if (e.kind === "bot") this.onEvent?.({ type: "feed", text: `${e.name} memakan ${o.name}!` });
    }
    if (o === this.player) {
      this.killerName = e.name || e.sp.name;
      this.deathTimer = 1.6;
      this.shake = 6;
      sfx.die();
      sfx.setSuck(false);
      this.texts.push({ x: mx, y: my - e.r - 10, text: "DIMAKAN!", color: "#ff5a6a", life: 1.5, max: 1.5, size: 16 });
      this.onEvent?.({ type: "feed", text: `${this.killerName} memakan ${o.name}!` });
      this.spectate = e;
    }
  }

  /** A coin pops out of the mouth (staggered by `delay`), then swoops to the coin counter. */
  addFlyCoin(x: number, y: number, value: number, delay = 0, dir = 0) {
    const a = -Math.PI / 2 + (Math.random() - 0.5) * 1.9 + dir * 0.3;
    const s = 70 + Math.random() * 90;
    this.flyCoins.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, t: -delay, value, sx: x, sy: y, bend: (Math.random() < 0.5 ? -1 : 1) * (16 + Math.random() * 30), trail: 0 });
  }

  bubble(x: number, y: number, size: number): Particle {
    return { x, y, vx: 0, vy: -10 - Math.random() * 10, life: 2.2 + Math.random() * 2, max: 4.2, type: "bubble", color: "#e8ffff", size };
  }

  spawnRing(x: number, y: number, color: string, size: number) {
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0.36, max: 0.36, type: "ring", color, size });
  }

  spawnSparks(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 38 + Math.random() * 85;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.55 + Math.random() * 0.4,
        max: 0.95,
        type: Math.random() < 0.5 ? "star" : "spark",
        color,
        size: 1.8,
      });
    }
  }

  emitHud() {
    const p = this.player;
    const ranked = this.fish.filter((f) => (f.kind === "bot" || f.kind === "player") && !f.dead).sort((a, b) => b.mass - a.mass);
    this.leaderId = ranked[0]?.id ?? -1;
    const rank = p && !p.dead ? ranked.indexOf(p) + 1 : 0;
    const frenzyStage = p ? Math.min(7, p.combo) : 0;
    const py = p ? p.y : this.cam.y;
    const zoneName = `${ZONE_LABELS[zoneAt(py)]} (${depthMeters(py)} m)`;
    this.onHud?.({
      coins: this.sessionCoins,
      score: this.arcadeScore,
      mass: p ? Math.round(p.mass) : 0,
      energy: p ? p.energy : 0,
      combo: p ? p.combo : 0,
      comboT: p ? p.comboT : 0,
      frenzyStage,
      level: this.level,
      growthPct: p ? this.calcGrowthPct(p.r) : 0,
      stageNum: Math.max(1, this.level - 1),
      zoneName,
      rank,
      total: ranked.length + this.respawnQueue.length, // rivals waiting to respawn still count: always 50 players
      leaderboard: ranked.slice(0, 6).map((f) => ({ name: f.name, score: Math.round(f.mass), me: f === p, color: f.sp.pal.body })),
      alive: !!p && !p.dead && this.deathTimer < 0,
      exhausted: p ? p.exhausted : false,
      boost: p ? p.boost : 0,
      boostExhausted: p ? p.boostExhausted : false,
      sucking: p ? p.sucking : false,
      boosting: p ? p.boosting : false,
    });
  }

  drawMinimap() {
    const m = this.minimap;
    if (!m) return;
    const c = m.getContext("2d")!;
    const w = m.width,
      h = m.height;
    const mg = c.createLinearGradient(0, 0, 0, h);
    mg.addColorStop(0, "#155e8a");
    mg.addColorStop(0.45, "#0c2d5e");
    mg.addColorStop(1, "#050d28");
    c.fillStyle = mg;
    c.fillRect(0, 0, w, h);

    const sx = w / WORLD_W,
      sy = h / WORLD_H;

    // Show cavern rock islands & crevices on minimap!
    c.fillStyle = "rgba(38, 95, 145, 0.7)";
    for (const col of this.ocean.colliders) {
      c.beginPath();
      c.arc(col.x * sx, col.y * sy, Math.max(1.5, col.r * sx * 1.2), 0, Math.PI * 2);
      c.fill();
    }

    c.fillStyle = "#4c2882";
    for (let x = 0; x < w; x++) {
      const fy = (floorY((x / w) * WORLD_W) / WORLD_H) * h;
      c.fillRect(x, fy, 1, h - fy);
    }

    c.strokeStyle = "rgba(255,245,190,0.75)";
    c.lineWidth = 1;
    c.strokeRect(this.camLeft * sx + 0.5, this.camTop * sy + 0.5, this.vw * sx, this.vh * sy);
    const p = this.player;
    for (const f of this.fish) {
      if (f.dead) continue;
      if (f.kind === "bot") {
        c.fillStyle = p && !p.dead && f.r * EAT_RATIO > p.r ? "#ff4a5a" : f.sp.pal.body;
        c.beginPath();
        c.arc(f.x * sx, f.y * sy, 1.9, 0, Math.PI * 2);
        c.fill();
      } else if (f.kind === "npc" && f.sp.predator) {
        c.fillStyle = "#ff8a8a";
        c.fillRect(f.x * sx - 1, f.y * sy - 1, 2, 2);
      }
    }
    // snack schools show up as little shimmering clusters
    c.fillStyle = "rgba(200, 245, 255, 0.95)";
    for (const s of this.schools) {
      if (s.members.length < 4) continue;
      const qx = s.x * sx,
        qy = s.y * sy;
      c.fillRect(qx - 2, qy - 0.5, 1, 1);
      c.fillRect(qx, qy - 1.5, 1, 1);
      c.fillRect(qx + 1.5, qy + 0.5, 1, 1);
      c.fillRect(qx - 0.5, qy + 1, 1, 1);
    }
    if (p && !p.dead) {
      c.fillStyle = "#ffffff";
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, 3.2, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = "#ffa22a";
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, 2, 0, Math.PI * 2);
      c.fill();
    }
  }

  // Draws 100% Seamless, Line-Free, Velvety Water Suction Mist (zero lines, zero triangle cone borders!)
  drawSoftSuctionVortex(f: Fish, camLeft: number, camTop: number, vw: number, vh: number) {
    if (f.suckVis < 0.02) return;
    const mx = f.mouthX() - camLeft,
      my = f.mouthY() - camTop;
    if (mx < -180 || mx > vw + 180 || my < -180 || my > vh + 180) return;
    const ctx = this.ctx;
    const range = this.suckRange(f);
    const ang = Math.atan2(Math.sin(f.tilt), f.face * Math.cos(f.tilt));
    const vis = f.suckVis;
    const S = this.pixelMode ? 1 : this.zoom * this.dpr;
    const cs = Math.cos(ang) * S,
      sn = Math.sin(ang) * S;
    const orb = glowOrb("rgba(170, 240, 255, 0.5)", false);
    ctx.globalCompositeOperation = "lighter";
    ctx.setTransform(cs, sn, -sn, cs, mx * S, my * S);
    // soft borderless mist in front of the mouth ...
    const rc = range * 0.52;
    ctx.globalAlpha = 0.6 * vis;
    ctx.drawImage(orb, range * 0.48 - rc, -rc * 0.56, rc * 2, rc * 1.12);
    // ... and three clouds gliding into it
    for (let i = 0; i < 3; i++) {
      const prog = (this.t * 1.6 + i / 3) % 1;
      const dist = range * (0.12 + (1 - prog * prog) * 0.7);
      const rx = range * (0.12 + (1 - prog) * 0.18);
      const ry = range * (0.08 + (1 - prog) * 0.24);
      ctx.globalAlpha = 0.55 * Math.sin(prog * Math.PI) * vis;
      ctx.drawImage(orb, dist - rx, -ry, rx * 2, ry * 2);
    }
    ctx.setTransform(S, 0, 0, S, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  /** Outlined text drawn once into a small canvas and then reused as a sprite (stroking glyphs per frame is slow). */
  label(text: string, col: string, size: number): { cv: HTMLCanvasElement; w: number; h: number } {
    const q = Math.min(4, Math.max(1, Math.ceil(this.pxs() * 2) / 2)); // device px per world unit, in half steps
    const key = text + "|" + col + "|" + size + "|" + q + (this.pixelMode ? "p" : "");
    let e = this.labels.get(key);
    if (!e) {
      const font = this.pixelMode ? `${Math.max(5, size - 2)}px 'Press Start 2P', monospace` : `700 ${size}px 'Fredoka', system-ui, sans-serif`;
      const cv = document.createElement("canvas");
      const c = cv.getContext("2d")!;
      c.font = font;
      const w = c.measureText(text).width + 6.4,
        h = size * 1.5 + 6.4;
      cv.width = Math.max(2, Math.ceil(w * q));
      cv.height = Math.max(2, Math.ceil(h * q));
      c.setTransform(q, 0, 0, q, 0, 0);
      c.font = font;
      c.textAlign = "center";
      c.textBaseline = "middle";
      c.lineJoin = "round";
      c.miterLimit = 2;
      c.strokeStyle = "rgba(8, 22, 52, 0.9)";
      c.lineWidth = 2.6;
      c.strokeText(text, w / 2, h / 2);
      c.fillStyle = col;
      c.fillText(text, w / 2, h / 2);
      e = { cv, w: cv.width / q, h: cv.height / q };
      if (this.labels.size > 260) this.labels.clear();
      this.labels.set(key, e);
    }
    return e;
  }

  private pxs() {
    return this.pixelMode ? 1 : this.zoom * this.dpr;
  }

  render() {
    beginSpriteFrame(SPRITE_BUDGET);
    const ctx = this.ctx;
    const scale = this.pixelMode ? 1 : this.zoom * this.dpr;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.imageSmoothingEnabled = !this.pixelMode;

    const vw = this.vw,
      vh = this.vh;
    let camLeft = this.cam.x - vw / 2;
    let camTop = this.cam.y - vh / 2;
    camLeft = vw >= WORLD_W ? (WORLD_W - vw) / 2 : clamp(camLeft, 0, WORLD_W - vw);
    camTop = clamp(camTop, -34, WORLD_H + 35 - vh);
    if (this.shake > 0) {
      // a smooth decaying wobble instead of random per-frame jitter
      camLeft += Math.sin(this.t * 58) * this.shake * 0.45;
      camTop += Math.cos(this.t * 47) * this.shake * 0.45;
    }
    // one camera, snapped to the device-pixel grid, for EVERYTHING drawn this frame: sprites and pixel-art
    // backgrounds then move in lockstep (no 1px wobble of fish against the reef)
    camLeft = Math.round(camLeft * scale) / scale;
    camTop = Math.round(camTop * scale) / scale;
    this.camLeft = camLeft;
    this.camTop = camTop;
    const t = this.t;
    const oc = this.ocean;
    oc.time = t;
    oc.pxs = scale;
    const focus = this.player && !this.player.dead ? this.player : null;
    oc.focusX = focus ? focus.x : -9999;
    oc.focusY = focus ? focus.y : -9999;

    oc.drawWater(ctx, camLeft, camTop, vw, vh);
    oc.drawLight(ctx, 0, camLeft, camTop, vw, vh, t); // sun bloom, far shafts, caustics
    oc.drawLayers(ctx, camLeft, camTop, vw, vh);

    // Soft glowing floating plankton & bioluminescent deep-sea dust (fast cached glowOrb blits!)
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const deepAmt = clamp((camTop - 550) / 500, 0, 1);
    ctx.globalAlpha = 0.38 + deepAmt * 0.36;
    for (const m of this.motes) {
      const p = 0.6 + m.s * 0.5;
      const x = ((((m.x - camLeft * p + t * 3.5 * m.s) % 2000) + 2000) % 2000) - 100;
      const y = ((((m.y - camTop * p + Math.sin(t + m.x) * 6) % 1400) + 1400) % 1400) - 100;
      if (x < -10 || x > vw + 10 || y < -10 || y > vh + 10) continue;
      const rad = (m.s > 0.7 ? 2.6 : 1.6) * (1 + deepAmt * 0.45);
      ctx.drawImage(glowOrb(m.col, true), x - rad, y - rad, rad * 2, rad * 2);
    }
    ctx.restore();

    // Scenic Rock Overhangs, Stalactite Arches & Glowing Bioluminescent Crevices!
    oc.drawRockFormations(ctx, camLeft, camTop, vw, vh, t);
    oc.drawFloor(ctx, camLeft, camTop, vw, vh);
    oc.drawBackDecor(ctx, camLeft, camTop, vw, vh, t);

    for (const c of this.worldCoins) {
      const x = c.x - camLeft,
        y = c.y - camTop;
      if (x < -12 || x > vw + 12 || y < -12 || y > vh + 12) continue;
      const blink = c.t > 20 && Math.floor(c.t * 8) % 2 === 0;
      if (blink) continue;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.45 + Math.sin(t * 5 + c.x) * 0.18;
      ctx.drawImage(glowOrb("rgba(255, 214, 80, 0.55)", false), x - 11, y - 11, 22, 22);
      ctx.restore();
      ctx.drawImage(coinSprite(Math.floor(c.t * 10 + c.x)), x - 5.5, y - 5.5, 11, 11);
    }

    // only fish near the view are sorted & drawn (the ocean holds ~650)
    const sorted = this.vis;
    sorted.length = 0;
    for (const f of this.fish) {
      if (f.dead) continue;
      const m = f.r * 3 + 70;
      const fx = f.eatenBy ? f.eatFromX : f.x,
        fy = f.eatenBy ? f.eatFromY : f.y;
      if (fx < camLeft - m || fx > camLeft + vw + m || fy < camTop - m || fy > camTop + vh + m) continue;
      sorted.push(f);
    }
    sorted.sort((a, b) => (a.eatenBy ? 1 : 0) - (b.eatenBy ? 1 : 0) || a.r - b.r);

    // the soft light the player carries in the dark zones (pre-rendered glow sprites, no gradients)
    const p = this.player;
    if (p && !p.dead && !p.eatenBy && p.y > DEEP_START - 120) {
      const kDeep = clamp((p.y - (DEEP_START - 120)) / 320, 0, 1);
      const orb = glowOrb("rgba(120, 232, 255, 0.5)", false);
      const haloR = p.r * 5.2 + 45;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.5 * kDeep;
      ctx.drawImage(orb, p.x - camLeft - haloR, p.y - camTop - haloR, haloR * 2, haloR * 2);
      const beamRx = p.r * 3.4 + 42,
        beamRy = beamRx * 0.42;
      const ang = Math.atan2(Math.sin(p.tilt), p.face * Math.cos(p.tilt));
      const cs = Math.cos(ang) * scale,
        sn = Math.sin(ang) * scale;
      ctx.setTransform(cs, sn, -sn, cs, (p.mouthX() - camLeft) * scale, (p.mouthY() - camTop) * scale);
      ctx.globalAlpha = 0.45 * kDeep;
      ctx.drawImage(orb, -beamRx * 0.28, -beamRy, beamRx * 2, beamRy * 2);
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    // Soft Suction Vortex Cones & Gossamer Ribbons
    for (const f of sorted) {
      if (f.sucking && !f.eatenBy) {
        this.drawSoftSuctionVortex(f, camLeft, camTop, vw, vh);
      }
    }

    // Draw Fish
    for (const f of sorted) this.drawFish(f, camLeft, camTop);

    // ---------- particles in two passes (normal, then additive): the blend mode is switched twice per
    // frame instead of save/restore around every single particle ----------
    const parts = this.particles;
    const bub = getBubbleStamp();
    const gold = glowOrb("rgba(255, 196, 40, 0.98)", false);
    ctx.lineCap = "round";
    for (const pt of parts) {
      const ty = pt.type;
      if (ty !== "bubble" && ty !== "bit" && ty !== "streak" && ty !== "glint") continue;
      const x = pt.x - camLeft,
        y = pt.y - camTop;
      if (x < -35 || x > vw + 35 || y < -35 || y > vh + 35) continue;
      const k = clamp(pt.life / pt.max, 0, 1);
      if (ty === "bubble") {
        const r = Math.max(1.4, pt.size * 1.35);
        ctx.drawImage(bub, x - r, y - r, r * 2, r * 2);
      } else if (ty === "bit") {
        const rad = pt.size * (0.8 + k * 0.8);
        ctx.globalAlpha = k;
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
        ctx.globalAlpha = 1;
      } else if (ty === "glint") {
        const rad = 2.4 * k + 0.4;
        ctx.drawImage(gold, x - rad, y - rad, rad * 2, rad * 2);
      } else {
        const d = Math.hypot(pt.vx, pt.vy) || 1;
        const len = 6 + k * 10;
        ctx.globalAlpha = k * 0.5;
        ctx.strokeStyle = "#d2fcff";
        ctx.lineWidth = 1.8 * k;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + (pt.vx / d) * len, y + (pt.vy / d) * len);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    ctx.globalCompositeOperation = "lighter";
    const mistOrb = glowOrb("#7dd3fc", true);
    for (const pt of parts) {
      const ty = pt.type;
      if (ty === "bubble" || ty === "bit" || ty === "streak" || ty === "glint") continue;
      const x = pt.x - camLeft,
        y = pt.y - camTop;
      if (x < -35 || x > vw + 35 || y < -35 || y > vh + 35) continue;
      const k = clamp(pt.life / pt.max, 0, 1);
      if (ty === "chomp") {
        // silky bite ripple: two crescents closing on each other
        const r = pt.size * (0.65 + (1 - k) * 0.48);
        const oy = r * (0.42 - (1 - k) * 0.45);
        const a0 = (pt.dir || 1) > 0 ? -0.5 : Math.PI - 0.5;
        ctx.globalAlpha = k * 0.75;
        ctx.strokeStyle = "rgba(224, 248, 255, 0.9)";
        ctx.lineWidth = 2.0 * k + 0.6;
        ctx.beginPath();
        ctx.arc(x, y - oy, r, a0, a0 + 1);
        ctx.moveTo(x + Math.cos(a0) * r, y + oy + Math.sin(a0) * r);
        ctx.arc(x, y + oy, r, a0, a0 + 1);
        ctx.stroke();
      } else if (ty === "suck") {
        const rad = pt.size * 2.0;
        ctx.globalAlpha = 1;
        ctx.drawImage(mistOrb, x - rad, y - rad, rad * 2, rad * 2);
      } else if (ty === "ring") {
        const r = pt.size * (0.9 + (1 - k) * 1.5);
        ctx.globalAlpha = k * 0.52;
        ctx.strokeStyle = pt.color;
        ctx.lineWidth = 2.2 * k;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        const rad = 3.8 * k + 1.2;
        ctx.globalAlpha = 1;
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
      }
    }
    // coins flying to the counter: all glows (still additive), then the coins themselves
    const coinGlow = glowOrb("rgba(255, 214, 80, 0.55)", false);
    const coinSc = (c: FlyCoin) => {
      // elastic pop-in, then the coin shrinks a little while it swoops into the counter
      const k = c.t / COIN_POP;
      return k < 0.45 ? 0.3 + k * 2.3 : k < 1 ? 1.34 - (k - 0.45) * 0.62 : 1 - Math.min(1, (c.t - COIN_POP) / COIN_FLY) * 0.3;
    };
    ctx.globalAlpha = 0.6;
    for (const c of this.flyCoins) {
      if (c.t < 0) continue;
      const sc = coinSc(c);
      ctx.drawImage(coinGlow, c.x - camLeft - 10 * sc, c.y - camTop - 10 * sc, 20 * sc, 20 * sc);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    for (const c of this.flyCoins) {
      if (c.t < 0) continue;
      const sc = coinSc(c);
      ctx.drawImage(coinSprite(Math.floor(c.t * 22)), c.x - camLeft - 5.5 * sc, c.y - camTop - 5.5 * sc, 11 * sc, 11 * sc);
    }

    // ---------- names, warnings & floating numbers: cached text sprites ----------
    for (const f of sorted) {
      if (f.eatenBy) continue;
      const x = f.x - camLeft,
        y = f.y - camTop - f.r * 1.15 - 8;
      if (x < -60 || x > vw + 60 || y < -25 || y > vh + 40) continue;
      if (f.kind !== "npc") {
        const col =
          f.kind === "player"
            ? "#ffffff"
            : p && !p.dead && f.r * EAT_RATIO > p.r
              ? "#ff9494"
              : p && !p.dead && f.r < p.r * EAT_RATIO
                ? "#a8ffbe"
                : "#e8f4ff";
        const L = this.label(f.name, col, 9);
        ctx.drawImage(L.cv, x - L.w / 2, y - L.h / 2, L.w, L.h);
        if (f.id === this.leaderId) this.drawCrown(x, y - 9);
      }
      if (p && !p.dead && f !== p && f.r * EAT_RATIO > p.r && p.invuln <= 0) {
        const d = Math.hypot(f.x - p.x, f.y - p.y);
        const hunting = f.ai.target === p || (f.kind === "bot" && d < 160);
        if (d < 200 && hunting && Math.floor(t * 6) % 2 === 0) {
          const L = this.label("!", "#ff3b4e", 11);
          ctx.drawImage(L.cv, x - L.w / 2, y - (f.kind === "npc" ? 0 : 11) - L.h / 2, L.w, L.h);
        }
      }
    }

    // slurp-chain counter riding next to the player: pops on every bite, with a draining combo timer
    if (p && !p.dead && !p.eatenBy && p.combo >= 2 && p.comboT > 0) {
      const kT = clamp(p.comboT / 2.6, 0, 1);
      const col = p.combo >= 10 ? "#ff7ad9" : p.combo >= 5 ? "#ffb347" : "#fff066";
      const L = this.label("x" + p.combo, col, 10 + Math.min(5, Math.round(p.combo * 0.22)));
      const sc = 1 + this.chainPop * 0.55;
      const cx = p.x - camLeft - p.face * (p.r * 0.9 + 13),
        cy = p.y - camTop - p.r * 1.15 - 22;
      ctx.globalAlpha = Math.min(1, kT * 5);
      ctx.drawImage(L.cv, cx - (L.w * sc) / 2, cy - (L.h * sc) / 2, L.w * sc, L.h * sc);
      ctx.fillStyle = "rgba(8, 22, 52, 0.75)";
      ctx.fillRect(cx - 8, cy + 7, 16, 2);
      ctx.fillStyle = col;
      ctx.fillRect(cx - 8, cy + 7, 16 * kT, 2);
      ctx.globalAlpha = 1;
    }

    for (const tx of this.texts) {
      const k = tx.life / tx.max;
      // squash-in pop: starts small, overshoots, settles
      const pop = k > 0.86 ? 0.5 + ((1 - k) / 0.14) * 0.78 : k > 0.72 ? 1.28 - ((0.86 - k) / 0.14) * 0.28 : 1;
      const L = this.label(tx.text, tx.color, tx.size + 2);
      ctx.globalAlpha = k < 0.3 ? k / 0.3 : 1;
      ctx.drawImage(L.cv, tx.x - camLeft - (L.w * pop) / 2, tx.y - camTop - (L.h * pop) / 2, L.w * pop, L.h * pop);
    }
    ctx.globalAlpha = 1;

    oc.drawLight(ctx, 1, camLeft, camTop, vw, vh, t); // light shafts falling in front of the reef and the fish
    // Layer 6 (1.24x): Foreground Parallax Coral, Crystal & Giant Kelp Silhouettes!
    oc.drawForegroundParallax(ctx, camLeft, camTop, vw, vh, t);
    oc.drawSurface(ctx, camLeft, camTop, vw, t);
    oc.drawVignette(ctx, camTop, vw, vh);

    // Depth-level gauge + zone title card
    if (focus && !focus.eatenBy) oc.drawHud(ctx, vw, vh, focus.y, t);
  }

  drawCrown(x: number, y: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.moveTo(-4.5, 2.5);
    ctx.lineTo(-5.2, -2.5);
    ctx.lineTo(-2, 0.2);
    ctx.lineTo(0, -3.5);
    ctx.lineTo(2, 0.2);
    ctx.lineTo(5.2, -2.5);
    ctx.lineTo(4.5, 2.5);
    ctx.closePath();
    ctx.fillStyle = "#ffd43b";
    ctx.fill();
    ctx.strokeStyle = "#4a2500";
    ctx.lineWidth = 1.2;
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
  }

  outlinedText(s: string, x: number, y: number, col: string, strokeW = 2.5) {
    const ctx = this.ctx;
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;
    ctx.strokeStyle = "rgba(8, 22, 52, 0.88)";
    ctx.lineWidth = strokeW;
    ctx.strokeText(s, x, y);
    ctx.fillStyle = col;
    ctx.fillText(s, x, y);
  }

  drawFish(f: Fish, camLeft: number, camTop: number) {
    const ctx = this.ctx;
    let x = f.x,
      y = f.y,
      sc = 1;
    let rot = f.tilt;
    let face = f.face;
    const spd = Math.hypot(f.vx, f.vy);
    let sx = 1 - f.sq * 0.48 + Math.min(0.08, spd * 0.0005) + (f.boosting ? 0.12 : 0);
    let sy = 1 + f.sq * 0.72 - Math.min(0.05, spd * 0.00035) - (f.boosting ? 0.06 : 0);

    if (f.jaw > 0.35 && !f.eatenBy) {
      sy += (f.jaw - 0.35) * 0.1;
      sx -= (f.jaw - 0.35) * 0.04;
    }

    if (f.sp.style === "puffer" && !f.eatenBy) {
      // the pufferfish balloons up while it vacuums and right after a gulp
      const pf = f.suckVis * 0.16 + Math.max(0, f.gulpT) * 0.06;
      sx *= 1 + pf * 0.5;
      sy *= 1 + pf;
    }

    if (f.eatenBy) {
      const e = f.eatenBy;
      const k = f.eatT * f.eatT;
      x = f.eatFromX + (e.mouthX() - f.eatFromX) * k;
      y = f.eatFromY + (e.mouthY() - f.eatFromY) * k;
      sc = 1 - f.eatT * 0.82;
      sx *= 1 + f.eatT * 0.55;
      sy *= 1 - f.eatT * 0.32;
      face = e.x > f.eatFromX ? -1 : 1;
      rot = 0;
    }

    const scrX = x - camLeft,
      scrY = y - camTop;
    const reach = f.r * 2.6;
    if (scrX < -reach || scrX > this.vw + reach || scrY < -reach || scrY > this.vh + reach) return;

    // Soft bioluminescent lure light pool for the anglerfish in deep water (pre-rendered glow)
    if (f.sp.lure && !f.eatenBy && f.y > DEEP_START - 200) {
      const lr = f.r * 2.6 + 18;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.7;
      ctx.drawImage(glowOrb("rgba(215, 255, 85, 0.5)", false), scrX + face * f.r * 1.15 - lr, scrY - f.r * 0.95 - lr, lr * 2, lr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    // lanternfish fry carry their own little light
    if (f.fry && f.sp.pal.lure && !f.eatenBy && f.id % 3 === 0) {
      // one shared glow for every third fish of the shoal (same look, a third of the blending)
      const gr = f.r * 5.2;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.55;
      ctx.drawImage(glowOrb("rgba(111, 240, 255, 0.5)", false), scrX - gr, scrY - gr, gr * 2, gr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    if (f.sucked > 0 && !f.eatenBy) {
      x += (Math.random() - 0.5) * 1.3;
      sx *= 1.12;
      sy *= 0.9;
    }

    let jawState: JawState = 0;
    if (f.eatenBy) jawState = 3;
    else if (f.chompT > 0.04) jawState = f.munch && Math.floor(f.chompT / 0.075) % 2 === 0 ? 1 : -1; // chew-chew-chew
    else if (f.jaw > 0.74) jawState = 3;
    else if (f.jaw > 0.42) jawState = 2;
    else if (f.jaw > 0.16) jawState = 1;

    let expr: EyeExpr = "normal";
    if (f.eatenBy || f.sucked > 0) expr = "panic";
    else if (f.chompT > 0.02) expr = "happy";

    const spr = fishSprite(f.sp, fishLen(f.r), jawState, f.tailPh, f.key, this.pixelMode, expr, f.kind === "player");

    // Soft dreamy shield aura when invulnerable (zero rings/lines, keeps fish body 100% solid & vibrant!)
    if (f.invuln > 0 && !f.eatenBy) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.35 + Math.sin(this.t * 8) * 0.15;
      const hr = f.r * 2.1;
      ctx.drawImage(glowOrb("rgba(190, 248, 255, 0.5)", false), x - camLeft - hr, y - camTop - hr, hr * 2, hr * 2);
      ctx.restore();
    }

    const flipX = f.eatenBy ? face : Math.abs(f.turnFlip) < 0.22 ? (f.turnFlip >= 0 ? 0.22 : -0.22) : f.turnFlip;
    ctx.globalAlpha = 1;
    // idle fish hover gently instead of hanging frozen in the water
    const swim = Math.min(1, spd / 110);
    const hover = f.eatenBy ? 0 : (1 - swim) * Math.sin(this.t * 1.7 + f.id * 1.3) * Math.min(1.2, f.r * 0.06);
    // one setTransform instead of save / translate / scale / rotate / scale / restore
    const S0 = this.pxs(),
      co = Math.cos(rot),
      si = Math.sin(rot),
      kx = sx * sc,
      ky = sy * sc;
    ctx.setTransform(S0 * flipX * co * kx, S0 * si * kx, -S0 * flipX * si * ky, S0 * co * ky, S0 * (x - camLeft), S0 * (y - camTop + hover));

    // LIVING BODY WAVE: the sprite is drawn as vertical slices riding a sine wave that travels from
    // head to tail (head almost steady, tail swinging widest, stronger the faster the fish swims).
    // The hinged tail fin baked into the sprite frames follows through a quarter beat later.
    const amp = f.eatenBy || this.pixelMode ? 0 : spr.h * (0.014 + swim * 0.03) * (f.sp.style === "orca" ? 1.35 : 1);
    const devPx = this.zoom * this.dpr;
    // a swallowed bite travels from the throat toward the belly as a bulge (finer slices keep it smooth)
    const gulp = f.gulpT > 0 && !f.eatenBy && !this.pixelMode;
    const gulpPos = 0.14 + (1 - f.gulpT) * 0.5;
    const gulpAmt = gulp ? f.gulpK * Math.min(1, f.gulpT * 4) : 0;
    const nSl = Math.min(gulp ? 22 : f.kind === "player" ? 14 : 9, Math.round((spr.w * devPx) / (gulp ? 7 : 13)));
    if (nSl < 6 || (!gulp && amp * devPx < 0.35)) {
      ctx.drawImage(spr.canvas, -spr.w / 2, -spr.h / 2, spr.w, spr.h);
    } else {
      const cvs = spr.canvas,
        SW = cvs.width,
        SH = cvs.height,
        dw = spr.w / nSl,
        ssw = SW / nSl;
      for (let i = 0; i < nSl; i++) {
        const back = 1 - (i + 0.5) / nSl; // 0 = snout ... 1 = tail tip
        const off = Math.sin(f.tailPh - back * 2.4) * amp * (0.1 + back * back * 1.25);
        const sW = Math.min(ssw + 1, SW - i * ssw); // 1px overlap hides the seams between slices
        const g = (back - gulpPos) / 0.21;
        const hs = 1 + gulpAmt * Math.exp(-g * g);
        ctx.drawImage(cvs, i * ssw, 0, sW, SH, -spr.w / 2 + i * dw, (-spr.h / 2) * hs + off, (sW * dw) / ssw, spr.h * hs);
      }
    }
    ctx.setTransform(S0, 0, 0, S0, 0, 0);

    if (f.kind === "player" && !f.eatenBy && f.r < 14) {
      const yy = y - camTop - f.r * 1.18 - 16 + Math.sin(this.t * 6) * 2;
      const xx = x - camLeft;
      ctx.save();
      ctx.fillStyle = "#ffe14a";
      ctx.strokeStyle = "rgba(8, 22, 52, 0.8)";
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(xx - 3.2, yy - 2);
      ctx.lineTo(xx + 3.2, yy - 2);
      ctx.lineTo(xx, yy + 2.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  }
}
