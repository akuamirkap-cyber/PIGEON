import { useEffect, useMemo, useState } from "react";
import { SKINS, skinToSpecies } from "../game/species";
import { spriteDataURL, coinSprite } from "../game/sprites";
import type { JawState } from "../game/sprites";
import type { SaveData } from "../save";
import { UPGRADE_COSTS, MAX_UPGRADE } from "../save";
import type { Upgrades } from "../game/engine";

interface Props {
  save: SaveData;
  setSave: (s: SaveData) => void;
  onPlay: () => void;
  loading?: boolean;
  loadPct?: number;
}

const UPGRADES: { id: keyof Upgrades; name: string; desc: string; icon: string }[] = [
  { id: "suck", name: "Sedotan Super", desc: "Jangkauan & kekuatan sedot lebih mantap", icon: "🌀" },
  { id: "speed", name: "Sirip Turbo", desc: "Berenang & belok lebih lincah", icon: "💨" },
  { id: "size", name: "Ikan Bongsor", desc: "Mulai sedikit lebih besar", icon: "🍔" },
];

export function coinURL() {
  return coinSprite(0).toDataURL();
}

const THUMBS: Record<string, string> = {}; // skin thumbnails, generated once
const PREVIEW_CYCLE: JawState[] = [0, 0, 0, 1, 2, 3, 3, -1, -1, 0, 0];

export default function Menu({ save, setSave, onPlay, loading = false, loadPct = 0 }: Props) {
  const [tab, setTab] = useState<"skin" | "shop">("skin");
  const [animStep, setAnimStep] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setAnimStep((s) => (s + 1) % PREVIEW_CYCLE.length), 210);
    return () => clearInterval(id);
  }, []);

  // Thumbnails are drawn two per frame AFTER the menu has appeared (and cached across visits),
  // instead of rendering all of them before the first paint.
  const [skinImgs, setSkinImgs] = useState<Record<string, string>>(() => ({ ...THUMBS }));
  useEffect(() => {
    let alive = true;
    let id = 0;
    const tick = () => {
      if (!alive) return;
      let n = 0;
      for (const s of SKINS) {
        if (THUMBS[s.id]) continue;
        THUMBS[s.id] = spriteDataURL(skinToSpecies(s), 190, 0);
        if (++n >= 2) break;
      }
      if (n > 0) {
        setSkinImgs({ ...THUMBS });
        id = requestAnimationFrame(tick);
      }
    };
    id = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(id);
    };
  }, []);

  const cur = SKINS.find((s) => s.id === save.skin) || SKINS[0];
  const heroFrames = useMemo(() => {
    const sp = skinToSpecies(cur);
    const states: JawState[] = [-1, 0, 1, 2, 3];
    return Object.fromEntries(states.map((st) => [st, spriteDataURL(sp, 240, st)])) as Record<JawState, string>;
  }, [cur]);

  const coin = useMemo(() => coinURL(), []);

  // every fish is unlocked: picking one simply equips it
  const pickSkin = (id: string) => setSave({ ...save, skin: id });

  const buyUp = (id: keyof Upgrades) => {
    const lv = save.upgrades[id];
    if (lv >= MAX_UPGRADE) return;
    const cost = UPGRADE_COSTS[lv];
    if (save.coins < cost) return;
    setSave({ ...save, coins: save.coins - cost, upgrades: { ...save.upgrades, [id]: lv + 1 } });
  };

  const curJaw = PREVIEW_CYCLE[animStep];

  return (
    <div
      className="absolute inset-0 flex overflow-y-auto p-3 clean-font"
      style={{ background: "radial-gradient(ellipse at center, rgba(8,30,68,0.22), rgba(4,14,38,0.72))" }}
    >
      <div className="m-auto w-full max-w-[1060px] flex flex-col items-center gap-3.5 py-3">
        {/* Artistic Fish.io Animated Header */}
        <div className="relative text-center select-none flex flex-col items-center">
          {/* Ambient Rising Bubbles */}
          <div className="pointer-events-none absolute -top-4 -left-8 w-5 h-5 rounded-full border-2 border-cyan-300/60 bg-cyan-400/20 bubble-float-1" />
          <div className="pointer-events-none absolute -top-8 right-6 w-7 h-7 rounded-full border-2 border-cyan-200/70 bg-cyan-300/25 bubble-float-2" />
          <div className="pointer-events-none absolute top-2 right-1/4 w-4 h-4 rounded-full border border-cyan-200/50 bg-cyan-400/15 bubble-float-3" />

          {/* Main Animated Title: Fish.io */}
          <div className="fish-title-wave relative inline-flex items-center justify-center gap-1.5 sm:gap-2.5">
            <h1 className="title-outline font-extrabold text-[58px] sm:text-[84px] md:text-[98px] leading-none tracking-tight fish-title-shine drop-shadow-[0_8px_16px_rgba(0,0,0,0.7)]">
              Fish<span className="text-[#5ce4ff] drop-shadow-[0_4px_12px_rgba(30,220,255,0.8)]">.io</span>
            </h1>

            {/* Cute Swimming Mascot Icon Wiggling beside .io */}
            <div className="mascot-wiggle relative -mt-3 sm:-mt-5">
              <span className="text-[34px] sm:text-[48px] filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.6)]">
                🐠
              </span>
              <span className="absolute -top-1 -right-1 text-[16px] sm:text-[22px] animate-spin" style={{ animationDuration: "6s" }}>
                ✨
              </span>
            </div>
          </div>

          {/* Carved Nautical Wooden Ribbon Subtitle Badge */}
          <div className="badge-glow -mt-2 sm:-mt-3 relative z-10 px-4 sm:px-6 py-1 sm:py-1.5 rounded-full bg-gradient-to-r from-[#2c1608] via-[#4d2810] to-[#2c1608] border-2 border-[#d49646] shadow-lg flex items-center gap-2">
            <span className="text-amber-400 text-[12px] sm:text-[14px]">⚓</span>
            <span className="text-outline font-bold text-[12px] sm:text-[14.5px] tracking-wider text-amber-200 uppercase">
              TROPICAL REEF • FEEDING FRENZY EDITION
            </span>
            <span className="text-amber-400 text-[12px] sm:text-[14px]">⚓</span>
          </div>

          {/* Slogan & Gameplay Tip */}
          <div className="text-outline font-semibold text-[12px] sm:text-[14.5px] mt-2.5 text-cyan-100 max-w-[620px] leading-snug">
            🌀 Sedot gerombolan ikan kecil untuk <span className="text-yellow-300 font-bold">COMBO</span> beruntun &amp; hujan koin — habiskan kawanan untuk bonus <span className="text-emerald-300 font-bold">SAPU BERSIH!</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 w-full items-stretch">
          {/* Left: Live Animated Hero Preview & Play */}
          <div className="artistic-wood-board relative p-5 flex-1 flex flex-col items-center justify-between gap-3 shadow-2xl">
            {/* Nautical Brass Screws in corners */}
            <div className="absolute top-2 left-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute top-2 right-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2 left-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2 right-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>

            <div className="flex flex-col items-center">
              <div className="relative">
                {/* Soft ambient aura behind selected fish */}
                <div className="absolute inset-0 bg-yellow-400/20 blur-xl rounded-full" />
                <img
                  src={heroFrames[curJaw]}
                  className="bob relative z-10 h-32 object-contain drop-shadow-[0_8px_14px_rgba(0,0,0,0.6)]"
                  alt={cur.name}
                />
              </div>
              <div className="text-[17px] font-extrabold text-amber-100 text-outline -mt-1 flex items-center gap-1.5">
                <span>{cur.name}</span>
                <span className="text-yellow-300 text-[13px] font-bold">({cur.subtitle})</span>
              </div>
            </div>

            <input
              value={save.name}
              maxLength={14}
              onChange={(e) => setSave({ ...save, name: e.target.value })}
              onKeyDown={(e) => {
                if (e.key === "Enter") onPlay();
              }}
              placeholder="Nama ikanmu..."
              className="w-full font-bold text-[16px] text-center py-2.5 px-4 rounded-xl bg-[#221206] text-amber-100 border-2 border-[#683b16] outline-none focus:border-yellow-300 placeholder:text-amber-200/40 shadow-inner"
            />
            <button
              onClick={onPlay}
              disabled={loading}
              className={`ui-btn relative overflow-hidden w-full py-3.5 text-[23px] text-white tracking-wide ${loading ? "" : "play-btn-pulse"}`}
              style={{
                background: loading ? "linear-gradient(180deg, #3f6b52, #2a4a39)" : "linear-gradient(180deg, #4be880, #1ba248)",
                cursor: loading ? "progress" : "pointer",
              }}
            >
              {loading && (
                <span
                  className="absolute inset-y-0 left-0"
                  style={{ width: `${Math.round(loadPct * 100)}%`, background: "linear-gradient(180deg, #45e078, #1fa84d)", opacity: 0.85 }}
                />
              )}
              <span className="relative drop-shadow-[0_2px_4px_rgba(0,0,0,0.7)] font-extrabold">{loading ? `⏳ Menyiapkan lautan… ${Math.round(loadPct * 100)}%` : "▶ MAIN SEKARANG!"}</span>
            </button>
            <div className="text-[12.5px] leading-relaxed text-amber-50 text-center font-medium bg-[#2b1708]/65 rounded-xl px-3 py-2 w-full border border-[#593418]">
              🖱️ Gerak ikan super mulus, lembut &amp; responsif mengikuti kursor!
              <br />
              <span className="text-yellow-300 font-bold">KLIK KIRI / SPASI</span> = <b>SEDOT</b> 🌀 •{" "}
              <span className="text-orange-300 font-bold">KLIK KANAN / SHIFT</span> = <b>BOOST</b> ⚡
              <br />
              Makan beruntun menyalakan papan <span className="text-yellow-200 font-bold">FRENZY!</span>
            </div>
            {save.best > 0 && (
              <div className="text-[14px] font-bold text-yellow-200 text-outline">
                🏆 Skor Rekor: {save.best.toLocaleString("en-US")}
              </div>
            )}
          </div>

          {/* Right: Feeding Frenzy Cast Skins & Upgrades */}
          <div className="artistic-wood-board relative p-4 sm:p-5 flex-[1.48] flex flex-col gap-3 shadow-2xl">
            {/* Nautical Brass Screws in corners */}
            <div className="absolute top-2 left-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute top-2 right-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2 left-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2 right-2 w-3 h-3 rounded-full bg-[#d4a046] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>

            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <button
                  onClick={() => setTab("skin")}
                  className="ui-btn px-4 py-1.5 text-[15px] text-white"
                  style={{ background: tab === "skin" ? "linear-gradient(180deg, #ff9938, #d95b12)" : "#4d2c14" }}
                >
                  🐠 IKAN FRENZY
                </button>
                <button
                  onClick={() => setTab("shop")}
                  className="ui-btn px-4 py-1.5 text-[15px] text-white"
                  style={{ background: tab === "shop" ? "linear-gradient(180deg, #ff9938, #d95b12)" : "#4d2c14" }}
                >
                  ⚡ UPGRADE
                </button>
              </div>
              <div className="ff-carved-slot px-3 py-1 flex items-center gap-1.5 text-[18px] font-bold text-yellow-200">
                <img src={coin} className="w-6 h-6" alt="" />
                {save.coins}
              </div>
            </div>

            {tab === "skin" ? (
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                <div className="col-span-full text-center text-[12px] font-bold text-emerald-200 text-outline -mb-0.5">
                  ✅ Semua {SKINS.length} ikan sudah terbuka — tinggal pilih &amp; main!
                </div>
                {SKINS.map((s) => {
                  const owned = true;
                  const sel = save.skin === s.id;
                  const afford = true;
                  return (
                    <button
                      key={s.id}
                      onClick={() => pickSkin(s.id)}
                      className="ui-btn px-2 py-1.5 flex flex-col items-center"
                      style={{
                        background: sel
                          ? "linear-gradient(180deg, #ffe359, #eb9f12)"
                          : owned
                            ? "linear-gradient(180deg, #5c371b, #3d220e)"
                            : "#2b180a",
                        opacity: owned || afford ? 1 : 0.7,
                      }}
                    >
                      {skinImgs[s.id] ? <img src={skinImgs[s.id]} className="h-12 object-contain drop-shadow" alt={s.name} /> : <div className="h-12" />}
                      <div className={`text-[13px] font-bold leading-tight ${sel ? "text-[#2b1504]" : "text-amber-50"}`}>{s.name}</div>
                      <div className={`text-[10px] leading-tight ${sel ? "text-[#4d2808]" : "text-amber-200/80"}`}>{s.subtitle}</div>
                      <div className={`text-[11px] font-bold mt-0.5 ${sel ? "text-[#3b1e00]" : "text-yellow-300"}`}>
                        {sel ? "✓ DIPAKAI" : owned ? "PAKAI" : `🪙 ${s.price}`}
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {UPGRADES.map((u) => {
                  const lv = save.upgrades[u.id];
                  const max = lv >= MAX_UPGRADE;
                  const cost = max ? 0 : UPGRADE_COSTS[lv];
                  return (
                    <div key={u.id} className="flex items-center gap-3 bg-[#2b180a]/85 border-2 border-[#5c3618] rounded-xl p-3">
                      <div className="text-[28px]">{u.icon}</div>
                      <div className="flex-1">
                        <div className="text-[15px] font-bold text-amber-50">{u.name}</div>
                        <div className="text-[12px] text-amber-200/85">{u.desc}</div>
                        <div className="flex gap-1.5 mt-1.5">
                          {Array.from({ length: MAX_UPGRADE }).map((_, i) => (
                            <div
                              key={i}
                              className="w-6 h-3 rounded-sm border border-[#1a0d04]"
                              style={{ background: i < lv ? "#eff52c" : "#422712" }}
                            />
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() => buyUp(u.id)}
                        disabled={max || save.coins < cost}
                        className="ui-btn px-4 py-2 text-[14px] text-white disabled:opacity-50"
                        style={{ background: max ? "#5c534a" : "linear-gradient(180deg, #ff9938, #d95b12)" }}
                      >
                        {max ? "MAX" : `🪙 ${cost}`}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
