import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Game } from "./game/engine";
import type { HudState, DeathInfo, GameEvent } from "./game/engine";
import { sfx } from "./game/audio";
import { SPECIES, SKINS } from "./game/species";
import { spriteDataURL } from "./game/sprites";
import Menu, { coinURL } from "./components/Menu";
import TopWoodBar from "./components/TopWoodBar";
import { loadSave, writeSave } from "./save";
import type { SaveData } from "./save";

type Screen = "menu" | "play" | "dead";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const [save, setSaveState] = useState<SaveData>(() => loadSave());
  const saveRef = useRef(save);
  const [hud, setHud] = useState<HudState | null>(null);
  const [death, setDeath] = useState<DeathInfo | null>(null);
  const [banner, setBanner] = useState<{ text: string; sub?: string; color: string; key: number } | null>(null);
  const [combo, setCombo] = useState<{ n: number; key: number } | null>(null);
  const [feed, setFeed] = useState<{ text: string; id: number }[]>([]);
  const [coinBump, setCoinBump] = useState(0);
  const [muted, setMuted] = useState(false);
  const [pixelMode, setPixelMode] = useState(false);
  const [load, setLoad] = useState({ pct: 0, ready: false });
  const [suckBtn, setSuckBtn] = useState(false);
  const [boostBtn, setBoostBtn] = useState(false);
  const isTouch = useMemo(() => typeof window !== "undefined" && "ontouchstart" in window, []);
  const screenRef = useRef(screen);
  screenRef.current = screen;

  const setSave = (s: SaveData) => {
    saveRef.current = s;
    setSaveState(s);
    writeSave(s);
  };

  const coin = useMemo(() => coinURL(), []);
  // HUD icons are only needed in-game, so they are drawn once the ocean is ready (not before first paint)
  const icons = useMemo(() => (load.ready ? SPECIES.map((s) => spriteDataURL(s, 115)) : []), [load.ready]);

  useEffect(() => {
    const g = new Game(canvasRef.current!);
    gameRef.current = g;
    g.minimap = miniRef.current;
    g.onHud = (h) => setHud(h);
    g.onLoad = (pct, ready) => setLoad({ pct, ready });
    g.onEvent = (e: GameEvent) => {
      if (e.type === "coinbump") setCoinBump((k) => k + 1);
      else if (e.type === "combo") setCombo({ n: e.n, key: Date.now() });
      else if (e.type === "frenzy") {
        const t = e.n >= 22 ? "MEGA FRENZY!!" : e.n >= 14 ? "DOUBLE FRENZY!" : "FEEDING FRENZY!";
        setBanner({ text: t, sub: e.n >= 14 ? "Skor & Koin x3!" : "Skor & Koin x2!", color: e.n >= 14 ? "#ff6ad8" : "#ffe047", key: Date.now() });
      } else if (e.type === "levelup") setBanner({ text: "GROWTH UP!", sub: e.text, color: "#f6ff54", key: Date.now() });
      else if (e.type === "bonus") setBanner({ text: e.title, sub: e.text, color: "#7dffb0", key: Date.now() });
      else if (e.type === "feed") {
        const id = Date.now() + Math.random();
        setFeed((f) => [...f.slice(-3), { text: e.text, id }]);
        setTimeout(() => setFeed((f) => f.filter((x) => x.id !== id)), 4000);
      }
    };
    g.onDeath = (d) => {
      const s = saveRef.current;
      setSave({ ...s, coins: s.coins + d.coins, best: Math.max(s.best, d.score) });
      setDeath(d);
      setScreen("dead");
    };
    const onMove = (e: MouseEvent) => {
      g.mouse.x = e.clientX;
      g.mouse.y = e.clientY;
      g.mouse.active = true;
    };
    const onDown = (e: MouseEvent) => {
      sfx.init();
      if (screenRef.current !== "play" || (e.target as HTMLElement).tagName !== "CANVAS") return;
      if (e.button === 0) g.setSuck(true);
      if (e.button === 2) g.setBoost(true);
    };
    const onUp = (e: MouseEvent) => {
      if (e.button === 0) g.setSuck(false);
      if (e.button === 2) g.setBoost(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (screenRef.current !== "play") return;
      if (e.code === "Space") {
        e.preventDefault();
        g.setSuck(e.type === "keydown");
      } else if (e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyW") {
        e.preventDefault();
        g.setBoost(e.type === "keydown");
      } else if (e.code === "Escape" && e.type === "keydown") {
        returnToMenu();
      }
    };
    const onBlur = () => {
      g.setSuck(false);
      g.setBoost(false);
    };
    const onTouch = (e: TouchEvent) => {
      sfx.init();
      const t = e.touches[0];
      if (t && (e.target as HTMLElement).tagName === "CANVAS") {
        g.mouse.x = t.clientX;
        g.mouse.y = t.clientY;
        g.mouse.active = true;
      }
    };
    const onCtx = (e: Event) => e.preventDefault();
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup", onUp);
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKey);
    window.addEventListener("touchstart", onTouch, { passive: true });
    window.addEventListener("touchmove", onTouch, { passive: true });
    window.addEventListener("contextmenu", onCtx);
    window.addEventListener("blur", onBlur);
    return () => {
      g.destroy();
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup", onUp);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKey);
      window.removeEventListener("touchstart", onTouch);
      window.removeEventListener("touchmove", onTouch);
      window.removeEventListener("contextmenu", onCtx);
      window.removeEventListener("blur", onBlur);
    };
  }, []);

  useEffect(() => {
    if (!banner) return;
    const id = setTimeout(() => setBanner(null), 1800);
    return () => clearTimeout(id);
  }, [banner]);
  useEffect(() => {
    if (!combo) return;
    const id = setTimeout(() => setCombo(null), 1100);
    return () => clearTimeout(id);
  }, [combo]);

  const play = () => {
    sfx.init();
    const g = gameRef.current;
    if (!g || !g.ready) return; // the ocean is still being generated
    const s = saveRef.current;
    const skin = SKINS.find((k) => k.id === s.skin) || SKINS[0];
    g.start({
      name: s.name.trim() || "Kamu",
      skin,
      upgrades: s.upgrades,
    });
    setDeath(null);
    setScreen("play");
  };

  const returnToMenu = () => {
    const g = gameRef.current;
    if (g && g.player && !g.player.dead) {
      let earned = g.sessionCoins;
      for (const c of g.flyCoins) earned += c.value;
      g.flyCoins = [];
      g.sessionCoins = 0;
      g.player.dead = true;
      sfx.setSuck(false);
      const s = saveRef.current;
      setSave({ ...s, coins: s.coins + earned, best: Math.max(s.best, g.arcadeScore) });
    }
    setScreen("menu");
  };

  const handleCoinBoxPos = useCallback((x: number, y: number) => {
    if (gameRef.current) {
      gameRef.current.coinHudPos = { x, y };
    }
  }, []);

  const toggleMute = () => {
    sfx.init();
    sfx.setMuted(!muted);
    setMuted(!muted);
  };

  const togglePixel = () => {
    const next = !pixelMode;
    setPixelMode(next);
    gameRef.current?.setPixelMode(next);
  };

  const showHud = screen === "play" && hud;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0b234a] clean-font">
      <canvas
        ref={canvasRef}
        className={`absolute inset-0 w-full h-full ${pixelMode ? "pixel" : ""}`}
        style={{
          cursor:
            screen === "play"
              ? `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16'%3E%3Ccircle cx='8' cy='8' r='3' fill='rgba(255,255,255,0.55)' stroke='rgba(8,30,68,0.45)' stroke-width='1'/%3E%3C/svg%3E") 8 8, crosshair`
              : "default",
        }}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: "radial-gradient(ellipse at center, transparent 58%, rgba(4,12,35,0.46) 100%)" }}
      />

      {/* ============ 100% AUTHENTIC FEEDING FRENZY TOP WOODEN PLANK BAR ============ */}
      {showHud && (
        <TopWoodBar
          hud={hud}
          icons={icons}
          coinImg={coin}
          coinBump={coinBump}
          onMenu={returnToMenu}
          onCoinBoxPos={handleCoinBoxPos}
        />
      )}

      {/* Compact Wood-Themed .io Leaderboard & Feed tucked cleanly below top bar */}
      <div className={`pointer-events-none absolute inset-0 transition-opacity duration-300 ${showHud ? "opacity-100" : "opacity-0"}`}>
        {/* Combo pop below top wood plank */}
        {combo && hud && hud.combo >= 3 && (
          <div
            key={combo.key}
            className="absolute left-1/2 -translate-x-1/2 top-[108px] pop title-outline font-bold text-[25px]"
            style={{ color: "#fff066" }}
          >
            COMBO x{combo.n}!
          </div>
        )}

        {/* Compact translucent wood leaderboard */}
        <div className="hidden md:block absolute right-3 top-[94px] bg-[#261508]/85 border-2 border-[#6e421f] rounded-xl px-3 py-2 w-[186px] shadow-lg">
          <div className="text-[11.5px] font-bold text-amber-300 mb-1 text-center tracking-wide">🏆 TOP LAUTAN (.IO)</div>
          {hud?.leaderboard.map((r, i) => (
            <div
              key={i}
              className={`flex justify-between items-center text-[12px] leading-5 font-semibold ${r.me ? "text-yellow-200 font-bold" : "text-amber-50/90"}`}
            >
              <span className="truncate max-w-[125px] flex items-center gap-1.5">
                <span className="inline-block w-2 h-2 rounded-full border border-black/50" style={{ background: r.color }} />
                {i + 1}. {r.name}
              </span>
              <span>{r.score}</span>
            </div>
          ))}
        </div>

        {/* Kill feed */}
        <div className="absolute left-3 top-[94px] flex flex-col items-start gap-1">
          {feed.map((f) => (
            <div key={f.id} className="text-[11.5px] font-semibold text-amber-50 bg-[#261508]/80 px-2.5 py-0.5 rounded-full border border-[#784922]">
              🍴 {f.text}
            </div>
          ))}
        </div>
      </div>

      {/* Minimap in matching dark carved wood frame */}
      <div className={`pointer-events-none absolute right-3 bottom-3 bg-[#361e0c]/90 border-2 border-[#784922] rounded-xl p-1 shadow-lg ${showHud ? "" : "hidden"}`}>
        <canvas ref={miniRef} width={186} height={58} className="block w-[186px] h-[58px] rounded-lg" />
      </div>

      {/* Mobile touch buttons */}
      {showHud && isTouch && (
        <>
          <button
            className="absolute right-6 bottom-24 w-24 h-24 rounded-full ui-btn text-white text-[15px]"
            style={{ background: suckBtn ? "#228be6" : "#3bc9db" }}
            onTouchStart={(e) => {
              e.stopPropagation();
              setSuckBtn(true);
              gameRef.current?.setSuck(true);
            }}
            onTouchEnd={() => {
              setSuckBtn(false);
              gameRef.current?.setSuck(false);
            }}
          >
            🌀 SEDOT
          </button>
          <button
            className="absolute right-32 bottom-20 w-20 h-20 rounded-full ui-btn text-white text-[14px]"
            style={{ background: boostBtn ? "#d9480f" : "#ff922b" }}
            onTouchStart={(e) => {
              e.stopPropagation();
              setBoostBtn(true);
              gameRef.current?.setBoost(true);
            }}
            onTouchEnd={() => {
              setBoostBtn(false);
              gameRef.current?.setBoost(false);
            }}
          >
            ⚡ BOOST
          </button>
        </>
      )}

      {/* Frenzy / Growth Up Banner */}
      {banner && screen === "play" && (
        <div key={banner.key} className="pointer-events-none absolute inset-x-0 top-[28%] flex flex-col items-center pop z-20">
          <div className="title-outline font-bold text-[34px] sm:text-[52px]" style={{ color: banner.color }}>
            {banner.text}
          </div>
          {banner.sub && <div className="text-outline font-bold text-[17px] sm:text-[22px] text-white mt-1">{banner.sub}</div>}
        </div>
      )}

      {/* Bottom-left compact Sound & 2D Clean / Pixel mode toggle */}
      <div className="absolute left-3 bottom-3 flex items-center gap-2 z-20">
        <button onClick={toggleMute} className="ui-btn px-3 py-1.5 text-[14px] text-white" style={{ background: "#4d2c14" }} title="Suara">
          {muted ? "🔇" : "🔊"}
        </button>
        <button
          onClick={togglePixel}
          className="ui-btn px-3 py-1.5 text-[12.5px] text-white"
          style={{ background: pixelMode ? "#7048e8" : "#6e401d" }}
          title="Ganti gaya grafis"
        >
          {pixelMode ? "👾 Mode Pixel" : "✨ 2D Clean"}
        </button>
      </div>

      {screen === "menu" && <Menu save={save} setSave={setSave} onPlay={play} loading={!load.ready} loadPct={load.pct} />}

      {screen === "dead" && death && (
        <div className="absolute inset-0 flex items-center justify-center p-4 z-30" style={{ background: "radial-gradient(ellipse at center, rgba(8,24,56,0.72), rgba(3,10,26,0.92))" }}>
          <div className="artistic-wood-board relative p-6 w-full max-w-[440px] flex flex-col items-center gap-4 pop shadow-2xl">
            {/* Corner Brass Rivets */}
            <div className="absolute top-2.5 left-2.5 w-3.5 h-3.5 rounded-full bg-[#e2aa4a] border border-[#3b1c04] shadow flex items-center justify-center text-[8px] text-[#4d2808]">✕</div>
            <div className="absolute top-2.5 right-2.5 w-3.5 h-3.5 rounded-full bg-[#e2aa4a] border border-[#3b1c04] shadow flex items-center justify-center text-[8px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2.5 left-2.5 w-3.5 h-3.5 rounded-full bg-[#e2aa4a] border border-[#3b1c04] shadow flex items-center justify-center text-[8px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2.5 right-2.5 w-3.5 h-3.5 rounded-full bg-[#e2aa4a] border border-[#3b1c04] shadow flex items-center justify-center text-[8px] text-[#4d2808]">✕</div>

            <div className="title-outline font-extrabold text-[38px] text-red-400 drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)] tracking-wide">
              DIMAKAN! 😵
            </div>
            <div className="text-[16px] font-bold text-amber-100 text-center text-outline -mt-1">
              Kamu disantap oleh <span className="text-yellow-300 font-extrabold text-[17px]">{death.killer}</span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 w-full text-[13px] font-bold text-amber-100">
              <div className="artistic-inset p-3">
                <span className="text-amber-200/90 text-[12px]">🎯 Skor Akhir</span>
                <div className="text-yellow-300 font-extrabold text-[22px] mt-0.5">{death.score.toLocaleString("en-US")}</div>
              </div>
              <div className="artistic-inset p-3">
                <span className="text-amber-200/90 text-[12px]">🐟 Ikan Dimakan</span>
                <div className="text-cyan-300 font-extrabold text-[22px] mt-0.5">{death.eaten}</div>
              </div>
              <div className="artistic-inset p-3">
                <span className="text-amber-200/90 text-[12px]">⏱️ Waktu Hidup</span>
                <div className="text-cyan-300 font-extrabold text-[22px] mt-0.5">{death.time}s</div>
              </div>
              <div className="artistic-inset p-3">
                <span className="text-amber-200/90 text-[12px]">🏆 Skor Rekor</span>
                <div className="text-yellow-300 font-extrabold text-[22px] mt-0.5">{save.best.toLocaleString("en-US")}</div>
              </div>
            </div>

            <div className="ff-carved-slot px-5 py-2 flex items-center gap-2 text-yellow-300 font-extrabold text-[24px]">
              +<img src={coin} className="w-8 h-8 drop-shadow" alt="" />
              {death.coins}
            </div>

            <div className="flex gap-3 w-full mt-1">
              <button
                onClick={play}
                className="ui-btn flex-1 py-3 text-[19px] text-white play-btn-pulse"
                style={{ background: "linear-gradient(180deg, #4be880, #1ba248)" }}
              >
                ▶ MAIN LAGI
              </button>
              <button
                onClick={() => setScreen("menu")}
                className="ui-btn flex-1 py-3 text-[18px] text-white"
                style={{ background: "linear-gradient(180deg, #ff9938, #d95b12)" }}
              >
                🐠 MENU &amp; IKAN
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
