import OriginalApp from '../original/OriginalApp';
import css from '../original/original.css?inline';
import type { PracticeStyle } from '../data';

export default function OriginalScreen({ initialGame, onPractice }: { initialGame: 'v1' | 'v2'; onPractice: (style?: PracticeStyle) => void }) {
  return (
    <>
      <style>{css}</style>
      <OriginalApp initialGame={initialGame} onPractice={onPractice} />
    </>
  );
}
