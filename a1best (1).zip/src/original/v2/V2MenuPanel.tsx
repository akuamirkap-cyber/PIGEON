import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';

export default function V2MenuPanel({ title, onClose, children }: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const el = dialog.current;
    el?.showModal();
    return () => el?.close();
  }, []);

  return (
    <dialog ref={dialog} className="v2-menu-dialog" aria-labelledby="v2-menu-dialog-title"
      onCancel={(event) => { event.preventDefault(); onClose(); }}
      onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <div className="of-panel pixel">
        <header className="v2-menu-dialog-head">
          <h2 id="v2-menu-dialog-title" className="of-panel__head">{title}</h2>
          <button className="of-icon" type="button" aria-label="Tutup panel" onClick={onClose}><X size={14} /></button>
        </header>
        {children}
      </div>
    </dialog>
  );
}