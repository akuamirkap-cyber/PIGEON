import type { Move } from './moves';
import { clamp } from './rng';

export type FootSchool = 'capoeira' | 'taekwondo' | 'lotus' | 'ember' | 'flamingo';

export const FOOT_SCHOOLS = {
  capoeira: { label: 'CAPOEIRA', color: '#79eec6', light: '#dcfff0' },
  taekwondo: { label: 'TAEKWONDO', color: '#83daff', light: '#edfbff' },
  lotus: { label: 'LOTUS', color: '#c1b1ff', light: '#f1e9ff' },
  ember: { label: 'BLACK LEG', color: '#ff9e55', light: '#fff0aa' },
  flamingo: { label: 'FLAMINGO', color: '#ffa568', light: '#fff2cb' },
} satisfies Record<FootSchool, { label: string; color: string; light: string }>;

export type FootLeg = 'ffoot' | 'bfoot';
export type FootBeat = { from: number; to: number; leg: FootLeg; power?: number; structure?: number; push?: number; stop?: number };

export interface FootMove extends Move {
  foot: { school: FootSchool; window: [number, number]; both?: boolean; beats?: readonly FootBeat[] };
}

function kick(id: string, name: string, pose: Move['pose'], school: FootSchool, options: Partial<Move> & {
  window?: [number, number]; both?: boolean; beats?: readonly FootBeat[];
} = {}): FootMove {
  const { window = [0.26, 0.86], both, beats, ...move } = options;
  return {
    id: `foot_${id}`, name, pose, kick: true, trail: false, limb: 'ffoot', sfx: 'kick',
    dmg: 3.4, structure: 17, range: 23, arc: 1.25, windup: 0.08, active: 0.17, recover: 0.14,
    kb: 58, knockdown: false, lunge: 32, hitstop: 0.033, shake: 0.23, hitR: 4.6,
    foot: { school, window, both, beats }, ...move,
  };
}

export const FOOT_MOVES = {
  FT_RASTEIRA: kick('rasteira', 'RASTEIRA SWEEP', 'foot_rasteira', 'capoeira', {
    active: 0.20, arc: 2.2, range: 22, lunge: 27, window: [0.23, 0.79],
  }),
  FT_SIDE: kick('side', 'SIDE SNAP', 'foot_side', 'taekwondo', {
    dmg: 4.1, structure: 22, lunge: 43, active: 0.15, window: [0.25, 0.90],
  }),
  FT_WHEEL: kick('wheel', 'LOTUS WHEEL', 'foot_wheel', 'lotus', {
    dmg: 4.6, structure: 26, windup: 0.10, active: 0.27, recover: 0.17, kb: 70, lunge: 50,
    range: 26, arc: 2.1, window: [0.18, 0.86], both: true,
  }),
  FT_EMBER: kick('ember', 'EMBER CRESCENT', 'foot_ember', 'ember', {
    dmg: 5.9, structure: 31, windup: 0.10, active: 0.24, recover: 0.20, kb: 140, lunge: 44,
    hitstop: 0.054, shake: 0.41, range: 27, launch: 80, window: [0.36, 0.87],
  }),
  FT_MEIA: kick('meia', 'MOON SWEEP', 'foot_meia', 'capoeira', {
    dmg: 5.8, structure: 29, windup: 0.11, active: 0.24, recover: 0.17, lunge: 37, kb: 68,
    arc: 2.5, range: 26, hitstop: 0.044, limb: 'bfoot', window: [0.25, 0.87],
  }),
  FT_TORNADO: kick('tornado', 'TORNADO HEEL', 'foot_tornado', 'taekwondo', {
    dmg: 6.4, structure: 37, windup: 0.115, active: 0.28, recover: 0.19, kb: 83, lunge: 57,
    range: 27, arc: 2.2, jump: 5, hitstop: 0.049, shake: 0.37, window: [0.20, 0.87], both: true,
  }),
  FT_BLAZE: kick('blaze', 'BLAZING COMET', 'foot_comet', 'ember', {
    dmg: 9.2, structure: 52, windup: 0.15, active: 0.27, recover: 0.30, kb: 225, lunge: 64,
    range: 28, jump: 5.5, launch: 115, knockdown: true, finisher: true, hitstop: 0.072,
    shake: 0.53, window: [0.34, 0.91],
  }),
  FT_LAUNCH: kick('launch', 'RISING LOTUS', 'foot_lotus', 'lotus', {
    dmg: 4.7, structure: 30, windup: 0.10, active: 0.19, recover: 0.17, lunge: 43, kb: 38,
    range: 24, launch: 165, hitstop: 0.037, window: [0.28, 0.85],
  }),
  FT_BACK: kick('back', 'COMET BACK KICK', 'foot_back', 'taekwondo', {
    dmg: 5.9, structure: 31, windup: 0.075, active: 0.245, recover: 0.22, travel: 164, jump: 3.5,
    kb: 125, range: 26, lunge: 0, hitstop: 0.054, window: [0.31, 0.87],
  }),
  FT_AIR_SCISSOR: kick('air_scissor', 'SKY SCISSORS', 'foot_scissor', 'lotus', {
    dmg: 4.1, structure: 24, windup: 0.055, active: 0.18, recover: 0.11, kb: 54, lunge: 47,
    range: 25, air: true, window: [0.23, 0.91], both: true,
  }),
  FT_AIR_TORNADO: kick('air_tornado', 'SKY TORNADO', 'foot_tornado', 'taekwondo', {
    dmg: 5.3, structure: 29, windup: 0.07, active: 0.23, recover: 0.13, kb: 74, lunge: 36,
    air: true, range: 26, window: [0.20, 0.90], both: true,
  }),
  FT_AIR_COMET: kick('air_comet', 'COMET DROP', 'foot_dive', 'ember', {
    dmg: 7.2, structure: 43, windup: 0.07, active: 0.235, recover: 0.20, lunge: 56, kb: 139,
    air: true, knockdown: true, range: 27, finisher: true, hitstop: 0.061, shake: 0.43,
    window: [0.20, 0.96],
  }),
  FT_CROSS: kick('cross', 'CROSSWIND', 'foot_cross', 'capoeira', {
    dmg: 6.1, structure: 32, windup: .082, active: .245, recover: .17, kb: 74, lunge: 49,
    arc: 2.2, range: 27, hitstop: .042, shake: .24, window: [.20, .91], both: true,
  }),
  FT_DRAGON: kick('dragon', 'CINDER DRAGON', 'foot_dragon', 'ember', {
    dmg: 8.8, structure: 50, windup: .13, active: .29, recover: .25, kb: 185, lunge: 65,
    range: 28, jump: 5.3, launch: 94, knockdown: true, finisher: true, hitstop: .066,
    shake: .42, window: [.30, .94],
  }),
  FT_FL_DOUBLE: kick('fl_double', 'SWITCH DOUBLE', 'foot_switch_double', 'flamingo', {
    dmg: 5.1, structure: 24, windup: .065, active: .33, recover: .153, kb: 41, lunge: 38,
    range: 25, arc: 1.49, hitR: 4.8, hitstop: .032, shake: .21,
    beats: [
      { from: .10, to: .36, leg: 'ffoot', power: .44, structure: .44, push: .48, stop: .017 },
      { from: .59, to: .90, leg: 'bfoot', power: .56, structure: .56, push: .62, stop: .034 },
    ],
    window: [.10, .90],
  }),
  FT_FL_HOOK: kick('fl_hook', 'REVERSE HOOK', 'foot_switch_hook', 'flamingo', {
    dmg: 5.8, structure: 29, windup: .072, active: .208, recover: .165, kb: 59, lunge: 41,
    limb: 'bfoot', range: 26, arc: 1.74, hitR: 5.1, hitstop: .038, shake: .24, window: [.24, .92],
  }),
  FT_FL_BREAK: kick('fl_break', 'HEEL BREAKER', 'foot_switch_ender', 'flamingo', {
    dmg: 8.6, structure: 45, windup: .115, active: .27, recover: .235, kb: 202, lunge: 54,
    range: 28, arc: 1.48, hitR: 5.9, hitstop: .074, shake: .43, knockdown: true, finisher: true,
    window: [.30, .91],
  }),
} satisfies Record<string, FootMove>;

export function footMove(move?: Move | null): FootMove | undefined {
  return move && 'foot' in move ? move as FootMove : undefined;
}

export function footContact(move: FootMove, progress: number) {
  return progress >= move.foot.window[0] && progress <= move.foot.window[1];
}

export function footBeatAt(move: FootMove, progress: number) {
  return move.foot.beats?.findIndex(beat => progress >= beat.from && progress <= beat.to) ?? -1;
}

export function footLeg(leg: FootLeg, lead: 1 | -1): FootLeg {
  return lead === 1 ? leg : leg === 'ffoot' ? 'bfoot' : 'ffoot';
}

export const footStanceColor = (lead: 1 | -1) => lead === 1 ? '#79eec6' : '#ffa568';

const LIGHT = ['FT_RASTEIRA', 'FT_SIDE', 'FT_WHEEL', 'FT_EMBER'] as const;
const HEAVY = ['FT_MEIA', 'FT_TORNADO', 'FT_BLAZE'] as const;
const AIR = ['FT_AIR_SCISSOR', 'FT_AIR_TORNADO'] as const;
export type FootKey = keyof typeof FOOT_MOVES;

export type FootCommand = { input: 'L' | 'H'; airborne: boolean; momentum: boolean; backKick: boolean; rising: boolean; autoAim?: boolean; aim?: number };
export type FootInput = FootCommand['input'];
export type FootChain = 'flow' | 'power' | 'air' | 'mixed' | 'special' | 'flamingo';
type FootContact = { x: number; y: number; at: number; direction: number; originY: number; originZ: number };

export class Footwork {
  private steps = { light: 0, heavy: 0, air: 0 };
  private lastStarted = -Infinity;
  private queue: { command: FootCommand; at: number }[] = [];
  private chase: { target: number; until: number } | null = null;
  private jumpUntil = -Infinity;
  private switchUntil = -Infinity;
  private stanceSince = -Infinity;
  private stanceUntil = -Infinity;
  private stanceStep = 0;
  private contacts = new Map<number, Set<number>>();
  lead: 1 | -1 = 1;
  attackLead: 1 | -1 = 1;
  contactBeat = -1;
  target: number | null = null;
  linkFrom: { pose: Move['pose']; t: number; facing: number; aim: number; footLead?: 1 | -1; footSwitch?: boolean } | null = null;
  clock = 0;
  activeKey: FootKey | null = null;
  route: FootChain = 'flow';
  confirmed = false;
  hits = 0;
  best = 0;
  lastHit = -Infinity;
  changedAt = -Infinity;
  beat = 0;
  total = 0;
  impact: (FootContact & { color: string; strong: boolean; school: FootSchool }) | null = null;

  get pending() { return this.queue[0] ?? null; }
  get inputs() { return this.queue.map(({ command }) => command.input); }
  get launchPending() { return this.queue.some(({ command }) => command.rising); }
  get chainHits() { return this.clock - this.lastHit <= 1.36 ? this.hits : 0; }
  get inFlamingo() { return this.clock < this.stanceUntil; }
  get switchPending() { return this.clock <= this.switchUntil; }
  get stanceTime() { return this.clock - this.stanceSince; }
  get stanceFill() { return clamp((this.stanceUntil - this.clock) / 2, 0, 1); }

  reset() {
    this.steps = { light: 0, heavy: 0, air: 0 };
    this.lastStarted = -Infinity;
    this.queue = [];
    this.chase = null;
    this.target = null;
    this.linkFrom = null;
    this.activeKey = null;
    this.confirmed = false;
    this.jumpUntil = -Infinity;
    this.switchUntil = this.stanceUntil = this.stanceSince = -Infinity;
    this.lead = this.attackLead = 1; this.stanceStep = 0;
    this.contacts.clear(); this.contactBeat = -1;
    this.route = 'flow';
    this.hits = this.best = 0; this.lastHit = -Infinity;
    this.changedAt = -Infinity;
    this.beat = this.total = 0;
    this.impact = null;
  }

  select({ input, airborne, momentum, backKick, rising }: FootCommand, time: number, tempo: number) {
    const fresh = time - this.lastStarted > 1.18 / Math.min(tempo, 1);
    if (fresh) this.steps = { light: 0, heavy: 0, air: 0 };
    this.lastStarted = time;
    this.changedAt = this.clock;
    const previous = this.activeKey;
    const linked = this.confirmed;
    this.confirmed = false;
    if (!airborne) this.steps.air = 0;
    if (!rising && !this.launchPending) this.clearJump();
    if (airborne || rising || backKick) this.leaveStance();
    if (airborne) return input === 'H' ? this.special('FT_AIR_COMET', 'air') : this.next('air', AIR);
    if (rising) return this.special('FT_LAUNCH');
    if (backKick) return this.special('FT_BACK');
    if (this.inFlamingo) {
      this.stanceUntil = this.clock + 2;
      if (input === 'H') return this.flamingo('FT_FL_BREAK', 3);
      if (!fresh && linked && previous === 'FT_FL_DOUBLE' && this.stanceStep === 1) return this.flamingo('FT_FL_HOOK', 2);
      return this.flamingo('FT_FL_DOUBLE', 1);
    }
    if (momentum) return this.special('FT_BACK');
    if (!fresh && linked && input === 'H' && previous === 'FT_SIDE') return this.branch('FT_CROSS', 3);
    if (!fresh && linked && input === 'L' && previous === 'FT_CROSS') return this.branch('FT_DRAGON', 4);
    return input === 'H' ? this.next('heavy', HEAVY) : this.next('light', LIGHT);
  }

  buffer(command: FootCommand, time: number) {
    // Keep the first committed link; a deliberate special may replace the last queued tap.
    if (this.queue.length >= 2) {
      const last = this.queue[1];
      const deliberate = command.rising || command.backKick || command.airborne;
      const stanceFinisher = this.inFlamingo && command.input === 'H' && last.command.input === 'L';
      if ((deliberate || stanceFinisher) && !(last.command.rising || last.command.backKick)) {
        this.queue[1] = { command, at: time };
      }
      return;
    }
    this.queue.push({ command, at: time });
  }

  discard() { this.queue = []; }

  interrupt() {
    this.discard(); this.target = null; this.linkFrom = null; this.chase = null;
    this.leaveStance(); this.switchUntil = -Infinity;
    this.activeKey = null; this.confirmed = false; this.clearJump();
    this.hits = 0; this.lastHit = -Infinity; this.lastStarted = -Infinity;
  }

  requestSwitch(tempo: number) { this.switchUntil = this.clock + .68 / Math.min(tempo, 1); }
  clearSwitch() { this.switchUntil = -Infinity; }

  switchStance() {
    this.switchUntil = -Infinity;
    this.lead = this.lead === 1 ? -1 : 1;
    this.stanceSince = this.clock;
    this.stanceUntil = this.clock + 2;
    if (this.route !== 'flamingo' || this.activeKey === 'FT_FL_BREAK') this.stanceStep = 0;
  }

  leaveStance() { this.stanceUntil = -Infinity; this.stanceStep = 0; }

  beginMove(move: FootMove) {
    this.contacts.clear(); this.contactBeat = -1;
    this.attackLead = move.foot.school === 'flamingo' ? this.lead : 1;
  }

  // The double kick owns two contact sets; holding or freezing a frame cannot repeat a beat.
  canContact(target: number, beat: number) { return !this.contacts.get(beat)?.has(target); }

  spendContact(target: number, beat: number) {
    let group = this.contacts.get(beat);
    if (!group) { group = new Set(); this.contacts.set(beat, group); }
    group.add(target);
  }

  take(time: number, lifetime: number) {
    while (this.queue.length && time - this.queue[0].at > lifetime) this.queue.shift();
    return this.queue.shift()?.command ?? null;
  }

  markLauncher(target: number, time: number) { this.chase = { target, until: time + .55 }; }

  bufferJump(tempo: number) { this.jumpUntil = this.clock + .46 / Math.min(tempo, 1); }
  get jumpQueued() { return this.clock <= this.jumpUntil; }
  clearJump() { this.jumpUntil = -Infinity; }

  takeLauncher(time: number) {
    const chase = this.chase;
    this.chase = null;
    return chase && time <= chase.until ? chase.target : null;
  }

  private next(track: keyof Footwork['steps'], list: readonly FootKey[]) {
    this.route = track === 'light' ? 'flow' : track === 'heavy' ? 'power' : 'air';
    this.beat = this.steps[track]++ % list.length + 1;
    this.total = list.length;
    return this.activeKey = list[this.beat - 1];
  }

  private special(key: FootKey, route: FootChain = 'special') {
    this.route = route;
    this.beat = this.total = 1;
    return this.activeKey = key;
  }

  private branch(key: FootKey, beat: number) {
    this.route = 'mixed'; this.beat = beat; this.total = 4;
    return this.activeKey = key;
  }

  private flamingo(key: FootKey, beat: number) {
    this.route = 'flamingo'; this.beat = this.stanceStep = beat; this.total = 3;
    if (key === 'FT_FL_BREAK') this.leaveStance();
    return this.activeKey = key;
  }

  recordImpact(contact: FootContact, move: FootMove) {
    this.confirmed = true;
    this.hits = this.clock - this.lastHit > 1.36 ? 1 : this.hits + 1;
    this.lastHit = this.clock;
    this.best = Math.max(this.best, this.hits);
    const switchColor = this.contactBeat === 1 ? this.attackLead === 1 ? -1 : 1 : this.attackLead;
    this.impact = { ...contact, color: move.foot.school === 'flamingo' ? footStanceColor(switchColor) : FOOT_SCHOOLS[move.foot.school].color, school: move.foot.school, strong: !!move.finisher };
  }
}

export function footProgress(attackT: number, active: number) {
  return clamp(1 - attackT / active, 0, 1);
}