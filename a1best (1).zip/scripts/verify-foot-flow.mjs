import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const base = (process.argv[2] || 'http://127.0.0.1:5173').replace(/\/$/, '');
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1366, height: 790 }, reducedMotion: 'reduce' });
const errors = [];
page.setDefaultTimeout(9000);
page.on('pageerror', e => errors.push(e.message));
const started = (key, phase = false) => page.waitForFunction(({ key, phase }) => window.flowTrace.started.includes(key) &&
  (!phase || (window.__kf.player.moveKey === key && window.__kf.player.attackPhase === 'active')), { key, phase });
const tap = key => page.keyboard.press(key, { delay: 24 });
const clear = () => page.evaluate(() => { window.flowTrace.started.length = window.flowTrace.hits.length = 0; });
const waitIdle = () => page.waitForFunction(() => window.__kf.player.attackPhase === 'none' && !window.__kf.player.airborne);

try {
  await page.goto(`${base}/#arena/training/foot`);
  await page.waitForFunction(() => window.__kf?.training && window.__kf.player.weapon === 'foot');
  await page.evaluate(() => {
    const g = window.__kf;
    window.flowTrace = { started: [], hits: [] };
    const start = g.startAttack.bind(g), melee = g.meleeHitEnemy.bind(g);
    g.startAttack = key => { window.flowTrace.started.push(key); start(key); };
    g.meleeHitEnemy = (enemy, move, ...rest) => { window.flowTrace.hits.push(move.id); return melee(enemy, move, ...rest); };
    g.input.focus();
  });

  await page.getByRole('button', { name: 'Rute Mix' }).click();
  await tap('j'); await started('FT_RASTEIRA', true);
  // Two complete taps in one event turn must not overwrite each other.
  await page.evaluate(() => {
    const g = window.__kf;
    for (const button of [0, 2]) { g.input.synthMouseDown(button); g.input.synthMouseUp(button); }
  });
  await page.waitForFunction(() => window.__kf.footwork.inputs.join('') === 'LH');
  await started('FT_CROSS', true);
  await tap('j');
  await page.getByText('KOMBO BERHASIL', { exact: true }).waitFor();
  const mix = await page.evaluate(() => window.flowTrace);
  assert.deepEqual(mix.started, ['FT_RASTEIRA', 'FT_SIDE', 'FT_CROSS', 'FT_DRAGON']);
  assert.deepEqual(mix.hits, ['foot_rasteira', 'foot_side', 'foot_cross', 'foot_dragon']);
  assert.ok(await page.getByText(/Rekor sesi 4 hit/).isVisible());
  console.log('PASS: ordered rapid taps, hit-confirmed Crossflow, four real contacts, and drill feedback');

  await waitIdle();
  await page.getByRole('button', { name: 'Rute Flow' }).click();
  await clear();
  const mouseCanvas = await page.locator('.arena-stage canvas').boundingBox();
  await page.locator('.arena-stage canvas').click({ button: 'left', position: { x: mouseCanvas.width * .69, y: mouseCanvas.height * .61 } });
  await started('FT_RASTEIRA');
  await page.waitForFunction(() => window.__kf.footwork.confirmed);
  console.log('PASS: real mouse input still aims and connects after the new tap queue');

  await page.getByRole('button', { name: 'Rute Flow' }).click();
  await clear();
  await page.evaluate(() => { window.__kf.enemies[0].x = window.__kf.player.x + 90; });
  await tap('j'); await started('FT_RASTEIRA', true);
  await tap('j'); await started('FT_SIDE', true);
  await tap('k'); await started('FT_MEIA');
  await waitIdle();
  assert.deepEqual(await page.evaluate(() => window.flowTrace.hits), []);
  assert.ok(!(await page.evaluate(() => window.flowTrace.started)).includes('FT_CROSS'));
  console.log('PASS: a whiff cannot trigger hit-confirm links or long-range contact');

  await page.getByRole('button', { name: 'Ulangi posisi' }).click();
  await clear();
  await page.evaluate(() => { const g = window.__kf; g.enemies[0].x = g.player.x - 18.5; });
  await tap('j');
  await page.waitForFunction(() => window.__kf.footwork.confirmed);
  assert.equal(await page.evaluate(() => window.__kf.player.facing), -1);
  await page.getByRole('button', { name: 'Ulangi posisi' }).click();
  await clear();
  await tap('j'); await started('FT_RASTEIRA', true);
  await tap('j');
  await page.waitForFunction(() => !!window.__kf.footwork.pending);
  await tap('Escape');
  await page.waitForFunction(() => window.__kf.state === 'paused');
  const time = await page.evaluate(() => window.__kf.footwork.clock);
  await page.waitForTimeout(500);
  assert.equal(await page.evaluate(() => window.__kf.footwork.clock), time);
  await page.getByRole('button', { name: 'LANJUTKAN', exact: true }).click();
  await started('FT_SIDE');
  console.log('PASS: nearby keyboard aim works left and right, and paused time does not eat buffered attacks');

  await page.getByRole('button', { name: 'Rute Udara' }).click();
  await clear();
  await page.getByRole('button', { name: 'ANGKAT', exact: true }).click();
  await started('FT_LAUNCH');
  await page.evaluate(() => window.__kf.input.pressed.add(' '));
  await page.waitForFunction(() => window.__kf.player.airborne);
  await tap('j'); await started('FT_AIR_SCISSOR');
  await tap('j'); await started('FT_AIR_TORNADO');
  await tap('k'); await started('FT_AIR_COMET');
  await page.getByText('KOMBO BERHASIL', { exact: true }).waitFor();
  await waitIdle();
  assert.deepEqual(await page.evaluate(() => window.flowTrace.hits), ['foot_launch', 'foot_air_scissor', 'foot_air_tornado', 'foot_air_comet']);
  console.log('PASS: an early jump waits for Rising Lotus and all four airborne-route hits register');

  await page.close();
  const mobile = await browser.newPage({ viewport: { width: 375, height: 812 }, hasTouch: true, isMobile: true, reducedMotion: 'reduce' });
  mobile.setDefaultTimeout(10000);
  mobile.on('pageerror', e => errors.push(e.message));
  await mobile.goto(`${base}/#arena/training/foot`);
  await mobile.getByRole('button', { name: 'Rute Udara' }).tap();
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth), 375);
  const canvas = await mobile.locator('.arena-stage canvas').boundingBox();
  assert.ok(canvas && canvas.height >= 345);
  await mobile.getByRole('button', { name: 'ANGKAT', exact: true }).tap();
  await mobile.getByRole('button', { name: 'Lompat', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.airborne);
  await mobile.getByRole('button', { name: 'Tendang', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.moveKey === 'FT_AIR_SCISSOR');
  await mobile.getByRole('button', { name: 'Tendang', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.moveKey === 'FT_AIR_TORNADO');
  await mobile.getByRole('button', { name: 'Tendangan berat', exact: true }).tap();
  await mobile.getByText('KOMBO BERHASIL', { exact: true }).waitFor();
  assert.deepEqual(errors, []);
  console.log('PASS: full aerial drill on touch, enlarged portrait arena, and no runtime errors');
} finally {
  await browser.close();
}