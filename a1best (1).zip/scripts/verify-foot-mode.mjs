import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const base = (process.argv[2] || 'http://127.0.0.1:5173').replace(/\/$/, '');
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const native = await browser.newPage({ viewport: { width: 1280, height: 800 }, reducedMotion: 'reduce' });
const errors = [];
const watch = page => {
  page.setDefaultTimeout(12000);
  page.on('pageerror', error => errors.push(error.message));
};
watch(native);
const weapon = (page, name) => page.waitForFunction(name => window.__kf?.player.weapon === name, name);

try {
  await native.goto(base);
  await native.locator('[data-office-menu-item="office"]').click();
  await native.waitForFunction(() => window.__kf?.state === 'playing');
  await native.locator('.tr').waitFor({ state: 'detached' });
  await native.getByRole('button', { name: 'Pengaturan dan senjata' }).click();
  const picker = native.getByRole('dialog', { name: 'SENJATA & KONTROL' });
  assert.deepEqual(await picker.locator('[data-weapon]').evaluateAll(e => e.slice(0, 4).map(x => x.dataset.weapon)), ['fist', 'foot', 'pistol', 'rifle']);
  await picker.locator('[data-weapon="foot"]').click();
  await weapon(native, 'foot');
  assert.equal(await picker.locator('[data-weapon="foot"]').getAttribute('aria-pressed'), 'true');
  await native.getByRole('button', { name: 'Tutup pengaturan' }).click();
  for (const [key, name] of [['1', 'fist'], ['q', 'foot'], ['q', 'pistol'], ['o', 'foot']]) {
    await native.keyboard.press(key, { delay: 30 });
    await weapon(native, name);
  }
  await native.locator('.solo-stage canvas').hover();
  await native.mouse.wheel(0, -120); await weapon(native, 'fist');
  await native.mouse.wheel(0, 120); await weapon(native, 'foot');
  await native.getByRole('button', { name: 'Foot Mode (O)' }).click(); await weapon(native, 'fist');
  await native.getByRole('button', { name: 'Foot Mode (O)' }).click(); await weapon(native, 'foot');
  console.log('PASS: native picker, O, Q, wheel, and quick selector all use Fist / Foot / Pistol order');

  await native.goto(base);
  await native.locator('[data-office-menu-item="help"]').click();
  await native.getByRole('button', { name: 'JURUS FOOT MODE', exact: true }).click();
  await native.getByRole('dialog', { name: 'FOOT MODE', exact: true }).waitFor();
  await native.getByText('Rising Lotus', { exact: true }).waitFor();
  await native.getByRole('button', { name: 'LATIHAN FOOT MODE', exact: true }).click();
  await native.waitForFunction(() => window.__kf?.training && window.__kf?.player.weapon === 'foot');
  await native.evaluate(() => {
    const g = window.__kf;
    window.trace = { moves: [], hits: [] };
    const start = g.startAttack.bind(g), hit = g.meleeHitEnemy.bind(g);
    g.startAttack = key => { window.trace.moves.push(key); start(key); };
    g.meleeHitEnemy = (enemy, move, ...rest) => {
      window.trace.hits.push({ id: move.id, limb: move.limb, target: enemy.id });
      return hit(enemy, move, ...rest);
    };
    g.input.focus();
  });
  const reset = async () => {
    await native.getByRole('button', { name: 'Ulangi posisi' }).click();
    await native.evaluate(() => { window.trace.moves.length = window.trace.hits.length = 0; });
  };
  const started = (key, phase = false) => native.waitForFunction(({ key, phase }) => window.trace.moves.includes(key) &&
    (!phase || (window.__kf.player.moveKey === key && window.__kf.player.attackPhase === 'active')), { key, phase });
  const landed = id => native.waitForFunction(id => window.trace.hits.some(hit => hit.id === id), id);

  await native.keyboard.press('j', { delay: 30 });
  await started('FT_RASTEIRA', true);
  await native.keyboard.press('j', { delay: 30 });
  await started('FT_SIDE', true);
  await native.keyboard.press('j', { delay: 30 });
  await started('FT_WHEEL', true);
  await native.keyboard.press('j', { delay: 30 });
  await landed('foot_ember');
  assert.deepEqual(await native.evaluate(() => window.trace.moves), ['FT_RASTEIRA', 'FT_SIDE', 'FT_WHEEL', 'FT_EMBER']);
  assert.deepEqual(await native.evaluate(() => window.trace.hits.map(h => h.id)), ['foot_rasteira', 'foot_side', 'foot_wheel', 'foot_ember']);
  console.log('PASS: four buffered Flow kicks produce four distinct foot contacts');

  await reset();
  for (const key of ['FT_MEIA', 'FT_TORNADO', 'FT_BLAZE']) {
    await native.keyboard.press('k', { delay: 30 });
    await started(key, true);
  }
  await landed('foot_blaze');
  assert.deepEqual(await native.evaluate(() => window.trace.hits.map(h => h.id)), ['foot_meia', 'foot_tornado', 'foot_blaze']);
  assert.equal(await native.evaluate(() => window.trace.hits[0].limb), 'bfoot');
  await reset();
  await native.keyboard.down('w');
  await native.keyboard.press('k', { delay: 40 });
  await native.keyboard.up('w');
  await started('FT_BACK');
  await landed('foot_back');
  console.log('PASS: Power Combo, rear-leg sweep, and travelling back kick');

  await reset();
  await native.keyboard.press('j', { delay: 25 });
  await started('FT_RASTEIRA', true);
  await native.keyboard.down('s');
  await native.keyboard.press('k', { delay: 35 });
  await native.keyboard.up('s');
  await landed('foot_launch');
  await native.keyboard.press('Space', { delay: 24 });
  await native.waitForFunction(() => window.__kf.player.airborne);
  await native.keyboard.press('j', { delay: 26 });
  await started('FT_AIR_SCISSOR', true);
  await native.keyboard.press('j', { delay: 28 });
  await started('FT_AIR_TORNADO', true);
  await native.keyboard.press('k', { delay: 27 });
  await started('FT_AIR_COMET', true);
  await native.waitForFunction(() => window.__kf.player.attackPhase === 'none' && !window.__kf.player.airborne);
  const trace = await native.evaluate(() => window.trace);
  assert.ok(trace.hits.some(hit => hit.id === 'foot_air_scissor'));
  assert.ok(trace.hits.every(hit => ['ffoot', 'bfoot'].includes(hit.limb)));
  console.log('PASS: buffered Rising Lotus, Sky Scissors, Sky Tornado, and Comet Drop with clean landing');

  await native.evaluate(() => { window.__kf.setTempo(.35); });
  await reset();
  await native.keyboard.press('j', { delay: 30 });
  await started('FT_RASTEIRA', true);
  await native.keyboard.press('j', { delay: 30 });
  await landed('foot_side');
  await native.evaluate(() => { window.__kf.setTempo(1); });
  console.log('PASS: combo buffering respects slower animation tempo');

  await reset();
  await native.keyboard.press('j', { delay: 25 });
  await started('FT_RASTEIRA', true);
  await native.keyboard.press('j', { delay: 30 });
  await native.keyboard.press('1', { delay: 32 });
  await weapon(native, 'fist');
  await native.waitForTimeout(400);
  assert.deepEqual(await native.evaluate(() => window.trace.moves), ['FT_RASTEIRA']);
  await native.getByRole('button', { name: 'Ulangi posisi' }).click();
  await native.getByRole('button', { name: /UJI CLINCH/ }).click();
  await native.waitForFunction(() => window.__kf.muay.contacts === 1);
  console.log('PASS: no stale kick follows an equipment switch, and the original single-knee Clinch remains intact');

  await native.close();
  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  watch(mobile);
  await mobile.goto(`${base}/#arena/training/foot`);
  await mobile.waitForFunction(() => window.__kf?.training && window.__kf.player.weapon === 'foot');
  await mobile.getByRole('button', { name: 'Tendang', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.moveKey === 'FT_RASTEIRA' && window.__kf.footwork.impact);
  await mobile.getByRole('button', { name: 'Tendangan berat', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.moveKey === 'FT_MEIA');
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth), 390);
  assert.deepEqual(errors, []);
  console.log('PASS: touch Flow/Power and responsive Dojo, no browser errors');
} finally {
  await browser.close();
}