import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const base = (process.argv[2] || 'http://127.0.0.1:5173').replace(/\/$/, '');
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1366, height: 820 }, reducedMotion: 'reduce' });
const errors = [];
page.setDefaultTimeout(10000);
page.on('pageerror', error => errors.push(error.message));
const waitGame = () => page.waitForFunction(() => window.__kf?.state === 'playing');
const tap = key => page.keyboard.press(key, { delay: 28 });
const idle = () => page.waitForFunction(() => window.__kf.player.attackPhase === 'none');
const switchButton = page.getByRole('button', { name: 'Ganti kuda-kuda Flamingo', exact: true });
const clear = () => page.evaluate(() => { window.flamingoTrace.moves.length = window.flamingoTrace.hits.length = 0; });

try {
  await page.goto(base);
  await page.locator('[data-office-menu-item="help"]').click();
  await page.getByRole('button', { name: 'JURUS FOOT MODE', exact: true }).click();
  await page.getByText('Flamingo Rush', { exact: true }).waitFor();
  await page.getByRole('button', { name: 'LATIHAN FOOT MODE', exact: true }).click();
  await waitGame();
  assert.ok(page.url().endsWith('/foot/flamingo'));
  assert.equal(await page.getByRole('button', { name: 'Rute Flamingo', exact: true }).getAttribute('aria-pressed'), 'true');
  await page.evaluate(() => {
    const g = window.__kf;
    window.flamingoTrace = { moves: [], hits: [] };
    const damage = g.meleeHitEnemy.bind(g), start = g.startAttack.bind(g);
    g.startAttack = key => { window.flamingoTrace.moves.push(key); start(key); };
    g.meleeHitEnemy = (enemy, move, ...rest) => {
      window.flamingoTrace.hits.push({ id: move.id, limb: move.limb, beat: g.footwork.contactBeat, hp: enemy.hp, at: g.time });
      return damage(enemy, move, ...rest);
    };
    g.input.focus();
  });

  await tap('i');
  await page.waitForFunction(() => window.__kf.footwork.inFlamingo && window.__kf.footwork.lead === -1);
  await tap('j');
  await page.waitForFunction(() => window.flamingoTrace.hits.length === 1);
  await tap('j');
  await page.waitForFunction(() => window.__kf.player.moveKey === 'FT_FL_HOOK');
  await tap('k');
  await page.getByText('KOMBO BERHASIL', { exact: true }).waitFor();
  await idle();
  const completed = await page.evaluate(() => ({ ...window.flamingoTrace, hitsCount: window.__kf.footwork.hits, stance: window.__kf.footwork.inFlamingo }));
  assert.deepEqual(completed.moves, ['FT_FL_DOUBLE', 'FT_FL_HOOK', 'FT_FL_BREAK']);
  assert.deepEqual(completed.hits.map(hit => [hit.id, hit.beat, hit.limb]), [
    ['foot_fl_double', 0, 'bfoot'], ['foot_fl_double', 1, 'ffoot'], ['foot_fl_hook', -1, 'ffoot'], ['foot_fl_break', -1, 'bfoot'],
  ]);
  assert.ok(completed.hits[1].at - completed.hits[0].at > .065);
  assert.equal(completed.hitsCount, 4);
  assert.equal(completed.stance, false);
  console.log('PASS: real two-beat Switch Double, connected Hook and Breaker, stance exit, and a completed four-hit drill');

  await page.getByRole('button', { name: 'Ulangi posisi' }).click();
  await clear();
  await switchButton.click();
  await switchButton.click();
  await page.waitForFunction(() => window.__kf.footwork.inFlamingo && window.__kf.footwork.lead === 1);
  await page.keyboard.down('j');
  await page.waitForFunction(() => window.flamingoTrace.hits.length === 2);
  await page.waitForTimeout(620);
  await page.keyboard.up('j');
  const otherLeg = await page.evaluate(() => window.flamingoTrace);
  assert.deepEqual(otherLeg.moves, ['FT_FL_DOUBLE']);
  assert.deepEqual(otherLeg.hits.map(hit => hit.limb), ['ffoot', 'bfoot']);
  console.log('PASS: the other stance really mirrors the striking legs; holding J does not retrigger a beat');

  await page.getByRole('button', { name: 'Ulangi posisi' }).click();
  await clear();
  await page.evaluate(() => { window.__kf.enemies[0].x = window.__kf.player.x + 91; });
  await tap('i'); await tap('j');
  await page.waitForFunction(() => window.flamingoTrace.moves.includes('FT_FL_DOUBLE'));
  await idle();
  assert.equal(await page.evaluate(() => window.flamingoTrace.hits.length), 0);
  await tap('j');
  await page.waitForFunction(() => window.flamingoTrace.moves.length >= 2);
  assert.equal(await page.evaluate(() => window.flamingoTrace.moves[1]), 'FT_FL_DOUBLE');
  console.log('PASS: outside range there is no impact or confirmed Reverse Hook');

  await page.getByRole('button', { name: 'Ulangi posisi' }).click();
  await clear();
  await tap('j');
  await page.waitForFunction(() => window.__kf.player.moveKey === 'FT_RASTEIRA' && window.__kf.player.attackPhase === 'active');
  await tap('i');
  await tap('j');
  await page.waitForFunction(() => window.flamingoTrace.moves.includes('FT_FL_DOUBLE'));
  assert.deepEqual(await page.evaluate(() => window.flamingoTrace.moves), ['FT_RASTEIRA', 'FT_FL_DOUBLE']);
  console.log('PASS: the stance switch can be buffered into an existing kick without cutting off its impact');

  await page.goto(base);
  await page.locator('[data-office-menu-item="office"]').click();
  await waitGame();
  await page.locator('.tr').waitFor({ state: 'detached' });
  await page.getByRole('button', { name: 'Foot Mode (O)', exact: true }).click();
  await page.waitForFunction(() => window.__kf.player.weapon === 'foot');
  await switchButton.click();
  await page.waitForFunction(() => window.__kf.footwork.inFlamingo);
  await tap('j');
  await page.waitForFunction(() => window.__kf.player.moveKey === 'FT_FL_DOUBLE');
  await tap('Shift+i');
  await page.waitForFunction(() => window.__kf.player.weapon === 'buster');
  console.log('PASS: native arena stance control, original equipment, and Buster shortcut');

  await page.close();
  const mobile = await browser.newPage({ viewport: { width: 360, height: 780 }, isMobile: true, hasTouch: true });
  mobile.setDefaultTimeout(10000);
  mobile.on('pageerror', error => errors.push(error.message));
  await mobile.goto(`${base}/#arena/training/foot/flamingo`);
  const control = mobile.getByRole('button', { name: 'Ganti kuda-kuda Flamingo', exact: true });
  await control.tap();
  await mobile.getByRole('button', { name: 'Tendang', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.moveKey === 'FT_FL_DOUBLE');
  await mobile.getByRole('button', { name: 'Tendang', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf.player.moveKey === 'FT_FL_HOOK');
  await mobile.getByRole('button', { name: 'Tendangan berat', exact: true }).tap();
  await mobile.getByText('KOMBO BERHASIL', { exact: true }).waitFor();
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth), 360);
  assert.deepEqual(errors, []);
  console.log('PASS: all four contacts with touch only, an undistorted portrait layout, and no runtime errors');
} finally {
  await browser.close();
}