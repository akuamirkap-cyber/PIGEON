import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const base = process.argv[2] || 'http://127.0.0.1:5173';
const browser = await chromium.launch({ args: ['--no-sandbox'] });
try {
  const page = await browser.newPage();
  await page.goto(`${base}/#arena/training`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__kf?.training);
  const results = await page.evaluate(async () => {
    const { solvePose } = await import('/src/original/v2/games/maxkungfu/game/stick.ts');
    const g = window.__kf, results = [];
    for (const fps of [24, 30, 60, 144]) {
      for (const direction of [-1, 1]) {
        g.resetTrainingPartner();
        const e = g.enemies[0];
        e.x = g.player.x + direction * 17;
        g.muay.start(g, e);
        for (let frame = 0; !g.muay.active?.hitDone && frame < fps * 2; frame++) g.muay.update(g, 1 / fps);
        const scene = g.muay.active;
        if (!scene?.hitDone) throw new Error('Expected a single contact');
        const po = g.playerStickOpts('knee', scene.t / 0.43);
        const eo = { ...po, x: e.x, y: e.y, facing: e.facing, aim: e.aim, pose: 'crouch', t: 0.6 };
        g.muay.bindPose(g, po); g.muay.bindPose(g, eo, e);
        const p = solvePose(po), target = solvePose(eo);
        const dx = (po.x + p.fknee.x) - (eo.x + target.head.x);
        const dy = (po.y + p.fknee.y) - (eo.y + target.head.y);
        for (let i = 0; i < 2 * fps; i++) g.muay.update(g, 1 / fps);
        results.push({ fps, direction, dx, dy, contacts: g.muay.contacts, released: !g.muay.active && !e.scenePose });
      }
    }
    return results;
  });
  assert.ok(results.every(r => r.contacts === 1 && r.released && Math.abs(r.dx) < 0.01 && Math.abs(r.dy - 1.5) < 0.01));
  console.log('PASS: knee meets the lower head contour once, with clean recovery, in both directions at 24, 30, 60, and 144 FPS.');
} finally { await browser.close(); }