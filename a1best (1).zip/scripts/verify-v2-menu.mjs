import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const base = (process.argv[2] || 'http://127.0.0.1:5173').replace(/\/$/, '');
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1167, height: 683 }, reducedMotion: 'reduce' });
const errors = [];
page.on('pageerror', error => errors.push(error.message));
const menu = page.getByRole('navigation', { name: 'Menu utama V2' });
const item = id => menu.locator(`[data-office-menu-item="${id}"]`);
const dialog = name => page.getByRole('dialog', { name, exact: true });
const backToMenu = async () => {
  await page.locator('.tr').waitFor({ state: 'detached' });
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'MENU UTAMA', exact: true }).click();
  await menu.waitFor();
};

try {
  await page.goto(base);
  await menu.waitFor();
  await page.waitForFunction(() => !!window.__kf && document.fonts.check('11px "Press Start 2P"') && document.querySelector('.v2-office-art')?.naturalWidth > 0);
  assert.equal(await menu.getByRole('button').count(), 7);
  assert.ok(await item('custom').isDisabled());
  const geometry = await page.evaluate(() => {
    const title = document.querySelector('.of-logo').getBoundingClientRect();
    const menu = document.querySelector('.of-menu').getBoundingClientRect();
    return { titleX: title.x, menuX: menu.x, menuW: menu.width, soundBarHidden: getComputedStyle(document.querySelector('#sound-bar')).display === 'none' };
  });
  assert.ok(geometry.titleX > 55 && geometry.titleX < 70 && geometry.menuX > 730 && geometry.menuX < 745);
  assert.ok(Math.abs(geometry.menuW - 360) < 3 && geometry.soundBarHidden);
  assert.equal(await menu.locator('.is-on').getAttribute('data-office-menu-item'), 'office');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('ArrowDown');
  assert.equal(await menu.locator('.is-on').getAttribute('data-office-menu-item'), 'editor');
  await page.keyboard.press('ArrowDown');
  await page.keyboard.press('Enter');
  await dialog('CARA MAIN').waitFor();
  await page.keyboard.press('Escape');
  await dialog('CARA MAIN').waitFor({ state: 'detached' });
  assert.equal(await page.evaluate(() => window.__kf.state), 'menu');
  console.log('PASS: V1 art, pixel font, reference layout, keyboard navigation, and help');

  await page.getByRole('button', { name: 'Matikan suara', exact: true }).click();
  assert.equal(await page.evaluate(() => window.__kf.sfx.muted), true);
  await item('office').click();
  await page.waitForFunction(() => window.__kf?.state === 'playing' && window.__kf.level.sideView);
  assert.equal(await page.evaluate(() => window.__kf.officeMapId), 'preset_tower_4');
  await backToMenu();
  await item('editor').click();
  await page.getByLabel('Nama peta kantor').fill('KANTOR QA');
  await page.getByRole('button', { name: 'SIMPAN', exact: true }).click();
  await page.getByText('TERSIMPAN: KANTOR QA').waitFor();
  await page.keyboard.press('Escape');
  await item('custom').click();
  await dialog('MAP KUSTOM').getByRole('button', { name: 'KANTOR QA', exact: true }).click();
  await page.waitForFunction(() => window.__kf?.state === 'playing' && window.__kf.officeMapId.startsWith('custom_'));
  await backToMenu();
  console.log('PASS: V2 office gameplay, pause, map editor, and saved custom maps');

  await item('story').click();
  await page.waitForFunction(() => window.__kf?.state === 'playing' && window.__kf.campaign && window.__kf.level.sideView);
  await backToMenu();
  await item('classic').click();
  await page.waitForFunction(() => window.__kf?.state === 'playing' && window.__kf.arena === 'meadow' && !window.__kf.level.sideView);
  await backToMenu();
  await item('modes').click();
  await dialog('MODE LAIN').getByRole('button', { name: 'PAPAN SKOR' }).click();
  await dialog('PAPAN SKOR').getByText('GURU', { exact: true }).waitFor();
  await page.keyboard.press('Escape');
  await dialog('MODE LAIN').getByRole('button', { name: 'KEMBALI KE GAME V1' }).click();
  await page.getByRole('navigation', { name: 'Menu mode side view', exact: true }).getByRole('button', { name: /GAME V2/ }).click();
  await menu.waitFor();
  console.log('PASS: native Story, classic arena, scoreboard, and switching between V1 and V2');

  await item('help').click();
  await dialog('CARA MAIN').getByRole('button', { name: 'MASUK DOJO LATIHAN' }).click();
  await page.waitForFunction(() => !!window.__kf?.training);
  await page.getByRole('button', { name: /UJI CLINCH/ }).click();
  await page.waitForFunction(() => window.__kf.muay.contacts === 1);
  await page.getByRole('button', { name: 'Lobi', exact: true }).click();
  await menu.waitFor();
  console.log('PASS: Dojo opens from the menu, lands one knee, and returns to V2');

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  mobile.on('pageerror', error => errors.push(error.message));
  await mobile.goto(base);
  await mobile.getByRole('navigation', { name: 'Menu utama V2' }).waitFor();
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth), 390);
  assert.equal(await mobile.getByRole('button', { name: 'Kontrol sentuh' }).getAttribute('aria-pressed'), 'true');
  await mobile.locator('[data-office-menu-item="help"]').tap();
  await mobile.getByRole('dialog', { name: 'CARA MAIN' }).getByRole('button', { name: 'KEMBALI', exact: true }).tap();
  await mobile.setViewportSize({ width: 320, height: 568 });
  await mobile.locator('[data-office-menu-item="modes"]').tap();
  await mobile.getByRole('dialog', { name: 'MODE LAIN' }).waitFor();
  console.log('PASS: portrait layout, touch controls, and compact screen scrolling');
  assert.deepEqual(errors, []);
} finally {
  await browser.close();
}