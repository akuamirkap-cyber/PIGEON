import assert from 'node:assert/strict';
import { chromium } from '@playwright/test';

const base = process.argv[2] || 'http://127.0.0.1:5173';
const arcade = `${base.replace(/\/$/, '')}/?arcade=1`;
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
const playing = () => page.waitForFunction(() => window.__kf?.state === 'playing');
const waitHits = (n) => page.waitForFunction((n) => window.__kf?.muay.contacts === n, n);

try {
  await page.goto(arcade, { waitUntil: 'domcontentloaded' });
  await page.getByRole('heading', { name: 'KUNGFU DRIFTER' }).waitFor();
  assert.equal(await page.locator('.mode-card').count(), 3);
  await page.getByRole('button', { name: 'Matikan suara game' }).click();
  await page.reload();
  await page.getByRole('button', { name: 'Aktifkan suara game' }).waitFor();
  await page.getByRole('button', { name: 'Buka profil pemain' }).click();
  await page.getByLabel('NAMA PEMAIN').fill('Drifter');
  await page.getByRole('button', { name: 'SIMPAN PROFIL' }).click();
  await page.getByRole('button', { name: 'TERSIMPAN' }).waitFor();
  await page.getByRole('button', { name: 'Tutup panel' }).click();
  assert.equal(await page.locator('.player-name').innerText(), 'Drifter');
  await page.getByRole('button', { name: 'Panduan Kontrol', exact: true }).click();
  await page.getByRole('tab', { name: 'Layar sentuh' }).click();
  await page.getByText('Arcade di genggamanmu.').waitFor();
  await page.keyboard.press('Escape');
  await page.getByRole('link', { name: 'Daftar Jurus', exact: true }).click();
  await page.getByRole('tab', { name: 'KUNGFU', exact: true }).click();
  await page.getByRole('heading', { name: 'Chain Punch' }).waitFor();
  await page.getByRole('tab', { name: 'MUAY THAI', exact: true }).click();
  await page.getByRole('button', { name: 'MASUK DOJO LATIHAN' }).click();
  await playing();
  await page.waitForFunction(() => !!window.__kf?.muay.markedTarget(window.__kf));
  assert.equal(await page.evaluate(() => window.__kf.sfx.muted), true);
  console.log('PASS: launcher, local profile, sound preference, and control guide');

  await page.evaluate(() => {
    const g = window.__kf,
      original = g.damageEnemy.bind(g);
    window.contactLog = [];
    g.damageEnemy = (...args) => {
      if (g.muay.active?.phase === 'knee')
        window.contactLog.push({
          gap: Math.hypot(args[0].x - g.player.x, args[0].y - g.player.y),
          damage: args[1],
        });
      return original(...args);
    };
    g.input.focus();
  });
  await page.keyboard.down('k');
  await waitHits(1);
  await page.waitForTimeout(1900);
  await page.keyboard.down('k');
  await page.waitForTimeout(400);
  assert.equal(await page.evaluate(() => window.contactLog.length), 1);
  await page.keyboard.up('k');
  await page.keyboard.press('k');
  await waitHits(2);
  const impacts = await page.evaluate(() => window.contactLog);
  assert.equal(impacts.length, 2);
  assert.ok(impacts.every((i) => i.gap <= 9 && i.damage === 12));
  console.log(
    'PASS: holding K across cooldown does not repeat; each new press delivers exactly one close-range hit',
  );

  await page.waitForTimeout(450);
  await page.getByRole('button', { name: 'Ulangi posisi' }).click();
  await page.getByRole('button', { name: 'UJI CLINCH' }).click();
  await waitHits(1);
  await page.getByRole('button', { name: 'Jeda permainan' }).click();
  await page.getByRole('heading', { name: 'GAME DIJEDA' }).waitFor();
  await page.getByRole('button', { name: 'LANJUTKAN', exact: true }).click();
  await playing();
  await page.getByRole('button', { name: 'Panduan kontrol', exact: true }).click();
  await page.keyboard.press('p');
  assert.equal(await page.evaluate(() => window.__kf.state), 'paused');
  await page.getByRole('button', { name: 'Tutup panel' }).click();
  await playing();
  await page.getByRole('button', { name: 'Lobi', exact: true }).click();
  console.log('PASS: practice reset, test button, pause, resume, and modal input isolation');

  for (const id of ['story', 'survival']) {
    await page.locator(`.mode-${id}`).click();
    await playing();
    await page.waitForFunction(() => window.__kf?.enemies.some((e) => !e.dead));
    assert.equal(await page.evaluate(() => window.__kf.campaign), id === 'story');
    await page.keyboard.press('Escape');
    await page.getByRole('heading', { name: 'GAME DIJEDA' }).waitFor();
    await page.getByRole('button', { name: 'Kembali ke lobi', exact: true }).click();
  }
  await page.getByRole('button', { name: 'Catatan patch' }).click();
  await page.getByRole('heading', { name: 'Single-knee update' }).waitFor();
  await page.keyboard.press('Escape');
  await page.getByRole('link', { name: 'Launcher klasik' }).click();
  await page.waitForFunction(() => window.__kf?.state === 'menu');
  console.log('PASS: original story, survival, patch notes, and preserved classic launcher');

  const mobile = await browser.newPage({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
  });
  mobile.on('pageerror', (e) => errors.push(e.message));
  await mobile.goto(arcade);
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth), 390);
  await mobile.getByRole('button', { name: 'Buka navigasi' }).tap();
  await mobile
    .getByRole('navigation', { name: 'Navigasi seluler' })
    .getByRole('link', { name: 'Daftar Jurus' })
    .tap();
  await mobile.getByRole('button', { name: 'MASUK DOJO LATIHAN' }).tap();
  await mobile.waitForFunction(() => !!window.__kf?.muay.markedTarget(window.__kf));
  await mobile.getByRole('button', { name: 'Clinch', exact: true }).tap();
  await mobile.waitForFunction(() => window.__kf?.muay.contacts === 1);
  await mobile.waitForTimeout(1700);
  assert.equal(await mobile.evaluate(() => window.__kf.muay.contacts), 1);
  console.log('PASS: mobile layout, menu, and single-tap clinch');
  assert.deepEqual(errors, []);
  console.log('PASS: no browser runtime errors');
} finally {
  await browser.close();
}
