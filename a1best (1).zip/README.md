# Pigeon Arcade: Kungfu Drifter

A playable Indonesian arcade launcher for the original Kungfu Drifter game from the supplied PIGEON archive. All game code, artwork, fonts, and sounds are served locally.

## Run

```sh
npm install
npm run dev
```

Use `npm run build` for a production build and `npm run preview` to serve it.

## Play

- **Mulai: Menara Kantor:** the default V2 menu uses the V1 pixel-art office and its title/menu layout. The game itself runs in the V2 office arena.
- **Story Mode / Arena 3/4 Klasik:** play the V2 office campaign or endless top-down waves.
- **Desain Map / Main Map Kustom:** create, save, and play office maps from the V2 map editor.
- **Cara Main > Masuk Dojo Latihan:** try the new clinch on a practice partner. Press **K**, right-click, or select **Uji Clinch**.
- **Mode Lain:** open team battles, view the scoreboard, switch to V1, or open the optional illustrated arcade lobby (`?arcade=1`).

Use the arrow keys and Enter or a mouse/touchscreen to navigate the menu. In the arena, WASD moves, J or left-click attacks, K or right-click performs a heavy attack or contextual clinch, Space jumps, Shift dashes, and Escape pauses.

## Single-Knee Update

`src/original/v2/games/maxkungfu/game/singleClinch.ts` replaces the three-hit loop with an approach, a grab, one timed contact, and recovery. A per-action latch prevents duplicate damage. Both skeletons use a shared world-space anchor, including the front knee when the original IK solver would otherwise return a straight leg. Movement respects the original map collisions. The target is released with restrained recoil instead of an exaggerated launch.

The illustrated dojo presentation is in `src/game/dojoRenderer.ts`. The original combat engine remains authoritative. `src/App.tsx` is the launcher entry point.

## Foot Mode (V2)

The equipment picker and Q/mouse-wheel cycle begin with **Fist Mode / Foot Mode / Pistol Mode**. **O** equips Foot Mode directly. In Story Mode, Foot Mode is available from the beginning; firearm unlocks still follow the campaign.

- **J / left-click:** Flow Combo: Rasteira Sweep, Side Snap, Lotus Wheel, Ember Crescent.
- **K / right-click:** Power Combo: Moon Sweep, Tornado Heel, Blazing Comet.
- **I, J, J, K:** Flamingo Rush, inspired by Hwoarang. Switch the lead leg with I, land Switch Double (two separately timed contacts), link Reverse Hook, and finish with Heel Breaker. Pressing I during recovery queues the next switch. **Shift+I** still equips Buster Sword from Foot Mode.
- **J, J, K, J:** Crossflow. Land Side Snap and Crosswind to link into Cinder Dragon.
- **S + K:** Rising Lotus launcher. **W + K**, or an attack while running or dashing, performs a Comet Back Kick.
- **Jump, then J / K:** Sky Scissors and Sky Tornado, or the Comet Drop finisher.
- **Cara Main > Jurus Foot Mode > Latihan Foot Mode:** practice kicks and aerial links against the Dojo partner.

Foot Mode buffers up to two attacks in order, including taps made during hitstop. A confirmed hit opens a quicker transition instead of restarting from a neutral pose. Short, collision-checked approach steps help nearby kicks connect without reaching through walls or across floors. The Dojo has Flamingo, Flow, Mix, and Aerial drills with step, hit, and session-best feedback. Its Flamingo button switches stance on touchscreens. Tap or click **Angkat** to practice Rising Lotus without a keyboard chord. Jump can be queued during Rising Lotus and starts only after it connects.

The dedicated moves, pose curves, and ankle trails are in `footwork.ts`, `footPoses.ts`, and `footEffects.ts` under `src/original/v2/games/maxkungfu/game/`. They use the V2 engine's standard collision, damage, and recovery. The previous Fist kick shortcut is available with **Shift+L**, and boxing can be selected with **Shift+J** or the equipment picker.

## Verification

With the development server running:

```sh
npx playwright install chromium
node scripts/verify-v2-menu.mjs http://127.0.0.1:5173
node scripts/verify-foot-mode.mjs http://127.0.0.1:5173
node scripts/verify-foot-flow.mjs http://127.0.0.1:5173
node scripts/verify-flamingo.mjs http://127.0.0.1:5173
node scripts/verify-arcade.mjs http://127.0.0.1:5173
node scripts/verify-contact.mjs http://127.0.0.1:5173
npx tsc --noEmit
```

The browser checks cover the V1-style V2 menu, keyboard and touch navigation, custom maps, version switching, and the optional arcade lobby. Foot Mode checks cover tap order, timed hit-confirm links, combo drills, early jump inputs, portrait play, and pause/resume. The original Muay Thai check still verifies a single contact per input.

## Source

Original game: https://github.com/akuamirkap-cyber/PIGEON/blob/main/enhance-combat-and-animations.zip

The supplied source is preserved in `src/original`, with the targeted V2 combat and input changes. Game progress and profile preferences are stored only in this browser.