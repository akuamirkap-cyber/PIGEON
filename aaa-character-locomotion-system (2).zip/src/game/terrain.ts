import { smoothstep } from './math';

export interface Box {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
  h: number;
}
export interface Ramp extends Omit<Box, 'h'> {
  h0: number;
  h1: number;
  axis: 'x' | 'z';
}
export interface Pillar {
  x: number;
  z: number;
  r: number;
}

/**
 * Analytic walkable height field. Pure math (no rendering) so the controller,
 * foot IK and camera can all sample it cheaply — and it can run headless.
 */
export class Terrain {
  boxes: Box[] = [];
  ramps: Ramp[] = [];
  pillars: Pillar[] = [];
  readonly bound = 78;

  constructor() {
    // Staircase → deck → ramp (foot IK on steps and slopes)
    const n = 6;
    const rise = 0.17;
    const run = 0.4;
    const sz = 6;
    for (let i = 0; i < n; i++) {
      this.boxes.push({ x0: 5, x1: 8, z0: sz + i * run, z1: sz + n * run, h: rise * (i + 1) });
    }
    const top = rise * n;
    this.boxes.push({ x0: 4, x1: 9, z0: sz + n * run, z1: sz + n * run + 4.6, h: top });
    this.ramps.push({ x0: -1.5, x1: 4, z0: 9.8, z1: 12.4, h0: 0, h1: top, axis: 'x' });

    // Jump course: ascending crates
    this.boxes.push({ x0: -7, x1: -5, z0: 4, z1: 6.2, h: 0.45 });
    this.boxes.push({ x0: -9.6, x1: -7.4, z0: 4.4, z1: 6.6, h: 0.9 });
    this.boxes.push({ x0: -13, x1: -10, z0: 4, z1: 7.2, h: 1.35 });

    // Low slabs you can simply step onto
    this.boxes.push({ x0: -4.5, x1: -1.2, z0: 14.5, z1: 17.5, h: 0.14 });
    this.boxes.push({ x0: -3.8, x1: -1.9, z0: 15.2, z1: 16.8, h: 0.28 });

    // Tree trunks (solid obstacles, deterministic scatter)
    let seed = 1337;
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < 90; i++) {
      const a = rnd() * Math.PI * 2;
      const r = 24 + rnd() * 80;
      const x = Math.sin(a) * r;
      const z = Math.cos(a) * r;
      const pr = 0.3 + rnd() * 0.15;
      if (x > 4 && Math.abs(z) < 8) continue; // keep the firing lane (+X) clear
      this.pillars.push({ x, z, r: pr });
    }
  }

  /** Natural snow surface: flat training field, ripple patch, mound, rolling hills. */
  base(x: number, z: number): number {
    const r = Math.hypot(x, z);
    let h =
      (1.5 * Math.sin(x * 0.06 + 0.4) * Math.cos(z * 0.055 + 1.1) +
        0.6 * Math.sin(x * 0.13 + z * 0.11 + 2)) *
      smoothstep(19, 46, r);
    // ripple patch (uneven ground for foot alignment)
    const rx = x + 6;
    const rz = z + 9;
    const rm = 1 - smoothstep(3.2, 6, Math.hypot(rx, rz));
    if (rm > 0) h += 0.1 * rm * Math.sin(x * 2.2) * Math.sin(z * 2.0);
    // smooth mound
    const mx = x - 10;
    const mz = z + 7;
    const md = (mx * mx + mz * mz) / 14;
    if (md < 8) h += 0.85 * Math.exp(-md);
    return h;
  }

  height(x: number, z: number): number {
    let h = this.base(x, z);
    for (const b of this.boxes) {
      if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && b.h > h) h = b.h;
    }
    for (const r of this.ramps) {
      if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) {
        const t = r.axis === 'x' ? (x - r.x0) / (r.x1 - r.x0) : (z - r.z0) / (r.z1 - r.z0);
        const rh = r.h0 + (r.h1 - r.h0) * t;
        if (rh > h) h = rh;
      }
    }
    return h;
  }

  /** Is this point inside a tree trunk (plus margin)? Used by the camera arm. */
  trunk(x: number, z: number, margin: number): boolean {
    for (const p of this.pillars) {
      const dx = x - p.x;
      const dz = z - p.z;
      const rr = p.r + margin;
      if (dx * dx + dz * dz < rr * rr) return true;
    }
    return false;
  }

  /**
   * Bullet ray vs. height field + tree trunks. Marches then bisects.
   * Returns the hit distance or Infinity.
   */
  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, tMin: number, tMax: number): number {
    const inside = (t: number) => {
      const x = ox + dx * t;
      const y = oy + dy * t;
      const z = oz + dz * t;
      const h = this.height(x, z);
      return y < h || (y < h + 5 && this.trunk(x, z, 0));
    };
    let prev = tMin;
    let t = tMin;
    while (t < tMax) {
      if (inside(t)) {
        let a = prev;
        let b = t;
        for (let i = 0; i < 9; i++) {
          const m = (a + b) / 2;
          if (inside(m)) b = m;
          else a = m;
        }
        return b;
      }
      prev = t;
      t += Math.min(0.5, 0.2 + t * 0.01);
    }
    return Infinity;
  }

  /** Non-walkable solid (tree trunks, world bound). */
  solid(x: number, z: number): boolean {
    if (x * x + z * z > this.bound * this.bound) return true;
    for (const p of this.pillars) {
      const dx = x - p.x;
      const dz = z - p.z;
      const rr = p.r + 0.28;
      if (dx * dx + dz * dz < rr * rr) return true;
    }
    return false;
  }
}
