import * as THREE from 'three';
import { Terrain } from './terrain';
import { CharacterController, Intent, LocoState, PACE_NAMES, STATES } from './controller';
import { Animator } from './animator';
import { Rig, Scarf } from './rig';
import { FollowCamera } from './camera';
import { Environment } from './environment';
import { Input } from './input';
import { Foley } from './audio';
import { Arsenal } from './weapons';
import { Range } from './targets';

export interface Hud {
  state: LocoState;
  weights: number[];
  speed: number;
  pace: string;
  sprinting: boolean;
  crouching: boolean;
  strafing: boolean;
  grounded: boolean;
  phase: number;
  contactL: number;
  contactR: number;
  cadence: number;
  lean: number;
  bank: number;
  slowmo: boolean;
  debug: boolean;
  muted: boolean;
  fps: number;
  engaged: boolean;
  // weapons / view
  armed: boolean;
  slot: number;
  weapon: string;
  fireMode: string;
  ammo: number;
  mag: number;
  ammoAll: number[];
  reload: number;
  firstPerson: boolean;
  ads: boolean;
  scope: number;
  spread: number;
  hits: number;
  shots: number;
  lastDist: number;
  hitAge: number;
}

const SPAWN = { x: 0, z: -2 };

export class Game {
  input: Input;
  hud: Hud;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private cam: THREE.PerspectiveCamera;
  private terrain = new Terrain();
  private ctrl = new CharacterController();
  private rig = new Rig();
  private anim: Animator;
  private scarf: Scarf;
  private follow: FollowCamera;
  private env: Environment;
  private foley = new Foley();
  private range: Range;
  private arsenal: Arsenal;
  private raf = 0;
  private last = 0;
  private time = 0;
  private timeScale = 1;
  private timeScaleT = 1;
  private fpsAcc = 0;
  private fpsN = 0;
  private gizmo = new THREE.Group();
  private gTargets: THREE.Mesh[] = [];
  private gPlants: THREE.Mesh[] = [];
  private gVel: THREE.ArrowHelper;
  private gIntent: THREE.ArrowHelper;
  private ro: ResizeObserver;
  private host: HTMLElement;
  private v = new THREE.Vector3();

  constructor(canvas: HTMLCanvasElement, host: HTMLElement) {
    this.host = host;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.95;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.cam = new THREE.PerspectiveCamera(52, 1, 0.08, 900);
    this.env = new Environment(this.scene, this.terrain);

    this.ctrl.reset(SPAWN.x, SPAWN.z, this.terrain);
    this.anim = new Animator(this.rig);
    this.anim.reset(this.ctrl, this.terrain);
    this.scene.add(this.rig.root);
    // settle the pose once so the scarf initialises on the real skeleton
    this.anim.update(1 / 60, this.ctrl, this.terrain, 0, 0, 0);
    this.scarf = new Scarf(this.rig);
    this.scene.add(this.scarf.mesh);

    this.follow = new FollowCamera(this.cam);
    this.follow.snap(this.ctrl);

    this.range = new Range(this.scene, this.terrain, SPAWN);
    this.arsenal = new Arsenal(this.scene, this.rig, this.terrain, this.range, this.foley);

    // ---- debug gizmos
    const tMat = new THREE.MeshBasicMaterial({ color: '#35e0ff', depthTest: false, transparent: true, opacity: 0.9 });
    const pMat = new THREE.MeshBasicMaterial({ color: '#7dff8a', depthTest: false, transparent: true, opacity: 0.9 });
    for (let i = 0; i < 2; i++) {
      const t = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), tMat);
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.1, 0.125, 24), pMat);
      ring.rotation.x = -Math.PI / 2;
      t.renderOrder = ring.renderOrder = 10;
      this.gTargets.push(t);
      this.gPlants.push(ring);
      this.gizmo.add(t, ring);
    }
    this.gVel = new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), new THREE.Vector3(), 1, 0x35e0ff, 0.18, 0.1);
    this.gIntent = new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), new THREE.Vector3(), 1, 0xffa23a, 0.18, 0.1);
    this.gizmo.add(this.gVel, this.gIntent);
    this.gizmo.visible = false;
    this.scene.add(this.gizmo);

    this.input = new Input(canvas);
    this.input.onEngage = () => {
      this.hud.engaged = true;
      this.foley.unlock();
    };
    this.input.onAction = (a) => {
      if (a === 'slowmo') {
        this.timeScaleT = this.timeScaleT < 1 ? 1 : 0.2;
        this.hud.slowmo = this.timeScaleT < 1;
      } else if (a === 'debug') {
        this.gizmo.visible = !this.gizmo.visible;
        this.hud.debug = this.gizmo.visible;
      } else if (a === 'mute') {
        this.foley.muted = !this.foley.muted;
        this.hud.muted = this.foley.muted;
      } else if (a === 'camera') {
        this.follow.toggleMode();
      } else if (a === 'reset') {
        this.ctrl.reset(SPAWN.x, SPAWN.z, this.terrain);
        this.anim.reset(this.ctrl, this.terrain);
        this.follow.snap(this.ctrl);
      }
    };

    this.hud = {
      state: 'IDLE',
      weights: STATES.map(() => 0),
      speed: 0,
      pace: 'RUN',
      sprinting: false,
      crouching: false,
      strafing: false,
      grounded: true,
      phase: 0,
      contactL: 1,
      contactR: 1,
      cadence: 0,
      lean: 0,
      bank: 0,
      slowmo: false,
      debug: false,
      muted: false,
      fps: 60,
      engaged: false,
      armed: false,
      slot: -1,
      weapon: 'UNARMED',
      fireMode: '',
      ammo: 0,
      mag: 0,
      ammoAll: [0, 0, 0],
      reload: 0,
      firstPerson: false,
      ads: false,
      scope: 0,
      spread: 0,
      hits: 0,
      shots: 0,
      lastDist: 0,
      hitAge: 9,
    };

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(host);
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  private resize() {
    const w = Math.max(1, this.host.clientWidth);
    const h = Math.max(1, this.host.clientHeight);
    this.renderer.setSize(w, h, false);
    this.cam.aspect = w / h;
    this.cam.updateProjectionMatrix();
  }

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const raw = Math.min((now - this.last) / 1000, 0.05);
    this.last = now;
    if (raw <= 0) return;
    this.fpsAcc += raw;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.hud.fps = Math.round(this.fpsN / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsN = 0;
    }
    this.timeScale += (this.timeScaleT - this.timeScale) * Math.min(1, raw * 8);
    const dt = raw * this.timeScale;

    const f = this.input.sample(raw);
    // look sensitivity scales with zoom so scoped aiming stays controllable
    const sens = Math.min(1, this.cam.fov / 60);
    this.follow.look(f.lookX * sens, f.lookY * sens);

    const ars = this.arsenal;
    const fp = this.follow.firstPerson;
    // aiming or shooting always wins over sprinting; first person only sprints forward
    let sprint = f.sprint && !f.aim && !(ars.armed && f.fire);
    if (fp && f.moveY < 0.5) sprint = false;

    this.follow.steer(raw, this.ctrl, ars.scopeW > 0.35 || (!!ars.def?.scope && ars.ads));
    ars.tick(dt, f, this.ctrl, this.follow.aimYaw, this.follow.aimPitch, fp);

    const intent: Intent = {
      moveX: f.moveX,
      moveY: f.moveY,
      sprint,
      jumpPressed: f.jumpPressed,
      jumpHeld: f.jumpHeld,
      crouchToggle: f.crouchToggle,
      strafe: f.strafeToggle || (!ars.armed && f.aim),
      pace: f.pace,
      // weapon up (or first person) → body squares up to the camera
      lockFacing: fp || (ars.facing && !sprint),
      speedCap: ars.ads ? 2.3 : undefined,
    };

    // fixed-size sub-steps keep springs/gait identical at any frame rate
    const n = Math.max(1, Math.ceil(dt / (1 / 90)));
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      if (i > 0) {
        intent.jumpPressed = false;
        intent.crouchToggle = false;
      }
      this.ctrl.update(h, intent, this.follow.yaw, this.terrain);
      this.time += h;
      this.anim.update(h, this.ctrl, this.terrain, this.time, this.follow.aimYaw, this.follow.aimPitch, ars.pose);
    }
    this.rig.root.updateMatrixWorld(true);
    this.scarf.update(Math.max(dt, 1e-4), this.time);

    for (const s of this.anim.steps) {
      this.env.addFootprint(s);
      this.foley.step(s.strength, s.side);
    }
    this.anim.steps.length = 0;

    this.follow.update(raw, this.ctrl, this.anim, this.terrain, {
      ads: ars.armed ? this.anim.adsW : 0,
      zoom: ars.def ? ars.def.zoom : 1,
      scope: ars.scopeW,
    });
    // shots resolve after the camera so the ray passes exactly through the crosshair
    this.cam.updateMatrixWorld();
    const kick = ars.shoot(this.cam, this.follow.camDist);
    if (kick > 0) this.follow.kick(kick);
    ars.updateFx(dt);
    this.range.update(dt, this.time);

    // first person hides the head; the scope hides the whole body
    const scoped = ars.scopeW > 0.6;
    this.rig.root.visible = !scoped;
    this.scarf.mesh.visible = !scoped;
    this.rig.neck.visible = this.follow.fpW < 0.5;

    this.env.update(dt, this.ctrl.pos, this.time);
    if (this.gizmo.visible) this.updateGizmo();
    this.renderer.render(this.scene, this.cam);

    // ---- HUD snapshot
    const hud = this.hud;
    const c = this.ctrl;
    hud.state = c.state;
    for (let i = 0; i < STATES.length; i++) hud.weights[i] = c.weights[STATES[i]];
    hud.speed = c.speed;
    hud.pace = PACE_NAMES[f.pace] ?? 'RUN';
    hud.sprinting = c.sprinting;
    hud.crouching = c.crouching;
    hud.strafing = c.strafing;
    hud.grounded = c.grounded;
    hud.phase = this.anim.phase;
    hud.contactL = this.anim.feet[0].contact;
    hud.contactR = this.anim.feet[1].contact;
    hud.cadence = this.anim.cadence;
    hud.lean = this.anim.leanOut;
    hud.bank = this.anim.bankOut;
    const def = ars.def;
    hud.armed = !!def;
    hud.slot = ars.slot;
    hud.weapon = def ? def.name : 'UNARMED';
    hud.fireMode = def ? def.mode : '';
    hud.ammo = def ? ars.ammo[ars.slot] : 0;
    hud.mag = def ? def.mag : 0;
    for (let i = 0; i < 3; i++) hud.ammoAll[i] = ars.ammo[i];
    hud.reload = ars.reloadK;
    hud.firstPerson = this.follow.firstPerson;
    hud.ads = ars.ads;
    hud.scope = ars.scopeW;
    hud.spread = ars.spread;
    hud.hits = ars.hits;
    hud.shots = ars.shots;
    hud.lastDist = ars.lastDist;
    hud.hitAge = ars.hitAge;
  };

  private updateGizmo() {
    const c = this.ctrl;
    for (let i = 0; i < 2; i++) {
      const f = this.anim.feet[i];
      this.gTargets[i].visible = f.mode === 1;
      this.gTargets[i].position.copy(f.target).y += 0.03;
      this.gPlants[i].visible = f.mode === 0;
      this.gPlants[i].position.set(f.pos.x, f.pos.y + 0.02, f.pos.z);
    }
    const o = this.v.set(c.pos.x, c.pos.y + 0.05, c.pos.z);
    this.gVel.position.copy(o);
    this.gVel.visible = c.speed > 0.1;
    if (c.speed > 0.1) {
      this.gVel.setDirection(new THREE.Vector3(c.vel.x, 0, c.vel.z).normalize());
      this.gVel.setLength(0.4 + c.speed * 0.22, 0.18, 0.1);
    }
    this.gIntent.position.copy(o);
    this.gIntent.visible = c.hasInput;
    if (c.hasInput) {
      this.gIntent.setDirection(new THREE.Vector3(Math.sin(c.moveYaw), 0, Math.cos(c.moveYaw)));
      this.gIntent.setLength(0.9, 0.18, 0.1);
    }
  }

  toggleCamera() {
    this.follow.toggleMode();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.input.dispose();
    this.renderer.dispose();
  }
}
