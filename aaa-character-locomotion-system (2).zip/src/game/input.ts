export interface Frame {
  moveX: number;
  moveY: number;
  sprint: boolean;
  jumpPressed: boolean;
  jumpHeld: boolean;
  crouchToggle: boolean;
  strafeToggle: boolean;
  pace: number;
  lookX: number;
  lookY: number;
  // weapons
  fire: boolean;
  firePressed: boolean;
  aim: boolean;
  reloadPressed: boolean;
  /** null = none, -1 = holster, -2 = cycle, 0..2 = slot */
  slot: number | null;
}

export type Action = 'slowmo' | 'debug' | 'reset' | 'mute' | 'camera';

const MOVE_KEYS = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);
const BLOCK = new Set(['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab']);

/** Keyboard + mouse (pointer-lock or drag), gamepad and touch → one Frame. */
export class Input {
  pace = 2;
  strafeToggle = false;
  onAction: (a: Action) => void = () => {};
  onEngage: () => void = () => {};

  // touch state (written by the on-screen controls)
  touchMove = { x: 0, y: 0 };
  touchSprint = false;
  touchFire = false;
  touchAim = false;

  private keys = new Set<string>();
  private lookX = 0;
  private lookY = 0;
  private jumpEdge = false;
  private crouchEdge = false;
  private fireEdge = false;
  private reloadEdge = false;
  private slotReq: number | null = null;
  private lmb = false;
  private rmb = false;
  private el: HTMLElement;
  private padPrev: boolean[] = [];
  private padSprint = false;
  private off: Array<() => void> = [];

  constructor(el: HTMLElement) {
    this.el = el;
    const on = (t: EventTarget, k: string, fn: (e: never) => void, opt?: AddEventListenerOptions) => {
      t.addEventListener(k, fn as EventListener, opt);
      this.off.push(() => t.removeEventListener(k, fn as EventListener, opt));
    };

    on(window, 'keydown', (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) return;
      if (BLOCK.has(e.code)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      switch (e.code) {
        case 'Space':
          this.jumpEdge = true;
          break;
        case 'KeyC':
          this.crouchEdge = true;
          break;
        case 'KeyX':
          this.pace = (this.pace + 2) % 3;
          break;
        case 'KeyF':
          this.strafeToggle = !this.strafeToggle;
          break;
        case 'Digit1':
          this.slotReq = 0;
          break;
        case 'Digit2':
          this.slotReq = 1;
          break;
        case 'Digit3':
          this.slotReq = 2;
          break;
        case 'Digit4':
        case 'KeyH':
          this.slotReq = -1;
          break;
        case 'KeyQ':
          this.slotReq = -2;
          break;
        case 'KeyR':
          this.reloadEdge = true;
          break;
        case 'KeyV':
          this.onAction('camera');
          break;
        case 'KeyT':
          this.onAction('slowmo');
          break;
        case 'KeyG':
          this.onAction('debug');
          break;
        case 'KeyP':
          this.onAction('reset');
          break;
        case 'KeyM':
          this.onAction('mute');
          break;
      }
      if (MOVE_KEYS.has(e.code) || /^(Space|KeyC|Shift|Digit[1-4]|KeyQ|KeyV)/.test(e.code)) this.onEngage();
    });
    on(window, 'keyup', (e: KeyboardEvent) => this.keys.delete(e.code));
    on(window, 'blur', () => {
      this.keys.clear();
      this.rmb = this.lmb = false;
    });

    on(el, 'mousedown', (e: MouseEvent) => {
      this.onEngage();
      if (e.button === 2) this.rmb = true;
      if (e.button === 0) {
        this.lmb = true;
        this.fireEdge = true;
        if (document.pointerLockElement !== el) {
          try {
            const r = el.requestPointerLock() as unknown as Promise<void> | undefined;
            if (r && typeof r.catch === 'function') r.catch(() => {});
          } catch {
            /* sandboxed iframe: fall back to drag-look */
          }
        }
      }
    });
    on(window, 'mouseup', (e: MouseEvent) => {
      if (e.button === 2) this.rmb = false;
      if (e.button === 0) this.lmb = false;
    });
    on(el, 'contextmenu', (e: Event) => e.preventDefault());
    on(window, 'mousemove', (e: MouseEvent) => {
      // pointer-locked: free look. Otherwise look while a button is held (drag).
      if (document.pointerLockElement === el || this.lmb || this.rmb) {
        this.lookX += e.movementX * 0.0024;
        this.lookY += e.movementY * 0.0022;
      }
    });
    on(
      el,
      'wheel',
      (e: WheelEvent) => {
        e.preventDefault();
        this.pace = Math.max(0, Math.min(2, this.pace + (e.deltaY < 0 ? 1 : -1)));
      },
      { passive: false },
    );
  }

  addLook(dx: number, dy: number) {
    this.lookX += dx;
    this.lookY += dy;
  }
  pressJump() {
    this.jumpEdge = true;
  }
  pressCrouch() {
    this.crouchEdge = true;
  }
  pressFire() {
    this.fireEdge = true;
  }
  pressReload() {
    this.reloadEdge = true;
  }
  requestSlot(s: number) {
    this.slotReq = s;
  }

  sample(dt: number): Frame {
    const k = this.keys;
    let mx = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
    let my = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
    let sprint = k.has('ShiftLeft') || k.has('ShiftRight') || this.touchSprint;
    let jumpHeld = k.has('Space');
    let fire = this.lmb || this.touchFire;
    let aim = this.rmb || this.touchAim;

    if (Math.hypot(this.touchMove.x, this.touchMove.y) > 0.05) {
      mx = this.touchMove.x;
      my = this.touchMove.y;
    }

    // gamepad (standard mapping): LT aim, RT fire, A jump, B crouch, X reload, Y next weapon, L3 sprint, R3 camera
    const pads = typeof navigator !== 'undefined' && navigator.getGamepads ? navigator.getGamepads() : [];
    const gp = pads && Array.from(pads).find((p) => p && p.connected && p.mapping === 'standard');
    if (gp) {
      const dz = (v: number) => (Math.abs(v) < 0.16 ? 0 : (v - Math.sign(v) * 0.16) / 0.84);
      const ax = dz(gp.axes[0]);
      const ay = dz(gp.axes[1]);
      if (ax || ay) {
        mx = ax;
        my = -ay;
        this.onEngage();
      }
      const rx = dz(gp.axes[2]);
      const ry = dz(gp.axes[3]);
      this.lookX += rx * Math.abs(rx) * 3.2 * dt;
      this.lookY += ry * Math.abs(ry) * 2.2 * dt;
      const b = gp.buttons.map((x) => x.pressed);
      const edge = (i: number) => b[i] && !this.padPrev[i];
      if (edge(0)) this.jumpEdge = true;
      if (edge(1)) this.crouchEdge = true;
      if (edge(2)) this.reloadEdge = true;
      if (edge(3)) this.slotReq = -2;
      if (edge(7)) this.fireEdge = true;
      if (edge(10)) this.padSprint = !this.padSprint;
      if (edge(11)) this.onAction('camera');
      if (!ax && !ay) this.padSprint = false;
      if (this.padSprint) sprint = true;
      if (b[6]) aim = true;
      if (b[7]) fire = true;
      if (b[0]) jumpHeld = true;
      this.padPrev = b;
    }

    const f: Frame = {
      moveX: mx,
      moveY: my,
      sprint,
      jumpPressed: this.jumpEdge,
      jumpHeld: jumpHeld || this.jumpEdge,
      crouchToggle: this.crouchEdge,
      strafeToggle: this.strafeToggle,
      pace: this.pace,
      lookX: this.lookX,
      lookY: this.lookY,
      fire,
      firePressed: this.fireEdge,
      aim,
      reloadPressed: this.reloadEdge,
      slot: this.slotReq,
    };
    this.lookX = this.lookY = 0;
    this.jumpEdge = this.crouchEdge = this.fireEdge = this.reloadEdge = false;
    this.slotReq = null;
    return f;
  }

  dispose() {
    for (const o of this.off) o();
    if (document.pointerLockElement === this.el) document.exitPointerLock();
  }
}
