import * as THREE from 'three';
import type { Terrain } from './terrain';
import { Spring } from './math';

interface Target {
  root: THREE.Group; // hinged at the base of the post
  center: THREE.Vector3; // plate centre (rest pose, world)
  normal: THREE.Vector3;
  r: number;
  swing: Spring;
  flash: number;
  mat: THREE.MeshStandardMaterial;
  baseZ: number;
  amp: number;
  phase: number;
}

/** Steel popper targets down the firing lane (+X from spawn), plus a few on the props. */
export class Range {
  private list: Target[] = [];
  private tmp = new THREE.Vector3();

  constructor(scene: THREE.Scene, terrain: Terrain, spawn: { x: number; z: number }) {
    const post = new THREE.MeshStandardMaterial({ color: '#39424f', roughness: 0.6, metalness: 0.5 });
    const white = new THREE.MeshStandardMaterial({ color: '#f1f4f8', roughness: 0.6 });
    const spots: Array<[number, number, number, number]> = [
      // x, z, radius, lateral sweep amplitude
      [12, -1.5, 0.3, 0],
      [17, 2.5, 0.3, 0],
      [24, -2.5, 0.32, 0],
      [29, 0.5, 0.32, 3.2],
      [36, 1.5, 0.34, 0],
      [47, -2, 0.36, 0],
      [60, 2, 0.4, 0],
      [73, 0, 0.45, 0],
      [-11.5, 5.6, 0.28, 0],
      [6.5, 11.6, 0.28, 0],
      [-3, -24, 0.32, 0],
    ];
    const H = 1.3;
    spots.forEach(([x, z, r, amp], i) => {
      const root = new THREE.Group();
      const y = terrain.height(x, z);
      root.position.set(x, y, z);
      const n = new THREE.Vector3(spawn.x - x, 0, spawn.z - z).normalize();
      root.rotation.y = Math.atan2(n.x, n.z);
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, H, 8), post);
      p.position.y = H / 2;
      const foot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.35), post);
      foot.position.y = 0.025;
      const mat = new THREE.MeshStandardMaterial({ color: '#f07f22', roughness: 0.5, metalness: 0.3, emissive: '#000000' });
      const disc = (rad: number, m: THREE.Material, zz: number) => {
        const g = new THREE.CylinderGeometry(rad, rad, 0.025, 28);
        g.rotateX(Math.PI / 2);
        const mesh = new THREE.Mesh(g, m);
        mesh.position.set(0, H, zz);
        mesh.castShadow = true;
        return mesh;
      };
      root.add(p, foot, disc(r, mat, 0.03), disc(r * 0.68, white, 0.036), disc(r * 0.36, mat, 0.042));
      p.castShadow = true;
      scene.add(root);
      this.list.push({
        root,
        center: new THREE.Vector3(x, y + H, z).addScaledVector(n, 0.04),
        normal: n,
        r,
        swing: new Spring(9, 0.28),
        flash: 0,
        mat,
        baseZ: z,
        amp,
        phase: i * 1.3,
      });
    });
  }

  /** Ray vs. target plates. */
  raycast(o: THREE.Vector3, d: THREE.Vector3, tMin: number, tMax: number): { t: number; index: number } | null {
    let best: { t: number; index: number } | null = null;
    for (let i = 0; i < this.list.length; i++) {
      const tg = this.list[i];
      const dn = d.dot(tg.normal);
      if (Math.abs(dn) < 1e-4) continue;
      const t = this.tmp.subVectors(tg.center, o).dot(tg.normal) / dn;
      if (t < tMin || t > tMax || (best && t > best.t)) continue;
      this.tmp.copy(o).addScaledVector(d, t).sub(tg.center);
      if (this.tmp.lengthSq() <= tg.r * tg.r) best = { t, index: i };
    }
    return best;
  }

  hit(i: number, power: number) {
    const tg = this.list[i];
    tg.swing.v -= 9 * power;
    tg.flash = 1;
  }

  update(dt: number, time: number) {
    for (const tg of this.list) {
      if (tg.amp > 0) {
        const z = tg.baseZ + Math.sin(time * 0.7 + tg.phase) * tg.amp;
        tg.center.z += z - tg.root.position.z;
        tg.root.position.z = z;
      }
      tg.swing.update(0, dt);
      // knocked back around the base hinge, then rings back upright
      tg.root.rotation.x = Math.max(-1.1, Math.min(0.5, tg.swing.x));
      tg.root.rotation.order = 'YXZ';
      if (tg.flash > 0) {
        tg.flash = Math.max(0, tg.flash - dt * 3.5);
        tg.mat.emissive.setRGB(tg.flash * 0.9, tg.flash * 0.75, tg.flash * 0.4);
      }
    }
  }
}
