/** Tiny synthesised foley: snow-crunch footsteps and landing thumps. */
export class Foley {
  muted = false;
  private ctx: AudioContext | null = null;
  private noise: AudioBuffer | null = null;
  private master: GainNode | null = null;

  /** Must be called from a user gesture. */
  unlock() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      const len = this.ctx.sampleRate * 0.4;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
    } catch {
      this.ctx = null;
    }
  }

  step(strength: number, side: number) {
    const ctx = this.ctx;
    if (!ctx || !this.noise || !this.master || this.muted || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.7 + Math.random() * 0.35;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 900 + Math.random() * 700 + strength * 500;
    bp.Q.value = 0.8;
    const g = ctx.createGain();
    const vol = 0.05 + 0.2 * strength;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 0.11 + strength * 0.08);
    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    src.connect(bp).connect(g);
    if (pan) {
      pan.pan.value = -side * 0.18;
      g.connect(pan).connect(this.master);
    } else g.connect(this.master);
    src.start(t, Math.random() * 0.2, 0.25);

    if (strength > 0.65) {
      // low body thump for landings
      const o = ctx.createOscillator();
      const og = ctx.createGain();
      o.frequency.setValueAtTime(95, t);
      o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
      og.gain.setValueAtTime(0.22 * strength, t);
      og.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      o.connect(og).connect(this.master);
      o.start(t);
      o.stop(t + 0.2);
    }
  }

  private burst(dur: number, freq: number, q: number, vol: number, type: BiquadFilterType = 'bandpass') {
    const ctx = this.ctx;
    if (!ctx || !this.noise || !this.master || this.muted || ctx.state !== 'running') return null;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random() * 0.1, dur + 0.05);
    return { ctx, t };
  }

  private thump(f0: number, f1: number, dur: number, vol: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  /** Gunshot: 0 pistol (snappy), 1 rifle (tight), 2 sniper (heavy with tail). */
  shot(kind: number) {
    if (kind === 0) {
      this.burst(0.11, 1900, 0.5, 0.5);
      this.thump(190, 70, 0.09, 0.45);
    } else if (kind === 1) {
      this.burst(0.12, 1400, 0.4, 0.5);
      this.burst(0.05, 5200, 0.8, 0.25, 'highpass');
      this.thump(150, 55, 0.1, 0.5);
    } else {
      this.burst(0.42, 900, 0.3, 0.75);
      this.burst(0.9, 420, 0.4, 0.22, 'lowpass');
      this.thump(110, 34, 0.26, 0.85);
    }
  }

  /** Mechanical click (dry fire, magazine, draw). */
  click(strength: number) {
    this.burst(0.03, 3200 + strength * 1200, 2.5, 0.12 + 0.14 * strength);
    this.thump(900, 500, 0.02, 0.05 * strength);
  }

  /** Steel target ring. */
  ping() {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    for (const [f, v, d] of [
      [1480 + Math.random() * 120, 0.16, 0.5],
      [2350 + Math.random() * 150, 0.09, 0.35],
      [3900, 0.04, 0.2],
    ]) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = f;
      g.gain.setValueAtTime(v, t);
      g.gain.exponentialRampToValueAtTime(0.0008, t + d);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + d + 0.02);
    }
  }
}
