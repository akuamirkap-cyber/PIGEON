import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

/** Skeleton proportions in metres (≈1.78 m tall). */
export const DIM = {
  hipH: 0.955, // standing hip-joint height (knees nearly straight at rest)
  hipW: 0.095, // half pelvis width
  hipDown: 0.02,
  thigh: 0.44,
  shin: 0.44,
  ankleH: 0.085,
  heelBack: 0.06,
  ballFwd: 0.13,
  upperArm: 0.29,
  foreArm: 0.26,
};

export interface ArmRig {
  upper: THREE.Object3D;
  fore: THREE.Object3D;
  hand: THREE.Object3D;
}
export interface LegRig {
  thigh: THREE.Object3D;
  shin: THREE.Object3D;
  foot: THREE.Object3D;
  toe: THREE.Object3D;
}

const unitSphere = new THREE.SphereGeometry(1, 28, 18);

function std(color: string, roughness = 0.82, metalness = 0) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}
function ell(m: THREE.Material, rx: number, ry: number, rz: number, x = 0, y = 0, z = 0) {
  const mesh = new THREE.Mesh(unitSphere, m);
  mesh.scale.set(rx, ry, rz);
  mesh.position.set(x, y, z);
  return mesh;
}
/** Tapered limb segment hanging along -Y from its joint, with rounded ends. */
function limb(m: THREE.Material, rTop: number, rBot: number, len: number, depth = 1) {
  const g = new THREE.Group();
  const cyl = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, len, 18, 1, true), m);
  cyl.position.y = -len / 2;
  cyl.scale.z = depth;
  g.add(cyl, ell(m, rTop, rTop, rTop * depth), ell(m, rBot, rBot, rBot * depth, 0, -len, 0));
  return g;
}

/**
 * Procedurally built character. The torso is a normal bone hierarchy
 * (hips → spine → chest → neck → head, arms on the chest). Legs live in world
 * space and are placed every frame by the IK solver.
 */
export class Rig {
  root = new THREE.Group();
  hips = new THREE.Object3D();
  spine = new THREE.Object3D();
  chest = new THREE.Object3D();
  neck = new THREE.Object3D();
  head = new THREE.Object3D();
  ribs = new THREE.Group();
  arms: ArmRig[] = [];
  legs: LegRig[] = [];
  scarfAnchors: THREE.Object3D[] = [];

  constructor() {
    const jacket = std('#c5531c', 0.78);
    const jacketDark = std('#8c3913', 0.8);
    const pants = std('#27313f', 0.9);
    const boots = std('#3a2b24', 0.7);
    const sole = std('#cfc8ba', 0.9);
    const glove = std('#25262b', 0.75);
    const skin = std('#e0ad8f', 0.65);
    const hair = std('#33241b', 0.9);
    const pack = std('#59634f', 0.88);
    const strap = std('#2c3027', 0.85);
    const scarf = std('#2a8f8d', 0.9);
    const metal = std('#b9bec6', 0.35, 0.8);

    const { root, hips, spine, chest, neck, head, ribs } = this;
    root.add(hips);

    // ---- pelvis
    hips.add(ell(pants, 0.162, 0.125, 0.118, 0, 0.0, 0));
    const hem = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.168, 0.13, 24, 1, true), jacket);
    hem.scale.z = 0.74;
    hem.position.y = 0.055;
    hips.add(hem);
    const belt = new THREE.Mesh(new THREE.TorusGeometry(0.152, 0.017, 8, 32), strap);
    belt.rotation.x = Math.PI / 2;
    belt.scale.y = 0.75;
    belt.position.y = 0.105;
    hips.add(belt);
    const buckle = new THREE.Mesh(new RoundedBoxGeometry(0.045, 0.035, 0.012, 2, 0.005), metal);
    buckle.position.set(0, 0.105, 0.125);
    hips.add(buckle);
    const pouch = new THREE.Mesh(new RoundedBoxGeometry(0.07, 0.09, 0.05, 2, 0.015), strap);
    pouch.position.set(-0.165, 0.06, 0.02);
    hips.add(pouch);

    // ---- spine / abdomen
    spine.position.set(0, 0.1, -0.005);
    hips.add(spine);
    spine.add(ell(jacket, 0.157, 0.15, 0.114, 0, 0.07, 0));

    // ---- chest
    chest.position.set(0, 0.17, 0);
    spine.add(chest);
    chest.add(ribs);
    ribs.add(ell(jacket, 0.188, 0.175, 0.128, 0, 0.115, 0.004));
    ribs.add(ell(jacketDark, 0.15, 0.06, 0.11, 0, 0.245, -0.002)); // yoke
    for (const s of [1, -1]) {
      ribs.add(ell(jacket, 0.078, 0.072, 0.078, s * 0.178, 0.2, -0.004));
      // pack straps
      const st = new THREE.Mesh(new THREE.TorusGeometry(0.128, 0.013, 6, 24, Math.PI * 1.15), strap);
      st.rotation.set(0, Math.PI / 2, -0.25);
      st.scale.set(1.0, 1.25, 1);
      st.position.set(s * 0.098, 0.13, 0.0);
      ribs.add(st);
    }
    // backpack + bedroll: makes torso twist readable from the chase camera
    const bag = new THREE.Mesh(new RoundedBoxGeometry(0.25, 0.33, 0.13, 3, 0.045), pack);
    bag.position.set(0, 0.085, -0.168);
    chest.add(bag);
    const pocket = new THREE.Mesh(new RoundedBoxGeometry(0.17, 0.14, 0.05, 2, 0.02), strap);
    pocket.position.set(0, 0.03, -0.24);
    chest.add(pocket);
    const roll = new THREE.Mesh(new THREE.CapsuleGeometry(0.052, 0.24, 6, 14), std('#a9b3bd', 0.9));
    roll.rotation.z = Math.PI / 2;
    roll.position.set(0, 0.275, -0.165);
    chest.add(roll);

    // ---- neck, scarf, head
    neck.position.set(0, 0.27, -0.008);
    chest.add(neck);
    const nk = new THREE.Mesh(new THREE.CylinderGeometry(0.047, 0.052, 0.11, 14), skin);
    nk.position.y = 0.04;
    neck.add(nk);
    const wrap = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.04, 10, 24), scarf);
    wrap.rotation.x = Math.PI / 2 + 0.12;
    wrap.scale.set(1.15, 1, 1.0);
    wrap.position.set(0, 0.0, 0.006);
    chest.add(wrap);
    wrap.position.y = 0.268;
    for (const s of [1, -1]) {
      const a = new THREE.Object3D();
      a.position.set(s * 0.085, -0.07, -0.21); // streamers tied to the bottom corners of the pack
      chest.add(a);
      this.scarfAnchors.push(a);
    }

    head.position.set(0, 0.085, 0.01);
    neck.add(head);
    head.add(ell(skin, 0.098, 0.115, 0.106, 0, 0.105, 0));
    head.add(ell(skin, 0.07, 0.05, 0.06, 0, 0.035, 0.03)); // jaw
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.113, 28, 16, 0, Math.PI * 2, 0, Math.PI * 0.56), hair);
    cap.scale.set(0.95, 1.02, 1.02);
    cap.rotation.x = -0.42;
    cap.position.set(0, 0.112, -0.006);
    head.add(cap);
    head.add(ell(hair, 0.085, 0.07, 0.06, 0, 0.075, -0.07));
    const nose = ell(skin, 0.014, 0.02, 0.02, 0, 0.09, 0.105);
    head.add(nose);
    for (const s of [1, -1]) {
      head.add(ell(std('#1b1b1f', 0.4), 0.011, 0.012, 0.008, s * 0.036, 0.118, 0.096));
      head.add(ell(skin, 0.012, 0.024, 0.016, s * 0.098, 0.1, 0));
    }
    // goggles pushed up on the forehead
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.103, 0.011, 6, 28), strap);
    band.rotation.x = Math.PI / 2 - 0.32;
    band.position.set(0, 0.162, 0.0);
    head.add(band);
    for (const s of [1, -1]) {
      const lens = ell(std('#f0a742', 0.2, 0.6), 0.028, 0.022, 0.014, s * 0.034, 0.174, 0.09);
      lens.rotation.x = -0.3;
      head.add(lens);
    }

    // ---- arms (FK, parented to the chest)
    for (const s of [1, -1]) {
      const upper = new THREE.Object3D();
      upper.position.set(s * 0.19, 0.2, -0.004);
      chest.add(upper);
      upper.add(limb(jacket, 0.058, 0.047, DIM.upperArm));
      const fore = new THREE.Object3D();
      fore.position.y = -DIM.upperArm;
      upper.add(fore);
      fore.add(limb(jacket, 0.046, 0.038, DIM.foreArm));
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.043, 0.043, 0.045, 14), jacketDark);
      cuff.position.y = -DIM.foreArm + 0.02;
      fore.add(cuff);
      const hand = new THREE.Object3D();
      hand.position.y = -DIM.foreArm;
      fore.add(hand);
      hand.add(ell(glove, 0.04, 0.062, 0.03, 0, -0.055, 0.004));
      hand.add(ell(glove, 0.016, 0.034, 0.018, -s * 0.022, -0.04, 0.03)); // thumb: forward / inward
      this.arms.push({ upper, fore, hand });
    }

    // ---- legs (world space, IK driven)
    for (const s of [1, -1]) {
      const thigh = new THREE.Object3D();
      thigh.add(limb(pants, 0.084, 0.062, DIM.thigh));
      const shin = new THREE.Object3D();
      shin.add(limb(pants, 0.06, 0.045, DIM.shin));
      shin.add(ell(strap, 0.048, 0.055, 0.03, 0, -0.01, 0.04)); // knee pad → shows knee direction
      const cuff = new THREE.Mesh(new THREE.CylinderGeometry(0.058, 0.05, 0.16, 16), boots);
      cuff.position.y = -DIM.shin + 0.1;
      shin.add(cuff);
      const foot = new THREE.Object3D();
      const len = DIM.heelBack + DIM.ballFwd;
      const body = new THREE.Mesh(new RoundedBoxGeometry(0.098, 0.075, len + 0.03, 3, 0.03), boots);
      body.position.set(0, -DIM.ankleH + 0.05, (DIM.ballFwd - DIM.heelBack) / 2 - 0.005);
      foot.add(body);
      foot.add(ell(boots, 0.05, 0.05, 0.05, 0, -0.01, 0));
      const sl = new THREE.Mesh(new RoundedBoxGeometry(0.102, 0.022, len + 0.035, 2, 0.01), sole);
      sl.position.set(0, -DIM.ankleH + 0.011, (DIM.ballFwd - DIM.heelBack) / 2 - 0.005);
      foot.add(sl);
      const toe = new THREE.Object3D();
      toe.position.set(0, -DIM.ankleH + 0.022, DIM.ballFwd);
      foot.add(toe);
      const tb = new THREE.Mesh(new RoundedBoxGeometry(0.098, 0.058, 0.1, 3, 0.027), boots);
      tb.position.set(0, 0.016, 0.035);
      toe.add(tb);
      const ts = new THREE.Mesh(new RoundedBoxGeometry(0.102, 0.022, 0.1, 2, 0.01), sole);
      ts.position.set(0, -0.011, 0.037);
      toe.add(ts);
      root.add(thigh, shin, foot);
      this.legs.push({ thigh, shin, foot, toe });
      void s;
    }

    root.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) o.castShadow = true;
    });
  }
}

/** Verlet pack streamers — cheap secondary motion that sells speed, stops and turns. */
export class Scarf {
  mesh: THREE.Mesh;
  private pts: THREE.Vector3[][] = [];
  private prev: THREE.Vector3[][] = [];
  private pos: THREE.BufferAttribute;
  private readonly n = 6;
  private readonly seg = 0.062;
  private rig: Rig;
  private tmp = new THREE.Vector3();
  private c1 = new THREE.Vector3();
  private c2 = new THREE.Vector3();
  private c3 = new THREE.Vector3();
  private side = new THREE.Vector3();

  constructor(rig: Rig) {
    this.rig = rig;
    const n = this.n;
    const geo = new THREE.BufferGeometry();
    this.pos = new THREE.BufferAttribute(new Float32Array(2 * n * 2 * 3), 3);
    this.pos.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position', this.pos);
    const idx: number[] = [];
    for (let t = 0; t < 2; t++) {
      const o = t * n * 2;
      for (let i = 0; i < n - 1; i++) {
        const a = o + i * 2;
        idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      }
      this.pts.push(Array.from({ length: n }, () => new THREE.Vector3()));
      this.prev.push(Array.from({ length: n }, () => new THREE.Vector3()));
    }
    geo.setIndex(idx);
    this.mesh = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({ color: '#2a8f8d', roughness: 0.9, side: THREE.DoubleSide }),
    );
    this.mesh.castShadow = true;
    this.mesh.frustumCulled = false;
    this.reset();
  }

  reset() {
    this.rig.root.updateMatrixWorld(true);
    for (let t = 0; t < 2; t++) {
      this.rig.scarfAnchors[t].getWorldPosition(this.tmp);
      for (let i = 0; i < this.n; i++) {
        this.pts[t][i].copy(this.tmp).y -= i * this.seg;
        this.prev[t][i].copy(this.pts[t][i]);
      }
    }
  }

  update(dt: number, time: number) {
    const { chest } = this.rig;
    this.rig.scarfAnchors[0].getWorldPosition(this.tmp);
    if (this.tmp.distanceToSquared(this.pts[0][0]) > 4) this.reset();
    this.c1.set(0, 0.15, -0.115);
    chest.localToWorld(this.c1);
    this.c2.set(0, 0.0, -0.115);
    chest.localToWorld(this.c2);
    this.c3.set(0, 0.0, -0.03);
    this.rig.hips.localToWorld(this.c3);
    this.side.setFromMatrixColumn(chest.matrixWorld, 0).normalize();
    const g = 9 * dt * dt;
    for (let t = 0; t < 2; t++) {
      const p = this.pts[t];
      const q = this.prev[t];
      this.rig.scarfAnchors[t].getWorldPosition(p[0]);
      for (let i = 1; i < this.n; i++) {
        const vx = (p[i].x - q[i].x) * 0.965;
        const vy = (p[i].y - q[i].y) * 0.965;
        const vz = (p[i].z - q[i].z) * 0.965;
        q[i].copy(p[i]);
        const w = Math.sin(time * 2.3 + i * 0.8 + t * 1.7) * 0.6 * dt * dt;
        p[i].x += vx + w;
        p[i].y += vy - g;
        p[i].z += vz + w * 0.5;
      }
      for (let it = 0; it < 4; it++) {
        for (let i = 1; i < this.n; i++) {
          const d = this.tmp.subVectors(p[i], p[i - 1]);
          const l = d.length() || 1e-5;
          p[i].addScaledVector(d, -(l - this.seg) / l);
          this.pushOut(p[i], this.c1, 0.155);
          this.pushOut(p[i], this.c2, 0.16);
          this.pushOut(p[i], this.c3, 0.175);
        }
      }
      const o = t * this.n * 2;
      for (let i = 0; i < this.n; i++) {
        const w = 0.026 - i * 0.002;
        this.pos.setXYZ(o + i * 2, p[i].x - this.side.x * w, p[i].y - this.side.y * w, p[i].z - this.side.z * w);
        this.pos.setXYZ(o + i * 2 + 1, p[i].x + this.side.x * w, p[i].y + this.side.y * w, p[i].z + this.side.z * w);
      }
    }
    this.pos.needsUpdate = true;
    this.mesh.geometry.computeVertexNormals();
  }

  private pushOut(p: THREE.Vector3, c: THREE.Vector3, r: number) {
    const dx = p.x - c.x;
    const dy = p.y - c.y;
    const dz = p.z - c.z;
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 < r * r && d2 > 1e-8) {
      const k = r / Math.sqrt(d2);
      p.set(c.x + dx * k, c.y + dy * k, c.z + dz * k);
    }
  }
}
