import * as THREE from 'three';
import { CharacterController } from './controller';
import { Animator } from './animator';
import { Terrain } from './terrain';
import { Spring, angleDiff, clamp, damp, dampAngle, lerp, smooth, smoothstep } from './math';

export interface ViewState {
  ads: number; // 0..1 aiming down sights
  zoom: number; // ADS magnification of the current weapon
  scope: number; // 0..1 sniper scope
}

/**
 * Dual-mode camera.
 *  • THIRD PERSON: over-the-shoulder spring arm (rotation inertia, damped pivot,
 *    speed-reactive distance/FOV, crouch height, landing spring). Aiming pulls
 *    it in tight over the shoulder.
 *  • FIRST PERSON: sits on the character's real eye point, so you look out of
 *    the same fully animated body (true first person) — arms, weapon and legs
 *    are the actual rig.
 * Both modes share one aim direction, which is also what the weapon points at.
 */
export class FollowCamera {
  yaw = 0;
  pitch = -0.16;
  firstPerson = false;
  /** 0 = third person, 1 = first person (smoothed). */
  fpW = 0;
  /** Final view direction (smoothed input + recoil). The weapon aims along this. */
  aimYaw = 0;
  aimPitch = -0.16;
  /** Distance from the camera to the character: bullets start beyond it. */
  camDist = 3.4;
  cam: THREE.PerspectiveCamera;

  private sYaw = 0;
  private sPitch = -0.16;
  private pivot = new THREE.Vector3();
  private dist = 3.4;
  private cDist = 3.4;
  private fov = 52;
  private land = new Spring(11, 0.6);
  private recoilP = new Spring(9, 0.8);
  private recoilY = new Spring(9, 0.8);
  private bob = 0;
  private sinceLook = 10;
  private focus = new THREE.Vector3();
  private dir = new THREE.Vector3();
  private tmp = new THREE.Vector3();
  private tps = new THREE.Vector3();

  constructor(cam: THREE.PerspectiveCamera) {
    this.cam = cam;
  }

  snap(c: CharacterController) {
    this.pivot.set(c.pos.x, c.pos.y + 1.48, c.pos.z);
    this.yaw = this.sYaw = this.aimYaw = c.yaw;
  }

  toggleMode() {
    this.firstPerson = !this.firstPerson;
  }

  look(dx: number, dy: number) {
    if (dx === 0 && dy === 0) return;
    this.yaw -= dx;
    const lim = this.firstPerson ? 1.35 : 1.0;
    this.pitch = clamp(this.pitch - dy, -lim, this.firstPerson ? 1.35 : 0.85);
    this.sinceLook = 0;
  }

  /** View recoil: kicks up, then settles back. */
  kick(up: number) {
    this.recoilP.v += up * 16;
    this.recoilY.v += (Math.random() - 0.5) * up * 9;
    this.sinceLook = 0;
  }

  /** Resolve the aim direction for this frame. Runs BEFORE the simulation. */
  steer(dt: number, c: CharacterController, scoped: boolean) {
    this.sinceLook += dt;
    if (!this.firstPerson && !c.strafing && c.speed > 1.2 && this.sinceLook > 1.3) {
      const err = angleDiff(c.heading, this.yaw);
      if (Math.abs(err) < 2.5) this.yaw += clamp(err, -1, 1) * 0.75 * smoothstep(1.3, 2.6, this.sinceLook) * dt;
    }
    this.fpW = damp(this.fpW, this.firstPerson || scoped ? 1 : 0, 11, dt);
    if (this.fpW < 0.002) this.fpW = 0;
    // third person keeps a little rotational inertia; first person is 1:1
    const rate = lerp(20, 90, this.fpW);
    this.sYaw = dampAngle(this.sYaw, this.yaw, rate, dt);
    this.sPitch = damp(this.sPitch, this.pitch, rate, dt);
    this.recoilP.update(0, dt);
    this.recoilY.update(0, dt);
    this.aimYaw = this.sYaw + this.recoilY.x;
    this.aimPitch = clamp(this.sPitch + this.recoilP.x, -1.4, 1.4);
  }

  /** Place the camera. Runs AFTER the animator (needs the solved eye point). */
  update(dt: number, c: CharacterController, a: Animator, terrain: Terrain, view: ViewState) {
    const speed = c.speed;
    const runK = smoothstep(2.5, 5, speed);
    const sprintK = smoothstep(5.2, 7.4, speed);
    const ads = view.ads;

    // ---- third-person rig
    const lam = lerp(17, 12, sprintK);
    const ty = a.visualY + 1.48 - 0.44 * a.crouchBlend + 0.13 * ads;
    this.pivot.x = damp(this.pivot.x, c.pos.x, lam, dt);
    this.pivot.z = damp(this.pivot.z, c.pos.z, lam, dt);
    this.pivot.y = damp(this.pivot.y, ty, c.grounded ? 9 : 6.5, dt);

    // aiming: tighter, higher and further out over the right shoulder
    const distT = lerp(3.35 + 0.2 * runK + 0.5 * sprintK - 0.45 * a.crouchBlend, 2.4, ads);
    this.dist = damp(this.dist, distT, ads > 0.5 ? 9 : 4, dt);

    if (a.landImpulse > 0) {
      this.land.v -= 1.1 * a.landImpulse;
      a.landImpulse = 0;
    }
    this.land.update(0, dt);
    this.bob = damp(this.bob, a.bounceOut * 0.35, 12, dt);

    const cp = Math.cos(this.aimPitch);
    this.dir.set(Math.sin(this.aimYaw) * cp, Math.sin(this.aimPitch), Math.cos(this.aimYaw) * cp);
    const closeK = clamp((this.cDist - 0.8) / 0.9, 0, 1);
    const sh = lerp(0.46, 0.52, ads) * closeK;
    this.focus.set(
      this.pivot.x - Math.cos(this.aimYaw) * sh,
      this.pivot.y + clamp(this.land.x, -0.25, 0.1) + this.bob,
      this.pivot.z + Math.sin(this.aimYaw) * sh,
    );

    let d = this.dist;
    for (let i = 1; i <= 12; i++) {
      const t = i / 12;
      this.tmp.copy(this.focus).addScaledVector(this.dir, -this.dist * t);
      if (this.tmp.y < terrain.height(this.tmp.x, this.tmp.z) + 0.28 || terrain.trunk(this.tmp.x, this.tmp.z, 0.25)) {
        d = this.dist * (t - 1 / 12);
        break;
      }
    }
    d = Math.max(d, 0.7);
    this.cDist = d < this.cDist ? damp(this.cDist, d, 26, dt) : damp(this.cDist, d, 6, dt);
    this.tps.copy(this.focus).addScaledVector(this.dir, -this.cDist);
    const gy = terrain.height(this.tps.x, this.tps.z) + 0.25;
    if (this.tps.y < gy) this.tps.y = gy;

    // ---- blend to the eye for first person
    const k = smooth(this.fpW);
    this.cam.position.lerpVectors(this.tps, a.eye, k);
    this.camDist = lerp(this.cDist + 0.45, 0.25, k);
    this.tmp.copy(this.cam.position).addScaledVector(this.dir, 10);
    this.cam.lookAt(this.tmp);

    // ---- field of view: speed breathing, ADS magnification, scope
    let fovT = lerp(52 + 2 * runK + 6.5 * sprintK, 74 + 5 * sprintK, k) / lerp(1, view.zoom, ads);
    fovT = lerp(fovT, 9.5, view.scope);
    this.fov = damp(this.fov, fovT, 15, dt);
    if (Math.abs(this.cam.fov - this.fov) > 0.01) {
      this.cam.fov = this.fov;
      this.cam.updateProjectionMatrix();
    }
  }
}
