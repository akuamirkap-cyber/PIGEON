/* Headless check of the weapon layer: hand-to-grip error, NaNs, elbow sanity.
   npx esbuild scripts/sim-weapons.ts --bundle --platform=node --format=cjs --outfile=/tmp/simw.cjs && node /tmp/simw.cjs */
import * as THREE from 'three';
import { Terrain } from '../src/game/terrain';
import { CharacterController, Intent } from '../src/game/controller';
import { Animator } from '../src/game/animator';
import { Rig } from '../src/game/rig';
import { WEAPONS, WeaponPose } from '../src/game/weapons';

const terrain = new Terrain();
const DT = 1 / 60;
const v = new THREE.Vector3();
const t = new THREE.Vector3();

function scenario(name: string, wi: number, opt: { aim: boolean; ads?: boolean; pitch?: number; move?: number; sprint?: boolean; crouch?: boolean; reload?: boolean; side?: number }) {
  const rig = new Rig();
  const c = new CharacterController();
  c.reset(0, -30, terrain);
  const a = new Animator(rig);
  a.reset(c, terrain);
  const def = WEAPONS[wi];
  const obj = def.build();
  rig.root.add(obj);
  const pose: WeaponPose = { obj, def, aim: opt.aim, ads: !!opt.ads, lower: 0, reload: 0, cycle: 0, kickBack: 0, kickUp: 0, aimYaw: 0, aimPitch: opt.pitch ?? 0 };
  let maxR = 0, maxL = 0, nan = false, minElbow = 9, time = 0, eyeMin = 9, eyeMax = -9;
  for (let k = 0; k < 240; k++) {
    const inp: Intent = { moveX: opt.side ?? 0, moveY: opt.move ?? 0, sprint: !!opt.sprint, jumpPressed: false, jumpHeld: false, crouchToggle: !!opt.crouch && k === 0, strafe: opt.aim, pace: 2, lockFacing: opt.aim };
    if (opt.reload) pose.reload = Math.min(0.999, Math.max(0.001, (k - 120) / 100));
    c.update(DT, inp, 0, terrain);
    a.update(DT, c, terrain, time, 0, pose.aimPitch, pose);
    time += DT;
    rig.root.updateMatrixWorld(true);
    if (k < 90) continue; // let blends settle
    // right wrist vs grip
    rig.arms[1].hand.getWorldPosition(v);
    t.set(0, -0.03, -0.065).applyMatrix4(obj.matrixWorld);
    const twoOrAim = def.twoHand || opt.aim;
    if (twoOrAim) maxR = Math.max(maxR, v.distanceTo(t));
    rig.arms[0].hand.getWorldPosition(v);
    t.set(...def.left).applyMatrix4(obj.matrixWorld);
    if (twoOrAim && !opt.reload) maxL = Math.max(maxL, v.distanceTo(t));
    if (!isFinite(v.x) || !isFinite(obj.position.x) || !isFinite(rig.arms[0].upper.quaternion.x)) nan = true;
    for (let i = 0; i < 2; i++) {
      const q = rig.arms[i].fore.quaternion;
      const ang = 2 * Math.acos(Math.min(1, Math.abs(q.w)));
      minElbow = Math.min(minElbow, ang);
    }
    eyeMin = Math.min(eyeMin, a.eye.y - c.pos.y);
    eyeMax = Math.max(eyeMax, a.eye.y - c.pos.y);
  }
  // muzzle direction vs aim
  const fwd = new THREE.Vector3(0, 0, 1).applyQuaternion(obj.quaternion);
  const want = new THREE.Vector3(0, Math.sin(pose.aimPitch), Math.cos(pose.aimPitch));
  const aimErr = opt.aim ? (fwd.angleTo(want) * 180) / Math.PI : NaN;
  console.log(
    `${name.padEnd(30)} R=${(maxR * 100).toFixed(1)}cm L=${(maxL * 100).toFixed(1)}cm aimErr=${aimErr.toFixed(1)}° eye=[${eyeMin.toFixed(2)},${eyeMax.toFixed(2)}] v=${c.speed.toFixed(1)} ${c.state} ${nan ? 'NaN!!' : ''}`,
  );
}

WEAPONS.forEach((w, i) => {
  scenario(`${w.name} carry idle`, i, { aim: false });
  scenario(`${w.name} carry run`, i, { aim: false, move: 1 });
  scenario(`${w.name} carry sprint`, i, { aim: false, move: 1, sprint: true });
  scenario(`${w.name} aim hip`, i, { aim: true });
  scenario(`${w.name} aim ADS`, i, { aim: true, ads: true });
  scenario(`${w.name} ADS up 50°`, i, { aim: true, ads: true, pitch: 0.87 });
  scenario(`${w.name} hip down 50°`, i, { aim: true, pitch: -0.87 });
  scenario(`${w.name} aim strafe run`, i, { aim: true, move: 0.2, side: 1 });
  scenario(`${w.name} aim crouch`, i, { aim: true, ads: true, crouch: true });
  scenario(`${w.name} reload`, i, { aim: true, reload: true });
});
