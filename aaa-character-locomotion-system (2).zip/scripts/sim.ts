/* Headless locomotion verification.
   npx esbuild scripts/sim.ts --bundle --platform=node --format=cjs --outfile=/tmp/sim.cjs && node /tmp/sim.cjs */
import * as THREE from 'three';
import { Terrain } from '../src/game/terrain';
import { CharacterController, Intent } from '../src/game/controller';
import { Animator } from '../src/game/animator';
import { Rig, DIM } from '../src/game/rig';

const terrain = new Terrain();
const DT = 1 / 60;

function mk(x = 0, z = 0) {
  const rig = new Rig();
  const c = new CharacterController();
  c.reset(x, z, terrain);
  const a = new Animator(rig);
  a.reset(c, terrain);
  return { rig, c, a, t: 0 };
}
type Sim = ReturnType<typeof mk>;
const base = (): Intent => ({
  moveX: 0,
  moveY: 0,
  sprint: false,
  jumpPressed: false,
  jumpHeld: false,
  crouchToggle: false,
  strafe: false,
  pace: 2,
});

interface Stats {
  nan: boolean;
  maxStretch: number;
  kneeBack: number;
  minSole: number;
  maxSlide: number;
  pelvisMin: number;
  pelvisMax: number;
  steps: number;
  armCorr: number;
  maxY: number;
  states: Set<string>;
  maxSwingStretch: number;
  minKneeAngle: number;
}
const v = new THREE.Vector3();
const v2 = new THREE.Vector3();

function run(s: Sim, secs: number, fn: (t: number, i: Intent) => void, camYaw = 0): Stats {
  const st: Stats = {
    nan: false,
    maxStretch: 0,
    kneeBack: 0,
    minSole: 1,
    maxSlide: 0,
    pelvisMin: 9,
    pelvisMax: -9,
    steps: 0,
    armCorr: 0,
    maxY: -9,
    states: new Set(),
    maxSwingStretch: 0,
    minKneeAngle: 9,
  };
  const prevBall = [new THREE.Vector3(), new THREE.Vector3()];
  const prevMode = [-1, -1];
  let corrN = 0;
  const n = Math.round(secs / DT);
  for (let k = 0; k < n; k++) {
    const inp = base();
    fn(k * DT, inp);
    s.c.update(DT, inp, camYaw, terrain);
    s.a.update(DT, s.c, terrain, s.t, camYaw, 0);
    s.t += DT;
    s.rig.root.updateMatrixWorld(true);
    st.states.add(s.c.state);
    st.steps += s.a.steps.length;
    s.a.steps.length = 0;
    st.maxY = Math.max(st.maxY, s.c.pos.y);
    const hipRel = s.rig.hips.position.y - s.a.visualY;
    if (s.c.grounded) {
      st.pelvisMin = Math.min(st.pelvisMin, hipRel);
      st.pelvisMax = Math.max(st.pelvisMax, hipRel);
    }
    if (!isFinite(hipRel) || !isFinite(s.c.pos.x)) st.nan = true;
    st.maxStretch = Math.max(st.maxStretch, s.a.maxStretch);
    const pf = v2.set(0, 0, 1).applyQuaternion(s.rig.hips.quaternion);
    for (let i = 0; i < 2; i++) {
      const f = s.a.feet[i];
      const leg = s.rig.legs[i];
      if (!isFinite(f.knee.x) || !isFinite(leg.thigh.quaternion.x)) st.nan = true;
      st.maxSwingStretch = Math.max(st.maxSwingStretch, f.stretch);
      // knee must be in front of the hip→ankle line
      v.copy(f.hip).add(f.ankle).multiplyScalar(0.5);
      const kf = (f.knee.x - v.x) * pf.x + (f.knee.z - v.z) * pf.z;
      st.kneeBack = Math.min(st.kneeBack, kf);
      // knee interior angle
      const a1 = v.subVectors(f.hip, f.knee).normalize().clone();
      const a2 = v.subVectors(f.ankle, f.knee).normalize();
      st.minKneeAngle = Math.min(st.minKneeAngle, Math.acos(Math.max(-1, Math.min(1, a1.dot(a2)))));
      // sole clearance (heel + ball of the rendered foot)
      for (const zz of [-DIM.heelBack, DIM.ballFwd]) {
        v.set(0, -DIM.ankleH, zz);
        leg.foot.localToWorld(v);
        if (s.c.grounded) st.minSole = Math.min(st.minSole, v.y - terrain.height(v.x, v.z));
      }
      // rendered ball of foot must not move while planted
      v.set(0, -DIM.ankleH, DIM.ballFwd);
      leg.foot.localToWorld(v);
      if (f.mode === 0 && prevMode[i] === 0 && f.pitch >= 0 && f.contact > 0.98) {
        st.maxSlide = Math.max(st.maxSlide, Math.hypot(v.x - prevBall[i].x, v.z - prevBall[i].z));
      }
      prevBall[i].copy(v);
      prevMode[i] = f.mode;
    }
    // arm/leg opposition: left hand forward ↔ right foot forward
    if (s.c.grounded && s.c.speed > 1) {
      s.rig.arms[0].hand.getWorldPosition(v);
      const hf = (v.x - s.c.pos.x) * Math.sin(s.c.yaw) + (v.z - s.c.pos.z) * Math.cos(s.c.yaw);
      const d = s.a.feet[1].fwd - s.a.feet[0].fwd;
      st.armCorr += Math.sign(hf - 0.02) * Math.sign(d) * Math.min(1, Math.abs(d) * 3);
      corrN++;
    }
  }
  st.armCorr /= Math.max(1, corrN);
  return st;
}

function rep(name: string, s: Sim, st: Stats, extra = '') {
  const f = (x: number) => x.toFixed(3);
  console.log(
    `${name.padEnd(22)} v=${f(s.c.speed)} cad=${s.a.cadence.toFixed(0).padStart(3)} steps=${String(st.steps).padStart(3)} ` +
      `stretch(st/any)=${f(st.maxStretch)}/${f(st.maxSwingStretch)} kneeBack=${f(st.kneeBack)} minKnee=${(
        (st.minKneeAngle * 180) /
        Math.PI
      ).toFixed(0)}° sole=${f(st.minSole)} slide=${f(st.maxSlide)} pelvis=[${f(st.pelvisMin)},${f(st.pelvisMax)}] arm=${f(
        st.armCorr,
      )} ${st.nan ? 'NaN!!' : ''} ${extra}\n    states: ${[...st.states].join(' ')}`,
  );
}

let s = mk();
rep('idle', s, run(s, 2, () => {}));

for (const [name, pace, sprint] of [
  ['walk', 0, false],
  ['jog', 1, false],
  ['run', 2, false],
  ['sprint', 2, true],
] as const) {
  s = mk(0, -30);
  s.c.yaw = Math.PI; // head away from props (−Z)
  s.a.reset(s.c, terrain);
  const st = run(
    s,
    5,
    (_t, i) => {
      i.moveY = 1;
      i.pace = pace;
      i.sprint = sprint;
    },
    Math.PI,
  );
  rep(name, s, st, `lean=${s.a.leanOut.toFixed(2)}`);
  const t0 = s.t;
  let stopT = 0;
  const st2 = run(s, 2.5, () => {
    if (!stopT && s.c.speed < 0.05) stopT = s.t - t0;
  }, Math.PI);
  rep(`  ${name} → stop`, s, st2, `stopTime=${stopT.toFixed(2)}s feetSep=${(s.a.feet[0].fwd - s.a.feet[1].fwd).toFixed(2)}`);
}

// run then 180° reversal
s = mk(0, -30);
run(s, 2.5, (_t, i) => { i.moveY = -1; });
rep('run 180 pivot', s, run(s, 2.0, (_t, i) => { i.moveY = 1; }), `yaw=${s.c.yaw.toFixed(2)}`);

// run with 90° turns
s = mk(0, -30);
run(s, 2, (_t, i) => { i.moveY = -1; });
rep('run 90 turn', s, run(s, 1.5, (_t, i) => { i.moveX = 1; }), `bank=${s.a.bankOut.toFixed(2)}`);

// idle 180 turn in place then walk
s = mk(0, -30);
rep('idle→back walk', s, run(s, 2, (_t, i) => { i.moveY = -1; i.pace = 0; }));

// strafing
for (const [name, mx, my] of [['strafe left', -1, 0], ['strafe back', 0, -1], ['strafe diag', 1, 1], ['strafe back-diag', -1, -1]] as const) {
  s = mk(0, -30);
  rep(name, s, run(s, 3, (_t, i) => { i.moveX = mx; i.moveY = my; i.strafe = true; i.pace = 0; }));
}
s = mk(0, -30);
rep('strafe run circle', s, run(s, 6, (t, i) => { i.moveX = Math.sin(t * 1.5); i.moveY = Math.cos(t * 1.5); i.strafe = true; }));

// crouch
s = mk(0, -30);
rep('crouch idle', s, run(s, 1.5, (t, i) => { i.crouchToggle = t < DT; }));
rep('crouch walk', s, run(s, 3, (_t, i) => { i.moveY = -1; }));
rep('crouch → stand', s, run(s, 1.5, (t, i) => { i.crouchToggle = t < DT; }));
s = mk(0, -30);
run(s, 2, (_t, i) => { i.moveY = -1; });
rep('run → crouch', s, run(s, 2, (t, i) => { i.moveY = -1; i.crouchToggle = t < DT; }));

// jumps
s = mk(0, -30);
let st = run(s, 2, (t, i) => { i.jumpPressed = Math.round(t / DT) === 18; i.jumpHeld = true; });
rep('standing jump', s, st, `apex=${st.maxY.toFixed(2)}`);
s = mk(0, -30);
run(s, 2, (_t, i) => { i.moveY = -1; });
const y0 = s.c.pos.y;
st = run(s, 2, (t, i) => { i.moveY = -1; i.jumpPressed = t < DT; i.jumpHeld = true; });
rep('running jump', s, st, `apex=+${(st.maxY - y0).toFixed(2)}`);
s = mk(0, -30);
run(s, 3, (_t, i) => { i.moveY = -1; i.sprint = true; });
st = run(s, 2, (t, i) => { i.moveY = -1; i.sprint = true; i.jumpPressed = t < DT; i.jumpHeld = true; });
rep('sprint jump', s, st);

// stairs + deck + drop
s = mk(6.5, 3);
st = run(s, 4, (_t, i) => { i.moveY = 1; i.pace = 0; });
rep('walk up stairs', s, st, `y=${s.c.pos.y.toFixed(2)} z=${s.c.pos.z.toFixed(2)}`);
s = mk(6.5, 0);
st = run(s, 4, (_t, i) => { i.moveY = 1; });
rep('run stairs→ledge', s, st, `y=${s.c.pos.y.toFixed(2)} z=${s.c.pos.z.toFixed(2)}`);
// ripple patch
s = mk(-6, -3);
st = run(s, 4, (_t, i) => { i.moveY = -1; i.pace = 0; });
rep('walk ripples', s, st);
// wall
s = mk(-6, 0);
st = run(s, 3, (_t, i) => { i.moveY = 1; });
rep('run into crate', s, st, `z=${s.c.pos.z.toFixed(2)}`);
