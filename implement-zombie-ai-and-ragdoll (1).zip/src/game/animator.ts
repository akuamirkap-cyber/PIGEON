import * as THREE from 'three';
import { DIM, Rig } from './rig';
import { CharacterController } from './controller';
import { Terrain } from './terrain';
import type { WeaponPose } from './weapons';
import { Spring, TAU, angleDiff, clamp, clamp01, damp, frac, keyLerp, lerp, lerpAngle, smooth, smoothstep } from './math';

const STANCE = 0;
const SWING = 1;
const AIR = 2;
const LEG_MAX = DIM.thigh + DIM.shin - 0.003;
const MAX_PELVIS_DROP = 0.14;

/* ---------------------------------------------------------------------------
 * GAIT BLEND TREE
 * Each column is a complete gait description at a reference speed
 * (stand, walk, jog, run, sprint). Parameters are blended continuously by
 * speed, then cross-blended with the crouch set and direction modifiers, so
 * there is never a hard switch between "animations".
 * ------------------------------------------------------------------------- */
const KEYS = [0, 1.5, 3.2, 4.8, 7.9];
const GAIT = {
  stride: [0.55, 1.42, 2.25, 3.15, 4.35], // metres per full cycle (two steps)
  duty: [0.66, 0.61, 0.38, 0.31, 0.255], // fraction of cycle each foot is planted (<0.5 = flight phase)
  stepH: [0.04, 0.045, 0.14, 0.24, 0.34], // swing arc on top of the toe-off ankle height
  front: [0.46, 0.41, 0.37, 0.35, 0.32], // share of stance travel in front of the hip (stance sits further back)
  armGain: [0.45, 0.5, 0.66, 0.88, 1.2], // arm swing per metre of foot separation
  elbow: [0.22, 0.28, 1.2, 1.5, 1.7], // base elbow flexion
  lean: [0, 0.035, 0.11, 0.2, 0.36], // forward torso inclination
  bounce: [0, 0, 0.032, 0.045, 0.04], // vertical flight-phase oscillation
  kick: [0, 0, 0.38, 0.7, 1.0], // running heel recovery (foot folds behind)
  hipDrop: [0, 0.012, 0.04, 0.06, 0.08], // lowered centre of mass
  width: [0.105, 0.08, 0.065, 0.05, 0.035], // step width from centreline
  heelMax: [0.5, 0.7, 0.85, 1.0, 1.18], // heel lift at toe-off (≈40° walking; long running strides need more)
  strike: [0.12, 0.21, 0.1, 0.035, -0.06], // toe-up at contact (≈12° walking; negative = forefoot strike)
};
type GaitKey = keyof typeof GAIT;
type GaitParams = Record<GaitKey, number>;
const GAIT_KEYS = Object.keys(GAIT) as GaitKey[];
const CROUCH_GAIT: GaitParams = {
  stride: 0.95,
  duty: 0.66,
  stepH: 0.1,
  front: 0.5,
  armGain: 0.16,
  elbow: 1.65,
  lean: 0,
  bounce: 0,
  kick: 0.12,
  hipDrop: 0,
  width: 0.14,
  heelMax: 0.75,
  strike: 0.1,
};

/**
 * Swing arc 0→1→0, shaped after motion capture: walking peaks early (25 % of the
 * swing, the heel is already up at toe-off) and then glides down; running rises
 * like a sine to 38 % as the heel folds toward the hip. Both come down with a
 * smoothstep so the foot meets the ground with no vertical velocity.
 */
function swingArc(t: number, walk: number): number {
  const peak = lerp(0.38, 0.25, walk);
  if (t >= peak) return 1 - smooth((t - peak) / (1 - peak));
  return lerp(Math.sin((Math.PI / 2) * (t / peak)), smooth(t / peak), walk);
}

export interface FootStep {
  x: number;
  y: number;
  z: number;
  yaw: number;
  side: number;
  strength: number;
}

class Foot {
  side: number; // +1 = left (+X when facing +Z)
  off: number; // phase offset in the gait cycle
  /** Flat-foot ground reference point (under the ankle). Locked in world space during stance. */
  pos = new THREE.Vector3();
  yaw = 0;
  /** Heel-toe roll: + = heel up (pivot on ball), - = toes up (pivot on heel). */
  pitch = 0;
  mode = STANCE;
  u = 0;
  from = new THREE.Vector3();
  fromYaw = 0;
  fromPitch = 0;
  adjust = false;
  dur = 0.3;
  liftH = 0.05;
  ready = true;
  minY = 0;
  landX = 0;
  /** Un-pivoted planted pose + pivot applied on the ball while the body turns over the foot. */
  plantPos = new THREE.Vector3();
  plantYaw = 0;
  pivot = 0;
  pitchVel = 0;
  pitchRate0 = 0;
  /** Root position at lift-off / predicted at touch-down (body-relative swing blending). */
  root0x = 0;
  root0z = 0;
  root1x = 0;
  root1z = 0;
  slopePitch = 0;
  slopeRoll = 0;
  contact = 1;
  swingW = 0;
  fwd = 0;
  target = new THREE.Vector3();
  targetYaw = 0;
  ankle = new THREE.Vector3();
  knee = new THREE.Vector3();
  hip = new THREE.Vector3();
  stretch = 0;
  constructor(side: number, off: number) {
    this.side = side;
    this.off = off;
  }
}

const _v = new THREE.Vector3();
const _n = new THREE.Vector3();
const _pv = new THREE.Vector3();
const _up = new THREE.Vector3();
const _x = new THREE.Vector3();
const _z = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _e = new THREE.Euler();
const _q = new THREE.Quaternion();
const X_AXIS = new THREE.Vector3(1, 0, 0);
const _qA = new THREE.Quaternion();
const _qAim = new THREE.Quaternion();
const _qCarry = new THREE.Quaternion();
const _qC = new THREE.Quaternion();
const _qU = new THREE.Quaternion();
const _qF = new THREE.Quaternion();
const _qT = new THREE.Quaternion();
const _qh = new THREE.Quaternion();
const _wp = new THREE.Vector3();
const _cp = new THREE.Vector3();
const _t = new THREE.Vector3();
const _s = new THREE.Vector3();
const _el = new THREE.Vector3();
const _b = new THREE.Vector3();

// Hand ↔ weapon grip relations (weapon local space)
const qx = (a: number) => new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), a);
const qy = (a: number) => new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), a);
const RH_GRIP = qx(-Math.PI / 2 - 0.15); // fingers forward, thumb up
const RH_GRIP_INV = RH_GRIP.clone().invert();
const RH_WRIST = new THREE.Vector3(0, -0.03, -0.065);
const LH_GRIP = qy(-0.55).multiply(qx(-Math.PI / 2 + 0.1)); // palm up under the hand-guard
const LH_PISTOL = qy(-0.5).multiply(qx(-Math.PI / 2 - 0.1)); // wraps the firing hand

function basisQuat(out: THREE.Quaternion, up: THREE.Vector3, hint: THREE.Vector3) {
  _x.crossVectors(up, hint);
  if (_x.lengthSq() < 1e-8) _x.set(1, 0, 0);
  _x.normalize();
  _z.crossVectors(_x, up);
  _m.makeBasis(_x, up, _z);
  out.setFromRotationMatrix(_m);
}

function setBasis(o: THREE.Object3D, up: THREE.Vector3, fwdHint: THREE.Vector3) {
  _x.crossVectors(up, fwdHint);
  if (_x.lengthSq() < 1e-8) _x.set(1, 0, 0);
  _x.normalize();
  _z.crossVectors(_x, up);
  _m.makeBasis(_x, up, _z);
  o.quaternion.setFromRotationMatrix(_m);
}

/**
 * Procedural full-body animator.
 *
 * Feet are planted in WORLD space: a stance foot never moves, the body travels
 * over it and the leg is solved with IK — so foot sliding is impossible by
 * construction. Swing feet fly to a landing spot predicted from velocity,
 * acceleration and turn rate. Everything above the feet (pelvis, spine, arms,
 * head) is layered on top from the feet + physics state through springs.
 */
export class Animator {
  rig: Rig;
  feet = [new Foot(1, 0), new Foot(-1, 0.5)];
  phase = 0;
  gaitActive = false;
  p: GaitParams = { ...CROUCH_GAIT };

  // outputs
  steps: FootStep[] = [];
  landImpulse = 0;
  visualY = 0;
  crouchBlend = 0;
  cadence = 0;
  maxStretch = 0;
  bounceOut = 0;
  leanOut = 0;
  bankOut = 0;

  private gaitW = 0;
  private stanceTime = 0.5;
  private hipYawOff = 0;
  private backpedal = false;
  private backW = 0;
  private refOff = 0;
  private prevY = 0;
  private prevGrounded = true;
  private wasAir = false;
  private airLead = 0;
  private adjustCooldown = 0;
  private exertion = 0;
  private breathPhase = 0;
  private runK = 0;
  private pace = 0;
  private hipTargetAbs = DIM.hipH;

  private crouchHip = new Spring(11, 0.9);
  private crouchTorso = new Spring(8, 0.85);
  private crouchArms = new Spring(6.5, 0.8);
  private leanPitch = new Spring(9, 0.6);
  private bank = new Spring(10, 0.7);
  private jumpDip = new Spring(28, 0.8);
  private land = new Spring(13, 0.7);
  private pelvisRel = new Spring(24, 1, DIM.hipH);
  private pelvisLat = new Spring(12, 0.9);
  private gaitYaw = new Spring(18, 0.9);
  private roll = new Spring(18, 1);
  private armSwing = new Spring(20, 0.75);
  private armBoth = new Spring(15, 0.7);
  private armOut = new Spring(13, 0.75);
  private elbow = new Spring(14, 0.8, 0.25);
  private look = new Spring(9, 0.9);

  // weapon layer
  /** Eye point in world space (first-person camera anchor / aim-frame origin). */
  eye = new THREE.Vector3(0, 1.68, 0);
  armedW = 0;
  aimW = 0;
  adsW = 0;
  private sprintCarry = 0;
  private swayX = new Spring(11, 0.55);
  private swayY = new Spring(11, 0.55);
  private prevAimYaw = 0;
  private prevAimPitch = 0;

  constructor(rig: Rig) {
    this.rig = rig;
  }

  reset(c: CharacterController, terrain: Terrain) {
    const lx = Math.cos(c.yaw);
    const lz = -Math.sin(c.yaw);
    for (const f of this.feet) {
      f.pos.set(c.pos.x + lx * f.side * 0.105, 0, c.pos.z + lz * f.side * 0.105);
      f.pos.y = terrain.height(f.pos.x, f.pos.z);
      f.yaw = c.yaw + f.side * 0.15;
      f.mode = STANCE;
      f.pitch = 0;
      f.contact = 1;
      f.ready = true;
      f.plantPos.copy(f.pos);
      f.plantYaw = f.yaw;
      f.pivot = 0;
    }
    this.gaitActive = false;
    this.wasAir = false;
    this.prevGrounded = true;
    this.prevY = c.pos.y;
    this.refOff = 0;
    this.pelvisRel.reset(DIM.hipH);
  }

  // ------------------------------------------------------------------ helpers
  private blendGait(speed: number, cw: number) {
    const p = this.p;
    for (const k of GAIT_KEYS) p[k] = keyLerp(KEYS, GAIT[k], speed);
    if (cw > 0.001) {
      for (const k of GAIT_KEYS) {
        const cv = k === 'stride' ? lerp(0.5, CROUCH_GAIT.stride, clamp01(speed / 1.35)) : CROUCH_GAIT[k];
        p[k] = lerp(p[k], cv, cw);
      }
    }
  }

  /** Heel-toe roll as a pure function of where the hip is relative to the planted foot. */
  private pitchRule(x: number, cw: number) {
    const p = this.p;
    const rk = this.runK;
    let r = 0;
    // heel-off: starts around mid-stance and rises faster and faster until toe-off (walking);
    // running lifts later and with an eased curve
    const start = lerp(0.18, 0.3, rk);
    if (x > start) {
      const q = clamp01((x - start) / lerp(0.34, 0.3, rk));
      r = p.heelMax * lerp(q * q, smooth(q), rk);
    } else if (x < -0.2) r = -p.strike * smooth((-x - 0.2) / 0.16);
    return r + cw * clamp(x - 0.02, 0, 0.3) * 2.0;
  }

  private sampleGround(v: THREE.Vector3, c: CharacterController, terrain: Terrain) {
    let h = terrain.height(v.x, v.z);
    if (Math.abs(h - c.pos.y) > 0.36) {
      // don't reach onto walls / off ledges: walk the foothold back toward the body until it is
      // somewhere the character could actually stand
      const ox = v.x;
      const oz = v.z;
      for (const k of [0.5, 0.25, 0.1, 0]) {
        v.x = lerp(c.pos.x, ox, k);
        v.z = lerp(c.pos.z, oz, k);
        h = terrain.height(v.x, v.z);
        if (Math.abs(h - c.pos.y) <= 0.36) break;
      }
      if (Math.abs(h - c.pos.y) > 0.36) h = c.pos.y;
    }
    v.y = h;
  }

  /** Predict where this foot should land. */
  private footTarget(f: Foot, c: CharacterController, terrain: Terrain, tRemain: number, pYaw: number, cw: number, moveW: number) {
    const p = this.p;
    const t = tRemain;
    const px = c.pos.x + c.vel.x * t + 0.5 * c.accel.x * t * t;
    const pz = c.pos.z + c.vel.z * t + 0.5 * c.accel.z * t * t;
    f.root1x = px;
    f.root1z = pz;
    const lt = this.stanceTime * p.front;
    let lx = c.vel.x * lt;
    let lz = c.vel.z * lt;
    const ll = Math.hypot(lx, lz);
    if (ll > 0.47) {
      lx *= 0.47 / ll;
      lz *= 0.47 / ll;
    }
    // braking steps: reach further ahead to catch the body's momentum
    const sp = Math.max(c.speed, 0.1);
    const decel = -(c.accel.x * c.vel.x + c.accel.z * c.vel.z) / sp;
    if (decel > 2 && c.speed > 0.5) {
      const b = clamp((decel - 2) * 0.01, 0, 0.08);
      lx += (c.vel.x / sp) * b;
      lz += (c.vel.z / sp) * b;
    }
    // the foot lands already rotated toward where the body will face (more so when turning on the spot)
    const yawLead = lerp(0.9, 0.52, moveW);
    const yawP = pYaw + clamp(c.yawRate * t * 0.9, -yawLead, yawLead);
    const sx = Math.cos(yawP);
    const sz = -Math.sin(yawP);
    const fx = Math.sin(yawP);
    const fz = Math.cos(yawP);
    const stag = f.side * (0.022 * (1 - moveW) + 0.12 * cw * (1 - 0.6 * moveW));
    // turning on the spot: feet step wider so they orbit the body instead of bunching under it
    const wid = p.width + 0.06 * smoothstep(1.5, 5, Math.abs(c.yawRate)) * (1 - moveW);
    let tx = px + lx + sx * f.side * wid + fx * stag;
    let tz = pz + lz + sz * f.side * wid + fz * stag;
    f.targetYaw = yawP + f.side * (lerp(0.15, 0.05, moveW) + 0.2 * cw);
    // foothold refinement: keep toes out of risers/walls and heels off the edge behind
    const tfx = Math.sin(f.targetYaw);
    const tfz = Math.cos(f.targetYaw);
    // first make sure the centre of the foothold is standable, then keep toes / heel clear
    f.target.x = tx;
    f.target.z = tz;
    this.sampleGround(f.target, c, terrain);
    tx = f.target.x;
    tz = f.target.z;
    const hC = f.target.y;
    let shift = 0;
    for (let d = 0.06; d < 0.25; d += 0.06) {
      const hd = terrain.height(tx + tfx * d, tz + tfz * d);
      if (hd > hC + 0.05) {
        shift = hd - c.pos.y < 0.36 && d <= 0.13 ? d + 0.075 : d - 0.26;
        break;
      }
    }
    if (shift === 0 && terrain.height(tx - tfx * 0.075, tz - tfz * 0.075) > hC + 0.05) shift = 0.085;
    f.target.x = tx + tfx * shift;
    f.target.z = tz + tfz * shift;
    this.sampleGround(f.target, c, terrain);
    f.landX =
      (px + sx * f.side * DIM.hipW - f.target.x) * Math.sin(f.targetYaw) +
      (pz + sz * f.side * DIM.hipW - f.target.z) * Math.cos(f.targetYaw);
  }

  private beginSwing(f: Foot, adjust: boolean, dur: number) {
    f.mode = SWING;
    f.u = 0;
    f.from.copy(f.pos);
    f.fromYaw = f.yaw;
    f.fromPitch = f.pitch;
    f.adjust = adjust;
    f.dur = dur;
    f.minY = f.pos.y;
    f.ready = false;
    f.pitchRate0 = -1;
  }

  private computeSlope(f: Foot, terrain: Terrain) {
    const fx = Math.sin(f.yaw);
    const fz = Math.cos(f.yaw);
    const hT = terrain.height(f.pos.x + fx * DIM.ballFwd, f.pos.z + fz * DIM.ballFwd);
    const hH = terrain.height(f.pos.x - fx * DIM.heelBack, f.pos.z - fz * DIM.heelBack);
    const dp = hT - hH;
    f.slopePitch = Math.abs(dp) < 0.09 ? -Math.atan2(dp, DIM.ballFwd + DIM.heelBack) : 0;
    const hL = terrain.height(f.pos.x + fz * 0.05, f.pos.z - fx * 0.05);
    const hR = terrain.height(f.pos.x - fz * 0.05, f.pos.z + fx * 0.05);
    const dr = hL - hR;
    f.slopeRoll = Math.abs(dr) < 0.06 ? Math.atan2(dr, 0.1) : 0;
  }

  private plant(f: Foot, terrain: Terrain, strength: number) {
    f.mode = STANCE;
    f.adjust = false;
    f.ready = false;
    f.plantPos.copy(f.pos);
    f.plantYaw = f.yaw;
    f.pivot = 0;
    f.pitchVel = 0;
    this.computeSlope(f, terrain);
    this.steps.push({ x: f.pos.x, y: f.pos.y, z: f.pos.z, yaw: f.yaw, side: f.side, strength });
  }

  /** Ankle joint from the ground reference + heel/toe pivot. */
  private computeAnkle(f: Foot) {
    const fx = Math.sin(f.yaw);
    const fz = Math.cos(f.yaw);
    const th = f.pitch;
    let along: number;
    let up: number;
    if (th >= 0) {
      const s = Math.sin(th);
      const co = Math.cos(th);
      along = DIM.ballFwd - DIM.ballFwd * co + DIM.ankleH * s;
      up = DIM.ballFwd * s + DIM.ankleH * co;
    } else {
      const s = Math.sin(-th);
      const co = Math.cos(-th);
      along = -DIM.heelBack + DIM.heelBack * co - DIM.ankleH * s;
      up = DIM.heelBack * s + DIM.ankleH * co;
    }
    f.ankle.set(f.pos.x + fx * along, f.pos.y + up, f.pos.z + fz * along);
  }

  /**
   * Weapon pose + two-bone arm IK.
   * The weapon blends between a CARRY pose (two-handed against the chest, or
   * simply following the swinging right hand for the pistol) and an AIM pose
   * defined in the aim frame at the eye, so the same data drives third- and
   * first-person. Hands are then solved onto the grip and hand-guard.
   */
  private weaponLayer(dt: number, c: CharacterController, W: WeaponPose | null, sw: number) {
    const rig = this.rig;
    if (!W) return;
    const def = W.def;
    const obj = W.obj;
    const aimK = smooth(this.aimW);
    const ads = this.adsW * (1 - W.lower);

    // ---- aim-frame pose (bob, sway and recoil are hip-fire flavour; ADS is steadier)
    const yawA = c.yaw + clamp(angleDiff(W.aimYaw, c.yaw), -1.25, 1.25);
    const ry = angleDiff(W.aimYaw, this.prevAimYaw) / dt;
    const rp = (W.aimPitch - this.prevAimPitch) / dt;
    this.prevAimYaw = W.aimYaw;
    this.prevAimPitch = W.aimPitch;
    const hipK = 1 - 0.85 * ads;
    const swX = this.swayX.update(clamp(-ry * 0.006, -0.035, 0.035), dt) * hipK;
    const swY = this.swayY.update(clamp(-rp * 0.006, -0.03, 0.03), dt) * hipK;
    const bobX = Math.sin(TAU * this.phase) * 0.011 * this.gaitW * hipK;
    const bobY = Math.cos(2 * TAU * this.phase) * 0.007 * this.gaitW * hipK;
    _wp.set(
      lerp(def.hip[0], def.ads[0], ads) + bobX + swX,
      lerp(def.hip[1], def.ads[1], ads) + bobY + swY,
      lerp(def.hip[2], def.ads[2], ads) - W.kickBack,
    );
    _e.set(-W.aimPitch, yawA, 0, 'YXZ');
    _qA.setFromEuler(_e);
    _wp.applyQuaternion(_qA).add(this.eye);
    _e.set(-W.kickUp + swY * 1.5, -swX * 2, swX * 3, 'YXZ');
    _qAim.copy(_qA).multiply(_q.setFromEuler(_e));

    // ---- carry pose
    if (def.twoHand) {
      // low-ready across the body; sprinting brings it up to port arms
      const sp = (this.sprintCarry = damp(this.sprintCarry, c.sprinting && c.speed > 5 ? 1 : 0, 7, dt));
      _cp.set(lerp(-0.04, -0.1, sp) + sw * 0.025, lerp(-0.02, -0.12, sp), lerp(0.17, 0.2, sp));
      rig.chest.localToWorld(_cp);
      _e.set(lerp(0.5, -0.7, sp), lerp(0.95, 0.9, sp) + sw * 0.1, 0.25 * (1 - sp), 'YXZ');
      rig.chest.getWorldQuaternion(_qC);
      _qCarry.copy(_qC).multiply(_q.setFromEuler(_e));
    } else {
      // pistol rides in the FK right hand (natural arm swing, muzzle down)
      const h = rig.arms[1].hand;
      h.getWorldQuaternion(_qCarry).multiply(RH_GRIP_INV);
      h.getWorldPosition(_cp);
      _cp.sub(_t.copy(RH_WRIST).applyQuaternion(_qCarry));
    }
    obj.position.lerpVectors(_cp, _wp, aimK);
    obj.quaternion.slerpQuaternions(_qCarry, _qAim, aimK);

    // ---- draw / reload / bolt cycle
    const rl = W.reload > 0 ? smooth(Math.sin(Math.PI * clamp01(W.reload)) * 1.6) : 0;
    const cyc = W.cycle > 0 ? Math.sin(Math.PI * W.cycle) : 0;
    if (W.lower > 0 || rl > 0 || cyc > 0) {
      _e.set(W.lower * 0.8 - rl * 0.3 + cyc * 0.06, 0, rl * 0.55 - cyc * 0.28, 'YXZ');
      obj.quaternion.multiply(_q.setFromEuler(_e));
      obj.position.y -= W.lower * 0.22 + rl * 0.05;
    }
    obj.updateMatrixWorld(true);

    // ---- hands onto the weapon
    const wHand = this.armedW * (def.twoHand ? 1 : aimK);
    _t.copy(RH_WRIST).applyMatrix4(obj.matrixWorld);
    _qh.copy(obj.quaternion).multiply(RH_GRIP);
    this.solveArm(1, _t, _qh, wHand);

    _t.set(def.left[0], def.left[1], def.left[2]).applyMatrix4(obj.matrixWorld);
    _qh.copy(obj.quaternion).multiply(def.twoHand ? LH_GRIP : LH_PISTOL);
    if (W.reload > 0) {
      // support hand travels to the belt for a fresh magazine and back
      const away = smoothstep(0.1, 0.28, W.reload) * (1 - smoothstep(0.52, 0.72, W.reload));
      _b.set(0.17, 0.05, 0.1);
      rig.hips.localToWorld(_b);
      _t.lerp(_b, away);
    }
    this.solveArm(0, _t, _qh, def.twoHand ? this.armedW : wHand);
  }

  /** Analytic two-bone IK for an arm, blended over its FK pose by `w`. */
  private solveArm(i: number, tgt: THREE.Vector3, handQ: THREE.Quaternion, w: number) {
    if (w < 0.002) return;
    const a = this.rig.arms[i];
    const L1 = DIM.upperArm;
    const L2 = DIM.foreArm;
    this.rig.chest.getWorldQuaternion(_qC);
    a.upper.getWorldPosition(_s);
    _n.subVectors(tgt, _s);
    let d = _n.length();
    _n.multiplyScalar(1 / Math.max(d, 1e-5));
    d = clamp(d, 0.12, L1 + L2 - 0.004);
    const aa = (L1 * L1 - L2 * L2 + d * d) / (2 * d);
    const hh = Math.sqrt(Math.max(0, L1 * L1 - aa * aa));
    // elbow pole: down, outward and slightly back relative to the chest
    _pv.set(i === 0 ? 0.55 : -0.55, -0.8, -0.25).applyQuaternion(_qC);
    _pv.addScaledVector(_n, -_pv.dot(_n));
    if (_pv.lengthSq() < 1e-6) _pv.set(0, -1, 0);
    _pv.normalize();
    _el.copy(_s).addScaledVector(_n, aa).addScaledVector(_pv, hh);
    _b.copy(_s).addScaledVector(_n, d); // reachable wrist

    basisQuat(_qU, _up.subVectors(_s, _el).normalize(), _n);
    basisQuat(_qF, _up.subVectors(_el, _b).normalize(), _n);
    a.upper.quaternion.slerp(_qT.copy(_qC).invert().multiply(_qU), w);
    a.fore.quaternion.slerp(_qT.copy(_qU).invert().multiply(_qF), w);
    a.hand.quaternion.slerp(_qT.copy(_qF).invert().multiply(handQ), w);
  }

  // ------------------------------------------------------------------- update
  update(
    dt: number,
    c: CharacterController,
    terrain: Terrain,
    time: number,
    camYaw: number,
    camPitch: number,
    weapon: WeaponPose | null = null,
  ) {
    const rig = this.rig;
    const feet = this.feet;
    const speed = c.speed;
    const grounded = c.grounded;

    // ---- crouch: staggered layers (hips lead, torso follows, arms settle last)
    const cr = c.crouching ? 1 : 0;
    const cH = this.crouchHip.update(cr, dt);
    const cT = this.crouchTorso.update(cr, dt);
    const cA = this.crouchArms.update(cr, dt);
    const cw = clamp01(cH);
    this.crouchBlend = cw;

    // ---- weapon layer weights
    const W = weapon;
    this.armedW = damp(this.armedW, W ? 1 : 0, 12, dt);
    this.aimW = damp(this.aimW, W && W.aim ? 1 : 0, 11, dt);
    this.adsW = damp(this.adsW, W && W.ads ? 1 : 0, 13, dt);

    // ---- travel direction relative to facing (directional blend)
    const moveW = smoothstep(0.25, 1.1, speed);
    const rel = speed > 0.3 ? angleDiff(Math.atan2(c.vel.x, c.vel.z), c.yaw) : 0;
    const absRel = Math.abs(rel);
    if (absRel > 1.95) this.backpedal = true;
    else if (absRel < 1.6) this.backpedal = false;
    // hips swing toward the travel direction, the spine counter-rotates to keep aim
    const hipTarget = clamp((this.backpedal ? angleDiff(rel, Math.PI) : rel) * 0.5 * moveW, -0.85, 0.85);
    this.hipYawOff = damp(this.hipYawOff, hipTarget, 9, dt);
    this.backW = damp(this.backW, this.backpedal ? 1 : 0, 8, dt);
    const sideK = Math.abs(Math.sin(rel)) * moveW;

    // ---- gait parameters
    this.blendGait(speed, cw);
    const p = this.p;
    p.stride *= lerp(1, 0.86, this.backW) * lerp(1, 0.9, sideK);
    p.kick *= 1 - 0.8 * this.backW;
    p.armGain *= 1 - 0.4 * this.backW;
    const runW = smoothstep(2.2, 4.2, speed) * (1 - cw);
    this.runK = smoothstep(1.8, 2.6, speed) * (1 - cw); // walking → running swing shape
    this.pace = smoothstep(3.2, 4.8, speed); // jog → full run
    const fwdK = clamp01(speed / 5);

    const pYaw = c.yaw + this.hipYawOff;
    const pfx = Math.sin(pYaw);
    const pfz = Math.cos(pYaw);
    const plx = pfz;
    const plz = -pfx;
    const ffx = Math.sin(c.yaw);
    const ffz = Math.cos(c.yaw);
    const flx = ffz;
    const flz = -ffx;

    const moving = grounded && speed > 0.25;
    // sharp turns shorten and quicken the steps: never rotate more than ~60° per step
    const freq = Math.max(speed / p.stride, moving ? Math.min(Math.abs(c.yawRate) / 1.05, 1.7) : 0);
    this.stanceTime = Math.min(p.duty / Math.max(freq, 0.05), 0.7);
    this.cadence = moving ? freq * 120 : 0;

    const rise = clamp01(c.vel.y / 6);
    const fall = clamp01(-c.vel.y / 8);

    // ---- take-off / touch-down
    if (!grounded && !this.wasAir) {
      for (const f of feet) {
        f.mode = AIR;
        f.u = 0;
        f.from.set(f.pos.x - c.pos.x, Math.min(f.pos.y - c.pos.y, 0.05), f.pos.z - c.pos.z);
        f.fromYaw = f.yaw;
      }
      const d0 = (feet[0].pos.x - feet[1].pos.x) * ffx + (feet[0].pos.z - feet[1].pos.z) * ffz;
      this.airLead = d0 >= 0 ? 0 : 1;
      this.gaitActive = false;
    }
    if (grounded && this.wasAir) {
      for (const f of feet) {
        this.sampleGround(f.pos, c, terrain);
        this.plant(f, terrain, 0.7 + 0.3 * c.landIntensity);
      }
      this.landImpulse = Math.max(this.landImpulse, 0.25 + c.landIntensity);
      this.land.v -= 1.2 + 3.4 * c.landIntensity;
      if (speed > 0.25) {
        // roll through: lead foot takes the weight, trailing foot steps through
        const lead = feet[this.airLead];
        this.phase = frac(0.04 - lead.off);
        lead.ready = false;
        feet[1 - this.airLead].ready = true;
        this.gaitActive = true;
      }
    }
    this.wasAir = !grounded;

    // ---- gait clock
    if (grounded) {
      if (moving && !this.gaitActive && !c.jumpPrep) {
        let first = feet[0].mode === SWING ? 0 : feet[1].mode === SWING ? 1 : -1;
        if (first < 0) {
          const sp = Math.max(speed, 0.01);
          const d0 = ((feet[0].pos.x - c.pos.x) * c.vel.x + (feet[0].pos.z - c.pos.z) * c.vel.z) / sp;
          const d1 = ((feet[1].pos.x - c.pos.x) * c.vel.x + (feet[1].pos.z - c.pos.z) * c.vel.z) / sp;
          first = d0 < d1 ? 0 : 1;
        }
        this.phase = frac(p.duty + 0.001 - feet[first].off);
        feet[0].ready = feet[1].ready = true;
        this.gaitActive = true;
      }
      if (this.gaitActive) {
        const settle = !moving;
        if (!c.jumpPrep) this.phase = frac(this.phase + dt * (settle ? Math.max(freq, 1.3) : freq));
        let allStance = true;
        for (const f of feet) {
          const pi = frac(this.phase + f.off);
          if (f.mode === STANCE) {
            if (pi < p.duty) f.ready = true;
            else if (f.ready && !settle && !c.jumpPrep) this.beginSwing(f, false, 0.3);
            // safety: body got too far from a planted foot → recover with a quick step
            if (f.mode === STANCE && Math.hypot(f.pos.x - c.pos.x, f.pos.z - c.pos.z) > 1.05) {
              this.beginSwing(f, true, 0.2);
              f.liftH = 0.1;
            }
          }
          if (f.mode !== STANCE) allStance = false;
        }
        if (settle && allStance) this.gaitActive = false;
      }

      // ---- idle foot adjustment / turn-in-place stepping
      if (!this.gaitActive && !c.jumpPrep) {
        this.adjustCooldown -= dt;
        if (feet[0].mode === STANCE && feet[1].mode === STANCE && this.adjustCooldown <= 0) {
          const busy = Math.abs(c.yawRate) > 0.4 || c.hasInput || Math.abs(this.crouchHip.v) > 0.25;
          const thr = busy ? 0.125 : 0.19;
          let worst = -1;
          let worstErr = 0;
          for (let i = 0; i < 2; i++) {
            const f = feet[i];
            this.footTarget(f, c, terrain, 0.2, pYaw, cw, moveW);
            const err =
              Math.hypot(f.target.x - f.pos.x, f.target.z - f.pos.z) +
              Math.abs(angleDiff(f.targetYaw, f.yaw)) * 0.3 +
              // turning on the spot: the foot on the inside of the turn opens it (no crossing legs)
              (Math.abs(c.yawRate) > 0.4 && Math.sign(c.yawRate) === f.side ? 0.06 : 0);
            if (err > thr && err > worstErr) {
              worst = i;
              worstErr = err;
            }
          }
          if (worst >= 0) {
            const f = feet[worst];
            // quick, light steps while the body is still rotating; unhurried when just settling
            const spin = smoothstep(1.5, 5, Math.abs(c.yawRate));
            this.beginSwing(f, true, clamp(0.21 + worstErr * 0.22, 0.21, 0.36) * lerp(1, 0.68, spin));
            f.liftH = 0.045 + Math.min(worstErr, 0.6) * 0.1;
            this.adjustCooldown = lerp(0.04, 0, spin);
          }
        }
      }
    }

    // ---- feet
    if (grounded) {
      const q = c.jumpPrep ? c.jumpPrepT / c.jumpPrepDur : 0;
      for (const f of feet) {
        if (f.mode === SWING) {
          let rate = f.adjust ? 1 / f.dur : Math.max(freq / Math.max(1 - p.duty, 0.2), 1 / 0.46);
          if (!f.adjust && !moving) rate = Math.max(rate, 1 / 0.28);
          f.u = Math.min(1, f.u + dt * rate);
          this.footTarget(f, c, terrain, (1 - f.u) / rate, pYaw, cw, moveW);
          const u = f.u;
          if (f.pitchRate0 < 0) f.pitchRate0 = clamp(f.pitchVel / rate, 0, 2.6); // heel-rise speed carried into the swing
          const wk = f.adjust ? 1 : 1 - this.runK; // walking-shape weight
          if (u <= dt * rate + 1e-6) {
            f.root0x = c.pos.x - c.vel.x * dt;
            f.root0z = c.pos.z - c.vel.z * dt;
          }
          // Horizontal: walking glides forward from toe-off; jogging lifts first, then travels, and
          // settles before touch-down; a full run travels the whole swing. Stepping up rises first.
          const upK = smoothstep(0.07, 0.17, f.target.y - f.from.y);
          const delay = 0.07 * (1 - this.pace);
          const sRun = smooth(Math.pow(clamp01((u - delay) / (1 - 2 * delay)), 0.9));
          const e = lerp(lerp(sRun, smooth(u), wk), smooth((u - 0.12) / 0.76), upK);
          const kv = lerp(lerp(smooth((u - 0.4) / 0.6), smooth(u), wk), smooth(u / 0.6), upK);
          // World-space at both ends (the foot leaves and meets the ground with zero ground speed),
          // body-relative through the middle: at running speed a purely world-space path leaves the
          // foot far behind after toe-off and throws it too far ahead before landing.
          const bw = 0.75 * Math.sin(Math.PI * u) ** 2;
          const wx = lerp(f.from.x, f.target.x, e);
          const wz = lerp(f.from.z, f.target.z, e);
          const bx = c.pos.x + lerp(f.from.x - f.root0x, f.target.x - f.root1x, e);
          const bz = c.pos.z + lerp(f.from.z - f.root0z, f.target.z - f.root1z, e);
          f.pos.x = lerp(wx, bx, bw);
          f.pos.z = lerp(wz, bz, bw);
          // a step that swings the foot round (turning) arcs out on its own side instead of
          // passing over the planted foot
          const o = feet[f.side > 0 ? 1 : 0];
          if (o.mode === STANCE && Math.abs(angleDiff(f.targetYaw, f.fromYaw)) > 0.78) {
            const cx = o.pos.x + Math.sin(o.yaw) * 0.065;
            const cz = o.pos.z + Math.cos(o.yaw) * 0.065;
            const ax = f.target.x - f.from.x;
            const az = f.target.z - f.from.z;
            const l2 = ax * ax + az * az;
            if (l2 > 1e-6) {
              const u0 = clamp(((cx - f.from.x) * ax + (cz - f.from.z) * az) / l2, 0, 1);
              if (u0 > 0.2 && u0 < 0.8) {
                const px = f.from.x + ax * u0 - cx;
                const pz = f.from.z + az * u0 - cz;
                const dist = Math.hypot(px, pz);
                const CLR = 0.165;
                if (dist < CLR) {
                  const nx = plx * f.side;
                  const nz = plz * f.side;
                  const along = px * nx + pz * nz;
                  const across = Math.sqrt(Math.max(dist * dist - along * along, 0));
                  const needed = Math.sqrt(Math.max(CLR * CLR - across * across, 0)) - along;
                  if (needed > 0) {
                    const amt = Math.min(needed / Math.sin(Math.PI * u0) ** 2, 0.15) * Math.sin(Math.PI * u) ** 2;
                    f.pos.x += nx * amt;
                    f.pos.z += nz * amt;
                  }
                }
              }
            }
          }
          const arc = swingArc(u, wk);
          let y = lerp(f.from.y, f.target.y, kv) + (f.adjust ? f.liftH : p.stepH) * arc;
          // clearance look-ahead so the foot rises over stair edges instead of clipping them
          const e2 = Math.min(1, e + 0.22);
          let need = Math.max(
            terrain.height(f.pos.x, f.pos.z),
            terrain.height(lerp(f.from.x, f.target.x, e2), lerp(f.from.z, f.target.z, e2)),
          );
          if (need - c.pos.y > 0.5) need = c.pos.y;
          f.minY = damp(f.minY, need, 35, dt);
          y = Math.max(y, f.minY + 0.03 * Math.sin(Math.PI * u));
          f.pos.y = y;
          f.yaw = lerpAngle(f.fromYaw, f.targetYaw, smooth(u));
          // foot attitude: keeps extending just after toe-off, toes come up gradually (walking) or
          // early (running) so it arrives heel-first at the strike angle
          const landPitch = this.pitchRule(f.landX, cw);
          const turn = lerp(smooth(u / 0.5), smooth((u - 0.15) / 0.85), wk);
          f.pitch =
            lerp(f.fromPitch, landPitch, turn) +
            f.pitchRate0 * u * (1 - u) * (1 - u) +
            p.kick * Math.sin(Math.PI * u) * (1 - u) * 1.6;
          f.swingW = Math.sin(Math.PI * f.u);
          if (f.u >= 1) {
            f.pos.copy(f.target);
            f.yaw = f.targetYaw;
            this.plant(f, terrain, clamp01(0.22 + speed / 8));
            // touch-down re-syncs the gait clock (keeps stance length honest while accelerating)
            if (this.gaitActive) {
              const pi = frac(this.phase + f.off);
              if (pi > p.duty) this.phase = frac(-f.off);
            }
          }
        } else {
          f.mode = STANCE;
          f.swingW = 0;
          // The planted foot stays put while the hips twist over it; past the limit (≈45° when
          // turning on the spot, less at speed) it pivots on the ball — only once the body has
          // rotated beyond it, and at 360°/s at most.
          {
            const rest = f.side * (lerp(0.15, 0.05, moveW) + 0.2 * cw);
            const twist = angleDiff(pYaw + rest, f.plantYaw);
            const soft = 0.14;
            const excess = Math.abs(twist) - lerp(0.78, 0.38, smoothstep(0.5, 1.6, speed));
            let wanted = 0;
            const behind = !(Math.abs(c.yawRate) > 0.17 && Math.sign(twist) !== Math.sign(c.yawRate));
            if (behind && excess > -soft) {
              wanted = Math.sign(twist) * (excess >= soft ? excess : (excess + soft) ** 2 / (4 * soft));
            }
            const stepP = 6.28 * dt;
            f.pivot += clamp(wanted - f.pivot, -stepP, stepP);
            if (f.pivot !== 0) {
              f.yaw = f.plantYaw + f.pivot;
              f.pos.x = f.plantPos.x + (Math.sin(f.plantYaw) - Math.sin(f.yaw)) * DIM.ballFwd;
              f.pos.z = f.plantPos.z + (Math.cos(f.plantYaw) - Math.cos(f.yaw)) * DIM.ballFwd;
            }
          }
          const fx = Math.sin(f.yaw);
          const fz = Math.cos(f.yaw);
          const x = (c.pos.x + plx * f.side * DIM.hipW - f.pos.x) * fx + (c.pos.z + plz * f.side * DIM.hipW - f.pos.z) * fz;
          let tp = this.pitchRule(x, cw);
          if (q > 0.55) tp += (0.6 * (q - 0.55)) / 0.45; // push-off: rise onto the toes
          const prevPitch = f.pitch;
          f.pitch = damp(f.pitch, tp, 40, dt);
          f.pitchVel = (f.pitch - prevPitch) / dt;
          // trailing leg ran out of length (hard acceleration, braking, ledges): release it early
          const other = feet[f.side > 0 ? 1 : 0];
          if (x > 0.25 && (other.mode === STANCE || (this.gaitActive && p.duty < 0.5))) {
            const dh2 = (f.ankle.x - f.hip.x) ** 2 + (f.ankle.z - f.hip.z) ** 2;
            const vert = this.hipTargetAbs - 0.07 - f.ankle.y;
            if (vert > 0 && LEG_MAX * LEG_MAX - dh2 < vert * vert) {
              if (this.gaitActive && moving) {
                this.beginSwing(f, false, 0.3);
                this.phase = frac(p.duty + 0.001 - f.off);
              } else {
                this.beginSwing(f, true, 0.24);
                f.liftH = 0.07;
              }
            }
          }
        }
        f.contact = damp(f.contact, f.mode === STANCE ? 1 : 0, 26, dt);
      }
    } else {
      // ---- airborne leg pose (body space), blended in from the take-off pose
      const h = c.heightAboveGround;
      const apex = 1 - Math.max(rise, fall);
      const near = clamp01(h / 0.6);
      for (let i = 0; i < 2; i++) {
        const f = feet[i];
        const lead = i === this.airLead;
        f.u = Math.min(1, f.u + dt / 0.18);
        const e = smooth(f.u);
        // running jumps split the legs into a leap; standing jumps keep them under the body
        const fw =
          (lead ? 0.1 + 0.34 * fwdK : -0.1 - 0.42 * fwdK * (1 - 0.7 * fall)) * (0.35 + 0.65 * near) + 0.1 * fall * near;
        let tuck = lead ? 0.08 + 0.16 * apex + 0.14 * fwdK : 0.04 + 0.12 * apex + 0.16 * fwdK * (1 - fall);
        tuck = Math.min(tuck * (1 - 0.45 * fall), h * 0.8);
        const tx = ffx * fw + flx * f.side * 0.085;
        const tz = ffz * fw + flz * f.side * 0.085;
        f.pos.set(c.pos.x + lerp(f.from.x, tx, e), c.pos.y + lerp(f.from.y, tuck, e), c.pos.z + lerp(f.from.z, tz, e));
        f.yaw = lerpAngle(f.fromYaw, c.yaw + f.side * 0.06, e);
        f.pitch = damp(f.pitch, lerp(0.2, lead ? 0.45 : 0.95, near), 14, dt);
        f.contact = damp(f.contact, 0, 26, dt);
        f.swingW = 0;
      }
    }

    // ---- jump anticipation / landing compression
    let dipT = 0;
    let prepQ = 0;
    if (c.jumpPrep) {
      prepQ = c.jumpPrepT / c.jumpPrepDur;
      dipT = prepQ < 0.6 ? 1 : -0.1;
    }
    const dip = this.jumpDip.update(dipT, dt);
    const dipPos = Math.max(dip, 0);
    this.land.update(0, dt);
    const landK = clamp(-this.land.x, -0.05, 0.3);
    const landW = clamp01(landK / 0.12);

    // ---- momentum lean (acceleration → pitch, lateral acceleration → bank)
    const accF = c.accel.x * ffx + c.accel.z * ffz;
    const accL = c.accel.x * flx + c.accel.z * flz;
    const gA = grounded ? 1 : 0.3;
    const leanT =
      p.lean * (1 - 1.7 * this.backW) +
      clamp(accF * 0.018, -0.22, 0.17) * gA +
      (grounded ? 0 : clamp(-c.vel.y * 0.012, -0.08, 0.1) + 0.06 * fwdK);
    const lean = this.leanPitch.update(leanT, dt);
    const bank = this.bank.update(clamp(-accL * 0.014, -0.3, 0.3) * gA, dt);
    this.leanOut = lean;
    this.bankOut = bank;

    // ---- pelvis position
    if (grounded && this.prevGrounded && !c.justLanded) this.refOff -= c.pos.y - this.prevY;
    this.refOff = clamp(damp(this.refOff, 0, 14, dt), -0.45, 0.45);
    this.prevY = c.pos.y;
    this.prevGrounded = grounded;
    const baseY = c.pos.y + this.refOff;
    this.visualY = baseY;

    this.gaitW = damp(this.gaitW, this.gaitActive ? 1 : 0, 10, dt);
    const bounce = -p.bounce * Math.cos(2 * TAU * (this.phase - p.duty * 0.5)) * this.gaitW;
    this.bounceOut = bounce;
    this.exertion = damp(this.exertion, c.sprinting && speed > 5 ? 1 : speed > 4 ? 0.45 : 0, c.sprinting ? 0.3 : 0.12, dt);
    this.breathPhase += dt * lerp(1.6, 4.4, this.exertion);
    const breath = Math.sin(this.breathPhase) * lerp(1, 2.6, this.exertion);
    const idleW = grounded ? 1 - moveW : 0;
    const brakeW = clamp01(-accF / 9) * moveW;
    const hipY =
      DIM.hipH -
      p.hipDrop * moveW -
      cH * 0.28 -
      Math.max(dip, -0.3) * lerp(0.17, 0.09, fwdK) -
      landK +
      bounce +
      breath * 0.0025 * idleW -
      0.03 * brakeW;

    const sway = Math.sin(time * 0.55) * 0.014 * idleW * (1 - cw * 0.5);
    // weight rides over the supporting foot — in the gait, and when stepping round on the spot
    const latT =
      (feet[0].contact - feet[1].contact) * (lerp(0.03, 0.012, runW) * this.gaitW + 0.04 * (1 - this.gaitW)) +
      sway -
      bank * 0.32;
    const lat = this.pelvisLat.update(latT, dt);
    const fore = -0.045 * lean - 0.05 * cH - landK * 0.25 - dipPos * 0.03;
    const hx = c.pos.x + plx * lat + ffx * fore;
    const hz = c.pos.z + plz * lat + ffz * fore;

    // pelvis IK: never ask a planted leg to be longer than it is
    let limRel = Infinity;
    if (grounded) {
      for (const f of feet) {
        // a foot about to land already starts easing the pelvis down → smooth, continuous bob
        if (f.mode === STANCE) {
          this.computeAnkle(f);
          const jx = hx + plx * f.side * DIM.hipW;
          const jz = hz + plz * f.side * DIM.hipW;
          const dh2 = (f.ankle.x - jx) ** 2 + (f.ankle.z - jz) ** 2;
          limRel = Math.min(limRel, f.ankle.y + Math.sqrt(Math.max(LEG_MAX * LEG_MAX - dh2, 0.04)) - baseY);
        } else if (f.u > 0.3) {
          // predicted geometry at touch-down, relaxed early in the swing
          const relax = (1 - smoothstep(0.3, 1, f.u)) * 0.07;
          const lxc = clamp(f.landX, -0.5, 0.5);
          const dh2 = lxc * lxc + 0.0004;
          limRel = Math.min(
            limRel,
            f.target.y + DIM.ankleH + 0.012 + Math.sqrt(Math.max(LEG_MAX * LEG_MAX - dh2, 0.04)) - baseY + relax,
          );
        }
      }
    }
    const floorRel = hipY - MAX_PELVIS_DROP;
    const relT = Math.min(hipY, Math.max(limRel, floorRel));
    let relY = this.pelvisRel.update(relT, dt);
    const cap = Math.max(limRel, floorRel);
    if (cap < relY) {
      relY = cap;
      this.pelvisRel.x = relY;
    }
    this.hipTargetAbs = baseY + hipY;
    const hy = baseY + relY + DIM.hipDown;

    // ---- pelvis rotation: yaw with the stride, list toward the swing side
    for (const f of feet) f.fwd = (f.pos.x - c.pos.x) * pfx + (f.pos.z - c.pos.z) * pfz;
    const dF = feet[0].fwd - feet[1].fwd;
    const gyaw = this.gaitYaw.update(
      grounded ? -clamp(dF * 0.1, -0.14, 0.14) * lerp(0.6, 1, this.gaitW) * (1 - 0.3 * cw) : 0,
      dt,
    );
    const groll = this.roll.update(
      -(feet[0].swingW - feet[1].swingW) * lerp(0.05, 0.075, runW) * this.gaitW + sway * 1.6,
      dt,
    );
    // pelvis tips forward at each heel strike and back at mid-stance (twice per stride)
    const tiltOsc = 0.03 * Math.cos(2 * TAU * this.phase) * this.gaitW * (1 - this.runK) * moveW;
    const pPitch = lean * 0.4 + cT * 0.2 + dipPos * 0.22 + landK * 0.9 + tiltOsc;
    rig.hips.position.set(hx, hy, hz);
    rig.hips.rotation.set(pPitch, pYaw + gyaw, groll + bank * 0.4, 'YXZ');

    // ---- spine: counter-rotates against the pelvis; head leads turns and stays level
    let lookT = 0;
    if (!c.strafing) {
      if (c.hasInput) lookT = clamp(angleDiff(c.moveYaw, c.yaw), -1.3, 1.3);
      else {
        const d = angleDiff(camYaw, c.yaw);
        lookT = Math.abs(d) < 2.3 ? clamp(d, -1.1, 1.1) * 0.75 : 0;
      }
    }
    const look = this.look.update(lookT, dt);
    // aim offset: the upper body follows the weapon's pitch and blades toward the stock
    const aimK = smooth(this.aimW);
    const aimP = W ? clamp(W.aimPitch, -1.25, 1.25) * aimK : 0;
    const blade = W ? (W.def.twoHand ? -0.3 : -0.1) * aimK * (1 - 0.5 * this.adsW) : 0;
    const sPitch = lean * 0.3 + cT * 0.2 + dipPos * 0.16 + landK * 0.7 - breath * 0.004 - aimP * 0.2 - tiltOsc;
    const cPitch = lean * 0.3 + cT * 0.22 + dipPos * 0.12 + landK * 0.5 - aimP * 0.25;
    const sRoll = -groll * 0.55 + bank * 0.3;
    rig.spine.rotation.set(sPitch, -gyaw * 0.9 - this.hipYawOff * 0.45 + look * 0.12 + blade * 0.35, sRoll, 'YXZ');
    rig.chest.rotation.set(cPitch, -gyaw * 0.9 - this.hipYawOff * 0.55 + look * 0.2 + blade * 0.65, sRoll, 'YXZ');
    rig.ribs.scale.set(1 + breath * 0.006, 1 + breath * 0.008, 1 + breath * 0.016);
    let headPitch = -(pPitch + sPitch + cPitch) * 0.78 - camPitch * 0.25 * (c.strafing ? 1 : 0.6);
    if (W) headPitch = lerp(headPitch, -clamp(W.aimPitch, -1.25, 1.25) - (pPitch + sPitch + cPitch), aimK);
    const headRoll = -(-0.1 * groll + bank) * 0.7 - 0.12 * this.adsW * (W && W.def.twoHand ? 1 : 0);
    rig.neck.rotation.set(headPitch * 0.5, gyaw * 0.4 + look * 0.25 - blade * 0.5, headRoll * 0.5, 'YXZ');
    rig.head.rotation.set(headPitch * 0.5, gyaw * 0.4 + look * 0.3 - blade * 0.5, headRoll * 0.5, 'YXZ');

    // ---- arms: driven by the opposite leg, plus jump / balance overlays
    const leadSign = this.airLead === 0 ? -1 : 1;
    const swT = grounded ? clamp(p.armGain * -dF, -1.4, 1.4) : leadSign * 0.85 * fwdK;
    const sw = this.armSwing.update(swT, dt);
    let bothT = 0;
    let outT = 0;
    let elbT = p.elbow;
    if (c.jumpPrep) {
      bothT = prepQ < 0.6 ? 0.75 : -0.7; // wind back, then throw forward
    } else if (!grounded) {
      // standing jump: both arms throw up; running jump: mostly opposition with the lead leg
      bothT = (-0.35 - 0.75 * rise) * (1 - 0.6 * fwdK) - 0.2 * fall;
      outT = 0.4 + 0.4 * fall;
      elbT = lerp(p.elbow, 0.8, 0.7);
    } else {
      bothT = -0.35 * landW;
      outT = 0.3 * landW + 0.22 * c.weights.STOP + 0.12 * c.weights.RECOVERY + 0.1 * brakeW;
    }
    const both = this.armBoth.update(bothT, dt);
    const out = this.armOut.update(outT, dt);
    const elb = this.elbow.update(elbT, dt);
    for (let i = 0; i < 2; i++) {
      const s = i === 0 ? 1 : -1;
      const f = s * sw; // >0 → this arm is forward
      const a = rig.arms[i];
      const pitch = -f * (f > 0 ? 1 : 0.9) + both + 0.12 * runW + 0.12 * cA; // crouch: elbows tucked, forearms level
      const abd = 0.07 + 0.06 * runW + 0.2 * cA + out;
      const twist = -s * (0.4 * runW + 0.3 * cA);
      a.upper.rotation.set(pitch, twist, s * abd, 'XZY');
      const flex = clamp(elb + f * (f > 0 ? 0.5 : 0.3) * (1 - 0.4 * runW), 0.05, 2.3);
      a.fore.rotation.set(-flex, 0, 0);
      a.hand.rotation.set(-0.12, 0, s * 0.1);
    }

    // ---- weapon + arm IK on top of the FK arms
    rig.hips.updateMatrixWorld(true);
    this.eye.set(0, 0.118, 0.085);
    rig.head.localToWorld(this.eye);
    this.weaponLayer(dt, c, W, sw);

    // ---- legs: analytic two-bone IK from the solved hip joints to the planted ankles
    rig.hips.updateMatrixWorld(true);
    this.maxStretch = 0;
    for (let i = 0; i < 2; i++) {
      const f = feet[i];
      const leg = rig.legs[i];
      this.computeAnkle(f);
      f.hip.set(f.side * DIM.hipW, -DIM.hipDown, 0);
      rig.hips.localToWorld(f.hip);
      _n.subVectors(f.ankle, f.hip);
      let d = _n.length();
      _n.multiplyScalar(1 / Math.max(d, 1e-5));
      f.stretch = Math.max(0, d - LEG_MAX);
      if (f.mode === STANCE) this.maxStretch = Math.max(this.maxStretch, f.stretch);
      if (d > LEG_MAX) {
        d = LEG_MAX;
        f.ankle.copy(f.hip).addScaledVector(_n, d);
      }
      d = Math.max(d, 0.3);
      const a = (DIM.thigh * DIM.thigh - DIM.shin * DIM.shin + d * d) / (2 * d);
      const hh = Math.sqrt(Math.max(0, DIM.thigh * DIM.thigh - a * a));
      // knee pole: between pelvis-forward and foot-forward, slightly outward (more when crouched)
      const kOut = f.side * (0.1 + 0.3 * cw);
      _pv.set(
        pfx * 0.55 + Math.sin(f.yaw) * 0.45 + plx * kOut,
        0,
        pfz * 0.55 + Math.cos(f.yaw) * 0.45 + plz * kOut,
      );
      _pv.addScaledVector(_n, -_pv.dot(_n));
      if (_pv.lengthSq() < 1e-6) _pv.set(pfx, 0, pfz);
      _pv.normalize();
      f.knee.copy(f.hip).addScaledVector(_n, a).addScaledVector(_pv, hh);

      leg.thigh.position.copy(f.hip);
      setBasis(leg.thigh, _up.subVectors(f.hip, f.knee).normalize(), _pv);
      leg.shin.position.copy(f.knee);
      setBasis(leg.shin, _up.subVectors(f.knee, f.ankle).normalize(), _pv);
      leg.foot.position.copy(f.ankle);
      _e.set(f.slopePitch * f.contact, f.yaw, f.slopeRoll * f.contact, 'YXZ');
      leg.foot.quaternion.setFromEuler(_e).multiply(_q.setFromAxisAngle(X_AXIS, f.pitch));
      // toes stay flat on the ground while the heel peels off
      leg.toe.rotation.x = lerp(-f.pitch * 0.7, clamp(-f.pitch, -1.15, 0), f.contact);
    }
    void _v;
  }
}
