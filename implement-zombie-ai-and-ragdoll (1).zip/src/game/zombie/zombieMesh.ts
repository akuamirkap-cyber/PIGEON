import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { L, NP, P, SEGS } from './skeleton';

type RGB = [number, number, number];
type ColorFn = (x: number, y: number, z: number) => RGB;

const hash = (x: number, y: number, z: number) => {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
};
/** Cheap smooth-ish 3D noise for grime / stains. */
function noise(x: number, y: number, z: number) {
  const f = 9;
  return (
    0.5 * Math.sin(x * f + Math.sin(z * f * 0.7) * 2) * Math.cos(y * f * 0.8 + x * 3) +
    0.35 * Math.sin(z * f * 1.9 + y * 5.1) * Math.sin(x * f * 2.3 - 1.3) +
    0.15 * (hash(x, y, z) * 2 - 1)
  );
}
let stainSeed = 0;
/** Clothing: grime, dark blood stains, worn patches. */
const cloth = (stain = 0.25): ColorFn => {
  const sd = (stainSeed += 1.37);
  return (x, y, z) => {
    const n = noise(x + sd, y, z - sd);
    const g = 0.78 + 0.22 * n;
    const st = noise(x * 1.7 - sd, y * 1.3, z * 1.9 + sd * 0.5);
    if (st > 1 - stain) return [0.55 * g, 0.12 * g, 0.1 * g]; // dried blood
    if (n < -0.55) return [0.45, 0.42, 0.38]; // torn / filthy patch
    return [g, g * 0.98, g * 0.94];
  };
};
const skin: ColorFn = (x, y, z) => {
  const n = noise(x * 1.3, y * 1.3, z * 1.3);
  const g = 0.86 + 0.16 * n;
  if (n > 0.62) return [0.72 * g, 0.62 * g, 0.7 * g]; // bruising
  return [g, g, g * 0.98];
};
const flat =
  (r: number, g: number, b: number): ColorFn =>
  () => [r, g, b];

function prim(geo: THREE.BufferGeometry, col: ColorFn, m?: THREE.Matrix4) {
  if (m) geo.applyMatrix4(m);
  geo.deleteAttribute('uv');
  const p = geo.attributes.position;
  const c = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) {
    const [r, g, b] = col(p.getX(i), p.getY(i), p.getZ(i));
    c[i * 3] = r;
    c[i * 3 + 1] = g;
    c[i * 3 + 2] = b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(c, 3));
  if (!geo.index) {
    const idx: number[] = [];
    for (let i = 0; i < p.count; i++) idx.push(i);
    geo.setIndex(idx);
  }
  return geo;
}
const M = (x = 0, y = 0, z = 0, sx = 1, sy = 1, sz = 1, rx = 0, ry = 0, rz = 0) =>
  new THREE.Matrix4().compose(
    new THREE.Vector3(x, y, z),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)),
    new THREE.Vector3(sx, sy, sz),
  );
const sph = (col: ColorFn, x: number, y: number, z: number, rx: number, ry: number, rz: number, seg = 12) =>
  prim(new THREE.SphereGeometry(1, seg, Math.max(6, (seg * 2) / 3)), col, M(x, y, z, rx, ry, rz));
/** Limb along +Y from 0 to len (hanging limbs: +Y points down the limb). */
const limb = (col: ColorFn, r0: number, r1: number, len: number, wob = 0) => {
  const g = new THREE.CylinderGeometry(r1, r0, len, 10, 3, true);
  g.translate(0, len / 2, 0);
  if (wob > 0) {
    // lumpy, uneven silhouette (worn baggy cloth / wasted flesh)
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const k = 1 + wob * noise(p.getX(i) * 3, p.getY(i) * 3, p.getZ(i) * 3);
      p.setX(i, p.getX(i) * k);
      p.setZ(i, p.getZ(i) * k);
    }
  }
  return [prim(g, col), sph(col, 0, 0, 0, r0, r0, r0, 10), sph(col, 0, len, 0, r1, r1, r1, 10)];
};
const merge = (parts: THREE.BufferGeometry[]) => {
  const g = mergeGeometries(parts)!;
  g.computeBoundingSphere();
  return g;
};

function buildGeometries() {
  const G: Record<string, THREE.BufferGeometry> = {};
  // ---- head: hollow cheeks, open jaw, sunken milky eyes, bloody mouth
  const face: ColorFn = (x, y, z) => {
    const s = skin(x, y, z);
    if (z > 0.04 && y < 0.075 && Math.abs(x) < 0.06) return [0.62, 0.16, 0.14]; // blood round the mouth
    if (z > 0.06 && y > 0.105 && y < 0.145 && Math.abs(Math.abs(x) - 0.036) < 0.026) return [s[0] * 0.55, s[1] * 0.5, s[2] * 0.58]; // dark eye bags
    return s;
  };
  G.head = merge([
    sph(face, 0, 0.125, -0.005, 0.094, 0.114, 0.104, 16),
    sph(face, 0, 0.05, 0.03, 0.066, 0.042, 0.06, 12), // jaw (hanging open)
    sph(flat(0.18, 0.03, 0.03), 0, 0.068, 0.078, 0.036, 0.02, 0.02, 8), // mouth cavity
    sph(flat(0.85, 0.8, 0.68), 0, 0.08, 0.085, 0.03, 0.006, 0.012, 8), // teeth
    sph(face, 0, 0.11, 0.1, 0.014, 0.022, 0.02, 8), // nose
    sph(flat(0.25, 0.18, 0.2), 0.036, 0.128, 0.086, 0.022, 0.016, 0.012, 8),
    sph(flat(0.25, 0.18, 0.2), -0.036, 0.128, 0.086, 0.022, 0.016, 0.012, 8),
    sph(flat(1.45, 1.42, 1.25), 0.036, 0.127, 0.09, 0.0105, 0.009, 0.008, 8), // milky eyes
    sph(flat(1.45, 1.42, 1.25), -0.036, 0.127, 0.09, 0.0105, 0.009, 0.008, 8),
    sph(face, 0.094, 0.115, 0, 0.012, 0.024, 0.016, 8),
    sph(face, -0.094, 0.115, 0, 0.012, 0.024, 0.016, 8),
  ]);
  const neckCol: ColorFn = (x, y, z) => (x > 0.02 && z > -0.01 && y > 0.02 && y < 0.07 ? [0.55, 0.12, 0.1] : skin(x, y, z));
  G.neck = merge([prim(new THREE.CylinderGeometry(0.046, 0.054, 0.13, 10, 2, true).translate(0, 0.05, 0.005), neckCol)]);
  // ---- torso: hunched back, dirty shirt with a collar
  const shirt = cloth(0.28);
  G.chest = merge([
    sph(shirt, 0, 0.165, 0.005, 0.172, 0.2, 0.118, 14),
    sph(shirt, 0, 0.245, -0.045, 0.14, 0.1, 0.085, 10), // hunch
    sph(shirt, 0.158, 0.29, -0.005, 0.074, 0.07, 0.074, 10),
    sph(shirt, -0.158, 0.29, -0.005, 0.074, 0.07, 0.074, 10),
    prim(new THREE.TorusGeometry(0.062, 0.02, 6, 16), shirt, M(0, 0.318, 0.012, 1.1, 1, 0.9, Math.PI / 2 + 0.2)),
  ]);
  const shirt2 = cloth(0.3);
  const hem = new THREE.CylinderGeometry(0.155, 0.165, 0.09, 14, 2, true);
  {
    // ragged untucked hem
    const p = hem.attributes.position;
    for (let i = 0; i < p.count; i++) if (p.getY(i) < 0) p.setY(i, p.getY(i) - Math.max(0, noise(p.getX(i) * 4, 0, p.getZ(i) * 4)) * 0.05);
  }
  G.abdomen = merge([sph(shirt2, 0, 0.1, 0.005, 0.152, 0.125, 0.108, 12), prim(hem, shirt2, M(0, 0.02, 0.003, 1, 1, 0.74))]);
  const pants = cloth(0.18);
  G.pelvis = merge([
    sph(pants, 0, 0.0, 0, 0.158, 0.112, 0.112, 12),
    prim(new THREE.TorusGeometry(0.15, 0.014, 6, 20), flat(0.25, 0.2, 0.18), M(0, 0.072, 0, 1, 1, 0.75, Math.PI / 2)),
  ]);
  // ---- arms (hanging: local +Y runs down the limb)
  G.upperArm = merge(limb(cloth(0.22), 0.058, 0.047, L.upper, 0.08));
  G.forearm = merge([
    ...limb(cloth(0.2), 0.046, 0.036, L.fore, 0.06),
    prim(new THREE.CylinderGeometry(0.04, 0.04, 0.03, 10, 1, true), flat(0.7, 0.68, 0.65), M(0, 0.02, 0)),
  ]);
  const handCol: ColorFn = (x, y, z) => (y > 0.135 ? [0.35, 0.28, 0.27] : skin(x, y, z));
  G.hand = merge([
    sph(handCol, 0, 0.055, 0, 0.04, 0.058, 0.022, 10),
    sph(handCol, 0, 0.12, -0.012, 0.037, 0.045, 0.017, 10), // clawed fingers
    sph(handCol, 0.03, 0.05, -0.018, 0.014, 0.032, 0.016, 8),
  ]);
  // ---- legs
  G.thigh = merge(limb(cloth(0.2), 0.086, 0.064, L.thigh, 0.07));
  G.shin = merge([
    ...limb(cloth(0.22), 0.064, 0.05, L.shin, 0.06),
    prim(new THREE.CylinderGeometry(0.058, 0.066, 0.06, 10, 1, true), cloth(0.1), M(0, L.shin - 0.05, 0)),
  ]);
  // foot: local +Y runs from ankle to toe, local +Z points DOWN
  const shoe = cloth(0.1);
  G.foot = merge([
    prim(new RoundedBoxGeometry(0.1, 0.26, 0.085, 2, 0.03), shoe, M(0, 0.05, 0.035)),
    prim(new RoundedBoxGeometry(0.104, 0.27, 0.02, 1, 0.008), flat(0.35, 0.33, 0.3), M(0, 0.05, 0.075)),
    sph(shoe, 0, 0, 0, 0.05, 0.05, 0.05, 8),
  ]);
  // the ankle→toe axis slopes down ~20°: tilt the shoe back so the sole sits flat
  G.foot.applyMatrix4(new THREE.Matrix4().makeRotationX(-0.34));
  // ---- hair variants (head local)
  const hair: ColorFn = (x, y, z) => {
    const n = 0.8 + 0.25 * noise(x * 3, y * 3, z * 3);
    return [n, n, n];
  };
  const tufts = (n: number, seed: number, yMin: number) => {
    const out: THREE.BufferGeometry[] = [];
    for (let i = 0; i < n; i++) {
      const a = hash(i, seed, 1) * Math.PI * 2;
      const e = yMin + hash(i, seed, 2) * (1.35 - yMin);
      const x = Math.cos(a) * Math.cos(e) * 0.1;
      const z = Math.sin(a) * Math.cos(e) * 0.1 - 0.01;
      const y = 0.13 + Math.sin(e) * 0.105;
      out.push(sph(hair, x, y, z, 0.03 + hash(i, seed, 3) * 0.025, 0.018, 0.03, 6));
    }
    return out;
  };
  const cap = (open: number) =>
    prim(new THREE.SphereGeometry(0.11, 14, 8, 0, Math.PI * 2, 0, Math.PI * open), hair, M(0, 0.128, -0.012, 0.97, 1.02, 1.02, -0.45));
  G.hair0 = merge([cap(0.52), ...tufts(14, 1, 0.3)]); // messy short
  G.hair1 = merge([
    cap(0.55),
    sph(hair, 0, 0.06, -0.075, 0.098, 0.13, 0.055, 10), // long, matted, hanging
    sph(hair, 0.08, 0.06, -0.02, 0.03, 0.11, 0.05, 8),
    sph(hair, -0.08, 0.05, -0.02, 0.03, 0.12, 0.05, 8),
    ...tufts(8, 2, 0.5),
  ]);
  G.hair2 = merge([
    prim(new THREE.TorusGeometry(0.095, 0.03, 6, 16, Math.PI * 1.3), hair, M(0, 0.12, -0.01, 1, 1, 1.05, Math.PI / 2, 0, Math.PI * 0.85)),
    ...tufts(6, 3, 0.9), // balding with stringy patches
  ]);
  // ---- stump: ragged raw flesh, protruding splintered bone, tendons and a torn cloth fringe
  const stumpCol: ColorFn = (x, y, z) => {
    const n = noise(x * 2, y * 2, z * 2);
    return y > 0.1 ? [0.5 + 0.15 * n, 0.05, 0.05] : [0.3, 0.02, 0.02];
  };
  const sg = new THREE.SphereGeometry(1, 12, 8);
  {
    const p = sg.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const k = 1 + 0.32 * noise(p.getX(i) * 2.3, p.getY(i) * 2.3, p.getZ(i) * 2.3);
      p.setXYZ(i, p.getX(i) * k, p.getY(i) * 0.42 * k, p.getZ(i) * k);
    }
  }
  const bone = new THREE.CylinderGeometry(0.22, 0.3, 1.1, 7, 2);
  {
    const p = bone.attributes.position;
    for (let i = 0; i < p.count; i++) if (p.getY(i) > 0.5) p.setY(i, p.getY(i) + (hash(i, 1, 2) - 0.5) * 0.5); // splintered end
  }
  bone.translate(0.08, 0.45, 0.05);
  const strips: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + 0.4;
    const t = new THREE.CylinderGeometry(0.06, 0.1, 0.55 + hash(i, 3, 1) * 0.4, 5);
    strips.push(prim(t, i % 2 ? flat(0.55, 0.08, 0.07) : flat(0.72, 0.6, 0.55), M(Math.cos(a) * 0.62, 0.25, Math.sin(a) * 0.62, 1, 1, 1, Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5)));
  }
  const fringe = new THREE.CylinderGeometry(1.15, 1.25, 0.5, 14, 2, true);
  {
    const p = fringe.attributes.position;
    for (let i = 0; i < p.count; i++) if (p.getY(i) > 0) p.setY(i, p.getY(i) + (hash(i, 7, 3) - 0.3) * 0.6);
  }
  fringe.translate(0, -0.25, 0);
  G.stump = merge([prim(sg, stumpCol), prim(bone, flat(0.92, 0.87, 0.76)), ...strips, prim(fringe, flat(0.3, 0.27, 0.25))]);
  return G;
}


const NOISE_GLSL = `
float zhash(vec3 p){ p = fract(p*0.3183099+0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float znoise(vec3 x){ vec3 i = floor(x); vec3 f = fract(x); f = f*f*(3.0-2.0*f);
  return mix(mix(mix(zhash(i), zhash(i+vec3(1,0,0)), f.x), mix(zhash(i+vec3(0,1,0)), zhash(i+vec3(1,1,0)), f.x), f.y),
             mix(mix(zhash(i+vec3(0,0,1)), zhash(i+vec3(1,0,1)), f.x), mix(zhash(i+vec3(0,1,1)), zhash(i+vec3(1,1,1)), f.x), f.y), f.z); }
varying vec3 vLoc; varying vec4 vW0; varying vec4 vW1; varying vec4 vW2; varying vec4 vTear;
`;
const WOUND_GLSL = `
void zWound(vec4 W, float n1, inout float wound, inout float rim, inout float core){
  float d = distance(vLoc, W.xyz);
  float rr = (0.016 + 0.028 * W.w) * (0.65 + 0.7 * n1);
  float on = step(0.001, W.w);
  wound = max(wound, on * (1.0 - smoothstep(rr * 0.7, rr, d)));
  rim = max(rim, on * (1.0 - smoothstep(rr, rr * 2.1, d)));
  core = max(core, on * (1.0 - smoothstep(0.0, rr * 0.42, d)));
}
`;
/**
 * Per-instance damage on the real animated mesh: wounds live in the body part's
 * local space (so they follow every animation and ragdoll pose), rips tear
 * through clothing to rotten skin, craters dent the surface, blasts char it.
 */
function damageMaterial(cloth: boolean, rough: number) {
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: rough, metalness: 0 });
  if (cloth) m.defines = { STANDARD: '', Z_CLOTH: '' };
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nattribute vec4 aW0; attribute vec4 aW1; attribute vec4 aW2; attribute vec4 aTear;' + NOISE_GLSL)
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vLoc = position; vW0 = aW0; vW1 = aW1; vW2 = aW2; vTear = aTear;
        float cr = aW0.w * (1.0 - smoothstep(0.0, 0.03 + 0.03*aW0.w, distance(position, aW0.xyz)))
                 + aW1.w * (1.0 - smoothstep(0.0, 0.03 + 0.03*aW1.w, distance(position, aW1.xyz)))
                 + aW2.w * (1.0 - smoothstep(0.0, 0.03 + 0.03*aW2.w, distance(position, aW2.xyz)));
        float tn = znoise(position * 34.0 + aTear.y * 5.0);
        transformed -= objectNormal * (min(cr, 1.6) * 0.013 + aTear.x * max(0.0, tn - 0.55) * 0.014);`,
      );
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\n' + NOISE_GLSL + WOUND_GLSL)
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float n1 = znoise(vLoc * 60.0 + vTear.y * 7.0);
        float n2 = znoise(vLoc * vec3(16.0, 34.0, 16.0) + vTear.y * 3.0) * 0.7 + znoise(vLoc * 70.0 + vTear.y) * 0.3;
        float wound = 0.0; float rim = 0.0; float core = 0.0;
        zWound(vW0, n1, wound, rim, core); zWound(vW1, n1, wound, rim, core); zWound(vW2, n1, wound, rim, core);
        float th = 1.0 - vTear.x * 0.52;
        float tear = smoothstep(0.0, 0.035, n2 - th);
        float fray = (1.0 - smoothstep(0.0, 0.05, th - n2)) * (1.0 - tear) * step(0.001, vTear.x);
        vec3 rotten = vec3(0.4, 0.43, 0.35) * (0.7 + 0.35 * n1);
        vec3 flesh = mix(vec3(0.33, 0.03, 0.03), vec3(0.62, 0.17, 0.13), n1);
        #ifdef Z_CLOTH
          diffuseColor.rgb = mix(diffuseColor.rgb, min(diffuseColor.rgb * 1.7 + 0.08, vec3(1.0)), fray * 0.55);
          diffuseColor.rgb = mix(diffuseColor.rgb, rotten, tear);
          diffuseColor.rgb = mix(diffuseColor.rgb, flesh * 0.8, tear * smoothstep(0.07, 0.14, n2 - th));
        #else
          diffuseColor.rgb = mix(diffuseColor.rgb, mix(flesh, vec3(0.22, 0.16, 0.18), 0.45), tear * 0.9);
          diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.7, 0.55, 0.62), fray * 0.6);
        #endif
        diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.5, 0.16, 0.15), rim * 0.85);
        diffuseColor.rgb = mix(diffuseColor.rgb, flesh, wound);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.05, 0.0, 0.0), core);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.035, 0.03, 0.025) * (0.5 + n1), clamp(vTear.z * (0.6 + 0.6 * n2), 0.0, 1.0));
        float zWet = max(wound, rim * 0.55);`,
      )
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\nroughnessFactor = mix(roughnessFactor, 0.18, zWet);');
  };
  return m;
}

export interface Palette {
  skin: THREE.Color;
  shirt: THREE.Color;
  sleeve: THREE.Color;
  pants: THREE.Color;
  shoes: THREE.Color;
  hair: THREE.Color;
  hairStyle: number;
}

const KINDS = ['head', 'neck', 'chest', 'abdomen', 'pelvis', 'upperArm', 'forearm', 'hand', 'thigh', 'shin', 'foot'];
const BLOOD = new THREE.Color(0.32, 0.02, 0.02);
const _c = new THREE.Color();

/**
 * All zombies share ~16 instanced meshes (one per body-part type) so a horde of
 * 100+ articulated bodies costs a handful of draw calls.
 */
export class ZombieRenderer {
  private meshes: Record<string, THREE.InstancedMesh> = {};
  private hair: THREE.InstancedMesh[] = [];
  private stumps: THREE.InstancedMesh;
  private segMesh: THREE.InstancedMesh[] = [];
  private segSub: number[] = [];
  private segPer: number[] = [];
  private base: THREE.Color[][] = [];
  readonly maxStumps: number;
  private stumpN = 0;
  private geos: Record<string, THREE.BufferGeometry> = {};
  private woundI: Uint8Array = new Uint8Array(0);

  constructor(scene: THREE.Scene, max: number) {
    const G = buildGeometries();
    this.geos = G;
    const mat = damageMaterial(true, 0.86);
    const skinMat = damageMaterial(false, 0.55);
    const hairMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, metalness: 0 });
    const plainMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.4, metalness: 0 });
    const count: Record<string, number> = {};
    for (const s of SEGS) count[s.kind] = (count[s.kind] ?? 0) + 1;
    for (const k of KINDS) {
      const im = new THREE.InstancedMesh(G[k], k === 'head' || k === 'hand' || k === 'neck' ? skinMat : mat, max * count[k]);
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      im.castShadow = true;
      im.receiveShadow = true;
      im.frustumCulled = false;
      im.count = max * count[k];
      for (let i = 0; i < im.count; i++) im.setColorAt(i, _c.setRGB(1, 1, 1));
      const n = im.count;
      for (const a of ['aW0', 'aW1', 'aW2', 'aTear']) {
        const at = new THREE.InstancedBufferAttribute(new Float32Array(n * 4), 4);
        at.setUsage(THREE.DynamicDrawUsage);
        G[k].setAttribute(a, at);
      }
      this.meshes[k] = im;
      scene.add(im);
    }
    for (let h = 0; h < 3; h++) {
      const im = new THREE.InstancedMesh(G['hair' + h], hairMat, max);
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      im.castShadow = true;
      im.frustumCulled = false;
      for (let i = 0; i < max; i++) im.setColorAt(i, _c.setRGB(1, 1, 1));
      this.hair.push(im);
      scene.add(im);
    }
    this.maxStumps = max * 4;
    this.stumps = new THREE.InstancedMesh(G.stump, plainMat, this.maxStumps);
    this.stumps.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.stumps.frustumCulled = false;
    this.stumps.castShadow = true;
    this.stumps.count = 0;
    scene.add(this.stumps);

    const seen: Record<string, number> = {};
    for (const s of SEGS) {
      const sub = seen[s.kind] ?? 0;
      seen[s.kind] = sub + 1;
      this.segMesh.push(this.meshes[s.kind]);
      this.segSub.push(sub);
      this.segPer.push(count[s.kind]);
    }
    for (let z = 0; z < max; z++) this.base.push(SEGS.map(() => new THREE.Color()));
    this.woundI = new Uint8Array(max * SEGS.length);
    for (const m of Object.values(this.meshes)) m.instanceMatrix.array.fill(0);
    for (const m of this.hair) m.instanceMatrix.array.fill(0);
  }


  private inst(slot: number, seg: number) {
    return slot * this.segPer[seg] + this.segSub[seg];
  }
  private attr(seg: number, name: string) {
    return this.segMesh[seg].geometry.getAttribute(name) as THREE.InstancedBufferAttribute;
  }

  /** Clear all wounds / tears of a slot (new zombie). */
  resetDamage(slot: number) {
    for (let i = 0; i < SEGS.length; i++) {
      const k = this.inst(slot, i);
      for (const a of ['aW0', 'aW1', 'aW2']) this.attr(i, a).setXYZW(k, 0, 0, 0, 0);
      this.attr(i, 'aTear').setXYZW(k, 0, Math.random() * 50, 0, 0);
      this.woundI[slot * SEGS.length + i] = 0;
    }
    this.flagDamage();
  }
  private flagDamage() {
    for (const m of Object.values(this.meshes)) for (const a of ['aW0', 'aW1', 'aW2', 'aTear']) (m.geometry.getAttribute(a) as THREE.BufferAttribute).needsUpdate = true;
  }

  /** Wound at a body-part local point (cycles through 3 slots per part). */
  woundLocal(slot: number, seg: number, x: number, y: number, z: number, strength: number) {
    const wi = slot * SEGS.length + seg;
    const w = this.woundI[wi] % 3;
    this.woundI[wi]++;
    const at = this.attr(seg, 'aW' + w);
    at.setXYZW(this.inst(slot, seg), x, y, z, Math.min(1.6, strength));
    at.needsUpdate = true;
  }

  /** Wound where a bullet struck in world space: converted into the part's local frame. */
  wound(slot: number, seg: number, p: THREE.Vector3, strength: number) {
    const arr = this.segMesh[seg].instanceMatrix.array as Float32Array;
    const o = this.inst(slot, seg) * 16;
    if (arr[o + 15] === 0) return;
    _m.fromArray(arr, o).invert();
    _v.copy(p).applyMatrix4(_m);
    this.woundLocal(slot, seg, _v.x, _v.y, _v.z, strength);
  }

  /** Rips through clothing (x), char (z). Values only grow. */
  tear(slot: number, seg: number, amount: number, burn = 0) {
    const at = this.attr(seg, 'aTear');
    const k = this.inst(slot, seg);
    at.setX(k, Math.min(1, Math.max(at.getX(k), amount)));
    at.setZ(k, Math.min(1, Math.max(at.getZ(k), burn)));
    at.needsUpdate = true;
  }
  tearOf(slot: number, seg: number) {
    return this.attr(seg, 'aTear').getX(this.inst(slot, seg));
  }

  /** A random point on the surface of a body part (for pre-existing damage). */
  surfacePoint(seg: number, out: THREE.Vector3) {
    const p = this.geos[SEGS[seg].kind].attributes.position;
    const i = (Math.random() * p.count) | 0;
    return out.set(p.getX(i), p.getY(i), p.getZ(i));
  }

  setPalette(slot: number, p: Palette) {
    SEGS.forEach((s, i) => {
      const c =
        s.kind === 'head' || s.kind === 'neck' || s.kind === 'hand'
          ? p.skin
          : s.kind === 'chest' || s.kind === 'abdomen' || s.kind === 'upperArm'
            ? p.shirt
            : s.kind === 'forearm'
              ? p.sleeve
              : s.kind === 'foot'
                ? p.shoes
                : p.pants;
      this.base[slot][i].copy(c);
      this.segMesh[i].setColorAt(slot * this.segPer[i] + this.segSub[i], c);
    });
    for (let h = 0; h < 3; h++) this.hair[h].setColorAt(slot, p.hair);
    for (const m of Object.values(this.meshes)) if (m.instanceColor) m.instanceColor.needsUpdate = true;
    for (const m of this.hair) if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }

  /** Blood soaks into a body part as it takes damage. */
  tint(slot: number, seg: number, amount: number) {
    _c.copy(this.base[slot][seg]).lerp(BLOOD, Math.min(0.45, amount * 0.6));
    const m = this.segMesh[seg];
    m.setColorAt(slot * this.segPer[seg] + this.segSub[seg], _c);
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }

  private static write(arr: ArrayLike<number> & { [i: number]: number }, o: number, X: number[], Y: number[], Z: number[], a: number[], s: number) {
    arr[o] = X[0] * s;
    arr[o + 1] = X[1] * s;
    arr[o + 2] = X[2] * s;
    arr[o + 3] = 0;
    arr[o + 4] = Y[0] * s;
    arr[o + 5] = Y[1] * s;
    arr[o + 6] = Y[2] * s;
    arr[o + 7] = 0;
    arr[o + 8] = Z[0] * s;
    arr[o + 9] = Z[1] * s;
    arr[o + 10] = Z[2] * s;
    arr[o + 11] = 0;
    arr[o + 12] = a[0];
    arr[o + 13] = a[1];
    arr[o + 14] = a[2];
    arr[o + 15] = 1;
  }

  /** Orient every segment from its two particles + a lateral reference. */
  write(slot: number, pts: Float32Array, s: number, hidden: number, hairStyle: number) {
    const sx = pts[P.LSH * 3] - pts[P.RSH * 3];
    const sy = pts[P.LSH * 3 + 1] - pts[P.RSH * 3 + 1];
    const sz = pts[P.LSH * 3 + 2] - pts[P.RSH * 3 + 2];
    const hx = pts[P.LHIP * 3] - pts[P.RHIP * 3];
    const hy = pts[P.LHIP * 3 + 1] - pts[P.RHIP * 3 + 1];
    const hz = pts[P.LHIP * 3 + 2] - pts[P.RHIP * 3 + 2];
    for (let i = 0; i < SEGS.length; i++) {
      const sg = SEGS[i];
      const m = this.segMesh[i];
      const arr = m.instanceMatrix.array as Float32Array;
      const o = (slot * this.segPer[i] + this.segSub[i]) * 16;
      if (hidden & (1 << i)) {
        for (let k = 0; k < 16; k++) arr[o + k] = 0;
        continue;
      }
      const a = sg.a * 3;
      const b = sg.b * 3;
      _A[0] = pts[a];
      _A[1] = pts[a + 1];
      _A[2] = pts[a + 2];
      let yx = pts[b] - pts[a];
      let yy = pts[b + 1] - pts[a + 1];
      let yz = pts[b + 2] - pts[a + 2];
      const yl = Math.hypot(yx, yy, yz) || 1e-5;
      yx /= yl;
      yy /= yl;
      yz /= yl;
      let rx = sg.ref === 'sh' ? sx : hx;
      let ry = sg.ref === 'sh' ? sy : hy;
      let rz = sg.ref === 'sh' ? sz : hz;
      let d = rx * yx + ry * yy + rz * yz;
      rx -= yx * d;
      ry -= yy * d;
      rz -= yz * d;
      let rl = Math.hypot(rx, ry, rz);
      if (rl < 1e-3) {
        // limb parallel to the shoulder line: fall back to the other reference
        rx = sg.ref === 'sh' ? hx : sx;
        ry = sg.ref === 'sh' ? hy : sy;
        rz = sg.ref === 'sh' ? hz : sz;
        d = rx * yx + ry * yy + rz * yz;
        rx -= yx * d;
        ry -= yy * d;
        rz -= yz * d;
        rl = Math.hypot(rx, ry, rz) || 1;
      }
      _X[0] = rx / rl;
      _X[1] = ry / rl;
      _X[2] = rz / rl;
      _Y[0] = yx;
      _Y[1] = yy;
      _Y[2] = yz;
      _Z[0] = _X[1] * yz - _X[2] * yy;
      _Z[1] = _X[2] * yx - _X[0] * yz;
      _Z[2] = _X[0] * yy - _X[1] * yx;
      ZombieRenderer.write(arr, o, _X, _Y, _Z, _A, s);
      if (i === 0) {
        for (let h = 0; h < 3; h++) {
          const ha = this.hair[h].instanceMatrix.array as Float32Array;
          if (h === hairStyle) ZombieRenderer.write(ha, slot * 16, _X, _Y, _Z, _A, s);
          else for (let k = 0; k < 16; k++) ha[slot * 16 + k] = 0;
        }
      }
    }
    if (hidden & 1) {
      for (let h = 0; h < 3; h++) {
        const ha = this.hair[h].instanceMatrix.array as Float32Array;
        for (let k = 0; k < 16; k++) ha[slot * 16 + k] = 0;
      }
    }
  }

  hide(slot: number) {
    for (let i = 0; i < SEGS.length; i++) {
      const arr = this.segMesh[i].instanceMatrix.array as Float32Array;
      const o = (slot * this.segPer[i] + this.segSub[i]) * 16;
      for (let k = 0; k < 16; k++) arr[o + k] = 0;
    }
    for (let h = 0; h < 3; h++) {
      const ha = this.hair[h].instanceMatrix.array as Float32Array;
      for (let k = 0; k < 16; k++) ha[slot * 16 + k] = 0;
    }
  }

  beginStumps() {
    this.stumpN = 0;
  }
  /** Raw wound cap at particle `at`, facing away from particle `from`. */
  stump(pts: Float32Array, at: number, from: number, r: number) {
    if (this.stumpN >= this.maxStumps) return;
    const ax = pts[at * 3];
    const ay = pts[at * 3 + 1];
    const az = pts[at * 3 + 2];
    _v.set(ax - pts[from * 3], ay - pts[from * 3 + 1], az - pts[from * 3 + 2]);
    if (_v.lengthSq() < 1e-8) _v.set(0, 1, 0);
    _v.normalize();
    _q.setFromUnitVectors(_up, _v);
    _m.compose(_p.set(ax, ay, az), _q, _s.set(r, r, r));
    this.stumps.setMatrixAt(this.stumpN++, _m);
  }

  commit() {
    for (const m of Object.values(this.meshes)) m.instanceMatrix.needsUpdate = true;
    for (const m of this.hair) m.instanceMatrix.needsUpdate = true;
    this.stumps.count = this.stumpN;
    this.stumps.instanceMatrix.needsUpdate = true;
  }
}

const _X = [0, 0, 0];
const _Y = [0, 0, 0];
const _Z = [0, 0, 0];
const _A = [0, 0, 0];
const _v = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
void NP;
