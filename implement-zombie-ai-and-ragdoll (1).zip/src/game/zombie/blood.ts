import * as THREE from 'three';
import type { Terrain } from '../terrain';

/* ---------------------------------------------------------------------------
 * LIQUID BLOOD
 *  • droplets are glossy instanced teardrops stretched along their velocity
 *    (fast spray reads as streaks/threads, slow drops as fat beads)
 *  • every landing droplet leaves a splat elongated in its flight direction
 *  • soft, noisy mist (no round sprites) and spreading wet pools
 *  • gore chunks, scorch marks and a "lens" value for blood on the camera
 * All pooled / instanced: no per-shot allocations.
 * ------------------------------------------------------------------------- */
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const _d = new THREE.Vector3();
const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _p = new THREE.Vector3();
const _e = new THREE.Euler();
const _c = new THREE.Color();
const FWD = new THREE.Vector3(0, 0, 1);

function cone(dir: THREE.Vector3, spread: number, out: THREE.Vector3) {
  _a.set(1, 0, 0);
  if (Math.abs(dir.x) > 0.8) _a.set(0, 1, 0);
  _a.cross(dir).normalize();
  _b.crossVectors(dir, _a);
  const ang = Math.random() * Math.PI * 2;
  const r = Math.tan(spread) * Math.sqrt(Math.random());
  return out.copy(dir).addScaledVector(_a, Math.cos(ang) * r).addScaledVector(_b, Math.sin(ang) * r).normalize();
}

/** White-on-transparent splat masks (tinted per instance). */
function splatTexture(kind: 'spot' | 'streak' | 'pool', seed: number): THREE.Texture {
  const s = 128;
  const cv = document.createElement('canvas');
  cv.width = cv.height = s;
  const g = cv.getContext('2d')!;
  let k = seed * 9301 + 49297;
  const r = () => {
    k = (k * 9301 + 49297) % 233280;
    return k / 233280;
  };
  const blob = (x: number, y: number, rx: number, ry: number, a: number) => {
    g.save();
    g.translate(x, y);
    g.scale(1, ry / rx);
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, rx);
    gr.addColorStop(0, `rgba(255,255,255,${a})`);
    gr.addColorStop(0.82, `rgba(235,235,235,${a})`);
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.beginPath();
    g.arc(0, 0, rx, 0, Math.PI * 2);
    g.fill();
    g.restore();
  };
  if (kind === 'pool') {
    for (let i = 0; i < 14; i++) blob(64 + (r() - 0.5) * 40, 64 + (r() - 0.5) * 40, 16 + r() * 22, 16 + r() * 22, 1);
  } else if (kind === 'streak') {
    // teardrop: fat head at the impact, thinning tail along +Y (flight direction)
    blob(64, 40, 18, 16, 1);
    for (let t = 0; t < 1; t += 0.04) blob(64 + Math.sin(t * 9) * 2, 40 + t * 80, 15 * (1 - t) + 2, 15 * (1 - t) + 2, 0.95);
    for (let i = 0; i < 10; i++) blob(64 + (r() - 0.5) * 44, 30 + r() * 90, 1.5 + r() * 3, 1.5 + r() * 3, 0.9);
  } else {
    for (let i = 0; i < 7; i++) blob(64 + (r() - 0.5) * 28, 64 + (r() - 0.5) * 28, 10 + r() * 16, 10 + r() * 16, 1);
    for (let i = 0; i < 12; i++) {
      const a = r() * Math.PI * 2;
      const d0 = 18 + r() * 10;
      const d1 = d0 + 8 + r() * 28;
      for (let t = 0; t < 1; t += 0.1) {
        const d = d0 + (d1 - d0) * t;
        blob(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, (1 - t) * 4.5 + 1.2, (1 - t) * 4.5 + 1.2, 0.95);
      }
    }
    for (let i = 0; i < 24; i++) {
      const a = r() * Math.PI * 2;
      const d = 30 + r() * 30;
      blob(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, 1.2 + r() * 3, 1.2 + r() * 3, 0.9);
    }
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function cloudTexture(): THREE.Texture {
  const s = 64;
  const cv = document.createElement('canvas');
  cv.width = cv.height = s;
  const g = cv.getContext('2d')!;
  for (let i = 0; i < 26; i++) {
    const x = 32 + (Math.random() - 0.5) * 30;
    const y = 32 + (Math.random() - 0.5) * 30;
    const r = 6 + Math.random() * 12;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, 'rgba(255,255,255,0.22)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, s, s);
  }
  return new THREE.CanvasTexture(cv);
}

interface Pool {
  x: number;
  z: number;
  y: number;
  idx: number;
  s: number;
  target: number;
  rate: number;
  rot: number;
}

export class Blood {
  private terrain: Terrain;
  /** blood on the camera lens (0..1), read by the HUD */
  lens = 0;
  camPos = new THREE.Vector3();
  // droplets
  private readonly ND = 3200;
  private dP: Float32Array;
  private dV: Float32Array;
  private dLife: Float32Array;
  private dSize: Float32Array;
  private dShade: Float32Array;
  private dI = 0;
  private drops: THREE.InstancedMesh;
  // mist
  private readonly NM = 420;
  private mPos: Float32Array;
  private mVel: Float32Array;
  private mLife: Float32Array;
  private mLife0: Float32Array;
  private mSize: Float32Array;
  private mSize0: Float32Array;
  private mAlpha: Float32Array;
  private mA0: Float32Array;
  private mCol: Float32Array;
  private mI = 0;
  private mist: THREE.Points;
  private mMat: THREE.ShaderMaterial;
  // decals
  private spots: THREE.InstancedMesh;
  private streaks: THREE.InstancedMesh;
  private poolMesh: THREE.InstancedMesh;
  private readonly NSPOT = 900;
  private readonly NPOOL = 90;
  private spotI = 0;
  private streakI = 0;
  private poolI = 0;
  private pools: Pool[] = [];
  private decalBudget = 0;
  // gore
  private readonly NG = 320;
  private gore: THREE.InstancedMesh;
  private gPos: Float32Array;
  private gVel: Float32Array;
  private gRot: Float32Array;
  private gSpin: Float32Array;
  private gScale: Float32Array;
  private gLife: Float32Array;
  private gRest: Uint8Array;
  private gI = 0;
  private gDirty = false;
  private frame = 0;

  constructor(scene: THREE.Scene, terrain: Terrain) {
    this.terrain = terrain;
    // ---------------------------------------------------------------- droplets
    this.dP = new Float32Array(this.ND * 3);
    this.dV = new Float32Array(this.ND * 3);
    this.dLife = new Float32Array(this.ND);
    this.dSize = new Float32Array(this.ND);
    this.dShade = new Float32Array(this.ND);
    const tear = new THREE.SphereGeometry(1, 8, 6);
    {
      // teardrop: round head at +Z, tapered tail toward -Z
      const p = tear.attributes.position;
      for (let i = 0; i < p.count; i++) {
        let x = p.getX(i);
        let y = p.getY(i);
        const z0 = p.getY(i); // sphere poles are on Y: remap Y -> Z
        const zz = z0;
        y = p.getZ(i);
        const taper = zz < 0 ? 1 + zz * 0.75 : 1;
        x *= taper;
        y *= taper;
        p.setXYZ(i, x, y, zz < 0 ? zz * 1.6 : zz);
      }
      tear.computeVertexNormals();
    }
    this.drops = new THREE.InstancedMesh(
      tear,
      new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.12, metalness: 0.15, emissive: '#1a0000', emissiveIntensity: 0.5 }),
      this.ND,
    );
    this.drops.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.drops.setColorAt(0, _c.setRGB(0.4, 0.02, 0.02));
    this.drops.count = 0;
    this.drops.frustumCulled = false;
    this.drops.castShadow = false;
    scene.add(this.drops);

    // -------------------------------------------------------------------- mist
    this.mPos = new Float32Array(this.NM * 3).fill(-9999);
    this.mVel = new Float32Array(this.NM * 3);
    this.mLife = new Float32Array(this.NM);
    this.mLife0 = new Float32Array(this.NM).fill(1);
    this.mSize = new Float32Array(this.NM);
    this.mSize0 = new Float32Array(this.NM);
    this.mAlpha = new Float32Array(this.NM);
    this.mA0 = new Float32Array(this.NM);
    this.mCol = new Float32Array(this.NM * 3);
    const mg = new THREE.BufferGeometry();
    mg.setAttribute('position', new THREE.BufferAttribute(this.mPos, 3).setUsage(THREE.DynamicDrawUsage));
    mg.setAttribute('aSize', new THREE.BufferAttribute(this.mSize, 1).setUsage(THREE.DynamicDrawUsage));
    mg.setAttribute('aAlpha', new THREE.BufferAttribute(this.mAlpha, 1).setUsage(THREE.DynamicDrawUsage));
    mg.setAttribute('color', new THREE.BufferAttribute(this.mCol, 3).setUsage(THREE.DynamicDrawUsage));
    this.mMat = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 600 }, map: { value: cloudTexture() } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aSize; attribute float aAlpha; attribute vec3 color; uniform float uScale;
        varying float vA; varying vec3 vC; varying float vR;
        void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); gl_Position = projectionMatrix*mv;
          gl_PointSize = aSize*uScale/max(0.05,-mv.z); vA=aAlpha; vC=color; vR = fract(position.x*13.7+position.z*7.1)*6.283; }`,
      fragmentShader: `uniform sampler2D map; varying float vA; varying vec3 vC; varying float vR;
        void main(){ vec2 c = gl_PointCoord-0.5; float s=sin(vR), co=cos(vR); c = vec2(c.x*co-c.y*s, c.x*s+c.y*co)+0.5;
          float a = texture2D(map, c).a; gl_FragColor = vec4(vC, a*vA*2.2); }`,
    });
    this.mist = new THREE.Points(mg, this.mMat);
    this.mist.frustumCulled = false;
    this.mist.renderOrder = 4;
    scene.add(this.mist);

    // ------------------------------------------------------------------ decals
    const pg = new THREE.PlaneGeometry(1, 1);
    pg.rotateX(-Math.PI / 2);
    const decalMat = (map: THREE.Texture) =>
      new THREE.MeshStandardMaterial({
        map,
        color: '#ffffff',
        transparent: true,
        depthWrite: false,
        roughness: 0.22,
        metalness: 0.1,
        polygonOffset: true,
        polygonOffsetFactor: -3,
        polygonOffsetUnits: -3,
      });
    const mk = (map: THREE.Texture, n: number) => {
      const im = new THREE.InstancedMesh(pg, decalMat(map), n);
      _m.makeScale(0, 0, 0);
      for (let i = 0; i < n; i++) {
        im.setMatrixAt(i, _m);
        im.setColorAt(i, _c.setRGB(0.3, 0.02, 0.02));
      }
      im.frustumCulled = false;
      im.receiveShadow = true;
      im.renderOrder = 1;
      scene.add(im);
      return im;
    };
    this.spots = mk(splatTexture('spot', 7), this.NSPOT);
    this.streaks = mk(splatTexture('streak', 3), this.NSPOT);
    this.poolMesh = mk(splatTexture('pool', 11), this.NPOOL);

    // -------------------------------------------------------------------- gore
    this.gPos = new Float32Array(this.NG * 3);
    this.gVel = new Float32Array(this.NG * 3);
    this.gRot = new Float32Array(this.NG * 3);
    this.gSpin = new Float32Array(this.NG * 3);
    this.gScale = new Float32Array(this.NG);
    this.gLife = new Float32Array(this.NG);
    this.gRest = new Uint8Array(this.NG);
    const gg = new THREE.IcosahedronGeometry(1, 1);
    {
      const p = gg.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const k = 0.75 + 0.35 * Math.sin(p.getX(i) * 7 + p.getY(i) * 5) * Math.cos(p.getZ(i) * 6);
        p.setXYZ(i, p.getX(i) * k, p.getY(i) * k * 0.7, p.getZ(i) * k * 0.85);
      }
      gg.computeVertexNormals();
    }
    this.gore = new THREE.InstancedMesh(gg, new THREE.MeshStandardMaterial({ roughness: 0.3, metalness: 0.05 }), this.NG);
    _m.makeScale(0, 0, 0);
    for (let i = 0; i < this.NG; i++) {
      this.gore.setMatrixAt(i, _m);
      this.gore.setColorAt(i, _c.setRGB(0.4, 0.02, 0.02));
    }
    this.gore.frustumCulled = false;
    this.gore.castShadow = true;
    scene.add(this.gore);
  }

  // ------------------------------------------------------------------ emit
  private lensHit(o: THREE.Vector3, amount: number) {
    const d = o.distanceTo(this.camPos);
    if (d < 3.2) this.lens = Math.min(1, this.lens + amount * (1 - d / 3.2));
  }

  /** Cone of liquid droplets. */
  spray(o: THREE.Vector3, dir: THREE.Vector3, n: number, speed: number, spread: number, size = 1) {
    for (let k = 0; k < n; k++) {
      const i = this.dI;
      this.dI = (this.dI + 1) % this.ND;
      cone(dir, spread, _d);
      const v = speed * rnd(0.35, 1.15);
      const j = i * 3;
      this.dP[j] = o.x + rnd(-0.015, 0.015);
      this.dP[j + 1] = o.y + rnd(-0.015, 0.015);
      this.dP[j + 2] = o.z + rnd(-0.015, 0.015);
      this.dV[j] = _d.x * v;
      this.dV[j + 1] = _d.y * v;
      this.dV[j + 2] = _d.z * v;
      this.dLife[i] = rnd(1.4, 2.6);
      this.dSize[i] = size * rnd(0.006, 0.017) * (Math.random() < 0.1 ? 2 : 1);
      this.dShade[i] = rnd(0.55, 1);
    }
  }

  /** A coherent jet (arterial spurt / pouring stump): many small drops in a tight thread. */
  stream(o: THREE.Vector3, dir: THREE.Vector3, n: number, speed: number) {
    for (let k = 0; k < n; k++) {
      const i = this.dI;
      this.dI = (this.dI + 1) % this.ND;
      cone(dir, 0.07, _d);
      const v = speed * rnd(0.85, 1.05);
      const j = i * 3;
      const back = rnd(0, 0.03);
      this.dP[j] = o.x - _d.x * back;
      this.dP[j + 1] = o.y - _d.y * back;
      this.dP[j + 2] = o.z - _d.z * back;
      this.dV[j] = _d.x * v;
      this.dV[j + 1] = _d.y * v;
      this.dV[j + 2] = _d.z * v;
      this.dLife[i] = rnd(1.2, 2);
      this.dSize[i] = rnd(0.007, 0.012);
      this.dShade[i] = rnd(0.5, 0.75);
    }
  }

  puffs(o: THREE.Vector3, n: number, size: number, r = 0.35, g = 0.02, b = 0.02, alpha = 0.55, life = 0.6, vel?: THREE.Vector3) {
    for (let k = 0; k < n; k++) {
      const i = this.mI;
      this.mI = (this.mI + 1) % this.NM;
      this.mPos[i * 3] = o.x + rnd(-0.05, 0.05);
      this.mPos[i * 3 + 1] = o.y + rnd(-0.05, 0.05);
      this.mPos[i * 3 + 2] = o.z + rnd(-0.05, 0.05);
      this.mVel[i * 3] = (vel ? vel.x : 0) + rnd(-0.4, 0.4);
      this.mVel[i * 3 + 1] = (vel ? vel.y : 0) + rnd(-0.1, 0.5);
      this.mVel[i * 3 + 2] = (vel ? vel.z : 0) + rnd(-0.4, 0.4);
      this.mLife[i] = this.mLife0[i] = life * rnd(0.7, 1.3);
      this.mSize0[i] = size * rnd(0.6, 1.3);
      this.mSize[i] = this.mSize0[i];
      this.mA0[i] = alpha * rnd(0.6, 1);
      this.mAlpha[i] = this.mA0[i];
      this.mCol[i * 3] = r;
      this.mCol[i * 3 + 1] = g;
      this.mCol[i * 3 + 2] = b;
    }
  }

  /** Splat on the ground. Elongated along (vx,vz) when the drop was moving fast. */
  decal(x: number, z: number, size: number, grow = 0, y?: number, vx = 0, vz = 0, shade = 1) {
    if (grow > 0) {
      const idx = this.poolI;
      this.poolI = (this.poolI + 1) % this.NPOOL;
      this.pools = this.pools.filter((p) => p.idx !== idx);
      const gy = (y ?? this.terrain.height(x, z)) + 0.011;
      this.pools.push({ x, z, y: gy, idx, s: size * 0.12, target: size, rate: grow, rot: Math.random() * 6.28 });
      this.poolMesh.setColorAt(idx, _c.setRGB(0.24 * shade, 0.012, 0.014));
      if (this.poolMesh.instanceColor) this.poolMesh.instanceColor.needsUpdate = true;
      return;
    }
    if (this.decalBudget <= 0) return;
    this.decalBudget--;
    const hs = Math.hypot(vx, vz);
    const streak = hs > 1.6;
    const im = streak ? this.streaks : this.spots;
    const idx = streak ? this.streakI : this.spotI;
    if (streak) this.streakI = (idx + 1) % this.NSPOT;
    else this.spotI = (idx + 1) % this.NSPOT;
    const gy = (y ?? this.terrain.height(x, z)) + 0.013 + Math.random() * 0.004;
    const rot = streak ? Math.atan2(vx, vz) + Math.PI : Math.random() * Math.PI * 2;
    _q.setFromAxisAngle(THREE.Object3D.DEFAULT_UP, rot);
    const len = streak ? 1 + Math.min(3, hs * 0.35) : rnd(0.85, 1.15);
    _m.compose(_p.set(x, gy, z), _q, _s.set(size * (streak ? 0.6 : 1), 1, size * len));
    im.setMatrixAt(idx, _m);
    const d = rnd(0.7, 1) * shade;
    im.setColorAt(idx, _c.setRGB(0.36 * d, 0.015 * d, 0.02 * d));
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }

  /** Charred blast mark. */
  scorch(x: number, z: number, size: number) {
    const idx = this.poolI;
    this.poolI = (this.poolI + 1) % this.NPOOL;
    this.pools = this.pools.filter((p) => p.idx !== idx);
    const gy = this.terrain.height(x, z) + 0.009;
    _q.setFromAxisAngle(THREE.Object3D.DEFAULT_UP, Math.random() * 6.28);
    _m.compose(_p.set(x, gy, z), _q, _s.set(size, 1, size));
    this.poolMesh.setMatrixAt(idx, _m);
    this.poolMesh.setColorAt(idx, _c.setRGB(0.03, 0.028, 0.026));
    this.poolMesh.instanceMatrix.needsUpdate = true;
    if (this.poolMesh.instanceColor) this.poolMesh.instanceColor.needsUpdate = true;
  }

  chunks(o: THREE.Vector3, dir: THREE.Vector3, n: number, speed: number, bone = 0.2, burnt = false) {
    for (let k = 0; k < n; k++) {
      const i = this.gI;
      this.gI = (this.gI + 1) % this.NG;
      cone(dir, 0.9, _d);
      const v = speed * rnd(0.3, 1.1);
      this.gPos.set([o.x, o.y, o.z], i * 3);
      this.gVel.set([_d.x * v, _d.y * v + rnd(0.5, 2.5), _d.z * v], i * 3);
      this.gRot.set([rnd(0, 6), rnd(0, 6), rnd(0, 6)], i * 3);
      this.gSpin.set([rnd(-14, 14), rnd(-14, 14), rnd(-14, 14)], i * 3);
      this.gScale[i] = rnd(0.015, 0.05);
      this.gLife[i] = 40;
      this.gRest[i] = 0;
      if (Math.random() < bone) this.gore.setColorAt(i, _c.setRGB(0.85, 0.8, 0.68));
      else if (burnt) this.gore.setColorAt(i, _c.setRGB(rnd(0.05, 0.15), 0.03, 0.02));
      else this.gore.setColorAt(i, _c.setRGB(rnd(0.3, 0.55), rnd(0.01, 0.05), rnd(0.02, 0.05)));
    }
    if (this.gore.instanceColor) this.gore.instanceColor.needsUpdate = true;
    this.gDirty = true;
  }

  /** Bullet wound: back-spatter at the entry, liquid cone out of the exit, heavy drips. */
  impact(p: THREE.Vector3, dir: THREE.Vector3, power: number, head = false) {
    this.decalBudget = Math.min(this.decalBudget + 10 + power * 8, 50);
    const back = _p.copy(dir).negate();
    this.spray(p, back, 8 + power * 5, 1.8 + power * 0.6, 0.55, 0.9);
    this.spray(p, dir, (head ? 40 : 22) + power * 18, 3 + power * 1.8, head ? 0.45 : 0.32, 1.15);
    this.stream(p, dir, 6 + power * 3, 2.5 + power);
    _d.copy(dir).multiplyScalar(0.6 + power * 0.4);
    this.puffs(p, 2 + power, head ? 0.3 : 0.2, 0.32, 0.015, 0.015, 0.5, 0.55, _d);
    _a.set(0, -1, 0);
    this.spray(p, _a, 5, 0.5, 0.25, 1.5);
    this.lensHit(p, 0.25 * power);
  }

  explode(p: THREE.Vector3, dir: THREE.Vector3) {
    this.decalBudget = 70;
    _a.copy(dir).multiplyScalar(0.6).add(_b.set(0, 0.6, 0)).normalize();
    this.spray(p, _a, 220, 5, 1.1, 1.3);
    this.spray(p, dir, 110, 7, 0.45, 1.2);
    this.puffs(p, 10, 0.5, 0.3, 0.015, 0.015, 0.6, 0.9, _a.multiplyScalar(1.2));
    this.chunks(p, dir, 26, 4.5, 0.35);
    this.lensHit(p, 0.9);
  }

  sever(p: THREE.Vector3, dir: THREE.Vector3) {
    this.decalBudget = Math.min(this.decalBudget + 30, 70);
    this.spray(p, dir, 80, 3.5, 0.8, 1.2);
    this.stream(p, dir, 20, 3);
    this.puffs(p, 5, 0.32, 0.32, 0.02, 0.02, 0.55, 0.7);
    this.chunks(p, dir, 9, 3, 0.3);
    this.lensHit(p, 0.5);
  }

  snow(p: THREE.Vector3, n: number) {
    this.puffs(p, n, 0.5, 0.92, 0.94, 0.97, 0.45, 0.9);
  }

  // ---------------------------------------------------------------- update
  update(dt: number, cam: THREE.PerspectiveCamera, viewH: number) {
    const scale = viewH / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov) / 2));
    this.mMat.uniforms.uScale.value = scale;
    const T = this.terrain;
    this.lens = Math.max(0, this.lens - dt * 0.35);

    // ---- droplets (compacted into the first `n` instances)
    const P = this.dP;
    const V = this.dV;
    const drag = Math.exp(-0.9 * dt);
    const arr = this.drops.instanceMatrix.array as Float32Array;
    const col = this.drops.instanceColor!.array as Float32Array;
    let n = 0;
    for (let i = 0; i < this.ND; i++) {
      if (this.dLife[i] <= 0) continue;
      this.dLife[i] -= dt;
      const j = i * 3;
      V[j] *= drag;
      V[j + 2] *= drag;
      V[j + 1] = V[j + 1] * drag - 9.8 * dt;
      P[j] += V[j] * dt;
      P[j + 1] += V[j + 1] * dt;
      P[j + 2] += V[j + 2] * dt;
      if (this.dLife[i] <= 0) continue;
      if (V[j + 1] < 0 && (i & 1) === (this.frame & 1)) {
        const gh = T.height(P[j], P[j + 2]);
        if (P[j + 1] <= gh + 0.01) {
          if (Math.random() < 0.38) this.decal(P[j], P[j + 2], this.dSize[i] * rnd(9, 18), 0, gh, V[j], V[j + 2], this.dShade[i]);
          this.dLife[i] = 0;
          continue;
        }
      }
      // stretch along velocity: fast spray becomes threads
      const sp = Math.hypot(V[j], V[j + 1], V[j + 2]);
      _d.set(V[j], V[j + 1], V[j + 2]).multiplyScalar(1 / (sp || 1));
      _q.setFromUnitVectors(FWD, _d);
      const r = this.dSize[i];
      const st = 1 + Math.min(7, sp * 0.9);
      _m.compose(_p.set(P[j], P[j + 1], P[j + 2]), _q, _s.set(r / Math.sqrt(st * 0.5 + 0.5), r / Math.sqrt(st * 0.5 + 0.5), r * st));
      _m.toArray(arr, n * 16);
      const sh = this.dShade[i];
      col[n * 3] = 0.42 * sh;
      col[n * 3 + 1] = 0.012 * sh;
      col[n * 3 + 2] = 0.018 * sh;
      n++;
    }
    this.frame++;
    this.drops.count = n;
    this.drops.instanceMatrix.needsUpdate = true;
    this.drops.instanceColor!.needsUpdate = true;

    // ---- mist
    const MP = this.mPos;
    const MV = this.mVel;
    for (let i = 0; i < this.NM; i++) {
      if (this.mLife[i] <= 0) continue;
      this.mLife[i] -= dt;
      const j = i * 3;
      if (this.mLife[i] <= 0) {
        MP[j + 1] = -9999;
        this.mAlpha[i] = 0;
        continue;
      }
      const k = 1 - this.mLife[i] / this.mLife0[i];
      MV[j] *= Math.exp(-3 * dt);
      MV[j + 1] = MV[j + 1] * Math.exp(-3 * dt) - 0.25 * dt;
      MV[j + 2] *= Math.exp(-3 * dt);
      MP[j] += MV[j] * dt;
      MP[j + 1] += MV[j + 1] * dt;
      MP[j + 2] += MV[j + 2] * dt;
      this.mSize[i] = this.mSize0[i] * (1 + k * 2);
      this.mAlpha[i] = this.mA0[i] * (1 - k) * (1 - k);
    }
    const mg = this.mist.geometry;
    mg.attributes.position.needsUpdate = true;
    mg.attributes.aSize.needsUpdate = true;
    mg.attributes.aAlpha.needsUpdate = true;
    mg.attributes.color.needsUpdate = true;

    // ---- spreading pools
    for (let i = this.pools.length - 1; i >= 0; i--) {
      const p = this.pools[i];
      p.s = Math.min(p.target, p.s + p.rate * dt * (1 - p.s / (p.target * 1.05)));
      _q.setFromAxisAngle(THREE.Object3D.DEFAULT_UP, p.rot);
      _m.compose(_p.set(p.x, p.y, p.z), _q, _s.set(p.s, 1, p.s * 0.85));
      this.poolMesh.setMatrixAt(p.idx, _m);
      this.poolMesh.instanceMatrix.needsUpdate = true;
      if (p.s >= p.target * 0.98) this.pools.splice(i, 1);
    }

    // ---- gore chunks
    let any = this.gDirty;
    this.gDirty = false;
    for (let i = 0; i < this.NG; i++) {
      if (this.gLife[i] <= 0 || this.gRest[i]) continue;
      any = true;
      const j = i * 3;
      const GP = this.gPos;
      const GV = this.gVel;
      GV[j + 1] -= 9.8 * dt;
      GP[j] += GV[j] * dt;
      GP[j + 1] += GV[j + 1] * dt;
      GP[j + 2] += GV[j + 2] * dt;
      this.gRot[j] += this.gSpin[j] * dt;
      this.gRot[j + 1] += this.gSpin[j + 1] * dt;
      this.gRot[j + 2] += this.gSpin[j + 2] * dt;
      const gh = T.height(GP[j], GP[j + 2]) + this.gScale[i] * 0.6;
      if (GP[j + 1] < gh) {
        GP[j + 1] = gh;
        if (GV[j + 1] < -1.5 && Math.random() < 0.6) this.decal(GP[j], GP[j + 2], rnd(0.08, 0.2), 0, undefined, GV[j], GV[j + 2]);
        GV[j + 1] *= -0.25;
        GV[j] *= 0.55;
        GV[j + 2] *= 0.55;
        this.gSpin[j] *= 0.5;
        this.gSpin[j + 1] *= 0.5;
        this.gSpin[j + 2] *= 0.5;
        if (Math.abs(GV[j + 1]) < 0.4 && Math.hypot(GV[j], GV[j + 2]) < 0.2) this.gRest[i] = 1;
      }
      _q.setFromEuler(_e.set(this.gRot[j], this.gRot[j + 1], this.gRot[j + 2]));
      const sc = this.gScale[i];
      _m.compose(_p.set(GP[j], GP[j + 1], GP[j + 2]), _q, _s.set(sc, sc, sc));
      this.gore.setMatrixAt(i, _m);
    }
    if (any) this.gore.instanceMatrix.needsUpdate = true;
    this.decalBudget = Math.min(this.decalBudget + dt * 24, 50);
  }
}
