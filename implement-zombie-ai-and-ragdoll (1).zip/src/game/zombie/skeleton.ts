import * as THREE from 'three';

/* ---------------------------------------------------------------------------
 * ZOMBIE PHYSICS SKELETON
 * 30 particles. Joints that can be torn apart (neck, shoulders, elbows, hips,
 * knees) are made of TWO coincident particles held by a zero-length joint
 * constraint, so a limb can separate cleanly with its own segment intact.
 * ------------------------------------------------------------------------- */
export const P = {
  HEAD: 0,
  NECK: 1,
  CHEST: 2,
  SPINE: 3,
  PELVIS: 4,
  LSH: 5,
  LEL: 6,
  LWR: 7,
  LHA: 8,
  RSH: 9,
  REL: 10,
  RWR: 11,
  RHA: 12,
  LHIP: 13,
  LKN: 14,
  LAN: 15,
  LTO: 16,
  RHIP: 17,
  RKN: 18,
  RAN: 19,
  RTO: 20,
  NECK2: 21,
  LEL2: 22,
  REL2: 23,
  LKN2: 24,
  RKN2: 25,
  LHIP2: 26,
  RHIP2: 27,
  LSH2: 28,
  RSH2: 29,
} as const;
export const NP = 30;

/** Body proportions (metres, scale 1 ≈ 1.76 m). */
export const L = {
  spine: 0.17,
  chest: 0.33,
  neck: 0.1,
  head: 0.23,
  shW: 0.175,
  hipW: 0.09,
  upper: 0.29,
  fore: 0.26,
  hand: 0.17,
  thigh: 0.44,
  shin: 0.44,
  ankleH: 0.08,
  standY: 0.98, // pelvis height with straight legs
};

const kg = [4.5, 2.5, 14, 11, 12, 4, 2, 1.2, 0.6, 4, 2, 1.2, 0.6, 6, 4, 2, 0.9, 6, 4, 2, 0.9, 2, 1.5, 1.5, 3, 3, 5, 5, 3, 3];
export const INV_MASS = new Float32Array(kg.map((m) => 1 / m));
export const RADIUS = new Float32Array([
  0.1, 0.06, 0.13, 0.12, 0.12, 0.07, 0.05, 0.04, 0.03, 0.07, 0.05, 0.04, 0.03, 0.08, 0.06, 0.05, 0.03, 0.08, 0.06, 0.05, 0.03,
  0.06, 0.05, 0.05, 0.06, 0.06, 0.08, 0.08, 0.07, 0.07,
]);

/** Joint pairs (body side, limb side) merged after every solve unless torn. */
export const JOINTS: [number, number][] = [
  [P.NECK, P.NECK2],
  [P.LSH, P.LSH2],
  [P.RSH, P.RSH2],
  [P.LEL, P.LEL2],
  [P.REL, P.REL2],
  [P.LHIP, P.LHIP2],
  [P.RHIP, P.RHIP2],
  [P.LKN, P.LKN2],
  [P.RKN, P.RKN2],
];

/** Severable body parts → the particles that leave the body. */
export type PartId = 'head' | 'lArm' | 'lFore' | 'rArm' | 'rFore' | 'lLeg' | 'lShin' | 'rLeg' | 'rShin';
export const SEVER: Record<PartId, { pts: number[]; stump: [number, number]; piece: [number, number] }> = {
  head: { pts: [P.NECK2, P.HEAD], stump: [P.NECK, P.CHEST], piece: [P.NECK2, P.HEAD] },
  lArm: { pts: [P.LSH2, P.LEL, P.LEL2, P.LWR, P.LHA], stump: [P.LSH, P.RSH], piece: [P.LSH2, P.LEL] },
  lFore: { pts: [P.LEL2, P.LWR, P.LHA], stump: [P.LEL, P.LSH2], piece: [P.LEL2, P.LWR] },
  rArm: { pts: [P.RSH2, P.REL, P.REL2, P.RWR, P.RHA], stump: [P.RSH, P.LSH], piece: [P.RSH2, P.REL] },
  rFore: { pts: [P.REL2, P.RWR, P.RHA], stump: [P.REL, P.RSH2], piece: [P.REL2, P.RWR] },
  lLeg: { pts: [P.LHIP2, P.LKN, P.LKN2, P.LAN, P.LTO], stump: [P.LHIP, P.SPINE], piece: [P.LHIP2, P.LKN] },
  lShin: { pts: [P.LKN2, P.LAN, P.LTO], stump: [P.LKN, P.LHIP2], piece: [P.LKN2, P.LAN] },
  rLeg: { pts: [P.RHIP2, P.RKN, P.RKN2, P.RAN, P.RTO], stump: [P.RHIP, P.SPINE], piece: [P.RHIP2, P.RKN] },
  rShin: { pts: [P.RKN2, P.RAN, P.RTO], stump: [P.RKN, P.RHIP2], piece: [P.RKN2, P.RAN] },
};

/* --------------------------------------------------------------- pose / FK */
export interface Pose {
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  pTilt: number;
  pTwist: number;
  pRoll: number;
  spBend: number;
  spSide: number;
  spTwist: number;
  chBend: number;
  chSide: number;
  chTwist: number;
  nkBend: number;
  hdPitch: number;
  hdYaw: number;
  hdRoll: number;
  shDropL: number;
  shDropR: number;
  aFlexL: number;
  aAbdL: number;
  eFlexL: number;
  wFlexL: number;
  aFlexR: number;
  aAbdR: number;
  eFlexR: number;
  wFlexR: number;
  hFlexL: number;
  hAbdL: number;
  kFlexL: number;
  ankL: number;
  hFlexR: number;
  hAbdR: number;
  kFlexR: number;
  ankR: number;
}
export type PoseKey = keyof Pose;
export function makePose(p: Partial<Pose> = {}): Pose {
  const base: Pose = {
    x: 0, y: L.standY, z: 0, yaw: 0, pitch: 0, roll: 0,
    pTilt: 0, pTwist: 0, pRoll: 0, spBend: 0, spSide: 0, spTwist: 0, chBend: 0, chSide: 0, chTwist: 0,
    nkBend: 0, hdPitch: 0, hdYaw: 0, hdRoll: 0, shDropL: 0, shDropR: 0,
    aFlexL: 0, aAbdL: 0.1, eFlexL: 0.1, wFlexL: 0, aFlexR: 0, aAbdR: 0.1, eFlexR: 0.1, wFlexR: 0,
    hFlexL: 0, hAbdL: 0, kFlexL: 0, ankL: 0, hFlexR: 0, hAbdR: 0, kFlexR: 0, ankR: 0,
  };
  return Object.assign(base, p);
}
export const POSE_KEYS = Object.keys(makePose()) as PoseKey[];
export function lerpPose(out: Pose, a: Pose, b: Pose, t: number) {
  for (const k of POSE_KEYS) out[k] = a[k] + (b[k] - a[k]) * t;
  return out;
}

const _E = new THREE.Euler();
const qR = new THREE.Quaternion();
const qL = new THREE.Quaternion();
const qP = new THREE.Quaternion();
const qS = new THREE.Quaternion();
const qC = new THREE.Quaternion();
const qN = new THREE.Quaternion();
const qH = new THREE.Quaternion();
const qA = new THREE.Quaternion();
const qF = new THREE.Quaternion();
const qT = new THREE.Quaternion();
const _v = new THREE.Vector3();

function rot(out: THREE.Quaternion, x: number, y: number, z: number, order: THREE.EulerOrder = 'YXZ') {
  _E.set(x, y, z, order);
  return out.setFromEuler(_E);
}
function put(o: Float32Array, i: number, from: number, q: THREE.Quaternion, x: number, y: number, z: number) {
  _v.set(x, y, z).applyQuaternion(q);
  o[i * 3] = o[from * 3] + _v.x;
  o[i * 3 + 1] = o[from * 3 + 1] + _v.y;
  o[i * 3 + 2] = o[from * 3 + 2] + _v.z;
}
function cp(o: Float32Array, i: number, from: number) {
  o[i * 3] = o[from * 3];
  o[i * 3 + 1] = o[from * 3 + 1];
  o[i * 3 + 2] = o[from * 3 + 2];
}

/** Forward kinematics: pose → all 30 particle targets in world space. */
export function fk(p: Pose, s: number, o: Float32Array, legs = true) {
  rot(qR, p.pitch, p.yaw, p.roll);
  qP.multiplyQuaternions(qR, rot(qL, p.pTilt, p.pTwist, p.pRoll));
  o[P.PELVIS * 3] = p.x;
  o[P.PELVIS * 3 + 1] = p.y;
  o[P.PELVIS * 3 + 2] = p.z;
  put(o, P.LHIP, P.PELVIS, qP, L.hipW * s, -0.02 * s, 0);
  put(o, P.RHIP, P.PELVIS, qP, -L.hipW * s, -0.02 * s, 0);
  cp(o, P.LHIP2, P.LHIP);
  cp(o, P.RHIP2, P.RHIP);
  qS.multiplyQuaternions(qP, rot(qL, p.spBend, p.spTwist, p.spSide));
  put(o, P.SPINE, P.PELVIS, qS, 0, L.spine * s, 0);
  qC.multiplyQuaternions(qS, rot(qL, p.chBend, p.chTwist, p.chSide));
  put(o, P.CHEST, P.SPINE, qC, 0, L.chest * s, 0);
  put(o, P.LSH, P.CHEST, qC, L.shW * s, (-0.035 + p.shDropL) * s, -0.01 * s);
  put(o, P.RSH, P.CHEST, qC, -L.shW * s, (-0.035 + p.shDropR) * s, -0.01 * s);
  cp(o, P.LSH2, P.LSH);
  cp(o, P.RSH2, P.RSH);
  qN.multiplyQuaternions(qC, rot(qL, p.nkBend, 0, 0));
  put(o, P.NECK, P.CHEST, qN, 0, L.neck * s, 0.012 * s);
  cp(o, P.NECK2, P.NECK);
  qH.multiplyQuaternions(qN, rot(qL, p.hdPitch, p.hdYaw, p.hdRoll));
  put(o, P.HEAD, P.NECK, qH, 0, L.head * s, 0.015 * s);

  // arms
  for (let k = 0; k < 2; k++) {
    const side = k === 0 ? 1 : -1;
    const sh = k === 0 ? P.LSH : P.RSH;
    const el = k === 0 ? P.LEL : P.REL;
    const el2 = k === 0 ? P.LEL2 : P.REL2;
    const wr = k === 0 ? P.LWR : P.RWR;
    const ha = k === 0 ? P.LHA : P.RHA;
    const flex = k === 0 ? p.aFlexL : p.aFlexR;
    const abd = k === 0 ? p.aAbdL : p.aAbdR;
    const ef = k === 0 ? p.eFlexL : p.eFlexR;
    const wf = k === 0 ? p.wFlexL : p.wFlexR;
    qA.multiplyQuaternions(qC, rot(qL, -flex, 0, side * abd, 'XZY'));
    put(o, el, sh, qA, 0, -L.upper * s, 0);
    cp(o, el2, el);
    qF.multiplyQuaternions(qA, rot(qL, -ef, 0, 0));
    put(o, wr, el, qF, 0, -L.fore * s, 0);
    qF.multiply(rot(qL, -wf, 0, 0));
    put(o, ha, wr, qF, 0, -L.hand * s, 0.01 * s);
  }
  if (!legs) return;
  for (let k = 0; k < 2; k++) {
    const side = k === 0 ? 1 : -1;
    const hip = k === 0 ? P.LHIP : P.RHIP;
    const kn = k === 0 ? P.LKN : P.RKN;
    const kn2 = k === 0 ? P.LKN2 : P.RKN2;
    const an = k === 0 ? P.LAN : P.RAN;
    const to = k === 0 ? P.LTO : P.RTO;
    const hf = k === 0 ? p.hFlexL : p.hFlexR;
    const ha = k === 0 ? p.hAbdL : p.hAbdR;
    const kf = k === 0 ? p.kFlexL : p.kFlexR;
    const ak = k === 0 ? p.ankL : p.ankR;
    qT.multiplyQuaternions(qP, rot(qL, -hf, 0, side * ha, 'XZY'));
    put(o, kn, hip, qT, 0, -L.thigh * s, 0);
    cp(o, kn2, kn);
    qT.multiply(rot(qL, kf, 0, 0));
    put(o, an, kn, qT, 0, -L.shin * s, 0);
    qT.multiply(rot(qL, ak, 0, 0));
    put(o, to, an, qT, side * 0.01 * s, -0.055 * s, 0.155 * s);
  }
}

/** Analytic two-bone IK. Writes the middle joint (b) and end (c) given a root (a) already placed. */
export function ik2(
  o: Float32Array,
  a: number,
  b: number,
  c: number,
  tx: number,
  ty: number,
  tz: number,
  l1: number,
  l2: number,
  px: number,
  py: number,
  pz: number,
) {
  const ax = o[a * 3];
  const ay = o[a * 3 + 1];
  const az = o[a * 3 + 2];
  let dx = tx - ax;
  let dy = ty - ay;
  let dz = tz - az;
  let d = Math.hypot(dx, dy, dz) || 1e-4;
  dx /= d;
  dy /= d;
  dz /= d;
  d = Math.min(Math.max(d, Math.abs(l1 - l2) + 0.02), l1 + l2 - 0.002);
  const along = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - along * along));
  // pole perpendicular to the chain
  const pd = px * dx + py * dy + pz * dz;
  let qx = px - dx * pd;
  let qy = py - dy * pd;
  let qz = pz - dz * pd;
  const ql = Math.hypot(qx, qy, qz) || 1;
  qx /= ql;
  qy /= ql;
  qz /= ql;
  o[b * 3] = ax + dx * along + qx * h;
  o[b * 3 + 1] = ay + dy * along + qy * h;
  o[b * 3 + 2] = az + dz * along + qz * h;
  o[c * 3] = ax + dx * d;
  o[c * 3 + 1] = ay + dy * d;
  o[c * 3 + 2] = az + dz * d;
}

/* ------------------------------------------------------------ constraints */
export interface ConstraintSet {
  a: Uint8Array;
  b: Uint8Array;
  min: Float32Array;
  max: Float32Array;
  stiff: Float32Array;
  n: number;
}

/** Build the ragdoll constraint set from the rest pose (scale 1; scaled at runtime). */
export function buildConstraints(): ConstraintSet {
  const rest = new Float32Array(NP * 3);
  fk(makePose({ aAbdL: 0.15, aAbdR: 0.15, eFlexL: 0.2, eFlexR: 0.2 }), 1, rest);
  const d = (i: number, j: number) =>
    Math.hypot(rest[i * 3] - rest[j * 3], rest[i * 3 + 1] - rest[j * 3 + 1], rest[i * 3 + 2] - rest[j * 3 + 2]);
  const list: [number, number, number, number, number][] = [];
  const rigid = (i: number, j: number) => {
    const r = d(i, j);
    list.push([i, j, r, r, 1]);
  };
  const range = (i: number, j: number, lo: number, hi: number, st = 1) => list.push([i, j, lo, hi, st]);
  const rel = (i: number, j: number, lo: number, hi: number, st = 1) => {
    const r = d(i, j);
    list.push([i, j, r * lo, r * hi, st]);
  };
  const apart = (i: number, j: number, m: number) => list.push([i, j, m, 99, 0.5]);
  const {
    HEAD, NECK, CHEST, SPINE, PELVIS, LSH, LEL, LWR, LHA, RSH, REL, RWR, RHA, LHIP, LKN, LAN, LTO, RHIP, RKN, RAN, RTO,
    NECK2, LEL2, REL2, LKN2, RKN2, LHIP2, RHIP2, LSH2, RSH2,
  } = P;

  // upper torso block
  rigid(NECK, CHEST);
  rigid(CHEST, SPINE);
  rigid(CHEST, LSH);
  rigid(CHEST, RSH);
  rigid(LSH, RSH);
  rigid(LSH, SPINE);
  rigid(RSH, SPINE);
  rigid(LSH, NECK);
  rigid(RSH, NECK);
  // lower torso / pelvis block
  rigid(SPINE, PELVIS);
  rigid(PELVIS, LHIP);
  rigid(PELVIS, RHIP);
  rigid(LHIP, RHIP);
  rigid(LHIP, SPINE);
  rigid(RHIP, SPINE);
  // lumbar joint limits (bend / side bend / twist)
  rel(CHEST, PELVIS, 0.82, 1.0);
  rel(LSH, LHIP, 0.84, 1.04);
  rel(RSH, RHIP, 0.84, 1.04);
  rel(LSH, RHIP, 0.9, 1.05);
  rel(RSH, LHIP, 0.9, 1.05);
  // head on the neck
  rigid(NECK2, HEAD);
  rel(HEAD, CHEST, 0.8, 1.01);
  rel(HEAD, LSH, 0.78, 1.12);
  rel(HEAD, RSH, 0.78, 1.12);
  // arms
  for (const [sh2, el, el2, wr, ha] of [
    [LSH2, LEL, LEL2, LWR, LHA],
    [RSH2, REL, REL2, RWR, RHA],
  ]) {
    rigid(sh2, el);
    rigid(el2, wr);
    rigid(wr, ha);
    range(sh2, wr, 0.16, L.upper + L.fore); // elbow hinge limit (~155° flex)
    range(el2, ha, (L.fore + L.hand) * 0.86, L.fore + L.hand); // wrist limit
    apart(el, SPINE, 0.13);
    apart(ha, SPINE, 0.13);
    apart(ha, CHEST, 0.14);
    apart(wr, PELVIS, 0.12);
    apart(ha, HEAD, 0.1);
  }
  // legs
  for (const [hip2, kn, kn2, an, to] of [
    [LHIP2, LKN, LKN2, LAN, LTO],
    [RHIP2, RKN, RKN2, RAN, RTO],
  ]) {
    rigid(hip2, kn);
    rigid(kn2, an);
    rigid(an, to);
    range(hip2, an, 0.2, L.thigh + L.shin); // knee limit
    rel(kn2, to, 0.88, 1.12); // ankle limit
    apart(kn, CHEST, 0.3);
    apart(kn, SPINE, 0.16);
    apart(an, PELVIS, 0.18);
  }
  apart(LKN, RKN, 0.15);
  apart(LAN, RAN, 0.14);
  apart(LTO, RTO, 0.12);
  apart(HEAD, PELVIS, 0.45);
  apart(HEAD, LKN, 0.2);
  apart(HEAD, RKN, 0.2);

  const n = list.length;
  const cs: ConstraintSet = {
    a: new Uint8Array(n),
    b: new Uint8Array(n),
    min: new Float32Array(n),
    max: new Float32Array(n),
    stiff: new Float32Array(n),
    n,
  };
  list.forEach(([i, j, lo, hi, st], k) => {
    cs.a[k] = i;
    cs.b[k] = j;
    cs.min[k] = lo;
    cs.max[k] = hi;
    cs.stiff[k] = st;
  });
  return cs;
}

/* ---------------------------------------------------------- render segments */
export type Region = 'head' | 'torso' | 'pelvis' | 'lArm' | 'rArm' | 'lLeg' | 'rLeg';
export interface SegDef {
  kind: string;
  a: number;
  b: number;
  ref: 'sh' | 'hip';
  r: number;
  region: Region;
  part?: PartId; // severing a hit here tears this part off
  dmg: number; // damage multiplier
}
export const SEGS: SegDef[] = [
  { kind: 'head', a: P.NECK2, b: P.HEAD, ref: 'sh', r: 0.115, region: 'head', part: 'head', dmg: 4 },
  { kind: 'neck', a: P.CHEST, b: P.NECK, ref: 'sh', r: 0.065, region: 'head', part: 'head', dmg: 2.2 },
  { kind: 'chest', a: P.SPINE, b: P.CHEST, ref: 'sh', r: 0.175, region: 'torso', dmg: 1 },
  { kind: 'abdomen', a: P.PELVIS, b: P.SPINE, ref: 'hip', r: 0.155, region: 'torso', dmg: 0.9 },
  { kind: 'pelvis', a: P.PELVIS, b: P.SPINE, ref: 'hip', r: 0.16, region: 'pelvis', dmg: 0.8 },
  { kind: 'upperArm', a: P.LSH2, b: P.LEL, ref: 'sh', r: 0.062, region: 'lArm', part: 'lArm', dmg: 0.6 },
  { kind: 'upperArm', a: P.RSH2, b: P.REL, ref: 'sh', r: 0.062, region: 'rArm', part: 'rArm', dmg: 0.6 },
  { kind: 'forearm', a: P.LEL2, b: P.LWR, ref: 'sh', r: 0.052, region: 'lArm', part: 'lFore', dmg: 0.5 },
  { kind: 'forearm', a: P.REL2, b: P.RWR, ref: 'sh', r: 0.052, region: 'rArm', part: 'rFore', dmg: 0.5 },
  { kind: 'hand', a: P.LWR, b: P.LHA, ref: 'sh', r: 0.045, region: 'lArm', part: 'lFore', dmg: 0.4 },
  { kind: 'hand', a: P.RWR, b: P.RHA, ref: 'sh', r: 0.045, region: 'rArm', part: 'rFore', dmg: 0.4 },
  { kind: 'thigh', a: P.LHIP2, b: P.LKN, ref: 'hip', r: 0.085, region: 'lLeg', part: 'lLeg', dmg: 0.7 },
  { kind: 'thigh', a: P.RHIP2, b: P.RKN, ref: 'hip', r: 0.085, region: 'rLeg', part: 'rLeg', dmg: 0.7 },
  { kind: 'shin', a: P.LKN2, b: P.LAN, ref: 'hip', r: 0.065, region: 'lLeg', part: 'lShin', dmg: 0.6 },
  { kind: 'shin', a: P.RKN2, b: P.RAN, ref: 'hip', r: 0.065, region: 'rLeg', part: 'rShin', dmg: 0.6 },
  { kind: 'foot', a: P.LAN, b: P.LTO, ref: 'hip', r: 0.055, region: 'lLeg', part: 'lShin', dmg: 0.4 },
  { kind: 'foot', a: P.RAN, b: P.RTO, ref: 'hip', r: 0.055, region: 'rLeg', part: 'rShin', dmg: 0.4 },
];

/* ------------------------------------------------------ get-up key frames */
const PI = Math.PI;
export interface Key {
  t: number;
  p: Pose;
}
/** Face-down recovery (local +Z = where the head lies). */
export const GETUP_PRONE: Key[] = [
  { t: 0, p: makePose({ y: 0.13, pitch: PI / 2, hdPitch: -0.2, hdYaw: 0.7, aFlexL: 0.7, aAbdL: 0.8, eFlexL: 1.9, aFlexR: 0.7, aAbdR: 0.8, eFlexR: 1.9, kFlexL: 0.15, kFlexR: 0.1 }) },
  { t: 0.9, p: makePose({ y: 0.3, z: 0.02, pitch: PI / 2 - 0.4, hdPitch: -0.6, chBend: -0.15, aFlexL: 1.3, aAbdL: 0.35, eFlexL: 0.7, aFlexR: 1.2, aAbdR: 0.4, eFlexR: 0.9, hFlexL: 0.5, kFlexL: 1.0, hFlexR: 0.35, kFlexR: 0.8 }) },
  { t: 1.8, p: makePose({ y: 0.52, z: -0.08, pitch: PI / 2 - 0.12, hdPitch: -0.75, aFlexL: 1.5, aAbdL: 0.1, eFlexL: 0.45, aFlexR: 1.45, aAbdR: 0.12, eFlexR: 0.5, hFlexL: 1.55, kFlexL: 1.6, hFlexR: 1.5, kFlexR: 1.6, ankL: 0.4, ankR: 0.4 }) },
  { t: 2.8, p: makePose({ y: 0.56, z: -0.04, pitch: 0.75, hdPitch: -0.3, spBend: 0.2, aFlexL: 1.0, aAbdL: 0.15, eFlexL: 0.4, aFlexR: 0.6, aAbdR: 0.2, eFlexR: 0.3, hFlexL: 1.9, kFlexL: 2.2, hFlexR: 0.8, kFlexR: 1.65, ankR: 0.3 }) },
  { t: 3.7, p: makePose({ y: 0.72, z: 0.04, pitch: 0.55, hdPitch: 0.1, spBend: 0.15, aFlexL: 0.7, aAbdL: 0.2, eFlexL: 0.5, aFlexR: 0.35, aAbdR: 0.2, eFlexR: 0.3, hFlexL: 1.25, kFlexL: 1.45, hFlexR: 0.75, kFlexR: 1.2 }) },
  { t: 4.6, p: makePose({ y: 0.93, z: 0.08, pitch: 0.25, hdPitch: 0.25, spBend: 0.1, chBend: 0.12, aFlexL: 0.3, aAbdL: 0.15, eFlexL: 0.3, aFlexR: 0.2, aAbdR: 0.15, eFlexR: 0.25, hFlexL: 0.3, kFlexL: 0.12, hFlexR: 0.28, kFlexR: 0.1 }) },
];
/** Face-up recovery (local +Z = where the feet lie: the zombie sits up toward them). */
export const GETUP_SUPINE: Key[] = [
  { t: 0, p: makePose({ y: 0.12, pitch: -PI / 2, hdPitch: 0.2, aFlexL: 0.1, aAbdL: 0.7, eFlexL: 0.4, aFlexR: 0.2, aAbdR: 0.6, eFlexR: 0.5, kFlexL: 0.15, kFlexR: 0.05 }) },
  { t: 1.1, p: makePose({ y: 0.15, pitch: -0.65, hdPitch: 0.5, spBend: 0.25, chBend: 0.2, aFlexL: -0.6, aAbdL: 0.35, eFlexL: 0.2, aFlexR: -0.5, aAbdR: 0.35, eFlexR: 0.25, hFlexL: PI / 2 - 0.65, hFlexR: PI / 2 - 0.65, kFlexL: 0.2, kFlexR: 0.1 }) },
  { t: 2.0, p: makePose({ y: 0.16, pitch: 0.15, hdPitch: 0.3, spBend: 0.3, aFlexL: 0.7, aAbdL: 0.25, eFlexL: 0.4, aFlexR: 0.5, aAbdR: 0.3, eFlexR: 0.5, hFlexL: 2.1, kFlexL: 2.2, hFlexR: 1.7, kFlexR: 1.5 }) },
  { t: 2.9, p: makePose({ y: 0.46, z: 0.12, pitch: 0.7, hdPitch: 0.1, spBend: 0.25, aFlexL: 1.1, aAbdL: 0.2, eFlexL: 0.3, aFlexR: 0.9, aAbdR: 0.25, eFlexR: 0.35, hFlexL: 2.2, kFlexL: 2.3, hFlexR: 0.9, kFlexR: 1.7 }) },
  { t: 3.8, p: makePose({ y: 0.74, z: 0.16, pitch: 0.5, hdPitch: 0.2, spBend: 0.2, aFlexL: 0.6, aAbdL: 0.2, eFlexL: 0.4, aFlexR: 0.4, aAbdR: 0.2, eFlexR: 0.3, hFlexL: 1.1, kFlexL: 1.3, hFlexR: 0.7, kFlexR: 1.0 }) },
  { t: 4.6, p: makePose({ y: 0.93, z: 0.18, pitch: 0.25, hdPitch: 0.25, spBend: 0.1, chBend: 0.12, aFlexL: 0.3, aAbdL: 0.15, eFlexL: 0.3, aFlexR: 0.2, aAbdR: 0.15, eFlexR: 0.25, hFlexL: 0.3, kFlexL: 0.12, hFlexR: 0.28, kFlexR: 0.1 }) },
];

export function sampleKeys(keys: Key[], t: number, out: Pose) {
  if (t <= keys[0].t) return lerpPose(out, keys[0].p, keys[0].p, 0);
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i].t) {
      let u = (t - keys[i - 1].t) / (keys[i].t - keys[i - 1].t);
      u = u * u * (3 - 2 * u);
      return lerpPose(out, keys[i - 1].p, keys[i].p, u);
    }
  }
  const k = keys[keys.length - 1].p;
  return lerpPose(out, k, k, 0);
}
