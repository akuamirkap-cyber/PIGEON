import type { Terrain } from '../terrain';

/**
 * Grid flow field toward the player. Every cell stores its path distance to
 * the player (8-connected Dijkstra, no corner cutting, step-height aware), so
 * any number of zombies can navigate around walls, props and trees for the
 * price of one search.
 */
export class FlowField {
  readonly cell = 1;
  readonly n = 164;
  readonly half = 82;
  walk: Uint8Array;
  /** cell and all 8 neighbours are open ground: a body can't touch anything solid here */
  clear: Uint8Array;
  h: Float32Array;
  dist: Float32Array;
  private heap: Int32Array;
  private heapK: Float32Array;
  private hn = 0;
  private lastCell = -1;
  private timer = 0;

  constructor(terrain: Terrain) {
    const N = this.n * this.n;
    this.walk = new Uint8Array(N);
    this.h = new Float32Array(N);
    this.dist = new Float32Array(N).fill(Infinity);
    this.heap = new Int32Array(N * 8);
    this.heapK = new Float32Array(N * 8);
    for (let j = 0; j < this.n; j++) {
      for (let i = 0; i < this.n; i++) {
        const k = j * this.n + i;
        const x = (i - this.half + 0.5) * this.cell;
        const z = (j - this.half + 0.5) * this.cell;
        const hc = terrain.height(x, z);
        this.h[k] = hc;
        let ok = !terrain.solid(x, z);
        if (ok) {
          // the whole cell must be standable (no trunks / wall edges inside it)
          for (const [ox, oz] of [
            [0.42, 0],
            [-0.42, 0],
            [0, 0.42],
            [0, -0.42],
            [0.3, 0.3],
            [-0.3, 0.3],
            [0.3, -0.3],
            [-0.3, -0.3],
          ]) {
            if (terrain.solid(x + ox, z + oz) || Math.abs(terrain.height(x + ox, z + oz) - hc) > 0.36) {
              ok = false;
              break;
            }
          }
        }
        this.walk[k] = ok ? 1 : 0;
      }
    }
    this.clear = new Uint8Array(N);
    for (let j = 1; j < this.n - 1; j++)
      for (let i = 1; i < this.n - 1; i++) {
        let c = 1;
        for (let dj = -1; dj <= 1 && c; dj++) for (let di = -1; di <= 1; di++) if (!this.walk[(j + dj) * this.n + i + di]) c = 0;
        this.clear[j * this.n + i] = c;
      }
  }

  idx(x: number, z: number) {
    const i = Math.floor(x / this.cell + this.half);
    const j = Math.floor(z / this.cell + this.half);
    if (i < 0 || j < 0 || i >= this.n || j >= this.n) return -1;
    return j * this.n + i;
  }
  cx(k: number) {
    return ((k % this.n) - this.half + 0.5) * this.cell;
  }
  cz(k: number) {
    return (Math.floor(k / this.n) - this.half + 0.5) * this.cell;
  }

  private push(k: number, d: number) {
    let i = this.hn++;
    const H = this.heap;
    const K = this.heapK;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (K[p] <= d) break;
      H[i] = H[p];
      K[i] = K[p];
      i = p;
    }
    H[i] = k;
    K[i] = d;
  }
  private pop(): number {
    const H = this.heap;
    const K = this.heapK;
    const top = H[0];
    const n = --this.hn;
    const lk = H[n];
    const ld = K[n];
    let i = 0;
    for (;;) {
      let c = i * 2 + 1;
      if (c >= n) break;
      if (c + 1 < n && K[c + 1] < K[c]) c++;
      if (K[c] >= ld) break;
      H[i] = H[c];
      K[i] = K[c];
      i = c;
    }
    H[i] = lk;
    K[i] = ld;
    return top;
  }

  /** Rebuild the field around the player (throttled). */
  update(dt: number, px: number, pz: number, force = false) {
    this.timer -= dt;
    const pc = this.idx(px, pz);
    if (!force && this.timer > 0 && (pc === this.lastCell || this.timer > 0.2)) return;
    this.timer = 0.4;
    this.lastCell = pc;
    const D = this.dist;
    D.fill(Infinity);
    this.hn = 0;
    const n = this.n;
    // seed every standable cell near the player (works even when the player stands on a prop)
    const ci = Math.floor(px / this.cell + this.half);
    const cj = Math.floor(pz / this.cell + this.half);
    for (let j = cj - 2; j <= cj + 2; j++) {
      for (let i = ci - 2; i <= ci + 2; i++) {
        if (i < 0 || j < 0 || i >= n || j >= n) continue;
        const k = j * n + i;
        if (!this.walk[k]) continue;
        const d = Math.hypot(this.cx(k) - px, this.cz(k) - pz);
        if (d > 2.3) continue;
        if (d < D[k]) {
          D[k] = d;
          this.push(k, d);
        }
      }
    }
    const W = this.walk;
    const Hh = this.h;
    while (this.hn > 0) {
      const dk = this.heapK[0];
      const k = this.pop();
      if (dk > D[k]) continue;
      const i = k % n;
      const j = (k - i) / n;
      for (let dj = -1; dj <= 1; dj++) {
        const jj = j + dj;
        if (jj < 0 || jj >= n) continue;
        for (let di = -1; di <= 1; di++) {
          if (di === 0 && dj === 0) continue;
          const ii = i + di;
          if (ii < 0 || ii >= n) continue;
          const nk = jj * n + ii;
          if (!W[nk] || Math.abs(Hh[nk] - Hh[k]) > 0.4) continue;
          let c = 1;
          if (di !== 0 && dj !== 0) {
            // no diagonal squeezing past corners
            if (!W[j * n + ii] || !W[jj * n + i]) continue;
            c = 1.4142;
          }
          const nd = dk + c;
          if (nd < D[nk]) {
            D[nk] = nd;
            this.push(nk, nd);
          }
        }
      }
    }
  }

  /**
   * Steering point: follow the downhill chain a few cells ahead so the path is
   * smooth instead of 8-directional. Returns false if no path exists.
   */
  steer(x: number, z: number, out: { x: number; z: number }, look = 3): boolean {
    let k = this.idx(x, z);
    if (k < 0) return false;
    const n = this.n;
    if (!isFinite(this.dist[k])) {
      // stood in a blocked cell (squeezed against a wall): pick the best neighbour
      let best = -1;
      let bd = Infinity;
      for (let dj = -1; dj <= 1; dj++)
        for (let di = -1; di <= 1; di++) {
          const nk = k + dj * n + di;
          if (nk >= 0 && nk < this.dist.length && this.dist[nk] < bd) {
            bd = this.dist[nk];
            best = nk;
          }
        }
      if (best < 0) return false;
      k = best;
    }
    for (let s = 0; s < look; s++) {
      const i = k % n;
      const j = (k - i) / n;
      let best = k;
      let bd = this.dist[k];
      for (let dj = -1; dj <= 1; dj++) {
        for (let di = -1; di <= 1; di++) {
          if (!di && !dj) continue;
          const ii = i + di;
          const jj = j + dj;
          if (ii < 0 || jj < 0 || ii >= n || jj >= n) continue;
          const nk = jj * n + ii;
          if (di && dj && (!this.walk[j * n + ii] || !this.walk[jj * n + i])) continue;
          if (this.dist[nk] < bd) {
            bd = this.dist[nk];
            best = nk;
          }
        }
      }
      if (best === k) break;
      k = best;
    }
    out.x = this.cx(k);
    out.z = this.cz(k);
    return true;
  }

  pathDist(x: number, z: number) {
    const k = this.idx(x, z);
    return k < 0 ? Infinity : this.dist[k];
  }
}
