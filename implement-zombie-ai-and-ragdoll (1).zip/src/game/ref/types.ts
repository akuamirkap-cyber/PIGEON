export type WeaponId = 'pistol' | 'rifle' | 'sniper';

export type ZoneId = 'compound' | 'courtyard' | 'alpine' | 'ridge';

export type GameMode = 'range' | 'drill' | 'horde' | 'tdm';

export type WeaponAnimState =
  | 'ready'
  | 'ads'
  | 'firing'
  | 'bolt_cycle'
  | 'reloading'
  | 'inspecting'
  | 'equipping';

export interface WeaponSpec {
  id: WeaponId;
  name: string;
  label: string;
  caliber: string;
  fireMode: 'SEMI-AUTO' | 'FULL-AUTO' | 'BOLT-ACTION';
  magSize: number;
  rpm: number;
  reloadDuration: number;
  boltCycleDuration: number;
  damageBody: number;
  damageHead: number;
  muzzleVelocity: number; // m/s visual tracer speed
  recoilPitch: number; // upward kick rad
  recoilKickZ: number; // rearward kick m
  recoilYaw: number; // random horizontal sway
  cameraPunch: number; // world camera pitch kick
  adsFov: number;
  spreadHip: number;
  spreadAds: number;
  shellLabel: string;
  muzzleFxLabel: string;
  actionAnimLabel: string;
  ejectionTimingLabel: string;
}

export const WEAPON_SPECS: Record<WeaponId, WeaponSpec> = {
  pistol: {
    id: 'pistol',
    name: 'TACTICAL 1911',
    label: 'PISTOL',
    caliber: '.45 ACP / 9mm',
    fireMode: 'SEMI-AUTO',
    magSize: 12,
    rpm: 380,
    reloadDuration: 1.02,
    boltCycleDuration: 0,
    damageBody: 34,
    damageHead: 90,
    muzzleVelocity: 170,
    recoilPitch: 0.24,
    recoilKickZ: 0.052,
    recoilYaw: 0.032,
    cameraPunch: 0.022,
    adsFov: 58,
    spreadHip: 0.012,
    spreadAds: 0.002,
    shellLabel: 'Selongsong kuningan pendek (.45) — memantul kanan-atas dari ruang bakar (Ejection Port)',
    muzzleFxLabel: 'Api muzzle bintang 4 arah + asap bubuk mesiu + proyektil tracer emas',
    actionAnimLabel: 'Slide atas mundur penuh (Blowback), Hammer memukul, terkunci mundur saat ammo 0',
    ejectionTimingLabel: 'Langsung saat slide mundur setiap tembakan',
  },
  rifle: {
    id: 'rifle',
    name: 'M4A1 CARBINE',
    label: 'RIFLE',
    caliber: '5.56×45mm NATO',
    fireMode: 'FULL-AUTO',
    magSize: 30,
    rpm: 680,
    reloadDuration: 1.28,
    boltCycleDuration: 0,
    damageBody: 28,
    damageHead: 72,
    muzzleVelocity: 260,
    recoilPitch: 0.095,
    recoilKickZ: 0.042,
    recoilYaw: 0.028,
    cameraPunch: 0.015,
    adsFov: 50,
    spreadHip: 0.018,
    spreadAds: 0.0025,
    shellLabel: 'Selongsong botol 5.56mm — terpantul Brass Deflector sisi kanan',
    muzzleFxLabel: 'Api Flash-Hider multi-arah + peluru supersonik 5.56 + gas & asap tipis',
    actionAnimLabel: 'Dust Cover terbuka, Bolt Carrier bolak-balik cepat tiap peluru + recoil bahu ritmis',
    ejectionTimingLabel: 'Otomatis beruntun saat Bolt Carrier mundur',
  },
  sniper: {
    id: 'sniper',
    name: 'M24 MARKSMAN',
    label: 'SNIPER',
    caliber: '.338 LAPUA MAG',
    fireMode: 'BOLT-ACTION',
    magSize: 5,
    rpm: 46,
    reloadDuration: 1.75,
    boltCycleDuration: 0.78,
    damageBody: 110,
    damageHead: 250,
    muzzleVelocity: 420,
    recoilPitch: 0.34,
    recoilKickZ: 0.105,
    recoilYaw: 0.025,
    cameraPunch: 0.044,
    adsFov: 52, // Peripheral world FOV around the 3D scope tube while inside the glass magnifies at 4.7x (14.5°)!
    spreadHip: 0.032,
    spreadAds: 0.0002,
    shellLabel: 'Selongsong panjang .338 kuningan — keluar SAAT kokang bolt ditarik mundur!',
    muzzleFxLabel: 'Semburan gas Muzzle Brake kiri-kanan + api depan + shockwave + jejak contrail putih',
    actionAnimLabel: 'Hentakan recoil berat -> Tangan kanan angkat Bolt 60°, tarik mundur (buang selongsong), dorong & kunci!',
    ejectionTimingLabel: 'Tertunda: keluar tepat saat tangan menarik kokang Bolt ke belakang',
  },
};
