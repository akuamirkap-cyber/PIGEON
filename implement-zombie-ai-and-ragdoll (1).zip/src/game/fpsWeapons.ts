import * as THREE from 'three';
import { buildAllWeaponRigs, WeaponRig } from './ref/weaponModels';
import { WEAPON_SPECS, WeaponId } from './ref/types';
import { soundEngine } from './ref/audio';
import type { Terrain } from './terrain';

/* ===========================================================================
 * FIRST-PERSON WEAPON SYSTEM — ported from the PIGEON reference engine
 * (zombie-horde-shader-implementation / src/game/engine.ts + weaponModels.ts):
 *  • sculpted-hand weapon rigs (buildAllWeaponRigs) in a dedicated vmScene
 *  • WEAPON_POSES ready / ads / reload / bolt / sprint, equip + inspect states
 *  • recoil impulses + spring recovery, slide blowback / hammer / slide lock,
 *    rifle bolt carrier + dust cover, sniper bolt-action cycle with staged audio
 *  • animateWeaponReload (pistol / rifle / sniper) with staged reload sounds
 *  • figure-8 bob, mouse sway, idle breathing, crouch cant, landing jolt
 *  • live picture-in-picture magnifying sniper scope (render target)
 *  • brass shell casings, speed tracers, sniper contrail, muzzle smoke,
 *    sniper brake blast — all spawned from projected viewmodel sockets
 *  • bodycam chest camera (breathing, C∞ bob, trauma, recoil punch, roll)
 * ======================================================================== */

type Pose = { pos: THREE.Vector3; rot: THREE.Euler };
type AnimState = 'ready' | 'ads' | 'reloading' | 'bolt_cycle' | 'equipping' | 'inspecting' | 'holstered';
export const IDS: WeaponId[] = ['pistol', 'rifle', 'sniper'];

export const CHEST_CAMERA_HEIGHT = 1.34;
export const CROUCH_CAMERA_HEIGHT = 0.8;
const BODYCAM_BASE_FOV = 98;
const BODYCAM_VM_FOV = 60;
const CAMERA_SHAKE = 0.14; // reference default filterSettings.cameraShake

const WEAPON_POSES: Record<WeaponId, { ready: Pose; ads: Pose; reload: Pose; bolt: Pose; sprint: Pose }> = {
  pistol: {
    ready: { pos: new THREE.Vector3(0.015, -0.115, -0.45), rot: new THREE.Euler(0.025, 0.0, -0.025) },
    ads: { pos: new THREE.Vector3(0.0, -0.068, -0.36), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(-0.005, -0.105, -0.42), rot: new THREE.Euler(0.16, 0.27, -0.21) },
    bolt: { pos: new THREE.Vector3(0.015, -0.115, -0.45), rot: new THREE.Euler(0.025, 0.0, -0.025) },
    sprint: { pos: new THREE.Vector3(0.0, -0.17, -0.43), rot: new THREE.Euler(-0.34, 0.12, -0.1) },
  },
  rifle: {
    ready: { pos: new THREE.Vector3(0.02, -0.125, -0.37), rot: new THREE.Euler(0.02, 0.0, -0.03) },
    ads: { pos: new THREE.Vector3(0.0, -0.118, -0.25), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(0.06, -0.135, -0.46), rot: new THREE.Euler(0.23, 0.56, -0.48) },
    bolt: { pos: new THREE.Vector3(0.02, -0.125, -0.37), rot: new THREE.Euler(0.02, 0.0, -0.03) },
    sprint: { pos: new THREE.Vector3(0.03, -0.175, -0.38), rot: new THREE.Euler(-0.3, 0.26, -0.18) },
  },
  sniper: {
    ready: { pos: new THREE.Vector3(0.095, -0.14, -0.42), rot: new THREE.Euler(0.025, 0.055, -0.045) },
    ads: { pos: new THREE.Vector3(0.0, -0.124, -0.285), rot: new THREE.Euler(0.0, 0.0, 0.0) },
    reload: { pos: new THREE.Vector3(0.065, -0.13, -0.46), rot: new THREE.Euler(0.2, 0.46, -0.34) },
    bolt: { pos: new THREE.Vector3(0.075, -0.135, -0.44), rot: new THREE.Euler(0.14, 0.3, -0.24) },
    sprint: { pos: new THREE.Vector3(0.05, -0.19, -0.44), rot: new THREE.Euler(-0.28, 0.3, -0.16) },
  },
};

interface Shell {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  age: number;
  maxAge: number;
  bounces: number;
  weapon: WeaponId;
}
interface Tracer {
  mesh: THREE.Mesh;
  start: THREE.Vector3;
  dir: THREE.Vector3;
  distTotal: number;
  distTraveled: number;
  speed: number;
}
interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  angVel: THREE.Vector3;
  gravity: number;
  age: number;
  maxAge: number;
  startScale: number;
  endScale: number;
}

export interface FpsInput {
  slot: number;
  adsHeld: boolean;
  reload: number; // arsenal reload progress (0 = not reloading)
  ammo: number;
  sprinting: boolean;
  speed: number;
  grounded: boolean;
  crouch: number;
  lookX: number; // radians this frame
  lookY: number;
  landed: number; // landing impact (0 = none)
}

/** Reference ADS pose (for aligning third-person aiming to the same sight line). */
export function adsPose(slot: number) {
  return WEAPON_POSES[IDS[slot]].ads;
}

export class FpsWeapons {
  vmScene = new THREE.Scene();
  vmCamera = new THREE.PerspectiveCamera(BODYCAM_VM_FOV, 1, 0.01, 10);
  visible = false;
  rigs: Record<WeaponId, WeaponRig>;
  weaponId: WeaponId = 'rifle';
  animState: AnimState = 'holstered';
  adsBlend = 0;
  sprintBlend = 0;
  crouchBlend = 0;
  camTrauma = 0;
  camRecoilPitch = 0;
  worldFov = BODYCAM_BASE_FOV;

  private worldScene: THREE.Scene;
  private terrain: Terrain;
  private scopeRT: THREE.WebGLRenderTarget;
  private scopeCam = new THREE.PerspectiveCamera(14.5, 1, 0.2, 380);
  private vmMuzzleLight = new THREE.PointLight(0xffa73b, 0, 2.5);
  private muzzleFlashTimer = 0;
  private equipTimer = 0;
  private inspectTimer = 0;
  private boltTimer = 0;
  private boltDuration = 0.78;
  private boltStage = new Set<string>();
  private reloadStage = new Set<string>();
  private triggerPullTimer = 0;
  private recoilPosZ = 0;
  private recoilRotX = 0;
  private recoilRotY = 0;
  private recoilRotZ = 0;
  private camRecoilVel = 0;
  private slideKick = 0;
  private rifleBoltKick = 0;
  private rifleDustCoverOpen = false;
  private swayX = 0;
  private swayY = 0;
  private turnRoll = 0;
  private moveBobTime = 0;
  private moveSpeedNorm = 0;
  private landJolt = 0;
  private landJoltVel = 0;
  private smoothCamBobX = 0;
  private smoothCamBobY = 0;
  private smoothCamPitch = 0;
  private smoothRollZ = 0;
  private smoothCamHeight = CHEST_CAMERA_HEIGHT;
  private rawTime = 0;
  private ammo = 0;
  private curVmPos = new THREE.Vector3();
  private curVmRot = new THREE.Euler();
  private tmpV1 = new THREE.Vector3();
  private tmpV2 = new THREE.Vector3();
  private tmpEuler = new THREE.Euler();
  private camVel = new THREE.Vector3();

  // world FX
  private shells: Shell[] = [];
  private tracers: Tracer[] = [];
  private contrails: { mesh: THREE.Mesh; age: number; maxAge: number }[] = [];
  private particles: Particle[] = [];
  private brassMat = new THREE.MeshStandardMaterial({ color: 0xe8b954, roughness: 0.25, metalness: 0.88, flatShading: true });
  private shellGeos: Record<WeaponId, THREE.BufferGeometry> = {
    pistol: new THREE.CylinderGeometry(0.0065, 0.0065, 0.024, 6).toNonIndexed(),
    rifle: new THREE.CylinderGeometry(0.0052, 0.0072, 0.044, 6).toNonIndexed(),
    sniper: new THREE.CylinderGeometry(0.0068, 0.0095, 0.068, 7).toNonIndexed(),
  };
  private smokeGeo = new THREE.IcosahedronGeometry(0.11, 0).toNonIndexed();
  private smokeMat = new THREE.MeshStandardMaterial({ color: 0xeaeff2, roughness: 0.95, transparent: true, opacity: 0.58, flatShading: true, depthWrite: false });
  private matPool: THREE.Material[] = [];
  private matPoolI = 0;
  private tracerGeo: Record<WeaponId, THREE.BufferGeometry> = (() => {
    const mk = (len: number, rad: number) => {
      const g = new THREE.CylinderGeometry(rad * 0.5, rad, len, 5);
      g.rotateX(Math.PI / 2);
      return g;
    };
    return { pistol: mk(1.35, 0.015), rifle: mk(2.1, 0.015), sniper: mk(3.2, 0.024) };
  })();
  private tracerMat: Record<WeaponId, THREE.MeshBasicMaterial> = {
    pistol: new THREE.MeshBasicMaterial({ color: 0xffd066, transparent: true, opacity: 0.95 }),
    rifle: new THREE.MeshBasicMaterial({ color: 0xffd066, transparent: true, opacity: 0.95 }),
    sniper: new THREE.MeshBasicMaterial({ color: 0xfff5ba, transparent: true, opacity: 0.95 }),
  };

  constructor(worldScene: THREE.Scene, terrain: Terrain) {
    this.worldScene = worldScene;
    this.terrain = terrain;
    this.scopeRT = new THREE.WebGLRenderTarget(1024, 1024, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: THREE.HalfFloatType,
      depthBuffer: true,
      samples: 4,
    });
    // dedicated viewmodel scene + reference lighting
    this.vmScene.add(new THREE.HemisphereLight(0xd2e6fb, 0x677b93, 0.56));
    const sun = new THREE.DirectionalLight(0xfff9ee, 1.02);
    sun.position.set(2.8, 3.5, 1.2);
    this.vmScene.add(sun);
    const rim = new THREE.DirectionalLight(0xa4c9ea, 0.24);
    rim.position.set(-2.8, 1.0, -1.8);
    this.vmScene.add(rim);
    this.vmScene.add(this.vmMuzzleLight);
    this.rigs = buildAllWeaponRigs(this.scopeRT.texture);
    for (const id of IDS) {
      this.rigs[id].root.visible = false;
      this.rigs[id].root.traverse((o) => (o.frustumCulled = false));
      this.vmScene.add(this.rigs[id].root);
    }
    const start = WEAPON_POSES[this.weaponId].ready;
    this.curVmPos.copy(start.pos);
    this.curVmRot.copy(start.rot);
  }

  setAspect(a: number) {
    this.vmCamera.aspect = a;
    this.vmCamera.updateProjectionMatrix();
  }

  get spec() {
    return WEAPON_SPECS[this.weaponId];
  }

  // ------------------------------------------------------------------ states
  private switchWeapon(id: WeaponId) {
    for (const k of IDS) {
      this.rigs[k].root.visible = false;
      this.resetRigAnimatedParts(this.rigs[k]);
    }
    this.weaponId = id;
    this.rigs[id].root.visible = true;
    this.animState = 'equipping';
    this.equipTimer = 0.28;
    this.boltTimer = 0;
    this.inspectTimer = 0;
    this.adsBlend = 0;
    this.muzzleFlashTimer = 0;
    this.rigs[id].muzzleFlash.visible = false;
    this.recoilPosZ = this.recoilRotX = this.recoilRotY = this.recoilRotZ = 0;
    this.slideKick = 0;
    this.rifleBoltKick = 0;
    const ready = WEAPON_POSES[id].ready;
    this.curVmPos.set(ready.pos.x, ready.pos.y - 0.16, ready.pos.z + 0.08);
    this.curVmRot.set(-0.28, 0.15, -0.1);
    soundEngine.playReloadStep('bolt_down');
  }

  triggerInspect() {
    if (this.animState === 'reloading' || this.animState === 'bolt_cycle' || this.animState === 'equipping' || this.animState === 'holstered') return;
    if (this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
    } else {
      this.animState = 'inspecting';
      this.inspectTimer = 3.2;
    }
  }

  private resetRigAnimatedParts(rig: WeaponRig) {
    rig.leftArm.position.copy(rig.leftArmRestPos);
    rig.leftArm.rotation.copy(rig.leftArmRestRot);
    rig.rightArm.position.copy(rig.rightArmRestPos);
    rig.rightArm.rotation.copy(rig.rightArmRestRot);
    rig.mag.position.copy(rig.magRestPos);
    rig.mag.rotation.copy(rig.magRestRot);
    rig.mag.visible = true;
    if (rig.slide) rig.slide.position.set(0, 0, 0);
    if (rig.hammer) rig.hammer.rotation.set(0, 0, 0);
    if (rig.bolt) rig.bolt.position.set(0, rig.id === 'sniper' ? 0.036 : 0, rig.id === 'sniper' ? -0.02 : 0);
    if (rig.boltHandle) rig.boltHandle.rotation.set(0, 0, 0);
    if (rig.chargingHandle) rig.chargingHandle.position.set(0, 0.055, 0.095);
    if (rig.trigger) rig.trigger.rotation.set(0, 0, 0);
  }

  // -------------------------------------------------------------------- fire
  /** Visual / mechanical half of the reference tryFire(). Ballistics stay in the Arsenal. */
  fire(slot: number, ammoLeft: number, worldCam: THREE.PerspectiveCamera, playerVel: THREE.Vector3) {
    const id = IDS[slot];
    if (!id) return;
    if (id !== this.weaponId) this.switchWeapon(id);
    const spec = WEAPON_SPECS[id];
    this.ammo = ammoLeft;
    this.camVel.copy(playerVel);
    if (this.animState === 'inspecting') {
      this.animState = 'ready';
      this.inspectTimer = 0;
    }
    this.triggerPullTimer = 0.09;
    const rig = this.rigs[id];
    this.muzzleFlashTimer = id === 'sniper' ? 0.095 : id === 'rifle' ? 0.058 : 0.052;
    rig.muzzleFlash.visible = true;
    rig.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
    const fScale = 0.88 + Math.random() * 0.26;
    rig.muzzleFlash.scale.set(fScale, fScale, fScale);
    this.vmMuzzleLight.intensity = id === 'sniper' ? 8.5 : id === 'rifle' ? 5.2 : 4.2;

    const adsScale = this.adsBlend > 0.5 ? 0.58 : 1.0;
    const crouchScale = 1 - this.crouchBlend * 0.3;
    const stability = adsScale * crouchScale;
    this.recoilPosZ = Math.min(0.14, this.recoilPosZ + spec.recoilKickZ * stability);
    this.recoilRotX = Math.min(0.42, this.recoilRotX + spec.recoilPitch * stability);
    this.recoilRotY += (Math.random() - 0.5) * spec.recoilYaw * stability;
    this.recoilRotZ += (Math.random() - 0.5) * spec.recoilYaw * 1.35 * stability;
    this.camRecoilVel += spec.cameraPunch * (this.adsBlend > 0.5 ? 0.68 : 1.0) * crouchScale;
    this.camTrauma = Math.min(1.0, this.camTrauma + (id === 'sniper' ? 0.52 : id === 'rifle' ? 0.18 : 0.24) * crouchScale);

    if (!this.visible) return;
    const muzzleWorld = this.muzzleWorld(worldCam);
    if (id === 'pistol') {
      this.slideKick = 1.0;
      this.spawnShellCasing('pistol', worldCam);
      this.spawnMuzzleSmoke(muzzleWorld, 2, 0.7, worldCam);
    } else if (id === 'rifle') {
      this.rifleDustCoverOpen = true;
      this.rifleBoltKick = 1.0;
      this.spawnShellCasing('rifle', worldCam);
      this.spawnMuzzleSmoke(muzzleWorld, 2, 0.9, worldCam);
    } else {
      this.spawnSniperBrakeBlast(muzzleWorld, worldCam);
      if (ammoLeft > 0) {
        this.animState = 'bolt_cycle';
        this.boltTimer = 0;
        this.boltDuration = spec.boltCycleDuration;
        this.boltStage.clear();
      }
    }
  }

  /** Muzzle socket projected from vmScene into the world (reference vmSocketToWorld). */
  muzzleWorld(worldCam: THREE.PerspectiveCamera, out = new THREE.Vector3()) {
    const rig = this.rigs[this.weaponId];
    const scoped = this.weaponId === 'sniper' && this.adsBlend > 0.68;
    if (scoped) return out.copy(worldCam.position).addScaledVector(worldCam.getWorldDirection(this.tmpV1), 0.9).add(this.tmpV2.set(0, -0.06, 0));
    return this.socketToWorld(rig.muzzleSocket, worldCam, this.weaponId === 'sniper' ? 1.15 : this.weaponId === 'rifle' ? 0.9 : 0.62, out);
  }

  private socketToWorld(socket: THREE.Object3D, worldCam: THREE.PerspectiveCamera, dist?: number, out = new THREE.Vector3()) {
    socket.updateWorldMatrix(true, false);
    const vmPos = new THREE.Vector3();
    socket.getWorldPosition(vmPos);
    const d = dist ?? Math.max(0.28, vmPos.length());
    const ndc = vmPos.clone().project(this.vmCamera);
    const wp = new THREE.Vector3(ndc.x, ndc.y, 0.5).unproject(worldCam);
    const dir = wp.sub(worldCam.position).normalize();
    return out.copy(worldCam.position).addScaledVector(dir, d);
  }

  // --------------------------------------------------------------- per frame
  update(simDt: number, rawDt: number, inp: FpsInput, worldCam: THREE.PerspectiveCamera) {
    this.rawTime += rawDt;
    this.ammo = inp.ammo;
    // mirror the arsenal's equipped slot
    if (inp.slot < 0) {
      if (this.animState !== 'holstered') {
        this.rigs[this.weaponId].root.visible = false;
        this.animState = 'holstered';
      }
    } else if (IDS[inp.slot] !== this.weaponId || this.animState === 'holstered') {
      this.switchWeapon(IDS[inp.slot]);
    }
    const rig = this.rigs[this.weaponId];
    const spec = WEAPON_SPECS[this.weaponId];

    // reload mirrors the arsenal timer
    if (inp.reload > 0 && this.animState !== 'reloading' && this.animState !== 'holstered') {
      this.animState = 'reloading';
      this.reloadStage.clear();
      this.boltTimer = 0;
      this.inspectTimer = 0;
    } else if (inp.reload <= 0 && this.animState === 'reloading') {
      this.animState = 'ready';
      this.rifleDustCoverOpen = false;
    }

    this.sprintBlend = THREE.MathUtils.lerp(this.sprintBlend, inp.sprinting ? 1 : 0, 1 - Math.exp(-8 * rawDt));
    this.crouchBlend = inp.crouch;
    // mouse sway + turn banking (reference: movementX * 0.00055 px → our look radians)
    this.swayX = THREE.MathUtils.clamp(this.swayX - inp.lookX * 0.229, -0.055, 0.055);
    this.swayY = THREE.MathUtils.clamp(this.swayY + inp.lookY * 0.229, -0.042, 0.042);
    this.turnRoll = THREE.MathUtils.clamp(this.turnRoll - inp.lookX * 0.2, -0.085, 0.085);
    this.turnRoll *= Math.exp(-7.5 * rawDt);
    if (inp.landed > 0) {
      this.landJoltVel = -2.2 * inp.landed;
      this.camTrauma = Math.min(1.0, this.camTrauma + 0.22 * inp.landed);
    }
    this.landJoltVel += (-68 * this.landJolt - 11.5 * this.landJoltVel) * rawDt;
    this.landJolt += this.landJoltVel * rawDt;
    this.moveSpeedNorm = THREE.MathUtils.clamp(inp.speed / 6.2, 0, 1.45);
    if (inp.grounded && inp.speed > 0.35) {
      const stepMeters = inp.crouch > 0.5 ? 1.45 : THREE.MathUtils.lerp(1.95, 2.75, this.sprintBlend);
      this.moveBobTime += (inp.speed * rawDt * Math.PI) / stepMeters;
    }
    // camera recoil, trauma decay
    this.camRecoilPitch += this.camRecoilVel;
    this.camRecoilVel *= Math.exp(-24 * rawDt);
    this.camRecoilPitch *= Math.exp(-9.0 * rawDt);
    this.camTrauma = Math.max(0, this.camTrauma - rawDt * 1.6);

    if (this.animState === 'holstered') return;

    if (this.triggerPullTimer > 0) this.triggerPullTimer = Math.max(0, this.triggerPullTimer - simDt);
    if (this.muzzleFlashTimer > 0) {
      this.muzzleFlashTimer -= simDt;
      if (this.muzzleFlashTimer <= 0) {
        rig.muzzleFlash.visible = false;
        this.vmMuzzleLight.intensity = 0;
      }
    }
    if (this.animState === 'equipping') {
      this.equipTimer -= simDt;
      if (this.equipTimer <= 0) this.animState = 'ready';
    }
    if (this.animState === 'inspecting') {
      this.inspectTimer -= simDt;
      if (this.inspectTimer <= 0) this.animState = 'ready';
    }

    const wantAds =
      inp.adsHeld && this.animState !== 'reloading' && this.animState !== 'bolt_cycle' && this.animState !== 'inspecting' && this.animState !== 'equipping';
    const adsRate = this.weaponId === 'sniper' ? 9.5 : 12.0;
    this.adsBlend = THREE.MathUtils.lerp(this.adsBlend, wantAds ? 1 : 0, Math.min(1, rawDt * adsRate));
    if (this.animState === 'ready' || this.animState === 'ads') this.animState = this.adsBlend > 0.55 ? 'ads' : 'ready';

    // FOV: wide bodycam lens + sprint surge, ADS peripheral zoom; vm narrows on ADS
    const baseFov = BODYCAM_BASE_FOV + this.sprintBlend * 7.5;
    const targetFov = THREE.MathUtils.lerp(baseFov, spec.adsFov, this.adsBlend);
    this.worldFov = THREE.MathUtils.lerp(this.worldFov, targetFov, 1 - Math.exp(-12.5 * rawDt));
    const adsVmFov = this.weaponId === 'sniper' ? 46 : 54;
    const targetVmFov = THREE.MathUtils.lerp(BODYCAM_VM_FOV, adsVmFov, this.adsBlend);
    if (Math.abs(this.vmCamera.fov - targetVmFov) > 0.04) {
      this.vmCamera.fov = THREE.MathUtils.lerp(this.vmCamera.fov, targetVmFov, 1 - Math.exp(-13 * rawDt));
      this.vmCamera.updateProjectionMatrix();
    }

    this.resetRigAnimatedParts(rig);

    // 1. recoil recovery & mechanical blowback
    const recDecay = this.weaponId === 'sniper' ? 6.2 : this.weaponId === 'rifle' ? 14.5 : 13.0;
    this.recoilPosZ *= Math.exp(-recDecay * simDt);
    this.recoilRotX *= Math.exp(-recDecay * simDt);
    this.recoilRotY *= Math.exp(-recDecay * 1.1 * simDt);
    this.recoilRotZ *= Math.exp(-recDecay * 1.1 * simDt);
    if (rig.trigger) rig.trigger.rotation.x = this.triggerPullTimer > 0 ? -0.55 : 0;
    if (this.weaponId === 'pistol' && rig.slide && rig.hammer) {
      this.slideKick = Math.max(0, this.slideKick - simDt * 12.5);
      const lockedBack = this.ammo === 0 && this.animState !== 'reloading';
      const slideBack = lockedBack ? 0.92 : Math.sin(this.slideKick * Math.PI);
      rig.slide.position.z = slideBack * 0.064;
      rig.hammer.rotation.x = this.slideKick > 0.72 ? -0.65 : slideBack * 0.42;
    }
    if (this.weaponId === 'rifle' && rig.bolt && rig.dustCover) {
      this.rifleBoltKick = Math.max(0, this.rifleBoltKick - simDt * 18.0);
      rig.bolt.position.z = Math.sin(this.rifleBoltKick * Math.PI) * 0.072;
      rig.dustCover.rotation.z = this.rifleDustCoverOpen ? -2.35 : 0;
    }

    // 2. sniper bolt-action cycle (hand lifts + pulls the bolt, shell ejects on the pull)
    if (this.animState === 'bolt_cycle' && this.weaponId === 'sniper' && rig.bolt && rig.boltHandle) {
      this.boltTimer += simDt;
      const p = THREE.MathUtils.clamp(this.boltTimer / this.boltDuration, 0, 1);
      const stage = (k: string, at: number, fn: () => void) => {
        if (p >= at && !this.boltStage.has(k)) {
          this.boltStage.add(k);
          fn();
        }
      };
      stage('up', 0.06, () => soundEngine.playReloadStep('bolt_up'));
      stage('back', 0.24, () => soundEngine.playReloadStep('bolt_back'));
      stage('eject', 0.43, () => this.visible && this.spawnShellCasing('sniper', worldCam));
      stage('fwd', 0.56, () => soundEngine.playReloadStep('bolt_fwd'));
      stage('down', 0.8, () => soundEngine.playReloadStep('bolt_down'));
      let lift = 0;
      let pull = 0;
      let hand = 0;
      if (p < 0.14) hand = p / 0.14;
      else if (p < 0.26) {
        hand = 1;
        lift = (p - 0.14) / 0.12;
      } else if (p < 0.48) {
        hand = 1;
        lift = 1;
        pull = (p - 0.26) / 0.22;
      } else if (p < 0.72) {
        hand = 1;
        lift = 1;
        pull = 1 - (p - 0.48) / 0.24;
      } else if (p < 0.86) {
        hand = 1;
        lift = 1 - (p - 0.72) / 0.14;
      } else hand = 1 - (p - 0.86) / 0.14;
      rig.boltHandle.rotation.z = lift * 1.08;
      rig.bolt.position.z = -0.02 + pull * 0.112;
      const knobPos = this.tmpV2.set(0.098 - lift * 0.022, 0.012 + lift * 0.052, 0.055 + pull * 0.112);
      const knobRot = new THREE.Euler(0.2, -0.12, -1.05 + lift * 0.38);
      rig.rightArm.position.lerpVectors(rig.rightArmRestPos, knobPos, hand);
      rig.rightArm.rotation.set(
        THREE.MathUtils.lerp(rig.rightArmRestRot.x, knobRot.x, hand),
        THREE.MathUtils.lerp(rig.rightArmRestRot.y, knobRot.y, hand),
        THREE.MathUtils.lerp(rig.rightArmRestRot.z, knobRot.z, hand),
      );
      if (p >= 1) this.animState = 'ready';
    }

    // 3. reload animation (progress from the arsenal)
    if (this.animState === 'reloading') this.animateWeaponReload(rig, THREE.MathUtils.clamp(inp.reload, 0, 1));

    // 4. pose blending
    const poses = WEAPON_POSES[this.weaponId];
    const targetPos = this.tmpV1;
    const targetRot = this.tmpEuler;
    if (this.animState === 'reloading' || this.animState === 'inspecting') {
      targetPos.copy(poses.reload.pos);
      targetRot.copy(poses.reload.rot);
      if (this.animState === 'inspecting') {
        const w = Math.sin(this.rawTime * 1.9);
        targetRot.y += w * 0.14;
        targetRot.z += w * 0.08;
      }
    } else if (this.animState === 'bolt_cycle') {
      targetPos.copy(poses.bolt.pos);
      targetRot.copy(poses.bolt.rot);
    } else {
      const sp = this.sprintBlend * (1 - this.adsBlend);
      const bx = THREE.MathUtils.lerp(poses.ready.pos.x, poses.sprint.pos.x, sp);
      const by = THREE.MathUtils.lerp(poses.ready.pos.y, poses.sprint.pos.y, sp);
      const bz = THREE.MathUtils.lerp(poses.ready.pos.z, poses.sprint.pos.z, sp);
      const rx = THREE.MathUtils.lerp(poses.ready.rot.x, poses.sprint.rot.x, sp);
      const ry = THREE.MathUtils.lerp(poses.ready.rot.y, poses.sprint.rot.y, sp);
      const rz = THREE.MathUtils.lerp(poses.ready.rot.z, poses.sprint.rot.z, sp);
      targetPos.set(
        THREE.MathUtils.lerp(bx, poses.ads.pos.x, this.adsBlend),
        THREE.MathUtils.lerp(by, poses.ads.pos.y, this.adsBlend),
        THREE.MathUtils.lerp(bz, poses.ads.pos.z, this.adsBlend),
      );
      targetRot.set(
        THREE.MathUtils.lerp(rx, poses.ads.rot.x, this.adsBlend),
        THREE.MathUtils.lerp(ry, poses.ads.rot.y, this.adsBlend),
        THREE.MathUtils.lerp(rz, poses.ads.rot.z, this.adsBlend),
      );
    }
    const blendSpeed = this.animState === 'reloading' || this.animState === 'bolt_cycle' ? 9.5 : 14.0;
    const a = 1 - Math.exp(-blendSpeed * rawDt);
    this.curVmPos.lerp(targetPos, a);
    this.curVmRot.x = THREE.MathUtils.lerp(this.curVmRot.x, targetRot.x, a);
    this.curVmRot.y = THREE.MathUtils.lerp(this.curVmRot.y, targetRot.y, a);
    this.curVmRot.z = THREE.MathUtils.lerp(this.curVmRot.z, targetRot.z, a);

    // composed sway, crouch tuck, sprint glide
    const swayScale = 1 - this.adsBlend * 0.88;
    const crouchSteady = 1 - this.crouchBlend * 0.35;
    this.swayX *= Math.exp(-9.5 * rawDt);
    this.swayY *= Math.exp(-9.5 * rawDt);
    const idleX = Math.cos(this.rawTime * 1.45) * 0.0026 * crouchSteady * swayScale;
    const idleY = Math.sin(this.rawTime * 2.15) * 0.003 * crouchSteady * swayScale;
    const sprintFactor = this.sprintBlend * (this.animState === 'reloading' ? 0.2 : 1.0);
    const waveY = (1 - Math.cos(this.moveBobTime * 2)) * 0.5;
    const bobX = Math.sin(this.moveBobTime) * (0.0085 + sprintFactor * 0.015) * this.moveSpeedNorm * crouchSteady * swayScale;
    const bobY = -waveY * (0.008 + sprintFactor * 0.013) * this.moveSpeedNorm * crouchSteady * swayScale;
    const crouchCantZ = -0.055 * this.crouchBlend * swayScale;
    const crouchDropY = -0.008 * this.crouchBlend * swayScale;
    rig.root.position.set(
      this.curVmPos.x + idleX + bobX + this.swayX * 0.52 * swayScale,
      this.curVmPos.y + idleY + bobY + crouchDropY + this.swayY * 0.52 * swayScale + this.landJolt * 0.028,
      this.curVmPos.z + this.recoilPosZ,
    );
    rig.root.rotation.set(
      this.curVmRot.x + this.recoilRotX + this.landJolt * 0.055,
      this.curVmRot.y + this.recoilRotY + this.swayX * 1.0 * swayScale,
      this.curVmRot.z + this.recoilRotZ + crouchCantZ - this.swayX * 1.05 * swayScale - Math.sin(this.moveBobTime) * 0.022 * sprintFactor,
    );
    if (this.vmMuzzleLight.intensity > 0.01) {
      rig.muzzleSocket.updateWorldMatrix(true, false);
      rig.muzzleSocket.getWorldPosition(this.tmpV2);
      this.vmMuzzleLight.position.copy(this.tmpV2);
    }
    // live scope parallax
    if (this.weaponId === 'sniper' && rig.scopeLensUniforms) {
      rig.scopeLensUniforms.uAdsBlend.value = this.adsBlend;
      rig.scopeLensUniforms.uEyeOffset.value.set(THREE.MathUtils.clamp(this.swayX * 1.35, -0.075, 0.075), THREE.MathUtils.clamp(this.swayY * 1.35, -0.075, 0.075));
    }
  }

  private animateWeaponReload(rig: WeaponRig, p: number) {
    const stage = (k: string, at: number, fn: () => void) => {
      if (p >= at && !this.reloadStage.has(k)) {
        this.reloadStage.add(k);
        fn();
      }
    };
    if (rig.id === 'pistol') {
      stage('out', 0.14, () => soundEngine.playReloadStep('mag_out'));
      stage('in', 0.48, () => {
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.06;
      });
      stage('rack', 0.68, () => soundEngine.playReloadStep('rack'));
      if (p < 0.34) {
        const t = THREE.MathUtils.smoothstep(p, 0.0, 0.34);
        rig.mag.position.set(0, rig.magRestPos.y - t * 0.22, rig.magRestPos.z + t * 0.055);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, new THREE.Vector3(-0.06, -0.26, 0.09), t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.85, t);
      } else if (p < 0.58) {
        const t = THREE.MathUtils.smoothstep(p, 0.34, 0.58);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.22, rig.magRestPos.z + (1 - t) * 0.055);
        rig.leftArm.position.lerpVectors(new THREE.Vector3(-0.06, -0.26, 0.09), new THREE.Vector3(-0.032, -0.11, 0.06), t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(1.85, 1.48, t);
      } else if (p < 0.86) {
        const t = (p - 0.58) / 0.28;
        const rack = Math.sin(t * Math.PI);
        if (rig.slide) rig.slide.position.z = rack * 0.062;
        rig.leftArm.position.set(-0.042, 0.062, -0.02 + rack * 0.062);
        rig.leftArm.rotation.set(0.12, -0.2, 0.85);
      } else {
        const t = (p - 0.86) / 0.14;
        rig.leftArm.position.lerpVectors(new THREE.Vector3(-0.042, 0.062, -0.02), rig.leftArmRestPos, t);
        rig.leftArm.rotation.set(
          THREE.MathUtils.lerp(0.12, rig.leftArmRestRot.x, t),
          THREE.MathUtils.lerp(-0.2, rig.leftArmRestRot.y, t),
          THREE.MathUtils.lerp(0.85, rig.leftArmRestRot.z, t),
        );
      }
    } else if (rig.id === 'rifle') {
      stage('out', 0.22, () => soundEngine.playReloadStep('mag_out'));
      stage('in', 0.62, () => {
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.055;
      });
      stage('rack', 0.74, () => soundEngine.playReloadStep('rack'));
      const magGripHand = new THREE.Vector3(-0.048, -0.16, -0.095);
      const magOutHand = new THREE.Vector3(-0.11, -0.36, -0.06);
      const chargeHand = new THREE.Vector3(-0.055, 0.065, 0.095);
      if (p < 0.2) {
        const t = THREE.MathUtils.smoothstep(p, 0, 0.2);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, magGripHand, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.52, t);
      } else if (p < 0.44) {
        const t = THREE.MathUtils.smoothstep(p, 0.2, 0.44);
        rig.mag.position.set(0, rig.magRestPos.y - t * 0.25, rig.magRestPos.z + t * 0.03);
        rig.mag.rotation.x = t * 0.22;
        rig.leftArm.position.lerpVectors(magGripHand, magOutHand, t);
        rig.leftArm.rotation.z = 1.52;
      } else if (p < 0.68) {
        const t = THREE.MathUtils.smoothstep(p, 0.44, 0.68);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.25, rig.magRestPos.z + (1 - t) * 0.03);
        rig.mag.rotation.x = (1 - t) * 0.22;
        rig.leftArm.position.lerpVectors(magOutHand, magGripHand, t);
        rig.leftArm.rotation.z = 1.52;
      } else if (p < 0.9) {
        const t = (p - 0.68) / 0.22;
        const pull = Math.sin(t * Math.PI);
        if (rig.chargingHandle) rig.chargingHandle.position.z = 0.095 + pull * 0.072;
        if (rig.bolt) rig.bolt.position.z = pull * 0.072;
        rig.leftArm.position.set(chargeHand.x, chargeHand.y, chargeHand.z + pull * 0.072);
        rig.leftArm.rotation.set(0.12, -0.18, 1.15);
      } else {
        const t = (p - 0.9) / 0.1;
        rig.leftArm.position.lerpVectors(chargeHand, rig.leftArmRestPos, t);
        rig.leftArm.rotation.set(
          THREE.MathUtils.lerp(0.12, rig.leftArmRestRot.x, t),
          THREE.MathUtils.lerp(-0.18, rig.leftArmRestRot.y, t),
          THREE.MathUtils.lerp(1.15, rig.leftArmRestRot.z, t),
        );
      }
    } else {
      stage('out', 0.16, () => soundEngine.playReloadStep('mag_out'));
      stage('in', 0.44, () => {
        soundEngine.playReloadStep('mag_in');
        this.recoilRotX += 0.06;
      });
      stage('bback', 0.62, () => soundEngine.playReloadStep('bolt_back'));
      stage('bfwd', 0.78, () => soundEngine.playReloadStep('bolt_fwd'));
      stage('bdown', 0.88, () => soundEngine.playReloadStep('bolt_down'));
      const magHandIn = new THREE.Vector3(-0.045, -0.14, -0.095);
      const magHandOut = new THREE.Vector3(-0.095, -0.34, -0.065);
      if (p < 0.28) {
        const t = THREE.MathUtils.smoothstep(p, 0.0, 0.28);
        const magT = THREE.MathUtils.smoothstep(p, 0.1, 0.28);
        rig.mag.position.set(0, rig.magRestPos.y - magT * 0.22, rig.magRestPos.z);
        rig.leftArm.position.lerpVectors(rig.leftArmRestPos, magHandOut, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(rig.leftArmRestRot.z, 1.55, t);
      } else if (p < 0.52) {
        const t = THREE.MathUtils.smoothstep(p, 0.28, 0.52);
        rig.mag.position.set(0, rig.magRestPos.y - (1 - t) * 0.22, rig.magRestPos.z);
        rig.leftArm.position.lerpVectors(magHandOut, magHandIn, t);
        rig.leftArm.rotation.z = 1.55;
      } else if (p < 0.62) {
        const t = (p - 0.52) / 0.1;
        rig.leftArm.position.lerpVectors(magHandIn, rig.leftArmRestPos, t);
        rig.leftArm.rotation.z = THREE.MathUtils.lerp(1.55, rig.leftArmRestRot.z, t);
      }
      if (p >= 0.55 && rig.bolt && rig.boltHandle) {
        const bp = THREE.MathUtils.clamp((p - 0.55) / 0.4, 0, 1);
        const lift = bp < 0.2 ? bp / 0.2 : bp < 0.8 ? 1 : (1 - bp) / 0.2;
        const pull = bp < 0.2 ? 0 : bp < 0.5 ? (bp - 0.2) / 0.3 : bp < 0.8 ? 1 - (bp - 0.5) / 0.3 : 0;
        const hb = bp < 0.12 ? bp / 0.12 : bp > 0.88 ? (1 - bp) / 0.12 : 1;
        rig.boltHandle.rotation.z = lift * 1.08;
        rig.bolt.position.z = -0.02 + pull * 0.11;
        const knobPos = new THREE.Vector3(0.098 - lift * 0.022, 0.012 + lift * 0.052, 0.055 + pull * 0.11);
        rig.rightArm.position.lerpVectors(rig.rightArmRestPos, knobPos, hb);
        rig.rightArm.rotation.z = THREE.MathUtils.lerp(rig.rightArmRestRot.z, -0.95 + lift * 0.3, hb);
      }
    }
  }

  // ---------------------------------------------------------- bodycam camera
  /** Reference chest bodycam: breathing, C∞ stride glide, trauma punch, recoil pitch, landing spring, roll. */
  applyCamera(cam: THREE.PerspectiveCamera, footX: number, footY: number, footZ: number, aimYaw: number, aimPitch: number, horizSpeed: number, grounded: boolean, strafe: number, extraTrauma: number, dt: number) {
    const t = this.rawTime;
    const adsDamp = THREE.MathUtils.lerp(1.0, 0.16, this.adsBlend);
    const shakeFactor = THREE.MathUtils.lerp(0.24, 1.0, CAMERA_SHAKE);
    const moveWeight = grounded ? THREE.MathUtils.clamp(horizSpeed / 5.2, 0, 1.15) : 0.08;
    const targetH = THREE.MathUtils.lerp(CHEST_CAMERA_HEIGHT, CROUCH_CAMERA_HEIGHT, this.crouchBlend);
    this.smoothCamHeight = THREE.MathUtils.lerp(this.smoothCamHeight, targetH, 1 - Math.exp(-10 * dt));
    const breathAmp = (1 - this.crouchBlend * 0.3) * adsDamp * shakeFactor;
    const breathPitch = (Math.sin(t * 1.55) * 0.0028 + Math.cos(t * 2.4) * 0.0012) * breathAmp;
    const breathYaw = (Math.cos(t * 1.15) * 0.0024 + Math.sin(t * 1.9) * 0.001) * breathAmp;
    const breathRoll = Math.sin(t * 1.32) * Math.cos(t * 0.85) * 0.0052 * breathAmp;
    const smoothWaveY = (1 - Math.cos(this.moveBobTime * 2)) * 0.5;
    const rawBobY = -smoothWaveY * THREE.MathUtils.lerp(0.011, 0.022 + CAMERA_SHAKE * 0.042, this.sprintBlend) * moveWeight * adsDamp;
    const rawBobX = Math.sin(this.moveBobTime) * THREE.MathUtils.lerp(0.007, 0.015 + CAMERA_SHAKE * 0.026, this.sprintBlend) * moveWeight * adsDamp;
    const rawBobPitch =
      Math.sin(this.moveBobTime * 2 - 0.5) * THREE.MathUtils.lerp(0.0018, 0.0048 + CAMERA_SHAKE * 0.018, this.sprintBlend) * moveWeight * adsDamp - this.sprintBlend * 0.01;
    const k = 1 - Math.exp(-14.5 * dt);
    this.smoothCamBobX = THREE.MathUtils.lerp(this.smoothCamBobX, rawBobX, k);
    this.smoothCamBobY = THREE.MathUtils.lerp(this.smoothCamBobY, rawBobY, k);
    this.smoothCamPitch = THREE.MathUtils.lerp(this.smoothCamPitch, rawBobPitch, k);
    const strideRoll = Math.sin(this.moveBobTime) * THREE.MathUtils.lerp(0.0035, 0.0085 + CAMERA_SHAKE * 0.032, this.sprintBlend) * moveWeight * adsDamp;
    const strafeLean = -THREE.MathUtils.clamp(strafe, -1, 1) * 0.014 * adsDamp;
    const targetRoll = breathRoll + strideRoll + strafeLean + this.turnRoll * (0.45 + CAMERA_SHAKE * 0.55) * adsDamp;
    this.smoothRollZ = THREE.MathUtils.lerp(this.smoothRollZ, targetRoll, 1 - Math.exp(-11.5 * dt));
    const trauma = Math.min(1, this.camTrauma + extraTrauma);
    const tq = trauma * trauma * (0.45 + CAMERA_SHAKE * 0.55);
    const yaw = aimYaw + Math.PI; // our yaw → three.js camera yaw
    cam.position.set(
      footX + Math.cos(yaw) * this.smoothCamBobX,
      footY + this.smoothCamHeight + this.smoothCamBobY + this.landJolt * 0.065,
      footZ - Math.sin(yaw) * this.smoothCamBobX,
    );
    cam.rotation.order = 'YXZ';
    cam.rotation.y = yaw + breathYaw + Math.cos(t * 42.0) * 0.018 * tq;
    cam.rotation.x = THREE.MathUtils.clamp(aimPitch + this.camRecoilPitch + breathPitch + this.smoothCamPitch + Math.sin(t * 48.0) * 0.024 * tq + this.landJolt * 0.055, -1.38, 1.38);
    cam.rotation.z = this.smoothRollZ + Math.sin(t * 54.0) * 0.034 * tq;
    if (Math.abs(cam.fov - this.worldFov) > 0.01) {
      cam.fov = this.worldFov;
      cam.updateProjectionMatrix();
    }
    cam.updateMatrixWorld();
  }

  /** Live picture-in-picture magnifier for the sniper glass (only while it is visible). */
  renderScope(renderer: THREE.WebGLRenderer, scene: THREE.Scene, cam: THREE.PerspectiveCamera) {
    if (!this.visible || this.weaponId !== 'sniper' || this.adsBlend <= 0.04) return;
    this.scopeCam.position.copy(cam.position);
    this.scopeCam.rotation.order = 'YXZ';
    this.scopeCam.rotation.set(cam.rotation.x, cam.rotation.y, 0);
    this.scopeCam.updateMatrixWorld();
    const prevLayers = this.scopeCam.layers.mask;
    renderer.setRenderTarget(this.scopeRT);
    renderer.setClearColor(0xa6daf7, 1);
    renderer.clear(true, true, true);
    renderer.render(scene, this.scopeCam);
    renderer.setRenderTarget(null);
    this.scopeCam.layers.mask = prevLayers;
  }

  render(renderer: THREE.WebGLRenderer) {
    if (!this.visible || this.animState === 'holstered') return;
    const ac = renderer.autoClear;
    renderer.autoClear = false;
    renderer.clearDepth();
    renderer.render(this.vmScene, this.vmCamera);
    renderer.autoClear = ac;
  }

  // ------------------------------------------------------------- world FX
  private acquireSmokeMat() {
    let m: THREE.Material;
    if (this.matPool.length < 56) {
      m = this.smokeMat.clone();
      this.matPool.push(m);
    } else {
      m = this.matPool[this.matPoolI++ % this.matPool.length];
      m.opacity = this.smokeMat.opacity;
    }
    return m;
  }

  private spawnShellCasing(weapon: WeaponId, worldCam: THREE.PerspectiveCamera) {
    const rig = this.rigs[weapon];
    const startPos = this.socketToWorld(rig.ejectionSocket, worldCam, weapon === 'pistol' ? 0.44 : 0.48);
    const mesh = new THREE.Mesh(this.shellGeos[weapon], this.brassMat);
    mesh.position.copy(startPos);
    mesh.quaternion.copy(worldCam.quaternion);
    mesh.rotateZ(Math.PI / 2);
    mesh.castShadow = true;
    this.worldScene.add(mesh);
    const v = new THREE.Vector3();
    if (weapon === 'pistol') v.set(1.55 + Math.random() * 0.55, 1.85 + Math.random() * 0.55, 0.35 + Math.random() * 0.3);
    else if (weapon === 'rifle') v.set(2.35 + Math.random() * 0.65, 1.35 + Math.random() * 0.45, 0.2 + Math.random() * 0.35);
    else v.set(1.65 + Math.random() * 0.45, 1.45 + Math.random() * 0.35, 0.45 + Math.random() * 0.25);
    v.applyQuaternion(worldCam.quaternion).add(this.camVel);
    this.shells.push({
      mesh,
      vel: v,
      angVel: new THREE.Vector3((Math.random() - 0.5) * 26, (Math.random() - 0.5) * 26, -18 - Math.random() * 14),
      age: 0,
      maxAge: 6.5,
      bounces: 0,
      weapon,
    });
    if (this.shells.length > 40) {
      const s = this.shells.shift()!;
      this.worldScene.remove(s.mesh);
    }
  }

  /** Reference speed tracer (+ sniper vapour contrail). */
  spawnTracer(start: THREE.Vector3, end: THREE.Vector3, slot: number) {
    const id = IDS[slot] ?? 'rifle';
    const dir = end.clone().sub(start);
    const distTotal = dir.length();
    if (distTotal < 0.2) return;
    dir.normalize();
    const mesh = new THREE.Mesh(this.tracerGeo[id], this.tracerMat[id]);
    mesh.position.copy(start);
    mesh.lookAt(end);
    this.worldScene.add(mesh);
    this.tracers.push({ mesh, start: start.clone(), dir, distTotal, distTraveled: 0, speed: WEAPON_SPECS[id].muzzleVelocity });
    if (id === 'sniper') {
      const len = Math.min(distTotal, 280);
      if (len < 1) return;
      const mid = start.clone().addScaledVector(dir, len * 0.5);
      const geo = new THREE.CylinderGeometry(0.016, 0.028, len, 5);
      geo.rotateX(Math.PI / 2);
      const c = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42, depthWrite: false }));
      c.position.copy(mid);
      c.lookAt(end);
      this.worldScene.add(c);
      this.contrails.push({ mesh: c, age: 0, maxAge: 0.95 });
    }
  }

  spawnMuzzleSmoke(pos: THREE.Vector3, count: number, scale: number, worldCam: THREE.PerspectiveCamera) {
    const forward = worldCam.getWorldDirection(new THREE.Vector3());
    for (let i = 0; i < count; i++) {
      const m = new THREE.Mesh(this.smokeGeo, this.acquireSmokeMat());
      m.position.copy(pos);
      this.worldScene.add(m);
      const vel = forward
        .clone()
        .multiplyScalar(1.4 + Math.random() * 1.4)
        .add(new THREE.Vector3((Math.random() - 0.5) * 0.7, 0.65 + Math.random() * 0.55, (Math.random() - 0.5) * 0.7));
      this.particles.push({
        mesh: m,
        vel,
        angVel: new THREE.Vector3(Math.random() * 2, Math.random() * 2, Math.random() * 2),
        gravity: -0.35,
        age: 0,
        maxAge: 0.55 + Math.random() * 0.3,
        startScale: 0.35 * scale,
        endScale: 1.85 * scale,
      });
    }
  }

  spawnSniperBrakeBlast(pos: THREE.Vector3, worldCam: THREE.PerspectiveCamera) {
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(worldCam.quaternion);
    const forward = worldCam.getWorldDirection(new THREE.Vector3());
    for (const side of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const m = new THREE.Mesh(this.smokeGeo, this.acquireSmokeMat());
        m.position.copy(pos);
        this.worldScene.add(m);
        const vel = right
          .clone()
          .multiplyScalar(side * (3.2 + i * 1.1))
          .addScaledVector(forward, -0.4 + Math.random() * 0.6)
          .add(new THREE.Vector3(0, 0.35 + Math.random() * 0.4, 0));
        this.particles.push({ mesh: m, vel, angVel: new THREE.Vector3(3, 3, 3), gravity: -0.25, age: 0, maxAge: 0.75 + Math.random() * 0.3, startScale: 0.5, endScale: 2.5 });
      }
    }
    this.spawnMuzzleSmoke(pos, 3, 1.3, worldCam);
  }

  updateFx(dt: number) {
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const s = this.shells[i];
      s.age += dt;
      if (s.age >= s.maxAge) {
        this.worldScene.remove(s.mesh);
        this.shells.splice(i, 1);
        continue;
      }
      s.vel.y -= 9.8 * dt;
      s.mesh.position.addScaledVector(s.vel, dt);
      s.mesh.rotation.x += s.angVel.x * dt;
      s.mesh.rotation.y += s.angVel.y * dt;
      s.mesh.rotation.z += s.angVel.z * dt;
      const floorY = this.terrain.height(s.mesh.position.x, s.mesh.position.z) + 0.01;
      if (s.mesh.position.y < floorY) {
        s.mesh.position.y = floorY;
        if (Math.abs(s.vel.y) > 0.65 && s.bounces < 3) {
          s.vel.y = -s.vel.y * 0.42;
          s.vel.x *= 0.58;
          s.vel.z *= 0.58;
          s.angVel.multiplyScalar(0.55);
          s.bounces++;
          if (s.bounces === 1) soundEngine.playShellBounce(s.weapon);
        } else {
          s.vel.set(0, 0, 0);
          s.angVel.set(0, 0, 0);
        }
      }
      if (s.age > s.maxAge - 0.8) s.mesh.scale.setScalar(Math.max(0.01, (s.maxAge - s.age) / 0.8));
    }
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const tr = this.tracers[i];
      tr.distTraveled += tr.speed * dt;
      if (tr.distTraveled >= tr.distTotal) {
        this.worldScene.remove(tr.mesh);
        this.tracers.splice(i, 1);
        continue;
      }
      tr.mesh.position.copy(tr.start).addScaledVector(tr.dir, tr.distTraveled);
    }
    for (let i = this.contrails.length - 1; i >= 0; i--) {
      const c = this.contrails[i];
      c.age += dt;
      if (c.age >= c.maxAge) {
        this.worldScene.remove(c.mesh);
        c.mesh.geometry.dispose();
        (c.mesh.material as THREE.Material).dispose();
        this.contrails.splice(i, 1);
        continue;
      }
      (c.mesh.material as THREE.MeshBasicMaterial).opacity = 0.42 * (1 - c.age / c.maxAge);
    }
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;
      if (p.age >= p.maxAge) {
        this.worldScene.remove(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      const t = p.age / p.maxAge;
      p.vel.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      p.mesh.rotation.x += p.angVel.x * dt;
      p.mesh.rotation.y += p.angVel.y * dt;
      p.mesh.rotation.z += p.angVel.z * dt;
      p.mesh.scale.setScalar(THREE.MathUtils.lerp(p.startScale, p.endScale, t));
      (p.mesh.material as THREE.MeshStandardMaterial).opacity = 0.58 * (1 - t);
    }
  }
}

/**
 * Third-person copies of the same reference weapons (no arms), converted to the
 * body-IK convention: origin at the pistol grip, +Z down the barrel.
 */
export function buildThirdPersonWeapons() {
  const rigs = buildAllWeaponRigs();
  return IDS.map((id) => {
    const rig = rigs[id];
    rig.leftArm.removeFromParent();
    rig.rightArm.removeFromParent();
    rig.mag.name = 'mag';
    rig.muzzleFlash.name = 'flash';
    rig.muzzleFlash.visible = false;
    rig.root.position.set(0, 0, 0);
    rig.root.rotation.set(0, 0, 0);
    rig.root.updateMatrixWorld(true);
    const grip = rig.rightArmRestPos.clone().applyMatrix4(rig.weaponBody.matrixWorld);
    const muzzle = new THREE.Vector3();
    rig.muzzleSocket.getWorldPosition(muzzle);
    const outer = new THREE.Group();
    const inner = new THREE.Group();
    inner.rotation.y = Math.PI; // reference barrels point down -Z
    inner.position.set(grip.x, -grip.y, grip.z);
    inner.add(rig.root);
    outer.add(inner);
    outer.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) o.castShadow = true;
    });
    const m = new THREE.Vector3(-muzzle.x + grip.x, muzzle.y - grip.y, -muzzle.z + grip.z);
    const left = rig.leftArmRestPos.clone().applyMatrix4(rig.weaponBody.matrixWorld);
    const l = new THREE.Vector3(-left.x + grip.x, left.y - grip.y, -left.z + grip.z);
    return { obj: outer, muzzle: m, left: l, grip, flash: rig.muzzleFlash };
  });
}
