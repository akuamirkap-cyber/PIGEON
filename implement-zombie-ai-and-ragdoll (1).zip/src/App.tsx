import { useEffect, useMemo, useRef, useState } from 'react';
import { Game, Hud } from './game/Game';
import { STATES, LocoState } from './game/controller';
import { AI_STATES } from './game/zombie/zombies';

const GROUPS: { title: string; items: LocoState[] }[] = [
  { title: 'Locomotion', items: ['IDLE', 'WALK', 'JOG', 'RUN', 'SPRINT', 'STOP', 'RECOVERY'] },
  { title: 'Turning', items: ['TURN_LEFT', 'TURN_RIGHT'] },
  { title: 'Crouch', items: ['CROUCH_IDLE', 'CROUCH_WALK', 'CROUCH_TURN'] },
  { title: 'Jump', items: ['JUMP_START', 'JUMP_AIR', 'JUMP_LAND'] },
];
const SPEED_MAX = 8.5;
const TICKS = [
  { v: 1.5, l: 'WALK' },
  { v: 3.2, l: 'JOG' },
  { v: 4.8, l: 'RUN' },
  { v: 7.9, l: 'SPRINT' },
];

const panel = 'rounded-lg border border-white/10 bg-slate-950/55 backdrop-blur-md shadow-xl shadow-black/20';
const label = 'font-mono text-[10px] uppercase tracking-[0.18em] text-white/45';

function Key({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="inline-flex min-w-[22px] items-center justify-center rounded border border-white/20 bg-white/10 px-1.5 py-0.5 font-mono text-[10px] font-semibold leading-none text-white/90">
      {children}
    </kbd>
  );
}

function Row({ keys, text, on }: { keys: string[]; text: string; on?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className={`text-[12px] ${on ? 'text-amber-300' : 'text-white/70'}`}>{text}</span>
      <span className="flex gap-1">
        {keys.map((k) => (
          <Key key={k}>{k}</Key>
        ))}
      </span>
    </div>
  );
}

function StatePanel({ hud }: { hud: Hud }) {
  return (
    <div className={`${panel} w-[212px] p-3`}>
      <div className="mb-2 flex items-center justify-between">
        <span className={label}>State machine</span>
        <span className="font-mono text-[10px] text-white/35">blend</span>
      </div>
      <div className="space-y-2.5">
        {GROUPS.map((g) => (
          <div key={g.title}>
            <div className="mb-1 font-mono text-[9px] uppercase tracking-[0.2em] text-white/30">{g.title}</div>
            <div className="space-y-[3px]">
              {g.items.map((s) => {
                const w = hud.weights[STATES.indexOf(s)] ?? 0;
                const active = hud.state === s;
                return (
                  <div key={s} className="flex items-center gap-2">
                    <span
                      className={`w-[92px] font-mono text-[10px] tracking-wider ${active ? 'text-amber-300' : w > 0.05 ? 'text-white/70' : 'text-white/35'}`}
                    >
                      {s}
                    </span>
                    <div className="h-[5px] flex-1 overflow-hidden rounded-full bg-white/10">
                      <div
                        className={`h-full rounded-full ${active ? 'bg-amber-400' : 'bg-sky-300/70'}`}
                        style={{ width: `${Math.round(w * 100)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SpeedBlock({ hud }: { hud: Hud }) {
  const pct = Math.min(1, hud.speed / SPEED_MAX) * 100;
  return (
    <div className={`${panel} w-[212px] p-3 sm:w-[300px]`}>
      <div className="flex items-end justify-between">
        <div>
          <div className={label}>Active state</div>
          <div className="font-display text-[30px] font-bold leading-none tracking-wide text-white">
            {hud.state.replace('_', ' ')}
          </div>
        </div>
        <div className="text-right">
          <div className="font-mono text-[22px] font-semibold leading-none text-amber-300 tabular-nums">
            {hud.speed.toFixed(1)}
          </div>
          <div className={label}>m/s</div>
        </div>
      </div>
      <div className="relative mt-3 h-[6px] rounded-full bg-white/10">
        <div
          className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-sky-300 via-amber-300 to-orange-500"
          style={{ width: `${pct}%` }}
        />
        {TICKS.map((t) => (
          <div key={t.l} className="absolute -top-[3px] h-3 w-px bg-white/40" style={{ left: `${(t.v / SPEED_MAX) * 100}%` }} />
        ))}
      </div>
      <div className="relative mt-1 hidden h-3 sm:block">
        {TICKS.map((t) => (
          <span
            key={t.l}
            className="absolute -translate-x-1/2 font-mono text-[8px] tracking-widest text-white/40"
            style={{ left: `${(t.v / SPEED_MAX) * 100}%` }}
          >
            {t.l}
          </span>
        ))}
      </div>
    </div>
  );
}

function GaitStrip({ hud }: { hud: Hud }) {
  const foot = (name: string, c: number) => (
    <div className="flex items-center gap-1.5">
      <span className="font-mono text-[10px] text-white/50">{name}</span>
      <div
        className="h-3 w-8 rounded-sm border border-white/20"
        style={{ background: `rgba(125,255,170,${0.12 + c * 0.8})`, boxShadow: c > 0.6 ? '0 0 10px rgba(125,255,170,.5)' : 'none' }}
      />
    </div>
  );
  const stat = (k: string, v: string) => (
    <div className="hidden items-baseline gap-1.5 sm:flex">
      <span className={label}>{k}</span>
      <span className="w-[44px] font-mono text-[11px] text-white/85 tabular-nums">{v}</span>
    </div>
  );
  return (
    <div className={`${panel} flex items-center gap-4 px-3 py-2`}>
      <span className={`${label} hidden md:inline`}>Foot contact</span>
      {foot('L', hud.contactL)}
      {foot('R', hud.contactR)}
      <div className="hidden h-4 w-px bg-white/15 sm:block" />
      {stat('Cadence', `${Math.round(hud.cadence)}`)}
      {stat('Lean', `${((hud.lean * 180) / Math.PI).toFixed(0)}°`)}
      {stat('Bank', `${((hud.bank * 180) / Math.PI).toFixed(0)}°`)}
      <div className="hidden items-center gap-1.5 md:flex">
        <span className={label}>Cycle</span>
        <div className="relative h-[5px] w-24 rounded-full bg-white/10">
          <div className="absolute top-1/2 h-2.5 w-[3px] -translate-y-1/2 rounded bg-amber-300" style={{ left: `${hud.phase * 100}%` }} />
        </div>
      </div>
    </div>
  );
}

function Legend({ hud }: { hud: Hud }) {
  return (
    <div className={`${panel} w-[236px] space-y-[5px] p-3`}>
      <div className={`${label} mb-1.5`}>Controls</div>
      <Row keys={['W', 'A', 'S', 'D']} text="Move" />
      <Row keys={['Shift']} text="Sprint" on={hud.sprinting} />
      <Row keys={['Space']} text="Jump" on={!hud.grounded} />
      <Row keys={['C']} text="Crouch" on={hud.crouching} />
      <Row keys={['X', 'Wheel']} text={`Pace · ${hud.pace}`} />
      <div className="!my-1.5 h-px bg-white/10" />
      <Row keys={['1', '2', '3']} text="1911 / M4A1 / M24" on={hud.armed} />
      <Row keys={['4']} text="Holster" />
      <Row keys={['LMB']} text="Fire" />
      <Row keys={['RMB']} text={hud.armed ? 'Aim down sights' : 'Strafe stance'} on={hud.ads || hud.strafing} />
      <Row keys={['R']} text="Reload" on={hud.reload > 0} />
      <Row keys={['F']} text="Inspect weapon (FPS)" />
      <Row keys={['N']} text={`FPS cam · ${hud.fpsCam}`} on={hud.fpsCam === 'BODYCAM'} />
      <Row keys={['V']} text={`Camera · ${hud.firstPerson ? 'FPS' : 'TPS'}`} on={hud.firstPerson} />
      <div className="!my-1.5 h-px bg-white/10" />
      <Row keys={['K']} text="Aggressive mode" on={hud.aggressive} />
      <Row keys={['T']} text="Slow motion" on={hud.slowmo} />
      <Row keys={['G', 'M', 'P']} text="IK debug / mute / restart" on={hud.debug} />
    </div>
  );
}

const SLOT_NAMES = ['PISTOL', 'RIFLE', 'SNIPER'];

function WeaponPanel({ hud }: { hud: Hud }) {
  const low = hud.armed && hud.ammo <= Math.max(1, Math.floor(hud.mag * 0.25));
  return (
    <div className={`${panel} w-[196px] p-3`}>
      <div className="flex items-center justify-between">
        <span className={label}>Weapon</span>
        <span className="font-mono text-[10px] tracking-widest text-white/45">{hud.fireMode}</span>
      </div>
      <div className="mt-1 flex items-end justify-between">
        <div className="font-display text-[24px] font-bold leading-none tracking-wide text-white">{hud.weapon}</div>
        {hud.armed && (
          <div className="font-mono leading-none tabular-nums">
            <span className={`text-[24px] font-semibold ${low ? 'text-red-400' : 'text-amber-300'}`}>{hud.ammo}</span>
            <span className="text-[12px] text-white/45"> / {hud.mag}</span>
          </div>
        )}
      </div>
      <div className="mt-2 h-[3px] overflow-hidden rounded-full bg-white/10">
        <div
          className={`h-full ${hud.reload > 0 ? 'bg-sky-300' : low ? 'bg-red-400' : 'bg-amber-400'}`}
          style={{ width: `${(hud.reload > 0 ? hud.reload : hud.armed ? hud.ammo / hud.mag : 0) * 100}%` }}
        />
      </div>
      <div className="mt-2.5 grid grid-cols-3 gap-1.5">
        {SLOT_NAMES.map((n, i) => (
          <div
            key={n}
            className={`rounded border px-1 py-1 text-center ${hud.slot === i ? 'border-amber-300/70 bg-amber-400/20' : 'border-white/10 bg-white/5'}`}
          >
            <div className="font-mono text-[9px] text-white/40">{i + 1}</div>
            <div className={`font-mono text-[9px] tracking-wider ${hud.slot === i ? 'text-amber-200' : 'text-white/60'}`}>{n}</div>
            <div className="font-mono text-[9px] text-white/35 tabular-nums">{hud.ammoAll[i]}</div>
          </div>
        ))}
      </div>
      <div className="mt-2.5 flex items-center justify-between font-mono text-[10px] text-white/55">
        <span>
          HITS <span className="text-white/90 tabular-nums">{hud.hits}</span>
          <span className="text-white/35"> / {hud.shots}</span>
        </span>
        <span>
          LAST <span className="text-white/90 tabular-nums">{hud.lastDist > 0 ? `${hud.lastDist.toFixed(0)} m` : '—'}</span>
        </span>
      </div>
    </div>
  );
}

function Crosshair({ hud }: { hud: Hud }) {
  if (hud.scope > 0.5) return null;
  const hit = hud.hitAge < 0.2;
  const kill = hud.killAge < 0.35;
  if (!hud.armed) {
    return <div className="absolute left-1/2 top-1/2 h-1 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/50" />;
  }
  const gap = 5 + Math.min(60, hud.spread * 900);
  const tick = 'absolute bg-white shadow-[0_0_2px_rgba(0,0,0,.9)]';
  return (
    <div className="absolute left-1/2 top-1/2">
      <div className="absolute h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-[0_0_2px_rgba(0,0,0,.9)]" />
      {!hud.ads && (
        <>
          <div className={`${tick} h-[2px] w-[9px] -translate-y-1/2`} style={{ left: gap }} />
          <div className={`${tick} h-[2px] w-[9px] -translate-y-1/2`} style={{ right: gap }} />
          <div className={`${tick} h-[9px] w-[2px] -translate-x-1/2`} style={{ top: gap }} />
          <div className={`${tick} h-[9px] w-[2px] -translate-x-1/2`} style={{ bottom: gap }} />
        </>
      )}
      {hit && (
        <div className="absolute -translate-x-1/2 -translate-y-1/2">
          {[45, 135, 225, 315].map((r) => (
            <div
              key={r}
              className={`absolute left-0 top-0 h-[2px] w-[10px] origin-left ${kill ? 'bg-red-500 shadow-[0_0_6px_rgba(255,0,0,.9)]' : 'bg-amber-300 shadow-[0_0_4px_rgba(251,191,36,.9)]'}`}
              style={{ transform: `rotate(${r}deg) translateX(7px)` }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ScopeOverlay({ hud }: { hud: Hud }) {
  if (hud.scope < 0.5) return null;
  const hit = hud.hitAge < 0.2;
  return (
    <div className="absolute inset-0">
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at center, transparent 0, transparent 39vmin, rgba(0,0,0,.55) 40vmin, #000 41.5vmin)',
        }}
      />
      <div className="absolute left-1/2 top-1/2 h-px w-[80vmin] -translate-x-1/2 bg-black/80" />
      <div className="absolute left-1/2 top-1/2 h-[80vmin] w-px -translate-y-1/2 bg-black/80" />
      {[6, 12, 18].map((d) => (
        <div key={d} className="absolute left-1/2 top-1/2 h-px w-3 -translate-x-1/2 bg-black/80" style={{ marginTop: `${d}vmin` }} />
      ))}
      <div
        className={`absolute left-1/2 top-1/2 h-[5px] w-[5px] -translate-x-1/2 -translate-y-1/2 rounded-full ${hit ? 'bg-amber-300 shadow-[0_0_10px_rgba(251,191,36,1)]' : 'bg-red-500'}`}
      />
      <div className="absolute bottom-[12vmin] left-1/2 -translate-x-1/2 font-mono text-[11px] tracking-[0.3em] text-white/70">
        {hud.ammo} / {hud.mag}
        {hud.lastDist > 0 && <span className="ml-4 text-amber-200/80">{hud.lastDist.toFixed(0)} M</span>}
      </div>
    </div>
  );
}

function TouchControls({ game }: { game: Game }) {
  const stick = useRef<{ id: number; x: number; y: number } | null>(null);
  const lookId = useRef<{ id: number; x: number; y: number } | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0, on: false });
  const [sprint, setSprint] = useState(false);
  const [aim, setAim] = useState(false);
  const R = 52;

  const btn =
    'pointer-events-auto flex h-12 w-12 items-center justify-center rounded-full border border-white/25 bg-slate-950/50 font-mono text-[9px] font-semibold tracking-wider text-white/90 backdrop-blur active:bg-amber-400/40';
  return (
    <>
      {/* look zone */}
      <div
        className="pointer-events-auto absolute inset-y-0 right-0 w-1/2 touch-none"
        onPointerDown={(e) => {
          lookId.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
          e.currentTarget.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          const l = lookId.current;
          if (!l || l.id !== e.pointerId) return;
          game.input.addLook((e.clientX - l.x) * 0.006, (e.clientY - l.y) * 0.005);
          l.x = e.clientX;
          l.y = e.clientY;
        }}
        onPointerUp={() => (lookId.current = null)}
        onPointerCancel={() => (lookId.current = null)}
      />
      {/* move stick */}
      <div
        className="pointer-events-auto absolute bottom-0 left-0 h-[55%] w-1/2 touch-none"
        onPointerDown={(e) => {
          stick.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
          e.currentTarget.setPointerCapture(e.pointerId);
          setKnob({ x: 0, y: 0, on: true });
          game.input.onEngage();
        }}
        onPointerMove={(e) => {
          const s = stick.current;
          if (!s || s.id !== e.pointerId) return;
          let dx = (e.clientX - s.x) / R;
          let dy = (e.clientY - s.y) / R;
          const m = Math.hypot(dx, dy);
          if (m > 1) {
            dx /= m;
            dy /= m;
          }
          game.input.touchMove.x = dx;
          game.input.touchMove.y = -dy;
          setKnob({ x: dx * R, y: dy * R, on: true });
        }}
        onPointerUp={() => {
          stick.current = null;
          game.input.touchMove.x = game.input.touchMove.y = 0;
          setKnob({ x: 0, y: 0, on: false });
        }}
        onPointerCancel={() => {
          stick.current = null;
          game.input.touchMove.x = game.input.touchMove.y = 0;
          setKnob({ x: 0, y: 0, on: false });
        }}
      >
        <div className="absolute bottom-10 left-10 h-[104px] w-[104px] rounded-full border border-white/20 bg-slate-950/30 backdrop-blur-sm">
          <div
            className={`absolute left-1/2 top-1/2 h-11 w-11 rounded-full border border-white/40 ${knob.on ? 'bg-amber-400/60' : 'bg-white/20'}`}
            style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
          />
        </div>
      </div>
      <div className="absolute bottom-6 right-4 grid grid-cols-3 gap-2.5">
        <button className={btn} onPointerDown={() => game.toggleCamera()}>
          CAM
        </button>
        <button className={btn} onPointerDown={() => game.input.requestSlot(-2)}>
          WPN
        </button>
        <button
          className={`${btn} ${sprint ? '!bg-amber-400/50' : ''}`}
          onPointerDown={() => {
            const v = !sprint;
            setSprint(v);
            game.input.touchSprint = v;
          }}
        >
          SPRINT
        </button>
        <button className={btn} onPointerDown={() => game.input.pressReload()}>
          RELOAD
        </button>
        <button
          className={`${btn} ${aim ? '!bg-sky-400/50' : ''}`}
          onPointerDown={() => {
            const v = !aim;
            setAim(v);
            game.input.touchAim = v;
          }}
        >
          AIM
        </button>
        <button className={btn} onPointerDown={() => game.input.pressCrouch()}>
          CROUCH
        </button>
        <button className={btn} onPointerDown={() => game.input.pressJump()}>
          JUMP
        </button>
        <button
          className={`${btn} col-span-2 !w-full !rounded-2xl !border-red-300/50 !bg-red-500/30`}
          onPointerDown={() => {
            game.input.pressFire();
            game.input.touchFire = true;
          }}
          onPointerUp={() => (game.input.touchFire = false)}
          onPointerCancel={() => (game.input.touchFire = false)}
          onPointerLeave={() => (game.input.touchFire = false)}
        >
          FIRE
        </button>
      </div>
    </>
  );
}

const STATE_COLOR: Record<string, string> = {
  IDLE: 'bg-slate-400',
  WANDERING: 'bg-slate-300',
  PLAYER_DETECTED: 'bg-yellow-300',
  INVESTIGATING: 'bg-amber-400',
  CHASING: 'bg-orange-500',
  APPROACHING: 'bg-red-500',
  ATTACKING: 'bg-red-600',
  STAGGERED: 'bg-fuchsia-400',
  KNOCKED_DOWN: 'bg-violet-500',
  GETTING_UP: 'bg-sky-400',
  DEAD: 'bg-stone-600',
};

function HordePanel({ hud }: { hud: Hud }) {
  const max = Math.max(1, ...hud.zStates);
  return (
    <div className={`${panel} w-[212px] p-3`}>
      <div className="mb-2 flex items-center justify-between">
        <span className={label}>Horde AI</span>
        <span className="font-mono text-[10px] text-red-300/90 tabular-nums">{hud.zAlive} alive</span>
      </div>
      <div className="space-y-[3px]">
        {AI_STATES.map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <span className={`w-[104px] font-mono text-[9.5px] tracking-wider ${hud.zStates[i] ? 'text-white/80' : 'text-white/30'}`}>{s}</span>
            <div className="h-[5px] flex-1 overflow-hidden rounded-full bg-white/10">
              <div className={`h-full rounded-full ${STATE_COLOR[s]}`} style={{ width: `${(hud.zStates[i] / max) * 100}%` }} />
            </div>
            <span className="w-5 text-right font-mono text-[9.5px] text-white/60 tabular-nums">{hud.zStates[i]}</span>
          </div>
        ))}
      </div>
      <div className="mt-2.5 grid grid-cols-3 gap-1.5 text-center">
        {[
          ['KILLS', hud.kills],
          ['HEADS', hud.headshots],
          ['LIMBS', hud.limbs],
        ].map(([k, v]) => (
          <div key={k} className="rounded border border-white/10 bg-white/5 py-1">
            <div className="font-mono text-[14px] font-semibold text-amber-300 tabular-nums">{v}</div>
            <div className="font-mono text-[8px] tracking-widest text-white/40">{k}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function HealthBar({ hud }: { hud: Hud }) {
  const low = hud.hp < 35;
  return (
    <div className={`${panel} w-[236px] p-3`}>
      <div className="flex items-end justify-between">
        <span className={label}>Health</span>
        <span className={`font-mono text-[20px] font-semibold leading-none tabular-nums ${low ? 'text-red-400' : 'text-emerald-300'}`}>
          {Math.ceil(hud.hp)}
        </span>
      </div>
      <div className="mt-2 h-[7px] overflow-hidden rounded-full bg-white/10">
        <div
          className={`h-full rounded-full transition-[width] duration-150 ${low ? 'bg-red-500' : 'bg-gradient-to-r from-emerald-400 to-lime-300'}`}
          style={{ width: `${hud.hp}%` }}
        />
      </div>
      <div className="mt-1.5 flex justify-between font-mono text-[9px] tracking-widest text-white/45">
        <span>NEAREST {hud.nearest < 99 ? `${hud.nearest.toFixed(1)} M` : '—'}</span>
        <span className={hud.nearest < 6 ? 'text-red-300' : ''}>{hud.nearest < 6 ? 'DANGER' : hud.nearest < 15 ? 'CLOSE' : 'CLEAR'}</span>
      </div>
    </div>
  );
}

function DamageFx({ hud }: { hud: Hud }) {
  const flash = Math.max(0, 1 - hud.hurtAge / 0.6);
  const low = Math.max(0, (45 - hud.hp) / 45);
  const a = Math.min(0.85, flash * 0.6 + low * 0.45);
  return (
    <>
      <div
        className="absolute inset-0"
        style={{ background: `radial-gradient(ellipse at center, transparent 45%, rgba(120,0,0,${a}) 100%)` }}
      />
      {flash > 0 && (
        <div className="absolute left-1/2 top-1/2" style={{ transform: `rotate(${-hud.hurtAng}rad)` }}>
          <div
            className="absolute -translate-x-1/2"
            style={{
              top: -150,
              width: 0,
              height: 0,
              borderLeft: '22px solid transparent',
              borderRight: '22px solid transparent',
              borderBottom: `30px solid rgba(255,40,30,${flash * 0.9})`,
              filter: 'drop-shadow(0 0 8px rgba(255,0,0,.8))',
            }}
          />
        </div>
      )}
    </>
  );
}

function KillFeed({ hud }: { hud: Hud }) {
  const k = hud.killAge < 0.9;
  const h = hud.headAge < 1.2;
  if (!k && !h) return null;
  return (
    <div className="absolute left-1/2 top-[58%] -translate-x-1/2 text-center">
      {h ? (
        <div className="font-display text-[22px] font-bold tracking-[0.35em] text-red-400 [text-shadow:0_0_12px_rgba(255,0,0,.7)]" style={{ opacity: 1 - hud.headAge / 1.2 }}>
          HEADSHOT
        </div>
      ) : (
        <div className="font-display text-[16px] font-bold tracking-[0.35em] text-white/90 [text-shadow:0_1px_6px_rgba(0,0,0,.8)]" style={{ opacity: 1 - hud.killAge / 0.9 }}>
          KILL
        </div>
      )}
    </div>
  );
}

function DeathScreen({ hud, game }: { hud: Hud; game: Game }) {
  if (!hud.dead) return null;
  return (
    <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,rgba(60,0,0,.55),rgba(10,0,0,.9))]">
      <div className="text-center">
        <div className="font-display text-[64px] font-bold leading-none tracking-[0.2em] text-red-500 [text-shadow:0_0_30px_rgba(255,0,0,.6)]">YOU DIED</div>
        <div className="mt-3 font-mono text-[12px] tracking-[0.3em] text-white/70">
          {hud.kills} KILLS · {hud.headshots} HEADSHOTS · {hud.limbs} LIMBS
        </div>
        <button
          className="mt-6 rounded-full border border-red-300/50 bg-red-600/40 px-6 py-2 font-mono text-[12px] tracking-[0.3em] text-white hover:bg-red-500/60"
          onClick={() => game.restart()}
        >
          RESTART (P)
        </button>
      </div>
    </div>
  );
}

function CamButton({ hud, game }: { hud: Hud; game: Game }) {
  const bc = hud.fpsCam === 'BODYCAM';
  return (
    <button
      className={`pointer-events-auto flex items-center gap-2 rounded-full border px-3.5 py-2 font-display text-[12px] font-bold uppercase tracking-[0.2em] backdrop-blur-md transition-all ${
        bc ? 'border-sky-300/70 bg-sky-500/35 text-white' : 'border-white/20 bg-slate-950/55 text-white/80 hover:text-white'
      }`}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => {
        e.stopPropagation();
        game.toggleFpsCam();
      }}
      title="First-person camera style (N)"
    >
      FPS Cam
      <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] tracking-widest ${bc ? 'bg-sky-950/60 text-sky-100' : 'bg-white/10 text-white/60'}`}>
        {hud.fpsCam}
      </span>
      <kbd className="font-mono text-[9px] text-white/45">N</kbd>
    </button>
  );
}

function AggroButton({ hud, game }: { hud: Hud; game: Game }) {
  const on = hud.aggressive;
  return (
    <button
      className={`pointer-events-auto group flex items-center gap-2.5 rounded-full border px-4 py-2 font-display text-[13px] font-bold uppercase tracking-[0.22em] backdrop-blur-md transition-all ${
        on
          ? 'border-red-400/80 bg-red-600/45 text-white shadow-[0_0_24px_rgba(255,30,30,.55)]'
          : 'border-white/20 bg-slate-950/55 text-white/80 hover:border-red-300/60 hover:text-white'
      }`}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => {
        e.stopPropagation();
        game.toggleAggressive();
      }}
      title="Toggle (K)"
    >
      <span className={`h-2.5 w-2.5 rounded-full ${on ? 'animate-pulse bg-red-400 shadow-[0_0_10px_rgba(255,60,60,1)]' : 'bg-white/30'}`} />
      Zombie Aggressive Mode
      <span className={`rounded px-1.5 py-0.5 font-mono text-[10px] tracking-widest ${on ? 'bg-red-950/60 text-red-200' : 'bg-white/10 text-white/50'}`}>
        {on ? 'ON' : 'OFF'}
      </span>
      <kbd className="font-mono text-[9px] text-white/45">K</kbd>
    </button>
  );
}

/** Blood spattered on the camera lens after close kills / blasts. */
function BloodLens({ lens }: { lens: number }) {
  const blobs = useMemo(
    () =>
      Array.from({ length: 14 }, () => {
        const edge = Math.random();
        const x = edge < 0.5 ? (Math.random() < 0.5 ? Math.random() * 18 : 82 + Math.random() * 18) : Math.random() * 100;
        const y = edge < 0.5 ? Math.random() * 100 : Math.random() < 0.5 ? Math.random() * 16 : 84 + Math.random() * 16;
        return { x, y, s: 40 + Math.random() * 140, drip: 30 + Math.random() * 120, r: Math.random() * 360 };
      }),
    [],
  );
  if (lens < 0.02) return null;
  return (
    <div className="absolute inset-0" style={{ opacity: Math.min(1, lens * 1.3) }}>
      {blobs.map((b, i) => (
        <div key={i} className="absolute" style={{ left: `${b.x}%`, top: `${b.y}%`, transform: `translate(-50%,-50%) rotate(${b.r}deg)` }}>
          <div
            style={{
              width: b.s,
              height: b.s * 0.8,
              borderRadius: '46% 54% 40% 60% / 55% 45% 55% 45%',
              background: 'radial-gradient(circle at 40% 35%, rgba(150,10,10,.55), rgba(90,0,0,.75) 55%, rgba(60,0,0,0) 72%)',
              filter: 'blur(1.5px)',
            }}
          />
          <div
            className="absolute left-1/2"
            style={{ top: b.s * 0.55, width: 6, height: b.drip * lens, borderRadius: 4, background: 'linear-gradient(rgba(110,0,0,.7), rgba(110,0,0,0))' }}
          />
        </div>
      ))}
    </div>
  );
}

function BlastFlash({ age }: { age: number }) {
  if (age > 0.7) return null;
  const a = Math.max(0, 1 - age / 0.7);
  return <div className="absolute inset-0" style={{ background: `radial-gradient(circle, rgba(255,235,200,${a * 0.75}), rgba(255,140,40,${a * 0.35}))` }} />;
}

export default function App() {
  const hostRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [hud, setHud] = useState<Hud | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [touch] = useState(() => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches);

  useEffect(() => {
    if (!canvasRef.current || !hostRef.current) return;
    let g: Game;
    try {
      g = new Game(canvasRef.current, hostRef.current);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'WebGL is not available in this browser.');
      return;
    }
    setGame(g);
    (window as unknown as { __game?: Game }).__game = g; // debug / automation handle
    const id = window.setInterval(() => setHud({ ...g.hud, weights: [...g.hud.weights] }), 70);
    return () => {
      window.clearInterval(id);
      g.dispose();
      setGame(null);
    };
  }, []);

  return (
    <div ref={hostRef} className="fixed inset-0 select-none overflow-hidden bg-[#cfd9e6] font-sans text-white">
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full cursor-crosshair outline-none" />

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950 p-8 text-center">
          <div>
            <div className="font-display text-2xl font-bold">Unable to start the renderer</div>
            <p className="mt-2 max-w-md text-sm text-white/60">{error}</p>
          </div>
        </div>
      )}

      {hud && game && (
        <div className="pointer-events-none absolute inset-0">
          <BlastFlash age={hud.blastAge} />
          <BloodLens lens={hud.lens} />
          <DamageFx hud={hud} />
          {hud.aggressive && (
            <div className="absolute inset-0 shadow-[inset_0_0_140px_rgba(160,0,0,.45)]" />
          )}
          <div className="absolute left-1/2 top-3 flex -translate-x-1/2 gap-2 sm:top-5">
            <AggroButton hud={hud} game={game} />
            <CamButton hud={hud} game={game} />
          </div>
          <ScopeOverlay hud={hud} />
          <Crosshair hud={hud} />
          <KillFeed hud={hud} />
          {/* top-left: identity + active state */}
          <div className="absolute left-3 top-3 space-y-2 sm:left-5 sm:top-5">
            <div className="flex items-center gap-2 pl-0.5">
              <div className="h-2 w-2 rotate-45 bg-amber-400" />
              <span className="font-display text-[13px] font-semibold uppercase tracking-[0.3em] text-white [text-shadow:0_1px_6px_rgba(15,23,42,.75)]">
                Dead Snow
              </span>
              <span className="hidden font-mono text-[10px] tracking-widest text-white/75 [text-shadow:0_1px_6px_rgba(15,23,42,.75)] sm:inline">
                HORDE · RAGDOLL · DISMEMBERMENT
              </span>
            </div>
            <SpeedBlock hud={hud} />
            <div className="hidden gap-2 lg:flex">
              <HordePanel hud={hud} />
              <div className="hidden 2xl:block">
                <StatePanel hud={hud} />
              </div>
            </div>
          </div>

          {/* top-right: status chips */}
          <div className="absolute right-3 top-3 flex flex-col items-end gap-1.5 sm:right-5 sm:top-5">
            <div className="flex items-center gap-1.5">
              {hud.slowmo && (
                <div className="rounded border border-amber-300/50 bg-amber-400/20 px-2.5 py-1 font-mono text-[10px] tracking-widest text-amber-200 backdrop-blur">
                  SLOW ×0.2
                </div>
              )}
              {hud.debug && (
                <div className="rounded border border-emerald-300/50 bg-emerald-400/20 px-2.5 py-1 font-mono text-[10px] tracking-widest text-emerald-100 backdrop-blur">
                  IK DEBUG
                </div>
              )}
              <div
                className={`rounded border px-2.5 py-1 font-mono text-[10px] tracking-widest backdrop-blur ${hud.firstPerson ? 'border-amber-300/60 bg-amber-400/25 text-amber-100' : 'border-white/10 bg-slate-950/55 text-white/70'}`}
              >
                {hud.firstPerson ? 'FIRST PERSON' : 'THIRD PERSON'}
              </div>
              <div className={`${panel} px-2.5 py-1 font-mono text-[10px] tracking-widest text-white/60`}>{hud.fps} Hz</div>
            </div>
            <WeaponPanel hud={hud} />
          </div>

          {/* bottom */}
          <div className="absolute bottom-5 left-3 sm:left-5">
            <HealthBar hud={hud} />
          </div>
          {!touch && (
            <div className="absolute bottom-5 left-1/2 hidden -translate-x-1/2 xl:block">
              <GaitStrip hud={hud} />
            </div>
          )}
          {!touch && (
            <div className="absolute bottom-5 right-5 hidden md:block">
              <Legend hud={hud} />
            </div>
          )}
          {touch && <TouchControls game={game} />}
          <DeathScreen hud={hud} game={game} />

          {/* intro */}
          <div
            className={`absolute inset-0 flex items-center justify-center bg-slate-950/35 backdrop-blur-[2px] transition-[opacity,visibility] duration-500 ${hud.engaged ? 'invisible opacity-0' : 'opacity-100'}`}
          >
            <div className={`${panel} mx-4 max-w-[440px] p-6 text-center`}>
              <div className="font-mono text-[10px] uppercase tracking-[0.35em] text-red-300">100 undead · physics ragdolls</div>
              <h1 className="mt-2 font-display text-[40px] font-bold leading-none tracking-wide">Dead Snow</h1>
              <p className="mx-auto mt-3 max-w-[350px] text-[13px] leading-relaxed text-white/65">
                A horde of 100 shamblers, lurchers and World War Z-style runners is out there. Every gunshot draws them in.
                Each body part reacts to the bullet that hits it, limbs tear off, heads burst, and the fallen crawl or
                struggle back to their feet. Shoot the red barrels to blow the horde apart, press V for first person and K
                (or the button on top) to unleash ZOMBIE AGGRESSIVE MODE. Grab a weapon (1 / 2 / 3) and survive.
              </p>
              <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-400/15 px-4 py-1.5 text-[12px] font-medium text-amber-100">
                {touch ? 'Drag the left stick to begin' : 'Click the scene or press W A S D to begin'}
              </div>
              {!touch && (
                <div className="mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[11px] text-white/55">
                  <span className="flex items-center gap-1.5">
                    <Key>Shift</Key> sprint
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Key>Space</Key> jump
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Key>C</Key> crouch
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Key>1</Key>
                    <Key>2</Key>
                    <Key>3</Key> weapons
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Key>V</Key> TPS / FPS
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
