// Headless verification of the zombie horde (AI, ragdoll, hits, get-up).
const fakeCtx = new Proxy(
  {},
  {
    get: (_t, k) => {
      if (k === 'createRadialGradient' || k === 'createLinearGradient') return () => ({ addColorStop() {} });
      return () => {};
    },
    set: () => true,
  },
);
(globalThis as any).document = { createElement: () => ({ width: 0, height: 0, getContext: () => fakeCtx }) };

import * as THREE from 'three';
import { Terrain } from '../src/game/terrain';
import { Foley } from '../src/game/audio';
import { Horde, ShotSpec } from '../src/game/zombie/zombies';
import { NP, P, SEGS } from '../src/game/zombie/skeleton';
import { soundEngine } from '../src/game/ref/audio';
soundEngine.setMuted(true);

const terrain = new Terrain();
const scene = new THREE.Scene();
const horde = new Horde(scene, terrain, new Foley());
const cam = new THREE.PerspectiveCamera(52, 1, 0.1, 500);
let hits = 0;
horde.onPlayerHit = () => hits++;
const player = { pos: new THREE.Vector3(0, 0, -2), vel: new THREE.Vector3(), sprinting: false, crouching: false, alive: true };
horde.populate(0, -2);

function check(label: string) {
  let nan = 0;
  let below = 0;
  let stretch = 0;
  let inWall = 0;
  for (const z of horde.zombies) {
    if (!z.active) continue;
    for (let i = 0; i < NP * 3; i++) if (!isFinite(z.pts[i])) nan++;
    for (let i = 0; i < NP; i++) {
      const gh = terrain.height(z.pts[i * 3], z.pts[i * 3 + 2]);
      if (z.pts[i * 3 + 1] < gh - 0.05 && !z.detached[i]) below++;
    }
    for (const s of SEGS) {
      if (z.detached[s.a] !== z.detached[s.b]) continue;
      const d = Math.hypot(z.pts[s.a * 3] - z.pts[s.b * 3], z.pts[s.a * 3 + 1] - z.pts[s.b * 3 + 1], z.pts[s.a * 3 + 2] - z.pts[s.b * 3 + 2]);
      if (d > 0.6 * z.s) {
        stretch++;
        console.log('  STRETCH', z.slot, s.kind, d.toFixed(2), z.body, z.crawler, [...z.severed].join('/'), z.detached[s.a], z.ghostTo[s.a], z.ghostTo[s.b]);
      }
    }
    if (z.upright && terrain.solid(z.pos.x, z.pos.z)) inWall++;
  }
  console.log(label, { nan, below, stretch, inWall });
}

const dt = 1 / 60;
const t0 = performance.now();
for (let f = 0; f < 60 * 25; f++) horde.update(dt, player, cam, 800);
console.log('25s sim ms/frame', ((performance.now() - t0) / (60 * 25)).toFixed(2));
console.log('states', horde.stateCounts, 'playerHits', hits);
const dists = horde.zombies.filter((z) => z.active && z.alive).map((z) => z.pos.distanceTo(player.pos)).sort((a, b) => a - b);
console.log('nearest 5', dists.slice(0, 5).map((d) => d.toFixed(1)));
check('after chase');

// ---- shoot the nearest upright zombie in different places
player.alive = false; // stop attacks so we can study reactions
const rifle: ShotSpec = { dmg: 31, power: 1.15, impulse: 15, pen: 1, explode: 0.4 };
const sniper: ShotSpec = { dmg: 170, power: 3, impulse: 44, pen: 3, explode: 1 };
function shootAt(z: any, pi: number, spec: ShotSpec) {
  const tx = z.pts[pi * 3];
  const ty = z.pts[pi * 3 + 1];
  const tz = z.pts[pi * 3 + 2];
  const o = new THREE.Vector3(tx + 6, ty + 0.3, tz + 1);
  const d = new THREE.Vector3(tx, ty, tz).sub(o).normalize();
  const hs = horde.raycast(o, d, 0.1, 50).filter((h) => h.z === z);
  if (!hs.length) return 'miss';
  horde.hit(hs[0], d, spec);
  return SEGS[hs[0].seg].kind;
}
const z = horde.zombies.find((q) => q.active && q.alive && q.upright)!;
z.hp = 9999;
console.log('target kind', z.kind);
const log: string[] = [];
const run = (sec: number) => {
  for (let f = 0; f < sec * 60; f++) {
    horde.update(dt, player, cam, 800);
    const st = z.body;
    if (log[log.length - 1] !== st) log.push(st);
  }
};
console.log('torso ->', shootAt(z, P.CHEST, rifle));
run(0.5);
console.log('leg ->', shootAt(z, P.LKN, rifle));
run(0.3);
console.log('leg ->', shootAt(z, P.RKN, rifle));
run(0.2);
console.log('head ->', shootAt(z, P.HEAD, rifle));
run(12);
console.log('body states', log.join(' > '));
check('after knockdown');

// dismember + kill
const z2 = horde.zombies.find((q) => q.active && q.alive && q.upright && q !== z)!;
console.log('arm ->', shootAt(z2, P.LEL, sniper), 'severed', [...z2.severed]);
run(1);
console.log('thigh ->', shootAt(z2, P.RKN, sniper), 'severed', [...z2.severed], 'body', z2.body, 'crawler', z2.crawler);
run(10);
console.log('z2 body', z2.body, 'alive', z2.alive);
console.log('head ->', shootAt(z2, P.HEAD, sniper), 'alive', z2.alive, 'hidden', z2.hidden);
run(6);
console.log('z2 asleep', z2.asleep, 'body', z2.body);
check('after gore');
console.log('kills', horde.kills, 'limbs', horde.limbs, 'heads', horde.headshots);
console.log('z severed', [...z.severed], z.limbHp, 'crawler', z.crawler);
for (const q of horde.zombies) {
  if (!q.active) continue;
  const bad: string[] = [];
  for (let i = 0; i < NP; i++) {
    const gh = terrain.height(q.pts[i * 3], q.pts[i * 3 + 2]);
    if (q.pts[i * 3 + 1] < gh - 0.05) bad.push(`${i}:${(q.pts[i * 3 + 1] - gh).toFixed(2)}${q.detached[i] ? 'D' : ''}${q.frozen[i] ? 'F' : ''}`);
  }
  if (bad.length) console.log(q.slot, q.body, q.alive, q.asleep, q.physics, bad.join(' '));
}
const z3 = horde.zombies.find((q) => q.active && q.alive && q.upright && q.dist < 40)!;
console.log('live headshot sniper ->', shootAt(z3, P.HEAD, sniper), 'alive', z3.alive, 'hidden', z3.hidden, 'severed', [...z3.severed]);
run(3);
check('after pop');
for (const q of horde.zombies) {
  if (!q.active || !q.upright) continue;
  let worst = 0;
  for (let i = 0; i < NP; i++) worst = Math.min(worst, q.pts[i * 3 + 1] - terrain.height(q.pts[i * 3], q.pts[i * 3 + 2]));
  if (worst < -0.3) console.log('Z', q.slot, q.beh, q.kind, q.pos.x.toFixed(2), q.pos.z.toFixed(2), 'wallW', q.wallW.toFixed(2), 'grab', q.grabW.toFixed(2), 'yaw', q.yaw.toFixed(2), 'gh', terrain.height(q.pos.x, q.pos.z).toFixed(2), 'rootY', q.rootY.toFixed(2));
}
console.log('--- pose check (upright zombies) ---');
let shown = 0;
for (const q of horde.zombies) {
  if (!q.active || !q.upright || shown > 5) continue;
  shown++;
  const y = (i: number) => (q.pts[i * 3 + 1] - q.rootY).toFixed(2);
  const fwd = (i: number) => ((q.pts[i * 3] - q.pts[P.PELVIS * 3]) * Math.sin(q.yaw) + (q.pts[i * 3 + 2] - q.pts[P.PELVIS * 3 + 2]) * Math.cos(q.yaw)).toFixed(2);
  console.log(q.kind.padEnd(8), q.beh.padEnd(12), 'head', y(P.HEAD), 'fwd', fwd(P.HEAD), '| chest', y(P.CHEST), '| pelvis', y(P.PELVIS), '| hands', y(P.LHA), y(P.RHA), 'fwd', fwd(P.LHA), fwd(P.RHA), '| ankles', y(P.LAN), y(P.RAN), '| toes', y(P.LTO), y(P.RTO));
}
