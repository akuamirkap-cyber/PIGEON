const fakeCtx = new Proxy({}, { get: (_t, k) => (k === 'createRadialGradient' || k === 'createLinearGradient' || k === 'createPattern' ? () => ({ addColorStop() {} }) : k === 'getImageData' || k === 'createImageData' ? () => ({ data: new Uint8ClampedArray(4) }) : k === 'measureText' ? () => ({ width: 10 }) : () => {}), set: () => true });
(globalThis as any).document = { createElement: () => ({ width: 0, height: 0, style: {}, getContext: () => fakeCtx }) };
(globalThis as any).window = globalThis;
import * as THREE from 'three';
import { Terrain } from '../src/game/terrain';
import { FpsWeapons, buildThirdPersonWeapons } from '../src/game/fpsWeapons';
import { WEAPONS } from '../src/game/weapons';
import { soundEngine } from '../src/game/ref/audio';
soundEngine.setMuted(true);

const scene = new THREE.Scene();
const fps = new FpsWeapons(scene, new Terrain());
fps.setAspect(1.6);
fps.visible = true;
const cam = new THREE.PerspectiveCamera(98, 1.6, 0.08, 500);
cam.position.set(0, 1.34, 0);
cam.lookAt(0, 1.34, 10);
cam.updateMatrixWorld();
const tp = buildThirdPersonWeapons();
console.log('TPS weapons', tp.map((t) => ({ muzzle: t.muzzle.toArray().map((v) => v.toFixed(2)), left: t.left.toArray().map((v) => v.toFixed(2)) })));
console.log('defs', WEAPONS.map((w) => ({ n: w.name, mag: w.mag, int: w.interval.toFixed(3), rl: w.reload, ads: w.ads.map((v) => v.toFixed(3)) })));
const base = { adsHeld: false, reload: 0, ammo: 10, sprinting: false, speed: 0, grounded: true, crouch: 0, lookX: 0, lookY: 0, landed: 0 };
const dt = 1 / 60;
let meshes = 0;
for (let slot = 0; slot < 3; slot++) {
  for (let i = 0; i < 40; i++) fps.update(dt, dt, { ...base, slot }, cam);
  fps.rigs[fps.weaponId].root.traverse((o) => { if ((o as THREE.Mesh).isMesh) meshes++; });
  fps.fire(slot, 4, cam, new THREE.Vector3());
  const states: string[] = [];
  for (let i = 0; i < 70; i++) {
    fps.update(dt, dt, { ...base, slot, ammo: 4 }, cam);
    if (states[states.length - 1] !== fps.animState) states.push(fps.animState);
  }
  const m = fps.muzzleWorld(cam).sub(cam.position);
  console.log(fps.weaponId, 'states after fire', states.join('>'), 'camRecoil', fps.camRecoilPitch.toFixed(3), 'muzzle rel', m.toArray().map((v) => v.toFixed(2)).join(','));
  // reload driven by arsenal progress
  const rs: string[] = [];
  for (let i = 0; i <= 60; i++) {
    fps.update(dt, dt, { ...base, slot, reload: Math.max(0.001, i / 60) }, cam);
    if (rs[rs.length - 1] !== fps.animState) rs.push(fps.animState);
  }
  fps.update(dt, dt, { ...base, slot, reload: 0 }, cam);
  console.log('  reload', rs.join('>'), '-> back to', fps.animState, 'mag y', fps.rigs[fps.weaponId].mag.position.y.toFixed(3));
}
fps.updateFx(0.5);
console.log('vm meshes per rig (approx)', meshes, 'worldFov', fps.worldFov.toFixed(1));
