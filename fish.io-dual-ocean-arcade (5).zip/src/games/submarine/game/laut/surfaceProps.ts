// ============================================================================
// MODE "DUNIA LAUT 3D" — Above-Water 3D Coastal Life:
//   • 2x Scaled Soaring, Water-Skimming & Swimming 3D Pelicans with sleek
//     lofted hooked upper bill & smooth gular throat pouch, folded resting
//     wings on water, periodic water-scoop dip + surface ripples
//   • 2x Scaled Sculpted 3D Tourist Boats in separated non-overlapping coastal
//     lanes, featuring recessed teak cockpits, hull portholes, helms &
//     captains driving at the wheel, cushioned benches with seated tourists,
//     and standing/waving diver-proportioned vacationers
// ============================================================================
import * as THREE from "three";
import { WORLD_W } from "../ocean";
import { COMMON, SHARED } from "./glsl";
import { mulberry32 } from "./geometry";
import { buildDiverMesh } from "../penyelam/meshes.js";

type RGB = [number, number, number];

interface PartSpec {
  g: THREE.BufferGeometry;
  col: RGB;
  met?: number;
  ao?: number;
  part?: number; // 0=solid, 1=pelican wing, 2=flutter flag/bunting, 4=wake/ripple foam, 5=tourist sway, 6=pelican head/neck/bill
}

interface MergedRaw {
  pos: Float32Array;
  norm: Float32Array;
  col: Float32Array;
  met: Float32Array;
  ao: Float32Array;
  part: Float32Array;
  count: number;
}

function mergeSurfaceParts(parts: PartSpec[], extras: MergedRaw[] = []): THREE.BufferGeometry {
  const clean: THREE.BufferGeometry[] = [];
  let totalVerts = 0;
  for (const p of parts) {
    const g = p.g.index ? p.g.toNonIndexed() : p.g;
    if (!g.getAttribute("normal")) g.computeVertexNormals();
    if (g.getAttribute("uv")) g.deleteAttribute("uv");
    clean.push(g);
    totalVerts += g.getAttribute("position").count;
  }
  for (const ex of extras) totalVerts += ex.count;

  const pos = new Float32Array(totalVerts * 3);
  const norm = new Float32Array(totalVerts * 3);
  const aCol = new Float32Array(totalVerts * 3);
  const aMet = new Float32Array(totalVerts);
  const aAO = new Float32Array(totalVerts);
  const aPart = new Float32Array(totalVerts);

  let off = 0;
  for (let i = 0; i < clean.length; i++) {
    const g = clean[i];
    const spec = parts[i];
    const gp = g.getAttribute("position") as THREE.BufferAttribute;
    const gn = g.getAttribute("normal") as THREE.BufferAttribute;
    const n = gp.count;
    pos.set(gp.array as Float32Array, off * 3);
    norm.set(gn.array as Float32Array, off * 3);
    const [r, gr, b] = spec.col;
    const met = spec.met ?? 0.08;
    const ao = spec.ao ?? 1.0;
    const pt = spec.part ?? 0.0;
    for (let k = 0; k < n; k++) {
      const idx = off + k;
      aCol[idx * 3] = r;
      aCol[idx * 3 + 1] = gr;
      aCol[idx * 3 + 2] = b;
      aMet[idx] = met;
      aAO[idx] = ao;
      aPart[idx] = pt;
    }
    off += n;
    if (g !== parts[i].g) parts[i].g.dispose();
    g.dispose();
  }

  for (const ex of extras) {
    pos.set(ex.pos, off * 3);
    norm.set(ex.norm, off * 3);
    aCol.set(ex.col, off * 3);
    aMet.set(ex.met, off);
    aAO.set(ex.ao, off);
    aPart.set(ex.part, off);
    off += ex.count;
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  out.setAttribute("normal", new THREE.BufferAttribute(norm, 3));
  out.setAttribute("aCol", new THREE.BufferAttribute(aCol, 3));
  out.setAttribute("aMet", new THREE.BufferAttribute(aMet, 1));
  out.setAttribute("aAO", new THREE.BufferAttribute(aAO, 1));
  out.setAttribute("aPart", new THREE.BufferAttribute(aPart, 1));
  out.computeBoundingSphere();
  return out;
}

/** Build a non-indexed closed buffer geometry from lofted cross-section loops (each loop of equal point count). */
function loftRings(loops: THREE.Vector3[][], capStart = true, capEnd = true): THREE.BufferGeometry {
  const seg = loops[0].length;
  const tris: number[] = [];
  const pushTri = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3) => {
    tris.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
  };
  for (let i = 0; i < loops.length - 1; i++) {
    const L0 = loops[i];
    const L1 = loops[i + 1];
    for (let j = 0; j < seg; j++) {
      const jn = (j + 1) % seg;
      pushTri(L0[j], L1[j], L1[jn]);
      pushTri(L0[j], L1[jn], L0[jn]);
    }
  }
  if (capStart && loops.length > 0) {
    const L = loops[0];
    const c = new THREE.Vector3();
    for (const p of L) c.add(p);
    c.divideScalar(seg);
    for (let j = 0; j < seg; j++) {
      const jn = (j + 1) % seg;
      pushTri(c, L[jn], L[j]);
    }
  }
  if (capEnd && loops.length > 0) {
    const L = loops[loops.length - 1];
    const c = new THREE.Vector3();
    for (const p of L) c.add(p);
    c.divideScalar(seg);
    for (let j = 0; j < seg; j++) {
      const jn = (j + 1) % seg;
      pushTri(c, L[j], L[jn]);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
  geo.computeVertexNormals();
  return geo;
}

// ------------------------------------------------------------------ Surface Daylight Material
function surfaceDaylightMaterial(transparentPass = false): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: { ...SHARED },
    side: THREE.DoubleSide,
    transparent: transparentPass,
    depthWrite: !transparentPass,
    vertexShader: /* glsl */ `
attribute vec3 aCol;
attribute float aMet;
attribute float aAO;
attribute float aPart;
attribute vec4 iCtrl; // (phase, flapAmp (<0 = folded swimming/perched wing!), wingFreq, glideOrSwimDip)
uniform float uTime;

varying vec3 vWP;
varying vec3 vN;
varying vec3 vCol;
varying float vMet;
varying float vAO;
varying float vPart;
varying float vPh;

void main(){
  vec3 pos = position;
  vec3 nrm = normal;
  float ph = iCtrl.x;

  // Pelican articulated left & right wings (part == 1.0)
  if (aPart > 0.5 && aPart < 1.5) {
    float side = pos.z >= 0.0 ? 1.0 : -1.0;
    float shZ = side * 2.1;
    float shY = 1.6;
    float dz = pos.z - shZ;
    float dy = pos.y - shY;
    float span = clamp(abs(dz) / 14.0, 0.0, 1.0);

    if (iCtrl.y < 0.0) {
      // Folded resting wing posture for pelicans swimming on water or perched on boats
      pos.z = side * (3.15 + abs(dz) * 0.085);
      pos.y = 1.25 + dy * 0.55 + sin(span * 2.6) * 1.45;
      pos.x -= abs(dz) * 0.42;
      pos.y += sin(uTime * 2.2 + ph) * 0.22 * span;
    } else {
      // Flying / soaring wingbeat + smooth glide cycles
      float beatWave = sin(uTime * iCtrl.z + ph - span * 0.45);
      float glideWave = sin(uTime * 0.48 + ph * 1.7);
      float activeFlap = mix(0.26, 1.0, smoothstep(-0.35, 0.35, glideWave));
      float ang = (beatWave * iCtrl.y * activeFlap + iCtrl.w) * (0.28 + 0.72 * span);
      float c = cos(ang), s = sin(ang) * side;
      pos.z = shZ + dz * c - dy * s;
      pos.y = shY + dz * s + dy * c;
      float ny = nrm.y, nz = nrm.z;
      nrm.z = nz * c - ny * s;
      nrm.y = nz * s + ny * c;
    }
  } else if (aPart > 1.5 && aPart < 2.5) {
    // Fluttering mast pennant & coastal breeze bunting
    float u = clamp((-pos.x) / 14.0, 0.0, 1.0);
    float flut = sin(uTime * 8.2 - pos.x * 0.35 + ph) * 2.1 * u;
    pos.z += flut;
    pos.y += cos(uTime * 6.4 - pos.x * 0.3 + ph) * 0.75 * u;
  } else if (aPart > 4.5 && aPart < 5.5) {
    // Cheerful diver-shaped tourists leaning gently on deck
    float sway = sin(uTime * 2.1 + ph + pos.x * 0.14) * 0.38 * clamp((pos.y - 20.0) / 14.0, 0.0, 1.0);
    pos.x += sway;
  } else if (aPart > 5.5 && aPart < 6.5) {
    // Pelican head, neck & pouched bill: gentle bob + water-scoop dip when swimming
    float pivotX = 4.2, pivotY = 0.8;
    float dx = pos.x - pivotX;
    float dy = pos.y - pivotY;
    float scoop = iCtrl.y < 0.0 ? pow(max(0.0, sin(uTime * 0.72 + ph * 2.3)), 14.0) * 0.42 : 0.0;
    float bob = sin(uTime * (iCtrl.y < 0.0 ? 2.4 : 1.4) + ph) * 0.042;
    float ang = -(scoop + bob);
    float c = cos(ang), s = sin(ang);
    pos.x = pivotX + dx * c - dy * s;
    pos.y = pivotY + dx * s + dy * c;
    float nx = nrm.x, ny = nrm.y;
    nrm.x = nx * c - ny * s;
    nrm.y = nx * s + ny * c;
  }

  mat4 mm = modelMatrix;
  #ifdef USE_INSTANCING
    mm = mm * instanceMatrix;
  #endif
  vec4 wp = mm * vec4(pos, 1.0);
  vWP = wp.xyz;
  vN = normalize(mat3(mm) * nrm);
  vCol = aCol;
  vMet = aMet;
  vAO = aAO;
  vPart = aPart;
  vPh = ph;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`,
    fragmentShader:
      COMMON +
      /* glsl */ `
varying vec3 vWP;
varying vec3 vN;
varying vec3 vCol;
varying float vMet;
varying float vAO;
varying float vPart;
varying float vPh;

void main(){
  vec3 N = normalize(vN);
  if (!gl_FrontFacing) N = -N;

  // Translucent boat wake & swimming pelican water-ripple foam (vPart == 4.0)
  if (vPart > 3.5 && vPart < 4.5) {
    float ripple = .55 + .45 * sin(vWP.x * .13 - uTime * 3.8 + vPh);
    float fade = clamp(vAO * ripple, 0.0, 1.0);
    vec3 foamCol = mix(vec3(.74, .97, 1.0), vec3(1.0, 1.0, 1.0), .58 + .42 * ripple);
    gl_FragColor = vec4(foamCol * fade * .76, fade * .76);
    return;
  }

  vec3 L = normalize(vec3(-0.36, 0.84, 0.42));
  vec3 V = vec3(0.0, 0.0, 1.0);
  vec3 H = normalize(L + V);
  float ndl = max(dot(N, L), 0.0);
  float wrap = max(0.0, dot(N, L) * 0.55 + 0.45);
  float skyFill = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
  float seaBounce = max(0.0, -N.y);

  // Warm coastal sunlight + sky zenith bounce + turquoise ocean reflection underneath
  vec3 skyAmb = mix(vec3(0.44, 0.68, 0.86), vec3(0.84, 0.94, 1.0), skyFill);
  vec3 bounce = vec3(0.24, 0.78, 0.84) * seaBounce * 0.34;
  vec3 sunLit = vec3(1.04, 0.99, 0.88) * (ndl * 0.82 + wrap * 0.28);
  vec3 lighting = skyAmb * 0.46 + sunLit + bounce;

  vec3 col = vCol * lighting * (0.58 + 0.42 * vAO);

  // Glossy painted fiberglass / sunglasses / beak / chrome specular sheen
  float shin = mix(20.0, 72.0, vMet);
  float spec = pow(max(dot(N, H), 0.0), shin) * (0.16 + 0.68 * vMet);
  col += vec3(1.0, 0.99, 0.94) * spec;

  // Rim sky highlight for crisp 3D silhouettes against bright ocean sky
  float rim = pow(1.0 - max(abs(N.z), 0.0), 2.3);
  col += vec3(0.75, 0.93, 1.0) * rim * 0.16;

  // Hull keel or pelican belly resting in water receives wet turquoise tint below y = 0
  float subK = smoothstep(1.5, -7.0, vWP.y);
  if (subK > 0.005) {
    vec3 wetCol = col * vec3(0.55, 0.90, 0.96);
    col = mix(col, mix(wetCol, waterCol(-vWP.y), 0.24), subK);
  }

  gl_FragColor = vec4(col, 1.0);
}`,
  });
}

// ------------------------------------------------------------------ Composite 3D Pelican Geometry (faces +X)
function buildSculptedPelicanBeak(): PartSpec[] {
  const parts: PartSpec[] = [];
  const beakGold: RGB = [0.98, 0.75, 0.2];
  const beakTipRed: RGB = [0.94, 0.28, 0.14];
  const pouchPeach: RGB = [0.98, 0.54, 0.34];
  const rimCream: RGB = [1.0, 0.9, 0.66];

  // 1) Long sculpted Upper Bill (culmen): broad at forehead, flat arched ridge, sleek sharp tip at x=20
  const upperMainLoops: THREE.Vector3[][] = [];
  const upperHookLoops: THREE.Vector3[][] = [];
  const nMain = 9;
  for (let i = 0; i <= nMain; i++) {
    const t = i / nMain; // 0..0.88 span of main golden culmen
    const u = t * 0.88;
    const x = 8.4 + u * 11.4;
    const w = (1 - u * 0.84) * 1.42;
    const h = (1 - u * 0.68) * 1.02;
    const yRim = 7.25 - u * 0.65 - u * u * 0.25;
    const yTop = yRim + h + Math.sin(u * Math.PI) * 0.18;
    upperMainLoops.push([
      new THREE.Vector3(x, yTop, 0),
      new THREE.Vector3(x, yRim + h * 0.58, w * 0.68),
      new THREE.Vector3(x, yRim, w),
      new THREE.Vector3(x, yRim - 0.12, 0),
      new THREE.Vector3(x, yRim, -w),
      new THREE.Vector3(x, yRim + h * 0.58, -w * 0.68),
    ]);
  }
  parts.push({ g: loftRings(upperMainLoops, true, true), col: beakGold, met: 0.44, ao: 1.0, part: 6 });

  // Signature downward-hooked orange-red tip nail (unguiculus) seamlessly continuing main culmen
  const hookPts: [number, number, number, number][] = [
    [0.86, 0.0, 1.0, 1.0],
    [0.92, -0.08, 0.82, 0.88],
    [0.97, -0.34, 0.52, 0.62],
    [1.01, -0.82, 0.18, 0.25],
  ];
  for (const [u, hookDrop, wf, hf] of hookPts) {
    const x = 8.4 + u * 11.4;
    const w = (1 - 0.88 * 0.84) * 1.42 * wf;
    const h = (1 - 0.88 * 0.68) * 1.02 * hf;
    const yRim = 7.25 - u * 0.65 - u * u * 0.25 + hookDrop;
    const yTop = yRim + h;
    upperHookLoops.push([
      new THREE.Vector3(x, yTop, 0),
      new THREE.Vector3(x, yRim + h * 0.55, w * 0.68),
      new THREE.Vector3(x, yRim, w),
      new THREE.Vector3(x, yRim - 0.16, 0),
      new THREE.Vector3(x, yRim, -w),
      new THREE.Vector3(x, yRim + h * 0.55, -w * 0.68),
    ]);
  }
  parts.push({ g: loftRings(upperHookLoops, true, true), col: beakTipRed, met: 0.48, ao: 1.0, part: 6 });

  // 2) Graceful Lower Mandible Jaw Rim + Tucked Elastic Gular Throat Pouch
  // Profile follows the upper bill edge underneath, bowing smoothly beneath the jaw without bulging past the bill sides
  const pouchLoops: THREE.Vector3[][] = [];
  const jawRimLoops: THREE.Vector3[][] = [];
  const nPouch = 10;
  for (let i = 0; i <= nPouch; i++) {
    const u = i / nPouch;
    const x = 8.2 + u * 11.0;
    const wRim = (1 - u * 0.86) * 1.28;
    const yRim = 7.12 - u * 0.66 - u * u * 0.22;
    // Sleek pelican throat-pouch curve: deepest in the rear throat-mid area, tapering cleanly to tip
    const drop = Math.sin(Math.PI * Math.pow(u, 0.62)) * 2.25;
    const wBelly = wRim * 0.72;
    pouchLoops.push([
      new THREE.Vector3(x, yRim - 0.05, wRim * 0.82),
      new THREE.Vector3(x, yRim - drop * 0.52, wBelly),
      new THREE.Vector3(x, yRim - drop, 0),
      new THREE.Vector3(x, yRim - drop * 0.52, -wBelly),
      new THREE.Vector3(x, yRim - 0.05, -wRim * 0.82),
      new THREE.Vector3(x, yRim + 0.05, 0),
    ]);
    jawRimLoops.push([
      new THREE.Vector3(x, yRim + 0.08, 0),
      new THREE.Vector3(x, yRim + 0.05, wRim),
      new THREE.Vector3(x, yRim - 0.22, wRim * 0.88),
      new THREE.Vector3(x, yRim - 0.16, 0),
      new THREE.Vector3(x, yRim - 0.22, -wRim * 0.88),
      new THREE.Vector3(x, yRim + 0.05, -wRim),
    ]);
  }
  parts.push({ g: loftRings(pouchLoops, true, true), col: pouchPeach, met: 0.14, ao: 0.94, part: 6 });
  parts.push({ g: loftRings(jawRimLoops, true, true), col: rimCream, met: 0.34, ao: 1.0, part: 6 });

  return parts;
}

function buildPelicanGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const white: RGB = [0.98, 0.97, 0.94];
  const cream: RGB = [0.96, 0.92, 0.82];
  const mantleGray: RGB = [0.68, 0.74, 0.8];
  const wingTip: RGB = [0.16, 0.19, 0.25];
  const eyeDark: RGB = [0.05, 0.06, 0.09];
  const eyeRingYellow: RGB = [0.98, 0.84, 0.36];
  const footOrange: RGB = [0.96, 0.52, 0.16];

  // Plump streamlined boat-shaped body (bow chest at +X, tail at -X)
  const body = new THREE.SphereGeometry(4.4, 16, 12);
  body.scale(1.62, 0.92, 0.84);
  parts.push({ g: body, col: white, met: 0.08, ao: 0.95 });

  // Soft silver-gray dorsal feather saddle
  const saddle = new THREE.SphereGeometry(3.8, 12, 9, 0, Math.PI * 2, 0, Math.PI * 0.55);
  saddle.scale(1.55, 0.75, 0.8);
  saddle.translate(-0.6, 1.4, 0);
  parts.push({ g: saddle, col: mantleGray, met: 0.06, ao: 0.92 });

  // Fanned tail feathers flaring cleanly backward (-X)
  const tail = new THREE.ConeGeometry(2.5, 6.2, 5);
  tail.rotateZ(-Math.PI / 2 + 0.18);
  tail.scale(1.0, 0.36, 1.25);
  tail.translate(-8.2, 0.8, 0);
  parts.push({ g: tail, col: wingTip, met: 0.05, ao: 0.88 });

  // Graceful S-curved neck (part = 6.0 so swimming pelicans can bob & dip!)
  const neckCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(4.2, 0.8, 0),
    new THREE.Vector3(5.6, 3.0, 0),
    new THREE.Vector3(5.2, 6.0, 0),
    new THREE.Vector3(6.8, 7.6, 0),
  ]);
  const neck = new THREE.TubeGeometry(neckCurve, 12, 1.65, 8, false);
  parts.push({ g: neck, col: white, met: 0.08, ao: 0.96, part: 6 });

  // Rounded head + cheerful cream nape crest
  const head = new THREE.SphereGeometry(2.35, 14, 10);
  head.scale(1.12, 0.96, 0.9);
  head.translate(7.3, 7.8, 0);
  parts.push({ g: head, col: white, met: 0.1, ao: 0.98, part: 6 });

  const crest = new THREE.ConeGeometry(1.0, 3.2, 6);
  crest.rotateZ(Math.PI * 0.62);
  crest.scale(1.0, 0.55, 0.65);
  crest.translate(5.0, 9.1, 0);
  parts.push({ g: crest, col: cream, met: 0.06, ao: 0.95, part: 6 });

  // Expressive golden eye ring + glossy dark eyes
  for (const sz of [-1, 1]) {
    const ring = new THREE.SphereGeometry(0.76, 8, 8);
    ring.scale(1.0, 0.9, 0.6);
    ring.translate(7.9, 8.3, sz * 1.72);
    parts.push({ g: ring, col: eyeRingYellow, met: 0.15, ao: 1.0, part: 6 });

    const eye = new THREE.SphereGeometry(0.5, 8, 8);
    eye.translate(8.15, 8.35, sz * 1.92);
    parts.push({ g: eye, col: eyeDark, met: 0.92, ao: 1.0, part: 6 });
  }

  // Sculpted long golden-amber pelican bill + hooked red-orange tip + sleek peach throat pouch
  parts.push(...buildSculptedPelicanBeak());

  // Articulated flapping/folding left & right wings (part = 1.0, swept neatly back -X)
  for (const sz of [-1, 1]) {
    const innerW = new THREE.BoxGeometry(6.8, 0.75, 9.2);
    innerW.rotateY(-sz * 0.14);
    innerW.translate(0.1, 1.8, sz * 6.5);
    parts.push({ g: innerW, col: white, met: 0.08, ao: 0.96, part: 1 });

    const outerW = new THREE.ConeGeometry(2.8, 8.8, 5);
    outerW.rotateX(sz * Math.PI * 0.5);
    outerW.rotateY(-sz * 0.36);
    outerW.rotateZ(0.2);
    outerW.scale(1.35, 0.25, 1.0);
    outerW.translate(-1.8, 2.0, sz * 14.0);
    parts.push({ g: outerW, col: wingTip, met: 0.06, ao: 0.9, part: 1 });
  }

  // Tucked orange webbed feet
  for (const sz of [-1, 1]) {
    const leg = new THREE.CylinderGeometry(0.35, 0.3, 3.2, 6);
    leg.rotateZ(-1.1);
    leg.translate(-4.6, -2.5, sz * 1.4);
    parts.push({ g: leg, col: footOrange, met: 0.2, ao: 0.85 });

    const web = new THREE.ConeGeometry(1.1, 2.4, 3);
    web.rotateZ(-Math.PI / 2);
    web.scale(1.0, 0.25, 0.9);
    web.translate(-6.4, -3.2, sz * 1.4);
    parts.push({ g: web, col: footOrange, met: 0.2, ao: 0.85 });
  }

  return mergeSurfaceParts(parts);
}

// ------------------------------------------------------------------ Stylized Diver-Proportioned Tourist Character Builder
// Uses clean PENYELAM diver anatomy (Dear Flight head + smooth torso + posed arms + posed legs),
// omitting ALL scuba gear (helmet, copper corselet, belts, tanks, boots, fins) for crisp resort attire!
interface TouristOutfitSpec {
  x: number;
  y: number;
  z: number;
  yaw: number;
  scale?: number;
  pose?: "stand" | "sit" | "drive";
  shirt: RGB;
  collar: RGB;
  shorts: RGB;
  skin: RGB;
  hair: RGB;
  hat?: "straw" | "captain" | "cap" | "none";
  hatCol?: RGB;
  hatBand?: RGB;
  sunglasses?: boolean;
  camera?: boolean;
  waveArm?: boolean;
}

function buildDiverTouristMerged(
  divSource: ReturnType<typeof buildDiverMesh>,
  cfg: TouristOutfitSpec,
): MergedRaw {
  const s = cfg.scale ?? 21.0;
  const pose = cfg.pose ?? "stand";
  const dv = new DataView(divSource.vb);
  const posArr: number[] = [];
  const normArr: number[] = [];
  const colArr: number[] = [];
  const metArr: number[] = [];
  const aoArr: number[] = [];
  const partArr: number[] = [];

  const qRot = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), cfg.yaw);
  const v = new THREE.Vector3();
  const n = new THREE.Vector3();

  const colorForVertex = (mat: number, part: number, lx: number, ly: number): [RGB, number] => {
    if (part === 1) {
      if (mat === 51) return [cfg.hair, 0.08];
      if (mat === 53) return [[0.56, 0.14, 0.14], 0.12];
      if (mat === 55) return [[cfg.skin[0] * 0.85, cfg.skin[1] * 0.72, cfg.skin[2] * 0.68], 0.08];
      if (mat === 56) return [[cfg.hair[0] * 0.72, cfg.hair[1] * 0.72, cfg.hair[2] * 0.72], 0.08];
      if (mat === 58 && !cfg.sunglasses) {
        const dEye = Math.hypot(Math.abs(lx) - 0.0435, ly - 0.795);
        if (dEye < 0.017) return [[0.06, 0.08, 0.14], 0.88];
        if (dEye < 0.025) return [[0.96, 0.98, 1.0], 0.45];
      }
      return [cfg.skin, 0.1];
    }
    if (part === 0) {
      // Casual waistband shorts transition at lower hip + shirt neck V-trim
      if (ly < 0.345) return [cfg.shorts, 0.1];
      if (ly > 0.585) return [cfg.collar, 0.14];
      // Clean resort Hawaiian / nautical pattern stripes
      const stripe = Math.sin(ly * 46 + lx * 32) > 0.38;
      if (stripe) {
        return [
          [
            Math.min(1, cfg.shirt[0] * 0.8 + cfg.collar[0] * 0.25 + 0.08),
            Math.min(1, cfg.shirt[1] * 0.8 + cfg.collar[1] * 0.25 + 0.08),
            Math.min(1, cfg.shirt[2] * 0.8 + cfg.collar[2] * 0.25 + 0.08),
          ],
          0.1,
        ];
      }
      return [cfg.shirt, 0.1];
    }
    if (part === 2 || part === 3) {
      // Short-sleeve summer shirt upper sleeve + bare forearm & skin hands
      if (ly >= 0.475) return [cfg.shirt, 0.1];
      return [cfg.skin, 0.1];
    }
    // Legs (part === 4, 5): resort beach shorts + bare legs + bright deck sneakers
    if (ly >= 0.155) return [cfg.shorts, 0.1];
    if (ly >= 0.085) return [cfg.skin, 0.1];
    return [[0.96, 0.97, 0.99], 0.22];
  };

  const rotX = (vx: number, vy: number, vz: number, px: number, py: number, pz: number, ang: number) => {
    const c = Math.cos(ang),
      sn = Math.sin(ang);
    const dy = vy - py,
      dz = vz - pz;
    return [vx, py + dy * c - dz * sn, pz + dy * sn + dz * c];
  };

  const pushTriVertex = (vi: number) => {
    const o = vi * 20;
    let lx = dv.getFloat32(o, true);
    let ly = dv.getFloat32(o + 4, true);
    let lz = dv.getFloat32(o + 8, true);
    let nx = dv.getInt8(o + 12) / 127;
    let ny = dv.getInt8(o + 13) / 127;
    let nz = dv.getInt8(o + 14) / 127;
    const ao = Math.max(0, dv.getInt8(o + 15) / 127);
    const mat = dv.getUint8(o + 16);
    const part = dv.getUint8(o + 17);

    // Compute shirt color BEFORE pose transforms so short sleeves / shorts follow limb UV!
    const [rgb, met] = colorForVertex(mat, part, lx, ly);

    // Pose 1: Driving / Steering at the helm wheel (both arms extended forward -Z & inward)
    if (pose === "drive" && (part === 2 || part === 3)) {
      const side = part === 2 ? -1 : 1;
      const sx = side * 0.155,
        sy = 0.542,
        sz = 0.0;
      const [rx, ry, rz] = rotX(lx, ly, lz, sx, sy, sz, 1.18);
      lx = rx - side * Math.max(0, -rz) * 0.28;
      ly = ry;
      lz = rz;
      const [nrx, nry, nrz] = rotX(nx, ny, nz, 0, 0, 0, 1.18);
      nx = nrx;
      ny = nry;
      nz = nrz;
    } else if (cfg.waveArm && part === 3) {
      // Pose 2: Happy waving right arm
      const sy = 0.542;
      const dx = lx - 0.155;
      const dy = ly - sy;
      const wa = 2.02;
      const c = Math.cos(wa),
        sn = Math.sin(wa);
      lx = 0.155 + dx * c - dy * sn;
      ly = sy + dx * sn + dy * c;
      const nrx = nx * c - ny * sn;
      const nry = nx * sn + ny * c;
      nx = nrx;
      ny = nry;
    }

    // Pose 3: Seated on bench! Bend thighs forward 82 deg (-Z) & lower legs back down 74 deg from knee
    if (pose === "sit" && (part === 4 || part === 5)) {
      const hipY = 0.285,
        hipZ = 0.0,
        kneeY = 0.175;
      const aThigh = 1.44;
      const cT = Math.cos(aThigh),
        sT = Math.sin(aThigh);
      const kneeWorldY = hipY + (kneeY - hipY) * cT;
      const kneeWorldZ = hipZ + (kneeY - hipY) * sT;

      if (ly >= kneeY) {
        [lx, ly, lz] = rotX(lx, ly, lz, lx, hipY, hipZ, aThigh);
        [nx, ny, nz] = rotX(nx, ny, nz, 0, 0, 0, aThigh);
      } else {
        const aShin = 0.12;
        const [tx, ty, tz] = rotX(lx, ly, lz, lx, kneeY, 0, aShin);
        lx = tx;
        ly = kneeWorldY + (ty - kneeY);
        lz = kneeWorldZ + tz;
        [nx, ny, nz] = rotX(nx, ny, nz, 0, 0, 0, aShin);
      }
    }

    // Seated casual arm pose: forearm bent slightly forward resting comfortably on lap
    if (pose === "sit" && (part === 2 || part === 3) && !cfg.waveArm) {
      const sy = 0.542,
        sz = 0.0;
      [lx, ly, lz] = rotX(lx, ly, lz, lx, sy, sz, 0.36);
      [nx, ny, nz] = rotX(nx, ny, nz, 0, 0, 0, 0.36);
    }

    v.set(lx * s, ly * s, lz * s).applyQuaternion(qRot);
    n.set(nx, ny, nz).applyQuaternion(qRot).normalize();

    posArr.push(cfg.x + v.x, cfg.y + v.y, cfg.z + v.z);
    normArr.push(n.x, n.y, n.z);
    colArr.push(rgb[0], rgb[1], rgb[2]);
    metArr.push(met);
    aoArr.push(Math.max(0.75, ao));
    partArr.push(pose === "stand" ? 5 : 0);
  };

  for (let t = 0; t < divSource.ib.length; t += 3) {
    const v0 = divSource.ib[t];
    const v1 = divSource.ib[t + 1];
    const v2 = divSource.ib[t + 2];
    const o0 = v0 * 20;
    const mat = dv.getUint8(o0 + 16);
    const part = dv.getUint8(o0 + 17);

    // Strip helmet (10), hoses (8), harpoon (9), flippers (6,7), tanks (6)
    if (part > 5 || mat === 6) continue;
    // On torso (part 0): strip copper corselet (1), brass bolts/buckle/knife (2), weight belt pouches (5), tank trim (8)!
    if (part === 0 && mat !== 0) continue;
    // On arms & legs: strip bulky brass diving cuffs & bulbous brass toe caps (mat === 2)
    if ((part >= 2 && part <= 5) && mat === 2) continue;

    pushTriVertex(v0);
    pushTriVertex(v1);
    pushTriVertex(v2);
  }

  // Clean Tourist Accessories in exact character space
  const accSpecs: PartSpec[] = [];
  const addAcc = (geo: THREE.BufferGeometry, col: RGB, met = 0.25) => {
    geo.scale(s, s, s);
    geo.applyQuaternion(qRot);
    geo.translate(cfg.x, cfg.y, cfg.z);
    accSpecs.push({ g: geo, col, met, ao: 0.96, part: pose === "stand" ? 5 : 0 });
  };

  // Casual slim leather belt or captain trim around waist
  const belt = new THREE.CylinderGeometry(0.122, 0.122, 0.024, 14);
  belt.scale(1.0, 1.0, 0.85);
  belt.translate(0, 0.348, 0);
  addAcc(belt, cfg.hat === "captain" ? [0.1, 0.15, 0.28] : [0.48, 0.28, 0.14], 0.2);

  if (cfg.sunglasses) {
    for (const sx of [-1, 1]) {
      const lens = new THREE.BoxGeometry(0.056, 0.032, 0.018);
      lens.translate(sx * 0.045, 0.794, -0.104);
      addAcc(lens, [0.05, 0.07, 0.13], 0.92);
    }
    const bridge = new THREE.BoxGeometry(0.034, 0.01, 0.014);
    bridge.translate(0, 0.802, -0.106);
    addAcc(bridge, [0.85, 0.72, 0.28], 0.85);
  }

  if (cfg.hat === "straw") {
    const brim = new THREE.CylinderGeometry(0.195, 0.205, 0.016, 14);
    brim.translate(0, 0.862, 0.005);
    addAcc(brim, cfg.hatCol ?? [0.95, 0.84, 0.56], 0.12);

    const crown = new THREE.CylinderGeometry(0.1, 0.115, 0.085, 14);
    crown.translate(0, 0.905, 0.005);
    addAcc(crown, cfg.hatCol ?? [0.95, 0.84, 0.56], 0.12);

    const band = new THREE.CylinderGeometry(0.117, 0.117, 0.022, 14);
    band.translate(0, 0.878, 0.005);
    addAcc(band, cfg.hatBand ?? cfg.shirt, 0.16);
  } else if (cfg.hat === "captain") {
    const capTop = new THREE.CylinderGeometry(0.128, 0.108, 0.072, 14);
    capTop.translate(0, 0.892, 0.005);
    addAcc(capTop, [0.98, 0.98, 0.99], 0.22);

    const band = new THREE.CylinderGeometry(0.11, 0.112, 0.03, 14);
    band.translate(0, 0.86, 0.005);
    addAcc(band, [0.08, 0.16, 0.36], 0.25);

    const visor = new THREE.BoxGeometry(0.15, 0.014, 0.095);
    visor.rotateX(0.18);
    visor.translate(0, 0.85, -0.105);
    addAcc(visor, [0.05, 0.07, 0.13], 0.78);
  } else if (cfg.hat === "cap") {
    const dome = new THREE.SphereGeometry(0.115, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.54);
    dome.translate(0, 0.855, 0.008);
    addAcc(dome, cfg.hatCol ?? cfg.shirt, 0.15);

    const peak = new THREE.BoxGeometry(0.14, 0.012, 0.085);
    peak.rotateX(0.12);
    peak.translate(0, 0.855, -0.102);
    addAcc(peak, cfg.hatBand ?? [0.98, 0.98, 0.98], 0.2);
  }

  if (cfg.camera) {
    const camBody = new THREE.BoxGeometry(0.11, 0.07, 0.045);
    camBody.translate(0, 0.49, -0.135);
    addAcc(camBody, [0.16, 0.18, 0.22], 0.55);

    const lens = new THREE.CylinderGeometry(0.025, 0.028, 0.045, 10);
    lens.rotateX(Math.PI / 2);
    lens.translate(0, 0.49, -0.168);
    addAcc(lens, [0.85, 0.9, 0.95], 0.88);
  }

  const accGeo = accSpecs.length ? mergeSurfaceParts(accSpecs) : null;
  const accCount = accGeo ? accGeo.getAttribute("position").count : 0;
  const baseCount = posArr.length / 3;
  const totalCount = baseCount + accCount;

  const pos = new Float32Array(totalCount * 3);
  const norm = new Float32Array(totalCount * 3);
  const col = new Float32Array(totalCount * 3);
  const met = new Float32Array(totalCount);
  const ao = new Float32Array(totalCount);
  const part = new Float32Array(totalCount);

  pos.set(posArr, 0);
  norm.set(normArr, 0);
  col.set(colArr, 0);
  met.set(metArr, 0);
  ao.set(aoArr, 0);
  part.set(partArr, 0);

  if (accGeo && accCount > 0) {
    pos.set(accGeo.getAttribute("position").array as Float32Array, baseCount * 3);
    norm.set(accGeo.getAttribute("normal").array as Float32Array, baseCount * 3);
    col.set(accGeo.getAttribute("aCol").array as Float32Array, baseCount * 3);
    met.set(accGeo.getAttribute("aMet").array as Float32Array, baseCount);
    ao.set(accGeo.getAttribute("aAO").array as Float32Array, baseCount);
    part.set(accGeo.getAttribute("aPart").array as Float32Array, baseCount);
    accGeo.dispose();
  }

  return { pos, norm, col, met, ao, part, count: totalCount };
}

// ------------------------------------------------------------------ Sculpted Lofted Boat Hull & Detailed Deck Props
interface HullStation {
  x: number;
  halfW: number;
  sheerY: number;
  chineY: number;
  keelY: number;
}

function buildSculptedBoatHullParts(
  stations: HullStation[],
  mainCol: RGB,
  keelCol: RGB,
  stripeCol: RGB,
  pinstripeCol: RGB,
  rubRailCol: RGB,
  deckCol: RGB,
): PartSpec[] {
  const parts: PartSpec[] = [];

  const upperLoops: THREE.Vector3[][] = [];
  const keelLoops: THREE.Vector3[][] = [];
  const stripeLoops: THREE.Vector3[][] = [];
  const pinLoops: THREE.Vector3[][] = [];
  const rubLoops: THREE.Vector3[][] = [];

  for (const st of stations) {
    const w = Math.max(0.25, st.halfW);
    const wMid = w * 0.94;
    const wChine = w * 0.80;
    const yMid = (st.sheerY + st.chineY) * 0.54;
    const wStripeTop = w * 0.98 + 0.45;
    const wStripeBot = w * 0.94 + 0.45;
    const yStrTop = st.sheerY - 2.4;
    const yStrBot = st.sheerY - 6.4;

    upperLoops.push([
      new THREE.Vector3(st.x, st.sheerY, w),
      new THREE.Vector3(st.x, yMid, wMid),
      new THREE.Vector3(st.x, st.chineY, wChine),
      new THREE.Vector3(st.x, st.keelY + 3.4, 0),
      new THREE.Vector3(st.x, st.chineY, -wChine),
      new THREE.Vector3(st.x, yMid, -wMid),
      new THREE.Vector3(st.x, st.sheerY, -w),
      new THREE.Vector3(st.x, st.sheerY + 0.35, 0),
    ]);

    keelLoops.push([
      new THREE.Vector3(st.x, st.chineY + 0.7, wChine * 0.96),
      new THREE.Vector3(st.x, st.keelY + 0.6, wChine * 0.28),
      new THREE.Vector3(st.x, st.keelY - 1.6, 0),
      new THREE.Vector3(st.x, st.keelY + 0.6, -wChine * 0.28),
      new THREE.Vector3(st.x, st.chineY + 0.7, -wChine * 0.96),
      new THREE.Vector3(st.x, st.chineY + 1.3, 0),
    ]);

    stripeLoops.push([
      new THREE.Vector3(st.x, yStrTop, wStripeTop),
      new THREE.Vector3(st.x, yStrBot, wStripeBot),
      new THREE.Vector3(st.x, yStrBot - 0.5, 0),
      new THREE.Vector3(st.x, yStrBot, -wStripeBot),
      new THREE.Vector3(st.x, yStrTop, -wStripeTop),
      new THREE.Vector3(st.x, yStrTop + 0.5, 0),
    ]);

    pinLoops.push([
      new THREE.Vector3(st.x, st.sheerY - 0.9, w + 0.45),
      new THREE.Vector3(st.x, st.sheerY - 2.2, w + 0.45),
      new THREE.Vector3(st.x, st.sheerY - 2.3, 0),
      new THREE.Vector3(st.x, st.sheerY - 2.2, -(w + 0.45)),
      new THREE.Vector3(st.x, st.sheerY - 0.9, -(w + 0.45)),
      new THREE.Vector3(st.x, st.sheerY - 0.8, 0),
    ]);

    rubLoops.push([
      new THREE.Vector3(st.x, st.sheerY + 1.4, w + 0.95),
      new THREE.Vector3(st.x, st.sheerY - 0.65, w + 0.95),
      new THREE.Vector3(st.x, st.sheerY - 0.75, 0),
      new THREE.Vector3(st.x, st.sheerY - 0.65, -(w + 0.95)),
      new THREE.Vector3(st.x, st.sheerY + 1.4, -(w + 0.95)),
      new THREE.Vector3(st.x, st.sheerY + 1.5, 0),
    ]);
  }

  parts.push({ g: loftRings(upperLoops, true, true), col: mainCol, met: 0.36, ao: 0.96 });
  parts.push({ g: loftRings(keelLoops, true, true), col: keelCol, met: 0.24, ao: 0.84 });
  parts.push({ g: loftRings(stripeLoops, true, true), col: stripeCol, met: 0.42, ao: 1.0 });
  parts.push({ g: loftRings(pinLoops, true, true), col: pinstripeCol, met: 0.38, ao: 1.0 });
  parts.push({ g: loftRings(rubLoops, true, true), col: rubRailCol, met: 0.3, ao: 0.92 });

  // Teak deck with longitudinal plank ribbing
  const firstX = stations[0].x;
  const lastX = stations[stations.length - 1].x;
  const deckLen = lastX - firstX - 24;
  const deckMid = (firstX + lastX) * 0.5 - 6;
  const deck = new THREE.BoxGeometry(deckLen, 1.8, 22);
  deck.translate(deckMid, 16.5, 0);
  parts.push({ g: deck, col: deckCol, met: 0.14, ao: 0.9 });

  const seamCol: RGB = [deckCol[0] * 0.6, deckCol[1] * 0.6, deckCol[2] * 0.6];
  for (const sz of [-7.5, -3.7, 0, 3.7, 7.5]) {
    const seam = new THREE.BoxGeometry(deckLen - 4, 0.35, 0.45);
    seam.translate(deckMid, 17.42, sz);
    parts.push({ g: seam, col: seamCol, met: 0.08, ao: 0.85 });
  }

  return parts;
}

function addShipWheel(parts: PartSpec[], x: number, y: number, z: number, radius: number, rimCol: RGB, spokeCol: RGB) {
  const wheelPitch = 0.55;
  const ring = new THREE.TorusGeometry(radius, radius * 0.14, 7, 16);
  ring.rotateY(Math.PI / 2);
  ring.rotateZ(wheelPitch);
  ring.translate(x, y, z);
  parts.push({ g: ring, col: rimCol, met: 0.82, ao: 1.0 });

  const hub = new THREE.CylinderGeometry(radius * 0.24, radius * 0.24, radius * 0.4, 8);
  hub.rotateZ(Math.PI / 2 + wheelPitch);
  hub.translate(x, y, z);
  parts.push({ g: hub, col: spokeCol, met: 0.86, ao: 1.0 });

  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI;
    const spoke = new THREE.CylinderGeometry(radius * 0.07, radius * 0.07, radius * 1.9, 5);
    spoke.rotateX(a);
    spoke.rotateZ(wheelPitch);
    spoke.translate(x, y, z);
    parts.push({ g: spoke, col: spokeCol, met: 0.86, ao: 1.0 });
  }
}

function addHullPortholes(parts: PartSpec[], xs: number[], y: number, zSide: number, ringCol: RGB, glassCol: RGB) {
  for (const px of xs) {
    for (const sz of [-1, 1]) {
      const bezel = new THREE.TorusGeometry(2.6, 0.58, 7, 14);
      bezel.rotateY(Math.PI / 2);
      bezel.translate(px, y, sz * zSide);
      parts.push({ g: bezel, col: ringCol, met: 0.9, ao: 1.0 });

      const pane = new THREE.CylinderGeometry(2.3, 2.3, 0.75, 12);
      pane.rotateX(Math.PI / 2);
      pane.translate(px, y, sz * (zSide - 0.1));
      parts.push({ g: pane, col: glassCol, met: 0.94, ao: 1.0 });
    }
  }
}

function addStripedLifebuoy(parts: PartSpec[], x: number, y: number, z: number, orangeCol: RGB, whiteCol: RGB) {
  for (let q = 0; q < 4; q++) {
    const arc = new THREE.TorusGeometry(3.8, 1.28, 8, 6, Math.PI * 0.48);
    arc.rotateZ(q * (Math.PI / 2));
    arc.translate(x, y, z);
    parts.push({ g: arc, col: q % 2 === 0 ? orangeCol : whiteCol, met: 0.28, ao: 1.0 });
  }
}

function addStripedBeachParasol(parts: PartSpec[], x: number, yBase: number, poleH: number, r: number, colA: RGB, colB: RGB, poleCol: RGB) {
  const pole = new THREE.CylinderGeometry(0.7, 0.78, poleH, 8);
  pole.translate(x, yBase + poleH * 0.5, 0);
  parts.push({ g: pole, col: poleCol, met: 0.16, ao: 0.95 });

  const yTop = yBase + poleH;
  const nSeg = 8;
  for (let i = 0; i < nSeg; i++) {
    const a0 = (i / nSeg) * Math.PI * 2;
    const a1 = ((i + 1) / nSeg) * Math.PI * 2;
    const aMid = (a0 + a1) * 0.5;
    const tris = new Float32Array([
      x, yTop + 4.2, 0,
      x + Math.cos(a0) * r, yTop - 3.6, Math.sin(a0) * r,
      x + Math.cos(a1) * r, yTop - 3.6, Math.sin(a1) * r,
    ]);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(tris, 3));
    g.computeVertexNormals();
    parts.push({ g, col: i % 2 === 0 ? colA : colB, met: 0.14, ao: 1.0 });

    const flap = new THREE.BoxGeometry(0.8, 2.2, (2 * Math.PI * r) / nSeg);
    flap.rotateY(-aMid);
    flap.translate(x + Math.cos(aMid) * (r * 0.95), yTop - 4.5, Math.sin(aMid) * (r * 0.95));
    parts.push({ g: flap, col: i % 2 === 0 ? colB : colA, met: 0.14, ao: 0.95 });
  }
  const finial = new THREE.SphereGeometry(1.2, 8, 6);
  finial.translate(x, yTop + 4.8, 0);
  parts.push({ g: finial, col: [0.98, 0.82, 0.22], met: 0.75, ao: 1.0 });
}

function addBuntingGarland(parts: PartSpec[], xStart: number, xEnd: number, yBase: number, z: number, sag: number, colors: RGB[]) {
  const n = colors.length;
  const lineCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(xStart, yBase, z),
    new THREE.Vector3((xStart + xEnd) * 0.5, yBase - sag, z),
    new THREE.Vector3(xEnd, yBase, z),
  ]);
  parts.push({ g: new THREE.TubeGeometry(lineCurve, 10, 0.22, 4, false), col: [0.95, 0.95, 0.92], met: 0.1, ao: 1.0 });

  for (let i = 0; i < n; i++) {
    const u = (i + 0.5) / n;
    const pt = lineCurve.getPoint(u);
    const tri = new THREE.ConeGeometry(2.1, 4.2, 3);
    tri.rotateX(Math.PI);
    tri.scale(1.0, 1.0, 0.22);
    tri.translate(pt.x, pt.y - 2.1, pt.z);
    parts.push({ g: tri, col: colors[i % colors.length], met: 0.12, ao: 1.0, part: 2 });
  }
}

function buildReefCruiserBoatGeometry(divSource: ReturnType<typeof buildDiverMesh>): THREE.BufferGeometry {
  const ivory: RGB = [0.98, 0.98, 0.96];
  const navyKeel: RGB = [0.08, 0.24, 0.50];
  const turquoise: RGB = [0.06, 0.76, 0.82];
  const coral: RGB = [1.0, 0.40, 0.26];
  const sunGold: RGB = [1.0, 0.80, 0.18];
  const teak: RGB = [0.76, 0.48, 0.24];
  const chrome: RGB = [0.88, 0.93, 0.98];
  const glass: RGB = [0.34, 0.82, 0.96];
  const cushionCream: RGB = [0.97, 0.95, 0.90];
  const charcoal: RGB = [0.14, 0.18, 0.25];

  const stations: HullStation[] = [
    { x: -64, halfW: 13.5, sheerY: 19.2, chineY: 5.5, keelY: -3.0 },
    { x: -50, halfW: 15.0, sheerY: 19.4, chineY: 5.2, keelY: -3.5 },
    { x: -28, halfW: 16.0, sheerY: 19.8, chineY: 5.0, keelY: -3.8 },
    { x: -4, halfW: 16.2, sheerY: 20.4, chineY: 5.0, keelY: -3.8 },
    { x: 20, halfW: 15.4, sheerY: 21.4, chineY: 5.5, keelY: -3.6 },
    { x: 42, halfW: 13.0, sheerY: 23.0, chineY: 7.0, keelY: -2.4 },
    { x: 60, halfW: 9.0, sheerY: 25.4, chineY: 9.6, keelY: -0.2 },
    { x: 74, halfW: 4.4, sheerY: 28.2, chineY: 14.0, keelY: 3.8 },
    { x: 83, halfW: 0.45, sheerY: 30.6, chineY: 20.2, keelY: 10.5 },
  ];

  const parts = buildSculptedBoatHullParts(stations, ivory, navyKeel, turquoise, coral, charcoal, teak);

  // Port & starboard sculpted fiberglass coaming gunwales with cream padded bolster trim
  for (const sz of [-1, 1]) {
    const coaming = new THREE.BoxGeometry(92, 4.4, 2.2);
    coaming.translate(-16, 20.8, sz * 13.6);
    parts.push({ g: coaming, col: ivory, met: 0.36, ao: 0.96 });

    const bolster = new THREE.BoxGeometry(88, 1.4, 1.4);
    bolster.translate(-16, 23.2, sz * 12.8);
    parts.push({ g: bolster, col: turquoise, met: 0.2, ao: 0.98 });
  }
  addHullPortholes(parts, [-44, -22, 0, 22], 11.4, 15.0, chrome, glass);

  // Panoramic dark-tinted cruiser side cabin window strip forward
  for (const sz of [-1, 1]) {
    const win = new THREE.BoxGeometry(22, 3.8, 1.2);
    win.rotateZ(0.08);
    win.translate(38, 16.2, sz * 13.8);
    parts.push({ g: win, col: [0.12, 0.22, 0.34], met: 0.92, ao: 1.0 });
  }

  // Forward sculpted foredeck, translucent skylight deck hatch, bow anchor & coiled mooring line
  const bowDeck = new THREE.CylinderGeometry(7.2, 13.8, 38, 8);
  bowDeck.rotateZ(-Math.PI / 2);
  bowDeck.scale(1.0, 0.22, 1.05);
  bowDeck.translate(51, 22.8, 0);
  parts.push({ g: bowDeck, col: ivory, met: 0.36, ao: 0.98 });

  const hatch = new THREE.BoxGeometry(10, 1.0, 9.5);
  hatch.rotateZ(0.14);
  hatch.translate(54, 24.8, 0);
  parts.push({ g: hatch, col: glass, met: 0.92, ao: 1.0 });

  const ropeCoil = new THREE.TorusGeometry(2.8, 0.72, 6, 12);
  ropeCoil.rotateX(Math.PI / 2);
  ropeCoil.translate(65, 27.0, -3.5);
  parts.push({ g: ropeCoil, col: [0.92, 0.85, 0.66], met: 0.08, ao: 0.95 });

  const bowAnchor = new THREE.BoxGeometry(8.5, 1.6, 3.0);
  bowAnchor.rotateZ(0.24);
  bowAnchor.translate(82, 30.2, 0);
  parts.push({ g: bowAnchor, col: chrome, met: 0.92, ao: 1.0 });

  // Bow stainless pulpit guardrails following tapered bow contour cleanly
  for (const sz of [-1, 1]) {
    for (const [px, py, pz] of [
      [34, 25.0, sz * 11.8],
      [52, 27.0, sz * 9.4],
      [68, 29.4, sz * 4.8],
    ]) {
      const post = new THREE.CylinderGeometry(0.6, 0.6, 8.6, 6);
      post.translate(px, py, pz);
      parts.push({ g: post, col: chrome, met: 0.92, ao: 1.0 });
    }
    const bowCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(34, 29.3, sz * 11.8),
      new THREE.Vector3(52, 31.3, sz * 9.4),
      new THREE.Vector3(68, 33.7, sz * 4.8),
      new THREE.Vector3(77, 34.4, sz * 1.0),
    ]);
    parts.push({ g: new THREE.TubeGeometry(bowCurve, 10, 0.62, 6, false), col: chrome, met: 0.92, ao: 1.0 });
  }

  // Forward Helm Console + Sculpted Dash + Chartplotter + Captain Pedestal Chair + Wheel!
  const helmBase = new THREE.BoxGeometry(16.5, 13.5, 18.5);
  helmBase.translate(22, 24.0, 0);
  parts.push({ g: helmBase, col: ivory, met: 0.36, ao: 0.96 });

  const dashCap = new THREE.BoxGeometry(13.5, 2.2, 17.5);
  dashCap.translate(21, 31.2, 0);
  parts.push({ g: dashCap, col: navyKeel, met: 0.3, ao: 0.95 });

  const sonar = new THREE.BoxGeometry(1.5, 4.4, 6.2);
  sonar.rotateZ(0.45);
  sonar.translate(18, 33.4, -3.5);
  parts.push({ g: sonar, col: [0.18, 0.94, 0.98], met: 0.7, ao: 1.0 });

  const throttleShaft = new THREE.CylinderGeometry(0.42, 0.42, 4.8, 6);
  throttleShaft.rotateZ(0.35);
  throttleShaft.translate(17.5, 33.5, 5.8);
  parts.push({ g: throttleShaft, col: chrome, met: 0.9, ao: 1.0 });
  const throttleKnob = new THREE.SphereGeometry(0.95, 8, 6);
  throttleKnob.translate(16.7, 35.8, 5.8);
  parts.push({ g: throttleKnob, col: coral, met: 0.4, ao: 1.0 });

  addShipWheel(parts, 14.2, 29.8, 0.8, 4.2, charcoal, chrome);

  // 3-Panel Wrap-Around Curved Tinted Windshield with brushed silver mullions
  const centerPane = new THREE.BoxGeometry(1.4, 12.0, 14.5);
  centerPane.rotateZ(-0.44);
  centerPane.translate(25.2, 36.2, 0);
  parts.push({ g: centerPane, col: glass, met: 0.94, ao: 1.0 });
  for (const sz of [-1, 1]) {
    const sidePane = new THREE.BoxGeometry(11.0, 11.2, 1.2);
    sidePane.rotateZ(-0.22);
    sidePane.rotateY(-sz * 0.28);
    sidePane.translate(20.6, 36.2, sz * 8.4);
    parts.push({ g: sidePane, col: glass, met: 0.94, ao: 1.0 });

    const mullion = new THREE.CylinderGeometry(0.55, 0.55, 13.0, 6);
    mullion.rotateZ(-0.44);
    mullion.translate(25.0, 36.2, sz * 7.4);
    parts.push({ g: mullion, col: chrome, met: 0.92, ao: 1.0 });
  }
  const shieldBar = new THREE.BoxGeometry(2.0, 1.3, 16.5);
  shieldBar.translate(22.6, 41.6, 0);
  parts.push({ g: shieldBar, col: chrome, met: 0.92, ao: 1.0 });

  // Cushioned Passenger Lounge Benches + Slatted Teak Cocktail Table + Tropical Drinks
  const aftBench = new THREE.BoxGeometry(11.5, 3.8, 22);
  aftBench.translate(-46, 19.2, 0);
  parts.push({ g: aftBench, col: teak, met: 0.14, ao: 0.92 });
  const aftPad = new THREE.BoxGeometry(10.5, 1.4, 21);
  aftPad.translate(-46, 21.8, 0);
  parts.push({ g: aftPad, col: cushionCream, met: 0.14, ao: 0.98 });

  const midBench = new THREE.BoxGeometry(26, 3.6, 7.6);
  midBench.translate(-14, 19.2, -8.5);
  parts.push({ g: midBench, col: teak, met: 0.14, ao: 0.92 });
  const midPad = new THREE.BoxGeometry(25, 1.4, 6.8);
  midPad.translate(-14, 21.6, -8.5);
  parts.push({ g: midPad, col: turquoise, met: 0.16, ao: 1.0 });
  const midBack = new THREE.BoxGeometry(25, 5.2, 1.8);
  midBack.translate(-14, 24.4, -11.4);
  parts.push({ g: midBack, col: cushionCream, met: 0.16, ao: 0.98 });
  const midPiping = new THREE.BoxGeometry(25.4, 1.0, 2.1);
  midPiping.translate(-14, 26.8, -11.4);
  parts.push({ g: midPiping, col: coral, met: 0.2, ao: 1.0 });

  const tblLeg = new THREE.CylinderGeometry(0.9, 1.1, 7.2, 8);
  tblLeg.translate(-12, 20.2, 2.5);
  parts.push({ g: tblLeg, col: chrome, met: 0.88, ao: 1.0 });
  const tblTop = new THREE.CylinderGeometry(5.2, 5.2, 1.1, 14);
  tblTop.translate(-12, 24.2, 2.5);
  parts.push({ g: tblTop, col: teak, met: 0.22, ao: 0.96 });
  for (const [cx, cz, cupCol] of [
    [-13.5, 1.5, coral],
    [-10.2, 3.4, sunGold],
  ] as [number, number, RGB][]) {
    const cup = new THREE.CylinderGeometry(0.85, 0.65, 2.2, 8);
    cup.translate(cx, 25.8, cz);
    parts.push({ g: cup, col: cupCol, met: 0.25, ao: 1.0 });
  }

  // Swept Curved Stainless Radar Arch + Sleek Hardtop Bimini Canopy + Solar Panels + Antennas!
  for (const sz of [-1, 1]) {
    const aftArch = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-48, 21, sz * 13.0),
      new THREE.Vector3(-46, 36, sz * 12.8),
      new THREE.Vector3(-40, 50.2, sz * 11.8),
    ]);
    parts.push({ g: new THREE.TubeGeometry(aftArch, 10, 0.95, 6, false), col: chrome, met: 0.92, ao: 1.0 });

    const fwdArch = new THREE.CatmullRomCurve3([
      new THREE.Vector3(16, 21, sz * 13.0),
      new THREE.Vector3(17, 36, sz * 12.6),
      new THREE.Vector3(13, 50.2, sz * 11.8),
    ]);
    parts.push({ g: new THREE.TubeGeometry(fwdArch, 10, 0.88, 6, false), col: chrome, met: 0.92, ao: 1.0 });
  }

  // Arched sculpted hardtop canopy + colorful stripes + solar skylight pads + coastal bunting
  const roofShell = new THREE.BoxGeometry(66, 2.2, 26.5);
  roofShell.translate(-14, 50.4, 0);
  parts.push({ g: roofShell, col: ivory, met: 0.36, ao: 0.98 });
  const roofTrim = new THREE.BoxGeometry(68, 1.4, 27.6);
  roofTrim.translate(-14, 49.6, 0);
  parts.push({ g: roofTrim, col: turquoise, met: 0.24, ao: 1.0 });
  for (let s = 0; s < 5; s++) {
    const band = new THREE.BoxGeometry(7.0, 2.45, 26.9);
    band.translate(-40 + s * 13, 50.5, 0);
    parts.push({ g: band, col: s % 2 === 0 ? turquoise : coral, met: 0.2, ao: 1.0 });
  }
  const solar = new THREE.BoxGeometry(16, 0.6, 14);
  solar.translate(-6, 51.8, 0);
  parts.push({ g: solar, col: [0.09, 0.16, 0.34], met: 0.9, ao: 1.0 });

  addBuntingGarland(parts, -44, 14, 48.2, 13.6, 3.2, [coral, sunGold, turquoise, [0.98, 0.98, 0.98], coral, sunGold]);

  // Radar dome, twin whip antennas, stern mast & fluttering pennant
  const radarDome = new THREE.SphereGeometry(3.4, 12, 8);
  radarDome.scale(1.2, 0.55, 1.2);
  radarDome.translate(6, 53.0, 0);
  parts.push({ g: radarDome, col: ivory, met: 0.45, ao: 1.0 });

  for (const sz of [-1, 1]) {
    const ant = new THREE.CylinderGeometry(0.18, 0.38, 16, 5);
    ant.rotateZ(0.22);
    ant.translate(10, 58.5, sz * 9.0);
    parts.push({ g: ant, col: chrome, met: 0.9, ao: 1.0 });
  }

  const mast = new THREE.CylinderGeometry(0.65, 0.85, 22, 6);
  mast.translate(-44, 60, 0);
  parts.push({ g: mast, col: chrome, met: 0.9, ao: 1.0 });

  const flag = new THREE.ConeGeometry(4.6, 13.5, 4);
  flag.rotateZ(Math.PI / 2);
  flag.scale(1.0, 1.0, 0.18);
  flag.translate(-51, 67, 0);
  parts.push({ g: flag, col: sunGold, met: 0.12, ao: 1.0, part: 2 });

  // Quad-striped lifebuoys + stern swim platform with boarding ladder + twin sculpted outboards
  for (const sz of [-1, 1]) {
    addStripedLifebuoy(parts, -26, 20.6, sz * 15.2, coral, ivory);
  }
  const swimStep = new THREE.BoxGeometry(8.2, 1.8, 24);
  swimStep.translate(-68, 10.5, 0);
  parts.push({ g: swimStep, col: teak, met: 0.15, ao: 0.92 });
  for (const rz of [10.0, 12.2]) {
    const rail = new THREE.CylinderGeometry(0.35, 0.35, 10, 5);
    rail.translate(-71.5, 8.2, rz);
    parts.push({ g: rail, col: chrome, met: 0.92, ao: 1.0 });
  }
  for (const ry of [4.8, 7.6, 10.4]) {
    const rung = new THREE.CylinderGeometry(0.3, 0.3, 2.4, 5);
    rung.rotateX(Math.PI / 2);
    rung.translate(-71.5, ry, 11.1);
    parts.push({ g: rung, col: chrome, met: 0.92, ao: 1.0 });
  }
  for (const sz of [-1, 1]) {
    const eng = new THREE.BoxGeometry(7.8, 11.5, 5.2);
    eng.translate(-66, 13.5, sz * 5.8);
    parts.push({ g: eng, col: charcoal, met: 0.76, ao: 0.9 });
    const cowlTop = new THREE.SphereGeometry(3.2, 8, 6);
    cowlTop.scale(1.3, 0.7, 0.85);
    cowlTop.translate(-66, 19.2, sz * 5.8);
    parts.push({ g: cowlTop, col: charcoal, met: 0.78, ao: 0.95 });
    const engStripe = new THREE.BoxGeometry(8.1, 2.2, 5.4);
    engStripe.translate(-66, 16.5, sz * 5.8);
    parts.push({ g: engStripe, col: turquoise, met: 0.45, ao: 1.0 });
    const prop = new THREE.CylinderGeometry(1.8, 1.8, 1.6, 6);
    prop.rotateZ(Math.PI / 2);
    prop.translate(-70.5, 6.2, sz * 5.8);
    parts.push({ g: prop, col: chrome, met: 0.92, ao: 0.95 });
  }

  // Stylized Driver + Seated & Standing Diver-Proportioned Tourists!
  const diverTourists: MergedRaw[] = [
    buildDiverTouristMerged(divSource, {
      x: 9.0,
      y: 18.0,
      z: 0.8,
      yaw: -Math.PI / 2,
      scale: 21.0,
      pose: "drive",
      shirt: [0.97, 0.98, 0.99],
      collar: [0.09, 0.24, 0.56],
      shorts: [0.1, 0.22, 0.46],
      skin: [0.92, 0.68, 0.5],
      hair: [0.22, 0.13, 0.07],
      hat: "captain",
    }),
    buildDiverTouristMerged(divSource, {
      x: -10,
      y: 16.8,
      z: -7.5,
      yaw: Math.PI,
      scale: 21.0,
      pose: "sit",
      shirt: [1.0, 0.36, 0.54],
      collar: [1.0, 0.86, 0.32],
      shorts: [0.95, 0.88, 0.68],
      skin: [0.96, 0.74, 0.58],
      hair: [0.28, 0.16, 0.08],
      hat: "straw",
      hatBand: [1.0, 0.36, 0.54],
      sunglasses: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: -24,
      y: 16.8,
      z: -7.5,
      yaw: Math.PI - 0.18,
      scale: 20.5,
      pose: "sit",
      shirt: [0.16, 0.8, 0.92],
      collar: [1.0, 0.5, 0.22],
      shorts: [0.18, 0.3, 0.5],
      skin: [0.85, 0.59, 0.43],
      hair: [0.16, 0.1, 0.06],
      hat: "cap",
      hatCol: sunGold,
      camera: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: -36,
      y: 17.4,
      z: 6.8,
      yaw: Math.PI - 0.22,
      scale: 21.0,
      pose: "stand",
      shirt: [1.0, 0.74, 0.18],
      collar: [0.22, 0.84, 0.58],
      shorts: [0.98, 0.96, 0.9],
      skin: [0.94, 0.7, 0.52],
      hair: [0.58, 0.34, 0.14],
      hat: "straw",
      hatBand: turquoise,
      sunglasses: true,
      waveArm: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: 42,
      y: 24.4,
      z: 2.5,
      yaw: Math.PI * 0.72,
      scale: 20.5,
      pose: "stand",
      shirt: [0.22, 0.86, 0.62],
      collar: [1.0, 0.92, 0.42],
      shorts: [0.18, 0.34, 0.62],
      skin: [0.9, 0.64, 0.47],
      hair: [0.18, 0.1, 0.06],
      camera: true,
    }),
  ];

  return mergeSurfaceParts(parts, diverTourists);
}

function buildIslandCanopyBoatGeometry(divSource: ReturnType<typeof buildDiverMesh>): THREE.BufferGeometry {
  const teak: RGB = [0.68, 0.4, 0.18];
  const cream: RGB = [0.99, 0.96, 0.88];
  const sunnyGold: RGB = [1.0, 0.78, 0.18];
  const royalBlue: RGB = [0.14, 0.44, 0.92];
  const coral: RGB = [1.0, 0.38, 0.36];
  const woodDark: RGB = [0.42, 0.22, 0.1];
  const chrome: RGB = [0.88, 0.92, 0.97];
  const glass: RGB = [0.45, 0.88, 0.98];

  const stations: HullStation[] = [
    { x: -60, halfW: 12.0, sheerY: 18.6, chineY: 5.5, keelY: -3.0 },
    { x: -42, halfW: 14.2, sheerY: 19.0, chineY: 5.0, keelY: -3.5 },
    { x: -16, halfW: 15.2, sheerY: 19.4, chineY: 4.8, keelY: -3.8 },
    { x: 10, halfW: 15.0, sheerY: 20.0, chineY: 5.0, keelY: -3.6 },
    { x: 34, halfW: 13.0, sheerY: 21.6, chineY: 6.2, keelY: -2.8 },
    { x: 54, halfW: 8.8, sheerY: 24.4, chineY: 9.2, keelY: -0.6 },
    { x: 70, halfW: 3.8, sheerY: 28.4, chineY: 14.5, keelY: 4.5 },
    { x: 79, halfW: 0.4, sheerY: 32.0, chineY: 22.0, keelY: 12.0 },
  ];

  const parts = buildSculptedBoatHullParts(stations, cream, royalBlue, sunnyGold, coral, woodDark, teak);

  // Carved traditional upturned tropical prow finial & chrome portholes
  const prowHorn = new THREE.ConeGeometry(2.4, 12, 6);
  prowHorn.rotateZ(-0.52);
  prowHorn.translate(79, 34.5, 0);
  parts.push({ g: prowHorn, col: woodDark, met: 0.22, ao: 0.96 });
  const prowGold = new THREE.SphereGeometry(1.5, 8, 6);
  prowGold.translate(82.2, 39.2, 0);
  parts.push({ g: prowGold, col: sunnyGold, met: 0.82, ao: 1.0 });
  addHullPortholes(parts, [-36, -12, 12], 11.2, 14.4, chrome, glass);

  // Varnished mahogany gunwale coaming trim + coiled bow dock line
  for (const sz of [-1, 1]) {
    const rail = new THREE.BoxGeometry(84, 3.6, 2.0);
    rail.translate(-14, 20.4, sz * 12.6);
    parts.push({ g: rail, col: woodDark, met: 0.2, ao: 0.95 });
  }
  const bowCoil = new THREE.TorusGeometry(2.6, 0.7, 6, 10);
  bowCoil.rotateX(Math.PI / 2);
  bowCoil.translate(58, 25.4, 2.5);
  parts.push({ g: bowCoil, col: [0.9, 0.82, 0.62], met: 0.08, ao: 0.94 });

  // Sculpted torpedo outrigger float (ama) lashed on gracefully arched curved wooden cross-booms (kiato)
  const ama = new THREE.CapsuleGeometry(3.1, 74, 5, 10);
  ama.rotateZ(Math.PI / 2);
  ama.translate(-4, 2.2, 24.5);
  parts.push({ g: ama, col: cream, met: 0.26, ao: 0.94 });
  const amaBand = new THREE.BoxGeometry(24, 2.2, 6.8);
  amaBand.translate(-4, 3.5, 24.5);
  parts.push({ g: amaBand, col: royalBlue, met: 0.34, ao: 1.0 });

  for (const bx of [-26, 18]) {
    const kiatoCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(bx, 18.2, 11.5),
      new THREE.Vector3(bx, 20.2, 18.0),
      new THREE.Vector3(bx, 13.5, 23.0),
      new THREE.Vector3(bx, 4.6, 24.5),
    ]);
    parts.push({ g: new THREE.TubeGeometry(kiatoCurve, 12, 1.05, 6, false), col: teak, met: 0.16, ao: 0.92 });
    const lashing = new THREE.CylinderGeometry(1.45, 1.45, 2.4, 8);
    lashing.translate(bx, 5.2, 24.5);
    parts.push({ g: lashing, col: sunnyGold, met: 0.14, ao: 0.98 });
  }

  // Aft Wooden Helm Pedestal + Brass Compass Binnacle + Brass Ship's Wheel + Engine
  const helmBox = new THREE.BoxGeometry(8.5, 11.5, 11);
  helmBox.translate(-35, 22.8, 0);
  parts.push({ g: helmBox, col: woodDark, met: 0.22, ao: 0.96 });
  const helmTop = new THREE.BoxGeometry(9.5, 1.8, 12);
  helmTop.translate(-35, 29.2, 0);
  parts.push({ g: helmTop, col: teak, met: 0.24, ao: 0.98 });
  const compass = new THREE.SphereGeometry(2.0, 10, 8);
  compass.translate(-34, 31.2, -3.0);
  parts.push({ g: compass, col: sunnyGold, met: 0.86, ao: 1.0 });
  addShipWheel(parts, -39.5, 29.0, 0.8, 4.4, teak, sunnyGold);

  const sternEng = new THREE.BoxGeometry(7.2, 11.0, 6.2);
  sternEng.translate(-62, 12.8, 0);
  parts.push({ g: sternEng, col: [0.14, 0.18, 0.25], met: 0.72, ao: 0.9 });

  // Cushioned teak passenger benches + picnic ice cooler + tropical fruit basket
  for (const sz of [-1, 1]) {
    const bench = new THREE.BoxGeometry(34, 3.6, 7.0);
    bench.translate(-8, 19.2, sz * 8.2);
    parts.push({ g: bench, col: teak, met: 0.14, ao: 0.92 });
    const pad = new THREE.BoxGeometry(33, 1.3, 6.4);
    pad.translate(-8, 21.5, sz * 8.2);
    parts.push({ g: pad, col: sz < 0 ? cream : coral, met: 0.16, ao: 1.0 });
  }
  const cooler = new THREE.BoxGeometry(9.0, 5.2, 6.2);
  cooler.translate(16, 19.8, 2.0);
  parts.push({ g: cooler, col: coral, met: 0.3, ao: 0.98 });
  const coolerLid = new THREE.BoxGeometry(9.4, 1.2, 6.6);
  coolerLid.translate(16, 22.8, 2.0);
  parts.push({ g: coolerLid, col: cream, met: 0.32, ao: 1.0 });

  // Turned wooden gazebo canopy posts + diagonal corner knee-braces + multi-striped pitched roof + coastal bunting!
  for (const px of [-36, 12]) {
    for (const sz of [-1, 1]) {
      const pole = new THREE.CylinderGeometry(0.95, 1.1, 30, 7);
      pole.translate(px, 33.5, sz * 11.4);
      parts.push({ g: pole, col: teak, met: 0.16, ao: 0.95 });

      const brace = new THREE.BoxGeometry(5.5, 1.1, 1.1);
      brace.rotateZ(px < 0 ? 0.68 : -0.68);
      brace.translate(px + (px < 0 ? 2.2 : -2.2), 45.2, sz * 11.4);
      parts.push({ g: brace, col: woodDark, met: 0.16, ao: 0.94 });
    }
  }
  const awning = new THREE.CylinderGeometry(16, 16, 58, 3);
  awning.rotateZ(Math.PI / 2);
  awning.scale(1.0, 0.42, 1.15);
  awning.translate(-12, 48.8, 0);
  parts.push({ g: awning, col: royalBlue, met: 0.16, ao: 0.96 });

  for (let st = 0; st < 4; st++) {
    const roofBand = new THREE.CylinderGeometry(16.2, 16.2, 6.5, 3);
    roofBand.rotateZ(Math.PI / 2);
    roofBand.scale(1.0, 0.42, 1.15);
    roofBand.translate(-32 + st * 13.5, 48.85, 0);
    parts.push({ g: roofBand, col: cream, met: 0.16, ao: 0.98 });
  }
  const ridgeBeam = new THREE.BoxGeometry(62, 1.8, 2.4);
  ridgeBeam.translate(-12, 55.6, 0);
  parts.push({ g: ridgeBeam, col: woodDark, met: 0.2, ao: 0.98 });

  const valance = new THREE.BoxGeometry(60, 2.8, 26.8);
  valance.translate(-12, 46.2, 0);
  parts.push({ g: valance, col: sunnyGold, met: 0.18, ao: 1.0 });

  addBuntingGarland(parts, -36, 12, 45.0, 13.5, 3.0, [coral, cream, sunnyGold, [0.06, 0.76, 0.82], coral, cream]);

  // 8-Panel Alternating Striped Beach Parasol Umbrella on foredeck!
  addStripedBeachParasol(parts, 32, 17.5, 23.0, 16.5, coral, cream, teak);

  // Boat Driver + Seated & Standing Diver-Proportioned Tourists!
  const diverTourists: MergedRaw[] = [
    buildDiverTouristMerged(divSource, {
      x: -44.2,
      y: 18.0,
      z: 0.8,
      yaw: -Math.PI / 2,
      scale: 20.5,
      pose: "drive",
      shirt: [0.96, 0.97, 0.98],
      collar: royalBlue,
      shorts: [0.16, 0.28, 0.48],
      skin: [0.85, 0.58, 0.4],
      hair: [0.16, 0.09, 0.05],
      hat: "captain",
    }),
    buildDiverTouristMerged(divSource, {
      x: -2,
      y: 16.8,
      z: -7.5,
      yaw: Math.PI + 0.12,
      scale: 21.0,
      pose: "sit",
      shirt: [1.0, 0.46, 0.22],
      collar: [1.0, 0.86, 0.28],
      shorts: [0.16, 0.32, 0.56],
      skin: [0.96, 0.75, 0.58],
      hair: [0.46, 0.26, 0.12],
      hat: "straw",
      hatBand: royalBlue,
      sunglasses: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: -18,
      y: 16.8,
      z: -7.5,
      yaw: Math.PI - 0.18,
      scale: 20.5,
      pose: "sit",
      shirt: [0.96, 0.36, 0.66],
      collar: [0.4, 0.92, 1.0],
      shorts: [0.96, 0.96, 0.98],
      skin: [0.85, 0.6, 0.43],
      hair: [0.2, 0.12, 0.08],
      hat: "cap",
      hatCol: [0.14, 0.56, 0.96],
      camera: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: 26,
      y: 17.8,
      z: 3.5,
      yaw: Math.PI - 0.32,
      scale: 21.0,
      pose: "stand",
      shirt: [0.22, 0.84, 0.62],
      collar: [1.0, 0.92, 0.4],
      shorts: [0.95, 0.88, 0.68],
      skin: [0.9, 0.64, 0.46],
      hair: [0.18, 0.11, 0.06],
      hat: "straw",
      hatBand: coral,
      sunglasses: true,
      waveArm: true,
    }),
  ];

  addStripedLifebuoy(parts, 22, 16.8, 14.8, coral, cream);

  const mast = new THREE.CylinderGeometry(0.65, 0.85, 19, 6);
  mast.translate(-38, 56, 0);
  parts.push({ g: mast, col: chrome, met: 0.84, ao: 1.0 });

  const flag = new THREE.ConeGeometry(4.5, 13.0, 4);
  flag.rotateZ(Math.PI / 2);
  flag.scale(1.0, 1.0, 0.18);
  flag.translate(-44.5, 62.5, 0);
  parts.push({ g: flag, col: coral, met: 0.12, ao: 1.0, part: 2 });

  return mergeSurfaceParts(parts, diverTourists);
}

function buildWakeFoamGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const foam: RGB = [0.85, 0.99, 1.0];

  for (let i = 0; i < 6; i++) {
    const t = i / 5;
    const w = 16 + t * 24;
    const puff = new THREE.SphereGeometry(4.2 - t * 1.4, 8, 6);
    puff.scale(1.8, 0.25, 0.85);
    puff.translate(-58 - t * 44, -0.5, (i % 2 ? 1 : -1) * (3 + t * 4));
    parts.push({ g: puff, col: foam, ao: 0.9 - t * 0.65, part: 4 });

    const bowRing = new THREE.BoxGeometry(w, 1.2, 2.2);
    bowRing.translate(48 - t * 68, -0.5, 14.5 + t * 1.5);
    parts.push({ g: bowRing, col: foam, ao: 0.72 - t * 0.48, part: 4 });
  }
  return mergeSurfaceParts(parts);
}

function buildSwimRippleGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const foam: RGB = [0.88, 0.99, 1.0];
  const outer = new THREE.TorusGeometry(9.0, 0.75, 5, 18);
  outer.rotateX(Math.PI / 2);
  outer.scale(1.35, 0.3, 0.7);
  parts.push({ g: outer, col: foam, ao: 0.72, part: 4 });

  const trail = new THREE.SphereGeometry(3.2, 8, 6);
  trail.scale(1.9, 0.22, 0.9);
  trail.translate(-10.5, 0, 0);
  parts.push({ g: trail, col: foam, ao: 0.56, part: 4 });
  return mergeSurfaceParts(parts);
}

// ------------------------------------------------------------------ Live Animated Manager
interface PelicanState {
  mode: "soar" | "skim" | "swim" | "perch";
  boatIdx: number;
  x: number;
  baseY: number;
  z: number;
  dir: number;
  speed: number;
  scale: number;
  ph: number;
  flapFreq: number;
  flapAmp: number;
  glideBias: number;
}

interface BoatState {
  style: 0 | 1;
  x: number;
  minX: number;
  maxX: number;
  z: number;
  dir: number;
  speed: number;
  scale: number;
  ph: number;
}

const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _scale = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _qTilt = new THREE.Quaternion();
const _qYaw = new THREE.Quaternion();
const _qRoll = new THREE.Quaternion();
const _axisX = new THREE.Vector3(1, 0, 0);
const _axisY = new THREE.Vector3(0, 1, 0);
const _axisZ = new THREE.Vector3(0, 0, 1);

/** Advance ping-pong trajectory monotonically so heading `dir` ALWAYS matches velocity dx/dt. */
function evalPatrol(
  x0: number,
  initDir: number,
  speed: number,
  t: number,
  minX: number,
  maxX: number,
): { x: number; dir: number } {
  const span = Math.max(1, maxX - minX);
  const xClamped = Math.max(minX, Math.min(maxX, x0));
  const u0 = initDir > 0 ? xClamped - minX : span * 2 - (xClamped - minX);
  const wrap = (((u0 + speed * t) % (span * 2)) + span * 2) % (span * 2);
  if (wrap <= span) return { x: minX + wrap, dir: 1 };
  return { x: maxX - (wrap - span), dir: -1 };
}

export class SurfaceProps3D {
  readonly group = new THREE.Group();
  private pelicansMesh: THREE.InstancedMesh;
  private swimRippleMesh: THREE.InstancedMesh;
  private boatsMeshes: [THREE.InstancedMesh, THREE.InstancedMesh];
  private wakeMesh: THREE.InstancedMesh;
  private pelicans: PelicanState[] = [];
  private swimIndices: number[] = [];
  private boats: BoatState[] = [];
  private disposables: { dispose: () => void }[] = [];

  constructor() {
    this.group.name = "coastal-surface-props";
    const rng = mulberry32(202607);

    // 1. Spawn 6 Tourist Boats across separated Z lanes & non-overlapping patrol sectors so boats NEVER clip!
    const sectors: [number, number][] = [
      [180, WORLD_W * 0.31],
      [WORLD_W * 0.35, WORLD_W * 0.65],
      [WORLD_W * 0.69, WORLD_W - 180],
    ];
    for (let s = 0; s < 3; s++) {
      const [sMin, sMax] = sectors[s];
      const mid = (sMin + sMax) * 0.5;
      // Foreground Lane (z = 16): Luxury Reef Sightseeing Cruiser
      this.boats.push({
        style: 0,
        x: mid - 120,
        minX: sMin,
        maxX: sMax,
        z: 16,
        dir: s % 2 === 0 ? 1 : -1,
        speed: 10.5 + rng() * 4.5,
        scale: 1.88,
        ph: rng() * Math.PI * 2,
      });
      // Mid-Distance Lane (z = 56): Tropical Island Canopy Boat
      this.boats.push({
        style: 1,
        x: mid + 140,
        minX: sMin,
        maxX: sMax,
        z: 56,
        dir: s % 2 === 0 ? -1 : 1,
        speed: 9.5 + rng() * 4.0,
        scale: 1.92,
        ph: rng() * Math.PI * 2,
      });
    }

    // 2. Spawn 14 2x-scaled 3D Pelicans:
    //    - 2 perched proudly atop boat roofs
    //    - 6 swimming buoyantly right on the ocean surface (wings folded, dipping sculpted bill)
    //    - 6 soaring & wave-skimming gracefully in the coastal sky
    for (let i = 0; i < 14; i++) {
      if (i < 2) {
        this.pelicans.push({
          mode: "perch",
          boatIdx: i * 2, // Boat 0 (Cruiser) and Boat 2 (Cruiser)
          x: 0,
          baseY: 50,
          z: 0,
          dir: i % 2 === 0 ? 1 : -1,
          speed: 0,
          scale: 1.56,
          ph: rng() * Math.PI * 2,
          flapFreq: 2.2,
          flapAmp: -1.0,
          glideBias: -0.35,
        });
      } else if (i < 8) {
        const idx = i - 2;
        this.swimIndices.push(i);
        this.pelicans.push({
          mode: "swim",
          boatIdx: -1,
          x: ((idx + 0.45) / 6) * WORLD_W + (rng() - 0.5) * 180,
          baseY: 2.6,
          z: 32 + rng() * 14,
          dir: i % 2 === 0 ? 1 : -1,
          speed: 11 + rng() * 6.5,
          scale: (0.86 + rng() * 0.16) * 2.0,
          ph: rng() * Math.PI * 2,
          flapFreq: 2.4,
          flapAmp: -1.0,
          glideBias: 0,
        });
      } else {
        const idx = i - 8;
        const isSkim = idx % 2 === 1;
        this.pelicans.push({
          mode: isSkim ? "skim" : "soar",
          boatIdx: -1,
          x: ((idx + 0.5) / 6) * WORLD_W + (rng() - 0.5) * 200,
          baseY: isSkim ? 48 + rng() * 22 : 96 + rng() * 76,
          z: 22 + rng() * 24,
          dir: i % 2 === 0 ? 1 : -1,
          speed: (isSkim ? 38 : 28) + rng() * 14,
          scale: (isSkim ? 0.88 : 0.8) * 2.0 + rng() * 0.35,
          ph: rng() * Math.PI * 2,
          flapFreq: 5.6 + rng() * 2.0,
          flapAmp: 0.62 + rng() * 0.18,
          glideBias: 0.12,
        });
      }
    }

    const solidMat = surfaceDaylightMaterial(false);
    const wakeMat = surfaceDaylightMaterial(true);
    this.disposables.push(solidMat, wakeMat);

    // ---- Instanced Tourist Boats (with PENYELAM diver-shaped captain + seated/standing tourists!)
    const divSource = buildDiverMesh();
    const cruiserGeo = buildReefCruiserBoatGeometry(divSource);
    const islandGeo = buildIslandCanopyBoatGeometry(divSource);
    const wakeGeo = buildWakeFoamGeometry();
    const swimRippleGeo = buildSwimRippleGeometry();
    this.disposables.push(cruiserGeo, islandGeo, wakeGeo, swimRippleGeo);

    const makeBoatInstanced = (geo: THREE.BufferGeometry, subset: BoatState[]): THREE.InstancedMesh => {
      const n = subset.length;
      const ctrl = new Float32Array(n * 4);
      subset.forEach((b, idx) => ctrl.set([b.ph, b.speed, 1, 0], idx * 4));
      geo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(ctrl, 4));
      const mesh = new THREE.InstancedMesh(geo, solidMat, n);
      mesh.frustumCulled = false;
      mesh.renderOrder = 22;
      this.group.add(mesh);
      return mesh;
    };

    const style0Boats = this.boats.filter((b) => b.style === 0);
    const style1Boats = this.boats.filter((b) => b.style === 1);
    this.boatsMeshes = [
      makeBoatInstanced(cruiserGeo, style0Boats),
      makeBoatInstanced(islandGeo, style1Boats),
    ];

    // ---- Instanced Boat Wake Foam
    const wakeCtrl = new Float32Array(this.boats.length * 4);
    this.boats.forEach((b, i) => wakeCtrl.set([b.ph, b.speed, 1, 0], i * 4));
    wakeGeo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(wakeCtrl, 4));
    this.wakeMesh = new THREE.InstancedMesh(wakeGeo, wakeMat, this.boats.length);
    this.wakeMesh.frustumCulled = false;
    this.wakeMesh.renderOrder = 21;
    this.group.add(this.wakeMesh);

    // ---- Instanced Water Ripples beneath Swimming Pelicans
    const ripCtrl = new Float32Array(this.swimIndices.length * 4);
    this.swimIndices.forEach((pi, i) => ripCtrl.set([this.pelicans[pi].ph, 1, 1, 0], i * 4));
    swimRippleGeo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(ripCtrl, 4));
    this.swimRippleMesh = new THREE.InstancedMesh(swimRippleGeo, wakeMat, this.swimIndices.length);
    this.swimRippleMesh.frustumCulled = false;
    this.swimRippleMesh.renderOrder = 21;
    this.group.add(this.swimRippleMesh);

    // ---- Instanced 3D Pelicans
    const pelicanGeo = buildPelicanGeometry();
    this.disposables.push(pelicanGeo);
    const pelCtrl = new Float32Array(this.pelicans.length * 4);
    this.pelicans.forEach((p, i) => pelCtrl.set([p.ph, p.flapAmp, p.flapFreq, p.glideBias], i * 4));
    pelicanGeo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(pelCtrl, 4));
    this.pelicansMesh = new THREE.InstancedMesh(pelicanGeo, solidMat, this.pelicans.length);
    this.pelicansMesh.frustumCulled = false;
    this.pelicansMesh.renderOrder = 24;
    this.group.add(this.pelicansMesh);

    this.update(0, -120);
  }

  update(t: number, camTop: number) {
    const visible = camTop < 280;
    this.group.visible = visible;
    if (!visible) return;

    const minX = 180;
    const maxX = WORLD_W - 180;

    let i0 = 0;
    let i1 = 0;
    const boatStates: { x: number; dir: number; bobY: number; scale: number; z: number }[] = [];

    for (let i = 0; i < this.boats.length; i++) {
      const b = this.boats[i];
      const pat = evalPatrol(b.x, b.dir, b.speed, t, b.minX, b.maxX);
      const bx = pat.x;
      const dir = pat.dir;

      const bobY = Math.sin(t * 1.45 + b.ph) * 2.4 + Math.cos(t * 2.3 + b.ph) * 0.6;
      const waveRoll = Math.sin(t * 1.2 + b.ph) * 0.028;
      boatStates.push({ x: bx, dir, bobY, scale: b.scale, z: b.z });

      _pos.set(bx, bobY, b.z);
      _scale.setScalar(b.scale);
      _qYaw.setFromAxisAngle(_axisY, dir > 0 ? -0.18 : Math.PI + 0.18);
      _qRoll.setFromAxisAngle(_axisZ, waveRoll);
      _qTilt.setFromAxisAngle(_axisX, 0.22);
      _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);

      _mat4.compose(_pos, _quat, _scale);
      if (b.style === 0) this.boatsMeshes[0].setMatrixAt(i0++, _mat4);
      else this.boatsMeshes[1].setMatrixAt(i1++, _mat4);

      _pos.set(bx, 0.5 + bobY * 0.2, b.z + 2);
      _qRoll.setFromAxisAngle(_axisZ, waveRoll * 0.2);
      _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);
      _mat4.compose(_pos, _quat, _scale);
      this.wakeMesh.setMatrixAt(i, _mat4);
    }
    this.boatsMeshes[0].instanceMatrix.needsUpdate = true;
    this.boatsMeshes[1].instanceMatrix.needsUpdate = true;
    this.wakeMesh.instanceMatrix.needsUpdate = true;

    let ripIdx = 0;
    for (let i = 0; i < this.pelicans.length; i++) {
      const p = this.pelicans[i];
      let px: number;
      let py: number;
      let pz: number;
      let dir: number;
      let bank = 0;

      if (p.mode === "perch" && p.boatIdx >= 0 && p.boatIdx < boatStates.length) {
        const bs = boatStates[p.boatIdx];
        const bStyle = this.boats[p.boatIdx].style;
        const localX = bStyle === 0 ? -18 : -10;
        const roofY = bStyle === 0 ? 51.6 : 53.6;
        px = bs.x + bs.dir * localX * bs.scale;
        py = roofY * bs.scale + 4.8 + bs.bobY;
        pz = bs.z + (bStyle === 0 ? 3 : 0);
        dir = bs.dir;
        bank = Math.sin(t * 1.2 + this.boats[p.boatIdx].ph) * 0.035;
      } else if (p.mode === "swim") {
        const pat = evalPatrol(p.x, p.dir, p.speed, t, minX, maxX);
        px = pat.x;
        dir = pat.dir;
        const waveBob = Math.sin(t * 1.8 + p.ph) * 1.6;
        py = p.baseY + waveBob;
        pz = p.z;
        bank = Math.sin(t * 1.5 + p.ph) * 0.04;

        _pos.set(px, 0.55 + waveBob * 0.2, pz);
        _scale.setScalar(p.scale);
        _qYaw.setFromAxisAngle(_axisY, dir > 0 ? -0.18 : Math.PI + 0.18);
        _qRoll.setFromAxisAngle(_axisZ, 0);
        _qTilt.setFromAxisAngle(_axisX, 0.22);
        _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);
        _mat4.compose(_pos, _quat, _scale);
        this.swimRippleMesh.setMatrixAt(ripIdx++, _mat4);
      } else {
        const pat = evalPatrol(p.x, p.dir, p.speed, t, minX, maxX);
        px = pat.x;
        dir = pat.dir;
        py = p.baseY + Math.sin(t * 1.3 + p.ph) * (p.mode === "skim" ? 7.5 : 14.5);
        pz = p.z + Math.cos(t * 0.7 + p.ph) * 8;
        bank = Math.cos(t * 1.3 + p.ph) * 0.14;
      }

      _pos.set(px, py, pz);
      _scale.setScalar(p.scale);
      _qYaw.setFromAxisAngle(_axisY, dir > 0 ? -0.34 : Math.PI + 0.34);
      _qRoll.setFromAxisAngle(_axisZ, bank);
      _qTilt.setFromAxisAngle(_axisX, 0.2);
      _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);
      _mat4.compose(_pos, _quat, _scale);
      this.pelicansMesh.setMatrixAt(i, _mat4);
    }
    this.pelicansMesh.instanceMatrix.needsUpdate = true;
    this.swimRippleMesh.instanceMatrix.needsUpdate = true;
  }

  dispose() {
    for (const d of this.disposables) d.dispose();
  }
}
