// ============================================================================
// MODE "DUNIA LAUT 3D" — shaders & materials
// Water column, god-rays, caustics, rock, coral & entity shading in the style of
// the Abyssal Garden dive scene (PENYELAM). Everything renders side-on with an
// orthographic camera so it stays pixel-aligned with the 2D game layer.
// ============================================================================
import * as THREE from "three";
import { WORLD_W } from "../ocean";

export const SUN_X_GL = WORLD_W * 0.56;

function createNoiseTexture(): THREE.DataTexture {
  const S = 128;
  const P = 16; // periodic integer lattice
  const grid = new Float32Array(P * P);
  for (let y = 0; y < P; y++) {
    for (let x = 0; x < P; x++) {
      const h = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
      grid[y * P + x] = h - Math.floor(h);
    }
  }
  const samplePeriodic = (px: number, py: number): [number, number, number] => {
    const ix = Math.floor(px);
    const iy = Math.floor(py);
    const fx = px - ix;
    const fy = py - iy;
    const ux = fx * fx * fx * (fx * (fx * 6 - 15) + 10);
    const uy = fy * fy * fy * (fy * (fy * 6 - 15) + 10);
    const dux = 30 * fx * fx * (fx * (fx - 2) + 1);
    const duy = 30 * fy * fy * (fy * (fy - 2) + 1);
    const x0 = ((ix % P) + P) % P;
    const y0 = ((iy % P) + P) % P;
    const x1 = (x0 + 1) % P;
    const y1 = (y0 + 1) % P;
    const a = grid[y0 * P + x0];
    const b = grid[y0 * P + x1];
    const c = grid[y1 * P + x0];
    const d = grid[y1 * P + x1];
    const k1 = b - a;
    const k2 = c - a;
    const k4 = a - b - c + d;
    return [
      a + k1 * ux + k2 * uy + k4 * ux * uy,
      dux * (k1 + k4 * uy),
      duy * (k2 + k4 * ux),
    ];
  };
  const data = new Uint8Array(S * S * 4);
  for (let iy = 0; iy < S; iy++) {
    const py = (iy / S) * P;
    for (let ix = 0; ix < S; ix++) {
      const px = (ix / S) * P;
      const [n1, dx, dy] = samplePeriodic(px, py);
      const [n2] = samplePeriodic(px * 2, py * 2);
      const [n4] = samplePeriodic(px * 4, py * 4);
      const fbm = n1 * 0.56 + n2 * 0.29 + n4 * 0.15;
      const idx = (iy * S + ix) * 4;
      data[idx] = Math.max(0, Math.min(255, Math.round(n1 * 255)));
      data[idx + 1] = Math.max(0, Math.min(255, Math.round((dx * 0.25 + 0.5) * 255)));
      data[idx + 2] = Math.max(0, Math.min(255, Math.round((dy * 0.25 + 0.5) * 255)));
      data[idx + 3] = Math.max(0, Math.min(255, Math.round(fbm * 255)));
    }
  }
  const tex = new THREE.DataTexture(data, S, S, THREE.RGBAFormat);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

const SHARED_NOISE_TEX = createNoiseTexture();

function createWaterLutTexture(): THREE.DataTexture {
  const W = 256;
  const H = 2;
  const ST_Y = [0, 300, 820, 1250, 1540, 2150, 2650];
  const ST_C: [number, number, number][] = [
    [0.3, 0.82, 0.86],
    [0.09, 0.58, 0.72],
    [0.035, 0.34, 0.56],
    [0.03, 0.21, 0.45],
    [0.05, 0.12, 0.34],
    [0.035, 0.07, 0.22],
    [0.02, 0.045, 0.14],
  ];
  const ST_C2: [number, number, number][] = [
    [0.22, 0.74, 0.7],
    [0.06, 0.48, 0.53],
    [0.04, 0.3, 0.42],
    [0.035, 0.2, 0.37],
    [0.045, 0.13, 0.3],
    [0.03, 0.08, 0.2],
    [0.02, 0.045, 0.14],
  ];
  const smoothstep = (e0: number, e1: number, x: number) => {
    const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0)));
    return t * t * (3 - 2 * t);
  };
  const data = new Uint8Array(W * H * 4);
  for (let row = 0; row < H; row++) {
    const pal = row === 0 ? ST_C : ST_C2;
    for (let x = 0; x < W; x++) {
      const y = (x / (W - 1)) * 2650;
      let r = pal[0][0],
        g = pal[0][1],
        b = pal[0][2];
      for (let i = 1; i < 7; i++) {
        const t = smoothstep(ST_Y[i - 1], ST_Y[i], y);
        r += (pal[i][0] - r) * t;
        g += (pal[i][1] - g) * t;
        b += (pal[i][2] - b) * t;
      }
      const idx = (row * W + x) * 4;
      data[idx] = Math.max(0, Math.min(255, Math.round(r * 255)));
      data[idx + 1] = Math.max(0, Math.min(255, Math.round(g * 255)));
      data[idx + 2] = Math.max(0, Math.min(255, Math.round(b * 255)));
      data[idx + 3] = 255;
    }
  }
  const tex = new THREE.DataTexture(data, W, H, THREE.RGBAFormat);
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

function createCausticsTexture(): THREE.DataTexture {
  const S = 256;
  const makeWorleyLayer = (cells: number, seedOffset: number) => {
    const ptsX = new Float32Array(cells * cells);
    const ptsY = new Float32Array(cells * cells);
    for (let cy = 0; cy < cells; cy++) {
      for (let cx = 0; cx < cells; cx++) {
        const h1 = Math.sin((cx + seedOffset) * 127.1 + (cy + seedOffset * 0.7) * 311.7) * 43758.5453123;
        const h2 = Math.sin((cx + seedOffset * 1.3) * 269.5 + (cy + seedOffset) * 183.3) * 43758.5453123;
        ptsX[cy * cells + cx] = 0.16 + 0.68 * (h1 - Math.floor(h1));
        ptsY[cy * cells + cx] = 0.16 + 0.68 * (h2 - Math.floor(h2));
      }
    }
    return { cells, ptsX, ptsY };
  };
  const layer0 = makeWorleyLayer(9, 0.0);
  const layer1 = makeWorleyLayer(12, 19.3);
  const layer2 = makeWorleyLayer(7, 41.7);

  const evalRippleFilaments = (
    u: number,
    v: number,
    layer: { cells: number; ptsX: Float32Array; ptsY: Float32Array },
    shiftX: number,
    shiftY: number,
    sharpness: number,
    warpAmp: number,
  ): number => {
    const TAU = Math.PI * 2;
    const wu = u + shiftX + warpAmp * Math.sin(v * TAU * 2.0 + u * TAU);
    const wv = v + shiftY + warpAmp * Math.cos(u * TAU * 2.0 - v * TAU);
    const cells = layer.cells;
    const px = (((wu % 1) + 1) % 1) * cells;
    const py = (((wv % 1) + 1) % 1) * cells;
    const ix = Math.floor(px);
    const iy = Math.floor(py);
    let d1 = 9;
    let d2 = 9;
    for (let dy = -1; dy <= 1; dy++) {
      const ny = (iy + dy + cells) % cells;
      for (let dx = -1; dx <= 1; dx++) {
        const nx = (ix + dx + cells) % cells;
        const idx = ny * cells + nx;
        const fx = ix + dx + layer.ptsX[idx] - px;
        const fy = iy + dy + layer.ptsY[idx] - py;
        const d = Math.hypot(fx, fy);
        if (d < d1) {
          d2 = d1;
          d1 = d;
        } else if (d < d2) {
          d2 = d;
        }
      }
    }
    const edge = Math.max(0, 1 - (d2 - d1) * sharpness);
    // Crisp refractive sunlit water ribbons with soft atmospheric falloff and zero dark bowl pits
    return Math.min(1, Math.pow(edge, 2.75) * 0.92 + Math.pow(edge, 1.35) * 0.14);
  };

  const data = new Uint8Array(S * S * 4);
  for (let y = 0; y < S; y++) {
    const v = y / S;
    for (let x = 0; x < S; x++) {
      const u = x / S;
      const c0 = evalRippleFilaments(u, v, layer0, 0.0, 0.0, 4.3, 0.024);
      const c1 = evalRippleFilaments(u, v, layer1, 0.37, 0.61, 4.6, 0.020);
      const c2 = evalRippleFilaments(u, v, layer2, 0.71, 0.23, 3.8, 0.026);
      const idx = (y * S + x) * 4;
      data[idx] = Math.round(c0 * 255);
      data[idx + 1] = Math.round(c1 * 255);
      data[idx + 2] = Math.round(c2 * 255);
      data[idx + 3] = 255;
    }
  }
  const tex = new THREE.DataTexture(data, S, S, THREE.RGBAFormat);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  return tex;
}

const SHARED_WATER_LUT = createWaterLutTexture();
const SHARED_CAUSTICS_TEX = createCausticsTexture();

/** uniforms shared (by reference) by every material in the scene */
export const SHARED = {
  uTime: { value: 0 },
  uReefView: { value: new THREE.Vector2(0, 0) },
  uCamC: { value: new THREE.Vector2(WORLD_W * 0.5, 500) }, // camera centre, world units (y down)
  uView: { value: new THREE.Vector2(800, 450) }, // view size, world units
  uCamTL: { value: new THREE.Vector2(0, 0) }, // camLeft, camTop
  uPx: { value: 2 }, // device pixels per world unit
  uLampCount: { value: 0 },
  uLampOrigin: { value: Array.from({ length: 7 }, () => new THREE.Vector4()) },
  uLampAxis: { value: Array.from({ length: 7 }, () => new THREE.Vector4()) },
  uBgStyle: { value: 0 }, // 0 = Game 1 ocean backdrop, 1 = Tropical Reef backdrop (Game 2)
  uWaterStyle: { value: 0 }, // 0 = Game 1 bright blue water & sunlight, 1 = Game 2 teal water
  uLightEnhance: { value: 1 }, // 1 = improved ocean lighting (After), 0 = original baseline (Before)
  uNoiseTex: { value: SHARED_NOISE_TEX },
  uWaterLut: { value: SHARED_WATER_LUT },
  uCausticTex: { value: SHARED_CAUSTICS_TEX },
};

export const COMMON = /* glsl */ `
uniform float uTime;
uniform vec2 uCamC;
uniform vec2 uView;
uniform vec2 uCamTL;
uniform float uPx;
uniform float uBgStyle;
uniform float uWaterStyle;
uniform float uLightEnhance;
uniform int uLampCount;
uniform vec4 uLampOrigin[7];
uniform vec4 uLampAxis[7];
uniform sampler2D uNoiseTex;
uniform sampler2D uWaterLut;
uniform sampler2D uCausticTex;

#define TAU 6.28318530718
#define SUN_X ${SUN_X_GL.toFixed(1)}

float hash11(float p){ p = fract(p * .1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){
  return texture2D(uNoiseTex, p * 0.0625).r;
}
float fbm2(vec2 p){
  float a = texture2D(uNoiseTex, p * 0.0625).a;
  float b = texture2D(uNoiseTex, p * 0.257 + vec2(0.37, 0.71)).r;
  return a * 0.72 + b * 0.28;
}

// value noise with analytic derivatives via precomputed gradient channels
vec3 fbmd(vec2 p){
  vec4 t1 = texture2D(uNoiseTex, p * 0.0625);
  vec4 t2 = texture2D(uNoiseTex, p * 0.126875 + vec2(0.37, 0.71));
  vec4 t3 = texture2D(uNoiseTex, p * 0.2575 + vec2(0.19, 0.43));
  float val = t1.r * 0.53 + t2.r * 0.27 + t3.a * 0.20;
  vec2 grad = ((t1.gb - 0.5) * 0.53 + (t2.gb - 0.5) * 0.548 + (t3.gb - 0.5) * 0.577) * 4.0;
  return vec3(val, grad);
}

// ---- water palette lookup (1 hardware texture fetch replaces 12 smoothsteps)
vec3 waterCol(float y){
  return texture2D(uWaterLut, vec2(clamp(y * 0.0003773585, 0., 1.), mix(0.25, 0.75, uWaterStyle))).rgb;
}
float sunK(float wy){ return exp(-max(wy, 0.) / 980.) * .93 + .07; }
vec3 absorbK(float wy){ return exp(-vec3(.00062, .00020, .00008) * max(wy, 0.)); }

// GPU-accelerated dual-layer scrolling caustic filaments with organic wave refraction
float caustics(vec2 uv, float time){
  vec2 wave = vec2(
    sin(uv.y * 8.4 + time * 0.92) * 0.014,
    cos(uv.x * 7.6 - time * 0.78) * 0.014
  );
  float a = texture2D(uCausticTex, uv * 0.85 + wave + vec2(time * 0.026, -time * 0.018)).r;
  float b = texture2D(uCausticTex, uv * 1.07 - wave * 0.85 + vec2(-time * 0.022, time * 0.029) + vec2(0.31, 0.59)).g;
  float net = a * 0.44 + b * 0.44 + (a * b) * 0.92;
  return smoothstep(0.18, 0.94, clamp(net, 0., 1.));
}

vec3 lightSurfaceC(vec3 alb, vec3 N, vec3 wp, float ao, float ck){
  float wy = -wp.y;
  vec3 L = normalize(vec3(-.40, .80, .45));
  float d = dot(N, L);
  float ndl = max(d, 0.);
  float wrap = d * .5 + .5;
  float sk = sunK(wy);
  vec3 wc = waterCol(wy);
  vec3 sunC = vec3(1., .95, .84) * sk * .92;
  vec3 hemi = mix(vec3(.12, .18, .30), wc * 1.12 + vec3(.22, .32, .36), N.y * .5 + .5);
  hemi = max(hemi, vec3(.12, .16, .28));
  vec3 col = alb * (hemi * .94 + sunC * (ndl * .90 + wrap * .28)) * ao * 1.24;
  float cAmt = smoothstep(1450., 260., wy) * ck;
  // Directional water caustics: illuminate upward sunlit ledges, softly graze mid-walls, never blast overhangs
  float dirMask = smoothstep(-0.16, 0.56, N.y) * (.22 + .78 * smoothstep(0.04, 0.76, ndl));
  if (cAmt > .012 && dirMask > .01) {
    float cs = caustics(wp.xy * .0095, uTime * .46);
    vec3 causTint = mix(vec3(.62, .94, .99), vec3(.98, .98, .88), sk);
    col += (alb * .52 + vec3(.06, .12, .14)) * causTint * cs * cAmt * dirMask * sk * (.55 + .35 * ao);
  }
  if (uLampCount > 0) {
    for(int i=0;i<7;i++){
      if(i>=uLampCount)break;
      vec3 off=wp-uLampOrigin[i].xyz;vec3 axis=uLampAxis[i].xyz;
      float along=dot(off,axis),reach=uLampOrigin[i].w;
      if(along>0.&&along<reach){
        float rad=1.4+along*abs(uLampAxis[i].w);
        vec3 side=off-axis*along;float fall=exp(-dot(side,side)/(rad*rad)*2.1);
        vec3 tint=uLampAxis[i].w>0.?vec3(1.0,.76,.39):vec3(.66,.87,1.);
        col+=(alb*.65+vec3(.045))*tint*fall*(1.-along/reach)*(.29+.71*max(0.,-dot(N,axis)));
      }
    }
  }
  col += alb * vec3(.025, .04, .075) * smoothstep(900., 2400., wy);
  return col * absorbK(wy);
}
vec3 lightSurface(vec3 alb, vec3 N, vec3 wp, float ao){ return lightSurfaceC(alb, N, wp, ao, 1.); }
`;

const SCREEN_VS = /* glsl */ `
varying vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }`;

// ---------------------------------------------------------------- backdrop (water volume)
export function backdropMaterial() {
  const loaded = { value: 0 };
  const shipLoaded = { value: 0 };
  const kelpLoaded = { value: 0 };
  const templeLoaded = { value: 0 };
  const lagoonLoaded = { value: 0 };
  const loader = new THREE.TextureLoader();
  const habitat = loader.load("/images/reef-habitat.webp", () => { loaded.value = 1; });
  const shipwreck = loader.load("/src/assets/images/ancient_shipwreck_bg_1795254425429.jpg", () => { shipLoaded.value = 1; });
  const kelp = loader.load("/src/assets/images/kelp_cathedral_bg_1795322568135.jpg", () => { kelpLoaded.value = 1; });
  const temple = loader.load("/src/assets/images/sunken_temple_bg_1795322569079.jpg", () => { templeLoaded.value = 1; });
  const lagoon = loader.load("/src/assets/images/crystal_lagoon_bg_1795322569691.jpg", () => { lagoonLoaded.value = 1; });
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uHabitat: { value: habitat },
      uHabitatReady: loaded,
      uShipwreck: { value: shipwreck },
      uShipwreckReady: shipLoaded,
      uKelp: { value: kelp },
      uKelpReady: kelpLoaded,
      uTemple: { value: temple },
      uTempleReady: templeLoaded,
      uLagoon: { value: lagoon },
      uLagoonReady: lagoonLoaded,
    },
    depthTest: false,
    depthWrite: false,
    vertexShader: SCREEN_VS,
    fragmentShader:
      COMMON +
      /* glsl */ `
varying vec2 vUv;
uniform sampler2D uHabitat;
uniform float uHabitatReady;
uniform sampler2D uShipwreck;
uniform float uShipwreckReady;
uniform sampler2D uKelp;
uniform float uKelpReady;
uniform sampler2D uTemple;
uniform float uTempleReady;
uniform sampler2D uLagoon;
uniform float uLagoonReady;
void main(){
  vec2 w = vec2(uCamTL.x + vUv.x * uView.x, uCamTL.y + (1. - vUv.y) * uView.y);
  float wy = w.y;
  vec3 col = waterCol(wy);
  float sx = SUN_X + (uCamC.x - SUN_X) * .86;
  float dx = w.x - sx;
  float top = exp(-max(wy, 0.) / 430.);
  col += vec3(.55, .88, .82) * exp(-dx * dx / (2. * 360. * 360.)) * top * mix(.42, .56, uLightEnhance);
  col += vec3(.10, .26, .30) * exp(-max(wy, 0.) / 760.) * mix(.28, .38, uLightEnhance);
  col = mix(col, vec3(.78, .97, .99), smoothstep(14., 0., wy) * .45);
  float n = fbm2(vec2((w.x - uCamC.x * .9) * .0034 + uTime * .012, wy * .0042 - uTime * .006));
  col *= .93 + .14 * n;
  col += vec3(.16, .07, .03) * smoothstep(2330., 2680., wy) * (.5 + .5 * fbm2(vec2(w.x * .004, uTime * .05))) * .5;

  float underwaterMask = smoothstep(-2., 12., wy);
  if (uBgStyle > 0.5 && underwaterMask > 0.002) {
    float isCustom169 = step(1.5, uBgStyle);
    float isKelp = step(2.5, uBgStyle) * (1.0 - step(3.5, uBgStyle));
    float isLagoon = step(4.5, uBgStyle);

    // Subtle ambient water color harmonization per ocean theme
    col = mix(col, col * vec3(.78, 1.07, .89) + vec3(0., .03, .01) * top, isKelp * .62 * underwaterMask);
    col = mix(col, col * vec3(.90, 1.05, 1.09) + vec3(.01, .04, .05) * top, isLagoon * .58 * underwaterMask);

    float texAspect = mix(3.0, 1.7778, isCustom169);
    float span = max(uView.x * 1.14, uView.y * texAspect * mix(1.22, 1.12, isCustom169));
    vec2 plane = vec2(span, span / texAspect);
    vec2 crop = (plane - uView) / plane;

    if (uBgStyle < 1.5) {
      if (uHabitatReady > 0.5 && uCamC.y < 1100.0) {
        vec2 uvReef = vUv * (1.0 - crop) + crop * vec2(.5 + .4 * sin(uCamTL.x * .0009), .75 - clamp(uCamTL.y / 1100.0, 0., .75));
        vec3 distantReef = texture2D(uHabitat, clamp(uvReef, 0., 1.)).rgb;
        vec3 brightReef = max(col * .90, distantReef * 1.38 + col * .28);
        vec3 reefCol = mix(brightReef, distantReef, uWaterStyle);
        float reefAmt = mix(.84, .96, uWaterStyle);
        float reefMix = (1.0 - smoothstep(520., 1100., uCamC.y)) * reefAmt * underwaterMask;
        col = mix(col, reefCol, reefMix);
      }
    } else if (uCamC.y < 1380.0) {
      float sceneDepthFade = (1.0 - smoothstep(680., 1380., uCamC.y)) * underwaterMask;
      vec2 uvScene = clamp(vUv * (1.0 - crop) + crop * vec2(.5 + .35 * sin(uCamTL.x * .00075), .78 - clamp(uCamTL.y / 1200.0, 0., .78)), 0., 1.);
      if (uBgStyle < 2.5) {
        if (uShipwreckReady > 0.5) {
          vec3 shipTex = texture2D(uShipwreck, uvScene).rgb;
          vec3 shipCol = mix(shipTex, max(col * .78, shipTex * 1.08 + col * .14), .48);
          col = mix(col, shipCol, sceneDepthFade * .92);
        }
      } else if (uBgStyle < 3.5) {
        if (uKelpReady > 0.5) {
          vec3 kelpTex = texture2D(uKelp, uvScene).rgb;
          vec3 kelpCol = mix(kelpTex, max(col * .80, kelpTex * 1.06 + col * .14), .36);
          col = mix(col, kelpCol, sceneDepthFade * .93);
        }
      } else if (uBgStyle < 4.5) {
        if (uTempleReady > 0.5) {
          vec3 templeTex = texture2D(uTemple, uvScene).rgb;
          vec3 templeCol = mix(templeTex, max(col * .82, templeTex * 1.07 + col * .15), .38);
          col = mix(col, templeCol, sceneDepthFade * .93);
        }
      } else {
        if (uLagoonReady > 0.5) {
          vec3 lagoonTex = texture2D(uLagoon, uvScene).rgb;
          vec3 lagoonCol = mix(lagoonTex, max(col * .84, lagoonTex * 1.09 + col * .18), .34);
          col = mix(col, lagoonCol, sceneDepthFade * .94);
        }
      }
    }
  }

  // Sunlit coastal sky with fluffy cumulus clouds & horizon haze when camera looks above the waves (wy < 4)
  if (wy < 4.0) {
    float alt = clamp(-wy / 260.0, 0.0, 1.0);
    vec3 skyHorizon = vec3(0.68, 0.95, 0.99);
    vec3 skyMid = vec3(0.32, 0.78, 0.98);
    vec3 skyZenith = vec3(0.17, 0.60, 0.94);
    vec3 skyCol = mix(skyHorizon, skyMid, smoothstep(0.0, 0.42, alt));
    skyCol = mix(skyCol, skyZenith, smoothstep(0.42, 1.0, alt));

    // High-altitude airy atmospheric shimmer (sculpted cumulus clouds & distant harbor draw crisply above Pass 0)
    float sunDist = length(vec2((w.x - sx) * 0.65, wy + 115.0));
    skyCol += vec3(0.32, 0.28, 0.14) * exp(-sunDist / 165.0);

    float skyMix = smoothstep(4.0, -2.5, wy);
    col = mix(col, skyCol, skyMix);
  }

  col += (hash21(gl_FragCoord.xy + fract(uTime)) - .5) / 150.;
  gl_FragColor = vec4(col, 1.);
}`,
  });
  mat.addEventListener("dispose", () => {
    habitat.dispose();
    shipwreck.dispose();
    kelp.dispose();
    temple.dispose();
    lagoon.dispose();
  });
  return mat;
}

// ---------------------------------------------------------------- god-rays / light shafts
export function raysMaterial(o: { par: number; strength: number; sharp: number; speed: number; off: number; additive: boolean }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uPar: { value: o.par },
      uStrength: { value: o.strength },
      uSharp: { value: o.sharp },
      uSpeed: { value: o.speed },
      uOff: { value: o.off },
    },
    transparent: true,
    depthTest: false,
    depthWrite: false,
    blending: THREE.CustomBlending,
    blendEquation: THREE.AddEquation,
    blendSrc: THREE.OneFactor,
    blendDst: o.additive ? THREE.OneFactor : THREE.OneMinusSrcAlphaFactor,
    vertexShader: SCREEN_VS,
    fragmentShader:
      COMMON +
      /* glsl */ `
uniform float uPar, uStrength, uSharp, uSpeed, uOff;
varying vec2 vUv;
void main(){
  vec2 w = vec2(uCamTL.x + vUv.x * uView.x, uCamTL.y + (1. - vUv.y) * uView.y);
  float lx = w.x - uCamC.x * (1. - uPar);
  float u = lx + w.y * .36 + uOff;
  float t = uTime * uSpeed;
  float n = vnoise(vec2(u * .0105, t * .4)) * .55 + vnoise(vec2(u * .026 + 7., -t * .7)) * .30 + vnoise(vec2(u * .058, t * 1.3 + 3.)) * .15;
  float r = smoothstep(.47 + uSharp * .06, .84, n);
  r = pow(r, 1. + uSharp);
  float depthFade = exp(-max(w.y, 0.) / mix(820., 980., uLightEnhance));
  float boost = 1. + mix(1.4, 1.85, uLightEnhance) * exp(-max(w.y, 0.) / 185.);
  float a = r * depthFade * boost * uStrength * mix(1.0, 0.56, uWaterStyle) * mix(1.0, 1.24, uLightEnhance) * smoothstep(-1., 18., w.y);
  vec3 c = mix(vec3(.55, .93, 1.), vec3(1., .96, .78), exp(-max(w.y, 0.) / 380.) * mix(.75, .88, uLightEnhance));
  gl_FragColor = vec4(c * a, a * .3);
}`,
  });
}

// ---------------------------------------------------------------- rock / sand / reef rock
export interface RockOpts {
  rock0: [number, number, number];
  rock1: [number, number, number];
  crust: [number, number, number];
  vein: [number, number, number];
  veinK: number;
  seed: number;
  fog: number;
  fade?: [number, number];
  lip?: boolean;
  cave?: boolean;
  crustAll?: number;
  instanced?: boolean;
  dark?: number;
  bump?: number;
  lite?: boolean;
}

export function rockMaterial(o: RockOpts) {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uRock0: { value: new THREE.Vector3(...o.rock0) },
      uRock1: { value: new THREE.Vector3(...o.rock1) },
      uCrust: { value: new THREE.Vector3(...o.crust) },
      uVein: { value: new THREE.Vector3(...o.vein) },
      uVeinK: { value: o.veinK },
      uSeed: { value: o.seed },
      uFog: { value: o.fog },
      uFade: { value: new THREE.Vector2(...(o.fade ?? [1e6, 2e6])) },
      uLip: { value: o.lip ? 1 : 0 },
      uCave: { value: o.cave ? 1 : 0 },
      uCrustAll: { value: o.crustAll ?? 0 },
      uDark: { value: o.dark ?? 0 },
      uBump: { value: o.bump ?? 1 },
      uLite: { value: o.lite ? 1 : 0 },
    },
    transparent: true,
    premultipliedAlpha: true,
    depthTest: true,
    depthWrite: true,
    side: THREE.DoubleSide,
    vertexShader: /* glsl */ `
attribute vec2 aSdf;
attribute float aLip;
varying vec3 vWP; varying vec3 vN; varying vec2 vLP; varying vec2 vSdf; varying float vLip;
void main(){
  #ifdef USE_INSTANCING
    mat4 im = modelMatrix * instanceMatrix;
    vLP = (instanceMatrix * vec4(position, 1.)).xy;
    vec4 wp = im * vec4(position, 1.);
    vN = normalize(mat3(im) * normal);
  #else
    vec4 wp = modelMatrix * vec4(position, 1.);
    vLP = position.xy;
    vN = normalize(mat3(modelMatrix) * normal);
  #endif
  vWP = wp.xyz; vSdf = aSdf; vLip = aLip;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`,
    fragmentShader:
      COMMON +
      /* glsl */ `
uniform vec3 uRock0, uRock1, uCrust, uVein;
uniform float uVeinK, uSeed, uFog, uLip, uCave, uCrustAll, uDark, uBump, uLite;
uniform vec2 uFade;
varying vec3 vWP; varying vec3 vN; varying vec2 vLP; varying vec2 vSdf; varying float vLip;

void main(){
  float fw = max(fwidth(vSdf.x), 1e-3);
  float a = clamp(.5 - vSdf.x / fw, 0., 1.);
  if (uLip > .5) a *= smoothstep(.02, .42, vLip);
  float wy = -vWP.y;
  a *= 1. - smoothstep(uFade.x, uFade.y, wy);
  if (a < .004) discard;

  vec3 N0 = normalize(vN);
  if (!gl_FrontFacing) N0 = -N0;
  vec2 q = vLP;
  float s = uSeed;
  if (uLite > .5){
    // distant canyon wall: cheap shading (no bump / caustics) — it is mostly water-fog anyway
    float m1 = fbm2(q * .03 + s);
    vec3 b0 = mix(uRock0, uRock1, smoothstep(.2, .8, m1));
    vec3 c0 = lightSurfaceC(b0, N0, vWP, .9, 0.);
    c0 += vec3(.2, .45, .55) * pow(1. - clamp(N0.z, 0., 1.), 2.2) * .25;
    float wy0 = -vWP.y;
    c0 = mix(c0, waterCol(wy0) * 1.06 + vec3(.02, .035, .04), uFog);
    c0 = mix(c0, vec3(.01, .035, .08), uDark);
    float a0 = clamp(.5 - vSdf.x / fw, 0., 1.) * (1. - smoothstep(uFade.x, uFade.y, wy0));
    if (a0 < .004) discard;
    gl_FragColor = vec4(c0 * a0, a0);
    return;
  }
  vec2 warp = vec2(
    fbm2(q * .021 + s),
    fbm2(q * .021 + s + vec2(5.3, 1.9))
  ) * 14.0;
  vec3 g1 = fbmd((q + warp * .55) * .042 + s);
  vec3 g2 = fbmd((q - warp * .35) * .135 + s * 2.3);
  float n1 = g1.x;
  float fine = vnoise(q * .55 + s) * .60 + vnoise(q * 1.35 + s * 1.7) * .40;
  float strataArg = (q.y + warp.y * .85 + n1 * 18.0) * .085 + s * 1.7;
  float strataWave = sin(strataArg);
  float strata = .5 + .5 * strataWave;
  float seam = smoothstep(.78, .98, abs(strataWave)) * (.35 + .65 * smoothstep(.35, .75, g2.x));
  float grainShade = smoothstep(.62, .90, g2.x);

  vec2 strataGrad = vec2(0., cos(strataArg) * .085 * 3.8);
  vec2 grad = (g1.yz * .042 * 7.5 + g2.yz * .135 * 2.4 + strataGrad) * uBump * .52;
  vec3 N = normalize(vec3(N0.xy - grad, N0.z));

  vec3 base = mix(uRock0, uRock1, smoothstep(.18, .82, n1 * .52 + strata * .48));
  base *= 1. - .15 * seam;
  base *= 1. - .10 * grainShade;
  base *= .92 + .18 * fine;

  float caveMask = uCave > .5 ? smoothstep(-26., 2., vSdf.y) : 0.;
  float up = smoothstep(.30, .86, N0.y) * (1. - caveMask * .86);
  float crust = up * smoothstep(.26, .64, n1);
  crust = max(crust, uCrustAll);
  vec3 cr = uCrust * (.82 + .28 * g2.x) * (.92 + .16 * strata);
  cr *= mix(1., .5, smoothstep(0., 70., -vSdf.x) * uCrustAll);
  base = mix(base, cr, clamp(crust, 0., 1.) * .88);

  float shallow = smoothstep(1350., 220., wy);
  float coastalWarm = smoothstep(.42, .74, strata) * shallow * up * (1. - uCrustAll);
  base = mix(base, vec3(.46, .54, .38), coastalWarm * .24);

  float mossMask = up * smoothstep(.38, .76, n1) * smoothstep(.44, .74, g2.x) * (1. - uCrustAll * .7);
  base = mix(base, vec3(.22, .52, .42), mossMask * .36);

  float ao = (1. - .16 * seam - .08 * grainShade) * (.76 + .24 * smoothstep(0., 20., -vSdf.x));
  float hollow = smoothstep(-1.5, 3., vSdf.y) * uCave;
  float ck = (1. - caveMask * .88) * (1. - hollow);
  vec3 col = lightSurfaceC(base, N, vWP, ao, ck);

  // Bioluminescent moss & mineral fissures only in deeper twilight/midnight/abyssal zones or deep caves
  float deepBio = max(smoothstep(880., 1380., wy), smoothstep(.02, .25, uVeinK) * smoothstep(680., 1020., wy));
  float hueShift = fbm2(q * .018 + s * 3.1);
  vec3 bioCol = hueShift < .36
    ? mix(vec3(.12, .94, .62), vec3(.10, .92, 1.0), smoothstep(.12, .36, hueShift))
    : mix(vec3(.10, .92, 1.0), vec3(.72, .36, 1.0), smoothstep(.36, .78, hueShift));
  if (uVeinK > .01) bioCol = mix(bioCol, uVein, .35 * clamp(uVeinK, 0., 1.));
  float fissure = 0.;
  if (deepBio > .005) {
    vec2 fq = q + warp * 1.45;
    float crack1 = 1. - abs(2. * fbm2(fq * .032 + s * 2.1) - 1.);
    float crack2 = 1. - abs(2. * fbm2(vec2(fq.x * .7 - fq.y * .7, fq.x * .7 + fq.y * .7) * .058 - s * 1.3 + vec2(3.7, 8.1)) - 1.);
    fissure = max(smoothstep(.92, .992, crack1), smoothstep(.935, .995, crack2) * .74);
    float creviceWeight = smoothstep(.22, .85, seam) * .72 + (1. - ao) * .65 + .26;
    float pulse = .58 + .42 * sin(uTime * 1.18 + q.x * .026 + q.y * .021 + hueShift * 6.28);
    float glowStrength = (.34 + uVeinK * .50) * fissure * clamp(creviceWeight, .25, 1.2) * deepBio * pulse;
    col += bioCol * glowStrength;
    col += mix(vec3(.14, .88, .58), vec3(.18, .92, .98), hueShift) * mossMask * (.14 * smoothstep(720., 1350., wy)) * pulse;
  }

  float caveAO = .68 + .32 * smoothstep(-4., 18., vSdf.y);
  vec3 gloom = base * (.28 + .10 * strata) * (1. - .22 * seam) + waterCol(wy) * .20 * caveAO + bioCol * fissure * .14 * deepBio;
  col = mix(col, gloom, hollow * .84);

  float upRim = smoothstep(-0.25, 0.72, N.y);
  float rim = pow(1. - clamp(N.z, 0., 1.), 2.8) * upRim;
  col += mix(vec3(.24, .56, .66), vec3(.32, .28, .68), smoothstep(900., 1800., wy)) * rim * (.12 + .14 * sunK(wy)) * (1. - hollow) * (1. - caveMask * .7);

  vec3 wc = waterCol(wy);
  col = mix(col, wc * 1.06 + vec3(.02, .035, .04), uFog);
  col = mix(col, vec3(.01, .035, .08), uDark);
  gl_FragColor = vec4(col * a, a);
}`,
  });
}

// ---------------------------------------------------------------- coral (instanced, swaying)
export function coralMaterial(o: { fog: number; dark?: number; sway?: number; double?: boolean; oblique?: boolean }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uFog: { value: o.fog },
      uDark: { value: o.dark ?? 0 },
      uSway: { value: o.sway ?? 1 },
      uOblique: { value: o.oblique === false ? 0 : 1 },
    },
    side: o.double ? THREE.DoubleSide : THREE.FrontSide,
    vertexShader: /* glsl */ `
attribute float aux;
attribute vec4 iTint;
attribute vec2 iData;
uniform float uTime; uniform float uSway; uniform float uOblique; uniform vec2 uReefView;
varying vec3 vWP; varying vec3 vN; varying vec3 vLP; varying vec3 vCol; varying float vAux; varying float vGlow;
void main(){
  vec3 lp = position;
  float h = clamp(position.y, 0., 1.6);
  float sw = uSway * iData.x * h * h;
  lp.x += sin(uTime * 1.25 + iTint.w + h * 2.4) * sw;
  lp.z += cos(uTime * .95 + iTint.w * 1.3 + h * 1.9) * sw * .6;
  mat4 im = modelMatrix * instanceMatrix;
  vec4 wp = im * vec4(lp, 1.);
  vWP = wp.xyz;
  vN = normalize(mat3(im) * normal);
  vLP = position;
  vAux = aux; vCol = iTint.rgb; vGlow = iData.y;
  wp.xy += uReefView * wp.z * uOblique;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`,
    fragmentShader:
      COMMON +
      /* glsl */ `
uniform float uFog, uDark;
varying vec3 vWP; varying vec3 vN; varying vec3 vLP; varying vec3 vCol; varying float vAux; varying float vGlow;
void main(){
  vec3 N = normalize(vN);
  if (!gl_FrontFacing) N = -N;
  float tip = clamp(vAux, 0., 1.);
  float tex = vnoise(vLP.xy * 34. + vLP.z * 21.);
  vec3 alb = vCol * (.70 + .56 * tip) * (.88 + .26 * tex);
  alb = mix(alb, alb * vec3(1.08, 1.14, 1.16) + .055, smoothstep(.63, 1., tip) * .66);
  float wy = -vWP.y;
  float deep = smoothstep(1000., 1900., wy);
  vec3 col = lightSurfaceC(alb, N, vWP, .62 + .38 * tip, .4);
  // living colour: corals keep their saturated hues instead of turning blue with the water
  vec3 pop = vCol * (.79 + .55 * tip) * (.84 + .57 * sunK(wy)) * (.89 + .11 * N.y) * absorbK(wy * .23);
  col = mix(col, pop, .74);
  float lum = dot(col, vec3(.3, .59, .11));
  col = mix(vec3(lum), col, 1.48);
  col += vec3(.15, .13, .09) * smoothstep(.62, .96, tip) * (.48 + .52 * max(0., N.y));
  col += vCol * tip * sunK(wy) * .17;
  col += vCol * (.07 + .5 * tip) * deep * vGlow;
  col += vCol * pow(1. - abs(N.z), 2.) * .20 * (sunK(wy) * .8 + .3 * deep * vGlow);
  col = mix(col, waterCol(wy) * 1.06 + vec3(.02, .035, .04), mix(uFog, uFog * .62, clamp(uBgStyle, 0., 1.)));
  col = mix(col, vec3(.01, .035, .08), uDark);
  gl_FragColor = vec4(col, 1.);
}`,
  });
}

// ---------------------------------------------------------------- entities (submarine, diver, chest, vent)
export function litMaterial(o: { fog: number; suit?: readonly [number, number, number] }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uFog: { value: o.fog },
      uHasSuit: { value: o.suit ? 1 : 0 },
      uSuit: { value: new THREE.Vector3(...(o.suit || ([0.76, 0.51, 0.12] as const))) },
    },
    vertexShader: /* glsl */ `
attribute vec3 aCol; attribute float aEmi; attribute float aMet; attribute float aAO;
attribute vec3 aFace; varying vec3 vFace;
attribute float aKind; varying float vKind; varying vec3 vLocal; uniform vec3 uSuit; uniform float uHasSuit;
varying vec3 vWP; varying vec3 vN; varying vec3 vC; varying float vE; varying float vM; varying float vAO;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.);
  vWP = wp.xyz; vN = normalize(mat3(modelMatrix) * normal);
  vC = aCol; vE = aEmi; vM = aMet; vAO = aAO;
  vFace = aFace;
  vKind = aKind; vLocal = position;
  if (uHasSuit > .5 && abs(aKind) < .1) vC = uSuit;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`,
    fragmentShader:
      COMMON +
      /* glsl */ `
uniform float uFog;
varying vec3 vFace;
varying float vKind; varying vec3 vLocal;
varying vec3 vWP; varying vec3 vN; varying vec3 vC; varying float vE; varying float vM; varying float vAO;
void main(){
  vec3 N = normalize(vN);
  if (!gl_FrontFacing) N = -N;
  float wy = -vWP.y;
  vec3 L = normalize(vec3(-.40, .80, .45));
  float sk = sunK(wy);
  float ndl = max(dot(N, L), 0.);
  float wrap = dot(N, L) * .5 + .5;
  vec3 wc = waterCol(wy);
  // Burnished copper, champagne brass & diver suits keep vibrant underwater warmth
  vec3 amb = mix(vec3(.30, .30, .34), wc * .88 + vec3(.14, .16, .19), .30);
  vec3 sun = vec3(1., .94, .80) * (sk * .85 + .15) * (ndl * .90 + wrap * .36 + .10);
  vec3 col = vC * (amb * (.74 + .26 * (N.y * .5 + .5)) + sun) * (.66 + .34 * vAO) * absorbK(wy * .30) * 1.18;
  // Soft caustic shimmer across upper-water submarine hull & diver suits
  float cAmt = smoothstep(1400., 220., wy) * (.45 + .55 * uLightEnhance);
  float cs = cAmt > .02 ? caustics(vWP.xy * .014, uTime * .55) : 0.;
  col += vC * vec3(.85, .97, 1.) * cs * cAmt * (.32 + .24 * max(0., N.y));
  vec3 Hh = normalize(L + vec3(0., 0., 1.));
  float spec = pow(max(dot(N, Hh), 0.), 22.) * vM * (sk * .88 + .22);
  col += vec3(1., .90, .68) * spec * .95;
  // Bright aqua edge-bounce on metal without darkening copper
  col = mix(col, col * .78 + wc * .22 * vM, pow(1. - abs(N.z), 2.2) * vM * .48);
  col += vC * vE * (.90 + .15 * sin(uTime * 2.1 + vWP.x * .05));
  float patina = vnoise(vLocal.xy * 9. + vLocal.z * 4.) * .67 + vnoise(vLocal.zy * 22. + vLocal.x * 11.) * .33;
  if (vM > .5) {
    col *= .93 + .17 * patina;
    if (vKind > 9.5 && vKind < 10.5) {
      float a = atan(vLocal.y, vLocal.x) / 6.283;
      float seam = min(abs(fract(vLocal.z * 2.3) - .5), abs(fract(a * 11.) - .5));
      col *= .88 + .12 * smoothstep(.004, .025, seam);
    }
    col = mix(col, vec3(.52, .32, .22), smoothstep(.72, .92, patina) * .10);
    col += vec3(.14, .24, .28) * pow(1. - abs(N.z), 2.5) * vM + vec3(.36, .28, .15) * pow(max(dot(N, normalize(vec3(-.53, .70, .46))), 0.), 42.) * vM;
  } else if (abs(vKind) < .1) {
    col *= .92 + .18 * patina + .022 * sin(vLocal.y * 255.) * sin(vLocal.x * 215.);
    col += vC * pow(1. - abs(N.z), 2.0) * .22;
  }
  if (vFace.z > .5) {
    vec2 face = vec2((vFace.x - .5) * .26, vFace.y * .30);
    float u = (abs(face.x) - .0415) / .031, q = clamp(u, -1., 1.), arc = pow(clamp(1. - q * q, 0., 1.), .72);
    float center = .174 + .001 * q, cycle = fract((uTime + .99) / 3.498), blink = smoothstep(.935, .966, cycle) * (1. - smoothstep(.977, .998, cycle));
    float upper = mix(center + arc * .0095, center - arc * .004, blink), lower = mix(center - arc * .011, center - arc * .004, blink);
    float feather = clamp(fwidth(vFace.y) * .17, .00055, .0035);
    float mask = smoothstep(lower - feather, lower + feather, face.y) * (1. - smoothstep(upper - feather, upper + feather, face.y)) * (1. - smoothstep(.97, 1.08, abs(u))) * (1. - smoothstep(.88, .995, blink));
    vec2 iris = face - vec2(sign(face.x) * .0415 + sin(floor(uTime * .53) * 23.3) * .003, .170 + sin(uTime * .73) * .0016);
    float ir = length(iris); vec3 paint = mix(vec3(.96, .93, .85), mix(vec3(.22, .105, .047), vec3(.115, .21, .17), smoothstep(.005, .012, ir)), 1. - smoothstep(.0102 - feather, .0118 + feather, ir));
    paint = mix(paint, vec3(.013, .009, .008), 1. - smoothstep(.0064 - feather, .0064 + feather, ir));
    paint += vec3(.89, .85, .75) * (1. - smoothstep(.0011, .0025 + feather, length(iris - vec2(-.0039, .0043))));
    col = max(col, vC * .72); col = mix(col, paint, mask);
  }
  col = mix(col, wc * 1.04 + vec3(.02, .035, .04), uFog);
  gl_FragColor = vec4(col, 1.);
}`,
  });
}

// ---------------------------------------------------------------- soft glow quad / beam cone
export function glowMaterial(color: [number, number, number], strength: number, kind: "radial" | "beam") {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uColor: { value: new THREE.Vector3(...color) },
      uStrength: { value: strength },
      uBeam: { value: kind === "beam" ? 1 : 0 },
    },
    transparent: true,
    depthTest: false,
    depthWrite: false,
    blending: THREE.CustomBlending,
    blendEquation: THREE.AddEquation,
    blendSrc: THREE.OneFactor,
    blendDst: THREE.OneFactor,
    side: THREE.DoubleSide,
    vertexShader: /* glsl */ `
varying vec2 vUv; varying vec3 vWP;
void main(){ vUv = uv; vec4 wp = modelMatrix * vec4(position, 1.); vWP = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }`,
    fragmentShader:
      COMMON +
      /* glsl */ `
uniform vec3 uColor; uniform float uStrength; uniform float uBeam;
varying vec2 vUv; varying vec3 vWP;
void main(){
  float wy = -vWP.y;
  float a;
  if (uBeam > .5){
    float across = abs(vUv.y - .5) * 2.;
    a = (1. - smoothstep(0., 1., across)) * pow(1. - vUv.x, 1.6);
    a *= .55 + .45 * sin(uTime * 1.7 + vUv.x * 9.);
    a *= .22 + .78 * smoothstep(250., 1500., wy);
  } else {
    vec2 d = (vUv - .5) * 2.;
    a = pow(max(1. - dot(d, d), 0.), 2.2);
  }
  a *= uStrength;
  gl_FragColor = vec4(uColor * a, a);
}`,
  });
}

// ---------------------------------------------------------------- rising particles (smoke plume / bubbles)
export function plumeMaterial(o: { color: [number, number, number]; additive: boolean; size: number; rise: number; spread: number; alpha: number; speed: number; bubble?: boolean }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...SHARED,
      uOrigin: { value: new THREE.Vector3(0, 0, 0) },
      uColor: { value: new THREE.Vector3(...o.color) },
      uSize: { value: o.size },
      uRise: { value: o.rise },
      uSpread: { value: o.spread },
      uAlpha: { value: o.alpha },
      uSpeed: { value: o.speed },
      uDir: { value: 0 },
      uBubble: { value: o.bubble ? 1 : 0 },
    },
    transparent: true,
    depthTest: false,
    depthWrite: false,
    blending: THREE.CustomBlending,
    blendEquation: THREE.AddEquation,
    blendSrc: THREE.OneFactor,
    blendDst: o.additive ? THREE.OneFactor : THREE.OneMinusSrcAlphaFactor,
    vertexShader: /* glsl */ `
attribute float aSeed;
uniform float uTime, uPx, uSize, uRise, uSpread, uSpeed, uDir, uBubble;
uniform vec3 uOrigin;
varying float vA; varying float vS;
float hsh(float p){ p = fract(p * .1031); p *= p + 33.33; p *= p + p; return fract(p); }
void main(){
  float h0 = hsh(aSeed), h1 = hsh(aSeed * 3.1);
  float age = fract(uTime * uSpeed * (.7 + .6 * h0) + aSeed);
  // real bubbles: bigger ones rise faster, small ones zig-zag more
  float big = h1;
  float rise = uBubble > .5 ? age * uRise * (.8 + .5 * big) : age * uRise;
  float wob = sin(age * (7. + 9. * (1. - big)) + aSeed * 40.) + .4 * sin(age * 2.3 + aSeed * 9.);
  vec3 p = uOrigin + vec3(wob * uSpread * (.25 + age) * (1.2 - .5 * big) - uDir * age * uSpread * 1.4, rise, 0.);
  vA = smoothstep(0., .08, age) * (1. - smoothstep(.6, 1., age));
  vS = age * 6.28 + aSeed * 20.;
  float grow = uBubble > .5 ? (.55 + age * .7) : (.45 + age * 1.1);
  gl_PointSize = max(1.5, uSize * uPx * grow * (.5 + .9 * big));
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(p, 1.);
}`,
    fragmentShader: /* glsl */ `
uniform vec3 uColor; uniform float uAlpha, uBubble;
varying float vA; varying float vS;
void main(){
  vec2 d = gl_PointCoord * 2. - 1.;
  if (uBubble > .5) {
    // oblate wobble
    d.x /= 1. + .12 * sin(vS);
    d.y *= 1. + .12 * sin(vS);
  }
  float r2 = dot(d, d);
  if (r2 > 1.) discard;
  float a;
  vec3 c = uColor;
  if (uBubble > .5) {
    float r = sqrt(r2);
    float rim = smoothstep(.62, .9, r) * (1. - smoothstep(.9, 1., r));          // thin bright edge
    float refr = smoothstep(.2, .85, r) * smoothstep(-.2, 1., d.x + d.y) * .35; // light pooling lower-right
    float spec = pow(max(0., 1. - length(d - vec2(-.38, -.42)) * 3.2), 2.) * 1.2; // top-left specular
    float glint = pow(max(0., 1. - length(d - vec2(.4, .45)) * 9.), 2.) * .6;
    float body = (1. - r2) * .06;
    a = (rim * .85 + refr + spec + glint + body) * vA * uAlpha;
    c = mix(uColor, vec3(1.), rim * .5 + spec + glint);
  } else {
    a = (1. - r2) * vA * uAlpha;
  }
  gl_FragColor = vec4(c * a, a);
}`,
  });
}

// ---------------------------------------------------------------- SSAA downsample & Contrast Adaptive Sharpening (RCAS)
export function createPostSharpenMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      tDiffuse: { value: null },
      uTexel: { value: new THREE.Vector2(1 / 1280, 1 / 720) },
      uSharpness: { value: 0.45 },
      uClarity: { value: 0.05 },
    },
    depthTest: false,
    depthWrite: false,
    transparent: false,
    blending: THREE.NoBlending,
    vertexShader: SCREEN_VS,
    fragmentShader: /* glsl */ `
uniform sampler2D tDiffuse;
uniform vec2 uTexel;
uniform float uSharpness;
uniform float uClarity;
varying vec2 vUv;

float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }

void main(){
  vec4 c = texture2D(tDiffuse, vUv);
  if (c.a <= 0.002) {
    gl_FragColor = vec4(0.0);
    return;
  }
  vec4 n = texture2D(tDiffuse, vUv + vec2(0.0, uTexel.y));
  vec4 s = texture2D(tDiffuse, vUv - vec2(0.0, uTexel.y));
  vec4 e = texture2D(tDiffuse, vUv + vec2(uTexel.x, 0.0));
  vec4 w = texture2D(tDiffuse, vUv - vec2(uTexel.x, 0.0));

  vec3 mn = min(c.rgb, min(min(n.rgb, s.rgb), min(e.rgb, w.rgb)));
  vec3 mx = max(c.rgb, max(max(n.rgb, s.rgb), max(e.rgb, w.rgb)));

  // FidelityFX RCAS-inspired contrast-adaptive local sharpening weight
  float lC = luma(c.rgb);
  float lMin = luma(mn);
  float lMax = luma(mx);
  float amp = clamp(min(lMin, 1.0 - lMax) / max(lMax, 1e-4), 0.0, 1.0);
  float k = sqrt(amp) * (-0.19 * uSharpness) * smoothstep(0.06, 0.74, c.a);

  vec3 nbr = n.rgb + s.rgb + e.rgb + w.rgb;
  vec3 sharp = (c.rgb + k * nbr) / (1.0 + 4.0 * k);
  sharp = clamp(sharp, mn, mx);

  // Subtle local clarity pop on underwater highlights without clipping
  vec3 avg4 = nbr * 0.25;
  sharp = clamp(sharp + (sharp - avg4) * uClarity * smoothstep(0.08, 0.82, c.a), 0.0, 1.0);
  gl_FragColor = vec4(sharp, c.a);
}`,
  });
}
