import { Component, ErrorInfo, ReactNode } from 'react';

/** Shows what went wrong instead of leaving a blank page when rendering the interface fails. */
export class ErrorBoundary extends Component<{ children: ReactNode }, { error: string | null }> {
  state = { error: null as string | null };

  static getDerivedStateFromError(e: unknown) {
    return { error: e instanceof Error ? e.message : String(e) };
  }

  componentDidCatch(e: Error, info: ErrorInfo) {
    console.error('[ui] render failed:', e, info.componentStack);
  }

  render() {
    if (this.state.error === null) return this.props.children;
    return (
      <div
        style={{
          position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          gap: 16, padding: 24, textAlign: 'center', background: '#1a0f04', color: '#f5e6c4', fontFamily: 'Georgia, serif',
        }}
      >
        <div style={{ fontSize: 22, letterSpacing: '0.16em' }}>ADA MASALAH</div>
        <div style={{ fontSize: 14, opacity: 0.8, maxWidth: 520 }}>Tampilan gagal dimuat: {this.state.error}</div>
        <button
          onClick={() => window.location.reload()}
          style={{ padding: '10px 26px', fontSize: 15, letterSpacing: '0.14em', border: 'none', borderRadius: 2, background: '#f39a2c', color: '#1c0d00', cursor: 'pointer' }}
        >
          MUAT ULANG
        </button>
      </div>
    );
  }
}
