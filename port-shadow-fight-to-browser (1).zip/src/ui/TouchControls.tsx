import { useRef, useState } from 'react';
import type { Input } from '../game/fighter';

interface Ready {
  jump: boolean;
  roll: boolean;
  flip: boolean;
  super: boolean;
}

export function TouchControls({ input, ready }: { input: Input; ready: Ready }) {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const active = useRef(false);

  const move = (e: React.PointerEvent) => {
    const el = base.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const R = r.width / 2;
    let dx = (e.clientX - (r.left + R)) / R;
    let dy = (e.clientY - (r.top + R)) / R;
    const l = Math.hypot(dx, dy);
    if (l > 1) {
      dx /= l;
      dy /= l;
    }
    setKnob({ x: dx, y: dy });
    input.l = dx < -0.36;
    input.r = dx > 0.36;
    input.u = dy < -0.5;
    input.d = dy > 0.5;
  };
  const end = () => {
    active.current = false;
    setKnob({ x: 0, y: 0 });
    input.l = input.r = input.u = input.d = false;
  };

  const tap = (label: string, cls: string, fn: () => void) => (
    <button
      className={`pad ${cls}`}
      onPointerDown={(e) => {
        e.preventDefault();
        fn();
      }}
    >
      {label}
    </button>
  );

  return (
    <div className="touch-layer">
      <div
        ref={base}
        className="stick"
        onPointerDown={(e) => {
          active.current = true;
          e.currentTarget.setPointerCapture(e.pointerId);
          move(e);
        }}
        onPointerMove={(e) => active.current && move(e)}
        onPointerUp={end}
        onPointerCancel={end}
      >
        <div className="stick-knob" style={{ transform: `translate(${knob.x * 36}%, ${knob.y * 36}%)` }} />
      </div>
      <div className="pads">
        {tap('SUPER', `pad-super ${ready.super ? 'pad-glow' : 'pad-off'}`, () => { input.super = 0.2; })}
        {tap('ROLL', `pad-sm ${ready.roll ? '' : 'pad-off'}`, () => { input.roll = 0.2; })}
        {tap('FLIP', `pad-sm ${ready.flip ? '' : 'pad-off'}`, () => { input.flip = 0.2; input.flipDir = 0; })}
        {tap('LEMPAR', 'pad-alt', () => { input.throw = 0.2; })}
        <button
          className="pad pad-alt"
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            input.block = true;
          }}
          onPointerUp={() => { input.block = false; }}
          onPointerCancel={() => { input.block = false; }}
        >
          BLOK
        </button>
        {tap('TENDANG', 'pad-big pad-kick', () => { input.kick = 0.2; })}
        {tap('GAYA', 'pad-sm pad-style', () => { input.style = 0.2; })}
        {tap('BERAT', 'pad-big pad-heavy', () => { input.heavy = 0.2; })}
        {tap('PUKUL', 'pad-big', () => { input.punch = 0.2; })}
      </div>
    </div>
  );
}
