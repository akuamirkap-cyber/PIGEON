export interface V {
  x: number;
  y: number;
}

export const DEG = Math.PI / 180;
export const TAU = Math.PI * 2;

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => {
  t = clamp(t, 0, 1);
  return t * t * (3 - 2 * t);
};
export const rand = (a = 1, b?: number) => (b === undefined ? Math.random() * a : a + Math.random() * (b - a));
export const damp = (a: number, b: number, lambda: number, dt: number) => lerp(a, b, 1 - Math.exp(-lambda * dt));

export type Ease = 'lin' | 'in' | 'out' | 'io' | 'snap';

export function ease(e: Ease | undefined, t: number): number {
  t = clamp(t, 0, 1);
  switch (e) {
    case 'in':
      return t * t * t;
    case 'out': {
      const u = 1 - t;
      return 1 - u * u * u;
    }
    case 'snap':
      // slow start then very violent acceleration – used for strikes
      return Math.pow(t, 2.4);
    case 'lin':
      return t;
    default:
      return t * t * (3 - 2 * t);
  }
}

/** deterministic hash -> 0..1 */
export function hash(n: number): number {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

export interface SegHit {
  dist: number;
  x: number;
  y: number;
}

/** Closest distance between segment p1-q1 and segment p2-q2. Returns the contact point on the 2nd segment. */
export function segSeg(p1: V, q1: V, p2: V, q2: V): SegHit {
  const d1x = q1.x - p1.x,
    d1y = q1.y - p1.y,
    d2x = q2.x - p2.x,
    d2y = q2.y - p2.y,
    rx = p1.x - p2.x,
    ry = p1.y - p2.y;
  const a = d1x * d1x + d1y * d1y,
    e = d2x * d2x + d2y * d2y,
    f = d2x * rx + d2y * ry;
  let s = 0,
    t = 0;
  if (a <= 1e-6 && e <= 1e-6) {
    // both points
  } else if (a <= 1e-6) {
    t = clamp(f / e, 0, 1);
  } else {
    const c = d1x * rx + d1y * ry;
    if (e <= 1e-6) {
      s = clamp(-c / a, 0, 1);
    } else {
      const b = d1x * d2x + d1y * d2y,
        den = a * e - b * b;
      s = den > 1e-6 ? clamp((b * f - c * e) / den, 0, 1) : 0;
      t = (b * s + f) / e;
      if (t < 0) {
        t = 0;
        s = clamp(-c / a, 0, 1);
      } else if (t > 1) {
        t = 1;
        s = clamp((b - c) / a, 0, 1);
      }
    }
  }
  const c1x = p1.x + d1x * s,
    c1y = p1.y + d1y * s,
    c2x = p2.x + d2x * t,
    c2y = p2.y + d2y * t;
  return { dist: Math.hypot(c1x - c2x, c1y - c2y), x: (c1x + c2x) / 2, y: (c1y + c2y) / 2 };
}
