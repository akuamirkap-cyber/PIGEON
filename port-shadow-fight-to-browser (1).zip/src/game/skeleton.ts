import { FighterCfg, FighterType } from './config';
import { DEG, V, clamp } from './math';

/**
 * A pose is authored in "body space" facing right. Angles are in degrees.
 *  - torso: 0 = upright, + leans forward · head: relative to the torso
 *  - sF/sB: upper arm, 0 = hanging down, 90 = pointing forward, 180 = up · eF/eB: elbow bend on top of it
 *  - wp: weapon angle relative to the forearm
 *  - px/py: pelvis offset from the root (py = height above the ground)
 *  - fFx/fFy/fFa: foot IK target relative to the root (+ foot pitch)
 *
 * Depth channels – the picture stays a side view, but the body is solved in 3D and projected:
 *  - tw / hw / hy: yaw of the shoulders / hips / head around the vertical axis.
 *      0 = pure profile. tw > 0 drives the weapon shoulder forward, tw < 0 pulls it back
 *      (chest opens to the camera). -180 = back turned to the opponent, -360 = a full spin.
 *  - zF / zB / wz: azimuth of the weapon arm / off arm / blade. 0 = in the picture plane,
 *      90 = pointing at the camera, 180 = pointing backwards, -90 = away from the camera.
 *      Parts that leave the picture plane are foreshortened.
 *  - lF / lB: azimuth of the whole leg around its hip (same convention).
 */
export interface Pose {
  px: number;
  py: number;
  torso: number;
  head: number;
  sF: number;
  eF: number;
  sB: number;
  eB: number;
  fFx: number;
  fFy: number;
  fFa: number;
  fBx: number;
  fBy: number;
  fBa: number;
  wp: number;
  tw: number;
  hw: number;
  hy: number;
  zF: number;
  zB: number;
  wz: number;
  lF: number;
  lB: number;
}

export const POSE_KEYS: (keyof Pose)[] = [
  'px', 'py', 'torso', 'head', 'sF', 'eF', 'sB', 'eB', 'fFx', 'fFy', 'fFa', 'fBx', 'fBy', 'fBa', 'wp',
  'tw', 'hw', 'hy', 'zF', 'zB', 'wz', 'lF', 'lB',
];
/** channels that are angles around the vertical axis – they may wind past ±180 during a spin */
export const YAW_KEYS: (keyof Pose)[] = ['tw', 'hw', 'hy', 'zF', 'zB', 'wz', 'lF', 'lB'];

export const STANCE: Pose = {
  // upright ready stance: knees only softly bent (straight legs would be py = 111)
  px: 0, py: 103, torso: 7, head: -3,
  sF: 14, eF: 34, sB: 36, eB: 96,
  fFx: 22, fFy: 0, fFa: 0,
  fBx: -27, fBy: 0, fBa: 0,
  wp: 12,
  // chest turned slightly towards the camera – a three-quarter stance
  tw: -20, hw: -8, hy: 0, zF: 0, zB: 0, wz: 0, lF: 0, lB: 0,
};

export const mk = (p: Partial<Pose> = {}): Pose => ({ ...STANCE, ...p });

export const zeroPose = (): Pose => {
  const z = { ...STANCE };
  for (let i = 0; i < POSE_KEYS.length; i++) z[POSE_KEYS[i]] = 0;
  return z;
};

export function copyPose(dst: Pose, src: Pose) {
  for (let i = 0; i < POSE_KEYS.length; i++) dst[POSE_KEYS[i]] = src[POSE_KEYS[i]];
}

export function mixPose(out: Pose, a: Pose, b: Pose, t: number) {
  for (let i = 0; i < POSE_KEYS.length; i++) {
    const k = POSE_KEYS[i];
    out[k] = a[k] + (b[k] - a[k]) * t;
  }
}

/** bring the yaw channels of p within half a turn of ref (a finished spin is the same pose as no spin) */
export function wrapYaw(p: Pose, ref: Pose) {
  for (let i = 0; i < YAW_KEYS.length; i++) {
    const k = YAW_KEYS[i];
    while (p[k] - ref[k] > 180) p[k] -= 360;
    while (p[k] - ref[k] < -180) p[k] += 360;
  }
}

// joint indices (shared with the ragdoll)
export const HEAD = 0, NECK = 1, PELVIS = 2, ELF = 3, HAF = 4, ELB = 5, HAB = 6,
  KNF = 7, ANF = 8, TOF = 9, KNB = 10, ANB = 11, TOB = 12, TIP = 13, WBASE = 14, NJ = 15;

export interface Build {
  kind: 'shadow' | 'titan' | 'silat';
  name: string;
  type: FighterType;
  antiKnockdown: boolean;
  scale: number;
  thick: number; // limb thickness multiplier
  speed: number; // animation / movement speed
  power: number; // damage multiplier
  mass: number; // resistance to knockback (1 = normal)
  hp: number;
  armor: boolean; // light hits do not interrupt attacks
  wLen: number; // weapon length (unscaled)
  reach: number;
  kickStep: number;
  eye: string; // r,g,b of the glowing eye
  off: Partial<Pose>; // additive posture offset
}

// bone lengths (unscaled)
export const BONE = {
  thigh: 52, shin: 52, foot: 22, ankle: 7,
  torso: 60, neck: 25, upper: 38, fore: 36, headR: 14,
  shoulder: 17, hip: 9, // half widths
};

export function makeBuild(c: FighterCfg): Build {
  const big = c.body === 'titan';
  return {
    kind: c.body, name: c.name, type: c.type, antiKnockdown: c.antiKnockdown,
    scale: c.scale, thick: big ? 1.32 : 1, speed: c.speed, power: c.power,
    mass: big ? 1.1 + (c.scale - 1) * 2 : 1, hp: c.hp, armor: big,
    wLen: c.weaponLen, reach: c.reach, kickStep: c.kickStep, eye: c.eye,
    off: big ? { torso: 6, head: -5, py: -3, fFx: 4, fBx: -5, sB: -8, eB: -14 } : {},
  };
}

export const newJoints = (): V[] => Array.from({ length: NJ }, () => ({ x: 0, y: 0 }));

/** what the renderer needs besides the 2D joints: shoulder / hip joints, depth and body yaw */
export interface Extra {
  shF: V;
  shB: V;
  hpF: V;
  hpB: V;
  z: Float64Array; // depth of every joint, + = towards the camera
  zsF: number; // depth of the shoulders
  zsB: number;
  tw: number; // yaw actually used, radians
  hw: number;
  hy: number;
}
export const newExtra = (): Extra => ({
  shF: { x: 0, y: 0 }, shB: { x: 0, y: 0 }, hpF: { x: 0, y: 0 }, hpB: { x: 0, y: 0 },
  z: new Float64Array(NJ), zsF: 0, zsB: 0, tw: 0, hw: 0, hy: 0,
});

export function copyExtra(d: Extra, s: Extra) {
  d.shF.x = s.shF.x; d.shF.y = s.shF.y; d.shB.x = s.shB.x; d.shB.y = s.shB.y;
  d.hpF.x = s.hpF.x; d.hpF.y = s.hpF.y; d.hpB.x = s.hpB.x; d.hpB.y = s.hpB.y;
  d.z.set(s.z);
  d.zsF = s.zsF; d.zsB = s.zsB; d.tw = s.tw; d.hw = s.hw; d.hy = s.hy;
}

/** the camera looks slightly down: whatever is nearer to it sits a little lower in the picture */
export const PITCH = 0.3;

const SHF = NJ, SHB = NJ + 1, HPF = NJ + 2, HPB = NJ + 3, N2 = NJ + 4;
const lx = new Float64Array(N2);
const ly = new Float64Array(N2);
const lz = new Float64Array(N2);
const flat = new Uint8Array(N2); // 1 = no camera-pitch offset (legs stay on the floor line)
for (const i of [PELVIS, KNF, ANF, TOF, KNB, ANB, TOB, HPF, HPB]) flat[i] = 1;

function put(i: number, x: number, y: number, z: number) {
  lx[i] = x; ly[i] = y; lz[i] = z;
}

/** limb segment: `a` = angle in the picture plane (0 down, 90 forward), `az` = azimuth of its horizontal part */
function seg(from: number, to: number, len: number, a: number, az: number) {
  const h = Math.sin(a) * len;
  put(to, lx[from] + h * Math.cos(az), ly[from] - Math.cos(a) * len, lz[from] + h * Math.sin(az));
}

function leg(hip: number, tx: number, ty: number, fa: number, yaw: number, s: number, kn: number, an: number, to: number) {
  const hx = lx[hip], hy = ly[hip], hz = lz[hip];
  const L1 = BONE.thigh * s, L2 = BONE.shin * s;
  let dx = tx - hx, dy = ty - hy;
  let d = Math.hypot(dx, dy);
  if (d < 1e-3) { dx = 0; dy = -1; d = 1; }
  const maxd = (L1 + L2) * 0.998, mind = 6 * s;
  const cd = clamp(d, mind, maxd);
  dx *= cd / d; dy *= cd / d; d = cd;
  const cosA = (L1 * L1 + d * d - L2 * L2) / (2 * L1 * d);
  const A = Math.acos(clamp(cosA, -1, 1));
  const ka = Math.atan2(dy, dx) + A; // knee always bends forward
  const kx = Math.cos(ka) * L1, ky = Math.sin(ka) * L1;
  const f = (fa - 13) * DEG;
  const fx = dx + Math.cos(f) * BONE.foot * s, fy = dy + Math.sin(f) * BONE.foot * s;
  // the whole leg turns around the vertical axis through its hip
  const c = Math.cos(yaw * DEG), sn = Math.sin(yaw * DEG);
  put(kn, hx + kx * c, hy + ky, hz + kx * sn);
  put(an, hx + dx * c, hy + dy, hz + dx * sn);
  put(to, hx + fx * c, hy + fy, hz + fx * sn);
}

/**
 * Pose -> projected joint positions.
 * rx/ry is the root on the ground (ry already includes jump elevation), y grows downwards on screen.
 * rot is a whole-body rotation in the picture plane around the centre of mass (flips, rolls).
 */
export function solve(p: Pose, b: Build, rx: number, ry: number, facing: number, rot: number, out: V[], ex: Extra) {
  const s = b.scale;
  const wide = Math.min(b.thick, 1.25);
  const T = p.torso * DEG;
  const pvx = p.px * s, pvy = p.py * s;
  put(PELVIS, pvx, pvy, 0);
  const nx = pvx + Math.sin(T) * BONE.torso * s, ny = pvy + Math.cos(T) * BONE.torso * s;
  put(NECK, nx, ny, 0);
  const Th = (p.torso + p.head) * DEG;
  put(HEAD, nx + Math.sin(Th) * BONE.neck * s, ny + Math.cos(Th) * BONE.neck * s, 0);

  // shoulder girdle: turns around the spine
  const tw = p.tw * DEG;
  const SW = BONE.shoulder * s * wide;
  const cx = Math.cos(T), cy = -Math.sin(T); // chest direction
  const sx = Math.sin(tw) * SW, sz = Math.cos(tw) * SW;
  put(SHF, nx + cx * sx, ny + cy * sx, sz);
  put(SHB, nx - cx * sx, ny - cy * sx, -sz);

  // weapon arm + blade
  const zF = p.zF * DEG;
  seg(SHF, ELF, BONE.upper * s, p.sF * DEG, zF);
  seg(ELF, HAF, BONE.fore * s, (p.sF + p.eF) * DEG, zF);
  seg(HAF, TIP, b.wLen * s, (p.sF + p.eF + p.wp) * DEG, p.wz * DEG);
  put(WBASE, lx[HAF], ly[HAF], lz[HAF]);
  // off arm
  const zB = p.zB * DEG;
  seg(SHB, ELB, BONE.upper * s, p.sB * DEG, zB);
  seg(ELB, HAB, BONE.fore * s, (p.sB + p.eB) * DEG, zB);

  // hips + legs (IK in the picture plane, then turned around the hip)
  const hw = p.hw * DEG;
  const HW = BONE.hip * s * wide;
  put(HPF, pvx + Math.sin(hw) * HW, pvy, Math.cos(hw) * HW);
  put(HPB, pvx - Math.sin(hw) * HW, pvy, -Math.cos(hw) * HW);
  leg(HPF, p.fFx * s, (p.fFy + BONE.ankle) * s, p.fFa, p.lF, s, KNF, ANF, TOF);
  leg(HPB, p.fBx * s, (p.fBy + BONE.ankle) * s, p.fBa, p.lB, s, KNB, ANB, TOB);

  const r = rot * DEG;
  const cr = Math.cos(r), sr = Math.sin(r);
  const useRot = Math.abs(rot) > 0.01;
  const ox0 = pvx, oy0 = pvy + 14 * s; // centre of mass
  for (let i = 0; i < N2; i++) {
    let x = lx[i], y = ly[i];
    if (useRot) {
      const ox = x - ox0, oy = y - oy0;
      x = ox0 + ox * cr + oy * sr;
      y = oy0 - ox * sr + oy * cr;
    }
    const X = rx + facing * x;
    const Y = ry - y + (flat[i] ? 0 : lz[i] * PITCH);
    if (i < NJ) {
      out[i].x = X; out[i].y = Y;
      ex.z[i] = lz[i];
    } else {
      const v = i === SHF ? ex.shF : i === SHB ? ex.shB : i === HPF ? ex.hpF : ex.hpB;
      v.x = X; v.y = Y;
    }
  }
  ex.zsF = lz[SHF]; ex.zsB = lz[SHB];
  ex.tw = tw; ex.hw = hw; ex.hy = p.hy * DEG;
}
