/** Tiny synthesised sound engine – no audio files needed. */
export class Sound {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicGain!: GainNode;
  private noiseBuf!: AudioBuffer;
  private musicTimer: number | null = null;
  private drone: OscillatorNode[] = [];
  private step = 0;
  private nextT = 0;
  muted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const AC: typeof AudioContext | undefined =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 6;
    comp.connect(ctx.destination);
    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.85;
    this.master.connect(comp);
    this.musicGain = ctx.createGain();
    this.musicGain.gain.value = 0;
    this.musicGain.connect(this.master);
    const len = ctx.sampleRate;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.85, this.ctx.currentTime, 0.05);
  }

  private noise(dur: number, type: BiquadFilterType, f0: number, f1: number, q: number, vol: number, delay = 0, out?: AudioNode) {
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const fl = ctx.createBiquadFilter();
    fl.type = type;
    fl.Q.value = q;
    fl.frequency.setValueAtTime(f0, t);
    fl.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + Math.min(0.02, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(fl).connect(g).connect(out ?? this.master);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.05);
  }

  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0, out?: AudioNode) {
    const ctx = this.ctx!;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(out ?? this.master);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private metal(base: number, dur: number, vol: number, delay = 0) {
    const ratios = [1, 2.32, 3.86, 5.43, 7.9];
    ratios.forEach((r, i) => this.tone(i % 2 ? 'square' : 'triangle', base * r * (0.98 + Math.random() * 0.04), base * r * 0.99, dur * (1 - i * 0.14), (vol / (i + 1.5)) * 0.9, delay));
  }

  play(name: string, vol = 1) {
    if (!this.ctx || this.muted) return;
    const v = Math.min(1.4, vol);
    switch (name) {
      case 'whoosh':
        this.noise(0.2, 'bandpass', 500, 2800, 1.4, 0.34 * v);
        break;
      case 'swish':
        this.noise(0.15, 'bandpass', 300, 1300, 1.2, 0.3 * v);
        break;
      case 'jump':
        this.noise(0.14, 'bandpass', 250, 900, 0.9, 0.16 * v);
        break;
      case 'land':
        this.tone('sine', 110, 50, 0.12, 0.3 * v);
        this.noise(0.1, 'lowpass', 900, 200, 0.7, 0.16 * v);
        break;
      case 'thud':
        this.tone('sine', 120, 38, 0.24, 0.6 * v);
        this.noise(0.16, 'lowpass', 700, 120, 0.7, 0.3 * v);
        break;
      case 'hit':
        this.tone('sine', 190, 48, 0.17, 0.62 * v);
        this.noise(0.1, 'lowpass', 2600, 300, 0.8, 0.42 * v);
        break;
      case 'cut':
        this.noise(0.13, 'highpass', 2400, 5200, 0.9, 0.34 * v);
        this.noise(0.16, 'bandpass', 1300, 500, 1.6, 0.34 * v);
        this.tone('sine', 150, 46, 0.16, 0.52 * v);
        break;
      case 'clang':
        this.metal(620 + Math.random() * 120, 0.42, 0.26 * v);
        this.noise(0.05, 'highpass', 3500, 6000, 0.8, 0.32 * v);
        break;
      case 'clank':
        this.metal(380 + Math.random() * 100, 0.3, 0.16 * v);
        break;
      case 'ko':
        this.tone('sine', 130, 28, 1.3, 0.9);
        this.noise(0.6, 'lowpass', 1800, 80, 0.7, 0.55);
        this.metal(190, 1.6, 0.14, 0.02);
        break;
      case 'gong':
        this.metal(104, 2.6, 0.5);
        this.tone('sine', 104, 100, 2.4, 0.5);
        this.noise(0.12, 'bandpass', 900, 400, 1, 0.2);
        break;
      case 'round':
        this.tone('sine', 96, 52, 0.4, 0.75);
        this.noise(0.12, 'lowpass', 900, 200, 0.7, 0.25);
        this.tone('sine', 96, 52, 0.4, 0.75, 0.32);
        this.noise(0.12, 'lowpass', 900, 200, 0.7, 0.25, 0.32);
        break;
      case 'win':
        [392, 523.25, 659.25, 783.99].forEach((f, i) => this.tone('triangle', f, f, 0.5, 0.26, i * 0.14));
        break;
      case 'lose':
        [392, 349.23, 293.66, 220].forEach((f, i) => this.tone('triangle', f, f * 0.98, 0.6, 0.24, i * 0.2));
        break;
      case 'twirl':
        this.noise(0.16, 'bandpass', 1500, 4200, 3, 0.2 * v);
        break;
      case 'step':
        this.tone('sine', 95, 55, 0.07, 0.2 * v);
        this.noise(0.05, 'lowpass', 1100, 300, 0.7, 0.1 * v);
        break;
      case 'skid':
        this.noise(0.26, 'bandpass', 2200, 700, 1.1, 0.22 * v);
        break;
      case 'charge':
        this.noise(0.45, 'bandpass', 300, 3200, 2.5, 0.3);
        this.tone('sawtooth', 70, 280, 0.42, 0.22);
        this.tone('sine', 220, 880, 0.42, 0.18);
        break;
      case 'deny':
        this.tone('square', 150, 110, 0.12, 0.12);
        break;
      case 'coin':
        this.tone('triangle', 1320, 1320, 0.09, 0.2);
        this.tone('triangle', 1760, 1760, 0.22, 0.2, 0.08);
        break;
      case 'ui':
        this.tone('triangle', 660, 880, 0.08, 0.16);
        break;
    }
  }

  // ───────────── ambient taiko loop ─────────────
  startMusic() {
    const ctx = this.ctx;
    if (!ctx || this.musicTimer !== null) return;
    this.musicGain.gain.cancelScheduledValues(ctx.currentTime);
    this.musicGain.gain.setTargetAtTime(1, ctx.currentTime, 0.6);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 240;
    const dg = ctx.createGain();
    dg.gain.value = 0.05;
    lp.connect(dg).connect(this.musicGain);
    for (const f of [55, 55.5, 82.6]) {
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = f;
      o.connect(lp);
      o.start();
      this.drone.push(o);
    }
    this.step = 0;
    this.nextT = ctx.currentTime + 0.1;
    const beat = 60 / 96 / 2;
    //            1 . . .  2 . . .  3 . . .  4 . . .
    const don = [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0];
    const ka = [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1];
    this.musicTimer = window.setInterval(() => {
      if (!this.ctx) return;
      while (this.nextT < this.ctx.currentTime + 0.25) {
        const d = Math.max(0, this.nextT - this.ctx.currentTime);
        const i = this.step % 16;
        const bar = Math.floor(this.step / 16) % 4;
        if (don[i] && !(bar === 3 && i > 11)) {
          this.tone('sine', i === 0 ? 105 : 92, 44, 0.3, i === 0 ? 0.42 : 0.3, d, this.musicGain);
          this.noise(0.06, 'lowpass', 600, 150, 0.7, 0.1, d, this.musicGain);
        }
        if (ka[i] && bar % 2 === 1) this.noise(0.045, 'bandpass', 2200, 1800, 3, 0.11, d, this.musicGain);
        if (bar === 3 && i >= 12) this.tone('sine', 120 + (i - 12) * 10, 60, 0.16, 0.24, d, this.musicGain);
        this.step++;
        this.nextT += beat;
      }
    }, 60);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    if (this.ctx) this.musicGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
    const old = this.drone;
    this.drone = [];
    setTimeout(() => old.forEach((o) => { try { o.stop(); } catch { /* already stopped */ } }), 700);
  }
}
