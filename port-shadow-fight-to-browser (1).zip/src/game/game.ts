import { AI, AILevel, LEVELS } from './ai';
import { Move, TAKEDOWNS_SILAT, takedownAt, throwRot } from './anims';
import { CONFIG, HeroKey, OpponentKey } from './config';
import { Fighter, GHOST_LIFE, Hooks, Input, clearInput, decayInput, newInput } from './fighter';
import { Fx } from './fx';
import { TAU, V, clamp, damp, lerp, rand, segSeg, smooth } from './math';
import { GRAVITY } from './ragdoll';
import {
  View, drawBackground, drawFighter, drawGround, drawKickTrail, drawProp, drawTrail, drawVignette, setInk, tintInk,
} from './render';
import {
  ANB, ANF, ELB, ELF, HAB, HAF, HEAD, KNB, KNF, NECK, PELVIS, TIP, TOB, TOF, WBASE, makeBuild,
} from './skeleton';

export type Phase = 'intro' | 'fight' | 'ko' | 'timeup' | 'end';
export type AnnKind = 'round' | 'fight' | 'ko' | 'info' | 'small';

export interface Hud {
  hp: [number, number];
  energy: [number, number];
  armed: [boolean, boolean];
  names: [string, string];
  rounds: [number, number];
  round: number;
  combo: number;
  comboDmg: number; // total damage of the running combo
  timer: number; // -1 = no time limit
  ready: { jump: boolean; roll: boolean; flip: boolean; super: boolean; slam: boolean };
}

export interface RoundResult {
  round: number;
  won: boolean;
  firstStrike: boolean;
  maxCombo: number;
  coinsWin: number;
  coinsCombo: number;
  coinsFirst: number;
  total: number;
}

export interface GameEvents {
  hud(h: Hud): void;
  announce(text: string, kind: AnnKind): void;
  end(playerWon: boolean, results: RoundResult[]): void;
  sfx(name: string, vol?: number): void;
}

const START_X = 185;
type Region = 'high' | 'mid' | 'low';

/** a weapon knocked out of a hand: two particles joined by a stick */
class Prop {
  vax: number; vay: number; vbx: number; vby: number;
  len: number;
  constructor(
    public kind: 'shadow' | 'titan' | 'silat', public s: number, public wLen: number, public facing: number,
    public ax: number, public ay: number, public bx: number, public by: number, vx: number, vy: number, spin: number,
  ) {
    this.len = Math.hypot(bx - ax, by - ay) || 1;
    const dx = bx - ax, dy = by - ay;
    this.vax = vx; this.vay = vy;
    this.vbx = vx - dy * spin; this.vby = vy + dx * spin;
  }
  /** returns the impact speed when it hits the floor */
  step(dt: number, minX: number, maxX: number): number {
    let hit = 0;
    const n = Math.max(1, Math.ceil(dt / (1 / 120)));
    const h = dt / n;
    for (let k = 0; k < n; k++) {
      const oax = this.ax, oay = this.ay, obx = this.bx, oby = this.by;
      this.vay += GRAVITY * h; this.vby += GRAVITY * h;
      this.ax += this.vax * h; this.ay += this.vay * h;
      this.bx += this.vbx * h; this.by += this.vby * h;
      const pa = this.vay, pb = this.vby;
      for (let it = 0; it < 3; it++) {
        let dx = this.bx - this.ax, dy = this.by - this.ay;
        const d = Math.hypot(dx, dy) || 1;
        const k2 = ((d - this.len) / d) * 0.5;
        dx *= k2; dy *= k2;
        this.ax += dx; this.ay += dy; this.bx -= dx; this.by -= dy;
        if (this.ay > -3) this.ay = -3;
        if (this.by > -3) this.by = -3;
        this.ax = clamp(this.ax, minX, maxX); this.bx = clamp(this.bx, minX, maxX);
      }
      this.vax = (this.ax - oax) / h; this.vay = (this.ay - oay) / h;
      this.vbx = (this.bx - obx) / h; this.vby = (this.by - oby) / h;
      if (this.ay >= -3.01) { if (pa > 200) { hit = Math.max(hit, pa); this.vay = -pa * 0.3; } this.vax *= Math.max(0, 1 - 8 * h); }
      if (this.by >= -3.01) { if (pb > 200) { hit = Math.max(hit, pb); this.vby = -pb * 0.3; } this.vbx *= Math.max(0, 1 - 8 * h); }
    }
    return hit;
  }
}

export class Game implements Hooks {
  f: [Fighter, Fighter];
  ai: [AI | null, AI | null] = [null, null];
  fx = new Fx();
  props: Prop[] = [];
  arena = 560;
  time = 0;
  bgTime = 0;
  mode: 'attract' | 'match' = 'attract';
  phase: Phase = 'fight';
  phaseT = 0;
  timer = 0;
  rounds: [number, number] = [0, 0];
  round = 1;
  results: RoundResult[] = [];
  hitstop = 0;
  slowT = 0;
  shakeAmt = 0;
  flash = 0;
  paused = false;
  player: Input = newInput();
  private blank: Input = newInput();
  view: View = { w: 1280, h: 720, ground: 620, camX: 0, camY: 0, zoom: 1.3 };
  bg: CanvasImageSource | null = null;
  bgW = 0;
  bgH = 0;
  private winner = 0;
  private firstStrikeBy = -1;
  private fightCalled = false;
  private coinsCalled = false;
  private pending: RoundResult | null = null;
  private throwDmg = 0;
  private tdDmg = 0;
  /** 0..1: a takedown is playing – the picture darkens, zooms in and gets letterbox bars */
  cine = 0;
  private attractN = 0;
  private comboDmg = 0;
  /** canvas factory for hosts without a DOM (tests) */
  makeCanvas: ((w: number, h: number) => HTMLCanvasElement) | null = null;
  private gcv: HTMLCanvasElement | null = null;
  private hudKey = '';
  private level: AILevel = LEVELS.normal;
  private opponent: OpponentKey = 'titan';

  constructor(public ev: GameEvents) {
    this.f = [new Fighter(makeBuild(CONFIG.player), 0), new Fighter(makeBuild(CONFIG.opponents.titan), 1)];
    this.startAttract();
  }

  // ───────────── hooks used by the fighters ─────────────
  sfx(name: string, vol?: number) {
    if (this.mode === 'attract') return;
    this.ev.sfx(name, vol);
  }
  dust(x: number, amount: number) {
    this.fx.dust(x, amount);
  }
  shake(a: number) {
    this.shakeAmt = Math.max(this.shakeAmt, a * CONFIG.feel.shake);
  }
  styleFx(f: Fighter) {
    this.fx.text(f.j[HEAD].x, f.j[HEAD].y - 46 * f.build.scale, 'FREESTYLE', '#9be7ff', 22);
    this.sfx('coin', 0.45);
  }
  superFx(f: Fighter) {
    const p = f.j[PELVIS];
    this.fx.charge(p.x, p.y - 30 * f.build.scale);
    this.fx.text(f.j[HEAD].x, f.j[HEAD].y - 46, 'SUPER STRIKE', '#c9b4ff', 26);
    this.sfx('charge', 1);
    this.slowT = Math.max(this.slowT, 0.42);
    this.flash = Math.max(this.flash, 0.3);
  }

  // ───────────── flow ─────────────
  private resetFighters(keepEnergy: boolean) {
    this.f[0].reset(-START_X, 1, keepEnergy);
    this.f[1].reset(START_X, -1, keepEnergy);
    this.f[0].input = newInput();
    this.f[1].input = newInput();
    this.f[0].powerMul = 1;
    this.f[0].human = this.mode === 'match';
    this.f[1].powerMul = this.mode === 'match' ? this.level.dmg : 1;
    this.fx.clear();
    this.props.length = 0;
    this.cine = 0;
    this.hitstop = 0; this.slowT = 0; this.flash = 0; this.shakeAmt = 0;
    this.firstStrikeBy = -1;
    this.comboDmg = 0;
    clearInput(this.player);
  }

  startAttract() {
    this.mode = 'attract';
    // the demo behind the menu alternates between the two heroes
    const n = this.attractN++;
    const hero = n % 2 === 0 ? CONFIG.heroes.pandeka : CONFIG.heroes.shadow;
    const foe = n % 3 === 2 ? CONFIG.opponents.ronin : CONFIG.opponents.titan;
    this.f = [new Fighter(makeBuild(hero), 0), new Fighter(makeBuild(foe), 1)];
    this.ai = [new AI(LEVELS.hard), new AI(LEVELS.normal)];
    this.phase = 'fight'; this.phaseT = 0;
    this.resetFighters(false);
    this.view.camX = 0;
  }

  startMatch(level: keyof typeof LEVELS, opponent: OpponentKey = 'titan', hero: HeroKey = 'shadow') {
    this.mode = 'match';
    this.level = LEVELS[level] ?? LEVELS.normal;
    this.opponent = CONFIG.opponents[opponent] ? opponent : 'titan';
    this.f = [new Fighter(makeBuild(CONFIG.heroes[hero] ?? CONFIG.player), 0), new Fighter(makeBuild(CONFIG.opponents[this.opponent]), 1)];
    this.rounds = [0, 0];
    this.results = [];
    this.round = 1;
    this.paused = false;
    this.startRound();
  }

  private startRound() {
    this.ai = [null, new AI(this.level)];
    this.resetFighters(this.round > 1);
    this.f[0].enter();
    this.f[1].enter();
    this.timer = CONFIG.round.timeLimit;
    this.phase = 'intro'; this.phaseT = 0; this.fightCalled = false; this.coinsCalled = false; this.pending = null;
    this.view.camX = 0;
    this.view.zoom = 1.05;
    this.ev.announce(`RONDE ${this.round}`, 'round');
    this.ev.sfx('round', 1);
    this.emitHud(true);
  }

  /** coins are counted per round: win bonus + highest combo + first strike */
  private roundResult(): RoundResult {
    const p = this.f[0], C = CONFIG.coins;
    const won = this.winner === 0;
    const first = this.firstStrikeBy === 0;
    const coinsWin = won ? C.roundWin : 0;
    const coinsCombo = p.maxCombo * C.perComboHit;
    const coinsFirst = first ? C.firstStrike : 0;
    return { round: this.round, won, firstStrike: first, maxCombo: p.maxCombo, coinsWin, coinsCombo, coinsFirst, total: coinsWin + coinsCombo + coinsFirst };
  }

  private endRound() {
    if (this.mode === 'attract') {
      this.startAttract();
      return;
    }
    this.results.push(this.pending ?? this.roundResult());
    this.rounds[this.winner]++;
    this.emitHud(true);
    if (this.rounds[this.winner] >= CONFIG.round.roundsToWin || this.round >= CONFIG.round.maxRounds) {
      this.phase = 'end'; this.phaseT = 0;
      this.ev.end(this.rounds[0] > this.rounds[1], this.results);
    } else {
      this.round++;
      this.startRound();
    }
  }

  private emitHud(force = false) {
    if (this.mode !== 'match') return;
    const [a, b] = this.f;
    const h0 = Math.max(0, a.hp / a.build.hp), h1 = Math.max(0, b.hp / b.build.hp);
    const e0 = Math.round(a.energy), e1 = Math.round(b.energy);
    const t = CONFIG.round.timeLimit > 0 ? Math.max(0, Math.ceil(this.timer)) : -1;
    const ready = { jump: a.cdJump <= 0, roll: a.cdRoll <= 0, flip: a.cdFlip <= 0, super: a.energy >= CONFIG.energy.max, slam: a.slamReady };
    const key = `${h0.toFixed(3)}|${h1.toFixed(3)}|${e0}|${e1}|${t}|${this.rounds[0]}${this.rounds[1]}|${this.round}|${a.combo}|${Math.round(this.comboDmg)}|${+a.armed}${+b.armed}|${+ready.jump}${+ready.roll}${+ready.flip}${+ready.super}${+ready.slam}`;
    if (!force && key === this.hudKey) return;
    this.hudKey = key;
    this.ev.hud({
      hp: [h0, h1], energy: [e0 / CONFIG.energy.max, e1 / CONFIG.energy.max], armed: [a.armed, b.armed],
      names: [a.build.name, b.build.name], rounds: [this.rounds[0], this.rounds[1]], round: this.round,
      combo: a.combo, comboDmg: Math.round(this.comboDmg), timer: t, ready,
    });
  }

  // ───────────── combat ─────────────
  private knockOut(a: Fighter) {
    this.hitstop = 0.2; this.slowT = 1.7; this.flash = 1;
    this.shake(18);
    this.sfx('ko', 1);
    this.winner = a.idx;
    this.phase = 'ko'; this.phaseT = 0;
    this.pending = this.roundResult();
    if (this.mode === 'match') this.ev.announce('K.O.', 'ko');
  }

  /** SHOCK: the weapon is torn out of the hand and stays on the floor until the round ends */
  private disarm(d: Fighter, dir: number) {
    const b = d.j[WBASE], t = d.j[TIP];
    this.props.push(new Prop(
      d.build.kind, d.build.scale, d.build.wLen, d.facing, b.x, b.y, t.x, t.y,
      dir * 240 + rand(-70, 70), -640, rand(6, 10) * (Math.random() < 0.5 ? -1 : 1),
    ));
    d.disarm();
    this.sfx('clang', 1);
  }

  private resolve(a: Fighter, d: Fighter) {
    const m = a.move;
    if (!a.hitActive || !m) return; // hitbox only exists in the ACTIVE phase
    if (d.state === 'ragdoll' && !d.dead) {
      // JUGGLE: a launched opponent can be struck again while still in the air
      const J = CONFIG.combo;
      if (m.part === 'grab' || d.juggled >= J.juggleMax || d.stateT < 0.08 || -d.j[PELVIS].y < J.juggleMinHeight * d.build.scale) return;
    } else if (d.down || d.dead || d.invuln > 0) return;
    const sa = a.build.scale, sd = d.build.scale, thd = Math.min(d.build.thick, 1.25);
    const usesWeapon = m.base === 'punch' || m.base === 'super' || m.base === 'flurry' || m.base === 'rapid' || (m.base === 'heavy' && m.part === 'weapon');
    // configured range (bare hands reach less far)
    const cap = m.range * sa * a.build.reach * (usesWeapon && !a.armed ? CONFIG.shock.unarmedRange : 1);
    if (Math.abs(d.x - a.x) > cap) return;

    if (m.part === 'grab') {
      if (d.aloft || (d.x - a.x) * a.facing < 0) return;
      const c = d.j[NECK];
      this.applyHit(a, d, m, 'mid', c.x, c.y + 20 * sd);
      return;
    }

    let p0: V, p1: V, r: number;
    const aj = a.j;
    // the strike counts from the elbow to the tip, so it also lands at point-blank range
    if (m.part === 'weapon' && a.armed) { p0 = aj[ELF]; p1 = aj[TIP]; r = 7 * sa; }
    else if (m.part === 'weapon' || m.part === 'handF') { p0 = aj[ELF]; p1 = aj[HAF]; r = 11 * sa; }
    else if (m.part === 'handB') { p0 = aj[ELB]; p1 = aj[HAB]; r = 11 * sa; }
    else if (m.part === 'footF') { p0 = aj[KNF]; p1 = aj[TOF]; r = 11 * sa; }
    else { p0 = aj[KNB]; p1 = aj[TOB]; r = 11 * sa; }
    const dj = d.j;
    const boxes: [V, V, number, Region][] = [
      [dj[HEAD], dj[HEAD], 15 * sd, 'high'],
      [dj[NECK], dj[PELVIS], 17 * sd * thd, 'mid'],
      [dj[PELVIS], dj[KNF], 10 * sd * thd, 'low'],
      [dj[KNF], dj[ANF], 8 * sd * thd, 'low'],
      [dj[PELVIS], dj[KNB], 10 * sd * thd, 'low'],
      [dj[KNB], dj[ANB], 8 * sd * thd, 'low'],
    ];
    let pen = 0, hx = 0, hy = 0, region: Region = 'mid', found = false;
    for (const bx of boxes) {
      const h = segSeg(p0, p1, bx[0], bx[1]);
      const pn = h.dist - r - bx[2];
      if (pn < pen) { pen = pn; hx = h.x; hy = h.y; region = bx[3]; found = true; }
    }
    if (found) this.applyHit(a, d, m, region, hx, hy);
  }

  private applyHit(a: Fighter, d: Fighter, m: Move, region: Region, hx: number, hy: number) {
    const C = CONFIG;
    a.hitDone = true; a.hitActive = false;
    const dir = a.facing;
    const usesWeapon = m.base === 'punch' || m.base === 'super' || m.base === 'flurry' || m.base === 'rapid' || (m.base === 'heavy' && m.part === 'weapon');
    const isThrow = m.part === 'grab';
    let dmg = m.dmg * a.build.power * a.powerMul * (usesWeapon && !a.armed ? C.shock.unarmedDamage : 1);
    const live = this.phase === 'fight';
    const juggle = d.state === 'ragdoll';
    // a multi-hit move: only its last hit carries the heavy reaction / the launch
    const more = a.hitsLeft > 0;
    const heavy = !!m.heavy && !more;
    const knock = more ? undefined : m.knock;
    // hook-and-pull and pass-through strikes drag the opponent the other way
    const rdir = dir * (m.kbDir ?? 1);

    // ── BLOCK: reduced damage, no combo, no bonuses. Throws go straight through. ──
    if (!isThrow && d.canBlock()) {
      d.hp = Math.max(1, d.hp - dmg * C.block.damageMul);
      a.combo = 0;
      a.addEnergy(m.energy * C.energy.blockedFactor);
      d.addEnergy(C.energy.onBlockTaken);
      d.takeBlock(m.kb * (m.heavy ? 1.5 : 1), dir);
      a.kb = -dir * 90;
      this.fx.hit(hx, hy, dir, m.heavy ? 1.15 : 0.75, 'block');
      this.sfx('clang', m.heavy ? 1 : 0.8);
      this.hitstop = m.heavy ? 0.08 : 0.045;
      this.shake(m.heavy ? 7 : 3.5);
      d.hitShake = this.hitstop + 0.04;
      return;
    }

    a.connected = true;
    const tx = d.j[HEAD].x, ty = d.j[HEAD].y - 44 * d.build.scale;

    // 1. HEAD HIT: +60% (not against exempt types such as the Gatekeeper)
    const head = region === 'high' && !isThrow;
    if (head && !C.headHit.exemptTypes.includes(d.build.type)) {
      dmg *= 1 + C.headHit.bonus;
      this.fx.text(tx, ty, 'HEAD HIT', '#ffe08a');
    }
    // 3. CRITICAL HIT: +50% and a knock-down (antiKnockdown fighters stay on their feet)
    const crit = Math.random() < C.crit.chance;
    if (crit) {
      dmg *= 1 + C.crit.bonus;
      this.fx.text(tx, ty, 'CRITICAL', '#ff8a4c', 28);
    }
    // 4. SHOCK: a head hit may disarm (never a boss)
    if (head && d.armed && !C.shock.immuneTypes.includes(d.build.type) && Math.random() < C.shock.chance) {
      this.disarm(d, dir);
      this.fx.text(tx, ty, 'SHOCK', '#8fe9ff', 28);
    }
    // 5. FIRST STRIKE: first unblocked hit of the round
    if (live && this.firstStrikeBy < 0) {
      this.firstStrikeBy = a.idx;
      this.fx.text(tx, ty, 'FIRST STRIKE', '#ffffff', 26);
      if (this.mode === 'match') this.ev.announce('FIRST STRIKE', 'small');
    }
    // 2. COMBO: every unblocked hit in a row
    a.combo++;
    if (a.combo > a.maxCombo) a.maxCombo = a.combo;
    if (a.combo >= C.takedown.hits) a.slamT = C.takedown.window;
    // 6. SHADOW ENERGY: fills when attacking and when being hit
    a.addEnergy(m.energy);
    d.addEnergy(C.energy.onHitTaken);
    if (juggle) dmg *= C.combo.juggleDamage;
    dmg *= Math.max(C.combo.scalingMin, Math.pow(C.combo.scaling, d.hitsTaken));
    d.hitsTaken++;
    if (a.idx === 0) this.comboDmg = a.combo === 1 ? dmg : this.comboDmg + dmg;

    // a throw that connects becomes a paired sequence: grab -> hoist -> hurl (damage lands on release)
    if (isThrow && !d.build.antiKnockdown) {
      this.throwDmg = dmg;
      a.beginThrow();
      d.beGrabbed();
      this.fx.hit(hx, hy, dir, 0.6, 'blunt');
      this.sfx('hit', 0.6);
      this.hitstop = 0.07; this.shake(4);
      return;
    }

    d.hp = Math.max(0, d.hp - dmg);
    const power = clamp(dmg / 10, 0.6, 1.8);
    const cut = usesWeapon && a.armed && m.part === 'weapon'; // elbows and knees land as blunt blows
    this.fx.hit(hx, hy, dir, power, cut ? 'slash' : 'blunt');
    if (m.base === 'super') this.fx.burst(hx, hy);
    this.sfx(cut ? 'cut' : 'hit', power);
    if (cut) this.fx.ink(hx, hy, dir, 2 + Math.round(power * 3));
    this.view.zoom *= 1 + 0.01 * power * C.feel.kick; // every blow kicks the camera in a little

    const fall = (!!knock || crit || isThrow) && !d.build.antiKnockdown;
    if (d.hp <= 0) {
      const k = m.koImp;
      d.toRagdoll(dir * k[0] * 1.1, -k[1] * 1.1, hx, hy, k[2], true);
      this.knockOut(a);
    } else if (juggle) {
      // popped up again – a finisher that strikes downwards spikes the body into the floor instead
      const P = C.combo.jugglePop;
      const spike = knock !== undefined && knock[1] < 0;
      d.juggleHit(dir * (spike ? knock![0] : P[0] * (heavy ? 1.6 : 1) * (m.through ? -0.4 : 1)), spike ? -knock![1] : -P[1] * (heavy ? 1.15 : 1));
      if (d.juggled === 1) this.fx.text(tx, ty, 'JUGGLE', '#b8ffb0', 24);
      this.hitstop = more ? 0.05 : m.stop; this.shake(6);
    } else if (fall || d.aloft) {
      const k = knock ?? [m.kb * 1.3 + 220, 330, 0.4];
      d.toRagdoll(dir * k[0], -k[1], hx, hy, k[2], false);
      this.hitstop = Math.max(m.stop, crit ? 0.12 : 0); this.shake(10);
      this.view.zoom *= 1.035;
    } else if (d.build.armor && d.state === 'attack' && !heavy && !knock && !isThrow && !more) {
      // super armour: the blow lands but does not interrupt the swing
      d.flv += region === 'mid' ? 150 : -190;
      d.kb = (dir * m.kb * 0.35) / d.build.mass;
      this.hitstop = m.stop * 0.7; this.shake(3);
    } else if (heavy || knock || crit || isThrow) {
      d.takeStagger(Math.max(m.kb, 360), rdir, m.kbDir === -1 && !m.through ? 'mid' : region);
      this.hitstop = m.stop * 1.15; this.shake(9);
      this.view.zoom *= 1.03;
    } else {
      d.takeHit(region, more ? 30 : m.kb, rdir);
      this.hitstop = more ? 0.05 : m.stop; this.shake(4 + power * 3);
    }
    d.hitShake = this.hitstop + 0.05;
    d.hitFlash = C.feel.flashTime * (heavy || knock ? 1 : 0.8);
    // a long combo closed with a knock-down gets a beat of slow motion
    if (m.cine && d.hp > 0) this.slowT = Math.max(this.slowT, 0.3);
    if (a.combo >= C.combo.finisherAt && (knock || m.base === 'super') && d.hp > 0) {
      this.slowT = Math.max(this.slowT, 0.34);
      this.view.zoom *= 1.04;
    }
  }

  // ───────────── takedown (Space) ─────────────
  /** the prompt: enough hits in a row on an opponent who is still reeling and close enough */
  private canSlam(a: Fighter, d: Fighter): boolean {
    const T = CONFIG.takedown;
    if (this.phase !== 'fight' || a.combo < T.hits || a.slamT <= 0 || a.cdSlam > 0) return false;
    // the opponent must still be reeling, or only just back on guard – not blocking, attacking or in the air
    if (d.dead || d.build.antiKnockdown || (d.state !== 'hit' && d.state !== 'stagger' && d.state !== 'stand')) return false;
    if ((a.state !== 'attack' && a.state !== 'stand') || a.aloft || d.aloft) return false;
    const dx = (d.x - a.x) * a.facing;
    return dx > 0 && dx < T.range * a.build.scale;
  }

  private startTakedown(a: Fighter, d: Fighter) {
    const T = CONFIG.takedown, s = a.build.scale;
    a.combo++;
    if (a.combo > a.maxCombo) a.maxCombo = a.combo;
    a.addEnergy(T.energy);
    d.addEnergy(CONFIG.energy.onHitTaken);
    a.cdSlam = T.cooldown;
    this.tdDmg = T.damage * a.build.power * a.powerMul;
    // Pandeka cycles through his scenes: once one has played, the next one is different
    const td = a.silat ? TAKEDOWNS_SILAT[a.tdN++ % TAKEDOWNS_SILAT.length] : null;
    // room needed between the thrower and the wall: the slam spot plus the length of the body lying there
    const room = this.arena + 70 - 140 * d.build.scale * Math.min(d.build.thick, 1.25) - (td ? td.room : 116) * s;
    if (td) a.beginTakedown(td, Math.abs(d.x - a.x), room - a.facing * a.x);
    else {
      // other fighters: the hoist-and-hurl throw, with the takedown's damage
      this.throwDmg = this.tdDmg;
      if (a.idx === 0) this.comboDmg += this.tdDmg;
      a.beginThrow();
    }
    d.beGrabbed();
    this.fx.text(d.j[HEAD].x, d.j[HEAD].y - 50 * s, td ? td.name : 'BANTING!', '#ff8a4c', 30);
    this.sfx('hit', 0.8);
    this.hitstop = 0.09; this.shake(6);
  }

  /** one of the two blows of a takedown */
  private tdHit(t: Fighter, v: Fighter, part: number, final: boolean) {
    const dir = t.facing, dmg = this.tdDmg * part;
    const p = v.j[PELVIS], n = v.j[NECK];
    const cx = (p.x + n.x) / 2, cy = (p.y + n.y) / 2;
    v.hp = Math.max(final ? 0 : 1, v.hp - dmg);
    if (t.idx === 0) this.comboDmg += dmg;
    v.hitFlash = CONFIG.feel.flashTime * 1.15;
    if (!final) {
      this.fx.dust(cx, 1.5);
      this.fx.hit(cx, cy, dir, 1.5, 'blunt');
      this.sfx('thud', 1); this.sfx('hit', 1);
      this.hitstop = 0.16; this.shake(15);
      return;
    }
    this.fx.hit(cx, cy, dir, 1.6, t.armed ? 'slash' : 'blunt');
    if (t.takedown?.floorSpark) this.fx.dust(cx, 1.1);
    this.fx.ink(cx, cy, 1, 5);
    this.fx.ink(cx, cy, -1, 5);
    this.sfx(t.armed ? 'cut' : 'hit', 1.4);
    this.hitstop = 0.15; this.shake(11);
    this.flash = Math.max(this.flash, 0.16);
    if (v.hp <= 0) {
      v.toRagdoll(dir * 140, -240, cx, cy, 0.2, true);
      this.knockOut(t);
    }
  }

  /** the victim hangs between the thrower's hands until it is let go */
  private carry(t: Fighter, v: Fighter, dt: number) {
    const dir = t.facing;
    const c = v.j[NECK];
    if (t.state !== 'throwing') {
      // safety: never leave anybody hanging in the air
      v.toRagdoll(dir * 200, 0, c.x, c.y, 0.1, false);
      return;
    }
    const td = t.takedown;
    if (td) {
      const now = t.animT, prev = t.tdPrev;
      const q = takedownAt(td, now);
      v.slamUpdate(dt, t.x + dir * q[0] * t.build.scale, q[1] * v.build.scale, q[2], smooth(now / 0.12), td.victim, now, this);
      const cross = (x: number) => prev < x && now >= x;
      if (cross(td.hang)) this.slowT = Math.max(this.slowT, 0.42);
      if (cross(td.impact)) this.tdHit(t, v, 0.4, false);
      if (cross(td.stab)) this.tdHit(t, v, 0.6, true);
      if (cross(td.release) && v.state === 'grabbed') v.toRagdoll(dir * 90, -170, c.x, c.y, 0.2, false);
      return;
    }
    // held at arm's length first, then pulled in over the shoulders
    const gx = (t.j[HAF].x + t.j[HAB].x) / 2 + dir * 26 * t.build.scale * (1 - smooth((t.animT - 0.16) / 0.2));
    const gy = (t.j[HAF].y + t.j[HAB].y) / 2;
    v.heldUpdate(dt, gx, gy, throwRot(t.animT), smooth(t.animT / 0.14), this);
    if (t.throwRelease) {
      t.throwRelease = false;
      const I = CONFIG.throwAnim.impulse;
      v.hp = Math.max(0, v.hp - this.throwDmg);
      const dead = v.hp <= 0;
      v.toRagdoll(dir * I[0], I[1], c.x, c.y, 0.1, dead);
      this.shake(7);
      if (dead) this.knockOut(t);
    }
  }

  private clash(a: Fighter, b: Fighter): boolean {
    if (!a.hitActive || !b.hitActive || !a.move || !b.move) return false;
    if (a.move.part !== 'weapon' || b.move.part !== 'weapon' || !a.armed || !b.armed) return false;
    if (a.move.base === 'super' || b.move.base === 'super') return false;
    const h = segSeg(a.j[HAF], a.j[TIP], b.j[HAF], b.j[TIP]);
    if (h.dist > 10) return false;
    a.hitDone = b.hitDone = true;
    a.hitActive = b.hitActive = false;
    a.combo = 0; b.combo = 0;
    if (a.grounded) a.takeBlock(330, -a.facing);
    if (b.grounded) b.takeBlock(330, -b.facing);
    this.fx.hit(h.x, h.y, 1, 1.3, 'block');
    this.fx.hit(h.x, h.y, -1, 1.3, 'block');
    this.sfx('clang', 1);
    this.hitstop = 0.09; this.shake(7);
    return true;
  }

  // ───────────── main update ─────────────
  update(realDt: number) {
    if (this.paused) return;
    realDt = Math.min(realDt, 1 / 30);
    this.phaseT += realDt;
    this.bgTime += realDt;

    let ts = 1;
    if (this.slowT > 0) {
      this.slowT -= realDt;
      ts = this.slowT > 0.5 ? 0.14 : lerp(1, 0.14, Math.max(0, this.slowT) / 0.5);
    }
    let dt = realDt * ts;
    if (this.hitstop > 0) {
      this.hitstop -= realDt;
      this.fx.update(realDt * 0.25);
      dt = 0;
    }
    this.time += dt;
    this.flash = Math.max(0, this.flash - realDt * 3.2);
    this.f[0].hitShake -= realDt;
    this.f[1].hitShake -= realDt;
    this.f[0].hitFlash -= realDt;
    this.f[1].hitFlash -= realDt;
    this.cine = damp(this.cine, this.f.some((f) => f.state === 'throwing' && f.takedown !== null) ? 1 : 0, 9, realDt);
    this.shakeAmt = damp(this.shakeAmt, 0, 11, realDt);
    this.fx.updateTexts(realDt);

    const [a, b] = this.f;
    if (this.phase === 'intro') {
      if (!this.fightCalled && this.phaseT > 1.25) {
        this.fightCalled = true;
        this.ev.announce('BERTARUNG!', 'fight');
        this.ev.sfx('gong', 1);
      }
      if (this.phaseT > CONFIG.round.introTime) { this.phase = 'fight'; this.phaseT = 0; }
    } else if (this.phase === 'fight') {
      if (this.mode === 'match' && CONFIG.round.timeLimit > 0) {
        this.timer -= dt;
        if (this.timer <= 0) {
          this.timer = 0;
          this.phase = 'timeup'; this.phaseT = 0;
          this.winner = a.hp / a.build.hp > b.hp / b.build.hp ? 0 : 1;
          this.pending = this.roundResult();
          this.ev.announce('WAKTU HABIS', 'info');
          this.ev.sfx('gong', 1);
        }
      }
    } else if (this.phase === 'ko' || this.phase === 'timeup') {
      const w = this.f[this.winner];
      if (this.phaseT > 1.0 && w.state === 'stand') w.celebrate();
      if (!this.coinsCalled && this.phaseT > 1.9 && this.mode === 'match' && this.pending) {
        this.coinsCalled = true;
        this.ev.announce(`+${this.pending.total} KOIN`, 'small');
        this.ev.sfx('coin', 1);
      }
      if (this.phaseT > (this.mode === 'attract' ? 4 : CONFIG.round.koTime)) this.endRound();
    }

    // inputs
    const live = this.phase === 'fight';
    for (let i = 0; i < 2; i++) {
      const f = this.f[i];
      const ai = this.ai[i];
      if (ai) {
        decayInput(f.input, realDt);
        if (live) ai.think(f, this.f[1 - i], dt);
        else clearInput(f.input);
      } else {
        decayInput(this.player, realDt);
        f.input = live ? this.player : this.blank;
      }
    }

    if (dt > 0) {
      // TAKEDOWN prompt + trigger
      for (let i = 0; i < 2; i++) {
        const f = this.f[i], o = this.f[1 - i];
        f.slamReady = this.canSlam(f, o);
        if (f.input.slam > 0 && f.slamReady) {
          f.input.slam = 0;
          f.slamReady = false;
          this.startTakedown(f, o);
        }
      }
      a.update(dt, b, this);
      b.update(dt, a, this);
      if (a.state === 'grabbed') this.carry(b, a, dt);
      else if (b.state === 'grabbed') this.carry(a, b, dt);

      // bodies cannot overlap
      if (!a.down && !b.down && a.state !== 'roll' && b.state !== 'roll' && !a.passing && !b.passing && Math.abs(a.elev - b.elev) < 90) {
        const min = 62 * (a.build.scale + b.build.scale) * 0.5;
        const d = b.x - a.x;
        if (Math.abs(d) < min) {
          const sgn = d === 0 ? a.facing : Math.sign(d);
          const push = (min - Math.abs(d)) / 2;
          a.x -= sgn * push; b.x += sgn * push;
          if (a.x < -this.arena) { b.x += -this.arena - a.x; a.x = -this.arena; }
          if (b.x > this.arena) { a.x -= b.x - this.arena; b.x = this.arena; }
          if (b.x < -this.arena) { a.x += -this.arena - b.x; b.x = -this.arena; }
          if (a.x > this.arena) { b.x -= a.x - this.arena; a.x = this.arena; }
        }
      }

      if (this.phase === 'fight') {
        if (!this.clash(a, b)) {
          this.resolve(a, b);
          if (this.phase === 'fight') this.resolve(b, a);
        }
      }
      for (const p of this.props) {
        const hit = p.step(dt, -this.arena - 70, this.arena + 70);
        if (hit > 320) this.sfx('clank', clamp(hit / 900, 0.2, 0.8));
      }
      this.fx.update(dt);
    }

    this.updateCamera(realDt);
    this.emitHud();
  }

  private updateCamera(dt: number) {
    const v = this.view;
    if (!Number.isFinite(v.zoom) || !Number.isFinite(v.camX) || !Number.isFinite(v.camY)) {
      v.zoom = 1.2; v.camX = 0; v.camY = 0;
    }
    const pa = this.f[0].j[PELVIS], pb = this.f[1].j[PELVIS];
    let tx = (pa.x + pb.x) / 2;
    const dist = Math.abs(pa.x - pb.x);
    let tz = clamp(v.w / (dist + 470), 0.76, 1.62);
    if (this.cine > 0.01) tz = lerp(tz, Math.min(1.9, tz * 1.34), this.cine);
    if (this.phase === 'ko' && this.phaseT < 2.6) {
      const vic = this.f[1 - this.winner].j[PELVIS];
      tx = lerp(tx, vic.x, 0.5);
      tz = Math.min(1.75, tz * 1.14);
    }
    const top = Math.max(-this.f[0].j[HEAD].y, -this.f[1].j[HEAD].y);
    const ty = Math.max(0, top - (v.ground - 70) / tz);
    v.zoom = damp(v.zoom, tz, 4.5, dt);
    const half = v.w / 2 / v.zoom;
    const lim = Math.max(0, this.arena + 230 - half);
    v.camX = damp(v.camX, clamp(tx, -lim, lim), 5.5, dt);
    v.camY = damp(v.camY, ty, 6, dt);
  }

  /** called after a frame threw: put everything back into a state that can be simulated and drawn */
  recover() {
    const v = this.view;
    if (!Number.isFinite(v.zoom) || !Number.isFinite(v.camX) || !Number.isFinite(v.camY)) {
      v.zoom = 1.2; v.camX = 0; v.camY = 0;
    }
    if (!Number.isFinite(this.hitstop)) this.hitstop = 0;
    if (!Number.isFinite(this.slowT)) this.slowT = 0;
    if (!Number.isFinite(this.flash)) this.flash = 0;
    if (!Number.isFinite(this.shakeAmt)) this.shakeAmt = 0;
    this.fx.clear();
    this.props.length = 0;
    this.gcv = null;
    let bad = false;
    for (const f of this.f) {
      if (!Number.isFinite(f.x) || !Number.isFinite(f.elev)) bad = true;
      for (const p of f.j) if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) bad = true;
      for (const gh of f.ghosts) gh.age = 9;
    }
    if (bad) {
      if (this.mode === 'attract') this.startAttract();
      else this.startRound();
    }
  }

  setView(w: number, h: number) {
    // a hidden or not yet laid out page reports 0 × 0 – keep the last valid view instead of poisoning it with NaN
    if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return;
    this.view.w = w;
    this.view.h = h;
    this.view.ground = Math.round(Math.min(h * 0.865, h / 2 + 300));
  }

  // ───────────── render ─────────────
  /**
   * Afterimages. Each one is drawn opaque into a scratch canvas and then blended in as a whole,
   * so overlapping limbs do not add up to darker patches.
   */
  private drawGhosts(ctx: CanvasRenderingContext2D, f: Fighter) {
    let n = 0;
    for (const gh of f.ghosts) if (gh.age < GHOST_LIFE) n++;
    if (!n || f.dead || typeof ctx.getTransform !== 'function') return;
    const main = ctx.canvas;
    if (!main) return;
    if (!this.gcv || this.gcv.width !== main.width || this.gcv.height !== main.height) {
      if (this.makeCanvas) this.gcv = this.makeCanvas(main.width, main.height);
      else if (typeof document !== 'undefined') {
        this.gcv = document.createElement('canvas');
        this.gcv.width = main.width; this.gcv.height = main.height;
      } else return;
    }
    const gc = this.gcv.getContext('2d');
    if (!gc) return;
    const m = ctx.getTransform();
    const pad = 64 * f.build.scale * Math.hypot(m.a, m.b);
    const list = f.ghosts.filter((gh) => gh.age < GHOST_LIFE).sort((p, q) => q.age - p.age);
    const j0 = f.j, e0 = f.ex;
    for (const gh of list) {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const p of gh.j) {
        const X = m.a * p.x + m.c * p.y + m.e, Y = m.b * p.x + m.d * p.y + m.f;
        if (X < x0) x0 = X;
        if (X > x1) x1 = X;
        if (Y < y0) y0 = Y;
        if (Y > y1) y1 = Y;
      }
      x0 = Math.max(0, Math.floor(x0 - pad)); y0 = Math.max(0, Math.floor(y0 - pad));
      x1 = Math.min(main.width, Math.ceil(x1 + pad)); y1 = Math.min(main.height, Math.ceil(y1 + pad));
      const w = x1 - x0, h = y1 - y0;
      if (w <= 0 || h <= 0) continue;
      gc.save();
      gc.setTransform(1, 0, 0, 1, 0, 0);
      gc.clearRect(x0, y0, w, h);
      gc.beginPath();
      gc.rect(x0, y0, w, h);
      gc.clip();
      gc.setTransform(m.a, m.b, m.c, m.d, m.e, m.f);
      try {
        f.j = gh.j; f.ex = gh.ex;
        drawFighter(gc, f, true);
      } finally {
        f.j = j0; f.ex = e0;
        gc.restore();
      }
      const k = 1 - gh.age / GHOST_LIFE;
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = 0.22 * k;
      ctx.drawImage(this.gcv, x0, y0, w, h, x0, y0, w, h);
      ctx.restore();
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    const v = this.view;
    ctx.save();
    if (this.shakeAmt > 0.2 && !this.paused) {
      ctx.translate((Math.random() - 0.5) * 2 * this.shakeAmt, (Math.random() - 0.5) * 2 * this.shakeAmt);
    }
    drawBackground(ctx, v, this.bgTime, this.bg, this.bgW, this.bgH);
    if (this.cine > 0.01) {
      ctx.fillStyle = `rgba(14,5,0,${(0.5 * this.cine).toFixed(3)})`;
      ctx.fillRect(-20, -20, v.w + 40, v.h + 40);
    }

    ctx.save();
    ctx.translate(v.w / 2, v.ground + v.camY * v.zoom);
    ctx.scale(v.zoom, v.zoom);
    ctx.translate(-v.camX, 0);
    const half = v.w / 2 / v.zoom + 40;
    drawGround(ctx, v.camX - half, v.camX + half, (v.h - v.ground) / v.zoom + 60);
    this.fx.drawDust(ctx);
    const [a, b] = this.f;

    // shadow energy aura: full bar = super strike ready
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const f of this.f) {
      const sup = f.move?.base === 'super';
      if ((f.energy >= CONFIG.energy.max || sup) && !f.dead) {
        const p = f.j[PELVIS], s = f.build.scale;
        const r = (sup ? 150 : 105 + Math.sin(this.bgTime * 5) * 10) * s;
        const cy = p.y - 34 * s;
        const g = ctx.createRadialGradient(p.x, cy, 0, p.x, cy, r);
        g.addColorStop(0, `rgba(150,110,255,${sup ? 0.55 : 0.32})`);
        g.addColorStop(0.5, 'rgba(110,70,255,0.14)');
        g.addColorStop(1, 'rgba(90,50,255,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, cy, r, 0, TAU);
        ctx.fill();
      }
    }
    ctx.restore();

    for (const p of this.props) drawProp(ctx, p.kind, p.ax, p.ay, p.bx, p.by, p.facing, p.s, p.wLen);

    const first = a.down && !b.down ? a : b.down && !a.down ? b : b.state === 'attack' ? a : b;
    const second = first === a ? b : a;
    this.drawGhosts(ctx, first);
    this.drawGhosts(ctx, second);
    for (const f of [first, second]) {
      // impact flash: a warm tint that eases out instead of a hard white frame
      if (f.hitFlash > 0 && !this.paused) {
        const u = Math.min(1, f.hitFlash / CONFIG.feel.flashTime);
        tintInk(CONFIG.feel.flash * u * u * (3 - 2 * u));
      }
      if (f.hitShake > 0 && !this.paused) {
        const amp = Math.min(1, f.hitShake * 14) * 3.4;
        ctx.save();
        ctx.translate(Math.sin(this.bgTime * 120 + f.idx * 2) * amp, Math.cos(this.bgTime * 97) * amp * 0.35);
        drawFighter(ctx, f);
        ctx.restore();
      } else drawFighter(ctx, f);
      setInk();
    }
    ctx.save();
    ctx.beginPath();
    ctx.rect(v.camX - half, -4000, half * 2, 4000);
    ctx.clip();
    ctx.globalCompositeOperation = 'lighter';
    drawTrail(ctx, a);
    drawTrail(ctx, b);
    drawKickTrail(ctx, a);
    drawKickTrail(ctx, b);
    ctx.restore();
    this.fx.drawLight(ctx);
    this.fx.drawTexts(ctx);
    ctx.restore();

    drawVignette(ctx, v.w, v.h);
    if (this.cine > 0.01) {
      // letterbox bars
      const bar = v.h * 0.085 * this.cine;
      ctx.fillStyle = '#000';
      ctx.fillRect(-20, -20, v.w + 40, bar + 20);
      ctx.fillRect(-20, v.h - bar, v.w + 40, bar + 20);
    }
    if (this.flash > 0) {
      ctx.fillStyle = `rgba(255,244,214,${(this.flash * 0.6).toFixed(3)})`;
      ctx.fillRect(-20, -20, v.w + 40, v.h + 40);
    }
    ctx.restore();
  }
}
