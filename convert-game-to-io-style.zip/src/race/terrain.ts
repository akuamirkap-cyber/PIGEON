// @ts-nocheck
// The world, built the way the fighter-jet game builds it:
//   · islands are a height per ground column, drawn as stacked layers (4 m each) with a material per column
//   · the sea is flat, banded by depth, with foam and twinkling sparkles
//   · clouds and trees are small stacks of boxes
//   · the sky is a stepped gradient with a hard-edged sun
// Everything is flat-coloured and meant to be drawn at low resolution with hard pixels.
import * as THREE from 'three'
import { makeSky } from './sky'

export const SKY = {
  day: { a: '#c6e8fa', m: '#7abef0', b: '#3e8ede', haze: '#cfe8f8', sun: '#fff6de', sunGlow: '#ffe9a8', sunDir: [0.5, 0.32], stars: 0 },
  sunset: { a: '#ffc684', m: '#ee7a82', b: '#544496', haze: '#f8b884', sun: '#ffaa5c', sunGlow: '#ff8a5a', sunDir: [0.95, 0.5], stars: 0.15 },
  night: { a: '#24386e', m: '#121c46', b: '#070a22', haze: '#26407f', sun: '#c8e0ff', sunGlow: '#5a76c0', sunDir: [0.3, 0.42], stars: 1 },
}

// materials: 0 sand · 1 sand speck · 2 grass · 3 grass dark · 4 grass light · 5 rock · 6 rock dark · 7 rock light · 8 snow · 9 snow shade
const MAT_TOP = [
  [238, 220, 164], [222, 200, 140], [96, 178, 52], [70, 148, 44], [134, 206, 76],
  [146, 140, 134], [118, 112, 110], [178, 172, 162], [246, 250, 255], [214, 226, 244],
]
const MAT_SIDE = [
  [204, 180, 122], [204, 180, 122], [56, 120, 44], [50, 108, 42], [60, 128, 46],
  [96, 90, 92], [86, 82, 86], [104, 98, 98], [186, 202, 228], [176, 192, 220],
]
const SEA = { deep: [36, 104, 180], mid: [44, 124, 198], shallow: [66, 160, 216], surf: [104, 204, 214], foam: [240, 252, 255] }

const Q = 4 // metres per stacked layer

function mulberry32(a) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))

/** the original's time-of-day grading, roughly */
export function grade(c, tod) {
  if (tod === 'sunset') return [Math.min(255, c[0] * 1.02 + 22), c[1] * 0.86 + 8, c[2] * 0.72]
  if (tod === 'night') return [c[0] * 0.3 + 6, c[1] * 0.38 + 10, c[2] * 0.62 + 30]
  return c
}
const tmpC = new THREE.Color()
const lin = (c) => {
  tmpC.setRGB(clamp(c[0], 0, 255) / 255, clamp(c[1], 0, 255) / 255, clamp(c[2], 0, 255) / 255, THREE.SRGBColorSpace)
  return [tmpC.r, tmpC.g, tmpC.b]
}
export const linCol = (c) => new THREE.Color().setRGB(clamp(c[0], 0, 255) / 255, clamp(c[1], 0, 255) / 255, clamp(c[2], 0, 255) / 255, THREE.SRGBColorSpace)

function noiseField(n, scaleCols, rnd, amp, out) {
  const P = Math.ceil(n / scaleCols) + 2
  const lat = new Float32Array(P * P)
  for (let i = 0; i < lat.length; i++) lat[i] = rnd()
  for (let j = 0; j < n; j++) {
    const fy = j / scaleCols
    const y0 = Math.floor(fy)
    let ty = fy - y0
    ty = ty * ty * (3 - 2 * ty)
    for (let i = 0; i < n; i++) {
      const fx = i / scaleCols
      const x0 = Math.floor(fx)
      let tx = fx - x0
      tx = tx * tx * (3 - 2 * tx)
      const a = lat[y0 * P + x0] + (lat[y0 * P + x0 + 1] - lat[y0 * P + x0]) * tx
      const b = lat[(y0 + 1) * P + x0] + (lat[(y0 + 1) * P + x0 + 1] - lat[(y0 + 1) * P + x0]) * tx
      out[j * n + i] += amp * (a + (b - a) * ty)
    }
  }
}

function boxBlur(src, n, r) {
  const tmp = new Float32Array(n * n)
  const out = new Float32Array(n * n)
  for (let j = 0; j < n; j++) {
    let s = 0
    for (let i = -r; i <= r; i++) s += src[j * n + clamp(i, 0, n - 1)]
    for (let i = 0; i < n; i++) {
      tmp[j * n + i] = s / (2 * r + 1)
      s += src[j * n + clamp(i + r + 1, 0, n - 1)] - src[j * n + clamp(i - r, 0, n - 1)]
    }
  }
  for (let i = 0; i < n; i++) {
    let s = 0
    for (let j = -r; j <= r; j++) s += tmp[clamp(j, 0, n - 1) * n + i]
    for (let j = 0; j < n; j++) {
      out[j * n + i] = s / (2 * r + 1)
      s += tmp[clamp(j + r + 1, 0, n - 1) * n + i] - tmp[clamp(j - r, 0, n - 1) * n + i]
    }
  }
  return out
}

export function buildTerrain(track, theme, opts) {
  const tod = theme
  const sky = SKY[tod] || SKY.day
  const rnd = mulberry32(Math.round(opts.worldSeed) * 9301 + 49297)
  const group = new THREE.Group()

  // ── area
  let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9
  for (let i = 0; i < track.N; i++) {
    x0 = Math.min(x0, track.px[i]); x1 = Math.max(x1, track.px[i])
    z0 = Math.min(z0, track.pz[i]); z1 = Math.max(z1, track.pz[i])
  }
  const margin = 1200
  const size = Math.max(x1 - x0, z1 - z0) + margin * 2
  const cx = (x0 + x1) / 2
  const cz = (z0 + z1) / 2
  const C = Math.max(12, size / 400)
  const n = Math.ceil(size / C)
  const ox = cx - size / 2
  const oz = cz - size / 2
  const S = track.minY - 130 // sea level

  // ── height field (value-noise octaves, like the original)
  const E = new Float32Array(n * n)
  const octs = [[1500, 1], [760, 0.55], [380, 0.3], [190, 0.16], [95, 0.08]]
  for (const [m, a] of octs) noiseField(n, Math.max(2, m / C), rnd, a, E)
  let mn = 1e9, mx = -1e9
  for (let i = 0; i < E.length; i++) { mn = Math.min(mn, E[i]); mx = Math.max(mx, E[i]) }
  for (let i = 0; i < E.length; i++) E[i] = (E[i] - mn) / (mx - mn || 1)
  // sea round the edges
  const fade = n * 0.1
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const e = Math.min(i, j, n - 1 - i, n - 1 - j) / fade
      if (e < 1) E[j * n + i] -= (1 - e * e * (3 - 2 * e)) * 0.7
    }
  }
  // threshold so that `islands` of the ground is land
  const hist = new Uint32Array(256)
  for (let i = 0; i < E.length; i++) hist[clamp(Math.floor(E[i] * 255), 0, 255)]++
  let acc = 0
  let thr = 1
  const want = (1 - clamp(opts.islands, 0.05, 0.8)) * E.length
  for (let b = 0; b < 256; b++) {
    acc += hist[b]
    if (acc >= want) { thr = (b + 1) / 255; break }
  }
  const T2 = new Float32Array(n * n) // patches: trees and grass shades
  noiseField(n, Math.max(2, 70 / C), rnd, 1, T2)
  noiseField(n, Math.max(2, 28 / C), rnd, 0.5, T2)

  // distance from the road (for keeping peaks clear of it)
  const CELL = 150
  const hash = new Map()
  for (let i = 0; i < track.N; i += 2) {
    const k = Math.floor(track.px[i] / CELL) + ',' + Math.floor(track.pz[i] / CELL)
    if (!hash.has(k)) hash.set(k, [])
    hash.get(k).push(i)
  }
  const nearest = (x, z) => {
    const cxx = Math.floor(x / CELL)
    const czz = Math.floor(z / CELL)
    let best = 1e9
    let bi = -1
    for (let a = -2; a <= 2; a++) {
      for (let b = -2; b <= 2; b++) {
        const arr = hash.get(cxx + a + ',' + (czz + b))
        if (!arr) continue
        for (const i of arr) {
          const d = Math.hypot(track.px[i] - x, track.pz[i] - z)
          if (d < best) { best = d; bi = i }
        }
      }
    }
    return [best, bi]
  }

  const level = new Uint8Array(n * n)
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const e = E[j * n + i]
      if (e <= thr) continue
      const hl = (e - thr) / (1 - thr)
      let H = 3 + Math.pow(hl, 0.8) * 86
      const x = ox + (i + 0.5) * C
      const z = oz + (j + 0.5) * C
      const [d, bi] = nearest(x, z)
      const far = clamp((d - 320) / 700, 0, 1)
      H *= 1 + far * 1.5
      if (bi >= 0) {
        const cap = track.py[bi] - 14 - S
        const nearK = clamp((d - 45) / 260, 0, 1)
        H = Math.min(H, cap + nearK * 500)
      }
      level[j * n + i] = clamp(Math.round(H / Q), 1, 60)
    }
  }
  const lv = (i, j) => (i < 0 || j < 0 || i >= n || j >= n ? 0 : level[j * n + i])

  // ── materials
  const mat = new Uint8Array(n * n)
  const tree = new Uint8Array(n * n)
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const L = level[j * n + i]
      if (!L) continue
      const m = L * Q
      const coast = lv(i - 1, j) === 0 || lv(i + 1, j) === 0 || lv(i, j - 1) === 0 || lv(i, j + 1) === 0
      const h = (i * 7 + j * 13 + ((i * j) % 5)) & 7
      const p = T2[j * n + i]
      let mm
      if (m <= 6 || (coast && m <= 12)) mm = h === 0 ? 1 : 0
      else if (m <= 44) {
        mm = h === 0 ? 4 : h < 3 ? 3 : 2
        if (p > 0.95 && m > 10 && m < 40) tree[j * n + i] = 1
      } else if (m <= 72) mm = h === 0 ? 7 : h < 3 ? 6 : 5
      else mm = h < 2 ? 9 : 8
      mat[j * n + i] = mm
    }
  }

  // ── mesh, in chunks
  const sunH = Math.hypot(sky.sunDir[0], sky.sunDir[1]) || 1
  const sx = -sky.sunDir[0] / sunH
  const sz = -sky.sunDir[1] / sunH
  const light = (nx, nz) => {
    const d = nx * sx + nz * sz
    return d > 0.25 ? 1 : d < -0.25 ? 0.62 : 0.8
  }
  const topCol = MAT_TOP.map((c) => lin(grade(c, tod)))
  const sideCol = MAT_SIDE.map((c) => lin(grade(c, tod)))
  const CH = 32
  const chunks = new Map()
  const chunkOf = (i, j) => {
    const k = Math.floor(i / CH) + ',' + Math.floor(j / CH)
    let c = chunks.get(k)
    if (!c) { c = { pos: [], col: [], idx: [] }; chunks.set(k, c) }
    return c
  }
  const quad = (c, a, b, d, e, col) => {
    const v = c.pos.length / 3
    c.pos.push(...a, ...b, ...d, ...e)
    for (let k = 0; k < 4; k++) c.col.push(col[0], col[1], col[2])
    c.idx.push(v, v + 1, v + 2, v, v + 2, v + 3)
  }
  const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]]
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const L = level[j * n + i]
      if (!L) continue
      const mm = mat[j * n + i]
      const c = chunkOf(i, j)
      const xa = ox + i * C, xb = xa + C, za = oz + j * C, zb = za + C
      const yt = S + L * Q
      quad(c, [xa, yt, za], [xa, yt, zb], [xb, yt, zb], [xb, yt, za], topCol[mm])
      for (const [dx, dz] of DIRS) {
        const Ln = lv(i + dx, j + dz)
        if (Ln >= L) continue
        const lo = Math.max(Ln, L - 14)
        const sc = sideCol[mm]
        const lt = light(dx, dz)
        for (let k = lo + 1; k <= L; k++) {
          const f = lt * (k % 2 ? 1 : 0.9)
          const col = [sc[0] * f, sc[1] * f, sc[2] * f]
          const ya = S + (k - 1) * Q
          const yb = S + k * Q
          if (dx === 1) quad(c, [xb, ya, za], [xb, yb, za], [xb, yb, zb], [xb, ya, zb], col)
          else if (dx === -1) quad(c, [xa, ya, za], [xa, ya, zb], [xa, yb, zb], [xa, yb, za], col)
          else if (dz === 1) quad(c, [xa, ya, zb], [xb, ya, zb], [xb, yb, zb], [xa, yb, zb], col)
          else quad(c, [xa, ya, za], [xa, yb, za], [xb, yb, za], [xb, ya, za], col)
        }
      }
    }
  }
  const landMat = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide })
  for (const c of chunks.values()) {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(c.pos, 3))
    g.setAttribute('color', new THREE.Float32BufferAttribute(c.col, 3))
    g.setIndex(c.idx)
    g.computeBoundingSphere()
    group.add(new THREE.Mesh(g, landMat))
  }

  // ── trees: three stacked boxes each
  {
    const spots = []
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      if (!tree[j * n + i]) continue
      const x = ox + (i + 0.5) * C
      const z = oz + (j + 0.5) * C
      spots.push([x, S + level[j * n + i] * Q, z, i, j])
    }
    const cap = 4200
    const step = Math.max(1, Math.ceil(spots.length / cap))
    const list = spots.filter((_, k) => k % step === 0)
    const boxG = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0)
    const tiers = [
      { w: 5.4, h: 4.2, y: 0, c: [28, 92, 46] },
      { w: 4.0, h: 3.6, y: 3.6, c: [42, 122, 54] },
      { w: 2.4, h: 3.0, y: 6.8, c: [70, 158, 64] },
    ]
    const m4 = new THREE.Matrix4()
    const q = new THREE.Quaternion()
    for (const t of tiers) {
      const mesh = new THREE.InstancedMesh(boxG, new THREE.MeshBasicMaterial(), list.length)
      const col = linCol(grade(t.c, tod))
      list.forEach((s, k) => {
        const jit = 0.8 + ((s[3] * 31 + s[4] * 17) % 7) / 18
        m4.compose(new THREE.Vector3(s[0] + ((s[3] * 13) % 5) - 2, s[1] + t.y * jit, s[2] + ((s[4] * 11) % 5) - 2), q.identity(), new THREE.Vector3(t.w * jit, t.h * jit, t.w * jit))
        mesh.setMatrixAt(k, m4)
        mesh.setColorAt(k, col)
      })
      mesh.frustumCulled = false
      group.add(mesh)
    }
  }

  // ── sea
  const seaTex = (() => {
    const mask = new Float32Array(n * n)
    for (let i = 0; i < mask.length; i++) mask[i] = level[i] ? 1 : 0
    const narrow = boxBlur(mask, n, Math.max(1, Math.round(110 / C)))
    const wide = boxBlur(boxBlur(mask, n, Math.max(2, Math.round(260 / C))), n, Math.max(2, Math.round(180 / C)))
    const data = new Uint8Array(n * n * 4)
    for (let i = 0; i < mask.length; i++) {
      data[i * 4] = clamp(narrow[i] * 255 * 1.3, 0, 255)
      data[i * 4 + 1] = clamp(wide[i] * 255 * 2.2, 0, 255)
      data[i * 4 + 3] = 255
    }
    const t = new THREE.DataTexture(data, n, n, THREE.RGBAFormat)
    t.magFilter = THREE.LinearFilter
    t.minFilter = THREE.LinearFilter
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping
    t.needsUpdate = true
    return t
  })()
  const hazeC = linCol(hexToRgb(sky.haze))
  const seaU = {
    tex: { value: seaTex },
    org: { value: new THREE.Vector2(ox, oz) },
    size: { value: size },
    time: { value: 0 },
    deep: { value: linCol(grade(SEA.deep, tod)) },
    mid: { value: linCol(grade(SEA.mid, tod)) },
    shal: { value: linCol(grade(SEA.shallow, tod)) },
    surf: { value: linCol(grade(SEA.surf, tod)) },
    foam: { value: linCol(grade(SEA.foam, tod)) },
    fogC: { value: hazeC },
    fogD: { value: opts.fogDensity },
    soft: { value: opts.soft ? 1 : 0 },
  }
  const sea = new THREE.Mesh(
    new THREE.PlaneGeometry(26000, 26000).rotateX(-Math.PI / 2),
    new THREE.ShaderMaterial({
      uniforms: seaU,
      vertexShader: 'varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW = w.xyz; gl_Position = projectionMatrix*viewMatrix*w; }',
      fragmentShader: `
        varying vec3 vW;
        uniform sampler2D tex; uniform vec2 org; uniform float size, time, fogD, soft;
        uniform vec3 deep, mid, shal, surf, foam, fogC;
        float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        void main(){
          vec2 uv = (vW.xz - org) / size;
          float inside = step(0.0, uv.x) * step(uv.x, 1.0) * step(0.0, uv.y) * step(uv.y, 1.0);
          vec2 d = texture2D(tex, uv).rg * inside;
          vec3 col = deep;
          float wv = sin((vW.x + vW.z) * 0.07 + time * 1.7 + d.r * 16.0);
          vec2 q = vec2(vW.x * 0.09 + time * 0.6, vW.z * 0.12);
          vec2 sp = floor(vW.xz / 6.0);
          float tw = h21(sp + floor(time * 1.6));
          if (soft > 0.5) {
            col = mix(col, mid, smoothstep(0.06, 0.15, d.g));
            col = mix(col, shal, smoothstep(0.22, 0.34, d.g));
            col = mix(col, surf, smoothstep(0.28, 0.40, d.r));
            float foamBand = smoothstep(0.50, 0.56, d.r) * (1.0 - smoothstep(0.60 + 0.07 * wv, 0.67 + 0.07 * wv, d.r));
            col = mix(col, foam, foamBand);
            float dash = smoothstep(0.88, 0.95, h21(floor(q))) * smoothstep(0.35, 0.55, fract(q.x * 2.0));
            col = mix(col, foam, dash * 0.3);
            float spk = (1.0 - smoothstep(0.0, 0.3, length(fract(vW.xz / 6.0) - 0.5))) * step(0.972, h21(sp)) * step(0.5, tw);
            col = mix(col, foam, spk);
          } else {
            if (d.g > 0.10) col = mid;
            if (d.g > 0.30) col = shal;
            if (d.r > 0.34) col = surf;
            if (d.r > 0.56 && d.r < 0.64 + 0.07 * wv) col = foam;
            float dash = step(0.9, h21(floor(q))) * step(0.45, fract(q.x * 2.0));
            col = mix(col, foam, dash * 0.35);
            if (h21(sp) > 0.972 && tw > 0.5) col = foam;
          }
          float dist = length(vW - cameraPosition);
          float f = 1.0 - exp(-fogD * fogD * dist * dist);
          col = mix(col, fogC, clamp(f, 0.0, 1.0));
          gl_FragColor = vec4(col, 1.0);
          gl_FragColor = linearToOutputTexel(gl_FragColor);
        }`,
    }),
  )
  sea.position.y = S
  sea.frustumCulled = false
  group.add(sea)

  // ── clouds: little stacks of boxes
  const cloudGroup = new THREE.Group()
  {
    const count = Math.floor(430 * clamp(opts.clouds, 0, 1))
    const layers = [
      { s: 1.0, y: 0, c: [160, 184, 224] },
      { s: 0.92, y: 5.5, c: [176, 198, 232] },
      { s: 0.78, y: 11, c: [200, 218, 244] },
      { s: 0.58, y: 16.5, c: [232, 240, 252] },
      { s: 0.34, y: 22, c: [255, 255, 255] },
    ]
    const boxG = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0)
    const mesh = new THREE.InstancedMesh(boxG, new THREE.MeshBasicMaterial(), Math.max(1, count * layers.length))
    const m4 = new THREE.Matrix4()
    const q = new THREE.Quaternion()
    const half = size * 0.75
    const cl = []
    for (let k = 0; k < 28; k++) cl.push([cx + (rnd() - 0.5) * 2 * half, cz + (rnd() - 0.5) * 2 * half])
    let idx = 0
    for (let k = 0; k < count; k++) {
      const c = cl[Math.floor(rnd() * cl.length)]
      const px = c[0] + (rnd() - 0.5) * 900
      const pz = c[1] + (rnd() - 0.5) * 900
      const high = rnd() < 0.55
      const y = high ? track.maxY + 45 + rnd() * 90 : S + 45 + rnd() * Math.max(10, track.minY - S - 100)
      const w = 50 + rnd() * 110
      const d = w * (0.55 + rnd() * 0.35)
      layers.forEach((L, li) => {
        m4.compose(new THREE.Vector3(px, y + L.y * (w / 110 + 0.4), pz), q.identity(), new THREE.Vector3(w * L.s * (0.9 + rnd() * 0.2), 5.5 * (w / 110 + 0.4), d * L.s))
        mesh.setMatrixAt(idx, m4)
        mesh.setColorAt(idx, linCol(grade(L.c, tod)))
        idx++
      })
    }
    mesh.count = idx
    mesh.frustumCulled = false
    cloudGroup.add(mesh)
    group.add(cloudGroup)
  }

  // ── sky
  const skyObj = makeSky({ tod, soft: opts.soft, sunDir: new THREE.Vector3(-sky.sunDir[0], 0.2 + sky.sunDir[1] * 0.1, -1).normalize() })
  const skyMesh = skyObj.mesh
  group.add(skyMesh)

  const gAt = (x, z) => {
    const i = Math.floor((x - ox) / C)
    const j = Math.floor((z - oz) / C)
    return S + lv(i, j) * Q
  }

  return {
    group,
    seaY: S,
    groundAt: gAt,
    update(dt, camPos) {
      seaU.time.value += dt
      skyObj.update(seaU.time.value, camPos)
      sea.position.x = Math.round(camPos.x / 6) * 6
      sea.position.z = Math.round(camPos.z / 6) * 6
      cloudGroup.position.x += dt * 2.4
    },
    dispose() {
      group.traverse((o) => {
        if (o.geometry) o.geometry.dispose()
        if (o.material) o.material.dispose?.()
      })
      seaTex.dispose()
    },
  }
}

export function hexToRgb(h) {
  const v = parseInt(h.slice(1), 16)
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255]
}
