export type VehicleStats = {
  speed: number
  acceleration: number
  steering: number
  grip: number
  damage: number
  turboDrain: number
}

const STANDARD: VehicleStats = {
  speed: 1,
  acceleration: 1,
  steering: 1,
  grip: 1,
  damage: 1,
  turboDrain: 1,
}

export const SKINS = [
  { id: 'scout', name: 'Scout Speeder', desc: 'Speeder putih, pilot berarmor', group: 'bike' },
  { id: 'sport', name: 'Sport Speeder', desc: 'Speeder merah, jok tinggi', group: 'bike' },
  { id: 'swoop', name: 'Swoop Bike', desc: 'Modifikasi liar, paling cepat', group: 'bike' },
  { id: 'racer', name: 'Racer', desc: 'Anti-gravity cerah', group: 'craft' },
  { id: 'jet', name: 'Jet', desc: 'Jet voxel klasik', group: 'craft' },
  { id: 'pod', name: 'Podracer', desc: 'Dua mesin raksasa', group: 'craft' },
  { id: 'fighter', name: 'Fighter', desc: 'Starfighter sayap-X', group: 'craft' },
] as const

export type VehicleId = (typeof SKINS)[number]['id']
export type BotSkins = 'mixed' | 'same'

export const SKIN_IDS: VehicleId[] = SKINS.map((skin) => skin.id)

const PROFILES: Record<VehicleId, VehicleStats> = {
  racer: STANDARD,
  jet: STANDARD,
  pod: STANDARD,
  fighter: STANDARD,
  scout: { ...STANDARD, steering: 1.06 },
  sport: { ...STANDARD, speed: 1.04, acceleration: 1.06, steering: 1.04 },
  swoop: { speed: 1.18, acceleration: 1.2, steering: 1.06, grip: 0.78, damage: 1.25, turboDrain: 1.12 },
}

export function getVehicleId(value: unknown): VehicleId {
  return SKIN_IDS.find((id) => id === value) ?? 'racer'
}

export function getVehicleStats(value: unknown): VehicleStats {
  return PROFILES[getVehicleId(value)]
}

export function vehicleForRacer(selected: unknown, botSkins: unknown, id: number): VehicleId {
  const playerVehicle = getVehicleId(selected)
  return id === 0 || botSkins === 'same' ? playerVehicle : SKIN_IDS[id % SKIN_IDS.length]
}

export function isBike(value: unknown): boolean {
  return value === 'scout' || value === 'sport' || value === 'swoop'
}