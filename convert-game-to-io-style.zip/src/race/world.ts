// @ts-nocheck
// The 3D world: road ribbon, neon barriers, pads, pylons, gantries, a city, sky and grid floor.
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { newFrame, type Track } from './track'
import { buildTerrain } from './terrain'

export const THEMES = {
  night: {
    fog: '#26407f', fogDensity: 0.00046, wallL: '#58e4ff', wallR: '#ff5aa8', road: '#12162a', bloom: 0.8, exposure: 1.0,
    ambient: 0.6, dir: 0.8, dirColor: '#9fb8ff', skyMid: '#121c46', gridB: '#ff5aa8',
  },
  sunset: {
    fog: '#f8b884', fogDensity: 0.0004, wallL: '#3fd8ff', wallR: '#ff9a3a', road: '#2e2a3c', bloom: 0.6, exposure: 1.0,
    ambient: 0.7, dir: 1.1, dirColor: '#ffc27a', skyMid: '#ee7a82', gridB: '#ff3b8d',
  },
  day: {
    fog: '#cfe8f8', fogDensity: 0.00034, wallL: '#2fb8ff', wallR: '#ff5a3a', road: '#2a3042', bloom: 0.4, exposure: 1.0,
    ambient: 0.9, dir: 1.4, dirColor: '#ffffff', skyMid: '#7abef0', gridB: '#7a8cff',
  },
}

function mulberry32(a) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

let SMOOTH = false
function canvasTex(w, h, draw, repeat = true) {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  draw(c.getContext('2d'), w, h)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping
  if (SMOOTH) {
    t.magFilter = THREE.LinearFilter
    t.minFilter = THREE.LinearMipmapLinearFilter
    t.generateMipmaps = true
    t.anisotropy = 8
  } else {
    t.magFilter = THREE.NearestFilter
    t.minFilter = THREE.NearestFilter
    t.generateMipmaps = false
  }
  return t
}

/** sweep a cross-section along the whole road. section: [{x, y, u, c?: [r,g,b]}] */
function sweep(track, section, vTile, colorFn) {
  const N = track.N
  const cols = section.length
  const rows = N + 1
  const pos = new Float32Array(rows * cols * 3)
  const uv = new Float32Array(rows * cols * 2)
  const col = colorFn ? new Float32Array(rows * cols * 3) : null
  for (let i = 0; i < rows; i++) {
    const k = i % N
    for (let j = 0; j < cols; j++) {
      const o = i * cols + j
      const sx = section[j].x
      const sy = section[j].y
      pos[o * 3] = track.px[k] + track.rx[k] * sx + track.ux[k] * sy
      pos[o * 3 + 1] = track.py[k] + track.ry[k] * sx + track.uy[k] * sy
      pos[o * 3 + 2] = track.pz[k] + track.rz[k] * sx + track.uz[k] * sy
      uv[o * 2] = section[j].u
      uv[o * 2 + 1] = ((i * track.ds) / track.L) * vTile
      if (col) {
        const c = colorFn(i, j)
        col[o * 3] = c[0]
        col[o * 3 + 1] = c[1]
        col[o * 3 + 2] = c[2]
      }
    }
  }
  const idx = []
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < cols - 1; j++) {
      const a = i * cols + j
      const b = a + 1
      const c = (i + 1) * cols + j
      const d = c + 1
      idx.push(a, c, b, b, c, d)
    }
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
  if (col) g.setAttribute('color', new THREE.BufferAttribute(col, 3))
  g.setIndex(idx)
  g.computeVertexNormals()
  return g
}

/** a flat strip over a stretch of road (pads, start line) */
function stretch(track, s0, s1, x0, x1, y, steps, vRepeat) {
  const f = newFrame()
  const pos = []
  const uv = []
  const idx = []
  for (let i = 0; i <= steps; i++) {
    const s = s0 + ((s1 - s0) * i) / steps
    track.frame(s, f)
    for (const [x, u] of [[x0, 0], [x1, 1]]) {
      pos.push(f.px + f.rx * x + f.ux * y, f.py + f.ry * x + f.uy * y, f.pz + f.rz * x + f.uz * y)
      uv.push(u, (i / steps) * vRepeat)
    }
    if (i > 0) {
      const a = (i - 1) * 2
      idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3)
    }
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2))
  g.setIndex(idx)
  return g
}

export function buildWorld(track: Track, themeName: string, wopts: any) {
  SMOOTH = !!wopts.soft
  const th = THEMES[themeName] || THEMES.night
  const group = new THREE.Group()
  const disposables = []
  const rnd = mulberry32(Math.round(track.opts.seed) * 131 + 7)
  const terrain = buildTerrain(track, themeName in THEMES ? themeName : 'day', { islands: wopts.islands, worldSeed: wopts.worldSeed, clouds: wopts.clouds, fogDensity: th.fogDensity, soft: !!wopts.soft })
  group.add(terrain.group)
  const groundY = terrain.seaY
  const hw = track.halfW
  const cWallL = new THREE.Color(th.wallL)
  const cWallR = new THREE.Color(th.wallR)
  const dark = new THREE.Color('#10121f')
  const anim = { pads: [], rings: [], uniforms: [] }

  // ── road surface
  const roadTex = canvasTex(256, 512, (g, w, h) => {
    g.fillStyle = th.road
    g.fillRect(0, 0, w, h)
    // faint panel noise
    for (let i = 0; i < 700; i++) {
      g.fillStyle = `rgba(255,255,255,${Math.random() * 0.025})`
      g.fillRect(Math.random() * w, Math.random() * h, Math.random() * 30, 1 + Math.random() * 2)
    }
    // edge lines
    const edge = (x, c) => {
      g.fillStyle = c
      g.fillRect(x, 0, 5, h)
      g.globalAlpha = 0.25
      g.fillRect(x - 5, 0, 15, h)
      g.globalAlpha = 1
    }
    edge(w * 0.045, th.wallL)
    edge(w * 0.955 - 5, th.wallR)
    // lane dashes
    g.fillStyle = 'rgba(200,220,255,0.38)'
    for (const lx of [0.25, 0.5, 0.75]) for (let k = 0; k < 4; k++) g.fillRect(w * lx - 2, k * (h / 4) + 12, 4, h / 8)
    // cross seams
    g.fillStyle = 'rgba(255,255,255,0.07)'
    g.fillRect(0, 0, w, 3)
    g.fillRect(0, h / 2, w, 2)
    // chevrons
    g.strokeStyle = 'rgba(120,200,255,0.10)'
    g.lineWidth = 3
    for (let k = 0; k < 2; k++) {
      g.beginPath()
      g.moveTo(w * 0.35, h * (0.25 + k * 0.5) + 20)
      g.lineTo(w * 0.5, h * (0.25 + k * 0.5))
      g.lineTo(w * 0.65, h * (0.25 + k * 0.5) + 20)
      g.stroke()
    }
  })
  const vTile = Math.max(2, Math.round(track.L / 40))
  const roadGeo = sweep(track, [{ x: -hw, y: 0, u: 0 }, { x: hw, y: 0, u: 1 }], vTile)
  const road = new THREE.Mesh(roadGeo, new THREE.MeshBasicMaterial({ map: roadTex, side: THREE.DoubleSide }))
  group.add(road)

  // ── belly (road thickness)
  const bellyGeo = sweep(track, [
    { x: -hw, y: 0, u: 0 }, { x: -hw * 0.94, y: -1.2, u: 0 }, { x: -hw * 0.6, y: -3.4, u: 0 },
    { x: hw * 0.6, y: -3.4, u: 0 }, { x: hw * 0.94, y: -1.2, u: 0 }, { x: hw, y: 0, u: 0 },
  ], 1)
  group.add(new THREE.Mesh(bellyGeo, new THREE.MeshBasicMaterial({ color: '#0b0d18', side: THREE.DoubleSide })))
  // glowing keel lights
  const keel = sweep(track, [{ x: -hw * 0.935, y: -1.25, u: 0 }, { x: -hw * 0.9, y: -1.9, u: 0 }], 1, (i) => (Math.floor(i / 2) % 2 ? [cWallL.r, cWallL.g, cWallL.b] : [0, 0, 0]))
  const keelR = sweep(track, [{ x: hw * 0.9, y: -1.9, u: 0 }, { x: hw * 0.935, y: -1.25, u: 0 }], 1, (i) => (Math.floor(i / 2) % 2 ? [cWallR.r, cWallR.g, cWallR.b] : [0, 0, 0]))
  for (const g of [keel, keelR]) group.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })))

  // ── barriers: a dark wall with a glowing cap, neon stripes along it
  const wallColor = (side) => (i, j) => {
    const c = side < 0 ? cWallL : cWallR
    const on = Math.floor(i / 4) % 2 === 0
    if (j === 0) return on ? [c.r * 0.55, c.g * 0.55, c.b * 0.55] : [dark.r, dark.g, dark.b]
    return on ? [c.r, c.g, c.b] : [c.r * 0.25, c.g * 0.25, c.b * 0.25]
  }
  for (const side of [-1, 1]) {
    const x = side * hw
    const wall = sweep(track, [{ x, y: 0, u: 0 }, { x, y: 1.35, u: 0 }], 1, wallColor(side))
    group.add(new THREE.Mesh(wall, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide })))
    const cap = sweep(track, [{ x: x - side * 0.25, y: 1.35, u: 0 }, { x: x + side * 0.1, y: 1.6, u: 0 }, { x: x + side * 0.1, y: 1.35, u: 0 }], 1, () => {
      const c = side < 0 ? cWallL : cWallR
      return [c.r * 1.1, c.g * 1.1, c.b * 1.1]
    })
    group.add(new THREE.Mesh(cap, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide })))
    // soft translucent field above the wall
    const field = sweep(track, [{ x, y: 1.6, u: 0 }, { x, y: 4.2, u: 0 }], 1, (i, j) => {
      const c = side < 0 ? cWallL : cWallR
      const a = j === 0 ? 0.45 : 0
      return [c.r * a, c.g * a, c.b * a]
    })
    group.add(new THREE.Mesh(field, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })))
    // outside skirt
    const skirt = sweep(track, [{ x, y: 0, u: 0 }, { x: x + side * 0.8, y: -2.4, u: 0 }], 1)
    group.add(new THREE.Mesh(skirt, new THREE.MeshBasicMaterial({ color: '#0d0f1c', side: THREE.DoubleSide })))
  }

  // ── boost pads
  const padTex = canvasTex(128, 256, (g, w, h) => {
    g.fillStyle = 'rgba(0,0,0,0)'
    g.clearRect(0, 0, w, h)
    const grd = g.createLinearGradient(0, 0, 0, h)
    grd.addColorStop(0, '#ff7a00')
    grd.addColorStop(1, '#ffe14d')
    g.fillStyle = grd
    for (let k = 0; k < 3; k++) {
      const y = k * (h / 3)
      g.beginPath()
      g.moveTo(w * 0.1, y + h / 3)
      g.lineTo(w * 0.5, y + h * 0.05)
      g.lineTo(w * 0.9, y + h / 3)
      g.lineTo(w * 0.9, y + h / 3 - 26)
      g.lineTo(w * 0.5, y + h * 0.05 + 22)
      g.lineTo(w * 0.1, y + h / 3 - 26)
      g.closePath()
      g.fill()
    }
    g.strokeStyle = '#ffd23c'
    g.lineWidth = 6
    g.strokeRect(3, 3, w - 6, h - 6)
  })
  for (const pad of track.pads) {
    const geo = stretch(track, pad.s - pad.len / 2, pad.s + pad.len / 2, pad.x - pad.w / 2, pad.x + pad.w / 2, 0.08, 10, 3)
    const tex = padTex.clone()
    tex.needsUpdate = true
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }))
    group.add(m)
    anim.pads.push(tex)
    // a glowing frame of light above the pad
    const f = newFrame()
    track.frame(pad.s, f)
  }

  // ── repair strip
  const rep = track.repair
  const repTex = canvasTex(64, 128, (g, w, h) => {
    g.fillStyle = 'rgba(30,255,140,0.18)'
    g.fillRect(0, 0, w, h)
    g.fillStyle = 'rgba(60,255,160,0.85)'
    for (let k = 0; k < 4; k++) g.fillRect(0, k * (h / 4) + 6, w, 8)
  })
  const repGeo = stretch(track, rep.s0, rep.s1, rep.side < 0 ? -hw + 1 : hw - 10, rep.side < 0 ? -hw + 10 : hw - 1, 0.07, 20, (rep.s1 - rep.s0) / 16)
  group.add(new THREE.Mesh(repGeo, new THREE.MeshBasicMaterial({ map: repTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })))

  // ── start line
  const checker = canvasTex(256, 64, (g, w, h) => {
    const n = 16
    for (let x = 0; x < n; x++) for (let y = 0; y < 4; y++) {
      g.fillStyle = (x + y) % 2 ? '#fff' : '#111'
      g.fillRect((x * w) / n, (y * h) / 4, w / n + 1, h / 4 + 1)
    }
  })
  group.add(new THREE.Mesh(stretch(track, -2, 2, -hw, hw, 0.09, 1, 1), new THREE.MeshBasicMaterial({ map: checker, side: THREE.DoubleSide })))

  // ── pylons holding the road up
  const pillarCount = Math.floor(track.L / 55)
  const pillarGeo = new THREE.CylinderGeometry(1, 1.25, 1, 4, 1, true)
  pillarGeo.translate(0, 0.5, 0)
  const pillars = new THREE.InstancedMesh(pillarGeo, new THREE.MeshBasicMaterial({ color: th.road === '#12162a' ? '#1b2142' : '#3a4260', side: THREE.DoubleSide }), pillarCount)
  const m4 = new THREE.Matrix4()
  const fr = newFrame()
  const q = new THREE.Quaternion()
  const sc = new THREE.Vector3()
  const pp = new THREE.Vector3()
  for (let i = 0; i < pillarCount; i++) {
    track.frame((i + 0.5) * (track.L / pillarCount), fr)
    const top = fr.py - fr.uy * 3.4
    const bx0 = fr.px - fr.ux * 3.4
    const bz0 = fr.pz - fr.uz * 3.4
    const gy = Math.max(groundY, terrain.groundAt(bx0, bz0))
    const h = Math.max(1, top - gy)
    pp.set(bx0, gy, bz0)
    sc.set(2.2 + h * 0.006, h, 2.2 + h * 0.006)
    m4.compose(pp, q.identity(), sc)
    pillars.setMatrixAt(i, m4)
  }
  group.add(pillars)

  // ── gantries: rings of light that make speed visible
  const gantryParts = []
  const colorize = (g, c) => {
    const n = g.attributes.position.count
    const a = new Float32Array(n * 3)
    for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b }
    g.setAttribute('color', new THREE.BufferAttribute(a, 3))
    return g
  }
  const post = (x) => colorize(new THREE.BoxGeometry(0.7, 8.5, 0.7).translate(x, 4.25, 0), new THREE.Color('#1a2040'))
  gantryParts.push(post(-hw - 0.2), post(hw + 0.2))
  gantryParts.push(colorize(new THREE.BoxGeometry(hw * 2 + 1.6, 0.8, 0.8).translate(0, 8.6, 0), new THREE.Color('#1a2040')))
  gantryParts.push(colorize(new THREE.BoxGeometry(hw * 2 - 2, 0.35, 0.35).translate(0, 8.0, 0.45), new THREE.Color(1.05, 1.05, 1.05)))
  const gantryGeo = mergeGeometries(gantryParts)
  const gCount = Math.floor(track.L / 230)
  const gantries = new THREE.InstancedMesh(gantryGeo, new THREE.MeshBasicMaterial({ vertexColors: true }), gCount)
  const cols = [cWallL, cWallR, new THREE.Color('#ffd23c')]
  const tmpM = new THREE.Matrix4()
  const bx = new THREE.Vector3(), by = new THREE.Vector3(), bz = new THREE.Vector3(), bp = new THREE.Vector3()
  for (let i = 0; i < gCount; i++) {
    track.frame(120 + i * (track.L / gCount), fr)
    bx.set(fr.rx, fr.ry, fr.rz)
    by.set(fr.ux, fr.uy, fr.uz)
    bz.set(-fr.tx, -fr.ty, -fr.tz)
    bp.set(fr.px, fr.py, fr.pz)
    tmpM.makeBasis(bx, by, bz)
    tmpM.setPosition(bp)
    gantries.setMatrixAt(i, tmpM)
    gantries.setColorAt(i, cols[i % 3])
  }
  group.add(gantries)

  // ── start / finish arch with banner
  {
    const parts = []
    const p2 = (x) => colorize(new THREE.BoxGeometry(1.4, 15, 1.4).translate(x, 7.5, 0), new THREE.Color('#222a52'))
    parts.push(p2(-hw - 1.2), p2(hw + 1.2))
    parts.push(colorize(new THREE.BoxGeometry(hw * 2 + 4.5, 1.4, 1.4).translate(0, 15.2, 0), new THREE.Color('#222a52')))
    parts.push(colorize(new THREE.BoxGeometry(hw * 2 + 3, 0.4, 0.4).translate(0, 14.3, 0.8), new THREE.Color(1.1, 1.1, 1.1)))
    const arch = new THREE.Mesh(mergeGeometries(parts), new THREE.MeshBasicMaterial({ vertexColors: true }))
    track.frame(0, fr)
    bx.set(fr.rx, fr.ry, fr.rz); by.set(fr.ux, fr.uy, fr.uz); bz.set(-fr.tx, -fr.ty, -fr.tz); bp.set(fr.px, fr.py, fr.pz)
    tmpM.makeBasis(bx, by, bz)
    tmpM.setPosition(bp)
    arch.applyMatrix4(tmpM)
    arch.matrixAutoUpdate = false
    group.add(arch)
    const banner = canvasTex(1024, 128, (g, w, h) => {
      const n = 40
      for (let x = 0; x < n; x++) for (let y = 0; y < 2; y++) {
        g.fillStyle = (x + y) % 2 ? '#f4f4f4' : '#15151c'
        g.fillRect((x * w) / n, y * 14, w / n + 1, 15)
      }
      g.fillStyle = '#0a0a14'
      g.fillRect(0, 28, w, h - 28)
      const grd = g.createLinearGradient(0, 0, w, 0)
      grd.addColorStop(0, th.wallL)
      grd.addColorStop(1, th.wallR)
      g.fillStyle = grd
      g.font = 'italic 900 78px "Arial Black", Impact, sans-serif'
      g.textAlign = 'center'
      g.fillText('START  ◆  FINISH', w / 2, 108)
    }, false)
    const bm = new THREE.Mesh(new THREE.PlaneGeometry(hw * 2 + 1, 4), new THREE.MeshBasicMaterial({ map: banner, side: THREE.DoubleSide }))
    bm.position.set(0, 12.2, 0.2)
    const holder = new THREE.Group()
    holder.add(bm)
    holder.applyMatrix4(tmpM)
    holder.matrixAutoUpdate = false
    group.add(holder)
  }

  group.traverse((o) => {
    if (o.geometry) disposables.push(o.geometry)
  })

  return {
    group,
    groundY,
    groundAt: terrain.groundAt,
    theme: th,
    update(dt, camPos) {
      for (const t of anim.pads) t.offset.y -= dt * 1.4
      terrain.update(dt, camPos)
    },
    dispose() {
      group.traverse((o) => {
        if (o.geometry) o.geometry.dispose()
        if (o.material) {
          const ms = Array.isArray(o.material) ? o.material : [o.material]
          for (const m of ms) { if (m.map) m.map.dispose(); m.dispose() }
        }
      })
    },
  }
}
