// @ts-nocheck
// Instanced tropical vegetation is grouped into spatial chunks so the jungle can
// be dense without drawing the entire map around the racer on every frame.
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import canopyUrl from './assets/rainforest-canopy.webp?inline'

const clamp = (value, low, high) => Math.min(high, Math.max(low, value))
const UP = new THREE.Vector3(0, 1, 0)
const GREEN = [
  '#275837', '#326d3d', '#3a7942', '#477f42', '#28664a', '#538c49', '#607c3c', '#39704e',
]

function randomFor(seed) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function barkTexture(seed, soft) {
  const rnd = randomFor(seed)
  const canvas = document.createElement('canvas')
  canvas.width = 128
  canvas.height = 256
  const ctx = canvas.getContext('2d')
  ctx.fillStyle = '#685744'
  ctx.fillRect(0, 0, 128, 256)
  for (let i = 0; i < 270; i++) {
    const x = rnd() * 128
    const y = rnd() * 256
    const width = 0.5 + rnd() * 3
    const height = 10 + rnd() * 95
    ctx.fillStyle = i % 4 === 0 ? 'rgba(130,132,86,.35)' : i % 3 === 0 ? 'rgba(194,168,118,.16)' : 'rgba(31,36,27,.24)'
    ctx.fillRect(x, y, width, height)
  }
  for (let i = 0; i < 45; i++) {
    ctx.strokeStyle = 'rgba(34,40,27,.28)'
    ctx.lineWidth = 1 + rnd()
    const x = rnd() * 128
    const y = rnd() * 256
    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.lineTo(x + 4 + rnd() * 10, y + 2 + rnd() * 5)
    ctx.stroke()
  }
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping
  texture.magFilter = soft ? THREE.LinearFilter : THREE.NearestFilter
  texture.minFilter = soft ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter
  texture.generateMipmaps = soft
  return texture
}

function shadowTexture() {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = 64
  const ctx = canvas.getContext('2d')
  const gradient = ctx.createRadialGradient(32, 32, 1, 32, 32, 32)
  gradient.addColorStop(0, 'rgba(21,39,20,.56)')
  gradient.addColorStop(0.45, 'rgba(21,39,20,.3)')
  gradient.addColorStop(1, 'rgba(21,39,20,0)')
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, 64, 64)
  return new THREE.CanvasTexture(canvas)
}

function frondGeometry() {
  const positions = []
  const colors = []
  const indices = []
  const segments = 20
  for (let i = 0; i <= segments; i++) {
    const t = i / segments
    const width = Math.pow(Math.sin(Math.PI * t), 0.7) * 0.19 * (i % 2 ? 0.66 : 1)
    const y = 0.22 * Math.sin(Math.PI * t) - 0.3 * t * t
    for (const side of [-1, 1]) {
      positions.push(t, y, side * width)
      const light = 0.7 + 0.3 * (1 - t) + (side > 0 ? 0.05 : 0)
      colors.push(light, light, light)
    }
    if (i < segments) {
      const a = i * 2
      indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2)
    }
  }
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
  geometry.setIndex(indices)
  geometry.computeVertexNormals()
  return geometry
}

function buttressGeometry() {
  const p = [
    0, 0, -0.24, 0, 1, 0, 1, 0, -0.10,
    0, 0, 0.24, 1, 0, 0.10, 0, 1, 0,
    0, 0, -0.24, 1, 0, -0.10, 1, 0, 0.10,
    0, 0, -0.24, 1, 0, 0.10, 0, 0, 0.24,
    1, 0, -0.10, 0, 1, 0, 1, 0, 0.10,
  ]
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(p, 3))
  geometry.computeVertexNormals()
  return geometry
}

function vineGeometry() {
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(0.05, -0.25, 0.015),
    new THREE.Vector3(-0.025, -0.55, 0.035),
    new THREE.Vector3(0.04, -0.78, 0),
    new THREE.Vector3(0, -1, 0.02),
  ])
  return new THREE.TubeGeometry(curve, 10, 0.012, 4, false)
}

function bushGeometry() {
  const a = new THREE.PlaneGeometry(1, 0.67).translate(0, 0.33, 0)
  const b = a.clone().rotateY(Math.PI / 2)
  const merged = mergeGeometries([a, b])
  a.dispose()
  b.dispose()
  return merged
}

export function buildRainforest(arena, { soft = false, density = 1 } = {}) {
  const rnd = randomFor(Math.round(arena.opts.seed) * 19391 + 127)
  const { cells: n, C, ox, oz } = arena
  const amount = clamp(Number.isFinite(density) ? density : 1, 0.35, 1.4)
  const group = new THREE.Group()
  group.name = 'rainforest'
  const trees = []
  const spacing = new Map()
  const spacingCell = 16
  const treesBySpecies = { emergent: 0, broadleaf: 0, palm: 0, fig: 0 }

  const sampleEdge = (x, z) => {
    const i = clamp(Math.floor((x - ox) / C), 0, n - 1)
    const j = clamp(Math.floor((z - oz) / C), 0, n - 1)
    return arena.edge[j * n + i]
  }
  const slopeAt = (x, z) => {
    const dx = (arena.groundAt(x + C, z) - arena.groundAt(x - C, z)) / (2 * C)
    const dz = (arena.groundAt(x, z + C) - arena.groundAt(x, z - C)) / (2 * C)
    return Math.hypot(dx, dz)
  }
  const valid = (x, z, radius) => {
    if (x < ox + 20 || z < oz + 20 || x > ox + arena.size - 20 || z > oz + arena.size - 20) return false
    if (sampleEdge(x, z) < 7 || slopeAt(x, z) > 0.72) return false
    for (const gate of arena.gates) if (Math.hypot(gate.x - x, gate.z - z) < gate.r + 17) return false
    const ix = Math.floor(x / spacingCell), iz = Math.floor(z / spacingCell)
    for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) {
      const bucket = spacing.get(`${ix + a},${iz + b}`)
      if (!bucket) continue
      for (const other of bucket) {
        if (Math.hypot(x - other.x, z - other.z) < Math.max(7, (radius + other.canopy) * 0.43)) return false
      }
    }
    return true
  }
  const place = (x, z, forced) => {
    const p = rnd()
    const kind = forced || (p < 0.24 ? 'emergent' : p < 0.55 ? 'broadleaf' : p < 0.78 ? 'palm' : 'fig')
    const height = kind === 'emergent' ? 50 + rnd() * 30 : kind === 'palm' ? 28 + rnd() * 20 : kind === 'fig' ? 34 + rnd() * 23 : 30 + rnd() * 25
    const canopy = kind === 'emergent' ? 15 + rnd() * 7 : kind === 'palm' ? 11 + rnd() * 5 : 11 + rnd() * 6
    if (!valid(x, z, canopy)) return false
    const trunk = kind === 'emergent' ? 2.2 + rnd() * 1.4 : kind === 'palm' ? 0.65 + rnd() * 0.4 : 1.2 + rnd() * 0.9
    const tree = { x, z, y: arena.groundAt(x, z), height, canopy, trunk, kind, rotation: rnd() * Math.PI * 2, tint: GREEN[Math.floor(rnd() * GREEN.length)] }
    trees.push(tree)
    treesBySpecies[kind]++
    const key = `${Math.floor(x / spacingCell)},${Math.floor(z / spacingCell)}`
    if (!spacing.has(key)) spacing.set(key, [])
    spacing.get(key).push(tree)
    return true
  }

  // Deliberate tall trees beside the race route ensure the canopy frames the
  // player even when the surrounding forest was procedurally generated.
  for (const path of arena.paths.slice(0, arena.n)) {
    for (let i = 5; i < path.pts.length - 5; i += Math.max(6, Math.round(10 / amount))) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / length, rz = (b[0] - a[0]) / length
      for (const side of [-1, 1]) {
        const offset = path.halfW + 11 + rnd() * 16
        const choice = rnd()
        const kind = choice < 0.42 ? 'palm' : choice < 0.72 ? 'emergent' : 'broadleaf'
        place(q[0] + rx * offset * side, q[1] + rz * offset * side, kind)
      }
    }
  }

  const candidates = []
  for (let j = 4; j < n - 4; j++) for (let i = 4; i < n - 4; i++) {
    if (arena.edge[j * n + i] >= 7) candidates.push([i, j])
  }
  // Shuffle rather than scanning from one corner, so density stays uniform.
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1))
    ;[candidates[i], candidates[j]] = [candidates[j], candidates[i]]
  }
  const target = Math.round(clamp((arena.size * arena.size) / 1300, 1600, 5700) * amount)
  for (const [i, j] of candidates) {
    if (trees.length >= target) break
    place(ox + (i + rnd()) * C, oz + (j + rnd()) * C)
  }

  const trunk = new THREE.CylinderGeometry(0.57, 1, 1, 7, 3).translate(0, 0.5, 0)
  const palmTrunk = new THREE.CylinderGeometry(0.55, 1, 1, 7, 5).translate(0, 0.5, 0)
  const palmPositions = palmTrunk.attributes.position
  for (let i = 0; i < palmPositions.count; i++) {
    const y = palmPositions.getY(i)
    palmPositions.setX(i, palmPositions.getX(i) + y * y * 3.2)
  }
  palmTrunk.computeVertexNormals()
  const branch = new THREE.CylinderGeometry(0.45, 1, 1, 6).translate(0, 0.5, 0)
  const crown = new THREE.DodecahedronGeometry(1, 0)
  const frond = frondGeometry()
  const roots = buttressGeometry()
  const vine = vineGeometry()
  const leaves = new THREE.PlaneGeometry(1, 0.67)
  const bush = bushGeometry()
  const shadow = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2)

  const bark = barkTexture(Math.round(arena.opts.seed) * 41 + 5, soft)
  const foliage = new THREE.TextureLoader().load(canopyUrl)
  foliage.colorSpace = THREE.SRGBColorSpace
  foliage.magFilter = soft ? THREE.LinearFilter : THREE.NearestFilter
  foliage.minFilter = soft ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter
  foliage.generateMipmaps = soft
  foliage.anisotropy = soft ? 4 : 1
  const shadows = shadowTexture()
  const materials = {
    trunk: new THREE.MeshLambertMaterial({ map: bark }),
    root: new THREE.MeshLambertMaterial({ color: '#ffffff', flatShading: true }),
    crown: new THREE.MeshLambertMaterial({ color: '#ffffff', flatShading: true }),
    frond: new THREE.MeshLambertMaterial({ color: '#ffffff', vertexColors: true, side: THREE.DoubleSide }),
    leaves: new THREE.MeshLambertMaterial({ map: foliage, color: '#ffffff', side: THREE.DoubleSide, alphaTest: 0.42 }),
    vine: new THREE.MeshLambertMaterial({ color: '#ffffff' }),
    shadow: new THREE.MeshBasicMaterial({ map: shadows, transparent: true, depthWrite: false, opacity: 0.52 }),
  }
  const geometries = { trunk, palmTrunk, branch, crown, frond, roots, vine, leaves, bush, shadow }
  const types = {
    trunk: ['trunk', 'trunk'], palmTrunk: ['palmTrunk', 'trunk'], branch: ['branch', 'trunk'],
    root: ['roots', 'root'], crown: ['crown', 'crown'], frond: ['frond', 'frond'],
    leaves: ['leaves', 'leaves'], bush: ['bush', 'leaves'], vine: ['vine', 'vine'], shadow: ['shadow', 'shadow'],
  }
  const chunkSize = 320
  const chunks = new Map()
  const matrix = new THREE.Matrix4()
  const position = new THREE.Vector3()
  const scale = new THREE.Vector3()
  const quaternion = new THREE.Quaternion()
  const euler = new THREE.Euler()
  const color = new THREE.Color()
  const add = (type, x, y, z, sx, sy, sz, ry, tint, rx = 0, rz = 0) => {
    const cx = Math.floor(x / chunkSize), cz = Math.floor(z / chunkSize)
    const key = `${cx},${cz}`
    if (!chunks.has(key)) chunks.set(key, { x: (cx + 0.5) * chunkSize, z: (cz + 0.5) * chunkSize, lists: new Map() })
    const chunk = chunks.get(key)
    if (!chunk.lists.has(type)) chunk.lists.set(type, [])
    euler.set(rx, ry, rz, 'YXZ')
    quaternion.setFromEuler(euler)
    matrix.compose(position.set(x, y, z), quaternion, scale.set(sx, sy, sz))
    chunk.lists.get(type).push({ matrix: matrix.clone(), tint })
  }
  const addBranch = (x, y, z, ex, ey, ez, radius, tint) => {
    const direction = new THREE.Vector3(ex - x, ey - y, ez - z)
    const length = direction.length()
    const cx = Math.floor(x / chunkSize), cz = Math.floor(z / chunkSize)
    const key = `${cx},${cz}`
    if (!chunks.has(key)) chunks.set(key, { x: (cx + 0.5) * chunkSize, z: (cz + 0.5) * chunkSize, lists: new Map() })
    const chunk = chunks.get(key)
    if (!chunk.lists.has('branch')) chunk.lists.set('branch', [])
    quaternion.setFromUnitVectors(UP, direction.normalize())
    matrix.compose(position.set(x, y, z), quaternion, scale.set(radius, length, radius))
    chunk.lists.get('branch').push({ matrix: matrix.clone(), tint })
  }

  for (const tree of trees) {
    const { x, y, z, height: h, canopy: r, trunk: tr, kind, rotation, tint } = tree
    const barkTint = kind === 'palm' ? '#beac8b' : kind === 'fig' ? '#a4a18a' : '#b4a384'
    add(kind === 'palm' ? 'palmTrunk' : 'trunk', x, y - 0.3, z, tr, h, tr, rotation, barkTint)
    add('shadow', x, y + 0.2, z, r * 2.2, 1, r * 2.2, rotation, '#ffffff')
    if (kind === 'palm') {
      const topX = x + Math.cos(rotation) * tr * 3.2
      const topZ = z - Math.sin(rotation) * tr * 3.2
      for (let k = 0; k < 8; k++) {
        const a = rotation + (k / 8) * Math.PI * 2 + (rnd() - 0.5) * 0.2
        const length = r * (0.8 + rnd() * 0.35)
        add('frond', topX, y + h * 0.98, topZ, length, length, length, a, tint, 0, (rnd() - 0.5) * 0.12)
      }
      continue
    }
    if (kind === 'emergent' || kind === 'fig') {
      const rootCount = kind === 'emergent' ? 5 : 3
      for (let k = 0; k < rootCount; k++) {
        const angle = rotation + (k / rootCount) * Math.PI * 2
        add('root', x, y, z, tr * 2.8, h * 0.1, tr * 0.75, angle, '#69543d')
      }
    }
    // A broad, irregular crown made from several branch-supported lobes.
    add('crown', x, y + h * 0.97, z, r * 0.84, r * 0.48, r * 0.82, rotation, tint)
    const limbs = kind === 'emergent' ? 4 : 3
    for (let k = 0; k < limbs; k++) {
      const angle = rotation + (k / limbs) * Math.PI * 2 + (rnd() - 0.5) * 0.35
      const offset = r * (0.48 + rnd() * 0.18)
      const ex = x + Math.cos(angle) * offset
      const ez = z + Math.sin(angle) * offset
      const ey = y + h * (0.94 + rnd() * 0.09)
      addBranch(x, y + h * 0.69, z, ex, ey - r * 0.15, ez, Math.max(0.35, tr * 0.42), barkTint)
      add('crown', ex, ey, ez, r * (0.58 + rnd() * 0.15), r * 0.38, r * (0.55 + rnd() * 0.15), angle, GREEN[Math.floor(rnd() * GREEN.length)])
    }
    // Crossed leaf cards give the solid canopy a detailed, organic silhouette.
    const cardY = y + h * 0.93
    for (let k = 0; k < 3; k++) {
      add('leaves', x + (rnd() - 0.5) * r * 0.6, cardY + (rnd() - 0.5) * r * 0.3, z + (rnd() - 0.5) * r * 0.6, r * 2.2, r * 2.2, 1, rotation + (k / 3) * Math.PI, '#b8d6a3')
    }
    if (kind === 'fig' || (kind === 'emergent' && rnd() < 0.45)) {
      for (let k = 0; k < 3; k++) {
        const a = rotation + (k / 3) * Math.PI * 2
        const len = h * (0.4 + rnd() * 0.28)
        add('vine', x + Math.cos(a) * r * 0.55, y + h * 0.91, z + Math.sin(a) * r * 0.55, len, len, len, a, '#416c38')
      }
    }
  }

  // Ferns and large-leaf plants form the understory near the path's edge.
  let understory = 0
  const understoryTarget = Math.round(Math.min(2400, 1600 * amount))
  for (let tries = 0; tries < understoryTarget * 30 && understory < understoryTarget; tries++) {
    const [i, j] = candidates[Math.floor(rnd() * candidates.length)] || [0, 0]
    const edge = arena.edge[j * n + i]
    if (edge < 2 || edge > 100) continue
    const x = ox + (i + rnd()) * C, z = oz + (j + rnd()) * C
    const y = arena.groundAt(x, z) + 0.3
    const length = 4 + rnd() * 4
    const start = rnd() * Math.PI * 2
    for (let k = 0; k < 5; k++) {
      const a = start + (k / 5) * Math.PI * 2
      add('frond', x, y, z, length, length, length, a, GREEN[Math.floor(rnd() * GREEN.length)], 0, -0.08)
    }
    if (rnd() < 0.65) add('bush', x, y, z, length, length, length, start, '#a8d098')
    understory++
  }

  // Distinct tropical undergrowth lines the clear racing corridor.
  for (const path of arena.paths.slice(0, arena.n)) {
    for (let i = 3; i < path.pts.length - 3; i += 4) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / length, rz = (b[0] - a[0]) / length
      for (const side of [-1, 1]) {
        const offset = path.halfW - 4 + rnd() * 13
        const x = q[0] + rx * offset * side, z = q[1] + rz * offset * side
        if (sampleEdge(x, z) < -14) continue
        const y = arena.groundAt(x, z) + 0.25
        const size = 4.5 + rnd() * 4
        const angle = rnd() * Math.PI
        add('bush', x, y, z, size, size, size, angle, '#b5d79e')
        for (let k = 0; k < 3; k++) {
          const a0 = angle + (k / 3) * Math.PI * 2
          add('frond', x, y, z, size * 0.8, size * 0.8, size * 0.8, a0, GREEN[Math.floor(rnd() * GREEN.length)])
        }
        understory++
      }
    }
  }

  // High branches over the track create short canopy tunnels without blocking
  // the racing line: their lowest point remains well above every vehicle.
  let canopyBridges = 0
  for (const path of arena.paths.slice(0, arena.n)) {
    for (let i = 12; i < path.pts.length - 12; i += 12) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / length, rz = (b[0] - a[0]) / length
      const side = rnd() < 0.5 ? -1 : 1
      const proposedX = q[0] + rx * side * (path.halfW + 9)
      const proposedZ = q[1] + rz * side * (path.halfW + 9)
      let nearest = null
      let nearestDistance = 70
      for (const tree of trees) {
        if (tree.kind === 'palm') continue
        const d = Math.hypot(tree.x - proposedX, tree.z - proposedZ)
        if (d < nearestDistance) { nearest = tree; nearestDistance = d }
      }
      if (!nearest) continue
      const x0 = nearest.x
      const z0 = nearest.z
      const ground = arena.groundAt(q[0], q[1])
      const y0 = Math.max(ground + 25, nearest.y + nearest.height * 0.7)
      const x1 = q[0] + rx * side * 8
      const z1 = q[1] + rz * side * 8
      const y1 = y0 + 6
      addBranch(x0, y0, z0, x1, y1, z1, 1.4, '#a09270')
      add('shadow', x1, ground + 0.25, z1, 34, 1, 24, rnd() * Math.PI, '#ffffff')
      for (let k = 0; k < 4; k++) {
        const u = 0.25 + k * 0.22
        const px = x0 + (x1 - x0) * u, pz = z0 + (z1 - z0) * u
        const py = y0 + (y1 - y0) * u + 2
        add('leaves', px, py, pz, 20, 20, 1, (k / 4) * Math.PI + rnd(), '#afc89a')
      }
      const vineLength = Math.min(14, y1 - ground - 12)
      if (vineLength > 4) add('vine', x1, y1, z1, vineLength, vineLength, vineLength, rnd() * 6.28, '#4f793f')
      canopyBridges++
    }
  }

  const visibleChunks = []
  for (const chunk of chunks.values()) {
    const chunkGroup = new THREE.Group()
    for (const [type, list] of chunk.lists) {
      const [geometryName, materialName] = types[type]
      const mesh = new THREE.InstancedMesh(geometries[geometryName], materials[materialName], list.length)
      list.forEach((item, i) => {
        mesh.setMatrixAt(i, item.matrix)
        mesh.setColorAt(i, color.set(item.tint))
      })
      mesh.instanceMatrix.needsUpdate = true
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
      mesh.computeBoundingSphere()
      mesh.userData.detailDistance = ['trunk', 'palmTrunk', 'crown'].includes(type) ? Infinity : ['root', 'shadow', 'bush'].includes(type) ? 480 : 580
      chunkGroup.add(mesh)
    }
    group.add(chunkGroup)
    visibleChunks.push({ group: chunkGroup, x: chunk.x, z: chunk.z })
  }

  return {
    group,
    info: {
      treeCount: trees.length,
      species: treesBySpecies,
      maxHeight: trees.reduce((max, tree) => Math.max(max, tree.height), 0),
      understory,
      canopyBridges,
      chunks: visibleChunks.length,
    },
    update(_time, camera) {
      const maxDistance = 650 + chunkSize
      for (const chunk of visibleChunks) {
        const dx = chunk.x - camera.x, dz = chunk.z - camera.z
        const distance = dx * dx + dz * dz
        chunk.group.visible = distance < maxDistance * maxDistance
        if (chunk.group.visible) {
          for (const mesh of chunk.group.children) mesh.visible = distance < mesh.userData.detailDistance * mesh.userData.detailDistance
        }
      }
    },
    dispose() {
      Object.values(geometries).forEach((geometry) => geometry.dispose())
      Object.values(materials).forEach((material) => material.dispose())
      bark.dispose()
      foliage.dispose()
      shadows.dispose()
    },
  }
}