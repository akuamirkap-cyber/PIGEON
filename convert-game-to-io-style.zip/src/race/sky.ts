// @ts-nocheck
// One sky for every mode: a rich multi-stop gradient, drifting lit clouds, a warm glow round the sun, stars and a nebula
// at night. In Pixel mode the bands and clouds are posterised into hard steps; in Soft mode everything is smooth.
import * as THREE from 'three'

export const FOG_COL = { day: '#cfe8f8', sunset: '#f8b884', night: '#26407f' }

export const SKY_PAL = {
  day: {
    top: '#0d5bd8', mid: '#3d9cf4', low: '#8fd0fb', hor: FOG_COL.day, warm: '#fff2cc',
    cLit: '#ffffff', cShade: '#9db9e0', sun: '#fffdf0', glow: '#ffe7a0', stars: 0, cover: 0.5, nebula: 0,
  },
  sunset: {
    top: '#1c1470', mid: '#8a3aa4', low: '#ff7078', hor: FOG_COL.sunset, warm: '#ffa23c',
    cLit: '#ffe0b0', cShade: '#7e3f92', sun: '#fff4c0', glow: '#ff8c46', stars: 0.1, cover: 0.52, nebula: 0,
  },
  night: {
    top: '#02051a', mid: '#0a1850', low: '#1b3480', hor: FOG_COL.night, warm: '#4a6ccc',
    cLit: '#7088cc', cShade: '#18235a', sun: '#eef5ff', glow: '#6a8ae6', stars: 1, cover: 0.44, nebula: 1,
  },
}

export function makeSky({ tod, soft, sunDir, hor }) {
  const P = SKY_PAL[tod] || SKY_PAL.day
  const C = (h) => new THREE.Color(h)
  const uniforms = {
    top: { value: C(P.top) }, mid: { value: C(P.mid) }, low: { value: C(P.low) }, hor: { value: C(P.hor) }, warm: { value: C(P.warm) },
    cLit: { value: C(P.cLit) }, cShade: { value: C(P.cShade) }, sunC: { value: C(P.sun) }, glowC: { value: C(P.glow) },
    sunDir: { value: sunDir.clone().normalize() }, stars: { value: P.stars }, nebula: { value: P.nebula }, cover: { value: P.cover },
    soft: { value: soft ? 1 : 0 }, time: { value: 0 },
  }
  if (hor) uniforms.hor.value = C(hor)
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(7000, 40, 20),
    new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false, uniforms,
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }',
      fragmentShader: `
        varying vec3 vD;
        uniform vec3 top, mid, low, hor, warm, cLit, cShade, sunC, glowC, sunDir;
        uniform float stars, nebula, cover, soft, time;
        float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        float vn(vec2 p){
          vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
          return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y);
        }
        float fbm(vec2 p){
          float a = 0.5, s = 0.0;
          for (int i = 0; i < 5; i++) { s += a*vn(p); p = p*2.03 + vec2(17.1, 9.3); a *= 0.5; }
          return s;
        }
        void main(){
          vec3 d = normalize(vD);
          float h = d.y;
          float hh = clamp(h, 0.0, 1.0);
          float g = soft > 0.5 ? hh : floor(hh*14.0)/14.0;
          vec3 col = mix(hor, low, smoothstep(0.0, 0.10, g));
          col = mix(col, mid, smoothstep(0.07, 0.40, g));
          col = mix(col, top, smoothstep(0.28, 0.95, g));
          if (h < 0.0) col = hor;
          vec3 sd = normalize(sunDir);
          // the sky glows warm on the sun's side, low down
          float az = max(dot(normalize(d.xz + vec2(1e-4)), normalize(sd.xz + vec2(1e-4))), 0.0);
          col = mix(col, warm, pow(az, 3.0) * (1.0 - smoothstep(0.0, 0.55, g)) * 0.8);
          // night: stars and a soft nebula
          if (stars > 0.01 && h > 0.0) {
            vec2 sp = vec2(atan(d.z, d.x) * 90.0, h * 180.0);
            vec2 cell = floor(sp);
            float r = h21(cell);
            float tw = 0.65 + 0.35 * sin(time * 2.0 + r * 40.0);
            col += vec3(1.0) * step(0.9955, r) * smoothstep(0.04, 0.3, h) * stars * tw;
            col += vec3(0.7, 0.8, 1.0) * step(0.9988, h21(cell + 7.7)) * smoothstep(0.04, 0.3, h) * stars;
          }
          if (nebula > 0.5 && h > 0.0) {
            vec2 np = vec2(atan(d.z, d.x) * 1.7, h * 3.2);
            float nb = fbm(np * 1.6 + 3.0);
            float band = exp(-pow((d.x * 0.45 + d.z * 0.35 + h * 0.9) * 2.6, 2.0));
            vec3 neb = mix(vec3(0.34, 0.12, 0.62), vec3(0.08, 0.5, 0.72), vn(np * 2.2));
            col += neb * smoothstep(0.35, 0.8, nb) * (0.20 + 0.45 * band) * smoothstep(0.02, 0.35, h);
          }
          // clouds
          if (h > 0.0) {
            vec2 cp = d.xz / (h + 0.07) * 0.75 + vec2(time * 0.012, time * 0.004);
            float dn = fbm(cp * 1.15);
            float dens = smoothstep(cover, cover + 0.2, dn);
            float dn2 = fbm(cp * 1.15 + sd.xz * 0.16);
            float lk = clamp(0.5 + (dn - dn2) * 5.0, 0.0, 1.0);
            if (soft < 0.5) { dens = floor(dens * 3.0 + 0.5) / 3.0; lk = floor(lk * 3.0 + 0.5) / 3.0; }
            vec3 cc = mix(cShade, cLit, lk);
            float sdot = max(dot(d, sd), 0.0);
            cc = mix(cc, glowC, pow(sdot, 5.0) * 0.45);
            float fadeH = smoothstep(0.015, 0.17, h);
            col = mix(col, cc, dens * fadeH * 0.96);
            // thin high cirrus
            float cir = smoothstep(0.52, 0.86, fbm(vec2(cp.x * 0.32, cp.y * 1.7) + 7.0));
            if (soft < 0.5) cir = step(0.5, cir) * 0.6;
            col = mix(col, cLit, cir * 0.32 * fadeH * (1.0 - dens));
          }
          // the sun, with a glow and a halo
          float sdot2 = max(dot(d, sd), 0.0);
          float glow = pow(sdot2, 6.0) * 0.22 + pow(sdot2, 40.0) * 0.5;
          col += glowC * glow * (soft > 0.5 ? 1.0 : 0.85);
          float disc = soft > 0.5 ? smoothstep(0.9968, 0.9978, sdot2) : step(0.9973, sdot2);
          col = mix(col, sunC, disc);
          gl_FragColor = vec4(col, 1.0);
          gl_FragColor = linearToOutputTexel(gl_FragColor);
        }`,
    }),
  )
  mesh.frustumCulled = false
  // drawn last, so the terrain in front of it spares the cost of the clouds
  mesh.renderOrder = 1000
  return {
    mesh,
    palette: P,
    update(time, camPos) {
      uniforms.time.value = time
      if (camPos) mesh.position.copy(camPos)
    },
  }
}
