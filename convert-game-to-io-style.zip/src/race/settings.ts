import { SKINS } from './vehicles'

export type Settings = Record<string, any>

export type Control =
  | { key: string; label: string; type: 'slider'; min: number; max: number; step: number; unit?: string; hint?: string; labels?: string[] }
  | { key: string; label: string; type: 'switch'; hint?: string }
  | { key: string; label: string; type: 'seg'; options: string[]; names?: string[] }
  | { key: string; label: string; type: 'random'; min: number; max: number }

export type Group = { title: string; open?: boolean; controls: Control[] }

export const CLASS_INFO = [
  { name: 'Vektor', kmh: 907, desc: 'Santai & stabil' },
  { name: 'Venom', kmh: 1231, desc: 'Seimbang' },
  { name: 'Flash', kmh: 1588, desc: 'Cepat & liar' },
  { name: 'Rapier', kmh: 1976, desc: 'Gila-gilaan' },
]

export const DEFAULTS: Settings = {
  // kendaraan
  skin: 'scout',
  botSkins: 'mixed',
  // mode
  mode: 'arena',
  arenaPlanet: 'forest',
  arenaSeed: 7,
  arenaSize: 1000,
  arenaGates: 8,
  arenaWidth: 100,
  forestDensity: 1,
  forestRelief: 1,
  shortcuts: 0.7,
  hazards: 0.45,
  // balapan
  laps: 3,
  bots: 11,
  botSkill: 0.6,
  rubber: 0.5,
  shipClass: 1,
  // handling
  assist: 0.5,
  steerGain: 1,
  accelGain: 1,
  airbrake: 1,
  wallDmg: 1,
  shieldMax: 100,
  turboDrain: 0.3,
  turboRegen: 0.1,
  padPower: 1,
  autoGas: false,
  // lintasan
  trackSeed: 7,
  trackRadius: 1000,
  trackWidth: 30,
  hills: 0.7,
  pads: 8,
  theme: 'day',
  islands: 0.34,
  clouds: 0.5,
  worldSeed: 7,
  // tampilan
  look: 'pixel',
  renderScale: 0.8,
  camMode: 'chase',
  fov: 78,
  bloom: false,
  pixelSize: 0,
  speedLines: true,
  showMini: true,
  showBoard: true,
  showHint: true,
  touchControls: 'auto',
  // suara
  volMaster: 0.8,
  volMusic: 0.55,
  volSfx: 0.9,
  muted: false,
}

export const PRESETS: { name: string; desc: string; values: Settings }[] = [
  { name: 'Santai', desc: 'Vektor · 7 bot lambat · bantuan penuh', values: { shipClass: 0, bots: 7, botSkill: 0.3, assist: 0.85, wallDmg: 0.5, rubber: 0.3, autoGas: true } },
  { name: 'Normal', desc: 'Venom · 11 bot', values: { shipClass: 1, bots: 11, botSkill: 0.6, assist: 0.5, wallDmg: 1, rubber: 0.5, autoGas: false } },
  { name: 'Sulit', desc: 'Flash · 15 bot pintar', values: { shipClass: 2, bots: 15, botSkill: 0.85, assist: 0.25, wallDmg: 1.2, rubber: 0.6, autoGas: false } },
  { name: 'Gila', desc: 'Rapier · tanpa bantuan', values: { shipClass: 3, bots: 15, botSkill: 1, assist: 0.05, wallDmg: 1.6, rubber: 0.8, autoGas: false } },
]

export const GROUPS: Group[] = [
  {
    title: 'Kendaraan',
    open: true,
    controls: [
      { key: 'skin', label: 'Kendaraan dan pilot (V ganti)', type: 'seg', options: SKINS.map((skin) => skin.id), names: SKINS.map((skin) => skin.name) },
      { key: 'botSkins', label: 'Skin lawan', type: 'seg', options: ['mixed', 'same'], names: ['Campur', 'Sama denganmu'] },
    ],
  },
  {
    title: 'Balapan',
    open: true,
    controls: [
      { key: 'mode', label: 'Mode balapan', type: 'seg', options: ['track', 'arena'], names: ['Sirkuit', 'Arena'] },
      { key: 'shipClass', label: 'Kelas pesawat', type: 'slider', min: 0, max: 3, step: 1, labels: CLASS_INFO.map((c) => c.name), hint: 'Makin tinggi makin kencang' },
      { key: 'laps', label: 'Jumlah lap', type: 'slider', min: 1, max: 10, step: 1 },
      { key: 'bots', label: 'Jumlah lawan (bot)', type: 'slider', min: 0, max: 15, step: 1, hint: 'Berlaku di balapan berikutnya' },
      { key: 'botSkill', label: 'Kepintaran bot', type: 'slider', min: 0.05, max: 1, step: 0.05 },
      { key: 'rubber', label: 'Bot ngejar (rubber-band)', type: 'slider', min: 0, max: 1, step: 0.05, hint: 'Bot mempercepat kalau kamu jauh di depan' },
    ],
  },
  {
    title: 'Handling pesawat',
    controls: [
      { key: 'assist', label: 'Bantuan kemudi', type: 'slider', min: 0, max: 1, step: 0.05, hint: '1 = hampir otomatis menempel jalur' },
      { key: 'steerGain', label: 'Ketajaman belok', type: 'slider', min: 0.5, max: 1.8, step: 0.05, unit: '×' },
      { key: 'accelGain', label: 'Akselerasi', type: 'slider', min: 0.5, max: 2, step: 0.05, unit: '×' },
      { key: 'airbrake', label: 'Kekuatan rem udara (Q/E)', type: 'slider', min: 0, max: 2, step: 0.1, unit: '×' },
      { key: 'wallDmg', label: 'Damage tabrak dinding', type: 'slider', min: 0, max: 3, step: 0.1, unit: '×' },
      { key: 'shieldMax', label: 'Kekuatan perisai', type: 'slider', min: 40, max: 400, step: 10 },
      { key: 'turboDrain', label: 'Boros turbo', type: 'slider', min: 0, max: 1.5, step: 0.05, unit: '/dtk', hint: '0 = turbo tanpa batas' },
      { key: 'turboRegen', label: 'Isi ulang turbo', type: 'slider', min: 0.01, max: 0.6, step: 0.01, unit: '/dtk' },
      { key: 'padPower', label: 'Kekuatan pad boost', type: 'slider', min: 0, max: 3, step: 0.1, unit: '×' },
      { key: 'autoGas', label: 'Gas otomatis', type: 'switch' },
    ],
  },
  {
    title: 'Arena: hutan & kanyon (mode Arena)',
    controls: [
      { key: 'arenaPlanet', label: 'Medan', type: 'seg', options: ['forest', 'desert', 'ice', 'lava'], names: ['Hutan', 'Gurun', 'Es', 'Lava'] },
      { key: 'arenaGates', label: 'Jumlah gerbang', type: 'slider', min: 5, max: 12, step: 1 },
      { key: 'arenaSize', label: 'Ukuran peta', type: 'slider', min: 550, max: 1400, step: 50, unit: 'm' },
      { key: 'arenaWidth', label: 'Lebar jalur utama', type: 'slider', min: 70, max: 160, step: 5, unit: 'm' },
      { key: 'forestDensity', label: 'Kepadatan hutan', type: 'slider', min: 0.4, max: 1.4, step: 0.1, unit: 'x', hint: 'Turunkan bila permainan terasa berat' },
      { key: 'forestRelief', label: 'Tinggi turunan hutan', type: 'slider', min: 0.4, max: 1.2, step: 0.1, unit: 'x', hint: 'Mengubah medan dan memulai ulang balapan' },
      { key: 'shortcuts', label: 'Jalan pintas', type: 'slider', min: 0, max: 1, step: 0.05, hint: 'Sebagian tertutup dinding batu: hancurkan dengan kecepatan tinggi / turbo' },
      { key: 'hazards', label: 'Rintangan bergerak', type: 'slider', min: 0, max: 1.4, step: 0.05, hint: 'Batu, penghalang berputar dan semburan' },
      { key: 'arenaSeed', label: 'Nomor arena', type: 'slider', min: 1, max: 99, step: 1 },
      { key: 'arenaSeed', label: 'Arena acak', type: 'random', min: 1, max: 99 },
    ],
  },
  {
    title: 'Lintasan',
    controls: [
      { key: 'trackSeed', label: 'Nomor lintasan', type: 'slider', min: 1, max: 99, step: 1 },
      { key: 'trackSeed', label: 'Lintasan acak', type: 'random', min: 1, max: 99 },
      { key: 'trackRadius', label: 'Ukuran lintasan', type: 'slider', min: 600, max: 1800, step: 50, unit: 'm' },
      { key: 'trackWidth', label: 'Lebar jalan', type: 'slider', min: 22, max: 50, step: 1, unit: 'm' },
      { key: 'hills', label: 'Tanjakan & turunan', type: 'slider', min: 0, max: 1.4, step: 0.05 },
      { key: 'pads', label: 'Jumlah pad boost', type: 'slider', min: 0, max: 16, step: 1 },
      { key: 'theme', label: 'Waktu', type: 'seg', options: ['day', 'sunset', 'night'], names: ['Siang', 'Senja', 'Malam'] },
      { key: 'islands', label: 'Luas pulau', type: 'slider', min: 0.08, max: 0.7, step: 0.01 },
      { key: 'clouds', label: 'Awan', type: 'slider', min: 0, max: 1, step: 0.05 },
      { key: 'worldSeed', label: 'Bentuk dunia (seed)', type: 'slider', min: 1, max: 99, step: 1 },
      { key: 'worldSeed', label: 'Dunia acak', type: 'random', min: 1, max: 99 },
    ],
  },
  {
    title: 'Kamera & tampilan',
    controls: [
      { key: 'look', label: 'Gaya gambar (F ganti)', type: 'seg', options: ['pixel', 'soft'], names: ['Pixel', 'Lembut'] },
      { key: 'renderScale', label: 'Resolusi (mode Lembut)', type: 'slider', min: 0.4, max: 1.5, step: 0.05, unit: '×', hint: 'Turunkan bila patah-patah; 1.0 = setajam layar' },
      { key: 'camMode', label: 'Kamera (C ganti)', type: 'seg', options: ['chase', 'near', 'cockpit'], names: ['Belakang', 'Rendah', 'Kokpit'] },
      { key: 'fov', label: 'Sudut pandang (FOV)', type: 'slider', min: 60, max: 110, step: 1, unit: '°' },
      { key: 'pixelSize', label: 'Ukuran piksel (mode Pixel, 0 = auto)', type: 'slider', min: 0, max: 8, step: 1, hint: 'Makin besar makin kasar & ringan' },
      { key: 'bloom', label: 'Efek cahaya (bloom)', type: 'switch' },
      { key: 'speedLines', label: 'Garis kecepatan', type: 'switch' },
      { key: 'showMini', label: 'Peta mini', type: 'switch' },
      { key: 'showBoard', label: 'Papan peringkat', type: 'switch' },
      { key: 'showHint', label: 'Petunjuk tombol', type: 'switch' },
    ],
  },
  {
    title: 'Suara',
    open: true,
    controls: [
      { key: 'muted', label: 'Bisukan semua suara (M)', type: 'switch' },
      { key: 'volMaster', label: 'Volume utama', type: 'slider', min: 0, max: 1, step: 0.05 },
      { key: 'volMusic', label: 'Musik', type: 'slider', min: 0, max: 1, step: 0.05 },
      { key: 'volSfx', label: 'Efek (mesin, tabrakan, boost)', type: 'slider', min: 0, max: 1, step: 0.05 },
    ],
  },
]

const KEY = 'hoverrush-settings-v5'

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }
  } catch {
    /* ignore */
  }
  return { ...DEFAULTS }
}
export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s))
  } catch {
    /* ignore */
  }
}
export function loadName(): string {
  try {
    return localStorage.getItem('hoverrush-name') || ''
  } catch {
    return ''
  }
}
export function saveName(n: string) {
  try {
    localStorage.setItem('hoverrush-name', n)
  } catch {
    /* ignore */
  }
}
