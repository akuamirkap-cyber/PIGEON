// @ts-nocheck
// Rideable river surfaces follow the same heightfield as the forest race route.
import * as THREE from 'three'

const clamp = (value, low, high) => Math.min(high, Math.max(low, value))

function pointsAlong(path, start, end) {
  const points = []
  for (let i = start; i < end; i++) {
    const a = path.pts[i], b = path.pts[i + 1]
    const distance = Math.hypot(b[0] - a[0], b[1] - a[1])
    const steps = Math.max(1, Math.ceil(distance / 4))
    for (let j = 0; j < steps; j++) {
      const t = j / steps
      points.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t])
    }
  }
  points.push(path.pts[end].slice())
  return points
}

export function buildForestRapids(arena, { fogColor, fogDensity, soft, mistTexture }) {
  const group = new THREE.Group()
  group.name = 'forest-rapids'
  const uniforms = {
    time: { value: 0 },
    fogColor: { value: new THREE.Color(fogColor) },
    fogDensity: { value: fogDensity },
    soft: { value: soft ? 1 : 0 },
  }
  const waterMaterial = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: `
      attribute vec2 flowInfo;
      varying vec2 vUv;
      varying vec2 vFlow;
      varying vec3 vWorld;
      void main(){
        vUv = uv;
        vFlow = flowInfo;
        vec4 world = modelMatrix * vec4(position, 1.0);
        vWorld = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }`,
    fragmentShader: `
      varying vec2 vUv;
      varying vec2 vFlow;
      varying vec3 vWorld;
      uniform float time, fogDensity, soft;
      uniform vec3 fogColor;
      float hash21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float noise2(vec2 p){
        vec2 i = floor(p), f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash21(i), hash21(i + vec2(1., 0.)), f.x), mix(hash21(i + vec2(0., 1.)), hash21(i + vec2(1., 1.)), f.x), f.y);
      }
      void main(){
        float edge = smoothstep(0.0, 0.12, vUv.x) * (1.0 - smoothstep(0.88, 1.0, vUv.x));
        float ends = smoothstep(0.0, 0.06, vFlow.x) * (1.0 - smoothstep(0.94, 1.0, vFlow.x));
        float speed = time * 1.4;
        float longWaves = noise2(vec2(vUv.x * 8.0, vUv.y * 3.6 - speed));
        float ripples = noise2(vec2(vUv.x * 24.0 + 4.0, vUv.y * 9.0 - speed * 2.1));
        float crest = smoothstep(0.54, 0.8, longWaves * 0.65 + ripples * 0.35 + vFlow.y * 0.12);
        if (soft < 0.5) crest = floor(crest * 4.0 + 0.5) / 4.0;
        vec3 water = mix(vec3(0.025, 0.19, 0.19), vec3(0.06, 0.44, 0.41), longWaves);
        water = mix(water, vec3(0.78, 0.97, 0.91), crest * (0.35 + vFlow.y * 0.55));
        float shoreFoam = (1.0 - smoothstep(0.0, 0.12, min(vUv.x, 1.0 - vUv.x))) * 0.42;
        water = mix(water, vec3(0.74, 0.94, 0.87), shoreFoam);
        float distanceToCamera = length(vWorld - cameraPosition);
        float fog = 1.0 - exp(-fogDensity * fogDensity * distanceToCamera * distanceToCamera);
        water = mix(water, fogColor, clamp(fog, 0.0, 1.0));
        gl_FragColor = vec4(water, edge * ends * 0.88);
        gl_FragColor = linearToOutputTexel(gl_FragColor);
      }`,
  })

  const rocks = []
  const mist = []
  for (const rapid of arena.rapids) {
    const path = arena.paths[rapid.pathId]
    const points = pointsAlong(path, rapid.startIndex, rapid.endIndex)
    if (points.length < 2) continue
    const rows = points.length
    const columns = 9
    const positions = new Float32Array(rows * columns * 3)
    const uv = new Float32Array(rows * columns * 2)
    const flow = new Float32Array(rows * columns * 2)
    const indices = []
    let distance = 0
    for (let i = 0; i < rows; i++) {
      const previous = points[Math.max(0, i - 1)]
      const next = points[Math.min(rows - 1, i + 1)]
      let dx = next[0] - previous[0], dz = next[1] - previous[1]
      const length = Math.hypot(dx, dz) || 1
      dx /= length; dz /= length
      if (i > 0) distance += Math.hypot(points[i][0] - points[i - 1][0], points[i][1] - points[i - 1][1])
      const before = arena.groundAt(previous[0], previous[1])
      const after = arena.groundAt(next[0], next[1])
      const slope = clamp((before - after) / length * 1.6, 0, 1)
      const progress = i / (rows - 1)
      const width = Math.min(38, path.halfW * 0.76) * (0.94 + 0.06 * Math.sin(progress * Math.PI * 4))
      for (let c = 0; c < columns; c++) {
        const across = (c / (columns - 1)) * 2 - 1
        const x = points[i][0] - dz * across * width
        const z = points[i][1] + dx * across * width
        const vertex = i * columns + c
        positions[vertex * 3] = x
        positions[vertex * 3 + 1] = arena.groundAt(x, z) + 0.75
        positions[vertex * 3 + 2] = z
        uv[vertex * 2] = c / (columns - 1)
        uv[vertex * 2 + 1] = distance / 38
        flow[vertex * 2] = progress
        flow[vertex * 2 + 1] = slope
        if (i < rows - 1 && c < columns - 1) {
          indices.push(vertex, vertex + columns, vertex + 1, vertex + 1, vertex + columns, vertex + columns + 1)
        }
      }
    }
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
    geometry.setAttribute('flowInfo', new THREE.BufferAttribute(flow, 2))
    geometry.setIndex(indices)
    geometry.computeBoundingSphere()
    const water = new THREE.Mesh(geometry, waterMaterial)
    water.name = `rapid-${rapid.segment}`
    water.renderOrder = 4
    group.add(water)

    // Low mossy rocks and spray sit at the river's banks, outside the riding line.
    for (let i = 3; i < rows - 3; i += Math.max(10, Math.floor(rows / 8))) {
      const a = points[i - 1], b = points[i + 1]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / length, rz = (b[0] - a[0]) / length
      for (const side of [-1, 1]) {
        const width = Math.min(38, path.halfW * 0.76) + 5 + ((i + rapid.segment) % 4) * 1.2
        const x = points[i][0] + rx * width * side
        const z = points[i][1] + rz * width * side
        const y = arena.groundAt(x, z)
        const size = 2.5 + ((i + rapid.segment * 3) % 5) * 0.45
        rocks.push({ x, y: y + size * 0.25, z, size, rotation: (i * 0.8 + side) % (Math.PI * 2) })
      }
    }
    const bottom = points[points.length - 1]
    for (let i = 0; i < 3; i++) {
      const material = new THREE.SpriteMaterial({ map: mistTexture, color: '#e2fff2', transparent: true, opacity: 0.12, depthWrite: false })
      const sprite = new THREE.Sprite(material)
      sprite.position.set(bottom[0] + (i - 1) * 10, arena.groundAt(bottom[0], bottom[1]) + 4 + i * 2, bottom[1] + (i - 1) * 5)
      const size = 24 + i * 6
      sprite.scale.setScalar(size)
      group.add(sprite)
      mist.push({ sprite, size, phase: i * 1.8 + rapid.segment })
    }
  }

  if (rocks.length) {
    const geometry = new THREE.DodecahedronGeometry(1, 0)
    const material = new THREE.MeshLambertMaterial({ color: '#68805b', flatShading: true })
    const mesh = new THREE.InstancedMesh(geometry, material, rocks.length)
    const matrix = new THREE.Matrix4(), position = new THREE.Vector3(), scale = new THREE.Vector3()
    const rotation = new THREE.Quaternion(), axis = new THREE.Vector3(0, 1, 0)
    rocks.forEach((rock, i) => {
      rotation.setFromAxisAngle(axis, rock.rotation)
      matrix.compose(position.set(rock.x, rock.y, rock.z), rotation, scale.set(rock.size, rock.size * 0.7, rock.size * 0.85))
      mesh.setMatrixAt(i, matrix)
    })
    mesh.computeBoundingSphere()
    group.add(mesh)
  }

  return {
    group,
    info: arena.rapids.map((rapid) => ({ ...rapid })),
    update(time) {
      uniforms.time.value = time
      for (const m of mist) m.sprite.scale.setScalar(m.size * (1 + 0.08 * Math.sin(time * 0.8 + m.phase)))
    },
    dispose() {
      const geometries = new Set(), materials = new Set()
      group.traverse((object) => {
        if (object.geometry && !object.isSprite) geometries.add(object.geometry)
        if (object.material) materials.add(object.material)
      })
      geometries.forEach((geometry) => geometry.dispose())
      materials.forEach((material) => material.dispose())
    },
  }
}