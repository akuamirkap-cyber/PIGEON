import { useState } from 'react'
import { GROUPS, PRESETS, type Control, type Settings } from './settings'

type Props = {
  open: boolean
  settings: Settings
  onChange: (patch: Settings) => void
  onReset: () => void
  onClose: () => void
}

const fmt = (v: number, step: number) => Number(v).toFixed(step >= 1 ? 0 : step >= 0.1 ? 1 : 2)

function Row({ c, value, onChange }: { c: Control; value: any; onChange: (v: any) => void }) {
  if (c.type === 'slider') {
    return (
      <label className="block">
        <div className="flex items-baseline justify-between gap-2 text-[11px] leading-4">
          <span className="text-white/80">{c.label}</span>
          <span className="font-bold tabular-nums text-cyan-300">
            {c.labels ? c.labels[value] : fmt(value, c.step)}
            {c.unit ? <span className="ml-0.5 text-[9px] font-normal text-white/50">{c.unit}</span> : null}
          </span>
        </div>
        <input
          type="range"
          min={c.min}
          max={c.max}
          step={c.step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          onPointerUp={(e) => (e.currentTarget as HTMLInputElement).blur()}
          className="mt-1 h-1.5 w-full cursor-pointer accent-cyan-400"
        />
        {c.hint ? <div className="mt-0.5 text-[9px] text-white/40">{c.hint}</div> : null}
      </label>
    )
  }
  if (c.type === 'switch') {
    return (
      <button
        type="button"
        onClick={(e) => {
          onChange(!value)
          e.currentTarget.blur()
        }}
        className="flex w-full items-center justify-between text-[11px] leading-4 text-white/80"
      >
        <span>{c.label}</span>
        <span className={`relative h-4 w-8 rounded-full transition-colors ${value ? 'bg-cyan-400' : 'bg-white/20'}`}>
          <span className={`absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all ${value ? 'left-[18px]' : 'left-0.5'}`} />
        </span>
      </button>
    )
  }
  if (c.type === 'random') {
    return (
      <button
        type="button"
        onClick={(e) => {
          onChange(Math.floor(c.min + Math.random() * (c.max - c.min + 1)))
          e.currentTarget.blur()
        }}
        className="w-full rounded border border-white/20 bg-white/5 py-1.5 text-[11px] uppercase tracking-wider text-white/85 hover:bg-white/10"
      >
        🎲 {c.label}
      </button>
    )
  }
  return (
    <div>
      <div className="mb-1 text-[11px] leading-4 text-white/80">{c.label}</div>
      <div className={c.options.length > 4 ? 'grid grid-cols-2 gap-1' : 'flex overflow-hidden rounded border border-white/15'}>
        {c.options.map((o, i) => (
          <button
            key={o}
            type="button"
            onClick={(e) => {
              onChange(o)
              e.currentTarget.blur()
            }}
            aria-pressed={value === o}
            className={`flex-1 px-1 py-1.5 text-[10px] uppercase tracking-wider transition-colors ${c.options.length > 4 ? 'border border-white/15' : ''} ${
              value === o ? 'bg-cyan-400 font-bold text-black' : 'bg-white/5 text-white/70 hover:bg-white/10'
            }`}
          >
            {c.names ? c.names[i] : o}
          </button>
        ))}
      </div>
    </div>
  )
}

export default function SettingsPanel({ open, settings, onChange, onReset, onClose }: Props) {
  const [closed, setClosed] = useState<Record<string, boolean>>(() => Object.fromEntries(GROUPS.map((g) => [g.title, !g.open])))
  return (
    <aside
      aria-hidden={!open}
      inert={!open}
      className={`absolute inset-y-0 right-0 z-40 flex w-[330px] max-w-[92vw] flex-col border-l border-cyan-300/25 bg-[#070b1c]/93 text-white shadow-2xl backdrop-blur transition-transform duration-200 ${
        open ? 'translate-x-0' : 'pointer-events-none translate-x-full'
      }`}
      onKeyDown={(e) => e.stopPropagation()}
    >
      <header className="flex items-center justify-between border-b border-white/10 px-4 py-3">
        <div>
          <div className="text-xs font-black uppercase italic tracking-[0.22em] text-cyan-300">Pengaturan</div>
          <div className="text-[10px] text-white/45">Balapan dijeda selagi dibuka · tersimpan otomatis</div>
        </div>
        <button type="button" onClick={onClose} className="rounded border border-white/20 px-2 py-1 text-[11px] hover:bg-white/10" aria-label="Tutup">
          ✕
        </button>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3">
        <div className="mb-1 text-[10px] uppercase tracking-[0.18em] text-white/50">Tingkat kesulitan</div>
        <div className="mb-4 grid grid-cols-2 gap-1.5">
          {PRESETS.map((p) => (
            <button
              key={p.name}
              type="button"
              onClick={(e) => {
                onChange(p.values)
                e.currentTarget.blur()
              }}
              className="rounded border border-white/15 bg-white/5 px-2 py-1.5 text-left transition-colors hover:border-cyan-300/60 hover:bg-cyan-300/10"
            >
              <div className="text-[11px] font-bold uppercase tracking-wider">{p.name}</div>
              <div className="text-[9px] leading-tight text-white/50">{p.desc}</div>
            </button>
          ))}
        </div>
        {GROUPS.map((g) => (
          <section key={g.title} className="mb-3 border-t border-white/10 pt-2">
            <button
              type="button"
              onClick={(e) => {
                setClosed((s) => ({ ...s, [g.title]: !s[g.title] }))
                e.currentTarget.blur()
              }}
              className="flex w-full items-center justify-between py-1 text-[11px] font-bold uppercase tracking-[0.18em] text-white/90"
            >
              {g.title}
              <span className="text-white/50">{closed[g.title] ? '+' : '–'}</span>
            </button>
            {!closed[g.title] && (
              <div className="mt-2 space-y-3">
                {g.controls.map((c, i) => (
                  <Row key={c.key + i} c={c} value={settings[c.key]} onChange={(v) => onChange({ [c.key]: v })} />
                ))}
              </div>
            )}
          </section>
        ))}
      </div>
      <footer className="border-t border-white/10 p-3">
        <button
          type="button"
          onClick={(e) => {
            onReset()
            e.currentTarget.blur()
          }}
          className="w-full rounded border border-white/20 py-1.5 text-[11px] uppercase tracking-wider text-white/80 hover:bg-white/10"
        >
          Reset ke default
        </button>
      </footer>
    </aside>
  )
}
