// Arena mode: an open canyon planet, no road. Gates ring the map; between gates the way splits into a wide main
// canyon and (often) a narrow shortcut, some of them sealed with a rock wall you must smash through at speed.
// Hazards move: rolling boulders, spinning bars, fire geysers. Pure maths — no three.js.
import { CLASS_TOP, type Input, type RaceEvent, type RaceParams } from './sim'
import { getVehicleStats, vehicleForRacer, type VehicleId } from './vehicles'

export const Q = 4 // metres per stacked layer

export type ArenaOpts = { seed: number; radius: number; gates: number; width: number; shortcuts: number; hazards: number; pads: number; planet: string; forestRelief?: number }

export type Path = { id: number; seg: number; kind: 'main' | 'cut'; pts: number[][]; halfW: number; len: number; hidden: boolean }
export type Gate = { x: number; z: number; nx: number; nz: number; r: number }
export type Obstacle = {
  id: number
  type: 'rock' | 'roller' | 'fan' | 'geyser' | 'rockwall'
  x: number
  z: number
  r: number
  ax?: number
  az?: number
  bx?: number
  bz?: number
  period: number
  phase: number
  duty: number
  len: number
  w: number
  path: number
  broken: boolean
}
export type ArenaPad = { x: number; z: number; r: number }
export type ForestRapid = { pathId: number; segment: number; startIndex: number; endIndex: number; drop: number }

export type Arena = {
  opts: ArenaOpts
  n: number // how many gates
  cells: number // ground columns along one side
  C: number
  ox: number
  oz: number
  size: number
  hgt: Float32Array // ground height in metres per column
  lat: Float32Array // 0 on the middle of a route .. 1 at its edge (beyond: more)
  edge: Float32Array // metres outside the nearest floor
  gates: Gate[]
  paths: Path[]
  segs: number[][]
  obstacles: Obstacle[]
  pads: ArenaPad[]
  rapids: ForestRapid[]
  meanSeg: number
  groundAt: (x: number, z: number) => number
  bounds: { x0: number; z0: number; sc: number; ox: number; oz: number }
}

function mulberry32(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v))
const wrapA = (a: number) => {
  while (a > Math.PI) a -= Math.PI * 2
  while (a < -Math.PI) a += Math.PI * 2
  return a
}

function catmull(ctrl: number[][], closed: boolean, sub: number): number[][] {
  const K = ctrl.length
  const out: number[][] = []
  const get = (i: number) => (closed ? ctrl[((i % K) + K) % K] : ctrl[clamp(i, 0, K - 1)])
  const segs = closed ? K : K - 1
  for (let k = 0; k < segs; k++) {
    const p0 = get(k - 1), p1 = get(k), p2 = get(k + 1), p3 = get(k + 2)
    for (let j = 0; j < sub; j++) {
      const t = j / sub, t2 = t * t, t3 = t2 * t
      out.push([0, 1].map((c) => 0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3)))
    }
  }
  if (!closed) out.push(ctrl[K - 1].slice())
  return out
}
function resample(pts: number[][], step: number): number[][] {
  const out: number[][] = [pts[0].slice()]
  let acc = 0
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i]
    let d = Math.hypot(b[0] - a[0], b[1] - a[1])
    let from = a
    while (acc + d >= step) {
      const t = (step - acc) / d
      const p = [from[0] + (b[0] - from[0]) * t, from[1] + (b[1] - from[1]) * t]
      out.push(p)
      from = p
      d = Math.hypot(b[0] - p[0], b[1] - p[1])
      acc = 0
    }
    acc += d
  }
  const last = pts[pts.length - 1]
  if (Math.hypot(out[out.length - 1][0] - last[0], out[out.length - 1][1] - last[1]) > 1) out.push(last.slice())
  return out
}
const plen = (p: number[][]) => {
  let l = 0
  for (let i = 1; i < p.length; i++) l += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1])
  return l
}

function noiseField(n: number, scaleCols: number, rnd: () => number, amp: number, out: Float32Array) {
  const P = Math.ceil(n / scaleCols) + 2
  const lat = new Float32Array(P * P)
  for (let i = 0; i < lat.length; i++) lat[i] = rnd()
  for (let j = 0; j < n; j++) {
    const fy = j / scaleCols
    const y0 = Math.floor(fy)
    let ty = fy - y0
    ty = ty * ty * (3 - 2 * ty)
    for (let i = 0; i < n; i++) {
      const fx = i / scaleCols
      const x0 = Math.floor(fx)
      let tx = fx - x0
      tx = tx * tx * (3 - 2 * tx)
      const a = lat[y0 * P + x0] + (lat[y0 * P + x0 + 1] - lat[y0 * P + x0]) * tx
      const b = lat[(y0 + 1) * P + x0] + (lat[(y0 + 1) * P + x0 + 1] - lat[(y0 + 1) * P + x0]) * tx
      out[j * n + i] += amp * (a + (b - a) * ty)
    }
  }
}

export function buildArena(o: ArenaOpts): Arena {
  const rnd = mulberry32(Math.round(o.seed) * 7177 + 31)
  const n = clamp(Math.round(o.gates), 4, 12)
  const R = o.radius
  // ── the gates: a ring (star-shaped, so it never crosses itself)
  const nodes: number[][] = []
  const jit = rnd() * Math.PI * 2
  for (let k = 0; k < n; k++) {
    const th = jit + (k / n) * Math.PI * 2 + (rnd() - 0.5) * 0.3 * ((Math.PI * 2) / n)
    const r = R * (0.74 + 0.26 * rnd())
    nodes.push([Math.cos(th) * r, Math.sin(th) * r])
  }
  // ── the wide main route: a closed spline through every gate, bowing in or out between them
  const planCut: boolean[] = []
  for (let k = 0; k < n; k++) planCut.push(rnd() < o.shortcuts)
  const ctrl: number[][] = []
  for (let k = 0; k < n; k++) {
    const a = nodes[k]
    const b = nodes[(k + 1) % n]
    const dx = b[0] - a[0], dz = b[1] - a[1]
    const L = Math.hypot(dx, dz) || 1
    const bow = (rnd() < 0.5 ? -1 : 1) * (planCut[k] ? 0.26 + rnd() * 0.14 : 0.08 + rnd() * 0.12) * L
    ctrl.push(a, [(a[0] + b[0]) / 2 - (dz / L) * bow, (a[1] + b[1]) / 2 + (dx / L) * bow])
  }
  const SUB = 24
  const dense = catmull(ctrl, true, SUB)
  // round every corner off, so the canyon can be flown at speed
  for (let pass = 0; pass < 5; pass++) {
    const c = dense.map((p) => p.slice())
    const M = dense.length
    for (let i = 0; i < M; i++) {
      for (let a = 0; a < 2; a++) {
        let sum = 0
        for (let k = -4; k <= 4; k++) sum += c[(i + k + M * 3) % M][a]
        dense[i][a] = sum / 9
      }
    }
  }
  // the gates sit on the smoothed route
  for (let k = 0; k < n; k++) nodes[k] = dense[(k * 2 * SUB) % dense.length].slice()
  const paths: Path[] = []
  const segs: number[][] = []
  const mainHalf = o.width / 2
  const cutHalf = Math.max(18, o.width * 0.34)
  for (let k = 0; k < n; k++) {
    const i0 = k * 2 * SUB
    const i1 = (k + 1) * 2 * SUB
    const part: number[][] = []
    for (let i = i0; i <= i1; i++) part.push(dense[i % dense.length])
    const pts = resample(part, 10)
    paths.push({ id: paths.length, seg: k, kind: 'main', pts, halfW: mainHalf, len: plen(pts), hidden: false })
    segs.push([paths.length - 1])
  }
  // ── shortcuts: straighter, narrower, nastier
  for (let k = 0; k < n; k++) {
    if (!planCut[k]) continue
    const a = nodes[k]
    const b = nodes[(k + 1) % n]
    const dx = b[0] - a[0], dz = b[1] - a[1]
    const L = Math.hypot(dx, dz) || 1
    const s1 = (rnd() - 0.5) * 0.12 * L
    const s2 = (rnd() - 0.5) * 0.12 * L
    const c = [a, [a[0] + dx * 0.34 - (dz / L) * s1, a[1] + dz * 0.34 + (dx / L) * s1], [a[0] + dx * 0.68 - (dz / L) * s2, a[1] + dz * 0.68 + (dx / L) * s2], b]
    const pts = resample(catmull(c, false, 16), 10)
    const len = plen(pts)
    if (len > paths[k].len * 0.93) continue
    paths.push({ id: paths.length, seg: k, kind: 'cut', pts, halfW: cutHalf, len, hidden: rnd() < 0.6 })
    segs[k].push(paths.length - 1)
  }
  // ── gate frames, from the main route's heading
  const gates: Gate[] = nodes.map((p, k) => {
    const prev = paths[(k - 1 + n) % n].pts
    const m = prev.length
    const a = prev[Math.max(0, m - 4)]
    const b = paths[k].pts[Math.min(3, paths[k].pts.length - 1)]
    let nx = b[0] - a[0], nz = b[1] - a[1]
    const l = Math.hypot(nx, nz) || 1
    nx /= l
    nz /= l
    return { x: p[0], z: p[1], nx, nz, r: 52 }
  })
  const meanSeg = paths.slice(0, n).reduce((s, p) => s + p.len, 0) / n

  // ── the map: bounds, then the canyons carved out of a high plateau
  let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9
  for (const p of paths) for (const q of p.pts) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); z0 = Math.min(z0, q[1]); z1 = Math.max(z1, q[1]) }
  const margin = 300
  const size = Math.max(x1 - x0, z1 - z0) + margin * 2
  const cx = (x0 + x1) / 2
  const cz = (z0 + z1) / 2
  const C = Math.max(9, size / 420)
  const N = Math.ceil(size / C)
  const ox = cx - size / 2
  const oz = cz - size / 2
  const bs = 1 / (Math.max(x1 - x0, z1 - z0) + 40)
  const bounds = { x0: x0 - 20, z0: z0 - 20, sc: bs, ox: (1 - (x1 - x0 + 40) * bs) / 2, oz: (1 - (z1 - z0 + 40) * bs) / 2 }

  const forest = o.planet === 'forest'
  const sm = (t: number) => t * t * (3 - 2 * t)
  const heightAnchors = [100, 30, 68, 22, 64, 100, 36, 78]
  const shortestMain = Math.min(...paths.slice(0, n).map((path) => path.len))
  const relief = clamp(o.forestRelief ?? 1, 0.4, 1.2) * Math.min(1, shortestMain / 450)
  const gateHeights = gates.map((_, i) => {
    const p = (i * heightAnchors.length) / n
    const k = Math.floor(p)
    const f = p - k
    const target = heightAnchors[k % heightAnchors.length] * (1 - f) + heightAnchors[(k + 1) % heightAnchors.length] * f
    return 55 + (target - 55) * relief
  })
  const downhill = Array.from({ length: n }, (_, i) => ({ segment: i, drop: gateHeights[i] - gateHeights[(i + 1) % n] }))
    .filter((item) => item.segment !== 0 && item.drop > 12)
    .sort((a, b) => b.drop - a.drop)
  const rapidSegments = new Set<number>(forest ? [0, ...downhill.slice(0, 1).map((item) => item.segment)] : [])
  const routeHeight = (path: Path, progress: number) => {
    const start = gateHeights[path.seg]
    const end = gateHeights[(path.seg + 1) % n]
    const t = rapidSegments.has(path.seg)
      ? 0.55 * sm(clamp((progress - 0.25) / 0.16, 0, 1)) + 0.45 * sm(clamp((progress - 0.43) / 0.16, 0, 1))
      : sm(progress)
    const rolling = 2.8 * relief * Math.sin(Math.PI * progress) * Math.sin(progress * Math.PI * 2 + path.seg * 1.2)
    return start + (end - start) * t + rolling
  }
  const rapids: ForestRapid[] = Array.from(rapidSegments).map((segment) => {
    const path = paths[segment]
    return {
      pathId: path.id,
      segment,
      startIndex: Math.max(1, Math.floor(path.pts.length * 0.16)),
      endIndex: Math.min(path.pts.length - 2, Math.floor(path.pts.length * 0.7)),
      drop: gateHeights[segment] - gateHeights[(segment + 1) % n],
    }
  })

  const HC = 100
  const hash = new Map<string, number[][]>()
  const addS = (x: number, z: number, hw: number, height = 0) => {
    const k = Math.floor(x / HC) + ',' + Math.floor(z / HC)
    let a = hash.get(k)
    if (!a) hash.set(k, (a = []))
    a.push([x, z, hw, height])
  }
  for (const p of paths) p.pts.forEach((q, i) => addS(q[0], q[1], p.halfW, forest ? routeHeight(p, i / Math.max(1, p.pts.length - 1)) : 0))
  gates.forEach((g, i) => addS(g.x, g.z, 64, forest ? gateHeights[i] : 0))
  const P1 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 420 / C), rnd, 1, P1)
  noiseField(N, Math.max(2, 130 / C), rnd, 0.5, P1)
  const F1 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 60 / C), rnd, 1, F1)
  const W1 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 80 / C), rnd, 1, W1)
  noiseField(N, Math.max(2, 28 / C), rnd, 0.5, W1)
  const hgt = new Float32Array(N * N)
  const lat = new Float32Array(N * N)
  const edge = new Float32Array(N * N)
  const WALL = 74 // the canyon wall climbs in three benches over this distance
  const TERR = 3
  for (let j = 0; j < N; j++) {
    for (let i = 0; i < N; i++) {
      const x = ox + (i + 0.5) * C
      const z = oz + (j + 0.5) * C
      const cxk = Math.floor(x / HC), czk = Math.floor(z / HC)
      let e = 1e9
      let lt = 9
      let weightedHeight = 0
      let totalWeight = 0
      for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) {
        const arr = hash.get(cxk + a + ',' + (czk + b))
        if (!arr) continue
        for (const s of arr) {
          const d0 = Math.hypot(s[0] - x, s[1] - z)
          const d = d0 - s[2]
          if (d < e) { e = d; lt = d0 / s[2] }
          if (forest) {
            const denominator = d0 * d0 + 400
            const weight = 1 / (denominator * denominator)
            weightedHeight += s[3] * weight
            totalWeight += weight
          }
        }
      }
      const idx = j * N + i
      edge[idx] = e > 1e8 ? 1000 : e
      lat[idx] = lt
      const pn = P1[idx] / 1.5
      const floorH = forest ? 8 + 2.4 * clamp(F1[idx] / 1.5, 0, 1) : 8 + 3 * clamp(F1[idx] / 1.5, 0, 1)
      let H: number
      if (forest) {
        // Blend the race route's elevation into the surrounding rolling forest.
        const shoulder = sm(clamp((e + 8) / 150, 0, 1))
        const hills = 6 + pn * 16 + (W1[idx] / 1.5) * 5
        const regional = 42 + pn * 15 + clamp(F1[idx] / 1.5, 0, 1) * 5
        const route = totalWeight > 0 ? weightedHeight / totalWeight : regional
        const routeBlend = 1 - sm(clamp((e - 25) / 110, 0, 1))
        H = regional * (1 - routeBlend) + route * routeBlend + shoulder * hills
      } else {
        const plateau = 66 + pn * 34 + (pn > 0.68 ? 10 : 0)
        H = plateau
        if (e <= 0) H = floorH
        else if (e < WALL + 16) {
          const ej = e - (W1[idx] / 1.5) * 16
          const t = clamp(ej / WALL, 0, 1)
          const ts = t * TERR
          const fl = Math.floor(ts)
          const fr = ts - fl
          const u = sm(clamp((fr - 0.3) / 0.62, 0, 1))
          const tt = Math.min(1, (fl + u) / TERR)
          H = floorH + tt * (plateau - floorH)
        }
      }
      const bd = Math.min(i, j, N - 1 - i, N - 1 - j)
      if (!forest && bd < 8) H = Math.max(H, bd < 3 ? 160 : 130)
      hgt[idx] = H
    }
  }
  // sandstone towers and mesas standing on the upper benches
  if (!forest) {
    const count = Math.round(52 * clamp(size / 2400, 0.6, 1.8))
    let made = 0
    for (let tries = 0; tries < count * 8 && made < count; tries++) {
      const i0 = Math.floor(rnd() * N)
      const j0 = Math.floor(rnd() * N)
      const idx = j0 * N + i0
      if (edge[idx] < 58 || edge[idx] > 170) continue
      if (Math.min(i0, j0, N - 1 - i0, N - 1 - j0) < 12) continue
      made++
      const base = hgt[idx]
      const mesa = rnd() < 0.4
      const r = mesa ? 3.5 + rnd() * 3.5 : 1.5 + rnd() * 1.9
      const tall = mesa ? 14 + rnd() * 16 : 24 + rnd() * 34
      const ri = Math.ceil(r + 1)
      for (let dj = -ri; dj <= ri; dj++) {
        for (let di = -ri; di <= ri; di++) {
          const d = Math.hypot(di, dj) / r
          if (d > 1) continue
          const ci = i0 + di, cj = j0 + dj
          if (ci < 0 || cj < 0 || ci >= N || cj >= N) continue
          const c2 = cj * N + ci
          if (edge[c2] < 40) continue
          const prof = 1 - sm(clamp((d - 0.5) / 0.5, 0, 1))
          hgt[c2] = Math.max(hgt[c2], base + tall * prof * (mesa ? 1 : 1 - d * 0.25))
        }
      }
    }
  }
  // round everything off outside the road, so rock reads as rock and not as steps
  for (let pass = 0; pass < 2; pass++) {
    const c = hgt.slice()
    for (let j = 1; j < N - 1; j++) {
      for (let i = 1; i < N - 1; i++) {
        const k = j * N + i
        if (edge[k] <= 2) continue
        hgt[k] = (4 * c[k] + 2 * (c[k - 1] + c[k + 1] + c[k - N] + c[k + N]) + c[k - N - 1] + c[k - N + 1] + c[k + N - 1] + c[k + N + 1]) / 16
      }
    }
  }
  const cellAt = (x: number, z: number) => {
    const i = Math.floor((x - ox) / C)
    const j = Math.floor((z - oz) / C)
    return i >= 0 && j >= 0 && i < N && j < N ? j * N + i : -1
  }
  // ramps: a gentle wedge, then a jump
  const ramps: number[][] = []
  const addRamp = (p: Path, f: number) => {
    const i = clamp(Math.floor(p.pts.length * f), 3, p.pts.length - 4)
    const a = p.pts[i - 1], b = p.pts[i + 1], m = p.pts[i]
    let tx = b[0] - a[0], tz = b[1] - a[1]
    const l = Math.hypot(tx, tz) || 1
    tx /= l; tz /= l
    const c0 = cellAt(m[0], m[1])
    if (c0 < 0) return
    const base = hgt[c0]
    const STEPS = 7
    for (let k = 0; k < STEPS; k++) {
      for (let lt = -3; lt <= 3; lt++) {
        const c = cellAt(m[0] + tx * k * C * 0.95 - tz * lt * C * 0.9, m[1] + tz * k * C * 0.95 + tx * lt * C * 0.9)
        if (c < 0) continue
        const taper = 1 - Math.pow(Math.abs(lt) / 4, 2)
        hgt[c] = Math.max(hgt[c], base + 5 * ((k + 1) / STEPS) * taper)
      }
    }
    ramps.push([m[0], m[1]])
  }
  for (const p of paths) {
    if (forest && rapidSegments.has(p.seg)) continue
    if (p.kind === 'cut') addRamp(p, 0.42 + rnd() * 0.2)
    else if (rnd() < 0.3) addRamp(p, 0.3 + rnd() * 0.4)
  }

  // ── hazards
  const obstacles: Obstacle[] = []
  const hz = clamp(o.hazards, 0, 1.5)
  const mk = (t: Obstacle['type'], x: number, z: number, r: number, path: number, extra: Partial<Obstacle> = {}): Obstacle => ({
    id: obstacles.length, type: t, x, z, r, period: 4, phase: rnd(), duty: 0.4, len: 0, w: 0, path, broken: false, ...extra,
  })
  for (const p of paths) {
    const cnt = Math.round((p.len / (p.kind === 'cut' ? 110 : 200)) * hz)
    for (let h = 0; h < cnt; h++) {
      const f = 0.12 + (0.76 * (h + 0.3 + rnd() * 0.4)) / Math.max(1, cnt)
      if (forest && p.kind === 'main' && rapidSegments.has(p.seg) && f > 0.15 && f < 0.74) continue
      const i = clamp(Math.floor(p.pts.length * f), 3, p.pts.length - 4)
      const m = p.pts[i]
      const a = p.pts[i - 1], b = p.pts[i + 1]
      let tx = b[0] - a[0], tz = b[1] - a[1]
      const l = Math.hypot(tx, tz) || 1
      tx /= l; tz /= l
      const px = -tz, pz = tx
      const roll = rnd()
      const cutW = p.kind === 'cut'
      if (roll < (cutW ? 0.3 : 0.34)) {
        const side = rnd() < 0.5 ? -1 : 1
        const off = side * p.halfW * (0.2 + rnd() * 0.35)
        obstacles.push(mk('rock', m[0] + px * off, m[1] + pz * off, 5 + rnd() * 5, p.id))
        if (rnd() < 0.6) obstacles.push(mk('rock', m[0] - px * off * 0.7, m[1] - pz * off * 0.7, 4 + rnd() * 4, p.id))
      } else if (roll < (cutW ? 0.58 : 0.6)) {
        const e = p.halfW - 9
        obstacles.push(mk('roller', m[0], m[1], 7, p.id, { ax: m[0] - px * e, az: m[1] - pz * e, bx: m[0] + px * e, bz: m[1] + pz * e, period: 3 + rnd() * 2.5 }))
      } else if (roll < (cutW ? 0.68 : 0.82)) {
        obstacles.push(mk('fan', m[0], m[1], 3.5, p.id, { len: p.halfW * (cutW ? 1.0 : 1.3), w: (rnd() < 0.5 ? -1 : 1) * (1.0 + rnd() * 0.7), phase: rnd() * 6.28 }))
      } else {
        const off = (rnd() - 0.5) * p.halfW * 1.1
        obstacles.push(mk('geyser', m[0] + px * off, m[1] + pz * off, 10, p.id, { period: 4 + rnd() * 2, duty: 0.35 }))
      }
    }
    // Keep a shortcut's breakable wall clear of the starting area and main route.
    if (p.kind === 'cut' && p.hidden) {
      let best: number[] | null = null
      let bestClearance = 0
      const start = Math.max(3, Math.floor(p.pts.length * 0.2))
      const end = Math.min(p.pts.length - 3, Math.floor(p.pts.length * 0.75))
      for (let i = start; i < end; i++) {
        const point = p.pts[i]
        let clearance = Infinity
        for (const main of paths.slice(0, n)) {
          for (const q of main.pts) clearance = Math.min(clearance, Math.hypot(point[0] - q[0], point[1] - q[1]) - main.halfW)
        }
        if (clearance > bestClearance) { bestClearance = clearance; best = point }
      }
      if (best && bestClearance > p.halfW + 8) obstacles.push(mk('rockwall', best[0], best[1], p.halfW + 3, p.id))
    }
  }
  // boost pads
  const pads: ArenaPad[] = []
  const nPads = Math.max(0, Math.round(o.pads))
  for (let k = 0; k < nPads; k++) {
    const p = paths[Math.floor(rnd() * paths.length)]
    const i = clamp(Math.floor(p.pts.length * (0.2 + rnd() * 0.6)), 3, p.pts.length - 4)
    const m = p.pts[i]
    pads.push({ x: m[0] + (rnd() - 0.5) * p.halfW * 0.8, z: m[1] + (rnd() - 0.5) * p.halfW * 0.8, r: 9 })
  }
  void ramps

  const gcell = (i: number, j: number) => hgt[clamp(j, 0, N - 1) * N + clamp(i, 0, N - 1)]
  const groundAt = (x: number, z: number) => {
    const fx = (x - ox) / C - 0.5
    const fz = (z - oz) / C - 0.5
    const i = Math.floor(fx)
    const j = Math.floor(fz)
    const tx = fx - i
    const tz = fz - j
    return (gcell(i, j) * (1 - tx) + gcell(i + 1, j) * tx) * (1 - tz) + (gcell(i, j + 1) * (1 - tx) + gcell(i + 1, j + 1) * tx) * tz
  }
  return { opts: o, n, cells: N, C, ox, oz, size, hgt, lat, edge, gates, paths, segs, obstacles, pads, rapids, meanSeg, groundAt, bounds }
}

// ───────────────────────────────────────────────────────────────── the race

export class ArenaShip {
  id = 0
  name = ''
  isPlayer = false
  skin: VehicleId = 'racer'
  color = 0
  skill = 0.5
  ai = false
  x = 0
  z = 0
  y = 0
  vy = 0
  vx = 0
  vz = 0
  yaw = 0
  yawV = 0
  driftT = 0
  drifting = false
  v = 0
  vlat = 0
  steerNow = 0
  throttle = 0
  shield = 100
  energy = 0.5
  boostT = 0
  turboOn = false
  wreckT = 0
  invuln = 0
  hitCd = 0
  scrape = 0
  hurtAt = -99
  scrapeSide = 1
  airborne = false
  pitch = 0
  cp = 0
  lap = 0
  dist = 0
  finished = false
  finishTime = 0
  lapStart = 0
  lapTimes: number[] = []
  best = Infinity
  rank = 1
  padsHit = 0
  lastInput: Input = { throttle: 0, brake: 0, steer: 0, abL: 0, abR: 0, turbo: false }
  // AI
  pathId = -1
  pi = 0
  stuck = 0
  mistake = 0
  // unused here, kept so the page can treat both modes alike
  s = 0
  vxl = 0
}

const NAMES = ['Kira', 'Rex', 'Nyx', 'Vega', 'Juno', 'Axel', 'Zed', 'Mako', 'Sora', 'Hiro', 'Luna', 'Dax', 'Rin', 'Kane', 'Ivo', 'Tess']
const HOVER = 1.5

export class ArenaSim {
  arena: Arena
  p: RaceParams
  ships: ArenaShip[] = []
  state: 'demo' | 'countdown' | 'racing' | 'finished' = 'demo'
  time = 0
  clock = 0
  count = 3.99
  events: RaceEvent[] = []
  player!: ArenaShip
  results: ArenaShip[] = []
  private afterFinish = 0
  private gasHeld = 0
  private brokenWalls = new Set<number>()

  constructor(arena: Arena, p: RaceParams) {
    this.arena = arena
    this.p = p
    this.setup('demo')
  }
  setArena(a: Arena) {
    this.arena = a
  }
  top() {
    return CLASS_TOP[clamp(Math.round(this.p.shipClass), 0, 3)]
  }

  topFor(ship: ArenaShip) {
    return this.top() * getVehicleStats(ship.skin).speed
  }

  syncVehicleSelections() {
    for (const ship of this.ships) ship.skin = vehicleForRacer(this.p.skin, this.p.botSkins, ship.id)
  }

  isBroken(o: Obstacle) {
    return this.brokenWalls.has(o.id)
  }

  setup(mode: 'demo' | 'countdown') {
    const A = this.arena
    const count = 1 + clamp(Math.round(this.p.bots), 0, 15)
    this.ships = []
    this.events.length = 0
    this.time = 0
    this.count = 3.99
    this.afterFinish = 0
    this.results = []
    this.gasHeld = 0
    this.brokenWalls.clear()
    const g0 = A.gates[0]
    const px = -g0.nz
    const pz = g0.nx
    for (let i = 0; i < count; i++) {
      const sh = new ArenaShip()
      sh.id = i
      sh.isPlayer = i === 0
      sh.ai = i !== 0 || mode === 'demo'
      sh.name = i === 0 ? 'Kamu' : NAMES[(i * 5 + 3) % NAMES.length]
      sh.color = i
      sh.skill = i === 0 ? 0.7 : clamp(this.p.botSkill + Math.sin(i * 12.9898) * 0.125, 0.05, 1)
      const row = Math.floor(i / 2)
      const col = i % 2 === 0 ? -1 : 1
      const back = 16 + row * 12 + (col > 0 ? 5 : 0)
      const lat = col * 8
      sh.x = g0.x - g0.nx * back + px * lat
      sh.z = g0.z - g0.nz * back + pz * lat
      sh.yaw = Math.atan2(g0.nx, -g0.nz)
      sh.y = A.groundAt(sh.x, sh.z) + HOVER
      sh.shield = this.p.shieldMax
      sh.energy = 0.5
      sh.invuln = 1
      this.ships.push(sh)
    }
    this.player = this.ships[0]
    this.syncVehicleSelections()
    this.state = mode
    this.refreshDist()
  }
  startRace() {
    this.setup('countdown')
  }
  finishedAll() {
    return this.ships.every((s) => s.finished)
  }

  private gateDist(sh: ArenaShip) {
    const A = this.arena
    const g = A.gates[sh.cp % A.n]
    return Math.hypot(g.x - sh.x, g.z - sh.z)
  }
  private refreshDist() {
    const A = this.arena
    for (const sh of this.ships) {
      const d = this.gateDist(sh)
      if (sh.cp === 0) sh.dist = -d
      else {
        const prev = A.gates[(sh.cp - 1) % A.n]
        const nxt = A.gates[sh.cp % A.n]
        const seg = Math.max(60, Math.hypot(nxt.x - prev.x, nxt.z - prev.z))
        sh.dist = (sh.cp - 1) * A.meanSeg + clamp(1 - d / seg, 0, 1) * A.meanSeg
      }
    }
  }
  ranking(): ArenaShip[] {
    const list = this.ships.slice()
    list.sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime
      if (a.finished) return -1
      if (b.finished) return 1
      return b.dist - a.dist
    })
    list.forEach((s, i) => (s.rank = i + 1))
    return list
  }

  // ── hazards as a function of time
  hazard(o: Obstacle, t: number) {
    if (o.type === 'roller') {
      const u = 0.5 + 0.5 * Math.sin((t / o.period) * Math.PI * 2 + o.phase * 6.28)
      return { x: o.ax! + (o.bx! - o.ax!) * u, z: o.az! + (o.bz! - o.az!) * u, active: true, warn: false, u }
    }
    if (o.type === 'geyser') {
      const ph = (t + o.phase * o.period) % o.period
      const on = o.duty * o.period
      return { x: o.x, z: o.z, active: ph < on, warn: ph > o.period - 0.9, u: ph < on ? 1 - ph / on : 0 }
    }
    if (o.type === 'fan') return { x: o.x, z: o.z, active: true, warn: false, u: o.phase + o.w * t }
    return { x: o.x, z: o.z, active: true, warn: false, u: 0 }
  }

  private blockedAt(px: number, pz: number, y: number) {
    const A = this.arena
    const R = 3.4
    const lim = y + 5
    return A.groundAt(px, pz) > lim || A.groundAt(px + R, pz) > lim || A.groundAt(px - R, pz) > lim || A.groundAt(px, pz + R) > lim || A.groundAt(px, pz - R) > lim
  }

  private hurt(sh: ArenaShip, dmg: number) {
    if (sh.invuln > 0 || sh.wreckT > 0) return
    sh.shield -= dmg * getVehicleStats(sh.skin).damage
    sh.hurtAt = this.clock
  }

  // ── AI pilot
  private choosePath(b: ArenaShip) {
    const A = this.arena
    const g = b.cp % A.n
    const seg = (g - 1 + A.n) % A.n
    const opts = A.segs[seg]
    let pick = opts[0]
    for (let k = 1; k < opts.length; k++) {
      const p = A.paths[opts[k]]
      const bold = b.skill * 0.9 - 0.28 + (this.time % 7) * 0
      const can = !p.hidden || (b.skill > 0.5 && this.p.botSkill > 0.4)
      if (can && Math.sin(b.id * 91.7 + b.cp * 17.3) * 0.5 + 0.5 < bold) pick = opts[k]
    }
    b.pathId = pick
    b.pi = 0
  }

  private aiInput(b: ArenaShip, dt: number): Input {
    const A = this.arena
    const p = this.p
    const top = this.topFor(b) * (0.88 + 0.12 * b.skill) * (b.isPlayer ? 1 : 0.985)
    let rub = 1
    if (p.rubber > 0 && !b.isPlayer && this.state === 'racing') rub = 1 + p.rubber * 0.09 * clamp((this.player.dist - b.dist) / 500, -1, 1)
    const vTop = top * rub
    const g = A.gates[b.cp % A.n]
    // follow the chosen route
    let tx = g.x
    let tz = g.z
    let turn = 0
    let kappa = 0
    let route: Path | null = null
    if (b.cp > 0) {
      if (b.pathId < 0 || A.paths[b.pathId].seg !== (b.cp % A.n - 1 + A.n) % A.n) this.choosePath(b)
      route = A.paths[b.pathId]
    }
    if (route) {
      const pts = route.pts
      let best = b.pi
      let bd = 1e9
      for (let i = b.pi; i < Math.min(pts.length, b.pi + 25); i++) {
        const d = Math.hypot(pts[i][0] - b.x, pts[i][1] - b.z)
        if (d < bd) { bd = d; best = i }
      }
      b.pi = best
      const look = clamp(Math.round((b.v * 0.55) / 10), 3, 12)
      const ti = Math.min(pts.length - 1, best + look)
      tx = pts[ti][0]
      tz = pts[ti][1]
      const j1 = Math.min(pts.length - 1, best + 4)
      const j2 = Math.min(pts.length - 1, best + 9)
      const h1 = Math.atan2(pts[j1][0] - pts[best][0], -(pts[j1][1] - pts[best][1]))
      const h2 = Math.atan2(pts[j2][0] - pts[j1][0], -(pts[j2][1] - pts[j1][1]))
      turn = Math.abs(wrapA(h2 - h1))
      kappa = turn / 45
      if (best >= pts.length - 4 || Math.hypot(g.x - b.x, g.z - b.z) < 80) { tx = g.x; tz = g.z }
    }
    const fx = Math.sin(b.yaw), fz = -Math.cos(b.yaw)
    const rx = Math.cos(b.yaw), rz = Math.sin(b.yaw)
    let desired = Math.atan2(tx - b.x, -(tz - b.z))
    let steerAdd = 0
    let slow = 1
    let wantTurbo = false
    // hazards
    for (const o of A.obstacles) {
      if (o.type === 'rockwall' && this.brokenWalls.has(o.id)) continue
      const hzd = this.hazard(o, this.clock)
      const rel0 = hzd.x - b.x
      const rel1 = hzd.z - b.z
      if (Math.abs(rel0) > 90 || Math.abs(rel1) > 90) continue
      const fd = rel0 * fx + rel1 * fz
      const ld = rel0 * rx + rel1 * rz
      const rr = (o.type === 'fan' ? o.len * 0.5 : o.r) + 7
      if (fd > -2 && fd < 40 + b.v * 0.5 && Math.abs(ld) < rr + 3) {
        if (o.type === 'rockwall') {
          if (b.skill > 0.5 && b.energy > 0.3) wantTurbo = true
          else steerAdd += -Math.sign(ld || 1) * 0.8
        } else if (o.type === 'geyser' && !hzd.active && !hzd.warn) {
          /* quiet */
        } else {
          steerAdd += -Math.sign(ld || 1) * clamp((rr - Math.abs(ld)) / rr, 0, 1) * (0.7 + 0.6 * b.skill)
          slow = Math.min(slow, 0.78)
        }
      }
    }
    // walls: three probes
    const probe = (ang: number, dd: number) => {
      const a = b.yaw + ang
      const ahead = A.groundAt(b.x + Math.sin(a) * dd, b.z - Math.cos(a) * dd)
      if (A.opts.planet === 'forest') return ahead > b.y + 4.5 && ahead - A.groundAt(b.x, b.z) > Math.max(8, dd * 0.85)
      return ahead > b.y + 4.5
    }
    const near = b.v * 0.35 + 20
    if (probe(0, near) || probe(0, near * 1.8)) {
      const l = probe(-0.5, near * 1.2)
      const r = probe(0.5, near * 1.2)
      steerAdd += l && !r ? 1 : r && !l ? -1 : b.id % 2 ? 1 : -1
      slow = Math.min(slow, 0.6)
    }
    let err = wrapA(desired - b.yaw)
    b.mistake += (Math.sin(this.time * (1.3 + b.id * 0.17) + b.id) - b.mistake) * 0.05
    const steer = clamp(err * 2.1 + steerAdd + b.mistake * (1 - b.skill) * 0.25, -1, 1)
    let vLimit = vTop
    if (route) {
      const pts = route.pts
      const aLat = 110 + 60 * b.skill + 40 * p.assist
      for (let i = b.pi + 1; i < Math.min(pts.length - 2, b.pi + 32); i++) {
        const d = (i - b.pi) * 10
        const h1 = Math.atan2(pts[i][0] - pts[i - 1][0], -(pts[i][1] - pts[i - 1][1]))
        const h2 = Math.atan2(pts[i + 2][0] - pts[i][0], -(pts[i + 2][1] - pts[i][1]))
        const kk = Math.abs(wrapA(h2 - h1)) / 15
        const vc = Math.sqrt(aLat / Math.max(kk, 1e-4))
        vLimit = Math.min(vLimit, Math.sqrt(vc * vc + 2 * 70 * Math.max(0, d - 15)))
      }
    }
    void kappa
    const vDes = vLimit * slow
    const eV = b.v - vDes
    const throttle = eV < 0 ? 1 : 0.15
    const brake = eV > 8 ? clamp((eV - 8) / 40, 0, 1) : 0
    const turbo = wantTurbo || (b.skill > 0.4 && b.energy > 0.55 && turn < 0.12 && Math.abs(err) < 0.1 && b.v > top * 0.8 && Math.sin(this.time * 0.37 + b.id * 3) > 0.25)
    // stuck? put it back on the route
    if (this.state === 'racing' && b.v < 6 && b.wreckT <= 0) b.stuck += dt
    else b.stuck = 0
    if (b.stuck > 1.6 && route) {
      const q = route.pts[Math.min(route.pts.length - 1, b.pi + 3)]
      const q2 = route.pts[Math.min(route.pts.length - 1, b.pi + 5)]
      b.x = q[0]; b.z = q[1]
      b.yaw = Math.atan2(q2[0] - q[0], -(q2[1] - q[1]))
      b.y = A.groundAt(b.x, b.z) + HOVER
      b.vx = b.vz = 0
      b.invuln = 1.5
      b.stuck = 0
    }
    return { throttle, brake, steer, abL: 0, abR: 0, turbo }
  }

  // ── one ship, one step
  private stepShip(sh: ArenaShip, inp: Input, dt: number) {
    const A = this.arena
    const p = this.p
    if (sh.wreckT > 0) {
      sh.wreckT -= dt
      sh.v = 0
      sh.vx = sh.vz = 0
      sh.yawV = 0
      sh.driftT = 0
      if (sh.wreckT <= 0) {
        // back to the last gate, facing the next
        const gi = (sh.cp - 1 + A.n * 4) % A.n
        const g = sh.cp === 0 ? A.gates[0] : A.gates[gi]
        const nx = A.gates[sh.cp % A.n]
        sh.x = g.x - g.nx * 6
        sh.z = g.z - g.nz * 6
        sh.yaw = Math.atan2(nx.x - sh.x, -(nx.z - sh.z))
        sh.y = A.groundAt(sh.x, sh.z) + HOVER
        sh.vy = 0
        sh.shield = p.shieldMax * 0.6
        sh.invuln = 2.5
        sh.boostT = 0
        sh.pi = 0
      }
      return
    }
    sh.invuln = Math.max(0, sh.invuln - dt)
    // the shield mends itself, slowly, when nothing has hit it for a while
    if (this.clock - sh.hurtAt > 3 && sh.shield < p.shieldMax) sh.shield = Math.min(p.shieldMax, sh.shield + 5 * dt)
    sh.hitCd = Math.max(0, sh.hitCd - dt)
    sh.boostT = Math.max(0, sh.boostT - dt)
    const frozen = this.state === 'countdown'
    const profile = getVehicleStats(sh.skin)
    const top = this.topFor(sh) * (sh.isPlayer || !sh.ai ? 1 : (0.88 + 0.12 * sh.skill) * 0.985)
    const wantTurbo = inp.turbo && sh.energy > 0.001 && !frozen
    sh.turboOn = wantTurbo && sh.v > 15
    if (sh.turboOn && p.turboDrain > 0) sh.energy = clamp(sh.energy - p.turboDrain * profile.turboDrain * dt, 0, 1)
    else if (!sh.turboOn) sh.energy = clamp(sh.energy + p.turboRegen * dt, 0, 1)
    if (p.turboDrain <= 0) sh.energy = 1
    const boosting = sh.turboOn || sh.boostT > 0
    const topNow = top * (sh.boostT > 0 ? 1.3 : 1) * (sh.turboOn ? 1.28 : 1)
    sh.airborne = sh.y > A.groundAt(sh.x, sh.z) + HOVER + 0.8
    const air = sh.airborne
    // heading: a quick, springy yaw, and a drift when you turn hard at speed
    const sf = 1 / (1 + (sh.v / top) * 0.5)
    const sharp = inp.abL > 0 || inp.abR > 0
    const wantDrift = !frozen && !air && sh.v > top * 0.45 && (Math.abs(inp.steer) > 0.55 || sharp)
    sh.drifting = wantDrift
    let yawT = frozen ? 0 : inp.steer * 3.4 * p.steerGain * profile.steering * sf * (wantDrift ? 1.15 : 1) + (inp.abR - inp.abL) * 1.4 * p.airbrake * sf
    if (air) yawT *= 0.35
    sh.yawV += (yawT - sh.yawV) * (1 - Math.exp(-dt * 13))
    const yawRate = sh.yawV
    sh.yaw += yawRate * dt
    if (wantDrift && Math.abs(yawRate) > 0.7) sh.driftT = Math.min(2.4, sh.driftT + dt)
    else if (!wantDrift) {
      if (sh.driftT > 0.55) {
        // coming out of a long drift: a push of speed
        sh.boostT = Math.max(sh.boostT, Math.min(1.5, 0.45 + sh.driftT * 0.5) * (sh.ai ? 0.6 : 1))
        this.events.push({ type: 'drift', id: sh.id, v: sh.driftT })
      }
      sh.driftT = 0
    }
    const fx = Math.sin(sh.yaw), fz = -Math.cos(sh.yaw)
    const rx = Math.cos(sh.yaw), rz = Math.sin(sh.yaw)
    let vf = sh.vx * fx + sh.vz * fz
    let vl = sh.vx * rx + sh.vz * rz
    const gA = A.groundAt(sh.x + fx * 9, sh.z + fz * 9)
    const gB = A.groundAt(sh.x - fx * 9, sh.z - fz * 9)
    const slope = clamp((gA - gB) / 18, -0.7, 0.7)
    const thr = frozen ? 0 : inp.throttle
    const ratio = clamp(vf / topNow, 0, 1.3)
    let a = thr * 92 * p.accelGain * profile.acceleration * (boosting ? 2.3 : 1) * (1 - ratio * ratio)
    if (!air) a -= 9.8 * 0.9 * slope
    if (!thr) a -= 8
    a -= inp.brake * 120
    a -= (inp.abL + inp.abR) * 20 * p.airbrake
    if (vf > topNow) a -= (vf - topNow) * 1.3
    vf = Math.max(0, vf + a * dt)
    const grip = (air ? 0.4 : wantDrift ? 4.8 + 2.4 * p.assist : 9 + 5 * p.assist) * profile.grip
    vl *= Math.exp(-grip * dt)
    sh.v = vf
    sh.vlat = vl
    sh.vx = fx * vf + rx * vl
    sh.vz = fz * vf + rz * vl
    // move, sliding along cliffs
    let nx = sh.x + sh.vx * dt
    let nz = sh.z + sh.vz * dt
    if (A.opts.planet === 'forest') {
      const travelled = Math.hypot(nx - sh.x, nz - sh.z)
      const rise = A.groundAt(nx, nz) - A.groundAt(sh.x, sh.z)
      // A hover bike follows a gradual uphill slope instead of treating it as a wall.
      if (rise > 0 && rise < travelled * 0.9 + 1.5) sh.y = Math.max(sh.y, A.groundAt(nx, nz) + HOVER)
    }
    sh.scrape = Math.max(0, sh.scrape - dt * 6)
    let hitX = false
    let hitZ = false
    if (this.blockedAt(nx, sh.z, sh.y)) { hitX = true; nx = sh.x }
    if (this.blockedAt(sh.x, nz, sh.y)) { hitZ = true; nz = sh.z }
    if (hitX || hitZ) {
      const imp = Math.max(hitX ? Math.abs(sh.vx) : 0, hitZ ? Math.abs(sh.vz) : 0)
      const wx = hitX ? Math.sign(sh.vx) : 0
      const wz = hitZ ? Math.sign(sh.vz) : 0
      const hard = (hitX ? Math.abs(sh.vx) : 0) * Math.abs(fx) + (hitZ ? Math.abs(sh.vz) : 0) * Math.abs(fz)
      if (hitX) sh.vx = -sh.vx * 0.25
      if (hitZ) sh.vz = -sh.vz * 0.25
      if (imp > 8 && hard > 8) {
        const sev = clamp(hard / 45, 0, 1.5)
        this.hurt(sh, (6 + 14 * sev) * p.wallDmg)
        this.events.push({ type: 'wall', id: sh.id, v: sev, side: Math.sign(wx * rx + wz * rz) || 1 })
      }
      sh.scrape = 1
      sh.scrapeSide = Math.sign(wx * rx + wz * rz) || 1
      sh.vx *= 1 - 0.6 * dt
      sh.vz *= 1 - 0.6 * dt
      if (sh.invuln <= 0) sh.shield -= 1.2 * p.wallDmg * profile.damage * dt * (Math.hypot(sh.vx, sh.vz) / 80)
    }
    sh.x = nx
    sh.z = nz
    // height: hover over the ground, fly off edges and ramps
    const gC = A.groundAt(sh.x, sh.z)
    const target = gC + HOVER + clamp(sh.v / top, 0, 1.3) * 0.5
    if (sh.y > target + 0.8) sh.vy -= 36 * dt
    else {
      sh.vy += ((target - sh.y) * 80 - sh.vy * 13) * dt
      sh.vy = clamp(sh.vy, -40, 21)
    }
    sh.y += sh.vy * dt
    if (sh.y < gC + 0.4) {
      if (sh.vy < -16 && sh.invuln <= 0) this.hurt(sh, 3 * p.wallDmg)
      if (sh.vy < -14) this.events.push({ type: 'bump', id: sh.id, v: clamp(-sh.vy / 40, 0.2, 1) })
      sh.y = gC + 0.4
      sh.vy = Math.max(0, sh.vy)
    }
    sh.pitch += (Math.atan2(sh.vy, Math.max(30, sh.v)) * 0.9 + slope * 0.4 - sh.pitch) * (1 - Math.exp(-dt * 6))
    sh.steerNow += (inp.steer - sh.steerNow) * (1 - Math.exp(-dt * 8))
    sh.throttle = thr
    // pads
    for (const pad of A.pads) {
      if (Math.hypot(sh.x - pad.x, sh.z - pad.z) < pad.r && !air && sh.boostT < 0.9) {
        sh.boostT = 1.7
        sh.v = Math.max(sh.v, Math.min(topNow * 1.1, sh.v + 22 * p.padPower))
        sh.vx = Math.sin(sh.yaw) * sh.v
        sh.vz = -Math.cos(sh.yaw) * sh.v
        sh.energy = clamp(sh.energy + 0.2, 0, 1)
        sh.padsHit++
        this.events.push({ type: 'pad', id: sh.id })
      }
    }
    // hazards
    if (sh.hitCd <= 0) {
      for (const o of A.obstacles) {
        const dx0 = o.x - sh.x
        const far = o.type === 'roller' ? 200 : 60
        if (Math.abs(dx0) > far && o.type !== 'roller') continue
        if (o.type === 'rockwall' && this.brokenWalls.has(o.id)) continue
        const hz = this.hazard(o, this.clock)
        const dx = hz.x - sh.x
        const dz = hz.z - sh.z
        const d = Math.hypot(dx, dz)
        if (d > 80) continue
        const g0 = A.groundAt(hz.x, hz.z)
        let hit = false
        if (o.type === 'rock') hit = d < o.r + 2.8 && sh.y < g0 + 15
        else if (o.type === 'roller') hit = d < o.r + 2.8 && Math.abs(sh.y - (g0 + o.r)) < o.r + 3
        else if (o.type === 'fan') {
          if (d < 3.5 + 2.6 && sh.y < g0 + 12) hit = true
          else if (d < o.len / 2 + 3) {
            const ang = hz.u
            const bx = Math.cos(ang), bz = Math.sin(ang)
            const along = (sh.x - o.x) * bx + (sh.z - o.z) * bz
            const perp = Math.abs(-(sh.x - o.x) * bz + (sh.z - o.z) * bx)
            hit = Math.abs(along) < o.len / 2 && perp < 3.4 && Math.abs(sh.y - (g0 + 4.5)) < 6
          }
        } else if (o.type === 'geyser') {
          if (hz.active && d < o.r && sh.y < g0 + 30) {
            sh.vy = Math.max(sh.vy, 22)
            this.hurt(sh, 5 * p.wallDmg)
            sh.hitCd = 0.8
            this.events.push({ type: 'wall', id: sh.id, v: 0.4, side: 1 })
          }
          continue
        } else if (o.type === 'rockwall') {
          if (d < o.r + 3 && sh.y < g0 + 20) {
            if (sh.v > 98 || sh.turboOn) {
              this.brokenWalls.add(o.id)
              this.hurt(sh, 7 * p.wallDmg)
              sh.v *= 0.85
              sh.vx *= 0.85
              sh.vz *= 0.85
              sh.hitCd = 0.4
              this.events.push({ type: 'smash', id: o.id })
              continue
            }
            hit = true
          }
        }
        if (hit) {
          const nrm = d > 0.01 ? [-dx / d, -dz / d] : [-Math.sin(sh.yaw), Math.cos(sh.yaw)]
          const sp = Math.max(30, sh.v)
          sh.vx = nrm[0] * sp * 0.55
          sh.vz = nrm[1] * sp * 0.55
          sh.x += nrm[0] * 2.5
          sh.z += nrm[1] * 2.5
          sh.vy = Math.max(sh.vy, 6)
          this.hurt(sh, (12 + sp / 12) * p.wallDmg)
          sh.hitCd = 0.55
          this.events.push({ type: 'wall', id: sh.id, v: 1, side: Math.sign(nrm[0] * rx + nrm[1] * rz) || 1 })
          break
        }
      }
    }
    // gates
    if (!sh.finished) {
      const gi = sh.cp % A.n
      const g = A.gates[gi]
      const sd = (sh.x - g.x) * g.nx + (sh.z - g.z) * g.nz
      const prev = (sh as any)._sd ?? sd
      ;(sh as any)._sd = sd
      const along = Math.abs(-(sh.x - g.x) * g.nz + (sh.z - g.z) * g.nx)
      if (prev < 0 && sd >= 0 && along < g.r && this.state !== 'countdown') {
        sh.cp++
        ;(sh as any)._sd = undefined
        if (sh.cp === 1) { sh.lap = 1; sh.lapStart = this.time }
        else if ((sh.cp - 1) % A.n === 0) {
          const done = (sh.cp - 1) / A.n
          const lt = this.time - sh.lapStart
          sh.lapTimes.push(lt)
          sh.best = Math.min(sh.best, lt)
          sh.lapStart = this.time
          if (done < p.laps) {
            sh.lap = done + 1
            if (sh.isPlayer) this.events.push({ type: 'lap', id: sh.id, n: done, v: lt })
            if (sh.lap === p.laps && sh.isPlayer && p.laps > 1) this.events.push({ type: 'final', id: sh.id })
          }
        }
        if (sh.cp >= p.laps * A.n + 1) {
          sh.finished = true
          sh.lap = p.laps
          sh.finishTime = this.time
          this.events.push({ type: 'finish', id: sh.id })
          if (sh.isPlayer) sh.ai = true
        }
        sh.pathId = -1
      }
    }
    if (sh.shield <= 0 && sh.wreckT <= 0) {
      sh.wreckT = 2.4
      sh.shield = 0
      this.events.push({ type: 'wreck', id: sh.id })
    }
  }

  /** put the player back at the last gate, facing the next one */
  resetPlayer() {
    const A = this.arena
    const sh = this.player
    if (sh.wreckT > 0 || sh.finished) return
    const g = A.gates[(sh.cp - 1 + A.n * 4) % A.n]
    const nx = A.gates[sh.cp % A.n]
    const from = sh.cp === 0 ? A.gates[0] : g
    sh.x = from.x - from.nx * 6
    sh.z = from.z - from.nz * 6
    sh.yaw = Math.atan2(nx.x - sh.x, -(nx.z - sh.z))
    sh.y = A.groundAt(sh.x, sh.z) + HOVER
    sh.vx = sh.vz = sh.v = sh.vy = 0
    sh.invuln = 1.5
  }

  step(dt: number, player: Input) {
    dt = Math.min(dt, 0.05)
    this.clock += dt
    if (this.state === 'countdown') {
      const before = Math.ceil(this.count)
      this.count -= dt
      if (player.throttle > 0.5) this.gasHeld += dt
      else this.gasHeld = 0
      const after = Math.ceil(this.count)
      if (after !== before && after > 0) this.events.push({ type: 'count', n: after })
      if (this.count <= 0) {
        this.state = 'racing'
        this.time = 0
        this.events.push({ type: 'go' })
        const pl = this.player
        if (this.gasHeld > 0.15 && this.gasHeld < 1.2) {
          pl.boostT = 1.4
          pl.v = 12
          this.events.push({ type: 'turbo' })
        }
        for (const s of this.ships) if (s !== pl) s.v = 6 + s.skill * 8
      }
    } else this.time += dt
    const pin: Input = { ...player }
    if (this.p.autoGas && pin.brake < 0.1) pin.throttle = 1
    for (const sh of this.ships) {
      const inp = sh.ai ? this.aiInput(sh, dt) : pin
      sh.lastInput = inp
      this.stepShip(sh, inp, dt / 2)
      this.stepShip(sh, inp, dt / 2)
    }
    // craft touching craft
    for (let i = 0; i < this.ships.length; i++) {
      const a = this.ships[i]
      if (a.wreckT > 0) continue
      for (let j = i + 1; j < this.ships.length; j++) {
        const b = this.ships[j]
        if (b.wreckT > 0) continue
        const dx = a.x - b.x
        const dz = a.z - b.z
        const d = Math.hypot(dx, dz)
        if (d > 5.2 || d < 0.01 || Math.abs(a.y - b.y) > 4) continue
        const nx = dx / d, nz = dz / d
        const push = (5.2 - d) * 0.5
        a.x += nx * push; a.z += nz * push
        b.x -= nx * push; b.z -= nz * push
        a.vx += nx * 6; a.vz += nz * 6
        b.vx -= nx * 6; b.vz -= nz * 6
        if (a.isPlayer || b.isPlayer) if (Math.random() < 0.2) this.events.push({ type: 'bump', id: a.isPlayer ? a.id : b.id, v: 0.5 })
      }
    }
    // passing the player
    const pl = this.player
    for (const o of this.ships) {
      if (o === pl) continue
      const ds = o.dist - pl.dist
      const prev = (o as any)._pds ?? ds
      if ((prev > 0) !== (ds > 0) && Math.hypot(o.x - pl.x, o.z - pl.z) < 30) this.events.push({ type: 'pass', id: o.id, v: ds > 0 ? 1 : -1, side: Math.sign((o.x - pl.x) * Math.cos(pl.yaw) + (o.z - pl.z) * Math.sin(pl.yaw)) || 1 })
      ;(o as any)._pds = ds
    }
    this.refreshDist()
    this.ranking()
    if (this.state === 'racing' && pl.finished) {
      this.afterFinish += dt
      if (this.finishedAll() || this.afterFinish > 18) {
        this.state = 'finished'
        this.results = this.ranking()
      }
    }
  }
}
