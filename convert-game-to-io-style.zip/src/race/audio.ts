// Synthesised sound for the racer — nothing is downloaded, it is all built with Web Audio.
//
// Built to be soft and never crackly:
//   · the engine is made of pure tones plus a little low, rounded (brown) noise — no white-noise hiss anywhere
//   · every parameter glides, and is updated at ~25 Hz instead of every frame
//   · the music scheduler skips ahead after a stall instead of firing a burst of late notes
//   · the whole mix passes a gentle low-pass and a soft compressor

const midi = (m: number) => 440 * Math.pow(2, (m - 69) / 12)
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v))
const rand = (a = 0, b = 1) => a + Math.random() * (b - a)

// A minor, eight bars: [root, chord tones]
const CHORDS: [number, number[]][] = [
  [45, [57, 60, 64, 69]], // Am
  [41, [53, 57, 60, 65]], // F
  [48, [55, 60, 64, 67]], // C
  [43, [55, 59, 62, 67]], // G
  [45, [57, 60, 64, 69]], // Am
  [41, [53, 57, 60, 65]], // F
  [43, [55, 59, 62, 67]], // G
  [40, [55, 59, 64, 67]], // Em
]
const BASS_PAT = [1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1]
const ARP = [0, 2, 1, 3, 2, 3, 1, 2, 0, 2, 1, 3, 3, 2, 1, 2]
const LEAD = [3, -1, 2, -1, 1, 2, -1, -1, 3, -1, 2, 1, 0, -1, -1, -1]

export type LiveState = {
  playing: boolean
  state: string
  speedRatio: number
  boost: number
  throttle: number
  scrape: number
  wrecked: boolean
  shield01: number
  rank: number
  pace: number
}

class RaceAudio {
  ctx: AudioContext | null = null
  private master!: GainNode
  private musicBus!: GainNode
  private sfxBus!: GainNode
  private revIn!: GainNode
  private delayIn!: GainNode
  private brown!: AudioBuffer
  private white!: AudioBuffer
  private vol = { master: 0.8, music: 0.55, sfx: 0.9 }
  private muted = false

  private timer = 0
  private nextT = 0
  private step = 0
  intensity = 0.2
  private lastBeep = 0
  private lastBoost = 0
  private lastUpd = -1
  private eng: any = null

  /** `external` lets a test hand in its own (offline) context */
  init(external?: any) {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume()
      return
    }
    let ctx: AudioContext
    if (external) ctx = external
    else {
      const AC: typeof AudioContext | undefined = window.AudioContext || (window as any).webkitAudioContext
      if (!AC) return
      // 'playback' asks for a bigger buffer: a little more latency, far fewer glitches
      ctx = new AC({ latencyHint: 'playback' })
    }
    this.ctx = ctx
    this.master = ctx.createGain()
    // everything passes a gentle low-pass (no harsh top end) and a soft compressor
    const tone = ctx.createBiquadFilter()
    tone.type = 'lowpass'
    tone.frequency.value = 9500
    tone.Q.value = 0.5
    const comp = ctx.createDynamicsCompressor()
    comp.threshold.value = -12
    comp.knee.value = 26
    comp.ratio.value = 3
    comp.attack.value = 0.012
    comp.release.value = 0.3
    this.master.connect(tone)
    tone.connect(comp)
    comp.connect(ctx.destination)
    this.musicBus = ctx.createGain()
    this.sfxBus = ctx.createGain()
    this.musicBus.connect(this.master)
    this.sfxBus.connect(this.master)

    // reverb
    const conv = ctx.createConvolver()
    const len = Math.floor(ctx.sampleRate * 2.0)
    const ir = ctx.createBuffer(2, len, ctx.sampleRate)
    for (let c = 0; c < 2; c++) {
      const d = ir.getChannelData(c)
      let lp = 0
      for (let i = 0; i < len; i++) {
        lp += (Math.random() * 2 - 1 - lp) * 0.4
        d[i] = lp * Math.pow(1 - i / len, 2.6)
      }
    }
    conv.buffer = ir
    this.revIn = ctx.createGain()
    const revOut = ctx.createGain()
    revOut.gain.value = 0.5
    this.revIn.connect(conv)
    conv.connect(revOut)
    revOut.connect(this.master)

    // delay for the arpeggio
    const dl = ctx.createDelay(1)
    dl.delayTime.value = 0.32
    const fb = ctx.createGain()
    fb.gain.value = 0.34
    const dlp = ctx.createBiquadFilter()
    dlp.type = 'lowpass'
    dlp.frequency.value = 2200
    this.delayIn = ctx.createGain()
    this.delayIn.connect(dl)
    dl.connect(dlp)
    dlp.connect(fb)
    fb.connect(dl)
    dlp.connect(this.musicBus)

    // soft, rounded noise for everything that needs noise; white noise only for the odd hi-hat
    const sr = ctx.sampleRate
    {
      const N = Math.floor(sr * 4)
      const F = Math.floor(sr * 0.25)
      const x = new Float32Array(N + F)
      let last = 0
      let peak = 0
      for (let i = 0; i < x.length; i++) {
        last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02
        x[i] = last
        peak = Math.max(peak, Math.abs(last))
      }
      this.brown = ctx.createBuffer(1, N, sr)
      const d = this.brown.getChannelData(0)
      for (let i = 0; i < N; i++) {
        // the first quarter second fades in from the tail, so the loop has no seam
        const v = i < F ? x[i] * (i / F) + x[N + i] * (1 - i / F) : x[i]
        d[i] = (v / peak) * 0.9
      }
    }
    this.white = ctx.createBuffer(1, Math.floor(sr * 2), sr)
    {
      const d = this.white.getChannelData(0)
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1
    }

    this.applyVolumes()
    this.startEngine()
    this.nextT = ctx.currentTime + 0.15
    if (!external) {
      this.timer = window.setInterval(() => this.scheduler(), 40)
      document.addEventListener('visibilitychange', () => {
        if (!this.ctx) return
        if (document.hidden) void this.ctx.suspend()
        else void this.ctx.resume()
      })
    }
  }

  setVolumes(master: number, music: number, sfx: number, muted: boolean) {
    this.vol = { master, music, sfx }
    this.muted = muted
    this.applyVolumes()
  }
  private applyVolumes() {
    if (!this.ctx) return
    const t = this.ctx.currentTime
    this.master.gain.setTargetAtTime(this.muted ? 0 : this.vol.master, t, 0.05)
    this.musicBus.gain.setTargetAtTime(this.vol.music * 0.62, t, 0.05)
    this.sfxBus.gain.setTargetAtTime(this.vol.sfx, t, 0.05)
  }

  // ── building blocks
  private noise(t: number, dur: number, white = false) {
    const src = this.ctx!.createBufferSource()
    const buf = white ? this.white : this.brown
    src.buffer = buf
    src.start(t, rand(0, Math.max(0, buf.duration - dur - 0.2)), dur + 0.05)
    return src
  }
  private chain(pan: number, send: number) {
    const ctx = this.ctx!
    const input = ctx.createGain()
    let out: AudioNode = input
    if (ctx.createStereoPanner) {
      const p = ctx.createStereoPanner()
      p.pan.value = clamp(pan, -1, 1)
      input.connect(p)
      out = p
    }
    out.connect(this.sfxBus)
    if (send > 0) {
      const s = ctx.createGain()
      s.gain.value = send
      out.connect(s)
      s.connect(this.revIn)
    }
    return input
  }
  private env(g: AudioParam, t: number, a: number, peak: number, d: number) {
    g.setValueAtTime(0.0001, t)
    g.linearRampToValueAtTime(peak, t + Math.max(0.004, a))
    g.exponentialRampToValueAtTime(0.0001, t + Math.max(0.004, a) + d)
  }
  private tone(dst: AudioNode, type: OscillatorType, f0: number, f1: number, t: number, a: number, peak: number, d: number) {
    const ctx = this.ctx!
    const o = ctx.createOscillator()
    o.type = type
    o.frequency.setValueAtTime(f0, t)
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(10, f1), t + a + d)
    const g = ctx.createGain()
    this.env(g.gain, t, a, peak, d)
    o.connect(g)
    g.connect(dst)
    o.start(t)
    o.stop(t + a + d + 0.05)
  }
  private filt(type: BiquadFilterType, f0: number, f1: number, t: number, dur: number, q = 1) {
    const f = this.ctx!.createBiquadFilter()
    f.type = type
    f.Q.value = q
    f.frequency.setValueAtTime(f0, t)
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur)
    return f
  }
  private live() {
    return !!this.ctx && this.ctx.state === 'running' && !this.muted
  }
  private bell(dst: AudioNode, m: number, t: number, peak = 0.2, dur = 0.8) {
    const ctx = this.ctx!
    const f = midi(m)
    const car = ctx.createOscillator()
    const mod = ctx.createOscillator()
    const mg = ctx.createGain()
    car.frequency.value = f
    mod.frequency.value = f * 2.01
    mg.gain.setValueAtTime(f * 0.9, t)
    mg.gain.exponentialRampToValueAtTime(1, t + dur * 0.6)
    mod.connect(mg)
    mg.connect(car.frequency)
    const g = ctx.createGain()
    this.env(g.gain, t, 0.006, peak, dur)
    car.connect(g)
    g.connect(dst)
    car.start(t)
    mod.start(t)
    car.stop(t + dur + 0.1)
    mod.stop(t + dur + 0.1)
  }
  /** a soft swell of rounded noise */
  private swell(dst: AudioNode, t: number, f0: number, f1: number, peak: number, rise: number, fall: number, q = 0.5) {
    const ctx = this.ctx!
    const n = this.noise(t, rise + fall)
    const bp = this.filt('bandpass', f0, f1, t, rise + fall, q)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.linearRampToValueAtTime(peak, t + rise)
    g.gain.exponentialRampToValueAtTime(0.0001, t + rise + fall)
    n.connect(bp)
    bp.connect(g)
    g.connect(dst)
  }

  // ── sound effects
  count(n: number) {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.25)
    this.tone(c, 'triangle', 440, 440, t, 0.01, 0.14, 0.22)
    this.tone(c, 'sine', 880, 880, t, 0.01, 0.12, 0.24)
    void n
  }
  go() {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.4)
    for (const m of [69, 76, 81]) this.tone(c, 'triangle', midi(m), midi(m), t, 0.01, 0.1, 0.8)
    for (const m of [81, 88]) this.tone(c, 'sine', midi(m), midi(m), t, 0.01, 0.12, 1.0)
    this.swell(c, t, 200, 1600, 0.42, 0.22, 0.9)
    this.tone(c, 'sine', 90, 44, t, 0.02, 0.5, 0.6)
  }
  /** boost pad: a smooth rising sweep */
  pad() {
    if (!this.live()) return
    const ctx = this.ctx!
    const t = ctx.currentTime
    const c = this.chain(0, 0.35)
    const o = ctx.createOscillator()
    o.type = 'triangle'
    o.frequency.setValueAtTime(150, t)
    o.frequency.exponentialRampToValueAtTime(1000, t + 0.5)
    const lp = this.filt('lowpass', 500, 3200, t, 0.5, 0.6)
    const g = ctx.createGain()
    this.env(g.gain, t, 0.04, 0.22, 0.5)
    o.connect(lp)
    lp.connect(g)
    g.connect(c)
    o.start(t)
    o.stop(t + 0.7)
    this.swell(c, t, 260, 1500, 0.4, 0.2, 0.55)
    this.tone(c, 'sine', 84, 42, t, 0.02, 0.5, 0.35)
    this.bell(c, 88, t + 0.1, 0.07, 0.5)
  }
  /** brushing or hitting rock: a dull thump and a rounded rumble, never a crackle */
  impact(sev: number, side: number) {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const k = clamp(0.4 + sev * 0.6, 0.3, 1.3)
    const c = this.chain(-side * 0.7, 0.22)
    this.tone(c, 'sine', 120, 42, t, 0.004, 0.85 * k, 0.26)
    this.swell(c, t, 900, 260, 0.5 * k, 0.012, 0.34, 0.7)
    this.tone(c, 'triangle', 190, 90, t, 0.004, 0.12 * k, 0.14)
  }
  bump(v: number) {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(rand(-0.4, 0.4), 0.1)
    this.tone(c, 'sine', 150, 60, t, 0.004, 0.5 * clamp(v, 0.3, 1), 0.16)
    this.swell(c, t, 700, 300, 0.22, 0.01, 0.12, 0.8)
  }
  explosion(dist: number, side: number) {
    if (!this.live()) return
    const ctx = this.ctx!
    const t = ctx.currentTime
    const att = 1 / (1 + dist / 120)
    const c = this.chain(side * 0.6, 0.5)
    const n = this.noise(t, 1.8)
    const lp = this.filt('lowpass', 2200 * Math.max(0.35, att), 70, t, 1.6, 0.6)
    const g = ctx.createGain()
    this.env(g.gain, t, 0.01, 0.95 * (0.3 + 0.7 * att), 1.6)
    n.connect(lp)
    lp.connect(g)
    g.connect(c)
    this.tone(c, 'sine', 92, 26, t, 0.01, 1.0 * att, 1.4)
    this.tone(c, 'triangle', 170, 50, t, 0.006, 0.4 * att, 0.5)
    for (let i = 0; i < 3; i++) this.swell(c, t + 0.1 + i * rand(0.12, 0.25), rand(160, 420), 120, rand(0.14, 0.28) * att, 0.02, 0.3, 0.8)
  }
  lap() {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.5)
    this.bell(c, 76, t, 0.22, 0.8)
    this.bell(c, 81, t + 0.11, 0.22, 0.9)
    this.bell(c, 88, t + 0.22, 0.2, 1.1)
  }
  finalLap() {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.5)
    ;[69, 72, 76, 81, 84].forEach((m, i) => {
      this.tone(c, 'triangle', midi(m), midi(m), t + i * 0.09, 0.006, 0.09, 0.28)
      this.bell(c, m + 12, t + i * 0.09, 0.12, 0.6)
    })
  }
  finish(rank: number) {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.65)
    const notes = rank === 1 ? [72, 76, 79, 84, 88, 91] : rank <= 3 ? [69, 72, 76, 81] : [64, 67, 71]
    notes.forEach((m, i) => {
      this.bell(c, m, t + i * 0.12, 0.22, 1.6)
      this.tone(c, 'triangle', midi(m - 12), midi(m - 12), t + i * 0.12, 0.02, 0.06, 0.9)
    })
  }
  /** another craft sliding past: a soft pass of air */
  whoosh(side: number) {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(side * 0.8, 0.15)
    this.swell(c, t, 1500, 360, 0.4, 0.14, 0.5, 0.6)
    this.tone(c, 'triangle', 420, 170, t, 0.04, 0.05, 0.4)
  }
  repair() {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(-0.5, 0.2)
    this.tone(c, 'triangle', 880, 1320, t, 0.006, 0.07, 0.12)
  }
  ui(kind: 'start' | 'click' | 'back') {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.4)
    if (kind === 'click') return this.tone(c, 'triangle', 700, 900, t, 0.004, 0.12, 0.07)
    if (kind === 'back') return this.tone(c, 'triangle', 600, 400, t, 0.004, 0.12, 0.1)
    ;[57, 64, 69, 76].forEach((m, i) => this.tone(c, 'triangle', midi(m), midi(m), t + i * 0.07, 0.008, 0.18, 0.5))
    this.swell(c, t, 200, 1800, 0.28, 0.3, 0.45)
  }

  // ── the hover engine: warm tones and a breath of low noise
  private startEngine() {
    const ctx = this.ctx!
    const bus = ctx.createGain()
    bus.gain.value = 0
    const soften = ctx.createBiquadFilter()
    soften.type = 'lowpass'
    soften.frequency.value = 1200
    soften.Q.value = 0.3
    bus.connect(soften)
    soften.connect(this.sfxBus)
    const loop = () => {
      const s = ctx.createBufferSource()
      s.buffer = this.brown
      s.loop = true
      s.start(0, rand(0, 3))
      return s
    }
    const osc = (type: OscillatorType, gain: number, dst: AudioNode) => {
      const o = ctx.createOscillator()
      o.type = type
      const g = ctx.createGain()
      g.gain.value = gain
      o.connect(g)
      g.connect(dst)
      o.start()
      return { o, g }
    }
    // the hum: a fundamental, a slightly detuned twin (a slow, soft beat), a quiet octave and a sub
    const humLp = ctx.createBiquadFilter()
    humLp.type = 'lowpass'
    humLp.frequency.value = 650
    humLp.Q.value = 0.4
    humLp.connect(bus)
    const f1 = osc('sine', 0.34, humLp)
    const f2 = osc('sine', 0.2, humLp)
    const h2 = osc('triangle', 0.1, humLp)
    const sub = osc('sine', 0.3, bus)
    // a faint turbine whistle
    const whLp = ctx.createBiquadFilter()
    whLp.type = 'lowpass'
    whLp.frequency.value = 1500
    whLp.connect(bus)
    const wh = osc('sine', 0.0, whLp)
    // air: rounded noise, never a hiss
    const airBp = ctx.createBiquadFilter()
    airBp.type = 'bandpass'
    airBp.Q.value = 0.5
    airBp.frequency.value = 400
    const airG = ctx.createGain()
    airG.gain.value = 0
    const air = loop()
    air.connect(airBp)
    airBp.connect(airG)
    airG.connect(bus)
    // the swell under the afterburner
    const swLp = ctx.createBiquadFilter()
    swLp.type = 'lowpass'
    swLp.frequency.value = 700
    const swG = ctx.createGain()
    swG.gain.value = 0
    const sw = loop()
    sw.connect(swLp)
    swLp.connect(swG)
    swG.connect(bus)
    // grinding along rock: a low rounded rumble
    const scBp = ctx.createBiquadFilter()
    scBp.type = 'bandpass'
    scBp.frequency.value = 300
    scBp.Q.value = 0.8
    const scG = ctx.createGain()
    scG.gain.value = 0
    const sc = loop()
    sc.connect(scBp)
    scBp.connect(scG)
    scG.connect(this.sfxBus)
    this.eng = { bus, f1, f2, h2, sub, wh, airBp, airG, swLp, swG, scG, soften }
  }

  /** called every frame; it only touches the audio graph about 25 times a second */
  update(s: LiveState) {
    const ctx = this.ctx
    if (!ctx || ctx.state !== 'running') return
    const t = ctx.currentTime
    if (t - this.lastUpd < 0.04) return
    this.lastUpd = t
    const e = this.eng
    const sp = clamp(s.speedRatio, 0, 1.3)
    const b = s.boost
    const level = s.wrecked ? 0.05 : s.playing ? 1 : 0.2
    const thr = 0.5 + 0.5 * s.throttle
    const T = 0.22 // everything glides
    const f = 60 + 150 * sp + 80 * b
    e.bus.gain.setTargetAtTime(0.3 * level, t, 0.25)
    e.f1.o.frequency.setTargetAtTime(f, t, T)
    e.f2.o.frequency.setTargetAtTime(f * 1.006, t, T)
    e.h2.o.frequency.setTargetAtTime(f * 2, t, T)
    e.h2.g.gain.setTargetAtTime(0.05 + 0.1 * sp * thr, t, T)
    e.sub.o.frequency.setTargetAtTime(f * 0.5, t, T)
    e.wh.o.frequency.setTargetAtTime(f * 3.2, t, T)
    e.wh.g.gain.setTargetAtTime((0.004 + 0.008 * sp + 0.01 * b) * thr, t, T)
    e.airBp.frequency.setTargetAtTime(260 + 480 * sp + 380 * b, t, T)
    e.airG.gain.setTargetAtTime((0.05 + 0.13 * sp + 0.1 * b) * thr, t, T)
    e.swLp.frequency.setTargetAtTime(500 + 500 * b, t, T)
    e.swG.gain.setTargetAtTime(0.2 * b, t, 0.3)
    e.scG.gain.setTargetAtTime(s.playing ? 0.1 * s.scrape : 0, t, 0.06)
    if (b > 0.5 && this.lastBoost <= 0.5 && s.playing) this.boostBlast()
    this.lastBoost = b
    // shield warning: a soft double beep
    if (s.playing && !s.wrecked && s.shield01 < 0.25 && t - this.lastBeep > 0.6) {
      this.lastBeep = t
      const c = this.chain(0, 0.1)
      this.tone(c, 'sine', 880, 880, t, 0.01, 0.06, 0.1)
      this.tone(c, 'sine', 880, 880, t + 0.16, 0.01, 0.06, 0.1)
    }
    const target =
      s.state === 'demo' ? 0.32 : s.state === 'countdown' ? 0.4 : s.state === 'finished' ? 0.25 : clamp(0.42 + 0.5 * s.pace + b * 0.12, 0, 1)
    this.intensity += (target - this.intensity) * 0.05
  }

  private boostBlast() {
    if (!this.live()) return
    const t = this.ctx!.currentTime
    const c = this.chain(0, 0.3)
    this.swell(c, t, 260, 1600, 0.26, 0.3, 0.9, 0.5)
    this.tone(c, 'sine', 70, 40, t, 0.05, 0.4, 0.7)
  }

  // ── music
  private scheduler() {
    void this.timer
    const ctx = this.ctx
    if (!ctx || ctx.state !== 'running') {
      if (ctx) this.nextT = Math.max(this.nextT, ctx.currentTime + 0.1)
      return
    }
    const now = ctx.currentTime
    const stepDur = () => 60 / (108 + 26 * this.intensity) / 4
    if (this.nextT < now - 0.05) {
      // the page stalled: skip the steps that were missed instead of playing them all at once
      const missed = Math.ceil((now + 0.05 - this.nextT) / stepDur())
      this.step += missed
      this.nextT += missed * stepDur()
    }
    let guard = 0
    while (this.nextT < now + 0.25 && guard++ < 6) {
      this.playStep(this.step, this.nextT)
      this.nextT += stepDur()
      this.step++
    }
  }

  private padChord(tones: number[], t: number, dur: number) {
    const ctx = this.ctx!
    const lp = this.filt('lowpass', 450, 450, t, dur, 0.5)
    lp.frequency.setValueAtTime(450, t)
    lp.frequency.linearRampToValueAtTime(1300, t + dur * 0.7)
    lp.frequency.linearRampToValueAtTime(650, t + dur + 1)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.linearRampToValueAtTime(1, t + 1.0)
    g.gain.setValueAtTime(1, t + dur - 0.1)
    g.gain.linearRampToValueAtTime(0.0001, t + dur + 1.4)
    lp.connect(g)
    g.connect(this.musicBus)
    const send = ctx.createGain()
    send.gain.value = 0.5
    g.connect(send)
    send.connect(this.revIn)
    tones.forEach((m) => {
      for (const det of [-8, 8]) {
        const o = ctx.createOscillator()
        o.type = 'sawtooth'
        o.frequency.value = midi(m)
        o.detune.value = det + rand(-2, 2)
        const og = ctx.createGain()
        og.gain.value = 0.022
        o.connect(og)
        og.connect(lp)
        o.start(t)
        o.stop(t + dur + 1.5)
      }
    })
  }

  private pluck(m: number, t: number, vel: number) {
    const ctx = this.ctx!
    const f = midi(m)
    const o = ctx.createOscillator()
    o.type = 'triangle'
    o.frequency.value = f
    const o2 = ctx.createOscillator()
    o2.type = 'sawtooth'
    o2.frequency.value = f
    o2.detune.value = 6
    const lp = this.filt('lowpass', 3000, 500, t, 0.22, 1.0)
    const g = ctx.createGain()
    this.env(g.gain, t, 0.004, vel, 0.26)
    const g2 = ctx.createGain()
    g2.gain.value = 0.22
    o.connect(lp)
    o2.connect(g2)
    g2.connect(lp)
    lp.connect(g)
    g.connect(this.musicBus)
    const s = ctx.createGain()
    s.gain.value = 0.5
    g.connect(s)
    s.connect(this.delayIn)
    const r = ctx.createGain()
    r.gain.value = 0.28
    g.connect(r)
    r.connect(this.revIn)
    o.start(t)
    o2.start(t)
    o.stop(t + 0.4)
    o2.stop(t + 0.4)
  }

  private bass(m: number, t: number, dur: number, peak: number, cut = 520) {
    const ctx = this.ctx!
    const o = ctx.createOscillator()
    o.type = 'triangle'
    o.frequency.value = midi(m)
    const o2 = ctx.createOscillator()
    o2.type = 'sine'
    o2.frequency.value = midi(m - 12)
    const lp = this.filt('lowpass', cut * 1.6, cut * 0.5, t, dur, 1.0)
    const g = ctx.createGain()
    this.env(g.gain, t, 0.008, peak, dur)
    o.connect(lp)
    o2.connect(lp)
    lp.connect(g)
    g.connect(this.musicBus)
    o.start(t)
    o2.start(t)
    o.stop(t + dur + 0.1)
    o2.stop(t + dur + 0.1)
  }

  private drum(kind: 'kick' | 'clap' | 'hat' | 'open', t: number, vel: number) {
    const ctx = this.ctx!
    if (kind === 'kick') {
      const o = ctx.createOscillator()
      o.type = 'sine'
      o.frequency.setValueAtTime(150, t)
      o.frequency.exponentialRampToValueAtTime(44, t + 0.15)
      const g = ctx.createGain()
      this.env(g.gain, t, 0.004, 0.85 * vel, 0.2)
      o.connect(g)
      g.connect(this.musicBus)
      o.start(t)
      o.stop(t + 0.25)
    } else if (kind === 'clap') {
      // a soft snap: rounded noise and a short tone, no sizzle
      const n = this.noise(t, 0.16)
      const bp = this.filt('bandpass', 1200, 1200, t, 0.16, 0.7)
      const g = ctx.createGain()
      this.env(g.gain, t, 0.004, 0.32 * vel, 0.13)
      n.connect(bp)
      bp.connect(g)
      g.connect(this.musicBus)
      const s = ctx.createGain()
      s.gain.value = 0.5
      g.connect(s)
      s.connect(this.revIn)
      const o = ctx.createOscillator()
      o.type = 'triangle'
      o.frequency.setValueAtTime(230, t)
      o.frequency.exponentialRampToValueAtTime(150, t + 0.08)
      const og = ctx.createGain()
      this.env(og.gain, t, 0.003, 0.2 * vel, 0.08)
      o.connect(og)
      og.connect(this.musicBus)
      o.start(t)
      o.stop(t + 0.12)
    } else {
      const dur = kind === 'open' ? 0.16 : 0.04
      const n = this.noise(t, dur, true)
      const bp = this.filt('bandpass', 6500, 6500, t, dur, 0.9)
      const g = ctx.createGain()
      this.env(g.gain, t, 0.002, (kind === 'open' ? 0.05 : 0.045) * vel, dur)
      n.connect(bp)
      bp.connect(g)
      g.connect(this.musicBus)
    }
  }

  private playStep(s: number, t: number) {
    const bar = Math.floor(s / 16) % CHORDS.length
    const i = s % 16
    const [root, tones] = CHORDS[bar]
    const I = this.intensity
    const barDur = (60 / (108 + 26 * I)) * 4
    if (i === 0) this.padChord(tones, t, barDur)

    if (I < 0.3) {
      if (i === 0) this.bass(root, t, barDur * 0.9, 0.24, 340)
    } else if (BASS_PAT[i]) {
      const oct = i === 6 || i === 14 ? 12 : 0
      this.bass(root + oct, t, 0.16, 0.27 + 0.06 * I, 420 + 420 * I)
    }
    const vel = 0.075 - 0.018 * I
    if (I < 0.3) {
      if (i % 4 === 0) this.pluck(tones[ARP[i]] + 12, t, vel)
    } else if (I < 0.62) {
      if (i % 2 === 0) this.pluck(tones[ARP[i]] + (i % 8 === 6 ? 24 : 12), t, vel * rand(0.8, 1.05))
    } else this.pluck(tones[ARP[i]] + (i % 8 === 7 ? 24 : 12), t, vel * rand(0.75, 1.05))
    if (I >= 0.55 && bar % 2 === 1 && LEAD[i] >= 0) this.pluck(tones[LEAD[i]] + 24, t, 0.06)
    if (I >= 0.25) {
      if (i % 4 === 0) this.drum('kick', t, i === 0 ? 1 : 0.85)
      if (I >= 0.4 && (i === 4 || i === 12)) this.drum('clap', t, 1)
      if (i % 4 === 2) this.drum('open', t, 0.5)
      if (I > 0.6 && i % 2 === 1) this.drum('hat', t, 0.55)
      if (I > 0.8 && (i === 7 || i === 15)) this.drum('kick', t, 0.5)
    }
  }
}

export const audio = new RaceAudio()
