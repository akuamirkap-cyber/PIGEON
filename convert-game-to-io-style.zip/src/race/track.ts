// Track data: a closed, banked, hilly ribbon described by evenly spaced samples.
// Pure maths (no three.js), so the race simulation can run anywhere.

export type TrackOpts = { seed: number; radius: number; width: number; hills: number; pads: number }

export type Pad = { s: number; x: number; len: number; w: number }

export type Frame = {
  px: number; py: number; pz: number
  tx: number; ty: number; tz: number
  rx: number; ry: number; rz: number
  ux: number; uy: number; uz: number
  curv: number
  bank: number
}

export type Track = {
  L: number
  N: number
  ds: number
  halfW: number
  opts: TrackOpts
  px: Float32Array; py: Float32Array; pz: Float32Array
  tx: Float32Array; ty: Float32Array; tz: Float32Array
  rx: Float32Array; ry: Float32Array; rz: Float32Array
  ux: Float32Array; uy: Float32Array; uz: Float32Array
  curv: Float32Array
  bank: Float32Array
  pads: Pad[]
  repair: { s0: number; s1: number; side: number }
  minY: number
  maxY: number
  frame: (s: number, out: Frame) => Frame
  curvAt: (s: number) => number
}

function mulberry32(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export const mod = (a: number, n: number) => ((a % n) + n) % n

export function buildTrack(o: TrackOpts): Track {
  const rnd = mulberry32(Math.round(o.seed) * 7919 + 11)
  // ── the centre line: a star-shaped loop (never crosses itself) with hills
  const R = o.radius
  const amps = [0.22, 0.14, 0.08, 0.045].map((a) => a * (0.65 + rnd() * 0.7))
  const phs = amps.map(() => rnd() * Math.PI * 2)
  const hp = [rnd() * 6.28, rnd() * 6.28, rnd() * 6.28]
  const K = 160
  const ctrl: number[][] = []
  for (let k = 0; k < K; k++) {
    const th = (k / K) * Math.PI * 2
    let r = 1
    for (let h = 0; h < amps.length; h++) r += amps[h] * Math.sin((h + 2) * th + phs[h])
    r *= R
    const y = o.hills * (46 * Math.sin(2 * th + hp[0]) + 26 * Math.sin(3 * th + hp[1]) + 12 * Math.sin(5 * th + hp[2]))
    ctrl.push([r * Math.cos(th), y, r * Math.sin(th)])
  }
  // dense Catmull–Rom polyline
  const SUB = 6
  const dense: number[][] = []
  for (let k = 0; k < K; k++) {
    const p0 = ctrl[(k - 1 + K) % K]
    const p1 = ctrl[k]
    const p2 = ctrl[(k + 1) % K]
    const p3 = ctrl[(k + 2) % K]
    for (let j = 0; j < SUB; j++) {
      const t = j / SUB
      const t2 = t * t
      const t3 = t2 * t
      const pt = [0, 0, 0]
      for (let c = 0; c < 3; c++) {
        pt[c] = 0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3)
      }
      dense.push(pt)
    }
  }
  const M = dense.length
  const cum = new Float64Array(M + 1)
  for (let i = 0; i < M; i++) {
    const a = dense[i]
    const b = dense[(i + 1) % M]
    cum[i + 1] = cum[i] + Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2])
  }
  const L0 = cum[M]
  const N = Math.round(L0 / 5)
  const ds = L0 / N
  const L = L0
  const px = new Float32Array(N)
  const py = new Float32Array(N)
  const pz = new Float32Array(N)
  let seg = 0
  for (let i = 0; i < N; i++) {
    const target = i * ds
    while (seg < M - 1 && cum[seg + 1] < target) seg++
    const f = (target - cum[seg]) / Math.max(1e-6, cum[seg + 1] - cum[seg])
    const a = dense[seg]
    const b = dense[(seg + 1) % M]
    px[i] = a[0] + (b[0] - a[0]) * f
    py[i] = a[1] + (b[1] - a[1]) * f
    pz[i] = a[2] + (b[2] - a[2]) * f
  }
  // light smoothing so the road has no kinks
  for (let pass = 0; pass < 3; pass++) {
    for (const arr of [px, py, pz]) {
      const c = Float32Array.from(arr)
      for (let i = 0; i < N; i++) arr[i] = (c[(i - 1 + N) % N] + 2 * c[i] + c[(i + 1) % N]) / 4
    }
  }
  // ── frames
  const tx = new Float32Array(N), ty = new Float32Array(N), tz = new Float32Array(N)
  for (let i = 0; i < N; i++) {
    const a = (i - 1 + N) % N
    const b = (i + 1) % N
    let x = px[b] - px[a]
    let y = py[b] - py[a]
    let z = pz[b] - pz[a]
    const l = Math.hypot(x, y, z) || 1
    x /= l; y /= l; z /= l
    tx[i] = x; ty[i] = y; tz[i] = z
  }
  // flat right (T × up)
  const fx = new Float32Array(N), fz = new Float32Array(N)
  for (let i = 0; i < N; i++) {
    // cross(T, (0,1,0)) = (-tz, 0, tx)
    let x = -tz[i]
    let z = tx[i]
    const l = Math.hypot(x, z) || 1
    fx[i] = x / l
    fz[i] = z / l
  }
  const curvRaw = new Float32Array(N)
  for (let i = 0; i < N; i++) {
    const a = (i - 1 + N) % N
    const b = (i + 1) % N
    const dx = (tx[b] - tx[a]) / (2 * ds)
    const dz = (tz[b] - tz[a]) / (2 * ds)
    curvRaw[i] = dx * fx[i] + dz * fz[i] // > 0: the road bends to the right
  }
  const blur = (src: Float32Array, w: number) => {
    const out = new Float32Array(N)
    for (let i = 0; i < N; i++) {
      let s = 0
      for (let k = -w; k <= w; k++) s += src[(i + k + N * 4) % N]
      out[i] = s / (2 * w + 1)
    }
    return out
  }
  const curv = blur(curvRaw, 3)
  const bankSrc = blur(curvRaw, 14)
  const bank = new Float32Array(N)
  const rx = new Float32Array(N), ry = new Float32Array(N), rz = new Float32Array(N)
  const ux = new Float32Array(N), uy = new Float32Array(N), uz = new Float32Array(N)
  for (let i = 0; i < N; i++) {
    const b = Math.max(-0.5, Math.min(0.5, bankSrc[i] * 150))
    bank[i] = b
    const cb = Math.cos(b)
    const sb = Math.sin(b)
    // right = flat * cos(b) - up * sin(b): the inside of the bend is lower
    let x = fx[i] * cb
    let y = -sb
    let z = fz[i] * cb
    const d = x * tx[i] + y * ty[i] + z * tz[i]
    x -= tx[i] * d; y -= ty[i] * d; z -= tz[i] * d
    const l = Math.hypot(x, y, z) || 1
    x /= l; y /= l; z /= l
    rx[i] = x; ry[i] = y; rz[i] = z
    // up = right × T
    ux[i] = y * tz[i] - z * ty[i]
    uy[i] = z * tx[i] - x * tz[i]
    uz[i] = x * ty[i] - y * tx[i]
  }
  let minY = 1e9
  let maxY = -1e9
  for (let i = 0; i < N; i++) {
    minY = Math.min(minY, py[i])
    maxY = Math.max(maxY, py[i])
  }

  // ── boost pads
  const pads: Pad[] = []
  const nPads = Math.max(0, Math.round(o.pads))
  for (let k = 0; k < nPads; k++) {
    const base = 320 + ((L - 640) * (k + 0.5)) / Math.max(1, nPads)
    const s = base + (rnd() - 0.5) * (L / Math.max(1, nPads)) * 0.4
    const lane = [-0.5, 0, 0.5][Math.floor(rnd() * 3)] * (o.width / 2) * 0.7
    pads.push({ s, x: lane, len: 26, w: 8 })
  }

  const track: Track = {
    L, N, ds, halfW: o.width / 2, opts: o,
    px, py, pz, tx, ty, tz, rx, ry, rz, ux, uy, uz, curv, bank,
    pads, repair: { s0: 40, s1: 300, side: -1 }, minY, maxY,
    frame(s: number, out: Frame) {
      const u = mod(s, L) / ds
      const i0 = Math.floor(u) % N
      const i1 = (i0 + 1) % N
      const f = u - Math.floor(u)
      const g = 1 - f
      out.px = px[i0] * g + px[i1] * f
      out.py = py[i0] * g + py[i1] * f
      out.pz = pz[i0] * g + pz[i1] * f
      let x = tx[i0] * g + tx[i1] * f, y = ty[i0] * g + ty[i1] * f, z = tz[i0] * g + tz[i1] * f
      let l = Math.hypot(x, y, z) || 1
      out.tx = x / l; out.ty = y / l; out.tz = z / l
      x = rx[i0] * g + rx[i1] * f; y = ry[i0] * g + ry[i1] * f; z = rz[i0] * g + rz[i1] * f
      l = Math.hypot(x, y, z) || 1
      out.rx = x / l; out.ry = y / l; out.rz = z / l
      out.ux = out.ry * out.tz - out.rz * out.ty
      out.uy = out.rz * out.tx - out.rx * out.tz
      out.uz = out.rx * out.ty - out.ry * out.tx
      out.curv = curv[i0] * g + curv[i1] * f
      out.bank = bank[i0] * g + bank[i1] * f
      return out
    },
    curvAt(s: number) {
      const u = mod(s, L) / ds
      const i0 = Math.floor(u) % N
      const i1 = (i0 + 1) % N
      const f = u - Math.floor(u)
      return curv[i0] * (1 - f) + curv[i1] * f
    },
  }
  return track
}

export const newFrame = (): Frame => ({
  px: 0, py: 0, pz: 0, tx: 0, ty: 0, tz: -1, rx: 1, ry: 0, rz: 0, ux: 0, uy: 1, uz: 0, curv: 0, bank: 0,
})
