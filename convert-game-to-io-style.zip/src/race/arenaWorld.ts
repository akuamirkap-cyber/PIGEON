// @ts-nocheck
// Draws the arena. The canyon is one smooth surface, shaded in a shader: sandstone layers that undulate along the walls,
// scree at their feet, rippled sand, pools, soft shadows from the cliffs. Scenery is kept simple and clean:
// faceted boulders, a few shrubs or crystals, distant ranges, drifting dust.
import * as THREE from 'three'
import { makeSky, SKY_PAL, FOG_COL } from './sky'
import { buildRainforest } from './rainforest'
import { buildForestRapids } from './forestRapids'

function mulberry32(a) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const smooth = (a, b, v) => {
  const t = clamp((v - a) / (b - a), 0, 1)
  return t * t * (3 - 2 * t)
}
const mixc = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k]
const tmpC = new THREE.Color()
const lin3 = (c) => {
  tmpC.setRGB(clamp(c[0], 0, 255) / 255, clamp(c[1], 0, 255) / 255, clamp(c[2], 0, 255) / 255, THREE.SRGBColorSpace)
  return new THREE.Vector3(tmpC.r, tmpC.g, tmpC.b)
}
const col3 = (c) => new THREE.Color().setRGB(clamp(c[0], 0, 255) / 255, clamp(c[1], 0, 255) / 255, clamp(c[2], 0, 255) / 255, THREE.SRGBColorSpace)

function tex(w, h, draw, soft) {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  draw(c.getContext('2d'), w, h)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  if (soft) {
    t.magFilter = THREE.LinearFilter
    t.minFilter = THREE.LinearMipmapLinearFilter
  } else {
    t.magFilter = THREE.NearestFilter
    t.minFilter = THREE.NearestFilter
    t.generateMipmaps = false
  }
  return t
}

let softDotTex = null
function makeSoftDot() {
  if (softDotTex) return softDotTex
  softDotTex = tex(64, 64, (g, w, h) => {
    const grd = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2)
    grd.addColorStop(0, 'rgba(255,255,255,1)')
    grd.addColorStop(0.4, 'rgba(255,255,255,0.5)')
    grd.addColorStop(1, 'rgba(255,255,255,0)')
    g.fillStyle = grd
    g.fillRect(0, 0, w, h)
  }, true)
  softDotTex.minFilter = THREE.LinearFilter
  return softDotTex
}

// colours are 0..255 sRGB. bands run from the canyon floor up to the rim.
const PLANETS = {
  desert: {
    bands: [[120, 52, 42], [158, 76, 48], [196, 104, 56], [224, 138, 76], [240, 176, 106], [248, 208, 146], [220, 150, 92], [178, 94, 58]],
    floor: [236, 200, 144], top: [222, 170, 114], high: [246, 222, 178], scree: [176, 114, 78], rock: [188, 120, 80],
    water: [58, 188, 206], green: [96, 150, 70], glow: null, dust: [240, 214, 168], id: 0,
  },
  ice: {
    bands: [[70, 104, 182], [96, 142, 214], [134, 180, 238], [178, 214, 250], [222, 240, 254], [160, 198, 240], [116, 156, 220], [84, 120, 196]],
    floor: [236, 246, 255], top: [244, 250, 255], high: [255, 255, 255], scree: [152, 192, 232], rock: [150, 186, 228],
    water: [84, 150, 240], green: null, glow: null, dust: [255, 255, 255], id: 1,
  },
  lava: {
    bands: [[40, 22, 26], [66, 32, 32], [98, 46, 38], [132, 62, 42], [82, 40, 36], [56, 30, 30], [158, 80, 48], [110, 54, 40]],
    floor: [78, 46, 42], top: [118, 72, 54], high: [172, 110, 76], scree: [94, 56, 46], rock: [80, 48, 42],
    water: null, green: null, glow: [255, 112, 32], dust: [255, 150, 60], id: 2,
  },
  forest: {
    bands: [[73, 86, 70], [92, 102, 78], [107, 113, 84], [123, 125, 91], [90, 104, 77], [74, 91, 73], [114, 119, 88], [84, 99, 76]],
    floor: [86, 139, 64], top: [57, 119, 57], high: [99, 157, 81], scree: [97, 114, 78], rock: [108, 112, 90],
    water: [40, 152, 151], green: [43, 115, 49], glow: null, dust: [255, 250, 210], id: 3, path: [130, 105, 72],
    mount: [63, 113, 94], fog: { day: '#b4d0bd', sunset: '#d8b193', night: '#1b3842' }, fogK: 1.35,
    falls: true, forest: true,
  },
}
const SUN = {
  day: { az: [0.5, 0.32], tan: 0.78, col: [1.0, 0.93, 0.8], k: 1.05, amb: [0.5, 0.6, 0.8], fog: 0.0006 },
  sunset: { az: [0.95, 0.5], tan: 0.36, col: [1.0, 0.56, 0.3], k: 1.12, amb: [0.56, 0.4, 0.64], fog: 0.00064 },
  night: { az: [0.3, 0.42], tan: 0.85, col: [0.45, 0.58, 1.0], k: 0.62, amb: [0.17, 0.23, 0.46], fog: 0.0007 },
}

// a rock: a rounded, faceted lump (the same corner always moves the same way, so the facets stay closed)
function rockGeometry(detail = 1) {
  const g = new THREE.IcosahedronGeometry(1, detail)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const k = Math.sin(Math.round(x * 90) * 12.9898 + Math.round(y * 90) * 78.233 + Math.round(z * 90) * 37.719) * 43758.5453
    const n = k - Math.floor(k)
    const s = 0.76 + 0.42 * n
    p.setXYZ(i, x * s, y * s, z * s)
  }
  g.computeVertexNormals()
  return g
}

export function buildArenaWorld(arena, theme, wopts) {
  const tod = theme in SKY_PAL ? theme : 'day'
  const soft = !!wopts.soft
  const pal = PLANETS[arena.opts.planet] || PLANETS.desert
  const softDot = makeSoftDot()
  const SUNC = SUN[tod]
  const fogHex = pal.fog ? pal.fog[tod] : FOG_COL[tod]
  const group = new THREE.Group()
  const { cells: n, C, ox, oz, hgt } = arena
  const Hc = (i, j) => hgt[clamp(j, 0, n - 1) * n + clamp(i, 0, n - 1)]

  // ── light: the same sun everywhere
  const sh0 = Math.hypot(SUNC.az[0], SUNC.az[1]) || 1
  const sx = -SUNC.az[0] / sh0
  const sz = -SUNC.az[1] / sh0
  const el = Math.atan(SUNC.tan)
  const toSun = new THREE.Vector3(sx * Math.cos(el), Math.sin(el), sz * Math.cos(el)).normalize()

  // ── per-column: shadow, cavity, pools
  const shadow = new Float32Array(n * n)
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const h0 = hgt[j * n + i]
      for (let st = 1; st <= 46; st++) {
        const ci = Math.round(i + sx * st)
        const cj = Math.round(j + sz * st)
        if (ci < 0 || cj < 0 || ci >= n || cj >= n) break
        if (hgt[cj * n + ci] > h0 + st * C * SUNC.tan + 1.5) { shadow[j * n + i] = 1; break }
      }
    }
  }
  {
    const c = shadow.slice()
    for (let j = 1; j < n - 1; j++) for (let i = 1; i < n - 1; i++) {
      const k = j * n + i
      shadow[k] = (c[k] * 4 + c[k - 1] * 2 + c[k + 1] * 2 + c[k - n] * 2 + c[k + n] * 2 + c[k - n - 1] + c[k - n + 1] + c[k + n - 1] + c[k + n + 1]) / 16
    }
  }
  const ring = [[3, 0], [-3, 0], [0, 3], [0, -3], [2, 2], [-2, 2], [2, -2], [-2, -2]]
  const poolN = (i, j) => (Math.sin(i * 0.11 + j * 0.061 + 2.0) + Math.sin(i * 0.043 - j * 0.1 + 0.7) + Math.sin(i * 0.19 + j * 0.17 + 4.1) * 0.6) / 2.6
  const poolV = new Float32Array(n * n)
  const greenV = new Float32Array(n * n)
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const k = j * n + i
      if (arena.edge[k] > 0 || arena.lat[k] < 0.62) continue
      const pn = poolN(i, j)
      if (pal.water || pal.glow) poolV[k] = smooth(0.46, 0.62, pn)
      if (pal.green) greenV[k] = smooth(0.2, 0.4, pn) * (1 - poolV[k])
    }
  }

  // ── waterfalls: walk up the wall from the edge of the floor, and put a pool at the foot
  const fallPaths = []
  if (pal.falls) {
    const rndW = mulberry32(Math.round(arena.opts.seed) * 211 + 3)
    const want = Math.round(clamp(arena.size / 330, 5, 14))
    const starts = []
    const edgeAt = (x, z) => arena.edge[clamp(Math.floor((z - oz) / C), 0, n - 1) * n + clamp(Math.floor((x - ox) / C), 0, n - 1)]
    for (let tries = 0; tries < 2600 && fallPaths.length < want; tries++) {
      const i = 12 + Math.floor(rndW() * (n - 24))
      const j = 12 + Math.floor(rndW() * (n - 24))
      const e = arena.edge[j * n + i]
      if (e < -3 || e > 1.5) continue
      const x = ox + (i + 0.5) * C
      const z = oz + (j + 0.5) * C
      if (starts.some((s) => Math.hypot(s[0] - x, s[1] - z) < 170)) continue
      const pts = [[x, z]]
      let cx = x
      let cz = z
      let reached = false
      for (let s = 0; s < 90; s++) {
        const gx = edgeAt(cx + C * 2, cz) - edgeAt(cx - C * 2, cz)
        const gz = edgeAt(cx, cz + C * 2) - edgeAt(cx, cz - C * 2)
        const gl = Math.hypot(gx, gz)
        if (gl < 1e-3) break
        cx += (gx / gl) * C * 1.1
        cz += (gz / gl) * C * 1.1
        pts.push([cx, cz])
        if (edgeAt(cx, cz) > 92) { reached = true; break }
      }
      if (!reached) continue
      const top = pts[pts.length - 1]
      if (arena.groundAt(top[0], top[1]) - arena.groundAt(x, z) < (pal.forest ? 12 : 45)) continue
      starts.push([x, z])
      fallPaths.push({ pts, x, z })
      for (let dj = -4; dj <= 4; dj++) {
        for (let di = -4; di <= 4; di++) {
          const ci = i + di
          const cj = j + dj
          if (ci < 0 || cj < 0 || ci >= n || cj >= n) continue
          if (Math.hypot(di, dj) * C < 30 && arena.edge[cj * n + ci] <= 1.5) poolV[cj * n + ci] = 1
        }
      }
    }
  }

  // ── terrain: one mesh per patch
  const terrainMat = new THREE.ShaderMaterial({
    uniforms: {
      bands: { value: pal.bands.map(lin3) },
      floorC: { value: lin3(pal.floor) }, topC: { value: lin3(pal.top) }, highC: { value: lin3(pal.high) }, screeC: { value: lin3(pal.scree) },
      greenC: { value: pal.green ? lin3(pal.green) : new THREE.Vector3() }, waterC: { value: pal.water ? lin3(pal.water) : new THREE.Vector3() },
      glowC: { value: pal.glow ? lin3(pal.glow) : new THREE.Vector3() },
      sunDir: { value: toSun }, sunCol: { value: new THREE.Vector3(...SUNC.col).multiplyScalar(SUNC.k) }, ambCol: { value: new THREE.Vector3(...SUNC.amb) },
      fogC: { value: new THREE.Color(fogHex) }, fogD: { value: SUNC.fog * (pal.fogK || 1) }, time: { value: 0 }, soft: { value: soft ? 1 : 0 },
      planet: { value: pal.id }, bandH: { value: 5.6 }, floorY: { value: 8 }, pathC: { value: pal.path ? lin3(pal.path) : new THREE.Vector3() },
    },
    vertexShader: `
      attribute vec4 aux; attribute vec2 aux2; varying vec3 vW; varying vec3 vN; varying vec4 vA; varying vec2 vA2;
      void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; vN = normal; vA = aux; vA2 = aux2; gl_Position = projectionMatrix * viewMatrix * w; }`,
    fragmentShader: `
      varying vec3 vW; varying vec3 vN; varying vec4 vA; varying vec2 vA2;
      uniform vec3 bands[8]; uniform vec3 floorC, topC, highC, screeC, greenC, waterC, glowC, sunDir, sunCol, ambCol, fogC, pathC;
      uniform float fogD, time, soft, planet, bandH, floorY;
      float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
      float vn(vec2 p){
        vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
        return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y);
      }
      vec3 pick(float idx){
        vec3 c = bands[0];
        for (int k = 1; k < 8; k++) { if (abs(idx - float(k)) < 0.5) c = bands[k]; }
        return c;
      }
      void main(){
        vec3 N = normalize(vN);
        float slope = 1.0 - N.y;
        float y = vW.y;
        // sandstone layers, rippling along the cliff
        float warp = (vn(vW.xz * 0.010) * 2.0 - 1.0) * 5.0 + (vn(vW.xz * 0.045 + 3.0) * 2.0 - 1.0) * 1.4;
        float sy = (y + warp) / bandH;
        float bi = floor(sy);
        float bf = fract(sy);
        float i0 = mod(bi, 8.0);
        float i1 = mod(bi + 1.0, 8.0);
        vec3 c0 = pick(i0);
        vec3 c1 = pick(i1);
        vec3 rock = soft > 0.5 ? mix(c0, c1, smoothstep(0.72, 1.0, bf)) : c0;
        rock *= mix(0.80, 1.0, smoothstep(0.0, 0.08, bf));
        if (planet > 2.5) rock = mix(screeC * 0.8, topC, vn(vW.xz * 0.022 + y * 0.015) * 0.38);
        float grain = soft > 0.5 ? vn(vW.xz * 0.4 + vW.y * 0.25) : h21(floor(vW.xz / 2.5) + floor(vW.y / 3.0));
        rock *= 0.93 + 0.14 * grain;
        // ground: rippled sand on the floor, drier rock on the benches, pale on the heights
        float rip = sin((vW.x * 0.6 + vW.z * 0.35) * 0.22 + vn(vW.xz * 0.02) * 6.0);
        float ripK = soft > 0.5 ? smoothstep(-0.3, 0.9, rip) : step(0.55, rip);
        float onFloor = 1.0 - smoothstep(floorY + 2.0, floorY + 6.0, y);
        vec3 ground = mix(floorC, topC, smoothstep(floorY + 3.0, floorY + 12.0, y));
        ground = mix(ground, highC, smoothstep(88.0, 125.0, y));
        ground = mix(ground, rock * 1.05, (planet > 2.5 ? 0.04 : 0.16) * smoothstep(floorY + 10.0, floorY + 16.0, y));
        ground *= 1.0 - (planet > 2.5 ? 0.015 : 0.07) * ripK * onFloor;
        ground *= 0.97 + 0.06 * grain;
        float pathK = 0.0;
        if (planet > 2.5) {
          // a packed-earth trail along the route, over lush, uneven grass
          pathK = 1.0 - smoothstep(0.2, 0.5, vA2.x);
          float gvv = vn(vW.xz * 0.045);
          ground = mix(ground, ground * vec3(1.14, 1.1, 0.8), gvv * 0.55);
          ground = mix(ground, pathC * (0.92 + 0.14 * grain), pathK * 0.88);
        }
        float flatK = smoothstep(0.66, 0.88, N.y);
        // scree at the foot of the cliffs
        float lowK = 1.0 - smoothstep(floorY + 4.0, floorY + 22.0, y);
        vec3 steep = mix(rock, screeC * (0.9 + 0.2 * grain), lowK * 0.78 * smoothstep(0.08, 0.45, slope));
        if (planet > 2.5) {
          // moss and hanging vines on the rock
          float mossN = vn(vW.xz * 0.06 + y * 0.02) * 0.55 + vn(vW.xz * 0.22 + y * 0.12) * 0.45;
          float mossK = smoothstep(0.52, 0.72, mossN + clamp((y - floorY) * 0.0022, 0.0, 0.2)) * smoothstep(0.1, 0.4, slope);
          float vine = smoothstep(0.62, 0.78, vn(vec2((vW.x + vW.z) * 0.35, y * 0.045))) * smoothstep(0.25, 0.6, slope);
          steep = mix(steep, greenC * (0.8 + 0.5 * grain), clamp(mossK * 0.7 + vine * 0.6, 0.0, 0.85));
        }
        vec3 alb = mix(steep, ground, flatK);
        if (planet > 2.5) {
          float fh = h21(floor(vW.xz * 0.7));
          float fl = step(0.998, fh) * flatK * (1.0 - pathK);
          vec3 fc = fh > 0.9945 ? vec3(1.0, 0.45, 0.7) : (fh > 0.99 ? vec3(1.0, 0.85, 0.3) : vec3(0.95, 0.97, 1.0));
          alb = mix(alb, fc, fl);
        }
        // oasis green, pools
        float poolN = vA.z + (vn(vW.xz * 0.25) - 0.5) * 0.12;
        float pool = smoothstep(0.5, 0.56, poolN) * onFloor * flatK;
        alb = mix(alb, greenC * (0.88 + 0.24 * grain), vA.w * onFloor * flatK * (1.0 - pool) * (planet < 0.5 ? 1.0 : 0.0));
        vec3 wcol = mix(waterC * 1.25, waterC * 0.7, smoothstep(0.55, 0.8, poolN));
        wcol = mix(wcol, vec3(0.9, 0.97, 1.0) * 0.8, 0.3 * (1.0 - smoothstep(0.5, 0.62, poolN)));
        if (planet < 1.5 || planet > 2.5) alb = mix(alb, wcol, pool);
        // light
        float ndl = max(dot(N, sunDir), 0.0);
        if (soft < 0.5) ndl = floor(ndl * 5.0 + 0.5) / 5.0;
        float sh = vA.y;
        float lit = ndl * (1.0 - 0.88 * sh);
        vec3 L = ambCol * (0.58 + 0.32 * N.y) * vA.x + sunCol * lit * 0.95 * (0.72 + 0.28 * vA.x);
        vec3 col = alb * L;
        // water glitter
        if (planet < 1.5 || planet > 2.5) col += vec3(1.0, 0.98, 0.9) * pool * step(0.985, h21(floor(vW.xz * 0.9) + floor(time * 2.0))) * (1.0 - sh) * 0.8;
        // lava: glowing pools and glowing seams in the cliffs
        if (planet > 1.5 && planet < 2.5) {
          float flow = vn(vW.xz * 0.11 + vec2(time * 0.25, 0.0));
          vec3 lv = glowC * (0.72 + 0.5 * flow);
          col = mix(col, lv, pool);
          float seam = step(mod(bi, 5.0), 0.5) * (1.0 - smoothstep(0.0, 0.2, bf)) * smoothstep(0.25, 0.5, slope);
          col += glowC * seam * (0.9 + 0.3 * sin(time * 2.0 + y * 0.3));
        }
        float dist = length(vW - cameraPosition);
        float f = 1.0 - exp(-fogD * fogD * dist * dist);
        col = mix(col, fogC, clamp(f, 0.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
        gl_FragColor = linearToOutputTexel(gl_FragColor);
      }`,
  })
  const CH = 40
  for (let cj = 0; cj * CH < n - 1; cj++) {
    for (let ci = 0; ci * CH < n - 1; ci++) {
      const i0 = ci * CH, i1 = Math.min(n - 1, i0 + CH)
      const j0 = cj * CH, j1 = Math.min(n - 1, j0 + CH)
      const nx = i1 - i0 + 1
      const nz = j1 - j0 + 1
      const pos = new Float32Array(nx * nz * 3)
      const nor = new Float32Array(nx * nz * 3)
      const aux = new Float32Array(nx * nz * 4)
      const aux2 = new Float32Array(nx * nz * 2)
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const v = (j - j0) * nx + (i - i0)
          const h = Hc(i, j)
          pos[v * 3] = ox + (i + 0.5) * C
          pos[v * 3 + 1] = h
          pos[v * 3 + 2] = oz + (j + 0.5) * C
          const dx = (Hc(i + 1, j) - Hc(i - 1, j)) / (2 * C)
          const dz = (Hc(i, j + 1) - Hc(i, j - 1)) / (2 * C)
          const nl = Math.hypot(dx, 1, dz)
          nor[v * 3] = -dx / nl
          nor[v * 3 + 1] = 1 / nl
          nor[v * 3 + 2] = -dz / nl
          // darker where the cliffs close in, lighter along a lip
          let avg = 0
          for (const [a, b] of ring) avg += Hc(i + a, j + b)
          avg /= ring.length
          const cav = (avg - h) / 46
          const k = Math.min(n - 1, Math.max(0, j)) * n + Math.min(n - 1, Math.max(0, i))
          aux[v * 4] = clamp(1 - clamp(cav, 0, 0.42) + clamp(-cav * 0.5, 0, 0.08), 0.5, 1.1)
          aux[v * 4 + 1] = shadow[k]
          aux[v * 4 + 2] = poolV[k]
          aux[v * 4 + 3] = greenV[k]
          aux2[v * 2] = arena.lat[k]
          aux2[v * 2 + 1] = arena.edge[k]
        }
      }
      const idx = []
      for (let j = 0; j < nz - 1; j++) {
        for (let i = 0; i < nx - 1; i++) {
          const a = j * nx + i
          idx.push(a, a + nx, a + 1, a + 1, a + nx, a + nx + 1)
        }
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
      g.setAttribute('normal', new THREE.BufferAttribute(nor, 3))
      g.setAttribute('aux', new THREE.BufferAttribute(aux, 4))
      g.setAttribute('aux2', new THREE.BufferAttribute(aux2, 2))
      g.setIndex(idx)
      g.computeBoundingSphere()
      group.add(new THREE.Mesh(g, terrainMat))
    }
  }
  // beyond the map: more plateau, running out to the haze
  const fogCol = new THREE.Color(fogHex)
  const farCol = col3(mixc(pal.top, [fogCol.r * 255, fogCol.g * 255, fogCol.b * 255], 0.22))
  const farShape = new THREE.Shape()
  farShape.moveTo(-20000, -20000)
  farShape.lineTo(20000, -20000)
  farShape.lineTo(20000, 20000)
  farShape.lineTo(-20000, 20000)
  farShape.closePath()
  const hole = new THREE.Path()
  hole.moveTo(ox - 4, -(oz - 4))
  hole.lineTo(ox - 4, -(oz + arena.size + 4))
  hole.lineTo(ox + arena.size + 4, -(oz + arena.size + 4))
  hole.lineTo(ox + arena.size + 4, -(oz - 4))
  hole.closePath()
  farShape.holes.push(hole)
  const far = new THREE.Mesh(new THREE.ShapeGeometry(farShape).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: farCol, side: THREE.DoubleSide }))
  far.position.y = pal.forest ? 25 : 66
  far.frustumCulled = false
  group.add(far)

  // ── sky
  const sky = makeSky({ tod, soft, sunDir: toSun, hor: fogHex })
  group.add(sky.mesh)

  // ── mountains standing in the haze
  {
    const rnd = mulberry32(Math.round(arena.opts.seed) * 313 + 9)
    const cx0 = ox + arena.size / 2
    const cz0 = oz + arena.size / 2
    const hazeRGB = [fogCol.r * 255, fogCol.g * 255, fogCol.b * 255]
    const topRGB = mixc(pal.mount || pal.bands[2], hazeRGB, 0.5)
    const ranges = [[4600, 190, 560, 0.62], [3300, 120, 420, 0.4]]
    for (const [R, hMin, hMax, mk] of ranges) {
      const pos = []
      const cols = []
      const idx = []
      const p1 = rnd() * 6.28, p2 = rnd() * 6.28, p3 = rnd() * 6.28
      const SEG = 360
      const bottom = hazeRGB
      const upper = mixc(topRGB, hazeRGB, mk)
      for (let k = 0; k <= SEG; k++) {
        const a = (k / SEG) * Math.PI * 2
        const s = 0.5 * Math.sin(a * 5 + p1) + 0.3 * Math.sin(a * 13 + p2) + 0.2 * Math.sin(a * 31 + p3)
        let r = clamp(0.5 + 0.5 * s, 0, 1)
        r = Math.round(r * 5) / 5 * 0.55 + r * 0.45 // some flat-topped mesas
        const h = hMin + (hMax - hMin) * r
        const x = cx0 + Math.cos(a) * R
        const z = cz0 + Math.sin(a) * R
        pos.push(x, -4, z, x, h, z)
        const lc = col3(bottom), uc = col3(upper)
        cols.push(lc.r, lc.g, lc.b, uc.r, uc.g, uc.b)
        if (k < SEG) {
          const v = k * 2
          idx.push(v, v + 2, v + 1, v + 1, v + 2, v + 3)
        }
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
      g.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3))
      g.setIndex(idx)
      const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide, fog: false }))
      m.frustumCulled = false
      group.add(m)
    }
  }

  // ── scenery: boulders, plus a few plants / crystals / shards
  const bandAt = (y) => pal.bands[((Math.floor(y / 5.6) % 8) + 8) % 8]
  const rockGeo = rockGeometry(1)
  const rockMatI = new THREE.MeshLambertMaterial({ flatShading: true })
  const inst = (geo, mat, list) => {
    if (!list.length) return
    const mesh = new THREE.InstancedMesh(geo, mat, list.length)
    const m4 = new THREE.Matrix4()
    const q = new THREE.Quaternion()
    const e = new THREE.Euler()
    list.forEach((o, k) => {
      e.set(o.tx || 0, o.ry, o.tz || 0, 'YXZ')
      q.setFromEuler(e)
      m4.compose(new THREE.Vector3(o.x, o.y, o.z), q, new THREE.Vector3(o.sx, o.sy, o.sz))
      mesh.setMatrixAt(k, m4)
      mesh.setColorAt(k, col3(o.col))
    })
    mesh.frustumCulled = false
    group.add(mesh)
  }
  {
    const rnd = mulberry32(Math.round(arena.opts.seed) * 977 + 5)
    const boulders = []
    const plants = []
    const accents = []
    const planet = arena.opts.planet
    for (let j = 8; j < n - 8; j += 2) {
      for (let i = 8; i < n - 8; i += 2) {
        const k = j * n + i
        const e = arena.edge[k]
        const x = ox + (i + rnd()) * C
        const z = oz + (j + rnd()) * C
        const g0 = arena.groundAt(x, z)
        // boulders spill down the foot of the cliffs
        if (e > 2 && e < 52 && g0 < 40 && rnd() < 0.1 && boulders.length < 700) {
          const s = 1.3 + Math.pow(rnd(), 2.2) * 5.2
          const b = bandAt(g0 + 4)
          const f = 0.82 + rnd() * 0.3
          boulders.push({ x, y: g0 + s * 0.22, z, sx: s * (1 + rnd() * 0.3), sy: s * (0.55 + rnd() * 0.25), sz: s * (0.9 + rnd() * 0.3), ry: rnd() * 6.28, col: pal.forest ? mixc([b[0] * f, b[1] * f, b[2] * f], [66, 118, 58], 0.34) : [b[0] * f, b[1] * f, b[2] * f] })
        }
        if (planet === 'desert') {
          // an oasis, and the odd dry bush along the foot of the walls
          const gv = greenV[k]
          if ((gv > 0.2 && rnd() < 0.3) || (e > 0 && e < 24 && g0 < 16 && rnd() < 0.012)) {
            if (plants.length > 340) continue
            const s = 1.1 + rnd() * 1.6
            const wet = gv > 0.2
            const c = wet ? [70 + rnd() * 40, 130 + rnd() * 30, 56 + rnd() * 20] : [150 + rnd() * 20, 134 + rnd() * 16, 84]
            plants.push({ x, y: g0 + s * 0.3, z, sx: s * 1.5, sy: s * 0.85, sz: s * 1.5, ry: rnd() * 6.28, col: c })
          }
        } else if (planet === 'ice') {
          if (e > 3 && e < 34 && g0 < 28 && rnd() < 0.035 && accents.length < 260) {
            const c = rnd()
            for (let q = 0; q < 3; q++) {
              const h = 3 + rnd() * 8
              accents.push({ x: x + (rnd() - 0.5) * 4, y: g0 - 0.3, z: z + (rnd() - 0.5) * 4, sx: 1.1 + rnd() * 1.3, sy: h, sz: 1.1 + rnd() * 1.3, ry: rnd() * 6.28, tx: (rnd() - 0.5) * 0.3, tz: (rnd() - 0.5) * 0.3, col: c < 0.5 ? [190, 232, 255] : [226, 246, 255] })
            }
          }
        } else if (e > 3 && e < 30 && g0 < 28 && rnd() < 0.03 && accents.length < 260) {
          for (let q = 0; q < 3; q++) {
            const h = 3 + rnd() * 9
            accents.push({ x: x + (rnd() - 0.5) * 4, y: g0 - 0.3, z: z + (rnd() - 0.5) * 4, sx: 0.9 + rnd() * 1.2, sy: h, sz: 0.9 + rnd() * 1.2, ry: rnd() * 6.28, tx: (rnd() - 0.5) * 0.35, tz: (rnd() - 0.5) * 0.35, col: [34 + rnd() * 20, 22, 40 + rnd() * 20] })
          }
        }
      }
    }
    inst(rockGeo, rockMatI, boulders)
    if (planet === 'desert') inst(new THREE.IcosahedronGeometry(1, 0), new THREE.MeshLambertMaterial({ flatShading: true }), plants)
    if (planet === 'ice') inst(new THREE.ConeGeometry(0.5, 1, 5).translate(0, 0.5, 0), new THREE.MeshLambertMaterial({ flatShading: true, emissive: new THREE.Color(0.16, 0.34, 0.5) }), accents)
    if (planet === 'lava') inst(new THREE.ConeGeometry(0.6, 1, 4).translate(0, 0.5, 0), new THREE.MeshLambertMaterial({ flatShading: true, emissive: new THREE.Color(0.34, 0.07, 0.02) }), accents)
  }

  // Forest trees are generated separately from the canyon scenery.
  let jungle = null
  let forestRapids = null
  const forestAnim = { fn: null }
  if (pal.forest) {
    const rndF = mulberry32(Math.round(arena.opts.seed) * 4441 + 17)
    const slopeAt = (x, z) => {
      const gx = (arena.groundAt(x + C, z) - arena.groundAt(x - C, z)) / (2 * C)
      const gz = (arena.groundAt(x, z + C) - arena.groundAt(x, z - C)) / (2 * C)
      return Math.hypot(gx, gz)
    }
    jungle = buildRainforest(arena, { soft, density: wopts.forestDensity })
    group.add(jungle.group)
    forestRapids = buildForestRapids(arena, { fogColor: fogHex, fogDensity: SUNC.fog * (pal.fogK || 1), soft, mistTexture: softDot })
    group.add(forestRapids.group)
    const lam = new THREE.MeshLambertMaterial({ flatShading: true })
    // flowers in the meadows
    {
      const FL = [[255, 110, 168], [255, 214, 70], [250, 250, 255], [176, 140, 255], [255, 150, 60], [90, 220, 255]]
      const fl = []
      for (let j = 10; j < n - 10 && fl.length < 1100; j++) {
        for (let i = 10; i < n - 10; i++) {
          const e = arena.edge[j * n + i]
          if (e < 3 || e > 60 || rndF() > 0.03) continue
          const x = ox + (i + rndF()) * C
          const z = oz + (j + rndF()) * C
          if (slopeAt(x, z) > 0.3) continue
          const s = 0.55 + rndF() * 0.55
          for (let q = 0; q < 3; q++) fl.push({ x: x + (rndF() - 0.5) * 5, y: arena.groundAt(x, z) + 0.35, z: z + (rndF() - 0.5) * 5, sx: s, sy: s * 0.8, sz: s, ry: 0, col: FL[Math.floor(rndF() * FL.length)] })
        }
      }
      inst(new THREE.IcosahedronGeometry(1, 0), tod === 'night' ? new THREE.MeshBasicMaterial() : lam, fl)
    }

    // waterfalls pouring down the cliffs in tiers, with a pool and mist at the foot
    const fallU = { time: { value: 0 }, fogC: { value: new THREE.Color(fogHex) }, fogD: { value: SUNC.fog * (pal.fogK || 1) }, soft: { value: soft ? 1 : 0 } }
    const fallMat = new THREE.ShaderMaterial({
      uniforms: fallU, transparent: true, depthWrite: false, side: THREE.DoubleSide,
      vertexShader: 'varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
      fragmentShader: `
        varying vec2 vUv; varying vec3 vW; uniform float time, fogD, soft; uniform vec3 fogC;
        float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f); return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y); }
        void main(){
          float edge = smoothstep(0.0, 0.2, vUv.x) * smoothstep(1.0, 0.8, vUv.x);
          float s1 = vn(vec2(vUv.x * 12.0, vUv.y * 46.0 - time * 3.0));
          float s2 = vn(vec2(vUv.x * 28.0 + 5.0, vUv.y * 90.0 - time * 5.2));
          float streak = s1 * 0.6 + s2 * 0.4;
          if (soft < 0.5) streak = floor(streak * 4.0) / 4.0;
          vec3 col = mix(vec3(0.5, 0.86, 0.95), vec3(1.0), smoothstep(0.3, 0.8, streak));
          float foam = smoothstep(0.9, 1.0, vUv.y);
          col = mix(col, vec3(1.0), foam * 0.85);
          float a = edge * (0.5 + 0.42 * streak) * smoothstep(0.0, 0.05, vUv.y);
          float d = length(vW - cameraPosition);
          col = mix(col, fogC, clamp(1.0 - exp(-fogD * fogD * d * d), 0.0, 1.0));
          gl_FragColor = vec4(col, a);
          gl_FragColor = linearToOutputTexel(gl_FragColor);
        }`,
    })
    const mist = []
    for (const f of fallPaths) {
      const P = f.pts
      // an even sample every ~3 m along the climb
      const S = []
      for (let a = 0; a < P.length - 1; a++) {
        const L = Math.hypot(P[a + 1][0] - P[a][0], P[a + 1][1] - P[a][1])
        const m = Math.max(1, Math.round(L / 3))
        for (let q = 0; q < m; q++) S.push([P[a][0] + ((P[a + 1][0] - P[a][0]) * q) / m, P[a][1] + ((P[a + 1][1] - P[a][1]) * q) / m])
      }
      const m = S.length
      if (m < 6) continue
      const pos = new Float32Array(m * 2 * 3)
      const uv = new Float32Array(m * 2 * 2)
      for (let r = 0; r < m; r++) {
        const a = S[Math.max(0, r - 1)], b = S[Math.min(m - 1, r + 1)]
        let dx = b[0] - a[0], dz = b[1] - a[1]
        const dl = Math.hypot(dx, dz) || 1
        dx /= dl; dz /= dl
        const w = 5 + 1.6 * (1 - r / m)
        for (let sd = 0; sd < 2; sd++) {
          const px = S[r][0] + -dz * w * (sd ? 1 : -1)
          const pz = S[r][1] + dx * w * (sd ? 1 : -1)
          const o = (r * 2 + sd) * 3
          pos[o] = px
          pos[o + 1] = arena.groundAt(px, pz) + 0.9
          pos[o + 2] = pz
          uv[(r * 2 + sd) * 2] = sd
          uv[(r * 2 + sd) * 2 + 1] = 1 - r / (m - 1)
        }
      }
      const idx = []
      for (let r = 0; r < m - 1; r++) {
        const a = r * 2
        idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3)
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
      g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
      g.setIndex(idx)
      g.computeBoundingSphere()
      const mesh = new THREE.Mesh(g, fallMat)
      mesh.renderOrder = 5
      group.add(mesh)
      // mist rolling off the foot
      const gy = arena.groundAt(f.x, f.z)
      for (let q = 0; q < 4; q++) {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: softDot, color: '#eefcff', transparent: true, opacity: 0.3, depthWrite: false }))
        const sc = 34 + rndF() * 26
        sp.position.set(f.x + (rndF() - 0.5) * 22, gy + 5 + rndF() * 6, f.z + (rndF() - 0.5) * 22)
        sp.scale.setScalar(sc)
        group.add(sp)
        mist.push({ sp, sc, ph: rndF() * 6.28 })
      }
    }

    // shafts of sunlight falling through the valley
    const rayTex = tex(32, 256, (g, w, h) => {
      const img = g.createImageData(w, h)
      for (let y = 0; y < h; y++) {
        const v = y / (h - 1)
        const va = Math.min(1, v / 0.16) * (1 - Math.pow(Math.max(0, (v - 0.55) / 0.45), 1.6))
        for (let x = 0; x < w; x++) {
          const u = (x / (w - 1)) * 2 - 1
          const ha = Math.pow(Math.max(0, 1 - u * u), 1.5)
          const o = (y * w + x) * 4
          img.data[o] = img.data[o + 1] = img.data[o + 2] = 255
          img.data[o + 3] = Math.round(255 * ha * va)
        }
      }
      g.putImageData(img, 0, 0)
    }, true)
    rayTex.minFilter = THREE.LinearFilter
    const rayCol = tod === 'sunset' ? '#ffb070' : tod === 'night' ? '#8ab0ff' : '#fff4c8'
    const rayBase = tod === 'sunset' ? 0.18 : tod === 'night' ? 0.07 : 0.14
    const rays = []
    const qRay = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), toSun)
    for (let k = 0; k < 18; k++) {
      const p = arena.paths[Math.floor(rndF() * arena.paths.length)]
      const q = p.pts[3 + Math.floor(rndF() * (p.pts.length - 6))]
      const a = p.pts[Math.max(0, p.pts.indexOf(q) - 1)], b = p.pts[Math.min(p.pts.length - 1, p.pts.indexOf(q) + 1)]
      let tx = b[0] - a[0], tz = b[1] - a[1]
      const tl = Math.hypot(tx, tz) || 1
      tx /= tl; tz /= tl
      const off = (rndF() - 0.5) * p.halfW * 2.2
      const x = q[0] - tz * off
      const z = q[1] + tx * off
      const g0 = arena.groundAt(x, z)
      const L = 190
      const wd = 10 + rndF() * 16
      const mat = new THREE.MeshBasicMaterial({ map: rayTex, color: rayCol, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, opacity: rayBase })
      for (let c = 0; c < 2; c++) {
        const m = new THREE.Mesh(new THREE.PlaneGeometry(wd, L), mat)
        m.quaternion.copy(qRay)
        m.rotateY((c * Math.PI) / 2)
        m.position.set(x, g0, z).addScaledVector(toSun, L / 2 - 2)
        m.frustumCulled = false
        group.add(m)
      }
      rays.push({ mat, ph: rndF() * 6.28, sp: 0.25 + rndF() * 0.4 })
    }
    forestAnim.fn = (t) => {
      fallU.time.value = t
      for (const r of rays) r.mat.opacity = rayBase * (0.65 + 0.35 * Math.sin(t * r.sp + r.ph))
      for (const m of mist) m.sp.scale.setScalar(m.sc * (1 + 0.08 * Math.sin(t * 0.9 + m.ph)))
    }
  }

  // ── gates
  const gates = []
  const curtainTex = tex(8, 64, (g, w, h) => {
    const grd = g.createLinearGradient(0, 0, 0, h)
    grd.addColorStop(0, 'rgba(255,255,255,0.0)')
    grd.addColorStop(0.9, 'rgba(255,255,255,0.65)')
    grd.addColorStop(1, 'rgba(255,255,255,0.95)')
    g.fillStyle = grd
    g.fillRect(0, 0, w, h)
  }, true)
  const up = new THREE.Vector3(0, 1, 0)
  arena.gates.forEach((gt, k) => {
    const grp = new THREE.Group()
    const gy = arena.groundAt(gt.x, gt.z)
    const lat = new THREE.Vector3(-gt.nz, 0, gt.nx)
    const back = new THREE.Vector3(-gt.nx, 0, -gt.nz)
    const m = new THREE.Matrix4().makeBasis(lat, up, back)
    m.setPosition(gt.x, gy, gt.z)
    grp.applyMatrix4(m)
    grp.matrixAutoUpdate = false
    const half = gt.r * 0.82
    const bodyMat = new THREE.MeshBasicMaterial({ color: '#eef3ff' })
    const stripeMat = new THREE.MeshBasicMaterial({ color: '#00e5ff' })
    for (const sdx of [-1, 1]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 2.1, 34, 10), bodyMat)
      p.position.set(sdx * half, 17, 0)
      grp.add(p)
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 1.6, 10), stripeMat)
      ring.position.set(sdx * half, 24, 0)
      grp.add(ring)
      const ring2 = ring.clone()
      ring2.position.y = 12
      grp.add(ring2)
      const cap = new THREE.Mesh(new THREE.SphereGeometry(2.6, 14, 10), stripeMat)
      cap.position.set(sdx * half, 35, 0)
      grp.add(cap)
    }
    const barMat = new THREE.MeshBasicMaterial({ color: '#00e5ff' })
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, half * 2, 10).rotateZ(Math.PI / 2), barMat)
    bar.position.set(0, 34, 0)
    grp.add(bar)
    const curtMat = new THREE.MeshBasicMaterial({ map: curtainTex, color: '#00e5ff', transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
    const curtain = new THREE.Mesh(new THREE.PlaneGeometry(half * 2, 33), curtMat)
    curtain.position.set(0, 17, 0)
    grp.add(curtain)
    const label = tex(128, 64, (g, w, h) => {
      g.fillStyle = '#0a0e1c'
      g.fillRect(0, 0, w, h)
      g.fillStyle = '#ffffff'
      g.font = 'bold 44px sans-serif'
      g.textAlign = 'center'
      g.fillText(k === 0 ? 'START' : String(k), w / 2, 48)
    }, true)
    label.minFilter = THREE.LinearFilter
    const banner = new THREE.Mesh(new THREE.PlaneGeometry(16, 8), new THREE.MeshBasicMaterial({ map: label, side: THREE.DoubleSide }))
    banner.position.set(0, 29, 0.3)
    grp.add(banner)
    group.add(grp)
    gates.push({ barMat, curtMat, stripeMat })
  })

  // ── route beacons: a slim post with a glowing gem, along the open canyon
  {
    const post = new THREE.CylinderGeometry(0.3, 0.5, 5, 6).translate(0, 2.5, 0)
    const gem = new THREE.OctahedronGeometry(1.3, 0).scale(1, 1.5, 1).translate(0, 6.6, 0)
    const list = []
    for (const p of arena.paths) {
      if (p.kind === 'cut' && p.hidden) continue
      for (let i = 4; i < p.pts.length - 4; i += 6) {
        const q = p.pts[i]
        const a = p.pts[i - 1], b = p.pts[i + 1]
        let tx = b[0] - a[0], tz = b[1] - a[1]
        const l = Math.hypot(tx, tz) || 1
        tx /= l; tz /= l
        for (const sdx of [-1, 1]) {
          const off = sdx * (p.halfW - 5)
          list.push([q[0] - tz * off, q[1] + tx * off, sdx, p.kind === 'cut'])
        }
      }
    }
    const pm = new THREE.InstancedMesh(post, new THREE.MeshBasicMaterial({ color: '#dfe8ff' }), list.length)
    const gm = new THREE.InstancedMesh(gem, new THREE.MeshBasicMaterial(), list.length)
    const m4 = new THREE.Matrix4()
    list.forEach((e, k) => {
      m4.makeTranslation(e[0], arena.groundAt(e[0], e[1]), e[1])
      pm.setMatrixAt(k, m4)
      gm.setMatrixAt(k, m4)
      gm.setColorAt(k, col3(e[3] ? [255, 90, 210] : e[2] < 0 ? [40, 235, 255] : [255, 170, 50]))
    })
    pm.frustumCulled = false
    gm.frustumCulled = false
    group.add(pm, gm)
  }

  // ── boost pads
  {
    const padTex = tex(64, 128, (g, w, h) => {
      g.clearRect(0, 0, w, h)
      const grd = g.createLinearGradient(0, 0, 0, h)
      grd.addColorStop(0, '#ff7a00')
      grd.addColorStop(1, '#ffe14d')
      g.fillStyle = grd
      for (let k = 0; k < 3; k++) {
        const y = k * (h / 3)
        g.beginPath()
        g.moveTo(w * 0.1, y + h / 3)
        g.lineTo(w * 0.5, y + h * 0.05)
        g.lineTo(w * 0.9, y + h / 3)
        g.lineTo(w * 0.9, y + h / 3 - 14)
        g.lineTo(w * 0.5, y + h * 0.05 + 12)
        g.lineTo(w * 0.1, y + h / 3 - 14)
        g.closePath()
        g.fill()
      }
    }, soft)
    padTex.wrapS = padTex.wrapT = THREE.RepeatWrapping
    const padMat = new THREE.MeshBasicMaterial({ map: padTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
    for (const pd of arena.pads) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(pd.r * 1.6, pd.r * 2.2).rotateX(-Math.PI / 2), padMat)
      m.position.set(pd.x, arena.groundAt(pd.x, pd.z) + 0.3, pd.z)
      group.add(m)
    }
    group.userData.padTex = padTex
  }

  // ── hazards
  const rockColor = col3(pal.rock)
  const darkColor = col3([pal.rock[0] * 0.66, pal.rock[1] * 0.66, pal.rock[2] * 0.66])
  const rockM = new THREE.MeshLambertMaterial({ color: rockColor, flatShading: true })
  const darkM = new THREE.MeshLambertMaterial({ color: darkColor, flatShading: true })
  const redMat = new THREE.MeshBasicMaterial({ color: '#ff3b30' })
  const whiteMat = new THREE.MeshBasicMaterial({ color: '#f6f6f6' })
  const forestWood = new THREE.MeshLambertMaterial({ color: '#594b38', flatShading: true })
  const forestMoss = new THREE.MeshLambertMaterial({ color: '#6b8745', flatShading: true })
  const icy = pal.id === 1 || pal.forest
  const flameTex = tex(16, 64, (g, w, h) => {
    const grd = g.createLinearGradient(0, 0, 0, h)
    if (icy) {
      grd.addColorStop(0, 'rgba(120,220,255,0)')
      grd.addColorStop(0.4, 'rgba(150,230,255,0.5)')
      grd.addColorStop(0.8, 'rgba(220,250,255,0.9)')
      grd.addColorStop(1, 'rgba(255,255,255,1)')
    } else {
      grd.addColorStop(0, 'rgba(255,90,20,0)')
      grd.addColorStop(0.35, 'rgba(255,140,30,0.55)')
      grd.addColorStop(0.75, 'rgba(255,214,100,0.92)')
      grd.addColorStop(1, 'rgba(255,255,226,1)')
    }
    g.fillStyle = grd
    g.fillRect(0, 0, w, h)
  }, true)
  flameTex.minFilter = THREE.LinearFilter
  const flameMat = new THREE.MeshBasicMaterial({ map: flameTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
  const warnMat = new THREE.MeshBasicMaterial({ color: icy ? '#7ae6ff' : '#ffb02a', transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
  const hz = []
  for (const o of arena.obstacles) {
    const g0 = arena.groundAt(o.x, o.z)
    const grp = new THREE.Group()
    const e = { o, grp, parts: {} }
    if (o.type === 'rock') {
      for (let k = 0; k < 3; k++) {
        const s = o.r * (k === 0 ? 1.0 : 0.62 - k * 0.1)
        const mesh = new THREE.Mesh(rockGeo, k % 2 ? darkM : rockM)
        mesh.scale.set(s * 1.1, s * 0.85, s)
        mesh.position.set(k === 0 ? 0 : (k === 1 ? 1 : -1) * o.r * 0.9, s * 0.55, k === 0 ? 0 : o.r * 0.3)
        mesh.rotation.y = o.id * 0.9 + k
        grp.add(mesh)
      }
      grp.position.set(o.x, g0 - 0.3, o.z)
    } else if (o.type === 'roller') {
      const b = new THREE.Mesh(rockGeo, darkM)
      b.scale.setScalar(o.r * 1.05)
      grp.add(b)
      e.parts.ball = b
    } else if (o.type === 'fan') {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 2.6, 16, 10), pal.forest ? forestWood : new THREE.MeshBasicMaterial({ color: '#c9d3ee' }))
      pole.position.y = 8
      grp.add(pole)
      const bar = new THREE.Group()
      const segs = 6
      for (let k = 0; k < segs; k++) {
        const w = o.len / segs
        const geometry = pal.forest ? new THREE.CylinderGeometry(1, 1.2, w, 8).rotateZ(Math.PI / 2) : new THREE.BoxGeometry(w, 1.6, 2.4)
        const b = new THREE.Mesh(geometry, pal.forest ? (k % 2 ? forestMoss : forestWood) : (k % 2 ? whiteMat : redMat))
        b.position.x = -o.len / 2 + w * (k + 0.5)
        bar.add(b)
      }
      const hub = new THREE.Mesh(new THREE.SphereGeometry(2.6, 12, 8), pal.forest ? forestWood : redMat)
      bar.add(hub)
      bar.position.y = 4.5
      grp.add(bar)
      e.parts.bar = bar
      grp.position.set(o.x, g0, o.z)
    } else if (o.type === 'geyser') {
      const vent = new THREE.Mesh(new THREE.CylinderGeometry(o.r * 0.7, o.r * 0.95, 1.4, 16), darkM)
      vent.position.y = 0.7
      grp.add(vent)
      const col = new THREE.Mesh(new THREE.CylinderGeometry(o.r * 0.45, o.r * 0.75, 40, 14, 1, true), flameMat)
      col.position.y = 20
      grp.add(col)
      const core = new THREE.Mesh(new THREE.CylinderGeometry(o.r * 0.22, o.r * 0.4, 40, 10, 1, true), flameMat)
      core.position.y = 20
      grp.add(core)
      const ringM = new THREE.Mesh(new THREE.CylinderGeometry(o.r, o.r, 0.4, 20, 1, true), warnMat)
      ringM.position.y = 1.2
      grp.add(ringM)
      e.parts.col = col
      e.parts.core = core
      e.parts.ring = ringM
      grp.position.set(o.x, g0, o.z)
    } else if (o.type === 'rockwall') {
      const p = arena.paths[o.path]
      let nearest = 1
      let distance = Infinity
      for (let i = 1; i < p.pts.length - 1; i++) {
        const d = Math.hypot(p.pts[i][0] - o.x, p.pts[i][1] - o.z)
        if (d < distance) { distance = d; nearest = i }
      }
      const a = p.pts[nearest - 1], b = p.pts[nearest + 1]
      let tx = b[0] - a[0], tz = b[1] - a[1]
      const l = Math.hypot(tx, tz) || 1
      tx /= l; tz /= l
      const cnt = Math.max(4, Math.round((o.r * 2) / 8))
      for (let row = 0; row < 2; row++) {
        for (let k = 0; k < cnt + (row ? -1 : 0); k++) {
          const s = row ? 5.4 : 6.6
          const mesh = new THREE.Mesh(rockGeo, (k + row) % 2 ? darkM : rockM)
          mesh.scale.set(s * 1.15, s * 0.95, s)
          mesh.position.set(-o.r + ((o.r * 2) / cnt) * (k + (row ? 1 : 0.5)), s * 0.7 + row * 6.2, row * 0.8)
          mesh.rotation.y = k * 1.7 + row
          grp.add(mesh)
        }
      }
      grp.rotation.y = Math.atan2(tx, tz)
      grp.position.set(o.x, g0 - 0.5, o.z)
    }
    group.add(grp)
    hz.push(e)
  }

  // ── drifting dust, snow or embers
  const DN = 320
  const dust = new Float32Array(DN * 3)
  {
    const r = mulberry32(99)
    for (let k = 0; k < DN; k++) {
      dust[k * 3] = (r() - 0.5) * 220
      dust[k * 3 + 1] = r() * 80
      dust[k * 3 + 2] = (r() - 0.5) * 220
    }
  }
  const dustGeo = new THREE.BufferGeometry()
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dust, 3))
  const planetName = arena.opts.planet
  const isForest = planetName === 'forest'
  const dustPts = new THREE.Points(
    dustGeo,
    new THREE.PointsMaterial({
      size: isForest ? 1.7 : planetName === 'lava' ? 0.6 : 0.42,
      color: isForest ? (tod === 'night' ? col3([190, 255, 140]) : col3([255, 244, 190])) : col3(pal.dust),
      map: isForest ? softDot : null, transparent: true,
      opacity: isForest ? (tod === 'night' ? 0.8 : 0.35) : planetName === 'lava' ? 0.9 : 0.5,
      depthWrite: false, sizeAttenuation: true, blending: isForest || planetName === 'lava' ? THREE.AdditiveBlending : THREE.NormalBlending,
    }),
  )
  dustPts.frustumCulled = false
  group.add(dustPts)
  const wind = isForest ? [3, 2.2, 1.5] : planetName === 'ice' ? [4, -7, 2] : planetName === 'lava' ? [1, 6, 1] : [16, 0.4, 7]
  let dustInit = false

  return {
    group,
    info: { falls: fallPaths.map((f) => ({ x: f.x, z: f.z, pts: f.pts })), forest: jungle?.info ?? null, rapids: forestRapids?.info ?? [] },
    groundAt: arena.groundAt,
    sunDir: toSun,
    fog: { color: fogHex, density: SUNC.fog * (pal.fogK || 1) },
    update(dt, camPos, sim) {
      const t = sim.clock
      sky.update(t, camPos)
      terrainMat.uniforms.time.value = t
      if (jungle) jungle.update(t, camPos)
      if (forestRapids) forestRapids.update(t)
      if (forestAnim.fn) forestAnim.fn(t)
      if (!dustInit) {
        for (let k = 0; k < DN; k++) {
          dust[k * 3] += camPos.x
          dust[k * 3 + 1] += camPos.y - 30
          dust[k * 3 + 2] += camPos.z
        }
        dustInit = true
      }
      for (let k = 0; k < DN; k++) {
        const o = k * 3
        dust[o] += (wind[0] + Math.sin(k + t * 0.7) * 2) * dt
        dust[o + 1] += (wind[1] + Math.cos(k * 1.7 + t) * 1.2) * dt
        dust[o + 2] += (wind[2] + Math.cos(k * 0.6 + t * 0.5) * 2) * dt
        if (dust[o] - camPos.x > 110) dust[o] -= 220
        else if (dust[o] - camPos.x < -110) dust[o] += 220
        if (dust[o + 2] - camPos.z > 110) dust[o + 2] -= 220
        else if (dust[o + 2] - camPos.z < -110) dust[o + 2] += 220
        if (dust[o + 1] - camPos.y > 55) dust[o + 1] -= 85
        else if (dust[o + 1] - camPos.y < -30) dust[o + 1] += 85
      }
      dustGeo.attributes.position.needsUpdate = true
      group.userData.padTex.offset.y -= dt * 1.3
      for (const e of hz) {
        const o = e.o
        if (o.type === 'roller') {
          const h = sim.hazard(o, t)
          e.grp.position.set(h.x, arena.groundAt(h.x, h.z) + o.r, h.z)
          e.parts.ball.rotation.x = t * 3
          e.parts.ball.rotation.z = t * 1.7
        } else if (o.type === 'fan') {
          e.parts.bar.rotation.y = -(o.phase + o.w * t)
        } else if (o.type === 'geyser') {
          const h = sim.hazard(o, t)
          e.parts.col.visible = h.active
          e.parts.core.visible = h.active
          const s = 0.15 + 0.85 * h.u
          e.parts.col.scale.set(1 + 0.08 * Math.sin(t * 30), s, 1 + 0.08 * Math.cos(t * 27))
          e.parts.col.position.y = 20 * s
          e.parts.core.scale.set(1, s * 0.9, 1)
          e.parts.core.position.y = 20 * s * 0.9
          e.parts.ring.material.opacity = h.warn ? 0.5 + 0.4 * Math.sin(t * 24) : 0
        } else if (o.type === 'rockwall') {
          e.grp.visible = !sim.isBroken(o)
        }
      }
      const next = sim.player.cp % arena.gates.length
      gates.forEach((g, k) => {
        const on = k === next
        g.barMat.color.set(on ? '#52ff7a' : '#00e5ff')
        g.stripeMat.color.set(on ? '#52ff7a' : '#00e5ff')
        g.curtMat.color.set(on ? '#52ff7a' : '#00e5ff')
        g.curtMat.opacity = on ? 0.5 + 0.18 * Math.sin(t * 5) : 0.16
      })
    },
    dispose() {
      if (forestRapids) {
        group.remove(forestRapids.group)
        forestRapids.dispose()
      }
      if (jungle) {
        group.remove(jungle.group)
        jungle.dispose()
      }
      const geometries = new Set()
      const materials = new Set()
      const textures = new Set()
      group.traverse((o) => {
        if (o.geometry && !o.isSprite) geometries.add(o.geometry)
        if (o.material) {
          for (const material of Array.isArray(o.material) ? o.material : [o.material]) materials.add(material)
        }
      })
      for (const material of materials) {
        for (const value of Object.values(material)) {
          if (value?.isTexture && value !== softDotTex) textures.add(value)
        }
        material.dispose()
      }
      geometries.forEach((geometry) => geometry.dispose())
      textures.forEach((texture) => texture.dispose())
    },
  }
}
