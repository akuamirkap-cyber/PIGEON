// @ts-nocheck
// A bike points down -Z, with a seated rider and a rear-facing repulsor at +Z.
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

const UP = new THREE.Vector3(0, 1, 0)

// The pilot and bike have many small pieces. Merge fixed pieces by material while
// keeping the rider, helmet, forks, and handlebars as independently animated groups.
function mergeStaticMeshes(parent) {
  const groups = new Map()
  for (const child of parent.children) {
    if (!child.isMesh || Array.isArray(child.material)) continue
    if (!groups.has(child.material)) groups.set(child.material, [])
    groups.get(child.material).push(child)
  }
  for (const [material, meshes] of groups) {
    if (meshes.length < 2) continue
    const parts = meshes.map((mesh) => {
      mesh.updateMatrix()
      const geometry = mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry.clone()
      for (const name of Object.keys(geometry.attributes)) {
        if (name !== 'position' && name !== 'normal') geometry.deleteAttribute(name)
      }
      geometry.clearGroups()
      geometry.applyMatrix4(mesh.matrix)
      return geometry
    })
    const geometry = mergeGeometries(parts)
    parts.forEach((part) => part.dispose())
    if (!geometry) continue
    for (const mesh of meshes) {
      parent.remove(mesh)
      mesh.geometry.dispose()
    }
    parent.add(new THREE.Mesh(geometry, material))
  }
}

function finish(color, roughness = 0.5, metalness = 0.25) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness })
}

function box(parent, material, size, position, rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material)
  mesh.position.set(...position)
  mesh.rotation.set(...rotation)
  parent.add(mesh)
  return mesh
}

function ellipsoid(parent, material, radii, position, rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 12), material)
  mesh.position.set(...position)
  mesh.scale.set(...radii)
  mesh.rotation.set(...rotation)
  parent.add(mesh)
  return mesh
}

function beam(parent, material, a, b, radius, radiusEnd = radius) {
  const start = new THREE.Vector3(...a)
  const end = new THREE.Vector3(...b)
  const direction = end.clone().sub(start)
  const length = direction.length()
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radiusEnd, radius, length, 10), material)
  mesh.position.copy(start).addScaledVector(direction, 0.5)
  mesh.quaternion.setFromUnitVectors(UP, direction.normalize())
  parent.add(mesh)
  return mesh
}

function panel(parent, material, points, depth, plate, position = [0, 0, 0]) {
  const mesh = new THREE.Mesh(plate(points, depth, 0.025), material)
  mesh.position.set(...position)
  parent.add(mesh)
  return mesh
}

function createRider(model, variant, bars) {
  const scout = variant === 'scout'
  const sport = variant === 'sport'
  const suit = finish(scout ? '#4d6158' : sport ? '#8a473c' : '#303a43', 0.82, 0.08)
  const suitDark = finish(scout ? '#2d3935' : sport ? '#392d38' : '#171c26', 0.8, 0.12)
  const trousers = finish(scout ? '#aaa99d' : sport ? '#aa856e' : '#55565a', 0.8, 0.05)
  const armour = finish(scout ? '#e8e6dc' : sport ? '#c4a36b' : '#94512e', 0.42, 0.3)
  const helmetPaint = finish(scout ? '#f2f1e9' : sport ? '#e9c378' : '#b85b30', 0.32, 0.35)
  const boots = finish('#252b2b', 0.66, 0.18)
  const visor = finish('#0a1722', 0.14, 0.55)
  const visorHighlight = new THREE.MeshBasicMaterial({ color: sport ? '#f7ca70' : swoopGlow(variant) })

  // The pivot is at the hips so the pilot can lean into corners without leaving the seat.
  const rider = new THREE.Group()
  rider.name = 'rider'
  rider.position.set(0, 0.76, 0.63)
  model.add(rider)

  ellipsoid(rider, trousers, [0.34, 0.23, 0.28], [0, 0.04, 0])
  const torso = ellipsoid(rider, suit, [0.37, 0.57, 0.27], [0, 0.55, -0.17], [-0.35, 0, 0])
  torso.name = 'rider-torso'
  ellipsoid(rider, suitDark, [0.33, 0.42, 0.08], [0, 0.57, -0.40], [-0.32, 0, 0])
  box(rider, armour, [0.43, 0.19, 0.09], [0, 0.7, -0.46], [-0.32, 0, 0])
  box(rider, suitDark, [0.56, 0.13, 0.11], [0, 0.19, 0.20], [-0.2, 0, 0])

  // Compact backpack on the back of the jacket, visible from the chase camera.
  box(rider, armour, [0.42, 0.52, 0.19], [0, 0.62, 0.14], [-0.32, 0, 0])
  box(rider, suitDark, [0.27, 0.31, 0.035], [0, 0.63, 0.25], [-0.32, 0, 0])
  box(rider, visorHighlight, [0.22, 0.045, 0.025], [0, 0.65, 0.28], [-0.32, 0, 0])

  for (const side of [-1, 1]) {
    const shoulder = [side * 0.34, 0.93, -0.30]
    const elbow = [side * 0.48, 0.66, -0.60]
    const hand = [side * 0.52, 0.61, -1.15]
    ellipsoid(rider, armour, [0.23, 0.15, 0.23], shoulder)
    beam(rider, suit, shoulder, elbow, 0.15, 0.13)
    ellipsoid(rider, suitDark, [0.14, 0.14, 0.14], elbow)
    beam(rider, suit, elbow, hand, 0.12, 0.105)
    ellipsoid(rider, boots, [0.13, 0.1, 0.17], hand)

    const hip = [side * 0.22, -0.02, 0.04]
    const knee = [side * 0.42, -0.21, -0.28]
    const ankle = [side * 0.43, -0.64, 0.08]
    beam(rider, trousers, hip, knee, 0.17, 0.15)
    ellipsoid(rider, armour, [0.14, 0.13, 0.16], knee)
    beam(rider, suitDark, knee, ankle, 0.115, 0.14)
    ellipsoid(rider, boots, [0.14, 0.12, 0.27], [side * 0.43, -0.68, -0.04])
  }

  beam(rider, suitDark, [0, 0.91, -0.3], [0, 1.17, -0.38], 0.14)
  const helmet = new THREE.Group()
  helmet.name = 'rider-helmet'
  helmet.position.set(0, 1.44, -0.43)
  rider.add(helmet)
  ellipsoid(helmet, helmetPaint, [0.32, 0.36, 0.34], [0, 0, 0])
  ellipsoid(helmet, visor, [0.28, 0.13, 0.07], [0, -0.045, -0.295])
  box(helmet, armour, [0.40, 0.12, 0.10], [0, -0.23, -0.22], [-0.15, 0, 0])
  box(helmet, suitDark, [0.46, 0.065, 0.05], [0, -0.075, 0.30])
  box(helmet, visorHighlight, [0.19, 0.025, 0.02], [-0.08, 0.015, -0.356])
  for (const side of [-1, 1]) {
    const earpiece = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.095, 0.07, 12).rotateZ(Math.PI / 2), armour)
    earpiece.position.set(side * 0.3, -0.02, 0.02)
    helmet.add(earpiece)
    ellipsoid(helmet, suitDark, [0.045, 0.045, 0.045], [side * 0.34, -0.02, 0.02])
  }
  if (sport || variant === 'swoop') {
    box(helmet, sport ? armour : suitDark, [0.095, 0.32, 0.05], [0, 0.17, -0.27], [-0.38, 0, 0])
  }
  mergeStaticMeshes(helmet)
  mergeStaticMeshes(rider)

  let lean = 0
  let tuck = 0
  let turn = 0
  return (state, dt) => {
    const ease = 1 - Math.exp(-Math.min(dt, 0.05) * 7)
    lean += (-state.steer * 0.22 - lean) * ease
    tuck += ((state.boost ? 0.12 : state.throttle * 0.035) - tuck) * ease
    turn += (state.steer * 0.25 - turn) * ease
    rider.rotation.z = lean
    rider.rotation.x = -tuck + Math.sin(state.time * 2.8) * 0.018
    helmet.rotation.z = -lean * 0.35
    helmet.rotation.x = tuck * 0.35
    bars.rotation.y = turn
  }
}

function swoopGlow(variant) {
  return variant === 'swoop' ? '#ffb45c' : '#ccecf0'
}

/** Builds the requested bike and returns its rider/steering animation callback. */
export function buildBike(model, glows, trails, M, variant, liveryIdx, helpers) {
  const { loft, plate, addEngine } = helpers
  const scout = variant === 'scout'
  const sport = variant === 'sport'
  const swoop = variant === 'swoop'

  const mainColor = scout ? '#dddeda' : sport ? '#9f2638' : '#384249'
  const accentColor = scout ? '#788d88' : sport ? '#e3ad3b' : '#d75d34'
  const bodyColor = new THREE.Color(mainColor)
  if (liveryIdx > 0) bodyColor.lerp(M.body, scout ? 0.18 : 0.28)
  const shell = finish(bodyColor, 0.4, 0.38)
  const accents = finish(accentColor, 0.4, 0.3)
  const frame = finish('#292f31', 0.47, 0.68)
  const steel = finish('#8a9290', 0.36, 0.68)
  const seat = finish(sport ? '#70462c' : swoop ? '#412c29' : '#45463e', 0.8, 0.08)
  const stripes = finish(sport ? '#9759a0' : swoop ? '#e99143' : '#d9e0d8', 0.42, 0.34)
  const dark = finish('#151e24', 0.52, 0.45)
  const exhaust = new THREE.Color(scout ? '#76dff2' : sport ? '#ffc273' : '#ff934f')
  const bikeEngine = {
    ...M,
    acc: exhaust,
    hot: exhaust.clone().lerp(new THREE.Color('#ffffff'), 0.65),
    neon: new THREE.MeshBasicMaterial({ color: exhaust.clone().lerp(new THREE.Color('#ffffff'), 0.65) }),
  }

  const bike = new THREE.Group()
  bike.name = `${variant}-bike`
  model.add(bike)

  // Rear engine housing and seat: armored on the scout, raised on the sport bike.
  const shellSections = [
    { z: -1.15, w: 0.18, h: 0.15, y: 0.05 },
    { z: -0.65, w: 0.38, h: 0.24, y: 0.02 },
    { z: 0.15, w: 0.52, h: 0.32, y: 0.04 },
    { z: 1.3, w: swoop ? 0.48 : 0.58, h: 0.42, y: 0.02 },
    { z: 2.25, w: swoop ? 0.42 : 0.52, h: 0.38, y: 0.02 },
    { z: 2.65, w: 0.32, h: 0.25, y: 0 },
  ]
  bike.add(new THREE.Mesh(loft(shellSections, 20), shell))
  box(bike, seat, [0.58, 0.16, 1.15], [0, 0.51, 0.72], [-0.06, 0, 0])
  box(bike, accents, [0.68, 0.07, 1.16], [0, 0.40, 0.7])
  if (sport) {
    // Tall upholstered backrest and its colored edges, matching the reference.
    box(bike, shell, [0.82, 1.0, 0.22], [0, 0.92, 1.42], [-0.22, 0, 0])
    box(bike, seat, [0.56, 0.85, 0.09], [0, 0.98, 1.29], [-0.22, 0, 0])
    box(bike, stripes, [0.70, 0.14, 0.23], [0, 1.42, 1.48], [-0.22, 0, 0])
    for (const side of [-1, 1]) box(bike, accents, [0.08, 0.88, 0.14], [side * 0.35, 1.0, 1.37], [-0.22, 0, 0])
  } else {
    box(bike, dark, [0.54, 0.45, 0.21], [0, 0.68, 1.34], [-0.22, 0, 0])
  }
  for (const side of [-1, 1]) {
    box(bike, shell, [0.12, 0.58, 1.0], [side * 0.54, 0.04, 1.36], [0, 0, side * 0.1])
    box(bike, steel, [0.035, 0.25, 0.32], [side * 0.615, -0.02, 1.44])
    for (let k = 0; k < 3; k++) box(bike, dark, [0.04, 0.025, 0.2], [side * 0.64, -0.08 + k * 0.08, 1.44])
    // Tail stabilizers, swept backward rather than wheels.
    panel(bike, shell, [[0.42 * side, 1.5], [1.18 * side, 2.28], [1.28 * side, 3.05], [0.48 * side, 2.54]], 0.07, plate, [0, -0.25, 0])
    panel(bike, stripes, [[0.86 * side, 2.28], [1.16 * side, 2.51], [1.21 * side, 2.8], [0.84 * side, 2.57]], 0.08, plate, [0, -0.24, 0])
    beam(bike, frame, [side * 0.43, -0.24, 0.55], [side * 1.08, -0.45, 0.72], 0.065)
    beam(bike, dark, [side * 0.9, -0.44, 0.48], [side * 1.2, -0.44, 0.48], 0.075)
  }
  addEngine(bike, glows, trails, bikeEngine, 0, 0.02, 2.66, swoop ? 0.53 : 0.43)

  // Long open forks and exposed mechanics leading to the forked front vanes.
  const nose = new THREE.Group()
  nose.position.set(0, -0.03, -1.0)
  bike.add(nose)
  const tipZ = swoop ? -4.9 : -4.3
  for (const side of [-1, 1]) {
    beam(nose, frame, [side * 0.3, -0.04, 0.2], [side * 0.46, -0.11, tipZ], swoop ? 0.095 : 0.075)
    beam(nose, steel, [side * 0.21, 0.2, -0.05], [side * 0.35, 0.1, tipZ + 0.32], 0.045)
    beam(nose, frame, [side * 0.30, -0.20, -0.4], [side * 0.49, -0.30, tipZ + 0.18], 0.045)
    for (let k = 0; k < 3; k++) {
      const z = -0.65 - k * 1.05
      beam(nose, steel, [side * 0.23, 0.12, z], [side * 0.39, -0.14, z - 0.2], 0.035)
    }
    const wing = swoop ? 1.55 : 1.18
    panel(nose, shell, [[0.18 * side, tipZ + 0.55], [0.55 * side, tipZ - 0.55], [wing * side, tipZ - 1.15], [0.77 * side, tipZ + 0.35]], 0.07, plate, [0, -0.21, 0])
    panel(nose, steel, [[0.39 * side, tipZ + 0.18], [0.65 * side, tipZ - 0.58], [1.03 * side, tipZ - 0.84], [0.76 * side, tipZ - 0.13]], 0.035, plate, [0, -0.12, 0])
    beam(nose, dark, [side * 0.46, -0.11, tipZ - 0.35], [side * 0.57, -0.1, tipZ - 1.25], 0.055)
  }
  for (const z of [-0.35, -1.65, -2.95]) beam(nose, frame, [-0.38, -0.1, z], [0.38, -0.1, z], 0.055)

  // Smooth forward instrument cowling, with the painted sport-bike stripes.
  const cowling = ellipsoid(bike, scout ? shell : accents, [0.64, 0.22, 0.78], [0, 0.52, -1.1])
  cowling.name = 'front-cowling'
  if (sport || swoop) {
    for (const side of [-1, 1]) {
      box(bike, stripes, [0.12, 0.025, 1.12], [side * 0.19, 0.72, -1.12], [0, 0, side * 0.04])
    }
  }
  ellipsoid(bike, dark, [0.31, 0.06, 0.22], [0, 0.73, -0.88])
  box(bike, M.neon, [0.16, 0.025, 0.08], [0, 0.79, -0.9])

  const bars = new THREE.Group()
  bars.position.set(0, 1.37, -0.52)
  bike.add(bars)
  beam(bars, steel, [-0.57, 0, 0], [0.57, 0, 0], 0.055)
  for (const side of [-1, 1]) {
    beam(bars, dark, [side * 0.43, 0, 0], [side * 0.65, 0, 0], 0.07)
    beam(bike, frame, [side * 0.30, 0.55, -0.72], [side * 0.46, 1.37, -0.52], 0.055)
  }

  if (swoop) {
    // Exposed overcharged machinery, reinforcing the outlaw-bike silhouette.
    for (const side of [-1, 1]) {
      const intake = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.26, 1.5, 12).rotateX(Math.PI / 2), steel)
      intake.position.set(side * 0.72, 0.1, 0.98)
      bike.add(intake)
      for (const z of [0.45, 0.8, 1.15, 1.5]) {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.035, 6, 12), accents)
        ring.position.set(side * 0.72, 0.1, z)
        bike.add(ring)
      }
      beam(bike, steel, [side * 0.75, 0.12, 1.7], [side * 0.8, 0.42, 2.35], 0.1)
      addEngine(bike, glows, trails, bikeEngine, side * 0.72, 0.1, 1.78, 0.2)
    }
    const fin = box(bike, accents, [0.08, 0.8, 1.0], [0, 0.68, 2.12], [-0.25, 0, 0])
    fin.name = 'swoop-fin'
  }

  const animateRider = createRider(bike, variant, bars)
  mergeStaticMeshes(nose)
  mergeStaticMeshes(bars)
  mergeStaticMeshes(bike)
  return (state, dt) => {
    animateRider(state, dt)
    const ease = 1 - Math.exp(-Math.min(dt, 0.05) * 9)
    nose.rotation.y += (state.steer * 0.11 - nose.rotation.y) * ease
  }
}