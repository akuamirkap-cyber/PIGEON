import Race from './race/Race'

export default function App() {
  return <Race />
}
