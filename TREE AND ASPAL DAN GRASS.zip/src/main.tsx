import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// StrictMode intentionally omitted: the WebGL engine is heavy and must only boot once.
createRoot(document.getElementById("root")!).render(<App />);
