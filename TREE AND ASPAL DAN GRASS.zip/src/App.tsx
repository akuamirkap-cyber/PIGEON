import { useEffect, useRef, useState } from "react";
import { Engine, defaultSettings, type CamPreset, type Mode, type Quality, type Settings } from "./engine/Engine";
import type { AssetDef } from "./engine/library";

const PRESETS: { id: CamPreset; label: string; sub: string }[] = [
  { id: "hillside", label: "Hillside", sub: "Referensi 1" },
  { id: "roadlevel", label: "Road Level", sub: "Referensi 2" },
  { id: "canopy", label: "God Rays", sub: "Tatap matahari" },
  { id: "drive", label: "Cinematic", sub: "Drive otomatis" },
  { id: "free", label: "Free Orbit", sub: "Bebas" },
];

function Slider(p: { label: string; value: number; min: number; max: number; step: number; unit?: string; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <div className="mb-1 flex items-center justify-between text-[11px] tracking-wide text-white/70">
        <span>{p.label}</span>
        <span className="font-mono text-white/90">
          {p.value.toFixed(p.step < 1 ? 2 : 0)}
          {p.unit}
        </span>
      </div>
      <input
        type="range"
        min={p.min}
        max={p.max}
        step={p.step}
        value={p.value}
        onChange={(e) => p.onChange(parseFloat(e.target.value))}
        className="h-1 w-full cursor-pointer appearance-none rounded-full bg-white/15 accent-lime-300"
      />
    </label>
  );
}

const panel = "rounded-2xl border border-white/10 bg-black/35 backdrop-blur-xl shadow-2xl shadow-black/40";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [quality, setQuality] = useState<Quality>("high");
  const [loading, setLoading] = useState<{ msg: string; p: number } | null>({ msg: "Memulai…", p: 0 });
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>("scene");
  const [preset, setPreset] = useState<CamPreset>("hillside");
  const [settings, setSettings] = useState<Settings>({ ...defaultSettings });
  const [stats, setStats] = useState({ fps: 0, trees: 0, calls: 0, tris: 0 });
  const [assets, setAssets] = useState<AssetDef[]>([]);
  const [asset, setAsset] = useState<{ id: string; variant: number }>({ id: "cedar", variant: 0 });
  const [autoRot, setAutoRot] = useState(true);
  const [panelOpen, setPanelOpen] = useState(true);
  const [hideUI, setHideUI] = useState(false);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const stateRef = useRef({ mode, preset, asset });
  stateRef.current = { mode, preset, asset };

  useEffect(() => {
    const canvas = canvasRef.current!;
    let cancelled = false;
    const eng = new Engine(canvas, quality);
    setLoading({ msg: "Memulai…", p: 0 });
    eng
      .init((msg, p) => !cancelled && setLoading({ msg, p }))
      .then(() => {
        if (cancelled) {
          eng.dispose();
          return;
        }
        engineRef.current = eng;
        (window as unknown as { __engine: Engine }).__engine = eng;
        eng.onStats = (s) => setStats(s);
        eng.applySettings(settingsRef.current);
        setAssets(eng.lib);
        const st = stateRef.current;
        eng.showAsset(st.asset.id, st.asset.variant);
        eng.setMode(st.mode);
        if (st.mode === "scene") eng.setPreset(st.preset, true);
        eng.start();
        setLoading(null);
      })
      .catch((e) => {
        console.error(e);
        setError(String(e?.message || e));
      });
    return () => {
      cancelled = true;
      if (engineRef.current === eng) {
        eng.dispose();
        engineRef.current = null;
      }
    };
  }, [quality]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "h" || e.key === "H") setHideUI((v) => !v);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const update = (s: Partial<Settings>) => {
    const next = { ...settings, ...s };
    setSettings(next);
    engineRef.current?.applySettings(s);
  };
  const choosePreset = (p: CamPreset) => {
    setPreset(p);
    engineRef.current?.setPreset(p);
  };
  const chooseMode = (m: Mode) => {
    setMode(m);
    setPanelOpen(m === "scene");
    engineRef.current?.setMode(m);
  };
  const chooseAsset = (id: string, variant = 0) => {
    setAsset({ id, variant });
    engineRef.current?.showAsset(id, variant);
  };

  const current = assets.find((a) => a.id === asset.id);
  const cats = Array.from(new Set(assets.map((a) => a.category)));

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#0d1410] font-sans text-white select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full outline-none" />

      {/* ---------- top bar ---------- */}
      {!hideUI && !loading && (
        <>
          <div className="pointer-events-none absolute left-0 right-0 top-0 h-40 bg-gradient-to-b from-black/45 to-transparent" />
          <div className="absolute left-5 top-5 flex flex-col gap-3">
            <div className={`${panel} px-5 py-4`}>
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-lime-300 to-emerald-600 text-xl shadow-lg shadow-lime-500/30">🌲</div>
                <div>
                  <h1 className="text-[17px] font-semibold leading-tight tracking-tight">Touge Forest — Realistic Asset Pack</h1>
                  <p className="text-[11px] text-white/60">Pohon · Tanah · Rumput · Semak · Aspal · Volumetric God Rays</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-1 rounded-xl bg-white/5 p-1">
                {(["scene", "gallery"] as Mode[]).map((m) => (
                  <button
                    key={m}
                    onClick={() => chooseMode(m)}
                    className={`rounded-lg px-3 py-2 text-xs font-medium transition ${mode === m ? "bg-lime-300 text-black shadow" : "text-white/75 hover:bg-white/10"}`}
                  >
                    {m === "scene" ? "🏞️ Scene Hutan" : "🧩 Asset Viewer"}
                  </button>
                ))}
              </div>
            </div>

            {mode === "gallery" && (
              <div className={`${panel} max-h-[calc(100vh-200px)] w-[300px] overflow-y-auto p-3`}>
                {cats.map((c) => (
                  <div key={c} className="mb-3 last:mb-0">
                    <div className="mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-lime-200/80">{c}</div>
                    <div className="flex flex-col gap-1">
                      {assets.filter((a) => a.category === c).map((a) => (
                        <button
                          key={a.id}
                          onClick={() => chooseAsset(a.id, 0)}
                          className={`rounded-xl px-3 py-2 text-left transition ${asset.id === a.id ? "bg-white/15 ring-1 ring-lime-300/60" : "hover:bg-white/8 hover:bg-white/10"}`}
                        >
                          <div className="text-[13px] font-medium">{a.name}</div>
                          <div className="text-[10.5px] italic text-white/50">{a.latin}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ---------- right settings panel ---------- */}
          <div className="absolute right-5 top-5 w-[270px]">
            <div className={`${panel} overflow-hidden`}>
              <button onClick={() => setPanelOpen((v) => !v)} className="flex w-full items-center justify-between px-4 py-3 text-left">
                <span className="text-xs font-semibold uppercase tracking-[0.16em] text-white/80">☀️ Pencahayaan</span>
                <span className="text-white/50">{panelOpen ? "–" : "+"}</span>
              </button>
              {panelOpen && (
                <div className="flex flex-col gap-3.5 border-t border-white/10 px-4 pb-4 pt-3">
                  <Slider label="Ketinggian Matahari" value={settings.sunElevation} min={6} max={80} step={1} unit="°" onChange={(v) => update({ sunElevation: v })} />
                  <Slider label="Arah Matahari" value={settings.sunAzimuth} min={-180} max={180} step={1} unit="°" onChange={(v) => update({ sunAzimuth: v })} />
                  <Slider label="Intensitas God Rays" value={settings.godRays} min={0} max={2.5} step={0.05} onChange={(v) => update({ godRays: v })} />
                  <Slider label="Kabut / Haze" value={settings.fog} min={0.2} max={2.5} step={0.05} onChange={(v) => update({ fog: v })} />
                  <Slider label="Angin" value={settings.wind} min={0} max={3} step={0.05} onChange={(v) => update({ wind: v })} />
                  <Slider label="Exposure" value={settings.exposure} min={0.4} max={2} step={0.02} onChange={(v) => update({ exposure: v })} />
                  <label className="flex items-center justify-between text-[11px] text-white/70">
                    <span>Asap drift di jalan</span>
                    <input type="checkbox" checked={settings.smoke} onChange={(e) => update({ smoke: e.target.checked })} className="h-4 w-4 accent-lime-300" />
                  </label>
                  <div className="flex gap-1.5 pt-1">
                    {[
                      { n: "Pagi", e: 14, a: 40 },
                      { n: "Siang", e: 58, a: 20 },
                      { n: "Sore", e: 9, a: -35 },
                    ].map((t) => (
                      <button key={t.n} onClick={() => update({ sunElevation: t.e, sunAzimuth: t.a })} className="flex-1 rounded-lg bg-white/8 bg-white/10 py-1.5 text-[11px] hover:bg-white/20">
                        {t.n}
                      </button>
                    ))}
                  </div>
                  <div>
                    <div className="mb-1 text-[11px] text-white/70">Kualitas Render</div>
                    <div className="grid grid-cols-3 gap-1 rounded-lg bg-white/5 p-1">
                      {(["low", "high", "ultra"] as Quality[]).map((q) => (
                        <button
                          key={q}
                          onClick={() => q !== quality && setQuality(q)}
                          className={`rounded-md py-1.5 text-[11px] capitalize transition ${quality === q ? "bg-white text-black" : "text-white/70 hover:bg-white/10"}`}
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                  <button onClick={() => update({ ...defaultSettings })} className="text-[11px] text-white/45 hover:text-white/80">
                    Reset ke default
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* ---------- bottom: camera presets / asset info ---------- */}
          {mode === "scene" ? (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2">
              <div className={`${panel} flex gap-1 p-1.5`}>
                {PRESETS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => choosePreset(p.id)}
                    className={`min-w-[96px] rounded-xl px-3 py-2 text-left transition ${preset === p.id ? "bg-lime-300 text-black" : "text-white hover:bg-white/10"}`}
                  >
                    <div className="text-[12.5px] font-semibold">{p.label}</div>
                    <div className={`text-[10px] ${preset === p.id ? "text-black/60" : "text-white/50"}`}>{p.sub}</div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            current && (
              <div className="absolute bottom-5 right-5 w-[min(440px,calc(100vw-40px))]">
                <div className={`${panel} p-5`}>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="text-[10px] font-semibold uppercase tracking-[0.18em] text-lime-200/80">{current.category}</div>
                      <h2 className="mt-0.5 text-xl font-semibold tracking-tight">{current.name}</h2>
                      <div className="text-xs italic text-white/55">{current.latin}</div>
                    </div>
                    <div className="rounded-lg bg-white/10 px-3 py-1.5 text-right">
                      <div className="text-[10px] text-white/50">Tinggi</div>
                      <div className="font-mono text-sm">{current.height}</div>
                    </div>
                  </div>
                  <p className="mt-3 text-[13px] leading-relaxed text-white/75">{current.desc}</p>
                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    <span className="text-[11px] text-white/50">Variasi:</span>
                    {Array.from({ length: current.variants + 2 }).map((_, v) => (
                      <button
                        key={v}
                        onClick={() => chooseAsset(current.id, v)}
                        className={`h-8 w-8 rounded-lg text-xs font-semibold transition ${asset.variant === v ? "bg-lime-300 text-black" : "bg-white/10 hover:bg-white/20"}`}
                      >
                        {String.fromCharCode(65 + v)}
                      </button>
                    ))}
                    <label className="ml-auto flex items-center gap-2 text-[11px] text-white/70">
                      <input
                        type="checkbox"
                        checked={autoRot}
                        onChange={(e) => {
                          setAutoRot(e.target.checked);
                          engineRef.current?.setAutoRotate(e.target.checked);
                        }}
                        className="h-4 w-4 accent-lime-300"
                      />
                      Turntable
                    </label>
                  </div>
                </div>
              </div>
            )
          )}

          {/* ---------- stats ---------- */}
          <div className="absolute bottom-6 left-5 hidden font-mono text-[10.5px] leading-relaxed text-white/55 md:block">
            <div>
              <span className={stats.fps >= 45 ? "text-lime-300" : stats.fps >= 25 ? "text-yellow-300" : "text-red-400"}>{stats.fps} FPS</span> · {quality.toUpperCase()}
            </div>
            <div>{stats.trees.toLocaleString()} pohon · {(stats.tris / 1e6).toFixed(2)}M tris</div>
            <div>{stats.calls} draw calls</div>
            <div className="mt-1 text-white/35">Drag: orbit · Scroll: zoom · H: sembunyikan UI</div>
          </div>
        </>
      )}

      {/* ---------- loading ---------- */}
      {loading && (
        <div className="absolute inset-0 z-50 grid place-items-center bg-[radial-gradient(ellipse_at_top,#1f3b2a,#08100b_70%)]">
          <div className="w-[min(460px,85vw)] text-center">
            <div className="mb-6 text-5xl">🌲🌳🌿</div>
            <h1 className="text-2xl font-semibold tracking-tight">Touge Forest</h1>
            <p className="mt-1 text-sm text-white/55">Realistic procedural forest — Japanese mountain road</p>
            <div className="mt-8 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-gradient-to-r from-lime-300 to-emerald-400 transition-all duration-500" style={{ width: `${Math.round(loading.p * 100)}%` }} />
            </div>
            <p className="mt-3 min-h-[2.5em] text-xs text-white/60">{error ? `⚠️ ${error}` : loading.msg}</p>
          </div>
        </div>
      )}
    </div>
  );
}
