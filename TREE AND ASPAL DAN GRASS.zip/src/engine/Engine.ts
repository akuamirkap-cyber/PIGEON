import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import {
  EffectComposer, RenderPass, EffectPass, BloomEffect, ToneMappingEffect, ToneMappingMode,
  HueSaturationEffect, BrightnessContrastEffect, SMAAEffect, GodRaysEffect,
  KernelSize,
} from "postprocessing";
import { createAllTextures, type TextureSet } from "./textures";
import { createLibrary, type AssetDef } from "./library";
import { buildWorld, createGroundMaterial, type World } from "./world";
import { globalUniforms, grassMaterial } from "./materials";
import { VolumetricLightEffect } from "./volumetric";
import { makeGrassTuft, type TreeAsset } from "./trees";
import { mulberry32, rand, smoothstep } from "./noise";

export type Quality = "low" | "high" | "ultra";
export type CamPreset = "hillside" | "roadlevel" | "canopy" | "drive" | "free";
export type Mode = "scene" | "gallery";

export interface Settings {
  sunElevation: number;
  sunAzimuth: number;
  godRays: number;
  fog: number;
  wind: number;
  exposure: number;
  smoke: boolean;
}

export const defaultSettings: Settings = {
  sunElevation: 42,
  sunAzimuth: 28,
  godRays: 1,
  fog: 1,
  wind: 1,
  exposure: 1,
  smoke: false,
};

const QUALITY = {
  low: { pr: 0.8, shadow: 2048, density: 0.6, grass: 0.45, msaa: 0, bushShadow: false },
  high: { pr: 1, shadow: 4096, density: 0.85, grass: 0.8, msaa: 4, bushShadow: true },
  ultra: { pr: 1.5, shadow: 4096, density: 1.05, grass: 1.15, msaa: 4, bushShadow: true },
};

const nextFrame = () => new Promise<void>((r) => requestAnimationFrame(() => setTimeout(r, 0)));

function skyMaterial() {
  return new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      uZenith: { value: new THREE.Color("#5d8fc4") },
      uHorizon: { value: new THREE.Color("#c9dbdc") },
      uSunColor: { value: new THREE.Color(1, 0.93, 0.8) },
    },
    vertexShader: `varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`,
    fragmentShader: `
      uniform vec3 uSunDir; uniform vec3 uZenith; uniform vec3 uHorizon; uniform vec3 uSunColor;
      varying vec3 vDir;
      void main(){
        vec3 d = normalize(vDir);
        float h = max(d.y, 0.0);
        vec3 col = mix(uHorizon, uZenith, pow(h, 0.5));
        float s = max(dot(d, uSunDir), 0.0);
        col += uSunColor * (pow(s, 1800.0) * 60.0 + pow(s, 60.0) * 1.2 + pow(s, 8.0) * 0.35);
        if (d.y < 0.0) col = mix(uHorizon, uHorizon * 0.6, min(-d.y * 3.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
}

interface SceneRig {
  scene: THREE.Scene;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  sky: THREE.Mesh;
  skyMat: THREE.ShaderMaterial;
  fog: THREE.FogExp2;
  baseFog: number;
}

export class Engine {
  canvas: HTMLCanvasElement;
  renderer!: THREE.WebGLRenderer;
  camera!: THREE.PerspectiveCamera;
  controls!: OrbitControls;
  composer!: EffectComposer;
  renderPass!: RenderPass;
  vol!: VolumetricLightEffect;
  godRays!: GodRaysEffect;
  sunMesh!: THREE.Mesh;
  bloom!: BloomEffect;
  tex!: TextureSet;
  lib!: AssetDef[];
  world!: World;
  main!: SceneRig;
  gal!: SceneRig;
  galleryHolder = new THREE.Group();
  quality: Quality;
  settings: Settings = { ...defaultSettings };
  mode: Mode = "scene";
  preset: CamPreset = "hillside";
  sunDir = new THREE.Vector3();
  clock = new THREE.Clock();
  running = false;
  raf = 0;
  driveT = 0;
  tween: { from: THREE.Vector3; to: THREE.Vector3; tFrom: THREE.Vector3; tTo: THREE.Vector3; t: number; dur: number } | null = null;
  fps = 0;
  private fpsAcc = 0;
  private fpsN = 0;
  onStats?: (s: { fps: number; trees: number; calls: number; tris: number }) => void;
  galleryAsset: { def: AssetDef; variant: number } | null = null;
  galleryCache = new Map<string, TreeAsset>();
  autoRotate = true;

  constructor(canvas: HTMLCanvasElement, quality: Quality) {
    this.canvas = canvas;
    this.quality = quality;
  }

  async init(progress: (msg: string, p: number) => void) {
    const Q = QUALITY[this.quality];
    progress("Menyiapkan renderer WebGL2…", 0.03);
    await nextFrame();
    const renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: false, powerPreference: "high-performance", stencil: false, depth: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2) * Q.pr > 2 ? 2 : Math.min(window.devicePixelRatio, 2) * Q.pr);
    renderer.setSize(this.canvas.clientWidth, this.canvas.clientHeight, false);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.toneMapping = THREE.NoToneMapping;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.info.autoReset = false;
    this.renderer = renderer;

    this.camera = new THREE.PerspectiveCamera(50, this.canvas.clientWidth / this.canvas.clientHeight, 0.1, 1500);

    progress("Melukis tekstur prosedural: aspal, serasah daun, lumut, kulit kayu…", 0.08);
    await nextFrame();
    this.tex = createAllTextures();
    const aniso = renderer.capabilities.getMaxAnisotropy();
    Object.values(this.tex).forEach((t: unknown) => {
      if (t instanceof THREE.Texture) t.anisotropy = Math.min(aniso, 8);
      else if (t && typeof t === "object") Object.values(t).forEach((x) => { if (x instanceof THREE.Texture) x.anisotropy = Math.min(aniso, 12); });
    });

    progress("Membuat material daun tembus cahaya & angin…", 0.35);
    await nextFrame();
    this.lib = createLibrary(this.tex);

    // ---- main scene
    this.main = this.makeRig(Q.shadow, "#a6bab2", 0.0029);
    progress("Menumbuhkan hutan: Sugi, Hinoki, Momiji, Buna, semak & rumput…", 0.45);
    await nextFrame();
    this.world = buildWorld(this.main.scene, this.tex, this.lib, { density: Q.density, grass: Q.grass, shadowsOnBushes: Q.bushShadow });

    // ---- gallery scene
    progress("Menyiapkan studio aset 3D…", 0.75);
    await nextFrame();
    this.gal = this.makeRig(2048, "#b8c8c2", 0.006);
    this.gal.sun.shadow.camera.left = this.gal.sun.shadow.camera.bottom = -22;
    this.gal.sun.shadow.camera.right = this.gal.sun.shadow.camera.top = 22;
    this.gal.sun.shadow.camera.updateProjectionMatrix();
    this.buildGalleryGround();
    this.gal.scene.add(this.galleryHolder);

    // ---- env map from sky
    const pm = new THREE.PMREMGenerator(renderer);
    const envScene = new THREE.Scene();
    const envSky = new THREE.Mesh(new THREE.SphereGeometry(10, 32, 16), this.main.skyMat);
    envScene.add(envSky);
    this.updateSun();
    const env = pm.fromScene(envScene, 0.04).texture;
    this.main.scene.environment = env;
    this.main.scene.environmentIntensity = 0.42;
    this.gal.scene.environment = env;
    this.gal.scene.environmentIntensity = 0.7;

    // ---- controls
    this.controls = new OrbitControls(this.camera, this.canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.maxPolarAngle = Math.PI * 0.94;

    // ---- post-processing
    progress("Menyusun pipeline sinematik: volumetric god rays, bloom, ACES…", 0.82);
    await nextFrame();
    this.setupComposer(Q.msaa);

    this.setPreset("hillside", true);
    progress("Kompilasi shader…", 0.9);
    await nextFrame();
    try {
      renderer.compile(this.main.scene, this.camera);
    } catch {
      /* ignore */
    }
    progress("Siap", 1);
    window.addEventListener("resize", this.onResize);
    this.onResize();
  }

  private makeRig(shadowSize: number, fogColor: string, fogDensity: number): SceneRig {
    const scene = new THREE.Scene();
    const skyMat = skyMaterial();
    const sky = new THREE.Mesh(new THREE.SphereGeometry(1000, 48, 24), skyMat);
    sky.frustumCulled = false;
    sky.renderOrder = -1;
    scene.add(sky);
    const fog = new THREE.FogExp2(fogColor, fogDensity);
    scene.fog = fog;
    scene.background = new THREE.Color(fogColor);
    const sun = new THREE.DirectionalLight(0xfff1dc, 3.4);
    sun.castShadow = true;
    sun.shadow.mapSize.set(shadowSize, shadowSize);
    const c = sun.shadow.camera;
    c.left = c.bottom = -70;
    c.right = c.top = 70;
    c.near = 1;
    c.far = 520;
    c.updateProjectionMatrix();
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.05;
    sun.shadow.radius = 2;
    scene.add(sun, sun.target);
    const hemi = new THREE.HemisphereLight(0xc3d6e2, 0x4a3b28, 0.75);
    scene.add(hemi);
    return { scene, sun, hemi, sky, skyMat, fog, baseFog: fogDensity };
  }

  private buildGalleryGround() {
    const geo = new THREE.CircleGeometry(90, 128, 0, Math.PI * 2);
    geo.rotateX(-Math.PI / 2);
    const p = geo.attributes.position as THREE.BufferAttribute;
    const uv = geo.attributes.uv as THREE.BufferAttribute;
    const moss = new Float32Array(p.count), ao = new Float32Array(p.count);
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), z = p.getZ(i);
      const d = Math.hypot(x, z);
      uv.setXY(i, x / 4, z / 4);
      moss[i] = smoothstep(5, 14, d) * 0.9;
      ao[i] = 1;
      p.setY(i, Math.max(0, d - 20) * 0.06);
    }
    geo.setAttribute("aMoss", new THREE.BufferAttribute(moss, 1));
    geo.setAttribute("aAO", new THREE.BufferAttribute(ao, 1));
    geo.computeVertexNormals();
    const g = new THREE.Mesh(geo, createGroundMaterial(this.tex));
    g.receiveShadow = true;
    this.gal.scene.add(g);
    // grass ring
    const tuft = makeGrassTuft();
    const r = mulberry32(5);
    const n = 5000;
    const im = new THREE.InstancedMesh(tuft, grassMaterial(this.tex.grass), n);
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
    for (let i = 0; i < n; i++) {
      const a = rand(r, 0, Math.PI * 2), d = 7 + Math.pow(r(), 0.8) * 40;
      q.setFromEuler(new THREE.Euler(0, rand(r, 0, 6.28), 0));
      const sc = rand(r, 0.6, 1.4);
      s.set(sc, sc * rand(r, 0.8, 1.3), sc);
      m.compose(new THREE.Vector3(Math.cos(a) * d, Math.max(0, d - 20) * 0.06 - 0.03, Math.sin(a) * d), q, s);
      im.setMatrixAt(i, m);
      im.setColorAt(i, new THREE.Color(rand(r, 0.8, 1.1), rand(r, 0.85, 1.1), rand(r, 0.7, 0.95)));
    }
    im.receiveShadow = true;
    this.gal.scene.add(im);
    // background ring of conifers for context
    const cedar = this.lib.find((d) => d.id === "cedar")!;
    const bgA = cedar.make(4242);
    const cnt = 46;
    const lm = new THREE.InstancedMesh(bgA.leaves, cedar.leaf.mat, cnt);
    const bm = new THREE.InstancedMesh(bgA.bark!, cedar.bark!.mat, cnt);
    for (let i = 0; i < cnt; i++) {
      const a = (i / cnt) * Math.PI * 2 + rand(r, -0.05, 0.05), d = rand(r, 55, 80);
      q.setFromEuler(new THREE.Euler(0, rand(r, 0, 6.28), 0));
      const sc = rand(r, 0.85, 1.15);
      s.setScalar(sc);
      m.compose(new THREE.Vector3(Math.cos(a) * d, Math.max(0, d - 20) * 0.06 - 0.2, Math.sin(a) * d), q, s);
      lm.setMatrixAt(i, m);
      bm.setMatrixAt(i, m);
    }
    lm.computeBoundingSphere();
    bm.computeBoundingSphere();
    this.gal.scene.add(lm, bm);
  }

  private setupComposer(msaa: number) {
    const composer = new EffectComposer(this.renderer, { frameBufferType: THREE.HalfFloatType, multisampling: msaa });
    this.renderPass = new RenderPass(this.main.scene, this.camera);
    composer.addPass(this.renderPass);

    this.vol = new VolumetricLightEffect();
    composer.addPass(new EffectPass(this.camera, this.vol));

    this.sunMesh = new THREE.Mesh(
      new THREE.SphereGeometry(18, 24, 12),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 0.94, 0.82), transparent: true, depthWrite: false, fog: false }),
    );
    this.sunMesh.frustumCulled = false;
    this.godRays = new GodRaysEffect(this.camera, this.sunMesh, {
      height: 480,
      kernelSize: KernelSize.SMALL,
      density: 0.97,
      decay: 0.93,
      weight: 0.42,
      exposure: 0.62,
      samples: 72,
      clampMax: 1,
      blur: true,
    });
    composer.addPass(new EffectPass(this.camera, this.godRays));

    this.bloom = new BloomEffect({ intensity: 0.7, luminanceThreshold: 0.82, luminanceSmoothing: 0.25, mipmapBlur: true, radius: 0.72 });
    composer.addPass(new EffectPass(this.camera, this.bloom));

    const tone = new ToneMappingEffect({ mode: ToneMappingMode.ACES_FILMIC });
    const hue = new HueSaturationEffect({ saturation: 0.24, hue: 0 });
    const bc = new BrightnessContrastEffect({ brightness: 0.01, contrast: 0.12 });
    composer.addPass(new EffectPass(this.camera, tone, hue, bc));
    if (!msaa) composer.addPass(new EffectPass(this.camera, new SMAAEffect()));
    this.composer = composer;
  }

  // -------------------- settings --------------------
  applySettings(s: Partial<Settings>) {
    Object.assign(this.settings, s);
    this.updateSun();
  }

  updateSun() {
    const st = this.settings;
    const el = THREE.MathUtils.degToRad(st.sunElevation);
    const az = THREE.MathUtils.degToRad(st.sunAzimuth);
    // azimuth 0 => sun straight down the road (-z), positive => to the right
    this.sunDir.set(Math.sin(az) * Math.cos(el), Math.sin(el), -Math.cos(az) * Math.cos(el)).normalize();
    const warm = smoothstep(4, 40, st.sunElevation);
    const sunCol = new THREE.Color(1, 0.62 + 0.33 * warm, 0.38 + 0.47 * warm);
    const zen = new THREE.Color("#3f6fae").lerp(new THREE.Color("#5d8fc4"), warm);
    const hor = new THREE.Color("#e9c9a2").lerp(new THREE.Color("#c9dbdc"), warm);
    for (const rig of [this.main, this.gal]) {
      if (!rig) continue;
      rig.sun.color.copy(sunCol);
      rig.sun.intensity = 4.4 * (0.35 + 0.65 * smoothstep(-2, 25, st.sunElevation));
      const u = rig.skyMat.uniforms;
      u.uSunDir.value.copy(this.sunDir);
      u.uSunColor.value.copy(sunCol);
      u.uZenith.value.copy(zen);
      u.uHorizon.value.copy(hor);
      rig.hemi.intensity = 0.42 + 0.18 * warm;
      rig.fog.density = rig.baseFog * st.fog;
      const fogCol = new THREE.Color("#8aa59d").lerp(hor, 0.15);
      if (rig === this.gal) fogCol.lerp(new THREE.Color("#c4d2cc"), 0.5);
      rig.fog.color.copy(fogCol);
      (rig.scene.background as THREE.Color).copy(fogCol);
    }
    globalUniforms.uWind.value = st.wind;
    if (this.vol) {
      this.vol.uniforms.get("uIntensity")!.value = st.godRays * (this.mode === "gallery" ? 0.6 : 1);
      this.vol.uniforms.get("uDensity")!.value = 0.0065 * (0.3 + 0.7 * st.fog);
      this.vol.uniforms.get("uSunColor")!.value.copy(sunCol).multiplyScalar(0.95);
      this.vol.uniforms.get("uExposure")!.value = st.exposure;
      (this.vol.uniforms.get("uAmbient")!.value as THREE.Color).copy(this.main.fog.color);
    }
    if (this.godRays) {
      this.godRays.godRaysMaterial.uniforms.weight.value = 0.42 * st.godRays;
      (this.sunMesh.material as THREE.MeshBasicMaterial).color.copy(sunCol);
    }
    if (this.world) {
      this.world.smoke.visible = st.smoke;
      this.world.smokeUniforms.uFogColor.value.copy(this.main.fog.color);
      this.world.smokeUniforms.uFogDensity.value = this.main.fog.density;
      this.world.smokeUniforms.uSun.value.copy(sunCol);
    }
  }

  // -------------------- cameras --------------------
  setPreset(p: CamPreset, instant = false) {
    this.preset = p;
    const w = this.world;
    let pos: THREE.Vector3, tgt: THREE.Vector3;
    switch (p) {
      case "hillside":
        pos = w.pointAt(212, -4.4, 0);
        pos.y = w.groundHeight(pos.x, pos.z) + 3.6;
        tgt = w.pointAt(300, 2.5, 2.2);
        break;
      case "roadlevel":
        pos = w.pointAt(228, -4.9, 0);
        pos.y = w.groundHeight(pos.x, pos.z) + 1.05;
        tgt = w.pointAt(285, -0.5, 2.0);
        break;
      case "canopy":
        pos = w.pointAt(250, 0, 1.7);
        tgt = pos.clone().add(new THREE.Vector3(this.sunDir.x, Math.max(0.35, this.sunDir.y * 0.8), this.sunDir.z).normalize().multiplyScalar(20));
        break;
      case "drive":
        this.driveT = 180;
        this.controls.enabled = false;
        this.tween = null;
        return;
      default:
        this.controls.enabled = true;
        return;
    }
    this.controls.enabled = true;
    if (instant) {
      this.camera.position.copy(pos);
      this.controls.target.copy(tgt);
      this.controls.update();
      this.tween = null;
    } else {
      this.tween = { from: this.camera.position.clone(), to: pos, tFrom: this.controls.target.clone(), tTo: tgt, t: 0, dur: 1.8 };
    }
  }

  setMode(m: Mode) {
    this.mode = m;
    const rig = m === "scene" ? this.main : this.gal;
    this.renderPass.mainScene = rig.scene;
    // RenderPass in postprocessing keeps the scene reference here:
    (this.renderPass as unknown as { scene: THREE.Scene }).scene = rig.scene;
    this.controls.autoRotate = m === "gallery" && this.autoRotate;
    this.controls.autoRotateSpeed = 0.6;
    if (m === "scene") {
      this.setPreset(this.preset === "drive" ? "drive" : this.preset, true);
    } else if (this.galleryAsset) {
      this.frameGallery(true);
    }
    this.updateSun();
  }

  showAsset(id: string, variant = 0) {
    const def = this.lib.find((d) => d.id === id);
    if (!def) return;
    this.galleryAsset = { def, variant };
    this.galleryHolder.clear();
    const k = `${id}|${variant}`;
    if (!this.galleryCache.has(k)) this.galleryCache.set(k, def.make(1000 + variant * 97 + def.id.length * 13));
    const a = this.galleryCache.get(k)!;
    if (a.bark && def.bark) {
      const b = new THREE.Mesh(a.bark, def.bark.mat);
      b.customDepthMaterial = def.bark.depth;
      b.castShadow = b.receiveShadow = true;
      this.galleryHolder.add(b);
    }
    const l = new THREE.Mesh(a.leaves, def.leaf.mat);
    l.customDepthMaterial = def.leaf.depth;
    l.castShadow = l.receiveShadow = true;
    this.galleryHolder.add(l);
    if (this.mode === "gallery") this.frameGallery(false);
  }

  private frameGallery(instant: boolean) {
    if (!this.galleryAsset) return;
    const box = new THREE.Box3().setFromObject(this.galleryHolder);
    const size = box.getSize(new THREE.Vector3());
    const c = box.getCenter(new THREE.Vector3());
    const h = Math.max(size.y, size.x * 0.8, 1.2);
    const dist = h * 1.25 + 2;
    const dir = new THREE.Vector3(-this.sunDir.x, 0, -this.sunDir.z).normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), 0.9);
    const pos = c.clone().addScaledVector(dir, dist);
    pos.y = Math.max(1.2, c.y * 0.45 + h * 0.12);
    const tgt = new THREE.Vector3(c.x, c.y * 0.85, c.z);
    this.controls.enabled = true;
    if (instant) {
      this.camera.position.copy(pos);
      this.controls.target.copy(tgt);
      this.tween = null;
    } else {
      this.tween = { from: this.camera.position.clone(), to: pos, tFrom: this.controls.target.clone(), tTo: tgt, t: 0, dur: 1.4 };
    }
  }

  setAutoRotate(v: boolean) {
    this.autoRotate = v;
    this.controls.autoRotate = this.mode === "gallery" && v;
  }

  // -------------------- loop --------------------
  start() {
    this.running = true;
    this.clock.start();
    const loop = () => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(loop);
      this.frame();
    };
    loop();
  }

  private frame() {
    const dt = Math.min(this.clock.getDelta(), 0.05);
    const time = this.clock.elapsedTime;
    globalUniforms.uTime.value = time;

    if (this.tween) {
      const tw = this.tween;
      tw.t += dt / tw.dur;
      const k = tw.t >= 1 ? 1 : 1 - Math.pow(1 - tw.t, 3);
      this.camera.position.lerpVectors(tw.from, tw.to, k);
      this.controls.target.lerpVectors(tw.tFrom, tw.tTo, k);
      if (tw.t >= 1) this.tween = null;
    }

    if (this.mode === "scene" && this.preset === "drive") {
      const w = this.world;
      this.driveT += dt * 11 / (w.roadLen / w.N);
      if (this.driveT > w.N - 80) this.driveT = 150;
      const i = this.driveT;
      const lat = Math.sin(time * 0.25) * 1.6 - 0.6;
      const p = w.pointAt(i, lat, 0);
      p.y += 1.25 + Math.sin(time * 0.6) * 0.15;
      const t = w.pointAt(i + 22, lat * 0.4 + Math.sin(time * 0.17) * 2, 1.2);
      this.camera.position.lerp(p, 0.12);
      this.controls.target.lerp(t, 0.08);
      this.camera.lookAt(this.controls.target);
    } else {
      this.controls.update();
    }

    const rig = this.mode === "scene" ? this.main : this.gal;
    // keep sky + sun centred on camera
    rig.sky.position.copy(this.camera.position);
    this.sunMesh.position.copy(this.camera.position).addScaledVector(this.sunDir, 800);
    this.sunMesh.updateMatrixWorld(true);
    // shadow frustum follows the view with texel snapping
    const fwd = new THREE.Vector3();
    this.camera.getWorldDirection(fwd);
    fwd.y = 0;
    fwd.normalize();
    const centre = this.mode === "scene" ? this.camera.position.clone().addScaledVector(fwd, 38) : new THREE.Vector3(0, 0, 0);
    const sun = rig.sun;
    const cam = sun.shadow.camera;
    const span = cam.right - cam.left;
    const texel = span / sun.shadow.mapSize.x;
    const lz = this.sunDir.clone();
    const lx = new THREE.Vector3(0, 1, 0).cross(lz).normalize();
    const ly = lz.clone().cross(lx).normalize();
    const px = Math.round(centre.dot(lx) / texel) * texel;
    const py = Math.round(centre.dot(ly) / texel) * texel;
    const pz = centre.dot(lz);
    const snapped = lx.multiplyScalar(px).addScaledVector(ly, py).addScaledVector(lz, pz);
    sun.target.position.copy(snapped);
    sun.position.copy(snapped).addScaledVector(this.sunDir, 250);
    sun.target.updateMatrixWorld();

    this.vol.sync(this.camera, sun, this.sunDir, time);
    this.vol.uniforms.get("uGroundY")!.value = this.mode === "scene" ? this.world.groundHeight(this.camera.position.x, this.camera.position.z) : 0;
    this.vol.uniforms.get("uMaxDist")!.value = this.mode === "scene" ? 110 : 60;

    this.renderer.info.reset();
    this.composer.render(dt);

    this.fpsAcc += dt;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.fps = Math.round(this.fpsN / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsN = 0;
      const info = this.renderer.info.render;
      this.onStats?.({ fps: this.fps, trees: this.world.treeCount, calls: info.calls, tris: info.triangles });
    }
  }

  onResize = () => {
    const w = this.canvas.clientWidth, h = this.canvas.clientHeight;
    if (!w || !h) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    this.composer?.setSize(w, h, false);
  };

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    this.controls?.dispose();
    this.composer?.dispose();
    this.renderer?.dispose();
    this.renderer?.forceContextLoss();
  }
}
