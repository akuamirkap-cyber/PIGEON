import { Canvas } from "@react-three/fiber";
import { Suspense, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { CARS, CATEGORY_LABEL, type Category, type CarSpec } from "./cars";
import { exportAllZip, exportGLB, exportPNG, exportVoxFile } from "./export";
import { getCarAsset } from "./three/assets";
import { World, type Mode } from "./three/scenes";

type Filter = "all" | Category;
const FILTERS: Filter[] = ["all", "blacklist", "bonus", "police", "initiald", "city", "special"];
const MODES: { id: Mode; label: string; icon: string }[] = [
  { id: "garage", label: "Garasi", icon: "🏁" },
  { id: "road", label: "Crossy Road", icon: "🐔" },
  { id: "lineup", label: "Parkiran", icon: "🅿️" },
];
const CAT_BADGE: Record<Category, { text: string; cls: string }> = {
  blacklist: { text: "BLACKLIST", cls: "bg-red-600" },
  bonus: { text: "BONUS", cls: "bg-orange-500" },
  police: { text: "ROCKPORT PD", cls: "bg-blue-600" },
  initiald: { text: "INITIAL D", cls: "bg-zinc-100 text-black" },
  city: { text: "KOTA", cls: "bg-amber-400 text-black" },
  special: { text: "SPESIAL", cls: "bg-emerald-600" },
};
const ICON: Record<string, string> = {
  taxi: "🚕",
  bluebird: "🚕",
  firetruck: "🚒",
  schoolbus: "🚌",
  tank: "💥",
  rally: "🏁",
  mrbean: "🧸",
  "mrbean-chair": "🛋️",
};
const chipTag = (c: CarSpec) =>
  c.rank ? `#${c.rank}` : ICON[c.id] ?? (c.category === "initiald" ? "86" : c.category === "police" ? "PD" : "★");

function Chunky({ children, onClick, active, className = "", title }: { children: ReactNode; onClick?: () => void; active?: boolean; className?: string; title?: string }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`font-bungee rounded-xl border-b-4 px-3 py-1.5 text-xs transition active:translate-y-[2px] active:border-b-2 md:text-sm ${
        active ? "border-yellow-600 bg-yellow-300 text-black" : "border-black/60 bg-black/60 text-white backdrop-blur hover:bg-black/75"
      } ${className}`}
    >
      {children}
    </button>
  );
}

function StatBar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-[11px] font-semibold uppercase tracking-wider text-white/70">
        <span>{label}</span>
        <span className="text-yellow-300">{value}/10</span>
      </div>
      <div className="flex gap-[3px]">
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={i}
            className={`h-2.5 flex-1 rounded-[2px] ${i < value ? "bg-yellow-300 shadow-[inset_0_-3px_0_rgba(0,0,0,0.25)]" : "bg-white/10"}`}
          />
        ))}
      </div>
    </div>
  );
}

function RankBadge({ car }: { car: CarSpec }) {
  const b = CAT_BADGE[car.category];
  return (
    <div className="flex items-stretch gap-2">
      {car.rank && (
        <div className="font-bungee flex items-center rounded-lg border-b-4 border-red-900 bg-red-600 px-2.5 text-2xl leading-none text-white">#{car.rank}</div>
      )}
      <div className="flex flex-col justify-center">
        <span className={`font-bungee w-fit rounded px-1.5 py-0.5 text-[10px] tracking-widest text-white ${b.cls}`}>{b.text}</span>
        {car.bounty ? (
          <span className="mt-1 text-xs font-bold text-white/80">
            Bounty <span className="text-yellow-300">${car.bounty.toLocaleString("en-US")}</span>
          </span>
        ) : (
          <span className="mt-1 text-xs font-bold text-white/60">{CATEGORY_LABEL[car.category]}</span>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [mode, setMode] = useState<Mode>("garage");
  const [idx, setIdx] = useState(0);
  const [night, setNight] = useState(false);
  const [lightsOn, setLightsOn] = useState(false);
  const [autoRotate, setAutoRotate] = useState(true);
  const [filter, setFilter] = useState<Filter>("all");
  const [hover, setHover] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chipRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  const car = CARS[idx];
  const asset = useMemo(() => getCarAsset(car.id), [car.id]);
  const assets = useMemo(() => Object.fromEntries(CARS.map((c) => [c.id, getCarAsset(c.id)])), []);
  const list = useMemo(() => (filter === "all" ? CARS : CARS.filter((c) => c.category === filter)), [filter]);
  const lights = lightsOn || night;
  const hoverCar = hover ? CARS.find((c) => c.id === hover) : undefined;

  const selectId = useCallback((id: string) => {
    const i = CARS.findIndex((c) => c.id === id);
    if (i >= 0) setIdx(i);
  }, []);

  const step = useCallback(
    (d: number) => {
      const pool = list.length ? list : CARS;
      const cur = pool.findIndex((c) => c.id === CARS[idx].id);
      const next = pool[(cur + d + pool.length) % pool.length] ?? pool[0];
      selectId(next.id);
    },
    [list, idx, selectId]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") step(1);
      else if (e.key === "ArrowLeft") step(-1);
      else if (e.key.toLowerCase() === "l") setLightsOn((v) => !v);
      else if (e.key.toLowerCase() === "n") setNight((v) => !v);
      else if (e.key === " ") {
        e.preventDefault();
        setAutoRotate((v) => !v);
      } else if (e.key === "1") setMode("garage");
      else if (e.key === "2") setMode("road");
      else if (e.key === "3") setMode("lineup");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [step]);

  useEffect(() => {
    chipRefs.current[car.id]?.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
  }, [car.id, filter]);

  useEffect(() => {
    setHover(null);
    document.body.style.cursor = "";
  }, [mode]);

  const pick = useCallback(
    (id: string) => {
      selectId(id);
      setMode("garage");
    },
    [selectId]
  );

  const [zipping, setZipping] = useState(false);
  const doZip = async () => {
    setZipping(true);
    try {
      await exportAllZip();
    } finally {
      setZipping(false);
    }
  };
  const doGLB = async () => {
    setBusy(true);
    try {
      await exportGLB(car.id);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className={`relative h-[100dvh] w-full select-none overflow-hidden ${
        night
          ? "bg-[linear-gradient(180deg,#060a18_0%,#121a36_55%,#1d2850_100%)]"
          : "bg-[linear-gradient(180deg,#6cc1ff_0%,#b4e2ff_45%,#e8f8ff_100%)]"
      }`}
    >
      <Canvas
        shadows
        flat
        dpr={[1, 2]}
        gl={{ preserveDrawingBuffer: true, antialias: true }}
        camera={{ position: [4.3, 2.5, 4.7], fov: 35, near: 0.1, far: 300 }}
        onCreated={({ gl }) => {
          canvasRef.current = gl.domElement;
        }}
      >
        <Suspense fallback={null}>
          <World mode={mode} carId={car.id} night={night} lights={lights} autoRotate={autoRotate} hover={hover} onPick={pick} onHover={setHover} />
        </Suspense>
      </Canvas>

      <div className="vignette pointer-events-none absolute inset-0" />

      {/* ── header ── */}
      <header className="pointer-events-none absolute inset-x-0 top-0 flex flex-wrap items-start justify-between gap-2 p-3 md:p-5">
        <div className="pointer-events-auto rounded-2xl border-b-4 border-black/70 bg-black/65 px-4 py-2.5 backdrop-blur">
          <div className="font-bungee text-[9px] tracking-[0.42em] text-yellow-300 md:text-[10px]">VOXEL · CROSSY STYLE</div>
          <h1 className="font-bungee text-2xl leading-none text-white md:text-[34px]">
            MOST <span className="text-yellow-300">WANTED</span>
          </h1>
          <div className="mt-0.5 text-[10px] font-semibold text-white/70 md:text-xs">NFS Most Wanted 2005 + Initial D · aset 3D voxel</div>
        </div>
        <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-1.5 md:gap-2">
          {MODES.map((m) => (
            <Chunky key={m.id} active={mode === m.id} onClick={() => setMode(m.id)} title={m.label}>
              <span className="mr-1">{m.icon}</span>
              <span className="hidden sm:inline">{m.label}</span>
            </Chunky>
          ))}
          <Chunky onClick={() => setNight((v) => !v)} active={night} title="Siang / Malam (N)">
            {night ? "🌙" : "☀️"}
            <span className="ml-1 hidden lg:inline">{night ? "Malam" : "Siang"}</span>
          </Chunky>
          <Chunky onClick={() => setLightsOn((v) => !v)} active={lights} title="Lampu & pop-up (L)">
            💡<span className="ml-1 hidden lg:inline">Lampu</span>
          </Chunky>
        </div>
      </header>

      {/* ── garage info card ── */}
      {mode === "garage" && (
        <aside className="pointer-events-auto absolute left-3 top-[118px] w-[min(340px,calc(100%-24px))] md:left-5 md:top-[132px]">
          <div className="no-scrollbar max-h-[calc(100dvh-300px)] overflow-y-auto rounded-2xl border-b-4 border-black/70 bg-black/65 p-3.5 text-white shadow-2xl backdrop-blur md:p-4">
            <RankBadge car={car} />
            <h2 className="font-bungee mt-2.5 text-lg leading-tight md:text-2xl">{car.name}</h2>
            <p className="text-xs font-semibold text-white/70 md:text-sm">
              Pengemudi: <span className="text-yellow-300">{car.driver}</span>
            </p>
            <div className="mt-3 hidden space-y-2 sm:block">
              <StatBar label="Top Speed" value={car.stats[0]} />
              <StatBar label="Akselerasi" value={car.stats[1]} />
              <StatBar label="Handling" value={car.stats[2]} />
            </div>
            <p className="mt-3 hidden text-[13px] leading-snug text-white/85 md:block">{car.desc}</p>
            <div className="mt-3 flex items-center gap-2">
              <div className="flex gap-1">
                {asset.swatches.map((c) => (
                  <span key={c} className="h-4 w-4 rounded-[4px] border border-white/30" style={{ background: c }} />
                ))}
              </div>
              <span className="text-[11px] font-semibold text-white/60">
                {asset.voxels.toLocaleString()} voxel · {asset.dims[0]}×{asset.dims[1]}×{asset.dims[2]}
              </span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-1.5">
              <Chunky active onClick={() => exportVoxFile(car.id)} className="!px-1 !text-[11px]" title="MagicaVoxel">
                ⬇ .VOX
              </Chunky>
              <Chunky active onClick={doGLB} className="!px-1 !text-[11px]" title="glTF binary">
                {busy ? "…" : "⬇ .GLB"}
              </Chunky>
              <Chunky active onClick={() => exportPNG(canvasRef.current, car.id)} className="!px-1 !text-[11px]" title="Screenshot">
                📸 PNG
              </Chunky>
            </div>
            <Chunky onClick={doZip} className="mt-1.5 w-full !text-[11px]" title="Semua mobil: .vox + .glb">
              {zipping ? `Mengemas ${CARS.length} kendaraan…` : `📦 ZIP semua ${CARS.length} kendaraan (.vox + .glb)`}
            </Chunky>
            <div className="mt-2 flex gap-1.5">
              <Chunky onClick={() => setAutoRotate((v) => !v)} active={autoRotate} className="flex-1 !text-[11px]">
                {autoRotate ? "⟳ Putar: ON" : "⟳ Putar: OFF"}
              </Chunky>
              <Chunky onClick={() => setLightsOn((v) => !v)} active={lights} className="flex-1 !text-[11px]">
                {(() => {
                  const kinds = new Set(asset.parts.map((p) => p.kind));
                  if (kinds.has("popup")) return lights ? "Pop-up: BUKA" : "Pop-up: TUTUP";
                  if (kinds.has("ladder")) return lights ? "Tangga: NAIK" : "Tangga: TURUN";
                  if (kinds.has("swing")) return lights ? "STOP arm: BUKA" : "STOP arm: TUTUP";
                  return lights ? "Lampu: ON" : "Lampu: OFF";
                })()}
              </Chunky>
            </div>
          </div>
          <p className="mt-2 hidden text-[11px] font-semibold text-black/60 md:block" style={{ color: night ? "rgba(255,255,255,.55)" : undefined }}>
            Drag = putar · Scroll = zoom · ←/→ ganti mobil · L lampu · N malam · Spasi auto-putar
          </p>
        </aside>
      )}

      {/* ── hover tag (road / lineup) ── */}
      {mode !== "garage" && (
        <div className="pointer-events-none absolute left-1/2 top-[120px] -translate-x-1/2 md:top-[96px]">
          {hoverCar ? (
            <div className="font-bungee flex items-center gap-2 whitespace-nowrap rounded-xl border-b-4 border-black/70 bg-black/75 px-4 py-2 text-sm text-white md:text-base">
              {hoverCar.rank ? <span className="rounded bg-red-600 px-1.5">#{hoverCar.rank}</span> : <span className="rounded bg-blue-600 px-1.5">{CATEGORY_LABEL[hoverCar.category]}</span>}
              {hoverCar.short} <span className="text-yellow-300">— {hoverCar.driver}</span>
            </div>
          ) : (
            <div className="whitespace-nowrap rounded-xl bg-black/55 px-3 py-1.5 text-xs font-bold text-white/85 backdrop-blur">
              {mode === "road" ? "🐔 Rockport Crossing — klik mobil buat buka di garasi" : "🅿️ Klik mobil mana aja buat masuk garasi"}
            </div>
          )}
        </div>
      )}

      {/* ── bottom carousel ── */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 p-2 md:p-4">
        <div className="pointer-events-auto mx-auto max-w-6xl rounded-2xl border-b-4 border-black/70 bg-black/55 p-2 backdrop-blur md:p-2.5">
          <div className="mb-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <Chunky onClick={() => step(-1)} className="!px-2.5">
              ◀
            </Chunky>
            <Chunky onClick={() => step(1)} className="!px-2.5">
              ▶
            </Chunky>
            <div className="mx-1 h-6 w-px shrink-0 bg-white/20" />
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold transition ${
                  filter === f ? "bg-yellow-300 text-black" : "bg-white/10 text-white/80 hover:bg-white/20"
                }`}
              >
                {f === "all" ? `Semua (${CARS.length})` : `${CATEGORY_LABEL[f]} (${CARS.filter((c) => c.category === f).length})`}
              </button>
            ))}
          </div>
          <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-0.5">
            {list.map((c) => {
              const active = c.id === car.id;
              return (
                <button
                  key={c.id}
                  ref={(el) => {
                    chipRefs.current[c.id] = el;
                  }}
                  onClick={() => (mode === "garage" ? selectId(c.id) : pick(c.id))}
                  className={`shrink-0 rounded-xl border-b-4 px-2.5 py-1.5 text-left transition active:translate-y-[2px] ${
                    active ? "border-yellow-600 bg-yellow-300 text-black" : "border-black/60 bg-black/50 text-white hover:bg-black/70"
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className={`font-bungee rounded px-1 text-[11px] ${active ? "bg-black text-yellow-300" : c.rank ? "bg-red-600 text-white" : "bg-white/15 text-white"}`}>
                      {chipTag(c)}
                    </span>
                    <span className="whitespace-nowrap text-[13px] font-bold">{c.short}</span>
                  </div>
                  <div className="mt-1 flex gap-0.5">
                    {assets[c.id].swatches.slice(0, 4).map((s) => (
                      <span key={s} className="h-1.5 w-3.5 rounded-sm border border-black/20" style={{ background: s }} />
                    ))}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
        <p className="mt-1 text-center text-[10px] font-semibold text-black/40" style={{ color: night ? "rgba(255,255,255,.35)" : undefined }}>
          Fan-made voxel tribute · bukan aset resmi EA / Initial D
        </p>
      </div>
    </div>
  );
}
