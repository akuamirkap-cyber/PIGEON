import * as THREE from "three";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import { getCarAsset } from "./three/assets";
import { writeVox } from "./voxel/exportVox";
import { CARS } from "./cars";
import { makeZip } from "./zip";

export function download(blob: Blob, name: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

/** MagicaVoxel file (pop-up lights merged in closed position). */
function voxBytes(id: string) {
  const asset = getCarAsset(id);
  const v = asset.build.vox.clone();
  asset.build.parts.forEach((p) => v.merge(p.vox));
  return writeVox(v);
}
export function exportVoxFile(id: string) {
  download(new Blob([voxBytes(id).buffer as ArrayBuffer], { type: "application/octet-stream" }), `${id}.vox`);
}

/** Binary glTF with vertex colors + unlit lights + decals. */
export async function exportGLB(id: string) {
  download(new Blob([await buildGLB(id)], { type: "model/gltf-binary" }), `${id}.glb`);
}

/** Every car as .vox + .glb in one zip. */
export async function exportAllZip() {
  const files: { name: string; data: Uint8Array }[] = [];
  for (const c of CARS) {
    files.push({ name: `voxel-most-wanted/vox/${c.id}.vox`, data: voxBytes(c.id) });
    files.push({ name: `voxel-most-wanted/glb/${c.id}.glb`, data: new Uint8Array(await buildGLB(c.id)) });
  }
  download(makeZip(files), "voxel-most-wanted.zip");
}

async function buildGLB(id: string): Promise<ArrayBuffer> {
  const asset = getCarAsset(id);
  const std = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, metalness: 0.05, name: "paint" });
  const glow = new THREE.MeshBasicMaterial({ vertexColors: true, name: "lights" });
  const mats = [std, glow, glow, glow];
  const root = new THREE.Group();
  root.name = id;
  const body = new THREE.Mesh(asset.geometry, mats);
  body.name = "body";
  root.add(body);
  asset.parts.forEach((p, i) => {
    const m = new THREE.Mesh(p.geometry, mats);
    m.name = `popup_${i}`;
    root.add(m);
  });
  asset.decals.forEach((d, i) =>
    d.planes.forEach((pl, j) => {
      const m = new THREE.Mesh(
        new THREE.PlaneGeometry(d.width, d.height),
        new THREE.MeshStandardMaterial({ map: d.texture, transparent: true, roughness: 0.6 })
      );
      m.position.set(...pl.position);
      m.rotation.y = pl.rotationY;
      m.name = `decal_${i}_${j}`;
      root.add(m);
    })
  );
  const exporter = new GLTFExporter();
  return (await exporter.parseAsync(root, { binary: true })) as ArrayBuffer;
}

export function exportPNG(canvas: HTMLCanvasElement | null, name: string) {
  if (!canvas) return;
  canvas.toBlob((b) => b && download(b, `${name}.png`), "image/png");
}
