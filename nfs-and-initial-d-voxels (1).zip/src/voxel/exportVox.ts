import type { Vox } from "./Vox";

/**
 * MagicaVoxel .vox (v150) writer. Our axes (x, y-up, z-front) are rotated into
 * MagicaVoxel's (x, y, z-up) with a proper rotation so the model is not mirrored.
 */
export function writeVox(vox: Vox): Uint8Array {
  const { min, max } = vox.bounds();
  const sx = max[0] - min[0] + 1;
  const sy = max[2] - min[2] + 1;
  const sz = max[1] - min[1] + 1;
  const palette: number[] = [];
  const index = new Map<number, number>();
  const data: number[] = [];
  vox.forEach((x, y, z, c) => {
    let i = index.get(c);
    if (i === undefined) {
      if (palette.length < 255) {
        palette.push(c);
        i = palette.length;
      } else i = 1;
      index.set(c, i);
    }
    data.push(x - min[0], max[2] - z, y - min[1], i);
  });
  const n = data.length / 4;
  const sizeChunk = 12 + 12;
  const xyziChunk = 12 + 4 + data.length;
  const rgbaChunk = 12 + 1024;
  const children = sizeChunk + xyziChunk + rgbaChunk;
  const buf = new ArrayBuffer(8 + 12 + children);
  const dv = new DataView(buf);
  let o = 0;
  const str = (s: string) => {
    for (let k = 0; k < 4; k++) dv.setUint8(o++, s.charCodeAt(k));
  };
  const i32 = (v: number) => {
    dv.setInt32(o, v, true);
    o += 4;
  };
  str("VOX ");
  i32(150);
  str("MAIN");
  i32(0);
  i32(children);
  str("SIZE");
  i32(12);
  i32(0);
  i32(sx);
  i32(sy);
  i32(sz);
  str("XYZI");
  i32(4 + data.length);
  i32(0);
  i32(n);
  for (const b of data) dv.setUint8(o++, b);
  str("RGBA");
  i32(1024);
  i32(0);
  for (let k = 0; k < 256; k++) {
    const c = palette[k] ?? 0;
    dv.setUint8(o++, (c >> 16) & 255);
    dv.setUint8(o++, (c >> 8) & 255);
    dv.setUint8(o++, c & 255);
    dv.setUint8(o++, k < palette.length ? 255 : 0);
  }
  return new Uint8Array(buf);
}
