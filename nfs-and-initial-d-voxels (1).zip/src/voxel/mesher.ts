import type { Hex, Vox } from "./Vox";

export interface RawMesh {
  positions: Float32Array;
  normals: Float32Array;
  colors: Float32Array;
  /** vertex ranges per material kind */
  groups: { start: number; count: number; kind: number }[];
}

const FACES: { n: [number, number, number]; u: [number, number, number]; v: [number, number, number] }[] = [
  { n: [1, 0, 0], u: [0, 1, 0], v: [0, 0, 1] },
  { n: [-1, 0, 0], u: [0, 0, 1], v: [0, 1, 0] },
  { n: [0, 1, 0], u: [0, 0, 1], v: [1, 0, 0] },
  { n: [0, -1, 0], u: [1, 0, 0], v: [0, 0, 1] },
  { n: [0, 0, 1], u: [1, 0, 0], v: [0, 1, 0] },
  { n: [0, 0, -1], u: [0, 1, 0], v: [1, 0, 0] },
];
const CORNERS: [number, number][] = [
  [0, 0],
  [1, 0],
  [1, 1],
  [0, 1],
];
const AO_CURVE = [0.52, 0.7, 0.86, 1];

const s2l = (c: number) => (c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));

/**
 * Greedy-free voxel mesher: emits only exposed faces with per-vertex ambient occlusion.
 * World position = (voxel - off) * scale.
 */
export function meshVox(
  vox: Vox,
  scale: number,
  off: [number, number, number],
  kindOf: (c: Hex) => number,
  linear = true,
  kinds = 4
): RawMesh {
  const buckets = Array.from({ length: kinds }, () => ({ p: [] as number[], n: [] as number[], c: [] as number[] }));
  const P: number[][] = [[], [], [], []];
  const ao = [0, 0, 0, 0];
  vox.forEach((x, y, z, hex) => {
    const kind = kindOf(hex);
    const b = buckets[kind];
    let r = ((hex >> 16) & 255) / 255;
    let g = ((hex >> 8) & 255) / 255;
    let bl = (hex & 255) / 255;
    if (linear) {
      r = s2l(r);
      g = s2l(g);
      bl = s2l(bl);
    }
    for (const f of FACES) {
      const nx = x + f.n[0];
      const ny = y + f.n[1];
      const nz = z + f.n[2];
      if (vox.has(nx, ny, nz)) continue;
      const bx = x + Math.max(f.n[0], 0);
      const by = y + Math.max(f.n[1], 0);
      const bz = z + Math.max(f.n[2], 0);
      for (let i = 0; i < 4; i++) {
        const [cu, cv] = CORNERS[i];
        P[i] = [bx + cu * f.u[0] + cv * f.v[0], by + cu * f.u[1] + cv * f.v[1], bz + cu * f.u[2] + cv * f.v[2]];
        if (kind === 0) {
          const su = cu ? 1 : -1;
          const sv = cv ? 1 : -1;
          const s1 = vox.has(nx + su * f.u[0], ny + su * f.u[1], nz + su * f.u[2]);
          const s2 = vox.has(nx + sv * f.v[0], ny + sv * f.v[1], nz + sv * f.v[2]);
          const cc = vox.has(nx + su * f.u[0] + sv * f.v[0], ny + su * f.u[1] + sv * f.v[1], nz + su * f.u[2] + sv * f.v[2]);
          ao[i] = s1 && s2 ? 0 : 3 - ((s1 ? 1 : 0) + (s2 ? 1 : 0) + (cc ? 1 : 0));
        } else ao[i] = 3;
      }
      const order = ao[0] + ao[2] > ao[1] + ao[3] ? [0, 1, 2, 0, 2, 3] : [1, 2, 3, 1, 3, 0];
      for (const i of order) {
        b.p.push((P[i][0] - off[0]) * scale, (P[i][1] - off[1]) * scale, (P[i][2] - off[2]) * scale);
        b.n.push(f.n[0], f.n[1], f.n[2]);
        const k = AO_CURVE[ao[i]];
        b.c.push(r * k, g * k, bl * k);
      }
    }
  });
  const total = buckets.reduce((s, b) => s + b.p.length, 0);
  const positions = new Float32Array(total);
  const normals = new Float32Array(total);
  const colors = new Float32Array(total);
  const groups: RawMesh["groups"] = [];
  let o = 0;
  buckets.forEach((b, kind) => {
    if (!b.p.length) return;
    positions.set(b.p, o);
    normals.set(b.n, o);
    colors.set(b.c, o);
    groups.push({ start: o / 3, count: b.p.length / 3, kind });
    o += b.p.length;
  });
  return { positions, normals, colors, groups };
}

/** Centering offset used for every car: x/z centered, wheels on y = 0. */
export function centerOffset(vox: Vox): [number, number, number] {
  const { min, max } = vox.bounds();
  return [(min[0] + max[0] + 1) / 2, min[1], (min[2] + max[2] + 1) / 2];
}
