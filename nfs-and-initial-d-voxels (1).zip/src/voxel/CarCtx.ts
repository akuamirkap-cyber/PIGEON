import { Vox, type Hex } from "./Vox";
import { P, GLOW } from "./palette";

export interface Livery {
  body: Hex;
  A?: Hex;
  C?: Hex;
  D?: Hex;
  E?: Hex;
  glass?: Hex;
  roof?: Hex;
  pillar?: Hex;
  wing?: Hex;
  trim?: Hex;
  rim?: Hex;
  tire?: Hex;
}

export interface Decal {
  text: string;
  /** smaller trailing text, e.g. （自家用） */
  sub?: string;
  z?: number; // voxel z of the decal center (side decals)
  y: number; // voxel y of the decal center (fractional ok)
  len: number; // length in voxels
  h: number; // height in voxels
  color: string;
  font?: string;
  bg?: string;
  stroke?: string;
  sides?: "both" | "left" | "right";
  /** side (default) = door stickers, front/rear = facing along z */
  face?: "side" | "front" | "rear";
  /** continuous x center for front/rear decals (0.5 = middle of the body) */
  x?: number;
}

export type PartKind = "popup" | "turret" | "swing" | "ladder";
export interface Part {
  vox: Vox;
  pivot: [number, number, number];
  kind: PartKind;
  /** swing direction (+1 / -1) */
  dir?: number;
}

export interface CarBuild {
  vox: Vox;
  hw: number;
  parts: Part[];
  decals: Decal[];
  siren: boolean;
  warnings: string[];
}

/** Car construction context: side-profile extrusion + ASCII "vinyl" painting helpers. */
export class CarCtx {
  v = new Vox();
  l: Livery;
  pal: Record<string, Hex>;
  parts: Part[] = [];
  decals: Decal[] = [];
  siren = false;
  warnings: string[] = [];
  hw: number;
  cw: number;
  protectSide: Set<Hex>;
  protectFront: Set<Hex>;

  constructor(l: Livery, o: { hw?: number; cw?: number } = {}) {
    this.l = l;
    this.hw = o.hw ?? 5;
    this.cw = o.cw ?? 4;
    const glass = l.glass ?? P.GLASS;
    this.pal = {
      B: l.body,
      A: l.A ?? l.body,
      C: l.C ?? l.body,
      D: l.D ?? l.body,
      E: l.E ?? l.body,
      K: P.BLACK,
      k: P.DARK,
      c: P.CARBON,
      W: P.WHITE,
      S: P.CHROME,
      s: P.SILVER,
      H: P.HEAD,
      X: P.XENON,
      T: P.TAIL,
      t: P.TAIL_DK,
      O: P.AMBER,
      w: P.LIGHT_W,
      L: P.PLATE,
      G: glass,
      h: P.GLASS_HI,
      R: P.RED,
      Y: P.YELLOW,
      F: P.ORANGE,
      P: P.PINK,
      N: P.NAVY,
      U: P.BLUE,
      M: P.MAROON,
      Z: P.GOLD,
      r: P.SIREN_R,
      b: P.SIREN_B,
    };
    const rim = l.rim ?? P.RIM;
    const tire = l.tire ?? P.TIRE;
    this.protectFront = new Set<Hex>([tire, rim, P.ARCH, P.TIRE]);
    this.protectSide = new Set<Hex>([tire, rim, P.ARCH, P.TIRE, glass, P.GLASS_HI, P.CHROME, P.SIREN_R, P.SIREN_B, ...GLOW]);
  }

  /** Side profile. rows[0] = top row; last row = y 1. Column index = z (0 = rear). */
  profile(rows: string[]) {
    const { v, l, hw, cw } = this;
    const n = rows.length;
    const len = rows[0].length;
    rows.forEach((r, i) => {
      if (r.length !== len) this.warnings.push(`profile row ${i} length ${r.length} != ${len}`);
    });
    const glass = l.glass ?? P.GLASS;
    const roof = l.roof ?? l.body;
    const wing = l.wing ?? P.CARBON;
    const trim = l.trim ?? P.BLACK;
    rows.forEach((row, i) => {
      const y = n - i;
      for (let z = 0; z < row.length; z++) {
        const ch = row[z];
        switch (ch) {
          case "B":
            v.box(-hw, hw, y, y, z, z, l.body);
            break;
          case "b":
            v.box(-hw + 1, hw - 1, y, y, z, z, l.body);
            break;
          case "c":
            v.box(-hw + 2, hw - 2, y, y, z, z, l.body);
            break;
          case "d":
            v.box(-hw + 3, hw - 3, y, y, z, z, l.body);
            break;
          case "p":
            v.box(-cw, cw, y, y, z, z, l.body);
            break;
          case "q":
            v.box(-cw + 2, cw - 2, y, y, z, z, roof);
            break;
          case "V":
            v.box(-hw - 1, hw + 1, y, y, z, z, wing);
            break;
          case "G":
            v.box(-cw, cw, y, y, z, z, glass);
            break;
          case "g":
            v.box(-cw + 1, cw - 1, y, y, z, z, glass);
            break;
          case "R":
            v.box(-cw, cw, y, y, z, z, roof);
            break;
          case "r":
            v.box(-cw + 1, cw - 1, y, y, z, z, roof);
            break;
          case "K":
            v.box(-hw, hw, y, y, z, z, trim);
            break;
          case "k":
            v.box(-hw + 1, hw - 1, y, y, z, z, trim);
            break;
          case "W":
            v.box(-hw, hw, y, y, z, z, wing);
            break;
          case "w":
            v.set(3, y, z, wing).set(-3, y, z, wing);
            break;
        }
      }
    });
    // automatic A/C pillars on each glass run
    const pillar = l.pillar ?? l.body;
    rows.forEach((row, i) => {
      const y = n - i;
      let z = 0;
      while (z < row.length) {
        if (row[z] === "G" || row[z] === "g") {
          let e = z;
          while (e + 1 < row.length && (row[e + 1] === "G" || row[e + 1] === "g")) e++;
          for (const zz of [z, e]) {
            const w = row[zz] === "G" ? cw : cw - 1;
            v.set(w, y, zz, pillar).set(-w, y, zz, pillar);
          }
          z = e + 1;
        } else z++;
      }
    });
    // soften roof corners for a cuter silhouette
    rows.forEach((row, i) => {
      const y = n - i;
      let z = 0;
      while (z < row.length) {
        if ("Rrq".includes(row[z])) {
          let e = z;
          while (e + 1 < row.length && "Rrq".includes(row[e + 1])) e++;
          if (e - z >= 3)
            for (const zz of [z, e]) {
              const w = row[zz] === "R" ? cw : row[zz] === "r" ? cw - 1 : cw - 2;
              v.del(w, y, zz).del(-w, y, zz);
            }
          z = e + 1;
        } else z++;
      }
    });
    return this;
  }

  /** Rounded wheels (size 3, 4 or 5 voxels) at the given start z's. */
  wheels(zs: number[], o: { flare?: boolean; flareColor?: Hex; size?: number } = {}) {
    const { v, hw, l } = this;
    const tire = l.tire ?? P.TIRE;
    const rim = l.rim ?? P.RIM;
    const n = o.size ?? 4;
    for (const zc of zs)
      for (const s of [1, -1]) {
        for (let y = 1; y <= n - 1; y++)
          for (let z = zc; z <= zc + n - 1; z++) {
            v.del(s * hw, y, z);
            if (v.has(s * (hw - 1), y, z)) v.set(s * (hw - 1), y, z, P.ARCH);
          }
        for (let dz = 0; dz < n; dz++)
          for (let dy = 0; dy < n; dy++) {
            if (n >= 4 && (dz === 0 || dz === n - 1) && (dy === 0 || dy === n - 1)) continue;
            const z = zc + dz;
            v.set(s * hw, dy, z, tire);
            const isRim = dz >= 1 && dz <= n - 2 && dy >= 1 && dy <= n - 2;
            const hub = n === 5 && dz === 2 && dy === 2;
            v.set(s * (hw + 1), dy, z, hub ? P.DARK : isRim ? rim : tire);
          }
        if (o.flare) {
          const fc = o.flareColor ?? l.body;
          for (let z = zc - 1; z <= zc + n; z++) v.set(s * (hw + 1), n, z, fc);
          for (let y = 1; y <= n - 1; y++) {
            v.set(s * (hw + 1), y, zc - 1, fc);
            v.set(s * (hw + 1), y, zc + n, fc);
          }
        }
      }
    return this;
  }

  /** Tank tracks with visible road wheels on the outer face. */
  tracks(z0: number, z1: number, xIn: number, xOut: number, o: { tread?: Hex; wheel?: Hex } = {}) {
    const tread = o.tread ?? 0x2c2d31;
    const tread2 = 0x232427;
    const wheel = o.wheel ?? 0x5d6269;
    for (const s of [1, -1])
      for (let x = xIn; x <= xOut; x++)
        for (let y = 0; y <= 3; y++)
          for (let z = z0; z <= z1; z++) {
            if ((z === z0 || z === z1) && (y === 0 || y === 3)) continue;
            let c = (z + y) % 2 === 0 ? tread : tread2;
            if (x === xOut && y >= 1 && y <= 2 && z > z0 && z < z1 && (z - z0) % 3 !== 0) c = wheel;
            this.v.set(s * x, y, z, c);
          }
    return this;
  }

  /** Attach an animated sub-model. */
  part(vox: Vox, pivot: [number, number, number], kind: PartKind, dir = 1) {
    this.parts.push({ vox, pivot, kind, dir });
    return this;
  }

  private check(kind: string, rows: string[], expect?: number) {
    const n = expect ?? rows[0]?.length;
    rows.forEach((r, i) => {
      if (r.length !== n) this.warnings.push(`${kind} row ${i} length ${r.length} != ${n}`);
    });
  }

  private col(ch: string): Hex | undefined {
    if (ch === "." || ch === " ") return undefined;
    return this.pal[ch];
  }

  /** Paint the front-most voxel. Rows top->bottom from yTop, columns = x ascending (viewer facing the car's nose). */
  front(rows: string[], yTop: number) {
    this.check("front", rows, 2 * this.hw + 1);
    rows.forEach((row, i) => {
      const y = yTop - i;
      const half = (row.length - 1) / 2;
      for (let j = 0; j < row.length; j++) {
        const c = this.col(row[j]);
        if (c === undefined) continue;
        const x = j - half;
        const z = this.v.maxZ(x, y);
        if (z === null) continue;
        if (this.protectFront.has(this.v.get(x, y, z)!)) continue;
        this.v.set(x, y, z, c);
      }
    });
    return this;
  }

  /** Paint the rear-most voxel. Columns = x descending (viewer behind the car). */
  rear(rows: string[], yTop: number) {
    this.check("rear", rows, 2 * this.hw + 1);
    rows.forEach((row, i) => {
      const y = yTop - i;
      const half = (row.length - 1) / 2;
      for (let j = 0; j < row.length; j++) {
        const c = this.col(row[j]);
        if (c === undefined) continue;
        const x = half - j;
        const z = this.v.minZ(x, y);
        if (z === null) continue;
        if (this.protectFront.has(this.v.get(x, y, z)!)) continue;
        this.v.set(x, y, z, c);
      }
    });
    return this;
  }

  /** Paint both flanks (outermost voxel). Columns = z (0 = rear). */
  side(rows: string[], yTop: number, z0 = 0, sides: "both" | "left" | "right" = "both") {
    this.check("side", rows);
    rows.forEach((row, i) => {
      const y = yTop - i;
      for (let j = 0; j < row.length; j++) {
        const c = this.col(row[j]);
        if (c === undefined) continue;
        const z = z0 + j;
        for (const s of [1, -1]) {
          if (sides === "left" && s > 0) continue;
          if (sides === "right" && s < 0) continue;
          const x = s > 0 ? this.v.maxX(y, z) : this.v.minX(y, z);
          if (x === null) continue;
          if (this.protectSide.has(this.v.get(x, y, z)!)) continue;
          this.v.set(x, y, z, c);
        }
      }
    });
    return this;
  }

  /** Paint top-most voxels. rows[0] = x max (+half) ... last = x min. Columns = z. Glass is protected. */
  top(rows: string[], z0 = 0) {
    this.check("top", rows);
    const half = (rows.length - 1) / 2;
    rows.forEach((row, i) => {
      const x = half - i;
      for (let j = 0; j < row.length; j++) {
        const c = this.col(row[j]);
        if (c === undefined) continue;
        const z = z0 + j;
        const y = this.v.maxY(x, z);
        if (y === null) continue;
        if (this.protectSide.has(this.v.get(x, y, z)!)) continue;
        this.v.set(x, y, z, c);
      }
    });
    return this;
  }

  /** Force-paint the outermost side voxel (used for pillars over glass). */
  sideFill(z0: number, z1: number, y0: number, y1: number, c: Hex) {
    for (let z = Math.min(z0, z1); z <= Math.max(z0, z1); z++)
      for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) {
        const a = this.v.maxX(y, z);
        const b = this.v.minX(y, z);
        if (a !== null) this.v.set(a, y, z, c);
        if (b !== null) this.v.set(b, y, z, c);
      }
    return this;
  }

  mirrors(z: number, y: number, c?: Hex) {
    const x = this.cw + 1;
    this.v.set(x, y, z, c ?? this.l.body).set(-x, y, z, c ?? this.l.body);
    return this;
  }

  /** Vertical end plates on a wing. */
  endplates(z0: number, z1: number, y0: number, y1: number, c?: Hex, x?: number) {
    const xx = x ?? this.hw;
    this.v.sym(xx, xx, y0, y1, z0, z1, c ?? this.l.wing ?? P.CARBON);
    return this;
  }

  /** Police light bar on the roof. */
  lightbar(z0: number, z1: number, y: number, half = 3) {
    for (let x = -half; x <= half; x++) {
      const c = x < 0 ? P.SIREN_R : x > 0 ? P.SIREN_B : P.LIGHT_W;
      this.v.box(x, x, y, y, z0, z1, c);
    }
    this.siren = true;
    return this;
  }

  /**
   * Pop-up headlight: lid layer at y (flush with hood), lamp layer at y-1 hidden behind the nose.
   * x0..x1 >= 0 (mirrored automatically), z0 = rear, z1 = front of the unit.
   */
  popups(x0: number, x1: number, y: number, z0: number, z1: number, lid?: Hex) {
    const lc = lid ?? this.l.body;
    for (const s of [1, -1]) {
      const part = new Vox();
      for (let x = x0; x <= x1; x++)
        for (let z = z0; z <= z1; z++) {
          const xx = s * x;
          this.v.del(xx, y, z).del(xx, y - 1, z);
          part.set(xx, y, z, lc);
          part.set(xx, y - 1, z, z === z1 ? P.HEAD : P.DARK);
        }
      this.parts.push({ vox: part, pivot: [s * ((x0 + x1) / 2 + 0.5), y - 1, z0], kind: "popup" });
    }
    return this;
  }

  decal(d: Decal) {
    this.decals.push(d);
    return this;
  }

  box(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: Hex) {
    this.v.box(x0, x1, y0, y1, z0, z1, c);
    return this;
  }
  sym(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: Hex) {
    this.v.sym(x0, x1, y0, y1, z0, z1, c);
    return this;
  }
  clear(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number) {
    this.v.clear(x0, x1, y0, y1, z0, z1);
    return this;
  }
  clearSym(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number) {
    this.v.clearSym(x0, x1, y0, y1, z0, z1);
    return this;
  }

  done(): CarBuild {
    return { vox: this.v, hw: this.hw, parts: this.parts, decals: this.decals, siren: this.siren, warnings: this.warnings };
  }
}

/** Remove wing characters from a profile (for wing-less variants). */
export const noWing = (rows: string[]) => rows.map((r) => r.replace(/[Ww]/g, "."));
