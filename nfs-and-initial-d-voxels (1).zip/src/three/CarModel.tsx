import { useFrame, type ThreeElements } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import type { PartKind } from "../voxel/CarCtx";
import { CAR_MATS, MATS, getCarAsset, type CarAsset } from "./assets";

/** Flashes every police light bar in sync (shared materials). */
export function SirenTicker() {
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const ph = Math.floor(t * 8) % 8;
    const r = ph === 0 || ph === 2 ? 1 : 0.12;
    const b = ph === 4 || ph === 6 ? 1 : 0.12;
    MATS.sirenR.color.setScalar(r);
    MATS.sirenB.color.setScalar(b);
  });
  return null;
}

function PartMesh({
  geometry,
  pivot,
  kind,
  dir,
  open,
}: {
  geometry: THREE.BufferGeometry;
  pivot: [number, number, number];
  kind: PartKind;
  dir: number;
  open: boolean;
}) {
  const ref = useRef<THREE.Group>(null);
  const t = useRef(0);
  useFrame(({ clock }, dt) => {
    const g = ref.current;
    if (!g) return;
    t.current = THREE.MathUtils.damp(t.current, open ? 1 : 0, kind === "ladder" ? 2.5 : 6, dt);
    const k = t.current;
    if (kind === "popup") {
      g.rotation.x = -0.32 * k;
      g.position.y = pivot[1] + 0.16 * k;
    } else if (kind === "ladder") g.rotation.x = -0.5 * k;
    else if (kind === "swing") g.rotation.y = dir * (Math.PI / 2) * k;
    else if (kind === "turret") g.rotation.y = Math.sin(clock.elapsedTime * 0.6) * 0.75;
  });
  return (
    <group ref={ref} position={pivot}>
      <mesh geometry={geometry} material={CAR_MATS} position={[-pivot[0], -pivot[1], -pivot[2]]} castShadow />
    </group>
  );
}

function Decals({ asset }: { asset: CarAsset }) {
  return (
    <>
      {asset.decals.map((d, i) =>
        d.planes.map((p, j) => (
          <mesh key={`${i}-${j}`} position={p.position} rotation={[0, p.rotationY, 0]} renderOrder={2}>
            <planeGeometry args={[d.width, d.height]} />
            <meshStandardMaterial map={d.texture} transparent roughness={0.6} depthWrite={false} polygonOffset polygonOffsetFactor={-4} />
          </mesh>
        ))
      )}
    </>
  );
}

type GroupProps = ThreeElements["group"];

export function CarModel({ carId, lights = false, ...props }: { carId: string; lights?: boolean } & Omit<GroupProps, "id">) {
  const asset = useMemo(() => getCarAsset(carId), [carId]);
  return (
    <group {...props}>
      <mesh geometry={asset.geometry} material={CAR_MATS} castShadow receiveShadow />
      {asset.parts.map((p, i) => (
        <PartMesh key={i} geometry={p.geometry} pivot={p.pivot} kind={p.kind} dir={p.dir} open={lights} />
      ))}
      <Decals asset={asset} />
    </group>
  );
}
