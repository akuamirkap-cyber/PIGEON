import * as THREE from "three";
import { carById } from "../cars";
import type { CarBuild, Decal, PartKind } from "../voxel/CarCtx";
import { centerOffset, meshVox, type RawMesh } from "../voxel/mesher";
import { GLOW, kindOf, P } from "../voxel/palette";
import { Vox, type Hex } from "../voxel/Vox";

export const VOXEL = 0.1;

export function rawToGeometry(m: RawMesh) {
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.BufferAttribute(m.positions, 3));
  g.setAttribute("normal", new THREE.BufferAttribute(m.normals, 3));
  g.setAttribute("color", new THREE.BufferAttribute(m.colors, 3));
  for (const gr of m.groups) g.addGroup(gr.start, gr.count, gr.kind);
  g.computeBoundingBox();
  g.computeBoundingSphere();
  return g;
}

export const MATS = {
  std: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.58, metalness: 0.04 }),
  glow: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
  sirenR: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
  sirenB: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
};
export const CAR_MATS: THREE.Material[] = [MATS.std, MATS.glow, MATS.sirenR, MATS.sirenB];

// ───────────── decals (pixel-crisp text stickers) ─────────────
export interface DecalPlane {
  position: [number, number, number];
  rotationY: number;
}
export interface DecalAsset {
  decal: Decal;
  width: number;
  height: number;
  planes: DecalPlane[];
  texture: THREE.CanvasTexture;
}

function decalTexture(d: Decal): THREE.CanvasTexture {
  if (typeof document === "undefined") return new THREE.CanvasTexture({ width: 1, height: 1 } as unknown as HTMLCanvasElement);
  const canvas = document.createElement("canvas");
  const H = 160;
  const W = Math.round((H * d.len) / d.h);
  canvas.width = W;
  canvas.height = H;
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  const font = d.font ?? '"Russo One", "Chakra Petch", "Arial Black", Impact, sans-serif';
  const draw = () => {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);
    const sub = 0.56;
    const gap = 0.06;
    const measure = (s: number) => {
      ctx.font = `900 ${s}px ${font}`;
      let w = ctx.measureText(d.text).width;
      if (d.sub) {
        ctx.font = `900 ${s * sub}px ${font}`;
        w += ctx.measureText(d.sub).width + s * gap;
      }
      return w;
    };
    let size = H * 0.84;
    let w = measure(size);
    if (w > W * 0.97) {
      size *= (W * 0.97) / w;
      w = measure(size);
    }
    let x = (W - w) / 2;
    const base = H / 2 + size * 0.36;
    ctx.fillStyle = d.color;
    ctx.font = `900 ${size}px ${font}`;
    ctx.fillText(d.text, x, base);
    if (d.sub) {
      x += ctx.measureText(d.text).width + size * gap;
      ctx.font = `900 ${size * sub}px ${font}`;
      ctx.fillText(d.sub, x, base);
    }
    tex.needsUpdate = true;
  };
  draw();
  if (typeof document !== "undefined" && document.fonts) {
    document.fonts
      .load(`900 64px ${font}`, d.text + (d.sub ?? ""))
      .then(draw)
      .catch(() => {});
    document.fonts.ready.then(draw).catch(() => {});
  }
  return tex;
}

function makeDecal(d: Decal, vox: Vox, off: [number, number, number], hw: number): DecalAsset {
  const face = d.face ?? "side";
  const y0 = Math.floor(d.y - d.h / 2);
  const y1 = Math.floor(d.y + d.h / 2 - 0.001);
  const yw = (d.y - off[1]) * VOXEL;
  const planes: DecalPlane[] = [];
  if (face === "side") {
    const zc = d.z ?? 0;
    const z0 = Math.floor(zc - d.len / 2);
    const z1 = Math.floor(zc + d.len / 2 - 0.001);
    let xr = -Infinity;
    let xl = Infinity;
    for (let y = y0; y <= y1; y++)
      for (let z = z0; z <= z1; z++) {
        const a = vox.maxX(y, z);
        const b = vox.minX(y, z);
        if (a !== null && a <= hw) xr = Math.max(xr, a);
        if (b !== null && b >= -hw) xl = Math.min(xl, b);
      }
    const zw = (zc - off[2]) * VOXEL;
    if (d.sides !== "left") planes.push({ position: [(xr + 1 - off[0]) * VOXEL + 0.004, yw, zw], rotationY: Math.PI / 2 });
    if (d.sides !== "right") planes.push({ position: [(xl - off[0]) * VOXEL - 0.004, yw, zw], rotationY: -Math.PI / 2 });
  } else {
    const xc = d.x ?? 0.5;
    const x0 = Math.floor(xc - d.len / 2);
    const x1 = Math.floor(xc + d.len / 2 - 0.001);
    let zf = -Infinity;
    let zr = Infinity;
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++) {
        const a = vox.maxZ(x, y);
        const b = vox.minZ(x, y);
        if (a !== null) zf = Math.max(zf, a);
        if (b !== null) zr = Math.min(zr, b);
      }
    const xw = (xc - off[0]) * VOXEL;
    if (face === "front" && isFinite(zf)) planes.push({ position: [xw, yw, (zf + 1 - off[2]) * VOXEL + 0.004], rotationY: 0 });
    if (face === "rear" && isFinite(zr)) planes.push({ position: [xw, yw, (zr - off[2]) * VOXEL - 0.004], rotationY: Math.PI });
  }
  return { decal: d, width: d.len * VOXEL, height: d.h * VOXEL, planes, texture: decalTexture(d) };
}

// ───────────── cars ─────────────
export interface CarAsset {
  id: string;
  build: CarBuild;
  geometry: THREE.BufferGeometry;
  parts: { geometry: THREE.BufferGeometry; pivot: [number, number, number]; kind: PartKind; dir: number }[];
  decals: DecalAsset[];
  dims: [number, number, number];
  length: number;
  height: number;
  /** turntable radius in voxels */
  platform: number;
  sirenBlue: boolean;
  voxels: number;
  swatches: string[];
}

const SKIP = new Set<Hex>([P.TIRE, P.ARCH, P.GLASS, P.GLASS_HI, P.PLATE, P.CHROME, P.DARK, P.SIREN_R, P.SIREN_B, ...GLOW]);
const hex = (c: number) => "#" + c.toString(16).padStart(6, "0");

const cache = new Map<string, CarAsset>();
export function getCarAsset(id: string): CarAsset {
  const hit = cache.get(id);
  if (hit) return hit;
  const spec = carById(id);
  const build = spec.build();
  const off = centerOffset(build.vox);
  const geometry = rawToGeometry(meshVox(build.vox, VOXEL, off, kindOf));
  const parts = build.parts.map((p) => ({
    geometry: rawToGeometry(meshVox(p.vox, VOXEL, off, kindOf)),
    pivot: [(p.pivot[0] - off[0]) * VOXEL, (p.pivot[1] - off[1]) * VOXEL, (p.pivot[2] - off[2]) * VOXEL] as [number, number, number],
    kind: p.kind,
    dir: p.dir ?? 1,
  }));
  const decals = build.decals.map((d) => makeDecal(d, build.vox, off, build.hw));
  const { min, max } = build.vox.bounds();
  const counts = new Map<Hex, number>();
  const rim = new Set<Hex>();
  build.vox.forEach((x, y, _z, c) => {
    if (Math.abs(x) === build.hw + 1 && y <= 3) rim.add(c);
  });
  build.vox.forEach((_x, _y, _z, c) => {
    if (SKIP.has(c)) return;
    counts.set(c, (counts.get(c) ?? 0) + 1);
  });
  const swatches = [...counts.entries()]
    .filter(([c, n]) => n > 6 && !(rim.has(c) && n < 40))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([c]) => hex(c));
  const voxels = build.vox.size + build.parts.reduce((s, p) => s + p.vox.size, 0);
  let top = max[1];
  let sirenBlue = false;
  build.parts.forEach((p) => (top = Math.max(top, p.vox.bounds().max[1])));
  build.vox.forEach((_x, _y, _z, c) => {
    if (c === P.SIREN_B) sirenBlue = true;
  });
  const lenV = max[2] - min[2] + 1;
  const widV = max[0] - min[0] + 1;
  const asset: CarAsset = {
    id,
    build,
    geometry,
    parts,
    decals,
    dims: [max[0] - min[0] + 1, max[1] - min[1] + 1, max[2] - min[2] + 1],
    length: lenV * VOXEL,
    height: (top - min[1] + 1) * VOXEL,
    platform: Math.max(17, Math.ceil(Math.hypot(lenV / 2, widV / 2) + 2)),
    sirenBlue,
    voxels,
    swatches,
  };
  cache.set(id, asset);
  return asset;
}

// ───────────── scenery voxel props ─────────────
const hash = (x: number, y: number, z: number) => {
  const h = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return h - Math.floor(h);
};

const platforms = new Map<number, THREE.BufferGeometry>();
export function platformGeometry(R = 17) {
  const hit = platforms.get(R);
  if (hit) return hit;
  const v = new Vox();
  for (let x = -R; x <= R; x++)
    for (let z = -R; z <= R; z++) {
      const r = Math.hypot(x, z);
      if (r > R + 0.35) continue;
      const ring = r > R - 2.3;
      const ang = Math.atan2(z, x);
      const stripe = Math.floor(((ang + Math.PI) / (Math.PI * 2)) * 28) % 2 === 0;
      const top = ring ? (stripe ? 0xffc81f : 0x1f2026) : hash(x, 0, z) > 0.82 ? 0x474a54 : 0x3d4049;
      v.set(x, 0, z, top);
      v.set(x, -1, z, ring ? 0x2b2d33 : 0x32353c);
      v.set(x, -2, z, 0x26282e);
    }
  const g = rawToGeometry(meshVox(v, VOXEL, [0, 1, 0], kindOf));
  platforms.set(R, g);
  return g;
}

const trees: THREE.BufferGeometry[] = [];
export function treeGeometry(variant: number) {
  const k = variant % 3;
  if (trees[k]) return trees[k];
  const v = new Vox();
  const trunk = 2 + k;
  v.box(-1, 0, 0, trunk, -1, 0, 0x8a5a33);
  const leafTop = trunk + 3 + k;
  for (let x = -3; x <= 2; x++)
    for (let z = -3; z <= 2; z++)
      for (let y = trunk + 1; y <= leafTop; y++) {
        const edge = (x === -3 || x === 2) && (z === -3 || z === 2);
        if (edge && (y === trunk + 1 || y === leafTop)) continue;
        const top = y === leafTop;
        const n = hash(x, y, z);
        v.set(x, y, z, top ? (n > 0.6 ? 0x8ee05a : 0x7fd651) : n > 0.75 ? 0x4aa23a : 0x5bb845);
      }
  trees[k] = rawToGeometry(meshVox(v, 0.12, [0, 0, 0], kindOf));
  return trees[k];
}

let chicken: THREE.BufferGeometry | null = null;
export function chickenGeometry() {
  if (chicken) return chicken;
  const v = new Vox();
  const W = 0xffffff;
  const O = 0xff9a1a;
  const R = 0xe8322e;
  v.box(-1, -1, 0, 1, 0, 0, O).box(1, 1, 0, 1, 0, 0, O); // legs
  v.box(-2, 2, 2, 6, -2, 2, W); // body
  v.box(-1, 1, 4, 5, -3, -3, 0xeeeeee); // tail
  v.box(-3, -3, 3, 4, -1, 1, 0xf3f3f3).box(3, 3, 3, 4, -1, 1, 0xf3f3f3); // wings
  v.box(0, 0, 7, 7, -1, 1, R); // comb
  v.box(-1, 1, 4, 4, 3, 3, O); // beak
  v.set(0, 3, 3, R); // wattle
  v.set(-2, 5, 1, 0x111111).set(2, 5, 1, 0x111111); // eyes
  chicken = rawToGeometry(meshVox(v, 0.07, [0, 0, 0], kindOf));
  return chicken;
}
