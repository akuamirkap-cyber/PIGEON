import { OrbitControls } from "@react-three/drei";
import { useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import { useEffect, useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { CARS } from "../cars";
import { CarModel, SirenTicker } from "./CarModel";
import { MATS, chickenGeometry, getCarAsset, platformGeometry, treeGeometry } from "./assets";

export type Mode = "garage" | "road" | "lineup";

const CAMS: Record<Mode, { pos: [number, number, number]; target: [number, number, number]; min: number; max: number }> = {
  garage: { pos: [4.3, 2.5, 4.7], target: [0, 0.42, 0], min: 2.2, max: 11 },
  road: { pos: [6.5, 15.5, 14.5], target: [0, 0, 0.6], min: 6, max: 42 },
  lineup: { pos: [0, 12.5, 17.5], target: [0, 0, 0.5], min: 4, max: 46 },
};

function CameraRig({ mode, fit }: { mode: Mode; fit: { scale: number; ty: number } }) {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const controls = useRef<OrbitControlsImpl>(null);
  const c = CAMS[mode];
  const aspect = size.width / Math.max(1, size.height);
  const k = aspect < 1 ? Math.min(2, Math.pow(1 / aspect, 0.85)) : 1;
  useEffect(() => {
    camera.position.set(
      c.target[0] + (c.pos[0] - c.target[0]) * k,
      c.target[1] + (c.pos[1] - c.target[1]) * k,
      c.target[2] + (c.pos[2] - c.target[2]) * k
    );
    controls.current?.target.set(...c.target);
    controls.current?.update();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, camera, c]);
  // garage: back the camera off for big vehicles (bus, fire truck, tank) and keep the orbit angle
  useEffect(() => {
    if (mode !== "garage") return;
    const ctl = controls.current;
    const target = new THREE.Vector3(0, fit.ty, 0);
    const dir = camera.position.clone().sub(ctl ? ctl.target : target);
    const base = new THREE.Vector3(...c.pos).sub(new THREE.Vector3(...c.target)).length() * k * fit.scale;
    dir.setLength(base);
    camera.position.copy(target).add(dir);
    ctl?.target.copy(target);
    ctl?.update();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fit.scale, fit.ty, mode]);
  return (
    <OrbitControls
      key={mode}
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      minDistance={c.min}
      maxDistance={c.max * k * (mode === "garage" ? fit.scale : 1)}
      maxPolarAngle={mode === "garage" ? 1.5 : 1.25}
      enablePan={mode !== "garage"}
      target={c.target}
    />
  );
}

function Lights({ night, wide }: { night: boolean; wide: boolean }) {
  const s = wide ? 17 : 4.5;
  const sun = useRef<THREE.DirectionalLight>(null);
  useLayoutEffect(() => {
    const cam = sun.current?.shadow.camera;
    if (!cam) return;
    cam.left = -s;
    cam.right = s;
    cam.top = s;
    cam.bottom = -s;
    cam.far = 60;
    cam.updateProjectionMatrix();
  }, [s]);
  return (
    <>
      <hemisphereLight args={night ? ["#6170b0", "#141826", 0.8] : ["#ffffff", "#b5c99c", 1.35]} />
      <directionalLight
        ref={sun}
        position={night ? [-4, 9, 3] : [5, 9, 4]}
        intensity={night ? 0.75 : 2.25}
        color={night ? "#a9bcff" : "#fff2dc"}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
        shadow-camera-left={-s}
        shadow-camera-right={s}
        shadow-camera-top={s}
        shadow-camera-bottom={-s}
        shadow-camera-far={60}
      />
    </>
  );
}

// ───────────────────────── Garage ─────────────────────────
function HeadSpot({ x, z }: { x: number; z: number }) {
  const light = useRef<THREE.SpotLight>(null);
  const target = useMemo(() => new THREE.Object3D(), []);
  useEffect(() => {
    if (light.current) light.current.target = target;
  }, [target]);
  return (
    <>
      <spotLight ref={light} position={[x, 0.32, z]} angle={0.5} penumbra={0.7} intensity={14} distance={10} decay={1.6} color="#fff0c4" />
      <primitive object={target} position={[x * 2, 0, z + 5]} />
    </>
  );
}

function SirenGlow({ blue }: { blue: boolean }) {
  const r = useRef<THREE.PointLight>(null);
  const b = useRef<THREE.PointLight>(null);
  useFrame(({ clock }) => {
    const ph = Math.floor(clock.elapsedTime * 8) % 8;
    if (r.current) r.current.intensity = ph === 0 || ph === 2 ? 5 : 0;
    if (b.current) b.current.intensity = ph === 4 || ph === 6 ? 5 : 0;
  });
  return (
    <>
      <pointLight ref={r} position={[-0.6, 1.4, 0]} color="#ff2a44" distance={6} decay={1.5} />
      <pointLight ref={b} position={[0.6, 1.4, 0]} color={blue ? "#2f6bff" : "#ff3a2a"} distance={6} decay={1.5} />
    </>
  );
}

const GARAGE_TREES = Array.from({ length: 14 }, (_, i) => {
  const a = (i / 14) * Math.PI * 2 + (i % 2) * 0.2;
  const r = 6.2 + (i % 3) * 1.4;
  return { x: Math.cos(a) * r, z: Math.sin(a) * r, v: i % 3, rot: (i * 1.3) % (Math.PI * 2) };
});

function Garage({ carId, night, lights, autoRotate }: { carId: string; night: boolean; lights: boolean; autoRotate: boolean }) {
  const spin = useRef<THREE.Group>(null);
  const drop = useRef<THREE.Group>(null);
  const t0 = useRef(performance.now());
  const asset = getCarAsset(carId);
  useEffect(() => {
    t0.current = performance.now();
  }, [carId]);
  useFrame((_, dt) => {
    if (spin.current && autoRotate) spin.current.rotation.y += dt * 0.35;
    const g = drop.current;
    if (!g) return;
    const t = (performance.now() - t0.current) / 1000;
    let y = 0;
    let sq = 1;
    if (t < 0.32) y = Math.pow(1 - t / 0.32, 2) * 1.3;
    else {
      const k = t - 0.32;
      y = Math.abs(Math.sin(k * 10)) * 0.14 * Math.exp(-k * 6);
      sq = 1 - 0.14 * Math.sin(Math.min(k / 0.22, 1) * Math.PI) * Math.exp(-k * 4);
    }
    g.position.y = y;
    g.scale.set(1 / Math.sqrt(sq), sq, 1 / Math.sqrt(sq));
  });
  const front = asset.length / 2;
  return (
    <group>
      <group ref={spin}>
        <mesh geometry={platformGeometry(asset.platform)} material={MATS.std} receiveShadow castShadow />
        <group ref={drop}>
          <CarModel carId={carId} lights={lights} />
        </group>
        {lights && (
          <>
            <HeadSpot x={0.32} z={front} />
            <HeadSpot x={-0.32} z={front} />
          </>
        )}
      </group>
      {asset.build.siren && night && <SirenGlow blue={asset.sirenBlue} />}
      <mesh rotation-x={-Math.PI / 2} position-y={-0.3} receiveShadow>
        <circleGeometry args={[60, 64]} />
        <meshStandardMaterial color={night ? "#1b2236" : "#bfe49a"} />
      </mesh>
      {GARAGE_TREES.map((t, i) => (
        <mesh key={i} geometry={treeGeometry(t.v)} material={MATS.std} position={[t.x, -0.3, t.z]} rotation-y={t.rot} castShadow receiveShadow />
      ))}
    </group>
  );
}

// ───────────────────────── Crossy Road diorama ─────────────────────────
const LANE = 1.7;
const ROAD_W = 46;
type Lane = { kind: "grass" | "road"; dir?: 1 | -1; speed?: number; chicken?: boolean; cars?: { id: string; gap?: number }[] };
const LANES: Lane[] = [
  { kind: "grass" },
  { kind: "grass" },
  { kind: "grass" },
  { kind: "road", dir: 1, speed: 2.6, cars: [{ id: "slr" }, { id: "db9" }, { id: "gallardo" }] },
  { kind: "road", dir: -1, speed: 2.0, cars: [{ id: "viper" }, { id: "corvette" }, { id: "clk" }, { id: "golf" }] },
  { kind: "grass", chicken: true },
  // hot pursuit: M3 GTR chased by Rockport PD
  { kind: "road", dir: 1, speed: 5.4, cars: [{ id: "m3gtr", gap: 0 }, { id: "police", gap: 3 }, { id: "cross", gap: 6.2 }] },
  { kind: "road", dir: -1, speed: 2.9, cars: [{ id: "mustang" }, { id: "evo" }, { id: "cayman" }] },
  { kind: "road", dir: 1, speed: 1.8, cars: [{ id: "eclipse" }, { id: "rx8" }, { id: "supra" }, { id: "is300" }] },
  { kind: "grass" },
  // touge battle: AE86 vs FD
  { kind: "road", dir: -1, speed: 3.8, cars: [{ id: "ae86", gap: 0 }, { id: "fd3s", gap: 2.9 }, { id: "razor-mustang", gap: 21 }] },
  { kind: "grass" },
  // city traffic
  { kind: "road", dir: 1, speed: 1.5, cars: [{ id: "schoolbus" }, { id: "taxi" }, { id: "mrbean-chair" }, { id: "bluebird" }] },
  { kind: "road", dir: -1, speed: 3.3, cars: [{ id: "firetruck", gap: 0 }, { id: "rally", gap: 15 }, { id: "mrbean", gap: 28 }] },
  { kind: "road", dir: 1, speed: 0.8, cars: [{ id: "tank" }] },
  { kind: "grass" },
  { kind: "grass" },
  { kind: "grass" },
];
const CHICKEN_LANE = LANES.findIndex((l) => l.chicken);
const laneZ = (i: number) => (i - (LANES.length - 1) / 2) * LANE;
const wrap = (x: number) => ((((x + ROAD_W / 2) % ROAD_W) + ROAD_W) % ROAD_W) - ROAD_W / 2;

function RoadLane({ lane, z, night, onPick, onHover }: { lane: Lane; z: number; night: boolean; onPick: (id: string) => void; onHover: (id: string | null) => void }) {
  const refs = useRef<(THREE.Group | null)[]>([]);
  const cars = lane.cars ?? [];
  const bases = useMemo(
    () => cars.map((c, i) => (c.gap !== undefined ? -(lane.dir ?? 1) * c.gap : (i * ROAD_W) / cars.length + (z * 3.7) % 5)),
    [cars, lane.dir, z]
  );
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    refs.current.forEach((g, i) => {
      if (!g) return;
      g.position.x = wrap(bases[i] + (lane.dir ?? 1) * (lane.speed ?? 1) * t);
      g.position.y = Math.abs(Math.sin(t * 9 + i)) * 0.012;
    });
  });
  return (
    <>
      {cars.map((c, i) => (
        <group
          key={c.id}
          ref={(el) => {
            refs.current[i] = el;
          }}
          position={[0, 0, z]}
          rotation-y={(lane.dir ?? 1) > 0 ? Math.PI / 2 : -Math.PI / 2}
          onClick={(e: ThreeEvent<MouseEvent>) => {
            e.stopPropagation();
            onPick(c.id);
          }}
          onPointerOver={(e: ThreeEvent<PointerEvent>) => {
            e.stopPropagation();
            onHover(c.id);
            document.body.style.cursor = "pointer";
          }}
          onPointerOut={() => {
            onHover(null);
            document.body.style.cursor = "";
          }}
        >
          <CarModel carId={c.id} lights={night} />
        </group>
      ))}
    </>
  );
}

function Chicken({ z }: { z: number }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const g = ref.current;
    if (!g) return;
    const t = clock.elapsedTime;
    const hop = (t * 1.4) % 1;
    g.position.y = 0.12 + Math.sin(hop * Math.PI) * 0.32;
    const sq = hop < 0.12 ? 1 - 0.25 * Math.sin((hop / 0.12) * Math.PI) : 1;
    g.scale.set(1 / Math.sqrt(sq), sq, 1 / Math.sqrt(sq));
    g.rotation.y = Math.floor(t * 1.4) % 4 === 3 ? Math.PI / 2 : Math.PI;
  });
  return (
    <group ref={ref} position={[-1.2, 0.12, z]}>
      <mesh geometry={chickenGeometry()} material={MATS.std} castShadow />
    </group>
  );
}

function Road({ night, onPick, onHover }: { night: boolean; onPick: (id: string) => void; onHover: (id: string | null) => void }) {
  const trees = useMemo(() => {
    const out: { x: number; z: number; v: number }[] = [];
    LANES.forEach((l, i) => {
      if (l.kind !== "grass") return;
      for (let k = 0; k < 9; k++) {
        const x = -21 + k * 5.1 + ((i * 7 + k * 3) % 4) * 0.6;
        if (i === CHICKEN_LANE && Math.abs(x + 1.2) < 2.5) continue;
        out.push({ x, z: laneZ(i) + (((k + i) % 3) - 1) * 0.25, v: (k + i) % 3 });
      }
    });
    return out;
  }, []);
  const dashes = useMemo(() => {
    const out: { x: number; z: number }[] = [];
    LANES.forEach((l, i) => {
      if (l.kind === "road" && LANES[i + 1]?.kind === "road") for (let x = -ROAD_W / 2; x < ROAD_W / 2; x += 1.8) out.push({ x, z: laneZ(i) + LANE / 2 });
    });
    return out;
  }, []);
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} position-y={-0.5} receiveShadow>
        <planeGeometry args={[220, 220]} />
        <meshStandardMaterial color={night ? "#1f3b25" : "#8cc84b"} />
      </mesh>
      {LANES.map((l, i) => {
        const grass = l.kind === "grass";
        const h = grass ? 0.62 : 0.5;
        const color = grass ? (i % 2 ? (night ? "#2f5a35" : "#a4dc5c") : night ? "#2a5230" : "#97d150") : night ? "#262a33" : "#555a64";
        return (
          <mesh key={i} position={[0, (grass ? 0.12 : 0) - h / 2, laneZ(i)]} receiveShadow>
            <boxGeometry args={[ROAD_W, h, LANE]} />
            <meshStandardMaterial color={color} />
          </mesh>
        );
      })}
      {dashes.map((d, i) => (
        <mesh key={i} position={[d.x, 0.006, d.z]}>
          <boxGeometry args={[0.85, 0.012, 0.09]} />
          <meshStandardMaterial color={night ? "#9aa0aa" : "#f4f4f4"} />
        </mesh>
      ))}
      {trees.map((t, i) => (
        <mesh key={i} geometry={treeGeometry(t.v)} material={MATS.std} position={[t.x, 0.12, t.z]} rotation-y={(i % 4) * (Math.PI / 2)} castShadow receiveShadow />
      ))}
      <Chicken z={laneZ(CHICKEN_LANE)} />
      {LANES.map((l, i) => (l.kind === "road" ? <RoadLane key={i} lane={l} z={laneZ(i)} night={night} onPick={onPick} onHover={onHover} /> : null))}
    </group>
  );
}

// ───────────────────────── Parking lineup ─────────────────────────
function LineupCar({ id, x, z, ring, hovered, selected, night, onPick, onHover }: { id: string; x: number; z: number; ring: number; hovered: boolean; selected: boolean; night: boolean; onPick: (id: string) => void; onHover: (id: string | null) => void }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }, dt) => {
    const g = ref.current;
    if (!g) return;
    const t = clock.elapsedTime;
    const ty = hovered ? 0.22 + Math.abs(Math.sin(t * 6)) * 0.12 : 0;
    g.position.y = THREE.MathUtils.damp(g.position.y, ty, 12, dt);
    g.rotation.y = THREE.MathUtils.damp(g.rotation.y, hovered ? Math.sin(t * 2) * 0.5 : 0, 6, dt);
  });
  return (
    <group position={[x, 0, z]}>
      {selected && (
        <mesh rotation-x={-Math.PI / 2} position-y={0.012}>
          <ringGeometry args={[ring, ring + 0.17, 40]} />
          <meshBasicMaterial color="#ffd21f" toneMapped={false} />
        </mesh>
      )}
      <group
        ref={ref}
        onClick={(e: ThreeEvent<MouseEvent>) => {
          e.stopPropagation();
          onPick(id);
        }}
        onPointerOver={(e: ThreeEvent<PointerEvent>) => {
          e.stopPropagation();
          onHover(id);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          onHover(null);
          document.body.style.cursor = "";
        }}
      >
        <CarModel carId={id} lights={night} />
      </group>
    </group>
  );
}

function Lineup({ carId, night, hover, onPick, onHover }: { carId: string; night: boolean; hover: string | null; onPick: (id: string) => void; onHover: (id: string | null) => void }) {
  const COLS = 5;
  const DX = 2.2;
  const rows = useMemo(() => {
    const out: { cars: typeof CARS; z: number; depth: number }[] = [];
    for (let i = 0; i < CARS.length; i += COLS) out.push({ cars: CARS.slice(i, i + COLS), z: 0, depth: 0 });
    out.forEach((r) => (r.depth = Math.max(...r.cars.map((c) => getCarAsset(c.id).length)) + 0.9));
    const total = out.reduce((a, r) => a + r.depth, 0);
    let acc = -total / 2;
    out.forEach((r) => {
      r.z = acc + r.depth / 2;
      acc += r.depth;
    });
    return out;
  }, []);
  return (
    <group>
      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[90, 90]} />
        <meshStandardMaterial color={night ? "#1d2029" : "#4a4e57"} />
      </mesh>
      {rows.map((r, ri) =>
        Array.from({ length: COLS + 1 }).map((__, c) => (
          <mesh key={`${ri}-${c}`} position={[(c - COLS / 2) * DX, 0.006, r.z]}>
            <boxGeometry args={[0.07, 0.012, r.depth - 0.45]} />
            <meshStandardMaterial color={night ? "#b9bdc6" : "#f2f2f2"} />
          </mesh>
        ))
      )}
      {rows.map((r) =>
        r.cars.map((car, ci) => (
          <LineupCar
            key={car.id}
            id={car.id}
            x={(ci - (COLS - 1) / 2) * DX}
            z={r.z}
            ring={Math.max(1.25, getCarAsset(car.id).length / 2 + 0.12)}
            hovered={hover === car.id}
            selected={carId === car.id}
            night={night}
            onPick={onPick}
            onHover={onHover}
          />
        ))
      )}
    </group>
  );
}

export function World(p: {
  mode: Mode;
  carId: string;
  night: boolean;
  lights: boolean;
  autoRotate: boolean;
  hover: string | null;
  onPick: (id: string) => void;
  onHover: (id: string | null) => void;
}) {
  const a = getCarAsset(p.carId);
  const scale = Math.max(1, a.length / 2.45, a.height / 1.05);
  const ty = Math.max(0.42, a.height * 0.42);
  const fit = useMemo(() => ({ scale, ty }), [scale, ty]);
  return (
    <>
      <SirenTicker />
      <Lights night={p.night} wide={p.mode !== "garage"} />
      <CameraRig mode={p.mode} fit={fit} />
      {p.mode === "garage" && <Garage carId={p.carId} night={p.night} lights={p.lights} autoRotate={p.autoRotate} />}
      {p.mode === "road" && <Road night={p.night} onPick={p.onPick} onHover={p.onHover} />}
      {p.mode === "lineup" && <Lineup carId={p.carId} night={p.night} hover={p.hover} onPick={p.onPick} onHover={p.onHover} />}
    </>
  );
}
