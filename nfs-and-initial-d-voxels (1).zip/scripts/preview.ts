// Offline preview: rasterizes every voxel car (with AO) into PPM tiles for visual QA.
import { writeFileSync, mkdirSync } from "fs";
import { CARS } from "../src/cars";
import { meshVox, centerOffset } from "../src/voxel/mesher";
import { kindOf } from "../src/voxel/palette";

const W = 420;
const H = 260;
const OUT = "/tmp/preview";
mkdirSync(OUT, { recursive: true });

type V3 = [number, number, number];
const norm = (v: V3): V3 => {
  const l = Math.hypot(v[0], v[1], v[2]);
  return [v[0] / l, v[1] / l, v[2] / l];
};
const cross = (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

type MeshIn = { pos: Float32Array; nor: Float32Array; col: Float32Array; glowStart: number };
function render(pos: Float32Array, nor: Float32Array, col: Float32Array, glowStart: number, camDir: V3, scale: number, yMid = 0.4, extra: MeshIn[] = []) {
  const img = new Uint8Array(W * H * 3);
  const zb = new Float32Array(W * H).fill(Infinity);
  for (let i = 0; i < W * H; i++) {
    const y = Math.floor(i / W);
    const t = y / H;
    img[i * 3] = 200 + 40 * t;
    img[i * 3 + 1] = 225 + 20 * t;
    img[i * 3 + 2] = 240;
  }
  for (const m of [{ pos, nor, col, glowStart }, ...extra]) draw(img, zb, m.pos, m.nor, m.col, m.glowStart, camDir, scale, yMid);
  return img;
}

function draw(img: Uint8Array, zb: Float32Array, pos: Float32Array, nor: Float32Array, col: Float32Array, glowStart: number, camDir: V3, scale: number, yMid: number) {
  const f = norm([-camDir[0], -camDir[1], -camDir[2]]);
  const r = norm(cross(f, [0, 1, 0]));
  const u = cross(r, f);
  const light = norm([0.5, 0.9, 0.35]);
  const proj = (i: number) => {
    const p: V3 = [pos[i * 3], pos[i * 3 + 1] - yMid, pos[i * 3 + 2]];
    return [dot(p, r) * scale + W / 2, -dot(p, u) * scale + H / 2, dot(p, f)];
  };
  const vcount = pos.length / 3;
  for (let t = 0; t < vcount; t += 3) {
    const a = proj(t), b = proj(t + 1), c = proj(t + 2);
    const n: V3 = [nor[t * 3], nor[t * 3 + 1], nor[t * 3 + 2]];
    if (dot(n, f) > 0) continue; // backface
    const glow = t >= glowStart;
    const shade = glow ? 1 : 0.5 + 0.55 * Math.max(0, dot(n, light));
    const minX = Math.max(0, Math.floor(Math.min(a[0], b[0], c[0])));
    const maxX = Math.min(W - 1, Math.ceil(Math.max(a[0], b[0], c[0])));
    const minY = Math.max(0, Math.floor(Math.min(a[1], b[1], c[1])));
    const maxY = Math.min(H - 1, Math.ceil(Math.max(a[1], b[1], c[1])));
    const area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
    if (Math.abs(area) < 1e-9) continue;
    for (let y = minY; y <= maxY; y++)
      for (let x = minX; x <= maxX; x++) {
        const px = x + 0.5, py = y + 0.5;
        const w0 = ((b[0] - px) * (c[1] - py) - (b[1] - py) * (c[0] - px)) / area;
        const w1 = ((c[0] - px) * (a[1] - py) - (c[1] - py) * (a[0] - px)) / area;
        const w2 = 1 - w0 - w1;
        if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
        const z = w0 * a[2] + w1 * b[2] + w2 * c[2];
        const k = y * W + x;
        if (z >= zb[k]) continue;
        zb[k] = z;
        for (let ch = 0; ch < 3; ch++) {
          const cv = w0 * col[t * 3 + ch] + w1 * col[(t + 1) * 3 + ch] + w2 * col[(t + 2) * 3 + ch];
          img[k * 3 + ch] = Math.min(255, Math.round(cv * shade * 255));
        }
      }
  }
}

// same transforms as CarModel.tsx PartMesh (open state)
function transformPart(pos: Float32Array, nor: Float32Array, pv: V3, kind: string, dir: number) {
  const P2 = new Float32Array(pos.length);
  const N2 = new Float32Array(nor.length);
  const rot = (x: number, y: number, z: number): V3 => {
    if (kind === "popup" || kind === "ladder") {
      const a = kind === "popup" ? -0.32 : -0.5;
      return [x, y * Math.cos(a) - z * Math.sin(a), y * Math.sin(a) + z * Math.cos(a)];
    }
    const b = kind === "swing" ? dir * (Math.PI / 2) : 0.75;
    return [x * Math.cos(b) + z * Math.sin(b), y, -x * Math.sin(b) + z * Math.cos(b)];
  };
  for (let i = 0; i < pos.length; i += 3) {
    const r = rot(pos[i] - pv[0], pos[i + 1] - pv[1], pos[i + 2] - pv[2]);
    P2[i] = r[0] + pv[0];
    P2[i + 1] = r[1] + pv[1] + (kind === "popup" ? 0.16 : 0);
    P2[i + 2] = r[2] + pv[2];
    const n = rot(nor[i], nor[i + 1], nor[i + 2]);
    N2[i] = n[0];
    N2[i + 1] = n[1];
    N2[i + 2] = n[2];
  }
  return { P2, N2 };
}

function ppm(path: string, img: Uint8Array) {
  const header = Buffer.from(`P6\n${W} ${H}\n255\n`);
  writeFileSync(path, Buffer.concat([header, Buffer.from(img)]));
}

const only = process.argv[2];
const OPEN = process.argv[3] === "open";
for (const spec of CARS) {
  if (only && !only.split(",").includes(spec.id)) continue;
  const b = spec.build();
  if (b.warnings.length) console.log("WARN", spec.id, b.warnings);
  const v = b.vox.clone();
  if (!OPEN) b.parts.forEach((p) => v.merge(p.vox));
  const off = centerOffset(b.vox);
  const m = meshVox(v, 0.1, off, kindOf, false);
  const extra: MeshIn[] = [];
  if (OPEN)
    for (const p of b.parts) {
      const pm = meshVox(p.vox, 0.1, off, kindOf, false);
      const pv: V3 = [(p.pivot[0] - off[0]) * 0.1, (p.pivot[1] - off[1]) * 0.1, (p.pivot[2] - off[2]) * 0.1];
      const { P2, N2 } = transformPart(pm.positions, pm.normals, pv, p.kind, p.dir ?? 1);
      extra.push({ pos: P2, nor: N2, col: pm.colors, glowStart: pm.groups.find((g) => g.kind !== 0)?.start ?? Infinity });
    }
  const glowStart = m.groups.find((g) => g.kind !== 0)?.start ?? Infinity;
  const { min, max } = b.vox.bounds();
  console.log(spec.id.padEnd(14), "voxels", v.size, "size", max[0] - min[0] + 1, "x", max[1] - min[1] + 1, "x", max[2] - min[2] + 1);
  const vb = v.bounds();
  const ext = Math.max((vb.max[2] - vb.min[2] + 1) * 0.1, (vb.max[1] - vb.min[1] + 1) * 0.16);
  const k = Math.min(1, 2.5 / ext);
  const ym = Math.max(0.4, (vb.max[1] - vb.min[1] + 1) * 0.05);
  ppm(`${OUT}/${spec.id}_a.ppm`, render(m.positions, m.normals, m.colors, glowStart, [1.1, 0.75, 1.25], 118 * k, ym, extra));
  ppm(`${OUT}/${spec.id}_b.ppm`, render(m.positions, m.normals, m.colors, glowStart, [-1.1, 0.8, -1.2], 118 * k, ym, extra));
  ppm(`${OUT}/${spec.id}_c.ppm`, render(m.positions, m.normals, m.colors, glowStart, [1, 0.12, 0.0001], 125 * k, ym, extra));
}
