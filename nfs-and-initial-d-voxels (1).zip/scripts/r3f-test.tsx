import ReactThreeTestRenderer from "@react-three/test-renderer";
import { World, type Mode } from "../src/three/scenes";

async function run(mode: Mode, carId: string, night: boolean) {
  const r = await ReactThreeTestRenderer.create(
    <World mode={mode} carId={carId} night={night} lights={night} autoRotate hover={null} onPick={() => {}} onHover={() => {}} />
  );
  await r.advanceFrames(5, 0.016);
  let meshes = 0;
  r.scene.instance.traverse((o: any) => { if (o.isMesh) meshes++; });
  console.log(`${mode.padEnd(7)} ${carId.padEnd(8)} night=${night} meshes=${meshes} children=${r.scene.children.length}`);
  try { await r.unmount(); } catch { /* mock canvas has no ownerDocument */ }
}
(async () => {
  const [mode, car, night] = process.argv.slice(2);
  try {
    await run(mode as Mode, car, night === "1");
    console.log("R3F_OK");
    process.exit(0);
  } catch (e) { console.error("R3F_FAIL", e); process.exit(1); }
})();
