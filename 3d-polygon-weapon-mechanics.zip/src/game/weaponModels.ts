import * as THREE from 'three';
import { WeaponId } from './types';

export interface ArmRig {
  root: THREE.Group;
  handGroup: THREE.Group;
  forearmPivot: THREE.Group;
  basePos: THREE.Vector3;
  baseRot: THREE.Euler;
}

export interface ScopeLensUniforms {
  uScopeTex: { value: THREE.Texture | null };
  uEyeOffset: { value: THREE.Vector2 };
  uAdsBlend: { value: number };
}

export interface BuiltWeaponRig {
  id: WeaponId;
  root: THREE.Group; // Positioned in camera space
  gunBody: THREE.Group;
  slideOrBoltGroup: THREE.Group;
  boltHandlePivot?: THREE.Group;
  chargingHandleGroup?: THREE.Group;
  hammerPivot?: THREE.Group;
  triggerPivot: THREE.Group;
  magGroup: THREE.Group;
  magBasePos: THREE.Vector3;
  magBaseRot: THREE.Euler;
  chamberRound?: THREE.Mesh;
  muzzleAnchor: THREE.Object3D;
  ejectionAnchor: THREE.Object3D;
  mechanismAnchor: THREE.Object3D;
  magAnchor: THREE.Object3D;
  scopeOpticAnchor?: THREE.Object3D;
  scopeLensUniforms?: ScopeLensUniforms;
  leftArm: ArmRig;
  rightArm: ArmRig;
  scopeMeshes?: THREE.Object3D[];
}

// ============================================================================
// SCULPTED STYLIZED LOW-POLY MATERIALS
// ============================================================================
const MAT_HAND_WHITE = new THREE.MeshStandardMaterial({
  color: 0xf6f9fc,
  emissive: 0x262e38,
  emissiveIntensity: 0.38,
  roughness: 0.7,
  metalness: 0.02,
  flatShading: true,
});

const MAT_HAND_CUFF = new THREE.MeshStandardMaterial({
  color: 0xeaf0f6,
  emissive: 0x222933,
  emissiveIntensity: 0.36,
  roughness: 0.74,
  metalness: 0.03,
  flatShading: true,
});

// Classic crisp dark tactical gunmetal materials (for Pistol, Rifle & Sniper)
const MAT_GUN_DARK = new THREE.MeshStandardMaterial({
  color: 0x282d36,
  roughness: 0.54,
  metalness: 0.32,
  flatShading: true,
});

const MAT_GUN_DEEPER = new THREE.MeshStandardMaterial({
  color: 0x1d2128,
  roughness: 0.6,
  metalness: 0.28,
  flatShading: true,
});

const MAT_GUN_BLACK = new THREE.MeshStandardMaterial({
  color: 0x14171d,
  roughness: 0.52,
  metalness: 0.36,
  flatShading: true,
});

const MAT_SLATE_MID = new THREE.MeshStandardMaterial({
  color: 0x363d4a,
  roughness: 0.48,
  metalness: 0.38,
  flatShading: true,
});

const MAT_SLATE_LIGHT = new THREE.MeshStandardMaterial({
  color: 0x4f5869,
  roughness: 0.42,
  metalness: 0.48,
  flatShading: true,
});

const MAT_STEEL_BOLT = new THREE.MeshStandardMaterial({
  color: 0x626c7d,
  roughness: 0.35,
  metalness: 0.64,
  flatShading: true,
});

const MAT_STEEL_NICKEL = new THREE.MeshStandardMaterial({
  color: 0x8d97a8,
  roughness: 0.28,
  metalness: 0.74,
  flatShading: true,
});

const MAT_BORE_VOID = new THREE.MeshBasicMaterial({
  color: 0x090b10,
  side: THREE.DoubleSide,
});

// Beloved Classic Pistol Accents (Copper Barrel Hood, Hammer & Warm Grip Panels)
const MAT_COPPER = new THREE.MeshStandardMaterial({
  color: 0xc67e43,
  roughness: 0.44,
  metalness: 0.45,
  flatShading: true,
});

const MAT_GRIP_WOOD = new THREE.MeshStandardMaterial({
  color: 0xa66332,
  roughness: 0.68,
  metalness: 0.12,
  flatShading: true,
});

const MAT_SIGHT_ORANGE = new THREE.MeshStandardMaterial({
  color: 0xe68a3e,
  emissive: 0x4d2205,
  roughness: 0.35,
  metalness: 0.2,
  flatShading: true,
});

const MAT_BRASS = new THREE.MeshStandardMaterial({
  color: 0xe0b64c,
  roughness: 0.28,
  metalness: 0.8,
  flatShading: true,
});

const MAT_BULLET_COPPER = new THREE.MeshStandardMaterial({
  color: 0xc86d3b,
  roughness: 0.32,
  metalness: 0.68,
  flatShading: true,
});

// Beloved Rifle EOTech Holographic Sight Materials
const MAT_HOLO_GLASS = new THREE.MeshStandardMaterial({
  color: 0x3b946e,
  emissive: 0x103826,
  roughness: 0.12,
  metalness: 0.1,
  transparent: true,
  opacity: 0.28,
  depthWrite: false,
});

const MAT_HOLO_RETICLE = new THREE.MeshBasicMaterial({
  color: 0x6dffb3,
  transparent: true,
  opacity: 0.94,
  depthWrite: false,
});

const MAT_FRONT_COATED_GLASS = new THREE.MeshStandardMaterial({
  color: 0x2a7a8c,
  emissive: 0x0d3642,
  roughness: 0.1,
  metalness: 0.35,
  transparent: true,
  opacity: 0.6,
  flatShading: true,
});

function box(
  w: number,
  h: number,
  d: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  return m;
}

function cyl(
  rTop: number,
  rBot: number,
  len: number,
  segs: number,
  mat: THREE.Material,
  x = 0,
  y = 0,
  z = 0,
  rotX = Math.PI / 2,
  openEnded = false
): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, len, segs, 1, openEnded), mat);
  m.rotation.x = rotX;
  m.position.set(x, y, z);
  return m;
}

/**
 * Stitches N-sided 3D vertex rings into a manifold, non-indexed, flat-shaded low-poly BufferGeometry.
 */
function createLoftedGeometry(
  rings: THREE.Vector3[][],
  capStart = true,
  capEnd = true
): THREE.BufferGeometry {
  const positions: number[] = [];
  const pushTri = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3, refCenter: THREE.Vector3) => {
    const ab = new THREE.Vector3().subVectors(b, a);
    const ac = new THREE.Vector3().subVectors(c, a);
    const normal = new THREE.Vector3().crossVectors(ab, ac);
    const triCenter = new THREE.Vector3().add(a).add(b).add(c).multiplyScalar(1 / 3);
    const outward = new THREE.Vector3().subVectors(triCenter, refCenter);
    if (normal.dot(outward) >= 0) {
      positions.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
    } else {
      positions.push(a.x, a.y, a.z, c.x, c.y, c.z, b.x, b.y, b.z);
    }
  };

  const ringCenters = rings.map((r) => {
    const c = new THREE.Vector3();
    r.forEach((v) => c.add(v));
    return c.multiplyScalar(1 / r.length);
  });

  for (let r = 0; r < rings.length - 1; r++) {
    const r0 = rings[r];
    const r1 = rings[r + 1];
    const n = r0.length;
    const sliceCenter = new THREE.Vector3().addVectors(ringCenters[r], ringCenters[r + 1]).multiplyScalar(0.5);

    for (let i = 0; i < n; i++) {
      const next = (i + 1) % n;
      const a = r0[i];
      const b = r0[next];
      const c = r1[next];
      const d = r1[i];
      pushTri(a, b, c, sliceCenter);
      pushTri(a, c, d, sliceCenter);
    }
  }

  if (capStart && rings.length >= 2) {
    const first = rings[0];
    const c0 = ringCenters[0];
    const interior = ringCenters[1];
    for (let i = 0; i < first.length; i++) {
      pushTri(c0, first[i], first[(i + 1) % first.length], interior);
    }
  }

  if (capEnd && rings.length >= 2) {
    const last = rings[rings.length - 1];
    const cLast = ringCenters[rings.length - 1];
    const interior = ringCenters[rings.length - 2];
    for (let i = 0; i < last.length; i++) {
      pushTri(cLast, last[i], last[(i + 1) % last.length], interior);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.computeVertexNormals();
  return geo;
}

function buildExtrudedProfileX(
  yzPoints: [number, number][],
  width: number,
  mat: THREE.Material
): THREE.Mesh {
  const shape = new THREE.Shape();
  yzPoints.forEach(([y, z], idx) => {
    if (idx === 0) shape.moveTo(z, y);
    else shape.lineTo(z, y);
  });
  shape.closePath();

  const extrudeGeo = new THREE.ExtrudeGeometry(shape, {
    depth: width,
    bevelEnabled: true,
    bevelThickness: Math.min(0.0028, width * 0.11),
    bevelSize: Math.min(0.0022, width * 0.09),
    bevelSegments: 1,
    curveSegments: 1,
  });
  extrudeGeo.translate(0, 0, -width * 0.5);
  extrudeGeo.rotateY(Math.PI / 2);
  const nonIndexed = extrudeGeo.toNonIndexed();
  nonIndexed.computeVertexNormals();
  return new THREE.Mesh(nonIndexed, mat);
}

// ============================================================================
// SCULPTED WHITE POLYGON HANDS
// ============================================================================
function buildJointedDigitMesh(
  joints: THREE.Vector3[],
  radii: { w: number; h: number }[],
  dorsalNormalHint: THREE.Vector3,
  mat: THREE.Material
): THREE.Mesh {
  const rings: THREE.Vector3[][] = [];
  let prevUp = dorsalNormalHint.clone().normalize();

  for (let i = 0; i < joints.length; i++) {
    const p = joints[i];
    const tangent = new THREE.Vector3();
    if (i === 0) {
      tangent.subVectors(joints[1], joints[0]).normalize();
    } else if (i === joints.length - 1) {
      tangent.subVectors(joints[i], joints[i - 1]).normalize();
    } else {
      const dIn = new THREE.Vector3().subVectors(joints[i], joints[i - 1]).normalize();
      const dOut = new THREE.Vector3().subVectors(joints[i + 1], joints[i]).normalize();
      tangent.addVectors(dIn, dOut);
      if (tangent.lengthSq() < 1e-5) tangent.copy(dOut);
      else tangent.normalize();
    }

    const right = new THREE.Vector3().crossVectors(tangent, prevUp);
    if (right.lengthSq() < 1e-5) {
      right.crossVectors(tangent, new THREE.Vector3(0, 1, 0));
    }
    right.normalize();
    const up = new THREE.Vector3().crossVectors(right, tangent).normalize();
    prevUp = up;

    const { w, h } = radii[i];
    const profile: [number, number][] = [
      [-w * 0.62, h * 0.96],
      [w * 0.62, h * 0.96],
      [w * 1.0, h * 0.12],
      [w * 0.66, -h * 0.92],
      [-w * 0.66, -h * 0.92],
      [-w * 1.0, h * 0.12],
    ];

    const ring = profile.map(([rx, ry]) =>
      p.clone().addScaledVector(right, rx).addScaledVector(up, ry)
    );
    rings.push(ring);
  }

  return new THREE.Mesh(createLoftedGeometry(rings, true, true), mat);
}

function buildSculptedPalmMesh(s: number, mat: THREE.Material): THREE.Mesh {
  const makePalmRing = (
    z: number,
    dorsalX: number,
    palmarX: number,
    topY: number,
    botY: number,
    ridgeBoostX: number,
    yShift = 0
  ): THREE.Vector3[] => {
    const midY = (topY + botY) * 0.5 + yShift;
    const halfH = (topY - botY) * 0.5;
    return [
      new THREE.Vector3(s * (dorsalX * 0.55), midY + halfH * 0.98, z),
      new THREE.Vector3(s * (dorsalX + ridgeBoostX * 0.65), midY + halfH * 0.52, z),
      new THREE.Vector3(s * (dorsalX + ridgeBoostX), midY - halfH * 0.04, z),
      new THREE.Vector3(s * (dorsalX + ridgeBoostX * 0.45), midY - halfH * 0.62, z),
      new THREE.Vector3(s * (dorsalX * 0.45), midY - halfH * 0.98, z),
      new THREE.Vector3(-s * (palmarX * 0.72), midY - halfH * 0.82, z),
      new THREE.Vector3(-s * palmarX, midY + halfH * 0.02, z),
      new THREE.Vector3(-s * (palmarX * 0.85), midY + halfH * 0.86, z),
    ];
  };

  const rings: THREE.Vector3[][] = [
    makePalmRing(0.044, 0.019, 0.016, 0.025, -0.025, 0.003, -0.004),
    makePalmRing(0.022, 0.023, 0.018, 0.034, -0.03, 0.007, 0.0),
    makePalmRing(-0.006, 0.025, 0.017, 0.038, -0.035, 0.009, 0.002),
    makePalmRing(-0.033, 0.023, 0.015, 0.037, -0.036, 0.006, 0.001),
    makePalmRing(-0.041, 0.017, 0.012, 0.034, -0.034, 0.003, 0.0),
  ];

  return new THREE.Mesh(createLoftedGeometry(rings, true, true), mat);
}

function buildSculptedForearmAndCuff(elbowOffset: THREE.Vector3, wristOrigin: THREE.Vector3): THREE.Group {
  const forearmPivot = new THREE.Group();
  forearmPivot.position.copy(wristOrigin);

  const dir = elbowOffset.clone().sub(wristOrigin);
  const armLen = Math.max(0.24, dir.length());
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());

  const holder = new THREE.Group();
  holder.quaternion.copy(q);
  forearmPivot.add(holder);

  const makeOctRing = (y: number, rx: number, rz: number): THREE.Vector3[] => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i < 8; i++) {
      const ang = (i / 8) * Math.PI * 2 + Math.PI / 8;
      pts.push(new THREE.Vector3(Math.cos(ang) * rx, y, Math.sin(ang) * rz));
    }
    return pts;
  };

  const cuffRings = [
    makeOctRing(-0.004, 0.024, 0.029),
    makeOctRing(0.006, 0.026, 0.031),
    makeOctRing(0.012, 0.031, 0.036),
    makeOctRing(0.042, 0.032, 0.037),
    makeOctRing(0.046, 0.029, 0.034),
  ];
  holder.add(new THREE.Mesh(createLoftedGeometry(cuffRings, true, true), MAT_HAND_CUFF));

  const sleeveRings = [
    makeOctRing(0.044, 0.03, 0.035),
    makeOctRing(0.14, 0.036, 0.04),
    makeOctRing(armLen * 0.58, 0.043, 0.046),
    makeOctRing(armLen, 0.049, 0.052),
  ];
  holder.add(new THREE.Mesh(createLoftedGeometry(sleeveRings, true, true), MAT_HAND_WHITE));

  return forearmPivot;
}

function buildPolygonArm(
  side: 'left' | 'right',
  gripStyle: 'pistolSupport' | 'pistolPrimary' | 'rifleForend' | 'pistolGrip' | 'sniperForend',
  elbowOffset: THREE.Vector3
): ArmRig {
  const s = side === 'right' ? 1 : -1;
  const root = new THREE.Group();
  const handGroup = new THREE.Group();
  root.add(handGroup);

  handGroup.add(buildSculptedPalmMesh(s, MAT_HAND_WHITE));
  const dorsalOut = new THREE.Vector3(s, 0.15, 0).normalize();

  const fingerBaseYs = [0.026, 0.009, -0.009, -0.026];
  const fingerRadiiSets = [
    [
      { w: 0.0088, h: 0.0082 },
      { w: 0.0082, h: 0.0076 },
      { w: 0.0074, h: 0.0068 },
      { w: 0.0062, h: 0.0056 },
    ],
    [
      { w: 0.0092, h: 0.0085 },
      { w: 0.0085, h: 0.0078 },
      { w: 0.0076, h: 0.007 },
      { w: 0.0064, h: 0.0058 },
    ],
    [
      { w: 0.0088, h: 0.0082 },
      { w: 0.008, h: 0.0075 },
      { w: 0.0072, h: 0.0066 },
      { w: 0.006, h: 0.0055 },
    ],
    [
      { w: 0.0078, h: 0.0074 },
      { w: 0.0072, h: 0.0068 },
      { w: 0.0064, h: 0.006 },
      { w: 0.0053, h: 0.005 },
    ],
  ];

  fingerBaseYs.forEach((fy, idx) => {
    const reachScale = idx === 1 ? 1.06 : idx === 3 ? 0.86 : 0.98;
    let joints: THREE.Vector3[];

    if (idx === 0 && (gripStyle === 'pistolPrimary' || gripStyle === 'pistolGrip')) {
      joints = [
        new THREE.Vector3(s * 0.012, fy, -0.032),
        new THREE.Vector3(s * 0.01, fy + 0.002, -0.056),
        new THREE.Vector3(s * 0.001, fy + 0.001, -0.076),
        new THREE.Vector3(-s * 0.014, fy, -0.079),
      ];
    } else if (gripStyle === 'pistolGrip') {
      joints = [
        new THREE.Vector3(s * 0.012, fy, -0.032),
        new THREE.Vector3(s * 0.011, fy - 0.002, -0.056 * reachScale),
        new THREE.Vector3(-s * 0.012, fy - 0.004, -0.062 * reachScale),
        new THREE.Vector3(-s * 0.032, fy - 0.005, -0.044 * reachScale),
      ];
    } else if (gripStyle === 'pistolPrimary') {
      joints = [
        new THREE.Vector3(s * 0.012, fy, -0.032),
        new THREE.Vector3(s * 0.01, fy - 0.001, -0.054 * reachScale),
        new THREE.Vector3(-s * 0.012, fy - 0.002, -0.058 * reachScale),
        new THREE.Vector3(-s * 0.028, fy - 0.002, -0.04 * reachScale),
      ];
    } else if (gripStyle === 'pistolSupport') {
      joints = [
        new THREE.Vector3(s * 0.013, fy, -0.032),
        new THREE.Vector3(s * 0.008, fy - 0.001, -0.058 * reachScale),
        new THREE.Vector3(-s * 0.018, fy - 0.002, -0.064 * reachScale),
        new THREE.Vector3(-s * 0.038, fy - 0.002, -0.046 * reachScale),
      ];
    } else {
      const wrapWidth = gripStyle === 'sniperForend' ? 0.044 : 0.04;
      joints = [
        new THREE.Vector3(s * 0.012, fy, -0.032),
        new THREE.Vector3(s * 0.004, fy + 0.003, -0.055 * reachScale),
        new THREE.Vector3(-s * (wrapWidth * 0.65), fy + 0.012, -0.058 * reachScale),
        new THREE.Vector3(-s * wrapWidth, fy + 0.032, -0.044 * reachScale),
      ];
    }

    handGroup.add(buildJointedDigitMesh(joints, fingerRadiiSets[idx], dorsalOut, MAT_HAND_WHITE));
  });

  const thumbRadii = [
    { w: 0.0165, h: 0.0145 },
    { w: 0.0125, h: 0.0112 },
    { w: 0.0104, h: 0.0095 },
    { w: 0.0082, h: 0.0074 },
  ];

  let thumbJoints: THREE.Vector3[];
  if (gripStyle === 'pistolSupport') {
    thumbJoints = [
      new THREE.Vector3(s * 0.006, 0.022, 0.016),
      new THREE.Vector3(s * 0.009, 0.044, -0.008),
      new THREE.Vector3(s * 0.006, 0.054, -0.038),
      new THREE.Vector3(s * 0.002, 0.057, -0.068),
    ];
  } else if (gripStyle === 'pistolPrimary') {
    thumbJoints = [
      new THREE.Vector3(s * 0.006, 0.022, 0.018),
      new THREE.Vector3(s * 0.008, 0.044, -0.004),
      new THREE.Vector3(s * 0.003, 0.052, -0.03),
      new THREE.Vector3(-s * 0.003, 0.053, -0.054),
    ];
  } else if (gripStyle === 'rifleForend' || gripStyle === 'sniperForend') {
    thumbJoints = [
      new THREE.Vector3(s * 0.006, 0.022, 0.014),
      new THREE.Vector3(s * 0.004, 0.046, -0.012),
      new THREE.Vector3(-s * 0.004, 0.062, -0.04),
      new THREE.Vector3(-s * 0.01, 0.068, -0.068),
    ];
  } else {
    thumbJoints = [
      new THREE.Vector3(s * 0.005, 0.022, 0.016),
      new THREE.Vector3(-s * 0.002, 0.042, -0.004),
      new THREE.Vector3(-s * 0.018, 0.046, -0.022),
      new THREE.Vector3(-s * 0.032, 0.042, -0.016),
    ];
  }

  handGroup.add(
    buildJointedDigitMesh(
      thumbJoints,
      thumbRadii,
      new THREE.Vector3(s * 0.65, 0.75, 0).normalize(),
      MAT_HAND_WHITE
    )
  );

  const wristOrigin = new THREE.Vector3(s * 0.002, -0.004, 0.042);
  const forearmPivot = buildSculptedForearmAndCuff(elbowOffset, wristOrigin);
  root.add(forearmPivot);

  return {
    root,
    handGroup,
    forearmPivot,
    basePos: new THREE.Vector3(),
    baseRot: new THREE.Euler(),
  };
}

function buildCartridgeMesh(scale = 1, steelCase = false): THREE.Group {
  const g = new THREE.Group();
  const caseMat = steelCase ? MAT_STEEL_NICKEL : MAT_BRASS;
  const tipMat = steelCase ? MAT_STEEL_BOLT : MAT_BULLET_COPPER;
  const casing = cyl(0.0055 * scale, 0.006 * scale, 0.024 * scale, 7, caseMat, 0, 0, 0.006 * scale);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.0052 * scale, 0.014 * scale, 7), tipMat);
  tip.rotation.x = -Math.PI / 2;
  tip.position.z = -0.012 * scale;
  g.add(casing, tip);
  return g;
}

/**
 * Crystal-Clear, Zero-Jitter Optical Magnifying Scope Lens Shader!
 * Uses derivative-based screen-space anti-aliasing (fwidth) for razor-sharp reticle lines,
 * bright optical transmission, convex glass magnification curve, and clean rim anti-aliasing.
 */
function createLiveMagnifyingScopeMaterial(
  scopeTexture?: THREE.Texture
): { material: THREE.ShaderMaterial; uniforms: ScopeLensUniforms } {
  const uniforms: ScopeLensUniforms = {
    uScopeTex: { value: scopeTexture ?? null },
    uEyeOffset: { value: new THREE.Vector2(0, 0) },
    uAdsBlend: { value: 0 },
  };

  const material = new THREE.ShaderMaterial({
    uniforms: uniforms as unknown as Record<string, THREE.IUniform>,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      varying vec3 vViewPos;
      varying vec3 vViewNormal;
      void main() {
        vUv = uv;
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPos = -mvPosition.xyz;
        vViewNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D uScopeTex;
      uniform vec2 uEyeOffset;
      uniform float uAdsBlend;
      varying vec2 vUv;
      varying vec3 vViewPos;
      varying vec3 vViewNormal;

      void main() {
        vec2 p = vUv * 2.0 - 1.0;
        float r2 = dot(p, p);
        float r = sqrt(r2);

        // Clean convex optical magnifying curve
        float magCurve = 0.88 + 0.12 * r2;
        vec2 parallax = uEyeOffset * (1.0 - uAdsBlend * 0.92);
        vec2 sampleUv = clamp((p * magCurve + parallax) * 0.5 + 0.5, vec2(0.008), vec2(0.992));

        // Sample high-res MSAA render target & apply crisp optical clarity + sRGB vibrancy match
        vec3 sceneCol = texture2D(uScopeTex, sampleUv).rgb;
        sceneCol = pow(max(sceneCol, vec3(0.0)), vec3(0.88)) * 1.14;

        // Derivative-AA Etched Precision Sniper Reticle (Zero shimmer, razor-sharp at every distance!)
        vec2 rp = p + parallax * 0.15;
        float pxSize = max(fwidth(rp.x), 0.004);
        float thinHalf = pxSize * 0.85;
        float postHalf = pxSize * 2.2;

        float hCross = (1.0 - smoothstep(thinHalf * 0.5, thinHalf * 1.5, abs(rp.y))) * smoothstep(0.035, 0.05, abs(rp.x));
        float vCross = (1.0 - smoothstep(thinHalf * 0.5, thinHalf * 1.5, abs(rp.x))) * smoothstep(0.035, 0.05, abs(rp.y));

        // Outer heavy duplex posts
        float outerPosts =
          (1.0 - smoothstep(postHalf * 0.6, postHalf * 1.5, abs(rp.y))) * smoothstep(0.54, 0.56, abs(rp.x)) +
          (1.0 - smoothstep(postHalf * 0.6, postHalf * 1.5, abs(rp.x))) * smoothstep(0.54, 0.56, -rp.y);

        // Clean Mil-Dot hash ticks along inner stadia
        float ticks = 0.0;
        for (int i = -3; i <= 3; i++) {
          if (i != 0) {
            float tPos = float(i) * 0.13;
            float hTick = (1.0 - smoothstep(thinHalf * 0.6, thinHalf * 1.6, abs(rp.x - tPos))) * (1.0 - smoothstep(0.018, 0.026, abs(rp.y)));
            float vTick = (1.0 - smoothstep(thinHalf * 0.6, thinHalf * 1.6, abs(rp.y - tPos))) * (1.0 - smoothstep(0.018, 0.026, abs(rp.x)));
            ticks += hTick + vTick;
          }
        }

        float reticleAlpha = clamp(hCross + vCross + outerPosts + ticks, 0.0, 1.0);
        sceneCol = mix(sceneCol, vec3(0.04, 0.06, 0.08), reticleAlpha * 0.9);

        // Crisp Illuminated Red Center Dot
        float dotDist = length(rp);
        float redDot = 1.0 - smoothstep(pxSize * 1.3, pxSize * 2.5, dotDist);
        sceneCol = mix(sceneCol, vec3(1.0, 0.2, 0.15), redDot);

        // Subtle Multi-Coated Optical Glass Specular Sheen (Sky-Cyan & Emerald Rim Glint)
        vec3 viewDir = normalize(vViewPos);
        float fresnel = pow(1.0 - clamp(abs(dot(viewDir, normalize(vViewNormal))), 0.0, 1.0), 2.6);
        float glassStreak = smoothstep(0.26, 0.0, abs((p.x * 0.75 + p.y * 0.65) - 0.38)) * (1.0 - r2 * 0.65);
        sceneCol += vec3(0.22, 0.82, 0.78) * (fresnel * 0.26 + glassStreak * 0.09 * (1.0 - uAdsBlend * 0.75));

        // Clean Smooth Inner Scope Rim Bezel Feather (No dark stripes, pure optical clarity!)
        float innerEdge = smoothstep(1.01, 0.90, r);
        gl_FragColor = vec4(sceneCol * innerEdge, 1.0);
      }
    `,
  });

  return { material, uniforms };
}

// ============================================================================
// 1. POLYGON PISTOL — BELOVED CLASSIC DESIGN (Dark Slide + Copper Chamber + Warm Grip!)
// ============================================================================
export function buildPistolRig(): BuiltWeaponRig {
  const root = new THREE.Group();
  const gunBody = new THREE.Group();
  root.add(gunBody);

  // Lower Frame & Dust Cover
  const lowerFrame = box(0.042, 0.024, 0.235, MAT_GUN_DEEPER, 0, -0.004, -0.075);
  const rearTang = box(0.042, 0.024, 0.042, MAT_GUN_DEEPER, 0, -0.006, 0.056);
  gunBody.add(lowerFrame, rearTang);

  // Fixed Copper Barrel & Chamber Hood (visible through ejection window & exposed on blowback!)
  const chamberHood = box(0.026, 0.024, 0.058, MAT_COPPER, 0.003, 0.024, -0.042);
  const innerBarrel = cyl(0.0095, 0.0095, 0.165, 8, MAT_COPPER, 0, 0.024, -0.115);
  const muzzleBore = cyl(0.0065, 0.0065, 0.012, 8, MAT_GUN_BLACK, 0, 0.024, -0.198);
  gunBody.add(chamberHood, innerBarrel, muzzleBore);

  // Trigger Guard & Pivoting Dark Trigger
  const tgBottom = box(0.018, 0.007, 0.062, MAT_GUN_DEEPER, 0, -0.046, -0.018);
  const tgFront = box(0.018, 0.036, 0.008, MAT_GUN_DEEPER, 0, -0.028, -0.048);
  gunBody.add(tgBottom, tgFront);

  const triggerPivot = new THREE.Group();
  triggerPivot.position.set(0, -0.014, -0.012);
  const triggerBlade = box(0.009, 0.026, 0.008, MAT_GUN_BLACK, 0, -0.012, -0.004);
  triggerBlade.rotation.x = 0.28;
  triggerPivot.add(triggerBlade);
  gunBody.add(triggerPivot);

  // Angled Pistol Grip + Warm Classic Grip Panels
  const gripGroup = new THREE.Group();
  gripGroup.position.set(0, -0.014, 0.036);
  gripGroup.rotation.x = 0.24;
  const gripCore = box(0.038, 0.128, 0.056, MAT_GUN_DEEPER, 0, -0.062, 0);
  const gripPanelL = box(0.006, 0.104, 0.042, MAT_GRIP_WOOD, -0.02, -0.062, 0);
  const gripPanelR = box(0.006, 0.104, 0.042, MAT_GRIP_WOOD, 0.02, -0.062, 0);
  const gripBackCopper = box(0.024, 0.096, 0.008, MAT_COPPER, 0, -0.062, 0.027);
  gripGroup.add(gripCore, gripPanelL, gripPanelR, gripBackCopper);
  gunBody.add(gripGroup);

  // Rear Copper Hammer
  const hammerPivot = new THREE.Group();
  hammerPivot.position.set(0, 0.012, 0.062);
  const hammerBlock = box(0.014, 0.034, 0.018, MAT_COPPER, 0, 0.014, 0.004);
  hammerPivot.add(hammerBlock);
  gunBody.add(hammerPivot);

  // Removable Magazine with 9mm Brass Round on top
  const magGroup = new THREE.Group();
  magGroup.position.set(0, -0.082, 0.038);
  magGroup.rotation.x = 0.24;
  const magBody = box(0.028, 0.122, 0.044, MAT_GUN_BLACK, 0, 0, 0);
  const magBase = box(0.038, 0.014, 0.054, MAT_COPPER, 0, -0.065, 0.002);
  const topRound = buildCartridgeMesh(1.05);
  topRound.position.set(0, 0.066, -0.002);
  magGroup.add(magBody, magBase, topRound);
  gunBody.add(magGroup);

  // RECIPROCATING DARK CHARCOAL SLIDE GROUP
  const slideGroup = new THREE.Group();
  gunBody.add(slideGroup);

  const slideFront = box(0.046, 0.04, 0.125, MAT_GUN_DARK, 0, 0.026, -0.135);
  const slideFrontBevel = box(0.036, 0.007, 0.125, MAT_GUN_DARK, 0, 0.048, -0.135);
  const slideLeftWall = box(0.013, 0.042, 0.066, MAT_GUN_DARK, -0.0165, 0.026, -0.04);
  const slideLeftTop = box(0.016, 0.007, 0.066, MAT_GUN_DARK, -0.012, 0.048, -0.04);
  const slideRightRail = box(0.009, 0.014, 0.066, MAT_GUN_DARK, 0.0185, 0.012, -0.04);
  const slideRearL = box(0.015, 0.042, 0.078, MAT_GUN_DARK, -0.0155, 0.026, 0.032);
  const slideRearR = box(0.015, 0.042, 0.078, MAT_GUN_DARK, 0.0155, 0.026, 0.032);
  const slideRearBridge = box(0.02, 0.022, 0.056, MAT_GUN_DARK, 0, 0.036, 0.021);
  const slideRearTop = box(0.036, 0.007, 0.072, MAT_GUN_DARK, 0, 0.048, 0.029);

  const frontSightBase = box(0.01, 0.012, 0.018, MAT_GUN_DEEPER, 0, 0.054, -0.184);
  const frontSightDot = box(0.007, 0.009, 0.012, MAT_SIGHT_ORANGE, 0, 0.056, -0.181);
  const rearSightL = box(0.011, 0.012, 0.018, MAT_GUN_DEEPER, -0.012, 0.054, 0.052);
  const rearSightR = box(0.011, 0.012, 0.018, MAT_GUN_DEEPER, 0.012, 0.054, 0.052);
  const rearSightAccent = box(0.008, 0.005, 0.012, MAT_SIGHT_ORANGE, 0, 0.05, 0.052);

  slideGroup.add(
    slideFront,
    slideFrontBevel,
    slideLeftWall,
    slideLeftTop,
    slideRightRail,
    slideRearL,
    slideRearR,
    slideRearBridge,
    slideRearTop,
    frontSightBase,
    frontSightDot,
    rearSightL,
    rearSightR,
    rearSightAccent
  );

  const muzzleAnchor = new THREE.Object3D();
  muzzleAnchor.position.set(0, 0.024, -0.205);
  gunBody.add(muzzleAnchor);

  const ejectionAnchor = new THREE.Object3D();
  ejectionAnchor.position.set(0.022, 0.038, -0.042);
  gunBody.add(ejectionAnchor);

  const mechanismAnchor = new THREE.Object3D();
  mechanismAnchor.position.set(-0.022, 0.042, -0.09);
  slideGroup.add(mechanismAnchor);

  const magAnchor = new THREE.Object3D();
  magAnchor.position.set(0, -0.04, 0.038);
  magGroup.add(magAnchor);

  // Two-Handed Symmetrical Sculpted White Polygon Hands
  const rightArm = buildPolygonArm('right', 'pistolPrimary', new THREE.Vector3(0.21, -0.44, 0.43));
  rightArm.root.position.set(0.02, -0.046, 0.046);
  rightArm.root.rotation.set(0.22, -0.11, 0.14);
  rightArm.basePos.copy(rightArm.root.position);
  rightArm.baseRot.copy(rightArm.root.rotation);
  gunBody.add(rightArm.root);

  const leftArm = buildPolygonArm('left', 'pistolSupport', new THREE.Vector3(-0.21, -0.44, 0.43));
  leftArm.root.position.set(-0.022, -0.044, 0.038);
  leftArm.root.rotation.set(0.22, 0.13, -0.14);
  leftArm.basePos.copy(leftArm.root.position);
  leftArm.baseRot.copy(leftArm.root.rotation);
  gunBody.add(leftArm.root);

  return {
    id: 'pistol',
    root,
    gunBody,
    slideOrBoltGroup: slideGroup,
    hammerPivot,
    triggerPivot,
    magGroup,
    magBasePos: magGroup.position.clone(),
    magBaseRot: magGroup.rotation.clone(),
    muzzleAnchor,
    ejectionAnchor,
    mechanismAnchor,
    magAnchor,
    leftArm,
    rightArm,
  };
}

// ============================================================================
// 2. POLYGON RIFLE — M4A1 CARBINE WITH BELOVED GREEN HOLOGRAPHIC SIGHT!
// 100% Pure Tactical Charcoal / Gunmetal / Steel — ZERO brown or orange anywhere!
// ============================================================================
export function buildRifleRig(): BuiltWeaponRig {
  const root = new THREE.Group();
  const gunBody = new THREE.Group();
  root.add(gunBody);

  // Upper & Lower Receiver
  const upperReceiver = box(0.052, 0.052, 0.225, MAT_GUN_DARK, 0, 0.024, -0.04);
  const lowerReceiver = box(0.048, 0.048, 0.185, MAT_GUN_DEEPER, 0, -0.022, -0.035);
  const magwellFlare = box(0.054, 0.038, 0.082, MAT_GUN_DEEPER, 0, -0.038, -0.095);
  gunBody.add(upperReceiver, lowerReceiver, magwellFlare);

  // Right-Side Ejection Port + Reciprocating Steel Bolt Carrier Group
  const ejectionDarkRecess = box(0.008, 0.022, 0.076, MAT_GUN_BLACK, 0.025, 0.026, -0.055);
  const dustCoverFlap = box(0.006, 0.014, 0.074, MAT_GUN_DEEPER, 0.028, 0.009, -0.055);
  dustCoverFlap.rotation.z = -0.45;
  gunBody.add(ejectionDarkRecess, dustCoverFlap);

  const boltGroup = new THREE.Group();
  const boltCarrier = box(0.012, 0.02, 0.072, MAT_STEEL_BOLT, 0.023, 0.026, -0.055);
  boltGroup.add(boltCarrier);
  gunBody.add(boltGroup);

  // T-Shaped Charging Handle
  const chargingHandleGroup = new THREE.Group();
  chargingHandleGroup.position.set(0, 0.046, 0.072);
  const chStem = box(0.016, 0.012, 0.075, MAT_GUN_DEEPER, 0, 0, -0.03);
  const chCrossBar = box(0.074, 0.016, 0.022, MAT_GUN_BLACK, 0, 0.002, 0.008);
  chargingHandleGroup.add(chStem, chCrossBar);
  gunBody.add(chargingHandleGroup);

  // Buffer Tube & Collapsible M4 Buttstock (Pure Tactical Dark Gunmetal — NO brown/orange!)
  const bufferTube = cyl(0.021, 0.021, 0.28, 8, MAT_GUN_DEEPER, 0, 0.018, 0.21);
  const stockSpine = box(0.046, 0.05, 0.26, MAT_GUN_DARK, 0, 0.02, 0.235);
  const stockLower = box(0.034, 0.092, 0.175, MAT_GUN_DEEPER, 0, -0.026, 0.265);
  stockLower.rotation.x = -0.22;
  const buttPad = box(0.048, 0.128, 0.024, MAT_GUN_BLACK, 0, -0.014, 0.368);
  gunBody.add(bufferTube, stockSpine, stockLower, buttPad);

  // Picatinny Top Rail + Discrete Rail Teeth
  const railSpine = box(0.032, 0.009, 0.22, MAT_GUN_DEEPER, 0, 0.054, -0.04);
  gunBody.add(railSpine);
  for (let i = 0; i < 11; i++) {
    gunBody.add(box(0.036, 0.007, 0.011, MAT_GUN_BLACK, 0, 0.06, 0.055 - i * 0.02));
  }

  // BELOVED EOTECH-STYLE HOLOGRAPHIC SIGHT (Exact match to Screenshot 1!)
  const holoGroup = new THREE.Group();
  holoGroup.position.set(0, 0.064, -0.075);
  const holoBase = box(0.046, 0.018, 0.108, MAT_GUN_BLACK, 0, 0.008, 0);
  const holoBatteryFwd = box(0.042, 0.022, 0.048, MAT_GUN_DARK, 0, 0.018, -0.032);
  const hoodL = box(0.008, 0.046, 0.062, MAT_GUN_DARK, -0.021, 0.038, 0.012);
  const hoodR = box(0.008, 0.046, 0.062, MAT_GUN_DARK, 0.021, 0.038, 0.012);
  const hoodTop = box(0.048, 0.009, 0.062, MAT_GUN_DARK, 0, 0.062, 0.012);
  const hoodGlass = box(0.034, 0.038, 0.003, MAT_HOLO_GLASS, 0, 0.038, 0.012);

  // Glowing Green Holographic Circle + 4 Crosshair Ticks + Center Dot Reticle!
  const reticleRing = new THREE.Mesh(new THREE.RingGeometry(0.0078, 0.0094, 24), MAT_HOLO_RETICLE);
  reticleRing.position.set(0, 0.038, 0.01);
  const reticleDot = new THREE.Mesh(new THREE.CircleGeometry(0.0018, 12), MAT_HOLO_RETICLE);
  reticleDot.position.set(0, 0.038, 0.0095);

  const tickGeoV = new THREE.PlaneGeometry(0.0012, 0.0036);
  const tickGeoH = new THREE.PlaneGeometry(0.0036, 0.0012);
  const tickTop = new THREE.Mesh(tickGeoV, MAT_HOLO_RETICLE);
  tickTop.position.set(0, 0.0465, 0.0096);
  const tickBot = new THREE.Mesh(tickGeoV, MAT_HOLO_RETICLE);
  tickBot.position.set(0, 0.0295, 0.0096);
  const tickL = new THREE.Mesh(tickGeoH, MAT_HOLO_RETICLE);
  tickL.position.set(-0.0085, 0.038, 0.0096);
  const tickR = new THREE.Mesh(tickGeoH, MAT_HOLO_RETICLE);
  tickR.position.set(0.0085, 0.038, 0.0096);

  holoGroup.add(
    holoBase,
    holoBatteryFwd,
    hoodL,
    hoodR,
    hoodTop,
    hoodGlass,
    reticleRing,
    reticleDot,
    tickTop,
    tickBot,
    tickL,
    tickR
  );
  gunBody.add(holoGroup);

  // Ribbed Cylindrical Quad-Rail Handguard
  const deltaRing = cyl(0.032, 0.035, 0.026, 8, MAT_GUN_BLACK, 0, 0.024, -0.165);
  const hgCore = cyl(0.028, 0.028, 0.245, 8, MAT_GUN_DEEPER, 0, 0.024, -0.298);
  const hgTopRail = box(0.022, 0.012, 0.24, MAT_GUN_BLACK, 0, 0.052, -0.298);
  const hgBotRail = box(0.022, 0.012, 0.24, MAT_GUN_BLACK, 0, -0.004, -0.298);
  gunBody.add(deltaRing, hgCore, hgTopRail, hgBotRail);

  for (let i = 0; i < 9; i++) {
    gunBody.add(cyl(0.034, 0.034, 0.014, 8, MAT_GUN_DARK, 0, 0.024, -0.19 - i * 0.026));
  }

  // A2 Triangle Front Sight Post + Barrel + Birdcage Flash Hider (Pure Dark Gunmetal!)
  const barrel = cyl(0.011, 0.012, 0.21, 8, MAT_GUN_DEEPER, 0, 0.024, -0.505);
  const flashHider = cyl(0.0145, 0.0145, 0.048, 8, MAT_GUN_BLACK, 0, 0.024, -0.618);
  const muzzleHole = cyl(0.008, 0.008, 0.01, 8, MAT_BORE_VOID, 0, 0.024, -0.642);

  const fsFrontLeg = box(0.011, 0.072, 0.012, MAT_GUN_DARK, 0, 0.062, -0.468);
  fsFrontLeg.rotation.x = 0.28;
  const fsRearLeg = box(0.011, 0.068, 0.011, MAT_GUN_DARK, 0, 0.06, -0.438);
  fsRearLeg.rotation.x = -0.12;
  const fsTopPost = box(0.005, 0.016, 0.006, MAT_GUN_BLACK, 0, 0.098, -0.453);
  const fsBaseRing = cyl(0.017, 0.017, 0.048, 8, MAT_GUN_BLACK, 0, 0.024, -0.452);

  gunBody.add(barrel, flashHider, muzzleHole, fsFrontLeg, fsRearLeg, fsTopPost, fsBaseRing);

  // Angled Pistol Grip + Trigger Guard + Trigger
  const gripGroup = new THREE.Group();
  gripGroup.position.set(0, -0.042, 0.026);
  gripGroup.rotation.x = 0.34;
  gripGroup.add(box(0.034, 0.112, 0.046, MAT_GUN_BLACK, 0, -0.05, 0));
  gunBody.add(gripGroup);

  gunBody.add(box(0.014, 0.006, 0.056, MAT_GUN_BLACK, 0, -0.056, -0.028));

  const triggerPivot = new THREE.Group();
  triggerPivot.position.set(0, -0.032, -0.018);
  const triggerBlade = box(0.008, 0.024, 0.008, MAT_STEEL_BOLT, 0, -0.011, -0.003);
  triggerBlade.rotation.x = 0.25;
  triggerPivot.add(triggerBlade);
  gunBody.add(triggerPivot);

  // Curved Ribbed 30-Round STANAG Magazine (Nickel-steel top cartridge so ZERO brown/copper on Rifle!)
  const magGroup = new THREE.Group();
  magGroup.position.set(0, -0.052, -0.095);
  const magUpper = box(0.032, 0.088, 0.068, MAT_GUN_DARK, 0, -0.038, 0);
  magUpper.rotation.x = -0.12;
  const magLower = box(0.032, 0.105, 0.068, MAT_GUN_DARK, 0, -0.118, -0.022);
  magLower.rotation.x = -0.32;
  const magRib1 = box(0.036, 0.155, 0.009, MAT_GUN_DEEPER, 0, -0.082, -0.002);
  magRib1.rotation.x = -0.22;
  const magRib2 = box(0.036, 0.155, 0.009, MAT_GUN_DEEPER, 0, -0.086, -0.022);
  magRib2.rotation.x = -0.22;
  const topRound556 = buildCartridgeMesh(1.15, true);
  topRound556.position.set(0, 0.008, -0.006);
  magGroup.add(magUpper, magLower, magRib1, magRib2, topRound556);
  gunBody.add(magGroup);

  const muzzleAnchor = new THREE.Object3D();
  muzzleAnchor.position.set(0, 0.024, -0.646);
  gunBody.add(muzzleAnchor);

  const ejectionAnchor = new THREE.Object3D();
  ejectionAnchor.position.set(0.034, 0.028, -0.055);
  gunBody.add(ejectionAnchor);

  const mechanismAnchor = new THREE.Object3D();
  mechanismAnchor.position.set(0.03, 0.028, -0.055);
  boltGroup.add(mechanismAnchor);

  const magAnchor = new THREE.Object3D();
  magAnchor.position.set(0, -0.1, -0.11);
  magGroup.add(magAnchor);

  // Sculpted White Polygon Hands
  const rightArm = buildPolygonArm('right', 'pistolGrip', new THREE.Vector3(0.17, -0.44, 0.42));
  rightArm.root.position.set(0.016, -0.072, 0.048);
  rightArm.root.rotation.set(0.32, -0.06, 0.08);
  rightArm.basePos.copy(rightArm.root.position);
  rightArm.baseRot.copy(rightArm.root.rotation);
  gunBody.add(rightArm.root);

  const leftArm = buildPolygonArm('left', 'rifleForend', new THREE.Vector3(-0.22, -0.45, 0.5));
  leftArm.root.position.set(-0.024, -0.016, -0.275);
  leftArm.root.rotation.set(0.14, 0.18, -0.36);
  leftArm.basePos.copy(leftArm.root.position);
  leftArm.baseRot.copy(leftArm.root.rotation);
  gunBody.add(leftArm.root);

  return {
    id: 'rifle',
    root,
    gunBody,
    slideOrBoltGroup: boltGroup,
    chargingHandleGroup,
    triggerPivot,
    magGroup,
    magBasePos: magGroup.position.clone(),
    magBaseRot: magGroup.rotation.clone(),
    muzzleAnchor,
    ejectionAnchor,
    mechanismAnchor,
    magAnchor,
    leftArm,
    rightArm,
  };
}

// ============================================================================
// 3. POLYGON SNIPER — BARRETT M82A1 / M107 ANTI-MATERIEL STYLIZED POLYGON!
// 100% Reference Match: Dual-Chamber Boxy Muzzle Brake, Slotted Rectangular Forend Shroud,
// Folded Under-Barrel Bipod + Lower Rail, Continuous Top Picatinny Rail, Large Slanted Box Mag,
// AR-Style Standalone Pistol Grip, Open Triangle Skeleton Buttstock, & Sleek Compact Scope!
// ============================================================================
export function buildSniperRig(scopeTexture?: THREE.Texture): BuiltWeaponRig {
  const root = new THREE.Group();
  const gunBody = new THREE.Group();
  root.add(gunBody);

  // 1. CONTINUOUS BARRETT UPPER RECEIVER & VENTILATED SLOTTED HANDGUARD SHROUD (z = +0.085 to -0.495)
  // Main Upper Receiver Housing (z = +0.085 to -0.215) with crisp beveled top shoulders
  const makeBarrettUpperRing = (z: number, wHalf: number, yTop: number, yBot: number) => [
    new THREE.Vector3(-wHalf * 0.76, yTop, z),
    new THREE.Vector3(wHalf * 0.76, yTop, z),
    new THREE.Vector3(wHalf, yTop - 0.008, z),
    new THREE.Vector3(wHalf, yBot, z),
    new THREE.Vector3(-wHalf, yBot, z),
    new THREE.Vector3(-wHalf, yTop - 0.008, z),
  ];

  const upperReceiverBody = new THREE.Mesh(
    createLoftedGeometry(
      [
        makeBarrettUpperRing(0.085, 0.025, 0.048, 0.002),
        makeBarrettUpperRing(-0.215, 0.025, 0.048, 0.002),
      ],
      true,
      true
    ),
    MAT_GUN_DARK
  );
  gunBody.add(upperReceiverBody);

  // Slotted Rectangular Ventilated Forend Handguard Shroud (z = -0.215 to -0.495)
  const forendShroud = new THREE.Mesh(
    createLoftedGeometry(
      [
        makeBarrettUpperRing(-0.215, 0.026, 0.048, -0.012),
        makeBarrettUpperRing(-0.495, 0.025, 0.048, -0.01),
      ],
      true,
      true
    ),
    MAT_SLATE_MID
  );
  // Handguard Barrel Seam & Reinforcement Clamp Ring at z = -0.22
  const shroudCollar = box(0.055, 0.064, 0.018, MAT_GUN_BLACK, 0, 0.018, -0.22);
  const flipFrontSight = box(0.014, 0.012, 0.024, MAT_GUN_BLACK, 0, 0.059, -0.242);
  gunBody.add(forendShroud, shroudCollar, flipFrontSight);

  // 2 Rows × 6 Rectangular Cooling Vent Slots on Left & Right Sides of Forend Shroud!
  for (let col = 0; col < 6; col++) {
    const vz = -0.255 - col * 0.038;
    [-1, 1].forEach((side) => {
      const slotUpper = box(0.004, 0.008, 0.022, MAT_BORE_VOID, side * 0.0255, 0.029, vz);
      const slotLower = box(0.004, 0.008, 0.022, MAT_BORE_VOID, side * 0.0255, 0.009, vz);
      gunBody.add(slotUpper, slotLower);
    });
  }

  // Full-Length Continuous Top Picatinny Rail + Discrete Teeth (z = +0.08 to -0.49)
  const fullTopRail = box(0.026, 0.007, 0.57, MAT_GUN_DEEPER, 0, 0.051, -0.205);
  gunBody.add(fullTopRail);
  for (let i = 0; i < 24; i++) {
    gunBody.add(box(0.03, 0.005, 0.011, MAT_GUN_BLACK, 0, 0.055, 0.072 - i * 0.024));
  }

  // 2. LOWER RECEIVER + SLANTED FLARED MAGWELL + FOLDED UNDER-BARREL BIPOD & LOWER RAIL!
  const lowerReceiver = box(0.046, 0.034, 0.145, MAT_GUN_DEEPER, 0, -0.015, 0.015);
  // Slanted Angled Magwell Housing ahead of Trigger Guard (z = -0.035 to -0.195)
  const magwellHousingProfile: [number, number][] = [
    [0.002, -0.032],
    [0.002, -0.205],
    [-0.026, -0.195],
    [-0.052, -0.038], // Characteristic Barrett downward rear magwell slant!
  ];
  const magwellHousing = buildExtrudedProfileX(magwellHousingProfile, 0.05, MAT_SLATE_MID);
  const magwellHollowSlot = box(0.038, 0.014, 0.138, MAT_BORE_VOID, 0, -0.032, -0.118);
  const magReleaseCatch = box(0.014, 0.02, 0.008, MAT_STEEL_NICKEL, 0, -0.052, -0.032);
  gunBody.add(lowerReceiver, magwellHousing, magwellHollowSlot, magReleaseCatch);

  // Under-Handguard Lower Accessory Rail + Folded Twin Bipod Legs (Exact match to Reference!)
  const lowerPicRail = box(0.022, 0.009, 0.175, MAT_GUN_BLACK, 0, -0.018, -0.335);
  gunBody.add(lowerPicRail);
  for (let i = 0; i < 8; i++) {
    gunBody.add(box(0.025, 0.005, 0.01, MAT_GUN_DEEPER, 0, -0.024, -0.258 - i * 0.022));
  }
  const bipodMountBlock = box(0.038, 0.022, 0.032, MAT_GUN_BLACK, 0, -0.022, -0.445);
  gunBody.add(bipodMountBlock);
  [-1, 1].forEach((side) => {
    const bx = side * 0.024;
    const legRod = cyl(0.0055, 0.0055, 0.195, 7, MAT_GUN_DEEPER, bx, -0.026, -0.338);
    const legCollar = cyl(0.0075, 0.0075, 0.028, 7, MAT_SLATE_LIGHT, bx, -0.026, -0.255);
    const legFoot = box(0.014, 0.018, 0.018, MAT_GUN_BLACK, bx, -0.028, -0.232);
    gunBody.add(legRod, legCollar, legFoot);
  });

  // 3. STRAIGHT UPPER STOCK SPINE + OPEN TRIANGLE SKELETON BUTTSTOCK + STANDALONE AR PISTOL GRIP!
  // Straight Horizontal Upper Stock Spine (z = +0.085 to +0.365)
  const stockTopSpine = new THREE.Mesh(
    createLoftedGeometry(
      [
        makeBarrettUpperRing(0.085, 0.024, 0.044, -0.008),
        makeBarrettUpperRing(0.365, 0.022, 0.042, -0.006),
      ],
      true,
      true
    ),
    MAT_GUN_DARK
  );

  // Open Triangular Skeleton Frame Stock Struts + Contoured Rubber Buttpad!
  const skeletonStockProfile: [number, number][] = [
    [-0.006, 0.175],
    [-0.006, 0.205],
    [-0.072, 0.232], // Front diagonal strut down to monopod hook!
    [-0.078, 0.345], // Bottom strut back to heel!
    [-0.006, 0.345],
    [-0.006, 0.368],
    [-0.104, 0.368], // Buttstock heel
    [-0.095, 0.228],
    [-0.104, 0.214], // Signature Barrett bottom grip hook!
    [-0.092, 0.198],
  ];
  const skeletonFrame = buildExtrudedProfileX(skeletonStockProfile, 0.034, MAT_GUN_DEEPER);
  const rubberButtPad = box(0.046, 0.148, 0.024, MAT_GUN_BLACK, 0, -0.03, 0.376);
  gunBody.add(stockTopSpine, skeletonFrame, rubberButtPad);

  // Standalone Angled AR-Style Pistol Grip with Finger-Groove Bump (NO Thumbhole bridge — exact match!)
  const gripGroup = new THREE.Group();
  gripGroup.position.set(0, -0.034, 0.058);
  gripGroup.rotation.x = 0.44;
  const arGripBody = box(0.033, 0.112, 0.044, MAT_GUN_BLACK, 0, -0.052, 0);
  const fingerBump = box(0.034, 0.014, 0.012, MAT_GUN_DEEPER, 0, -0.042, -0.024);
  const gripBaseCap = box(0.037, 0.01, 0.05, MAT_GUN_DEEPER, 0, -0.108, 0.002);
  gripGroup.add(arGripBody, fingerBump, gripBaseCap);
  gunBody.add(gripGroup);

  // Rounded Trigger Guard + Curved Trigger Blade
  const tgLoopProfile: [number, number][] = [
    [-0.028, 0.042],
    [-0.058, 0.036],
    [-0.058, -0.022],
    [-0.032, -0.032],
    [-0.032, -0.023],
    [-0.05, -0.015],
    [-0.05, 0.028],
    [-0.028, 0.034],
  ];
  gunBody.add(buildExtrudedProfileX(tgLoopProfile, 0.015, MAT_GUN_BLACK));

  const triggerPivot = new THREE.Group();
  triggerPivot.position.set(0, -0.03, 0.012);
  const triggerBlade = box(0.008, 0.024, 0.008, MAT_STEEL_NICKEL, 0, -0.011, -0.002);
  triggerBlade.rotation.x = 0.24;
  triggerPivot.add(triggerBlade);
  gunBody.add(triggerPivot);

  // 4. LARGE BARRETT SLANTED-FLOORPLATE DETACHABLE BOX MAGAZINE (Crystal-clear during Reload!)
  const magGroup = new THREE.Group();
  magGroup.position.set(0, -0.052, -0.118);

  // Characteristic Barrett Magazine Profile: Taller at rear, angled upward toward front!
  const barrettMagProfile: [number, number][] = [
    [0.018, 0.068],
    [0.018, -0.068],
    [-0.088, -0.068], // Front bottom corner
    [-0.116, 0.068], // Deeper rear bottom heel!
  ];
  const magMainMesh = buildExtrudedProfileX(barrettMagProfile, 0.038, MAT_GUN_DARK);
  // Stamped Vertical Side Indentation Ribs (Iconic Barrett .50 / .338 mag stamping!)
  const magStampFwd = box(0.041, 0.078, 0.038, MAT_GUN_DEEPER, 0, -0.034, -0.032);
  const magStampRear = box(0.041, 0.092, 0.042, MAT_GUN_DEEPER, 0, -0.042, 0.028);
  const magSlantedPlate = box(0.044, 0.01, 0.142, MAT_GUN_BLACK, 0, -0.103, 0.0);
  magSlantedPlate.rotation.x = -0.2;

  // Gleaming Heavy Brass Cartridges with Copper Tips stacked in top feed lips!
  const feedLipsL = box(0.006, 0.014, 0.112, MAT_STEEL_BOLT, -0.015, 0.022, 0);
  const feedLipsR = box(0.006, 0.014, 0.112, MAT_STEEL_BOLT, 0.015, 0.022, 0);
  const topRound1 = buildCartridgeMesh(1.65);
  topRound1.position.set(0, 0.026, -0.008);
  const topRound2 = buildCartridgeMesh(1.6);
  topRound2.position.set(0.003, 0.014, -0.005);

  magGroup.add(magMainMesh, magStampFwd, magStampRear, magSlantedPlate, feedLipsL, feedLipsR, topRound1, topRound2);
  gunBody.add(magGroup);

  // 5. RIGHT-SIDE EJECTION PORT + RECIPROCATING BOLT & HANDLE ASSEMBLY
  const ejectionPortRecess = box(0.012, 0.022, 0.108, MAT_BORE_VOID, 0.021, 0.024, -0.085);
  gunBody.add(ejectionPortRecess);

  const chamberRoundGroup = buildCartridgeMesh(1.5);
  chamberRoundGroup.position.set(0.014, 0.024, -0.085);
  gunBody.add(chamberRoundGroup);

  const boltGroup = new THREE.Group();
  gunBody.add(boltGroup);
  const boltCarrier = box(0.014, 0.02, 0.115, MAT_STEEL_NICKEL, 0.019, 0.024, -0.082);
  boltGroup.add(boltCarrier);

  const boltHandlePivot = new THREE.Group();
  boltHandlePivot.position.set(0.02, 0.024, -0.042);
  const boltStem = cyl(0.0052, 0.006, 0.038, 7, MAT_STEEL_NICKEL, 0.018, -0.006, 0.002, 0);
  boltStem.rotation.z = -1.25;
  const boltKnob = new THREE.Mesh(new THREE.IcosahedronGeometry(0.0115, 1), MAT_GUN_BLACK);
  boltKnob.position.set(0.035, -0.014, 0.004);
  boltHandlePivot.add(boltStem, boltKnob);
  boltGroup.add(boltHandlePivot);

  // 6. LONG FLUTED MATCH BARREL + ICONIC BARRETT 2-CHAMBER ARROWHEAD BOXY MUZZLE BRAKE!
  const heavyBarrel = cyl(0.0145, 0.0175, 0.45, 10, MAT_SLATE_LIGHT, 0, 0.024, -0.715);
  gunBody.add(heavyBarrel);

  // Iconic Barrett Dual-Chamber Rectangular/Arrowhead Muzzle Brake at z = -0.96
  const brakeGroup = new THREE.Group();
  brakeGroup.position.set(0, 0.024, -0.962);
  const brakeNeck = cyl(0.021, 0.015, 0.024, 8, MAT_GUN_DARK, 0, 0, 0.042);
  const brakeTopPlate = box(0.056, 0.008, 0.086, MAT_GUN_DARK, 0, 0.018, -0.005);
  const brakeBotPlate = box(0.056, 0.008, 0.086, MAT_GUN_DARK, 0, -0.018, -0.005);
  const brakeCenterSpine = box(0.018, 0.028, 0.086, MAT_GUN_BLACK, 0, 0, -0.005);
  // Swept Rear Baffle Wall, Mid Divider Baffle, & Front Baffle Wall creating the 2 Open Side Vents!
  const baffleRear = box(0.056, 0.038, 0.01, MAT_SLATE_MID, 0, 0, 0.032);
  const baffleMid = box(0.058, 0.038, 0.009, MAT_SLATE_MID, 0, 0, -0.004);
  const baffleFwd = box(0.054, 0.038, 0.01, MAT_SLATE_MID, 0, 0, -0.041);
  const darkVentChamber1 = box(0.052, 0.026, 0.024, MAT_BORE_VOID, 0, 0, 0.014);
  const darkVentChamber2 = box(0.052, 0.026, 0.024, MAT_BORE_VOID, 0, 0, -0.022);
  const muzzleBore = cyl(0.0105, 0.0105, 0.012, 8, MAT_BORE_VOID, 0, 0, -0.045);
  brakeGroup.add(
    brakeNeck,
    brakeTopPlate,
    brakeBotPlate,
    brakeCenterSpine,
    baffleRear,
    baffleMid,
    baffleFwd,
    darkVentChamber1,
    darkVentChamber2,
    muzzleBore
  );
  gunBody.add(brakeGroup);

  // 7. SLEEK COMPACT PROPORTIONED TACTICAL RIFLE SCOPE (Not bulky! Matches Reference 100%!)
  // Scope optical centerline cleanly positioned at y = 0.094 with slim, elegant proportions!
  const scopeGroup = new THREE.Group();
  gunBody.add(scopeGroup);

  const scopeY = 0.094;
  const scopeCenterZ = -0.068;

  // Dual Tactical Scope Mount Rings clamping onto the Picatinny rail
  const mountRingFwd = box(0.031, 0.036, 0.022, MAT_GUN_BLACK, 0, 0.072, scopeCenterZ - 0.052);
  const mountRingRear = box(0.031, 0.036, 0.022, MAT_GUN_BLACK, 0, 0.072, scopeCenterZ + 0.052);

  // Slim 30mm-Proportioned Central Scope Tube + Spherical/Rounded Turret Saddle + Tall Elevation Turret!
  const scopeTube = cyl(0.0135, 0.0135, 0.165, 16, MAT_GUN_DARK, 0, scopeY, scopeCenterZ);
  const turretSaddle = new THREE.Mesh(new THREE.IcosahedronGeometry(0.0205, 1), MAT_SLATE_MID);
  turretSaddle.position.set(0, scopeY, scopeCenterZ);
  // Distinct Tall Knurled Top Elevation Turret Knob (Prominently visible in Reference!)
  const tallTopTurret = cyl(0.0125, 0.013, 0.032, 12, MAT_GUN_DARK, 0, scopeY + 0.027, scopeCenterZ, 0);
  const topTurretCap = cyl(0.0135, 0.0135, 0.008, 12, MAT_GUN_BLACK, 0, scopeY + 0.042, scopeCenterZ, 0);
  const sideWindageTurret = cyl(0.0115, 0.012, 0.022, 12, MAT_GUN_BLACK, 0.023, scopeY, scopeCenterZ, 0);
  sideWindageTurret.rotation.z = Math.PI / 2;

  // Sleek Compact Tapered Front Objective Bell (r = 0.024 — clean & slim, never oversized!)
  const objCone = cyl(0.024, 0.0135, 0.058, 16, MAT_GUN_DARK, 0, scopeY, scopeCenterZ - 0.108);
  const objHood = cyl(0.0245, 0.024, 0.046, 16, MAT_GUN_DEEPER, 0, scopeY, scopeCenterZ - 0.158);
  const objFrontGlass = cyl(0.0215, 0.0215, 0.005, 16, MAT_FRONT_COATED_GLASS, 0, scopeY, scopeCenterZ - 0.18);

  // Sleek Compact Rear Ocular Eyepiece Housing — OPEN-ENDED HOLLOW CYLINDERS (Zero Z-fighting!)
  const ocuCone = cyl(0.0135, 0.0225, 0.048, 20, MAT_GUN_DARK, 0, scopeY, scopeCenterZ + 0.102, Math.PI / 2, true);
  const ocuBarrel = cyl(0.024, 0.0225, 0.044, 20, MAT_GUN_DEEPER, 0, scopeY, scopeCenterZ + 0.148, Math.PI / 2, true);
  const ocuOuterCollar = cyl(0.025, 0.024, 0.016, 20, MAT_GUN_BLACK, 0, scopeY, scopeCenterZ + 0.178, Math.PI / 2, true);
  const ocuInteriorBackstop = new THREE.Mesh(new THREE.CircleGeometry(0.022, 20), MAT_BORE_VOID);
  ocuInteriorBackstop.position.set(0, scopeY, scopeCenterZ + 0.132);

  // Clean Slim Rubberized Eyepiece Bezel + Crystal-Clear Live Magnifying Glass Lens (z = 0.117)
  const lensZ = scopeCenterZ + 0.185;
  const ocuBezelRim = new THREE.Mesh(new THREE.RingGeometry(0.0205, 0.0252, 28), MAT_GUN_BLACK);
  ocuBezelRim.position.set(0, scopeY, lensZ + 0.0012);

  const { material: liveScopeMat, uniforms: scopeLensUniforms } =
    createLiveMagnifyingScopeMaterial(scopeTexture);
  const ocuMagnifyingLens = new THREE.Mesh(new THREE.CircleGeometry(0.0212, 32), liveScopeMat);
  ocuMagnifyingLens.position.set(0, scopeY, lensZ);

  scopeGroup.add(
    mountRingFwd,
    mountRingRear,
    scopeTube,
    turretSaddle,
    tallTopTurret,
    topTurretCap,
    sideWindageTurret,
    objCone,
    objHood,
    objFrontGlass,
    ocuCone,
    ocuBarrel,
    ocuOuterCollar,
    ocuInteriorBackstop,
    ocuMagnifyingLens,
    ocuBezelRim
  );

  // Exact 3D Simulation Anchors
  const muzzleAnchor = new THREE.Object3D();
  muzzleAnchor.position.set(0, 0.024, -1.01);
  gunBody.add(muzzleAnchor);

  const ejectionAnchor = new THREE.Object3D();
  ejectionAnchor.position.set(0.032, 0.026, -0.085);
  gunBody.add(ejectionAnchor);

  const mechanismAnchor = new THREE.Object3D();
  mechanismAnchor.position.set(0.036, -0.012, 0.004);
  boltHandlePivot.add(mechanismAnchor);

  const magAnchor = new THREE.Object3D();
  magAnchor.position.set(0, -0.056, 0.0);
  magGroup.add(magAnchor);

  const scopeOpticAnchor = new THREE.Object3D();
  scopeOpticAnchor.position.set(0, scopeY, scopeCenterZ - 0.19);
  gunBody.add(scopeOpticAnchor);

  // Sculpted White Polygon Hands tailored to Barrett Standalone Grip & Slotted Forend!
  const rightArm = buildPolygonArm('right', 'pistolGrip', new THREE.Vector3(0.18, -0.44, 0.43));
  rightArm.root.position.set(0.017, -0.068, 0.072);
  rightArm.root.rotation.set(0.32, -0.08, 0.08);
  rightArm.basePos.copy(rightArm.root.position);
  rightArm.baseRot.copy(rightArm.root.rotation);
  gunBody.add(rightArm.root);

  const leftArm = buildPolygonArm('left', 'sniperForend', new THREE.Vector3(-0.24, -0.46, 0.54));
  leftArm.root.position.set(-0.026, -0.018, -0.305);
  leftArm.root.rotation.set(0.12, 0.16, -0.28);
  leftArm.basePos.copy(leftArm.root.position);
  leftArm.baseRot.copy(leftArm.root.rotation);
  gunBody.add(leftArm.root);

  return {
    id: 'sniper',
    root,
    gunBody,
    slideOrBoltGroup: boltGroup,
    boltHandlePivot,
    triggerPivot,
    magGroup,
    magBasePos: magGroup.position.clone(),
    magBaseRot: magGroup.rotation.clone(),
    muzzleAnchor,
    ejectionAnchor,
    mechanismAnchor,
    magAnchor,
    scopeOpticAnchor,
    scopeLensUniforms,
    leftArm,
    rightArm,
    scopeMeshes: [scopeGroup],
  };
}
