import * as THREE from 'three';

export interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  maxY: number;
  walkableTop?: boolean;
  surface?: 'wood' | 'stone';
}

export interface ShootableEntity {
  id: string;
  kind: 'bot' | 'target' | 'barrel' | 'crate';
  root: THREE.Group;
  headMesh?: THREE.Object3D;
  bodyMesh: THREE.Object3D;
  hp: number;
  maxHp: number;
  alive: boolean;
  respawnTimer: number;
  flinchTimer: number;
  // AI / movement fields
  basePos: THREE.Vector3;
  strafePhase: number;
  strafeSpeed: number;
  strafeAmp: number;
  fireCooldown: number;
  distanceLabel?: number;
  pivotGroup?: THREE.Group;
}

export interface EnemyProjectile {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
}

export interface BuiltWorld {
  scene: THREE.Scene;
  colliders: BoxCollider[];
  staticHitMeshes: { mesh: THREE.Object3D; surface: 'stone' | 'wood' | 'metal' }[];
  entities: ShootableEntity[];
  enemyProjectiles: EnemyProjectile[];
  spawnWaveBots: (wave: number) => void;
  setRangeModeActive: (isRange: boolean) => void;
  update: (
    dt: number,
    playerPos: THREE.Vector3,
    isCombatMode: boolean,
    onPlayerHit: (dmg: number) => void
  ) => number; // returns alive enemy count
}

const MAT_GRASS = new THREE.MeshStandardMaterial({
  color: 0x82a358,
  roughness: 0.92,
  flatShading: true,
});

const MAT_STONE_TILE = new THREE.MeshStandardMaterial({
  color: 0xc2c5bc,
  roughness: 0.88,
  flatShading: true,
});

const MAT_BUILDING_CREAM = new THREE.MeshStandardMaterial({
  color: 0xd8d4c7,
  roughness: 0.85,
  flatShading: true,
});

const MAT_BUILDING_TRIM = new THREE.MeshStandardMaterial({
  color: 0x8f979e,
  roughness: 0.82,
  flatShading: true,
});

const MAT_ROOF_RUST = new THREE.MeshStandardMaterial({
  color: 0xa86048,
  roughness: 0.78,
  flatShading: true,
});

const MAT_CRATE_WOOD = new THREE.MeshStandardMaterial({
  color: 0xb9854f,
  roughness: 0.82,
  flatShading: true,
});

const MAT_CRATE_FRAME = new THREE.MeshStandardMaterial({
  color: 0x8c5e32,
  roughness: 0.85,
  flatShading: true,
});

const MAT_ROCK = new THREE.MeshStandardMaterial({
  color: 0x7d868c,
  roughness: 0.88,
  flatShading: true,
});

const MAT_PINE_LEAF = new THREE.MeshStandardMaterial({
  color: 0x3b6943,
  roughness: 0.88,
  flatShading: true,
});

const MAT_PINE_TRUNK = new THREE.MeshStandardMaterial({
  color: 0x5c4028,
  roughness: 0.9,
  flatShading: true,
});

const MAT_MOUNTAIN_FAR = new THREE.MeshStandardMaterial({
  color: 0x7a9eb0,
  roughness: 0.95,
  flatShading: true,
});

function buildWoodenCrate(size = 1.35): THREE.Group {
  const g = new THREE.Group();
  const core = new THREE.Mesh(new THREE.BoxGeometry(size, size, size), MAT_CRATE_WOOD);
  core.position.y = size * 0.5;
  core.castShadow = true;
  core.receiveShadow = true;
  g.add(core);

  // Diagonal X-brace & border planks just like the left panel crate in Image 1 & 2!
  const braceThick = size * 0.08;
  const diagLen = size * 1.28;
  [-1, 1].forEach((side) => {
    const zPos = side * (size * 0.505);
    const d1 = new THREE.Mesh(new THREE.BoxGeometry(diagLen, braceThick, braceThick * 0.6), MAT_CRATE_FRAME);
    d1.position.set(0, size * 0.5, zPos);
    d1.rotation.z = Math.PI / 4;
    g.add(d1);

    const xPos = side * (size * 0.505);
    const d2 = new THREE.Mesh(new THREE.BoxGeometry(braceThick * 0.6, braceThick, diagLen), MAT_CRATE_FRAME);
    d2.position.set(xPos, size * 0.5, 0);
    d2.rotation.x = Math.PI / 4;
    g.add(d2);
  });

  const topFrame = new THREE.Mesh(new THREE.BoxGeometry(size * 1.04, braceThick, size * 1.04), MAT_CRATE_FRAME);
  topFrame.position.y = size - braceThick * 0.4;
  g.add(topFrame);

  return g;
}

function buildPineTree(scale = 1): THREE.Group {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18 * scale, 0.28 * scale, 1.8 * scale, 6), MAT_PINE_TRUNK);
  trunk.position.y = 0.9 * scale;
  trunk.castShadow = true;
  g.add(trunk);

  const tiers = [
    { r: 1.45, h: 2.4, y: 2.5 },
    { r: 1.15, h: 2.2, y: 3.9 },
    { r: 0.8, h: 1.9, y: 5.2 },
  ];
  tiers.forEach((t) => {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(t.r * scale, t.h * scale, 7), MAT_PINE_LEAF);
    cone.position.y = t.y * scale;
    cone.castShadow = true;
    g.add(cone);
  });
  return g;
}

function buildTacticalBot(id: string, pos: THREE.Vector3): ShootableEntity {
  const root = new THREE.Group();
  root.position.copy(pos);

  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x2d3748,
    roughness: 0.55,
    metalness: 0.25,
    flatShading: true,
  });
  const accentMat = new THREE.MeshStandardMaterial({
    color: 0xd9483b,
    roughness: 0.45,
    flatShading: true,
  });
  const visorMat = new THREE.MeshBasicMaterial({ color: 0xff5238 });
  const limbMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.72,
    flatShading: true,
  });

  // Legs
  const legL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.78, 0.24), armorMat);
  legL.position.set(-0.15, 0.39, 0);
  const legR = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.78, 0.24), armorMat);
  legR.position.set(0.15, 0.39, 0);

  // Armored Torso (Body Hitbox)
  const torsoGroup = new THREE.Group();
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.68, 0.34), armorMat);
  torso.position.set(0, 1.12, 0);
  torso.castShadow = true;
  const chestPlate = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.38, 0.38), accentMat);
  chestPlate.position.set(0, 1.16, 0);
  const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.1, 0.58, 6), limbMat);
  armL.position.set(-0.36, 1.12, 0.14);
  armL.rotation.x = Math.PI / 3;
  const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.1, 0.58, 6), limbMat);
  armR.position.set(0.36, 1.12, 0.14);
  armR.rotation.x = Math.PI / 3;
  const botGun = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.12, 0.65),
    new THREE.MeshStandardMaterial({ color: 0x1a202c, flatShading: true })
  );
  botGun.position.set(0.18, 1.06, 0.42);
  torsoGroup.add(torso, chestPlate, armL, armR, botGun);

  // Faceted Tactical Helmet + Glowing Visor (Critical Headshot Hitbox!)
  const headGroup = new THREE.Group();
  const headBox = new THREE.Mesh(new THREE.IcosahedronGeometry(0.23, 0), limbMat);
  headBox.position.set(0, 1.68, 0);
  headBox.castShadow = true;
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.11, 0.16), visorMat);
  visor.position.set(0, 1.69, 0.14);
  headGroup.add(headBox, visor);

  // Floating HP Bar above bot
  const hpBg = new THREE.Mesh(
    new THREE.PlaneGeometry(0.75, 0.08),
    new THREE.MeshBasicMaterial({ color: 0x0f172a, side: THREE.DoubleSide })
  );
  hpBg.position.set(0, 2.12, 0);
  const hpFill = new THREE.Mesh(
    new THREE.PlaneGeometry(0.71, 0.055),
    new THREE.MeshBasicMaterial({ color: 0xef4444, side: THREE.DoubleSide })
  );
  hpFill.position.set(0, 2.12, 0.01);
  hpFill.name = 'hpFill';
  root.add(legL, legR, torsoGroup, headGroup, hpBg, hpFill);

  const entity: ShootableEntity = {
    id,
    kind: 'bot',
    root,
    headMesh: headGroup,
    bodyMesh: torsoGroup,
    hp: 100,
    maxHp: 100,
    alive: true,
    respawnTimer: 0,
    flinchTimer: 0,
    basePos: pos.clone(),
    strafePhase: Math.random() * Math.PI * 2,
    strafeSpeed: 1.25 + Math.random() * 0.9,
    strafeAmp: 1.8 + Math.random() * 2.2,
    fireCooldown: 1.5 + Math.random() * 2.2,
  };

  headGroup.traverse((c) => {
    c.userData = { entity, isHead: true };
  });
  torsoGroup.traverse((c) => {
    c.userData = { entity, isHead: false };
  });
  legL.userData = { entity, isHead: false };
  legR.userData = { entity, isHead: false };

  return entity;
}

function buildRangeSteelTarget(
  id: string,
  pos: THREE.Vector3,
  distanceM: number,
  strafeAmp = 0
): ShootableEntity {
  const root = new THREE.Group();
  root.position.copy(pos);

  const standBase = new THREE.Mesh(
    new THREE.BoxGeometry(0.9, 0.14, 0.6),
    new THREE.MeshStandardMaterial({ color: 0x334155, flatShading: true })
  );
  standBase.position.y = 0.07;
  root.add(standBase);

  const pivotGroup = new THREE.Group();
  pivotGroup.position.y = 0.14;
  root.add(pivotGroup);

  const post = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, 0.85, 0.1),
    new THREE.MeshStandardMaterial({ color: 0x475569, flatShading: true })
  );
  post.position.y = 0.42;
  pivotGroup.add(post);

  const bodyPlate = new THREE.Mesh(
    new THREE.BoxGeometry(0.72, 0.82, 0.08),
    new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4, metalness: 0.5, flatShading: true })
  );
  bodyPlate.position.y = 1.15;
  bodyPlate.castShadow = true;

  const centerRing = new THREE.Mesh(
    new THREE.BoxGeometry(0.38, 0.42, 0.095),
    new THREE.MeshStandardMaterial({ color: 0x2563eb, flatShading: true })
  );
  centerRing.position.y = 1.15;

  const headPlate = new THREE.Mesh(
    new THREE.CylinderGeometry(0.22, 0.22, 0.09, 8),
    new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.35, metalness: 0.45, flatShading: true })
  );
  headPlate.rotation.x = Math.PI / 2;
  headPlate.position.y = 1.78;
  headPlate.castShadow = true;

  const bodyGroup = new THREE.Group();
  bodyGroup.add(bodyPlate, centerRing);
  const headGroup = new THREE.Group();
  headGroup.add(headPlate);

  pivotGroup.add(bodyGroup, headGroup);

  const entity: ShootableEntity = {
    id,
    kind: 'target',
    root,
    headMesh: headGroup,
    bodyMesh: bodyGroup,
    hp: 90,
    maxHp: 90,
    alive: true,
    respawnTimer: 0,
    flinchTimer: 0,
    basePos: pos.clone(),
    strafePhase: Math.random() * Math.PI * 2,
    strafeSpeed: 1.15,
    strafeAmp,
    fireCooldown: 999,
    distanceLabel: distanceM,
    pivotGroup,
  };

  headGroup.traverse((c) => {
    c.userData = { entity, isHead: true };
  });
  bodyGroup.traverse((c) => {
    c.userData = { entity, isHead: false };
  });

  return entity;
}

function buildExplosiveBarrel(id: string, pos: THREE.Vector3): ShootableEntity {
  const root = new THREE.Group();
  root.position.copy(pos);

  const barrelMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    roughness: 0.5,
    metalness: 0.3,
    flatShading: true,
  });
  const stripeMat = new THREE.MeshStandardMaterial({
    color: 0xfacc15,
    roughness: 0.55,
    flatShading: true,
  });

  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 1.18, 9), barrelMat);
  body.position.y = 0.59;
  body.castShadow = true;
  const stripe = new THREE.Mesh(new THREE.CylinderGeometry(0.435, 0.435, 0.22, 9), stripeMat);
  stripe.position.y = 0.62;

  const bodyGroup = new THREE.Group();
  bodyGroup.add(body, stripe);
  root.add(bodyGroup);

  const entity: ShootableEntity = {
    id,
    kind: 'barrel',
    root,
    bodyMesh: bodyGroup,
    hp: 60,
    maxHp: 60,
    alive: true,
    respawnTimer: 0,
    flinchTimer: 0,
    basePos: pos.clone(),
    strafePhase: 0,
    strafeSpeed: 0,
    strafeAmp: 0,
    fireCooldown: 999,
  };

  bodyGroup.traverse((c) => {
    c.userData = { entity, isHead: false };
  });

  return entity;
}

export function buildStylizedWorld(): BuiltWorld {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8bc6ec);
  scene.fog = new THREE.Fog(0xa8d5f0, 48, 195);

  // Sunny Stylized Low-Poly Lighting matching Image 1 & Image 2!
  const hemiLight = new THREE.HemisphereLight(0xdff2ff, 0x7b935e, 1.05);
  scene.add(hemiLight);

  const sunLight = new THREE.DirectionalLight(0xfff6e3, 1.65);
  sunLight.position.set(38, 62, 32);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.set(2048, 2048);
  sunLight.shadow.bias = -0.00045;
  sunLight.shadow.normalBias = 0.025;
  sunLight.shadow.camera.near = 5;
  sunLight.shadow.camera.far = 170;
  const d = 55;
  sunLight.shadow.camera.left = -d;
  sunLight.shadow.camera.right = d;
  sunLight.shadow.camera.top = d;
  sunLight.shadow.camera.bottom = -d;
  scene.add(sunLight);

  const colliders: BoxCollider[] = [];
  const staticHitMeshes: { mesh: THREE.Object3D; surface: 'stone' | 'wood' | 'metal' }[] = [];
  const entities: ShootableEntity[] = [];
  const enemyProjectiles: EnemyProjectile[] = [];

  // Main Grass Valley Terrain
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(280, 280, 28, 28), MAT_GRASS);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);
  staticHitMeshes.push({ mesh: ground, surface: 'stone' });

  // =========================================================================
  // ZONE A: URBAN COURTYARD & COBBLE ALLEY (Left / Forward-Left — Like Pistol Panel!)
  // =========================================================================
  const cobblePlaza = new THREE.Mesh(new THREE.BoxGeometry(22, 0.08, 46), MAT_STONE_TILE);
  cobblePlaza.position.set(-10, 0.04, -14);
  cobblePlaza.receiveShadow = true;
  scene.add(cobblePlaza);
  staticHitMeshes.push({ mesh: cobblePlaza, surface: 'stone' });

  // Stylized Cream Buildings framing left & far courtyard
  const buildingConfigs = [
    { x: -21.5, z: -10, w: 7.5, h: 11.5, d: 14 },
    { x: -21.5, z: -26, w: 7.5, h: 9.5, d: 12 },
    { x: -11.5, z: -38, w: 12, h: 10.5, d: 8 },
  ];

  buildingConfigs.forEach((b) => {
    const bGroup = new THREE.Group();
    const main = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), MAT_BUILDING_CREAM);
    main.position.set(b.x, b.h * 0.5, b.z);
    main.castShadow = true;
    main.receiveShadow = true;

    const cornice = new THREE.Mesh(new THREE.BoxGeometry(b.w + 0.4, 0.45, b.d + 0.4), MAT_BUILDING_TRIM);
    cornice.position.set(b.x, b.h * 0.55, b.z);

    const awning = new THREE.Mesh(new THREE.BoxGeometry(b.w + 0.7, 0.35, 1.4), MAT_ROOF_RUST);
    awning.position.set(b.x + (b.x < -15 ? b.w * 0.5 : 0), 3.3, b.z + (b.z < -30 ? b.d * 0.5 : 0));

    bGroup.add(main, cornice, awning);
    scene.add(bGroup);
    staticHitMeshes.push({ mesh: main, surface: 'stone' });
    colliders.push({
      minX: b.x - b.w * 0.5 - 0.4,
      maxX: b.x + b.w * 0.5 + 0.4,
      minZ: b.z - b.d * 0.5 - 0.4,
      maxZ: b.z + b.d * 0.5 + 0.4,
      maxY: b.h,
    });
  });

  // Wooden Crates scattered tactically in Courtyard & Spawn Cover (Jumpable single & stacked vantage boxes!)
  const crateCoords: { x: number; y?: number; z: number; s: number }[] = [
    { x: -14.8, z: -8.5, s: 1.45 },
    { x: -14.8, y: 1.45, z: -10.0, s: 1.35 }, // Upper stacked crate reachable from lower crate!
    { x: -14.8, z: -10.0, s: 1.45 },
    { x: -13.2, z: -15.5, s: 1.4 },
    { x: -5.4, z: -11.2, s: 1.38 },
    { x: -7.5, z: -22.5, s: 1.5 },
    { x: 4.6, z: -9.5, s: 1.32 },
    { x: 6.0, z: -9.5, s: 1.32 },
    { x: 6.0, y: 1.32, z: -9.5, s: 1.25 }, // Stacked valley sniper overlook box!
    { x: -2.2, z: -5.2, s: 1.18 }, // Jumpable box right in front of spawn!
    { x: -0.8, z: -5.2, s: 1.42 }, // Adjacent taller crate step!
  ];
  crateCoords.forEach((c) => {
    const baseY = c.y ?? 0;
    const crate = buildWoodenCrate(c.s);
    crate.position.set(c.x, baseY, c.z);
    scene.add(crate);
    staticHitMeshes.push({ mesh: crate, surface: 'wood' });
    colliders.push({
      minX: c.x - c.s * 0.52,
      maxX: c.x + c.s * 0.52,
      minZ: c.z - c.s * 0.52,
      maxZ: c.z + c.s * 0.52,
      maxY: baseY + c.s,
      walkableTop: true,
      surface: 'wood',
    });
  });

  // =========================================================================
  // ZONE B: ALPINE ROCKY VALLEY & PINE HILLS (Center & Right — Like Rifle & Sniper Panels!)
  // =========================================================================
  const cliffConfigs = [
    { x: 18, z: -34, r: 6.5, h: 14 },
    { x: 26, z: -48, r: 8.5, h: 19 },
    { x: -3, z: -64, r: 9.0, h: 17 },
    { x: 34, z: -22, r: 5.5, h: 10 },
  ];
  cliffConfigs.forEach((cl) => {
    const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(cl.r, 1), MAT_ROCK);
    rock.scale.set(1, cl.h / (cl.r * 1.3), 0.9);
    rock.position.set(cl.x, cl.h * 0.32, cl.z);
    rock.castShadow = true;
    rock.receiveShadow = true;
    scene.add(rock);
    staticHitMeshes.push({ mesh: rock, surface: 'stone' });
    colliders.push({
      minX: cl.x - cl.r * 0.75,
      maxX: cl.x + cl.r * 0.75,
      minZ: cl.z - cl.r * 0.75,
      maxZ: cl.z + cl.r * 0.75,
      maxY: cl.h,
    });
  });

  // Scattered Low-Poly Boulders for Tactical Mid-Field Cover
  const boulderCoords = [
    { x: 8.5, z: -18, r: 1.4 },
    { x: 12.5, z: -26, r: 1.7 },
    { x: 2.2, z: -29, r: 1.35 },
    { x: 16.5, z: -14, r: 1.2 },
    { x: 21.0, z: -38, r: 1.8 },
  ];
  boulderCoords.forEach((b) => {
    const bMesh = new THREE.Mesh(new THREE.IcosahedronGeometry(b.r, 0), MAT_ROCK);
    bMesh.scale.set(1.2, 0.78, 1.0);
    bMesh.position.set(b.x, b.r * 0.45, b.z);
    bMesh.castShadow = true;
    bMesh.receiveShadow = true;
    scene.add(bMesh);
    staticHitMeshes.push({ mesh: bMesh, surface: 'stone' });
    colliders.push({
      minX: b.x - b.r * 0.85,
      maxX: b.x + b.r * 0.85,
      minZ: b.z - b.r * 0.85,
      maxZ: b.z + b.r * 0.85,
      maxY: b.r * 1.02,
      walkableTop: true,
      surface: 'stone',
    });
  });

  // Pine Trees across Valley Hillsides
  const pinePositions = [
    [14, -22, 1.0],
    [22, -29, 1.25],
    [9, -42, 1.15],
    [19, -55, 1.35],
    [29, -36, 1.1],
    [-4, -48, 1.2],
    [6, -72, 1.4],
    [26, -68, 1.3],
    [32, -14, 0.95],
  ];
  pinePositions.forEach(([px, pz, ps]) => {
    const tree = buildPineTree(ps);
    tree.position.set(px, 0, pz);
    scene.add(tree);
  });

  // Distant Misty Blue Mountain Peaks on Horizon (Signature look of Rifle & Sniper backgrounds!)
  const mountainSpecs = [
    { x: -35, z: -135, r: 34, h: 48 },
    { x: 12, z: -145, r: 42, h: 62 },
    { x: 64, z: -138, r: 38, h: 54 },
    { x: 105, z: -115, r: 34, h: 44 },
  ];
  mountainSpecs.forEach((m) => {
    const peak = new THREE.Mesh(new THREE.ConeGeometry(m.r, m.h, 7), MAT_MOUNTAIN_FAR);
    peak.position.set(m.x, m.h * 0.45, m.z);
    scene.add(peak);
  });

  // Invisible Arena Boundary Walls so player stays in scenic playable valley
  colliders.push(
    { minX: -26, maxX: -24.5, minZ: -80, maxZ: 25, maxY: 20 },
    { minX: 38, maxX: 40, minZ: -80, maxZ: 25, maxY: 20 },
    { minX: -26, maxX: 40, minZ: 18, maxZ: 20, maxY: 20 },
    { minX: -26, maxX: 40, minZ: -78, maxZ: -76, maxY: 20 }
  );

  // =========================================================================
  // INTERACTIVE RANGE TARGETS (Close Pistol 13m, Mid Rifle 28m/44m, Long Sniper 72m/98m!)
  // =========================================================================
  const rangeSpecs = [
    { id: 't_close_1', pos: new THREE.Vector3(-9.5, 0, -13), dist: 14, amp: 1.5 },
    { id: 't_close_2', pos: new THREE.Vector3(-3.0, 0, -15), dist: 15, amp: 0 },
    { id: 't_mid_1', pos: new THREE.Vector3(3.5, 0, -28), dist: 28, amp: 2.8 },
    { id: 't_mid_2', pos: new THREE.Vector3(11.0, 0, -38), dist: 40, amp: 2.2 },
    { id: 't_sniper_1', pos: new THREE.Vector3(8.0, 0, -64), dist: 65, amp: 3.4 },
    { id: 't_sniper_2', pos: new THREE.Vector3(21.0, 0, -86), dist: 89, amp: 3.8 },
  ];
  rangeSpecs.forEach((rs) => {
    const t = buildRangeSteelTarget(rs.id, rs.pos, rs.dist, rs.amp);
    scene.add(t.root);
    entities.push(t);
  });

  // Explosive Red Barrels
  const barrelPositions = [
    new THREE.Vector3(-11.2, 0, -18.5),
    new THREE.Vector3(6.8, 0, -23.5),
    new THREE.Vector3(14.5, 0, -44.0),
  ];
  barrelPositions.forEach((bp, idx) => {
    const brl = buildExplosiveBarrel(`barrel_${idx}`, bp);
    scene.add(brl.root);
    entities.push(brl);
  });

  // Spawn Tactical Polygon Wave Bots
  const botSpawnPool = [
    new THREE.Vector3(-11.5, 0, -19.5), // Urban alley close
    new THREE.Vector3(-6.2, 0, -25.0), // Courtyard crates
    new THREE.Vector3(5.5, 0, -22.0), // Grass valley mid
    new THREE.Vector3(13.5, 0, -32.0), // Pine hillside mid
    new THREE.Vector3(1.5, 0, -40.0), // Valley center
    new THREE.Vector3(15.5, 0, -52.0), // Sniper ridge
    new THREE.Vector3(7.0, 0, -58.0), // Far valley sniper
  ];

  const spawnWaveBots = (wave: number) => {
    // Remove dead/old bots first
    for (let i = entities.length - 1; i >= 0; i--) {
      if (entities[i].kind === 'bot') {
        scene.remove(entities[i].root);
        entities.splice(i, 1);
      }
    }
    const count = Math.min(7, 4 + wave);
    for (let i = 0; i < count; i++) {
      const base = botSpawnPool[i % botSpawnPool.length].clone();
      base.x += (Math.random() - 0.5) * 2.5;
      const bot = buildTacticalBot(`bot_w${wave}_${i}`, base);
      bot.maxHp = 95 + wave * 12;
      bot.hp = bot.maxHp;
      scene.add(bot.root);
      entities.push(bot);
    }
  };

  const setRangeModeActive = (isRange: boolean) => {
    for (let i = entities.length - 1; i >= 0; i--) {
      if (entities[i].kind === 'bot') {
        entities[i].root.visible = !isRange && entities[i].alive;
      }
    }
    if (isRange) {
      // Clear enemy projectiles in range lab mode
      enemyProjectiles.forEach((ep) => scene.remove(ep.mesh));
      enemyProjectiles.length = 0;
    }
  };

  const projGeo = new THREE.OctahedronGeometry(0.085, 0);
  const projMat = new THREE.MeshBasicMaterial({ color: 0xff5a26 });

  const update = (
    dt: number,
    playerPos: THREE.Vector3,
    isCombatMode: boolean,
    onPlayerHit: (dmg: number) => void
  ): number => {
    let botsAlive = 0;

    for (const ent of entities) {
      if (ent.kind === 'target') {
        if (ent.alive) {
          ent.strafePhase += dt * ent.strafeSpeed;
          if (ent.strafeAmp > 0) {
            ent.root.position.x = ent.basePos.x + Math.sin(ent.strafePhase) * ent.strafeAmp;
          }
          if (ent.pivotGroup) {
            ent.pivotGroup.rotation.x = THREE.MathUtils.lerp(ent.pivotGroup.rotation.x, 0, Math.min(1, dt * 10));
          }
        } else {
          if (ent.pivotGroup) {
            ent.pivotGroup.rotation.x = THREE.MathUtils.lerp(
              ent.pivotGroup.rotation.x,
              Math.PI / 2,
              Math.min(1, dt * 14)
            );
          }
          ent.respawnTimer -= dt;
          if (ent.respawnTimer <= 0) {
            ent.alive = true;
            ent.hp = ent.maxHp;
          }
        }
      } else if (ent.kind === 'barrel') {
        if (!ent.alive) {
          ent.respawnTimer -= dt;
          if (ent.respawnTimer <= 0) {
            ent.alive = true;
            ent.hp = ent.maxHp;
            ent.root.visible = true;
          }
        }
      } else if (ent.kind === 'bot') {
        if (!isCombatMode) {
          ent.root.visible = false;
          continue;
        }
        if (ent.alive) {
          botsAlive++;
          ent.root.visible = true;
          ent.strafePhase += dt * ent.strafeSpeed;
          ent.root.position.x = ent.basePos.x + Math.sin(ent.strafePhase) * ent.strafeAmp;
          ent.root.lookAt(playerPos.x, ent.root.position.y, playerPos.z);

          // Update HP bar
          const hpFill = ent.root.getObjectByName('hpFill') as THREE.Mesh | undefined;
          if (hpFill) {
            const ratio = Math.max(0.01, ent.hp / ent.maxHp);
            hpFill.scale.x = ratio;
          }

          if (ent.flinchTimer > 0) {
            ent.flinchTimer -= dt;
            ent.root.rotation.x = -0.14 * (ent.flinchTimer / 0.12);
          } else {
            ent.root.rotation.x = 0;
          }

          // Bot tactical suppressive fire
          ent.fireCooldown -= dt;
          if (ent.fireCooldown <= 0) {
            ent.fireCooldown = 2.1 + Math.random() * 1.9;
            const origin = ent.root.position.clone().add(new THREE.Vector3(0, 1.25, 0));
            const aimTarget = playerPos
              .clone()
              .add(new THREE.Vector3((Math.random() - 0.5) * 1.25, -0.15 + (Math.random() - 0.5) * 0.5, 0));
            const dir = aimTarget.sub(origin).normalize();
            const bolt = new THREE.Mesh(projGeo, projMat);
            bolt.position.copy(origin);
            scene.add(bolt);
            enemyProjectiles.push({
              mesh: bolt,
              vel: dir.multiplyScalar(22),
              life: 4.5,
            });
          }
        } else {
          // Collapse animation on death
          ent.root.rotation.x = THREE.MathUtils.lerp(ent.root.rotation.x, -Math.PI / 2, Math.min(1, dt * 9));
          ent.respawnTimer -= dt;
          if (ent.respawnTimer <= 0) {
            ent.root.visible = false;
          }
        }
      }
    }

    // Update enemy plasma bolts
    for (let i = enemyProjectiles.length - 1; i >= 0; i--) {
      const ep = enemyProjectiles[i];
      ep.life -= dt;
      ep.mesh.position.addScaledVector(ep.vel, dt);
      ep.mesh.rotation.x += dt * 10;
      ep.mesh.rotation.y += dt * 12;

      // Check collision with crates/rocks
      let blocked = false;
      for (const c of colliders) {
        if (
          ep.mesh.position.x >= c.minX &&
          ep.mesh.position.x <= c.maxX &&
          ep.mesh.position.z >= c.minZ &&
          ep.mesh.position.z <= c.maxZ &&
          ep.mesh.position.y <= c.maxY
        ) {
          blocked = true;
          break;
        }
      }

      if (!blocked && ep.mesh.position.distanceTo(playerPos) < 0.72) {
        onPlayerHit(9);
        blocked = true;
      }

      if (blocked || ep.life <= 0 || ep.mesh.position.y <= 0.05) {
        scene.remove(ep.mesh);
        enemyProjectiles.splice(i, 1);
      }
    }

    return botsAlive;
  };

  // Start with Wave 1 spawned!
  spawnWaveBots(1);

  return {
    scene,
    colliders,
    staticHitMeshes,
    entities,
    enemyProjectiles,
    spawnWaveBots,
    setRangeModeActive,
    update,
  };
}
