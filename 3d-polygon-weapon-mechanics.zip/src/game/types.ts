export type WeaponId = 'pistol' | 'rifle' | 'sniper';

export type FireMode = 'SEMI' | 'AUTO' | 'BURST' | 'BOLT';

export type WeaponPoseMode =
  | 'READY' // Gambar 2: Mode Siap Nembak (sejajar bidikan tengah)
  | 'SPRINTING' // Mode Lari Taktis (Tac-Sprint / Across-Chest realistis)
  | 'RELOADING' // Gambar 1: Saat Mengisi Ammo (sudut miring taktis + animasi magazen)
  | 'BOLT_CYCLE' // Siklus kokang bolt-action khusus Sniper setelah tembakan
  | 'INSPECT_POSE_1'; // Tahan/toggle melihat sudut Gambar 1 secara langsung

export type GameMode = 'COMBAT' | 'RANGE';

export interface WeaponSpec {
  id: WeaponId;
  label: string;
  subtitle: string;
  caliber: string;
  muzzleVelocityText: string;
  magSize: number;
  reserveMax: number;
  rpm: number; // Rounds per minute
  damage: number;
  headshotMult: number;
  reloadDuration: number; // seconds (empty mag + chamber rack)
  tacticalReloadDuration: number; // seconds (fast mag swap with round in chamber)
  boltCycleDuration?: number; // seconds for sniper
  fireModes: FireMode[];
  recoilKickZ: number;
  recoilPitchUp: number;
  recoilYawJitter: number;
  adsFov: number;
  casingType: '9mm' | '556' | '338';
  simulationInfo: {
    muzzleOutput: string;
    ejectionOutput: string;
    mechanicalAction: string;
    casingDirection: string;
  };
}

export interface ScreenAnchor {
  x: number;
  y: number;
  visible: boolean;
}

export interface WeaponAnchors2D {
  muzzle: ScreenAnchor;
  ejection: ScreenAnchor;
  mechanism: ScreenAnchor;
  magazine: ScreenAnchor;
}

export interface ShotLogEntry {
  id: number;
  weaponId: WeaponId;
  weaponLabel: string;
  caliber: string;
  muzzleEvent: string;
  casingEvent: string;
  mechEvent: string;
  hitText?: string;
  isHeadshot?: boolean;
  timestamp: number;
}

export interface DamagePopup {
  id: number;
  x: number;
  y: number;
  damage: number;
  isHeadshot: boolean;
  distanceM: number;
}

export interface HudSnapshot {
  weaponId: WeaponId;
  ammo: Record<WeaponId, number>;
  reserve: Record<WeaponId, number>;
  fireMode: FireMode;
  poseMode: WeaponPoseMode;
  reloadProgress: number; // 0..1
  reloadStageLabel: string;
  boltProgress: number; // 0..1
  isAds: boolean;
  isSniperScoped: boolean;
  isSprinting: boolean;
  isCrouching: boolean;
  bodycamMode: boolean;
  slowMo: boolean;
  showCallouts: boolean;
  gameMode: GameMode;
  pointerLocked: boolean;
  health: number;
  maxHealth: number;
  armor: number;
  score: number;
  kills: number;
  shotsFired: number;
  shotsHit: number;
  headshots: number;
  wave: number;
  enemiesAlive: number;
  anchors: WeaponAnchors2D;
  lastShotPulse: number;
  lastEjectPulse: number;
  hitmarkerType: 'none' | 'body' | 'head';
  hitmarkerTime: number;
}

export const WEAPON_SPECS: Record<WeaponId, WeaponSpec> = {
  pistol: {
    id: 'pistol',
    label: 'PISTOL',
    subtitle: 'Tactical M19-Poly 9mm',
    caliber: '9×19mm Parabellum',
    muzzleVelocityText: '375 m/s',
    magSize: 12,
    reserveMax: 96,
    rpm: 400,
    damage: 36,
    headshotMult: 2.4,
    reloadDuration: 1.28,
    tacticalReloadDuration: 1.02,
    fireModes: ['SEMI'],
    recoilKickZ: 0.055,
    recoilPitchUp: 0.14,
    recoilYawJitter: 0.022,
    adsFov: 56,
    casingType: '9mm',
    simulationInfo: {
      muzzleOutput: 'Proyektil 9mm tembaga + Api Moncong bintang pendek + Percikan mesiu & asap tipis laras',
      ejectionOutput: 'Selongsong 9mm kuningan pendek terlempar ke KANAN-ATAS dari celah barrel tembaga',
      mechanicalAction: 'Slide atas menghentak mundur (Blowback 65mm), Hammer terkokang, terkunci terbuka saat peluru habis',
      casingDirection: 'Arah jam 2 (Kanan-Atas) • Saat Slide mundur penuh',
    },
  },
  rifle: {
    id: 'rifle',
    label: 'RIFLE',
    subtitle: 'M4A1 Carbine Holo 5.56',
    caliber: '5.56×45mm NATO',
    muzzleVelocityText: '910 m/s',
    magSize: 30,
    reserveMax: 180,
    rpm: 650,
    damage: 31,
    headshotMult: 2.3,
    reloadDuration: 1.58,
    tacticalReloadDuration: 1.26,
    fireModes: ['AUTO', 'BURST', 'SEMI'],
    recoilKickZ: 0.042,
    recoilPitchUp: 0.072,
    recoilYawJitter: 0.028,
    adsFov: 48,
    casingType: '556',
    simulationInfo: {
      muzzleOutput: 'Peluru 5.56mm supersonik + Api Kompensator 4-arah (Birdcage) + Gas propelan & asap laras',
      ejectionOutput: 'Selongsong leher botol 5.56mm terlempar cepat ke SAMPING KANAN port ejeksi + asap chamber',
      mechanicalAction: 'Bolt Carrier samping kanan bergerak resiprokal super cepat tiap tembakan; T-Charging Handle ditarik saat reload',
      casingDirection: 'Arah jam 3–4 (Samping Kanan) • Otomatis tiap siklus tembak',
    },
  },
  sniper: {
    id: 'sniper',
    label: 'SNIPER',
    subtitle: 'M82-Poly .50 / .338 Heavy',
    caliber: '.338 / .50 Anti-Materiel',
    muzzleVelocityText: '1.020 m/s',
    magSize: 5,
    reserveMax: 35,
    rpm: 46,
    damage: 115,
    headshotMult: 2.8,
    reloadDuration: 1.92,
    tacticalReloadDuration: 1.52,
    boltCycleDuration: 0.84,
    fireModes: ['BOLT'],
    recoilKickZ: 0.115,
    recoilPitchUp: 0.24,
    recoilYawJitter: 0.018,
    adsFov: 20,
    casingType: '338',
    simulationInfo: {
      muzzleOutput: 'Proyektil berat .338 + Semburan Muzzle Brake raksasa + Cincin Gelombang Kejut (Shockwave) & jejak uap udara',
      ejectionOutput: 'Selongsong besar .338 baru keluar SAAT tuas Bolt diangkat & ditarik ke belakang oleh tangan kanan!',
      mechanicalAction: 'Hentakan mundur berat -> Tangan kanan mengangkat tuas Bolt 65° -> Tarik mundur (Ejeksi!) -> Dorong peluru baru & kunci',
      casingDirection: 'Arah jam 3 (Kanan Receiver) • Keluar saat siklus tarik Bolt-Action',
    },
  },
};
