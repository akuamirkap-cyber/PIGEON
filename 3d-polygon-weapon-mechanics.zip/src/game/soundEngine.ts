import { WeaponId } from './types';

export type ReloadAudioStage =
  | 'grabTilt'
  | 'magOut'
  | 'magDrop'
  | 'magTap'
  | 'magIn'
  | 'rackPull'
  | 'rackRelease'
  | 'readySnap';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private dryBus: GainNode | null = null;
  private reverbSend: GainNode | null = null;
  private whiteNoiseBuffer: AudioBuffer | null = null;
  private pinkNoiseBuffer: AudioBuffer | null = null;
  private shotBuffers: Partial<Record<WeaponId, AudioBuffer>> = {};
  public muted = false;

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
      this.setupStudioMasterChain(this.ctx);
      this.bakeNoiseAndWeaponBuffers(this.ctx);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock() {
    this.ensureContext();
  }

  /**
   * Builds a studio-grade firearm master bus:
   * Dry Bus + True Stereo Outdoor Urban-Valley Convolver -> Analog Tape Soft-Clipper -> Punch Limiter
   */
  private setupStudioMasterChain(ctx: AudioContext) {
    const saturator = ctx.createWaveShaper();
    const curve = new Float32Array(2048);
    const drive = 1.58;
    const norm = Math.tanh(drive);
    for (let i = 0; i < 2048; i++) {
      const x = (i * 2) / 2047 - 1;
      curve[i] = Math.tanh(x * drive) / norm;
    }
    saturator.curve = curve;
    saturator.oversample = '2x';

    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-7.5, ctx.currentTime);
    compressor.knee.setValueAtTime(6, ctx.currentTime);
    compressor.ratio.setValueAtTime(6.5, ctx.currentTime);
    compressor.attack.setValueAtTime(0.0018, ctx.currentTime); // Preserves razor-sharp 2ms gunshot transient!
    compressor.release.setValueAtTime(0.14, ctx.currentTime);

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.95, ctx.currentTime);

    this.dryBus = ctx.createGain();
    this.dryBus.gain.setValueAtTime(1.0, ctx.currentTime);

    this.reverbSend = ctx.createGain();
    this.reverbSend.gain.setValueAtTime(0.42, ctx.currentTime);

    const convolver = ctx.createConvolver();
    convolver.buffer = this.buildOutdoorImpulseResponse(ctx);

    const reverbLowpass = ctx.createBiquadFilter();
    reverbLowpass.type = 'lowpass';
    reverbLowpass.frequency.setValueAtTime(3400, ctx.currentTime);

    this.dryBus.connect(saturator);
    this.reverbSend.connect(convolver);
    convolver.connect(reverbLowpass);
    reverbLowpass.connect(saturator);

    saturator.connect(compressor);
    compressor.connect(masterGain);
    masterGain.connect(ctx.destination);
  }

  /**
   * Generates a realistic 1.65s stereo outdoor courtyard + alpine valley acoustic impulse response
   */
  private buildOutdoorImpulseResponse(ctx: AudioContext): AudioBuffer {
    const sr = ctx.sampleRate;
    const duration = 1.65;
    const len = Math.floor(sr * duration);
    const ir = ctx.createBuffer(2, len, sr);
    const left = ir.getChannelData(0);
    const right = ir.getChannelData(1);

    // Discrete early slapback reflections off stone courtyard walls & crates
    const earlyTaps = [
      { time: 0.016, gainL: 0.42, gainR: 0.24 },
      { time: 0.031, gainL: 0.22, gainR: 0.44 },
      { time: 0.054, gainL: 0.31, gainR: 0.28 },
      { time: 0.089, gainL: 0.19, gainR: 0.33 },
      { time: 0.145, gainL: 0.25, gainR: 0.16 }, // Near cliff bounce
      { time: 0.275, gainL: 0.14, gainR: 0.22 }, // Valley ridge bounce
    ];

    for (const tap of earlyTaps) {
      const idx = Math.floor(tap.time * sr);
      for (let k = 0; k < 180 && idx + k < len; k++) {
        const env = Math.exp(-k / 42);
        left[idx + k] += (Math.random() * 2 - 1) * tap.gainL * env;
        right[idx + k] += (Math.random() * 2 - 1) * tap.gainR * env;
      }
    }

    // Smooth air-damped outdoor valley diffuse tail
    let lpL = 0;
    let lpR = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const env = Math.pow(1 - t / duration, 2.4) * Math.exp(-t * 2.35);
      // Progressive high-frequency air absorption over distance
      const damp = Math.max(0.08, 0.58 * Math.exp(-t * 2.1));
      lpL += damp * ((Math.random() * 2 - 1) - lpL);
      lpR += damp * ((Math.random() * 2 - 1) - lpR);
      left[i] += lpL * env * 0.34;
      right[i] += lpR * env * 0.34;
    }

    return ir;
  }

  /**
   * Pre-bakes high-definition stereo gunshot waveforms with Friedlander N-Wave supersonic shockwaves,
   * dynamic turbulent gas expansion sweeps, and caliber-accurate chest thump!
   */
  private bakeNoiseAndWeaponBuffers(ctx: AudioContext) {
    const sr = ctx.sampleRate;
    const nLen = Math.floor(sr * 1.6);
    this.whiteNoiseBuffer = ctx.createBuffer(1, nLen, sr);
    this.pinkNoiseBuffer = ctx.createBuffer(1, nLen, sr);

    const wData = this.whiteNoiseBuffer.getChannelData(0);
    const pData = this.pinkNoiseBuffer.getChannelData(0);

    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < nLen; i++) {
      const white = Math.random() * 2 - 1;
      wData[i] = white;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      pData[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }

    this.shotBuffers.pistol = this.synthesizeGunshotBuffer(ctx, 'pistol');
    this.shotBuffers.rifle = this.synthesizeGunshotBuffer(ctx, 'rifle');
    this.shotBuffers.sniper = this.synthesizeGunshotBuffer(ctx, 'sniper');
  }

  private synthesizeGunshotBuffer(ctx: AudioContext, weapon: WeaponId): AudioBuffer {
    const sr = ctx.sampleRate;
    const duration = weapon === 'sniper' ? 1.45 : weapon === 'rifle' ? 0.55 : 0.38;
    const len = Math.floor(sr * duration);
    const buf = ctx.createBuffer(2, len, sr);
    const outL = buf.getChannelData(0);
    const outR = buf.getChannelData(1);

    // State variables for dynamic 1-pole low-pass & high-pass gas filters
    let lpL = 0;
    let lpR = 0;
    let hpPrevL = 0;
    let hpPrevR = 0;
    let subPhase = 0;
    let bodyPhase = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const nL = Math.random() * 2 - 1;
      const nR = Math.random() * 2 - 1;
      const nMono = (nL + nR) * 0.5;

      if (weapon === 'pistol') {
        // 1. 9x19mm Friedlander Supersonic Muzzle Snap (0 - 3ms)
        const tPlus = 0.00052;
        const shock = t < 0.004 ? (1 - t / tPlus) * Math.exp(-t / tPlus) * 0.95 : 0;

        // 2. Tight 9mm Chest Thump (195Hz -> 56Hz over 65ms)
        const fSub = 56 + 142 * Math.exp(-t * 48);
        subPhase += (2 * Math.PI * fSub) / sr;
        const thump = Math.sin(subPhase) * Math.exp(-t * 34) * 0.78;

        // 3. Snappy Propellant Bark (Dynamic LP cutoff 7800Hz -> 420Hz)
        const cutoff = 420 + 7400 * Math.exp(-t * 36);
        const alpha = Math.min(0.98, (2 * Math.PI * cutoff) / sr);
        const rawL = nMono * 0.72 + nL * 0.28;
        const rawR = nMono * 0.72 + nR * 0.28;
        lpL += alpha * (rawL - lpL);
        lpR += alpha * (rawR - lpR);

        // High-pass out DC mud on crack layer
        const gasEnv = Math.exp(-t * 21) * 0.88 + Math.exp(-t * 7.5) * 0.14;
        const sampleL = Math.tanh((shock + thump + lpL * gasEnv) * 1.45);
        const sampleR = Math.tanh((shock + thump + lpR * gasEnv) * 1.45);

        outL[i] = sampleL * 0.88;
        outR[i] = sampleR * 0.88;
      } else if (weapon === 'rifle') {
        // 1. 5.56x45mm NATO Razor Supersonic Crack (910 m/s N-wave + high-freq whip)
        const tPlus = 0.00064;
        const shock = t < 0.0055 ? (1 - t / tPlus) * Math.exp(-t / tPlus) * 1.08 : 0;
        const crackNoise = nMono * Math.exp(-t * 145) * 0.75;

        // 2. Muscular M4A1 Carbine Mid-Bass Thump (168Hz -> 44Hz) + Throat Growl (310Hz -> 95Hz)
        const fSub = 44 + 128 * Math.exp(-t * 38);
        const fBody = 95 + 225 * Math.exp(-t * 32);
        subPhase += (2 * Math.PI * fSub) / sr;
        bodyPhase += (2 * Math.PI * fBody) / sr;
        const punch =
          Math.sin(subPhase) * Math.exp(-t * 26) * 0.82 +
          Math.sin(bodyPhase) * Math.exp(-t * 42) * 0.44;

        // 3. Saturated Birdcage Compensator Gas Roar (8800Hz -> 360Hz)
        const cutoff = 360 + 8400 * Math.exp(-t * 28);
        const alpha = Math.min(0.99, (2 * Math.PI * cutoff) / sr);
        const turb = 1 + 0.22 * Math.sin(t * 410); // Gas turbulence flutter
        const rawL = (nMono * 0.65 + nL * 0.35) * turb;
        const rawR = (nMono * 0.65 + nR * 0.35) * turb;
        lpL += alpha * (rawL - lpL);
        lpR += alpha * (rawR - lpR);

        const gasEnv = Math.exp(-t * 15.5) * 0.96 + Math.exp(-t * 5.8) * 0.18;
        const sL = Math.tanh((shock + crackNoise + punch + lpL * gasEnv) * 1.62);
        const sR = Math.tanh((shock + crackNoise + punch + lpR * gasEnv) * 1.62);

        outL[i] = sL * 0.92;
        outR[i] = sR * 0.92;
      } else {
        // SNIPER: .338 Lapua Magnum Massive Muzzle-Brake Cannon + Rolling Valley Tail!
        const tPlus = 0.00125;
        const shock = t < 0.01 ? (1 - t / tPlus) * Math.exp(-t / tPlus) * 1.25 : 0;
        const whipCrack = (nMono - hpPrevL) * Math.exp(-t * 110) * 0.68;
        hpPrevL = nMono;
        hpPrevR = hpPrevR * 0.5;

        // Deep Concussive Sub-Bass Slam (108Hz -> 25Hz over 290ms)
        const fSub = 25 + 86 * Math.exp(-t * 19);
        const fChest = 68 + 145 * Math.exp(-t * 24);
        subPhase += (2 * Math.PI * fSub) / sr;
        bodyPhase += (2 * Math.PI * fChest) / sr;
        const slam =
          Math.sin(subPhase) * Math.exp(-t * 9.2) * 0.95 +
          Math.sin(bodyPhase) * Math.exp(-t * 18) * 0.58;

        // Ferocious Lateral Muzzle Brake Blast + Long Rolling Alpine Thunder
        const cutoff = 210 + 7200 * Math.exp(-t * 14);
        const alpha = Math.min(0.99, (2 * Math.PI * cutoff) / sr);
        const turb = 1 + 0.28 * Math.sin(t * 195) * Math.cos(t * 83);
        const rawL = (nMono * 0.55 + nL * 0.45) * turb;
        const rawR = (nMono * 0.55 + nR * 0.45) * turb;
        lpL += alpha * (rawL - lpL);
        lpR += alpha * (rawR - lpR);

        // Multi-stage envelope: violent initial blast + rolling mountain valley rumble
        const blastEnv =
          Math.exp(-t * 8.5) * 1.05 +
          Math.exp(-Math.pow((t - 0.16) / 0.12, 2)) * 0.24 + // Left cliff echo swell
          Math.exp(-Math.pow((t - 0.34) / 0.18, 2)) * 0.17 + // Right mountain ridge swell
          Math.exp(-t * 2.4) * 0.16;

        const sL = Math.tanh((shock + whipCrack + slam + lpL * blastEnv) * 1.72);
        const sR = Math.tanh((shock + whipCrack + slam + lpR * (blastEnv * 1.03)) * 1.72);

        outL[i] = sL * 0.96;
        outR[i] = sR * 0.96;
      }
    }

    return buf;
  }

  /**
   * Plays realistic modal steel resonance (gun slides, bolt lugs, mag catches, charging handles) — ZERO retro square waves!
   */
  private triggerSteelModalImpact(
    ctx: AudioContext,
    time: number,
    baseFreq: number,
    ratios: number[],
    decaySec: number,
    volume: number,
    brightness = 3800
  ) {
    if (!this.dryBus || !this.whiteNoiseBuffer) return;

    // 1. Short crisp contact transient impulse (filtered noise click)
    const clickSrc = ctx.createBufferSource();
    clickSrc.buffer = this.whiteNoiseBuffer;
    const clickFilter = ctx.createBiquadFilter();
    clickFilter.type = 'bandpass';
    clickFilter.frequency.setValueAtTime(brightness, time);
    clickFilter.Q.setValueAtTime(2.2, time);

    const clickGain = ctx.createGain();
    clickGain.gain.setValueAtTime(volume * 0.85, time);
    clickGain.gain.exponentialRampToValueAtTime(0.0008, time + 0.014);

    clickSrc.connect(clickFilter);
    clickFilter.connect(clickGain);
    clickGain.connect(this.dryBus);
    clickSrc.start(time, Math.random() * 0.5, 0.02);

    // 2. Inharmonic steel eigenmodes
    ratios.forEach((ratio, idx) => {
      const freq = baseFreq * ratio;
      if (freq > ctx.sampleRate * 0.45) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.985, time + decaySec);

      const modeAmp = (volume * 0.42) / (1 + idx * 0.75);
      const modeDecay = decaySec / (1 + idx * 0.45);
      gain.gain.setValueAtTime(modeAmp, time);
      gain.gain.exponentialRampToValueAtTime(0.0005, time + modeDecay);

      osc.connect(gain);
      gain.connect(this.dryBus!);
      osc.start(time);
      osc.stop(time + modeDecay + 0.008);
    });
  }

  /**
   * Plays realistic sliding metal/polymer friction scrape (magazines, bolts, slides, cloth)
   */
  private triggerFrictionSlide(
    ctx: AudioContext,
    time: number,
    duration: number,
    startFreq: number,
    endFreq: number,
    q: number,
    volume: number,
    usePink = false
  ) {
    const buf = usePink ? this.pinkNoiseBuffer : this.whiteNoiseBuffer;
    if (!buf || !this.dryBus) return;

    const src = ctx.createBufferSource();
    src.buffer = buf;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(startFreq, time);
    filter.frequency.exponentialRampToValueAtTime(Math.max(80, endFreq), time + duration);
    filter.Q.setValueAtTime(q, time);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, time);
    gain.gain.linearRampToValueAtTime(volume, time + Math.min(0.015, duration * 0.25));
    gain.gain.exponentialRampToValueAtTime(0.0008, time + duration);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.dryBus);

    src.start(time, Math.random() * 0.6, duration + 0.02);
  }

  /**
   * Plays deep physical polymer/metal body thud (magazine slam, shoulder mount, bolt stop)
   */
  private triggerBodyThud(
    ctx: AudioContext,
    time: number,
    startFreq: number,
    endFreq: number,
    duration: number,
    volume: number
  ) {
    if (!this.dryBus) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, time);
    osc.frequency.exponentialRampToValueAtTime(Math.max(24, endFreq), time + duration);

    gain.gain.setValueAtTime(volume, time);
    gain.gain.exponentialRampToValueAtTime(0.0008, time + duration);

    osc.connect(gain);
    gain.connect(this.dryBus);
    osc.start(time);
    osc.stop(time + duration + 0.01);
  }

  /**
   * FIRES STUDIO-GRADE REALISTIC GUNSHOT + MECHANICAL ACTION + OUTDOOR REVERB TAIL
   */
  public playGunshot(weapon: WeaponId, slowMo = false, isLastRound = false) {
    const ctx = this.ensureContext();
    const shotBuf = this.shotBuffers[weapon];
    if (!ctx || !shotBuf || !this.dryBus || !this.reverbSend) return;

    const now = ctx.currentTime;
    const rateJitter = 0.975 + Math.random() * 0.05; // Natural shot-to-shot acoustic variation
    const playbackRate = (slowMo ? 0.46 : 1.0) * rateJitter;
    const stretch = slowMo ? 2.1 : 1.0;

    // 1. Primary Pre-Baked Acoustic Blast Wave + Propellant Roar
    const src = ctx.createBufferSource();
    src.buffer = shotBuf;
    src.playbackRate.setValueAtTime(playbackRate, now);

    // Subtle per-shot presence filter variation
    const presence = ctx.createBiquadFilter();
    presence.type = 'peaking';
    presence.frequency.setValueAtTime(
      (weapon === 'pistol' ? 2400 : weapon === 'rifle' ? 1950 : 1250) * rateJitter,
      now
    );
    presence.gain.setValueAtTime(2.2 + (Math.random() - 0.5) * 1.4, now);

    const dryGain = ctx.createGain();
    const wetGain = ctx.createGain();

    if (weapon === 'pistol') {
      dryGain.gain.setValueAtTime(0.92, now);
      wetGain.gain.setValueAtTime(0.48, now);
    } else if (weapon === 'rifle') {
      dryGain.gain.setValueAtTime(0.98, now);
      wetGain.gain.setValueAtTime(0.68, now);
    } else {
      dryGain.gain.setValueAtTime(1.12, now);
      wetGain.gain.setValueAtTime(1.05, now); // Huge canyon tail for .338 Sniper!
    }

    src.connect(presence);
    presence.connect(dryGain);
    presence.connect(wetGain);
    dryGain.connect(this.dryBus);
    wetGain.connect(this.reverbSend);
    src.start(now);

    // 2. Real-Time Mechanical Firearm Action Layer (Shooter's Ear Perspective!)
    if (weapon === 'pistol') {
      // Crisp steel slide blowback clack + recoil spring zip
      this.triggerSteelModalImpact(
        ctx,
        now + 0.022 * stretch,
        1820 * rateJitter,
        [1.0, 1.54, 2.28, 3.12],
        0.048 * stretch,
        0.24,
        4600
      );
      if (isLastRound) {
        // Distinct open-chamber steel slide-lock catch ping when magazine hits 0!
        this.triggerSteelModalImpact(
          ctx,
          now + 0.042 * stretch,
          2680,
          [1.0, 1.48, 2.15],
          0.11 * stretch,
          0.28,
          5400
        );
      }
    } else if (weapon === 'rifle') {
      // M4A1 Bolt Carrier high-speed reciprocation clack + iconic subtle AR-15 buffer spring ring!
      this.triggerSteelModalImpact(
        ctx,
        now + 0.02 * stretch,
        1540 * rateJitter,
        [1.0, 1.62, 2.41, 3.35],
        0.055 * stretch,
        0.26,
        4200
      );
      // Subtle damped AR-15 buffer tube spring resonance inside buttstock
      this.triggerSteelModalImpact(
        ctx,
        now + 0.034 * stretch,
        1095,
        [1.0, 2.68],
        0.095 * stretch,
        0.085,
        3100
      );
    } else if (weapon === 'sniper') {
      // Heavy forged steel receiver & barrel harmonic ring after .338 detonation
      this.triggerSteelModalImpact(
        ctx,
        now + 0.015 * stretch,
        1380,
        [1.0, 1.74, 2.86],
        0.16 * stretch,
        0.22,
        3800
      );
    }
  }

  /**
   * HYPER-REALISTIC TACTICAL RELOAD FOLEY SUITE (Tailored to Pistol 9mm, Rifle M4A1, & Sniper .338!)
   */
  public playReloadSound(weapon: WeaponId, stage: ReloadAudioStage, slowMo = false) {
    const ctx = this.ensureContext();
    if (!ctx || !this.dryBus) return;
    const now = ctx.currentTime;
    const s = slowMo ? 1.85 : 1.0;

    switch (stage) {
      case 'grabTilt': {
        // Brisk tactical sleeve/glove swoosh + firm weapon cant grab
        this.triggerFrictionSlide(ctx, now, 0.085 * s, 950, 1850, 0.9, 0.14, true);
        this.triggerBodyThud(ctx, now + 0.015 * s, 115, 48, 0.055 * s, 0.16);
        break;
      }

      case 'magOut': {
        // 1. Crisp steel magazine release button click
        this.triggerSteelModalImpact(
          ctx,
          now,
          weapon === 'sniper' ? 1480 : 1950,
          [1.0, 1.58, 2.35],
          0.038 * s,
          0.28,
          4400
        );
        // 2. Weapon-specific magazine extraction scrape
        if (weapon === 'pistol') {
          this.triggerFrictionSlide(ctx, now + 0.014 * s, 0.095 * s, 2200, 3900, 2.4, 0.2);
          this.triggerBodyThud(ctx, now + 0.02 * s, 150, 72, 0.045 * s, 0.14);
        } else if (weapon === 'rifle') {
          // Hollow STANAG aluminum/polymer magwell scrape
          this.triggerFrictionSlide(ctx, now + 0.016 * s, 0.125 * s, 1350, 2650, 2.8, 0.25);
          this.triggerSteelModalImpact(ctx, now + 0.045 * s, 980, [1.0, 1.82], 0.05 * s, 0.14, 2800);
        } else {
          // Heavy .338 steel box mag unlatch clunk + slide
          this.triggerBodyThud(ctx, now + 0.012 * s, 128, 44, 0.075 * s, 0.26);
          this.triggerFrictionSlide(ctx, now + 0.02 * s, 0.145 * s, 920, 2100, 2.5, 0.26);
          this.triggerSteelModalImpact(ctx, now + 0.03 * s, 840, [1.0, 1.49, 2.22], 0.07 * s, 0.22, 2600);
        }
        break;
      }

      case 'magDrop': {
        // Empty magazine clattering on ground
        this.triggerBodyThud(ctx, now, 185, 65, 0.055, 0.14);
        this.triggerSteelModalImpact(
          ctx,
          now,
          weapon === 'pistol' ? 1620 : 1120,
          [1.0, 1.44, 2.18],
          0.065,
          0.15,
          3200
        );
        this.triggerSteelModalImpact(
          ctx,
          now + 0.088,
          weapon === 'pistol' ? 1740 : 1210,
          [1.0, 1.52],
          0.048,
          0.09,
          2900
        );
        break;
      }

      case 'magTap': {
        // Crisp magazine lip alignment contact against magwell flare right before the slam!
        this.triggerSteelModalImpact(
          ctx,
          now,
          weapon === 'sniper' ? 1280 : 1760,
          [1.0, 1.66],
          0.032 * s,
          0.19,
          3800
        );
        this.triggerFrictionSlide(ctx, now + 0.008 * s, 0.055 * s, 1600, 950, 2.0, 0.15);
        break;
      }

      case 'magIn': {
        // THE SIGNATURE HIGH-MOMENTUM MAGAZINE SLAM + POSITIVE LATCH LOCK!
        if (weapon === 'pistol') {
          this.triggerBodyThud(ctx, now, 178, 54, 0.085 * s, 0.42);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.012 * s,
            2180,
            [1.0, 1.51, 2.29, 3.14],
            0.058 * s,
            0.36,
            5100
          );
        } else if (weapon === 'rifle') {
          // Deep resonant M4 magwell thud + crisp STANAG mag-catch click + baseplate palm slap!
          this.triggerBodyThud(ctx, now, 152, 44, 0.105 * s, 0.5);
          this.triggerFrictionSlide(ctx, now, 0.045 * s, 2100, 1150, 2.2, 0.24);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.016 * s,
            1840,
            [1.0, 1.58, 2.38, 3.25],
            0.068 * s,
            0.38,
            4700
          );
        } else {
          // Heavy .338 steel box magazine authoritative rock-and-lock KA-THUNK!
          this.triggerBodyThud(ctx, now, 128, 36, 0.125 * s, 0.56);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.018 * s,
            1390,
            [1.0, 1.47, 2.19, 3.08],
            0.085 * s,
            0.42,
            4100
          );
        }
        break;
      }

      case 'rackPull': {
        if (weapon === 'pistol') {
          // Serrated steel slide brisk rearward rack + recoil spring compression
          this.triggerFrictionSlide(ctx, now, 0.075 * s, 2100, 3800, 2.6, 0.26);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.045 * s,
            2050,
            [1.0, 1.55, 2.32],
            0.048 * s,
            0.3,
            4900
          );
        } else if (weapon === 'rifle') {
          // M4 T-Charging Handle latch unhook click + aluminum receiver channel pull!
          this.triggerSteelModalImpact(ctx, now, 2240, [1.0, 1.62], 0.032 * s, 0.26, 5200);
          this.triggerFrictionSlide(ctx, now + 0.012 * s, 0.095 * s, 1650, 3300, 2.8, 0.28);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.068 * s,
            1580,
            [1.0, 1.49, 2.25],
            0.055 * s,
            0.28,
            4300
          );
        } else {
          // Sniper bolt cam lift + heavy steel pull back
          this.playBoltStep('lift');
          setTimeout(() => this.playBoltStep('pull'), 65 * s);
        }
        break;
      }

      case 'rackRelease': {
        if (weapon === 'pistol') {
          // Slingshot steel slide slamming forward into battery + 9mm brass chambering clink!
          this.triggerFrictionSlide(ctx, now, 0.045 * s, 3400, 1900, 2.2, 0.22);
          this.triggerBodyThud(ctx, now + 0.018 * s, 168, 56, 0.068 * s, 0.36);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.018 * s,
            1960,
            [1.0, 1.52, 2.36, 3.42],
            0.072 * s,
            0.42,
            5400
          );
        } else if (weapon === 'rifle') {
          // Iconic M4A1 Bolt-Carrier KA-CHUNK slam forward + buffer spring ring!
          this.triggerFrictionSlide(ctx, now, 0.052 * s, 2900, 1500, 2.4, 0.25);
          this.triggerBodyThud(ctx, now + 0.022 * s, 148, 46, 0.082 * s, 0.44);
          this.triggerSteelModalImpact(
            ctx,
            now + 0.022 * s,
            1680,
            [1.0, 1.59, 2.44, 3.31],
            0.08 * s,
            0.45,
            4800
          );
          // Subtle AR buffer spring ring
          this.triggerSteelModalImpact(
            ctx,
            now + 0.036 * s,
            1105,
            [1.0, 2.65],
            0.095 * s,
            0.1,
            3100
          );
        } else {
          // Sniper heavy .338 cartridge feed + steel bolt lug lock down!
          this.playBoltStep('push');
          setTimeout(() => this.playBoltStep('lock'), 70 * s);
        }
        break;
      }

      case 'readySnap': {
        // Firm shoulder/grip settle as weapon whips back into Gambar 2 Ready Pose
        this.triggerFrictionSlide(ctx, now, 0.065 * s, 1400, 820, 1.0, 0.12, true);
        this.triggerBodyThud(ctx, now + 0.01 * s, 105, 42, 0.055 * s, 0.18);
        break;
      }
    }
  }

  /**
   * Legacy helper mapped cleanly onto the new high-realism reload audio suite
   */
  public playReloadStep(step: 'magOut' | 'magIn' | 'rack', weapon: WeaponId = 'rifle') {
    if (step === 'magOut') this.playReloadSound(weapon, 'magOut');
    else if (step === 'magIn') this.playReloadSound(weapon, 'magIn');
    else {
      this.playReloadSound(weapon, 'rackPull');
      setTimeout(() => this.playReloadSound(weapon, 'rackRelease'), 95);
    }
  }

  public playWeaponSwitch(weapon: WeaponId) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    // Holster/sling cloth draw + crisp metallic safety/grip index click
    this.triggerFrictionSlide(ctx, now, 0.11, 850, 1950, 1.1, 0.16, true);
    this.triggerBodyThud(
      ctx,
      now + 0.035,
      weapon === 'sniper' ? 105 : 135,
      44,
      0.065,
      0.22
    );
    this.triggerSteelModalImpact(
      ctx,
      now + 0.055,
      weapon === 'pistol' ? 2150 : weapon === 'rifle' ? 1780 : 1420,
      [1.0, 1.56, 2.3],
      0.045,
      0.2,
      4200
    );
  }

  public playBoltStep(step: 'lift' | 'pull' | 'push' | 'lock') {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    if (step === 'lift') {
      // Heavy steel camming lug unlock clunk
      this.triggerBodyThud(ctx, now, 135, 52, 0.05, 0.22);
      this.triggerSteelModalImpact(ctx, now, 1680, [1.0, 1.54, 2.28], 0.052, 0.32, 4300);
    } else if (step === 'pull') {
      // Smooth oiled steel receiver rail slide + brass extractor ring
      this.triggerFrictionSlide(ctx, now, 0.115, 1450, 3200, 2.8, 0.28);
      this.triggerSteelModalImpact(ctx, now + 0.065, 2120, [1.0, 1.61, 2.45], 0.065, 0.34, 5100);
    } else if (step === 'push') {
      // Stripping heavy .338 cartridge up feed ramp into steel chamber
      this.triggerFrictionSlide(ctx, now, 0.105, 2850, 1350, 2.5, 0.26);
      this.triggerSteelModalImpact(ctx, now + 0.055, 1840, [1.0, 1.48, 2.18], 0.055, 0.28, 4400);
    } else {
      // Solid authoritative steel bolt handle lock down!
      this.triggerBodyThud(ctx, now, 142, 46, 0.075, 0.34);
      this.triggerSteelModalImpact(ctx, now, 1520, [1.0, 1.58, 2.39, 3.18], 0.072, 0.38, 4600);
    }
  }

  public playShellBounce(caliber: '9mm' | '556' | '338') {
    const ctx = this.ensureContext();
    if (!ctx || !this.dryBus) return;
    const now = ctx.currentTime;
    const baseFreq = caliber === '9mm' ? 4850 : caliber === '556' ? 4120 : 3280;

    [0, 0.068, 0.128].forEach((offset, idx) => {
      const jitter = 0.97 + Math.random() * 0.06;
      this.triggerSteelModalImpact(
        ctx,
        now + offset,
        baseFreq * jitter,
        [1.0, 1.38, 1.92],
        0.048 / (1 + idx * 0.25),
        0.095 / (idx + 1),
        6200
      );
    });
  }

  public playDryFire() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    this.triggerSteelModalImpact(ctx, now, 2750, [1.0, 1.56, 2.42], 0.036, 0.3, 5600);
  }

  public playHitmarker(isHeadshot: boolean) {
    const ctx = this.ensureContext();
    if (!ctx || !this.dryBus) return;
    const now = ctx.currentTime;
    // Crisp Modern Warfare / Bodycam tactile hit thud + headshot helmet dink!
    this.triggerBodyThud(ctx, now, isHeadshot ? 240 : 185, 62, 0.048, 0.28);
    this.triggerFrictionSlide(ctx, now, 0.028, 3200, 1800, 1.4, 0.22);
    if (isHeadshot) {
      this.triggerSteelModalImpact(
        ctx,
        now + 0.006,
        2480,
        [1.0, 1.52, 2.26],
        0.14,
        0.34,
        5800
      );
    }
  }

  public playFootstep(isSprint: boolean, side: 'left' | 'right', onWood = false) {
    const ctx = this.ensureContext();
    if (!ctx || !this.dryBus || !this.pinkNoiseBuffer) return;
    const now = ctx.currentTime;
    const pitchJitter = (side === 'left' ? 0.97 : 1.03) * (0.97 + Math.random() * 0.06);
    const vol = isSprint ? 0.175 : 0.105;

    if (onWood) {
      // Warm muffled rubber-sole step on wooden crate (soft attack, no harsh click)
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(145 * pitchJitter, now);
      osc.frequency.exponentialRampToValueAtTime(52, now + 0.095);
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(vol * 1.15, now + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0008, now + 0.1);
      osc.connect(g);
      g.connect(this.dryBus);
      osc.start(now);
      osc.stop(now + 0.11);

      this.triggerFrictionSlide(ctx, now + 0.008, 0.075, 620 * pitchJitter, 340, 1.1, vol * 0.45, true);
      return;
    }

    // 1. Soft-attack cushioned heel-to-toe low-end roll (12ms smooth ramp -> zero harsh click!)
    const heelOsc = ctx.createOscillator();
    const heelGain = ctx.createGain();
    heelOsc.type = 'sine';
    heelOsc.frequency.setValueAtTime((isSprint ? 92 : 78) * pitchJitter, now);
    heelOsc.frequency.exponentialRampToValueAtTime(32, now + (isSprint ? 0.105 : 0.088));
    heelGain.gain.setValueAtTime(0.001, now);
    heelGain.gain.linearRampToValueAtTime(vol, now + 0.013);
    heelGain.gain.exponentialRampToValueAtTime(0.0008, now + (isSprint ? 0.11 : 0.092));
    heelOsc.connect(heelGain);
    heelGain.connect(this.dryBus);
    heelOsc.start(now);
    heelOsc.stop(now + 0.12);

    // 2. Smooth low-passed turf/earth sole roll-off (Pink noise gently filtered < 950Hz, zero high-pitch hiss!)
    const soleSrc = ctx.createBufferSource();
    soleSrc.buffer = this.pinkNoiseBuffer;
    const soleLp = ctx.createBiquadFilter();
    soleLp.type = 'lowpass';
    soleLp.frequency.setValueAtTime((isSprint ? 920 : 720) * pitchJitter, now);
    soleLp.frequency.exponentialRampToValueAtTime(360, now + 0.095);

    const soleGain = ctx.createGain();
    soleGain.gain.setValueAtTime(0.001, now + 0.006);
    soleGain.gain.linearRampToValueAtTime(vol * 0.52, now + 0.024);
    soleGain.gain.exponentialRampToValueAtTime(0.0008, now + (isSprint ? 0.105 : 0.085));

    soleSrc.connect(soleLp);
    soleLp.connect(soleGain);
    soleGain.connect(this.dryBus);
    soleSrc.start(now + 0.006, Math.random() * 0.6, 0.12);

    // 3. Very subtle warm fabric/trouser air-whoosh during long sprint strides
    if (isSprint) {
      this.triggerFrictionSlide(ctx, now + 0.018, 0.095, 680, 440, 0.85, 0.036, true);
    }
  }

  public playJumpLand(isLanding: boolean, onWood = false) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    if (isLanding) {
      if (onWood) {
        // Solid boot thump on hollow wooden box crate!
        this.triggerBodyThud(ctx, now, 210, 58, 0.14, 0.48);
        this.triggerSteelModalImpact(ctx, now + 0.005, 320, [1.0, 1.65, 2.35], 0.095, 0.32, 1650);
        this.triggerFrictionSlide(ctx, now + 0.015, 0.09, 1450, 720, 1.3, 0.18, true);
      } else {
        this.triggerBodyThud(ctx, now, 136, 28, 0.13, 0.38);
        this.triggerFrictionSlide(ctx, now + 0.01, 0.11, 980, 480, 1.1, 0.22, true);
        this.triggerFrictionSlide(ctx, now + 0.025, 0.09, 2200, 1200, 1.2, 0.075, true);
      }
    } else {
      this.triggerBodyThud(ctx, now, 92, 148, 0.065, 0.2);
      this.triggerFrictionSlide(ctx, now, 0.075, 1600, 2300, 1.2, 0.095, true);
    }
  }

  public playCrouchToggle(crouching: boolean) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    // Crisp tactical pants/gear rustle + soft knee/stance settle
    this.triggerFrictionSlide(
      ctx,
      now,
      0.095,
      crouching ? 1650 : 1050,
      crouching ? 920 : 1750,
      1.05,
      0.13,
      true
    );
    this.triggerBodyThud(ctx, now + 0.02, crouching ? 108 : 95, 42, 0.055, 0.14);
  }

  public playExplosion() {
    const ctx = this.ensureContext();
    if (!ctx || !this.pinkNoiseBuffer || !this.dryBus || !this.reverbSend) return;
    const now = ctx.currentTime;
    this.triggerBodyThud(ctx, now, 125, 22, 0.55, 0.85);

    const src = ctx.createBufferSource();
    src.buffer = this.pinkNoiseBuffer;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(950, now);
    lp.frequency.exponentialRampToValueAtTime(140, now + 0.85);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.82, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

    src.connect(lp);
    lp.connect(g);
    g.connect(this.dryBus);
    g.connect(this.reverbSend);
    src.start(now, 0, 0.95);
  }
}

export const soundEngine = new SoundEngine();
