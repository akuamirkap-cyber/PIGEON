import * as THREE from 'three';
import { WeaponId } from './types';
import { soundEngine } from './soundEngine';

interface ActiveBullet {
  group: THREE.Group;
  vel: THREE.Vector3;
  distTraveled: number;
  maxDist: number;
  life: number;
}

interface ActiveCasing {
  group: THREE.Group;
  vel: THREE.Vector3;
  rotVel: THREE.Vector3;
  caliber: '9mm' | '556' | '338';
  bounced: boolean;
  life: number;
  maxLife: number;
}

interface ActiveDroppedMag {
  group: THREE.Group;
  weapon: WeaponId;
  vel: THREE.Vector3;
  rotVel: THREE.Vector3;
  bounced: boolean;
  life: number;
  maxLife: number;
}

interface ActiveParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  gravity: number;
  drag: number;
  scaleRate: number;
  life: number;
  maxLife: number;
  initialOpacity: number;
  mat: THREE.MeshBasicMaterial | THREE.MeshStandardMaterial;
}

interface ActiveShockRing {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  life: number;
  maxLife: number;
  expandRate: number;
}

const MAT_CASING_BRASS = new THREE.MeshStandardMaterial({
  color: 0xe6bc53,
  roughness: 0.26,
  metalness: 0.82,
  flatShading: true,
});

const MAT_CASING_MOUTH = new THREE.MeshBasicMaterial({
  color: 0x161412,
});

const MAT_BULLET_TIP = new THREE.MeshStandardMaterial({
  color: 0xd4743b,
  emissive: 0x5c2408,
  roughness: 0.28,
  metalness: 0.65,
  flatShading: true,
});

const MAT_DROPPED_MAG = new THREE.MeshStandardMaterial({
  color: 0x22262e,
  roughness: 0.54,
  metalness: 0.35,
  flatShading: true,
});

const MAT_DROPPED_MAG_BASE = new THREE.MeshStandardMaterial({
  color: 0xb8733c,
  roughness: 0.45,
  metalness: 0.42,
  flatShading: true,
});

export class BallisticsSystem {
  private worldScene: THREE.Scene;
  private bullets: ActiveBullet[] = [];
  private casings: ActiveCasing[] = [];
  private droppedMags: ActiveDroppedMag[] = [];
  private particles: ActiveParticle[] = [];
  private shockRings: ActiveShockRing[] = [];
  private muzzleFlashes: { group: THREE.Group; light: THREE.PointLight; life: number; maxLife: number }[] = [];

  private smokeGeo = new THREE.IcosahedronGeometry(0.032, 0);
  private sparkGeo = new THREE.OctahedronGeometry(0.012, 0);

  constructor(worldScene: THREE.Scene) {
    this.worldScene = worldScene;
  }

  private buildCasingGeometry(caliber: '9mm' | '556' | '338'): THREE.Group {
    const g = new THREE.Group();
    if (caliber === '9mm') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.0058, 0.006, 0.022, 7), MAT_CASING_BRASS);
      body.rotation.x = Math.PI / 2;
      const mouth = new THREE.Mesh(new THREE.CircleGeometry(0.005, 7), MAT_CASING_MOUTH);
      mouth.position.z = -0.0112;
      mouth.rotation.y = Math.PI;
      g.add(body, mouth);
    } else if (caliber === '556') {
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.0058, 0.0062, 0.03, 7), MAT_CASING_BRASS);
      body.rotation.x = Math.PI / 2;
      body.position.z = 0.005;
      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.0056, 0.012, 7), MAT_CASING_BRASS);
      neck.rotation.x = Math.PI / 2;
      neck.position.z = -0.015;
      const mouth = new THREE.Mesh(new THREE.CircleGeometry(0.0036, 7), MAT_CASING_MOUTH);
      mouth.position.z = -0.0212;
      mouth.rotation.y = Math.PI;
      g.add(body, neck, mouth);
    } else {
      // Large .338 Lapua Magnum Brass Casing
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.0082, 0.0088, 0.048, 8), MAT_CASING_BRASS);
      body.rotation.x = Math.PI / 2;
      body.position.z = 0.008;
      const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.0056, 0.008, 0.018, 8), MAT_CASING_BRASS);
      neck.rotation.x = Math.PI / 2;
      neck.position.z = -0.024;
      const mouth = new THREE.Mesh(new THREE.CircleGeometry(0.005, 8), MAT_CASING_MOUTH);
      mouth.position.z = -0.0332;
      mouth.rotation.y = Math.PI;
      g.add(body, neck, mouth);
    }
    g.scale.setScalar(1.35); // Slightly enhanced visibility so player clearly sees brass spin in 3D
    return g;
  }

  /**
   * Spawns 3D Copper Bullet + Tracer + Muzzle Flash + Propellant Sparks + Hot Barrel Smoke from exact Muzzle Anchor
   */
  public fireFromMuzzle(
    weapon: WeaponId,
    muzzleWorldPos: THREE.Vector3,
    targetWorldPos: THREE.Vector3,
    cameraQuat: THREE.Quaternion
  ) {
    const dir = targetWorldPos.clone().sub(muzzleWorldPos);
    const totalDist = Math.max(1.5, dir.length());
    dir.normalize();

    // 1. 3D Bullet Projectile + Glowing Tracer Streak
    const bulletGroup = new THREE.Group();
    bulletGroup.position.copy(muzzleWorldPos);
    bulletGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), dir);

    const scale = weapon === 'sniper' ? 1.55 : weapon === 'rifle' ? 1.15 : 1.0;
    const ogive = new THREE.Mesh(new THREE.ConeGeometry(0.009 * scale, 0.036 * scale, 7), MAT_BULLET_TIP);
    ogive.rotation.x = -Math.PI / 2;
    ogive.position.z = -0.018 * scale;

    const jacket = new THREE.Mesh(
      new THREE.CylinderGeometry(0.009 * scale, 0.009 * scale, 0.028 * scale, 7),
      MAT_BULLET_TIP
    );
    jacket.rotation.x = Math.PI / 2;
    jacket.position.z = 0.014 * scale;

    const tracerLen = weapon === 'sniper' ? 2.4 : weapon === 'rifle' ? 1.55 : 0.95;
    const tracerColor = weapon === 'sniper' ? 0xfff3b8 : weapon === 'rifle' ? 0xffcb6b : 0xffb347;
    const tracerMat = new THREE.MeshBasicMaterial({
      color: tracerColor,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
    });
    const tracerBeam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.0035 * scale, 0.011 * scale, tracerLen, 6),
      tracerMat
    );
    tracerBeam.rotation.x = Math.PI / 2;
    tracerBeam.position.z = tracerLen * 0.5 + 0.025;

    bulletGroup.add(ogive, jacket, tracerBeam);
    this.worldScene.add(bulletGroup);

    const speed = weapon === 'sniper' ? 240 : weapon === 'rifle' ? 185 : 130;
    this.bullets.push({
      group: bulletGroup,
      vel: dir.clone().multiplyScalar(speed),
      distTraveled: 0,
      maxDist: totalDist,
      life: 1.8,
    });

    // Sniper supersonic vapor trail ring along barrel wake
    if (weapon === 'sniper') {
      for (let i = 1; i <= 3; i++) {
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xeef6ff,
          transparent: true,
          opacity: 0.52 / i,
          side: THREE.DoubleSide,
          depthWrite: false,
        });
        const ring = new THREE.Mesh(new THREE.RingGeometry(0.02, 0.055, 12), ringMat);
        ring.position.copy(muzzleWorldPos).addScaledVector(dir, i * 0.45);
        ring.lookAt(targetWorldPos);
        this.worldScene.add(ring);
        this.shockRings.push({
          mesh: ring,
          mat: ringMat,
          life: 0,
          maxLife: 0.28 + i * 0.06,
          expandRate: 4.6 - i * 0.8,
        });
      }
    }

    // 2. Weapon-Specific 3D Polygonal Muzzle Flash + Dynamic Light
    const flashGroup = new THREE.Group();
    flashGroup.position.copy(muzzleWorldPos);
    flashGroup.quaternion.copy(cameraQuat);
    flashGroup.rotateZ(Math.random() * Math.PI * 2);

    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xfff8cc,
      transparent: true,
      opacity: 0.96,
      depthWrite: false,
    });
    const outerMat = new THREE.MeshBasicMaterial({
      color: 0xff7b1c,
      transparent: true,
      opacity: 0.86,
      depthWrite: false,
    });

    if (weapon === 'pistol') {
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.036, 0.14, 6), outerMat);
      cone.rotation.x = -Math.PI / 2;
      cone.position.z = -0.07;
      const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.03, 0), coreMat);
      core.position.z = -0.02;
      flashGroup.add(cone, core);
    } else if (weapon === 'rifle') {
      // 4-way Birdcage Flash Hider Cross Spikes + Forward Jet
      const fwd = new THREE.Mesh(new THREE.ConeGeometry(0.032, 0.22, 6), outerMat);
      fwd.rotation.x = -Math.PI / 2;
      fwd.position.z = -0.11;
      flashGroup.add(fwd);
      for (let i = 0; i < 4; i++) {
        const wing = new THREE.Mesh(new THREE.ConeGeometry(0.022, 0.13, 5), i % 2 === 0 ? coreMat : outerMat);
        const angle = (i * Math.PI) / 2 + Math.PI / 4;
        wing.position.set(Math.cos(angle) * 0.055, Math.sin(angle) * 0.055, -0.035);
        wing.rotation.z = angle - Math.PI / 2;
        wing.rotation.x = -0.35;
        flashGroup.add(wing);
      }
    } else {
      // Sniper Massive Lateral Muzzle Brake Blast + Long Central Lance
      const lance = new THREE.Mesh(new THREE.ConeGeometry(0.048, 0.38, 7), coreMat);
      lance.rotation.x = -Math.PI / 2;
      lance.position.z = -0.19;
      const leftJet = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.28, 6), outerMat);
      leftJet.rotation.z = Math.PI / 2;
      leftJet.position.set(-0.14, 0, -0.03);
      const rightJet = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.28, 6), outerMat);
      rightJet.rotation.z = -Math.PI / 2;
      rightJet.position.set(0.14, 0, -0.03);
      flashGroup.add(lance, leftJet, rightJet);
    }

    const flashLight = new THREE.PointLight(0xffa94d, weapon === 'sniper' ? 5.5 : 3.2, 6.5);
    flashLight.position.copy(muzzleWorldPos);
    this.worldScene.add(flashGroup, flashLight);
    this.muzzleFlashes.push({
      group: flashGroup,
      light: flashLight,
      life: 0,
      maxLife: weapon === 'sniper' ? 0.085 : 0.052,
    });

    // 3. Unburnt Powder Sparks & Rising Muzzle Heat Smoke
    const sparkCount = weapon === 'sniper' ? 11 : weapon === 'rifle' ? 7 : 5;
    for (let i = 0; i < sparkCount; i++) {
      const sMat = new THREE.MeshBasicMaterial({
        color: i % 2 === 0 ? 0xffe28a : 0xff7714,
        transparent: true,
        opacity: 1,
      });
      const spark = new THREE.Mesh(this.sparkGeo, sMat);
      spark.position.copy(muzzleWorldPos);
      const spread = new THREE.Vector3(
        (Math.random() - 0.5) * 2.8,
        (Math.random() - 0.35) * 2.8,
        (Math.random() - 0.5) * 2.8
      );
      const sVel = dir.clone().multiplyScalar(8 + Math.random() * 14).add(spread);
      this.worldScene.add(spark);
      this.particles.push({
        mesh: spark,
        vel: sVel,
        gravity: -6.5,
        drag: 4.5,
        scaleRate: -1.4,
        life: 0,
        maxLife: 0.18 + Math.random() * 0.16,
        initialOpacity: 1,
        mat: sMat,
      });
    }

    const smokeCount = weapon === 'sniper' ? 6 : weapon === 'rifle' ? 3 : 2;
    for (let i = 0; i < smokeCount; i++) {
      const smMat = new THREE.MeshStandardMaterial({
        color: 0xd8dee9,
        roughness: 0.95,
        transparent: true,
        opacity: weapon === 'sniper' ? 0.44 : 0.32,
        flatShading: true,
        depthWrite: false,
      });
      const puff = new THREE.Mesh(this.smokeGeo, smMat);
      puff.position.copy(muzzleWorldPos).addScaledVector(dir, 0.08 + i * 0.06);
      puff.scale.setScalar(weapon === 'sniper' ? 1.35 : 0.85);
      const pVel = dir
        .clone()
        .multiplyScalar(1.2 + Math.random() * 1.8)
        .add(new THREE.Vector3((Math.random() - 0.5) * 0.45, 0.55 + Math.random() * 0.5, (Math.random() - 0.5) * 0.45));
      this.worldScene.add(puff);
      this.particles.push({
        mesh: puff,
        vel: pVel,
        gravity: 0.65, // Warm gas rises gently!
        drag: 2.8,
        scaleRate: 2.6,
        life: 0,
        maxLife: 0.65 + Math.random() * 0.45,
        initialOpacity: smMat.opacity,
        mat: smMat,
      });
    }
  }

  /**
   * Ejects a 3D Brass Shell Casing + Chamber Smoke Puff from exact Ejection Port Anchor!
   */
  public ejectShellCasing(
    caliber: '9mm' | '556' | '338',
    ejectWorldPos: THREE.Vector3,
    cameraQuat: THREE.Quaternion,
    playerVelocity: THREE.Vector3
  ) {
    const casingGroup = this.buildCasingGeometry(caliber);
    casingGroup.position.copy(ejectWorldPos);
    casingGroup.quaternion.copy(cameraQuat);

    // Local ejection direction in camera/weapon space:
    // Pistol (9mm): Up and Right (2 o'clock)
    // Rifle (5.56): Crisp Right & slightly backward (3:30 o'clock)
    // Sniper (.338): Smooth heavy Right arc (3 o'clock) when bolt pulls back
    const localImpulse =
      caliber === '9mm'
        ? new THREE.Vector3(2.1 + Math.random() * 0.6, 2.35 + Math.random() * 0.55, 0.35 + Math.random() * 0.4)
        : caliber === '556'
        ? new THREE.Vector3(3.15 + Math.random() * 0.75, 1.45 + Math.random() * 0.45, 0.85 + Math.random() * 0.5)
        : new THREE.Vector3(2.45 + Math.random() * 0.5, 1.65 + Math.random() * 0.4, 0.55 + Math.random() * 0.35);

    const worldVel = localImpulse.applyQuaternion(cameraQuat).add(playerVelocity);

    this.worldScene.add(casingGroup);
    this.casings.push({
      group: casingGroup,
      vel: worldVel,
      rotVel: new THREE.Vector3(
        (Math.random() - 0.5) * 28,
        14 + Math.random() * 18,
        -18 - Math.random() * 16
      ),
      caliber,
      bounced: false,
      life: 0,
      maxLife: 4.5,
    });

    // Chamber Gas Puff escaping directly out of the Ejection Port!
    for (let i = 0; i < 2; i++) {
      const chMat = new THREE.MeshStandardMaterial({
        color: 0xcbd5e1,
        roughness: 0.95,
        transparent: true,
        opacity: 0.34,
        flatShading: true,
        depthWrite: false,
      });
      const puff = new THREE.Mesh(this.smokeGeo, chMat);
      puff.position.copy(ejectWorldPos);
      puff.scale.setScalar(0.65);
      const puffVel = new THREE.Vector3(0.9 + Math.random() * 0.5, 0.65 + Math.random() * 0.35, 0.1)
        .applyQuaternion(cameraQuat)
        .add(playerVelocity);
      this.worldScene.add(puff);
      this.particles.push({
        mesh: puff,
        vel: puffVel,
        gravity: 0.45,
        drag: 3.4,
        scaleRate: 2.1,
        life: 0,
        maxLife: 0.48 + Math.random() * 0.2,
        initialOpacity: 0.34,
        mat: chMat,
      });
    }
  }

  public dropEmptyMagazine(
    weapon: WeaponId,
    magWorldPos: THREE.Vector3,
    cameraQuat: THREE.Quaternion,
    playerVelocity: THREE.Vector3
  ) {
    const g = new THREE.Group();
    if (weapon === 'pistol') {
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.135, 0.048), MAT_DROPPED_MAG);
      const base = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.016, 0.056), MAT_DROPPED_MAG_BASE);
      base.position.y = -0.072;
      g.add(body, base);
    } else if (weapon === 'rifle') {
      const upper = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.095, 0.072), MAT_DROPPED_MAG);
      upper.rotation.x = -0.14;
      const lower = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.11, 0.072), MAT_DROPPED_MAG);
      lower.position.set(0, -0.088, -0.022);
      lower.rotation.x = -0.32;
      g.add(upper, lower);
    } else {
      const boxMag = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.105, 0.128), MAT_DROPPED_MAG);
      g.add(boxMag);
    }

    g.position.copy(magWorldPos);
    g.quaternion.copy(cameraQuat);

    // Tactical flick impulse downward and slightly left/forward
    const localFlick = new THREE.Vector3(
      -0.65 + (Math.random() - 0.5) * 0.35,
      -2.45 - Math.random() * 0.55,
      -0.85 + (Math.random() - 0.5) * 0.3
    );
    const worldVel = localFlick.applyQuaternion(cameraQuat).add(playerVelocity);

    this.worldScene.add(g);
    this.droppedMags.push({
      group: g,
      weapon,
      vel: worldVel,
      rotVel: new THREE.Vector3(
        5.5 + Math.random() * 5,
        (Math.random() - 0.5) * 6,
        -7.5 - Math.random() * 6
      ),
      bounced: false,
      life: 0,
      maxLife: 5.5,
    });
  }

  public spawnImpactEffect(
    hitPos: THREE.Vector3,
    hitNormal: THREE.Vector3,
    surface: 'stone' | 'wood' | 'metal' | 'headshot'
  ) {
    const count = surface === 'headshot' ? 14 : surface === 'metal' ? 10 : 7;
    for (let i = 0; i < count; i++) {
      const color =
        surface === 'headshot'
          ? i % 2 === 0
            ? 0xffd700
            : 0xff3b3b
          : surface === 'metal'
          ? 0xffb732
          : surface === 'wood'
          ? 0xb87a44
          : 0xcbd5e1;

      const mat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.95,
      });
      const mesh = new THREE.Mesh(
        surface === 'stone' ? this.smokeGeo : this.sparkGeo,
        mat
      );
      mesh.position.copy(hitPos).addScaledVector(hitNormal, 0.03);
      mesh.scale.setScalar(surface === 'headshot' ? 1.6 : 1.15);

      const rand = new THREE.Vector3(
        (Math.random() - 0.5) * 4.5,
        Math.random() * 3.8,
        (Math.random() - 0.5) * 4.5
      );
      const vel = hitNormal.clone().multiplyScalar(2.6 + Math.random() * 3.5).add(rand);

      this.worldScene.add(mesh);
      this.particles.push({
        mesh,
        vel,
        gravity: -11.5,
        drag: 2.2,
        scaleRate: surface === 'stone' ? 1.8 : -0.9,
        life: 0,
        maxLife: 0.35 + Math.random() * 0.25,
        initialOpacity: 0.95,
        mat,
      });
    }
  }

  public spawnExplosion(center: THREE.Vector3) {
    for (let i = 0; i < 24; i++) {
      const isFire = i < 14;
      const mat = new THREE.MeshBasicMaterial({
        color: isFire ? (i % 2 === 0 ? 0xff9e2c : 0xff3d1f) : 0x334155,
        transparent: true,
        opacity: 0.92,
      });
      const m = new THREE.Mesh(this.smokeGeo, mat);
      m.position.copy(center);
      m.scale.setScalar(isFire ? 3.2 : 4.2);
      const dir = new THREE.Vector3(
        Math.random() - 0.5,
        Math.random() * 0.9 + 0.15,
        Math.random() - 0.5
      )
        .normalize()
        .multiplyScalar(4 + Math.random() * 9);
      this.worldScene.add(m);
      this.particles.push({
        mesh: m,
        vel: dir,
        gravity: isFire ? -3.5 : 1.5,
        drag: 2.0,
        scaleRate: 3.4,
        life: 0,
        maxLife: 0.65 + Math.random() * 0.55,
        initialOpacity: 0.92,
        mat,
      });
    }
  }

  public update(dt: number) {
    // Update 3D Bullets
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      const step = b.vel.length() * dt;
      b.group.position.addScaledVector(b.vel, dt);
      b.group.rotateZ(dt * 38); // Rifling spin!
      b.distTraveled += step;
      b.life -= dt;
      if (b.distTraveled >= b.maxDist || b.life <= 0) {
        this.worldScene.remove(b.group);
        this.bullets.splice(i, 1);
      }
    }

    // Update Muzzle Flashes
    for (let i = this.muzzleFlashes.length - 1; i >= 0; i--) {
      const mf = this.muzzleFlashes[i];
      mf.life += dt;
      const t = mf.life / mf.maxLife;
      if (t >= 1) {
        this.worldScene.remove(mf.group, mf.light);
        this.muzzleFlashes.splice(i, 1);
      } else {
        const s = 1 + t * 0.45;
        mf.group.scale.setScalar(s);
        mf.light.intensity *= 1 - t * 0.65;
      }
    }

    // Update Shockwave Rings
    for (let i = this.shockRings.length - 1; i >= 0; i--) {
      const sr = this.shockRings[i];
      sr.life += dt;
      const t = sr.life / sr.maxLife;
      if (t >= 1) {
        this.worldScene.remove(sr.mesh);
        sr.mat.dispose();
        this.shockRings.splice(i, 1);
      } else {
        sr.mesh.scale.addScalar(sr.expandRate * dt);
        sr.mat.opacity = (1 - t) * 0.48;
      }
    }

    // Update 3D Brass Shell Casings with ground bounce physics!
    for (let i = this.casings.length - 1; i >= 0; i--) {
      const c = this.casings[i];
      c.life += dt;
      c.vel.y -= 13.8 * dt;
      c.group.position.addScaledVector(c.vel, dt);
      c.group.rotation.x += c.rotVel.x * dt;
      c.group.rotation.y += c.rotVel.y * dt;
      c.group.rotation.z += c.rotVel.z * dt;

      if (c.group.position.y <= 0.022) {
        c.group.position.y = 0.022;
        if (Math.abs(c.vel.y) > 0.65) {
          c.vel.y = -c.vel.y * 0.42;
          c.vel.x *= 0.65;
          c.vel.z *= 0.65;
          c.rotVel.multiplyScalar(0.55);
          if (!c.bounced) {
            c.bounced = true;
            soundEngine.playShellBounce(c.caliber);
          }
        } else {
          c.vel.set(0, 0, 0);
          c.rotVel.set(0, 0, 0);
          c.group.rotation.x = 0;
        }
      }

      if (c.life >= c.maxLife) {
        this.worldScene.remove(c.group);
        this.casings.splice(i, 1);
      }
    }

    // Update 3D Dropped Empty Magazines with spin & realistic ground clatter!
    for (let i = this.droppedMags.length - 1; i >= 0; i--) {
      const dm = this.droppedMags[i];
      dm.life += dt;
      dm.vel.y -= 14.5 * dt;
      dm.group.position.addScaledVector(dm.vel, dt);
      dm.group.rotation.x += dm.rotVel.x * dt;
      dm.group.rotation.y += dm.rotVel.y * dt;
      dm.group.rotation.z += dm.rotVel.z * dt;

      if (dm.group.position.y <= 0.032) {
        dm.group.position.y = 0.032;
        if (Math.abs(dm.vel.y) > 0.7) {
          dm.vel.y = -dm.vel.y * 0.32;
          dm.vel.x *= 0.58;
          dm.vel.z *= 0.58;
          dm.rotVel.multiplyScalar(0.45);
          if (!dm.bounced) {
            dm.bounced = true;
            soundEngine.playReloadSound(dm.weapon, 'magDrop');
          }
        } else {
          dm.vel.set(0, 0, 0);
          dm.rotVel.set(0, 0, 0);
          dm.group.rotation.z = Math.PI * 0.5;
        }
      }

      if (dm.life >= dm.maxLife) {
        this.worldScene.remove(dm.group);
        this.droppedMags.splice(i, 1);
      }
    }

    // Update Sparks & Smoke Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      const t = p.life / p.maxLife;
      if (t >= 1) {
        this.worldScene.remove(p.mesh);
        p.mat.dispose();
        this.particles.splice(i, 1);
        continue;
      }
      p.vel.y += p.gravity * dt;
      p.vel.multiplyScalar(Math.max(0, 1 - p.drag * dt));
      p.mesh.position.addScaledVector(p.vel, dt);
      const nextScale = Math.max(0.05, p.mesh.scale.x + p.scaleRate * dt);
      p.mesh.scale.setScalar(nextScale);
      p.mat.opacity = p.initialOpacity * (1 - t);
    }
  }

  public dispose() {
    this.smokeGeo.dispose();
    this.sparkGeo.dispose();
  }
}
