import { useCallback, useRef, useState } from 'react';
import { GameCanvas, GameCanvasHandle } from './components/GameCanvas';
import { HUD } from './components/HUD';
import {
  DamagePopup,
  HudSnapshot,
  ShotLogEntry,
  WEAPON_SPECS,
  WeaponId,
} from './game/types';
import { soundEngine } from './game/soundEngine';

const INITIAL_HUD: HudSnapshot = {
  weaponId: 'pistol',
  ammo: {
    pistol: WEAPON_SPECS.pistol.magSize,
    rifle: WEAPON_SPECS.rifle.magSize,
    sniper: WEAPON_SPECS.sniper.magSize,
  },
  reserve: {
    pistol: WEAPON_SPECS.pistol.reserveMax,
    rifle: WEAPON_SPECS.rifle.reserveMax,
    sniper: WEAPON_SPECS.sniper.reserveMax,
  },
  fireMode: 'SEMI',
  poseMode: 'READY',
  reloadProgress: 0,
  reloadStageLabel: '',
  boltProgress: 0,
  isAds: false,
  isSniperScoped: false,
  isSprinting: false,
  isCrouching: false,
  bodycamMode: true,
  slowMo: false,
  showCallouts: true,
  gameMode: 'COMBAT',
  pointerLocked: false,
  health: 100,
  maxHealth: 100,
  armor: 50,
  score: 0,
  kills: 0,
  shotsFired: 0,
  shotsHit: 0,
  headshots: 0,
  wave: 1,
  enemiesAlive: 5,
  anchors: {
    muzzle: { x: 0, y: 0, visible: false },
    ejection: { x: 0, y: 0, visible: false },
    mechanism: { x: 0, y: 0, visible: false },
    magazine: { x: 0, y: 0, visible: false },
  },
  lastShotPulse: 0,
  lastEjectPulse: 0,
  hitmarkerType: 'none',
  hitmarkerTime: 0,
};

export function App() {
  const canvasRef = useRef<GameCanvasHandle | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [shotLogs, setShotLogs] = useState<ShotLogEntry[]>([]);
  const [damagePopups, setDamagePopups] = useState<DamagePopup[]>([]);
  const [muted, setMuted] = useState(false);

  const handleHudUpdate = useCallback((next: HudSnapshot) => {
    setHud(next);
  }, []);

  const handleShotLog = useCallback((entry: ShotLogEntry) => {
    setShotLogs((prev) => [entry, ...prev.slice(0, 4)]);
  }, []);

  const handleDamagePopup = useCallback((popup: DamagePopup) => {
    setDamagePopups((prev) => [...prev.slice(-8), popup]);
    setTimeout(() => {
      setDamagePopups((prev) => prev.filter((p) => p.id !== popup.id));
    }, 850);
  }, []);

  const handleToggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      soundEngine.muted = next;
      return next;
    });
  }, []);

  const handleSelectWeapon = useCallback((id: WeaponId) => {
    canvasRef.current?.selectWeapon(id);
  }, []);

  const handleToggleGameMode = useCallback(() => {
    canvasRef.current?.setGameMode(hud.gameMode === 'COMBAT' ? 'RANGE' : 'COMBAT');
  }, [hud.gameMode]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-slate-950">
      <GameCanvas
        ref={canvasRef}
        onHudUpdate={handleHudUpdate}
        onShotLog={handleShotLog}
        onDamagePopup={handleDamagePopup}
      />

      <HUD
        hud={hud}
        shotLogs={shotLogs}
        damagePopups={damagePopups}
        muted={muted}
        onToggleMute={handleToggleMute}
        onSelectWeapon={handleSelectWeapon}
        onTriggerReload={() => canvasRef.current?.triggerReload()}
        onTriggerSimShot={() => canvasRef.current?.triggerSimShot()}
        onTogglePose1={() => canvasRef.current?.toggleInspectPose1()}
        onToggleBodycam={() => canvasRef.current?.toggleBodycamMode()}
        onToggleSlowMo={() => canvasRef.current?.toggleSlowMo()}
        onToggleCallouts={() => canvasRef.current?.toggleCallouts()}
        onToggleGameMode={handleToggleGameMode}
        onCycleFireMode={() => canvasRef.current?.cycleFireMode()}
        onEnterPointerLock={() => canvasRef.current?.requestPointerLock()}
      />
    </main>
  );
}

export default App;
