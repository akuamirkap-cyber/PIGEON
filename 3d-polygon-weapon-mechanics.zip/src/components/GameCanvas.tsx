import { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import * as THREE from 'three';
import {
  DamagePopup,
  FireMode,
  GameMode,
  HudSnapshot,
  ShotLogEntry,
  WEAPON_SPECS,
  WeaponAnchors2D,
  WeaponId,
  WeaponPoseMode,
} from '../game/types';
import {
  BuiltWeaponRig,
  buildPistolRig,
  buildRifleRig,
  buildSniperRig,
} from '../game/weaponModels';
import { BallisticsSystem } from '../game/ballisticsSystem';
import { buildStylizedWorld, ShootableEntity } from '../game/worldBuilder';
import { soundEngine } from '../game/soundEngine';

export interface GameCanvasHandle {
  selectWeapon: (id: WeaponId) => void;
  triggerReload: () => void;
  triggerSimShot: () => void;
  toggleInspectPose1: () => void;
  toggleBodycamMode: () => void;
  toggleCrouch: () => void;
  toggleSlowMo: () => void;
  toggleCallouts: () => void;
  setGameMode: (mode: GameMode) => void;
  cycleFireMode: () => void;
  requestPointerLock: () => void;
}

interface GameCanvasProps {
  onHudUpdate: (hud: HudSnapshot) => void;
  onShotLog: (entry: ShotLogEntry) => void;
  onDamagePopup: (popup: DamagePopup) => void;
}

interface PoseTransform {
  pos: THREE.Vector3;
  rot: THREE.Euler;
}

// Calibrated exact camera-space poses matching Reference Image 2 (READY) & Reference Image 1 (RELOAD / INSPECT)
const POSE_READY_GAMBAR_2: Record<WeaponId, PoseTransform> = {
  // Gambar 2 Left: Symmetrical centered two-hand classic pistol converging straight into crosshair!
  pistol: {
    pos: new THREE.Vector3(0.0, -0.092, -0.44),
    rot: new THREE.Euler(0.02, 0.0, 0.0),
  },
  // Gambar 2 Center: Centered M4A1 looking straight along stock, T-charging handle & rail right through green Holo window!
  rifle: {
    pos: new THREE.Vector3(0.0, -0.102, -0.34),
    rot: new THREE.Euler(0.0, 0.0, 0.0),
  },
  // Gambar 2 Right: Barrett M82A1 shoulder stance showing compact scope, slotted shroud & live magnifying lens!
  sniper: {
    pos: new THREE.Vector3(0.112, -0.122, -0.47),
    rot: new THREE.Euler(0.054, 0.112, 0.02),
  },
};

const POSE_ADS_PRECISION: Record<WeaponId, PoseTransform> = {
  pistol: {
    pos: new THREE.Vector3(0.0, -0.056, -0.34),
    rot: new THREE.Euler(0.0, 0.0, 0.0),
  },
  rifle: {
    // Aligns eye dead-center through the glowing green Holographic Sight window!
    pos: new THREE.Vector3(0.0, -0.102, -0.24),
    rot: new THREE.Euler(0.0, 0.0, 0.0),
  },
  sniper: {
    // Aligns eye directly into the compact Barrett Scope's Crystal-Clear Magnifying Lens (y=0.094, z=0.117)!
    pos: new THREE.Vector3(0.0, -0.094, -0.172),
    rot: new THREE.Euler(0.0, 0.0, 0.0),
  },
};

const POSE_RELOAD_GAMBAR_1: Record<WeaponId, PoseTransform> = {
  pistol: {
    pos: new THREE.Vector3(-0.02, -0.112, -0.45),
    rot: new THREE.Euler(0.25, 0.18, -0.085),
  },
  rifle: {
    pos: new THREE.Vector3(0.045, -0.155, -0.52),
    rot: new THREE.Euler(0.56, 0.51, -0.33),
  },
  // Showcases the Barrett M82A1 Slanted Box Mag, Folded Bipod, Slotted Shroud & Compact Scope clearly!
  sniper: {
    pos: new THREE.Vector3(0.085, -0.105, -0.53),
    rot: new THREE.Euler(0.42, 0.48, -0.3),
  },
};

// Pro-Operator Disciplined Tactical Sprint Poses (Composed, tucked, rock-steady Tier-1 control!)
const POSE_TACTICAL_SPRINT: Record<WeaponId, PoseTransform> = {
  pistol: {
    pos: new THREE.Vector3(-0.042, -0.072, -0.385),
    rot: new THREE.Euler(0.68, 0.22, -0.26),
  },
  rifle: {
    pos: new THREE.Vector3(-0.032, -0.142, -0.415),
    rot: new THREE.Euler(0.24, 0.72, -0.38),
  },
  sniper: {
    pos: new THREE.Vector3(0.018, -0.148, -0.465),
    rot: new THREE.Euler(0.32, 0.62, -0.3),
  },
};

export const GameCanvas = forwardRef<GameCanvasHandle, GameCanvasProps>(
  ({ onHudUpdate, onShotLog, onDamagePopup }, ref) => {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const controlsApiRef = useRef<GameCanvasHandle | null>(null);

    useImperativeHandle(ref, () => ({
      selectWeapon: (id) => controlsApiRef.current?.selectWeapon(id),
      triggerReload: () => controlsApiRef.current?.triggerReload(),
      triggerSimShot: () => controlsApiRef.current?.triggerSimShot(),
      toggleInspectPose1: () => controlsApiRef.current?.toggleInspectPose1(),
      toggleBodycamMode: () => controlsApiRef.current?.toggleBodycamMode(),
      toggleCrouch: () => controlsApiRef.current?.toggleCrouch(),
      toggleSlowMo: () => controlsApiRef.current?.toggleSlowMo(),
      toggleCallouts: () => controlsApiRef.current?.toggleCallouts(),
      setGameMode: (m) => controlsApiRef.current?.setGameMode(m),
      cycleFireMode: () => controlsApiRef.current?.cycleFireMode(),
      requestPointerLock: () => controlsApiRef.current?.requestPointerLock(),
    }));

    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;

      // Renderer setup (manual clear for dual-pass World + Viewmodel rendering)
      const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(container.clientWidth, container.clientHeight);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.06;
      renderer.autoClear = false;
      container.appendChild(renderer.domElement);

      // Build Stylized World (Urban Courtyard + Alpine Valley + Bots + Targets)
      const world = buildStylizedWorld();
      const ballistics = new BallisticsSystem(world.scene);

      const aspect = container.clientWidth / container.clientHeight;
      const worldCamera = new THREE.PerspectiveCamera(68, aspect, 0.1, 260);
      const vmCamera = new THREE.PerspectiveCamera(62, aspect, 0.02, 10);

      // Dedicated Viewmodel Scene + Camera-Relative 3-Point Studio Lighting so white polygon hand facets look crisp 360°!
      const vmScene = new THREE.Scene();
      const vmHemi = new THREE.HemisphereLight(0xebf6ff, 0x9aa988, 1.05);
      vmScene.add(vmHemi);

      const vmCameraRig = new THREE.Group();
      vmScene.add(vmCameraRig);

      const vmLightTarget = new THREE.Object3D();
      vmLightTarget.position.set(0, -0.12, -0.42);
      vmCameraRig.add(vmLightTarget);

      const vmSunKey = new THREE.DirectionalLight(0xfffaf0, 1.48);
      vmSunKey.position.set(1.6, 3.2, 2.1);
      vmSunKey.target = vmLightTarget;
      vmCameraRig.add(vmSunKey);

      const vmSkyFill = new THREE.DirectionalLight(0xd2e8ff, 0.62);
      vmSkyFill.position.set(-2.2, 1.5, 1.6);
      vmSkyFill.target = vmLightTarget;
      vmCameraRig.add(vmSkyFill);

      const vmRimLight = new THREE.DirectionalLight(0xffffff, 0.35);
      vmRimLight.position.set(0.0, 2.0, -2.5);
      vmRimLight.target = vmLightTarget;
      vmCameraRig.add(vmRimLight);

      // High-Definition 1024x1024 4x-MSAA Magnifying Scope Render Target & 4.7x Optical Camera (Zero Jitter!)
      const scopeRenderTarget = new THREE.WebGLRenderTarget(1024, 1024, {
        minFilter: THREE.LinearFilter,
        magFilter: THREE.LinearFilter,
        depthBuffer: true,
        samples: 4,
      });
      const scopeMagnifierCamera = new THREE.PerspectiveCamera(14.5, 1.0, 0.2, 260);

      // Build all 3 Sculpted Polygon Weapon + White Hand Rigs
      const rigs: Record<WeaponId, BuiltWeaponRig> = {
        pistol: buildPistolRig(),
        rifle: buildRifleRig(),
        sniper: buildSniperRig(scopeRenderTarget.texture),
      };
      (Object.keys(rigs) as WeaponId[]).forEach((k) => {
        vmCameraRig.add(rigs[k].root);
        rigs[k].root.visible = k === 'pistol';
      });

      // Player Physics (3D Box-Landing Feet + Toggle Crouch + Smooth Bodycam + Sprint Spring)
      let playerFeetY = 0;
      let standingOnWood = false;
      const playerPos = new THREE.Vector3(-3.2, 1.7, 1.8);
      const playerVel = new THREE.Vector3();
      let targetYaw = -0.05;
      let targetPitch = 0.01;
      let smoothYaw = -0.05;
      let smoothPitch = 0.01;
      let smoothRollZ = 0;
      let smoothEyeHeight = 1.7;
      let crouchToggle = false;
      let crouchAlpha = 0;
      let landingDipY = 0;
      let landingDipVel = 0;
      let recoilCameraPitch = 0;
      let recoilCameraYaw = 0;
      let onGround = true;
      let wasOnGround = true;
      let stridePhase = 0;
      let lastFootstepIdx = 0;
      let smoothCamBobX = 0;
      let smoothCamBobY = 0;
      let smoothCamPitch = 0;
      let sprintAlpha = 0;
      let sprintSpringVal = 0;
      let sprintSpringVel = 0;
      let wasSprinting = false;
      let sprintFireSuppressTimer = 0;
      let bodycamMode = true;
      const bodycamFreeAimRot = new THREE.Vector3();
      const bodycamFreeAimPos = new THREE.Vector3();

      // Weapon & Simulation State
      let currentWeapon: WeaponId = 'pistol';
      const ammo: Record<WeaponId, number> = {
        pistol: WEAPON_SPECS.pistol.magSize,
        rifle: WEAPON_SPECS.rifle.magSize,
        sniper: WEAPON_SPECS.sniper.magSize,
      };
      const reserve: Record<WeaponId, number> = {
        pistol: WEAPON_SPECS.pistol.reserveMax,
        rifle: WEAPON_SPECS.rifle.reserveMax,
        sniper: WEAPON_SPECS.sniper.reserveMax,
      };
      const weaponFireModes: Record<WeaponId, FireMode> = {
        pistol: 'SEMI',
        rifle: 'AUTO',
        sniper: 'BOLT',
      };

      let poseMode: WeaponPoseMode = 'READY';
      let inspectPose1Toggle = false;
      let reloadTimer = 0;
      let reloadWasEmpty = false;
      let activeReloadDuration = 1.3;
      let reloadStageSoundMask = 0;
      let boltTimer = 0;
      let boltSoundMask = 0;
      let sniperCasingEjectedThisCycle = false;

      let fireCooldown = 0;
      let burstRemaining = 0;
      let burstTimer = 0;
      let isMouseDown = false;
      let semiLocked = false;
      let isAds = false;
      let adsAlpha = 0;
      let equipProgress = 1; // 0 -> 1 smooth draw when switching weapons

      // Spring-damper weapon recoil & mechanical blowback state
      const recoilOffset = new THREE.Vector3();
      const recoilVel = new THREE.Vector3();
      const recoilRot = new THREE.Vector3(); // x=pitch, y=yaw, z=roll
      const recoilRotVel = new THREE.Vector3();
      const swayOffset = new THREE.Vector2();
      let slideBlowback = 0; // 0..1 instantaneous blowback for Pistol/Rifle
      let triggerPull = 0;

      // Modes & Stats
      let slowMo = false;
      let showCallouts = true;
      let gameMode: GameMode = 'COMBAT';
      let pointerLocked = false;
      let health = 100;
      const maxHealth = 100;
      let armor = 50;
      let score = 0;
      let kills = 0;
      let shotsFired = 0;
      let shotsHit = 0;
      let headshots = 0;
      let wave = 1;
      let waveClearCooldown = 0;
      let lastShotPulse = 0;
      let lastEjectPulse = 0;
      let hitmarkerType: 'none' | 'body' | 'head' = 'none';
      let hitmarkerTime = 0;
      let shotIdCounter = 1;
      let popupIdCounter = 1;

      const keys: Record<string, boolean> = {};
      const raycaster = new THREE.Raycaster();

      // Convert a 3D Object3D inside vmScene to:
      // 1. Exact 2D screen pixel coords (for live simulation callout markers)
      // 2. Exact 3D world-space position aligned with worldCamera view ray (zero parallax mismatch!)
      const projectVmAnchor = (
        anchor: THREE.Object3D
      ): { screen: { x: number; y: number; visible: boolean }; worldPos: THREE.Vector3 } => {
        const vmWorldPos = new THREE.Vector3();
        anchor.getWorldPosition(vmWorldPos);

        const relToVmCam = vmWorldPos.clone().sub(vmCamera.position);
        const dist = Math.max(0.12, relToVmCam.length());

        const ndc = vmWorldPos.clone().project(vmCamera);
        const w = container.clientWidth;
        const h = container.clientHeight;
        const sx = (ndc.x * 0.5 + 0.5) * w;
        const sy = (-ndc.y * 0.5 + 0.5) * h;
        const visible = ndc.z >= -1 && ndc.z <= 1 && sx >= -60 && sx <= w + 60 && sy >= -60 && sy <= h + 60;

        // Unproject NDC into worldCamera at exact metric depth `dist`
        const unproj = new THREE.Vector3(ndc.x, ndc.y, 0.5).unproject(worldCamera);
        const worldRayDir = unproj.sub(worldCamera.position).normalize();
        const alignedWorldPos = worldCamera.position.clone().addScaledVector(worldRayDir, dist);

        return {
          screen: { x: sx, y: sy, visible },
          worldPos: alignedWorldPos,
        };
      };

      const switchWeapon = (next: WeaponId) => {
        if (next === currentWeapon && poseMode !== 'INSPECT_POSE_1') return;
        currentWeapon = next;
        (Object.keys(rigs) as WeaponId[]).forEach((k) => {
          rigs[k].root.visible = k === next;
        });
        // Cancel reload/bolt cycle on switch
        reloadTimer = 0;
        boltTimer = 0;
        burstRemaining = 0;
        poseMode = inspectPose1Toggle ? 'INSPECT_POSE_1' : 'READY';
        equipProgress = 0;
        slideBlowback = next === 'pistol' && ammo.pistol === 0 ? 0.92 : 0;
        // Crisp draw momentum impulse + realistic weapon draw Foley
        recoilVel.y += 0.55;
        recoilRotVel.x -= 1.15;
        recoilRotVel.z += 0.85;
        soundEngine.playWeaponSwitch(next);
      };

      const startReload = () => {
        const spec = WEAPON_SPECS[currentWeapon];
        if (poseMode === 'RELOADING') return;
        if (ammo[currentWeapon] >= spec.magSize) return;
        if (reserve[currentWeapon] <= 0 && gameMode === 'COMBAT') {
          // Top up emergency reserve so player never gets stuck!
          reserve[currentWeapon] = spec.magSize * 2;
        }
        inspectPose1Toggle = false;
        isAds = false;
        burstRemaining = 0;
        boltTimer = 0;
        reloadWasEmpty = ammo[currentWeapon] === 0;
        activeReloadDuration = reloadWasEmpty
          ? spec.reloadDuration
          : spec.tacticalReloadDuration;
        poseMode = 'RELOADING';
        reloadTimer = 0;
        reloadStageSoundMask = 0;

        // Immediate aggressive whip-snap momentum into Sudut Gambar 1 + tactical cloth/grip sound!
        recoilVel.y += 0.42;
        recoilVel.x += 0.18;
        recoilRotVel.x += 1.65;
        recoilRotVel.z -= 2.45;
        recoilCameraPitch += 0.008;
        soundEngine.playReloadSound(currentWeapon, 'grabTilt', slowMo);
      };

      const applyDamageToEntity = (
        ent: ShootableEntity,
        dmg: number,
        isHead: boolean,
        hitPoint: THREE.Vector3
      ): string => {
        if (!ent.alive) return '';
        ent.hp -= dmg;
        ent.flinchTimer = 0.12;
        shotsHit++;
        if (isHead) headshots++;

        hitmarkerType = isHead ? 'head' : 'body';
        hitmarkerTime = performance.now();
        soundEngine.playHitmarker(isHead);

        // Project hitPoint to 2D for floating damage number
        const hitNdc = hitPoint.clone().project(worldCamera);
        if (hitNdc.z < 1) {
          onDamagePopup({
            id: popupIdCounter++,
            x: (hitNdc.x * 0.5 + 0.5) * container.clientWidth,
            y: (-hitNdc.y * 0.5 + 0.5) * container.clientHeight,
            damage: Math.round(dmg),
            isHeadshot: isHead,
            distanceM: Math.round(worldCamera.position.distanceTo(hitPoint)),
          });
        }

        if (ent.hp <= 0) {
          ent.alive = false;
          if (ent.kind === 'barrel') {
            ent.root.visible = false;
            ent.respawnTimer = 8.0;
            ballistics.spawnExplosion(ent.root.position.clone().add(new THREE.Vector3(0, 0.7, 0)));
            soundEngine.playExplosion();
            score += 150;
            // Splash damage to nearby bots!
            for (const other of world.entities) {
              if (other.alive && other.kind === 'bot') {
                const dist = other.root.position.distanceTo(ent.root.position);
                if (dist < 6.5) {
                  other.hp -= 120;
                  if (other.hp <= 0) {
                    other.alive = false;
                    other.respawnTimer = 1.4;
                    kills++;
                    score += 200;
                  }
                }
              }
            }
            return 'BAREL MELEDAK!';
          } else if (ent.kind === 'target') {
            ent.respawnTimer = 2.2;
            score += isHead ? 120 : 60;
            return isHead
              ? `BULLSEYE KRITIS (${ent.distanceLabel ?? 25}m)`
              : `PLAT TARGET JATUH (${ent.distanceLabel ?? 25}m)`;
          } else if (ent.kind === 'bot') {
            ent.respawnTimer = 1.3;
            kills++;
            score += isHead ? 250 : 125;
            return isHead ? 'ELIMINASI HEADSHOT!' : 'BOT TERELIMINASI';
          }
        }

        return isHead ? `HEADSHOT! -${Math.round(dmg)}` : `KENA TARGET -${Math.round(dmg)}`;
      };

      const fireSingleRound = () => {
        const spec = WEAPON_SPECS[currentWeapon];
        if (poseMode === 'RELOADING' || poseMode === 'BOLT_CYCLE') return;

        // Instant Sprint-to-Fire & Inspect-to-Fire transition!
        sprintFireSuppressTimer = 0.36;
        if (poseMode === 'INSPECT_POSE_1' || poseMode === 'SPRINTING') {
          inspectPose1Toggle = false;
          poseMode = 'READY';
        }

        if (ammo[currentWeapon] <= 0) {
          soundEngine.playDryFire();
          startReload();
          return;
        }

        ammo[currentWeapon]--;
        shotsFired++;
        fireCooldown = 60 / spec.rpm;
        lastShotPulse = performance.now();

        soundEngine.playGunshot(currentWeapon, slowMo, ammo[currentWeapon] === 0);

        // Mechanical slide/bolt impulse & recoil spring impulse
        triggerPull = 1.0;
        if (currentWeapon !== 'sniper') {
          slideBlowback = 1.0;
        }

        const adsFactor = (isAds ? 0.62 : 1.0) * (1 - crouchAlpha * 0.28);
        recoilVel.z += spec.recoilKickZ * 16.5 * adsFactor;
        recoilVel.y += spec.recoilPitchUp * 1.4 * adsFactor;
        recoilRotVel.x += spec.recoilPitchUp * 19.0 * adsFactor;
        recoilRotVel.y += (Math.random() - 0.5) * spec.recoilYawJitter * 28.0;
        recoilRotVel.z += (Math.random() - 0.5) * 2.2;

        // Camera kick
        recoilCameraPitch += spec.recoilPitchUp * 0.24 * adsFactor;
        recoilCameraYaw += (Math.random() - 0.5) * spec.recoilYawJitter * 0.45;

        // Update matrices before reading exact 3D muzzle & ejection anchors!
        vmScene.updateMatrixWorld(true);
        const rig = rigs[currentWeapon];
        const muzzleProj = projectVmAnchor(rig.muzzleAnchor);
        const ejectProj = projectVmAnchor(rig.ejectionAnchor);

        // Raycast straight from exact screen crosshair center (with crisp weapon bloom)
        const spread = isAds ? (currentWeapon === 'sniper' ? 0.0002 : 0.0025) : 0.0085;
        const aimNdc = new THREE.Vector2(
          (Math.random() - 0.5) * spread,
          (Math.random() - 0.5) * spread
        );
        raycaster.setFromCamera(aimNdc, worldCamera);

        // Gather shootable meshes + static world meshes
        const testObjects: THREE.Object3D[] = [];
        for (const ent of world.entities) {
          if (!ent.alive || !ent.root.visible) continue;
          testObjects.push(ent.root);
        }
        for (const st of world.staticHitMeshes) {
          testObjects.push(st.mesh);
        }

        const hits = raycaster.intersectObjects(testObjects, true);
        let targetWorldPoint = raycaster.ray.origin
          .clone()
          .addScaledVector(raycaster.ray.direction, 120);
        let hitSummary = '';
        let wasHeadshot = false;

        if (hits.length > 0) {
          const firstHit = hits[0];
          targetWorldPoint = firstHit.point.clone();
          const hitNormal = firstHit.face
            ? firstHit.face.normal.clone().transformDirection(firstHit.object.matrixWorld)
            : new THREE.Vector3(0, 1, 0);

          // Check if we hit a ShootableEntity (bot / steel target / barrel)
          let node: THREE.Object3D | null = firstHit.object;
          let foundEntity: ShootableEntity | null = null;
          let isHead = false;
          while (node) {
            if (node.userData && node.userData.entity) {
              foundEntity = node.userData.entity as ShootableEntity;
              isHead = Boolean(node.userData.isHead);
              break;
            }
            node = node.parent;
          }

          if (foundEntity && foundEntity.alive) {
            const finalDmg = spec.damage * (isHead ? spec.headshotMult : 1.0);
            wasHeadshot = isHead;
            hitSummary = applyDamageToEntity(foundEntity, finalDmg, isHead, targetWorldPoint);
            ballistics.spawnImpactEffect(
              targetWorldPoint,
              hitNormal,
              isHead ? 'headshot' : 'metal'
            );
          } else {
            // Static surface impact
            const matchedStatic = world.staticHitMeshes.find(
              (s) => s.mesh === firstHit.object || firstHit.object.parent === s.mesh
            );
            ballistics.spawnImpactEffect(
              targetWorldPoint,
              hitNormal,
              matchedStatic ? matchedStatic.surface : 'stone'
            );
          }
        }

        // Spawn 3D Bullet + Tracer + Muzzle Flash + Sparks + Barrel Smoke from exact Muzzle Anchor!
        ballistics.fireFromMuzzle(
          currentWeapon,
          muzzleProj.worldPos,
          targetWorldPoint,
          worldCamera.quaternion
        );

        // Eject 3D Brass Casing immediately for Semi/Auto Pistol & Rifle!
        // For Bolt-Action Sniper, the .338 casing stays locked in the chamber until Bolt Pull-Back!
        if (currentWeapon !== 'sniper') {
          ballistics.ejectShellCasing(
            spec.casingType,
            ejectProj.worldPos,
            worldCamera.quaternion,
            playerVel
          );
          lastEjectPulse = performance.now();
        } else if (ammo.sniper > 0) {
          // Schedule Sniper Bolt-Action Re-chambering Cycle!
          poseMode = 'BOLT_CYCLE';
          boltTimer = 0;
          boltSoundMask = 0;
          sniperCasingEjectedThisCycle = false;
        }

        // Emit live Shot Simulation Telemetry entry!
        onShotLog({
          id: shotIdCounter++,
          weaponId: currentWeapon,
          weaponLabel: spec.label,
          caliber: spec.caliber,
          muzzleEvent:
            currentWeapon === 'pistol'
              ? 'Peluru 9mm + Api Moncong Bintang + Asap Laras keluar dari Ujung Barrel'
              : currentWeapon === 'rifle'
              ? 'Peluru 5.56mm + Api Birdcage 4-Arah + Gas Propelan keluar dari Flash Hider'
              : 'Proyektil .338 + Gelombang Kejut + Semburan Muzzle Brake Raksasa!',
          casingEvent:
            currentWeapon === 'pistol'
              ? 'Selongsong 9mm terlempar ke KANAN-ATAS dari celah barrel tembaga'
              : currentWeapon === 'rifle'
              ? 'Selongsong 5.56mm terlempar ke KANAN dari port ejeksi receiver'
              : ammo.sniper > 0
              ? 'Menunggu tarik tuas Bolt-Action -> Selongsong .338 akan keluar!'
              : 'Peluru terakhir ditembakkan -> Tekan [R] untuk Isi Ammo!',
          mechEvent:
            currentWeapon === 'pistol'
              ? ammo.pistol === 0
                ? 'Slide Blowback & TERKUNCI TERBUKA (Slide Lock — Magazen Habis!)'
                : 'Slide mundur 65mm (Blowback) & mengokang peluru berikutnya'
              : currentWeapon === 'rifle'
              ? 'Bolt Carrier bergerak resiprokal cepat di sisi kanan receiver'
              : 'Recoil berat .338 -> Tangan kanan bersiap memutar tuas Bolt 65°',
          hitText: hitSummary || undefined,
          isHeadshot: wasHeadshot,
          timestamp: Date.now(),
        });
      };

      // Input Listeners
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.repeat) return;
        const code = e.code;
        keys[code] = true;
        soundEngine.unlock();

        if (code === 'Digit1') switchWeapon('pistol');
        else if (code === 'Digit2') switchWeapon('rifle');
        else if (code === 'Digit3') switchWeapon('sniper');
        else if (code === 'KeyR') startReload();
        else if (code === 'KeyZ') {
          slowMo = !slowMo;
        } else if (code === 'KeyT') {
          showCallouts = !showCallouts;
        } else if (code === 'KeyF') {
          if (poseMode !== 'RELOADING' && poseMode !== 'BOLT_CYCLE') {
            inspectPose1Toggle = !inspectPose1Toggle;
            poseMode = inspectPose1Toggle ? 'INSPECT_POSE_1' : 'READY';
            if (inspectPose1Toggle) isAds = false;
          }
        } else if (code === 'KeyC') {
          crouchToggle = !crouchToggle;
          soundEngine.playCrouchToggle(crouchToggle);
          recoilVel.y += crouchToggle ? -0.28 : 0.26;
          recoilRotVel.z += crouchToggle ? -0.65 : 0.65;
        } else if (code === 'KeyV') {
          bodycamMode = !bodycamMode;
        } else if (code === 'KeyB') {
          controlsApiRef.current?.cycleFireMode();
        } else if (code === 'KeyM') {
          const nextMode: GameMode = gameMode === 'COMBAT' ? 'RANGE' : 'COMBAT';
          controlsApiRef.current?.setGameMode(nextMode);
        } else if (code === 'Space' && onGround) {
          // Uncrouch automatically on jump so full jump height clears 1.5m+ wooden crates!
          if (crouchToggle) crouchToggle = false;
          playerVel.y = 7.75;
          onGround = false;
          recoilVel.y -= 0.48;
          recoilRotVel.x += 1.05;
          soundEngine.playJumpLand(false, standingOnWood);
        }
      };

      const handleKeyUp = (e: KeyboardEvent) => {
        keys[e.code] = false;
      };

      const handleMouseMove = (e: MouseEvent) => {
        if (!pointerLocked) return;
        const sens = isAds && currentWeapon === 'sniper' ? 0.00075 : isAds ? 0.0014 : 0.0021;
        targetYaw -= e.movementX * sens;
        targetPitch -= e.movementY * sens;
        targetPitch = Math.max(-1.38, Math.min(1.38, targetPitch));

        swayOffset.x = THREE.MathUtils.clamp(swayOffset.x - e.movementX * 0.00028, -0.022, 0.022);
        swayOffset.y = THREE.MathUtils.clamp(swayOffset.y + e.movementY * 0.00028, -0.022, 0.022);
      };

      const handleMouseDown = (e: MouseEvent) => {
        // Ignore clicks on overlay UI buttons
        if ((e.target as HTMLElement)?.closest('[data-ui-interactive="true"]')) return;
        soundEngine.unlock();

        if (!pointerLocked) {
          renderer.domElement.requestPointerLock?.();
          return;
        }

        if (e.button === 0) {
          isMouseDown = true;
          semiLocked = false;
          sprintFireSuppressTimer = 0.36;
          const fm = weaponFireModes[currentWeapon];
          if (fm === 'BURST' && burstRemaining === 0 && fireCooldown <= 0) {
            burstRemaining = 3;
            burstTimer = 0;
          }
        } else if (e.button === 2) {
          if (poseMode === 'READY' || poseMode === 'SPRINTING' || poseMode === 'INSPECT_POSE_1') {
            inspectPose1Toggle = false;
            poseMode = 'READY';
            isAds = true;
          }
        }
      };

      const handleMouseUp = (e: MouseEvent) => {
        if (e.button === 0) {
          isMouseDown = false;
          semiLocked = false;
        } else if (e.button === 2) {
          isAds = false;
        }
      };

      const handleWheel = (e: WheelEvent) => {
        const order: WeaponId[] = ['pistol', 'rifle', 'sniper'];
        const idx = order.indexOf(currentWeapon);
        const nextIdx = (idx + (e.deltaY > 0 ? 1 : -1) + order.length) % order.length;
        switchWeapon(order[nextIdx]);
      };

      const handleContextMenu = (e: MouseEvent) => e.preventDefault();

      const handlePointerLockChange = () => {
        pointerLocked = document.pointerLockElement === renderer.domElement;
        if (!pointerLocked) {
          isMouseDown = false;
          isAds = false;
        }
      };

      const handleResize = () => {
        if (!container) return;
        const w = container.clientWidth;
        const h = container.clientHeight;
        renderer.setSize(w, h);
        worldCamera.aspect = w / h;
        worldCamera.updateProjectionMatrix();
        vmCamera.aspect = w / h;
        vmCamera.updateProjectionMatrix();
      };

      window.addEventListener('keydown', handleKeyDown);
      window.addEventListener('keyup', handleKeyUp);
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mousedown', handleMouseDown);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('wheel', handleWheel, { passive: true });
      window.addEventListener('contextmenu', handleContextMenu);
      document.addEventListener('pointerlockchange', handlePointerLockChange);
      window.addEventListener('resize', handleResize);

      // Expose imperative API for HUD buttons
      controlsApiRef.current = {
        selectWeapon: (id) => switchWeapon(id),
        triggerReload: () => startReload(),
        triggerSimShot: () => {
          soundEngine.unlock();
          if (fireCooldown <= 0) fireSingleRound();
        },
        toggleInspectPose1: () => {
          if (poseMode !== 'RELOADING' && poseMode !== 'BOLT_CYCLE') {
            inspectPose1Toggle = !inspectPose1Toggle;
            poseMode = inspectPose1Toggle ? 'INSPECT_POSE_1' : 'READY';
            if (inspectPose1Toggle) isAds = false;
          }
        },
        toggleBodycamMode: () => {
          bodycamMode = !bodycamMode;
        },
        toggleCrouch: () => {
          crouchToggle = !crouchToggle;
          soundEngine.playCrouchToggle(crouchToggle);
          recoilVel.y += crouchToggle ? -0.28 : 0.26;
        },
        toggleSlowMo: () => {
          slowMo = !slowMo;
        },
        toggleCallouts: () => {
          showCallouts = !showCallouts;
        },
        setGameMode: (mode) => {
          gameMode = mode;
          world.setRangeModeActive(mode === 'RANGE');
          if (mode === 'COMBAT') {
            health = maxHealth;
            armor = 50;
          }
        },
        cycleFireMode: () => {
          const modes = WEAPON_SPECS[currentWeapon].fireModes;
          if (modes.length <= 1) return;
          const idx = modes.indexOf(weaponFireModes[currentWeapon]);
          weaponFireModes[currentWeapon] = modes[(idx + 1) % modes.length];
          soundEngine.playBoltStep('lift');
        },
        requestPointerLock: () => {
          soundEngine.unlock();
          renderer.domElement.requestPointerLock?.();
        },
      };

      // Main 60–144Hz Game & Simulation Loop
      let lastTime = performance.now();
      let hudThrottle = 0;
      let animFrameId = 0;

      const animate = (now: number) => {
        animFrameId = requestAnimationFrame(animate);
        const realDt = Math.min(0.05, (now - lastTime) / 1000);
        lastTime = now;

        // Time scale: 0.2x in Slow-Motion Ballistics Mode so every mechanical & ballistic detail is crystal clear!
        const simDt = realDt * (slowMo ? 0.2 : 1.0);

        // 1. Viral Bodycam Smooth Rotational Inertia + Realistic Human Locomotion & Sprint
        if (sprintFireSuppressTimer > 0) {
          sprintFireSuppressTimer = Math.max(0, sprintFireSuppressTimer - realDt);
        }

        const lookRate = isAds ? 32 : bodycamMode ? 18.5 : 46;
        const lookAlpha = 1 - Math.exp(-lookRate * realDt);
        const prevSmoothYaw = smoothYaw;
        const prevSmoothPitch = smoothPitch;
        smoothYaw = THREE.MathUtils.lerp(smoothYaw, targetYaw, lookAlpha);
        smoothPitch = THREE.MathUtils.lerp(smoothPitch, targetPitch, lookAlpha);
        const angularVelYaw = (smoothYaw - prevSmoothYaw) / Math.max(0.001, realDt);
        const angularVelPitch = (smoothPitch - prevSmoothPitch) / Math.max(0.001, realDt);

        const forwardInput = (keys['KeyW'] ? 1 : 0) - (keys['KeyS'] ? 1 : 0);
        const strafeInput = (keys['KeyD'] ? 1 : 0) - (keys['KeyA'] ? 1 : 0);
        const hasMoveInput = forwardInput !== 0 || strafeInput !== 0;

        // Auto-uncrouch if player initiates a forward Shift Sprint!
        if ((keys['ShiftLeft'] || keys['ShiftRight']) && forwardInput > 0 && crouchToggle) {
          crouchToggle = false;
          soundEngine.playCrouchToggle(false);
        }
        const isCrouching = Boolean(crouchToggle || keys['ControlLeft']);
        crouchAlpha = THREE.MathUtils.lerp(
          crouchAlpha,
          isCrouching ? 1 : 0,
          1 - Math.exp(-13 * realDt)
        );

        const wantsSprint = Boolean(
          (keys['ShiftLeft'] || keys['ShiftRight']) &&
            hasMoveInput &&
            forwardInput >= 0 &&
            !isAds &&
            !isCrouching &&
            !isMouseDown &&
            sprintFireSuppressTimer <= 0 &&
            poseMode !== 'RELOADING' &&
            poseMode !== 'BOLT_CYCLE'
        );

        // Subtle Pro-Operator Shoulder Settle on Sprint Enter & Exit (No excessive shake!)
        if (wantsSprint !== wasSprinting) {
          wasSprinting = wantsSprint;
          if (wantsSprint) {
            recoilVel.y += 0.11;
            recoilRotVel.x += 0.32;
          } else {
            recoilVel.y -= 0.09;
            recoilRotVel.x -= 0.28;
          }
        }

        // Smooth Pro-Stabilized Sprint Blend & Over-Damped Spring (Zero bounce/overshoot wobble!)
        const sprintLerpRate = wantsSprint ? 10.5 : 15.0;
        sprintAlpha = THREE.MathUtils.lerp(
          sprintAlpha,
          wantsSprint ? 1 : 0,
          1 - Math.exp(-sprintLerpRate * realDt)
        );
        if (sprintAlpha < 0.004) sprintAlpha = 0;

        const spStiff = wantsSprint ? 150 : 195;
        const spDamp = wantsSprint ? 24.5 : 27.0; // Critically damped -> smooth pro lock!
        sprintSpringVel += ((wantsSprint ? 1 : 0) - sprintSpringVal) * spStiff * realDt;
        sprintSpringVel *= Math.max(0, 1 - spDamp * realDt);
        sprintSpringVal = THREE.MathUtils.clamp(sprintSpringVal + sprintSpringVel * realDt, 0, 1);

        if (poseMode !== 'RELOADING' && poseMode !== 'BOLT_CYCLE' && poseMode !== 'INSPECT_POSE_1') {
          poseMode = sprintAlpha > 0.25 ? 'SPRINTING' : 'READY';
        } else if (wantsSprint && poseMode === 'INSPECT_POSE_1') {
          inspectPose1Toggle = false;
          poseMode = 'SPRINTING';
        }

        // Long-Striding Athletic Sprint Speeds (Pistol 14.8 m/s, Rifle 14.0 m/s, Sniper 13.0 m/s — covers ground effortlessly!)
        const sprintTopSpeed =
          currentWeapon === 'pistol' ? 14.8 : currentWeapon === 'rifle' ? 14.0 : 13.0;
        const moveSpeed = isCrouching
          ? 3.6
          : THREE.MathUtils.lerp(6.5, sprintTopSpeed, sprintAlpha);

        const forward = new THREE.Vector3(-Math.sin(smoothYaw), 0, -Math.cos(smoothYaw));
        const right = new THREE.Vector3(Math.cos(smoothYaw), 0, -Math.sin(smoothYaw));
        const wishDir = new THREE.Vector3();
        if (keys['KeyW']) wishDir.add(forward);
        if (keys['KeyS']) wishDir.sub(forward);
        if (keys['KeyD']) wishDir.add(right);
        if (keys['KeyA']) wishDir.sub(right);
        if (wishDir.lengthSq() > 0) wishDir.normalize();

        // Responsive human acceleration & crisp stop deceleration
        const accelRate = hasMoveInput ? 11.5 : 12.0;
        const velLerp = 1 - Math.exp(-accelRate * realDt);
        playerVel.x = THREE.MathUtils.lerp(playerVel.x, wishDir.x * moveSpeed, velLerp);
        playerVel.z = THREE.MathUtils.lerp(playerVel.z, wishDir.z * moveSpeed, velLerp);
        playerVel.y -= 18.5 * realDt;

        // 3D Box/Crate Aware Horizontal Collision (Allows boots at playerFeetY >= c.maxY - 0.30 to clear crate top edges!)
        const pRadius = 0.34;
        const stepClearance = 0.3;
        const nextX = playerPos.x + playerVel.x * realDt;
        let blockedX = false;
        for (const c of world.colliders) {
          if (
            nextX > c.minX - pRadius &&
            nextX < c.maxX + pRadius &&
            playerPos.z > c.minZ - pRadius &&
            playerPos.z < c.maxZ + pRadius &&
            playerFeetY < c.maxY - stepClearance
          ) {
            blockedX = true;
            break;
          }
        }
        if (!blockedX) playerPos.x = nextX;

        const nextZ = playerPos.z + playerVel.z * realDt;
        let blockedZ = false;
        for (const c of world.colliders) {
          if (
            playerPos.x > c.minX - pRadius &&
            playerPos.x < c.maxX + pRadius &&
            nextZ > c.minZ - pRadius &&
            nextZ < c.maxZ + pRadius &&
            playerFeetY < c.maxY - stepClearance
          ) {
            blockedZ = true;
            break;
          }
        }
        if (!blockedZ) playerPos.z = nextZ;

        // Find highest walkable Box/Crate/Boulder surface directly beneath player's boots!
        const prevFeetY = playerFeetY;
        let supportY = 0;
        let supportSurface: 'wood' | 'stone' = 'stone';
        for (const c of world.colliders) {
          if (
            playerPos.x >= c.minX - pRadius * 0.82 &&
            playerPos.x <= c.maxX + pRadius * 0.82 &&
            playerPos.z >= c.minZ - pRadius * 0.82 &&
            playerPos.z <= c.maxZ + pRadius * 0.82 &&
            prevFeetY >= c.maxY - 0.34
          ) {
            if (c.maxY > supportY) {
              supportY = c.maxY;
              supportSurface = c.surface ?? 'stone';
            }
          }
        }

        // Smooth crouch eye-height transition + Vertical Box-Top Landing Physics!
        const targetEyeHeight = isCrouching ? 1.04 : 1.7;
        smoothEyeHeight = THREE.MathUtils.lerp(
          smoothEyeHeight,
          targetEyeHeight,
          1 - Math.exp(-13.5 * realDt)
        );

        wasOnGround = onGround;
        const preLandVelY = playerVel.y;
        playerFeetY += playerVel.y * realDt;

        if (playerFeetY <= supportY && playerVel.y <= 0) {
          playerFeetY = supportY;
          playerVel.y = 0;
          onGround = true;
          standingOnWood = supportY > 0.05 && supportSurface === 'wood';
          if (!wasOnGround && preLandVelY < -2.0) {
            const impact = Math.min(1.45, Math.abs(preLandVelY) / 6.8);
            landingDipVel -= 2.4 * impact;
            recoilVel.y -= 0.6 * impact;
            recoilRotVel.x -= 1.65 * impact;
            recoilRotVel.z += (Math.random() - 0.5) * 1.1;
            soundEngine.playJumpLand(true, standingOnWood);
          }
        } else {
          onGround = false;
        }
        playerPos.y = playerFeetY + smoothEyeHeight;

        // Update knee-compression landing spring
        landingDipVel += -landingDipY * 95 * realDt;
        landingDipVel *= Math.max(0, 1 - 12 * realDt);
        landingDipY += landingDipVel * realDt;

        // True Distance-Driven Long-Stride Cadence (~3.55m per sprint step!) + Smooth Cushioned Footstep Audio!
        const horizSpeed = Math.hypot(playerVel.x, playerVel.z);
        const speedNorm = THREE.MathUtils.clamp(horizSpeed / 14.5, 0, 1);
        if (horizSpeed > 0.45 && onGround) {
          // Long human stride length: 2.15m walking -> 3.55m sprinting (~3.8–4.1 natural steps/sec, never machine-gun tapping!)
          const stepMeters = isCrouching
            ? 1.55
            : THREE.MathUtils.lerp(2.15, 3.55, sprintAlpha);
          const distAdvance = (horizSpeed * realDt * Math.PI) / stepMeters;
          stridePhase += distAdvance;
          const stepIndex = Math.floor(stridePhase / Math.PI);
          if (stepIndex > lastFootstepIdx) {
            lastFootstepIdx = stepIndex;
            soundEngine.playFootstep(
              sprintAlpha > 0.4,
              stepIndex % 2 === 0 ? 'left' : 'right',
              standingOnWood
            );
          }
        } else {
          lastFootstepIdx = Math.floor(stridePhase / Math.PI);
        }

        const moveWeight = onGround ? THREE.MathUtils.clamp(horizSpeed / 5.2, 0, 1) : 0.12;
        const adsDampen = isAds ? 0.14 : 1.0;

        // Silky-Smooth C-infinity Sinusoidal Gimbal Camera Glide (Zero sharp corners at Math.abs(sin) = 0!)
        // (1 - cos(2*phase))*0.5 has continuous derivative everywhere -> buttery-smooth AAA sprint camera!
        const smoothWaveY = (1 - Math.cos(stridePhase * 2)) * 0.5;
        const rawCamBobY =
          -smoothWaveY * THREE.MathUtils.lerp(0.01, 0.017, sprintAlpha) * moveWeight * adsDampen;
        const rawCamBobX =
          Math.sin(stridePhase) * THREE.MathUtils.lerp(0.006, 0.011, sprintAlpha) * moveWeight * adsDampen;
        const rawCamPitch =
          Math.sin(stridePhase * 2 - 0.5) * THREE.MathUtils.lerp(0.0014, 0.0035, sprintAlpha) * moveWeight * adsDampen -
          sprintAlpha * 0.012;

        const camSmoothAlpha = 1 - Math.exp(-14 * realDt);
        smoothCamBobX = THREE.MathUtils.lerp(smoothCamBobX, rawCamBobX, camSmoothAlpha);
        smoothCamBobY = THREE.MathUtils.lerp(smoothCamBobY, rawCamBobY, camSmoothAlpha);
        smoothCamPitch = THREE.MathUtils.lerp(smoothCamPitch, rawCamPitch, camSmoothAlpha);

        // Organic Bodycam handheld breathing + head-turn banking + strafe lean + subtle pro stride roll!
        const tSec = now * 0.001;
        const handheldPitch = bodycamMode
          ? (Math.sin(tSec * 1.45) * 0.0018 + Math.cos(tSec * 2.3) * 0.0008) * (isAds ? 0.25 : 1.0)
          : 0;
        const handheldYaw = bodycamMode
          ? (Math.cos(tSec * 1.12) * 0.0016 + Math.sin(tSec * 1.9) * 0.0007) * (isAds ? 0.25 : 1.0)
          : 0;
        const handheldRoll = bodycamMode
          ? Math.sin(tSec * 1.25) * Math.cos(tSec * 0.85) * 0.0034 * (isAds ? 0.2 : 1.0)
          : 0;

        const turnBankRoll = bodycamMode
          ? THREE.MathUtils.clamp(angularVelYaw * 0.014, -0.052, 0.052)
          : THREE.MathUtils.clamp(angularVelYaw * 0.005, -0.02, 0.02);
        const strafeLeanRoll = -strafeInput * (bodycamMode ? 0.02 : 0.009) * (isAds ? 0.3 : 1.0);
        const strideHeadRoll =
          Math.sin(stridePhase) *
          THREE.MathUtils.lerp(0.0025, bodycamMode ? 0.0065 : 0.004, sprintAlpha) *
          moveWeight *
          adsDampen;

        const targetRollZ = turnBankRoll + strafeLeanRoll + strideHeadRoll + handheldRoll;
        smoothRollZ = THREE.MathUtils.lerp(
          smoothRollZ,
          targetRollZ,
          1 - Math.exp(-10.5 * realDt)
        );

        // Smooth camera recoil recovery
        recoilCameraPitch = THREE.MathUtils.lerp(recoilCameraPitch, 0, Math.min(1, realDt * 10));
        recoilCameraYaw = THREE.MathUtils.lerp(recoilCameraYaw, 0, Math.min(1, realDt * 10));

        const scopeBreath =
          isAds && currentWeapon === 'sniper'
            ? Math.sin(now * 0.0018) * 0.0022
            : 0;

        // Apply silky-smoothed camera glide position
        worldCamera.position.set(
          playerPos.x + right.x * smoothCamBobX,
          playerPos.y + smoothCamBobY + landingDipY,
          playerPos.z + right.z * smoothCamBobX
        );
        worldCamera.rotation.order = 'YXZ';
        worldCamera.rotation.y = smoothYaw + recoilCameraYaw + handheldYaw;
        worldCamera.rotation.x = THREE.MathUtils.clamp(
          smoothPitch + recoilCameraPitch + scopeBreath + smoothCamPitch + handheldPitch + landingDipY * 0.28,
          -1.42,
          1.42
        );
        worldCamera.rotation.z = smoothRollZ;

        // Smooth World Camera FOV transition (Base 68° -> +11.5° Fast Sprint Surge -> Peripheral/Precision ADS)
        adsAlpha = THREE.MathUtils.lerp(adsAlpha, isAds ? 1 : 0, 1 - Math.exp(-13.5 * realDt));
        const hipFovWithSprint = 68 + sprintAlpha * 11.5 * speedNorm;
        const peripheralAdsFov =
          currentWeapon === 'sniper' ? 46 : WEAPON_SPECS[currentWeapon].adsFov;
        const targetWorldFov = THREE.MathUtils.lerp(
          hipFovWithSprint,
          peripheralAdsFov,
          adsAlpha
        );
        if (Math.abs(worldCamera.fov - targetWorldFov) > 0.015) {
          worldCamera.fov = THREE.MathUtils.lerp(
            worldCamera.fov,
            targetWorldFov,
            1 - Math.exp(-12 * realDt)
          );
          worldCamera.updateProjectionMatrix();
        }

        // Sync Viewmodel Camera & Rig with World Camera
        vmCamera.position.copy(worldCamera.position);
        vmCamera.quaternion.copy(worldCamera.quaternion);
        vmCameraRig.position.copy(vmCamera.position);
        vmCameraRig.quaternion.copy(vmCamera.quaternion);

        // 2. Weapon Firing Cooldowns & Auto/Burst Logic
        if (fireCooldown > 0) fireCooldown -= simDt;

        const fm = weaponFireModes[currentWeapon];
        if (fm === 'BURST' && burstRemaining > 0) {
          burstTimer -= simDt;
          if (burstTimer <= 0 && fireCooldown <= 0) {
            fireSingleRound();
            burstRemaining--;
            burstTimer = 60 / WEAPON_SPECS[currentWeapon].rpm;
          }
        } else if (isMouseDown && fireCooldown <= 0) {
          if (fm === 'AUTO') {
            fireSingleRound();
          } else if ((fm === 'SEMI' || fm === 'BOLT') && !semiLocked) {
            semiLocked = true;
            fireSingleRound();
          }
        }

        // 3. Reload State Machine (GAMBAR 1 POSE + 4-Stage Magazine & Slide/Bolt Choreography!)
        const spec = WEAPON_SPECS[currentWeapon];
        const rig = rigs[currentWeapon];
        let reloadProgress = 0;
        let reloadStageLabel = '';
        let boltProgress = 0;

        // Reset hand & mag transforms to baseline before applying active procedural animation
        rig.leftArm.root.position.copy(rig.leftArm.basePos);
        rig.leftArm.root.rotation.copy(rig.leftArm.baseRot);
        rig.rightArm.root.position.copy(rig.rightArm.basePos);
        rig.rightArm.root.rotation.copy(rig.rightArm.baseRot);
        rig.magGroup.position.copy(rig.magBasePos);
        rig.magGroup.rotation.copy(rig.magBaseRot);
        if (rig.chargingHandleGroup) rig.chargingHandleGroup.position.z = 0.072;
        if (rig.boltHandlePivot) rig.boltHandlePivot.rotation.z = 0;

        if (poseMode === 'RELOADING') {
          reloadTimer += simDt;
          reloadProgress = Math.min(1, reloadTimer / activeReloadDuration);
          const magGrabOffset =
            currentWeapon === 'sniper'
              ? new THREE.Vector3(-0.022, -0.048, 0.015)
              : new THREE.Vector3(-0.024, -0.022, 0.022);
          const magTravelDist = currentWeapon === 'sniper' ? 0.195 : 0.29;

          // Keep Pistol slide locked open during empty reload until slingshot release!
          if (currentWeapon === 'pistol' && reloadWasEmpty && reloadProgress < 0.68) {
            slideBlowback = 0.92;
            rig.slideOrBoltGroup.position.z = slideBlowback * 0.062;
            if (rig.hammerPivot) rig.hammerPivot.rotation.x = -0.68;
          }

          if (!reloadWasEmpty) {
            // =================================================================
            // FAST HIGH-MOMENTUM TACTICAL RELOAD (Round already in chamber!)
            // =================================================================
            if (reloadProgress < 0.14) {
              reloadStageLabel = 'Whip ke Sudut Isi Ammo (Gambar 1)';
              const p = 1 - Math.pow(1 - reloadProgress / 0.14, 3);
              rig.leftArm.root.position.lerp(rig.magBasePos.clone().add(magGrabOffset), p);
            } else if (reloadProgress < 0.44) {
              reloadStageLabel = 'Flick & Lepas Magazen Cepat!';
              if ((reloadStageSoundMask & 1) === 0) {
                reloadStageSoundMask |= 1;
                soundEngine.playReloadSound(currentWeapon, 'magOut', slowMo);
                // Crisp tactical wrist-flick impulse!
                recoilRotVel.z += 2.65;
                recoilRotVel.y -= 1.15;
                recoilVel.y -= 0.44;
                recoilCameraPitch -= 0.009;
                vmScene.updateMatrixWorld(true);
                const magProj = projectVmAnchor(rig.magAnchor);
                ballistics.dropEmptyMagazine(
                  currentWeapon,
                  magProj.worldPos,
                  worldCamera.quaternion,
                  playerVel
                );
              }
              const p = (reloadProgress - 0.14) / 0.3;
              const accelP = p * p * 1.15;
              const dropVec = new THREE.Vector3(-0.03 * accelP, -magTravelDist * accelP, 0.034 * accelP);
              rig.magGroup.position.copy(rig.magBasePos).add(dropVec);
              rig.magGroup.rotation.z = -0.16 * p;
              rig.leftArm.root.position.copy(rig.magBasePos).add(dropVec).add(magGrabOffset);
            } else if (reloadProgress < 0.84) {
              reloadStageLabel = 'Slam Magazen .338 / STANAG Baru!';
              const p = (reloadProgress - 0.44) / 0.4;
              // Explosive easeOutQuart bring-up into magwell
              const easeP = 1 - Math.pow(1 - p, 4);
              const rem = 1 - easeP;
              const liftVec = new THREE.Vector3(-0.024 * rem, -magTravelDist * rem, 0.026 * rem);
              rig.magGroup.position.copy(rig.magBasePos).add(liftVec);
              rig.magGroup.rotation.z = -0.14 * rem;
              rig.leftArm.root.position.copy(rig.magBasePos).add(liftVec).add(magGrabOffset);

              if (p > 0.52 && (reloadStageSoundMask & 2) === 0) {
                reloadStageSoundMask |= 2;
                soundEngine.playReloadSound(currentWeapon, 'magTap', slowMo);
              }
              if (p > 0.84 && (reloadStageSoundMask & 4) === 0) {
                reloadStageSoundMask |= 4;
                soundEngine.playReloadSound(currentWeapon, 'magIn', slowMo);
                // Visceral high-momentum Mag-Slam shock!
                recoilVel.y += 1.48;
                recoilVel.z -= 0.44;
                recoilRotVel.x += 2.9;
                recoilRotVel.z -= 1.75;
                recoilCameraPitch += 0.017;
              }
            } else {
              reloadStageLabel = 'Snap Siap Tembak (Gambar 2)!';
              if ((reloadStageSoundMask & 32) === 0) {
                reloadStageSoundMask |= 32;
                soundEngine.playReloadSound(currentWeapon, 'readySnap', slowMo);
              }
              const p = (reloadProgress - 0.84) / 0.16;
              const snapP = 1 - Math.pow(1 - p, 3);
              rig.leftArm.root.position.lerpVectors(
                rig.magBasePos.clone().add(magGrabOffset),
                rig.leftArm.basePos,
                snapP
              );
            }
          } else {
            // =================================================================
            // EMPTY RELOAD + EXPLOSIVE SLINGSHOT / BOLT CHAMBERING!
            // =================================================================
            if (reloadProgress < 0.12) {
              reloadStageLabel = 'Whip ke Sudut Isi Ammo (Gambar 1)';
              const p = 1 - Math.pow(1 - reloadProgress / 0.12, 3);
              rig.leftArm.root.position.lerp(rig.magBasePos.clone().add(magGrabOffset), p);
            } else if (reloadProgress < 0.36) {
              reloadStageLabel = 'Flick Buang Magazen Kosong!';
              if ((reloadStageSoundMask & 1) === 0) {
                reloadStageSoundMask |= 1;
                soundEngine.playReloadSound(currentWeapon, 'magOut', slowMo);
                // Aggressive empty-mag wrist flick!
                recoilRotVel.z += 3.15;
                recoilRotVel.y -= 1.45;
                recoilVel.y -= 0.5;
                recoilCameraPitch -= 0.011;
                vmScene.updateMatrixWorld(true);
                const magProj = projectVmAnchor(rig.magAnchor);
                ballistics.dropEmptyMagazine(
                  currentWeapon,
                  magProj.worldPos,
                  worldCamera.quaternion,
                  playerVel
                );
              }
              const p = (reloadProgress - 0.12) / 0.24;
              const accelP = p * p * 1.22;
              const dropVec = new THREE.Vector3(-0.034 * accelP, -magTravelDist * 1.08 * accelP, 0.038 * accelP);
              rig.magGroup.position.copy(rig.magBasePos).add(dropVec);
              rig.magGroup.rotation.z = -0.2 * p;
              rig.leftArm.root.position.copy(rig.magBasePos).add(dropVec).add(magGrabOffset);
            } else if (reloadProgress < 0.68) {
              reloadStageLabel = 'Slam Magazen Penuh Baru!';
              const p = (reloadProgress - 0.36) / 0.32;
              const easeP = 1 - Math.pow(1 - p, 4);
              const rem = 1 - easeP;
              const liftVec = new THREE.Vector3(-0.025 * rem, -magTravelDist * 1.08 * rem, 0.028 * rem);
              rig.magGroup.position.copy(rig.magBasePos).add(liftVec);
              rig.magGroup.rotation.z = -0.18 * rem;
              rig.leftArm.root.position.copy(rig.magBasePos).add(liftVec).add(magGrabOffset);

              if (p > 0.52 && (reloadStageSoundMask & 2) === 0) {
                reloadStageSoundMask |= 2;
                soundEngine.playReloadSound(currentWeapon, 'magTap', slowMo);
              }
              if (p > 0.82 && (reloadStageSoundMask & 4) === 0) {
                reloadStageSoundMask |= 4;
                soundEngine.playReloadSound(currentWeapon, 'magIn', slowMo);
                // Heavy high-momentum Mag-Slam impact!
                recoilVel.y += 1.62;
                recoilVel.z -= 0.52;
                recoilRotVel.x += 3.25;
                recoilRotVel.z -= 1.95;
                recoilCameraPitch += 0.02;
              }
            } else {
              reloadStageLabel =
                currentWeapon === 'pistol'
                  ? 'Slingshot Kokang Slide 9mm!'
                  : currentWeapon === 'rifle'
                  ? 'Tarik & Lepas T-Charging Handle M4!'
                  : 'Kokang Cepat Bolt Sniper (.338)!';

              const p = (reloadProgress - 0.68) / 0.32;

              // Trigger sharp rearward pull sound + momentum yank
              if (p >= 0.04 && (reloadStageSoundMask & 8) === 0) {
                reloadStageSoundMask |= 8;
                soundEngine.playReloadSound(currentWeapon, 'rackPull', slowMo);
                recoilVel.z += 0.96;
                recoilRotVel.x += 2.35;
                recoilCameraPitch += 0.012;
              }

              // Trigger explosive forward bolt/slide slam sound + forward momentum punch!
              if (p >= 0.52 && (reloadStageSoundMask & 16) === 0) {
                reloadStageSoundMask |= 16;
                soundEngine.playReloadSound(currentWeapon, 'rackRelease', slowMo);
                recoilVel.z -= 1.45;
                recoilRotVel.x -= 3.15;
                recoilRotVel.z += 1.55;
                recoilCameraPitch -= 0.016;
              }

              // Asymmetric whip curve: brisk pull back (0..0.52), instant spring slam shut (0.52..0.72), hand snap home (0.72..1.0)
              const pullAmount =
                p < 0.52
                  ? 1 - Math.pow(1 - p / 0.52, 2.5)
                  : p < 0.7
                  ? 1 - (p - 0.52) / 0.18
                  : 0;

              const handBlend =
                p < 0.62 ? Math.min(1, p / 0.22) : Math.max(0, 1 - (p - 0.62) / 0.38);

              if (currentWeapon === 'pistol') {
                slideBlowback = p < 0.52 ? 0.92 + pullAmount * 0.2 : pullAmount;
                rig.slideOrBoltGroup.position.z = slideBlowback * 0.062;
                if (rig.hammerPivot) rig.hammerPivot.rotation.x = -slideBlowback * 0.72;
                rig.leftArm.root.position.lerpVectors(
                  rig.leftArm.basePos,
                  new THREE.Vector3(-0.03, 0.038, 0.018 + pullAmount * 0.062),
                  handBlend
                );
              } else if (currentWeapon === 'rifle') {
                slideBlowback = pullAmount;
                rig.slideOrBoltGroup.position.z = slideBlowback * 0.068;
                if (rig.chargingHandleGroup) {
                  rig.chargingHandleGroup.position.z = 0.072 + pullAmount * 0.076;
                }
                rig.leftArm.root.position.lerpVectors(
                  rig.leftArm.basePos,
                  new THREE.Vector3(-0.028, 0.048, 0.078 + pullAmount * 0.076),
                  handBlend
                );
              } else if (currentWeapon === 'sniper') {
                const handleLift = p < 0.18 ? p / 0.18 : p < 0.78 ? 1 : 1 - (p - 0.78) / 0.22;
                if (rig.boltHandlePivot) {
                  rig.boltHandlePivot.rotation.z = Math.max(0, handleLift) * 1.14;
                }
                rig.slideOrBoltGroup.position.z = pullAmount * 0.098;
                rig.rightArm.root.position.lerpVectors(
                  rig.rightArm.basePos,
                  new THREE.Vector3(0.054, 0.026, 0.048 + pullAmount * 0.095),
                  handBlend
                );
              }
            }
          }

          if (reloadProgress >= 1) {
            const needed = spec.magSize - ammo[currentWeapon];
            const transfer = Math.min(needed, reserve[currentWeapon]);
            ammo[currentWeapon] += transfer;
            reserve[currentWeapon] -= transfer;
            slideBlowback = 0;
            rig.slideOrBoltGroup.position.z = 0;
            poseMode = 'READY';
          }
        } else if (poseMode === 'BOLT_CYCLE' && currentWeapon === 'sniper') {
          // High-Momentum 4-step Sniper Bolt-Action Re-chambering (0.84s) + Delayed .338 Shell Ejection!
          const dur = spec.boltCycleDuration ?? 0.84;
          boltTimer += simDt;
          boltProgress = Math.min(1, boltTimer / dur);

          if (boltProgress < 0.2) {
            // 1. Snappy cam-lift bolt handle up 65°
            if ((boltSoundMask & 1) === 0) {
              boltSoundMask |= 1;
              soundEngine.playBoltStep('lift');
              recoilRotVel.z -= 1.35;
              recoilVel.y += 0.28;
            }
            const p = 1 - Math.pow(1 - boltProgress / 0.2, 2.5);
            if (rig.boltHandlePivot) rig.boltHandlePivot.rotation.z = p * 1.14;
            rig.rightArm.root.position.lerp(new THREE.Vector3(0.056, 0.028, 0.048), p);
          } else if (boltProgress < 0.52) {
            // 2. Brisk pull backward -> EJECT SMOKING .338 SHELL CASING!
            if ((boltSoundMask & 2) === 0) {
              boltSoundMask |= 2;
              soundEngine.playBoltStep('pull');
              recoilVel.z += 0.82;
              recoilRotVel.x += 1.65;
              recoilCameraPitch += 0.01;
            }
            const p = 1 - Math.pow(1 - (boltProgress - 0.2) / 0.32, 2.2);
            if (rig.boltHandlePivot) rig.boltHandlePivot.rotation.z = 1.14;
            rig.slideOrBoltGroup.position.z = p * 0.098;
            rig.rightArm.root.position.set(0.056, 0.028, 0.048 + p * 0.098);

            if (p >= 0.58 && !sniperCasingEjectedThisCycle) {
              sniperCasingEjectedThisCycle = true;
              vmScene.updateMatrixWorld(true);
              const ejectProj = projectVmAnchor(rig.ejectionAnchor);
              ballistics.ejectShellCasing(
                '338',
                ejectProj.worldPos,
                worldCamera.quaternion,
                playerVel
              );
              lastEjectPulse = performance.now();
            }
          } else if (boltProgress < 0.8) {
            // 3. Slam bolt forward stripping fresh .338 cartridge into chamber
            if ((boltSoundMask & 4) === 0) {
              boltSoundMask |= 4;
              soundEngine.playBoltStep('push');
              recoilVel.z -= 1.05;
              recoilRotVel.x -= 1.85;
            }
            const p = 1 - Math.pow(1 - (boltProgress - 0.52) / 0.28, 2.5);
            if (rig.boltHandlePivot) rig.boltHandlePivot.rotation.z = 1.14;
            rig.slideOrBoltGroup.position.z = (1 - p) * 0.098;
            rig.rightArm.root.position.set(0.056, 0.028, 0.048 + (1 - p) * 0.098);
          } else {
            // 4. Crisp steel lug lock down & snap right hand back to grip
            if ((boltSoundMask & 8) === 0) {
              boltSoundMask |= 8;
              soundEngine.playBoltStep('lock');
              recoilRotVel.z += 1.55;
              recoilCameraPitch -= 0.01;
            }
            const p = 1 - Math.pow(1 - (boltProgress - 0.8) / 0.2, 2.5);
            if (rig.boltHandlePivot) rig.boltHandlePivot.rotation.z = (1 - p) * 1.14;
            rig.slideOrBoltGroup.position.z = 0;
            rig.rightArm.root.position.lerpVectors(
              new THREE.Vector3(0.056, 0.028, 0.048),
              rig.rightArm.basePos,
              p
            );
          }

          if (boltProgress >= 1) {
            rig.slideOrBoltGroup.position.z = 0;
            poseMode = 'READY';
          }
        }

        // 4. Slide Blowback & Hammer / Trigger Mechanical Animation
        if (poseMode !== 'RELOADING' && poseMode !== 'BOLT_CYCLE') {
          const isPistolSlideLocked = currentWeapon === 'pistol' && ammo.pistol === 0;
          const targetSlide = isPistolSlideLocked ? 0.9 : 0;
          slideBlowback = THREE.MathUtils.lerp(slideBlowback, targetSlide, Math.min(1, simDt * 24));

          if (currentWeapon === 'pistol') {
            rig.slideOrBoltGroup.position.z = slideBlowback * 0.062;
            if (rig.hammerPivot) {
              rig.hammerPivot.rotation.x = -slideBlowback * 0.72;
            }
          } else if (currentWeapon === 'rifle') {
            rig.slideOrBoltGroup.position.z = slideBlowback * 0.068;
          } else {
            rig.slideOrBoltGroup.position.z = 0;
          }
        }

        triggerPull = THREE.MathUtils.lerp(triggerPull, 0, Math.min(1, simDt * 20));
        rig.triggerPivot.rotation.x = triggerPull * 0.42;

        // 5. Damped Harmonic Recoil Spring Physics + Weapon Pose Blending (Gambar 2 vs Gambar 1)
        const stiffness = 175;
        const damping = 18;
        recoilVel.addScaledVector(recoilOffset, -stiffness * simDt);
        recoilVel.multiplyScalar(Math.max(0, 1 - damping * simDt));
        recoilOffset.addScaledVector(recoilVel, simDt);

        recoilRotVel.addScaledVector(recoilRot, -stiffness * simDt);
        recoilRotVel.multiplyScalar(Math.max(0, 1 - damping * simDt));
        recoilRot.addScaledVector(recoilRotVel, simDt);

        swayOffset.x = THREE.MathUtils.lerp(swayOffset.x, 0, Math.min(1, realDt * 8));
        swayOffset.y = THREE.MathUtils.lerp(swayOffset.y, 0, Math.min(1, realDt * 8));

        // Bodycam Hand-Mass Rotational Lag / Free-Aim Inertia (Signature Unrecord / Bodycam weighty feel!)
        const freeAimScale = isAds ? 0.22 : bodycamMode ? 1.0 : 0.35;
        const targetFreeAimRotX = THREE.MathUtils.clamp(-angularVelPitch * 0.019 * freeAimScale, -0.095, 0.095);
        const targetFreeAimRotY = THREE.MathUtils.clamp(-angularVelYaw * 0.024 * freeAimScale, -0.115, 0.115);
        const targetFreeAimRotZ = THREE.MathUtils.clamp(
          (angularVelYaw * 0.026 - strafeInput * 0.032) * freeAimScale,
          -0.12,
          0.12
        );
        const freeAimAlpha = 1 - Math.exp(-10.5 * realDt);
        bodycamFreeAimRot.x = THREE.MathUtils.lerp(bodycamFreeAimRot.x, targetFreeAimRotX, freeAimAlpha);
        bodycamFreeAimRot.y = THREE.MathUtils.lerp(bodycamFreeAimRot.y, targetFreeAimRotY, freeAimAlpha);
        bodycamFreeAimRot.z = THREE.MathUtils.lerp(bodycamFreeAimRot.z, targetFreeAimRotZ, freeAimAlpha);

        const targetFreeAimPosX = THREE.MathUtils.clamp(-angularVelYaw * 0.0045 - strafeInput * 0.008, -0.024, 0.024) * freeAimScale;
        const targetFreeAimPosY =
          (THREE.MathUtils.clamp(angularVelPitch * 0.004, -0.02, 0.02) +
            Math.sin(tSec * 1.55) * 0.0022) *
          freeAimScale;
        bodycamFreeAimPos.x = THREE.MathUtils.lerp(bodycamFreeAimPos.x, targetFreeAimPosX, freeAimAlpha);
        bodycamFreeAimPos.y = THREE.MathUtils.lerp(bodycamFreeAimPos.y, targetFreeAimPosY, freeAimAlpha);

        equipProgress = Math.min(1, equipProgress + realDt * 4.5);
        const equipDrop = (1 - equipProgress) * (1 - equipProgress) * -0.18;

        // Pro-Operator Composed Walk & Stabilized Tactical Sprint Glide (Pure C-infinity sine glide, zero sharp bounce!)
        const bobScale =
          isAds ? 0.12 : poseMode === 'RELOADING' || poseMode === 'INSPECT_POSE_1' ? 0.24 : 1.0;

        const smoothVertPulse = (1 - Math.cos(stridePhase * 2)) * 0.5;
        const walkSwingX = Math.sin(stridePhase) * 0.005 * moveWeight * bobScale;
        const walkSwingY = -smoothVertPulse * 0.0055 * moveWeight * bobScale;

        const sprintPumpMult =
          currentWeapon === 'pistol' ? 1.0 : currentWeapon === 'rifle' ? 0.94 : 0.86;
        const sprintSwingX = Math.sin(stridePhase) * 0.0115 * sprintPumpMult;
        const sprintSwingY = -smoothVertPulse * 0.012 * sprintPumpMult;
        const sprintSwingZ = Math.sin(stridePhase * 2 - 0.25) * 0.005 * sprintPumpMult;

        const bobX = THREE.MathUtils.lerp(walkSwingX, sprintSwingX, sprintAlpha * moveWeight);
        const bobY = THREE.MathUtils.lerp(walkSwingY, sprintSwingY, sprintAlpha * moveWeight);
        const bobZ = sprintSwingZ * sprintAlpha * moveWeight;

        const sprintRotPumpX =
          Math.sin(stridePhase * 2 - 0.25) * 0.021 * sprintAlpha * moveWeight;
        const sprintRotPumpY = Math.cos(stridePhase) * 0.024 * sprintAlpha * moveWeight;
        const sprintRotPumpZ = -Math.cos(stridePhase) * 0.018 * sprintAlpha * moveWeight;

        // Tactical CQB Low-Ready Cant when Crouched (`C`)!
        const crouchCantZ = -crouchAlpha * 0.085 * (1 - adsAlpha) * (1 - sprintAlpha);
        const crouchTuckX = -crouchAlpha * 0.014 * (1 - adsAlpha) * (1 - sprintAlpha);
        const crouchTuckY = -crouchAlpha * 0.008 * (1 - adsAlpha) * (1 - sprintAlpha);

        // Determine Target Base Pose with Spring-Driven Sprint Transition (`sprintSpringVal`):
        const useGambar1 = poseMode === 'RELOADING' || poseMode === 'INSPECT_POSE_1';
        const baseReady = POSE_READY_GAMBAR_2[currentWeapon];
        const baseAds = POSE_ADS_PRECISION[currentWeapon];
        const baseGambar1 = POSE_RELOAD_GAMBAR_1[currentWeapon];
        const baseSprint = POSE_TACTICAL_SPRINT[currentWeapon];

        const desiredPos = new THREE.Vector3();
        const desiredRot = new THREE.Euler();

        if (useGambar1) {
          if (poseMode === 'RELOADING' && reloadProgress > 0.86) {
            const exitBlend = 1 - Math.pow(1 - (reloadProgress - 0.86) / 0.14, 2.5);
            desiredPos.lerpVectors(baseGambar1.pos, baseReady.pos, exitBlend);
            desiredRot.set(
              THREE.MathUtils.lerp(baseGambar1.rot.x, baseReady.rot.x, exitBlend),
              THREE.MathUtils.lerp(baseGambar1.rot.y, baseReady.rot.y, exitBlend),
              THREE.MathUtils.lerp(baseGambar1.rot.z, baseReady.rot.z, exitBlend)
            );
          } else {
            desiredPos.copy(baseGambar1.pos);
            desiredRot.copy(baseGambar1.rot);
          }
        } else {
          const readyOrAdsPos = new THREE.Vector3().lerpVectors(baseReady.pos, baseAds.pos, adsAlpha);
          const readyOrAdsRotX = THREE.MathUtils.lerp(baseReady.rot.x, baseAds.rot.x, adsAlpha);
          const readyOrAdsRotY = THREE.MathUtils.lerp(baseReady.rot.y, baseAds.rot.y, adsAlpha);
          const readyOrAdsRotZ = THREE.MathUtils.lerp(baseReady.rot.z, baseAds.rot.z, adsAlpha);

          const activeSprintBlend =
            poseMode === 'BOLT_CYCLE' ? 0 : sprintSpringVal * (1 - adsAlpha);
          desiredPos.lerpVectors(readyOrAdsPos, baseSprint.pos, activeSprintBlend);
          desiredRot.set(
            THREE.MathUtils.lerp(readyOrAdsRotX, baseSprint.rot.x, activeSprintBlend),
            THREE.MathUtils.lerp(readyOrAdsRotY, baseSprint.rot.y, activeSprintBlend),
            THREE.MathUtils.lerp(readyOrAdsRotZ, baseSprint.rot.z, activeSprintBlend)
          );

          if (poseMode === 'BOLT_CYCLE') {
            const c = Math.sin(boltProgress * Math.PI);
            desiredRot.z -= c * 0.14;
            desiredRot.x += c * 0.08;
            desiredPos.x -= c * 0.025;
          }
        }

        const lerpSpeed = 1 - Math.exp(-(poseMode === 'RELOADING' ? 21 : 16.5) * realDt);
        rig.root.position.lerp(
          new THREE.Vector3(
            desiredPos.x + crouchTuckX + recoilOffset.x + swayOffset.x + bodycamFreeAimPos.x + bobX,
            desiredPos.y + crouchTuckY + recoilOffset.y + swayOffset.y + bodycamFreeAimPos.y + bobY + equipDrop + landingDipY * 0.22,
            desiredPos.z + recoilOffset.z + bobZ
          ),
          lerpSpeed
        );

        rig.root.rotation.x = THREE.MathUtils.lerp(
          rig.root.rotation.x,
          desiredRot.x + recoilRot.x + bodycamFreeAimRot.x + sprintRotPumpX,
          lerpSpeed
        );
        rig.root.rotation.y = THREE.MathUtils.lerp(
          rig.root.rotation.y,
          desiredRot.y + recoilRot.y + bodycamFreeAimRot.y + sprintRotPumpY,
          lerpSpeed
        );
        rig.root.rotation.z = THREE.MathUtils.lerp(
          rig.root.rotation.z,
          desiredRot.z + crouchCantZ + recoilRot.z + bodycamFreeAimRot.z + sprintRotPumpZ,
          lerpSpeed
        );

        // Keep 3D Sniper Scope visible at all times so you look directly through its Live 3D Magnifying Glass Lens!
        rig.root.visible = true;
        const isSniperAimingGlass = currentWeapon === 'sniper' && adsAlpha > 0.65;

        // 6. Update World Bots, Targets & 3D Ballistics Particles
        const enemiesAlive = world.update(
          simDt,
          playerPos,
          gameMode === 'COMBAT',
          (dmg) => {
            if (armor > 0) {
              const absorbed = Math.min(armor, dmg * 0.65);
              armor = Math.max(0, armor - absorbed);
              health = Math.max(15, health - (dmg - absorbed));
            } else {
              health = Math.max(15, health - dmg);
            }
          }
        );

        if (gameMode === 'COMBAT') {
          if (enemiesAlive === 0) {
            waveClearCooldown += realDt;
            if (waveClearCooldown >= 2.2) {
              waveClearCooldown = 0;
              wave++;
              health = Math.min(maxHealth, health + 35);
              armor = Math.min(100, armor + 30);
              world.spawnWaveBots(wave);
            }
          } else {
            waveClearCooldown = 0;
          }
          if (health < maxHealth) {
            health = Math.min(maxHealth, health + realDt * 2.2);
          }
        }

        ballistics.update(simDt);

        // 7A. JITTER-FREE REAL-TIME MAGNIFYING GLASS SCOPE RENDER PASS (1024x1024 4x-MSAA!)
        if (currentWeapon === 'sniper' && rigs.sniper.scopeLensUniforms) {
          const lensUni = rigs.sniper.scopeLensUniforms!;
          lensUni.uAdsBlend.value = adsAlpha;
          // Smooth subtle optical eye-relief parallax without high-frequency shake
          lensUni.uEyeOffset.value.set(
            THREE.MathUtils.clamp(swayOffset.x * 1.4, -0.075, 0.075),
            THREE.MathUtils.clamp(swayOffset.y * 1.4, -0.075, 0.075)
          );

          // Stabilized optical axis (decoupled from footstep bob & weapon viewmodel spring -> ZERO JITTER!)
          scopeMagnifierCamera.position.set(
            playerPos.x,
            playerPos.y + landingDipY * 0.35,
            playerPos.z
          );
          scopeMagnifierCamera.rotation.order = 'YXZ';
          scopeMagnifierCamera.rotation.y = smoothYaw + recoilCameraYaw;
          scopeMagnifierCamera.rotation.x = THREE.MathUtils.clamp(
            smoothPitch + recoilCameraPitch + scopeBreath * 0.45,
            -1.42,
            1.42
          );
          scopeMagnifierCamera.rotation.z = 0;

          renderer.setRenderTarget(scopeRenderTarget);
          renderer.clear();
          renderer.render(world.scene, scopeMagnifierCamera);
          renderer.setRenderTarget(null);
        }

        // 7B. Main Dual-Pass Render: Render 3D World -> Clear Depth Buffer -> Render Crisp Polygon Hands & Weapon!
        renderer.clear();
        renderer.render(world.scene, worldCamera);
        renderer.clearDepth();
        renderer.render(vmScene, vmCamera);

        // 8. Project Live 3D Simulation Anchor Points to 2D Screen for HUD Callouts (~30fps UI update)
        hudThrottle += realDt;
        if (hudThrottle >= 0.032) {
          hudThrottle = 0;
          vmScene.updateMatrixWorld(true);
          const anchors: WeaponAnchors2D = isSniperAimingGlass
            ? {
                muzzle: { x: 0, y: 0, visible: false },
                ejection: { x: 0, y: 0, visible: false },
                mechanism: { x: 0, y: 0, visible: false },
                magazine: { x: 0, y: 0, visible: false },
              }
            : {
                muzzle: projectVmAnchor(rig.muzzleAnchor).screen,
                ejection: projectVmAnchor(rig.ejectionAnchor).screen,
                mechanism: projectVmAnchor(rig.mechanismAnchor).screen,
                magazine: projectVmAnchor(rig.magAnchor).screen,
              };

          onHudUpdate({
            weaponId: currentWeapon,
            ammo: { ...ammo },
            reserve: { ...reserve },
            fireMode: weaponFireModes[currentWeapon],
            poseMode,
            reloadProgress,
            reloadStageLabel,
            boltProgress,
            isAds,
            isSniperScoped: false,
            isSprinting: sprintAlpha > 0.35,
            isCrouching,
            bodycamMode,
            slowMo,
            showCallouts,
            gameMode,
            pointerLocked,
            health: Math.round(health),
            maxHealth,
            armor: Math.round(armor),
            score,
            kills,
            shotsFired,
            shotsHit,
            headshots,
            wave,
            enemiesAlive,
            anchors,
            lastShotPulse,
            lastEjectPulse,
            hitmarkerType,
            hitmarkerTime,
          });
        }
      };

      animFrameId = requestAnimationFrame(animate);

      return () => {
        cancelAnimationFrame(animFrameId);
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('keyup', handleKeyUp);
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mousedown', handleMouseDown);
        window.removeEventListener('mouseup', handleMouseUp);
        window.removeEventListener('wheel', handleWheel);
        window.removeEventListener('contextmenu', handleContextMenu);
        document.removeEventListener('pointerlockchange', handlePointerLockChange);
        window.removeEventListener('resize', handleResize);
        ballistics.dispose();
        scopeRenderTarget.dispose();
        renderer.dispose();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
      };
    }, [onDamagePopup, onHudUpdate, onShotLog]);

    return <div ref={containerRef} className="w-full h-full relative cursor-crosshair" />;
  }
);

GameCanvas.displayName = 'GameCanvas';
