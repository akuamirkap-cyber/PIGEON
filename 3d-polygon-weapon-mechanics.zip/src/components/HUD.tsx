import React from 'react';
import {
  Crosshair,
  Flame,
  Gauge,
  Layers,
  Play,
  RotateCw,
  Shield,
  Sparkles,
  Target,
  Video,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  DamagePopup,
  HudSnapshot,
  ShotLogEntry,
  WEAPON_SPECS,
  WeaponId,
} from '../game/types';

interface HUDProps {
  hud: HudSnapshot;
  shotLogs: ShotLogEntry[];
  damagePopups: DamagePopup[];
  muted: boolean;
  onToggleMute: () => void;
  onSelectWeapon: (id: WeaponId) => void;
  onTriggerReload: () => void;
  onTriggerSimShot: () => void;
  onTogglePose1: () => void;
  onToggleBodycam: () => void;
  onToggleSlowMo: () => void;
  onToggleCallouts: () => void;
  onToggleGameMode: () => void;
  onCycleFireMode: () => void;
  onEnterPointerLock: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  hud,
  shotLogs,
  damagePopups,
  muted,
  onToggleMute,
  onSelectWeapon,
  onTriggerReload,
  onTriggerSimShot,
  onTogglePose1,
  onToggleBodycam,
  onToggleSlowMo,
  onToggleCallouts,
  onToggleGameMode,
  onCycleFireMode,
  onEnterPointerLock,
}) => {
  const activeSpec = WEAPON_SPECS[hud.weaponId];
  const currentAmmo = hud.ammo[hud.weaponId];
  const currentReserve = hud.reserve[hud.weaponId];
  const accuracy =
    hud.shotsFired > 0 ? Math.round((hud.shotsHit / hud.shotsFired) * 100) : 100;

  const now = performance.now();
  const shotRecent = now - hud.lastShotPulse < (hud.slowMo ? 550 : 180);
  const ejectRecent = now - hud.lastEjectPulse < (hud.slowMo ? 650 : 240);
  const showHitmarker = hud.hitmarkerType !== 'none' && now - hud.hitmarkerTime < 220;

  return (
    <div className="pointer-events-none fixed inset-0 z-20 overflow-hidden">
      {/* Subtle Bodycam & Tactical Sprint Peripheral Lens Vignette */}
      {(hud.bodycamMode || hud.isSprinting) && !hud.isSniperScoped && (
        <div
          className="fixed inset-0 z-5 transition-opacity duration-300"
          style={{
            opacity: hud.isSprinting ? 0.72 : 0.36,
            background:
              'radial-gradient(circle at center, transparent 58%, rgba(4, 8, 16, 0.38) 88%, rgba(2, 5, 12, 0.72) 100%)',
          }}
        />
      )}

      {/* =====================================================================
          SNIPER FULL OPTICAL SCOPE OVERLAY (Active when holding Right Click on Sniper)
      ===================================================================== */}
      {hud.isSniperScoped && (
        <div className="fixed inset-0 z-10 flex items-center justify-center">
          {/* Vignette mask */}
          <div
            className="absolute inset-0"
            style={{
              background:
                'radial-gradient(circle at center, transparent 27%, rgba(5, 9, 15, 0.96) 31%, #04070c 46%)',
            }}
          />
          {/* Crisp Mil-Dot Sniper Reticle */}
          <div className="relative w-[56vmin] h-[56vmin] rounded-full border-2 border-slate-700/80 shadow-[0_0_60px_rgba(0,0,0,0.95)] flex items-center justify-center">
            <div className="absolute inset-x-0 h-[1px] bg-slate-900/85" />
            <div className="absolute inset-y-0 w-[1px] bg-slate-900/85" />
            {/* Mildot ticks */}
            {[-3, -2, -1, 1, 2, 3].map((t) => (
              <React.Fragment key={t}>
                <div
                  className="absolute w-1.5 h-1.5 rounded-full bg-red-500/90"
                  style={{ left: `calc(50% + ${t * 26}px)`, top: '50%', transform: 'translate(-50%, -50%)' }}
                />
                <div
                  className="absolute w-1.5 h-1.5 rounded-full bg-slate-900"
                  style={{ top: `calc(50% + ${t * 26}px)`, left: '50%', transform: 'translate(-50%, -50%)' }}
                />
              </React.Fragment>
            ))}
            <div className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_10px_#ef4444]" />
            <div className="absolute bottom-6 text-[11px] font-tactical tracking-widest text-emerald-300/90 bg-slate-950/75 px-2.5 py-0.5 rounded border border-emerald-500/30">
              OPTIK 4.5× • .338 LAPUA MAGNUM
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          DYNAMIC CENTER CROSSHAIR & HITMARKER
      ===================================================================== */}
      {!hud.isSniperScoped && (
        <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex items-center justify-center">
          {/* Dynamic Tactical Crosshair (hides during Rifle/Sniper 3D Optic ADS so live 3D reticle shines!) */}
          {!(hud.isAds && (hud.weaponId === 'rifle' || hud.weaponId === 'sniper')) && (
            <div
              className={`relative transition-all duration-150 ${
                shotRecent
                  ? 'scale-125'
                  : hud.isSprinting
                  ? 'scale-150 opacity-35'
                  : hud.isCrouching
                  ? 'scale-90'
                  : hud.isAds
                  ? 'scale-75 opacity-85'
                  : 'scale-100'
              }`}
            >
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />
              <div className="absolute left-1/2 -top-3.5 -translate-x-1/2 w-0.5 h-2 bg-white/90 shadow" />
              <div className="absolute left-1/2 -bottom-3.5 -translate-x-1/2 w-0.5 h-2 bg-white/90 shadow" />
              <div className="absolute -left-3.5 top-1/2 -translate-y-1/2 w-2 h-0.5 bg-white/90 shadow" />
              <div className="absolute -right-3.5 top-1/2 -translate-y-1/2 w-2 h-0.5 bg-white/90 shadow" />
            </div>
          )}

          {/* Hitmarker X */}
          {showHitmarker && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div
                className={`w-6 h-6 relative ${
                  hud.hitmarkerType === 'head' ? 'text-amber-400 scale-125' : 'text-white'
                }`}
              >
                <span className="absolute left-0 top-1/2 w-2.5 h-0.5 bg-current rotate-45 -translate-y-2 -translate-x-1" />
                <span className="absolute right-0 top-1/2 w-2.5 h-0.5 bg-current -rotate-45 -translate-y-2 translate-x-1" />
                <span className="absolute left-0 bottom-1/2 w-2.5 h-0.5 bg-current -rotate-45 translate-y-2 -translate-x-1" />
                <span className="absolute right-0 bottom-1/2 w-2.5 h-0.5 bg-current rotate-45 translate-y-2 translate-x-1" />
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          FLOATING 2D DAMAGE & HEADSHOT POPUPS
      ===================================================================== */}
      {damagePopups.map((dp) => (
        <div
          key={dp.id}
          className="fixed z-30 animate-damage-float font-tactical font-bold pointer-events-none"
          style={{ left: dp.x, top: dp.y }}
        >
          <div
            className={`px-2 py-0.5 rounded text-sm shadow-lg ${
              dp.isHeadshot
                ? 'bg-amber-500/95 text-slate-950 border border-yellow-200'
                : 'bg-slate-900/85 text-white border border-white/20'
            }`}
          >
            {dp.isHeadshot ? `HEADSHOT! -${dp.damage}` : `-${dp.damage}`}
            <span className="ml-1.5 text-[10px] opacity-80">{dp.distanceM}m</span>
          </div>
        </div>
      ))}

      {/* =====================================================================
          LIVE 3D-TO-2D WEAPON SIMULATION CALLOUT PINS (Muzzle, Ejection Port, Slide/Bolt!)
      ===================================================================== */}
      {hud.showCallouts && !hud.isSniperScoped && (
        <div className="fixed inset-0 z-15 pointer-events-none">
          {/* 1. MUZZLE ANCHOR PIN (Quadrant Upper-Left): Where Bullet, Muzzle Flash & Barrel Smoke exit */}
          {hud.anchors.muzzle.visible && (
            <div
              className="absolute"
              style={{ left: hud.anchors.muzzle.x, top: hud.anchors.muzzle.y }}
            >
              <div className="relative -translate-x-1/2 -translate-y-1/2">
                <div
                  className={`w-4 h-4 rounded-full border-2 border-orange-400 bg-orange-500/30 shadow-[0_0_12px_#fb923c] ${
                    shotRecent ? 'scale-150 bg-orange-400/75' : ''
                  }`}
                />
                {shotRecent && (
                  <div className="absolute left-1/2 top-1/2 w-11 h-11 rounded-full border-2 border-amber-300 animate-pulse-ring" />
                )}
              </div>
              <div className="absolute -left-6 top-[-18px] w-7 h-[1.5px] bg-orange-400/80 rotate-[28deg] origin-right" />
              <div className="absolute -left-60 -top-16 w-54 bg-slate-950/86 backdrop-blur-md border border-orange-500/55 rounded-lg px-2.5 py-1.5 shadow-xl">
                <div className="flex items-center gap-1.5 text-[10px] font-tactical font-bold text-orange-400 uppercase tracking-wider">
                  <Flame className="w-3 h-3 shrink-0" />
                  TITIK KELUAR PELURU & API
                </div>
                <p className="text-[10px] leading-snug text-slate-200 mt-0.5">
                  {hud.weaponId === 'pistol' && 'Proyektil 9mm + Api Bintang + Asap Laras'}
                  {hud.weaponId === 'rifle' && 'Peluru 5.56mm + Api Birdcage 4-Arah + Asap'}
                  {hud.weaponId === 'sniper' && 'Proyektil .338 + Gelombang Kejut + Semburan'}
                </p>
              </div>
            </div>
          )}

          {/* 2. EJECTION PORT ANCHOR PIN (Quadrant Upper-Right): Where 3D Brass Shell Casing & Chamber Gas exit */}
          {hud.anchors.ejection.visible && (
            <div
              className="absolute"
              style={{ left: hud.anchors.ejection.x, top: hud.anchors.ejection.y }}
            >
              <div className="relative -translate-x-1/2 -translate-y-1/2">
                <div
                  className={`w-4 h-4 rounded-full border-2 border-yellow-300 bg-yellow-400/30 shadow-[0_0_12px_#facc15] ${
                    ejectRecent ? 'scale-150 bg-yellow-300/85' : ''
                  }`}
                />
                {ejectRecent && (
                  <div className="absolute left-1/2 top-1/2 w-11 h-11 rounded-full border-2 border-yellow-300 animate-pulse-ring" />
                )}
              </div>
              {hud.weaponId === 'sniper' ? (
                <>
                  <div className="absolute -left-6 top-[-20px] w-7 h-[1.5px] bg-yellow-300/80 rotate-[32deg] origin-right" />
                  <div className="absolute -left-60 -top-20 w-56 bg-slate-950/86 backdrop-blur-md border border-yellow-400/55 rounded-lg px-2.5 py-1.5 shadow-xl">
                    <div className="flex items-center gap-1.5 text-[10px] font-tactical font-bold text-yellow-300 uppercase tracking-wider">
                      <Sparkles className="w-3 h-3 shrink-0" />
                      TITIK SELONSONG KELUAR
                    </div>
                    <p className="text-[10px] leading-snug text-slate-200 mt-0.5">
                      {activeSpec.simulationInfo.casingDirection}
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <div className="absolute left-1 top-[-16px] w-7 h-[1.5px] bg-yellow-300/80 -rotate-[25deg] origin-left" />
                  <div className="absolute left-7 -top-16 w-56 bg-slate-950/86 backdrop-blur-md border border-yellow-400/55 rounded-lg px-2.5 py-1.5 shadow-xl">
                    <div className="flex items-center gap-1.5 text-[10px] font-tactical font-bold text-yellow-300 uppercase tracking-wider">
                      <Sparkles className="w-3 h-3 shrink-0" />
                      TITIK SELONSONG KELUAR
                    </div>
                    <p className="text-[10px] leading-snug text-slate-200 mt-0.5">
                      {activeSpec.simulationInfo.casingDirection}
                    </p>
                  </div>
                </>
              )}
            </div>
          )}

          {/* 3. MECHANISM ANCHOR PIN (Quadrant Lower-Left): Slide Blowback / Bolt Carrier / Sniper Bolt Knob */}
          {hud.anchors.mechanism.visible && (
            <div
              className="absolute"
              style={{ left: hud.anchors.mechanism.x, top: hud.anchors.mechanism.y }}
            >
              <div className="w-3 h-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-cyan-400 bg-cyan-400/35 shadow-[0_0_10px_#22d3ee]" />
              <div className="absolute -left-6 top-2 w-7 h-[1.5px] bg-cyan-400/80 -rotate-[22deg] origin-right" />
              <div className="absolute -left-56 top-4 w-50 bg-slate-950/84 backdrop-blur-md border border-cyan-400/50 rounded-lg px-2.5 py-1 shadow-xl">
                <div className="text-[10px] font-tactical font-bold text-cyan-300 uppercase">
                  {hud.weaponId === 'pistol' && 'MEKANISME SLIDE BLOWBACK'}
                  {hud.weaponId === 'rifle' && 'BOLT CARRIER RESIPROKAL'}
                  {hud.weaponId === 'sniper' && 'TUAS KOKANG BOLT-ACTION'}
                </div>
              </div>
            </div>
          )}

          {/* 4. MAGAZINE ANCHOR PIN (Quadrant Lower-Right — Highlighted in Gambar 1 Reload / Inspect Pose!) */}
          {(hud.poseMode === 'RELOADING' || hud.poseMode === 'INSPECT_POSE_1') &&
            hud.anchors.magazine.visible && (
              <div
                className="absolute"
                style={{ left: hud.anchors.magazine.x, top: hud.anchors.magazine.y }}
              >
                <div className="w-3.5 h-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-emerald-400 bg-emerald-400/35 shadow-[0_0_10px_#34d399]" />
                <div className="absolute left-2 top-3 w-7 h-[1.5px] bg-emerald-400/80 rotate-[20deg] origin-left" />
                <div className="absolute left-8 top-4 w-48 bg-slate-950/86 border border-emerald-400/55 rounded-lg px-2.5 py-1 shadow-xl">
                  <div className="text-[10px] font-tactical font-bold text-emerald-300 uppercase">
                    SLOT MAGAZEN ({activeSpec.magSize} PELURU)
                  </div>
                </div>
              </div>
            )}
        </div>
      )}

      {/* =====================================================================
          TOP HEADER BAR: POSE INDICATOR (GAMBAR 1 vs GAMBAR 2), WAVE/STATS & QUICK LAB CONTROLS
      ===================================================================== */}
      <div className="fixed top-3 inset-x-4 flex flex-wrap items-start justify-between gap-3 z-30">
        {/* Top-Left: Combat Stats & Mode Switch */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 bg-slate-950/80 backdrop-blur-md border border-white/15 rounded-xl px-3.5 py-2 shadow-xl">
            <div className="flex items-center gap-2 pr-3 border-r border-white/15">
              <Target className="w-4 h-4 text-emerald-400" />
              <div>
                <div className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                  {hud.gameMode === 'COMBAT' ? `GELOMBANG ${hud.wave}` : 'LAB & LAPANGAN TEMBAK'}
                </div>
                <div className="text-sm font-tactical font-bold text-white">
                  {hud.gameMode === 'COMBAT'
                    ? `${hud.enemiesAlive} Bot Aktif • ${hud.kills} Eliminasi`
                    : 'Target 15m / 40m / 89m Aktif'}
                </div>
              </div>
            </div>

            <div className="px-2 text-center">
              <div className="text-[10px] text-slate-400 uppercase">Skor</div>
              <div className="text-sm font-tactical font-bold text-amber-300">{hud.score}</div>
            </div>

            <div className="px-2 text-center border-l border-white/10">
              <div className="text-[10px] text-slate-400 uppercase">Akurasi</div>
              <div className="text-sm font-tactical font-bold text-cyan-300">{accuracy}%</div>
            </div>

            <div className="pl-2 text-center border-l border-white/10">
              <div className="text-[10px] text-slate-400 uppercase">Headshot</div>
              <div className="text-sm font-tactical font-bold text-rose-400">{hud.headshots}</div>
            </div>
          </div>

          {/* Health & Tactical Shield Bar */}
          <div className="flex items-center gap-3 bg-slate-950/75 backdrop-blur-md border border-white/10 rounded-xl px-3.5 py-1.5 w-fit">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-tactical font-bold text-emerald-400">HP {hud.health}</span>
              <div className="w-24 h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-lime-400 transition-all"
                  style={{ width: `${(hud.health / hud.maxHealth) * 100}%` }}
                />
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-[11px] font-tactical font-bold text-sky-300">{hud.armor}</span>
              <div className="w-16 h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-sky-400 transition-all"
                  style={{ width: `${hud.armor}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Top-Center: LIVE ANGLE / POSE STATUS BADGE (GAMBAR 1 vs GAMBAR 2) */}
        <div className="flex flex-col items-center gap-1.5">
          <div
            className={`px-4 py-1.5 rounded-full border backdrop-blur-md shadow-xl font-tactical text-xs font-bold tracking-wider flex items-center gap-2 transition-all ${
              hud.poseMode === 'RELOADING'
                ? 'bg-amber-500/25 border-amber-400 text-amber-200'
                : hud.poseMode === 'SPRINTING'
                ? 'bg-cyan-500/25 border-cyan-400 text-cyan-100'
                : hud.poseMode === 'INSPECT_POSE_1'
                ? 'bg-sky-500/25 border-sky-400 text-sky-200'
                : hud.poseMode === 'BOLT_CYCLE'
                ? 'bg-yellow-500/25 border-yellow-300 text-yellow-200'
                : 'bg-emerald-500/20 border-emerald-400/70 text-emerald-200'
            }`}
          >
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                hud.poseMode === 'RELOADING'
                  ? 'bg-amber-400 animate-ping'
                  : hud.poseMode === 'SPRINTING'
                  ? 'bg-cyan-300 animate-ping'
                  : hud.poseMode === 'BOLT_CYCLE'
                  ? 'bg-yellow-300 animate-ping'
                  : hud.poseMode === 'INSPECT_POSE_1'
                  ? 'bg-sky-400'
                  : 'bg-emerald-400'
              }`}
            />
            {hud.poseMode === 'READY' &&
              (hud.isAds
                ? `BIDIK PRESISI AKTIF • ${activeSpec.label}`
                : `MODE SIAP NEMBAK (SUDUT GAMBAR 2) • ${activeSpec.label}`)}
            {hud.poseMode === 'SPRINTING' &&
              `MODE LARI TAKTIS (TAC-SPRINT POV) • ${activeSpec.label}`}
            {hud.poseMode === 'RELOADING' &&
              `MENGISI AMMO / RELOAD (SUDUT GAMBAR 1) • ${Math.round(hud.reloadProgress * 100)}%`}
            {hud.poseMode === 'INSPECT_POSE_1' &&
              `PRATINJAU SUDUT GAMBAR 1 (POSE ISI AMMO) • ${activeSpec.label}`}
            {hud.poseMode === 'BOLT_CYCLE' &&
              `SIKLUS KOKANG BOLT SNIPER & EJEKSI SELONSONG .338`}
          </div>

          {/* Reload Stage Progress Bar */}
          {hud.poseMode === 'RELOADING' && (
            <div className="w-72 bg-slate-950/85 border border-amber-400/40 rounded-lg px-3 py-1.5 shadow-lg">
              <div className="flex justify-between text-[11px] font-medium text-amber-200 mb-1">
                <span>{hud.reloadStageLabel}</span>
                <span>{Math.round(hud.reloadProgress * 100)}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-400 transition-all duration-75"
                  style={{ width: `${hud.reloadProgress * 100}%` }}
                />
              </div>
            </div>
          )}

          {hud.isCrouching && (
            <div className="px-3 py-0.5 rounded-full bg-teal-600/85 border border-teal-300 text-[11px] font-tactical font-bold text-white shadow">
              🛡️ MODE JONGKOK TAKTIS [C] AKTIF (RECOIL STABIL)
            </div>
          )}

          {hud.slowMo && (
            <div className="px-3 py-0.5 rounded-full bg-purple-600/85 border border-purple-300 text-[11px] font-tactical font-bold text-white shadow">
              ⏱️ SIMULASI GERAK LAMBAT (0.2× SPEED) AKTIF
            </div>
          )}
        </div>

        {/* Top-Right: Interactive Simulation Lab Controls */}
        <div
          data-ui-interactive="true"
          className="pointer-events-auto flex flex-wrap items-center justify-end gap-1.5 max-w-md"
        >
          <button
            onClick={onTriggerSimShot}
            className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-400 text-slate-950 font-tactical font-bold text-xs shadow-lg flex items-center gap-1.5 cursor-pointer transition active:scale-95"
            title="Uji tembak langsung & amati peluru + selongsong keluar"
          >
            <Flame className="w-3.5 h-3.5" />
            UJI TEMBAK
          </button>

          <button
            onClick={onTriggerReload}
            className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/35 border border-amber-400/60 text-amber-200 font-tactical font-bold text-xs flex items-center gap-1.5 cursor-pointer transition"
            title="Masuk sudut Gambar 1 & animasi isi ammo [R]"
          >
            <RotateCw className="w-3.5 h-3.5" />
            ISI AMMO [R]
          </button>

          <button
            onClick={onTogglePose1}
            className={`px-3 py-1.5 rounded-lg border font-tactical font-bold text-xs flex items-center gap-1.5 cursor-pointer transition ${
              hud.poseMode === 'INSPECT_POSE_1'
                ? 'bg-sky-500 text-slate-950 border-sky-300'
                : 'bg-slate-900/85 hover:bg-slate-800 border-white/20 text-slate-200'
            }`}
            title="Bandingkan sudut Gambar 1 (Isi Ammo) vs Gambar 2 (Siap Nembak) [F]"
          >
            <Layers className="w-3.5 h-3.5" />
            {hud.poseMode === 'INSPECT_POSE_1' ? 'KEMBALI GAMBAR 2 [F]' : 'LIHAT GAMBAR 1 [F]'}
          </button>

          <button
            onClick={onToggleBodycam}
            className={`px-3 py-1.5 rounded-lg border font-tactical font-bold text-xs flex items-center gap-1.5 cursor-pointer transition ${
              hud.bodycamMode
                ? 'bg-cyan-500/25 border-cyan-400/75 text-cyan-200 shadow-[0_0_12px_rgba(34,211,238,0.28)]'
                : 'bg-slate-900/85 hover:bg-slate-800 border-white/20 text-slate-300'
            }`}
            title="Smooth Bodycam Inertia & Roll Camera [V]"
          >
            <Video className="w-3.5 h-3.5" />
            BODYCAM {hud.bodycamMode ? 'ON' : 'OFF'} [V]
          </button>

          <button
            onClick={onToggleSlowMo}
            className={`px-3 py-1.5 rounded-lg border font-tactical font-bold text-xs flex items-center gap-1.5 cursor-pointer transition ${
              hud.slowMo
                ? 'bg-purple-500 text-white border-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.6)]'
                : 'bg-slate-900/85 hover:bg-slate-800 border-white/20 text-slate-200'
            }`}
            title="Perlambat simulasi 0.2x untuk melihat peluru & selongsong [Z]"
          >
            <Gauge className="w-3.5 h-3.5" />
            SLOW-MO [Z]
          </button>

          <button
            onClick={onToggleCallouts}
            className={`px-2.5 py-1.5 rounded-lg border font-tactical font-bold text-xs cursor-pointer transition ${
              hud.showCallouts
                ? 'bg-emerald-500/25 border-emerald-400/60 text-emerald-200'
                : 'bg-slate-900/85 border-white/15 text-slate-400'
            }`}
            title="Tampilkan/sembunyikan penanda titik keluar peluru & selongsong [T]"
          >
            PIN SIMULASI [T]
          </button>

          <button
            onClick={onToggleGameMode}
            className="px-2.5 py-1.5 rounded-lg bg-slate-900/85 hover:bg-slate-800 border border-white/20 text-slate-200 font-tactical font-bold text-xs cursor-pointer transition"
          >
            {hud.gameMode === 'COMBAT' ? 'KE LAPANGAN TEMBAK [M]' : 'KE ARENA BOT [M]'}
          </button>

          <button
            onClick={onToggleMute}
            className="p-1.5 rounded-lg bg-slate-900/85 hover:bg-slate-800 border border-white/20 text-slate-200 cursor-pointer"
            title={muted ? 'Nyalakan Suara' : 'Matikan Suara'}
          >
            {muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* =====================================================================
          CENTER-LEFT CLICK-TO-PLAY PROMPT (Non-blocking compact banner when mouse unlocked)
      ===================================================================== */}
      {!hud.pointerLocked && (
        <div
          data-ui-interactive="true"
          className="pointer-events-auto fixed left-4 top-32 z-30 max-w-xs bg-slate-950/88 backdrop-blur-md border border-emerald-400/45 rounded-2xl p-3.5 shadow-2xl"
        >
          <div className="flex items-center gap-2 text-emerald-300 font-tactical font-bold text-sm">
            <Crosshair className="w-4 h-4 shrink-0" />
            MODE KONTROL FPS PENUH
          </div>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            Klik area layar 3D atau tombol di bawah untuk mengunci mouse Smooth Bodycam 360°, jalan{' '}
            <span className="text-white font-semibold">WASD</span>, lari taktis{' '}
            <span className="text-cyan-300 font-semibold">Shift + W</span>, tembak{' '}
            <span className="text-white font-semibold">Klik Kiri</span>, dan bidik{' '}
            <span className="text-white font-semibold">Klik Kanan</span>.
          </p>
          <button
            onClick={onEnterPointerLock}
            className="mt-2.5 w-full py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-tactical font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg cursor-pointer transition"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            MULAI KONTROL MOUSE FPS (ESC UNTUK LEPAS)
          </button>
        </div>
      )}

      {/* =====================================================================
          LEFT-BOTTOM SIMULATION BREAKDOWN CARD & LIVE SHOT LOG
      ===================================================================== */}
      <div className="fixed left-4 bottom-20 z-20 max-w-sm hidden md:flex flex-col gap-2">
        {/* Active Weapon Mechanics Card */}
        <div className="bg-slate-950/82 backdrop-blur-md border border-white/15 rounded-xl p-3 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-1.5 mb-2">
            <div>
              <span className="text-xs font-tactical font-bold text-amber-300 uppercase">
                SIMULASI BALISTIK • {activeSpec.label}
              </span>
              <span className="ml-2 text-[11px] text-slate-400">{activeSpec.caliber}</span>
            </div>
            <span className="text-[10px] font-mono bg-slate-800 px-1.5 py-0.5 rounded text-cyan-300">
              {activeSpec.muzzleVelocityText}
            </span>
          </div>

          <div className="space-y-1.5 text-[11px] leading-snug">
            <div>
              <span className="text-orange-400 font-semibold">• Ujung Laras (Moncong): </span>
              <span className="text-slate-200">{activeSpec.simulationInfo.muzzleOutput}</span>
            </div>
            <div>
              <span className="text-yellow-300 font-semibold">• Lubang Ejeksi: </span>
              <span className="text-slate-200">{activeSpec.simulationInfo.ejectionOutput}</span>
            </div>
            <div>
              <span className="text-cyan-300 font-semibold">• Animasi Senjata: </span>
              <span className="text-slate-200">{activeSpec.simulationInfo.mechanicalAction}</span>
            </div>
          </div>
        </div>

        {/* Live Telemetry Log of Most Recent Shot */}
        {shotLogs.length > 0 && (
          <div className="bg-slate-950/75 backdrop-blur-md border border-orange-400/30 rounded-xl px-3 py-2 shadow-lg">
            <div className="flex items-center justify-between text-[10px] font-tactical text-orange-300 uppercase">
              <span>LOG TEMBAKAN TERAKHIR #{shotLogs[0].id}</span>
              {shotLogs[0].hitText && (
                <span
                  className={`px-1.5 py-0.2 rounded font-bold ${
                    shotLogs[0].isHeadshot
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-emerald-500/30 text-emerald-200'
                  }`}
                >
                  {shotLogs[0].hitText}
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-200 mt-0.5">{shotLogs[0].mechEvent}</div>
          </div>
        )}
      </div>

      {/* =====================================================================
          CENTER-BOTTOM WEAPON SELECTOR CARDS (PISTOL | RIFLE | SNIPER — Styled like Reference!)
      ===================================================================== */}
      <div
        data-ui-interactive="true"
        className="pointer-events-auto fixed bottom-14 left-1/2 -translate-x-1/2 z-30 flex items-end gap-2.5"
      >
        {(['pistol', 'rifle', 'sniper'] as WeaponId[]).map((wId, idx) => {
          const spec = WEAPON_SPECS[wId];
          const isSelected = hud.weaponId === wId;
          return (
            <button
              key={wId}
              onClick={() => onSelectWeapon(wId)}
              className={`group relative px-5 py-1.5 rounded-xl border backdrop-blur-md transition-all cursor-pointer flex flex-col items-center ${
                isSelected
                  ? 'bg-slate-900/92 border-amber-400 shadow-[0_0_24px_rgba(251,191,36,0.3)] -translate-y-1 scale-105'
                  : 'bg-slate-950/70 border-white/15 hover:border-white/35 opacity-80 hover:opacity-100'
              }`}
            >
              <span className="absolute top-1 left-2 text-[10px] font-tactical font-bold text-slate-400">
                [{idx + 1}]
              </span>
              <span className="font-weapon-label text-3xl leading-none text-white tracking-wider pt-1">
                {spec.label}
              </span>
              <span className="text-[10px] font-tactical text-slate-300">
                {hud.ammo[wId]}/{hud.reserve[wId]}
              </span>
            </button>
          );
        })}
      </div>

      {/* =====================================================================
          RIGHT-BOTTOM AMMO COUNTER + VISUAL BRASS CARTRIDGE STRIP + FIRE MODE
      ===================================================================== */}
      <div
        data-ui-interactive="true"
        className="pointer-events-auto fixed right-4 bottom-16 z-30 bg-slate-950/85 backdrop-blur-md border border-white/15 rounded-2xl px-4 py-3 shadow-2xl min-w-[230px]"
      >
        <div className="flex items-baseline justify-between gap-4">
          <div>
            <div className="text-[10px] font-tactical uppercase tracking-wider text-slate-400">
              {activeSpec.subtitle}
            </div>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span
                className={`text-4xl font-tactical font-bold leading-none ${
                  currentAmmo === 0
                    ? 'text-rose-500 animate-pulse'
                    : currentAmmo <= Math.ceil(activeSpec.magSize * 0.25)
                    ? 'text-amber-400'
                    : 'text-white'
                }`}
              >
                {currentAmmo}
              </span>
              <span className="text-lg font-tactical text-slate-400">/ {currentReserve}</span>
            </div>
          </div>

          <button
            onClick={onCycleFireMode}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-white/15 text-xs font-tactical font-bold text-amber-300 cursor-pointer"
            title="Ubah Mode Tembak [B]"
          >
            {hud.fireMode} {activeSpec.fireModes.length > 1 ? '[B]' : ''}
          </button>
        </div>

        {/* Visual Brass Cartridge Icons */}
        <div className="flex flex-wrap gap-1 mt-2.5 max-w-[220px]">
          {Array.from({ length: activeSpec.magSize }).map((_, idx) => {
            const filled = idx < currentAmmo;
            return (
              <div
                key={idx}
                className={`h-3.5 rounded-t-full transition-all ${
                  activeSpec.id === 'sniper' ? 'w-2.5' : activeSpec.id === 'pistol' ? 'w-2' : 'w-1.5'
                } ${
                  filled
                    ? 'bg-gradient-to-t from-amber-500 to-yellow-200 shadow-[0_0_4px_rgba(251,191,36,0.5)]'
                    : 'bg-slate-800/80'
                }`}
              />
            );
          })}
        </div>
      </div>

      {/* =====================================================================
          BOTTOM KEYBIND BAR (Styled cleanly like dark tactical bottom strip in Gambar 2!)
      ===================================================================== */}
      <div className="fixed bottom-0 inset-x-0 h-10 bg-slate-950/95 border-t border-white/10 px-4 flex items-center justify-center gap-4 md:gap-6 text-xs text-slate-300 z-30">
        <div className="flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-white">
            W A S D
          </kbd>
          <span>Gerak</span>
        </div>
        <div className="flex items-center gap-1.5">
          <kbd className="px-2 py-0.5 rounded border border-cyan-400/45 bg-slate-900 font-mono text-[11px] text-cyan-300">
            Shift + W
          </kbd>
          <span>Lari Cepat</span>
        </div>
        <div className="flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded border border-teal-400/45 bg-slate-900 font-mono text-[11px] text-teal-300">
            C
          </kbd>
          <span>Jongkok</span>
        </div>
        <div className="flex items-center gap-1.5">
          <kbd className="px-2 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-white">
            Spasi
          </kbd>
          <span>Lompat Kotak</span>
        </div>
        <div className="flex items-center gap-1.5">
          <kbd className="px-2 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-amber-300">
            Klik Kiri
          </kbd>
          <span>Tembak</span>
        </div>
        <div className="flex items-center gap-1.5">
          <kbd className="px-2 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-emerald-300">
            Klik Kanan
          </kbd>
          <span>Bidik / Scope</span>
        </div>
        <div className="flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-amber-300">
            R
          </kbd>
          <span>Isi Ammo (Gambar 1)</span>
        </div>
        <div className="hidden sm:flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-sky-300">
            1 / 2 / 3
          </kbd>
          <span>Pistol • Rifle • Sniper</span>
        </div>
        <div className="hidden lg:flex items-center gap-1.5">
          <kbd className="px-1.5 py-0.5 rounded border border-white/25 bg-slate-900 font-mono text-[11px] text-purple-300">
            Z
          </kbd>
          <span>Slow-Mo 0.2×</span>
        </div>
      </div>
    </div>
  );
};
