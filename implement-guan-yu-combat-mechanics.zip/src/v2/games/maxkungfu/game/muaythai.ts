import { dist, lerp } from './rng';
import { pcircle, pfontO, pring, prect, type Ctx } from './pixel';

/**
 * ADEGAN FIST BARU — Muay Thai Clinch & Taekwondo Back Kick (Mode V2 Kantor).
 *
 * MUAY THAI CLINCH (RMB saat musuh goyah/jatuh di dekat kita): pemain menyergap, MEMEGANG
 * KEPALA musuh dengan dua tangan, menariknya turun, lalu menghantamkan DENGKUL beruntun
 * ke wajahnya — diakhiri dengkul besar yang melempar musuh. Marker "RMB CLINCH" muncul
 * di musuh yang bisa dicengkeram, sama seperti marker Straight Punch.
 *
 * TAEKWONDO BACK KICK (finisher otomatis): saat pukulan rantai akan menamatkan musuh yang
 * sekarat, kadang diganti adegan putar badan + tendangan belakang Taekwondo yang melempar
 * musuh berputar jauh. Bergantian dengan finisher biasa (cooldown adegan).
 */
type G = any;

const label = (ctx: Ctx, x: number, y: number, text: string, color: string, w = 30) => {
  prect(ctx, Math.round(x - w / 2), Math.round(y), w, 7, '#000000aa');
  pfontO(ctx, text, x, y + 1, color, '#000', 1, 'center');
};

/* ============================================================ MUAY THAI CLINCH */
interface ClinchScene {
  e: any; phase: 'approach' | 'grab' | 'knees' | 'recover';
  t: number; knees: number; dir: number; hitMark: number;
}

export class MuayThai {
  active: ClinchScene | null = null;
  cd = 0;
  time = 0;

  reset() { this.active = null; this.cd = 0; }

  /** musuh yang sedang bisa dicengkeram: dekat, dan sedang goyah / jatuh / terpukul mundur */
  markedTarget(g: G): any | null {
    if (g.state !== 'playing' || this.active || this.cd > 0) return null;
    const p = g.player;
    if (p.weapon !== 'fist' || p.airborne || p.stunT > 0 || p.holdT > 0 || p.fatality || p.dashT > 0 ||
        g.silat || g.botPunch?.active || g.tkd?.active || g.propsPlay?.scene || g.carry?.carrying || g.grab?.holding) return null;
    let best: any = null, bd = 56;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0 || e.z > 2) continue;
      const vulnerable = e.stagger > 0 || e.down > 0 || e.state === 'down' || e.state === 'stagger' || e.state === 'stun';
      if (!vulnerable) continue;
      const d = dist(p.x, p.y, e.x, e.y);
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }

  maybeStart(g: G): boolean {
    if (!g.input?.mouse?.rpressed) return false;
    const e = this.markedTarget(g);
    if (!e) return false;
    this.start(g, e);
    return true;
  }

  start(g: G, e: any) {
    const p = g.player;
    const dir = Math.atan2(e.y - p.y, e.x - p.x);
    this.active = { e, phase: 'approach', t: 0, knees: 0, dir, hitMark: 0 };
    p.aim = dir; p.bodyAim = dir; p.facing = Math.cos(dir) >= 0 ? 1 : -1;
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = '';
    p.iframes = Math.max(p.iframes ?? 0, 0.9);
    g.input.mouse.rpressed = false; g.input.mouse.rdown = false;
    g.sfx?.dash?.(); g.sfx?.whoosh?.();
    g.say?.('MUAY THAI CLINCH!', '#ffb347', 2, 0.75);
    this.cd = 3.5;
  }

  private setPhase(s: ClinchScene, phase: ClinchScene['phase']) { s.phase = phase; s.t = 0; }

  update(g: G, dt: number): boolean {
    this.time += dt;
    if (this.cd > 0) this.cd -= dt;
    const s = this.active;
    if (!s) return false;
    const p = g.player, e = s.e;
    if (g.state !== 'playing' || e.dead || p.weapon !== 'fist') { this.active = null; return false; }
    s.t += dt;
    p.moving = false; p.running = false; p.runT = 0;
    p.iframes = Math.max(p.iframes ?? 0, 0.3);
    // titik cengkeraman: tepat di depan dada pemain
    const cx = p.x + Math.cos(s.dir) * 16, cy = p.y + Math.sin(s.dir) * 16;

    if (s.phase === 'approach') {
      // menyergap ke depan musuh
      const tx = e.x - Math.cos(s.dir) * 17, ty = e.y - Math.sin(s.dir) * 17;
      const k = 1 - Math.exp(-16 * dt);
      p.x += (tx - p.x) * k; p.y += (ty - p.y) * k;
      p.squash = 0.9;
      if (s.t > 0.16) this.setPhase(s, 'grab');
    } else if (s.phase === 'grab') {
      // dua tangan memegang kepala musuh dan menariknya turun ke titik cengkeraman
      const k = 1 - Math.exp(-14 * dt);
      e.x += (cx - e.x) * k; e.y += (cy - e.y) * k;
      e.kx = e.ky = e.vx = e.vy = 0; e.z = 0;
      e.stun = Math.max(e.stun ?? 0, 0.3); e.state = 'stun'; e.pose = 'hurt'; e.poseT = 0.4;
      e.sqx = 1.15; e.sqy = 0.8;
      p.squash = 0.86;
      if (s.t > 0.22) { this.setPhase(s, 'knees'); g.say?.('PEJAMKAN KEPALANYA!', '#ffb347', 1, 0.5); }
    } else if (s.phase === 'knees') {
      // musuh terkunci di cengkeraman; dengkul menghantam beruntun
      e.x = cx; e.y = cy; e.kx = e.ky = e.vx = e.vy = 0;
      e.stun = Math.max(e.stun ?? 0, 0.3); e.state = 'stun'; e.pose = 'hurt';
      const nextAt = 0.06 + s.knees * 0.27;
      if (s.t >= nextAt && s.knees < 3) {
        s.knees++;
        const final = s.knees === 3;
        // kepala musuh dipertemukan dengan dengkul kita
        g.damageEnemy(e, final ? 10 : 5, final ? 46 : 28, s.dir, final ? 520 : 120, {
          melee: true, hitstop: final ? 0.07 : 0.04, shake: final ? 0.4 : 0.2,
          knockdown: final, launch: final ? 150 : 40,
        });
        e.sqx = 1.35; e.sqy = 0.6;
        g.sfx?.kick?.(); g.sfx?.hit?.();
        g.hitstop = Math.max(g.hitstop ?? 0, final ? 0.06 : 0.03);
        g.shake?.(final ? 0.35 : 0.15);
        g.particles?.impact?.(cx, cy - 12, final ? 10 : 6, '#ffffff');
        g.particles?.spark?.(cx, cy - 12, final ? 10 : 5, '#ffb347', -Math.PI / 2, 1, 180);
        if (final) { g.say?.('DENGKUL!', '#ffb347', 2, 0.6); g.slow?.(0.18, 0.3); }
        if (e.dead) { this.active = null; return false; }
      }
      p.squash = 0.92 + Math.sin(s.t * 24) * 0.05;
      if (s.knees >= 3 || s.t > 1.0) this.setPhase(s, 'recover');
    } else {
      p.squash = lerp(p.squash ?? 1, 1, Math.min(1, dt * 8));
      if (s.t > 0.28) { this.active = null; p.squash = 1; }
    }
    return true;
  }

  poseOverride(): { pose: string; t: number } | null {
    const s = this.active;
    if (!s) return null;
    if (s.phase === 'approach') return { pose: 'dash', t: 0.4 };
    if (s.phase === 'grab') return { pose: 'grab', t: 0.55 };
    if (s.phase === 'knees') {
      const u = (s.t % 0.27) / 0.27;
      return { pose: 'knee', t: 0.2 + u * 0.6 }; // dengkul naik-turun berirama
    }
    return { pose: 'knee', t: 0.9 };
  }

  draw(g: G, ctx: Ctx) {
    ctx.save();
    if (!this.active) {
      const mark = this.markedTarget(g);
      if (mark) {
        const pulse = 0.7 + 0.3 * Math.sin(this.time * 10);
        ctx.globalAlpha = pulse;
        pring(ctx, mark.x, mark.y - 7, 12, '#ffb347', 2);
        pcircle(ctx, mark.x, mark.y - 7, 2, '#ffb347');
        ctx.globalAlpha = 1;
        label(ctx, mark.x, mark.y - 32, 'RMB  CLINCH', '#ffb347', 62);
      }
      ctx.restore();
      return;
    }
    const s = this.active, e = s.e;
    if (s.phase === 'knees') label(ctx, e.x, e.y - 34, `DENGKUL ${s.knees}/3`, '#ffb347', 52);
    else if (s.phase === 'grab') label(ctx, e.x, e.y - 34, 'CLINCH!', '#ffb347', 40);
    ctx.restore();
  }
}

/* ============================================================ TAEKWONDO BACK KICK */
interface TkdScene { e: any; t: number; hitDone: boolean; dir: number }

export class TkdKick {
  active: TkdScene | null = null;
  cd = 0;
  time = 0;

  reset() { this.active = null; this.cd = 0; }

  /** dipanggil dari finisher rantai pukulan: true bila adegan mengambil alih penyelesaian kombo */
  maybeFinish(g: G, target: any): boolean {
    if (!target || target.dead || this.active || this.cd > 0) return false;
    const p = g.player;
    if (p.weapon !== 'fist' || p.airborne || p.stunT > 0 || p.fatality || g.silat ||
        g.botPunch?.active || g.muay?.active || g.propsPlay?.scene) return false;
    if (dist(p.x, p.y, target.x, target.y) > 74) return false;
    const dir = Math.atan2(target.y - p.y, target.x - p.x);
    this.active = { e: target, t: 0, hitDone: false, dir };
    p.aim = dir; p.bodyAim = dir; p.facing = Math.cos(dir) >= 0 ? 1 : -1;
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = '';
    p.iframes = Math.max(p.iframes ?? 0, 0.6);
    g.sfx?.whoosh?.();
    g.say?.('TAEKWONDO BACK KICK!', '#7ce7ff', 2, 0.8);
    this.cd = 6;
    return true;
  }

  update(g: G, dt: number): boolean {
    this.time += dt;
    if (this.cd > 0) this.cd -= dt;
    const s = this.active;
    if (!s) return false;
    const p = g.player, e = s.e;
    if (g.state !== 'playing' || p.weapon !== 'fist') { this.active = null; return false; }
    s.t += dt;
    p.moving = false; p.running = false; p.runT = 0;
    p.iframes = Math.max(p.iframes ?? 0, 0.3);

    if (s.t < 0.2) {
      // putar badan: punggung menghadap musuh, langkah kecil menutup jarak
      p.aim = s.dir; p.facing = Math.cos(s.dir) >= 0 ? 1 : -1;
      const tx = e.x - Math.cos(s.dir) * 19, ty = e.y - Math.sin(s.dir) * 19;
      const k = 1 - Math.exp(-12 * dt);
      p.x += (tx - p.x) * k; p.y += (ty - p.y) * k;
      p.squash = 0.88;
    } else if (!s.hitDone) {
      s.hitDone = true;
      // badan membelakangi sasaran, kaki menendang lurus ke belakang dengan seluruh momentum putaran
      p.aim = s.dir + Math.PI; p.facing = Math.cos(p.aim) >= 0 ? 1 : -1;
      if (!e.dead) {
        g.damageEnemy(e, 16, 72, s.dir, 780, { melee: true, knockdown: true, hitstop: 0.08, shake: 0.55, launch: 130 });
        e.rot = (e.rot ?? 0) + 2.4;
      }
      g.sfx?.heavy?.(); g.sfx?.hit?.();
      g.hitstop = Math.max(g.hitstop ?? 0, 0.07);
      g.shake?.(0.55);
      g.slow?.(0.22, 0.3);
      g.flash?.('#ffffff', 0.08);
      g.particles?.impact?.(e.x, e.y - 8, 12, '#ffffff');
      g.particles?.spark?.(e.x, e.y - 8, 14, '#7ce7ff', s.dir, 1.4, 280);
      g.say?.('BACK KICK!', '#7ce7ff', 2, 0.6);
      p.squash = 0.82;
    } else {
      p.aim = s.dir; p.facing = Math.cos(s.dir) >= 0 ? 1 : -1;
      p.squash = lerp(p.squash ?? 1, 1, Math.min(1, dt * 8));
    }
    if (s.t > 0.62) { this.active = null; p.squash = 1; }
    return true;
  }

  poseOverride(): { pose: string; t: number } | null {
    const s = this.active;
    if (!s) return null;
    if (s.t < 0.2) return { pose: 'spinback', t: (s.t / 0.2) * 0.45 };       // putaran badan
    if (s.t < 0.36) return { pose: 'sidekick', t: 0.55 };                     // kaki menendang ke belakang
    return { pose: 'spinback', t: 0.9 };                                      // kembali menghadap depan
  }
}
