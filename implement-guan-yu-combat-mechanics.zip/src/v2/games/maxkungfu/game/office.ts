import { TILE, type Palette } from './constants';
import type { Level } from './level';
import { px, prect, pline, pfontO, pcircle, type Ctx } from './pixel';
import { clamp, hash2 } from './rng';
import type { Vec } from './types';

// Office tile types
export const OT_AIR = 0;
export const OT_WALL = 1;    // Solid concrete wall / outer wall / pillar
export const OT_FLOOR = 2;   // One-way walkable office floor slab (jump up through, drop down with S+Space)
export const OT_STAIRS = 3;  // Stairwell / ladder connecting floors
export const OT_GLASS = 4;   // Breakable glass partition (shatters on attack / dash / slam)
export const OT_ELEV = 5;    // Elevator / boost pad (W or Space zips up to next floor)

export type OfficeThemeId = 'cyber_night' | 'sunset_corp' | 'midnight_rain' | 'dojo_tower';

export interface OfficeTheme {
  id: OfficeThemeId;
  name: string;
  skyTop: string;
  skyBot: string;
  cityFar: string;
  cityNear: string;
  cityWin: string;
  wallFill: string;
  wallShade: string;
  wallTrim: string;
  roomBg: string;
  roomPanel: string;
  slabTop: string;
  slabBody: string;
  slabBot: string;
  stairCol: string;
  glassCol: string;
  accent: string;
  accent2: string;
  lightTint: string;
}

export const OFFICE_THEMES: Record<OfficeThemeId, OfficeTheme> = {
  cyber_night: {
    id: 'cyber_night',
    name: 'CYBER NIGHT',
    skyTop: '#060916',
    skyBot: '#131d38',
    cityFar: '#0b1224',
    cityNear: '#0f1830',
    cityWin: '#ffd86b',
    wallFill: '#242b3d',
    wallShade: '#181d2b',
    wallTrim: '#49587a',
    roomBg: '#121622',
    roomPanel: '#171c2b',
    slabTop: '#566482',
    slabBody: '#2b3347',
    slabBot: '#181c28',
    stairCol: '#c48d48',
    glassCol: '#7ce8ff',
    accent: '#ff5a36',
    accent2: '#46e2ff',
    lightTint: '#d6f0ff',
  },
  sunset_corp: {
    id: 'sunset_corp',
    name: 'SUNSET CORP',
    skyTop: '#1b0b1e',
    skyBot: '#5c2230',
    cityFar: '#281123',
    cityNear: '#1c0c1b',
    cityWin: '#ffb84a',
    wallFill: '#2d232b',
    wallShade: '#1d161c',
    wallTrim: '#634b5c',
    roomBg: '#19141a',
    roomPanel: '#211a22',
    slabTop: '#7a5d66',
    slabBody: '#382b33',
    slabBot: '#1c151a',
    stairCol: '#d99a4e',
    glassCol: '#ffd0a6',
    accent: '#ff6b35',
    accent2: '#ffd166',
    lightTint: '#ffe8c8',
  },
  midnight_rain: {
    id: 'midnight_rain',
    name: 'RAINY HQ',
    skyTop: '#05080d',
    skyBot: '#0f1c24',
    cityFar: '#081016',
    cityNear: '#0c161e',
    cityWin: '#63f2c8',
    wallFill: '#1e272e',
    wallShade: '#13191e',
    wallTrim: '#3e515e',
    roomBg: '#10151a',
    roomPanel: '#141b21',
    slabTop: '#4a5d6b',
    slabBody: '#242f38',
    slabBot: '#12181d',
    stairCol: '#8fa4b3',
    glassCol: '#8be9fd',
    accent: '#35f0ff',
    accent2: '#ff4d6d',
    lightTint: '#c4f5ff',
  },
  dojo_tower: {
    id: 'dojo_tower',
    name: 'DOJO TOWER',
    skyTop: '#0b0807',
    skyBot: '#291512',
    cityFar: '#160d0b',
    cityNear: '#100908',
    cityWin: '#ffaa44',
    wallFill: '#2f241f',
    wallShade: '#1e1613',
    wallTrim: '#6e5041',
    roomBg: '#171210',
    roomPanel: '#1f1815',
    slabTop: '#8c6244',
    slabBody: '#402c20',
    slabBot: '#211610',
    stairCol: '#d9a45b',
    glassCol: '#ffe6b3',
    accent: '#ffd447',
    accent2: '#ff3b3b',
    lightTint: '#ffebb8',
  },
};

export type OfficeDecorKind = 'window' | 'cabinet' | 'server' | 'whiteboard' | 'light' | 'plant_bg';

export interface OfficeDecor {
  tx: number;
  ty: number;
  kind: OfficeDecorKind;
  w?: number;
  h?: number;
}

export interface OfficePropSpawn {
  tx: number;
  ty: number;
  kind: 'table' | 'pot' | 'crate' | 'barrel';
}

export interface OfficeMapData {
  id: string;
  name: string;
  w: number;
  h: number;
  theme: OfficeThemeId;
  tiles: number[];
  decor: OfficeDecor[];
  props: OfficePropSpawn[];
  spawn: { tx: number; ty: number };
  leftGates: { tx: number; ty: number }[];
  rightGates: { tx: number; ty: number }[];
  updatedAt?: number;
}

const STORAGE_MAPS_KEY = 'v2_kf_office_maps_v1';
const STORAGE_ACTIVE_ID_KEY = 'v2_kf_office_active_map_v1';

/** Build an empty boxed building shell with ground floor. */
export function createBlankOfficeMap(name = 'KANTOR BARU', w = 68, h = 24, theme: OfficeThemeId = 'cyber_night'): OfficeMapData {
  const tiles = new Array<number>(w * h).fill(OT_AIR);
  const set = (tx: number, ty: number, v: number) => {
    if (tx >= 0 && ty >= 0 && tx < w && ty < h) tiles[ty * w + tx] = v;
  };
  for (let x = 0; x < w; x++) {
    set(x, 0, OT_WALL);
    set(x, 1, OT_WALL);
    set(x, h - 1, OT_WALL);
    set(x, h - 2, OT_WALL);
  }
  for (let y = 0; y < h; y++) {
    set(0, y, OT_WALL);
    set(1, y, OT_WALL);
    set(w - 1, y, OT_WALL);
    set(w - 2, y, OT_WALL);
  }
  const groundTy = h - 2;
  return {
    id: `custom_${Date.now()}`,
    name,
    w,
    h,
    theme,
    tiles,
    decor: [],
    props: [
      { tx: Math.floor(w / 2) - 5, ty: groundTy, kind: 'table' },
      { tx: Math.floor(w / 2) + 5, ty: groundTy, kind: 'pot' },
    ],
    spawn: { tx: Math.floor(w / 2), ty: groundTy },
    leftGates: [{ tx: 3, ty: groundTy }],
    rightGates: [{ tx: w - 4, ty: groundTy }],
    updatedAt: Date.now(),
  };
}

function makePresetTower4(): OfficeMapData {
  const w = 78, h = 26;
  const m = createBlankOfficeMap('MENARA KANTOR 4 LT', w, h, 'cyber_night');
  m.id = 'preset_tower_4';
  const set = (tx: number, ty: number, v: number) => {
    if (tx >= 0 && ty >= 0 && tx < w && ty < h) m.tiles[ty * w + tx] = v;
  };
  // Floor surface Y tile indices: ground = 24, floor2 = 19, floor3 = 14, floor4 = 9, roof ceiling = 4
  const floors = [24, 19, 14, 9];
  // Outer walls already at 0..1 and w-2..w-1; add roof slab at y=4
  for (let x = 2; x < w - 2; x++) set(x, 4, OT_WALL);

  // Add upper one-way floor slabs with stairwell openings
  for (const fy of [19, 14, 9]) {
    for (let x = 2; x < w - 2; x++) {
      // Leave stairwell openings at x=11..14, x=63..66
      if ((x >= 11 && x <= 14) || (x >= 63 && x <= 66)) continue;
      set(x, fy, OT_FLOOR);
    }
  }

  // Left & Right 4-tile-wide switchback staircases connecting floors
  for (let f = 0; f < 3; f++) {
    const bot = floors[f] - 1;
    const top = floors[f + 1];
    for (let y = top; y <= bot; y++) {
      for (let sx = 11; sx <= 14; sx++) set(sx, y, OT_STAIRS);
      for (let sx = 63; sx <= 66; sx++) set(sx, y, OT_STAIRS);
    }
  }

  // Central Elevator Pads on floors 1, 2, 3
  for (const fy of [24, 19, 14]) {
    set(38, fy - 1, OT_ELEV);
    set(39, fy - 1, OT_ELEV);
  }

  // Breakable Glass Conference Partitions across floors
  for (const [gx, fy] of [[24, 24], [52, 24], [28, 19], [49, 19], [22, 14], [55, 14], [30, 9], [47, 9]]) {
    for (let dy = 1; dy <= 3; dy++) set(gx, fy - dy, OT_GLASS);
  }

  // Structural interior concrete columns on ground & mid floors (with doorway gaps)
  for (const [px, fy] of [[8, 24], [69, 24], [19, 14], [58, 14]]) {
    set(px, fy - 3, OT_WALL);
    set(px, fy - 4, OT_WALL);
  }

  // Doors for enemy waves on Left and Right on every floor!
  m.leftGates = [
    { tx: 3, ty: 24 },
    { tx: 3, ty: 19 },
    { tx: 3, ty: 14 },
    { tx: 3, ty: 9 },
  ];
  m.rightGates = [
    { tx: w - 4, ty: 24 },
    { tx: w - 4, ty: 19 },
    { tx: w - 4, ty: 14 },
    { tx: w - 4, ty: 9 },
  ];
  m.spawn = { tx: 39, ty: 24 };

  // Office Decor (windows, ceiling lights, cabinets, whiteboards, server racks)
  for (const fy of floors) {
    for (let x = 6; x < w - 6; x += 10) {
      if (Math.abs(x - 38) > 3 && Math.abs(x - 13) > 3 && Math.abs(x - 64) > 3) {
        m.decor.push({ tx: x, ty: fy - 3, kind: 'window', w: 5, h: 2 });
      }
      m.decor.push({ tx: x + 1, ty: fy - 4, kind: 'light', w: 3, h: 1 });
    }
    m.decor.push({ tx: 18, ty: fy - 1, kind: 'cabinet' });
    m.decor.push({ tx: 59, ty: fy - 1, kind: 'whiteboard' });
  }
  m.decor.push({ tx: 33, ty: 14 - 1, kind: 'server' });
  m.decor.push({ tx: 44, ty: 14 - 1, kind: 'server' });

  // Interactive Props (Tables/Desks, Flower Pots, Crates, Water Coolers)
  m.props = [
    { tx: 20, ty: 24, kind: 'table' },
    { tx: 31, ty: 24, kind: 'pot' },
    { tx: 46, ty: 24, kind: 'pot' },
    { tx: 56, ty: 24, kind: 'table' },
    { tx: 22, ty: 19, kind: 'table' },
    { tx: 34, ty: 19, kind: 'barrel' },
    { tx: 44, ty: 19, kind: 'crate' },
    { tx: 55, ty: 19, kind: 'table' },
    { tx: 27, ty: 14, kind: 'crate' },
    { tx: 35, ty: 14, kind: 'pot' },
    { tx: 49, ty: 14, kind: 'table' },
    { tx: 25, ty: 9, kind: 'table' },
    { tx: 39, ty: 9, kind: 'pot' },
    { tx: 52, ty: 9, kind: 'barrel' },
  ];
  return m;
}

function makePresetLobbyMezz(): OfficeMapData {
  const w = 70, h = 22;
  const m = createBlankOfficeMap('LOBI & MEZANIN', w, h, 'sunset_corp');
  m.id = 'preset_lobby_mezz';
  const set = (tx: number, ty: number, v: number) => {
    if (tx >= 0 && ty >= 0 && tx < w && ty < h) m.tiles[ty * w + tx] = v;
  };
  for (let x = 2; x < w - 2; x++) set(x, 3, OT_WALL);
  // Mezzanine left & right wings (ty=14) + top bridge (ty=9)
  for (let x = 2; x <= 26; x++) set(x, 14, OT_FLOOR);
  for (let x = 43; x <= w - 3; x++) set(x, 14, OT_FLOOR);
  for (let x = 16; x <= w - 17; x++) set(x, 9, OT_FLOOR);
  // Central twin stairs + side stairs (3 tiles wide for clean switchback steps)
  for (let y = 14; y <= 19; y++) {
    set(23, y, OT_STAIRS); set(24, y, OT_STAIRS); set(25, y, OT_STAIRS);
    set(44, y, OT_STAIRS); set(45, y, OT_STAIRS); set(46, y, OT_STAIRS);
  }
  for (let y = 9; y <= 13; y++) {
    set(18, y, OT_STAIRS); set(19, y, OT_STAIRS); set(20, y, OT_STAIRS);
    set(49, y, OT_STAIRS); set(50, y, OT_STAIRS); set(51, y, OT_STAIRS);
  }
  // Center lobby elevator pad
  set(34, 19, OT_ELEV); set(35, 19, OT_ELEV);
  set(34, 13, OT_ELEV); set(35, 13, OT_ELEV);
  // Glass partitions
  for (let dy = 1; dy <= 3; dy++) {
    set(14, 20 - dy, OT_GLASS);
    set(55, 20 - dy, OT_GLASS);
    set(34, 9 - dy, OT_GLASS);
  }
  m.spawn = { tx: 34, ty: 20 };
  m.leftGates = [{ tx: 3, ty: 20 }, { tx: 3, ty: 14 }];
  m.rightGates = [{ tx: w - 4, ty: 20 }, { tx: w - 4, ty: 14 }];
  for (let x = 6; x < w - 6; x += 11) {
    m.decor.push({ tx: x, ty: 16, kind: 'window', w: 6, h: 3 });
    m.decor.push({ tx: x + 1, ty: 5, kind: 'light', w: 3, h: 1 });
  }
  m.props = [
    { tx: 29, ty: 20, kind: 'pot' },
    { tx: 40, ty: 20, kind: 'pot' },
    { tx: 10, ty: 20, kind: 'table' },
    { tx: 59, ty: 20, kind: 'table' },
    { tx: 11, ty: 14, kind: 'table' },
    { tx: 57, ty: 14, kind: 'crate' },
    { tx: 34, ty: 9, kind: 'barrel' },
  ];
  return m;
}

function makePresetServerHQ(): OfficeMapData {
  const w = 64, h = 22;
  const m = createBlankOfficeMap('MARKAS SERVER 3 LT', w, h, 'midnight_rain');
  m.id = 'preset_server_hq';
  const set = (tx: number, ty: number, v: number) => {
    if (tx >= 0 && ty >= 0 && tx < w && ty < h) m.tiles[ty * w + tx] = v;
  };
  for (let x = 2; x < w - 2; x++) set(x, 4, OT_WALL);
  for (const fy of [15, 10]) {
    for (let x = 2; x < w - 2; x++) {
      if ((x >= 10 && x <= 12) || (x >= 51 && x <= 53)) continue;
      set(x, fy, OT_FLOOR);
    }
  }
  for (let y = 10; y <= 19; y++) {
    set(10, y, OT_STAIRS); set(11, y, OT_STAIRS); set(12, y, OT_STAIRS);
    set(51, y, OT_STAIRS); set(52, y, OT_STAIRS); set(53, y, OT_STAIRS);
  }
  set(31, 19, OT_ELEV); set(32, 19, OT_ELEV);
  set(31, 14, OT_ELEV); set(32, 14, OT_ELEV);
  for (const [gx, fy] of [[21, 20], [42, 20], [24, 15], [39, 15], [27, 10], [36, 10]]) {
    for (let dy = 1; dy <= 3; dy++) set(gx, fy - dy, OT_GLASS);
  }
  m.spawn = { tx: 32, ty: 20 };
  m.leftGates = [{ tx: 3, ty: 20 }, { tx: 3, ty: 15 }, { tx: 3, ty: 10 }];
  m.rightGates = [{ tx: w - 4, ty: 20 }, { tx: w - 4, ty: 15 }, { tx: w - 4, ty: 10 }];
  for (const fy of [20, 15, 10]) {
    for (let x = 15; x < 49; x += 8) {
      m.decor.push({ tx: x, ty: fy - 1, kind: 'server' });
      m.decor.push({ tx: x + 2, ty: fy - 4, kind: 'light', w: 3, h: 1 });
    }
  }
  m.props = [
    { tx: 17, ty: 20, kind: 'crate' }, { tx: 46, ty: 20, kind: 'barrel' },
    { tx: 29, ty: 15, kind: 'table' }, { tx: 45, ty: 15, kind: 'pot' },
    { tx: 20, ty: 10, kind: 'table' }, { tx: 42, ty: 10, kind: 'crate' },
  ];
  return m;
}

function makePresetDojoCorp(): OfficeMapData {
  const w = 72, h = 24;
  const m = createBlankOfficeMap('KANTOR DOJO SENJA', w, h, 'dojo_tower');
  m.id = 'preset_dojo_corp';
  const set = (tx: number, ty: number, v: number) => {
    if (tx >= 0 && ty >= 0 && tx < w && ty < h) m.tiles[ty * w + tx] = v;
  };
  for (let x = 2; x < w - 2; x++) set(x, 3, OT_WALL);
  for (const fy of [17, 11]) {
    for (let x = 2; x < w - 2; x++) {
      if ((x >= 16 && x <= 18) || (x >= 53 && x <= 55)) continue;
      set(x, fy, OT_FLOOR);
    }
  }
  for (let y = 11; y <= 21; y++) {
    set(16, y, OT_STAIRS); set(17, y, OT_STAIRS); set(18, y, OT_STAIRS);
    set(53, y, OT_STAIRS); set(54, y, OT_STAIRS); set(55, y, OT_STAIRS);
  }
  set(35, 21, OT_ELEV); set(36, 21, OT_ELEV);
  set(35, 16, OT_ELEV); set(36, 16, OT_ELEV);
  for (let dy = 1; dy <= 3; dy++) {
    set(26, 22 - dy, OT_GLASS); set(45, 22 - dy, OT_GLASS);
    set(29, 17 - dy, OT_GLASS); set(42, 17 - dy, OT_GLASS);
  }
  m.spawn = { tx: 36, ty: 22 };
  m.leftGates = [{ tx: 3, ty: 22 }, { tx: 3, ty: 17 }, { tx: 3, ty: 11 }];
  m.rightGates = [{ tx: w - 4, ty: 22 }, { tx: w - 4, ty: 17 }, { tx: w - 4, ty: 11 }];
  for (const fy of [22, 17, 11]) {
    for (let x = 7; x < w - 9; x += 12) {
      m.decor.push({ tx: x, ty: fy - 3, kind: 'window', w: 5, h: 2 });
      m.decor.push({ tx: x + 1, ty: fy - 4, kind: 'light', w: 3, h: 1 });
    }
  }
  m.props = [
    { tx: 22, ty: 22, kind: 'pot' }, { tx: 49, ty: 22, kind: 'pot' },
    { tx: 31, ty: 22, kind: 'table' }, { tx: 40, ty: 22, kind: 'table' },
    { tx: 24, ty: 17, kind: 'table' }, { tx: 48, ty: 17, kind: 'barrel' },
    { tx: 35, ty: 11, kind: 'pot' }, { tx: 24, ty: 11, kind: 'crate' },
  ];
  return m;
}

export const OFFICE_PRESETS: OfficeMapData[] = [
  makePresetTower4(),
  makePresetLobbyMezz(),
  makePresetServerHQ(),
  makePresetDojoCorp(),
];

export function cloneOfficeMap(m: OfficeMapData): OfficeMapData {
  return {
    ...m,
    tiles: [...m.tiles],
    decor: m.decor.map((d) => ({ ...d })),
    props: m.props.map((p) => ({ ...p })),
    spawn: { ...m.spawn },
    leftGates: m.leftGates.map((g) => ({ ...g })),
    rightGates: m.rightGates.map((g) => ({ ...g })),
  };
}

export function loadCustomOfficeMaps(): OfficeMapData[] {
  try {
    const raw = localStorage.getItem(STORAGE_MAPS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function listAllOfficeMaps(): OfficeMapData[] {
  const custom = loadCustomOfficeMaps();
  const customIds = new Set(custom.map((m) => m.id));
  return [...custom, ...OFFICE_PRESETS.filter((p) => !customIds.has(p.id))];
}

export function saveCustomOfficeMap(map: OfficeMapData): OfficeMapData[] {
  const copy = cloneOfficeMap(map);
  copy.updatedAt = Date.now();
  const existing = loadCustomOfficeMaps().filter((m) => m.id !== copy.id);
  const next = [copy, ...existing];
  try { localStorage.setItem(STORAGE_MAPS_KEY, JSON.stringify(next)); } catch { /* ignore */ }
  return next;
}

export function deleteCustomOfficeMap(id: string): OfficeMapData[] {
  const next = loadCustomOfficeMaps().filter((m) => m.id !== id);
  try { localStorage.setItem(STORAGE_MAPS_KEY, JSON.stringify(next)); } catch { /* ignore */ }
  return next;
}

export function getSelectedOfficeMapId(): string {
  try { return localStorage.getItem(STORAGE_ACTIVE_ID_KEY) || OFFICE_PRESETS[0].id; } catch { return OFFICE_PRESETS[0].id; }
}

export function setSelectedOfficeMapId(id: string) {
  try { localStorage.setItem(STORAGE_ACTIVE_ID_KEY, id); } catch { /* ignore */ }
}

export function getOfficeMapById(id?: string): OfficeMapData {
  const target = id || getSelectedOfficeMapId();
  const all = listAllOfficeMaps();
  return cloneOfficeMap(all.find((m) => m.id === target) || OFFICE_PRESETS[0]);
}

/** Build a playable Level object from an OfficeMapData blueprint. */
export function buildOfficeLevel(mapData: OfficeMapData): Level {
  const map = cloneOfficeMap(mapData);
  const w = map.w, h = map.h;
  const officeTiles = new Uint8Array(w * h);
  const tiles = new Uint8Array(w * h);
  const floorRowSet = new Set<number>();

  for (let i = 0; i < w * h; i++) {
    const v = map.tiles[i] ?? 0;
    officeTiles[i] = v;
    // Standard level.tiles: 1 = blocks horizontal movement & bullets (Wall or unbroken Glass)
    tiles[i] = v === OT_WALL || v === OT_GLASS ? 1 : 0;
    if (v === OT_FLOOR) floorRowSet.add(Math.floor(i / w) * TILE);
  }

  // Also register solid ground floor top
  for (let ty = 1; ty < h; ty++) {
    let groundRun = 0;
    for (let tx = 2; tx < w - 2; tx++) {
      if (officeTiles[ty * w + tx] === OT_WALL && officeTiles[(ty - 1) * w + tx] !== OT_WALL) {
        groundRun++;
      }
    }
    if (groundRun > w * 0.4) floorRowSet.add(ty * TILE);
  }

  const officeFloors = [...floorRowSet].sort((a, b) => b - a); // [Floor 1 bottom .. Top floor]
  const floorTiles: Vec[] = [];
  for (let ty = 1; ty < h - 1; ty++) {
    for (let tx = 1; tx < w - 1; tx++) {
      const here = officeTiles[ty * w + tx];
      const below = officeTiles[(ty + 1) * w + tx];
      if ((here === OT_AIR || here === OT_STAIRS || here === OT_ELEV) && (below === OT_WALL || below === OT_FLOOR)) {
        floorTiles.push({ x: tx * TILE + TILE / 2, y: (ty + 1) * TILE });
      }
    }
  }

  const spawn: Vec = { x: map.spawn.tx * TILE + TILE / 2, y: map.spawn.ty * TILE };
  const leftSpawns: Vec[] = (map.leftGates.length ? map.leftGates : [{ tx: 3, ty: map.spawn.ty }]).map((g) => ({
    x: g.tx * TILE + TILE / 2,
    y: g.ty * TILE,
  }));
  const rightSpawns: Vec[] = (map.rightGates.length ? map.rightGates : [{ tx: w - 4, ty: map.spawn.ty }]).map((g) => ({
    x: g.tx * TILE + TILE / 2,
    y: g.ty * TILE,
  }));

  return {
    n: 1,
    zone: 0,
    w,
    h,
    tiles,
    spawn,
    exit: { ...spawn },
    floorTiles,
    isBoss: false,
    style: map.theme,
    seed: 707,
    sideView: true,
    officeMap: map,
    officeTiles,
    officeFloors,
    leftSpawns,
    rightSpawns,
  };
}

export function officeTileAt(l: Level, tx: number, ty: number): number {
  if (tx < 0 || ty < 0 || tx >= l.w || ty >= l.h) return OT_WALL;
  return l.officeTiles ? l.officeTiles[ty * l.w + tx] : OT_AIR;
}

/** True if (x, y) collides with solid wall or unbroken glass in side-view. */
export function officeSolidAt(l: Level, x: number, y: number): boolean {
  const t = officeTileAt(l, Math.floor(x / TILE), Math.floor(y / TILE));
  return t === OT_WALL || t === OT_GLASS;
}

/** Check entity body box [x-r .. x+r] x [y-12 .. y-1] against solid walls/glass. */
export function officeBodySolid(l: Level, x: number, y: number, r: number): boolean {
  const x0 = Math.floor((x - r) / TILE), x1 = Math.floor((x + r) / TILE);
  const y0 = Math.floor((y - 12) / TILE), y1 = Math.floor((y - 1.5) / TILE);
  for (let ty = y0; ty <= y1; ty++) {
    for (let tx = x0; tx <= x1; tx++) {
      const t = officeTileAt(l, tx, ty);
      if (t === OT_WALL || t === OT_GLASS) return true;
    }
  }
  return false;
}

/** Find the Y coordinate of the supporting floor surface directly under/at entity's feet. */
export function officeFloorSupportY(l: Level, x: number, y: number, r: number, ignoreOneWay = false): number | null {
  const x0 = Math.floor((x - r * 0.7) / TILE), x1 = Math.floor((x + r * 0.7) / TILE);
  const tyStart = Math.max(0, Math.floor((y - 2) / TILE));
  for (let ty = tyStart; ty < l.h; ty++) {
    for (let tx = x0; tx <= x1; tx++) {
      const t = officeTileAt(l, tx, ty);
      if (t === OT_WALL || (!ignoreOneWay && t === OT_FLOOR)) {
        return ty * TILE;
      }
    }
  }
  return null;
}

export function officeOnStairs(l: Level, x: number, y: number, padPx = 5): boolean {
  const tyFoot = Math.floor((y - 2) / TILE);
  const tyHead = Math.floor((y - 11) / TILE);
  for (const ox of [0, -padPx, padPx]) {
    const tx = Math.floor((x + ox) / TILE);
    if (
      officeTileAt(l, tx, tyFoot) === OT_STAIRS ||
      officeTileAt(l, tx, tyHead) === OT_STAIRS ||
      officeTileAt(l, tx, tyFoot + 1) === OT_STAIRS
    ) {
      return true;
    }
  }
  return false;
}

export function officeStairSpan(
  l: Level,
  x: number,
  y: number,
): { sx0: number; sx1: number; sy0: number; sy1: number; cols: number } | null {
  const tyCand = [Math.floor((y - 2) / TILE), Math.floor((y - 11) / TILE), Math.floor((y + 4) / TILE)];
  const txCand = [Math.floor(x / TILE), Math.floor((x - 7) / TILE), Math.floor((x + 7) / TILE)];
  let hitTx = -1;
  let hitTy = -1;
  for (const cy of tyCand) {
    for (const cx of txCand) {
      if (officeTileAt(l, cx, cy) === OT_STAIRS) {
        hitTx = cx;
        hitTy = cy;
        break;
      }
    }
    if (hitTx >= 0) break;
  }
  if (hitTx < 0) return null;

  let sx0 = hitTx;
  let sx1 = hitTx;
  while (sx0 > 0 && officeTileAt(l, sx0 - 1, hitTy) === OT_STAIRS) sx0--;
  while (sx1 < l.w - 1 && officeTileAt(l, sx1 + 1, hitTy) === OT_STAIRS) sx1++;

  let sy0 = hitTy;
  let sy1 = hitTy;
  while (sy0 > 0) {
    let ok = false;
    for (let cx = sx0; cx <= sx1; cx++) if (officeTileAt(l, cx, sy0 - 1) === OT_STAIRS) { ok = true; break; }
    if (!ok) break;
    sy0--;
  }
  while (sy1 < l.h - 1) {
    let ok = false;
    for (let cx = sx0; cx <= sx1; cx++) if (officeTileAt(l, cx, sy1 + 1) === OT_STAIRS) { ok = true; break; }
    if (!ok) break;
    sy1++;
  }
  return { sx0, sx1, sy0, sy1, cols: sx1 - sx0 + 1 };
}

export function officeStairCenterX(l: Level, x: number, y: number): number | null {
  const sp = officeStairSpan(l, x, y);
  if (!sp) return null;
  return ((sp.sx0 + sp.sx1 + 1) * TILE) / 2;
}

/** Target X along the rendered zig-zag office staircase at height y, so climbers follow the treads. */
export function officeStairZigZagX(l: Level, x: number, y: number): number | null {
  const sp = officeStairSpan(l, x, y);
  if (!sp) return null;
  if (sp.cols <= 1) return sp.sx0 * TILE + TILE / 2;

  const bx = sp.sx0 * TILE;
  const bw = sp.cols * TILE;
  const byTop = sp.sy0 * TILE;
  const byBot = (sp.sy1 + 1) * TILE;
  const totalH = Math.max(TILE, byBot - byTop);
  const storyRows = Math.max(1, Math.round((sp.sy1 - sp.sy0 + 1) / 5));
  const segH = totalH / storyRows;
  const segIdx = clamp(Math.floor(Math.max(0, byBot - y - 1) / segH), 0, storyRows - 1);
  const sBot = byBot - segIdx * segH;
  const u = clamp((sBot - y) / segH, 0, 1);
  const padL = bx + 7;
  const padR = bx + bw - 8;
  if (u <= 0.5) return padL + (padR - padL) * (u * 2);
  return padR - (padR - padL) * ((u - 0.5) * 2);
}

/** Find a nearby stair entrance within maxDist px horizontally (for pressing W/S beside stairs). */
export function officeFindNearbyStairX(l: Level, x: number, y: number, wantDown: boolean, maxDist = 24): number | null {
  const ty = Math.floor((wantDown ? y + 4 : y - 4) / TILE);
  let bestX: number | null = null;
  let bestD = maxDist;
  for (let ox = -maxDist; ox <= maxDist; ox += 4) {
    const cx = x + ox;
    const tx = Math.floor(cx / TILE);
    if (officeTileAt(l, tx, ty) === OT_STAIRS || officeTileAt(l, tx, ty - (wantDown ? 0 : 1)) === OT_STAIRS) {
      const d = Math.abs(ox);
      if (d < bestD) { bestD = d; bestX = cx; }
    }
  }
  return bestX;
}

export function officeOnElev(l: Level, x: number, y: number): boolean {
  const tx = Math.floor(x / TILE);
  const tyFoot = Math.floor((y - 3) / TILE);
  return officeTileAt(l, tx, tyFoot) === OT_ELEV;
}

export interface OfficeStandProp {
  x: number;
  y: number;
  kind: string;
  dead: boolean;
}

/** Tabletop surface Y (pr.y - 9) if falling entity crosses an intact desk from above. */
export function sideTableSurfaceY(
  props: readonly OfficeStandProp[] | undefined,
  x: number,
  oldY: number,
  ny: number,
  dropThrough = false,
): number | null {
  if (!props || dropThrough) return null;
  let best: number | null = null;
  for (const pr of props) {
    if (pr.dead || pr.kind !== 'table') continue;
    const topY = pr.y - 9;
    if (x >= pr.x - 10 && x <= pr.x + 10 && oldY <= topY + 4 && ny >= topY - 0.5) {
      if (best === null || topY < best) best = topY;
    }
  }
  return best;
}

/** Check if an entity at (x, y) is currently supported on top of an intact desk. */
export function sideTableSupportY(
  props: readonly OfficeStandProp[] | undefined,
  x: number,
  y: number,
): number | null {
  if (!props) return null;
  for (const pr of props) {
    if (pr.dead || pr.kind !== 'table') continue;
    const topY = pr.y - 9;
    if (x >= pr.x - 10 && x <= pr.x + 10 && Math.abs(y - topY) <= 4) {
      return topY;
    }
  }
  return null;
}

/** Move entity in side-view with horizontal wall blocking and one-way floor slabs + stairs + office desks. */
export function moveSideView(
  l: Level,
  e: { x: number; y: number; r: number },
  dx: number,
  dy: number,
  dropThrough = false,
  props?: readonly OfficeStandProp[],
): { bx: boolean; by: boolean; onTable?: boolean; hitGlass: { tx: number; ty: number }[] } {
  let bx = false, by = false;
  let onTable = false;
  const hitGlass: { tx: number; ty: number }[] = [];
  const r = e.r * 0.75;

  if (dx !== 0) {
    const nx = e.x + dx;
    if (!officeBodySolid(l, nx, e.y, r)) {
      e.x = nx;
    } else {
      // Check if we hit glass tiles
      const txCheck = Math.floor((nx + Math.sign(dx) * r) / TILE);
      const y0 = Math.floor((e.y - 12) / TILE), y1 = Math.floor((e.y - 1.5) / TILE);
      for (let ty = y0; ty <= y1; ty++) {
        if (officeTileAt(l, txCheck, ty) === OT_GLASS) hitGlass.push({ tx: txCheck, ty });
      }
      const step = Math.sign(dx);
      let tries = 0;
      while (tries < 16 && !officeBodySolid(l, e.x + step, e.y, r)) { e.x += step; tries++; }
      bx = true;
    }
  }

  if (dy !== 0) {
    const oldY = e.y;
    const ny = e.y + dy;
    if (dy > 0) {
      // Falling / moving down: stop at solid wall, one-way floor slab, or office desk tabletop crossed from above
      const x0 = Math.floor((e.x - r) / TILE), x1 = Math.floor((e.x + r) / TILE);
      const ty0 = Math.floor(oldY / TILE), ty1 = Math.floor(ny / TILE);
      let landedY: number | null = null;
      for (let ty = ty0; ty <= ty1; ty++) {
        for (let tx = x0; tx <= x1; tx++) {
          const t = officeTileAt(l, tx, ty);
          const surfY = ty * TILE;
          if (t === OT_WALL || t === OT_GLASS) {
            if (oldY <= surfY + 3 && (landedY === null || surfY < landedY)) landedY = surfY;
          } else if (t === OT_FLOOR && !dropThrough) {
            if (oldY <= surfY + 3 && (landedY === null || surfY < landedY)) landedY = surfY;
          }
        }
      }
      const tableY = sideTableSurfaceY(props, e.x, oldY, ny, dropThrough);
      if (tableY !== null && ny >= tableY && (landedY === null || tableY <= landedY)) {
        landedY = tableY;
        onTable = true;
      }
      if (landedY !== null && ny >= landedY) {
        e.y = landedY;
        by = true;
      } else if (!officeBodySolid(l, e.x, ny, r)) {
        e.y = ny;
      } else {
        by = true;
      }
    } else {
      // Jumping / moving UP: one-way floor slabs (OT_FLOOR) and desks do NOT block upward movement!
      const x0 = Math.floor((e.x - r) / TILE), x1 = Math.floor((e.x + r) / TILE);
      const headY = ny - 12;
      const headTy = Math.floor(headY / TILE);
      let hitCeil = false;
      for (let tx = x0; tx <= x1; tx++) {
        const t = officeTileAt(l, tx, headTy);
        if (t === OT_WALL || t === OT_GLASS) { hitCeil = true; break; }
      }
      if (!hitCeil) {
        e.y = ny;
      } else {
        e.y = (headTy + 1) * TILE + 12.1;
        by = true;
      }
    }
  }

  return { bx, by, onTable, hitGlass };
}

/** Shatter a glass partition tile and update both level.officeTiles, level.tiles, and levelCanvas. */
export function shatterOfficeGlassTile(l: Level, canvas: HTMLCanvasElement | null, tx: number, ty: number): Vec | null {
  if (!l.officeTiles || tx < 0 || ty < 0 || tx >= l.w || ty >= l.h) return null;
  const idx = ty * l.w + tx;
  if (l.officeTiles[idx] !== OT_GLASS) return null;
  l.officeTiles[idx] = OT_AIR;
  l.tiles[idx] = 0;

  // Also shatter connected vertical glass pane tiles (entire office partition!)
  const pts: { x: number; y: number }[] = [{ x: tx, y: ty }];
  for (const dir of [-1, 1]) {
    for (let dy = 1; dy <= 4; dy++) {
      const ny = ty + dir * dy;
      if (ny < 0 || ny >= l.h) break;
      const nIdx = ny * l.w + tx;
      if (l.officeTiles[nIdx] === OT_GLASS) {
        l.officeTiles[nIdx] = OT_AIR;
        l.tiles[nIdx] = 0;
        pts.push({ x: tx, y: ny });
      } else break;
    }
  }

  if (canvas && l.officeMap) {
    const ctx = canvas.getContext('2d')!;
    const th = OFFICE_THEMES[l.officeMap.theme] ?? OFFICE_THEMES.cyber_night;
    for (const pt of pts) {
      const X = pt.x * TILE, Y = pt.y * TILE;
      ctx.fillStyle = th.roomBg;
      ctx.fillRect(X, Y, TILE, TILE);
      // subtle wall panel seam + broken glass frame stubs at top/bottom
      ctx.fillStyle = th.roomPanel;
      ctx.fillRect(X + 1, Y + 1, TILE - 2, TILE - 2);
      ctx.fillStyle = th.glassCol + '55';
      ctx.fillRect(X + 6, Y, 4, 2);
      ctx.fillRect(X + 6, Y + TILE - 2, 4, 2);
    }
  }

  return { x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2 };
}

/** Draw the multi-story side-view office building onto an offscreen canvas. */
export function buildOfficeCanvas(l: Level, _pal: Palette): HTMLCanvasElement {
  const cv = document.createElement('canvas');
  cv.width = l.w * TILE;
  cv.height = l.h * TILE;
  const ctx = cv.getContext('2d')!;
  const map = l.officeMap;
  const th = OFFICE_THEMES[map?.theme ?? 'cyber_night'];

  // 1. Night / Dusk City Skyline Background (visible outside windows & above roof)
  const skyGrad = ctx.createLinearGradient(0, 0, 0, cv.height);
  skyGrad.addColorStop(0, th.skyTop);
  skyGrad.addColorStop(1, th.skyBot);
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, cv.width, cv.height);

  // Far & Near skyscraper silhouettes
  for (let bx = 0; bx < cv.width; bx += 28) {
    const hFar = 50 + (hash2(bx, 1, 19) % 130);
    ctx.fillStyle = th.cityFar;
    ctx.fillRect(bx, cv.height - hFar - 40, 26, hFar + 40);
  }
  for (let bx = 8; bx < cv.width; bx += 36) {
    const hNear = 40 + (hash2(bx, 2, 41) % 110);
    const by = cv.height - hNear - 20;
    ctx.fillStyle = th.cityNear;
    ctx.fillRect(bx, by, 32, hNear + 20);
    // Tiny lit skyscraper windows
    for (let wy = by + 6; wy < cv.height - 16; wy += 7) {
      for (let wx = bx + 4; wx < bx + 28; wx += 6) {
        if (hash2(wx, wy, 77) % 5 === 0) {
          ctx.fillStyle = th.cityWin + '77';
          ctx.fillRect(wx, wy, 3, 4);
        }
      }
    }
  }

  // 2. Interior Corporate Rooms (fill inside building bounds)
  for (let ty = 1; ty < l.h - 1; ty++) {
    for (let tx = 1; tx < l.w - 1; tx++) {
      const t = officeTileAt(l, tx, ty);
      if (t === OT_WALL) continue;
      // Check if inside building (walls above/below or inside [2..w-3])
      if (tx >= 2 && tx <= l.w - 3 && ty >= 2 && ty <= l.h - 3) {
        const X = tx * TILE, Y = ty * TILE;
        ctx.fillStyle = th.roomBg;
        ctx.fillRect(X, Y, TILE, TILE);
        // Subtle acoustic drywall panel
        ctx.fillStyle = th.roomPanel;
        ctx.fillRect(X + 1, Y + 1, TILE - 2, TILE - 2);
        // Baseboard stripe near floor tiles
        if (officeTileAt(l, tx, ty + 1) === OT_FLOOR || officeTileAt(l, tx, ty + 1) === OT_WALL) {
          ctx.fillStyle = th.wallShade;
          ctx.fillRect(X, Y + TILE - 3, TILE, 3);
        }
      }
    }
  }

  // 3. Decor (Windows looking out to city skyline, Whiteboards, Cabinets, Server Racks, Ceiling Lights)
  if (map) {
    for (const d of map.decor) {
      const X = d.tx * TILE, Y = d.ty * TILE;
      if (d.kind === 'window') {
        const ww = (d.w ?? 5) * TILE, wh = (d.h ?? 2) * TILE;
        // Cut back to skyline inside window!
        const wSky = ctx.createLinearGradient(0, Y, 0, Y + wh);
        wSky.addColorStop(0, th.skyTop);
        wSky.addColorStop(1, th.skyBot);
        ctx.fillStyle = wSky;
        ctx.fillRect(X, Y, ww, wh);
        // Distant towers inside window
        for (let sx = X + 4; sx < X + ww - 8; sx += 14) {
          const sh = 10 + (hash2(sx, d.ty, 99) % (wh - 6));
          ctx.fillStyle = th.cityNear;
          ctx.fillRect(sx, Y + wh - sh, 10, sh);
          for (let wy = Y + wh - sh + 3; wy < Y + wh - 3; wy += 5) {
            if (hash2(sx, wy, 12) % 3 === 0) {
              ctx.fillStyle = th.cityWin + '99';
              ctx.fillRect(sx + 2, wy, 2, 2);
              ctx.fillRect(sx + 6, wy, 2, 2);
            }
          }
        }
        // Mullion frame & glass reflection
        ctx.strokeStyle = th.wallTrim;
        ctx.lineWidth = 2;
        ctx.strokeRect(X + 1, Y + 1, ww - 2, wh - 2);
        ctx.fillStyle = th.wallTrim;
        for (let mx = X + TILE * 2; mx < X + ww - 4; mx += TILE * 2) {
          ctx.fillRect(mx, Y, 2, wh);
        }
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
        ctx.fillRect(X + 3, Y + 3, ww - 6, 4);
      } else if (d.kind === 'light') {
        const lw = (d.w ?? 3) * TILE;
        ctx.fillStyle = th.wallTrim;
        ctx.fillRect(X + 2, Y, lw - 4, 2);
        ctx.fillStyle = th.lightTint;
        ctx.fillRect(X + 4, Y + 2, lw - 8, 2);
      } else if (d.kind === 'cabinet') {
        ctx.fillStyle = '#3c4559';
        ctx.fillRect(X + 2, Y - 6, 12, 22);
        ctx.fillStyle = '#53607a';
        ctx.fillRect(X + 3, Y - 5, 10, 5);
        ctx.fillRect(X + 3, Y + 2, 10, 5);
        ctx.fillRect(X + 3, Y + 9, 10, 5);
        ctx.fillStyle = '#b9c6e0';
        ctx.fillRect(X + 7, Y - 3, 2, 1);
        ctx.fillRect(X + 7, Y + 4, 2, 1);
        ctx.fillRect(X + 7, Y + 11, 2, 1);
      } else if (d.kind === 'whiteboard') {
        ctx.fillStyle = '#5a6378';
        ctx.fillRect(X - 4, Y - 8, 24, 14);
        ctx.fillStyle = '#dde5ed';
        ctx.fillRect(X - 3, Y - 7, 22, 12);
        ctx.fillStyle = th.accent;
        ctx.fillRect(X, Y - 4, 9, 1);
        ctx.fillStyle = '#2d6cdf';
        ctx.fillRect(X, Y - 1, 14, 1);
        ctx.fillRect(X + 2, Y + 2, 8, 1);
      } else if (d.kind === 'server') {
        ctx.fillStyle = '#19202e';
        ctx.fillRect(X + 2, Y - 10, 12, 26);
        ctx.fillStyle = '#2b364d';
        ctx.fillRect(X + 3, Y - 9, 10, 24);
        for (let sy = Y - 7; sy <= Y + 11; sy += 4) {
          ctx.fillStyle = '#111622';
          ctx.fillRect(X + 4, sy, 8, 2);
          ctx.fillStyle = (sy + X) % 3 === 0 ? th.accent2 : '#39ff88';
          ctx.fillRect(X + 5, sy, 2, 1);
        }
      } else if (d.kind === 'plant_bg') {
        ctx.fillStyle = '#8b4513';
        ctx.fillRect(X + 5, Y + 8, 6, 8);
        ctx.fillStyle = '#2e7d32';
        ctx.fillRect(X + 4, Y, 8, 8);
      }
    }
  }

  // 4. Tiles: Solid Walls (1), One-Way Floor Slabs (2), Stairs (3), Breakable Glass (4), Elevator Pads (5)
  const drawnStair = new Uint8Array(l.w * l.h);
  const drawDiagonalFlight = (
    xStart: number,
    yStart: number,
    xEnd: number,
    yEnd: number,
    steps: number,
  ) => {
    const dx = xEnd - xStart;
    const dy = yEnd - yStart; // negative (going UP)
    const sw = Math.abs(dx) / steps;
    const sh = Math.abs(dy) / steps;
    const dir = dx >= 0 ? 1 : -1;

    // Angled steel stringer beam underneath the steps
    ctx.strokeStyle = '#0d111a';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(xStart, yStart + 2);
    ctx.lineTo(xEnd, yEnd + 4);
    ctx.stroke();

    ctx.strokeStyle = th.slabBody;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(xStart, yStart + 2);
    ctx.lineTo(xEnd, yEnd + 4);
    ctx.stroke();

    // Individual chunky stair steps (riser + tread + bright top edge)
    for (let s = 0; s < steps; s++) {
      const sx0 = xStart + dir * s * sw;
      const sx1 = xStart + dir * (s + 1) * sw;
      const rx = Math.round(Math.min(sx0, sx1));
      const rw = Math.max(3, Math.ceil(Math.abs(sx1 - sx0)) + 1);
      const ry = Math.round(yStart + (s + 1) * (dy / steps));
      const rh = Math.max(3, Math.ceil(sh) + 2);

      // Step riser block
      ctx.fillStyle = th.wallShade;
      ctx.fillRect(rx, ry + 2, rw, rh);
      // Warm/metallic stair tread cap
      ctx.fillStyle = th.stairCol;
      ctx.fillRect(rx - (dir < 0 ? 1 : 0), ry, rw + 1, 2);
      ctx.fillStyle = '#fff3d1';
      ctx.globalAlpha = 0.45;
      ctx.fillRect(rx, ry, rw, 1);
      ctx.globalAlpha = 1;
    }

    // Handrail balusters & angled safety rail
    ctx.fillStyle = th.wallTrim;
    for (let s = 0; s <= steps; s += Math.max(1, Math.floor(steps / 3))) {
      const bx = Math.round(xStart + (s / steps) * dx);
      const by = Math.round(yStart + (s / steps) * dy);
      ctx.fillRect(bx, by - 9, 1, 9);
    }
    pline(ctx, xStart, yStart - 8, xEnd, yEnd - 8, '#0b0d14', 2);
    pline(ctx, xStart, yStart - 9, xEnd, yEnd - 9, th.wallTrim, 1);
    pline(ctx, xStart, yStart - 10, xEnd, yEnd - 10, '#cfd9eb', 1);
  };

  for (let ty = 0; ty < l.h; ty++) {
    for (let tx = 0; tx < l.w; tx++) {
      const t = officeTileAt(l, tx, ty);
      const X = tx * TILE, Y = ty * TILE;
      if (t === OT_WALL) {
        ctx.fillStyle = th.wallFill;
        ctx.fillRect(X, Y, TILE, TILE);
        ctx.fillStyle = th.wallShade;
        ctx.fillRect(X, Y + TILE - 3, TILE, 3);
        ctx.fillRect(X + TILE - 2, Y, 2, TILE);
        if (officeTileAt(l, tx, ty - 1) !== OT_WALL) {
          ctx.fillStyle = th.wallTrim;
          ctx.fillRect(X, Y, TILE, 3);
        }
        if ((tx + ty) % 3 === 0) {
          ctx.fillStyle = 'rgba(255,255,255,0.04)';
          ctx.fillRect(X + 3, Y + 5, 5, 2);
        }
      } else if (t === OT_FLOOR) {
        // Sleek concrete & steel floor slab with drop ceiling underneath
        ctx.fillStyle = th.slabTop;
        ctx.fillRect(X, Y, TILE, 3);
        ctx.fillStyle = th.slabBody;
        ctx.fillRect(X, Y + 3, TILE, 5);
        ctx.fillStyle = th.slabBot;
        ctx.fillRect(X, Y + 8, TILE, 2);
        // Steel I-beam rivets
        ctx.fillStyle = th.wallTrim;
        ctx.fillRect(X + 3, Y + 5, 2, 1);
        ctx.fillRect(X + 11, Y + 5, 2, 1);
      } else if (t === OT_STAIRS) {
        if (drawnStair[ty * l.w + tx]) continue;
        // Measure horizontal span of contiguous OT_STAIRS at this row
        let sx0 = tx, sx1 = tx;
        while (sx0 > 0 && officeTileAt(l, sx0 - 1, ty) === OT_STAIRS) sx0--;
        while (sx1 < l.w - 1 && officeTileAt(l, sx1 + 1, ty) === OT_STAIRS) sx1++;
        const cols = sx1 - sx0 + 1;

        if (cols >= 2) {
          // Multi-tile stairwell bay: find vertical extent matching this bay width
          let sy0 = ty, sy1 = ty;
          while (sy0 > 0) {
            let ok = false;
            for (let x = sx0; x <= sx1; x++) if (officeTileAt(l, x, sy0 - 1) === OT_STAIRS) { ok = true; break; }
            if (!ok) break;
            sy0--;
          }
          while (sy1 < l.h - 1) {
            let ok = false;
            for (let x = sx0; x <= sx1; x++) if (officeTileAt(l, x, sy1 + 1) === OT_STAIRS) { ok = true; break; }
            if (!ok) break;
            sy1++;
          }
          for (let y = sy0; y <= sy1; y++) {
            for (let x = sx0; x <= sx1; x++) {
              if (officeTileAt(l, x, y) === OT_STAIRS) drawnStair[y * l.w + x] = 1;
            }
          }

          const bx = sx0 * TILE, bw = cols * TILE;
          const byTop = sy0 * TILE, byBot = (sy1 + 1) * TILE;
          const totalH = byBot - byTop;

          // Recessed architectural stairwell shaft background
          ctx.fillStyle = 'rgba(6, 8, 14, 0.56)';
          ctx.fillRect(bx + 1, byTop, bw - 2, totalH);
          ctx.fillStyle = th.wallShade;
          ctx.fillRect(bx, byTop, 2, totalH);
          ctx.fillRect(bx + bw - 2, byTop, 2, totalH);

          // Split shaft into 5-tile (80px) floor-to-floor flights with zig-zag switchback steps
          const storyRows = Math.max(1, Math.round((sy1 - sy0 + 1) / 5));
          const segH = totalH / storyRows;
          for (let f = 0; f < storyRows; f++) {
            const sBot = Math.round(byBot - f * segH);
            const sTop = Math.round(byBot - (f + 1) * segH);
            const sMid = Math.round((sBot + sTop) * 0.5);
            const padL = bx + 5;
            const padR = bx + bw - 6;
            const landW = Math.max(10, Math.round(bw * 0.24));

            // Lower flight: left -> right up to mid-landing
            drawDiagonalFlight(padL, sBot - 3, padR - landW + 2, sMid, Math.max(4, Math.min(7, cols + 2)));

            // Mid-landing platform (bordes)
            ctx.fillStyle = th.slabBody;
            ctx.fillRect(padR - landW, sMid, landW + 3, 5);
            ctx.fillStyle = th.stairCol;
            ctx.fillRect(padR - landW, sMid - 1, landW + 3, 2);
            ctx.fillStyle = th.wallTrim;
            ctx.fillRect(padR - landW, sMid - 9, 1, 9);
            ctx.fillRect(padR + 2, sMid - 9, 1, 9);
            pline(ctx, padR - landW, sMid - 9, padR + 2, sMid - 9, '#cfd9eb', 1);

            // Upper flight: mid-landing right -> upper floor left
            drawDiagonalFlight(padR - landW + 1, sMid - 1, padL + 2, sTop + 3, Math.max(4, Math.min(7, cols + 2)));

            // Top landing edge connecting cleanly to the floor slab
            ctx.fillStyle = th.stairCol;
            ctx.fillRect(bx + 2, sTop, Math.min(bw - 4, 14), 2);
          }
        } else {
          drawnStair[ty * l.w + tx] = 1;
          // Check for diagonal stair placement in custom maps
          const diagUpR = officeTileAt(l, tx + 1, ty - 1) === OT_STAIRS || officeTileAt(l, tx - 1, ty + 1) === OT_STAIRS;
          const diagUpL = officeTileAt(l, tx - 1, ty - 1) === OT_STAIRS || officeTileAt(l, tx + 1, ty + 1) === OT_STAIRS;
          if (diagUpR) {
            drawDiagonalFlight(X, Y + TILE - 1, X + TILE, Y - 1, 4);
          } else if (diagUpL) {
            drawDiagonalFlight(X + TILE, Y + TILE - 1, X, Y - 1, 4);
          } else {
            // Single-column industrial steel access ladder
            ctx.fillStyle = 'rgba(0,0,0,0.28)';
            ctx.fillRect(X + 3, Y, TILE - 6, TILE);
            ctx.fillStyle = th.wallTrim;
            ctx.fillRect(X + 3, Y, 2, TILE);
            ctx.fillRect(X + TILE - 5, Y, 2, TILE);
            ctx.fillStyle = th.stairCol;
            for (let sy = 2; sy < TILE; sy += 4) {
              ctx.fillRect(X + 4, Y + sy, TILE - 8, 2);
            }
          }
        }
      } else if (t === OT_GLASS) {
        // Translucent cyan/tint glass partition with diagonal specular streaks
        ctx.fillStyle = th.glassCol + '38';
        ctx.fillRect(X + 5, Y, 6, TILE);
        ctx.fillStyle = th.glassCol + 'aa';
        ctx.fillRect(X + 5, Y, 1, TILE);
        ctx.fillRect(X + 10, Y, 1, TILE);
        ctx.fillStyle = '#ffffff88';
        ctx.fillRect(X + 7, Y + 3, 2, 4);
        ctx.fillRect(X + 7, Y + 11, 2, 3);
      } else if (t === OT_ELEV) {
        // Elevator shaft frame + glowing up pad
        ctx.fillStyle = th.wallShade;
        ctx.fillRect(X + 1, Y, TILE - 2, TILE);
        ctx.fillStyle = th.accent2 + '44';
        ctx.fillRect(X + 2, Y + 2, TILE - 4, TILE - 2);
        ctx.fillStyle = th.accent2;
        ctx.fillRect(X + 2, Y + TILE - 3, TILE - 4, 2);
        // Up chevron
        px(ctx, X + 8, Y + 7, th.accent2);
        pline(ctx, X + 5, Y + 10, X + 8, Y + 7, th.accent2, 1);
        pline(ctx, X + 11, Y + 10, X + 8, Y + 7, th.accent2, 1);
      }
    }
  }

  // 5. Floor Stencil Numbers (LT 1, LT 2, ...) & Left/Right Security Entry Doors
  if (l.officeFloors) {
    l.officeFloors.forEach((fy, idx) => {
      const floorNum = idx + 1;
      pfontO(ctx, `LT ${floorNum}`, 38, fy - 24, th.wallTrim, '#000', 1, 'left');
    });
  }
  const drawGateDoor = (gx: number, gy: number, side: 'L' | 'R') => {
    const X = Math.round(gx - 8), Y = Math.round(gy - 24);
    prect(ctx, X, Y, 16, 24, th.wallShade);
    prect(ctx, X + 2, Y + 2, 12, 22, '#0b0e14');
    prect(ctx, X + 2, Y + 2, 12, 2, th.accent);
    pfontO(ctx, side === 'L' ? 'IN>' : '<IN', gx, Y - 5, th.accent, '#000', 1, 'center');
  };
  for (const g of l.leftSpawns ?? []) drawGateDoor(g.x, g.y, 'L');
  for (const g of l.rightSpawns ?? []) drawGateDoor(g.x, g.y, 'R');

  return cv;
}

/** Live animated ambient effects for side-view office (light cones, elevator glow, rain/dust). */
export function drawOfficeAmbience(ctx: Ctx, l: Level, camX: number, camY: number, time: number, sw: number, sh: number) {
  const map = l.officeMap;
  if (!map) return;
  const th = OFFICE_THEMES[map.theme] ?? OFFICE_THEMES.cyber_night;

  // Soft fluorescent light cones under ceiling light fixtures visible on screen
  for (const d of map.decor) {
    if (d.kind !== 'light') continue;
    const lx = d.tx * TILE, ly = d.ty * TILE + 4;
    const lw = (d.w ?? 3) * TILE;
    if (lx + lw < camX - 20 || lx > camX + sw + 20 || ly + 48 < camY || ly > camY + sh) continue;
    const flicker = (hash2(d.tx, d.ty, 7) % 5 === 0 && Math.sin(time * 24 + d.tx) > 0.92) ? 0.03 : 0.08;
    ctx.fillStyle = th.lightTint;
    ctx.globalAlpha = flicker;
    ctx.beginPath();
    ctx.moveTo(lx + 4, ly);
    ctx.lineTo(lx + lw - 4, ly);
    ctx.lineTo(lx + lw + 10, ly + 46);
    ctx.lineTo(lx - 10, ly + 46);
    ctx.closePath();
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  // Pulsing glow on Left & Right spawn doors
  const pulse = 0.25 + 0.2 * Math.sin(time * 5);
  ctx.globalAlpha = pulse;
  for (const g of [...(l.leftSpawns ?? []), ...(l.rightSpawns ?? [])]) {
    if (g.x < camX - 24 || g.x > camX + sw + 24 || g.y < camY - 24 || g.y > camY + sh + 24) continue;
    prect(ctx, Math.round(g.x - 5), Math.round(g.y - 20), 10, 18, th.accent);
  }
  ctx.globalAlpha = 1;

  // Subtle floating dust / office air motes
  for (let i = 0; i < 18; i++) {
    const mx = camX + ((hash2(i, 1, 31) + time * (6 + (i % 5))) % sw);
    const my = camY + ((hash2(i, 2, 57) + Math.sin(time * 0.9 + i) * 14) % sh);
    ctx.globalAlpha = 0.22;
    px(ctx, mx, my, th.lightTint);
  }
  ctx.globalAlpha = 1;
}

/** Determine which story floor number (1-based) an entity at y is currently on. */
export function officeFloorIndex(l: Level, y: number): number {
  const floors = l.officeFloors;
  if (!floors || floors.length === 0) return 1;
  let best = 1;
  let bestDist = Infinity;
  floors.forEach((fy, idx) => {
    const d = Math.abs(y - fy);
    if (d < bestDist) { bestDist = d; best = idx + 1; }
  });
  return best;
}
