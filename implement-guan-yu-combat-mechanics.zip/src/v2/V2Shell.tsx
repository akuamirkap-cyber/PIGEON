import { useEffect } from 'react';
import V2App from './App';
import './v2.css';

/** GAME V2 (numpang): game dari repo PIGEON zip kedua, berjalan terisolasi dari game V1.
 *  Kode di src/v2, penyimpanan berprefiks v2_, CSS dikurung di .v2-root. */
export default function V2Shell({ onBack }: { onBack: () => void }) {
  useEffect(() => {
    const prev = document.title;
    document.title = 'Kungfu Drifter V2 – Kantor Side-View (numpang)';
    return () => {
      document.title = prev;
      // V2 menempelkan kelas render ke <body>; bersihkan supaya V1 tidak ikut halus/2D
      document.body.classList.remove('smooth-mode', 'view-2d');
      delete (window as unknown as { __kf?: unknown }).__kf;
    };
  }, []);
  return (
    <div className="v2-root">
      <V2App />
      <button type="button" className="v2-back" title="Kembali ke game V1 (Menara Kantor)" onClick={onBack}>
        <b>◀</b> GAME V1
      </button>
    </div>
  );
}
