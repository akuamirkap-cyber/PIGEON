import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { Maximize2, Minimize2, Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { OfficeGame, type OfficeUI } from './engine';
import { loadCustomMap, type OfficeMap } from './map';
import { defaultMap, LEVEL_COUNT, levelSpec } from './gen';
import { ATMO_NAME, type AtmoId } from './atmo';
import type { SoundVersion } from '../maxkungfu/game/soundPacks';
import './office.css';

interface Props {
  soundVersion: SoundVersion;
  /** peta dari editor untuk uji main (langsung mulai) */
  testMap: OfficeMap | null;
  /** pengali kecepatan jurus (1 = asli) */
  tempo: number;
  /** suasana: auto / subuh / pagi / siang / sore / malam / hujan */
  atmo: 'auto' | AtmoId;
  /** kontrol senjata: V2 (mouse membidik, klik kiri/kanan) atau keyboard (J/K) */
  ctrl: 'v2' | 'kbd';
  onClassic: () => void;
  onEditor: () => void;
  onBackToEditor?: () => void;
  /** pindah ke GAME V2 (numpang) */
  onV2?: () => void;
}

const initialUI: OfficeUI = { level: 0, levelGoal: 0, levelMax: 1, atmo: 'malam', atmoMode: 'auto', state: 'title', wave: 0, score: 0, kills: 0, bestCombo: 0, floor: '', best: { score: 0, wave: 0 }, muted: false, mapName: '', time: 0, floorsClimbed: 0, ally: false, ctrl: 'v2' };

function TouchBtn({ code, label, game, className = '', children }: { code: string; label: string; game: React.RefObject<OfficeGame | null>; className?: string; children: ReactNode }) {
  const down = useRef(false);
  const press = (e: React.PointerEvent) => { e.preventDefault(); e.stopPropagation(); if (down.current) return; down.current = true; (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); game.current?.setKey(code, true); };
  const release = () => { if (!down.current) return; down.current = false; game.current?.setKey(code, false); };
  return <button type="button" aria-label={label} className={`of-touch-btn ${className}`} onPointerDown={press} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}>{children}</button>;
}

export default function OfficeApp({ soundVersion, testMap, tempo, atmo, ctrl, onClassic, onEditor, onBackToEditor, onV2 }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<OfficeGame | null>(null);
  const [ui, setUi] = useState<OfficeUI>(initialUI);
  const [menuIdx, setMenuIdx] = useState(0);
  const [panel, setPanel] = useState<'none' | 'help' | 'levels'>('none');
  const lastLevel = useRef(0);
  const [done, setDone] = useState<Set<number>>(new Set());
  const [custom, setCustom] = useState<OfficeMap | null>(() => loadCustomMap());
  const [size, setSize] = useState({ w: 960, h: 540 });
  const [fs, setFs] = useState(false);
  const [touch, setTouch] = useState(() => window.matchMedia('(pointer: coarse)').matches);
  const lastMap = useRef<OfficeMap>(defaultMap());

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const g = new OfficeGame(cv, soundVersion);
    gameRef.current = g;
    g.onUI = setUi;
    if (testMap) { lastMap.current = testMap; g.newGame(testMap); }
    else g.showTitle(defaultMap());
    g.start();
    (window as unknown as { __office?: OfficeGame }).__office = g;
    return () => { g.destroy(); if (gameRef.current === g) gameRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { gameRef.current?.setTempo(tempo); }, [tempo]);
  useEffect(() => { gameRef.current?.setAtmoMode(atmo); }, [atmo]);
  useEffect(() => { gameRef.current?.setCtrl(ctrl); }, [ctrl]);

  // kanvas 16:9 menyesuaikan ruang
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const calc = () => {
      const r = el.getBoundingClientRect();
      const deck = touch && window.innerHeight > window.innerWidth ? 190 : 0;
      const w = Math.max(240, Math.min(r.width, (r.height - deck) * 16 / 9));
      setSize({ w: Math.floor(w), h: Math.floor(w * 9 / 16) });
    };
    calc();
    const ro = new ResizeObserver(calc);
    ro.observe(el);
    window.addEventListener('resize', calc);
    return () => { ro.disconnect(); window.removeEventListener('resize', calc); };
  }, [touch]);

  useEffect(() => {
    const onFs = () => setFs(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFs);
    const mq = window.matchMedia('(pointer: coarse)');
    const onMq = () => setTouch(mq.matches);
    mq.addEventListener?.('change', onMq);
    return () => { document.removeEventListener('fullscreenchange', onFs); mq.removeEventListener?.('change', onMq); };
  }, []);

  const startLevel = useCallback((n: number) => { lastLevel.current = n; setPanel('none'); gameRef.current?.sfx.init(); gameRef.current?.sfx.select(); gameRef.current?.startLevel(n); }, []);
  const openLevels = useCallback(() => { try { setDone(new Set(JSON.parse(localStorage.getItem('office_level_done') || '[]') as number[])); } catch { setDone(new Set()); } gameRef.current?.sfx.select(); setPanel('levels'); }, []);
  const retry = () => (lastLevel.current ? startLevel(lastLevel.current) : start(lastMap.current));
  const start = useCallback((m: OfficeMap) => { lastLevel.current = 0; lastMap.current = m; setPanel('none'); gameRef.current?.sfx.init(); gameRef.current?.sfx.select(); gameRef.current?.newGame(m); }, []);
  const toTitle = useCallback(() => { setCustom(loadCustomMap()); gameRef.current?.sfx.stopMusic(); gameRef.current?.showTitle(defaultMap()); setMenuIdx(0); }, []);

  const items: { id: string; label: string; sub: string; disabled?: boolean; run: () => void }[] = [
    { id: 'tower', label: 'MULAI: MENARA NAGA', sub: '6 lantai, 96 petak - wave tanpa akhir', run: () => start(defaultMap()) },
    { id: 'levels', label: 'MODE 100 LEVEL', sub: `terbuka sampai level ${ui.levelMax} dari ${LEVEL_COUNT}`, run: () => openLevels() },
    { id: 'custom', label: 'MAIN MAP KUSTOM', sub: custom ? custom.name : 'belum ada - buat di DESAIN MAP', disabled: !custom, run: () => custom && start(custom) },
    { id: 'editor', label: 'DESAIN MAP', sub: 'rancang gedung kantormu sendiri', run: () => { gameRef.current?.sfx.select(); onEditor(); } },
    { id: 'help', label: 'CARA MAIN', sub: 'kontrol & jurus', run: () => { gameRef.current?.sfx.select(); setPanel('help'); } },
    { id: 'classic', label: 'ARENA 3/4 KLASIK', sub: 'kembali ke Kungfu Drifter top-down', run: () => onClassic() },
    ...(onV2 ? [{ id: 'v2', label: 'GAME V2 (NUMPANG)', sub: 'versi kantor dari zip kedua - terpisah', run: () => onV2() }] : []),
  ];

  useEffect(() => {
    if (ui.state !== 'title') return;
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (panel !== 'none') { if (['Escape', 'Enter', 'Space'].includes(e.code)) { e.preventDefault(); setPanel('none'); } return; }
      if (e.code === 'ArrowDown' || e.code === 'KeyS') { e.preventDefault(); setMenuIdx((i) => (i + 1) % items.length); gameRef.current?.sfx.init(); gameRef.current?.sfx.beep(); }
      else if (e.code === 'ArrowUp' || e.code === 'KeyW') { e.preventDefault(); setMenuIdx((i) => (i - 1 + items.length) % items.length); gameRef.current?.sfx.init(); gameRef.current?.sfx.beep(); }
      else if (e.code === 'Enter') { e.preventDefault(); const it = items[menuIdx]; if (!it.disabled) it.run(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const toggleFs = () => {
    const el = document.documentElement;
    if (document.fullscreenElement) void document.exitFullscreen().catch(() => {});
    else void el.requestFullscreen?.().catch(() => {});
  };
  const g = () => gameRef.current;
  const newBest = ui.state === 'over' && ui.score > 0 && ui.score >= ui.best.score;

  return (
    <div className="of-root">
      <div ref={wrapRef} className="of-stage">
        <div className="of-frame" style={{ width: size.w, height: size.h }}>
          <canvas ref={canvasRef} className="of-canvas" style={{ width: size.w, height: size.h }} />

          <div className="of-tools" onPointerDown={(e) => e.stopPropagation()}>
            {(ui.state === 'playing' || ui.state === 'paused') && (
              <button type="button" className="of-icon" aria-label={ui.state === 'paused' ? 'Lanjut' : 'Jeda'} onClick={() => g()?.togglePause()}>
                {ui.state === 'paused' ? <Play size={14} /> : <Pause size={14} />}
              </button>
            )}
            <button type="button" className="of-icon" aria-label={ui.muted ? 'Nyalakan suara' : 'Matikan suara'} onClick={() => g()?.toggleMute()}>
              {ui.muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            <button type="button" className="of-icon" aria-label="Layar penuh" onClick={toggleFs}>{fs ? <Minimize2 size={14} /> : <Maximize2 size={14} />}</button>
            {(ui.state === 'playing' || ui.state === 'paused') && (
              <button type="button" className={`of-icon of-icon--txt ${ui.ally ? 'is-on' : ''}`} aria-label="Bot sekutu" title="Bot sekutu ahli kombo (M)" onClick={() => g()?.toggleAlly()}>BOT</button>
            )}
            <button type="button" className={`of-icon of-icon--txt ${touch ? 'is-on' : ''}`} aria-label="Kontrol sentuh" onClick={() => setTouch((v) => !v)}>TOUCH</button>
          </div>

          {ui.state === 'title' && (
            <div className="of-overlay of-title" onPointerDown={(e) => e.stopPropagation()}>
              <div className="of-logo pixel">
                <span className="of-logo__sub">KUNGFU DRIFTER</span>
                <h1 className="of-logo__main">MENARA<br />KANTOR</h1>
                <span className="of-logo__tag">SIDE VIEW - BERTAHAN DARI KIRI &amp; KANAN</span>
              </div>
              <nav className="of-menu" aria-label="Menu mode side view">
                {items.map((it, i) => (
                  <button key={it.id} type="button" disabled={it.disabled}
                    className={`of-item pixel ${menuIdx === i ? 'is-on' : ''}`}
                    style={{ animationDelay: `${0.15 + i * 0.07}s` }}
                    onPointerEnter={() => setMenuIdx(i)} onFocus={() => setMenuIdx(i)} onClick={() => !it.disabled && it.run()}>
                    <span className="of-caret">{menuIdx === i ? '>' : ''}</span>
                    <span className="of-item__label">{it.label}</span>
                    <span className="of-item__sub">{it.sub}</span>
                  </button>
                ))}
                <div className="of-best pixel">REKOR: {ui.best.score.toLocaleString('id-ID')} - WAVE {ui.best.wave}</div>
              </nav>
            </div>
          )}

          {panel === 'help' && (
            <div className="of-overlay of-dim" onPointerDown={(e) => e.stopPropagation()}>
              <div className="of-panel pixel">
                <div className="of-panel__head">CARA MAIN</div>
                <div className="of-help">
                  <div><b>KONTROL V2 (MOUSE)</b><span>sama persis dengan game V2: kursor = arah hadap &amp; bidikan. Tangan kosong saat berlari menghadap arah lari</span></div>
                  <div><b>A / D · SPASI</b><span>jalan (tahan = lari) · lompat (S+SPASI turun pijakan) · W/S pintu, lift, tangga</span></div>
                  <div><b>KLIK KIRI</b><span>serang ringan / tembak. Tempo klik kungfu: cepat = WING CHUN, sedang = BLACK LEG, lambat = KUNG FU</span></div>
                  <div><b>KLIK KANAN</b><span>serang berat (pistol = TRIK SHOT, busur = AKROBAT, shotgun = ISI ULANG, kapak = LEMPAR)</span></div>
                  <div><b>LARI + KLIK KIRI</b><span>Taekwondo · Iaijutsu (katana) · Grand Slam (pemukul) · Dragon Lash · dash cut</span></div>
                  <div><b>DI UDARA</b><span>kiri = Air Jab, Air Cross, Air Kick, Axe Slam · kanan = Meteor Spike</span></div>
                  <div><b>TAHAN</b><span>pemukul &amp; tinju = spam · yoyo kanan = orbit · nunchaku = rantai api · busur = tarik · buster kiri = isi tenaga → BLADE BEAM</span></div>
                  <div><b>1 2 3 4 5 6 7 8 9 0</b><span>kungfu, pistol, senapan, nunchaku, katana, kapak, pedang kembar, yoyo, takamura, hayabusa</span></div>
                  <div><b>Z T Y U I J</b><span>guan dao (Z lagi = atraksi), pemukul, shotgun, busur, buster, tinju (skema keyboard: B)</span></div>
                  <div><b>Q / RODA MOUSE</b><span>ganti senjata berikutnya</span></div>
                  <div><b>SHIFT · C</b><span>dash · tangkis (tepat waktu = PARRY + counter x2)</span></div>
                  <div><b>F · R · G · M</b><span>eksekusi musuh pusing · CHI penuh = Tinju Naga · angkat &amp; lempar · bot sekutu</span></div>
                  <div><b>N · X</b><span>Pembukaan 8 Gerbang (gerbang 3+: kanan = Lotus) · One For All</span></div>
                  <div><b>KONTROL KEYBOARD</b><span>pilih di bilah bawah: J ringan, K berat, B tinju, W/S membidik</span></div>
                </div>
                <p className="of-panel__note">Banting musuh ke kaca jendela untuk DEFENESTRASI, ke dinding untuk WALL SPLAT, ke perabot untuk menghancurkannya. Bos MASTER bisa mengajak ADU PUKULAN: tekan J/K secepatnya! Musuh PERISAI menahan serangan dari depan: lompati, serang saat dia menyerang, atau ANGKAT &amp; banting. BOM bisa dipukul balik atau ditembak. Lempar musuh ke RAK SERVER = kesetrum. Lindungi karyawan kantor yang kabur: tiap yang selamat +50.</p>
                <button type="button" className="of-btn" onClick={() => setPanel('none')}>MENGERTI</button>
              </div>
            </div>
          )}

          {ui.state === 'paused' && (
            <div className="of-overlay of-dim" onPointerDown={(e) => e.stopPropagation()}>
              <div className="of-panel pixel">
                <div className="of-panel__head">JEDA</div>
                <div className="of-stats"><span>WAVE {ui.wave}</span><span>{ui.floor}</span><span>SKOR {ui.score.toLocaleString('id-ID')}</span></div>
                <button type="button" className="of-btn" onClick={() => g()?.togglePause()}>LANJUT</button>
                <button type="button" className="of-btn" onClick={retry}>{lastLevel.current ? `ULANGI LEVEL ${lastLevel.current}` : 'ULANGI'}</button>
                {onBackToEditor && <button type="button" className="of-btn" onClick={onBackToEditor}>KEMBALI KE EDITOR</button>}
                <button type="button" className="of-btn of-btn--ghost" onClick={toTitle}>MENU UTAMA</button>
              </div>
            </div>
          )}

          {panel === 'levels' && (
            <div className="of-overlay of-dim" onPointerDown={(e) => e.stopPropagation()}>
              <div className="of-panel of-panel--wide pixel">
                <div className="of-panel__head">MODE 100 LEVEL</div>
                <p className="of-panel__note">Taklukkan Menara Naga lantai demi lantai. Tiap level punya gedung baru 2x lebih luas, susunan ruangan, suasana &amp; tingkat kesulitan sendiri. Level kelipatan 10 = lantai direksi + bos.</p>
                <div className="of-levels">
                  {Array.from({ length: LEVEL_COUNT }, (_, i) => i + 1).map((n) => {
                    const sp = levelSpec(n), locked = n > ui.levelMax;
                    return (
                      <button key={n} type="button" disabled={locked} title={`LEVEL ${n}: ${sp.stories} lantai, ${sp.waves} wave, ${ATMO_NAME[sp.atmo]}${sp.boss ? ', BOS' : ''}`}
                        className={`of-lv ${done.has(n) ? 'is-done' : ''} ${sp.boss ? 'is-boss' : ''}`} onClick={() => startLevel(n)}>{locked ? '-' : n}</button>
                    );
                  })}
                </div>
                <button type="button" className="of-btn of-btn--ghost" onClick={() => setPanel('none')}>KEMBALI</button>
              </div>
            </div>
          )}

          {ui.state === 'levelclear' && (
            <div className="of-overlay of-dim" onPointerDown={(e) => e.stopPropagation()}>
              <div className="of-panel pixel">
                <div className="of-panel__head of-panel__head--green">{ui.level >= LEVEL_COUNT ? 'MENARA DITAKLUKKAN!' : `LEVEL ${ui.level} SELESAI!`}</div>
                <div className="of-grid">
                  <div><small>SKOR</small><b>{ui.score.toLocaleString('id-ID')}</b></div>
                  <div><small>KO</small><b>{ui.kills}</b></div>
                  <div><small>KOMBO</small><b>{ui.bestCombo}</b></div>
                  <div><small>WAVE</small><b>{ui.wave}</b></div>
                  <div><small>LANTAI NAIK</small><b>{ui.floorsClimbed}</b></div>
                  <div><small>SUASANA</small><b>{ATMO_NAME[ui.atmo]}</b></div>
                </div>
                {ui.level < LEVEL_COUNT && (() => { const nx = levelSpec(ui.level + 1); return (
                  <button type="button" className="of-btn" onClick={() => startLevel(ui.level + 1)}>LANJUT LEVEL {ui.level + 1} - {nx.stories} LANTAI, {ATMO_NAME[nx.atmo]}{nx.boss ? ', BOS!' : ''}</button>
                ); })()}
                <button type="button" className="of-btn" onClick={() => { toTitle(); openLevels(); }}>PILIH LEVEL</button>
                <button type="button" className="of-btn of-btn--ghost" onClick={toTitle}>MENU UTAMA</button>
              </div>
            </div>
          )}

          {ui.state === 'over' && (
            <div className="of-overlay of-dim of-dim--red" onPointerDown={(e) => e.stopPropagation()}>
              <div className="of-panel pixel">
                <div className="of-panel__head of-panel__head--red">K.O.</div>
                {newBest && <div className="of-newbest">REKOR BARU!</div>}
                <div className="of-grid">
                  <div><small>WAVE</small><b>{ui.wave}</b></div>
                  <div><small>SKOR</small><b>{ui.score.toLocaleString('id-ID')}</b></div>
                  <div><small>KO</small><b>{ui.kills}</b></div>
                  <div><small>KOMBO</small><b>{ui.bestCombo}</b></div>
                  <div><small>LANTAI NAIK</small><b>{ui.floorsClimbed}</b></div>
                  <div><small>LOKASI</small><b>{ui.floor}</b></div>
                </div>
                <button type="button" className="of-btn" onClick={retry}>{lastLevel.current ? `ULANGI LEVEL ${lastLevel.current}` : 'COBA LAGI'}</button>
                {onBackToEditor && <button type="button" className="of-btn" onClick={onBackToEditor}>KEMBALI KE EDITOR</button>}
                <button type="button" className="of-btn of-btn--ghost" onClick={toTitle}>MENU UTAMA</button>
              </div>
            </div>
          )}
        </div>

        {touch && ui.state === 'playing' && (
          <div className="of-touch" onContextMenu={(e) => e.preventDefault()}>
            <div className="of-dpad">
              <TouchBtn game={gameRef} code="KeyW" label="Atas / pintu" className="up">▲</TouchBtn>
              <TouchBtn game={gameRef} code="KeyA" label="Kiri" className="left">◀</TouchBtn>
              <TouchBtn game={gameRef} code="KeyS" label="Bawah" className="down">▼</TouchBtn>
              <TouchBtn game={gameRef} code="KeyD" label="Kanan" className="right">▶</TouchBtn>
            </div>
            <div className="of-acts">
              <TouchBtn game={gameRef} code="Mouse0" label="Pukul" className="big">PUKUL</TouchBtn>
              <TouchBtn game={gameRef} code="Mouse2" label="Serangan berat" className="big">BERAT</TouchBtn>
              <TouchBtn game={gameRef} code="Space" label="Lompat">LOMPAT</TouchBtn>
              <TouchBtn game={gameRef} code="KeyL" label="Dash">DASH</TouchBtn>
              <TouchBtn game={gameRef} code="KeyC" label="Tangkis">TANGKIS</TouchBtn>
              <TouchBtn game={gameRef} code="KeyF" label="Eksekusi">EKSEKUSI</TouchBtn>
              <TouchBtn game={gameRef} code="KeyR" label="Chi">CHI</TouchBtn>
              <TouchBtn game={gameRef} code="KeyQ" label="Ganti senjata">SENJATA</TouchBtn>
              <TouchBtn game={gameRef} code="KeyG" label="Angkat dan lempar">G ANGKAT</TouchBtn>
              <TouchBtn game={gameRef} code="KeyN" label="Delapan Gerbang">N GERBANG</TouchBtn>
              <TouchBtn game={gameRef} code="KeyX" label="One For All">X OFA</TouchBtn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
