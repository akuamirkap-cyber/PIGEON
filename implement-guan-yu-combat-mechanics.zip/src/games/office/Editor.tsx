import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Brush, Hand, Minus, Plus, RotateCcw, Square, ZoomIn, ZoomOut } from 'lucide-react';
import { TILES, TILE_BY_CH, STORY, T, PROP_CHARS, type OfficeMap, type TileDef, THEMES, THEME_IDS, blankMap, normalizeMap, saveCustomMap, loadCustomMap, exportMap, importMap, storiesOf, themeOf, floorLabel } from './map';
import { defaultMap, randomTower } from './gen';
import { buildBuilding, drawProp, drawConnector, drawGlassTile, hh } from './art';
import { drawStick } from '../../v2/games/maxkungfu/game/stick';
import './office.css';

interface Props { initial: OfficeMap; onPlay: (m: OfficeMap) => void; onExit: () => void; onChange: (m: OfficeMap) => void }
type Tool = 'brush' | 'rect' | 'pan';

function stickAt(g: CanvasRenderingContext2D, x: number, y: number, c: string, c2: string, alpha = 1) {
  drawStick(g, { x, y, c, c2, scale: 1, facing: 1, aim: 0, walk: 0, moving: false, pose: 'idle', t: 0, acc: 'headband', weapon: 'none', flash: false, alpha, outline: '#000', eyes: '#111', time: 0, lean: { x: 1, y: 0 }, anime: true });
}

/** gambar peta lengkap (gedung + kaca + pintu + perabot + penanda) untuk editor */
function composeWorld(m: OfficeMap): HTMLCanvasElement {
  const { cv } = buildBuilding(m);
  const g = cv.getContext('2d')!;
  g.imageSmoothingEnabled = false;
  for (let r = 0; r < m.h; r++) for (let c = 0; c < m.w; c++) {
    const ch = m.rows[r][c];
    const x = c * T, yF = (r + 1) * T, s = Math.floor(r / STORY);
    if (ch === 'G') drawGlassTile(g, x, r * T, true, m.rows[r - 1]?.[c] !== 'G', m.rows[r + 1]?.[c] !== 'G', 0);
    else if (ch === 'S' || ch === 'E') drawConnector(g, ch, x, yF, 0, 0);
    else if (PROP_CHARS.includes(ch)) drawProp(g, ch, x, yF, { broken: false, t: 0, seed: hh(c, r, 5), shake: 0, nl: m.rows[r][c - 1] === ch, nr: m.rows[r][c + 1] === ch, th: themeOf(m, s) });
    else if (ch === 'P') stickAt(g, x + 8, yF, '#ffffff', '#ff3b3b');
    else if (ch === 'X') {
      g.fillStyle = 'rgba(255,77,109,0.85)'; g.beginPath(); g.moveTo(x + 8, yF - 2); g.lineTo(x + 3, yF - 9); g.lineTo(x + 13, yF - 9); g.closePath(); g.fill();
      g.fillRect(x + 6, yF - 15, 4, 6);
      stickAt(g, x + 8, yF - 1, '#ff8f8f', '#5a1010', 0.45);
    }
  }
  return cv;
}

function iconFor(t: TileDef): string {
  const cv = document.createElement('canvas'); cv.width = 16; cv.height = 32;
  const g = cv.getContext('2d')!;
  g.fillStyle = '#2c3045'; g.fillRect(0, 0, 16, 32);
  const th = themeOf(defaultMap(), 4);
  switch (t.kind) {
    case 'air': g.strokeStyle = '#ff5a5a'; g.lineWidth = 2; g.beginPath(); g.moveTo(3, 11); g.lineTo(13, 21); g.moveTo(13, 11); g.lineTo(3, 21); g.stroke(); break;
    case 'solid': g.fillStyle = '#454a58'; g.fillRect(0, 16, 16, 16); g.fillStyle = '#4c5f80'; g.fillRect(0, 16, 16, 5); g.fillStyle = '#7a8cab'; g.fillRect(0, 16, 16, 1); break;
    case 'platform': g.fillStyle = '#7d8494'; g.fillRect(0, 16, 16, 4); g.fillStyle = '#b8c0cf'; g.fillRect(0, 16, 16, 1); g.fillStyle = '#aab3c2'; g.fillRect(0, 7, 16, 1); g.fillRect(0, 7, 1, 9); g.fillRect(15, 7, 1, 9); break;
    case 'ladder': g.fillStyle = '#d7ab52'; g.fillRect(3, 0, 1, 32); g.fillRect(12, 0, 1, 32); for (let y = 2; y < 32; y += 4) g.fillRect(3, y, 10, 1); break;
    case 'glass': drawGlassTile(g, 0, 0, true, true, false, 0); drawGlassTile(g, 0, 16, true, false, true, 0); break;
    case 'door': case 'elevator': g.fillStyle = '#0b0c10'; g.fillRect(0, 6, 16, 26); drawConnector(g, t.ch, 0, 32, 0, 0); break;
    case 'spawn': g.fillStyle = '#ff4d6d'; g.beginPath(); g.moveTo(8, 30); g.lineTo(2, 20); g.lineTo(14, 20); g.closePath(); g.fill(); g.fillRect(6, 10, 4, 10); break;
    case 'player': stickAt(g, 8, 31, '#ffffff', '#ff3b3b'); break;
    case 'prop': drawProp(g, t.ch, 0, 32, { broken: false, t: 0, seed: 0.8, shake: 0, nl: false, nr: false, th }); break;
    case 'deco': g.fillStyle = '#d9dde3'; g.fillRect(1, 9, 14, 11); g.fillStyle = '#f7f9fb'; g.fillRect(2, 10, 12, 9); g.fillStyle = '#3a6fd8'; g.fillRect(4, 12, 6, 1); g.fillStyle = '#d83a3a'; g.fillRect(4, 15, 8, 1); break;
  }
  return cv.toDataURL();
}

export default function Editor({ initial, onPlay, onExit, onChange }: Props) {
  const [map, setMap] = useState<OfficeMap>(() => normalizeMap(initial));
  const mapRef = useRef(map);
  const [sel, setSel] = useState('#');
  const [tool, setTool] = useState<Tool>('brush');
  const [hover, setHover] = useState<{ c: number; r: number } | null>(null);
  const [view, setView] = useState({ z: 2, ox: 20, oy: 20 });
  const [modal, setModal] = useState<'none' | 'export' | 'import'>('none');
  const [text, setText] = useState('');
  const [toast, setToast] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLCanvasElement | null>(null);
  const undo = useRef<OfficeMap[]>([]);
  const drag = useRef<{ mode: 'paint' | 'erase' | 'pan' | 'rect'; sx: number; sy: number; ox: number; oy: number; c0: number; r0: number; last: { c: number; r: number } | null; ch: string } | null>(null);
  const [rect, setRect] = useState<{ c0: number; r0: number; c1: number; r1: number } | null>(null);
  const spaceDown = useRef(false);
  const dirty = useRef(true);
  const icons = useMemo(() => Object.fromEntries(TILES.map((t) => [t.ch, iconFor(t)])), []);

  const flash = (m: string) => { setToast(m); window.setTimeout(() => setToast((t) => (t === m ? '' : t)), 1800); };
  const commit = useCallback((m: OfficeMap, push = true) => {
    if (push) { undo.current.push(mapRef.current); if (undo.current.length > 60) undo.current.shift(); }
    mapRef.current = m; dirty.current = true; setMap(m); onChange(m);
  }, [onChange]);

  const fit = useCallback(() => {
    const box = boxRef.current; if (!box) return;
    const r = box.getBoundingClientRect(), m = mapRef.current;
    const z = Math.max(0.5, Math.min(4, Math.min((r.width - 40) / (m.w * T), (r.height - 40) / (m.h * T))));
    setView({ z, ox: (r.width - m.w * T * z) / 2, oy: (r.height - m.h * T * z) / 2 });
  }, []);
  useEffect(() => { fit(); }, [fit]);

  // ---------- render ----------
  useEffect(() => {
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const cv = canvasRef.current, box = boxRef.current;
      if (!cv || !box) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1), r = box.getBoundingClientRect();
      const W = Math.round(r.width * dpr), H = Math.round(r.height * dpr);
      if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      if (dirty.current || !worldRef.current) { worldRef.current = composeWorld(mapRef.current); dirty.current = false; }
      const m = mapRef.current, g = cv.getContext('2d')!;
      g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = '#0a0c14'; g.fillRect(0, 0, W, H);
      const { z, ox, oy } = viewRef.current;
      g.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy);
      g.imageSmoothingEnabled = false;
      const sg = g.createLinearGradient(0, 0, 0, m.h * T); sg.addColorStop(0, '#070a1c'); sg.addColorStop(0.7, '#2a1a4a'); sg.addColorStop(1, '#8a3b4a');
      g.fillStyle = sg; g.fillRect(0, 0, m.w * T, m.h * T);
      g.drawImage(worldRef.current!, 0, 0);
      // grid
      g.lineWidth = 1 / z;
      g.strokeStyle = 'rgba(255,255,255,0.07)'; g.beginPath();
      for (let c = 0; c <= m.w; c++) { g.moveTo(c * T, 0); g.lineTo(c * T, m.h * T); }
      for (let rr = 0; rr <= m.h; rr++) { g.moveTo(0, rr * T); g.lineTo(m.w * T, rr * T); }
      g.stroke();
      g.strokeStyle = 'rgba(95,240,255,0.45)'; g.beginPath();
      for (let s = 0; s <= storiesOf(m); s++) { g.moveTo(-6, s * STORY * T); g.lineTo(m.w * T + 6, s * STORY * T); }
      g.stroke();
      const rc = rectRef.current;
      if (rc) { g.fillStyle = 'rgba(255,209,102,0.25)'; g.strokeStyle = '#ffd166'; const x0 = Math.min(rc.c0, rc.c1), y0 = Math.min(rc.r0, rc.r1); g.fillRect(x0 * T, y0 * T, (Math.abs(rc.c1 - rc.c0) + 1) * T, (Math.abs(rc.r1 - rc.r0) + 1) * T); g.strokeRect(x0 * T, y0 * T, (Math.abs(rc.c1 - rc.c0) + 1) * T, (Math.abs(rc.r1 - rc.r0) + 1) * T); }
      const hv = hoverRef.current;
      if (hv && hv.c >= 0 && hv.r >= 0 && hv.c < m.w && hv.r < m.h) { g.strokeStyle = '#ffffff'; g.lineWidth = 2 / z; g.strokeRect(hv.c * T, hv.r * T, T, T); }
      // label lantai (ruang layar)
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.font = `${Math.round(9 * dpr)}px 'Press Start 2P', monospace`; g.textBaseline = 'top';
      for (let s = 0; s < storiesOf(m); s++) {
        const th = themeOf(m, s), y = (oy + (s * STORY + 0.15) * T * z) * dpr, x = (ox + T * z * 0.2) * dpr;
        const label = `${floorLabel(m, s)} - ${th.name}`;
        g.fillStyle = 'rgba(0,0,0,0.65)'; g.fillRect(x - 3 * dpr, y - 2 * dpr, g.measureText(label).width + 6 * dpr, 13 * dpr);
        g.fillStyle = th.accent; g.fillText(label, x, y);
      }
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);
  const viewRef = useRef(view); viewRef.current = view;
  const hoverRef = useRef(hover); hoverRef.current = hover;
  const rectRef = useRef(rect); rectRef.current = rect;

  // ---------- edit ----------
  const setTiles = (cells: { c: number; r: number }[], ch: string, base: OfficeMap): OfficeMap => {
    const rows = base.rows.map((r) => [...r]);
    if (ch === 'P') for (const row of rows) for (let i = 0; i < row.length; i++) if (row[i] === 'P') row[i] = '.';
    for (const { c, r } of cells) if (r >= 0 && r < base.h && c >= 0 && c < base.w) rows[r][c] = ch;
    return { ...base, rows: rows.map((r) => r.join('')) };
  };
  const toTile = (e: { clientX: number; clientY: number }) => {
    const r = canvasRef.current!.getBoundingClientRect(), v = viewRef.current;
    return { c: Math.floor((e.clientX - r.left - v.ox) / v.z / T), r: Math.floor((e.clientY - r.top - v.oy) / v.z / T) };
  };
  const line = (a: { c: number; r: number }, b: { c: number; r: number }) => {
    const out: { c: number; r: number }[] = [];
    const n = Math.max(Math.abs(b.c - a.c), Math.abs(b.r - a.r), 1);
    for (let i = 0; i <= n; i++) out.push({ c: Math.round(a.c + (b.c - a.c) * i / n), r: Math.round(a.r + (b.r - a.r) * i / n) });
    return out;
  };
  const onDown = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    const t = toTile(e), v = viewRef.current;
    const pan = e.button === 1 || tool === 'pan' || spaceDown.current;
    if (pan) { drag.current = { mode: 'pan', sx: e.clientX, sy: e.clientY, ox: v.ox, oy: v.oy, c0: 0, r0: 0, last: null, ch: '' }; return; }
    const erase = e.button === 2;
    const ch = erase ? '.' : sel;
    if (tool === 'rect') { drag.current = { mode: 'rect', sx: 0, sy: 0, ox: 0, oy: 0, c0: t.c, r0: t.r, last: t, ch }; setRect({ c0: t.c, r0: t.r, c1: t.c, r1: t.r }); return; }
    undo.current.push(mapRef.current); if (undo.current.length > 60) undo.current.shift();
    drag.current = { mode: erase ? 'erase' : 'paint', sx: 0, sy: 0, ox: 0, oy: 0, c0: t.c, r0: t.r, last: t, ch };
    const m = setTiles([t], ch, mapRef.current); mapRef.current = m; dirty.current = true;
  };
  const onMove = (e: React.PointerEvent) => {
    const t = toTile(e);
    if (!hover || hover.c !== t.c || hover.r !== t.r) setHover(t);
    const d = drag.current; if (!d) return;
    if (d.mode === 'pan') { setView((v) => ({ ...v, ox: d.ox + e.clientX - d.sx, oy: d.oy + e.clientY - d.sy })); return; }
    if (d.mode === 'rect') { setRect({ c0: d.c0, r0: d.r0, c1: t.c, r1: t.r }); return; }
    if (d.last && (d.last.c !== t.c || d.last.r !== t.r)) {
      const m = setTiles(d.ch === 'P' ? [t] : line(d.last, t), d.ch, mapRef.current); mapRef.current = m; dirty.current = true; d.last = t;
    }
  };
  const onUp = () => {
    const d = drag.current; drag.current = null;
    if (!d) return;
    if (d.mode === 'rect' && rectRef.current) {
      const rc = rectRef.current, cells: { c: number; r: number }[] = [];
      for (let r = Math.min(rc.r0, rc.r1); r <= Math.max(rc.r0, rc.r1); r++) for (let c = Math.min(rc.c0, rc.c1); c <= Math.max(rc.c0, rc.c1); c++) cells.push({ c, r });
      setRect(null);
      commit(setTiles(d.ch === 'P' ? cells.slice(0, 1) : cells, d.ch, mapRef.current));
      return;
    }
    if (d.mode === 'paint' || d.mode === 'erase') { const m = mapRef.current; setMap(m); onChange(m); }
  };
  const onWheel = (e: React.WheelEvent) => {
    const r = canvasRef.current!.getBoundingClientRect();
    const mx = e.clientX - r.left, my = e.clientY - r.top;
    setView((v) => { const z = Math.max(0.4, Math.min(6, v.z * (e.deltaY < 0 ? 1.15 : 1 / 1.15))); return { z, ox: mx - (mx - v.ox) * z / v.z, oy: my - (my - v.oy) * z / v.z }; });
  };
  const zoomBy = (k: number) => { const box = boxRef.current!.getBoundingClientRect(); const mx = box.width / 2, my = box.height / 2; setView((v) => { const z = Math.max(0.4, Math.min(6, v.z * k)); return { z, ox: mx - (mx - v.ox) * z / v.z, oy: my - (my - v.oy) * z / v.z }; }); };
  const doUndo = useCallback(() => { const prev = undo.current.pop(); if (prev) { mapRef.current = prev; dirty.current = true; setMap(prev); onChange(prev); } }, [onChange]);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.code === 'Space') { spaceDown.current = true; e.preventDefault(); }
      if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') { e.preventDefault(); doUndo(); return; }
      if (e.code === 'KeyB') setTool('brush');
      if (e.code === 'KeyR') setTool('rect');
      if (e.code === 'KeyG') setTool('pan');
      if (e.code === 'Equal' || e.code === 'NumpadAdd') zoomBy(1.2);
      if (e.code === 'Minus' || e.code === 'NumpadSubtract') zoomBy(1 / 1.2);
      const dg = /^Digit(\d)$/.exec(e.code);
      if (dg) { const i = (Number(dg[1]) + 9) % 10; if (TILES[i]) setSel(TILES[i].ch); }
    };
    const up = (e: KeyboardEvent) => { if (e.code === 'Space') spaceDown.current = false; };
    window.addEventListener('keydown', down); window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, [doUndo]);

  // ---------- ukuran peta ----------
  const addStory = () => {
    const m = mapRef.current; if (storiesOf(m) >= 12) return;
    const w = m.w, rows: string[] = [];
    for (let i = 0; i < STORY; i++) {
      if (i === STORY - 1) rows.push('#'.repeat(w));
      else { const ch = i === 0 ? '#' : 'G'; rows.push(ch + '.'.repeat(w - 2) + ch); }
    }
    rows[STORY - 2] = rows[STORY - 2].slice(0, 2) + 'S' + rows[STORY - 2].slice(3, w - 3) + 'E' + rows[STORY - 2].slice(w - 2);
    commit({ ...m, h: m.h + STORY, rows: [...rows, ...m.rows], themes: m.themes ? ['', ...m.themes] : undefined }); flash('LANTAI DITAMBAH DI ATAS');
  };
  const removeStory = () => { const m = mapRef.current; if (storiesOf(m) <= 1) return; commit(normalizeMap({ ...m, h: m.h - STORY, rows: m.rows.slice(STORY), themes: m.themes?.slice(1) })); flash('LANTAI TERATAS DIHAPUS'); };
  const widen = (k: number) => {
    const m = mapRef.current, w = m.w + k * 4;
    if (w < 16 || w > 192) return;
    const rows = m.rows.map((row, r) => {
      if (k > 0) { const fill = r % STORY === STORY - 1 ? '#' : '.'; return row.slice(0, m.w - 1) + fill.repeat(4) + row[m.w - 1]; }
      return row.slice(0, m.w - 5) + row[m.w - 1];
    });
    commit(normalizeMap({ ...m, w, rows }));
  };

  const setStoryTheme = (i: number, t: string) => { const m = mapRef.current, n = storiesOf(m); const th = Array.from({ length: n }, (_, k) => m.themes?.[k] ?? ''); th[i] = t; commit({ ...m, themes: th.some(Boolean) ? th : undefined }); };
  const stats = useMemo(() => {
    const n = storiesOf(map), out: { label: string; spawns: number; conns: number; theme: string }[] = [];
    let hasP = false;
    for (let s = 0; s < n; s++) {
      let sp = 0, cn = 0;
      for (let r = s * STORY; r < (s + 1) * STORY; r++) for (const ch of map.rows[r]) { if (ch === 'S' || ch === 'E') { sp++; cn++; } if (ch === 'X') sp++; if (ch === 'P') hasP = true; }
      out.push({ label: floorLabel(map, s), spawns: sp, conns: cn, theme: themeOf(map, s).name });
    }
    return { floors: out, hasP };
  }, [map]);

  const selDef = TILE_BY_CH[sel];
  const hoverInfo = hover && hover.r >= 0 && hover.r < map.h && hover.c >= 0 && hover.c < map.w
    ? `${hover.c},${hover.r}  ${floorLabel(map, Math.floor(hover.r / STORY))}  [${TILE_BY_CH[map.rows[hover.r][hover.c]]?.name ?? '?'}]` : '-';

  const groups: { id: TileDef['group']; label: string }[] = [{ id: 'struktur', label: 'STRUKTUR' }, { id: 'jalur', label: 'JALUR & MUSUH' }, { id: 'perabot', label: 'PERABOT' }, { id: 'dekor', label: 'DEKOR & RUANG' }];

  return (
    <div className="ed-root">
      <header className="ed-top">
        <div className="ed-brand pixel">DESAIN MAP<span>MENARA KANTOR</span></div>
        <input className="ed-name pixel" value={map.name} maxLength={24} aria-label="Nama map" onChange={(e) => commit({ ...mapRef.current, name: e.target.value.toUpperCase() }, false)} />
        <div className="ed-group">
          <span className="ed-lbl">LANTAI {storiesOf(map)}</span>
          <button type="button" className="ed-btn" aria-label="Kurangi lantai" onClick={removeStory}><Minus size={12} /></button>
          <button type="button" className="ed-btn" aria-label="Tambah lantai" onClick={addStory}><Plus size={12} /></button>
        </div>
        <div className="ed-group">
          <span className="ed-lbl">LEBAR {map.w}</span>
          <button type="button" className="ed-btn" aria-label="Persempit" onClick={() => widen(-1)}><Minus size={12} /></button>
          <button type="button" className="ed-btn" aria-label="Perlebar" onClick={() => widen(1)}><Plus size={12} /></button>
        </div>
        <label className="ed-check pixel"><input type="checkbox" checked={map.roof} onChange={(e) => commit({ ...mapRef.current, roof: e.target.checked })} /> ATAP TERBUKA</label>
        <div className="ed-group">
          <button type="button" className={`ed-btn ${tool === 'brush' ? 'is-on' : ''}`} title="Kuas (B)" aria-label="Kuas" onClick={() => setTool('brush')}><Brush size={13} /></button>
          <button type="button" className={`ed-btn ${tool === 'rect' ? 'is-on' : ''}`} title="Kotak (R)" aria-label="Kotak" onClick={() => setTool('rect')}><Square size={13} /></button>
          <button type="button" className={`ed-btn ${tool === 'pan' ? 'is-on' : ''}`} title="Geser (G / tahan SPASI)" aria-label="Geser" onClick={() => setTool('pan')}><Hand size={13} /></button>
          <button type="button" className="ed-btn" title="Undo (Ctrl+Z)" aria-label="Undo" onClick={doUndo}><RotateCcw size={13} /></button>
          <button type="button" className="ed-btn" aria-label="Perkecil" onClick={() => zoomBy(1 / 1.2)}><ZoomOut size={13} /></button>
          <button type="button" className="ed-btn" aria-label="Perbesar" onClick={() => zoomBy(1.2)}><ZoomIn size={13} /></button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={fit}>PAS</button>
        </div>
        <div className="ed-group ed-group--right">
          <button type="button" className="ed-btn ed-btn--txt" onClick={() => { commit(blankMap()); window.setTimeout(fit, 0); }}>BARU</button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={() => { commit(defaultMap()); window.setTimeout(fit, 0); }}>DEFAULT</button>
          <button type="button" className="ed-btn ed-btn--txt" title="Gedung acak dari generator 100 level" onClick={() => { commit(randomTower()); window.setTimeout(fit, 0); }}>ACAK</button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={() => { const m = loadCustomMap(); if (m) { commit(m); window.setTimeout(fit, 0); flash('MAP DIMUAT'); } else flash('BELUM ADA MAP TERSIMPAN'); }}>MUAT</button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={() => { saveCustomMap(mapRef.current); flash('TERSIMPAN!'); }}>SIMPAN</button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={() => { setText(exportMap(mapRef.current)); setModal('export'); }}>EKSPOR</button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={() => { setText(''); setModal('import'); }}>IMPOR</button>
          <button type="button" className="ed-btn ed-btn--play" onClick={() => { const m = normalizeMap(mapRef.current); saveCustomMap(m); onPlay(m); }}>UJI MAIN</button>
          <button type="button" className="ed-btn ed-btn--txt" onClick={onExit}>KELUAR</button>
        </div>
      </header>

      <div className="ed-body">
        <aside className="ed-palette">
          {groups.map((gr) => (
            <div key={gr.id} className="ed-pal-group">
              <div className="ed-pal-head pixel">{gr.label}</div>
              <div className="ed-pal-grid">
                {TILES.filter((t) => t.group === gr.id).map((t) => {
                  const idx = TILES.indexOf(t);
                  return (
                    <button key={t.ch} type="button" className={`ed-tile ${sel === t.ch ? 'is-on' : ''}`} title={t.hint} onClick={() => setSel(t.ch)}>
                      <img src={icons[t.ch]} alt="" width={16} height={32} />
                      <span className="ed-tile__name">{t.name}</span>
                      {idx < 10 && <kbd>{(idx + 1) % 10}</kbd>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </aside>

        <main ref={boxRef} className="ed-canvas-box">
          <canvas ref={canvasRef} className="ed-canvas" style={{ cursor: tool === 'pan' ? 'grab' : 'crosshair' }}
            onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} onPointerLeave={() => setHover(null)}
            onWheel={onWheel} onContextMenu={(e) => e.preventDefault()} />
          {toast && <div className="ed-toast pixel">{toast}</div>}
        </main>

        <aside className="ed-side">
          <div className="ed-card">
            <div className="ed-card__head pixel">TERPILIH</div>
            <div className="ed-sel"><img src={icons[sel]} alt="" width={24} height={48} /><div><b className="pixel">{selDef?.name}</b><p>{selDef?.hint}</p></div></div>
          </div>
          <div className="ed-card">
            <div className="ed-card__head pixel">CEK LANTAI</div>
            {!stats.hasP && <p className="ed-warn">Belum ada POSISI PEMAIN - otomatis di lantai dasar.</p>}
            <ul className="ed-floors">
              {stats.floors.map((f, i) => (
                <li key={i} className={f.spawns ? '' : 'warn'}>
                  <span className="pixel">{f.label}</span>
                  <select className="ed-theme" aria-label={`Tema ${f.label}`} value={map.themes?.[i] ?? ''} onChange={(e) => setStoryTheme(i, e.target.value)}>
                    <option value="">AUTO: {f.theme}</option>
                    {THEME_IDS.map((t) => <option key={t} value={t}>{THEMES[t].name}</option>)}
                  </select>
                  <em>{f.spawns ? `${f.spawns} titik musuh` : 'musuh turun dari plafon'}</em>
                </li>
              ))}
            </ul>
          </div>
          <div className="ed-card ed-tips">
            <div className="ed-card__head pixel">TIPS</div>
            <p>Klik kiri = lukis, klik kanan = hapus, roda = zoom, tengah / SPASI = geser.</p>
            <p>Letakkan <b>PINTU DARURAT</b> / <b>LIFT</b> di ujung kiri &amp; kanan tiap lantai: musuh datang dari sana. Pintu di kolom yang sama (beda lantai) otomatis tersambung.</p>
            <p><b>TANGGA PANJAT</b> harus menembus pelat beton lantai atas.</p>
            <p>Dinding <b>KACA</b> di tepi gedung = musuh bisa dilempar keluar!</p>
          </div>
          <div className="ed-status pixel">{hoverInfo}</div>
        </aside>
      </div>

      {modal !== 'none' && (
        <div className="ed-modal" onPointerDown={(e) => { if (e.target === e.currentTarget) setModal('none'); }}>
          <div className="ed-modal__box">
            <div className="ed-card__head pixel">{modal === 'export' ? 'EKSPOR KODE MAP' : 'IMPOR KODE MAP'}</div>
            <textarea className="ed-text" value={text} readOnly={modal === 'export'} placeholder="Tempel kode map di sini..." onChange={(e) => setText(e.target.value)} />
            <div className="ed-modal__row">
              {modal === 'export'
                ? <button type="button" className="ed-btn ed-btn--txt" onClick={() => { void navigator.clipboard?.writeText(text).then(() => flash('KODE DISALIN')).catch(() => flash('SALIN MANUAL')); }}>SALIN</button>
                : <button type="button" className="ed-btn ed-btn--play" onClick={() => { const m = importMap(text); if (m) { commit(m); setModal('none'); window.setTimeout(fit, 0); flash('MAP DIIMPOR'); } else flash('KODE TIDAK VALID'); }}>MUAT KODE</button>}
              <button type="button" className="ed-btn ed-btn--txt" onClick={() => setModal('none')}>TUTUP</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
