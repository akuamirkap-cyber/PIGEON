// JEMBATAN ARSENAL ASLI KUNGFU DRIFTER -> MENARA KANTOR (side view).
// Modul senjata asli (Katana, SF-Nunchaku + Fire Trail, Yoyo V2, Buster, Boxing, Takamura, Hayabusa, Guan Dao, Leviathan)
// dijalankan APA ADANYA. Objek ini meniru permukaan API `Game` yang mereka pakai, dipetakan ke engine side view.
// Arah bidik selalu 0 / PI (hadap kanan / kiri) — persis tampilan game asli saat petarung menghadap samping.
import type { Game } from '../../v2/games/maxkungfu/game/game';
import type { Pose, Vec } from '../../v2/games/maxkungfu/game/types';
import type { Move } from '../../v2/games/maxkungfu/game/moves';
import { MOVES } from '../../v2/games/maxkungfu/game/moves';
import { solvePose, type StickOpts } from '../../v2/games/maxkungfu/game/stick';
import { Katana } from '../../v2/games/maxkungfu/game/katana';
import { SFNunchaku } from '../../v2/games/maxkungfu/game/sfnunchaku';
import { FireTrail } from '../../v2/games/maxkungfu/game/fireTrail';
import { YoyoV2 } from '../../v2/games/maxkungfu/game/yoyoV2';
import { YOYO_SKIN_KEY, isYoyoSkinId } from '../../v2/games/maxkungfu/game/yoyoSkins';
import { Buster, drawBusterSword, BUSTER_LEN, MAKO } from '../../v2/games/maxkungfu/game/buster';
import { Boxing, drawGlove } from '../../v2/games/maxkungfu/game/boxing';
import { Takamura } from '../../v2/games/maxkungfu/game/takamura';
import { Hayabusa } from '../../v2/games/maxkungfu/game/hayabusa';
import { GuanDao } from '../../v2/games/maxkungfu/game/guandao';
import { Leviathan } from '../../v2/games/maxkungfu/game/leviathan';
import { drawAxe, drawBat, drawShortBlade, AXE_LEN, BAT_LEN, DUAL_LEN } from '../../v2/games/maxkungfu/game/weapons';
import { drawBow, drawQuiver } from '../../v2/games/maxkungfu/game/bow';
import { drawShotgun, drawShells } from '../../v2/games/maxkungfu/game/shotgun';
import { pfontO, type Ctx } from '../maxkungfu/game/pixel';
import { rnd } from '../maxkungfu/game/rng';

/* eslint-disable @typescript-eslint/no-explicit-any */
type Any = any;
const MODULE_WEAPONS = new Set(['takamura', 'hayabusa', 'guandao']);
const BLADE_LEN: Record<string, number> = { katana: 17, axe: AXE_LEN, bat: BAT_LEN, dual: DUAL_LEN, buster: BUSTER_LEN, shotgun: 12 };

export class Bridge {
  e: Any;
  katana = new Katana(); sfNun = new SFNunchaku(); fire = new FireTrail(); yoyo = new YoyoV2(); bu = new Buster(); box = new Boxing();
  tak = new Takamura(); hay = new Hayabusa(); gd = new GuanDao(); lev = new Leviathan();
  sfNunAim = 0; sgSpin = 0; bowVib = 0; bowGlint = 0;
  /** pemain tiruan dengan field yang dibaca modul asli */
  P: Any = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, kx: 0, ky: 0, aim: 0, facing: 1, r: 4, airborne: false, dashT: 0, stunT: 0, holdT: 0, holdPose: 'idle', holdPoseT: 0,
    iframes: 0, moving: false, runT: 0, weapon: 'fist', attackPhase: 'none', buffered: null, landT: 0, sinceDash: 9, squash: 1, focus: 0, fatality: null, focusDash: null, rageDash: null, lean: { x: 1, y: 0 } };
  input = { mouse: { x: 0, y: 0, down: false, rdown: false, mdown: false, pressed: false, rpressed: false, wheel: 0 }, keys: new Set<string>() };
  stats: Any = new Proxy({}, { get: () => 1 });
  level: Any = { n: 1, zone: 0, w: 1, h: 1, tiles: new Uint8Array(1), spawn: { x: 0, y: 0 }, outdoor: false };
  props: Any[] = []; silat = null; botPunch = null; carry = null; grab = null; propsPlay = null; cinematic = false;
  blood = { spray: (x: number, y: number, ang: number, power: number) => this.e.fxBack.blood(x, y, Math.round(3 + power * 2), ang, 90 + power * 30) };
  particles = {
    add: (q: Any) => {
      const k = [0, 1, 2, 3, 5, 7, 9].includes(q.k ?? 0) ? (q.k ?? 0) : q.k === 4 ? 4 : 0;
      (k === 4 ? this.e.fxBack : this.e.fx).add({ ...q, k, vy: (q.vy ?? 0) * (k === 4 ? 0.4 : 1) - (q.vz ?? 0) * 0.5, g: k === 4 ? 520 : (q.g ?? 0), z: undefined, vz: undefined });
    },
    spark: (x: number, y: number, n: number, c: string, dir: number, spread?: number, speed?: number) => this.e.fx.spark(x, y, n, c, dir, spread, speed),
    burst: (x: number, y: number, n: number, c: string, speed: number, life: number, size?: number) => this.e.fx.burst(x, y, n, c, speed, life, size),
    dirBurst: (x: number, y: number, n: number, c: string, dir: number, spread: number, speed: number, life: number, size = 1) => {
      for (let i = 0; i < n; i++) { const a = dir + rnd(-spread, spread), sp = rnd(speed * 0.4, speed); this.e.fx.add({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: rnd(life * 0.5, life), c, s: size, fr: 5, k: 0 }); }
    },
    lines: (x: number, y: number, n: number, c: string, dir: number, speed?: number) => this.e.fx.lines(x, y, n, c, dir, speed),
    ring: (x: number, y: number, r0: number, r1: number, c: string, life: number, w?: number) => this.e.fx.ring(x, y, r0, r1, c, life, w),
    shockwave: (x: number, y: number, r1: number, c: string, life?: number) => this.e.fx.shockwave(x, y, r1, c, life),
    smoke: (x: number, y: number, n: number, c: string, speed?: number, life?: number) => this.e.fx.smoke(x, y, n, c, speed, life),
    impact: (x: number, y: number, size: number, c: string) => this.e.fx.impact(x, y, size, c),
    ember: (x: number, y: number, n: number, c: string) => this.e.fx.ember(x, y, n, c),
    blood: (x: number, y: number, n: number, dir: number, power: number, c?: string) => this.e.fxBack.blood(x, y, n, dir, power, c),
  };

  constructor(engine: Any) {
    this.e = engine;
    try { const id = localStorage.getItem(YOYO_SKIN_KEY); if (isYoyoSkinId(id)) this.yoyo.setSkin(id); } catch { /* */ }
  }
  get G(): Game { return this as unknown as Game; }

  // ================= permukaan API Game yang dibaca modul =================
  get player() { return this.P; }
  private _en: Any[] = [];
  get enemies(): Any[] { return this._en; }
  get time() { return this.e.time; }
  get rawDt() { return this.e.lastDt || 1 / 60; }
  get tempo() { return this.e.tempo; }
  get state() { return this.e.state === 'playing' ? 'playing' : 'paused'; }
  get hitstop() { return this.e.hitstop; }
  set hitstop(v: number) { this.e.hitstop = Math.min(0.12, v); }
  get zoomKick() { return 0; }
  set zoomKick(v: number) { if (v > 0) this.e.zoomPunch(5 / 3 + v * 3); }
  get texts() { return this.e.texts; }
  get sfx() { return this.e.sfx; }
  get bullets() { return this.e.bullets.filter((b: Any) => !b.mine); }
  /** V2: modul membidik ke kursor mouse asli; tanpa mouse = lurus ke depan */
  mouseWorld(): Vec { return this.e.player?.mouseAim ? this.e.mouseWorld() : { x: this.P.x + this.P.facing * 90, y: this.P.y - 9 }; }
  playerStickOpts(pose: Pose, t: number): StickOpts { return this.e.playerOpts(pose, t); }
  damageEnemy(en: Any, dmg: number, structure: number, ang: number, kb: number, o: Any = {}) {
    const m: Move = { id: 'mod', name: '', pose: 'idle', dmg, structure, range: 20, arc: 1, windup: 0, active: 0, recover: 0, kb, knockdown: !!o.knockdown, lunge: 0, hitstop: o.hitstop ?? 0.04, shake: o.shake ?? 0.2, sfx: 'slash', limb: 'blade', hitR: 4, launch: o.launch, bleed: true };
    this.e.hitEnemy(en, m, { x: en.x - Math.sign(Math.cos(ang) || 1) * 3 * en.scale, y: en.y - 9 * en.scale }, Math.cos(ang) >= 0 ? 1 : -1, true);
  }
  meleeHitEnemy(en: Any, mv: Move, a: number, at: Vec) {
    this.e.hitEnemy(en, mv, { x: at.x, y: Math.min(en.y - 3, Math.max(en.y - 14 * en.scale, at.y)) }, Math.cos(a) >= 0 ? 1 : -1, true);
  }
  shockwaveHit(x: number, y: number, r: number, dmg: number, excludeId: number) {
    for (const en of this.enemies) {
      if (en.id === excludeId || en.spawnT > 0 || Math.hypot(en.x - x, (en.y - y) * 1.6) > r) continue;
      this.damageEnemy(en, dmg, 20, Math.atan2(0, en.x - x), 200, { knockdown: true, launch: 40 });
    }
  }
  addAfterimage(src: Any, color?: string) {
    const pp = this.e.currentPlayerPose();
    const o = this.e.playerOpts(src.pose ?? pp.pose, src.poseT ?? pp.t);
    o.x = src.x; o.y = this.P.y; o.facing = src.facing ?? this.P.facing;
    this.e.ghost(o, color ?? '#bfe8ff');
  }
  /** kombo sudah dihitung per hantaman oleh engine */
  addCombo(_n = 1) { /* */ }
  addOfa(n: number) { this.e.addOfa(n); }
  heal(n: number) { this.e.heal(n * 6); }
  flash(_c: string, a: number) { this.e.flash = Math.max(this.e.flash, a * 1.6); }
  say(text: string, c: string, _s?: number, life?: number) { this.e.texts.add(this.P.x, this.P.y - 34, text, c, 1, life ?? 1); }
  shake(t: number) { this.e.shake(t); }
  slow(d: number, k: number) { this.e.slow(d, k); }
  isFree(x: number, y: number, r: number) { return !this.e.solidAt(x - r, y - 9, true) && !this.e.solidAt(x + r, y - 9, true) && !this.e.solidAt(x, y - 3, true); }
  nearestEnemy(x: number, y: number, maxD: number, aim?: number, arc?: number) {
    let best: Any = null, bd = maxD;
    for (const en of this.enemies) {
      if (en.spawnT > 0) continue;
      const d = Math.hypot(en.x - x, en.y - y);
      if (d > bd) continue;
      if (aim !== undefined && arc !== undefined) { const a = Math.atan2(en.y - y, en.x - x); if (Math.abs(Math.atan2(Math.sin(a - aim), Math.cos(a - aim))) > arc) continue; }
      bd = d; best = en;
    }
    return best;
  }
  damageProp() { /* perabot side view ditangani engine */ }
  deflectBullet(b: Any, ang: number) { const sp = Math.hypot(b.vx, b.vy) * 1.3; b.vx = Math.cos(ang) * sp; b.vy = Math.sin(ang) * sp * 0.3; b.mine = true; b.dmg = 16; b.kb = 240; this.e.sfx.ricochet(); }
  splat(x: number, y: number, n: number) { this.e.fxBack.blood(x, y - 4, Math.min(14, n), -Math.PI / 2, 110); }

  // ================= sinkronisasi =================
  /** grid tiruan untuk solidAt(level): digeser satu petak supaya proyektil setinggi kaki tidak menabrak lantai */
  buildLevel() {
    const e = this.e, w = e.W, h = e.H, tiles = new Uint8Array(w * h);
    for (let r = 1; r < h; r++) for (let c = 0; c < w; c++) { const ch = e.tiles[r - 1][c]; tiles[r * w + c] = ch === '#' || ch === 'G' ? 1 : 0; }
    this.level = { n: 1, zone: 0, w, h, tiles, spawn: { x: 0, y: 0 }, outdoor: false };
  }
  syncIn(dt: number) {
    const p = this.e.player, P = this.P;
    P.x = p.x; P.y = p.y; P.z = 0; P.vx = p.vx; P.vy = 0; P.vz = 0; P.kx = p.kx; P.ky = 0;
    P.aim = Number.isFinite(p.aim) ? p.aim : (p.facing > 0 ? 0 : Math.PI); P.facing = p.facing; P.lean = { x: p.facing, y: 0 };
    P.airborne = !p.onGround; P.dashT = p.dashT; P.stunT = p.hurtT > 0 || p.downT > 0 || p.getupT > 0 || p.dead ? 0.1 : 0;
    P.iframes = p.iframes; P.moving = Math.abs(p.vx) > 10; P.runT = p.runT; P.weapon = p.weapon; P.attackPhase = p.phase;
    P.landT = p.land; P.squash = p.squash; P.sinceDash = p.dashT > 0 ? 0 : P.sinceDash + dt;
    P.fatality = this.e.exec || this.e.slam ? {} : null; P.rageDash = this.e.special ? true : null;
    P.holdT = p.holdT;
    for (const en of this.e.enemies) { en.r = 4 * en.scale; en.z = 0; en.stun = en.stun ?? 0; }
    const st = this.e.storyOf(p.y);
    this._en = this.e.enemies.filter((q: Any) => !q.dead && q.state !== 'held' && this.e.storyOf(q.y) === st);
  }
  syncOut() {
    const p = this.e.player, P = this.P;
    if (Math.abs(P.x - p.x) > 0.001) { const dir = Math.sign(P.x - p.x); if (!this.e.solidAt(P.x + dir * 4, p.y - 8, true)) p.x = P.x; }
    p.kx = P.kx; p.iframes = Math.max(p.iframes, P.iframes);
    if (P.holdT > p.holdT + 0.01) { p.holdT = P.holdT; p.holdPose = P.holdPose; }
    if (Math.abs(P.vx) < Math.abs(p.vx) * 0.5) p.vx = P.vx;
  }

  // ================= update per senjata =================
  onEquip(w: string) {
    const p = this.e.player;
    if (w === 'axe') this.lev.reset();
    if (w === 'takamura') { this.tak.reset(); this.katana.sheen = 0.3; }
    if (w === 'hayabusa') this.hay.reset();
    if (w === 'guandao') { this.syncIn(0); this.gd.onEquip(this); }
    if (w === 'nunchaku') { this.sfNun.reset(p.x, p.y - 4); this.fire.reset(); }
    if (w === 'yoyo') this.yoyo.reset(p.x, p.y - 6);
  }
  isModuleWeapon(w: string) { return MODULE_WEAPONS.has(w); }
  /** dipanggil tiap frame setelah input pemain dibaca */
  update(dt: number) {
    const e = this.e, p = e.player, w = p.weapon;
    (this.gd as Any).hintT = 0;
    this.katana.update(dt);
    this.bu.update(dt, e.time);
    this.fire.update(dt);
    this.box.stance = p.boxStance; this.box.update(dt, Math.abs(p.vx) > 10, Math.min(1, Math.abs(p.vx) / 120));
    this.bowVib = Math.max(0, this.bowVib - dt * 3); this.bowGlint = Math.max(0, this.bowGlint - dt);
    this.sgSpin = Math.max(0, this.sgSpin - dt * 9);
    if (e.state !== 'playing' || p.dead) return;
    this.syncIn(dt);
    if (w === 'takamura') this.tak.update(this.G, dt);
    else if (w === 'hayabusa') this.hay.update(this.G, dt);
    else if (w === 'guandao') { this.gd.update(this, dt); }
    else if (w === 'axe') this.lev.update(this.G, dt);
    if (w === 'guandao' || w === 'takamura' || w === 'hayabusa' || w === 'axe') this.syncOut();
    if (w === 'nunchaku') this.updateSFNunchaku(dt);
    if (w === 'yoyo') this.updateYoyo(dt);
    for (const en of e.enemies) if (en.stun > 0) { en.stun = Math.max(0, en.stun - dt); if (!en.dead && en.state === 'idle') { en.vx = 0; } }
  }
  moveMul(): number {
    const w = this.e.player.weapon;
    if (w === 'takamura') return this.tak.moveMul;
    if (w === 'hayabusa') return this.hay.moveMul;
    if (w === 'guandao') return this.gd.moveMul(this.P) ?? 1;
    return 1;
  }
  bodyPose(): { pose: Pose; t: number } | null {
    const p = this.e.player, w = p.weapon;
    if (!p.onGround) return null;
    if (w === 'hayabusa' && this.hay.bodyPose) return { pose: this.hay.bodyPose, t: this.hay.bodyT };
    if (w === 'takamura' && this.tak.bodyPose) return { pose: this.tak.bodyPose, t: this.tak.bodyT };
    if (w === 'guandao') { const q = this.gd.bodyPose(this); if (q) return { pose: q.pose as Pose, t: q.t }; }
    if (w === 'axe' && this.lev.bodyPose) return { pose: this.lev.bodyPose, t: this.lev.bodyT };
    return null;
  }
  /** opsi stickman tambahan sesuai senjata (persis playerStickOpts asli) */
  decorate(o: StickOpts, render = true) {
    const w = this.e.player.weapon;
    if (w === 'takamura' || w === 'hayabusa') {
      const m = w === 'hayabusa' ? this.hay : this.tak;
      o.tka = m.bladeA; o.tkp = w === 'hayabusa' ? this.hay.ext : (this.tak.mode === 'charge' ? this.tak.chargeLevel : this.tak.ext); o.tkh = m.hop;
      if (m.lockAim !== null) { o.aim = m.lockAim; o.look = m.lockAim; o.facing = Math.cos(m.lockAim) >= 0 ? 1 : -1; }
    }
    if (!render) return;
    if (w === 'guandao') { const g = this.gd.grips(this); o.handOverride = g.front; o.bhandOverride = g.back; }
    if (w === 'nunchaku' && this.sfNun.pts.length === 6) { o.handOverride = { x: this.sfNun.pts[0].x, y: this.sfNun.pts[0].y }; if (this.sfNun.attacking) o.mood = 'angry'; }
  }
  // ---- SF NUNCHAKU + FIRE TRAIL (gaya bawaan Kungfu Drifter)
  nunPress(heavy: boolean, aim?: number) {
    const nun = this.sfNun, p = this.e.player;
    if (!nun.attacking) { this.sfNunAim = aim ?? (p.facing > 0 ? 0 : Math.PI); nun.start(heavy); this.e.sfx.swing(nun.cur?.heavy ? 0.7 : 1.1); }
    else if (nun.cur && nun.t / nun.cur.dur > 0.3) nun.buffered = true;
  }
  private updateSFNunchaku(dt: number) {
    const e = this.e, p = e.player, nun = this.sfNun;
    if (p.hurtT > 0 || p.downT > 0) { nun.cur = null; nun.buffered = false; nun.idx = 0; }
    const aimNow = Number.isFinite(p.aim) ? p.aim : (p.facing > 0 ? 0 : Math.PI);
    if (!nun.attacking) this.sfNunAim = aimNow;
    const facing = nun.attacking ? this.sfNunAim : aimNow;
    if (nun.attacking) p.facing = Math.cos(facing) >= 0 ? 1 : -1;
    const ev = nun.step(dt * e.tempo * e.gates.atkMul);
    if (nun.cur) p.vx += Math.cos(facing) * nun.lungeK() * nun.cur.lunge * 0.6;
    nun.update(dt, p.x, p.y - 4, facing, e.time, p.dashT > 0 ? 'dash' : 'idle', 1);
    const tip = nun.pts[5];
    this.fire.emit(tip.x, tip.y, nun.endSpeed, dt, nun.attacking ? 1.3 : 0.7);
    const atk = nun.cur;
    if (ev === 'hit' && atk) {
      const t = this.nearestEnemy(p.x, p.y, atk.range + 6, facing, Math.max(0.9, atk.arc / 2));
      if (t) {
        t.nunCd = e.time + 0.22;
        this.damageEnemy(t, atk.dmg * e.gates.dmgMul * 0.9, atk.posture, facing, atk.kb, { knockdown: !!atk.heavy, hitstop: atk.name === 'WHIP CRACK' ? 0.05 : 0.025, shake: atk.heavy ? 0.25 : 0.1, launch: atk.heavy ? 70 : 0 });
        this.fire.burst(t.x, t.y - 7, facing, atk.heavy ? 1 : 0.5); e.sfx.nunchakuHit(!!atk.heavy);
      }
      if (atk.name === 'WHIP CRACK') { e.shake(0.15); e.fx.ring(tip.x, tip.y, 2, 9, '#ffffff', 0.15, 1); }
    }
    if (atk && nun.endSpeed > 150) {
      const ha = Math.atan2(tip.y - nun.prevEnd.y, tip.x - nun.prevEnd.x);
      for (const en of this.enemies) {
        if (en.spawnT > 0 || (en.nunCd ?? 0) > e.time) continue;
        const d = Math.min(nun.stickDist(en.x, en.y - 4), nun.stickDist(en.x, en.y - 8 * en.scale), nun.stickDist(en.x, en.y - 12 * en.scale));
        if (d < en.r + 4.5) {
          en.nunCd = e.time + 0.18;
          this.damageEnemy(en, atk.dmg * e.gates.dmgMul * 0.7, atk.posture, ha, atk.kb, { hitstop: 0.02, shake: 0.08 });
          this.fire.burst(en.x, en.y - 7, ha, 0.45); e.sfx.nunchakuHit(false);
        }
      }
    }
    if (nun.endSpeed > 260 && Math.random() < 0.25) e.sfx.chainRattle();
  }
  // ---- YOYO V2 (lintasan freestyle asli)
  private updateYoyo(dt: number) {
    const e = this.e, p = e.player;
    const m: Move | null = p.move && p.phase !== 'none' ? p.move : null;
    const ym = m?.yoyo ? m : null;
    const pose: Pose = m ? m.pose : p.dashT > 0 ? 'dash' : !p.onGround ? 'jump' : Math.abs(p.vx) > 10 ? 'run' : 'y2_idle';
    const prog = m ? e.poseT() : 0;
    const sk = solvePose(e.playerOpts(pose, prog));
    const hand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y };
    const aim = Number.isFinite(p.aim) ? p.aim : (p.facing > 0 ? 0 : Math.PI);
    this.yoyo.update(dt, hand, { x: p.x, y: p.y - 6 }, aim, ym?.id ?? null, p.phase, prog, Math.min(ym?.range ?? 78, 70));
    if (ym && p.phase === 'active' && Math.random() < 0.18) { const tp = this.yoyo.position, sk2 = this.yoyo.skin; e.fx.add({ x: tp.x, y: tp.y, vx: rnd(-20, 20), vy: rnd(-30, 15), life: 0.18, c: Math.random() < 0.5 ? sk2.spark : sk2.trailLight, s: 1, k: 0 }); }
  }

  // ================= hitbox senjata (geometri bladeSeg asli, ruang layar) =================
  bladeSegs(m: Move, poseT: number, a0: number, a1: number, second: boolean): { base: Vec; tip: Vec }[] {
    const e = this.e, p = e.player;
    const sk = solvePose(e.playerOpts(m.pose, poseT));
    const hand = second ? { x: p.x + sk.bhand.x, y: p.y + sk.bhand.y } : { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y };
    const len = m.buster ? BUSTER_LEN : m.bat ? BAT_LEN : m.axe ? AXE_LEN : m.dual ? DUAL_LEN : p.weapon === 'shotgun' ? 12 : this.katana.len;
    const lift = (m.slash?.lift ?? 0) * 10, out: { base: Vec; tip: Vec }[] = [];
    const n = Math.min(6, Math.max(1, Math.ceil(Math.abs(a1 - a0) / 0.25)));
    for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * (i / n); out.push({ base: hand, tip: { x: hand.x + Math.cos(a) * len * 1.12, y: hand.y + Math.sin(a) * len * 0.6 * 1.12 - lift } }); }
    return out;
  }
  yoyoSeg(m: Move): { base: Vec; tip: Vec } {
    const orbit = m.id === 'y_orbit' || m.id === 'y_storm' || m.id === 'y_flare';
    const pt = { ...this.yoyo.position };
    return { base: orbit ? { ...this.yoyo.hand } : pt, tip: pt };
  }

  // ================= gambar (port bagian senjata drawPlayer asli) =================
  drawBack(ctx: Ctx) {
    this.katana.drawArcs(ctx);
    this.bu.drawSlashes(ctx);
    if (this.e.player.weapon === 'guandao') this.gd.drawFx(this, ctx);
  }
  drawWeapon(ctx: Ctx, opts: StickOpts, pose: Pose, t: number) {
    const e = this.e, p = e.player, w = p.weapon;
    if (p.dead || e.exec || e.special) return;
    const sk = solvePose(opts);
    const H = (v: Vec) => ({ x: p.x + v.x, y: p.y + v.y });
    const fh = H(sk.fhand), bh = H(sk.bhand);
    const aim = p.facing > 0 ? 0 : Math.PI, f = p.facing;
    const m: Move | null = p.move && p.phase !== 'none' ? p.move : null;
    const pt = e.poseT();
    const lift = m?.slash?.lift ?? 0;
    const glowing = !!m && pt > 0.25 && pt < 0.65;
    switch (w) {
      case 'katana': {
        const hip = H(sk.hip), sheathed = pose === 'k_sheathe' && t > 0.6;
        this.katana.drawScabbard(ctx, hip, f);
        const b = this.katana.blade(fh, m ? p.bladeA : aim, lift);
        this.katana.drawBlade(ctx, b.base, b.tip, sheathed);
        break;
      }
      case 'axe': if (this.lev.held) drawAxe(ctx, fh, m ? p.bladeA : aim + Math.PI + 0.9 * f, lift); this.lev.draw(ctx, this.G); break;
      case 'dual': drawShortBlade(ctx, fh, m ? p.bladeA : aim, lift); drawShortBlade(ctx, bh, m ? p.bladeB : aim + Math.PI * 0.85, lift); break;
      case 'bat': {
        let ang = m ? p.bladeA : aim + Math.PI + 0.9 * f;
        if (!m && p.batTwirl > 0) ang += (1 - p.batTwirl / 0.6) * Math.PI * 4 * f;
        drawBat(ctx, fh, ang, lift, glowing ? '#ffd27f' : null);
        break;
      }
      case 'buster': {
        let ang: number;
        if (m) ang = p.bladeA;
        else if (p.buCharging) ang = aim - f * (Math.PI * 0.5 + 0.9 * p.buCharge);
        else if (Math.abs(p.vx) > 70) ang = aim + f * (Math.PI - 0.55);
        else ang = p.busterRest > 0 ? aim - f * (Math.PI - 0.6) : aim + f * 0.5;
        ang += this.bu.flourishSpin() * f;
        drawBusterSword(ctx, fh, ang, lift, glowing ? this.bu.trailColor() : p.buCharging && p.buCharge >= 1 ? MAKO : this.bu.momentum >= 3 ? MAKO : null, p.buCharging ? p.buCharge : 0, e.time);
        break;
      }
      case 'shotgun': {
        let hand = fh; let ang = aim + this.sgSpin * Math.PI * 2 * f - p.recoil * 0.45 * f;
        if (m) { hand = { x: fh.x + Math.cos(p.bladeA) * 10, y: fh.y + Math.sin(p.bladeA) * 6 }; ang = p.bladeA + Math.PI; }
        else ang += p.aimRel * f;
        drawShotgun(ctx, hand, ang, f, m ? 0 : p.recoil, glowing ? '#ffd27f' : null, p.recoil > 0.7 ? 1 : 0);
        if (e.state === 'playing') drawShells(ctx, p.x, p.y + 6, p.ammo.shotgun ?? 0);
        break;
      }
      case 'bow': {
        drawQuiver(ctx, H(sk.neck), H(sk.hip), f);
        const aimA = aim + p.aimRel * f;
        drawBow(ctx, fh, bh, aimA, p.bowDraw, this.bowVib, e.time, this.bowVib <= 0.05, this.bowGlint, 0);
        if (p.bowDraw > 0.05 && e.state === 'playing') {
          const wd = 16, bx = Math.round(p.x - wd / 2), by = Math.round(p.y + 5);
          ctx.fillStyle = '#000'; ctx.fillRect(bx - 1, by - 1, wd + 2, 4);
          const full = p.bowDraw >= 1;
          ctx.fillStyle = full ? (Math.floor(e.time * 12) % 2 ? '#ffffff' : '#ffd27f') : '#c98a3a'; ctx.fillRect(bx, by, Math.round(wd * p.bowDraw), 2);
          if (full) pfontO(ctx, 'FULL', p.x, p.y - 34, '#fff3c4', '#000', 1, 'center');
        }
        break;
      }
      case 'yoyo': this.yoyo.draw(ctx, !!m && !!m.yoyo, fh); break;
      case 'nunchaku': this.fire.drawSmoke(ctx); this.fire.draw(ctx); this.sfNun.draw(ctx, '#ffb04a', false); break;
      case 'takamura': this.tak.draw(ctx, this.G, sk); break;
      case 'hayabusa': this.hay.draw(ctx, this.G, sk); break;
      case 'guandao': this.gd.draw(this, ctx); break;
      case 'boxing': {
        const d = this.box.def;
        if (m && p.phase === 'active') {
          const pw = m.finisher ? 1 : 0.5;
          if (m.limb !== 'bhand') this.box.trail(fh.x, fh.y, aim, true, pw);
          if (m.limb !== 'fhand') this.box.trail(bh.x, bh.y, aim, false, pw);
          if (Math.random() < 0.5) { const side = Math.random() < 0.5 ? 1 : -1; this.box.arc(p.x + Math.cos(aim) * 7, p.y - 7, 8 + pw * 4, aim + side * 1.1, aim - side * 0.5, d.accent, 0.14); }
        }
        this.box.drawGhosts(ctx); this.box.drawArcs(ctx);
        const puls = 1 + this.box.pulse * 0.22;
        drawGlove(ctx, bh.x, bh.y, aim, puls, d, p.flash > 0);
        drawGlove(ctx, fh.x, fh.y, aim, puls, d, p.flash > 0);
        break;
      }
      default: break;
    }
  }
}
export { MOVES, BLADE_LEN };
