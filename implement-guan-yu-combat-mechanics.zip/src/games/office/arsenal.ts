// ARSENAL KUNGFU DRIFTER untuk MENARA KANTOR (side view).
// Senjata dengan tabel jurus asli (MOVES: kungfu, nunchaku, katana, kapak, bat, pedang kembar, yoyo) dipakai apa adanya;
// Takamura, Hayabusa, Guan Dao, Buster & Tinju diberi set jurus side view memakai pose asli mereka.
// Semua gambar senjata digambar ulang TANPA foreshortening 3/4 supaya ayunan vertikal tampak utuh dari samping.
import { MOVES, type Move } from '../../v2/games/maxkungfu/game/moves';
import type { Pose, Vec, WeaponKind } from '../../v2/games/maxkungfu/game/types';
import { drawGlove, BOX_STANCES, type BoxStance } from '../../v2/games/maxkungfu/game/boxing';
import { drawYoyoSprite } from '../../v2/games/maxkungfu/game/yoyoV2';
import { YOYO_SKINS, YOYO_SKIN_KEY, isYoyoSkinId, type YoyoSkin } from '../../v2/games/maxkungfu/game/yoyoSkins';
import { drawShotgun } from '../../v2/games/maxkungfu/game/shotgun';
import { MAKO } from '../../v2/games/maxkungfu/game/buster';
import { pcircle, pline, type Ctx } from '../maxkungfu/game/pixel';

export type WKind = 'fist' | 'blade' | 'gun' | 'bow' | 'yoyo' | 'nunchaku' | 'glove';
export interface GunSpec { auto: boolean; cd: number; dmg: number; kb: number; mag: number; reload: number; spread: number; speed: number; pellets: number; perShell?: boolean }
export interface WeaponDef {
  id: WeaponKind; name: string; code: string; key: string; color: string; kind: WKind; idle: Pose; twoHand: boolean;
  /** panjang senjata (px dunia) dari genggaman ke ujung */
  len: number;
  /** sudut istirahat relatif arah hadap (negatif = ke atas) */
  rest: number;
  trail: string;
  /** nama jurus (L, LL, H, RUN, DASH, AIR, DOWNAIR, UPH, DOWNH, DOWNL) -> kunci di tabel */
  get: (name: string) => Move | undefined;
  gun?: GunSpec;
}

const mk = (o: Partial<Move> & { id: string; name: string; pose: Pose }): Move => ({
  dmg: 5, structure: 20, range: 26, arc: 1.2, windup: 0.08, active: 0.12, recover: 0.2, kb: 160, knockdown: false, lunge: 60,
  hitstop: 0.05, shake: 0.3, sfx: 'slash', limb: 'blade', hitR: 5, ...o,
});
const TAU = Math.PI * 2;

// ---------------------------------------------------------------- TAKAMURA (pedang tongkat iaijutsu)
const TK: Record<string, Move> = {
  L: mk({ id: 'tk_cut1', name: 'KIRIOROSHI', pose: 't_slash', dmg: 6, range: 28, windup: 0.06, active: 0.1, recover: 0.14, kb: 150, lunge: 90, bleed: true, katana: true, slash: { from: -1.5, to: 0.8, r: 22 } }),
  LL: mk({ id: 'tk_cut2', name: 'KIRIAGE', pose: 't_slash', dmg: 6, range: 28, windup: 0.06, active: 0.1, recover: 0.14, kb: 160, lunge: 90, bleed: true, katana: true, slash: { from: 0.9, to: -1.3, r: 22 } }),
  LLL: mk({ id: 'tk_iai', name: 'IAI: ISSEN', pose: 't_iai', dmg: 13, structure: 60, range: 34, windup: 0.12, active: 0.22, recover: 0.32, kb: 260, knockdown: true, lunge: 0, travel: 430, hitstop: 0.09, shake: 0.6, bleed: true, katana: true, finisher: true, showName: true, slash: { from: -0.3, to: 0.25, r: 24 } }),
  H: mk({ id: 'tk_silent', name: 'IAI: SENYAP', pose: 't_iai', dmg: 0, structure: 0, range: 30, windup: 0.18, active: 0.26, recover: 0.5, kb: 0, lunge: 0, travel: 520, hitstop: 0, shake: 0.2, katana: true, showName: true, slash: { from: -0.2, to: 0.2, r: 24 } }),
  RUN: mk({ id: 'tk_iai', name: 'IAI: ISSEN', pose: 't_iai', dmg: 13, structure: 60, range: 34, windup: 0.08, active: 0.22, recover: 0.3, kb: 260, knockdown: true, lunge: 0, travel: 460, hitstop: 0.09, shake: 0.6, bleed: true, katana: true, finisher: true, showName: true, slash: { from: -0.3, to: 0.25, r: 24 } }),
  UPH: mk({ id: 'tk_rise', name: 'TSUBAME GAESHI', pose: 't_slash', dmg: 8, structure: 30, windup: 0.08, active: 0.12, recover: 0.24, kb: 120, launch: 190, bleed: true, katana: true, showName: true, slash: { from: 1.2, to: -2.2, r: 22 } }),
  DOWNH: mk({ id: 'tk_low', name: 'ASHI BARAI', pose: 't_slash', dmg: 7, windup: 0.08, active: 0.12, recover: 0.22, kb: 160, knockdown: true, bleed: true, katana: true, slash: { from: 0.3, to: 1.4, r: 22 } }),
  AIR: mk({ id: 'tk_air', name: 'OTOSHI', pose: 't_slash', dmg: 8, windup: 0.04, active: 0.16, recover: 0.16, kb: 220, knockdown: true, air: true, bleed: true, katana: true, slash: { from: -1.9, to: 1.3, r: 22 } }),
};
// ---------------------------------------------------------------- HAYABUSA (pedang naga ninja)
const HY: Record<string, Move> = {
  L: mk({ id: 'hy_s1', name: 'RYU: ICHI', pose: 'h_slash', dmg: 5, windup: 0.05, active: 0.09, recover: 0.1, kb: 120, lunge: 80, bleed: true, katana: true, slash: { from: -1.2, to: 0.9, r: 21 } }),
  LL: mk({ id: 'hy_s2', name: 'RYU: NI', pose: 'h_slash', dmg: 5, windup: 0.05, active: 0.09, recover: 0.1, kb: 130, lunge: 80, bleed: true, katana: true, slash: { from: 0.9, to: -1.3, r: 21 } }),
  LLL: mk({ id: 'hy_s3', name: 'RYUKEN', pose: 'h_blade', dmg: 9, structure: 40, windup: 0.1, active: 0.13, recover: 0.26, kb: 340, knockdown: true, hitstop: 0.09, shake: 0.6, bleed: true, katana: true, finisher: true, showName: true, slash: { from: -2.6, to: 1.1, r: 23 } }),
  H: mk({ id: 'hy_spin', name: 'HISHOU KAZE', pose: 'h_spin', dmg: 3.5, structure: 14, range: 28, windup: 0.06, active: 0.48, recover: 0.2, kb: 200, rehit: 0.14, bleed: true, katana: true, showName: true, slash: { from: 0, to: TAU, r: 22 } }),
  LH: mk({ id: 'hy_tsuki', name: 'TSUKI', pose: 'h_blade', dmg: 8, structure: 36, range: 32, windup: 0.1, active: 0.12, recover: 0.26, kb: 380, knockdown: true, lunge: 220, bleed: true, katana: true, showName: true, slash: { from: 0, to: 0, r: 26 } }),
  UPH: mk({ id: 'hy_izuna', name: 'IZUNA DROP', pose: 'h_izuna', dmg: 0, windup: 0.06, active: 0.1, recover: 0.1, kb: 0, katana: true, showName: true, slash: { from: 1.2, to: -2.0, r: 21 } }),
  RUN: mk({ id: 'hy_hien', name: 'HIEN', pose: 'h_slash', dmg: 9, structure: 40, windup: 0.06, active: 0.24, recover: 0.26, kb: 380, knockdown: true, lunge: 0, travel: 380, bleed: true, katana: true, finisher: true, showName: true, slash: { from: -1.0, to: 0.8, r: 22 } }),
  DOWNH: mk({ id: 'hy_low', name: 'KAZE BARAI', pose: 'h_spin', dmg: 6, windup: 0.08, active: 0.14, recover: 0.22, kb: 180, knockdown: true, bleed: true, katana: true, slash: { from: 0.3, to: 1.6, r: 22 } }),
  AIR: mk({ id: 'hy_air', name: 'SORA OTOSHI', pose: 'h_blade', dmg: 7, windup: 0.04, active: 0.18, recover: 0.16, kb: 240, knockdown: true, air: true, bleed: true, katana: true, slash: { from: -1.7, to: 1.4, r: 22 } }),
};
// ---------------------------------------------------------------- GUAN DAO (tombak bulan sabit)
const GD: Record<string, Move> = {
  L: mk({ id: 'gd_sweep', name: 'SAPUAN NAGA', pose: 'a_swing1', sfx: 'axe', dmg: 7, structure: 30, range: 40, windup: 0.12, active: 0.14, recover: 0.24, kb: 300, lunge: 60, hitR: 6, bleed: true, axe: true, slash: { from: -1.5, to: 1.0, r: 40 } }),
  LL: mk({ id: 'gd_rev', name: 'BALIKAN BULAN', pose: 'a_swing2', sfx: 'axe', dmg: 7, structure: 30, range: 40, windup: 0.1, active: 0.14, recover: 0.24, kb: 320, lunge: 60, hitR: 6, bleed: true, axe: true, slash: { from: 1.1, to: -1.6, r: 40 } }),
  LLL: mk({ id: 'gd_taishan', name: 'TAISHAN', pose: 'a_overhead', sfx: 'axe', dmg: 13, structure: 70, range: 42, windup: 0.2, active: 0.14, recover: 0.36, kb: 360, knockdown: true, lunge: 70, hitstop: 0.12, shake: 0.9, hitR: 7, bleed: true, axe: true, finisher: true, showName: true, slash: { from: -2.9, to: 0.7, r: 42 } }),
  H: mk({ id: 'gd_whirl', name: 'PUSARAN NAGA', pose: 'a_spin', sfx: 'axe', dmg: 4.5, structure: 20, range: 40, windup: 0.12, active: 0.5, recover: 0.3, kb: 260, rehit: 0.16, hitR: 6, bleed: true, axe: true, showName: true, slash: { from: 0, to: TAU, r: 40 } }),
  LH: mk({ id: 'gd_thrust', name: 'TUSUKAN', pose: 'a_bunt', sfx: 'axe', dmg: 9, structure: 40, range: 46, windup: 0.14, active: 0.14, recover: 0.3, kb: 420, knockdown: true, lunge: 200, hitR: 5, bleed: true, axe: true, showName: true, slash: { from: 0, to: 0, r: 46 } }),
  UPH: mk({ id: 'gd_moon', name: 'BULAN SABIT', pose: 'a_leap', sfx: 'axe', dmg: 8, structure: 40, range: 40, windup: 0.12, active: 0.16, recover: 0.3, kb: 140, launch: 220, hitR: 6, bleed: true, axe: true, showName: true, slash: { from: 1.3, to: -2.3, r: 40 } }),
  DOWNH: mk({ id: 'gd_low', name: 'SAPU KAKI', pose: 'a_golf', sfx: 'axe', dmg: 7, range: 40, windup: 0.12, active: 0.14, recover: 0.26, kb: 220, knockdown: true, hitR: 6, axe: true, slash: { from: 0.5, to: 1.5, r: 40 } }),
  RUN: mk({ id: 'gd_charge', name: 'SERBUAN KAVALERI', pose: 'a_homerun', sfx: 'axe', dmg: 11, structure: 50, range: 40, windup: 0.1, active: 0.26, recover: 0.32, kb: 480, knockdown: true, lunge: 0, travel: 300, hitR: 6, bleed: true, axe: true, finisher: true, showName: true, slash: { from: -0.8, to: 0.6, r: 40 } }),
  AIR: mk({ id: 'gd_air', name: 'BULAN JATUH', pose: 'a_overhead', sfx: 'axe', dmg: 10, range: 40, windup: 0.06, active: 0.18, recover: 0.2, kb: 300, knockdown: true, air: true, hitR: 6, axe: true, slash: { from: -2.6, to: 1.2, r: 40 } }),
};
// ---------------------------------------------------------------- BUSTER SWORD
const BU: Record<string, Move> = {
  L: mk({ id: 'bu_x1', name: 'CROSS SLASH', pose: 'a_swing1', sfx: 'axe', dmg: 9, structure: 40, range: 30, windup: 0.14, active: 0.14, recover: 0.3, kb: 380, lunge: 70, hitR: 7, bleed: true, buster: true, slash: { from: -2.0, to: 1.0, r: 28 } }),
  LL: mk({ id: 'bu_x2', name: 'CROSS SLASH II', pose: 'a_swing2', sfx: 'axe', dmg: 9, structure: 40, range: 30, windup: 0.12, active: 0.14, recover: 0.3, kb: 400, lunge: 70, hitR: 7, bleed: true, buster: true, slash: { from: 1.0, to: -1.9, r: 28 } }),
  LLL: mk({ id: 'bu_braver', name: 'BRAVER', pose: 'a_overhead', sfx: 'axe', dmg: 16, structure: 90, range: 32, windup: 0.22, active: 0.14, recover: 0.42, kb: 420, knockdown: true, lunge: 90, hitstop: 0.14, shake: 1, hitR: 8, bleed: true, buster: true, finisher: true, showName: true, slash: { from: -3.0, to: 1.1, r: 30 } }),
  H: mk({ id: 'bu_beam', name: 'BLADE BEAM', pose: 'a_swing1', sfx: 'axe', dmg: 8, structure: 30, range: 30, windup: 0.2, active: 0.14, recover: 0.36, kb: 300, hitR: 7, buster: true, showName: true, slash: { from: -1.8, to: 0.8, r: 28 } }),
  RUN: mk({ id: 'bu_climb', name: 'CLIMHAZZARD', pose: 'a_homerun', sfx: 'axe', dmg: 12, structure: 60, range: 30, windup: 0.1, active: 0.2, recover: 0.36, kb: 160, launch: 260, travel: 220, hitR: 7, bleed: true, buster: true, finisher: true, showName: true, slash: { from: 1.3, to: -2.4, r: 28 } }),
  UPH: mk({ id: 'bu_rise', name: 'CLIMHAZZARD', pose: 'a_homerun', sfx: 'axe', dmg: 10, structure: 50, range: 30, windup: 0.12, active: 0.16, recover: 0.34, kb: 140, launch: 250, hitR: 7, bleed: true, buster: true, showName: true, slash: { from: 1.3, to: -2.4, r: 28 } }),
  DOWNH: mk({ id: 'bu_low', name: 'GROUND SLASH', pose: 'a_golf', sfx: 'axe', dmg: 9, range: 30, windup: 0.14, active: 0.14, recover: 0.3, kb: 260, knockdown: true, hitR: 7, buster: true, slash: { from: 0.6, to: 1.6, r: 28 } }),
  AIR: mk({ id: 'bu_meteor', name: 'METEORAIN', pose: 'a_overhead', sfx: 'axe', dmg: 12, range: 30, windup: 0.06, active: 0.2, recover: 0.24, kb: 340, knockdown: true, air: true, hitR: 8, buster: true, showName: true, slash: { from: -2.8, to: 1.3, r: 28 } }),
};
// ---------------------------------------------------------------- TINJU (boxing: Ali / Tyson / Ippo)
const BXm = (o: Partial<Move> & { id: string; name: string; pose: Pose }) => mk({ sfx: 'punch', limb: 'fhand', range: 17, hitR: 4.5, windup: 0.05, active: 0.08, recover: 0.1, kb: 110, lunge: 70, ...o });
const BX: Record<string, Move> = {
  L: BXm({ id: 'bx_jab', name: 'JAB', pose: 'bx_jab', dmg: 2.5 }),
  LL: BXm({ id: 'bx_cross', name: 'STRAIGHT', pose: 'bx_cross', dmg: 3, limb: 'bhand', kb: 140 }),
  LLL: BXm({ id: 'bx_lhook', name: 'LEFT HOOK', pose: 'bx_lhook', dmg: 4, kb: 170, sfx: 'kick' }),
  LLLL: BXm({ id: 'bx_upper', name: 'UPPERCUT', pose: 'bx_upper', dmg: 6, limb: 'bhand', kb: 120, launch: 170, sfx: 'heavy', finisher: true, showName: true }),
  LLLLL: BXm({ id: 'bx_smash', name: 'SMASH', pose: 'bx_smash', dmg: 9, structure: 60, kb: 420, knockdown: true, sfx: 'heavy', windup: 0.1, recover: 0.3, finisher: true, showName: true }),
  H: BXm({ id: 'bx_body', name: 'LIVER BLOW', pose: 'bx_body', dmg: 4, structure: 45, kb: 160, sfx: 'kick', showName: true }),
  LH: BXm({ id: 'bx_rhook', name: 'RIGHT HOOK', pose: 'bx_rhook', dmg: 5, limb: 'bhand', kb: 220, sfx: 'kick' }),
  HL: BXm({ id: 'bx_shovel', name: 'SHOVEL HOOK', pose: 'bx_shovel', dmg: 5, kb: 120, launch: 90, sfx: 'kick' }),
  HH: BXm({ id: 'bx_heart', name: 'HEART BREAK SHOT', pose: 'bx_heart', dmg: 9, structure: 140, kb: 160, sfx: 'heavy', windup: 0.12, recover: 0.3, finisher: true, showName: true }),
  RUN: BXm({ id: 'bx_gazelle', name: 'GAZELLE PUNCH', pose: 'bx_gazelle', dmg: 8, structure: 50, kb: 180, launch: 190, travel: 260, jump: 12, sfx: 'heavy', active: 0.2, recover: 0.3, finisher: true, showName: true }),
  DASH: BXm({ id: 'bx_dempsey', name: 'DEMPSEY ROLL', pose: 'bx_dempsey', dmg: 3, structure: 20, kb: 160, travel: 200, rehit: 0.1, active: 0.6, recover: 0.26, sfx: 'kick', showName: true, limb: 'both' }),
  UPH: BXm({ id: 'bx_upper', name: 'UPPERCUT', pose: 'bx_upper', dmg: 6, limb: 'bhand', kb: 120, launch: 190, sfx: 'heavy', showName: true }),
  DOWNH: BXm({ id: 'bx_shovel', name: 'SHOVEL HOOK', pose: 'bx_shovel', dmg: 5, kb: 120, launch: 90, sfx: 'kick' }),
  AIR: BXm({ id: 'bx_over', name: 'OVERHAND', pose: 'bx_over', dmg: 6, kb: 260, knockdown: true, air: true, sfx: 'heavy' }),
};

/** jurus dari tabel asli (MOVES) dengan alias untuk input side view */
const fromMoves = (prefix: string, alias: Record<string, string>) => (name: string): Move | undefined => {
  const k = alias[name] ?? prefix + name;
  return MOVES[k];
};
const fromTable = (t: Record<string, Move>) => (name: string): Move | undefined => t[name];

const PISTOL: GunSpec = { auto: false, cd: 0.14, dmg: 7, kb: 150, mag: 12, reload: 0.9, spread: 0.025, speed: 560, pellets: 1 };
const RIFLE: GunSpec = { auto: true, cd: 0.09, dmg: 4.5, kb: 110, mag: 30, reload: 1.3, spread: 0.05, speed: 640, pellets: 1 };
const SHOTGUN: GunSpec = { auto: false, cd: 0.62, dmg: 3.8, kb: 240, mag: 6, reload: 0.32, spread: 0.2, speed: 520, pellets: 7, perShell: true };
const BOW: GunSpec = { auto: false, cd: 0.25, dmg: 6, kb: 160, mag: 1, reload: 0, spread: 0, speed: 300, pellets: 1 };

export const WEAPONS: Record<WeaponKind, WeaponDef> = {
  fist: { id: 'fist', name: 'KUNGFU', code: 'Digit1', key: '1', color: '#ffffff', kind: 'fist', idle: 'idle', twoHand: false, len: 0, rest: 0, trail: '#ffffff',
    get: fromMoves('', { DASH: 'DASH', AIR: 'AIR', DOWNAIR: 'HLL', RUN: 'RUNPUNCH', RUNH: 'TKD', UPH: 'LLLH', DOWNH: 'LLH', DOWNL: 'HL' }) },
  pistol: { id: 'pistol', name: 'PISTOL', code: 'Digit2', key: '2', color: '#ffd166', kind: 'gun', idle: 'idle', twoHand: false, len: 8, rest: 0, trail: '#ffd166', gun: PISTOL, get: fromMoves('', { H: 'TKD', AIR: 'AIR', DOWNH: 'LLH', UPH: 'LLLH' }) },
  rifle: { id: 'rifle', name: 'SENAPAN', code: 'Digit3', key: '3', color: '#ffb347', kind: 'gun', idle: 'idle', twoHand: true, len: 12, rest: 0, trail: '#ffb347', gun: RIFLE, get: fromMoves('', { H: 'TKD', AIR: 'AIR', DOWNH: 'LLH', UPH: 'LLLH' }) },
  nunchaku: { id: 'nunchaku', name: 'NUNCHAKU', code: 'Digit4', key: '4', color: '#ff8a3d', kind: 'nunchaku', idle: 'n_idle', twoHand: false, len: 13, rest: 0.9, trail: '#ff8a3d',
    get: fromMoves('N', { UPH: 'NLH', DOWNH: 'NHL', AIR: 'NDASH', RUNH: 'NRUN' }) },
  katana: { id: 'katana', name: 'KATANA', code: 'Digit5', key: '5', color: '#e8f6ff', kind: 'blade', idle: 'k_idle', twoHand: false, len: 18, rest: -0.7, trail: '#e8f6ff',
    get: fromMoves('K', { UPH: 'KLH', DOWNH: 'KLLH', AIR: 'KDASH', RUNH: 'KRUN' }) },
  axe: { id: 'axe', name: 'KAPAK', code: 'Digit6', key: '6', color: '#ffb070', kind: 'blade', idle: 'a_idle', twoHand: true, len: 16, rest: -2.1, trail: '#ffb070',
    get: fromMoves('A', { UPH: 'ALLH', DOWNH: 'AHL', AIR: 'ADASH', RUNH: 'ARUN' }) },
  dual: { id: 'dual', name: 'PEDANG KEMBAR', code: 'Digit7', key: '7', color: '#bfe8ff', kind: 'blade', idle: 'd_idle', twoHand: false, len: 12, rest: 0.6, trail: '#bfe8ff',
    get: fromMoves('D', { UPH: 'DLH', DOWNH: 'DH', AIR: 'DDASH', RUNH: 'DRUN' }) },
  yoyo: { id: 'yoyo', name: 'YOYO', code: 'Digit8', key: '8', color: '#ff6b3d', kind: 'yoyo', idle: 'y2_idle', twoHand: false, len: 60, rest: 1.2, trail: '#ff8a3d',
    get: fromMoves('Y', { UPH: 'YLH', DOWNH: 'YHL', AIR: 'YAIR', DASH: 'YRUN', RUNH: 'YRUN' }) },
  takamura: { id: 'takamura', name: 'TAKAMURA', code: 'Digit9', key: '9', color: '#ffffff', kind: 'blade', idle: 't_cane', twoHand: false, len: 21, rest: 1.25, trail: '#ffffff', get: fromTable(TK) },
  hayabusa: { id: 'hayabusa', name: 'HAYABUSA', code: 'Digit0', key: '0', color: '#9ff8ff', kind: 'blade', idle: 'h_idle', twoHand: false, len: 20, rest: -0.5, trail: '#9ff8ff', get: fromTable(HY) },
  guandao: { id: 'guandao', name: 'GUAN DAO', code: 'KeyZ', key: 'Z', color: '#ff5a5a', kind: 'blade', idle: 'a_idle', twoHand: true, len: 40, rest: -1.25, trail: '#ff6a5a', get: fromTable(GD) },
  bat: { id: 'bat', name: 'PEMUKUL', code: 'KeyT', key: 'T', color: '#ffd27f', kind: 'blade', idle: 'a_idle', twoHand: true, len: 17, rest: -2.2, trail: '#ffd27f',
    get: fromMoves('B', { UPH: 'BLLL', DOWNH: 'BH', AIR: 'BDASH', RUNH: 'BRUN', LH: 'BLLLL' }) },
  shotgun: { id: 'shotgun', name: 'SHOTGUN', code: 'KeyY', key: 'Y', color: '#ff9d6a', kind: 'gun', idle: 'idle', twoHand: true, len: 14, rest: 0, trail: '#ff9d6a', gun: SHOTGUN, get: fromMoves('', { H: 'TKD', AIR: 'AIR', DOWNH: 'LLH', UPH: 'LLLH' }) },
  bow: { id: 'bow', name: 'BUSUR', code: 'KeyU', key: 'U', color: '#c8f08f', kind: 'bow', idle: 'bow', twoHand: true, len: 12, rest: 0, trail: '#c8f08f', gun: BOW, get: fromMoves('', { H: 'TKD', AIR: 'AIR', DOWNH: 'LLH', UPH: 'LLLH' }) },
  buster: { id: 'buster', name: 'BUSTER', code: 'KeyI', key: 'I', color: MAKO, kind: 'blade', idle: 'a_idle', twoHand: true, len: 26, rest: -2.0, trail: MAKO, get: fromTable(BU) },
  boxing: { id: 'boxing', name: 'TINJU', code: 'KeyB', key: 'B', color: '#ff5a5a', kind: 'glove', idle: 'bx_ali', twoHand: false, len: 0, rest: 0, trail: '#ff5a5a', get: fromTable(BX) },
};
export const WEAPON_ORDER: WeaponKind[] = ['fist', 'pistol', 'rifle', 'nunchaku', 'katana', 'axe', 'dual', 'yoyo', 'takamura', 'hayabusa', 'guandao', 'bat', 'shotgun', 'bow', 'buster', 'boxing'];
export const WEAPON_BY_CODE: Record<string, WeaponKind> = Object.fromEntries(WEAPON_ORDER.map((w) => [WEAPONS[w].code, w]));
export { BOX_STANCES };
export type { BoxStance };

export function yoyoSkin(): YoyoSkin {
  try { const id = localStorage.getItem(YOYO_SKIN_KEY); if (isYoyoSkinId(id)) return YOYO_SKINS.find((s) => s.id === id) ?? YOYO_SKINS[0]; } catch { /* */ }
  return YOYO_SKINS[0];
}

/** sudut senjata relatif arah hadap di fase jurus. k = progres 0..1 dalam fase */
export function swingRel(w: WeaponDef, m: Move, phase: 'windup' | 'active' | 'recover', k: number): number {
  let from: number, to: number;
  if (m.slash) { from = m.slash.from; to = m.slash.to; }
  else if (m.arc >= Math.PI - 0.01) { from = 0; to = TAU; }
  else if (w.kind === 'yoyo') { from = -0.15; to = 0.15; }
  else { from = -1.6; to = 1.1; }
  const ease = (u: number) => 1 - Math.pow(1 - u, 3);
  if (phase === 'windup') return w.rest + (from - w.rest) * ease(k);
  if (phase === 'active') return from + (to - from) * ease(k);
  const end = ((to % TAU) + TAU) % TAU > Math.PI && Math.abs(to - from) > 4 ? to - TAU : to;
  return end + (w.rest - end) * ease(k);
}
export const toWorld = (rel: number, facing: number) => (facing > 0 ? rel : Math.PI - rel);

// ================================ GAMBAR SENJATA (side view, tanpa foreshortening) ================================
const D = (a: number) => ({ x: Math.cos(a), y: Math.sin(a) });

function blade(ctx: Ctx, g: Vec, a: number, len: number, back: number, steel: string, edge: string, guard: string, grip: string, w = 1) {
  const d = D(a), n = { x: -d.y, y: d.x };
  const hx = g.x - d.x * back, hy = g.y - d.y * back, tx = g.x + d.x * len, ty = g.y + d.y * len;
  pline(ctx, hx, hy, tx, ty, '#000', w + 2);
  pline(ctx, hx, hy, g.x + d.x, g.y + d.y, grip, w + 1);
  pline(ctx, g.x + d.x * 1.5, g.y + d.y * 1.5, tx, ty, steel, w);
  ctx.globalAlpha = 0.85; pline(ctx, g.x + d.x * 3 + n.x * 0.7, g.y + d.y * 3 + n.y * 0.7, tx - d.x, ty - d.y, edge, 1); ctx.globalAlpha = 1;
  pline(ctx, g.x + d.x * 1.2 + n.x * 2, g.y + d.y * 1.2 + n.y * 2, g.x + d.x * 1.2 - n.x * 2, g.y + d.y * 1.2 - n.y * 2, guard, 1);
}

export interface DrawState { grip: Vec; back: Vec; ang: number; facing: number; time: number; ext: number; spin: number; active: boolean; charge: number; recoil: number; draw: number; aim: number; flash: boolean; stance: BoxStance; fh: Vec; bh: Vec; sheathed: boolean }

export function drawWeapon(ctx: Ctx, w: WeaponDef, s: DrawState) {
  const g = s.grip, a = s.ang, d = D(a), n = { x: -d.y, y: d.x }, side = s.facing;
  switch (w.id) {
    case 'katana': blade(ctx, g, a, 17, 4, '#dfe6ee', '#ffffff', '#c9a033', '#2a2140'); break;
    case 'hayabusa': blade(ctx, g, a, 18, 4, '#b9c8dc', '#9ff8ff', '#e0b84a', '#141018'); if (s.active) { ctx.globalAlpha = 0.5; pline(ctx, g.x, g.y, g.x + d.x * 18, g.y + d.y * 18, '#9ff8ff', 3); ctx.globalAlpha = 1; } break;
    case 'takamura': {
      if (s.sheathed) {
        // tongkat (sarung) di tangan
        pline(ctx, g.x - d.x * 3, g.y - d.y * 3, g.x + d.x * 18, g.y + d.y * 18, '#000', 3);
        pline(ctx, g.x - d.x * 3, g.y - d.y * 3, g.x + d.x * 18, g.y + d.y * 18, '#5a3a22', 1);
        pcircle(ctx, g.x + d.x * 18, g.y + d.y * 18, 1, '#c0c8d0');
      } else {
        blade(ctx, g, a, 21, 3, '#f4f8ff', '#ffffff', '#8a6a3a', '#5a3a22');
        const sb = s.back; pline(ctx, sb.x - 1, sb.y + 2, sb.x + side * 2, sb.y - 14, '#000', 3); pline(ctx, sb.x - 1, sb.y + 2, sb.x + side * 2, sb.y - 14, '#5a3a22', 1);
      }
      break;
    }
    case 'axe': {
      const tip = { x: g.x + d.x * 15, y: g.y + d.y * 15 };
      pline(ctx, g.x - d.x * 3, g.y - d.y * 3, tip.x, tip.y, '#000', 4); pline(ctx, g.x - d.x * 3, g.y - d.y * 3, tip.x, tip.y, '#6b4a2b', 2);
      const hx = tip.x - d.x * 3, hy = tip.y - d.y * 3, sn = side;
      for (let i = 0; i <= 5; i++) { const w2 = 4 - i * 0.5; pline(ctx, hx + n.x * sn * i, hy + n.y * sn * i, hx + n.x * sn * i + d.x * w2, hy + n.y * sn * i + d.y * w2, '#000', 3); }
      for (let i = 0; i <= 5; i++) { const w2 = 4 - i * 0.5; pline(ctx, hx + n.x * sn * i, hy + n.y * sn * i, hx + n.x * sn * i + d.x * w2, hy + n.y * sn * i + d.y * w2, '#a8b0b8', 1); }
      pline(ctx, hx + n.x * sn * 5.5, hy + n.y * sn * 5.5, hx + n.x * sn * 5.5 + d.x * 2, hy + n.y * sn * 5.5 + d.y * 2, '#ffffff', 1);
      break;
    }
    case 'bat': {
      const L = 17, at = (k: number) => ({ x: g.x + d.x * L * k, y: g.y + d.y * L * k });
      const kb = at(-0.12), g1 = at(0.3), mid = at(0.55), tip = at(1);
      pline(ctx, kb.x, kb.y, g1.x, g1.y, '#000', 3); pline(ctx, g1.x, g1.y, mid.x, mid.y, '#000', 4); pline(ctx, mid.x, mid.y, tip.x, tip.y, '#000', 5);
      pline(ctx, kb.x, kb.y, g1.x, g1.y, '#2b2b33', 1); pline(ctx, g1.x, g1.y, mid.x, mid.y, '#d9a866', 2); pline(ctx, mid.x, mid.y, tip.x, tip.y, '#e6b877', 3);
      pline(ctx, mid.x + n.x * 0.8, mid.y + n.y * 0.8, tip.x + n.x * 0.8 - d.x, tip.y + n.y * 0.8 - d.y, '#fff1cf', 1);
      break;
    }
    case 'dual': {
      blade(ctx, g, a, 11, 2.5, '#d9dde3', '#ffffff', '#c9a033', '#3b2a6b');
      const b2 = s.bh, a2 = a + side * (s.active ? 0.9 : 0.5);
      blade(ctx, b2, a2, 11, 2.5, '#c9ced6', '#ffffff', '#c9a033', '#3b2a6b');
      break;
    }
    case 'guandao': {
      const tip = { x: g.x + d.x * 40, y: g.y + d.y * 40 }, butt = { x: g.x - d.x * 14, y: g.y - d.y * 14 };
      pline(ctx, butt.x, butt.y, tip.x, tip.y, '#000', 4); pline(ctx, butt.x, butt.y, tip.x, tip.y, '#7a2a1a', 2);
      pline(ctx, g.x + d.x * 8, g.y + d.y * 8, g.x + d.x * 30, g.y + d.y * 30, '#9a3a24', 1);
      pcircle(ctx, butt.x, butt.y, 1.2, '#c9a033');
      // bilah bulan sabit + jumbai merah
      const bx = tip.x - d.x * 7, by = tip.y - d.y * 7, sn = side;
      ctx.fillStyle = '#000'; ctx.beginPath(); ctx.moveTo(bx - n.x * sn, by - n.y * sn); ctx.lineTo(tip.x + d.x * 5 + n.x * sn * 1, tip.y + d.y * 5 + n.y * sn * 1); ctx.lineTo(bx + n.x * sn * 6 + d.x * 2, by + n.y * sn * 6 + d.y * 2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#c9d2dc'; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(tip.x + d.x * 4, tip.y + d.y * 4); ctx.lineTo(bx + n.x * sn * 5 + d.x * 2, by + n.y * sn * 5 + d.y * 2); ctx.closePath(); ctx.fill();
      pline(ctx, bx + n.x * sn * 5 + d.x * 2, by + n.y * sn * 5 + d.y * 2, tip.x + d.x * 4, tip.y + d.y * 4, '#ffffff', 1);
      const ts = Math.sin(s.time * 8) * 1.2;
      pline(ctx, bx - d.x, by - d.y, bx - d.x * 2 - n.x * sn * 3 + ts, by - d.y * 2 - n.y * sn * 3 + 4, '#ff2a2a', 2);
      break;
    }
    case 'buster': {
      const L = 26, tip = { x: g.x + d.x * L, y: g.y + d.y * L };
      const base = { x: g.x + d.x * 3, y: g.y + d.y * 3 };
      const wdt = 2.6;
      const P = (p: Vec, k: number) => ({ x: p.x + n.x * k, y: p.y + n.y * k });
      ctx.fillStyle = '#000'; ctx.beginPath();
      const q = [P(base, -wdt - 1), P(tip, -wdt - 1), { x: tip.x + d.x * 2, y: tip.y + d.y * 2 }, P(tip, wdt + 1), P(base, wdt + 1)];
      ctx.moveTo(q[0].x, q[0].y); for (const v of q) ctx.lineTo(v.x, v.y); ctx.closePath(); ctx.fill();
      ctx.fillStyle = s.charge > 0 ? '#bfe8d8' : '#a3acb6'; ctx.beginPath();
      const r = [P(base, -wdt), P(tip, -wdt), { x: tip.x + d.x, y: tip.y + d.y }, P(tip, wdt), P(base, wdt)];
      ctx.moveTo(r[0].x, r[0].y); for (const v of r) ctx.lineTo(v.x, v.y); ctx.closePath(); ctx.fill();
      pline(ctx, P(base, wdt - 0.5).x, P(base, wdt - 0.5).y, P(tip, wdt - 0.5).x, P(tip, wdt - 0.5).y, '#e8eef4', 1);
      pcircle(ctx, base.x + d.x * 3, base.y + d.y * 3, 1, '#2a2a2a'); pcircle(ctx, base.x + d.x * 6, base.y + d.y * 6, 1, '#2a2a2a');
      pline(ctx, g.x - d.x * 4, g.y - d.y * 4, base.x, base.y, '#000', 3); pline(ctx, g.x - d.x * 4, g.y - d.y * 4, base.x, base.y, '#3a2a1a', 1);
      pline(ctx, P(base, -wdt - 1.5).x, P(base, -wdt - 1.5).y, P(base, wdt + 1.5).x, P(base, wdt + 1.5).y, '#6b7280', 1);
      if (s.charge > 0 || s.active) { ctx.globalAlpha = 0.35 + 0.3 * s.charge; pline(ctx, base.x, base.y, tip.x, tip.y, MAKO, 6); ctx.globalAlpha = 1; }
      break;
    }
    case 'nunchaku': {
      // gagang di tangan, rantai, batang bebas yang tertinggal mengikuti ayunan
      const h = { x: g.x + d.x * 6, y: g.y + d.y * 6 };
      const lag = s.active ? -side * 0.55 : 0;
      const fa = s.active ? a + lag : Math.PI / 2 + Math.sin(s.time * 3) * 0.25;
      const fd = D(fa), c1 = { x: h.x + fd.x * 3, y: h.y + fd.y * 3 }, e2 = { x: c1.x + fd.x * 6, y: c1.y + fd.y * 6 };
      pline(ctx, g.x - d.x, g.y - d.y, h.x, h.y, '#000', 3); pline(ctx, g.x - d.x, g.y - d.y, h.x, h.y, '#c98a3a', 1);
      pline(ctx, h.x, h.y, c1.x, c1.y, '#9aa3b2', 1);
      pline(ctx, c1.x, c1.y, e2.x, e2.y, '#000', 3); pline(ctx, c1.x, c1.y, e2.x, e2.y, '#c98a3a', 1);
      pcircle(ctx, e2.x, e2.y, 0.8, '#ffd27f');
      break;
    }
    case 'yoyo': {
      const L = s.ext;
      const yx = g.x + d.x * L, yy = g.y + d.y * L;
      ctx.globalAlpha = 0.8; pline(ctx, g.x, g.y, yx, yy, '#f4f4f4', 1); ctx.globalAlpha = 1;
      drawYoyoSprite(ctx, yx, yy, yoyoSkin(), s.spin, s.active, s.flash);
      break;
    }
    case 'shotgun': drawShotgun(ctx, g, s.aim, side, s.recoil * 2, null, s.recoil > 0.6 ? 1 : 0); break;
    case 'bow': {
      // busur tegak di tangan depan, tali ditarik tangan belakang
      const ad = D(s.aim), an = { x: -ad.y, y: ad.x };
      const top = { x: g.x + an.x * -9 - ad.x * 2, y: g.y + an.y * -9 - ad.y * 2 }, bot = { x: g.x + an.x * 9 - ad.x * 2, y: g.y + an.y * 9 - ad.y * 2 };
      const belly = { x: g.x + ad.x * 2.5, y: g.y + ad.y * 2.5 };
      ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(top.x, top.y); ctx.quadraticCurveTo(belly.x + ad.x * 3, belly.y + ad.y * 3, bot.x, bot.y); ctx.stroke();
      ctx.strokeStyle = '#8a5a2a'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(top.x, top.y); ctx.quadraticCurveTo(belly.x + ad.x * 3, belly.y + ad.y * 3, bot.x, bot.y); ctx.stroke();
      const pull = { x: g.x - ad.x * (2 + s.draw * 8), y: g.y - ad.y * (2 + s.draw * 8) };
      pline(ctx, top.x, top.y, pull.x, pull.y, '#e8e8e8', 1); pline(ctx, bot.x, bot.y, pull.x, pull.y, '#e8e8e8', 1);
      if (s.draw > 0.02) { pline(ctx, pull.x, pull.y, g.x + ad.x * 6, g.y + ad.y * 6, '#c9a063', 1); pline(ctx, g.x + ad.x * 6, g.y + ad.y * 6, g.x + ad.x * 8, g.y + ad.y * 8, '#dfe6ee', 1); if (s.draw >= 0.99 && Math.sin(s.time * 30) > 0) pcircle(ctx, g.x + ad.x * 8, g.y + ad.y * 8, 1, '#ffffff'); }
      break;
    }
    case 'boxing': {
      const def = BOX_STANCES[s.stance];
      drawGlove(ctx, s.bh.x, s.bh.y, a + Math.PI * 0.1, 1, def, s.flash);
      drawGlove(ctx, s.fh.x, s.fh.y, a, 1, def, s.flash);
      break;
    }
    default: break;
  }
}

/** ikon mini (±12x8 px) untuk HUD & roda senjata — versi ringkas tiap senjata */
export function drawWeaponIcon(ctx: Ctx, w: WeaponDef, x: number, y: number, t: number) {
  const g = { x: x - 4, y: y + 3 }, a = -0.6;
  switch (w.id) {
    case 'fist': pcircle(ctx, x, y, 3, '#ffffff'); pline(ctx, x - 2, y - 1, x + 2, y - 1, '#000'); break;
    case 'pistol': pline(ctx, x - 4, y - 1, x + 4, y - 1, '#000', 3); pline(ctx, x - 4, y - 1, x + 4, y - 1, '#c9ced6', 1); pline(ctx, x - 3, y, x - 3, y + 3, '#000', 2); break;
    case 'rifle': pline(ctx, x - 6, y, x + 6, y - 1, '#000', 3); pline(ctx, x - 6, y, x + 6, y - 1, '#8a6a3a', 1); pline(ctx, x - 1, y, x - 1, y + 3, '#000', 2); break;
    case 'shotgun': pline(ctx, x - 6, y + 1, x + 6, y - 1, '#000', 3); pline(ctx, x - 6, y + 1, x - 1, y, '#7a4a22', 1); pline(ctx, x - 1, y, x + 6, y - 1, '#9aa3ad', 1); break;
    case 'katana': blade(ctx, g, a, 10, 2, '#dfe6ee', '#ffffff', '#c9a033', '#2a2140'); break;
    case 'hayabusa': blade(ctx, g, a, 10, 2, '#b9c8dc', '#9ff8ff', '#e0b84a', '#141018'); break;
    case 'takamura': blade(ctx, g, a, 11, 2, '#f4f8ff', '#ffffff', '#8a6a3a', '#5a3a22'); break;
    case 'dual': blade(ctx, { x: x - 4, y: y + 2 }, -0.4, 7, 2, '#d9dde3', '#ffffff', '#c9a033', '#3b2a6b'); blade(ctx, { x: x - 2, y: y + 4 }, -0.9, 7, 2, '#c9ced6', '#ffffff', '#c9a033', '#3b2a6b'); break;
    case 'axe': { const d = D(a), tp = { x: g.x + d.x * 10, y: g.y + d.y * 10 }; pline(ctx, g.x, g.y, tp.x, tp.y, '#000', 3); pline(ctx, g.x, g.y, tp.x, tp.y, '#6b4a2b', 1); pcircle(ctx, tp.x + 1, tp.y + 1, 2.5, '#000'); pcircle(ctx, tp.x + 1, tp.y + 1, 1.6, '#a8b0b8'); break; }
    case 'bat': { const d = D(a); pline(ctx, g.x, g.y, g.x + d.x * 5, g.y + d.y * 5, '#000', 3); pline(ctx, g.x + d.x * 5, g.y + d.y * 5, g.x + d.x * 11, g.y + d.y * 11, '#000', 4); pline(ctx, g.x + d.x * 4, g.y + d.y * 4, g.x + d.x * 11, g.y + d.y * 11, '#e6b877', 2); break; }
    case 'guandao': { const d = D(-0.75), b0 = { x: x - 5, y: y + 4 }, tp = { x: b0.x + d.x * 13, y: b0.y + d.y * 13 }; pline(ctx, b0.x, b0.y, tp.x, tp.y, '#000', 3); pline(ctx, b0.x, b0.y, tp.x, tp.y, '#7a2a1a', 1); pcircle(ctx, tp.x + 1, tp.y, 2.4, '#000'); pcircle(ctx, tp.x + 1, tp.y, 1.5, '#c9d2dc'); pline(ctx, tp.x - 2, tp.y + 1, tp.x - 3, tp.y + 3, '#ff2a2a', 1); break; }
    case 'buster': { const d = D(a), tp = { x: g.x + d.x * 11, y: g.y + d.y * 11 }; pline(ctx, g.x, g.y, tp.x, tp.y, '#000', 5); pline(ctx, g.x + d.x * 2, g.y + d.y * 2, tp.x, tp.y, '#a3acb6', 3); pline(ctx, g.x - d.x * 2, g.y - d.y * 2, g.x + d.x, g.y + d.y, '#3a2a1a', 1); break; }
    case 'nunchaku': pline(ctx, x - 4, y - 3, x - 2, y + 2, '#000', 3); pline(ctx, x - 4, y - 3, x - 2, y + 2, '#c98a3a', 1); pline(ctx, x - 2, y + 2, x + 1, y + 2, '#9aa3b2', 1); pline(ctx, x + 1, y + 2, x + 4, y - 3, '#000', 3); pline(ctx, x + 1, y + 2, x + 4, y - 3, '#c98a3a', 1); break;
    case 'yoyo': drawYoyoSprite(ctx, x, y, yoyoSkin(), t * 8, false); break;
    case 'boxing': drawGlove(ctx, x, y, 0, 1, BOX_STANCES.ali); break;
    case 'bow': ctx.strokeStyle = '#000'; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.moveTo(x - 1, y - 5); ctx.quadraticCurveTo(x + 5, y, x - 1, y + 5); ctx.stroke(); ctx.strokeStyle = '#8a5a2a'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x - 1, y - 5); ctx.quadraticCurveTo(x + 5, y, x - 1, y + 5); ctx.stroke(); pline(ctx, x - 1, y - 5, x - 1, y + 5, '#e8e8e8', 1); break;
    default: break;
  }
}
