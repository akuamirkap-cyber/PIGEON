import type { HeroKind, Team, UnitType } from "./constants";

export interface Unit {
  id: number;
  team: Team;
  type: UnitType;
  hero?: HeroKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  atk: number;
  cd: number;
  cdT: number;
  range: number;
  speed: number;
  aggro: number;
  radius: number;
  cleave: number;
  ranged: boolean;
  facing: number;
  walk: number;
  spawnT: number; // counts up from negative (delay) -> anim
  hitT: number;
  atkT: number;
  showHpT: number;
  target: Unit | null;
  attackingCastle: boolean;
  retarget: number;
  squad: Squad;
  offX: number;
  offY: number;
  dead: boolean;
  chargeDist: number;
  scale: number;
  seed: number;
  shootDelay: number;
  fleeing: boolean;
  cheerT: number;
  charged: boolean;
  recoil: number;
  flyZ: number;
  flyV: number;
}

export interface Squad {
  id: number;
  team: Team;
  type: UnitType;
  hero?: HeroKind;
  anchorX: number;
  anchorY: number;
  units: Unit[];
  bannerX: number;
  bannerY: number;
  speed: number;
  spawnT: number;
  dead: boolean;
  deadT: number;
  engaged: number;
  alive: number;
  state: "ready" | "march" | "rout";
  walk: number;
  volleyCd: number;
  volleyWant: boolean;
  initial: number;
  launchT: number;
  cost: number;
  charging: boolean;
  chargeCheck: number;
}

export interface Decal {
  x: number;
  y: number;
  r: number;
  t: number;
  kind: "blood" | "crater" | "pool";
  rot: number;
  seed: number;
}

export interface Corpse {
  x: number;
  y: number;
  team: Team;
  type: UnitType;
  hero?: HeroKind;
  facing: number;
  t: number;
  scale: number;
}

export interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind: "dust" | "spark" | "debris" | "helmet" | "ring" | "smoke" | "fire" | "star" | "blood" | "slash" | "flash" | "leaf" | "dirt";
  rot: number;
  vr: number;
}

export interface Projectile {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  t: number;
  dur: number;
  arc: number;
  z0: number;
  team: number;
  dmg: number;
  target: Unit | null;
  castle: number; // -1 none, else castle team index
  big: boolean;
  atkType?: string;
  ball?: boolean;
}

export interface StuckArrow {
  x: number;
  y: number;
  ang: number;
  t: number;
}

export interface FloatText {
  x: number;
  y: number;
  text: string;
  color: string;
  t: number;
  max: number;
  size: number;
}
