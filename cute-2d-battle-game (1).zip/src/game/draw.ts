import { CASTLE, FIELD_BOTTOM, FIELD_TOP, H, TEAM_COLORS, W } from "./constants";
import type { HeroKind, Team, UnitType } from "./constants";

const BLACK = "#1a1814";
const HELM = "#c9c7c2";
const HELM_LIGHT = "#efeee9";
const HELM_DARK = "#8f8c86";
const STEEL = "#e7e7e3";
const WOOD = "#5a3f26";

export function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const easeOutBack = (t: number) => {
  const c1 = 2.2;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
};
export const easeOutElastic = (t: number) => {
  if (t <= 0) return 0;
  if (t >= 1) return 1;
  return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * ((2 * Math.PI) / 3)) + 1;
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

function circle(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}
function ellipse(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, color: string, rot = 0) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
  ctx.fill();
}
function line(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, color: string, w: number) {
  ctx.strokeStyle = color;
  ctx.lineWidth = w;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1, y1);
  ctx.stroke();
}

export interface FigureOpts {
  team: Team;
  type: UnitType;
  hero?: HeroKind;
  walk: number;
  moving: boolean;
  atk: number; // 1 -> 0
  flash: boolean;
  recoil?: number;
}

/* -------------------- helmets / heads -------------------- */
function drawHead(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, o: FigureOpts, c: (s: string) => string) {
  const h = o.hero;
  if (h === "swiftbow") {
    // green hood
    ctx.fillStyle = c("#3f6e3b");
    ctx.beginPath();
    ctx.moveTo(x - r * 1.1, y + r * 0.6);
    ctx.quadraticCurveTo(x - r * 1.3, y - r * 1.6, x - r * 0.2, y - r * 1.5);
    ctx.quadraticCurveTo(x + r * 1.2, y - r * 1.1, x + r * 1.0, y + r * 0.6);
    ctx.closePath();
    ctx.fill();
    circle(ctx, x + r * 0.25, y + r * 0.05, r * 0.6, c("#14120f"));
    circle(ctx, x + r * 0.5, y - r * 0.05, r * 0.13, c("#fff"));
    return;
  }
  if (h === "edward") {
    circle(ctx, x, y, r, c("#2a2520"));
    // crown
    ctx.fillStyle = c("#f2c23a");
    ctx.beginPath();
    ctx.moveTo(x - r, y - r * 0.4);
    ctx.lineTo(x - r, y - r * 1.5);
    ctx.lineTo(x - r * 0.5, y - r * 0.95);
    ctx.lineTo(x, y - r * 1.7);
    ctx.lineTo(x + r * 0.5, y - r * 0.95);
    ctx.lineTo(x + r, y - r * 1.5);
    ctx.lineTo(x + r, y - r * 0.4);
    ctx.closePath();
    ctx.fill();
    circle(ctx, x + r * 0.45, y + r * 0.1, r * 0.17, c("#fff"));
    return;
  }
  if (h === "brian") {
    circle(ctx, x, y, r, c("#24201b"));
    // blue face paint
    ctx.fillStyle = c("#3a7bd5");
    ctx.fillRect(x - r * 0.1, y - r * 0.35, r * 1.0, r * 0.45);
    circle(ctx, x + r * 0.5, y - r * 0.12, r * 0.15, c("#fff"));
    // hair tuft
    ctx.fillStyle = c("#b5672b");
    ctx.beginPath();
    ctx.moveTo(x - r * 0.9, y - r * 0.4);
    ctx.lineTo(x - r * 0.6, y - r * 1.5);
    ctx.lineTo(x - r * 0.1, y - r * 0.9);
    ctx.lineTo(x + r * 0.3, y - r * 1.4);
    ctx.lineTo(x + r * 0.6, y - r * 0.7);
    ctx.closePath();
    ctx.fill();
    return;
  }
  // standard helmet
  circle(ctx, x, y, r, c(HELM));
  ctx.fillStyle = c(HELM_DARK);
  ctx.beginPath();
  ctx.arc(x, y, r, 0.2, Math.PI - 0.2);
  ctx.fill();
  circle(ctx, x - r * 0.35, y - r * 0.35, r * 0.38, c(HELM_LIGHT));
  // eye slit
  ctx.fillStyle = c("#15130f");
  ctx.fillRect(x + r * 0.05, y - r * 0.12, r * 0.95, r * 0.34);
  // nasal / rim
  ctx.fillStyle = c(HELM_DARK);
  ctx.fillRect(x - r * 1.05, y + r * 0.15, r * 2.1, r * 0.25);

  if (h === "toralf" || h === "olaf") {
    // horns
    ctx.strokeStyle = c("#f3eadb");
    ctx.lineWidth = r * 0.45;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x - r * 0.7, y - r * 0.6);
    ctx.quadraticCurveTo(x - r * 1.7, y - r * 1.0, x - r * 1.4, y - r * 2.0);
    ctx.moveTo(x + r * 0.7, y - r * 0.6);
    ctx.quadraticCurveTo(x + r * 1.7, y - r * 1.0, x + r * 1.4, y - r * 2.0);
    ctx.stroke();
    if (h === "olaf") {
      ctx.fillStyle = c("#d9792f");
      ctx.beginPath();
      ctx.moveTo(x - r * 0.4, y + r * 0.5);
      ctx.lineTo(x + r * 1.1, y + r * 0.4);
      ctx.lineTo(x + r * 0.4, y + r * 1.7);
      ctx.closePath();
      ctx.fill();
    } else {
      // skull face
      circle(ctx, x + r * 0.35, y + r * 0.1, r * 0.55, c("#f3eadb"));
      circle(ctx, x + r * 0.5, y, r * 0.15, c("#15130f"));
    }
  }
  if (h === "carl") {
    // blue plume
    ctx.fillStyle = c("#5b8ef0");
    ctx.beginPath();
    ctx.moveTo(x - r * 0.2, y - r * 0.8);
    ctx.quadraticCurveTo(x - r * 0.2, y - r * 2.6, x - r * 1.8, y - r * 2.2);
    ctx.quadraticCurveTo(x - r * 1.0, y - r * 1.5, x - r * 0.9, y - r * 0.6);
    ctx.closePath();
    ctx.fill();
  }
  if (h === "renold") {
    ctx.fillStyle = c("#d63b3b");
    ctx.beginPath();
    ctx.moveTo(x, y - r * 0.8);
    ctx.quadraticCurveTo(x - r * 0.3, y - r * 2.4, x - r * 2, y - r * 1.6);
    ctx.quadraticCurveTo(x - r * 1, y - r * 1.2, x - r * 0.8, y - r * 0.5);
    ctx.closePath();
    ctx.fill();
  }
}

function drawShield(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, o: FigureOpts, c: (s: string) => string) {
  const tc = TEAM_COLORS[o.team];
  let main = tc.main;
  let dark = tc.dark;
  let cross = "";
  if (o.hero === "renold") {
    main = "#f1ede4";
    dark = "#b8b1a3";
    cross = "#d63b3b";
  } else if (o.hero === "edward") {
    main = "#8b5cc8";
    dark = "#58378a";
  } else if (o.hero === "carl") {
    main = "#a9c3f0";
    dark = "#5c7cb8";
    cross = "#ffffff";
  }
  if (o.hero === "renold") {
    // heater shield
    ctx.fillStyle = c(dark);
    ctx.beginPath();
    ctx.moveTo(x - r, y - r);
    ctx.lineTo(x + r, y - r);
    ctx.quadraticCurveTo(x + r, y + r * 0.6, x, y + r * 1.3);
    ctx.quadraticCurveTo(x - r, y + r * 0.6, x - r, y - r);
    ctx.fill();
    ctx.fillStyle = c(main);
    ctx.beginPath();
    ctx.moveTo(x - r * 0.8, y - r * 0.8);
    ctx.lineTo(x + r * 0.8, y - r * 0.8);
    ctx.quadraticCurveTo(x + r * 0.8, y + r * 0.5, x, y + r * 1.05);
    ctx.quadraticCurveTo(x - r * 0.8, y + r * 0.5, x - r * 0.8, y - r * 0.8);
    ctx.fill();
    ctx.fillStyle = c(cross);
    ctx.fillRect(x - r * 0.18, y - r * 0.75, r * 0.36, r * 1.6);
    ctx.fillRect(x - r * 0.7, y - r * 0.3, r * 1.4, r * 0.36);
    return;
  }
  circle(ctx, x, y, r, c(dark));
  circle(ctx, x, y, r * 0.78, c(main));
  circle(ctx, x - r * 0.25, y - r * 0.28, r * 0.28, c("rgba(255,255,255,0.35)"));
  if (cross) {
    ctx.fillStyle = c(cross);
    ctx.fillRect(x - r * 0.12, y - r * 0.6, r * 0.24, r * 1.2);
    ctx.fillRect(x - r * 0.6, y - r * 0.12, r * 1.2, r * 0.24);
  } else {
    circle(ctx, x, y, r * 0.22, c(HELM));
  }
}

/** weapon swing angle: 0 = straight up, + = forward */
function swingAngle(atk: number, rest: number, back: number, fwd: number) {
  if (atk <= 0) return rest;
  const p = 1 - atk;
  if (p < 0.3) return lerp(rest, back, p / 0.3);
  if (p < 0.55) return lerp(back, fwd, (p - 0.3) / 0.25);
  return lerp(fwd, rest, (p - 0.55) / 0.45);
}

function drawHorse(ctx: CanvasRenderingContext2D, o: FigureOpts, c: (s: string) => string, bob: number) {
  const white = o.hero === "renold";
  const body = white ? "#efe9dd" : TEAM_COLORS[o.team].horse;
  const dark = white ? "#c4bcad" : "#2a221c";
  const legC = white ? "#d8d0c1" : "#2b231d";
  // legs
  const g = o.moving ? o.walk : 0;
  const legs = [-5.2, -3.4, 3.4, 5.2];
  legs.forEach((lx, i) => {
    const sw = o.moving ? Math.sin(g + i * 1.6) * 1.8 : 0;
    const lift = o.moving ? Math.max(0, Math.cos(g + i * 1.6)) * 1.2 : 0;
    line(ctx, lx, -6 + bob, lx + sw, -0.6 - lift, c(i % 2 ? legC : dark), 1.5);
  });
  // tail
  ctx.strokeStyle = c(dark);
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(-7, -8.5 + bob);
  ctx.quadraticCurveTo(-10, -7 + bob + (o.moving ? Math.sin(g * 2) : 0), -9.5, -3.5 + bob);
  ctx.stroke();
  // body
  ellipse(ctx, 0, -7.5 + bob, 7.8, 3.7, c(body));
  ellipse(ctx, 0, -6.4 + bob, 7, 2.2, c(white ? "#ddd5c7" : "rgba(0,0,0,0.18)"));
  // neck + head
  ctx.fillStyle = c(body);
  ctx.beginPath();
  ctx.moveTo(3.5, -10 + bob);
  ctx.lineTo(7.5, -15 + bob);
  ctx.lineTo(9.5, -13.5 + bob);
  ctx.lineTo(7, -7 + bob);
  ctx.closePath();
  ctx.fill();
  ellipse(ctx, 9.6, -13.4 + bob, 3.2, 1.8, c(body), 0.45);
  circle(ctx, 9.4, -14.6 + bob, 0.5, c("#111"));
  // mane
  line(ctx, 4, -10.5 + bob, 7.4, -15.6 + bob, c(dark), 1.2);
  // ear
  line(ctx, 7.6, -15.4 + bob, 7.2, -17 + bob, c(dark), 1);
  // saddle cloth
  const tc = TEAM_COLORS[o.team];
  ctx.fillStyle = c(white ? "#d63b3b" : tc.main);
  ctx.beginPath();
  ctx.moveTo(-3, -10.6 + bob);
  ctx.lineTo(3, -10.6 + bob);
  ctx.lineTo(2.4, -5 + bob);
  ctx.lineTo(-2.4, -5 + bob);
  ctx.closePath();
  ctx.fill();
}

/** Draw a figure facing right with feet at (0,0). */
export function drawFigure(ctx: CanvasRenderingContext2D, o: FigureOpts) {
  const c = (s: string) => (o.flash ? "#ffffff" : s);
  if (o.type === "cannon") return drawCannon(ctx, o, c);
  const mounted = o.type === "cavalry" || o.hero === "renold";
  const lunge = o.atk > 0 ? Math.sin((1 - o.atk) * Math.PI) * (mounted ? 4 : 2.6) : 0;

  if (mounted) {
    const bob = o.moving ? -Math.abs(Math.sin(o.walk)) * 1.6 : 0;
    ctx.save();
    ctx.translate(lunge * 0.5, 0);
    drawHorse(ctx, o, c, bob);
    // rider
    const ry = -11 + bob;
    ellipse(ctx, -0.5, ry - 1.5, 2.8, 3.6, c(BLACK));
    drawHead(ctx, 0, ry - 6.6, 2.9, o, c);
    // lance
    const ang = o.atk > 0 ? lerp(0.2, 0, Math.sin((1 - o.atk) * Math.PI)) : 0.22;
    ctx.save();
    ctx.translate(1, ry - 1);
    ctx.rotate(-ang);
    line(ctx, -6, 0, 17 + lunge, 0, c(WOOD), 1.3);
    ctx.fillStyle = c(STEEL);
    ctx.beginPath();
    ctx.moveTo(17 + lunge, -1.2);
    ctx.lineTo(21 + lunge, 0);
    ctx.lineTo(17 + lunge, 1.2);
    ctx.fill();
    // pennant
    ctx.fillStyle = c(o.hero === "renold" ? "#d63b3b" : TEAM_COLORS[o.team].main);
    ctx.beginPath();
    ctx.moveTo(12, 0);
    ctx.lineTo(16, 0);
    ctx.lineTo(13, -3 - (o.moving ? Math.sin(o.walk * 2) * 0.8 : 0));
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    drawShield(ctx, 1.4, ry - 1, 2.6, o, c);
    ctx.restore();
    return;
  }

  // ---------------- infantry ----------------
  const step = o.moving ? Math.sin(o.walk) : 0;
  const bob = o.moving ? -Math.abs(Math.sin(o.walk)) * 1.1 : 0;
  // legs
  ctx.fillStyle = c(BLACK);
  const l1 = Math.max(0, step) * 1.6;
  const l2 = Math.max(0, -step) * 1.6;
  ctx.fillRect(-2.3 + step * 0.6, -3.6 - l1, 1.7, 3.6);
  ctx.fillRect(0.6 - step * 0.6, -3.6 - l2, 1.7, 3.6);

  ctx.save();
  ctx.translate(lunge, bob);

  const isArcher = o.type === "archer" || o.hero === "swiftbow";
  const big = o.hero === "brian" || o.hero === "toralf";

  // back weapon arm / quiver
  if (isArcher) {
    ctx.fillStyle = c(o.hero === "swiftbow" ? "#6b4a2a" : TEAM_COLORS[o.team].dark);
    ctx.save();
    ctx.translate(-3, -8);
    ctx.rotate(-0.4);
    ctx.fillRect(-1.2, -3, 2.4, 6);
    line(ctx, 0, -3, -0.6, -5, c("#ddd"), 0.7);
    line(ctx, 0.8, -3, 0.6, -5.2, c("#ddd"), 0.7);
    ctx.restore();
  }

  // body
  if (o.hero === "swiftbow") {
    ellipse(ctx, 0, -6.2, 3.8, 4.4, c("#2f5a2c"));
  } else {
    ellipse(ctx, 0, -6.2, big ? 4.2 : 3.6, big ? 4.6 : 4.3, c(BLACK));
  }
  // team scarf for archers so team is readable
  if (isArcher && !o.hero) {
    ctx.fillStyle = c(TEAM_COLORS[o.team].main);
    ctx.fillRect(-3, -9.4, 6, 1.6);
  }

  const headR = big ? 3.6 : 3.3;
  drawHead(ctx, 0.3, -12.4, headR, o, c);

  // weapons
  if (isArcher) {
    const draw = o.atk > 0 ? Math.sin((1 - o.atk) * Math.PI) : 0;
    ctx.strokeStyle = c("#7a5530");
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(2.2, -6.8, 5.2, -1.15, 1.15);
    ctx.stroke();
    const tx = 2.2 + Math.cos(1.15) * 5.2;
    const ty1 = -6.8 - Math.sin(1.15) * 5.2;
    const ty2 = -6.8 + Math.sin(1.15) * 5.2;
    ctx.strokeStyle = c("#e8e2d0");
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.moveTo(tx, ty1);
    ctx.lineTo(tx - draw * 3.5, -6.8);
    ctx.lineTo(tx, ty2);
    ctx.stroke();
    if (draw > 0.1) line(ctx, tx - draw * 3.5, -6.8, tx + 5, -6.8, c("#e8e2d0"), 0.7);
  } else if (o.type === "spear") {
    const ang = o.atk > 0 ? lerp(0.12, 1.4, Math.sin((1 - o.atk) * Math.PI)) : 0.12;
    ctx.save();
    ctx.translate(1.8, -6);
    ctx.rotate(ang);
    line(ctx, 0, 6, 0, -17, c(WOOD), 1.15);
    ctx.fillStyle = c(STEEL);
    ctx.beginPath();
    ctx.moveTo(-1.2, -16.5);
    ctx.lineTo(0, -21);
    ctx.lineTo(1.2, -16.5);
    ctx.fill();
    ctx.restore();
    drawShield(ctx, 2.6, -6, 3, o, c);
  } else if (o.hero === "toralf") {
    const ang = swingAngle(o.atk, 0.3, -1.4, 2.0);
    ctx.save();
    ctx.translate(2.2, -6.5);
    ctx.rotate(ang);
    line(ctx, 0, 3, 0, -13, c(WOOD), 1.4);
    ctx.fillStyle = c(STEEL);
    ctx.beginPath();
    ctx.moveTo(0, -13);
    ctx.quadraticCurveTo(6, -14, 6.5, -9);
    ctx.quadraticCurveTo(4, -10.5, 0, -9);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(0, -13);
    ctx.quadraticCurveTo(-3.5, -12.5, -3.8, -9.8);
    ctx.lineTo(0, -10);
    ctx.fill();
    ctx.restore();
  } else if (o.hero === "olaf") {
    const ang = swingAngle(o.atk, 0.5, -1.2, 2.0);
    for (const [hx, off] of [
      [2.4, 0],
      [-2.2, 0.6],
    ] as const) {
      ctx.save();
      ctx.translate(hx, -6.5);
      ctx.rotate(ang - off);
      line(ctx, 0, 2, 0, -8, c(WOOD), 1.2);
      ctx.fillStyle = c(STEEL);
      ctx.beginPath();
      ctx.moveTo(0, -8);
      ctx.quadraticCurveTo(4, -8.5, 4.2, -5);
      ctx.lineTo(0, -5.5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  } else if (o.hero === "brian") {
    const ang = swingAngle(o.atk, 0.35, -1.3, 2.1);
    ctx.save();
    ctx.translate(2.2, -6.5);
    ctx.rotate(ang);
    line(ctx, 0, 2.5, 0, -1, c("#3a2a1a"), 1.4);
    line(ctx, -2.5, -1, 2.5, -1, c(HELM_DARK), 1.3);
    ctx.fillStyle = c(STEEL);
    ctx.beginPath();
    ctx.moveTo(-1.2, -1.2);
    ctx.lineTo(-1.1, -19);
    ctx.lineTo(0, -21.5);
    ctx.lineTo(1.1, -19);
    ctx.lineTo(1.2, -1.2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  } else if (o.hero === "carl") {
    const ang = swingAngle(o.atk, 0.45, -1.2, 1.9);
    ctx.save();
    ctx.translate(2.4, -6.5);
    ctx.rotate(ang);
    line(ctx, 0, 2, 0, -10, c(WOOD), 1.3);
    ctx.fillStyle = c(HELM);
    ctx.fillRect(-2.6, -13, 5.2, 3.6);
    ctx.fillStyle = c(HELM_LIGHT);
    ctx.fillRect(-2.6, -13, 5.2, 1.2);
    ctx.restore();
    drawShield(ctx, 2.8, -6, 3.6, o, c);
  } else {
    // sword (also edward)
    const ang = swingAngle(o.atk, 0.55, -1.1, 1.9);
    ctx.save();
    ctx.translate(2.4, -6.5);
    ctx.rotate(ang);
    line(ctx, 0, 1.5, 0, -1, c("#3a2a1a"), 1.2);
    line(ctx, -1.6, -1, 1.6, -1, c(HELM_DARK), 1);
    line(ctx, 0, -1.2, 0, -9.5, c(STEEL), 1.25);
    ctx.restore();
    drawShield(ctx, 2.8, -6, o.hero ? 3.6 : 3.3, o, c);
  }
  ctx.restore();
}

export function drawShadow(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, alpha = 0.28) {
  ctx.fillStyle = `rgba(28,42,14,${alpha})`;
  ctx.beginPath();
  ctx.ellipse(x + rx * 0.25, y, rx, rx * 0.38, 0, 0, Math.PI * 2);
  ctx.fill();
}

/* -------------------- corpses -------------------- */
export function drawCorpse(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  team: Team,
  type: UnitType,
  facing: number,
  scale: number,
  alpha: number,
  fall: number,
  hero?: HeroKind
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  ctx.scale(facing * scale, scale);
  if (type === "cannon") {
    // broken cannon
    ellipse(ctx, 0, -2, 9, 3, "#5a3d22");
    ctx.save();
    ctx.rotate(0.25 * fall);
    ctx.fillStyle = "#2b2b2e";
    ctx.fillRect(-6, -8, 16, 4);
    ctx.restore();
    circle(ctx, -6, -3, 3.5, "#3b2a1a");
    ctx.restore();
    return;
  }
  const mounted = type === "cavalry" || hero === "renold";
  if (mounted) {
    ellipse(ctx, 0, -2.5, 8.5 * fall + 1, 3, hero === "renold" ? "#e5dfd2" : TEAM_COLORS[team].horse);
    line(ctx, 6, -3, 10, -5, hero === "renold" ? "#e5dfd2" : TEAM_COLORS[team].horse, 3);
  }
  ctx.rotate(-Math.PI / 2 * fall);
  ellipse(ctx, 0, -5, 3.4, 3.9, BLACK);
  circle(ctx, 0.3, -11, 3, HELM_DARK);
  if (type !== "archer") {
    circle(ctx, 2.6, -5, 2.8, TEAM_COLORS[team].dark);
  }
  ctx.restore();
}

/* -------------------- banner -------------------- */
export function drawBanner(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  team: Team,
  t: number,
  scale: number,
  fall: number,
  alpha: number,
  seed: number
) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  // shadow
  drawShadow(ctx, 0, 0, 5 * scale, 0.3);
  ctx.rotate(fall * (team === 0 ? -1 : 1) * (Math.PI / 2.1));
  ctx.scale(scale, scale);
  const tc = TEAM_COLORS[team];
  const poleH = 46;
  line(ctx, 0, 0, 0, -poleH, BLACK, 1.8);
  // ornament
  circle(ctx, 0, -poleH - 2.2, 2.4, HELM);
  circle(ctx, -0.7, -poleH - 2.9, 0.9, HELM_LIGHT);
  line(ctx, 0, -poleH - 4, 0, -poleH - 8, HELM, 1.1);
  // stripes on pole top
  ctx.fillStyle = HELM;
  ctx.fillRect(-1.3, -poleH + 2, 2.6, 1.2);
  ctx.fillRect(-1.3, -poleH + 5, 2.6, 1.2);

  const dir = team === 0 ? -1 : 1; // trailing
  const fw = 17;
  const fh = 24;
  const top = -poleH + 8;
  const wav = (xx: number, yy: number) => Math.sin(t * 4.2 + seed + xx * 0.32 + yy * 0.1) * xx * 0.075;
  const pts: [number, number][] = [];
  const N = 6;
  for (let i = 0; i <= N; i++) {
    const xx = (fw * i) / N;
    pts.push([xx, top + wav(xx, 0)]);
  }
  // bottom edge with notch
  const bot = top + fh;
  if (team === 0) {
    pts.push([fw, bot + wav(fw, fh)]);
    pts.push([fw / 2, bot - 5 + wav(fw / 2, fh)]);
    pts.push([0, bot]);
  } else {
    pts.push([fw, bot - 4 + wav(fw, fh)]);
    pts.push([fw * 0.75, bot + wav(fw * 0.75, fh)]);
    pts.push([fw * 0.5, bot - 3 + wav(fw * 0.5, fh)]);
    pts.push([fw * 0.25, bot + wav(fw * 0.25, fh)]);
    pts.push([0, bot - 2]);
  }
  // crossbar
  line(ctx, 0, top, dir * (fw + 1), top + wav(fw, 0), BLACK, 1.1);
  ctx.fillStyle = tc.main;
  ctx.beginPath();
  pts.forEach(([px, py], i) => (i === 0 ? ctx.moveTo(px * dir, py) : ctx.lineTo(px * dir, py)));
  ctx.closePath();
  ctx.fill();
  // shade band
  ctx.fillStyle = "rgba(0,0,0,0.13)";
  ctx.beginPath();
  ctx.moveTo(fw * 0.62 * dir, top + wav(fw * 0.62, 0));
  ctx.lineTo(fw * dir, top + wav(fw, 0));
  ctx.lineTo(fw * dir, bot - 2 + wav(fw, fh));
  ctx.lineTo(fw * 0.62 * dir, bot - 2 + wav(fw * 0.62, fh));
  ctx.closePath();
  ctx.fill();

  // emblem
  const cx = (fw / 2) * dir;
  const cy = top + fh * 0.45 + wav(fw / 2, fh / 2);
  ctx.strokeStyle = "#f6f1e6";
  ctx.fillStyle = "#f6f1e6";
  ctx.lineCap = "round";
  if (team === 0) {
    // crossed axes
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx - 5, cy + 6);
    ctx.lineTo(cx + 5, cy - 6);
    ctx.moveTo(cx + 5, cy + 6);
    ctx.lineTo(cx - 5, cy - 6);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx + 5, cy - 6);
    ctx.quadraticCurveTo(cx + 8, cy - 3, cx + 5.5, cy - 1.5);
    ctx.lineTo(cx + 3, cy - 4);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - 5, cy - 6);
    ctx.quadraticCurveTo(cx - 8, cy - 3, cx - 5.5, cy - 1.5);
    ctx.lineTo(cx - 3, cy - 4);
    ctx.fill();
  } else {
    ctx.lineWidth = 1.3;
    for (let k = -1; k <= 1; k++) {
      ctx.beginPath();
      for (let i = 0; i <= 8; i++) {
        const px = cx - 5.5 + (11 * i) / 8;
        const py = cy + k * 4 + Math.sin(i * 1.4) * 1.2;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
  }
  ctx.restore();
}

/* -------------------- castle -------------------- */
export function drawCastle(ctx: CanvasRenderingContext2D, team: Team, squash: number, hpFrac: number, t: number, flash: number) {
  const C = CASTLE[team];
  const tc = TEAM_COLORS[team];
  ctx.save();
  ctx.translate(C.cx, C.baseY);
  // shadow
  ctx.fillStyle = "rgba(15,10,5,0.35)";
  ctx.beginPath();
  ctx.ellipse(6, 4, 110, 26, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.scale(1 + squash * 0.07, 1 - squash * 0.09);
  if (team === 1) ctx.scale(-1, 1);

  const fl = flash > 0;
  const S = (s: string) => (fl ? "#fff6ea" : s);
  const stone = "#c3bcad";
  const stoneD = "#9a9385";
  const stoneDD = "#6f695e";
  const stoneL = "#ddd7ca";

  const merlons = (x0: number, x1: number, y: number, h: number, col: string) => {
    ctx.fillStyle = S(col);
    for (let x = x0; x < x1 - 2; x += 9) ctx.fillRect(x, y - h, 5.5, h);
  };

  const flag = (fx: number, fy: number, size: number) => {
    line(ctx, fx, fy, fx, fy - 26 * size, BLACK, 1.6);
    circle(ctx, fx, fy - 27 * size, 1.8 * size, HELM);
    const fw = 20 * size;
    const fh = 11 * size;
    ctx.fillStyle = S(tc.main);
    ctx.beginPath();
    const ftop = fy - 25 * size;
    const N = 6;
    for (let i = 0; i <= N; i++) {
      const xx = (fw * i) / N;
      const w = Math.sin(t * 5 + xx * 0.3 + fx) * xx * 0.08;
      if (i === 0) ctx.moveTo(fx + xx, ftop + w);
      else ctx.lineTo(fx + xx, ftop + w);
    }
    for (let i = N; i >= 0; i--) {
      const xx = (fw * i) / N;
      const w = Math.sin(t * 5 + xx * 0.3 + fx) * xx * 0.08;
      const notch = i === N ? -fh * 0.5 : 0;
      ctx.lineTo(fx + xx + notch * 0.6, ftop + fh + w + (i === N ? -fh * 0.5 + fh * 0.5 : 0));
    }
    ctx.closePath();
    ctx.fill();
  };

  const cone = (x: number, y: number, w: number, h: number) => {
    ctx.fillStyle = S(tc.main);
    ctx.beginPath();
    ctx.moveTo(x - w, y);
    ctx.lineTo(x, y - h);
    ctx.lineTo(x + w, y);
    ctx.quadraticCurveTo(x, y + 6, x - w, y);
    ctx.fill();
    ctx.fillStyle = S(tc.dark);
    ctx.beginPath();
    ctx.moveTo(x, y - h);
    ctx.lineTo(x + w, y);
    ctx.quadraticCurveTo(x + w * 0.5, y + 4.5, x + w * 0.15, y + 5.5);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = S("rgba(255,255,255,0.18)");
    ctx.beginPath();
    ctx.moveTo(x, y - h);
    ctx.lineTo(x - w * 0.55, y + 1);
    ctx.lineTo(x - w * 0.3, y + 2.5);
    ctx.closePath();
    ctx.fill();
  };

  // ---- keep (back) ----
  ctx.fillStyle = S(stoneD);
  ctx.fillRect(-34, -175, 68, 120);
  ctx.fillStyle = S(stone);
  ctx.fillRect(-34, -175, 46, 120);
  ctx.fillStyle = S(stoneL);
  ctx.fillRect(-34, -175, 68, 6);
  merlons(-34, 34, -175, 7, stone);
  // windows
  ctx.fillStyle = S("#2a231b");
  ctx.fillRect(-14, -150, 5, 11);
  ctx.fillRect(4, -150, 5, 11);
  ctx.fillRect(-5, -120, 6, 13);
  cone(0, -183, 40, 46);
  flag(0, -229, 1.15);

  // ---- side towers ----
  for (const tx of [-74, 74]) {
    ctx.fillStyle = S(stoneD);
    ctx.fillRect(tx - 18, -118, 36, 118);
    ctx.fillStyle = S(stone);
    ctx.fillRect(tx - 18, -118, 24, 118);
    ellipse(ctx, tx, 0, 18, 5, S(stoneDD));
    ctx.fillStyle = S(stoneL);
    ctx.fillRect(tx - 20, -122, 40, 7);
    merlons(tx - 20, tx + 20, -122, 6, stone);
    ctx.fillStyle = S("#2a231b");
    ctx.fillRect(tx - 3, -92, 5, 10);
    ctx.fillRect(tx - 3, -58, 5, 10);
    cone(tx, -128, 23, 36);
    flag(tx, -164, 0.8);
  }

  // ---- curtain wall (front) ----
  ctx.fillStyle = S(stone);
  ctx.fillRect(-56, -74, 112, 74);
  ctx.fillStyle = S(stoneD);
  ctx.fillRect(-56, -14, 112, 14);
  ctx.fillStyle = S(stoneL);
  ctx.fillRect(-58, -78, 116, 7);
  merlons(-58, 58, -78, 7, stoneL);
  // bricks
  if (!fl) {
    ctx.strokeStyle = "rgba(60,50,40,0.18)";
    ctx.lineWidth = 1;
    for (let row = 0; row < 5; row++) {
      const yy = -64 + row * 12;
      ctx.beginPath();
      ctx.moveTo(-56, yy);
      ctx.lineTo(56, yy);
      ctx.stroke();
      for (let xx = -56 + (row % 2) * 9; xx < 56; xx += 18) {
        ctx.beginPath();
        ctx.moveTo(xx, yy);
        ctx.lineTo(xx, yy + 12);
        ctx.stroke();
      }
    }
  }
  // gate
  ctx.fillStyle = S("#2a231b");
  ctx.beginPath();
  ctx.moveTo(-15, 0);
  ctx.lineTo(-15, -26);
  ctx.arc(0, -26, 15, Math.PI, 0);
  ctx.lineTo(15, 0);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = S("#77705f");
  ctx.lineWidth = 1.2;
  for (let gx = -10; gx <= 10; gx += 5) {
    ctx.beginPath();
    ctx.moveTo(gx, -36 + Math.abs(gx) * 0.3);
    ctx.lineTo(gx, -6);
    ctx.stroke();
  }
  for (let gy = -30; gy <= -8; gy += 7) {
    ctx.beginPath();
    ctx.moveTo(-13, gy);
    ctx.lineTo(13, gy);
    ctx.stroke();
  }
  // hanging banners
  for (const bx of [-38, 38]) {
    ctx.fillStyle = S(tc.main);
    ctx.beginPath();
    ctx.moveTo(bx - 7, -70);
    ctx.lineTo(bx + 7, -70);
    ctx.lineTo(bx + 7, -36);
    ctx.lineTo(bx, -42);
    ctx.lineTo(bx - 7, -36);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = S("#f6f1e6");
    circle(ctx, bx, -56, 3, S("#f6f1e6"));
    line(ctx, bx - 8, -70, bx + 8, -70, BLACK, 1.5);
  }

  // damage cracks
  if (hpFrac < 0.66 && !fl) {
    ctx.strokeStyle = "rgba(30,24,18,0.75)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-40, -74);
    ctx.lineTo(-34, -60);
    ctx.lineTo(-40, -50);
    ctx.lineTo(-32, -38);
    ctx.stroke();
    if (hpFrac < 0.4) {
      ctx.beginPath();
      ctx.moveTo(20, -175);
      ctx.lineTo(14, -160);
      ctx.lineTo(22, -148);
      ctx.lineTo(15, -130);
      ctx.moveTo(70, -118);
      ctx.lineTo(76, -100);
      ctx.lineTo(68, -88);
      ctx.stroke();
    }
  }
  ctx.restore();
}

/* -------------------- cannon -------------------- */
function drawCannon(ctx: CanvasRenderingContext2D, o: FigureOpts, c: (s: string) => string) {
  const tc = TEAM_COLORS[o.team];
  const rc = o.recoil ?? 0;
  const wheelRot = o.walk * 0.6;
  // crew member (loader) behind
  const step = o.moving ? Math.sin(o.walk) : 0;
  const cx = -13 - rc * 2;
  ctx.fillStyle = c(BLACK);
  ctx.fillRect(cx - 2 + step * 0.6, -3.5, 1.6, 3.5);
  ctx.fillRect(cx + 0.6 - step * 0.6, -3.5, 1.6, 3.5);
  ellipse(ctx, cx, -6.2, 3.3, 4, c(BLACK));
  ctx.fillStyle = c(tc.main);
  ctx.fillRect(cx - 3, -9.2, 6, 1.6);
  drawHead(ctx, cx + 0.3, -12, 3, { ...o, hero: undefined }, c);
  // rammer
  line(ctx, cx + 1, -6, cx + 9, o.moving ? -4 : -10, c(WOOD), 1.1);
  // carriage
  ctx.fillStyle = c("#7a5230");
  ctx.beginPath();
  ctx.moveTo(-10, -3);
  ctx.lineTo(6, -3);
  ctx.lineTo(4, -8);
  ctx.lineTo(-8, -6.5);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = c("#4e331c");
  ctx.fillRect(-10, -3.6, 16, 1.4);
  // barrel
  ctx.save();
  ctx.translate(-1 - rc * 3.5, -9);
  ctx.rotate(-0.2 - rc * 0.15);
  ctx.fillStyle = c("#2a2a2e");
  ctx.beginPath();
  ctx.moveTo(-7, -3);
  ctx.lineTo(13, -2.2);
  ctx.lineTo(13, 2.2);
  ctx.lineTo(-7, 3);
  ctx.quadraticCurveTo(-10, 0, -7, -3);
  ctx.fill();
  ctx.fillStyle = c("#45454b");
  ctx.fillRect(11, -3, 3, 6);
  ctx.fillRect(-1, -3.2, 1.6, 6.4);
  line(ctx, -5, -1.6, 10, -1.2, c("rgba(255,255,255,0.35)"), 0.9);
  ctx.restore();
  // wheel
  ctx.save();
  ctx.translate(-2, -4.5);
  circle(ctx, 0, 0, 4.8, c("#3b2a1a"));
  circle(ctx, 0, 0, 3.6, c("#9a6c3c"));
  ctx.rotate(wheelRot);
  for (let i = 0; i < 4; i++) {
    ctx.rotate(Math.PI / 4);
    line(ctx, -3.4, 0, 3.4, 0, c("#3b2a1a"), 0.9);
  }
  circle(ctx, 0, 0, 1.1, c("#3b2a1a"));
  ctx.restore();
  // team pennant
  line(ctx, -9, -6, -9, -16, c(BLACK), 0.9);
  ctx.fillStyle = c(tc.main);
  ctx.beginPath();
  ctx.moveTo(-9, -16);
  ctx.lineTo(-15, -14.5);
  ctx.lineTo(-9, -13);
  ctx.fill();
}

/* -------------------- decals -------------------- */
export function drawBloodDecal(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, seed: number, alpha: number, pool: boolean) {
  const rnd = mulberry32(Math.floor(seed * 1000));
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y);
  ctx.fillStyle = pool ? "#8e1616" : "#a51d1d";
  ctx.beginPath();
  ctx.ellipse(0, 0, r, r * 0.55, rnd() * 0.6 - 0.3, 0, Math.PI * 2);
  ctx.fill();
  const n = pool ? 5 : 3;
  for (let i = 0; i < n; i++) {
    const a = rnd() * Math.PI * 2;
    const d = r * (0.7 + rnd() * 0.8);
    const rr = r * (0.18 + rnd() * 0.3);
    ctx.beginPath();
    ctx.ellipse(Math.cos(a) * d, Math.sin(a) * d * 0.55, rr, rr * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  if (pool) {
    ctx.fillStyle = "#6e0f0f";
    ctx.beginPath();
    ctx.ellipse(-r * 0.1, 0, r * 0.55, r * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.beginPath();
    ctx.ellipse(-r * 0.35, -r * 0.15, r * 0.18, r * 0.07, -0.3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawCrater(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, alpha: number) {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = "rgba(60,48,30,0.55)";
  ctx.beginPath();
  ctx.ellipse(x, y, r * 1.5, r * 0.75, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#6b5232";
  ctx.beginPath();
  ctx.ellipse(x, y, r, r * 0.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#3e2f1c";
  ctx.beginPath();
  ctx.ellipse(x, y + 1, r * 0.6, r * 0.3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* -------------------- background (sunny meadow) -------------------- */
const LEAF = ["#5f9a45", "#6ea94f", "#4f8a3a"];
const LEAF_HI = ["#86c264", "#93cd6d", "#76b558"];
const GOLD = ["#d9b45a", "#e2c16b", "#c99f45"];
const GOLD_HI = ["#f0d68a", "#f5df9c", "#e5c574"];

function drawTree(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, rnd: () => number) {
  const golden = rnd() < 0.28;
  const k = Math.floor(rnd() * 3);
  const main = golden ? GOLD[k] : LEAF[k];
  const hi = golden ? GOLD_HI[k] : LEAF_HI[k];
  const dark = golden ? "#a9813a" : "#3f7430";
  ctx.fillStyle = "rgba(30,50,15,0.32)";
  ctx.beginPath();
  ctx.ellipse(x + 10 * s, y + 3 * s, 28 * s, 9 * s, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#6b4a2c";
  ctx.fillRect(x - 2.5 * s, y - 15 * s, 5 * s, 16 * s);
  ctx.fillStyle = "#553a22";
  ctx.fillRect(x + 0.5 * s, y - 15 * s, 2 * s, 16 * s);
  const blobs: [number, number, number][] = [];
  const n = 5 + Math.floor(rnd() * 4);
  for (let i = 0; i < n; i++) blobs.push([(rnd() - 0.5) * 34 * s, -26 * s - rnd() * 16 * s, (9 + rnd() * 8) * s]);
  blobs.forEach(([bx, by, r]) => circle(ctx, x + bx + 2.5 * s, y + by + 3.5 * s, r, dark));
  blobs.forEach(([bx, by, r]) => circle(ctx, x + bx, y + by, r, main));
  blobs.forEach(([bx, by, r]) => circle(ctx, x + bx - r * 0.3, y + by - r * 0.35, r * 0.5, hi));
  if (!golden && rnd() < 0.35) {
    // tiny fruits / blossoms
    for (let i = 0; i < 5; i++) {
      const b = blobs[Math.floor(rnd() * blobs.length)];
      circle(ctx, x + b[0] + (rnd() - 0.5) * b[2], y + b[1] + (rnd() - 0.5) * b[2], 1.4 * s, rnd() < 0.5 ? "#ff8f8f" : "#fff2f2");
    }
  }
}

function drawBush(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, rnd: () => number) {
  ctx.fillStyle = "rgba(30,50,15,0.3)";
  ctx.beginPath();
  ctx.ellipse(x + 4 * s, y + 2 * s, 15 * s, 5 * s, 0, 0, Math.PI * 2);
  ctx.fill();
  const bl: [number, number, number][] = [];
  for (let i = 0; i < 4; i++) bl.push([(rnd() - 0.5) * 16 * s, -4 * s - rnd() * 5 * s, (5 + rnd() * 4) * s]);
  bl.forEach(([bx, by, r]) => circle(ctx, x + bx + 1.5, y + by + 2, r, "#3f7430"));
  bl.forEach(([bx, by, r]) => circle(ctx, x + bx, y + by, r, "#5a9640"));
  bl.forEach(([bx, by, r]) => circle(ctx, x + bx - r * 0.3, y + by - r * 0.35, r * 0.45, "#7fbb5c"));
  if (rnd() < 0.5) for (let i = 0; i < 3; i++) circle(ctx, x + (rnd() - 0.5) * 14 * s, y - rnd() * 8 * s, 1.2, "#fff6b0");
}

function drawRock(ctx: CanvasRenderingContext2D, x: number, y: number, s: number) {
  ellipse(ctx, x + 2 * s, y + 1, 7 * s, 2.5 * s, "rgba(30,50,15,0.3)");
  ctx.fillStyle = "#9b978c";
  ctx.beginPath();
  ctx.moveTo(x - 6 * s, y);
  ctx.lineTo(x - 4 * s, y - 5 * s);
  ctx.lineTo(x + 1 * s, y - 7 * s);
  ctx.lineTo(x + 6 * s, y - 3 * s);
  ctx.lineTo(x + 6 * s, y);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#c4c0b4";
  ctx.beginPath();
  ctx.moveTo(x - 4 * s, y - 5 * s);
  ctx.lineTo(x + 1 * s, y - 7 * s);
  ctx.lineTo(x + 2 * s, y - 3 * s);
  ctx.lineTo(x - 3 * s, y - 2 * s);
  ctx.closePath();
  ctx.fill();
}

function drawFence(ctx: CanvasRenderingContext2D, x0: number, y: number, n: number) {
  for (let i = 0; i < n; i++) {
    const x = x0 + i * 14;
    ellipse(ctx, x + 2, y + 1, 3, 1.2, "rgba(30,50,15,0.3)");
    ctx.fillStyle = "#8a6038";
    ctx.fillRect(x - 1.5, y - 12, 3, 12);
    ctx.fillStyle = "#a87a4a";
    ctx.fillRect(x - 1.5, y - 12, 1.2, 12);
  }
  ctx.fillStyle = "#9a6c3c";
  ctx.fillRect(x0 - 2, y - 10, (n - 1) * 14 + 4, 2);
  ctx.fillRect(x0 - 2, y - 5, (n - 1) * 14 + 4, 2);
}

export function roadY(x: number) {
  return 452 + Math.sin(x * 0.006) * 18 + Math.sin(x * 0.017 + 1) * 6;
}

export function buildBackground(seed = 7) {
  const SC = 2;
  const bg = document.createElement("canvas");
  bg.width = W * SC;
  bg.height = H * SC;
  const ctx = bg.getContext("2d")!;
  ctx.scale(SC, SC);
  const rnd = mulberry32(seed);

  // grass base
  const base = ctx.createLinearGradient(0, 0, 0, H);
  base.addColorStop(0, "#8cb65a");
  base.addColorStop(1, "#7aa64c");
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 55; i++) {
    const x = rnd() * W;
    const y = rnd() * H;
    const r = 60 + rnd() * 180;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    const light = rnd() > 0.5;
    g.addColorStop(0, light ? "rgba(178,212,110,0.35)" : "rgba(86,128,52,0.3)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  // river along the top
  ctx.fillStyle = "#d9c48e";
  ctx.beginPath();
  ctx.moveTo(0, 0);
  for (let x = 0; x <= W; x += 20) ctx.lineTo(x, 52 + Math.sin(x * 0.01) * 10 + Math.sin(x * 0.033) * 4);
  ctx.lineTo(W, 0);
  ctx.closePath();
  ctx.fill();
  const water = ctx.createLinearGradient(0, 0, 0, 50);
  water.addColorStop(0, "#5aa7cf");
  water.addColorStop(1, "#7cc3e0");
  ctx.fillStyle = water;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  for (let x = 0; x <= W; x += 20) ctx.lineTo(x, 42 + Math.sin(x * 0.01) * 10 + Math.sin(x * 0.033) * 4);
  ctx.lineTo(W, 0);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.55)";
  ctx.lineWidth = 1.5;
  ctx.lineCap = "round";
  for (let i = 0; i < 70; i++) {
    const x = rnd() * W;
    const y = 6 + rnd() * 28;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + 5, y - 2, x + 10 + rnd() * 8, y);
    ctx.stroke();
  }

  // dirt road between the castles
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  const roadPath = () => {
    ctx.beginPath();
    for (let x = 0; x <= W; x += 10) {
      const y = roadY(x);
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
  };
  roadPath();
  ctx.strokeStyle = "#b99c63";
  ctx.lineWidth = 54;
  ctx.stroke();
  roadPath();
  ctx.strokeStyle = "#d8bf88";
  ctx.lineWidth = 46;
  ctx.stroke();
  ctx.strokeStyle = "rgba(170,140,90,0.45)";
  ctx.lineWidth = 2;
  for (const off of [-9, 9]) {
    ctx.beginPath();
    for (let x = 0; x <= W; x += 10) {
      const y = roadY(x) + off;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  for (let i = 0; i < 160; i++) {
    const x = rnd() * W;
    ellipse(ctx, x, roadY(x) + (rnd() - 0.5) * 38, 1 + rnd() * 1.6, 0.7 + rnd(), rnd() < 0.5 ? "#c3a771" : "#ead7a8");
  }

  // grass tufts
  for (let i = 0; i < 2200; i++) {
    const x = rnd() * W;
    const y = 60 + rnd() * (H - 60);
    if (Math.abs(y - roadY(x)) < 26) continue;
    const dark = rnd() > 0.45;
    ctx.strokeStyle = dark ? "rgba(84,128,52,0.9)" : "rgba(176,214,118,0.85)";
    ctx.lineWidth = 1.1;
    const n = 2 + Math.floor(rnd() * 3);
    ctx.beginPath();
    for (let k = 0; k < n; k++) {
      const dx = (k - n / 2) * 1.8;
      ctx.moveTo(x + dx, y);
      ctx.lineTo(x + dx * 1.8 + (rnd() - 0.5), y - 3 - rnd() * 3);
    }
    ctx.stroke();
  }
  // flowers
  const fc = ["#ffffff", "#ffe066", "#ff9ec4", "#c9a0ff", "#ff7b6b", "#ffffff"];
  for (let i = 0; i < 260; i++) {
    const x = rnd() * W;
    const y = 70 + rnd() * (H - 70);
    if (Math.abs(y - roadY(x)) < 28) continue;
    const col = fc[Math.floor(rnd() * fc.length)];
    const n = 2 + Math.floor(rnd() * 5);
    for (let k = 0; k < n; k++) {
      const fx = x + (rnd() - 0.5) * 16;
      const fy = y + (rnd() - 0.5) * 8;
      line(ctx, fx, fy + 2, fx, fy, "rgba(70,110,40,0.8)", 0.8);
      circle(ctx, fx, fy, 1.5, col);
      circle(ctx, fx, fy, 0.6, "#ffd23a");
    }
  }
  // rocks and bushes
  for (let i = 0; i < 22; i++) {
    const x = rnd() * W;
    const y = FIELD_TOP + rnd() * (FIELD_BOTTOM - FIELD_TOP);
    if (Math.abs(y - roadY(x)) < 30) continue;
    drawRock(ctx, x, y, 0.6 + rnd() * 0.7);
  }
  for (let i = 0; i < 20; i++) {
    const x = 240 + rnd() * (W - 480);
    const y = FIELD_TOP + rnd() * (FIELD_BOTTOM - FIELD_TOP);
    if (Math.abs(y - roadY(x)) < 34) continue;
    drawBush(ctx, x, y, 0.7 + rnd() * 0.5, rnd);
  }
  // fences by the castles
  drawFence(ctx, 22, 640, 13);
  drawFence(ctx, W - 200, 640, 13);
  drawFence(ctx, 22, 300, 6);
  drawFence(ctx, W - 100, 300, 6);

  // top tree line
  const trees: [number, number, number][] = [];
  for (let i = 0; i < 30; i++) trees.push([rnd() * W, 62 + rnd() * 48, 0.75 + rnd() * 0.6]);
  trees.sort((a, b) => a[1] - b[1]).forEach(([x, y, s]) => drawTree(ctx, x, y, s, rnd));

  // castle ground patches (packed earth)
  for (const C of CASTLE) {
    const g = ctx.createRadialGradient(C.cx, C.baseY - 30, 10, C.cx, C.baseY - 30, 150);
    g.addColorStop(0, "rgba(200,175,120,0.55)");
    g.addColorStop(1, "rgba(200,175,120,0)");
    ctx.fillStyle = g;
    ctx.fillRect(C.cx - 150, C.baseY - 180, 300, 300);
  }

  // foreground
  const fg = document.createElement("canvas");
  fg.width = W * SC;
  fg.height = H * SC;
  const fctx = fg.getContext("2d")!;
  fctx.scale(SC, SC);
  const ft: [number, number, number][] = [];
  for (let i = 0; i < 24; i++) ft.push([rnd() * W, FIELD_BOTTOM + 45 + rnd() * 110, 0.9 + rnd() * 0.8]);
  ft.sort((a, b) => a[1] - b[1]).forEach(([x, y, s]) => drawTree(fctx, x, y, s, rnd));
  // warm sunlight + soft vignette
  const sun = fctx.createLinearGradient(0, 0, W, H);
  sun.addColorStop(0, "rgba(255,238,180,0.20)");
  sun.addColorStop(0.5, "rgba(255,238,180,0.0)");
  sun.addColorStop(1, "rgba(40,60,90,0.10)");
  fctx.fillStyle = sun;
  fctx.fillRect(0, 0, W, H);
  const vg = fctx.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, H * 1.05);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(25,35,15,0.32)");
  fctx.fillStyle = vg;
  fctx.fillRect(0, 0, W, H);

  return { bg, fg };
}

export function buildCloudShadow() {
  const cv = document.createElement("canvas");
  cv.width = 520;
  cv.height = 300;
  const ctx = cv.getContext("2d")!;
  const rnd = mulberry32(99);
  for (let i = 0; i < 9; i++) {
    const x = 120 + rnd() * 280;
    const y = 90 + rnd() * 120;
    const r = 60 + rnd() * 70;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, "rgba(20,40,30,0.10)");
    g.addColorStop(1, "rgba(20,40,30,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 520, 300);
  }
  return cv;
}
