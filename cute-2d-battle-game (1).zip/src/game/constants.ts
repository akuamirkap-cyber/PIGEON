export const W = 1600;
export const H = 900;

export const FIELD_TOP = 120;
export const FIELD_BOTTOM = 760;

export const SQUAD_SIZE = 20;

export type Team = 0 | 1; // 0 = player (left, red), 1 = enemy (right, blue)
export type UnitType = "sword" | "spear" | "archer" | "cavalry" | "hero" | "cannon";
export type SquadType = "sword" | "spear" | "archer" | "cavalry";

export type HeroKind =
  | "renold"
  | "toralf"
  | "swiftbow"
  | "brian"
  | "olaf"
  | "edward"
  | "carl";

export interface UnitDef {
  type: UnitType;
  name: string;
  desc: string;
  hp: number;
  atk: number;
  cd: number;
  range: number;
  speed: number;
  aggro: number;
  cost: number;
  radius: number;
  ranged?: boolean;
  key: string;
}

export const UNIT_DEFS: Record<SquadType, UnitDef> = {
  sword: {
    type: "sword",
    name: "Pedang",
    desc: "Unggul vs Tombak",
    hp: 34,
    atk: 7,
    cd: 0.8,
    range: 11,
    speed: 36,
    aggro: 80,
    cost: 60,
    radius: 4,
    key: "1",
  },
  spear: {
    type: "spear",
    name: "Tombak",
    desc: "Unggul vs Kavaleri",
    hp: 30,
    atk: 8,
    cd: 1.0,
    range: 19,
    speed: 34,
    aggro: 80,
    cost: 75,
    radius: 4,
    key: "2",
  },
  archer: {
    type: "archer",
    name: "Pemanah",
    desc: "Unggul vs Pedang",
    hp: 18,
    atk: 6,
    cd: 1.5,
    range: 230,
    speed: 32,
    aggro: 250,
    cost: 90,
    radius: 4,
    ranged: true,
    key: "3",
  },
  cavalry: {
    type: "cavalry",
    name: "Kavaleri",
    desc: "Unggul vs Pemanah",
    hp: 60,
    atk: 10,
    cd: 0.9,
    range: 13,
    speed: 64,
    aggro: 110,
    cost: 140,
    radius: 6.5,
    key: "4",
  },
};

/** Cannon: a single siege piece with crew. Slow, long range, splash, crushes castles. */
export const CANNON_DEF = {
  name: "Meriam",
  desc: "Ledakan area & penghancur istana",
  hp: 140,
  atk: 24,
  cd: 5.2,
  range: 400,
  minRange: 45,
  speed: 17,
  aggro: 420,
  radius: 9,
  splash: 38,
  castleMult: 3,
  cost: 170,
  max: 3,
  key: "5",
};

export interface HeroDef {
  kind: HeroKind;
  name: string;
  title: string;
  hp: number;
  atk: number;
  cd: number;
  range: number;
  speed: number;
  aggro: number;
  radius: number;
  cleave: number; // radius of splash damage, 0 = none
  ranged?: boolean;
  mounted?: boolean;
  cooldown: number;
  key: string;
}

export const HERO_DEFS: Record<HeroKind, HeroDef> = {
  renold: {
    kind: "renold",
    name: "Lord Renold",
    title: "Ksatria Kuda Putih",
    hp: 420,
    atk: 26,
    cd: 0.9,
    range: 16,
    speed: 70,
    aggro: 160,
    radius: 8,
    cleave: 14,
    mounted: true,
    cooldown: 30,
    key: "Q",
  },
  toralf: {
    kind: "toralf",
    name: "Toralf the Strong",
    title: "Kapak Raksasa",
    hp: 520,
    atk: 30,
    cd: 1.1,
    range: 14,
    speed: 38,
    aggro: 130,
    radius: 6,
    cleave: 26,
    cooldown: 30,
    key: "W",
  },
  swiftbow: {
    kind: "swiftbow",
    name: "John Swiftbow",
    title: "Panah Kilat",
    hp: 260,
    atk: 16,
    cd: 0.45,
    range: 300,
    speed: 40,
    aggro: 320,
    radius: 5,
    cleave: 0,
    ranged: true,
    cooldown: 30,
    key: "E",
  },
  brian: {
    kind: "brian",
    name: "Brian Mackendrick",
    title: "Pedang Besar",
    hp: 460,
    atk: 34,
    cd: 1.2,
    range: 18,
    speed: 40,
    aggro: 130,
    radius: 6,
    cleave: 30,
    cooldown: 30,
    key: "R",
  },
  olaf: {
    kind: "olaf",
    name: "Olaf the Furious",
    title: "Kapak Kembar",
    hp: 480,
    atk: 26,
    cd: 0.7,
    range: 14,
    speed: 44,
    aggro: 130,
    radius: 6,
    cleave: 20,
    cooldown: 50,
    key: "",
  },
  edward: {
    kind: "edward",
    name: "Edward the Throneless",
    title: "Raja Tanpa Takhta",
    hp: 500,
    atk: 26,
    cd: 0.9,
    range: 14,
    speed: 40,
    aggro: 130,
    radius: 6,
    cleave: 18,
    cooldown: 50,
    key: "",
  },
  carl: {
    kind: "carl",
    name: "Sir Carl of Hammerhill",
    title: "Palu Bukit",
    hp: 540,
    atk: 28,
    cd: 1.0,
    range: 15,
    speed: 38,
    aggro: 130,
    radius: 6,
    cleave: 24,
    cooldown: 50,
    key: "",
  },
};

export const PLAYER_HEROES: HeroKind[] = ["renold", "toralf", "swiftbow", "brian"];
export const ENEMY_HEROES: HeroKind[] = ["olaf", "edward", "carl"];

export const TEAM_COLORS = [
  { main: "#c8323a", dark: "#8a1f25", light: "#e5555b", horse: "#5e3d2a" },
  { main: "#3f66c4", dark: "#263f80", light: "#6f92e6", horse: "#3d342e" },
];

export const CASTLE = [
  { cx: 115, baseY: 555, hw: 78, top: 330 },
  { cx: W - 115, baseY: 555, hw: 78, top: 330 },
];

export const ZONES = [
  { x0: 215, x1: 620 },
  { x0: W - 620, x1: W - 215 },
];

export const CASTLE_HP = 3000;
export const GOLD_MAX = 800;
export const GOLD_START = 300;
export const WAVE_TIME = 10;
export const WAVE_INCOME = 160;
export const WAVE_INCOME_GROWTH = 8; // per wave
export const WAVE_INCOME_MAX = 260;
export const KILL_BOUNTY = 1;
export const HERO_COST = 150;

/** Damage multiplier: COUNTER[attacker][defender] */
export const COUNTER: Record<string, Partial<Record<string, number>>> = {
  sword: { spear: 1.6, cannon: 1.6 },
  spear: { cavalry: 2.4, hero: 1.3 },
  cavalry: { archer: 2.3, cannon: 2.6 },
  archer: { sword: 1.5, spear: 1.15 },
};

export const TYPE_ICON: Record<string, string> = {
  sword: "🗡️",
  spear: "🔱",
  archer: "🏹",
  cavalry: "🐎",
  hero: "⭐",
  cannon: "💣",
};
export const TYPE_NAME: Record<string, string> = {
  sword: "Pedang",
  spear: "Tombak",
  archer: "Pemanah",
  cavalry: "Kavaleri",
  hero: "Hero",
  cannon: "Meriam",
};

export type Difficulty = "easy" | "normal" | "hard";
export const DIFF_MULT: Record<Difficulty, number> = {
  easy: 0.75,
  normal: 1.0,
  hard: 1.3,
};
