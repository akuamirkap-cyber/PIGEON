class Sfx {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  dry: GainNode | null = null;
  wet: GainNode | null = null;
  muted = false;
  last: Record<string, number> = {};
  noiseBuf: AudioBuffer | null = null;
  windGain: GainNode | null = null;
  ambientOn = false;

  ensure() {
    if (!this.ctx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const c = new AC();
        this.ctx = c;
        this.master = c.createGain();
        this.master.gain.value = 0.55;
        // gentle compressor so big battles don't clip
        const comp = c.createDynamicsCompressor();
        comp.threshold.value = -16;
        comp.ratio.value = 4;
        this.master.connect(comp);
        comp.connect(c.destination);
        this.dry = c.createGain();
        this.dry.connect(this.master);
        // reverb (generated impulse response) – gives an open-field echo
        const conv = c.createConvolver();
        const len = Math.floor(c.sampleRate * 1.6);
        const ir = c.createBuffer(2, len, c.sampleRate);
        for (let ch = 0; ch < 2; ch++) {
          const d = ir.getChannelData(ch);
          for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
        }
        conv.buffer = ir;
        this.wet = c.createGain();
        this.wet.gain.value = 0.22;
        this.wet.connect(conv);
        conv.connect(this.master);
        const nlen = c.sampleRate * 2;
        this.noiseBuf = c.createBuffer(1, nlen, c.sampleRate);
        const nd = this.noiseBuf.getChannelData(0);
        for (let i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;
      } catch {
        this.ctx = null;
      }
    }
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.05);
  }

  private gate(name: string, minGap: number) {
    if (this.muted || !this.ctx || !this.master) return false;
    const now = this.ctx.currentTime;
    if (this.last[name] && now - this.last[name] < minGap) return false;
    this.last[name] = now;
    return true;
  }

  private out(node: AudioNode, wet = 0.5) {
    node.connect(this.dry!);
    if (wet > 0) {
      const g = this.ctx!.createGain();
      g.gain.value = wet;
      node.connect(g);
      g.connect(this.wet!);
    }
  }

  private tone(freq0: number, freq1: number, dur: number, vol: number, type: OscillatorType = "sine", delay = 0, wet = 0.3) {
    const c = this.ctx!;
    const t = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, freq1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    this.out(g, wet);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, freq: number, q = 1.5, type: BiquadFilterType = "bandpass", delay = 0, freqEnd?: number, wet = 0.3) {
    const c = this.ctx!;
    const t = c.currentTime + delay;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    s.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = c.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f);
    f.connect(g);
    this.out(g, wet);
    s.start(t, Math.random() * 1.5);
    s.stop(t + dur + 0.05);
  }

  /* ---------------- combat ---------------- */
  clang() {
    if (!this.gate("clang", 0.045)) return;
    const f = 950 + Math.random() * 700;
    const parts: [number, number, number][] = [
      [1, 0.22, 0.03],
      [2.76, 0.16, 0.022],
      [5.4, 0.1, 0.014],
      [8.93, 0.06, 0.008],
    ];
    for (const [r, d, v] of parts) this.tone(f * r, f * r * 0.995, d, v, "sine", 0, 0.6);
    this.noise(0.03, 0.08, 5000, 1, "highpass");
  }
  thud() {
    if (!this.gate("thud", 0.05)) return;
    this.noise(0.09, 0.14, 500, 0.8, "lowpass", 0, 200, 0.15);
    this.tone(140 + Math.random() * 40, 55, 0.1, 0.09, "sine", 0, 0.1);
  }
  hit() {
    if (Math.random() < 0.55) this.clang();
    else this.thud();
  }
  block() {
    if (!this.gate("block", 0.06)) return;
    this.tone(320, 190, 0.07, 0.07, "triangle", 0, 0.3);
    this.noise(0.05, 0.08, 900, 2);
  }
  splat() {
    if (!this.gate("splat", 0.07)) return;
    this.noise(0.08, 0.07, 700, 1.2, "lowpass", 0, 180, 0.1);
  }
  bow() {
    if (!this.gate("bow", 0.08)) return;
    this.tone(220, 180, 0.05, 0.04, "triangle", 0, 0.1);
    this.noise(0.28, 0.05, 2600, 2, "bandpass", 0.02, 700, 0.3);
  }
  volley() {
    if (!this.gate("volley", 0.5)) return;
    this.noise(0.55, 0.1, 3000, 1.2, "bandpass", 0, 600, 0.4);
    for (let i = 0; i < 4; i++) this.tone(200 + Math.random() * 60, 160, 0.05, 0.03, "triangle", i * 0.03, 0.1);
  }
  thunk() {
    if (!this.gate("thunk", 0.06)) return;
    this.tone(500, 200, 0.04, 0.03, "square", 0, 0.1);
  }
  die() {
    if (!this.gate("die", 0.07)) return;
    const f = 420 + Math.random() * 160;
    this.tone(f, f * 0.45, 0.16, 0.05, "triangle", 0, 0.2);
  }
  cannon() {
    if (!this.gate("cannon", 0.15)) return;
    this.tone(110, 28, 0.7, 0.45, "sine", 0, 0.6);
    this.noise(0.9, 0.35, 900, 0.7, "lowpass", 0, 120, 0.7);
    this.noise(0.06, 0.25, 3000, 0.8, "highpass", 0, undefined, 0.3);
  }
  explosion() {
    if (!this.gate("expl", 0.1)) return;
    this.tone(80, 22, 0.8, 0.4, "sine", 0, 0.6);
    this.noise(1.1, 0.35, 700, 0.6, "lowpass", 0, 90, 0.8);
    this.noise(0.25, 0.12, 2500, 1, "bandpass", 0.03, 600, 0.4);
  }
  castle() {
    if (!this.gate("castle", 0.12)) return;
    this.tone(150, 45, 0.3, 0.22, "sine", 0, 0.5);
    this.noise(0.25, 0.12, 400, 0.8, "lowpass", 0, 120, 0.5);
    this.noise(0.12, 0.05, 2500, 1.5, "bandpass", 0.04);
  }
  impact() {
    if (!this.gate("impact", 0.12)) return;
    this.tone(100, 40, 0.25, 0.25, "sine", 0, 0.4);
    this.noise(0.2, 0.18, 600, 0.7, "lowpass", 0, 150, 0.4);
    for (let i = 0; i < 3; i++) this.clangDelayed(i * 0.03 + Math.random() * 0.03);
  }
  private clangDelayed(d: number) {
    const f = 900 + Math.random() * 800;
    this.tone(f, f, 0.15, 0.02, "sine", d, 0.6);
    this.tone(f * 2.76, f * 2.76, 0.1, 0.012, "sine", d, 0.6);
  }
  battleCry(team: number) {
    if (!this.gate("cry" + team, 1.5)) return;
    const c = this.ctx!;
    const t = c.currentTime;
    const base = team === 0 ? 170 : 150;
    const f1 = c.createBiquadFilter();
    f1.type = "bandpass";
    f1.frequency.setValueAtTime(600, t);
    f1.frequency.linearRampToValueAtTime(850, t + 0.5);
    f1.Q.value = 2.5;
    const f2 = c.createBiquadFilter();
    f2.type = "bandpass";
    f2.frequency.value = 1150;
    f2.Q.value = 3;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.18, t + 0.18);
    g.gain.setValueAtTime(0.18, t + 0.7);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
    f1.connect(g);
    f2.connect(g);
    this.out(g, 0.8);
    for (let i = 0; i < 9; i++) {
      const o = c.createOscillator();
      o.type = "sawtooth";
      const f = base * (0.85 + Math.random() * 0.4);
      o.frequency.setValueAtTime(f * 0.9, t);
      o.frequency.linearRampToValueAtTime(f * 1.15, t + 0.35);
      o.frequency.linearRampToValueAtTime(f * 0.95, t + 1.5);
      const og = c.createGain();
      og.gain.value = 0.25;
      o.connect(og);
      og.connect(f1);
      og.connect(f2);
      o.start(t + Math.random() * 0.12);
      o.stop(t + 1.7);
    }
    this.noise(1.4, 0.05, 1200, 0.8, "bandpass", 0, 800, 0.6);
  }
  gallop() {
    if (!this.gate("gallop", 0.6)) return;
    for (let i = 0; i < 4; i++) this.tone(130 + Math.random() * 30, 60, 0.06, 0.06, "sine", i * 0.09 + (i > 1 ? 0.08 : 0), 0.1);
  }

  /* ---------------- ui / events ---------------- */
  pop() {
    if (!this.gate("pop", 0.035)) return;
    const f = 520 + Math.random() * 260;
    this.tone(f, f * 1.7, 0.07, 0.06, "sine", 0, 0.1);
  }
  deploy() {
    if (!this.gate("deploy", 0.1)) return;
    this.tone(330, 660, 0.12, 0.08, "triangle", 0, 0.2);
    this.tone(495, 990, 0.12, 0.06, "triangle", 0.08, 0.2);
    this.noise(0.08, 0.06, 300, 1, "lowpass", 0.02);
  }
  coin() {
    if (!this.gate("coin", 0.3)) return;
    [1318, 1760, 2093].forEach((f, i) => this.tone(f, f, 0.18, 0.05, "triangle", i * 0.06, 0.4));
  }
  hero() {
    if (!this.gate("hero", 0.3)) return;
    [392, 523, 659, 784].forEach((f, i) => this.tone(f, f, 0.22, 0.08, "triangle", i * 0.07, 0.5));
  }
  error() {
    if (!this.gate("err", 0.2)) return;
    this.tone(220, 150, 0.15, 0.07, "square", 0, 0.1);
  }
  click() {
    if (!this.gate("click", 0.03)) return;
    this.tone(700, 1050, 0.05, 0.06, "sine", 0, 0.1);
    this.noise(0.02, 0.04, 3000, 1, "highpass");
  }
  horn() {
    if (!this.gate("horn", 1)) return;
    const c = this.ctx!;
    const t = c.currentTime;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 1100;
    this.out(f, 1);
    const notes: [number, number, number][] = [
      [146.8, 0, 0.32],
      [196, 0.28, 0.28],
      [220, 0.52, 1.0],
    ];
    for (const [freq, d, dur] of notes) {
      for (const det of [-3, 0, 4]) {
        const o = c.createOscillator();
        const g = c.createGain();
        o.type = "sawtooth";
        o.frequency.value = freq + det * 0.35;
        g.gain.setValueAtTime(0.0001, t + d);
        g.gain.exponentialRampToValueAtTime(0.07, t + d + 0.06);
        g.gain.setValueAtTime(0.07, t + d + dur - 0.12);
        g.gain.exponentialRampToValueAtTime(0.0001, t + d + dur);
        o.connect(g);
        g.connect(f);
        o.start(t + d);
        o.stop(t + d + dur + 0.05);
      }
    }
  }
  drum() {
    if (!this.gate("drum", 0.2)) return;
    this.tone(105, 48, 0.22, 0.22, "sine", 0, 0.5);
    this.noise(0.06, 0.06, 220, 1, "lowpass");
  }
  tick() {
    if (!this.gate("tick", 0.3)) return;
    this.tone(1300, 1300, 0.05, 0.05, "square", 0, 0.2);
    this.tone(650, 650, 0.08, 0.04, "triangle", 0, 0.2);
  }
  win() {
    if (!this.gate("win", 1)) return;
    [523, 659, 784, 1046, 784, 1046].forEach((f, i) => this.tone(f, f, 0.3, 0.09, "triangle", i * 0.12, 0.6));
  }
  lose() {
    if (!this.gate("lose", 1)) return;
    [392, 349, 311, 262].forEach((f, i) => this.tone(f, f * 0.98, 0.4, 0.09, "triangle", i * 0.22, 0.6));
  }

  /* ---------------- ambience ---------------- */
  startAmbient() {
    if (!this.ctx || this.ambientOn) return;
    this.ambientOn = true;
    const c = this.ctx;
    const s = c.createBufferSource();
    s.buffer = this.noiseBuf;
    s.loop = true;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 380;
    const g = c.createGain();
    g.gain.value = 0.035;
    this.windGain = g;
    s.connect(f);
    f.connect(g);
    g.connect(this.master!);
    s.start();
  }
  ambientTick(dt: number) {
    if (!this.ctx || this.muted || !this.ambientOn) return;
    if (this.windGain) this.windGain.gain.setTargetAtTime(0.025 + Math.sin(this.ctx.currentTime * 0.4) * 0.015, this.ctx.currentTime, 0.5);
    if (Math.random() < dt * 0.35) {
      // a little bird chirp
      const base = 2600 + Math.random() * 1400;
      const n = 2 + Math.floor(Math.random() * 3);
      for (let i = 0; i < n; i++) {
        const d = i * (0.09 + Math.random() * 0.04);
        this.tone(base, base * (1.2 + Math.random() * 0.3), 0.06, 0.012, "sine", d, 0.5);
      }
    }
  }
}

export const sfx = new Sfx();
