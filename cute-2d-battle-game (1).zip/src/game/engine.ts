import {
  CANNON_DEF,
  CASTLE,
  CASTLE_HP,
  DIFF_MULT,
  ENEMY_HEROES,
  FIELD_BOTTOM,
  FIELD_TOP,
  COUNTER,
  GOLD_MAX,
  GOLD_START,
  HERO_COST,
  KILL_BOUNTY,
  TYPE_NAME,
  WAVE_INCOME,
  WAVE_INCOME_GROWTH,
  WAVE_INCOME_MAX,
  WAVE_TIME,
  H,
  HERO_DEFS,
  PLAYER_HEROES,
  SQUAD_SIZE,
  TEAM_COLORS,
  UNIT_DEFS,
  W,
  ZONES,
} from "./constants";
import type { Difficulty, HeroKind, SquadType, Team, UnitType } from "./constants";
import type { Corpse, Decal, FloatText, Particle, Projectile, Squad, StuckArrow, Unit } from "./types";
import { buildBackground, buildCloudShadow, drawBanner, drawBloodDecal, drawCastle, drawCorpse, drawCrater, drawFigure, drawShadow, easeOutBack, easeOutElastic } from "./draw";
import { sfx } from "./audio";

type Pt = { x: number; y: number };
export type BasicType = SquadType;
export type GameState = "menu" | "playing" | "paused" | "won" | "lost";

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

interface CastleState {
  hp: number;
  squash: number;
  sv: number;
  flash: number;
  shootCd: number;
  smokeT: number;
}

export interface GameEvent {
  type: "nogold" | "deploy" | "end" | "hero" | "cooldown" | "launch" | "tick" | "refund";
}

interface AiAction {
  at: number; // phaseT value (counting down) at which to act
  kind: "plan" | "react" | "final";
  ref?: Squad;
}

const CELL = 40;
const US = 1.3; // global unit scale
const GCOLS = Math.ceil(W / CELL);
const GROWS = Math.ceil(H / CELL);

export class Game {
  units: Unit[] = [];
  squads: Squad[] = [];
  corpses: Corpse[] = [];
  particles: Particle[] = [];
  projectiles: Projectile[] = [];
  stuck: StuckArrow[] = [];
  texts: FloatText[] = [];
  castles: CastleState[] = [];
  gold = [GOLD_START, GOLD_START];
  time = 0;
  state: GameState = "menu";
  selected: BasicType = "sword";
  pendingHero: HeroKind | null = null;
  heroCd: Record<string, number> = {};
  drawing: Pt[] | null = null;
  mouse: Pt & { inside: boolean } = { x: 0, y: 0, inside: false };
  shake = 0;
  diff: Difficulty = "normal";
  stats = { deployed: 0, kills: 0, lost: 0, squads: 0, fled: 0, spent: 0 };
  events: GameEvent[] = [];
  aiActions: AiAction[] = [];
  aiSeen = new Set<number>();
  phaseT = WAVE_TIME;
  wave = 1;
  launchFx = 0;
  marchDrumT = 0;
  lastIncome = [0, 0];
  nextId = 1;
  grid: Unit[][] = [];
  bg: HTMLCanvasElement;
  fg: HTMLCanvasElement;
  endT = 0;
  hint = 1;
  decals: Decal[] = [];
  blood = true;
  pendingCannon = false;
  cloudImg: HTMLCanvasElement;
  clouds: { x: number; y: number; s: number; v: number }[] = [];
  birds: { x: number; y: number; vx: number; n: number; t: number }[] = [];
  birdT = 4;
  zoomPunch = 0;

  constructor() {
    const { bg, fg } = buildBackground(11);
    this.bg = bg;
    this.fg = fg;
    this.cloudImg = buildCloudShadow();
    for (let i = 0; i < 4; i++) this.clouds.push({ x: rand(-300, W), y: rand(60, H - 250), s: rand(1.1, 1.8), v: rand(8, 14) });
    for (let i = 0; i < GCOLS * GROWS; i++) this.grid.push([]);
    this.reset("normal");
    this.state = "menu";
    // ambient demo armies for the menu backdrop
    this.spawnDemo();
  }

  reset(diff: Difficulty) {
    this.diff = diff;
    this.units = [];
    this.squads = [];
    this.corpses = [];
    this.particles = [];
    this.projectiles = [];
    this.stuck = [];
    this.texts = [];
    this.decals = [];
    this.pendingCannon = false;
    this.castles = [0, 1].map(() => ({ hp: CASTLE_HP, squash: 0, sv: 0, flash: 0, shootCd: 0, smokeT: 0 }));
    this.gold = [GOLD_START, GOLD_START];
    this.time = 0;
    this.stats = { deployed: 0, kills: 0, lost: 0, squads: 0, fled: 0, spent: 0 };
    this.heroCd = {};
    PLAYER_HEROES.forEach((h) => (this.heroCd[h] = 10));
    this.phaseT = WAVE_TIME;
    this.wave = 1;
    this.aiSeen = new Set();
    this.aiActions = [];
    this.gold = [GOLD_START, Math.round(GOLD_START * DIFF_MULT[diff])];
    this.lastIncome = [0, 0];
    this.planAI();
    this.drawing = null;
    this.pendingHero = null;
    this.endT = 0;
    this.hint = 1;
  }

  spawnDemo() {
    const shapes: [Team, BasicType, Pt[]][] = [
      [0, "sword", this.linePts(380, 300, 470, 420)],
      [0, "spear", this.linePts(330, 470, 450, 600)],
      [1, "sword", this.linePts(1200, 300, 1120, 440)],
      [1, "archer", this.linePts(1260, 480, 1260, 640)],
    ];
    shapes.forEach(([t, ty, p]) => this.spawnSquad(t, ty, p, true));
    this.squads.forEach((s) => {
      if (s.state === "ready") {
        s.state = "march";
        s.launchT = 0;
      }
    });
  }

  linePts(x0: number, y0: number, x1: number, y1: number): Pt[] {
    return [
      { x: x0, y: y0 },
      { x: x1, y: y1 },
    ];
  }

  start(diff: Difficulty) {
    this.reset(diff);
    this.state = "playing";
    sfx.deploy();
  }

  /* ------------------------------------------------------------ */
  /*  Formation sampling                                          */
  /* ------------------------------------------------------------ */
  samplePath(pts: Pt[], team: Team, type: UnitType): Pt[] {
    const n = SQUAD_SIZE;
    const Z = ZONES[team];
    const cl = (p: Pt) => ({ x: clamp(p.x, Z.x0, Z.x1), y: clamp(p.y, FIELD_TOP + 10, FIELD_BOTTOM - 10) });
    let total = 0;
    const segs: number[] = [];
    for (let i = 1; i < pts.length; i++) {
      const d = Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
      segs.push(d);
      total += d;
    }
    const out: Pt[] = [];
    if (total < 26) {
      // compact block
      const c = pts[pts.length - 1];
      const sp = (type === "cavalry" ? 16 : 12) * US;
      const cols = 4;
      const rows = 5;
      for (let i = 0; i < n; i++) {
        const cx = i % cols;
        const ry = Math.floor(i / cols);
        out.push(cl({ x: c.x + (cx - (cols - 1) / 2) * sp + (ry % 2) * 3, y: c.y + (ry - (rows - 1) / 2) * sp }));
      }
      return out;
    }
    for (let i = 0; i < n; i++) {
      let target = (total * i) / (n - 1);
      let k = 0;
      while (k < segs.length - 1 && target > segs[k]) {
        target -= segs[k];
        k++;
      }
      const a = pts[k];
      const b = pts[k + 1] ?? pts[k];
      const t = segs[k] > 0 ? clamp(target / segs[k], 0, 1) : 0;
      out.push(cl({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }));
    }
    return out;
  }

  /* ------------------------------------------------------------ */
  /*  Spawning                                                    */
  /* ------------------------------------------------------------ */
  makeUnit(team: Team, type: UnitType, x: number, y: number, squad: Squad, delay: number, hero?: HeroKind): Unit {
    let hp, atk, cd, range, speed, aggro, radius, cleave = 0, ranged = false, scale = 1;
    if (type === "cannon") {
      const d = CANNON_DEF;
      ({ hp, atk, cd, range, speed, aggro } = d);
      radius = 7;
      ranged = true;
      scale = US;
    } else if (hero) {
      const d = HERO_DEFS[hero];
      ({ hp, atk, cd, range, speed, aggro, radius, cleave } = d);
      ranged = !!d.ranged;
      scale = 1.5 * US;
    } else {
      const d = UNIT_DEFS[type as BasicType];
      ({ hp, atk, cd, range, speed, aggro, radius } = d);
      ranged = !!d.ranged;
      scale = US;
    }
    radius *= US;
    speed *= rand(0.94, 1.06);
    return {
      id: this.nextId++,
      team,
      type,
      hero,
      x,
      y,
      vx: 0,
      vy: 0,
      hp,
      maxHp: hp,
      atk,
      cd,
      cdT: rand(0, cd),
      range,
      speed,
      aggro,
      radius,
      cleave,
      ranged,
      facing: team === 0 ? 1 : -1,
      walk: rand(0, 6),
      spawnT: -delay,
      hitT: 0,
      atkT: 0,
      showHpT: 0,
      target: null,
      attackingCastle: false,
      retarget: rand(0, 0.2),
      squad,
      offX: 0,
      offY: 0,
      dead: false,
      chargeDist: 0,
      scale,
      seed: Math.random() * 100,
      shootDelay: -1,
      fleeing: false,
      cheerT: 0,
      charged: false,
      recoil: 0,
      flyZ: 0,
      flyV: 0,
    };
  }

  spawnSquad(team: Team, type: BasicType, path: Pt[], silent = false) {
    const pts = this.samplePath(path, team, type);
    const cx = pts.reduce((s, p) => s + p.x, 0) / pts.length;
    const cy = pts.reduce((s, p) => s + p.y, 0) / pts.length;
    const sq: Squad = {
      id: this.nextId++,
      team,
      type,
      anchorX: cx,
      anchorY: cy,
      units: [],
      bannerX: cx,
      bannerY: cy,
      speed: UNIT_DEFS[type].speed,
      spawnT: 0,
      dead: false,
      deadT: 0,
      engaged: 0,
      alive: SQUAD_SIZE,
      state: "ready",
      walk: 0,
      volleyCd: 0,
      volleyWant: false,
      initial: SQUAD_SIZE,
      launchT: 0,
      cost: UNIT_DEFS[type].cost,
      charging: false,
      chargeCheck: 0,
    };
    pts.forEach((p, i) => {
      const u = this.makeUnit(team, type, p.x, p.y, sq, silent ? 0 : i * 0.03);
      u.offX = p.x - cx;
      u.offY = p.y - cy;
      sq.units.push(u);
      this.units.push(u);
    });
    this.squads.push(sq);
    if (!silent) {
      this.ring(cx, cy, TEAM_COLORS[team].light, 60);
      if (team === 0) {
        sfx.deploy();
        this.stats.deployed += SQUAD_SIZE;
        this.stats.squads++;
      }
    }
  }

  spawnHero(team: Team, kind: HeroKind, x: number, y: number) {
    const Z = ZONES[team];
    x = clamp(x, Z.x0, Z.x1);
    y = clamp(y, FIELD_TOP + 10, FIELD_BOTTOM - 10);
    const sq: Squad = {
      id: this.nextId++,
      team,
      type: "hero",
      hero: kind,
      anchorX: x,
      anchorY: y,
      units: [],
      bannerX: x,
      bannerY: y,
      speed: HERO_DEFS[kind].speed,
      spawnT: 0,
      dead: false,
      deadT: 0,
      engaged: 0,
      alive: 1,
      state: "ready",
      walk: 0,
      volleyCd: 0,
      volleyWant: false,
      initial: 1,
      launchT: 0,
      cost: HERO_COST,
      charging: false,
      chargeCheck: 0,
    };
    const u = this.makeUnit(team, "hero", x, y, sq, 0, kind);
    sq.units.push(u);
    this.units.push(u);
    this.squads.push(sq);
    this.ring(x, y, "#f2c23a", 80);
    this.ring(x, y, "#fff3c4", 50);
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2;
      this.particles.push(this.mkP(x, y, 4, Math.cos(a) * 90, Math.sin(a) * 45, rand(40, 90), "star", "#f2c23a", 0.8, rand(2, 3.5)));
    }
    this.shake = Math.max(this.shake, 6);
    this.text(x, y - 40, HERO_DEFS[kind].name + "!", "#f6d36b", 1.6, 18);
    sfx.hero();
  }

  /* ------------------------------------------------------------ */
  /*  Particles helpers                                           */
  /* ------------------------------------------------------------ */
  cannonCount(team: Team) {
    return this.units.filter((u) => u.team === team && u.type === "cannon").length;
  }

  spawnCannon(team: Team, x: number, y: number) {
    const Z = ZONES[team];
    x = clamp(x, Z.x0, Z.x1);
    y = clamp(y, FIELD_TOP + 10, FIELD_BOTTOM - 10);
    const sq: Squad = {
      id: this.nextId++,
      team,
      type: "cannon",
      anchorX: x,
      anchorY: y,
      units: [],
      bannerX: x,
      bannerY: y,
      speed: CANNON_DEF.speed,
      spawnT: 0,
      dead: false,
      deadT: 0,
      engaged: 0,
      alive: 1,
      state: "ready",
      walk: 0,
      volleyCd: 0,
      volleyWant: false,
      initial: 1,
      launchT: 0,
      cost: CANNON_DEF.cost,
      charging: false,
      chargeCheck: 0,
    };
    const u = this.makeUnit(team, "cannon", x, y, sq, 0);
    sq.units.push(u);
    this.units.push(u);
    this.squads.push(sq);
    this.ring(x, y, TEAM_COLORS[team].light, 50);
    this.dust(x, y, 8, 40);
    this.shake = Math.max(this.shake, 3);
    sfx.deploy();
  }

  mkP(x: number, y: number, z: number, vx: number, vy: number, vz: number, kind: Particle["kind"], color: string, life: number, size: number): Particle {
    return { x, y, z, vx, vy, vz, life, max: life, size, color, kind, rot: rand(0, 6), vr: rand(-10, 10) };
  }
  ring(x: number, y: number, color: string, size: number) {
    this.particles.push(this.mkP(x, y, 0, 0, 0, 0, "ring", color, 0.5, size));
  }
  dust(x: number, y: number, n: number, spread = 30) {
    for (let i = 0; i < n; i++) {
      this.particles.push(this.mkP(x + rand(-3, 3), y + rand(-2, 2), 1, rand(-spread, spread), rand(-spread, spread) * 0.4, rand(5, 20), "dust", "rgba(170,150,115,", rand(0.4, 0.8), rand(2, 4)));
    }
  }
  text(x: number, y: number, text: string, color: string, max = 1, size = 14) {
    this.texts.push({ x, y, text, color, t: 0, max, size });
  }

  /* ------------------------------------------------------------ */
  /*  Input                                                       */
  /* ------------------------------------------------------------ */
  inZone(x: number, y: number) {
    const Z = ZONES[0];
    return x >= Z.x0 - 30 && x <= Z.x1 + 30 && y >= FIELD_TOP - 20 && y <= FIELD_BOTTOM + 20;
  }

  pointerDown(x: number, y: number, button: number) {
    if (this.state !== "playing") return;
    sfx.ensure();
    if (button === 2) {
      if (this.drawing || this.pendingHero || this.pendingCannon) {
        this.drawing = null;
        this.pendingHero = null;
        this.pendingCannon = false;
        return;
      }
      this.tryRefund(x, y);
      return;
    }
    if (this.pendingCannon) {
      if (!this.inZone(x, y)) {
        this.text(x, y - 10, "Di luar zona!", "#ffb3a8", 0.9, 13);
        sfx.error();
        return;
      }
      if (this.gold[0] < CANNON_DEF.cost) {
        this.text(x, y - 14, "Emas kurang!", "#ffcf5a", 1, 15);
        sfx.error();
        this.events.push({ type: "nogold" });
        return;
      }
      if (this.cannonCount(0) >= CANNON_DEF.max) {
        this.text(x, y - 14, "Maks " + CANNON_DEF.max + " meriam!", "#ffcf5a", 1, 15);
        sfx.error();
        return;
      }
      this.gold[0] -= CANNON_DEF.cost;
      this.stats.spent += CANNON_DEF.cost;
      this.spawnCannon(0, x, y);
      if (this.gold[0] < CANNON_DEF.cost || this.cannonCount(0) >= CANNON_DEF.max) this.pendingCannon = false;
      this.events.push({ type: "deploy" });
      return;
    }
    if (this.pendingHero) {
      if (this.inZone(x, y)) {
        const h = this.pendingHero;
        if (this.gold[0] < HERO_COST) {
          this.text(x, y - 14, "Emas kurang!", "#ffcf5a", 1, 15);
          sfx.error();
          this.events.push({ type: "nogold" });
          return;
        }
        this.gold[0] -= HERO_COST;
        this.stats.spent += HERO_COST;
        this.spawnHero(0, h, x, y);
        this.heroCd[h] = HERO_DEFS[h].cooldown;
        this.pendingHero = null;
        this.events.push({ type: "hero" });
      } else {
        this.text(x, y - 10, "Di luar zona!", "#ffb3a8", 0.9, 13);
        sfx.error();
      }
      return;
    }
    if (!this.inZone(x, y)) {
      this.text(x, y - 10, "Gambar di zona merah!", "#ffb3a8", 0.9, 13);
      sfx.error();
      return;
    }
    this.drawing = [{ x, y }];
  }

  /** Right-click on one of your own READY squads to cancel it and get a full refund. */
  tryRefund(x: number, y: number) {
    let best: Squad | null = null;
    let bd = 22 * 22;
    for (const sq of this.squads) {
      if (sq.team !== 0 || sq.state !== "ready" || sq.dead) continue;
      for (const u of sq.units) {
        if (u.dead) continue;
        const d = (u.x - x) ** 2 + (u.y - y) ** 2;
        if (d < bd) {
          bd = d;
          best = sq;
        }
      }
    }
    if (!best) return;
    const sq = best;
    const refund = sq.cost;
    this.gold[0] = Math.min(GOLD_MAX, this.gold[0] + refund);
    this.stats.spent -= refund;
    if (sq.type !== "hero" && sq.type !== "cannon") this.stats.squads--;
    else if (sq.hero) this.heroCd[sq.hero] = 0;
    for (const u of sq.units) {
      if (u.dead) continue;
      u.dead = true;
      this.dust(u.x, u.y, 2, 20);
    }
    this.units = this.units.filter((u) => !u.dead);
    this.squads = this.squads.filter((s) => s !== sq);
    this.text(sq.bannerX, sq.bannerY - 50, "+" + refund + " emas (batal)", "#ffe08a", 1.2, 14);
    sfx.click();
    this.events.push({ type: "refund" });
  }

  pointerMove(x: number, y: number) {
    this.mouse.x = x;
    this.mouse.y = y;
    this.mouse.inside = true;
    if (this.drawing) {
      const last = this.drawing[this.drawing.length - 1];
      if (Math.hypot(x - last.x, y - last.y) > 5) this.drawing.push({ x, y });
    }
  }

  pointerUp() {
    if (!this.drawing) return;
    const path = this.drawing;
    this.drawing = null;
    const cost = UNIT_DEFS[this.selected].cost;
    if (this.gold[0] < cost) {
      const p = path[path.length - 1];
      this.text(p.x, p.y - 14, "Emas kurang!", "#ffcf5a", 1, 15);
      sfx.error();
      this.events.push({ type: "nogold" });
      return;
    }
    this.gold[0] -= cost;
    this.stats.spent += cost;
    this.spawnSquad(0, this.selected, path);
    this.hint = 0;
    this.events.push({ type: "deploy" });
  }

  selectCannon() {
    if (this.cannonCount(0) >= CANNON_DEF.max) {
      sfx.error();
      this.text(this.mouse.x, this.mouse.y - 14, "Maks " + CANNON_DEF.max + " meriam!", "#ffcf5a", 1, 14);
      return;
    }
    this.pendingCannon = !this.pendingCannon;
    this.pendingHero = null;
    sfx.click();
  }

  selectHero(h: HeroKind) {
    this.pendingCannon = false;
    if ((this.heroCd[h] ?? 0) > 0) {
      sfx.error();
      this.events.push({ type: "cooldown" });
      return;
    }
    this.pendingHero = this.pendingHero === h ? null : h;
    sfx.click();
  }

  /* ------------------------------------------------------------ */
  /*  Waves                                                       */
  /* ------------------------------------------------------------ */
  income() {
    return Math.min(WAVE_INCOME_MAX, WAVE_INCOME + (this.wave - 1) * WAVE_INCOME_GROWTH);
  }

  launchWave() {
    let n = 0;
    for (const sq of this.squads) {
      if (sq.state !== "ready" || sq.dead) continue;
      sq.state = "march";
      sq.launchT = 0;
      n++;
      this.ring(sq.bannerX, sq.bannerY, TEAM_COLORS[sq.team].light, 50);
      for (const u of sq.units) u.cheerT = 1 + Math.random() * 0.5;
    }
    const inc = this.income();
    const m = DIFF_MULT[this.diff];
    this.lastIncome = [inc, Math.round(inc * m)];
    this.gold[0] = Math.min(GOLD_MAX, this.gold[0] + inc);
    this.gold[1] = Math.min(GOLD_MAX, this.gold[1] + inc * m);
    this.wave++;
    this.phaseT = WAVE_TIME;
    this.planAI();
    this.marchDrumT = n > 0 ? 4.5 : 0;
    this.launchFx = 1;
    this.shake = Math.max(this.shake, n > 0 ? 5 : 2);
    sfx.horn();
    sfx.coin();
    if (n > 0) {
      setTimeout(() => sfx.battleCry(0), 700);
      setTimeout(() => sfx.battleCry(1), 950);
    }
    this.zoomPunch = 1;
    this.events.push({ type: "launch" });
  }

  readyCounts(team: Team) {
    const c: Record<string, number> = { sword: 0, spear: 0, archer: 0, cavalry: 0, hero: 0, cannon: 0 };
    for (const sq of this.squads) if (sq.team === team && sq.state === "ready" && !sq.dead) c[sq.type]++;
    return c;
  }

  /* ------------------------------------------------------------ */
  /*  AI — it watches your preparation and answers it             */
  /* ------------------------------------------------------------ */
  aiHeroCd = 25;

  planAI() {
    const m = DIFF_MULT[this.diff];
    this.aiActions = [
      { at: WAVE_TIME - rand(0.8, 2.0), kind: "plan" },
      { at: rand(4.8, 6.2), kind: "plan" },
      { at: m >= 1.2 ? rand(0.5, 0.9) : rand(1.0, 1.8), kind: "final" },
    ];
  }

  counterOf(t: UnitType): BasicType {
    switch (t) {
      case "sword":
        return "archer";
      case "spear":
        return "sword";
      case "archer":
        return "cavalry";
      case "cavalry":
        return "spear";
      case "cannon":
        return "cavalry";
      default:
        return "spear";
    }
  }

  aiPlace(type: BasicType, laneY: number, reason?: string): boolean {
    const cost = UNIT_DEFS[type].cost;
    if (this.gold[1] < cost) return false;
    const Z = ZONES[1];
    const y = clamp(laneY, FIELD_TOP + 95, FIELD_BOTTOM - 95);
    let path: Pt[];
    const r = Math.random();
    if (type === "spear") {
      const x = Z.x0 + rand(30, 100);
      path =
        r < 0.6
          ? [
              { x, y: y - 95 },
              { x, y: y + 95 },
            ]
          : [
              { x: x + 40, y: y - 85 },
              { x: x - 25, y },
              { x: x + 40, y: y + 85 },
            ];
    } else if (type === "sword") {
      const x = Z.x0 + rand(40, 130);
      if (r < 0.45)
        path = [
          { x: x + 55, y: y - 85 },
          { x: x - 45, y },
          { x: x + 55, y: y + 85 },
        ];
      else if (r < 0.75)
        path = [
          { x, y: y - 90 },
          { x, y: y + 90 },
        ];
      else
        path = [
          { x: x - 90, y },
          { x: x + 90, y },
        ];
    } else if (type === "archer") {
      const x = Z.x1 - rand(30, 110);
      path = [];
      for (let i = 0; i <= 8; i++) {
        const a = -1.0 + (2.0 * i) / 8;
        path.push({ x: x - Math.cos(a) * 40 + 40, y: y + Math.sin(a) * 100 });
      }
    } else {
      const x = rand(Z.x0 + 120, Z.x1 - 60);
      path =
        r < 0.5
          ? [
              { x: x - 80, y },
              { x: x + 80, y },
            ]
          : [
              { x: x - 50, y: y - 70 },
              { x: x + 50, y: y + 70 },
            ];
    }
    this.gold[1] -= cost;
    this.spawnSquad(1, type, path);
    if (reason) {
      const c = path.reduce((a, p) => ({ x: a.x + p.x / path.length, y: a.y + p.y / path.length }), { x: 0, y: 0 });
      this.text(c.x, c.y - 60, reason, "#bcd2ff", 2.2, 14);
    }
    return true;
  }

  aiLane(): number {
    const mine = this.squads.filter((s) => s.team === 0 && !s.dead);
    if (mine.length && Math.random() < 0.7) {
      const s = mine[Math.floor(Math.random() * mine.length)];
      return s.anchorY + rand(-40, 40);
    }
    return [270, 440, 610][Math.floor(Math.random() * 3)] + rand(-40, 40);
  }

  aiPickType(): { type: BasicType; reason?: string } {
    const m = DIFF_MULT[this.diff];
    const cnt: Record<string, number> = { sword: 0, spear: 0, archer: 0, cavalry: 0, hero: 0, cannon: 0 };
    for (const u of this.units) if (u.team === 0) cnt[u.type] += 1;
    let top = "sword";
    for (const k in cnt) if (cnt[k] > cnt[top]) top = k;
    if (cnt[top] > 8 && Math.random() < Math.min(0.9, 0.55 * m)) {
      const t = this.counterOf(top as UnitType);
      return { type: t, reason: `${TYPE_NAME[t]} vs ${TYPE_NAME[top]}` };
    }
    // balanced army: front line first, then support
    const mineReady = this.readyCounts(1);
    if (mineReady.sword + mineReady.spear === 0) return { type: Math.random() < 0.6 ? "sword" : "spear" };
    if (mineReady.archer === 0 && Math.random() < 0.7) return { type: "archer" };
    const opts: BasicType[] = ["sword", "spear", "archer", "cavalry"];
    return { type: opts[Math.floor(Math.random() * 4)] };
  }

  updateAI(dt: number) {
    const m = DIFF_MULT[this.diff];
    this.aiHeroCd -= dt;
    // watch the player's preparation
    for (const sq of this.squads) {
      if (sq.team !== 0 || sq.state !== "ready" || this.aiSeen.has(sq.id)) continue;
      this.aiSeen.add(sq.id);
      if (Math.random() > 0.35 + 0.45 * m) continue; // easy AI sometimes doesn't notice
      const at = this.phaseT - rand(0.7, 2.0) / m;
      if (at > 0.25) this.aiActions.push({ at, kind: "react", ref: sq });
    }
    const due = this.aiActions.filter((a) => a.at >= this.phaseT);
    if (!due.length) return;
    this.aiActions = this.aiActions.filter((a) => a.at < this.phaseT);
    for (const a of due) {
      if (a.kind === "react" && a.ref) {
        const ref = a.ref;
        if (ref.dead || ref.state !== "ready") continue;
        const t = this.counterOf(ref.type);
        this.aiPlace(t, ref.anchorY + rand(-20, 20), `${TYPE_NAME[t]} menangkal ${TYPE_NAME[ref.type]}!`);
      } else if (a.kind === "plan") {
        const reserve = m >= 1.2 ? 0.35 : 0.15;
        if (this.gold[1] * (1 - reserve) < 60) continue;
        if (this.wave > 1 && this.gold[1] >= CANNON_DEF.cost && this.cannonCount(1) < CANNON_DEF.max && Math.random() < 0.18 + 0.12 * m) {
          this.gold[1] -= CANNON_DEF.cost;
          const cx = rand(ZONES[1].x1 - 90, ZONES[1].x1 - 20);
          const cy = clamp(this.aiLane(), FIELD_TOP + 95, FIELD_BOTTOM - 95);
          this.spawnCannon(1, cx, cy);
          this.text(cx, cy - 40, "Meriam disiapkan!", "#bcd2ff", 2, 14);
          continue;
        }
        const pick = this.aiPickType();
        this.aiPlace(pick.type, this.aiLane(), pick.reason);
      } else {
        // final: hero or spend the rest
        if (this.aiHeroCd <= 0 && this.gold[1] >= HERO_COST && Math.random() < 0.55) {
          const h = ENEMY_HEROES[Math.floor(Math.random() * ENEMY_HEROES.length)];
          this.gold[1] -= HERO_COST;
          this.spawnHero(1, h, rand(ZONES[1].x0 + 60, ZONES[1].x1 - 40), this.aiLane());
          this.aiHeroCd = rand(35, 50) / m;
        }
        if (this.gold[1] >= CANNON_DEF.cost && this.cannonCount(1) < CANNON_DEF.max && Math.random() < 0.22 + 0.1 * m) {
          this.gold[1] -= CANNON_DEF.cost;
          const cx = rand(ZONES[1].x1 - 90, ZONES[1].x1 - 20);
          const cy = this.aiLane();
          this.spawnCannon(1, cx, cy);
          this.text(cx, clamp(cy, FIELD_TOP + 95, FIELD_BOTTOM - 95) - 40, "Meriam disiapkan!", "#bcd2ff", 2, 14);
        }
        const keep = m < 0.9 ? this.gold[1] * 0.4 : 0;
        let guard = 0;
        while (this.gold[1] - keep >= 60 && guard++ < 4) {
          const pick = this.aiPickType();
          if (!this.aiPlace(pick.type, this.aiLane(), pick.reason)) {
            if (!this.aiPlace("sword", this.aiLane())) break;
          }
        }
      }
    }
  }

  /* ------------------------------------------------------------ */
  /*  Combat                                                      */
  /* ------------------------------------------------------------ */
  castleDist(u: Unit, team: number) {
    const C = CASTLE[team];
    const nx = clamp(u.x, C.cx - C.hw, C.cx + C.hw);
    const ny = clamp(u.y, C.top + 60, C.baseY);
    return { d: Math.hypot(u.x - nx, u.y - ny), nx, ny };
  }

  hasShield(u: Unit) {
    return u.type === "sword" || u.type === "spear" || u.type === "cavalry" || u.hero === "edward" || u.hero === "carl" || u.hero === "renold";
  }

  bleed(x: number, y: number, z: number, n: number, dirX: number, power = 1) {
    if (!this.blood) return;
    for (let i = 0; i < n; i++) {
      this.particles.push(
        this.mkP(x, y, z, (rand(-35, 35) + dirX * 45) * power, rand(-18, 18) * power, rand(40, 110) * power, "blood", Math.random() < 0.5 ? "#c42828" : "#9e1b1b", 1.2, rand(1, 2))
      );
    }
  }

  damage(t: Unit, dmg: number, from: { x: number; y: number }, kb = 2, melee = false) {
    if (t.dead) return;
    const dx = t.x - from.x;
    const dy = t.y - from.y;
    const d = Math.hypot(dx, dy) || 1;
    const nx = dx / d;
    // shield block
    if (melee && this.hasShield(t) && Math.random() < 0.22) {
      dmg *= 0.5;
      for (let i = 0; i < 4; i++) {
        this.particles.push(this.mkP(t.x - nx * 3, t.y, 7 * t.scale, rand(-70, 70) - nx * 30, rand(-30, 30), rand(40, 90), "spark", "#ffe9a0", 0.22, 2));
      }
      sfx.block();
      kb *= 0.5;
    }
    t.hp -= dmg;
    t.hitT = 1;
    t.showHpT = 1.6;
    t.x += nx * kb;
    t.y += (dy / d) * kb * 0.6;
    for (let i = 0; i < 2; i++) {
      this.particles.push(this.mkP(t.x, t.y, 8 * t.scale, rand(-50, 50) + nx * 40, rand(-25, 25), rand(30, 70), "spark", "#fff4d6", 0.22, 2));
    }
    if (melee) {
      const p = this.mkP(t.x - nx * 2, t.y, 8 * t.scale, 0, 0, 0, "slash", "#ffffff", 0.18, 9 * t.scale);
      p.rot = Math.atan2(dy, dx) + rand(-0.6, 0.6);
      this.particles.push(p);
    }
    if (t.type === "cannon") {
      for (let i = 0; i < 3; i++) this.particles.push(this.mkP(t.x, t.y, 6, rand(-50, 50), rand(-20, 20), rand(40, 90), "debris", "#7a5230", 0.9, 2));
    } else this.bleed(t.x, t.y, 8 * t.scale, 2, nx, 1);
    if (t.hero) this.text(t.x + rand(-6, 6), t.y - 30, "-" + Math.round(dmg), "#ffd0c4", 0.7, 12);
    if (t.hp <= 0) this.kill(t);
  }

  explode(x: number, y: number, team: number, dmg: number, radius: number) {
    // splash damage that launches tiny soldiers into the air
    for (const o of this.units) {
      if (o.dead || o.team === team || o.spawnT < 0) continue;
      const dx = o.x - x;
      const dy = (o.y - y) * 1.3;
      const d = Math.hypot(dx, dy);
      if (d > radius) continue;
      const k = 1 - (d / radius) * 0.6;
      const mult = this.counterMult("cannon" as UnitType, o.type) * (o.hero ? 0.6 : 1);
      if (o.type !== "hero" && o.type !== "cannon") {
        o.flyV = Math.max(o.flyV, rand(70, 150) * k);
        o.flyZ = Math.max(o.flyZ, 0.1);
      }
      this.damage(o, dmg * k * mult, { x, y }, 10 * k);
    }
    this.decals.push({ x, y, r: 9, t: 0, kind: "crater", rot: 0, seed: Math.random() });
    for (let i = 0; i < 16; i++) {
      this.particles.push(this.mkP(x, y, 2, rand(-120, 120), rand(-60, 60), rand(80, 220), "dirt", Math.random() < 0.5 ? "#6b5232" : "#8a6c44", rand(0.8, 1.4), rand(1.5, 3.2)));
    }
    for (let i = 0; i < 8; i++) {
      this.particles.push(this.mkP(x + rand(-10, 10), y + rand(-5, 5), rand(4, 20), rand(-25, 25), rand(-10, 10), rand(10, 40), "smoke", "", rand(1.2, 2.2), rand(8, 14)));
    }
    this.particles.push(this.mkP(x, y, 6, 0, 0, 0, "flash", "#fff3c0", 0.22, radius * 0.9));
    this.ring(x, y, "rgba(255,240,200,0.9)", radius * 1.6);
    this.shake = Math.max(this.shake, 7);
    sfx.explosion();
  }

  kill(u: Unit) {
    u.dead = true;
    this.corpses.push({ x: u.x, y: u.y, team: u.team, type: u.type, hero: u.hero, facing: u.facing, t: 0, scale: u.scale });
    if (this.corpses.length > 420) this.corpses.shift();
    // helmet pop
    this.particles.push(this.mkP(u.x, u.y, 12 * u.scale, rand(-40, 40), rand(-20, 20), rand(70, 120), "helmet", "#c9c7c2", 1.6, 2.6 * u.scale));
    this.dust(u.x, u.y, 4, 25);
    for (let i = 0; i < 3; i++) {
      this.particles.push(this.mkP(u.x, u.y, 8, rand(-40, 40), rand(-20, 20), rand(40, 80), "star", TEAM_COLORS[u.team].light, 0.5, 2));
    }
    if (u.type === "cannon") {
      this.explode(u.x, u.y, u.team, 0, 1);
    } else if (this.blood) {
      this.bleed(u.x, u.y, 9 * u.scale, 6, u.facing * -1, 1.3);
      this.decals.push({ x: u.x + rand(-2, 2), y: u.y + 1, r: (u.type === "cavalry" ? 9 : 6) * u.scale, t: 0, kind: "pool", rot: 0, seed: Math.random() });
      sfx.splat();
    }
    if (this.decals.length > 500) this.decals.splice(0, this.decals.length - 500);
    sfx.die();
    if (u.team === 1) this.stats.kills++;
    else this.stats.lost++;
    if (u.hero) {
      this.shake = Math.max(this.shake, 8);
      this.text(u.x, u.y - 40, HERO_DEFS[u.hero].name + " gugur!", "#ffffff", 1.6, 15);
      this.ring(u.x, u.y, "#ffffff", 70);
    }
    // war spoils for the side that scored the kill
    const k = 1 - u.team;
    this.gold[k] = Math.min(GOLD_MAX, this.gold[k] + KILL_BOUNTY * (u.hero ? 25 : 1));
  }

  hitCastle(team: number, dmg: number, x: number, y: number) {
    const c = this.castles[team];
    if (c.hp <= 0) return;
    c.hp = Math.max(0, c.hp - dmg);
    c.sv += 0.9;
    c.flash = 0.06;
    for (let i = 0; i < 2; i++) {
      this.particles.push(this.mkP(x, y, rand(5, 30), rand(-60, 60), rand(-30, 30), rand(40, 110), "debris", Math.random() < 0.5 ? "#c3bcad" : "#8a8377", 1.2, rand(1.5, 3)));
    }
    if (Math.random() < 0.15) this.text(x + rand(-10, 10), y - rand(30, 60), "-" + Math.round(dmg), "#ffe0a8", 0.8, 13);
    this.shake = Math.max(this.shake, team === 0 ? 3.5 : 2);
    sfx.castle();
    if (c.hp <= 0) this.castleDestroyed(team);
  }

  castleDestroyed(team: number) {
    const C = CASTLE[team];
    this.shake = 22;
    for (let i = 0; i < 90; i++) {
      this.particles.push(this.mkP(C.cx + rand(-80, 80), C.baseY - rand(0, 30), rand(10, 140), rand(-160, 160), rand(-80, 80), rand(60, 260), "debris", ["#c3bcad", "#8a8377", TEAM_COLORS[team].main][i % 3], rand(1.5, 2.6), rand(2, 5)));
    }
    for (let i = 0; i < 30; i++) {
      this.particles.push(this.mkP(C.cx + rand(-80, 80), C.baseY - rand(0, 40), rand(10, 100), rand(-30, 30), rand(-15, 15), rand(10, 40), "smoke", "", rand(1.5, 3), rand(10, 22)));
    }
    this.ring(C.cx, C.baseY - 60, "#fff", 200);
    this.state = team === 1 ? "won" : "lost";
    this.endT = 0;
    if (team === 1) sfx.win();
    else sfx.lose();
    this.events.push({ type: "end" });
  }

  buildGrid() {
    for (const cell of this.grid) cell.length = 0;
    for (const u of this.units) {
      if (u.dead || u.spawnT < 0) continue;
      const cx = clamp(Math.floor(u.x / CELL), 0, GCOLS - 1);
      const cy = clamp(Math.floor(u.y / CELL), 0, GROWS - 1);
      this.grid[cy * GCOLS + cx].push(u);
    }
  }

  findTarget(u: Unit): Unit | null {
    const r = u.aggro;
    const c0 = clamp(Math.floor((u.x - r) / CELL), 0, GCOLS - 1);
    const c1 = clamp(Math.floor((u.x + r) / CELL), 0, GCOLS - 1);
    const r0 = clamp(Math.floor((u.y - r) / CELL), 0, GROWS - 1);
    const r1 = clamp(Math.floor((u.y + r) / CELL), 0, GROWS - 1);
    let best: Unit | null = null;
    let bd = r * r;
    for (let gy = r0; gy <= r1; gy++) {
      for (let gx = c0; gx <= c1; gx++) {
        const cell = this.grid[gy * GCOLS + gx];
        for (const o of cell) {
          if (o.team === u.team || o.dead) continue;
          const dx = o.x - u.x;
          const dy = o.y - u.y;
          const d = dx * dx + dy * dy;
          if (d < bd) {
            bd = d;
            best = o;
          }
        }
      }
    }
    return best;
  }

  counterMult(atk: UnitType, def: UnitType) {
    return COUNTER[atk]?.[def] ?? 1;
  }

  meleeHit(u: Unit, t: Unit) {
    let dmg = u.atk * rand(0.85, 1.15);
    let kb = 1.6;
    const cm = u.hero ? 1 : this.counterMult(u.type, t.type);
    dmg *= cm;
    if (cm >= 1.5 && Math.random() < 0.06) this.text(t.x, t.y - 22, "Efektif!", u.team === 0 ? "#ffd27a" : "#bcd2ff", 0.7, 11);
    if ((u.type === "cavalry" || u.hero === "renold") && u.chargeDist > 70) {
      dmg *= 2;
      kb = 7;
      this.dust(t.x, t.y, 5, 40);
      this.shake = Math.max(this.shake, 1.5);
    }
    u.chargeDist = 0;
    if (!u.charged && u.squad.charging) {
      // first clash of a charge
      u.charged = true;
      dmg *= 1.4;
      kb = Math.max(kb, 5);
      this.dust(t.x, t.y, 4, 45);
      this.particles.push(this.mkP(t.x, t.y, 6, 0, 0, 0, "flash", "#ffffff", 0.14, 10));
      this.shake = Math.max(this.shake, 2.5);
      sfx.impact();
    }
    if (t.type === "hero") kb *= 0.4;
    this.damage(t, dmg, u, kb, true);
    if (u.cleave > 0) {
      const r2 = u.cleave * u.cleave;
      for (const o of this.units) {
        if (o === t || o.dead || o.team === u.team) continue;
        const dx = o.x - t.x;
        const dy = o.y - t.y;
        if (dx * dx + dy * dy < r2) this.damage(o, dmg * 0.6, u, 3, true);
      }
      this.ring(t.x, t.y, "rgba(255,255,255,0.8)", u.cleave * 1.4);
      this.shake = Math.max(this.shake, 2);
    }
    sfx.hit();
  }

  shoot(u: Unit, tx: number, ty: number, target: Unit | null, castle: number) {
    const d = Math.hypot(tx - u.x, ty - u.y);
    const big = !!u.hero;
    const dur = 0.45 + d / 480;
    const lead = target ? dur * 0.9 : 0;
    const ex = tx + (target ? target.vx * lead : 0) + rand(-4, 4);
    const ey = ty + (target ? target.vy * lead : 0) + rand(-3, 3);
    this.projectiles.push({
      x0: u.x + u.facing * 4,
      y0: u.y,
      x1: ex,
      y1: ey,
      t: 0,
      dur,
      arc: 24 + d * 0.3,
      z0: 9 * u.scale,
      team: u.team,
      dmg: u.atk * rand(0.85, 1.15),
      target,
      castle,
      big,
      atkType: u.hero ? "hero" : u.type,
    });
    sfx.bow();
  }

  fireCannon(u: Unit, tx: number, ty: number, castle: number) {
    const d = Math.hypot(tx - u.x, ty - u.y);
    const dur = 0.9 + d / 500;
    this.projectiles.push({
      x0: u.x + u.facing * 14,
      y0: u.y,
      x1: tx + rand(-14, 14),
      y1: ty + rand(-8, 8),
      t: 0,
      dur,
      arc: 60 + d * 0.35,
      z0: 14,
      team: u.team,
      dmg: CANNON_DEF.atk * rand(0.9, 1.1),
      target: null,
      castle,
      big: true,
      ball: true,
    });
    u.recoil = 1;
    u.atkT = 1;
    const mx = u.x + u.facing * 18;
    this.particles.push(this.mkP(mx, u.y, 14, 0, 0, 0, "flash", "#fff0a0", 0.12, 9));
    for (let i = 0; i < 6; i++) {
      this.particles.push(this.mkP(mx, u.y, 14, u.facing * rand(20, 70), rand(-15, 15), rand(5, 20), "smoke", "", rand(0.9, 1.6), rand(5, 9)));
    }
    this.shake = Math.max(this.shake, 3);
    sfx.cannon();
  }

  /* ------------------------------------------------------------ */
  /*  Update                                                      */
  /* ------------------------------------------------------------ */
  update(dt: number) {
    dt = Math.min(dt, 1 / 30);
    const sim = this.state === "playing" || this.state === "menu" || this.state === "won" || this.state === "lost";
    if (this.state === "paused") return;
    this.time += dt;

    if (this.state === "playing") {
      const prev = this.phaseT;
      this.phaseT -= dt;
      if (Math.ceil(this.phaseT) !== Math.ceil(prev) && this.phaseT <= 3 && this.phaseT > 0) {
        sfx.tick();
        this.events.push({ type: "tick" });
      }
      for (const k in this.heroCd) this.heroCd[k] = Math.max(0, this.heroCd[k] - dt);
      this.updateAI(dt);
      if (this.phaseT <= 0) this.launchWave();
      if (this.marchDrumT > 0) {
        const before = this.marchDrumT;
        this.marchDrumT -= dt;
        if (Math.floor(before / 0.5) !== Math.floor(this.marchDrumT / 0.5)) sfx.drum();
      }
    }
    this.launchFx = Math.max(0, this.launchFx - dt);
    if (this.state === "won" || this.state === "lost") this.endT += dt;
    if (!sim) return;

    this.buildGrid();

    // squads
    for (const sq of this.squads) {
      sq.spawnT += dt;
      let alive = 0;
      let engaged = 0;
      let sx = 0;
      let sy = 0;
      for (const u of sq.units) {
        if (u.dead) continue;
        alive++;
        sx += u.x;
        sy += u.y;
        if (u.target || u.attackingCastle) engaged++;
      }
      sq.alive = alive;
      sq.engaged = engaged;
      if (alive === 0) {
        if (!sq.dead) {
          sq.dead = true;
          if (sq.state !== "rout") sq.deadT = 0;
        }
        sq.deadT += dt;
        continue;
      }
      const dir = sq.team === 0 ? 1 : -1;
      if (sq.state === "march") {
        sq.launchT += dt;
        sq.walk += dt * 11;
        const factor = engaged / alive > 0.2 ? 0.06 : 1;
        // squads march slowly at first then pick up pace (a real advance)
        const ramp = Math.min(1, 0.4 + sq.launchT * 0.4);
        sq.chargeCheck -= dt;
        if (sq.chargeCheck <= 0 && sq.type !== "archer" && sq.type !== "cannon") {
          sq.chargeCheck = 0.3;
          const fx = sx / alive;
          const fy = sy / alive;
          let near = false;
          for (const o of this.units) {
            if (o.team === sq.team || o.dead) continue;
            const ddx = (o.x - fx) * dir;
            if (ddx > -20 && ddx < 230 && Math.abs(o.y - fy) < 140) {
              near = true;
              break;
            }
          }
          if (near && !sq.charging) {
            sq.charging = true;
            sfx.battleCry(sq.team);
            if (sq.type === "cavalry" || sq.hero === "renold") sfx.gallop();
            this.text(fx, fy - 40, sq.team === 0 ? "Serbuuu!" : "Hyaaa!", sq.team === 0 ? "#ffe2c4" : "#d6e3ff", 1, 14);
          }
          if (!near && engaged === 0) sq.charging = false;
        }
        const chargeMul = sq.charging && engaged / alive < 0.3 ? 1.75 : 1;
        sq.anchorX += dir * sq.speed * 0.9 * factor * ramp * chargeMul * dt;
        sq.anchorX = clamp(sq.anchorX, CASTLE[0].cx + 40, CASTLE[1].cx - 40);
        // morale: a broken squad routs
        if (sq.initial >= 5 && alive <= Math.ceil(sq.initial * 0.25) && engaged > 0) {
          sq.state = "rout";
          sq.deadT = 0;
          for (const u of sq.units) {
            u.fleeing = true;
            u.target = null;
          }
          this.text(sx / alive, sy / alive - 30, "Mundur!", sq.team === 0 ? "#ffb3a8" : "#bcd2ff", 1.3, 15);
        }
      } else if (sq.state === "rout") {
        sq.deadT += dt;
      }
      // archer volleys
      if (sq.type === "archer") {
        sq.volleyCd -= dt;
        if (sq.volleyWant && sq.volleyCd <= 0) {
          sq.volleyCd = UNIT_DEFS.archer.cd * rand(0.95, 1.1);
          sfx.volley();
          for (const u of sq.units) {
            if (u.dead || !u.target) continue;
            const d = Math.hypot(u.target.x - u.x, u.target.y - u.y);
            if (d <= u.range + 4) u.shootDelay = rand(0, 0.22);
          }
        }
        sq.volleyWant = false;
      }
      const bx = sx / alive - dir * 4;
      const by = sy / alive + 1;
      sq.bannerX += (bx - sq.bannerX) * Math.min(1, dt * 4);
      sq.bannerY += (by - sq.bannerY) * Math.min(1, dt * 4);
    }
    this.squads = this.squads.filter((s) => !(s.dead && s.deadT > 2.6));

    // units
    for (const u of this.units) {
      if (u.dead) continue;
      if (u.spawnT < 0) {
        u.spawnT += dt;
        if (u.spawnT >= 0) {
          sfx.pop();
          this.dust(u.x, u.y, 2, 20);
        }
        continue;
      }
      u.spawnT += dt;
      u.cdT -= dt;
      u.hitT = Math.max(0, u.hitT - dt * 4.5);
      u.atkT = Math.max(0, u.atkT - dt * 3.2);
      u.showHpT = Math.max(0, u.showHpT - dt);
      if (u.cheerT > 0) u.cheerT = Math.max(0, u.cheerT - dt * 2.2);
      u.recoil = Math.max(0, u.recoil - dt * 2.5);
      if (u.flyZ > 0) {
        // tossed by an explosion
        u.flyV -= 420 * dt;
        u.flyZ += u.flyV * dt;
        u.x += u.vx * dt * 1.5;
        u.y += u.vy * dt * 1.5;
        if (u.flyZ <= 0) {
          u.flyZ = 0;
          u.flyV = 0;
          u.vx *= 0.2;
          u.vy *= 0.2;
          this.dust(u.x, u.y, 3, 25);
          u.hitT = 1;
        }
        continue;
      }
      if (u.spawnT < 0.3) continue;

      const sq = u.squad;
      const dir = u.team === 0 ? 1 : -1;
      let mx = 0;
      let my = 0;
      let spd = u.speed;
      let synced = false;
      u.attackingCastle = false;

      if (u.fleeing) {
        // run home
        mx = -dir;
        my = Math.sin(u.seed + this.time) * 0.3;
        spd *= 1.25;
        u.facing = -dir;
        const home = u.team === 0 ? ZONES[0].x0 : ZONES[1].x1;
        if ((u.team === 0 && u.x <= home) || (u.team === 1 && u.x >= home)) {
          u.dead = true;
          this.dust(u.x, u.y, 3, 20);
          if (u.team === 0) this.stats.fled++;
          continue;
        }
      } else {
        u.retarget -= dt;
        if (u.target && (u.target.dead || Math.hypot(u.target.x - u.x, u.target.y - u.y) > u.aggro * 1.4)) u.target = null;
        if (u.retarget <= 0) {
          u.retarget = rand(0.18, 0.32);
          const t = this.findTarget(u);
          // squads waiting for the horn only defend themselves (archers may shoot)
          if (t && sq.state === "ready" && !u.ranged && Math.hypot(t.x - u.x, t.y - u.y) > 60) u.target = null;
          else if (t) u.target = t;
        }

        const enemyTeam = 1 - u.team;
        if (u.target) {
          const t = u.target;
          const dx = t.x - u.x;
          const dy = t.y - u.y;
          const d = Math.hypot(dx, dy) || 1;
          u.facing = dx >= 0 ? 1 : -1;
          const reach = u.range + (u.ranged ? 0 : t.radius + u.radius * 0.5);
          if (d > reach) {
            mx = dx / d;
            my = dy / d;
            if (!u.ranged) spd *= 1.15;
          } else if (u.type === "cannon") {
            if (u.cdT <= 0) {
              u.cdT = u.cd * rand(0.95, 1.1);
              this.fireCannon(u, t.x, t.y, -1);
            }
          } else if (u.ranged && !u.hero && u.type === "archer") {
            // volley fire: wait for the squad command
            sq.volleyWant = true;
            if (u.shootDelay >= 0) {
              u.shootDelay -= dt;
              if (u.shootDelay < 0) {
                u.atkT = 1;
                this.shoot(u, t.x, t.y, t, -1);
                u.shootDelay = -1;
              }
            }
          } else if (u.cdT <= 0) {
            u.cdT = u.cd * rand(0.9, 1.15);
            u.atkT = 1;
            if (u.ranged) {
              this.shoot(u, t.x, t.y, t, -1);
              if (u.hero === "swiftbow" && Math.random() < 0.5) {
                this.shoot(u, t.x + rand(-12, 12), t.y + rand(-8, 8), null, -1);
              }
            } else this.meleeHit(u, t);
          }
        } else {
          const cd = this.castleDist(u, enemyTeam);
          const near = sq.state === "march" && (cd.d < u.aggro * (u.type === "cannon" ? 0.9 : 1.1) || cd.d < 120);
          if (near && this.castles[enemyTeam].hp > 0) {
            u.attackingCastle = true;
            const dx = cd.nx - u.x;
            const dy = cd.ny - u.y;
            u.facing = dx >= 0 ? 1 : -1;
            if (cd.d > u.range + 3) {
              mx = dx / (cd.d || 1);
              my = dy / (cd.d || 1);
            } else if (u.cdT <= 0) {
              u.cdT = u.cd * rand(0.9, 1.15);
              u.atkT = 1;
              if (u.type === "cannon") this.fireCannon(u, cd.nx, cd.ny, enemyTeam);
              else if (u.ranged) this.shoot(u, cd.nx + rand(-15, 15), cd.ny - rand(0, 40), null, enemyTeam);
              else {
                this.hitCastle(enemyTeam, u.atk * (u.hero ? 1.5 : 1), cd.nx, cd.ny);
                sfx.hit();
              }
            }
          } else {
            const sx = sq.anchorX + u.offX;
            const sy = sq.anchorY + u.offY;
            const dx = sx - u.x;
            const dy = sy - u.y;
            const d = Math.hypot(dx, dy);
            if (d > 2.5) {
              mx = dx / d;
              my = dy / d;
              if (d > 25) spd *= 1.3;
              else spd *= Math.max(0.35, d / 25) * 1.1 + 0.2;
              if (sq.charging) spd *= 1.75;
            }
            u.facing = dir;
            if (Math.abs(dx) > 8 && sq.state !== "march") u.facing = dx > 0 ? 1 : -1;
            if (sq.state === "march" && d < 14 && !sq.charging) {
              // lock-step marching
              u.walk = sq.walk + (u.type === "cavalry" ? (u.seed % 1) * 0.6 : 0);
              synced = true;
            }
          }
        }
      }
      const k = Math.min(1, dt * 7);
      u.vx += (mx * spd - u.vx) * k;
      u.vy += (my * spd - u.vy) * k;
      u.x += u.vx * dt;
      u.y += u.vy * dt;
      const sp = Math.hypot(u.vx, u.vy);
      if (sp > 4) {
        if (!synced) u.walk += dt * (u.type === "cavalry" || u.hero === "renold" ? 11 : 13) * Math.min(1.3, sp / 30 + 0.3);
        if (u.type === "cavalry" || u.hero === "renold") {
          u.chargeDist += sp * dt;
          if (Math.random() < dt * 3) this.dust(u.x - u.facing * 6, u.y, 1, 12);
        } else if (sq.state === "march" && Math.random() < dt * (sq.charging ? 5 : 0.4)) {
          this.dust(u.x - u.facing * 4, u.y, 1, sq.charging ? 16 : 8);
        }
      } else {
        u.chargeDist = 0;
      }
      u.y = clamp(u.y, FIELD_TOP, FIELD_BOTTOM);
      u.x = clamp(u.x, 10, W - 10);
    }
    this.units = this.units.filter((u) => !u.dead);

    // separation
    this.buildGrid();
    for (const u of this.units) {
      if (u.dead || u.spawnT < 0) continue;
      const gx = clamp(Math.floor(u.x / CELL), 0, GCOLS - 1);
      const gy = clamp(Math.floor(u.y / CELL), 0, GROWS - 1);
      for (let yy = Math.max(0, gy - 1); yy <= Math.min(GROWS - 1, gy + 1); yy++) {
        for (let xx = Math.max(0, gx - 1); xx <= Math.min(GCOLS - 1, gx + 1); xx++) {
          for (const o of this.grid[yy * GCOLS + xx]) {
            if (o.id <= u.id) continue;
            const dx = o.x - u.x;
            const dy = (o.y - u.y) * 1.5;
            const min = u.radius + o.radius;
            const d2 = dx * dx + dy * dy;
            if (d2 < min * min && d2 > 0.0001) {
              const d = Math.sqrt(d2);
              const push = (min - d) * 0.5;
              const nx = dx / d;
              const ny = dy / d;
              const wu = o.type === "hero" ? 0.85 : u.type === "hero" ? 0.15 : 0.5;
              u.x -= nx * push * wu * 2;
              u.y -= ny * push * wu * 1.2;
              o.x += nx * push * (1 - wu) * 2;
              o.y += ny * push * (1 - wu) * 1.2;
            }
          }
        }
      }
      // castle collision
      for (let t = 0; t < 2; t++) {
        const C = CASTLE[t];
        if (u.x > C.cx - C.hw && u.x < C.cx + C.hw && u.y > C.top + 60 && u.y < C.baseY) {
          const left = u.x - (C.cx - C.hw);
          const right = C.cx + C.hw - u.x;
          const up = u.y - (C.top + 60);
          const down = C.baseY - u.y;
          const m = Math.min(left, right, up, down);
          if (m === left) u.x = C.cx - C.hw;
          else if (m === right) u.x = C.cx + C.hw;
          else if (m === up) u.y = C.top + 60;
          else u.y = C.baseY;
        }
      }
    }

    this.units = this.units.filter((u) => !u.dead);

    // castles
    for (let t = 0; t < 2; t++) {
      const c = this.castles[t];
      const C = CASTLE[t];
      c.sv += (-170 * c.squash - 9 * c.sv) * dt;
      c.squash += c.sv * dt;
      c.flash = Math.max(0, c.flash - dt);
      if (c.hp <= 0) continue;
      c.shootCd -= dt;
      if (c.shootCd <= 0 && this.state === "playing") {
        let best: Unit | null = null;
        let bd = 300 * 300;
        for (const u of this.units) {
          if (u.team === t || u.spawnT < 0) continue;
          const dx = u.x - C.cx;
          const dy = u.y - (C.baseY - 60);
          const d = dx * dx + dy * dy;
          if (d < bd) {
            bd = d;
            best = u;
          }
        }
        if (best) {
          c.shootCd = 0.32;
          const tx = C.cx + (Math.random() < 0.5 ? -74 : 74);
          const d = Math.hypot(best.x - tx, best.y - C.baseY);
          this.projectiles.push({
            x0: tx,
            y0: C.baseY - 10,
            x1: best.x + best.vx * 0.3,
            y1: best.y + best.vy * 0.3,
            t: 0,
            dur: 0.35 + d / 600,
            arc: 30 + d * 0.15,
            z0: 120,
            team: t,
            dmg: 9,
            target: best,
            castle: -1,
            big: false,
          });
        } else c.shootCd = 0.2;
      }
      const frac = c.hp / CASTLE_HP;
      if (frac < 0.6) {
        c.smokeT -= dt;
        if (c.smokeT <= 0) {
          c.smokeT = frac < 0.3 ? 0.08 : 0.2;
          const sx = C.cx + rand(-70, 70);
          this.particles.push(this.mkP(sx, C.baseY - rand(5, 20), rand(60, 140), rand(-8, 8), rand(-4, 4), rand(18, 30), "smoke", "", rand(2, 3.5), rand(6, 12)));
          if (frac < 0.3) this.particles.push(this.mkP(sx, C.baseY - 10, rand(60, 110), rand(-5, 5), 0, rand(20, 40), "fire", "", rand(0.4, 0.7), rand(3, 6)));
        }
      }
    }

    // projectiles
    for (const p of this.projectiles) {
      p.t += dt / p.dur;
      if (p.t >= 1) {
        if (p.ball) {
          if (p.castle >= 0) this.hitCastle(p.castle, p.dmg * CANNON_DEF.castleMult, p.x1, p.y1);
          this.explode(p.x1, p.y1, p.team, p.castle >= 0 ? p.dmg * 0.5 : p.dmg, CANNON_DEF.splash);
        } else if (p.castle >= 0) {
          this.hitCastle(p.castle, p.dmg, p.x1, p.y1);
        } else {
          let hit: Unit | null = null;
          if (p.target && !p.target.dead && Math.hypot(p.target.x - p.x1, p.target.y - p.y1) < 14 + p.target.radius) hit = p.target;
          else {
            // splash check
            let bd = 64;
            for (const u of this.units) {
              if (u.team === p.team) continue;
              const d = (u.x - p.x1) ** 2 + (u.y - p.y1) ** 2;
              if (d < bd) {
                bd = d;
                hit = u;
              }
            }
          }
          if (hit) this.damage(hit, p.dmg * (p.atkType && p.atkType !== "hero" ? this.counterMult(p.atkType as UnitType, hit.type) : 1), { x: p.x0, y: p.y0 }, 1.2);
          else {
            const ang = Math.atan2(p.y1 - p.y0, p.x1 - p.x0);
            this.stuck.push({ x: p.x1, y: p.y1, ang, t: 0 });
            if (Math.random() < 0.3) sfx.thunk();
            if (this.stuck.length > 250) this.stuck.shift();
          }
        }
      }
    }
    this.projectiles = this.projectiles.filter((p) => p.t < 1);

    for (const s of this.stuck) s.t += dt;
    this.stuck = this.stuck.filter((s) => s.t < 8);
    for (const d of this.decals) d.t += dt;
    this.decals = this.decals.filter((d) => d.t < (d.kind === "crater" ? 25 : 18));
    for (const c of this.clouds) {
      c.x += c.v * dt;
      if (c.x > W + 50) {
        c.x = -520 * c.s - rand(0, 200);
        c.y = rand(60, H - 250);
      }
    }
    this.birdT -= dt;
    if (this.birdT <= 0) {
      this.birdT = rand(12, 22);
      const fromLeft = Math.random() < 0.5;
      this.birds.push({ x: fromLeft ? -60 : W + 60, y: rand(120, 600), vx: (fromLeft ? 1 : -1) * rand(55, 85), n: 3 + Math.floor(rand(0, 4)), t: 0 });
    }
    for (const b of this.birds) {
      b.x += b.vx * dt;
      b.t += dt;
    }
    this.birds = this.birds.filter((b) => b.x > -120 && b.x < W + 120);
    if (Math.random() < dt * 1.2) {
      // drifting leaves / petals
      this.particles.push(this.mkP(rand(0, W), rand(80, H - 100), rand(30, 70), rand(10, 30), rand(-3, 3), 0, "leaf", Math.random() < 0.5 ? "#f0d68a" : "#ffd0e0", rand(6, 10), rand(1.5, 2.5)));
    }
    this.zoomPunch = Math.max(0, this.zoomPunch - dt * 1.8);
    for (const c of this.corpses) c.t += dt;
    this.corpses = this.corpses.filter((c) => c.t < 14);

    // particles
    for (const p of this.particles) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.rot += p.vr * dt;
      if (p.kind === "blood") {
        p.vz -= 380 * dt;
        if (p.z <= 0) {
          p.life = 0;
          this.decals.push({ x: p.x, y: p.y, r: p.size * 1.3, t: 0, kind: "blood", rot: 0, seed: Math.random() });
        }
      } else if (p.kind === "dirt") {
        p.vz -= 400 * dt;
        if (p.z < 0) {
          p.z = 0;
          p.vz = 0;
          p.vx *= 0.3;
          p.vy *= 0.3;
        }
      } else if (p.kind === "leaf") {
        p.vx += Math.sin(this.time * 2 + p.rot) * 10 * dt;
        p.vz = Math.sin(this.time * 3 + p.rot) * 6;
      } else if (p.kind === "debris" || p.kind === "helmet" || p.kind === "spark" || p.kind === "star") {
        p.vz -= 320 * dt;
        if (p.z < 0) {
          p.z = 0;
          p.vz = -p.vz * 0.45;
          p.vx *= 0.6;
          p.vy *= 0.6;
          p.vr *= 0.5;
        }
      } else if (p.kind === "dust") {
        p.vx *= 1 - dt * 3;
        p.vy *= 1 - dt * 3;
      } else if (p.kind === "smoke" || p.kind === "fire") {
        p.vx += 6 * dt;
      }
    }
    this.particles = this.particles.filter((p) => p.life > 0);
    if (this.particles.length > 1500) this.particles.splice(0, this.particles.length - 1500);

    for (const t of this.texts) t.t += dt;
    this.texts = this.texts.filter((t) => t.t < t.max);

    this.shake = Math.max(0, this.shake - dt * 30);

    // keep menu backdrop alive
    if (this.state === "menu" && this.units.length < 40) this.spawnDemo();
  }

  /* ------------------------------------------------------------ */
  /*  Render                                                      */
  /* ------------------------------------------------------------ */
  render(ctx: CanvasRenderingContext2D) {
    ctx.save();
    if (this.shake > 0) ctx.translate(rand(-1, 1) * this.shake, rand(-1, 1) * this.shake);
    if (this.zoomPunch > 0) {
      const z = 1 + Math.sin(this.zoomPunch * Math.PI) * 0.018;
      ctx.translate(W / 2, H / 2);
      ctx.scale(z, z);
      ctx.translate(-W / 2, -H / 2);
    }
    ctx.drawImage(this.bg, 0, 0, W, H);

    // zone highlight
    if (this.state === "playing") {
      const Z = ZONES[0];
      const active = !!this.drawing || !!this.pendingHero || this.pendingCannon || this.inZone(this.mouse.x, this.mouse.y) || this.hint > 0;
      const pulse = 0.5 + Math.sin(this.time * 3) * 0.5;
      ctx.fillStyle = `rgba(220,60,60,${active ? 0.1 + pulse * 0.04 : 0.05})`;
      this.roundRect(ctx, Z.x0, FIELD_TOP - 10, Z.x1 - Z.x0, FIELD_BOTTOM - FIELD_TOP + 20, 18);
      ctx.fill();
      ctx.setLineDash([8, 8]);
      ctx.lineDashOffset = -this.time * 20;
      ctx.strokeStyle = `rgba(200,40,50,${active ? 0.75 : 0.35})`;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.setLineDash([]);
      if (active) {
        ctx.font = "700 14px 'Alegreya SC', Georgia, serif";
        ctx.textAlign = "center";
        ctx.lineWidth = 3;
        ctx.strokeStyle = "rgba(60,20,20,0.6)";
        ctx.strokeText("ZONA PENEMPATAN", (Z.x0 + Z.x1) / 2, FIELD_TOP + 8);
        ctx.fillStyle = "rgba(255,240,230,0.95)";
        ctx.fillText("ZONA PENEMPATAN", (Z.x0 + Z.x1) / 2, FIELD_TOP + 8);
      }
    }

    // enemy zone (you can always see what the enemy is preparing)
    if (this.state === "playing") {
      const Z = ZONES[1];
      ctx.fillStyle = "rgba(63,102,196,0.06)";
      this.roundRect(ctx, Z.x0, FIELD_TOP - 10, Z.x1 - Z.x0, FIELD_BOTTOM - FIELD_TOP + 20, 18);
      ctx.fill();
      ctx.setLineDash([8, 8]);
      ctx.lineDashOffset = this.time * 20;
      ctx.strokeStyle = "rgba(50,80,170,0.4)";
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.font = "700 14px 'Alegreya SC', Georgia, serif";
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(20,30,60,0.55)";
      ctx.strokeText("PERSIAPAN MUSUH", (Z.x0 + Z.x1) / 2, FIELD_TOP + 8);
      ctx.fillStyle = "rgba(230,238,255,0.9)";
      ctx.fillText("PERSIAPAN MUSUH", (Z.x0 + Z.x1) / 2, FIELD_TOP + 8);
      this.drawTacticalArrows(ctx);
    }

    // ground decals
    for (const s of this.stuck) {
      const a = s.t > 6 ? 1 - (s.t - 6) / 2 : 1;
      ctx.globalAlpha = a;
      ctx.strokeStyle = "#2a2018";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(s.x - Math.cos(s.ang) * 5, s.y - 5);
      ctx.stroke();
      ctx.fillStyle = "#e8e2d0";
      ctx.fillRect(s.x - Math.cos(s.ang) * 5 - 1, s.y - 6, 2, 1.5);
    }
    ctx.globalAlpha = 1;
    for (const d of this.decals) {
      const life = d.kind === "crater" ? 25 : 18;
      const a = d.t > life - 4 ? (life - d.t) / 4 : 1;
      if (d.kind === "crater") drawCrater(ctx, d.x, d.y, d.r, a);
      else {
        const grow = d.kind === "pool" ? Math.min(1, d.t / 1.2) : Math.min(1, d.t / 0.1);
        drawBloodDecal(ctx, d.x, d.y, d.r * (0.3 + 0.7 * easeOutBack(grow)), d.seed, a * 0.85, d.kind === "pool");
      }
    }
    for (const c of this.corpses) {
      const fall = easeOutBack(Math.min(1, c.t / 0.35));
      const a = c.t > 10 ? 1 - (c.t - 10) / 4 : 1;
      drawCorpse(ctx, c.x, c.y, c.team, c.type, c.facing, c.scale, a * 0.85, Math.min(1.05, fall), c.hero);
    }

    // depth-sorted entities
    type D = { y: number; f: () => void };
    const list: D[] = [];
    for (let t = 0; t < 2; t++) {
      const c = this.castles[t];
      if (c.hp <= 0 && (this.state === "won" || this.state === "lost")) {
        const C = CASTLE[t];
        list.push({ y: C.baseY, f: () => this.drawRuins(ctx, t) });
      } else {
        list.push({ y: CASTLE[t].baseY, f: () => drawCastle(ctx, t as Team, c.squash, c.hp / CASTLE_HP, this.time, c.flash) });
      }
    }
    for (const u of this.units) {
      if (u.spawnT < 0) continue;
      list.push({ y: u.y, f: () => this.drawUnit(ctx, u) });
    }
    for (const sq of this.squads) {
      if (sq.type === "hero" || sq.type === "cannon") continue;
      list.push({ y: sq.bannerY + 0.5, f: () => this.drawSquadBanner(ctx, sq) });
    }
    list.sort((a, b) => a.y - b.y);
    for (const d of list) d.f();

    // projectiles
    for (const p of this.projectiles) {
      const t = p.t;
      const x = p.x0 + (p.x1 - p.x0) * t;
      const gy = p.y0 + (p.y1 - p.y0) * t;
      const z = p.z0 * (1 - t) + Math.sin(Math.PI * t) * p.arc;
      const t2 = Math.min(1, t + 0.03);
      const x2 = p.x0 + (p.x1 - p.x0) * t2;
      const gy2 = p.y0 + (p.y1 - p.y0) * t2;
      const z2 = p.z0 * (1 - t2) + Math.sin(Math.PI * t2) * p.arc;
      const ang = Math.atan2(gy2 - z2 - (gy - z), x2 - x);
      if (p.ball) {
        drawShadow(ctx, x, gy, 3 + t * 2, 0.3);
        ctx.fillStyle = "#222226";
        ctx.beginPath();
        ctx.arc(x, gy - z, 3.6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.45)";
        ctx.beginPath();
        ctx.arc(x - 1.2, gy - z - 1.2, 1.2, 0, Math.PI * 2);
        ctx.fill();
        if (Math.random() < 0.5) this.particles.push(this.mkP(x, gy, z, 0, 0, 3, "smoke", "", 0.5, 2.5));
        continue;
      }
      ctx.fillStyle = "rgba(28,42,14,0.25)";
      ctx.fillRect(x - 2, gy - 0.5, 4, 1);
      ctx.save();
      ctx.translate(x, gy - z);
      ctx.rotate(ang);
      const L = p.big ? 9 : 7;
      ctx.strokeStyle = "#2a2018";
      ctx.lineWidth = p.big ? 1.4 : 1;
      ctx.beginPath();
      ctx.moveTo(-L, 0);
      ctx.lineTo(0, 0);
      ctx.stroke();
      ctx.fillStyle = "#e8e2d0";
      ctx.fillRect(-L, -1, 2.2, 2);
      ctx.fillStyle = p.big ? "#f2c23a" : "#cfcfcf";
      ctx.beginPath();
      ctx.moveTo(2, 0);
      ctx.lineTo(-0.5, -1.3);
      ctx.lineTo(-0.5, 1.3);
      ctx.fill();
      ctx.restore();
    }

    this.drawParticles(ctx);

    // floating texts
    ctx.textAlign = "center";
    for (const t of this.texts) {
      const k = t.t / t.max;
      const s = easeOutElastic(Math.min(1, t.t / 0.4));
      ctx.save();
      ctx.globalAlpha = k > 0.7 ? 1 - (k - 0.7) / 0.3 : 1;
      ctx.translate(t.x, t.y - k * 26);
      ctx.scale(s, s);
      ctx.font = `900 ${t.size}px 'Alegreya SC', Georgia, serif`;
      ctx.lineWidth = 3.5;
      ctx.strokeStyle = "rgba(20,14,8,0.85)";
      ctx.strokeText(t.text, 0, 0);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, 0, 0);
      ctx.restore();
    }

    this.drawPreview(ctx);

    for (const c of this.clouds) ctx.drawImage(this.cloudImg, c.x, c.y, 520 * c.s, 300 * c.s);
    for (const b of this.birds) {
      for (let i = 0; i < b.n; i++) {
        const bx = b.x - Math.sign(b.vx) * (i % 2 ? 1 : 0.6) * (Math.ceil(i / 2) * 14);
        const by = b.y + (i % 2 ? -1 : 1) * Math.ceil(i / 2) * 9;
        const flap = Math.sin(b.t * 12 + i) * 3;
        ctx.fillStyle = "rgba(28,42,14,0.18)";
        ctx.beginPath();
        ctx.ellipse(bx + 30, by + 70, 4, 1.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#2a2622";
        ctx.lineWidth = 1.6;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(bx - 5, by - flap);
        ctx.quadraticCurveTo(bx - 2, by - 2, bx, by);
        ctx.quadraticCurveTo(bx + 2, by - 2, bx + 5, by - flap);
        ctx.stroke();
      }
    }

    ctx.drawImage(this.fg, 0, 0, W, H);
    ctx.restore();
  }

  roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  drawTacticalArrows(ctx: CanvasRenderingContext2D) {
    const urgency = this.phaseT < 3 ? 1 : 0;
    for (const sq of this.squads) {
      if (sq.state !== "ready" || sq.dead || sq.spawnT < 0.3) continue;
      const dir = sq.team === 0 ? 1 : -1;
      const col = sq.team === 0 ? "229,85,91" : "111,146,230";
      let minY = Infinity;
      let maxY = -Infinity;
      let front = sq.team === 0 ? -Infinity : Infinity;
      for (const u of sq.units) {
        if (u.dead) continue;
        minY = Math.min(minY, u.y);
        maxY = Math.max(maxY, u.y);
        front = sq.team === 0 ? Math.max(front, u.x) : Math.min(front, u.x);
      }
      const cy = (minY + maxY) / 2;
      const half = Math.max(14, (maxY - minY) / 2);
      const x0 = front + dir * 14;
      const len = (sq.type === "cannon" ? 70 : 0) + (sq.type === "cavalry" || sq.hero === "renold" ? 230 : sq.type === "archer" ? 120 : 170) + Math.sin(this.time * 4 + sq.id) * 6 + urgency * 20;
      const x1 = x0 + dir * len;
      const a = 0.32 + urgency * 0.25 * (0.5 + 0.5 * Math.sin(this.time * 10));
      // broad arrow body (war-map style)
      ctx.fillStyle = `rgba(${col},${a * 0.35})`;
      ctx.beginPath();
      const w0 = Math.min(half, 60);
      const w1 = Math.min(half * 0.55, 32);
      ctx.moveTo(x0, cy - w0);
      ctx.quadraticCurveTo((x0 + x1) / 2, cy - w0 * 0.8, x1 - dir * 18, cy - w1);
      ctx.lineTo(x1 - dir * 18, cy - w1 - 12);
      ctx.lineTo(x1 + dir * 8, cy);
      ctx.lineTo(x1 - dir * 18, cy + w1 + 12);
      ctx.lineTo(x1 - dir * 18, cy + w1);
      ctx.quadraticCurveTo((x0 + x1) / 2, cy + w0 * 0.8, x0, cy + w0);
      ctx.closePath();
      ctx.fill();
      ctx.setLineDash([7, 6]);
      ctx.lineDashOffset = -this.time * 30 * dir;
      ctx.strokeStyle = `rgba(${col},${a + 0.15})`;
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.setLineDash([]);
      // type label at arrow tip
      ctx.font = "700 11px 'Alegreya SC', Georgia, serif";
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(30,25,15,0.6)";
      const label0 = sq.hero ? HERO_DEFS[sq.hero].name : sq.type === "cannon" ? "Meriam" : `${TYPE_NAME[sq.type]} ×${sq.alive}`;
      ctx.strokeText(label0, (x0 + x1) / 2, cy - w0 - 6);
      ctx.fillStyle = `rgba(255,250,240,${0.8 + urgency * 0.2})`;
      const label = label0;
      ctx.fillText(label, (x0 + x1) / 2, cy - w0 - 6);
    }
  }

  drawRuins(ctx: CanvasRenderingContext2D, t: number) {
    const C = CASTLE[t];
    ctx.save();
    ctx.translate(C.cx, C.baseY);
    ctx.fillStyle = "rgba(15,10,5,0.35)";
    ctx.beginPath();
    ctx.ellipse(0, 4, 100, 22, 0, 0, Math.PI * 2);
    ctx.fill();
    const blocks: [number, number, number, number][] = [
      [-80, -40, 30, 40],
      [-50, -22, 40, 22],
      [-10, -55, 30, 55],
      [25, -30, 35, 30],
      [60, -48, 26, 48],
    ];
    blocks.forEach(([x, y, w], i) => {
      ctx.fillStyle = i % 2 ? "#9a9385" : "#b3ac9e";
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, y + 6);
      ctx.lineTo(x + w * 0.3, y);
      ctx.lineTo(x + w * 0.6, y + 8);
      ctx.lineTo(x + w, y + 3);
      ctx.lineTo(x + w, 0);
      ctx.closePath();
      ctx.fill();
    });
    ctx.fillStyle = TEAM_COLORS[t].dark;
    ctx.beginPath();
    ctx.moveTo(-20, -2);
    ctx.lineTo(10, -14);
    ctx.lineTo(30, -2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  drawSquadBanner(ctx: CanvasRenderingContext2D, sq: Squad) {
    const appear = easeOutElastic(Math.min(1, sq.spawnT / 0.9));
    const drop = (1 - Math.min(1, sq.spawnT / 0.35)) * -60;
    let fall = 0;
    let alpha = 1;
    if (sq.dead || sq.state === "rout") {
      fall = easeOutBack(Math.min(1, sq.deadT / 0.6));
      alpha = sq.deadT > 1.6 ? Math.max(0, 1 - (sq.deadT - 1.6)) : 1;
    }
    if (sq.state === "march" && sq.launchT < 0.8) {
      // banners raised high at the horn
      ctx.save();
      const lift = Math.sin((sq.launchT / 0.8) * Math.PI) * 10;
      ctx.translate(0, -lift);
      drawBanner(ctx, sq.bannerX, sq.bannerY, sq.team, this.time, 1 + lift * 0.02, 0, 1, sq.id);
      ctx.restore();
      return;
    }
    const sway = sq.engaged > 0 ? Math.sin(this.time * 12 + sq.id) * 0.05 : 0;
    ctx.save();
    ctx.translate(0, drop);
    if (sway) {
      ctx.translate(sq.bannerX, sq.bannerY);
      ctx.rotate(sway);
      ctx.translate(-sq.bannerX, -sq.bannerY);
    }
    drawBanner(ctx, sq.bannerX, sq.bannerY, sq.team, this.time, 0.35 + appear * 0.65, fall, alpha, sq.id);
    ctx.restore();
  }

  drawUnit(ctx: CanvasRenderingContext2D, u: Unit) {
    const sp = Math.min(1, u.spawnT / 0.4);
    const s = easeOutBack(sp);
    const moving = Math.hypot(u.vx, u.vy) > 4;
    let sx = 1 + u.hitT * 0.35;
    let sy = 1 - u.hitT * 0.28;
    if (moving) {
      const b = Math.sin(u.walk * 2);
      sy *= 1 + b * 0.06;
      sx *= 1 - b * 0.05;
    }
    if (sp < 1) {
      // spawn squash: tall then flat then settle
      sy *= 1 + Math.sin(sp * Math.PI) * 0.35;
      sx *= 1 - Math.sin(sp * Math.PI) * 0.2;
    }
    if (!moving) sy *= 1 + Math.sin(this.time * 3 + u.seed) * 0.03;
    const sc = u.scale * s;
    let hop = sp < 1 ? Math.sin(sp * Math.PI) * 10 : 0;
    if (u.cheerT > 0 && u.cheerT < 1) {
      hop += Math.abs(Math.sin(u.cheerT * Math.PI * 2)) * 6;
      sy *= 1 + Math.sin(u.cheerT * Math.PI * 2) * 0.12;
    }

    if (u.hero) {
      // golden ring
      ctx.strokeStyle = `rgba(242,194,58,${0.55 + Math.sin(this.time * 5) * 0.25})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.ellipse(u.x, u.y, 17 + Math.sin(this.time * 5) * 1.5, 6.5, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    drawShadow(ctx, u.x, u.y, (u.type === "cavalry" || u.hero === "renold" ? 9 : u.type === "cannon" ? 11 : 4.5) * sc * (1 - Math.min(0.5, u.flyZ / 80)));
    ctx.save();
    ctx.translate(u.x, u.y - hop - u.flyZ);
    if (u.flyZ > 0) ctx.rotate(u.facing * -u.flyZ * 0.04);
    else if (moving && u.squad.charging && !u.target) ctx.rotate(u.facing * 0.16);
    ctx.scale(u.facing * sc * sx, sc * sy);
    drawFigure(ctx, {
      team: u.team,
      type: u.type,
      hero: u.hero,
      walk: u.walk,
      moving,
      atk: u.atkT,
      flash: u.hitT > 0.65,
      recoil: u.recoil,
    });
    ctx.restore();
    if (u.fleeing) {
      // little sweat drop
      const yy = u.y - 22 * u.scale + Math.sin(this.time * 12 + u.seed) * 1.5;
      ctx.fillStyle = "#cfe6ff";
      ctx.beginPath();
      ctx.moveTo(u.x + 4, yy - 4);
      ctx.quadraticCurveTo(u.x + 7, yy, u.x + 4, yy + 1.5);
      ctx.quadraticCurveTo(u.x + 1, yy, u.x + 4, yy - 4);
      ctx.fill();
    }

    if (u.showHpT > 0 || u.hero) {
      const w = u.hero ? 26 : 10;
      const y = u.y - (u.type === "cavalry" ? 24 : 19) * u.scale - (u.hero ? 6 : 0);
      ctx.globalAlpha = u.hero ? 1 : Math.min(1, u.showHpT * 2);
      ctx.fillStyle = "rgba(20,14,8,0.8)";
      ctx.fillRect(u.x - w / 2 - 1, y - 1, w + 2, u.hero ? 4 : 3);
      ctx.fillStyle = u.team === 0 ? "#7be07b" : "#ff6b6b";
      ctx.fillRect(u.x - w / 2, y, (w * Math.max(0, u.hp)) / u.maxHp, u.hero ? 2 : 1);
      ctx.globalAlpha = 1;
      if (u.hero) {
        ctx.font = "700 10px 'Alegreya SC', Georgia, serif";
        ctx.textAlign = "center";
        ctx.lineWidth = 3;
        ctx.strokeStyle = "rgba(20,14,8,0.85)";
        const name = HERO_DEFS[u.hero].name;
        ctx.strokeText(name, u.x, y - 4);
        ctx.fillStyle = u.team === 0 ? "#ffe3a3" : "#cfe0ff";
        ctx.fillText(name, u.x, y - 4);
      }
    }
  }

  drawParticles(ctx: CanvasRenderingContext2D) {
    for (const p of this.particles) {
      const k = p.life / p.max;
      switch (p.kind) {
        case "dust": {
          const r = p.size * (1.6 - k * 0.6);
          ctx.fillStyle = p.color + (k * 0.5).toFixed(3) + ")";
          ctx.beginPath();
          ctx.arc(p.x, p.y - p.z, r, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "spark": {
          ctx.strokeStyle = p.color;
          ctx.globalAlpha = k;
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y - p.z);
          ctx.lineTo(p.x - p.vx * 0.03, p.y - p.z + p.vz * 0.03);
          ctx.stroke();
          ctx.globalAlpha = 1;
          break;
        }
        case "star": {
          ctx.globalAlpha = Math.min(1, k * 2);
          ctx.fillStyle = p.color;
          ctx.save();
          ctx.translate(p.x, p.y - p.z);
          ctx.rotate(p.rot);
          const s = p.size;
          ctx.beginPath();
          for (let i = 0; i < 8; i++) {
            const r = i % 2 ? s * 0.4 : s;
            const a = (i / 8) * Math.PI * 2;
            ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
          }
          ctx.fill();
          ctx.restore();
          ctx.globalAlpha = 1;
          break;
        }
        case "debris": {
          ctx.fillStyle = "rgba(15,10,5,0.25)";
          ctx.fillRect(p.x - p.size / 2, p.y - 0.5, p.size, 1);
          ctx.save();
          ctx.globalAlpha = Math.min(1, k * 3);
          ctx.translate(p.x, p.y - p.z);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          ctx.restore();
          break;
        }
        case "helmet": {
          ctx.save();
          ctx.globalAlpha = Math.min(1, k * 3);
          drawShadow(ctx, p.x, p.y, p.size, 0.2);
          ctx.translate(p.x, p.y - p.z);
          ctx.rotate(p.rot);
          ctx.fillStyle = "#c9c7c2";
          ctx.beginPath();
          ctx.arc(0, 0, p.size, Math.PI, 0);
          ctx.fill();
          ctx.fillStyle = "#8f8c86";
          ctx.fillRect(-p.size * 1.1, 0, p.size * 2.2, p.size * 0.35);
          ctx.restore();
          break;
        }
        case "ring": {
          const e = 1 - k;
          const r = p.size * easeOutBack(Math.min(1, e * 1.2));
          ctx.strokeStyle = p.color;
          ctx.globalAlpha = k;
          ctx.lineWidth = 3 * k + 0.5;
          ctx.beginPath();
          ctx.ellipse(p.x, p.y, Math.max(0, r), Math.max(0, r * 0.4), 0, 0, Math.PI * 2);
          ctx.stroke();
          ctx.globalAlpha = 1;
          break;
        }
        case "smoke": {
          const r = p.size * (1.8 - k);
          ctx.fillStyle = `rgba(110,104,96,${k * 0.42})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y - p.z, r, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "blood": {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y - p.z, p.size, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "dirt": {
          ctx.globalAlpha = Math.min(1, k * 2);
          ctx.fillStyle = p.color;
          ctx.fillRect(p.x - p.size / 2, p.y - p.z - p.size / 2, p.size, p.size);
          ctx.globalAlpha = 1;
          break;
        }
        case "slash": {
          const e = 1 - k;
          ctx.save();
          ctx.translate(p.x, p.y - p.z);
          ctx.rotate(p.rot);
          ctx.strokeStyle = `rgba(255,255,255,${k})`;
          ctx.lineWidth = 2.2 * k + 0.4;
          ctx.lineCap = "round";
          ctx.beginPath();
          ctx.arc(0, 0, p.size * (0.6 + e * 0.5), -1.1 + e * 0.6, 1.1 + e * 0.6);
          ctx.stroke();
          ctx.restore();
          break;
        }
        case "flash": {
          const r = p.size * (0.5 + (1 - k) * 0.8);
          const g = ctx.createRadialGradient(p.x, p.y - p.z, 0, p.x, p.y - p.z, r);
          g.addColorStop(0, `rgba(255,255,240,${k})`);
          g.addColorStop(0.5, `rgba(255,220,120,${k * 0.6})`);
          g.addColorStop(1, "rgba(255,200,100,0)");
          ctx.fillStyle = g;
          ctx.beginPath();
          ctx.arc(p.x, p.y - p.z, r, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
        case "leaf": {
          ctx.save();
          ctx.globalAlpha = Math.min(1, k * 3, (p.max - p.life) * 2);
          ctx.translate(p.x, p.y - p.z);
          ctx.rotate(p.rot + this.time * 2);
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.ellipse(0, 0, p.size, p.size * 0.5, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          break;
        }
        case "fire": {
          const r = p.size * k;
          ctx.fillStyle = k > 0.5 ? "rgba(255,210,90,0.9)" : "rgba(235,110,40,0.8)";
          ctx.beginPath();
          ctx.arc(p.x, p.y - p.z, r, 0, Math.PI * 2);
          ctx.fill();
          break;
        }
      }
    }
  }

  drawPreview(ctx: CanvasRenderingContext2D) {
    if (this.state !== "playing") return;
    const tc = TEAM_COLORS[0];
    if (this.pendingCannon) {
      const ok = this.inZone(this.mouse.x, this.mouse.y) && this.gold[0] >= CANNON_DEF.cost;
      ctx.save();
      ctx.globalAlpha = 0.3;
      ctx.strokeStyle = "#fff";
      ctx.setLineDash([6, 6]);
      ctx.lineDashOffset = -this.time * 20;
      ctx.beginPath();
      ctx.ellipse(this.mouse.x, this.mouse.y, CANNON_DEF.range, CANNON_DEF.range * 0.55, 0, -0.6, 0.6);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = ok ? 0.8 : 0.35;
      drawShadow(ctx, this.mouse.x, this.mouse.y, 13);
      ctx.translate(this.mouse.x, this.mouse.y + Math.sin(this.time * 6) * 2 - 3);
      ctx.scale(US, US);
      drawFigure(ctx, { team: 0, type: "cannon", walk: this.time * 3, moving: false, atk: 0, flash: false });
      ctx.restore();
      ctx.font = "700 13px 'Alegreya SC', Georgia, serif";
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(20,14,8,0.8)";
      const lbl = ok ? `Klik: Meriam • ${CANNON_DEF.cost} emas` : "Tidak bisa ditempatkan";
      ctx.strokeText(lbl, this.mouse.x, this.mouse.y - 34);
      ctx.fillStyle = ok ? "#ffe9c9" : "#ffb3a8";
      ctx.fillText(lbl, this.mouse.x, this.mouse.y - 34);
      return;
    }
    if (this.pendingHero) {
      const ok = this.inZone(this.mouse.x, this.mouse.y);
      const b = Math.sin(this.time * 6) * 2;
      ctx.save();
      ctx.globalAlpha = ok ? 0.75 : 0.35;
      ctx.strokeStyle = "#f2c23a";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.ellipse(this.mouse.x, this.mouse.y, 16, 6, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.translate(this.mouse.x, this.mouse.y + b - 4);
      ctx.scale(1.5 * US, 1.5 * US);
      drawFigure(ctx, { team: 0, type: "hero", hero: this.pendingHero, walk: this.time * 8, moving: true, atk: 0, flash: false });
      ctx.restore();
      ctx.font = "700 12px 'Alegreya SC', Georgia, serif";
      ctx.textAlign = "center";
      ctx.fillStyle = ok ? "#f6d36b" : "#ffb3a8";
      ctx.fillText(ok ? "Klik untuk memanggil " + HERO_DEFS[this.pendingHero].name : "Di luar zona", this.mouse.x, this.mouse.y - 40);
      return;
    }
    if (!this.drawing) return;
    const pts = this.drawing.concat([{ x: this.mouse.x, y: this.mouse.y }]);
    // path stroke
    ctx.save();
    ctx.strokeStyle = "rgba(255,240,220,0.35)";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.stroke();
    ctx.strokeStyle = tc.light;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -this.time * 30;
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    const samples = this.samplePath(pts, 0, this.selected);
    const enough = this.gold[0] >= UNIT_DEFS[this.selected].cost;
    samples.forEach((p, i) => {
      const b = Math.abs(Math.sin(this.time * 9 + i * 0.5)) * 3;
      ctx.save();
      ctx.globalAlpha = enough ? 0.7 : 0.35;
      drawShadow(ctx, p.x, p.y, 4.5 * US);
      ctx.translate(p.x, p.y - b);
      ctx.scale(US, US * (1 + b * 0.03));
      drawFigure(ctx, { team: 0, type: this.selected, walk: 0, moving: false, atk: 0, flash: !enough && Math.sin(this.time * 20) > 0 });
      ctx.restore();
    });
    const last = pts[pts.length - 1];
    const label = `20 × ${UNIT_DEFS[this.selected].name}  •  ${UNIT_DEFS[this.selected].cost} emas`;
    ctx.font = "700 13px 'Alegreya SC', Georgia, serif";
    ctx.textAlign = "left";
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(20,14,8,0.85)";
    ctx.strokeText(label, last.x + 14, last.y - 14);
    ctx.fillStyle = enough ? "#ffe9c9" : "#ff9a8a";
    ctx.fillText(label, last.x + 14, last.y - 14);
  }

  counts() {
    let a = 0;
    let b = 0;
    for (const u of this.units) {
      if (u.team === 0) a++;
      else b++;
    }
    return [a, b];
  }
}
