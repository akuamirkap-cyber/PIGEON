import { useCallback, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { Game } from "./game/engine";
import type { BasicType } from "./game/engine";
import {
  CANNON_DEF,
  CASTLE_HP,
  GOLD_MAX,
  H,
  HERO_COST,
  HERO_DEFS,
  PLAYER_HEROES,
  TYPE_ICON,
  TYPE_NAME,
  UNIT_DEFS,
  W,
  WAVE_TIME,
} from "./game/constants";
import type { Difficulty, HeroKind } from "./game/constants";
import { sfx } from "./game/audio";
import UnitIcon from "./components/UnitIcon";

interface Snap {
  state: Game["state"];
  gold: number;
  hp: [number, number];
  time: number;
  selected: BasicType;
  pendingHero: HeroKind | null;
  pendingCannon: boolean;
  heroCd: Record<string, number>;
  counts: number[];
  stats: Game["stats"];
  hint: number;
  phaseT: number;
  wave: number;
  ready: [Record<string, number>, Record<string, number>];
  income: number;
  lastIncome: number[];
  cannons: number;
  blood: boolean;
}

const TYPES: BasicType[] = ["sword", "spear", "archer", "cavalry"];
const INK = "#3b2a1a";

function fmtTime(t: number) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function snap(g: Game): Snap {
  return {
    state: g.state,
    gold: g.gold[0],
    hp: [g.castles[0].hp, g.castles[1].hp],
    time: g.time,
    selected: g.selected,
    pendingHero: g.pendingHero,
    pendingCannon: g.pendingCannon,
    heroCd: { ...g.heroCd },
    counts: g.counts(),
    stats: { ...g.stats },
    hint: g.hint,
    phaseT: g.phaseT,
    wave: g.wave,
    ready: [g.readyCounts(0), g.readyCounts(1)],
    income: g.income(),
    lastIncome: [...g.lastIncome],
    cannons: g.cannonCount(0),
    blood: g.blood,
  };
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  if (!gameRef.current) gameRef.current = new Game();
  const game = gameRef.current;

  const [stage, setStage] = useState({ w: 1280, h: 720 });
  const [ui, setUi] = useState<Snap>(() => snap(game));
  const [goldFx, setGoldFx] = useState<{ k: number; cls: string }>({ k: 0, cls: "" });
  const [diff, setDiff] = useState<Difficulty>("normal");
  const [muted, setMuted] = useState(false);
  const [hpFx, setHpFx] = useState([0, 0]);
  const [launchKey, setLaunchKey] = useState(0);
  const [tickKey, setTickKey] = useState(0);
  const lastHp = useRef([CASTLE_HP, CASTLE_HP]);

  useEffect(() => {
    const onResize = () => {
      const w = Math.min(window.innerWidth, (window.innerHeight * 16) / 9);
      setStage({ w: Math.floor(w), h: Math.floor((w * 9) / 16) });
    };
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  useEffect(() => {
    const cv = canvasRef.current!;
    const ctx = cv.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.floor(stage.w * dpr);
    cv.height = Math.floor(stage.h * dpr);
    let raf = 0;
    let last = performance.now();
    let uiT = 0;
    const loop = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      game.update(dt);
      sfx.ambientTick(Math.min(dt, 0.1));
      const s = (stage.w / W) * dpr;
      ctx.setTransform(s, 0, 0, s, 0, 0);
      game.render(ctx);
      uiT += dt;
      if (uiT > 0.05) {
        uiT = 0;
        setUi(snap(game));
        for (const e of game.events) {
          if (e.type === "nogold") setGoldFx((g) => ({ k: g.k + 1, cls: "shake-x" }));
          if (e.type === "deploy" || e.type === "hero" || e.type === "refund") setGoldFx((g) => ({ k: g.k + 1, cls: "squish" }));
          if (e.type === "launch") {
            setLaunchKey((k) => k + 1);
            setGoldFx((g) => ({ k: g.k + 1, cls: "squish" }));
          }
          if (e.type === "tick") setTickKey((k) => k + 1);
        }
        game.events.length = 0;
        const hp = [game.castles[0].hp, game.castles[1].hp];
        setHpFx((f) => [hp[0] < lastHp.current[0] ? f[0] + 1 : f[0], hp[1] < lastHp.current[1] ? f[1] + 1 : f[1]]);
        lastHp.current = hp;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [stage, game]);

  const toLogical = useCallback((e: { clientX: number; clientY: number }) => {
    const r = canvasRef.current!.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * W, y: ((e.clientY - r.top) / r.height) * H };
  }, []);

  useEffect(() => {
    const up = () => game.pointerUp();
    const move = (e: PointerEvent) => {
      const p = toLogical(e);
      game.pointerMove(p.x, p.y);
    };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointermove", move);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointermove", move);
    };
  }, [game, toLogical]);

  const selectType = useCallback(
    (t: BasicType) => {
      game.selected = t;
      game.pendingHero = null;
      game.pendingCannon = false;
      sfx.ensure();
      sfx.click();
      setUi(snap(game));
    },
    [game]
  );
  const pickHero = useCallback(
    (h: HeroKind) => {
      sfx.ensure();
      game.selectHero(h);
      setUi(snap(game));
    },
    [game]
  );
  const pickCannon = useCallback(() => {
    sfx.ensure();
    game.selectCannon();
    setUi(snap(game));
  }, [game]);
  const togglePause = useCallback(() => {
    if (game.state === "playing") game.state = "paused";
    else if (game.state === "paused") game.state = "playing";
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const toggleMute = useCallback(() => {
    sfx.setMuted(!sfx.muted);
    setMuted(sfx.muted);
  }, []);
  const toggleBlood = useCallback(() => {
    game.blood = !game.blood;
    if (!game.blood) game.decals = game.decals.filter((d) => d.kind === "crater");
    sfx.click();
    setUi(snap(game));
  }, [game]);
  const startGame = useCallback(
    (d: Difficulty) => {
      sfx.ensure();
      sfx.startAmbient();
      game.start(d);
      lastHp.current = [CASTLE_HP, CASTLE_HP];
      setUi(snap(game));
    },
    [game]
  );
  const toMenu = useCallback(() => {
    game.reset(game.diff);
    game.state = "menu";
    game.spawnDemo();
    sfx.click();
    setUi(snap(game));
  }, [game]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "escape" || k === "p") {
        if (game.pendingHero || game.drawing || game.pendingCannon) {
          game.pendingHero = null;
          game.drawing = null;
          game.pendingCannon = false;
        } else togglePause();
        return;
      }
      if (k === "m") return toggleMute();
      if (game.state !== "playing") return;
      const idx = ["1", "2", "3", "4"].indexOf(k);
      if (idx >= 0) selectType(TYPES[idx]);
      if (k === "5") pickCannon();
      const hidx = ["q", "w", "e", "r"].indexOf(k);
      if (hidx >= 0) pickHero(PLAYER_HEROES[hidx]);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [game, togglePause, toggleMute, selectType, pickHero, pickCannon]);

  const scale = stage.w / W;
  const playing = ui.state === "playing" || ui.state === "paused";

  return (
    <div className="w-full h-full flex items-center justify-center bg-[#1d2a14]">
      <div className="relative overflow-hidden shadow-2xl" style={{ width: stage.w, height: stage.h }}>
        <canvas
          ref={canvasRef}
          className="absolute inset-0 block"
          style={{ width: stage.w, height: stage.h, cursor: "crosshair", touchAction: "none" }}
          onContextMenu={(e) => e.preventDefault()}
          onPointerDown={(e) => {
            const p = toLogical(e);
            game.pointerMove(p.x, p.y);
            game.pointerDown(p.x, p.y, e.button);
          }}
        />
        <div
          className="absolute top-0 left-0 pointer-events-none font-body"
          style={{ width: W, height: H, transform: `scale(${scale})`, transformOrigin: "top left" }}
        >
          {playing && (
            <>
              <TopBar ui={ui} hpFx={hpFx} tickKey={tickKey} />
              <IntelPanel ui={ui} />
              {launchKey > 0 && <LaunchBanner key={launchKey} wave={ui.wave - 1} income={ui.lastIncome[0]} />}
              <BottomBar
                ui={ui}
                goldFx={goldFx}
                onSelect={selectType}
                onHero={pickHero}
                onCannon={pickCannon}
                onPause={togglePause}
                onMute={toggleMute}
                onBlood={toggleBlood}
                muted={muted}
              />
              {ui.hint > 0 && ui.state === "playing" && (
                <div className="absolute left-[418px] top-[560px] -translate-x-1/2 pointer-events-none floaty">
                  <div className="parch rounded-2xl px-5 py-2.5 text-center">
                    <div className="font-title text-[19px] ink-text leading-tight">🖱️ Tahan &amp; seret di zona merah</div>
                    <div className="text-[14px] text-[#6b4a2c] leading-tight">
                      20 prajurit berbaris mengikuti garismu &amp; maju saat terompet tiap {WAVE_TIME} detik
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          {ui.state === "menu" && <Menu diff={diff} setDiff={setDiff} onStart={startGame} blood={ui.blood} onBlood={toggleBlood} />}
          {ui.state === "paused" && <PauseOverlay onResume={togglePause} onMenu={toMenu} blood={ui.blood} onBlood={toggleBlood} />}
          {(ui.state === "won" || ui.state === "lost") && <EndOverlay ui={ui} onRetry={() => startGame(game.diff)} onMenu={toMenu} />}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */

function Ribbon({ children, color = "#c8323a", dark = "#7d1d22", className = "" }: { children: ReactNode; color?: string; dark?: string; className?: string }) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <span className="absolute -left-3 top-[6px] w-5 h-[calc(100%-2px)]" style={{ background: dark, clipPath: "polygon(0 0,100% 0,100% 100%,0 100%,40% 50%)" }} />
      <span className="absolute -right-3 top-[6px] w-5 h-[calc(100%-2px)]" style={{ background: dark, clipPath: "polygon(0 0,100% 0,60% 50%,100% 100%,0 100%)" }} />
      <span
        className="relative px-4 py-0.5 font-title text-[#fff4e0] border-[3px] rounded-[4px] whitespace-nowrap"
        style={{ background: `linear-gradient(180deg, ${color}, ${dark})`, borderColor: INK, textShadow: `0 2px 0 ${INK}` }}
      >
        {children}
      </span>
    </div>
  );
}

function HpPlate({ hp, side, fx }: { hp: number; side: 0 | 1; fx: number }) {
  const frac = Math.max(0, hp / CASTLE_HP);
  const color = side === 0 ? "#d8383f" : "#4672d6";
  const dark = side === 0 ? "#8a1f25" : "#263f80";
  const danger = frac < 0.3;
  return (
    <div className={`parch rounded-2xl px-3 py-2 flex items-center gap-3 w-[400px] ${side === 1 ? "flex-row-reverse" : ""}`}>
      <div className="relative shrink-0">
        <div
          className="w-[52px] h-[52px] rounded-xl border-[3px] flex items-center justify-center text-[28px]"
          style={{ background: `linear-gradient(180deg, ${color}, ${dark})`, borderColor: INK, boxShadow: `0 3px 0 ${INK}` }}
        >
          🏰
        </div>
      </div>
      <div className={`flex-1 ${side === 1 ? "text-right" : ""}`}>
        <div className={`flex items-baseline justify-between ${side === 1 ? "flex-row-reverse" : ""}`}>
          <span className="font-title text-[19px] ink-text leading-none">{side === 0 ? "Istana Merah" : "Istana Biru"}</span>
          <span className={`text-[13px] font-bold ${danger ? "text-[#c0282e]" : "text-[#6b4a2c]"}`}>{Math.ceil(hp)}</span>
        </div>
        <div key={fx} className={`relative mt-1.5 h-[20px] rounded-full border-[3px] overflow-hidden ${fx ? "squish" : ""}`} style={{ borderColor: INK, background: "#5a3a22" }}>
          <div className="absolute top-0 h-full bg-[#fff1cf] transition-[width] duration-700" style={{ width: `${frac * 100}%`, [side === 0 ? "left" : "right"]: 0 }} />
          <div
            className="absolute top-0 h-full transition-[width] duration-150"
            style={{ width: `${frac * 100}%`, background: `linear-gradient(180deg, ${color}, ${dark})`, [side === 0 ? "left" : "right"]: 0 }}
          />
          <div className="absolute inset-x-0 top-0 h-[40%] bg-white/25" />
          <div className="absolute inset-0 flex">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="flex-1 border-r border-black/15" />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function TopBar({ ui, hpFx, tickKey }: { ui: Snap; hpFx: number[]; tickKey: number }) {
  const frac = Math.max(0, ui.phaseT / WAVE_TIME);
  const urgent = ui.phaseT <= 3;
  const R = 36;
  const C = 2 * Math.PI * R;
  return (
    <div className="absolute top-3 left-4 right-4 flex items-start justify-between">
      <HpPlate hp={ui.hp[0]} side={0} fx={hpFx[0]} />
      <div className="flex flex-col items-center -mt-1">
        <div key={urgent ? tickKey : -1} className={`relative w-[100px] h-[100px] ${urgent ? "squish" : ""}`}>
          <div className="absolute inset-0 rounded-full border-[3px]" style={{ borderColor: INK, background: "linear-gradient(180deg,#8a5d36,#5a3a20)", boxShadow: `0 4px 0 ${INK}` }} />
          <div className="absolute inset-[9px] rounded-full parch !shadow-none !border-2" />
          <svg width="100" height="100" className="absolute inset-0 -rotate-90">
            <circle cx="50" cy="50" r={R} fill="none" stroke="rgba(59,42,26,0.18)" strokeWidth="6" />
            <circle
              cx="50"
              cy="50"
              r={R}
              fill="none"
              stroke={urgent ? "#d63b3b" : "#e0a82e"}
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={C * (1 - frac)}
            />
          </svg>
          <div className={`absolute inset-0 flex flex-col items-center justify-center ${urgent ? "urgent" : ""}`}>
            <span className="font-title text-[38px] leading-none" style={{ color: urgent ? "#c0282e" : INK }}>
              {Math.ceil(ui.phaseT)}
            </span>
            <span className="text-[10px] font-bold tracking-wider text-[#6b4a2c] -mt-0.5">{urgent ? "BERSIAP!" : "DETIK"}</span>
          </div>
        </div>
        <Ribbon className="-mt-3 text-[16px]">Gelombang {ui.wave}</Ribbon>
        <div className="mt-1.5 parch rounded-full px-3 py-0.5 flex items-center gap-2 text-[13px] font-bold !shadow-[0_2px_0_#3b2a1a]">
          <span className="text-[#c0282e]">⚔ {ui.counts[0]}</span>
          <span className="text-[#8a6a48]">•</span>
          <span className="ink-text">⏱ {fmtTime(ui.time)}</span>
          <span className="text-[#8a6a48]">•</span>
          <span className="text-[#2c55b8]">{ui.counts[1]} ⚔</span>
        </div>
      </div>
      <HpPlate hp={ui.hp[1]} side={1} fx={hpFx[1]} />
    </div>
  );
}

function ReadyChips({ counts, team }: { counts: Record<string, number>; team: 0 | 1 }) {
  const keys = ["sword", "spear", "archer", "cavalry", "cannon", "hero"].filter((k) => counts[k] > 0);
  if (!keys.length) return <span className="text-[13px] italic text-[#8a6a48]">belum ada</span>;
  return (
    <div className={`flex gap-1 ${team === 1 ? "flex-row-reverse" : ""}`}>
      {keys.map((k) => (
        <span
          key={k + counts[k]}
          className="pop-in inline-flex items-center gap-0.5 px-1.5 py-[1px] rounded-md text-[12px] font-bold text-white border-2"
          style={{ background: team === 0 ? "#b02e34" : "#3459b0", borderColor: INK }}
          title={TYPE_NAME[k]}
        >
          {TYPE_ICON[k]}×{counts[k]}
        </span>
      ))}
    </div>
  );
}

function IntelPanel({ ui }: { ui: Snap }) {
  return (
    <>
      <div className="absolute top-[92px] left-6 parch rounded-xl px-2.5 py-1 flex items-center gap-2 !shadow-[0_3px_0_#3b2a1a]">
        <span className="font-title text-[13px] text-[#b02e34]">🚩 Siap maju</span>
        <ReadyChips counts={ui.ready[0]} team={0} />
      </div>
      <div className="absolute top-[92px] right-6 parch rounded-xl px-2.5 py-1 flex items-center gap-2 flex-row-reverse !shadow-[0_3px_0_#3b2a1a]">
        <span className="font-title text-[13px] text-[#3459b0]">👁 Mata-mata</span>
        <ReadyChips counts={ui.ready[1]} team={1} />
      </div>
    </>
  );
}

function LaunchBanner({ wave, income }: { wave: number; income: number }) {
  const [show, setShow] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setShow(false), 1750);
    return () => clearTimeout(t);
  }, []);
  if (!show) return null;
  return (
    <div className="absolute left-1/2 top-[250px] -translate-x-1/2 pointer-events-none fade-out-up">
      <div className="slam flex flex-col items-center">
        <div className="relative">
          <div className="absolute -left-10 top-6 w-16 h-[74px]" style={{ background: "#7d1d22", clipPath: "polygon(0 0,100% 0,100% 100%,0 100%,35% 50%)" }} />
          <div className="absolute -right-10 top-6 w-16 h-[74px]" style={{ background: "#7d1d22", clipPath: "polygon(0 0,100% 0,65% 50%,100% 100%,0 100%)" }} />
          <div
            className="relative shine overflow-hidden px-12 py-2 border-[4px] rounded-md"
            style={{ background: "linear-gradient(180deg,#e04148,#a3242b)", borderColor: INK, boxShadow: `0 8px 0 ${INK}` }}
          >
            <div className="font-title text-[78px] leading-none text-[#fff3d6] tracking-wide" style={{ textShadow: `0 4px 0 ${INK}, 0 0 24px rgba(255,220,150,0.5)` }}>
              ⚔ SERBU! ⚔
            </div>
          </div>
        </div>
        <div className="mt-4 parch rounded-full px-5 py-1 font-title text-[19px] ink-text">
          Gelombang {wave} maju • <span className="text-[#b07a10]">+{income} emas</span>
        </div>
      </div>
    </div>
  );
}

function CoinBadge({ cost, ok }: { cost: number; ok: boolean }) {
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-[1px] rounded-full border-2 text-[13px] font-bold"
      style={{ borderColor: INK, background: ok ? "linear-gradient(180deg,#ffe28a,#e0a82e)" : "#d9c5a2", color: ok ? INK : "#8a6a48" }}
    >
      ◈ {cost}
    </span>
  );
}

function Hotkey({ k }: { k: string }) {
  return (
    <span className="absolute -top-2 -left-2 w-6 h-6 rounded-full border-2 flex items-center justify-center font-title text-[13px] text-[#fff4e0] z-10" style={{ background: INK, borderColor: "#f1dfb6" }}>
      {k}
    </span>
  );
}

function BottomBar({
  ui,
  goldFx,
  onSelect,
  onHero,
  onCannon,
  onPause,
  onMute,
  onBlood,
  muted,
}: {
  ui: Snap;
  goldFx: { k: number; cls: string };
  onSelect: (t: BasicType) => void;
  onHero: (h: HeroKind) => void;
  onCannon: () => void;
  onPause: () => void;
  onMute: () => void;
  onBlood: () => void;
  muted: boolean;
}) {
  return (
    <div className="absolute bottom-0 left-3 right-3 h-[150px] wood rounded-t-[26px] px-4 pt-4 flex items-start gap-3">
      <div className="absolute top-2 left-3 nail" />
      <div className="absolute top-2 right-3 nail" />
      {/* gold pouch */}
      <div key={goldFx.k} className={`pointer-events-auto w-[150px] parch rounded-2xl px-3 py-2 ${goldFx.cls}`}>
        <div className="flex items-center gap-2">
          <div
            className="w-11 h-11 rounded-full border-[3px] flex items-center justify-center font-title text-[20px]"
            style={{ borderColor: INK, background: "radial-gradient(circle at 35% 30%, #fff1b0, #f2c23a 55%, #b8860b)", color: "#6b4a10", boxShadow: `0 3px 0 ${INK}` }}
          >
            ◈
          </div>
          <div>
            <div className="font-title text-[30px] leading-none ink-text">{Math.floor(ui.gold)}</div>
            <div className="text-[11px] font-bold text-[#8a6a48] leading-none mt-0.5">EMAS</div>
          </div>
        </div>
        <div className="mt-2 h-[9px] rounded-full border-2 overflow-hidden" style={{ borderColor: INK, background: "#5a3a22" }}>
          <div className="h-full" style={{ width: `${(ui.gold / GOLD_MAX) * 100}%`, background: "linear-gradient(90deg,#e0a82e,#ffe28a)" }} />
        </div>
        <div className="text-[11px] text-[#6b4a2c] mt-1 leading-none">+{ui.income} tiap gelombang</div>
      </div>

      {/* squads */}
      <div className="flex gap-2.5">
        {TYPES.map((t) => {
          const d = UNIT_DEFS[t];
          const sel = ui.selected === t && !ui.pendingHero && !ui.pendingCannon;
          const afford = ui.gold >= d.cost;
          return (
            <button
              key={t}
              onClick={() => onSelect(t)}
              className={`card-btn pointer-events-auto relative w-[104px] h-[122px] rounded-2xl parch flex flex-col items-center pt-0.5 ${sel ? "-translate-y-3 pulse-glow" : ""} ${
                afford ? "" : "grayscale-[0.7] opacity-75"
              }`}
              style={sel ? { background: "linear-gradient(180deg,#fff6dc,#f6d98e)" } : undefined}
            >
              <Hotkey k={d.key} />
              <span className="absolute top-1 right-1.5 text-[10px] font-bold text-white px-1 rounded" style={{ background: INK }}>
                ×20
              </span>
              <UnitIcon type={t} size={56} zoom={t === "cavalry" ? 2.2 : 2.7} animate={sel} />
              <div className="font-title text-[15px] ink-text leading-none">{d.name}</div>
              <div className="text-[10px] text-[#8a5a2c] leading-tight mt-0.5 mb-1">{d.desc}</div>
              <CoinBadge cost={d.cost} ok={afford} />
            </button>
          );
        })}
        {/* cannon */}
        {(() => {
          const sel = ui.pendingCannon;
          const afford = ui.gold >= CANNON_DEF.cost && ui.cannons < CANNON_DEF.max;
          return (
            <button
              onClick={onCannon}
              className={`card-btn pointer-events-auto relative w-[104px] h-[122px] rounded-2xl parch flex flex-col items-center pt-0.5 ${sel ? "-translate-y-3 pulse-glow" : ""} ${
                afford ? "" : "grayscale-[0.7] opacity-75"
              }`}
              style={sel ? { background: "linear-gradient(180deg,#fff6dc,#f6d98e)" } : { background: "linear-gradient(180deg,#f3ead8,#ddd0b4)" }}
            >
              <Hotkey k={CANNON_DEF.key} />
              <span className="absolute top-1 right-1.5 text-[10px] font-bold text-white px-1 rounded" style={{ background: INK }}>
                {ui.cannons}/{CANNON_DEF.max}
              </span>
              <UnitIcon type="cannon" size={56} zoom={2.2} animate={sel} />
              <div className="font-title text-[15px] ink-text leading-none">{CANNON_DEF.name}</div>
              <div className="text-[10px] text-[#8a5a2c] leading-tight mt-0.5 mb-1">Ledakan & hancurkan istana</div>
              <CoinBadge cost={CANNON_DEF.cost} ok={afford} />
            </button>
          );
        })()}
      </div>

      <div className="w-[3px] self-stretch my-2 rounded bg-black/30" />

      {/* heroes */}
      <div className="flex gap-2">
        {PLAYER_HEROES.map((h) => {
          const d = HERO_DEFS[h];
          const cd = ui.heroCd[h] ?? 0;
          const ready = cd <= 0;
          const sel = ui.pendingHero === h;
          const frac = cd / d.cooldown;
          const afford = ui.gold >= HERO_COST;
          return (
            <button
              key={h}
              onClick={() => onHero(h)}
              title={`${d.name} — ${d.title}`}
              className={`card-btn pointer-events-auto relative w-[96px] h-[122px] rounded-2xl flex flex-col items-center pt-0.5 border-[3px] ${sel ? "-translate-y-3 pulse-glow" : ""}`}
              style={{
                borderColor: INK,
                background: "linear-gradient(180deg,#fff3c4,#e9c66a)",
                boxShadow: `0 4px 0 ${INK}, inset 0 0 0 2px #fff7d6, inset 0 0 0 4px #c99a2e`,
              }}
            >
              <Hotkey k={d.key} />
              <UnitIcon type="hero" hero={h} size={54} zoom={h === "renold" ? 2.0 : 2.35} animate={sel || ready} />
              <div className="font-title text-[12px] ink-text leading-[1.05] text-center px-1 h-[26px] flex items-center">{d.name}</div>
              <div className="mt-0.5">
                <CoinBadge cost={HERO_COST} ok={afford} />
              </div>
              {!ready && (
                <div
                  className="absolute inset-0 rounded-[13px] flex items-center justify-center"
                  style={{ background: `conic-gradient(rgba(40,25,10,0.72) ${frac * 360}deg, rgba(40,25,10,0.2) 0deg)` }}
                >
                  <span className="font-title text-[28px] text-[#fff4e0]" style={{ textShadow: `0 2px 0 ${INK}` }}>
                    {Math.ceil(cd)}
                  </span>
                </div>
              )}
            </button>
          );
        })}
      </div>

      <div className="flex-1" />
      <div className="grid grid-cols-1 gap-1.5">
        {[
          { label: "❚❚", on: onPause, title: "Jeda (Esc)" },
          { label: muted ? "🔇" : "🔊", on: onMute, title: "Suara (M)" },
          { label: ui.blood ? "🩸" : "💧", on: onBlood, title: "Darah on/off" },
        ].map((b) => (
          <button
            key={b.title}
            title={b.title}
            onClick={b.on}
            className="menu-btn pointer-events-auto w-[42px] h-[38px] rounded-xl parch !shadow-[0_3px_0_#3b2a1a] text-[17px] ink-text font-bold"
          >
            {b.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`pop-in pointer-events-auto parch rounded-[28px] ${className}`}>{children}</div>;
}

function BigBtn({ children, onClick, color = "#d8383f", dark = "#8a1f25" }: { children: ReactNode; onClick: () => void; color?: string; dark?: string }) {
  return (
    <button
      onClick={onClick}
      className="menu-btn pointer-events-auto font-title text-[26px] text-[#fff4e0] px-10 py-2.5 rounded-2xl border-[3px]"
      style={{
        borderColor: INK,
        background: `linear-gradient(180deg, ${color}, ${dark})`,
        boxShadow: `0 6px 0 ${INK}, inset 0 3px 0 rgba(255,255,255,0.3)`,
        textShadow: `0 2px 0 ${INK}`,
      }}
    >
      {children}
    </button>
  );
}

function Toggle({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} className="menu-btn pointer-events-auto flex items-center gap-2 font-title text-[15px] ink-text">
      <span className="relative w-11 h-6 rounded-full border-[3px] transition-colors" style={{ borderColor: INK, background: on ? "#c8323a" : "#bba98a" }}>
        <span className="absolute top-[1px] w-4 h-4 rounded-full bg-[#fff4e0] border-2 transition-all" style={{ borderColor: INK, left: on ? 20 : 1 }} />
      </span>
      {label}
    </button>
  );
}

function Menu({
  diff,
  setDiff,
  onStart,
  blood,
  onBlood,
}: {
  diff: Difficulty;
  setDiff: (d: Difficulty) => void;
  onStart: (d: Difficulty) => void;
  blood: boolean;
  onBlood: () => void;
}) {
  const diffs: [Difficulty, string][] = [
    ["easy", "Mudah"],
    ["normal", "Normal"],
    ["hard", "Sulit"],
  ];
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#1d2a14]/25">
      <div className="pop-in flex items-end justify-center gap-4 mb-3">
        <UnitIcon type="hero" hero="renold" size={120} zoom={4.4} animate />
        <div className="text-center">
          <div className="font-title text-[100px] leading-[0.85] text-[#fff4e0] tracking-wide" style={{ textShadow: `0 6px 0 ${INK}, 0 0 30px rgba(0,0,0,0.25)`, WebkitTextStroke: `3px ${INK}` }}>
            Tiny Banners
          </div>
          <Ribbon className="mt-3 text-[22px]">Perang Mini • Gambar Barisanmu</Ribbon>
        </div>
        <UnitIcon type="cannon" team={1} size={120} zoom={4.2} animate />
      </div>

      <Panel className="px-9 py-6 w-[880px]">
        <div className="grid grid-cols-4 gap-4 ink-text text-[14px] leading-snug mb-4">
          {[
            ["🖱️", "Gambar barisan", "Seret mouse membentuk ( > , | , — ). Satu garis = 20 prajurit."],
            ["📯", `Tiap ${WAVE_TIME} detik`, "Terompet berbunyi, semua barisan siap menyerbu serentak."],
            ["👁️", "Saling mengintai", "Lihat persiapan musuh — musuh juga membaca & menangkalmu."],
            ["💣", "Meriam", "Ledakan area & penghancur istana. Lemah lawan kavaleri."],
          ].map(([i, t, d]) => (
            <div key={t} className="rounded-xl bg-[#3b2a1a]/[0.06] border-2 border-[#3b2a1a]/15 p-2.5">
              <div className="text-[26px] leading-none">{i}</div>
              <div className="font-title text-[17px] text-[#a3242b] mt-1">{t}</div>
              <div className="text-[13px] text-[#5a3f26]">{d}</div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-1.5 mb-3 text-[14px] ink-text">
          <span className="font-title text-[#a3242b] mr-1">Saling tangkal:</span>
          {["sword", "spear", "cavalry", "archer", "sword"].map((k, i) => (
            <span key={i} className="flex items-center gap-1.5">
              {i > 0 && <span className="font-bold text-[#b07a10]">›</span>}
              <span className="px-2 py-0.5 rounded-lg border-2 bg-[#fff8e6] font-bold" style={{ borderColor: INK }}>
                {TYPE_ICON[k]} {TYPE_NAME[k]}
              </span>
            </span>
          ))}
        </div>
        <div className="text-[12.5px] text-[#6b4a2c] text-center mb-4">
          <b>1-4</b> pasukan • <b>5</b> meriam • <b>Q W E R</b> hero • <b>Klik kanan barisan siap</b> = batal &amp; uang kembali • <b>Esc</b> jeda • <b>M</b> suara
        </div>
        <div className="flex items-center justify-center gap-6 mb-5">
          <div className="flex gap-2">
            {diffs.map(([d, label]) => (
              <button
                key={d}
                onClick={() => {
                  setDiff(d);
                  sfx.ensure();
                  sfx.click();
                }}
                className="menu-btn pointer-events-auto font-title text-[17px] px-5 py-1.5 rounded-xl border-[3px]"
                style={{
                  borderColor: INK,
                  background: diff === d ? "linear-gradient(180deg,#ffe28a,#e0a82e)" : "#efe0bf",
                  boxShadow: `0 4px 0 ${INK}`,
                  color: INK,
                }}
              >
                {label}
              </button>
            ))}
          </div>
          <Toggle on={blood} onClick={onBlood} label="Darah" />
        </div>
        <div className="flex justify-center">
          <BigBtn onClick={() => onStart(diff)}>⚔ Mulai Perang</BigBtn>
        </div>
      </Panel>
    </div>
  );
}

function PauseOverlay({ onResume, onMenu, blood, onBlood }: { onResume: () => void; onMenu: () => void; blood: boolean; onBlood: () => void }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#1d2a14]/45">
      <Panel className="px-14 pt-6 pb-9 text-center">
        <Ribbon className="text-[30px] mb-6">Jeda</Ribbon>
        <div className="flex flex-col gap-5 items-center">
          <BigBtn onClick={onResume}>▶ Lanjut</BigBtn>
          <BigBtn onClick={onMenu} color="#8a6a48" dark="#5a3f26">
            ⌂ Menu
          </BigBtn>
          <Toggle on={blood} onClick={onBlood} label="Darah" />
        </div>
      </Panel>
    </div>
  );
}

function EndOverlay({ ui, onRetry, onMenu }: { ui: Snap; onRetry: () => void; onMenu: () => void }) {
  const won = ui.state === "won";
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#1d2a14]/40">
      <Panel className="px-12 pt-4 pb-8 text-center w-[660px]">
        <div className="flex justify-center -mt-24 mb-1">
          <div className="floaty">
            <UnitIcon type="hero" hero={won ? "renold" : "olaf"} team={won ? 0 : 1} size={130} zoom={won ? 4.4 : 5.2} animate />
          </div>
        </div>
        <Ribbon className="text-[44px]" color={won ? "#e0a82e" : "#5a6a8a"} dark={won ? "#9a6a10" : "#2e3a55"}>
          {won ? "Kemenangan!" : "Kekalahan..."}
        </Ribbon>
        <div className="font-title text-[#6b4a2c] text-[19px] mt-3 mb-5">{won ? "Istana biru telah runtuh!" : "Istanamu telah jatuh."}</div>
        <div className="grid grid-cols-3 gap-3 mb-7">
          {[
            ["⏱", fmtTime(ui.time), "Waktu"],
            ["📯", ui.wave - 1, "Gelombang"],
            ["🚩", ui.stats.squads, "Barisan"],
            ["💀", ui.stats.kills, "Musuh tumbang"],
            ["🪦", ui.stats.lost, "Prajurit gugur"],
            ["🏃", ui.stats.fled, "Kabur"],
          ].map(([i, v, l]) => (
            <div key={l as string} className="rounded-2xl border-[3px] py-2 bg-[#fff8e6]" style={{ borderColor: INK, boxShadow: `0 3px 0 ${INK}` }}>
              <div className="text-2xl">{i}</div>
              <div className="font-title ink-text text-[26px] leading-none mt-1">{v}</div>
              <div className="text-[12px] text-[#8a6a48] mt-1">{l}</div>
            </div>
          ))}
        </div>
        <div className="flex justify-center gap-5">
          <BigBtn onClick={onRetry}>↻ Main Lagi</BigBtn>
          <BigBtn onClick={onMenu} color="#8a6a48" dark="#5a3f26">
            ⌂ Menu
          </BigBtn>
        </div>
      </Panel>
    </div>
  );
}
