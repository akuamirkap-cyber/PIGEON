import { useEffect, useRef } from "react";
import { drawFigure, drawShadow, drawBanner } from "../game/draw";
import type { HeroKind, Team, UnitType } from "../game/constants";

interface Props {
  type: UnitType;
  hero?: HeroKind;
  team?: Team;
  size?: number;
  zoom?: number;
  animate?: boolean;
  banner?: boolean;
}

export default function UnitIcon({ type, hero, team = 0, size = 56, zoom = 2.6, animate = false, banner = false }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = size * dpr;
    cv.height = size * dpr;
    const ctx = cv.getContext("2d")!;
    let raf = 0;
    const start = performance.now();
    const paint = () => {
      const t = (performance.now() - start) / 1000;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size, size);
      const mounted = type === "cavalry" || hero === "renold";
      const cx = size / 2 - (mounted ? 3 : 0);
      const cy = size * 0.82;
      if (banner) drawBanner(ctx, size * 0.18, cy, team, t, 0.75, 0, 1, 3);
      drawShadow(ctx, cx, cy, (mounted ? 9 : 5) * zoom * 0.9);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale((team === 0 ? 1 : -1) * zoom, zoom);
      drawFigure(ctx, {
        team,
        type,
        hero,
        walk: t * 9,
        moving: animate,
        atk: animate ? Math.max(0, 1 - ((t * 1.2) % 1.6)) : 0,
        flash: false,
      });
      ctx.restore();
      if (animate) raf = requestAnimationFrame(paint);
    };
    paint();
    return () => cancelAnimationFrame(raf);
  }, [type, hero, team, size, zoom, animate, banner]);
  return <canvas ref={ref} style={{ width: size, height: size }} />;
}
