import * as THREE from 'three';
import {
  createMat,
  getDistressedDenimTexture,
  getSilatDenimTexture,
  getSkillLegTexture,
  getWoodlandCamoTexture,
  makeStylizedMesh,
  PALETTE,
} from '../materials';
import {
  buildLimbBetween,
  createAthleticSportShoe,
  createBeveledBoxGeometry,
  createLoftGeometry,
  createStylizedBoot,
  createTacticalKneePad,
  createTacticalPouch,
  FootAnchors,
} from '../common';
import { createDropLegHolster } from '../weapons';
import { SkinId } from '../types';

export interface ArticulatedLegNodes {
  hipPivot: THREE.Group;
  kneePivot: THREE.Group;
  anklePivot: THREE.Group;
  hipWorld: THREE.Vector3;
  kneeWorld: THREE.Vector3;
  ankleWorld: THREE.Vector3;
  footPos: THREE.Vector3;
  footRotY: number;
  /** 4 exact shoe-sole corner points in anklePivot-local coordinates for exact zero-clip ground clamping */
  solePoints: THREE.Vector3[];
}

export interface ArticulatedLowerRig {
  pelvisGroup: THREE.Group;
  leftLeg: ArticulatedLegNodes;
  rightLeg: ArticulatedLegNodes;
  anchors: FootAnchors;
}

function isLowCutShoe(shoesId: SkinId): boolean {
  return shoesId === 'gold' || shoesId === 'skill' || shoesId === 'silat';
}

/**
 * Builds an articulated 3-joint leg hierarchy (hipPivot -> kneePivot -> anklePivot)
 * using inverse-offset inner containers so meshes authored in standard world coordinates
 * sit identically at rest while articulating smoothly around exact anatomical joints!
 */
function makeLegHierarchy(
  side: 'left' | 'right',
  hipWorld: THREE.Vector3,
  kneeWorld: THREE.Vector3,
  ankleWorld: THREE.Vector3,
  footPos: THREE.Vector3,
  footRotY: number,
  jointMat: THREE.Material,
  hipRadius = 0.088,
  kneeRadius = 0.072
): {
  nodes: ArticulatedLegNodes;
  thighInner: THREE.Group;
  shinInner: THREE.Group;
  footHolder: THREE.Group;
} {
  const hipPivot = new THREE.Group();
  hipPivot.name = `${side}_HipPivot`;
  hipPivot.position.copy(hipWorld);
  hipPivot.userData.rigRole = side === 'left' ? 'leftHipPivot' : 'rightHipPivot';

  const thighInner = new THREE.Group();
  thighInner.position.copy(hipWorld).negate();
  hipPivot.add(thighInner);

  // Smooth rounded hip cap inside pelvis so extreme sprint/crouch hip flexion never leaves a gap!
  const hipCap = makeStylizedMesh(new THREE.SphereGeometry(hipRadius, 10, 7), jointMat, {
    outline: 0.0042,
  });
  hipCap.position.copy(hipWorld);
  thighInner.add(hipCap);

  // Knee pivot nested directly inside hipPivot at exact relative offset (knee - hip)!
  const kneePivot = new THREE.Group();
  kneePivot.name = `${side}_KneePivot`;
  kneePivot.position.copy(kneeWorld);
  kneePivot.userData.rigRole = side === 'left' ? 'leftKneePivot' : 'rightKneePivot';

  const shinInner = new THREE.Group();
  shinInner.position.copy(kneeWorld).negate();
  kneePivot.add(shinInner);

  // Smooth knee joint cap so 115° crouch & sprint bends stay 100% watertight!
  const kneeCap = makeStylizedMesh(new THREE.SphereGeometry(kneeRadius, 10, 7), jointMat, {
    outline: 0.0040,
  });
  kneeCap.position.copy(kneeWorld);
  shinInner.add(kneeCap);

  thighInner.add(kneePivot);

  // Ankle pivot nested inside kneePivot at ankleWorld!
  const anklePivot = new THREE.Group();
  anklePivot.name = `${side}_AnklePivot`;
  anklePivot.position.copy(ankleWorld);
  anklePivot.userData.rigRole = side === 'left' ? 'leftAnklePivot' : 'rightAnklePivot';

  const footHolder = new THREE.Group();
  footHolder.position.copy(ankleWorld).negate();
  anklePivot.add(footHolder);

  shinInner.add(anklePivot);

  // Full 8-point shoe-sole perimeter (toe tip, toe L/R, midfoot L/R, heel L/R, heel back)
  // including outer cel-outline thickness (-0.006m) so zero shoe geometry EVER penetrates y = 0!
  const rawCorners = [
    new THREE.Vector3(0.0, -0.006, 0.176),
    new THREE.Vector3(-0.044, -0.006, 0.162),
    new THREE.Vector3(0.044, -0.006, 0.162),
    new THREE.Vector3(-0.056, -0.006, 0.045),
    new THREE.Vector3(0.056, -0.006, 0.045),
    new THREE.Vector3(-0.052, -0.006, -0.074),
    new THREE.Vector3(0.052, -0.006, -0.074),
    new THREE.Vector3(0.0, -0.006, -0.084),
  ];
  const rotMat = new THREE.Matrix4().makeRotationY(footRotY);
  const solePoints = rawCorners.map((c) =>
    c.applyMatrix4(rotMat).add(footPos).sub(ankleWorld)
  );

  return {
    nodes: {
      hipPivot,
      kneePivot,
      anklePivot,
      hipWorld: hipWorld.clone(),
      kneeWorld: kneeWorld.clone(),
      ankleWorld: ankleWorld.clone(),
      footPos: footPos.clone(),
      footRotY,
      solePoints,
    },
    thighInner,
    shinInner,
    footHolder,
  };
}

// ============================================================================
// CUSTOM SHOE SPECIALS
// ============================================================================
function createSkillSneaker(): THREE.Group {
  const g = new THREE.Group();
  const shoeMat = createMat({ color: PALETTE.skillSneaker, roughness: 0.68 });
  const soleMat = createMat({ color: 0x111216, roughness: 0.85 });
  const laceMat = createMat({ color: PALETTE.skillLaceWhite, roughness: 0.72 });

  const base = createStylizedBoot({
    upperMat: shoeMat,
    lowerMat: shoeMat,
    soleMat,
    dressShoe: true,
    outline: 0.0042,
  });
  g.add(base);

  for (let i = 0; i < 4; i++) {
    const zPos = 0.040 + i * 0.018;
    const yPos = 0.072 - i * 0.008;
    for (const rot of [0.34, -0.34]) {
      const lace = makeStylizedMesh(
        createBeveledBoxGeometry(0.044, 0.0055, 0.006, 0.001),
        laceMat,
        { outline: 0 }
      );
      lace.position.set(0, yPos, zPos);
      lace.rotation.y = rot;
      lace.rotation.x = 0.32;
      g.add(lace);
    }
  }
  return g;
}

function createSurvivalLacedBoot(): THREE.Group {
  const g = new THREE.Group();
  const leatherMat = createMat({ color: PALETTE.spetsBootBrown, roughness: 0.78 });
  const cuffMat = createMat({ color: 0x7c5438, roughness: 0.82 });
  const soleMat = createMat({ color: PALETTE.spetsBootSole, roughness: 0.90 });
  const laceMat = createMat({ color: 0x9b7450, roughness: 0.82 });

  g.add(
    createStylizedBoot({
      upperMat: leatherMat,
      lowerMat: leatherMat,
      soleMat,
      height: 0.235,
      outline: 0.0046,
    })
  );

  g.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.195, rx: 0.062, rz: 0.068, oz: -0.004 },
          { y: 0.238, rx: 0.068, rz: 0.074, oz: -0.004 },
        ],
        10
      ),
      cuffMat,
      { outline: 0.0038 }
    )
  );

  for (let i = 0; i < 4; i++) {
    const yPos = 0.105 + i * 0.028;
    for (const rot of [0.32, -0.32]) {
      const lace = makeStylizedMesh(
        createBeveledBoxGeometry(0.046, 0.007, 0.008, 0.001),
        laceMat,
        { outline: 0.0012 }
      );
      lace.position.set(0, yPos, 0.060 - i * 0.002);
      lace.rotation.z = rot;
      g.add(lace);
    }
  }
  return g;
}

function createSingleShoeById(shoesId: SkinId): THREE.Group {
  if (shoesId === 'boonie') {
    return createStylizedBoot({
      upperMat: createMat({ color: PALETTE.boonieBootUpper, roughness: 0.80 }),
      lowerMat: createMat({ color: PALETTE.boonieBootLower, roughness: 0.78 }),
      soleMat: createMat({ color: PALETTE.boonieBootSole, roughness: 0.90 }),
      height: 0.225,
    });
  }
  if (shoesId === 'venom') {
    const bootMat = createMat({ color: PALETTE.venomBoot, roughness: 0.74 });
    return createStylizedBoot({
      upperMat: bootMat,
      lowerMat: bootMat,
      soleMat: createMat({ color: 0x111215, roughness: 0.90 }),
      height: 0.22,
    });
  }
  if (shoesId === 'gold') {
    const shoeMat = createMat({ color: PALETTE.suitShoe, roughness: 0.44, metalness: 0.16 });
    return createStylizedBoot({
      upperMat: shoeMat,
      lowerMat: shoeMat,
      soleMat: createMat({ color: 0x111214, roughness: 0.84 }),
      dressShoe: true,
    });
  }
  if (shoesId === 'reaper') {
    const bootMat = createMat({ color: PALETTE.reaperBoot, roughness: 0.74 });
    return createStylizedBoot({
      upperMat: bootMat,
      lowerMat: bootMat,
      soleMat: createMat({ color: 0x0f1013, roughness: 0.90 }),
      height: 0.22,
    });
  }
  if (shoesId === 'police') {
    const bootMat = createMat({ color: PALETTE.policeBoot, roughness: 0.72 });
    return createStylizedBoot({
      upperMat: bootMat,
      lowerMat: bootMat,
      soleMat: createMat({ color: 0x0e1013, roughness: 0.90 }),
      height: 0.22,
    });
  }
  if (shoesId === 'gunner') {
    return createStylizedBoot({
      upperMat: createMat({ color: PALETTE.gunnerBoot, roughness: 0.80 }),
      lowerMat: createMat({ color: 0x625c3c, roughness: 0.78 }),
      soleMat: createMat({ color: 0x2a2720, roughness: 0.90 }),
      height: 0.225,
    });
  }
  if (shoesId === 'skill') {
    return createSkillSneaker();
  }
  if (shoesId === 'silat') {
    // Sleek black athletic running/sport sneaker (NON-BOOT!) matching Reference Image 1!
    return createAthleticSportShoe({
      upperMat: createMat({ color: PALETTE.silatSportUpper, roughness: 0.72 }),
      soleMat: createMat({ color: PALETTE.silatSportSole, roughness: 0.84 }),
      accentMat: createMat({ color: PALETTE.silatSportAccent, roughness: 0.65 }),
      outline: 0.0040,
    });
  }
  return createSurvivalLacedBoot();
}

function attachShoeToLeg(
  footHolder: THREE.Group,
  shoesId: SkinId,
  footPos: THREE.Vector3,
  footRotY: number,
  slotIndex: number
) {
  const shoe = createSingleShoeById(shoesId);
  shoe.position.copy(footPos);
  shoe.rotation.y = footRotY;
  shoe.traverse((c) => {
    c.userData.slotIndex = slotIndex;
    c.userData.partSlot = 'shoes';
  });
  shoe.userData.slotIndex = slotIndex;
  shoe.userData.partSlot = 'shoes';
  footHolder.add(shoe);
}

// ============================================================================
// UNIFIED ARTICULATED LOWER-BODY BUILDER FOR ALL 9 SKINS
// ============================================================================
export function buildArticulatedPantsAndShoes(
  pantsId: SkinId,
  shoesId: SkinId,
  slotIndex: number
): ArticulatedLowerRig {
  const pelvisGroup = new THREE.Group();
  pelvisGroup.name = `Pelvis_${pantsId}`;

  const lowCut = isLowCutShoe(shoesId);
  const shinEndY = lowCut ? 0.078 : 0.195;

  // Helper to tag pelvis & leg meshes as 'pants'
  const tagAsPants = (obj: THREE.Object3D) => {
    obj.traverse((c) => {
      if (c.userData.partSlot === undefined) {
        c.userData.slotIndex = slotIndex;
        c.userData.partSlot = 'pants';
      }
    });
  };

  // --- 01: CAPTAIN BOONIE ---
  if (pantsId === 'boonie') {
    const camoMat = createMat({
      color: 0xffffff,
      map: getWoodlandCamoTexture('pants'),
      roughness: 0.85,
    });
    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.140, 0, 0.012),
      rightPos: new THREE.Vector3(-0.140, 0, 0.012),
      leftRotY: 0.14,
      rightRotY: -0.22,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.84, rx: 0.148, rz: 0.102 },
            { y: 0.92, rx: 0.172, rz: 0.114 },
            { y: 1.00, rx: 0.164, rz: 0.108 },
          ],
          10
        ),
        camoMat,
        { outline: 0.005 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.098, 0.91, 0.0);
      const knee = new THREE.Vector3(s * 0.124, 0.535, 0.016);
      const ankle = new THREE.Vector3(s * 0.140, 0.190, 0.004);
      const shinTarget = new THREE.Vector3(s * 0.140, shinEndY, 0.004);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        camoMat,
        0.088,
        0.072
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.092, 0.096, 0.085, 0.089, 0.075, 0.079, camoMat, 10, {
          outline: 0.0048,
        })
      );
      const cargo = makeStylizedMesh(
        createBeveledBoxGeometry(0.030, 0.145, 0.096, 0.005),
        camoMat,
        { outline: 0.0034 }
      );
      cargo.position.set(s * 0.186, 0.68, 0.006);
      cargo.rotation.z = s * -0.05;
      leg.thighInner.add(cargo);

      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.076, 0.080, 0.073, 0.077, 0.062, 0.066, camoMat, 10, {
          outline: 0.0048,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 02: VENOM FANG OPS ---
  if (pantsId === 'venom') {
    const uniformMat = createMat({ color: PALETTE.venomUniform, roughness: 0.84 });
    const armorMat = createMat({ color: PALETTE.venomArmor, roughness: 0.72, metalness: 0.10 });
    const webbingMat = createMat({ color: PALETTE.venomWebbing, roughness: 0.86 });
    const kneeMat = createMat({ color: PALETTE.venomKnee, roughness: 0.66, metalness: 0.14 });

    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.128, 0, 0.042),
      rightPos: new THREE.Vector3(-0.148, 0, -0.016),
      leftRotY: 0.08,
      rightRotY: -0.30,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.83, rx: 0.154, rz: 0.108 },
            { y: 0.92, rx: 0.176, rz: 0.118 },
            { y: 1.00, rx: 0.170, rz: 0.114 },
          ],
          10
        ),
        uniformMat,
        { outline: 0.005 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.100, 0.91, 0.0);
      const knee =
        side === 'left'
          ? new THREE.Vector3(0.114, 0.535, 0.056)
          : new THREE.Vector3(-0.134, 0.535, 0.036);
      const ankle =
        side === 'left'
          ? new THREE.Vector3(0.128, 0.190, 0.034)
          : new THREE.Vector3(-0.148, 0.190, -0.018);
      const shinTarget = new THREE.Vector3(ankle.x, shinEndY, ankle.z);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        uniformMat,
        0.090,
        0.075
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.095, 0.099, 0.087, 0.091, 0.077, 0.081, uniformMat, 10, {
          outline: 0.005,
        })
      );
      for (const frac of [0.44, 0.62]) {
        const pt = new THREE.Vector3().lerpVectors(hip, knee, frac);
        const strap = makeStylizedMesh(
          new THREE.CylinderGeometry(0.091, 0.089, 0.022, 10),
          webbingMat,
          { outline: 0.003 }
        );
        strap.position.copy(pt);
        strap.rotation.z = s * -0.05;
        leg.thighInner.add(strap);
      }
      if (side === 'left') {
        const thighPouch = createTacticalPouch({
          width: 0.078,
          height: 0.150,
          depth: 0.120,
          pouchMat: armorMat,
          flap: true,
          flapMat: kneeMat,
          outline: 0.004,
        });
        thighPouch.position.set(0.204, 0.725, 0.026);
        thighPouch.rotation.y = 0.15;
        thighPouch.rotation.z = -0.06;
        leg.thighInner.add(thighPouch);
      } else {
        const rightPad = makeStylizedMesh(
          createBeveledBoxGeometry(0.034, 0.135, 0.092, 0.005),
          armorMat,
          { outline: 0.0036 }
        );
        rightPad.position.set(-0.204, 0.720, 0.012);
        rightPad.rotation.y = -0.18;
        leg.thighInner.add(rightPad);
      }

      const kneePad = createTacticalKneePad(kneeMat, webbingMat, 0.004);
      kneePad.position.copy(knee);
      kneePad.rotation.y = side === 'left' ? 0.08 : -0.24;
      leg.shinInner.add(kneePad);

      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.079, 0.083, 0.075, 0.079, 0.063, 0.067, uniformMat, 10, {
          outline: 0.005,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 03: GOLDEN ENFORCER ---
  if (pantsId === 'gold') {
    const pantsMat = createMat({ color: PALETTE.suitPants, roughness: 0.80 });
    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.136, 0, 0.006),
      rightPos: new THREE.Vector3(-0.136, 0, 0.006),
      leftRotY: 0.18,
      rightRotY: -0.22,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.85, rx: 0.146, rz: 0.094 },
            { y: 0.93, rx: 0.162, rz: 0.104 },
            { y: 1.00, rx: 0.156, rz: 0.100 },
          ],
          10
        ),
        pantsMat,
        { outline: 0.0048 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.092, 0.91, 0.002);
      const knee = new THREE.Vector3(s * 0.118, 0.535, 0.008);
      const ankle = new THREE.Vector3(s * 0.136, 0.185, 0.004);
      const shinTarget = new THREE.Vector3(s * 0.136, lowCut ? 0.074 : 0.195, 0.004);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        pantsMat,
        0.084,
        0.068
      );

      // Sleek pressed dress trousers split cleanly at knee for smooth running & crouching!
      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.086, 0.092, 0.080, 0.086, 0.070, 0.076, pantsMat, 10, {
          outline: 0.0048,
        })
      );
      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.070, 0.076, 0.064, 0.070, 0.050, 0.056, pantsMat, 10, {
          outline: 0.0048,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 04: RED-EYE TROOPER ---
  if (pantsId === 'reaper') {
    const uniformMat = createMat({ color: PALETTE.reaperUniform, roughness: 0.86 });
    const rigMat = createMat({ color: PALETTE.reaperRig, roughness: 0.76, metalness: 0.08 });
    const rigDarkMat = createMat({ color: 0x16181b, roughness: 0.86 });
    const kneeMat = createMat({ color: PALETTE.reaperKnee, roughness: 0.66, metalness: 0.14 });

    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.144, 0, 0.008),
      rightPos: new THREE.Vector3(-0.144, 0, 0.008),
      leftRotY: 0.24,
      rightRotY: -0.18,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.83, rx: 0.152, rz: 0.104 },
            { y: 0.92, rx: 0.174, rz: 0.114 },
            { y: 1.00, rx: 0.168, rz: 0.110 },
          ],
          10
        ),
        uniformMat,
        { outline: 0.005 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.100, 0.91, 0.0);
      const knee = new THREE.Vector3(s * 0.126, 0.538, 0.022);
      const ankle = new THREE.Vector3(s * 0.144, 0.190, 0.004);
      const shinTarget = new THREE.Vector3(s * 0.144, shinEndY, 0.004);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        uniformMat,
        0.090,
        0.074
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.094, 0.098, 0.086, 0.090, 0.076, 0.080, uniformMat, 10, {
          outline: 0.005,
        })
      );
      for (const frac of [0.36, 0.56]) {
        const pt = new THREE.Vector3().lerpVectors(hip, knee, frac);
        const strap = makeStylizedMesh(
          new THREE.CylinderGeometry(0.091, 0.089, 0.022, 10),
          rigDarkMat,
          { outline: 0.003 }
        );
        strap.position.copy(pt);
        strap.rotation.z = s * -0.05;
        leg.thighInner.add(strap);
      }
      if (side === 'right') {
        const holster = createDropLegHolster();
        holster.position.set(-0.204, 0.742, 0.014);
        holster.rotation.y = -0.15;
        holster.rotation.z = 0.06;
        leg.thighInner.add(holster);
      } else {
        const thighPouch = createTacticalPouch({
          width: 0.056,
          height: 0.142,
          depth: 0.092,
          pouchMat: rigMat,
          flap: true,
          flapMat: rigDarkMat,
          outline: 0.0036,
        });
        thighPouch.position.set(0.198, 0.742, 0.012);
        thighPouch.rotation.y = 0.14;
        thighPouch.rotation.z = -0.05;
        leg.thighInner.add(thighPouch);
      }

      const kneePad = createTacticalKneePad(kneeMat, rigDarkMat, 0.004);
      kneePad.position.copy(knee);
      kneePad.rotation.y = s * 0.14;
      leg.shinInner.add(kneePad);

      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.078, 0.082, 0.074, 0.078, 0.064, 0.068, uniformMat, 10, {
          outline: 0.005,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 05: SWAT POLICE ---
  if (pantsId === 'police') {
    const navyMat = createMat({ color: PALETTE.policeUniformNavy, roughness: 0.84 });
    const strapMat = createMat({ color: 0x181b21, roughness: 0.86 });
    const kneeMat = createMat({ color: PALETTE.policeKnee, roughness: 0.64, metalness: 0.14 });

    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.142, 0, 0.014),
      rightPos: new THREE.Vector3(-0.142, 0, 0.014),
      leftRotY: 0.16,
      rightRotY: -0.24,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.84, rx: 0.152, rz: 0.104 },
            { y: 0.92, rx: 0.174, rz: 0.114 },
            { y: 1.00, rx: 0.168, rz: 0.110 },
          ],
          10
        ),
        navyMat,
        { outline: 0.005 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.100, 0.91, 0.0);
      const knee = new THREE.Vector3(s * 0.126, 0.538, 0.024);
      const ankle = new THREE.Vector3(s * 0.142, 0.190, 0.008);
      const shinTarget = new THREE.Vector3(s * 0.142, shinEndY, 0.008);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        navyMat,
        0.090,
        0.074
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.094, 0.098, 0.086, 0.090, 0.076, 0.080, navyMat, 10, {
          outline: 0.005,
        })
      );
      for (const frac of [0.36, 0.56]) {
        const pt = new THREE.Vector3().lerpVectors(hip, knee, frac);
        const strap = makeStylizedMesh(
          new THREE.CylinderGeometry(0.091, 0.089, 0.022, 10),
          strapMat,
          { outline: 0.003 }
        );
        strap.position.copy(pt);
        strap.rotation.z = s * -0.05;
        leg.thighInner.add(strap);
      }
      if (side === 'right') {
        const holster = createDropLegHolster();
        holster.position.set(-0.204, 0.745, 0.015);
        holster.rotation.y = -0.16;
        holster.rotation.z = 0.06;
        leg.thighInner.add(holster);
      }

      const kneePad = createTacticalKneePad(kneeMat, strapMat, 0.0042);
      kneePad.position.copy(knee);
      kneePad.rotation.y = s * 0.14;
      leg.shinInner.add(kneePad);

      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.078, 0.082, 0.074, 0.078, 0.064, 0.068, navyMat, 10, {
          outline: 0.005,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 06: HEAVY LMG GUNNER ---
  if (pantsId === 'gunner') {
    const camoMat = createMat({
      color: 0xffffff,
      map: getWoodlandCamoTexture('gunner'),
      roughness: 0.85,
    });
    const strapMat = createMat({ color: 0x262925, roughness: 0.86 });

    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.146, 0, 0.018),
      rightPos: new THREE.Vector3(-0.146, 0, 0.012),
      leftRotY: 0.10,
      rightRotY: -0.26,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.84, rx: 0.156, rz: 0.108 },
            { y: 0.92, rx: 0.180, rz: 0.120 },
            { y: 1.00, rx: 0.172, rz: 0.114 },
          ],
          10
        ),
        camoMat,
        { outline: 0.005 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.104, 0.91, 0.0);
      const knee = new THREE.Vector3(s * 0.130, 0.535, 0.018);
      const ankle = new THREE.Vector3(s * 0.146, 0.190, 0.006);
      const shinTarget = new THREE.Vector3(s * 0.146, shinEndY, 0.006);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        camoMat,
        0.092,
        0.076
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.098, 0.102, 0.090, 0.094, 0.079, 0.083, camoMat, 10, {
          outline: 0.005,
        })
      );
      const cargo = makeStylizedMesh(
        createBeveledBoxGeometry(0.034, 0.155, 0.102, 0.005),
        camoMat,
        { outline: 0.0036 }
      );
      cargo.position.set(s * 0.196, 0.67, 0.008);
      cargo.rotation.z = s * -0.05;
      leg.thighInner.add(cargo);

      if (side === 'right') {
        const legStrap = makeStylizedMesh(
          new THREE.CylinderGeometry(0.096, 0.094, 0.022, 10),
          strapMat,
          { outline: 0.003 }
        );
        legStrap.position.set(-0.116, 0.74, 0.008);
        legStrap.rotation.z = 0.06;
        leg.thighInner.add(legStrap);
      }

      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.080, 0.084, 0.076, 0.080, 0.065, 0.069, camoMat, 10, {
          outline: 0.005,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 07: SKILL ISSUE AGENT ---
  if (pantsId === 'skill') {
    const pantBlack = createMat({ color: PALETTE.skillPantsBlack, roughness: 0.84 });
    const sockMat = createMat({ color: PALETTE.skillSock, roughness: 0.86 });
    const legPrintMat = createMat({
      color: 0xffffff,
      map: getSkillLegTexture(),
      roughness: 0.82,
    });

    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.146, 0, 0.010),
      rightPos: new THREE.Vector3(-0.146, 0, 0.018),
      leftRotY: 0.12,
      rightRotY: -0.30,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.83, rx: 0.156, rz: 0.104 },
            { y: 0.92, rx: 0.174, rz: 0.114 },
            { y: 1.00, rx: 0.168, rz: 0.110 },
          ],
          10
        ),
        pantBlack,
        { outline: 0.005 }
      )
    );

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.102, 0.90, 0.0);
      const knee = new THREE.Vector3(s * 0.128, 0.54, 0.022);
      const joggerCuff = new THREE.Vector3(s * 0.142, 0.255, 0.008);
      const ankle = new THREE.Vector3(s * 0.146, 0.175, 0.006);
      const sockEnd = new THREE.Vector3(s * 0.146, lowCut ? 0.072 : 0.185, 0.006);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        pantBlack,
        0.092,
        0.078
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.098, 0.102, 0.094, 0.098, 0.084, 0.088, pantBlack, 10, {
          outline: 0.0048,
        })
      );
      if (side === 'left') {
        const cargo = createTacticalPouch({
          width: 0.042,
          height: 0.165,
          depth: 0.112,
          pouchMat: pantBlack,
          flap: true,
          flapMat: sockMat,
          outline: 0.0036,
        });
        cargo.position.set(0.194, 0.69, 0.010);
        cargo.rotation.z = -0.05;
        leg.thighInner.add(cargo);
      } else {
        const stripeGeom = new THREE.CylinderGeometry(
          0.098,
          0.089,
          0.34,
          10,
          1,
          true,
          -Math.PI * 0.56,
          Math.PI * 0.40
        );
        const stripe = new THREE.Mesh(stripeGeom, legPrintMat);
        stripe.position.set(-0.116, 0.705, 0.012);
        stripe.rotation.z = 0.07;
        stripe.renderOrder = 2;
        leg.thighInner.add(stripe);
      }

      leg.shinInner.add(
        buildLimbBetween(knee, joggerCuff, 0.086, 0.090, 0.080, 0.084, 0.056, 0.060, pantBlack, 10, {
          outline: 0.0048,
        })
      );
      const cuff = makeStylizedMesh(
        new THREE.CylinderGeometry(0.058, 0.054, 0.036, 10),
        pantBlack,
        { outline: 0.0036 }
      );
      cuff.position.copy(joggerCuff);
      leg.shinInner.add(cuff);

      leg.shinInner.add(
        buildLimbBetween(joggerCuff, sockEnd, 0.044, 0.046, 0.042, 0.044, 0.040, 0.042, sockMat, 10, {
          outline: 0.0038,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 08: LEVEL-3 SURVIVOR ---
  if (pantsId === 'spetsnaz') {
    const denimMat = createMat({
      color: 0xffffff,
      map: getDistressedDenimTexture(),
      roughness: 0.86,
    });
    const leatherMat = createMat({ color: PALETTE.spetsLeather, roughness: 0.72 });
    const leatherDark = createMat({ color: 0x4d301d, roughness: 0.76 });
    const kneePadMat = createMat({ color: PALETTE.spetsKneePad, roughness: 0.74 });
    const rustAccent = createMat({ color: 0xa65934, roughness: 0.72 });

    const anchors: FootAnchors = {
      leftPos: new THREE.Vector3(0.118, 0, -0.012),
      rightPos: new THREE.Vector3(-0.128, 0, 0.044),
      leftRotY: 0.14,
      rightRotY: -0.22,
      drapesLow: lowCut,
    };

    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.84, rx: 0.148, rz: 0.100 },
            { y: 0.92, rx: 0.168, rz: 0.110 },
            { y: 1.00, rx: 0.160, rz: 0.104 },
          ],
          10
        ),
        denimMat,
        { outline: 0.0048 }
      )
    );
    pelvisGroup.add(
      makeStylizedMesh(
        createLoftGeometry(
          [
            { y: 0.955, rx: 0.166, rz: 0.109 },
            { y: 1.000, rx: 0.166, rz: 0.109 },
          ],
          10
        ),
        leatherMat,
        { outline: 0.0036 }
      )
    );
    const diagBelt = makeStylizedMesh(
      createLoftGeometry(
        [
          { y: -0.018, rx: 0.174, rz: 0.114 },
          { y: 0.018, rx: 0.174, rz: 0.114 },
        ],
        12
      ),
      leatherDark,
      { outline: 0.0034 }
    );
    diagBelt.position.set(0, 0.915, 0.0);
    diagBelt.rotation.z = -0.18;
    pelvisGroup.add(diagBelt);

    const beltBuckle = makeStylizedMesh(
      createBeveledBoxGeometry(0.044, 0.044, 0.014, 0.003),
      createMat({ color: 0x8a795f, roughness: 0.45, metalness: 0.5 }),
      { outline: 0.0022 }
    );
    beltBuckle.position.set(0, 0.978, 0.112);
    pelvisGroup.add(beltBuckle);

    const leftSatchel = createTacticalPouch({
      width: 0.058,
      height: 0.125,
      depth: 0.098,
      pouchMat: leatherMat,
      flap: true,
      flapMat: leatherDark,
      outline: 0.0036,
    });
    leftSatchel.position.set(0.186, 0.858, 0.024);
    leftSatchel.rotation.z = -0.08;
    leftSatchel.rotation.y = 0.16;
    pelvisGroup.add(leftSatchel);

    const rightPouch = createTacticalPouch({
      width: 0.052,
      height: 0.110,
      depth: 0.082,
      pouchMat: leatherDark,
      flap: true,
      flapMat: leatherMat,
      outline: 0.0032,
    });
    rightPouch.position.set(-0.180, 0.892, -0.028);
    rightPouch.rotation.y = -0.24;
    pelvisGroup.add(rightPouch);

    const buildSide = (side: 'left' | 'right') => {
      const s = side === 'left' ? 1 : -1;
      const hip = new THREE.Vector3(s * 0.098, 0.90, 0.0);
      const knee =
        side === 'right'
          ? new THREE.Vector3(-0.114, 0.540, 0.048)
          : new THREE.Vector3(0.110, 0.538, 0.008);
      const ankle =
        side === 'right'
          ? new THREE.Vector3(-0.128, 0.195, 0.036)
          : new THREE.Vector3(0.118, 0.195, -0.016);
      const shinTarget = new THREE.Vector3(ankle.x, lowCut ? 0.076 : 0.215, ankle.z);

      const leg = makeLegHierarchy(
        side,
        hip,
        knee,
        ankle,
        side === 'left' ? anchors.leftPos : anchors.rightPos,
        side === 'left' ? anchors.leftRotY : anchors.rightRotY,
        denimMat,
        0.085,
        0.068
      );

      leg.thighInner.add(
        buildLimbBetween(hip, knee, 0.088, 0.092, 0.080, 0.084, 0.070, 0.074, denimMat, 10, {
          outline: 0.0048,
        })
      );

      const pad = createTacticalKneePad(kneePadMat, leatherDark, 0.004);
      pad.position.copy(knee);
      pad.rotation.y = side === 'right' ? -0.18 : 0.14;
      if (side === 'right') {
        const badge = makeStylizedMesh(
          createBeveledBoxGeometry(0.036, 0.022, 0.012, 0.003),
          rustAccent,
          { outline: 0 }
        );
        badge.position.set(0, -0.018, 0.102);
        pad.add(badge);
      }
      leg.shinInner.add(pad);

      leg.shinInner.add(
        buildLimbBetween(knee, shinTarget, 0.072, 0.076, 0.068, 0.072, 0.058, 0.062, denimMat, 10, {
          outline: 0.0048,
        })
      );
      attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
      tagAsPants(leg.nodes.hipPivot);
      return leg.nodes;
    };

    tagAsPants(pelvisGroup);
    return { pelvisGroup, leftLeg: buildSide('left'), rightLeg: buildSide('right'), anchors };
  }

  // --- 09: SILAT STRIKER (Worn Dark-Indigo Slim Fighter Jeans — Reference Image 1!) ---
  const silatDenimMat = createMat({
    color: 0xffffff,
    map: getSilatDenimTexture(),
    roughness: 0.85,
  });
  const beltDarkMat = createMat({ color: 0x1e2024, roughness: 0.82 });

  // Agile athletic Silat martial-arts stance!
  const anchors: FootAnchors = {
    leftPos: new THREE.Vector3(0.156, 0, 0.032),
    rightPos: new THREE.Vector3(-0.156, 0, -0.014),
    leftRotY: 0.22,
    rightRotY: -0.28,
    drapesLow: lowCut,
  };

  pelvisGroup.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.83, rx: 0.152, rz: 0.104 },
          { y: 0.92, rx: 0.172, rz: 0.112 },
          { y: 0.99, rx: 0.166, rz: 0.108 },
        ],
        10
      ),
      silatDenimMat,
      { outline: 0.0048 }
    )
  );

  // Slim dark belt peeking cleanly beneath heather-grey undershirt hem
  pelvisGroup.add(
    makeStylizedMesh(
      createLoftGeometry(
        [
          { y: 0.925, rx: 0.171, rz: 0.112 },
          { y: 0.955, rx: 0.171, rz: 0.112 },
        ],
        10
      ),
      beltDarkMat,
      { outline: 0.0032 }
    )
  );

  const buildSilatSide = (side: 'left' | 'right') => {
    const s = side === 'left' ? 1 : -1;
    const hip = new THREE.Vector3(s * 0.102, 0.90, 0.0);
    const knee =
      side === 'left'
        ? new THREE.Vector3(0.138, 0.535, 0.038)
        : new THREE.Vector3(-0.142, 0.535, 0.018);
    const ankle =
      side === 'left'
        ? new THREE.Vector3(0.156, 0.175, 0.024)
        : new THREE.Vector3(-0.156, 0.175, -0.018);
    const shinTarget = new THREE.Vector3(ankle.x, lowCut ? 0.088 : 0.195, ankle.z);

    const leg = makeLegHierarchy(
      side,
      hip,
      knee,
      ankle,
      side === 'left' ? anchors.leftPos : anchors.rightPos,
      side === 'left' ? anchors.leftRotY : anchors.rightRotY,
      silatDenimMat,
      0.088,
      0.072
    );

    leg.thighInner.add(
      buildLimbBetween(hip, knee, 0.092, 0.096, 0.084, 0.088, 0.074, 0.078, silatDenimMat, 10, {
        outline: 0.0048,
      })
    );
    leg.shinInner.add(
      buildLimbBetween(knee, shinTarget, 0.074, 0.078, 0.068, 0.072, 0.056, 0.060, silatDenimMat, 10, {
        outline: 0.0048,
      })
    );
    attachShoeToLeg(leg.footHolder, shoesId, leg.nodes.footPos, leg.nodes.footRotY, slotIndex);
    tagAsPants(leg.nodes.hipPivot);
    return leg.nodes;
  };

  tagAsPants(pelvisGroup);
  return {
    pelvisGroup,
    leftLeg: buildSilatSide('left'),
    rightLeg: buildSilatSide('right'),
    anchors,
  };
}
