import { HitZone } from '../models/types';

let audioCtx: AudioContext | null = null;

function getAudioCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const Ctor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (Ctor) {
      audioCtx = new Ctor();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Plays a punchy stylized tactical gunshot + zone-specific impact sound.
 * On the 3rd fatal hit (`isFatal = true`), adds a cinematic low sub-bass knockout punch!
 */
export function playHitSound(zone: HitZone, isFatal: boolean): void {
  const ctx = getAudioCtx();
  if (!ctx) return;

  const now = ctx.currentTime;

  // 1. Crisp Tactical Gunshot Crack (filtered noise burst)
  const noiseDur = isFatal ? 0.16 : 0.10;
  const bufSize = Math.floor(ctx.sampleRate * noiseDur);
  const buffer = ctx.createBuffer(1, bufSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufSize; i++) {
    const env = Math.pow(1 - i / bufSize, 2.6);
    data[i] = (Math.random() * 2 - 1) * env;
  }

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const filter = ctx.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.setValueAtTime(zone === 'head' ? 1850 : 1150, now);
  filter.Q.setValueAtTime(0.9, now);

  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(isFatal ? 0.28 : 0.20, now);
  noiseGain.gain.exponentialRampToValueAtTime(0.001, now + noiseDur);

  noise.connect(filter);
  filter.connect(noiseGain);
  noiseGain.connect(ctx.destination);
  noise.start(now);

  // 2. Kinetic Impact Thump (higher metallic ping for headshot, heavy punch for chest/limbs)
  const osc = ctx.createOscillator();
  const oscGain = ctx.createGain();
  if (zone === 'head') {
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(isFatal ? 620 : 520, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.14);
  } else {
    osc.type = 'sine';
    osc.frequency.setValueAtTime(isFatal ? 190 : 155, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + (isFatal ? 0.24 : 0.12));
  }

  oscGain.gain.setValueAtTime(isFatal ? 0.34 : 0.22, now);
  oscGain.gain.exponentialRampToValueAtTime(0.001, now + (isFatal ? 0.26 : 0.14));

  osc.connect(oscGain);
  oscGain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + (isFatal ? 0.28 : 0.15));

  // 3. Dramatic Sub-Bass Knockout Boom on 3rd Fatal Hit (HP = 0!)
  if (isFatal) {
    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(110, now + 0.02);
    sub.frequency.exponentialRampToValueAtTime(28, now + 0.55);
    subGain.gain.setValueAtTime(0.32, now + 0.02);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.58);
    sub.connect(subGain);
    subGain.connect(ctx.destination);
    sub.start(now + 0.02);
    sub.stop(now + 0.60);
  }
}

/**
 * Plays a dull weighty ground thud when a knocked-out character slams onto the floor.
 */
export function playFloorSlamSound(): void {
  const ctx = getAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(88, now);
  osc.frequency.exponentialRampToValueAtTime(26, now + 0.24);
  gain.gain.setValueAtTime(0.28, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + 0.28);
}
