/**
 * Global aim arbitration for shoot mode.
 * 'zombie' = the crosshair punches straight through the squad and hits whatever
 * zombie body part sits under the cursor (the squad is only shot as a fallback
 * when no zombie is behind it). 'squad' = the classic behaviour.
 */
export const aim: { mode: 'zombie' | 'squad' } = { mode: 'zombie' };

/**
 * One-shot command queue drained by the render loop — how the HUD asks the scene
 * to play a scripted melee beat ('axe' = kapak bacok, 'kick' = tendangan dobek).
 */
export const cmd: { queue: ('axe' | 'kick')[] } = { queue: [] };
