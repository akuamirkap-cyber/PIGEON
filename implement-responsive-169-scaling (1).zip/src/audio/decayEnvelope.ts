/**
 * Cheap `(1 - i / len) ^ p` decay envelopes for generated reverb impulses.
 *
 * Every audio engine in the game builds its own convolver impulse — 1.1 s,
 * 1.2 s, 2.2 s and 3.2 s of shaped noise, two channels each. Calling
 * `Math.pow` once per sample made those loops the single most expensive part
 * of starting the audio (20-40 ms *per engine* on the main thread, measured),
 * dwarfing the convolver's own FFT (7-11 ms).
 *
 * The curve is perfectly smooth, so it is evaluated once per 64-sample block
 * and linearly interpolated in between. The largest deviation from the exact
 * curve is far below one part in a thousand — inaudible — and the per-sample
 * loop is left with a multiply and an add.
 */
const BLOCK = 64;

/**
 * Fill `d[from..len)` with `shape(i, env)`, where `env` is the interpolated
 * `(1 - (i - from) / (len - from)) ^ p` envelope. `shape` is called once per
 * sample with the current envelope and must return the sample value; it owns
 * any noise colouring (one-pole smoothing, attack ramps, …).
 */
export function fillDecay(
  d: Float32Array,
  len: number,
  p: number,
  shape: (i: number, env: number) => number,
  from = 0,
): void {
  const span = Math.max(1, len - from);
  let e0 = 1;
  for (let b = from; b < len; b += BLOCK) {
    const end = Math.min(len, b + BLOCK);
    const e1 = Math.pow(Math.max(0, 1 - (end - from) / span), p);
    const de = (e1 - e0) / (end - b);
    let env = e0;
    for (let i = b; i < end; i++) {
      d[i] = shape(i, env);
      env += de;
    }
    e0 = e1;
  }
}
