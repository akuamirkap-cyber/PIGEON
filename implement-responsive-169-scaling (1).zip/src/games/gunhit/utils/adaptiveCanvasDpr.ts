/**
 * Render-quality governor: keeps the frame under 16.7 ms by trading raster
 * density first and cosmetic particle counts second — never simulation speed,
 * never the artwork itself.
 *
 * Every live animation frame feeds its interval in. Each 0.6 s window counts
 * how many frames missed 60 Hz; sustained misses step the canvas backing-store
 * density down (0.25 at a time when half the frames are late), and once the
 * density sits on its floor the cosmetic effect level is trimmed instead.
 * Sustained smooth windows restore the effects first, then the density, slowly
 * enough that repeated shooting cannot make the quality oscillate (a density
 * change reallocates the backing store, which is itself a hitch).
 *
 * A single long stall or a background-tab pause must never lower quality, so
 * one frame contributes at most one "late" mark and clock jumps are ignored.
 */
const WINDOW_MS = 600;
const FX_FLOOR = 0.5;

export class AdaptiveCanvasDpr {
  private enabled = false;
  private ceiling = 1;
  private floor = 1;
  private density = 1;
  private elapsed = 0;
  private frames = 0;
  private slowFrames = 0;
  private stableWindows = 0;
  private fxEnabled = false;
  /** Cosmetic particle multiplier, 1 (full) → 0.5; read by the engine each frame. */
  fxLevel = 1;

  reset(baseDensity: number, enabled: boolean): void {
    this.ceiling = baseDensity;
    this.floor = Math.min(baseDensity, 1.0);
    this.density = baseDensity;
    this.enabled = enabled && baseDensity > this.floor;
    // Effects may still be trimmed when there is no density headroom at all.
    this.fxEnabled = enabled;
    this.fxLevel = 1;
    this.pause();
  }

  /** Discard incomplete measurements while paused or hidden, retaining density. */
  pause(): void {
    this.elapsed = 0;
    this.frames = 0;
    this.slowFrames = 0;
    this.stableWindows = 0;
  }

  /**
   * Feed one visible, active requestAnimationFrame interval in milliseconds.
   * Returns a new DPR only when the backing store should actually be resized.
   */
  recordFrame(ms: number): number | null {
    // Do not confuse resuming a suspended tab, or a clock discontinuity, with
    // sustained rendering load. The simulation has its own independent dt cap.
    if ((!this.enabled && !this.fxEnabled) || !Number.isFinite(ms) || ms <= 0 || ms > 1000) {
      this.pause();
      return null;
    }
    // A single long stall contributes only one slow frame, not an entire
    // measurement window, while repeated long frames still lower the DPR.
    this.elapsed += Math.min(ms, 200);
    this.frames++;
    // Anything past a 60 Hz tick (with a little timer slack) is a missed frame.
    if (ms > 17.4) this.slowFrames++;
    if (this.elapsed < WINDOW_MS) return null;

    const slowFraction = this.slowFrames / this.frames;
    this.elapsed = 0;
    this.frames = 0;
    this.slowFrames = 0;
    let next = this.density;
    if (slowFraction >= 0.5) {
      // Badly behind: a big step straight away.
      this.stableWindows = 0;
      if (this.enabled && this.density > this.floor) next = Math.max(this.floor, this.density - 0.25);
      else this.fxLevel = Math.max(FX_FLOOR, this.fxLevel - 0.15);
    } else if (slowFraction >= 0.2) {
      this.stableWindows = 0;
      if (this.enabled && this.density > this.floor) next = Math.max(this.floor, this.density - 0.1);
      else this.fxLevel = Math.max(FX_FLOOR, this.fxLevel - 0.1);
    } else if (slowFraction <= 0.05) {
      // Recover only after ~3.6 s of consistently smooth frames: effects come
      // back first (free), density last (a reallocation).
      if (++this.stableWindows >= 6) {
        this.stableWindows = 0;
        if (this.fxLevel < 1) this.fxLevel = Math.min(1, this.fxLevel + 0.1);
        else if (this.enabled) next = Math.min(this.ceiling, this.density + 0.1);
      }
    } else {
      this.stableWindows = 0;
    }
    this.fxLevel = Math.round(this.fxLevel * 100) / 100;
    if (next === this.density) return null;
    next = Math.min(this.ceiling, Math.max(this.floor, Math.round(next * 100) / 100));
    if (next === this.density) return null;
    this.density = next;
    return next;
  }
}
