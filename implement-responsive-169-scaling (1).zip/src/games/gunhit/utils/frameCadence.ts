/**
 * Frame-cadence governor: the game draws on a steady 60 Hz grid.
 *
 * A 90 / 120 / 144 Hz screen asks for a frame every 11.1 / 8.3 / 6.9 ms. Drawing
 * on every one of them doubles the raster work for no visible gain in a game
 * whose feel is tuned for 60, and the moment the work starts to fill the
 * interval the browser delivers an *uneven* mix of short and long frames —
 * which reads as judder even though the average frame rate is still "high".
 * Locking the drawing to the 60 Hz grid trades a jittery 80-144 fps for a rock
 * steady 60, which is what "smooth" actually looks like, and leaves headroom
 * on the GPU for the effects.
 *
 * It only ever skips *drawing*. Simulation and input keep running on every
 * animation frame (so a 120 Hz player still gets 120 Hz input latency), the
 * resolution governor keeps its own job, and nothing about the artwork
 * changes. On a 60 Hz screen it does nothing at all: every frame draws.
 *
 * Scheduling is grid-based rather than "at least 16.4 ms since the last draw":
 * the latter starves to 48 fps on 144 Hz (every third frame). Here the next
 * draw is the first animation frame at or after each 16.67 ms grid tick, so
 * the count is exactly 60 per second on any refresh rate above 60.
 */
const GRID_MS = 1000 / 60;

export class FrameCadence {
  /** Draw at most one frame per 60 Hz tick while the lock is on. */
  private capped = false;
  private interval = 16.7;
  private work = 0;
  private warm = 0;
  private fast = 0;
  private slow = 0;
  private lastDraw = -Infinity;
  private nextGrid = -Infinity;

  reset(): void {
    this.capped = false;
    this.interval = 16.7;
    this.work = 0;
    this.warm = 0;
    this.fast = 0;
    this.slow = 0;
    this.lastDraw = -Infinity;
    this.nextGrid = -Infinity;
  }

  get isCapped(): boolean {
    return this.capped;
  }

  /** Exponential averages of what the loop can actually observe. */
  private sample(intervalMs: number, workMs: number): void {
    // Ignore tab switches and other clock discontinuities.
    if (!Number.isFinite(intervalMs) || intervalMs <= 0 || intervalMs > 200) return;
    this.interval += (intervalMs - this.interval) * 0.08;
    this.work += (Math.max(0, workMs) - this.work) * 0.12;
  }

  /**
   * Decide whether this animation frame should draw.
   *
   * @param now      the timestamp handed to the RAF callback
   * @param interval milliseconds since the previous callback
   * @param work     milliseconds the previous frame spent in update + render
   */
  shouldRender(now: number, interval: number, work: number): boolean {
    this.sample(interval, work);
    if (this.warm < 30) {
      this.warm++;
      this.lastDraw = now;
      this.nextGrid = now + GRID_MS;
      return true;
    }
    // A display clearly faster than 60 Hz engages the lock; it is released
    // only when the display itself is back at ~60 Hz (the window was dragged
    // to another monitor, the OS dropped its refresh rate) — never because of
    // load, so it can not flap.
    if (!this.capped) {
      this.fast = this.interval < 12.5 ? this.fast + 1 : 0;
      if (this.fast >= 20) {
        this.capped = true;
        this.fast = 0;
        this.slow = 0;
        this.nextGrid = now + GRID_MS;
        this.lastDraw = now;
        return true;
      }
      this.lastDraw = now;
      return true;
    }
    this.slow = this.interval > 14.5 ? this.slow + 1 : 0;
    if (this.slow >= 60) {
      this.capped = false;
      this.slow = 0;
      this.lastDraw = now;
      return true;
    }
    // Draw on the first frame at (or just before) each grid tick.
    const half = Math.max(1, this.interval) / 2;
    if (now < this.nextGrid - half) return false;
    // Keep the grid phase; re-anchor if the page stalled past a whole tick.
    this.nextGrid = now - this.nextGrid > GRID_MS ? now + GRID_MS : this.nextGrid + GRID_MS;
    this.lastDraw = now;
    return true;
  }
}
