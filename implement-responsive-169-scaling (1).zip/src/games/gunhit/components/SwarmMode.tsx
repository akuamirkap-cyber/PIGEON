import React, { useEffect, useRef, useState, useCallback } from 'react';
import { drawGunCentered } from '../game/art/drawCentered';
import { getGunVariant } from '../game/art/gunVariants';
import { getWeapon, type WeaponId } from '../game/weapons';
import { playFireSfx } from '../game/Game';
import { sfx } from '../game/audio';
import CoinSprite from '../../shared/CoinSprite';
import { tr } from '../../../i18n/strings';
import type { Language } from '../../../i18n/language';
import { getFast2DContext, getMaxCanvasDpr } from '../utils/mobilePerf';
import { Trophy, RotateCcw, X, Crosshair, AlertTriangle } from 'lucide-react';

interface SwarmModeProps {
  weaponId: WeaponId;
  language: Language;
  onClose: () => void;
  onAddCoins: (amount: number) => void;
  frame: { w: number; h: number };
}

interface SwarmWheel {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  rot: number;
  spinSpeed: number;
  hp: number;
  maxHp: number;
  isBoss: boolean;
  isMiniBoss: boolean;
  theme: 'orange' | 'lemon' | 'lime' | 'watermelon' | 'boss';
  squish: number;
  squishV: number;
  hitFlash: number;
  cracks: number;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

interface FloatingText {
  id: number;
  text: string;
  x: number;
  y: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  scale: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  rot: number;
  vRot: number;
}

const TOTAL_ROUNDS = 5;

export default function SwarmMode({
  weaponId,
  language,
  onClose,
  onAddCoins,
  frame,
}: SwarmModeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [currentRound, setCurrentRound] = useState(1);
  const [sessionCoins, setSessionCoins] = useState(0);
  const [lives, setLives] = useState(3);
  const [gameState, setGameState] = useState<'countdown' | 'playing' | 'round_clear' | 'game_over' | 'victory'>('countdown');
  const [roundBanner, setRoundBanner] = useState('');
  const [stats, setStats] = useState({ bullseyes: 0, hits: 0, shots: 0 });

  // Game world states kept in refs for smooth 60fps canvas loop
  const worldRef = useRef({
    gunX: 92,
    gunY: frame.h / 2,
    gunAngle: 0,
    gunRecoil: 0,
    muzzleFlash: 0,
    lastShotAt: 0,
    pointer: { x: frame.w * 0.75, y: frame.h / 2 },
    isPointerDown: false,
    wheels: [] as SwarmWheel[],
    bullets: [] as Bullet[],
    texts: [] as FloatingText[],
    particles: [] as Particle[],
    spawnQueue: [] as { delay: number; wheel: Omit<SwarmWheel, 'id'> }[],
    roundActive: false,
    nextId: 1,
    screenShake: 0,
    time: 0,
  });

  const weapon = getWeapon(weaponId);
  const variant = getGunVariant(weaponId);

  // Sound triggering helper
  const playShot = useCallback(() => {
    try {
      playFireSfx(weaponId);
    } catch {
      sfx.shoot();
    }
  }, [weaponId]);

  // Start / restart round
  const startRound = useCallback((roundNum: number) => {
    const w = worldRef.current;
    w.wheels = [];
    w.bullets = [];
    w.spawnQueue = [];
    w.roundActive = true;
    setCurrentRound(roundNum);

    const banner = roundNum === 5
      ? (language === 'id' ? '⚠️ GELOMBANG BOS & PASUKAN!' : '⚠️ BOSS & SQUAD WAVE!')
      : (language === 'id' ? `RONDE ${roundNum} DARI 5` : `ROUND ${roundNum} OF 5`);
    setRoundBanner(banner);
    setGameState('countdown');

    // Prepare spawns according to rules:
    // Round 1: 1 wheel
    // Round 2: 2 wheels
    // Round 3: 3 wheels
    // Round 4: 4 wheels
    // Round 5: 1 Boss + 5 Mini-Bosses (20% smaller than boss)
    const themes: ('orange' | 'lemon' | 'lime' | 'watermelon')[] = ['orange', 'lemon', 'lime', 'watermelon'];

    if (roundNum <= 4) {
      const count = roundNum;
      for (let i = 0; i < count; i++) {
        const hp = i % 2 === 1 ? 2 : 1; // some need 2 hits, some need 1 hit
        const theme = themes[i % themes.length];
        const delay = 0.5 + i * 1.1; // staggered flight
        const targetY = 90 + Math.random() * (frame.h - 180);
        const vx = -(160 + roundNum * 18 + Math.random() * 30);
        const vy = (Math.random() - 0.5) * 45;

        w.spawnQueue.push({
          delay,
          wheel: {
            x: frame.w + 60,
            y: targetY,
            vx,
            vy,
            radius: 44,
            rot: Math.random() * Math.PI * 2,
            spinSpeed: (Math.random() > 0.5 ? 1 : -1) * (1.8 + Math.random() * 2),
            hp,
            maxHp: hp,
            isBoss: false,
            isMiniBoss: false,
            theme,
            squish: 0,
            squishV: 0,
            hitFlash: 0,
            cracks: 0,
          },
        });
      }
    } else {
      // Round 5: Boss + 5 Mini-Bosses
      const bossRadius = 65;
      const miniRadius = Math.round(bossRadius * 0.8); // Exactly 20% smaller than boss!

      // 1 Boss
      w.spawnQueue.push({
        delay: 0.6,
        wheel: {
          x: frame.w + 80,
          y: frame.h / 2,
          vx: -130,
          vy: 20,
          radius: bossRadius,
          rot: 0,
          spinSpeed: 1.4,
          hp: 5,
          maxHp: 5,
          isBoss: true,
          isMiniBoss: false,
          theme: 'boss',
          squish: 0,
          squishV: 0,
          hitFlash: 0,
          cracks: 0,
        },
      });

      // 5 Mini-Bosses
      for (let i = 0; i < 5; i++) {
        const delay = 1.8 + i * 0.85;
        const targetY = 80 + (i * 55) % (frame.h - 160);
        w.spawnQueue.push({
          delay,
          wheel: {
            x: frame.w + 60,
            y: targetY,
            vx: -(170 + Math.random() * 35),
            vy: (Math.random() - 0.5) * 50,
            radius: miniRadius,
            rot: Math.random() * Math.PI * 2,
            spinSpeed: -2.2,
            hp: 2,
            maxHp: 2,
            isBoss: false,
            isMiniBoss: true,
            theme: 'boss',
            squish: 0,
            squishV: 0,
            hitFlash: 0,
            cracks: 0,
          },
        });
      }
    }

    // Switch to playing after short countdown
    setTimeout(() => {
      setGameState('playing');
    }, 1100);
  }, [frame.w, frame.h, language]);

  // Initial mount
  useEffect(() => {
    startRound(1);
  }, [startRound]);

  // Fire bullet function
  const fireBullet = useCallback(() => {
    const w = worldRef.current;
    const now = performance.now();
    const cooldownMs = Math.max(75, (weapon.cooldown ?? 0.2) * 1000 * 0.65);
    if (now - w.lastShotAt < cooldownMs) return;
    w.lastShotAt = now;

    // Angle towards pointer
    const dx = w.pointer.x - w.gunX;
    const dy = w.pointer.y - w.gunY;
    const aimAngle = Math.atan2(dy, dx);
    w.gunAngle = aimAngle;
    w.gunRecoil = 1.0;
    w.muzzleFlash = 1.0;

    // Bullet speed (+40% faster)
    const speed = 2100 * 1.4;
    const muzzleDist = 48;
    const bx = w.gunX + Math.cos(aimAngle) * muzzleDist;
    const by = w.gunY + Math.sin(aimAngle) * muzzleDist;

    w.bullets.push({
      x: bx,
      y: by,
      vx: Math.cos(aimAngle) * speed,
      vy: Math.sin(aimAngle) * speed,
      life: 0,
      maxLife: 1.2,
    });

    // Muzzle sparks
    for (let i = 0; i < 5; i++) {
      const spd = 120 + Math.random() * 220;
      const a = aimAngle + (Math.random() - 0.5) * 0.45;
      w.particles.push({
        x: bx,
        y: by,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        life: 0.15 + Math.random() * 0.12,
        maxLife: 0.27,
        size: 2.5 + Math.random() * 2.5,
        color: '#fef08a',
        rot: 0,
        vRot: 0,
      });
    }

    setStats((s) => ({ ...s, shots: s.shots + 1 }));
    playShot();
  }, [weapon.cooldown, playShot]);

  // Pointer event handlers
  const handlePointerDown = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * frame.w;
    const py = ((e.clientY - rect.top) / rect.height) * frame.h;
    const w = worldRef.current;
    w.pointer = { x: px, y: py };
    w.isPointerDown = true;
    fireBullet();
  }, [frame.w, frame.h, fireBullet]);

  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * frame.w;
    const py = ((e.clientY - rect.top) / rect.height) * frame.h;
    worldRef.current.pointer = { x: px, y: py };
  }, [frame.w, frame.h]);

  const handlePointerUp = useCallback(() => {
    worldRef.current.isPointerDown = false;
  }, []);

  // Main 60 FPS animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = getFast2DContext(canvas);
    if (!ctx) return;

    let raf = 0;
    let lastTime = performance.now();

    const renderLoop = (now: number) => {
      const dt = Math.min(0.04, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;
      const w = worldRef.current;
      w.time += dt;

      // Handle continuous auto-fire if mouse is held down
      if (w.isPointerDown && weapon.auto && gameState === 'playing') {
        fireBullet();
      }

      // Smooth gun angle tracking
      const targetAngle = Math.atan2(w.pointer.y - w.gunY, w.pointer.x - w.gunX);
      const angleDiff = targetAngle - w.gunAngle;
      w.gunAngle += angleDiff * Math.min(1, dt * 26);

      // Gun recoil & muzzle flash decay (+50% faster recovery)
      w.gunRecoil = Math.max(0, w.gunRecoil - dt * 10.5);
      w.muzzleFlash = Math.max(0, w.muzzleFlash - dt * 18);
      w.screenShake = Math.max(0, w.screenShake - dt * 14);

      // Process spawn queue
      if (gameState === 'playing' || gameState === 'countdown') {
        for (let i = w.spawnQueue.length - 1; i >= 0; i--) {
          const item = w.spawnQueue[i];
          item.delay -= dt;
          if (item.delay <= 0) {
            w.wheels.push({
              ...item.wheel,
              id: w.nextId++,
            });
            w.spawnQueue.splice(i, 1);
          }
        }
      }

      // Update wheels (flight, bounce spring, bounds)
      for (let i = w.wheels.length - 1; i >= 0; i--) {
        const wh = w.wheels[i];
        wh.x += wh.vx * dt;
        wh.y += wh.vy * dt;
        wh.rot += wh.spinSpeed * dt;
        wh.hitFlash = Math.max(0, wh.hitFlash - dt * 5);

        // Rubber/Bouncy squash & stretch spring oscillation (like Martian Heat-Ray effect 1)
        const sqAcc = -300 * wh.squish - 6.8 * wh.squishV;
        wh.squishV += sqAcc * (dt * 1.5);
        wh.squish += wh.squishV * (dt * 1.5);

        // Gentle vertical boundary bounce so they stay in play area
        if (wh.y < wh.radius + 40 && wh.vy < 0) wh.vy = -wh.vy;
        if (wh.y > frame.h - wh.radius - 40 && wh.vy > 0) wh.vy = -wh.vy;

        // Wheel escapes to the left (past the gun line)
        if (wh.x < 50) {
          w.wheels.splice(i, 1);
          w.screenShake = 12;
          try { sfx.hit(); } catch {}
          setLives((l) => {
            const nextL = Math.max(0, l - 1);
            if (nextL === 0) setGameState('game_over');
            return nextL;
          });
          w.texts.push({
            id: w.nextId++,
            text: language === 'id' ? '⚠️ RODA LOLOS! -1 ❤️' : '⚠️ MISSED! -1 ❤️',
            x: 160,
            y: wh.y,
            vy: -40,
            life: 0,
            maxLife: 1.1,
            color: '#ef4444',
            scale: 1.2,
          });
        }
      }

      // Update bullets & collision detection against wheels
      for (let bi = w.bullets.length - 1; bi >= 0; bi--) {
        const b = w.bullets[bi];
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.life += dt;

        let bulletSpent = b.life >= b.maxLife || b.x > frame.w + 60 || b.x < -30 || b.y < -30 || b.y > frame.h + 30;

        if (!bulletSpent) {
          // Check collision with wheels
          for (let wi = w.wheels.length - 1; wi >= 0; wi--) {
            const wh = w.wheels[wi];
            const dist = Math.hypot(b.x - wh.x, b.y - wh.y);

            if (dist <= wh.radius) {
              bulletSpent = true;
              setStats((s) => ({ ...s, hits: s.hits + 1 }));

              // === DISTANCE BASED COIN SCORING ===
              // Bullseye (near center <= 22% radius): 10 coins!
              // Farther from center: scales down smoothly to 1 coin!
              const ratio = Math.min(1, dist / wh.radius);
              let coinsEarned = 1;
              let isBullseye = false;

              if (ratio <= 0.22) {
                coinsEarned = 10;
                isBullseye = true;
                setStats((s) => ({ ...s, bullseyes: s.bullseyes + 1 }));
              } else {
                coinsEarned = Math.max(1, Math.round(10 - ratio * 9.5));
              }

              // Award coins
              setSessionCoins((sc) => sc + coinsEarned);
              onAddCoins(coinsEarned);

              // Sound effects
              try { sfx.coin(); } catch {}

              // === BOUNCY SQUASH & STRETCH EFFECT ===
              // Exactly as requested: bouncy spring reaction like Martian Heat Ray Slide 2
              wh.squishV += 0.88 * 36;
              wh.hitFlash = 0.25;
              wh.hp -= 1;
              wh.cracks += 1;

              // Floating score popup text (pure readable text without missing font glyphs)
              const textStr = isBullseye
                ? (language === 'id' ? '+10 TEPAT TENGAH!' : '+10 BULLSEYE!')
                : `+${coinsEarned} ${language === 'id' ? 'KOIN' : 'COINS'}`;
              const textColor = isBullseye ? '#fde047' : coinsEarned >= 6 ? '#fbbf24' : '#cbd5e1';
              w.texts.push({
                id: w.nextId++,
                text: textStr,
                x: wh.x,
                y: wh.y - wh.radius - 12,
                vy: -55,
                life: 0,
                maxLife: 0.95,
                color: textColor,
                scale: isBullseye ? 1.4 : 1.1,
              });

              // Hit sparks
              for (let p = 0; p < (isBullseye ? 12 : 7); p++) {
                const angle = Math.random() * Math.PI * 2;
                const spd = 80 + Math.random() * 180;
                w.particles.push({
                  x: b.x,
                  y: b.y,
                  vx: Math.cos(angle) * spd,
                  vy: Math.sin(angle) * spd,
                  life: 0.2 + Math.random() * 0.2,
                  maxLife: 0.4,
                  size: 2 + Math.random() * 3,
                  color: isBullseye ? '#facc15' : '#fed7aa',
                  rot: 0,
                  vRot: 0,
                });
              }

              // Check if wheel destroyed
              if (wh.hp <= 0) {
                try { sfx.shatter(); } catch {}
                w.screenShake = wh.isBoss ? 16 : 8;

                // Wheel shattering debris particles
                const shardCount = wh.isBoss ? 20 : 10;
                for (let k = 0; k < shardCount; k++) {
                  const a = (k / shardCount) * Math.PI * 2 + Math.random() * 0.4;
                  const sp = 120 + Math.random() * 240;
                  w.particles.push({
                    x: wh.x,
                    y: wh.y,
                    vx: Math.cos(a) * sp,
                    vy: Math.sin(a) * sp,
                    life: 0.4 + Math.random() * 0.35,
                    maxLife: 0.75,
                    size: 5 + Math.random() * 7,
                    color: wh.theme === 'boss' ? '#ef4444' : wh.theme === 'lemon' ? '#fde047' : '#ea580c',
                    rot: Math.random() * Math.PI,
                    vRot: (Math.random() - 0.5) * 14,
                  });
                }
                w.wheels.splice(wi, 1);
              }
              break;
            }
          }
        }

        if (bulletSpent) {
          w.bullets.splice(bi, 1);
        }
      }

      // Update floating texts
      for (let i = w.texts.length - 1; i >= 0; i--) {
        const txt = w.texts[i];
        txt.y += txt.vy * dt;
        txt.life += dt;
        if (txt.life >= txt.maxLife) w.texts.splice(i, 1);
      }

      // Update particles
      for (let i = w.particles.length - 1; i >= 0; i--) {
        const pt = w.particles[i];
        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;
        pt.rot += pt.vRot * dt;
        pt.life -= dt;
        if (pt.life <= 0) w.particles.splice(i, 1);
      }

      // Check wave completion
      if (gameState === 'playing' && w.wheels.length === 0 && w.spawnQueue.length === 0) {
        if (currentRound < TOTAL_ROUNDS) {
          setGameState('round_clear');
          setTimeout(() => {
            startRound(currentRound + 1);
          }, 1400);
        } else {
          setGameState('victory');
        }
      }

      // ─────────────────────────────────────────────────────────────
      // DRAW PASS
      // ─────────────────────────────────────────────────────────────
      const dpr = getMaxCanvasDpr();
      if (canvas.width !== Math.round(frame.w * dpr) || canvas.height !== Math.round(frame.h * dpr)) {
        canvas.width = Math.round(frame.w * dpr);
        canvas.height = Math.round(frame.h * dpr);
      }

      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Camera shake
      if (w.screenShake > 0) {
        const sx = (Math.random() - 0.5) * w.screenShake;
        const sy = (Math.random() - 0.5) * w.screenShake;
        ctx.translate(sx, sy);
      }

      // 1. Cyber / Arcade Night Sky Background
      ctx.fillStyle = '#060a14';
      ctx.fillRect(0, 0, frame.w, frame.h);

      // Background grid lines
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
      ctx.lineWidth = 1;
      const gridGap = 40;
      const gridOffset = (w.time * 20) % gridGap;
      for (let x = -gridOffset; x < frame.w; x += gridGap) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, frame.h);
        ctx.stroke();
      }
      for (let y = 0; y < frame.h; y += gridGap) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(frame.w, y);
        ctx.stroke();
      }

      // Aiming laser guide line from gun to cursor
      ctx.save();
      ctx.setLineDash([4, 8]);
      ctx.lineDashOffset = -w.time * 40;
      ctx.strokeStyle = 'rgba(244, 63, 94, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(w.gunX, w.gunY);
      ctx.lineTo(w.pointer.x, w.pointer.y);
      ctx.stroke();
      ctx.restore();

      // 2. Draw Bullets
      for (const b of w.bullets) {
        ctx.save();
        ctx.translate(b.x, b.y);
        const ang = Math.atan2(b.vy, b.vx);
        ctx.rotate(ang);
        // Bullet tracer glow
        ctx.fillStyle = '#fef08a';
        ctx.shadowColor = '#eab308';
        ctx.shadowBlur = 8;
        ctx.fillRect(-12, -2.5, 24, 5);
        ctx.restore();
      }

      // 3. Draw Wheels with Bouncy Squash & Stretch!
      for (const wh of w.wheels) {
        ctx.save();
        ctx.translate(wh.x, wh.y);

        // Bouncy squash & stretch scaling
        const sq = Math.max(-1.15, Math.min(1.28, wh.squish));
        const squashX = Math.max(0.72, 1 + sq * 0.22);
        const squashY = Math.max(0.68, 1 - sq * 0.26);
        ctx.scale(squashX, squashY);
        ctx.rotate(wh.rot);

        const r = wh.radius;

        // Hit flash overlay
        if (wh.hitFlash > 0) {
          ctx.shadowColor = '#ffffff';
          ctx.shadowBlur = 18;
        }

        if (wh.theme === 'boss') {
          // Boss & Mini-Boss Wheel artwork
          // Fiery / Demonic Crimson Rim
          ctx.beginPath();
          ctx.arc(0, 0, r, 0, Math.PI * 2);
          ctx.fillStyle = '#1e1b4b';
          ctx.fill();
          ctx.lineWidth = wh.isBoss ? 7 : 5;
          ctx.strokeStyle = '#dc2626';
          ctx.stroke();

          // Boss spikes / gears
          const teeth = wh.isBoss ? 12 : 8;
          ctx.fillStyle = '#f87171';
          for (let k = 0; k < teeth; k++) {
            const ta = (k / teeth) * Math.PI * 2;
            const tx = Math.cos(ta) * (r + 4);
            const ty = Math.sin(ta) * (r + 4);
            ctx.beginPath();
            ctx.arc(tx, ty, wh.isBoss ? 6 : 4, 0, Math.PI * 2);
            ctx.fill();
          }

          // Center demonic boss face / skull emblem
          ctx.beginPath();
          ctx.arc(0, 0, r * 0.65, 0, Math.PI * 2);
          ctx.fillStyle = '#7f1d1d';
          ctx.fill();

          // Glowing angry eyes
          const eyeX = r * 0.28;
          const eyeY = -r * 0.12;
          const eyeR = wh.isBoss ? 7 : 5;
          ctx.fillStyle = '#fef08a';
          ctx.beginPath();
          ctx.arc(-eyeX, eyeY, eyeR, 0, Math.PI * 2);
          ctx.arc(eyeX, eyeY, eyeR, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#b91c1c';
          ctx.beginPath();
          ctx.arc(-eyeX, eyeY, eyeR * 0.45, 0, Math.PI * 2);
          ctx.arc(eyeX, eyeY, eyeR * 0.45, 0, Math.PI * 2);
          ctx.fill();

          // Bullseye Target Ring at center (gold/white center dot for the 10 coins!)
          ctx.strokeStyle = 'rgba(254, 240, 138, 0.85)';
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.arc(0, 0, r * 0.22, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = '#facc15';
          ctx.beginPath();
          ctx.arc(0, 0, 4, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // Citrus Wheel (Orange / Lemon / Lime)
          const rindColor = wh.theme === 'lemon' ? '#facc15' : wh.theme === 'lime' ? '#65a30d' : '#f59e0b';
          const fleshColor = wh.theme === 'lemon' ? '#fde047' : wh.theme === 'lime' ? '#a3e635' : '#fb923c';

          // Outer Rind
          ctx.beginPath();
          ctx.arc(0, 0, r, 0, Math.PI * 2);
          ctx.fillStyle = rindColor;
          ctx.fill();
          ctx.lineWidth = 4;
          ctx.strokeStyle = '#78350f';
          ctx.stroke();

          // Pith (white circle)
          ctx.beginPath();
          ctx.arc(0, 0, r * 0.9, 0, Math.PI * 2);
          ctx.fillStyle = '#fffbeb';
          ctx.fill();

          // Flesh
          ctx.beginPath();
          ctx.arc(0, 0, r * 0.82, 0, Math.PI * 2);
          ctx.fillStyle = fleshColor;
          ctx.fill();

          // 10 Citrus Segments lines
          ctx.strokeStyle = '#fffbeb';
          ctx.lineWidth = 3;
          for (let s = 0; s < 10; s++) {
            const a = (s / 10) * Math.PI * 2;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(Math.cos(a) * r * 0.82, Math.sin(a) * r * 0.82);
            ctx.stroke();
          }

          // Bullseye Center Core (Gold/Amber 10-Coins Target Zone!)
          ctx.beginPath();
          ctx.arc(0, 0, r * 0.22, 0, Math.PI * 2);
          ctx.fillStyle = '#fffbeb';
          ctx.fill();
          ctx.beginPath();
          ctx.arc(0, 0, r * 0.16, 0, Math.PI * 2);
          ctx.fillStyle = '#f59e0b';
          ctx.fill();
          ctx.beginPath();
          ctx.arc(0, 0, 3, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();

          // Armor Ring for 2 HP wheels
          if (wh.maxHp > 1) {
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 3.5;
            ctx.beginPath();
            ctx.arc(0, 0, r + 2, 0, Math.PI * 2);
            ctx.stroke();
          }
        }

        // Damage cracks if hit once but not destroyed
        if (wh.cracks > 0) {
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(-r * 0.4, -r * 0.2);
          ctx.lineTo(r * 0.1, r * 0.1);
          ctx.lineTo(r * 0.35, -r * 0.3);
          ctx.stroke();
        }

        ctx.restore();

        // HP Badge / Dots above wheel (drawn without rotation)
        if (wh.maxHp > 1) {
          ctx.save();
          ctx.translate(wh.x, wh.y - wh.radius - 12);
          ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
          ctx.beginPath();
          ctx.roundRect(-16, -6, 32, 12, 6);
          ctx.fill();
          ctx.strokeStyle = wh.isBoss ? '#ef4444' : '#38bdf8';
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // HP pips
          const pipGap = 24 / wh.maxHp;
          for (let p = 0; p < wh.maxHp; p++) {
            ctx.fillStyle = p < wh.hp ? (wh.isBoss ? '#f87171' : '#38bdf8') : 'rgba(255,255,255,0.2)';
            ctx.beginPath();
            ctx.arc(-12 + p * pipGap + pipGap / 2, 0, 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        }
      }

      // 4. Draw Particles
      for (const p of w.particles) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        const alpha = Math.max(0, p.life / p.maxLife);
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(0, 0, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // 5. Draw Player Gun on the LEFT facing target angle
      ctx.save();
      // Gun base position with recoil kickback
      const kickX = Math.cos(w.gunAngle) * (-w.gunRecoil * 18);
      const kickY = Math.sin(w.gunAngle) * (-w.gunRecoil * 18);
      ctx.translate(w.gunX + kickX, w.gunY + kickY);

      // Rotate gun to face mouse aim angle (+90 deg because drawGunCentered points UP)
      ctx.rotate(w.gunAngle + Math.PI / 2);
      ctx.scale(0.85, 0.85);

      try {
        drawGunCentered(ctx, weaponId, w.time, w.muzzleFlash, true, variant);
      } catch {
        // Fallback simple gun if art fails
        ctx.fillStyle = '#64748b';
        ctx.fillRect(-12, -45, 24, 70);
      }
      ctx.restore();

      // 6. Floating Score & Miss Texts
      for (const txt of w.texts) {
        ctx.save();
        ctx.translate(txt.x, txt.y);
        const a = Math.max(0, 1 - txt.life / txt.maxLife);
        ctx.globalAlpha = a;
        ctx.font = `bold ${Math.round(18 * txt.scale)}px 'Russo One', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.85)';
        ctx.lineWidth = 4;
        ctx.strokeText(txt.text, 0, 0);
        ctx.fillStyle = txt.color;
        ctx.fillText(txt.text, 0, 0);
        ctx.restore();
      }

      // 7. Crosshair at Mouse Pointer
      ctx.save();
      ctx.translate(w.pointer.x, w.pointer.y);
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(0, 0, 14, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-18, 0); ctx.lineTo(-7, 0);
      ctx.moveTo(7, 0); ctx.lineTo(18, 0);
      ctx.moveTo(0, -18); ctx.lineTo(0, -7);
      ctx.moveTo(0, 7); ctx.lineTo(0, 18);
      ctx.stroke();
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.restore();

      raf = requestAnimationFrame(renderLoop);
    };

    raf = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(raf);
  }, [frame.w, frame.h, weaponId, variant, weapon.auto, gameState, currentRound, language, fireBullet, onAddCoins, startRound]);

  return (
    <div
      className="absolute inset-0 z-50 h-full w-full select-none overflow-hidden bg-[#060a14] font-game text-white"
      style={{ width: frame.w, height: frame.h }}
    >
      {/* Canvas */}
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="block h-full w-full cursor-crosshair touch-none"
        style={{ width: frame.w, height: frame.h }}
      />

      {/* TOP HUD */}
      <div className="pointer-events-none absolute inset-x-0 top-2.5 z-30 flex items-center justify-between px-4">
        {/* Left: Exit button & Lives */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="pointer-events-auto press flex items-center gap-1 rounded-xl border border-white/20 bg-slate-900/80 px-2.5 py-1.5 text-[11px] font-bold text-white shadow-md backdrop-blur hover:bg-slate-800"
          >
            <X className="h-4 w-4 text-rose-400" />
            <span>EXIT</span>
          </button>

          {/* Hearts / Lives */}
          <div className="flex items-center gap-1 rounded-xl border border-rose-500/30 bg-rose-950/60 px-2.5 py-1 text-rose-400 shadow-md backdrop-blur">
            {Array.from({ length: 3 }).map((_, i) => (
              <svg
                key={i}
                viewBox="0 0 24 24"
                className={`h-4 w-4 transition-transform ${
                  i < lives ? 'scale-100 fill-rose-500 text-rose-500 drop-shadow-[0_0_6px_rgba(244,63,94,0.6)]' : 'scale-85 fill-slate-700 text-slate-700 opacity-40'
                }`}
              >
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
              </svg>
            ))}
          </div>
        </div>

        {/* Center: Round info */}
        <div className="flex flex-col items-center">
          <div className="rounded-xl border border-purple-500/40 bg-gradient-to-r from-purple-900/80 via-indigo-900/80 to-purple-900/80 px-4 py-1 text-center shadow-lg backdrop-blur">
            <span className="text-[14px] font-black tracking-wider text-purple-200">
              {currentRound === 5 ? (language === 'id' ? '👑 RONDE BOS' : '👑 BOSS WAVE') : `RONDE ${currentRound} / 5`}
            </span>
          </div>
          <span className="mt-0.5 text-[10px] font-bold text-slate-300 drop-shadow">
            {language === 'id' ? 'Tembak titik tengah untuk 10 Koin!' : 'Shoot center for 10 Coins!'}
          </span>
        </div>

        {/* Right: Coins earned */}
        <div className="flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-950/70 px-3 py-1.5 shadow-lg backdrop-blur">
          <CoinSprite size={20} />
          <span className="font-mono text-[16px] font-black text-amber-300 tabular-nums">
            +{sessionCoins}
          </span>
        </div>
      </div>

      {/* ROUND START BANNER */}
      {gameState === 'countdown' && (
        <div className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center">
          <div className="animate-bounce-in rounded-2xl border-2 border-purple-400/80 bg-slate-950/90 px-8 py-4 text-center shadow-[0_0_40px_rgba(168,85,247,0.5)] backdrop-blur">
            <div className="text-[26px] font-black tracking-wider text-yellow-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
              {roundBanner}
            </div>
            <div className="mt-1 text-[13px] font-bold text-purple-200">
              {currentRound === 5
                ? (language === 'id' ? '1 Bos Besar + 5 Pasukan Mini!' : '1 Giant Boss + 5 Mini Squads!')
                : (language === 'id' ? `${currentRound} Roda Berdatangan!` : `${currentRound} Incoming Wheels!`)}
            </div>
          </div>
        </div>
      )}

      {/* ROUND CLEAR BANNER */}
      {gameState === 'round_clear' && (
        <div className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center">
          <div className="animate-scale-up rounded-2xl border-2 border-emerald-400/80 bg-slate-950/90 px-8 py-4 text-center shadow-[0_0_40px_rgba(52,211,153,0.5)] backdrop-blur">
            <div className="text-[26px] font-black tracking-wider text-emerald-400 drop-shadow">
              {language === 'id' ? `RONDE ${currentRound} SELESAI!` : `ROUND ${currentRound} CLEARED!`}
            </div>
            <div className="mt-1 flex items-center justify-center gap-1.5 text-[14px] font-bold text-amber-300">
              <span>+{sessionCoins}</span>
              <CoinSprite size={16} />
              <span>{language === 'id' ? 'Koin Terkumpul' : 'Coins Earned'}</span>
            </div>
          </div>
        </div>
      )}

      {/* VICTORY MODAL */}
      {gameState === 'victory' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="relative flex w-[90%] max-w-[420px] flex-col items-center rounded-3xl border-2 border-yellow-400/80 bg-gradient-to-b from-[#1e1b4b] to-[#0f172a] p-6 text-center shadow-[0_0_60px_rgba(250,204,21,0.4)]">
            <Trophy className="h-16 w-16 text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.8)]" />
            <h2 className="mt-2 text-[26px] font-black tracking-wider text-yellow-300">
              {language === 'id' ? '🏆 SWARM TAKLUK!' : '🏆 SWARM CLEARED!'}
            </h2>
            <p className="mt-1 text-[12px] font-semibold text-slate-300">
              {language === 'id'
                ? 'Semua gelombang roda dan bos berhasil dihancurkan!'
                : 'All wheel waves and the boss have been conquered!'}
            </p>

            <div className="my-4 grid w-full grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="text-[11px] font-bold text-slate-400">{language === 'id' ? 'TOTAL KOIN' : 'TOTAL COINS'}</div>
                <div className="mt-1 flex items-center justify-center gap-1.5 text-[20px] font-black text-amber-300">
                  <CoinSprite size={20} />
                  <span>+{sessionCoins}</span>
                </div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="text-[11px] font-bold text-slate-400">{language === 'id' ? 'BULLSEYE' : 'BULLSEYES'}</div>
                <div className="mt-1 text-[20px] font-black text-emerald-400">
                  🎯 {stats.bullseyes}
                </div>
              </div>
            </div>

            <div className="flex w-full gap-3">
              <button
                type="button"
                onClick={() => startRound(1)}
                className="press flex flex-1 items-center justify-center gap-1.5 rounded-2xl border border-purple-400 bg-gradient-to-r from-purple-600 to-indigo-600 py-3 text-[14px] font-black text-white shadow-lg active:scale-95"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{language === 'id' ? 'MAIN LAGI' : 'PLAY AGAIN'}</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="press flex flex-1 items-center justify-center gap-1.5 rounded-2xl border border-amber-300 bg-gradient-to-r from-amber-500 to-yellow-500 py-3 text-[14px] font-black text-slate-950 shadow-lg active:scale-95"
              >
                <span>{language === 'id' ? 'KEMBALI KE MENU' : 'RETURN TO MENU'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GAME OVER MODAL */}
      {gameState === 'game_over' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="relative flex w-[90%] max-w-[400px] flex-col items-center rounded-3xl border-2 border-rose-500/80 bg-gradient-to-b from-[#31131a] to-[#0f172a] p-6 text-center shadow-[0_0_60px_rgba(244,63,94,0.4)]">
            <AlertTriangle className="h-14 w-14 text-rose-500 drop-shadow-[0_0_15px_rgba(244,63,94,0.8)]" />
            <h2 className="mt-2 text-[24px] font-black tracking-wider text-rose-400">
              {language === 'id' ? 'RODA LOLOS!' : 'WHEEL CRASHED!'}
            </h2>
            <p className="mt-1 text-[12px] font-semibold text-slate-300">
              {language === 'id'
                ? `Roda berhasil menerobos pertahanan di Ronde ${currentRound}.`
                : `A wheel breached defenses at Round ${currentRound}.`}
            </p>

            <div className="my-4 flex items-center justify-center gap-2 rounded-2xl border border-amber-500/30 bg-amber-950/50 px-4 py-2 text-[15px] font-black text-amber-300">
              <span>{language === 'id' ? 'Koin Tersimpan:' : 'Coins Kept:'}</span>
              <CoinSprite size={18} />
              <span>+{sessionCoins}</span>
            </div>

            <div className="flex w-full gap-3">
              <button
                type="button"
                onClick={() => {
                  setLives(3);
                  startRound(currentRound);
                }}
                className="press flex flex-1 items-center justify-center gap-1.5 rounded-2xl border border-rose-400 bg-gradient-to-r from-rose-600 to-red-600 py-3 text-[14px] font-black text-white shadow-lg active:scale-95"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{language === 'id' ? 'COBA LAGI' : 'TRY AGAIN'}</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="press flex flex-1 items-center justify-center gap-1.5 rounded-2xl border border-slate-600 bg-slate-800 py-3 text-[14px] font-black text-white shadow-lg active:scale-95"
              >
                <span>MENU</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
