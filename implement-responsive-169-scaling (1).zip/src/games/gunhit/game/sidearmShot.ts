/**
 * SIDEARM sample — thin wrapper kept for the two original call sites
 * (slide 1's `sfx.shoot()` and slide 4's `Synth.play('pistol')`). The sample
 * itself, its licence and the shared decode live in `gunSamples.ts` together
 * with the AK-47, shotgun and nail-gun recordings.
 */
import { gunSampleReady, loadGunSamples, playGunSample } from './gunSamples';

export function loadSidearmShot(ctx: BaseAudioContext): void {
  loadGunSamples(ctx);
}

export function sidearmShotReady(): boolean {
  return gunSampleReady('pistol');
}

export function playSidearmShot(
  ctx: AudioContext,
  dest: AudioNode,
  gain: number,
  send?: { node: AudioNode; amount: number } | null,
): boolean {
  return playGunSample('pistol', ctx, dest, gain, send);
}
