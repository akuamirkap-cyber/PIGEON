/**
 * Damage / combo callouts ("+10", "PERFECT") as cached sprites.
 *
 * Each callout used to be rasterised from scratch on every frame it was alive:
 * two `strokeText` passes (a 0.28·size dark outline and a 0.14·size white one)
 * plus a gradient `fillText`, all under a rotated, popping transform that the
 * HUD text cache cannot serve. A burst of hits puts several of these on screen
 * at once, and stroked text is one of the most expensive things a 2D canvas
 * can do — it showed up as 20+ ms frames right when the game should feel most
 * responsive.
 *
 * The glyphs never change while a callout lives; only its position, rotation,
 * pop scale and alpha do. So the text is painted once, at device resolution
 * with room for the biggest pop, into a small canvas and blitted with
 * `drawImage` afterwards — one call per callout per frame.
 */
export interface ImpactTextSprite {
  cv: HTMLCanvasElement;
  /** Size to draw the sprite at, in the caller's (world) units. */
  w: number;
  h: number;
}

const cache = new Map<string, ImpactTextSprite>();
const MAX_ENTRIES = 48;
let measurer: CanvasRenderingContext2D | null = null;

function fontFor(size: number): string {
  return `italic 900 ${size}px Impact, 'Arial Black', sans-serif`;
}

/**
 * @param density device pixels per world unit the sprite should be baked at
 *                (world scale × DPR × the largest pop the callout reaches).
 * @param color   the resolved CSS colour for the middle gradient stop.
 */
export function impactTextSprite(text: string, size: number, color: string, density: number): ImpactTextSprite | null {
  if (typeof document === 'undefined' || !text) return null;
  // Quantise the density so a slowly changing stage scale does not mint a new
  // sprite per frame; 0.25 steps are invisible on a tumbling callout.
  const d = Math.min(4, Math.max(1, Math.ceil(density * 4) / 4));
  const key = `${text}|${size}|${color}|${d}`;
  const hit = cache.get(key);
  if (hit) return hit;

  measurer ??= document.createElement('canvas').getContext('2d');
  if (!measurer) return null;
  const font = fontFor(size);
  measurer.font = font;
  measurer.textAlign = 'center';
  measurer.textBaseline = 'middle';
  const m = measurer.measureText(text);
  // Outline + round joins reach past the glyph box; pad for the widest stroke.
  const pad = size * 0.16 + 3;
  const left = (Number.isFinite(m.actualBoundingBoxLeft) ? m.actualBoundingBoxLeft : m.width / 2) + pad;
  const right = (Number.isFinite(m.actualBoundingBoxRight) ? m.actualBoundingBoxRight : m.width / 2) + pad;
  const up = (Number.isFinite(m.actualBoundingBoxAscent) ? m.actualBoundingBoxAscent : size * 0.6) + pad;
  const down = (Number.isFinite(m.actualBoundingBoxDescent) ? m.actualBoundingBoxDescent : size * 0.4) + pad;
  const half = Math.max(left, right); // keep the anchor at the sprite's centre
  const vhalf = Math.max(up, down);
  const w = Math.ceil(half * 2);
  const h = Math.ceil(vhalf * 2);

  let cv: HTMLCanvasElement | undefined;
  if (cache.size >= MAX_ENTRIES) {
    // Map iterates in insertion order: the first key is the oldest sprite.
    const oldest = cache.keys().next().value as string | undefined;
    if (oldest !== undefined) {
      cv = cache.get(oldest)?.cv;
      cache.delete(oldest);
    }
  }
  cv ??= document.createElement('canvas');
  cv.width = Math.max(1, Math.ceil(w * d));
  cv.height = Math.max(1, Math.ceil(h * d));
  const g = cv.getContext('2d');
  if (!g) return null;
  g.setTransform(d, 0, 0, d, (w / 2) * d, (h / 2) * d);
  g.font = font;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.lineJoin = 'round';
  g.strokeStyle = '#1a0a00';
  g.lineWidth = size * 0.28;
  g.strokeText(text, 0, 0);
  g.strokeStyle = '#ffffff';
  g.lineWidth = size * 0.14;
  g.strokeText(text, 0, 0);
  const tg = g.createLinearGradient(0, -size / 2, 0, size / 2);
  tg.addColorStop(0, '#fff6b0');
  tg.addColorStop(0.5, color);
  tg.addColorStop(1, '#ff7a00');
  g.fillStyle = tg;
  g.fillText(text, 0, 0);

  const entry: ImpactTextSprite = { cv, w, h };
  cache.set(key, entry);
  return entry;
}
