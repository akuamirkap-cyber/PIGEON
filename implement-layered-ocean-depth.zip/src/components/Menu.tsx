import { useEffect, useMemo, useState } from "react";
import { SKINS, skinToSpecies } from "../game/species";
import { spriteDataURL, coinSprite } from "../game/sprites";
import type { JawState } from "../game/sprites";
import type { SaveData } from "../save";
import { UPGRADE_COSTS, MAX_UPGRADE } from "../save";
import type { Upgrades } from "../game/engine";

interface Props {
  save: SaveData;
  setSave: (s: SaveData) => void;
  onPlay: () => void;
  loading?: boolean;
  loadPct?: number;
}

const UPGRADES: { id: keyof Upgrades; name: string; desc: string; icon: string }[] = [
  { id: "suck", name: "Sedotan Super", desc: "Jangkauan & kekuatan sedot lebih mantap", icon: "🌀" },
  { id: "speed", name: "Sirip Turbo", desc: "Berenang & belok lebih lincah", icon: "💨" },
  { id: "size", name: "Ikan Bongsor", desc: "Mulai sedikit lebih besar", icon: "🍔" },
];

export function coinURL() {
  return coinSprite(0).toDataURL();
}

const THUMBS: Record<string, string> = {}; // skin thumbnails, generated once
const PREVIEW_CYCLE: JawState[] = [0, 0, 0, 1, 2, 3, 3, -1, -1, 0, 0];

export default function Menu({ save, setSave, onPlay, loading = false, loadPct = 0 }: Props) {
  const [tab, setTab] = useState<"skin" | "shop">("skin");
  const [animStep, setAnimStep] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setAnimStep((s) => (s + 1) % PREVIEW_CYCLE.length), 210);
    return () => clearInterval(id);
  }, []);

  // Thumbnails are drawn two per frame AFTER the menu has appeared (and cached across visits),
  // instead of rendering all of them before the first paint.
  const [skinImgs, setSkinImgs] = useState<Record<string, string>>(() => ({ ...THUMBS }));
  useEffect(() => {
    let alive = true;
    let id = 0;
    const tick = () => {
      if (!alive) return;
      let n = 0;
      for (const s of SKINS) {
        if (THUMBS[s.id]) continue;
        THUMBS[s.id] = spriteDataURL(skinToSpecies(s), 190, 0);
        if (++n >= 2) break;
      }
      if (n > 0) {
        setSkinImgs({ ...THUMBS });
        id = requestAnimationFrame(tick);
      }
    };
    id = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(id);
    };
  }, []);

  const cur = SKINS.find((s) => s.id === save.skin) || SKINS[0];
  const heroFrames = useMemo(() => {
    const sp = skinToSpecies(cur);
    const states: JawState[] = [-1, 0, 1, 2, 3];
    return Object.fromEntries(states.map((st) => [st, spriteDataURL(sp, 240, st)])) as Record<JawState, string>;
  }, [cur]);

  const coin = useMemo(() => coinURL(), []);

  // every fish is unlocked: picking one simply equips it
  const pickSkin = (id: string) => setSave({ ...save, skin: id });

  const buyUp = (id: keyof Upgrades) => {
    const lv = save.upgrades[id];
    if (lv >= MAX_UPGRADE) return;
    const cost = UPGRADE_COSTS[lv];
    if (save.coins < cost) return;
    setSave({ ...save, coins: save.coins - cost, upgrades: { ...save.upgrades, [id]: lv + 1 } });
  };

  const curJaw = PREVIEW_CYCLE[animStep];

  const titleChars = [
    { ch: "F", isIo: false, delay: "0s" },
    { ch: "i", isIo: false, delay: "0.11s" },
    { ch: "s", isIo: false, delay: "0.22s" },
    { ch: "h", isIo: false, delay: "0.33s" },
    { ch: ".", isIo: true, delay: "0.44s" },
    { ch: "i", isIo: true, delay: "0.55s" },
    { ch: "o", isIo: true, delay: "0.66s" },
  ];

  return (
    <div
      className="absolute inset-0 flex overflow-y-auto p-3 clean-font"
      style={{
        background:
          "radial-gradient(ellipse at 50% 24%, rgba(28, 176, 224, 0.10) 0%, rgba(6, 26, 62, 0.34) 55%, rgba(3, 12, 34, 0.64) 100%)",
      }}
    >
      <div className="m-auto w-full max-w-[1060px] flex flex-col items-center gap-3.5 py-2.5">
        {/* ============ ARTISTIC Fish.io HEADER MATCHING REFERENCE LOGO ============ */}
        <div className="relative text-center select-none flex flex-col items-center pt-1">
          {/* Crisp Underwater Sunbeam Starburst behind Fish.io Title */}
          <div
            className="sun-halo-spin pointer-events-none -top-10 absolute w-[360px] sm:w-[480px] h-[180px] rounded-full opacity-55"
            style={{
              background:
                "repeating-conic-gradient(from 0deg, rgba(135, 245, 255, 0.22) 0deg 10deg, transparent 10deg 26deg)",
              WebkitMaskImage: "radial-gradient(ellipse at center, black 20%, transparent 72%)",
              maskImage: "radial-gradient(ellipse at center, black 20%, transparent 72%)",
            }}
          />

          {/* Title Row with Left-Flanking Animated Clownfish & Blue Reef Fish */}
          <div className="relative inline-flex items-center justify-center px-10 sm:px-14">
            {/* Top-Left Swimming Orange Clownfish */}
            <svg
              viewBox="0 0 60 36"
              className="mascot-wiggle pointer-events-none absolute -left-2 sm:left-0 top-1 sm:top-2 w-11 h-7 sm:w-14 sm:h-9 drop-shadow-[0_3px_5px_rgba(0,0,0,0.65)]"
            >
              <path className="mascot-tail" d="M16,18 L3,8 L7,18 L3,28 Z" fill="#ff7d14" stroke="#1e0b02" strokeWidth="2.5" strokeLinejoin="round" />
              <path d="M14,18 C16,7 38,5 54,18 C38,31 16,29 14,18 Z" fill="#ff841a" stroke="#1e0b02" strokeWidth="2.6" />
              <path d="M27,9 C25,18 25,21 27,27" fill="none" stroke="#ffffff" strokeWidth="3.6" />
              <path d="M38,9 C36,18 36,21 38,27" fill="none" stroke="#ffffff" strokeWidth="3.2" />
              <g className="mascot-eye">
                <circle cx="45" cy="15" r="4" fill="#ffffff" stroke="#1e0b02" strokeWidth="1.8" />
                <circle cx="46.2" cy="15" r="2" fill="#121c36" />
                <circle cx="45.6" cy="14" r="0.8" fill="#ffffff" />
              </g>
              <path d="M47,20 Q51,22 54,19" fill="none" stroke="#1e0b02" strokeWidth="1.8" strokeLinecap="round" />
            </svg>

            {/* Main Bold Golden + Cyan Fish.io Title */}
            <h1 className="font-extrabold text-[62px] sm:text-[90px] md:text-[106px] leading-none tracking-tight flex items-baseline">
              {titleChars.map((item, idx) => (
                <span
                  key={idx}
                  className={`fish-letter ${item.isIo ? "fish-word-io" : "fish-word-gold"}`}
                  style={{ animationDelay: item.delay }}
                >
                  {item.ch}
                </span>
              ))}
            </h1>
          </div>

          {/* Wide Dark Wooden Pill Badge with Golden Rim & Left-Perched Blue Fish */}
          <div className="relative -mt-1.5 sm:-mt-2.5 z-10">
            {/* Small Blue Reef Fish Perched on Left Edge of Pill Banner */}
            <svg
              viewBox="0 0 50 32"
              className="bob pointer-events-none absolute -left-3 sm:-left-4 -top-4 w-9 h-6 sm:w-11 sm:h-7 z-20 drop-shadow-[0_3px_4px_rgba(0,0,0,0.65)]"
            >
              <path className="mascot-tail" d="M14,16 L2,8 L5,16 L2,24 Z" fill="#2294ff" stroke="#0c1a3a" strokeWidth="2.3" strokeLinejoin="round" />
              <path d="M12,16 C14,6 34,5 46,16 C34,27 14,26 12,16 Z" fill="#2cb6ff" stroke="#0c1a3a" strokeWidth="2.4" />
              <path d="M23,8 L23,24 M30,8 L30,24" stroke="#0e45a0" strokeWidth="2.6" />
              <circle cx="38" cy="14" r="3.4" fill="#ffffff" stroke="#0c1a3a" strokeWidth="1.6" />
              <circle cx="39" cy="14" r="1.7" fill="#0c1a3a" />
            </svg>

            <div className="badge-glow relative overflow-hidden ui-sheen px-7 sm:px-14 py-1.5 sm:py-2 rounded-full bg-[#361b08]/95 border-[2.5px] border-[#e8a645] shadow-[0_6px_16px_rgba(0,0,0,0.65)] flex items-center gap-3 sm:gap-5">
              <span className="text-sky-300 text-[13px] sm:text-[15px]">⚓</span>
              <span className="font-extrabold text-[12px] sm:text-[15.5px] tracking-[0.12em] text-white uppercase drop-shadow-[0_2px_2px_rgba(0,0,0,0.9)]">
                LAUTAN BERLAPIS • FEEDING FRENZY
              </span>
              <span className="text-sky-300 text-[13px] sm:text-[15px]">⚓</span>
            </div>
          </div>

          {/* Slogan & Gameplay Tip */}
          <div className="text-outline font-semibold text-[12px] sm:text-[14.5px] mt-2 text-cyan-50 max-w-[660px] leading-snug">
            🌀 Sedot gerombolan ikan kecil untuk <span className="text-yellow-300 font-bold">COMBO</span> beruntun &amp; hujan koin — habiskan kawanan untuk bonus{" "}
            <span className="text-emerald-300 font-bold">SAPU BERSIH!</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 w-full items-stretch mt-0.5">
          {/* Left: Live Animated Hero Preview & Play */}
          <div className="artistic-wood-board relative p-5 flex-1 flex flex-col items-center justify-between gap-3 shadow-2xl">
            {/* Decorative Swaying Coral Flourishes */}
            <svg viewBox="0 0 36 42" className="coral-sway pointer-events-none absolute -top-5 -left-3 w-8 h-9 drop-shadow-[0_3px_4px_rgba(0,0,0,0.5)]">
              <path d="M18,40 L18,22 M18,28 C12,24 9,17 11,10 M18,23 C25,19 28,12 25,6 M14,19 C10,16 6,17 5,13" fill="none" stroke="#ff6b2b" strokeWidth="4.5" strokeLinecap="round" />
              <path d="M18,40 L18,22 M18,28 C12,24 9,17 11,10 M18,23 C25,19 28,12 25,6" fill="none" stroke="#ffbe4f" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
            <svg viewBox="0 0 36 42" className="coral-sway-r pointer-events-none absolute -top-5 -right-3 w-8 h-9 drop-shadow-[0_3px_4px_rgba(0,0,0,0.5)]">
              <path d="M18,40 L18,20 M18,27 C11,22 8,15 11,8 M18,22 C24,18 28,13 26,6" fill="none" stroke="#a644e8" strokeWidth="4.5" strokeLinecap="round" />
              <path d="M18,40 L18,20 M18,27 C11,22 8,15 11,8 M18,22 C24,18 28,13 26,6" fill="none" stroke="#eab8ff" strokeWidth="1.5" strokeLinecap="round" />
            </svg>

            {/* Nautical Brass Screws in corners */}
            <div className="absolute top-2.5 left-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute top-2.5 right-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2.5 left-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2.5 right-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>

            {/* Sunlit Underwater Pearl Pedestal */}
            <div className="flex flex-col items-center w-full">
              <div className="relative flex flex-col items-center justify-center py-1">
                {/* Soft sunlit aura & caustic floor shimmer */}
                <div className="absolute inset-0 bg-cyan-300/20 blur-2xl rounded-full" />
                <div className="caustic-pedestal absolute bottom-1 w-32 h-5 rounded-full bg-gradient-to-r from-transparent via-cyan-300/45 to-transparent blur-[3px]" />
                <img
                  src={heroFrames[curJaw]}
                  className="bob relative z-10 h-32 object-contain drop-shadow-[0_10px_16px_rgba(0,0,0,0.65)]"
                  alt={cur.name}
                />
              </div>
              <div className="mt-0.5 px-3.5 py-0.5 rounded-full bg-[#241306]/80 border border-[#75451d] text-[15px] font-extrabold text-amber-100 text-outline flex items-center gap-1.5 shadow">
                <span>{cur.name}</span>
                <span className="text-yellow-300 text-[12.5px] font-bold">({cur.subtitle})</span>
              </div>
            </div>

            <div className="relative w-full">
              <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[16px] opacity-80">🏷️</span>
              <input
                value={save.name}
                maxLength={14}
                onChange={(e) => setSave({ ...save, name: e.target.value })}
                onKeyDown={(e) => {
                  if (e.key === "Enter") onPlay();
                }}
                placeholder="Nama ikanmu..."
                className="w-full font-bold text-[16px] text-center py-2.5 px-9 rounded-xl bg-[#221206] text-amber-100 border-2 border-[#6e3f18] outline-none focus:border-yellow-300 focus:shadow-[0_0_12px_rgba(255,220,90,0.35)] placeholder:text-amber-200/40 shadow-inner transition-all"
              />
            </div>

            <button
              onClick={onPlay}
              className={`ui-btn ui-sheen relative overflow-hidden w-full py-3.5 text-[23px] text-white tracking-wide ${loading ? "" : "play-btn-pulse"}`}
              style={{
                background: loading ? "linear-gradient(180deg, #3f8a62, #246342)" : "linear-gradient(180deg, #4be880, #1ba248)",
                cursor: "pointer",
              }}
            >
              {loading && (
                <span
                  className="absolute inset-y-0 left-0"
                  style={{ width: `${Math.round(loadPct * 100)}%`, background: "linear-gradient(180deg, #45e078, #1fa84d)", opacity: 0.85 }}
                />
              )}
              <span className="relative drop-shadow-[0_2px_4px_rgba(0,0,0,0.7)] font-extrabold">{loading ? `⏳ Menyiapkan lautan… ${Math.round(loadPct * 100)}%` : "▶ MAIN SEKARANG!"}</span>
            </button>

            {/* Compact Speed Adjustment Slider + Presets */}
            <div className="w-full bg-[#241307]/80 border border-[#6e3f18] rounded-xl px-3 py-2 flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-[12px] font-bold text-amber-100">
                <span>⚡ Kecepatan Ikan</span>
                <span className="px-2 py-0.5 rounded-full bg-[#3f220c] border border-[#a86a2e] text-yellow-300 font-extrabold">
                  {save.speedPref.toFixed(1)}x
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={0.7}
                  max={1.8}
                  step={0.1}
                  value={save.speedPref}
                  onChange={(e) => setSave({ ...save, speedPref: parseFloat(e.target.value) })}
                  className="flex-1 accent-amber-400 cursor-pointer h-1.5"
                />
                <div className="flex gap-1">
                  {[
                    { label: "0.8x", val: 0.8 },
                    { label: "1.0x", val: 1.0 },
                    { label: "1.3x", val: 1.3 },
                    { label: "1.6x", val: 1.6 },
                  ].map((p) => (
                    <button
                      key={p.val}
                      onClick={() => setSave({ ...save, speedPref: p.val })}
                      className={`px-1.5 py-0.5 rounded text-[10.5px] font-bold cursor-pointer transition-colors ${
                        Math.abs(save.speedPref - p.val) < 0.05
                          ? "bg-amber-400 text-[#281204]"
                          : "bg-[#3d210d] text-amber-100/80 hover:bg-[#573014]"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="text-[12.5px] leading-relaxed text-amber-50 text-center font-medium bg-[#2b1708]/65 rounded-xl px-3 py-2 w-full border border-[#593418]">
              🖱️ Gerak ikan super mulus, lembut &amp; responsif mengikuti kursor!
              <br />
              <span className="text-yellow-300 font-bold">KLIK KIRI / SPASI</span> = <b>SEDOT</b> 🌀 •{" "}
              <span className="text-orange-300 font-bold">KLIK KANAN / SHIFT</span> = <b>BOOST</b> ⚡
              <br />
              Makan beruntun menyalakan papan <span className="text-yellow-200 font-bold">FRENZY!</span>
            </div>
            {save.best > 0 && (
              <div className="text-[14px] font-bold text-yellow-200 text-outline">
                🏆 Skor Rekor: {save.best.toLocaleString("en-US")}
              </div>
            )}
          </div>

          {/* Right: Feeding Frenzy Cast Skins & Upgrades */}
          <div className="artistic-wood-board relative p-4 sm:p-5 flex-[1.48] flex flex-col gap-3 shadow-2xl">
            {/* Decorative Swaying Sea Fan Accent */}
            <svg viewBox="0 0 36 42" className="coral-sway-r pointer-events-none absolute -top-5 -right-3 w-8 h-9 drop-shadow-[0_3px_4px_rgba(0,0,0,0.5)]">
              <path d="M18,40 L18,22 M18,28 C12,24 9,17 11,10 M18,23 C25,19 28,12 25,6" fill="none" stroke="#ff7224" strokeWidth="4.5" strokeLinecap="round" />
              <path d="M18,40 L18,22 M18,28 C12,24 9,17 11,10 M18,23 C25,19 28,12 25,6" fill="none" stroke="#ffd25e" strokeWidth="1.6" strokeLinecap="round" />
            </svg>

            {/* Nautical Brass Screws in corners */}
            <div className="absolute top-2.5 left-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute top-2.5 right-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2.5 left-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>
            <div className="absolute bottom-2.5 right-2.5 w-3 h-3 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[7px] text-[#4d2808]">✕</div>

            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <button
                  onClick={() => setTab("skin")}
                  className="ui-btn px-4 py-1.5 text-[15px] text-white"
                  style={{ background: tab === "skin" ? "linear-gradient(180deg, #ff9938, #d95b12)" : "#4d2c14" }}
                >
                  🐠 IKAN FRENZY
                </button>
                <button
                  onClick={() => setTab("shop")}
                  className="ui-btn px-4 py-1.5 text-[15px] text-white"
                  style={{ background: tab === "shop" ? "linear-gradient(180deg, #ff9938, #d95b12)" : "#4d2c14" }}
                >
                  ⚡ UPGRADE
                </button>
              </div>
              <div className="ff-carved-slot px-3 py-1 flex items-center gap-1.5 text-[18px] font-bold text-yellow-200">
                <img src={coin} className="w-6 h-6" alt="" />
                {save.coins}
              </div>
            </div>

            {tab === "skin" ? (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-[370px] overflow-y-auto pr-1">
                <div className="col-span-full text-center text-[12px] font-bold text-emerald-200 text-outline -mb-0.5">
                  ✅ Semua {SKINS.length} ikan sudah terbuka — tinggal pilih &amp; main!
                </div>
                {SKINS.map((s) => {
                  const owned = true;
                  const sel = save.skin === s.id;
                  const afford = true;
                  return (
                    <button
                      key={s.id}
                      onClick={() => pickSkin(s.id)}
                      className={`ui-btn relative overflow-hidden px-2 py-1.5 flex flex-col items-center transition-transform duration-150 ${
                        sel ? "ui-sheen ring-2 ring-yellow-200/80" : "hover:-translate-y-0.5"
                      }`}
                      style={{
                        background: sel
                          ? "linear-gradient(180deg, #ffe359, #eb9f12)"
                          : owned
                            ? "linear-gradient(180deg, #5c371b, #3d220e)"
                            : "#2b180a",
                        opacity: owned || afford ? 1 : 0.7,
                      }}
                    >
                      {skinImgs[s.id] ? <img src={skinImgs[s.id]} className="h-12 object-contain drop-shadow" alt={s.name} /> : <div className="h-12" />}
                      <div className={`text-[13px] font-bold leading-tight ${sel ? "text-[#2b1504]" : "text-amber-50"}`}>{s.name}</div>
                      <div className={`text-[10px] leading-tight ${sel ? "text-[#4d2808]" : "text-amber-200/80"}`}>{s.subtitle}</div>
                      <div className={`text-[11px] font-bold mt-0.5 ${sel ? "text-[#3b1e00]" : "text-yellow-300"}`}>
                        {sel ? "✓ DIPAKAI" : owned ? "PAKAI" : `🪙 ${s.price}`}
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {UPGRADES.map((u) => {
                  const lv = save.upgrades[u.id];
                  const max = lv >= MAX_UPGRADE;
                  const cost = max ? 0 : UPGRADE_COSTS[lv];
                  return (
                    <div key={u.id} className="flex items-center gap-3 bg-[#2b180a]/85 border-2 border-[#5c3618] rounded-xl p-3">
                      <div className="text-[28px]">{u.icon}</div>
                      <div className="flex-1">
                        <div className="text-[15px] font-bold text-amber-50">{u.name}</div>
                        <div className="text-[12px] text-amber-200/85">{u.desc}</div>
                        <div className="flex gap-1.5 mt-1.5">
                          {Array.from({ length: MAX_UPGRADE }).map((_, i) => (
                            <div
                              key={i}
                              className="w-6 h-3 rounded-sm border border-[#1a0d04]"
                              style={{ background: i < lv ? "#eff52c" : "#422712" }}
                            />
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() => buyUp(u.id)}
                        disabled={max || save.coins < cost}
                        className="ui-btn px-4 py-2 text-[14px] text-white disabled:opacity-50"
                        style={{ background: max ? "#5c534a" : "linear-gradient(180deg, #ff9938, #d95b12)" }}
                      >
                        {max ? "MAX" : `🪙 ${cost}`}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
