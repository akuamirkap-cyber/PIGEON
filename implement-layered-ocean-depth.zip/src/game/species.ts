export interface Palette {
  body: string;
  dark: string;
  belly: string;
  fin: string;
  tail?: string;
  outline: string;
  iris?: string;
  stripe?: string;
  spot?: string;
  lure?: string;
}

export type BodyStyle =
  | "andy"
  | "clown"
  | "minnow"
  | "boris"
  | "layla"
  | "pierre"
  | "leon"
  | "peter"
  | "eddy"
  | "orca"
  | "barracuda"
  | "shark"
  | "leopard"
  | "puffer"
  | "tang"
  | "idol"
  | "sailfish"
  | "parrot";

export interface Species {
  id: string;
  name: string;
  style: BodyStyle;
  hRatio: number; // body height / body length
  eye: number; // eye size relative to body half-height
  blush: boolean;
  angry: boolean;
  teeth: boolean;
  underbite?: boolean;
  lure?: boolean;
  spinyCrest?: boolean;
  stripes: number[];
  spots: boolean;
  deepPref?: "upper" | "any" | "deep"; // preferred ocean depth zone
  pal: Palette;
  minR: number;
  maxR: number;
  speed: number;
  predator: boolean;
  weight: number;
}

const base = {
  blush: false,
  angry: false,
  teeth: false,
  stripes: [] as number[],
  spots: false,
  predator: false,
  deepPref: "any" as "upper" | "any" | "deep",
};

// Food-chain species across both Sunlit Reef & Deep Bioluminescent Cavern
export const SPECIES: Species[] = [
  {
    ...base,
    id: "minnow",
    name: "Hiromi Teri",
    style: "minnow",
    hRatio: 0.44,
    eye: 0.34,
    deepPref: "any",
    pal: {
      body: "#6be8ce",
      dark: "#259c96",
      belly: "#eafff8",
      fin: "#9cf5e8",
      outline: "#13474d",
      iris: "#1e56a0",
      spot: "#18646e",
    },
    spots: true,
    minR: 3.2,
    maxR: 4.8,
    speed: 70,
    weight: 34,
  },
  {
    ...base,
    id: "boris_npc",
    name: "Boris",
    style: "boris",
    hRatio: 0.88,
    eye: 0.28,
    deepPref: "upper",
    pal: {
      body: "#bce8f7",
      dark: "#5b9bd5",
      belly: "#e8faff",
      fin: "#c9e218",
      tail: "#d8db22",
      outline: "#13214a",
      iris: "#1b3a7a",
      stripe: "#2e52b2",
      spot: "#16245c",
    },
    minR: 4.8,
    maxR: 6.6,
    speed: 63,
    weight: 22,
  },
  {
    ...base,
    id: "andy_npc",
    name: "Andy",
    style: "andy",
    hRatio: 0.94,
    eye: 0.28,
    deepPref: "any",
    pal: {
      body: "#ff8c14",
      dark: "#b83c06",
      belly: "#ffb82e",
      fin: "#e8640c",
      tail: "#fff8dc",
      outline: "#591d04",
      iris: "#2b1608",
      stripe: "#df22ff",
    },
    minR: 6.3,
    maxR: 8.8,
    speed: 62,
    weight: 18,
  },
  {
    ...base,
    id: "layla_npc",
    name: "Layla",
    style: "layla",
    hRatio: 0.74,
    eye: 0.25,
    deepPref: "upper",
    pal: {
      body: "#ffd238",
      dark: "#e67c18",
      belly: "#c8dce8",
      fin: "#78d2e8",
      tail: "#22b858",
      outline: "#2b3848",
      iris: "#1a5276",
      stripe: "#326480",
      spot: "#4e6e84",
    },
    minR: 9.6,
    maxR: 12.8,
    speed: 58,
    weight: 13,
  },
  {
    ...base,
    id: "pierre_npc",
    name: "Pierre",
    style: "pierre",
    hRatio: 0.6,
    eye: 0.3,
    spots: true,
    deepPref: "any",
    pal: {
      body: "#4476ff",
      dark: "#1d3fb3",
      belly: "#9ec2ff",
      fin: "#5992ff",
      outline: "#142563",
      iris: "#d9920f",
      spot: "#f5fbff",
    },
    minR: 13.6,
    maxR: 17.5,
    speed: 56,
    weight: 10,
  },
  {
    ...base,
    id: "leon_npc",
    name: "Leon Lepu",
    style: "leon",
    hRatio: 0.66,
    eye: 0.29,
    spinyCrest: true,
    deepPref: "any",
    stripes: [],
    pal: {
      body: "#c9a614",
      dark: "#6d5806",
      belly: "#dfe6a8",
      fin: "#b8d0a8",
      tail: "#d8e2c4",
      outline: "#282206",
      iris: "#987408",
      stripe: "#f5f4c8",
      spot: "#3c4828",
    },
    minR: 18.0,
    maxR: 23.0,
    speed: 52,
    weight: 7,
  },
  {
    ...base,
    id: "eddy_npc",
    name: "Eddy Lentera",
    style: "eddy",
    hRatio: 0.86,
    eye: 0.27,
    lure: true,
    underbite: true,
    predator: true,
    deepPref: "deep",
    pal: {
      body: "#56962a",
      dark: "#22460c",
      belly: "#8ecb56",
      fin: "#528a24",
      tail: "#4a7c22",
      outline: "#112806",
      iris: "#44aa22",
      lure: "#38ff14",
    },
    minR: 23.5,
    maxR: 29.5,
    speed: 55,
    weight: 6,
  },
  {
    ...base,
    id: "barracuda",
    name: "Robert",
    style: "barracuda",
    hRatio: 0.32,
    eye: 0.32,
    angry: true,
    teeth: true,
    predator: true,
    deepPref: "any",
    pal: {
      body: "#9cd1d9",
      dark: "#4d8291",
      belly: "#f2fcff",
      fin: "#84bdb2",
      outline: "#1b3d4a",
      iris: "#d49b1a",
      stripe: "#2d5563",
      spot: "#1b3540",
    },
    spots: true,
    minR: 30.0,
    maxR: 38.0,
    speed: 62,
    weight: 4,
  },
  {
    ...base,
    id: "orca_npc",
    name: "Goliath Orca",
    style: "orca",
    hRatio: 0.52,
    eye: 0.27,
    teeth: true,
    predator: true,
    deepPref: "any",
    pal: {
      body: "#232a38",
      dark: "#0d111a",
      belly: "#ffffff",
      fin: "#181e29",
      outline: "#090d17",
      iris: "#2b6cb0",
      spot: "#ffffff",
    },
    minR: 39.0,
    maxR: 50.0,
    speed: 65,
    weight: 2,
  },
];

// Tiny schooling fish: the snack schools you vacuum up for combos & coins.
// They are NOT part of the growth ladder (SPECIES), so levels and the food chain stay unchanged.
export const FRY: Species[] = [
  {
    ...base,
    id: "fry_sarden",
    name: "Sarden",
    style: "minnow",
    hRatio: 0.42,
    eye: 0.36,
    deepPref: "upper",
    pal: { body: "#7fc8f0", dark: "#2a6fb8", belly: "#f4fbff", fin: "#bfe8ff", outline: "#173b6b", iris: "#17325c" },
    minR: 2.7,
    maxR: 3.3,
    speed: 62,
    weight: 0,
  },
  {
    ...base,
    id: "fry_ekorkuning",
    name: "Ekor Kuning",
    style: "minnow",
    hRatio: 0.46,
    eye: 0.34,
    deepPref: "any",
    pal: { body: "#4aa8ff", dark: "#1f5fd0", belly: "#e8f6ff", fin: "#ffe04a", tail: "#ffd21f", outline: "#142c66", iris: "#1a2a50", stripe: "#ffe04a" },
    minR: 2.8,
    maxR: 3.4,
    speed: 60,
    weight: 0,
  },
  {
    ...base,
    id: "fry_lentera",
    name: "Ikan Lentera",
    style: "minnow",
    hRatio: 0.44,
    eye: 0.4,
    deepPref: "deep",
    pal: { body: "#3a3f9a", dark: "#17194f", belly: "#8a9cf0", fin: "#6fe8ff", tail: "#6fe8ff", outline: "#0a0b2c", iris: "#0e1238", stripe: "#7ff4ff", lure: "#6ff0ff" },
    minR: 2.7,
    maxR: 3.3,
    speed: 56,
    weight: 0,
  },
];

// Default Hero: Exact Image 1 Andy Angelfish shape, pointed snout & 3D oval eye!
export const HERO: Species = {
  ...base,
  id: "hero",
  name: "Andy",
  style: "andy",
  hRatio: 0.94,
  eye: 0.29,
  pal: {
    body: "#ff8c14",
    dark: "#b83c06",
    belly: "#ffb82e",
    fin: "#e8640c",
    tail: "#fff8dc",
    outline: "#591d04",
    iris: "#2b1608",
    stripe: "#df22ff",
  },
  minR: 7,
  maxR: 100,
  speed: 100,
  weight: 0,
};

export interface Skin {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  style: BodyStyle;
  hRatio: number;
  pal: Palette;
  stripes?: number[];
  spots?: boolean;
  spinyCrest?: boolean;
  lure?: boolean;
  underbite?: boolean;
  teeth?: boolean;
  eye?: number;
}

export const SKINS: Skin[] = [
  {
    id: "andy",
    name: "Andy",
    subtitle: "Angelfish Klasik",
    price: 0,
    style: "andy",
    hRatio: 0.94,
    pal: HERO.pal,
  },
  {
    id: "andy_blue",
    name: "Ryan",
    subtitle: "Angelfish Biru",
    price: 0,
    style: "andy",
    hRatio: 0.94,
    pal: {
      body: "#1fa2ff",
      dark: "#0e47a1",
      belly: "#66e0ff",
      fin: "#1677d9",
      tail: "#e0fbff",
      outline: "#092559",
      iris: "#122240",
      stripe: "#1ef5d8",
    },
  },
  {
    id: "orange",
    name: "Si Oren",
    subtitle: "Clownfish Badut",
    price: 0,
    style: "clown",
    hRatio: 0.72,
    eye: 0.28,
    pal: {
      body: "#ff7e14",
      dark: "#c44406",
      belly: "#ffa834",
      fin: "#ff8c1a",
      tail: "#ff8c1a",
      outline: "#180b04",
      iris: "#241409",
      stripe: "#ffffff",
    },
    stripes: [],
  },
  {
    id: "boris",
    name: "Boris",
    subtitle: "Butterfly FF2",
    price: 0,
    style: "boris",
    hRatio: 0.88,
    eye: 0.28,
    pal: {
      body: "#bce8f7",
      dark: "#5b9bd5",
      belly: "#e8faff",
      fin: "#c9e218",
      tail: "#d8db22",
      outline: "#13214a",
      iris: "#1b3a7a",
      stripe: "#2e52b2",
      spot: "#16245c",
    },
  },
  {
    id: "layla",
    name: "Layla",
    subtitle: "Queen Trigger",
    price: 0,
    style: "layla",
    hRatio: 0.72,
    eye: 0.24,
    pal: {
      body: "#ffd43a",
      dark: "#e67a16",
      belly: "#c8dce8",
      fin: "#86d8ea",
      tail: "#22b858",
      outline: "#2a3c4e",
      iris: "#1a5276",
      stripe: "#326480",
      spot: "#4e6e84",
    },
  },
  {
    id: "pierre",
    name: "Pierre",
    subtitle: "Kerapu Bintik",
    price: 0,
    style: "pierre",
    hRatio: 0.6,
    spots: true,
    pal: {
      body: "#4476ff",
      dark: "#1d3fb3",
      belly: "#9ec2ff",
      fin: "#5992ff",
      outline: "#142563",
      iris: "#d9920f",
      spot: "#f5fbff",
    },
  },
  {
    id: "leon",
    name: "Leon",
    subtitle: "Lionfish Kipas",
    price: 0,
    style: "leon",
    hRatio: 0.66,
    eye: 0.29,
    spinyCrest: true,
    stripes: [],
    pal: {
      body: "#c9a614",
      dark: "#6d5806",
      belly: "#dfe6a8",
      fin: "#b8d0a8",
      tail: "#d8e2c4",
      outline: "#282206",
      iris: "#987408",
      stripe: "#f5f4c8",
      spot: "#3c4828",
    },
  },
  {
    id: "peter",
    name: "Peter",
    subtitle: "John Dory FF2",
    price: 0,
    style: "peter",
    hRatio: 0.84,
    eye: 0.27,
    spinyCrest: true,
    pal: {
      body: "#28863c",
      dark: "#0f421a",
      belly: "#4ca850",
      fin: "#6ea862",
      tail: "#688c66",
      outline: "#0b2410",
      iris: "#a8c828",
      stripe: "#ffe61c",
      spot: "#101a10",
    },
  },
  {
    id: "eddy",
    name: "Eddy",
    subtitle: "Angler Laut Dalam",
    price: 0,
    style: "eddy",
    hRatio: 0.86,
    eye: 0.27,
    lure: true,
    underbite: true,
    pal: {
      body: "#56962a",
      dark: "#22460c",
      belly: "#8ecb56",
      fin: "#528a24",
      tail: "#4a7c22",
      outline: "#112806",
      iris: "#44aa22",
      lure: "#38ff14",
    },
  },
  {
    id: "orca",
    name: "Goliath",
    subtitle: "Orca Raja Laut",
    price: 0,
    style: "orca",
    hRatio: 0.54,
    teeth: true,
    pal: {
      body: "#232a38",
      dark: "#0d111a",
      belly: "#ffffff",
      fin: "#181e29",
      outline: "#090d17",
      iris: "#2b6cb0",
      spot: "#ffffff",
    },
  },
  // ---------------- five new playable species ----------------
  {
    id: "hiu",
    name: "Bruce",
    subtitle: "Hiu Putih",
    price: 0,
    style: "shark",
    hRatio: 0.48,
    teeth: true,
    eye: 0.3,
    pal: { body: "#5d7186", dark: "#364657", belly: "#ffffff", fin: "#52667a", tail: "#485a6e", outline: "#18222e", iris: "#111822" },
  },
  {
    id: "hiu_totol",
    name: "Toto",
    subtitle: "Hiu Totol",
    price: 0,
    style: "leopard",
    hRatio: 0.38,
    teeth: true,
    eye: 0.34,
    pal: { body: "#f0d47c", dark: "#a88034", belly: "#fff7dc", fin: "#d6b87a", tail: "#d8be88", outline: "#3b2310", iris: "#1b3446", spot: "#4d2311" },
  },
  {
    id: "buntal",
    name: "Bubu",
    subtitle: "Buntal Duri",
    price: 0,
    style: "puffer",
    hRatio: 0.9,
    eye: 0.33,
    pal: { body: "#f2c24e", dark: "#b57d1e", belly: "#fff8e2", fin: "#ffd970", outline: "#4a2f0a", iris: "#1f4a6e", spot: "#6b4312" },
  },
  {
    id: "dori",
    name: "Dori",
    subtitle: "Blue Tang",
    price: 0,
    style: "tang",
    hRatio: 0.66,
    eye: 0.3,
    pal: { body: "#2274ff", dark: "#0e36a8", belly: "#5aa4ff", fin: "#1b52dc", tail: "#ffd91f", outline: "#07174a", iris: "#141c30", stripe: "#0b1026", spot: "#ffd91f" },
  },
  {
    id: "idol",
    name: "Gill",
    subtitle: "Moorish Idol",
    price: 0,
    style: "idol",
    hRatio: 1.44,
    eye: 0.19,
    pal: { body: "#fffcf2", dark: "#dbd2b6", belly: "#ffffff", fin: "#fff9e2", tail: "#1d0c28", outline: "#0c0412", iris: "#7a2c24", stripe: "#1b0b26", spot: "#f2b838" },
  },
  {
    id: "layaran",
    name: "Kilat",
    subtitle: "Ikan Layaran",
    price: 0,
    style: "sailfish",
    hRatio: 0.36,
    eye: 0.3,
    pal: { body: "#2e63c9", dark: "#122a66", belly: "#eef6ff", fin: "#3d4fd0", tail: "#22428f", outline: "#0a1436", iris: "#121a2c", stripe: "#a6d4ff", spot: "#0c1a4c" },
  },
  {
    id: "kakatua",
    name: "Raja",
    subtitle: "Ikan Kakatua",
    price: 0,
    style: "parrot",
    hRatio: 0.68,
    eye: 0.23,
    pal: { body: "#12b84a", dark: "#06662c", belly: "#3ae276", fin: "#18a8d8", tail: "#1ab8c8", outline: "#04261c", iris: "#143850", stripe: "#0098d8", spot: "#06562a" },
  },
];

export function skinToSpecies(skin: Skin): Species {
  return {
    ...HERO,
    id: "skin-" + skin.id,
    name: skin.name,
    style: skin.style,
    hRatio: skin.hRatio,
    pal: skin.pal,
    stripes: skin.stripes ?? [],
    spots: !!skin.spots,
    spinyCrest: !!skin.spinyCrest,
    lure: !!skin.lure,
    underbite: !!skin.underbite,
    teeth: !!skin.teeth,
    eye: skin.eye ?? (skin.style === "orca" ? 0.26 : skin.style === "andy" || skin.style === "boris" ? 0.29 : 0.31),
  };
}

export const BOT_NAMES = [
  "Boris_FF",
  "Andy_Gacor",
  "RyanBiru",
  "LaylaQueen",
  "LeonSpiky",
  "EddyLampu",
  "PeterDory",
  "PierreBiru",
  "OrcaImut",
  "IkanLele",
  "Nemo_KW",
  "BudiGacor",
  "Mujair",
  "ProPlayer",
  "Bandeng",
  "KakapMerah",
  "Gurame",
  "Patin_OP",
  "TuyulLaut",
  "Sultan_Ikan",
  "HiuBocil",
  "BuntalSakti",
  "DoriLupa",
  "GillNgegas",
  "LayaranKilat",
  "CupangGalak",
  "TongkolSad",
  "BawalPutih",
  "TeriMedan",
  "CakalangGG",
  "TenggiriPro",
  "KerapuMacan",
  "BaronangID",
  "Kembung99",
  "NilaKesayangan",
  "SiDugong",
  "PausGabut",
  "RajaLaut",
  "RatuKarang",
  "JuraganKoin",
  "SedotSultan",
  "MabarYuk",
  "NoobMaster",
  "AnakPantai",
  "BangNelayan",
  "MbakPari",
  "CumiHitam",
  "UdangRebus",
  "KepitingAsoy",
  "GuritaSantuy",
];
