import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent } from 'react';
import { Download, Layers, Play, Plus, Save, Trash2, Upload, X, ZoomIn, ZoomOut } from 'lucide-react';
import { TILE, type Palette } from './game/constants';
import {
  OFFICE_PRESETS, OFFICE_THEMES, OT_AIR, OT_ELEV, OT_FLOOR, OT_GLASS, OT_STAIRS, OT_WALL,
  buildOfficeCanvas, buildOfficeLevel, cloneOfficeMap, createBlankOfficeMap,
  deleteCustomOfficeMap, getOfficeMapById, listAllOfficeMaps, saveCustomOfficeMap,
  setSelectedOfficeMapId, type OfficeDecorKind, type OfficeMapData, type OfficePropSpawn,
  type OfficeThemeId,
} from './game/office';

type ToolId =
  | 'erase'
  | 'floor'
  | 'wall'
  | 'stairs'
  | 'glass'
  | 'elev'
  | 'spawn'
  | 'leftGate'
  | 'rightGate'
  | 'prop_table'
  | 'prop_pot'
  | 'prop_computer'
  | 'prop_crate'
  | 'prop_barrel'
  | 'decor_window'
  | 'decor_light'
  | 'decor_cabinet'
  | 'decor_server'
  | 'decor_whiteboard'
  | 'decor_reception'
  | 'decor_cubicle'
  | 'decor_vending'
  | 'decor_sofa'
  | 'decor_bookshelf'
  | 'decor_pantry'
  | 'decor_copier'
  | 'decor_chandelier'
  | 'decor_vent';

interface ToolDef {
  id: ToolId;
  label: string;
  hint: string;
  group: 'STRUKTUR' | 'SPAWN' | 'OBJEK' | 'DEKOR';
  badgeCol: string;
}

const TOOLS: ToolDef[] = [
  { id: 'floor', label: 'LANTAI', hint: 'Lantai 1-arah / mezanin (lompat naik, S+Space turun)', group: 'STRUKTUR', badgeCol: '#566482' },
  { id: 'wall', label: 'DINDING', hint: 'Tembok beton / pilar kokoh', group: 'STRUKTUR', badgeCol: '#49587a' },
  { id: 'stairs', label: 'TANGGA', hint: 'Tangga naik/turun antar lantai', group: 'STRUKTUR', badgeCol: '#c48d48' },
  { id: 'glass', label: 'KACA', hint: 'Partisi kaca kantor (pecah saat dihantam!)', group: 'STRUKTUR', badgeCol: '#7ce8ff' },
  { id: 'elev', label: 'LIFT', hint: 'Pad lift (W / Space meluncur cepat ke atas)', group: 'STRUKTUR', badgeCol: '#46e2ff' },
  { id: 'erase', label: 'HAPUS', hint: 'Kosongkan sel / hapus dekor & pintu', group: 'STRUKTUR', badgeCol: '#ff4d4d' },

  { id: 'spawn', label: 'PEMAIN', hint: 'Titik mulai stickman kamu', group: 'SPAWN', badgeCol: '#57e6ff' },
  { id: 'leftGate', label: 'PINTU KIRI', hint: 'Pintu gelombang musuh dari sisi KIRI', group: 'SPAWN', badgeCol: '#ff5a36' },
  { id: 'rightGate', label: 'PINTU KANAN', hint: 'Pintu gelombang musuh dari sisi KANAN', group: 'SPAWN', badgeCol: '#ff9f43' },

  { id: 'prop_table', label: 'MEJA', hint: 'Meja kantor (bisa dipijak & dihancurkan)', group: 'OBJEK', badgeCol: '#8a5a2b' },
  { id: 'prop_pot', label: 'POT (1 TGN)', hint: 'Pot tanaman kantor (lempar 1 tangan cepat & pecah keramik!)', group: 'OBJEK', badgeCol: '#c66b3d' },
  { id: 'prop_computer', label: 'KOMPUTER (2 TGN)', hint: 'Set komputer kantor (angkat & lempar 2 tangan, meledak listrik!)', group: 'OBJEK', badgeCol: '#46e2ff' },
  { id: 'prop_crate', label: 'PETI', hint: 'Peti kayu arsip', group: 'OBJEK', badgeCol: '#a67642' },
  { id: 'prop_barrel', label: 'DISPENSER', hint: 'Tabung / drum peledak kantor', group: 'OBJEK', badgeCol: '#c0392b' },

  { id: 'decor_window', label: 'JENDELA', hint: 'Jendela kaca panorama kota', group: 'DEKOR', badgeCol: '#ffd86b' },
  { id: 'decor_light', label: 'LAMPU', hint: 'Lampu neon plafon', group: 'DEKOR', badgeCol: '#d6f0ff' },
  { id: 'decor_chandelier', label: 'KRISTAL', hint: 'Lampu gantung kristal lobi / direksi', group: 'DEKOR', badgeCol: '#ffe8b0' },
  { id: 'decor_reception', label: 'RESEPSIONIS', hint: 'Meja resepsionis lobi utama & monitor', group: 'DEKOR', badgeCol: '#46e2ff' },
  { id: 'decor_cubicle', label: 'KUBIKEL', hint: 'Meja kubikel kerja komputer & kursi', group: 'DEKOR', badgeCol: '#63f2c8' },
  { id: 'decor_pantry', label: 'PANTRI', hint: 'Bar pantri, mesin kopi espresso & kulkas', group: 'DEKOR', badgeCol: '#a0aec0' },
  { id: 'decor_vending', label: 'VENDING', hint: 'Mesin minuman & camilan otomatis menyala', group: 'DEKOR', badgeCol: '#ff4d6d' },
  { id: 'decor_copier', label: 'FOTOKOPI', hint: 'Mesin fotokopi & printer kantor besar', group: 'DEKOR', badgeCol: '#cbd5e0' },
  { id: 'decor_sofa', label: 'SOFA VIP', hint: 'Sofa kulit ruang tunggu & meja kopi kaca', group: 'DEKOR', badgeCol: '#ec4899' },
  { id: 'decor_bookshelf', label: 'RAK BUKU', hint: 'Lemari perpustakaan & arsip direksi', group: 'DEKOR', badgeCol: '#eab308' },
  { id: 'decor_cabinet', label: 'KABINET', hint: 'Lemari arsip kantor', group: 'DEKOR', badgeCol: '#53607a' },
  { id: 'decor_server', label: 'SERVER', hint: 'Rak mainframe server data menyala', group: 'DEKOR', badgeCol: '#39ff88' },
  { id: 'decor_whiteboard', label: 'PAPAN', hint: 'Papan tulis strategi rapat', group: 'DEKOR', badgeCol: '#dde5ed' },
  { id: 'decor_vent', label: 'VENTILASI', hint: 'Saluran pipa AC / ventilasi plafon', group: 'DEKOR', badgeCol: '#5c6e8c' },
];

function dummyPalette(themeId: OfficeThemeId): Palette {
  const th = OFFICE_THEMES[themeId] ?? OFFICE_THEMES.cyber_night;
  return {
    bg: th.skyTop,
    floor: th.roomBg,
    floorAlt: th.roomPanel,
    wall: th.wallShade,
    wallTop: th.wallFill,
    accent: th.accent,
    accent2: th.accent2,
  };
}

export function OfficeMapEditor({
  activeMapId,
  onClose,
  onPlayMap,
}: {
  activeMapId: string;
  onClose: () => void;
  onPlayMap: (mapId: string) => void;
}) {
  const [maps, setMaps] = useState<OfficeMapData[]>(() => listAllOfficeMaps());
  const [draft, setDraft] = useState<OfficeMapData>(() => getOfficeMapById(activeMapId));
  const [tool, setTool] = useState<ToolId>('floor');
  const [zoom, setZoom] = useState<number>(2);
  const [hover, setHover] = useState<{ tx: number; ty: number } | null>(null);
  const [status, setStatus] = useState<string>('');
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState('');

  const previewRef = useRef<HTMLCanvasElement>(null);
  const paintingRef = useRef<'paint' | 'erase' | null>(null);
  const lastCellRef = useRef<string>('');

  const flashStatus = useCallback((msg: string) => {
    setStatus(msg);
  }, []);

  useEffect(() => {
    if (!status) return;
    const id = window.setTimeout(() => setStatus(''), 2600);
    return () => window.clearTimeout(id);
  }, [status]);

  // Escape closes editor cleanly (unless import panel is open)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (showImport) setShowImport(false);
      else onClose();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose, showImport]);

  // Render live office canvas whenever draft or hover/zoom updates
  useEffect(() => {
    const cv = previewRef.current;
    if (!cv) return;
    const lv = buildOfficeLevel(draft);
    const officeCv = buildOfficeCanvas(lv, dummyPalette(draft.theme));
    cv.width = draft.w * TILE;
    cv.height = draft.h * TILE;
    const ctx = cv.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.drawImage(officeCv, 0, 0);

    // Subtle tile grid overlay
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 0; x <= draft.w; x++) {
      ctx.moveTo(x * TILE + 0.5, 0);
      ctx.lineTo(x * TILE + 0.5, cv.height);
    }
    for (let y = 0; y <= draft.h; y++) {
      ctx.moveTo(0, y * TILE + 0.5);
      ctx.lineTo(cv.width, y * TILE + 0.5);
    }
    ctx.stroke();

    // Draw interactive props markers
    for (const pr of draft.props) {
      const px = pr.tx * TILE + TILE / 2;
      const py = pr.ty * TILE;
      ctx.fillStyle = pr.kind === 'table' ? '#c79a5a' : pr.kind === 'pot' ? '#ff6b81' : pr.kind === 'computer' ? '#46e2ff' : pr.kind === 'crate' ? '#a67642' : '#e0533c';
      ctx.fillRect(px - 5, py - 8, 10, 8);
      ctx.strokeStyle = '#000';
      ctx.strokeRect(px - 5, py - 8, 10, 8);
    }

    // Draw Player Spawn Marker
    {
      const sx = draft.spawn.tx * TILE + TILE / 2;
      const sy = draft.spawn.ty * TILE;
      ctx.fillStyle = '#57e6ff';
      ctx.fillRect(sx - 3, sy - 14, 6, 14);
      ctx.strokeStyle = '#000';
      ctx.strokeRect(sx - 3, sy - 14, 6, 14);
      ctx.fillStyle = '#fff';
      ctx.fillRect(sx - 2, sy - 12, 4, 4);
    }

    // Hover highlight
    if (hover && hover.tx >= 0 && hover.ty >= 0 && hover.tx < draft.w && hover.ty < draft.h) {
      ctx.strokeStyle = '#ffd447';
      ctx.lineWidth = 1;
      ctx.strokeRect(hover.tx * TILE + 0.5, hover.ty * TILE + 0.5, TILE - 1, TILE - 1);
    }
  }, [draft, hover]);

  const applyToolAt = useCallback((tx: number, ty: number, activeTool: ToolId) => {
    if (tx < 0 || ty < 0 || tx >= draft.w || ty >= draft.h) return;
    const key = `${tx},${ty},${activeTool}`;
    if (lastCellRef.current === key) return;
    lastCellRef.current = key;

    setDraft((prev) => {
      const next = cloneOfficeMap(prev);
      const idx = ty * next.w + tx;
      const isBorder = tx === 0 || ty === 0 || tx === next.w - 1 || ty === next.h - 1;

      const clearExtrasAt = (x: number, y: number) => {
        next.props = next.props.filter((p) => !(p.tx === x && p.ty === y));
        next.leftGates = next.leftGates.filter((g) => !(g.tx === x && g.ty === y));
        next.rightGates = next.rightGates.filter((g) => !(g.tx === x && g.ty === y));
        next.decor = next.decor.filter((d) => !(Math.abs(d.tx - x) <= 1 && Math.abs(d.ty - y) <= 1));
      };

      switch (activeTool) {
        case 'erase':
          if (!isBorder) next.tiles[idx] = OT_AIR;
          clearExtrasAt(tx, ty);
          break;
        case 'floor':
          if (!isBorder) next.tiles[idx] = OT_FLOOR;
          break;
        case 'wall':
          next.tiles[idx] = OT_WALL;
          break;
        case 'stairs':
          if (!isBorder) next.tiles[idx] = OT_STAIRS;
          break;
        case 'glass':
          if (!isBorder) next.tiles[idx] = OT_GLASS;
          break;
        case 'elev':
          if (!isBorder) next.tiles[idx] = OT_ELEV;
          break;
        case 'spawn':
          next.spawn = { tx, ty };
          break;
        case 'leftGate': {
          const exists = next.leftGates.some((g) => g.tx === tx && g.ty === ty);
          next.leftGates = exists
            ? next.leftGates.filter((g) => !(g.tx === tx && g.ty === ty))
            : [...next.leftGates, { tx, ty }];
          break;
        }
        case 'rightGate': {
          const exists = next.rightGates.some((g) => g.tx === tx && g.ty === ty);
          next.rightGates = exists
            ? next.rightGates.filter((g) => !(g.tx === tx && g.ty === ty))
            : [...next.rightGates, { tx, ty }];
          break;
        }
        case 'prop_table':
        case 'prop_pot':
        case 'prop_computer':
        case 'prop_crate':
        case 'prop_barrel': {
          const kind = activeTool.replace('prop_', '') as OfficePropSpawn['kind'];
          next.props = [...next.props.filter((p) => !(p.tx === tx && p.ty === ty)), { tx, ty, kind }];
          break;
        }
        case 'decor_window':
        case 'decor_light':
        case 'decor_cabinet':
        case 'decor_server':
        case 'decor_whiteboard':
        case 'decor_reception':
        case 'decor_cubicle':
        case 'decor_vending':
        case 'decor_sofa':
        case 'decor_bookshelf':
        case 'decor_pantry':
        case 'decor_copier':
        case 'decor_chandelier':
        case 'decor_vent': {
          const kind = activeTool.replace('decor_', '') as OfficeDecorKind;
          const w =
            kind === 'window' || kind === 'reception' ? 5
            : kind === 'pantry' || kind === 'vent' ? 4
            : kind === 'light' || kind === 'cubicle' || kind === 'sofa' || kind === 'bookshelf' || kind === 'chandelier' ? 3
            : kind === 'copier' ? 2
            : 1;
          const h = kind === 'window' ? 2 : 1;
          const label = kind === 'reception' ? 'NAGA CORP' : undefined;
          next.decor = [
            ...next.decor.filter((d) => !(d.tx === tx && d.ty === ty)),
            { tx, ty, kind, w, h, label },
          ];
          break;
        }
      }
      return next;
    });
  }, [draft.w, draft.h]);

  const cellFromPointer = (e: PointerEvent<HTMLCanvasElement>) => {
    const cv = previewRef.current;
    if (!cv) return null;
    const rect = cv.getBoundingClientRect();
    const rx = (e.clientX - rect.left) / (rect.width || 1);
    const ry = (e.clientY - rect.top) / (rect.height || 1);
    const tx = Math.floor((rx * cv.width) / TILE);
    const ty = Math.floor((ry * cv.height) / TILE);
    return { tx, ty };
  };

  const handlePointerDown = (e: PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const mode = e.button === 2 ? 'erase' : 'paint';
    paintingRef.current = mode;
    lastCellRef.current = '';
    const cell = cellFromPointer(e);
    if (cell) {
      setHover(cell);
      applyToolAt(cell.tx, cell.ty, mode === 'erase' ? 'erase' : tool);
    }
  };

  const handlePointerMove = (e: PointerEvent<HTMLCanvasElement>) => {
    const cell = cellFromPointer(e);
    setHover(cell);
    if (!paintingRef.current || !cell) return;
    applyToolAt(cell.tx, cell.ty, paintingRef.current === 'erase' ? 'erase' : tool);
  };

  const handlePointerUp = () => {
    paintingRef.current = null;
    lastCellRef.current = '';
  };

  const handleSave = useCallback((asNew = false) => {
    const toSave = cloneOfficeMap(draft);
    if (asNew || toSave.id.startsWith('preset_')) {
      toSave.id = `custom_${Date.now()}`;
      if (asNew && !toSave.name.endsWith('COPY')) toSave.name = `${toSave.name} COPY`.slice(0, 26);
    }
    saveCustomOfficeMap(toSave);
    setSelectedOfficeMapId(toSave.id);
    setDraft(toSave);
    setMaps(listAllOfficeMaps());
    flashStatus(`TERSIMPAN: ${toSave.name}`);
  }, [draft, flashStatus]);

  const handlePlayNow = useCallback(() => {
    const toPlay = cloneOfficeMap(draft);
    if (toPlay.id.startsWith('preset_')) {
      // Ensure edits on preset are saved as custom if modified, or keep preset if untouched
      toPlay.id = `custom_${Date.now()}`;
      saveCustomOfficeMap(toPlay);
      setDraft(toPlay);
      setMaps(listAllOfficeMaps());
    } else {
      saveCustomOfficeMap(toPlay);
      setMaps(listAllOfficeMaps());
    }
    setSelectedOfficeMapId(toPlay.id);
    onPlayMap(toPlay.id);
  }, [draft, onPlayMap]);

  const handleNewBlank = (w: number, h: number) => {
    const blank = createBlankOfficeMap('KANTOR CUSTOM', w, h, draft.theme);
    setDraft(blank);
    setConfirmDelete(false);
    flashStatus(`BUAT KANVAS ${w}x${h}`);
  };

  const handleAddFloorBand = () => {
    // Utility: stamp an accessible mezzanine floor 5 tiles above ground/lowest empty spot
    setDraft((prev) => {
      const next = cloneOfficeMap(prev);
      const candidateYs = [next.h - 7, next.h - 12, next.h - 17, 6].filter((y) => y >= 4 && y < next.h - 3);
      // Find first row not already containing OT_FLOOR
      let targetY = candidateYs.find((y) => {
        let count = 0;
        for (let x = 3; x < next.w - 3; x++) if (next.tiles[y * next.w + x] === OT_FLOOR) count++;
        return count < 6;
      });
      if (targetY === undefined) targetY = Math.max(5, Math.floor(next.h / 2));
      for (let x = 2; x < next.w - 2; x++) {
        if ((x >= 10 && x <= 12) || (x >= next.w - 13 && x <= next.w - 11)) continue;
        next.tiles[targetY * next.w + x] = OT_FLOOR;
      }
      for (let y = targetY; y <= Math.min(next.h - 3, targetY + 4); y++) {
        next.tiles[y * next.w + 10] = OT_STAIRS;
        next.tiles[y * next.w + 11] = OT_STAIRS;
        next.tiles[y * next.w + 12] = OT_STAIRS;
        next.tiles[y * next.w + (next.w - 13)] = OT_STAIRS;
        next.tiles[y * next.w + (next.w - 12)] = OT_STAIRS;
        next.tiles[y * next.w + (next.w - 11)] = OT_STAIRS;
      }
      if (!next.leftGates.some((g) => g.ty === targetY)) next.leftGates.push({ tx: 3, ty: targetY });
      if (!next.rightGates.some((g) => g.ty === targetY)) next.rightGates.push({ tx: next.w - 4, ty: targetY });
      return next;
    });
    flashStatus('LANTAI + TANGGA + PINTU DITAMBAH!');
  };

  const handleDelete = () => {
    if (draft.id.startsWith('preset_')) {
      flashStatus('PRESET BAWAAN TIDAK BISA DIHAPUS');
      setConfirmDelete(false);
      return;
    }
    deleteCustomOfficeMap(draft.id);
    const updated = listAllOfficeMaps();
    setMaps(updated);
    const fallback = updated[0] ?? OFFICE_PRESETS[0];
    setDraft(cloneOfficeMap(fallback));
    setSelectedOfficeMapId(fallback.id);
    setConfirmDelete(false);
    flashStatus('MAP DIHAPUS');
  };

  const handleExport = async () => {
    const json = JSON.stringify(draft, null, 2);
    try {
      await navigator.clipboard.writeText(json);
      flashStatus('JSON DISALIN KE CLIPBOARD!');
    } catch {
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${draft.name.toLowerCase().replace(/[^a-z0-9]+/g, '_') || 'office_map'}.json`;
      a.click();
      URL.revokeObjectURL(url);
      flashStatus('FILE JSON DIUNDUH!');
    }
  };

  const handleImportSubmit = () => {
    try {
      const parsed = JSON.parse(importText) as OfficeMapData;
      if (!parsed || !Array.isArray(parsed.tiles) || typeof parsed.w !== 'number' || typeof parsed.h !== 'number') {
        flashStatus('FORMAT JSON TIDAK VALID');
        return;
      }
      const imported: OfficeMapData = {
        ...parsed,
        id: `custom_${Date.now()}`,
        name: String(parsed.name || 'IMPORTED OFFICE').slice(0, 26).toUpperCase(),
        theme: OFFICE_THEMES[parsed.theme] ? parsed.theme : 'cyber_night',
        decor: Array.isArray(parsed.decor) ? parsed.decor : [],
        props: Array.isArray(parsed.props) ? parsed.props : [],
        spawn: parsed.spawn ?? { tx: Math.floor(parsed.w / 2), ty: parsed.h - 2 },
        leftGates: Array.isArray(parsed.leftGates) ? parsed.leftGates : [{ tx: 3, ty: parsed.h - 2 }],
        rightGates: Array.isArray(parsed.rightGates) ? parsed.rightGates : [{ tx: parsed.w - 4, ty: parsed.h - 2 }],
      };
      saveCustomOfficeMap(imported);
      setSelectedOfficeMapId(imported.id);
      setDraft(imported);
      setMaps(listAllOfficeMaps());
      setShowImport(false);
      setImportText('');
      flashStatus(`IMPOR SUKSES: ${imported.name}`);
    } catch {
      flashStatus('GAGAL MEMBACA JSON');
    }
  };

  const activeToolDef = useMemo(() => TOOLS.find((t) => t.id === tool) ?? TOOLS[0], [tool]);
  const groups: ToolDef['group'][] = ['STRUKTUR', 'SPAWN', 'OBJEK', 'DEKOR'];

  return (
    <div
      className="absolute inset-0 z-[90] flex flex-col bg-[#080a10]/95 text-[#f7eee7] pixel"
      onContextMenu={(e) => e.preventDefault()}
      onPointerDown={(e) => e.stopPropagation()}
    >
      {/* Top Toolbar */}
      <header className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-[#2a3042] bg-[#0f121b] px-3 py-2">
        <div className="flex items-center gap-3">
          <span className="text-[11px] tracking-wider text-[#ff5a36]">DESAIN MAP KANTOR</span>
          <select
            aria-label="Pilih peta kantor"
            value={draft.id}
            onChange={(e) => {
              const found = maps.find((m) => m.id === e.target.value);
              if (found) {
                setDraft(cloneOfficeMap(found));
                setConfirmDelete(false);
              }
            }}
            className="border border-[#2a3042] bg-[#141826] px-2 py-1.5 text-[9px] text-[#fff2e4]"
          >
            {maps.map((m) => (
              <option key={m.id} value={m.id}>
                {m.id.startsWith('preset_') ? '[PRESET] ' : '[CUSTOM] '}
                {m.name} ({m.w}x{m.h})
              </option>
            ))}
          </select>
          <input
            type="text"
            aria-label="Nama peta kantor"
            value={draft.name}
            maxLength={24}
            onChange={(e) => setDraft((prev) => ({ ...prev, name: e.target.value.toUpperCase() }))}
            className="w-44 border border-[#2a3042] bg-[#141826] px-2 py-1.5 text-[9px] text-[#ffd447] uppercase outline-none focus:border-[#ff5a36]"
          />
          <select
            aria-label="Tema gedung kantor"
            value={draft.theme}
            onChange={(e) => setDraft((prev) => ({ ...prev, theme: e.target.value as OfficeThemeId }))}
            className="border border-[#2a3042] bg-[#141826] px-2 py-1.5 text-[9px] text-[#7ce8ff]"
          >
            {Object.values(OFFICE_THEMES).map((th) => (
              <option key={th.id} value={th.id}>
                TEMA: {th.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={handleAddFloorBand}
            title="Otomatis tambahkan 1 tingkat lantai + tangga + pintu kiri & kanan"
            className="flex items-center gap-1 border border-[#2a3042] bg-[#141826] px-2.5 py-1.5 text-[8px] text-[#c4cadb] hover:border-[#ffd447] hover:text-white cursor-pointer"
          >
            <Layers size={12} /> +1 LANTAI
          </button>
          <button
            type="button"
            onClick={() => handleNewBlank(68, 24)}
            title="Buat kanvas gedung kantor kosong"
            className="flex items-center gap-1 border border-[#2a3042] bg-[#141826] px-2.5 py-1.5 text-[8px] text-[#c4cadb] hover:border-[#ff5a36] hover:text-white cursor-pointer"
          >
            <Plus size={12} /> BARU
          </button>
          <button
            type="button"
            onClick={() => handleSave(false)}
            className="flex items-center gap-1 border border-[#2a3042] bg-[#141826] px-2.5 py-1.5 text-[8px] text-[#7bed9f] hover:border-[#7bed9f] cursor-pointer"
          >
            <Save size={12} /> SIMPAN
          </button>
          <button
            type="button"
            onClick={handleExport}
            title="Salin JSON peta ke clipboard"
            className="flex items-center gap-1 border border-[#2a3042] bg-[#141826] px-2 py-1.5 text-[8px] text-[#c4cadb] hover:border-[#7ce8ff] cursor-pointer"
          >
            <Download size={12} /> JSON
          </button>
          <button
            type="button"
            onClick={() => setShowImport((v) => !v)}
            title="Impor peta dari JSON"
            className="flex items-center gap-1 border border-[#2a3042] bg-[#141826] px-2 py-1.5 text-[8px] text-[#c4cadb] hover:border-[#7ce8ff] cursor-pointer"
          >
            <Upload size={12} /> IMPOR
          </button>
          {!draft.id.startsWith('preset_') && (
            confirmDelete ? (
              <button
                type="button"
                onClick={handleDelete}
                className="flex items-center gap-1 border border-[#ff3b3b] bg-[#ff3b3b] px-2 py-1.5 text-[8px] text-black cursor-pointer"
              >
                KONFIRMASI HAPUS
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="flex items-center gap-1 border border-[#2a3042] bg-[#141826] px-2 py-1.5 text-[8px] text-[#ff6b6b] hover:border-[#ff3b3b] cursor-pointer"
              >
                <Trash2 size={12} />
              </button>
            )
          )}
          <button
            type="button"
            onClick={handlePlayNow}
            className="flex items-center gap-1.5 border border-[#ff5a36] bg-[#ff5a36] px-3 py-1.5 text-[9px] text-[#150806] shadow-[2px_2px_0_#000] hover:bg-[#ff7455] cursor-pointer"
          >
            <Play size={12} /> MAIN MAP INI!
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup desain map"
            className="flex items-center gap-1 border border-[#6b4a3e] bg-[#10131d] px-2.5 py-1.5 text-[8px] text-[#fff2e4] hover:border-[#ff5a36] cursor-pointer"
          >
            <X size={13} /> KEMBALI
          </button>
        </div>
      </header>

      {/* Main Split Area: Left Tool Palette + Center Scrollable Blueprint Canvas */}
      <div className="flex min-h-0 flex-1 overflow-hidden">
        {/* Left Palette */}
        <aside className="flex w-56 shrink-0 flex-col gap-3 overflow-y-auto border-r-2 border-[#2a3042] bg-[#0d1019] p-2.5">
          {groups.map((grp) => (
            <div key={grp}>
              <div className="mb-1.5 text-[7px] tracking-widest text-[#7b86a3]">{grp}</div>
              <div className="grid grid-cols-2 gap-1.5">
                {TOOLS.filter((t) => t.group === grp).map((t) => {
                  const active = tool === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      title={t.hint}
                      aria-pressed={active}
                      onClick={() => setTool(t.id)}
                      className={`flex items-center gap-1.5 border px-2 py-2 text-left text-[7px] cursor-pointer transition-colors ${
                        active
                          ? 'border-[#ff5a36] bg-[#ff5a36] text-[#150806] shadow-[0_0_10px_rgba(255,90,54,0.4)]'
                          : 'border-[#2a3042] bg-[#131724] text-[#e9edf9] hover:border-[#7b86a3]'
                      }`}
                    >
                      <span
                        className="inline-block h-2.5 w-2.5 shrink-0 border border-black/60"
                        style={{ backgroundColor: t.badgeCol }}
                      />
                      <span className="truncate">{t.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          <div className="mt-1 border-t border-[#2a3042] pt-2.5">
            <div className="mb-1.5 text-[7px] tracking-widest text-[#7b86a3]">UKURAN KANVAS</div>
            <div className="grid grid-cols-3 gap-1">
              {([[56, 22], [70, 26], [84, 30]] as const).map(([rw, rh]) => (
                <button
                  key={`${rw}x${rh}`}
                  type="button"
                  onClick={() => handleNewBlank(rw, rh)}
                  className={`border py-1.5 text-[7px] cursor-pointer ${
                    draft.w === rw && draft.h === rh
                      ? 'border-[#ffd447] bg-[#1e2538] text-[#ffd447]'
                      : 'border-[#2a3042] bg-[#131724] text-[#c4cadb] hover:border-[#7b86a3]'
                  }`}
                >
                  {rw}x{rh}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-auto border border-[#2a3042] bg-[#111521] p-2 text-[7px] leading-[1.8] text-[#9aa6c6]">
            <div className="text-[#ffd447]">{activeToolDef.label}</div>
            <div>{activeToolDef.hint}</div>
            <div className="mt-1.5 text-[#7b86a3]">KLIK KIRI: PASANG · KLIK KANAN: HAPUS</div>
          </div>
        </aside>

        {/* Center Canvas Workspace */}
        <div className="relative flex flex-1 flex-col overflow-hidden bg-[#06080d]">
          <div className="flex items-center justify-between border-b border-[#1c2233] bg-[#0b0e16] px-3 py-1.5 text-[8px] text-[#9aa6c6]">
            <div className="flex items-center gap-3">
              <span>
                GRID: {hover ? `${hover.tx}, ${hover.ty}` : `${draft.w}x${draft.h}`}
              </span>
              <span>
                PINTU KIRI: <b className="text-[#ff5a36]">{draft.leftGates.length}</b> · PINTU KANAN:{' '}
                <b className="text-[#ff9f43]">{draft.rightGates.length}</b> · OBJEK:{' '}
                <b className="text-[#ffd447]">{draft.props.length}</b>
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              {status && <span className="mr-2 text-[#7bed9f]">{status}</span>}
              <button
                type="button"
                aria-label="Perkecil kanvas"
                onClick={() => setZoom((z) => Math.max(1, Number((z - 0.5).toFixed(1))))}
                className="border border-[#2a3042] bg-[#141826] p-1 text-[#e9edf9] hover:border-[#ff5a36] cursor-pointer"
              >
                <ZoomOut size={12} />
              </button>
              <span className="w-8 text-center text-[#ffd447]">{zoom}x</span>
              <button
                type="button"
                aria-label="Perbesar kanvas"
                onClick={() => setZoom((z) => Math.min(3, Number((z + 0.5).toFixed(1))))}
                className="border border-[#2a3042] bg-[#141826] p-1 text-[#e9edf9] hover:border-[#ff5a36] cursor-pointer"
              >
                <ZoomIn size={12} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-4">
            <div className="inline-block border-2 border-[#2a3042] bg-black shadow-[0_12px_36px_rgba(0,0,0,0.8)]">
              <canvas
                ref={previewRef}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
                onPointerLeave={() => {
                  setHover(null);
                  handlePointerUp();
                }}
                style={{
                  width: draft.w * TILE * zoom,
                  height: draft.h * TILE * zoom,
                  imageRendering: 'pixelated',
                  cursor: 'crosshair',
                  display: 'block',
                }}
              />
            </div>
          </div>

          {showImport && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/80 p-4">
              <div className="flex w-full max-w-lg flex-col gap-3 border-2 border-[#ff5a36] bg-[#131622] p-4 shadow-[6px_6px_0_#000]">
                <div className="flex items-center justify-between text-[10px] text-[#ffd447]">
                  <span>IMPOR JSON PETA KANTOR</span>
                  <button
                    type="button"
                    onClick={() => setShowImport(false)}
                    className="border border-[#6b4a3e] px-2 py-1 text-[8px] text-white cursor-pointer"
                  >
                    X
                  </button>
                </div>
                <textarea
                  rows={8}
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  placeholder="Tempel JSON peta kantor di sini..."
                  className="w-full border border-[#2a3042] bg-[#0a0c13] p-2 font-mono text-[11px] text-[#e9edf9] outline-none focus:border-[#ff5a36]"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowImport(false)}
                    className="border border-[#6b4a3e] px-3 py-1.5 text-[8px] text-[#c4cadb] cursor-pointer"
                  >
                    BATAL
                  </button>
                  <button
                    type="button"
                    onClick={handleImportSubmit}
                    className="border border-[#ff5a36] bg-[#ff5a36] px-3 py-1.5 text-[8px] text-[#150806] cursor-pointer"
                  >
                    MUAT PETA
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
