// MENARA KANTOR — mode SIDE VIEW. Stickman & jurus kungfu persis Kungfu Drifter (stick.ts + moves.ts),
// arena berubah jadi potongan gedung kantor bertingkat: musuh datang dari kiri & kanan tiap lantai.
import { drawStick, solvePose, gaitCadence, LEG_K, type StickOpts } from '../../v2/games/maxkungfu/game/stick';
import { MOVES, IPPO_PLANS, IPPO_HEAVY, type Move } from '../../v2/games/maxkungfu/game/moves';
import { Sfx } from '../maxkungfu/game/audio';
import type { SoundVersion } from '../maxkungfu/game/soundPacks';
import { Texts } from '../maxkungfu/game/particles';
import { pfontO, pcircle, pline, textWidth } from '../maxkungfu/game/pixel';
import type { Pose, Vec } from '../../v2/games/maxkungfu/game/types';
import { clamp, lerp, rnd, angleDiff, dist } from '../maxkungfu/game/rng';
import { T, STORY, STORY_PX, type OfficeMap, type Theme, storiesOf, themeOf, floorLabel, PROP_CHARS } from './map';
import { FX } from './fx';
import { WEAPONS, WEAPON_ORDER, BOX_STANCES, toWorld, drawWeaponIcon, type BoxStance, type GunSpec } from './arsenal';
import { Bridge } from './bridge';
import { EightGates } from '../maxkungfu/game/eightGates';
import { crescent, MAKO } from '../maxkungfu/game/buster';
import type { WeaponKind } from '../../v2/games/maxkungfu/game/types';
import { buildBuilding, drawProp, drawConnector, drawGlassTile, propHeight, storySpan, hh, drawWallDecor, type Lamp, type Win, type WallDecor } from './art';
import { ATMOS, ATMO_NAME, mixAtmo, buildSky2, drawSky2, css, Weather, type AtmoDef, type AtmoId, type Sky2 } from './atmo';
import { levelSpec, generateTower, LEVEL_COUNT, ATMO_CYCLE } from './gen';

export const VW = 480, VH = 270;
const BASE_ZOOM = 5 / 3;
const GRAV = 900, JUMP_V = 292, MAX_FALL = 640;
const WALK = 74, RUN = 128;
const BODY_H = 15, HALF_W = 3.5;
const IDLE_POSES = new Set<string>(['idle', 'run', 'n_idle', 'bx_float', 'bx_weave', 'bx_press']);
const MOVING_POSES = new Set<string>(['idle', 'run', 'bow', 'shoot', 'n_idle', 'y2_idle', 'k_idle', 'a_idle', 'd_idle', 'bx_float', 'bx_weave', 'bx_press']);
const BLADE_WEAPONS = new Set<string>(['katana', 'axe', 'dual', 'bat', 'buster', 'shotgun']);

type Kind = 'thug' | 'kicker' | 'knife' | 'guard' | 'gunner' | 'brute' | 'master' | 'shield' | 'monk' | 'bomber' | 'smg' | 'shotgunner';
interface KindDef { name: string; hp: number; speed: number; dmg: number; reach: number; windup: number; recover: number; color: string; color2: string; acc: string; weapon: string; scale: number; structure: number; poses: Pose[]; armor?: boolean; score: number }
const KINDS: Record<Kind, KindDef> = {
  thug: { name: 'PREMAN', hp: 14, speed: 56, dmg: 7, reach: 15, windup: 0.44, recover: 0.42, color: '#d9d9d9', color2: '#5a5a5a', acc: 'band', weapon: 'none', scale: 1, structure: 40, poses: ['jab', 'cross', 'hook'], score: 100 },
  kicker: { name: 'JAGOAN TENDANG', hp: 18, speed: 62, dmg: 9, reach: 21, windup: 0.5, recover: 0.46, color: '#8fd3ff', color2: '#1f4e6e', acc: 'headband', weapon: 'none', scale: 1, structure: 50, poses: ['sidekick', 'roundhouse', 'knee'], score: 140 },
  knife: { name: 'PISAU', hp: 12, speed: 80, dmg: 8, reach: 17, windup: 0.3, recover: 0.34, color: '#ffcf6b', color2: '#6b4a10', acc: 'mask', weapon: 'knife', scale: 1, structure: 36, poses: ['jab', 'cross'], score: 150 },
  guard: { name: 'SATPAM', hp: 24, speed: 50, dmg: 11, reach: 21, windup: 0.56, recover: 0.5, color: '#7fa8ff', color2: '#1b2c5a', acc: 'helmet', weapon: 'bat', scale: 1, structure: 60, poses: ['hammer', 'hook'], score: 170 },
  gunner: { name: 'PENEMBAK', hp: 14, speed: 52, dmg: 9, reach: 15, windup: 0.6, recover: 0.5, color: '#ff8f8f', color2: '#5a1010', acc: 'shades', weapon: 'pistol', scale: 1, structure: 40, poses: ['jab'], score: 180 },
  brute: { name: 'BADAK', hp: 70, speed: 40, dmg: 16, reach: 22, windup: 0.75, recover: 0.7, color: '#c48a5a', color2: '#4a2a10', acc: 'none', weapon: 'none', scale: 1.35, structure: 140, poses: ['hammer', 'palm'], armor: true, score: 500 },
  shield: { name: 'PERISAI', hp: 26, speed: 46, dmg: 10, reach: 16, windup: 0.5, recover: 0.5, color: '#9fb4c8', color2: '#2a3a4a', acc: 'helmet', weapon: 'shield', scale: 1.05, structure: 45, poses: ['palm', 'elbow'], score: 220 },
  monk: { name: 'BIKSU TONGKAT', hp: 20, speed: 64, dmg: 9, reach: 25, windup: 0.42, recover: 0.42, color: '#ffb347', color2: '#7a3d10', acc: 'none', weapon: 'staff', scale: 1, structure: 55, poses: ['spinback', 'sweep', 'hook'], score: 200 },
  bomber: { name: 'PELEMPAR BOM', hp: 14, speed: 50, dmg: 18, reach: 15, windup: 0.6, recover: 0.6, color: '#c8f08f', color2: '#3a5a10', acc: 'mask', weapon: 'bomb', scale: 1, structure: 40, poses: ['jab'], score: 220 },
  smg: { name: 'PENEMBAK SMG', hp: 16, speed: 54, dmg: 5, reach: 15, windup: 0.6, recover: 0.5, color: '#ff6b9a', color2: '#5a1030', acc: 'shades', weapon: 'smg', scale: 1, structure: 40, poses: ['jab'], score: 220 },
  shotgunner: { name: 'SHOTGUN', hp: 20, speed: 48, dmg: 5, reach: 15, windup: 0.7, recover: 0.6, color: '#e08a5a', color2: '#4a2010', acc: 'hood', weapon: 'shotgun', scale: 1.05, structure: 50, poses: ['palm'], score: 240 },
  master: { name: 'SANG MASTER', hp: 130, speed: 78, dmg: 11, reach: 19, windup: 0.3, recover: 0.34, color: '#ffd23c', color2: '#7a4a00', acc: 'headband', weapon: 'none', scale: 1.08, structure: 170, poses: ['jab', 'cross', 'hook', 'roundhouse', 'sidekick', 'spinback', 'uppercut'], score: 1500 },
};
const BOSS_NAMES = ['KEPALA KEAMANAN', 'MANAJER BESI', 'DIREKTUR BAYANGAN', 'CEO NAGA', 'SANG PEWARIS'];

type Zone = 'head' | 'torso' | 'legs';
interface React { zone: Zone; t: number; dur: number; dir: number; amp: number; side: number }
interface Body {
  id: number; x: number; y: number; vx: number; vy: number; facing: number; onGround: boolean; scale: number;
  hp: number; maxHp: number; flash: number; walk: number; stride: number; runK: number; rot: number; vrot: number;
  sqx: number; sqy: number; alpha: number; climbing: boolean; ladder: Ladder | null; dropT: number; react: React | null;
  /** blending pose: transisi antar pose disilang-halus, bukan patah */
  animPose: Pose; animT: number; prevPose: Pose; prevT: number; blend: number; blendDur: number; lastFacing: number; pivotT: number;
}
type EState = 'spawn' | 'idle' | 'windup' | 'attack' | 'recover' | 'hurt' | 'air' | 'down' | 'getup' | 'dizzy' | 'stagger' | 'aim' | 'block' | 'door' | 'climb' | 'charge' | 'dead' | 'clash' | 'held';
interface Atk { pose: Pose; dmg: number; reach: number; windup: number; active: number; recover: number; heavy: boolean; hit: boolean; launch: number; lunge: number }
interface Enemy extends Body {
  kind: Kind; def: KindDef; name: string; boss: boolean; elite: boolean;
  state: EState; stateT: number; poseT: number; atkCd: number; atk: Atk | null; chain: number;
  structure: number; dizzy: number; knock: boolean; dead: boolean; deadT: number; outside: boolean; token: boolean;
  spawnT: number; spawnMode: 'door' | 'drop'; doorTo: Conn | null; fall: Pose; juggle: number; blockCd: number; aimT: number; wallCd: number; hold: number; recoil: number;
  arrows?: { dx: number; dy: number; ang: number }[];
  col?: string; acc?: string; turnT?: number; burst?: number; jumpCd?: number; spurt?: number; pooled?: boolean; blockMsg?: number;
}
interface Player extends Body {
  chi: number; seq: string; moveKey: string | null; phase: 'none' | 'windup' | 'active' | 'recover'; phaseT: number;
  hitSet: Set<number>; hitTimes: Map<number, number>; comboTimer: number; buffer: string | null; bufferT: number; airSeq: string; airHits: number;
  dashT: number; dashCd: number; dashDir: number; airDash: boolean; parryT: number; parryCd: number; parryAnim: number; blocking: boolean; counterT: number;
  iframes: number; hurtT: number; downT: number; getupT: number; dead: boolean; runT: number; coyote: number; land: number; squash: number;
  door: { t: number; to: Conn; out: boolean } | null; afterT: number; stepIdx: number; brake: number; climbPh: number; fall: Pose;
  weapon: WeaponKind; move: Move | null; swingA: number; swingPrev: number; ammo: Record<string, number>; reloadT: number; fireCd: number;
  bowDraw: number; bowFull: boolean; recoil: number; aimRel: number; shootT: number; boxStance: BoxStance; iaiMarks: Enemy[]; iaiT: number;
  ofa: number; ofaOn: boolean; holdPose: Pose; holdT: number;
  kx: number; bladeA: number; bladeB: number; bladePrevA: number; sheatheT: number; arcDone: boolean; batTwirl: number; batTwirlCd: number; busterRest: number;
  grab: Enemy | null; grabT: number;
  // ---- KONTROL GAYA V2: arah bidik kursor, ritme freestyle, trik senjata
  aim: number; attackAim: number; bodyAim: number; mouseAim: boolean; sinceDash: number; tkdCd: number;
  rhythm: number[]; chainLast: number; style: 'none' | 'wingchun' | 'blackleg' | 'kungfu'; styleStreak: number; flowStep: number; chain: number; chainSide: number; wcCount: number;
  katanaPlan: number; bufferKey: string | null; gunIdle: number; twirlT: number; sgPhase: 'ready' | 'cock' | 'load'; sgT: number; sgBuf: boolean; buCharging: boolean; buHold: number; buCharge: number;
}
interface Conn { c: number; r: number; ch: 'S' | 'E'; x: number; yF: number; story: number; open: number; openT: number; up: Conn | null; down: Conn | null }
interface Ladder { c: number; x: number; topY: number; botY: number }
interface Prop { ch: string; x: number; yF: number; hp: number; broken: boolean; shake: number; seed: number; nl: boolean; nr: boolean; h: number; story: number }
interface Bullet { x: number; y: number; vx: number; vy: number; life: number; dmg: number; mine: boolean; kb: number; kind: 'bullet' | 'pellet' | 'arrow' | 'beam' | 'enemy'; hit?: Set<number>; power?: number }
interface SlashFx { x: number; y: number; r: number; a0: number; a1: number; life: number; max: number; c: string; w: number }
interface Slam { kind: 'lotus' | 'izuna'; e: Enemy; t: number; phase: number; dir: number; x0: number; c: string }
function ptSeg(q: Vec, a: Vec, b: Vec) { const dx = b.x - a.x, dy = b.y - a.y, l = dx * dx + dy * dy; const t = l ? clamp(((q.x - a.x) * dx + (q.y - a.y) * dy) / l, 0, 1) : 0; return Math.hypot(q.x - (a.x + dx * t), q.y - (a.y + dy * t)); }
function segSeg(a: Vec, b: Vec, c: Vec, d: Vec) {
  const cr = (o: Vec, u: Vec, v: Vec) => (u.x - o.x) * (v.y - o.y) - (u.y - o.y) * (v.x - o.x);
  const d1 = cr(c, d, a), d2 = cr(c, d, b), d3 = cr(a, b, c), d4 = cr(a, b, d);
  if ((d1 > 0) !== (d2 > 0) && (d3 > 0) !== (d4 > 0)) return 0;
  return Math.min(ptSeg(a, c, d), ptSeg(b, c, d), ptSeg(c, a, b), ptSeg(d, a, b));
}
interface Pickup { x: number; y: number; vy: number; kind: 'hp' | 'chi'; life: number }
interface Ghost { o: StickOpts; life: number; max: number }
interface SpawnPt { x: number; yF: number; story: number; conn: Conn | null }
interface Banner { text: string; sub: string; t: number; max: number; c: string }
interface Exec { e: Enemy; step: number; t: number; seq: { pose: Pose; dur: number; name: string }[]; hitDone: boolean }
interface Clash { e: Enemy; t: number; power: number; spark: number }
interface Special { t: number; phase: 'dash' | 'strike'; dir: number; hits: Enemy[]; done: number }

export interface OfficeUI { state: 'title' | 'playing' | 'paused' | 'over' | 'levelclear'; level: number; levelGoal: number; levelMax: number; atmo: AtmoId; atmoMode: 'auto' | AtmoId; wave: number; score: number; kills: number; bestCombo: number; floor: string; best: { score: number; wave: number }; muted: boolean; mapName: string; time: number; floorsClimbed: number; ally: boolean; ctrl: 'v2' | 'kbd' }

const KEYS = {
  left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'], up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'],
  jump: ['Space'], light: ['KeyJ', 'Mouse0'], heavy: ['KeyK', 'Mouse2'], dash: ['KeyL', 'ShiftLeft', 'ShiftRight'],
  parry: ['KeyC'], special: ['KeyR'], exec: ['KeyF', 'KeyE'], pause: ['Escape', 'KeyP'], mute: ['Comma'], ally: ['KeyM'],
  grab: ['KeyG'], cycle: ['KeyQ'], gates: ['KeyN'], ofa: ['KeyX'], weapons: WEAPON_ORDER.map((w) => WEAPONS[w].code),
};
const GAME_CODES = new Set(Object.values(KEYS).flat());
const BEST_KEY = 'office_best_v1';
const RANKS: [number, string, string][] = [[50, 'LEGENDA!', '#ff3bf2'], [35, 'SADIS!', '#ff3b3b'], [20, 'BRUTAL!', '#ff8a3d'], [10, 'KEREN!', '#ffd166'], [5, 'BAGUS!', '#7cff9a']];

const EXEC_SEQS: { pose: Pose; dur: number; name: string }[][] = [
  [{ pose: 'hook', dur: 0.3, name: 'HOOK' }, { pose: 'uppercut', dur: 0.36, name: 'DRAGON UPPERCUT' }, { pose: 'axekick', dur: 0.46, name: 'AXE KICK' }],
  [{ pose: 'elbow', dur: 0.28, name: 'ELBOW' }, { pose: 'knee', dur: 0.32, name: 'KNEE' }, { pose: 'dragontail', dur: 0.5, name: 'DRAGON TAIL' }],
  [{ pose: 'tigerclaw', dur: 0.3, name: 'TIGER CLAW' }, { pose: 'spinback', dur: 0.36, name: 'BACKFIST' }, { pose: 'cranekick', dur: 0.5, name: 'CRANE KICK' }],
];

const STRIKE_POSES = new Set<Pose>([...Object.values(MOVES).map((m) => m.pose), 'hammer', 'charge', 'shoot', 'punch', 'kick']);
/** durasi silang-halus antar pose (detik) */
function blendDur(from: Pose, to: Pose) {
  const fa = STRIKE_POSES.has(from), ta = STRIKE_POSES.has(to);
  if (to === 'hurt' || to === 'fly' || to === 'launched' || to === 'stagger') return 0.05;
  if (fa && ta) return 0.06;
  if (ta) return 0.05;
  if (fa) return 0.15;
  if (from === 'getup') return 0.18;
  if ((from === 'run' && to === 'idle') || (from === 'idle' && to === 'run')) return 0.2;
  if (from === 'jump' || to === 'jump') return 0.1;
  return 0.12;
}
function kOf(r: React) { const u = clamp(r.t / r.dur, 0, 1); return u < 0.14 ? u / 0.14 : Math.pow(1 - (u - 0.14) / 0.86, 1.5); }
function zoneOfMove(m: Move): Zone {
  if (m.limb === 'sweep' || m.id === 'sweep') return 'legs';
  if (['jab', 'cross', 'hook', 'dragon', 'spinback', 'roundhouse', 'cranekick', 'axekick', 'monkeyflip', 'dragontail'].includes(m.id)) return 'head';
  return 'torso';
}

interface Ally extends Body { phase: 'none' | 'windup' | 'active' | 'recover'; phaseT: number; move: Move | null; combo: string; step: number; hit: boolean; cd: number; tpT: number }
interface Civ extends Body { mode: 'idle' | 'flee' | 'down' | 'gone'; t: number; tie: string; acc: string; shirt: string; goal: Conn | null; saidT: number }
const BOSS_CYCLE: Kind[] = ['brute', 'master', 'shield', 'bomber'];
const BOSS_SUB: Partial<Record<Kind, string>> = { master: 'MASTER KUNGFU - HATI-HATI ADU PUKULAN!', brute: 'BADAK BAJA - TANGKIS SERUDUKANNYA!', shield: 'KOMANDAN PERISAI - SERANG DARI BELAKANG / BANTING!', bomber: 'PAKAR BOM - PUKUL BALIK BOMNYA!' };
const ALLY_COMBOS = ['LLLL', 'LLLH', 'LLH', 'LHL', 'HLL', 'HH', 'LLLLL', 'LH', 'HLH'];
function rgba(hex: string, a: number) { const n = parseInt(hex.slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }

export class OfficeGame {
  canvas: HTMLCanvasElement; ctx: CanvasRenderingContext2D;
  buf: HTMLCanvasElement; b: CanvasRenderingContext2D;
  sfx: Sfx; fx = new FX(); fxBack = new FX(); texts = new Texts();
  /** pengali kecepatan jurus pemain (1 = asli, <1 = lebih pelan, jelas & nyaman) */
  tempo = 0.75; private lastDt = 0; private K = 1;
  map!: OfficeMap; W = 0; H = 0; tiles: string[][] = []; stories = 1;
  building!: HTMLCanvasElement; decals!: HTMLCanvasElement; dctx!: CanvasRenderingContext2D; sky: Sky2;
  spans: [number, number][] = [];
  conns: Conn[] = []; ladders: Ladder[] = []; props: Prop[] = []; spawnPts: SpawnPt[] = []; glassCells: { c: number; r: number }[] = [];
  player!: Player; enemies: Enemy[] = []; bullets: Bullet[] = []; pickups: Pickup[] = []; ghosts: Ghost[] = [];
  cam = { x: 0, y: 0, zoom: BASE_ZOOM, tz: BASE_ZOOM, shake: 0, sx: 0, sy: 0, look: 0 };
  time = 0; real = 0; hitstop = 0; slowT = 0; slowK = 1; flash = 0; hurtFlash = 0; letter = 0; letterT = 0; lightning = 0; lightningT = 6;
  state: OfficeUI['state'] = 'title';
  wave = 0; waveState: 'intro' | 'fight' | 'clear' | 'climb' | 'arrive' | 'none' = 'none'; waveT = 0; queue: { kind: Kind; boss: boolean; elite: boolean }[] = []; spawnT = 0; nextSide = 1; maxAlive = 4; climbFrom = 0;
  score = 0; kills = 0; combo = 0; comboT = 0; bestCombo = 0; comboPop = 0; rankT = 0; rank: [string, string] | null = null; floorsClimbed = 0;
  banner: Banner | null = null; hint = 10; exec: Exec | null = null; clash: Clash | null = null; special: Special | null = null; bossIntro = 0; bossRef: Enemy | null = null;
  deathT = 0; overSent = false; best = { score: 0, wave: 0 };
  private nextId = 1; private keys = new Set<string>(); private press = new Map<string, number>();
  private raf = 0; private last = 0; private uiT = 0; private destroyed = false;
  onUI: ((ui: OfficeUI) => void) | null = null;
  private storyEntered = -1;
  slashes: SlashFx[] = []; stuck: { x: number; y: number; ang: number; life: number }[] = []; cuts: { x: number; y: number; life: number; max: number }[] = [];
  wheelT = 0; lock: Enemy | null = null; ofaScale = 1; ofaSaid = false; slam: Slam | null = null;
  bombs: { x: number; y: number; vx: number; vy: number; fuse: number; mine: boolean; spin: number }[] = [];
  pools: { x: number; y: number; r: number; max: number; a: number }[] = [];
  lights: { x: number; y: number; r: number; c: string; life: number; max: number }[] = [];
  glowProps: Prop[] = [];
  lamps: Lamp[] = []; windows: Win[] = []; liveDecor: WallDecor[] = [];
  atmoMode: 'auto' | AtmoId = 'auto'; atmoTarget: AtmoId = 'malam'; atmoFrom: AtmoDef = ATMOS.malam; atmoTo: AtmoDef = ATMOS.malam; atmoK = 1; A: AtmoDef = ATMOS.malam;
  weather = new Weather(); thunderT = 0; rainWaves = 0;
  levelMode = 0; levelGoal = 0; diff = 0; levelMax = 1;
  toast: { text: string; c: string; t: number; max: number } | null = null;
  ally: Ally | null = null; private allyHitting = false;
  civs: Civ[] = [];
  ctrl: 'v2' | 'kbd' = 'v2'; mouseSX = VW / 2; mouseSY = VH / 2; mouseAt = -99; mouseIn = false; mouseKind = 'mouse';
  private fistStep = 0; private fistLastT = -9; private fistHist: string[] = []; private ippoPlan: string[] = []; private ippoI = 0; private fistLastKey = ''; private ippoSayT = -9; ippoGuardT = 0;
  private batFlow = 0; private batJuggle = 0; private batLastT = -9; private batLastSpecial = ''; private batLastPower = ''; private runHeavyToggle = 0; private sgDryT = -9;
  trick: { kind: 'gun' | 'bow'; style: string; pose: Pose; t: number; dur: number; shots: number; fired: number } | null = null; private trickCd = 0;
  gates = new EightGates();
  /** modul senjata asli Kungfu Drifter yang berjalan di side view */
  br = new Bridge(this);
  /** pemain tiruan untuk modul Delapan Gerbang asli (koordinat 3/4 -> side view, z selalu 0) */
  private gp = { x: 0, y: 0, z: 0, vx: 0, vy: 0, kx: 0, ky: 0, facing: 1, aim: 0, holdT: 0, holdPose: 'flex', holdPoseT: 0, fatality: null as unknown, weapon: 'fist', stunT: 0, lean: { x: 1, y: 0 } };
  private ga: Record<string, unknown> = {};

  constructor(canvas: HTMLCanvasElement, soundVersion: SoundVersion = 'v2') {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.buf = document.createElement('canvas');
    this.buf.width = Math.ceil(VW / 1.2) + 4; this.buf.height = Math.ceil(VH / 1.2) + 4;
    this.b = this.buf.getContext('2d')!;
    this.sfx = new Sfx(soundVersion);
    this.sky = buildSky2();
    try { const m = localStorage.getItem('office_atmo'); if (m === 'auto' || (m && m in ATMOS)) this.atmoMode = m as 'auto' | AtmoId; } catch { /* */ }
    try { this.levelMax = Math.max(1, Math.min(LEVEL_COUNT, Number(localStorage.getItem('office_level_max')) || 1)); } catch { /* */ }
    try { const s = JSON.parse(localStorage.getItem(BEST_KEY) || 'null'); if (s) this.best = s; } catch { /* kosong */ }
    this.fx.solid = (x, y) => this.solidAt(x, y, false, true);
    this.fx.onBlood = (x, y, c, s, floor) => this.stampBlood(x, y, c, s, floor);
    this.fxBack.solid = this.fx.solid;
    this.fxBack.onBlood = this.fx.onBlood;
    try { const t = Number(localStorage.getItem('office_tempo')); if (t >= 0.3 && t <= 1) this.tempo = t; } catch { /* */ }
    window.addEventListener('keydown', this.onKeyDown, true);
    window.addEventListener('keyup', this.onKeyUp, true);
    window.addEventListener('blur', this.onBlur);
    window.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('pointerdown', this.onPointer);
    canvas.addEventListener('contextmenu', this.onCtx);
    canvas.addEventListener('wheel', this.onWheel, { passive: false });
    canvas.addEventListener('pointermove', this.onMouseMove);
    canvas.addEventListener('pointerleave', this.onMouseLeave);
    try { const c = localStorage.getItem('office_ctrl'); if (c === 'kbd' || c === 'v2') this.ctrl = c; } catch { /* */ }
    this.setupGates();
  }

  // ============================== INPUT ==============================
  private onKeyDown = (e: KeyboardEvent) => {
    if (this.destroyed) return;
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    if (!GAME_CODES.has(e.code)) return;
    if (this.state === 'playing' || this.state === 'paused') e.preventDefault();
    this.sfx.init();
    if (!e.repeat) this.press.set(e.code, this.real);
    this.keys.add(e.code);
    if (!e.repeat && KEYS.pause.includes(e.code) && (this.state === 'playing' || this.state === 'paused')) this.togglePause();
    if (!e.repeat && KEYS.mute.includes(e.code)) { this.sfx.toggleMute(); this.pushUI(true); }
  };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.code); };
  private onBlur = () => { this.keys.clear(); };
  private onPointer = (e: PointerEvent) => {
    this.sfx.init();
    if (this.state !== 'playing') return;
    this.onMouseMove(e);
    const code = e.button === 2 ? 'Mouse2' : 'Mouse0';
    this.press.set(code, this.real); this.keys.add(code);
  };
  private onPointerUp = (e: PointerEvent) => { this.keys.delete(e.button === 2 ? 'Mouse2' : 'Mouse0'); };
  private onCtx = (e: Event) => e.preventDefault();
  private wheelCd = 0;
  private onWheel = (e: WheelEvent) => {
    if (this.state !== 'playing') return;
    e.preventDefault();
    if (this.real - this.wheelCd < 0.12) return;
    this.wheelCd = this.real;
    this.cycleWeapon(e.deltaY > 0 ? 1 : -1);
  };
  /** kontrol sentuh */
  setKey(code: string, down: boolean) {
    this.sfx.init();
    if (down) { if (!this.keys.has(code)) this.press.set(code, this.real); this.keys.add(code); if (KEYS.pause.includes(code)) this.togglePause(); }
    else this.keys.delete(code);
  }
  private held(list: string[]) { for (const k of list) if (this.keys.has(k)) return true; return false; }
  private hit(list: string[]) {
    for (const k of list) { const t = this.press.get(k); if (t !== undefined && this.real - t < 0.16) { this.press.delete(k); return true; } }
    return false;
  }

  // ============================== SETUP ==============================
  load(map: OfficeMap) {
    this.map = map; this.W = map.w; this.H = map.h; this.stories = storiesOf(map);
    this.tiles = map.rows.map((r) => [...r]);
    const bb = buildBuilding(map);
    this.sprites.clear();
    this.building = bb.cv; this.lamps = bb.lamps; this.windows = bb.windows; this.liveDecor = bb.decor;
    this.decals = document.createElement('canvas'); this.decals.width = this.W * T; this.decals.height = this.H * T;
    this.dctx = this.decals.getContext('2d')!;
    this.spans = Array.from({ length: this.stories }, (_, s) => storySpan(map, s));
    this.conns = []; this.ladders = []; this.props = []; this.spawnPts = []; this.glassCells = [];
    let px = this.W * T / 2, py = this.H * T;
    for (let r = 0; r < this.H; r++) for (let c = 0; c < this.W; c++) {
      const ch = this.tiles[r][c];
      const story = Math.floor(r / STORY);
      if (ch === 'S' || ch === 'E') this.conns.push({ c, r, ch, x: c * T + 8, yF: this.floorBelow(c, r), story, open: 0, openT: 0, up: null, down: null });
      else if (ch === 'G') this.glassCells.push({ c, r });
      else if (ch === 'P') { px = c * T + 8; py = this.floorBelow(c, r); }
      else if (ch === 'X') { const yF = this.floorBelow(c, r); this.spawnPts.push({ x: c * T + 8, yF, story: this.storyOf(yF), conn: null }); }
      else if (PROP_CHARS.includes(ch)) {
        this.props.push({ ch, x: c * T, yF: (r + 1) * T, hp: ch === 'R' ? 9999 : 'vrfFmjhsVBJA'.includes(ch) ? 3 : 2, broken: false, shake: 0, seed: hh(c, r, 5), nl: this.tiles[r][c - 1] === ch, nr: this.tiles[r][c + 1] === ch, h: propHeight(ch), story });
      }
      if (ch === 'H' && (r === 0 || this.tiles[r - 1][c] !== 'H')) {
        let rb = r; while (rb + 1 < this.H && this.tiles[rb + 1][c] === 'H') rb++;
        this.ladders.push({ c, x: c * T + 8, topY: r * T, botY: (rb + 1) * T });
      }
    }
    for (const a of this.conns) {
      a.story = this.storyOf(a.yF);
      let bu: Conn | null = null, bd: Conn | null = null;
      for (const o of this.conns) {
        if (o === a || Math.abs(o.c - a.c) > 3) continue;
        if (o.yF < a.yF - 8 && (!bu || o.yF > bu.yF)) bu = o;
        if (o.yF > a.yF + 8 && (!bd || o.yF < bd.yF)) bd = o;
      }
      a.up = bu; a.down = bd;
      this.spawnPts.push({ x: a.x, yF: a.yF, story: a.story, conn: a });
    }
    this.player = this.makePlayer(px, py);
    this.glowProps = this.props.filter((pr) => 'liVAOvy'.includes(pr.ch));
    this.br.buildLevel();
    this.spawnCivs();
    this.br.onEquip(this.player.weapon);
  }
  private floorBelow(c: number, r: number) { let rr = r; while (rr < this.H - 1 && !this.solidTile(c, rr + 1)) rr++; return (rr + 1) * T; }
  private solidTile(c: number, r: number) { const ch = this.tiles[r]?.[c]; return ch === '#' || ch === 'G'; }
  storyOf(y: number) { return clamp(Math.floor((y - 1) / STORY_PX), 0, this.stories - 1); }
  theme(story: number): Theme { return themeOf(this.map, story); }

  private makeBody(x: number, y: number, scale: number, hp: number): Body {
    return { id: this.nextId++, x, y, vx: 0, vy: 0, facing: 1, onGround: true, scale, hp, maxHp: hp, flash: 0, walk: 0, stride: 2.4, runK: 0, rot: 0, vrot: 0, sqx: 1, sqy: 1, alpha: 1, climbing: false, ladder: null, dropT: 0, react: null,
      animPose: 'idle', animT: 0, prevPose: 'idle', prevT: 0, blend: 0, blendDur: 0.1, lastFacing: 1, pivotT: 0 };
  }
  private makePlayer(x: number, y: number): Player {
    return { ...this.makeBody(x, y, 1, 100), chi: 0, seq: '', moveKey: null, phase: 'none', phaseT: 0, hitSet: new Set(), hitTimes: new Map(), comboTimer: 0, buffer: null, bufferT: 0, airSeq: '', airHits: 0,
      dashT: 0, dashCd: 0, dashDir: 1, airDash: false, parryT: 0, parryCd: 0, parryAnim: 0, blocking: false, counterT: 0, iframes: 0, hurtT: 0, downT: 0, getupT: 0, dead: false, runT: 0, coyote: 0, land: 0, squash: 1,
      door: null, afterT: 0, stepIdx: 0, brake: 0, climbPh: 0, fall: 'broken',
      weapon: this.savedWeapon(), move: null, swingA: 0, swingPrev: 0, ammo: { pistol: 12, rifle: 30, shotgun: 6, bow: 1 }, reloadT: 0, fireCd: 0,
      bowDraw: 0, bowFull: false, recoil: 0, aimRel: 0, shootT: 0, boxStance: 'ali', iaiMarks: [], iaiT: 0, ofa: 0, ofaOn: false, holdPose: 'flex', holdT: 0,
      kx: 0, bladeA: 0, bladeB: 0, bladePrevA: 0, sheatheT: 0, arcDone: false, batTwirl: 0, batTwirlCd: 5, busterRest: 0, grab: null, grabT: 0,
      aim: 0, attackAim: 0, bodyAim: 0, mouseAim: false, sinceDash: 9, tkdCd: 0, rhythm: [], chainLast: -9, style: 'none', styleStreak: 0, flowStep: 0, chain: 0, chainSide: 1, wcCount: 0,
      katanaPlan: 0, bufferKey: null, gunIdle: 0, twirlT: 0, sgPhase: 'ready', sgT: 0, sgBuf: false, buCharging: false, buHold: 0, buCharge: 0 };
  }

  start() { this.last = performance.now(); this.raf = requestAnimationFrame(this.frame); }
  destroy() {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown, true);
    window.removeEventListener('keyup', this.onKeyUp, true);
    window.removeEventListener('blur', this.onBlur);
    window.removeEventListener('pointerup', this.onPointerUp);
    this.canvas.removeEventListener('pointerdown', this.onPointer);
    this.canvas.removeEventListener('contextmenu', this.onCtx);
    this.canvas.removeEventListener('wheel', this.onWheel);
    this.canvas.removeEventListener('pointermove', this.onMouseMove);
    this.canvas.removeEventListener('pointerleave', this.onMouseLeave);
    this.weather.stop();
    this.sfx.stopMusic(); this.sfx.dispose();
  }

  showTitle(map: OfficeMap) {
    this.levelMode = 0; this.diff = 0;
    this.load(map); this.state = 'title'; this.enemies = []; this.waveState = 'none';
    this.cam.x = this.player.x; this.cam.y = this.player.y - 30; this.letter = 0;
    this.pushUI(true);
  }
  newGame(map: OfficeMap, level = 0) {
    this.levelMode = level; this.levelGoal = level ? levelSpec(level).waves : 0; this.diff = level ? levelSpec(level).diff : 0; this.rainWaves = 0;
    this.load(map);
    this.enemies = []; this.bullets = []; this.pickups = []; this.ghosts = []; this.fx.list = []; this.fxBack.list = []; this.texts.list = [];
    this.score = 0; this.kills = 0; this.combo = 0; this.bestCombo = 0; this.wave = 0; this.floorsClimbed = 0;
    this.exec = null; this.clash = null; this.special = null; this.deathT = 0; this.overSent = false; this.hint = 12; this.slowT = 0; this.hitstop = 0;
    this.bombs = []; this.pools = []; this.lights = []; this.toast = null; this.ally = null; this.slashes = []; this.stuck = []; this.cuts = []; this.slam = null; this.lock = null; this.ofaScale = 1; this.ofaSaid = false; this.gates.reset(); this.wheelT = 3.5;
    this.press.clear(); this.keys.clear(); this.bossRef = null; this.bossIntro = 0; this.banner = null; this.flash = 0; this.hurtFlash = 0;
    this.cam.x = this.player.x; this.cam.y = this.player.y - 30; this.cam.zoom = 2.4; this.cam.tz = BASE_ZOOM;
    this.state = 'playing';
    this.storyEntered = this.storyOf(this.player.y);
    this.sfx.init(); this.sfx.startMusic(0.35);
    this.applyAtmo(true);
    this.startWave(1);
    this.pushUI(true);
  }
  togglePause() {
    if (this.state === 'playing') { this.state = 'paused'; this.sfx.stopMusic(); this.weather.stop(); }
    else if (this.state === 'paused') { this.state = 'playing'; this.sfx.startMusic(0.4); this.last = performance.now(); }
    this.pushUI(true);
  }
  toggleMute() { this.sfx.init(); this.sfx.toggleMute(); this.pushUI(true); }
  setTempo(v: number) { this.tempo = clamp(v, 0.3, 1); try { localStorage.setItem('office_tempo', String(this.tempo)); } catch { /* */ } }

  pushUI(force = false) {
    if (!this.onUI) return;
    if (!force && this.real - this.uiT < 0.2) return;
    this.uiT = this.real;
    this.onUI({ level: this.levelMode, levelGoal: this.levelGoal, levelMax: this.levelMax, atmo: this.atmoTarget, atmoMode: this.atmoMode, state: this.state, wave: this.wave, score: Math.round(this.score), kills: this.kills, bestCombo: this.bestCombo, floor: this.map ? floorLabel(this.map, this.storyOf(this.player.y)) : '', best: this.best, muted: this.sfx.muted, mapName: this.map?.name ?? '', time: this.time, floorsClimbed: this.floorsClimbed, ally: !!this.ally, ctrl: this.ctrl });
  }

  // ============================== WORLD ==============================
  /** forFx: probe partikel (kaca pecah tetap tembus) */
  solidAt(x: number, y: number, isPlayer: boolean, forFx = false): boolean {
    const c = Math.floor(x / T), r = Math.floor(y / T);
    if (r >= this.H) return true;
    if (c < 0 || c >= this.W || r < 0) return isPlayer;
    const ch = this.tiles[r][c];
    if (ch === '#') return true;
    if (ch === 'G') return true;
    if (ch === 'g') return isPlayer && !forFx;
    return false;
  }
  private platTop(x: number, y: number) {
    const c = Math.floor(x / T), r = Math.floor(y / T);
    const ch = this.tiles[r]?.[c];
    if (ch === '=') return true;
    if (ch === 'H' && this.tiles[r - 1]?.[c] !== 'H') return true;
    return false;
  }
  private move(f: Body, dt: number, isPlayer: boolean, grav: number) {
    const hw = HALF_W * f.scale, bh = BODY_H * f.scale;
    // Unstick horizontal bila badan sedikit terhimpit ke dalam dinding kiri/kanan
    const midY = f.y - bh * 0.5;
    if (this.solidAt(f.x - hw, midY, isPlayer) && !this.solidAt(f.x + hw + 4, midY, isPlayer)) {
      for (let k = 1; k <= 12 && this.solidAt(f.x - hw, midY, isPlayer); k++) f.x += 1;
    } else if (this.solidAt(f.x + hw, midY, isPlayer) && !this.solidAt(f.x - hw - 4, midY, isPlayer)) {
      for (let k = 1; k <= 12 && this.solidAt(f.x + hw, midY, isPlayer); k++) f.x -= 1;
    }
    let wall = 0, landed = false, bonk = false, glass = false;
    const dx = f.vx * dt, n = Math.max(1, Math.ceil(Math.abs(dx) / 3)), sx = dx / n;
    for (let i = 0; i < n; i++) {
      const nx = f.x + sx, edge = nx + Math.sign(sx) * hw;
      const probes = [f.y - 2, f.y - bh * 0.5, f.y - bh + 2];
      let blocked = false;
      for (const py of probes) if (this.solidAt(edge, py, isPlayer)) { blocked = true; break; }
      if (blocked && !isPlayer && Math.abs(f.vx) > 125) {
        const gc = Math.floor(edge / T);
        let broke = false;
        for (const py of probes) { const gr = Math.floor(py / T); if (this.tiles[gr]?.[gc] === 'G') { this.breakGlass(gc, gr, Math.sign(sx), f.x, f.y - bh / 2); broke = true; } }
        if (broke) { glass = true; blocked = false; for (const py of probes) if (this.solidAt(edge, py, false)) blocked = true; }
      }
      if (blocked) { wall = Math.sign(sx); break; }
      f.x = nx;
    }
    if (!f.climbing) f.vy = Math.min(MAX_FALL, f.vy + grav * dt);
    const dy = f.vy * dt, m = Math.max(1, Math.ceil(Math.abs(dy) / 3)), sy = dy / m;
    for (let i = 0; i < m; i++) {
      const ny = f.y + sy;
      if (sy > 0) {
        const hitL = this.solidAt(f.x - hw + 1, ny, isPlayer) && !this.solidAt(f.x - hw + 1, ny - 5, isPlayer);
        const hitR = this.solidAt(f.x + hw - 1, ny, isPlayer) && !this.solidAt(f.x + hw - 1, ny - 5, isPlayer);
        let hitG = hitL || hitR;
        if (!hitG && f.dropT <= 0 && !f.climbing) {
          const top = Math.floor(ny / T) * T;
          if (f.y <= top + 0.01 && ny >= top && (this.platTop(f.x, ny))) hitG = true;
        }
        if (hitG) { f.y = Math.floor(ny / T) * T; landed = true; break; }
      } else if (sy < 0 && this.solidAt(f.x, ny - bh, isPlayer)) { bonk = true; break; }
      f.y = ny;
    }
    if (landed || bonk) f.vy = landed ? 0 : Math.max(0, f.vy * -0.2);
    f.onGround = landed;
    return { wall, landed, bonk, glass };
  }
  private breakGlass(c: number, r: number, dir: number, x: number, y: number) {
    const s = Math.floor(r / STORY);
    for (let rr = s * STORY; rr < s * STORY + STORY - 1; rr++) if (this.tiles[rr][c] === 'G') {
      this.tiles[rr][c] = 'g';
      this.fx.glass(c * T + 8, rr * T + 8, 9, dir > 0 ? 0 : Math.PI, 1.2);
    }
    this.fx.glass(x + dir * 6, y, 14, dir > 0 ? -0.3 : Math.PI + 0.3, 1.6);
    this.sfx.glassShatter();
    this.shake(0.5); this.slow(0.45, 0.3);
  }
  private stampBlood(x: number, y: number, c: string, s: number, floor: boolean) {
    const st = this.storyOf(y + (floor ? 0 : 1));
    const sp = this.spans[st];
    if (!sp || x < sp[0] * T || x > (sp[1] + 1) * T) return;
    const g = this.dctx;
    g.fillStyle = c;
    if (floor) { const w = s + Math.floor(rnd(1, 4)); g.globalAlpha = 0.9; g.fillRect(Math.round(x - w / 2), Math.round(y + rnd(0, 3)), w, 1); }
    else {
      if (this.solidAt(x, y, false, true) || this.theme(st).outdoor) return;
      g.globalAlpha = 0.55; g.fillRect(Math.round(x), Math.round(y), Math.min(2, s), Math.min(2, s));
      if (s > 1 && Math.random() < 0.4) g.fillRect(Math.round(x), Math.round(y) + s, 1, Math.floor(rnd(2, 6)));
    }
    g.globalAlpha = 1;
  }
  private crack(x: number, y: number, vertical: boolean) {
    const g = this.dctx; g.fillStyle = 'rgba(15,15,20,0.8)';
    let cx = x, cy = y;
    for (let i = 0; i < 7; i++) { cx += vertical ? rnd(-1.5, 1.5) : rnd(-2, 2); cy += vertical ? rnd(-2, 2) : rnd(-1, 1); g.fillRect(Math.round(cx), Math.round(cy), 1, 1); }
  }

  shake(t: number) { this.cam.shake = Math.min(1.2, this.cam.shake + t * 0.6); }
  slow(dur: number, k: number) { if (this.slowT <= 0 || k <= this.slowK) { this.slowT = Math.max(this.slowT, dur); this.slowK = k; } }
  zoomPunch(z: number) { this.cam.tz = Math.max(this.cam.tz, z); }
  say(text: string, sub = '', c = '#ffffff', dur = 1.6) { this.banner = { text, sub, t: 0, max: dur, c }; }

  // ============================== LOOP ==============================
  private frame = (now: number) => {
    if (this.destroyed) return;
    this.raf = requestAnimationFrame(this.frame);
    const raw = Math.min(0.05, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    this.real += raw;
    this.resize();
    if (this.map && this.state !== 'paused') this.step(raw);
    if (this.map) this.render();
    this.pushUI();
  };
  private resize() {
    const r = this.canvas.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(VW, Math.round(r.width * dpr)), h = Math.round(w * VH / VW);
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
  }

  private step(raw: number) {
    this.lastDt = 0;
    let ts = 1;
    if (this.slowT > 0) { this.slowT -= raw; ts = this.slowK; }
    if (this.exec) ts = Math.min(ts, 0.55);
    if (this.bossIntro > 0) { this.bossIntro -= raw; ts = Math.min(ts, 0.5); }
    this.flash = Math.max(0, this.flash - raw * 3);
    this.hurtFlash = Math.max(0, this.hurtFlash - raw * 1.6);
    this.letterT = this.exec || this.clash || this.bossIntro > 0 || this.special || this.slam ? 1 : 0;
    this.letter += (this.letterT - this.letter) * Math.min(1, raw * 8);
    if (this.map) this.updateAtmo(raw);
    this.updateCamera(raw);
    this.texts.update(raw);
    if (this.banner) { this.banner.t += raw; if (this.banner.t > this.banner.max) this.banner = null; }
    if (this.toast) { this.toast.t += raw; if (this.toast.t > this.toast.max) this.toast = null; }
    this.comboPop = Math.max(0, this.comboPop - raw * 4);
    this.wheelT = Math.max(0, this.wheelT - raw);
    this.rankT = Math.max(0, this.rankT - raw);
    if (this.hitstop > 0) { this.hitstop -= raw; return; }
    // MODE X: dunia melambat ke 30%, pemain bergerak 133%
    this.ofaScale += ((this.player?.ofaOn ? 0.3 : 1) - this.ofaScale) * Math.min(1, raw * 9);
    const dt = raw * Math.min(ts, this.ofaScale);
    const pdt = this.player?.ofaOn && !this.exec && !this.slam ? raw * (4 / 3) : dt;
    this.lastDt = dt;
    this.time += dt;
    for (const c of this.conns) { c.openT = Math.max(0, c.openT - dt); c.open += ((c.openT > 0 ? 1 : 0) - c.open) * Math.min(1, dt * 9); }
    for (const p of this.props) p.shake = Math.max(0, p.shake - dt);
    if (this.state === 'title') { this.fx.update(dt); this.fxBack.update(dt); this.idlePlayer(dt); this.updateCivs(dt); return; }
    if (this.clash) { this.updateClash(raw); this.fx.update(raw); this.fxBack.update(raw); return; }
    this.hint = Math.max(0, this.hint - dt);
    this.updatePlayer(pdt);
    this.br.update(pdt);
    this.updateAlly(dt);
    this.updateCivs(dt);
    if (this.player.grab && (this.player.dead || this.exec || this.special || this.slam || this.player.door || this.player.downT > 0)) this.dropHeld();
    this.syncGp(); this.gates.update(this.ga, pdt); this.readGp();
    this.updateOfa(raw);
    if (this.exec) this.updateExec(dt);
    else if (this.slam) this.updateSlam(dt);
    else for (const e of this.enemies) this.updateEnemy(e, dt);
    for (const sl of this.slashes) sl.life -= dt;
    this.slashes = this.slashes.filter((sl) => sl.life > 0);
    for (const ct of this.cuts) ct.life -= dt;
    this.cuts = this.cuts.filter((ct) => ct.life > 0);
    this.updateBullets(dt);
    this.updateBombs(dt);
    this.updateLights(dt);
    this.updatePickups(dt);
    this.updateGhosts(dt);
    this.fx.update(dt);
    this.fxBack.update(dt);
    if (this.state === 'playing') this.updateWave(dt);
    if (this.comboT > 0) { this.comboT -= dt; if (this.comboT <= 0) this.combo = 0; }
    // musik ikut tegang
    const alive = this.enemies.filter((e) => !e.dead).length;
    this.sfx.setIntensity(clamp(0.25 + alive * 0.08 + (this.bossRef && !this.bossRef.dead ? 0.4 : 0) + this.combo * 0.01, 0, 1));
    const old = this.enemies.filter((e) => e.dead);
    if (old.length > 16) { const o = old[0]; this.enemies.splice(this.enemies.indexOf(o), 1); }
    this.enemies = this.enemies.filter((e) => !(e.dead && (e.deadT > 14 || e.y > this.H * T + 300)));
    if (this.player.dead) {
      this.deathT += raw;
      if (this.deathT > 2.4 && !this.overSent) {
        this.overSent = true; this.state = 'over'; this.sfx.stopMusic();
        if (this.score > this.best.score || this.wave > this.best.wave) { this.best = { score: Math.max(this.best.score, Math.round(this.score)), wave: Math.max(this.best.wave, this.wave) }; try { localStorage.setItem(BEST_KEY, JSON.stringify(this.best)); } catch { /* */ } }
        this.pushUI(true);
      }
    }
  }

  private idlePlayer(dt: number) {
    const p = this.player;
    p.walk = 0; p.vx = 0;
    this.move(p, dt, true, GRAV);
  }

  // ============================== WAVES ==============================
  private startWave(n: number) {
    this.wave = n; this.waveState = 'intro'; this.waveT = 2.0;
    if (this.atmoMode === 'auto' && !this.levelMode) { if (this.rainWaves > 0) this.rainWaves--; else if (n > 2 && Math.random() < 0.2) this.rainWaves = 2; }
    const dn = n + this.diff;
    const count = Math.min(30, 4 + Math.floor(dn * 2));
    const pool: Kind[] = ['thug', 'thug', 'thug'];
    if (dn >= 2) pool.push('kicker', 'kicker');
    if (dn >= 3) pool.push('knife', 'monk');
    if (dn >= 4) pool.push('guard', 'shield');
    if (dn >= 5) pool.push('gunner', 'smg');
    if (dn >= 6) pool.push('bomber');
    if (dn >= 7) pool.push('brute');
    if (dn >= 8) pool.push('shotgunner', 'monk');
    if (dn >= 9) pool.push('knife', 'gunner', 'kicker', 'shield');
    this.queue = [];
    for (let i = 0; i < count; i++) this.queue.push({ kind: pool[Math.floor(Math.random() * pool.length)], boss: false, elite: Math.random() < Math.min(0.35, dn * 0.025) });
    if (this.levelMode ? n === this.levelGoal : n % 3 === 0) this.queue.push({ kind: BOSS_CYCLE[((this.levelMode ? this.levelMode : n / 3) - 1) % BOSS_CYCLE.length], boss: true, elite: true });
    this.maxAlive = Math.min(10, 4 + Math.floor(dn / 2));
    this.spawnT = 0.6;
    const st = this.storyOf(this.player.y);
    this.say(this.levelMode ? `LEVEL ${this.levelMode} - WAVE ${n}/${this.levelGoal}` : `WAVE ${n}`, `${floorLabel(this.map, st)} - ${this.theme(st).name}`, this.theme(st).accent, 2.2);
    this.sfx.announce();
  }
  private updateWave(dt: number) {
    const p = this.player;
    const st = this.storyOf(p.y);
    if (st !== this.storyEntered && p.onGround && !p.door) {
      if (st < this.storyEntered) this.floorsClimbed++;
      this.storyEntered = st;
      if (this.waveState !== 'climb') this.say(floorLabel(this.map, st), this.theme(st).name, this.theme(st).accent, 1.4);
    }
    switch (this.waveState) {
      case 'intro': this.waveT -= dt; if (this.waveT <= 0) this.waveState = 'fight'; break;
      case 'fight': {
        this.spawnT -= dt;
        const alive = this.enemies.filter((e) => !e.dead).length;
        if (this.queue.length && alive < this.maxAlive && this.spawnT <= 0 && !p.dead) {
          const q = this.queue.shift()!;
          this.spawnEnemy(q.kind, this.nextSide, q.boss, q.elite);
          this.nextSide *= -1;
          this.spawnT = Math.max(0.45, 1.5 - this.dw * 0.06) * rnd(0.7, 1.25);
        }
        if (!this.queue.length && alive === 0 && !p.dead) this.waveClear();
        break;
      }
      case 'clear':
        this.waveT -= dt;
        if (this.waveT <= 0) {
          if ((this.levelMode ? this.wave < this.levelGoal : this.wave % 3 === 0) && st > 0 && this.hasRouteUp(st)) { this.waveState = 'climb'; this.waveT = 14; this.climbFrom = st; this.say('NAIK KE LANTAI ATAS!', 'PAKAI TANGGA / PINTU DARURAT / LIFT (W)', '#5ff0ff', 3); }
          else this.startWave(this.wave + 1);
        }
        break;
      case 'climb':
        this.waveT -= dt;
        if (st < this.climbFrom && p.onGround && !p.door) {
          this.score += 1000; this.heal(30);
          this.say('LANTAI BARU!', `+1000  ${this.theme(st).name}`, this.theme(st).accent, 2);
          this.sfx.levelClear();
          this.waveState = 'arrive'; this.waveT = 1.4;
        } else if (this.waveT <= 0) this.startWave(this.wave + 1);
        break;
      case 'arrive':
        this.waveT -= dt;
        if (this.waveT <= 0) this.startWave(this.wave + 1);
        break;
      default: break;
    }
  }
  private hasRouteUp(st: number) { return this.conns.some((c) => c.story === st && c.up) || this.ladders.some((l) => this.storyOf(l.botY) === st && this.storyOf(l.topY) < st); }
  private waveClear() {
    if (this.levelMode && this.wave >= this.levelGoal) { this.waveState = 'none'; this.levelComplete(); return; }
    this.waveState = 'clear'; this.waveT = 2.8;
    const bonus = 250 * this.wave;
    this.score += bonus; this.heal(15);
    this.say('WAVE BERSIH!', `BONUS +${bonus}`, '#7cff9a', 2.4);
    this.sfx.levelClear();
  }
  private spawnEnemy(kind: Kind, side: number, boss: boolean, elite: boolean) {
    const p = this.player, ps = this.storyOf(p.y);
    const pts = this.spawnPts.filter((s) => s.story === ps);
    const sideOk = pts.filter((s) => (side < 0 ? s.x < p.x - 50 : s.x > p.x + 50));
    const near = sideOk.filter((s) => Math.abs(s.x - p.x) < 340);
    let cands = near.length ? near : sideOk.length ? [sideOk.reduce((a, b) => (Math.abs(a.x - p.x) < Math.abs(b.x - p.x) ? a : b))] : [];
    if (!cands.length) cands = pts.filter((s) => Math.abs(s.x - p.x) > 50);
    let x: number, yF: number, conn: Conn | null = null, drop = false;
    if (cands.length) { const s = cands[Math.floor(Math.random() * cands.length)]; x = s.x; yF = s.yF; conn = s.conn; drop = !conn; }
    else {
      const sp = this.spans[ps];
      x = clamp(p.x + side * 150, sp[0] * T + 24, (sp[1] + 1) * T - 24); yF = ps * STORY_PX + STORY_PX - T; drop = true;
    }
    const d = KINDS[kind];
    const sc = d.scale * (boss && kind === 'brute' ? 1.12 : 1);
    const hp = Math.round(d.hp * (elite ? 1.5 : 1) * (boss ? 1.8 : 1) * (1 + this.dw * 0.035));
    const e: Enemy = {
      ...this.makeBody(x, drop ? yF - 50 : yF, sc, hp), kind, def: d, name: boss ? BOSS_NAMES[Math.floor(this.wave / 3) % BOSS_NAMES.length] : d.name, boss, elite,
      state: 'spawn', stateT: 0, poseT: 0, atkCd: rnd(0.4, 1.2), atk: null, chain: 0, structure: 0, dizzy: 0, knock: false, dead: false, deadT: 0, outside: false, token: false,
      spawnT: drop ? 0.9 : 0.6, spawnMode: drop ? 'drop' : 'door', doorTo: null, fall: 'broken', juggle: 0, blockCd: 0, aimT: 0, wallCd: 0, hold: rnd(0, 1), recoil: 0,
    };
    e.facing = p.x >= x ? 1 : -1;
    e.alpha = 0;
    if (!boss && (kind === 'thug' || kind === 'kicker' || kind === 'knife')) {
      const cols = kind === 'thug' ? ['#d9d9d9', '#cdb9a6', '#b9c9d9', '#d9c99f', '#a9bfa3', '#c9a9c9', '#e8e8e8'] : kind === 'kicker' ? ['#8fd3ff', '#9ff8d0', '#b9a8ff', '#ffb0d0'] : ['#ffcf6b', '#ffb36b', '#ffe08a'];
      e.col = cols[Math.floor(Math.random() * cols.length)];
      if (kind === 'thug') e.acc = ['band', 'none', 'glasses', 'hood', 'shades', 'mask', 'band', 'crown'][Math.floor(Math.random() * 8)];
    }
    if (drop) e.vy = 0;
    this.enemies.push(e);
    if (conn) {
      conn.openT = 0.9;
      if (conn.ch === 'E') { this.sfx.beep(); this.texts.add(conn.x, conn.yF - 34, 'DING!', '#ffd166', 1, 0.8); }
      else this.sfx.spawn();
    } else this.sfx.spawn();
    if (boss) {
      this.bossRef = e; this.bossIntro = 1.6;
      this.say(e.name, BOSS_SUB[kind] ?? '', '#ff3b3b', 2.4);
      this.sfx.fatality();
    }
  }

  // ============================== PLAYER ==============================
  private heal(n: number) { const p = this.player; if (p.dead) return; p.hp = Math.min(p.maxHp, p.hp + n); }
  private atDoor(): Conn | null {
    const p = this.player;
    for (const c of this.conns) if (Math.abs(c.x - p.x) < 8 && Math.abs(c.yF - p.y) < 3) return c;
    return null;
  }
  private atLadder(b: Body): Ladder | null {
    for (const l of this.ladders) if (Math.abs(l.x - b.x) < 7 && b.y >= l.topY - 1 && b.y <= l.botY + 1) return l;
    return null;
  }
  private updatePlayer(dt: number) {
    const p = this.player;
    p.flash = Math.max(0, p.flash - dt); p.iframes = Math.max(0, p.iframes - dt); p.parryT = Math.max(0, p.parryT - dt); p.parryCd = Math.max(0, p.parryCd - dt);
    p.parryAnim = Math.max(0, p.parryAnim - dt); p.counterT = Math.max(0, p.counterT - dt); p.dashCd = Math.max(0, p.dashCd - dt); p.dropT = Math.max(0, p.dropT - dt);
    p.land = Math.max(0, p.land - dt); p.squash += (1 - p.squash) * Math.min(1, dt * 12); p.bufferT = Math.max(0, p.bufferT - dt);
    if (p.react) { p.react.t += dt; if (p.react.t > p.react.dur) p.react = null; }
    p.holdT = Math.max(0, p.holdT - dt);
    p.sinceDash = p.dashT > 0 ? 0 : p.sinceDash + dt; p.tkdCd = Math.max(0, p.tkdCd - dt); p.twirlT = Math.max(0, p.twirlT - dt); this.ippoGuardT = Math.max(0, this.ippoGuardT - dt);
    this.br.input.mouse.pressed = false; this.br.input.mouse.rpressed = false;
    if (p.iaiT > 0) { p.iaiT -= dt; if (p.iaiT <= 0) this.iaiDetonate(); }
    if (p.dead) { const r = this.move(p, dt, true, GRAV); if (r.landed) { p.vx *= 0.8; p.vrot = 0; p.rot = 0; } else p.rot += p.vrot * dt; p.vx *= Math.max(0, 1 - dt * 3); return; }
    if (this.exec || this.slam) return;
    if (p.door) { this.updateDoorTransit(dt); return; }
    if (this.special) { this.updateSpecial(dt); return; }
    const ix = (this.held(KEYS.right) ? 1 : 0) - (this.held(KEYS.left) ? 1 : 0);
    const upH = this.held(KEYS.up), downH = this.held(KEYS.down);
    const jumpHit = this.hit(KEYS.jump);
    let lightHit = this.hit(this.lightKeys), heavyHit = this.hit(this.heavyKeys);
    const dashHit = this.hit(KEYS.dash), parryHit = this.hit(KEYS.parry), specialHit = this.hit(KEYS.special), execHit = this.hit(KEYS.exec);
    const upHit = this.hit(KEYS.up), downHit = this.hit(KEYS.down);
    if (p.downT > 0) {
      p.downT -= dt; const r = this.move(p, dt, true, GRAV); if (r.landed) p.vx *= Math.max(0, 1 - dt * 10);
      if (p.downT <= 0) { p.getupT = 0.4; p.iframes = 0.7; }
      return;
    }
    if (p.getupT > 0) { p.getupT -= dt; p.vx = 0; this.move(p, dt, true, GRAV); return; }
    if (p.hurtT > 0) { p.hurtT -= dt; p.vx *= Math.max(0, 1 - dt * 6); this.move(p, dt, true, GRAV); return; }
    // ---- tangga panjat
    if (p.climbing && p.ladder) {
      const l = p.ladder;
      const vy = (upH ? -64 : 0) + (downH ? 64 : 0);
      p.x += (l.x - p.x) * Math.min(1, dt * 14); p.vx = 0; p.vy = vy;
      p.climbPh += Math.abs(vy) * dt * 0.25;
      p.walk += Math.abs(vy) * dt * 0.5;
      p.y += vy * dt;
      if (p.y <= l.topY) { p.y = l.topY; p.climbing = false; p.ladder = null; p.onGround = true; p.vy = 0; }
      else if (p.y >= l.botY) { p.y = l.botY; p.climbing = false; p.ladder = null; p.onGround = true; p.vy = 0; }
      if (jumpHit || (ix !== 0 && !upH && !downH)) { p.climbing = false; p.ladder = null; p.dropT = 0.2; if (jumpHit) { p.vy = -JUMP_V * 0.75; p.vx = ix * WALK; } }
      return;
    }
    // ---- senjata (tombol sama dengan Kungfu Drifter) + MODE N (Delapan Gerbang) + MODE X (One For All)
    this.updateAim();
    for (const w of WEAPON_ORDER) if (this.hit(this.weaponCodes(w))) this.setWeapon(w);
    if (this.hit(KEYS.cycle)) this.cycleWeapon(1);
    if (this.hit(KEYS.gates)) { this.syncGp(); this.gates.toggle(this.ga); this.readGp(); }
    if (this.hit(KEYS.ofa)) this.tryOfa();
    if (this.hit(KEYS.ally)) this.toggleAlly();
    if (this.hit(KEYS.grab)) { if (p.grab) { this.throwHeld(); lightHit = false; } else this.tryGrab(); }
    if (p.grab) { this.updateHeld(dt); if (lightHit) { this.throwHeld(); lightHit = false; } else if (heavyHit) { this.slamHeld(); heavyHit = false; } }
    // ---- input tempur
    if (specialHit && p.chi >= 100) { this.startSpecial(); return; }
    if (execHit) { const t = this.execTarget(); if (t) { this.startExec(t); return; } }
    if (parryHit && p.parryCd <= 0) { p.parryT = 0.2; p.parryCd = 0.32; p.parryAnim = 0.22; if (p.phase !== 'active') { p.phase = 'none'; p.moveKey = null; p.move = null; } this.sfx.swing(1.5); }
    p.blocking = this.held(KEYS.parry) && p.phase === 'none' && p.onGround;
    if (dashHit && p.dashCd <= 0 && (p.onGround || !p.airDash) && p.phase !== 'active') {
      p.dashT = 0.22; p.dashCd = 0.42; p.dashDir = ix || p.facing; if (!p.mouseAim) p.facing = p.dashDir; p.iframes = Math.max(p.iframes, 0.2); p.phase = 'none'; p.moveKey = null; p.move = null;
      if (!p.onGround) { p.airDash = true; p.vy = Math.min(p.vy, -40); }
      this.sfx.dash(); this.fx.dust(p.x, p.y, 5, p.dashDir);
    }
    // ---- INPUT SENJATA GAYA V2: klik kiri / klik kanan, arah = kursor mouse
    const lh = this.held(this.lightKeys), rh = this.held(this.heavyKeys);
    const bi = this.br.input.mouse; bi.pressed = lightHit; bi.rpressed = heavyHit; bi.down = lh; bi.rdown = rh;
    if (this.held(KEYS.dash)) this.br.input.keys.add('shift'); else this.br.input.keys.delete('shift');
    const wk0 = p.weapon, Wk = WEAPONS[wk0].kind, freeA = p.phase === 'none' || p.phase === 'recover';
    if (this.br.isModuleWeapon(wk0)) { if ((lightHit || heavyHit) && !p.mouseAim) this.autoFace(ix); }
    else if (Wk === 'gun' || Wk === 'bow') this.updateGuns(dt, lightHit, heavyHit, lh, upH, downH);
    else if (wk0 === 'buster') this.busterInput(dt, lightHit, heavyHit, lh);
    else {
      if (lightHit) this.queueAttack('L', ix);
      if (heavyHit && wk0 !== 'axe') this.queueAttack('H', ix);
      // TAHAN (V2): pemukul & tinju spam, yoyo orbit, nunchaku rantai api
      if ((wk0 === 'bat' || wk0 === 'boxing') && p.onGround && !p.buffer && freeA) { if (lh && !lightHit) this.queueAttack('L', ix); else if (rh && !heavyHit) this.queueAttack('H', ix); }
      if (wk0 === 'yoyo' && p.onGround) {
        if (rh && p.phase === 'active' && (p.moveKey === 'YH' || p.moveKey === 'YHH') && p.phaseT < 0.1) p.phaseT = 0.1;
        if (p.phase === 'none' && rh && !heavyHit) this.startAttack('YH');
        else if (p.phase === 'none' && lh && !lightHit) this.queueAttack('L', ix);
      }
      if (wk0 === 'nunchaku' && lh && !lightHit && p.onGround) this.br.nunPress(false, p.aim);
    }
    if (Wk !== 'gun' && Wk !== 'bow') { p.recoil = Math.max(0, p.recoil - dt * 6); p.shootT = Math.max(0, p.shootT - dt); this.trickCd = Math.max(0, this.trickCd - dt); }
    // ---- pintu / lift
    const door = p.onGround && p.phase === 'none' ? this.atDoor() : null;
    if (door && upHit && door.up) { this.enterDoor(door, door.up); return; }
    if (door && downHit && door.down) { this.enterDoor(door, door.down); return; }
    // ---- naik tangga panjat
    const lad = this.atLadder(p);
    if (lad && p.phase === 'none' && ((upH && p.y > lad.topY + 1) || (downH && p.y < lad.botY - 1 && !door))) {
      if (!(downH && p.onGround && p.y >= lad.botY - 1)) { p.climbing = true; p.ladder = lad; p.dashT = 0; p.vx = 0; p.dropT = 0.15; return; }
    }
    // ---- gerak
    const attacking = p.phase !== 'none';
    if (p.dashT > 0) {
      p.dashT -= dt; p.vx = p.dashDir * 290; p.vy = Math.min(p.vy, 60);
      p.afterT -= dt; if (p.afterT <= 0) { p.afterT = 0.035; this.ghost(this.playerOpts('dash', 0.5), '#9fe8ff'); }
    } else if (!attacking && !p.blocking && p.parryAnim <= 0) {
      // jalan -> lari naik bertahap (smoothstep), bukan loncat kecepatan
      const rk = clamp((p.runT - 0.22) / 0.4, 0, 1);
      const target = ix * (WALK + (RUN - WALK) * rk * rk * (3 - 2 * rk)) * this.gates.speedMul * (p.weapon === 'bow' ? 1 - 0.6 * p.bowDraw : 1) * (p.weapon === 'boxing' ? BOX_STANCES[p.boxStance].speed : 1) * this.br.moveMul() * (p.grab ? 0.72 : 1);
      if (ix !== 0) {
        if (Math.sign(p.vx) === -ix) { if (Math.abs(p.vx) > 60 && p.onGround) { p.brake = 1; this.fx.dust(p.x, p.y, 2, -ix); } p.runT = 0; }
        if (!p.mouseAim) p.facing = ix;
        p.runT += dt;
      } else p.runT = 0;
      const acc = p.onGround ? (ix ? (Math.sign(p.vx) === -ix ? 1400 : 760) : 1100) : 520;
      p.vx += clamp(target - p.vx, -acc * dt, acc * dt);
    } else {
      p.runT = 0;
      if (p.onGround) p.vx *= Math.max(0, 1 - dt * (p.blocking ? 14 : 7));
    }
    p.brake = Math.max(0, p.brake - dt * 4);
    p.runK += ((Math.abs(p.vx) > WALK + 8 ? 1 : 0) - p.runK) * Math.min(1, dt * 6);
    // ---- lompat
    if (p.onGround) { p.coyote = 0.1; p.airDash = false; p.airSeq = ''; p.airHits = 0; } else p.coyote -= dt;
    const ranged = WEAPONS[p.weapon].kind === 'gun' || WEAPONS[p.weapon].kind === 'bow';
    const wantJump = jumpHit || (upHit && !door && !lad && !ranged);
    if (wantJump && p.coyote > 0 && !attacking) {
      if (downH && this.platTop(p.x, p.y + 1)) { p.dropT = 0.25; p.onGround = false; }
      else { p.vy = -JUMP_V; p.coyote = 0; p.squash = 0.8; this.fx.dust(p.x, p.y, 4); this.sfx.swing(1.3); }
    }
    if (downH && jumpHit && this.platTop(p.x, p.y + 1)) { p.dropT = 0.25; }
    this.updateAttack(dt);
    const hang = p.phase !== 'none' && !p.onGround && !(p.move && (p.move.air || p.move.id === 'axekick')) ? 0.22 : 1;
    if (hang < 1 && p.vy > 40) p.vy *= 0.85;
    const wasAir = !p.onGround;
    p.vx += p.kx;
    const r = this.move(p, dt, true, GRAV * hang);
    p.vx -= p.kx; p.kx *= Math.max(0, 1 - 8 * dt);
    if (r.landed && wasAir) {
      p.squash = 0.78; p.land = 0.12; this.fx.dust(p.x, p.y, 4); this.sfx.land();
      if (p.move && (p.move.air || p.move.id === 'axekick')) this.groundPound();
    }
    // ---- gaya jalan
    const sp = Math.abs(p.vx);
    if (p.onGround && sp > 10) {
      const gc = gaitCadence(sp, p.runK, 1);
      p.stride = gc.stride;
      p.walk += Math.PI * sp * dt * gc.duty / Math.max(1.5, gc.stride) * LEG_K;
      const si = Math.floor(p.walk / Math.PI);
      if (si !== p.stepIdx) { p.stepIdx = si; this.sfx.footstep(p.runK); if (p.runK > 0.5) this.fx.dust(p.x - p.facing * 2, p.y, 1, p.facing); }
    } else if (sp <= 10) { p.walk = 0; p.stride = 2.4; }
    // pickup
    for (const k of this.pickups) if (Math.abs(k.x - p.x) < 9 && Math.abs(k.y - p.y) < 14) {
      k.life = 0;
      if (k.kind === 'hp') { this.heal(25); this.texts.add(p.x, p.y - 26, '+25 HP', '#7cff9a', 1, 0.9); }
      else { p.chi = Math.min(100, p.chi + 35); this.texts.add(p.x, p.y - 26, '+CHI', '#5ff0ff', 1, 0.9); }
      this.sfx.pickup();
    }
  }

  private enterDoor(from: Conn, to: Conn) {
    const p = this.player;
    if (p.grab) this.dropHeld();
    p.door = { t: 0, to, out: false }; p.vx = 0; p.phase = 'none'; p.moveKey = null; p.move = null; p.iframes = 1;
    from.openT = 0.6;
    if (from.ch === 'E') this.sfx.beep(); else this.sfx.portal();
  }
  private updateDoorTransit(dt: number) {
    const p = this.player, d = p.door!;
    d.t += dt;
    if (!d.out) {
      p.alpha = Math.max(0, 1 - d.t / 0.3);
      if (d.t >= 0.45) { d.out = true; d.t = 0; p.x = d.to.x; p.y = d.to.yF; p.vy = 0; d.to.openT = 0.6; if (d.to.ch === 'E') { this.sfx.beep(); this.texts.add(d.to.x, d.to.yF - 34, 'DING!', '#ffd166', 1, 0.7); } }
    } else {
      p.alpha = Math.min(1, d.t / 0.25);
      if (d.t >= 0.3) { p.door = null; p.alpha = 1; p.iframes = 0.4; }
    }
  }

  // ---- serangan
  private queueAttack(k: 'L' | 'H', ix = 0) {
    const p = this.player;
    if (p.hurtT > 0 || p.downT > 0 || p.getupT > 0 || p.holdT > 0 || this.exec || this.slam || this.special || this.trick) return;
    if (!p.mouseAim) this.autoFace(ix);
    // MODE N: gerbang 3+ tangan kosong, klik kanan = LOTUS TERSEMBUNYI
    if (k === 'H' && p.weapon === 'fist' && this.gates.on && this.gates.gates >= 3 && !this.gates.lotus && this.gates.lotusCd <= 0 && this.gates.energy >= 14 && !this.slam) {
      const t = this.grabTarget(80);
      if (t) { this.gates.energy -= 14; this.gates.lotusCd = 6; this.startSlam('lotus', t); return; }
    }
    // nunchaku (gaya API bawaan V2): semua klik = rantai Street Fighter
    if (p.weapon === 'nunchaku') { this.br.nunPress(k === 'H', p.aim); return; }
    // FREESTYLE RHYTHM ENGINE: tempo klik memilih gaya (Wing Chun / Black Leg / Kung Fu)
    const bare = p.weapon === 'fist' || (p.weapon === 'axe' && !this.br.lev.held);
    if (k === 'L' && bare && p.onGround && !this.isRunning() && p.dashT <= 0 && p.sinceDash > 0.2) {
      const gap = this.time - p.chainLast;
      p.chainLast = this.time;
      if (gap <= 1.1) { p.rhythm.push(gap); if (p.rhythm.length > 4) p.rhythm.shift(); } else { p.rhythm = []; p.style = 'none'; p.styleStreak = 0; p.flowStep = 0; p.chain = 0; }
      const style = this.classifyRhythm();
      if (style !== 'none') { this.flowMove(style); return; }
    }
    const cur = p.move;
    if (p.phase === 'none' || (p.phase === 'recover' && cur && (cur.bat || p.phaseT < cur.recover * 0.65))) this.startAttackInput(k);
    else { p.buffer = k; p.bufferT = 0.35 / this.tempo; }
  }
  private runBuffer(k: 'L' | 'H') {
    const p = this.player;
    if (p.bufferKey) { const bk = p.bufferKey; p.bufferKey = null; p.seq = ''; this.startAttack(bk); }
    else this.queueAttack(k);
  }
  /** pemetaan jurus per senjata — port langsung dari startAttackInput game V2 */
  private startAttackInput(k: 'L' | 'H') {
    const p = this.player, w = p.weapon, running = this.isRunning(), dash = p.dashT > 0 || p.sinceDash < 0.16;
    if (this.br.isModuleWeapon(w)) return;
    let key = '';
    if (!p.onGround) {
      if (w === 'fist' || w === 'boxing') {
        if (k === 'H') key = this.nearestEnemy(p.x, p.y, 52, p.aim, 2.2) || w === 'boxing' ? 'AIR_H' : 'AIR';
        else key = p.seq === 'AIR1' ? 'AIR2' : p.seq === 'AIR2' ? 'AIR3' : p.seq === 'AIR3' ? 'AIR4' : 'AIR1';
      } else if (w === 'katana') key = 'KDASH';
      else if (w === 'dual') key = 'DDASH';
      else if (w === 'axe') key = this.br.lev.held ? 'ADASH' : 'AIR';
      else if (w === 'bat' || w === 'shotgun') key = 'BDASH';
      else if (w === 'yoyo') key = 'YAIR';
      else return;
      this.startAttack(key);
      return;
    }
    if (w === 'yoyo') {
      if (k === 'L' && running && p.seq === '') key = 'YRUN';
      else { const base = p.seq.startsWith('Y') ? p.seq : 'Y'; const cand = base + k; key = MOVES[cand] ? cand : 'Y' + k; }
    } else if (w === 'boxing') {
      const st = p.boxStance, bx = this.br.box;
      bx.stance = st;
      if (k === 'H') key = bx.nextHeavy();
      else if (running && p.seq === '' && p.tkdCd <= 0) { key = st === 'ali' ? 'BX_SHUFFLE' : st === 'tyson' ? 'BX_ROLLIN' : 'BX_GAZELLE'; p.tkdCd = 1.15; }
      else if (dash) key = st === 'ali' ? 'BX_CROSS' : st === 'tyson' ? 'BX_UPPER' : 'BX_GAZELLE';
      else key = bx.nextLight();
    } else if (w === 'bat' || w === 'shotgun') {
      if (this.time - this.batLastT > 1.1) { this.batFlow = 0; this.batJuggle = 0; }
      this.batLastT = this.time;
      if (k === 'L' && running && p.seq === '' && p.tkdCd <= 0) { key = 'BRUN'; p.tkdCd = 1.3; this.sayP('GRAND SLAM', '#ffb347'); this.sfx.launch(); }
      else if (k === 'L' && dash) key = 'BDASH';
      else if (k === 'H') key = this.batPowerSwing();
      else {
        const air = this.nearestEnemy(p.x, p.y, 38, p.aim, 1.3);
        const down = this.enemies.find((e) => !e.dead && e.alpha > 0.5 && e.state === 'down' && Math.abs(e.x - p.x) < 34 && Math.abs(e.y - p.y) < 8 && Math.sign(e.x - p.x) === p.facing);
        if (air && (air.state === 'air' || !air.onGround)) { this.batJuggle++; if (this.batJuggle >= 4) { key = 'B_SPIKE'; this.batJuggle = 0; } else key = 'B_PEPPER'; }
        else if (down) key = 'SB_POUND';
        else {
          const n = ++this.batFlow;
          if (n % 12 === 0) key = 'B_HOMER';
          else if (n % 4 === 0 || (n > 1 && Math.random() < 0.2)) { const sp = ['SB_KNOB', 'SB_UPPER', 'SB_SMASH', 'BP_HOMER', 'BP_LINE', 'BP_LOFT', 'BP_BACK'].filter((x) => x !== this.batLastSpecial); key = sp[Math.floor(Math.random() * sp.length)]; this.batLastSpecial = key; }
          else key = n % 2 === 1 ? 'SB_F' : 'SB_B';
        }
      }
    } else if ((w === 'axe' && this.br.lev.held) || w === 'dual') {
      const Rk = w === 'axe' ? 'A' : 'D';
      if (k === 'L' && running && p.seq === '' && p.tkdCd <= 0) { key = Rk + 'RUN'; p.tkdCd = w === 'axe' ? 1.5 : 1.2; this.sayP(MOVES[key].name, w === 'axe' ? '#ffb347' : '#bfe8ff'); this.sfx.launch(); }
      else if (k === 'L' && (dash || (running && p.seq === ''))) key = Rk + 'DASH';
      else { const base = p.seq.startsWith(Rk) ? p.seq : Rk; const cand = base + k; key = MOVES[cand] ? cand : Rk + k; }
    } else if (w === 'katana') {
      if (k === 'L' && running && p.seq === '' && p.tkdCd <= 0) { key = 'KRUN'; p.tkdCd = 1.3; this.sayP('IAIJUTSU', '#ffffff'); this.sfx.whoosh(); }
      else if (k === 'L' && (dash || (running && p.seq === ''))) key = 'KDASH';
      else {
        const base = p.seq.startsWith('K') ? p.seq : 'K', cand = base + k;
        key = MOVES[cand] ? cand : 'K' + k;
        if (k === 'L') {
          // KATANA CHAIN VARIATIF V2: kadang 1 tebas + SHEATHE FLASH, kadang 2 + DASH CUT, kadang 3 + HEAVEN SPLITTER
          if (p.seq === '') { const r = Math.random(); p.katanaPlan = r < 0.4 ? 1 : r < 0.7 ? 2 : 3; }
          const nS = p.seq === 'KL' ? 1 : p.seq === 'KLL' ? 2 : p.seq === 'KLLL' ? 3 : 0;
          if (p.katanaPlan === 1 && nS >= 1) key = 'KSHEATH';
          else if (p.katanaPlan === 2 && nS >= 2) key = 'KDASH';
        }
      }
    } else {
      // tangan kosong (juga kapak saat dilempar)
      if (k === 'L' && dash) key = 'DASH';
      else if (k === 'L' && running && p.seq === '') {
        if (p.tkdCd <= 0) { key = 'TKD'; p.tkdCd = 0.9; this.sayP('TAEKWONDO!', '#ffd166'); this.sfx.launch(); } else key = 'RUNPUNCH';
      } else if (k === 'H' && running && p.seq === '') key = p.tkdCd > 0.45 ? 'DASH' : this.runHeavyToggle++ % 2 === 0 ? 'RUNPUNCH' : 'DASH';
      else key = this.pickFreestyle(k);
    }
    if (!MOVES[key]) return;
    this.startAttack(key);
  }
  private startAttack(key: string) {
    const p = this.player, m = MOVES[key];
    if (!m) return;
    const NO_COMBO = ['DASH', 'RUNPUNCH', 'TKD', 'AIR', 'AIR_H', 'CHAIN', 'CHAINEND', 'KRUN', 'KDASH', 'NRUN', 'NDASH', 'ARUN', 'ADASH', 'DRUN', 'DDASH', 'YRUN', 'YAIR', 'BRUN', 'BDASH', 'XRUN', 'XAIR', 'XBEAM', 'KSHEATH'];
    p.moveKey = key; p.move = m; p.phase = 'windup'; p.phaseT = m.windup; p.hitSet.clear(); p.hitTimes.clear();
    p.seq = NO_COMBO.includes(key) ? '' : key;
    p.comboTimer = 0.95; p.dashT = 0; p.parryAnim = 0; p.blocking = false; p.bowDraw = 0; p.holdT = 0; p.runT = 0; p.twirlT = 0; p.buCharging = false;
    // bantuan bidik lembut (V2): sasaran terdekat dalam kerucut arah kursor
    const searchArc = Math.max(1.3, m.arc + 0.7);
    let target = this.nearestEnemy(p.x, p.y, m.range * 1.7 + 12 + (m.travel ? 50 : 0), p.aim, searchArc);
    if (!target) target = this.nearestEnemy(p.x, p.y, 16, p.aim, 2.6);
    if (target) p.aim += angleDiff(Math.atan2(target.y - p.y, target.x - p.x), p.aim) * 0.85;
    const ranged = p.weapon === 'pistol' || p.weapon === 'rifle' || p.weapon === 'shotgun' || p.weapon === 'bow' || p.weapon === 'yoyo';
    const base = Math.cos(p.aim) >= 0 ? 0 : Math.PI;
    if (!m.travel && !m.air && !ranged) p.aim = base;                                   // jarak dekat: rata ke sisi kursor
    else if (m.air && !m.travel) {                                                        // udara: miring maks 0.55 rad ke kursor
      p.aim = base + clamp(angleDiff(p.aim, base), -0.55, 0.55);
      const airT = this.nearestEnemy(p.x, p.y, 44, p.aim, 1.8);
      if (airT && Math.abs(airT.x - p.x) > 10) p.kx += Math.sign(airT.x - p.x) * 28;
    } else if (m.travel) p.aim = base;
    p.attackAim = p.aim;
    p.facing = Math.cos(p.aim) >= 0 ? 1 : -1;
    if (!p.onGround) p.vy = Math.min(p.vy, m.air || m.id === 'axekick' ? -60 : -30);
    if (m.jump && !m.air) { this.fx.dust(p.x, p.y, 5); p.squash = 0.85; }
    if (key === 'TKD') { this.fx.ring(p.x, p.y - 6, 3, 12, '#ffffff', 0.18, 1); this.fx.dust(p.x, p.y, 6, p.facing); }
    // ancang-ancang tangan kosong: merunduk & tertarik ke belakang, lalu meledak maju
    if ((p.weapon === 'fist' || p.weapon === 'boxing') && !m.travel && !m.jump) {
      const heavy = !!m.finisher || m.dmg >= 9 || !!m.knockdown;
      p.squash = heavy ? 0.87 : 0.93; p.kx -= p.facing * (heavy ? 30 : 15);
      this.fx.smoke(p.x, p.y + 1, heavy ? 2 : 1, '#9a9a9a', 13, 0.26);
    }
    if (/^(BX|FP)_/.test(key) && p.weapon === 'fist') this.ippoGuardT = 1.5;
    // MODE X (ONE FOR ALL): kedip ke target terkunci bila di luar jangkauan
    const L = this.lock;
    if (p.ofaOn && L && !L.dead && this.storyOf(L.y) === this.storyOf(p.y)) {
      const d = Math.abs(L.x - p.x), reach = (m.slash?.r ?? m.range) + 4;
      if (d > reach && d < 240) {
        const dir = Math.sign(L.x - p.x) || p.facing;
        for (let i = 1; i <= 5; i++) { const g = this.playerOpts(m.pose, 0.2); g.x = lerp(p.x, L.x - dir * 12, i / 6); this.ghost(g, '#57e6ff'); }
        const nx = L.x - dir * (10 + 4 * L.scale);
        if (!this.solidAt(nx + dir * 4, p.y - 8, true)) { p.x = nx; p.facing = dir; p.aim = p.attackAim = dir > 0 ? 0 : Math.PI; p.iframes = Math.max(p.iframes, 0.12); this.sfx.dash(); this.fx.spark(p.x, p.y - 8, 6, '#57e6ff', 0, Math.PI, 160); }
      }
    }
    if (m.id === 'k_iaijutsu') p.iaiMarks = [];
    if (BLADE_WEAPONS.has(p.weapon)) { const aim = p.facing > 0 ? 0 : Math.PI; p.sheatheT = 0; p.busterRest = 0; p.bladeA = aim + (m.slash ? m.slash.from * p.facing : 0); p.bladePrevA = p.bladeA; p.bladeB = aim - (m.slash ? m.slash.from * p.facing : 0); p.arcDone = false; }
  }
  private isRunning() { const p = this.player; return (p.runT > 0.25 && Math.abs(p.vx) > 40) || p.runK > 0.6; }
  private sayP(text: string, c: string) { const p = this.player; this.texts.add(p.x, p.y - 32, text, c, 1, 0.8); }
  private nearestEnemy(x: number, y: number, maxD: number, aim?: number, arc?: number): Enemy | null {
    let best: Enemy | null = null, bd = maxD;
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.5 || e.state === 'held' || e.state === 'spawn' || e.state === 'door' || Math.abs(e.y - y) > 22) continue;
      const d = Math.hypot(e.x - x, (e.y - y) * 0.6);
      if (d > bd) continue;
      if (aim !== undefined && arc !== undefined && Math.abs(angleDiff(Math.atan2(e.y - y, e.x - x), aim)) > arc) continue;
      bd = d; best = e;
    }
    return best;
  }
  /** tempo klik -> gaya. Butuh 2 jeda konsisten supaya satu klik ganda tidak langsung ganti gaya (port V2) */
  private classifyRhythm(): 'none' | 'wingchun' | 'blackleg' | 'kungfu' {
    const p = this.player, r = p.rhythm;
    if (r.length < 2) return 'none';
    const cls = (x: number) => (x >= 0.06 && x < 0.3 ? 'wingchun' : x >= 0.3 && x < 0.62 ? 'blackleg' : x >= 0.62 && x <= 1.05 ? 'kungfu' : 'none');
    const ca = cls(r[r.length - 1]), cb = cls(r[r.length - 2]);
    if (ca === 'none') return 'none';
    if (ca === p.style) return ca;
    if (ca === cb) return ca;
    return p.style !== 'none' && p.styleStreak > 0 ? p.style : 'none';
  }
  private flowMove(style: 'wingchun' | 'blackleg' | 'kungfu') {
    const p = this.player;
    const label = style === 'wingchun' ? 'WING CHUN' : style === 'blackleg' ? 'BLACK LEG' : 'KUNG FU';
    const switching = p.style !== style && p.style !== 'none';
    if (p.style !== style) { p.style = style; p.flowStep = 0; p.styleStreak = 0; p.chain = 0; if (switching) this.sayP(label, '#ffd166'); }
    p.styleStreak++;
    if (p.styleStreak === 2) this.sayP(style === 'blackleg' ? 'BLACK LEG STYLE' : label, '#ffd166');
    const target = this.nearestEnemy(p.x, p.y, 34, p.aim, 1.5) ?? this.nearestEnemy(p.x, p.y, 22, p.aim, 2.8);
    const nearlyDead = !!target && !target.boss && target.hp <= Math.max(3, target.maxHp * 0.22);
    const bossSoft = !!target && target.boss && target.structure >= target.def.structure * 1.4 * 0.6;
    const reset = () => { p.phase = 'none'; p.buffer = null; p.bufferKey = null; p.seq = ''; p.chain = 0; };
    if (style === 'wingchun') {
      p.wcCount++;
      if (p.wcCount % 9 === 0 && p.styleStreak >= 4) { reset(); this.ippoGuardT = 1.5; this.startAttack('FP_DEMPSEY'); this.sayP('DEMPSEY ROLL', '#7ce7ff'); return; }
      if (p.wcCount % 5 === 0 && p.styleStreak >= 3) {
        const mix = ['KV2', 'HL', 'S1', 'KV3', 'LH', 'S2', 'BX_BODY', 'BX_SHOVEL', 'BX_CHECK', 'BX_UPPER'];
        reset(); this.startAttack(mix[Math.floor(Math.random() * mix.length)]);
        return;
      }
      this.chainPunch(); return;
    }
    if (switching) { reset(); this.startAttack(style === 'blackleg' ? 'S4' : 'HH'); return; }
    const flows: Record<'blackleg' | 'kungfu', string[]> = {
      blackleg: ['S1', 'S2', 'LH', 'S3', 'BX_BODY', 'S4', 'H', 'S5', 'LLL', 'BX_SHOVEL', 'S1', 'HL', 'S6', 'KF2', 'S7', 'S8'],
      kungfu: ['H', 'KF1', 'FX_SHOCKPALM', 'BX_JAB2', 'KV2', 'FX_HOOKS', 'BX_CROSS', 'FX_RISEELBOW', 'FX_CLAW', 'LH', 'KF2', 'BX_OVER', 'HL', 'LLLH', 'KV3', 'BX_UPPER', 'HHL', 'LHH', 'FP_GAZELLE', 'LLLLH', 'HLL', 'S3', 'FP_HEART'],
    };
    const flow = flows[style];
    let key = flow[p.flowStep % flow.length];
    if ((nearlyDead || bossSoft) && p.styleStreak >= 2) key = style === 'blackleg' ? (p.flowStep % 2 ? 'S8' : 'S5') : (p.flowStep % 2 ? 'LLLH' : 'HHL');
    p.flowStep++;
    if (/^(BX|FP)_/.test(key)) this.ippoGuardT = 1.5;
    const cur = p.move;
    if (p.phase === 'windup' || (p.phase === 'active' && cur && p.phaseT > cur.active * 0.5)) { p.buffer = 'L'; p.bufferT = 0.35; p.bufferKey = key; return; }
    p.phase = 'none'; p.buffer = null; p.seq = '';
    if (!MOVES[key]) return;
    this.startAttack(key);
    if (MOVES[key].finisher) this.sayP(MOVES[key].name, '#ffd166');
  }
  /** satu mata rantai Wing Chun: tinju bergantian langsung tanpa jeda; tutup saat sasaran hampir habis */
  private chainPunch() {
    const p = this.player;
    p.chain++; p.chainSide *= -1;
    const target = this.nearestEnemy(p.x, p.y, 30, p.aim, 1.4) ?? this.nearestEnemy(p.x, p.y, 20, p.aim, 2.8);
    if (target) {
      const nearlyDead = target.hp <= Math.max(3, target.maxHp * 0.22) && !target.boss;
      const bossSoft = target.boss && target.structure >= target.def.structure * 1.4 * 0.6;
      if (nearlyDead || bossSoft || p.chain >= 24) { p.chain = 0; this.startAttack('CHAINEND'); this.sayP('WING CHUN FINISH', '#ffd166'); return; }
    }
    p.phase = 'none'; p.buffer = null; p.seq = '';
    this.startAttack('CHAIN');
    this.fx.lines(p.x + p.facing * 8, p.y - 9, 2, '#ffffff', p.facing > 0 ? 0 : Math.PI, 220);
    if (p.chain === 6) this.sayP('CHAIN PUNCH!', '#ffd166');
    if (p.chain > 0 && p.chain % 10 === 0) this.sayP(`${p.chain} CHAIN`, '#ffe66d');
  }
  private pickIppo(key: string): string {
    this.fistLastKey = key; this.ippoGuardT = 1.5;
    const mv = MOVES[key];
    if (mv && mv.finisher) { this.fistStep = 0; this.ippoPlan = []; }
    return key;
  }
  /** FREESTYLE V2: tangan & kaki berganti sesuai situasi (jarak, lawan jatuh, lawan sekarat) */
  private pickFreestyle(k: 'L' | 'H'): string {
    const p = this.player;
    if (this.time - this.fistLastT > 1.0) { this.fistStep = 0; this.fistHist = []; this.ippoPlan = []; this.ippoI = 0; }
    this.fistLastT = this.time;
    const step = ++this.fistStep;
    const target = this.nearestEnemy(p.x, p.y, 34, p.aim, 1.5) ?? this.nearestEnemy(p.x, p.y, 22, p.aim, 2.8);
    const d = target ? dist(p.x, p.y, target.x, target.y) : 99;
    const down = !!target && target.state === 'down';
    const weak = !!target && !target.boss && target.hp <= Math.max(3, target.maxHp * 0.25);
    if (this.ippoPlan.length && this.ippoI < this.ippoPlan.length && k === 'L') return this.pickIppo(this.ippoPlan[this.ippoI++]);
    if (k === 'L' && step === 1 && d < 40 && Math.random() < 0.42) {
      this.ippoPlan = IPPO_PLANS[Math.floor(Math.random() * IPPO_PLANS.length)]; this.ippoI = 1;
      if (this.time - this.ippoSayT > 4) { this.ippoSayT = this.time; this.sayP('IPPO COMBO', '#7ce7ff'); }
      return this.pickIppo(this.ippoPlan[0]);
    }
    if (k === 'H' && Math.random() < 0.4) { const pool = IPPO_HEAVY.filter((x) => x !== this.fistLastKey); return this.pickIppo(pool[Math.floor(Math.random() * pool.length)]); }
    const HANDS = { light: ['L', 'LL', 'LLL', 'LHL', 'FX_TRIPLE', 'FX_STRAIGHT'], mid: ['H', 'LH', 'LHH', 'KF1', 'KF2', 'FX_SHOCKPALM', 'FX_RISEELBOW', 'FX_HOOKS', 'FX_CLAW'], heavy: ['LLLH', 'LLLLH', 'KF1', 'KF2', 'FX_DROPFIST', 'FX_SHOCKPALM'] };
    const FEET = { light: ['KV1', 'KV2', 'HL', 'LLLL', 'S1', 'S2', 'S3'], mid: ['KV3', 'HLL', 'LLH', 'S4', 'KV4', 'FX_KNEES'], heavy: ['HHL', 'HLH', 'S5', 'S6', 'S8', 'KVH', 'KV5', 'LLLLL', 'HH'] };
    let tier: 'light' | 'mid' | 'heavy' = k === 'H' ? (step >= 3 ? 'heavy' : 'mid') : step <= 2 ? 'light' : step === 3 ? 'mid' : 'heavy';
    if (weak && step >= 2) tier = 'heavy';
    const hist = this.fistHist, l1 = hist[hist.length - 1], l2 = hist[hist.length - 2];
    let foot: boolean;
    if (l1 && l1 === l2) foot = l1 === 'h';
    else if (l1) foot = Math.random() < 0.72 ? l1 === 'h' : l1 === 'f';
    else foot = Math.random() < 0.4;
    let pool: string[];
    if (down) { pool = ['KV3', 'KF2', 'HLL', 'S6']; foot = true; }
    else pool = (foot ? FEET : HANDS)[tier];
    const reach = pool.filter((x) => MOVES[x] && MOVES[x].range + 8 >= d && x !== this.fistLastKey);
    const use = reach.length ? reach : pool.filter((x) => MOVES[x] && x !== this.fistLastKey);
    const key = (use.length ? use : pool)[Math.floor(Math.random() * (use.length ? use.length : pool.length))];
    hist.push(foot ? 'f' : 'h'); if (hist.length > 4) hist.shift();
    this.fistLastKey = key;
    if (tier === 'heavy' || MOVES[key]?.finisher) { this.sayP(MOVES[key]?.name ?? key, '#ffd166'); this.fistStep = 0; }
    return key;
  }
  private batPowerSwing(): string {
    const p = this.player;
    const air = this.nearestEnemy(p.x, p.y, 40, p.aim, 1.3);
    const down = this.enemies.find((e) => !e.dead && e.alpha > 0.5 && e.state === 'down' && Math.abs(e.x - p.x) < 34 && Math.abs(e.y - p.y) < 8 && Math.sign(e.x - p.x) === p.facing);
    let key: string;
    if (air && (air.state === 'air' || !air.onGround) && Math.random() < 0.65) key = 'B_SPIKE';
    else if (down && Math.random() < 0.7) key = 'SB_POUND';
    else { const pool = ['BP_HOMER', 'BP_LINE', 'BP_BACK', 'BP_LOFT', 'BP_HOMER'].filter((x) => x !== this.batLastPower); key = pool[Math.floor(Math.random() * pool.length)]; }
    this.batLastPower = key;
    return key;
  }
  // ============================== KONTROL GAYA V2 ==============================
  setCtrl(c: 'v2' | 'kbd') { this.ctrl = c; try { localStorage.setItem('office_ctrl', c); } catch { /* */ } this.pushUI(true); }
  get lightKeys() { return this.ctrl === 'v2' ? ['Mouse0'] : ['KeyJ', 'Mouse0']; }
  get heavyKeys() { return this.ctrl === 'v2' ? ['Mouse2'] : ['KeyK', 'Mouse2']; }
  private weaponCodes(w: WeaponKind) { return w === 'boxing' ? (this.ctrl === 'v2' ? ['KeyJ', 'KeyB'] : ['KeyB']) : [WEAPONS[w].code]; }
  mouseOn() { return this.ctrl === 'v2' && this.mouseIn && this.mouseKind === 'mouse'; }
  mouseWorld(): Vec { const c = this.cam, z = c.zoom; return { x: c.x - VW / (2 * z) + c.sx + this.mouseSX / z, y: c.y - VH / (2 * z) + c.sy + this.mouseSY / z }; }
  private onMouseMove = (e: PointerEvent) => {
    const r = this.canvas.getBoundingClientRect(); if (!r.width) return;
    this.mouseSX = ((e.clientX - r.left) / r.width) * VW; this.mouseSY = ((e.clientY - r.top) / r.height) * VH;
    this.mouseAt = this.real; this.mouseIn = true; this.mouseKind = e.pointerType || 'mouse';
  };
  private onMouseLeave = () => { this.mouseIn = false; };
  /** arah bidik = kursor mouse (V2). Badan menghadap kursor; tangan kosong saat berlari menghadap arah lari. */
  private updateAim() {
    const p = this.player, mo = this.mouseOn(), Wd = WEAPONS[p.weapon];
    const ranged = Wd.kind === 'gun' || Wd.kind === 'bow';
    p.mouseAim = mo;
    if (mo) { const mw = this.mouseWorld(); p.aim = Math.atan2(mw.y - (p.y - 9), mw.x - p.x); }
    else p.aim = ranged ? toWorld(p.aimRel, p.facing) : (p.facing > 0 ? 0 : Math.PI);
    if ((p.phase === 'windup' || p.phase === 'active') && p.move && !p.move.yoyo) p.aim = p.attackAim;
    if (mo && !p.climbing) {
      const travel = p.weapon === 'fist' && p.phase === 'none' && p.dashT <= 0 && Math.abs(p.vx) > 6 && !this.trick;
      if (travel) { if (Math.abs(p.vx) > 4) p.facing = p.vx >= 0 ? 1 : -1; }
      else p.facing = Math.cos(p.aim) >= 0 ? 1 : -1;
      p.bodyAim = travel || p.phase === 'none' ? (p.facing > 0 ? 0 : Math.PI) : p.aim;
      p.aimRel = clamp(angleDiff(p.aim, p.facing > 0 ? 0 : Math.PI) * p.facing, -1.5, 1.5);
    } else p.bodyAim = p.phase === 'none' ? (p.facing > 0 ? 0 : Math.PI) : p.aim;
  }
  /** BUSTER V2: tahan kiri = isi tenaga (penuh = BLADE BEAM), ketuk = kombo X1-X5, kanan = XH */
  private busterInput(dt: number, lightHit: boolean, heavyHit: boolean, lh: boolean) {
    const p = this.player;
    if (heavyHit && p.onGround) { p.buCharging = false; p.buCharge = 0; this.queueAttack('H'); }
    if (lightHit && p.onGround) { if (p.phase !== 'none') this.queueAttack('L'); else { p.buCharging = true; p.buHold = 0; p.buCharge = 0; } }
    if (!lightHit && !p.onGround && lightHit) this.queueAttack('L');
    if (!p.buCharging) return;
    if (p.phase !== 'none' || !p.onGround || p.hurtT > 0) { p.buCharging = false; p.buCharge = 0; return; }
    if (lh) {
      p.buHold += dt;
      if (p.buHold > 0.16) {
        const before = p.buCharge;
        p.buCharge = Math.min(1, p.buCharge + dt / 0.6);
        if (Math.floor(before * 8) !== Math.floor(p.buCharge * 8) && p.buCharge < 1) this.sfx.busterHum(p.buCharge);
        if (Math.random() < 0.5) this.fx.spark(p.x + rnd(-8, 8), p.y - rnd(0, 14), 1, MAKO, -Math.PI / 2, 0.4, 60 + 80 * p.buCharge);
        if (before < 1 && p.buCharge >= 1) { this.sfx.focus(); this.flash = Math.max(this.flash, 0.12); this.fx.ring(p.x, p.y - 8, 3, 18, '#c9fff0', 0.25, 1); this.sayP('BLADE BEAM SIAP', '#c9fff0'); }
      }
    } else {
      const full = p.buCharge >= 1;
      p.buCharging = false; p.buCharge = 0;
      if (full) { this.br.bu.swing(this.time); p.seq = ''; this.startAttack('XBEAM'); } else this.queueAttack('L');
    }
  }
  /** TRIK V2: pistol/senapan = freestyle trick shot, busur = akrobat multi-panah (klik kanan) */
  private startTrick(kind: 'gun' | 'bow') {
    const p = this.player;
    const styles: [string, Pose][] = kind === 'gun' ? [['FLIP', 'bow_flip'], ['SLIDE', 'bow_slide'], ['ROLL', 'bow_roll'], ['AIR SHOT', 'bow_air'], ['KNEEL', 'bow_kneel'], ['LEAN', 'bow_lean'], ['AKIMBO', 'gun_akimbo']] : [['FLIP', 'bow_flip'], ['SLIDE', 'bow_slide'], ['ROLL', 'bow_roll'], ['AIR', 'bow_air'], ['MULTI', 'bow_multi']];
    const [style, pose] = styles[Math.floor(Math.random() * styles.length)];
    this.trick = { kind, style, pose, t: 0, dur: kind === 'gun' ? 0.62 : 0.72, shots: kind === 'gun' ? (style === 'AKIMBO' ? 6 : 4) : 3, fired: 0 };
    p.iframes = Math.max(p.iframes, 0.65); p.twirlT = 0; p.phase = 'none'; p.move = null; p.moveKey = null;
    if (style === 'SLIDE' || style === 'ROLL') p.vx = p.facing * 230;
    if ((style === 'FLIP' || style.startsWith('AIR')) && p.onGround) { p.vy = -270; p.onGround = false; }
    this.sayP(`${kind === 'gun' ? 'TRIK' : 'AKROBAT'}: ${style}`, kind === 'gun' ? '#ffd166' : '#c8f08f');
    if (kind === 'gun') this.sfx.spinCock(); else this.sfx.bowNock();
  }
  private updateTrick(dt: number) {
    const Tk = this.trick!, p = this.player;
    Tk.t += dt;
    if (Tk.kind === 'bow') p.bowDraw = 0.9;
    if (Math.random() < 0.5) this.ghost(this.playerOpts(Tk.pose, Math.min(1, Tk.t / Tk.dur)), Tk.kind === 'gun' ? '#ffd166' : '#c8f08f');
    const due = Math.floor((Tk.t / Tk.dur) * (Tk.shots + 1));
    while (Tk.fired < Math.min(Tk.shots, due)) {
      Tk.fired++;
      const tg = this.nearestEnemy(p.x, p.y, 260);
      const sx = p.x + p.facing * 4, sy = p.y - 10;
      const ang = tg ? Math.atan2(tg.y - 9 * tg.scale - sy, tg.x - sx) : (p.facing > 0 ? 0 : Math.PI) + (Math.random() - 0.5) * 0.3;
      const c = Math.cos(ang), sn = Math.sin(ang);
      if (Tk.kind === 'gun') {
        const G = WEAPONS[p.weapon].gun!;
        this.bullets.push({ x: sx + c * 9, y: sy + sn * 9, vx: c * G.speed, vy: sn * G.speed, life: 1, dmg: G.dmg * 1.3 * this.gates.dmgMul, mine: true, kb: G.kb, kind: 'bullet' });
        this.sfx.shot(p.weapon === 'rifle' ? 'rifle' : 'pistol', 0); this.fx.impact(sx + c * 10, sy + sn * 10, 4, '#ffd166'); this.addLight(sx, sy, 46, '#ffd27f', 0.07); p.recoil = 1;
      } else {
        this.bullets.push({ x: sx + c * 8, y: sy + sn * 8, vx: c * 520, vy: sn * 520, life: 2, dmg: 16 * this.gates.dmgMul, mine: true, kb: 260, kind: 'arrow', power: 0.85 });
        this.sfx.bowRelease(0.85);
      }
      if (tg) p.facing = Math.sign(tg.x - p.x) || p.facing;
    }
    if (Tk.t >= Tk.dur) { this.trick = null; this.trickCd = Tk.kind === 'gun' ? 1.1 : 1.4; p.bowDraw = 0; }
  }
  private poseT(): number {
    const p = this.player, m = p.move;
    if (!m) return 0;
    if (p.phase === 'windup') return 0.3 * (1 - p.phaseT / m.windup);
    if (p.phase === 'active') return 0.3 + 0.3 * (1 - p.phaseT / m.active);
    if (p.phase === 'recover') return 0.6 + 0.4 * (1 - p.phaseT / m.recover);
    return 0;
  }
  private updateAttack(dt: number) {
    const p = this.player, W = WEAPONS[p.weapon];
    const aim = p.facing > 0 ? 0 : Math.PI, f = p.facing;
    p.bladePrevA = p.bladeA;
    p.sheatheT = Math.max(0, p.sheatheT - dt); p.busterRest = Math.max(0, p.busterRest - dt);
    if (p.phase === 'none' || !p.move) {
      // siaga: bilah kembali mengarah ke depan (chudan) — persis updateKatana asli
      p.bladeA += angleDiff(aim, p.bladeA) * Math.min(1, dt * 18);
      if (p.weapon === 'bat') { p.batTwirlCd -= dt; p.batTwirl = Math.max(0, p.batTwirl - dt); if (p.batTwirlCd <= 0 && p.batTwirl === 0 && Math.abs(p.vx) < 10 && p.onGround) { p.batTwirl = 0.6; p.batTwirlCd = 6 + Math.random() * 4; this.sfx.swing(1.3); } }
      if (p.seq) { p.comboTimer -= dt; if (p.comboTimer <= 0) p.seq = ''; }
      if (p.buffer && p.bufferT > 0) { const k = p.buffer as 'L' | 'H'; p.buffer = null; this.runBuffer(k); }
      return;
    }
    const m = p.move;
    const spd = this.tempo * this.gates.atkMul * (p.weapon === 'boxing' ? BOX_STANCES[p.boxStance].speed : 1) * (m.buster ? this.br.bu.speed : 1);
    p.phaseT -= dt * spd;
    let resolve = false;
    if (p.phase === 'windup' && p.phaseT <= 0) {
      p.phase = 'active'; p.phaseT = m.active;
      if (p.onGround && !m.travel) p.vx += p.facing * m.lunge * 0.9;
      if (m.travel) p.vx = p.facing * m.travel * 0.8 * this.tempo;
      if (m.jump && p.onGround) { p.vy = -m.jump * 11; p.onGround = false; }
      if (m.air) { p.vx = p.facing * 250; p.vy = 230; }
      if (m.id === 'axekick' && !p.onGround) p.vy = 320;
      if (m.buster) this.br.bu.swing(this.time);
      this.swingSound(m);
      if (W.kind === 'fist' || W.kind === 'glove' || W.kind === 'gun' || W.kind === 'bow') this.fx.lines(p.x + p.facing * 8, p.y - 9, m.finisher ? 5 : 3, '#ffffff', aim, m.finisher ? 320 : 240);
      if (m.travel || m.finisher) this.ghost(this.playerOpts(m.pose, 0.42), m.finisher ? '#ffd166' : W.trail);
      if (m.id === 'sweep' || m.id === 'dragontail') { this.fx.dust(p.x, p.y, 6); this.fx.ring(p.x, p.y - 1, 4, m.range, '#ffffff', 0.2, 1); }
      if (m.showName && !m.travel) this.texts.add(p.x, p.y - 30, m.name, m.finisher ? '#ffd166' : W.color, 1, 0.8);
      if (m.id === 'bu_beam' || p.moveKey === 'XBEAM') this.fireBeam();
    } else if (p.phase === 'active') {
      if (m.travel) { p.vx = p.facing * m.travel * 0.8 * this.tempo; p.afterT -= dt; if (p.afterT <= 0) { p.afterT = 0.04; this.ghost(this.playerOpts(m.pose, this.poseT()), m.katana ? '#bfe8ff' : W.trail); } }
      resolve = true;
      if ((m.id === 'gd_taishan' || m.id === 'bu_braver') && this.poseT() >= 0.45 && !p.hitSet.has(-1)) { p.hitSet.add(-1); this.groundShock(); }
      if (p.phaseT <= 0) { p.phase = 'recover'; p.phaseT = m.recover; if (m.travel) { p.vx *= 0.35; if (m.showName) this.texts.add(p.x, p.y - 30, m.name, m.finisher ? '#ffd166' : W.color, 1, 0.8); } if (m.id === 'tk_silent' || m.id === 'k_iaijutsu') p.iaiT = 0.34; }
    } else if (p.phase === 'recover' && p.phaseT <= 0) {
      p.phase = 'none'; p.moveKey = null; p.move = null;
      if (p.weapon === 'katana' && (m.finisher || m.id === 'k_iaijutsu')) { p.sheatheT = 0.45; this.sfx.sheathe(); }
      if (m.buster && m.finisher) p.busterRest = 1.2;
      if (p.buffer && p.bufferT > 0) { const k = p.buffer as 'L' | 'H'; p.buffer = null; this.runBuffer(k); }
      return;
    }
    // ---- SUDUT BILAH: rumus updateKatana asli (windup menunggu di sudut awal, aktif menyapu from->to, recover kembali)
    if (m.slash && BLADE_WEAPONS.has(p.weapon)) {
      const s = m.slash, pt = this.poseT();
      const k = pt < 0.3 ? 0 : pt < 0.6 ? (pt - 0.3) / 0.3 : 1;
      const ease = k < 1 ? 1 - Math.pow(1 - k, 2.2) : 1;
      const rel = s.from + (s.to - s.from) * ease;
      const settle = pt > 0.6 ? clamp((pt - 0.6) / 0.4, 0, 1) : 0;
      p.bladeA = aim + rel * f * (1 - settle);
      p.bladeB = aim - rel * f * (1 - settle);
      if (m.id === 'k_heaven' || m.id === 'k_thrust' || m.id === 'k_iaijutsu') p.bladeA = aim + (m.id === 'k_heaven' ? (pt < 0.3 ? -1.4 * f * (1 - pt / 0.3) - 0.3 * f : 0.4 * f * settle) : 0);
      // busur tebasan asli (Katana.addArc / Buster.addSlash)
      if (pt >= 0.3 && pt < 0.42 && !p.arcDone && s.from !== s.to) {
        const sk = solvePose(this.playerOpts(m.pose, pt)), hx = p.x + sk.fhand.x, hy = p.y + sk.fhand.y;
        const col = m.buster ? this.br.bu.trailColor() : m.axe || m.bat ? '#ffd27f' : '#bfe8ff';
        if (m.buster) {
          this.br.bu.addSlash(hx, hy, s.r, aim + s.from * f, aim + s.to * f, col, 5 + 1.5 * this.br.bu.momentum, s.lift ?? 0, m.rehit ? 0.32 : 0.24);
          this.br.bu.addSlash(hx, hy, s.r * 0.86, aim + s.from * f + 0.12, aim + s.to * f - 0.1, '#c9fff0', 2, s.lift ?? 0, 0.18, 0.52);
        } else this.br.katana.addArc(hx, hy, s.r, aim + s.from * f, aim + s.to * f, col, s.lift ?? 0, m.rehit ? 0.3 : 0.22);
        if (m.dual) { const bx = p.x + sk.bhand.x, by = p.y + sk.bhand.y; this.br.katana.addArc(bx, by, s.r, aim - s.from * f, aim - s.to * f, col, s.lift ?? 0, 0.22); }
        if (!m.rehit) p.arcDone = true;
      }
      if (m.rehit && pt >= 0.3 && pt < 0.6 && Math.random() < 0.5 && Math.abs(p.bladeA - p.bladePrevA) > 0.2) {
        const sk = solvePose(this.playerOpts(m.pose, pt)), hx = p.x + sk.fhand.x, hy = p.y + sk.fhand.y;
        if (m.buster) this.br.bu.addSlash(hx, hy, s.r * 0.95, p.bladePrevA, p.bladeA, this.br.bu.trailColor(), 3, 0, 0.14);
        else this.br.katana.addArc(hx, hy, s.r * 0.95, p.bladePrevA, p.bladeA, '#bfe8ff', 0, 0.12);
      }
      if (m.id === 'k_iaijutsu' && p.phase === 'active') this.ghost(this.playerOpts('k_iaijutsu', 0.5), '#bfe8ff');
    }
    if (resolve) this.resolveMelee(m);
  }
  private strikePoint(m: Move): Vec {
    const p = this.player;
    const sk = solvePose(this.playerOpts(m.pose, this.poseT()));
    let j: Vec;
    switch (m.limb) {
      case 'bhand': j = sk.bhand; break;
      case 'ffoot': case 'sweep': j = sk.ffoot; break;
      case 'bfoot': j = sk.bfoot; break;
      case 'both': j = { x: (sk.fhand.x + sk.bhand.x) / 2, y: (sk.fhand.y + sk.bhand.y) / 2 }; break;
      case 'body': j = sk.hip; break;
      default: j = sk.fhand;
    }
    return { x: p.x + j.x, y: p.y + j.y };
  }
  private resolveMelee(m: Move) {
    const p = this.player;
    const ps = this.storyOf(p.y);
    const activeK = 1 - p.phaseT / m.active;
    const pt = this.poseT();
    const blade = BLADE_WEAPONS.has(p.weapon) && (m.limb === 'blade' || m.limb === 'blade2');
    const yoyo = m.limb === 'yoyo' && p.weapon === 'yoyo';
    let segs: { base: Vec; tip: Vec }[] = [];
    if (blade) { segs = this.br.bladeSegs(m, pt, p.bladePrevA, p.bladeA, false); if (m.limb === 'blade2') segs = segs.concat(this.br.bladeSegs(m, pt, p.bladeB, p.bladeB, true)); }
    else if (yoyo) segs = [this.br.yoyoSeg(m)];
    const pt0 = segs.length ? segs[segs.length - 1].tip : this.strikePoint(m);
    for (const bm of this.bombs) if (!bm.mine && Math.hypot(bm.x - pt0.x, bm.y - 3 - pt0.y) < 13) { bm.mine = true; bm.vx = p.facing * 280; bm.vy = -170; bm.fuse = Math.max(bm.fuse, 0.6); this.sfx.parry(); this.texts.add(bm.x, bm.y - 12, 'BALIK!', '#ffd166', 1, 0.6); }
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.45 || e.state === 'door' || (this.storyOf(e.y) !== ps && Math.abs(e.y - p.y) > 20)) continue;
      if (m.id === 'tk_silent' || m.id === 'k_iaijutsu') {
        if (Math.abs(e.x - p.x) < 13 * e.scale && Math.abs(e.y - p.y) < 20 && !p.iaiMarks.includes(e)) {
          p.iaiMarks.push(e); e.state = 'stagger'; e.stateT = 1.4; e.vx = 0; e.atk = null; this.releaseToken(e);
          this.cuts.push({ x: e.x, y: e.y - 9 * e.scale, life: 0.6, max: 0.6 }); this.sfx.slash(1.5);
        }
        continue;
      }
      const last = p.hitTimes.get(e.id);
      if (p.hitSet.has(e.id) && !(m.rehit && last !== undefined && this.time - last >= m.rehit)) continue;
      const lying = e.state === 'down' || e.state === 'getup';
      const top = lying ? e.y - 5 : e.y - BODY_H * e.scale;
      let ok: boolean; let contact = pt0;
      if (segs.length) {
        // GEOMETRI ASLI: segmen bilah (tangan -> ujung, foreshortening 0.6 seperti bladeSeg) vs garis tubuh musuh
        const ca = lying ? { x: e.x - 8 * e.scale, y: e.y - 2 } : { x: e.x, y: top }, cb = lying ? { x: e.x + 8 * e.scale, y: e.y - 2 } : { x: e.x, y: e.y - 1 };
        let best = 1e9, bi = 0;
        for (let i = 0; i < segs.length; i++) { const dd = segSeg(segs[i].base, segs[i].tip, ca, cb); if (dd < best) { best = dd; bi = i; } }
        ok = best <= (yoyo ? m.hitR * 0.8 : m.hitR * 0.55) + 3 * e.scale;
        const sd = Math.sign(e.x - p.x) || p.facing;
        contact = { x: e.x - sd * 3 * e.scale, y: clamp((segs[bi].base.y + segs[bi].tip.y) / 2, top + 2, e.y - 3) };
      } else {
        const segD = lying ? Math.hypot(Math.max(0, Math.abs(pt0.x - e.x) - 8 * e.scale), pt0.y - (e.y - 2)) : Math.hypot(pt0.x - e.x, pt0.y - clamp(pt0.y, top, e.y - 1));
        ok = segD <= m.hitR + 3.5 * e.scale + 2;
        const fx = m.arc >= Math.PI - 0.01 ? Math.abs(e.x - p.x) : (e.x - p.x) * p.facing;
        if (!ok && activeK < 0.85 && fx > -4 && fx < m.range + 4 * e.scale && pt0.y > top - 6 && pt0.y < e.y + 4 && Math.abs(e.y - p.y) < 22) ok = true;
      }
      if (lying && !(m.id === 'sweep' || m.id === 'axekick' || m.id === 'dragontail' || m.knockdown || pt0.y > e.y - 8)) ok = false;
      if (!ok) continue;
      p.hitSet.add(e.id); p.hitTimes.set(e.id, this.time);
      this.hitEnemy(e, m, contact);
    }
    for (const pr of this.props) {
      if (pr.broken || Math.abs(pr.x + 8 - pt0.x) > 9 || pt0.y < pr.yF - pr.h - 2 || pt0.y > pr.yF + 2 || pr.shake > 0.15) continue;
      pr.shake = 0.25;
      if (m.dmg >= 5 || blade) this.damageProp(pr, p.facing, 2); else this.sfx.hit();
    }
  }
  private hitEnemy(e: Enemy, m: Move, pt: Vec, dirOverride?: number, _mod = false) {
    const p = this.player;
    const dir = dirOverride ?? p.facing;
    // MASTER bisa menangkis & mengadu pukulan
    if (!this.allyHitting && e.kind === 'master' && e.state !== 'hurt' && e.state !== 'air' && e.state !== 'down' && e.state !== 'dizzy' && e.state !== 'stagger') {
      if (e.state === 'attack' && Math.sign(p.x - e.x) === e.facing && Math.abs(p.x - e.x) < 34) { this.startClash(e); return; }
      if ((e.state === 'idle' || e.state === 'block') && e.blockCd <= 0 && Math.random() < 0.42) {
        e.state = 'block'; e.stateT = 0.32; e.blockCd = 0.25; e.facing = -dir;
        this.fx.spark(pt.x, pt.y, 10, '#ffd166', dir > 0 ? Math.PI : 0, 0.9, 200); this.fx.impact(pt.x, pt.y, 5, '#ffd166');
        this.sfx.parry(); this.hitstop = Math.max(this.hitstop, 0.05); this.texts.add(e.x, e.y - 26, 'DITANGKIS!', '#ffd166', 1, 0.6);
        p.vx = -dir * 70;
        if (Math.random() < 0.6) { e.atkCd = 0; e.blockCd = 0.6; }
        return;
      }
    }
    if (!this.allyHitting && e.kind === 'shield' && (e.state === 'idle' || e.state === 'hurt' || e.state === 'block') && Math.sign(p.x - e.x) === e.facing && !(m.finisher || m.dmg >= 8 || (m.knockdown && m.dmg >= 5))) {
      e.structure += m.structure * 0.7;
      this.fx.spark(pt.x, pt.y, 8, '#cfe3ff', dir > 0 ? Math.PI : 0, 0.8, 200); this.fx.flash(pt.x, pt.y, 2); this.sfx.parry();
      this.hitstop = Math.max(this.hitstop, 0.035); if (p.onGround) p.vx = -dir * 50;
      if (e.structure >= e.def.structure * (e.boss ? 2 : 1)) { e.structure = 0; e.state = 'stagger'; e.stateT = 1.3; e.atk = null; this.releaseToken(e); this.texts.add(e.x, e.y - 28, 'PERISAI JEBOL!', '#ffd166', 1, 0.9); this.sfx.stagger(); }
      else if (this.time - (e.blockMsg ?? -9) > 0.6) { e.blockMsg = this.time; this.texts.add(e.x, e.y - 26, 'TERTAHAN', '#cfe3ff', 1, 0.5); }
      return;
    }
    let dmg = m.dmg * this.gates.dmgMul * (p.weapon === 'boxing' ? BOX_STANCES[p.boxStance].power : 1);
    const kb = m.kb * this.gates.kbMul;
    if (p.counterT > 0) { dmg *= 2; p.counterT = 0; this.texts.add(e.x, e.y - 30, 'COUNTER!', '#ff3bf2', 1, 0.8); this.zoomPunch(1.95); }
    if (e.dizzy > 0) dmg *= 1.5;
    if (e.state === 'down') dmg *= 0.6;
    e.hp -= dmg; e.flash = 0.1;
    e.structure += m.structure * (e.state === 'stagger' ? 1.4 : 1);
    const heavy = !!m.finisher || m.dmg >= 5 || m.knockdown;
    this.hitstop = Math.max(this.hitstop, m.hitstop * (heavy ? 1.25 : 1));
    this.shake(m.shake * 0.7);
    const a = dir > 0 ? 0 : Math.PI;
    this.hitFx(e.x, e.y, e.scale, pt, dir, { heavy, blood: Math.round(2 + m.dmg * 1.2) + (m.bleed ? 5 : 0), power: 110 + kb * 0.3 });
    if (heavy) this.zoomPunch(BASE_ZOOM + 0.08);
    this.hitSound(m, heavy);
    this.addOfa(1.2 + m.dmg * 0.4);
    this.texts.hit(pt.x, pt.y - 6, ['POW!', 'BAM!', 'WHAM!', 'CRACK!'][Math.floor(Math.random() * 4)], '#ffffff');
    this.addCombo();
    p.chi = Math.min(100, p.chi + 3.5);
    this.score += Math.round(m.dmg * 10 * (1 + this.combo * 0.05));
    e.facing = -dir;
    e.react = { zone: zoneOfMove(m), t: 0.01, dur: zoneOfMove(m) === 'head' ? 0.46 : zoneOfMove(m) === 'torso' ? 0.6 : 0.66, dir: a, amp: clamp(0.6 + dmg * 0.05 + kb / 2500, 0.4, 1.3), side: Math.random() < 0.5 ? 1 : -1 };
    if (e.atk && (e.state === 'windup' || e.state === 'attack') && !(e.def.armor && !heavy)) { e.atk = null; this.releaseToken(e); }
    if (e.hp <= 0) { this.killEnemy(e, dir, kb, m.launch ?? 0, !!m.finisher); return; }
    if (e.structure >= e.def.structure * (e.boss ? 1.4 : 1) && e.state !== 'dizzy') {
      e.structure = 0; e.dizzy = e.boss ? 2 : 2.8; e.state = 'dizzy'; e.stateT = e.dizzy; e.atk = null; this.releaseToken(e);
      this.texts.add(e.x, e.y - 28, 'PUSING!', '#9ff8ff', 1, 0.9); this.sfx.stagger();
      if (!e.onGround) e.vy = Math.min(e.vy, -120);
      return;
    }
    const armored = e.def.armor && !heavy && e.state !== 'dizzy' && e.onGround;
    if (armored) { e.vx += dir * 20; this.fx.spark(pt.x, pt.y, 4, '#ffb070', a + Math.PI, 0.6, 120); return; }
    if (!e.onGround || e.state === 'air') {
      e.juggle++;
      const k = Math.max(0.35, 1 - e.juggle * 0.09);
      e.state = 'air'; e.vy = m.launch ? -(m.launch * 1.05 + 40) * k : Math.min(e.vy, -150 * k); e.vx = dir * (m.knockdown ? kb * 0.5 : 55);
      e.knock = true; e.vrot = m.knockdown ? dir * rnd(5, 10) : 0;
      return;
    }
    if (m.launch || m.knockdown) {
      e.state = 'air'; e.onGround = false; e.juggle = 1; e.knock = !!m.knockdown || (m.launch ?? 0) > 120;
      e.vx = dir * kb * (m.knockdown ? 0.62 : 0.3);
      e.vy = -((m.launch ?? 0) * 1.05 + (m.knockdown ? 95 : 40));
      e.vrot = m.knockdown ? dir * rnd(4, 9) : 0;
      if ((m.launch ?? 0) >= 150) { this.fx.ring(e.x, e.y, 3, 14, '#ffffff', 0.2, 1); this.sfx.launch(); }
      this.fx.dust(e.x, e.y, 4, dir);
      return;
    }
    e.state = 'hurt'; e.stateT = 0.24 + Math.min(0.3, m.structure * 0.006); e.vx = dir * kb * 0.45;
    e.atk = null; this.releaseToken(e);
  }
  /** EFEK KENA PUKUL. Sisi DEPAN (titik kontak kepalan/kaki) cuma kilatan kecil supaya pukulannya terlihat jelas.
   *  Darah, gelombang kejut, garis laju & bintang benturan keluar dari sisi BELAKANG tubuh korban (searah pukulan)
   *  dan digambar di lapisan belakang sprite. */
  private hitFx(vx: number, feet: number, scale: number, pt: Vec, dir: number, o: { heavy: boolean; blood: number; power: number; kill?: boolean; color?: string }) {
    const a = dir > 0 ? 0 : Math.PI;
    const top = feet - BODY_H * scale;
    const by = clamp(pt.y, top + 2, feet - 3);
    const bx = vx + dir * (4.5 * scale + 1);
    this.fx.flash(pt.x, pt.y, o.heavy ? 3 : 2);
    if (o.heavy) this.fx.ring(pt.x, pt.y, 1, 4, '#ffffff', 0.09, 1);
    const B = this.fxBack;
    if (o.heavy || o.kill) this.addLight(bx, by, o.kill ? 44 : 30, o.color ?? '#ffffff', 0.09);
    B.impact(bx + dir * 2, by, o.kill ? 11 : o.heavy ? 8 : 5, o.color ?? (o.heavy ? '#ffd166' : '#ffffff'));
    B.lines(bx + dir * 3, by, o.heavy ? 5 : 3, '#ffffff', a, o.heavy ? 340 : 260);
    B.spark(bx, by, o.heavy ? 8 : 4, o.kill ? '#ff8a8a' : '#ffffff', a, 0.55, o.heavy ? 290 : 210);
    if (o.heavy || o.kill) B.shockwave(bx + dir * 3, by, o.kill ? 20 : 13, '#ffffff', o.kill ? 0.3 : 0.22);
    B.blood(bx, by, o.blood, a, o.power, '#d40000', o.kill ? 0.55 : 0.42);
    B.mist(bx, by, o.kill ? 5 : o.heavy ? 3 : 1, a);
  }
  private addCombo() {
    this.combo++; this.comboT = 2.3; this.comboPop = 1;
    if (this.combo > this.bestCombo) this.bestCombo = this.combo;
    for (const [n, label, c] of RANKS) if (this.combo === n) { this.rank = [label, c]; this.rankT = 1.6; this.sfx.announce(); break; }
  }
  private killEnemy(e: Enemy, dir: number, kb: number, launch: number, finisher: boolean, how: 'hit' | 'fall' | 'exec' | 'special' = 'hit') {
    if (e.dead) return;
    e.dead = true; e.hp = 0; e.state = 'dead'; e.atk = null; this.releaseToken(e); e.deadT = 0;
    e.fall = (['broken', 'knock', 'curled'] as Pose[])[Math.floor(Math.random() * 3)];
    if (how !== 'fall') {
      e.vx = dir * (170 + kb * 0.45); e.vy = -(150 + launch * 0.7); e.vrot = dir * rnd(8, 15); e.onGround = false;
      const hy = e.y - 9 * e.scale;
      if (finisher || how === 'exec' || how === 'special' || kb > 380) { e.spurt = 0.9; this.fxBack.debris(e.x, hy, 2, [e.def.color, e.col ?? e.def.color], dir > 0 ? -0.5 : Math.PI + 0.5, 170); }
      this.addLight(e.x, hy, 42, '#ff5a5a', 0.14);
      this.hitFx(e.x, e.y, e.scale, { x: e.x - dir * 4 * e.scale, y: hy }, dir, { heavy: true, blood: 18, power: 230, kill: true, color: '#ff5a5a' });
      this.hitstop = Math.max(this.hitstop, 0.1);
    }
    this.kills++;
    const pts = Math.round(e.def.score * (e.elite ? 1.5 : 1) * (e.boss ? 3 : 1) * (1 + this.combo * 0.03));
    this.score += pts; this.player.chi = Math.min(100, this.player.chi + (e.boss ? 40 : 10));
    this.shake(finisher ? 0.8 : 0.5);
    this.sfx.kill();
    const last = this.waveState === 'fight' && !this.queue.length && !this.enemies.some((o) => !o.dead);
    if (last || e.boss) { this.slow(1.1, 0.2); this.zoomPunch(2.3); this.flash = 0.3; this.sfx.fatality(); }
    else if (finisher) { this.slow(0.35, 0.35); this.zoomPunch(1.9); }
    if (e.boss) { this.say('BOS TUMBANG!', `+${pts}`, '#ffd166', 2.2); this.bossRef = null; this.spawnPickup(e.x, e.y - 10, 'hp'); }
    else if (Math.random() < 0.1) this.spawnPickup(e.x, e.y - 10, Math.random() < 0.55 ? 'hp' : 'chi');
    this.texts.add(e.x, e.y - 28, how === 'fall' ? 'DEFENESTRASI!' : 'K.O.', how === 'fall' ? '#5ff0ff' : '#ff5a5a', 1, 1);
  }
  private releaseToken(e: Enemy) { e.token = false; }
  private groundPound() {
    const p = this.player;
    this.fx.shockwave(p.x, p.y - 1, 26, '#ffffff', 0.3); this.fx.dust(p.x, p.y, 10); this.shake(0.6); this.sfx.slam();
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.5 || Math.abs(e.x - p.x) > 30 || Math.abs(e.y - p.y) > 6 || p.hitSet.has(e.id)) continue;
      e.hp -= 3; e.flash = 0.1; this.addCombo();
      if (e.hp <= 0) { this.killEnemy(e, Math.sign(e.x - p.x) || 1, 200, 80, true); continue; }
      if (!(e.def.armor)) { e.state = 'air'; e.knock = true; e.vy = -170; e.vx = Math.sign(e.x - p.x) * 90; e.onGround = false; }
    }
  }

  // ============================== ENEMY AI ==============================
  private tokensUsed() { return this.enemies.filter((e) => e.token && !e.dead).length; }
  private maxTokens() { return this.wave <= 2 ? 1 : this.wave <= 6 ? 2 : 3; }
  private updateEnemy(e: Enemy, dt: number) {
    const p = this.player;
    e.flash = Math.max(0, e.flash - dt); e.atkCd -= dt; e.blockCd -= dt; e.wallCd -= dt; e.jumpCd = Math.max(0, (e.jumpCd ?? 0) - dt); e.dropT = Math.max(0, e.dropT - dt); e.recoil = Math.max(0, e.recoil - dt * 6);
    e.sqx += (1 - e.sqx) * Math.min(1, dt * 10); e.sqy += (1 - e.sqy) * Math.min(1, dt * 10);
    if (e.react) { e.react.t += dt; if (e.react.t > e.react.dur) e.react = null; }
    if (e.dead) { this.updateCorpse(e, dt); return; }
    if (e.state === 'held') return;
    if (e.state === 'spawn') {
      e.spawnT -= dt;
      e.alpha = clamp(1 - e.spawnT / (e.spawnMode === 'drop' ? 0.9 : 0.6), 0, 1) * 1.2;
      if (e.spawnMode === 'door') { e.vx = e.facing * e.def.speed * 0.5; }
      this.move(e, dt, false, e.spawnMode === 'drop' ? GRAV * 0.35 : GRAV);
      this.gait(e, dt);
      if (e.spawnT <= 0) { e.state = 'idle'; e.alpha = 1; }
      return;
    }
    if (e.state === 'door') {
      e.stateT -= dt; e.alpha = clamp(e.stateT / 0.3, 0, 1);
      if (e.stateT <= 0 && e.doorTo) { e.x = e.doorTo.x; e.y = e.doorTo.yF; e.doorTo.openT = 0.6; e.state = 'spawn'; e.spawnMode = 'door'; e.spawnT = 0.5; e.doorTo = null; e.facing = p.x >= e.x ? 1 : -1; }
      return;
    }
    if (e.state === 'climb' && e.ladder) {
      const l = e.ladder, up = this.storyOf(p.y) < this.storyOf(e.y);
      e.x += (l.x - e.x) * Math.min(1, dt * 12); e.vy = up ? -50 : 50; e.y += e.vy * dt; e.walk += 50 * dt * 0.5;
      if (e.y <= l.topY || e.y >= l.botY) { e.y = clamp(e.y, l.topY, l.botY); e.climbing = false; e.ladder = null; e.state = 'idle'; e.vy = 0; e.dropT = 0.1; }
      return;
    }
    const r0 = this.move(e, dt, false, e.state === 'air' ? GRAV * 0.86 : GRAV);
    this.envImpacts(e, r0);
    if (e.x < -6 || e.x > this.W * T + 6) { e.outside = true; this.score += 300; this.killEnemy(e, Math.sign(e.vx) || 1, 0, 0, true, 'fall'); this.slow(0.7, 0.3); this.zoomPunch(1.95); return; }
    const sameStory = this.storyOf(e.y) === this.storyOf(p.y) && !p.door;
    const dx = p.x - e.x, adx = Math.abs(dx);
    switch (e.state) {
      case 'air':
        e.rot += e.vrot * dt;
        if (r0.landed) {
          e.rot = 0; e.vrot = 0; e.juggle = 0;
          this.fx.dust(e.x, e.y, 5); this.sfx.land();
          if (e.knock) { e.state = 'down'; e.stateT = e.boss ? 0.6 : rnd(0.75, 1.1); e.sqx = 1.3; e.sqy = 0.7; this.shake(0.25); this.fx.blood(e.x, e.y - 3, 3, -Math.PI / 2, 60); }
          else { e.state = 'hurt'; e.stateT = 0.2; }
        }
        return;
      case 'down': e.vx *= Math.max(0, 1 - dt * 9); e.stateT -= dt; if (e.stateT <= 0) { e.state = 'getup'; e.stateT = 0.42; } return;
      case 'getup': e.vx = 0; e.stateT -= dt; if (e.stateT <= 0) { e.state = 'idle'; e.atkCd = Math.max(e.atkCd, 0.4); } return;
      case 'hurt': e.vx *= Math.max(0, 1 - dt * 7); e.stateT -= dt; if (e.stateT <= 0) e.state = 'idle'; return;
      case 'dizzy': e.vx *= Math.max(0, 1 - dt * 8); e.dizzy -= dt; e.stateT -= dt; if (e.stateT <= 0) { e.state = 'idle'; e.dizzy = 0; } return;
      case 'stagger': e.vx *= Math.max(0, 1 - dt * 8); e.stateT -= dt; if (e.stateT <= 0) e.state = 'idle'; return;
      case 'block': e.vx *= Math.max(0, 1 - dt * 10); e.stateT -= dt; e.facing = Math.sign(dx) || e.facing; if (e.stateT <= 0) e.state = 'idle'; return;
      case 'windup': {
        const a = e.atk!;
        e.vx *= Math.max(0, 1 - dt * 10); e.stateT -= dt; e.poseT = 0.3 * (1 - e.stateT / a.windup);
        if (e.stateT <= 0) { e.state = 'attack'; e.stateT = a.active; e.vx += e.facing * a.lunge; this.sfx.swing(a.heavy ? 0.7 : 1); }
        return;
      }
      case 'attack': {
        const a = e.atk!;
        e.stateT -= dt; e.poseT = 0.3 + 0.3 * (1 - e.stateT / a.active);
        if (!a.hit) this.enemyStrike(e, a);
        if (e.stateT <= 0) { e.state = 'recover'; e.stateT = a.recover; }
        return;
      }
      case 'recover': {
        const a = e.atk;
        e.vx *= Math.max(0, 1 - dt * 8); e.stateT -= dt; e.poseT = a ? 0.6 + 0.4 * (1 - e.stateT / a.recover) : 1;
        if (e.stateT <= 0) {
          if (a && e.chain > 0 && sameStory && adx < (a.reach + 12) * e.scale) { e.chain--; this.beginAttack(e, true); }
          else { e.state = 'idle'; e.atk = null; e.atkCd = e.def.recover * rnd(0.8, 1.6) * (e.boss ? 0.6 : 1); this.releaseToken(e); }
        }
        return;
      }
      case 'aim': {
        e.vx *= Math.max(0, 1 - dt * 10); e.facing = Math.sign(dx) || e.facing; e.aimT -= dt;
        if (e.aimT <= 0) {
          const mx = e.x + e.facing * 9 * e.scale, my = e.y - 9.5 * e.scale, pan = clamp((e.x - this.cam.x) / 200, -1, 1);
          if (e.kind === 'bomber') {
            const nb = e.boss ? 3 : 1;
            for (let k = 0; k < nb; k++) this.bombs.push({ x: e.x + e.facing * 5, y: e.y - 15 * e.scale, vx: e.facing * clamp(adx / 0.52, 70, 300) * (1 + (k - (nb - 1) / 2) * 0.28), vy: -200 - k * 15, fuse: 1.3 + k * 0.12, mine: false, spin: k });
            this.sfx.swing(0.9);
          } else if (e.kind === 'shotgunner') {
            for (let k = 0; k < 6; k++) { const a = rnd(-0.16, 0.16); this.bullets.push({ x: mx, y: my, vx: e.facing * Math.cos(a) * 300, vy: Math.sin(a) * 300, life: 0.5, dmg: e.def.dmg, mine: false, kb: 0, kind: 'enemy' }); }
            this.sfx.shotgunBlast(pan); this.shake(0.25); e.vx -= e.facing * 60;
            this.fx.impact(mx + e.facing * 3, my, 7, '#ffd166'); this.fx.smoke(mx, my, 4, '#9a9a9a', 18, 0.5); this.addLight(mx, my, 60, '#ffd27f', 0.08);
          } else {
            this.bullets.push({ x: mx, y: my, vx: e.facing * (e.kind === 'smg' ? 360 : 330), vy: e.kind === 'smg' ? rnd(-12, 12) : 0, life: 1.6, dmg: e.def.dmg, mine: false, kb: 0, kind: 'enemy' });
            this.sfx.enemyShot(pan); this.fx.impact(mx + e.facing * 2, my, 4, '#ffd166'); this.fx.spark(mx, my, 4, '#ffd166', e.facing > 0 ? 0 : Math.PI, 0.4, 160); this.addLight(mx, my, 40, '#ffd27f', 0.06);
          }
          e.recoil = 1;
          if (e.kind === 'smg' && (e.burst ?? 0) > 1) { e.burst = (e.burst ?? 1) - 1; e.aimT = 0.09; return; }
          e.state = 'recover'; e.stateT = 0.5; e.atk = null; e.atkCd = rnd(1.4, 2.4) * (e.kind === 'bomber' ? 1.3 : 1);
        }
        return;
      }
      case 'charge': {
        e.stateT -= dt;
        if (e.hold > 0) { e.hold -= dt; e.vx = 0; e.poseT = 0.3 * (1 - e.hold / 0.65); if (e.hold <= 0) this.sfx.dash(); return; }
        e.vx = e.facing * 215; e.poseT = 0.5;
        this.ghostEnemy(e);
        if (sameStory && Math.abs(dx) < 12 * e.scale && Math.sign(dx) === e.facing && Math.abs(p.y - e.y) < 16) {
          this.enemyStrike(e, { pose: 'charge', dmg: e.def.dmg + 4, reach: 14, windup: 0, active: 0, recover: 0, heavy: true, hit: false, launch: 0, lunge: 0 });
          if (e.state === 'charge') { e.state = 'recover'; e.stateT = 0.8; e.atk = null; }
        }
        if (r0.wall) { e.state = 'dizzy'; e.dizzy = 1.6; e.stateT = 1.6; this.shake(0.7); this.sfx.slam(); this.fx.dust(e.x + e.facing * 6, e.y - 8, 8, -e.facing); this.texts.add(e.x, e.y - 30, 'NABRAK!', '#ffd166', 1, 0.8); }
        else if (e.stateT <= 0) { e.state = 'recover'; e.stateT = 0.6; e.atk = null; }
        return;
      }
      default: break;
    }
    // ---- idle: berpikir
    e.poseT = 0;
    if (!sameStory || p.dead) {
      if (!p.dead && !this.navigate(e, dt)) e.vx *= Math.max(0, 1 - dt * 6);
      this.gait(e, dt); this.separate(e, dt);
      return;
    }
    if (e.kind === 'shield' && dx !== 0 && Math.sign(dx) !== e.facing) { e.turnT = (e.turnT ?? 0) + dt; if (e.turnT > 0.55) { e.facing = Math.sign(dx); e.turnT = 0; } }
    else { e.turnT = 0; e.facing = Math.sign(dx) || e.facing; }
    const reach = e.def.reach * e.scale + 2;
    // naik ke pijakan / turun mengejar pemain (side view: musuh bisa melompat)
    const dyp = p.y - e.y;
    if ((e.jumpCd ?? 0) <= 0 && e.onGround && p.onGround && !p.climbing) {
      if (dyp < -12 && dyp > -44 && adx < 48) { e.vy = -305; e.onGround = false; e.jumpCd = 1.4; e.vx = e.facing * Math.max(40, e.def.speed); this.fx.dust(e.x, e.y, 3); }
      else if (dyp > 12 && this.platTop(e.x, e.y + 1)) { e.dropT = 0.3; e.onGround = false; e.jumpCd = 0.9; }
    }
    if (e.kind === 'gunner' || e.kind === 'smg' || e.kind === 'shotgunner' || e.kind === 'bomber') {
      const want = e.kind === 'shotgunner' ? 46 : e.kind === 'bomber' ? 120 : e.kind === 'smg' ? 90 : 105;
      const maxR = e.kind === 'shotgunner' ? 80 : e.kind === 'bomber' ? 190 : 220;
      if (adx < 26 && e.atkCd <= 0) { this.beginAttack(e, false); return; }
      const tv = adx < want - 25 ? -e.facing * e.def.speed : adx > want + 35 ? e.facing * e.def.speed * (adx > 160 ? 1.5 : 1) : 0;
      e.vx += clamp(tv - e.vx, -500 * dt, 500 * dt);
      if (e.atkCd <= 0 && adx < maxR && Math.abs(dyp) < 14) { e.state = 'aim'; e.aimT = (e.elite ? 0.5 : 0.75) * (e.kind === 'bomber' ? 0.9 : 1); e.burst = e.kind === 'smg' ? 4 : 1; this.texts.add(e.x, e.y - 24, '!', '#ff3b3b', 1, 0.5); }
      this.gait(e, dt); this.separate(e, dt);
      return;
    }
    if (e.kind === 'brute' && e.atkCd <= 0 && adx > 55 && adx < 170 && Math.random() < dt * 0.8) {
      e.state = 'charge'; e.stateT = 1.0; e.hold = 0.65; e.flash = 0.1;
      this.texts.add(e.x, e.y - 30 * e.scale, '!!', '#ff3b3b', 1, 0.7); return;
    }
    if (!e.token && e.atkCd <= 0 && this.tokensUsed() < this.maxTokens() + (e.boss ? 1 : 0)) e.token = true;
    if (e.token) {
      if (adx > reach) { const sp = e.def.speed * (e.elite ? 1.15 : 1) * (adx > 150 ? 1.75 : adx > 90 ? 1.25 : 1); e.vx += clamp(e.facing * sp - e.vx, -600 * dt, 600 * dt); }
      else if (e.atkCd <= 0) { this.beginAttack(e, false); return; }
      else e.vx *= Math.max(0, 1 - dt * 8);
      if (e.kind === 'master' && adx > 60 && adx < 140 && Math.random() < dt * 0.9) { e.vx = e.facing * 260; this.ghostEnemy(e); }
    } else {
      // tanpa giliran: menjaga jarak di sisinya, berayun & sesekali memprovokasi
      const ring = 34 + (e.id % 4) * 10 + Math.sin(this.time * 1.3 + e.id) * 4;
      const tv = adx < ring - 6 ? -e.facing * e.def.speed * 0.7 : adx > ring + 10 ? e.facing * e.def.speed * (adx > 150 ? 1.6 : 0.8) : 0;
      e.vx += clamp(tv - e.vx, -400 * dt, 400 * dt);
    }
    this.gait(e, dt); this.separate(e, dt);
  }
  private beginAttack(e: Enemy, chained: boolean) {
    const d = e.def;
    const pose = d.poses[Math.floor(Math.random() * d.poses.length)];
    const heavy = pose === 'roundhouse' || pose === 'hammer' || pose === 'sidekick' || pose === 'spinback' || pose === 'uppercut' || e.kind === 'brute';
    const sp = (e.elite ? 0.85 : 1) / (0.65 + 0.35 * this.tempo);
    e.atk = { pose, dmg: d.dmg * (heavy ? 1.25 : 1) * (1 + this.dw * 0.02), reach: d.reach + (pose === 'sidekick' || pose === 'roundhouse' ? 4 : 0), windup: d.windup * sp * (chained ? 0.75 : rnd(0.9, 1.15)), active: 0.12 * sp, recover: d.recover * sp, heavy, hit: false, launch: pose === 'uppercut' ? 160 : 0, lunge: heavy ? 110 : 70 };
    if (!chained) e.chain = e.kind === 'master' ? Math.floor(rnd(1, 4)) : e.kind === 'knife' ? 1 : e.elite && Math.random() < 0.5 ? 1 : 0;
    e.state = 'windup'; e.stateT = e.atk.windup; e.poseT = 0; e.token = true;
    if (heavy && !chained) e.flash = 0.06;
  }
  private enemyStrike(e: Enemy, a: Atk) {
    const p = this.player;
    if (p.dead || p.door) return;
    const fx = (p.x - e.x) * e.facing;
    if (fx < -3 || fx > a.reach * e.scale + 5 || Math.abs(p.y - e.y) > 15 * e.scale) return;
    a.hit = true;
    const cx = e.x + e.facing * Math.min(fx, a.reach * e.scale) * 0.8, cy = e.y - 10 * e.scale;
    if (p.iframes > 0 || p.dashT > 0) { this.texts.add(p.x, p.y - 24, 'MISS', '#9fe8ff', 1, 0.5); return; }
    const facingIt = p.facing === -e.facing;
    if (p.parryT > 0 && facingIt) { this.perfectParry(e, cx, cy); return; }
    if (p.blocking && facingIt && !(e.kind === 'brute' && e.state === 'charge')) {
      const chip = Math.max(1, Math.round(a.dmg * 0.15));
      p.hp -= chip; p.vx = e.facing * (a.heavy ? 150 : 90); p.chi = Math.min(100, p.chi + 2);
      this.fx.spark(cx, cy, 8, '#9fe8ff', e.facing > 0 ? Math.PI : 0, 0.8, 200); this.fx.impact(cx, cy, 5, '#9fe8ff');
      this.sfx.parry(); this.hitstop = Math.max(this.hitstop, 0.04); this.texts.add(p.x, p.y - 24, 'TAHAN', '#9fe8ff', 1, 0.5);
      if (p.hp <= 0) this.playerDie(e.facing);
      return;
    }
    this.damagePlayer(Math.round(a.dmg), e.facing, a.heavy && (e.kind === 'brute' || a.launch > 0 || e.boss), cx, cy);
  }
  private perfectParry(e: Enemy, cx: number, cy: number) {
    const p = this.player;
    this.sfx.parry();
    this.fx.spark(cx, cy, 16, '#ffd166', 0, Math.PI, 260); this.fx.ring(cx, cy, 2, 18, '#ffd166', 0.25, 2); this.fx.impact(cx, cy, 9, '#ffffff');
    this.hitstop = Math.max(this.hitstop, 0.08); this.slow(0.35, 0.3); this.zoomPunch(1.9);
    e.state = 'stagger'; e.stateT = e.boss ? 0.7 : 1.0; e.atk = null; this.releaseToken(e); e.vx = e.facing * -80;
    if (e.kind === 'brute') { e.state = 'dizzy'; e.dizzy = 1.6; e.stateT = 1.6; }
    e.structure += 30;
    p.chi = Math.min(100, p.chi + 15); p.counterT = 0.8; p.parryAnim = 0.25; p.parryT = 0;
    this.score += 50;
    this.texts.add(cx, cy - 14, 'PARRY!', '#ffd166', 1, 0.8);
  }
  private damagePlayer(dmg: number, dir: number, heavy: boolean, cx: number, cy: number) {
    const p = this.player;
    if (p.grab) this.dropHeld();
    p.hp -= dmg; p.flash = 0.12; p.iframes = 0.55; p.phase = 'none'; p.moveKey = null; p.move = null; p.climbing = false; p.ladder = null; p.dashT = 0;
    this.combo = 0; this.comboT = 0;
    this.shake(heavy ? 0.7 : 0.45); this.hitstop = Math.max(this.hitstop, 0.06); this.hurtFlash = 0.45;
    this.sfx.hurt();
    this.hitFx(p.x, p.y, 1, { x: cx, y: cy }, dir, { heavy, blood: 6, power: 130, color: '#ff5a5a' });
    p.react = { zone: heavy ? 'torso' : 'head', t: 0.01, dur: 0.46, dir: dir > 0 ? 0 : Math.PI, amp: 1, side: 1 };
    this.texts.add(p.x, p.y - 24, `-${dmg}`, '#ff5a5a', 1, 0.7);
    if (p.hp <= 0) { this.playerDie(dir); return; }
    if (heavy) { p.downT = 0.7; p.vy = -170; p.vx = dir * 170; p.onGround = false; p.fall = Math.random() < 0.5 ? 'broken' : 'knock'; }
    else { p.hurtT = 0.28; p.vx = dir * 130; }
  }
  private playerDie(dir: number) {
    const p = this.player;
    if (p.dead) return;
    p.dead = true; p.hp = 0; p.vy = -200; p.vx = dir * 150; p.vrot = dir * 9; p.onGround = false; p.fall = 'broken';
    this.slow(2.2, 0.25); this.zoomPunch(2.6); this.flash = 0.4; this.sfx.death();
    this.say('K.O.', `WAVE ${this.wave}  -  SKOR ${Math.round(this.score)}`, '#ff3b3b', 3);
  }
  private envImpacts(e: Enemy, r: { wall: number; landed: boolean; bonk: boolean; glass: boolean }) {
    const flying = e.state === 'air' || e.state === 'hurt' || e.dead;
    if (r.glass) { this.score += 50; }
    if (r.wall && flying && Math.abs(e.vx) > 150 && e.wallCd <= 0) {
      e.wallCd = 0.3;
      const wx = e.x + r.wall * 4, wy = e.y - 8 * e.scale;
      this.fx.dust(wx, wy, 6, -r.wall); this.fx.impact(wx, wy, 7, '#ffffff'); this.fx.blood(wx, wy, 6, r.wall > 0 ? Math.PI : 0, 110);
      this.crack(wx, wy, true); this.shake(0.5); this.sfx.slam(); this.hitstop = Math.max(this.hitstop, 0.06);
      e.vx = -e.vx * 0.38;
      if (!e.dead) {
        e.hp -= 2; this.addCombo(); this.score += 50; this.texts.add(e.x, e.y - 26, 'WALL SPLAT!', '#ffd166', 1, 0.8);
        e.state = 'air'; e.knock = true; e.vy = Math.min(e.vy, -110); e.onGround = false;
        if (e.hp <= 0) this.killEnemy(e, -r.wall, 60, 40, true);
      }
    }
    if (r.bonk && (e.state === 'air' || e.dead)) {
      this.fx.dust(e.x, e.y - BODY_H * e.scale, 5, 0, '#8a8f9c'); this.crack(e.x, e.y - BODY_H * e.scale, false); this.sfx.hit(); this.shake(0.3);
      if (!e.dead) { e.hp -= 1; this.texts.add(e.x, e.y - 26, 'BONK!', '#ffffff', 1, 0.6); if (e.hp <= 0) this.killEnemy(e, e.facing * -1, 30, 0, false); }
    }
    // tubuh terlempar menghantam perabot & musuh lain (efek bowling)
    if (flying && (Math.abs(e.vx) > 105 || e.vy > 220)) {
      for (const pr of this.props) {
        if (pr.broken || Math.abs(pr.x + 8 - e.x) > 9 || e.y < pr.yF - pr.h - 4 || e.y > pr.yF + 6) continue;
        if (pr.ch === 'r' && !e.dead) { e.hp -= 10; e.flash = 0.2; this.fx.zap(e.x, e.y - 8, 6); this.fx.spark(e.x, e.y - 8, 10, '#bfe6ff', -Math.PI / 2, 1.4, 220); this.addLight(e.x, e.y - 8, 56, '#9fd8ff', 0.3); this.texts.add(e.x, e.y - 28, 'KESETRUM!', '#9fd8ff', 1, 0.9); this.score += 150; this.sfx.busterHum(1); if (e.hp <= 0) this.killEnemy(e, Math.sign(e.vx) || 1, 60, 60, true); }
        this.damageProp(pr, Math.sign(e.vx) || 1, 3); e.vx *= 0.75;
      }
      if (Math.abs(e.vx) > 150) for (const o of this.enemies) {
        if (o === e || o.dead || o.state === 'air' || o.state === 'down' || o.alpha < 0.6 || Math.abs(o.x - e.x) > 8 || Math.abs(o.y - e.y) > 10 || o.def.armor) continue;
        o.state = 'air'; o.knock = true; o.vx = Math.sign(e.vx) * 150; o.vy = -140; o.onGround = false; o.hp -= 3; o.flash = 0.1; o.atk = null; this.releaseToken(o);
        e.vx *= 0.6; this.sfx.hit(); this.addCombo(); this.score += 40;
        this.texts.add(o.x, o.y - 26, 'STRIKE!', '#7cff9a', 1, 0.7);
        if (o.hp <= 0) this.killEnemy(o, Math.sign(e.vx) || 1, 120, 50, false);
      }
    }
  }
  private damageProp(pr: Prop, dir: number, n: number) {
    if (pr.ch === 'R') return;
    pr.hp -= n; pr.shake = 0.3;
    if (pr.hp > 0 || pr.broken) { this.sfx.hit(); return; }
    pr.broken = true;
    const cx = pr.x + 8, cy = pr.yF - pr.h / 2;
    const col: Record<string, string[]> = { d: ['#a8865e', '#6b4f36', '#2a2d35'], c: ['#2f3542', '#4f5870'], p: ['#b8613a', '#3fbf5a', '#5a3a24'], w: ['#d8dde4', '#8fd8ff'], f: ['#8a909c', '#5a606c'], v: ['#c42f3a', '#ffd166', '#5ff0ff'], x: ['#d8dce4', '#a0a5ae'], r: ['#14161c', '#3aff7a', '#3a8bff'], b: ['#b07a40', '#d8c08a'], k: ['#8a3048', '#a0435a'], q: ['#e8dcc0', '#2a2633'], a: ['#9aa3b0', '#3a3f4a'] };
    this.fx.debris(cx, cy, 10, col[pr.ch] ?? ['#888'], dir > 0 ? -0.6 : Math.PI + 0.6, 160);
    this.fx.smoke(cx, cy, 4, '#8a8a8a', 25, 0.6);
    if ('dfxq'.includes(pr.ch)) this.fx.paper(cx, cy - 4, 12);
    if (pr.ch === 'w') { this.fx.water(cx, cy, 24); this.sfx.splash(); }
    if ('vrx'.includes(pr.ch) || (pr.ch === 'd' && pr.seed > 0.4)) { this.fx.zap(cx, cy - 4, 4); this.fx.spark(cx, cy, 10, '#bfe6ff', -Math.PI / 2, 1.4, 200); }
    if ('vd'.includes(pr.ch)) { this.fx.glass(cx, cy - 6, 8, dir > 0 ? 0 : Math.PI, 0.7); this.sfx.glassShatter(); } else this.sfx.heavy();
    if (pr.ch === 'A') { this.fx.water(cx, cy, 34); this.sfx.splash(); this.fx.debris(cx, cy, 4, ['#ff8a3d', '#ffd166', '#ff5a8a'], dir > 0 ? -0.5 : Math.PI + 0.5, 140); this.fx.glass(cx, cy, 10, dir > 0 ? 0 : Math.PI, 0.8); this.texts.add(cx, cy - 16, 'BYUR!', '#8fd8ff', 1, 0.8); }
    if (pr.ch === 's') { for (let k = 0; k < 22; k++) this.fx.add({ x: cx + rnd(-5, 5), y: cy - 4, vx: rnd(-80, 80), vy: rnd(-150, -50), life: rnd(2, 3.4), c: k % 3 ? '#7cd88a' : '#4aa85a', s: 1, k: 8, rot: rnd(0, 6), vr: rnd(4, 9) }); this.score += 300; this.texts.add(cx, cy - 18, '+300 UANG!', '#7cff9a', 1, 1); this.sfx.pickup(); }
    if (pr.ch === 'y') { for (let k = 0; k < 18; k++) this.fx.add({ x: cx + rnd(-3, 3), y: cy, vx: rnd(-90, 90), vy: rnd(-180, -40), life: rnd(0.6, 1.2), c: k % 2 ? '#6a3a1a' : '#8a5a2a', s: rnd(1, 2), k: 12, g: 620 }); this.sfx.splash(); }
    if ('iVOl'.includes(pr.ch)) { this.fx.zap(cx, cy - 4, 5); this.fx.spark(cx, cy, 12, '#bfe6ff', -Math.PI / 2, 1.4, 220); this.fx.glass(cx, cy - 4, 8, dir > 0 ? 0 : Math.PI, 0.6); this.addLight(cx, cy, 60, '#9fd8ff', 0.25); this.sfx.glassShatter(); }
    if (pr.ch === 'h' || pr.ch === 'J') this.fx.debris(cx, cy, 8, ['#e0b84a', '#c9a033', '#fff2b0'], dir > 0 ? -0.5 : Math.PI + 0.5, 170);
    if (pr.ch === 'm') this.fx.paper(cx, cy - 6, 16);
    if (pr.ch === 'v') { this.spawnPickup(cx, cy, 'hp'); this.spawnPickup(cx + 4, cy, Math.random() < 0.5 ? 'hp' : 'chi'); }
    this.shake(0.3); this.score += 25;
  }
  private spawnPickup(x: number, y: number, kind: 'hp' | 'chi') { this.pickups.push({ x, y, vy: -120, kind, life: 14 }); }
  private navigate(e: Enemy, dt: number): boolean {
    const p = this.player, es = this.storyOf(e.y), ps = this.storyOf(p.y);
    if (es === ps) return false;
    const up = ps < es;
    let best: { x: number; c?: Conn; l?: Ladder } | null = null, bd = Infinity;
    for (const c of this.conns) if (c.story === es && (up ? c.up : c.down)) { const d = Math.abs(c.x - e.x); if (d < bd) { bd = d; best = { x: c.x, c }; } }
    for (const l of this.ladders) {
      const ts = this.storyOf(l.topY), bs = this.storyOf(l.botY);
      if ((up && bs === es && ts < es) || (!up && ts === es && bs > es)) { const d = Math.abs(l.x - e.x); if (d < bd) { bd = d; best = { x: l.x, l }; } }
    }
    if (!best) return false;
    const dx = best.x - e.x;
    if (Math.abs(dx) > 3) { e.facing = Math.sign(dx); e.vx += clamp(e.facing * e.def.speed * 1.1 - e.vx, -600 * dt, 600 * dt); return true; }
    e.vx = 0;
    if (best.c && e.onGround) { const to = up ? best.c.up! : best.c.down!; best.c.openT = 0.5; e.state = 'door'; e.stateT = 0.45; e.doorTo = to; }
    else if (best.l) { e.state = 'climb'; e.climbing = true; e.ladder = best.l; e.dropT = 0.2; }
    return true;
  }
  private separate(e: Enemy, dt: number) {
    for (const o of this.enemies) {
      if (o === e || o.dead || o.state === 'air' || Math.abs(o.y - e.y) > 6) continue;
      const d = e.x - o.x;
      if (Math.abs(d) < 9) e.vx += (Math.sign(d) || (e.id > o.id ? 1 : -1)) * 260 * dt;
    }
    const p = this.player;
    if (!p.dead && Math.abs(p.y - e.y) < 8 && Math.abs(p.x - e.x) < 6 && e.onGround) e.vx += (Math.sign(e.x - p.x) || 1) * 300 * dt;
  }
  private gait(e: Enemy, dt: number) {
    const sp = Math.abs(e.vx);
    e.runK += ((sp > e.def.speed * 1.1 ? 1 : 0) - e.runK) * Math.min(1, dt * 5);
    if (sp > 8 && e.onGround) { const gc = gaitCadence(sp, e.runK, e.scale); e.stride = gc.stride; e.walk += dt * gc.stepsPerSec * Math.PI; }
    else e.walk = 0;
  }
  private updateCorpse(e: Enemy, dt: number) {
    e.deadT += dt;
    if (this.player.grab === e) { e.deadT = Math.min(e.deadT, 6); return; }
    if ((e.spurt ?? 0) > 0) { e.spurt = (e.spurt ?? 0) - dt; if (Math.random() < 0.75) this.fxBack.blood(e.x + rnd(-2, 2), e.y - (e.onGround ? 3 : 9 * e.scale), 2, -Math.PI / 2 + rnd(-0.5, 0.5), 170, '#c80000', 0.25); }
    if (!e.pooled && e.onGround && Math.abs(e.vx) < 25 && !e.outside) { e.pooled = true; this.pools.push({ x: e.x, y: e.y, r: 1.5, max: rnd(8, 14) * e.scale, a: 1 }); if (this.pools.length > 40) this.pools.shift(); }
    if (e.outside) { e.vy = Math.min(MAX_FALL, e.vy + GRAV * dt); e.x += e.vx * dt; e.y += e.vy * dt; e.rot += e.vrot * dt; return; }
    const r = this.move(e, dt, false, GRAV);
    this.envImpacts(e, r);
    if (e.x < -6 || e.x > this.W * T + 6) { e.outside = true; this.texts.add(e.x, e.y - 20, 'AAAA!', '#ffffff', 1, 0.8); }
    if (r.landed) { if (Math.abs(e.vy) < 1 && e.vrot !== 0) { this.fx.dust(e.x, e.y, 4); this.fx.blood(e.x, e.y - 2, 4, -Math.PI / 2, 50); } e.vrot = 0; e.rot = 0; e.vx *= Math.max(0, 1 - dt * 8); }
    else e.rot += e.vrot * dt;
    e.alpha = e.deadT > 11 ? Math.max(0, 1 - (e.deadT - 11) / 3) : 1;
  }

  // ============================== CLASH (adu pukulan ala duel) ==============================
  private startClash(e: Enemy) {
    const p = this.player;
    this.clash = { e, t: 0, power: 0.5, spark: 0 };
    e.state = 'clash'; p.vx = 0; e.vx = 0;
    p.x = clamp(p.x, e.x - e.facing * 30, e.x - e.facing * 14);
    this.sfx.parry(); this.flash = 0.3; this.hitstop = 0.1;
    this.say('ADU PUKULAN!', 'TEKAN J / K SECEPATNYA!', '#ffd166', 2.2);
  }
  private updateClash(raw: number) {
    const C = this.clash!, p = this.player, e = C.e;
    C.t += raw; C.spark -= raw;
    if (this.hit(this.lightKeys) || this.hit(this.heavyKeys) || this.hit(['Mouse0', 'Mouse2'])) { C.power += 0.055; this.sfx.punch(); this.shake(0.15); }
    C.power -= raw * (0.2 + this.dw * 0.004);
    const mx = (p.x + e.x) / 2, my = p.y - 10;
    if (C.spark <= 0) { C.spark = 0.06; this.fx.spark(mx, my, 6, Math.random() < 0.5 ? '#ffd166' : '#ffffff', -Math.PI / 2, Math.PI, 220); this.fx.impact(mx, my, 5, '#ffd166'); }
    if (C.t > 2.4 || C.power >= 1 || C.power <= 0) {
      const win = C.power >= 0.5;
      this.clash = null; this.hitstop = 0.12; this.flash = 0.4; this.shake(0.9);
      this.fx.shockwave(mx, my, 30, '#ffffff', 0.35);
      if (win) {
        e.state = 'dizzy'; e.dizzy = 1.8; e.stateT = 1.8; e.vx = e.facing * -160; e.hp -= 12; e.flash = 0.15;
        this.say('MENANG ADU!', 'HAJAR DIA SEKARANG!', '#7cff9a', 1.6); this.sfx.heavy(); p.chi = Math.min(100, p.chi + 25);
        if (e.hp <= 0) this.killEnemy(e, p.facing, 300, 100, true);
      } else {
        e.state = 'idle'; e.atkCd = 0.2;
        this.damagePlayer(10, e.facing, true, mx, my);
        this.say('KALAH ADU!', '', '#ff5a5a', 1.2);
      }
      this.slow(0.5, 0.3);
    }
  }

  // ============================== EKSEKUSI ==============================
  private execTarget(): Enemy | null {
    const p = this.player;
    if (!p.onGround || p.phase !== 'none') return null;
    let best: Enemy | null = null, bd = 30;
    for (const e of this.enemies) {
      if (e.dead || (e.state !== 'dizzy' && e.state !== 'stagger') || Math.abs(e.y - p.y) > 8) continue;
      const d = Math.abs(e.x - p.x); if (d < bd) { bd = d; best = e; }
    }
    return best;
  }
  private startExec(e: Enemy) {
    const p = this.player;
    p.facing = Math.sign(e.x - p.x) || p.facing;
    e.x = p.x + p.facing * 13 * e.scale; e.facing = -p.facing; e.vx = 0;
    this.exec = { e, step: 0, t: 0, seq: EXEC_SEQS[Math.floor(Math.random() * EXEC_SEQS.length)], hitDone: false };
    p.iframes = 3; p.vx = 0;
    this.sfx.focus(); this.say('EKSEKUSI!', '', '#ff3b3b', 0.85);
  }
  private updateExec(dt: number) {
    const X = this.exec!, p = this.player, e = X.e, st = X.seq[X.step];
    X.t += dt;
    const k = X.t / st.dur;
    if (!X.hitDone && k >= 0.36) {
      X.hitDone = true;
      const hx = e.x - p.facing * 2, hy = e.y - 10 * e.scale, a = p.facing > 0 ? 0 : Math.PI;
      const final = X.step === X.seq.length - 1;
      this.hitFx(e.x, e.y, e.scale, { x: hx, y: hy }, p.facing, { heavy: true, blood: final ? 22 : 8, power: 190, kill: final, color: final ? '#ff3b3b' : '#ffd166' }); void a;
      this.hitstop = final ? 0.16 : 0.07; this.shake(final ? 1 : 0.5); this.addCombo();
      this.texts.add(p.x, p.y - 32, st.name, '#ffd166', 1, 0.7);
      if (final) { this.sfx.fatality(); this.sfx.heavy(); } else this.sfx.kick();
      e.flash = 0.12; e.react = { zone: 'head', t: 0.01, dur: 0.46, dir: a, amp: 1.3, side: 1 };
      if (X.step === 1) { e.vy = -200; e.state = 'air'; e.onGround = false; }
      if (final) {
        this.exec = null; p.iframes = 0.6;
        this.score += 500; this.heal(10);
        this.fxBack.shockwave(e.x + p.facing * 9 * e.scale, hy, 34, '#ff3b3b', 0.4); this.flash = 0.4; this.slow(0.8, 0.25); this.zoomPunch(2.45);
        this.killEnemy(e, p.facing, 520, 160, true, 'exec');
        return;
      }
    }
    if (X.step === 1 || X.step === 2) { this.move(e, dt, false, GRAV * 0.5); e.x += (p.x + p.facing * 13 * e.scale - e.x) * Math.min(1, dt * 10); }
    if (k >= 1) { X.step++; X.t = 0; X.hitDone = false; if (X.step === 2) { p.vy = -150; p.onGround = false; } }
    this.move(p, dt, true, GRAV * 0.6);
  }

  // ============================== CHI: TINJU NAGA ==============================
  private startSpecial() {
    const p = this.player;
    p.chi = 0; p.phase = 'none'; p.moveKey = null; p.move = null; p.iframes = 2;
    this.special = { t: 0, phase: 'dash', dir: p.facing, hits: [], done: 0 };
    this.flash = 0.4; this.sfx.focus(); this.sfx.dash(); this.say('TINJU NAGA!', '', '#ffd166', 1.4); this.zoomPunch(2.1);
  }
  private updateSpecial(dt: number) {
    const S = this.special!, p = this.player;
    S.t += dt;
    if (S.phase === 'dash') {
      p.vx = S.dir * 560; p.vy = 0;
      const r = this.move(p, dt, true, 0);
      this.ghost(this.playerOpts('ragedash', 0.5), '#ffd166');
      this.fx.ember(p.x, p.y - 8, 2, '#ffd166');
      for (const e of this.enemies) if (!e.dead && e.alpha > 0.5 && !S.hits.includes(e) && Math.abs(e.x - p.x) < 16 * e.scale && Math.abs(e.y - p.y) < 20) { S.hits.push(e); e.state = 'stagger'; e.stateT = 3; e.vx = 0; e.atk = null; this.fx.impact(e.x, e.y - 9, 6, '#ffd166'); this.sfx.punch(); }
      if (S.t > 0.34 || r.wall) { S.phase = 'strike'; S.t = 0; p.vx = 0; }
    } else {
      p.vx = 0; this.move(p, dt, true, GRAV);
      const idx = Math.floor((S.t - 0.12) / 0.06);
      while (S.done <= idx && S.done < S.hits.length) {
        const e = S.hits[S.done++];
        if (e.dead) continue;
        e.hp -= 32; e.flash = 0.15; this.addCombo();
        this.hitFx(e.x, e.y, e.scale, { x: e.x - S.dir * 4 * e.scale, y: e.y - 9 * e.scale }, S.dir, { heavy: true, blood: 10, power: 180, color: '#ffd166' }); this.sfx.heavy(); this.shake(0.6);
        if (e.hp <= 0) this.killEnemy(e, S.dir, 420, 220, true, 'special');
        else { e.state = 'air'; e.knock = true; e.vy = -260; e.vx = S.dir * 120; e.onGround = false; }
      }
      if (S.t >= 0.55) { this.special = null; p.iframes = 0.5; if (S.hits.length) { this.flash = 0.35; this.slow(0.5, 0.3); } }
    }
  }

  // ============================== PELURU, PICKUP, GHOST ==============================
  private updateBullets(dt: number) {
    const p = this.player;
    for (const b of this.bullets) {
      b.life -= dt;
      if (b.kind === 'arrow') b.vy += 330 * dt;
      const steps = Math.max(1, Math.ceil(Math.hypot(b.vx, b.vy) * dt / 5));
      for (let s = 0; s < steps && b.life > 0; s++) { b.x += b.vx * dt / steps; b.y += b.vy * dt / steps; this.bulletStep(b, p); }
    }
    this.bullets = this.bullets.filter((b) => b.life > 0);
    for (const s of this.stuck) s.life -= dt;
    this.stuck = this.stuck.filter((s) => s.life > 0);
  }
  private bulletStep(b: Bullet, p: Player) {
    const c = Math.floor(b.x / T), r = Math.floor(b.y / T), tile = this.tiles[r]?.[c];
    if (tile === 'G' && b.mine) { this.breakGlass(c, r, Math.sign(b.vx) || 1, b.x, b.y); if (b.kind === 'pellet' || b.kind === 'bullet') { b.life = 0; return; } }
    else if (this.solidAt(b.x, b.y, false) && tile !== 'g') {
      b.life = 0;
      if (b.kind === 'beam') { this.fx.spark(b.x, b.y, 10, MAKO, b.vx > 0 ? Math.PI : 0, 1, 200); this.fx.shockwave(b.x, b.y, 10, MAKO, 0.2); }
      else if (b.kind === 'arrow') { this.stuck.push({ x: b.x, y: b.y, ang: Math.atan2(b.vy, b.vx), life: 9 }); this.sfx.arrowWood(); }
      else { this.fx.spark(b.x, b.y, 5, '#ffd166', b.vx > 0 ? Math.PI : 0, 0.8, 140); this.sfx.bulletWall(); }
      return;
    }
    if (!b.mine) {
      if (p.dead || p.door || Math.abs(b.x - p.x) > 5 || b.y < p.y - 16 || b.y > p.y + 1) return;
      const facing = p.facing === -Math.sign(b.vx);
      if (facing && (p.parryT > 0 || p.phase === 'active')) { b.vx = -b.vx * 1.4; b.mine = true; b.dmg = 20; b.kb = 260; this.sfx.parry(); this.fx.spark(b.x, b.y, 10, '#ffd166', b.vx > 0 ? 0 : Math.PI, 0.6, 200); this.texts.add(p.x, p.y - 26, 'BALIK!', '#ffd166', 1, 0.7); this.slow(0.25, 0.3); return; }
      if (p.iframes > 0 || p.dashT > 0) return;
      if (p.blocking && facing) { b.life = 0; this.fx.spark(b.x, b.y, 6, '#9fe8ff', b.vx > 0 ? Math.PI : 0, 0.6, 140); this.sfx.parry(); p.hp -= 1; return; }
      b.life = 0; this.sfx.bulletFlesh(); this.damagePlayer(b.dmg, Math.sign(b.vx), false, b.x, b.y);
      return;
    }
    for (const bm of this.bombs) if (Math.abs(bm.x - b.x) < 4 && Math.abs(bm.y - 3 - b.y) < 4) { bm.fuse = 0; bm.mine = true; b.life = 0; this.texts.add(bm.x, bm.y - 14, 'DOR!', '#ffd166', 1, 0.6); return; }
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.5 || (b.hit && b.hit.has(e.id))) continue;
      const top = e.y - BODY_H * e.scale, wide = b.kind === 'beam' ? 5 : 0;
      if (Math.abs(b.x - e.x) > 4 * e.scale + wide || b.y < top - wide * 2 || b.y > e.y + 1 + wide) continue;
      this.shootEnemy(e, b, top);
      if (b.kind === 'beam' || (b.kind === 'arrow' && (b.power ?? 0) >= 0.95)) { (b.hit ??= new Set()).add(e.id); if (b.kind === 'arrow' && b.hit.size > 1) b.life = 0; continue; }
      b.life = 0; break;
    }
    if (b.life > 0) for (const pr of this.props) {
      // perabot tinggi di latar (pohon, patung, rak, lemari, mesin) tidak menelan peluru — hanya perabot rendah di depan
      if (pr.broken || pr.h > 18 || pr.ch === 'R' || Math.abs(pr.x + 8 - b.x) > 7 || b.y < pr.yF - pr.h || b.y > pr.yF) continue;
      this.damageProp(pr, Math.sign(b.vx) || 1, b.kind === 'pellet' ? 1 : 2);
      if (b.kind !== 'beam') b.life = 0;
      break;
    }
  }
  private shootEnemy(e: Enemy, b: Bullet, top: number) {
    const dir = Math.sign(b.vx) || 1;
    if (e.kind === 'shield' && b.kind !== 'beam' && (e.state === 'idle' || e.state === 'hurt' || e.state === 'block' || e.state === 'windup') && dir === -e.facing) { this.fx.spark(b.x, b.y, 6, '#cfe3ff', dir > 0 ? Math.PI : 0, 0.7, 180); this.sfx.ricochet(); return; }
    const head = b.kind !== 'beam' && b.y < top + 4 * e.scale;
    const dmg = b.dmg * (head ? 2 : 1);
    e.hp -= dmg; e.flash = 0.1; this.addCombo(); this.addOfa(1);
    this.player.chi = Math.min(100, this.player.chi + 1.5);
    this.score += Math.round(dmg * 8);
    if (head && b.kind !== 'pellet') { this.sfx.headshot(); this.texts.add(e.x, e.y - 28, 'HEADSHOT!', '#ff5a5a', 1, 0.8); }
    if (b.kind === 'arrow') { this.sfx.arrowFlesh((b.power ?? 0) > 0.8); (e.arrows ??= []).push({ dx: b.x - e.x, dy: b.y - e.y, ang: Math.atan2(b.vy, b.vx) }); }
    else if (b.kind === 'beam') this.sfx.axeHit(true); else this.sfx.bulletFlesh();
    this.hitFx(e.x, e.y, e.scale, { x: b.x, y: b.y }, dir, { heavy: b.kind === 'beam' || head, blood: b.kind === 'pellet' ? 3 : 7, power: 150 + b.kb * 0.3, color: b.kind === 'beam' ? MAKO : undefined });
    e.react = { zone: head ? 'head' : 'torso', t: 0.01, dur: 0.46, dir: dir > 0 ? 0 : Math.PI, amp: 1, side: 1 };
    if (e.hp <= 0) { this.killEnemy(e, dir, b.kb, b.kind === 'beam' ? 80 : 30, b.kind !== 'pellet'); return; }
    if (e.def.armor && b.kind !== 'beam' && b.kind !== 'pellet') { e.vx += dir * 20; return; }
    if (b.kind === 'beam' || (b.kind === 'pellet' && b.kb > 200)) { e.state = 'air'; e.knock = b.kind === 'beam' || Math.random() < 0.45; e.vx = dir * b.kb * 0.55; e.vy = Math.min(e.vy, -110); e.onGround = false; e.atk = null; this.releaseToken(e); return; }
    if (e.state !== 'air') { e.state = 'hurt'; e.stateT = 0.3; e.atk = null; this.releaseToken(e); }
    e.vx = dir * b.kb * 0.5;
  }
  private updatePickups(dt: number) {
    for (const k of this.pickups) {
      k.life -= dt; k.vy = Math.min(MAX_FALL, k.vy + GRAV * dt);
      const ny = k.y + k.vy * dt;
      if (this.solidAt(k.x, ny, false) || this.platTop(k.x, ny)) { k.y = Math.floor(ny / T) * T; k.vy = k.vy > 80 ? -k.vy * 0.3 : 0; } else k.y = ny;
    }
    this.pickups = this.pickups.filter((k) => k.life > 0);
  }
  private ghost(o: StickOpts, color: string) { this.ghosts.push({ o: { ...o, c: color, c2: color, outline: null, eyes: color, flash: false }, life: 0.22, max: 0.22 }); if (this.ghosts.length > 40) this.ghosts.shift(); }
  private ghostEnemy(e: Enemy) { if (Math.random() < 0.5) this.ghost(this.enemyOpts(e), e.kind === 'master' ? '#ffd23c' : '#ff8a5a'); }
  private updateGhosts(dt: number) { for (const g of this.ghosts) g.life -= dt; this.ghosts = this.ghosts.filter((g) => g.life > 0); }

  // ============================== SENJATA KUNGFU DRIFTER ==============================
  private savedWeapon(): WeaponKind {
    return 'fist';
  }
  setWeapon(w: WeaponKind) {
    const p = this.player;
    if (!p || p.dead) return;
    if (p.weapon === w) {
      if (w === 'guandao') { this.br.syncIn(0); this.br.gd.trick(this.br); }
      if (w === 'boxing') { const order: BoxStance[] = ['ali', 'tyson', 'ippo']; p.boxStance = order[(order.indexOf(p.boxStance) + 1) % 3]; const d = BOX_STANCES[p.boxStance]; this.texts.add(p.x, p.y - 30, d.name, d.accent, 1, 0.9); this.sfx.boxing(0.4); }
      this.wheelT = 1.2;
      return;
    }
    const W = WEAPONS[w];
    p.weapon = w; p.phase = 'none'; p.move = null; p.moveKey = null; p.seq = ''; p.bowDraw = 0; p.reloadT = 0; p.shootT = 0;
    p.swingA = W.rest; p.swingPrev = W.rest;
    p.bladeA = p.facing > 0 ? 0 : Math.PI; p.bladePrevA = p.bladeA; p.sheatheT = 0; p.busterRest = 0;
    p.buCharging = false; p.buCharge = 0; p.sgPhase = 'ready'; p.sgBuf = false; p.twirlT = 0; this.trick = null; p.bufferKey = null;
    this.br.onEquip(w);
    try { localStorage.setItem('office_weapon', w); } catch { /* */ }
    this.wheelT = 1.3;
    this.fx.ring(p.x, p.y - 8, 3, 14, W.color, 0.25, 1);
    this.texts.add(p.x, p.y - 30, W.name, W.color, 1, 0.9);
    if (W.kind === 'blade') this.sfx.sheathe(); else if (W.kind === 'gun') this.sfx.leverClack(); else if (W.kind === 'bow') this.sfx.bowNock(); else if (W.kind === 'glove') this.sfx.boxing(0.3); else this.sfx.select();
    this.pushUI(true);
  }
  cycleWeapon(dir: number) { const i = WEAPON_ORDER.indexOf(this.player.weapon); this.setWeapon(WEAPON_ORDER[(i + dir + WEAPON_ORDER.length) % WEAPON_ORDER.length]); }
  private shoulder(): Vec { const p = this.player; return { x: p.x + p.facing * 0.5, y: p.y - 8.5 }; }
  private swingSound(m: Move) {
    const p = this.player;
    switch (m.sfx) {
      case 'slash': this.sfx.slash(m.finisher ? 0.8 : 1.1); break;
      case 'axe': if (p.weapon === 'bat') this.sfx.swing(0.8); else this.sfx.axeSwing(); if (p.weapon === 'buster') this.sfx.busterHum(0.6); break;
      case 'dual': this.sfx.dualSwing(); break;
      case 'nunchaku': this.sfx.swing(1.4); this.sfx.chainRattle(); break;
      case 'yoyo': this.sfx.yoyoThrow(m.arc >= Math.PI - 0.01); break;
      default: this.sfx.swing(m.sfx === 'heavy' ? 0.7 : m.sfx === 'kick' ? 0.85 : 1.1);
    }
  }
  private hitSound(m: Move, heavy: boolean) {
    const p = this.player;
    switch (m.sfx) {
      case 'slash': this.sfx.slashHit(heavy); break;
      case 'axe': if (p.weapon === 'bat') this.sfx.batCrack(); else this.sfx.axeHit(heavy); break;
      case 'dual': this.sfx.dualHit(); break;
      case 'nunchaku': this.sfx.nunchakuHit(heavy); break;
      case 'yoyo': this.sfx.yoyoHit(heavy); break;
      case 'punch': if (p.weapon === 'boxing') this.sfx.boxing(heavy ? 0.9 : 0.5); else this.sfx.punch(); break;
      case 'kick': if (p.weapon === 'boxing') this.sfx.boxing(0.7); else this.sfx.kick(); break;
      default: if (p.weapon === 'boxing') this.sfx.boxing(1); else this.sfx.heavy();
    }
  }
  private fireBeam() {
    const p = this.player;
    this.bullets.push({ x: p.x + p.facing * 14, y: p.y - 9, vx: p.facing * 300, vy: 0, life: 1.2, dmg: 10 * this.gates.dmgMul, mine: true, kb: 340, kind: 'beam', hit: new Set() });
    this.fx.shockwave(p.x + p.facing * 12, p.y - 9, 12, MAKO, 0.25); this.flash = Math.max(this.flash, 0.15); this.sfx.busterHum(1); this.shake(0.4);
  }
  private groundShock() {
    const p = this.player, x = p.x + p.facing * 22, y = p.y, c = WEAPONS[p.weapon].trail;
    this.fxBack.shockwave(x, y - 2, 30, c, 0.35); this.fx.dust(x, y, 10); this.crack(x, y + 1, false); this.shake(0.8); this.sfx.slam();
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.5 || Math.abs(e.x - x) > 34 || Math.abs(e.y - y) > 6 || p.hitSet.has(e.id)) continue;
      e.hp -= 3 * this.gates.dmgMul; e.flash = 0.1; this.addCombo();
      if (e.hp <= 0) { this.killEnemy(e, Math.sign(e.x - p.x) || 1, 200, 120, true); continue; }
      if (!e.def.armor) { e.state = 'air'; e.knock = true; e.vy = -190; e.vx = (Math.sign(e.x - p.x) || 1) * 70; e.onGround = false; e.atk = null; this.releaseToken(e); }
    }
  }
  /** IAI SENYAP: semua yang dilewati tebasan baru menyemburkan darah saat pedang disarungkan */
  private iaiDetonate() {
    const p = this.player, marks = p.iaiMarks.filter((e) => !e.dead);
    p.iaiMarks = [];
    this.sfx.sheathe();
    if (!marks.length) return;
    this.flash = Math.max(this.flash, 0.3); this.slow(0.6, 0.25); this.shake(0.9); this.zoomPunch(2.0);
    this.texts.add(p.x, p.y - 34, 'ZAN!', '#ffffff', 1, 1);
    for (const e of marks) {
      e.hp -= 24 * this.gates.dmgMul; e.flash = 0.15; this.addCombo(); this.addOfa(3);
      this.hitFx(e.x, e.y, e.scale, { x: e.x - p.facing * 3, y: e.y - 9 * e.scale }, p.facing, { heavy: true, blood: 16, power: 200, kill: e.hp <= 0 });
      this.sfx.slashHit(true);
      if (e.hp <= 0) this.killEnemy(e, p.facing, 260, 60, true);
      else { e.state = 'air'; e.knock = true; e.vy = -150; e.vx = p.facing * 90; e.onGround = false; e.atk = null; }
    }
  }
  private grabTarget(range: number): Enemy | null {
    const p = this.player; let best: Enemy | null = null, bd = range;
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.6 || e.state === 'door' || e.state === 'spawn' || e.state === 'air' || Math.abs(e.y - p.y) > 8) continue;
      const d = Math.abs(e.x - p.x);
      if (d < bd && (Math.sign(e.x - p.x) === p.facing || d < 14)) { bd = d; best = e; }
    }
    return best;
  }
  // ---- senjata api & busur
  /** senjata jarak jauh gaya V2 (gunInput / shotgunInput / bowInput) */
  private updateGuns(dt: number, lightHit: boolean, heavyHit: boolean, lh: boolean, up: boolean, down: boolean) {
    const p = this.player, W = WEAPONS[p.weapon], G = W.gun;
    p.recoil = Math.max(0, p.recoil - dt * 6); p.shootT = Math.max(0, p.shootT - dt); p.fireCd = Math.max(-1, p.fireCd - dt);
    this.trickCd = Math.max(0, this.trickCd - dt);
    if (this.trick) { this.updateTrick(dt); return; }
    if (!G) return;
    if (!p.mouseAim) p.aimRel += ((up ? -0.45 : down ? 0.32 : 0) - p.aimRel) * Math.min(1, dt * 14);
    const id = p.weapon;
    if (id === 'shotgun') {
      p.sgT = Math.max(0, p.sgT - dt);
      if (p.sgPhase === 'cock' && p.sgT <= 0) { p.sgPhase = 'ready'; this.sfx.leverClack(); if (p.sgBuf && (p.ammo.shotgun ?? 0) > 0 && p.phase === 'none') { p.sgBuf = false; p.sgPhase = 'cock'; p.sgT = 0.42; this.fireGun(G, 'shotgun'); } }
      if (p.sgPhase === 'load' && p.sgT <= 0) { p.ammo.shotgun = Math.min(G.mag, (p.ammo.shotgun ?? 0) + 1); this.sfx.shellIn(); if ((p.ammo.shotgun ?? 0) < G.mag) p.sgT = G.reload; else { p.sgPhase = 'ready'; this.sfx.spinCock(); this.br.sgSpin = 1; } }
      const attacking = p.phase !== 'none', shells = p.ammo.shotgun ?? 0;
      if (heavyHit && !attacking && p.onGround) {
        if (shells < G.mag && p.sgPhase !== 'load') { p.sgPhase = 'load'; p.sgT = G.reload; this.texts.add(p.x, p.y - 26, 'RELOAD', '#ffd27f', 1, 0.5); this.sfx.leverClick(); }
        else if (p.sgPhase === 'ready') { this.br.sgSpin = 1; this.sfx.spinCock(); }
      }
      if (lightHit && p.onGround) {
        if (shells > 0 && !attacking && (p.sgPhase === 'ready' || p.sgPhase === 'load')) { p.sgPhase = 'cock'; p.sgT = 0.42; this.fireGun(G, 'shotgun'); }
        else if (shells > 0 && p.sgPhase === 'cock' && !attacking) p.sgBuf = true;
        else if (shells === 0 || attacking) { if (shells === 0 && this.time - this.sgDryT > 1.2) { this.sgDryT = this.time; this.sfx.dryFire(); this.sayP('PENTUNG!', '#ffb347'); } if (p.sgPhase === 'load') p.sgPhase = 'ready'; this.queueAttack('L'); }
      } else if (shells === 0 && lh && p.onGround && !p.buffer && (p.phase === 'none' || p.phase === 'recover')) { if (p.sgPhase === 'load') p.sgPhase = 'ready'; this.queueAttack('L'); }
      return;
    }
    if (p.reloadT > 0) { p.reloadT -= dt; if (p.reloadT <= 0) { p.ammo[id] = G.mag; this.sfx.leverClack(); } }
    if (p.phase !== 'none' || p.dashT > 0) return;
    if (W.kind === 'bow') {
      if (heavyHit && this.trickCd <= 0) { this.startTrick('bow'); return; }
      if (lh) {
        const before = p.bowDraw; p.bowDraw = Math.min(1, p.bowDraw + dt / 0.7);
        if (before === 0) this.sfx.bowNock();
        if (Math.floor(before * 6) !== Math.floor(p.bowDraw * 6)) this.sfx.bowCreak(p.bowDraw);
        if (p.bowDraw >= 1 && !p.bowFull) { p.bowFull = true; this.sfx.bowFull(); }
      } else if (p.bowDraw > 0.12 && p.fireCd <= 0) { this.fireArrow(p.bowDraw); p.bowDraw = 0; p.bowFull = false; p.fireCd = G.cd; }
      else { p.bowDraw = Math.max(0, p.bowDraw - dt * 4); p.bowFull = false; }
      return;
    }
    // pistol / senapan (gunInput V2): kanan = trick shot, kiri = tembak (pistol semi, senapan otomatis)
    if (heavyHit && this.trickCd <= 0) { this.startTrick('gun'); return; }
    if (!lh && Math.abs(p.vx) < 6 && p.onGround) { p.gunIdle += dt; if (p.gunIdle > 2.6 && p.twirlT <= 0) { p.twirlT = 0.7; p.gunIdle = 0; this.sfx.spinCock(); } } else p.gunIdle = 0;
    if (lightHit || lh) p.twirlT = 0;
    const want = id === 'pistol' ? lightHit || (lh && p.fireCd <= -0.15) : lh;
    if (!want || p.fireCd > 0 || p.reloadT > 0) return;
    if ((p.ammo[id] ?? 0) <= 0) { this.sfx.dryFire(); p.reloadT = G.reload; p.fireCd = 0.25; return; }
    this.fireGun(G, id);
  }
  private fireGun(G: GunSpec, id: string) {
    const p = this.player, sh = this.shoulder();
    const aim = toWorld(p.aimRel, p.facing);
    const L = id === 'pistol' ? 9 : id === 'rifle' ? 14 : 15;
    const mx = sh.x + Math.cos(aim) * L, my = sh.y + 1 + Math.sin(aim) * L;
    for (let i = 0; i < G.pellets; i++) {
      const a = aim + rnd(-G.spread, G.spread), sp = G.speed * (G.pellets > 1 ? rnd(0.85, 1.1) : 1);
      this.bullets.push({ x: mx, y: my, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: G.pellets > 1 ? 0.45 : 1.1, dmg: G.dmg * this.gates.dmgMul, mine: true, kb: G.kb, kind: G.pellets > 1 ? 'pellet' : 'bullet' });
    }
    p.ammo[id] = (p.ammo[id] ?? 0) - 1; p.fireCd = G.cd; p.recoil = 1; p.shootT = 0.45;
    const pan = clamp((p.x - this.cam.x) / 200, -1, 1);
    if (id === 'shotgun') { this.sfx.shotgunBlast(pan); this.shake(0.5); p.vx -= p.facing * 70; }
    else { this.sfx.shot(id === 'rifle' ? 'rifle' : 'pistol', pan); this.shake(id === 'rifle' ? 0.12 : 0.18); }
    this.fx.impact(mx + Math.cos(aim) * 2, my + Math.sin(aim) * 2, id === 'shotgun' ? 7 : 4, '#ffd166');
    this.fx.spark(mx, my, id === 'shotgun' ? 8 : 3, '#ffe9a0', aim, 0.35, 220); this.addLight(mx, my, id === 'shotgun' ? 70 : 46, '#ffd27f', 0.07);
    this.fx.smoke(mx, my, id === 'shotgun' ? 4 : 1, '#9a9a9a', 18, 0.5);
    this.fx.debris(sh.x, sh.y + 1, 1, [id === 'shotgun' ? '#c43030' : '#d9a441'], aim + Math.PI - p.facing * 1.2, 90);
    if (Math.random() < 0.5) this.sfx.casing();
    if (p.ammo[id] <= 0 && id !== 'shotgun') { p.reloadT = G.reload; this.sfx.leverClick(); }
  }
  private fireArrow(power: number) {
    const p = this.player, sh = this.shoulder();
    const aim = toWorld(p.aimRel, p.facing);
    const sp = 260 + 330 * power;
    const x = sh.x + Math.cos(aim) * 10, y = sh.y + 1 + Math.sin(aim) * 10;
    this.bullets.push({ x, y, vx: Math.cos(aim) * sp, vy: Math.sin(aim) * sp, life: 2.2, dmg: (6 + 18 * power) * this.gates.dmgMul, mine: true, kb: 120 + 220 * power, kind: 'arrow', power });
    this.sfx.bowRelease(power); p.shootT = 0.3;
    if (power >= 0.99) { this.fx.ring(x, y, 2, 10, '#c8f08f', 0.2, 1); this.texts.add(p.x, p.y - 28, 'TEMBUS!', '#c8f08f', 1, 0.6); }
  }

  // ============================== MODE X: ONE FOR ALL ==============================
  private addOfa(n: number) {
    const p = this.player;
    if (!p || p.ofaOn || !(n > 0)) return;
    p.ofa = Math.min(100, p.ofa + n);
    if (p.ofa >= 25 && !this.ofaSaid) { this.ofaSaid = true; this.texts.add(p.x, p.y - 34, 'ONE FOR ALL SIAP - X', '#57e6ff', 1, 1.2); this.sfx.select(); }
  }
  private tryOfa() {
    const p = this.player;
    if (p.dead || p.ofaOn || this.exec || this.slam || this.clash) return;
    if (p.ofa < 25) { this.texts.add(p.x, p.y - 26, 'OFA BELUM SIAP', '#3a6a78', 1, 0.6); this.sfx.empty(); return; }
    p.ofaOn = true; this.ofaSaid = true;
    this.say('ONE FOR ALL', 'DUNIA MELAMBAT - KAMU MELESAT', '#57e6ff', 1.4);
    this.sfx.announce(); this.sfx.focus();
    this.flash = Math.max(this.flash, 0.35); this.shake(0.8); this.slow(0.4, 0.25);
    this.fxBack.shockwave(p.x, p.y - 6, 60, '#57e6ff', 0.5); this.fx.ring(p.x, p.y - 8, 2, 26, '#ffffff', 0.35, 2);
    p.iframes = Math.max(p.iframes, 0.6);
  }
  private updateOfa(raw: number) {
    const p = this.player;
    if (!p.ofaOn) { this.lock = null; return; }
    let best: Enemy | null = null, bd = 340;
    const st = this.storyOf(p.y);
    for (const e of this.enemies) { if (e.dead || e.alpha < 0.5) continue; const d = Math.abs(e.x - p.x) + (this.storyOf(e.y) === st ? 0 : 400); if (d < bd) { bd = d; best = e; } }
    this.lock = best;
    p.ofa = Math.max(0, p.ofa - raw * 8);
    if (Math.random() < 0.85) { const a = rnd(0, Math.PI * 2); this.fx.spark(p.x + Math.cos(a) * 6, p.y - 8 + Math.sin(a) * 7, 1, Math.random() < 0.6 ? '#7df9ff' : '#ffffff', a, 0.8, 50); }
    if (Math.random() < 0.3) this.fx.zap(p.x + rnd(-6, 6), p.y - rnd(2, 16), 1);
    if (Math.random() < 0.35) { const pp = this.currentPlayerPose(); this.ghost(this.playerOpts(pp.pose, pp.t), '#57e6ff'); }
    if (p.ofa <= 0) { p.ofa = 0; p.ofaOn = false; this.lock = null; this.ofaSaid = false; this.say('ONE FOR ALL SELESAI', '', '#8a8a8a', 0.9); this.fx.ring(p.x, p.y - 8, 2, 18, '#57e6ff', 0.3, 1); }
  }
  private drawOfaAura(b: CanvasRenderingContext2D, p: Player) {
    b.save(); b.globalCompositeOperation = 'lighter';
    const g = b.createRadialGradient(p.x, p.y - 8, 2, p.x, p.y - 8, 16); g.addColorStop(0, 'rgba(87,230,255,0.35)'); g.addColorStop(1, 'rgba(87,230,255,0)');
    b.fillStyle = g; b.fillRect(p.x - 16, p.y - 24, 32, 32);
    b.restore();
    for (let i = 0; i < 3; i++) { let x = p.x + rnd(-6, 6), y = p.y - rnd(0, 16); for (let k = 0; k < 3; k++) { const nx = x + rnd(-3, 3), ny = y + rnd(-4, 1); pline(b, x, y, nx, ny, Math.random() < 0.5 ? '#7df9ff' : '#ffffff'); x = nx; y = ny; } }
  }

  // ============================== MODE N: DELAPAN GERBANG (modul asli) ==============================
  private setupGates() {
    const self = this;
    this.ga = {
      get state() { return self.state; }, get player() { return self.gp; }, get enemies() { return self.enemies; },
      texts: this.texts, sfx: this.sfx,
      particles: {
        shockwave: (x: number, _y: number, r: number, c: string, l?: number) => self.fx.groundRing(x, self.player.y, r, c, l ?? 0.4),
        ring: (x: number, _y: number, _r0: number, r1: number, c: string, l: number) => self.fx.groundRing(x, self.player.y, r1, c, l),
        burst: (x: number, y: number, n: number, c: string, sp: number, l: number, sz?: number) => self.fx.burst(x, y, n, c, sp, l, sz),
        smoke: (x: number, y: number, n: number, c: string, sp?: number, l?: number) => self.fx.smoke(x, y, n, c, sp, l),
      },
      say: (text: string, c: string, _s?: number, life?: number) => self.showToast(text.replace('KLIK KANAN', 'K').replace(/  +/g, ' - '), c, life ?? 1.2),
      shake: (t: number) => self.shake(t),
      flash: (_c: string, a: number) => { self.flash = Math.max(self.flash, a * 2.5); },
      slow: (d: number, k: number) => self.slow(d, k),
      get zoomKick() { return 0; }, set zoomKick(v: number) { self.zoomPunch(BASE_ZOOM + v * 3); },
      get hitstop() { return self.hitstop; }, set hitstop(v: number) { self.hitstop = Math.min(0.12, v); },
    };
  }
  private syncGp() {
    const p = this.player, g = this.gp;
    if (!p) return;
    g.x = p.x; g.y = p.y; g.z = 0; g.vx = p.vx; g.vy = p.vy; g.facing = p.facing; g.aim = p.facing > 0 ? 0 : Math.PI; g.weapon = p.weapon;
  }
  private readGp() {
    const p = this.player, g = this.gp;
    if (g.holdT > 0) { p.holdT = 0.32; p.holdPose = g.holdPose as Pose; g.holdT = 0; }
  }
  // ---- LOTUS TERSEMBUNYI (gerbang 3+) & IZUNA DROP (Hayabusa): bantingan sinematik vertikal side view
  private startSlam(kind: 'lotus' | 'izuna', e: Enemy) {
    const p = this.player;
    this.slam = { kind, e, t: 0, phase: kind === 'lotus' ? 0 : 1, dir: Math.sign(e.x - p.x) || p.facing, x0: p.x, c: kind === 'lotus' ? '#6fd6ff' : '#9ff8ff' };
    p.facing = this.slam.dir; p.phase = 'none'; p.move = null; p.moveKey = null; p.iframes = 5; p.vx = 0; p.dashT = 0;
    e.state = 'stagger'; e.stateT = 9; e.atk = null; e.vx = 0; this.releaseToken(e); e.facing = -p.facing;
    for (const o of this.enemies) if (o !== e && !o.dead) o.atkCd = Math.max(o.atkCd, 1.6);
    if (kind === 'lotus') this.gates.lotus = true;
    this.say(kind === 'lotus' ? 'LOTUS TERSEMBUNYI!' : 'IZUNA DROP!', kind === 'lotus' ? 'OMOTE RENGE' : 'RYU HAYABUSA', this.slam.c, 1.4);
    this.sfx.announce(); this.sfx.dash(); this.sfx.whoosh(); this.flash = Math.max(this.flash, 0.25);
  }
  private slamPose(): { pose: Pose; t: number } {
    const S = this.slam!;
    if (S.phase === 0) return { pose: 'flying', t: 0.5 };
    if (S.phase === 1) return S.kind === 'lotus' ? { pose: 'cranekick', t: clamp(S.t / 0.22, 0, 1) } : { pose: 'h_izuna', t: clamp(S.t / 0.22, 0, 0.5) };
    if (S.phase === 2) return S.kind === 'lotus' ? { pose: 'monkeyflip', t: 0.5 } : { pose: 'h_izuna', t: 0.6 };
    return S.kind === 'lotus' ? { pose: 'kneedrop', t: 0.5 } : { pose: 'h_izuna', t: 0.85 };
  }
  private updateSlam(dt: number) {
    const S = this.slam!, p = this.player, e = S.e;
    S.t += dt; this.slowT = Math.max(this.slowT, 0.1); this.slowK = S.phase >= 2 ? 0.45 : 0.6;
    p.iframes = Math.max(p.iframes, 1);
    if (e.dead && S.phase < 3) { this.endSlam(); return; }
    if (S.phase === 0) {
      const tx = e.x - S.dir * (9 + 3 * e.scale), u = clamp(S.t / 0.18, 0, 1);
      p.x = S.x0 + (tx - S.x0) * (1 - Math.pow(1 - u, 3)); p.vx = 0;
      this.ghost(this.playerOpts('flying', 0.5), S.c); this.fx.lines(p.x - S.dir * 6, p.y - 8, 2, '#bfeaff', S.dir > 0 ? Math.PI : 0, 240);
      if (u >= 1) { S.phase = 1; S.t = 0; }
      this.move(p, dt, true, GRAV);
      return;
    }
    if (S.phase === 1) {
      p.vx = 0; this.move(p, dt, true, GRAV);
      if (S.t >= 0.09 && e.state !== 'air') {
        e.state = 'air'; e.knock = true; e.onGround = false; e.vy = -430; e.vx = 0; e.flash = 0.12; e.y -= 2;
        this.fxBack.shockwave(e.x, e.y - 18, 16, S.c, 0.3); this.fxBack.impact(e.x, e.y - 20, 9, '#ffffff'); this.fxBack.blood(e.x, e.y - 14, 8, -Math.PI / 2, 160, '#d40000', 0.5);
        this.fx.flash(e.x - S.dir * 3, e.y - 10, 3); this.sfx.launch(); this.sfx.heavy(); this.shake(0.6); this.hitstop = 0.06; this.addCombo();
      }
      if (S.t >= 0.24) { S.phase = 2; S.t = 0; p.vy = -410; p.onGround = false; this.sfx.whoosh(); }
      this.move(e, dt, false, GRAV * 0.75);
      return;
    }
    if (S.phase === 2) {
      this.move(e, dt, false, GRAV * 0.75);
      p.x += (e.x - S.dir * 4 - p.x) * Math.min(1, dt * 12);
      this.move(p, dt, true, GRAV * 0.8);
      e.rot += dt * 14 * S.dir;
      this.ghost(this.playerOpts(this.slamPose().pose, 0.5), S.c);
      if (S.t >= 0.3 || (p.vy >= -20 && S.t > 0.15)) { S.phase = 3; S.t = 0; this.sfx.whoosh(); this.texts.add(p.x, p.y - 34, S.kind === 'lotus' ? 'OMOTE RENGE!' : 'IZUNA!', S.c, 1, 0.8); }
      return;
    }
    p.vy = 560; e.vy = 600; e.vx = 0;
    e.x += (p.x + S.dir * 3 - e.x) * Math.min(1, dt * 14);
    e.rot += dt * 24 * S.dir;
    this.ghost(this.playerOpts(this.slamPose().pose, 0.5), S.c);
    this.fx.ember(p.x, p.y - 6, 2, S.c);
    const r = this.move(e, dt, false, 0);
    this.move(p, dt, true, 0);
    if (r.landed || S.t > 0.9) this.slamImpact();
  }
  private slamImpact() {
    const S = this.slam!, p = this.player, e = S.e;
    const x = e.x, y = e.y;
    e.hp -= (S.kind === 'lotus' ? 34 : 28) * this.gates.dmgMul; e.flash = 0.2; e.rot = 0; this.addCombo(); this.addOfa(6);
    this.fxBack.shockwave(x, y - 3, 46, S.c, 0.45); this.fx.shockwave(x, y - 2, 24, '#ffffff', 0.25);
    this.fx.dust(x, y, 18); this.fxBack.blood(x, y - 4, 24, -Math.PI / 2, 240, '#d40000', 1.1); this.fxBack.mist(x, y - 4, 6, -Math.PI / 2);
    this.crack(x - 6, y + 1, false); this.crack(x + 6, y + 1, false); this.crack(x, y + 2, false);
    this.shake(1.2); this.hitstop = 0.2; this.flash = Math.max(this.flash, 0.5); this.slow(0.8, 0.25); this.zoomPunch(2.4);
    this.sfx.slam(); this.sfx.heavy(); this.sfx.explosion();
    this.texts.add(x, y - 30, S.kind === 'lotus' ? 'LOTUS!' : 'IZUNA DROP!', S.c, 1, 1);
    if (e.hp <= 0) this.killEnemy(e, S.dir, 260, 80, true);
    else { e.state = 'air'; e.knock = true; e.vy = -90; e.vx = S.dir * 40; e.onGround = false; }
    for (const o of this.enemies) {
      if (o === e || o.dead || Math.abs(o.x - x) > 42 || Math.abs(o.y - y) > 8) continue;
      o.hp -= 4; o.flash = 0.1;
      if (o.hp <= 0) { this.killEnemy(o, Math.sign(o.x - x) || 1, 220, 120, true); continue; }
      if (!o.def.armor) { o.state = 'air'; o.knock = true; o.vy = -200; o.vx = (Math.sign(o.x - x) || 1) * 110; o.onGround = false; o.atk = null; this.releaseToken(o); }
    }
    p.vy = -170; p.vx = -S.dir * 70; p.onGround = false;
    this.score += S.kind === 'lotus' ? 800 : 600;
    this.endSlam();
  }
  private endSlam() { this.slam = null; this.gates.lotus = false; this.player.iframes = 0.6; }
  private drawWraps(b: CanvasRenderingContext2D) {
    const S = this.slam; if (!S || S.phase < 2) return;
    const p = this.player, e = S.e;
    for (let i = 0; i < 3; i++) { const t = this.real * 12 + i * 2.1; pline(b, p.x + Math.cos(t) * 3, p.y - 10 + Math.sin(t) * 3, e.x + Math.cos(t + 1) * 3, e.y - 8 * e.scale + Math.sin(t + 1) * 3, S.kind === 'lotus' ? '#f4f0e8' : '#9ff8ff'); }
  }

  // ============================== GAMBAR SENJATA ==============================
  private drawBullet(b: CanvasRenderingContext2D, bl: Bullet) {
    const sp = Math.hypot(bl.vx, bl.vy) || 1, ux = bl.vx / sp, uy = bl.vy / sp;
    if (bl.kind === 'arrow') { pline(b, bl.x, bl.y, bl.x - ux * 8, bl.y - uy * 8, '#c9a063'); b.fillStyle = '#dfe6ee'; b.fillRect(Math.round(bl.x), Math.round(bl.y), 1, 1); b.fillStyle = '#e8e8e8'; b.fillRect(Math.round(bl.x - ux * 8), Math.round(bl.y - uy * 8) - 1, 1, 2); return; }
    if (bl.kind === 'beam') {
      const a = Math.atan2(uy, ux), k = Math.min(1, bl.life / 0.3);
      b.save(); b.globalCompositeOperation = 'lighter'; b.fillStyle = 'rgba(125,255,200,0.22)'; b.fillRect(bl.x - 10, bl.y - 13, 16, 26); b.restore();
      crescent(b, bl.x - ux * 6, bl.y, 11, a - 1.15, a + 1.15, 3, MAKO, 0.9 * k, 0, 0, 1);
      return;
    }
    const len = bl.kind === 'pellet' ? 4 : 8;
    pline(b, bl.x, bl.y, bl.x - ux * len, bl.y - uy * len, bl.mine ? '#ffd166' : '#ffefa0');
    b.fillStyle = '#ffffff'; b.fillRect(Math.round(bl.x), Math.round(bl.y), 1, 1);
  }

  // ============================== GRAB & LEMPAR (G) ==============================
  private autoFace(ix: number) {
    const p = this.player;
    if (ix !== 0) { p.facing = ix; return; }
    const st = this.storyOf(p.y);
    let best: Enemy | null = null, bd = 44;
    for (const e of this.enemies) { if (e.dead || e.alpha < 0.5 || this.storyOf(e.y) !== st) continue; const d = Math.abs(e.x - p.x); if (d < bd) { bd = d; best = e; } }
    if (best && Math.sign(best.x - p.x) === -p.facing) {
      const front = this.enemies.some((e) => !e.dead && Math.sign(e.x - p.x) === p.facing && Math.abs(e.x - p.x) < bd + 6 && this.storyOf(e.y) === st);
      if (!front) p.facing = -p.facing;
    }
  }
  private tryGrab() {
    const p = this.player;
    if (p.phase !== 'none' || !p.onGround || p.dead || p.climbing) return;
    let best: Enemy | null = null, bd = 20;
    for (const e of this.enemies) {
      if (e.alpha < 0.6 || Math.abs(e.y - p.y) > 6 || e.outside) continue;
      if (!e.dead && (e.boss || e.def.armor || ['air', 'spawn', 'door', 'climb', 'clash', 'charge'].includes(e.state))) continue;
      if (e.dead && !e.onGround) continue;
      const d = Math.abs(e.x - p.x);
      if (d < bd && (Math.sign(e.x - p.x) === p.facing || d < 8)) { bd = d; best = e; }
    }
    if (!best) { this.texts.add(p.x, p.y - 26, 'TIDAK ADA YANG DIANGKAT', '#9aa3b8', 1, 0.5); return; }
    p.grab = best; p.grabT = 0; p.facing = Math.sign(best.x - p.x) || p.facing;
    if (!best.dead) { best.state = 'held'; best.atk = null; this.releaseToken(best); }
    best.vx = 0; best.vy = 0; best.onGround = false;
    p.holdT = 0.18; p.holdPose = 'grab';
    this.sfx.punch(); this.shake(0.2);
    this.texts.add(p.x, p.y - 30, best.dead ? 'ANGKAT!' : 'TANGKAP!', '#ffd27f', 1, 0.7);
  }
  private updateHeld(dt: number) {
    const p = this.player, e = p.grab;
    if (!e || e.alpha <= 0) { p.grab = null; return; }
    p.grabT += dt;
    const k = clamp(p.grabT / 0.2, 0, 1), ease = 1 - (1 - k) * (1 - k);
    e.x = p.x + p.facing * 7 * (1 - ease); e.y = p.y - 3 - 17 * ease;
    e.vx = 0; e.vy = 0; e.onGround = false; e.facing = -p.facing;
    e.rot = p.facing * (Math.PI / 2) * ease + (e.dead ? 0 : Math.sin(this.time * 18) * 0.12);
    if (!e.dead && p.grabT > 3.2) { this.texts.add(e.x, e.y - 12, 'LEPAS!', '#ff8a8a', 1, 0.6); this.dropHeld(); }
  }
  private releaseHeld(): Enemy | null {
    const p = this.player, e = p.grab;
    p.grab = null;
    if (e) e.rot = 0;
    return e;
  }
  private dropHeld() {
    const p = this.player, e = this.releaseHeld();
    if (!e) return;
    e.vx = p.facing * 40; e.vy = -60; e.onGround = false;
    if (!e.dead) { e.state = 'air'; e.knock = false; }
  }
  private throwHeld() {
    const p = this.player, e = this.releaseHeld();
    if (!e) return;
    const dir = p.facing;
    const tx = p.x + dir * 5;
    e.x = !this.solidAt(tx + dir * 4, p.y - 8, false) ? tx : p.x;
    e.y = !this.solidAt(e.x, p.y - 18, false) ? Math.min(e.y, p.y - 12) : p.y - 2;
    e.vx = dir * 390; e.vy = -140; e.vrot = dir * 13; e.onGround = false;
    if (!e.dead) { e.state = 'air'; e.knock = true; e.juggle = 0; e.hp -= 2; e.flash = 0.1; }
    p.holdT = 0.28; p.holdPose = 'throw'; p.vx -= dir * 30;
    this.sfx.whoosh(); this.sfx.heavy(); this.shake(0.35); this.addCombo(); this.score += 60;
    this.fx.lines(e.x, e.y, 4, '#ffffff', dir > 0 ? 0 : Math.PI, 300);
    this.texts.add(p.x, p.y - 32, e.dead ? 'LEMPAR MAYAT!' : 'LEMPAR!', '#ffd27f', 1, 0.8);
  }
  private slamHeld() {
    const p = this.player, e = this.releaseHeld();
    if (!e) return;
    const dir = p.facing;
    let x = p.x + dir * 11;
    if (this.solidAt(x + dir * 4, p.y - 6, false)) x = p.x;
    e.x = x; e.y = p.y; e.vx = dir * 30; e.vy = 0; e.onGround = true;
    p.holdT = 0.32; p.holdPose = 'stomp';
    this.fxBack.groundRing(x, p.y, 34, '#ffffff', 0.35); this.fx.dust(x, p.y, 14); this.crack(x, p.y + 1, false); this.crack(x + 5, p.y + 1, false);
    this.fxBack.blood(x, p.y - 4, 10, -Math.PI / 2, 150);
    this.shake(0.9); this.hitstop = Math.max(this.hitstop, 0.1); this.sfx.slam(); this.sfx.heavy(); this.addCombo(); this.addOfa(3);
    this.texts.add(x, p.y - 30, 'BANTING!', '#ffd166', 1, 0.9);
    if (!e.dead) { e.hp -= 13 * this.gates.dmgMul; e.flash = 0.15; e.sqx = 1.4; e.sqy = 0.6; this.score += 120; if (e.hp <= 0) this.killEnemy(e, dir, 60, 30, true); else { e.state = 'down'; e.stateT = 1.4; e.knock = true; } }
    for (const o of this.enemies) {
      if (o === e || o.dead || o.alpha < 0.6 || Math.abs(o.x - x) > 30 || Math.abs(o.y - p.y) > 6 || o.def.armor) continue;
      o.state = 'air'; o.knock = true; o.vy = -170; o.vx = (Math.sign(o.x - x) || 1) * 90; o.onGround = false; o.hp -= 3; o.atk = null; this.releaseToken(o);
      if (o.hp <= 0) this.killEnemy(o, Math.sign(o.x - x) || 1, 160, 80, false);
    }
  }

  // ============================== BOM & LEDAKAN ==============================
  private updateBombs(dt: number) {
    for (const bm of this.bombs) {
      bm.fuse -= dt; bm.spin += dt * 14;
      bm.vy = Math.min(MAX_FALL, bm.vy + GRAV * dt);
      const nx = bm.x + bm.vx * dt;
      if (this.solidAt(nx, bm.y - 3, false)) bm.vx = -bm.vx * 0.45; else bm.x = nx;
      const ny = bm.y + bm.vy * dt;
      if (bm.vy > 0 && (this.solidAt(bm.x, ny, false) || this.platTop(bm.x, ny))) {
        bm.y = Math.floor(ny / T) * T;
        if (bm.vy > 70) { bm.vy = -bm.vy * 0.38; this.sfx.casing(); } else bm.vy = 0;
        bm.vx *= 0.72;
      } else if (bm.vy < 0 && this.solidAt(bm.x, ny - 5, false)) bm.vy = 0;
      else bm.y = ny;
      if (Math.random() < 0.5) this.fx.add({ x: bm.x + Math.cos(bm.spin) * 2, y: bm.y - 6 + Math.sin(bm.spin), vx: rnd(-15, 15), vy: rnd(-40, -10), life: 0.25, c: Math.random() < 0.5 ? '#ffd166' : '#ff8a3d', s: 1, k: 7 });
      if (bm.fuse <= 0) { this.explode(bm.x, bm.y - 4, 30, bm.mine ? 26 : 20, bm.mine); bm.fuse = -99; }
    }
    this.bombs = this.bombs.filter((bm) => bm.fuse > -50);
  }
  private explode(x: number, y: number, r: number, dmg: number, fromPlayer: boolean) {
    this.sfx.explosion(); this.shake(1.0); this.hitstop = Math.max(this.hitstop, 0.05); this.flash = Math.max(this.flash, 0.22);
    this.addLight(x, y, 120, '#ffb347', 0.5);
    const floorY = this.storyOf(y) * STORY_PX + STORY_PX - T;
    this.fxBack.shockwave(x, y, r * 1.5, '#ffd166', 0.35); this.fx.groundRing(x, Math.min(floorY, y + 6), r * 1.8, '#ffe2a0', 0.4);
    this.fx.burst(x, y, 24, '#ffd166', 230, 0.5, 2); this.fx.burst(x, y, 14, '#ff6a3d', 170, 0.6, 2); this.fx.ember(x, y, 14, '#ffb347');
    this.fx.smoke(x, y, 16, '#3a3a3a', 55, 1.3); this.fx.debris(x, y, 10, ['#2a2a2a', '#5a4a3a', '#ff8a3d'], 0, 230);
    this.scorch(x, y, floorY);
    const p = this.player;
    if (!p.dead && Math.hypot(p.x - x, (p.y - 8 - y) * 1.25) < r + 6 && p.iframes <= 0 && p.dashT <= 0) this.damagePlayer(Math.round(dmg * (fromPlayer ? 0.35 : 1)), Math.sign(p.x - x) || 1, true, p.x, p.y - 8);
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.5 || e.state === 'held') continue;
      if (Math.hypot(e.x - x, (e.y - 8 - y) * 1.25) > r + 6) continue;
      const dir = Math.sign(e.x - x) || 1;
      e.hp -= dmg * (fromPlayer ? 1.5 : 0.9); e.flash = 0.15; this.addCombo();
      if (e.hp <= 0) { this.killEnemy(e, dir, 460, 280, true); e.spurt = 1; continue; }
      if (!e.def.armor || fromPlayer) { e.state = 'air'; e.knock = true; e.vx = dir * 230; e.vy = -290; e.onGround = false; e.atk = null; this.releaseToken(e); }
    }
    for (const c of this.civs) if (c.mode !== 'gone' && c.mode !== 'down' && Math.hypot(c.x - x, (c.y - 8 - y) * 1.25) < r + 14) this.knockCiv(c, Math.sign(c.x - x) || 1);
    for (const pr of this.props) if (!pr.broken && Math.abs(pr.x + 8 - x) < r + 4 && Math.abs(pr.yF - pr.h / 2 - y) < r) this.damageProp(pr, Math.sign(pr.x + 8 - x) || 1, 5);
    const rr = Math.floor(y / T);
    for (let c = Math.floor((x - r) / T); c <= Math.floor((x + r) / T); c++) if (this.tiles[rr]?.[c] === 'G') this.breakGlass(c, rr, Math.sign(c * T + 8 - x) || 1, x, y);
  }
  private scorch(x: number, y: number, floorY: number) {
    const g = this.dctx, st = this.storyOf(y);
    if (!this.theme(st).outdoor) {
      const top = Math.max(st * STORY_PX + T, y - 16);
      const rg = g.createRadialGradient(x, y, 1, x, y, 16);
      rg.addColorStop(0, 'rgba(12,10,8,0.7)'); rg.addColorStop(1, 'rgba(12,10,8,0)');
      g.fillStyle = rg; g.fillRect(x - 16, top, 32, Math.max(0, floorY - top));
    }
    g.fillStyle = 'rgba(10,8,6,0.75)'; g.fillRect(Math.round(x - 10), floorY, 20, 1); g.fillRect(Math.round(x - 6), floorY + 1, 12, 1);
  }

  // ============================== CAHAYA, GENANGAN, DEBU ==============================
  private addLight(x: number, y: number, r: number, c: string, life: number) {
    this.lights.push({ x, y, r, c, life, max: life });
    if (this.lights.length > 48) this.lights.shift();
  }
  private updateLights(dt: number) {
    for (const l of this.lights) l.life -= dt;
    this.lights = this.lights.filter((l) => l.life > 0);
    for (const pl of this.pools) pl.r = Math.min(pl.max, pl.r + dt * 3.2);
  }
  private sprites = new Map<string, HTMLCanvasElement>();
  private skyBuf = document.createElement('canvas'); private skyCtx = this.skyBuf.getContext('2d')!;
  private txtCache = new Map<string, HTMLCanvasElement>(); private vigCv: HTMLCanvasElement | null = null;
  private gradeTint(): [number, number, number] { const g = this.A.grade, k = this.A.gradeA; return [255 + (g[0] - 255) * k, 255 + (g[1] - 255) * k, 255 + (g[2] - 255) * k]; }
  /** teks pixel HUD disimpan sebagai gambar (bukan ratusan kotak tiap frame) */
  private tx(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, c: string, oc: string, scale = 1, align: 'left' | 'center' | 'right' = 'left') {
    const key = `${text}|${c}|${oc}|${scale}`;
    let cv = this.txtCache.get(key);
    if (!cv) {
      if (this.txtCache.size > 500) this.txtCache.clear();
      cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.ceil(textWidth(String(text).toUpperCase(), scale) + scale * 2)); cv.height = Math.ceil(scale * 7);
      pfontO(cv.getContext('2d')!, text, scale, scale, c, oc, scale, 'left');
      this.txtCache.set(key, cv);
    }
    const w = cv.width - scale * 2;
    const dx = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x;
    ctx.drawImage(cv, Math.round(dx) - scale, Math.round(y) - scale);
  }
  private vignette() {
    const W = this.canvas.width, H = this.canvas.height;
    if (!this.vigCv || this.vigCv.width !== W || this.vigCv.height !== H) {
      const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      const g = cv.getContext('2d')!, vg = g.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, W * 0.62);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.55)');
      g.fillStyle = vg; g.fillRect(0, 0, W, H); this.vigCv = cv;
    }
    return this.vigCv;
  }
  /** sprite pendar radial berwarna, resolusi = K piksel buffer per piksel dunia */
  private glowSprite(c: string, r: number) {
    const R = Math.max(4, Math.round(r / 4) * 4), key = `g${c}${R}${this.K}`;
    let cv = this.sprites.get(key);
    if (!cv) {
      cv = document.createElement('canvas'); const S = R * 2 * this.K; cv.width = cv.height = S;
      const g = cv.getContext('2d')!, gr = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
      gr.addColorStop(0, rgba(c, 1)); gr.addColorStop(0.45, rgba(c, 0.4)); gr.addColorStop(1, rgba(c, 0));
      g.fillStyle = gr; g.fillRect(0, 0, S, S); this.sprites.set(key, cv);
    }
    return cv;
  }
  private glow(b: CanvasRenderingContext2D, x: number, y: number, r: number, c: string, a: number) {
    if (a <= 0.01 || r < 2) return;
    b.globalAlpha = Math.min(1, a); b.drawImage(this.glowSprite(c, r), x - r, y - r, r * 2, r * 2); b.globalAlpha = 1;
  }
  /** kerucut + genangan cahaya lampu plafon (dibuat sekali per warna) */
  private lampSprite(c: string, h: number) {
    const key = `l${c}${h}${this.K}`;
    let cv = this.sprites.get(key);
    if (!cv) {
      const K = this.K; cv = document.createElement('canvas'); cv.width = 64 * K; cv.height = (h + 4) * K;
      const g = cv.getContext('2d')!; g.scale(K, K);
      const cg = g.createLinearGradient(0, 2, 0, h); cg.addColorStop(0, rgba(c, 0.22)); cg.addColorStop(1, rgba(c, 0));
      g.fillStyle = cg; g.beginPath(); g.moveTo(26, 3); g.lineTo(38, 3); g.lineTo(64, h); g.lineTo(0, h); g.closePath(); g.fill();
      const rg = g.createRadialGradient(32, h + 1, 1, 32, h + 1, 32); rg.addColorStop(0, rgba(c, 0.34)); rg.addColorStop(1, rgba(c, 0));
      g.save(); g.translate(0, h + 1); g.scale(1, 0.12); g.translate(0, -(h + 1)); g.fillStyle = rg; g.fillRect(0, h + 1 - 32, 64, 64); g.restore();
      g.fillStyle = rgba(c, 0.5); g.fillRect(26, 0, 12, 3);
      this.sprites.set(key, cv);
    }
    return cv;
  }

  private drawLights(b: CanvasRenderingContext2D) {
    const p = this.player;
    b.save(); b.globalCompositeOperation = 'lighter';
    for (const l of this.lights) { const k = l.life / l.max; this.glow(b, l.x, l.y, l.r * (0.7 + 0.3 * k), l.c, 0.42 * k); }
    if (this.gates.on) this.glow(b, p.x, p.y - 9, 34 + this.gates.gates * 5, '#3a8bff', 0.16 + 0.03 * this.gates.gates + Math.sin(this.real * 9) * 0.03);
    if (p.ofaOn) this.glow(b, p.x, p.y - 9, 34, '#57e6ff', 0.22 + Math.sin(this.real * 20) * 0.05);
    if (p.weapon === 'nunchaku' && this.br.sfNun.pts.length === 6) { const tp = this.br.sfNun.pts[5]; this.glow(b, tp.x, tp.y, 20 + Math.min(18, this.br.sfNun.endSpeed / 30), '#ff8a3d', 0.2); }
    for (const bl of this.bullets) if (bl.kind === 'beam') this.glow(b, bl.x, bl.y, 36, '#7dffc8', 0.3);
    for (const bm of this.bombs) if (bm.fuse < 0.5 && Math.floor(this.real * 16) % 2) this.glow(b, bm.x, bm.y - 4, 18, '#ff3b3b', 0.3);
    b.restore();
  }
  private drawPools(b: CanvasRenderingContext2D) {
    for (const pl of this.pools) {
      const r = pl.r, x = pl.x, y = Math.round(pl.y);
      b.fillStyle = '#4a0000'; b.fillRect(Math.round(x - r), y, Math.round(r * 2), 1);
      b.fillStyle = '#6e0000'; b.fillRect(Math.round(x - r + 1), y + 1, Math.max(1, Math.round(r * 2 - 2)), 1);
      b.fillStyle = 'rgba(255,110,110,0.45)'; b.fillRect(Math.round(x - r * 0.4), y, Math.max(1, Math.round(r * 0.5)), 1);
    }
  }
  private drawBombs(b: CanvasRenderingContext2D) {
    for (const bm of this.bombs) {
      const x = bm.x, y = bm.y - 3;
      pcircle(b, x, y, 3, '#000'); pcircle(b, x, y, 2.2, bm.fuse < 0.45 && Math.floor(this.real * 18) % 2 ? '#ff3b3b' : '#2e2e36');
      b.fillStyle = '#9aa3b8'; b.fillRect(Math.round(x - 1), Math.round(y - 2), 1, 1);
      pline(b, x, y - 3, x + Math.cos(bm.spin) * 2, y - 5 + Math.sin(bm.spin), '#c9a063');
    }
  }
  private drawMotes(b: CanvasRenderingContext2D, ix: number, iy: number, bw: number, bh: number) {
    b.fillStyle = 'rgba(255,240,210,0.6)';
    for (const l of this.lamps) {
      if (l.x < ix - 40 || l.x > ix + bw + 40 || l.floorY < iy || l.y > iy + bh) continue;
      const span = Math.max(8, l.floorY - l.y - 12);
      for (let i = 0; i < 6; i++) {
        const ph = hh(Math.round(l.x), i, 31) * 6.28;
        const yy = l.y + 6 + ((this.real * (2.5 + (i % 3)) + ph * 9) % span);
        const xx = l.x + Math.sin(this.real * 0.5 + ph) * (4 + (yy - l.y) * 0.4);
        b.globalAlpha = 0.18 + 0.18 * Math.sin(this.real * 2 + ph);
        b.fillRect(Math.round(xx * 4) / 4, Math.round(yy * 4) / 4, 1, 1);
      }
    }
    b.globalAlpha = 1;
  }
  showToast(text: string, c: string, life = 1.2) { this.toast = { text, c, t: 0, max: life + 0.3 }; }

  // ============================== BOT SEKUTU (M) ==============================
  toggleAlly() {
    const p = this.player;
    if (!p || this.state !== 'playing') return;
    if (this.ally) { this.fx.smoke(this.ally.x, this.ally.y - 8, 10, '#8fd8ff', 30, 0.6); this.ally = null; this.showToast('BOT SEKUTU PERGI', '#8fd8ff', 1); this.pushUI(true); return; }
    const a = this.makeBody(p.x - p.facing * 14, p.y, 1, 100) as Ally;
    Object.assign(a, { phase: 'none', phaseT: 0, move: null, combo: '', step: 0, hit: false, cd: 0.4, tpT: 0, facing: p.facing });
    if (this.solidAt(a.x, a.y - 8, true)) a.x = p.x;
    this.ally = a;
    this.fx.smoke(a.x, a.y - 8, 12, '#8fd8ff', 40, 0.7); this.fx.groundRing(a.x, a.y, 20, '#8fd8ff', 0.35);
    this.sfx.select(); this.showToast('BOT SEKUTU DATANG - M UNTUK MEMANGGIL PULANG', '#8fd8ff', 1.6);
    this.pushUI(true);
  }
  private allyPoseT(a: Ally) {
    const m = a.move; if (!m) return 0;
    if (a.phase === 'windup') return 0.3 * (1 - a.phaseT / m.windup);
    if (a.phase === 'active') return 0.3 + 0.3 * (1 - a.phaseT / m.active);
    if (a.phase === 'recover') return 0.6 + 0.4 * (1 - a.phaseT / m.recover);
    return 0;
  }
  private updateAlly(dt: number) {
    const a = this.ally, p = this.player;
    if (!a) return;
    a.flash = Math.max(0, a.flash - dt); a.cd -= dt;
    const st = this.storyOf(a.y);
    // ikut pindah lantai / menyusul bila tertinggal jauh
    if ((st !== this.storyOf(p.y) || Math.abs(a.x - p.x) > 260) && !p.door && p.onGround && !p.dead) {
      a.tpT += dt;
      if (a.tpT > 0.7) { this.fx.smoke(a.x, a.y - 8, 8, '#8fd8ff', 30, 0.5); a.x = p.x - p.facing * 14; if (this.solidAt(a.x, p.y - 8, true)) a.x = p.x; a.y = p.y; a.vx = 0; a.vy = 0; a.tpT = 0; a.phase = 'none'; a.move = null; this.fx.smoke(a.x, a.y - 8, 10, '#8fd8ff', 30, 0.6); }
    } else a.tpT = 0;
    let tgt: Enemy | null = null, bd = 230;
    for (const e of this.enemies) {
      if (e.dead || e.alpha < 0.6 || e.state === 'held' || e.state === 'spawn' || e.state === 'door' || this.storyOf(e.y) !== st) continue;
      const d = Math.abs(e.x - a.x) + Math.abs(e.y - a.y) * 2;
      if (d < bd) { bd = d; tgt = e; }
    }
    if (a.phase !== 'none' && a.move) {
      const m = a.move;
      a.phaseT -= dt * this.tempo;
      a.vx *= Math.max(0, 1 - dt * 6);
      if (a.phase === 'windup' && a.phaseT <= 0) { a.phase = 'active'; a.phaseT = m.active; a.vx += a.facing * m.lunge * 0.8; this.sfx.swing(m.sfx === 'heavy' ? 0.7 : 1.05); if (m.finisher) this.ghost(this.allyOpts(a, m.pose, 0.45), '#8fd8ff'); }
      else if (a.phase === 'active') {
        if (!a.hit && tgt && Math.abs(tgt.x - a.x) < m.range + 7 && Math.abs(tgt.y - a.y) < 14 && (tgt.state !== 'down' || m.knockdown)) {
          a.hit = true; this.allyHitting = true;
          this.hitEnemy(tgt, m, { x: tgt.x - a.facing * 3 * tgt.scale, y: a.y - 10 }, a.facing);
          this.allyHitting = false;
        }
        if (a.phaseT <= 0) { a.phase = 'recover'; a.phaseT = m.recover; }
      } else if (a.phase === 'recover' && a.phaseT <= 0) { a.phase = 'none'; a.move = null; a.cd = a.step >= a.combo.length ? 0.5 : 0.05; }
    } else {
      const inRange = tgt && Math.abs(tgt.x - a.x) < 18 && Math.abs(tgt.y - a.y) < 10;
      if (tgt && inRange && a.cd <= 0 && a.onGround && tgt.state !== 'down') {
        if (!a.combo || a.step >= a.combo.length) { a.combo = ALLY_COMBOS[Math.floor(Math.random() * ALLY_COMBOS.length)]; a.step = 0; }
        a.step++;
        const m = MOVES[a.combo.slice(0, a.step)] ?? MOVES.L;
        a.move = m; a.phase = 'windup'; a.phaseT = m.windup; a.hit = false; a.facing = Math.sign(tgt.x - a.x) || a.facing;
      } else {
        const want = tgt ? tgt.x - (Math.sign(tgt.x - a.x) || 1) * 13 : p.x - p.facing * 18;
        const dx = want - a.x;
        const tv = Math.abs(dx) < 4 ? 0 : Math.sign(dx) * (Math.abs(dx) > 80 ? RUN : WALK);
        a.vx += clamp(tv - a.vx, -900 * dt, 900 * dt);
        if (Math.abs(dx) > 4) a.facing = Math.sign(dx);
        else if (tgt) a.facing = Math.sign(tgt.x - a.x) || a.facing;
        else a.facing = p.facing;
        // ikut melompat ke pijakan bila pemain di atas
        if (a.onGround && p.onGround && p.y < a.y - 12 && p.y > a.y - 44 && Math.abs(p.x - a.x) < 50 && !tgt) { a.vy = -305; a.onGround = false; }
      }
    }
    this.move(a, dt, true, GRAV);
    const sp = Math.abs(a.vx);
    a.runK += ((sp > WALK + 10 ? 1 : 0) - a.runK) * Math.min(1, dt * 5);
    if (a.onGround && sp > 8) { const gc = gaitCadence(sp, a.runK, 1); a.stride = gc.stride; a.walk += dt * gc.stepsPerSec * Math.PI; } else if (sp <= 8) a.walk = 0;
  }
  private allyOpts(a: Ally, pose: Pose, t: number): StickOpts {
    const sp = Math.abs(a.vx), moving = a.onGround && sp > 8 && (pose === 'idle' || pose === 'run');
    const m = a.move, strike = m && a.phase === 'active' ? (m.limb === 'sweep' ? 'ffoot' : m.limb === 'body' ? null : (m.limb as StickOpts['strike'])) : null;
    return {
      x: a.x, y: a.y, c: '#8fd8ff', c2: '#2a6fd8', scale: 1, facing: a.facing, aim: a.facing > 0 ? 0 : Math.PI, look: a.facing > 0 ? 0 : Math.PI,
      walk: a.walk, moving, pose, t, acc: 'headband', weapon: 'none', flash: a.flash > 0, alpha: a.alpha, outline: '#000000', eyes: '#111111', time: this.time,
      lean: { x: a.facing, y: 0 }, z: 0, rot: 0, run: a.runK, vel: moving ? { x: Math.sign(a.vx), y: 0 } : undefined, stride: a.stride, anime: true, sideView: true, seed: 7.7,
      strike, impact: strike ? 1 : 0, mood: a.phase !== 'none' ? 'angry' : 'normal', pivot: a.pivotT > 0 ? clamp(a.pivotT / 0.16, 0, 1) : 0, pivotDir: { x: a.facing, y: 0 },
    };
  }
  private drawAlly(b: CanvasRenderingContext2D) {
    const a = this.ally;
    if (!a) return;
    const pose: Pose = a.move ? a.move.pose : !a.onGround ? 'jump' : a.runK > 0.55 ? 'run' : 'idle';
    const t = a.move ? this.allyPoseT(a) : !a.onGround ? clamp(0.5 + a.vy / 500, 0, 1) : 0;
    const o = this.allyOpts(a, pose, t);
    if (a.onGround) { b.globalAlpha = 0.35; b.fillStyle = '#000'; b.fillRect(Math.round(a.x - 4.5), Math.round(a.y) - 1, 9, 2); b.globalAlpha = 1; }
    this.stick(b, o, this.anim(a, pose, t));
    pfontO(b, 'SEKUTU', a.x, a.y - 32, '#8fd8ff', '#000', 1, 'center');
  }

  // ============================== WARGA KANTOR (NPC) ==============================
  private spawnCivs() {
    this.civs = [];
    const pick = <V,>(a: V[]) => a[Math.floor(Math.random() * a.length)];
    for (let s = 0; s < this.stories; s++) {
      if (this.theme(s).outdoor) continue;
      const spots = this.props.filter((pr) => pr.story === s && 'dqxwkf'.includes(pr.ch));
      const n = Math.min(spots.length, 2 + Math.floor(Math.random() * 3));
      for (let i = 0; i < n; i++) {
        const pr = spots.splice(Math.floor(Math.random() * spots.length), 1)[0];
        const c = this.makeBody(pr.x + 8 + rnd(-3, 3), pr.yF, 0.94, 1) as Civ;
        Object.assign(c, { mode: 'idle', t: rnd(0, 6), tie: pick(['#2a4a8a', '#8a2a3a', '#2a6a4a', '#6a4a8a', '#c98a2a']), acc: pick(['none', 'glasses', 'none', 'glasses', 'band']), shirt: pick(['#ecebe4', '#dfe8f2', '#f2e8dc', '#e4e4e4']), goal: null, facing: Math.random() < 0.5 ? 1 : -1, saidT: 0 });
        this.civs.push(c);
      }
    }
  }
  private updateCivs(dt: number) {
    const p = this.player;
    for (const c of this.civs) {
      if (c.mode === 'gone') continue;
      c.t += dt; c.saidT -= dt;
      const st = this.storyOf(c.y);
      if (c.mode === 'idle') {
        const danger = this.state === 'playing' && (this.enemies.some((e) => !e.dead && e.alpha > 0.5 && this.storyOf(e.y) === st && Math.abs(e.x - c.x) < 150)
          || this.bombs.some((bm) => Math.abs(bm.x - c.x) < 90 && this.storyOf(bm.y) === st)
          || (!!p && this.storyOf(p.y) === st && p.phase === 'active' && Math.abs(p.x - c.x) < 80));
        if (danger) {
          c.mode = 'flee'; c.t = 0;
          const doors = this.conns.filter((cn) => cn.story === st);
          c.goal = doors.length ? doors.reduce((a, b) => (Math.abs(b.x - c.x) < Math.abs(a.x - c.x) ? b : a)) : null;
          if (Math.random() < 0.6) this.texts.add(c.x, c.y - 24, ['AAA!', 'TOLONG!', 'LARI!', 'KYAA!'][Math.floor(Math.random() * 4)], '#ffe9a8', 1, 0.8);
        } else {
          // diam di meja: sesekali melangkah kecil & berbalik
          const w = Math.sin(c.t * 0.45 + c.id * 3.1);
          c.vx += ((w > 0.93 ? c.facing * 22 : 0) - c.vx) * Math.min(1, dt * 5);
          if (Math.sin(c.t * 0.21 + c.id) > 0.995) c.facing = -c.facing;
        }
      } else if (c.mode === 'flee') {
        if (c.goal) {
          const dx = c.goal.x - c.x;
          if (Math.abs(dx) < 4 && c.onGround) {
            c.goal.openT = 0.4; c.vx = 0; c.alpha -= dt * 3;
            if (c.alpha <= 0) { c.mode = 'gone'; if (this.state === 'playing') { this.score += 50; this.texts.add(c.x, c.y - 24, 'SELAMAT +50', '#7cff9a', 1, 0.8); } }
          } else { c.facing = Math.sign(dx) || c.facing; c.vx += (c.facing * 108 - c.vx) * Math.min(1, dt * 8); }
        } else c.vx *= Math.max(0, 1 - dt * 6);
      } else if (c.mode === 'down') { if (c.onGround) c.vx *= Math.max(0, 1 - dt * 8); if (c.t > 1.3) { c.mode = 'flee'; c.t = 0; } }
      // tertabrak tubuh yang terlempar
      if (c.mode !== 'down') for (const e of this.enemies) {
        if (!(e.state === 'air' || e.dead) || Math.abs(e.vx) < 140 || Math.abs(e.x - c.x) > 8 || Math.abs(e.y - c.y) > 12) continue;
        this.knockCiv(c, Math.sign(e.vx) || 1); break;
      }
      this.move(c, dt, true, GRAV);
      const sp = Math.abs(c.vx);
      c.runK += ((sp > 80 ? 1 : 0) - c.runK) * Math.min(1, dt * 6);
      if (c.onGround && sp > 6) { const gc = gaitCadence(sp, c.runK, c.scale); c.stride = gc.stride; c.walk += dt * gc.stepsPerSec * Math.PI; } else if (sp <= 6) c.walk = 0;
    }
  }
  private knockCiv(c: Civ, dir: number) {
    c.mode = 'down'; c.t = 0; c.vx = dir * 120; c.vy = -150; c.onGround = false;
    this.sfx.hit(); if (c.saidT <= 0) { c.saidT = 1; this.texts.add(c.x, c.y - 24, 'ADUH!', '#ffe9a8', 1, 0.7); }
  }
  private drawCivs(b: CanvasRenderingContext2D) {
    for (const c of this.civs) {
      if (c.mode === 'gone' || c.alpha <= 0) continue;
      const pose: Pose = c.mode === 'down' ? (c.onGround ? 'knock' : 'fly') : c.runK > 0.4 ? 'run' : 'idle';
      const sp = Math.abs(c.vx), moving = c.onGround && sp > 6 && c.mode !== 'down';
      const o: StickOpts = {
        x: c.x, y: c.y, c: c.shirt, c2: c.tie, scale: c.scale, facing: c.facing, aim: c.facing > 0 ? 0 : Math.PI, look: c.facing > 0 ? 0 : Math.PI,
        walk: c.walk, moving, pose, t: 0.5, acc: c.acc, weapon: 'none', flash: false, alpha: c.alpha, outline: '#000000', eyes: '#111111', time: this.time,
        lean: { x: c.facing, y: 0 }, z: 0, rot: 0, run: c.runK, vel: moving ? { x: Math.sign(c.vx), y: 0 } : undefined, stride: c.stride, anime: true, sideView: true, seed: c.id * 2.3,
        mood: c.mode === 'idle' ? 'normal' : 'hurt', flail: c.mode === 'down' && !c.onGround ? 0.8 : 0,
      };
      // panik: kedua tangan terangkat ke atas kepala
      if (c.mode === 'flee') { const s = Math.sin(this.time * 18 + c.id) * 1.6; o.handOverride = { x: c.x + c.facing * 5 + s, y: c.y - 16.5 + Math.abs(s) * 0.4 }; o.bhandOverride = { x: c.x - c.facing * 5 + s, y: c.y - 16.5 + Math.abs(s) * 0.4 }; }
      if (c.onGround) { b.globalAlpha = 0.3 * c.alpha; b.fillStyle = '#000'; b.fillRect(Math.round(c.x - 4), Math.round(c.y) - 1, 8, 2); b.globalAlpha = 1; }
      this.stick(b, o, this.anim(c, pose, 0.5));
      // dasi
      if (c.mode !== 'down') { b.fillStyle = c.tie; b.fillRect(Math.round(c.x + c.facing * 0.5), Math.round(c.y - 7.5 * c.scale), 1, 2); }
    }
  }

  // ============================== SUASANA & CAHAYA ==============================
  setAtmoMode(m: 'auto' | AtmoId) {
    this.atmoMode = m;
    try { localStorage.setItem('office_atmo', m); } catch { /* */ }
    this.applyAtmo(false);
    this.pushUI(true);
  }
  private autoAtmo(): AtmoId {
    if (this.state === 'title') return ATMO_CYCLE[Math.floor(this.real / 7) % ATMO_CYCLE.length];
    if (this.levelMode) return levelSpec(this.levelMode).atmo;
    if (this.rainWaves > 0) return 'hujan';
    const order: AtmoId[] = ['pagi', 'siang', 'sore', 'malam', 'subuh'];
    return order[Math.floor((Math.max(1, this.wave) - 1) / 2) % order.length];
  }
  private applyAtmo(instant: boolean) {
    const id = this.atmoMode === 'auto' ? this.autoAtmo() : this.atmoMode;
    if (id === this.atmoTarget && !instant) return;
    if (id !== this.atmoTarget && this.state === 'playing') this.showToast(`SUASANA: ${ATMO_NAME[id]}`, '#ffe9a8', 1.2);
    this.atmoFrom = this.A; this.atmoTo = ATMOS[id]; this.atmoTarget = id; this.atmoK = instant ? 1 : 0;
    if (instant) this.A = this.atmoTo;
  }
  private updateAtmo(raw: number) {
    this.applyAtmo(false);
    if (this.atmoK < 1) { this.atmoK = Math.min(1, this.atmoK + raw / 3.5); const k = this.atmoK; this.A = mixAtmo(this.atmoFrom, this.atmoTo, k * k * (3 - 2 * k)); }
    const A = this.A;
    if (A.lightning > 0.4) {
      this.lightningT -= raw;
      if (this.lightningT <= 0) { this.lightning = 0.75; this.lightningT = rnd(3.5, 9); this.thunderT = rnd(0.25, 1.3); }
    }
    if (this.thunderT > 0) { this.thunderT -= raw; if (this.thunderT <= 0) { this.weather.thunder(this.sfx, rnd(0.55, 1)); this.shake(0.15); } }
    this.lightning = Math.max(0, this.lightning - raw * 2.6);
    this.weather.update(this.sfx, A.rain, this.state === 'playing' || this.state === 'title');
    // percikan hujan di lantai luar ruangan (atap & jalan)
    if (A.rain > 0.2 && this.map) {
      const c = this.cam, vw = VW / c.zoom, l = c.x - vw / 2;
      const n = Math.floor(raw * 90 * A.rain + Math.random());
      for (let i = 0; i < n; i++) {
        const x = l + Math.random() * vw;
        const roofY = this.theme(0).outdoor ? (STORY - 1) * T : -1;
        const y = x < 0 || x > this.W * T ? (this.H - 1) * T : roofY;
        if (y < 0) continue;
        this.fx.add({ x, y: y - 0.5, vx: rnd(-25, 25), vy: rnd(-70, -25), life: rnd(0.2, 0.35), c: '#cfe3ff', s: 1, k: 12, g: 500 });
      }
    }
  }
  private isOutdoor(x: number, y: number) {
    if (y >= this.H * T - T) return true;
    const s = this.storyOf(y);
    if (this.theme(s).outdoor) return true;
    const sp = this.spans[s];
    return !sp || x < sp[0] * T || x > (sp[1] + 1) * T;
  }
  /** interior digelapkan / dihangatkan sesuai suasana (sebelum petarung digambar, supaya mereka tetap jelas) */
  private drawAmbient(b: CanvasRenderingContext2D, iy: number, bh: number) {
    const A = this.A, gt = this.gradeTint();
    const amb: [number, number, number] = [A.ambient[0] * gt[0] / 255, A.ambient[1] * gt[1] / 255, A.ambient[2] * gt[2] / 255];
    const dark = amb[0] < 250 || amb[1] < 250 || amb[2] < 250;
    for (let s = 0; s < this.stories; s++) {
      if (this.theme(s).outdoor) continue;
      const y0 = s * STORY_PX, y1 = y0 + STORY_PX - T + 6;
      if (y1 < iy || y0 > iy + bh) continue;
      const [ca, cb] = this.spans[s];
      const x0 = ca * T, w = (cb + 1) * T - x0;
      if (dark) { b.globalCompositeOperation = 'multiply'; b.fillStyle = css(amb); b.fillRect(x0, y0, w, y1 - y0); }
      if (A.lift > 0.01) { b.globalCompositeOperation = 'screen'; b.fillStyle = `rgba(255,248,236,${A.lift})`; b.fillRect(x0, y0, w, y1 - y0); }
    }
    b.globalCompositeOperation = 'source-over';
  }
  /** lampu plafon, berkas sinar matahari dari jendela, cahaya perabot (lampu lantai, TV, arcade, akuarium) */
  private drawAtmoLight(b: CanvasRenderingContext2D, ix: number, iy: number, bw: number, bh: number) {
    const A = this.A;
    b.save(); b.globalCompositeOperation = 'lighter';
    const vis = (x: number, y: number, m = 40) => x > ix - m && x < ix + bw + m && y > iy - m - 60 && y < iy + bh + m;
    if (A.lamp > 0.03) for (const l of this.lamps) {
      if (!vis(l.x, l.y)) continue;
      let k = A.lamp;
      if (A.rain > 0.5 && hh(Math.round(l.x), l.story, 3) > 0.8) k *= 0.5 + 0.5 * Math.abs(Math.sin(this.real * 23 + l.x));
      if (this.lightning > 0.3 && hh(Math.round(l.x), l.story, 5) > 0.6) k *= 0.3;
      const lh = Math.round(l.floorY - l.y);
      b.globalAlpha = Math.min(1, k); b.drawImage(this.lampSprite(l.color, lh), l.x - 32, l.y, 64, lh + 4); b.globalAlpha = 1;
    }
    if (A.beam > 0.03) for (const w of this.windows) {
      if (!vis(w.x + w.w / 2, w.y)) continue;
      const floorY = w.story * STORY_PX + STORY_PX - T, sh = (floorY - w.y) * A.beamDir * 0.7;
      b.fillStyle = css(A.beamColor, 0.07 * A.beam); b.beginPath(); b.moveTo(w.x, w.y); b.lineTo(w.x + w.w, w.y); b.lineTo(w.x + w.w + sh, floorY); b.lineTo(w.x + sh, floorY); b.closePath(); b.fill();
      b.fillStyle = css(A.beamColor, 0.07 * A.beam); b.beginPath(); b.moveTo(w.x + 6, w.y); b.lineTo(w.x + w.w - 6, w.y); b.lineTo(w.x + w.w - 6 + sh * 0.6, w.y + (floorY - w.y) * 0.6); b.lineTo(w.x + 6 + sh * 0.6, w.y + (floorY - w.y) * 0.6); b.closePath(); b.fill();
      b.fillStyle = css(A.beamColor, 0.12 * A.beam); b.fillRect(w.x, w.y, w.w, w.h);
      b.fillStyle = css(A.beamColor, 0.22 * A.beam); b.fillRect(Math.round(w.x + sh), floorY - 1, w.w, 2);
    }
    const dk = Math.max(A.lamp, A.night * 0.8);
    if (dk > 0.15) for (const pr of this.glowProps) {
      if (pr.broken) continue;
      const cx = pr.x + 8, cy = pr.yF - pr.h * 0.6;
      if (!vis(cx, cy)) continue;
      const col = pr.ch === 'l' ? '#ffd99a' : pr.ch === 'i' ? '#7ab8ff' : pr.ch === 'V' ? '#ff3df2' : pr.ch === 'A' ? (this.theme(pr.story).id === 'lab' ? '#5aff9a' : '#3ab8e8') : pr.ch === 'O' ? '#7aff9a' : pr.ch === 'v' ? '#ff5a5a' : '#ffb347';
      const r = pr.ch === 'l' ? 38 : 22, a = (pr.ch === 'l' ? 0.4 : 0.22) * dk;
      this.glow(b, cx, pr.ch === 'l' ? pr.yF - 22 : cy, r, col, a);
      if (pr.ch === 'l') { b.globalAlpha = Math.min(1, 0.55 * dk); b.drawImage(this.glowSprite(col, 26), cx - 26, pr.yF - 3, 52, 6); b.globalAlpha = 1; }
    }
    b.restore();
  }
  /** hujan di depan (hanya area luar ruangan), genangan atap, kilat & color grading suasana */
  private drawWeatherFront(b: CanvasRenderingContext2D, ix: number, iy: number, bw: number, bh: number) {
    const A = this.A;
    if (A.rain > 0.02) {
      const n = Math.round(110 * A.rain);
      b.fillStyle = `rgba(190,210,240,${0.35 + 0.25 * A.rain})`;
      for (let i = 0; i < n; i++) {
        const sp = 300 + (i % 7) * 45;
        const x = ix + ((i * 71.3 + this.real * 70) % (bw + 20) + bw + 20) % (bw + 20) - 10;
        const y = iy + ((i * 37.9 + this.real * sp) % (bh + 20) + bh + 20) % (bh + 20) - 10;
        if (!this.isOutdoor(x, y)) continue;
        b.fillRect(Math.round(x), Math.round(y), 1, 5); b.fillRect(Math.round(x) - 1, Math.round(y) + 5, 1, 3);
      }
      if (this.theme(0).outdoor && A.rain > 0.3) {
        const fy = (STORY - 1) * T;
        if (fy > iy - 4 && fy < iy + bh) for (let x = Math.floor(ix / 24) * 24; x < ix + bw; x += 24) {
          const w = 8 + Math.floor(hh(x, 3, 61) * 14);
          b.fillStyle = 'rgba(170,200,240,0.28)'; b.fillRect(x + 2, fy, w, 1);
          const ph = (this.real * 1.5 + hh(x, 9, 7) * 3) % 1;
          b.globalAlpha = (1 - ph) * 0.5; b.strokeStyle = '#dfefff'; b.lineWidth = 0.6; b.beginPath(); b.ellipse(x + 2 + w / 2, fy + 0.5, 1 + ph * 5, 0.5 + ph * 1.2, 0, 0, Math.PI * 2); b.stroke(); b.globalAlpha = 1;
        }
      }
      // tetesan air menuruni kaca jendela
      b.fillStyle = 'rgba(200,225,255,0.55)';
      for (const w of this.windows) {
        if (w.x + w.w < ix || w.x > ix + bw || w.y > iy + bh || w.y + w.h < iy) continue;
        for (let k = 0; k < 5; k++) { const dx = Math.floor(hh(w.x, k, 13) * (w.w - 2)), sp = 14 + hh(k, w.x, 5) * 20, dy = ((this.real * sp + hh(w.x, k, 7) * w.h) % w.h); b.fillRect(w.x + 1 + dx, Math.round(w.y + dy), 1, 3); }
      }
    }
    if (this.lightning > 0.02) { b.save(); b.globalCompositeOperation = 'screen'; b.fillStyle = `rgba(200,215,255,${this.lightning * 0.4})`; b.fillRect(ix, iy, bw, bh); b.restore(); }

  }

  // ============================== MODE 100 LEVEL ==============================
  get dw() { return this.wave + this.diff; }
  startLevel(n: number) {
    const L = Math.max(1, Math.min(LEVEL_COUNT, n));
    this.newGame(generateTower(L), L);
  }
  private levelComplete() {
    const L = this.levelMode;
    this.state = 'levelclear';
    const bonus = 2000 + L * 150;
    this.score += bonus;
    this.levelMax = Math.max(this.levelMax, Math.min(LEVEL_COUNT, L + 1));
    try { localStorage.setItem('office_level_max', String(this.levelMax)); const done = JSON.parse(localStorage.getItem('office_level_done') || '[]') as number[]; if (!done.includes(L)) { done.push(L); localStorage.setItem('office_level_done', JSON.stringify(done)); } } catch { /* */ }
    this.say(L >= LEVEL_COUNT ? 'MENARA DITAKLUKKAN!' : `LEVEL ${L} SELESAI!`, `BONUS +${bonus}`, '#7cff9a', 3);
    this.sfx.levelClear(); this.sfx.stopMusic(); this.slow(1.2, 0.3); this.flash = 0.35;
    if (this.score > this.best.score) { this.best = { score: Math.round(this.score), wave: Math.max(this.best.wave, this.wave) }; try { localStorage.setItem(BEST_KEY, JSON.stringify(this.best)); } catch { /* */ } }
    this.pushUI(true);
  }

  // ============================== CAMERA ==============================
  private updateCamera(raw: number) {
    const p = this.player, c = this.cam;
    if (!p) return;
    // look-ahead diperhalus terpisah: berbalik arah tidak menyentak kamera
    c.look += (p.facing * 14 + clamp(p.vx, -150, 150) * 0.1 - c.look) * (1 - Math.exp(-raw * 2.4));
    let tx = p.x + c.look;
    const st = this.storyOf(p.y);
    const floorY = st * STORY_PX + STORY_PX - T;
    let ty = st * STORY_PX + 38;
    if (p.climbing) ty = lerp(ty, p.y - 22, 0.6);
    else if (!p.dead && p.y < floorY - 30) ty -= (floorY - 30 - p.y) * 0.7;
    if (this.state === 'title') { tx = this.W * T / 2 + Math.sin(this.real * 0.12) * this.W * T * 0.32; ty = (this.H * T - 40) - (0.5 - 0.5 * Math.cos(this.real * 0.07)) * (this.H * T - 120); c.tz = 1.5; }
    if (this.exec) { tx = (p.x + this.exec.e.x) / 2; ty = p.y - 18; c.tz = Math.max(c.tz, 2.65); }
    if (this.clash) { tx = (p.x + this.clash.e.x) / 2; ty = p.y - 14; c.tz = Math.max(c.tz, 2.5); }
    if (this.bossIntro > 0 && this.bossRef) { tx = this.bossRef.x; ty = this.bossRef.y - 18; c.tz = Math.max(c.tz, 2.3); }
    if (this.slam) { tx = (p.x + this.slam.e.x) / 2; ty = Math.min(p.y, this.slam.e.y) - 16; c.tz = Math.max(c.tz, 2.2); }
    const k = 1 - Math.exp(-raw * (this.state === 'title' ? 1 : 5));
    c.x += (tx - c.x) * k; c.y += (ty - c.y) * (1 - Math.exp(-raw * 4));
    c.zoom += (c.tz - c.zoom) * (1 - Math.exp(-raw * 6));
    if (!this.exec && !this.clash && !this.slam && this.bossIntro <= 0) c.tz += ((this.state === 'title' ? 1.5 : BASE_ZOOM) - c.tz) * (1 - Math.exp(-raw * 2.4));
    const vw = VW / c.zoom, vh = VH / c.zoom, mw = this.W * T, mh = this.H * T;
    c.x = mw + 48 < vw ? mw / 2 : clamp(c.x, vw / 2 - 24, mw - vw / 2 + 24);
    c.y = mh + 60 < vh ? mh / 2 : clamp(c.y, vh / 2 - 40, mh - vh / 2 + 12);
    // getaran berbasis gelombang (bukan acak per frame) -> tegas tapi tidak bikin pusing
    c.shake = Math.max(0, c.shake - raw * 2.4);
    const s = c.shake * c.shake * 4.5;
    c.sx = (Math.sin(this.real * 47.3) + Math.sin(this.real * 83.9) * 0.5) * s * 0.67;
    c.sy = (Math.cos(this.real * 53.1) + Math.cos(this.real * 97.7) * 0.5) * s * 0.55;
  }

  // ============================== RENDER ==============================
  private playerOpts(pose: Pose, t: number): StickOpts {
    const p = this.player;
    const sp = Math.abs(p.vx);
    const moving = p.onGround && sp > 10 && MOVING_POSES.has(pose);
    const m = p.move;
    const strike = m && p.phase === 'active' ? (m.limb === 'sweep' ? 'ffoot' : m.limb === 'body' ? null : (m.limb as StickOpts['strike'])) : null;
    const r = p.react;
    const o: StickOpts = {
      x: p.x, y: p.y, c: '#ffffff', c2: '#ff3b3b', scale: 1, facing: p.facing, aim: IDLE_POSES.has(pose) ? p.bodyAim : p.aim, look: p.aim,
      walk: p.walk, moving, pose, t, acc: 'headband', weapon: 'none', flash: p.flash > 0, alpha: p.alpha, outline: '#000000', eyes: '#111111', time: this.time,
      lean: { x: p.facing, y: 0 }, z: 0, rot: p.rot, run: p.runK, squash: p.squash, vel: moving ? { x: Math.sign(p.vx), y: 0 } : undefined, stride: p.stride,
      anime: true, sideView: true, chainSide: p.chainSide, brake: p.brake, seed: 3.1, strike, impact: strike ? 1 : 0,
      pivot: p.pivotT > 0 ? clamp(p.pivotT / 0.16, 0, 1) : 0, pivotDir: { x: p.facing, y: 0 }, trail: m && m.trail && p.phase === 'active' ? '#ffffff' : null,
      react: r ? { zone: r.zone, k: kOf(r) * r.amp, dx: Math.cos(r.dir), dy: 0, side: r.side, amp: r.amp } : undefined,
      mood: p.dead ? 'dead' : p.hurtT > 0 || p.downT > 0 ? 'hurt' : p.phase !== 'none' || p.blocking ? 'angry' : 'normal',
      flail: p.dead && !p.onGround ? 0.8 : 0,
    };
    const W = WEAPONS[p.weapon];
    if (W.kind === 'gun') { if (p.weapon !== 'shotgun') o.weapon = p.weapon; o.recoil = p.recoil; o.gunSpin = p.twirlT > 0 ? (1 - p.twirlT / 0.7) * Math.PI * 4 * p.facing : 0; }
    if (W.kind === 'bow') { o.bowDraw = p.bowDraw; o.bowNock = p.bowDraw > 0.01 ? 1 : 0; }
    if (p.weapon === 'boxing') o.box = { stance: p.boxStance, weaveX: Math.sin(this.time * 3.4) * 1.5, weaveY: Math.abs(Math.sin(this.time * 3.4)) * 0.5, step: (this.time * 4.4) % 1, clock: this.time };
    this.br.decorate(o, false);
    if (p.ofaOn) o.mood = 'angry';
    return o;
  }
  private currentPlayerPose(): { pose: Pose; t: number } {
    const p = this.player;
    if (this.exec) { const st = this.exec.seq[this.exec.step]; return { pose: st.pose, t: clamp(this.exec.t / st.dur, 0, 1) }; }
    if (this.clash) return { pose: 'cross', t: 0.45 };
    if (this.special) return this.special.phase === 'dash' ? { pose: 'ragedash', t: 0.5 } : { pose: 'ragekill', t: clamp(this.special.t / 0.55, 0, 1) };
    if (p.dead) return { pose: p.onGround ? p.fall : 'fly', t: 1 };
    if (p.downT > 0) return { pose: p.onGround ? p.fall : 'fly', t: 1 };
    if (p.getupT > 0) return { pose: 'getup', t: 1 - p.getupT / 0.4 };
    if (p.hurtT > 0) return { pose: 'idle', t: 0 };
    if (p.climbing) return { pose: 'idle', t: 0 };
    if (this.slam) return this.slamPose();
    if (this.trick) return { pose: this.trick.pose, t: Math.min(1, this.trick.t / this.trick.dur) };
    if (p.buCharging && p.phase === 'none' && p.onGround) return { pose: 'k_heaven', t: 0.05 + 0.2 * p.buCharge };
    if (p.grab && p.holdT <= 0) return { pose: Math.abs(p.vx) > 10 ? 'run' : 'idle', t: 0 };
    const mbp = !p.move ? this.br.bodyPose() : null;
    if (mbp) return mbp;
    if (p.move) return { pose: p.move.pose, t: this.poseT() };
    if (p.holdT > 0) return { pose: p.holdPose, t: clamp(1 - p.holdT / 0.32, 0, 1) };
    if (p.dashT > 0) return { pose: 'dash', t: 0.5 };
    if (p.parryAnim > 0) return { pose: 'parry', t: 1 - p.parryAnim / 0.25 };
    if (p.blocking) return { pose: 'parry', t: 0.5 };
    if (!p.onGround) return { pose: 'jump', t: clamp(0.5 + p.vy / 500, 0, 1) };
    const W = WEAPONS[p.weapon];
    if (W.kind === 'gun') return p.twirlT > 0 && p.weapon !== 'shotgun' ? { pose: 'gun_twirl', t: 1 - p.twirlT / 0.7 } : { pose: 'shoot', t: 0.5 };
    if (W.kind === 'bow') return { pose: 'bow', t: p.bowDraw };
    const moving = Math.abs(p.vx) > 10;
    if (p.weapon === 'boxing') return { pose: moving ? (p.boxStance === 'tyson' ? 'bx_weave' : p.boxStance === 'ippo' ? 'bx_press' : 'bx_float') : (p.boxStance === 'tyson' ? 'bx_peek' : p.boxStance === 'ippo' ? 'bx_ippo' : 'bx_ali'), t: 0.5 };
    if (p.weapon === 'fist' && this.ippoGuardT > 0 && !moving && p.phase === 'none' && p.onGround) return { pose: 'bx_ippo', t: 0.5 };
    if (p.weapon === 'katana' && p.sheatheT > 0 && !moving && p.onGround) return { pose: 'k_sheathe', t: 1 - p.sheatheT / 0.45 };
    if (p.runK > 0.55) return { pose: 'run', t: 0 };
    if (p.weapon === 'buster' && !moving) return { pose: p.busterRest > 0 ? 'a_idle' : 'k_idle', t: 0.5 };
    if (p.weapon === 'axe' && !this.br.lev.held && !moving) return { pose: 'idle', t: 0 };
    if (!moving && W.kind !== 'fist') return { pose: W.idle, t: 0.5 };
    return { pose: 'idle', t: 0 };
  }
  private enemyOpts(e: Enemy): StickOpts {
    let pose: Pose = 'idle', t = 0;
    switch (e.state) {
      case 'windup': case 'attack': case 'recover': pose = e.atk?.pose ?? 'idle'; t = e.atk ? e.poseT : 0; break;
      case 'air': pose = e.knock ? 'fly' : 'launched'; t = 0.5; break;
      case 'down': pose = e.fall; t = 1; break;
      case 'dead': pose = e.onGround ? e.fall : 'fly'; t = 1; break;
      case 'getup': pose = 'getup'; t = 1 - e.stateT / 0.42; break;
      case 'stagger': pose = 'stagger'; t = 0.5; break;
      case 'block': pose = 'parry'; t = 0.5; break;
      case 'aim': pose = e.kind === 'bomber' ? 'throw' : 'shoot'; t = e.kind === 'bomber' ? clamp(1 - e.aimT / 0.7, 0, 1) * 0.5 : 0.5; break;
      case 'held': pose = 'launched'; t = 0.5; break;
      case 'charge': pose = 'charge'; t = e.poseT; break;
      case 'clash': pose = 'cross'; t = 0.45; break;
      case 'hurt': pose = 'idle'; break;
      default: pose = e.climbing ? 'idle' : 'idle';
    }
    const sp = Math.abs(e.vx);
    const moving = e.onGround && sp > 8 && pose === 'idle';
    const r = e.react;
    const dizzy = e.state === 'dizzy';
    return {
      x: e.x, y: e.y, c: this.enemyColor(e), c2: e.def.color2, scale: e.scale, facing: e.facing, aim: e.facing > 0 ? 0 : Math.PI, look: e.facing > 0 ? 0 : Math.PI,
      walk: e.walk, moving, pose, t, acc: e.acc ?? e.def.acc, weapon: e.def.weapon, flash: e.flash > 0, alpha: e.alpha, outline: e.boss ? '#ffffff' : e.elite ? '#ffd166' : '#000000',
      eyes: e.elite || e.boss ? '#ff2a2a' : '#101010', time: this.time, lean: { x: e.facing, y: 0 }, z: 0, rot: e.state === 'air' || e.state === 'held' || e.dead ? e.rot : dizzy ? Math.sin(this.time * 9) * 0.16 : 0,
      run: e.runK, sqx: e.sqx, sqy: e.sqy, vel: moving ? { x: Math.sign(e.vx), y: 0 } : undefined, stride: e.stride, anime: true, sideView: true, seed: e.id * 1.7, recoil: e.recoil,
      pivot: e.pivotT > 0 ? clamp(e.pivotT / 0.16, 0, 1) : 0, pivotDir: { x: e.facing, y: 0 },
      react: r && (pose === 'idle') ? { zone: r.zone, k: kOf(r) * r.amp, dx: Math.cos(r.dir), dy: 0, side: r.side, amp: r.amp } : undefined,
      flail: e.state === 'air' || e.state === 'held' || (e.dead && !e.onGround && this.player.grab !== e) ? Math.min(1, 0.35 + Math.abs(e.vx) / 400) : 0,
      mood: e.dead ? 'dead' : e.state === 'hurt' || e.state === 'down' || dizzy || e.state === 'stagger' ? 'hurt' : e.state === 'windup' || e.state === 'attack' || e.state === 'charge' ? 'angry' : 'normal',
      strike: e.state === 'attack' ? (e.atk?.pose === 'sidekick' || e.atk?.pose === 'roundhouse' || e.atk?.pose === 'knee' ? 'ffoot' : 'bhand') : null, impact: e.state === 'attack' ? 1 : 0,
    };
  }

  /** gambar stickman dengan penempatan sub-piksel (kelipatan 1/K piksel dunia) */
  private stick(b: CanvasRenderingContext2D, o: StickOpts, prev?: { pose: Pose; t: number; blend: number }) {
    const K = this.K;
    const rx = Math.round(o.x), ry = Math.round(o.y);
    const fx = Math.round((o.x - rx) * K) / K, fy = Math.round((o.y - ry) * K) / K;
    if (fx === 0 && fy === 0) { drawStick(b, o, prev); return; }
    const oo: StickOpts = { ...o, x: rx, y: ry };
    if (o.handOverride) oo.handOverride = { x: o.handOverride.x - fx, y: o.handOverride.y - fy };
    if (o.bhandOverride) oo.bhandOverride = { x: o.bhandOverride.x - fx, y: o.bhandOverride.y - fy };
    b.translate(fx, fy);
    drawStick(b, oo, prev);
    b.translate(-fx, -fy);
  }
  /** lacak perubahan pose -> silang-halus (ease-out) + animasi putar badan saat arah hadap berbalik */
  private anim(a: Body, pose: Pose, t: number): { pose: Pose; t: number; blend: number } | undefined {
    const dt = this.lastDt;
    if (a.facing !== a.lastFacing) { a.lastFacing = a.facing; a.pivotT = 0.16; }
    a.pivotT = Math.max(0, a.pivotT - dt);
    if (pose !== a.animPose) { a.prevPose = a.animPose; a.prevT = a.animT; a.blend = 1; a.blendDur = blendDur(a.animPose, pose); a.animPose = pose; }
    a.animT = t;
    if (a.blend > 0) a.blend = Math.max(0, a.blend - dt / a.blendDur);
    return a.blend > 0.01 && a.prevPose !== pose ? { pose: a.prevPose, t: a.prevT, blend: a.blend * a.blend } : undefined;
  }
  private enemyColor(e: Enemy) {
    if (e.boss && Math.sin(this.real * 6) > 0.6) return '#ffffff';
    return e.col ?? e.def.color;
  }

  render() {
    const c = this.cam, z = c.zoom;
    const vw = VW / z, vh = VH / z;
    const left = c.x - vw / 2 + c.sx, top = c.y - vh / 2 + c.sy;
    const ix = Math.floor(left), iy = Math.floor(top);
    const bw = Math.ceil(vw) + 2, bh = Math.ceil(vh) + 2;
    // SUPERSAMPLING: 1 piksel dunia = K piksel buffer. Seni tetap pixel-art, tapi posisi petarung & partikel
    // ditempatkan sub-piksel sehingga gerakan & scroll kamera mulus (tidak meloncat per piksel).
    const K = this.K = Math.max(1, Math.min(3, Math.floor(this.canvas.width / (VW / BASE_ZOOM))));
    if (this.buf.width < bw * K || this.buf.height < bh * K) { this.buf.width = (bw + 24) * K; this.buf.height = (bh + 16) * K; }
    const b = this.b;
    if (this.skyBuf.width !== bw || this.skyBuf.height !== bh) { this.skyBuf.width = bw; this.skyBuf.height = bh; }
    const sc = this.skyCtx;
    sc.setTransform(1, 0, 0, 1, 0, 0); sc.imageSmoothingEnabled = false; sc.globalAlpha = 1; sc.globalCompositeOperation = 'source-over';
    drawSky2(sc, this.sky, this.A, bw, bh, ix, iy, this.H * T, this.real, this.lightning);
    if (this.A.gradeA > 0.01) { sc.globalCompositeOperation = 'multiply'; sc.fillStyle = css(this.gradeTint()); sc.fillRect(0, 0, bw, bh); sc.globalCompositeOperation = 'source-over'; }
    b.setTransform(1, 0, 0, 1, 0, 0); b.imageSmoothingEnabled = false; b.globalAlpha = 1; b.globalCompositeOperation = 'source-over';
    b.drawImage(this.skyBuf, 0, 0, bw * K, bh * K);
    b.setTransform(K, 0, 0, K, -ix * K, -iy * K);
    this.fx.sub = K; this.fxBack.sub = K;
    this.drawGround(b, ix, iy, bw, bh);
    b.drawImage(this.building, 0, 0);
    b.drawImage(this.decals, 0, 0);
    for (const d of this.liveDecor) if (d.x > ix - 30 && d.x < ix + bw + 10 && d.yF > iy && d.y0 < iy + bh) drawWallDecor(b, d, this.real);
    if (this.A.lamp > 0.3) this.drawMotes(b, ix, iy, bw, bh);
    const c0 = Math.max(0, Math.floor(ix / T) - 1), c1 = Math.min(this.W - 1, Math.ceil((ix + bw) / T) + 1);
    const r0 = Math.max(0, Math.floor(iy / T) - 2), r1 = Math.min(this.H - 1, Math.ceil((iy + bh) / T) + 2);
    for (const g of this.glassCells) {
      if (g.c < c0 || g.c > c1 || g.r < r0 || g.r > r1) continue;
      const ch = this.tiles[g.r][g.c];
      const up = this.map.rows[g.r - 1]?.[g.c] !== 'G', dn = this.map.rows[g.r + 1]?.[g.c] !== 'G';
      drawGlassTile(b, g.c * T, g.r * T, ch === 'G', up, dn, this.real);
    }
    for (const cn of this.conns) if (cn.c >= c0 && cn.c <= c1) drawConnector(b, cn.ch, cn.c * T, cn.yF, cn.open, this.real);
    for (const pr of this.props) if (pr.x / T >= c0 - 1 && pr.x / T <= c1) drawProp(b, pr.ch, pr.x, pr.yF, { broken: pr.broken, t: this.real, seed: pr.seed, shake: pr.shake, nl: pr.nl, nr: pr.nr, th: this.theme(pr.story) });
    for (const k of this.pickups) this.drawPickup(b, k);
    // efek tembus pukulan (darah, gelombang kejut) DI BELAKANG sprite petarung
    this.fxBack.draw(b);
    this.drawPools(b);
    for (const sa of this.stuck) { b.globalAlpha = Math.min(1, sa.life); pline(b, sa.x, sa.y, sa.x - Math.cos(sa.ang) * 7, sa.y - Math.sin(sa.ang) * 7, '#c9a063'); b.globalAlpha = 1; }
    // bayangan kaki
    const qx = (v: number) => Math.round(v * K) / K;
    const shadowFor = (x: number, y: number, s: number) => { b.globalAlpha = 0.35; b.fillStyle = '#000'; const w = Math.round(9 * s); b.fillRect(qx(x - w / 2), Math.round(y) - 1, w, 2); b.globalAlpha = 1; };
    this.drawAmbient(b, iy, bh);
    this.drawCivs(b);
    for (const e of this.enemies) if (e.dead && e.alpha > 0) { const o = this.enemyOpts(e); this.stick(b, o, this.anim(e, o.pose, o.t)); }
    for (const e of this.enemies) {
      if (e.dead || e.alpha <= 0.01) continue;
      if (e.onGround) shadowFor(e.x, e.y, e.scale);
      if (e.state === 'spawn' && e.spawnMode === 'drop') { pline(b, e.x, e.y - BODY_H * e.scale - 40, e.x, e.y - BODY_H * e.scale, '#2a2a2a'); }
      if (e.state === 'aim' && (e.kind === 'gunner' || e.kind === 'smg')) this.drawLaser(b, e);
      const eo = this.enemyOpts(e);
      this.stick(b, eo, this.anim(e, eo.pose, eo.t));
      this.drawEnemyMarks(b, e);
      if (e.arrows) for (const ar of e.arrows) { const ax = e.x + ar.dx, ay = e.y + ar.dy; pline(b, ax, ay, ax - Math.cos(ar.ang) * 6, ay - Math.sin(ar.ang) * 6, '#c9a063'); b.fillStyle = '#e8e8e8'; b.fillRect(Math.round(ax - Math.cos(ar.ang) * 6), Math.round(ay - Math.sin(ar.ang) * 6), 1, 1); }
    }
    this.drawAlly(b);
    const pl = this.player;
    if (pl.ofaOn && this.lock && !this.lock.dead) {
      const L = this.lock, tY = L.y - BODY_H * L.scale - 3, k = 2 + Math.sin(this.real * 10);
      for (const [sx, sy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { const cx = L.x + sx * (6 + k), cy = sy < 0 ? tY : L.y + 1; pline(b, cx, cy, cx - sx * 3, cy, '#57e6ff'); pline(b, cx, cy, cx, cy - sy * 3, '#57e6ff'); }
    }
    this.br.drawBack(b);
    for (const g of this.ghosts) { const o = g.o; this.stick(b, { ...o, alpha: (g.life / g.max) * 0.5 }); }
    const p = this.player;
    if (p.onGround && p.alpha > 0.5) shadowFor(p.x, p.y, 1);
    const pp = this.currentPlayerPose();
    const po = this.playerOpts(pp.pose, pp.t);
    if (p.climbing && p.ladder) { const ph = Math.sin(p.climbPh * 2); po.handOverride = { x: p.ladder.x + 3 * p.facing, y: p.y - 15 + ph * 2 }; po.bhandOverride = { x: p.ladder.x - 2 * p.facing, y: p.y - 13 - ph * 2 }; po.moving = true; po.vel = { x: p.facing, y: 0 }; }
    if (p.iframes > 0 && !p.dead && !this.exec && !this.special && p.hurtT <= 0 && p.dashT <= 0) po.alpha = p.alpha * (0.74 + 0.26 * Math.sin(this.real * 26));
    this.br.decorate(po, true);
    if (p.grab) { const gb = p.grab; po.handOverride = { x: gb.x + p.facing * 3, y: gb.y + 1 }; po.bhandOverride = { x: gb.x - p.facing * 3, y: gb.y + 2 }; }
    this.syncGp();
    this.gates.drawAura(b, this.ga, po, this.lastDt);
    if (p.ofaOn) this.drawOfaAura(b, p);
    this.stick(b, po, this.anim(p, pp.pose, pp.t));
    if (!p.grab) this.br.drawWeapon(b, po, pp.pose, pp.t);
    this.gates.drawAuraFront(b, this.ga, po);
    this.drawWraps(b);
    for (const ct of this.cuts) { b.globalAlpha = ct.life / ct.max; pline(b, ct.x - 9, ct.y + 2, ct.x + 9, ct.y - 2, '#ffffff'); b.globalAlpha = 1; }
    if (p.blocking) { b.globalAlpha = 0.5 + 0.3 * Math.sin(this.real * 20); pline(b, p.x + p.facing * 7, p.y - 15, p.x + p.facing * 7, p.y - 3, '#9fe8ff'); b.globalAlpha = 1; }
    for (const bl of this.bullets) this.drawBullet(b, bl);
    this.drawAtmoLight(b, ix, iy, bw, bh);
    this.drawBombs(b);
    this.fx.draw(b);
    this.drawLights(b);
    this.drawWeatherFront(b, ix, iy, bw, bh);
    // ---- blit ke layar
    const ctx = this.ctx, W = this.canvas.width, H = this.canvas.height, S = W / VW;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = false; ctx.globalAlpha = 1;
    ctx.drawImage(this.buf, (left - ix) * K, (top - iy) * K, vw * K, vh * K, 0, 0, W, H);
    ctx.setTransform(S, 0, 0, S, 0, 0);
    this.drawOverlay(ctx, left, top, z);
  }
  /** trotoar & jalan di sisi gedung (setinggi lobi) + fondasi gelap di bawah peta */
  private drawGround(b: CanvasRenderingContext2D, ix: number, iy: number, bw: number, bh: number) {
    const gy = (this.H - 1) * T, by = this.H * T, x0 = ix - 2, x1 = ix + bw + 2;
    if (iy + bh < gy) return;
    const side = (a: number, c: number) => {
      if (c <= a) return;
      b.fillStyle = '#3a3d48'; b.fillRect(a, gy, c - a, 4); b.fillStyle = '#6b6e7a'; b.fillRect(a, gy, c - a, 1);
      b.fillStyle = '#16181e'; b.fillRect(a, gy + 4, c - a, 12);
      b.fillStyle = '#c9a04a'; for (let x = Math.floor(a / 20) * 20; x < c; x += 20) b.fillRect(x, gy + 10, 9, 1);
      b.fillStyle = '#4a4e5a'; for (let x = Math.floor(a / 64) * 64 + 30; x < c; x += 64) { b.fillRect(x, gy - 30, 1, 30); b.fillRect(x - 4, gy - 31, 9, 2); b.fillStyle = 'rgba(255,220,150,0.18)'; b.fillRect(x - 10, gy - 29, 21, 29); b.fillStyle = '#4a4e5a'; }
    };
    side(x0, Math.min(x1, 0)); side(Math.max(x0, this.W * T), x1);
    if (iy + bh > by) {
      const g = b.createLinearGradient(0, by, 0, by + 90);
      g.addColorStop(0, '#15161c'); g.addColorStop(1, '#030305');
      b.fillStyle = g; b.fillRect(x0, by, x1 - x0, Math.max(0, iy + bh - by) + 4);
      b.fillStyle = '#23252e'; b.fillRect(x0, by, x1 - x0, 1);
      b.fillStyle = '#1c1e26'; for (let x = Math.floor(x0 / 32) * 32; x < x1; x += 32) b.fillRect(x, by + 3, 1, 40);
    }
  }
  private drawPickup(b: CanvasRenderingContext2D, k: Pickup) {
    const bob = k.vy === 0 ? Math.sin(this.real * 4 + k.x) * 1 : 0;
    const x = Math.round(k.x), y = Math.round(k.y - 1 + bob);
    if (k.life < 3 && Math.floor(this.real * 8) % 2 === 0) return;
    b.save(); b.globalCompositeOperation = 'lighter'; b.fillStyle = k.kind === 'hp' ? 'rgba(124,255,154,0.25)' : 'rgba(95,240,255,0.25)'; b.fillRect(x - 5, y - 11, 10, 11); b.restore();
    if (k.kind === 'hp') { b.fillStyle = '#e8e8e8'; b.fillRect(x - 2, y - 7, 5, 7); b.fillStyle = '#2bd96b'; b.fillRect(x - 1, y - 5, 3, 1); b.fillRect(x, y - 6, 1, 3); b.fillStyle = '#bbb'; b.fillRect(x - 2, y - 8, 5, 1); }
    else { pcircle(b, x, y - 4, 3, '#5ff0ff'); b.fillStyle = '#ffffff'; b.fillRect(x - 1, y - 5, 1, 1); }
  }
  private drawLaser(b: CanvasRenderingContext2D, e: Enemy) {
    const sx = e.x + e.facing * 9 * e.scale, sy = e.y - 9.5 * e.scale;
    let ex = sx;
    for (let i = 0; i < 260; i += 2) { ex = sx + e.facing * i; if (this.solidAt(ex, sy, false)) break; }
    b.globalAlpha = 0.35 + 0.4 * (1 - e.aimT / 0.75) * (Math.sin(this.real * 30) > 0 ? 1 : 0.6);
    pline(b, sx, sy, ex, sy, '#ff2a2a');
    b.globalAlpha = 1;
  }
  private drawEnemyMarks(b: CanvasRenderingContext2D, e: Enemy) {
    const topY = e.y - (BODY_H + 2) * e.scale;
    if (e.state === 'dizzy' || e.state === 'stagger') {
      for (let i = 0; i < 3; i++) { const a = this.real * 9 + (i * Math.PI * 2) / 3; b.fillStyle = i % 2 ? '#9ff8ff' : '#ffffff'; b.fillRect(Math.round(e.x + Math.cos(a) * 5), Math.round(topY - 3 + Math.sin(a) * 2), 1, 1); }
      const p = this.player;
      if (Math.abs(p.x - e.x) < 30 && Math.abs(p.y - e.y) < 8 && Math.floor(this.real * 4) % 2 === 0) pfontO(b, 'F', e.x, topY - 13, '#ff3b3b', '#000', 1, 'center');
    }
    if (e.state === 'windup' && e.atk) {
      const k = 1 - e.stateT / e.atk.windup;
      if (k > 0.45) { b.fillStyle = e.atk.heavy ? '#ff3b3b' : '#ffd166'; const ex = Math.round(e.x + e.facing * 2 * e.scale), ey = Math.round(e.y - 12.5 * e.scale); b.fillRect(ex - 1, ey, 3, 1); b.fillRect(ex, ey - 1, 1, 3); }
    }
    if (e.state === 'charge' && e.hold > 0 && Math.floor(this.real * 12) % 2 === 0) pfontO(b, '!!', e.x, topY - 12, '#ff3b3b', '#000', 1, 'center');
    if (!e.boss && e.hp < e.maxHp && e.state !== 'spawn') { const w = Math.round(12 * e.scale); b.fillStyle = '#000'; b.fillRect(Math.round(e.x - w / 2) - 1, Math.round(topY) - 4, w + 2, 3); b.fillStyle = e.elite ? '#ffd166' : '#ff3b3b'; b.fillRect(Math.round(e.x - w / 2), Math.round(topY) - 3, Math.max(0, Math.round(w * e.hp / e.maxHp)), 1); }
  }

  private drawOverlay(ctx: CanvasRenderingContext2D, left: number, top: number, z: number) {
    // vignette + flash
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(this.vignette(), 0, 0); ctx.restore();
    if (this.hurtFlash > 0) { const hg = ctx.createRadialGradient(VW / 2, VH / 2, VH * 0.2, VW / 2, VH / 2, VW * 0.6); hg.addColorStop(0, 'rgba(255,0,0,0)'); hg.addColorStop(1, `rgba(255,20,20,${this.hurtFlash * 0.7})`); ctx.fillStyle = hg; ctx.fillRect(0, 0, VW, VH); }
    if (this.flash > 0) { ctx.fillStyle = `rgba(255,255,255,${Math.min(0.7, this.flash)})`; ctx.fillRect(0, 0, VW, VH); }
    if (this.slowT > 0 && this.slowK < 0.5) { ctx.fillStyle = 'rgba(120,180,255,0.06)'; ctx.fillRect(0, 0, VW, VH); }
    const lb = Math.round(this.letter * 26);
    if (lb > 0) { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, VW, lb); ctx.fillRect(0, VH - lb, VW, lb); }
    const toS = (wx: number, wy: number) => ({ x: (wx - left) * z, y: (wy - top) * z });
    // teks melayang dunia digambar di lapisan layar: ukuran tetap tajam walau kamera zoom
    for (const t of this.texts.list) {
      const a = t.life / t.max, s = toS(t.x, t.y);
      if (s.x < -40 || s.x > VW + 40 || s.y < -20 || s.y > VH + 20) continue;
      ctx.globalAlpha = a < 0.3 ? a / 0.3 : 1;
      this.tx(ctx, t.text, s.x, s.y - 4, t.c, '#000', t.max - t.life < 0.07 ? 2 : 1, 'center');
    }
    ctx.globalAlpha = 1;
    if (this.state === 'title') return;
    const p = this.player;
    // ---- HUD kiri atas
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(6, 6, 112, 30);
    this.tx(ctx, 'HP', 10, 9, '#ffffff', '#000', 1);
    ctx.fillStyle = '#2a0a0a'; ctx.fillRect(24, 9, 90, 6);
    const hpw = Math.round(90 * clamp(p.hp / p.maxHp, 0, 1));
    ctx.fillStyle = p.hp / p.maxHp < 0.3 && Math.floor(this.real * 6) % 2 === 0 ? '#ff7a7a' : '#e83a3a'; ctx.fillRect(24, 9, hpw, 6);
    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(24, 9, hpw, 1);
    this.tx(ctx, 'CHI', 10, 18, '#5ff0ff', '#000', 1);
    ctx.fillStyle = '#0a1a22'; ctx.fillRect(24, 19, 90, 4);
    const full = p.chi >= 100;
    ctx.fillStyle = full ? (Math.floor(this.real * 8) % 2 ? '#ffd166' : '#fff2b0') : '#3ac8ff'; ctx.fillRect(24, 19, Math.round(90 * p.chi / 100), 4);
    this.tx(ctx, 'OFA', 10, 27, '#57e6ff', '#000', 1);
    ctx.fillStyle = '#081820'; ctx.fillRect(24, 28, 90, 4);
    ctx.fillStyle = p.ofaOn ? (Math.floor(this.real * 14) % 2 ? '#ffffff' : '#57e6ff') : p.ofa >= 25 ? '#57e6ff' : '#2a6a78'; ctx.fillRect(24, 28, Math.round(90 * p.ofa / 100), 4);
    ctx.fillStyle = '#000'; ctx.fillRect(24 + Math.round(90 * 0.25), 28, 1, 4);
    // ---- panel senjata
    const Wh = WEAPONS[p.weapon];
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(6, 38, 112, 17);
    drawWeaponIcon(ctx, Wh, 17, 46, this.real);
    this.tx(ctx, `${Wh.key} ${Wh.name}`, 30, 41, Wh.color, '#000', 1);
    const G = Wh.gun;
    const v2c = this.ctrl === 'v2', L = v2c ? 'KIRI' : 'J', H = v2c ? 'KANAN' : 'K';
    const HINTS: Record<string, string> = {
      fist: `${L} BERIRAMA = GAYA  ${H} BERAT`, katana: `${L} KOMBO  LARI+${L} IAI`, dual: `${L} KOMBO  ${H} TARIAN`, bat: `TAHAN ${L} SPAM  ${H} POWER`,
      buster: `TAHAN ${L} = BEAM  ${H} XH`, nunchaku: `${L}/${H} RANTAI API`, yoyo: `${L} LEMPAR  TAHAN ${H} ORBIT`, takamura: `${L} TEBAS  TAHAN ${H} IAI`,
      hayabusa: `${L} TEBAS  TAHAN ${H} BLADE`, guandao: `${L} KOMBO  ${H} PUSARAN  Z ATRAKSI`, axe: this.br.lev.held ? `${L} KOMBO  ${H} LEMPAR` : `${H} PANGGIL KAPAK`,
      boxing: `${L} RINGAN  ${H} PAMUNGKAS`, pistol: `${L} TEMBAK  ${H} TRIK`, rifle: `TAHAN ${L} TEMBAK  ${H} TRIK`, shotgun: `${L} TEMBAK  ${H} ISI ULANG`, bow: `TAHAN ${L} TARIK  ${H} AKROBAT`,
    };
    let sub = HINTS[p.weapon] ?? 'Q GANTI SENJATA';
    if (Wh.kind === 'gun' && G && (p.reloadT > 0 || p.sgPhase === 'load')) sub = 'ISI ULANG...';
    else if (Wh.kind === 'gun' && G && this.real % 4 < 2) sub = `PELURU ${p.ammo[p.weapon] ?? 0}/${G.mag}`;
    else if (Wh.kind === 'bow' && p.bowDraw > 0) sub = `TARIK ${Math.round(p.bowDraw * 100)}%`;
    else if (p.weapon === 'boxing') sub = `${BOX_STANCES[p.boxStance].name} - B GANTI`;
    this.tx(ctx, sub, 30, 48, '#9aa3b8', '#000', 1);
    let hy = 58;
    if (full) { this.tx(ctx, 'R: TINJU NAGA!', 10, hy, '#ffd166', '#000', 1); hy += 8; }
    if (p.ofa >= 25 && !p.ofaOn) { this.tx(ctx, 'X: ONE FOR ALL', 10, hy, '#57e6ff', '#000', 1); hy += 8; }
    if (!this.gates.on && this.gates.energy >= 25 && this.gates.exhaust <= 0 && this.state === 'playing') this.tx(ctx, 'N: 8 GERBANG', 10, hy, '#6fd6ff', '#000', 1);
    // ---- tengah atas
    const st = this.storyOf(p.y);
    this.tx(ctx, `WAVE ${this.wave}`, VW / 2, 7, '#ffffff', '#000', 2, 'center');
    this.tx(ctx, `${floorLabel(this.map, st)} - ${this.theme(st).name}`, VW / 2, 20, this.theme(st).accent, '#000', 1, 'center');
    if (this.levelMode) this.tx(ctx, `LEVEL ${this.levelMode}/${LEVEL_COUNT}  WAVE ${this.wave}/${this.levelGoal}`, VW / 2, 36, '#ffd166', '#000', 1, 'center');
    const left2 = this.queue.length + this.enemies.filter((e) => !e.dead).length;
    if (this.waveState === 'fight') this.tx(ctx, `MUSUH ${left2}`, VW / 2, 28, '#ff8a8a', '#000', 1, 'center');
    if (this.waveState === 'climb') this.tx(ctx, `NAIK! ${Math.ceil(this.waveT)}`, VW / 2, 28, '#5ff0ff', '#000', 1, 'center');
    // ---- kanan atas
    this.tx(ctx, `${Math.round(this.score)}`.padStart(7, '0'), VW - 8, 7, '#ffffff', '#000', 2, 'right');
    this.tx(ctx, `KO ${this.kills}`, VW - 8, 20, '#ff8a8a', '#000', 1, 'right');
    this.tx(ctx, ATMO_NAME[this.atmoTarget], VW - 8, 28, this.A.night > 0.5 ? '#9fb8ff' : '#ffe9a8', '#000', 1, 'right');
    // ---- kombo
    if (this.combo >= 2) {
      const sc = 3 + (this.comboPop > 0.5 ? 1 : 0);
      const a = clamp(this.comboT / 0.6, 0, 1);
      ctx.globalAlpha = a;
      this.tx(ctx, `${this.combo}`, VW - 12, 52, this.combo >= 20 ? '#ff8a3d' : '#ffd166', '#000', sc, 'right');
      this.tx(ctx, 'HIT KOMBO', VW - 12, 52 + sc * 6, '#ffffff', '#000', 1, 'right');
      ctx.fillStyle = '#ffd166'; ctx.fillRect(VW - 62, 52 + sc * 6 + 8, Math.round(50 * clamp(this.comboT / 2.3, 0, 1)), 1);
      ctx.globalAlpha = 1;
    }
    if (this.rank && this.rankT > 0) { const k = 1 - this.rankT / 1.6; ctx.globalAlpha = this.rankT < 0.4 ? this.rankT / 0.4 : 1; this.tx(ctx, this.rank[0], VW - 12, 92 - k * 6, this.rank[1], '#000', 2, 'right'); ctx.globalAlpha = 1; }
    // ---- indikator musuh di luar layar (kiri & kanan)
    let nl = 0, nr = 0;
    for (const e of this.enemies) {
      if (e.dead || this.storyOf(e.y) !== st) continue;
      const sx = (e.x - left) * z;
      if (sx < -4) nl++; else if (sx > VW + 4) nr++;
    }
    const pulse = Math.floor(this.real * 5) % 2 === 0;
    const midY = toS(0, st * STORY_PX + 40).y;
    if (nl) { this.arrow(ctx, 8, midY, -1, pulse ? '#ff3b3b' : '#ff8a8a'); this.tx(ctx, `${nl}`, 18, midY - 2, '#ffffff', '#000', 1); }
    if (nr) { this.arrow(ctx, VW - 8, midY, 1, pulse ? '#ff3b3b' : '#ff8a8a'); this.tx(ctx, `${nr}`, VW - 18, midY - 2, '#ffffff', '#000', 1, 'right'); }
    // ---- bos
    const boss = this.bossRef;
    if (boss && !boss.dead) {
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(VW / 2 - 100, 36, 200, 18);
      this.tx(ctx, boss.name, VW / 2, 38, '#ffd166', '#000', 1, 'center');
      ctx.fillStyle = '#300'; ctx.fillRect(VW / 2 - 94, 46, 188, 5);
      ctx.fillStyle = '#ff3b3b'; ctx.fillRect(VW / 2 - 94, 46, Math.round(188 * clamp(boss.hp / boss.maxHp, 0, 1)), 5);
    }
    // ---- HUD Delapan Gerbang (modul asli) & roda senjata
    this.syncGp(); this.gates.drawHud(ctx, this.ga, VW, VH);
    if (this.wheelT > 0 && this.state === 'playing') {
      ctx.globalAlpha = Math.min(1, this.wheelT / 0.4);
      // roda senjata di tengah atas (di bawah info wave), jauh dari area bertarung
      const n = WEAPON_ORDER.length, sw = 17, x0 = 124, y0 = boss && !boss.dead ? 58 : 38;
      ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(x0 - 3, y0 - 3, n * sw + 4, 36);
      WEAPON_ORDER.forEach((w, i) => {
        const Wd = WEAPONS[w], x = x0 + i * sw, sel = w === p.weapon;
        ctx.fillStyle = sel ? 'rgba(255,255,255,0.2)' : 'rgba(255,255,255,0.05)'; ctx.fillRect(x, y0, sw - 1, 22);
        if (sel) { ctx.fillStyle = Wd.color; ctx.fillRect(x, y0, sw - 1, 1); ctx.fillRect(x, y0 + 21, sw - 1, 1); }
        drawWeaponIcon(ctx, Wd, x + 8, y0 + 7, this.real);
        this.tx(ctx, Wd.key, x + 8, y0 + 15, sel ? Wd.color : '#8a93b8', '#000', 1, 'center');
      });
      this.tx(ctx, WEAPONS[p.weapon].name, x0 + (n * sw) / 2, y0 + 25, WEAPONS[p.weapon].color, '#000', 1, 'center');
      ctx.globalAlpha = 1;
    }
    // ---- prompt pintu / tangga
    if (!p.dead && !p.door && p.onGround && p.phase === 'none') {
      const d = this.atDoor();
      if (d && (d.up || d.down)) { const s = toS(d.x, d.yF - 36); this.tx(ctx, `${d.up ? 'W NAIK' : ''}${d.up && d.down ? '  ' : ''}${d.down ? 'S TURUN' : ''}`, s.x, s.y, '#3ddc84', '#000', 1, 'center'); }
      const l = this.atLadder(p);
      if (l && !d) { const s = toS(l.x, p.y - 30); this.tx(ctx, 'W/S PANJAT', s.x, s.y, '#e7b85c', '#000', 1, 'center'); }
    }
    // ---- adu pukulan
    if (this.clash) {
      const C = this.clash;
      ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.fillRect(VW / 2 - 90, VH - 52, 180, 16);
      ctx.fillStyle = '#ff3b3b'; ctx.fillRect(VW / 2 - 86, VH - 48, 172, 8);
      ctx.fillStyle = '#5ff0ff'; ctx.fillRect(VW / 2 - 86, VH - 48, Math.round(172 * clamp(C.power, 0, 1)), 8);
      ctx.fillStyle = '#fff'; ctx.fillRect(VW / 2 - 1, VH - 50, 2, 12);
      this.tx(ctx, 'KAMU', VW / 2 - 88, VH - 60, '#5ff0ff', '#000', 1);
      this.tx(ctx, C.e.name, VW / 2 + 88, VH - 60, '#ff5a5a', '#000', 1, 'right');
    }
    // ---- banner
    if (this.banner) {
      const B = this.banner, k = B.t / B.max;
      const inK = clamp(B.t / 0.18, 0, 1), outK = clamp((B.max - B.t) / 0.3, 0, 1);
      ctx.globalAlpha = Math.min(inK, outK);
      const y = VH * 0.36 - (1 - inK) * 14;
      ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(0, y - 6, VW, B.sub ? 40 : 30);
      ctx.fillStyle = B.c; ctx.fillRect(0, y - 6, VW, 1); ctx.fillRect(0, y + (B.sub ? 33 : 23), VW, 1);
      this.tx(ctx, B.text, VW / 2 + (1 - inK) * 30, y, B.c, '#000', B.text.length <= 14 ? 4 : B.text.length <= 22 ? 3 : 2, 'center');
      if (B.sub) this.tx(ctx, B.sub, VW / 2, y + 24, '#ffffff', '#000', 1, 'center');
      ctx.globalAlpha = 1; void k;
    }
    if (this.toast && this.state === 'playing') {
      const Tt = this.toast, a = Math.max(0, Math.min(1, Tt.t / 0.12, (Tt.max - Tt.t) / 0.3));
      const w = Tt.text.length * 4 + 10;
      ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(4,8,18,0.72)'; ctx.fillRect(Math.round(VW / 2 - w / 2), 36, w, 11);
      ctx.fillStyle = Tt.c; ctx.fillRect(Math.round(VW / 2 - w / 2), 36, 2, 11);
      this.tx(ctx, Tt.text, VW / 2, 39, Tt.c, '#000', 1, 'center');
      ctx.globalAlpha = 1;
    }
    if (this.hint > 0 && this.state === 'playing' && this.letter < 0.05 && !(this.bossRef && !this.bossRef.dead)) {
      ctx.globalAlpha = Math.min(1, this.hint / 1.5);
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(0, VH - 22, VW, 22);
      this.tx(ctx, this.ctrl === 'v2' ? 'A/D JALAN  SPASI LOMPAT  KLIK KIRI RINGAN/TEMBAK  KLIK KANAN BERAT/TRIK  MOUSE = ARAH  SHIFT DASH' : 'A/D JALAN  SPASI LOMPAT  J PUKUL/TEMBAK  K BERAT  L DASH  C TANGKIS  R CHI  G ANGKAT', VW / 2, VH - 19, '#ffffff', '#000', 1, 'center');
      this.tx(ctx, this.ctrl === 'v2' ? '1-0 Z T Y U I J SENJATA  Q/RODA GANTI  C TANGKIS  N GERBANG  X OFA  F EKSEKUSI  G ANGKAT  R CHI' : '1-0 Z T Y U I B SENJATA  Q GANTI  N GERBANG  X ONE FOR ALL  F EKSEKUSI', VW / 2, VH - 10, '#ffd166', '#000', 1, 'center');
      ctx.globalAlpha = 1;
    }
  }
  private arrow(ctx: CanvasRenderingContext2D, x: number, y: number, dir: number, c: string) {
    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.moveTo(x + dir * 6, y); ctx.lineTo(x - dir * 4, y - 7); ctx.lineTo(x - dir * 4, y + 7); ctx.closePath(); ctx.fill();
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.moveTo(x + dir * 4, y); ctx.lineTo(x - dir * 3, y - 5); ctx.lineTo(x - dir * 3, y + 5); ctx.closePath(); ctx.fill();
  }
}
