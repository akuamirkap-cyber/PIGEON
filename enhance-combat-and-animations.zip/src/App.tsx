import { useState } from 'react';
import V2Shell from './v2/V2Shell';
import MaxkungfuGame from './games/maxkungfu/App';
import OfficeApp from './games/office/OfficeApp';
import Editor from './games/office/Editor';
import { loadCustomMap, type OfficeMap } from './games/office/map';
import { defaultMap } from './games/office/gen';
import { ATMO_LIST, type AtmoId } from './games/office/atmo';
import { setTallMode, tallModeOn } from './games/maxkungfu/game/stick';
import type { Game, UIState } from './games/maxkungfu/game/game';
import { SOUND_VERSIONS, type SoundVersion } from './games/maxkungfu/game/soundPacks';

type Arena = 'office' | 'editor' | 'classic';

function initialVersion(): SoundVersion {
  // Default V2 (pukulan, tendangan, pentungan). Bisa ditimpa lewat URL: ?v=1 / ?v=2 / ?v=3
  const param = new URLSearchParams(window.location.search).get('v');
  const match = SOUND_VERSIONS.find((v) => v.id === `v${param}`);
  return match ? match.id : 'v2';
}
function initialArena(): Arena {
  // ?arena=classic -> arena 3/4 top-down asli, ?arena=editor -> langsung desain map
  const a = new URLSearchParams(window.location.search).get('arena');
  return a === 'classic' || a === 'editor' ? a : 'office';
}

const handle = () => (window as unknown as { __kf?: Game }).__kf;

function Group({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="sound-bar__unit">
      <span className="sound-bar__label">{label}</span>
      <div className="sound-bar__group" role="group" aria-label={label}>{children}</div>
    </div>
  );
}

function V1App({ onGame }: { onGame: (g: 'v1' | 'v2') => void }) {
  const [version, setVersion] = useState<SoundVersion>(initialVersion);
  const [ui, setUi] = useState<UIState | null>(null);
  const [arena, setArena] = useState<Arena>(initialArena);
  const [editMap, setEditMap] = useState<OfficeMap>(() => loadCustomMap() ?? defaultMap());
  const [testMap, setTestMap] = useState<OfficeMap | null>(null);
  const [officeKey, setOfficeKey] = useState(0);
  const [tall, setTall] = useState(tallModeOn());
  const [officeAtmo, setOfficeAtmo] = useState<'auto' | AtmoId>(() => {
    try { const m = localStorage.getItem('office_atmo'); return m === 'auto' || ATMO_LIST.some((a) => a.id === m) ? (m as 'auto' | AtmoId) : 'auto'; } catch { return 'auto'; }
  });
  const [officeCtrl, setOfficeCtrl] = useState<'v2' | 'kbd'>(() => { try { return localStorage.getItem('office_ctrl') === 'kbd' ? 'kbd' : 'v2'; } catch { return 'v2'; } });
  const [officeTempo, setOfficeTempo] = useState<number>(() => {
    try { const t = Number(localStorage.getItem('office_tempo')); return t >= 0.3 && t <= 1 ? t : 0.75; } catch { return 0.75; }
  });
  const active = SOUND_VERSIONS.find((v) => v.id === version);

  const nunStyle = ui?.nunStyle ?? 'v3';
  const showHits = ui?.showHits ?? false;

  const goOffice = () => { setTestMap(null); setOfficeKey((k) => k + 1); setArena('office'); };
  const goEditor = () => setArena('editor');
  const goClassic = () => setArena('classic');

  const gameGroup = (
    <div className="game-switch"><Group label="GAME">
      <button type="button" className="sound-bar__btn" title="Game V1: Menara Kantor side view (game utama)" aria-pressed>V1</button>
      <button type="button" className="sound-bar__btn" title="Game V2: versi kantor dari zip kedua (numpang, terpisah)" aria-pressed={false} onClick={() => onGame('v2')}>V2</button>
    </Group></div>
  );
  const arenaGroup = (
    <Group label="ARENA">
      <button type="button" className="sound-bar__btn" title="Arena asli Kungfu Drifter: tampilan 3/4 top-down"
        aria-pressed={arena === 'classic'} onClick={goClassic}>3/4 TOPDOWN</button>
      <button type="button" className="sound-bar__btn" title="Menara kantor bertingkat side view: musuh datang dari kiri & kanan"
        aria-pressed={arena === 'office'} onClick={goOffice}>SIDE VIEW</button>
      <button type="button" className="sound-bar__btn" title="Editor: rancang gedung kantor sendiri lalu uji main"
        aria-pressed={arena === 'editor'} onClick={goEditor}>DESAIN MAP</button>
    </Group>
  );
  const soundGroup = (
    <Group label="SUARA">
      {SOUND_VERSIONS.map((v) => (
        <button key={v.id} type="button" className="sound-bar__btn" title={v.hint}
          aria-label={`Suara ${v.label}`} aria-pressed={v.id === version} onClick={() => setVersion(v.id)}>{v.label}</button>
      ))}
    </Group>
  );

  if (arena === 'editor') {
    return (
      <div className="flex h-full w-full flex-col bg-black">
        <Editor initial={editMap} onChange={setEditMap}
          onPlay={(m) => { setEditMap(m); setTestMap(m); setOfficeKey((k) => k + 1); setArena('office'); }}
          onExit={goOffice} />
      </div>
    );
  }

  if (arena === 'office') {
    return (
      <div className="flex h-full w-full flex-col bg-black">
        <OfficeApp key={`${version}-${officeKey}`} soundVersion={version} testMap={testMap} tempo={officeTempo} atmo={officeAtmo} ctrl={officeCtrl}
          onClassic={goClassic} onEditor={goEditor} onV2={() => onGame('v2')} onBackToEditor={testMap ? goEditor : undefined} />
        <div id="sound-bar" className="sound-bar arena-bar">
          {gameGroup}{arenaGroup}
          {soundGroup}
          <Group label="TEMPO">
            {([[1, 'CEPAT', 'Kecepatan jurus asli'], [0.75, 'NYAMAN', 'Sedikit lebih pelan: gerakan jelas & nyaman (bawaan)'], [0.55, 'PELAN', 'Ayunan pelan, tiap pukulan terbaca'], [0.4, 'SINEMATIK', 'Sangat pelan & dramatis']] as const).map(([v, label, hint]) => (
              <button key={label} type="button" className="sound-bar__btn" title={hint} aria-label={`Tempo jurus ${label}`}
                aria-pressed={officeTempo === v} onClick={() => setOfficeTempo(v)}>{label}</button>
            ))}
          </Group>
          <Group label="KONTROL">
            <button type="button" className="sound-bar__btn" title="Sama dengan game V2: mouse membidik & menentukan arah hadap, klik kiri ringan / tembak, klik kanan berat / trik, J = tinju" aria-pressed={officeCtrl === 'v2'} onClick={() => setOfficeCtrl('v2')}>V2 MOUSE</button>
            <button type="button" className="sound-bar__btn" title="Keyboard saja: J ringan, K berat, B tinju, W/S membidik" aria-pressed={officeCtrl === 'kbd'} onClick={() => setOfficeCtrl('kbd')}>KEYBOARD</button>
          </Group>
          <Group label="SUASANA">
            <button type="button" className="sound-bar__btn" title="Otomatis: waktu berjalan tiap wave (pagi > siang > sore > malam > subuh), kadang hujan deras" aria-pressed={officeAtmo === 'auto'} onClick={() => setOfficeAtmo('auto')}>AUTO</button>
            {ATMO_LIST.map((a) => (
              <button key={a.id} type="button" className="sound-bar__btn" title={`Suasana ${a.name}`} aria-pressed={officeAtmo === a.id} onClick={() => setOfficeAtmo(a.id)}>{a.id === 'hujan' ? 'HUJAN' : a.name}</button>
            ))}
          </Group>
          <Group label="MODEL">
            <button type="button" className="sound-bar__btn" title="Proporsi stickman lebih tinggi: badan, tangan, kaki memanjang"
              aria-pressed={tall} onClick={() => { setTallMode(!tall); setTall(!tall); }}>PANJANG</button>
          </Group>
          <span className="sound-bar__hint">SIDE VIEW: tahan serbuan dari kiri &amp; kanan, naik lantai demi lantai sampai atap.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full w-full flex-col bg-black">
      <div className="game-shell">
        {/* key -> game dibuat ulang saat versi suara berganti (audio lama ditutup oleh destroy()) */}
        <MaxkungfuGame key={version} soundVersion={version} onState={setUi} onArena={(a) => (a === 'office' ? goOffice() : goEditor())} />
      </div>

      <div id="sound-bar" className="sound-bar">
        {gameGroup}{arenaGroup}
        {soundGroup}

        <Group label="NUNCHAKU">
          {(['v1', 'v2', 'v3'] as const).map((s) => (
            <button key={s} type="button" className="sound-bar__btn"
              title={s === 'v3' ? 'Fire Trail — jejak api atraksi' : s === 'v2' ? 'Stick Fist klasik' : 'Drifter klasik'}
              aria-label={`Nunchaku ${s === 'v3' ? 'Api' : s.toUpperCase()}`}
              aria-pressed={nunStyle === s}
              onClick={() => handle()?.selectNunStyle(s)}>{s === 'v3' ? 'API' : s.toUpperCase()}</button>
          ))}
        </Group>

        <Group label="BOXING">
          {([['ali', 'ALI'], ['tyson', 'TYSON'], ['ippo', 'IPPO']] as const).map(([id, label]) => (
            <button key={id} type="button" className="sound-bar__btn"
              title={id === 'ali' ? 'Ali Shuffle — melayang, flicker jab' : id === 'tyson' ? 'Peek-a-Boo — merunduk, hook & uppercut' : 'Dempsey Roll — menekan, body blow & Gazelle'}
              aria-label={`Boxing ${label}`}
              aria-pressed={ui?.weapon === 'boxing' && ui?.boxStance === id}
              onClick={() => handle()?.selectBoxStance(id)}>{label}</button>
          ))}
        </Group>

        <Group label="MODE">
          <button type="button" className="sound-bar__btn" title="Bertahan dari gelombang musuh tanpa akhir"
            aria-label="Mode Wave" aria-pressed={ui?.mode === 'survival' && !ui?.campaign} onClick={() => handle()?.startWaveMode()}>WAVE</button>
          <button type="button" className="sound-bar__btn" title="Story: tiap wave diakhiri bos bersenjata. Menang = senjata baru"
            aria-label="Mode Story" aria-pressed={!!ui?.campaign} onClick={() => handle()?.startStoryMode()}>STORY</button>
          <button type="button" className="sound-bar__btn" title="Tim 20 lawan 20: kamu + 19 sekutu (nama biru) melawan 20 musuh (nama merah)"
            aria-label="Mode Tim 20 lawan 20" aria-pressed={ui?.mode === 'team'} onClick={() => handle()?.startTeamMode()}>TIM</button>
        </Group>

        <Group label="TEMPO">
          {([[1, 'NORMAL', 'Kecepatan serangan asli'], [0.5, 'NATURAL', 'Ayunan setengah kecepatan, terasa natural  (tombol [ dan ])'], [0.35, 'PELAN', 'Ayunan pelan dan nyaman'], [0.25, 'SANTAI', 'Ayunan sangat pelan, sinematik']] as const).map(([v, label, hint]) => (
            <button key={label} type="button" className="sound-bar__btn" title={hint} aria-label={`Tempo serangan ${label}`}
              aria-pressed={(ui?.tempo ?? 1) === v} onClick={() => handle()?.setTempo(v)}>{label}</button>
          ))}
        </Group>

        <Group label="GAMBAR">
          <button type="button" className="sound-bar__btn" title="Tampilan pixel asli" aria-label="Gambar pixel"
            aria-pressed={!(ui?.view2d ?? false)} onClick={() => handle()?.set2D(false)}>PIXEL</button>
          <button type="button" className="sound-bar__btn" title="Versi 2D mulus tanpa blok pixel, dengan bayangan lembut" aria-label="Gambar 2D halus"
            aria-pressed={ui?.view2d ?? false} onClick={() => handle()?.set2D(true)}>2D HALUS</button>
        </Group>

        <Group label="MODEL">
          <button type="button" className="sound-bar__btn" title="Proporsi stickman lebih tinggi: badan, tangan, kaki memanjang"
            aria-pressed={ui?.tall ?? false} onClick={() => handle()?.toggleTall()}>PANJANG</button>
          <button type="button" className="sound-bar__btn" title="Render halus dengan bayangan dan cahaya kedalaman, tanpa pixelated"
            aria-pressed={ui?.smooth ?? false} onClick={() => handle()?.toggleSmooth()}>3D HALUS</button>
        </Group>

        <Group label="BOT">
          <button type="button" className="sound-bar__btn" title="Bot sekutu ahli kombo + fatality (tombol M)"
            aria-pressed={ui?.botOn ?? false} onClick={() => handle()?.toggleBot()}>BOT</button>
          <button type="button" className="sound-bar__btn" title="Musuh cermin yang memakai senjata pemain secara live"
            aria-pressed={ui?.mirrorOn ?? false} onClick={() => handle()?.spawnMirror()}>MIRROR</button>
        </Group>

        <Group label="FX">
          <button type="button" className="sound-bar__btn" title="Filter retro: vignette + garis pindai"
            aria-label="Filter retro" aria-pressed={ui?.filters ?? false}
            onClick={() => handle()?.setFilters(!(ui?.filters ?? false))}>{(ui?.filters ?? false) ? 'ON' : 'OFF'}</button>
        </Group>

        <Group label="TEKS">
          <button type="button" className="sound-bar__btn" title="Hanya judul jurus pamungkas"
            aria-pressed={!showHits} onClick={() => handle()?.setShowHits(false)}>MIN</button>
          <button type="button" className="sound-bar__btn" title="Tampilkan kata tiap hantaman"
            aria-pressed={showHits} onClick={() => handle()?.setShowHits(true)}>FULL</button>
        </Group>

        <span className="sound-bar__hint">{active?.hint}</span>
      </div>
    </div>
  );
}

type GameVer = 'v1' | 'v2';
function initialGame(): GameVer {
  const q = new URLSearchParams(window.location.search).get('game');
  if (q === 'v1' || q === 'v2') return q;
  try { return localStorage.getItem('kd_game_version') === 'v1' ? 'v1' : 'v2'; } catch { return 'v2'; }
}

/** Pemilih game: V1 = Menara Kantor (utama), V2 = game zip kedua yang numpang & terisolasi. */
export default function App() {
  const [game, setGame] = useState<GameVer>(initialGame);
  const choose = (g: GameVer) => { try { localStorage.setItem('kd_game_version', g); } catch { /* */ } setGame(g); };
  if (game === 'v2') return <V2Shell onBack={() => choose('v1')} />;
  return <V1App onGame={choose} />;
}
