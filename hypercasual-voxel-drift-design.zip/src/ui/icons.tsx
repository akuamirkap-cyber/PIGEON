interface IconProps {
  className?: string;
}

/** koin voxel (kotak diputar 45°) */
export function Gem({ className = '' }: IconProps) {
  return (
    <span
      aria-hidden="true"
      className={`inline-block size-3.5 shrink-0 rotate-45 rounded-[3px] border-2 border-ink bg-sun ${className}`}
    />
  );
}

export function Trophy({ className = '' }: IconProps) {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className={`size-4 shrink-0 ${className}`} fill="currentColor">
      <path d="M7 3h10v2h3v3a4 4 0 0 1-4 4h-.3A5 5 0 0 1 13 14.9V18h3v3H8v-3h3v-3.1A5 5 0 0 1 8.3 12H8a4 4 0 0 1-4-4V5h3V3Zm0 4H6v1a2 2 0 0 0 1 1.7V7Zm10 0v2.7A2 2 0 0 0 18 8V7h-1Z" />
    </svg>
  );
}

export function Sound({ muted, className = '' }: IconProps & { muted: boolean }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      className={`size-5 shrink-0 ${className}`}
      fill="none"
      stroke="currentColor"
      strokeWidth="2.6"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 9.5h3l5-4v13l-5-4H4z" fill="currentColor" />
      {muted ? <path d="m16 9.5 5 5m0-5-5 5" /> : <path d="M16 9a4.2 4.2 0 0 1 0 6m2.6-8.6a8 8 0 0 1 0 11.2" />}
    </svg>
  );
}

export function Chevron({ dir, className = '' }: IconProps & { dir: 'left' | 'right' }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      className={`size-6 shrink-0 ${className}`}
      fill="none"
      stroke="currentColor"
      strokeWidth="4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d={dir === 'left' ? 'M15 5l-7 7 7 7' : 'M9 5l7 7-7 7'} />
    </svg>
  );
}

export function Lock({ className = '' }: IconProps) {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className={`size-5 shrink-0 ${className}`} fill="currentColor">
      <path d="M12 2a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5Zm-2.4 5a2.4 2.4 0 0 1 4.8 0v3H9.6V7Z" />
    </svg>
  );
}

export function CamIcon({ className = '' }: IconProps) {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className={`size-5 shrink-0 ${className}`} fill="currentColor">
      <path d="M4 7a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2.2l3.6-2.4A1 1 0 0 1 21 7.6v8.8a1 1 0 0 1-1.4.8L16 14.8V17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7Z" />
    </svg>
  );
}
