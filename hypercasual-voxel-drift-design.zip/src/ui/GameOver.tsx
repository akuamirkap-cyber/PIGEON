import { useEffect, useState } from 'react';
import type { CarDef } from '../game/cars';
import { Gem } from './icons';

export interface Result {
  id: number;
  score: number;
  gems: number;
  perfects: number;
  bestCombo: number;
  best: number;
  newBest: boolean;
  message: string;
}

interface Props {
  result: Result;
  totalGems: number;
  nextCar: CarDef | null;
  onRetry: () => void;
  onMenu: () => void;
}

function useCountUp(target: number, ms: number) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (target <= 0) {
      setV(0);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      const k = Math.min(1, (now - t0) / ms);
      setV(Math.round(target * (1 - Math.pow(1 - k, 3))));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

function Stat({ label, value, gem }: { label: string; value: string | number; gem?: boolean }) {
  return (
    <div className="rounded-2xl bg-ink/[0.06] px-2 py-2">
      <div className="flex items-center justify-center gap-1.5 text-xl font-bold leading-none tabular-nums">
        {gem && <Gem />}
        {value}
      </div>
      <div className="mt-1 text-[0.65rem] font-bold tracking-[0.14em] text-ink/55">{label}</div>
    </div>
  );
}

export default function GameOver({ result, totalGems, nextCar, onRetry, onMenu }: Props) {
  const shown = useCountUp(result.score, Math.min(900, 250 + result.score * 25));
  const canUnlock = !!nextCar && totalGems >= nextCar.price;
  const pct = nextCar ? Math.min(100, Math.round((totalGems / nextCar.price) * 100)) : 100;

  return (
    <div className="absolute inset-0 flex items-end justify-center px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-3 font-game sm:items-center short:items-center short:pb-3">
      <div
        role="dialog"
        aria-label="Hasil permainan"
        className="anim-rise pointer-events-auto max-h-full w-full max-w-sm overflow-y-auto rounded-[2rem] border-[3px] border-ink bg-white p-5 text-center text-ink shadow-[0_8px_0_rgba(38,38,58,0.9)] short:flex short:max-w-2xl short:items-center short:gap-5 short:p-4"
      >
        <div className="short:w-[38%] short:shrink-0">
        <p className="text-sm font-bold tracking-[0.2em] text-coral">{result.message}</p>

        {result.newBest && (
          <div className="anim-bump mx-auto mt-2 w-fit rounded-full border-[3px] border-ink bg-sun px-3 py-0.5 text-sm font-bold">
            ★ REKOR BARU!
          </div>
        )}

        <div className="mt-2 text-[clamp(3.5rem,11vh,5rem)] font-bold leading-none tabular-nums" aria-label={`Skor ${result.score}`}>
          {shown}
        </div>
        <div className="mt-1 text-sm font-bold tracking-wider text-ink/55">TERBAIK {result.best}</div>
        </div>

        <div className="short:min-w-0 short:flex-1">
        <div className="mt-4 grid grid-cols-3 gap-2 short:mt-0">
          <Stat label="PERFECT" value={result.perfects} />
          <Stat label="COMBO" value={`×${result.bestCombo}`} />
          <Stat label="KOIN" value={`+${result.gems}`} gem />
        </div>

        {nextCar && (
          <div className="mt-3 rounded-2xl bg-ink/[0.06] px-3 py-2 text-left">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className={canUnlock ? 'text-coral' : 'text-ink/70'}>
                {canUnlock ? `${nextCar.name} SIAP DIBUKA!` : `MOBIL BARU: ${nextCar.name}`}
              </span>
              <span className="flex items-center gap-1.5 tabular-nums">
                <Gem className="!size-2.5" />
                {Math.min(totalGems, nextCar.price)}/{nextCar.price}
              </span>
            </div>
            <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-ink/15">
              <div
                className={`h-full rounded-full transition-[width] duration-700 ${canUnlock ? 'bg-coral' : 'bg-sun'}`}
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        )}

        <div className="anim-breathe mt-4 short:mt-3">
          <button
            type="button"
            onClick={onRetry}
            className="btn-3d w-full rounded-2xl border-[3px] border-ink bg-coral py-3 text-2xl font-bold text-white short:py-2"
          >
            MAIN LAGI
          </button>
        </div>
        <button
          type="button"
          onClick={onMenu}
          className={`focus-ring mt-3 rounded-full px-4 py-1.5 text-sm font-bold short:mt-2 short:py-1 underline-offset-4 hover:underline ${
            canUnlock ? 'bg-sun text-ink' : 'text-ink/60'
          }`}
        >
          {canUnlock ? 'KE GARASI — BUKA MOBIL!' : 'GARASI & MOBIL'}
        </button>
        </div>
      </div>
    </div>
  );
}
