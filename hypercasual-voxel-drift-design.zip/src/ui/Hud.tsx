import type { Hint, PopTone } from '../game/Game';
import { camById, CAMERAS, type CamId } from '../game/cameras';
import { CamIcon, Gem } from './icons';

export interface PopItem {
  id: number;
  text: string;
  sub?: string;
  tone: PopTone;
  gain: number;
}

export interface StageMsg {
  id: number;
  index: number;
  name: string;
}

interface Props {
  score: number;
  combo: number;
  gems: number;
  cam: CamId;
  pops: PopItem[];
  hint: Hint;
  stage: StageMsg | null;
  onCam: () => void;
}

const TONE: Record<PopTone, string> = {
  perfect: '#ffd23f',
  good: '#ffffff',
  near: '#ff9a4d',
  swirl: '#7df3ff',
  air: '#b9f5c9',
};

const HINT_TEXT: Record<Exclude<Hint, null>, string> = {
  hold: 'TAHAN!',
  keep: 'TAHAN TERUS…',
  release: 'LEPAS!',
};

export default function Hud({ score, combo, gems, cam, pops, hint, stage, onCam }: Props) {
  const camDef = camById(cam);
  const camIdx = CAMERAS.findIndex((c) => c.id === camDef.id);
  return (
    <div className="absolute inset-0 font-game">
      {/* pemilih kamera cepat (kiri atas) */}
      <button
        type="button"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={onCam}
        aria-label={`Ganti kamera (${camDef.name})`}
        className="btn-3d pointer-events-auto absolute left-3 top-[max(0.75rem,env(safe-area-inset-top))] z-10 flex items-center gap-1.5 rounded-full border-[3px] border-ink bg-white px-3 py-1 text-xs font-bold text-ink"
      >
        <CamIcon className="size-4 text-coral" />
        <span key={camDef.id} className="anim-bump inline-block">
          {camDef.name}
        </span>
        <span className="rounded-full bg-sun px-1.5 py-0.5 text-[0.65rem] leading-none">{camIdx + 1}/4</span>
      </button>

      {/* skor */}
      <div className="absolute inset-x-0 top-0 flex flex-col items-center pt-[max(0.6rem,env(safe-area-inset-top))]">
        <div
          key={score}
          className="anim-bump hud-text text-[clamp(3.5rem,14vmin,6rem)] font-bold leading-none tabular-nums"
          aria-live="polite"
          aria-label={`Skor ${score}`}
        >
          {score}
        </div>
        {combo >= 2 && (
          <div
            key={combo}
            className="anim-bump mt-1 rounded-full border-[3px] border-ink bg-sun px-3 py-0.5 text-sm font-bold text-ink"
          >
            COMBO ×{combo}
          </div>
        )}
      </div>

      {/* koin */}
      <div className="absolute right-3 top-[max(0.75rem,env(safe-area-inset-top))] flex items-center gap-2 rounded-full border-[3px] border-ink bg-white px-3 py-1 text-base font-bold text-ink tabular-nums">
        <Gem />
        <span key={gems} className="anim-bump inline-block">
          {gems}
        </span>
      </div>

      {/* banner ganti stage */}
      {stage && (
        <div className="absolute inset-x-0 top-[19%] flex justify-center overflow-hidden py-2">
          <div
            key={stage.id}
            className="anim-banner border-y-[3px] border-ink bg-white px-10 py-1.5 text-center text-ink shadow-[0_5px_0_rgba(38,38,58,0.9)]"
          >
            <div className="text-xs font-bold tracking-[0.25em] text-coral">STAGE {stage.index}</div>
            <div className="text-2xl font-bold leading-tight">{stage.name}</div>
          </div>
        </div>
      )}

      {/* popup PERFECT / MANTAP / NYARIS */}
      <div className="absolute left-1/2 top-[30%] w-0">
        {pops.map((p) => (
          <div key={p.id} className="anim-pop absolute left-0 top-0 whitespace-nowrap text-center">
            <div
              className="hud-text text-[clamp(2rem,9vmin,3.4rem)] font-bold leading-none"
              style={{ color: TONE[p.tone] }}
            >
              {p.text}
            </div>
            <div className="mt-1.5 flex items-center justify-center gap-1.5 text-sm font-bold">
              {p.sub && <span className="rounded-full border-2 border-ink bg-sun px-2.5 py-0.5 text-ink">{p.sub}</span>}
              <span className="rounded-full border-2 border-ink bg-white px-2.5 py-0.5 text-ink">+{p.gain}</span>
            </div>
          </div>
        ))}
      </div>

      {/* hint tutorial */}
      {hint && (
        <div className="absolute inset-x-0 bottom-[max(1rem,env(safe-area-inset-bottom))] flex justify-center">
          <div
            key={hint === 'keep' ? 'hold' : hint}
            className={`anim-bump flex items-center gap-3 rounded-full border-[3px] border-ink px-6 py-2 text-2xl font-bold short:py-1 short:text-xl shadow-[0_5px_0_rgba(38,38,58,0.9)] ${
              hint === 'release' ? 'bg-coral text-white' : 'bg-white text-ink'
            }`}
          >
            <span className="relative grid size-7 place-items-center">
              {hint === 'release' && <span className="anim-ring absolute inset-0 rounded-full border-[3px] border-white" />}
              <span
                className={`block size-5 rounded-full ${hint === 'release' ? 'bg-white' : 'anim-press bg-coral'}`}
              />
            </span>
            {HINT_TEXT[hint]}
          </div>
        </div>
      )}
    </div>
  );
}
