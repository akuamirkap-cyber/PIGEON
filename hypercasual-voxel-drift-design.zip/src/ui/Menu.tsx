import { CARS } from '../game/cars';
import { camById, CAMERAS } from '../game/cameras';
import type { Save } from '../game/storage';
import { CamIcon, Chevron, Gem, Lock, Sound, Trophy } from './icons';

interface Props {
  save: Save;
  view: number;
  shakeKey: number;
  onPrev: () => void;
  onNext: () => void;
  onBuy: () => void;
  onMute: () => void;
  onCam: () => void;
}

export default function Menu({ save, view, shakeKey, onPrev, onNext, onBuy, onMute, onCam }: Props) {
  const car = CARS[view];
  const cam = camById(save.cam);
  const camIdx = CAMERAS.findIndex((c) => c.id === cam.id);
  const owned = save.owned.includes(car.id);
  const affordable = save.gems >= car.price;

  return (
    <div className="absolute inset-0 font-game">
      {/* bar atas */}
      <div className="absolute inset-x-0 top-0 z-10 flex justify-center px-4 pt-[max(0.75rem,env(safe-area-inset-top))]">
      <div className="flex w-full max-w-2xl items-center justify-between short:max-w-none">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onMute}
            aria-label={save.muted ? 'Nyalakan suara' : 'Matikan suara'}
            aria-pressed={save.muted}
            className="btn-3d pointer-events-auto grid size-11 place-items-center rounded-full border-[3px] border-ink bg-white text-ink"
          >
            <Sound muted={save.muted} />
          </button>
          <button
            type="button"
            onClick={onCam}
            aria-label={`Ganti kamera: ${cam.name}`}
            className="btn-3d pointer-events-auto flex h-11 items-center gap-1.5 rounded-full border-[3px] border-ink bg-white px-3 text-xs font-bold text-ink"
          >
            <CamIcon className="text-coral" />
            <span key={cam.id} className="anim-bump hidden sm:inline">
              {cam.name}
            </span>
            <span className="rounded-full bg-sun px-1.5 py-0.5 text-[0.65rem] leading-none">
              {camIdx + 1}/4
            </span>
          </button>
        </div>
        <div className="flex items-center gap-2 text-base font-bold text-ink tabular-nums">
          <div
            className="flex items-center gap-1.5 rounded-full border-[3px] border-ink bg-white px-3 py-1"
            aria-label={`Skor terbaik ${save.best}`}
          >
            <Trophy className="text-coral" />
            {save.best}
          </div>
          <div
            className="flex items-center gap-2 rounded-full border-[3px] border-ink bg-white px-3 py-1"
            aria-label={`Koin ${save.gems}`}
          >
            <Gem />
            <span key={save.gems} className="anim-bump inline-block">
              {save.gems}
            </span>
          </div>
        </div>
      </div>

      </div>

      <div className="absolute inset-0 flex flex-col items-center px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[calc(max(0.75rem,env(safe-area-inset-top))+3.25rem)] short:flex-row short:items-end short:px-6">
      {/* logo */}
      <div className="anim-drop mt-[2vh] flex flex-col items-center short:mb-auto short:mt-[5vh]">
        <h1 className="logo anim-floaty text-center text-[clamp(2.2rem,min(17vw,11.5vh),6.5rem)] font-bold">
          TOUGE
          <br />
          <span className="logo-accent">SLING</span>
        </h1>
        <p className="mt-[max(0.6rem,1.6vh)] rounded-full bg-ink px-4 py-1 text-[0.8rem] font-semibold tracking-[0.18em] text-white">
          VOXEL DRIFT · SATU JARI
        </p>
      </div>

      <div className="flex-1" />

      {/* garasi + CTA */}
      <div className="flex w-full max-w-sm flex-col items-center gap-3 short:w-[17rem] short:gap-2">
        {owned ? (
          <div className="anim-breathe hud-text text-[1.7rem] font-bold short:text-2xl">TAP UNTUK MAIN</div>
        ) : (
          <div key={shakeKey} className={shakeKey ? 'anim-wiggle' : ''}>
            <button
              type="button"
              onClick={onBuy}
              aria-disabled={!affordable}
              className={`btn-3d pointer-events-auto flex items-center gap-2.5 rounded-full border-[3px] border-ink px-6 py-2.5 text-xl font-bold ${
                affordable ? 'bg-sun text-ink' : 'bg-white text-ink/55'
              }`}
            >
              <Lock />
              {affordable ? 'BUKA' : 'KURANG'}
              <span className="flex items-center gap-2 tabular-nums">
                <Gem />
                {affordable ? car.price : car.price - save.gems}
              </span>
            </button>
          </div>
        )}

        <div className="flex w-full items-center gap-2.5">
          <button
            type="button"
            onClick={onPrev}
            aria-label="Mobil sebelumnya"
            className="btn-3d pointer-events-auto grid size-12 shrink-0 place-items-center rounded-2xl border-[3px] border-ink bg-white text-ink"
          >
            <Chevron dir="left" />
          </button>
          <div
            key={car.id}
            className="anim-bump min-w-0 flex-1 rounded-2xl border-[3px] border-ink bg-white px-3 py-1.5 text-center text-ink shadow-[0_5px_0_rgba(38,38,58,0.9)]"
            aria-live="polite"
          >
            <div className="truncate text-xl font-bold leading-tight">{car.name}</div>
            <div className="truncate text-xs font-semibold text-ink/60">
              {owned ? car.tag : `terkunci · ${car.price} koin`}
            </div>
          </div>
          <button
            type="button"
            onClick={onNext}
            aria-label="Mobil berikutnya"
            className="btn-3d pointer-events-auto grid size-12 shrink-0 place-items-center rounded-2xl border-[3px] border-ink bg-white text-ink"
          >
            <Chevron dir="right" />
          </button>
        </div>

        <div className="flex items-center gap-1.5" aria-hidden="true">
          {CARS.map((c, i) => (
            <span
              key={c.id}
              className={`block rounded-full border-2 border-ink transition-all ${i === view ? 'size-3.5' : 'size-2.5'} ${
                save.owned.includes(c.id) ? 'bg-sun' : 'bg-white/70'
              }`}
            />
          ))}
        </div>

        <p className="rounded-full bg-white/80 px-3 py-1 text-[0.72rem] font-bold tracking-[0.14em] text-ink">
          TAHAN = DRIFT · LEPAS = LURUS
        </p>
      </div>
      </div>
    </div>
  );
}
