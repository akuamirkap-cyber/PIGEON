import { useCallback, useEffect, useRef, useState } from 'react';
import { Game, type GameEvent, type GameState, type Hint } from './game/Game';
import { CARS } from './game/cars';
import { CAMERAS } from './game/cameras';
import { loadSave, persist, type Save } from './game/storage';
import Hud, { type PopItem, type StageMsg } from './ui/Hud';
import Menu from './ui/Menu';
import GameOver, { type Result } from './ui/GameOver';

const OVER_LINES = ['YAH, NYEMPLUNG!', 'KEBABLASAN!', 'DIKIT LAGI!', 'WADUH, JATUH!', 'OVERSTEER, BOS!', 'REM-NYA MANA?!'];

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const popId = useRef(0);
  const timers = useRef<number[]>([]);

  const [save, setSave] = useState<Save>(() => loadSave());
  const saveRef = useRef(save);

  const [state, setState] = useState<GameState>('menu');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [runGems, setRunGems] = useState(0);
  const [hint, setHint] = useState<Hint>(null);
  const [pops, setPops] = useState<PopItem[]>([]);
  const [stage, setStage] = useState<StageMsg | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [shakeKey, setShakeKey] = useState(0);
  const [view, setView] = useState(() =>
    Math.max(
      0,
      CARS.findIndex((c) => c.id === save.car),
    ),
  );

  const viewRef = useRef(view);

  const commit = useCallback((next: Save) => {
    saveRef.current = next;
    setSave(next);
    persist(next);
  }, []);

  // ── engine ──
  useEffect(() => {
    const el = mount.current;
    if (!el) return;
    const pending = timers.current;

    const handle = (e: GameEvent) => {
      switch (e.type) {
        case 'state':
          setState(e.state);
          if (e.state === 'playing') {
            setScore(0);
            setCombo(0);
            setRunGems(0);
            setPops([]);
            setHint(null);
            setStage(null);
            setResult(null);
          }
          break;
        case 'score':
          setScore(e.score);
          setCombo(e.combo);
          break;
        case 'gems':
          setRunGems(e.run);
          break;
        case 'hint':
          setHint(e.hint);
          break;
        case 'pop': {
          const id = ++popId.current;
          setPops((p) => [...p.slice(-2), { id, text: e.text, sub: e.sub, tone: e.tone, gain: e.gain }]);
          pending.push(window.setTimeout(() => setPops((p) => p.filter((x) => x.id !== id)), 960));
          break;
        }
        case 'stage':
          setStage({ id: Date.now(), index: e.index, name: e.name });
          break;
        case 'locked':
          setShakeKey((k) => k + 1);
          break;
        case 'over': {
          const prev = saveRef.current;
          const best = Math.max(prev.best, e.score);
          const next: Save = { ...prev, best, gems: prev.gems + e.gems, plays: prev.plays + 1 };
          commit(next);
          setResult({
            id: Date.now(),
            score: e.score,
            gems: e.gems,
            perfects: e.perfects,
            bestCombo: e.bestCombo,
            best,
            newBest: e.score > prev.best && e.score > 0,
            message: OVER_LINES[Math.floor(Math.random() * OVER_LINES.length)],
          });
          if (gameRef.current) gameRef.current.tutorial = best < 3;
          break;
        }
      }
    };

    const s0 = saveRef.current;
    const game = new Game(el, handle, { car: s0.car, cam: s0.cam, muted: s0.muted, tutorial: s0.best < 3 });
    gameRef.current = game;
    return () => {
      game.dispose();
      gameRef.current = null;
      pending.forEach((t) => window.clearTimeout(t));
      pending.length = 0;
    };
  }, [commit]);

  // ── garasi ──
  const cycle = useCallback(
    (dir: number) => {
      const n = (viewRef.current + dir + CARS.length) % CARS.length;
      viewRef.current = n;
      setView(n);
      const def = CARS[n];
      const s = saveRef.current;
      const owned = s.owned.includes(def.id);
      gameRef.current?.setCar(def.id, owned);
      if (owned && s.car !== def.id) commit({ ...s, car: def.id });
    },
    [commit],
  );

  const buy = useCallback(() => {
    const def = CARS[view];
    const s = saveRef.current;
    if (s.owned.includes(def.id)) return;
    if (s.gems < def.price) {
      gameRef.current?.deny();
      setShakeKey((k) => k + 1);
      return;
    }
    commit({ ...s, gems: s.gems - def.price, owned: [...s.owned, def.id], car: def.id });
    gameRef.current?.setCanStart(true);
    gameRef.current?.celebrate();
  }, [view, commit]);

  const toggleMute = useCallback(() => {
    const s = saveRef.current;
    const muted = !s.muted;
    commit({ ...s, muted });
    gameRef.current?.setMuted(muted);
  }, [commit]);

  const cycleCam = useCallback(() => {
    const s = saveRef.current;
    const i = CAMERAS.findIndex((c) => c.id === s.cam);
    const next = CAMERAS[(i + 1) % CAMERAS.length].id;
    commit({ ...s, cam: next });
    gameRef.current?.setCam(next);
  }, [commit]);

  const retry = useCallback(() => gameRef.current?.start(), []);
  const toMenu = useCallback(() => gameRef.current?.toMenu(), []);

  // pintasan keyboard: C ganti kamera, panah kiri/kanan ganti mobil di menu
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'KeyC' && !e.repeat) {
        cycleCam();
        return;
      }
      if (state === 'menu') {
        if (e.code === 'ArrowLeft') cycle(-1);
        else if (e.code === 'ArrowRight') cycle(1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [state, cycle, cycleCam]);

  const nextCar = CARS.find((c) => !save.owned.includes(c.id)) ?? null;

  return (
    <main className="fixed inset-0 overflow-hidden select-none">
      <div
        ref={mount}
        className="absolute inset-0 touch-none"
        role="application"
        aria-label="Touge Sling: tahan untuk drift, lepas untuk melaju lurus"
      />

      <div className="pointer-events-none absolute inset-0">
        {state === 'menu' && (
          <Menu
            save={save}
            view={view}
            shakeKey={shakeKey}
            onPrev={() => cycle(-1)}
            onNext={() => cycle(1)}
            onBuy={buy}
            onMute={toggleMute}
            onCam={cycleCam}
          />
        )}

        {(state === 'playing' || state === 'falling') && (
          <Hud
            score={score}
            combo={combo}
            gems={runGems}
            cam={save.cam}
            pops={pops}
            hint={hint}
            stage={stage}
            onCam={cycleCam}
          />
        )}

        {state === 'over' && result && (
          <GameOver key={result.id} result={result} totalGems={save.gems} nextCar={nextCar} onRetry={retry} onMenu={toMenu} />
        )}
      </div>
    </main>
  );
}
