import { CAMERAS, type CamId } from './cameras';

const KEY = 'touge-sling-save-v1';

export interface Save {
  best: number;
  gems: number;
  owned: string[];
  car: string;
  cam: CamId;
  muted: boolean;
  plays: number;
}

const DEFAULTS: Save = {
  best: 0,
  gems: 0,
  owned: ['mochi'],
  car: 'mochi',
  cam: 'sling',
  muted: false,
  plays: 0,
};

export function loadSave(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS, owned: [...DEFAULTS.owned] };
    const data = JSON.parse(raw) as Partial<Save>;
    const owned = Array.isArray(data.owned) && data.owned.length ? data.owned : ['mochi'];
    if (!owned.includes('mochi')) owned.unshift('mochi');
    const validCam = CAMERAS.some((c) => c.id === data.cam) ? (data.cam as CamId) : 'sling';
    return {
      best: Number(data.best) || 0,
      gems: Number(data.gems) || 0,
      owned,
      car: typeof data.car === 'string' && owned.includes(data.car) ? data.car : 'mochi',
      cam: validCam,
      muted: !!data.muted,
      plays: Number(data.plays) || 0,
    };
  } catch {
    return { ...DEFAULTS, owned: [...DEFAULTS.owned] };
  }
}

export function persist(save: Save) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* storage penuh / private mode: abaikan, game tetap jalan */
  }
}
