/**
 * Track prosedural tanpa ujung.
 *
 * Track = deretan "papan" (sample) berjarak ~1 unit. Semuanya terus MENURUN
 * (ala touge downhill), jadi track boleh saling tumpuk di sumbu XZ — itu yang
 * bikin swirl/helix turun bisa ada di versi 3D ini.
 *
 * Konvensi arah (lihat dari atas, Y ke atas):
 *   heading th  → maju  = ( sin th, cos th)
 *                 kiri  = ( cos th, -sin th)
 *   belok kiri  → th bertambah (turn = +1)
 */

export const HW = 3.3; // setengah lebar track normal
export const START_I = 6; // index sample tempat mobil mulai
export const GATE_I = 3; // index gerbang start

export const K_STRAIGHT = 0;
export const K_ARC = 1;
export const K_HELIX = 2;
export const K_RAMP = 3;
export const K_NARROW = 4;

export interface Sample {
  x: number;
  z: number;
  /** tinggi permukaan papan */
  y: number;
  /** tinggi yang dilalui mobil (beda dengan y saat melayang di atas gap) */
  carY: number;
  th: number;
  hw: number;
  kind: number;
  gap: boolean;
  len: number;
  lenL: number;
  lenR: number;
  gem: boolean;
  gemTaken: boolean;
  // state animasi (diisi renderer)
  spawnT: number;
  fallT: number;
  pressT: number;
}

export interface Arc {
  cx: number;
  cz: number;
  R: number;
  /** +1 kiri, -1 kanan */
  turn: number;
  startI: number;
  endI: number;
  th0: number;
  th1: number;
  helix: boolean;
  /** tinggi tiang pivot (tikungan biasa) */
  py: number;
  yTop: number;
  yBot: number;
  hw: number;
}

interface StraightOpts {
  hw?: number;
  slope?: number;
  kind?: number;
  gems?: boolean;
}

interface ArcOpts {
  hw?: number;
  slope?: number;
  helix?: boolean;
  gems?: boolean;
}

function mulberry32(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const LOC = { i: 0, f: 0, lat: 0 };

export class Track {
  samples: Sample[] = [];
  arcs: Arc[] = [];

  private x = 0;
  private z = 0;
  private y = 0;
  private th = 0;
  private w = HW;
  /** akumulasi arah bersih, dipakai supaya track tidak muter terus ke satu sisi */
  private net = 0;
  private corners = 0;
  private feat = 0;
  private last = '';
  private sinceHelix = 9;
  private sinceJump = 9;
  private helixCount = 0;
  private r: () => number;

  constructor(seed: number) {
    this.r = mulberry32(seed);
    this.put(K_STRAIGHT, HW, 1.02, 1.02, 1.02, false, this.y);
    this.straight(24, { gems: false });
  }

  /** pastikan sample sampai index i sudah digenerate */
  ensure(i: number) {
    let guard = 0;
    while (this.samples.length <= i && guard++ < 4000) this.next();
  }

  /** cari posisi mobil relatif terhadap track (pencarian lokal di sekitar hint) */
  locate(x: number, z: number, hint: number) {
    const h = Math.floor(hint);
    const a = Math.max(0, h - 4);
    const b = Math.min(this.samples.length - 1, h + 14);
    let bi = a;
    let bd = Infinity;
    for (let i = a; i <= b; i++) {
      const s = this.samples[i];
      const dx = x - s.x;
      const dz = z - s.z;
      const d = dx * dx + dz * dz;
      if (d < bd) {
        bd = d;
        bi = i;
      }
    }
    const s = this.samples[bi];
    const dx = x - s.x;
    const dz = z - s.z;
    const sn = Math.sin(s.th);
    const cs = Math.cos(s.th);
    const along = dx * sn + dz * cs;
    LOC.i = bi;
    LOC.f = bi + Math.max(-0.6, Math.min(0.6, along));
    LOC.lat = dx * cs - dz * sn;
    return LOC;
  }

  heightAt(f: number) {
    const i = Math.max(0, Math.min(this.samples.length - 2, Math.floor(f)));
    const t = Math.max(0, Math.min(1, f - i));
    return this.samples[i].carY * (1 - t) + this.samples[i + 1].carY * t;
  }

  // ───────────────────────────── builder ─────────────────────────────

  private put(
    kind: number,
    hw: number,
    len: number,
    lenL: number,
    lenR: number,
    gap: boolean,
    carY: number,
  ) {
    this.samples.push({
      x: this.x,
      z: this.z,
      y: this.y,
      carY,
      th: this.th,
      hw,
      kind,
      gap,
      len,
      lenL,
      lenR,
      gem: false,
      gemTaken: false,
      spawnT: 1e9,
      fallT: -1,
      pressT: -1,
    });
  }

  private fwd() {
    this.x += Math.sin(this.th);
    this.z += Math.cos(this.th);
  }

  private straight(n: number, o: StraightOpts = {}) {
    const hw = o.hw ?? this.w;
    const slope = o.slope ?? 0.07;
    const kind = o.kind ?? K_STRAIGHT;
    const first = this.samples.length;
    for (let k = 0; k < n; k++) {
      this.fwd();
      this.y -= slope;
      this.put(kind, hw, 1.02, 1.02, 1.02, false, this.y);
    }
    if (o.gems !== false && n >= 7 && this.r() < 0.6) {
      const m = first + Math.floor(n / 2);
      for (const d of [-2, 0, 2]) this.samples[m + d].gem = true;
    }
  }

  private arc(R: number, angle: number, turn: number, o: ArcOpts = {}) {
    const hw = o.hw ?? this.w;
    const helix = !!o.helix;
    const slope = o.slope ?? (helix ? 0.165 : 0.12);
    const n = Math.max(3, Math.round(R * angle));
    const dth = angle / n;
    const step = R * dth;
    const th0 = this.th;
    const cx = this.x + turn * R * Math.cos(th0);
    const cz = this.z - turn * R * Math.sin(th0);
    const startI = this.samples.length - 1;
    const yTop = this.y;
    const kind = helix ? K_HELIX : K_ARC;
    const outer = (step * (R + hw)) / R + 0.08;
    const inner = Math.max(0.35, (step * (R - hw)) / R + 0.08);
    this.samples[startI].kind = kind;

    for (let k = 1; k <= n; k++) {
      const th = th0 + turn * dth * k;
      this.x = cx - turn * R * Math.cos(th);
      this.z = cz + turn * R * Math.sin(th);
      this.y -= slope * step;
      this.th = th;
      this.put(kind, hw, outer, turn > 0 ? inner : outer, turn > 0 ? outer : inner, false, this.y);
    }

    const endI = this.samples.length - 1;
    const mid = (startI + endI) >> 1;
    this.arcs.push({
      cx,
      cz,
      R,
      turn,
      startI,
      endI,
      th0,
      th1: this.th,
      helix,
      py: this.samples[mid].y,
      yTop,
      yBot: this.y,
      hw,
    });

    if (helix) {
      for (let i = startI + 3; i < endI - 1; i += 4) this.samples[i].gem = true;
    } else if (o.gems !== false && n >= 8 && this.r() < 0.5) {
      for (const d of [-2, 0, 2]) this.samples[mid + d].gem = true;
    }

    this.corners++;
    this.net += turn * (helix ? angle % (Math.PI * 2) : angle);
  }

  /** ramp naik → gap kosong → mendarat lebih rendah */
  private jump() {
    this.straight(6, { gems: false });
    for (let k = 0; k < 4; k++) {
      this.fwd();
      this.y += 0.3;
      this.put(K_RAMP, this.w, 1.02, 1.02, 1.02, false, this.y);
    }
    const y0 = this.y;
    const G = 7;
    const drop = 2.6;
    const H = 1.8;
    for (let k = 1; k <= G; k++) {
      this.fwd();
      const t = k / (G + 1);
      this.y = y0 - drop * t;
      this.put(K_STRAIGHT, this.w, 1.02, 1.02, 1.02, true, y0 - drop * t + 4 * H * t * (1 - t));
      if (k % 2 === 0) this.samples[this.samples.length - 1].gem = true;
    }
    this.y = y0 - drop;
    this.straight(10, { gems: false });
  }

  /** pilih arah belok, condong melawan arah bersih supaya track tetap "mengalir" */
  private pick() {
    const lim = 1.75;
    if (this.net > lim) return this.r() < 0.88 ? -1 : 1;
    if (this.net < -lim) return this.r() < 0.88 ? 1 : -1;
    return this.r() < 0.5 ? 1 : -1;
  }

  private choose(d: number, c: number) {
    const table: [string, number][] = [
      ['turn', 3],
      ['hairpin', 2.2],
      ['ess', 2.2],
      ['touge', 1.6 + d],
      ['sweep', 1.2],
      ['zig', 1.2 + d],
      ['helix', this.sinceHelix >= 3 ? 1.6 : 0],
      ['jump', this.sinceJump >= 3 ? 1.1 : 0],
      ['narrow', c > 12 && this.last !== 'jump' ? 0.8 : 0],
    ];
    let total = 0;
    for (const [n, w] of table) if (n !== this.last || n === 'turn') total += w;
    let roll = this.r() * total;
    for (const [n, w] of table) {
      if (n === this.last && n !== 'turn') continue;
      roll -= w;
      if (roll <= 0) return n;
    }
    return 'turn';
  }

  private next() {
    const r = this.r;
    const c = this.corners;
    const d = Math.min(1, c / 45);
    this.w = c > 45 ? HW - 0.45 : c > 22 ? HW - 0.2 : HW;
    const run = () => Math.round(12 - 4 * d + r() * 5);
    const f = this.feat++;

    let name: string;
    if (f < 3) name = 'easy';
    else if (f === 3) name = 'hairpin';
    else if (f === 4) name = 'helix';
    else if (f === 5) name = 'ess';
    else if (f === 6) name = 'jump';
    else name = this.choose(d, c);

    this.sinceHelix++;
    this.sinceJump++;

    switch (name) {
      case 'easy': {
        this.arc(8.5, Math.PI / 2, this.pick(), { gems: f > 0 });
        this.straight(15);
        break;
      }
      case 'turn': {
        const angles = [1.25, 1.57, 1.57, 1.95];
        this.arc(7 + r() * 3, angles[Math.floor(r() * angles.length)], this.pick());
        this.straight(run());
        break;
      }
      case 'hairpin': {
        this.arc(6.6 + r() * 1.4, Math.PI, this.pick());
        this.straight(run());
        break;
      }
      case 'ess': {
        const t = this.pick();
        const a = 0.95 + r() * 0.5;
        const R = 7.5 + r() * 1.5;
        this.arc(R, a, t);
        this.straight(4 + Math.round(r() * 2), { gems: false });
        this.arc(R, a, -t);
        this.straight(run());
        break;
      }
      case 'touge': {
        // switchback khas jalan gunung: hairpin kiri-kanan-kiri
        let t = this.pick();
        const n = 2 + (r() < 0.35 + d * 0.4 ? 1 : 0);
        for (let k = 0; k < n; k++) {
          this.arc(6.8, Math.PI, t, { gems: k === 0 });
          this.straight(k < n - 1 ? 8 + Math.round(r() * 3) : run());
          t = -t;
        }
        break;
      }
      case 'sweep': {
        this.arc(12 + r() * 2.5, 2.1 + r() * 0.7, this.pick());
        this.straight(run());
        break;
      }
      case 'zig': {
        let t = this.pick();
        for (let k = 0; k < 4; k++) {
          this.arc(7, 0.8, t, { gems: false });
          this.straight(k < 3 ? 4 + Math.round(r()) : run(), { gems: k === 3 });
          t = -t;
        }
        break;
      }
      case 'helix': {
        // SWIRL: spiral turun mengelilingi tiang raksasa
        const opts = [Math.PI * 2, Math.PI * 2.5, Math.PI * 3];
        const ang = this.helixCount === 0 ? opts[0] : opts[Math.floor(r() * opts.length)];
        this.arc(9, ang, this.pick(), { helix: true });
        this.straight(run() + 2);
        this.sinceHelix = 0;
        this.helixCount++;
        break;
      }
      case 'jump': {
        this.jump();
        this.straight(Math.max(3, run() - 6));
        this.sinceJump = 0;
        break;
      }
      case 'narrow': {
        this.straight(3, { gems: false });
        this.straight(9, { hw: 2.2, kind: K_NARROW });
        this.straight(5, { gems: false });
        break;
      }
    }
    this.last = name;
  }
}
