/**
 * Mobil voxel mini (chibi sporty). Dibangun dari voxel bertingkat untuk
 * siluet yang ekspresif: wide-body fender, bemper menonjol, kaca berbingkai,
 * wajah imut, knalpot ganda + api boost, serta roda berputar & berbelok.
 * Mobil menghadap +Z, kiri = +X.
 */
import * as THREE from 'three';

export type CarExtra = 'none' | 'tofu' | 'taxi' | 'neko' | 'frog' | 'police' | 'crown';

export interface CarDef {
  id: string;
  name: string;
  tag: string;
  price: number;
  body: number;
  lower: number;
  roof: number;
  rim: number;
  extra: CarExtra;
  spoiler?: boolean;
  stripe?: number;
  hood?: number;
}

/** skala visual mobil di dunia */
export const CAR_SCALE = 1.36;

export const CARS: CarDef[] = [
  { id: 'mochi', name: 'MOCHI', tag: 'si merah turbo', price: 0, body: 0xff4d5a, lower: 0xc92a3e, roof: 0xff4d5a, rim: 0xf4f7fb, extra: 'none', spoiler: true, stripe: 0xffffff },
  { id: 'tofu', name: 'TOFU-86', tag: 'kurir tahu gunung', price: 25, body: 0xf9fafc, lower: 0x26283b, roof: 0xf9fafc, rim: 0xffd23f, extra: 'tofu', hood: 0x26283b, spoiler: true },
  { id: 'taksi', name: 'TAKSI', tag: 'argo ngebut', price: 60, body: 0xffc93c, lower: 0xd9960c, roof: 0xffc93c, rim: 0xf4f7fb, extra: 'taxi' },
  { id: 'neko', name: 'NEKO', tag: 'meong ngeeeng', price: 110, body: 0xff9ebb, lower: 0xe66791, roof: 0xffc4d6, rim: 0xffffff, extra: 'neko', stripe: 0xffffff },
  { id: 'kodok', name: 'KODOK', tag: 'hobi lompat', price: 170, body: 0x5cd669, lower: 0x3ba648, roof: 0x89ed93, rim: 0xffe066, extra: 'frog' },
  { id: 'polisi', name: 'POLISI', tag: 'wiu wiu wiu', price: 240, body: 0xf9fafc, lower: 0x2d74f5, roof: 0x2d74f5, rim: 0xf4f7fb, extra: 'police', spoiler: true },
  { id: 'sultan', name: 'SULTAN', tag: 'emas 24 karat', price: 400, body: 0xffcf33, lower: 0xd99200, roof: 0xffe680, rim: 0xffffff, extra: 'crown', spoiler: true, stripe: 0xfff8d6 },
];

export function carById(id: string): CarDef {
  return CARS.find((c) => c.id === id) ?? CARS[0];
}

export interface CarRig {
  group: THREE.Group;
  tilt: THREE.Group;
  frontPivots: THREE.Group[];
  wheels: THREE.Mesh[];
  flames: THREE.Mesh[];
  sirens: THREE.Mesh[];
  colors: number[];
  dispose(): void;
}

/** [sx, sy, sz, x, y, z, color] */
type Part = [number, number, number, number, number, number, number];

const FACES: { n: [number, number, number]; v: [number, number, number][] }[] = [
  { n: [1, 0, 0], v: [[1, -1, 1], [1, -1, -1], [1, 1, -1], [1, 1, 1]] },
  { n: [-1, 0, 0], v: [[-1, -1, -1], [-1, -1, 1], [-1, 1, 1], [-1, 1, -1]] },
  { n: [0, 1, 0], v: [[-1, 1, 1], [1, 1, 1], [1, 1, -1], [-1, 1, -1]] },
  { n: [0, -1, 0], v: [[-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]] },
  { n: [0, 0, 1], v: [[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]] },
  { n: [0, 0, -1], v: [[1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]] },
];

function voxelGeometry(parts: Part[]): THREE.BufferGeometry {
  const pos: number[] = [];
  const nor: number[] = [];
  const col: number[] = [];
  const idx: number[] = [];
  const c = new THREE.Color();
  for (const [sx, sy, sz, x, y, z, hex] of parts) {
    c.setHex(hex);
    const hx = sx / 2;
    const hy = sy / 2;
    const hz = sz / 2;
    for (const f of FACES) {
      const base = pos.length / 3;
      for (const v of f.v) {
        pos.push(x + v[0] * hx, y + v[1] * hy, z + v[2] * hz);
        nor.push(f.n[0], f.n[1], f.n[2]);
        col.push(c.r, c.g, c.b);
      }
      idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  return g;
}

const WHITE = 0xffffff;
const INK = 0x222336;
const GLASS = 0x2a3b61;
const GLASS_HI = 0x8bc2ff;
const TAIL = 0xff2a3c;
const TAIL_GLOW = 0xff7b88;
const BLUSH = 0xff8fab;
const TIRE = 0x252636;
const CHROME = 0xb9c4d6;
const AMBER = 0xffaa2b;

function bodyParts(d: CarDef): Part[] {
  const B = d.body;
  const L = d.lower;
  const p: Part[] = [];
  const sym = (sx: number, sy: number, sz: number, x: number, y: number, z: number, c: number) => {
    p.push([sx, sy, sz, x, y, z, c], [sx, sy, sz, -x, y, z, c]);
  };

  // chassis & wide-body side skirts
  p.push([1.48, 0.44, 2.26, 0, 0.56, 0, B]);
  p.push([1.58, 0.16, 2.34, 0, 0.34, 0, L]);
  // overhang bumper depan (splitter sporty) & bumper belakang
  p.push([1.62, 0.16, 0.24, 0, 0.34, 1.18, L]);
  p.push([1.52, 0.18, 0.18, 0, 0.46, 1.16, B]);
  p.push([1.62, 0.16, 0.22, 0, 0.34, -1.16, L]);
  p.push([1.52, 0.18, 0.16, 0, 0.47, -1.14, B]);
  // diffuser belakang
  p.push([0.92, 0.14, 0.12, 0, 0.28, -1.24, INK]);

  // wheel arch / over-fender gemoy di atas 4 roda
  for (const sz of [0.72, -0.72]) {
    sym(0.24, 0.28, 0.72, 0.74, 0.58, sz, L);
    sym(0.2, 0.16, 0.56, 0.74, 0.74, sz, B);
  }

  // kap mesin bertingkat (sedikit melandai ke depan)
  p.push([1.36, 0.14, 0.78, 0, 0.81, 0.68, d.hood ?? B]);
  // air scoop imut di kap untuk mobil sporty
  if (d.spoiler || d.extra === 'tofu') {
    p.push([0.48, 0.08, 0.28, 0, 0.91, 0.64, L]);
    p.push([0.38, 0.05, 0.06, 0, 0.91, 0.78, INK]);
  }

  // kabin (kaca depan agak miring + bingkai pilar warna bodi)
  p.push([1.28, 0.44, 1.24, 0, 1.0, -0.2, B]);
  p.push([1.32, 0.1, 1.28, 0, 1.26, -0.2, d.roof]);
  // mahkota atap halus bertingkat
  p.push([1.14, 0.07, 1.08, 0, 1.34, -0.2, d.roof]);

  // kaca depan, belakang, samping + kilau kaca
  p.push([1.06, 0.3, 0.08, 0, 1.01, 0.42, GLASS]);
  p.push([0.26, 0.1, 0.04, 0.28, 1.09, 0.45, GLASS_HI]);
  p.push([0.1, 0.06, 0.04, 0.06, 1.07, 0.45, GLASS_HI]);
  p.push([0.96, 0.28, 0.08, 0, 1.01, -0.82, GLASS]);
  sym(0.08, 0.28, 0.88, 0.63, 1.01, -0.2, GLASS);
  // bingkai kaca tengah (B-pillar)
  sym(0.1, 0.3, 0.12, 0.63, 1.01, -0.2, B);

  // spion imut bertangkai
  sym(0.18, 0.13, 0.16, 0.84, 0.86, 0.32, d.roof);

  // ── WAJAH DEPAN EKPRESIF ──
  const eyeBg = B === 0xf9fafc || B === WHITE ? 0xffe49e : WHITE;
  // mata besar berkilau (lampu utama)
  sym(0.38, 0.3, 0.08, 0.43, 0.58, 1.13, eyeBg);
  sym(0.18, 0.2, 0.08, 0.4, 0.57, 1.17, INK);
  sym(0.07, 0.07, 0.05, 0.44, 0.62, 1.2, WHITE);
  sym(0.04, 0.04, 0.04, 0.36, 0.53, 1.2, WHITE);
  // kelopak/alis imut
  sym(0.4, 0.06, 0.09, 0.43, 0.74, 1.14, L);
  // pipi merona & sein
  sym(0.14, 0.08, 0.06, 0.68, 0.47, 1.15, BLUSH);
  sym(0.12, 0.08, 0.08, 0.68, 0.57, 1.13, AMBER);

  // grill / senyum manis
  if (d.extra === 'frog') {
    p.push([0.84, 0.07, 0.06, 0, 0.46, 1.21, INK]);
    p.push([0.24, 0.08, 0.05, 0.15, 0.41, 1.22, BLUSH]);
  } else if (d.extra === 'neko') {
    p.push([0.14, 0.09, 0.06, 0, 0.53, 1.2, BLUSH]);
    sym(0.12, 0.05, 0.05, 0.09, 0.46, 1.2, INK);
  } else {
    p.push([0.36, 0.11, 0.07, 0, 0.47, 1.18, INK]);
    p.push([0.28, 0.04, 0.05, 0, 0.48, 1.21, CHROME]);
  }

  // ── BAGIAN BELAKANG (yang paling sering dilihat pemain saat main!) ──
  // lampu rem lebar bertingkat
  sym(0.36, 0.16, 0.08, 0.5, 0.59, -1.14, TAIL);
  sym(0.16, 0.08, 0.05, 0.52, 0.6, -1.17, TAIL_GLOW);
  sym(0.1, 0.08, 0.05, 0.28, 0.59, -1.17, AMBER);
  // plat nomor + garnish belakang
  p.push([0.46, 0.18, 0.06, 0, 0.48, -1.19, WHITE]);
  p.push([0.32, 0.04, 0.04, 0, 0.48, -1.21, INK]);
  // knalpot kembar chrome
  sym(0.16, 0.14, 0.2, 0.44, 0.28, -1.25, CHROME);
  sym(0.1, 0.09, 0.06, 0.44, 0.28, -1.34, INK);

  // racing stripe dari hidung ke atap sampai bagasi belakang
  if (d.stripe !== undefined) {
    p.push([0.34, 0.04, 0.78, 0, 0.89, 0.68, d.stripe]);
    p.push([0.34, 0.04, 1.1, 0, 1.38, -0.2, d.stripe]);
    p.push([0.34, 0.04, 0.34, 0, 0.79, -0.98, d.stripe]);
  }

  // wing spoiler GT belakang
  if (d.spoiler) {
    p.push([1.48, 0.08, 0.32, 0, 1.0, -1.04, L]);
    sym(0.12, 0.16, 0.36, 0.72, 1.02, -1.04, B); // endplate wing keren!
    sym(0.1, 0.22, 0.14, 0.44, 0.86, -1.04, INK);
  }

  // aksesori khas per mobil
  switch (d.extra) {
    case 'tofu': {
      // strip samping panda + peti tahu bertumpuk di atap
      sym(0.05, 0.14, 1.7, 0.75, 0.56, 0, INK);
      p.push([0.66, 0.26, 0.56, 0, 1.5, -0.22, 0xfff3d6]);
      p.push([0.68, 0.06, 0.58, 0, 1.5, -0.22, 0xd4a359]);
      p.push([0.46, 0.18, 0.42, 0, 1.7, -0.22, 0xffffff]);
      break;
    }
    case 'taxi': {
      p.push([0.64, 0.22, 0.28, 0, 1.48, -0.1, WHITE]);
      p.push([0.66, 0.08, 0.3, 0, 1.48, -0.1, AMBER]);
      for (let k = -4; k < 4; k++) {
        sym(0.04, 0.12, 0.26, 0.75, 0.56, k * 0.25 + 0.12, k & 1 ? INK : WHITE);
      }
      break;
    }
    case 'neko': {
      // kuping kucing imut + ekor meong meliuk di belakang!
      sym(0.32, 0.34, 0.16, 0.44, 1.52, 0.18, B);
      sym(0.16, 0.18, 0.06, 0.44, 1.5, 0.26, BLUSH);
      p.push([0.14, 0.14, 0.38, 0, 0.84, -1.32, B]);
      p.push([0.16, 0.16, 0.28, 0.06, 0.98, -1.5, B]);
      p.push([0.2, 0.2, 0.2, 0.1, 1.12, -1.58, WHITE]);
      break;
    }
    case 'frog': {
      // mata kodok gede di atap + mahkota kecil
      sym(0.46, 0.42, 0.44, 0.42, 1.56, 0.18, B);
      sym(0.32, 0.3, 0.06, 0.42, 1.58, 0.41, WHITE);
      sym(0.14, 0.18, 0.06, 0.42, 1.58, 0.44, INK);
      break;
    }
    case 'police': {
      // pintu hitam-putih + lightbar sirene (merah/birunya animasi terpisah)
      sym(0.05, 0.4, 0.86, 0.75, 0.56, -0.05, INK);
      p.push([0.96, 0.09, 0.32, 0, 1.42, -0.12, INK]);
      break;
    }
    case 'crown': {
      p.push([0.74, 0.14, 0.74, 0, 1.45, -0.18, 0xffb703]);
      for (const sx of [-1, 1]) {
        for (const sz of [-1, 1]) {
          p.push([0.16, 0.24, 0.16, sx * 0.29, 1.64, -0.18 + sz * 0.29, 0xffb703]);
        }
      }
      p.push([0.22, 0.22, 0.22, 0, 1.62, -0.18, 0xff2a6d]);
      break;
    }
    default:
      break;
  }
  return p;
}

export function buildCar(def: CarDef): CarRig {
  const material = new THREE.MeshLambertMaterial({ vertexColors: true });
  const glowMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const group = new THREE.Group();
  group.scale.setScalar(CAR_SCALE);
  const tilt = new THREE.Group();
  group.add(tilt);

  const bodyGeo = voxelGeometry(bodyParts(def));
  const body = new THREE.Mesh(bodyGeo, material);
  body.castShadow = true;
  tilt.add(body);

  const geos: THREE.BufferGeometry[] = [bodyGeo];
  const frontPivots: THREE.Group[] = [];
  const wheels: THREE.Mesh[] = [];
  const flames: THREE.Mesh[] = [];
  const sirens: THREE.Mesh[] = [];

  // 4 roda chunky (bisa berputar + roda depan bisa counter-steer)
  for (const sx of [1, -1]) {
    for (const sz of [1, -1]) {
      const geo = voxelGeometry([
        [0.36, 0.62, 0.62, 0, 0, 0, TIRE],
        [0.08, 0.34, 0.34, sx * 0.18, 0, 0, def.rim],
        [0.06, 0.14, 0.14, sx * 0.21, 0, 0, INK],
      ]);
      geos.push(geo);
      const wheel = new THREE.Mesh(geo, material);
      wheel.castShadow = true;
      wheels.push(wheel);

      if (sz > 0) {
        const pivot = new THREE.Group();
        pivot.position.set(sx * 0.72, 0.31, sz * 0.72);
        pivot.add(wheel);
        tilt.add(pivot);
        frontPivots.push(pivot);
      } else {
        wheel.position.set(sx * 0.72, 0.31, sz * 0.72);
        tilt.add(wheel);
      }
    }
  }

  // api knalpot ganda (muncul saat turbo/boost/combo!)
  const flameGeo = voxelGeometry([
    [0.14, 0.14, 0.45, 0, 0, -0.22, 0x38e8ff],
    [0.09, 0.09, 0.62, 0, 0, -0.34, 0xffffff],
  ]);
  geos.push(flameGeo);
  for (const sx of [1, -1]) {
    const f = new THREE.Mesh(flameGeo, glowMat);
    f.position.set(sx * 0.44, 0.28, -1.35);
    f.visible = false;
    tilt.add(f);
    flames.push(f);
  }

  // sirene berkedip untuk polisi
  if (def.extra === 'police') {
    const rGeo = voxelGeometry([[0.38, 0.2, 0.28, 0, 0, 0, 0xff2a3c]]);
    const bGeo = voxelGeometry([[0.38, 0.2, 0.28, 0, 0, 0, 0x2d88ff]]);
    geos.push(rGeo, bGeo);
    const rMesh = new THREE.Mesh(rGeo, glowMat);
    const bMesh = new THREE.Mesh(bGeo, glowMat);
    rMesh.position.set(0.25, 1.56, -0.12);
    bMesh.position.set(-0.25, 1.56, -0.12);
    tilt.add(rMesh, bMesh);
    sirens.push(rMesh, bMesh);
  }

  return {
    group,
    tilt,
    frontPivots,
    wheels,
    flames,
    sirens,
    colors: [def.body, def.body, def.lower, def.roof, TIRE],
    dispose() {
      for (const g of geos) g.dispose();
      material.dispose();
      glowMat.dispose();
    },
  };
}
