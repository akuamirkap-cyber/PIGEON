/**
 * Palet warna simple, clean, hypercasual khas:
 * 1 warna jalan polos lembut + 1 warna kerb solid + 1 garis tengah lembut +
 * tiang pivot cerah + langit gradien pastel.
 */
export interface Theme {
  name: string;
  skyTop: number;
  skyBottom: number;
  fog: number;
  /** warna permukaan jalan utama (polos clean) */
  trackA: number;
  /** warna garis tengah jalan lembut */
  trackB: number;
  /** warna jalan di tikungan (sangat subtle biar tetap satu kesatuan mulus) */
  arcA: number;
  /** warna garis tengah di tikungan */
  arcB: number;
  /** kerb samping solid */
  curbA: number;
  /** warna pilar penyangga jalan di bawah */
  curbB: number;
  /** kepala kubus pivot */
  pivot: number;
  /** tali sling */
  rope: number;
  cloud: number;
}

export const THEMES: Theme[] = [
  {
    name: 'LAVENDER SKY',
    skyTop: 0x5cc6ff,
    skyBottom: 0xffe4ec,
    fog: 0xb7dcff,
    trackA: 0x9183d8, // ungu lavender polos khas
    trackB: 0xa99de6, // garis tengah lembut
    arcA: 0x897ad2,   // tikungan senada halus
    arcB: 0xa599e3,
    curbA: 0x9f2358,  // kerb berry-maroon tegas
    curbB: 0x7363ba,  // pilar penyangga ungu
    pivot: 0xffc93c,  // kubus pivot emas cerah!
    rope: 0xffd859,
    cloud: 0xffffff,
  },
  {
    name: 'MINT CORAL',
    skyTop: 0x3bd3c5,
    skyBottom: 0xfff3e2,
    fog: 0xa5ebe3,
    trackA: 0x45a39e,
    trackB: 0x67bdb8,
    arcA: 0x3e9893,
    arcB: 0x62b7b2,
    curbA: 0xff5a66,
    curbB: 0x327f7b,
    pivot: 0xffd23f,
    rope: 0xff6b75,
    cloud: 0xffffff,
  },
  {
    name: 'PEACH SUNSET',
    skyTop: 0xff836b,
    skyBottom: 0xfff0d4,
    fog: 0xffbfa8,
    trackA: 0x6c4b75,
    trackB: 0x896694,
    arcA: 0x64446e,
    arcB: 0x82608c,
    curbA: 0xff6f3c,
    curbB: 0x52375a,
    pivot: 0xffe066,
    rope: 0xff9f43,
    cloud: 0xfff2e6,
  },
  {
    name: 'CYBER INDIGO',
    skyTop: 0x161245,
    skyBottom: 0x573399,
    fog: 0x32216e,
    trackA: 0x38327a,
    trackB: 0x574fa8,
    arcA: 0x332d73,
    arcB: 0x5249a3,
    curbA: 0x00e5cc,
    curbB: 0x262059,
    pivot: 0xff4d9d,
    rope: 0x00f5d4,
    cloud: 0x5947ad,
  },
  {
    name: 'SAKURA CREAM',
    skyTop: 0xff92bc,
    skyBottom: 0xfff2f6,
    fog: 0xffc9de,
    trackA: 0xe67da3,
    trackB: 0xf7a1c0,
    arcA: 0xde729a,
    arcB: 0xf296b8,
    curbA: 0x7a2b5c,
    curbB: 0xc26185,
    pivot: 0xffe066,
    rope: 0xffd23f,
    cloud: 0xffffff,
  },
];
