/**
 * 4 preset kamera khas hypercasual (semua jauh & lega agar tikungan terlihat jelas).
 */
export type CamId = 'sling' | 'chase' | 'iso' | 'top';

export interface CamPreset {
  id: CamId;
  name: string;
  tag: string;
  dist: number;
  pitch: number;
  look: number;
  yawOff: number;
  kYaw: number;
  fovAdd: number;
  driftSwing: number;
}

export const CAMERAS: CamPreset[] = [
  {
    id: 'sling',
    name: 'SLING 3D',
    tag: 'tinggi & jauh ke depan',
    dist: 35,
    pitch: 1.04,
    look: 10.5,
    yawOff: 0.14,
    kYaw: 2.6,
    fovAdd: -2,
    driftSwing: 0,
  },
  {
    id: 'chase',
    name: 'KEJAR LUAS',
    tag: 'belakang luas',
    dist: 30,
    pitch: 0.64,
    look: 9.5,
    yawOff: 0,
    kYaw: 3.4,
    fovAdd: 2,
    driftSwing: 0.08,
  },
  {
    id: 'iso',
    name: 'ISOMETRIK',
    tag: 'sudut samping 3D',
    dist: 36,
    pitch: 0.82,
    look: 7.5,
    yawOff: 0.56,
    kYaw: 2.5,
    fovAdd: -4,
    driftSwing: 0,
  },
  {
    id: 'top',
    name: 'ATAS 2D+',
    tag: 'tegak ala 2D',
    dist: 38,
    pitch: 1.28,
    look: 7.5,
    yawOff: 0,
    kYaw: 2.4,
    fovAdd: -4,
    driftSwing: 0,
  },
];

export function camById(id: string): CamPreset {
  return CAMERAS.find((c) => c.id === id) ?? CAMERAS[0];
}
