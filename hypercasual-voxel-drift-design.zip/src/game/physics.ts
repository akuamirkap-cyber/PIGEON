/**
 * Fisika sling — murni logika, tanpa rendering (bisa diuji headless).
 *
 * TAHAN  → tali terkait ke pivot tikungan berikutnya. Selama mobil masih
 *          mendekat, tali "kendur" & memendek sendiri (ratchet). Begitu mobil
 *          mulai menjauh, tali menegang → mobil mengorbit pivot = DRIFT.
 * LEPAS  → mobil melaju lurus searah heading saat itu.
 *
 * Efeknya: menekan terlalu cepat tidak dihukum (masuk tikungan selalu mulus),
 * skill-nya ada di TIMING MELEPAS dan menjaga posisi tetap di tengah.
 */
import type { Arc, Track } from './track';
import { K_ARC, K_HELIX } from './track';

export interface CarState {
  x: number;
  z: number;
  y: number;
  /** heading arah gerak */
  th: number;
  speed: number;
  /** progres di track (index sample, pecahan) */
  idx: number;
  /** offset lateral dari tengah track (+ = kiri) */
  lat: number;
  /** seberapa jauh melewati tepi (negatif = masih di dalam) */
  over: number;
  hook: Arc | null;
  hookR: number;
  taut: boolean;
  alpha: number;
}

export const EV_HOOK = 1;
export const EV_TAUT = 2;
export const EV_RELEASE = 4;
export const EV_OFF = 8;

/** jangkauan lempar tali di luar tepi track */
export const HOOK_EXTRA = 7.5;
/** toleransi: pusat mobil boleh sedikit melewati tepi sebelum jatuh */
export const EDGE_TOL = 0.32;

const TAU = Math.PI * 2;

export function angDiff(a: number, b: number) {
  let d = (a - b) % TAU;
  if (d > Math.PI) d -= TAU;
  else if (d < -Math.PI) d += TAU;
  return d;
}

export function makeCar(): CarState {
  return {
    x: 0,
    z: 0,
    y: 0,
    th: 0,
    speed: 0,
    idx: 0,
    lat: 0,
    over: -1,
    hook: null,
    hookR: 0,
    taut: false,
    alpha: 0,
  };
}

/**
 * Majukan mobil satu langkah. Mengembalikan bit-flag event (EV_*).
 * @param target  tikungan berikutnya yang belum dilewati
 * @param assist  kecepatan auto-lurus halus di jalan lurus (rad/detik)
 */
export function stepCar(
  c: CarState,
  tr: Track,
  target: Arc | undefined,
  pressed: boolean,
  canHook: boolean,
  assist: number,
  dt: number,
): number {
  let ev = 0;

  if (pressed) {
    if (!c.hook && canHook && target) {
      const dx = c.x - target.cx;
      const dz = c.z - target.cz;
      const d = Math.hypot(dx, dz);
      if (d < target.R + target.hw + HOOK_EXTRA) {
        c.hook = target;
        c.hookR = d;
        c.taut = false;
        ev |= EV_HOOK;
      }
    }
  } else if (c.hook) {
    c.hook = null;
    c.taut = false;
    ev |= EV_RELEASE;
  }

  const a = c.hook;
  if (a && c.taut) {
    // mengorbit pivot dengan radius tetap
    c.alpha += ((a.turn * c.speed) / c.hookR) * dt;
    c.x = a.cx - a.turn * c.hookR * Math.cos(c.alpha);
    c.z = a.cz + a.turn * c.hookR * Math.sin(c.alpha);
    c.th = c.alpha;
  } else {
    // sedikit bantuan meluruskan mobil di jalan lurus (kalau error-nya kecil)
    const s0 = tr.samples[Math.round(c.idx)];
    if (assist > 0 && s0 && s0.kind !== K_ARC && s0.kind !== K_HELIX) {
      const e = angDiff(s0.th, c.th);
      if (Math.abs(e) < 0.4) c.th += Math.max(-assist * dt, Math.min(assist * dt, e));
    }
    c.x += Math.sin(c.th) * c.speed * dt;
    c.z += Math.cos(c.th) * c.speed * dt;

    if (a) {
      const dx = c.x - a.cx;
      const dz = c.z - a.cz;
      const d = Math.hypot(dx, dz);
      // proyeksi gerak mobil terhadap vektor ke pivot: <= 0 berarti sudah tegak lurus / mulai menjauh
      const radialVel = dx * Math.sin(c.th) + dz * Math.cos(c.th);
      const almostTaut = c.idx >= a.startI - 0.45 && radialVel > -0.25 * d * 0.15;
      if (d <= c.hookR && !almostTaut) {
        c.hookR = d; // tali kendur: memendek mengikuti mobil
      } else {
        // tali menegang → langsung mulai drift tanpa telat
        c.taut = true;
        c.hookR = Math.max(1.2, d);
        const raw = Math.atan2(a.turn * dz, -a.turn * dx);
        c.alpha = c.th + angDiff(raw, c.th);
        c.x = a.cx - a.turn * c.hookR * Math.cos(c.alpha);
        c.z = a.cz + a.turn * c.hookR * Math.sin(c.alpha);
        c.th = c.alpha;
        ev |= EV_TAUT;
      }
    }
  }

  const loc = tr.locate(c.x, c.z, c.idx);
  c.idx = loc.f;
  c.lat = loc.lat;
  c.over = Math.abs(loc.lat) - tr.samples[loc.i].hw;
  if (c.over > EDGE_TOL) ev |= EV_OFF;
  c.y = tr.heightAt(c.idx);
  return ev;
}
