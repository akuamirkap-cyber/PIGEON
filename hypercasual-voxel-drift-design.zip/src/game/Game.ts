/**
 * TOUGE SLING — engine game.
 *
 * Track digambar memakai TrackMesh (prisma kontinu yang menyambung mulus tanpa
 * undakan tangga, namun tiap segmen tetap bisa patah, melenting pop-in,
 * bergelombang saat ripple/dilindas, dan runtuh collapse di belakang mobil).
 * Kerb, pivot, awan, partikel, koin, dan tali digambar lewat 2 InstancedMesh.
 */
import * as THREE from 'three';
import { Track, START_I, GATE_I, K_ARC, K_HELIX, K_RAMP, type Arc, type Sample } from './track';
import { stepCar, makeCar, angDiff, EV_HOOK, EV_TAUT, EV_RELEASE, EV_OFF, type CarState } from './physics';
import { THEMES, type Theme } from './themes';
import { buildCar, carById, CAR_SCALE, type CarRig } from './cars';
import { camById, type CamId } from './cameras';
import { Sfx } from './audio';

export type GameState = 'menu' | 'playing' | 'falling' | 'over';
export type Hint = 'hold' | 'keep' | 'release' | null;
export type PopTone = 'perfect' | 'good' | 'near' | 'swirl' | 'air';

export type GameEvent =
  | { type: 'state'; state: GameState }
  | { type: 'score'; score: number; combo: number }
  | { type: 'gems'; run: number }
  | { type: 'pop'; text: string; sub?: string; tone: PopTone; gain: number }
  | { type: 'hint'; hint: Hint }
  | { type: 'stage'; index: number; name: string }
  | { type: 'locked' }
  | { type: 'over'; score: number; gems: number; perfects: number; bestCombo: number; corners: number };

export interface GameOptions {
  car: string;
  cam: CamId;
  muted: boolean;
  tutorial: boolean;
}

// ───────────────────────────── konstanta ─────────────────────────────

const AHEAD = 84; // papan muncul sejauh ini di depan mobil
const BEHIND = 12; // papan runtuh setelah tertinggal sejauh ini
const TH = 0.9; // tebal dek track
const CURB_W = 0.48; // lebar kerb samping
const CURB_H = TH + 0.16; // tinggi kerb
const ASSIST = 0.65;
const PERFECT_ANG = 0.16;
const TAU = Math.PI * 2;
const SRGB = THREE.SRGBColorSpace;

const PKEYS = [
  'skyTop',
  'skyBottom',
  'fog',
  'trackA',
  'trackB',
  'arcA',
  'arcB',
  'curbA',
  'curbB',
  'pivot',
  'rope',
  'cloud',
] as const;
type PKey = (typeof PKEYS)[number];
type Palette = Record<PKey, THREE.Color>;

function makePalette(t: Theme): Palette {
  const p = {} as Palette;
  for (const k of PKEYS) p[k] = new THREE.Color(t[k]);
  return p;
}

const C_WHITE = new THREE.Color(0xffffff);
const C_INK = new THREE.Color(0x26263a);
const C_GEM = new THREE.Color(0xffc21a);
const C_SKID = new THREE.Color(0x474c6b);
const C_SPARK = new THREE.Color(0xffb703);
const CONFETTI = [0xff5a5f, 0xffd23f, 0x3ddc97, 0x3a86ff, 0xff8fab, 0xffffff, 0xb388ff].map(
  (h) => new THREE.Color(h),
);
const Z_AXIS = new THREE.Vector3(0, 0, 1);

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const rnd = (a = 1, b = 0) => b + Math.random() * (a - b);
const hash = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};
const backOut = (t: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
};

// ───────────────────────────── mesh track mulus + pecah per-segmen ─────────────────────────────

class TrackMesh {
  mesh: THREE.Mesh;
  private geo: THREE.BufferGeometry;
  private pos: Float32Array;
  private nor: Float32Array;
  private col: Float32Array;
  private capQuads: number;
  private qCount = 0;

  constructor(maxPrisms: number, material: THREE.Material) {
    // 6 quad per prisma * maxPrisms
    this.capQuads = maxPrisms * 6;
    const vCount = this.capQuads * 4;
    this.pos = new Float32Array(vCount * 3);
    this.nor = new Float32Array(vCount * 3);
    this.col = new Float32Array(vCount * 3);

    const idx = new Uint32Array(this.capQuads * 6);
    for (let i = 0; i < this.capQuads; i++) {
      const vb = i * 4;
      const ib = i * 6;
      idx[ib] = vb;
      idx[ib + 1] = vb + 1;
      idx[ib + 2] = vb + 2;
      idx[ib + 3] = vb;
      idx[ib + 4] = vb + 2;
      idx[ib + 5] = vb + 3;
    }

    const geo = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(this.pos, 3);
    const norAttr = new THREE.BufferAttribute(this.nor, 3);
    const colAttr = new THREE.BufferAttribute(this.col, 3);
    posAttr.setUsage(THREE.DynamicDrawUsage);
    norAttr.setUsage(THREE.DynamicDrawUsage);
    colAttr.setUsage(THREE.DynamicDrawUsage);

    geo.setAttribute('position', posAttr);
    geo.setAttribute('normal', norAttr);
    geo.setAttribute('color', colAttr);
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.setDrawRange(0, 0);
    this.geo = geo;

    const mesh = new THREE.Mesh(geo, material);
    mesh.frustumCulled = false;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.mesh = mesh;
  }

  begin() {
    this.qCount = 0;
  }

  private pushQuad(
    ax: number, ay: number, az: number,
    bx: number, by: number, bz: number,
    cx: number, cy: number, cz: number,
    dx: number, dy: number, dz: number,
    r: number, g: number, b: number,
  ) {
    if (this.qCount >= this.capQuads) return;
    const vb = this.qCount * 4;
    const o = vb * 3;
    const P = this.pos;
    P[o] = ax; P[o + 1] = ay; P[o + 2] = az;
    P[o + 3] = bx; P[o + 4] = by; P[o + 5] = bz;
    P[o + 6] = cx; P[o + 7] = cy; P[o + 8] = cz;
    P[o + 9] = dx; P[o + 10] = dy; P[o + 11] = dz;

    // normal = normalize((B - A) x (D - A))
    const ux = bx - ax, uy = by - ay, uz = bz - az;
    const vx = dx - ax, vy = dy - ay, vz = dz - az;
    let nx = uy * vz - uz * vy;
    let ny = uz * vx - ux * vz;
    let nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz) || 1;
    nx /= len; ny /= len; nz /= len;

    const N = this.nor;
    const C = this.col;
    for (let k = 0; k < 12; k += 3) {
      N[o + k] = nx; N[o + k + 1] = ny; N[o + k + 2] = nz;
      C[o + k] = r; C[o + k + 1] = g; C[o + k + 2] = b;
    }
    this.qCount++;
  }

  /**
   * Gambar satu segmen prisma (8 sudut: 4 di penampang belakang 0, 4 di penampang depan 1).
   * Saat `capEnds` false (menyambung mulus dengan tetangga), tutup depan/belakang
   * tidak perlu digambar sehingga lebih hemat & tanpa z-fighting.
   */
  addPrism(
    tl0x: number, tl0y: number, tl0z: number,
    tr0x: number, tr0y: number, tr0z: number,
    bl0x: number, bl0y: number, bl0z: number,
    br0x: number, br0y: number, br0z: number,
    tl1x: number, tl1y: number, tl1z: number,
    tr1x: number, tr1y: number, tr1z: number,
    bl1x: number, bl1y: number, bl1z: number,
    br1x: number, br1y: number, br1z: number,
    cTop: THREE.Color,
    cSide: THREE.Color,
    capStart: boolean,
    capEnd: boolean,
  ) {
    // Atas (+Y)
    this.pushQuad(tl0x, tl0y, tl0z, tr0x, tr0y, tr0z, tr1x, tr1y, tr1z, tl1x, tl1y, tl1z, cTop.r, cTop.g, cTop.b);
    // Bawah (-Y)
    this.pushQuad(bl0x, bl0y, bl0z, bl1x, bl1y, bl1z, br1x, br1y, br1z, br0x, br0y, br0z, cSide.r, cSide.g, cSide.b);
    // Sisi +L
    this.pushQuad(tl1x, tl1y, tl1z, bl1x, bl1y, bl1z, bl0x, bl0y, bl0z, tl0x, tl0y, tl0z, cSide.r, cSide.g, cSide.b);
    // Sisi -L
    this.pushQuad(tr0x, tr0y, tr0z, br0x, br0y, br0z, br1x, br1y, br1z, tr1x, tr1y, tr1z, cSide.r, cSide.g, cSide.b);
    // Tutup belakang
    if (capStart) {
      this.pushQuad(tl0x, tl0y, tl0z, bl0x, bl0y, bl0z, br0x, br0y, br0z, tr0x, tr0y, tr0z, cSide.r, cSide.g, cSide.b);
    }
    // Tutup depan
    if (capEnd) {
      this.pushQuad(tr1x, tr1y, tr1z, br1x, br1y, br1z, bl1x, bl1y, bl1z, tl1x, tl1y, tl1z, cSide.r, cSide.g, cSide.b);
    }
  }

  end() {
    this.geo.setDrawRange(0, this.qCount * 6);
    (this.geo.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.getAttribute('normal') as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.getAttribute('color') as THREE.BufferAttribute).needsUpdate = true;
  }

  dispose() {
    this.geo.dispose();
  }
}

// ───────────────────────────── batch kotak ─────────────────────────────

class BoxBatch {
  mesh: THREE.InstancedMesh;
  private n = 0;
  private cap: number;
  private mat: Float32Array;
  private col: Float32Array;
  private m = new THREE.Matrix4();
  private p = new THREE.Vector3();
  private s = new THREE.Vector3();
  private qy = new THREE.Quaternion();

  constructor(cap: number, material: THREE.Material, shadows: boolean) {
    this.cap = cap;
    const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), material, cap);
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    const color = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3);
    color.setUsage(THREE.DynamicDrawUsage);
    mesh.instanceColor = color;
    mesh.frustumCulled = false;
    mesh.castShadow = shadows;
    mesh.receiveShadow = shadows;
    mesh.count = 0;
    this.mesh = mesh;
    this.mat = mesh.instanceMatrix.array as Float32Array;
    this.col = color.array as Float32Array;
  }

  begin() {
    this.n = 0;
  }

  add(
    x: number,
    y: number,
    z: number,
    sx: number,
    sy: number,
    sz: number,
    q: THREE.Quaternion,
    r: number,
    g: number,
    b: number,
  ) {
    const n = this.n;
    if (n >= this.cap) return;
    this.m.compose(this.p.set(x, y, z), q, this.s.set(sx, sy, sz));
    this.m.toArray(this.mat, n * 16);
    const o = n * 3;
    this.col[o] = r;
    this.col[o + 1] = g;
    this.col[o + 2] = b;
    this.n = n + 1;
  }

  yaw(x: number, y: number, z: number, sx: number, sy: number, sz: number, yaw: number, c: THREE.Color) {
    this.qy.set(0, Math.sin(yaw / 2), 0, Math.cos(yaw / 2));
    this.add(x, y, z, sx, sy, sz, this.qy, c.r, c.g, c.b);
  }

  end() {
    this.mesh.count = this.n;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  dispose() {
    this.mesh.geometry.dispose();
    this.mesh.dispose();
  }
}

// ───────────────────────────── partikel & awan ─────────────────────────────

/** mode: 0 puff (membesar→mengecil) · 1 mengecil · 2 jejak ban · 3 garis kecepatan */
interface Particle {
  on: boolean;
  glow: boolean;
  mode: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  g: number;
  drag: number;
  age: number;
  life: number;
  sx: number;
  sy: number;
  sz: number;
  yaw: number;
  rot: number;
  spin: number;
  r: number;
  gr: number;
  b: number;
}

interface Cloud {
  x: number;
  y: number;
  z: number;
  i: number;
  yaw: number;
  born: number;
  vx: number;
  parts: number[];
}

const MAX_PARTS = 640;

// ───────────────────────────── game ─────────────────────────────

export class Game {
  tutorial: boolean;

  private el: HTMLElement;
  private emitFn: (e: GameEvent) => void;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(52, 1, 0.5, 520);
  private sun: THREE.DirectionalLight;
  private fog: THREE.Fog;
  private roadMesh: TrackMesh;
  private roadMat: THREE.MeshLambertMaterial;
  private lit: BoxBatch;
  private glow: BoxBatch;
  private litMat: THREE.MeshLambertMaterial;
  private glowMat: THREE.MeshBasicMaterial;
  private skyMesh: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;
  private ro: ResizeObserver;
  private raf = 0;
  private last = 0;
  private aspect = 1;
  private reduced = false;
  private sfx = new Sfx();

  // palet (di-lerp antar stage)
  private pal: Palette = makePalette(THEMES[0]);
  private palFrom: Palette = makePalette(THEMES[0]);
  private palTo: Palette = makePalette(THEMES[0]);
  private palT = 1;
  private palDur = 1;
  private edgeCol = new THREE.Color();
  private sideCol = new THREE.Color();
  private kerbSideCol = new THREE.Color();

  // dunia
  private track!: Track;
  private car: CarState = makeCar();
  private rig: CarRig;
  private carId: string;
  private camId: CamId;
  private canStart = true;
  private parts: Particle[] = [];
  private pi = 0;
  private clouds: Cloud[] = [];

  // state
  private state: GameState = 'menu';
  private stateT = 0;
  private time = 0;
  private timeScale = 1;
  private timeScaleTarget = 1;
  private pressed = false;
  private score = 0;
  private combo = 0;
  private bestCombo = 0;
  private perfects = 0;
  private cleared = 0;
  private runGems = 0;
  private stage = 0;
  private arcPtr = 0;
  private arcLo = 0;
  private pendingEval: Arc | null = null;
  private inGap = false;
  private boost = 0;
  private assistT = 0;
  private nearT = 0;
  private hint: Hint = null;
  private gemStreak = 0;
  private gemT = -10;

  // tiles
  private tileLo = 0;
  private tileHi = -1;
  private fallPtr = 0;
  private intro = true;
  private rippleT = -1;
  private rippleI = 0;

  // visual mobil
  private visTh = 0;
  private drift = 0;
  private driftV = 0;
  private sq = 0;
  private sqV = 0;
  private pitch = 0;
  private wheelRot = 0;
  private fallVy = 0;
  private tumbleAxis = new THREE.Vector3(1, 0, 0);
  private tumbleSpeed = 0;
  private smokeAcc = 0;
  private skidAcc = 0;
  private trailAcc = 0;
  private puffAcc = 0;
  private sparkAcc = 0;
  private driftSparkAcc = 0;
  private speedLineAcc = 0;

  // tali
  private ropeT = 0;
  private ropeBack = 0;
  private ropeArc: Arc | null = null;

  // kamera
  private camYaw = Math.PI;
  private camPitch = 0.28;
  private camDist = 9.4;
  private camLook = 0;
  private camT = new THREE.Vector3();
  private menuAng = 0;
  private shake = 0;
  private fovKick = 0;
  private helixMix = 0;
  private helixArc: Arc | null = null;

  // temp
  private q = new THREE.Quaternion();
  private q2 = new THREE.Quaternion();
  private e = new THREE.Euler();
  private col = new THREE.Color();
  private v1 = new THREE.Vector3();

  constructor(el: HTMLElement, emit: (e: GameEvent) => void, opts: GameOptions) {
    this.el = el;
    this.emitFn = emit;
    this.tutorial = opts.tutorial;
    this.carId = opts.car;
    this.camId = opts.cam;
    this.sfx.setMuted(opts.muted);
    this.reduced =
      typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.domElement.style.display = 'block';
    el.appendChild(renderer.domElement);
    this.renderer = renderer;

    // langit: quad full-screen ber-gradasi
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { top: { value: this.pal.skyTop }, bottom: { value: this.pal.skyBottom } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.9999, 1.0); }',
      fragmentShader: `
        varying vec2 vUv; uniform vec3 top; uniform vec3 bottom;
        void main(){
          vec3 c = mix(bottom, top, smoothstep(0.0, 1.0, vUv.y));
          float g = 1.0 - smoothstep(0.0, 0.85, distance(vUv, vec2(0.5, 1.08)));
          c += g * g * 0.10;
          gl_FragColor = vec4(pow(c, vec3(1.0 / 2.2)), 1.0);
        }`,
      depthTest: false,
      depthWrite: false,
    });
    this.skyMesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.skyMat);
    this.skyMesh.frustumCulled = false;
    this.skyMesh.renderOrder = -1000;
    this.scene.add(this.skyMesh);

    this.fog = new THREE.Fog(0xffffff, 88, 250);
    this.scene.fog = this.fog;

    // cahaya
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0xd8dcff, 2.25));
    const sun = new THREE.DirectionalLight(0xffffff, 1.35);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    const sc = sun.shadow.camera;
    sc.left = -52;
    sc.right = 52;
    sc.top = 52;
    sc.bottom = -52;
    sc.near = 1;
    sc.far = 155;
    sun.shadow.bias = -0.0008;
    sun.shadow.normalBias = 0.03;
    this.scene.add(sun, sun.target);
    this.sun = sun;

    // track mulus (1 draw call untuk seluruh dek, kerb solid, & garis tengah kontinu)
    this.roadMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    this.roadMesh = new TrackMesh(560, this.roadMat);
    this.scene.add(this.roadMesh.mesh);

    // batch kotak (pilar, koin, tiang pivot, tali, awan, asap lembut)
    this.litMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    this.glowMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.lit = new BoxBatch(2200, this.litMat, true);
    this.glow = new BoxBatch(1100, this.glowMat, false);
    this.scene.add(this.lit.mesh, this.glow.mesh);

    for (let i = 0; i < MAX_PARTS; i++) {
      this.parts.push({
        on: false, glow: false, mode: 0, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, g: 0, drag: 0,
        age: 0, life: 1, sx: 1, sy: 1, sz: 1, yaw: 0, rot: 0, spin: 0, r: 1, gr: 1, b: 1,
      });
    }
    for (let i = 0; i < 16; i++) {
      this.clouds.push({ x: 0, y: 0, z: 0, i: 0, yaw: 0, born: -10, vx: 0, parts: [] });
    }

    this.rig = buildCar(carById(this.carId));
    this.scene.add(this.rig.group);

    this.reset(true);

    el.addEventListener('pointerdown', this.onDown);
    el.addEventListener('contextmenu', this.onContext);
    window.addEventListener('pointerup', this.onUp);
    window.addEventListener('pointercancel', this.onUp);
    window.addEventListener('blur', this.onUp);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(el);
    this.resize();

    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  // ───────────────────────────── API publik ─────────────────────────────

  start() {
    this.sfx.unlock();
    if (this.state === 'playing' || this.state === 'falling') return;
    if (this.state === 'over') this.reset(false);
    this.pressed = false;
    this.setState('playing');
    this.sfx.go();
  }

  toMenu() {
    this.sfx.unlock();
    this.sfx.click();
    this.reset(true);
    this.setState('menu');
  }

  setCar(id: string, canStart: boolean) {
    this.canStart = canStart;
    if (id === this.carId) return;
    this.carId = id;
    const old = this.rig;
    this.scene.remove(old.group);
    old.dispose();
    this.rig = buildCar(carById(id));
    this.scene.add(this.rig.group);
    this.sqV += 5.5;
    this.sfx.unlock();
    this.sfx.click();
    const c = this.car;
    for (let i = 0; i < 12; i++) {
      const a = rnd(TAU);
      this.emit3(false, 0, c.x + Math.cos(a) * 1.0, c.y + rnd(0.2, 1.3), c.z + Math.sin(a) * 1.0,
        Math.cos(a) * 3.2, rnd(1, 3.2), Math.sin(a) * 3.2, rnd(0.35, 0.6), rnd(0.32, 0.52), C_WHITE, -1, 3);
    }
  }

  setCanStart(v: boolean) {
    this.canStart = v;
  }

  setCam(id: CamId) {
    if (id === this.camId) return;
    this.camId = id;
    this.sfx.unlock();
    this.sfx.click();
  }

  setMuted(m: boolean) {
    this.sfx.unlock();
    this.sfx.setMuted(m);
    if (!m) this.sfx.click();
  }

  uiClick() {
    this.sfx.unlock();
    this.sfx.click();
  }

  deny() {
    this.sfx.unlock();
    this.sfx.deny();
  }

  celebrate() {
    this.sfx.unlock();
    this.sfx.buy();
    this.sqV += 6.5;
    const c = this.car;
    this.confetti(c.x, c.y + 1.2, c.z, 36);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.el.removeEventListener('pointerdown', this.onDown);
    this.el.removeEventListener('contextmenu', this.onContext);
    window.removeEventListener('pointerup', this.onUp);
    window.removeEventListener('pointercancel', this.onUp);
    window.removeEventListener('blur', this.onUp);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.sfx.engine(false, 0, 0);
    this.sfx.drift(false, 0);
    this.rig.dispose();
    this.roadMesh.dispose();
    this.roadMat.dispose();
    this.lit.dispose();
    this.glow.dispose();
    this.litMat.dispose();
    this.glowMat.dispose();
    this.skyMesh.geometry.dispose();
    this.skyMat.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }

  // ───────────────────────────── input ─────────────────────────────

  private onDown = (e: PointerEvent) => {
    if (e.button > 0) return;
    e.preventDefault();
    this.press();
  };
  private onUp = () => {
    this.pressed = false;
  };
  private onContext = (e: Event) => e.preventDefault();
  private onKeyDown = (e: KeyboardEvent) => {
    if (e.code !== 'Space' && e.code !== 'ArrowUp' && e.code !== 'Enter' && e.code !== 'KeyX') return;
    const t = e.target as HTMLElement | null;
    if (t && typeof t.closest === 'function' && t.closest('button')) return;
    e.preventDefault();
    if (e.repeat) return;
    this.press();
  };
  private onKeyUp = (e: KeyboardEvent) => {
    if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'Enter' || e.code === 'KeyX') this.pressed = false;
  };

  private press() {
    this.sfx.unlock();
    if (this.state === 'menu') {
      if (this.canStart) this.start();
      else {
        this.sfx.deny();
        this.emit({ type: 'locked' });
      }
    } else if (this.state === 'over') {
      if (this.stateT > 0.45) this.start();
    } else if (this.state === 'playing') {
      this.pressed = true;
    }
  }

  // ───────────────────────────── helper ─────────────────────────────

  private emit(e: GameEvent) {
    this.emitFn(e);
  }

  private setState(s: GameState) {
    this.state = s;
    this.stateT = 0;
    this.emit({ type: 'state', state: s });
  }

  private pop(text: string, tone: PopTone, gain: number, sub?: string) {
    this.emit({ type: 'pop', text, sub, tone, gain });
  }

  private vibrate(ms: number) {
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') navigator.vibrate(ms);
    } catch {
      /* tidak didukung */
    }
  }

  private baseSpeed() {
    return 19.2 + Math.min(this.cleared, 75) * 0.22;
  }

  private setTheme(t: Theme, dur: number) {
    for (const k of PKEYS) {
      this.palFrom[k].copy(this.pal[k]);
      this.palTo[k].setHex(t[k]);
    }
    this.palT = 0;
    this.palDur = dur;
  }

  private resize() {
    const w = Math.max(1, this.el.clientWidth);
    const h = Math.max(1, this.el.clientHeight);
    this.aspect = w / h;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(w, h);
    this.camera.aspect = this.aspect;
    this.camera.updateProjectionMatrix();
  }

  private reset(menu: boolean) {
    this.track = new Track((Math.random() * 2147483647) | 0);
    this.track.ensure(START_I + AHEAD + 140);
    const s = this.track.samples[START_I];
    const c = this.car;
    c.x = s.x;
    c.z = s.z;
    c.y = s.carY;
    c.th = s.th;
    c.speed = 0;
    c.idx = START_I;
    c.lat = 0;
    c.over = -1;
    c.hook = null;
    c.taut = false;
    c.hookR = 0;
    c.alpha = 0;

    this.visTh = c.th;
    this.drift = 0;
    this.driftV = 0;
    this.sq = 0;
    this.sqV = 0;
    this.pitch = 0;
    this.wheelRot = 0;
    this.arcPtr = 0;
    this.arcLo = 0;
    this.pendingEval = null;
    this.inGap = false;
    this.pressed = false;
    this.score = 0;
    this.combo = 0;
    this.bestCombo = 0;
    this.perfects = 0;
    this.cleared = 0;
    this.runGems = 0;
    this.stage = 0;
    this.boost = 0;
    this.assistT = 0;
    this.nearT = 0;
    this.fovKick = 0;
    this.shake = 0;
    this.hint = null;
    this.tileLo = 0;
    this.tileHi = -1;
    this.fallPtr = 0;
    this.intro = true;
    this.rippleT = -1;
    this.ropeBack = 0;
    this.ropeArc = null;
    this.timeScale = 1;
    this.timeScaleTarget = 1;
    this.helixMix = 0;
    this.helixArc = null;
    for (const p of this.parts) p.on = false;
    for (const cl of this.clouds) {
      this.placeCloud(cl, Math.max(0, START_I - 8 + rnd(105)));
      cl.born = -10;
    }

    this.camT.set(c.x, c.y + 0.7, c.z);
    this.camYaw = c.th + (menu ? Math.PI : 0);
    if (menu) {
      this.camPitch = 0.28;
      this.camDist = 9.4;
      this.camLook = 0;
    }
    this.rig.group.visible = true;
    this.rig.group.rotation.set(0, c.th, 0);
    this.rig.tilt.rotation.set(0, 0, 0);
    this.rig.tilt.scale.set(1, 1, 1);
    this.setTheme(THEMES[0], 0.5);
  }

  // ───────────────────────────── partikel ─────────────────────────────

  private emit3(
    glow: boolean,
    mode: number,
    x: number,
    y: number,
    z: number,
    vx: number,
    vy: number,
    vz: number,
    life: number,
    size: number,
    c: THREE.Color,
    g = 0,
    drag = 0,
    spin = 0,
  ): Particle {
    const p = this.parts[this.pi];
    this.pi = (this.pi + 1) % MAX_PARTS;
    p.on = true;
    p.glow = glow;
    p.mode = mode;
    p.x = x;
    p.y = y;
    p.z = z;
    p.vx = vx;
    p.vy = vy;
    p.vz = vz;
    p.g = g;
    p.drag = drag;
    p.age = 0;
    p.life = life;
    p.sx = p.sy = p.sz = size;
    p.yaw = rnd(TAU);
    p.rot = spin !== 0 ? rnd(TAU) : 0;
    p.spin = spin;
    p.r = c.r;
    p.gr = c.g;
    p.b = c.b;
    return p;
  }

  private confetti(x: number, y: number, z: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = rnd(TAU);
      const sp = rnd(3.5, 10.5);
      this.emit3(true, 1, x, y, z, Math.cos(a) * sp, rnd(6.5, 14), Math.sin(a) * sp, rnd(0.7, 1.15),
        rnd(0.22, 0.38), CONFETTI[(Math.random() * CONFETTI.length) | 0], 24, 0.6, rnd(-10, 10));
    }
  }

  private dustRing(n: number, speed: number) {
    const c = this.car;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + rnd(0.4);
      this.emit3(false, 0, c.x + Math.cos(a) * 0.7, c.y + 0.2, c.z + Math.sin(a) * 0.7,
        Math.cos(a) * speed, rnd(0.5, 2.2), Math.sin(a) * speed, rnd(0.35, 0.6), rnd(0.38, 0.65), C_WHITE, -0.5, 3.5);
    }
  }

  private placeCloud(cl: Cloud, baseI: number) {
    const tr = this.track;
    const i = Math.max(0, Math.floor(baseI));
    tr.ensure(i + 2);
    const s = tr.samples[i];
    const side = Math.random() < 0.5 ? -1 : 1;
    const lat = rnd(3, 54);
    const yo = -rnd(16, 50);
    cl.x = s.x + Math.cos(s.th) * lat * side;
    cl.z = s.z - Math.sin(s.th) * lat * side;
    cl.y = s.y + yo;
    cl.i = i;
    cl.yaw = rnd(TAU);
    cl.born = this.time;
    cl.vx = rnd(-0.5, 0.5);
    const w = rnd(5, 11);
    const d = rnd(3, 6);
    cl.parts = [
      0, 0, 0, w, 1.8, d,
      -w * 0.2, 1.3, 0.2, w * 0.5, 1.4, d * 0.7,
      w * 0.24, 1.0, -0.3, w * 0.34, 1.0, d * 0.6,
    ];
  }

  // ───────────────────────────── loop utama ─────────────────────────────

  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    let rdt = (now - this.last) / 1000;
    this.last = now;
    if (!(rdt > 0)) rdt = 0.016;
    if (rdt > 0.05) rdt = 0.05;
    this.timeScale += (this.timeScaleTarget - this.timeScale) * Math.min(1, rdt * 12);
    const dt = rdt * this.timeScale;
    this.time += dt;
    this.stateT += rdt;

    this.update(dt, rdt);

    this.roadMesh.begin();
    this.lit.begin();
    this.glow.begin();
    this.drawTrack();
    this.drawPivots();
    this.drawRope(rdt);
    this.drawClouds();
    this.drawParticles();
    this.roadMesh.end();
    this.lit.end();
    this.glow.end();

    this.updateRig(dt);
    this.updateCamera(rdt);
    this.renderer.render(this.scene, this.camera);
  };

  private update(dt: number, rdt: number) {
    const c = this.car;

    if (this.state === 'playing') {
      const n = Math.max(1, Math.ceil(dt / 0.006));
      const h = dt / n;
      let alive = true;
      for (let k = 0; k < n && alive; k++) alive = this.step(h);
      if (alive) this.afterStep(dt);
    } else if (this.state === 'falling') {
      c.x += Math.sin(c.th) * c.speed * 0.8 * dt;
      c.z += Math.cos(c.th) * c.speed * 0.8 * dt;
      this.fallVy -= 34 * dt;
      c.y += this.fallVy * dt;
      this.q.setFromAxisAngle(this.tumbleAxis, this.tumbleSpeed * dt);
      this.rig.group.quaternion.premultiply(this.q);
      this.puffAcc += dt;
      if (this.puffAcc > 0.04) {
        this.puffAcc = 0;
        this.emit3(false, 0, c.x, c.y + 0.5, c.z, rnd(-1, 1), rnd(1, 3), rnd(-1, 1), 0.5, rnd(0.3, 0.5), C_WHITE, 0, 2);
      }
      this.timeScaleTarget = this.stateT < 0.28 ? 0.3 : 1;
      if (this.stateT > 1.25) this.finish();
    }

    this.fovKick = Math.max(0, this.fovKick - rdt * 2.1);
    this.shake *= Math.exp(-9 * rdt);

    // transisi palet
    if (this.palT < 1) {
      this.palT = Math.min(1, this.palT + rdt / this.palDur);
      const e = this.palT * this.palT * (3 - 2 * this.palT);
      for (const k of PKEYS) this.pal[k].copy(this.palFrom[k]).lerp(this.palTo[k], e);
    }
    this.fog.color.copy(this.pal.fog);

    // partikel
    for (const p of this.parts) {
      if (!p.on) continue;
      p.age += dt;
      if (p.age >= p.life) {
        p.on = false;
        continue;
      }
      if (p.drag > 0) {
        const k = Math.max(0, 1 - p.drag * dt);
        p.vx *= k;
        p.vy *= k;
        p.vz *= k;
      }
      p.vy -= p.g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.rot += p.spin * dt;
    }

    // awan
    for (const cl of this.clouds) {
      cl.x += cl.vx * dt;
      if (this.state === 'playing' && cl.i < c.idx - 28) this.placeCloud(cl, c.idx + 62 + rnd(48));
    }
  }

  /** satu sub-langkah fisika; false kalau mobil jatuh */
  private step(dt: number): boolean {
    const c = this.car;
    const tr = this.track;
    const cornerBoost = c.hook && c.taut ? 1.07 : 1;
    const target = this.baseSpeed() * (1 + 0.24 * this.boost) * cornerBoost;
    c.speed += (target - c.speed) * Math.min(1, dt * 4.8);

    const prevHook = c.hook;
    const prevTaut = c.taut;
    const ev = stepCar(c, tr, tr.arcs[this.arcPtr], this.pressed, !this.inGap, this.assistT > 0 ? 1.8 : ASSIST, dt);

    if (ev & EV_HOOK) {
      this.ropeT = 0;
      this.sfx.hook();
    }
    if (ev & EV_TAUT) this.onTaut();
    if (ev & EV_RELEASE && prevHook) this.onRelease(prevHook, prevTaut);
    if (ev & EV_OFF) {
      this.crash();
      return false;
    }

    const ri = Math.round(c.idx);
    const s = tr.samples[ri];
    if (s.gap !== this.inGap) {
      this.inGap = s.gap;
      if (s.gap) this.onTakeoff();
      else this.onLand();
    }
    if (!s.gap && s.pressT < 0) s.pressT = this.time;

    // tikungan terlewati?
    while (this.arcPtr < tr.arcs.length && c.idx > tr.arcs[this.arcPtr].endI) {
      const a = tr.arcs[this.arcPtr++];
      if (c.hook === a) this.pendingEval = a;
      else this.evalArc(a);
    }

    // koin
    const i0 = Math.max(0, Math.floor(c.idx) - 1);
    for (let i = i0; i <= i0 + 3; i++) {
      const g = tr.samples[i];
      if (g && g.gem && !g.gemTaken) {
        const dx = g.x - c.x;
        const dz = g.z - c.z;
        if (dx * dx + dz * dz < 2.8) {
          g.gemTaken = true;
          this.onGem(g.x, g.carY + 0.95, g.z);
        }
      }
    }
    return true;
  }

  /** efek per-frame saat bermain: asap, jejak, percikan, hint, audio */
  private afterStep(dt: number) {
    const c = this.car;
    const tr = this.track;
    this.boost = Math.max(0, this.boost - dt * 1.05);
    this.assistT = Math.max(0, this.assistT - dt);

    const taut = !!c.hook && c.taut;
    const yaw = this.visTh + this.drift;
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    const lx = Math.cos(yaw);
    const lz = -Math.sin(yaw);
    const wl = 0.72 * CAR_SCALE;
    const rx = c.x - fx * 0.75 * CAR_SCALE;
    const rz = c.z - fz * 0.75 * CAR_SCALE;
    const ground = !this.inGap;

    const preHook = !!c.hook && !c.taut;
    if ((taut || preHook) && ground) {
      // gumpalan asap putih lembut & empuk (mulai muncul begitu pencet!)
      const smokeStep = taut ? 0.016 : 0.036;
      const smokeSize = taut ? rnd(0.58, 0.96) : rnd(0.36, 0.56);
      this.smokeAcc += dt;
      while (this.smokeAcc > smokeStep) {
        this.smokeAcc -= smokeStep;
        const colr =
          taut && this.combo >= 3
            ? this.col.setHSL((this.time * 0.85) % 1, 0.9, 0.78, SRGB)
            : C_WHITE;
        for (const sd of [-1, 1]) {
          this.emit3(
            false,
            0,
            rx + lx * wl * 0.85 * sd + rnd(-0.18, 0.18),
            c.y + 0.28 + rnd(0, 0.12),
            rz + lz * wl * 0.85 * sd + rnd(-0.18, 0.18),
            -fx * 1.8 + rnd(-1.1, 1.1),
            rnd(0.9, 2.4),
            -fz * 1.8 + rnd(-1.1, 1.1),
            rnd(0.55, 0.92),
            smokeSize,
            colr,
            -1.4,
            2.8,
            rnd(-2.2, 2.2),
          );
        }
      }
      if (taut) {
        this.skidAcc += dt;
        while (this.skidAcc > 0.016) {
          this.skidAcc -= 0.016;
          for (const sd of [-1, 1]) {
            const p = this.emit3(false, 2, rx + lx * wl * sd, c.y + 0.05, rz + lz * wl * sd, 0, 0, 0, 0.65, 0.36, C_SKID);
            p.sy = 0.05;
            p.sz = 0.88;
            p.yaw = yaw;
          }
        }
        this.driftSparkAcc += dt;
        if (this.driftSparkAcc > 0.05) {
          this.driftSparkAcc = 0;
          const outer = c.hook ? c.hook.turn : 1;
          this.emit3(true, 1, rx + lx * wl * outer, c.y + 0.15, rz + lz * wl * outer,
            -fx * 5 + rnd(-2, 2), rnd(2.2, 5.0), -fz * 5 + rnd(-2, 2), rnd(0.22, 0.34), rnd(0.11, 0.18), C_SPARK, 22, 0, rnd(-8, 8));
        }
      }
    } else if (ground) {
      // asap knalpot lembut bergumpal mengikuti belakang mobil
      this.puffAcc += dt;
      while (this.puffAcc > 0.065) {
        this.puffAcc -= 0.065;
        this.emit3(
          false,
          0,
          rx - fx * 0.55 + rnd(-0.12, 0.12),
          c.y + 0.36,
          rz - fz * 0.55 + rnd(-0.12, 0.12),
          -fx * 2.2 + rnd(-0.4, 0.4),
          rnd(0.6, 1.4),
          -fz * 2.2 + rnd(-0.4, 0.4),
          rnd(0.45, 0.65),
          rnd(0.38, 0.56),
          C_WHITE,
          -0.9,
          2.6,
          rnd(-1.5, 1.5),
        );
      }
    }

    // ekor pelangi saat combo
    if (this.combo >= 2) {
      this.trailAcc += dt;
      while (this.trailAcc > 0.025) {
        this.trailAcc -= 0.025;
        const colr = this.col.setHSL((this.time * 1.45) % 1, 0.95, 0.64, SRGB);
        this.emit3(true, 1, rx + rnd(-0.3, 0.3), c.y + 0.72 + rnd(-0.1, 0.1), rz + rnd(-0.3, 0.3),
          0, rnd(0, 0.6), 0, 0.44, rnd(0.32, 0.48), colr, 0, 0, rnd(-4, 4));
      }
    }

    // garis kecepatan saat boost atau melaju kencang
    if ((this.boost > 0.1 || c.speed > 24) && !this.reduced) {
      this.speedLineAcc += dt;
      const rate = this.boost > 0.1 ? 0.016 : 0.04;
      while (this.speedLineAcc > rate) {
        this.speedLineAcc -= rate;
        const ahead = rnd(7, 30);
        const side = rnd(3.2, 12) * (Math.random() < 0.5 ? -1 : 1);
        const p = this.emit3(true, 3, c.x + Math.sin(c.th) * ahead + Math.cos(c.th) * side, c.y + rnd(0.6, 6.5),
          c.z + Math.cos(c.th) * ahead - Math.sin(c.th) * side, 0, 0, 0, 0.28, 0.075, C_WHITE);
        p.sz = rnd(3.2, 6.2);
        p.yaw = c.th;
      }
    }

    // nyaris jatuh: percikan + bonus kalau selamat
    const s = tr.samples[Math.round(c.idx)];
    const ratio = Math.abs(c.lat) / s.hw;
    if (ground && ratio > 0.9) {
      this.nearT += dt;
      this.sparkAcc += dt;
      if (this.sparkAcc > 0.02) {
        this.sparkAcc = 0;
        const sd = c.lat > 0 ? 1 : -1;
        this.emit3(true, 1, c.x + lx * wl * sd, c.y + 0.15, c.z + lz * wl * sd,
          -fx * 4 + rnd(-3, 3), rnd(3, 7), -fz * 4 + rnd(-3, 3), rnd(0.2, 0.35), rnd(0.12, 0.2), C_SPARK, 22, 0, rnd(-8, 8));
      }
    } else if (ratio < 0.78) {
      if (this.nearT > 0.07) {
        this.score += 1;
        this.emit({ type: 'score', score: this.score, combo: this.combo });
        this.pop('NYARIS!', 'near', 1);
        this.sfx.near();
        this.shake = Math.max(this.shake, 0.2);
      }
      this.nearT = 0;
    }

    // hint tutorial (+ slow-mo di tikungan pertama)
    let hint: Hint = null;
    if (this.tutorial && this.cleared < 3) {
      const a = tr.arcs[this.arcPtr];
      if (c.hook) hint = c.idx > c.hook.endI - 2.4 ? 'release' : 'keep';
      else if (a && c.idx > a.startI - 6.5 && c.idx < a.endI - 2.5) hint = 'hold';
    }
    if (hint !== this.hint) {
      this.hint = hint;
      this.emit({ type: 'hint', hint });
    }
    this.timeScaleTarget = this.tutorial && this.cleared < 2 && hint === 'release' ? 0.5 : 1;

    this.sfx.engine(true, c.speed, this.boost, taut && ground);
    this.sfx.drift(taut && ground, c.speed);
  }

  // ───────────────────────────── event gameplay ─────────────────────────────

  private onTaut() {
    this.sqV -= 3.8;
    this.sfx.grip();
    this.dustRing(8, 4.2);
    if (!this.reduced) this.shake = Math.max(this.shake, 0.14);
  }

  private onRelease(a: Arc, wasTaut: boolean) {
    this.ropeBack = 0.12;
    this.ropeArc = a;
    if (wasTaut) {
      this.sqV += 3.2;
      this.boost = Math.max(this.boost, 0.35); // whip sling ringan tiap lepas drift!
      this.sfx.release();
    }
    if (this.pendingEval === a) {
      this.pendingEval = null;
      this.evalArc(a);
    }
  }

  private onTakeoff() {
    this.sqV += 5;
    this.sfx.jump();
  }

  private onLand() {
    this.sqV -= 7;
    this.sfx.land();
    this.dustRing(14, 6.5);
    if (!this.reduced) this.shake = Math.max(this.shake, 0.42);
    this.vibrate(15);
    this.score += 1;
    this.emit({ type: 'score', score: this.score, combo: this.combo });
    this.pop('TERBANG!', 'air', 1);
  }

  private onGem(x: number, y: number, z: number) {
    this.runGems++;
    this.gemStreak = this.time - this.gemT < 1.2 ? this.gemStreak + 1 : 0;
    this.gemT = this.time;
    this.sfx.gem(this.gemStreak);
    this.emit({ type: 'gems', run: this.runGems });
    for (let i = 0; i < 8; i++) {
      const a = rnd(TAU);
      this.emit3(true, 1, x, y, z, Math.cos(a) * rnd(2, 5.5), rnd(2.5, 6.5), Math.sin(a) * rnd(2, 5.5),
        rnd(0.3, 0.5), rnd(0.13, 0.24), C_GEM, 14, 0, rnd(-8, 8));
    }
  }

  /** nilai kualitas keluar tikungan → skor, combo, juice */
  private evalArc(a: Arc) {
    const c = this.car;
    const s = this.track.samples[Math.round(c.idx)];
    const he = Math.abs(angDiff(c.th, a.th1));
    const lat = Math.abs(c.lat) / s.hw;
    this.cleared++;
    let gain = a.helix ? 3 : 1;

    if (he < PERFECT_ANG && lat < 0.55) {
      this.combo++;
      this.perfects++;
      if (this.combo > this.bestCombo) this.bestCombo = this.combo;
      gain += Math.min(this.combo, 5);
      this.boost = 1;
      this.assistT = 0.35;
      this.rippleT = this.time;
      this.rippleI = c.idx;
      this.sqV += 3.6;
      if (!this.reduced) this.fovKick = 1.1;
      this.confetti(c.x, c.y + 1, c.z, 14 + Math.min(this.combo, 6) * 2);
      this.sfx.perfect(this.combo);
      this.vibrate(14);
      if (this.combo % 3 === 0) {
        this.runGems += 2;
        this.emit({ type: 'gems', run: this.runGems });
      }
      this.pop(a.helix ? 'SWIRL PERFECT!' : 'PERFECT!', 'perfect', gain, this.combo > 1 ? `COMBO ×${this.combo}` : undefined);
    } else {
      this.combo = 0;
      if (a.helix) {
        this.pop('SWIRL!', 'swirl', gain);
        this.sfx.good();
      } else if (he < 0.34 && lat < 0.85) {
        this.pop('MANTAP!', 'good', gain);
        this.sfx.good();
      } else {
        this.sfx.pass();
      }
    }

    this.score += gain;
    this.emit({ type: 'score', score: this.score, combo: this.combo });

    const st = Math.floor(this.cleared / 10);
    if (st !== this.stage) {
      this.stage = st;
      const theme = THEMES[st % THEMES.length];
      this.setTheme(theme, 1.4);
      this.emit({ type: 'stage', index: st + 1, name: theme.name });
      this.sfx.stage();
    }
  }

  private crash() {
    const c = this.car;
    c.hook = null;
    c.taut = false;
    this.pendingEval = null;
    this.pressed = false;
    this.fallVy = 2.5;
    this.tumbleAxis.set(rnd(-1, 1), rnd(-0.3, 0.3), rnd(-1, 1)).normalize();
    this.tumbleSpeed = rnd(6, 10);
    if (!this.reduced) this.shake = 1;
    this.timeScaleTarget = 0.3;
    this.sfx.crash();
    this.sfx.engine(false, 0, 0);
    this.sfx.drift(false, 0);
    this.vibrate(70);
    const colors = this.rig.colors;
    for (let i = 0; i < 18; i++) {
      this.col.setHex(colors[i % colors.length]);
      this.emit3(false, 1, c.x, c.y + 0.6, c.z, rnd(-6, 6) + Math.sin(c.th) * 5, rnd(4, 11), rnd(-6, 6) + Math.cos(c.th) * 5,
        rnd(0.8, 1.2), rnd(0.24, 0.44), this.col, 30, 0, rnd(-10, 10));
    }
    if (this.hint) {
      this.hint = null;
      this.emit({ type: 'hint', hint: null });
    }
    this.setState('falling');
  }

  private finish() {
    this.rig.group.visible = false;
    this.timeScaleTarget = 1;
    this.setState('over');
    this.emit({
      type: 'over',
      score: this.score,
      gems: this.runGems,
      perfects: this.perfects,
      bestCombo: this.bestCombo,
      corners: this.cleared,
    });
  }

  // ───────────────────────────── gambar ─────────────────────────────

  private sampleWave(i: number, t: number, rip: number): { yo: number; fl: number } {
    const s = this.track.samples[i];
    let yo = 0;
    let fl = 0;
    if (s.pressT >= 0) {
      const p = t - s.pressT;
      if (p < 0.65) yo -= 0.14 * Math.exp(-p * 7.5) * Math.cos(p * 20);
    }
    if (rip >= 0) {
      const d = i - this.rippleI;
      if (d > 0 && d < 46) {
        const ph = rip - d;
        if (ph > -3 && ph < 3) {
          fl = Math.exp(-ph * ph * 0.7) * (1 - d / 46);
          yo += fl * 0.35;
        }
      }
    }
    return { yo, fl };
  }

  private drawTrack() {
    const tr = this.track;
    const t = this.time;
    const pal = this.pal;
    const L = this.lit;
    const R = this.roadMesh;
    const ci = Math.floor(this.car.idx);
    const hi = ci + AHEAD;
    tr.ensure(hi + 130);

    // segmen baru pop-in di depan
    if (hi > this.tileHi) {
      for (let i = this.tileHi + 1; i <= hi; i++) {
        tr.samples[i].spawnT = this.intro ? t + Math.max(0, i - START_I) * 0.011 : t;
      }
      this.tileHi = hi;
      this.intro = false;
    }
    // segmen di belakang runtuh (collapse!)
    if (this.state === 'playing') {
      const lim = ci - BEHIND;
      while (this.fallPtr < lim) {
        const s = tr.samples[this.fallPtr];
        if (s.fallT < 0) s.fallT = t + hash(this.fallPtr) * 0.06;
        this.fallPtr++;
      }
    }
    while (this.tileLo < this.tileHi) {
      const s = tr.samples[this.tileLo];
      if (s.fallT >= 0 && t - s.fallT > 0.95) this.tileLo++;
      else break;
    }

    this.edgeCol.copy(pal.trackA).lerp(pal.trackB, 0.42);
    let rip = -1;
    if (this.rippleT >= 0) {
      rip = (t - this.rippleT) * 78;
      if (rip > 60) {
        this.rippleT = -1;
        rip = -1;
      }
    }

    for (let i = Math.max(1, this.tileLo); i <= this.tileHi; i++) {
      const s0 = tr.samples[i - 1];
      const s1 = tr.samples[i];

      const a = (t - s1.spawnT) / 0.42;
      if (a <= 0) continue;

      let yo = 0;
      let sc = 1;
      let tx = 0;
      let tz = 0;
      let detached = false;

      if (a < 1) {
        yo = (backOut(a) - 1) * 7.5;
        sc = Math.min(1, 0.25 + a * 1.5);
        detached = true;
      }
      if (s1.fallT >= 0) {
        const f = t - s1.fallT;
        if (f > 0) {
          yo -= 27 * f * f;
          sc *= Math.max(0, 1 - f / 0.95);
          tx = f * (hash(i * 7.13) - 0.5) * 5.2;
          tz = f * (hash(i * 3.71) - 0.5) * 5.2;
          detached = true;
        }
      }
      if (sc < 0.02) continue;

      const w0 = this.sampleWave(i - 1, t, rip);
      const w1 = this.sampleWave(i, t, rip);

      // jika segmen sudah menyatu di jalan, gunakan gelombang mulus per-sample;
      // jika sedang pop-in atau collapse, lepaskan segmen sebagai blok utuh!
      const dy0 = detached ? yo + w1.yo : w0.yo;
      const dy1 = detached ? yo + w1.yo : w1.yo;
      const prevDetached =
        (t - s0.spawnT) / 0.42 < 1 || (s0.fallT >= 0 && t - s0.fallT > 0) || s0.gap;
      const next = i + 1 <= this.tileHi ? tr.samples[i + 1] : null;
      const nextDetached =
        !next || (t - next.spawnT) / 0.42 < 1 || (next.fallT >= 0 && t - next.fallT > 0) || next.gap;

      if (!s1.gap) {
        const isArc = s1.kind === K_ARC || s1.kind === K_HELIX;
        const isRamp = s1.kind === K_RAMP;

        const base = isArc ? pal.arcA : isRamp ? pal.curbA : pal.trackA;
        const col = this.col.copy(base);
        if (w1.fl > 0) col.lerp(pal.rope, w1.fl * 0.72);
        this.sideCol.copy(col).multiplyScalar(0.75);

        // kerb solid clean & khas (tanpa belang ramai)
        const curb = pal.curbA;
        this.kerbSideCol.copy(curb).multiplyScalar(0.76);

        const lx0 = Math.cos(s0.th), lz0 = -Math.sin(s0.th);
        const lx1 = Math.cos(s1.th), lz1 = -Math.sin(s1.th);
        const wIn0 = Math.max(0.5, s0.hw - CURB_W);
        const wIn1 = Math.max(0.5, s1.hw - CURB_W);

        // titik pusat transformasi saat segmen pop-in / runtuh
        const mx = (s0.x + s1.x) * 0.5;
        const my = (s0.y + s1.y) * 0.5 + yo - TH * 0.5;
        const mz = (s0.z + s1.z) * 0.5;
        const hasRot = tx !== 0 || tz !== 0;
        if (hasRot) this.q.setFromEuler(this.e.set(tx, 0, tz, 'YXZ'));

        const xform = (px: number, py: number, pz: number): [number, number, number] => {
          if (!detached) return [px, py, pz];
          const vx = (px - mx) * sc;
          const vy = (py - (s0.y + s1.y) * 0.5 + TH * 0.5) * sc;
          const vz = (pz - mz) * sc;
          if (hasRot) {
            this.v1.set(vx, vy, vz).applyQuaternion(this.q);
            return [mx + this.v1.x, my + this.v1.y, mz + this.v1.z];
          }
          return [mx + vx, my + vy, mz + vz];
        };

        const capStart = detached || prevDetached;
        const capEnd = detached || nextDetached;

        // 1) Dek aspal tengah polos mulus
        const [dtl0x, dtl0y, dtl0z] = xform(s0.x + lx0 * wIn0, s0.y + dy0, s0.z + lz0 * wIn0);
        const [dtr0x, dtr0y, dtr0z] = xform(s0.x - lx0 * wIn0, s0.y + dy0, s0.z - lz0 * wIn0);
        const [dbl0x, dbl0y, dbl0z] = xform(s0.x + lx0 * wIn0, s0.y - TH + dy0, s0.z + lz0 * wIn0);
        const [dbr0x, dbr0y, dbr0z] = xform(s0.x - lx0 * wIn0, s0.y - TH + dy0, s0.z - lz0 * wIn0);

        const [dtl1x, dtl1y, dtl1z] = xform(s1.x + lx1 * wIn1, s1.y + dy1, s1.z + lz1 * wIn1);
        const [dtr1x, dtr1y, dtr1z] = xform(s1.x - lx1 * wIn1, s1.y + dy1, s1.z - lz1 * wIn1);
        const [dbl1x, dbl1y, dbl1z] = xform(s1.x + lx1 * wIn1, s1.y - TH + dy1, s1.z + lz1 * wIn1);
        const [dbr1x, dbr1y, dbr1z] = xform(s1.x - lx1 * wIn1, s1.y - TH + dy1, s1.z - lz1 * wIn1);

        R.addPrism(
          dtl0x, dtl0y, dtl0z, dtr0x, dtr0y, dtr0z, dbl0x, dbl0y, dbl0z, dbr0x, dbr0y, dbr0z,
          dtl1x, dtl1y, dtl1z, dtr1x, dtr1y, dtr1z, dbl1x, dbl1y, dbl1z, dbr1x, dbr1y, dbr1z,
          col, this.sideCol, capStart, capEnd,
        );

        // 2) Kerb solid kiri (+L) & kanan (-L) mengikuti kemiringan mulus
        const topK = 0.08;
        const botK = topK - CURB_H;
        for (const sd of [1, -1]) {
          const wA0 = sd > 0 ? s0.hw + 0.03 : -wIn0;
          const wB0 = sd > 0 ? wIn0 : -(s0.hw + 0.03);
          const wA1 = sd > 0 ? s1.hw + 0.03 : -wIn1;
          const wB1 = sd > 0 ? wIn1 : -(s1.hw + 0.03);

          const [kl0x, kl0y, kl0z] = xform(s0.x + lx0 * wA0, s0.y + topK + dy0, s0.z + lz0 * wA0);
          const [kr0x, kr0y, kr0z] = xform(s0.x + lx0 * wB0, s0.y + topK + dy0, s0.z + lz0 * wB0);
          const [kbl0x, kbl0y, kbl0z] = xform(s0.x + lx0 * wA0, s0.y + botK + dy0, s0.z + lz0 * wA0);
          const [kbr0x, kbr0y, kbr0z] = xform(s0.x + lx0 * wB0, s0.y + botK + dy0, s0.z + lz0 * wB0);

          const [kl1x, kl1y, kl1z] = xform(s1.x + lx1 * wA1, s1.y + topK + dy1, s1.z + lz1 * wA1);
          const [kr1x, kr1y, kr1z] = xform(s1.x + lx1 * wB1, s1.y + topK + dy1, s1.z + lz1 * wB1);
          const [kbl1x, kbl1y, kbl1z] = xform(s1.x + lx1 * wA1, s1.y + botK + dy1, s1.z + lz1 * wA1);
          const [kbr1x, kbr1y, kbr1z] = xform(s1.x + lx1 * wB1, s1.y + botK + dy1, s1.z + lz1 * wB1);

          R.addPrism(
            kl0x, kl0y, kl0z, kr0x, kr0y, kr0z, kbl0x, kbl0y, kbl0z, kbr0x, kbr0y, kbr0z,
            kl1x, kl1y, kl1z, kr1x, kr1y, kr1z, kbl1x, kbl1y, kbl1z, kbr1x, kbr1y, kbr1z,
            curb, this.kerbSideCol, capStart, capEnd,
          );
        }

        // 3) Garis tengah tipis menyambung mulus (simple & clean!)
        if (!isRamp && !detached) {
          const lineCol = isArc ? pal.arcB : pal.trackB;
          const lw = 0.12;
          const yT = 0.018;
          const yB = -0.02;
          R.addPrism(
            s0.x + lx0 * lw, s0.y + yT + dy0, s0.z + lz0 * lw,
            s0.x - lx0 * lw, s0.y + yT + dy0, s0.z - lz0 * lw,
            s0.x + lx0 * lw, s0.y + yB + dy0, s0.z + lz0 * lw,
            s0.x - lx0 * lw, s0.y + yB + dy0, s0.z - lz0 * lw,
            s1.x + lx1 * lw, s1.y + yT + dy1, s1.z + lz1 * lw,
            s1.x - lx1 * lw, s1.y + yT + dy1, s1.z - lz1 * lw,
            s1.x + lx1 * lw, s1.y + yB + dy1, s1.z + lz1 * lw,
            s1.x - lx1 * lw, s1.y + yB + dy1, s1.z - lz1 * lw,
            lineCol, lineCol, prevDetached, nextDetached,
          );
        }

        // 4) Pilar-pilar penyangga panjang menjuntai ke bawah (ikut pop-in & collapse!)
        if (i % 5 === 0) {
          const ph = 34 * sc;
          const pCol = pal.curbB;
          const pYaw = s1.th;
          const offP = s1.hw - 0.55;
          const sd = i % 10 === 0 ? 1 : -1;
          const px = s1.x + lx1 * offP * sd;
          const pz = s1.z + lz1 * offP * sd;
          const py = s1.y - TH - ph * 0.5 + yo + dy1;
          if (hasRot) {
            this.q.setFromEuler(this.e.set(tx, pYaw, tz, 'YXZ'));
            L.add(px, py, pz, 0.72 * sc, ph, 0.72 * sc, this.q, pCol.r, pCol.g, pCol.b);
          } else {
            L.yaw(px, py, pz, 0.72 * sc, ph, 0.72 * sc, pYaw, pCol);
          }
        }
      }

      if (s1.gem && !s1.gemTaken && s1.fallT < 0) {
        const gs = 0.56 * sc;
        this.q2.setFromEuler(this.e.set(0.62, t * 3 + i, 0.62, 'YXZ'));
        L.add(s1.x, s1.carY + 0.95 + Math.sin(t * 4 + i) * 0.12 + yo, s1.z, gs, gs, gs, this.q2, C_GEM.r, C_GEM.g, C_GEM.b);
      }

      if (i === GATE_I) {
        this.q.set(0, Math.sin(s1.th / 2), 0, Math.cos(s1.th / 2));
        this.drawGate(s1, yo, sc);
      }
    }
  }

  private drawGate(s: Sample, yo: number, sc: number) {
    const L = this.lit;
    const pal = this.pal;
    const q = this.q;
    const off = s.hw + 0.5;
    const lx = Math.cos(s.th);
    const lz = -Math.sin(s.th);
    const h = 4.6 * sc;
    for (const sd of [-1, 1]) {
      L.add(s.x + lx * off * sd, s.y + h / 2 + yo, s.z + lz * off * sd, 0.6 * sc, h, 0.6 * sc, q, pal.pivot.r, pal.pivot.g, pal.pivot.b);
    }
    const n = 8;
    const w = (off * 2 + 0.6) / n;
    for (let k = 0; k < n; k++) {
      const u = -off - 0.3 + w * (k + 0.5);
      const c = k & 1 ? C_INK : C_WHITE;
      L.add(s.x + lx * u, s.y + h + 0.45 * sc + yo, s.z + lz * u, w * sc, 0.9 * sc, 0.36 * sc, q, c.r, c.g, c.b);
    }
  }

  private pivotTopY(a: Arc) {
    return a.py + Math.sin(this.time * 2 + a.startI * 0.37) * 0.15 + 1.95;
  }

  private drawPivots() {
    const tr = this.track;
    const t = this.time;
    const c = this.car;
    const pal = this.pal;
    const L = this.lit;
    const G = this.glow;

    for (let k = this.arcLo; k < tr.arcs.length; k++) {
      const a = tr.arcs[k];
      if (a.startI > this.tileHi) break;
      if (a.endI < this.tileLo) {
        if (k === this.arcLo) this.arcLo++;
        continue;
      }
      const s0 = tr.samples[a.startI];
      const s1 = tr.samples[a.endI];
      let sc = clamp((t - s0.spawnT) / 0.5, 0, 1);
      if (sc <= 0) continue;
      sc = backOut(sc);
      if (s1.fallT >= 0) sc *= clamp(1 - (t - s1.fallT) / 0.5, 0, 1);
      if (sc <= 0.01) continue;

      const hooked = c.hook === a;
      const target = k === this.arcPtr && this.state === 'playing';
      const pulse = hooked ? 1.16 + Math.sin(t * 34) * 0.06 : target ? 1 + (0.5 + 0.5 * Math.sin(t * 9)) * 0.14 : 1;
      const topCol = hooked ? pal.rope : pal.pivot;
      const B = hooked ? G : L;

      if (a.helix) {
        const top = a.yTop + 3;
        const bot = a.yBot - 3;
        const visTop = Math.min(top, c.y + 3.4);
        const n = Math.ceil((top - bot) / 1.5);
        for (let j = 0; j <= n; j++) {
          const y = top - j * 1.5;
          const m = clamp((visTop - y) / 1.2 + 0.5, 0, 1) * sc;
          if (m <= 0.02) continue;
          L.yaw(a.cx, y, a.cz, 1.7 * m, 1.5 * Math.min(1, m * 1.5), 1.7 * m, t * 0.9 + j * 0.45, j & 1 ? pal.pivot : C_WHITE);
        }
        const ts = 1.35 * sc * pulse;
        this.q.setFromEuler(this.e.set(0.62, t * (hooked ? 7 : 1.4), 0.62, 'YXZ'));
        B.add(a.cx, visTop + 1.9 + Math.sin(t * 2.2) * 0.15, a.cz, ts, ts, ts, this.q, topCol.r, topCol.g, topCol.b);
      } else {
        // tiang pivot menjulang tinggi dari langit dengan leher ring + kubus cerah di puncak
        const py = this.pivotTopY(a) - 1.95;
        const pLen = 38 * sc;
        L.yaw(a.cx, py + 1.2 - pLen * 0.5, a.cz, 0.48 * sc, pLen, 0.48 * sc, 0.785, C_WHITE);
        L.yaw(a.cx, py + 1.28, a.cz, 0.95 * sc, 0.22 * sc, 0.95 * sc, 0.785, pal.curbA);
        const ts = 1.25 * sc * pulse;
        this.q.setFromEuler(this.e.set(0.55, t * (hooked ? 9 : 1.5) + k, 0.55, 'YXZ'));
        B.add(a.cx, py + 2.05, a.cz, ts, ts, ts, this.q, topCol.r, topCol.g, topCol.b);
        if (target) {
          for (let j = 0; j < 3; j++) {
            const ang = t * 3 + (j * TAU) / 3;
            G.yaw(a.cx + Math.cos(ang) * 1.65, py + 2.05 + Math.sin(t * 4 + j) * 0.2, a.cz + Math.sin(ang) * 1.65, 0.24, 0.24, 0.24, ang, pal.rope);
          }
        }
      }
    }
  }

  private drawRope(rdt: number) {
    const c = this.car;
    const pal = this.pal;
    let a = c.hook;
    let k = 1;
    let thick = 0.1;
    if (a) {
      this.ropeT += rdt;
      k = Math.min(1, this.ropeT / 0.03);
      thick = c.taut ? 0.2 + Math.sin(this.time * 48) * 0.03 : 0.12;
    } else if (this.ropeBack > 0 && this.ropeArc) {
      this.ropeBack -= rdt;
      a = this.ropeArc;
      k = Math.max(0, this.ropeBack / 0.12);
    }
    if (!a || k <= 0) return;

    const fx = c.x;
    const fy = c.y + 0.95 * CAR_SCALE;
    const fz = c.z;
    const ty = a.helix ? c.y + 1.7 : this.pivotTopY(a);
    const ex = fx + (a.cx - fx) * k;
    const ey = fy + (ty - fy) * k;
    const ez = fz + (a.cz - fz) * k;
    const dx = ex - fx;
    const dy = ey - fy;
    const dz = ez - fz;
    const len = Math.hypot(dx, dy, dz);
    if (len < 0.01) return;
    this.v1.set(dx / len, dy / len, dz / len);
    this.q.setFromUnitVectors(Z_AXIS, this.v1);
    this.glow.add((fx + ex) / 2, (fy + ey) / 2, (fz + ez) / 2, thick, thick, len, this.q, pal.rope.r, pal.rope.g, pal.rope.b);
    this.glow.add(ex, ey, ez, 0.38, 0.38, 0.38, this.q, 1, 1, 1);
  }

  private drawClouds() {
    const L = this.lit;
    const col = this.edgeCol.copy(this.pal.cloud).lerp(this.pal.fog, 0.3);
    for (const cl of this.clouds) {
      const sc = clamp((this.time - cl.born) / 0.8, 0, 1);
      if (sc <= 0) continue;
      const sn = Math.sin(cl.yaw);
      const cs = Math.cos(cl.yaw);
      const p = cl.parts;
      for (let j = 0; j < p.length; j += 6) {
        const ox = p[j] * cs + p[j + 2] * sn;
        const oz = -p[j] * sn + p[j + 2] * cs;
        L.yaw(cl.x + ox, cl.y + p[j + 1], cl.z + oz, p[j + 3] * sc, p[j + 4] * sc, p[j + 5] * sc, cl.yaw, col);
      }
    }
  }

  private drawParticles() {
    const q = this.q;
    for (const p of this.parts) {
      if (!p.on) continue;
      const k = p.age / p.life;
      let sx = p.sx;
      let sy = p.sy;
      let sz = p.sz;
      if (p.mode === 0) {
        // kurva asap mengembang lembut lalu memudar halus
        const m = k < 0.22 ? 0.4 + Math.sin((k / 0.22) * (Math.PI * 0.5)) * 0.72 : 1.12 * Math.pow(1 - (k - 0.22) / 0.78, 0.85);
        sx *= m;
        sy *= m;
        sz *= m;
      } else if (p.mode === 1) {
        const m = 1 - k * k;
        sx *= m;
        sy *= m;
        sz *= m;
      } else if (p.mode === 2) {
        const m = k < 0.6 ? 1 : 1 - (k - 0.6) / 0.4;
        sx *= m;
        sz *= m;
      } else {
        sz *= 1 - k;
      }
      if (p.rot !== 0) q.setFromEuler(this.e.set(p.rot, p.yaw, p.rot * 0.7, 'YXZ'));
      else q.set(0, Math.sin(p.yaw / 2), 0, Math.cos(p.yaw / 2));
      (p.glow ? this.glow : this.lit).add(p.x, p.y, p.z, sx, sy, sz, q, p.r, p.gr, p.b);
    }
  }

  // ───────────────────────────── mobil & kamera ─────────────────────────────

  private updateRig(dt: number) {
    const c = this.car;
    const rig = this.rig;
    const t = this.time;
    if (this.state === 'falling' || this.state === 'over') {
      rig.group.position.set(c.x, c.y, c.z);
      for (const f of rig.flames) f.visible = false;
      return;
    }

    this.visTh += angDiff(c.th, this.visTh) * Math.min(1, dt * 32);
    // begitu pencet (pre-hook) langsung mulai lean-in lembut agar tidak terasa telat,
    // lalu masuk penuh dengan spring halus dan empuk saat tali menegang!
    const target = c.hook ? c.hook.turn * (c.taut ? 0.74 : 0.34) : 0;
    this.driftV += ((target - this.drift) * 185 - this.driftV * 13.5) * dt;
    this.drift += this.driftV * dt;
    // squash & stretch
    this.sqV += (-this.sq * 340 - this.sqV * 14) * dt;
    this.sq += this.sqV * dt;
    const sq = clamp(this.sq, -0.36, 0.48);

    let slope = 0;
    if (this.state === 'playing') {
      slope = (this.track.heightAt(c.idx + 0.6) - this.track.heightAt(c.idx - 0.6)) / 1.2;
    }
    this.pitch += (clamp(-Math.atan(slope), -0.7, 0.9) - this.pitch) * Math.min(1, dt * 14);

    let bob = 0;
    let sy = 1 + sq;
    if (this.state === 'menu') {
      bob = Math.abs(Math.sin(t * 2.8)) * 0.08;
      sy += Math.sin(t * 5.6) * 0.03;
    } else if (!this.inGap) {
      bob = Math.sin(t * 42) * 0.015;
    }

    rig.group.position.set(c.x, c.y + bob, c.z);
    rig.group.rotation.set(0, this.visTh + this.drift, 0);
    rig.tilt.rotation.set(this.pitch, 0, this.drift * 0.36);
    rig.tilt.scale.set(1 - sq * 0.5, sy, 1 - sq * 0.5);

    // counter-steer roda depan + putaran semua roda
    for (const p of rig.frontPivots) p.rotation.y = -this.drift * 1.05;
    if (this.state === 'playing') this.wheelRot += (c.speed / 0.42) * dt;
    for (const w of rig.wheels) w.rotation.x = this.wheelRot;

    // api turbo knalpot saat boost / combo / drift kencang
    const showFlame = this.state === 'playing' && (this.boost > 0.12 || this.combo >= 2);
    for (const f of rig.flames) {
      f.visible = showFlame;
      if (showFlame) {
        const pulse = 0.8 + Math.sin(t * 55) * 0.3 + this.boost * 0.5;
        f.scale.set(1, 1, pulse);
      }
    }

    // sirene mobil polisi berkedip
    if (rig.sirens.length === 2) {
      const flip = Math.sin(t * 14) > 0;
      rig.sirens[0].scale.setScalar(flip ? 1.25 : 0.85);
      rig.sirens[1].scale.setScalar(flip ? 0.85 : 1.25);
    }
  }

  private updateCamera(rdt: number) {
    const c = this.car;
    const tr = this.track;
    const preset = camById(this.camId);
    let yawT = this.camYaw;
    let pitchT = preset.pitch;
    let distT = preset.dist;
    let lookT = preset.look;
    let kYaw = preset.kYaw;
    let helix = 0;

    if (this.state === 'menu') {
      this.menuAng += rdt * 0.55;
      yawT = c.th + Math.PI + Math.sin(this.menuAng) * 0.6;
      pitchT = 0.28;
      distT = 10.2;
      lookT = 0;
      kYaw = 2.6;
    } else if (this.state === 'playing') {
      const li = Math.min(tr.samples.length - 1, Math.round(c.idx) + 7);
      yawT = tr.samples[li].th + preset.yawOff + this.drift * preset.driftSwing;
      const a = tr.arcs[this.arcPtr];
      if (a && a.helix && c.idx > a.startI - 7) {
        yawT = a.th1 + preset.yawOff * 0.4;
        pitchT = Math.max(preset.pitch, 1.06);
        distT = Math.max(preset.dist + 5, 34.5);
        lookT = 0;
        kYaw = 1.9;
        helix = 1;
        this.helixArc = a;
      }
    } else {
      distT = Math.max(preset.dist * 0.85, 22);
    }
    if (this.aspect < 1) distT *= 1.14;

    const k = (r: number) => 1 - Math.exp(-r * rdt);
    const camRate = this.state === 'playing' && this.stateT < 0.9 ? 5.0 : 3.2;
    this.camYaw += angDiff(yawT, this.camYaw) * k(kYaw);
    this.camPitch += (pitchT - this.camPitch) * k(camRate);
    this.camDist += (distT - this.camDist) * k(camRate);
    this.camLook += (lookT - this.camLook) * k(camRate);
    this.helixMix += (helix - this.helixMix) * k(3.2);

    const fx = Math.sin(this.camYaw);
    const fz = Math.cos(this.camYaw);
    if (this.state === 'menu' || this.state === 'playing') {
      let tx = c.x + fx * this.camLook;
      let tz = c.z + fz * this.camLook;
      const h = this.helixArc;
      if (h && this.helixMix > 0.001) {
        const m = this.helixMix * 0.5;
        tx += (h.cx - c.x) * m;
        tz += (h.cz - c.z) * m;
      }
      const kp = k(this.state === 'menu' ? 6 : 15);
      this.camT.x += (tx - this.camT.x) * kp;
      this.camT.z += (tz - this.camT.z) * kp;
      this.camT.y += (c.y + (this.state === 'menu' ? 1.25 : 0.8) - this.camT.y) * k(7.5);
    }

    const hd = Math.cos(this.camPitch) * this.camDist;
    const vd = Math.sin(this.camPitch) * this.camDist;
    const sh = this.shake * 1.1;
    this.camera.position.set(
      this.camT.x - fx * hd + rnd(-sh, sh),
      this.camT.y + vd + rnd(-sh, sh),
      this.camT.z - fz * hd + rnd(-sh, sh),
    );
    this.camera.lookAt(this.camT);

    const base = (this.aspect < 1 ? 52 + (1 - this.aspect) * 26 : 52) + (this.state === 'playing' ? preset.fovAdd : 0);
    const speedFov = this.state === 'playing' ? Math.max(0, (c.speed - 19) * 0.32) : 0;
    const fov = base + this.fovKick * 6.5 + this.boost * 4 + speedFov;
    if (Math.abs(fov - this.camera.fov) > 0.01) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }

    this.sun.position.set(this.camT.x - 15, this.camT.y + 34, this.camT.z - 10);
    this.sun.target.position.copy(this.camT);
    this.sun.target.updateMatrixWorld();
  }
}
