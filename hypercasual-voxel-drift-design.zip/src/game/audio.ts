/**
 * SFX sintetis (WebAudio) — mesin sport mini ber-karakter, decit ban drift dual-filter,
 * tarikan tali sling yang snappy, whoosh boost, & chime PERFECT pentatonik.
 */
const PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24];

type Ctor = typeof AudioContext;

export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;

  // mesin: sub-bass + dual detuned saw + harmonic + turbo whine
  private engGain: GainNode | null = null;
  private engSub: OscillatorNode | null = null;
  private engA: OscillatorNode | null = null;
  private engB: OscillatorNode | null = null;
  private engFilter: BiquadFilterNode | null = null;
  private turboGain: GainNode | null = null;
  private turboOsc: OscillatorNode | null = null;

  // decit drift: dual resonant bandpass + LFO bergetar seperti ban selip di aspal
  private driftGain: GainNode | null = null;
  private driftF1: BiquadFilterNode | null = null;
  private driftF2: BiquadFilterNode | null = null;

  // angin kecepatan
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;

  private noiseBuf: AudioBuffer | null = null;
  private muted = false;

  unlock() {
    if (!this.ctx) {
      const w = window as unknown as { AudioContext?: Ctor; webkitAudioContext?: Ctor };
      const AC = w.AudioContext ?? w.webkitAudioContext;
      if (!AC) return;
      try {
        this.ctx = new AC();
      } catch {
        return;
      }
      const ctx = this.ctx;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -12;
      comp.ratio.value = 4;

      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(comp).connect(ctx.destination);

      // noise buffer untuk ban, angin, & impact
      const len = ctx.sampleRate * 2;
      this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;

      // ── MESIN SPORT MINI ──
      this.engFilter = ctx.createBiquadFilter();
      this.engFilter.type = 'lowpass';
      this.engFilter.frequency.value = 650;
      this.engFilter.Q.value = 2.4;

      this.engGain = ctx.createGain();
      this.engGain.gain.value = 0;

      this.engSub = ctx.createOscillator();
      this.engSub.type = 'triangle';
      this.engA = ctx.createOscillator();
      this.engA.type = 'sawtooth';
      this.engB = ctx.createOscillator();
      this.engB.type = 'sawtooth';

      const subG = ctx.createGain();
      subG.gain.value = 0.6;
      const mainG = ctx.createGain();
      mainG.gain.value = 0.28;

      this.engSub.connect(subG).connect(this.engFilter);
      this.engA.connect(mainG).connect(this.engFilter);
      this.engB.connect(mainG);
      this.engFilter.connect(this.engGain).connect(this.master);

      this.engSub.start();
      this.engA.start();
      this.engB.start();

      // turbo spool whine halus
      this.turboOsc = ctx.createOscillator();
      this.turboOsc.type = 'sine';
      this.turboGain = ctx.createGain();
      this.turboGain.gain.value = 0;
      this.turboOsc.connect(this.turboGain).connect(this.master);
      this.turboOsc.start();

      // ── DECIT BAN DRIFT (dual resonant squeal) ──
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuf;
      src.loop = true;

      this.driftF1 = ctx.createBiquadFilter();
      this.driftF1.type = 'bandpass';
      this.driftF1.frequency.value = 1480;
      this.driftF1.Q.value = 5.5;

      this.driftF2 = ctx.createBiquadFilter();
      this.driftF2.type = 'bandpass';
      this.driftF2.frequency.value = 2580;
      this.driftF2.Q.value = 7.0;

      const d1G = ctx.createGain();
      d1G.gain.value = 0.7;
      const d2G = ctx.createGain();
      d2G.gain.value = 0.45;

      this.driftGain = ctx.createGain();
      this.driftGain.gain.value = 0;

      // modulasi getaran ban halus
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 26;
      const lfoG = ctx.createGain();
      lfoG.gain.value = 95;
      lfo.connect(lfoG);
      lfoG.connect(this.driftF1.frequency);
      lfoG.connect(this.driftF2.frequency);
      lfo.start();

      src.connect(this.driftF1).connect(d1G).connect(this.driftGain);
      src.connect(this.driftF2).connect(d2G).connect(this.driftGain);
      this.driftGain.connect(this.master);
      src.start();

      // ── ANGIN KECEPATAN ──
      const wSrc = ctx.createBufferSource();
      wSrc.buffer = this.noiseBuf;
      wSrc.loop = true;
      this.windFilter = ctx.createBiquadFilter();
      this.windFilter.type = 'bandpass';
      this.windFilter.frequency.value = 520;
      this.windFilter.Q.value = 0.7;
      this.windGain = ctx.createGain();
      this.windGain.gain.value = 0;
      wSrc.connect(this.windFilter).connect(this.windGain).connect(this.master);
      wSrc.start();
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx && this.master) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.03);
    }
  }

  engine(on: boolean, speed: number, boost: number, drifting = false) {
    const ctx = this.ctx;
    if (!ctx || !this.engGain || !this.engSub || !this.engA || !this.engB || !this.engFilter) return;
    const t = ctx.currentTime;
    const rpm = 58 + speed * 2.5 + boost * 28 + (drifting ? 16 : 0);
    this.engSub.frequency.setTargetAtTime(rpm * 0.5, t, 0.05);
    this.engA.frequency.setTargetAtTime(rpm, t, 0.05);
    this.engB.frequency.setTargetAtTime(rpm * 1.014, t, 0.05);
    this.engFilter.frequency.setTargetAtTime(480 + speed * 24 + boost * 700 + (drifting ? 340 : 0), t, 0.05);
    this.engGain.gain.setTargetAtTime(on ? 0.14 + boost * 0.04 : 0, t, 0.07);

    if (this.turboOsc && this.turboGain) {
      this.turboOsc.frequency.setTargetAtTime(1600 + speed * 45 + boost * 1300, t, 0.06);
      this.turboGain.gain.setTargetAtTime(on ? Math.max(0, boost * 0.028) : 0, t, 0.05);
    }

    if (this.windGain && this.windFilter) {
      const wg = on ? Math.max(0, (speed - 16) * 0.004 + boost * 0.055) : 0;
      this.windGain.gain.setTargetAtTime(Math.min(0.11, wg), t, 0.08);
      this.windFilter.frequency.setTargetAtTime(420 + speed * 22 + boost * 500, t, 0.08);
    }
  }

  drift(on: boolean, speed: number) {
    const ctx = this.ctx;
    if (!ctx || !this.driftGain || !this.driftF1 || !this.driftF2) return;
    const t = ctx.currentTime;
    this.driftGain.gain.setTargetAtTime(on ? 0.16 : 0, t, on ? 0.025 : 0.06);
    this.driftF1.frequency.setTargetAtTime(1250 + speed * 28, t, 0.04);
    this.driftF2.frequency.setTargetAtTime(2200 + speed * 42, t, 0.04);
  }

  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0) {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted) return;
    const t = ctx.currentTime + delay;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  private burst(dur: number, vol: number, freq: number, q: number, type: BiquadFilterType = 'bandpass', delay = 0, freqEnd?: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master || !this.noiseBuf || this.muted) return;
    const t = ctx.currentTime + delay;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd !== undefined) f.frequency.exponentialRampToValueAtTime(Math.max(40, freqEnd), t + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.03);
  }

  private note(semi: number) {
    return 523.25 * Math.pow(2, semi / 12);
  }

  click() {
    this.tone('triangle', 680, 960, 0.06, 0.14);
  }
  go() {
    // start balap: chord C-E-G-C cepat + deru awal
    this.tone('triangle', 392, 392, 0.09, 0.16);
    this.tone('triangle', 523.25, 523.25, 0.09, 0.16, 0.07);
    this.tone('triangle', 783.99, 783.99, 0.2, 0.2, 0.14);
    this.tone('sine', 160, 90, 0.14, 0.18, 0.14);
  }
  hook() {
    // thwip-clack kait tali sling
    this.tone('sine', 420, 1280, 0.065, 0.14);
    this.burst(0.05, 0.09, 3200, 1.8);
  }
  grip() {
    // snap tali menegang + punch grip ban
    this.tone('triangle', 260, 140, 0.07, 0.15);
    this.burst(0.09, 0.17, 2400, 1.5, 'bandpass', 0, 1400);
  }
  release() {
    // whoosh turbo + pop ringan saat dilepas
    this.tone('sine', 820, 420, 0.085, 0.12);
    this.burst(0.16, 0.13, 1800, 0.9, 'bandpass', 0, 520);
  }
  pass() {
    this.tone('triangle', 587, 659, 0.08, 0.1);
  }
  good() {
    this.tone('triangle', 659, 659, 0.1, 0.15);
    this.tone('triangle', 880, 880, 0.15, 0.14, 0.055);
  }
  perfect(combo: number) {
    const i = Math.min(PENTA.length - 4, Math.max(0, combo - 1));
    // punch bass + triad + kilau nada tinggi
    this.tone('sine', 145, 52, 0.13, 0.22);
    this.tone('triangle', this.note(PENTA[i]), this.note(PENTA[i]), 0.14, 0.18);
    this.tone('triangle', this.note(PENTA[i + 2]), this.note(PENTA[i + 2]), 0.2, 0.17, 0.05);
    this.tone('triangle', this.note(PENTA[i + 3]), this.note(PENTA[i + 3]), 0.24, 0.14, 0.1);
    this.tone('sine', this.note(PENTA[i] + 24), this.note(PENTA[i] + 24), 0.3, 0.08, 0.08);
    this.burst(0.18, 0.07, 6500, 0.8, 'highpass');
  }
  gem(streak: number) {
    const f = 1046.5 * Math.pow(2, Math.min(streak, 10) / 12);
    this.tone('sine', f, f * 1.5, 0.09, 0.12);
    this.tone('triangle', f * 2, f * 2, 0.11, 0.06, 0.03);
  }
  near() {
    this.tone('sawtooth', 320, 980, 0.14, 0.09);
    this.burst(0.15, 0.11, 4600, 2.2);
  }
  jump() {
    this.tone('sine', 240, 820, 0.28, 0.15);
    this.burst(0.18, 0.08, 1200, 0.8, 'bandpass', 0, 2800);
  }
  land() {
    this.tone('sine', 165, 48, 0.22, 0.34);
    this.tone('triangle', 220, 320, 0.08, 0.1, 0.04); // boing suspensi imut
    this.burst(0.13, 0.14, 480, 0.6, 'lowpass');
  }
  stage() {
    [0, 4, 7, 12].forEach((s, k) => this.tone('triangle', this.note(s), this.note(s), 0.2, 0.16, k * 0.07));
  }
  crash() {
    this.burst(0.55, 0.36, 680, 0.5, 'lowpass', 0, 140);
    this.tone('sawtooth', 460, 55, 0.55, 0.16);
    this.tone('sine', 720, 85, 0.85, 0.12, 0.08);
  }
  buy() {
    [0, 4, 7, 12, 16].forEach((s, k) => this.tone('triangle', this.note(s), this.note(s), 0.18, 0.16, k * 0.055));
  }
  deny() {
    this.tone('square', 196, 145, 0.14, 0.1);
  }
}
