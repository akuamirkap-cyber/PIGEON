// @ts-nocheck
import { useCallback, useEffect, useRef, useState } from 'react'
import { createEngine } from './engine'
import { audio } from './audio'
import { LIVERIES } from './ships'
import { getVehicleStats, SKINS } from './vehicles'
import SettingsPanel from './SettingsPanel'
import { CLASS_INFO, DEFAULTS, PRESETS, loadSettings, saveSettings } from './settings'

const fmt = (t: number) => {
  if (!t || !isFinite(t)) return '--:--.-'
  const m = Math.floor(t / 60)
  const s = t - m * 60
  return `${m}:${s < 10 ? '0' : ''}${s.toFixed(1)}`
}
const ordinal = (n: number) => `${n}${n === 1 ? 'ST' : n === 2 ? 'ND' : n === 3 ? 'RD' : 'TH'}`
const accent = (i: number) => LIVERIES[i % LIVERIES.length].accent
const PLANET_LIST = [['forest', 'Hutan', '#4cd05a'], ['desert', 'Gurun', '#f0a050'], ['ice', 'Es', '#8cc8ff'], ['lava', 'Lava', '#ff6a2a']]
const ARENA_TEXT = {
  forest: 'Jelajahi rimba raya sinematik: lembah sungai jernih & jeram air terjun, pohon raksasa & bunga tropis, pegunungan hutan awan, pemandu rute hologram sci-fi, serta tekan N untuk terbang bebas.',
  desert: 'Melaju menembus Kanyon Batu Merah monumental: lengkungan tebing alami raksasa, menara hoodoo & mesa bertingkat, sungai oasis pirus berpalem, kaktus saguaro & obelisk kuno.',
  ice: 'Terbang di Fjord Kanyon Gletser Safir: jembatan es bertirai stalaktit, gugusan kristal bercahaya, sungai kaca beku retak, cemara salju, dan cahaya Aurora Borealis menari di langit.',
  lava: 'Taklukkan Kaldera Kanyon Obsidian: sungai & air terjun magma cair membara, lengkungan batu berurat api, kolom basalt heksagonal, serta kepulan kawah vulkanik.',
}

const EMPTY = {
  state: 'demo', count: 3, speed: 0, speedRatio: 0, lap: 0, laps: 3, rank: 1, total: 1, time: 0, lapTime: 0, best: 0, lastLap: 0,
  shield: 100, shieldMax: 100, energy: 0.5, boost: false, turbo: false, wrecked: false, scrape: 0, finished: false, board: [], results: [],
  camMode: 'chase', class: 'Venom', top: 140, gap: 0,
}

export default function Race() {
  const [settings, setSettings] = useState(loadSettings)
  const [h, setH] = useState(EMPTY)
  const [panelOpen, setPanelOpen] = useState(false)
  const [toast, setToast] = useState(null)
  const [fingers, setFingers] = useState(false)
  const [showHint, setShowHint] = useState(true)
  const [showPreview, setShowPreview] = useState(false)
  const [tourMode, setTourMode] = useState(null)
  const mountRef = useRef(null)
  const engRef = useRef(null)
  const linesRef = useRef(null)
  const miniRef = useRef(null)
  const tourMapRef = useRef(null)
  const settingsRef = useRef(settings)
  const toastTimer = useRef(0)
  const hintTimer = useRef(0)
  settingsRef.current = settings

  const say = useCallback((text, color = '#00e5ff', ms = 1500, size = 'lg') => {
    setToast({ text, color, size, id: Math.random() })
    window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToast(null), ms)
  }, [])

  const patch = useCallback((p) => {
    setSettings((s) => {
      const next = { ...s, ...p }
      saveSettings(next)
      return next
    })
  }, [])

  // ── engine
  useEffect(() => {
    if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) setFingers(true)
    const eng = createEngine(mountRef.current, settingsRef.current)
    engRef.current = eng
    eng.onCamera = (m) => patch({ camMode: m })
    let raf = 0
    let sample = 0
    let last = performance.now()
    const loop = (now) => {
      raf = requestAnimationFrame(loop)
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      const hud = eng.hud
      for (const e of eng.drainEvents()) {
        if (e.type === 'go') say('GO!', '#7dff6a', 900, 'xl')
        else if (e.type === 'pad') say('BOOST', '#ffd23c', 700, 'md')
        else if (e.type === 'drift') say('DRIFT BOOST', '#52ff7a', 900, 'md')
        else if (e.type === 'launch') say('PERFECT START', '#ffd23c', 1500, 'md')
        else if (e.type === 'lap') say(`LAP ${e.n} · ${fmt(e.v)}${e.best ? ' · TERBAIK' : ''}`, e.best ? '#7dff6a' : '#00e5ff', 2200, 'md')
        else if (e.type === 'final') say('FINAL LAP', '#ff3b8d', 2200, 'xl')
        else if (e.type === 'wreck') say('HANCUR', '#ff4a3a', 2000, 'xl')
        else if (e.type === 'flyOn') say('✈ MODE TERBANG', '#38f8ff', 1300, 'md')
        else if (e.type === 'flyOff') say('MENDARAT', '#7dffb2', 950, 'md')
      }
      // speed lines
      const cv = linesRef.current
      if (cv) {
        const w = cv.clientWidth
        const hh = cv.clientHeight
        const dpr = Math.min(2, window.devicePixelRatio || 1)
        if (cv.width !== Math.round(w * dpr)) {
          cv.width = Math.round(w * dpr)
          cv.height = Math.round(hh * dpr)
        }
        const g = cv.getContext('2d')
        g.setTransform(dpr, 0, 0, dpr, 0, 0)
        g.clearRect(0, 0, w, hh)
        const k = Math.max(0, hud.speedRatio - 0.5) * 1.6 + (hud.boost || hud.turbo ? 0.6 : 0)
        if (settingsRef.current.speedLines && k > 0.05 && hud.state !== 'demo' && !hud.wrecked && hud.camMode !== 'cockpit') {
          const R = Math.hypot(w, hh) / 2
          const n = Math.floor(14 + 50 * Math.min(1, k))
          g.lineWidth = 1.5
          for (let i = 0; i < n; i++) {
            const a = Math.random() * 6.283
            const r0 = R * (0.38 + Math.random() * 0.5)
            const r1 = r0 + R * (0.06 + 0.3 * Math.min(1, k) * Math.random())
            g.strokeStyle = `rgba(190,235,255,${(0.04 + 0.28 * Math.min(1, k) * Math.random()).toFixed(3)})`
            g.beginPath()
            g.moveTo(w / 2 + Math.cos(a) * r0, hh / 2 + Math.sin(a) * r0)
            g.lineTo(w / 2 + Math.cos(a) * r1, hh / 2 + Math.sin(a) * r1)
            g.stroke()
          }
        }
        if (hud.scrape > 0.3) {
          const grd = g.createRadialGradient(w / 2, hh / 2, Math.min(w, hh) * 0.35, w / 2, hh / 2, Math.max(w, hh) * 0.7)
          grd.addColorStop(0, 'rgba(255,140,40,0)')
          grd.addColorStop(1, `rgba(255,120,30,${0.22 * hud.scrape})`)
          g.fillStyle = grd
          g.fillRect(0, 0, w, hh)
        }
      }
      // sci-fi topographical mini map
      const paintMap = (canvas, size) => {
        if (!canvas || !hud.mini.length) return
        const dpr = Math.min(2, window.devicePixelRatio || 1)
        if (canvas.width !== size * dpr) {
          canvas.width = size * dpr
          canvas.height = size * dpr
        }
        const g = canvas.getContext('2d')
        g.setTransform(dpr, 0, 0, dpr, 0, 0)
        g.clearRect(0, 0, size, size)
        const pad = Math.round(size * 0.085)
        const S = size - pad * 2
        const isForestMap = hud.mode === 'arena' && hud.planet === 'forest'
        g.lineJoin = 'round'
        g.lineCap = 'round'

        if (hud.mode === 'arena' && hud.peaks?.length) {
          const pkCore = isForestMap
            ? 'rgba(84,205,116,0.4)'
            : hud.planet === 'desert'
              ? 'rgba(238,136,78,0.38)'
              : hud.planet === 'ice'
                ? 'rgba(135,208,255,0.38)'
                : 'rgba(255,96,42,0.4)'
          for (const [px, pz, pr] of hud.peaks) {
            const cx = pad + px * S, cz = pad + pz * S
            const r = Math.max(5, Math.min(size * 0.24, pr * S * 0.85))
            const grd = g.createRadialGradient(cx, cz, 1, cx, cz, r)
            grd.addColorStop(0, pkCore)
            grd.addColorStop(1, 'rgba(0,0,0,0)')
            g.fillStyle = grd
            g.beginPath()
            g.arc(cx, cz, r, 0, 6.283)
            g.fill()
          }
        }

        if (hud.mode === 'arena') {
          const streamCol = hud.planet === 'lava'
            ? 'rgba(255,118,28,0.78)'
            : hud.planet === 'ice'
              ? 'rgba(126,220,255,0.72)'
              : 'rgba(42,216,208,0.7)'
          if (hud.lagoons?.length) {
            for (const [lx, lz, lr] of hud.lagoons) {
              g.fillStyle = streamCol
              g.beginPath()
              g.arc(pad + lx * S, pad + lz * S, Math.max(3, lr * S * 1.15), 0, 6.283)
              g.fill()
            }
          }
          if (hud.rivers?.length) {
            for (const rv of hud.rivers) {
              g.lineWidth = rv.kind === 'rapid' ? 2.4 : rv.kind === 'tributary' ? 1.2 : 1.8
              g.strokeStyle = streamCol
              g.beginPath()
              rv.pts.forEach(([x, z], i) => (i ? g.lineTo(pad + x * S, pad + z * S) : g.moveTo(pad + x * S, pad + z * S)))
              g.stroke()
            }
          }
        }

        g.lineWidth = 6.5
        g.strokeStyle = 'rgba(6,16,32,0.88)'
        g.beginPath()
        hud.mini.forEach(([x, z], i) => (i ? g.lineTo(pad + x * S, pad + z * S) : g.moveTo(pad + x * S, pad + z * S)))
        g.closePath()
        g.stroke()
        g.lineWidth = 2.8
        g.strokeStyle = '#1ef2ff'
        g.stroke()

        if (hud.mode === 'arena') {
          g.lineWidth = 1.9
          g.strokeStyle = 'rgba(255,105,235,0.82)'
          g.setLineDash([3, 2.5])
          for (const cut of hud.cuts) {
            g.beginPath()
            cut.forEach(([x, z], i) => (i ? g.lineTo(pad + x * S, pad + z * S) : g.moveTo(pad + x * S, pad + z * S)))
            g.stroke()
          }
          g.setLineDash([])
          hud.gatePts.forEach(([x, z], i) => {
            const active = i === hud.nextGate
            g.fillStyle = active ? '#38ff9a' : '#ffffff'
            const s = active ? 6 : 4.4
            g.fillRect(pad + x * S - s / 2, pad + z * S - s / 2, s, s)
          })
        }
        const [sx, sz] = hud.mini[0]
        g.fillStyle = '#fff'
        g.fillRect(pad + sx * S - 3, pad + sz * S - 3, 6, 6)
        for (const [x, z, id, you, dead] of hud.minis) {
          if (you) continue
          g.fillStyle = dead ? '#555' : accent(id)
          g.beginPath()
          g.arc(pad + x * S, pad + z * S, 2.8, 0, 6.283)
          g.fill()
        }
        for (const [x, z, , you] of hud.minis) {
          if (!you) continue
          g.fillStyle = hud.flying ? '#38f8ff' : '#fff'
          g.strokeStyle = hud.flying ? '#ffffff' : '#ff2a8a'
          g.lineWidth = 2
          g.beginPath()
          g.arc(pad + x * S, pad + z * S, 4.8, 0, 6.283)
          g.fill()
          g.stroke()
        }
      }
      paintMap(miniRef.current, 156)
      paintMap(tourMapRef.current, 168)
      sample += dt
      if (sample > 0.07) {
        sample = 0
        setH({ ...hud })
      }
    }
    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      window.clearTimeout(toastTimer.current)
      window.clearTimeout(hintTimer.current)
      eng.dispose()
      engRef.current = null
    }
  }, [])

  useEffect(() => {
    engRef.current?.applySettings(settings)
  }, [settings])

  useEffect(() => {
    audio.setVolumes(settings.volMaster, settings.volMusic, settings.volSfx, !!settings.muted)
  }, [settings.volMaster, settings.volMusic, settings.volSfx, settings.muted])

  useEffect(() => {
    const go = () => audio.init()
    window.addEventListener('pointerdown', go)
    window.addEventListener('keydown', go)
    return () => {
      window.removeEventListener('pointerdown', go)
      window.removeEventListener('keydown', go)
    }
  }, [])

  const racing = h.state === 'racing' || h.state === 'countdown'
  // opening the panel pauses a race in progress
  useEffect(() => {
    engRef.current?.setPaused(panelOpen && racing)
  }, [panelOpen, racing])

  const startRace = useCallback(() => {
    audio.init()
    audio.ui('start')
    setPanelOpen(false)
    setShowPreview(false)
    setTourMode(null)
    engRef.current?.setGaragePreview(false)
    engRef.current?.setForestTour(null)
    engRef.current?.startRace()
    setShowHint(true)
    window.clearTimeout(hintTimer.current)
    hintTimer.current = window.setTimeout(() => setShowHint(false), 14000)
  }, [])
  const toMenu = useCallback(() => {
    audio.ui('back')
    engRef.current?.toMenu()
  }, [])

  useEffect(() => {
    const onKey = (e) => {
      if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return
      if (e.code === 'Escape' && (showPreview || tourMode)) {
        e.preventDefault()
        engRef.current?.setGaragePreview(false)
        engRef.current?.setForestTour(null)
        setShowPreview(false)
        setTourMode(null)
      } else if (e.code === 'Escape' || e.code === 'KeyP') {
        e.preventDefault()
        setPanelOpen((o) => !o)
      } else if (e.code === 'KeyM') patch({ muted: !settingsRef.current.muted })
      else if (e.code === 'KeyV') {
        const ids = SKINS.map((k) => k.id)
        patch({ skin: ids[(Math.max(0, ids.indexOf(settingsRef.current.skin)) + 1) % ids.length] })
      } else if (e.code === 'KeyF') patch({ look: settingsRef.current.look === 'soft' ? 'pixel' : 'soft' })
      else if (e.code === 'Enter') {
        const st = engRef.current?.hud.state
        if (st === 'demo' || st === 'finished') startRace()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [patch, startRace, showPreview, tourMode])

  const touchOn = settings.touchControls === 'on' || (settings.touchControls === 'auto' && fingers)
  const tb = (key) => ({
    onPointerDown: (e) => {
      e.preventDefault()
      try { e.currentTarget.setPointerCapture(e.pointerId) } catch { /* gone */ }
      engRef.current?.setTouch({ [key]: true })
    },
    onPointerUp: () => engRef.current?.setTouch({ [key]: false }),
    onPointerCancel: () => engRef.current?.setTouch({ [key]: false }),
    onLostPointerCapture: () => engRef.current?.setTouch({ [key]: false }),
    onContextMenu: (e) => e.preventDefault(),
  })

  const me = h.board.find((b) => b.isPlayer)
  const done = h.finished
  const speedPct = Math.min(1, h.speedRatio / 1.2)
  const hot = h.boost || h.turbo
  const shieldPct = Math.max(0, Math.min(1, h.shield / h.shieldMax))
  const panelCls = 'bg-[#060a1c]/70 backdrop-blur-sm border-l-2 border-cyan-300/70 shadow-lg'
  const vehicle = SKINS.find((skin) => skin.id === settings.skin) || SKINS[3]
  const vehicleStats = getVehicleStats(vehicle.id)

  return (
    <div className="relative h-screen w-full select-none overflow-hidden bg-black text-white" style={{ height: '100dvh', fontFamily: 'ui-sans-serif, system-ui, "Segoe UI", sans-serif' }}>
      <div ref={mountRef} className="absolute inset-0" />
      <canvas ref={linesRef} className="pointer-events-none absolute inset-0 h-full w-full" />

      {/* ── race HUD */}
      {racing || h.state === 'finished' ? (
        <div className="pointer-events-none absolute inset-0 z-10">
          {/* position + lap (the cockpit has its own screen for these) */}
          {h.camMode !== 'cockpit' && (
          <div className="absolute left-4 top-4 flex items-end gap-4">
            <div className={`${panelCls} px-4 py-2`} style={{ transform: 'skewX(-8deg)' }}>
              <div style={{ transform: 'skewX(8deg)' }}>
                <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-cyan-300">Posisi</div>
                <div className="flex items-baseline gap-1 italic">
                  <span className="text-6xl font-black leading-none text-white">{h.rank}</span>
                  <span className="text-xl font-bold text-white/60">/{h.total}</span>
                </div>
              </div>
            </div>
            <div className={`${panelCls} px-4 py-2`} style={{ transform: 'skewX(-8deg)' }}>
              <div style={{ transform: 'skewX(8deg)' }}>
                <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-cyan-300">Lap</div>
                <div className="text-3xl font-black italic leading-none">
                  {Math.max(1, h.lap)}
                  <span className="text-lg text-white/60">/{h.laps}</span>
                </div>
              </div>
            </div>
          </div>
          )}

          {/* timer */}
          <div className="absolute inset-x-0 top-3 flex justify-center">
            <div className={`${panelCls} border-l-0 border-b-2 px-5 py-1.5 text-center`} style={{ transform: 'skewX(-8deg)' }}>
              <div style={{ transform: 'skewX(8deg)' }}>
                <div className="text-2xl font-black italic tabular-nums leading-none">{fmt(h.time)}</div>
                <div className="mt-1 flex justify-center gap-4 text-[10px] uppercase tracking-widest text-white/60">
                  <span>Lap <b className="text-white">{fmt(h.lapTime)}</b></span>
                  <span>Terbaik <b className="text-white">{fmt(h.best)}</b></span>
                </div>
              </div>
            </div>
          </div>

          {/* arena: which way to the next gate */}
          {h.mode === 'arena' && h.state === 'racing' && !done && (
            <div className="absolute inset-x-0 top-[74px] flex justify-center">
              <div className="flex items-center gap-3 rounded bg-black/45 px-3 py-1 backdrop-blur-sm">
                <div style={{ transform: `rotate(${h.gateAngle}rad)` }} className="text-2xl leading-none text-emerald-300 drop-shadow-[0_0_8px_rgba(82,255,122,.9)]">▲</div>
                <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/90">
                  Gerbang {h.nextGate === 0 ? 'FINISH' : h.nextGate}/{h.gateCount - 1 || 1}
                  <span className="ml-2 text-emerald-300">{Math.round(h.gateDist)} m</span>
                </div>
              </div>
            </div>
          )}

          {/* board + map */}
          <div className="absolute right-4 top-4 flex w-56 flex-col items-end gap-2">
            {settings.showBoard && (
              <div className={`${panelCls} w-full border-l-0 border-r-2 px-3 py-2`}>
                <ol className="space-y-0.5 text-[11px]">
                  {h.board.map((b) => (
                    <li key={b.id} className={`flex items-center gap-1.5 ${b.isPlayer ? 'font-black text-cyan-300' : 'text-white/85'}`}>
                      <span className="w-4 text-right italic text-white/50">{b.rank}</span>
                      <span className="h-3 w-1 rounded-sm" style={{ background: accent(b.color) }} />
                      <span className="min-w-0 flex-1 truncate uppercase tracking-wide">{b.name}</span>
                      <span className="tabular-nums text-white/60">{b.rank === 1 ? (b.finished ? fmt(b.time) : 'LEAD') : b.finished ? fmt(b.time) : `+${b.gap.toFixed(1)}`}</span>
                    </li>
                  ))}
                </ol>
              </div>
            )}
            {settings.showMini && h.camMode !== 'cockpit' && <canvas ref={miniRef} style={{ width: 150, height: 150 }} className="rounded-full bg-[#060a1c]/55 shadow-lg" />}
          </div>

          {/* speed + shield (in the cockpit the dials and screens show it) */}
          {h.camMode !== 'cockpit' && (
          <div className="absolute bottom-5 left-1/2 w-[min(520px,90vw)] -translate-x-1/2" style={{ bottom: touchOn ? 110 : 20 }}>
            <div className="flex items-end justify-between">
              <div className="italic">
                <span className="text-7xl font-black leading-none tabular-nums" style={{ color: hot ? '#ffd23c' : '#fff', textShadow: hot ? '0 0 24px rgba(255,170,0,.8)' : '0 0 18px rgba(0,229,255,.5)' }}>
                  {h.speed}
                </span>
                <span className="ml-2 text-sm font-bold uppercase tracking-[0.3em] text-white/60">km/h</span>
              </div>
              <div className="flex flex-col items-end gap-1 pb-1 text-right text-[10px] font-bold uppercase tracking-[0.22em] text-white/55">
                {h.state === 'racing' && !done && (
                  <button
                    type="button"
                    onClick={() => engRef.current?.toggleFlight()}
                    className={`pointer-events-auto flex items-center gap-1.5 rounded border px-2.5 py-1 text-[10px] font-black uppercase tracking-[0.16em] transition ${
                      h.flying
                        ? 'border-cyan-300 bg-cyan-400/25 text-cyan-100 shadow-[0_0_16px_rgba(56,248,255,0.45)]'
                        : 'border-white/25 bg-black/50 text-cyan-200/85 hover:border-cyan-300/70 hover:bg-cyan-400/15'
                    }`}
                  >
                    <span>✈ {h.flying ? `TERBANG · ${h.alt}M` : 'TERBANG [N]'}</span>
                  </button>
                )}
                <div>
                  {h.class} · <span className="text-cyan-300">{h.camMode === 'chase' ? 'Belakang' : h.camMode === 'near' ? 'Rendah' : 'Kokpit'}</span>
                </div>
              </div>
            </div>
            {h.flying && !done && (
              <div className="mt-1 flex items-center justify-between rounded border border-cyan-300/40 bg-cyan-950/55 px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.18em] text-cyan-100">
                <span>✈ Mode Terbang Aktif · ALT {h.alt} m</span>
                <span className="text-cyan-300">Space/E Naik · Q Tukik · N Mendarat</span>
              </div>
            )}
            {(h.drift || 0) > 0.02 && (
              <div className="mt-1 flex items-center gap-2">
                <span className="text-[9px] font-black uppercase tracking-[0.3em]" style={{ color: h.drift >= 0.46 ? '#52ff7a' : '#ffb347' }}>Drift</span>
                <div className="h-1.5 flex-1 overflow-hidden border border-white/20 bg-black/50" style={{ transform: 'skewX(-25deg)' }}>
                  <div className="h-full" style={{ width: `${Math.min(1, h.drift) * 100}%`, background: h.drift >= 0.46 ? '#52ff7a' : '#ffb347' }} />
                </div>
              </div>
            )}
            <div className="mt-1.5 h-2.5 overflow-hidden border border-white/20 bg-black/50" style={{ transform: 'skewX(-25deg)' }}>
              <div className="h-full" style={{ width: `${speedPct * 100}%`, background: hot ? 'linear-gradient(90deg,#ff7a1a,#ffe14d)' : 'linear-gradient(90deg,#00e5ff,#7a5cff,#ff2a8a)' }} />
            </div>
            <div className="mt-2 grid grid-cols-2 gap-3">
              <div>
                <div className="mb-0.5 flex justify-between text-[9px] font-bold uppercase tracking-[0.25em] text-white/60">
                  <span>Perisai</span>
                  <span className="tabular-nums">{Math.ceil(h.shield)}</span>
                </div>
                <div className="h-2 overflow-hidden border border-white/20 bg-black/50" style={{ transform: 'skewX(-25deg)' }}>
                  <div className="h-full" style={{ width: `${shieldPct * 100}%`, background: shieldPct > 0.5 ? '#5dff7a' : shieldPct > 0.25 ? '#ffd23c' : '#ff4a3a' }} />
                </div>
              </div>
              <div>
                <div className="mb-0.5 flex justify-between text-[9px] font-bold uppercase tracking-[0.25em] text-white/60">
                  <span>Turbo (Shift)</span>
                  <span className="tabular-nums">{Math.round(h.energy * 100)}%</span>
                </div>
                <div className="h-2 overflow-hidden border border-white/20 bg-black/50" style={{ transform: 'skewX(-25deg)' }}>
                  <div className="h-full" style={{ width: `${h.energy * 100}%`, background: h.turbo ? '#ffd23c' : '#4cc9ff' }} />
                </div>
              </div>
            </div>
            {settings.showHint && showHint && h.state !== 'finished' && !touchOn && (
              <p className="mt-2.5 rounded bg-black/50 px-2.5 py-1 text-center text-[10px] uppercase tracking-[0.13em] text-white/85">
                {h.mode === 'arena'
                  ? 'W gas · A/D belok (tahan = DRIFT) · Shift turbo · N TERBANG (Space/E naik, Q tukik, N mendarat) · Ikuti pita hologram & pilar cahaya gerbang · C kamera · R reset'
                  : 'W gas · S rem · A/D belok · Q/E rem udara · Shift turbo · N TERBANG (Space/E naik, Q tukik) · C kamera · R reset'}
              </p>
            )}
          </div>
          )}

          {/* countdown */}
          {h.state === 'countdown' && (
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div key={h.count} className="animate-[cd_1s_ease-out_both] text-[min(34vw,300px)] font-black italic leading-none" style={{ color: '#fff', textShadow: '0 0 40px #00e5ff, 0 0 90px #ff2a8a' }}>
                {h.count}
              </div>
              <div className="mt-2 rounded bg-black/40 px-3 py-1 text-xs font-bold uppercase tracking-[0.3em] text-cyan-200">Tahan W saat angka terakhir untuk start sempurna</div>
            </div>
          )}

          {/* messages */}
          {toast && h.state !== 'countdown' && !done && (
            <div key={toast.id} className="absolute inset-x-0 top-[24%] flex justify-center">
              <div
                className={`animate-[pop_1.5s_ease-out_forwards] font-black italic uppercase tracking-[0.12em] ${toast.size === 'xl' ? 'text-6xl' : 'text-3xl'}`}
                style={{ color: toast.color, textShadow: `0 0 24px ${toast.color}, 0 3px 0 rgba(0,0,0,.6)` }}
              >
                {toast.text}
              </div>
            </div>
          )}

          {/* wrecked */}
          {h.wrecked && !done && (
            <div className="absolute inset-0 flex items-center justify-center bg-red-900/20">
              <div className="text-sm font-bold uppercase tracking-[0.4em] text-red-200">Pesawat dipulihkan…</div>
            </div>
          )}

          {/* finish banner */}
          {done && h.state !== 'finished' && (
            <div className="absolute inset-x-0 top-[26%] flex flex-col items-center">
              <div className="animate-[pop_2.8s_ease-out_forwards] text-7xl font-black italic" style={{ color: '#7dff6a', textShadow: '0 0 30px #7dff6a' }}>
                FINISH · {ordinal(me?.rank || h.rank)}
              </div>
            </div>
          )}
        </div>
      ) : null}

      {/* top-right buttons */}
      {!(h.state === 'demo' && (showPreview || tourMode)) && (
      <div className="absolute bottom-4 right-4 z-20 flex gap-2" style={{ bottom: touchOn && racing ? 'auto' : 16, top: touchOn && racing ? 12 : 'auto', right: touchOn && racing ? 'auto' : 16, left: touchOn && racing ? 12 : 'auto' }}>
        <button
          type="button"
          onClick={() => patch({ muted: !settings.muted })}
          className="rounded border border-white/25 bg-black/50 px-2.5 py-1.5 text-xs backdrop-blur hover:bg-white/15"
          title="Bisukan suara (M)"
        >
          {settings.muted ? '🔇' : '🔊'}
        </button>
        <button
          type="button"
          onClick={() => patch({ look: settings.look === 'soft' ? 'pixel' : 'soft' })}
          className="rounded border border-white/25 bg-black/50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.15em] backdrop-blur hover:bg-white/15"
          title="Ganti gaya gambar (F)"
        >
          ◐ {settings.look === 'soft' ? 'Lembut' : 'Pixel'}
        </button>
        <button
          type="button"
          onClick={() => setPanelOpen(true)}
          className="rounded border border-white/25 bg-black/50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.15em] backdrop-blur hover:bg-white/15"
        >
          ⚙ Atur
        </button>
        {racing && (
          <button
            type="button"
            onClick={toMenu}
            className="rounded border border-white/25 bg-black/50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.15em] backdrop-blur hover:bg-white/15"
          >
            ✕ Menu
          </button>
        )}
      </div>
      )}

      {/* touch controls (with N Flight Mode + Climb/Dive buttons!) */}
      {touchOn && racing && !done && (
        <div className="absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-4" style={{ touchAction: 'none' }}>
          <div className="flex flex-col gap-2">
            {h.flying && (
              <div className="flex gap-2">
                <button type="button" {...tb('climb')} className="h-12 flex-1 rounded-xl border border-cyan-300/70 bg-cyan-400/25 text-xs font-black uppercase active:bg-cyan-400/55" style={{ touchAction: 'none' }}>▲ Naik</button>
                <button type="button" {...tb('dive')} className="h-12 flex-1 rounded-xl border border-sky-300/60 bg-sky-400/20 text-xs font-black uppercase active:bg-sky-400/50" style={{ touchAction: 'none' }}>▼ Tukik</button>
              </div>
            )}
            <div className="flex gap-2.5">
              <button type="button" {...tb('left')} className="h-20 w-20 rounded-xl border border-cyan-300/50 bg-cyan-300/15 text-3xl active:bg-cyan-300/40" style={{ touchAction: 'none' }}>◀</button>
              <button type="button" {...tb('right')} className="h-20 w-20 rounded-xl border border-cyan-300/50 bg-cyan-300/15 text-3xl active:bg-cyan-300/40" style={{ touchAction: 'none' }}>▶</button>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <button
              type="button"
              onClick={() => engRef.current?.toggleFlight()}
              className={`h-12 rounded-xl border px-4 text-xs font-black uppercase tracking-wider ${h.flying ? 'border-cyan-200 bg-cyan-400/45 text-white' : 'border-cyan-300/60 bg-cyan-400/20 text-cyan-100'}`}
              style={{ touchAction: 'none' }}
            >
              ✈ {h.flying ? 'Mendarat (N)' : 'Terbang (N)'}
            </button>
            <div className="flex gap-2.5">
              <button type="button" {...tb('brake')} className="h-20 w-15 rounded-xl border border-white/30 bg-white/10 text-[11px] font-bold uppercase active:bg-white/30" style={{ touchAction: 'none' }}>Rem</button>
              <button type="button" {...tb('turbo')} className="h-20 w-16 rounded-xl border border-amber-300/60 bg-amber-400/20 text-[11px] font-bold uppercase active:bg-amber-400/50" style={{ touchAction: 'none' }}>Turbo</button>
              <button type="button" {...tb('gas')} className="h-20 w-20 rounded-xl border border-emerald-300/60 bg-emerald-400/25 text-sm font-black uppercase active:bg-emerald-400/55" style={{ touchAction: 'none' }}>Gas</button>
            </div>
          </div>
        </div>
      )}

      {/* ── results */}
      {h.state === 'finished' && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/55 p-4 backdrop-blur-[2px]">
          <div className="w-[min(560px,100%)] border border-cyan-300/30 bg-[#060a1c]/93 p-5 shadow-2xl">
            <div className="text-center">
              <div className="text-[11px] font-bold uppercase tracking-[0.4em] text-cyan-300">Hasil balapan</div>
              <div className="mt-1 text-5xl font-black italic" style={{ color: (me?.rank || 9) === 1 ? '#ffd23c' : '#fff', textShadow: '0 0 24px rgba(0,229,255,.5)' }}>
                {(me?.rank || h.rank) === 1 ? 'JUARA 1!' : `POSISI ${me?.rank || h.rank}`}
              </div>
            </div>
            <div className="mt-4 max-h-[44vh] overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="text-[10px] uppercase tracking-widest text-white/45">
                  <tr><th className="py-1 text-left">#</th><th className="text-left">Pilot</th><th className="text-right">Waktu</th><th className="text-right">Lap terbaik</th></tr>
                </thead>
                <tbody>
                  {h.results.map((r) => (
                    <tr key={r.id} className={r.isPlayer ? 'bg-cyan-300/15 font-black text-cyan-200' : 'text-white/85'}>
                      <td className="py-1 pl-1 italic">{r.rank}</td>
                      <td><span className="mr-2 inline-block h-2.5 w-2.5 rounded-sm align-middle" style={{ background: accent(r.color) }} />{r.name}</td>
                      <td className="text-right tabular-nums">{r.finished ? fmt(r.time) : 'DNF'}</td>
                      <td className="pr-1 text-right tabular-nums">{fmt(r.best)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button type="button" onClick={startRace} className="bg-cyan-400 py-3 text-sm font-black uppercase italic tracking-[0.25em] text-black hover:brightness-110 active:scale-95">Balap lagi (Enter)</button>
              <button type="button" onClick={toMenu} className="border border-white/30 py-3 text-sm font-bold uppercase tracking-[0.2em] hover:bg-white/10">Menu</button>
            </div>
            <button type="button" onClick={() => setPanelOpen(true)} className="mt-2 w-full border border-white/15 py-2 text-[11px] uppercase tracking-[0.18em] text-white/70 hover:bg-white/10">⚙ Ubah kelas / bot / lintasan</button>
          </div>
        </div>
      )}

      {/* ── menu */}
      {h.state === 'demo' && !showPreview && !tourMode && (
        <div className="absolute inset-y-0 left-0 z-20 flex w-[min(520px,100%)] flex-col bg-gradient-to-r from-[#040912]/98 via-[#07131d]/92 to-[#07131d]/70 shadow-[20px_0_80px_rgba(2,8,15,.28)]">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-6 pb-5 pt-6 sm:px-9" data-testid="garage-menu">
            <div className="mx-auto max-w-[440px]">
              <div className="text-[10px] font-bold uppercase tracking-[0.36em] text-cyan-300/80">Balap anti-gravity / Garasi</div>
              <h1 className="mt-1 whitespace-nowrap text-4xl font-black italic tracking-tight text-white sm:text-5xl" style={{ textShadow: '0 0 28px rgba(0,229,255,.25)' }}>
                HOVER <span className="text-cyan-300">RUSH</span>
              </h1>
              <p className="mt-2 text-xs leading-relaxed text-white/60">{settings.mode === 'arena' ? `${ARENA_TEXT[settings.arenaPlanet] || ARENA_TEXT.forest} Lawan ${settings.bots} pilot AI.` : `Balapan di lintasan melayang bersama ${settings.bots} pilot AI.`}</p>

              <section className="mt-5" aria-labelledby="vehicle-heading">
                <div className="flex items-center justify-between">
                  <h2 id="vehicle-heading" className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/55">Pilih motor &amp; pilot</h2>
                  <button type="button" onClick={() => { engRef.current?.setGaragePreview(true); setShowPreview(true) }} className="text-[10px] font-bold uppercase tracking-wider text-cyan-300 transition hover:text-white">Lihat 3D</button>
                </div>
                <div className="mt-2 grid grid-cols-3 gap-1.5">
                  {SKINS.filter((skin) => skin.group === 'bike').map((skin) => {
                    const on = settings.skin === skin.id
                    return (
                      <button key={skin.id} type="button" aria-pressed={on} onClick={() => { patch({ skin: skin.id }); audio.ui('click') }} className={`min-h-[68px] border px-2.5 py-2 text-left transition duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300 ${on ? 'border-cyan-300/80 bg-cyan-300/15 shadow-[inset_0_-2px_0_#67e8f9]' : 'border-white/15 bg-white/[0.04] hover:border-white/40 hover:bg-white/10'}`}>
                        <span className={`block text-[11px] font-black uppercase leading-tight ${on ? 'text-cyan-200' : 'text-white'}`}>{skin.name}</span>
                        <span className="mt-1 block text-[10px] leading-tight text-white/55">{skin.desc}</span>
                      </button>
                    )
                  })}
                </div>
                <div className="mt-1.5 grid grid-cols-4 gap-1.5" aria-label="Kendaraan lain">
                  {SKINS.filter((skin) => skin.group === 'craft').map((skin) => {
                    const on = settings.skin === skin.id
                    return (
                      <button key={skin.id} type="button" aria-pressed={on} onClick={() => { patch({ skin: skin.id }); audio.ui('click') }} className={`min-h-9 border px-1 py-1.5 text-center text-[10px] font-bold uppercase transition duration-200 ${on ? 'border-cyan-300/80 bg-cyan-300/15 text-cyan-200' : 'border-white/10 bg-white/[0.03] text-white/65 hover:border-white/40 hover:text-white'}`}>
                        {skin.name}
                      </button>
                    )
                  })}
                </div>
                <p className="mt-2 min-h-4 text-[11px] leading-snug text-white/60" aria-live="polite">
                  {vehicle.id === 'swoop' ? 'Swoop: 18% lebih cepat, akselerasi lebih kuat, tetapi lebih licin dan rentan saat menabrak.' : vehicle.desc}
                </p>
              </section>

              <section className="mt-4" aria-labelledby="mode-heading">
                <h2 id="mode-heading" className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/55">Pilih mode</h2>
                <div className="mt-2 grid grid-cols-2 gap-1.5">
                  {[['arena', 'Arena', 'Hutan & dunia bercabang'], ['track', 'Sirkuit', 'Lintasan melayang']].map(([k, title, desc]) => {
                    const on = settings.mode === k
                    return (
                      <button key={k} type="button" aria-pressed={on} onClick={() => { patch({ mode: k }); audio.ui('click') }} className={`border px-3 py-2 text-left transition-colors ${on ? 'border-fuchsia-400/70 bg-fuchsia-500/15' : 'border-white/15 bg-white/[0.04] hover:bg-white/10'}`}>
                        <span className={`block text-[11px] font-black uppercase ${on ? 'text-fuchsia-200' : 'text-white'}`}>{title}</span>
                        <span className="mt-0.5 block text-[10px] text-white/55">{desc}</span>
                      </button>
                    )
                  })}
                </div>
              </section>

              {settings.mode === 'arena' && (
                <section className="mt-4" aria-labelledby="terrain-heading">
                  <div className="flex items-center justify-between">
                    <h2 id="terrain-heading" className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/55">Medan &amp; Peta</h2>
                    <div className="flex items-center gap-3">
                      <button type="button" onClick={() => { patch({ arenaSeed: 1 + Math.floor(Math.random() * 99) }); audio.ui('click') }} className="text-[10px] font-bold uppercase tracking-wider text-white/55 transition hover:text-emerald-200">Acak #{settings.arenaSeed}</button>
                      <button type="button" onClick={() => { engRef.current?.setForestTour('river'); setTourMode('river'); audio.ui('click') }} className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 transition hover:text-white">
                        {settings.arenaPlanet === 'forest' ? 'Jelajah hutan 3D' : 'Jelajah kanyon 3D'}
                      </button>
                    </div>
                  </div>
                  <div className="mt-2 grid grid-cols-4 gap-1.5">
                    {PLANET_LIST.map(([k, title, c]) => {
                      const on = settings.arenaPlanet === k
                      return (
                        <button key={k} type="button" aria-pressed={on} onClick={() => { patch({ arenaPlanet: k }); audio.ui('click') }} className={`flex min-h-9 items-center justify-center gap-1.5 border px-1 py-1.5 text-[10px] font-bold uppercase transition-colors ${on ? 'border-emerald-300/70 bg-emerald-300/15 text-emerald-100' : 'border-white/15 bg-white/[0.04] text-white/65 hover:bg-white/10'}`}>
                          <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />{title}
                        </button>
                      )
                    })}
                  </div>
                </section>
              )}

              <section className="mt-4" aria-labelledby="class-heading">
                <div className="flex items-center justify-between">
                  <h2 id="class-heading" className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/55">Kelas kecepatan</h2>
                  <span className="text-[10px] text-white/35">Tanpa turbo</span>
                </div>
                <div className="mt-2 grid grid-cols-4 gap-1.5">
                  {CLASS_INFO.map((c, i) => {
                    const on = Math.round(settings.shipClass) === i
                    return (
                      <button key={c.name} type="button" aria-pressed={on} onClick={() => { patch({ shipClass: i }); audio.ui('click') }} className={`border px-2 py-2 text-left transition-colors ${on ? 'border-cyan-300/70 bg-cyan-300/15' : 'border-white/15 bg-white/[0.04] hover:bg-white/10'}`}>
                        <span className={`block text-[10px] font-black uppercase ${on ? 'text-cyan-200' : 'text-white'}`}>{c.name}</span>
                        <span className="mt-0.5 block text-[10px] tabular-nums text-white/55">{Math.round(c.kmh * vehicleStats.speed)} km/h</span>
                      </button>
                    )
                  })}
                </div>
              </section>

              <details className="mt-4 border-t border-white/10 pt-3 text-white/70">
                <summary className="cursor-pointer text-[10px] font-bold uppercase tracking-[0.2em] hover:text-white">Lawan, lap &amp; tingkat kesulitan</summary>
                <div className="mt-3 grid grid-cols-2 gap-4">
                  <label><span className="flex justify-between text-[10px] uppercase tracking-wider">Lawan <b>{settings.bots}</b></span><input type="range" min={0} max={15} step={1} value={settings.bots} onChange={(e) => patch({ bots: Number(e.target.value) })} className="mt-1 w-full accent-cyan-400" /></label>
                  <label><span className="flex justify-between text-[10px] uppercase tracking-wider">Lap <b>{settings.laps}</b></span><input type="range" min={1} max={10} step={1} value={settings.laps} onChange={(e) => patch({ laps: Number(e.target.value) })} className="mt-1 w-full accent-cyan-400" /></label>
                </div>
                <div className="mt-2 grid grid-cols-4 gap-1.5">
                  {PRESETS.map((p) => {
                    const on = Object.keys(p.values).every((k) => settings[k] === p.values[k])
                    return <button key={p.name} type="button" title={p.desc} onClick={() => { patch(p.values); audio.ui('click') }} className={`border py-1.5 text-[10px] font-bold uppercase ${on ? 'border-fuchsia-400 bg-fuchsia-500/25' : 'border-white/15 bg-white/5 hover:bg-white/10'}`}>{p.name}</button>
                  })}
                </div>
                <p className="mt-3 text-[10px] leading-relaxed text-white/55">W gas · S rem · A/D belok · Q/E rem udara · Shift turbo · <b className="text-cyan-300">N terbang bebas</b> (Space/E naik, Q tukik, N mendarat) · C kamera. Gamepad &amp; layar sentuh didukung.</p>
              </details>
            </div>
          </div>
          <div className="border-t border-white/10 bg-[#061019]/90 px-6 py-3 sm:px-9">
            <div className="mx-auto flex max-w-[440px] gap-2">
              <button type="button" onClick={startRace} className="min-h-12 flex-1 bg-gradient-to-r from-cyan-300 to-cyan-500 px-5 text-sm font-black uppercase italic tracking-[0.2em] text-[#07151b] transition hover:brightness-110 active:scale-[.98]">Balap!</button>
              <button type="button" onClick={() => setPanelOpen(true)} className="min-h-12 border border-white/20 px-4 text-[10px] font-bold uppercase tracking-[0.15em] text-white/75 transition hover:bg-white/10">Pengaturan</button>
            </div>
          </div>
        </div>
      )}

      {h.state === 'demo' && showPreview && (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between bg-gradient-to-b from-[#061018]/65 via-transparent to-[#061018]/80 px-6 py-7 sm:px-10">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-cyan-200/75">Garasi / Tampilan 3D</div>
            <h2 className="mt-2 text-3xl font-black uppercase italic tracking-tight text-white sm:text-5xl">{vehicle.name}</h2>
            <p className="mt-1 max-w-sm text-xs leading-relaxed text-white/70">{vehicle.desc}{vehicle.id === 'swoop' ? ' - lebih cepat, lebih sulit dikendalikan.' : ''}</p>
          </div>
          <div className="pointer-events-auto flex max-w-md flex-wrap gap-2">
            <button type="button" aria-label="Kendaraan sebelumnya" onClick={() => { const i = SKINS.findIndex((skin) => skin.id === settings.skin); patch({ skin: SKINS[(i - 1 + SKINS.length) % SKINS.length].id }); audio.ui('click') }} className="min-h-12 min-w-12 border border-white/30 bg-[#061018]/70 px-3 text-lg text-white transition hover:bg-white/15">&lt;</button>
            <button type="button" aria-label="Kendaraan berikutnya" onClick={() => { const i = SKINS.findIndex((skin) => skin.id === settings.skin); patch({ skin: SKINS[(i + 1) % SKINS.length].id }); audio.ui('click') }} className="min-h-12 min-w-12 border border-white/30 bg-[#061018]/70 px-3 text-lg text-white transition hover:bg-white/15">&gt;</button>
            <button type="button" onClick={() => { engRef.current?.setGaragePreview(false); setShowPreview(false) }} className="min-h-12 flex-1 border border-white/30 bg-[#061018]/70 px-3 text-[10px] font-bold uppercase tracking-[0.15em] text-white transition hover:bg-white/15">Kembali</button>
            <button type="button" onClick={startRace} className="min-h-12 flex-1 bg-cyan-300 px-4 text-[11px] font-black uppercase tracking-[0.15em] text-[#07151b] transition hover:brightness-110">Balap!</button>
          </div>
        </div>
      )}

      {h.state === 'demo' && tourMode && (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between bg-gradient-to-b from-[#04120e]/55 via-transparent to-[#04120e]/75 px-6 py-6 sm:px-9">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.32em] text-cyan-300/90">
                Eksplorasi {settings.arenaPlanet === 'desert' ? 'Kanyon Gurun' : settings.arenaPlanet === 'ice' ? 'Kanyon Gletser Es' : settings.arenaPlanet === 'lava' ? 'Kanyon Kaldera Lava' : 'Rimba Raya'} · Peta #{settings.arenaSeed}
              </div>
              <h2 className="mt-1 text-2xl font-black uppercase italic tracking-tight text-white sm:text-4xl">
                {tourMode === 'river'
                  ? (settings.arenaPlanet === 'lava' ? 'Sungai & Air Terjun Magma' : settings.arenaPlanet === 'ice' ? 'Sungai Safir & Aurora' : settings.arenaPlanet === 'desert' ? 'Ngarai & Sungai Oasis' : 'Sungai & Rute Hologram')
                  : tourMode === 'giants'
                    ? (settings.arenaPlanet === 'forest' ? 'Rimba Pohon Raksasa' : 'Lengkungan Tebing Raksasa')
                    : tourMode === 'mountain'
                      ? (settings.arenaPlanet === 'desert' ? 'Mesa & Menara Hoodoo' : settings.arenaPlanet === 'ice' ? 'Puncak Gletser Kristal' : settings.arenaPlanet === 'lava' ? 'Puncak Kaldera Vulkanik' : 'Pegunungan Hutan Awan')
                      : 'Panorama Bentuk Peta'}
              </h2>
              <div className="pointer-events-auto mt-2.5 flex flex-wrap gap-1.5">
                {PLANET_LIST.map(([k, title, c]) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => { patch({ arenaPlanet: k }); audio.ui('click') }}
                    className={`flex items-center gap-1.5 border px-2.5 py-1 text-[10px] font-bold uppercase backdrop-blur-sm transition ${settings.arenaPlanet === k ? 'border-white/75 bg-white/20 text-white' : 'border-white/20 bg-black/45 text-white/70 hover:bg-white/15'}`}
                  >
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />{title}
                  </button>
                ))}
              </div>
            </div>
            <div className="hidden flex-col items-center rounded-xl border border-cyan-300/25 bg-[#041518]/72 p-2 backdrop-blur-sm sm:flex">
              <canvas ref={tourMapRef} style={{ width: 168, height: 168 }} className="rounded-lg" />
              <div className="mt-1 flex gap-3 text-[9px] font-bold uppercase tracking-wider text-white/70">
                <span className="flex items-center gap-1"><i className="inline-block h-1.5 w-1.5 rounded-full bg-cyan-300" />Rute</span>
                <span className="flex items-center gap-1"><i className="inline-block h-1.5 w-1.5 rounded-full bg-fuchsia-400" />Pintas</span>
                <span className="flex items-center gap-1"><i className="inline-block h-1.5 w-1.5 rounded-full" style={{ background: settings.arenaPlanet === 'lava' ? '#ff7820' : '#5eead4' }} />{settings.arenaPlanet === 'lava' ? 'Magma' : 'Aliran'}</span>
              </div>
            </div>
          </div>
          <div className="pointer-events-auto flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex flex-wrap gap-1.5">
              {[
                ['river', settings.arenaPlanet === 'lava' ? 'Sungai Magma' : settings.arenaPlanet === 'desert' ? 'Ngarai & Oasis' : 'Sungai & Rute'],
                ['giants', settings.arenaPlanet === 'forest' ? 'Pohon Raksasa' : 'Lengkungan Tebing'],
                ['mountain', settings.arenaPlanet === 'desert' ? 'Mesa & Hoodoo' : settings.arenaPlanet === 'lava' ? 'Kaldera' : 'Puncak Megah'],
                ['map', 'Bentuk Peta'],
              ].map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => { engRef.current?.setForestTour(id); setTourMode(id); audio.ui('click') }}
                  className={`min-h-10 border px-3.5 text-[10px] font-black uppercase tracking-[0.14em] backdrop-blur-sm transition ${tourMode === id ? 'border-emerald-300 bg-emerald-400/25 text-emerald-100' : 'border-white/25 bg-[#041310]/70 text-white/80 hover:bg-white/15'}`}
                >
                  {label}
                </button>
              ))}
              <button type="button" onClick={() => { patch({ arenaSeed: 1 + Math.floor(Math.random() * 99) }); audio.ui('click') }} className="min-h-10 border border-teal-300/35 bg-[#041310]/70 px-3.5 text-[10px] font-bold uppercase tracking-[0.14em] text-teal-200 backdrop-blur-sm transition hover:bg-teal-400/20">↻ Acak Peta</button>
              <button type="button" onClick={() => { patch({ theme: settings.theme === 'day' ? 'sunset' : settings.theme === 'sunset' ? 'night' : 'day' }); audio.ui('click') }} className="min-h-10 border border-white/25 bg-[#041310]/70 px-3 text-[10px] font-bold uppercase tracking-[0.14em] text-white/80 backdrop-blur-sm transition hover:bg-white/15">
                {settings.theme === 'day' ? '☀ Siang' : settings.theme === 'sunset' ? '🌇 Senja' : '🌙 Malam'}
              </button>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => { engRef.current?.setForestTour(null); setTourMode(null); audio.ui('back') }} className="min-h-10 border border-white/30 bg-[#041310]/75 px-4 text-[10px] font-bold uppercase tracking-[0.15em] text-white backdrop-blur-sm transition hover:bg-white/15">Kembali</button>
              <button type="button" onClick={startRace} className="min-h-10 bg-gradient-to-r from-emerald-300 to-cyan-300 px-5 text-[11px] font-black uppercase italic tracking-[0.18em] text-[#051814] transition hover:brightness-110">Balap!</button>
            </div>
          </div>
        </div>
      )}

      <SettingsPanel
        open={panelOpen}
        settings={settings}
        onChange={patch}
        onReset={() => {
          saveSettings({ ...DEFAULTS })
          setSettings({ ...DEFAULTS })
        }}
        onClose={() => setPanelOpen(false)}
      />
    </div>
  )
}
