// @ts-nocheck
// Clean, pole-free futuristic sci-fi holographic route guidance & portal gate system.
// Zero roadside sticks or billboard poles — uses flush flowing ground/water chevron streams,
// sleek low-floating plasma curb ribbons, frameless curved holographic corner arrows,
// floating shortcut energy arches, and aerodynamic angled portal gates with a soft
// radial-faded beacon glow on the active checkpoint.
import * as THREE from 'three'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const wrapA = (a) => {
  while (a > Math.PI) a -= Math.PI * 2
  while (a < -Math.PI) a += Math.PI * 2
  return a
}

function makeBadgeTexture(text, subText, accentHex) {
  const c = document.createElement('canvas')
  c.width = 256
  c.height = 96
  const g = c.getContext('2d')
  g.clearRect(0, 0, 256, 96)
  g.fillStyle = 'rgba(4, 14, 26, 0.86)'
  g.beginPath()
  g.moveTo(20, 6)
  g.lineTo(236, 6)
  g.lineTo(250, 26)
  g.lineTo(250, 70)
  g.lineTo(236, 90)
  g.lineTo(20, 90)
  g.lineTo(6, 70)
  g.lineTo(6, 26)
  g.closePath()
  g.fill()
  g.strokeStyle = accentHex
  g.lineWidth = 4
  g.stroke()

  g.fillStyle = accentHex
  g.font = 'bold 15px ui-monospace, monospace'
  g.textAlign = 'center'
  g.fillText(subText, 128, 28)

  g.fillStyle = '#ffffff'
  g.font = '900 italic 42px ui-sans-serif, system-ui, sans-serif'
  g.fillText(text, 128, 74)

  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.minFilter = THREE.LinearFilter
  return t
}

export function buildRouteGuide(arena, { fogColor, fogDensity }) {
  const group = new THREE.Group()
  group.name = 'scifi-route-guide'
  const guideGroup = new THREE.Group()
  guideGroup.name = 'scifi-ribbons-and-signs'
  group.add(guideGroup)

  const surfaceLift = (x, z) => {
    const rv = arena.riverAt ? arena.riverAt(x, z) : 0
    return rv > 0.36 ? 1.48 : 0.48
  }

  // ── 1. Flush Flowing Holographic Centerline Chevron Stream (`>>>`) — ZERO POLES!
  const ribbonUniforms = {
    time: { value: 0 },
    activeSeg: { value: 0 },
    fogC: { value: new THREE.Color(fogColor) },
    fogD: { value: fogDensity * 0.65 },
  }
  const ribbonMat = new THREE.ShaderMaterial({
    uniforms: ribbonUniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    vertexShader: `
      attribute vec2 routeMeta;
      varying vec2 vUv;
      varying vec2 vMeta;
      varying vec3 vW;
      void main(){
        vUv = uv;
        vMeta = routeMeta;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      varying vec2 vUv;
      varying vec2 vMeta;
      varying vec3 vW;
      uniform float time, activeSeg, fogD;
      void main(){
        float isCut = vMeta.y;
        float isActive = 1.0 - step(0.45, abs(vMeta.x - activeSeg));
        float ax = abs(vUv.x * 2.0 - 1.0);

        float sideRail = smoothstep(0.09, 0.0, abs(ax - 0.88)) * 0.58;
        float speed = 2.1 + isActive * 0.9;
        float flow = vUv.y - time * speed;
        float cell = fract(flow - ax * 0.54);
        float chev1 = smoothstep(0.22, 0.09, abs(cell - 0.5)) * (1.0 - smoothstep(0.68, 0.85, ax));
        float cell2 = fract(flow * 2.0 - ax * 0.45);
        float chev2 = smoothstep(0.12, 0.02, abs(cell2 - 0.5)) * (1.0 - smoothstep(0.32, 0.52, ax)) * 0.38;

        float packet = 0.6 + 0.4 * sin(vUv.y * 0.62 - time * 4.2);
        vec3 mainCol = mix(vec3(0.0, 0.86, 1.0), vec3(0.22, 1.0, 0.72), isActive * 0.6 + chev1 * 0.25);
        vec3 cutCol  = mix(vec3(1.0, 0.3, 0.92), vec3(1.0, 0.8, 0.28), chev1 * 0.45);
        vec3 col = mix(mainCol, cutCol, isCut);
        col = mix(col, vec3(0.95, 1.0, 1.0), chev1 * (0.35 + 0.25 * isActive) * (1.0 - ax));

        float intensity = (chev1 * (0.78 + 0.34 * packet) + chev2 + sideRail * (0.5 + 0.45 * packet)) * (0.62 + 0.48 * isActive);
        float dist = length(vW - cameraPosition);
        float fogFade = exp(-fogD * fogD * dist * dist) * (1.0 - smoothstep(520.0, 920.0, dist));
        float alpha = clamp(intensity * (1.0 - smoothstep(0.92, 1.0, ax)) * fogFade * 0.76, 0.0, 0.9);
        if (alpha < 0.012) discard;
        gl_FragColor = vec4(col * alpha, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })

  for (const p of arena.paths) {
    if (p.kind === 'cut' && p.hidden) continue
    const pts = p.pts
    if (pts.length < 4) continue
    const halfW = p.kind === 'cut' ? 4.2 : 5.6
    const startI = 2
    const endI = pts.length - 2
    const rows = endI - startI + 1
    const pos = new Float32Array(rows * 2 * 3)
    const uv = new Float32Array(rows * 2 * 2)
    const meta = new Float32Array(rows * 2 * 2)
    const idx = []
    let accDist = 0
    for (let r = 0; r < rows; r++) {
      const i = startI + r
      const q = pts[i]
      if (r > 0) accDist += Math.hypot(q[0] - pts[i - 1][0], q[1] - pts[i - 1][1])
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)]
      const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / tl, rz = (b[0] - a[0]) / tl
      const endTaper = Math.min(1, r / 3, (rows - 1 - r) / 3)
      const w = halfW * (0.4 + 0.6 * endTaper)
      for (let s = 0; s < 2; s++) {
        const side = s === 0 ? -1 : 1
        const wx = q[0] + rx * side * w
        const wz = q[1] + rz * side * w
        const v = r * 2 + s
        pos[v * 3] = wx
        pos[v * 3 + 1] = arena.groundAt(wx, wz) + surfaceLift(wx, wz)
        pos[v * 3 + 2] = wz
        uv[v * 2] = s
        uv[v * 2 + 1] = accDist / 28
        meta[v * 2] = p.seg
        meta[v * 2 + 1] = p.kind === 'cut' ? 1 : 0
      }
      if (r < rows - 1) {
        const v = r * 2
        idx.push(v, v + 2, v + 1, v + 1, v + 2, v + 3)
      }
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
    g.setAttribute('routeMeta', new THREE.BufferAttribute(meta, 2))
    g.setIndex(idx)
    g.computeBoundingSphere()
    const m = new THREE.Mesh(g, ribbonMat)
    m.renderOrder = 6
    guideGroup.add(m)
  }

  // ── 2. Pole-Free Low-Hovering Sci-Fi Plasma Curb Ribbons (Left = Cyan, Right = Gold, Shortcut = Magenta)
  // Smooth continuous light-curbs hugging the terrain at y + 1.15 m — completely unobstructed scenery!
  const railUniforms = {
    time: { value: 0 },
    activeSeg: { value: 0 },
    fogD: { value: fogDensity * 0.72 },
  }
  const railMat = new THREE.ShaderMaterial({
    uniforms: railUniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    vertexShader: `
      attribute vec3 railColor;
      attribute float railSeg;
      varying vec2 vUv;
      varying vec3 vCol;
      varying float vSeg;
      varying vec3 vW;
      void main(){
        vUv = uv;
        vCol = railColor;
        vSeg = railSeg;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      varying vec2 vUv;
      varying vec3 vCol;
      varying float vSeg;
      varying vec3 vW;
      uniform float time, activeSeg, fogD;
      void main(){
        float isActive = 1.0 - step(0.45, abs(vSeg - activeSeg));
        float core = pow(clamp(1.0 - abs(vUv.x * 2.0 - 1.0), 0.0, 1.0), 1.7);
        float dash = smoothstep(0.16, 0.34, fract(vUv.y * 0.45)) * (1.0 - smoothstep(0.80, 0.95, fract(vUv.y * 0.45)));
        float pulse = pow(0.5 + 0.5 * sin(vUv.y * 0.52 - time * 5.0), 4.0);
        float glow = core * (0.28 + 0.44 * dash + pulse * (0.62 + 0.5 * isActive)) * (0.68 + 0.42 * isActive);
        float d = length(vW - cameraPosition);
        float fade = exp(-fogD * fogD * d * d) * (1.0 - smoothstep(480.0, 860.0, d));
        float a = clamp(glow * fade * 0.82, 0.0, 0.92);
        if (a < 0.012) discard;
        vec3 col = mix(vCol, vec3(1.0), pulse * core * 0.5);
        gl_FragColor = vec4(col * a, a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })

  const railPos = []
  const railUv = []
  const railCol = []
  const railSeg = []
  const railIdx = []
  let railVerts = 0

  const cornerSigns = []
  const splitBeacons = []

  const cLeft = new THREE.Color('#18f2ff')
  const cRight = new THREE.Color('#ffba3b')
  const cCut = new THREE.Color('#ff54f0')

  for (const p of arena.paths) {
    if (p.kind === 'cut' && p.hidden) continue
    const pts = p.pts
    const borderOff = p.halfW - 4.2
    const railH = p.kind === 'cut' ? 0.36 : 0.46

    for (const side of [-1, 1]) {
      const col = p.kind === 'cut' ? cCut : side < 0 ? cLeft : cRight
      let dist = 0
      const baseV = railVerts
      let count = 0
      for (let i = 3; i < pts.length - 3; i += 2) {
        const q = pts[i]
        if (count > 0) {
          const prev = pts[i - 2]
          dist += Math.hypot(q[0] - prev[0], q[1] - prev[1])
        }
        const a = pts[i - 1], b = pts[i + 1]
        const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
        const rx = -(b[1] - a[1]) / tl, rz = (b[0] - a[0]) / tl
        const wx = q[0] + rx * side * borderOff
        const wz = q[1] + rz * side * borderOff
        const wy = arena.groundAt(wx, wz) + 1.25
        const fadeEnd = Math.min(1, count / 2, Math.floor((pts.length - 4 - i) / 2) / 2)
        const hNow = railH * (0.3 + 0.7 * clamp(fadeEnd, 0, 1))
        // Flat angled horizontal-vertical curb ribbon so it reads cleanly from both chase cam and sky!
        railPos.push(wx - rx * side * 0.55, wy - hNow * 0.5, wz - rz * side * 0.55)
        railPos.push(wx + rx * side * 0.55, wy + hNow, wz + rz * side * 0.55)
        railUv.push(0, dist / 14, 1, dist / 14)
        railCol.push(col.r, col.g, col.b, col.r, col.g, col.b)
        railSeg.push(p.seg, p.seg)
        railVerts += 2
        if (count > 0) {
          const v = baseV + (count - 1) * 2
          railIdx.push(v, v + 2, v + 1, v + 1, v + 2, v + 3)
        }
        count++
      }
    }

    // Frameless Floating Holographic Corner Chevron Strips (`» » »`) ONLY on genuine sharp corners — ZERO POLES!
    if (p.kind === 'main') {
      let lastSignI = -99
      for (let i = 7; i < pts.length - 7; i += 3) {
        if (i - lastSignI < 8) continue
        const p0 = pts[i - 4], p1 = pts[i], p2 = pts[i + 4]
        const h1 = Math.atan2(p1[0] - p0[0], -(p1[1] - p0[1]))
        const h2 = Math.atan2(p2[0] - p1[0], -(p2[1] - p1[1]))
        const dAng = wrapA(h2 - h1)
        if (Math.abs(dAng) < 0.24) continue
        lastSignI = i
        const outSide = dAng > 0 ? -1 : 1
        const tx = p2[0] - p0[0], tz = p2[1] - p0[1]
        const tl = Math.hypot(tx, tz) || 1
        const rx = -tz / tl, rz = tx / tl
        const off = p.halfW - 2.2
        const wx = p1[0] + rx * outSide * off
        const wz = p1[1] + rz * outSide * off
        const wy = arena.groundAt(wx, wz)
        const tangentYaw = Math.atan2(tx / tl, tz / tl) + (outSide > 0 ? -Math.PI / 2 : Math.PI / 2)
        cornerSigns.push({
          x: wx, y: wy, z: wz,
          yaw: tangentYaw,
          dir: outSide > 0 ? -1 : 1,
        })
      }
    }

    // Floating Holographic Shortcut Entrance Archway
    if (p.kind === 'cut' && !p.hidden && pts.length > 10) {
      const idxFork = Math.min(8, Math.floor(pts.length * 0.16))
      const q = pts[idxFork], qNext = pts[idxFork + 2]
      splitBeacons.push({
        x: q[0], y: arena.groundAt(q[0], q[1]), z: q[1],
        yaw: Math.atan2(qNext[0] - q[0], qNext[1] - q[1]),
      })
    }
  }

  if (railIdx.length) {
    const rg = new THREE.BufferGeometry()
    rg.setAttribute('position', new THREE.Float32BufferAttribute(railPos, 3))
    rg.setAttribute('uv', new THREE.Float32BufferAttribute(railUv, 2))
    rg.setAttribute('railColor', new THREE.Float32BufferAttribute(railCol, 3))
    rg.setAttribute('railSeg', new THREE.Float32BufferAttribute(railSeg, 1))
    rg.setIndex(railIdx)
    rg.computeBoundingSphere()
    const railMesh = new THREE.Mesh(rg, railMat)
    railMesh.renderOrder = 6
    guideGroup.add(railMesh)
  }

  // ── 3. Pole-Free Levitating Holographic Corner Chevron Ribbons (`» » »`)
  const signUniforms = {
    time: { value: 0 },
    fogD: { value: fogDensity * 0.7 },
  }
  const signMat = new THREE.ShaderMaterial({
    uniforms: signUniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vW;
      void main(){
        vUv = uv;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      varying vec2 vUv;
      varying vec3 vW;
      uniform float time, fogD;
      void main(){
        float ay = abs(vUv.y * 2.0 - 1.0);
        float border = smoothstep(0.1, 0.0, abs(ay - 0.9)) * 0.65;
        float scroll = vUv.x * 3.5 - time * 2.8 - ay * 0.44;
        float arrow = smoothstep(0.42, 0.24, abs(fract(scroll) - 0.5)) * (1.0 - smoothstep(0.7, 0.86, ay));
        vec3 col = mix(vec3(0.0, 0.92, 1.0), vec3(1.0, 0.82, 0.22), arrow * 0.82);
        col = mix(col, vec3(1.0), pow(arrow, 2.0) * 0.5);
        float d = length(vW - cameraPosition);
        float fade = exp(-fogD * fogD * d * d) * (1.0 - smoothstep(380.0, 680.0, d));
        float xEnd = smoothstep(0.0, 0.14, vUv.x) * (1.0 - smoothstep(0.86, 1.0, vUv.x));
        float a = clamp((arrow * 0.92 + border) * xEnd * fade * 0.85, 0.0, 0.92);
        if (a < 0.012) discard;
        gl_FragColor = vec4(col * a, a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })
  const floatingSigns = []
  if (cornerSigns.length) {
    const boardGeo = new THREE.PlaneGeometry(18, 4.4)
    for (let i = 0; i < cornerSigns.length; i++) {
      const cs = cornerSigns[i]
      const board = new THREE.Mesh(boardGeo, signMat)
      board.position.set(cs.x, cs.y + 5.2, cs.z)
      board.rotation.y = cs.yaw
      board.scale.x = cs.dir
      board.renderOrder = 7
      guideGroup.add(board)
      floatingSigns.push({ mesh: board, baseY: cs.y + 5.2, ph: i * 1.1 })
    }
  }

  // ── 4. Floating Holographic Shortcut Entrance Arches (Curved Energy Ring, Zero Poles)
  if (splitBeacons.length) {
    const archGeo = new THREE.TorusGeometry(15.5, 0.45, 8, 32, Math.PI)
    const archMat = new THREE.MeshBasicMaterial({
      color: '#ff5af2',
      transparent: true,
      opacity: 0.72,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
    const cutBadge = makeBadgeTexture('PINTAS', '◈ JALUR CABANG ◈', '#ff66f5')
    const badgeMat = new THREE.MeshBasicMaterial({ map: cutBadge, transparent: true, side: THREE.DoubleSide, depthWrite: false })
    const badgeGeo = new THREE.PlaneGeometry(11.5, 4.3)
    for (const sb of splitBeacons) {
      const bg = new THREE.Group()
      bg.position.set(sb.x, sb.y, sb.z)
      bg.rotation.y = sb.yaw
      const arch = new THREE.Mesh(archGeo, archMat)
      arch.position.y = 0.5
      const sign = new THREE.Mesh(badgeGeo, badgeMat)
      sign.position.set(0, 18.6, 0)
      bg.add(arch, sign)
      guideGroup.add(bg)
    }
  }

  // ── 5. Sculpted Curved Sci-Fi Portal Arch Gates (Sweeping Continuous Arch, NOT Two Stick Poles!)
  const gates = []
  // Soft radially-dissolving sky glow (zero sharp vertical cylinder edges!)
  const beamTex = (() => {
    const c = document.createElement('canvas')
    c.width = 64
    c.height = 256
    const g = c.getContext('2d')
    const img = g.createImageData(64, 256)
    for (let y = 0; y < 256; y++) {
      const vy = 1 - y / 255 // 0 at bottom, 1 at top
      const va = Math.pow(1 - vy, 2.2) * Math.min(1, vy / 0.08)
      for (let x = 0; x < 64; x++) {
        const ux = Math.abs((x / 63) * 2 - 1)
        const ha = Math.pow(Math.max(0, 1 - ux), 2.4)
        const o = (y * 64 + x) * 4
        img.data[o] = img.data[o + 1] = img.data[o + 2] = 255
        img.data[o + 3] = Math.round(255 * va * ha)
      }
    }
    g.putImageData(img, 0, 0)
    const t = new THREE.CanvasTexture(c)
    t.minFilter = THREE.LinearFilter
    return t
  })()

  const curtainTex = (() => {
    const c = document.createElement('canvas')
    c.width = 64
    c.height = 128
    const g = c.getContext('2d')
    const img = g.createImageData(64, 128)
    for (let y = 0; y < 128; y++) {
      const vy = y / 127 // 0 top .. 1 bottom
      const archFade = Math.pow(1 - vy, 1.5) * 0.72 + Math.pow(vy, 4.0) * 0.25
      const scan = y % 6 < 2 ? 1.15 : 0.85
      for (let x = 0; x < 64; x++) {
        const ux = (x / 63) * 2 - 1
        // Only fill inside the semi-elliptical portal arch!
        const archCeiling = 1 - Math.sqrt(Math.max(0, 1 - ux * ux))
        const inside = vy > archCeiling ? 1 : 0
        const o = (y * 64 + x) * 4
        img.data[o] = img.data[o + 1] = img.data[o + 2] = 255
        img.data[o + 3] = Math.round(clamp(255 * archFade * scan * inside, 0, 255))
      }
    }
    g.putImageData(img, 0, 0)
    const t = new THREE.CanvasTexture(c)
    t.minFilter = THREE.LinearFilter
    return t
  })()

  const archHull = new THREE.MeshStandardMaterial({ color: '#1a2838', roughness: 0.28, metalness: 0.82 })
  const archTrim = new THREE.MeshStandardMaterial({ color: '#e4f0fa', roughness: 0.25, metalness: 0.65 })
  const up = new THREE.Vector3(0, 1, 0)

  arena.gates.forEach((gt, k) => {
    const grp = new THREE.Group()
    const gy = arena.groundAt(gt.x, gt.z)
    const lat = new THREE.Vector3(-gt.nz, 0, gt.nx)
    const back = new THREE.Vector3(-gt.nx, 0, -gt.nz)
    const m = new THREE.Matrix4().makeBasis(lat, up, back)
    m.setPosition(gt.x, gy, gt.z)
    grp.applyMatrix4(m)
    grp.matrixAutoUpdate = false

    const half = gt.r * 0.85
    const archHeight = 38
    const glowMat = new THREE.MeshBasicMaterial({ color: '#00e5ff' })

    // Seamless sweeping curved sci-fi portal ring arch (Wipeout / Halo forerunner style!)
    const mainArch = new THREE.Mesh(new THREE.TorusGeometry(half, 1.85, 10, 44, Math.PI), archHull)
    mainArch.scale.set(1, archHeight / half, 1.25)
    grp.add(mainArch)

    const outerCrest = new THREE.Mesh(new THREE.TorusGeometry(half + 1.5, 0.65, 8, 44, Math.PI), archTrim)
    outerCrest.scale.set(1, archHeight / half, 1.4)
    grp.add(outerCrest)

    const innerPlasma = new THREE.Mesh(new THREE.TorusGeometry(half - 1.55, 0.72, 8, 44, Math.PI), glowMat)
    innerPlasma.scale.set(1, archHeight / half, 1.0)
    grp.add(innerPlasma)

    // Sturdy low angled anchor footings at both ends of the arch
    for (const sdx of [-1, 1]) {
      const foot = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 4.8, 4.2, 8), archHull)
      foot.position.set(sdx * half, 1.6, 0)
      const footRing = new THREE.Mesh(new THREE.TorusGeometry(3.8, 0.35, 8, 18).rotateX(Math.PI / 2), glowMat)
      footRing.position.set(sdx * half, 3.6, 0)
      grp.add(foot, footRing)
    }

    // Semi-elliptical holographic scanline curtain fitted cleanly inside the curved arch
    const curtMat = new THREE.MeshBasicMaterial({
      map: curtainTex,
      color: '#00e5ff',
      transparent: true,
      opacity: 0.28,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    })
    const curtain = new THREE.Mesh(new THREE.PlaneGeometry((half - 2) * 2, archHeight - 1.5), curtMat)
    curtain.position.set(0, (archHeight - 1.5) * 0.5, 0)
    curtain.renderOrder = 6
    grp.add(curtain)

    // Sleek floating gate crown badge
    const labelStr = k === 0 ? 'FINISH' : `GATE ${k < 10 ? '0' + k : k}`
    const badge = makeBadgeTexture(labelStr, k === 0 ? '◈ START / FINISH ◈' : '◈ CHECKPOINT ◈', k === 0 ? '#52ff9a' : '#38f2ff')
    const banner = new THREE.Mesh(
      new THREE.PlaneGeometry(21, 7.8),
      new THREE.MeshBasicMaterial({ map: badge, transparent: true, side: THREE.DoubleSide }),
    )
    banner.position.set(0, archHeight + 6.2, 0)
    grp.add(banner)

    // High-altitude holographic Flight Ring (only visible on active gate when flying!)
    const skyRingMat = new THREE.MeshBasicMaterial({
      color: '#38ff9c',
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
    const skyRing = new THREE.Mesh(new THREE.TorusGeometry(21, 0.85, 8, 36), skyRingMat)
    skyRing.position.set(0, archHeight + 36, 0)
    skyRing.visible = false
    grp.add(skyRing)

    // Soft feather-edged volumetric waypoint glow ONLY on the active next gate!
    const beaconMat = new THREE.MeshBasicMaterial({
      map: beamTex,
      color: '#38ff9c',
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
      fog: false,
    })
    const beaconGrp = new THREE.Group()
    beaconGrp.position.set(0, archHeight + 115, 0)
    for (let c = 0; c < 2; c++) {
      const bm = new THREE.Mesh(new THREE.PlaneGeometry(34, 220), beaconMat)
      bm.rotation.y = (c * Math.PI) / 2
      bm.renderOrder = 7
      beaconGrp.add(bm)
    }
    grp.add(beaconGrp)

    group.add(grp)
    gates.push({ glowMat, curtMat, beaconMat, beaconGrp, skyRingMat, skyRing })
  })

  return {
    group,
    setVisible(show) {
      guideGroup.visible = !!show
    },
    update(time, sim) {
      const n = arena.gates.length
      const next = sim.player.cp % n
      const afterNext = (next + 1) % n
      const curSeg = (next - 1 + n) % n
      const flying = !!(sim.player.flying || sim.player.airborne)

      ribbonUniforms.time.value = time
      ribbonUniforms.activeSeg.value = curSeg
      railUniforms.time.value = time
      railUniforms.activeSeg.value = curSeg
      signUniforms.time.value = time

      for (const fs of floatingSigns) {
        fs.mesh.position.y = fs.baseY + Math.sin(time * 2.4 + fs.ph) * 0.35
      }

      gates.forEach((g, k) => {
        const isNext = k === next
        const isAfter = k === afterNext
        const col = isNext ? '#38ff9a' : isAfter ? '#2cf2ff' : '#00b4e6'
        g.glowMat.color.set(col)
        g.curtMat.color.set(col)
        g.curtMat.opacity = isNext ? 0.38 + 0.14 * Math.sin(time * 5.0) : isAfter ? 0.18 : 0.10
        g.beaconGrp.visible = isNext
        if (isNext) {
          g.beaconMat.opacity = (0.24 + 0.08 * Math.sin(time * 3.8)) * (flying ? 1.3 : 1)
        }
        g.skyRing.visible = flying && (isNext || isAfter)
        if (g.skyRing.visible) {
          g.skyRing.rotation.z = time * 0.9 + k
          g.skyRingMat.color.set(col)
          g.skyRingMat.opacity = isNext ? 0.72 + 0.15 * Math.sin(time * 5) : 0.32
        }
      })
    },
  }
}
