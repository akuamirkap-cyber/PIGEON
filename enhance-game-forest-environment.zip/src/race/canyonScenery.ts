// @ts-nocheck
// Pole-Free, Multi-Zone Monumental Canyon World Scenery (Desert, Ice, Lava).
// Every lap flows through dramatically varied visual zones with rich color contrast:
// - DESERT: Havasu-style turquoise waterfalls cascading off crimson-gold cliffs into
//   crystal oasis lagoons, lush umbrella acacia groves & vibrant bougainvillea bushes,
//   sweeping red-rock natural bridges, sleek white-and-gold sci-fi canyon solar rings,
//   smooth sandstone boulders, and soaring golden eagles.
// - ICE: Sapphire mirror-ice rivers & steaming emerald-turquoise hot-spring lagoons,
//   translucent blue glacier arches, radiant amethyst-rose & aquamarine geode clusters
//   (rich jewel-tone contrast against white snow!), sleek sci-fi cryo-stabilizer rings,
//   soft snow-cushioned alpine pines, and sweeping volumetric Aurora Borealis curtains.
// - LAVA: Roaring golden-orange magma rivers & caldera lakes, towering incandescent
//   lava-falls pouring down dark basalt cliffs, glowing magma-veined obsidian arches,
//   colossal cool-cyan sci-fi geothermal containment rings (striking cyan-vs-fire
//   contrast!), glowing ember boulders, and lit volcanic caldera clouds.
import * as THREE from 'three'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))

function mulberry32(seed) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function smoothStreamPts(rawPts, step = 4.0) {
  if (!rawPts || rawPts.length < 2) return []
  const K = rawPts.length
  const get = (i) => rawPts[clamp(i, 0, K - 1)]
  const out = []
  for (let k = 0; k < K - 1; k++) {
    const p0 = get(k - 1), p1 = get(k), p2 = get(k + 1), p3 = get(k + 2)
    const segL = Math.hypot(p2[0] - p1[0], p2[1] - p1[1])
    const sub = Math.max(1, Math.ceil(segL / step))
    for (let j = 0; j < sub; j++) {
      const t = j / sub, t2 = t * t, t3 = t2 * t
      const itp = (c) =>
        0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3)
      out.push([itp(0), itp(1), Math.max(4.0, itp(2))])
    }
  }
  out.push(rawPts[K - 1].slice())
  return out
}

// Broad sweeping organic natural canyon bridge (Landscape / Rainbow Bridge style)
function naturalBridgeGeometry(span, height, thickness, seed, cragAmp = 0.2) {
  const segU = 36
  const segV = 14
  const positions = []
  const indices = []
  for (let iu = 0; iu <= segU; iu++) {
    const u = iu / segU
    const ang = u * Math.PI
    const s = Math.sin(ang)
    const cx = Math.cos(ang) * span
    const cy = Math.pow(s, 0.78) * height - 6.0 + Math.sin(u * 8.0 + seed) * 1.2 * s
    const cz = Math.sin(ang * 2.0 + seed * 0.7) * 3.5 * s
    const tx = -Math.sin(ang) * span
    const ty = Math.cos(ang) * height * 0.78
    const tl = Math.hypot(tx, ty) || 1
    const nx = ty / tl, ny = -tx / tl
    // Wide sculpted canyon abutments tapering smoothly to an elegant broad stone/ice span
    const radXY = thickness * (1.65 - 0.85 * Math.pow(s, 0.88))
    const radZ = thickness * (1.55 - 0.55 * Math.pow(s, 0.85))
    for (let iv = 0; iv <= segV; iv++) {
      const v = (iv / segV) * Math.PI * 2
      const cv = Math.cos(v), sv = Math.sin(v)
      const h = Math.sin(iu * 11.3 + Math.round(cv * 20) * 7.1 + Math.round(sv * 20) * 17.9 + seed * 2.9) * 43758.5453
      const crag = 1 + ((h - Math.floor(h)) - 0.5) * cragAmp * 2
      const flatDeck = cv > 0.3 ? 0.82 : 1.0
      positions.push(
        cx + nx * cv * radXY * crag * flatDeck,
        cy + ny * cv * radXY * crag * flatDeck,
        cz + sv * radZ * crag,
      )
    }
  }
  const stride = segV + 1
  for (let iu = 0; iu < segU; iu++) {
    for (let iv = 0; iv < segV; iv++) {
      const a = iu * stride + iv, b = a + stride
      indices.push(a, a + 1, b, a + 1, b + 1, b)
    }
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  g.setIndex(indices)
  g.computeVertexNormals()
  return g
}

// Smooth painterly umbrella canopy cushion for lush desert oasis acacias & flowering bushes
function smoothCanopyPadGeo() {
  const g = new THREE.IcosahedronGeometry(1, 2)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const a = Math.atan2(z, x)
    const puff = 0.92 + 0.1 * Math.sin(a * 5 + y * 2) + 0.06 * Math.cos(a * 7 - y * 3)
    const ys = y > 0 ? Math.pow(y, 0.78) * 0.62 : y * 0.36
    p.setXYZ(i, x * puff * 1.15, ys * puff, z * puff * 1.15)
  }
  g.computeVertexNormals()
  return g
}

// Smooth water-worn / wind-carved boulder geometry
function smoothBoulderGeo() {
  const g = new THREE.IcosahedronGeometry(1, 1)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const k = Math.sin(Math.round(x * 70) * 19.1 + Math.round(y * 70) * 47.3 + Math.round(z * 70) * 31.7) * 43758.5453
    const s = 0.84 + 0.28 * (k - Math.floor(k))
    p.setXYZ(i, x * s, y * s * 0.72, z * s)
  }
  g.computeVertexNormals()
  return g
}

// Broad faceted crystal geode dome (low wide multi-faceted jewel boulder, NOT a thin pole!)
function geodeCrystalGeo() {
  const g = new THREE.OctahedronGeometry(1, 0)
  g.scale(0.85, 1.35, 0.85)
  g.translate(0, 0.55, 0)
  return g
}

function addInstanced(parent, geo, mat, list) {
  if (!list.length) return null
  const mesh = new THREE.InstancedMesh(geo, mat, list.length)
  const m4 = new THREE.Matrix4()
  const pos = new THREE.Vector3()
  const scl = new THREE.Vector3()
  const q = new THREE.Quaternion()
  const eu = new THREE.Euler()
  const c = new THREE.Color()
  for (let i = 0; i < list.length; i++) {
    const it = list[i]
    eu.set(it.rx || 0, it.ry || 0, it.rz || 0, 'YXZ')
    q.setFromEuler(eu)
    m4.compose(pos.set(it.x, it.y, it.z), q, scl.set(it.sx, it.sy, it.sz))
    mesh.setMatrixAt(i, m4)
    if (it.col) {
      c.set(it.col)
      mesh.setColorAt(i, c)
    }
  }
  mesh.instanceMatrix.needsUpdate = true
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
  mesh.frustumCulled = false
  parent.add(mesh)
  return mesh
}

function createCanyonArchMaterial({ bands, sunDir, sunCol, ambCol, fogColor, fogDensity, soft, planetId }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      bands: { value: bands },
      sunDir: { value: sunDir.clone() },
      sunCol: { value: sunCol.clone() },
      ambCol: { value: ambCol.clone() },
      fogC: { value: new THREE.Color(fogColor) },
      fogD: { value: fogDensity },
      soft: { value: soft ? 1 : 0 },
      planet: { value: planetId },
      time: { value: 0 },
    },
    vertexShader: `
      varying vec3 vW; varying vec3 vN;
      void main() {
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        vN = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      uniform vec3 bands[8];
      uniform vec3 sunDir, sunCol, ambCol, fogC;
      uniform float fogD, soft, planet, time;
      varying vec3 vW; varying vec3 vN;
      float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vn(vec2 p){
        vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
      }
      vec3 pick(float idx){
        vec3 c = bands[0];
        for (int k = 1; k < 8; k++) if (abs(idx - float(k)) < 0.5) c = bands[k];
        return c;
      }
      void main() {
        vec3 N = normalize(vN);
        vec3 V = normalize(cameraPosition - vW);
        float warp = (vn(vW.xz * 0.015) * 2.0 - 1.0) * 4.5 + (vn(vW.xz * 0.06 + 2.1) * 2.0 - 1.0) * 1.2;
        float sy = (vW.y + warp) / 5.2;
        float bi = floor(sy), bf = fract(sy);
        vec3 alb = mix(pick(mod(bi, 8.0)), pick(mod(bi + 1.0, 8.0)), smoothstep(0.66, 1.0, bf));
        float grain = vn(vW.xz * 0.42 + vW.y * 0.35);
        alb *= (0.86 + 0.26 * grain) * mix(0.76, 1.0, smoothstep(0.0, 0.12, bf));
        if (planet < 0.5) alb = mix(alb, vec3(0.86, 0.64, 0.40), smoothstep(0.55, 0.9, N.y) * 0.52);
        else if (planet < 1.5) alb = mix(alb, vec3(0.94, 0.98, 1.0), smoothstep(0.45, 0.85, N.y) * 0.8);
        else alb = mix(alb, vec3(0.14, 0.07, 0.07), smoothstep(0.5, 0.85, N.y) * 0.55);

        float ndl = max(dot(N, sunDir), 0.0);
        if (soft < 0.5) ndl = floor(ndl * 5.0 + 0.5) / 5.0;
        float rim = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.8);
        vec3 bounce = planet < 0.5 ? vec3(0.36, 0.14, 0.06) : planet < 1.5 ? vec3(0.14, 0.42, 0.68) : vec3(0.52, 0.12, 0.02);
        vec3 col = alb * (ambCol * (0.58 + 0.38 * N.y) + bounce * clamp(-N.y * 0.6 + 0.25, 0.0, 0.7) + sunCol * ndl * 1.08);
        if (planet < 0.5) col += sunCol * vec3(1.0, 0.72, 0.42) * rim * 0.3;
        else if (planet < 1.5) {
          vec3 H = normalize(sunDir + V);
          col += vec3(0.24, 0.8, 1.0) * rim * 0.45 + sunCol * pow(max(dot(N, H), 0.0), 44.0) * 0.6;
        } else {
          float crack = pow(clamp(1.0 - abs(vn(vW.xz * 0.12 + vW.y * 0.1) * 2.0 - 1.0), 0.0, 1.0), 10.0);
          col += mix(vec3(1.2, 0.25, 0.02), vec3(2.4, 1.4, 0.3), crack) * crack * (0.8 + 0.3 * sin(time * 2.4 + vW.y * 0.2));
        }
        float dist = length(vW - cameraPosition);
        col = mix(col, fogC, clamp(1.0 - exp(-fogD * fogD * dist * dist), 0.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })
}

function createCanyonStreamMaterial({ planetId, sunDir, sunCol, fogColor, fogDensity, soft, tod }) {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    uniforms: {
      time: { value: 0 },
      planet: { value: planetId },
      sunDir: { value: sunDir.clone() },
      sunCol: { value: sunCol.clone() },
      fogC: { value: new THREE.Color(fogColor) },
      fogD: { value: fogDensity },
      soft: { value: soft ? 1 : 0 },
      nightK: { value: tod === 'night' ? 1 : 0 },
    },
    vertexShader: `
      attribute vec2 aFlow;
      varying vec2 vUv; varying vec2 vFlow; varying vec3 vW;
      void main() {
        vUv = uv; vFlow = aFlow;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      uniform float time, planet, fogD, soft, nightK;
      uniform vec3 sunDir, sunCol, fogC;
      varying vec2 vUv; varying vec2 vFlow; varying vec3 vW;
      float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vn(vec2 p){
        vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
      }
      float caustics(vec2 p, float t){
        float a = vn(p + vec2(t * 0.35, -t * 0.8));
        float b = vn(p * 1.3 - vec2(t * 0.4, t * 0.6) + 4.3);
        return pow(clamp(1.0 - abs(a - b) * 2.3, 0.0, 1.0), 2.6);
      }
      void main() {
        float shore = min(vUv.x, 1.0 - vUv.x) * 2.0;
        float edgeA = smoothstep(0.0, 0.16, shore);
        float endA = smoothstep(0.0, 0.06, vFlow.x) * (1.0 - smoothstep(0.94, 1.0, vFlow.x));
        vec3 V = normalize(cameraPosition - vW);
        vec3 col = vec3(0.0);
        float alpha = 0.9;

        if (planet < 0.5) {
          // DESERT: Vivid Havasu-Falls turquoise-aquamarine water dazzling against crimson-gold sandstone!
          float scr = time * vFlow.y;
          float w1 = vn(vec2(vUv.x * 7.5, vUv.y * 3.6 - scr));
          float w2 = vn(vec2(vUv.x * 19.0 + 3.1, vUv.y * 8.5 - scr * 1.65));
          vec3 shallow = vec3(0.14, 0.78, 0.72);
          vec3 deep    = vec3(0.015, 0.38, 0.54);
          col = mix(shallow, deep, smoothstep(0.08, 0.88, shore));
          col += vec3(0.35, 0.62, 0.48) * caustics(vec2(vUv.x * 10.0, vUv.y * 5.0), time * 0.85) * (1.0 - shore * 0.45) * (1.0 - nightK * 0.6);
          vec3 N = normalize(vec3((w2 - 0.5) * 0.34, 1.0, (w1 - 0.5) * 0.34));
          float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.0);
          col = mix(col, mix(vec3(0.72, 0.38, 0.2), sunCol * 0.9, 0.62), fres * 0.5);
          vec3 H = normalize(sunDir + V);
          col += sunCol * (pow(max(dot(N, H), 0.0), 54.0) * 1.3 + step(0.85, w2) * 0.36);
          float foam = (1.0 - smoothstep(0.02, 0.18, shore)) * (0.5 + 0.38 * w2) + smoothstep(0.76, 0.92, w1 * 0.6 + w2 * 0.4) * 0.45;
          col = mix(col, vec3(0.97, 0.99, 0.96), clamp(foam, 0.0, 0.85));
          if (nightK > 0.5) col *= 0.58;
          alpha = edgeA * endA * 0.9;
        } else if (planet < 1.5) {
          // ICE: Dazzling emerald-turquoise geothermal springs & mirror sapphire ice veins!
          float p1 = vn(vW.xz * 0.075);
          float p2 = vn(vW.xz * 0.22 + 5.2);
          float crack = pow(clamp(1.0 - abs(vn(vW.xz * 0.15 + p1 * 1.4) * 2.0 - 1.0), 0.0, 1.0), 8.5);
          // Warm geothermal emerald-cyan rim transitioning into deep royal sapphire centre!
          vec3 warmRim = vec3(0.10, 0.82, 0.78);
          vec3 royalSapphire = vec3(0.03, 0.24, 0.64);
          col = mix(warmRim, royalSapphire, smoothstep(0.08, 0.75, shore));
          col += vec3(0.65, 0.96, 1.25) * crack * 0.9;
          col = mix(col, vec3(0.92, 0.98, 1.0), (1.0 - smoothstep(0.0, 0.16, shore)) * 0.68);
          vec3 N = normalize(vec3((p2 - 0.5) * 0.14, 1.0, (p1 - 0.5) * 0.14));
          vec3 H = normalize(sunDir + V);
          col += sunCol * pow(max(dot(N, H), 0.0), 85.0) * 1.55;
          alpha = edgeA * endA * 0.91;
        } else {
          // LAVA: Incandescent golden-orange molten river with floating dark obsidian crust plates!
          float scr = time * vFlow.y;
          vec2 uvFlow = vec2(vUv.x * 5.0, vUv.y * 2.3 - scr * (0.65 + 0.45 * shore));
          float warp = vn(uvFlow * 1.5 + vec2(0.0, -scr * 0.35));
          float magma = vn(uvFlow + warp * 1.35) * 0.6 + vn(uvFlow * 2.6 - warp) * 0.4;
          if (soft < 0.5) magma = floor(magma * 5.0) / 5.0;
          float heat = clamp(magma * (0.58 + 0.66 * shore) + 0.12 * sin(time * 2.2 + vUv.y * 4.0), 0.0, 1.15);
          col = mix(vec3(0.05, 0.025, 0.03), vec3(0.95, 0.12, 0.01), smoothstep(0.24, 0.46, heat));
          col = mix(col, vec3(1.95, 0.64, 0.05), smoothstep(0.45, 0.72, heat));
          col = mix(col, vec3(2.85, 2.1, 0.62), smoothstep(0.72, 0.96, heat));
          alpha = edgeA * endA * 0.96;
        }

        float dist = length(vW - cameraPosition);
        col = mix(col, fogC, clamp(1.0 - exp(-fogD * fogD * dist * dist), 0.0, 1.0));
        gl_FragColor = vec4(col, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })
}

export function buildCanyonScenery(arena, { planet, pal, bandsLin, sunDir, sunCol, ambCol, fogHex, fogDensity, soft, tod, mistTexture }) {
  const group = new THREE.Group()
  group.name = `canyon-scenery-${planet}`
  const rnd = mulberry32(Math.round(arena.opts.seed) * 5179 + (planet === 'ice' ? 41 : planet === 'lava' ? 89 : 13))
  const { cells: n, C, ox, oz } = arena
  const isDesert = planet === 'desert'
  const isIce = planet === 'ice'
  const isLava = planet === 'lava'

  const sampleEdge = (x, z) => {
    const i = clamp(Math.floor((x - ox) / C), 0, n - 1)
    const j = clamp(Math.floor((z - oz) / C), 0, n - 1)
    return arena.edge[j * n + i]
  }

  // ── 1. RIVERS & EXPANSIVE OASIS / GEOTHERMAL / MAGMA LAGOONS
  const streamMat = createCanyonStreamMaterial({ planetId: pal.id, sunDir, sunCol, fogColor: fogHex, fogDensity, soft, tod })
  const animMist = []
  const animRings = []

  for (const rv of arena.rivers || []) {
    const pts = smoothStreamPts(rv.pts, 4.0)
    if (pts.length < 3) continue
    const rows = pts.length, cols = 11
    const pos = new Float32Array(rows * cols * 3)
    const uv = new Float32Array(rows * cols * 2)
    const flow = new Float32Array(rows * cols * 2)
    const idx = []
    let dist = 0
    for (let i = 0; i < rows; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(rows - 1, i + 1)]
      const l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / l, rz = (b[0] - a[0]) / l
      if (i > 0) dist += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
      const progress = i / (rows - 1)
      const hw = pts[i][2]
      for (let c = 0; c < cols; c++) {
        const u = c / (cols - 1)
        const across = u * 2 - 1
        const x = pts[i][0] + rx * across * hw
        const z = pts[i][1] + rz * across * hw
        const v = i * cols + c
        pos[v * 3] = x
        pos[v * 3 + 1] = arena.groundAt(x, z) + 0.62
        pos[v * 3 + 2] = z
        uv[v * 2] = u
        uv[v * 2 + 1] = dist / 32
        flow[v * 2] = progress
        flow[v * 2 + 1] = rv.flowSpeed
        if (i < rows - 1 && c < cols - 1) idx.push(v, v + cols, v + 1, v + 1, v + cols, v + cols + 1)
      }
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
    g.setAttribute('aFlow', new THREE.BufferAttribute(flow, 2))
    g.setIndex(idx)
    g.computeBoundingSphere()
    const m = new THREE.Mesh(g, streamMat)
    m.renderOrder = 4
    group.add(m)
  }

  for (let li = 0; li < (arena.lagoons || []).length; li++) {
    const lg = arena.lagoons[li]
    const rings = 8, segs = 34
    const total = 1 + rings * segs
    const pos = new Float32Array(total * 3)
    const uv = new Float32Array(total * 2)
    const flow = new Float32Array(total * 2)
    const idx = []
    const cs = Math.cos(lg.rot), sn = Math.sin(lg.rot)
    const baseY = arena.groundAt(lg.x, lg.z) + 0.68
    pos[0] = lg.x; pos[1] = baseY; pos[2] = lg.z
    uv[0] = 0.5; uv[1] = 0; flow[0] = 0.5; flow[1] = 0.42
    for (let r = 1; r <= rings; r++) {
      const rf = r / rings
      for (let s = 0; s < segs; s++) {
        const a = (s / segs) * Math.PI * 2
        const wob = 1 + 0.11 * Math.sin(a * 3 + li) + 0.06 * Math.cos(a * 5 - li)
        const lx = Math.cos(a) * lg.rx * rf * wob, lz = Math.sin(a) * lg.rz * rf * wob
        const wx = lg.x + lx * cs - lz * sn, wz = lg.z + lx * sn + lz * cs
        const v = 1 + (r - 1) * segs + s
        pos[v * 3] = wx
        pos[v * 3 + 1] = Math.max(baseY, arena.groundAt(wx, wz) + 0.54)
        pos[v * 3 + 2] = wz
        uv[v * 2] = 0.5 * (1 - rf)
        uv[v * 2 + 1] = (wx * cs + wz * sn) / 28
        flow[v * 2] = 0.5; flow[v * 2 + 1] = 0.42
      }
    }
    for (let s = 0; s < segs; s++) idx.push(0, 1 + s, 1 + ((s + 1) % segs))
    for (let r = 1; r < rings; r++) {
      const bA = 1 + (r - 1) * segs, bB = 1 + r * segs
      for (let s = 0; s < segs; s++) {
        const s2 = (s + 1) % segs
        idx.push(bA + s, bB + s, bA + s2, bA + s2, bB + s, bB + s2)
      }
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
    g.setAttribute('aFlow', new THREE.BufferAttribute(flow, 2))
    g.setIndex(idx)
    g.computeBoundingSphere()
    const m = new THREE.Mesh(g, streamMat)
    m.renderOrder = 4
    group.add(m)

    // Soft glowing geothermal steam (Ice), golden oasis spray (Desert), or molten ember mist (Lava) over lagoons
    for (let q = 0; q < 2; q++) {
      const sp = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: mistTexture,
          color: isLava ? '#ff7a24' : isIce ? '#c8fff8' : '#e4fffc',
          transparent: true,
          opacity: isLava ? 0.24 : 0.18,
          blending: isLava ? THREE.AdditiveBlending : THREE.NormalBlending,
          depthWrite: false,
        }),
      )
      const sc = 36 + rnd() * 24
      sp.position.set(lg.x + (q - 0.5) * 18, baseY + 5 + q * 3, lg.z + (rnd() - 0.5) * 14)
      sp.scale.set(sc * 1.3, sc * 0.7, 1)
      group.add(sp)
      animMist.push({ sp, sc, baseY: sp.position.y, ph: rnd() * 6.28, rise: isLava ? 2.2 : 0.9, wide: true })
    }
  }

  // ── 2. CLIFF WATERFALLS (Havasu Falls in Desert! Crystal Glacial Falls in Ice! Roaring Magma Falls in Lava!)
  const cascadeMat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    uniforms: {
      time: { value: 0 },
      isLava: { value: isLava ? 1 : 0 },
      fogC: { value: new THREE.Color(fogHex) },
      fogD: { value: fogDensity },
      soft: { value: soft ? 1 : 0 },
    },
    vertexShader: 'varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
    fragmentShader: `
      uniform float time, isLava, fogD, soft;
      uniform vec3 fogC;
      varying vec2 vUv; varying vec3 vW;
      float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float vn(vec2 p){
        vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
      }
      void main() {
        float edge = smoothstep(0.0, 0.22, vUv.x) * smoothstep(1.0, 0.78, vUv.x);
        float speed = isLava > 0.5 ? 2.0 : 3.4;
        float s1 = vn(vec2(vUv.x * 10.0, vUv.y * 34.0 - time * speed));
        float s2 = vn(vec2(vUv.x * 24.0 + 4.1, vUv.y * 68.0 - time * speed * 1.65));
        float k = s1 * 0.6 + s2 * 0.4 + smoothstep(0.86, 1.0, vUv.y) * 0.4;
        if (soft < 0.5) k = floor(k * 4.0) / 4.0;
        vec3 col;
        if (isLava > 0.5) {
          col = mix(vec3(0.55, 0.06, 0.02), vec3(1.8, 0.45, 0.03), smoothstep(0.2, 0.58, k));
          col = mix(col, vec3(2.9, 1.95, 0.48), smoothstep(0.58, 0.92, k));
        } else {
          // Sparkling Havasu turquoise-to-pure-white foaming cliff waterfall!
          col = mix(vec3(0.22, 0.85, 0.88), vec3(1.0), smoothstep(0.28, 0.78, k));
        }
        float d = length(vW - cameraPosition);
        col = mix(col, fogC, clamp(1.0 - exp(-fogD * fogD * d * d), 0.0, 1.0));
        float a = edge * smoothstep(0.0, 0.06, vUv.y) * (0.62 + 0.34 * s1);
        gl_FragColor = vec4(col, a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })
  {
    const fallStarts = []
    const wantFalls = isLava ? 14 : 10
    for (let tries = 0; tries < 2600 && fallStarts.length < wantFalls; tries++) {
      const i = 12 + Math.floor(rnd() * (n - 24)), j = 12 + Math.floor(rnd() * (n - 24))
      const e = arena.edge[j * n + i]
      if (e < -2 || e > 2.5) continue
      const x = ox + (i + 0.5) * C, z = oz + (j + 0.5) * C
      const footY = arena.groundAt(x, z)
      // In Desert & Ice, concentrate waterfalls dramatically in the low oasis/fjord basins!
      if (!isLava && footY > 30) continue
      if (fallStarts.some((s) => Math.hypot(s[0] - x, s[1] - z) < 135)) continue
      const pts = [[x, z]]
      let cx = x, cz = z, reached = false
      for (let st = 0; st < 85; st++) {
        const gx = sampleEdge(cx + C * 2, cz) - sampleEdge(cx - C * 2, cz)
        const gz = sampleEdge(cx, cz + C * 2) - sampleEdge(cx, cz - C * 2)
        const gl = Math.hypot(gx, gz)
        if (gl < 1e-3) break
        cx += (gx / gl) * C * 1.08; cz += (gz / gl) * C * 1.08
        pts.push([cx, cz])
        if (sampleEdge(cx, cz) > 86) { reached = true; break }
      }
      if (!reached) continue
      const top = pts[pts.length - 1]
      if (arena.groundAt(top[0], top[1]) - footY < 45) continue
      fallStarts.push([x, z])
      const S = smoothStreamPts(pts.map((q) => [q[0], q[1], 8]), 3.0)
      const m = S.length
      if (m < 6) continue
      const pos = new Float32Array(m * 2 * 3)
      const uv = new Float32Array(m * 2 * 2)
      const idx = []
      const baseW = 6.5 + rnd() * 5.0
      for (let r = 0; r < m; r++) {
        const a = S[Math.max(0, r - 1)], b = S[Math.min(m - 1, r + 1)]
        const dl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
        const rx = -(b[1] - a[1]) / dl, rz = (b[0] - a[0]) / dl
        const w = baseW * (0.72 + 0.45 * (1 - r / m))
        for (let sd = 0; sd < 2; sd++) {
          const px = S[r][0] + rx * w * (sd ? 1 : -1)
          const pz = S[r][1] + rz * w * (sd ? 1 : -1)
          const o = (r * 2 + sd) * 3
          pos[o] = px; pos[o + 1] = arena.groundAt(px, pz) + 1.05; pos[o + 2] = pz
          uv[(r * 2 + sd) * 2] = sd; uv[(r * 2 + sd) * 2 + 1] = 1 - r / (m - 1)
        }
        if (r < m - 1) { const a0 = r * 2; idx.push(a0, a0 + 2, a0 + 1, a0 + 1, a0 + 2, a0 + 3) }
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
      g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
      g.setIndex(idx)
      g.computeBoundingSphere()
      const fm = new THREE.Mesh(g, cascadeMat)
      fm.renderOrder = 5
      group.add(fm)

      // Rolling mist cloud at waterfall plunge pool
      for (let q = 0; q < 3; q++) {
        const sp = new THREE.Sprite(
          new THREE.SpriteMaterial({
            map: mistTexture,
            color: isLava ? (q === 0 ? '#ffb038' : '#ff4c14') : '#e6ffff',
            transparent: true,
            opacity: isLava ? 0.28 : 0.3,
            blending: isLava ? THREE.AdditiveBlending : THREE.NormalBlending,
            depthWrite: false,
          }),
        )
        const sc = 34 + rnd() * 24
        sp.position.set(x + (rnd() - 0.5) * 18, footY + 5 + q * 3, z + (rnd() - 0.5) * 18)
        sp.scale.setScalar(sc)
        group.add(sp)
        animMist.push({ sp, sc, baseY: sp.position.y, ph: rnd() * 6.28, rise: 1.5 })
      }
    }
  }

  // ── 3. ALTERNATING HERO LANDMARKS: NATURAL CANYON BRIDGES & SLEEK SCI-FI MEGASTRUCTURE RINGS!
  // Gives every sector its own unforgettable silhouette:
  // - Low gorges: majestic sweeping Natural Sandstone / Sapphire-Glacier / Magma-Obsidian Bridges
  // - High mesa passes: colossal sleek Sci-Fi Orbital Energy Rings (Wipeout / Star Wars / Horizon feel!)
  const archMat = createCanyonArchMaterial({
    bands: bandsLin, sunDir, sunCol, ambCol, fogColor: fogHex, fogDensity, soft, planetId: pal.id,
  })
  const megaHull = new THREE.MeshStandardMaterial({
    color: isDesert ? '#f2ece2' : isIce ? '#dceefa' : '#1b222c',
    roughness: 0.26,
    metalness: 0.72,
  })
  const megaAccent = new THREE.MeshStandardMaterial({
    color: isDesert ? '#d8963c' : isIce ? '#4a88c8' : '#3a4658',
    roughness: 0.3,
    metalness: 0.78,
  })
  const megaGlow = new THREE.MeshBasicMaterial({
    color: isLava ? '#28f4ff' : isIce ? '#52ffda' : '#38f2ff',
  })

  let archCount = 0
  for (let seg = 0; seg < arena.n; seg++) {
    const p = arena.paths[seg]
    if (p.pts.length < 16) continue
    const idxP = clamp(Math.floor(p.pts.length * 0.5), 5, p.pts.length - 6)
    const q = p.pts[idxP], a = p.pts[idxP - 2], b = p.pts[idxP + 2]
    if (arena.gates.some((g) => Math.hypot(g.x - q[0], g.z - q[1]) < 72)) continue
    const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
    const yaw = Math.atan2(-(b[0] - a[0]) / tl, -(b[1] - a[1]) / tl)
    const gy = arena.groundAt(q[0], q[1])

    if (gy > 32 && seg % 2 === 1) {
      // HIGH PASS LANDMARK: Colossal Sleek Sci-Fi Canyon Hydro/Solar/Geo-Reactor Ring Arch!
      const mg = new THREE.Group()
      mg.position.set(q[0], gy, q[1])
      mg.rotation.y = yaw
      const rad = p.halfW + 14
      const outerArc = new THREE.Mesh(new THREE.TorusGeometry(rad, 3.2, 10, 48, Math.PI), megaHull)
      outerArc.scale.set(1, 0.86, 1.35)
      const trimArc = new THREE.Mesh(new THREE.TorusGeometry(rad + 2.8, 1.1, 8, 48, Math.PI), megaAccent)
      trimArc.scale.set(1, 0.86, 1.5)
      const energyArc = new THREE.Mesh(new THREE.TorusGeometry(rad - 2.9, 0.85, 8, 48, Math.PI), megaGlow)
      energyArc.scale.set(1, 0.86, 1.0)
      // Rotating floating sci-fi halo ring suspended at the crown of the megastructure!
      const crownRing = new THREE.Mesh(new THREE.TorusGeometry(9.5, 0.65, 8, 28), megaGlow)
      crownRing.position.set(0, rad * 0.86 + 11, 0)
      mg.add(outerArc, trimArc, energyArc, crownRing)
      group.add(mg)
      animRings.push(crownRing)
    } else {
      // DEEP GORGE LANDMARK: Sweeping Natural Stratified Rock / Sapphire-Glacier / Magma-Obsidian Bridge!
      const span = p.halfW + 16 + rnd() * 10
      const archH = 48 + rnd() * 24
      const thick = 6.2 + rnd() * 2.4
      const archMesh = new THREE.Mesh(
        naturalBridgeGeometry(span, archH, thick, archCount * 2.7 + 1.1, isLava ? 0.3 : 0.2),
        archMat,
      )
      archMesh.position.set(q[0], gy, q[1])
      archMesh.rotation.y = yaw + (rnd() - 0.5) * 0.32
      group.add(archMesh)
    }
    archCount++
  }

  // Also arch intimate natural bridges over selected shortcut gorges
  for (const p of arena.paths) {
    if (p.kind !== 'cut' || p.pts.length < 16 || p.id % 2 !== 0) continue
    const idxP = Math.floor(p.pts.length * 0.5)
    const q = p.pts[idxP], a = p.pts[idxP - 2], b = p.pts[idxP + 2]
    const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
    const archMesh = new THREE.Mesh(naturalBridgeGeometry(p.halfW + 11, 36 + rnd() * 12, 4.8, p.id * 3.1, 0.22), archMat)
    archMesh.position.set(q[0], arena.groundAt(q[0], q[1]), q[1])
    archMesh.rotation.y = Math.atan2(-(b[0] - a[0]) / tl, -(b[1] - a[1]) / tl)
    group.add(archMesh)
    archCount++
  }

  // ── 4. RICH SUB-BIOME FLORA, CRYSTAL GEODES, AURORA & VOLCANIC PLUMES (100% POLE-FREE!)
  const animFns = []
  const boulderGeo = smoothBoulderGeo()

  if (isDesert) {
    // Lush Oasis Umbrella Acacia Canopies, Vibrant Magenta/Gold Bougainvillea Gardens & River Stones!
    const canopies = []
    const trunks = []
    const flowers = []
    const riverRocks = []
    const greenPalette = ['#2d9a48', '#3db24c', '#54c048', '#68c84a', '#268c52']
    const bloomPalette = ['#ff529a', '#ffc838', '#ff7842', '#e868ff']

    const plantOasisTree = (x, z, big = true) => {
      const i = clamp(Math.floor((x - ox) / C), 0, n - 1)
      const j = clamp(Math.floor((z - oz) / C), 0, n - 1)
      if (arena.edge[j * n + i] < -3 && arena.lat[j * n + i] < 0.78) return
      if (arena.riverAt(x, z) > 0.43) return
      if (trunks.some((t) => Math.hypot(t.x - x, t.z - z) < 11)) return
      const y = arena.groundAt(x, z)
      if (y > 34) return
      const h = big ? 11 + rnd() * 9 : 6 + rnd() * 5
      const r = big ? 8.5 + rnd() * 5.5 : 4.5 + rnd() * 3.0
      const rot = rnd() * 6.28
      // Short sturdy natural desert acacia trunk hidden gracefully beneath a wide lush umbrella canopy!
      trunks.push({ x, y: y - 0.5, z, sx: r * 0.11, sy: h * 0.85, sz: r * 0.11, rx: 0.08, ry: rot, col: '#6d5038' })
      canopies.push({ x, y: y + h * 0.88, z, sx: r, sy: r * 0.52, sz: r * 0.94, ry: rot, col: greenPalette[Math.floor(rnd() * greenPalette.length)] })
      canopies.push({
        x: x + Math.cos(rot) * r * 0.45,
        y: y + h * 0.78,
        z: z + Math.sin(rot) * r * 0.45,
        sx: r * 0.68, sy: r * 0.42, sz: r * 0.65, ry: rot + 1.2,
        col: greenPalette[Math.floor(rnd() * greenPalette.length)],
      })
      // Colorful flowering desert bougainvillea bush cushioned at the base!
      if (rnd() < 0.68) {
        const fs = 2.4 + rnd() * 2.2
        flowers.push({
          x: x + Math.cos(rot + 2.2) * (r * 0.55),
          y: y + fs * 0.25,
          z: z + Math.sin(rot + 2.2) * (r * 0.55),
          sx: fs * 1.2, sy: fs * 0.75, sz: fs * 1.1, ry: rnd() * 6.28,
          col: bloomPalette[Math.floor(rnd() * bloomPalette.length)],
        })
      }
    }

    for (const lg of arena.lagoons || []) {
      const cs = Math.cos(lg.rot), sn = Math.sin(lg.rot)
      for (let k = 0; k < 18; k++) {
        const a = (k / 18) * Math.PI * 2 + rnd() * 0.2
        const lx = Math.cos(a) * (lg.rx + 5 + rnd() * 14)
        const lz = Math.sin(a) * (lg.rz + 5 + rnd() * 14)
        const wx = lg.x + lx * cs - lz * sn, wz = lg.z + lx * sn + lz * cs
        plantOasisTree(wx, wz, k % 3 !== 0)
        if (k % 2 === 0) {
          const rs = 2.2 + rnd() * 3.4
          riverRocks.push({ x: lg.x + lx * 0.88 * cs - lz * 0.88 * sn, y: arena.groundAt(wx, wz) + rs * 0.2, z: lg.z + lx * 0.88 * sn + lz * 0.88 * cs, sx: rs * 1.2, sy: rs * 0.7, sz: rs, ry: rnd() * 6.28, col: '#b87650' })
        }
      }
    }
    for (const rv of arena.rivers || []) {
      for (let i = 1; i < rv.pts.length - 1; i += 2) {
        const a = rv.pts[Math.max(0, i - 1)], b = rv.pts[Math.min(rv.pts.length - 1, i + 1)], q = rv.pts[i]
        const l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
        const rx = -(b[1] - a[1]) / l, rz = (b[0] - a[0]) / l
        for (const sd of [-1, 1]) {
          const bx = q[0] + rx * sd * (q[2] + 6 + rnd() * 12)
          const bz = q[1] + rz * sd * (q[2] + 6 + rnd() * 12)
          if (rnd() < 0.68) plantOasisTree(bx, bz, rnd() < 0.65)
        }
      }
    }
    // Low desert sage & golden rabbitbrush cushions tucked along high sunlit canyon ledges
    for (let j = 8; j < n - 8; j += 3) {
      for (let i = 8; i < n - 8; i += 3) {
        const e = arena.edge[j * n + i]
        if (e < 5 || e > 58 || rnd() > 0.08 || canopies.length > 900) continue
        const x = ox + (i + rnd()) * C, z = oz + (j + rnd()) * C
        const s = 2.2 + rnd() * 3.2
        canopies.push({
          x, y: arena.groundAt(x, z) + s * 0.2, z,
          sx: s * 1.25, sy: s * 0.65, sz: s * 1.15, ry: rnd() * 6.28,
          col: rnd() < 0.45 ? '#6ea652' : rnd() < 0.78 ? '#c8a646' : '#4b9850',
        })
      }
    }

    const padGeo = smoothCanopyPadGeo()
    addInstanced(group, new THREE.CylinderGeometry(0.55, 1.05, 1, 7).translate(0, 0.5, 0), new THREE.MeshLambertMaterial({ color: '#ffffff' }), trunks)
    addInstanced(group, padGeo, new THREE.MeshLambertMaterial({ color: '#ffffff' }), canopies)
    addInstanced(group, padGeo, new THREE.MeshLambertMaterial({ color: '#ffffff' }), flowers)
    addInstanced(group, boulderGeo, new THREE.MeshLambertMaterial({ color: '#ffffff' }), riverRocks)

    // Soaring Canyon Eagles gliding peacefully above the mesas
    const eagles = []
    const wingGeo = new THREE.PlaneGeometry(3.2, 1.1).rotateX(-Math.PI / 2).translate(1.6, 0, 0)
    const eagleMat = new THREE.MeshBasicMaterial({ color: tod === 'night' ? '#b8d0ff' : '#3d2214', side: THREE.DoubleSide })
    for (let e = 0; e < 12; e++) {
      const gt = arena.gates[e % arena.gates.length]
      const eg = new THREE.Group()
      const lw = new THREE.Mesh(wingGeo, eagleMat), rw = new THREE.Mesh(wingGeo, eagleMat)
      rw.rotation.y = Math.PI
      eg.add(lw, rw)
      group.add(eg)
      eagles.push({ grp: eg, lw, rw, cx: gt.x, cz: gt.z, y: 112 + rnd() * 44, r: 80 + rnd() * 55, a0: rnd() * 6.28, w: (e % 2 ? 1 : -1) * (0.12 + rnd() * 0.05), ph: rnd() * 6.28 })
    }
    animFns.push((t) => {
      for (const eg of eagles) {
        const a = eg.a0 + t * eg.w
        eg.grp.position.set(eg.cx + Math.cos(a) * eg.r, eg.y + Math.sin(t * 0.5 + eg.ph) * 4, eg.cz + Math.sin(a) * eg.r)
        eg.grp.rotation.y = -a + (eg.w > 0 ? 0 : Math.PI)
        const flap = Math.sin(t * 3.2 + eg.ph) * 0.22 + 0.08
        eg.lw.rotation.z = flap; eg.rw.rotation.z = flap
      }
    })
  }

  if (isIce) {
    // Radiant Amethyst, Rose-Quartz & Aquamarine Crystal Geode Clusters tucked along glacial canyon shelves!
    const geodes = []
    const snowCushions = []
    const jewelCols = ['#56f4ff', '#c27aff', '#ff7ad8', '#4effc8', '#8ad8ff']
    for (let j = 8; j < n - 8; j += 3) {
      for (let i = 8; i < n - 8; i += 3) {
        const e = arena.edge[j * n + i]
        if (e < 6 || e > 88 || rnd() > 0.065 || geodes.length > 520) continue
        const cx0 = ox + (i + rnd()) * C, cz0 = oz + (j + rnd()) * C
        const g0 = arena.groundAt(cx0, cz0)
        // Alternate amethyst-rose cavern zones and aquamarine crystal zones across the map!
        const zone = Math.sin(cx0 * 0.003 + cz0 * 0.0025)
        const col = zone > 0.15 ? (rnd() < 0.6 ? '#c27aff' : '#ff7ad8') : jewelCols[Math.floor(rnd() * jewelCols.length)]
        for (let q = 0; q < 3; q++) {
          const s = (q === 0 ? 5.5 : 3.4) + rnd() * 4.5
          const a = (q / 3) * Math.PI * 2 + rnd() * 0.6
          geodes.push({
            x: cx0 + Math.cos(a) * s * 0.35,
            y: g0 - 0.8,
            z: cz0 + Math.sin(a) * s * 0.35,
            sx: s * 0.72, sy: s * 1.15, sz: s * 0.72,
            rx: q === 0 ? 0.12 : 0.42, ry: a, rz: 0,
            col,
          })
        }
        if (rnd() < 0.55) {
          const ps = 4.5 + rnd() * 4.5
          snowCushions.push({ x: cx0 + 7, y: g0 + ps * 0.25, z: cz0, sx: ps, sy: ps * 0.65, sz: ps, ry: rnd() * 6.28, col: rnd() < 0.5 ? '#2e7e78' : '#4ca69c' })
        }
      }
    }
    addInstanced(
      group,
      geodeCrystalGeo(),
      new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.12, metalness: 0.2, emissive: new THREE.Color('#2a4888'), emissiveIntensity: 0.62 }),
      geodes,
    )
    addInstanced(group, smoothCanopyPadGeo(), new THREE.MeshLambertMaterial({ color: '#ffffff' }), snowCushions)

    // Sweeping Volumetric Aurora Borealis Curtains dancing across the polar canyon sky!
    const auroraMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      fog: false,
      uniforms: { time: { value: 0 }, uIntensity: { value: tod === 'night' ? 0.88 : tod === 'sunset' ? 0.55 : 0.42 } },
      vertexShader: `
        uniform float time; varying vec2 vUv;
        void main() {
          vUv = uv;
          vec3 p = position;
          p.x += sin(uv.x * 18.84955 + time * 0.45) * 90.0 * (0.4 + 0.6 * uv.y);
          p.z += cos(uv.x * 12.56637 + time * 0.35) * 80.0;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        }`,
      fragmentShader: `
        uniform float time, uIntensity; varying vec2 vUv;
        void main() {
          float rays = 0.5 + 0.5 * sin(vUv.x * 130.0 + time * 1.4 + sin(vUv.x * 32.0 - time * 0.6) * 3.0);
          float curtain = smoothstep(0.0, 0.18, vUv.y) * pow(1.0 - vUv.y, 1.65);
          float bandMask = smoothstep(0.18, 0.85, 0.5 + 0.5 * sin(vUv.x * 18.84955 + time * 0.22));
          vec3 col = mix(vec3(0.08, 1.0, 0.68), vec3(0.14, 0.78, 1.0), smoothstep(0.12, 0.5, vUv.y));
          col = mix(col, vec3(0.76, 0.26, 1.0), smoothstep(0.48, 0.92, vUv.y));
          float a = curtain * (0.38 + 0.62 * pow(rays, 1.5)) * bandMask * uIntensity;
          if (a < 0.008) discard;
          gl_FragColor = vec4(col * a, a);
        }`,
    })
    const cx0 = ox + arena.size * 0.5, cz0 = oz + arena.size * 0.5
    for (let r = 0; r < 2; r++) {
      const aurMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(arena.size * (0.46 + r * 0.18), arena.size * (0.5 + r * 0.18), 460, 128, 6, true),
        auroraMat,
      )
      aurMesh.position.set(cx0, 470 + r * 110, cz0)
      aurMesh.rotation.y = r * 1.7
      aurMesh.frustumCulled = false
      aurMesh.renderOrder = 3
      group.add(aurMesh)
    }
    animFns.push((t) => { auroraMat.uniforms.time.value = t })
  }

  if (isLava) {
    // Sculpted Glowing Magma-Geode Boulders, Contrast Teal-Gold Mineral Formations & Lit Volcanic Caldera Clouds!
    const emberRocks = []
    const mineralGems = []
    for (let j = 8; j < n - 8; j += 3) {
      for (let i = 8; i < n - 8; i += 3) {
        const e = arena.edge[j * n + i]
        if (e < 6 || e > 88 || rnd() > 0.06 || emberRocks.length > 420) continue
        const x = ox + (i + rnd()) * C, z = oz + (j + rnd()) * C
        const y = arena.groundAt(x, z)
        const s = 3.5 + rnd() * 5.8
        emberRocks.push({ x, y: y + s * 0.15, z, sx: s * 1.25, sy: s * 0.85, sz: s, ry: rnd() * 6.28, col: '#221820' })
        if (rnd() < 0.58) {
          const gs = s * 0.58
          const isTealZone = Math.sin(x * 0.0032 - z * 0.0028) > 0.25
          mineralGems.push({
            x, y: y + s * 0.3, z, sx: gs, sy: gs * 1.15, sz: gs,
            rx: 0.25, ry: rnd() * 6.28, rz: 0,
            col: isTealZone ? '#2ef2d8' : rnd() < 0.5 ? '#ff9418' : '#ffd838',
          })
        }
      }
    }
    addInstanced(group, boulderGeo, new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.4, metalness: 0.45 }), emberRocks)
    addInstanced(group, geodeCrystalGeo(), new THREE.MeshBasicMaterial({ color: '#ffffff' }), mineralGems)

    // Billowing Fire-Lit Volcanic Caldera Clouds crowning the surrounding volcanoes
    for (const pk of (arena.peaks || []).filter((p) => p.kind !== 'karst').slice(0, 12)) {
      for (let c = 0; c < 2; c++) {
        const sp = new THREE.Sprite(
          new THREE.SpriteMaterial({
            map: mistTexture,
            color: c === 0 ? '#ff7222' : '#582c2c',
            transparent: true,
            opacity: c === 0 ? 0.34 : 0.24,
            blending: c === 0 ? THREE.AdditiveBlending : THREE.NormalBlending,
            depthWrite: false,
          }),
        )
        const sc = 92 + c * 55
        sp.position.set(pk.x + (rnd() - 0.5) * 24, pk.y + 10 + c * 32, pk.z + (rnd() - 0.5) * 24)
        sp.scale.set(sc * 1.35, sc * 0.72, 1)
        group.add(sp)
        animMist.push({ sp, sc, baseY: sp.position.y, ph: rnd() * 6.28, rise: 4.0, wide: true })
      }
    }
  }

  return {
    group,
    archCount,
    update(time) {
      streamMat.uniforms.time.value = time
      archMat.uniforms.time.value = time
      cascadeMat.uniforms.time.value = time
      for (const fn of animFns) fn(time)
      for (let i = 0; i < animRings.length; i++) {
        animRings[i].rotation.y = time * 0.8 + i
        animRings[i].rotation.z = Math.sin(time * 1.4 + i) * 0.25
      }
      for (const m of animMist) {
        const pulse = 1 + 0.08 * Math.sin(time * 1.0 + m.ph)
        if (m.wide) m.sp.scale.set(m.sc * 1.32 * pulse, m.sc * 0.72 * pulse, 1)
        else m.sp.scale.setScalar(m.sc * pulse)
        m.sp.position.y = m.baseY + Math.sin(time * 0.65 + m.ph) * m.rise
      }
    },
    dispose() {
      const geos = new Set(), mats = new Set(), texs = new Set()
      group.traverse((o) => {
        if (o.geometry && !o.isSprite) geos.add(o.geometry)
        if (o.material) {
          for (const mt of Array.isArray(o.material) ? o.material : [o.material]) {
            mats.add(mt)
            if (mt.map && mt.map !== mistTexture) texs.add(mt.map)
          }
        }
      })
      geos.forEach((g) => g.dispose())
      mats.forEach((m) => m.dispose())
      texs.forEach((t) => t.dispose())
    },
  }
}
