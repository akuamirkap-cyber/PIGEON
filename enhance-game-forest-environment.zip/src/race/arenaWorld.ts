// @ts-nocheck
// Draws the arena. The canyon is one smooth surface, shaded in a shader: sandstone layers that undulate along the walls,
// scree at their feet, rippled sand, pools, soft shadows from the cliffs. Scenery is kept simple and clean:
// faceted boulders, a few shrubs or crystals, distant ranges, drifting dust.
import * as THREE from 'three'
import { makeSky, SKY_PAL, FOG_COL } from './sky'
import { buildRainforest } from './rainforest'
import { buildForestRapids } from './forestRapids'
import { buildRouteGuide } from './routeGuide'
import { buildCanyonScenery } from './canyonScenery'
import { buildArenaHazards } from './hazards'

function mulberry32(a) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const smooth = (a, b, v) => {
  const t = clamp((v - a) / (b - a), 0, 1)
  return t * t * (3 - 2 * t)
}
const mixc = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k]
const tmpC = new THREE.Color()
const lin3 = (c) => {
  tmpC.setRGB(clamp(c[0], 0, 255) / 255, clamp(c[1], 0, 255) / 255, clamp(c[2], 0, 255) / 255, THREE.SRGBColorSpace)
  return new THREE.Vector3(tmpC.r, tmpC.g, tmpC.b)
}
const col3 = (c) => new THREE.Color().setRGB(clamp(c[0], 0, 255) / 255, clamp(c[1], 0, 255) / 255, clamp(c[2], 0, 255) / 255, THREE.SRGBColorSpace)

function tex(w, h, draw, soft) {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  draw(c.getContext('2d'), w, h)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  if (soft) {
    t.magFilter = THREE.LinearFilter
    t.minFilter = THREE.LinearMipmapLinearFilter
  } else {
    t.magFilter = THREE.NearestFilter
    t.minFilter = THREE.NearestFilter
    t.generateMipmaps = false
  }
  return t
}

let softDotTex = null
function makeSoftDot() {
  if (softDotTex) return softDotTex
  softDotTex = tex(64, 64, (g, w, h) => {
    const grd = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2)
    grd.addColorStop(0, 'rgba(255,255,255,1)')
    grd.addColorStop(0.4, 'rgba(255,255,255,0.5)')
    grd.addColorStop(1, 'rgba(255,255,255,0)')
    g.fillStyle = grd
    g.fillRect(0, 0, w, h)
  }, true)
  softDotTex.minFilter = THREE.LinearFilter
  return softDotTex
}

// colours are 0..255 sRGB. bands run from the canyon floor up to the rim.
const PLANETS = {
  desert: {
    // Rich Navajo / Grand Canyon / Antelope Canyon sedimentary strata: crimson ironstone, burnt sienna, terracotta, warm ochre & cream sandstone
    bands: [[126, 46, 38], [174, 72, 46], [212, 104, 54], [236, 146, 78], [246, 188, 118], [250, 218, 162], [218, 132, 74], [162, 68, 48]],
    floor: [240, 202, 146], top: [216, 148, 94], high: [248, 216, 166], scree: [182, 108, 68], rock: [196, 112, 70],
    water: [36, 192, 198], green: [78, 154, 62], glow: null, dust: [255, 224, 168], id: 0,
    mount: [198, 102, 68], fog: { day: '#f2dac2', sunset: '#f7a46e', night: '#1f2e58' }, fogK: 0.78,
  },
  ice: {
    // Crystalline glacial fjord strata: deep cobalt glacier ice, sapphire blue, luminous aquamarine, frost silver & pure alpine snow
    bands: [[42, 92, 178], [68, 138, 218], [108, 184, 244], [168, 222, 255], [228, 246, 255], [132, 198, 246], [84, 152, 228], [54, 112, 196]],
    floor: [232, 246, 255], top: [242, 250, 255], high: [255, 255, 255], scree: [132, 186, 236], rock: [128, 182, 234],
    water: [56, 158, 246], green: null, glow: null, dust: [228, 248, 255], id: 1,
    mount: [96, 168, 232], fog: { day: '#cceaff', sunset: '#ebb4d4', night: '#12264e' }, fogK: 0.74,
  },
  lava: {
    // Dramatic volcanic obsidian & basalt caldera: glossy charcoal, roasted umber, iron rust, volcanic ash & incandescent magma!
    bands: [[28, 18, 22], [52, 26, 28], [86, 38, 34], [124, 54, 38], [64, 30, 30], [38, 22, 26], [148, 68, 42], [92, 42, 34]],
    floor: [58, 36, 36], top: [92, 52, 44], high: [152, 86, 58], scree: [78, 44, 38], rock: [68, 38, 36],
    water: null, green: null, glow: [255, 118, 24], dust: [255, 156, 52], id: 2,
    mount: [118, 46, 38], fog: { day: '#5a2d28', sunset: '#6e2820', night: '#2b1218' }, fogK: 0.84,
  },
  forest: {
    bands: [[58, 76, 62], [76, 92, 70], [94, 106, 78], [112, 118, 86], [74, 96, 70], [60, 82, 66], [102, 112, 82], [70, 90, 70]],
    floor: [68, 138, 54], top: [44, 114, 52], high: [36, 102, 64], scree: [86, 106, 72], rock: [96, 104, 86],
    water: [24, 162, 158], green: [36, 122, 46], glow: null, dust: [255, 248, 198], id: 3, path: [118, 92, 62],
    mount: [38, 108, 76], fog: { day: '#b8dfd0', sunset: '#ebb286', night: '#112c3b' }, fogK: 0.88,
    falls: true, forest: true,
  },
}
const SUN = {
  day: { az: [0.5, 0.32], tan: 0.78, col: [1.0, 0.93, 0.8], k: 1.05, amb: [0.5, 0.6, 0.8], fog: 0.0006 },
  sunset: { az: [0.95, 0.5], tan: 0.36, col: [1.0, 0.56, 0.3], k: 1.12, amb: [0.56, 0.4, 0.64], fog: 0.00064 },
  night: { az: [0.3, 0.42], tan: 0.85, col: [0.45, 0.58, 1.0], k: 0.62, amb: [0.17, 0.23, 0.46], fog: 0.0007 },
}

// a rock: a rounded, faceted lump (the same corner always moves the same way, so the facets stay closed)
function rockGeometry(detail = 1) {
  const g = new THREE.IcosahedronGeometry(1, detail)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const k = Math.sin(Math.round(x * 90) * 12.9898 + Math.round(y * 90) * 78.233 + Math.round(z * 90) * 37.719) * 43758.5453
    const n = k - Math.floor(k)
    const s = 0.76 + 0.42 * n
    p.setXYZ(i, x * s, y * s, z * s)
  }
  g.computeVertexNormals()
  return g
}

export function buildArenaWorld(arena, theme, wopts) {
  const tod = theme in SKY_PAL ? theme : 'day'
  const soft = !!wopts.soft
  const pal = PLANETS[arena.opts.planet] || PLANETS.desert
  const softDot = makeSoftDot()
  const SUNC = SUN[tod]
  const fogHex = pal.fog ? pal.fog[tod] : FOG_COL[tod]
  const group = new THREE.Group()
  const { cells: n, C, ox, oz, hgt } = arena
  const Hc = (i, j) => hgt[clamp(j, 0, n - 1) * n + clamp(i, 0, n - 1)]

  // ── light: the same sun everywhere
  const sh0 = Math.hypot(SUNC.az[0], SUNC.az[1]) || 1
  const sx = -SUNC.az[0] / sh0
  const sz = -SUNC.az[1] / sh0
  const el = Math.atan(SUNC.tan)
  const toSun = new THREE.Vector3(sx * Math.cos(el), Math.sin(el), sz * Math.cos(el)).normalize()

  // ── per-column: shadow, cavity, pools
  const shadow = new Float32Array(n * n)
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const h0 = hgt[j * n + i]
      for (let st = 1; st <= 46; st++) {
        const ci = Math.round(i + sx * st)
        const cj = Math.round(j + sz * st)
        if (ci < 0 || cj < 0 || ci >= n || cj >= n) break
        if (hgt[cj * n + ci] > h0 + st * C * SUNC.tan + 1.5) { shadow[j * n + i] = 1; break }
      }
    }
  }
  {
    const c = shadow.slice()
    for (let j = 1; j < n - 1; j++) for (let i = 1; i < n - 1; i++) {
      const k = j * n + i
      shadow[k] = (c[k] * 4 + c[k - 1] * 2 + c[k + 1] * 2 + c[k - n] * 2 + c[k + n] * 2 + c[k - n - 1] + c[k - n + 1] + c[k + n - 1] + c[k + n + 1]) / 16
    }
  }
  const ring = [[3, 0], [-3, 0], [0, 3], [0, -3], [2, 2], [-2, 2], [2, -2], [-2, -2]]
  const poolN = (i, j) => (Math.sin(i * 0.11 + j * 0.061 + 2.0) + Math.sin(i * 0.043 - j * 0.1 + 0.7) + Math.sin(i * 0.19 + j * 0.17 + 4.1) * 0.6) / 2.6
  const poolV = new Float32Array(n * n)
  const greenV = new Float32Array(n * n)
  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const k = j * n + i
      if (arena.edge[k] > 0 || arena.lat[k] < 0.62) continue
      const pn = poolN(i, j)
      if (pal.water || pal.glow) poolV[k] = smooth(0.46, 0.62, pn)
      if (pal.green) greenV[k] = smooth(0.2, 0.4, pn) * (1 - poolV[k])
    }
  }

  // ── waterfalls: cascade down mossy cliffs & highland gullies into turquoise plunge pools
  const fallPaths = []
  if (pal.falls) {
    const rndW = mulberry32(Math.round(arena.opts.seed) * 211 + 3)
    const want = Math.round(clamp(arena.size / (pal.forest ? 185 : 330), 7, 18))
    const starts = []
    const edgeAt = (x, z) => arena.edge[clamp(Math.floor((z - oz) / C), 0, n - 1) * n + clamp(Math.floor((x - ox) / C), 0, n - 1)]
    for (let tries = 0; tries < 3600 && fallPaths.length < want; tries++) {
      const i = 12 + Math.floor(rndW() * (n - 24)), j = 12 + Math.floor(rndW() * (n - 24))
      const e = arena.edge[j * n + i]
      if (e < -3 || e > (pal.forest ? 18 : 1.5)) continue
      const x = ox + (i + 0.5) * C, z = oz + (j + 0.5) * C
      if (starts.some((s) => Math.hypot(s[0] - x, s[1] - z) < 135)) continue
      const pts = [[x, z]]
      let cx = x, cz = z, reached = false
      for (let s = 0; s < 105; s++) {
        const gx = edgeAt(cx + C * 2, cz) - edgeAt(cx - C * 2, cz)
        const gz = edgeAt(cx, cz + C * 2) - edgeAt(cx, cz - C * 2)
        const hx = arena.groundAt(cx + C * 2, cz) - arena.groundAt(cx - C * 2, cz)
        const hz2 = arena.groundAt(cx, cz + C * 2) - arena.groundAt(cx, cz - C * 2)
        const ux = gx + (pal.forest ? hx * 0.65 : 0), uz = gz + (pal.forest ? hz2 * 0.65 : 0)
        const gl = Math.hypot(ux, uz)
        if (gl < 1e-3) break
        cx += (ux / gl) * C * 1.15; cz += (uz / gl) * C * 1.15
        if (cx < ox + 28 || cz < oz + 28 || cx > ox + arena.size - 28 || cz > oz + arena.size - 28) break
        pts.push([cx, cz])
        if (edgeAt(cx, cz) > 105 && arena.groundAt(cx, cz) - arena.groundAt(x, z) > 36) { reached = true; break }
      }
      if (!reached) continue
      const top = pts[pts.length - 1]
      const drop = arena.groundAt(top[0], top[1]) - arena.groundAt(x, z)
      if (drop < (pal.forest ? 26 : 45)) continue
      starts.push([x, z])
      fallPaths.push({ pts, x, z, width: clamp(5.5 + drop * 0.06, 6, 12) })
      for (let dj = -4; dj <= 4; dj++) for (let di = -4; di <= 4; di++) {
        const ci = i + di, cj = j + dj
        if (ci < 0 || cj < 0 || ci >= n || cj >= n) continue
        if (Math.hypot(di, dj) * C < 32 && arena.edge[cj * n + ci] <= 6) poolV[cj * n + ci] = 1
      }
    }
  }

  // ── terrain shader: high-detail botanical moss, dappled golden canopy gobo, wet specular riverbanks & mossy basalt cliffs
  const terrainMat = new THREE.ShaderMaterial({
    uniforms: {
      bands: { value: pal.bands.map(lin3) },
      floorC: { value: lin3(pal.floor) }, topC: { value: lin3(pal.top) }, highC: { value: lin3(pal.high) }, screeC: { value: lin3(pal.scree) },
      greenC: { value: pal.green ? lin3(pal.green) : new THREE.Vector3() }, waterC: { value: pal.water ? lin3(pal.water) : new THREE.Vector3() },
      glowC: { value: pal.glow ? lin3(pal.glow) : new THREE.Vector3() },
      sunDir: { value: toSun }, sunCol: { value: new THREE.Vector3(...SUNC.col).multiplyScalar(SUNC.k) }, ambCol: { value: new THREE.Vector3(...SUNC.amb) },
      fogC: { value: new THREE.Color(fogHex) }, fogD: { value: SUNC.fog * (pal.fogK || 1) }, time: { value: 0 }, soft: { value: soft ? 1 : 0 },
      planet: { value: pal.id }, bandH: { value: 5.6 }, floorY: { value: 8 }, pathC: { value: pal.path ? lin3(pal.path) : new THREE.Vector3() },
    },
    vertexShader: `
      attribute vec4 aux; attribute vec3 aux2; varying vec3 vW; varying vec3 vN; varying vec4 vA; varying vec3 vA2;
      void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; vN = normal; vA = aux; vA2 = aux2; gl_Position = projectionMatrix * viewMatrix * w; }`,
    fragmentShader: `
      varying vec3 vW; varying vec3 vN; varying vec4 vA; varying vec3 vA2;
      uniform vec3 bands[8]; uniform vec3 floorC, topC, highC, screeC, greenC, waterC, glowC, sunDir, sunCol, ambCol, fogC, pathC;
      uniform float fogD, time, soft, planet, bandH, floorY;
      float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
      float vn(vec2 p){
        vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
        return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y);
      }
      float fbm3(vec2 p){
        return vn(p) * 0.54 + vn(p * 2.13 + 5.7) * 0.30 + vn(p * 4.41 - 3.1) * 0.16;
      }
      vec3 pick(float idx){
        vec3 c = bands[0];
        for (int k = 1; k < 8; k++) { if (abs(idx - float(k)) < 0.5) c = bands[k]; }
        return c;
      }
      void main(){
        vec3 N = normalize(vN);
        vec3 V = normalize(cameraPosition - vW);
        float slope = 1.0 - N.y;
        float y = vW.y;
        // Rich multi-scale geological stratification: sweeping cross-bedded sandstone waves, micro-sediment ribs & vertical desert-varnish streaks!
        float warp = (vn(vW.xz * 0.009) * 2.0 - 1.0) * 5.4 + (vn(vW.xz * 0.042 + 3.0) * 2.0 - 1.0) * 1.6;
        float sy = (y + warp) / bandH;
        float bi = floor(sy), bf = fract(sy);
        vec3 rock = soft > 0.5 ? mix(pick(mod(bi, 8.0)), pick(mod(bi + 1.0, 8.0)), smoothstep(0.66, 1.0, bf)) : pick(mod(bi, 8.0));
        // Fine sub-bedding laminations & ledge overhang shadow lines along canyon cliff faces!
        float microLedge = 0.88 + 0.12 * sin(sy * 18.8495 + vn(vW.xz * 0.12) * 2.5);
        rock *= mix(0.72, 1.04, smoothstep(0.0, 0.11, bf)) * (soft > 0.5 ? microLedge : 1.0);
        // Natural vertical cliff weathering / desert-varnish / glacial-flute / basalt-column striations!
        float vertFlute = vn(vec2((vW.x - vW.z) * (planet > 1.5 && planet < 2.5 ? 0.42 : 0.18), y * 0.018));
        if (planet < 0.5) {
          // Dark iron-manganese desert varnish streaks dripping down sunlit red-rock walls
          float varnish = smoothstep(0.58, 0.85, vertFlute) * smoothstep(0.25, 0.7, slope) * smoothstep(floorY + 14.0, floorY + 58.0, y);
          rock *= 1.0 - 0.34 * varnish;
        } else if (planet > 0.5 && planet < 1.5) {
          // Vertical blue glacial ice flutes & shimmering crystal facets
          rock = mix(rock, rock * vec3(0.75, 1.05, 1.25), smoothstep(0.45, 0.82, vertFlute) * 0.45);
        } else if (planet > 1.5 && planet < 2.5) {
          // Sharp columnar basalt vertical ribbing along volcanic cliffs
          float hexRib = smoothstep(0.2, 0.8, sin((vW.x * 0.72 + vW.z * 0.68) * 1.15 + vertFlute * 1.2) * 0.5 + 0.5);
          rock *= 0.76 + 0.36 * hexRib;
        }
        float fineGrain = soft > 0.5 ? fbm3(vW.xz * 0.45 + vW.y * 0.2) : h21(floor(vW.xz / 2.5) + floor(vW.y / 3.0));
        if (planet > 2.5) {
          vec3 basalt = vec3(0.075, 0.085, 0.082);
          vec3 warmStone = screeC * 0.72;
          rock = mix(basalt, warmStone, fbm3(vW.xz * 0.055 + y * 0.04));
        }
        rock *= 0.88 + 0.24 * fineGrain;

        // Multi-zone macro geological color shift across the map so NO two canyon sectors look the same!
        float zoneWave = sin(vW.x * 0.0022 + vW.z * 0.0016) * 0.5 + 0.5;
        float zoneWave2 = cos(vW.x * 0.0019 - vW.z * 0.0024) * 0.5 + 0.5;
        if (planet < 0.5) {
          // Desert shifts between Deep Vermilion-Crimson Canyon, Warm Golden-Honey Sandstone & Rose-Ivory White-Pocket Cliffs!
          rock = mix(rock * vec3(1.18, 0.78, 0.76), rock * vec3(1.12, 1.08, 0.82), zoneWave);
          rock = mix(rock, vec3(0.84, 0.68, 0.56), smoothstep(0.72, 0.96, zoneWave2) * 0.42);
        } else if (planet > 0.5 && planet < 1.5) {
          // Ice shifts between Deep Sapphire-Turquoise Glacier & Dreamy Amethyst-Rose Crystal Cavern Walls!
          rock = mix(rock * vec3(0.76, 1.12, 1.18), rock * vec3(1.22, 0.88, 1.28), smoothstep(0.35, 0.82, zoneWave));
        } else if (planet > 1.5 && planet < 2.5) {
          // Lava shifts between Glossy Midnight Obsidian, Roasted Crimson Scoria & Golden-Sulfur Caldera Strata!
          rock = mix(rock * vec3(0.78, 0.82, 1.05), rock * vec3(1.32, 0.95, 0.68), smoothstep(0.38, 0.84, zoneWave));
        }

        // Sculpted wind-blown desert sand ripples, crisp wind-packed snow sastrugi & ropy cooled pahoehoe lava floor!
        float rip = sin((vW.x * 0.62 + vW.z * 0.36) * 0.28 + fbm3(vW.xz * 0.025) * 6.5);
        float fineRip = sin((vW.x * 0.85 - vW.z * 0.45) * 1.15 + vn(vW.xz * 0.14) * 3.5);
        float ripK = soft > 0.5 ? smoothstep(-0.35, 0.88, rip * 0.72 + fineRip * 0.28) : step(0.55, rip);
        // True route-floor mask (works across BOTH low 10m basins AND high 58m mesa-rim roads!)
        float onFloor = planet > 2.5
          ? 1.0 - smoothstep(floorY + 2.5, floorY + 7.5, y)
          : 1.0 - smoothstep(-1.0, 11.0, vA2.y);
        vec3 ground = mix(floorC, topC, 1.0 - onFloor);
        ground = mix(ground, highC, smoothstep(92.0, 175.0, y));
        ground = mix(ground, rock * 1.06, (planet > 2.5 ? 0.04 : 0.24) * (1.0 - onFloor));
        ground *= 1.0 - (planet > 2.5 ? 0.01 : 0.10) * ripK * onFloor;
        ground *= 0.93 + 0.14 * fineGrain;

        float pathK = 0.0;
        float wetSpec = 0.0;
        float canyonCrackGlow = 0.0;
        float rv = vA2.z;

        // Multi-zone distinct canyon floor biomes for Desert (0), Ice (1) & Lava (2)!
        if (planet < 2.5) {
          float centreTrack = 1.0 - smoothstep(0.16, 0.54, vA2.x);
          float lowBasinK = 1.0 - smoothstep(16.0, 30.0, y);
          float highRimK  = smoothstep(38.0, 54.0, y);
          if (planet < 0.5) {
            // Zone 1 (Low Havasu Oasis Basin): lush verdant emerald meadows, wildflowers & warm golden river beaches!
            float meadowNoise = fbm3(vW.xz * 0.045);
            float oasisMeadow = clamp(lowBasinK * smoothstep(0.28, 0.65, meadowNoise) * (1.0 - centreTrack * 0.75) + smoothstep(0.01, 0.28, rv) * (1.0 - smoothstep(0.34, 0.52, rv)), 0.0, 1.0);
            vec3 lushOasis = mix(vec3(0.06, 0.34, 0.08), vec3(0.22, 0.52, 0.12), fineGrain);
            // Zone 2 (High Mesa Rim): dramatic red-gold slickrock flagstones & painted sandstone pavement!
            vec3 slickRock = mix(vec3(0.56, 0.21, 0.11), vec3(0.78, 0.46, 0.22), fbm3(vW.xz * 0.06));
            ground = mix(ground, slickRock, highRimK * onFloor * 0.68);
            ground = mix(ground, screeC * vec3(1.18, 0.96, 0.82), (1.0 - highRimK) * smoothstep(0.45, 0.82, meadowNoise) * onFloor * 0.42);
            // Defined warm terracotta-sandstone race track down the centre!
            ground = mix(ground, vec3(0.42, 0.24, 0.15) * (0.9 + 0.2 * fineGrain), centreTrack * onFloor * 0.42);
            ground = mix(ground, lushOasis, oasisMeadow * onFloor * 0.88);
            if (rv > 0.22) {
              float wetSand = smoothstep(0.22, 0.50, rv);
              ground = mix(ground, vec3(0.38, 0.30, 0.20), wetSand * 0.78);
              wetSpec = wetSand * 0.62;
            }
          } else if (planet < 1.5) {
            // Ice Zone 1: Gleaming cobalt-sapphire glacier ice road; Zone 2: Warm emerald-gold geothermal spring rims; Zone 3: Violet crystal frost!
            float blueRoad = clamp(centreTrack * 0.62 + smoothstep(0.46, 0.78, fbm3(vW.xz * 0.045)) * 0.42, 0.0, 0.82);
            vec3 glacierRoad = mix(vec3(0.14, 0.48, 0.86), vec3(0.36, 0.32, 0.78), zoneWave * 0.45) * (0.88 + 0.24 * fineGrain);
            ground = mix(ground, glacierRoad, blueRoad * onFloor);
            if (rv > 0.02) {
              // Warm golden-emerald mineral travertine terrace framing steaming geothermal turquoise springs!
              float springRim = smoothstep(0.02, 0.26, rv) * (1.0 - smoothstep(0.32, 0.52, rv));
              ground = mix(ground, vec3(0.18, 0.62, 0.52) * (0.85 + 0.3 * fineGrain), springRim * 0.72);
            }
            wetSpec = clamp(blueRoad * 0.7 + smoothstep(0.18, 0.52, rv) * 0.65, 0.0, 0.9) * onFloor;
          } else {
            // Lava Zone 1: Glossy midnight obsidian speedway; Zone 2: Blazing golden-orange magma veins; Zone 3: Exotic teal-gold volcanic mineral terraces!
            float c1 = 1.0 - abs(vn(vW.xz * 0.095 + fbm3(vW.xz * 0.04) * 1.6) * 2.0 - 1.0);
            float lavaVein = pow(clamp(c1, 0.0, 1.0), 10.0) * (1.0 - centreTrack * 0.5) * onFloor;
            float bankEmber = smoothstep(0.14, 0.48, rv) * (1.0 - smoothstep(0.48, 0.72, rv));
            canyonCrackGlow = clamp(lavaVein * 1.25 + bankEmber * 1.05, 0.0, 1.6);
            // Vibrant Danakil/Yellowstone emerald-gold geothermal mineral crust patches on upper passes for rich color contrast!
            float sulfurPatch = highRimK * smoothstep(0.56, 0.82, fbm3(vW.xz * 0.055)) * (1.0 - centreTrack * 0.8);
            vec3 mineralCol = mix(vec3(0.48, 0.42, 0.08), vec3(0.08, 0.42, 0.38), zoneWave2);
            ground = mix(ground, vec3(0.028, 0.022, 0.032), centreTrack * onFloor * 0.72);
            ground = mix(ground, mineralCol, sulfurPatch * onFloor * 0.68);
            wetSpec = 0.34 * onFloor;
          }
        }
        if (planet > 2.5) {
          // Multi-scale painterly rainforest floor: sunlit golden-lime clover, deep velvet emerald moss & rich dark humus!
          float macroBio = fbm3(vW.xz * 0.028);
          float mossTuft = fbm3(vW.xz * 0.18 + 9.2);
          float blades   = vn(vW.xz * 1.65);
          vec3 sunlitClover = floorC * vec3(1.28, 1.22, 0.68);
          vec3 deepVelvet   = greenC * vec3(0.58, 0.95, 0.72);
          vec3 humusLitter  = pathC * vec3(0.55, 0.48, 0.38);
          ground = mix(deepVelvet, sunlitClover, smoothstep(0.28, 0.76, macroBio));
          ground = mix(ground, topC * (0.85 + 0.32 * blades), mossTuft * 0.5);
          float forestEdge = smoothstep(-2.0, 22.0, vA2.y) * (1.0 - smoothstep(55.0, 120.0, vA2.y));
          ground = mix(ground, humusLitter, smoothstep(0.62, 0.85, mossTuft) * forestEdge * 0.42);

          // Lush cloud-forest carpet across mountain slopes with subtle textured canopy micro-variation
          float mntH = smoothstep(82.0, 200.0, y);
          float canopyBump = fbm3(vW.xz * 0.085);
          vec3 mntCol = mix(vec3(0.025, 0.11, 0.055), vec3(0.08, 0.24, 0.085), canopyBump);
          ground = mix(ground, mntCol, mntH * 0.72);

          // Natural rainforest sanctuary trail: rich packed earth center with mossy ancient cobble shoulder!
          float wob = (fbm3(vW.xz * 0.08) - 0.5) * 0.14;
          pathK = (1.0 - smoothstep(0.16, 0.54, vA2.x + wob)) * (1.0 - smoothstep(0.28, 0.50, rv));
          float stonePatch = smoothstep(0.58, 0.76, vn(vW.xz * 0.75)) * smoothstep(0.18, 0.45, vA2.x);
          vec3 trailCol = mix(pathC * vec3(0.86, 0.82, 0.76), pathC * vec3(1.12, 1.06, 0.96), fineGrain);
          trailCol = mix(trailCol, vec3(0.16, 0.18, 0.15), stonePatch * 0.42);
          ground = mix(ground, trailCol, pathK * 0.78);

          // Riparian riverbank: lush damp moss -> golden pebble beach -> glossy wet dark river cobbles!
          if (rv > 0.02) {
            float peb = vn(vW.xz * 1.45) * 0.58 + vn(vW.xz * 3.8 + 1.7) * 0.42;
            vec3 dampMoss = vec3(0.035, 0.21, 0.055) * (0.85 + 0.35 * peb);
            vec3 goldSand = mix(vec3(0.24, 0.19, 0.12), vec3(0.12, 0.14, 0.11), smoothstep(0.38, 0.78, peb));
            vec3 wetBed   = mix(vec3(0.04, 0.12, 0.10), vec3(0.02, 0.19, 0.18), smoothstep(0.46, 0.92, rv)) * (0.78 + 0.44 * peb);
            ground = mix(ground, dampMoss, smoothstep(0.02, 0.18, rv) * (1.0 - smoothstep(0.24, 0.40, rv)) * 0.72);
            ground = mix(ground, goldSand, smoothstep(0.16, 0.34, rv) * (1.0 - smoothstep(0.44, 0.58, rv)) * 0.86);
            ground = mix(ground, wetBed, smoothstep(0.42, 0.65, rv) * 0.94);
            wetSpec = smoothstep(0.18, 0.48, rv) * 0.42;
          }

          // Animated golden sunlit canopy-gobo leaf dapples dancing softly over trail & meadows!
          float gobo = vn(vW.xz * 0.11 + vec2(time * 0.045, time * 0.025)) * 0.6
                     + vn(vW.xz * 0.27 - vec2(time * 0.035, -time * 0.02)) * 0.4;
          ground *= mix(vec3(0.84, 0.92, 0.94), vec3(1.18, 1.14, 0.96), smoothstep(0.32, 0.74, gobo));
        }

        float flatK = planet > 2.5 ? smoothstep(0.42, 0.78, N.y) : smoothstep(0.66, 0.88, N.y);
        float lowK = 1.0 - smoothstep(floorY + 4.0, floorY + 22.0, y);
        vec3 steep = mix(rock, screeC * (0.9 + 0.2 * fineGrain), lowK * 0.78 * smoothstep(0.08, 0.45, slope));
        if (planet > 2.5) {
          float mossN = fbm3(vW.xz * 0.065 + y * 0.025);
          float mossK = smoothstep(0.32, 0.64, mossN + clamp((y - floorY) * 0.0028, 0.0, 0.28)) * smoothstep(0.08, 0.36, slope);
          float vine = smoothstep(0.54, 0.74, vn(vec2((vW.x + vW.z) * 0.30, y * 0.042))) * smoothstep(0.18, 0.52, slope);
          steep = mix(steep, greenC * (0.75 + 0.55 * fineGrain), clamp(mossK * 0.82 + vine * 0.65, 0.0, 0.92));
        }
        vec3 alb = mix(steep, ground, flatK);

        float lowPoolZone = 1.0 - smoothstep(18.0, 28.0, y);
        float poolN = vA.z + (vn(vW.xz * 0.25) - 0.5) * 0.12;
        float pool = smoothstep(0.5, 0.56, poolN) * onFloor * flatK * lowPoolZone;
        alb = mix(alb, greenC * (0.88 + 0.24 * fineGrain), vA.w * onFloor * flatK * lowPoolZone * (1.0 - pool) * (planet < 0.5 ? 1.0 : 0.0));
        vec3 wcol = mix(waterC * 1.25, waterC * 0.7, smoothstep(0.55, 0.8, poolN));
        wcol = mix(wcol, vec3(0.9, 0.97, 1.0) * 0.8, 0.3 * (1.0 - smoothstep(0.5, 0.62, poolN)));
        if (planet < 1.5 || planet > 2.5) alb = mix(alb, wcol, pool);

        // Rich cinematic lighting: micro-bumped rock/sand normals, warm red-rock radiosity bounce, glacial subsurface glow & volcanic under-lighting!
        vec3 nLit = N;
        if (soft > 0.5) {
          float b1 = vn(vW.xz * 0.52 + y * 0.35) - 0.5;
          float b2 = vn(vW.xz * 0.52 + vec2(2.3, 1.7) - y * 0.35) - 0.5;
          nLit = normalize(N + vec3(b1, 0.0, b2) * 0.24);
        }
        float ndl = max(dot(nLit, sunDir), 0.0);
        if (soft < 0.5) ndl = floor(ndl * 5.0 + 0.5) / 5.0;
        float sh = vA.y;
        float lit = ndl * (1.0 - (planet > 2.5 ? 0.68 : 0.80) * sh);
        // Authentic Antelope-Canyon warm bounce in Desert, luminous cyan glacier bounce in Ice, fiery magma bounce in Lava!
        vec3 canyonBounce = planet < 0.5
          ? vec3(0.42, 0.16, 0.07) * (1.0 - clamp((y - floorY) / 68.0, 0.0, 1.0)) * (0.4 + 0.6 * slope)
          : planet < 1.5
            ? vec3(0.14, 0.42, 0.68) * (0.35 + 0.65 * slope)
            : planet < 2.5
              ? glowC * 0.36 * (1.0 - clamp((y - floorY) / 56.0, 0.0, 1.0)) * (0.45 + 0.55 * slope)
              : vec3(0.0);
        vec3 skyAmb = planet > 2.5
          ? mix(vec3(0.18, 0.36, 0.26), ambCol * vec3(0.86, 1.08, 1.0), 0.5 + 0.5 * N.y)
          : ambCol * (0.56 + 0.38 * N.y) + canyonBounce;
        vec3 L = skyAmb * vA.x + sunCol * lit * 1.08 * (0.74 + 0.26 * vA.x);
        vec3 col = alb * L;

        // Glacial ice wall subsurface scattering & sparkling snow diamond glints!
        if (planet > 0.5 && planet < 1.5) {
          float iceRim = pow(1.0 - clamp(dot(nLit, V), 0.0, 1.0), 2.8) * smoothstep(0.15, 0.6, slope);
          col += vec3(0.18, 0.68, 1.0) * iceRim * 0.45;
          float snowSparkle = step(0.992, h21(floor(vW.xz * 2.2) + floor(V.xz * 14.0))) * flatK * (1.0 - sh * 0.8);
          col += vec3(1.1, 1.25, 1.4) * snowSparkle * 0.85;
        }
        if (wetSpec > 0.001) {
          vec3 H = normalize(sunDir + V);
          col += sunCol * pow(max(dot(nLit, H), 0.0), 42.0) * wetSpec * (1.0 - sh * 0.65);
        }
        if (planet < 1.5 || planet > 2.5) col += vec3(1.0, 0.98, 0.9) * pool * step(0.985, h21(floor(vW.xz * 0.9) + floor(time * 2.0))) * (1.0 - sh) * 0.8;
        if (planet > 1.5 && planet < 2.5) {
          float pulse = 0.78 + 0.28 * sin(time * 2.2 + vW.x * 0.04 + y * 0.25);
          float flow = vn(vW.xz * 0.11 + vec2(time * 0.28, -time * 0.14));
          vec3 moltenPool = mix(glowC * 0.85, vec3(2.4, 1.55, 0.35), smoothstep(0.35, 0.8, flow));
          col = mix(col, moltenPool, pool);
          // Pulsing magma floor cracks + incandescent cliff strata seams + diagonal volcanic dikes!
          vec3 crackCol = mix(glowC * 1.1, vec3(2.3, 1.35, 0.28), clamp(canyonCrackGlow * 0.7, 0.0, 1.0));
          col += crackCol * canyonCrackGlow * pulse;
          float seam = step(mod(bi, 4.0), 0.5) * (1.0 - smoothstep(0.0, 0.18, bf)) * smoothstep(0.22, 0.52, slope);
          float dike = pow(clamp(1.0 - abs(vn(vec2((vW.x + vW.z) * 0.055, y * 0.05)) * 2.0 - 1.0), 0.0, 1.0), 14.0) * smoothstep(0.3, 0.65, slope);
          col += mix(glowC, vec3(2.2, 1.2, 0.25), 0.45) * (seam * 1.15 + dike * 1.35) * pulse;
        }

        // Height-aware atmospheric haze + golden desert sun-haze / polar mist / volcanic caldera ember glow!
        float dist = length(vW - cameraPosition);
        float canyonMist = clamp(1.0 - (y - 12.0) / 72.0, 0.0, 1.0) * (planet > 1.5 && planet < 2.5 ? 0.22 : 0.16) * smoothstep(95.0, 520.0, dist);
        float f = clamp(1.0 - exp(-fogD * fogD * dist * dist) + canyonMist, 0.0, 1.0);
        float sunGlow = pow(clamp(dot(-V, sunDir), 0.0, 1.0), 4.5) * 0.42;
        vec3 hazeCol = planet > 1.5 && planet < 2.5
          ? mix(fogC, fogC + glowC * 0.35, sunGlow + canyonMist * 1.2)
          : mix(fogC, fogC * 0.74 + sunCol * 0.40, sunGlow);
        col = mix(col, hazeCol, f);
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })
  const CH = 40
  for (let cj = 0; cj * CH < n - 1; cj++) {
    for (let ci = 0; ci * CH < n - 1; ci++) {
      const i0 = ci * CH, i1 = Math.min(n - 1, i0 + CH)
      const j0 = cj * CH, j1 = Math.min(n - 1, j0 + CH)
      const nx = i1 - i0 + 1
      const nz = j1 - j0 + 1
      const pos = new Float32Array(nx * nz * 3)
      const nor = new Float32Array(nx * nz * 3)
      const aux = new Float32Array(nx * nz * 4)
      const aux2 = new Float32Array(nx * nz * 3)
      const rMask = arena.riverMask
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const v = (j - j0) * nx + (i - i0)
          const h = Hc(i, j)
          pos[v * 3] = ox + (i + 0.5) * C
          pos[v * 3 + 1] = h
          pos[v * 3 + 2] = oz + (j + 0.5) * C
          const dx = (Hc(i + 1, j) - Hc(i - 1, j)) / (2 * C)
          const dz = (Hc(i, j + 1) - Hc(i, j - 1)) / (2 * C)
          const nl = Math.hypot(dx, 1, dz)
          nor[v * 3] = -dx / nl
          nor[v * 3 + 1] = 1 / nl
          nor[v * 3 + 2] = -dz / nl
          let avg = 0
          for (const [a, b] of ring) avg += Hc(i + a, j + b)
          avg /= ring.length
          const cav = (avg - h) / 46
          const k = Math.min(n - 1, Math.max(0, j)) * n + Math.min(n - 1, Math.max(0, i))
          aux[v * 4] = clamp(1 - clamp(cav, 0, 0.42) + clamp(-cav * 0.5, 0, 0.08), 0.5, 1.1)
          aux[v * 4 + 1] = shadow[k]
          aux[v * 4 + 2] = poolV[k]
          aux[v * 4 + 3] = greenV[k]
          aux2[v * 3] = arena.lat[k]
          aux2[v * 3 + 1] = arena.edge[k]
          aux2[v * 3 + 2] = rMask ? rMask[k] : 0
        }
      }
      const idx = []
      for (let j = 0; j < nz - 1; j++) {
        for (let i = 0; i < nx - 1; i++) {
          const a = j * nx + i
          idx.push(a, a + nx, a + 1, a + 1, a + nx, a + nx + 1)
        }
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
      g.setAttribute('normal', new THREE.BufferAttribute(nor, 3))
      g.setAttribute('aux', new THREE.BufferAttribute(aux, 4))
      g.setAttribute('aux2', new THREE.BufferAttribute(aux2, 3))
      g.setIndex(idx)
      g.computeBoundingSphere()
      group.add(new THREE.Mesh(g, terrainMat))
    }
  }
  // beyond the map: more plateau, running out to the haze
  const fogCol = new THREE.Color(fogHex)
  const farCol = col3(mixc(pal.top, [fogCol.r * 255, fogCol.g * 255, fogCol.b * 255], 0.22))
  const farShape = new THREE.Shape()
  farShape.moveTo(-20000, -20000)
  farShape.lineTo(20000, -20000)
  farShape.lineTo(20000, 20000)
  farShape.lineTo(-20000, 20000)
  farShape.closePath()
  const hole = new THREE.Path()
  hole.moveTo(ox - 4, -(oz - 4))
  hole.lineTo(ox - 4, -(oz + arena.size + 4))
  hole.lineTo(ox + arena.size + 4, -(oz + arena.size + 4))
  hole.lineTo(ox + arena.size + 4, -(oz - 4))
  hole.closePath()
  farShape.holes.push(hole)
  const far = new THREE.Mesh(new THREE.ShapeGeometry(farShape).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: farCol, side: THREE.DoubleSide }))
  far.position.y = pal.forest ? 25 : 66
  far.frustumCulled = false
  group.add(far)

  // ── sky
  const sky = makeSky({ tod, soft, sunDir: toSun, hor: fogHex })
  group.add(sky.mesh)

  // ── majestic panoramic mountain ranges: for forest, custom painterly cloud-forest canopy shader with sunlit ridges & silver waterfalls!
  {
    const rnd = mulberry32(Math.round(arena.opts.seed) * 313 + 9)
    const cx0 = ox + arena.size / 2
    const cz0 = oz + arena.size / 2
    const hazeRGB = [fogCol.r * 255, fogCol.g * 255, fogCol.b * 255]
    if (pal.forest) {
      const baseR = arena.size * 0.54
      const mntMat = new THREE.ShaderMaterial({
        side: THREE.DoubleSide,
        fog: false,
        uniforms: {
          sunDir: { value: toSun },
          sunCol: { value: new THREE.Vector3(...SUNC.col).multiplyScalar(SUNC.k) },
          fogC: { value: new THREE.Color(fogHex) },
          shadeC: { value: lin3(tod === 'night' ? [14, 46, 44] : tod === 'sunset' ? [42, 82, 62] : [22, 88, 54]) },
          litC: { value: lin3(tod === 'night' ? [34, 84, 72] : tod === 'sunset' ? [146, 152, 74] : [76, 158, 66]) },
        },
        vertexShader: `
          attribute vec2 mMeta; // x = heightFrac, y = layerHaze
          varying vec3 vW;
          varying vec3 vN;
          varying vec2 vM;
          void main(){
            vM = mMeta;
            vN = normal;
            vec4 w = modelMatrix * vec4(position, 1.0);
            vW = w.xyz;
            gl_Position = projectionMatrix * viewMatrix * w;
          }`,
        fragmentShader: `
          varying vec3 vW;
          varying vec3 vN;
          varying vec2 vM;
          uniform vec3 sunDir, sunCol, fogC, shadeC, litC;
          float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
          float vn(vec2 p){
            vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
            return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x), mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
          }
          void main(){
            vec3 N = normalize(vN);
            // Multi-scale billowing broccoli-canopy micro-bumps so distant mountains read as millions of lush trees!
            float c1 = vn(vW.xz * 0.018 + vW.y * 0.012);
            float c2 = vn(vW.xz * 0.055 - vW.y * 0.025);
            float canopy = c1 * 0.6 + c2 * 0.4;
            float ndl = clamp(dot(normalize(N + vec3((c2 - 0.5) * 0.45, 0.25, (c1 - 0.5) * 0.45)), sunDir) * 0.65 + 0.45, 0.0, 1.0);
            vec3 col = mix(shadeC, litC, ndl * (0.72 + 0.38 * canopy));
            // Subtle sunlit emerald cliff faces + slender silver highland waterfalls on steep upper peaks
            float cliff = smoothstep(0.68, 0.92, vM.x) * smoothstep(0.58, 0.78, c1);
            col = mix(col, vec3(0.16, 0.21, 0.17) * (0.6 + 0.6 * ndl), cliff * 0.38);
            float fallLine = smoothstep(0.965, 0.992, sin(atan(vW.z, vW.x) * 26.0 + c1 * 1.4)) * smoothstep(0.28, 0.78, vM.x) * (1.0 - vM.y);
            col = mix(col, vec3(0.82, 0.97, 0.98), fallLine * 0.55);
            // Dreamy cloud-valley mist band wrapping mountain bases + golden aerial sun-scatter!
            float valleyCloud = pow(1.0 - clamp(vM.x, 0.0, 1.0), 1.8) * 0.72;
            vec3 V = normalize(vW - cameraPosition);
            float sunHaze = pow(clamp(dot(V, sunDir), 0.0, 1.0), 4.0) * 0.35;
            vec3 mist = mix(fogC, fogC * 0.76 + sunCol * 0.38, sunHaze);
            col = mix(col, mist, clamp(vM.y + valleyCloud * (1.0 - vM.y * 0.5), 0.0, 0.94));
            gl_FragColor = vec4(col, 1.0);
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }`,
      })
      const mntRanges = [
        { rFoot: baseR + 70, rCrest: baseR + 640, rBack: baseR + 1150, hMin: 210, hMax: 560, haze: 0.22 },
        { rFoot: baseR + 860, rCrest: baseR + 1680, rBack: baseR + 2350, hMin: 320, hMax: 820, haze: 0.48 },
        { rFoot: baseR + 2050, rCrest: baseR + 3150, rBack: baseR + 4100, hMin: 440, hMax: 1120, haze: 0.72 },
      ]
      for (const rg of mntRanges) {
        const SEG = 260, RINGS = 5
        const p1 = rnd() * 6.28, p2 = rnd() * 6.28, p3 = rnd() * 6.28, p4 = rnd() * 6.28
        const pos = [], meta = [], idx = []
        const hAt = (a) => {
          const s1 = 0.5 + 0.5 * Math.sin(a * 5 + p1)
          const s2 = 1 - Math.abs(Math.sin(a * 11 + p2))
          const s3 = 1 - Math.abs(Math.cos(a * 23 + p3))
          const s4 = 0.5 + 0.5 * Math.sin(a * 43 + p4)
          return rg.hMin + (rg.hMax - rg.hMin) * clamp(Math.pow(s1, 1.2) * 0.42 + Math.pow(s2, 1.4) * 0.35 + s3 * 0.16 + s4 * 0.07, 0, 1)
        }
        for (let k = 0; k <= SEG; k++) {
          const a = (k / SEG) * Math.PI * 2
          const hc = hAt(a), ca = Math.cos(a), sa = Math.sin(a)
          const spur = Math.sin(a * 17 + p2) * 95
          const rings = [
            [rg.rFoot + spur * 0.65, 34, 0.0],
            [rg.rFoot + (rg.rCrest - rg.rFoot) * 0.36 + spur, hc * 0.38 + Math.sin(a * 27 + p3) * 18, 0.38],
            [rg.rFoot + (rg.rCrest - rg.rFoot) * 0.72 + spur * 0.7, hc * 0.74 + Math.cos(a * 31 + p4) * 16, 0.74],
            [rg.rCrest + spur * 0.4, hc, 1.0],
            [rg.rBack, 28, 0.15],
          ]
          for (const [rad, hy, hf] of rings) {
            pos.push(cx0 + ca * rad, hy, cz0 + sa * rad)
            meta.push(hf, rg.haze)
          }
          if (k < SEG) {
            const b = k * RINGS
            for (let q = 0; q < RINGS - 1; q++) {
              idx.push(b + q, b + RINGS + q, b + q + 1, b + q + 1, b + RINGS + q, b + RINGS + q + 1)
            }
          }
        }
        const g = new THREE.BufferGeometry()
        g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
        g.setAttribute('mMeta', new THREE.Float32BufferAttribute(meta, 2))
        g.setIndex(idx)
        g.computeVertexNormals()
        const m = new THREE.Mesh(g, mntMat)
        m.frustumCulled = false
        group.add(m)
      }
    } else {
      // 3-Tier Volumetric 3D Horizon Mountain Ranges tailored per Canyon Planet:
      // Desert: Monument Valley flat-topped crimson-gold mesas & cathedral buttes
      // Ice: Razor-sharp sunlit Himalayan/polar crystal glacier horns & snow massifs
      // Lava: Jagged smoking volcanic caldera ranges with glowing magma crater rims!
      const pName = arena.opts.planet
      const baseR = arena.size * 0.55
      const shadeRGB = pName === 'ice'
        ? [52, 108, 188]
        : pName === 'lava'
          ? [38, 18, 22]
          : [138, 56, 48]
      const litRGB = pName === 'ice'
        ? [236, 248, 255]
        : pName === 'lava'
          ? [156, 62, 38]
          : [244, 158, 92]
      const rimGlowRGB = pName === 'lava' ? [255, 118, 28] : litRGB
      const cRanges = [
        { rFoot: baseR + 180, rCrest: baseR + 780, rBack: baseR + 1320, hMin: 185, hMax: 520, haze: 0.28 },
        { rFoot: baseR + 1080, rCrest: baseR + 1950, rBack: baseR + 2680, hMin: 280, hMax: 780, haze: 0.54 },
        { rFoot: baseR + 2400, rCrest: baseR + 3650, rBack: baseR + 4500, hMin: 390, hMax: 1080, haze: 0.78 },
      ]
      for (const rg of cRanges) {
        const SEG = 320, RINGS = 4
        const p1 = rnd() * 6.28, p2 = rnd() * 6.28, p3 = rnd() * 6.28
        const pos = [], cols = [], idx = []
        const heightAt = (a) => {
          const s1 = 0.5 + 0.5 * Math.sin(a * 6 + p1)
          const s2 = 1 - Math.abs(Math.sin(a * 13 + p2))
          const s3 = 0.5 + 0.5 * Math.cos(a * 29 + p3)
          let r = clamp(s1 * 0.45 + s2 * 0.36 + s3 * 0.19, 0, 1)
          if (pName === 'desert') {
            // Iconic stepped flat-topped Monument Valley mesas punctuated by tall narrow butte spires!
            r = (Math.round(r * 5) / 5) * 0.72 + r * 0.28
          } else if (pName === 'ice') {
            // Dramatic soaring razor-peaked glacial horns
            r = Math.pow(r, 1.32)
          } else {
            // Jagged volcanic caldera teeth & notched craters
            const notch = r > 0.76 ? (r - 0.76) * 0.9 : 0
            r = clamp(Math.pow(r, 1.15) - notch, 0, 1)
          }
          return rg.hMin + (rg.hMax - rg.hMin) * r
        }
        for (let k = 0; k <= SEG; k++) {
          const a = (k / SEG) * Math.PI * 2
          const hc = heightAt(a), hn = heightAt(a + 0.02)
          const ca = Math.cos(a), sa = Math.sin(a)
          const inSun = clamp((-ca * toSun.x - sa * toSun.z) * 0.5 + 0.5 + (hc - hn) * 0.008, 0, 1)
          const spur = Math.sin(a * 17 + p2) * 85
          const ringDefs = [
            [rg.rFoot + spur * 0.6, 52, 0.0],
            [rg.rFoot + (rg.rCrest - rg.rFoot) * 0.52 + spur, hc * 0.56, 0.55],
            [rg.rCrest + spur * 0.35, hc, 1.0],
            [rg.rBack, 40, 0.2],
          ]
          for (const [rad, hy, hf] of ringDefs) {
            pos.push(cx0 + ca * rad, hy, cz0 + sa * rad)
            let rgb = mixc(shadeRGB, litRGB, clamp(inSun * 0.8 + hf * 0.2, 0, 1))
            if (pName === 'lava' && hf > 0.9 && hc > rg.hMin + (rg.hMax - rg.hMin) * 0.64) {
              rgb = mixc(rgb, rimGlowRGB, 0.65)
            }
            const mistK = clamp(rg.haze + Math.pow(1 - hf, 1.7) * 0.48, 0, 0.96)
            rgb = mixc(rgb, hazeRGB, mistK)
            const cc = col3(rgb)
            cols.push(cc.r, cc.g, cc.b)
          }
          if (k < SEG) {
            const b = k * RINGS
            for (let q = 0; q < RINGS - 1; q++) {
              idx.push(b + q, b + RINGS + q, b + q + 1, b + q + 1, b + RINGS + q, b + RINGS + q + 1)
            }
          }
        }
        const g = new THREE.BufferGeometry()
        g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
        g.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3))
        g.setIndex(idx)
        const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide, fog: false }))
        m.frustumCulled = false
        group.add(m)
      }
    }
  }

  // ── scenery: boulders, plus a few plants / crystals / shards
  const bandAt = (y) => pal.bands[((Math.floor(y / 5.6) % 8) + 8) % 8]
  const rockGeo = rockGeometry(1)
  const rockMatI = new THREE.MeshLambertMaterial({ flatShading: !pal.forest })
  const inst = (geo, mat, list) => {
    if (!list.length) return
    const mesh = new THREE.InstancedMesh(geo, mat, list.length)
    const m4 = new THREE.Matrix4()
    const q = new THREE.Quaternion()
    const e = new THREE.Euler()
    list.forEach((o, k) => {
      e.set(o.tx || 0, o.ry, o.tz || 0, 'YXZ')
      q.setFromEuler(e)
      m4.compose(new THREE.Vector3(o.x, o.y, o.z), q, new THREE.Vector3(o.sx, o.sy, o.sz))
      mesh.setMatrixAt(k, m4)
      mesh.setColorAt(k, col3(o.col))
    })
    mesh.frustumCulled = false
    group.add(mesh)
  }
  {
    const rnd = mulberry32(Math.round(arena.opts.seed) * 977 + 5)
    const boulders = []
    const plants = []
    const accents = []
    const planet = arena.opts.planet
    for (let j = 8; j < n - 8; j += 2) {
      for (let i = 8; i < n - 8; i += 2) {
        const k = j * n + i
        const e = arena.edge[k]
        const x = ox + (i + rnd()) * C
        const z = oz + (j + rnd()) * C
        const g0 = arena.groundAt(x, z)
        // boulders spill down the foot of the cliffs
        if (e > 2 && e < 52 && g0 < 40 && rnd() < 0.1 && boulders.length < 700) {
          const s = 1.3 + Math.pow(rnd(), 2.2) * 5.2
          const b = bandAt(g0 + 4)
          const f = 0.82 + rnd() * 0.3
          boulders.push({ x, y: g0 + s * 0.22, z, sx: s * (1 + rnd() * 0.3), sy: s * (0.55 + rnd() * 0.25), sz: s * (0.9 + rnd() * 0.3), ry: rnd() * 6.28, col: pal.forest ? mixc([b[0] * f, b[1] * f, b[2] * f], [66, 118, 58], 0.34) : [b[0] * f, b[1] * f, b[2] * f] })
        }
        if (planet === 'desert') {
          // an oasis, and the odd dry bush along the foot of the walls
          const gv = greenV[k]
          if ((gv > 0.2 && rnd() < 0.3) || (e > 0 && e < 24 && g0 < 16 && rnd() < 0.012)) {
            if (plants.length > 340) continue
            const s = 1.1 + rnd() * 1.6
            const wet = gv > 0.2
            const c = wet ? [70 + rnd() * 40, 130 + rnd() * 30, 56 + rnd() * 20] : [150 + rnd() * 20, 134 + rnd() * 16, 84]
            plants.push({ x, y: g0 + s * 0.3, z, sx: s * 1.5, sy: s * 0.85, sz: s * 1.5, ry: rnd() * 6.28, col: c })
          }
        }
      }
    }
    void accents
    inst(rockGeo, rockMatI, boulders)
    if (planet === 'desert') inst(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshLambertMaterial(), plants)
  }

  // Monumental canyon scenery (Desert arches/oases/saguaros, Ice glacier bridges/aurora/crystals, Lava magma-rivers/magma-falls/basalt columns)
  let canyonScenery = null
  if (!pal.forest) {
    canyonScenery = buildCanyonScenery(arena, {
      planet: arena.opts.planet,
      pal,
      bandsLin: pal.bands.map(lin3),
      sunDir: toSun,
      sunCol: new THREE.Vector3(...SUNC.col).multiplyScalar(SUNC.k),
      ambCol: new THREE.Vector3(...SUNC.amb),
      fogHex,
      fogDensity: SUNC.fog * (pal.fogK || 1),
      soft,
      tod,
      mistTexture: softDot,
    })
    group.add(canyonScenery.group)
  }

  // Forest trees are generated separately from the canyon scenery.
  let jungle = null
  let forestRapids = null
  const forestAnim = { fn: null }
  if (pal.forest) {
    const rndF = mulberry32(Math.round(arena.opts.seed) * 4441 + 17)
    const slopeAt = (x, z) => {
      const gx = (arena.groundAt(x + C, z) - arena.groundAt(x - C, z)) / (2 * C)
      const gz = (arena.groundAt(x, z + C) - arena.groundAt(x, z - C)) / (2 * C)
      return Math.hypot(gx, gz)
    }
    const fDensity = SUNC.fog * (pal.fogK || 1)
    jungle = buildRainforest(arena, { soft, density: wopts.forestDensity, sunDir: toSun, fogColor: fogHex, fogDensity: fDensity, tod })
    group.add(jungle.group)
    forestRapids = buildForestRapids(arena, { fogColor: fogHex, fogDensity: fDensity, soft, mistTexture: softDot, sunDir: toSun, tod })
    group.add(forestRapids.group)

    // Tropical wildflower meadows & softly glowing bioluminescent forest mushrooms along shaded mossy banks!
    {
      const FL = [[255, 112, 165], [255, 212, 66], [255, 250, 240], [186, 142, 255], [255, 132, 58]]
      const MUSH = [[68, 252, 224], [116, 255, 188], [130, 215, 255]]
      const fl = []
      const caps = []
      const stems = []
      for (let j = 10; j < n - 10 && fl.length < 1200; j++) {
        for (let i = 10; i < n - 10; i++) {
          const e = arena.edge[j * n + i]
          if (e < 3 || e > 58 || rndF() > 0.032) continue
          const x = ox + (i + rndF()) * C, z = oz + (j + rndF()) * C
          if (arena.riverAt?.(x, z) > 0.38 || slopeAt(x, z) > 0.36) continue
          if (e > 7 && rndF() < 0.24 && caps.length < 480) {
            // Enchanted cluster of glowing rainforest mushrooms nestled under giant tree roots!
            const colM = MUSH[Math.floor(rndF() * MUSH.length)]
            for (let q = 0; q < 4; q++) {
              const mx = x + (rndF() - 0.5) * 3.8, mz = z + (rndF() - 0.5) * 3.8
              const my = arena.groundAt(mx, mz)
              const h = 0.65 + rndF() * 1.15
              const r = h * (0.55 + rndF() * 0.28)
              stems.push({ x: mx, y: my + h * 0.45, z: mz, sx: r * 0.22, sy: h, sz: r * 0.22, ry: 0, col: [210, 240, 225] })
              caps.push({ x: mx, y: my + h * 0.92, z: mz, sx: r, sy: r * 0.45, sz: r, ry: rndF() * 6.28, col: colM })
            }
          } else {
            const c = FL[Math.floor(rndF() * FL.length)]
            for (let q = 0; q < 4; q++) {
              const fx0 = x + (rndF() - 0.5) * 5.2, fz0 = z + (rndF() - 0.5) * 5.2
              const s = 0.42 + rndF() * 0.48
              fl.push({ x: fx0, y: arena.groundAt(fx0, fz0) + 0.38, z: fz0, sx: s, sy: s * 0.55, sz: s, ry: rndF() * 6.28, col: c })
            }
          }
        }
      }
      inst(new THREE.SphereGeometry(1, 7, 5), new THREE.MeshLambertMaterial(), fl)
      inst(new THREE.CylinderGeometry(0.7, 1, 1, 6), new THREE.MeshLambertMaterial(), stems)
      inst(new THREE.SphereGeometry(1, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.58), new THREE.MeshBasicMaterial(), caps)
    }

    // waterfalls pouring down the cliffs in tiers, with a pool and mist at the foot
    const fallU = { time: { value: 0 }, fogC: { value: new THREE.Color(fogHex) }, fogD: { value: SUNC.fog * (pal.fogK || 1) }, soft: { value: soft ? 1 : 0 } }
    const fallMat = new THREE.ShaderMaterial({
      uniforms: fallU, transparent: true, depthWrite: false, side: THREE.DoubleSide,
      vertexShader: 'varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
      fragmentShader: `
        varying vec2 vUv; varying vec3 vW; uniform float time, fogD, soft; uniform vec3 fogC;
        float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f); return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y); }
        void main(){
          float edge = smoothstep(0.0, 0.2, vUv.x) * smoothstep(1.0, 0.8, vUv.x);
          float s1 = vn(vec2(vUv.x * 12.0, vUv.y * 46.0 - time * 3.0));
          float s2 = vn(vec2(vUv.x * 28.0 + 5.0, vUv.y * 90.0 - time * 5.2));
          float streak = s1 * 0.6 + s2 * 0.4;
          if (soft < 0.5) streak = floor(streak * 4.0) / 4.0;
          vec3 col = mix(vec3(0.5, 0.86, 0.95), vec3(1.0), smoothstep(0.3, 0.8, streak));
          float foam = smoothstep(0.9, 1.0, vUv.y);
          col = mix(col, vec3(1.0), foam * 0.85);
          float a = edge * (0.5 + 0.42 * streak) * smoothstep(0.0, 0.05, vUv.y);
          float d = length(vW - cameraPosition);
          col = mix(col, fogC, clamp(1.0 - exp(-fogD * fogD * d * d), 0.0, 1.0));
          gl_FragColor = vec4(col, a);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    })
    const mist = []
    for (const f of fallPaths) {
      const P = f.pts
      // an even sample every ~3 m along the climb
      const S = []
      for (let a = 0; a < P.length - 1; a++) {
        const L = Math.hypot(P[a + 1][0] - P[a][0], P[a + 1][1] - P[a][1])
        const m = Math.max(1, Math.round(L / 3))
        for (let q = 0; q < m; q++) S.push([P[a][0] + ((P[a + 1][0] - P[a][0]) * q) / m, P[a][1] + ((P[a + 1][1] - P[a][1]) * q) / m])
      }
      const m = S.length
      if (m < 6) continue
      const pos = new Float32Array(m * 2 * 3)
      const uv = new Float32Array(m * 2 * 2)
      for (let r = 0; r < m; r++) {
        const a = S[Math.max(0, r - 1)], b = S[Math.min(m - 1, r + 1)]
        let dx = b[0] - a[0], dz = b[1] - a[1]
        const dl = Math.hypot(dx, dz) || 1
        dx /= dl; dz /= dl
        const w = (f.width || 6.8) * (0.72 + 0.44 * (1 - r / m))
        for (let sd = 0; sd < 2; sd++) {
          const px = S[r][0] + -dz * w * (sd ? 1 : -1)
          const pz = S[r][1] + dx * w * (sd ? 1 : -1)
          const o = (r * 2 + sd) * 3
          pos[o] = px
          pos[o + 1] = arena.groundAt(px, pz) + 0.9
          pos[o + 2] = pz
          uv[(r * 2 + sd) * 2] = sd
          uv[(r * 2 + sd) * 2 + 1] = 1 - r / (m - 1)
        }
      }
      const idx = []
      for (let r = 0; r < m - 1; r++) {
        const a = r * 2
        idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3)
      }
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3))
      g.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
      g.setIndex(idx)
      g.computeBoundingSphere()
      const mesh = new THREE.Mesh(g, fallMat)
      mesh.renderOrder = 5
      group.add(mesh)
      // mist rolling off the foot
      const gy = arena.groundAt(f.x, f.z)
      for (let q = 0; q < 4; q++) {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: softDot, color: '#eefcff', transparent: true, opacity: 0.3, depthWrite: false }))
        const sc = 34 + rndF() * 26
        sp.position.set(f.x + (rndF() - 0.5) * 22, gy + 5 + rndF() * 6, f.z + (rndF() - 0.5) * 22)
        sp.scale.setScalar(sc)
        group.add(sp)
        mist.push({ sp, sc, ph: rndF() * 6.28 })
      }
    }

    // shafts of sunlight falling through the valley
    const rayTex = tex(32, 256, (g, w, h) => {
      const img = g.createImageData(w, h)
      for (let y = 0; y < h; y++) {
        const v = y / (h - 1)
        const va = Math.min(1, v / 0.16) * (1 - Math.pow(Math.max(0, (v - 0.55) / 0.45), 1.6))
        for (let x = 0; x < w; x++) {
          const u = (x / (w - 1)) * 2 - 1
          const ha = Math.pow(Math.max(0, 1 - u * u), 1.5)
          const o = (y * w + x) * 4
          img.data[o] = img.data[o + 1] = img.data[o + 2] = 255
          img.data[o + 3] = Math.round(255 * ha * va)
        }
      }
      g.putImageData(img, 0, 0)
    }, true)
    rayTex.minFilter = THREE.LinearFilter
    const rayCol = tod === 'sunset' ? '#ffb070' : tod === 'night' ? '#8ab0ff' : '#fff4c8'
    const rayBase = tod === 'sunset' ? 0.18 : tod === 'night' ? 0.07 : 0.14
    const rays = []
    const qRay = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), toSun)
    for (let k = 0; k < 18; k++) {
      const p = arena.paths[Math.floor(rndF() * arena.paths.length)]
      const q = p.pts[3 + Math.floor(rndF() * (p.pts.length - 6))]
      const a = p.pts[Math.max(0, p.pts.indexOf(q) - 1)], b = p.pts[Math.min(p.pts.length - 1, p.pts.indexOf(q) + 1)]
      let tx = b[0] - a[0], tz = b[1] - a[1]
      const tl = Math.hypot(tx, tz) || 1
      tx /= tl; tz /= tl
      const off = (rndF() - 0.5) * p.halfW * 2.2
      const x = q[0] - tz * off
      const z = q[1] + tx * off
      const g0 = arena.groundAt(x, z)
      const L = 190
      const wd = 10 + rndF() * 16
      const mat = new THREE.MeshBasicMaterial({ map: rayTex, color: rayCol, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, opacity: rayBase })
      for (let c = 0; c < 2; c++) {
        const m = new THREE.Mesh(new THREE.PlaneGeometry(wd, L), mat)
        m.quaternion.copy(qRay)
        m.rotateY((c * Math.PI) / 2)
        m.position.set(x, g0, z).addScaledVector(toSun, L / 2 - 2)
        m.frustumCulled = false
        group.add(m)
      }
      rays.push({ mat, ph: rndF() * 6.28, sp: 0.25 + rndF() * 0.4 })
    }
    // Soft sunlit prism rainbow arcs hovering gently in waterfall plunge mist during daytime!
    if (tod === 'day' && arena.lagoons?.length) {
      const rbTex = tex(128, 32, (g, w, h) => {
        const grd = g.createLinearGradient(0, 0, 0, h)
        grd.addColorStop(0.0, 'rgba(255,80,80,0)')
        grd.addColorStop(0.18, 'rgba(255,95,95,0.45)')
        grd.addColorStop(0.34, 'rgba(255,215,85,0.45)')
        grd.addColorStop(0.52, 'rgba(95,255,155,0.45)')
        grd.addColorStop(0.70, 'rgba(85,205,255,0.45)')
        grd.addColorStop(0.86, 'rgba(165,115,255,0.38)')
        grd.addColorStop(1.0, 'rgba(165,115,255,0)')
        g.fillStyle = grd
        g.fillRect(0, 0, w, h)
      }, true)
      const rbMat = new THREE.MeshBasicMaterial({
        map: rbTex, transparent: true, opacity: 0.24, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
      })
      for (const lg of arena.lagoons.slice(0, 3)) {
        const arc = new THREE.Mesh(new THREE.RingGeometry(24, 31, 32, 1, 0.18, Math.PI - 0.36), rbMat)
        arc.position.set(lg.x, lg.y + 1.5, lg.z)
        arc.rotation.y = lg.rot + 0.6
        arc.renderOrder = 6
        group.add(arc)
      }
    }

    // High timber-and-rope rainforest canopy suspension bridges with warm glowing lanterns above waterfall valleys!
    {
      const woodMat = new THREE.MeshLambertMaterial({ color: '#6b5239' })
      const ropeMat = new THREE.MeshLambertMaterial({ color: '#947c58' })
      const lanternMat = new THREE.MeshBasicMaterial({ color: '#ffdd82' })
      const plankGeo = new THREE.BoxGeometry(2.1, 0.28, 4.4)
      const lanternGeo = new THREE.SphereGeometry(0.68, 8, 6)
      for (const rp of arena.rapids || []) {
        const p = arena.paths[rp.pathId]
        const midI = Math.floor((rp.startIndex + rp.endIndex) * 0.48)
        if (midI < 2 || midI >= p.pts.length - 2) continue
        const q = p.pts[midI], a = p.pts[midI - 1], b = p.pts[midI + 1]
        const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
        const rx = -(b[1] - a[1]) / tl, rz = (b[0] - a[0]) / tl
        const span = p.halfW + 14
        const xL = q[0] - rx * span, zL = q[1] - rz * span
        const xR = q[0] + rx * span, zR = q[1] + rz * span
        const deckY = Math.max(arena.groundAt(q[0], q[1]) + 33, arena.groundAt(xL, zL) + 22, arena.groundAt(xR, zR) + 22)
        const sag = 4.6
        const bGrp = new THREE.Group()
        for (const [tx0, tz0] of [[xL, zL], [xR, zR]]) {
          for (const sOff of [-2.1, 2.1]) {
            const px0 = tx0 - rz * sOff, pz0 = tz0 + rx * sOff
            const gBase = arena.groundAt(px0, pz0)
            const twH = Math.max(8, deckY + 4.5 - gBase)
            const tw = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.85, twH, 8), woodMat)
            tw.position.set(px0, gBase + twH * 0.5 - 0.5, pz0)
            bGrp.add(tw)
          }
        }
        const planks = 26
        const yaw = Math.atan2(xR - xL, zR - zL) - Math.PI / 2
        const plankInst = new THREE.InstancedMesh(plankGeo, woodMat, planks + 1)
        const pm4 = new THREE.Matrix4()
        const pq = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw)
        const pOne = new THREE.Vector3(1, 1, 1)
        for (let k = 0; k <= planks; k++) {
          const u = k / planks, sc = 4 * u * (1 - u)
          const px0 = xL + (xR - xL) * u, pz0 = zL + (zR - zL) * u, py0 = deckY - sag * sc
          pm4.compose(new THREE.Vector3(px0, py0, pz0), pq, pOne)
          plankInst.setMatrixAt(k, pm4)
          if (k > 1 && k < planks - 1 && k % 6 === 0) {
            for (const sOff of [-2.1, 2.1]) {
              const ln = new THREE.Mesh(lanternGeo, lanternMat)
              ln.position.set(px0 - rz * sOff, py0 + 2.5, pz0 + rx * sOff)
              bGrp.add(ln)
            }
          }
        }
        plankInst.computeBoundingSphere()
        bGrp.add(plankInst)
        for (const sOff of [-2.1, 2.1]) {
          const rPts = []
          for (let k = 0; k <= 12; k++) {
            const u = k / 12, sc = 4 * u * (1 - u)
            rPts.push(new THREE.Vector3(xL + (xR - xL) * u - rz * sOff, deckY + 3.4 - (sag + 0.8) * sc, zL + (zR - zL) * u + rx * sOff))
          }
          bGrp.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(rPts), 16, 0.16, 5, false), ropeMat))
        }
        group.add(bGrp)
      }
    }

    // Soft drifting cloud-forest mist ribbons embracing the mountain peaks
    const peakClouds = []
    const cloudColor = tod === 'sunset' ? '#ffd9be' : tod === 'night' ? '#2c5a6c' : '#f0fcf7'
    for (const pk of (arena.peaks || []).filter((p) => p.kind !== 'karst').slice(0, 14)) {
      for (let c = 0; c < 2; c++) {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({
          map: softDot, color: cloudColor, transparent: true, opacity: tod === 'night' ? 0.14 : 0.22, depthWrite: false,
        }))
        const ang = rndF() * Math.PI * 2, rad = pk.radius * (0.35 + rndF() * 0.25)
        const bx = pk.x + Math.cos(ang) * rad, bz = pk.z + Math.sin(ang) * rad
        sp.position.set(bx, pk.y * (0.74 + c * 0.14), bz)
        sp.scale.set(170 + rndF() * 115, 44 + rndF() * 28, 1)
        group.add(sp)
        peakClouds.push({ sp, bx, bz, ph: rndF() * 6.28, sp2: 0.08 + rndF() * 0.08 })
      }
    }

    // Iridescent Blue Morpho & Golden Birdwing rainforest butterflies fluttering beside scenic lagoons & trails!
    const butterflies = []
    const bfWingGeo = new THREE.PlaneGeometry(0.68, 0.52).rotateX(-Math.PI / 2).translate(0.34, 0, 0)
    const bfMats = [
      new THREE.MeshBasicMaterial({ color: '#28c8ff', side: THREE.DoubleSide }),
      new THREE.MeshBasicMaterial({ color: '#ffd448', side: THREE.DoubleSide }),
      new THREE.MeshBasicMaterial({ color: '#5effb8', side: THREE.DoubleSide }),
    ]
    for (let bf = 0; bf < 28; bf++) {
      const p = arena.paths[bf % arena.n]
      const q = p.pts[4 + Math.floor(rndF() * Math.max(2, p.pts.length - 8))]
      const bx = q[0] + (rndF() - 0.5) * p.halfW * 1.4
      const bz = q[1] + (rndF() - 0.5) * p.halfW * 1.4
      const by = arena.groundAt(bx, bz) + 3.2 + rndF() * 5.5
      const bGrp = new THREE.Group()
      const matB = bfMats[bf % bfMats.length]
      const lw = new THREE.Mesh(bfWingGeo, matB), rw = new THREE.Mesh(bfWingGeo, matB)
      rw.rotation.y = Math.PI
      bGrp.add(lw, rw)
      group.add(bGrp)
      butterflies.push({ grp: bGrp, lw, rw, bx, by, bz, r: 5 + rndF() * 9, ph: rndF() * 6.28, sp: 0.55 + rndF() * 0.5 })
    }

    // Soaring flocks of jungle egrets & vibrant tropical macaws circling lagoons & mountain peaks
    const birds = []
    const wingGeo = new THREE.PlaneGeometry(2.5, 0.95).rotateX(-Math.PI / 2).translate(1.25, 0, 0)
    const birdColors = ['#f8fff8', '#f8fff8', '#ff6444', '#ffd24a', '#3cd8ff']
    const flockAnchors = [
      ...(arena.lagoons || []).slice(0, 4).map((lg) => [lg.x, lg.y + 52 + rndF() * 34, lg.z, 58 + rndF() * 42]),
      ...(arena.peaks || []).slice(0, 3).map((pk) => [pk.x, pk.y + 50 + rndF() * 28, pk.z, 88 + rndF() * 45]),
    ]
    for (let f = 0; f < flockAnchors.length; f++) {
      const [ax, ay, az, orbitR] = flockAnchors[f]
      const bMat = new THREE.MeshBasicMaterial({ color: birdColors[f % birdColors.length], side: THREE.DoubleSide })
      for (let b = 0; b < 5; b++) {
        const bGrp = new THREE.Group()
        const lw = new THREE.Mesh(wingGeo, bMat), rw = new THREE.Mesh(wingGeo, bMat)
        rw.rotation.y = Math.PI
        bGrp.add(lw, rw)
        group.add(bGrp)
        birds.push({
          grp: bGrp, lw, rw, ax, ay: ay + (b - 2) * 3.5, az,
          r: orbitR + (rndF() - 0.5) * 26, ang0: (b / 5) * 0.9 + rndF() * 6.28,
          omega: (f % 2 === 0 ? 1 : -1) * (0.14 + rndF() * 0.06), flapPh: rndF() * 6.28,
        })
      }
    }

    forestAnim.fn = (t) => {
      fallU.time.value = t
      for (const r of rays) r.mat.opacity = rayBase * (0.65 + 0.35 * Math.sin(t * r.sp + r.ph))
      for (const m of mist) m.sp.scale.setScalar(m.sc * (1 + 0.08 * Math.sin(t * 0.9 + m.ph)))
      for (const pc of peakClouds) {
        pc.sp.position.x = pc.bx + Math.sin(t * pc.sp2 + pc.ph) * 28
        pc.sp.position.z = pc.bz + Math.cos(t * pc.sp2 * 0.8 + pc.ph) * 18
      }
      for (const bd of birds) {
        const a = bd.ang0 + t * bd.omega
        bd.grp.position.set(bd.ax + Math.cos(a) * bd.r, bd.ay + Math.sin(t * 0.7 + bd.flapPh) * 3.2, bd.az + Math.sin(a) * bd.r)
        bd.grp.rotation.y = -a + (bd.omega > 0 ? 0 : Math.PI)
        const flap = Math.sin(t * 6.8 + bd.flapPh) * 0.42
        bd.lw.rotation.z = flap
        bd.rw.rotation.z = flap
      }
      for (const bf of butterflies) {
        const a = t * bf.sp + bf.ph
        bf.grp.position.set(bf.bx + Math.cos(a) * bf.r, bf.by + Math.sin(t * 2.4 + bf.ph) * 1.1, bf.bz + Math.sin(a * 1.3) * bf.r)
        bf.grp.rotation.y = -a
        const fl = Math.sin(t * 16 + bf.ph) * 0.75
        bf.lw.rotation.z = fl
        bf.rw.rotation.z = fl
      }
    }
  }

  // ── Sci-Fi Holographic Route Guidance, Corner Chevrons, Shortcut Arches & Sky-Beacon Portal Gates
  const routeGuide = buildRouteGuide(arena, { fogColor: fogHex, fogDensity: SUNC.fog * (pal.fogK || 1) })
  if (wopts.showGuides === false) routeGuide.setVisible(false)
  group.add(routeGuide.group)

  // ── Sleek route-aligned Sci-Fi Plasma Accelerator Boost Pads
  {
    const padTex = tex(128, 256, (g, w, h) => {
      g.clearRect(0, 0, w, h)
      g.fillStyle = 'rgba(56, 255, 190, 0.9)'
      g.fillRect(4, 0, 8, h)
      g.fillRect(w - 12, 0, 8, h)
      const grd = g.createLinearGradient(0, 0, 0, h)
      grd.addColorStop(0, '#38ffbe')
      grd.addColorStop(0.5, '#ffe848')
      grd.addColorStop(1, '#ff7818')
      g.fillStyle = grd
      for (let k = 0; k < 4; k++) {
        const y = k * (h / 4)
        g.beginPath()
        g.moveTo(w * 0.14, y + h * 0.23)
        g.lineTo(w * 0.5, y + h * 0.03)
        g.lineTo(w * 0.86, y + h * 0.23)
        g.lineTo(w * 0.86, y + h * 0.14)
        g.lineTo(w * 0.5, y - h * 0.04 + 12)
        g.lineTo(w * 0.14, y + h * 0.14)
        g.closePath()
        g.fill()
      }
    }, true)
    padTex.wrapS = padTex.wrapT = THREE.RepeatWrapping
    const padMat = new THREE.MeshBasicMaterial({ map: padTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
    for (const pd of arena.pads) {
      let bestD = Infinity, btx = 0, btz = -1
      for (const p of arena.paths) {
        for (let i = 1; i < p.pts.length; i++) {
          const d = Math.hypot(p.pts[i][0] - pd.x, p.pts[i][1] - pd.z)
          if (d < bestD) {
            bestD = d
            const dx = p.pts[i][0] - p.pts[i - 1][0], dz = p.pts[i][1] - p.pts[i - 1][1]
            const l = Math.hypot(dx, dz) || 1
            btx = dx / l; btz = dz / l
          }
        }
      }
      const isWet = arena.riverAt?.(pd.x, pd.z) > 0.36
      const m = new THREE.Mesh(new THREE.PlaneGeometry(pd.r * 1.65, pd.r * 2.5).rotateX(-Math.PI / 2), padMat)
      m.position.set(pd.x, arena.groundAt(pd.x, pd.z) + (isWet ? 1.45 : 0.55), pd.z)
      m.rotation.y = Math.atan2(-btx, -btz)
      m.renderOrder = 6
      group.add(m)
    }
    group.userData.padTex = padTex
  }

  // ── High-Clarity Sci-Fi & Elemental Arena Hazards (pole-free, laser-outlined hitboxes & smashable holo-walls!)
  const arenaHazards = buildArenaHazards(arena, {
    planet: arena.opts.planet,
    fogDensity: SUNC.fog * (pal.fogK || 1),
  })
  group.add(arenaHazards.group)

  // ── drifting dust, snow or embers
  const DN = 320
  const dust = new Float32Array(DN * 3)
  {
    const r = mulberry32(99)
    for (let k = 0; k < DN; k++) {
      dust[k * 3] = (r() - 0.5) * 220
      dust[k * 3 + 1] = r() * 80
      dust[k * 3 + 2] = (r() - 0.5) * 220
    }
  }
  const dustGeo = new THREE.BufferGeometry()
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dust, 3))
  const planetName = arena.opts.planet
  const isForest = planetName === 'forest'
  const dustPts = new THREE.Points(
    dustGeo,
    new THREE.PointsMaterial({
      size: isForest ? 1.7 : planetName === 'lava' ? 1.55 : planetName === 'ice' ? 1.35 : 1.15,
      color: isForest ? (tod === 'night' ? col3([190, 255, 140]) : col3([255, 244, 190])) : col3(pal.dust),
      map: softDot, transparent: true,
      opacity: isForest ? (tod === 'night' ? 0.8 : 0.38) : planetName === 'lava' ? 0.92 : planetName === 'ice' ? 0.72 : 0.48,
      depthWrite: false, sizeAttenuation: true, blending: isForest || planetName === 'lava' || planetName === 'ice' ? THREE.AdditiveBlending : THREE.NormalBlending,
    }),
  )
  dustPts.frustumCulled = false
  group.add(dustPts)
  const wind = isForest ? [3, 2.2, 1.5] : planetName === 'ice' ? [4, -7, 2] : planetName === 'lava' ? [1, 6, 1] : [16, 0.4, 7]
  let dustInit = false

  return {
    group,
    info: { falls: fallPaths.map((f) => ({ x: f.x, z: f.z, pts: f.pts })), forest: jungle?.info ?? null, rapids: forestRapids?.info ?? [] },
    groundAt: arena.groundAt,
    sunDir: toSun,
    fog: { color: fogHex, density: SUNC.fog * (pal.fogK || 1) },
    update(dt, camPos, sim) {
      const t = sim.clock
      sky.update(t, camPos)
      terrainMat.uniforms.time.value = t
      if (canyonScenery) canyonScenery.update(t)
      if (jungle) jungle.update(t, camPos)
      if (forestRapids) forestRapids.update(t)
      if (forestAnim.fn) forestAnim.fn(t)
      if (!dustInit) {
        for (let k = 0; k < DN; k++) {
          dust[k * 3] += camPos.x
          dust[k * 3 + 1] += camPos.y - 30
          dust[k * 3 + 2] += camPos.z
        }
        dustInit = true
      }
      for (let k = 0; k < DN; k++) {
        const o = k * 3
        dust[o] += (wind[0] + Math.sin(k + t * 0.7) * 2) * dt
        dust[o + 1] += (wind[1] + Math.cos(k * 1.7 + t) * 1.2) * dt
        dust[o + 2] += (wind[2] + Math.cos(k * 0.6 + t * 0.5) * 2) * dt
        if (dust[o] - camPos.x > 110) dust[o] -= 220
        else if (dust[o] - camPos.x < -110) dust[o] += 220
        if (dust[o + 2] - camPos.z > 110) dust[o + 2] -= 220
        else if (dust[o + 2] - camPos.z < -110) dust[o + 2] += 220
        if (dust[o + 1] - camPos.y > 55) dust[o + 1] -= 85
        else if (dust[o + 1] - camPos.y < -30) dust[o + 1] += 85
      }
      dustGeo.attributes.position.needsUpdate = true
      group.userData.padTex.offset.y -= dt * 1.7
      arenaHazards.update(t, sim)
      routeGuide.update(t, sim)
    },
    setGuides(show) {
      routeGuide.setVisible(show)
    },
    dispose() {
      if (canyonScenery) {
        group.remove(canyonScenery.group)
        canyonScenery.dispose()
      }
      if (forestRapids) {
        group.remove(forestRapids.group)
        forestRapids.dispose()
      }
      if (jungle) {
        group.remove(jungle.group)
        jungle.dispose()
      }
      const geometries = new Set()
      const materials = new Set()
      const textures = new Set()
      group.traverse((o) => {
        if (o.geometry && !o.isSprite) geometries.add(o.geometry)
        if (o.material) {
          for (const material of Array.isArray(o.material) ? o.material : [o.material]) materials.add(material)
        }
      })
      for (const material of materials) {
        for (const value of Object.values(material)) {
          if (value?.isTexture && value !== softDotTex) textures.add(value)
        }
        material.dispose()
      }
      geometries.forEach((geometry) => geometry.dispose())
      textures.forEach((texture) => texture.dispose())
    },
  }
}
