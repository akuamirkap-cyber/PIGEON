// @ts-nocheck
// Cinematic botanical rainforest & cloud-mountain ecosystem.
// Replaces low-poly geometric blobs with true volumetric 3D curved leaf-cluster bouquets,
// spherical outward canopy normals, custom backlit subsurface-scattering (SSS) foliage
// shader, gentle living wind gusts, 512x512 mossy tropical hardwood bark, sinuous curved
// buttress roots, swaying vine curtains, flowering flamboyant & tabebuia trees, graceful
// riverbank palms, bamboo groves, tree ferns, heliconia blooms, and highland cloud-pines.
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))
const UP = new THREE.Vector3(0, 1, 0)

// Harmonious painterly rainforest palette (calibrated for ACES Filmic + golden sunlight + SSS)
const DEEP_CANOPY = [
  '#1f5d34', '#246838', '#2a723c', '#317b3f', '#1e6042', '#276e49',
  '#38823e', '#43893f', '#2d6a35', '#3b7938',
]
const SUNLIT_EMERGENT = [
  '#2c7239', '#367e3d', '#428940', '#4f9241', '#2f7846', '#5b963e', '#3c833a',
]
const CLOUD_MONTANE = [
  '#1b533a', '#215f41', '#276a46', '#2e7348', '#1f5a46', '#357847', '#29653d',
]
const TROPICAL_BLOSSOMS = [
  '#ffbf3c', // Golden Tabebuia (Trumpet Tree)
  '#ff7847', // Royal Flamboyant (Flame of the Forest)
  '#f78cb6', // Tropical Pink Cassia
  '#ffa43b', // Sunset Pride-of-Burma
  '#b88cff', // Highland Jacaranda
]

function randomFor(seed) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// High-resolution 512x512 mossy rainforest hardwood bark texture
function makeMossyBarkTexture(seed, soft) {
  const rnd = randomFor(seed)
  const W = 256, H = 512
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')

  // Warm tropical walnut-grey bark transitioning to velvety emerald moss stocking at base
  const grad = ctx.createLinearGradient(0, H, 0, 0)
  grad.addColorStop(0.0, '#2a4d28')
  grad.addColorStop(0.18, '#3f5733')
  grad.addColorStop(0.36, '#5c4d3b')
  grad.addColorStop(0.72, '#73604a')
  grad.addColorStop(1.0, '#826e56')
  ctx.fillStyle = grad
  ctx.fillRect(0, 0, W, H)

  // Sinuous organic vertical bark ridges & deep shadow fissures
  for (let i = 0; i < 480; i++) {
    const x = rnd() * W
    const y = rnd() * H
    const h = 24 + rnd() * 140
    const sway = (rnd() - 0.5) * 14
    ctx.lineWidth = 0.9 + rnd() * 3.2
    const pick = rnd()
    ctx.strokeStyle = pick < 0.38
      ? 'rgba(24, 20, 14, 0.34)'
      : pick < 0.72
        ? 'rgba(186, 162, 124, 0.18)'
        : 'rgba(62, 112, 48, 0.30)'
    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.quadraticCurveTo(x + sway, y + h * 0.5, x + sway * 0.4, y + h)
    ctx.stroke()
  }

  // Soft pale-sage rainforest lichen & emerald moss cushions clinging to bark
  for (let i = 0; i < 95; i++) {
    const x = rnd() * W
    const y = (0.2 + 0.8 * Math.pow(rnd(), 0.7)) * H
    const rx = 5 + rnd() * 16
    const ry = 4 + rnd() * 14
    const g = ctx.createRadialGradient(x, y, 1, x, y, rx)
    if (i % 3 === 0) {
      g.addColorStop(0, 'rgba(165, 192, 142, 0.34)')
      g.addColorStop(1, 'rgba(165, 192, 142, 0)')
    } else {
      g.addColorStop(0, 'rgba(56, 122, 46, 0.48)')
      g.addColorStop(1, 'rgba(42, 95, 36, 0)')
    }
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.ellipse(x, y, rx, ry, rnd() * Math.PI, 0, Math.PI * 2)
    ctx.fill()
  }

  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping
  tex.magFilter = soft ? THREE.LinearFilter : THREE.NearestFilter
  tex.minFilter = soft ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter
  tex.generateMipmaps = soft
  if (soft) tex.anisotropy = 4
  return tex
}

// High-resolution 512x512 botanical canopy bouquet texture (neutral bright white-sage leaves
// with crisp midribs & depth variation so instanceColor tints both rich emerald leaves AND vivid blossoms!)
function makeBotanicalCanopyTexture(seed, soft) {
  const rnd = randomFor(seed)
  const S = 512
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = S
  const ctx = canvas.getContext('2d')
  ctx.clearRect(0, 0, S, S)

  const paintLeaf = (x, y, len, wid, ang, l0, l1, warmShift, vein) => {
    ctx.save()
    ctx.translate(x, y)
    ctx.rotate(ang)
    const g = ctx.createLinearGradient(0, 0, len, 0)
    const r0 = clamp(Math.round(l0 * (1 - warmShift * 0.08)), 0, 255)
    const g0 = clamp(Math.round(l0 * 1.03), 0, 255)
    const b0 = clamp(Math.round(l0 * (0.94 - warmShift * 0.08)), 0, 255)
    const r1 = clamp(Math.round(l1 * (1 + warmShift * 0.08)), 0, 255)
    const g1 = clamp(Math.round(l1 * 1.04), 0, 255)
    const b1 = clamp(Math.round(l1 * (0.86 - warmShift * 0.12)), 0, 255)
    g.addColorStop(0, `rgb(${r0},${g0},${b0})`)
    g.addColorStop(1, `rgb(${r1},${g1},${b1})`)
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.moveTo(0, 0)
    // Graceful pointed tropical drip-tip leaf silhouette!
    ctx.bezierCurveTo(len * 0.25, -wid, len * 0.68, -wid * 0.88, len * 0.92, -wid * 0.08)
    ctx.lineTo(len, 0)
    ctx.lineTo(len * 0.92, wid * 0.08)
    ctx.bezierCurveTo(len * 0.68, wid * 0.88, len * 0.25, wid, 0, 0)
    ctx.closePath()
    ctx.fill()

    if (vein > 0) {
      ctx.strokeStyle = `rgba(255,255,240,${vein})`
      ctx.lineWidth = 1.35
      ctx.beginPath()
      ctx.moveTo(len * 0.06, 0)
      ctx.lineTo(len * 0.88, 0)
      ctx.stroke()
    }
    ctx.restore()
  }

  // Paint overlapping botanical leaf rosettes: dense inner core + lacy feathered tropical rim!
  const passes = [
    { n: 95, rMax: 155, lMin: 48, lMax: 84, b0: 122, b1: 158, warm: 0.1, vein: 0.0 },
    { n: 125, rMax: 188, lMin: 40, lMax: 74, b0: 158, b1: 205, warm: 0.35, vein: 0.16 },
    { n: 110, rMax: 208, lMin: 30, lMax: 60, b0: 192, b1: 244, warm: 0.65, vein: 0.28 },
    // Delicate outer acacia/mimosa tip leaflets for gorgeous natural sky silhouettes!
    { n: 85, rMax: 222, lMin: 18, lMax: 38, b0: 210, b1: 252, warm: 0.8, vein: 0.2 },
  ]
  for (const P of passes) {
    for (let i = 0; i < P.n; i++) {
      const a = rnd() * Math.PI * 2
      const r = Math.pow(rnd(), 0.62) * P.rMax
      const cx = S * 0.5 + Math.cos(a) * r
      const cy = S * 0.5 + Math.sin(a) * r
      const len = P.lMin + rnd() * (P.lMax - P.lMin)
      const wid = len * (0.31 + rnd() * 0.16)
      const ang = a + (rnd() - 0.5) * 1.1
      const jitter = (rnd() - 0.5) * 18
      paintLeaf(cx, cy, len, wid, ang, P.b0 + jitter, P.b1 + jitter, P.warm, P.vein)
    }
  }

  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.magFilter = soft ? THREE.LinearFilter : THREE.NearestFilter
  tex.minFilter = soft ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter
  tex.generateMipmaps = soft
  if (soft) tex.anisotropy = 4
  return tex
}

// Draping rainforest vine & Spanish-moss curtain texture (true crisp alpha!)
function makeVineCurtainTexture(seed, soft) {
  const rnd = randomFor(seed)
  const W = 256, H = 512
  const canvas = document.createElement('canvas')
  canvas.width = W
  canvas.height = H
  const ctx = canvas.getContext('2d')
  ctx.clearRect(0, 0, W, H)

  const strands = 14
  for (let s = 0; s < strands; s++) {
    let x = 18 + (s / (strands - 1)) * (W - 36) + (rnd() - 0.5) * 12
    const maxY = H * (0.42 + rnd() * 0.55)
    ctx.strokeStyle = s % 2 ? 'rgb(145, 185, 130)' : 'rgb(115, 160, 105)'
    ctx.lineWidth = 2.2 + rnd() * 1.8
    ctx.beginPath()
    ctx.moveTo(x, 0)
    const phase = rnd() * 6.28
    for (let y = 12; y <= maxY; y += 12) {
      const nx = x + Math.sin(y * 0.025 + phase) * 7
      ctx.lineTo(nx, y)
    }
    ctx.stroke()
    // Dainty hanging ivy/philodendron leaves along every trailing liana!
    for (let y = 14; y < maxY - 12; y += 15 + rnd() * 12) {
      const lx = x + Math.sin(y * 0.025 + phase) * 7
      const side = rnd() < 0.5 ? -1 : 1
      const ll = 10 + rnd() * 11
      const lw = ll * 0.48
      ctx.save()
      ctx.translate(lx, y)
      ctx.rotate(Math.PI * 0.5 + side * (0.45 + rnd() * 0.45))
      const bright = Math.round(165 + (1 - y / maxY) * 75)
      ctx.fillStyle = `rgb(${Math.round(bright * 0.88)},${bright},${Math.round(bright * 0.78)})`
      ctx.beginPath()
      ctx.moveTo(0, 0)
      ctx.quadraticCurveTo(ll * 0.5, -lw, ll, 0)
      ctx.quadraticCurveTo(ll * 0.5, lw, 0, 0)
      ctx.fill()
      ctx.restore()
    }
  }
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.magFilter = soft ? THREE.LinearFilter : THREE.NearestFilter
  tex.minFilter = soft ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter
  tex.generateMipmaps = soft
  return tex
}

// Lush tropical jungle fern & broadleaf understory bush texture
function makeUnderstoryTexture(seed, soft) {
  const rnd = randomFor(seed)
  const S = 384
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = S
  const ctx = canvas.getContext('2d')
  ctx.clearRect(0, 0, S, S)

  for (let i = 0; i < 62; i++) {
    const k = i / 62
    const bx = S * (0.2 + rnd() * 0.6)
    const by = S * (0.95 - rnd() * 0.14)
    const ang = -Math.PI * 0.5 + (rnd() - 0.5) * 1.75
    const len = 95 + rnd() * 175
    const wid = 20 + rnd() * 36
    ctx.save()
    ctx.translate(bx, by)
    ctx.rotate(ang)
    const l0 = Math.round(115 + k * 75)
    const l1 = Math.round(170 + k * 82)
    const g = ctx.createLinearGradient(0, 0, len, 0)
    g.addColorStop(0, `rgb(${Math.round(l0 * 0.85)},${l0},${Math.round(l0 * 0.82)})`)
    g.addColorStop(1, `rgb(${Math.round(l1 * 0.98)},${l1},${Math.round(l1 * 0.78)})`)
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.bezierCurveTo(len * 0.32, -wid, len * 0.72, -wid * 0.8, len, 0)
    ctx.bezierCurveTo(len * 0.72, wid * 0.8, len * 0.32, wid, 0, 0)
    ctx.closePath()
    ctx.fill()
    ctx.strokeStyle = 'rgba(248,255,220,0.32)'
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(8, 0)
    ctx.lineTo(len * 0.88, 0)
    ctx.stroke()
    ctx.restore()
  }

  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.magFilter = soft ? THREE.LinearFilter : THREE.NearestFilter
  tex.minFilter = soft ? THREE.LinearMipmapLinearFilter : THREE.NearestFilter
  tex.generateMipmaps = soft
  return tex
}

function shadowTexture() {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = 128
  const ctx = canvas.getContext('2d')
  const g = ctx.createRadialGradient(64, 64, 4, 64, 64, 62)
  g.addColorStop(0, 'rgba(8, 28, 14, 0.58)')
  g.addColorStop(0.5, 'rgba(10, 34, 18, 0.28)')
  g.addColorStop(1, 'rgba(10, 34, 18, 0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 128, 128)
  return new THREE.CanvasTexture(canvas)
}

// ── Studio Ghibli / Horizon Volumetric Botanical Leaf-Cloud Bouquet!
// 20 curved dome leaf-cards arranged in a dense pillowy umbrella canopy with SPHERICAL OUTWARD NORMALS
// and baked interior-to-tip self-shadowing (zero flat-shaded polyhedron facets, zero flat X-plane artifacts!).
function makeVolumetricCrownGeometry(seed = 11) {
  const rnd = randomFor(seed)
  const parts = []
  const goldenAngle = Math.PI * (3 - Math.sqrt(5))
  const cardCount = 15

  // Helper: create a gently domed 2x2 leaf card facing outward from canopy center
  const makeDomedCard = (dirX, dirY, dirZ, radius, cardSize, spin) => {
    const g = new THREE.PlaneGeometry(cardSize, cardSize, 2, 2)
    const p = g.attributes.position
    for (let i = 0; i < p.count; i++) {
      const lx = p.getX(i), ly = p.getY(i)
      const r2 = (lx * lx + ly * ly) / (cardSize * cardSize * 0.5)
      // Cup gently inward around the crown so every angle looks plump and organic!
      p.setZ(i, -r2 * cardSize * 0.16)
    }
    const normal = new THREE.Vector3(dirX, dirY, dirZ).normalize()
    const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal)
    const spinQ = new THREE.Quaternion().setFromAxisAngle(normal, spin)
    quat.premultiply(spinQ)
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(dirX * radius, dirY * radius * 0.62, dirZ * radius),
      quat,
      new THREE.Vector3(1, 1, 1),
    )
    g.applyMatrix4(m)

    // Assign smooth SPHERICAL OUTWARD NORMALS + baked interior-to-crown AO & wind weight!
    const pos = g.attributes.position
    const nor = g.attributes.normal
    const col = new Float32Array(pos.count * 3)
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i), vy = pos.getY(i), vz = pos.getZ(i)
      const sn = new THREE.Vector3(vx, vy * 1.45 + 0.28, vz).normalize()
      nor.setXYZ(i, sn.x, sn.y, sn.z)
      const shellDist = clamp(Math.hypot(vx, vy * 1.35, vz) / 1.18, 0, 1.15)
      const topLift = clamp((vy + 0.58) / 1.25, 0, 1)
      // Deep emerald shadow inside & beneath crown, luminous warm sunlit leaves on top & outer tips!
      const ao = clamp(0.46 + 0.34 * topLift + 0.30 * shellDist, 0.42, 1.15)
      col[i * 3] = ao * (0.9 + 0.16 * topLift)
      col[i * 3 + 1] = ao * 1.02
      col[i * 3 + 2] = ao * (1.02 - 0.12 * topLift)
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3))
    return g
  }

  // Outer billowing Fibonacci umbrella puffs
  for (let k = 0; k < cardCount; k++) {
    const t = k / (cardCount - 1)
    // Concentrate rich leaf cards across upper dome & equatorial rim, fewer beneath
    const y = -0.34 + 1.32 * Math.pow(t, 0.85)
    const rRing = Math.sqrt(Math.max(0, 1 - Math.min(1, y * y)))
    const theta = k * goldenAngle
    const dx = Math.cos(theta) * rRing
    const dz = Math.sin(theta) * rRing
    const rad = 0.38 + 0.24 * rnd()
    const sz = 1.28 + 0.26 * rnd()
    parts.push(makeDomedCard(dx, y, dz, rad, sz, rnd() * Math.PI * 2))
  }
  // 2 dense interior cross-baffles so sunlight never finds an empty hole through the heart of a crown!
  for (let c = 0; c < 2; c++) {
    const a = (c / 2) * Math.PI + 0.35
    parts.push(makeDomedCard(Math.cos(a), 0.36, Math.sin(a), 0.06, 1.46, a))
  }

  const merged = mergeGeometries(parts)
  parts.forEach((p) => p.dispose())
  return merged
}

// ── Layered Botanical Cloud-Pine / Agathis Mountain Tree Geometry (feathery whorled bough fans, ZERO traffic cones!)
function makeMontaneBoughGeometry(seed = 29) {
  const rnd = randomFor(seed)
  const parts = []
  const tiers = 5
  for (let t = 0; t < tiers; t++) {
    const tf = t / (tiers - 1) // 0 = wide lower bough whorl .. 1 = slender sunlit crown spire
    const y = 0.18 + tf * 0.76
    const tierR = (1.0 - tf * 0.62) * 0.95
    const fans = t < 3 ? 4 : 3
    for (let f = 0; f < fans; f++) {
      const a = (f / fans) * Math.PI * 2 + t * 0.85 + (rnd() - 0.5) * 0.25
      const sz = tierR * 1.48
      const g = new THREE.PlaneGeometry(sz, sz, 2, 2)
      const p = g.attributes.position
      for (let i = 0; i < p.count; i++) {
        const lx = p.getX(i), ly = p.getY(i)
        // Graceful drooping cedar/agathis bough arch
        p.setZ(i, -(lx * lx + ly * ly) / (sz * 1.8))
      }
      const dir = new THREE.Vector3(Math.cos(a) * 0.72, 0.68 + tf * 0.25, Math.sin(a) * 0.72).normalize()
      const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir)
      const m = new THREE.Matrix4().compose(
        new THREE.Vector3(Math.cos(a) * tierR * 0.34, y, Math.sin(a) * tierR * 0.34),
        q,
        new THREE.Vector3(1, 1, 1),
      )
      g.applyMatrix4(m)
      const pos = g.attributes.position
      const nor = g.attributes.normal
      const col = new Float32Array(pos.count * 3)
      for (let i = 0; i < pos.count; i++) {
        const vx = pos.getX(i), vy = pos.getY(i), vz = pos.getZ(i)
        const sn = new THREE.Vector3(vx, 0.55 + tf * 0.45, vz).normalize()
        nor.setXYZ(i, sn.x, sn.y, sn.z)
        const ao = clamp(0.48 + tf * 0.46 + clamp(Math.hypot(vx, vz) / (tierR + 0.2), 0, 0.22), 0.45, 1.12)
        col[i * 3] = ao * 0.92
        col[i * 3 + 1] = ao * 1.02
        col[i * 3 + 2] = ao * 0.98
      }
      g.setAttribute('color', new THREE.BufferAttribute(col, 3))
      parts.push(g)
    }
  }
  const merged = mergeGeometries(parts)
  parts.forEach((p) => p.dispose())
  return merged
}

// Smooth, organically fluted & gently curving rainforest hardwood trunk (12 radial segments, silky normals)
function makeOrganicTrunkGeometry() {
  const geo = new THREE.CylinderGeometry(0.52, 1.28, 1, 12, 8).translate(0, 0.5, 0)
  const pos = geo.attributes.position
  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i)
    const ang = Math.atan2(z, x)
    // Smooth botanical root-crown buttress fluting on bottom 30%
    const flare = Math.pow(Math.max(0, 1 - y / 0.32), 2.1)
    const flute = 1 + flare * (0.24 + 0.18 * Math.cos(ang * 5) + 0.07 * Math.sin(ang * 3))
    x *= flute
    z *= flute
    // Natural graceful S-curve growth toward sunlight
    x += Math.sin(y * Math.PI * 1.1) * 0.24
    z += (Math.cos(y * Math.PI * 0.85) - 1) * 0.11
    pos.setXYZ(i, x, y, z)
  }
  geo.computeVertexNormals()
  return geo
}

// Smooth curved plank buttress root (sinuous rainforest Kapok / Tualang fin root with rounded spine!)
function makeCurvedButtressGeometry() {
  const segs = 7
  const pos = []
  const uv = []
  const idx = []
  // Cross-section profile around the root fin: bottom-left -> rounded top spine -> bottom-right
  const prof = [
    [-1, 0, 0],
    [-0.65, 0.65, 0.25],
    [0, 1, 0.5],
    [0.65, 0.65, 0.75],
    [1, 0, 1],
  ]
  const cols = prof.length
  for (let s = 0; s <= segs; s++) {
    const t = s / segs // 0 = trunk attachment .. 1 = mossy forest floor tip
    const x = t
    // Concave sweeping rainforest buttress curve
    const crestY = Math.pow(1 - t, 1.85)
    // Gentle serpentine ground wiggle as root snakes across moss
    const snaking = Math.sin(t * Math.PI * 1.4) * 0.12 * t
    const halfThick = 0.24 * (1 - t * 0.68)
    for (let c = 0; c < cols; c++) {
      const [pz, py, u] = prof[c]
      pos.push(x, crestY * py, snaking + pz * halfThick)
      uv.push(u, 1 - crestY * py)
    }
    if (s < segs) {
      const b = s * cols
      for (let c = 0; c < cols - 1; c++) {
        idx.push(b + c, b + cols + c, b + c + 1, b + c + 1, b + cols + c, b + cols + c + 1)
      }
    }
  }
  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2))
  geo.setIndex(idx)
  geo.computeVertexNormals()
  return geo
}

// Graceful multi-leaflet arching tropical palm / tree-fern frond with translucent golden-tip gradient
function makeFeatheryFrondGeometry() {
  const positions = []
  const colors = []
  const indices = []
  const segments = 26
  for (let i = 0; i <= segments; i++) {
    const t = i / segments
    const env = Math.pow(Math.sin(Math.PI * t), 0.65)
    const serration = i % 2 === 0 ? 1.0 : 0.42
    const w = env * 0.23 * serration
    const y = 0.28 * Math.sin(Math.PI * t * 0.88) - 0.38 * t * t
    const droop = i % 2 === 0 ? -w * 0.24 : 0
    // Spine vertex + left/right leaflet vertices for genuine 3D V-ribbed frond depth!
    const spineLit = 0.72 + 0.34 * t
    const tipLit = 0.68 + 0.44 * Math.pow(t, 0.7)
    positions.push(t, y, 0)
    colors.push(spineLit * 1.05, spineLit * 1.06, spineLit * 0.82)
    positions.push(t, y + droop, -w)
    colors.push(tipLit * 0.96, tipLit * 1.02, tipLit * 0.86)
    positions.push(t, y + droop, w)
    colors.push(tipLit * 1.02, tipLit * 1.04, tipLit * 0.84)
    if (i < segments) {
      const a = i * 3, b = (i + 1) * 3
      indices.push(a, a + 1, b, a + 1, b + 1, b)
      indices.push(a, b, a + 2, a + 2, b, b + 2)
    }
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
  g.setIndex(indices)
  g.computeVertexNormals()
  return g
}

// Broad sculpted heart-shaped tropical Alocasia / Monstera leaf with graceful curved arch
function makeAlocasiaLeafGeometry() {
  const positions = [
    0.0, 0.0, 0.0,      // stem base
    0.16, 0.38, 0.0,    // petiole crown
    0.06, 0.42, -0.24,  // left heart lobe
    0.06, 0.42, 0.24,   // right heart lobe
    0.46, 0.56, -0.36,  // left mid blade
    0.48, 0.60, 0.0,    // midrib arch
    0.46, 0.56, 0.36,   // right mid blade
    0.78, 0.48, -0.22,  // left fore blade
    0.78, 0.48, 0.22,   // right fore blade
    1.04, 0.30, 0.0,    // drooping drip tip
  ]
  const colors = [
    0.52, 0.62, 0.52,
    0.76, 0.86, 0.68,
    0.72, 0.82, 0.68,
    0.74, 0.84, 0.68,
    0.88, 0.96, 0.78,
    1.04, 1.08, 0.86,
    0.92, 0.98, 0.80,
    0.98, 1.04, 0.82,
    1.00, 1.05, 0.82,
    1.12, 1.12, 0.82,
  ]
  const indices = [
    0, 2, 1, 0, 1, 3,
    1, 2, 4, 1, 4, 5, 1, 5, 6, 1, 6, 3,
    4, 7, 5, 5, 7, 9, 5, 9, 8, 5, 8, 6,
  ]
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  g.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3))
  g.setIndex(indices)
  g.computeVertexNormals()
  return g
}

function makeVineCurtainGeometry() {
  const a = new THREE.PlaneGeometry(1, 1, 1, 4).translate(0, -0.5, 0)
  const b = a.clone().rotateY(Math.PI * 0.5)
  const merged = mergeGeometries([a, b])
  a.dispose()
  b.dispose()
  return merged
}

function makeLushBushGeometry() {
  const parts = []
  for (let k = 0; k < 4; k++) {
    const g = new THREE.PlaneGeometry(1, 0.88, 1, 2).translate(0, 0.42, 0)
    g.rotateX(0.14)
    g.rotateY((k / 4) * Math.PI + (k % 2) * 0.2)
    parts.push(g)
  }
  const merged = mergeGeometries(parts)
  parts.forEach((p) => p.dispose())
  return merged
}

// ── Custom Sunlit Subsurface-Scattering (SSS) + Living Wind Rainforest Foliage ShaderMaterial!
function makeSunlitFoliageMaterial({ map, alphaTest = 0.35, vertexColors = false, windAmp = 0.45, sssStrength = 0.52, sharedUniforms }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      ...sharedUniforms,
      uMap: { value: map || null },
      uHasMap: { value: map ? 1 : 0 },
      uAlphaTest: { value: alphaTest },
      uUseVCol: { value: vertexColors ? 1 : 0 },
      uWindAmp: { value: windAmp },
      uSss: { value: sssStrength },
    },
    side: THREE.DoubleSide,
    vertexShader: `
      #ifdef USE_INSTANCING_COLOR
        varying vec3 vICol;
      #endif
      ${vertexColors ? 'attribute vec3 color; varying vec3 vVCol;' : ''}
      varying vec2 vUv;
      varying vec3 vWorld;
      varying vec3 vNormalW;
      uniform float uTime, uWindAmp;
      void main(){
        vUv = uv;
        #ifdef USE_INSTANCING_COLOR
          vICol = instanceColor;
        #endif
        ${vertexColors ? 'vVCol = color;' : ''}
        vec4 local = vec4(position, 1.0);
        #ifdef USE_INSTANCING
          vec4 world = modelMatrix * instanceMatrix * local;
          vec3 nW = normalize(mat3(modelMatrix) * mat3(instanceMatrix) * normal);
        #else
          vec4 world = modelMatrix * local;
          vec3 nW = normalize(mat3(modelMatrix) * normal);
        #endif
        // Cohesive travelling tropical wind gusts fluttering leaves, fronds & hanging vines!
        float tipFlex = clamp(length(position.xz) * 0.85 + abs(position.y) * 0.45, 0.0, 1.5);
        float gust = sin(uTime * 1.65 + world.x * 0.042 + world.z * 0.031)
                   + 0.45 * cos(uTime * 2.9 + world.x * 0.11 - world.z * 0.09 + position.y * 2.2);
        world.x += gust * uWindAmp * tipFlex;
        world.z += cos(uTime * 1.35 + world.z * 0.048 + world.x * 0.025) * uWindAmp * 0.7 * tipFlex;
        world.y += sin(uTime * 2.1 + world.x * 0.07 + position.x * 3.0) * uWindAmp * 0.22 * tipFlex;
        vWorld = world.xyz;
        vNormalW = nW;
        gl_Position = projectionMatrix * viewMatrix * world;
      }`,
    fragmentShader: `
      #ifdef USE_INSTANCING_COLOR
        varying vec3 vICol;
      #endif
      ${vertexColors ? 'varying vec3 vVCol;' : ''}
      varying vec2 vUv;
      varying vec3 vWorld;
      varying vec3 vNormalW;
      ${map ? 'uniform sampler2D uMap;' : ''}
      uniform float uAlphaTest, uSss, uFogD, uSoft, uNight;
      uniform vec3 uSunDir, uSunCol, uSkyAmb, uGroundAmb, uFogCol;
      void main(){
        vec3 base = vec3(1.0);
        ${map ? 'vec4 tx = texture2D(uMap, vUv); if (tx.a < uAlphaTest) discard; base = tx.rgb;' : ''}
        #ifdef USE_INSTANCING_COLOR
          base *= vICol;
        #endif
        ${vertexColors ? 'base *= vVCol;' : ''}

        vec3 N = normalize(vNormalW);
        vec3 L = normalize(uSunDir);
        vec3 V = normalize(cameraPosition - vWorld);

        // Soft Ghibli/Horizon wrap-diffuse so sunlight caresses the whole lush canopy dome!
        float wrap = clamp((dot(N, L) + 0.48) / 1.48, 0.0, 1.0);
        if (uSoft < 0.5) wrap = floor(wrap * 4.0 + 0.5) / 4.0;

        // Lush sky-jade vs deep forest-moss hemisphere bounce (zero dead grey shadows!)
        float hemiK = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
        vec3 amb = mix(uGroundAmb, uSkyAmb, hemiK);

        // Warm golden-lime backlit Subsurface Scattering (SSS) when sun shines through tropical leaves!
        float backLight = pow(clamp(dot(V, -L), 0.0, 1.0), 2.8);
        float rimTrans = pow(1.0 - abs(dot(N, V)), 1.8) * 0.45 + 0.55;
        vec3 sssCol = base * vec3(1.38, 1.42, 0.62) * uSunCol * (backLight * rimTrans + pow(wrap, 2.0) * 0.22) * uSss;

        // Subtle morning-dew wet rainforest leaf specular sheen
        vec3 H = normalize(L + V);
        float dewSpec = pow(max(dot(N, H), 0.0), 28.0) * 0.11 * (1.0 - uNight * 0.6);

        // Sunlit warm-gold shift on direct-lit crown leaves, rich cool emerald-teal in deep shade
        vec3 shadeTint = mix(vec3(0.78, 0.98, 1.08), vec3(1.14, 1.08, 0.86), wrap);
        vec3 col = base * 1.35 * shadeTint * (amb + uSunCol * wrap * 1.18) + sssCol * 1.2 + uSunCol * dewSpec;

        // Atmospheric aerial perspective + warm golden sun-inscatter in the rainforest valley mist!
        float dist = length(vWorld - cameraPosition);
        float heightMist = clamp(1.0 - (vWorld.y - 18.0) / 110.0, 0.0, 1.0) * 0.22 * smoothstep(95.0, 540.0, dist);
        float fog = clamp(1.0 - exp(-uFogD * uFogD * dist * dist) + heightMist, 0.0, 1.0);
        float sunScatter = pow(clamp(dot(-V, L), 0.0, 1.0), 5.0) * (1.0 - uNight * 0.8);
        vec3 mistCol = mix(uFogCol, uFogCol * 0.74 + uSunCol * 0.42, sunScatter * 0.46);
        col = mix(col, mistCol, fog);

        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })
}

export function buildRainforest(arena, { soft = true, density = 1, sunDir, fogColor = '#b8dfd0', fogDensity = 0.00055, tod = 'day' } = {}) {
  const rnd = randomFor(Math.round(arena.opts.seed) * 19391 + 127)
  const { cells: n, C, ox, oz } = arena
  const amount = clamp(Number.isFinite(density) ? density : 1, 0.4, 1.5)
  const group = new THREE.Group()
  group.name = 'rainforest'

  const sunV = (sunDir ? sunDir.clone() : new THREE.Vector3(0.45, 0.72, 0.35)).normalize()
  const sunCol = tod === 'sunset'
    ? new THREE.Color('#ff9d52').multiplyScalar(1.22)
    : tod === 'night'
      ? new THREE.Color('#6c96e8').multiplyScalar(0.55)
      : new THREE.Color('#fff2d2').multiplyScalar(1.12)
  const skyAmb = tod === 'sunset'
    ? new THREE.Color('#c88b7e').multiplyScalar(0.58)
    : tod === 'night'
      ? new THREE.Color('#235468').multiplyScalar(0.52)
      : new THREE.Color('#8cdac6').multiplyScalar(0.62)
  const groundAmb = tod === 'sunset'
    ? new THREE.Color('#4a3824').multiplyScalar(0.42)
    : tod === 'night'
      ? new THREE.Color('#0c2824').multiplyScalar(0.42)
      : new THREE.Color('#1d4c28').multiplyScalar(0.45)

  const sharedUniforms = {
    uTime: { value: 0 },
    uSunDir: { value: sunV },
    uSunCol: { value: new THREE.Vector3(sunCol.r, sunCol.g, sunCol.b) },
    uSkyAmb: { value: new THREE.Vector3(skyAmb.r, skyAmb.g, skyAmb.b) },
    uGroundAmb: { value: new THREE.Vector3(groundAmb.r, groundAmb.g, groundAmb.b) },
    uFogCol: { value: new THREE.Color(fogColor) },
    uFogD: { value: fogDensity },
    uSoft: { value: soft ? 1 : 0 },
    uNight: { value: tod === 'night' ? 1 : 0 },
  }

  const trees = []
  const spacing = new Map()
  const spacingCell = 18
  const treesBySpecies = { colossus: 0, emergent: 0, banyan: 0, broadleaf: 0, palm: 0, montane: 0, blossom: 0 }

  const sampleEdge = (x, z) => {
    const i = clamp(Math.floor((x - ox) / C), 0, n - 1)
    const j = clamp(Math.floor((z - oz) / C), 0, n - 1)
    return arena.edge[j * n + i]
  }
  const riverAt = (x, z) => (arena.riverAt ? arena.riverAt(x, z) : 0)
  const slopeAt = (x, z) => {
    const dx = (arena.groundAt(x + C, z) - arena.groundAt(x - C, z)) / (2 * C)
    const dz = (arena.groundAt(x, z + C) - arena.groundAt(x, z - C)) / (2 * C)
    return Math.hypot(dx, dz)
  }

  const valid = (x, z, radius, { minEdge = 7, maxSlope = 1.25, packFactor = 0.38 } = {}) => {
    if (x < ox + 18 || z < oz + 18 || x > ox + arena.size - 18 || z > oz + arena.size - 18) return false
    if (sampleEdge(x, z) < minEdge) return false
    if (riverAt(x, z) > 0.43) return false
    if (slopeAt(x, z) > maxSlope) return false
    for (const gate of arena.gates) {
      if (Math.hypot(gate.x - x, gate.z - z) < gate.r + 17) return false
    }
    const ix = Math.floor(x / spacingCell), iz = Math.floor(z / spacingCell)
    for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) {
      const bucket = spacing.get(`${ix + a},${iz + b}`)
      if (!bucket) continue
      for (const other of bucket) {
        if (Math.hypot(x - other.x, z - other.z) < Math.max(6.4, (radius + other.canopy) * packFactor)) return false
      }
    }
    return true
  }

  const place = (x, z, forced, opts = {}) => {
    const y = arena.groundAt(x, z)
    const sl = slopeAt(x, z)
    const rv = riverAt(x, z)
    let kind = forced
    if (!kind) {
      const p = rnd()
      if (y > 125 || (y > 95 && sl > 0.42)) {
        kind = p < 0.52 ? 'montane' : p < 0.78 ? 'broadleaf' : p < 0.93 ? 'emergent' : 'colossus'
      } else if (rv > 0.06 && rv <= 0.43) {
        kind = p < 0.38 ? 'palm' : p < 0.62 ? 'banyan' : p < 0.80 ? 'emergent' : p < 0.90 ? 'colossus' : 'blossom'
      } else {
        kind = p < 0.08 ? 'colossus'
          : p < 0.32 ? 'emergent'
            : p < 0.49 ? 'banyan'
              : p < 0.76 ? 'broadleaf'
                : p < 0.91 ? 'palm'
                  : 'blossom'
      }
    }

    let height, canopy, trunk, tint
    if (kind === 'colossus') {
      height = 86 + rnd() * 50 // 86 - 136 m awe-inspiring ancient Kapok / Tualang titans!
      canopy = 25 + rnd() * 13
      trunk = 3.2 + rnd() * 2.1
      tint = SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)]
    } else if (kind === 'emergent') {
      height = 54 + rnd() * 32
      canopy = 17 + rnd() * 8.5
      trunk = 2.0 + rnd() * 1.3
      tint = SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)]
    } else if (kind === 'banyan') {
      height = 36 + rnd() * 24
      canopy = 19 + rnd() * 9
      trunk = 2.0 + rnd() * 1.2
      tint = DEEP_CANOPY[Math.floor(rnd() * DEEP_CANOPY.length)]
    } else if (kind === 'montane') {
      height = 36 + rnd() * 38
      canopy = 13 + rnd() * 7
      trunk = 1.2 + rnd() * 0.85
      tint = CLOUD_MONTANE[Math.floor(rnd() * CLOUD_MONTANE.length)]
    } else if (kind === 'palm') {
      height = 22 + rnd() * 22
      canopy = 12 + rnd() * 5.5
      trunk = 0.58 + rnd() * 0.36
      tint = SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)]
    } else if (kind === 'blossom') {
      height = 28 + rnd() * 24
      canopy = 15 + rnd() * 7
      trunk = 1.3 + rnd() * 0.8
      tint = TROPICAL_BLOSSOMS[Math.floor(rnd() * TROPICAL_BLOSSOMS.length)]
    } else {
      height = 28 + rnd() * 26
      canopy = 13.5 + rnd() * 6.5
      trunk = 1.2 + rnd() * 0.85
      tint = DEEP_CANOPY[Math.floor(rnd() * DEEP_CANOPY.length)]
    }

    const maxSlope = kind === 'montane' ? 2.25 : opts.maxSlope ?? 1.28
    if (!valid(x, z, canopy, { ...opts, maxSlope })) return false

    let rotation = rnd() * Math.PI * 2
    if (kind === 'palm' && rv > 0.04) {
      const gx = riverAt(x + 8, z) - riverAt(x - 8, z)
      const gz = riverAt(x, z + 8) - riverAt(x, z - 8)
      if (Math.hypot(gx, gz) > 0.01) rotation = Math.atan2(-gz, gx) + (rnd() - 0.5) * 0.42
    }

    const tree = { x, z, y, height, canopy, trunk, kind, rotation, tint }
    trees.push(tree)
    treesBySpecies[kind] = (treesBySpecies[kind] || 0) + 1
    const key = `${Math.floor(x / spacingCell)},${Math.floor(z / spacingCell)}`
    if (!spacing.has(key)) spacing.set(key, [])
    spacing.get(key).push(tree)
    return true
  }

  // ── PASS 1: Monumental Colossal Ancient Giants framing valley turns, waterfalls, rivers & sacred islands
  for (const path of arena.paths) {
    const stride = path.kind === 'main' ? Math.max(8, Math.round(12 / amount)) : 15
    for (let i = 4; i < path.pts.length - 4; i += stride) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / len, rz = (b[0] - a[0]) / len
      const side = i % 2 === 0 ? 1 : -1
      const off = path.halfW + 15 + rnd() * 20
      place(q[0] + rx * off * side, q[1] + rz * off * side, 'colossus', { minEdge: 9.5, packFactor: 0.35 })
    }
  }

  // ── PASS 2: Multi-tier scenic corridor wall (golden/coral blossom trees, arching palms, cathedral banyans, tall emergents)
  for (const path of arena.paths) {
    const step = Math.max(4, Math.round(6.5 / amount))
    for (let i = 3; i < path.pts.length - 3; i += step) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / len, rz = (b[0] - a[0]) / len
      for (const side of [-1, 1]) {
        const off1 = path.halfW + 9.5 + rnd() * 13
        const r1 = rnd()
        const k1 = r1 < 0.28 ? 'emergent' : r1 < 0.50 ? 'palm' : r1 < 0.70 ? 'banyan' : r1 < 0.87 ? 'broadleaf' : 'blossom'
        place(q[0] + rx * off1 * side, q[1] + rz * off1 * side, k1, { minEdge: 6.8, packFactor: 0.34 })

        const off2 = path.halfW + 28 + rnd() * 24
        const r2 = rnd()
        const k2 = r2 < 0.22 ? 'colossus' : r2 < 0.58 ? 'emergent' : r2 < 0.80 ? 'broadleaf' : r2 < 0.93 ? 'banyan' : 'blossom'
        place(q[0] + rx * off2 * side, q[1] + rz * off2 * side, k2, { minEdge: 10, packFactor: 0.35 })
      }
    }
  }

  // ── PASS 3: Enchanted Riverbank & Lagoon Sanctuary Vegetation (palms, flowering trees, bamboo groves, tree ferns)
  const bambooClumps = []
  const treeFerns = []
  for (const rv of arena.rivers || []) {
    const stride = rv.kind === 'tributary' ? 4 : 3
    for (let i = 2; i < rv.pts.length - 2; i += stride) {
      const a = rv.pts[i - 1], b = rv.pts[i + 1], q = rv.pts[i]
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / len, rz = (b[0] - a[0]) / len
      const hw = q[2]
      for (const side of [-1, 1]) {
        const bx = q[0] + rx * side * (hw + 6.5 + rnd() * 9)
        const bz = q[1] + rz * side * (hw + 6.5 + rnd() * 9)
        if (sampleEdge(bx, bz) >= 5.8) {
          const pick = rnd()
          const kind = pick < 0.40 ? 'palm' : pick < 0.62 ? 'banyan' : pick < 0.78 ? 'emergent' : pick < 0.90 ? 'blossom' : 'colossus'
          place(bx, bz, kind, { minEdge: 5.8, packFactor: 0.32 })
        }
        if (rnd() < 0.42 && bambooClumps.length < 240) {
          const gx = q[0] + rx * side * (hw + 4.8 + rnd() * 7)
          const gz = q[1] + rz * side * (hw + 4.8 + rnd() * 7)
          if (sampleEdge(gx, gz) >= 4.8 && riverAt(gx, gz) <= 0.4) {
            bambooClumps.push({ x: gx, z: gz, y: arena.groundAt(gx, gz), h: 17 + rnd() * 13, rot: rnd() * 6.28 })
          }
        }
        if (rnd() < 0.42 && treeFerns.length < 320) {
          const fx = q[0] + rx * side * (hw + 3.8 + rnd() * 8)
          const fz = q[1] + rz * side * (hw + 3.8 + rnd() * 8)
          if (sampleEdge(fx, fz) >= 3.8 && riverAt(fx, fz) <= 0.42) {
            treeFerns.push({ x: fx, z: fz, y: arena.groundAt(fx, fz), h: 6.5 + rnd() * 7.5, rot: rnd() * 6.28 })
          }
        }
      }
    }
  }
  for (const lg of arena.lagoons || []) {
    const cs = Math.cos(lg.rot), sn = Math.sin(lg.rot)
    for (let k = 0; k < 15; k++) {
      const ang = (k / 15) * Math.PI * 2 + rnd() * 0.22
      const wx = lg.x + Math.cos(ang) * (lg.rx + 8 + rnd() * 10) * cs - Math.sin(ang) * (lg.rz + 8 + rnd() * 10) * sn
      const wz = lg.z + Math.cos(ang) * (lg.rx + 8 + rnd() * 10) * sn + Math.sin(ang) * (lg.rz + 8 + rnd() * 10) * cs
      const kind = k % 4 === 0 ? 'blossom' : k % 5 === 0 ? 'colossus' : k % 3 === 0 ? 'banyan' : 'palm'
      place(wx, wz, kind, { minEdge: 5.8, packFactor: 0.33 })
    }
  }

  // ── PASS 4: Dense Cloud-Forest Blanketing Every Single Mountain Peak, Ridge & Mossy Karst Tower!
  for (const pk of arena.peaks || []) {
    const count = pk.kind === 'central'
      ? Math.round(250 * amount)
      : pk.kind === 'ridge'
        ? Math.round(115 * amount)
        : Math.round(36 * amount)
    for (let k = 0; k < count; k++) {
      const ang = rnd() * Math.PI * 2
      const rf = Math.pow(rnd(), 0.58)
      const tx = pk.x + Math.cos(ang) * pk.radius * rf * 0.98
      const tz = pk.z + Math.sin(ang) * pk.radius * rf * 0.98
      const rChoice = rnd()
      const kind = pk.kind === 'karst'
        ? (rChoice < 0.40 ? 'banyan' : rChoice < 0.72 ? 'emergent' : rChoice < 0.88 ? 'colossus' : 'blossom')
        : rf < 0.34
          ? (rChoice < 0.60 ? 'montane' : rChoice < 0.86 ? 'emergent' : 'colossus')
          : (rChoice < 0.46 ? 'montane' : rChoice < 0.72 ? 'broadleaf' : rChoice < 0.90 ? 'emergent' : rChoice < 0.96 ? 'colossus' : 'blossom')
      place(tx, tz, kind, { minEdge: 11, maxSlope: 2.25, packFactor: 0.34 })
    }
  }

  // ── PASS 5: Full-map rainforest canopy blanket
  const candidates = []
  for (let j = 3; j < n - 3; j++) for (let i = 3; i < n - 3; i++) {
    if (arena.edge[j * n + i] >= 7) candidates.push([i, j])
  }
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1))
    ;[candidates[i], candidates[j]] = [candidates[j], candidates[i]]
  }
  const target = Math.round(clamp((arena.size * arena.size) / 1050, 2800, 8200) * amount)
  for (const [i, j] of candidates) {
    if (trees.length >= target) break
    place(ox + (i + rnd()) * C, oz + (j + rnd()) * C, null, { maxSlope: 2.05, packFactor: 0.37 })
  }

  // ── High-craft botanical geometries & sunlit SSS materials
  const trunk = makeOrganicTrunkGeometry()
  const palmTrunk = new THREE.CylinderGeometry(0.48, 1.06, 1, 9, 8).translate(0, 0.5, 0)
  const palmPos = palmTrunk.attributes.position
  for (let i = 0; i < palmPos.count; i++) {
    const y = palmPos.getY(i)
    // Graceful tropical curve + subtle coconut-palm growth rings
    const ring = 1 + 0.045 * Math.sin(y * 38)
    palmPos.setX(i, palmPos.getX(i) * ring + Math.pow(y, 1.85) * 3.5)
    palmPos.setZ(i, palmPos.getZ(i) * ring)
  }
  palmTrunk.computeVertexNormals()
  const bambooCulm = new THREE.CylinderGeometry(0.68, 1, 1, 6, 1).translate(0, 0.5, 0)
  const branch = new THREE.CylinderGeometry(0.45, 1, 1, 8).translate(0, 0.5, 0)
  const log = new THREE.CylinderGeometry(0.84, 1.08, 1, 9).rotateZ(Math.PI / 2)
  const crown = makeVolumetricCrownGeometry(Math.round(arena.opts.seed) * 13 + 7)
  const conifer = makeMontaneBoughGeometry(Math.round(arena.opts.seed) * 19 + 3)
  const frond = makeFeatheryFrondGeometry()
  const ear = makeAlocasiaLeafGeometry()
  const roots = makeCurvedButtressGeometry()
  const vine = makeVineCurtainGeometry()
  const bush = makeLushBushGeometry()
  const shadow = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2)

  const barkTex = makeMossyBarkTexture(Math.round(arena.opts.seed) * 41 + 5, soft)
  const canopyTex = makeBotanicalCanopyTexture(Math.round(arena.opts.seed) * 73 + 19, soft)
  const vineTex = makeVineCurtainTexture(Math.round(arena.opts.seed) * 97 + 11, soft)
  const bushTex = makeUnderstoryTexture(Math.round(arena.opts.seed) * 113 + 31, soft)
  const shadowsTex = shadowTexture()

  const materials = {
    trunk: new THREE.MeshLambertMaterial({ map: barkTex }),
    root: new THREE.MeshLambertMaterial({ map: barkTex, color: '#8f8468' }),
    bamboo: new THREE.MeshLambertMaterial({ color: '#ffffff' }),
    crown: makeSunlitFoliageMaterial({ map: canopyTex, alphaTest: 0.36, vertexColors: true, windAmp: 0.42, sssStrength: 0.58, sharedUniforms }),
    frond: makeSunlitFoliageMaterial({ map: null, vertexColors: true, windAmp: 0.52, sssStrength: 0.65, sharedUniforms }),
    bush: makeSunlitFoliageMaterial({ map: bushTex, alphaTest: 0.34, vertexColors: false, windAmp: 0.34, sssStrength: 0.52, sharedUniforms }),
    vine: makeSunlitFoliageMaterial({ map: vineTex, alphaTest: 0.28, vertexColors: false, windAmp: 0.58, sssStrength: 0.6, sharedUniforms }),
    shadow: new THREE.MeshBasicMaterial({ map: shadowsTex, transparent: true, depthWrite: false, opacity: 0.5 }),
  }

  const geometries = { trunk, palmTrunk, bambooCulm, branch, log, crown, conifer, frond, ear, roots, vine, bush, shadow }
  const types = {
    trunk: ['trunk', 'trunk'],
    palmTrunk: ['palmTrunk', 'trunk'],
    bamboo: ['bambooCulm', 'bamboo'],
    branch: ['branch', 'trunk'],
    log: ['log', 'root'],
    root: ['roots', 'root'],
    crown: ['crown', 'crown'],
    conifer: ['conifer', 'crown'],
    frond: ['frond', 'frond'],
    ear: ['ear', 'frond'],
    bush: ['bush', 'bush'],
    vine: ['vine', 'vine'],
    shadow: ['shadow', 'shadow'],
  }

  const chunkSize = 620
  const chunks = new Map()
  const matrix = new THREE.Matrix4()
  const position = new THREE.Vector3()
  const scale = new THREE.Vector3()
  const quaternion = new THREE.Quaternion()
  const euler = new THREE.Euler()
  const color = new THREE.Color()
  const tmpDir = new THREE.Vector3()

  const getChunk = (x, z) => {
    const cx = Math.floor(x / chunkSize), cz = Math.floor(z / chunkSize)
    const key = `${cx},${cz}`
    let ch = chunks.get(key)
    if (!ch) {
      ch = { x: (cx + 0.5) * chunkSize, z: (cz + 0.5) * chunkSize, lists: new Map() }
      chunks.set(key, ch)
    }
    return ch
  }
  const add = (type, x, y, z, sx, sy, sz, ry, tint, rx = 0, rz = 0) => {
    const chunk = getChunk(x, z)
    let list = chunk.lists.get(type)
    if (!list) { list = []; chunk.lists.set(type, list) }
    euler.set(rx, ry, rz, 'YXZ')
    quaternion.setFromEuler(euler)
    matrix.compose(position.set(x, y, z), quaternion, scale.set(sx, sy, sz))
    list.push({ matrix: matrix.clone(), tint })
  }
  const addBranch = (x, y, z, ex, ey, ez, radius, tint) => {
    tmpDir.set(ex - x, ey - y, ez - z)
    const length = tmpDir.length()
    if (length < 0.2) return
    const chunk = getChunk(x, z)
    let list = chunk.lists.get('branch')
    if (!list) { list = []; chunk.lists.set('branch', list) }
    quaternion.setFromUnitVectors(UP, tmpDir.divideScalar(length))
    matrix.compose(position.set(x, y, z), quaternion, scale.set(radius, length, radius))
    list.push({ matrix: matrix.clone(), tint })
  }

  // ── Assemble every tree with rich organic botanical architecture
  for (const tree of trees) {
    const { x, y, z, height: h, canopy: r, trunk: tr, kind, rotation, tint } = tree
    const nearRoute = sampleEdge(x, z) < 110

    if (kind === 'palm') {
      add('palmTrunk', x, y - 0.6, z, tr, h, tr, rotation, '#c2ad88')
      if (nearRoute) add('shadow', x, y + 0.22, z, r * 2.1, 1, r * 2.1, rotation, '#ffffff')
      const topX = x + Math.cos(rotation) * tr * 3.5
      const topZ = z - Math.sin(rotation) * tr * 3.5
      // Lush 13-frond tropical coconut/queen palm rosette (lower arching ring + upper sunlit fountain ring)
      for (let k = 0; k < 13; k++) {
        const a = rotation + (k / 13) * Math.PI * 2 + (rnd() - 0.5) * 0.2
        const tier = k % 3
        const len = r * (tier === 0 ? 0.72 + rnd() * 0.22 : 0.94 + rnd() * 0.34)
        const pitch = tier === 0 ? 0.38 : tier === 1 ? 0.1 : -0.14
        const leafTint = tier === 0 ? '#5ca844' : tier === 1 ? tint : '#2b6c39'
        add('frond', topX, y + h * 0.985, topZ, len, len, len, a, leafTint, 0, pitch)
      }
      continue
    }

    if (kind === 'montane') {
      add('trunk', x, y - 1.8, z, tr, h * 0.86, tr, rotation, '#8e775c')
      add('conifer', x, y + h * 0.14, z, r, h * 0.9, r, rotation, tint)
      continue
    }

    const barkTint = kind === 'colossus' ? '#aa9c80' : kind === 'banyan' ? '#9e9c84' : '#b5a282'
    add('trunk', x, y - 1.3, z, tr, h * 0.86, tr, rotation, barkTint)
    if (nearRoute) add('shadow', x, y + 0.24, z, r * 2.4, 1, r * 2.4, rotation, '#ffffff')

    // Sinuous sweeping rainforest buttress roots
    if (kind === 'colossus' || kind === 'emergent' || kind === 'banyan') {
      const rootCount = kind === 'colossus' ? 7 : kind === 'emergent' ? 5 : 4
      const rootSpan = kind === 'colossus' ? tr * 3.6 : tr * 2.8
      const rootH = kind === 'colossus' ? h * 0.17 : h * 0.12
      for (let k = 0; k < rootCount; k++) {
        const ang = rotation + (k / rootCount) * Math.PI * 2 + (rnd() - 0.5) * 0.24
        add('root', x, y - 0.5, z, rootSpan * (0.85 + rnd() * 0.35), rootH * (0.85 + rnd() * 0.3), tr * 1.1, ang, '#7f7354')
      }
    }

    if (kind === 'colossus') {
      // MONUMENTAL 90-136 m ANCIENT RAINFOREST EMERGENT GIANT:
      // Lower sub-canopy boughs with epiphytic scarlet bromeliads + soaring 6-lobe volumetric umbrella crown + swaying vine curtains!
      for (let s = 0; s < 3; s++) {
        const sa = rotation + (s / 3) * Math.PI * 2 + 0.55
        const sd = r * (0.48 + rnd() * 0.16)
        const sx = x + Math.cos(sa) * sd, sz = z + Math.sin(sa) * sd
        const sy = y + h * (0.65 + rnd() * 0.06)
        addBranch(x, y + h * 0.52, z, sx, sy, sz, tr * 0.4, barkTint)
        add('crown', sx, sy + r * 0.06, sz, r * 0.48, r * 0.44, r * 0.48, sa, DEEP_CANOPY[Math.floor(rnd() * DEEP_CANOPY.length)])
      }
      // Grand central upper volumetric leaf dome
      add('crown', x, y + h * 0.94, z, r * 0.94, r * 0.78, r * 0.92, rotation, tint)
      const limbs = 5
      for (let k = 0; k < limbs; k++) {
        const ang = rotation + (k / limbs) * Math.PI * 2 + (rnd() - 0.5) * 0.3
        const off = r * (0.58 + rnd() * 0.22)
        const ex = x + Math.cos(ang) * off, ez = z + Math.sin(ang) * off
        const ey = y + h * (0.88 + rnd() * 0.1)
        addBranch(x, y + h * 0.68, z, ex, ey - r * 0.1, ez, tr * 0.44, barkTint)
        add('crown', ex, ey, ez, r * (0.58 + rnd() * 0.16), r * 0.52, r * (0.56 + rnd() * 0.16), ang + 1.2, SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)])

        // Epiphytic bird's-nest ferns & scarlet bromeliad rosettes blooming on the massive mossy boughs!
        if (nearRoute && k < 3) {
          const mx = (x + ex) * 0.5, my = (y + h * 0.68 + ey) * 0.5 + 0.8, mz = (z + ez) * 0.5
          const epiCol = k === 0 ? '#e84c3d' : '#58a642'
          for (let f = 0; f < 5; f++) {
            add('frond', mx, my, mz, 3.8, 3.8, 3.8, ang + (f / 5) * Math.PI * 2, epiCol, 0, 0.32)
          }
          // Swaying leafy liana curtain draping gracefully beneath the giant bough!
          add('vine', ex * 0.8 + x * 0.2, ey - r * 0.08, ez * 0.8 + z * 0.2, 8.5, h * (0.28 + rnd() * 0.18), 8.5, ang, '#4d8c42')
        }
      }
      continue
    }

    // Lush volumetric canopy for emergent, cathedral banyan, broadleaf & golden/coral blossom trees
    add('crown', x, y + h * 0.93, z, r * 0.9, r * 0.78, r * 0.88, rotation, tint)
    const limbs = kind === 'banyan' ? 4 : 3
    for (let k = 0; k < limbs; k++) {
      const ang = rotation + (k / limbs) * Math.PI * 2 + (rnd() - 0.5) * 0.36
      const off = r * ((kind === 'banyan' ? 0.58 : 0.5) + rnd() * 0.18)
      const ex = x + Math.cos(ang) * off, ez = z + Math.sin(ang) * off
      const ey = y + h * (0.87 + rnd() * 0.1)
      addBranch(x, y + h * 0.64, z, ex, ey - r * 0.12, ez, Math.max(0.36, tr * 0.42), barkTint)
      const lobeCol = kind === 'blossom'
        ? tint
        : kind === 'emergent'
          ? SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)]
          : DEEP_CANOPY[Math.floor(rnd() * DEEP_CANOPY.length)]
      add('crown', ex, ey, ez, r * (0.58 + rnd() * 0.15), r * 0.52, r * (0.56 + rnd() * 0.15), ang + 0.9, lobeCol)

      // Cathedral Banyan aerial prop roots + swaying mossy vine curtains
      if (kind === 'banyan' && nearRoute) {
        const px = x + Math.cos(ang) * off * 0.74, pz = z + Math.sin(ang) * off * 0.74
        const gBelow = arena.groundAt(px, pz)
        const topRootY = y + h * 0.78
        if (topRootY > gBelow + 4 && sampleEdge(px, pz) > 5.5) {
          addBranch(px, gBelow - 0.4, pz, px + (rnd() - 0.5) * 1.5, topRootY, pz + (rnd() - 0.5) * 1.5, 0.25 + rnd() * 0.18, '#8b8368')
        }
        if (k < 2) add('vine', ex, ey - r * 0.1, ez, 6.8, h * (0.3 + rnd() * 0.18), 6.8, ang, '#529245')
      }
    }
    if (nearRoute && kind === 'emergent' && rnd() < 0.5) {
      add('vine', x + Math.cos(rotation) * r * 0.45, y + h * 0.85, z + Math.sin(rotation) * r * 0.45, 7.2, h * 0.32, 7.2, rotation, '#4a8840')
    }
  }

  // ── Assemble Giant Emerald Bamboo Groves & Prehistoric Cyathea Tree Ferns
  for (const bm of bambooClumps) {
    const culms = 6 + Math.floor(rnd() * 3)
    for (let c = 0; c < culms; c++) {
      const a = bm.rot + (c / culms) * Math.PI * 2 + rnd() * 0.3
      const dist = 0.7 + rnd() * 2.0
      const cx = bm.x + Math.cos(a) * dist, cz = bm.z + Math.sin(a) * dist
      const ch = bm.h * (0.8 + rnd() * 0.32)
      add('bamboo', cx, bm.y - 0.3, cz, 0.24, ch, 0.24, a, c % 3 === 0 ? '#7fb046' : '#528d3b', 0.07 + rnd() * 0.1, 0)
      if (c % 2 === 0) add('crown', cx, bm.y + ch * 0.92, cz, 4.8, 3.8, 4.8, a, '#5da844')
    }
  }
  for (const tf of treeFerns) {
    add('palmTrunk', tf.x, tf.y - 0.3, tf.z, 0.34, tf.h, 0.34, tf.rot, '#5a4632')
    const topX = tf.x + Math.cos(tf.rot) * 0.34 * 3.5
    const topZ = tf.z - Math.sin(tf.rot) * 0.34 * 3.5
    for (let k = 0; k < 10; k++) {
      const a = tf.rot + (k / 10) * Math.PI * 2
      const fl = 4.8 + rnd() * 2.8
      add('frond', topX, tf.y + tf.h * 0.98, topZ, fl, fl, fl, a, k % 2 ? '#54a644' : '#38883c', 0, 0.12)
    }
  }

  // ── Multi-layered Lush Tropical Understory: giant sword ferns, glossy Alocasia elephant ears,
  //    vibrant scarlet/gold Heliconia blooms & moss-draped fallen nurse logs!
  let understory = 0
  const understoryTarget = Math.round(Math.min(2600, 1850 * amount))
  for (let tries = 0; tries < understoryTarget * 22 && understory < understoryTarget; tries++) {
    const [i, j] = candidates[Math.floor(rnd() * candidates.length)] || [0, 0]
    const edge = arena.edge[j * n + i]
    if (edge < 2.5 || edge > 95) continue
    const x = ox + (i + rnd()) * C, z = oz + (j + rnd()) * C
    const rv = riverAt(x, z)
    if (rv > 0.42) continue
    const y = arena.groundAt(x, z) + 0.18
    const len = 4.2 + rnd() * 4.8
    const start = rnd() * Math.PI * 2
    if (rv > 0.05 || rnd() < 0.38) {
      for (let k = 0; k < 5; k++) {
        const a = start + (k / 5) * Math.PI * 2 + (rnd() - 0.5) * 0.25
        add('ear', x, y, z, len * 0.95, len * 0.95, len * 0.95, a, DEEP_CANOPY[Math.floor(rnd() * DEEP_CANOPY.length)])
      }
    } else {
      for (let k = 0; k < 6; k++) {
        const a = start + (k / 6) * Math.PI * 2
        add('frond', x, y, z, len, len, len, a, SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)], 0, 0.04)
      }
    }
    if (rnd() < 0.65) add('bush', x, y - 0.1, z, len * 1.15, len * 1.05, len * 1.15, start, '#3e8c3f')
    understory++
  }

  // Rich tropical border foliage + scarlet/gold Heliconia spikes + fallen mossy hollow giant logs!
  for (const path of arena.paths) {
    for (let i = 3; i < path.pts.length - 3; i += 4) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / length, rz = (b[0] - a[0]) / length
      for (const side of [-1, 1]) {
        const offset = path.halfW + 1 + rnd() * 13
        const x = q[0] + rx * offset * side, z = q[1] + rz * offset * side
        if (sampleEdge(x, z) < -3 || riverAt(x, z) > 0.4) continue
        const y = arena.groundAt(x, z) + 0.14
        const size = 4.6 + rnd() * 4.4
        const angle = rnd() * Math.PI * 2
        add('bush', x, y, z, size, size * 0.95, size, angle, rnd() < 0.14 ? '#f26444' : '#449240')
        for (let k = 0; k < 4; k++) {
          const a0 = angle + (k / 4) * Math.PI * 2
          add(k % 2 === 0 ? 'ear' : 'frond', x, y + 0.08, z, size * 0.85, size * 0.85, size * 0.85, a0, DEEP_CANOPY[Math.floor(rnd() * DEEP_CANOPY.length)])
        }
        if (i % 16 === 3 && rnd() < 0.55) {
          const lx = q[0] + rx * (path.halfW + 11 + rnd() * 8) * side
          const lz = q[1] + rz * (path.halfW + 11 + rnd() * 8) * side
          if (sampleEdge(lx, lz) > 8 && riverAt(lx, lz) < 0.3) {
            const ly = arena.groundAt(lx, lz) + 0.9
            const logLen = 14 + rnd() * 12, logR = 1.2 + rnd() * 0.75
            const logAng = Math.atan2(b[1] - a[1], b[0] - a[0]) + (rnd() - 0.5) * 0.85
            add('log', lx, ly, lz, logLen, logR, logR, logAng, '#5f7848')
            for (let f = 0; f < 3; f++) {
              add('frond', lx, ly + logR * 0.82, lz, 3.8, 3.8, 3.8, logAng + f * 2.1, f === 0 ? '#ff6f42' : '#52a444', 0, 0.22)
            }
          }
        }
        understory++
      }
    }
  }

  // ── Living Mossy Overhead Canopy Cathedral Arches draped in swaying vine curtains & golden blossoms!
  let canopyBridges = 0
  for (const path of arena.paths.slice(0, arena.n)) {
    for (let i = 9; i < path.pts.length - 9; i += 10) {
      const a = path.pts[i - 1], b = path.pts[i + 1], q = path.pts[i]
      const length = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
      const rx = -(b[1] - a[1]) / length, rz = (b[0] - a[0]) / length
      const side = i % 2 === 0 ? -1 : 1
      const proposedX = q[0] + rx * side * (path.halfW + 12)
      const proposedZ = q[1] + rz * side * (path.halfW + 12)
      let nearest = null
      let nearestDistance = 78
      for (const tree of trees) {
        if (tree.kind === 'palm' || tree.kind === 'montane' || tree.height < 42) continue
        const d = Math.hypot(tree.x - proposedX, tree.z - proposedZ)
        if (d < nearestDistance) { nearest = tree; nearestDistance = d }
      }
      if (!nearest) continue
      const x0 = nearest.x, z0 = nearest.z
      const ground = arena.groundAt(q[0], q[1])
      const y0 = Math.max(ground + 29, nearest.y + nearest.height * 0.66)
      const x1 = q[0] - rx * side * (path.halfW * 0.24)
      const z1 = q[1] - rz * side * (path.halfW * 0.24)
      const y1 = y0 + 7 + rnd() * 5
      addBranch(x0, y0, z0, x1, y1, z1, nearest.kind === 'colossus' ? 2.1 : 1.5, '#928766')
      add('shadow', q[0], ground + 0.24, q[1], 44, 1, 30, rnd() * Math.PI, '#ffffff')
      // Lush volumetric overhead leaf clouds + swaying curtain vines hanging safely above racers
      for (let k = 0; k < 3; k++) {
        const u = 0.34 + k * 0.32
        const px = x0 + (x1 - x0) * u, pz = z0 + (z1 - z0) * u, py = y0 + (y1 - y0) * u + 3.2
        const colB = k === 1 && canopyBridges % 4 === 0
          ? TROPICAL_BLOSSOMS[canopyBridges % TROPICAL_BLOSSOMS.length]
          : SUNLIT_EMERGENT[Math.floor(rnd() * SUNLIT_EMERGENT.length)]
        add('crown', px, py, pz, 12.5, 9.5, 12.5, rnd() * 6.28, colB)
        const vLen = Math.min(13, py - ground - 18)
        if (vLen > 4) add('vine', px, py - 2.5, pz, 7.5, vLen, 7.5, rnd() * 6.28, '#559646')
      }
      canopyBridges++
    }
  }

  // ── Assemble spatially chunked InstancedMeshes
  const visibleChunks = []
  for (const chunk of chunks.values()) {
    const chunkGroup = new THREE.Group()
    for (const [type, list] of chunk.lists) {
      const [geometryName, materialName] = types[type]
      const mesh = new THREE.InstancedMesh(geometries[geometryName], materials[materialName], list.length)
      list.forEach((item, i) => {
        mesh.setMatrixAt(i, item.matrix)
        mesh.setColorAt(i, color.set(item.tint))
      })
      mesh.instanceMatrix.needsUpdate = true
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
      mesh.computeBoundingSphere()
      mesh.userData.detailDistance = ['trunk', 'palmTrunk', 'crown', 'conifer'].includes(type)
        ? Infinity
        : ['branch', 'frond', 'bamboo'].includes(type)
          ? 1050
          : ['root', 'vine', 'log'].includes(type)
            ? 880
            : 760
      chunkGroup.add(mesh)
    }
    group.add(chunkGroup)
    visibleChunks.push({ group: chunkGroup, x: chunk.x, z: chunk.z })
  }

  return {
    group,
    info: {
      treeCount: trees.length,
      species: treesBySpecies,
      maxHeight: trees.reduce((max, tree) => Math.max(max, tree.height), 0),
      bambooGroves: bambooClumps.length,
      treeFerns: treeFerns.length,
      understory,
      canopyBridges,
      chunks: visibleChunks.length,
    },
    update(time, camera) {
      sharedUniforms.uTime.value = time
      const elevatedBoost = camera.y > 140 ? 1800 : 0
      const limit = 2000 + chunkSize + elevatedBoost
      for (const chunk of visibleChunks) {
        const dx = chunk.x - camera.x, dz = chunk.z - camera.z
        const distSq = dx * dx + dz * dz
        chunk.group.visible = distSq < limit * limit
        if (chunk.group.visible) {
          for (const mesh of chunk.group.children) {
            const d = mesh.userData.detailDistance + elevatedBoost * 0.45
            mesh.visible = distSq < d * d
          }
        }
      }
    },
    dispose() {
      Object.values(geometries).forEach((g) => g.dispose())
      Object.values(materials).forEach((m) => m.dispose())
      barkTex.dispose()
      canopyTex.dispose()
      vineTex.dispose()
      bushTex.dispose()
      shadowsTex.dispose()
    },
  }
}
