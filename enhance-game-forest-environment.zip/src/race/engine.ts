// @ts-nocheck
// Ties everything together: renderer, camera, craft meshes, particles, input, audio.
import * as THREE from 'three'
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js'
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js'
import { buildTrack, newFrame } from './track'
import { Sim } from './sim'
import { buildWorld, THEMES } from './world'
import { makeShip, disposeShip, LIVERIES, cockpitPalette } from './ships'
import { isBike } from './vehicles'
import { buildCockpit, drawCockpit } from './cockpit'
import { buildArena, ArenaSim } from './arena'
import { buildArenaWorld } from './arenaWorld'
import { audio } from './audio'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))

const TRACK_KEYS = ['trackSeed', 'trackRadius', 'trackWidth', 'hills', 'pads']
const ARENA_KEYS = ['arenaSeed', 'arenaSize', 'arenaGates', 'arenaWidth', 'shortcuts', 'hazards', 'pads', 'arenaPlanet', 'forestRelief']
function arenaOpts(s) {
  return { seed: s.arenaSeed, radius: s.arenaSize, gates: s.arenaGates, width: s.arenaWidth, shortcuts: s.shortcuts, hazards: s.hazards, pads: s.pads, planet: s.arenaPlanet, forestRelief: s.forestRelief }
}

function trackOpts(s) {
  return { seed: s.trackSeed, radius: s.trackRadius, width: s.trackWidth, hills: s.hills, pads: s.pads }
}
function raceParams(s) {
  return {
    laps: s.laps, bots: s.bots, botSkill: s.botSkill, rubber: s.rubber, shipClass: s.shipClass, assist: s.assist,
    steerGain: s.steerGain, accelGain: s.accelGain, wallDmg: s.wallDmg, shieldMax: s.shieldMax,
    turboDrain: s.turboDrain, turboRegen: s.turboRegen, padPower: s.padPower, airbrake: s.airbrake, autoGas: s.autoGas,
    skin: s.skin, botSkins: s.botSkins,
  }
}

export function createEngine(container, initial) {
  let settings = { ...initial }
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
  renderer.outputColorSpace = THREE.SRGBColorSpace
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  renderer.toneMappingExposure = 1.05
  renderer.domElement.style.display = 'block'
  renderer.domElement.style.width = '100%'
  renderer.domElement.style.height = '100%'
  container.appendChild(renderer.domElement)

  // the cockpit is painted on its own low-resolution canvas over the 3D view (hard pixels, like the jet game)
  const cockCv = document.createElement('canvas')
  cockCv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none;display:none;image-rendering:pixelated'
  container.appendChild(cockCv)
  const cockCtx = cockCv.getContext('2d')
  let cockArt = null
  let cockKey = ''
  let cockFb = null
  let cockImg = null
  let cockIn = 0
  let headX = 0, headY = 0, headVX = 0, headVY = 0
  const PIVOT = 0.44 // where the reticle sits, as a fraction of the frame height

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(78, 1, 0.3, 9000)
  const hemi = new THREE.HemisphereLight('#ffffff', '#223', 0.6)
  const sun = new THREE.DirectionalLight('#ffffff', 1)
  sun.position.set(0.4, 1, 0.3)
  scene.add(hemi, sun)

  let composer = null
  let bloom = null
  const makeComposer = () => {
    const w = container.clientWidth || 800
    const h = container.clientHeight || 600
    if (composer) composer.dispose()
    const rt = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: settings.look === 'soft' ? 4 : 0 })
    composer = new EffectComposer(renderer, rt)
    composer.addPass(new RenderPass(scene, camera))
    bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.28, 0.42, 0.85)
    composer.addPass(bloom)
    composer.addPass(new OutputPass())
  }
  makeComposer()

  // ── world
  let mode = settings.mode === 'arena' ? 'arena' : 'track'
  let track = buildTrack(trackOpts(settings))
  let world = null
  const trackSim = new Sim(track, raceParams(settings))
  let arena = null
  let arenaSim = null
  if (mode === 'arena') {
    arena = buildArena(arenaOpts(settings))
    arenaSim = new ArenaSim(arena, raceParams(settings))
  }
  let sim = mode === 'arena' ? arenaSim : trackSim
  let paused = false
  const shipMeshes = []
  const frame = newFrame()
  const frame2 = newFrame()

  const setTheme = () => {
    const th = THEMES[settings.theme] || THEMES.night
    const fogC = world && world.fog ? world.fog.color : th.fog
    const fogD = world && world.fog ? world.fog.density : th.fogDensity
    scene.fog = new THREE.FogExp2(fogC, fogD)
    scene.background = new THREE.Color(fogC)
    if (world && world.sunDir) sun.position.copy(world.sunDir).multiplyScalar(100)
    hemi.color.set(th.skyMid)
    hemi.groundColor.set(th.gridB)
    const aPlanet = mode === 'arena' ? arena?.opts.planet : null
    const isForest = aPlanet === 'forest'
    if (isForest) {
      hemi.color.set(settings.theme === 'night' ? '#6ca8c2' : settings.theme === 'sunset' ? '#ffd0a0' : '#bcefe0')
      hemi.groundColor.set(settings.theme === 'night' ? '#144236' : settings.theme === 'sunset' ? '#6b5230' : '#2f6c35')
    } else if (aPlanet === 'desert') {
      hemi.color.set(settings.theme === 'night' ? '#6d88cc' : settings.theme === 'sunset' ? '#ffb878' : '#ffe8c8')
      hemi.groundColor.set(settings.theme === 'night' ? '#2c1e28' : '#b85c34')
    } else if (aPlanet === 'ice') {
      hemi.color.set(settings.theme === 'night' ? '#64b8ff' : settings.theme === 'sunset' ? '#f5c2e8' : '#d8f4ff')
      hemi.groundColor.set(settings.theme === 'night' ? '#143868' : '#4a8ec8')
    } else if (aPlanet === 'lava') {
      hemi.color.set(settings.theme === 'night' ? '#9e4c3c' : '#e88254')
      hemi.groundColor.set('#d84414')
    }
    hemi.intensity = th.ambient * 2.65
    sun.color.set(
      isForest && settings.theme === 'day'
        ? '#fff4dc'
        : aPlanet === 'desert' && settings.theme === 'day'
          ? '#ffebd0'
          : aPlanet === 'lava'
            ? '#ffc088'
            : th.dirColor,
    )
    sun.intensity = th.dir * (aPlanet ? 2.58 : 2.4)
    renderer.toneMappingExposure = aPlanet && settings.theme === 'day' ? 1.06 : th.exposure
    if (bloom) {
      bloom.strength = isForest ? (settings.theme === 'night' ? 0.36 : 0.22) : aPlanet === 'lava' ? 0.42 : th.bloom * 0.42
      bloom.enabled = !!settings.bloom
    }
  }
  const buildAll = () => {
    if (world) {
      scene.remove(world.group)
      world.dispose()
    }
    const soft = settings.look === 'soft'
    world = mode === 'arena'
      ? buildArenaWorld(arena, settings.theme, { soft, forestDensity: settings.forestDensity, showGuides: settings.showGuides !== false })
      : buildWorld(track, settings.theme, { islands: settings.islands, worldSeed: settings.worldSeed, clouds: settings.clouds, soft })
    scene.add(world.group)
    setTheme()
    if (paused) world.update(0, camera.position, sim)
  }
  buildAll()

  const syncShips = () => {
    while (shipMeshes.length) {
      const m = shipMeshes.pop()
      scene.remove(m.root)
      disposeShip(m)
    }
    for (const sh of sim.ships) {
      const m = makeShip(sh.color, sh.skin)
      m.root.matrixAutoUpdate = false
      m.model.matrixAutoUpdate = true
      scene.add(m.root)
      shipMeshes.push(m)
    }
  }
  syncShips()

  // ── sparks and debris
  const PN = 600
  const pPos = new Float32Array(PN * 3)
  const pCol = new Float32Array(PN * 3)
  const pVel = new Float32Array(PN * 3)
  const pLife = new Float32Array(PN)
  const pMax = new Float32Array(PN)
  const pBase = new Float32Array(PN * 3)
  let pHead = 0
  const pGeo = new THREE.BufferGeometry()
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3))
  pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3))
  const pts = new THREE.Points(
    pGeo,
    new THREE.PointsMaterial({ size: 0.55, vertexColors: true, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, sizeAttenuation: true }),
  )
  pts.frustumCulled = false
  scene.add(pts)
  const spark = (x, y, z, vx, vy, vz, life, r, g, b) => {
    const i = pHead
    pHead = (pHead + 1) % PN
    pPos[i * 3] = x; pPos[i * 3 + 1] = y; pPos[i * 3 + 2] = z
    pVel[i * 3] = vx; pVel[i * 3 + 1] = vy; pVel[i * 3 + 2] = vz
    pLife[i] = life; pMax[i] = life
    pBase[i * 3] = r; pBase[i * 3 + 1] = g; pBase[i * 3 + 2] = b
  }
  const stepParticles = (dt) => {
    for (let i = 0; i < PN; i++) {
      if (pLife[i] <= 0) { pCol[i * 3] = pCol[i * 3 + 1] = pCol[i * 3 + 2] = 0; continue }
      pLife[i] -= dt
      pVel[i * 3 + 1] -= 18 * dt
      pPos[i * 3] += pVel[i * 3] * dt
      pPos[i * 3 + 1] += pVel[i * 3 + 1] * dt
      pPos[i * 3 + 2] += pVel[i * 3 + 2] * dt
      const k = clamp(pLife[i] / pMax[i], 0, 1)
      pCol[i * 3] = pBase[i * 3] * k
      pCol[i * 3 + 1] = pBase[i * 3 + 1] * k
      pCol[i * 3 + 2] = pBase[i * 3 + 2] * k
    }
    pGeo.attributes.position.needsUpdate = true
    pGeo.attributes.color.needsUpdate = true
  }

  // ── input + N-key 3D Flight Mode
  const keys = new Set()
  const touch = { left: false, right: false, gas: false, brake: false, turbo: false, climb: false, dive: false }
  let flightMode = false
  let nClimbHold = false
  let steerSmooth = 0
  const input = { throttle: 0, brake: 0, steer: 0, abL: 0, abR: 0, turbo: false, fly: false, climb: 0 }
  let garagePreview = false
  let forestTour = null
  let tourTime = 0
  let landCamDip = 0
  let camMode = settings.camMode || 'chase'

  const toggleFlight = () => {
    if (sim.state !== 'racing' || sim.player.wreckT > 0 || sim.player.finished) return
    flightMode = !flightMode
    if (!flightMode) nClimbHold = false
  }

  const onKeyDown = (e) => {
    if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault()
    if (e.repeat) return
    keys.add(e.code)
    if (e.code === 'KeyN') {
      // Press N while on ground -> launches into 3D Flight Mode (holding N keeps climbing higher, releasing stays flying!).
      // Press N while already flying -> smoothly disengages flight and executes a cushioned hover landing!
      if (sim.state === 'racing' && sim.player.wreckT <= 0 && !sim.player.finished) {
        if (!flightMode) {
          flightMode = true
          nClimbHold = true
        } else {
          flightMode = false
          nClimbHold = false
        }
      }
    }
    if (e.code === 'KeyC') {
      camMode = camMode === 'chase' ? 'near' : camMode === 'near' ? 'cockpit' : 'chase'
      api.onCamera?.(camMode)
    }
    if (e.code === 'KeyR' && sim.state === 'racing') resetPlayer()
  }
  const onKeyUp = (e) => {
    keys.delete(e.code)
    if (e.code === 'KeyN') nClimbHold = false
  }
  const onBlur = () => {
    keys.clear()
    nClimbHold = false
  }
  window.addEventListener('keydown', onKeyDown)
  window.addEventListener('keyup', onKeyUp)
  window.addEventListener('blur', onBlur)

  const readInput = (dt) => {
    if (sim.state !== 'racing' || sim.player.wreckT > 0 || sim.player.finished) {
      flightMode = false
      nClimbHold = false
    }
    const k = (c) => keys.has(c)
    let steerT = (k('KeyD') || k('ArrowRight') || touch.right ? 1 : 0) - (k('KeyA') || k('ArrowLeft') || touch.left ? 1 : 0)
    let thr = k('KeyW') || k('ArrowUp') || touch.gas ? 1 : 0
    let brk = k('KeyS') || k('ArrowDown') || touch.brake ? 1 : 0
    let abL = !flightMode && k('KeyQ') ? 1 : 0
    let abR = !flightMode && k('KeyE') ? 1 : 0
    let turbo = k('ShiftLeft') || k('ShiftRight') || (!flightMode && k('Space')) || touch.turbo
    // In Flight Mode: Space / E / held-initial-N climbs up; Q / Ctrl dives down!
    let climb = 0
    if (flightMode) {
      const upCmd = k('Space') || k('KeyE') || nClimbHold || touch.climb ? 1 : 0
      const dnCmd = k('KeyQ') || k('ControlLeft') || k('ControlRight') || touch.dive ? 1 : 0
      climb = upCmd - dnCmd
    }
    // gamepad
    const pads = navigator.getGamepads ? navigator.getGamepads() : []
    const gp = pads && Array.from(pads).find((g) => g && g.connected)
    if (gp) {
      const ax = gp.axes[0] || 0
      const ay = gp.axes[1] || 0
      if (Math.abs(ax) > 0.12) steerT = ax
      if (flightMode && Math.abs(ay) > 0.16) climb = clamp(climb - ay, -1, 1)
      const rt = gp.buttons[7]?.value || 0
      const lt = gp.buttons[6]?.value || 0
      if (rt > 0.05) thr = rt
      if (lt > 0.05) brk = lt
      if (gp.buttons[0]?.pressed || gp.buttons[2]?.pressed) turbo = true
      if (gp.buttons[4]?.pressed) { if (flightMode) climb = -1; else abL = 1 }
      if (gp.buttons[5]?.pressed) { if (flightMode) climb = 1; else abR = 1 }
    }
    const rate = steerT === 0 ? 18 : 14
    steerSmooth += (steerT - steerSmooth) * (1 - Math.exp(-dt * rate))
    input.steer = clamp(steerSmooth, -1, 1)
    input.throttle = thr
    input.brake = brk
    input.abL = abL
    input.abR = abR
    input.turbo = !!turbo
    input.fly = flightMode
    input.climb = climb
    return input
  }

  const resetPlayer = () => {
    flightMode = false
    nClimbHold = false
    const p = sim.player
    if (mode === 'arena') { sim.resetPlayer(); return }
    if (p.wreckT > 0 || p.finished) return
    p.x = 0
    p.vx = 0
    p.flyH = 0
    p.flyVy = 0
    p.flying = false
    p.v *= 0.55
    p.invuln = 1.5
  }

  // ── camera
  let camX = 0
  let camH = 2.6
  let camUp = new THREE.Vector3(0, 1, 0)
  let fov = 78
  let shake = 0
  const tmpV = new THREE.Vector3()
  const tmpV2 = new THREE.Vector3()
  const tmpU = new THREE.Vector3()
  const camPos = new THREE.Vector3()

  let camYaw = 0
  const arenaFwd = new THREE.Vector3()
  const updateCameraArena = (dt, target, state, ratio, boost) => {
    const A = arena
    const bike = isBike(target.skin)
    const wrapAng = (a) => Math.atan2(Math.sin(a), Math.cos(a))
    const demoOff = state === 'demo' ? 0.55 + Math.sin(clock * 0.22) * 0.25 : 0
    camYaw += wrapAng(target.yaw + demoOff - camYaw) * (1 - Math.exp(-dt * (camMode === 'cockpit' ? 16 : 7.5)))
    if (state === 'demo') {
      const aspect = container.clientWidth / Math.max(1, container.clientHeight)
      const framing = garagePreview ? clamp(0.9 / aspect, 1, 2.5) : 1
      const back = (bike ? 12 : 15) * framing
      camPos.set(target.x - Math.sin(camYaw) * back, target.y + 4.5 * framing, target.z + Math.cos(camYaw) * back)
      camera.position.copy(camPos)
      camera.up.set(0, 1, 0)
      camera.lookAt(target.x, target.y + (bike ? 1.05 : 0.45), target.z)
    } else if (camMode === 'cockpit') {
      const cp = Math.cos(target.pitch), sp = Math.sin(target.pitch)
      camPos.set(target.x, target.y + (bike ? 2.1 : 1.5), target.z)
      camera.position.copy(camPos)
      const rollA = clamp(target.steerNow * 0.28, -0.4, 0.4)
      camera.up.set(Math.sin(rollA) * Math.cos(target.yaw), Math.cos(rollA), Math.sin(rollA) * Math.sin(target.yaw))
      camera.lookAt(camPos.x + Math.sin(target.yaw) * cp * 30, camPos.y + sp * 30, camPos.z - Math.cos(target.yaw) * cp * 30)
    } else {
      landCamDip = Math.max(0, landCamDip - dt * 3.4)
      const flyExtra = target.flying ? 2.6 : 0
      const back = camMode === 'near' ? (bike ? 8 : 6) + flyExtra * 0.5 : (bike ? 11.8 : 10) + ratio * 4.4 + boost * 2 + flyExtra
      const h = (camMode === 'near' ? 1.9 : 3.65 - boost * 0.35) + (target.flying ? 0.9 - target.pitch * 2.4 : 0) - landCamDip * 0.75
      camPos.set(target.x - Math.sin(camYaw) * back, target.y + h, target.z + Math.cos(camYaw) * back)
      const gc = A.groundAt(camPos.x, camPos.z)
      if (camPos.y < gc + 3) camPos.y = gc + 3
      camera.position.copy(camPos)
      const leanCap = target.flying ? 0.22 : 0.13
      const lean = clamp(target.steerNow * (target.flying ? 0.14 : 0.08) + clamp(target.vlat / 90, -1, 1) * 0.05, -leanCap, leanCap)
      camera.up.set(Math.cos(camYaw) * Math.sin(lean), Math.cos(lean), Math.sin(camYaw) * Math.sin(lean))
      camera.lookAt(target.x + Math.sin(camYaw) * 20, target.y + 1.6 + target.pitch * 16 - landCamDip * 0.4, target.z - Math.cos(camYaw) * 20)
    }
    if (shake > 0.02) {
      camera.position.x += (Math.random() - 0.5) * shake * 0.35
      camera.position.y += (Math.random() - 0.5) * shake * 0.35
      camera.position.z += (Math.random() - 0.5) * shake * 0.35
    }
    camera.updateMatrixWorld()
    void arenaFwd
  }

  const updateCamera = (dt) => {
    const state = sim.state
    const target = sim.player
    const top = sim.topFor(target)
    const m = shipMeshes[target.id]
    const boost = target.boostT > 0 || target.turboOn ? 1 : 0
    const ratio = clamp(target.v / top, 0, 1.4)
    const targetFov = state === 'demo' ? (garagePreview ? 42 : 58) : (camMode === 'cockpit' ? settings.fov - 18 : settings.fov) + 24 * Math.pow(ratio, 1.5) + boost * 12
    fov += (targetFov - fov) * (1 - Math.exp(-dt * 4))
    if (Math.abs(camera.fov - fov) > 0.01) {
      camera.fov = fov
      camera.updateProjectionMatrix()
    }
    shake += (((boost ? 0.5 : 0) + target.scrape * 0.9 + (target.v > top * 1.05 ? 0.2 : 0)) * ratio - shake) * (1 - Math.exp(-dt * 8))
    if (mode === 'arena') {
      updateCameraArena(dt, target, state, ratio, boost)
      return
    }
    if (state === 'demo') {
      track.frame(target.s, frame)
      const angle = target.yaw + 0.55 + Math.sin(clock * 0.22) * 0.25
      const cs = Math.cos(angle), sn = Math.sin(angle)
      const fx = frame.tx * cs + frame.rx * sn
      const fy = frame.ty * cs + frame.ry * sn
      const fz = frame.tz * cs + frame.rz * sn
      const x = frame.px + frame.rx * target.x
      const y = frame.py + frame.ry * target.x
      const z = frame.pz + frame.rz * target.x
      const aspect = container.clientWidth / Math.max(1, container.clientHeight)
      const framing = garagePreview ? clamp(0.9 / aspect, 1, 2.5) : 1
      const back = (isBike(target.skin) ? 12 : 15) * framing
      camera.position.set(x - fx * back + frame.ux * 5.8 * framing, y - fy * back + frame.uy * 5.8 * framing, z - fz * back + frame.uz * 5.8 * framing)
      camera.up.set(frame.ux, frame.uy, frame.uz)
      camera.lookAt(x + frame.ux * 2.2, y + frame.uy * 2.2, z + frame.uz * 2.2)
      camera.updateMatrixWorld()
      return
    }
    if (camMode === 'cockpit' && state !== 'demo') {
      if (m) m.root.visible = false
      // from inside the nose
      m && m.model.updateMatrixWorld(true)
      const tr = target
      track.frame(tr.s, frame)
      const hover = 1.4 + (tr.flyH || 0)
      const eyeHeight = isBike(tr.skin) ? 2.1 : 0.8
      camPos.set(frame.px + frame.rx * tr.x + frame.ux * (hover + eyeHeight), frame.py + frame.ry * tr.x + frame.uy * (hover + eyeHeight), frame.pz + frame.rz * tr.x + frame.uz * (hover + eyeHeight))
      const cy = Math.cos(tr.yaw), sy = Math.sin(tr.yaw)
      tmpV.set(frame.tx * cy + frame.rx * sy, frame.ty * cy + frame.ry * sy + Math.sin(tr.pitch || 0) * 0.6, frame.tz * cy + frame.rz * sy)
      camera.position.copy(camPos)
      camera.up.set(frame.ux, frame.uy, frame.uz)
      camera.lookAt(camPos.x + tmpV.x * 30, camPos.y + tmpV.y * 30, camPos.z + tmpV.z * 30)
    } else {
      landCamDip = Math.max(0, landCamDip - dt * 3.4)
      const flyH = target.flyH || 0
      const back = camMode === 'near' ? (isBike(target.skin) ? 7.5 : 5.2) : (isBike(target.skin) ? 10 : 8.5) + ratio * 3 + boost * 1.5 + (target.flying ? 2.4 : 0)
      const h = (camMode === 'near' ? 1.45 : 2.8 - boost * 0.3) + flyH + (target.flying ? 1.2 : 0) - landCamDip * 0.7
      const orbit = state === 'demo' ? Math.sin(sim.time * 0.25) * 16 : 0
      const hDemo = state === 'demo' ? 3 + Math.sin(sim.time * 0.17) * 2.5 : 0
      camX += (target.x * 0.8 + orbit - camX) * (1 - Math.exp(-dt * 5))
      camH += (h + hDemo - camH) * (1 - Math.exp(-dt * 7))
      track.frame(target.s - back, frame)
      track.frame(target.s + 16 + ratio * 14, frame2)
      camPos.set(
        frame.px + frame.rx * camX + frame.ux * camH,
        frame.py + frame.ry * camX + frame.uy * camH,
        frame.pz + frame.rz * camX + frame.uz * camH,
      )
      tmpU.set(frame.ux, frame.uy, frame.uz)
      camUp.lerp(tmpU, 1 - Math.exp(-dt * 3.5))
      camera.position.copy(camPos)
      camera.up.copy(tmpV2.set(0, 1, 0).lerp(camUp, 0.7).normalize())
      const lookAlt = 1.4 + flyH + (target.pitch || 0) * 10
      camera.lookAt(
        frame2.px + frame2.rx * target.x * 0.9 + frame2.ux * lookAlt,
        frame2.py + frame2.ry * target.x * 0.9 + frame2.uy * lookAlt,
        frame2.pz + frame2.rz * target.x * 0.9 + frame2.uz * lookAlt,
      )
    }
    if (shake > 0.02) {
      camera.position.x += (Math.random() - 0.5) * shake * 0.35
      camera.position.y += (Math.random() - 0.5) * shake * 0.35
      camera.position.z += (Math.random() - 0.5) * shake * 0.35
    }
    camera.updateMatrixWorld()
  }

  // ── meshes follow the simulation
  const bx = new THREE.Vector3(), by = new THREE.Vector3(), bz = new THREE.Vector3()
  const mat = new THREE.Matrix4()
  const updateShipsArena = (dt, time) => {
    for (const sh of sim.ships) {
      const m = shipMeshes[sh.id]
      if (!m) continue
      const top = sim.topFor(sh)
      if (garagePreview && sim.state === 'demo' && !sh.isPlayer) { m.root.visible = false; continue }
      const wrecked = sh.wreckT > 0
      if (!(camMode === 'cockpit' && sh.isPlayer && sim.state !== 'demo')) m.root.visible = !wrecked && !(sh.invuln > 0 && sh.invuln < 2.4 && Math.floor(time * 12) % 2 === 0 && sh.isPlayer && sim.state === 'racing')
      else m.root.visible = false
      const cyw = Math.cos(sh.yaw), syw = Math.sin(sh.yaw)
      const cp = Math.cos(sh.pitch), sp = Math.sin(sh.pitch)
      // forward, then right and up from it
      const fx = syw * cp, fy = sp, fz = -cyw * cp
      const rx = cyw, ry = 0, rz = syw
      const ux = ry * fz - rz * fy
      const uy = rz * fx - rx * fz
      const uz = rx * fy - ry * fx
      // Dynamic banking roll: sleek MotoGP carve on ground, dramatic swept bank when flying in N mode!
      const roll = clamp(sh.steerNow * (sh.flying ? 0.68 : 0.54) + sh.vlat * 0.011, -0.92, 0.92)
      const cr = Math.cos(roll), sr = Math.sin(roll)
      bx.set(rx * cr - ux * sr, ry * cr - uy * sr, rz * cr - uz * sr)
      by.set(ux * cr + rx * sr, uy * cr + ry * sr, uz * cr + rz * sr)
      bz.set(-fx, -fy, -fz)
      mat.makeBasis(bx, by, bz)
      mat.setPosition(sh.x, sh.y + Math.sin(time * 3 + sh.id * 1.7) * 0.08, sh.z)
      m.root.matrix.copy(mat)
      m.root.matrixWorldNeedsUpdate = true
      const boost = sh.boostT > 0 || sh.turboOn ? 1 : 0
      m.animate?.({
        steer: sh.steerNow,
        drift: sh.drifting ? clamp(sh.driftT / 0.8, 0.25, 1) : 0,
        throttle: sh.throttle,
        boost,
        speedRatio: sh.v / Math.max(1, top),
        pitch: sh.pitch || 0,
        vy: sh.vy || 0,
        airborne: !!sh.airborne,
        flying: !!sh.flying,
        climb: sh.climbNow || 0,
        landImpact: sh.landImpact || 0,
        time,
      }, dt)
      const flyFlame = sh.flying ? 1.8 : 0
      const len = 0.9 + sh.throttle * 2.6 * (0.4 + sh.v / top) + boost * 6.5 + flyFlame
      for (const t of m.trails) {
        t.scale.set(1 + boost * 0.35 + (sh.flying ? 0.2 : 0), 1 + boost * 0.35 + (sh.flying ? 0.2 : 0), len * (0.85 + Math.random() * 0.3))
        t.visible = sh.v > 2 || sh.flying
      }
      for (const g of m.glows) g.scale.setScalar((g.userData.baseScale || 1.3) * (0.75 + sh.throttle * 0.3 + boost * 0.6 + (sh.flying ? 0.3 : 0) + Math.random() * 0.05))
      m.under.visible = !sh.airborne
      m.under.material.opacity = 0.55 + 0.25 * Math.min(1, sh.v / top)
      // Sleek cyan-aqua wingtip flight vortex contrails when soaring in N Flight Mode!
      if (sh.flying && sh.wreckT <= 0 && sh.v > 12) {
        for (const sd of [-1, 1]) {
          spark(
            sh.x - fx * 2.5 + bx.x * sd * 1.65, sh.y - fy * 2.5 + bx.y * sd * 1.65, sh.z - fz * 2.5 + bx.z * sd * 1.65,
            -fx * 6 + (Math.random() - 0.5) * 2, 16 * dt + (Math.random() - 0.5) * 1.5, -fz * 6 + (Math.random() - 0.5) * 2,
            0.36 + Math.random() * 0.22, 0.28, 1.45, 1.85,
          )
        }
      }
      // Biome-reactive surface spray when skimming fast across forest rivers, desert oases, frozen ice streams & molten lava rivers!
      if (sh.wreckT <= 0 && !sh.airborne && sh.v > 16 && arena.riverAt?.(sh.x, sh.z) > 0.44) {
        const dxw = sh.x - camera.position.x, dzw = sh.z - camera.position.z
        if (dxw * dxw + dzw * dzw < 230 * 230) {
          const pln = arena.opts.planet
          const sr = pln === 'lava' ? 2.1 : pln === 'ice' ? 0.75 : 0.52
          const sg = pln === 'lava' ? 0.85 : pln === 'ice' ? 1.55 : 1.42
          const sb = pln === 'lava' ? 0.14 : pln === 'ice' ? 1.95 : 1.4
          for (const sd of [-1, 1]) {
            if (Math.random() < 0.72) {
              spark(
                sh.x - fx * 2.4 + rx * sd * 1.7, sh.y - 1.1, sh.z - fz * 2.4 + rz * sd * 1.7,
                -fx * 11 + rx * sd * (5 + Math.random() * 6) + (Math.random() - 0.5) * 6,
                2.8 + Math.random() * 6.8,
                -fz * 11 + rz * sd * (5 + Math.random() * 6) + (Math.random() - 0.5) * 6,
                0.32 + Math.random() * 0.34, sr, sg, sb,
              )
            }
          }
        }
      }
      if (sh.drifting && sh.wreckT <= 0 && !sh.airborne) {
        const dx0 = sh.x - camera.position.x
        const dz0 = sh.z - camera.position.z
        if (dx0 * dx0 + dz0 * dz0 < 200 * 200) {
          const charged = sh.driftT > 0.55
          for (const sd of [-1, 1]) {
            if (Math.random() < 0.7) {
              spark(
                sh.x - fx * 2.8 + rx * sd * 2.2, sh.y - 1.1, sh.z - fz * 2.8 + rz * sd * 2.2,
                -fx * 14 + (Math.random() - 0.5) * 12 + rx * sd * 7, 2 + Math.random() * 7, -fz * 14 + (Math.random() - 0.5) * 12 + rz * sd * 7,
                0.3 + Math.random() * 0.35, charged ? 0.3 : 1.6, charged ? 0.9 : 0.9, charged ? 2.0 : 0.25,
              )
            }
          }
        }
      }
      if (sh.scrape > 0.5 && sh.wreckT <= 0) {
        const dx = sh.x - camera.position.x
        const dz = sh.z - camera.position.z
        if (dx * dx + dz * dz < 160 * 160) {
          for (let k = 0; k < 3; k++) {
            spark(
              sh.x + rx * sh.scrapeSide * 2.6, sh.y - 0.4 + Math.random() * 0.8, sh.z + rz * sh.scrapeSide * 2.6,
              -fx * sh.v * 0.1 + (Math.random() - 0.5) * 9, Math.random() * 7, -fz * sh.v * 0.1 + (Math.random() - 0.5) * 9,
              0.35 + Math.random() * 0.4, 1.6, 1.0, 0.35,
            )
          }
        }
      }
    }
  }
  const updateShips = (dt, time) => {
    if (mode === 'arena') return updateShipsArena(dt, time)
    for (const sh of sim.ships) {
      const m = shipMeshes[sh.id]
      if (!m) continue
      const top = sim.topFor(sh)
      if (garagePreview && sim.state === 'demo' && !sh.isPlayer) { m.root.visible = false; continue }
      const wrecked = sh.wreckT > 0
      if (!(camMode === 'cockpit' && sh.isPlayer && sim.state !== 'demo')) m.root.visible = !wrecked && !(sh.invuln > 0 && sh.invuln < 2.4 && Math.floor(time * 12) % 2 === 0 && sh.isPlayer && sim.state === 'racing')
      else m.root.visible = false
      track.frame(sh.s, frame)
      const hover = 1.4 + (sh.flyH || 0) + Math.sin(time * 3 + sh.id * 1.7) * 0.08 + sh.boostT * 0.02
      const cy = Math.cos(sh.yaw), sy = Math.sin(sh.yaw)
      let fx = frame.tx * cy + frame.rx * sy, fy = frame.ty * cy + frame.ry * sy, fz = frame.tz * cy + frame.rz * sy
      const rx = frame.rx * cy - frame.tx * sy, ry = frame.ry * cy - frame.ty * sy, rz = frame.rz * cy - frame.tz * sy
      // Pitch around right axis when climbing/diving in Flight Mode!
      const pt = sh.airborne ? sh.pitch || 0 : 0
      const cpt = Math.cos(pt), spt = Math.sin(pt)
      const fx2 = fx * cpt + frame.ux * spt, fy2 = fy * cpt + frame.uy * spt, fz2 = fz * cpt + frame.uz * spt
      const ux2 = frame.ux * cpt - fx * spt, uy2 = frame.uy * cpt - fy * spt, uz2 = frame.uz * cpt - fz * spt
      fx = fx2; fy = fy2; fz = fz2
      const roll = clamp(sh.steerNow * (sh.flying ? 0.68 : 0.54) + sh.vx * 0.008, -0.88, 0.88)
      const cr = Math.cos(roll), sr = Math.sin(roll)
      const r2x = rx * cr - ux2 * sr, r2y = ry * cr - uy2 * sr, r2z = rz * cr - uz2 * sr
      const u2x = ux2 * cr + rx * sr, u2y = uy2 * cr + ry * sr, u2z = uz2 * cr + rz * sr
      bx.set(r2x, r2y, r2z)
      by.set(u2x, u2y, u2z)
      bz.set(-fx, -fy, -fz)
      mat.makeBasis(bx, by, bz)
      mat.setPosition(
        frame.px + frame.rx * sh.x + frame.ux * hover,
        frame.py + frame.ry * sh.x + frame.uy * hover,
        frame.pz + frame.rz * sh.x + frame.uz * hover,
      )
      m.root.matrix.copy(mat)
      m.root.matrixWorldNeedsUpdate = true
      m.under.visible = !sh.airborne
      const boost = sh.boostT > 0 || sh.turboOn ? 1 : 0
      m.animate?.({
        steer: sh.steerNow,
        drift: 0,
        throttle: sh.throttle,
        boost,
        speedRatio: sh.v / Math.max(1, top),
        pitch: sh.pitch || 0,
        vy: sh.vy || 0,
        airborne: !!sh.airborne,
        flying: !!sh.flying,
        climb: sh.climbNow || 0,
        landImpact: sh.landImpact || 0,
        time,
      }, dt)
      const len = 0.9 + sh.throttle * 2.6 * (0.4 + sh.v / top) + boost * 6.5
      for (const t of m.trails) {
        t.scale.set(1 + boost * 0.35, 1 + boost * 0.35, len * (0.85 + Math.random() * 0.3))
        t.visible = sh.v > 2
      }
      for (const g of m.glows) g.scale.setScalar((g.userData.baseScale || 1.3) * (0.75 + sh.throttle * 0.3 + boost * 0.6 + Math.random() * 0.05))
      m.under.material.opacity = 0.55 + 0.25 * Math.min(1, sh.v / top)
      // sparks from scraping
      if (sh.scrape > 0.5 && sh.wreckT <= 0) {
        const dx = frame.px + frame.rx * sh.scrapeSide * (track.halfW - 0.4) + frame.ux * 0.6 - camera.position.x
        const dz = frame.pz + frame.rz * sh.scrapeSide * (track.halfW - 0.4) - camera.position.z
        if (dx * dx + dz * dz < 160 * 160) {
          for (let k = 0; k < 3; k++) {
            spark(
              frame.px + frame.rx * sh.scrapeSide * (track.halfW - 0.4) + frame.ux * (0.3 + Math.random() * 0.6),
              frame.py + frame.ry * sh.scrapeSide * (track.halfW - 0.4) + frame.uy * (0.3 + Math.random() * 0.6),
              frame.pz + frame.rz * sh.scrapeSide * (track.halfW - 0.4) + frame.uz * (0.3 + Math.random() * 0.6),
              -frame.tx * sh.v * 0.12 - frame.rx * sh.scrapeSide * (4 + Math.random() * 8) + (Math.random() - 0.5) * 8,
              Math.random() * 7,
              -frame.tz * sh.v * 0.12 - frame.rz * sh.scrapeSide * (4 + Math.random() * 8) + (Math.random() - 0.5) * 8,
              0.35 + Math.random() * 0.4, 1.6, 1.0, 0.35,
            )
          }
        }
      }
    }
  }

  const boom = (sh) => {
    let px, py, pz
    if (mode === 'arena') {
      px = sh.x; py = sh.y + 1; pz = sh.z
      frame.tx = Math.sin(sh.yaw); frame.tz = -Math.cos(sh.yaw)
    } else {
      track.frame(sh.s, frame)
      px = frame.px + frame.rx * sh.x + frame.ux * 1
      py = frame.py + frame.ry * sh.x + frame.uy * 1
      pz = frame.pz + frame.rz * sh.x + frame.uz * 1
    }
    for (let k = 0; k < 110; k++) {
      const a = Math.random() * 6.283
      const e = (Math.random() - 0.2) * 1.4
      const sp = 8 + Math.random() * 40
      spark(px, py, pz, Math.cos(a) * Math.cos(e) * sp + frame.tx * sh.v * 0.5, Math.sin(e) * sp + 6, Math.sin(a) * Math.cos(e) * sp + frame.tz * sh.v * 0.5, 0.6 + Math.random() * 1.1, 1.8, 0.8 + Math.random() * 0.5, 0.2)
    }
  }

  // ── hud
  const hud = {
    state: 'demo', count: 3, speed: 0, speedRatio: 0, lap: 0, laps: 3, rank: 1, total: 1, time: 0, lapTime: 0, best: 0, shield: 100, shieldMax: 100,
    energy: 0.5, boost: false, turbo: false, flying: false, alt: 0, wrecked: false, scrape: 0, finished: false, board: [], results: [], mini: [], minis: [],
    camMode, paused: false, gap: 0, lastLap: 0, class: 'Flash', top: 178, mode, cuts: [], gatePts: [], nextGate: 0, gateAngle: 0, gateDist: 0, gateCount: 0,
    planet: 'forest', rivers: [], lagoons: [], peaks: [],
  }
  // mini-map outline + topographical rivers, lagoons & forested mountains
  let mini = []
  let miniBounds = null
  const buildMini = () => {
    if (mode === 'arena') {
      const B = arena.bounds
      const nrm = (x, z) => [(x - B.x0) * B.sc + B.ox, (z - B.z0) * B.sc + B.oz]
      const main = []
      for (let k = 0; k < arena.n; k++) {
        const p = arena.paths[k]
        for (let i = 0; i < p.pts.length - 1; i += 2) main.push(nrm(p.pts[i][0], p.pts[i][1]))
      }
      miniBounds = B
      mini = main
      hud.mini = main
      hud.planet = arena.opts.planet
      hud.cuts = arena.paths.filter((p) => p.kind === 'cut').map((p) => p.pts.filter((_, i) => i % 2 === 0 || i === p.pts.length - 1).map((q) => nrm(q[0], q[1])))
      hud.gatePts = arena.gates.map((g) => nrm(g.x, g.z))
      hud.rivers = (arena.rivers || []).map((rv) => ({
        kind: rv.kind,
        pts: rv.pts.filter((_, i) => i % 2 === 0 || i === rv.pts.length - 1).map((q) => nrm(q[0], q[1])),
      }))
      hud.lagoons = (arena.lagoons || []).map((lg) => {
        const [lx, lz] = nrm(lg.x, lg.z)
        return [lx, lz, Math.max(lg.rx, lg.rz) * B.sc]
      })
      hud.peaks = (arena.peaks || []).map((pk) => {
        const [px, pz] = nrm(pk.x, pk.z)
        return [px, pz, pk.radius * B.sc, pk.kind]
      })
      return
    }
    hud.cuts = []
    hud.gatePts = []
    hud.rivers = []
    hud.lagoons = []
    hud.peaks = []
    hud.planet = ''
    const pts2 = []
    let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9
    for (let i = 0; i < track.N; i += 6) {
      pts2.push([track.px[i], track.pz[i]])
      x0 = Math.min(x0, track.px[i]); x1 = Math.max(x1, track.px[i]); z0 = Math.min(z0, track.pz[i]); z1 = Math.max(z1, track.pz[i])
    }
    const sc = 1 / Math.max(x1 - x0, z1 - z0)
    const ox = (1 - (x1 - x0) * sc) / 2
    const oz = (1 - (z1 - z0) * sc) / 2
    miniBounds = { x0, z0, sc, ox, oz }
    mini = pts2.map(([x, z]) => [(x - x0) * sc + ox, (z - z0) * sc + oz])
    hud.mini = mini
  }
  buildMini()

  const events = []
  const handleEvents = () => {
    const evs = sim.events.splice(0)
    const pl = sim.player
    for (const e of evs) {
      switch (e.type) {
        case 'count': audio.count(e.n); events.push({ type: 'count', n: e.n }); break
        case 'go': audio.go(); events.push({ type: 'go' }); break
        case 'pad': if (e.id === 0) { audio.pad(); events.push({ type: 'pad' }) } break
        case 'turbo': audio.pad(); events.push({ type: 'launch' }); break
        case 'wall': if (e.id === 0) audio.impact(e.v, e.side) ; break
        case 'bump': audio.bump(e.v); break
        case 'wreck': {
          const sh = sim.ships[e.id]
          boom(sh)
          const d = Math.abs(sh.dist - pl.dist)
          audio.explosion(sh.isPlayer ? 0 : d, sh.isPlayer ? 0 : Math.sign(sh.x - pl.x))
          if (sh.isPlayer) events.push({ type: 'wreck' })
          break
        }
        case 'lap': {
          const prevBest = pl.lapTimes.length > 1 ? Math.min(...pl.lapTimes.slice(0, -1)) : Infinity
          audio.lap()
          events.push({ type: 'lap', n: e.n, v: e.v, best: e.v <= prevBest })
          break
        }
        case 'final': audio.finalLap(); events.push({ type: 'final' }); break
        case 'finish': if (e.id === 0) { audio.finish(pl.rank); events.push({ type: 'finish', rank: pl.rank }) } break
        case 'pass': audio.whoosh(e.side || 1); break
        case 'drift': if (e.id === 0) { audio.pad(); events.push({ type: 'drift', v: e.v }) } break
        case 'smash': {
          const o = arena.obstacles[e.id]
          const g0 = arena.groundAt(o.x, o.z)
          for (let k = 0; k < 70; k++) {
            const a = Math.random() * 6.283
            const sp = 6 + Math.random() * 30
            spark(o.x + (Math.random() - 0.5) * o.r * 1.6, g0 + 2 + Math.random() * 12, o.z + (Math.random() - 0.5) * 6, Math.cos(a) * sp, Math.random() * 18, Math.sin(a) * sp, 0.6 + Math.random() * 0.9, 1.5, 0.9, 0.5)
          }
          audio.explosion(Math.hypot(o.x - pl.x, o.z - pl.z), 0)
          events.push({ type: 'smash' })
          break
        }
        case 'repair': audio.repair(); break
        case 'flyOn':
          audio.flightOn()
          events.push({ type: 'flyOn' })
          break
        case 'flyOff':
          audio.flightOff()
          events.push({ type: 'flyOff' })
          break
        case 'land': {
          const sev = clamp(e.v || 0.5, 0.25, 1.5)
          audio.land(sev)
          landCamDip = Math.max(landCamDip, Math.min(1.1, sev * 0.8))
          // Radial hover-cushion / river-splash ring on touchdown!
          let lx = pl.x, ly = pl.y - 0.9, lz = pl.z, onWater = false
          if (mode === 'arena') {
            onWater = arena.opts.planet === 'forest' && arena.riverAt?.(pl.x, pl.z) > 0.42
          } else {
            track.frame(pl.s, frame)
            lx = frame.px + frame.rx * pl.x + frame.ux * 0.4
            ly = frame.py + frame.ry * pl.x + frame.uy * 0.4
            lz = frame.pz + frame.rz * pl.x + frame.uz * 0.4
          }
          const ringCount = Math.round(18 + sev * 18)
          for (let k = 0; k < ringCount; k++) {
            const a = (k / ringCount) * Math.PI * 2 + Math.random() * 0.2
            const sp = (9 + Math.random() * 11) * sev
            spark(
              lx + Math.cos(a) * 1.4, ly, lz + Math.sin(a) * 1.4,
              Math.cos(a) * sp, (2.5 + Math.random() * 5) * sev, Math.sin(a) * sp,
              0.34 + Math.random() * 0.28,
              onWater ? 0.5 : 0.45, onWater ? 1.5 : 1.35, onWater ? 1.5 : 1.75,
            )
          }
          break
        }
      }
    }
  }

  const updateHud = () => {
    const pl = sim.player
    const top = sim.topFor(pl)
    hud.state = sim.state
    hud.count = Math.max(1, Math.ceil(sim.count))
    hud.speed = Math.round(pl.v * 3.6 * 1.8)
    hud.speedRatio = pl.v / top
    hud.lap = clamp(pl.lap, 0, settings.laps)
    hud.laps = settings.laps
    hud.rank = pl.rank
    hud.total = sim.ships.length
    hud.time = sim.state === 'racing' || sim.state === 'finished' ? sim.time : 0
    hud.lapTime = pl.lap >= 1 && !pl.finished ? sim.time - pl.lapStart : 0
    hud.best = pl.best === Infinity ? 0 : pl.best
    hud.lastLap = pl.lapTimes.length ? pl.lapTimes[pl.lapTimes.length - 1] : 0
    hud.shield = Math.max(0, pl.shield)
    hud.shieldMax = settings.shieldMax
    hud.energy = pl.energy
    hud.boost = pl.boostT > 0
    hud.turbo = pl.turboOn
    hud.flying = !!pl.flying
    hud.alt = Math.max(0, Math.round(mode === 'arena' ? pl.y - arena.groundAt(pl.x, pl.z) : pl.flyH || 0))
    hud.drift = pl.driftT ? Math.min(1, pl.driftT / 1.2) : 0
    hud.drifting = !!pl.drifting
    hud.wrecked = pl.wreckT > 0
    hud.scrape = pl.scrape
    hud.finished = pl.finished
    hud.camMode = camMode
    hud.class = ['Vektor', 'Venom', 'Flash', 'Rapier'][clamp(Math.round(settings.shipClass), 0, 3)]
    hud.top = top
    const rk = sim.ranking()
    const leader = rk[0]
    hud.board = rk.slice(0, 8).map((s) => ({
      id: s.id, name: s.name, color: s.color, rank: s.rank, isPlayer: s.isPlayer, finished: s.finished, time: s.finishTime,
      gap: s === leader ? 0 : Math.max(0, (leader.dist - s.dist) / Math.max(40, s.v || top * 0.5)),
    }))
    if (!hud.board.some((b) => b.isPlayer)) {
      const s = pl
      hud.board.push({ id: s.id, name: s.name, color: s.color, rank: s.rank, isPlayer: true, finished: s.finished, time: s.finishTime, gap: Math.max(0, (leader.dist - s.dist) / Math.max(40, s.v || top * 0.5)) })
    }
    hud.results = sim.state === 'finished' || pl.finished ? rk.map((s) => ({ id: s.id, name: s.name, color: s.color, rank: s.rank, isPlayer: s.isPlayer, finished: s.finished, time: s.finishTime, best: s.best === Infinity ? 0 : s.best, progress: s.dist })) : []
    const dd = hud.minis
    dd.length = 0
    for (const s of sim.ships) {
      if (mode === 'arena') {
        dd.push([(s.x - miniBounds.x0) * miniBounds.sc + miniBounds.ox, (s.z - miniBounds.z0) * miniBounds.sc + miniBounds.oz, s.id, s.isPlayer ? 1 : 0, s.wreckT > 0 ? 1 : 0])
        continue
      }
      const i = Math.floor(s.s / track.ds) % track.N
      dd.push([(track.px[i] - miniBounds.x0) * miniBounds.sc + miniBounds.ox, (track.pz[i] - miniBounds.z0) * miniBounds.sc + miniBounds.oz, s.id, s.isPlayer ? 1 : 0, s.wreckT > 0 ? 1 : 0])
    }
    hud.mode = mode
    if (mode === 'arena') {
      const g = arena.gates[pl.cp % arena.n]
      hud.nextGate = pl.cp % arena.n
      hud.gateCount = arena.n
      hud.gateDist = Math.hypot(g.x - pl.x, g.z - pl.z)
      let ang = Math.atan2(g.x - pl.x, -(g.z - pl.z)) - pl.yaw
      hud.gateAngle = Math.atan2(Math.sin(ang), Math.cos(ang))
    }
    hud.gap = pl.rank > 1 ? hud.board.find((b) => b.isPlayer)?.gap || 0 : 0
  }

  const camFwd = new THREE.Vector3()
  const camTmp = new THREE.Vector3()
  const SUN_COL = { day: [255, 246, 222], sunset: [255, 170, 92], night: [150, 190, 255] }
  const SUN_DIR = { day: [0.5, 0.32], sunset: [0.95, 0.5], night: [0.3, 0.42] }
  const SUN_POW = { day: 1, sunset: 1.1, night: 0.45 }
  const packRGB = (c) => ((255 << 24) | (c[2] << 16) | (c[1] << 8) | c[0]) >>> 0

  const drawBikeCockpit = () => {
    const W = cockCv.width
    const H = cockCv.height
    if (!W || !H) return
    const ctx = cockCtx
    const pilot = sim.player
    const s = H / 720
    const lean = clamp(pilot.steerNow, -1, 1)
    const color = settings.skin === 'sport' ? '#e4b65a' : settings.skin === 'swoop' ? '#f27b42' : '#a8eced'
    const polygon = (points, fill, stroke, line = 1) => {
      ctx.beginPath()
      points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)))
      ctx.closePath()
      ctx.fillStyle = fill
      ctx.fill()
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = line; ctx.stroke() }
    }

    ctx.clearRect(0, 0, W, H)
    ctx.save()
    ctx.globalAlpha = cockIn
    ctx.translate(W / 2, H)
    ctx.scale(s, s)
    ctx.translate(-lean * 13, 0)
    const reach = Math.max(350, W / (2 * s))
    const paint = ctx.createLinearGradient(0, -175, 0, 0)
    paint.addColorStop(0, '#899697')
    paint.addColorStop(0.28, '#48565b')
    paint.addColorStop(1, '#17252d')

    // Fairing and handlebars stay low enough to leave the route unobstructed.
    polygon([[-185, 0], [-135, -104], [-74, -132], [74, -132], [135, -104], [185, 0]], paint, '#101c22', 5)
    polygon([[-75, -100], [-56, -149], [56, -149], [75, -100]], '#18282d', '#b6c7c4', 4)
    ctx.lineCap = 'round'
    for (const side of [-1, 1]) {
      ctx.beginPath()
      ctx.moveTo(side * 65, -114)
      ctx.lineTo(side * 180, -157 + side * lean * 8)
      ctx.lineTo(side * 260, -147 + side * lean * 8)
      ctx.strokeStyle = '#101a20'
      ctx.lineWidth = 21
      ctx.stroke()
      ctx.strokeStyle = '#9aa9a5'
      ctx.lineWidth = 10
      ctx.stroke()
      ctx.beginPath()
      ctx.moveTo(side * 190, -155 + side * lean * 8)
      ctx.lineTo(side * 272, -145 + side * lean * 8)
      ctx.strokeStyle = '#1b2528'
      ctx.lineWidth = 18
      ctx.stroke()
      // Gloved hands reach the controls from either lower corner.
      polygon([[side * reach, 0], [side * 295, -66], [side * 235, -126], [side * 204, -117], [side * 224, -76], [side * 255, 0]], '#3a4b45', '#1b2625', 4)
      ctx.beginPath()
      ctx.ellipse(side * 222, -132 + side * lean * 8, 37, 22, -side * 0.18, 0, Math.PI * 2)
      ctx.fillStyle = '#263334'
      ctx.fill()
      ctx.strokeStyle = '#9aa9a5'
      ctx.lineWidth = 3
      ctx.stroke()
    }
    ctx.fillStyle = color
    ctx.font = 'bold 44px ui-monospace, monospace'
    ctx.textAlign = 'center'
    ctx.fillText(String(hud.speed), 0, -97)
    ctx.fillStyle = '#d9eeee'
    ctx.font = 'bold 13px ui-monospace, monospace'
    ctx.fillText('KM/H', 0, -78)
    ctx.fillStyle = '#142126'
    ctx.fillRect(-53, -65, 106, 7)
    ctx.fillStyle = color
    ctx.fillRect(-53, -65, 106 * clamp(pilot.energy, 0, 1), 7)
    ctx.restore()
  }

  const drawCockpitFrame = (dt, time) => {
    const W = cockCv.width
    const H = cockCv.height
    if (!W || !H) return
    const pl = sim.player
    const tod = settings.theme in SUN_DIR ? settings.theme : 'day'
    const key = W + 'x' + H + tod
    if (!cockArt || key !== cockKey) {
      cockArt = buildCockpit(W, H, cockpitPalette(0, tod))
      cockKey = key
      cockFb = new Uint32Array(W * H)
      cockImg = new ImageData(new Uint8ClampedArray(cockFb.buffer), W, H)
    }
    cockFb.fill(0)
    const top = sim.topFor(pl)
    const boost = pl.boostT > 0 || pl.turboOn ? 1 : 0
    // the pilot's head sways with the flying, on a soft spring
    const hxGoal = clamp(pl.steerNow, -1, 1) * 6.4 + Math.sin(time * 0.53) * 0.3
    const hyGoal = boost * 1.6 + (pl.v / top) * 0.8 + Math.sin(time * 0.71 + 1) * 0.25 + (pl.scrape > 0.3 ? (Math.random() - 0.5) * 2 : 0)
    headVX += ((hxGoal - headX) * 64 - headVX * 11) * dt
    headVY += ((hyGoal - headY) * 64 - headVY * 11) * dt
    headX = clamp(headX + headVX * dt, -8, 8)
    headY = clamp(headY + headVY * dt, -5, 5)
    // where the horizon and the roll are, from the camera
    camera.getWorldDirection(camFwd)
    const flat = Math.hypot(camFwd.x, camFwd.z) || 1
    camTmp.set(camera.position.x + (camFwd.x / flat) * 6000, camera.position.y, camera.position.z + (camFwd.z / flat) * 6000).project(camera)
    const horizonY = (1 - camTmp.y) * 0.5 * H
    const e = camera.matrixWorld.elements
    const roll = Math.atan2(-e[1], e[5])
    const pitch = Math.asin(clamp(camFwd.y, -1, 1))
    const focal = H / 2 / Math.tan((camera.fov * Math.PI) / 360)
    // sunlight from where the sun is, relative to the way the road runs
    let fwdX, fwdZ, rgtX, rgtZ
    if (mode === 'arena') {
      fwdX = Math.sin(pl.yaw); fwdZ = -Math.cos(pl.yaw); rgtX = Math.cos(pl.yaw); rgtZ = Math.sin(pl.yaw)
    } else {
      track.frame(pl.s, frame)
      fwdX = frame.tx; fwdZ = frame.tz; rgtX = frame.rx; rgtZ = frame.rz
    }
    const sd = SUN_DIR[tod]
    const sl = Math.hypot(sd[0], sd[1]) || 1
    const sunSide = -(sd[0] * rgtX + sd[1] * rgtZ) / sl
    const sunFront = -(sd[0] * fwdX + sd[1] * fwdZ) / sl
    const u = clamp((cockIn - 0.55) / 0.45, 0, 1)
    const live = {
      time,
      inPlace: cockIn,
      hud: u * u * (3 - 2 * u),
      roll,
      pitch,
      pivotY: Math.round(H * PIVOT),
      horizonY,
      focal,
      headX,
      headY: headY + (boost && cockIn > 0.9 ? ((((time * 30) | 0) & 1) - 0.5) * 1.4 : 0),
      sunSide,
      sunReach: 0.72 - 0.28 * sunFront,
      sunColor: packRGB(SUN_COL[tod]),
      sunPower: SUN_POW[tod],
      kmh: hud.speed,
      speed01: pl.v / top,
      energy: pl.energy,
      shield01: pl.shield / Math.max(1, settings.shieldMax),
      turn: pl.steerNow,
      climb: clamp(pl.throttle * 0.7 - (pl.lastInput?.brake || 0), -1, 1),
      boost: clamp(Math.max(pl.throttle * 0.75, boost), 0, 1),
      curve: mode === 'arena' ? clamp(hud.gateAngle * 1.3, -1, 1) : clamp(track.curvAt(pl.s + pl.v * 0.6) * 700, -1, 1),
      rank: pl.rank,
      total: sim.ships.length,
      lap: clamp(pl.lap, 1, settings.laps),
      arena: mode === 'arena',
      laps: settings.laps,
      map: { pts: hud.mini, ships: hud.minis, cuts: hud.cuts, gates: hud.gatePts, next: hud.nextGate },
    }
    drawCockpit(cockFb, cockArt, live)
    cockCtx.putImageData(cockImg, 0, 0)
  }

  const updateCockpit = (dt, time) => {
    const want = camMode === 'cockpit' && sim.state !== 'demo' && sim.player.wreckT <= 0
    cockIn += ((want ? 1 : 0) - cockIn) * (1 - Math.exp(-dt * 3.4))
    if (!want && cockIn < 0.01) cockIn = 0
    if (want && cockIn > 0.995) cockIn = 1
    const on = cockIn > 0.004
    cockCv.style.display = on ? 'block' : 'none'
    const w = container.clientWidth
    const h = container.clientHeight
    if (on && w && h) {
      // the world is framed in the window above the instrument panel
      const bike = isBike(sim.player.skin)
      camera.setViewOffset(w, h, 0, (h / 2 - h * (bike ? 0.5 : PIVOT)) * cockIn, w, h)
      if (bike) drawBikeCockpit()
      else drawCockpitFrame(dt, time)
    } else if (sim.state === 'demo' && !garagePreview && !forestTour && w > 720) {
      camera.setViewOffset(w, h, -Math.min(260, (w - 520) / 2), 0, w, h)
    } else if (camera.view && camera.view.enabled) camera.clearViewOffset()
  }

  const renderFrame = () => {
    if (settings.bloom || settings.look === 'soft') composer.render()
    else renderer.render(scene, camera)
  }

  // ── main loop
  let raf = 0
  let last = performance.now()
  let clock = 0
  const loop = (now) => {
    raf = requestAnimationFrame(loop)
    let dt = Math.min(0.05, Math.max(0.0001, (now - last) / 1000))
    last = now
    if (paused) { renderFrame(); return }
    clock += dt
    const inp = readInput(dt)
    if (!(garagePreview && sim.state === 'demo')) sim.step(dt, inp)
    handleEvents()
    updateShips(dt, clock)
    updateCamera(dt)
    if (forestTour && mode === 'arena' && arena && sim.state === 'demo') {
      tourTime += dt
      const cx0 = arena.ox + arena.size * 0.5, cz0 = arena.oz + arena.size * 0.5
      camera.up.set(0, 1, 0)
      if (forestTour === 'river') {
        const rv = (arena.rivers || []).find((r) => r.kind === 'rapid') || arena.rivers?.[0]
        if (rv && rv.pts.length > 4) {
          const u = (tourTime * 0.065) % 0.82
          const fi = u * (rv.pts.length - 1), i0 = Math.floor(fi), i1 = Math.min(rv.pts.length - 1, i0 + 1), f = fi - i0
          const px = rv.pts[i0][0] + (rv.pts[i1][0] - rv.pts[i0][0]) * f
          const pz = rv.pts[i0][1] + (rv.pts[i1][1] - rv.pts[i0][1]) * f
          const li = Math.min(rv.pts.length - 1, i0 + 6)
          camera.position.set(px, arena.groundAt(px, pz) + 19 + Math.sin(tourTime * 0.5) * 4, pz)
          camera.lookAt(rv.pts[li][0], arena.groundAt(rv.pts[li][0], rv.pts[li][1]) + 10, rv.pts[li][1])
        }
      } else if (forestTour === 'giants') {
        // Sweep around oasis lagoon / monumental canyon arch / giant rainforest grove!
        const p0 = arena.paths[0]
        const archPt = p0.pts[Math.floor(p0.pts.length * 0.34)]
        const focal = arena.opts.planet === 'forest'
          ? (arena.lagoons?.[0] || { x: arena.gates[1].x, z: arena.gates[1].z })
          : { x: archPt[0], z: archPt[1] }
        const a = tourTime * 0.17 + 0.6, rad = arena.opts.planet === 'forest' ? 115 : 92
        const px = focal.x + Math.cos(a) * rad, pz = focal.z + Math.sin(a) * rad
        camera.position.set(px, arena.groundAt(px, pz) + 26, pz)
        camera.lookAt(focal.x, arena.groundAt(focal.x, focal.z) + 28, focal.z)
      } else if (forestTour === 'mountain') {
        const pk = (arena.peaks || []).find((p) => p.kind === 'central') || arena.peaks?.[0] || { x: cx0, z: cz0, y: 240 }
        const a = tourTime * 0.12 + 2.2, rad = Math.max(620, arena.size * 0.26)
        const px = pk.x + Math.cos(a) * rad, pz = pk.z + Math.sin(a) * rad
        camera.position.set(px, Math.max(arena.groundAt(px, pz) + 68, pk.y * 0.85), pz)
        camera.lookAt(pk.x, pk.y * 0.55, pk.z)
      } else if (forestTour === 'map') {
        const a = tourTime * 0.085 + 0.85, rad = arena.size * 0.42
        camera.position.set(cx0 + Math.cos(a) * rad, 920, cz0 + Math.sin(a) * rad)
        camera.lookAt(cx0, 62, cz0)
      }
      camera.fov = 64
      camera.updateProjectionMatrix()
      camera.updateMatrixWorld()
    }
    if (api.freeCam) {
      const f = api.freeCam
      camera.position.set(f.pos[0], f.pos[1], f.pos[2])
      camera.up.set(0, 1, 0)
      camera.lookAt(f.look[0], f.look[1], f.look[2])
      camera.updateMatrixWorld()
    }
    updateCockpit(dt, clock)
    stepParticles(dt)
    world.update(dt, camera.position, sim)
    updateHud()
    const pl = sim.player
    const top = sim.topFor(pl)
    audio.update({
      playing: sim.state !== 'demo',
      state: sim.state,
      speedRatio: clamp(pl.v / top, 0, 1.5),
      boost: pl.boostT > 0 || pl.turboOn ? 1 : 0,
      throttle: pl.throttle,
      scrape: pl.scrape,
      wrecked: pl.wreckT > 0,
      shield01: pl.shield / Math.max(1, settings.shieldMax),
      rank: pl.rank,
      pace: clamp(sim.state === 'demo' ? 0.4 : pl.v / top, 0, 1),
    })
    renderFrame()
  }
  raf = requestAnimationFrame(loop)

  // ── sizing
  const resize = () => {
    const w = container.clientWidth
    const h = container.clientHeight
    if (!w || !h) return
    let lw
    let lh
    const soft = settings.look === 'soft'
    if (soft) {
      // soft look: close to the screen's own resolution, smoothed when stretched
      const k = Math.min(window.devicePixelRatio || 1, 2) * clamp(settings.renderScale || 0.8, 0.3, 1.5)
      lw = Math.max(64, Math.round(w * k))
      lh = Math.max(36, Math.round(h * k))
    } else {
      // low resolution, upscaled with hard pixels — like the jet game
      const auto = Math.min(8, Math.max(2, Math.round(Math.sqrt((w * h) / 100000))))
      const px = settings.pixelSize > 0 ? Math.round(settings.pixelSize) : auto
      lw = Math.max(64, Math.ceil(w / px))
      lh = Math.max(36, Math.ceil(h / px))
    }
    renderer.setPixelRatio(1)
    renderer.setSize(lw, lh, false)
    renderer.domElement.style.imageRendering = soft ? 'auto' : 'pixelated'
    cockCv.style.imageRendering = soft ? 'auto' : 'pixelated'
    composer.setPixelRatio(1)
    composer.setSize(lw, lh)
    cockCv.width = lw
    cockCv.height = lh
    cockKey = ''
    camera.aspect = w / h
    camera.updateProjectionMatrix()
  }
  const ro = new ResizeObserver(resize)
  ro.observe(container)
  resize()

  let rebuildTimer = 0
  let trackDirty = false
  let arenaDirty = false
  let worldDirty = false
  const applyWorldChanges = () => {
    if (!worldDirty) return
    window.clearTimeout(rebuildTimer)
    rebuildTimer = 0
    const nextMode = settings.mode === 'arena' ? 'arena' : 'track'
    const modeChanged = nextMode !== mode
    const wasRacing = sim.state === 'countdown' || sim.state === 'racing'
    let structuralChange = modeChanged
    mode = nextMode
    if (mode === 'track') {
      if (trackDirty) {
        track = buildTrack(trackOpts(settings))
        trackSim.setTrack(track)
        structuralChange = true
      }
      sim = trackSim
      trackDirty = false
    } else {
      if (!arena || !arenaSim || arenaDirty) {
        arena = buildArena(arenaOpts(settings))
        arenaSim = new ArenaSim(arena, raceParams(settings))
        structuralChange = true
      }
      sim = arenaSim
      arenaDirty = false
    }
    sim.p = raceParams(settings)
    if (structuralChange) {
      sim.setup(wasRacing ? 'countdown' : 'demo')
      buildMini()
      syncShips()
    }
    worldDirty = false
    buildAll()
  }
  const api = {
    freeCam: null,
    get world() { return world },
    get arena() { return arena },
    get sim() { return sim },
    hud,
    drainEvents: () => events.splice(0, events.length),
    onCamera: null,
    startRace() {
      flightMode = false
      nClimbHold = false
      forestTour = null
      garagePreview = false
      applyWorldChanges()
      sim.p = raceParams(settings)
      sim.startRace()
      syncShips()
      steerSmooth = 0
      camX = 0
    },
    toMenu() {
      flightMode = false
      nClimbHold = false
      applyWorldChanges()
      sim.p = raceParams(settings)
      sim.setup('demo')
      syncShips()
    },
    toggleFlight: () => toggleFlight(),
    resetPlayer: () => resetPlayer(),
    setGaragePreview(v) {
      applyWorldChanges()
      if (v) forestTour = null
      if (v && !garagePreview && sim.state === 'demo') {
        sim.setup('demo')
        camYaw = sim.player.yaw
      }
      garagePreview = !!v
    },
    setForestTour(preset) {
      applyWorldChanges()
      if (preset) garagePreview = false
      forestTour = preset || null
      tourTime = 0
    },
    setPaused(v) { paused = v; hud.paused = v },
    setCamera(m) { camMode = m },
    setTouch(patch) { Object.assign(touch, patch) },
    applySettings(next) {
      const prev = settings
      settings = { ...next }
      sim.p = raceParams(settings)
      if (prev.camMode !== settings.camMode) camMode = settings.camMode
      if (prev.showGuides !== settings.showGuides) world?.setGuides?.(settings.showGuides !== false)
      if (prev.skin !== settings.skin || prev.botSkins !== settings.botSkins) {
        sim.syncVehicleSelections()
        syncShips()
      }
      if (prev.look !== settings.look) {
        makeComposer()
        setTheme()
      }
      if (prev.pixelSize !== settings.pixelSize || prev.renderScale !== settings.renderScale || prev.look !== settings.look) resize()
      const trackChanged = TRACK_KEYS.some((k) => prev[k] !== settings[k])
      const arenaChanged = ARENA_KEYS.some((k) => prev[k] !== settings[k])
      const themeChanged = prev.theme !== settings.theme || prev.look !== settings.look || prev.islands !== settings.islands || prev.worldSeed !== settings.worldSeed || prev.clouds !== settings.clouds || prev.forestDensity !== settings.forestDensity
      trackDirty ||= trackChanged
      arenaDirty ||= arenaChanged
      const nextMode = settings.mode === 'arena' ? 'arena' : 'track'
      if (nextMode !== mode || (nextMode === 'track' ? trackDirty : arenaDirty) || themeChanged) {
        worldDirty = true
        window.clearTimeout(rebuildTimer)
        rebuildTimer = window.setTimeout(applyWorldChanges, 260)
      } else if (bloom) setTheme()
      if (sim.state === 'demo' && prev.bots !== settings.bots) { sim.setup('demo'); syncShips() }
      if (sim.state === 'demo' && prev.shipClass !== settings.shipClass) { sim.setup('demo'); syncShips() }
    },
    dispose() {
      cancelAnimationFrame(raf)
      window.clearTimeout(rebuildTimer)
      ro.disconnect()
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      window.removeEventListener('blur', onBlur)
      for (const ship of shipMeshes) disposeShip(ship)
      world.dispose()
      renderer.dispose()
      composer.dispose()
      container.removeChild(renderer.domElement)
      container.removeChild(cockCv)
    },
    renderer,
    camera,
    scene,
  }
  void LIVERIES
  if (typeof window !== 'undefined') window.__hr = api
  return api
}
