// Race simulation: hover-craft physics in track space, AI pilots, laps, positions.
import { mod, type Track } from './track'
import { getVehicleStats, vehicleForRacer, type VehicleId } from './vehicles'

export const CLASS_TOP = [140, 190, 245, 305] // m/s
export const CLASS_NAMES = ['Vektor', 'Venom', 'Flash', 'Rapier']

export type RaceParams = {
  laps: number
  bots: number
  botSkill: number
  rubber: number
  shipClass: number
  assist: number
  steerGain: number
  accelGain: number
  wallDmg: number
  shieldMax: number
  turboDrain: number
  turboRegen: number
  padPower: number
  airbrake: number
  autoGas: boolean
  skin?: string
  botSkins?: string
}

export type Input = {
  throttle: number
  brake: number
  steer: number
  abL: number
  abR: number
  turbo: boolean
  fly?: boolean
  climb?: number
}

export type RaceEvent = {
  type: 'pad' | 'wall' | 'bump' | 'wreck' | 'lap' | 'finish' | 'count' | 'go' | 'pass' | 'repair' | 'final' | 'turbo' | 'smash' | 'drift' | 'flyOn' | 'flyOff' | 'land'
  id?: number
  n?: number
  v?: number
  side?: number
}

export class Ship {
  id = 0
  name = ''
  isPlayer = false
  skin: VehicleId = 'racer'
  color = 0
  skill = 0.5
  lane = 0
  dist = 0
  s = 0
  x = 0
  vx = 0
  v = 0
  yaw = 0
  yawV = 0
  pitch = 0
  vy = 0
  flyH = 0
  flyVy = 0
  flying = false
  airborne = false
  landImpact = 0
  climbNow = 0
  driftT = 0
  drifting = false
  shield = 100
  energy = 0.5
  boostT = 0
  turboOn = false
  lap = 0
  finished = false
  finishTime = 0
  lapStart = 0
  lapTimes: number[] = []
  best = Infinity
  wreckT = 0
  invuln = 0
  scrape = 0
  scrapeSide = 0
  throttle = 0
  steerNow = 0
  lastInput: Input = { throttle: 0, brake: 0, steer: 0, abL: 0, abR: 0, turbo: false }
  mistake = 0
  rank = 1
  padsHit = 0
  sparkSide = 0
  finalSaid = false
  ai = false
}

const NAMES = ['Kira', 'Rex', 'Nyx', 'Vega', 'Juno', 'Axel', 'Zed', 'Mako', 'Sora', 'Hiro', 'Luna', 'Dax', 'Rin', 'Kane', 'Ivo', 'Tess']

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v))

export class Sim {
  track: Track
  p: RaceParams
  ships: Ship[] = []
  state: 'demo' | 'countdown' | 'racing' | 'finished' = 'demo'
  time = 0
  count = 3.99
  events: RaceEvent[] = []
  player!: Ship
  private seedN = 1
  private afterFinish = 0
  private gasHeld = 0
  results: Ship[] = []

  constructor(track: Track, p: RaceParams) {
    this.track = track
    this.p = p
    this.setup('demo')
  }

  setTrack(track: Track) {
    this.track = track
  }

  top(): number {
    return CLASS_TOP[clamp(Math.round(this.p.shipClass), 0, 3)]
  }

  topFor(ship: Ship): number {
    return this.top() * getVehicleStats(ship.skin).speed
  }

  syncVehicleSelections() {
    for (const ship of this.ships) ship.skin = vehicleForRacer(this.p.skin, this.p.botSkins, ship.id)
  }

  /** put everybody on the grid. mode 'demo' = everyone is driven by the computer */
  setup(mode: 'demo' | 'countdown') {
    const t = this.track
    const n = 1 + clamp(Math.round(this.p.bots), 0, 15)
    this.ships = []
    this.events.length = 0
    this.time = 0
    this.count = 3.99
    this.afterFinish = 0
    this.results = []
    this.gasHeld = 0
    for (let i = 0; i < n; i++) {
      const sh = new Ship()
      sh.id = i
      sh.isPlayer = i === 0
      sh.ai = i !== 0 || mode === 'demo'
      sh.name = i === 0 ? 'Kamu' : NAMES[(i * 5 + 3) % NAMES.length]
      sh.color = i
      sh.skill = i === 0 ? 0.7 : clamp(this.p.botSkill + (Math.sin(i * 12.9898) * 0.5) * 0.25, 0.05, 1)
      sh.lane = (Math.sin(i * 78.233) * 0.5) * t.halfW * 0.5
      const row = Math.floor(i / 2)
      const col = i % 2 === 0 ? -1 : 1
      sh.dist = -(14 + row * 12 + (col > 0 ? 5 : 0))
      sh.x = col * t.halfW * 0.28
      sh.s = mod(sh.dist, t.L)
      sh.shield = this.p.shieldMax
      sh.energy = 0.5
      sh.invuln = 1
      this.ships.push(sh)
    }
    this.player = this.ships[0]
    this.syncVehicleSelections()
    // the player's grid slot depends on nothing: start mid-pack-front so racing starts exciting
    this.state = mode
    this.seedN++
  }

  startRace() {
    this.setup('countdown')
  }

  finishedAll() {
    return this.ships.every((s) => s.finished)
  }

  ranking(): Ship[] {
    const list = this.ships.slice()
    list.sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime
      if (a.finished) return -1
      if (b.finished) return 1
      return b.dist - a.dist
    })
    list.forEach((s, i) => (s.rank = i + 1))
    return list
  }

  // ── Smart AI pilot: multi-horizon braking, out-in-out apex line, pad hunting, repair awareness & tactical turbo
  private aiInput(b: Ship): Input {
    const t = this.track
    const p = this.p
    const skill = b.skill
    const profile = getVehicleStats(b.skin)
    const top = this.topFor(b) * (0.91 + 0.095 * skill) * (b.isPlayer ? 1 : 0.992)
    let rub = 1
    if (p.rubber > 0 && !b.isPlayer && this.state === 'racing') {
      const gap = this.player.dist - b.dist
      rub = 1 + p.rubber * 0.1 * clamp(gap / 380, -1, 1)
    }
    const vTop = top * rub

    // Multi-point braking curve: calculates exact safe entry speed for every upcoming curve point
    const look = b.v * 1.15 + 35
    const aLat = (64 + 54 * skill) * profile.steering
    let vDes = vTop
    let cmax = 0
    for (let k = 1; k <= 8; k++) {
      const d = (look * k) / 8
      const c = Math.abs(t.curvAt(b.s + d))
      cmax = Math.max(cmax, c)
      const vCorner = Math.sqrt(aLat / (c + 8e-5))
      const vBrake = Math.sqrt(vCorner * vCorner + 2 * 95 * Math.max(0, d - 14))
      vDes = Math.min(vDes, vBrake)
    }
    const err = b.v - vDes
    const throttle = err < 2 ? 1 : err < 14 ? 0.35 : 0
    const brake = err > 10 ? clamp((err - 10) / 36, 0, 1) : 0

    // Out-in-out racing line: position wide on corner entry, clip inside apex cleanly, open throttle early on exit
    const cNear = t.curvAt(b.s + b.v * 0.35 + 14)
    const cFar = t.curvAt(b.s + b.v * 0.85 + 32)
    const apex = clamp(cNear * 820, -0.72, 0.72) * t.halfW * (0.45 + 0.55 * skill)
    const entrySetup = Math.abs(cNear) < 0.0005 ? -clamp(cFar * 340, -0.28, 0.28) * t.halfW * skill : 0
    let tx = b.lane * (1 - skill * 0.55) + apex + entrySetup

    // Seek repair strip when shield is critically low
    const rep = t.repair
    const toRep = mod(rep.s0 - b.s, t.L)
    if (skill > 0.35 && b.shield < p.shieldMax * 0.42 && (toRep < 110 || (b.s >= rep.s0 && b.s <= rep.s1))) {
      tx = rep.side * (t.halfW - 4.2)
    } else if (skill > 0.3) {
      // Score and capture the best reachable boost pad ahead
      let bestPadScore = 0
      for (const pad of t.pads) {
        const ahead = mod(pad.s - b.s, t.L)
        if (ahead > 5 && ahead < 165) {
          const reach = t.halfW * (0.48 + 0.42 * skill)
          const latErr = Math.abs(pad.x - b.x)
          if (latErr < reach) {
            const score = (1 - ahead / 170) * (1 - latErr / (reach + 8))
            if (score > bestPadScore) {
              bestPadScore = score
              tx = tx * 0.18 + pad.x * 0.82
            }
          }
        }
      }
    }

    // Smart overtaking: choose the wider side around slower craft ahead instead of bumping their tail
    for (const o of this.ships) {
      if (o === b || o.wreckT > 0 || o.flyH > 4) continue
      const ds = o.dist - b.dist
      if (ds > -2 && ds < 44 && b.v >= o.v - 6) {
        const latGap = Math.abs(o.x - b.x)
        if (latGap < 4.6) {
          const roomRight = (t.halfW - 3.6) - o.x
          const roomLeft = o.x - (-t.halfW + 3.6)
          const passDir = roomRight > roomLeft + 3 ? 1 : roomLeft > roomRight + 3 ? -1 : b.x >= o.x ? 1 : -1
          tx = clamp(o.x + passDir * 5.2, -t.halfW + 3.4, t.halfW - 3.4)
        }
      }
    }
    const safeWall = t.halfW - (3.0 + (1 - skill) * 1.1)
    tx = clamp(tx, -safeWall, safeWall)

    // Subtle human imperfection only for lower-skill bots
    b.mistake += (Math.sin(this.time * (1.2 + b.id * 0.19) + b.id) - b.mistake) * 0.04
    const wob = b.mistake * Math.pow(1 - skill, 1.4) * 0.28
    const steerAccel = 105 * p.steerGain * profile.steering
    const ff = (t.curvAt(b.s + b.v * 0.18) * b.v * b.v * (0.55 - 0.4 * p.assist)) / steerAccel
    const steer = clamp((tx - b.x) * (0.15 + 0.05 * skill) - b.vx * 0.075 + ff + wob, -1, 1)

    // Airbrake assist on very sharp bends for skilled pilots
    const needAb = skill > 0.55 && Math.abs(cNear) > 0.0022 && Math.abs(steer) > 0.82
    const abL = needAb && steer < 0 ? 0.65 : 0
    const abR = needAb && steer > 0 ? 0.65 : 0

    // Tactical turbo: uphill climbs, corner exits onto straights, or final sprint to finish!
    const fr = t.frame(b.s, FR)
    const uphill = fr.ty > 0.08
    const remDist = p.laps * t.L - b.dist
    const finalSprint = this.state === 'racing' && remDist > 0 && remDist < 420 && b.energy > 0.12
    const straightExit = cmax < 0.00095 && Math.abs(tx - b.x) < t.halfW * 0.45
    const turbo =
      this.state === 'racing' &&
      skill > 0.28 &&
      (finalSprint ||
        (straightExit && uphill && b.energy > 0.35) ||
        (straightExit && b.energy > (0.68 - skill * 0.2) && b.v > top * 0.72) ||
        (b.turboOn && straightExit && b.energy > 0.24))
    return { throttle, brake, steer, abL, abR, turbo }
  }

  // ── one ship, one step
  private stepShip(sh: Ship, inp: Input, dt: number) {
    const t = this.track
    const p = this.p
    if (sh.wreckT > 0) {
      sh.wreckT -= dt
      sh.v = 0
      sh.vx = 0
      sh.vy = 0
      sh.flying = false
      sh.flyH = Math.max(0, sh.flyH - 25 * dt)
      if (sh.wreckT <= 0) {
        sh.shield = p.shieldMax * 0.6
        sh.x = 0
        sh.flyH = 0
        sh.invuln = 2.5
        sh.boostT = 0
      }
      return
    }
    sh.invuln = Math.max(0, sh.invuln - dt)
    sh.boostT = Math.max(0, sh.boostT - dt)
    const frozen = this.state === 'countdown'
    const profile = getVehicleStats(sh.skin)
    const top = this.topFor(sh) * (sh.isPlayer || !sh.ai ? 1 : (0.9 + 0.1 * sh.skill) * 0.985)
    // turbo
    const wantTurbo = inp.turbo && sh.energy > 0.001 && !frozen
    sh.turboOn = wantTurbo && sh.v > 15
    if (sh.turboOn && p.turboDrain > 0) sh.energy = clamp(sh.energy - p.turboDrain * profile.turboDrain * dt, 0, 1)
    else if (!sh.turboOn) sh.energy = clamp(sh.energy + p.turboRegen * dt, 0, 1)
    if (p.turboDrain <= 0) sh.energy = 1
    const boosting = sh.turboOn || sh.boostT > 0
    const topNow = top * (sh.boostT > 0 ? 1.3 : 1) * (sh.turboOn ? 1.28 : 1)
    const fr = t.frame(sh.s, FR)
    // forward speed
    let a = 0
    const thr = frozen ? 0 : inp.throttle
    const ratio = clamp(sh.v / topNow, 0, 1.3)
    a += thr * 88 * p.accelGain * profile.acceleration * (boosting ? 2.3 : 1) * (1 - ratio * ratio)
    a -= 9.8 * 0.9 * fr.ty // hills pull back / push forward
    if (!thr) a -= 8
    a -= inp.brake * 120
    a -= (inp.abL + inp.abR) * 38 * p.airbrake
    if (sh.v > topNow) a -= (sh.v - topNow) * 1.3
    sh.v = Math.max(0, sh.v + a * dt)
    // lateral
    const steerAccel = 105 * p.steerGain * profile.steering + (inp.abL > 0 && inp.steer < 0 ? 38 * inp.abL * p.airbrake : 0) + (inp.abR > 0 && inp.steer > 0 ? 38 * inp.abR * p.airbrake : 0)
    const cf = 0.55 - 0.4 * p.assist
    const axc = -fr.curv * sh.v * sh.v * cf
    sh.vx += (axc + steerAccel * inp.steer * (frozen ? 0 : 1) - 2.3 * profile.grip * sh.vx) * dt
    sh.x += sh.vx * dt
    sh.steerNow += (inp.steer - sh.steerNow) * (1 - Math.exp(-dt * 8))
    sh.throttle = thr
    // ── N-key Anti-Gravity Flight Mode in Track space
    const wantFly = !!inp.fly && !frozen && !sh.ai
    if (wantFly !== sh.flying) {
      sh.flying = wantFly
      if (wantFly) {
        sh.flyVy = Math.max(sh.flyVy, 24)
        sh.v = Math.max(sh.v, top * 0.38)
        if (sh.isPlayer) this.events.push({ type: 'flyOn', id: sh.id })
      } else if (sh.isPlayer) {
        this.events.push({ type: 'flyOff', id: sh.id })
      }
    }
    const climbCmd = sh.flying ? clamp(inp.climb || 0, -1, 1) : 0
    sh.climbNow += (climbCmd - sh.climbNow) * (1 - Math.exp(-dt * 9))
    const wasAir = sh.flyH > 0.6
    if (sh.flying) {
      const targetVy = climbCmd * 38 + (sh.flyH < 12 && climbCmd >= -0.05 ? (14 - sh.flyH) * 1.4 : 0)
      sh.flyVy += (targetVy - sh.flyVy) * (1 - Math.exp(-dt * 6.5))
      sh.flyH = clamp(sh.flyH + sh.flyVy * dt, 2.2, 135)
      if (sh.flyH >= 134.5 && sh.flyVy > 0) sh.flyVy = 0
      if (sh.v < top * 0.42 && inp.brake < 0.2) sh.v += 55 * dt
    } else if (sh.flyH > 0 || sh.flyVy > 0) {
      sh.flyVy -= 36 * dt
      sh.flyH += sh.flyVy * dt
      if (sh.flyH <= 0) {
        const downSpd = -sh.flyVy
        sh.flyH = 0
        sh.flyVy = 0
        if (wasAir && downSpd > 5) {
          const imp = clamp(downSpd / 28, 0.25, 1.45)
          sh.landImpact = Math.max(sh.landImpact, imp)
          if (sh.isPlayer) this.events.push({ type: 'land', id: sh.id, v: imp })
        }
      }
    }
    sh.landImpact = Math.max(0, sh.landImpact - dt * 2.8)
    sh.vy = sh.flyVy
    sh.airborne = sh.flyH > 0.7
    const goalPitch = sh.airborne ? clamp(Math.atan2(sh.flyVy, Math.max(38, sh.v)) * 1.15 + sh.climbNow * 0.14, -0.52, 0.55) : clamp(fr.ty * 0.55, -0.35, 0.35)
    sh.pitch += (goalPitch - sh.pitch) * (1 - Math.exp(-dt * 8))

    // walls (generous sky corridor when flying high above barriers)
    const lim = sh.flyH > 5.5 ? t.halfW * 2.4 : t.halfW - 1.7
    sh.scrape = Math.max(0, sh.scrape - dt * 6)
    if (Math.abs(sh.x) > lim) {
      const side = Math.sign(sh.x)
      const into = Math.abs(sh.vx)
      const hit = into > 4 && sh.vx * side > 0
      sh.x = side * lim
      if (hit) {
        sh.vx = -sh.vx * 0.3
        const sev = clamp(into / 30, 0, 1.5)
        sh.v *= 1 - 0.08 * sev
        if (sh.invuln <= 0) sh.shield -= (6 + 14 * sev) * p.wallDmg * profile.damage
        this.events.push({ type: 'wall', id: sh.id, v: sev, side })
      } else {
        sh.vx = Math.min(0, sh.vx * side) * side
      }
      sh.scrape = 1
      sh.scrapeSide = side
      sh.v = Math.max(0, sh.v - 16 * dt)
      if (sh.invuln <= 0) sh.shield -= 1.5 * p.wallDmg * profile.damage * dt * (sh.v / 80)
    }
    // yaw for looks
    const prevYaw = sh.yaw
    const targetYaw = Math.atan2(sh.vx, Math.max(30, sh.v)) * 1.1 + sh.steerNow * 0.22
    sh.yaw += (targetYaw - sh.yaw) * (1 - Math.exp(-dt * 7))
    sh.yawV = (sh.yaw - prevYaw) / Math.max(dt, 1e-4)
    // advance along the road
    const dd = sh.v * dt
    sh.dist += dd
    sh.s = mod(sh.dist, t.L)
    // boost pads
    if (sh.flyH < 3.5) for (const pad of t.pads) {
      const ds = mod(sh.s - pad.s + t.L / 2, t.L) - t.L / 2
      if (ds > -pad.len / 2 && ds < pad.len / 2 && Math.abs(sh.x - pad.x) < pad.w / 2 + 1) {
        if (sh.boostT < 0.9) {
          sh.boostT = 1.7
          sh.v = Math.max(sh.v, Math.min(topNow * 1.1, sh.v + 22 * p.padPower))
          sh.energy = clamp(sh.energy + 0.2, 0, 1)
          sh.padsHit++
          this.events.push({ type: 'pad', id: sh.id })
        }
      }
    }
    // repair strip
    const r = t.repair
    if (sh.s > r.s0 && sh.s < r.s1 && sh.x * r.side > t.halfW - 10 && sh.shield < p.shieldMax) {
      sh.shield = Math.min(p.shieldMax, sh.shield + 22 * dt)
      if (sh.isPlayer && Math.random() < dt * 3) this.events.push({ type: 'repair', id: sh.id })
    }
    // wrecked
    if (sh.shield <= 0 && sh.wreckT <= 0) {
      sh.wreckT = 2.4
      sh.shield = 0
      this.events.push({ type: 'wreck', id: sh.id })
    }
    // laps
    if (!sh.finished && sh.dist >= 0) {
      const lap = Math.min(Math.floor(sh.dist / t.L) + 1, p.laps + 1)
      if (lap > sh.lap) {
        if (sh.lap >= 1) {
          const lt = this.time - sh.lapStart
          sh.lapTimes.push(lt)
          sh.best = Math.min(sh.best, lt)
          if (sh.isPlayer && lap <= p.laps) this.events.push({ type: 'lap', id: sh.id, n: sh.lap, v: lt })
        }
        sh.lapStart = this.time
        sh.lap = lap
        if (lap === p.laps && sh.isPlayer && p.laps > 1) this.events.push({ type: 'final', id: sh.id })
      }
      if (sh.dist >= p.laps * t.L) {
        sh.finished = true
        sh.lap = p.laps
        sh.finishTime = this.time
        this.events.push({ type: 'finish', id: sh.id })
        if (sh.isPlayer) sh.ai = true // autopilot takes over after the flag
      }
    }
  }

  step(dt: number, player: Input) {
    dt = Math.min(dt, 0.05)
    const t = this.track
    if (this.state === 'countdown') {
      const before = Math.ceil(this.count)
      this.count -= dt
      if (player.throttle > 0.5) this.gasHeld += dt
      else this.gasHeld = 0
      const after = Math.ceil(this.count)
      if (after !== before && after > 0) this.events.push({ type: 'count', n: after })
      if (this.count <= 0) {
        this.state = 'racing'
        this.time = 0
        this.events.push({ type: 'go' })
        // a perfect launch: gas held just before GO
        const pl = this.player
        if (this.gasHeld > 0.15 && this.gasHeld < 1.2) {
          pl.boostT = 1.4
          pl.v = 12
          this.events.push({ type: 'turbo' })
        }
        for (const s of this.ships) if (s !== pl) { s.v = 6 + s.skill * 8 }
      }
    } else {
      this.time += dt
    }
    // gentle auto-gas for newcomers
    const pin: Input = { ...player }
    if (this.p.autoGas && pin.brake < 0.1) pin.throttle = 1
    for (const sh of this.ships) {
      const inp = sh.ai ? this.aiInput(sh) : pin
      sh.lastInput = inp
      this.stepShip(sh, inp, dt)
    }
    // craft touching craft
    for (let i = 0; i < this.ships.length; i++) {
      const a = this.ships[i]
      if (a.wreckT > 0) continue
      for (let j = i + 1; j < this.ships.length; j++) {
        const b = this.ships[j]
        if (b.wreckT > 0) continue
        if (Math.abs(a.flyH - b.flyH) > 3.2) continue
        let ds = a.dist - b.dist
        if (Math.abs(ds) > 4.2) continue
        const dx = a.x - b.x
        if (Math.abs(dx) > 2.3) continue
        const push = (dx >= 0 ? 1 : -1) * (2.3 - Math.abs(dx))
        a.x += push * 0.5
        b.x -= push * 0.5
        a.vx += push * 7
        b.vx -= push * 7
        const front = ds > 0 ? a : b
        const back = ds > 0 ? b : a
        back.v *= 1 - 0.7 * dt * 4
        front.v += 0.5
        if ((a.isPlayer || b.isPlayer) && Math.random() < 0.2) this.events.push({ type: 'bump', id: a.isPlayer ? a.id : b.id, v: Math.abs(push) })
      }
    }
    // a craft passing the player
    const pl = this.player
    for (const o of this.ships) {
      if (o === pl) continue
      const ds = o.dist - pl.dist
      const prev = (o as any)._pds ?? ds
      if ((prev > 0) !== (ds > 0) && Math.abs(ds) < 40 && Math.abs(o.x - pl.x) < 12) this.events.push({ type: 'pass', id: o.id, v: ds > 0 ? 1 : -1, side: Math.sign(o.x - pl.x) })
      ;(o as any)._pds = ds
    }
    this.ranking()
    if (this.state === 'racing') {
      if (pl.finished) {
        this.afterFinish += dt
        if (this.finishedAll() || this.afterFinish > 18) {
          this.state = 'finished'
          this.results = this.ranking()
        }
      }
    }
    void t
  }
}

const FR = {
  px: 0, py: 0, pz: 0, tx: 0, ty: 0, tz: -1, rx: 1, ry: 0, rz: 0, ux: 0, uy: 1, uz: 0, curv: 0, bank: 0,
}
