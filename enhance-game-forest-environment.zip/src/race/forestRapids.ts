// @ts-nocheck
// Cinematic rainforest river, whitewater rapid & emerald lagoon renderer:
// dual-layer Voronoi-style sunlight caustics, multi-octave flowing normal ripples,
// sky/canopy Fresnel reflection, golden sun-path sparkles, silky whitewater foam,
// smooth water-worn mossy boulders, notched lotus lily pads, blossoms & river mist.
import * as THREE from 'three'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))

function mulberry32(seed) {
  return function () {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function smoothRiverPoints(rawPts, stepMeters = 3.6) {
  if (!rawPts || rawPts.length < 2) return []
  const K = rawPts.length
  const get = (i) => rawPts[clamp(i, 0, K - 1)]
  const dense = []
  for (let k = 0; k < K - 1; k++) {
    const p0 = get(k - 1), p1 = get(k), p2 = get(k + 1), p3 = get(k + 2)
    const segLen = Math.hypot(p2[0] - p1[0], p2[1] - p1[1])
    const sub = Math.max(1, Math.ceil(segLen / stepMeters))
    for (let j = 0; j < sub; j++) {
      const t = j / sub, t2 = t * t, t3 = t2 * t
      const interp = (c) =>
        0.5 * (
          2 * p1[c]
          + (-p0[c] + p2[c]) * t
          + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2
          + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3
        )
      dense.push([interp(0), interp(1), Math.max(3.2, interp(2)), Math.max(0.5, interp(3))])
    }
  }
  dense.push(rawPts[K - 1].slice())
  return dense
}

// Smooth water-worn river boulder with baked wet waterline & mossy top vertex colors!
function makeSmoothRiverBoulderGeometry() {
  const geo = new THREE.IcosahedronGeometry(1, 2)
  const pos = geo.attributes.position
  const col = new Float32Array(pos.count * 3)
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i)
    const n1 = Math.sin(x * 3.1 + z * 2.4) * 0.1 + Math.cos(y * 4.2 - x * 2.7) * 0.08
    const s = 0.94 + n1
    const sy = y > 0 ? 0.68 : 0.52
    pos.setXYZ(i, x * s, y * s * sy, z * s)
    // Dark wet river granite at waterline, warm mineral stone mid, lush velvet moss cap on top!
    const moss = clamp((y - 0.18) / 0.58, 0, 1)
    const wet = clamp(1 - (y + 0.35) / 0.65, 0, 1)
    let r = 0.34, g = 0.37, b = 0.34
    r = r * (1 - moss) + 0.18 * moss
    g = g * (1 - moss) + 0.46 * moss
    b = b * (1 - moss) + 0.16 * moss
    const wetDark = 1 - wet * 0.45
    col[i * 3] = r * wetDark
    col[i * 3 + 1] = g * wetDark
    col[i * 3 + 2] = b * wetDark
  }
  geo.setAttribute('color', new THREE.BufferAttribute(col, 3))
  geo.computeVertexNormals()
  return geo
}

function makeLotusGeometry() {
  const pad = new THREE.CircleGeometry(1, 16, 0.2, Math.PI * 2 - 0.4)
  pad.rotateX(-Math.PI / 2)
  return pad
}

export function buildForestRapids(arena, { fogColor, fogDensity, soft, mistTexture, sunDir, tod = 'day' }) {
  const group = new THREE.Group()
  group.name = 'forest-rivers'
  const rnd = mulberry32(Math.round(arena.opts.seed) * 6311 + 83)

  const skyTint = tod === 'sunset'
    ? new THREE.Color('#ffbe86')
    : tod === 'night'
      ? new THREE.Color('#2c748a')
      : new THREE.Color('#c2f6f0')
  const specTint = tod === 'sunset'
    ? new THREE.Color('#ffd89a')
    : tod === 'night'
      ? new THREE.Color('#a4eeff')
      : new THREE.Color('#fffce8')
  const sunVec = sunDir ? sunDir.clone().normalize() : new THREE.Vector3(0.45, 0.72, 0.35).normalize()

  const uniforms = {
    time: { value: 0 },
    fogColor: { value: new THREE.Color(fogColor) },
    fogDensity: { value: fogDensity },
    soft: { value: soft ? 1 : 0 },
    sunDir: { value: sunVec },
    skyTint: { value: skyTint },
    specTint: { value: specTint },
    nightK: { value: tod === 'night' ? 1 : 0 },
  }

  const waterMaterial = new THREE.ShaderMaterial({
    uniforms,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: `
      attribute vec4 flowInfo;
      uniform float time;
      varying vec2 vUv;
      varying vec4 vFlow;
      varying vec3 vWorld;
      void main(){
        vUv = uv;
        vFlow = flowInfo;
        vec3 p = position;
        float bankFade = sin(clamp(uv.x, 0.0, 1.0) * 3.14159265);
        float wave = sin(uv.y * 5.4 - time * 3.4 * max(0.35, flowInfo.z) + uv.x * 6.5) * 0.095
                   + cos(uv.y * 10.2 - time * 4.8 * max(0.35, flowInfo.z) - uv.x * 8.2) * 0.055;
        p.y += wave * bankFade * (0.55 + flowInfo.y * 1.45);
        vec4 world = modelMatrix * vec4(p, 1.0);
        vWorld = world.xyz;
        gl_Position = projectionMatrix * viewMatrix * world;
      }`,
    fragmentShader: `
      varying vec2 vUv;
      varying vec4 vFlow;
      varying vec3 vWorld;
      uniform float time, fogDensity, soft, nightK;
      uniform vec3 fogColor, sunDir, skyTint, specTint;

      float hash21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
      float noise2(vec2 p){
        vec2 i = floor(p), f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x),
          mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x),
          f.y
        );
      }
      float caustics(vec2 p, float t){
        float a = noise2(p * 1.35 + vec2(t * 0.38, -t * 0.95));
        float b = noise2(p * 1.55 - vec2(t * 0.44, t * 0.78) + 6.1);
        float c = noise2(p * 2.8 + vec2(-t * 0.3, -t * 1.3) + 2.4);
        float r1 = 1.0 - abs(a - b) * 2.5;
        float r2 = 1.0 - abs(b - c) * 2.5;
        return pow(clamp(max(r1, r2 * 0.8), 0.0, 1.0), 2.8);
      }

      void main(){
        float shoreDist = min(vUv.x, 1.0 - vUv.x) * 2.0;
        float edgeAlpha = smoothstep(0.0, 0.14, shoreDist);
        float endAlpha = smoothstep(0.0, 0.05, vFlow.x) * (1.0 - smoothstep(0.95, 1.0, vFlow.x));
        float slope = vFlow.y;
        float fSpeed = vFlow.z;
        float depth = clamp(shoreDist * (0.72 + 0.38 * vFlow.w), 0.0, 1.0);

        float centerFast = 0.72 + 0.38 * sin(clamp(vUv.x, 0.0, 1.0) * 3.14159);
        float scroll = time * fSpeed * (1.2 + slope * 1.6) * centerFast;

        // Multi-scale analytical ripple field & normal estimation for real sparkling water reflections!
        vec2 uv1 = vec2(vUv.x * 8.0 + sin(vUv.y * 1.5) * 0.35, vUv.y * 3.6 - scroll);
        vec2 uv2 = vec2(vUv.x * 21.0 + 4.3, vUv.y * 8.8 - scroll * 1.68);
        vec2 uv3 = vec2(vUv.x * 42.0 - 2.1, vUv.y * 18.0 - scroll * 2.35);
        float w1 = noise2(uv1);
        float w2 = noise2(uv2);
        float w3 = noise2(uv3);
        float w2x = noise2(uv2 + vec2(0.22, 0.0));
        float w2y = noise2(uv2 + vec2(0.0, 0.22));
        float braids = noise2(vec2(vUv.x * 14.0 + (w1 - 0.5) * 1.7, vUv.y * 2.3 - scroll * 1.25));
        float waveMix = w1 * 0.46 + w2 * 0.35 + w3 * 0.19;

        // Crystal shallow amber-emerald -> luminous Plitvice/Kalimantan turquoise -> deep sapphire-jade
        vec3 shallowCol = vec3(0.14, 0.52, 0.42);
        vec3 midTurq    = vec3(0.03, 0.50, 0.49);
        vec3 deepJade   = vec3(0.01, 0.22, 0.27);
        vec3 water = mix(shallowCol, midTurq, smoothstep(0.04, 0.40, depth));
        water = mix(water, deepJade, smoothstep(0.36, 0.94, depth));
        water = mix(water, vec3(0.08, 0.64, 0.58), (w1 * 0.55 + braids * 0.45) * 0.44);

        // Dancing golden-aqua sunlight caustics across the clear shallow riverbed
        float caust = caustics(vec2(vUv.x * 11.5, vUv.y * 5.4), time * max(0.45, fSpeed));
        water += vec3(0.30, 0.52, 0.38) * caust * (1.0 - smoothstep(0.18, 0.88, depth)) * (1.0 - slope * 0.55);

        // True perturbed water normal for lush green canopy & golden sky Fresnel reflection + sun diamond glints!
        vec3 N = normalize(vec3((w2 - w2x) * 1.45 + (w3 - 0.5) * 0.28, 1.0, (w2 - w2y) * 1.45 - (w3 - 0.5) * 0.28));
        vec3 V = normalize(cameraPosition - vWorld);
        vec3 L = normalize(sunDir);
        float fresnel = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 3.4);
        vec3 envRefl = mix(vec3(0.04, 0.30, 0.19), skyTint * 0.72, smoothstep(0.25, 0.78, w1));
        water = mix(water, envRefl, clamp(fresnel * 0.74, 0.08, 0.70));

        vec3 H = normalize(L + V);
        float ndh = max(dot(N, H), 0.0);
        float spec = pow(ndh, 48.0) * 0.78 + pow(ndh, 180.0) * 1.85;
        float glitter = step(0.83, w3 * 0.62 + w2 * 0.38) * pow(ndh, 10.0) * 0.72;
        if (soft < 0.5) { spec = step(0.35, spec) * 0.85; glitter = step(0.25, glitter) * 0.65; }
        water += specTint * (spec + glitter) * (1.0 - slope * 0.3);

        // Enchanted bioluminescent rainforest river glow at night!
        if (nightK > 0.5) {
          water *= 0.56;
          water += vec3(0.05, 0.58, 0.68) * smoothstep(0.58, 0.88, braids) * 0.65;
          water += vec3(0.15, 0.85, 0.75) * caust * 0.35;
        }

        // Silky whitewater rapid ribbons & delicate lapping shore foam
        float rapidCrest = smoothstep(0.55 - slope * 0.24, 0.81 - slope * 0.14, waveMix + braids * 0.18);
        float silkThread = smoothstep(0.68, 0.88, braids * 0.72 + w2 * 0.28) * (0.18 + slope * 0.68);
        float shoreWave = 0.5 + 0.5 * sin(vUv.y * 14.5 - scroll * 1.85 + w1 * 5.2);
        float shoreFoam = (1.0 - smoothstep(0.02, 0.15 + 0.05 * shoreWave, shoreDist)) * (0.4 + 0.32 * w2);
        float totalFoam = clamp(rapidCrest * (0.14 + slope * 0.85) + silkThread + shoreFoam, 0.0, 1.0);
        if (soft < 0.5) totalFoam = floor(totalFoam * 4.0 + 0.5) / 4.0;
        vec3 foamCol = mix(vec3(0.86, 0.99, 0.97), vec3(1.0, 1.0, 0.99), slope);
        if (nightK > 0.5) foamCol *= vec3(0.55, 0.82, 0.92);
        water = mix(water, foamCol, totalFoam);

        float dist = length(vWorld - cameraPosition);
        float fog = 1.0 - exp(-fogDensity * fogDensity * dist * dist);
        water = mix(water, fogColor, clamp(fog, 0.0, 1.0));

        float alpha = edgeAlpha * endAlpha * clamp(0.78 + depth * 0.17 + totalFoam * 0.14, 0.0, 0.95);
        gl_FragColor = vec4(water, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })

  const boulders = []
  const lilyPads = []
  const lotusFlowers = []
  const mist = []

  const riverList = arena.rivers && arena.rivers.length ? arena.rivers : []

  for (const river of riverList) {
    const stepM = river.kind === 'tributary' ? 3.4 : 3.8
    const points = smoothRiverPoints(river.pts, stepM)
    if (points.length < 3) continue
    const rows = points.length
    const columns = river.kind === 'tributary' ? 9 : 13
    const positions = new Float32Array(rows * columns * 3)
    const uv = new Float32Array(rows * columns * 2)
    const flow = new Float32Array(rows * columns * 4)
    const indices = []
    let distance = 0

    for (let i = 0; i < rows; i++) {
      const prev = points[Math.max(0, i - 1)], next = points[Math.min(rows - 1, i + 1)]
      let dx = next[0] - prev[0], dz = next[1] - prev[1]
      const segL = Math.hypot(dx, dz) || 1
      dx /= segL; dz /= segL
      const rx = -dz, rz = dx
      if (i > 0) distance += Math.hypot(points[i][0] - points[i - 1][0], points[i][1] - points[i - 1][1])

      const hPrev = arena.groundAt(prev[0], prev[1])
      const hNext = arena.groundAt(next[0], next[1])
      const rawSlope = (hPrev - hNext) / segL
      const slope = clamp(rawSlope * 2.1 + (river.kind === 'rapid' ? 0.16 : river.kind === 'tributary' ? 0.22 : 0.03), 0, 1)
      const progress = i / (rows - 1)
      const width = points[i][2] * (0.93 + 0.09 * Math.sin(progress * Math.PI * 5 + river.id))
      const chDepth = clamp(points[i][3] / 1.6, 0.25, 1)

      const centerGround = arena.groundAt(points[i][0], points[i][1])
      const leftBank = arena.groundAt(points[i][0] - rx * width * 0.85, points[i][1] - rz * width * 0.85)
      const rightBank = arena.groundAt(points[i][0] + rx * width * 0.85, points[i][1] + rz * width * 0.85)
      const flatWaterY = Math.min(leftBank, rightBank, centerGround + 1.45) + 0.82

      for (let c = 0; c < columns; c++) {
        const u = c / (columns - 1)
        const across = u * 2 - 1
        const x = points[i][0] + rx * across * width
        const z = points[i][1] + rz * across * width
        const gY = arena.groundAt(x, z)
        const lift = river.kind === 'tributary' ? 1.15 : 0.92
        const v = i * columns + c
        positions[v * 3] = x
        positions[v * 3 + 1] = Math.max(gY + lift * (0.65 + 0.35 * (1 - across * across)), flatWaterY)
        positions[v * 3 + 2] = z
        uv[v * 2] = u
        uv[v * 2 + 1] = distance / (river.kind === 'tributary' ? 22 : 34)
        flow[v * 4] = progress
        flow[v * 4 + 1] = slope
        flow[v * 4 + 2] = river.flowSpeed
        flow[v * 4 + 3] = chDepth
        if (i < rows - 1 && c < columns - 1) {
          indices.push(v, v + columns, v + 1, v + 1, v + columns, v + columns + 1)
        }
      }

      // Smooth water-worn mossy granite river boulders + pebble clusters lining riverbanks
      const rockStride = river.kind === 'tributary' ? 5 : 7
      if (i > 2 && i < rows - 2 && i % rockStride === 0 && boulders.length < 1800) {
        for (const side of [-1, 1]) {
          if (rnd() > 0.72) continue
          const bankOff = width * (0.92 + rnd() * 0.28)
          const bx = points[i][0] + rx * side * bankOff
          const bz = points[i][1] + rz * side * bankOff
          const by = arena.groundAt(bx, bz)
          const sz = (river.kind === 'tributary' ? 1.5 : 2.1) + Math.pow(rnd(), 1.6) * 3.4
          boulders.push({ x: bx, y: by + sz * 0.16, z: bz, sx: sz * (1 + rnd() * 0.35), sy: sz * (0.65 + rnd() * 0.3), sz: sz * (0.9 + rnd() * 0.35), rot: rnd() * 6.28, shade: 0.85 + rnd() * 0.3 })
          if (rnd() < 0.65) {
            const cs = sz * (0.4 + rnd() * 0.25)
            const cx2 = bx + (rnd() - 0.5) * sz * 1.9, cz2 = bz + (rnd() - 0.5) * sz * 1.9
            boulders.push({ x: cx2, y: arena.groundAt(cx2, cz2) + cs * 0.14, z: cz2, sx: cs * 1.2, sy: cs * 0.58, sz: cs, rot: rnd() * 6.28, shade: 0.9 + rnd() * 0.25 })
          }
        }
        if (river.kind === 'tributary' && rnd() < 0.42) {
          const midOff = (rnd() - 0.5) * width * 0.85
          const mx = points[i][0] + rx * midOff, mz = points[i][1] + rz * midOff
          const ms = 1.6 + rnd() * 2.4
          boulders.push({ x: mx, y: arena.groundAt(mx, mz) + 0.52, z: mz, sx: ms * 1.15, sy: ms * 0.82, sz: ms * 0.95, rot: rnd() * 6.28, shade: 0.82 })
        }
      }

      if (slope > 0.35 && i % 15 === 0 && mist.length < 80) {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({
          map: mistTexture,
          color: tod === 'sunset' ? '#ffe6ce' : '#ebfffa',
          transparent: true,
          opacity: 0.15,
          depthWrite: false,
        }))
        const sc = 26 + rnd() * 20
        sp.position.set(points[i][0] + (rnd() - 0.5) * width * 0.6, centerGround + 4.4 + rnd() * 3.5, points[i][1] + (rnd() - 0.5) * width * 0.6)
        sp.scale.setScalar(sc)
        group.add(sp)
        mist.push({ sprite: sp, size: sc, phase: rnd() * 6.28 })
      }
    }

    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
    geometry.setAttribute('flowInfo', new THREE.BufferAttribute(flow, 4))
    geometry.setIndex(indices)
    geometry.computeBoundingSphere()
    const mesh = new THREE.Mesh(geometry, waterMaterial)
    mesh.name = `river-${river.kind}-${river.id}`
    mesh.renderOrder = 4
    group.add(mesh)

    if (river.kind === 'rapid' || river.kind === 'tributary') {
      const bottom = points[points.length - 1]
      const count = river.kind === 'rapid' ? 4 : 2
      for (let m = 0; m < count && mist.length < 95; m++) {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({
          map: mistTexture,
          color: tod === 'sunset' ? '#ffe5cc' : '#e8fff7',
          transparent: true,
          opacity: river.kind === 'rapid' ? 0.18 : 0.12,
          depthWrite: false,
        }))
        const sc = (river.kind === 'rapid' ? 32 : 20) + m * 7
        sp.position.set(bottom[0] + (m - 1) * 9, arena.groundAt(bottom[0], bottom[1]) + 4.8 + m * 2, bottom[1] + (rnd() - 0.5) * 10)
        sp.scale.setScalar(sc)
        group.add(sp)
        mist.push({ sprite: sp, size: sc, phase: m * 1.7 + river.id })
      }
    }
  }

  // Build serene crystal turquoise lagoons with floating lotus pads & blossoms
  const lagoons = arena.lagoons || []
  for (let li = 0; li < lagoons.length; li++) {
    const lg = lagoons[li]
    const rings = 10, segs = 38
    const totalV = 1 + rings * segs
    const positions = new Float32Array(totalV * 3)
    const uv = new Float32Array(totalV * 2)
    const flow = new Float32Array(totalV * 4)
    const indices = []
    const cs = Math.cos(lg.rot), sn = Math.sin(lg.rot)
    const baseLevel = Math.max(lg.y, arena.groundAt(lg.x, lg.z) + 1.25)

    positions[0] = lg.x; positions[1] = baseLevel; positions[2] = lg.z
    uv[0] = 0.5; uv[1] = 0
    flow[0] = 0.5; flow[1] = 0.03; flow[2] = 0.4; flow[3] = 1.0

    for (let r = 1; r <= rings; r++) {
      const rf = r / rings
      for (let s = 0; s < segs; s++) {
        const ang = (s / segs) * Math.PI * 2
        const wob = 1 + 0.11 * Math.sin(ang * 3 + li * 1.7) + 0.06 * Math.cos(ang * 5 - li)
        const lx = Math.cos(ang) * lg.rx * rf * wob
        const lz = Math.sin(ang) * lg.rz * rf * wob
        const wx = lg.x + lx * cs - lz * sn
        const wz = lg.z + lx * sn + lz * cs
        const gy = arena.groundAt(wx, wz)
        const v = 1 + (r - 1) * segs + s
        positions[v * 3] = wx
        positions[v * 3 + 1] = Math.max(baseLevel, gy + 0.72 * (1 - rf * 0.45))
        positions[v * 3 + 2] = wz
        uv[v * 2] = 0.5 * (1 - rf)
        uv[v * 2 + 1] = (wx * cs + wz * sn) / 28
        flow[v * 4] = 0.5; flow[v * 4 + 1] = 0.03; flow[v * 4 + 2] = 0.42; flow[v * 4 + 3] = 1 - rf * 0.7
      }
    }
    for (let s = 0; s < segs; s++) indices.push(0, 1 + s, 1 + ((s + 1) % segs))
    for (let r = 1; r < rings; r++) {
      const bA = 1 + (r - 1) * segs, bB = 1 + r * segs
      for (let s = 0; s < segs; s++) {
        const s2 = (s + 1) % segs
        indices.push(bA + s, bB + s, bA + s2, bA + s2, bB + s, bB + s2)
      }
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2))
    geo.setAttribute('flowInfo', new THREE.BufferAttribute(flow, 4))
    geo.setIndex(indices)
    geo.computeBoundingSphere()
    const mesh = new THREE.Mesh(geo, waterMaterial)
    mesh.renderOrder = 4
    group.add(mesh)

    const clusters = 5 + Math.floor(rnd() * 4)
    for (let cl = 0; cl < clusters; cl++) {
      const ang = rnd() * Math.PI * 2, rf = 0.55 + rnd() * 0.3
      const cx0 = lg.x + Math.cos(ang) * lg.rx * rf * cs - Math.sin(ang) * lg.rz * rf * sn
      const cz0 = lg.z + Math.cos(ang) * lg.rx * rf * sn + Math.sin(ang) * lg.rz * rf * cs
      for (let p = 0; p < 5 + Math.floor(rnd() * 4); p++) {
        const px = cx0 + (rnd() - 0.5) * 9, pz = cz0 + (rnd() - 0.5) * 9
        const py = Math.max(baseLevel, arena.groundAt(px, pz) + 0.65) + 0.12
        const ps = 1.2 + rnd() * 1.4
        lilyPads.push({ x: px, y: py, z: pz, s: ps, rot: rnd() * 6.28, tint: rnd() < 0.5 ? '#3b8c42' : '#58a848' })
        if (rnd() < 0.42) {
          lotusFlowers.push({ x: px, y: py + 0.25, z: pz, s: ps * 0.4, rot: rnd() * 6.28, tint: rnd() < 0.55 ? '#ff94c4' : rnd() < 0.85 ? '#fff8ec' : '#ffd86b' })
        }
      }
    }
    for (let b = 0; b < 10 && boulders.length < 1900; b++) {
      const ang = (b / 10) * Math.PI * 2 + rnd() * 0.35
      const bx = lg.x + Math.cos(ang) * lg.rx * (0.94 + rnd() * 0.15) * cs - Math.sin(ang) * lg.rz * (0.94 + rnd() * 0.15) * sn
      const bz = lg.z + Math.cos(ang) * lg.rx * (0.94 + rnd() * 0.15) * sn + Math.sin(ang) * lg.rz * (0.94 + rnd() * 0.15) * cs
      const sz = 2.2 + rnd() * 3.5
      boulders.push({ x: bx, y: arena.groundAt(bx, bz) + sz * 0.18, z: bz, sx: sz * 1.25, sy: sz * 0.7, sz: sz * 0.98, rot: rnd() * 6.28, shade: 0.86 + rnd() * 0.26 })
    }
  }

  const m4 = new THREE.Matrix4()
  const pos = new THREE.Vector3(), scl = new THREE.Vector3()
  const quat = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0), col = new THREE.Color()

  if (boulders.length) {
    const stoneGeo = makeSmoothRiverBoulderGeometry()
    const stoneMat = new THREE.MeshStandardMaterial({ color: '#ffffff', vertexColors: true, roughness: 0.62, metalness: 0.05 })
    const mesh = new THREE.InstancedMesh(stoneGeo, stoneMat, boulders.length)
    boulders.forEach((rk, i) => {
      quat.setFromAxisAngle(up, rk.rot)
      m4.compose(pos.set(rk.x, rk.y, rk.z), quat, scl.set(rk.sx, rk.sy, rk.sz))
      mesh.setMatrixAt(i, m4)
      col.setScalar(rk.shade)
      mesh.setColorAt(i, col)
    })
    mesh.instanceMatrix.needsUpdate = true
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true
    mesh.frustumCulled = false
    group.add(mesh)
  }

  if (lilyPads.length) {
    const padGeo = makeLotusGeometry()
    const padMat = new THREE.MeshLambertMaterial({ color: '#ffffff', side: THREE.DoubleSide })
    const mesh = new THREE.InstancedMesh(padGeo, padMat, lilyPads.length)
    lilyPads.forEach((lp, i) => {
      quat.setFromAxisAngle(up, lp.rot)
      m4.compose(pos.set(lp.x, lp.y, lp.z), quat, scl.set(lp.s, 1, lp.s))
      mesh.setMatrixAt(i, m4)
      mesh.setColorAt(i, col.set(lp.tint))
    })
    mesh.frustumCulled = false
    group.add(mesh)
  }

  if (lotusFlowers.length) {
    const flGeo = new THREE.SphereGeometry(1, 10, 8)
    const flMat = new THREE.MeshBasicMaterial({ color: '#ffffff' })
    const mesh = new THREE.InstancedMesh(flGeo, flMat, lotusFlowers.length)
    lotusFlowers.forEach((lf, i) => {
      quat.setFromAxisAngle(up, lf.rot)
      m4.compose(pos.set(lf.x, lf.y, lf.z), quat, scl.set(lf.s, lf.s * 0.65, lf.s))
      mesh.setMatrixAt(i, m4)
      mesh.setColorAt(i, col.set(lf.tint))
    })
    mesh.frustumCulled = false
    group.add(mesh)
  }

  return {
    group,
    info: {
      rapids: arena.rapids.map((r) => ({ ...r })),
      riverCount: riverList.length,
      lagoonCount: lagoons.length,
    },
    update(time) {
      uniforms.time.value = time
      for (const m of mist) m.sprite.scale.setScalar(m.size * (1 + 0.09 * Math.sin(time * 0.85 + m.phase)))
    },
    dispose() {
      const geometries = new Set(), materials = new Set()
      group.traverse((object) => {
        if (object.geometry && !object.isSprite) geometries.add(object.geometry)
        if (object.material) materials.add(object.material)
      })
      geometries.forEach((geometry) => geometry.dispose())
      materials.forEach((material) => material.dispose())
    },
  }
}
