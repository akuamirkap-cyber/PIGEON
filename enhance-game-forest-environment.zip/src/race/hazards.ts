// @ts-nocheck
// High-clarity, pole-free sci-fi & elemental Arena Hazard System:
// 1. ROCK     — Sculpted dark-armored boulder outcrop laced with glowing amber/crimson energy crystals
//               + crisp pulsing holographic ground perimeter ring (exact hitbox clarity!).
// 2. ROLLER   — Geodesic obsidian-titanium plasma-crusher sphere with blazing dual equatorial energy
//               bands, rolling visibly along a flush glowing laser guide-rail between its anchors.
// 3. FAN      — Sleek low-profile anti-gravity plasma turbine dome (NO ugly tall pole!) projecting
//               twin blazing crimson-gold laser-plasma blades + 360° ground sweep-radius warning ring.
// 4. GEYSER   — Sculpted volcanic/cryo reactor caldera crater with always-visible simmering core,
//               flashing pre-eruption shock ring, and swirling volumetric plasma/cryo vortex column.
// 5. ROCKWALL — Fractured shortcut barrier wall glowing with cyan-gold energy cracks + floating
//               holographic "⚡ DOBRAK TURBO" target emblem so smashable shortcuts are unmistakable!
import * as THREE from 'three'

const clamp = (v, a, b) => Math.min(b, Math.max(a, v))

function makeSmashBadge() {
  const c = document.createElement('canvas')
  c.width = 320
  c.height = 112
  const g = c.getContext('2d')
  g.clearRect(0, 0, 320, 112)
  g.fillStyle = 'rgba(6, 22, 34, 0.88)'
  g.beginPath()
  g.moveTo(22, 8)
  g.lineTo(298, 8)
  g.lineTo(312, 30)
  g.lineTo(312, 82)
  g.lineTo(298, 104)
  g.lineTo(22, 104)
  g.lineTo(8, 82)
  g.lineTo(8, 30)
  g.closePath()
  g.fill()
  g.strokeStyle = '#38f8ff'
  g.lineWidth = 4
  g.stroke()
  g.fillStyle = '#ffd84a'
  g.font = 'bold 20px ui-monospace, monospace'
  g.textAlign = 'center'
  g.fillText('⚡ JALAN PINTAS ⚡', 160, 36)
  g.fillStyle = '#ffffff'
  g.font = '900 italic 38px ui-sans-serif, system-ui, sans-serif'
  g.fillText('DOBRAK TURBO', 160, 82)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.minFilter = THREE.LinearFilter
  return t
}

function cragRockGeo() {
  const g = new THREE.IcosahedronGeometry(1, 1)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i)
    const k = Math.sin(Math.round(x * 80) * 15.73 + Math.round(y * 80) * 63.11 + Math.round(z * 80) * 29.41) * 43758.5453
    const n = k - Math.floor(k)
    const s = 0.78 + 0.38 * n
    p.setXYZ(i, x * s, y * s, z * s)
  }
  g.computeVertexNormals()
  return g
}

export function buildArenaHazards(arena, { planet, fogDensity }) {
  const group = new THREE.Group()
  group.name = 'arena-hazards'

  const isIce = planet === 'ice'
  const isLava = planet === 'lava'
  const isForest = planet === 'forest'

  const surfaceLift = (x, z) => (arena.riverAt && arena.riverAt(x, z) > 0.38 ? 1.38 : 0.45)

  // Shared high-visibility holographic danger-perimeter ring shader (rotating hazard chevron ticks!)
  const ringUniforms = {
    time: { value: 0 },
    fogD: { value: fogDensity * 0.7 },
  }
  const makeDangerRingMat = (colHex, innerSoft = 0.14) =>
    new THREE.ShaderMaterial({
      uniforms: {
        time: ringUniforms.time,
        fogD: ringUniforms.fogD,
        uCol: { value: new THREE.Color(colHex) },
        uBoost: { value: 1.0 },
        uFill: { value: innerSoft },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      vertexShader: `
        varying vec2 vUv;
        varying vec3 vW;
        void main(){
          vUv = uv;
          vec4 w = modelMatrix * vec4(position, 1.0);
          vW = w.xyz;
          gl_Position = projectionMatrix * viewMatrix * w;
        }`,
      fragmentShader: `
        varying vec2 vUv;
        varying vec3 vW;
        uniform float time, fogD, uBoost, uFill;
        uniform vec3 uCol;
        void main(){
          vec2 p = vUv * 2.0 - 1.0;
          float r = length(p);
          if (r > 1.0) discard;
          float ang = atan(p.y, p.x);
          // Crisp outer perimeter ring + dashed rotating sci-fi hazard ticks
          float outer = smoothstep(0.08, 0.0, abs(r - 0.91));
          float dash = step(0.32, fract(ang * 2.54648 - time * 0.85)); // 16 crisp hazard dashes
          float inner = smoothstep(0.055, 0.0, abs(r - 0.78)) * dash * 0.85;
          float pulse = 0.78 + 0.22 * sin(time * 4.5 - r * 5.0);
          float disc = (1.0 - smoothstep(0.0, 0.92, r)) * uFill * pulse;
          float d = length(vW - cameraPosition);
          float fade = exp(-fogD * fogD * d * d) * (1.0 - smoothstep(420.0, 760.0, d));
          float a = clamp((outer * 0.9 + inner + disc) * uBoost * fade, 0.0, 0.95);
          if (a < 0.012) discard;
          vec3 c = mix(uCol, vec3(1.0, 0.96, 0.88), outer * 0.42);
          gl_FragColor = vec4(c * a, a);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`,
    })

  // Shared swirling volumetric geyser plasma/cryo vortex shader!
  const vortexUniforms = {
    time: { value: 0 },
    fogD: { value: fogDensity * 0.7 },
    cBase: { value: new THREE.Color(isIce ? '#00b8ff' : isForest ? '#18f0d8' : '#ff3c08') },
    cHot: { value: new THREE.Color(isIce ? '#e4fcff' : isForest ? '#d6fff8' : '#fff088') },
  }
  const vortexMat = new THREE.ShaderMaterial({
    uniforms: vortexUniforms,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vW;
      void main(){
        vUv = uv;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      varying vec2 vUv;
      varying vec3 vW;
      uniform float time, fogD;
      uniform vec3 cBase, cHot;
      void main(){
        // Helical upward-roaring plasma/cryo vortex ribbons!
        float spiral1 = 0.5 + 0.5 * sin(vUv.x * 25.1327 + vUv.y * 14.0 - time * 15.0);
        float spiral2 = 0.5 + 0.5 * cos(vUv.x * 18.8495 - vUv.y * 20.0 + time * 19.0);
        float energy = pow(spiral1 * 0.6 + spiral2 * 0.4, 1.35);
        float vFade = smoothstep(0.0, 0.08, vUv.y) * pow(1.0 - vUv.y, 0.85);
        vec3 col = mix(cBase, cHot, clamp(energy * 0.85 + (1.0 - vUv.y) * 0.45, 0.0, 1.0));
        float d = length(vW - cameraPosition);
        float a = clamp((0.36 + 0.64 * energy) * vFade * exp(-fogD * fogD * d * d), 0.0, 0.96);
        if (a < 0.012) discard;
        gl_FragColor = vec4(col * a * 1.35, a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })

  // Shared glowing roller-track rail shader
  const trackRailMat = new THREE.ShaderMaterial({
    uniforms: { time: ringUniforms.time, fogD: ringUniforms.fogD },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    vertexShader: 'varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
    fragmentShader: `
      varying vec2 vUv; varying vec3 vW; uniform float time, fogD;
      void main(){
        float ay = abs(vUv.y * 2.0 - 1.0);
        float rails = smoothstep(0.14, 0.0, abs(ay - 0.78));
        // Bidirectional warning chevrons along roller lane
        float stripe = smoothstep(0.32, 0.52, abs(fract(vUv.x - ay * 0.35) - 0.5)) * (1.0 - smoothstep(0.55, 0.75, ay)) * 0.42;
        float pulse = 0.72 + 0.28 * sin(time * 5.0 + vUv.x * 2.0);
        vec3 col = mix(vec3(1.0, 0.24, 0.14), vec3(1.0, 0.78, 0.18), stripe * 1.6);
        float d = length(vW - cameraPosition);
        float fade = exp(-fogD * fogD * d * d) * (1.0 - smoothstep(420.0, 760.0, d));
        float endF = smoothstep(0.0, 0.05, vUv.x) * (1.0 - smoothstep(0.95, 1.0, vUv.x));
        float a = clamp((rails * 0.78 + stripe) * pulse * endF * fade, 0.0, 0.9);
        if (a < 0.012) discard;
        gl_FragColor = vec4(col * a, a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  })

  // High-contrast sculpted materials (intentionally distinct from surrounding canyon rock/snow/grass!)
  const rockGeo = cragRockGeo()
  const crystalGeo = new THREE.ConeGeometry(0.45, 1.6, 5).translate(0, 0.7, 0)
  const planeGeo = new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2)

  const boulderPrimary = new THREE.MeshStandardMaterial({
    color: isIce ? '#1b3558' : isLava ? '#1d1620' : isForest ? '#38423a' : '#4a2622',
    roughness: 0.55,
    metalness: 0.25,
  })
  const boulderAccent = new THREE.MeshStandardMaterial({
    color: isIce ? '#2c5482' : isLava ? '#341e22' : isForest ? '#4d5c44' : '#6e3428',
    roughness: 0.48,
    metalness: 0.3,
  })
  // Vibrant glowing warning crystal shards embedded in rock obstacles so every boulder pops sharply!
  const crystalWarnMat = new THREE.MeshBasicMaterial({
    color: isIce ? '#ff487a' : isLava ? '#ffcc28' : '#ff6824',
  })
  const alloyDark = new THREE.MeshStandardMaterial({ color: '#182230', roughness: 0.3, metalness: 0.82 })
  const alloyRim = new THREE.MeshStandardMaterial({ color: '#c8d8e8', roughness: 0.26, metalness: 0.72 })
  const plasmaRed = new THREE.MeshBasicMaterial({ color: '#ff3828' })
  const plasmaHot = new THREE.MeshBasicMaterial({ color: '#ffbe38' })
  const plasmaCoreWhite = new THREE.MeshBasicMaterial({ color: '#fff4d8' })
  const smashCrackMat = new THREE.MeshBasicMaterial({ color: '#38f8ff' })
  const smashGoldMat = new THREE.MeshBasicMaterial({ color: '#ffd844' })

  const rockRingMat = makeDangerRingMat(isIce ? '#ff3c6e' : '#ff5424', 0.1)
  const fanRingMat = makeDangerRingMat('#ff3428', 0.06)
  const smashBadgeTex = makeSmashBadge()
  const smashBadgeMat = new THREE.MeshBasicMaterial({ map: smashBadgeTex, transparent: true, side: THREE.DoubleSide, depthWrite: false })

  const bladeGlowMat = new THREE.MeshBasicMaterial({
    color: '#ff3b24',
    transparent: true,
    opacity: 0.52,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  })

  const entries = []

  for (const o of arena.obstacles) {
    const g0 = arena.groundAt(o.x, o.z)
    const lift = surfaceLift(o.x, o.z)
    const grp = new THREE.Group()
    const entry = { o, grp, parts: {} }

    if (o.type === 'rock') {
      // Sculpted dark monolithic crag cluster + blazing mineral crystal spires + ground danger perimeter ring!
      const main = new THREE.Mesh(rockGeo, boulderPrimary)
      main.scale.set(o.r * 1.05, o.r * 1.18, o.r * 0.98)
      main.position.set(0, o.r * 0.62, 0)
      main.rotation.y = o.id * 1.1
      grp.add(main)
      for (const sd of [-1, 1]) {
        const sub = new THREE.Mesh(rockGeo, boulderAccent)
        const s = o.r * 0.62
        sub.scale.set(s * 1.1, s * 0.88, s)
        sub.position.set(sd * o.r * 0.68, s * 0.48, sd * o.r * 0.22)
        sub.rotation.y = o.id * 0.7 + sd
        grp.add(sub)
      }
      // 4 glowing warning crystal shards erupting from the boulder crown (super clear silhouette!)
      for (let c = 0; c < 4; c++) {
        const a = (c / 4) * Math.PI * 2 + o.id * 0.5
        const cr = new THREE.Mesh(crystalGeo, c === 0 ? plasmaHot : crystalWarnMat)
        const cs = o.r * (c === 0 ? 0.58 : 0.42)
        cr.scale.set(cs * 0.55, cs * 1.15, cs * 0.55)
        cr.position.set(Math.cos(a) * o.r * (c === 0 ? 0.1 : 0.48), o.r * (c === 0 ? 0.95 : 0.55), Math.sin(a) * o.r * (c === 0 ? 0.1 : 0.48))
        cr.rotation.set(Math.sin(a) * 0.36, a, -Math.cos(a) * 0.36)
        grp.add(cr)
      }
      // Crisp flush danger circle marking exact collision radius
      const ring = new THREE.Mesh(planeGeo, rockRingMat)
      ring.scale.setScalar(o.r + 2.4)
      ring.position.y = lift + 0.3
      ring.renderOrder = 6
      grp.add(ring)
      grp.position.set(o.x, g0 - 0.3, o.z)
    } else if (o.type === 'roller') {
      // 1. Flush glowing laser guide-rail along the roller's exact travel path (ax,az -> bx,bz)
      const dx = o.bx - o.ax, dz = o.bz - o.az
      const span = Math.hypot(dx, dz) || 1
      const segs = Math.max(8, Math.ceil(span / 8))
      const rPos = new Float32Array((segs + 1) * 2 * 3)
      const rUv = new Float32Array((segs + 1) * 2 * 2)
      const rIdx = []
      const nx = -dz / span, nz = dx / span
      const railHalfW = 3.6
      for (let i = 0; i <= segs; i++) {
        const u = i / segs
        const cx = o.ax + dx * u, cz = o.az + dz * u
        for (let s = 0; s < 2; s++) {
          const sd = s === 0 ? -1 : 1
          const wx = cx + nx * sd * railHalfW
          const wz = cz + nz * sd * railHalfW
          const v = i * 2 + s
          rPos[v * 3] = wx
          rPos[v * 3 + 1] = arena.groundAt(wx, wz) + surfaceLift(wx, wz) + 0.1
          rPos[v * 3 + 2] = wz
          rUv[v * 2] = (u * span) / 10
          rUv[v * 2 + 1] = s
        }
        if (i < segs) {
          const v = i * 2
          rIdx.push(v, v + 2, v + 1, v + 1, v + 2, v + 3)
        }
      }
      const trGeo = new THREE.BufferGeometry()
      trGeo.setAttribute('position', new THREE.BufferAttribute(rPos, 3))
      trGeo.setAttribute('uv', new THREE.BufferAttribute(rUv, 2))
      trGeo.setIndex(rIdx)
      trGeo.computeBoundingSphere()
      const trMesh = new THREE.Mesh(trGeo, trackRailMat)
      trMesh.renderOrder = 6
      group.add(trMesh)

      // 2. Armored Sci-Fi Plasma-Core Crusher Orb (rolls along the track with blazing neon bands!)
      const ball = new THREE.Group()
      const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(o.r * 0.96, 1), alloyDark)
      const band1 = new THREE.Mesh(new THREE.TorusGeometry(o.r * 0.97, 0.58, 8, 28), plasmaRed)
      const band2 = new THREE.Mesh(new THREE.TorusGeometry(o.r * 0.97, 0.45, 8, 28).rotateX(Math.PI / 2), plasmaHot)
      const band3 = new THREE.Mesh(new THREE.TorusGeometry(o.r * 0.98, 0.3, 6, 24).rotateY(Math.PI / 2), alloyRim)
      ball.add(shell, band1, band2, band3)
      grp.add(ball)
      // Moving ground warning shadow-ring right beneath the rolling sphere
      const footRing = new THREE.Mesh(planeGeo, rockRingMat)
      footRing.scale.setScalar(o.r + 2.8)
      footRing.position.y = -o.r + 0.55
      footRing.renderOrder = 6
      grp.add(footRing)
      entry.parts.ball = ball
      entry.parts.rollAxis = Math.atan2(dx, dz)
    } else if (o.type === 'fan') {
      // Sleek Low-Slung Sci-Fi Anti-Gravity Plasma Rotor Sweeper — ZERO TALL POLE!
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 3.8, 2.2, 12), alloyDark)
      ped.position.y = 1.1
      const pedCollar = new THREE.Mesh(new THREE.TorusGeometry(3.1, 0.28, 8, 20).rotateX(Math.PI / 2), plasmaRed)
      pedCollar.position.y = 2.1
      grp.add(ped, pedCollar)

      // Rotating twin laser-plasma rotor assembly at collision height y = 4.5 m
      const rotor = new THREE.Group()
      rotor.position.y = 4.5
      // Central armored reactor hub + glowing dome core (total height only 6.2 m — clean & aerodynamic!)
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(2.8, 3.0, 2.1, 12), alloyDark)
      const hubRim = new THREE.Mesh(new THREE.TorusGeometry(2.95, 0.34, 8, 24).rotateX(Math.PI / 2), alloyRim)
      const coreOrb = new THREE.Mesh(new THREE.SphereGeometry(1.85, 14, 10), plasmaHot)
      coreOrb.position.y = 0.7
      rotor.add(hub, hubRim, coreOrb)

      const halfSpan = o.len * 0.5
      const bladeLen = Math.max(4, halfSpan - 3.2)
      for (const sd of [-1, 1]) {
        // Emitter hilt collar
        const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 1.15, 2.2, 8).rotateZ(Math.PI / 2), alloyRim)
        hilt.position.x = sd * 3.4
        // Blazing white-hot plasma blade core + wide crimson plasma energy aura + glowing tip pod!
        const cx = sd * (3.2 + bladeLen * 0.5)
        const coreBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, bladeLen, 8).rotateZ(Math.PI / 2), plasmaCoreWhite)
        coreBeam.position.x = cx
        const outerBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.88, 0.88, bladeLen, 8).rotateZ(Math.PI / 2), plasmaRed)
        outerBeam.material = bladeGlowMat
        outerBeam.position.x = cx
        const flatBlade = new THREE.Mesh(new THREE.PlaneGeometry(bladeLen, 2.8).rotateX(-Math.PI / 2), bladeGlowMat)
        flatBlade.position.x = cx
        const tipPod = new THREE.Mesh(new THREE.OctahedronGeometry(1.35, 0), plasmaHot)
        tipPod.position.x = sd * halfSpan
        rotor.add(hilt, coreBeam, outerBeam, flatBlade, tipPod)
      }
      grp.add(rotor)

      // Full-radius flush holographic ground circle showing exact blade tip sweep!
      const sweepRing = new THREE.Mesh(planeGeo, fanRingMat)
      sweepRing.scale.setScalar(halfSpan + 1.2)
      sweepRing.position.y = lift
      sweepRing.renderOrder = 6
      grp.add(sweepRing)

      entry.parts.bar = rotor
      grp.position.set(o.x, g0, o.z)
    } else if (o.type === 'geyser') {
      // Sculpted Volcanic / Cryo-Plasma Caldera Vent + Dynamic Countdown Ring + Swirling Vortex Plume!
      const ventOuter = new THREE.Mesh(new THREE.CylinderGeometry(o.r * 0.68, o.r * 0.96, 1.8, 16), alloyDark)
      ventOuter.position.y = 0.7
      const coreGlow = new THREE.Mesh(
        new THREE.CircleGeometry(o.r * 0.58, 18).rotateX(-Math.PI / 2),
        new THREE.MeshBasicMaterial({ color: isIce ? '#38e8ff' : isForest ? '#38ffdc' : '#ff7a18' }),
      )
      coreGlow.position.y = 1.65
      grp.add(ventOuter, coreGlow)

      // Individual warning ring material so each geyser animates its own pre-eruption flash!
      const gRingMat = makeDangerRingMat(isIce || isForest ? '#2ce8ff' : '#ff6818', 0.16)
      const gRing = new THREE.Mesh(planeGeo, gRingMat)
      gRing.scale.setScalar(o.r + 1.5)
      gRing.position.y = lift + 0.12
      gRing.renderOrder = 6
      grp.add(gRing)

      // Swirling double-helix vortex eruption column
      const col = new THREE.Mesh(new THREE.CylinderGeometry(o.r * 0.58, o.r * 0.82, 42, 18, 1, true), vortexMat)
      col.position.y = 21
      col.renderOrder = 6
      const core = new THREE.Mesh(new THREE.CylinderGeometry(o.r * 0.25, o.r * 0.44, 40, 12, 1, true), vortexMat)
      core.position.y = 20
      core.renderOrder = 6
      grp.add(col, core)

      entry.parts.col = col
      entry.parts.core = core
      entry.parts.ringMat = gRingMat
      entry.parts.coreGlow = coreGlow
      grp.position.set(o.x, g0, o.z)
    } else if (o.type === 'rockwall') {
      // Smashable Secret-Shortcut Crystalline Barrier Wall with Blazing Fracture Seams & "⚡ DOBRAK TURBO" Holo-Sign!
      const p = arena.paths[o.path]
      let nearest = 1, distance = Infinity
      for (let i = 1; i < p.pts.length - 1; i++) {
        const d = Math.hypot(p.pts[i][0] - o.x, p.pts[i][1] - o.z)
        if (d < distance) { distance = d; nearest = i }
      }
      const a = p.pts[nearest - 1], b = p.pts[nearest + 1]
      const tx = b[0] - a[0], tz = b[1] - a[1]
      const l = Math.hypot(tx, tz) || 1
      const cnt = Math.max(5, Math.round((o.r * 2) / 7.5))
      for (let k = 0; k < cnt; k++) {
        const u = (k + 0.5) / cnt
        const lx = -o.r + o.r * 2 * u
        const archH = 11.5 + Math.sin(u * Math.PI) * 4.5
        const slab = new THREE.Mesh(rockGeo, k % 2 ? boulderPrimary : boulderAccent)
        slab.scale.set(4.6, archH * 0.65, 3.8)
        slab.position.set(lx, archH * 0.48, (k % 2 - 0.5) * 0.6)
        slab.rotation.set(0.08 * (k % 2 ? 1 : -1), k * 1.3, (u - 0.5) * 0.25)
        grp.add(slab)
        // Glowing cyan-gold fracture fissure seams between every rock slab!
        if (k < cnt - 1) {
          const seam = new THREE.Mesh(
            new THREE.BoxGeometry(0.55, archH * 0.85, 4.3),
            k % 2 === 0 ? smashCrackMat : smashGoldMat,
          )
          seam.position.set(lx + o.r / cnt, archH * 0.48, 0)
          seam.rotation.z = (k % 2 ? 1 : -1) * 0.16
          grp.add(seam)
        }
      }
      // Floating Holographic "⚡ DOBRAK TURBO" target badge right on the wall!
      const badge = new THREE.Mesh(new THREE.PlaneGeometry(18, 6.3), smashBadgeMat)
      badge.position.set(0, 18.5, 0)
      badge.renderOrder = 7
      grp.add(badge)
      entry.parts.badge = badge
      grp.rotation.y = Math.atan2(tx / l, tz / l)
      grp.position.set(o.x, g0 - 0.5, o.z)
    }

    group.add(grp)
    entries.push(entry)
  }

  return {
    group,
    update(time, sim) {
      ringUniforms.time.value = time
      vortexUniforms.time.value = time
      for (const e of entries) {
        const o = e.o
        if (o.type === 'roller') {
          const h = sim.hazard(o, time)
          e.grp.position.set(h.x, arena.groundAt(h.x, h.z) + o.r, h.z)
          const spin = (h.u - 0.5) * 8.5
          e.parts.ball.rotation.set(spin, e.parts.rollAxis, spin * 0.65)
        } else if (o.type === 'fan') {
          e.parts.bar.rotation.y = -(o.phase + o.w * time)
        } else if (o.type === 'geyser') {
          const h = sim.hazard(o, time)
          e.parts.col.visible = h.active
          e.parts.core.visible = h.active
          if (h.active) {
            const s = 0.22 + 0.78 * clamp(h.u * 1.35, 0, 1)
            const wob = 1 + 0.08 * Math.sin(time * 24 + o.id)
            e.parts.col.scale.set(wob, s, wob)
            e.parts.col.position.y = 21 * s
            e.parts.core.scale.set(1, s * 0.94, 1)
            e.parts.core.position.y = 20 * s * 0.94
            e.parts.ringMat.uniforms.uBoost.value = 1.45
            e.parts.coreGlow.scale.setScalar(1.12)
          } else if (h.warn) {
            // Unmistakable rapid high-intensity pre-eruption strobe!
            const flash = 0.9 + 0.85 * Math.abs(Math.sin(time * 22))
            e.parts.ringMat.uniforms.uBoost.value = flash
            e.parts.coreGlow.scale.setScalar(0.95 + 0.22 * Math.sin(time * 26))
          } else {
            e.parts.ringMat.uniforms.uBoost.value = 0.52
            e.parts.coreGlow.scale.setScalar(0.82 + 0.06 * Math.sin(time * 3 + o.id))
          }
        } else if (o.type === 'rockwall') {
          const intact = !sim.isBroken(o)
          e.grp.visible = intact
          if (intact && e.parts.badge) {
            e.parts.badge.position.y = 18.5 + Math.sin(time * 3.2 + o.id) * 0.65
          }
        }
      }
    },
  }
}
