// Arena mode: an open canyon planet, no road. Gates ring the map; between gates the way splits into a wide main
// canyon and (often) a narrow shortcut, some of them sealed with a rock wall you must smash through at speed.
// Hazards move: rolling boulders, spinning bars, fire geysers. Pure maths — no three.js.
import { CLASS_TOP, type Input, type RaceEvent, type RaceParams } from './sim'
import { getVehicleStats, vehicleForRacer, type VehicleId } from './vehicles'

export const Q = 4 // metres per stacked layer

export type ArenaOpts = { seed: number; radius: number; gates: number; width: number; shortcuts: number; hazards: number; pads: number; planet: string; forestRelief?: number }

export type Path = { id: number; seg: number; kind: 'main' | 'cut'; pts: number[][]; halfW: number; len: number; hidden: boolean }
export type Gate = { x: number; z: number; nx: number; nz: number; r: number }
export type Obstacle = {
  id: number
  type: 'rock' | 'roller' | 'fan' | 'geyser' | 'rockwall'
  x: number
  z: number
  r: number
  ax?: number
  az?: number
  bx?: number
  bz?: number
  period: number
  phase: number
  duty: number
  len: number
  w: number
  path: number
  broken: boolean
}
export type ArenaPad = { x: number; z: number; r: number }
export type ForestRapid = { pathId: number; segment: number; startIndex: number; endIndex: number; drop: number }
export type ForestRiver = {
  id: number
  kind: 'rapid' | 'valley' | 'tributary' | 'meander'
  pts: number[][] // [x, z, halfWidth, depth]
  flowSpeed: number
}
export type ForestLagoon = { x: number; z: number; rx: number; rz: number; rot: number; y: number }
export type MountainPeak = { x: number; z: number; y: number; radius: number; kind: 'central' | 'ridge' | 'karst' }

export type Arena = {
  opts: ArenaOpts
  n: number // how many gates
  cells: number // ground columns along one side
  C: number
  ox: number
  oz: number
  size: number
  hgt: Float32Array // ground height in metres per column
  lat: Float32Array // 0 on the middle of a route .. 1 at its edge (beyond: more)
  edge: Float32Array // metres outside the nearest floor
  riverMask: Float32Array // 0 dry .. 0.45 riverbank .. 1 deep channel
  gates: Gate[]
  paths: Path[]
  segs: number[][]
  obstacles: Obstacle[]
  pads: ArenaPad[]
  rapids: ForestRapid[]
  rivers: ForestRiver[]
  lagoons: ForestLagoon[]
  peaks: MountainPeak[]
  meanSeg: number
  groundAt: (x: number, z: number) => number
  riverAt: (x: number, z: number) => number
  bounds: { x0: number; z0: number; sc: number; ox: number; oz: number }
}

function mulberry32(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v))
const wrapA = (a: number) => {
  while (a > Math.PI) a -= Math.PI * 2
  while (a < -Math.PI) a += Math.PI * 2
  return a
}

function catmull(ctrl: number[][], closed: boolean, sub: number): number[][] {
  const K = ctrl.length
  const out: number[][] = []
  const get = (i: number) => (closed ? ctrl[((i % K) + K) % K] : ctrl[clamp(i, 0, K - 1)])
  const segs = closed ? K : K - 1
  for (let k = 0; k < segs; k++) {
    const p0 = get(k - 1), p1 = get(k), p2 = get(k + 1), p3 = get(k + 2)
    for (let j = 0; j < sub; j++) {
      const t = j / sub, t2 = t * t, t3 = t2 * t
      out.push([0, 1].map((c) => 0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3)))
    }
  }
  if (!closed) out.push(ctrl[K - 1].slice())
  return out
}
function resample(pts: number[][], step: number): number[][] {
  const out: number[][] = [pts[0].slice()]
  let acc = 0
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i]
    let d = Math.hypot(b[0] - a[0], b[1] - a[1])
    let from = a
    while (acc + d >= step) {
      const t = (step - acc) / d
      const p = [from[0] + (b[0] - from[0]) * t, from[1] + (b[1] - from[1]) * t]
      out.push(p)
      from = p
      d = Math.hypot(b[0] - p[0], b[1] - p[1])
      acc = 0
    }
    acc += d
  }
  const last = pts[pts.length - 1]
  if (Math.hypot(out[out.length - 1][0] - last[0], out[out.length - 1][1] - last[1]) > 1) out.push(last.slice())
  return out
}
const plen = (p: number[][]) => {
  let l = 0
  for (let i = 1; i < p.length; i++) l += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1])
  return l
}

function noiseField(n: number, scaleCols: number, rnd: () => number, amp: number, out: Float32Array) {
  const P = Math.ceil(n / scaleCols) + 2
  const lat = new Float32Array(P * P)
  for (let i = 0; i < lat.length; i++) lat[i] = rnd()
  for (let j = 0; j < n; j++) {
    const fy = j / scaleCols
    const y0 = Math.floor(fy)
    let ty = fy - y0
    ty = ty * ty * (3 - 2 * ty)
    for (let i = 0; i < n; i++) {
      const fx = i / scaleCols
      const x0 = Math.floor(fx)
      let tx = fx - x0
      tx = tx * tx * (3 - 2 * tx)
      const a = lat[y0 * P + x0] + (lat[y0 * P + x0 + 1] - lat[y0 * P + x0]) * tx
      const b = lat[(y0 + 1) * P + x0] + (lat[(y0 + 1) * P + x0 + 1] - lat[(y0 + 1) * P + x0]) * tx
      out[j * n + i] += amp * (a + (b - a) * ty)
    }
  }
}

export function buildArena(o: ArenaOpts): Arena {
  const rnd = mulberry32(Math.round(o.seed) * 7177 + 31)
  const forest = o.planet === 'forest'
  const isDesertOrLava = (pl: string) => pl === 'desert' || pl === 'lava'
  const sm = (t: number) => t * t * (3 - 2 * t)
  const n = clamp(Math.round(o.gates), 4, 12)
  const R = o.radius

  // ── the gates: for forest, sculpt an asymmetric multi-basin rainforest river valley & cloud-ridge circuit
  const nodes: number[][] = []
  const jit = rnd() * Math.PI * 2
  const lobeP1 = jit + 0.65
  const lobeP2 = jit * 1.7 + 2.1
  for (let k = 0; k < n; k++) {
    const baseTh = jit + (k / n) * Math.PI * 2
    const th = baseTh + (rnd() - 0.5) * (forest ? 0.24 : 0.3) * ((Math.PI * 2) / n)
    if (forest) {
      const lobe2 = Math.cos((baseTh - lobeP1) * 2) * 0.16
      const lobe3 = Math.sin((baseTh - lobeP2) * 3) * 0.11
      const r = R * clamp(0.84 + lobe2 + lobe3 + (rnd() - 0.5) * 0.14, 0.58, 1.14)
      nodes.push([Math.cos(th) * r * 1.08, Math.sin(th) * r * 0.94])
    } else {
      const r = R * (0.74 + 0.26 * rnd())
      nodes.push([Math.cos(th) * r, Math.sin(th) * r])
    }
  }

  // ── wide main route: flowing S-curve river valleys & sweeping mountain-gorge bends
  const planCut: boolean[] = []
  for (let k = 0; k < n; k++) planCut.push(rnd() < (forest ? Math.max(0.55, o.shortcuts) : o.shortcuts))
  const ctrl: number[][] = []
  const ptsPerSeg = forest ? 3 : 2
  for (let k = 0; k < n; k++) {
    const a = nodes[k]
    const b = nodes[(k + 1) % n]
    const dx = b[0] - a[0], dz = b[1] - a[1]
    const L = Math.hypot(dx, dz) || 1
    const px = -dz / L, pz = dx / L
    if (forest) {
      const sCurve = !planCut[k] && k % 2 === 1
      const dir = (k % 2 === 0 ? 1 : -1) * (rnd() < 0.72 ? 1 : -1)
      if (sCurve) {
        const amp = (0.14 + rnd() * 0.1) * L
        ctrl.push(
          a,
          [a[0] + dx * 0.33 + px * dir * amp, a[1] + dz * 0.33 + pz * dir * amp],
          [a[0] + dx * 0.67 - px * dir * amp * 0.92, a[1] + dz * 0.67 - pz * dir * amp * 0.92],
        )
      } else {
        const mainBow = dir * (planCut[k] ? 0.24 + rnd() * 0.14 : 0.14 + rnd() * 0.1) * L
        const asym = 0.72 + rnd() * 0.42
        ctrl.push(
          a,
          [a[0] + dx * 0.34 + px * mainBow * asym, a[1] + dz * 0.34 + pz * mainBow * asym],
          [a[0] + dx * 0.68 + px * mainBow * (1.55 - asym * 0.55), a[1] + dz * 0.68 + pz * mainBow * (1.55 - asym * 0.55)],
        )
      }
    } else {
      const bow = (rnd() < 0.5 ? -1 : 1) * (planCut[k] ? 0.26 + rnd() * 0.14 : 0.08 + rnd() * 0.12) * L
      ctrl.push(a, [(a[0] + b[0]) / 2 + px * bow, (a[1] + b[1]) / 2 + pz * bow])
    }
  }
  const SUB = forest ? 20 : 24
  const dense = catmull(ctrl, true, SUB)
  for (let pass = 0; pass < 5; pass++) {
    const c = dense.map((p) => p.slice())
    const M = dense.length
    for (let i = 0; i < M; i++) {
      for (let a = 0; a < 2; a++) {
        let sum = 0
        for (let k = -4; k <= 4; k++) sum += c[(i + k + M * 3) % M][a]
        dense[i][a] = sum / 9
      }
    }
  }
  for (let k = 0; k < n; k++) nodes[k] = dense[(k * ptsPerSeg * SUB) % dense.length].slice()
  const paths: Path[] = []
  const segs: number[][] = []
  const mainHalf = o.width / 2
  const cutHalf = Math.max(18, o.width * (forest ? 0.38 : 0.34))
  for (let k = 0; k < n; k++) {
    const i0 = k * ptsPerSeg * SUB
    const i1 = (k + 1) * ptsPerSeg * SUB
    const part: number[][] = []
    for (let i = i0; i <= i1; i++) part.push(dense[i % dense.length])
    const pts = resample(part, 10)
    paths.push({ id: paths.length, seg: k, kind: 'main', pts, halfW: mainHalf, len: plen(pts), hidden: false })
    segs.push([paths.length - 1])
  }
  // ── mountain ravine shortcuts
  for (let k = 0; k < n; k++) {
    if (!planCut[k]) continue
    const a = nodes[k], b = nodes[(k + 1) % n]
    const dx = b[0] - a[0], dz = b[1] - a[1]
    const L = Math.hypot(dx, dz) || 1
    const s1 = (rnd() - 0.5) * (forest ? 0.15 : 0.12) * L
    const s2 = (rnd() - 0.5) * (forest ? 0.15 : 0.12) * L
    const c = [a, [a[0] + dx * 0.34 - (dz / L) * s1, a[1] + dz * 0.34 + (dx / L) * s1], [a[0] + dx * 0.68 - (dz / L) * s2, a[1] + dz * 0.68 + (dx / L) * s2], b]
    const pts = resample(catmull(c, false, 16), 10)
    const len = plen(pts)
    if (len > paths[k].len * 0.94) continue
    paths.push({ id: paths.length, seg: k, kind: 'cut', pts, halfW: cutHalf, len, hidden: rnd() < (forest ? 0.42 : 0.6) })
    segs[k].push(paths.length - 1)
  }
  // ── braided island splits wrapping around colossal forest groves OR monumental canyon butte/oasis/caldera islands!
  const islandCenters: number[][] = []
  {
    let braids = 0
    const maxBraids = forest ? Math.max(2, Math.floor(n * 0.42)) : Math.max(2, Math.floor(n * 0.32))
    for (let k = 1; k < n && braids < maxBraids; k++) {
      const main = paths[k]
      if (main.len < 480 || (segs[k].length > 1 && rnd() < 0.5)) continue
      const M = main.pts.length
      const side = k % 2 ? 1 : -1
      const spread = clamp(o.width * 1.22 + 38, 98, 156)
      const braidPts: number[][] = []
      for (let i = 0; i < M; i++) {
        const u = i / Math.max(1, M - 1)
        const env = Math.pow(Math.sin(Math.PI * clamp((u - 0.12) / 0.76, 0, 1)), 1.35)
        const p0 = main.pts[Math.max(0, i - 1)], p1 = main.pts[Math.min(M - 1, i + 1)]
        const tl = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) || 1
        const rx = -(p1[1] - p0[1]) / tl, rz = (p1[0] - p0[0]) / tl
        braidPts.push([main.pts[i][0] + rx * side * spread * env, main.pts[i][1] + rz * side * spread * env])
      }
      const resampled = resample(braidPts, 10)
      const mid = Math.floor(M * 0.5)
      const p0 = main.pts[Math.max(0, mid - 1)], p1 = main.pts[Math.min(M - 1, mid + 1)]
      const tl = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) || 1
      islandCenters.push([
        main.pts[mid][0] - ((p1[1] - p0[1]) / tl) * side * spread * 0.5,
        main.pts[mid][1] + ((p1[0] - p0[0]) / tl) * side * spread * 0.5,
        spread * 0.34,
      ])
      paths.push({ id: paths.length, seg: k, kind: 'cut', pts: resampled, halfW: Math.max(25, o.width * 0.42), len: plen(resampled), hidden: false })
      segs[k].push(paths.length - 1)
      braids++
    }
  }

  // ── gate frames
  const gates: Gate[] = nodes.map((p, k) => {
    const prev = paths[(k - 1 + n) % n].pts
    const m = prev.length
    const a = prev[Math.max(0, m - 4)]
    const b = paths[k].pts[Math.min(3, paths[k].pts.length - 1)]
    let nx = b[0] - a[0], nz = b[1] - a[1]
    const l = Math.hypot(nx, nz) || 1
    nx /= l; nz /= l
    return { x: p[0], z: p[1], nx, nz, r: 52 }
  })
  const meanSeg = paths.slice(0, n).reduce((s, p) => s + p.len, 0) / n

  // ── bounds & heightfield grid
  let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9
  for (const p of paths) for (const q of p.pts) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); z0 = Math.min(z0, q[1]); z1 = Math.max(z1, q[1]) }
  const margin = forest ? 420 : 300
  const size = Math.max(x1 - x0, z1 - z0) + margin * 2
  const cx = (x0 + x1) / 2
  const cz = (z0 + z1) / 2
  const C = Math.max(forest ? 8.5 : 9, size / (forest ? 440 : 420))
  const N = Math.ceil(size / C)
  const ox = cx - size / 2
  const oz = cz - size / 2
  const bs = 1 / (Math.max(x1 - x0, z1 - z0) + 60)
  const bounds = { x0: x0 - 30, z0: z0 - 30, sc: bs, ox: (1 - (x1 - x0 + 60) * bs) / 2, oz: (1 - (z1 - z0 + 60) * bs) / 2 }

  // ── Multi-zone elevation choreography for BOTH Rainforest & Grand Canyons!
  // Canyons flow through 4 distinct zones: High Sunlit Mesa Rim (56m) -> Deep Slot-Canyon Drop (10m) ->
  // Wide Oasis / Mirror-Lake / Magma-Caldera Amphitheater (10m) -> Terraced Sky-Bridge Pass (58m) -> Cascade Plunge!
  const heightAnchors = forest
    ? [108, 30, 22, 74, 114, 42, 24, 78]
    : [56, 12, 9, 38, 60, 14, 10, 42]
  const shortestMain = Math.min(...paths.slice(0, n).map((path) => path.len))
  const relief = clamp(o.forestRelief ?? 1, 0.4, 1.35) * Math.min(1, shortestMain / 420)
  const pivotH = forest ? 54 : 30
  const canyonRelief = Math.min(1, shortestMain / 400)
  const gateHeights = gates.map((_, i) => {
    const p = (i * heightAnchors.length) / n
    const k = Math.floor(p)
    const f = p - k
    const target = heightAnchors[k % heightAnchors.length] * (1 - f) + heightAnchors[(k + 1) % heightAnchors.length] * f
    return pivotH + (target - pivotH) * (forest ? relief : canyonRelief)
  })
  const downhill = Array.from({ length: n }, (_, i) => ({ segment: i, drop: gateHeights[i] - gateHeights[(i + 1) % n] }))
    .filter((item) => item.segment !== 0 && item.drop > 10)
    .sort((a, b) => b.drop - a.drop)
  const rapidSegments = new Set<number>(forest ? [0, ...downhill.slice(0, 2).map((item) => item.segment)] : [])
  const routeHeight = (path: Path, progress: number) => {
    const start = gateHeights[path.seg]
    const end = gateHeights[(path.seg + 1) % n]
    const t = rapidSegments.has(path.seg)
      ? 0.42 * sm(clamp((progress - 0.16) / 0.16, 0, 1))
        + 0.34 * sm(clamp((progress - 0.36) / 0.16, 0, 1))
        + 0.24 * sm(clamp((progress - 0.56) / 0.16, 0, 1))
      : sm(progress)
    const rollAmp = forest ? 3.2 * relief : 2.6 * canyonRelief
    const rolling = rollAmp * Math.sin(Math.PI * progress) * Math.sin(progress * Math.PI * 2 + path.seg * 1.3)
    return start + (end - start) * t + rolling
  }
  // Dynamic corridor width modulation on Canyons: blooms wide open in low oasis/caldera basins, tightens dramatically in slot gorges!
  const routeHalfW = (path: Path, progress: number, rH: number) => {
    if (forest || path.kind === 'cut') return path.halfW
    const env = Math.sin(Math.PI * progress)
    const basinBloom = rH < 20 ? 0.32 * env : rH > 46 ? 0.12 * env : -0.06 * env
    return path.halfW * (1 + basinBloom)
  }
  const rapids: ForestRapid[] = Array.from(rapidSegments).map((segment) => {
    const path = paths[segment]
    return {
      pathId: path.id,
      segment,
      startIndex: Math.max(1, Math.floor(path.pts.length * 0.1)),
      endIndex: Math.min(path.pts.length - 2, Math.floor(path.pts.length * 0.84)),
      drop: gateHeights[segment] - gateHeights[(segment + 1) % n],
    }
  })

  const HC = 140
  const hash = new Map<string, number[][]>()
  const addS = (x: number, z: number, hw: number, height = 0) => {
    const k = Math.floor(x / HC) + ',' + Math.floor(z / HC)
    let a = hash.get(k)
    if (!a) hash.set(k, (a = []))
    a.push([x, z, hw, height])
  }
  for (const p of paths) {
    p.pts.forEach((q, i) => {
      const prog = i / Math.max(1, p.pts.length - 1)
      const rh = routeHeight(p, prog)
      addS(q[0], q[1], routeHalfW(p, prog, rh), rh)
    })
  }
  gates.forEach((g, i) => addS(g.x, g.z, 64, gateHeights[i]))
  const P1 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 420 / C), rnd, 1, P1)
  noiseField(N, Math.max(2, 130 / C), rnd, 0.5, P1)
  const F1 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 60 / C), rnd, 1, F1)
  const W1 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 80 / C), rnd, 1, W1)
  noiseField(N, Math.max(2, 28 / C), rnd, 0.5, W1)
  const R1 = new Float32Array(N * N)
  const R2 = new Float32Array(N * N)
  noiseField(N, Math.max(2, 310 / C), rnd, 1, R1)
  noiseField(N, Math.max(2, 115 / C), rnd, 1, R2)

  const hgt = new Float32Array(N * N)
  const lat = new Float32Array(N * N)
  const edge = new Float32Array(N * N)
  const riverMask = new Float32Array(N * N)
  const WALL = 74
  const TERR = 3
  const searchR = 2
  for (let j = 0; j < N; j++) {
    for (let i = 0; i < N; i++) {
      const x = ox + (i + 0.5) * C
      const z = oz + (j + 0.5) * C
      const cxk = Math.floor(x / HC), czk = Math.floor(z / HC)
      let e = 1e9
      let lt = 9
      let weightedHeight = 0
      let totalWeight = 0
      for (let a = -searchR; a <= searchR; a++) for (let b = -searchR; b <= searchR; b++) {
        const arr = hash.get(cxk + a + ',' + (czk + b))
        if (!arr) continue
        for (const s of arr) {
          const d0 = Math.hypot(s[0] - x, s[1] - z)
          const d = d0 - s[2]
          if (d < e) { e = d; lt = d0 / s[2] }
          const denominator = d0 * d0 + 440
          const weight = 1 / (denominator * denominator)
          weightedHeight += s[3] * weight
          totalWeight += weight
        }
      }
      const idx = j * N + i
      edge[idx] = e > 1e8 ? 1000 : e
      lat[idx] = lt
      const pn = P1[idx] / 1.5
      let H: number
      if (forest) {
        const warpX = clamp(Math.round(i + (P1[idx] - 0.75) * 18), 0, N - 1)
        const warpZ = clamp(Math.round(j + (W1[idx] - 0.75) * 18), 0, N - 1)
        const wIdx = warpZ * N + warpX
        const ridgeA = 1 - Math.abs(R1[wIdx] * 2 - 1)
        const ridgeB = 1 - Math.abs(R2[idx] * 2 - 1)
        const ridgeCombo = Math.pow(ridgeA, 1.65) * 0.68 + Math.pow(ridgeB, 1.75) * 0.32
        const bankRise = sm(clamp((e - 5) / 58, 0, 1))
        const mountainMask = sm(clamp((e - 40) / 155, 0, 1))
        const deepWild = sm(clamp((e - 130) / 210, 0, 1))
        const foothills = bankRise * (10 + pn * 20 + (W1[idx] / 1.5) * 6)
        const ridges = mountainMask * (20 + ridgeCombo * 58 + pn * 18) + deepWild * (22 + ridgeCombo * 46)
        const regional = 42 + pn * 20 + clamp(F1[idx] / 1.5, 0, 1) * 5
        const routeBlend = e < 135 ? 1 - sm(clamp((e - 16) / 112, 0, 1)) : 0
        const route = routeBlend > 0 && totalWeight > 0 ? weightedHeight / totalWeight : regional
        H = regional * (1 - routeBlend) + route * routeBlend + foothills + ridges
      } else {
        // Multi-Zone Sculpted Canyon World:
        // - When route is HIGH (50-60m Mesa Rim Overlook): low open sandstone/glacier parapet (only ~22-35m above road!)
        //   so pilots look out across vast sunlit sky vistas, stepped valleys, and distant monuments!
        // - When route plunges LOW (9-16m Deep Gorge & Oasis/Caldera Basin): towering 85-115m 4-tier cliffs rise dramatically!
        const routeFloor = (totalWeight > 0 ? weightedHeight / totalWeight : 28) + 1.8 * clamp(F1[idx] / 1.5, 0, 1)
        const ridgeA = 1 - Math.abs(R1[idx] * 2 - 1)
        const ridgeB = 1 - Math.abs(R2[idx] * 2 - 1)
        const ridgeMix = Math.pow(ridgeA, 1.55) * 0.65 + Math.pow(ridgeB, 1.7) * 0.35
        const isIce = o.planet === 'ice'
        const isLava = o.planet === 'lava'
        const upperRim = sm(clamp((e - WALL) / 150, 0, 1))
        // Keep plateau Base high enough above even high rim roads (+22m min curb wall) while opening grand sky views!
        const plateauBase = Math.max(routeFloor + 22 + pn * 18, 78 + pn * 44 + (pn > 0.62 ? 16 : 0))
        const plateauUpper = isIce
          ? upperRim * (34 + Math.pow(ridgeA, 1.9) * 88 + ridgeB * 28)
          : isLava
            ? upperRim * (30 + ridgeMix * 80 + (pn > 0.72 ? 24 : 0))
            : upperRim * (26 + Math.round(pn * 4) * 13 + ridgeMix * 46)
        const plateau = plateauBase + plateauUpper
        H = plateau
        const wallSpan = WALL + 18
        if (e <= 0) {
          const edgeBank = sm(clamp((lt - 0.72) / 0.3, 0, 1))
          const dune = Math.sin(x * 0.042 + z * 0.031 + W1[idx] * 2.0) * 0.5 + 0.5
          H = routeFloor + edgeBank * (1.2 + 1.6 * dune)
        } else if (e < wallSpan + 20) {
          const fluting = (W1[idx] / 1.5 - 0.5) * 20 + (ridgeB - 0.5) * 12
          const ej = e + fluting
          const t = clamp(ej / wallSpan, 0, 1)
          const tiers = isDesertOrLava(o.planet) ? 4 : TERR + 1
          const ts = t * tiers
          const fl = Math.floor(ts)
          const fr = ts - fl
          const talus = sm(clamp(t / 0.22, 0, 1)) * 0.14
          const stepProf = sm(clamp((fr - 0.24) / 0.54, 0, 1))
          const tt = clamp(talus + 0.86 * Math.min(1, (fl + stepProf) / tiers), 0, 1)
          H = routeFloor + tt * (plateauBase - routeFloor)
        }
      }
      const bd = Math.min(i, j, N - 1 - i, N - 1 - j)
      if (!forest && bd < 8) H = Math.max(H, bd < 3 ? 185 : 148)
      hgt[idx] = H
    }
  }

  // ── sculpted forested mountain ranges, central massif, mossy karst pillars & full watershed hydrology
  const peaks: MountainPeak[] = []
  const rivers: ForestRiver[] = []
  const lagoons: ForestLagoon[] = []
  if (forest) {
    const addMountain = (
      mx: number, mz: number, heightAdd: number, rx: number, rz: number,
      rot: number, kind: MountainPeak['kind'], curveBend: number,
    ) => {
      const i0 = Math.round((mx - ox) / C)
      const j0 = Math.round((mz - oz) / C)
      const rMax = Math.ceil((Math.max(rx, rz) * 1.15) / C) + 2
      const cs = Math.cos(rot), sn = Math.sin(rot)
      let summitY = 0
      for (let dj = -rMax; dj <= rMax; dj++) {
        const cj = j0 + dj
        if (cj < 1 || cj >= N - 1) continue
        for (let di = -rMax; di <= rMax; di++) {
          const ci = i0 + di
          if (ci < 1 || ci >= N - 1) continue
          const k = cj * N + ci
          const e = edge[k]
          if (e < 16) continue
          const wx = ox + (ci + 0.5) * C - mx
          const wz = oz + (cj + 0.5) * C - mz
          const rawX = (wx * cs + wz * sn) / rx
          const rawZ = (-wx * sn + wz * cs) / rz - curveBend * rawX * rawX
          const warp = (W1[k] / 1.5 - 0.5) * 0.24
          const d = Math.hypot(rawX + warp * 0.5, rawZ - warp * 0.5)
          if (d >= 1) continue
          const localRidge = 1 - Math.abs(R2[k] * 2 - 1)
          const broadFold = 1 - Math.abs(R1[k] * 2 - 1)
          const erosion = 0.72 + 0.34 * localRidge + 0.18 * broadFold
          const safe = sm(clamp((e - 16) / (kind === 'karst' ? 30 : 62), 0, 1))
          const prof = kind === 'karst'
            ? (1 - sm(clamp((d - 0.36) / 0.64, 0, 1))) * (0.82 + 0.22 * localRidge)
            : Math.pow(1 - d, 1.45) * (1 + 0.18 * (1 - Math.min(1, Math.abs(rawZ) * 2.2))) * erosion
          hgt[k] += heightAdd * prof * safe
          if (hgt[k] > summitY && d < 0.22) summitY = hgt[k]
        }
      }
      if (summitY > 75) peaks.push({ x: mx, z: mz, y: summitY, radius: (rx + rz) * 0.5, kind })
    }

    // Central Forested Massif ("Gunung Rimba Agung")
    let bestE = 0, cmx = cx, cmz = cz
    const innerScan = R * 0.68
    for (let j = 8; j < N - 8; j += 3) {
      const z = oz + (j + 0.5) * C
      if (Math.abs(z - cz) > innerScan) continue
      for (let i = 8; i < N - 8; i += 3) {
        const x = ox + (i + 0.5) * C
        if (Math.hypot(x - cx, z - cz) > innerScan) continue
        const e = edge[j * N + i]
        if (e > bestE) { bestE = e; cmx = x; cmz = z }
      }
    }
    if (bestE > 85) {
      const mainR = clamp(bestE * 1.15, 200, 460)
      addMountain(cmx, cmz, clamp(105 + bestE * 0.17, 125, 175), mainR * 1.18, mainR * 0.88, rnd() * 3.14, 'central', (rnd() - 0.5) * 0.55)
      for (let s = 0; s < 4; s++) {
        const a = (s / 4) * Math.PI * 2 + rnd() * 0.6
        const dist = mainR * (0.56 + rnd() * 0.3)
        const sx = cmx + Math.cos(a) * dist, sz = cmz + Math.sin(a) * dist
        const se = edge[clamp(Math.floor((sz - oz) / C), 0, N - 1) * N + clamp(Math.floor((sx - ox) / C), 0, N - 1)]
        if (se > 60) {
          const sr = clamp(se * 1.1, 135, 310)
          addMountain(sx, sz, 62 + rnd() * 48, sr * 1.32, sr * 0.72, a + 0.35, 'ridge', (rnd() - 0.5) * 0.65)
        }
      }
    }

    // Outer interlocking forested mountain chains
    const wantMountains = Math.round(clamp(size / 130, 18, 26))
    for (let tries = 0; tries < wantMountains * 28 && peaks.length < wantMountains + 5; tries++) {
      const i0 = 10 + Math.floor(rnd() * (N - 20)), j0 = 10 + Math.floor(rnd() * (N - 20))
      const e = edge[j0 * N + i0]
      if (e < 76) continue
      const mx = ox + (i0 + 0.5) * C, mz = oz + (j0 + 0.5) * C
      if (peaks.some((pk) => Math.hypot(pk.x - mx, pk.z - mz) < 245)) continue
      const rad = clamp(e * (0.9 + rnd() * 0.45), 155, 380)
      const tall = clamp(68 + rnd() * 78 + (e > 195 ? 28 : 0), 72, 168)
      addMountain(mx, mz, tall, rad * (1.2 + rnd() * 0.38), rad * (0.68 + rnd() * 0.25), rnd() * Math.PI, 'ridge', (rnd() - 0.5) * 0.7)
    }

    // Dramatic mossy rainforest karst bluffs flanking valley curves
    let madeKarst = 0
    for (let tries = 0; tries < 480 && madeKarst < 16; tries++) {
      const i0 = 14 + Math.floor(rnd() * (N - 28)), j0 = 14 + Math.floor(rnd() * (N - 28))
      const e = edge[j0 * N + i0]
      if (e < 44 || e > 145) continue
      const mx = ox + (i0 + 0.5) * C, mz = oz + (j0 + 0.5) * C
      if (peaks.some((pk) => Math.hypot(pk.x - mx, pk.z - mz) < 150)) continue
      const rad = 46 + rnd() * 44
      addMountain(mx, mz, 38 + rnd() * 48, rad * 1.15, rad * 0.85, rnd() * Math.PI, 'karst', (rnd() - 0.5) * 0.4)
      madeKarst++
    }
    for (const [ix, iz, ir] of islandCenters) addMountain(ix, iz, 14 + rnd() * 12, ir, ir * 0.85, rnd() * Math.PI, 'karst', 0.15)
  } else {
    // ── Monumental Canyon Landmarks: Central Citadel Butte/Caldera/Glacier + Tiered Mesas, Hoodoo Spires & Ridge Massifs!
    const isIce = o.planet === 'ice'
    const isLava = o.planet === 'lava'

    const stampFormation = (
      i0: number, j0: number, rxCells: number, rzCells: number, rot: number,
      tall: number, style: 'mesa' | 'spire' | 'caldera', minE: number, kind: MountainPeak['kind'],
    ) => {
      const base = hgt[j0 * N + i0]
      const ri = Math.ceil(Math.max(rxCells, rzCells) + 2)
      const cs = Math.cos(rot), sn = Math.sin(rot)
      let topY = base
      for (let dj = -ri; dj <= ri; dj++) {
        const cj = j0 + dj
        if (cj < 2 || cj >= N - 2) continue
        for (let di = -ri; di <= ri; di++) {
          const ci = i0 + di
          if (ci < 2 || ci >= N - 2) continue
          const c2 = cj * N + ci
          if (edge[c2] < minE) continue
          const lx = (di * cs + dj * sn) / rxCells
          const lz = (-di * sn + dj * cs) / rzCells
          const flute = 1 + 0.12 * Math.cos(Math.atan2(lz, lx) * 6 + i0)
          const d = Math.hypot(lx, lz) * flute
          if (d > 1.05) continue
          const safe = sm(clamp((edge[c2] - minE) / 18, 0, 1))
          let prof = 0
          if (style === 'mesa') {
            // Monument Valley two-tiered flat-topped sandstone butte with crisp caprock rim!
            const lower = 1 - sm(clamp((d - 0.52) / 0.48, 0, 1))
            const upperCap = 1 - sm(clamp((d - 0.28) / 0.18, 0, 1))
            prof = lower * 0.68 + upperCap * 0.32
          } else if (style === 'caldera') {
            // Dramatic smoking volcanic caldera cone with sunken glowing magma crater rim!
            const cone = Math.pow(Math.max(0, 1 - d), 1.25)
            const craterDip = d < 0.28 ? (1 - sm(d / 0.28)) * 0.34 : 0
            prof = Math.max(0, cone - craterDip)
          } else {
            // Sharp towering glacier horn / sandstone hoodoo needle / obsidian spire
            prof = Math.pow(Math.max(0, 1 - d), isIce ? 1.55 : 1.3) * (1 - sm(clamp((d - 0.72) / 0.28, 0, 1)))
          }
          const nh = base + tall * prof * safe
          if (nh > hgt[c2]) hgt[c2] = nh
          if (nh > topY && d < 0.35) topY = nh
        }
      }
      if (topY > base + 18) {
        peaks.push({
          x: ox + (i0 + 0.5) * C,
          z: oz + (j0 + 0.5) * C,
          y: topY,
          radius: ((rxCells + rzCells) * 0.5) * C,
          kind,
        })
      }
    }

    // 1. Hero Central Monument towering over the heart of the canyon circuit
    let bestE = 0, ciBest = Math.floor(N / 2), cjBest = Math.floor(N / 2)
    for (let j = 14; j < N - 14; j += 3) {
      for (let i = 14; i < N - 14; i += 3) {
        const wx = ox + (i + 0.5) * C, wz = oz + (j + 0.5) * C
        if (Math.hypot(wx - cx, wz - cz) > R * 0.65) continue
        if (edge[j * N + i] > bestE) { bestE = edge[j * N + i]; ciBest = i; cjBest = j }
      }
    }
    if (bestE > 95) {
      const rCells = clamp((bestE * 0.62) / C, 8, 22)
      const heroTall = isLava ? 128 : isIce ? 136 : 112
      const heroStyle = isLava ? 'caldera' : isIce ? 'spire' : 'mesa'
      stampFormation(ciBest, cjBest, rCells * 1.18, rCells * 0.88, rnd() * Math.PI, heroTall, heroStyle, 52, 'central')
    }

    // 2. Grand Upper-Bench Monuments: Monument Valley Mesas, Hoodoo Towers, Glacial Horns & Volcanic Cones
    const count = Math.round(78 * clamp(size / 2200, 0.75, 1.9))
    let made = 0
    for (let tries = 0; tries < count * 12 && made < count; tries++) {
      const i0 = 12 + Math.floor(rnd() * (N - 24)), j0 = 12 + Math.floor(rnd() * (N - 24))
      const e = edge[j0 * N + i0]
      if (e < 56 || e > 260) continue
      const wx = ox + (i0 + 0.5) * C, wz = oz + (j0 + 0.5) * C
      const grand = made < 18 && e > 92 && !peaks.some((p) => Math.hypot(p.x - wx, p.z - wz) < 210)
      made++
      if (grand) {
        const style: 'mesa' | 'spire' | 'caldera' = isLava
          ? (rnd() < 0.55 ? 'caldera' : 'spire')
          : isIce
            ? (rnd() < 0.72 ? 'spire' : 'mesa')
            : (rnd() < 0.68 ? 'mesa' : 'spire')
        const rx = (style === 'spire' ? 6.5 : 9.5) + rnd() * 6.5
        const rz = rx * (0.62 + rnd() * 0.34)
        const tall = (style === 'mesa' ? 54 : 74) + rnd() * 52
        stampFormation(i0, j0, rx, rz, rnd() * Math.PI, tall, style, 46, 'ridge')
      } else {
        const style: 'mesa' | 'spire' | 'caldera' = isIce
          ? (rnd() < 0.65 ? 'spire' : 'mesa')
          : isLava
            ? (rnd() < 0.55 ? 'caldera' : 'mesa')
            : 'mesa'
        const rx = 5.0 + rnd() * 4.8
        const rz = rx * (0.62 + rnd() * 0.35)
        const tall = 26 + rnd() * 34
        stampFormation(i0, j0, rx, rz, rnd() * Math.PI, tall, style, 44, 'karst')
      }
    }
  }

  for (let pass = 0; pass < 2; pass++) {
    const c = hgt.slice()
    for (let j = 1; j < N - 1; j++) {
      for (let i = 1; i < N - 1; i++) {
        const k = j * N + i
        if (edge[k] <= 2) continue
        hgt[k] = (4 * c[k] + 2 * (c[k - 1] + c[k + 1] + c[k - N] + c[k + N]) + c[k - N - 1] + c[k - N + 1] + c[k + N - 1] + c[k + N + 1]) / 16
      }
    }
  }

  const sampleHgtRaw = (x: number, z: number) => {
    const fx = (x - ox) / C - 0.5, fz = (z - oz) / C - 0.5
    const i = Math.floor(fx), j = Math.floor(fz)
    const tx = fx - i, tz = fz - j
    const gc = (a: number, b: number) => hgt[clamp(b, 0, N - 1) * N + clamp(a, 0, N - 1)]
    return (gc(i, j) * (1 - tx) + gc(i + 1, j) * tx) * (1 - tz) + (gc(i, j + 1) * (1 - tx) + gc(i + 1, j + 1) * tx) * tz
  }

  // ── Complete connected rainforest river watershed
  if (forest) {
    // 1. Stepped whitewater rapid rivers & plunge lagoons
    for (const rapid of rapids) {
      const p = paths[rapid.pathId]
      const pts: number[][] = []
      const M = p.pts.length
      const phase = rapid.segment * 1.9 + 0.4
      for (let i = 0; i < M; i++) {
        const u = i / Math.max(1, M - 1)
        const prev = p.pts[Math.max(0, i - 1)], next = p.pts[Math.min(M - 1, i + 1)]
        const tl = Math.hypot(next[0] - prev[0], next[1] - prev[1]) || 1
        const rx = -(next[1] - prev[1]) / tl, rz = (next[0] - prev[0]) / tl
        const meander = Math.sin(u * Math.PI * 2.4 + phase) * p.halfW * 0.24 * Math.sin(Math.PI * u)
        const hw = Math.min(36, p.halfW * 0.68) * (0.78 + 0.34 * Math.sin(u * Math.PI) + 0.16 * sm(clamp((u - 0.72) / 0.28, 0, 1)))
        pts.push([p.pts[i][0] + rx * meander, p.pts[i][1] + rz * meander, hw, 0.85])
      }
      rivers.push({ id: rivers.length, kind: 'rapid', pts, flowSpeed: 1.55 })
      const foot = pts[pts.length - 1], prevF = pts[Math.max(0, pts.length - 3)]
      const fl = Math.hypot(foot[0] - prevF[0], foot[1] - prevF[1]) || 1
      const side = rapid.segment % 2 === 0 ? 1 : -1
      lagoons.push({
        x: foot[0] - ((foot[1] - prevF[1]) / fl) * side * p.halfW * 0.52,
        z: foot[1] + ((foot[0] - prevF[0]) / fl) * side * p.halfW * 0.52,
        rx: 44 + rnd() * 20, rz: 32 + rnd() * 14,
        rot: Math.atan2(foot[1] - prevF[1], foot[0] - prevF[0]),
        y: sampleHgtRaw(foot[0], foot[1]),
      })
    }

    // 2. Winding emerald valley rivers, braided oxbow island channels & grand canyon outflow rivers
    for (let seg = 0; seg < n; seg++) {
      if (rapidSegments.has(seg)) continue
      const p = paths[seg]
      const hStart = gateHeights[seg], hEnd = gateHeights[(seg + 1) % n]
      const forward = hStart >= hEnd
      const isLowBasin = Math.min(hStart, hEnd) < 48
      const pts: number[][] = []
      const M = p.pts.length
      const sideBase = seg % 2 === 0 ? 1 : -1
      const phase = seg * 2.3 + rnd() * 1.4
      for (let step = 0; step < M; step++) {
        const i = forward ? step : M - 1 - step
        const u = step / Math.max(1, M - 1)
        const prev = p.pts[Math.max(0, i - 1)], next = p.pts[Math.min(M - 1, i + 1)]
        const tl = Math.hypot(next[0] - prev[0], next[1] - prev[1]) || 1
        const rx = -(next[1] - prev[1]) / tl, rz = (next[0] - prev[0]) / tl
        const offset = isLowBasin
          ? Math.sin(u * Math.PI * 2.2 + phase) * (p.halfW * 0.78) + sideBase * p.halfW * 0.18
          : sideBase * p.halfW * (0.66 + 0.34 * Math.sin(u * Math.PI * 3 + phase))
        const hw = isLowBasin
          ? (16 + 9 * (0.5 + 0.5 * Math.sin(u * Math.PI * 3.1 + seg))) * (0.72 + 0.28 * Math.sin(Math.PI * u))
          : (10 + 5.5 * (0.5 + 0.5 * Math.cos(u * Math.PI * 2.5 + seg))) * (0.75 + 0.25 * Math.sin(Math.PI * u))
        pts.push([p.pts[i][0] + rx * offset, p.pts[i][1] + rz * offset, hw, Math.abs(offset) > p.halfW * 0.72 ? 1.45 : 0.75])
      }
      rivers.push({ id: rivers.length, kind: isLowBasin ? 'valley' : 'meander', pts, flowSpeed: isLowBasin ? 0.92 : 1.15 })

      if (isLowBasin && pts.length > 14) {
        const oxbow: number[][] = []
        const iStart = Math.floor(pts.length * 0.18), iEnd = Math.floor(pts.length * 0.82)
        for (let idx = iStart; idx <= iEnd; idx++) {
          const u = (idx - iStart) / Math.max(1, iEnd - iStart)
          const a = pts[Math.max(0, idx - 1)], b = pts[Math.min(pts.length - 1, idx + 1)]
          const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
          const bow = Math.sin(Math.PI * u) * (46 + rnd() * 6) * sideBase
          oxbow.push([pts[idx][0] - ((b[1] - a[1]) / tl) * bow, pts[idx][1] + ((b[0] - a[0]) / tl) * bow, 11 + 6 * Math.sin(Math.PI * u), 1.35])
        }
        rivers.push({ id: rivers.length, kind: 'valley', pts: oxbow, flowSpeed: 0.85 })

        const mid = pts[Math.floor(pts.length * (0.45 + rnd() * 0.18))]
        lagoons.push({
          x: mid[0] + sideBase * 22, z: mid[1] - sideBase * 14,
          rx: 52 + rnd() * 22, rz: 36 + rnd() * 16, rot: rnd() * Math.PI,
          y: sampleHgtRaw(mid[0], mid[1]),
        })

        // Outflow river carving a dramatic emerald gorge through the outer mountains
        const endPt = pts[pts.length - 1]
        const outAng = Math.atan2(endPt[1] - cz, endPt[0] - cx)
        const outflow: number[][] = [[endPt[0], endPt[1], 21, 1.5]]
        let rx0 = endPt[0], rz0 = endPt[1]
        const baseOutY = sampleHgtRaw(rx0, rz0)
        for (let st = 1; st <= 64; st++) {
          const ang = outAng + Math.sin(st * 0.26 + seg) * 0.46
          rx0 += Math.cos(ang) * 15; rz0 += Math.sin(ang) * 15
          if (rx0 < ox + 22 || rz0 < oz + 22 || rx0 > ox + size - 22 || rz0 > oz + size - 22) break
          outflow.push([rx0, rz0, 21 + Math.min(18, st * 0.34), 2.1])
        }
        if (outflow.length > 8) {
          for (const qp of outflow) {
            const canyonR = qp[2] + 44
            const ci0 = clamp(Math.floor((qp[0] - canyonR - ox) / C), 1, N - 2)
            const ci1 = clamp(Math.ceil((qp[0] + canyonR - ox) / C), 1, N - 2)
            const cj0 = clamp(Math.floor((qp[1] - canyonR - oz) / C), 1, N - 2)
            const cj1 = clamp(Math.ceil((qp[1] + canyonR - oz) / C), 1, N - 2)
            for (let cj = cj0; cj <= cj1; cj++) for (let ci = ci0; ci <= ci1; ci++) {
              const k = cj * N + ci
              if (edge[k] < 6) continue
              const d = Math.hypot(ox + (ci + 0.5) * C - qp[0], oz + (cj + 0.5) * C - qp[1])
              if (d >= canyonR) continue
              const carveK = (1 - sm(clamp((d - qp[2] * 0.85) / (canyonR - qp[2] * 0.85), 0, 1))) * sm(clamp((edge[k] - 6) / 24, 0, 1))
              const targetY = baseOutY - 0.8
              if (hgt[k] > targetY) hgt[k] = hgt[k] * (1 - carveK) + targetY * carveK
            }
          }
          rivers.push({ id: rivers.length, kind: 'valley', pts: outflow, flowSpeed: 0.95 })
        }
      }
    }

    // 3. Mountain headwater tributaries pouring seamlessly into the valley rivers + summit spring tarn
    const centralPk = peaks.find((pk) => pk.kind === 'central')
    const tribSources: Array<{ pk: MountainPeak; target: number[]; wide?: boolean }> = []
    if (centralPk) {
      for (let s = 0; s < 3; s++) {
        const p = paths[Math.floor((s / 3) * n + 1) % n]
        tribSources.push({ pk: centralPk, target: p.pts[Math.floor(p.pts.length * 0.5)], wide: true })
      }
    }
    const valleyPeaks = peaks
      .filter((pk) => pk.kind === 'ridge')
      .map((pk) => {
        let nearPt = paths[0].pts[0], nearD = 1e9
        for (let k = 0; k < n; k++) for (let i = 0; i < paths[k].pts.length; i += 5) {
          const q = paths[k].pts[i], d = Math.hypot(q[0] - pk.x, q[1] - pk.z)
          if (d < nearD) { nearD = d; nearPt = q }
        }
        return { pk, target: nearPt, nearD }
      })
      .filter((item) => item.nearD < 620)
      .sort((a, b) => a.nearD - b.nearD)
    for (const vp of valleyPeaks.slice(0, 9)) tribSources.push({ pk: vp.pk, target: vp.target })

    for (let t = 0; t < tribSources.length; t++) {
      const { pk, target, wide } = tribSources[t]
      const baseAng = Math.atan2(target[1] - pk.z, target[0] - pk.x)
      let sx = pk.x + Math.cos(baseAng) * pk.radius * (wide ? 0.2 : 0.25)
      let sz = pk.z + Math.sin(baseAng) * pk.radius * (wide ? 0.2 : 0.25)
      const startY = sampleHgtRaw(sx, sz)
      if (startY < 92) continue
      const streamPts: number[][] = [[sx, sz, wide ? 7.5 : 5.2, 1.3]]
      let dirX = Math.cos(baseAng), dirZ = Math.sin(baseAng), reachedValley = false, endY = startY
      for (let step = 1; step <= 85; step++) {
        const gx = (sampleHgtRaw(sx - C * 1.6, sz) - sampleHgtRaw(sx + C * 1.6, sz)) / (3.2 * C)
        const gz = (sampleHgtRaw(sx, sz - C * 1.6) - sampleHgtRaw(sx, sz + C * 1.6)) / (3.2 * C)
        const gl = Math.hypot(gx, gz)
        const toTx = target[0] - sx, toTz = target[1] - sz, toL = Math.hypot(toTx, toTz) || 1
        dirX = gl > 0.02 ? (gx / gl) * 0.56 + (toTx / toL) * 0.44 : toTx / toL
        dirZ = gl > 0.02 ? (gz / gl) * 0.56 + (toTz / toL) * 0.44 : toTz / toL
        const dl = Math.hypot(dirX, dirZ) || 1
        dirX /= dl; dirZ /= dl
        const wig = Math.sin(step * 0.34 + t * 1.9) * 0.28
        const wx = dirX - dirZ * wig, wz = dirZ + dirX * wig, wl = Math.hypot(wx, wz) || 1
        const nx = sx + (wx / wl) * 11, nz = sz + (wz / wl) * 11
        if (nx < ox + 36 || nz < oz + 36 || nx > ox + size - 36 || nz > oz + size - 36) break
        sx = nx; sz = nz; endY = sampleHgtRaw(sx, sz)
        const hw = (wide ? 7.5 : 5.2) + clamp(step / 48, 0, 1) * (wide ? 12.5 : 8.5)
        streamPts.push([sx, sz, hw, 1.4])
        if (edge[clamp(Math.floor((sz - oz) / C), 0, N - 1) * N + clamp(Math.floor((sx - ox) / C), 0, N - 1)] < -8 && step > 8) {
          streamPts.push([sx + dirX * 14, sz + dirZ * 14, hw * 1.2, 0.85])
          reachedValley = true
          if (lagoons.length < 10 && !lagoons.some((lg) => Math.hypot(lg.x - sx, lg.z - sz) < 145)) {
            lagoons.push({ x: sx, z: sz, rx: 30 + rnd() * 14, rz: 23 + rnd() * 11, rot: rnd() * Math.PI, y: endY })
          }
          break
        }
      }
      if (reachedValley && streamPts.length >= 8 && startY - endY > 28) {
        rivers.push({ id: rivers.length, kind: 'tributary', pts: streamPts, flowSpeed: wide ? 1.55 : 1.4 })
      }
    }
    if (centralPk) {
      const hs = rivers.find((r) => r.kind === 'tributary')?.pts[0]
      if (hs) lagoons.push({ x: hs[0], z: hs[1], rx: 28, rz: 22, rot: rnd() * Math.PI, y: sampleHgtRaw(hs[0], hs[1]) })
    }

    // 4. Paint riverMask (channels + lagoons + sandy/mossy riparian banks) & carve gentle smooth riverbeds
    const stampWater = (wx: number, wz: number, hw: number) => {
      const outer = hw + 13
      const i0 = clamp(Math.floor((wx - outer - ox) / C), 1, N - 2)
      const i1 = clamp(Math.ceil((wx + outer - ox) / C), 1, N - 2)
      const j0 = clamp(Math.floor((wz - outer - oz) / C), 1, N - 2)
      const j1 = clamp(Math.ceil((wz + outer - oz) / C), 1, N - 2)
      for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
        const d = Math.hypot(ox + (i + 0.5) * C - wx, oz + (j + 0.5) * C - wz)
        if (d >= outer) continue
        const k = j * N + i
        const m = d < hw ? 0.45 + 0.55 * (1 - sm(clamp(d / hw, 0, 1))) : 0.45 * (1 - sm(clamp((d - hw) / 13, 0, 1)))
        if (m > riverMask[k]) riverMask[k] = m
      }
    }
    for (const rv of rivers) {
      for (let i = 0; i < rv.pts.length - 1; i++) {
        const a = rv.pts[i], b = rv.pts[i + 1]
        const steps = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / (C * 0.65)))
        for (let s = 0; s <= steps; s++) {
          const u = s / steps
          stampWater(a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u)
        }
      }
    }
    for (const lg of lagoons) {
      const rMax = Math.max(lg.rx, lg.rz) + 15
      const cs = Math.cos(lg.rot), sn = Math.sin(lg.rot)
      const i0 = clamp(Math.floor((lg.x - rMax - ox) / C), 1, N - 2)
      const i1 = clamp(Math.ceil((lg.x + rMax - ox) / C), 1, N - 2)
      const j0 = clamp(Math.floor((lg.z - rMax - oz) / C), 1, N - 2)
      const j1 = clamp(Math.ceil((lg.z + rMax - oz) / C), 1, N - 2)
      for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
        const dx = ox + (i + 0.5) * C - lg.x, dz = oz + (j + 0.5) * C - lg.z
        const d = Math.hypot((dx * cs + dz * sn) / lg.rx, (-dx * sn + dz * cs) / lg.rz)
        if (d >= 1.32) continue
        const k = j * N + i
        const m = d < 1 ? 0.45 + 0.55 * (1 - sm(d)) : 0.45 * (1 - sm((d - 1) / 0.32))
        if (m > riverMask[k]) riverMask[k] = m
        if (d < 1.15 && edge[k] > -18) {
          const flat = (1 - sm(clamp(d / 1.15, 0, 1))) * 0.55
          hgt[k] = hgt[k] * (1 - flat) + (lg.y - 1.1) * flat
        }
      }
      lg.y = sampleHgtRaw(lg.x, lg.z) + 1.15
    }
    for (let k = 0; k < N * N; k++) {
      const m = riverMask[k]
      if (m > 0.4) hgt[k] -= sm(clamp((m - 0.4) / 0.6, 0, 1)) * (edge[k] > 4 ? 1.85 : 0.9)
    }
  }
  const cellAt = (x: number, z: number) => {
    const i = Math.floor((x - ox) / C)
    const j = Math.floor((z - oz) / C)
    return i >= 0 && j >= 0 && i < N && j < N ? j * N + i : -1
  }
  // ramps: a gentle wedge, then a jump
  const ramps: number[][] = []
  const addRamp = (p: Path, f: number) => {
    const i = clamp(Math.floor(p.pts.length * f), 3, p.pts.length - 4)
    const a = p.pts[i - 1], b = p.pts[i + 1], m = p.pts[i]
    let tx = b[0] - a[0], tz = b[1] - a[1]
    const l = Math.hypot(tx, tz) || 1
    tx /= l; tz /= l
    const c0 = cellAt(m[0], m[1])
    if (c0 < 0) return
    const base = hgt[c0]
    const STEPS = 7
    for (let k = 0; k < STEPS; k++) {
      for (let lt = -3; lt <= 3; lt++) {
        const c = cellAt(m[0] + tx * k * C * 0.95 - tz * lt * C * 0.9, m[1] + tz * k * C * 0.95 + tx * lt * C * 0.9)
        if (c < 0) continue
        const taper = 1 - Math.pow(Math.abs(lt) / 4, 2)
        hgt[c] = Math.max(hgt[c], base + 5 * ((k + 1) / STEPS) * taper)
      }
    }
    ramps.push([m[0], m[1]])
  }
  for (const p of paths) {
    if (forest && rapidSegments.has(p.seg)) continue
    if (p.kind === 'cut') addRamp(p, 0.42 + rnd() * 0.2)
    else if (rnd() < 0.3) addRamp(p, 0.3 + rnd() * 0.4)
  }

  // ── hazards
  const obstacles: Obstacle[] = []
  const hz = clamp(o.hazards, 0, 1.5)
  const mk = (t: Obstacle['type'], x: number, z: number, r: number, path: number, extra: Partial<Obstacle> = {}): Obstacle => ({
    id: obstacles.length, type: t, x, z, r, period: 4, phase: rnd(), duty: 0.4, len: 0, w: 0, path, broken: false, ...extra,
  })
  for (const p of paths) {
    const cnt = Math.round((p.len / (p.kind === 'cut' ? 110 : 200)) * hz)
    for (let h = 0; h < cnt; h++) {
      const f = 0.12 + (0.76 * (h + 0.3 + rnd() * 0.4)) / Math.max(1, cnt)
      if (forest && p.kind === 'main' && rapidSegments.has(p.seg) && f > 0.15 && f < 0.74) continue
      const i = clamp(Math.floor(p.pts.length * f), 3, p.pts.length - 4)
      const m = p.pts[i]
      const a = p.pts[i - 1], b = p.pts[i + 1]
      let tx = b[0] - a[0], tz = b[1] - a[1]
      const l = Math.hypot(tx, tz) || 1
      tx /= l; tz /= l
      const px = -tz, pz = tx
      const roll = rnd()
      const cutW = p.kind === 'cut'
      if (roll < (cutW ? 0.3 : 0.34)) {
        const side = rnd() < 0.5 ? -1 : 1
        const off = side * p.halfW * (0.2 + rnd() * 0.35)
        obstacles.push(mk('rock', m[0] + px * off, m[1] + pz * off, 5 + rnd() * 5, p.id))
        if (rnd() < 0.6) obstacles.push(mk('rock', m[0] - px * off * 0.7, m[1] - pz * off * 0.7, 4 + rnd() * 4, p.id))
      } else if (roll < (cutW ? 0.58 : 0.6)) {
        const e = p.halfW - 9
        obstacles.push(mk('roller', m[0], m[1], 7, p.id, { ax: m[0] - px * e, az: m[1] - pz * e, bx: m[0] + px * e, bz: m[1] + pz * e, period: 3 + rnd() * 2.5 }))
      } else if (roll < (cutW ? 0.68 : 0.82)) {
        obstacles.push(mk('fan', m[0], m[1], 3.5, p.id, { len: p.halfW * (cutW ? 1.0 : 1.3), w: (rnd() < 0.5 ? -1 : 1) * (1.0 + rnd() * 0.7), phase: rnd() * 6.28 }))
      } else {
        const off = (rnd() - 0.5) * p.halfW * 1.1
        obstacles.push(mk('geyser', m[0] + px * off, m[1] + pz * off, 10, p.id, { period: 4 + rnd() * 2, duty: 0.35 }))
      }
    }
    // Keep a shortcut's breakable wall clear of the starting area and main route.
    if (p.kind === 'cut' && p.hidden) {
      let best: number[] | null = null
      let bestClearance = 0
      const start = Math.max(3, Math.floor(p.pts.length * 0.2))
      const end = Math.min(p.pts.length - 3, Math.floor(p.pts.length * 0.75))
      for (let i = start; i < end; i++) {
        const point = p.pts[i]
        let clearance = Infinity
        for (const main of paths.slice(0, n)) {
          for (const q of main.pts) clearance = Math.min(clearance, Math.hypot(point[0] - q[0], point[1] - q[1]) - main.halfW)
        }
        if (clearance > bestClearance) { bestClearance = clearance; best = point }
      }
      if (best && bestClearance > p.halfW + 8) obstacles.push(mk('rockwall', best[0], best[1], p.halfW + 3, p.id))
    }
  }
  // boost pads
  const pads: ArenaPad[] = []
  const nPads = Math.max(0, Math.round(o.pads))
  for (let k = 0; k < nPads; k++) {
    const p = paths[Math.floor(rnd() * paths.length)]
    const i = clamp(Math.floor(p.pts.length * (0.2 + rnd() * 0.6)), 3, p.pts.length - 4)
    const m = p.pts[i]
    pads.push({ x: m[0] + (rnd() - 0.5) * p.halfW * 0.8, z: m[1] + (rnd() - 0.5) * p.halfW * 0.8, r: 9 })
  }
  void ramps

  const gcell = (i: number, j: number) => hgt[clamp(j, 0, N - 1) * N + clamp(i, 0, N - 1)]
  const groundAt = (x: number, z: number) => {
    const fx = (x - ox) / C - 0.5
    const fz = (z - oz) / C - 0.5
    const i = Math.floor(fx), j = Math.floor(fz)
    const tx = fx - i, tz = fz - j
    return (gcell(i, j) * (1 - tx) + gcell(i + 1, j) * tx) * (1 - tz) + (gcell(i, j + 1) * (1 - tx) + gcell(i + 1, j + 1) * tx) * tz
  }
  // ── Zone-Distinct Canyon Hydrology: Grand Oasis Paradise Basins, Sapphire Mirror-Ice Lakes & Molten Magma Seas!
  // Placed specifically in the LOW canyon valley & downhill cascade segments so high mesa rims stay dry & arid
  // while low basins burst into breathtaking contrast (lush Havasu oasis / glowing aurora lake / blazing lava caldera)!
  if (!forest) {
    const isDesert = o.planet === 'desert'
    const isIce = o.planet === 'ice'
    const isLava = o.planet === 'lava'
    for (let seg = 0; seg < n; seg++) {
      const hStart = gateHeights[seg], hEnd = gateHeights[(seg + 1) % n]
      const isLowOasisBasin = Math.max(hStart, hEnd) < 28
      const isCascadeDrop = hStart - hEnd > 22
      if (!isLowOasisBasin && !isCascadeDrop) continue
      const p = paths[seg]
      const M = p.pts.length
      if (M < 10) continue
      const pts: number[][] = []
      const sideBase = seg % 2 === 0 ? 1 : -1
      const ph = seg * 1.9 + 0.5
      const s0 = isCascadeDrop ? Math.floor(M * 0.12) : 0
      const s1 = isCascadeDrop ? M - 1 : M - 1
      for (let i = s0; i <= s1; i++) {
        const u = (i - s0) / Math.max(1, s1 - s0)
        const a = p.pts[Math.max(0, i - 1)], b = p.pts[Math.min(M - 1, i + 1)]
        const tl = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1
        const rx = -(b[1] - a[1]) / tl, rz = (b[0] - a[0]) / tl
        const off = Math.sin(u * Math.PI * 2.2 + ph) * (p.halfW * 0.62) + sideBase * p.halfW * 0.2
        const baseW = isLowOasisBasin ? (isLava ? 20 : isIce ? 24 : 21) : 15
        const hw = (baseW + 8 * (0.5 + 0.5 * Math.sin(u * Math.PI * 3 + seg))) * (0.7 + 0.3 * Math.sin(Math.PI * u))
        pts.push([p.pts[i][0] + rx * off, p.pts[i][1] + rz * off, hw, 0.8])
      }
      rivers.push({
        id: rivers.length,
        kind: isCascadeDrop || isLava ? 'rapid' : 'valley',
        pts,
        flowSpeed: isLava ? (isCascadeDrop ? 0.95 : 0.55) : isIce ? 0.22 : (isCascadeDrop ? 1.35 : 0.85),
      })
      // Dramatic expansive Oasis Lagoon / Crystal Lake / Magma Caldera Pool in the heart of each low basin!
      const anchor = pts[Math.floor(pts.length * (isCascadeDrop ? 0.86 : 0.5))]
      const lx = anchor[0] + sideBase * 14
      const lz = anchor[1] - sideBase * 10
      if (lagoons.length < 6 && !lagoons.some((lg) => Math.hypot(lg.x - lx, lg.z - lz) < 165)) {
        lagoons.push({
          x: lx, z: lz,
          rx: (isDesert ? 44 : 48) + rnd() * 18,
          rz: (isDesert ? 32 : 35) + rnd() * 14,
          rot: rnd() * Math.PI,
          y: sampleHgtRaw(lx, lz) + 0.55,
        })
      }
    }
    // Paint smooth canyon riverMask (wet dark sand / frost rim / scorched glowing basalt crust along banks!)
    const stampCanyonChannel = (wx: number, wz: number, hw: number) => {
      const outer = hw + 10
      const i0 = clamp(Math.floor((wx - outer - ox) / C), 1, N - 2)
      const i1 = clamp(Math.ceil((wx + outer - ox) / C), 1, N - 2)
      const j0 = clamp(Math.floor((wz - outer - oz) / C), 1, N - 2)
      const j1 = clamp(Math.ceil((wz + outer - oz) / C), 1, N - 2)
      for (let j = j0; j <= j1; j++) {
        const pz = oz + (j + 0.5) * C
        for (let i = i0; i <= i1; i++) {
          const k = j * N + i
          if (edge[k] > 3) continue
          const d = Math.hypot(ox + (i + 0.5) * C - wx, pz - wz)
          if (d >= outer) continue
          const m = d < hw ? 0.45 + 0.55 * (1 - sm(d / hw)) : 0.45 * (1 - sm((d - hw) / 10))
          if (m > riverMask[k]) riverMask[k] = m
        }
      }
    }
    for (const rv of rivers) {
      for (let i = 0; i < rv.pts.length - 1; i++) {
        const a = rv.pts[i], b = rv.pts[i + 1]
        const steps = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / (C * 0.7)))
        for (let s = 0; s <= steps; s++) {
          const u = s / steps
          stampCanyonChannel(a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u)
        }
      }
    }
    for (const lg of lagoons) {
      stampCanyonChannel(lg.x, lg.z, (lg.rx + lg.rz) * 0.5)
    }
  }

  const rcell = (i: number, j: number) => riverMask[clamp(j, 0, N - 1) * N + clamp(i, 0, N - 1)]
  const riverAt = (x: number, z: number) => {
    const fx = (x - ox) / C - 0.5
    const fz = (z - oz) / C - 0.5
    const i = Math.floor(fx), j = Math.floor(fz)
    const tx = fx - i, tz = fz - j
    return (rcell(i, j) * (1 - tx) + rcell(i + 1, j) * tx) * (1 - tz) + (rcell(i, j + 1) * (1 - tx) + rcell(i + 1, j + 1) * tx) * tz
  }
  return { opts: o, n, cells: N, C, ox, oz, size, hgt, lat, edge, riverMask, gates, paths, segs, obstacles, pads, rapids, rivers, lagoons, peaks, meanSeg, groundAt, riverAt, bounds }
}

// ───────────────────────────────────────────────────────────────── the race

export class ArenaShip {
  id = 0
  name = ''
  isPlayer = false
  skin: VehicleId = 'racer'
  color = 0
  skill = 0.5
  ai = false
  x = 0
  z = 0
  y = 0
  vy = 0
  vx = 0
  vz = 0
  yaw = 0
  yawV = 0
  driftT = 0
  drifting = false
  v = 0
  vlat = 0
  steerNow = 0
  throttle = 0
  shield = 100
  energy = 0.5
  boostT = 0
  turboOn = false
  wreckT = 0
  invuln = 0
  hitCd = 0
  scrape = 0
  hurtAt = -99
  scrapeSide = 1
  airborne = false
  flying = false
  climbNow = 0
  landImpact = 0
  pitch = 0
  cp = 0
  lap = 0
  dist = 0
  finished = false
  finishTime = 0
  lapStart = 0
  lapTimes: number[] = []
  best = Infinity
  rank = 1
  padsHit = 0
  lastInput: Input = { throttle: 0, brake: 0, steer: 0, abL: 0, abR: 0, turbo: false }
  // AI
  pathId = -1
  pi = 0
  stuck = 0
  mistake = 0
  // unused here, kept so the page can treat both modes alike
  s = 0
  vxl = 0
}

const NAMES = ['Kira', 'Rex', 'Nyx', 'Vega', 'Juno', 'Axel', 'Zed', 'Mako', 'Sora', 'Hiro', 'Luna', 'Dax', 'Rin', 'Kane', 'Ivo', 'Tess']
const HOVER = 1.5

export class ArenaSim {
  arena: Arena
  p: RaceParams
  ships: ArenaShip[] = []
  state: 'demo' | 'countdown' | 'racing' | 'finished' = 'demo'
  time = 0
  clock = 0
  count = 3.99
  events: RaceEvent[] = []
  player!: ArenaShip
  results: ArenaShip[] = []
  private afterFinish = 0
  private gasHeld = 0
  private brokenWalls = new Set<number>()

  constructor(arena: Arena, p: RaceParams) {
    this.arena = arena
    this.p = p
    this.setup('demo')
  }
  setArena(a: Arena) {
    this.arena = a
  }
  top() {
    return CLASS_TOP[clamp(Math.round(this.p.shipClass), 0, 3)]
  }

  topFor(ship: ArenaShip) {
    return this.top() * getVehicleStats(ship.skin).speed
  }

  syncVehicleSelections() {
    for (const ship of this.ships) ship.skin = vehicleForRacer(this.p.skin, this.p.botSkins, ship.id)
  }

  isBroken(o: Obstacle) {
    return this.brokenWalls.has(o.id)
  }

  setup(mode: 'demo' | 'countdown') {
    const A = this.arena
    const count = 1 + clamp(Math.round(this.p.bots), 0, 15)
    this.ships = []
    this.events.length = 0
    this.time = 0
    this.count = 3.99
    this.afterFinish = 0
    this.results = []
    this.gasHeld = 0
    this.brokenWalls.clear()
    const g0 = A.gates[0]
    const px = -g0.nz
    const pz = g0.nx
    for (let i = 0; i < count; i++) {
      const sh = new ArenaShip()
      sh.id = i
      sh.isPlayer = i === 0
      sh.ai = i !== 0 || mode === 'demo'
      sh.name = i === 0 ? 'Kamu' : NAMES[(i * 5 + 3) % NAMES.length]
      sh.color = i
      sh.skill = i === 0 ? 0.7 : clamp(this.p.botSkill + Math.sin(i * 12.9898) * 0.125, 0.05, 1)
      const row = Math.floor(i / 2)
      const col = i % 2 === 0 ? -1 : 1
      const back = 16 + row * 12 + (col > 0 ? 5 : 0)
      const lat = col * 8
      sh.x = g0.x - g0.nx * back + px * lat
      sh.z = g0.z - g0.nz * back + pz * lat
      sh.yaw = Math.atan2(g0.nx, -g0.nz)
      sh.y = A.groundAt(sh.x, sh.z) + HOVER
      sh.shield = this.p.shieldMax
      sh.energy = 0.5
      sh.invuln = 1
      this.ships.push(sh)
    }
    this.player = this.ships[0]
    this.syncVehicleSelections()
    this.state = mode
    this.refreshDist()
  }
  startRace() {
    this.setup('countdown')
  }
  finishedAll() {
    return this.ships.every((s) => s.finished)
  }

  private gateDist(sh: ArenaShip) {
    const A = this.arena
    const g = A.gates[sh.cp % A.n]
    return Math.hypot(g.x - sh.x, g.z - sh.z)
  }
  private refreshDist() {
    const A = this.arena
    for (const sh of this.ships) {
      const d = this.gateDist(sh)
      if (sh.cp === 0) sh.dist = -d
      else {
        const prev = A.gates[(sh.cp - 1) % A.n]
        const nxt = A.gates[sh.cp % A.n]
        const seg = Math.max(60, Math.hypot(nxt.x - prev.x, nxt.z - prev.z))
        sh.dist = (sh.cp - 1) * A.meanSeg + clamp(1 - d / seg, 0, 1) * A.meanSeg
      }
    }
  }
  ranking(): ArenaShip[] {
    const list = this.ships.slice()
    list.sort((a, b) => {
      if (a.finished && b.finished) return a.finishTime - b.finishTime
      if (a.finished) return -1
      if (b.finished) return 1
      return b.dist - a.dist
    })
    list.forEach((s, i) => (s.rank = i + 1))
    return list
  }

  // ── hazards as a function of time
  hazard(o: Obstacle, t: number) {
    if (o.type === 'roller') {
      const u = 0.5 + 0.5 * Math.sin((t / o.period) * Math.PI * 2 + o.phase * 6.28)
      return { x: o.ax! + (o.bx! - o.ax!) * u, z: o.az! + (o.bz! - o.az!) * u, active: true, warn: false, u }
    }
    if (o.type === 'geyser') {
      const ph = (t + o.phase * o.period) % o.period
      const on = o.duty * o.period
      return { x: o.x, z: o.z, active: ph < on, warn: ph > o.period - 0.9, u: ph < on ? 1 - ph / on : 0 }
    }
    if (o.type === 'fan') return { x: o.x, z: o.z, active: true, warn: false, u: o.phase + o.w * t }
    return { x: o.x, z: o.z, active: true, warn: false, u: 0 }
  }

  private blockedAt(px: number, pz: number, y: number) {
    const A = this.arena
    const R = 3.4
    const lim = y + 5
    return A.groundAt(px, pz) > lim || A.groundAt(px + R, pz) > lim || A.groundAt(px - R, pz) > lim || A.groundAt(px, pz + R) > lim || A.groundAt(px, pz - R) > lim
  }

  private hurt(sh: ArenaShip, dmg: number) {
    if (sh.invuln > 0 || sh.wreckT > 0) return
    sh.shield -= dmg * getVehicleStats(sh.skin).damage
    sh.hurtAt = this.clock
  }

  // ── Smart Tactical AI Pilot: route time-cost selection, predictive TTA multi-lane planner, apex cutting, drift-boost & strategic turbo
  private choosePath(b: ArenaShip) {
    const A = this.arena
    const g = b.cp % A.n
    const seg = (g - 1 + A.n) % A.n
    const opts = A.segs[seg]
    const vRef = Math.max(85, this.topFor(b) * 0.85)
    const shield01 = b.shield / Math.max(1, this.p.shieldMax)
    let bestId = opts[0]
    let bestCost = Infinity

    for (let k = 0; k < opts.length; k++) {
      const pid = opts[k]
      const pt = A.paths[pid]
      let cost = pt.len / vRef // base travel time in seconds
      // Assess hazards & sealed rockwalls on this branch
      let sealedWall = false
      let hzCount = 0
      for (const o of A.obstacles) {
        if (o.path !== pid) continue
        if (o.type === 'rockwall' && !this.brokenWalls.has(o.id)) sealedWall = true
        else hzCount++
      }
      cost += hzCount * (0.28 - 0.16 * b.skill)
      if (sealedWall) {
        const canSmash = b.skill > 0.38 && shield01 > 0.36 && (b.energy > 0.28 || b.v > 105)
        cost += canSmash ? 0.45 : 99
      }
      // Low-skill bots sometimes overlook shorter cuts; high-skill bots pick fast cuts decisively while spreading across tight braids
      if (pt.kind === 'cut') {
        const awareness = clamp(b.skill * 1.18 - (pt.hidden ? 0.18 : 0), 0.08, 1)
        const roll = Math.sin(b.id * 91.7 + b.cp * 17.3 + k * 31.1) * 0.5 + 0.5
        if (roll > awareness) cost += 4.5
      }
      // Subtle per-pilot variety so the pack fans out naturally across nearly equal braided island paths
      cost += (Math.sin(b.id * 43.1 + pid * 11.7 + b.cp * 5.3) * 0.5) * 0.38
      if (cost < bestCost) {
        bestCost = cost
        bestId = pid
      }
    }
    b.pathId = bestId
    b.pi = 0
  }

  private aiInput(b: ArenaShip, dt: number): Input {
    const A = this.arena
    const p = this.p
    const sk = b.skill
    const top = this.topFor(b) * (0.9 + 0.105 * sk) * (b.isPlayer ? 1 : 0.992)
    let rub = 1
    if (p.rubber > 0 && !b.isPlayer && this.state === 'racing') {
      rub = 1 + p.rubber * 0.1 * clamp((this.player.dist - b.dist) / 460, -1, 1)
    }
    const vTop = top * rub
    const g = A.gates[b.cp % A.n]

    let tx = g.x
    let tz = g.z
    let rtx = Math.sin(b.yaw), rtz = -Math.cos(b.yaw)
    let turnSigned = 0
    let turnAbs = 0
    let farTurn = 0
    let route: Path | null = null
    const distToGate = Math.hypot(g.x - b.x, g.z - b.z)

    if (b.cp > 0) {
      if (b.pathId < 0 || A.paths[b.pathId].seg !== (b.cp % A.n - 1 + A.n) % A.n) this.choosePath(b)
      route = A.paths[b.pathId]
    }

    let usableHalfW = 36
    let baseLatTarget = 0
    if (route) {
      const pts = route.pts
      usableHalfW = Math.max(12, route.halfW - 8.5)
      let best = b.pi
      let bd = 1e9
      const scanStart = Math.max(0, b.pi - 3)
      const scanEnd = Math.min(pts.length, b.pi + 28)
      for (let i = scanStart; i < scanEnd; i++) {
        const d = Math.hypot(pts[i][0] - b.x, pts[i][1] - b.z)
        if (d < bd) { bd = d; best = i }
      }
      b.pi = best

      // Adaptive velocity-scaled spline lookahead (tighter in hairpins, farther on high-speed sweepers)
      const j1 = Math.min(pts.length - 1, best + 4)
      const j2 = Math.min(pts.length - 1, best + 9)
      const j3 = Math.min(pts.length - 1, best + 16)
      const h1 = Math.atan2(pts[j1][0] - pts[best][0], -(pts[j1][1] - pts[best][1]))
      const h2 = Math.atan2(pts[j2][0] - pts[j1][0], -(pts[j2][1] - pts[j1][1]))
      const h3 = Math.atan2(pts[j3][0] - pts[j2][0], -(pts[j3][1] - pts[j2][1]))
      turnSigned = wrapA(h2 - h1)
      turnAbs = Math.abs(turnSigned)
      farTurn = Math.abs(wrapA(h3 - h2))

      const lookSteps = clamp(Math.round((b.v * (0.48 - Math.min(0.18, turnAbs * 0.28))) / 10), 3, 13)
      const ti = Math.min(pts.length - 1, best + lookSteps)
      const ta = pts[Math.max(0, ti - 1)], tb = pts[Math.min(pts.length - 1, ti + 1)]
      const tl = Math.hypot(tb[0] - ta[0], tb[1] - ta[1]) || 1
      rtx = (tb[0] - ta[0]) / tl
      rtz = (tb[1] - ta[1]) / tl
      tx = pts[ti][0]
      tz = pts[ti][1]

      // Out-in-out apex racing line: hug the inside apex of upcoming corners, widen slightly before far bends!
      const apexShift = clamp(turnSigned * 1.15, -0.58, 0.58) * usableHalfW * (0.35 + 0.65 * sk)
      const personalLane = Math.sin(b.id * 37.3) * usableHalfW * 0.22 * (1 - sk * 0.55)
      baseLatTarget = clamp(apexShift + personalLane, -usableHalfW * 0.72, usableHalfW * 0.72)

      // Smoothly converge straight through the checkpoint gate center when close
      if (best >= pts.length - 4 || distToGate < 78) {
        tx = g.x; tz = g.z
        rtx = g.nx; rtz = g.nz
        usableHalfW = Math.min(usableHalfW, g.r * 0.68)
        baseLatTarget *= clamp(distToGate / 78, 0, 1)
      }
    }

    const rrx = -rtz, rrz = rtx // right-hand vector of route at target
    const fx = Math.sin(b.yaw), fz = -Math.cos(b.yaw)
    const rx = Math.cos(b.yaw), rz = Math.sin(b.yaw)
    const curLat = route
      ? (b.x - route.pts[b.pi][0]) * rrx + (b.z - route.pts[b.pi][1]) * rrz
      : 0

    // ── Predictive Time-To-Arrival (TTA) 7-lane corridor scorer (dodges moving hazards, grabs boost pads & overtakes cleanly!)
    const LANES = [-0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75]
    const laneCost = new Float32Array(7)
    for (let li = 0; li < 7; li++) {
      const candLat = LANES[li] * usableHalfW
      // Prefer racing line apex + smooth low-jerk continuity from current lateral position
      laneCost[li] =
        Math.abs(candLat - baseLatTarget) * 0.045 +
        Math.abs(candLat - curLat) * 0.022
    }

    let wantTurbo = false
    let slow = 1
    const spdSafe = Math.max(32, b.v)
    const lookDist = 48 + b.v * 0.72

    // 1. Score all upcoming obstacles at their PREDICTED future position (clock + TTA)!
    for (const o of A.obstacles) {
      if (o.type === 'rockwall' && this.brokenWalls.has(o.id)) continue
      const dx0 = o.x - b.x, dz0 = o.z - b.z
      const maxCheck = o.type === 'roller' ? lookDist + 75 : lookDist + 25
      if (Math.abs(dx0) > maxCheck || Math.abs(dz0) > maxCheck) continue
      const fdApprox = dx0 * fx + dz0 * fz
      if (fdApprox < -6 || fdApprox > lookDist) continue

      if (o.type === 'rockwall') {
        if (fdApprox < 72 && (sk > 0.35 && b.energy > 0.18)) wantTurbo = true
        continue
      }

      // Predict exact hazard state at arrival instant!
      const tta = clamp(fdApprox / spdSafe, 0, 2.2) * (0.45 + 0.55 * sk)
      const fut = this.hazard(o, this.clock + tta)
      if (o.type === 'geyser' && !fut.active && !fut.warn) continue

      const relX = fut.x - b.x, relZ = fut.z - b.z
      const fd = relX * fx + relZ * fz
      if (fd < -4 || fd > lookDist) continue
      const hLat = route
        ? (fut.x - route.pts[b.pi][0]) * rrx + (fut.z - route.pts[b.pi][1]) * rrz
        : relX * rx + relZ * rz

      let dangerR = o.r + 7.5
      if (o.type === 'fan') {
        // Compute effective lateral sweep of the rotating blade at arrival time!
        const ang = fut.u
        const crossSpan = Math.abs(Math.cos(ang) * rrx + Math.sin(ang) * rrz) * (o.len * 0.5)
        dangerR = Math.max(8.5, crossSpan + 5.5)
      }
      // Protect shield proactively: widen safety margin & prioritize survival when shield is below 55%!
      const caution = b.shield < p.shieldMax * 0.55 ? 1.32 : 1.0
      const safeR = dangerR * caution
      const urgency = clamp(1.4 - fd / lookDist, 0.28, 1.45) * caution
      for (let li = 0; li < 7; li++) {
        const candLat = LANES[li] * usableHalfW
        const gap = Math.abs(candLat - hLat)
        if (gap < safeR) {
          laneCost[li] += ((safeR - gap) / safeR) * 18 * urgency
        }
      }
      if (fd < 42 && Math.abs(relX * rx + relZ * rz) < safeR * 0.78) slow = Math.min(slow, b.shield < p.shieldMax * 0.45 ? 0.68 : 0.78)
    }

    // 2. Attract toward upcoming Boost Pads for free burst speed + turbo energy!
    if (sk > 0.25 && distToGate > 55) {
      for (const pad of A.pads) {
        const dxp = pad.x - b.x, dzp = pad.z - b.z
        if (Math.abs(dxp) > 135 || Math.abs(dzp) > 135) continue
        const fd = dxp * fx + dzp * fz
        if (fd < 8 || fd > 125) continue
        const pLat = route
          ? (pad.x - route.pts[b.pi][0]) * rrx + (pad.z - route.pts[b.pi][1]) * rrz
          : dxp * rx + dzp * rz
        if (Math.abs(pLat) > usableHalfW * 0.92) continue
        const reward = (1.6 + 2.2 * sk) * (1 - fd / 135)
        for (let li = 0; li < 7; li++) {
          const dLat = Math.abs(LANES[li] * usableHalfW - pLat)
          if (dLat < 16) laneCost[li] -= reward * (1 - dLat / 16)
        }
      }
    }

    // 3. Clean overtaking around slower ships ahead (avoid rear-ending & side-slamming)
    for (const other of this.ships) {
      if (other === b || other.wreckT > 0 || other.flying || Math.abs(other.y - b.y) > 6) continue
      const dxo = other.x - b.x, dzo = other.z - b.z
      if (Math.abs(dxo) > 55 || Math.abs(dzo) > 55) continue
      const fd = dxo * fx + dzo * fz
      if (fd < -2 || fd > 46 || b.v < other.v - 8) continue
      const oLat = route
        ? (other.x - route.pts[b.pi][0]) * rrx + (other.z - route.pts[b.pi][1]) * rrz
        : dxo * rx + dzo * rz
      for (let li = 0; li < 7; li++) {
        const gap = Math.abs(LANES[li] * usableHalfW - oLat)
        if (gap < 8.5) laneCost[li] += (1 - gap / 8.5) * 4.2
      }
    }

    // Pick lowest-cost lane and offset target point cleanly along it
    let bestLane = 3
    for (let li = 0; li < 7; li++) if (laneCost[li] < laneCost[bestLane]) bestLane = li
    const chosenLat = route && distToGate > 42 ? LANES[bestLane] * usableHalfW : 0
    const goalX = tx + rrx * chosenLat
    const goalZ = tz + rrz * chosenLat

    // 4. 5-ray terrain cliff/wall fan probe so bots flow smoothly around valley walls without scraping
    let wallSteer = 0
    const probe = (ang: number, dd: number) => {
      const a = b.yaw + ang
      const px = b.x + Math.sin(a) * dd, pz = b.z - Math.cos(a) * dd
      const ahead = A.groundAt(px, pz)
      return ahead > b.y + 4.8 && ahead - A.groundAt(b.x, b.z) > Math.max(8.5, dd * 0.78)
    }
    const near = b.v * 0.34 + 19
    const pLL = probe(-0.58, near * 1.15)
    const pL = probe(-0.26, near * 1.35)
    const pC = probe(0, near) || probe(0, near * 1.65)
    const pR = probe(0.26, near * 1.35)
    const pRR = probe(0.58, near * 1.15)
    if (pC || pL || pR) {
      const leftBlock = (pLL ? 1 : 0) + (pL ? 1.5 : 0)
      const rightBlock = (pRR ? 1 : 0) + (pR ? 1.5 : 0)
      if (leftBlock > rightBlock) wallSteer = 0.85
      else if (rightBlock > leftBlock) wallSteer = -0.85
      else if (pC) wallSteer = turnSigned >= 0 ? 0.9 : -0.9
      if (pC) slow = Math.min(slow, 0.68)
    }

    const desired = Math.atan2(goalX - b.x, -(goalZ - b.z))
    const err = wrapA(desired - b.yaw)
    b.mistake += (Math.sin(this.time * (1.2 + b.id * 0.17) + b.id) - b.mistake) * 0.04
    const wob = b.mistake * Math.pow(1 - sk, 1.45) * 0.22
    const steerGainAI = 2.25 + 0.55 * sk
    const steer = clamp(err * steerGainAI - b.yawV * 0.08 + wallSteer + wob, -1, 1)

    // Precision physics-based braking lookahead along upcoming spline curvature
    let vLimit = vTop
    if (route) {
      const pts = route.pts
      const aLat = 122 + 78 * sk + 42 * p.assist
      for (let i = b.pi + 1; i < Math.min(pts.length - 2, b.pi + 34); i++) {
        const d = (i - b.pi) * 10
        const h1 = Math.atan2(pts[i][0] - pts[i - 1][0], -(pts[i][1] - pts[i - 1][1]))
        const h2 = Math.atan2(pts[i + 2][0] - pts[i][0], -(pts[i + 2][1] - pts[i][1]))
        const kk = Math.abs(wrapA(h2 - h1)) / 15
        const vc = Math.sqrt(aLat / Math.max(kk, 1e-4))
        vLimit = Math.min(vLimit, Math.sqrt(vc * vc + 2 * 82 * Math.max(0, d - 14)))
      }
    }
    const vDes = vLimit * slow
    const eV = b.v - vDes
    const throttle = eV < 3 ? 1 : eV < 14 ? 0.3 : 0
    const brake = eV > 10 ? clamp((eV - 10) / 38, 0, 1) : 0

    // Skilled bots tap airbrakes into sharp corners to pivot fast & harvest real exit drift-boosts!
    const wantAb = sk > 0.52 && turnAbs > 0.38 && Math.abs(err) > 0.24 && b.v > top * 0.52
    const abL = wantAb && steer < -0.45 ? 0.75 : 0
    const abR = wantAb && steer > 0.45 ? 0.75 : 0

    // Smart tactical turbo: rockwall smash, uphill slope boost, clean straightaway exit, or final-lap sprint!
    const uphill = A.groundAt(b.x + fx * 14, b.z + fz * 14) - A.groundAt(b.x, b.z) > 1.8
    const finalGate = this.state === 'racing' && b.cp >= p.laps * A.n && distToGate < 450 && b.energy > 0.1
    const cleanLine = turnAbs < 0.16 && farTurn < 0.28 && Math.abs(err) < 0.14 && !pC
    const turbo =
      this.state === 'racing' &&
      (wantTurbo ||
        finalGate ||
        (sk > 0.32 && cleanLine && uphill && b.energy > 0.34) ||
        (sk > 0.35 && cleanLine && b.energy > (0.64 - sk * 0.18) && b.v > top * 0.68) ||
        (b.turboOn && cleanLine && b.energy > 0.22))

    // Fast clean recovery if a bot ever gets wedged
    if (this.state === 'racing' && b.v < 9 && b.wreckT <= 0) b.stuck += dt
    else b.stuck = Math.max(0, b.stuck - dt * 2)
    if (b.stuck > 1.25 && route) {
      const q = route.pts[Math.min(route.pts.length - 1, b.pi + 3)]
      const q2 = route.pts[Math.min(route.pts.length - 1, b.pi + 6)]
      b.x = q[0]; b.z = q[1]
      b.yaw = Math.atan2(q2[0] - q[0], -(q2[1] - q[1]))
      b.y = A.groundAt(b.x, b.z) + HOVER
      b.vx = Math.sin(b.yaw) * 28
      b.vz = -Math.cos(b.yaw) * 28
      b.v = 28
      b.invuln = 1.5
      b.stuck = 0
    }
    return { throttle, brake, steer, abL, abR, turbo }
  }

  // ── one ship, one step
  private stepShip(sh: ArenaShip, inp: Input, dt: number) {
    const A = this.arena
    const p = this.p
    if (sh.wreckT > 0) {
      sh.wreckT -= dt
      sh.v = 0
      sh.vx = sh.vz = 0
      sh.yawV = 0
      sh.driftT = 0
      sh.flying = false
      sh.climbNow = 0
      if (sh.wreckT <= 0) {
        const gi = (sh.cp - 1 + A.n * 4) % A.n
        const g = sh.cp === 0 ? A.gates[0] : A.gates[gi]
        const nx = A.gates[sh.cp % A.n]
        sh.x = g.x - g.nx * 6
        sh.z = g.z - g.nz * 6
        sh.yaw = Math.atan2(nx.x - sh.x, -(nx.z - sh.z))
        sh.y = A.groundAt(sh.x, sh.z) + HOVER
        sh.vy = 0
        sh.shield = p.shieldMax * 0.6
        sh.invuln = 2.5
        sh.boostT = 0
        sh.pi = 0
      }
      return
    }
    sh.invuln = Math.max(0, sh.invuln - dt)
    // the shield mends itself, slowly, when nothing has hit it for a while
    if (this.clock - sh.hurtAt > 3 && sh.shield < p.shieldMax) sh.shield = Math.min(p.shieldMax, sh.shield + 5 * dt)
    sh.hitCd = Math.max(0, sh.hitCd - dt)
    sh.boostT = Math.max(0, sh.boostT - dt)
    const frozen = this.state === 'countdown'
    const profile = getVehicleStats(sh.skin)
    const top = this.topFor(sh) * (sh.isPlayer || !sh.ai ? 1 : (0.88 + 0.12 * sh.skill) * 0.985)
    const wantTurbo = inp.turbo && sh.energy > 0.001 && !frozen
    sh.turboOn = wantTurbo && sh.v > 15
    if (sh.turboOn && p.turboDrain > 0) sh.energy = clamp(sh.energy - p.turboDrain * profile.turboDrain * dt, 0, 1)
    else if (!sh.turboOn) sh.energy = clamp(sh.energy + p.turboRegen * dt, 0, 1)
    if (p.turboDrain <= 0) sh.energy = 1
    // ── N-key 3D Anti-Gravity Flight Mode
    const wantFly = !!inp.fly && !frozen && !sh.ai
    if (wantFly !== sh.flying) {
      sh.flying = wantFly
      if (wantFly) {
        sh.vy = Math.max(sh.vy, 30)
        // Give a crisp forward flight launch even if player presses N from standstill!
        if (sh.v < top * 0.4) {
          sh.v = top * 0.4
          sh.vx = Math.sin(sh.yaw) * sh.v
          sh.vz = -Math.cos(sh.yaw) * sh.v
        }
        if (sh.isPlayer) this.events.push({ type: 'flyOn', id: sh.id })
      } else if (sh.isPlayer) {
        this.events.push({ type: 'flyOff', id: sh.id })
      }
    }
    const climbCmd = sh.flying ? clamp(inp.climb || 0, -1, 1) : 0
    sh.climbNow += (climbCmd - sh.climbNow) * (1 - Math.exp(-dt * 9))
    sh.landImpact = Math.max(0, sh.landImpact - dt * 2.8)

    const boosting = sh.turboOn || sh.boostT > 0
    const topNow = top * (sh.boostT > 0 ? 1.3 : 1) * (sh.turboOn ? 1.28 : 1) * (sh.flying ? 1.08 : 1)
    const groundHere = A.groundAt(sh.x, sh.z)
    const wasAirborne = sh.airborne
    sh.airborne = sh.flying || sh.y > groundHere + HOVER + 0.85
    const air = sh.airborne
    // heading: responsive banked aerial turns in Flight Mode, springy drift on ground
    const sf = 1 / (1 + (sh.v / top) * 0.5)
    const sharp = !sh.flying && (inp.abL > 0 || inp.abR > 0)
    const wantDrift = !frozen && !air && sh.v > top * 0.45 && (Math.abs(inp.steer) > 0.55 || sharp)
    sh.drifting = wantDrift
    let yawT = frozen
      ? 0
      : inp.steer * 3.4 * p.steerGain * profile.steering * sf * (wantDrift ? 1.15 : sh.flying ? 0.86 : 1)
        + (sharp ? (inp.abR - inp.abL) * 1.4 * p.airbrake * sf : 0)
    if (air && !sh.flying) yawT *= 0.42
    sh.yawV += (yawT - sh.yawV) * (1 - Math.exp(-dt * 13))
    const yawRate = sh.yawV
    sh.yaw += yawRate * dt
    if (wantDrift && Math.abs(yawRate) > 0.7) sh.driftT = Math.min(2.4, sh.driftT + dt)
    else if (!wantDrift) {
      if (sh.driftT > 0.55) {
        // coming out of a long drift: a push of speed
        sh.boostT = Math.max(sh.boostT, Math.min(1.5, 0.45 + sh.driftT * 0.5) * (sh.ai ? 0.6 : 1))
        this.events.push({ type: 'drift', id: sh.id, v: sh.driftT })
      }
      sh.driftT = 0
    }
    const fx = Math.sin(sh.yaw), fz = -Math.cos(sh.yaw)
    const rx = Math.cos(sh.yaw), rz = Math.sin(sh.yaw)
    let vf = sh.vx * fx + sh.vz * fz
    let vl = sh.vx * rx + sh.vz * rz
    const gA = A.groundAt(sh.x + fx * 9, sh.z + fz * 9)
    const gB = A.groundAt(sh.x - fx * 9, sh.z - fz * 9)
    const slope = clamp((gA - gB) / 18, -0.7, 0.7)
    // In Flight Mode, maintain smooth minimum cruise thrust even if player glides without holding W, full jet speed with W!
    const thr = frozen ? 0 : sh.flying ? Math.max(inp.throttle, inp.brake > 0.1 ? 0 : 0.48) : inp.throttle
    const ratio = clamp(vf / topNow, 0, 1.3)
    let a = thr * 92 * p.accelGain * profile.acceleration * (boosting ? 2.3 : 1) * (1 - ratio * ratio)
    if (!air) a -= 9.8 * 0.9 * slope
    if (!thr) a -= sh.flying ? 4 : 8
    a -= inp.brake * (sh.flying ? 95 : 120)
    if (!sh.flying) a -= (inp.abL + inp.abR) * 20 * p.airbrake
    if (vf > topNow) a -= (vf - topNow) * 1.3
    vf = Math.max(0, vf + a * dt)
    const grip = (sh.flying ? 6.8 : air ? 0.5 : wantDrift ? 4.8 + 2.4 * p.assist : 9 + 5 * p.assist) * profile.grip
    vl *= Math.exp(-grip * dt)
    sh.v = vf
    sh.vlat = vl
    sh.vx = fx * vf + rx * vl
    sh.vz = fz * vf + rz * vl
    // move, sliding along cliffs
    let nx = sh.x + sh.vx * dt
    let nz = sh.z + sh.vz * dt
    {
      const travelled = Math.hypot(nx - sh.x, nz - sh.z)
      const rise = A.groundAt(nx, nz) - A.groundAt(sh.x, sh.z)
      // Hover bikes & ships glide smoothly up gradual valley & canyon slopes while vertical cliff walls still block!
      if (rise > 0 && rise < travelled * 0.85 + 1.5) sh.y = Math.max(sh.y, A.groundAt(nx, nz) + HOVER)
    }
    sh.scrape = Math.max(0, sh.scrape - dt * 6)
    let hitX = false
    let hitZ = false
    if (sh.flying) {
      // Smoothly lift up over steep forested mountainsides while flying!
      const gNext = A.groundAt(nx, nz)
      if (gNext + 5 > sh.y) {
        sh.y += Math.min(gNext + 5 - sh.y, 68 * dt)
        sh.vy = Math.max(sh.vy, 18)
      }
    } else {
      if (this.blockedAt(nx, sh.z, sh.y)) { hitX = true; nx = sh.x }
      if (this.blockedAt(sh.x, nz, sh.y)) { hitZ = true; nz = sh.z }
    }
    if (hitX || hitZ) {
      const imp = Math.max(hitX ? Math.abs(sh.vx) : 0, hitZ ? Math.abs(sh.vz) : 0)
      const wx = hitX ? Math.sign(sh.vx) : 0
      const wz = hitZ ? Math.sign(sh.vz) : 0
      const hard = (hitX ? Math.abs(sh.vx) : 0) * Math.abs(fx) + (hitZ ? Math.abs(sh.vz) : 0) * Math.abs(fz)
      if (hitX) sh.vx = -sh.vx * 0.25
      if (hitZ) sh.vz = -sh.vz * 0.25
      if (imp > 8 && hard > 8) {
        const sev = clamp(hard / 45, 0, 1.5)
        this.hurt(sh, (6 + 14 * sev) * p.wallDmg)
        this.events.push({ type: 'wall', id: sh.id, v: sev, side: Math.sign(wx * rx + wz * rz) || 1 })
      }
      sh.scrape = 1
      sh.scrapeSide = Math.sign(wx * rx + wz * rz) || 1
      sh.vx *= 1 - 0.6 * dt
      sh.vz *= 1 - 0.6 * dt
      if (sh.invuln <= 0) sh.shield -= 1.2 * p.wallDmg * profile.damage * dt * (Math.hypot(sh.vx, sh.vz) / 80)
    }
    // Keep flying craft inside the outer mountain sanctuary boundary smoothly
    if (sh.flying) {
      const bMargin = 95
      nx = clamp(nx, A.ox + bMargin, A.ox + A.size - bMargin)
      nz = clamp(nz, A.oz + bMargin, A.oz + A.size - bMargin)
    }
    sh.x = nx
    sh.z = nz

    // ── Height: free 3D aerial flight when sh.flying, or spring hover + jumps + cushioned landings!
    const gC = A.groundAt(sh.x, sh.z)
    const target = gC + HOVER + clamp(sh.v / top, 0, 1.3) * 0.5
    if (sh.flying) {
      const agl = sh.y - gC
      const minCruise = 18
      const maxAlt = gC + 340
      let goalVy = climbCmd * 46
      // Automatic smooth terrain-following lift so flying low over waterfalls, hills & rivers feels effortless!
      if (agl < minCruise && climbCmd >= -0.05) {
        goalVy = Math.max(goalVy, (minCruise - agl) * 2.2)
      }
      // Look ahead for rising mountainside & lift smoothly over it while flying
      const gAhead = A.groundAt(sh.x + fx * 28, sh.z + fz * 28)
      if (gAhead + 9 > sh.y && climbCmd >= -0.2) {
        goalVy = Math.max(goalVy, (gAhead + 11 - sh.y) * 2.6)
      }
      sh.vy += (goalVy - sh.vy) * (1 - Math.exp(-dt * 6.5))
      sh.y = Math.min(maxAlt, sh.y + sh.vy * dt)
      if (sh.y < gC + 4.2) {
        sh.y = gC + 4.2
        sh.vy = Math.max(0, sh.vy)
      }
      if (sh.y >= maxAlt - 0.5 && sh.vy > 0) sh.vy = 0
    } else {
      const prevVy = sh.vy
      if (sh.y > target + 0.85) sh.vy -= 36 * dt
      else {
        // Trigger authentic landing animation & sound the instant an airborne craft touches down into hover cushion!
        if (wasAirborne && prevVy < -4.5) {
          const imp = clamp(-prevVy / 24, 0.25, 1.5)
          sh.landImpact = Math.max(sh.landImpact, imp)
          if (sh.isPlayer) this.events.push({ type: 'land', id: sh.id, v: imp })
        }
        sh.vy += ((target - sh.y) * 80 - sh.vy * 13) * dt
        sh.vy = clamp(sh.vy, -40, 21)
      }
      sh.y += sh.vy * dt
      if (sh.y < gC + 0.4) {
        if (prevVy < -6) {
          const imp = clamp(-prevVy / 22, 0.3, 1.5)
          sh.landImpact = Math.max(sh.landImpact, imp)
          if (sh.isPlayer) this.events.push({ type: 'land', id: sh.id, v: imp })
        }
        if (prevVy < -20 && sh.invuln <= 0) this.hurt(sh, 2.5 * p.wallDmg)
        sh.y = gC + 0.4
        sh.vy = Math.max(0, sh.vy)
      }
    }
    const targetPitch = sh.flying
      ? clamp(Math.atan2(sh.vy, Math.max(42, sh.v)) * 1.15 + sh.climbNow * 0.14, -0.58, 0.62)
      : Math.atan2(sh.vy, Math.max(30, sh.v)) * 0.92 + slope * 0.42
    sh.pitch += (targetPitch - sh.pitch) * (1 - Math.exp(-dt * 7.5))
    sh.steerNow += (inp.steer - sh.steerNow) * (1 - Math.exp(-dt * 8))
    sh.throttle = thr
    // pads
    for (const pad of A.pads) {
      if (Math.hypot(sh.x - pad.x, sh.z - pad.z) < pad.r && !air && sh.boostT < 0.9) {
        sh.boostT = 1.7
        sh.v = Math.max(sh.v, Math.min(topNow * 1.1, sh.v + 22 * p.padPower))
        sh.vx = Math.sin(sh.yaw) * sh.v
        sh.vz = -Math.cos(sh.yaw) * sh.v
        sh.energy = clamp(sh.energy + 0.2, 0, 1)
        sh.padsHit++
        this.events.push({ type: 'pad', id: sh.id })
      }
    }
    // hazards
    if (sh.hitCd <= 0) {
      for (const o of A.obstacles) {
        const dx0 = o.x - sh.x
        const far = o.type === 'roller' ? 200 : 60
        if (Math.abs(dx0) > far && o.type !== 'roller') continue
        if (o.type === 'rockwall' && this.brokenWalls.has(o.id)) continue
        const hz = this.hazard(o, this.clock)
        const dx = hz.x - sh.x
        const dz = hz.z - sh.z
        const d = Math.hypot(dx, dz)
        if (d > 80) continue
        const g0 = A.groundAt(hz.x, hz.z)
        let hit = false
        if (o.type === 'rock') hit = d < o.r + 2.8 && sh.y < g0 + 15
        else if (o.type === 'roller') hit = d < o.r + 2.8 && Math.abs(sh.y - (g0 + o.r)) < o.r + 3
        else if (o.type === 'fan') {
          if (d < 3.5 + 2.6 && sh.y < g0 + 12) hit = true
          else if (d < o.len / 2 + 3) {
            const ang = hz.u
            const bx = Math.cos(ang), bz = Math.sin(ang)
            const along = (sh.x - o.x) * bx + (sh.z - o.z) * bz
            const perp = Math.abs(-(sh.x - o.x) * bz + (sh.z - o.z) * bx)
            hit = Math.abs(along) < o.len / 2 && perp < 3.4 && Math.abs(sh.y - (g0 + 4.5)) < 6
          }
        } else if (o.type === 'geyser') {
          if (hz.active && d < o.r && sh.y < g0 + 30) {
            sh.vy = Math.max(sh.vy, 22)
            this.hurt(sh, 5 * p.wallDmg)
            sh.hitCd = 0.8
            this.events.push({ type: 'wall', id: sh.id, v: 0.4, side: 1 })
          }
          continue
        } else if (o.type === 'rockwall') {
          if (d < o.r + 3 && sh.y < g0 + 20) {
            if (sh.v > 98 || sh.turboOn) {
              this.brokenWalls.add(o.id)
              this.hurt(sh, 7 * p.wallDmg)
              sh.v *= 0.85
              sh.vx *= 0.85
              sh.vz *= 0.85
              sh.hitCd = 0.4
              this.events.push({ type: 'smash', id: o.id })
              continue
            }
            hit = true
          }
        }
        if (hit) {
          const nrm = d > 0.01 ? [-dx / d, -dz / d] : [-Math.sin(sh.yaw), Math.cos(sh.yaw)]
          const sp = Math.max(30, sh.v)
          sh.vx = nrm[0] * sp * 0.55
          sh.vz = nrm[1] * sp * 0.55
          sh.x += nrm[0] * 2.5
          sh.z += nrm[1] * 2.5
          sh.vy = Math.max(sh.vy, 6)
          this.hurt(sh, (12 + sp / 12) * p.wallDmg)
          sh.hitCd = 0.55
          this.events.push({ type: 'wall', id: sh.id, v: 1, side: Math.sign(nrm[0] * rx + nrm[1] * rz) || 1 })
          break
        }
      }
    }
    // gates
    if (!sh.finished) {
      const gi = sh.cp % A.n
      const g = A.gates[gi]
      const sd = (sh.x - g.x) * g.nx + (sh.z - g.z) * g.nz
      const prev = (sh as any)._sd ?? sd
      ;(sh as any)._sd = sd
      const along = Math.abs(-(sh.x - g.x) * g.nz + (sh.z - g.z) * g.nx)
      const gateWidth = sh.flying ? g.r * 1.35 : g.r
      if (prev < 0 && sd >= 0 && along < gateWidth && this.state !== 'countdown') {
        sh.cp++
        ;(sh as any)._sd = undefined
        if (sh.cp === 1) { sh.lap = 1; sh.lapStart = this.time }
        else if ((sh.cp - 1) % A.n === 0) {
          const done = (sh.cp - 1) / A.n
          const lt = this.time - sh.lapStart
          sh.lapTimes.push(lt)
          sh.best = Math.min(sh.best, lt)
          sh.lapStart = this.time
          if (done < p.laps) {
            sh.lap = done + 1
            if (sh.isPlayer) this.events.push({ type: 'lap', id: sh.id, n: done, v: lt })
            if (sh.lap === p.laps && sh.isPlayer && p.laps > 1) this.events.push({ type: 'final', id: sh.id })
          }
        }
        if (sh.cp >= p.laps * A.n + 1) {
          sh.finished = true
          sh.lap = p.laps
          sh.finishTime = this.time
          this.events.push({ type: 'finish', id: sh.id })
          if (sh.isPlayer) sh.ai = true
        }
        sh.pathId = -1
      }
    }
    if (sh.shield <= 0 && sh.wreckT <= 0) {
      sh.wreckT = 2.4
      sh.shield = 0
      this.events.push({ type: 'wreck', id: sh.id })
    }
  }

  /** put the player back at the last gate, facing the next one */
  resetPlayer() {
    const A = this.arena
    const sh = this.player
    if (sh.wreckT > 0 || sh.finished) return
    const g = A.gates[(sh.cp - 1 + A.n * 4) % A.n]
    const nx = A.gates[sh.cp % A.n]
    const from = sh.cp === 0 ? A.gates[0] : g
    sh.x = from.x - from.nx * 6
    sh.z = from.z - from.nz * 6
    sh.yaw = Math.atan2(nx.x - sh.x, -(nx.z - sh.z))
    sh.y = A.groundAt(sh.x, sh.z) + HOVER
    sh.flying = false
    sh.climbNow = 0
    sh.vx = sh.vz = sh.v = sh.vy = 0
    sh.invuln = 1.5
  }

  step(dt: number, player: Input) {
    dt = Math.min(dt, 0.05)
    this.clock += dt
    if (this.state === 'countdown') {
      const before = Math.ceil(this.count)
      this.count -= dt
      if (player.throttle > 0.5) this.gasHeld += dt
      else this.gasHeld = 0
      const after = Math.ceil(this.count)
      if (after !== before && after > 0) this.events.push({ type: 'count', n: after })
      if (this.count <= 0) {
        this.state = 'racing'
        this.time = 0
        this.events.push({ type: 'go' })
        const pl = this.player
        if (this.gasHeld > 0.15 && this.gasHeld < 1.2) {
          pl.boostT = 1.4
          pl.v = 12
          this.events.push({ type: 'turbo' })
        }
        for (const s of this.ships) if (s !== pl) s.v = 6 + s.skill * 8
      }
    } else this.time += dt
    const pin: Input = { ...player }
    if (this.p.autoGas && pin.brake < 0.1) pin.throttle = 1
    for (const sh of this.ships) {
      const inp = sh.ai ? this.aiInput(sh, dt) : pin
      sh.lastInput = inp
      this.stepShip(sh, inp, dt / 2)
      this.stepShip(sh, inp, dt / 2)
    }
    // craft touching craft
    for (let i = 0; i < this.ships.length; i++) {
      const a = this.ships[i]
      if (a.wreckT > 0) continue
      for (let j = i + 1; j < this.ships.length; j++) {
        const b = this.ships[j]
        if (b.wreckT > 0) continue
        const dx = a.x - b.x
        const dz = a.z - b.z
        const d = Math.hypot(dx, dz)
        if (d > 5.2 || d < 0.01 || Math.abs(a.y - b.y) > 4) continue
        const nx = dx / d, nz = dz / d
        const push = (5.2 - d) * 0.5
        a.x += nx * push; a.z += nz * push
        b.x -= nx * push; b.z -= nz * push
        a.vx += nx * 6; a.vz += nz * 6
        b.vx -= nx * 6; b.vz -= nz * 6
        if (a.isPlayer || b.isPlayer) if (Math.random() < 0.2) this.events.push({ type: 'bump', id: a.isPlayer ? a.id : b.id, v: 0.5 })
      }
    }
    // passing the player
    const pl = this.player
    for (const o of this.ships) {
      if (o === pl) continue
      const ds = o.dist - pl.dist
      const prev = (o as any)._pds ?? ds
      if ((prev > 0) !== (ds > 0) && Math.hypot(o.x - pl.x, o.z - pl.z) < 30) this.events.push({ type: 'pass', id: o.id, v: ds > 0 ? 1 : -1, side: Math.sign((o.x - pl.x) * Math.cos(pl.yaw) + (o.z - pl.z) * Math.sin(pl.yaw)) || 1 })
      ;(o as any)._pds = ds
    }
    this.refreshDist()
    this.ranking()
    if (this.state === 'racing' && pl.finished) {
      this.afterFinish += dt
      if (this.finishedAll() || this.afterFinish > 18) {
        this.state = 'finished'
        this.results = this.ranking()
      }
    }
  }
}
