// @ts-nocheck
// Speeder bikes pointing down -Z with a fully articulated rider skeleton:
// hip weight-shift, leaning torso, horizon-levelled apex-looking helmet, dual-jointed
// handlebar-tracking arms, MotoGP inside knee-flare legs, wind-rippling scarf,
// active flight aero-vanes, and spring-damped climb / dive / landing suspension.
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

const UP = new THREE.Vector3(0, 1, 0)
const clamp = (v, a, b) => Math.min(b, Math.max(a, v))

// Merge fixed pieces that share a material inside a single group (leaves child groups articulated).
function mergeStaticMeshes(parent) {
  const groups = new Map()
  for (const child of parent.children) {
    if (!child.isMesh || Array.isArray(child.material)) continue
    if (!groups.has(child.material)) groups.set(child.material, [])
    groups.get(child.material).push(child)
  }
  for (const [material, meshes] of groups) {
    if (meshes.length < 2) continue
    const parts = meshes.map((mesh) => {
      mesh.updateMatrix()
      const geometry = mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry.clone()
      for (const name of Object.keys(geometry.attributes)) {
        if (name !== 'position' && name !== 'normal') geometry.deleteAttribute(name)
      }
      geometry.clearGroups()
      geometry.applyMatrix4(mesh.matrix)
      return geometry
    })
    const geometry = mergeGeometries(parts)
    parts.forEach((part) => part.dispose())
    if (!geometry) continue
    for (const mesh of meshes) {
      parent.remove(mesh)
      mesh.geometry.dispose()
    }
    parent.add(new THREE.Mesh(geometry, material))
  }
}

function finish(color, roughness = 0.5, metalness = 0.25) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness })
}

function box(parent, material, size, position, rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material)
  mesh.position.set(...position)
  mesh.rotation.set(...rotation)
  parent.add(mesh)
  return mesh
}

function ellipsoid(parent, material, radii, position, rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 12), material)
  mesh.position.set(...position)
  mesh.scale.set(...radii)
  mesh.rotation.set(...rotation)
  parent.add(mesh)
  return mesh
}

function beam(parent, material, a, b, radius, radiusEnd = radius) {
  const start = new THREE.Vector3(...a)
  const end = new THREE.Vector3(...b)
  const direction = end.clone().sub(start)
  const length = direction.length()
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radiusEnd, radius, length, 10), material)
  mesh.position.copy(start).addScaledVector(direction, 0.5)
  mesh.quaternion.setFromUnitVectors(UP, direction.normalize())
  parent.add(mesh)
  return mesh
}

function panel(parent, material, points, depth, plate, position = [0, 0, 0]) {
  const mesh = new THREE.Mesh(plate(points, depth, 0.025), material)
  mesh.position.set(...position)
  parent.add(mesh)
  return mesh
}

function swoopGlow(variant) {
  return variant === 'swoop' ? '#ffb45c' : '#7ef4ff'
}

// Analytical two-bone arm solver so the pilot's hands stay locked onto the moving handlebars
// while the elbows bend and flare naturally during corners, climbs, and landings!
const _shoulderW = new THREE.Vector3()
const _gripW = new THREE.Vector3()
const _toGrip = new THREE.Vector3()
const _pole = new THREE.Vector3()
const _elbow = new THREE.Vector3()
const _segDir = new THREE.Vector3()
const _invTorso = new THREE.Matrix4()

function createRider(bike, variant, bars, gripL, gripR) {
  const scout = variant === 'scout'
  const sport = variant === 'sport'
  const suit = finish(scout ? '#485d54' : sport ? '#8e3d35' : '#2d3742', 0.78, 0.1)
  const suitDark = finish(scout ? '#26322f' : sport ? '#352834' : '#161b25', 0.78, 0.14)
  const trousers = finish(scout ? '#a6a598' : sport ? '#a8846c' : '#505359', 0.78, 0.06)
  const armour = finish(scout ? '#eceae0' : sport ? '#cfa96c' : '#9c5430', 0.36, 0.34)
  const helmetPaint = finish(scout ? '#f4f3eb' : sport ? '#f0c87b' : '#c05f32', 0.28, 0.38)
  const boots = finish('#22282a', 0.62, 0.22)
  const visor = finish('#081520', 0.1, 0.65)
  const glowColor = sport ? '#ffd074' : swoopGlow(variant)
  const visorHighlight = new THREE.MeshBasicMaterial({ color: glowColor })
  const scarfMat = finish(scout ? '#1ec8c8' : sport ? '#f2b644' : '#ef6436', 0.72, 0.06)

  // ── 1. Pelvis / Hip group (slides sideways into turns & compresses vertically on landing)
  const rider = new THREE.Group()
  rider.name = 'rider'
  const baseHipY = 0.76
  const baseHipZ = 0.63
  rider.position.set(0, baseHipY, baseHipZ)
  bike.add(rider)

  ellipsoid(rider, trousers, [0.34, 0.23, 0.28], [0, 0.03, 0])
  box(rider, suitDark, [0.55, 0.12, 0.12], [0, 0.16, 0.19], [-0.18, 0, 0])
  mergeStaticMeshes(rider)

  // ── 2. Articulated Upper Body / Torso (pivots at waist for deep corner lean, aero tuck, climb brace & landing shock)
  const torso = new THREE.Group()
  torso.name = 'rider-torso'
  torso.position.set(0, 0.14, -0.02)
  rider.add(torso)

  ellipsoid(torso, suit, [0.37, 0.55, 0.27], [0, 0.41, -0.15], [-0.34, 0, 0])
  ellipsoid(torso, suitDark, [0.33, 0.41, 0.08], [0, 0.43, -0.38], [-0.32, 0, 0])
  box(torso, armour, [0.44, 0.2, 0.095], [0, 0.56, -0.44], [-0.32, 0, 0])
  // Sculpted sci-fi flight jetpack / spine rig with live telemetry thruster bars
  box(torso, armour, [0.43, 0.52, 0.19], [0, 0.48, 0.16], [-0.32, 0, 0])
  box(torso, suitDark, [0.28, 0.32, 0.04], [0, 0.49, 0.27], [-0.32, 0, 0])
  const packLed = box(torso, visorHighlight, [0.23, 0.05, 0.03], [0, 0.53, 0.3], [-0.32, 0, 0])
  // Shoulder pauldrons & neck
  for (const side of [-1, 1]) {
    ellipsoid(torso, armour, [0.23, 0.15, 0.23], [side * 0.35, 0.79, -0.28])
    // Compact dorsal jump-jet nozzles on the backpack
    box(torso, suitDark, [0.09, 0.16, 0.09], [side * 0.15, 0.22, 0.26], [-0.2, 0, 0])
  }
  beam(torso, suitDark, [0, 0.77, -0.28], [0, 1.03, -0.36], 0.14)
  mergeStaticMeshes(torso)
  void packLed

  // ── 3. Flowing 3-segment sci-fi rider scarf (streams dynamically in wind, turns, climbs & dives)
  const scarfSegs = []
  let scarfParent = torso
  for (let s = 0; s < 3; s++) {
    const seg = new THREE.Group()
    seg.position.set(0, s === 0 ? 0.86 : 0, s === 0 ? -0.06 : 0.31)
    const w = 0.24 - s * 0.035
    const l = 0.34
    const cloth = new THREE.Mesh(new THREE.BoxGeometry(w, 0.032, l), scarfMat)
    cloth.position.set(0, 0, l * 0.5)
    seg.add(cloth)
    scarfParent.add(seg)
    scarfSegs.push(seg)
    scarfParent = seg
  }

  // ── 4. Articulated Two-Bone Arms (track live handlebar grips with dynamic elbow flare)
  const arms = []
  const upperLen = 0.44
  const foreLen = 0.56
  for (const side of [-1, 1]) {
    const shPos = new THREE.Vector3(side * 0.35, 0.78, -0.28)
    const upper = new THREE.Group()
    upper.position.copy(shPos)
    const uMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.125, 0.148, upperLen, 10).translate(0, upperLen * 0.5, 0), suit)
    const ePad = new THREE.Mesh(new THREE.SphereGeometry(0.135, 12, 10), armour)
    ePad.position.set(0, upperLen, 0)
    upper.add(uMesh, ePad)
    mergeStaticMeshes(upper)
    torso.add(upper)

    const fore = new THREE.Group()
    const fMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.102, 0.12, foreLen, 10).translate(0, foreLen * 0.5, 0), suit)
    const glove = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), boots)
    glove.scale.set(0.13, 0.1, 0.16)
    glove.position.set(0, foreLen, 0)
    fore.add(fMesh, glove)
    mergeStaticMeshes(fore)
    torso.add(fore)

    arms.push({ side, shPos, upper, fore, grip: side < 0 ? gripL : gripR })
  }

  // ── 5. Articulated Legs (thigh + knee + shin — inside knee swings out MotoGP-style in corners, squats on landing, sweeps back in flight!)
  const legs = []
  for (const side of [-1, 1]) {
    const legHip = new THREE.Group()
    legHip.position.set(side * 0.22, -0.02, 0.04)
    rider.add(legHip)

    beam(legHip, trousers, [0, 0, 0], [side * 0.19, -0.19, -0.32], 0.17, 0.148)
    ellipsoid(legHip, armour, [0.145, 0.135, 0.165], [side * 0.2, -0.2, -0.33])
    mergeStaticMeshes(legHip)

    const shin = new THREE.Group()
    shin.position.set(side * 0.2, -0.2, -0.33)
    legHip.add(shin)
    beam(shin, suitDark, [0, 0, 0], [side * 0.01, -0.43, 0.36], 0.118, 0.14)
    ellipsoid(shin, boots, [0.14, 0.12, 0.27], [side * 0.01, -0.47, 0.24])
    mergeStaticMeshes(shin)

    legs.push({ side, legHip, shin })
  }

  // ── 6. Articulated Helmet (horizon counter-roll, corner look-ahead yaw, climb gaze & landing nod)
  const helmet = new THREE.Group()
  helmet.name = 'rider-helmet'
  helmet.position.set(0, 1.29, -0.41)
  torso.add(helmet)
  ellipsoid(helmet, helmetPaint, [0.32, 0.36, 0.34], [0, 0, 0])
  ellipsoid(helmet, visor, [0.285, 0.135, 0.075], [0, -0.045, -0.295])
  box(helmet, armour, [0.4, 0.12, 0.1], [0, -0.23, -0.22], [-0.15, 0, 0])
  box(helmet, suitDark, [0.46, 0.065, 0.05], [0, -0.075, 0.3])
  box(helmet, visorHighlight, [0.21, 0.028, 0.022], [-0.06, 0.015, -0.358])
  for (const side of [-1, 1]) {
    const earpiece = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.095, 0.07, 12).rotateZ(Math.PI / 2), armour)
    earpiece.position.set(side * 0.3, -0.02, 0.02)
    helmet.add(earpiece)
    ellipsoid(helmet, suitDark, [0.045, 0.045, 0.045], [side * 0.34, -0.02, 0.02])
  }
  if (sport || variant === 'swoop') {
    box(helmet, sport ? armour : suitDark, [0.095, 0.32, 0.05], [0, 0.17, -0.27], [-0.38, 0, 0])
  }
  mergeStaticMeshes(helmet)

  // ── Smooth spring-damper kinematic state
  let lean = 0
  let leanVel = 0
  let hipShift = 0
  let turn = 0
  let tuck = 0
  let climbPose = 0
  let flyBlend = 0
  let airBlend = 0
  let squatPos = 0
  let squatVel = 0
  let headNod = 0
  let headNodVel = 0
  let lastLand = 0

  const updateArmsIK = (elbowOut) => {
    bike.updateMatrixWorld(true)
    _invTorso.copy(torso.matrixWorld).invert()
    for (const arm of arms) {
      arm.grip.getWorldPosition(_gripW)
      _gripW.applyMatrix4(_invTorso)
      _shoulderW.copy(arm.shPos)
      _toGrip.subVectors(_gripW, _shoulderW)
      const dist = clamp(_toGrip.length(), 0.22, upperLen + foreLen - 0.02)
      _toGrip.normalize()
      // Law of cosines for exact elbow bend angle
      const cosA = clamp((upperLen * upperLen + dist * dist - foreLen * foreLen) / (2 * upperLen * dist), -0.98, 0.98)
      const along = upperLen * cosA
      const perp = Math.sqrt(Math.max(0.001, upperLen * upperLen - along * along))
      // Natural outward & slightly downward motorcycle elbow pole vector
      _pole.set(arm.side * (0.78 + elbowOut * 0.45), -0.45 + elbowOut * 0.25, 0.28)
      _pole.addScaledVector(_toGrip, -_pole.dot(_toGrip)).normalize()
      _elbow.copy(_shoulderW).addScaledVector(_toGrip, along).addScaledVector(_pole, perp)

      arm.upper.position.copy(_shoulderW)
      _segDir.subVectors(_elbow, _shoulderW).normalize()
      arm.upper.quaternion.setFromUnitVectors(UP, _segDir)

      arm.fore.position.copy(_elbow)
      _segDir.subVectors(_gripW, _elbow)
      const fDist = Math.max(0.18, _segDir.length())
      arm.fore.quaternion.setFromUnitVectors(UP, _segDir.divideScalar(fDist))
      arm.fore.scale.set(1, fDist / foreLen, 1)
    }
  }

  return (state, dt) => {
    const h = Math.min(dt || 0.016, 0.05)
    const steer = clamp(state.steer || 0, -1, 1)
    const drift = clamp(state.drift || 0, 0, 1)
    const boost = state.boost ? 1 : 0
    const throttle = clamp(state.throttle || 0, 0, 1)
    const speedK = clamp(state.speedRatio || 0, 0, 1.4)
    const pitch = clamp(state.pitch || 0, -0.7, 0.7)
    const vy = clamp(state.vy || 0, -45, 45)
    const flying = state.flying ? 1 : 0
    const airborne = state.airborne || flying ? 1 : 0
    const climbCmd = clamp(state.climb || 0, -1, 1)
    const landIn = state.landImpact || 0

    // Trigger crisp spring-damped landing compression + helmet nod impulse on touchdown!
    if (landIn > lastLand + 0.08) {
      const imp = clamp(landIn, 0.25, 1.5)
      squatVel -= imp * 3.9
      headNodVel += imp * 5.2
    }
    lastLand = landIn

    // Damped harmonic spring for rider landing squat & takeoff lift
    const squatForce = -squatPos * 92 - squatVel * 11.5
    squatVel += squatForce * h
    squatPos = clamp(squatPos + squatVel * h, -0.34, 0.18)

    const nodForce = -headNod * 78 - headNodVel * 9.5
    headNodVel += nodForce * h
    headNod = clamp(headNod + headNodVel * h, -0.35, 0.42)

    // Springy cornering body lean (leans aggressively INTO the turn, amplified by speed & drift!)
    const turnIntensity = steer * (0.55 + 0.45 * Math.min(1, speedK)) * (1 + drift * 0.35)
    const targetLean = -turnIntensity * 0.56
    leanVel += ((targetLean - lean) * 72 - leanVel * 10.5) * h
    lean = clamp(lean + leanVel * h, -0.72, 0.72)

    const easeFast = 1 - Math.exp(-h * 11)
    const easeMed = 1 - Math.exp(-h * 7.5)

    hipShift += (turnIntensity * 0.22 - hipShift) * easeFast
    flyBlend += (flying - flyBlend) * easeMed
    airBlend += (airborne - airBlend) * easeFast

    // Handlebar steering: turns into corner, subtle realistic counter-steer snap when drifting hard!
    const barGoal = -steer * (0.28 - drift * 0.12)
    turn += (barGoal - turn) * easeFast
    bars.rotation.y = turn

    // Climb (+1) vs Dive/Descent (-1) continuous kinematic pose
    const rawClimb = clamp(vy / 24 + pitch * 1.15 + climbCmd * 0.55, -1.2, 1.2)
    climbPose += (rawClimb - climbPose) * easeMed

    // Forward aerodynamic tuck during high speed, turbo boost, flight cruise, and diving
    const diveCrouch = Math.max(0, -climbPose) * 0.24
    const climbRise = Math.max(0, climbPose)
    const tuckGoal = boost * 0.22 + throttle * 0.06 + flyBlend * 0.14 + diveCrouch - climbRise * 0.12
    tuck += (tuckGoal - tuck) * easeMed

    // 1. Pelvis position & rotation: shifts inside the saddle in turns, lifts slightly in attack stance on climbs/jumps, drops deep on landing!
    const climbLift = climbRise * 0.085 + airBlend * (1 - flyBlend) * 0.06
    const cornerDrop = -Math.abs(hipShift) * 0.14
    rider.position.set(
      hipShift,
      baseHipY + climbLift + cornerDrop + squatPos * 0.62,
      baseHipZ - climbRise * 0.06 + flyBlend * 0.07 - squatPos * 0.15,
    )
    rider.rotation.z = lean * 0.58
    rider.rotation.y = -turnIntensity * 0.16

    // 2. Torso: hangs deep into corner, tucks for aero/dive, pulls heroically on climb/takeoff, folds to absorb landing!
    const breath = Math.sin((state.time || 0) * 3.1) * 0.016 + (boost ? Math.sin((state.time || 0) * 28) * 0.008 : 0)
    const landFold = Math.max(0, -squatPos) * 1.15
    torso.rotation.z = lean * 0.52
    torso.rotation.y = -turnIntensity * 0.22
    torso.rotation.x = -(tuck + landFold) + climbRise * 0.15 + breath

    // 3. Helmet: stays level with horizon, looks into the corner apex, looks up on climb & down on descent, nods on touchdown!
    helmet.rotation.z = -lean * 0.68
    helmet.rotation.y = -steer * 0.34
    helmet.rotation.x = tuck * 0.52 + climbPose * 0.24 - headNod

    // 4. Legs: inside knee flares out MotoGP-style in corners, flexes deeply on landing, sweeps back in flight mode!
    const squatFlex = Math.max(0, -squatPos) * 1.45
    for (const leg of legs) {
      // steer > 0 = turning right (side = +1 is inside leg); steer < 0 = turning left (side = -1 is inside leg)
      const isInside = clamp(steer * leg.side, 0, 1) * (0.45 + 0.55 * Math.min(1, speedK)) * (1 - flyBlend * 0.65)
      const isOutside = clamp(-steer * leg.side, 0, 1)
      // Flare inside knee wide outward, tuck outside knee tightly against frame
      leg.legHip.rotation.y = -leg.side * (isInside * 0.52 - isOutside * 0.1)
      leg.legHip.rotation.z = leg.side * (isInside * 0.34 + squatFlex * 0.18)
      leg.legHip.rotation.x = squatFlex * 0.65 - flyBlend * 0.36 + climbRise * 0.14 - Math.max(0, -climbPose) * 0.12
      leg.shin.rotation.x = -squatFlex * 0.85 - flyBlend * 0.32 - isInside * 0.18
    }

    // 5. Flowing pilot scarf rippling in slipstream, whipping on turns & billowing with vertical velocity!
    const windSpd = 6 + speedK * 15 + boost * 10 + flyBlend * 6
    const tNow = state.time || 0
    for (let s = 0; s < scarfSegs.length; s++) {
      const seg = scarfSegs[s]
      const flutter = Math.sin(tNow * windSpd - s * 1.35) * (0.06 + 0.11 * Math.min(1.2, speedK + boost * 0.5))
      const sway = Math.cos(tNow * (windSpd * 0.7) - s * 1.1) * 0.05
      if (s === 0) {
        const lift = clamp(0.28 + speedK * 0.65 + boost * 0.25 - vy * 0.018, -0.35, 1.38)
        seg.rotation.x = lift + flutter
        seg.rotation.y = steer * 0.42 + sway
        seg.rotation.z = -lean * 0.35
      } else {
        seg.rotation.x = flutter * 1.25 - vy * 0.008
        seg.rotation.y = steer * 0.18 + sway * 1.3
      }
    }

    // 6. Solve two-bone arm IK so gloves always grip the handlebars cleanly!
    const elbowOut = Math.max(0, -squatPos) * 1.8 + boost * 0.35 + Math.abs(steer) * 0.25
    updateArmsIK(elbowOut)

    // Return chassis suspension offset so the bike frame also responds physically to landings & climbs
    return { squatPos, flyBlend, climbPose }
  }
}

/** Builds the requested bike and returns its rider, suspension, and flight-vane animation callback. */
export function buildBike(model, glows, trails, M, variant, liveryIdx, helpers) {
  const { loft, plate, addEngine } = helpers
  const scout = variant === 'scout'
  const sport = variant === 'sport'
  const swoop = variant === 'swoop'

  const mainColor = scout ? '#e0e1dc' : sport ? '#a8263a' : '#38434c'
  const accentColor = scout ? '#6e8c86' : sport ? '#e8b23e' : '#df6034'
  const bodyColor = new THREE.Color(mainColor)
  if (liveryIdx > 0) bodyColor.lerp(M.body, scout ? 0.18 : 0.28)
  const shell = finish(bodyColor, 0.36, 0.42)
  const accents = finish(accentColor, 0.38, 0.32)
  const frame = finish('#272e31', 0.45, 0.7)
  const steel = finish('#8e9795', 0.32, 0.72)
  const seat = finish(sport ? '#70462c' : swoop ? '#412c29' : '#45463e', 0.8, 0.08)
  const stripes = finish(sport ? '#9d5ca6' : swoop ? '#ee9546' : '#dce4dc', 0.4, 0.36)
  const dark = finish('#141d24', 0.5, 0.48)
  const exhaust = new THREE.Color(scout ? '#6ae6ff' : sport ? '#ffc470' : '#ff9248')
  const bikeEngine = {
    ...M,
    acc: exhaust,
    hot: exhaust.clone().lerp(new THREE.Color('#ffffff'), 0.68),
    neon: new THREE.MeshBasicMaterial({ color: exhaust.clone().lerp(new THREE.Color('#ffffff'), 0.65) }),
  }

  const bike = new THREE.Group()
  bike.name = `${variant}-bike`
  model.add(bike)

  // Rear engine housing and sculpted saddle
  const shellSections = [
    { z: -1.15, w: 0.18, h: 0.15, y: 0.05 },
    { z: -0.65, w: 0.38, h: 0.24, y: 0.02 },
    { z: 0.15, w: 0.52, h: 0.32, y: 0.04 },
    { z: 1.3, w: swoop ? 0.48 : 0.58, h: 0.42, y: 0.02 },
    { z: 2.25, w: swoop ? 0.42 : 0.52, h: 0.38, y: 0.02 },
    { z: 2.65, w: 0.32, h: 0.25, y: 0 },
  ]
  bike.add(new THREE.Mesh(loft(shellSections, 20), shell))
  box(bike, seat, [0.58, 0.16, 1.15], [0, 0.51, 0.72], [-0.06, 0, 0])
  box(bike, accents, [0.68, 0.07, 1.16], [0, 0.4, 0.7])
  if (sport) {
    box(bike, shell, [0.82, 1.0, 0.22], [0, 0.92, 1.42], [-0.22, 0, 0])
    box(bike, seat, [0.56, 0.85, 0.09], [0, 0.98, 1.29], [-0.22, 0, 0])
    box(bike, stripes, [0.7, 0.14, 0.23], [0, 1.42, 1.48], [-0.22, 0, 0])
    for (const side of [-1, 1]) box(bike, accents, [0.08, 0.88, 0.14], [side * 0.35, 1.0, 1.37], [-0.22, 0, 0])
  } else {
    box(bike, dark, [0.54, 0.45, 0.21], [0, 0.68, 1.34], [-0.22, 0, 0])
  }

  // Articulated rear aero-flight wings (deploy wider when pressing N to fly!)
  const flightWings = []
  const liftGlowMat = new THREE.MeshBasicMaterial({
    color: '#4af8ff',
    transparent: true,
    opacity: 0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  })
  for (const side of [-1, 1]) {
    box(bike, shell, [0.12, 0.58, 1.0], [side * 0.54, 0.04, 1.36], [0, 0, side * 0.1])
    box(bike, steel, [0.035, 0.25, 0.32], [side * 0.615, -0.02, 1.44])
    for (let k = 0; k < 3; k++) box(bike, dark, [0.04, 0.025, 0.2], [side * 0.64, -0.08 + k * 0.08, 1.44])

    const wingPivot = new THREE.Group()
    wingPivot.position.set(side * 0.44, -0.22, 1.8)
    panel(wingPivot, shell, [[0, -0.3], [0.78 * side, 0.48], [0.92 * side, 1.28], [0.06 * side, 0.74]], 0.07, plate)
    panel(wingPivot, stripes, [[0.42 * side, 0.46], [0.74 * side, 0.7], [0.8 * side, 1.0], [0.4 * side, 0.76]], 0.08, plate, [0, 0.01, 0])
    // Glowing holographic flight-wing leading edge strip (illuminates in N Flight Mode!)
    const holoEdge = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.035, 0.14), liftGlowMat)
    holoEdge.position.set(side * 0.58, 0.02, 0.36)
    holoEdge.rotation.y = -side * 0.52
    wingPivot.add(holoEdge)
    mergeStaticMeshes(wingPivot)
    bike.add(wingPivot)
    flightWings.push({ side, wingPivot })

    beam(bike, frame, [side * 0.43, -0.24, 0.55], [side * 1.08, -0.45, 0.72], 0.065)
    beam(bike, dark, [side * 0.9, -0.44, 0.48], [side * 1.2, -0.44, 0.48], 0.075)
  }

  // Ventral anti-gravity flight repulsor ring (glows vividly when flying & landing)
  const liftRing = new THREE.Mesh(new THREE.RingGeometry(0.42, 0.78, 20).rotateX(-Math.PI / 2), liftGlowMat)
  liftRing.position.set(0, -0.42, 0.65)
  bike.add(liftRing)
  const frontLiftRing = new THREE.Mesh(new THREE.RingGeometry(0.28, 0.54, 18).rotateX(-Math.PI / 2), liftGlowMat)
  frontLiftRing.position.set(0, -0.38, -3.6)
  bike.add(frontLiftRing)

  addEngine(bike, glows, trails, bikeEngine, 0, 0.02, 2.66, swoop ? 0.53 : 0.43)

  // Long open front outrigger forks & steering vanes
  const nose = new THREE.Group()
  nose.position.set(0, -0.03, -1.0)
  bike.add(nose)
  const tipZ = swoop ? -4.9 : -4.3
  for (const side of [-1, 1]) {
    beam(nose, frame, [side * 0.3, -0.04, 0.2], [side * 0.46, -0.11, tipZ], swoop ? 0.095 : 0.075)
    beam(nose, steel, [side * 0.21, 0.2, -0.05], [side * 0.35, 0.1, tipZ + 0.32], 0.045)
    beam(nose, frame, [side * 0.3, -0.2, -0.4], [side * 0.49, -0.3, tipZ + 0.18], 0.045)
    for (let k = 0; k < 3; k++) {
      const z = -0.65 - k * 1.05
      beam(nose, steel, [side * 0.23, 0.12, z], [side * 0.39, -0.14, z - 0.2], 0.035)
    }
    const wing = swoop ? 1.55 : 1.18
    panel(nose, shell, [[0.18 * side, tipZ + 0.55], [0.55 * side, tipZ - 0.55], [wing * side, tipZ - 1.15], [0.77 * side, tipZ + 0.35]], 0.07, plate, [0, -0.21, 0])
    panel(nose, steel, [[0.39 * side, tipZ + 0.18], [0.65 * side, tipZ - 0.58], [1.03 * side, tipZ - 0.84], [0.76 * side, tipZ - 0.13]], 0.035, plate, [0, -0.12, 0])
    beam(nose, dark, [side * 0.46, -0.11, tipZ - 0.35], [side * 0.57, -0.1, tipZ - 1.25], 0.055)
  }
  for (const z of [-0.35, -1.65, -2.95]) beam(nose, frame, [-0.38, -0.1, z], [0.38, -0.1, z], 0.055)

  // Forward instrument cowling
  const cowling = ellipsoid(bike, scout ? shell : accents, [0.64, 0.22, 0.78], [0, 0.52, -1.1])
  cowling.name = 'front-cowling'
  if (sport || swoop) {
    for (const side of [-1, 1]) {
      box(bike, stripes, [0.12, 0.025, 1.12], [side * 0.19, 0.72, -1.12], [0, 0, side * 0.04])
    }
  }
  ellipsoid(bike, dark, [0.31, 0.06, 0.22], [0, 0.73, -0.88])
  box(bike, M.neon, [0.16, 0.025, 0.08], [0, 0.79, -0.9])

  // Rotating handlebars with left/right grip target anchors for rider arm IK
  const bars = new THREE.Group()
  bars.position.set(0, 1.37, -0.52)
  bike.add(bars)
  beam(bars, steel, [-0.57, 0, 0], [0.57, 0, 0], 0.055)
  const gripL = new THREE.Object3D()
  gripL.position.set(-0.54, 0, 0.02)
  const gripR = new THREE.Object3D()
  gripR.position.set(0.54, 0, 0.02)
  bars.add(gripL, gripR)
  for (const side of [-1, 1]) {
    beam(bars, dark, [side * 0.43, 0, 0], [side * 0.65, 0, 0], 0.07)
    beam(bike, frame, [side * 0.3, 0.55, -0.72], [side * 0.46, 1.37, -0.52], 0.055)
  }

  if (swoop) {
    for (const side of [-1, 1]) {
      const intake = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.26, 1.5, 12).rotateX(Math.PI / 2), steel)
      intake.position.set(side * 0.72, 0.1, 0.98)
      bike.add(intake)
      for (const z of [0.45, 0.8, 1.15, 1.5]) {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.035, 6, 12), accents)
        ring.position.set(side * 0.72, 0.1, z)
        bike.add(ring)
      }
      beam(bike, steel, [side * 0.75, 0.12, 1.7], [side * 0.8, 0.42, 2.35], 0.1)
      addEngine(bike, glows, trails, bikeEngine, side * 0.72, 0.1, 1.78, 0.2)
    }
    const fin = box(bike, accents, [0.08, 0.8, 1.0], [0, 0.68, 2.12], [-0.25, 0, 0])
    fin.name = 'swoop-fin'
  }

  const animateRider = createRider(bike, variant, bars, gripL, gripR)
  mergeStaticMeshes(nose)
  mergeStaticMeshes(bars)
  mergeStaticMeshes(bike)

  return (state, dt) => {
    const h = Math.min(dt || 0.016, 0.05)
    const { squatPos, flyBlend, climbPose } = animateRider(state, h)
    const ease = 1 - Math.exp(-h * 9.5)
    // Steering front forks + subtle nose flex during climbs and cushioned landing squat!
    nose.rotation.y += (-(state.steer || 0) * 0.12 - nose.rotation.y) * ease
    nose.rotation.x += ((squatPos * 0.22 + climbPose * 0.05) - nose.rotation.x) * ease
    // Whole bike hover-suspension bounce on landing + subtle nose-up flare on boost/takeoff
    bike.position.y = squatPos * 0.88
    bike.rotation.x = clamp(squatPos * 0.26 + (state.boost ? 0.035 : 0) + climbPose * 0.06, -0.18, 0.22)
    // Deploy rear stabilizer aero-wings & glow anti-gravity lift rings in N Flight Mode (and flare on landing!)
    const landFlare = clamp((state.landImpact || 0) * 0.85, 0, 0.9)
    liftGlowMat.opacity = clamp(flyBlend * (0.68 + 0.18 * Math.sin((state.time || 0) * 9)) + landFlare * 0.75, 0, 0.95)
    const ringScale = 1 + flyBlend * 0.42 + landFlare * 0.55
    liftRing.scale.setScalar(ringScale)
    frontLiftRing.scale.setScalar(ringScale)
    for (const fw of flightWings) {
      fw.wingPivot.scale.x = 1 + flyBlend * 0.42
      fw.wingPivot.rotation.z = fw.side * (flyBlend * 0.18 - (state.steer || 0) * fw.side * 0.12)
      fw.wingPivot.rotation.x = -climbPose * 0.15
    }
  }
}
