// @ts-nocheck
// Four craft skins, all driving the same way:
//   racer    — a smooth, glossy anti-gravity racer with twin engine pods
//   jet      — the classic voxel fighter from the jet game
//   pod      — a podracer: two huge engines up front, a little cockpit pod trailing on energy cables
//   fighter  — an X-winged starfighter with four engines
// The nose points to -Z, up is +Y, the engines burn towards +Z.
import * as THREE from 'three'
import { decodeJet, JET_W, JET_L, JET_H, JET_PALETTE, JET_PIVOT_K, JET_PIVOT_Y, JET_ENGINE_A, JET_ENGINE_Y, JET_NOZZLE_K } from './jet-model'
import { buildBike } from './bikes'
import { isBike } from './vehicles'

export { SKINS, SKIN_IDS } from './vehicles'

// body = main paint, accent = wings / trim / flames, dark = underside. All saturated, all bright.
export const LIVERIES = [
  { name: 'Kamu', body: '#18c8ff', accent: '#ff2fb4', dark: '#101a3a' },
  { name: 'Solar', body: '#ffc21a', accent: '#ff3d2e', dark: '#3a2208' },
  { name: 'Toxin', body: '#46e05a', accent: '#f4ff3a', dark: '#0e3018' },
  { name: 'Violet', body: '#8a4dff', accent: '#00f0ff', dark: '#1c1040' },
  { name: 'Crimson', body: '#ff2f4d', accent: '#ffd23c', dark: '#3a0e18' },
  { name: 'Ice', body: '#e8f7ff', accent: '#2f7bff', dark: '#10304a' },
  { name: 'Ember', body: '#ff7a1a', accent: '#fff0a0', dark: '#3a1a08' },
  { name: 'Magenta', body: '#ff3fb4', accent: '#7affea', dark: '#34102a' },
  { name: 'Teal', body: '#12e0c0', accent: '#ff5a2a', dark: '#08302a' },
  { name: 'Cobalt', body: '#2f64ff', accent: '#ffe14d', dark: '#0e1840' },
  { name: 'Lime', body: '#b6ff2a', accent: '#8a2bff', dark: '#243a0c' },
  { name: 'Coral', body: '#ff6a5a', accent: '#00e0ff', dark: '#3a1612' },
  { name: 'Pearl', body: '#fff1c2', accent: '#ff8a00', dark: '#3a2c10' },
  { name: 'Aqua', body: '#27c8ff', accent: '#ff3d6e', dark: '#0a2a40' },
  { name: 'Plum', body: '#b02fe0', accent: '#3affa0', dark: '#280c34' },
  { name: 'Chrome', body: '#d4dcf0', accent: '#ff2f2f', dark: '#1a1c28' },
]

let glowTex = null
let flameTex = null
function textures() {
  if (glowTex) return
  const c = document.createElement('canvas')
  c.width = c.height = 128
  const g = c.getContext('2d')
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64)
  grd.addColorStop(0, 'rgba(255,255,255,1)')
  grd.addColorStop(0.25, 'rgba(255,255,255,0.55)')
  grd.addColorStop(1, 'rgba(255,255,255,0)')
  g.fillStyle = grd
  g.fillRect(0, 0, 128, 128)
  glowTex = new THREE.CanvasTexture(c)
  glowTex.colorSpace = THREE.SRGBColorSpace
  // a flame: bright at the nozzle, fading along its length and towards its edges
  const c2 = document.createElement('canvas')
  c2.width = 128
  c2.height = 32
  const g2 = c2.getContext('2d')
  const lg = g2.createLinearGradient(0, 0, 128, 0)
  lg.addColorStop(0, 'rgba(255,255,255,1)')
  lg.addColorStop(0.25, 'rgba(255,255,255,0.7)')
  lg.addColorStop(1, 'rgba(255,255,255,0)')
  g2.fillStyle = lg
  g2.fillRect(0, 0, 128, 32)
  const vg = g2.createLinearGradient(0, 0, 0, 32)
  vg.addColorStop(0, 'rgba(0,0,0,1)')
  vg.addColorStop(0.5, 'rgba(0,0,0,0)')
  vg.addColorStop(1, 'rgba(0,0,0,1)')
  g2.globalCompositeOperation = 'destination-out'
  g2.fillStyle = vg
  g2.fillRect(0, 0, 128, 32)
  flameTex = new THREE.CanvasTexture(c2)
  flameTex.colorSpace = THREE.SRGBColorSpace
}

const lumOf = (r, g, b) => 0.299 * r + 0.587 * g + 0.114 * b
const hex = (h) => [(parseInt(h.slice(1), 16) >> 16) & 255, (parseInt(h.slice(1), 16) >> 8) & 255, parseInt(h.slice(1), 16) & 255]

/** the fighter's palette with its three colour families swapped for new key colours */
function recolor(body, accent, canopy) {
  const keys = { 0: { key: 4, col: body }, 1: { key: 3, col: accent }, 2: { key: 3, col: canopy } }
  const keyLum = {}
  for (const row of JET_PALETTE) {
    const fam = row[4]
    if (fam < 3 && ((row[0] - 1) & 15) === keys[fam].key) keyLum[fam] = lumOf(row[1], row[2], row[3])
  }
  const palette = {}
  for (const row of JET_PALETTE) {
    const [idx, r, g, b, fam] = row
    let c = [r, g, b]
    if (fam < 3) {
      const k = keys[fam]
      const l = lumOf(r, g, b)
      const kl = keyLum[fam] || 100
      if (l <= kl) c = k.col.map((v) => v * (l / kl))
      else c = k.col.map((v) => v + (255 - v) * ((l - kl) / (255 - kl)))
    }
    palette[idx] = c
  }
  return palette
}

/** colours for the cockpit, in the pilot's livery: gunmetal framework, painted parts in the accent colour */
export function cockpitPalette(liveryIdx: number, tod: string) {
  const lv = LIVERIES[liveryIdx % LIVERIES.length]
  const b = hex(lv.body)
  const gun = [84, 89, 105]
  const body = recolor([b[0] * 0.35 + gun[0] * 0.65, b[1] * 0.35 + gun[1] * 0.65, b[2] * 0.35 + gun[2] * 0.65], hex(lv.accent), [30, 150, 190])
  const grade = (c) => (tod === 'night' ? [c[0] * 0.55, c[1] * 0.6, c[2] * 0.85] : tod === 'sunset' ? [Math.min(255, c[0] * 1.05 + 8), c[1] * 0.92, c[2] * 0.82] : c)
  const pack = (c) => {
    const g = grade(c)
    return ((255 << 24) | (Math.min(255, Math.round(g[2])) << 16) | (Math.min(255, Math.round(g[1])) << 8) | Math.min(255, Math.round(g[0]))) >>> 0
  }
  const B = []
  for (let t = 0; t < 9; t++) B.push(pack(body[1 + t]))
  const A = []
  for (let t = 0; t < 6; t++) A.push(pack(body[17 + t]))
  return { body: B, hot: A }
}

// ───────────────────────────────────────────────────────────── shapes

/** a smooth shell: super-elliptic cross-sections strung along z */
function loft(secs, seg = 24) {
  const pos = []
  const idx = []
  const S = secs.length
  for (let s = 0; s < S; s++) {
    const { z, w, h, y = 0, x = 0, p = 2.5 } = secs[s]
    for (let k = 0; k < seg; k++) {
      const t = (k / seg) * Math.PI * 2
      const c = Math.cos(t)
      const sn = Math.sin(t)
      pos.push(x + w * Math.sign(c) * Math.pow(Math.abs(c), 2 / p), y + h * Math.sign(sn) * Math.pow(Math.abs(sn), 2 / p), z)
    }
  }
  for (let s = 0; s < S - 1; s++) {
    for (let k = 0; k < seg; k++) {
      const a = s * seg + k
      const b = s * seg + ((k + 1) % seg)
      const c = (s + 1) * seg + k
      const d = (s + 1) * seg + ((k + 1) % seg)
      idx.push(a, c, b, b, c, d)
    }
  }
  const n0 = pos.length / 3
  pos.push(secs[0].x || 0, secs[0].y || 0, secs[0].z)
  pos.push(secs[S - 1].x || 0, secs[S - 1].y || 0, secs[S - 1].z)
  for (let k = 0; k < seg; k++) {
    idx.push(n0, k, (k + 1) % seg)
    idx.push(n0 + 1, (S - 1) * seg + ((k + 1) % seg), (S - 1) * seg + k)
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
  g.setIndex(idx)
  g.computeVertexNormals()
  return g
}

/** a flat plate with rounded edges, outline given as [x, z] points */
function plate(points, depth, bevel = 0.05) {
  const sh = new THREE.Shape()
  points.forEach(([x, z], i) => (i ? sh.lineTo(x, -z) : sh.moveTo(x, -z)))
  sh.closePath()
  const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: true, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 2, steps: 1 })
  g.rotateX(-Math.PI / 2)
  return g
}

const Y_AXIS = new THREE.Vector3(0, 1, 0)
/** a cylinder between two points */
function rod(a, b, r, mat) {
  const A = new THREE.Vector3(...a)
  const B = new THREE.Vector3(...b)
  const d = new THREE.Vector3().subVectors(B, A)
  const len = d.length()
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 8), mat)
  m.position.copy(A).addScaledVector(d, 0.5)
  m.quaternion.setFromUnitVectors(Y_AXIS, d.normalize())
  return m
}

function paints(lv) {
  const body = new THREE.Color(lv.body)
  const acc = new THREE.Color(lv.accent)
  const hot = acc.clone().lerp(new THREE.Color('#ffffff'), 0.55)
  return {
    body, acc, hot,
    // bright, glossy paint that never goes dull in shade (it glows a little by itself)
    paint: new THREE.MeshStandardMaterial({ color: body, roughness: 0.24, metalness: 0.2, emissive: body.clone().multiplyScalar(0.34), side: THREE.DoubleSide }),
    trim: new THREE.MeshStandardMaterial({ color: acc, roughness: 0.3, metalness: 0.1, emissive: acc.clone().multiplyScalar(0.85), side: THREE.DoubleSide }),
    dark: new THREE.MeshStandardMaterial({ color: lv.dark, roughness: 0.4, metalness: 0.5, emissive: new THREE.Color(lv.dark).multiplyScalar(0.5), side: THREE.DoubleSide }),
    glass: new THREE.MeshStandardMaterial({ color: '#0a1838', roughness: 0.04, metalness: 0.7, emissive: acc.clone().multiplyScalar(0.3) }),
    neon: new THREE.MeshBasicMaterial({ color: hot }),
  }
}

/** a nozzle with its glow and a two-layer flame that stretches along +z */
function addEngine(model, glows, trails, M, x, y, z, r) {
  const noz = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.88, r, r * 1.1, 18, 1, true).rotateX(Math.PI / 2), M.dark)
  noz.position.set(x, y, z - r * 0.2)
  model.add(noz)
  const disc = new THREE.Mesh(new THREE.CircleGeometry(r * 0.84, 18), M.neon)
  disc.position.set(x, y, z + r * 0.36)
  model.add(disc)
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: M.hot, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.95 }))
  sp.position.set(x, y, z + r * 0.7)
  sp.scale.setScalar(r * 4.3)
  sp.userData.baseScale = r * 4.3
  model.add(sp)
  glows.push(sp)
  const tg = new THREE.Group()
  tg.position.set(x, y, z + r * 0.4)
  const flame = (col, w, op) => {
    const m = new THREE.MeshBasicMaterial({ map: flameTex, color: col, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, side: THREE.DoubleSide, opacity: op })
    const g1 = new THREE.PlaneGeometry(1, w).translate(0.5, 0, 0).rotateY(-Math.PI / 2)
    const g2 = g1.clone().rotateZ(Math.PI / 2)
    tg.add(new THREE.Mesh(g1, m), new THREE.Mesh(g2, m))
  }
  flame(M.acc.clone().lerp(new THREE.Color('#ffffff'), 0.25), r * 2.4, 0.95)
  flame(new THREE.Color('#ffffff'), r * 1.1, 0.9)
  model.add(tg)
  trails.push(tg)
}

// ───────────────────────────────────────────────────────────── 1 · racer
function buildRacer(model, glows, trails, M) {
  const { paint, trim, dark, glass, neon, acc } = M
  const fus = new THREE.Mesh(
    loft([
      { z: -3.7, w: 0.05, h: 0.05, y: -0.02 },
      { z: -3.1, w: 0.3, h: 0.2, y: -0.02 },
      { z: -2.1, w: 0.58, h: 0.32, y: 0.0 },
      { z: -0.9, w: 0.8, h: 0.44, y: 0.06 },
      { z: 0.4, w: 0.86, h: 0.48, y: 0.08 },
      { z: 1.5, w: 0.66, h: 0.38, y: 0.05 },
      { z: 2.4, w: 0.34, h: 0.22, y: 0.02 },
      { z: 2.8, w: 0.1, h: 0.1, y: 0.0 },
    ], 26),
    paint,
  )
  model.add(fus)
  model.add(new THREE.Mesh(loft([{ z: -3.74, w: 0.03, h: 0.03, y: -0.02 }, { z: -3.35, w: 0.17, h: 0.12, y: -0.02 }, { z: -3.0, w: 0.3, h: 0.2, y: -0.02 }], 16), trim))
  const can = new THREE.Mesh(new THREE.SphereGeometry(0.5, 20, 12), glass)
  can.scale.set(0.58, 0.36, 1.2)
  can.position.set(0, 0.5, -0.5)
  model.add(can)
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.045, 8, 28), trim)
  rim.scale.set(0.58, 1.2, 1)
  rim.rotation.x = Math.PI / 2
  rim.position.set(0, 0.49, -0.5)
  model.add(rim)
  for (const side of [-1, 1]) {
    const X = 2.0 * side
    const pod = new THREE.Mesh(
      loft([
        { z: -2.5, w: 0.1, h: 0.1, y: 0.1 },
        { z: -1.7, w: 0.46, h: 0.4, y: 0.12 },
        { z: -0.2, w: 0.6, h: 0.5, y: 0.12 },
        { z: 1.5, w: 0.58, h: 0.48, y: 0.12 },
        { z: 2.5, w: 0.5, h: 0.42, y: 0.12 },
        { z: 2.8, w: 0.44, h: 0.38, y: 0.12 },
      ], 24),
      paint,
    )
    pod.position.x = X
    model.add(pod)
    for (const z of [-1.2, 0.9]) {
      const r = new THREE.Mesh(new THREE.TorusGeometry(0.56, 0.075, 8, 24), trim)
      r.position.set(X, 0.12, z)
      model.add(r)
    }
    const wing = new THREE.Mesh(plate([[0.55 * side, -1.5], [1.55 * side, -0.7], [1.65 * side, 1.1], [0.7 * side, 1.9]], 0.09, 0.04), trim)
    wing.position.y = 0.1
    model.add(wing)
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.85, 1.0), trim)
    fin.position.set(X + 0.2 * side, 0.74, 2.0)
    fin.rotation.z = -0.22 * side
    fin.rotation.x = -0.18
    model.add(fin)
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.06, 2.8), neon)
    strip.position.set(X, -0.4, 0.4)
    model.add(strip)
    addEngine(model, glows, trails, M, X, 0.12, 2.9, 0.42)
  }
  const spoiler = new THREE.Mesh(new THREE.BoxGeometry(4.3, 0.09, 0.6), trim)
  spoiler.position.set(0, 0.7, 2.25)
  model.add(spoiler)
  const mast = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.5, 0.7), trim)
  mast.position.set(0, 0.5, 2.0)
  model.add(mast)
  void dark
  void acc
}

// ───────────────────────────────────────────────────────────── 2 · classic voxel jet
const VS = 0.15 // metres per voxel
let slices = null
const geoCache = new Map()
const toLin = (rgb) => {
  const c = new THREE.Color().setRGB(Math.min(255, Math.max(0, rgb[0])) / 255, Math.min(255, Math.max(0, rgb[1])) / 255, Math.min(255, Math.max(0, rgb[2])) / 255, THREE.SRGBColorSpace)
  return [c.r, c.g, c.b]
}
/** the fighter's sprite stack, recoloured for a livery, as one mesh of exposed voxel faces */
function jetGeometry(liveryIdx) {
  const key = liveryIdx % LIVERIES.length
  if (geoCache.has(key)) return geoCache.get(key)
  if (!slices) slices = decodeJet()
  const lv = LIVERIES[key]
  const palette = recolor(hex(lv.body), hex(lv.accent), [30, 150, 190])
  const W = JET_W, L = JET_L, H = JET_H
  const at = (x, y, k) => (x < 0 || x >= W || k < 0 || k >= L || y < 0 || y >= H ? 0 : slices[y][k * W + x])
  const pos = []
  const col = []
  const idxs = []
  const face = (p, c) => {
    const v = pos.length / 3
    pos.push(...p[0], ...p[1], ...p[2], ...p[3])
    for (let i = 0; i < 4; i++) col.push(c[0], c[1], c[2])
    idxs.push(v, v + 1, v + 2, v, v + 2, v + 3)
  }
  for (let y = 0; y < H; y++) {
    for (let k = 0; k < L; k++) {
      for (let x = 0; x < W; x++) {
        const v = at(x, y, k)
        if (!v) continue
        const base = palette[v]
        const lin = (f) => toLin(base.map((c) => c * f))
        const px = (x - (W - 1) / 2) * VS
        const py = (y - JET_PIVOT_Y) * VS
        const pz = (k - JET_PIVOT_K) * VS
        const x0 = px - VS / 2, x1 = px + VS / 2, y0 = py, y1 = py + VS, z0 = pz - VS / 2, z1 = pz + VS / 2
        if (!at(x, y + 1, k)) face([[x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0]], lin(1.05))
        if (!at(x, y - 1, k)) face([[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]], lin(0.62))
        if (!at(x + 1, y, k)) face([[x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]], lin(0.86))
        if (!at(x - 1, y, k)) face([[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], lin(0.76))
        if (!at(x, y, k + 1)) face([[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], lin(0.7))
        if (!at(x, y, k - 1)) face([[x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [x1, y0, z0]], lin(0.95))
      }
    }
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3))
  g.setIndex(idxs)
  g.userData.sharedGeometry = true
  geoCache.set(key, g)
  return g
}
function buildJet(model, glows, trails, M, liveryIdx) {
  model.add(new THREE.Mesh(jetGeometry(liveryIdx), new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide })))
  const nozY = (JET_ENGINE_Y - JET_PIVOT_Y) * VS
  const nozZ = (JET_NOZZLE_K - JET_PIVOT_K) * VS
  const nozX = JET_ENGINE_A * VS
  for (const side of [-1, 1]) addEngine(model, glows, trails, M, nozX * side, nozY, nozZ, 0.2)
}

// ───────────────────────────────────────────────────────────── 3 · podracer
// Two huge engines side by side up front; a slim cockpit pod trails behind, joined by energy cables.
function buildPod(model, glows, trails, M) {
  const { paint, trim, dark, glass, neon, acc } = M
  const EX = 2.55
  const EY = 0.25
  for (const side of [-1, 1]) {
    const X = EX * side
    // the barrel
    const barrel = new THREE.Mesh(
      loft([
        { z: -3.3, w: 0.84, h: 0.84, y: EY },
        { z: -2.6, w: 0.98, h: 0.98, y: EY },
        { z: -0.4, w: 1.04, h: 1.04, y: EY },
        { z: 1.3, w: 0.98, h: 0.98, y: EY },
        { z: 2.0, w: 0.86, h: 0.86, y: EY },
      ], 28),
      paint,
    )
    barrel.position.x = X
    model.add(barrel)
    // the air intake: a dark cone, with a bright lip
    const intake = new THREE.Mesh(
      loft([
        { z: -4.5, w: 0.04, h: 0.04, y: EY },
        { z: -4.0, w: 0.36, h: 0.36, y: EY },
        { z: -3.5, w: 0.7, h: 0.7, y: EY },
        { z: -3.25, w: 0.84, h: 0.84, y: EY },
      ], 24),
      dark,
    )
    intake.position.x = X
    model.add(intake)
    const lip = new THREE.Mesh(new THREE.TorusGeometry(0.88, 0.1, 8, 28), trim)
    lip.position.set(X, EY, -3.25)
    model.add(lip)
    for (const z of [-2.0, -0.4, 1.0]) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.05, 0.08, 8, 30), trim)
      ring.position.set(X, EY, z)
      model.add(ring)
    }
    // a stabiliser fin on top, and a vane underneath
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.8, 1.9), trim)
    fin.position.set(X, EY + 1.2, 0.6)
    fin.rotation.x = -0.12
    model.add(fin)
    const vane = new THREE.Mesh(plate([[0.2 * side, -2.2], [1.5 * side, -1.2], [1.5 * side, -0.4], [0.2 * side, -0.6]], 0.07, 0.03), trim)
    vane.position.set(X, EY - 0.7, 0)
    model.add(vane)
    // the rear: nozzle and flame
    addEngine(model, glows, trails, M, X, EY, 2.1, 0.78)
    // the energy cables to the pod
    model.add(rod([X * 0.86, EY, 1.9], [side * 0.28, 0.18, 3.5], 0.1, dark))
    model.add(rod([X * 0.86, EY + 0.28, 1.9], [side * 0.28, 0.3, 3.5], 0.06, neon))
    model.add(rod([X * 0.86, EY - 0.28, 1.9], [side * 0.28, 0.06, 3.5], 0.06, neon))
  }
  // the coupling between the engines, and a glowing binder across the front
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(2 * EX - 1.6, 0.22, 0.7), paint)
  bridge.position.set(0, EY, -1.5)
  model.add(bridge)
  model.add(rod([-EX + 0.9, EY + 0.45, -2.6], [EX - 0.9, EY + 0.45, -2.6], 0.09, neon))
  model.add(rod([-EX + 0.9, EY - 0.1, -2.9], [EX - 0.9, EY - 0.1, -2.9], 0.06, neon))
  // the pod
  const pod = new THREE.Mesh(
    loft([
      { z: 2.9, w: 0.05, h: 0.05, y: 0.15 },
      { z: 3.5, w: 0.42, h: 0.3, y: 0.15 },
      { z: 4.6, w: 0.62, h: 0.44, y: 0.2 },
      { z: 5.8, w: 0.5, h: 0.36, y: 0.16 },
      { z: 6.9, w: 0.14, h: 0.14, y: 0.1 },
    ], 24),
    paint,
  )
  model.add(pod)
  const can = new THREE.Mesh(new THREE.SphereGeometry(0.5, 20, 12), glass)
  can.scale.set(0.5, 0.34, 1.0)
  can.position.set(0, 0.62, 4.2)
  model.add(can)
  const prim = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.04, 8, 24), trim)
  prim.scale.set(0.5, 1.0, 1)
  prim.rotation.x = Math.PI / 2
  prim.position.set(0, 0.6, 4.2)
  model.add(prim)
  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.7, 1.2), trim)
  tail.position.set(0, 0.62, 6.1)
  tail.rotation.x = -0.2
  model.add(tail)
  const glowStrip = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 2.4), neon)
  glowStrip.position.set(0, -0.28, 4.7)
  model.add(glowStrip)
  void acc
  // everything is centred round the middle of the craft
  model.position.z = -1.1
}

// ───────────────────────────────────────────────────────────── 4 · X-winged starfighter
function buildFighter(model, glows, trails, M) {
  const { paint, trim, dark, glass, neon } = M
  const fus = new THREE.Mesh(
    loft([
      { z: -5.0, w: 0.03, h: 0.03, y: 0.0 },
      { z: -4.2, w: 0.14, h: 0.12, y: 0.0 },
      { z: -3.0, w: 0.32, h: 0.24, y: 0.02 },
      { z: -1.6, w: 0.54, h: 0.38, y: 0.04 },
      { z: 0.0, w: 0.7, h: 0.5, y: 0.06 },
      { z: 1.6, w: 0.8, h: 0.52, y: 0.06 },
      { z: 2.6, w: 0.68, h: 0.46, y: 0.04 },
      { z: 3.1, w: 0.5, h: 0.34, y: 0.02 },
    ], 26),
    paint,
  )
  model.add(fus)
  model.add(new THREE.Mesh(loft([{ z: -5.04, w: 0.02, h: 0.02, y: 0 }, { z: -4.5, w: 0.09, h: 0.08, y: 0 }, { z: -3.6, w: 0.22, h: 0.17, y: 0.01 }], 16), trim))
  const can = new THREE.Mesh(new THREE.SphereGeometry(0.5, 20, 12), glass)
  can.scale.set(0.56, 0.4, 1.3)
  can.position.set(0, 0.52, -0.9)
  model.add(can)
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.04, 8, 28), trim)
  rim.scale.set(0.56, 1.3, 1)
  rim.rotation.x = Math.PI / 2
  rim.position.set(0, 0.5, -0.9)
  model.add(rim)
  // the droid dome behind the cockpit
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.34, 16, 10), trim)
  dome.position.set(0, 0.66, 1.3)
  model.add(dome)
  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), neon)
  eye.position.set(0, 0.72, 0.99)
  model.add(eye)
  // four wings in an X, each with an engine at the root and a long cannon at the tip
  const TH = 0.3
  for (const sx of [-1, 1]) {
    for (const sy of [-1, 1]) {
      const wg = new THREE.Group()
      wg.rotation.z = sx * sy * TH
      const wing = new THREE.Mesh(plate([[0.5 * sx, -0.5], [3.5 * sx, 0.6], [3.5 * sx, 1.4], [0.5 * sx, 2.3]], 0.07, 0.035), paint)
      wing.position.y = -0.03
      wg.add(wing)
      const stripe = new THREE.Mesh(plate([[1.5 * sx, 0.1], [3.4 * sx, 0.7], [3.4 * sx, 1.0], [1.5 * sx, 0.55]], 0.09, 0.03), trim)
      stripe.position.y = -0.04
      wg.add(stripe)
      model.add(wg)
      // where the tip ends up after the tilt
      const tx = 3.5 * sx * Math.cos(TH)
      const ty = sy * 3.5 * Math.sin(TH)
      model.add(rod([tx, ty, -2.6], [tx, ty, 1.2], 0.07, dark))
      const tip = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), neon)
      tip.position.set(tx, ty, -2.62)
      model.add(tip)
      // the engine
      const ex = 1.4 * sx
      const ey = sy * 0.5
      const eng = new THREE.Mesh(
        loft([
          { z: -0.9, w: 0.2, h: 0.2, y: ey, x: ex },
          { z: -0.2, w: 0.42, h: 0.42, y: ey, x: ex },
          { z: 1.6, w: 0.46, h: 0.46, y: ey, x: ex },
          { z: 2.9, w: 0.4, h: 0.4, y: ey, x: ex },
        ], 22),
        paint,
      )
      model.add(eng)
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.47, 0.06, 8, 22), trim)
      ring.position.set(ex, ey, 0.9)
      model.add(ring)
      addEngine(model, glows, trails, M, ex, ey, 2.95, 0.36)
    }
  }
  model.position.y = 0.18
}

// ───────────────────────────────────────────────────────────── assemble
export function makeShip(liveryIdx: number, skin: string = 'racer') {
  textures()
  const lv = LIVERIES[liveryIdx % LIVERIES.length]
  const root = new THREE.Group()
  const model = new THREE.Group()
  root.add(model)
  const M = paints(lv)
  const glows = []
  const trails = []
  let animate = null
  if (isBike(skin)) animate = buildBike(model, glows, trails, M, skin, liveryIdx, { loft, plate, addEngine })
  else {
    if (skin === 'jet') buildJet(model, glows, trails, M, liveryIdx)
    else if (skin === 'pod') buildPod(model, glows, trails, M)
    else if (skin === 'fighter') buildFighter(model, glows, trails, M)
    else buildRacer(model, glows, trails, M)
    const baseY = model.position.y
    let sqP = 0, sqV = 0, lastL = 0, bank = 0, pitchA = 0
    animate = (state, dt) => {
      const h = Math.min(dt || 0.016, 0.05)
      const li = state.landImpact || 0
      if (li > lastL + 0.08) sqV -= Math.min(1.5, li) * 4.2
      lastL = li
      sqV += (-sqP * 88 - sqV * 10.5) * h
      sqP = Math.max(-0.4, Math.min(0.22, sqP + sqV * h))
      const ease = 1 - Math.exp(-h * 9)
      bank += (-(state.steer || 0) * (state.flying ? 0.28 : 0.16) - bank) * ease
      const climbGoal = Math.max(-0.22, Math.min(0.24, (state.vy || 0) * 0.005 + (state.climb || 0) * 0.1 + sqP * 0.3))
      pitchA += (climbGoal - pitchA) * ease
      model.position.y = baseY + sqP * 0.95
      model.rotation.z = bank
      model.rotation.x = pitchA
    }
  }
  // light on the ground under the craft
  const under = new THREE.Mesh(
    new THREE.PlaneGeometry(7, 9),
    new THREE.MeshBasicMaterial({ map: glowTex, color: isBike(skin) ? (skin === 'scout' ? '#76dff2' : skin === 'sport' ? '#ffc273' : '#ff934f') : M.acc, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.6 }),
  )
  under.rotation.x = -Math.PI / 2
  under.position.set(0, -1.3, 0.3)
  root.add(under)
  return { root, model, glows, trails, under, livery: lv, bodyMat: M.paint, skin, animate }
}

export function disposeShip(ship) {
  const geometries = new Set()
  const materials = new Set()
  ship.root.traverse((object) => {
    if (object.geometry && !object.isSprite && !object.geometry.userData.sharedGeometry) geometries.add(object.geometry)
    if (object.material) {
      for (const material of Array.isArray(object.material) ? object.material : [object.material]) materials.add(material)
    }
  })
  geometries.forEach((geometry) => geometry.dispose())
  materials.forEach((material) => material.dispose())
}
