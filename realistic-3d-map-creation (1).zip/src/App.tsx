import { useEffect, useState, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import * as THREE from 'three';
import Scene from './components/Scene';
import EngineAudio from './components/EngineAudio';
import { input, playerState } from './world/systems';

function useHud() {
  const [hud, setHud] = useState({ speed: 0, drifting: false, cam: 0 });
  useEffect(() => {
    const id = setInterval(() => {
      setHud({ speed: playerState.speed, drifting: playerState.drifting, cam: playerState.cameraMode });
    }, 120);
    return () => clearInterval(id);
  }, []);
  return hud;
}

const CAM_NAMES = ['CHASE', 'TRACKSIDE', 'HOOD'];

function TouchButton({
  label,
  onPress,
  onRelease,
  className = '',
}: {
  label: string;
  onPress: () => void;
  onRelease: () => void;
  className?: string;
}) {
  return (
    <button
      className={`select-none rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-sm font-semibold text-white/90 backdrop-blur-sm active:bg-white/30 ${className}`}
      onPointerDown={(e) => {
        e.preventDefault();
        onPress();
      }}
      onPointerUp={onRelease}
      onPointerLeave={onRelease}
      onPointerCancel={onRelease}
      onContextMenu={(e) => e.preventDefault()}
    >
      {label}
    </button>
  );
}

export default function App() {
  const [started, setStarted] = useState(false);
  const [audio, setAudio] = useState(false);
  const hud = useHud();
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    setIsTouch('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  const start = useCallback(() => {
    setStarted(true);
    setAudio(true);
  }, []);

  useEffect(() => {
    const onKey = () => {
      if (!started) start();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [started, start]);

  const kmh = Math.round(hud.speed * 3.6);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#cdd8cc] font-sans">
      <Canvas
        shadows
        dpr={[1, 1.5]}
        camera={{ fov: 62, near: 0.3, far: 420, position: [0, 3, 8] }}
        gl={{
          antialias: false,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.25,
          powerPreference: 'high-performance',
        }}
        onCreated={({ gl }) => {
          gl.shadowMap.type = THREE.PCFShadowMap;
        }}
      >
        <Scene />
      </Canvas>

      <EngineAudio enabled={audio} />

      {/* HUD */}
      <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-4 sm:p-6">
        <div className="flex items-start justify-between">
          <div className="rounded-lg bg-black/30 px-3 py-2 text-white backdrop-blur-sm">
            <div className="text-[10px] tracking-[0.3em] text-white/60">GUNMA · 峠</div>
            <div className="text-lg font-bold leading-tight tracking-wide">杉林ドリフト<span className="ml-2 text-xs font-normal text-white/60">Cedar Touge</span></div>
          </div>
          <div className="rounded-lg bg-black/30 px-3 py-2 text-right text-white backdrop-blur-sm">
            <div className="text-[10px] tracking-[0.3em] text-white/60">CAMERA · C</div>
            <div className="text-sm font-semibold">{CAM_NAMES[hud.cam]}</div>
          </div>
        </div>

        <div className="flex items-end justify-between">
          <div className="hidden rounded-lg bg-black/30 px-3 py-2 text-[11px] leading-relaxed text-white/80 backdrop-blur-sm sm:block">
            <div><span className="font-bold text-white">W / S</span> gas · brake</div>
            <div><span className="font-bold text-white">A / D</span> steer</div>
            <div><span className="font-bold text-white">SPACE</span> handbrake (drift)</div>
            <div><span className="font-bold text-white">R</span> reset · <span className="font-bold text-white">C</span> camera</div>
          </div>
          <div className="rounded-lg bg-black/30 px-4 py-2 text-right text-white backdrop-blur-sm">
            <div className={`text-[10px] tracking-[0.3em] ${hud.drifting ? 'text-orange-300' : 'text-white/60'}`}>
              {hud.drifting ? 'DRIFT' : 'SPEED'}
            </div>
            <div className="text-3xl font-black tabular-nums leading-none">
              {kmh}
              <span className="ml-1 text-xs font-medium text-white/60">km/h</span>
            </div>
          </div>
        </div>
      </div>

      {/* touch controls */}
      {isTouch && started && (
        <div className="absolute inset-x-0 bottom-20 flex items-end justify-between px-4">
          <div className="flex gap-2">
            <TouchButton label="◀" onPress={() => (input.left = 1)} onRelease={() => (input.left = 0)} className="px-6 py-5" />
            <TouchButton label="▶" onPress={() => (input.right = 1)} onRelease={() => (input.right = 0)} className="px-6 py-5" />
          </div>
          <div className="flex gap-2">
            <TouchButton label="HB" onPress={() => (input.handbrake = 1)} onRelease={() => (input.handbrake = 0)} className="px-5 py-5" />
            <TouchButton label="▼" onPress={() => (input.back = 1)} onRelease={() => (input.back = 0)} className="px-5 py-5" />
            <TouchButton label="▲" onPress={() => (input.forward = 1)} onRelease={() => (input.forward = 0)} className="px-6 py-5" />
          </div>
        </div>
      )}
      {isTouch && started && (
        <button
          className="absolute right-4 top-16 rounded-lg bg-black/35 px-3 py-1 text-xs text-white"
          onClick={() => (input.camToggle = true)}
        >
          CAM
        </button>
      )}

      {/* start overlay */}
      {!started && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/45 backdrop-blur-[2px]">
          <button
            onClick={start}
            className="group rounded-2xl border border-white/20 bg-black/50 px-10 py-8 text-center text-white shadow-2xl transition hover:bg-black/60"
          >
            <div className="text-[11px] tracking-[0.4em] text-white/60">群馬 · 杉の峠</div>
            <div className="mt-1 text-4xl font-black tracking-tight">CEDAR TOUGE</div>
            <div className="mt-2 text-sm text-white/70">Jalan aspal berkelok di hutan sugi — drift sepuasnya.</div>
            <div className="mt-6 inline-block rounded-full bg-white px-6 py-2 text-sm font-bold text-black transition group-hover:scale-105">
              TAP / TEKAN TOMBOL APA SAJA
            </div>
            <div className="mt-4 text-[11px] text-white/50">WASD · SPACE handbrake · C camera · R reset</div>
          </button>
        </div>
      )}
    </div>
  );
}
