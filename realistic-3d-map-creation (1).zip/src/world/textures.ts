import * as THREE from 'three';
import { mulberry32 } from './noise';

function makeCanvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return c;
}

function toTex(c: HTMLCanvasElement, repeat = true, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

// ---------------------------------------------------------------------------
// ASPHALT — worn mountain road: grey-black aggregate, patches, wheel polish,
// cracks. u = across road, v = along road.
// ---------------------------------------------------------------------------
export function makeAsphalt() {
  const S = 1024;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(42);
  ctx.fillStyle = '#5e5e5c';
  ctx.fillRect(0, 0, S, S);

  // large tonal patches (repairs, damp areas)
  for (let i = 0; i < 40; i++) {
    const x = rnd() * S;
    const y = rnd() * S;
    const r = 80 + rnd() * 240;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    const dark = rnd() > 0.5;
    const a = 0.08 + rnd() * 0.12;
    g.addColorStop(0, dark ? `rgba(30,30,30,${a})` : `rgba(120,118,112,${a})`);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  // aggregate grain
  const img = ctx.getImageData(0, 0, S, S);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (rnd() - 0.5) * 70;
    const spark = rnd() > 0.985 ? 60 : 0;
    const dark = rnd() > 0.97 ? -45 : 0;
    d[i] = Math.max(0, Math.min(255, d[i] + n + spark + dark));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n + spark + dark));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n * 0.9 + spark + dark));
  }
  ctx.putImageData(img, 0, 0);

  // wheel-polished tracks (darker, smoother) running along v
  const tracks = [0.27, 0.73];
  for (const tx of tracks) {
    const g = ctx.createLinearGradient(tx * S - 120, 0, tx * S + 120, 0);
    g.addColorStop(0, 'rgba(20,20,20,0)');
    g.addColorStop(0.5, 'rgba(20,20,20,0.28)');
    g.addColorStop(1, 'rgba(20,20,20,0)');
    ctx.fillStyle = g;
    ctx.fillRect(tx * S - 120, 0, 240, S);
  }
  // middle faded lighter strip (less traffic)
  {
    const g = ctx.createLinearGradient(S * 0.42, 0, S * 0.58, 0);
    g.addColorStop(0, 'rgba(140,135,125,0)');
    g.addColorStop(0.5, 'rgba(140,135,125,0.12)');
    g.addColorStop(1, 'rgba(140,135,125,0)');
    ctx.fillStyle = g;
    ctx.fillRect(S * 0.42, 0, S * 0.16, S);
  }

  // cracks
  ctx.strokeStyle = 'rgba(15,15,15,0.55)';
  ctx.lineCap = 'round';
  for (let i = 0; i < 26; i++) {
    let x = rnd() * S;
    let y = rnd() * S;
    ctx.lineWidth = 1 + rnd() * 1.5;
    ctx.beginPath();
    ctx.moveTo(x, y);
    const steps = 8 + Math.floor(rnd() * 14);
    for (let s = 0; s < steps; s++) {
      x += (rnd() - 0.5) * 50;
      y += (rnd() - 0.3) * 50;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  // tar snakes (crack sealant)
  ctx.strokeStyle = 'rgba(22,22,24,0.8)';
  for (let i = 0; i < 6; i++) {
    let x = rnd() * S;
    let y = rnd() * S;
    ctx.lineWidth = 5 + rnd() * 4;
    ctx.beginPath();
    ctx.moveTo(x, y);
    for (let s = 0; s < 10; s++) {
      x += (rnd() - 0.5) * 70;
      y += (rnd() - 0.2) * 70;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  // white edge lines, worn
  const lineW = S * 0.022;
  const inset = S * 0.035;
  for (const lx of [inset, S - inset - lineW]) {
    ctx.fillStyle = 'rgba(225,222,210,0.85)';
    ctx.fillRect(lx, 0, lineW, S);
    // wear
    for (let i = 0; i < 1400; i++) {
      ctx.fillStyle = `rgba(70,70,68,${0.25 + rnd() * 0.5})`;
      const w = 1 + rnd() * 4;
      ctx.fillRect(lx + rnd() * lineW, rnd() * S, w, 1 + rnd() * 6);
    }
  }
  // dirt / leaf debris near edges
  for (let i = 0; i < 900; i++) {
    const side = rnd() > 0.5;
    const x = side ? rnd() * S * 0.08 : S - rnd() * S * 0.08;
    const y = rnd() * S;
    ctx.fillStyle = `rgba(${90 + rnd() * 60},${70 + rnd() * 40},${40 + rnd() * 20},${0.3 + rnd() * 0.5})`;
    ctx.beginPath();
    ctx.ellipse(x, y, 1 + rnd() * 3, 1 + rnd() * 2, rnd() * 3, 0, Math.PI * 2);
    ctx.fill();
  }

  const map = toTex(c);
  // roughness: wheel tracks are smoother (darker roughness), rest rough
  const rc = makeCanvas(S, S);
  const rctx = rc.getContext('2d')!;
  rctx.fillStyle = '#c8c8c8';
  rctx.fillRect(0, 0, S, S);
  for (const tx of tracks) {
    const g = rctx.createLinearGradient(tx * S - 130, 0, tx * S + 130, 0);
    g.addColorStop(0, 'rgba(110,110,110,0)');
    g.addColorStop(0.5, 'rgba(110,110,110,0.75)');
    g.addColorStop(1, 'rgba(110,110,110,0)');
    rctx.fillStyle = g;
    rctx.fillRect(tx * S - 130, 0, 260, S);
  }
  const rimg = rctx.getImageData(0, 0, S, S);
  for (let i = 0; i < rimg.data.length; i += 4) {
    const n = (rnd() - 0.5) * 40;
    rimg.data[i] += n;
    rimg.data[i + 1] += n;
    rimg.data[i + 2] += n;
  }
  rctx.putImageData(rimg, 0, 0);
  const roughness = toTex(rc, true, false);

  // bump from grain
  const bc = makeCanvas(512, 512);
  const bctx = bc.getContext('2d')!;
  const bimg = bctx.createImageData(512, 512);
  for (let i = 0; i < bimg.data.length; i += 4) {
    const v = 110 + (rnd() - 0.5) * 120;
    bimg.data[i] = bimg.data[i + 1] = bimg.data[i + 2] = v;
    bimg.data[i + 3] = 255;
  }
  bctx.putImageData(bimg, 0, 0);
  const bump = toTex(bc, true, false);
  return { map, roughness, bump };
}

// ---------------------------------------------------------------------------
// CONCRETE GUTTER with periodic steel grates
// ---------------------------------------------------------------------------
export function makeConcrete() {
  const W = 256;
  const H = 1024;
  const c = makeCanvas(W, H);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(7);
  ctx.fillStyle = '#8d8b84';
  ctx.fillRect(0, 0, W, H);
  const img = ctx.getImageData(0, 0, W, H);
  for (let i = 0; i < img.data.length; i += 4) {
    const n = (rnd() - 0.5) * 50;
    img.data[i] += n;
    img.data[i + 1] += n;
    img.data[i + 2] += n - 4;
  }
  ctx.putImageData(img, 0, 0);
  // moss / grime along inner edge
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, 'rgba(50,60,30,0.45)');
  g.addColorStop(0.35, 'rgba(50,60,30,0)');
  g.addColorStop(1, 'rgba(40,40,35,0.25)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  // segment joints
  ctx.fillStyle = 'rgba(40,40,40,0.7)';
  for (let y = 0; y < H; y += 256) ctx.fillRect(0, y, W, 3);
  // grate every other segment
  for (let y = 128; y < H; y += 512) {
    ctx.fillStyle = '#2a2a2a';
    ctx.fillRect(28, y - 60, W - 56, 120);
    ctx.fillStyle = '#6a6a66';
    for (let k = 0; k < 7; k++) ctx.fillRect(28, y - 54 + k * 17, W - 56, 5);
  }
  // channel darkening (U shape shading)
  const g2 = ctx.createLinearGradient(0, 0, W, 0);
  g2.addColorStop(0, 'rgba(0,0,0,0.0)');
  g2.addColorStop(0.3, 'rgba(0,0,0,0.35)');
  g2.addColorStop(0.7, 'rgba(0,0,0,0.35)');
  g2.addColorStop(1, 'rgba(0,0,0,0.0)');
  ctx.fillStyle = g2;
  ctx.fillRect(0, 0, W, H);
  return toTex(c);
}

// ---------------------------------------------------------------------------
// FOREST FLOOR — dark humus, dead cedar needles, leaves, moss
// ---------------------------------------------------------------------------
export function makeForestFloor() {
  const S = 1024;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(99);
  ctx.fillStyle = '#4a4232';
  ctx.fillRect(0, 0, S, S);
  const img = ctx.getImageData(0, 0, S, S);
  for (let i = 0; i < img.data.length; i += 4) {
    const n = (rnd() - 0.5) * 40;
    img.data[i] += n;
    img.data[i + 1] += n;
    img.data[i + 2] += n;
  }
  ctx.putImageData(img, 0, 0);
  // moss patches
  for (let i = 0; i < 140; i++) {
    const x = rnd() * S;
    const y = rnd() * S;
    const r = 30 + rnd() * 140;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(${70 + rnd() * 30},${105 + rnd() * 40},${40},0.6)`);
    g.addColorStop(1, 'rgba(60,90,30,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }
  // dead needles & leaves
  for (let i = 0; i < 6000; i++) {
    const x = rnd() * S;
    const y = rnd() * S;
    const t = rnd();
    if (t < 0.9) {
      ctx.strokeStyle = `rgba(${105 + rnd() * 50},${82 + rnd() * 35},${40 + rnd() * 20},${0.35 + rnd() * 0.35})`;
      ctx.lineWidth = 1;
      const a = rnd() * Math.PI;
      const l = 4 + rnd() * 9;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
      ctx.stroke();
    } else {
      ctx.fillStyle = `rgba(${95 + rnd() * 40},${78 + rnd() * 30},${48 + rnd() * 20},${0.35 + rnd() * 0.3})`;
      ctx.beginPath();
      ctx.ellipse(x, y, 2 + rnd() * 5, 1.5 + rnd() * 3, rnd() * 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  // small stones
  for (let i = 0; i < 300; i++) {
    const v = 90 + rnd() * 70;
    ctx.fillStyle = `rgba(${v},${v},${v - 10},0.9)`;
    ctx.beginPath();
    ctx.ellipse(rnd() * S, rnd() * S, 1 + rnd() * 3, 1 + rnd() * 2, rnd() * 3, 0, Math.PI * 2);
    ctx.fill();
  }
  return toTex(c);
}

// ---------------------------------------------------------------------------
// BARK — cedar: reddish-brown, vertical fibrous strips
// ---------------------------------------------------------------------------
export function makeBark() {
  const W = 256;
  const H = 512;
  const c = makeCanvas(W, H);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(3);
  ctx.fillStyle = '#5a4030';
  ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 600; i++) {
    const x = rnd() * W;
    const w = 2 + rnd() * 8;
    const v = rnd();
    ctx.fillStyle = v > 0.5 ? `rgba(${100 + rnd() * 50},${70 + rnd() * 30},${50},0.5)` : `rgba(30,20,12,${0.3 + rnd() * 0.4})`;
    const y = rnd() * H;
    const h = 40 + rnd() * 200;
    ctx.fillRect(x, y, w, h);
    ctx.fillRect(x, y - H, w, h); // wrap
  }
  // moss/lichen
  for (let i = 0; i < 80; i++) {
    const x = rnd() * W;
    const y = rnd() * H;
    const r = 5 + rnd() * 18;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, 'rgba(90,120,60,0.5)');
    g.addColorStop(1, 'rgba(90,120,60,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }
  return toTex(c);
}

// ---------------------------------------------------------------------------
// FOLIAGE CARDS — alpha textures
// ---------------------------------------------------------------------------
function drawNeedleCluster(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  rnd: () => number,
  baseHue: number,
) {
  // a spray of needles radiating outward & downward (sugi look)
  const n = 60;
  for (let i = 0; i < n; i++) {
    const a = rnd() * Math.PI * 2;
    const len = r * (0.4 + rnd() * 0.6);
    const l = 28 + rnd() * 22;
    const s = 45 + rnd() * 30;
    ctx.strokeStyle = `hsla(${baseHue + (rnd() - 0.5) * 18},${s}%,${l}%,${0.75 + rnd() * 0.25})`;
    ctx.lineWidth = 1.5 + rnd() * 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    const ex = cx + Math.cos(a) * len;
    const ey = cy + Math.sin(a) * len + len * 0.35; // droop
    ctx.quadraticCurveTo(cx + Math.cos(a) * len * 0.5, cy + Math.sin(a) * len * 0.5, ex, ey);
    ctx.stroke();
  }
}

export function makeCedarCard() {
  const S = 512;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(21);
  ctx.clearRect(0, 0, S, S);
  // conical silhouette: wider at bottom. Many clusters.
  const clusters = 110;
  for (let i = 0; i < clusters; i++) {
    const y = 40 + rnd() * (S - 80);
    const halfW = (y / S) * S * 0.44 + 20;
    const x = S / 2 + (rnd() * 2 - 1) * halfW;
    // interior clusters are darker (self shadow)
    const edge = Math.abs(x - S / 2) / halfW;
    const hue = 115 + rnd() * 20;
    drawNeedleCluster(ctx, x, y, 22 + rnd() * 22, rnd, hue);
    if (edge < 0.5) {
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = 'rgba(10,25,10,1)';
      ctx.beginPath();
      ctx.arc(x, y, 10 + rnd() * 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }
  // highlight tips
  for (let i = 0; i < 400; i++) {
    const y = 40 + rnd() * (S - 80);
    const halfW = (y / S) * S * 0.44 + 20;
    const x = S / 2 + (rnd() * 2 - 1) * halfW;
    ctx.fillStyle = `hsla(${95 + rnd() * 25},60%,${55 + rnd() * 20}%,0.6)`;
    ctx.fillRect(x, y, 2, 4);
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

// ---------------------------------------------------------------------------
// FOLIAGE TUFTS — soft, round foliage masses with baked shading (lit from the
// upper-left, dark underside). Used as camera-facing billboards.
// ---------------------------------------------------------------------------
function makeTuft(opts: {
  seed: number;
  hue: [number, number];
  sat: [number, number];
  lightTop: number;
  lightBottom: number;
  leaf: 'needle' | 'oval';
  clusters: number;
  holes: number;
}) {
  const S = 512;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(opts.seed);
  ctx.clearRect(0, 0, S, S);
  const cx = S / 2;
  const cy = S / 2 + 10;
  const rx = 228;
  const ry = 205;
  // a few sub-lobes make the silhouette irregular instead of a perfect ellipse
  const lobes: [number, number, number][] = [];
  for (let i = 0; i < 5; i++) {
    const a = rnd() * Math.PI * 2;
    lobes.push([cx + Math.cos(a) * rx * 0.45, cy + Math.sin(a) * ry * 0.4, 0.55 + rnd() * 0.3]);
  }
  const inside = (x: number, y: number) => {
    let best = 2;
    const d0 = Math.hypot((x - cx) / rx, (y - cy) / ry);
    best = Math.min(best, d0 / 0.78);
    for (const [lx, ly, lr] of lobes) {
      const d = Math.hypot((x - lx) / (rx * lr), (y - ly) / (ry * lr));
      best = Math.min(best, d);
    }
    return best; // <1 inside, ~1 edge
  };
  for (let i = 0; i < opts.clusters; i++) {
    const x = rnd() * S;
    const y = rnd() * S;
    const e = inside(x, y);
    if (e > 1) continue;
    // feather the edge, punch some holes for light to come through
    if (rnd() < (e - 0.6) * 1.6) continue;
    if (opts.holes > 0 && Math.sin(x * 0.045 + 3) * Math.cos(y * 0.05) > 1 - opts.holes && rnd() > 0.25) continue;
    // baked shading: lit from upper-left, darker toward bottom-right & center-bottom
    const vert = (y - (cy - ry)) / (2 * ry); // 0 top .. 1 bottom
    const diag = ((x - (cx - rx)) / (2 * rx)) * 0.35;
    const shade = Math.max(0, Math.min(1, vert * 0.8 + diag + (rnd() - 0.5) * 0.25));
    const l = opts.lightTop + (opts.lightBottom - opts.lightTop) * shade;
    const h = opts.hue[0] + rnd() * (opts.hue[1] - opts.hue[0]);
    const s = opts.sat[0] + rnd() * (opts.sat[1] - opts.sat[0]);
    if (opts.leaf === 'needle') {
      const n = 10 + Math.floor(rnd() * 8);
      for (let j = 0; j < n; j++) {
        const a = rnd() * Math.PI * 2;
        const len = 7 + rnd() * 11;
        ctx.strokeStyle = `hsla(${h + (rnd() - 0.5) * 8},${s}%,${l + (rnd() - 0.5) * 8}%,${0.85 + rnd() * 0.15})`;
        ctx.lineWidth = 1.3 + rnd() * 1.4;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len + len * 0.4);
        ctx.stroke();
      }
    } else {
      const n = 4 + Math.floor(rnd() * 4);
      for (let j = 0; j < n; j++) {
        ctx.fillStyle = `hsla(${h + (rnd() - 0.5) * 10},${s}%,${l + (rnd() - 0.5) * 10}%,${0.9 + rnd() * 0.1})`;
        ctx.save();
        ctx.translate(x + (rnd() - 0.5) * 16, y + (rnd() - 0.5) * 16);
        ctx.rotate(rnd() * Math.PI);
        ctx.beginPath();
        ctx.ellipse(0, 0, 4 + rnd() * 5, 2.5 + rnd() * 3, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
  }
  // sun-kissed highlights on the upper-left rim
  for (let i = 0; i < 260; i++) {
    const a = -Math.PI * 0.9 + rnd() * Math.PI * 0.8;
    const r = 0.55 + rnd() * 0.3;
    const x = cx + Math.cos(a) * rx * r;
    const y = cy + Math.sin(a) * ry * r;
    if (inside(x, y) > 0.95) continue;
    ctx.fillStyle = `hsla(${opts.hue[0] - 10 + rnd() * 20},70%,${opts.lightTop + 14}%,0.55)`;
    ctx.fillRect(x, y, 2 + rnd() * 2, 2 + rnd() * 3);
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

// ---------------------------------------------------------------------------
// LEAF SPRAY — a few twigs fanning out from the bottom-centre with leaves
// attached in pairs; airy, irregular silhouette with sky showing through.
// ---------------------------------------------------------------------------
export function makeLeafSpray(seed: number) {
  const S = 512;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(seed);
  ctx.clearRect(0, 0, S, S);
  const ox = S / 2;
  const oy = S * 0.62;
  const leaf = (x: number, y: number, ang: number, size: number, backlit: boolean) => {
    const vert = 1 - y / S; // 1 top .. 0 bottom
    let l = 36 + vert * 24 + (rnd() - 0.5) * 12;
    let h = 80 + rnd() * 24;
    let s = 48 + rnd() * 18;
    if (backlit) {
      l += 14;
      h -= 6;
      s += 10;
    }
    if (rnd() < 0.18) l -= 12; // shaded leaves on the underside
    ctx.fillStyle = `hsla(${h},${s}%,${l}%,${0.92 + rnd() * 0.08})`;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(ang);
    ctx.beginPath();
    // pointed leaf
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(size * 0.5, -size * 0.42, size, 0);
    ctx.quadraticCurveTo(size * 0.5, size * 0.42, 0, 0);
    ctx.fill();
    // midrib
    ctx.strokeStyle = `hsla(${h},${s}%,${l - 12}%,0.5)`;
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(size, 0);
    ctx.stroke();
    ctx.restore();
  };
  const twig = (x0: number, y0: number, ang: number, len: number, w: number, depth: number) => {
    const bend = (rnd() - 0.5) * 0.9;
    const cx = x0 + Math.cos(ang + bend * 0.5) * len * 0.5;
    const cy = y0 + Math.sin(ang + bend * 0.5) * len * 0.5;
    const x1 = x0 + Math.cos(ang + bend) * len;
    const y1 = y0 + Math.sin(ang + bend) * len;
    ctx.strokeStyle = `rgba(${60 + rnd() * 20},${45 + rnd() * 15},${30},0.95)`;
    ctx.lineWidth = w;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.stroke();
    // leaves along the outer part of this twig
    const steps = Math.floor(len / 11);
    for (let i = Math.floor(steps * (depth === 0 ? 0.45 : 0.15)); i < steps; i++) {
      const f = i / steps;
      const px = (1 - f) * (1 - f) * x0 + 2 * (1 - f) * f * cx + f * f * x1;
      const py = (1 - f) * (1 - f) * y0 + 2 * (1 - f) * f * cy + f * f * y1;
      const tang = Math.atan2(py - y0, px - x0);
      if (rnd() < 0.25) continue; // gaps
      const size = 15 + rnd() * 12;
      leaf(px, py, tang + 0.9 + (rnd() - 0.5) * 0.6, size, rnd() < 0.3);
      if (rnd() < 0.8) leaf(px, py, tang - 0.9 + (rnd() - 0.5) * 0.6, size, rnd() < 0.3);
    }
    if (depth < 2) {
      const n = 2 + Math.floor(rnd() * 2);
      for (let i = 0; i < n; i++) {
        const f = 0.35 + rnd() * 0.6;
        const px = (1 - f) * (1 - f) * x0 + 2 * (1 - f) * f * cx + f * f * x1;
        const py = (1 - f) * (1 - f) * y0 + 2 * (1 - f) * f * cy + f * f * y1;
        twig(px, py, ang + bend * f + (rnd() < 0.5 ? 1 : -1) * (0.5 + rnd() * 0.5), len * (0.45 + rnd() * 0.25), w * 0.6, depth + 1);
      }
    }
  };
  const main = 4 + Math.floor(rnd() * 2);
  for (let i = 0; i < main; i++) {
    const ang = -Math.PI / 2 + (i / (main - 1) - 0.5) * 2.4 + (rnd() - 0.5) * 0.3;
    twig(ox + (rnd() - 0.5) * 30, oy + (rnd() - 0.5) * 20, ang, 150 + rnd() * 70, 3.2, 0);
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

// ---------------------------------------------------------------------------
// CEDAR SPRAY — a hanging feathery needle cluster, anchored at the top centre.
// ---------------------------------------------------------------------------
export function makeCedarSpray(seed: number) {
  const S = 512;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(seed);
  ctx.clearRect(0, 0, S, S);
  const needles = (x: number, y: number, dir: number, n: number, light: number) => {
    for (let i = 0; i < n; i++) {
      const a = dir + (rnd() - 0.5) * 1.6;
      const len = 7 + rnd() * 12;
      const l = light + (rnd() - 0.5) * 14;
      ctx.strokeStyle = `hsla(${112 + rnd() * 22},${32 + rnd() * 18}%,${l}%,${0.85 + rnd() * 0.15})`;
      ctx.lineWidth = 1.2 + rnd() * 1.3;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len + len * 0.35);
      ctx.stroke();
    }
  };
  const stem = (x0: number, y0: number, ang: number, len: number, w: number, depth: number) => {
    const x1 = x0 + Math.cos(ang) * len;
    const y1 = y0 + Math.sin(ang) * len;
    ctx.strokeStyle = 'rgba(70,52,36,0.9)';
    ctx.lineWidth = w;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
    const steps = Math.floor(len / 9);
    for (let i = 1; i <= steps; i++) {
      const f = i / steps;
      const px = x0 + (x1 - x0) * f;
      const py = y0 + (y1 - y0) * f;
      const vert = py / S;
      const light = 26 + (1 - vert) * 8 + f * 16; // tips brighter
      needles(px, py, ang + 1.0, 5, light);
      needles(px, py, ang - 1.0, 5, light);
      if (depth < 1 && i % 2 === 0 && rnd() < 0.8) {
        stem(px, py, ang + (rnd() < 0.5 ? 1 : -1) * (0.6 + rnd() * 0.5), len * (0.3 + rnd() * 0.3), w * 0.6, depth + 1);
      }
    }
  };
  // 2–3 hanging stems from the top anchor
  const n = 2 + Math.floor(rnd() * 2);
  for (let i = 0; i < n; i++) {
    const ang = Math.PI / 2 + (i / Math.max(1, n - 1) - 0.5) * 1.1 + (rnd() - 0.5) * 0.3;
    stem(S / 2 + (rnd() - 0.5) * 30, 14, ang, 300 + rnd() * 170, 3, 0);
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

export const makeCedarTuft = () =>
  makeTuft({ seed: 311, hue: [108, 132], sat: [30, 48], lightTop: 48, lightBottom: 20, leaf: 'needle', clusters: 3400, holes: 0.1 });
export const makeBroadTuft = () =>
  makeTuft({ seed: 512, hue: [78, 104], sat: [48, 66], lightTop: 64, lightBottom: 30, leaf: 'oval', clusters: 2800, holes: 0.18 });

// A single drooping sugi branch, root at the left edge, tip at the right.
export function makeCedarBranchCard() {
  const W = 512;
  const H = 256;
  const c = makeCanvas(W, H);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(1234);
  ctx.clearRect(0, 0, W, H);
  const rootX = 8;
  const rootY = H * 0.32;
  // main branch curve: out and gently drooping
  const tipX = W - 20;
  const tipY = H * 0.62;
  const cpX = W * 0.55;
  const cpY = H * 0.22;
  const branchAt = (f: number) => {
    const x = (1 - f) * (1 - f) * rootX + 2 * (1 - f) * f * cpX + f * f * tipX;
    const y = (1 - f) * (1 - f) * rootY + 2 * (1 - f) * f * cpY + f * f * tipY;
    return [x, y] as const;
  };
  // woody branch
  ctx.strokeStyle = '#4a3a2c';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(rootX, rootY);
  ctx.quadraticCurveTo(cpX, cpY, tipX, tipY);
  ctx.stroke();
  // side twigs with hanging needle sprays
  const twigs = 26;
  for (let i = 0; i < twigs; i++) {
    const f = 0.12 + (i / twigs) * 0.86 + (rnd() - 0.5) * 0.03;
    const [bx, by] = branchAt(f);
    const side = i % 2 === 0 ? 1 : -1;
    const twigLen = 30 + rnd() * 55 + f * 25;
    // twigs hang downward (canvas y grows down) and drift toward the tip
    const ex = bx + side * twigLen * (0.2 + rnd() * 0.25) + twigLen * 0.25;
    const ey = by + twigLen * (0.55 + rnd() * 0.45) * (side > 0 ? 1 : 0.35);
    ctx.strokeStyle = '#5a4634';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(bx, by);
    ctx.quadraticCurveTo((bx + ex) / 2 + 8, (by + ey) / 2 - 10, ex, ey);
    ctx.stroke();
    // needle sprays along twig
    const sprays = 7 + Math.floor(rnd() * 5);
    for (let k = 0; k < sprays; k++) {
      const g = k / sprays;
      const sx = bx + (ex - bx) * g + (rnd() - 0.5) * 10;
      const sy = by + (ey - by) * g + (rnd() - 0.5) * 10;
      const n = 14 + Math.floor(rnd() * 10);
      const rr = 10 + rnd() * 12 + g * 6;
      for (let j = 0; j < n; j++) {
        const a = rnd() * Math.PI * 2;
        const len = rr * (0.4 + rnd() * 0.6);
        const tipLight = rnd();
        const l = 24 + tipLight * 26 + g * 6;
        const s = 42 + rnd() * 25;
        ctx.strokeStyle = `hsla(${112 + rnd() * 22},${s}%,${l}%,${0.8 + rnd() * 0.2})`;
        ctx.lineWidth = 1.2 + rnd() * 1.6;
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(sx + Math.cos(a) * len, sy + Math.sin(a) * len + len * 0.45);
        ctx.stroke();
      }
    }
  }
  // bright sun-kissed tips near the branch end
  for (let i = 0; i < 160; i++) {
    const f = 0.6 + rnd() * 0.4;
    const [bx, by] = branchAt(f);
    ctx.fillStyle = `hsla(${92 + rnd() * 25},65%,${62 + rnd() * 18}%,0.7)`;
    ctx.fillRect(bx + (rnd() - 0.5) * 50, by + rnd() * 60 - 10, 2, 3);
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

export function makeBroadleafCard() {
  const S = 512;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(55);
  ctx.clearRect(0, 0, S, S);
  // round cloud silhouette of many small leaves
  const cx = S / 2;
  const cy = S / 2;
  for (let i = 0; i < 2600; i++) {
    const a = rnd() * Math.PI * 2;
    const rr = Math.sqrt(rnd()) * S * 0.46;
    // skip some so holes appear (dappled light)
    const x = cx + Math.cos(a) * rr;
    const y = cy + Math.sin(a) * rr * 0.9;
    const hole = Math.sin(x * 0.05) * Math.cos(y * 0.045) > 0.55;
    if (hole && rnd() > 0.2) continue;
    const depth = rr / (S * 0.46);
    const l = 30 + rnd() * 25 + (1 - depth) * -5 + (y < cy ? 12 : 0);
    ctx.fillStyle = `hsla(${88 + rnd() * 30},${50 + rnd() * 25}%,${l}%,${0.8 + rnd() * 0.2})`;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rnd() * Math.PI);
    ctx.beginPath();
    ctx.ellipse(0, 0, 4 + rnd() * 7, 2.5 + rnd() * 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

export function makeUndergrowthCard() {
  const S = 256;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(77);
  ctx.clearRect(0, 0, S, S);
  // fern-ish fronds from the bottom center
  for (let i = 0; i < 14; i++) {
    const a = -Math.PI / 2 + (rnd() - 0.5) * 2.4;
    const len = 90 + rnd() * 110;
    const hue = 95 + rnd() * 30;
    const light = 32 + rnd() * 22;
    ctx.strokeStyle = `hsl(${hue},55%,${light}%)`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(S / 2, S);
    const ex = S / 2 + Math.cos(a) * len;
    const ey = S + Math.sin(a) * len;
    ctx.quadraticCurveTo(S / 2 + Math.cos(a) * len * 0.5, S + Math.sin(a) * len * 0.6, ex, ey);
    ctx.stroke();
    // leaflets
    for (let k = 0; k < 16; k++) {
      const f = k / 16;
      const px = S / 2 + Math.cos(a) * len * f;
      const py = S + Math.sin(a) * len * f + (1 - f) * 0 ;
      const lw = (1 - f) * 18 + 4;
      ctx.fillStyle = `hsla(${hue + (rnd() - 0.5) * 10},60%,${light + 5}%,0.9)`;
      ctx.beginPath();
      ctx.ellipse(px, py, lw, lw * 0.35, a + Math.PI / 2 + 0.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(px, py, lw, lw * 0.35, a + Math.PI / 2 - 0.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

// ---------------------------------------------------------------------------
// SPRITES
// ---------------------------------------------------------------------------
export function makeSmokeSprite() {
  const S = 128;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(5);
  const g = ctx.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,255,255,0.55)');
  g.addColorStop(0.45, 'rgba(255,255,255,0.28)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  // wispy blobs
  for (let i = 0; i < 18; i++) {
    const x = S / 2 + (rnd() - 0.5) * 60;
    const y = S / 2 + (rnd() - 0.5) * 60;
    const r = 12 + rnd() * 25;
    const gg = ctx.createRadialGradient(x, y, 0, x, y, r);
    gg.addColorStop(0, 'rgba(255,255,255,0.25)');
    gg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gg;
    ctx.fillRect(0, 0, S, S);
  }
  const t = toTex(c, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

export function makeShaftGradient() {
  const W = 64;
  const H = 256;
  const c = makeCanvas(W, H);
  const ctx = c.getContext('2d')!;
  const gv = ctx.createLinearGradient(0, 0, 0, H);
  gv.addColorStop(0, 'rgba(255,255,255,0)');
  gv.addColorStop(0.25, 'rgba(255,255,255,1)');
  gv.addColorStop(0.75, 'rgba(255,255,255,0.8)');
  gv.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = gv;
  ctx.fillRect(0, 0, W, H);
  const gh = ctx.createLinearGradient(0, 0, W, 0);
  gh.addColorStop(0, 'rgba(0,0,0,1)');
  gh.addColorStop(0.5, 'rgba(0,0,0,0)');
  gh.addColorStop(1, 'rgba(0,0,0,1)');
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fillStyle = gh;
  ctx.fillRect(0, 0, W, H);
  const t = toTex(c, false, false);
  t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

export function makeCurveSign() {
  const W = 256;
  const H = 384;
  const c = makeCanvas(W, H);
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#e8e4d8';
  ctx.fillRect(0, 0, W, H);
  // rust & grime
  const rnd = mulberry32(13);
  for (let i = 0; i < 60; i++) {
    const x = rnd() * W;
    const y = rnd() * H;
    const r = 5 + rnd() * 30;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, `rgba(${120 + rnd() * 60},${60 + rnd() * 30},20,${0.25 + rnd() * 0.4})`);
    g.addColorStop(1, 'rgba(120,70,20,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }
  // red curving arrow
  ctx.strokeStyle = '#c8281e';
  ctx.lineWidth = 26;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(70, 190);
  ctx.quadraticCurveTo(70, 70, 170, 70);
  ctx.stroke();
  ctx.fillStyle = '#c8281e';
  ctx.beginPath();
  ctx.moveTo(150, 30);
  ctx.lineTo(215, 70);
  ctx.lineTo(150, 110);
  ctx.closePath();
  ctx.fill();
  // text 右カーブ
  ctx.fillStyle = '#1a1a1a';
  ctx.font = 'bold 72px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('右カーブ', W / 2, 290);
  ctx.font = 'bold 34px sans-serif';
  ctx.fillStyle = '#c8281e';
  ctx.fillText('スピード落せ', W / 2, 345);
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 6;
  ctx.strokeRect(6, 6, W - 12, H - 12);
  return toTex(c, false);
}

export function makeSkidTexture() {
  const S = 128;
  const c = makeCanvas(S, S);
  const ctx = c.getContext('2d')!;
  const rnd = mulberry32(31);
  ctx.clearRect(0, 0, S, S);
  const g = ctx.createLinearGradient(0, 0, S, 0);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(0.2, 'rgba(0,0,0,0.9)');
  g.addColorStop(0.8, 'rgba(0,0,0,0.9)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, S, S);
  ctx.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 400; i++) {
    ctx.fillStyle = `rgba(0,0,0,${rnd() * 0.5})`;
    ctx.fillRect(rnd() * S, rnd() * S, 2, 6 + rnd() * 10);
  }
  const t = toTex(c, true, false);
  return t;
}
