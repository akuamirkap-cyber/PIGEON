// Shared lightweight singletons used across components (no React re-renders).

export interface SmokeRequest {
  x: number;
  y: number;
  z: number;
  vx: number;
  vz: number;
  intensity: number; // 0..1
}

export const smokeQueue: SmokeRequest[] = [];
export function emitSmoke(x: number, y: number, z: number, vx: number, vz: number, intensity: number) {
  if (smokeQueue.length < 400) smokeQueue.push({ x, y, z, vx, vz, intensity });
}

export interface SkidRequest {
  // quad corners (world space, already lifted slightly above road)
  ax: number; ay: number; az: number;
  bx: number; by: number; bz: number;
  cx: number; cy: number; cz: number;
  dx: number; dy: number; dz: number;
  alpha: number;
}
export const skidQueue: SkidRequest[] = [];

export const input = {
  forward: 0,
  back: 0,
  left: 0,
  right: 0,
  handbrake: 0,
  reset: false,
  camToggle: false,
};

export const playerState = {
  x: 0,
  y: 0,
  z: 0,
  heading: 0,
  speed: 0,
  drifting: false,
  slip: 0,
  cameraMode: 0, // 0 chase, 1 trackside cinematic, 2 hood
};
