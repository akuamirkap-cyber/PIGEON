import { useMemo } from 'react';
import * as THREE from 'three';
import { curve, ROAD_WIDTH, GUTTER_WIDTH, TRACK_LENGTH, EDGE, CORRIDOR, terrainHeight } from '../world/track';
import { makeAsphalt, makeConcrete, makeForestFloor } from '../world/textures';

const SEGMENTS = 1600;
const up = new THREE.Vector3(0, 1, 0);

function buildStrip(offsetA: number, offsetB: number, uRepeatPerMeter: number, yLift: number, camber = 0) {
  const pos: number[] = [];
  const uv: number[] = [];
  const nrm: number[] = [];
  const idx: number[] = [];
  const p = new THREE.Vector3();
  const t = new THREE.Vector3();
  const right = new THREE.Vector3();
  for (let i = 0; i <= SEGMENTS; i++) {
    const u = (i % SEGMENTS) / SEGMENTS;
    curve.getPointAt(u, p);
    curve.getTangentAt(u, t);
    t.y = 0;
    t.normalize();
    right.crossVectors(t, up).normalize(); // right of travel
    const v = (i / SEGMENTS) * TRACK_LENGTH * uRepeatPerMeter;
    pos.push(p.x + right.x * offsetA, p.y + yLift + Math.abs(offsetA) * camber, p.z + right.z * offsetA);
    uv.push(0, v);
    nrm.push(0, 1, 0);
    pos.push(p.x + right.x * offsetB, p.y + yLift + Math.abs(offsetB) * camber, p.z + right.z * offsetB);
    uv.push(1, v);
    nrm.push(0, 1, 0);
    if (i < SEGMENTS) {
      const a = i * 2;
      idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  g.setIndex(idx);
  return g;
}

// Curve-following embankment / shoulder mesh with several lateral stations so the
// steep cut bank is represented exactly (no grid interpolation artefacts).
function buildCorridor(stations: number[]) {
  const SEG = 1100;
  const S = stations.length;
  const pos: number[] = [];
  const uv: number[] = [];
  const col: number[] = [];
  const idx: number[] = [];
  const p = new THREE.Vector3();
  const t = new THREE.Vector3();
  const right = new THREE.Vector3();
  for (let i = 0; i <= SEG; i++) {
    const u = (i % SEG) / SEG;
    curve.getPointAt(u, p);
    curve.getTangentAt(u, t);
    t.y = 0;
    t.normalize();
    right.crossVectors(t, up).normalize();
    const along = (i / SEG) * TRACK_LENGTH;
    for (let s = 0; s < S; s++) {
      const off = stations[s];
      const x = p.x + right.x * off;
      const z = p.z + right.z * off;
      const y = terrainHeight(x, z);
      pos.push(x, y, z);
      uv.push(off / 9, along / 9);
      col.push(1, 1, 1);
    }
    if (i < SEG) {
      for (let s = 0; s < S - 1; s++) {
        const a = i * S + s;
        const b = a + S;
        idx.push(a, a + 1, b, a + 1, b + 1, b);
      }
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  // colour: steep faces = exposed brown soil & roots, flat = mossy humus
  const nrm = g.attributes.normal as THREE.BufferAttribute;
  const c = g.attributes.color as THREE.BufferAttribute;
  const posA = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < nrm.count; i++) {
    const ny = nrm.getY(i);
    const steep = 1 - THREE.MathUtils.smoothstep(ny, 0.5, 0.92);
    const x = posA.getX(i);
    const z = posA.getZ(i);
    const seed = Math.sin(x * 12.9898 + z * 78.233) * 43758.5453;
    const r = seed - Math.floor(seed);
    const mossy = 0.75 + r * 0.25;
    c.setXYZ(
      i,
      THREE.MathUtils.lerp(0.7 * mossy, 0.95, steep),
      THREE.MathUtils.lerp(0.95 * mossy, 0.8, steep),
      THREE.MathUtils.lerp(0.6 * mossy, 0.6, steep),
    );
  }
  return g;
}

export default function Road() {
  const data = useMemo(() => {
    const half = ROAD_WIDTH / 2;
    const asphaltGeo = buildStrip(-half, half, 1 / 7, 0.0, -0.012);
    const gutterL = buildStrip(-half - GUTTER_WIDTH, -half, 1 / 4, 0.01);
    const gutterR = buildStrip(half, half + GUTTER_WIDTH, 1 / 4, 0.01);
    const left = buildCorridor([-CORRIDOR, -11, -8.5, -6.5, -5.4, -4.7, -(EDGE + 0.3), -(EDGE - 0.08)]);
    const right = buildCorridor([EDGE - 0.08, EDGE + 0.3, EDGE + 0.9, EDGE + 1.6, EDGE + 2.5, EDGE + 3.6, EDGE + 5, 8.5, 11, CORRIDOR]);
    const asphalt = makeAsphalt();
    const concrete = makeConcrete();
    const floor = makeForestFloor();
    return { asphaltGeo, gutterL, gutterR, left, right, asphalt, concrete, floor };
  }, []);

  return (
    <group>
      <mesh geometry={data.asphaltGeo} receiveShadow>
        <meshStandardMaterial
          map={data.asphalt.map}
          roughnessMap={data.asphalt.roughness}
          bumpMap={data.asphalt.bump}
          bumpScale={0.015}
          roughness={1}
          metalness={0.0}
          color="#dcdad6"
        />
      </mesh>
      <mesh geometry={data.gutterL} receiveShadow>
        <meshStandardMaterial map={data.concrete} roughness={0.95} color="#d6d1c7" />
      </mesh>
      <mesh geometry={data.gutterR} receiveShadow>
        <meshStandardMaterial map={data.concrete} roughness={0.95} color="#d6d1c7" />
      </mesh>
      <mesh geometry={data.left} receiveShadow>
        <meshStandardMaterial map={data.floor} vertexColors roughness={1} color="#cfc6b4" />
      </mesh>
      <mesh geometry={data.right} receiveShadow>
        <meshStandardMaterial map={data.floor} vertexColors roughness={1} color="#cfc6b4" />
      </mesh>
    </group>
  );
}
