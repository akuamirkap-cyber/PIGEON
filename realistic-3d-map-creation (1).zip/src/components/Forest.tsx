import { useMemo, useEffect } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { mulberry32 } from '../world/noise';
import { queryRoad, terrainHeight, ROAD_WIDTH, GUTTER_WIDTH } from '../world/track';
import { TERRAIN_SIZE, TERRAIN_CENTER } from './Terrain';
import { makeBark, makeLeafSpray, makeCedarSpray, makeUndergrowthCard } from '../world/textures';

const _p = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _c = new THREE.Color();
const _e = new THREE.Euler();
const _m = new THREE.Matrix4();
const IDENT = new THREE.Quaternion();
const UP = new THREE.Vector3(0, 1, 0);

interface Placed {
  x: number;
  y: number;
  z: number;
  dist: number;
  signed: number;
}

function scatter(rnd: () => number, count: number, minDist: number, maxDist: number, nearBias: number): Placed[] {
  const out: Placed[] = [];
  const half = TERRAIN_SIZE / 2 - 10;
  let tries = 0;
  while (out.length < count && tries < count * 40) {
    tries++;
    const x = TERRAIN_CENTER.x + (rnd() * 2 - 1) * half;
    const z = TERRAIN_CENTER.z + (rnd() * 2 - 1) * half;
    const q = queryRoad(x, z);
    if (q.dist < minDist || q.dist > maxDist) continue;
    const keep = 1 - nearBias * THREE.MathUtils.smoothstep(q.dist, 12, maxDist);
    if (rnd() > keep) continue;
    out.push({ x, y: terrainHeight(x, z), z, dist: q.dist, signed: q.signed });
  }
  return out;
}

// ---------------------------------------------------------------------------
// Procedural branch skeletons. Each variant is a merged geometry (instanced per
// tree) plus "anchors": points on the outer branches where foliage attaches.
// ---------------------------------------------------------------------------
interface Anchor {
  p: THREE.Vector3;
  h: number; // 0..1 normalised height within the crown
  tip: boolean;
}
interface Variant {
  geo: THREE.BufferGeometry;
  anchors: Anchor[];
  height: number;
}

function segment(a: THREE.Vector3, b: THREE.Vector3, r0: number, r1: number, sides = 5) {
  const len = a.distanceTo(b);
  const g = new THREE.CylinderGeometry(r1, r0, len, sides, 1, true);
  g.translate(0, len / 2, 0);
  const dir = b.clone().sub(a).normalize();
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(UP, dir));
  g.translate(a.x, a.y, a.z);
  return g;
}

function buildBroadleafVariant(rnd: () => number): Variant {
  const parts: THREE.BufferGeometry[] = [];
  const anchors: Anchor[] = [];
  let top = 0;
  const grow = (from: THREE.Vector3, dir: THREE.Vector3, len: number, r: number, depth: number) => {
    const to = from.clone().addScaledVector(dir, len);
    top = Math.max(top, to.y);
    parts.push(segment(from, to, r, r * (depth === 4 ? 0.4 : 0.62), depth < 2 ? 6 : 4));
    if (depth >= 3) anchors.push({ p: to.clone(), h: 0, tip: depth === 4 });
    if (depth === 4) return;
    const n = depth === 0 ? 3 + Math.floor(rnd() * 2) : 2 + (rnd() < 0.55 ? 1 : 0);
    for (let i = 0; i < n; i++) {
      const axis = new THREE.Vector3(rnd() - 0.5, rnd() - 0.5, rnd() - 0.5).cross(dir).normalize();
      const ang = (0.4 + rnd() * 0.55) * (depth === 0 ? 1.15 : 1);
      const nd = dir.clone().applyAxisAngle(axis, ang);
      nd.y += 0.22 + rnd() * 0.2; // phototropism: reach for the light
      nd.normalize();
      grow(to, nd, len * (0.66 + rnd() * 0.14), r * 0.6, depth + 1);
    }
  };
  const trunkDir = new THREE.Vector3(0, 1, 0).applyAxisAngle(new THREE.Vector3(1, 0, 0), (rnd() - 0.5) * 0.35);
  grow(new THREE.Vector3(0, 0, 0), trunkDir, 3.0 + rnd() * 1.6, 0.2, 0);
  for (const a of anchors) a.h = THREE.MathUtils.clamp(a.p.y / top, 0, 1);
  const geo = mergeGeometries(parts)!;
  geo.computeVertexNormals();
  return { geo, anchors, height: top };
}

function buildCedarVariant(rnd: () => number): Variant {
  // Branch whorls on a 24 m tree (the straight trunk is a separate instanced
  // mesh). Branches are near-horizontal, drooping, with a slight upturned tip.
  const H = 24;
  const parts: THREE.BufferGeometry[] = [];
  const anchors: Anchor[] = [];
  const whorls = 7;
  for (let w = 0; w < whorls; w++) {
    const f = w / (whorls - 1);
    const y = H * (0.34 + f * 0.6) + (rnd() - 0.5) * 1.2;
    const n = 3;
    const base = rnd() * Math.PI * 2;
    for (let i = 0; i < n; i++) {
      const a = base + (i * Math.PI * 2) / n + (rnd() - 0.5) * 0.7;
      const len = (1 - f) * 2.8 + 0.9;
      const dir = new THREE.Vector3(Math.cos(a), -0.12 + rnd() * 0.1, Math.sin(a)).normalize();
      const root = new THREE.Vector3(0, y, 0);
      const mid = root.clone().addScaledVector(dir, len * 0.55);
      const dir2 = dir.clone();
      dir2.y -= 0.3;
      dir2.normalize();
      const tip = mid.clone().addScaledVector(dir2, len * 0.45);
      parts.push(segment(root, mid, 0.07, 0.045, 4));
      parts.push(segment(mid, tip, 0.045, 0.015, 4));
      anchors.push({ p: mid, h: f, tip: false });
      anchors.push({ p: tip, h: f, tip: true });
    }
  }
  anchors.push({ p: new THREE.Vector3(0, H - 0.6, 0), h: 1, tip: true });
  const geo = mergeGeometries(parts)!;
  geo.computeVertexNormals();
  return { geo, anchors, height: H };
}

// ---------------------------------------------------------------------------
// Billboard foliage material (camera-facing quads; light-facing in shadow pass)
// ---------------------------------------------------------------------------
const timeUniform = { value: 0 };

const billboardVertex = `
  vec3 camRight = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
  vec3 camUp = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);
  vec3 iPos = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
  float sway = sin(uTime * 0.9 + iPos.x * 0.35 + iPos.z * 0.21) * 0.03 + sin(uTime * 1.7 + iPos.y * 0.5) * 0.015;
  vec3 transformed = camRight * (position.x + sway * (position.y + 0.5)) + camUp * position.y;
`;

function makeBillboardMaterial(map: THREE.Texture, tint: string, emissive: string, emissiveIntensity: number) {
  const mat = new THREE.MeshStandardMaterial({
    map,
    alphaTest: 0.45,
    side: THREE.DoubleSide,
    roughness: 1,
    metalness: 0,
    color: tint,
    emissive,
    emissiveMap: map,
    emissiveIntensity,
  });
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = timeUniform;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime;')
      .replace(
        '#include <beginnormal_vertex>',
        `vec3 camFwd = vec3(viewMatrix[0][2], viewMatrix[1][2], viewMatrix[2][2]);
         vec3 objectNormal = normalize(vec3(0.0, 1.0, 0.0) + camFwd * 0.7);
         #ifdef USE_TANGENT
         vec3 objectTangent = vec3( tangent.xyz );
         #endif`,
      )
      .replace('#include <begin_vertex>', billboardVertex);
  };
  return mat;
}

function makeBillboardDepth(map: THREE.Texture) {
  const mat = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map, alphaTest: 0.45, side: THREE.DoubleSide });
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = timeUniform;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime;')
      .replace('#include <begin_vertex>', billboardVertex);
  };
  return mat;
}

function makeCardMaterial(map: THREE.Texture, tint: string, emissive: string, emissiveIntensity: number) {
  const mat = new THREE.MeshStandardMaterial({
    map,
    alphaTest: 0.42,
    side: THREE.DoubleSide,
    roughness: 1,
    metalness: 0,
    color: tint,
    emissive,
    emissiveMap: map,
    emissiveIntensity,
  });
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader.replace(
      '#include <beginnormal_vertex>',
      'vec3 objectNormal = vec3(0.0, 1.0, 0.0);\n#ifdef USE_TANGENT\nvec3 objectTangent = vec3( tangent.xyz );\n#endif',
    );
  };
  return mat;
}

interface Inst {
  m: THREE.Matrix4;
  c?: THREE.Color;
}

function Instanced({ geo, mat, items, colors, shadow, depth }: { geo: THREE.BufferGeometry; mat: THREE.Material; items: Inst[]; colors: boolean; shadow: boolean; depth?: THREE.Material }) {
  const mesh = useMemo(() => {
    const m = new THREE.InstancedMesh(geo, mat, Math.max(1, items.length));
    for (let i = 0; i < items.length; i++) {
      m.setMatrixAt(i, items[i].m);
      if (colors && items[i].c) m.setColorAt(i, items[i].c!);
    }
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
    m.frustumCulled = false;
    m.castShadow = shadow;
    m.receiveShadow = true;
    if (depth) m.customDepthMaterial = depth;
    return m;
  }, [geo, mat, items, colors, shadow, depth]);
  useEffect(() => () => mesh.dispose(), [mesh]);
  return <primitive object={mesh} />;
}

export default function Forest() {
  const built = useMemo(() => {
    const rnd = mulberry32(2024);
    const edge = ROAD_WIDTH / 2 + GUTTER_WIDTH;

    const broadVariants = [0, 1, 2, 3, 4].map(() => buildBroadleafVariant(rnd));
    const cedarVariants = [0, 1, 2].map(() => buildCedarVariant(rnd));

    // ------------------------------------------------------------ broadleaf
    const broad = scatter(rnd, 820, edge + 1.0, 60, 0.75);
    const broadSkel: Inst[][] = broadVariants.map(() => []);
    const leafA: Inst[] = [];
    const leafB: Inst[] = [];
    for (const t of broad) {
      const vi = Math.floor(rnd() * broadVariants.length);
      const v = broadVariants[vi];
      const scale = 0.8 + rnd() * 0.75;
      const leanAway = t.signed > 0 ? -1 : 1;
      const q0 = queryRoad(t.x, t.z);
      // lean toward the road (toward light)
      const roadDir = new THREE.Vector3(-q0.tangent.z * leanAway, 0, q0.tangent.x * leanAway);
      const leanAxis = new THREE.Vector3().crossVectors(UP, roadDir).normalize();
      _q.setFromAxisAngle(leanAxis, -(0.08 + rnd() * 0.2));
      _q.multiply(new THREE.Quaternion().setFromAxisAngle(UP, rnd() * Math.PI * 2));
      _p.set(t.x, t.y - 0.2, t.z);
      _s.set(scale, scale, scale);
      _m.compose(_p, _q, _s);
      broadSkel[vi].push({ m: _m.clone() });

      const near = t.dist < 28;
      const keep = near ? 0.75 : 0.45;
      const hue = 0.2 + rnd() * 0.06;
      const vigor = 0.8 + rnd() * 0.4;
      for (const a of v.anchors) {
        if (rnd() > keep) continue;
        const wp = a.p.clone().applyMatrix4(_m);
        wp.y += 0.2 * scale;
        const size = (1.5 + rnd() * 1.3) * scale * (a.tip ? 1 : 0.85);
        _p.copy(wp);
        _s.set(size, size, size);
        // colour: sunlit top, darker interior, occasional backlit yellow-green
        const inner = a.tip ? 0 : 0.18;
        let l = (0.3 + a.h * 0.26 - inner + (rnd() - 0.5) * 0.1) * vigor;
        let h = hue;
        let s = 0.5;
        if (rnd() < 0.22) {
          l += 0.1;
          h -= 0.02;
          s = 0.62;
        }
        _c.setHSL(h, s, THREE.MathUtils.clamp(l, 0.14, 0.66));
        (rnd() < 0.5 ? leafA : leafB).push({ m: new THREE.Matrix4().compose(_p, IDENT, _s), c: _c.clone() });
      }
    }

    // --------------------------------------------------------------- cedars
    const cedars = [...scatter(rnd, 1300, edge + 2.4, 130, 0.45), ...scatter(rnd, 90, edge + 1.3, edge + 2.4, 0)];
    const cedarTrunks: Inst[] = [];
    const cedarSkel: Inst[][] = cedarVariants.map(() => []);
    const cedarSpray: Inst[] = [];
    for (const t of cedars) {
      const vi = Math.floor(rnd() * cedarVariants.length);
      const v = cedarVariants[vi];
      const scale = 0.75 + rnd() * 0.6;
      const H = v.height * scale;
      const lean = (rnd() - 0.5) * 0.03;
      _e.set(lean, rnd() * Math.PI * 2, lean, 'YXZ');
      _q.setFromEuler(_e);
      _p.set(t.x, t.y - 0.4, t.z);
      _s.set(scale, scale, scale);
      _m.compose(_p, _q, _s);
      cedarSkel[vi].push({ m: _m.clone() });
      const rBase = (0.3 + rnd() * 0.2) * scale + H * 0.006;
      _s.set(rBase, H + 0.4, rBase);
      cedarTrunks.push({ m: new THREE.Matrix4().compose(_p, _q, _s) });

      const near = t.dist < 45;
      const shade = 0.75 + rnd() * 0.4;
      for (const a of v.anchors) {
        if (!near && !a.tip) continue;
        if (rnd() < 0.1) continue;
        const wp = a.p.clone().applyMatrix4(_m);
        const size = (a.tip ? 2.0 + rnd() * 1.0 : 1.6 + rnd() * 0.8) * scale;
        _p.copy(wp);
        _p.y += 0.15;
        _s.set(size, size * (1.1 + rnd() * 0.3), size);
        const l = (0.2 + a.h * 0.13 + (a.tip ? 0.05 : 0) + (rnd() - 0.5) * 0.06) * shade;
        _c.setHSL(0.33 + (rnd() - 0.5) * 0.03 - a.h * 0.03, 0.38, THREE.MathUtils.clamp(l, 0.12, 0.42));
        cedarSpray.push({ m: new THREE.Matrix4().compose(_p, IDENT, _s), c: _c.clone() });
      }
    }

    // ------------------------------------------------ overhanging canopy layer
    const canopy = scatter(rnd, 520, 0, 24, 0);
    for (const t of canopy) {
      const size = 3.2 + rnd() * 2.4;
      _p.set(t.x, t.y + 8.5 + rnd() * 9, t.z);
      _s.set(size, size, size);
      _c.setHSL(0.21 + rnd() * 0.06, 0.5, 0.2 + rnd() * 0.16); // seen from below: darker
      (rnd() < 0.5 ? leafA : leafB).push({ m: new THREE.Matrix4().compose(_p, IDENT, _s), c: _c.clone() });
    }

    // ------------------------------------------------------------- undergrowth
    const bushes = scatter(rnd, 2400, edge + 0.15, 30, 0.9);
    const bushCards: Inst[] = [];
    for (const t of bushes) {
      const w = 0.5 + rnd() * 1.2;
      const yaw = rnd() * Math.PI;
      const l = 0.28 + rnd() * 0.16;
      for (let j = 0; j < 2; j++) {
        _p.set(t.x, t.y - 0.05, t.z);
        _e.set(0, yaw + j * Math.PI * 0.5, 0);
        _q.setFromEuler(_e);
        _s.set(w, w * 0.8, 1);
        _c.setHSL(0.24 + rnd() * 0.05, 0.45, l);
        bushCards.push({ m: new THREE.Matrix4().compose(_p, _q, _s), c: _c.clone() });
      }
    }
    const shrubs = scatter(rnd, 380, edge + 0.6, 18, 0.95);
    for (const t of shrubs) {
      const size = 1.0 + rnd() * 1.4;
      _p.set(t.x, t.y + size * 0.3, t.z);
      _s.set(size, size, size);
      _c.setHSL(0.21 + rnd() * 0.06, 0.5, 0.26 + rnd() * 0.16);
      (rnd() < 0.5 ? leafA : leafB).push({ m: new THREE.Matrix4().compose(_p, IDENT, _s), c: _c.clone() });
    }

    // ----------------------------------------------------------------- rocks
    const rockPts = scatter(rnd, 260, edge + 0.3, 14, 0.9).filter((p) => p.signed > 0);
    const rocks: Inst[] = [];
    for (const t of rockPts) {
      const s = 0.2 + rnd() * 0.5;
      _p.set(t.x, t.y - s * 0.4, t.z);
      _e.set(rnd() * 3, rnd() * 3, rnd() * 3);
      _q.setFromEuler(_e);
      _s.set(s * (0.8 + rnd() * 0.6), s * (0.5 + rnd() * 0.4), s);
      rocks.push({ m: new THREE.Matrix4().compose(_p, _q, _s) });
    }
    const logPts = scatter(rnd, 60, edge + 0.4, 9, 1);
    const logs: Inst[] = [];
    for (const t of logPts) {
      const len = 1 + rnd() * 3;
      const r = 0.05 + rnd() * 0.1;
      _p.set(t.x, t.y + r, t.z);
      _e.set((rnd() - 0.5) * 0.3, rnd() * Math.PI, Math.PI / 2 + (rnd() - 0.5) * 0.2);
      _q.setFromEuler(_e);
      _s.set(r, len, r);
      logs.push({ m: new THREE.Matrix4().compose(_p, _q, _s) });
    }

    return { broadVariants, cedarVariants, broadSkel, leafA, leafB, cedarTrunks, cedarSkel, cedarSpray, bushCards, rocks, logs };
  }, []);

  const mats = useMemo(() => {
    const bark = makeBark();
    bark.repeat.set(2, 6);
    const sprayA = makeLeafSpray(101);
    const sprayB = makeLeafSpray(202);
    const cedar = makeCedarSpray(303);
    const bush = makeUndergrowthCard();
    return {
      bark: new THREE.MeshStandardMaterial({ map: bark, color: '#7d6b5c', roughness: 1 }),
      branch: new THREE.MeshStandardMaterial({ color: '#4a4036', roughness: 1 }),
      branchLight: new THREE.MeshStandardMaterial({ color: '#6b645a', roughness: 1 }),
      leafA: makeBillboardMaterial(sprayA, '#e2f0bc', '#72a434', 0.32),
      leafB: makeBillboardMaterial(sprayB, '#dfeeb8', '#72a434', 0.32),
      leafADepth: makeBillboardDepth(sprayA),
      leafBDepth: makeBillboardDepth(sprayB),
      cedar: makeBillboardMaterial(cedar, '#c4d6b0', '#3c6a26', 0.32),
      cedarDepth: makeBillboardDepth(cedar),
      bush: makeCardMaterial(bush, '#93b478', '#4e7a2c', 0.22),
      bushDepth: new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: bush, alphaTest: 0.42, side: THREE.DoubleSide }),
      rock: new THREE.MeshStandardMaterial({ color: '#6f6a60', roughness: 1, flatShading: true }),
      log: new THREE.MeshStandardMaterial({ map: bark, color: '#5a4636', roughness: 1 }),
    };
  }, []);

  const geos = useMemo(() => {
    const trunk = new THREE.CylinderGeometry(0.4, 1, 1, 8, 1, true);
    trunk.translate(0, 0.5, 0);
    const card = new THREE.PlaneGeometry(1, 1, 1, 1);
    card.translate(0, 0.5, 0);
    const quad = new THREE.PlaneGeometry(1, 1, 1, 1);
    const hanging = new THREE.PlaneGeometry(1, 1, 1, 1);
    hanging.translate(0, -0.5, 0); // pivot at the top: sprays hang from the branch
    const rock = new THREE.DodecahedronGeometry(1, 0);
    const log = new THREE.CylinderGeometry(1, 1, 1, 6, 1);
    return { trunk, card, quad, hanging, rock, log };
  }, []);

  useFrame(({ clock }) => {
    timeUniform.value = clock.elapsedTime;
  });

  return (
    <group>
      <Instanced geo={geos.trunk} mat={mats.bark} items={built.cedarTrunks} colors={false} shadow />
      {built.cedarVariants.map((v, i) => (
        <Instanced key={'cs' + i} geo={v.geo} mat={mats.branch} items={built.cedarSkel[i]} colors={false} shadow />
      ))}
      {built.broadVariants.map((v, i) => (
        <Instanced key={'bs' + i} geo={v.geo} mat={mats.branchLight} items={built.broadSkel[i]} colors={false} shadow />
      ))}
      <Instanced geo={geos.quad} mat={mats.leafA} items={built.leafA} colors shadow depth={mats.leafADepth} />
      <Instanced geo={geos.quad} mat={mats.leafB} items={built.leafB} colors shadow depth={mats.leafBDepth} />
      <Instanced geo={geos.hanging} mat={mats.cedar} items={built.cedarSpray} colors shadow depth={mats.cedarDepth} />
      <Instanced geo={geos.card} mat={mats.bush} items={built.bushCards} colors shadow depth={mats.bushDepth} />
      <Instanced geo={geos.rock} mat={mats.rock} items={built.rocks} colors={false} shadow />
      <Instanced geo={geos.log} mat={mats.log} items={built.logs} colors={false} shadow />
    </group>
  );
}
