import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { smokeQueue, skidQueue } from '../world/systems';
import { makeSmokeSprite, makeSkidTexture } from '../world/textures';

// ------------------------------------------------------------------ TIRE SMOKE
const MAX_SMOKE = 1400;

export function TireSmoke() {
  const ref = useRef<THREE.Points>(null);
  const state = useMemo(() => {
    const pos = new Float32Array(MAX_SMOKE * 3);
    const size = new Float32Array(MAX_SMOKE);
    const alpha = new Float32Array(MAX_SMOKE);
    const vel = new Float32Array(MAX_SMOKE * 3);
    const life = new Float32Array(MAX_SMOKE);
    const maxLife = new Float32Array(MAX_SMOKE);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));
    geo.setAttribute('aAlpha', new THREE.BufferAttribute(alpha, 1));
    const tex = makeSmokeSprite();
    const mat = new THREE.ShaderMaterial({
      uniforms: { map: { value: tex }, fogColor: { value: new THREE.Color('#d6e0cf') }, fogDensity: { value: 0.0088 } },
      vertexShader: `
        attribute float aSize; attribute float aAlpha;
        uniform float fogDensity;
        varying float vAlpha; varying float vFog;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position,1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * (520.0 / -mv.z);
          vAlpha = aAlpha;
          float d = -mv.z;
          vFog = 1.0 - exp(-fogDensity*fogDensity*d*d);
        }`,
      fragmentShader: `
        uniform sampler2D map; uniform vec3 fogColor;
        varying float vAlpha; varying float vFog;
        void main(){
          vec4 t = texture2D(map, gl_PointCoord);
          vec3 col = mix(vec3(0.86,0.87,0.84), fogColor, vFog);
          gl_FragColor = vec4(col, t.a * vAlpha);
        }`,
      transparent: true,
      depthWrite: false,
      depthTest: true,
    });
    return { geo, mat, pos, size, alpha, vel, life, maxLife, head: 0 };
  }, []);

  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.05);
    const { pos, size, alpha, vel, life, maxLife } = state;
    // spawn
    while (smokeQueue.length) {
      const r = smokeQueue.pop()!;
      const n = 1 + Math.floor(r.intensity * 2);
      for (let k = 0; k < n; k++) {
        const i = state.head;
        state.head = (state.head + 1) % MAX_SMOKE;
        pos[i * 3] = r.x + (Math.random() - 0.5) * 0.4;
        pos[i * 3 + 1] = r.y + 0.05;
        pos[i * 3 + 2] = r.z + (Math.random() - 0.5) * 0.4;
        vel[i * 3] = r.vx * 0.25 + (Math.random() - 0.5) * 1.2;
        vel[i * 3 + 1] = 0.4 + Math.random() * 0.9;
        vel[i * 3 + 2] = r.vz * 0.25 + (Math.random() - 0.5) * 1.2;
        maxLife[i] = 1.6 + Math.random() * 2.2;
        life[i] = maxLife[i];
        size[i] = 0.6 + Math.random() * 0.5;
        alpha[i] = 0.5 * r.intensity;
      }
    }
    // integrate
    for (let i = 0; i < MAX_SMOKE; i++) {
      if (life[i] <= 0) {
        alpha[i] = 0;
        continue;
      }
      life[i] -= dt;
      const f = life[i] / maxLife[i];
      pos[i * 3] += vel[i * 3] * dt;
      pos[i * 3 + 1] += vel[i * 3 + 1] * dt;
      pos[i * 3 + 2] += vel[i * 3 + 2] * dt;
      vel[i * 3] *= 1 - 1.6 * dt;
      vel[i * 3 + 2] *= 1 - 1.6 * dt;
      vel[i * 3 + 1] += 0.12 * dt;
      size[i] += (2.4 + (1 - f)) * dt;
      alpha[i] = Math.min(alpha[i], 0.55) * (f < 0.8 ? f / 0.8 : 1) * 0.985;
    }
    const g = state.geo;
    (g.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (g.attributes.aSize as THREE.BufferAttribute).needsUpdate = true;
    (g.attributes.aAlpha as THREE.BufferAttribute).needsUpdate = true;
  });

  return <points ref={ref} geometry={state.geo} material={state.mat} frustumCulled={false} renderOrder={10} />;
}

// ------------------------------------------------------------------ SKID MARKS
const MAX_SKID = 4000;

export function SkidMarks() {
  const state = useMemo(() => {
    const pos = new Float32Array(MAX_SKID * 4 * 3);
    const uv = new Float32Array(MAX_SKID * 4 * 2);
    const col = new Float32Array(MAX_SKID * 4);
    const idx = new Uint32Array(MAX_SKID * 6);
    for (let i = 0; i < MAX_SKID; i++) {
      const b = i * 4;
      idx[i * 6] = b;
      idx[i * 6 + 1] = b + 2;
      idx[i * 6 + 2] = b + 1;
      idx[i * 6 + 3] = b + 1;
      idx[i * 6 + 4] = b + 2;
      idx[i * 6 + 5] = b + 3;
      uv[b * 2] = 0; uv[b * 2 + 1] = 0;
      uv[b * 2 + 2] = 1; uv[b * 2 + 3] = 0;
      uv[b * 2 + 4] = 0; uv[b * 2 + 5] = 1;
      uv[b * 2 + 6] = 1; uv[b * 2 + 7] = 1;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geo.setAttribute('aAlpha', new THREE.BufferAttribute(col, 1));
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.setDrawRange(0, 0);
    const tex = makeSkidTexture();
    const mat = new THREE.ShaderMaterial({
      uniforms: { map: { value: tex } },
      vertexShader: `
        attribute float aAlpha; varying float vA; varying vec2 vUv;
        void main(){ vA = aAlpha; vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `
        uniform sampler2D map; varying float vA; varying vec2 vUv;
        void main(){ float a = texture2D(map, vUv).a; gl_FragColor = vec4(0.05,0.05,0.05, a * vA); }`,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    return { geo, mat, pos, col, head: 0, count: 0 };
  }, []);

  useFrame(() => {
    if (!skidQueue.length) return;
    const { pos, col } = state;
    while (skidQueue.length) {
      const s = skidQueue.pop()!;
      const i = state.head;
      state.head = (state.head + 1) % MAX_SKID;
      state.count = Math.min(state.count + 1, MAX_SKID);
      const b = i * 12;
      pos[b] = s.ax; pos[b + 1] = s.ay; pos[b + 2] = s.az;
      pos[b + 3] = s.bx; pos[b + 4] = s.by; pos[b + 5] = s.bz;
      pos[b + 6] = s.cx; pos[b + 7] = s.cy; pos[b + 8] = s.cz;
      pos[b + 9] = s.dx; pos[b + 10] = s.dy; pos[b + 11] = s.dz;
      col[i * 4] = col[i * 4 + 1] = col[i * 4 + 2] = col[i * 4 + 3] = s.alpha;
    }
    (state.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (state.geo.attributes.aAlpha as THREE.BufferAttribute).needsUpdate = true;
    state.geo.setDrawRange(0, state.count * 6);
  });

  return <mesh geometry={state.geo} material={state.mat} frustumCulled={false} renderOrder={2} />;
}
