import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import CarModel, { CarHandle } from './CarModel';
import { curve, TRACK_LENGTH, terrainHeight } from '../world/track';
import { emitSmoke, skidQueue } from '../world/systems';
import { clamp, lerp } from '../world/noise';

interface AIState {
  t: number;
  speed: number;
  drift: number;
  lateral: number;
  prevL: THREE.Vector3;
  prevR: THREE.Vector3;
  had: boolean;
}

function AICar({ start, speed, color, wing, accent }: { start: number; speed: number; color: string; wing?: boolean; accent?: string }) {
  const ref = useRef<CarHandle>(null);
  const st = useMemo<AIState>(
    () => ({ t: start, speed, drift: 0, lateral: 0, prevL: new THREE.Vector3(), prevR: new THREE.Vector3(), had: false }),
    [start, speed],
  );
  const tmp = useMemo(
    () => ({ p: new THREE.Vector3(), p2: new THREE.Vector3(), tan: new THREE.Vector3(), tan2: new THREE.Vector3(), e: new THREE.Euler(), wl: new THREE.Vector3(), wr: new THREE.Vector3() }),
    [],
  );

  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.033);
    const h = ref.current;
    if (!h) return;
    const { p, tan, tan2, e } = tmp;
    // curvature look-ahead
    curve.getTangentAt(st.t, tan).setY(0).normalize();
    curve.getTangentAt((st.t + 10 / TRACK_LENGTH) % 1, tan2).setY(0).normalize();
    const a1 = Math.atan2(-tan.x, -tan.z);
    const a2 = Math.atan2(-tan2.x, -tan2.z);
    const turn = Math.atan2(Math.sin(a2 - a1), Math.cos(a2 - a1)); // + = left turn ahead
    const targetDrift = clamp(turn * 4.5, -0.75, 0.75);
    st.drift = lerp(st.drift, targetDrift, 1 - Math.exp(-2.2 * dt));
    // slow in corners, swing wide to the outside then clip the apex
    const targetSpeed = st.speed * (1 - Math.min(Math.abs(turn) * 2.2, 0.45));
    const v = targetSpeed;
    st.t = (st.t + (v * dt) / TRACK_LENGTH) % 1;
    const targetLat = clamp(-turn * 9, -1.9, 1.9);
    st.lateral = lerp(st.lateral, targetLat, 1 - Math.exp(-1.5 * dt));

    curve.getPointAt(st.t, p);
    curve.getTangentAt(st.t, tan).setY(0).normalize();
    const rx = -tan.z, rz = tan.x;
    const x = p.x + rx * st.lateral;
    const z = p.z + rz * st.lateral;
    const heading = Math.atan2(-tan.x, -tan.z) + st.drift;
    const y = terrainHeight(x, z) + 0.06;
    const g = h.group;
    g.position.set(x, y, z);
    const fx = -tan.x, fz = -tan.z; // use travel direction slope
    const hF = terrainHeight(x + fx * 1.4, z + fz * 1.4);
    const hB = terrainHeight(x - fx * 1.4, z - fz * 1.4);
    const pitch = Math.atan2(hB - hF, 2.8);
    e.set(pitch, heading, -st.drift * 0.08, 'YXZ');
    g.quaternion.setFromEuler(e);
    h.steer(-st.drift * 0.9); // counter-steer
    h.spin((v * dt) / 0.31);
    h.setBrake(Math.abs(turn) > 0.08);

    const ad = Math.abs(st.drift);
    const nsin = Math.sin(heading), ncos = Math.cos(heading);
    const nfx = -nsin, nfz = -ncos, nrx = ncos, nrz = -nsin;
    const wl = tmp.wl.set(x - nrx * 0.82 - nfx * 1.42, y + 0.02, z - nrz * 0.82 - nfz * 1.42);
    const wr = tmp.wr.set(x + nrx * 0.82 - nfx * 1.42, y + 0.02, z + nrz * 0.82 - nfz * 1.42);
    if (ad > 0.18) {
      const inten = clamp((ad - 0.1) * 1.6, 0, 1);
      emitSmoke(wl.x, wl.y, wl.z, fx * v, fz * v, inten);
      emitSmoke(wr.x, wr.y, wr.z, fx * v, fz * v, inten);
      if (st.had) {
        const w = 0.13;
        for (const [prev, cur] of [[st.prevL, wl], [st.prevR, wr]] as [THREE.Vector3, THREE.Vector3][]) {
          const dx = cur.x - prev.x, dz = cur.z - prev.z;
          const len = Math.hypot(dx, dz) || 1;
          const px = (-dz / len) * w, pz = (dx / len) * w;
          skidQueue.push({
            ax: prev.x - px, ay: prev.y, az: prev.z - pz,
            bx: prev.x + px, by: prev.y, bz: prev.z + pz,
            cx: cur.x - px, cy: cur.y, cz: cur.z - pz,
            dx: cur.x + px, dy: cur.y, dz: cur.z + pz,
            alpha: 0.2 + inten * 0.5,
          });
        }
      }
      st.had = true;
    } else st.had = false;
    st.prevL.copy(wl);
    st.prevR.copy(wr);
  });

  return <CarModel ref={ref} color={color} wing={wing} accent={accent} />;
}

export default function AICars() {
  return (
    <>
      <AICar start={0.035} speed={19} color="#f2c516" accent="#111" />
      <AICar start={0.07} speed={18.5} color="#c9cbc6" wing accent="#1b5fa8" />
      <AICar start={0.5} speed={19.5} color="#e0301e" accent="#0e0e0e" />
    </>
  );
}
