import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import CarModel, { CarHandle } from './CarModel';
import { input, playerState, emitSmoke, skidQueue } from '../world/systems';
import { queryRoad, terrainHeight, ROAD_WIDTH, GUTTER_WIDTH, curve } from '../world/track';
import { clamp, lerp } from '../world/noise';

const EDGE = ROAD_WIDTH / 2 + GUTTER_WIDTH;
const WHEEL_R = 0.31;

const wrapAngle = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));

export default function PlayerCar() {
  const car = useRef<CarHandle>(null);
  const { camera } = useThree();

  const s = useMemo(() => {
    const p0 = curve.getPointAt(0);
    const t0 = curve.getTangentAt(0);
    return {
      x: p0.x,
      z: p0.z,
      y: p0.y,
      heading: Math.atan2(-t0.x, -t0.z),
      vx: 0,
      vz: 0,
      yawRate: 0,
      steer: 0,
      pitch: 0,
      roll: 0,
      prevRL: new THREE.Vector3(),
      prevRR: new THREE.Vector3(),
      hadSkid: false,
      camPos: new THREE.Vector3(p0.x, p0.y + 3, p0.z + 8),
      camLook: new THREE.Vector3(p0.x, p0.y, p0.z),
      trackside: new THREE.Vector3(),
      tracksideValid: false,
      shakeT: 0,
    };
  }, []);

  // keyboard
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW': case 'ArrowUp': input.forward = 1; break;
        case 'KeyS': case 'ArrowDown': input.back = 1; break;
        case 'KeyA': case 'ArrowLeft': input.left = 1; break;
        case 'KeyD': case 'ArrowRight': input.right = 1; break;
        case 'Space': input.handbrake = 1; e.preventDefault(); break;
        case 'KeyR': input.reset = true; break;
        case 'KeyC': input.camToggle = true; break;
      }
    };
    const up = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW': case 'ArrowUp': input.forward = 0; break;
        case 'KeyS': case 'ArrowDown': input.back = 0; break;
        case 'KeyA': case 'ArrowLeft': input.left = 0; break;
        case 'KeyD': case 'ArrowRight': input.right = 0; break;
        case 'Space': input.handbrake = 0; break;
      }
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, []);

  const tmp = useMemo(
    () => ({
      f: new THREE.Vector3(),
      r: new THREE.Vector3(),
      wl: new THREE.Vector3(),
      wr: new THREE.Vector3(),
      desired: new THREE.Vector3(),
      look: new THREE.Vector3(),
      q: new THREE.Quaternion(),
      e: new THREE.Euler(),
    }),
    [],
  );

  useFrame((_, dtRaw) => {
    const dt = Math.min(dtRaw, 0.033);
    const h = car.current;
    if (!h) return;

    if (typeof location !== 'undefined' && location.hash === '#top' && playerState.cameraMode !== 3) playerState.cameraMode = 3;
    if (input.camToggle) {
      input.camToggle = false;
      playerState.cameraMode = (playerState.cameraMode + 1) % 3;
      s.tracksideValid = false;
    }

    if (input.reset) {
      input.reset = false;
      const q = queryRoad(s.x, s.z);
      const t = q.t;
      const p = curve.getPointAt(t);
      const tan = curve.getTangentAt(t);
      s.x = p.x;
      s.z = p.z;
      s.heading = Math.atan2(-tan.x, -tan.z);
      s.vx = s.vz = 0;
      s.yawRate = 0;
    }

    // ------------------------------------------------------------ physics
    const sinH = Math.sin(s.heading);
    const cosH = Math.cos(s.heading);
    const fx = -sinH, fz = -cosH; // forward (nose is -Z in model space)
    const rx = cosH, rz = -sinH; // right
    let vF = s.vx * fx + s.vz * fz;
    let vR = s.vx * rx + s.vz * rz;
    const speed = Math.hypot(s.vx, s.vz);

    const q = queryRoad(s.x, s.z);
    const offroad = q.dist > EDGE + 0.15;

    // throttle / brake
    const maxSpeed = offroad ? 16 : 36;
    if (input.forward) vF += 12.5 * Math.max(0, 1 - vF / maxSpeed) * dt;
    if (input.back) {
      if (vF > 0.5) vF -= 20 * dt;
      else vF = Math.max(vF - 6 * dt, -8);
    }
    // rolling resistance & drag
    vF -= vF * (offroad ? 0.9 : 0.09) * dt;
    if (Math.abs(vF) < 0.05 && !input.forward && !input.back) vF = 0;
    if (input.handbrake) vF -= vF * 1.1 * dt;

    // steering (smoothed)
    const steerTarget = (input.left - input.right) * 0.55;
    s.steer = lerp(s.steer, steerTarget, 1 - Math.exp(-9 * dt));
    const speedFactor = clamp(Math.abs(vF) / 7, 0, 1);
    const slip = Math.abs(vR);
    const drifting = slip > 2.0 || (input.handbrake === 1 && speed > 3);
    // steering authority grows a bit while drifting so you can hold angle
    const steerRate = 1.75 * (drifting ? 1.35 : 1) * speedFactor * Math.sign(vF || 1);
    let yawTarget = s.steer * steerRate;

    // self aligning torque: nose tends toward velocity vector
    if (speed > 1) {
      const velAngle = Math.atan2(-s.vx, -s.vz);
      const d = wrapAngle(velAngle - s.heading) * (vF < 0 ? 0 : 1);
      const alignK = input.handbrake ? 0.6 : drifting ? 1.3 : 2.6;
      yawTarget += d * alignK;
    }
    s.yawRate = lerp(s.yawRate, yawTarget, 1 - Math.exp(-6 * dt));
    s.heading += s.yawRate * dt;

    // lateral grip: lower when hand-braking, power-sliding or on dirt
    let grip = 7.0;
    if (offroad) grip = 2.8;
    if (input.handbrake) grip = 1.1;
    else if (drifting) grip = 2.1 + (input.forward ? 0 : 0.9);
    // power oversteer: strong throttle in a tight turn kicks the tail out
    const kick = input.forward && Math.abs(s.yawRate) > 0.75 && vF > 9 ? 1 : 0;
    if (kick) {
      grip *= 0.5;
      vR += Math.sign(s.yawRate) * 3.2 * dt;
    }
    vR *= Math.exp(-grip * dt);
    // yaw induces slip (velocity lags behind the nose)
    vR += s.yawRate * vF * 0.5 * dt;

    // recompose
    const nsin = Math.sin(s.heading);
    const ncos = Math.cos(s.heading);
    const nfx = -nsin, nfz = -ncos, nrx = ncos, nrz = -nsin;
    s.vx = nfx * vF + nrx * vR;
    s.vz = nfz * vF + nrz * vR;
    s.x += s.vx * dt;
    s.z += s.vz * dt;

    // soft walls (cut bank uphill, drop-off downhill)
    const q2 = queryRoad(s.x, s.z);
    const limitR = EDGE + 1.6; // uphill bank
    const limitL = EDGE + 3.2; // downhill shoulder
    if (q2.signed > limitR || q2.signed < -limitL) {
      const lim = q2.signed > 0 ? limitR : -limitL;
      const tx = q2.tangent.x, tz = q2.tangent.z;
      const rightx = -tz, rightz = tx;
      const over = q2.signed - lim;
      s.x -= rightx * over;
      s.z -= rightz * over;
      const vOut = s.vx * rightx + s.vz * rightz;
      if (Math.sign(vOut) === Math.sign(lim)) {
        s.vx -= rightx * vOut * 1.4;
        s.vz -= rightz * vOut * 1.4;
        s.vx *= 0.7;
        s.vz *= 0.7;
        s.shakeT = 0.3;
      }
    }

    // ------------------------------------------------------------ pose
    const hF = terrainHeight(s.x + nfx * 1.4, s.z + nfz * 1.4);
    const hB = terrainHeight(s.x - nfx * 1.4, s.z - nfz * 1.4);
    const hL = terrainHeight(s.x - nrx * 0.8, s.z - nrz * 0.8);
    const hR = terrainHeight(s.x + nrx * 0.8, s.z + nrz * 0.8);
    const groundY = (hF + hB + hL + hR) / 4 + 0.06;
    s.y = lerp(s.y, groundY, 1 - Math.exp(-14 * dt));
    const pitchT = Math.atan2(hB - hF, 2.8);
    const rollT = Math.atan2(hR - hL, 1.6);
    // body roll from lateral g + squat
    const bodyRoll = clamp(vR * 0.012 + s.yawRate * vF * 0.004, -0.08, 0.08);
    const squat = clamp((input.forward ? -0.02 : 0) + (input.back && vF > 2 ? 0.03 : 0), -0.05, 0.05);
    s.pitch = lerp(s.pitch, pitchT + squat, 1 - Math.exp(-8 * dt));
    s.roll = lerp(s.roll, rollT + bodyRoll, 1 - Math.exp(-8 * dt));

    const g = h.group;
    g.position.set(s.x, s.y, s.z);
    tmp.e.set(s.pitch, s.heading, s.roll, 'YXZ');
    g.quaternion.setFromEuler(tmp.e);
    h.steer(s.steer);
    h.spin((vF * dt) / WHEEL_R);
    h.setBrake(input.back === 1 || input.handbrake === 1);

    // ------------------------------------------------------------ smoke & skid
    const rearL = tmp.wl.set(s.x - nrx * 0.82 + nfx * -1.42, s.y + 0.02, s.z - nrz * 0.82 + nfz * -1.42);
    const rearR = tmp.wr.set(s.x + nrx * 0.82 + nfx * -1.42, s.y + 0.02, s.z + nrz * 0.82 + nfz * -1.42);
    const burnout = input.forward === 1 && input.handbrake === 1 && speed < 8;
    const intensity = clamp(slip / 9 + (burnout ? 0.6 : 0) + (kick ? 0.3 : 0), 0, 1);
    const slipping = (drifting && speed > 2.5) || burnout;
    if (slipping && !offroad) {
      emitSmoke(rearL.x, rearL.y, rearL.z, s.vx, s.vz, intensity);
      emitSmoke(rearR.x, rearR.y, rearR.z, s.vx, s.vz, intensity);
      if (s.hadSkid) {
        const w = 0.13;
        const alpha = clamp(0.25 + intensity * 0.6, 0, 0.85);
        for (const [prev, cur] of [
          [s.prevRL, rearL],
          [s.prevRR, rearR],
        ] as [THREE.Vector3, THREE.Vector3][]) {
          const dx = cur.x - prev.x;
          const dz = cur.z - prev.z;
          const len = Math.hypot(dx, dz) || 1;
          const px = (-dz / len) * w;
          const pz = (dx / len) * w;
          skidQueue.push({
            ax: prev.x - px, ay: prev.y, az: prev.z - pz,
            bx: prev.x + px, by: prev.y, bz: prev.z + pz,
            cx: cur.x - px, cy: cur.y, cz: cur.z - pz,
            dx: cur.x + px, dy: cur.y, dz: cur.z + pz,
            alpha,
          });
        }
      }
      s.hadSkid = true;
    } else {
      s.hadSkid = false;
    }
    if (offroad && speed > 4) {
      // dust kick on dirt
      emitSmoke(rearL.x, rearL.y, rearL.z, s.vx, s.vz, 0.25);
    }
    s.prevRL.copy(rearL);
    s.prevRR.copy(rearR);

    // ------------------------------------------------------------ shared state
    playerState.x = s.x;
    playerState.y = s.y;
    playerState.z = s.z;
    playerState.heading = s.heading;
    playerState.speed = speed;
    playerState.drifting = slipping;
    playerState.slip = slip;

    // ------------------------------------------------------------ camera
    const mode = playerState.cameraMode;
    s.shakeT = Math.max(0, s.shakeT - dt);
    if (mode === 0) {
      // chase cam, swings toward the velocity direction while drifting
      const velA = speed > 2 ? Math.atan2(-s.vx, -s.vz) : s.heading;
      const blend = clamp(slip / 10, 0, 0.6);
      const camA = s.heading + wrapAngle(velA - s.heading) * blend;
      const bx = -Math.sin(camA), bz = -Math.cos(camA);
      const dist = 7.4 + speed * 0.06;
      tmp.desired.set(s.x - bx * dist, s.y + 2.7 + speed * 0.01, s.z - bz * dist);
      s.camPos.lerp(tmp.desired, 1 - Math.exp(-5 * dt));
      // keep the camera above the ground
      const camGround = terrainHeight(s.camPos.x, s.camPos.z) + 0.7;
      if (s.camPos.y < camGround) s.camPos.y = camGround;
      tmp.look.set(s.x + nfx * 3, s.y + 0.9, s.z + nfz * 3);
      s.camLook.lerp(tmp.look, 1 - Math.exp(-10 * dt));
      camera.position.copy(s.camPos);
      if (s.shakeT > 0) camera.position.y += (Math.random() - 0.5) * 0.08;
      camera.lookAt(s.camLook);
      (camera as THREE.PerspectiveCamera).fov = lerp((camera as THREE.PerspectiveCamera).fov, 62 + speed * 0.35, 0.05);
      camera.updateProjectionMatrix();
    } else if (mode === 1) {
      // trackside photographer cam on the uphill bank, re-picked as the car passes
      const toCam = s.tracksideValid ? s.trackside.distanceTo(g.position) : Infinity;
      const passed =
        s.tracksideValid && (s.trackside.x - s.x) * nfx + (s.trackside.z - s.z) * nfz < -12;
      if (!s.tracksideValid || toCam > 75 || passed) {
        const tAhead = (q2.t + (30 + Math.random() * 15) / curve.getLength()) % 1;
        const p = curve.getPointAt(tAhead);
        const tn = curve.getTangentAt(tAhead).setY(0).normalize();
        const side = Math.random() > 0.35 ? 1 : -1;
        const lat = side > 0 ? EDGE + 1.0 + Math.random() * 1.5 : -(EDGE + 1.2);
        s.trackside.set(p.x + -tn.z * lat, 0, p.z + tn.x * lat);
        s.trackside.y = terrainHeight(s.trackside.x, s.trackside.z) + 1.6 + (side > 0 ? 0.6 : 0.2);
        s.tracksideValid = true;
        camera.position.copy(s.trackside);
      }
      camera.position.copy(s.trackside);
      tmp.look.set(s.x, s.y + 0.7, s.z);
      s.camLook.lerp(tmp.look, 1 - Math.exp(-6 * dt));
      camera.lookAt(s.camLook);
      const d = s.trackside.distanceTo(g.position);
      (camera as THREE.PerspectiveCamera).fov = clamp(900 / (d + 6), 28, 55);
      camera.updateProjectionMatrix();
    } else if (mode === 3) {
      camera.position.set(s.x + 6, s.y + 55, s.z + 6);
      camera.lookAt(s.x, s.y, s.z);
      (camera as THREE.PerspectiveCamera).fov = 50;
      camera.updateProjectionMatrix();
    } else {
      // hood cam
      tmp.desired.set(s.x + nfx * 0.2, s.y + 1.05, s.z + nfz * 0.2);
      camera.position.copy(tmp.desired);
      tmp.look.set(s.x + nfx * 12, s.y + 0.6, s.z + nfz * 12);
      camera.quaternion.setFromEuler(tmp.e.set(s.pitch * 0.6, s.heading, s.roll * 0.5, 'YXZ'));
      (camera as THREE.PerspectiveCamera).fov = 75;
      camera.updateProjectionMatrix();
    }
  });

  return <CarModel ref={car} color="#d8231b" accent="#2a0a0a" />;
}
