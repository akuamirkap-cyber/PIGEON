import { Suspense } from 'react';
import { EffectComposer, Bloom, Vignette, ToneMapping } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import Road from './Road';
import Terrain from './Terrain';
import Forest from './Forest';
import { Sun, LightShafts, DustMotes, SkyDome, FOG_COLOR, SKY_COLOR } from './Lighting';
import PlayerCar from './PlayerCar';
import AICars from './AICars';
import RoadProps from './RoadProps';
import { TireSmoke, SkidMarks } from './Effects';

export default function Scene() {
  return (
    <>
      <color attach="background" args={[SKY_COLOR]} />
      <fogExp2 attach="fog" args={[FOG_COLOR, 0.0088]} />
      <Sun />
      <Suspense fallback={null}>
        <Terrain />
        <Road />
        <Forest />
        <RoadProps />
        <LightShafts />
        <DustMotes />
        <SkidMarks />
        <TireSmoke />
        <PlayerCar />
        <AICars />
      </Suspense>
      <SkyDome />
      <EffectComposer multisampling={4}>
        <Bloom luminanceThreshold={0.7} luminanceSmoothing={0.35} intensity={0.85} mipmapBlur radius={0.7} />
        <Vignette eskil={false} offset={0.18} darkness={0.75} />
        <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      </EffectComposer>
    </>
  );
}
