import { useMemo, useRef, useEffect } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { playerState } from '../world/systems';
import { curve, terrainHeight } from '../world/track';
import { mulberry32 } from '../world/noise';
import { makeShaftGradient, makeSmokeSprite } from '../world/textures';

export const SUN_DIR = new THREE.Vector3(0.22, 1, 0.16).normalize();
export const SKY_COLOR = '#e3e9de';
export const FOG_COLOR = '#d6e0cf';

export function Sun() {
  const light = useRef<THREE.DirectionalLight>(null);
  const target = useMemo(() => new THREE.Object3D(), []);
  const { scene } = useThree();
  useEffect(() => {
    scene.add(target);
    return () => {
      scene.remove(target);
    };
  }, [scene, target]);

  useFrame(() => {
    if (!light.current) return;
    // Keep the shadow frustum centred on the player so canopy shadows stay crisp.
    const px = playerState.x;
    const pz = playerState.z;
    const py = playerState.y;
    target.position.set(px, py, pz);
    target.updateMatrixWorld();
    light.current.position.set(px + SUN_DIR.x * 90, py + SUN_DIR.y * 90, pz + SUN_DIR.z * 90);
    light.current.target = target;
  });

  return (
    <>
      <directionalLight
        ref={light}
        color="#fff0d2"
        intensity={3.4}
        castShadow
        shadow-mapSize={[4096, 4096]}
        shadow-bias={-0.00025}
        shadow-normalBias={0.03}
        shadow-radius={3}
      >
        <orthographicCamera attach="shadow-camera" args={[-55, 55, 55, -55, 10, 220]} />
      </directionalLight>
      <hemisphereLight color="#dfeadf" groundColor="#52623a" intensity={2.0} />
      <ambientLight color="#9db394" intensity={0.35} />
    </>
  );
}

// Volumetric-looking light shafts: additive gradient planes aligned with the sun.
export function LightShafts() {
  const group = useRef<THREE.Group>(null);
  const { tex, items } = useMemo(() => {
    const tex = makeShaftGradient();
    const rnd = mulberry32(808);
    const items: { pos: THREE.Vector3; rot: THREE.Quaternion; w: number; h: number; o: number; phase: number }[] = [];
    const up = new THREE.Vector3(0, 1, 0);
    const align = new THREE.Quaternion().setFromUnitVectors(up, SUN_DIR);
    const count = 150;
    for (let i = 0; i < count; i++) {
      const t = rnd();
      const p = curve.getPointAt(t);
      const tan = curve.getTangentAt(t).setY(0).normalize();
      const right = new THREE.Vector3().crossVectors(tan, up);
      const lateral = (rnd() - 0.5) * 16;
      const along = (rnd() - 0.5) * 6;
      const base = new THREE.Vector3(
        p.x + right.x * lateral + tan.x * along,
        0,
        p.z + right.z * lateral + tan.z * along,
      );
      base.y = terrainHeight(base.x, base.z);
      const h = 26 + rnd() * 22;
      // centre the shaft halfway up its height along the sun direction
      const centre = base.clone().addScaledVector(SUN_DIR, h * 0.45);
      for (let k = 0; k < 2; k++) {
        const spin = new THREE.Quaternion().setFromAxisAngle(SUN_DIR, rnd() * Math.PI);
        const rot = spin.clone().multiply(align);
        items.push({
          pos: centre,
          rot,
          w: 1.5 + rnd() * 5,
          h,
          o: 0.07 + rnd() * 0.12,
          phase: rnd() * Math.PI * 2,
        });
      }
    }
    return { tex, items };
  }, []);

  const mats = useRef<THREE.MeshBasicMaterial[]>([]);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    for (let i = 0; i < mats.current.length; i++) {
      const m = mats.current[i];
      if (!m) continue;
      const it = items[i];
      m.opacity = it.o * (0.75 + 0.25 * Math.sin(t * 0.35 + it.phase));
    }
  });

  return (
    <group ref={group}>
      {items.map((it, i) => (
        <mesh key={i} position={it.pos} quaternion={it.rot} scale={[it.w, it.h, 1]} renderOrder={5}>
          <planeGeometry args={[1, 1]} />
          <meshBasicMaterial
            ref={(m) => {
              if (m) mats.current[i] = m;
            }}
            map={tex}
            color="#fff3cf"
            transparent
            opacity={it.o}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
            side={THREE.DoubleSide}
            fog={false}
          />
        </mesh>
      ))}
    </group>
  );
}

// Floating dust / pollen motes catching the light
export function DustMotes() {
  const ref = useRef<THREE.Points>(null);
  const { geo, mat } = useMemo(() => {
    const n = 900;
    const pos = new Float32Array(n * 3);
    const rnd = mulberry32(99);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = (rnd() - 0.5) * 60;
      pos[i * 3 + 1] = rnd() * 14;
      pos[i * 3 + 2] = (rnd() - 0.5) * 60;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: '#fff3cc',
      size: 0.16,
      map: makeSmokeSprite(),
      transparent: true,
      opacity: 0.5,
      depthWrite: false,
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
    });
    return { geo, mat };
  }, []);
  useFrame(({ clock }) => {
    if (!ref.current) return;
    const t = clock.elapsedTime;
    ref.current.position.set(playerState.x, playerState.y, playerState.z);
    ref.current.rotation.y = t * 0.01;
    const p = ref.current.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i += 7) {
      p.setY(i, p.getY(i) + Math.sin(t + i) * 0.002);
    }
    p.needsUpdate = true;
  });
  return <points ref={ref} geometry={geo} material={mat} />;
}

// Gradient sky dome with a warm glow around the sun (fog-free so it stays luminous)
export function SkyDome() {
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: {
          sunDir: { value: SUN_DIR.clone() },
          zenith: { value: new THREE.Color('#bcd3e2') },
          horizon: { value: new THREE.Color('#eef1e6') },
          sunCol: { value: new THREE.Color('#fff2cc') },
        },
        vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `
          uniform vec3 sunDir, zenith, horizon, sunCol; varying vec3 vDir;
          void main(){
            float h = clamp(vDir.y, 0.0, 1.0);
            vec3 col = mix(horizon, zenith, pow(h, 0.55));
            float s = max(dot(normalize(vDir), sunDir), 0.0);
            col += sunCol * (pow(s, 6.0) * 0.55 + pow(s, 60.0) * 1.6);
            gl_FragColor = vec4(col, 1.0);
          }`,
      }),
    [],
  );
  const ref = useRef<THREE.Mesh>(null);
  useFrame(({ camera }) => {
    if (ref.current) ref.current.position.copy(camera.position);
  });
  return (
    <mesh ref={ref} material={mat} renderOrder={-10} frustumCulled={false}>
      <sphereGeometry args={[300, 32, 16]} />
    </mesh>
  );
}
