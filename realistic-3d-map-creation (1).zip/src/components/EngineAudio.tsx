import { useEffect, useRef } from 'react';
import { input, playerState } from '../world/systems';

// Tiny procedural engine + tyre squeal using the Web Audio API.
export default function EngineAudio({ enabled }: { enabled: boolean }) {
  const ctxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC();
    ctxRef.current = ctx;
    const master = ctx.createGain();
    master.gain.value = 0.35;
    master.connect(ctx.destination);

    // engine: two detuned saws + sub through a lowpass
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const sub = ctx.createOscillator();
    osc1.type = 'sawtooth';
    osc2.type = 'square';
    sub.type = 'triangle';
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 600;
    const eg = ctx.createGain();
    eg.gain.value = 0.25;
    osc1.connect(lp);
    osc2.connect(lp);
    sub.connect(lp);
    lp.connect(eg);
    eg.connect(master);
    osc1.start();
    osc2.start();
    sub.start();

    // tyre squeal: filtered noise
    const bufferSize = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 1900;
    bp.Q.value = 9;
    const ng = ctx.createGain();
    ng.gain.value = 0;
    noise.connect(bp);
    bp.connect(ng);
    ng.connect(master);
    noise.start();

    let rpm = 0.2;
    let raf = 0;
    const tick = () => {
      const t = ctx.currentTime;
      const spd = playerState.speed;
      // crude gearbox
      const gearSpan = 9;
      const gearPos = (spd % gearSpan) / gearSpan;
      const targetRpm = 0.18 + gearPos * 0.75 + (input.forward ? 0.08 : 0);
      rpm += (targetRpm - rpm) * 0.12;
      const f = 38 + rpm * 150;
      osc1.frequency.setTargetAtTime(f, t, 0.03);
      osc2.frequency.setTargetAtTime(f * 1.01 * 0.5, t, 0.03);
      sub.frequency.setTargetAtTime(f * 0.5, t, 0.03);
      lp.frequency.setTargetAtTime(350 + rpm * 1600 + (input.forward ? 400 : 0), t, 0.05);
      eg.gain.setTargetAtTime(0.16 + rpm * 0.18, t, 0.05);
      const squeal = playerState.drifting ? Math.min(1, playerState.slip / 7 + 0.25) : 0;
      ng.gain.setTargetAtTime(squeal * 0.14, t, 0.08);
      bp.frequency.setTargetAtTime(1500 + playerState.slip * 90, t, 0.08);
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      ctx.close();
    };
  }, [enabled]);

  return null;
}
