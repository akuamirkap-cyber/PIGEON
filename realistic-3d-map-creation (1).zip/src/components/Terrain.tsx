import { useMemo } from 'react';
import * as THREE from 'three';
import { gridHeight } from '../world/track';
import { makeForestFloor } from '../world/textures';

export const TERRAIN_SIZE = 480;
export const TERRAIN_CENTER = { x: -8, z: 42 };
const RES = 300;

export default function Terrain() {
  const { geo, map } = useMemo(() => {
    const geo = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, RES, RES);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) + TERRAIN_CENTER.x;
      const z = pos.getZ(i) + TERRAIN_CENTER.z;
      const h = gridHeight(x, z);
      pos.setXYZ(i, x, h, z);
      // vertex colour: mossy green on flatter ground, raw earth on steep cut banks
      const seed = Math.sin(x * 12.9898 + z * 78.233) * 43758.5453;
      const r = seed - Math.floor(seed);
      c.setHSL(0.22 + r * 0.05, 0.25 + r * 0.2, 0.32 + r * 0.1);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    // darken steep slopes (exposed soil + roots) by modulating color with normal
    const nrm = geo.attributes.normal as THREE.BufferAttribute;
    const col = geo.attributes.color as THREE.BufferAttribute;
    for (let i = 0; i < nrm.count; i++) {
      const ny = nrm.getY(i);
      const steep = 1 - THREE.MathUtils.smoothstep(ny, 0.55, 0.9);
      const r = THREE.MathUtils.lerp(col.getX(i), 0.42, steep);
      const g = THREE.MathUtils.lerp(col.getY(i), 0.33, steep);
      const b = THREE.MathUtils.lerp(col.getZ(i), 0.22, steep);
      col.setXYZ(i, r, g, b);
    }
    const map = makeForestFloor();
    map.repeat.set(TERRAIN_SIZE / 9, TERRAIN_SIZE / 9);
    return { geo, map };
  }, []);

  return (
    <mesh geometry={geo} receiveShadow>
      <meshStandardMaterial map={map} vertexColors roughness={1} color="#c9c0b0" />
    </mesh>
  );
}
