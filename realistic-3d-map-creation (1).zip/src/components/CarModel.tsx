import { forwardRef, useImperativeHandle, useRef, useMemo } from 'react';
import * as THREE from 'three';

export interface CarHandle {
  group: THREE.Group;
  steer: (angle: number) => void;
  spin: (delta: number) => void;
  setBrake: (on: boolean) => void;
}

interface Props {
  color: string;
  wing?: boolean;
  accent?: string;
}

const Wheel = forwardRef<THREE.Group, { x: number; z: number; camber: number }>(({ x, z, camber }, ref) => {
  return (
    <group position={[x, 0.31, z]} rotation={[0, 0, camber]}>
      <group ref={ref}>
        <mesh rotation={[0, 0, Math.PI / 2]} castShadow>
          <cylinderGeometry args={[0.31, 0.31, 0.24, 24]} />
          <meshStandardMaterial color="#141414" roughness={0.9} />
        </mesh>
        {/* rim */}
        <mesh rotation={[0, 0, Math.PI / 2]} position={[x > 0 ? 0.08 : -0.08, 0, 0]}>
          <cylinderGeometry args={[0.215, 0.215, 0.12, 20]} />
          <meshStandardMaterial color="#c9c7bf" metalness={0.85} roughness={0.3} />
        </mesh>
        {/* deep dish lip */}
        <mesh rotation={[0, 0, Math.PI / 2]} position={[x > 0 ? 0.12 : -0.12, 0, 0]}>
          <torusGeometry args={[0.2, 0.025, 8, 24]} />
          <meshStandardMaterial color="#e8e6de" metalness={0.9} roughness={0.2} />
        </mesh>
        {/* spokes */}
        {[0, 1, 2, 3, 4].map((i) => (
          <mesh
            key={i}
            position={[x > 0 ? 0.13 : -0.13, 0, 0]}
            rotation={[(i * Math.PI * 2) / 5, 0, 0]}
          >
            <boxGeometry args={[0.02, 0.3, 0.04]} />
            <meshStandardMaterial color="#8b8a86" metalness={0.8} roughness={0.35} />
          </mesh>
        ))}
        {/* brake disc */}
        <mesh rotation={[0, 0, Math.PI / 2]} position={[x > 0 ? 0.02 : -0.02, 0, 0]}>
          <cylinderGeometry args={[0.17, 0.17, 0.02, 16]} />
          <meshStandardMaterial color="#4a4a4a" metalness={0.6} roughness={0.5} />
        </mesh>
      </group>
    </group>
  );
});

const CarModel = forwardRef<CarHandle, Props>(({ color, wing = false, accent = '#dcdcdc' }, ref) => {
  const group = useRef<THREE.Group>(null!);
  const fl = useRef<THREE.Group>(null!);
  const fr = useRef<THREE.Group>(null!);
  const rl = useRef<THREE.Group>(null!);
  const rr = useRef<THREE.Group>(null!);
  const steerL = useRef<THREE.Group>(null!);
  const steerR = useRef<THREE.Group>(null!);
  const brakeMat = useRef<THREE.MeshStandardMaterial>(null!);

  useImperativeHandle(ref, () => ({
    group: group.current,
    steer: (a: number) => {
      steerL.current.rotation.y = a;
      steerR.current.rotation.y = a;
    },
    spin: (d: number) => {
      fl.current.rotation.x += d;
      fr.current.rotation.x += d;
      rl.current.rotation.x += d;
      rr.current.rotation.x += d;
    },
    setBrake: (on: boolean) => {
      if (brakeMat.current) brakeMat.current.emissiveIntensity = on ? 4 : 1.2;
    },
  }));

  const paint = useMemo(
    () => new THREE.MeshPhysicalMaterial({ color, metalness: 0.4, roughness: 0.28, clearcoat: 1, clearcoatRoughness: 0.12 }),
    [color],
  );
  const glass = useMemo(
    () => new THREE.MeshPhysicalMaterial({ color: '#0d1418', metalness: 0.2, roughness: 0.05, transparent: true, opacity: 0.85 }),
    [],
  );

  const trackW = 0.78;

  // Side-profile silhouettes extruded across the width: low wedge nose, fast
  // windscreen, short roof, kicked-up rear deck (90s JDM coupe proportions).
  const { bodyGeo, cabinGeo } = useMemo(() => {
    const body = new THREE.Shape();
    body.moveTo(-2.2, 0.28);
    body.lineTo(-2.2, 0.5);
    body.lineTo(-2.05, 0.6);
    body.lineTo(-1.3, 0.66);
    body.lineTo(-0.35, 0.8);
    body.lineTo(0.9, 0.84);
    body.lineTo(1.9, 0.86);
    body.lineTo(2.15, 0.78);
    body.lineTo(2.18, 0.28);
    body.closePath();
    const bodyGeo = new THREE.ExtrudeGeometry(body, { depth: 1.62, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.05, bevelSegments: 3, curveSegments: 4 });
    bodyGeo.rotateY(-Math.PI / 2);
    bodyGeo.translate(0.81, 0, 0);
    const cabin = new THREE.Shape();
    cabin.moveTo(-0.45, 0.8);
    cabin.lineTo(0.15, 1.2);
    cabin.lineTo(0.95, 1.23);
    cabin.lineTo(1.5, 1.02);
    cabin.lineTo(1.85, 0.84);
    cabin.closePath();
    const cabinGeo = new THREE.ExtrudeGeometry(cabin, { depth: 1.42, bevelEnabled: true, bevelThickness: 0.04, bevelSize: 0.04, bevelSegments: 2 });
    cabinGeo.rotateY(-Math.PI / 2);
    cabinGeo.translate(0.71, 0, 0);
    return { bodyGeo, cabinGeo };
  }, []);

  return (
    <group ref={group}>
      {/* main body */}
      <mesh geometry={bodyGeo} castShadow material={paint} />
      {/* glasshouse */}
      <mesh geometry={cabinGeo} castShadow material={glass} />
      {/* roof panel & pillars in body colour */}
      <mesh position={[0, 1.235, 0.55]} castShadow material={paint}>
        <boxGeometry args={[1.3, 0.035, 0.7]} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.68, 1.0, 0.0]} rotation={[0.55, 0, 0]} material={paint}>
          <boxGeometry args={[0.05, 0.5, 0.06]} />
        </mesh>
      ))}
      {/* front lip & side skirts */}
      <mesh position={[0, 0.3, -2.18]} castShadow>
        <boxGeometry args={[1.78, 0.12, 0.16]} />
        <meshStandardMaterial color="#111" roughness={0.6} />
      </mesh>
      <mesh position={[0.88, 0.3, 0]}>
        <boxGeometry args={[0.06, 0.12, 2.6]} />
        <meshStandardMaterial color="#111" roughness={0.6} />
      </mesh>
      <mesh position={[-0.88, 0.3, 0]}>
        <boxGeometry args={[0.06, 0.12, 2.6]} />
        <meshStandardMaterial color="#111" roughness={0.6} />
      </mesh>
      {/* fender flares */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 0.84, 0.5, -1.38]} castShadow material={paint}>
            <boxGeometry args={[0.12, 0.3, 0.95]} />
          </mesh>
          <mesh position={[s * 0.86, 0.5, 1.42]} castShadow material={paint}>
            <boxGeometry args={[0.16, 0.32, 1.0]} />
          </mesh>
        </group>
      ))}
      {/* pop-up headlights */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.55, 0.62, -2.1]}>
          <boxGeometry args={[0.42, 0.16, 0.18]} />
          <meshStandardMaterial color="#f4f1e8" emissive="#fff6d0" emissiveIntensity={0.8} roughness={0.3} />
        </mesh>
      ))}
      {/* tail light bar */}
      <mesh position={[0, 0.58, 2.17]}>
        <boxGeometry args={[1.5, 0.16, 0.06]} />
        <meshStandardMaterial ref={brakeMat} color="#6a0b0b" emissive="#ff2211" emissiveIntensity={1.2} roughness={0.3} />
      </mesh>
      {/* exhaust */}
      <mesh position={[0.55, 0.28, 2.2]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 0.2, 12]} />
        <meshStandardMaterial color="#9a9a9a" metalness={0.9} roughness={0.3} />
      </mesh>
      {/* mirrors */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.92, 0.9, -0.35]} material={paint}>
          <boxGeometry args={[0.2, 0.1, 0.14]} />
        </mesh>
      ))}
      {/* lower side accent */}
      <mesh position={[0, 0.33, 0]}>
        <boxGeometry args={[1.76, 0.07, 3.6]} />
        <meshStandardMaterial color={accent} roughness={0.5} />
      </mesh>
      {/* GT wing */}
      {wing && (
        <group position={[0, 1.08, 1.85]}>
          <mesh castShadow>
            <boxGeometry args={[1.6, 0.03, 0.3]} />
            <meshStandardMaterial color="#1a1a1a" roughness={0.4} />
          </mesh>
          {[-0.55, 0.55].map((x) => (
            <mesh key={x} position={[x, -0.17, 0.02]}>
              <boxGeometry args={[0.05, 0.3, 0.22]} />
              <meshStandardMaterial color="#1a1a1a" roughness={0.4} />
            </mesh>
          ))}
          {[-0.8, 0.8].map((x) => (
            <mesh key={x} position={[x, 0.08, 0]}>
              <boxGeometry args={[0.03, 0.2, 0.3]} />
              <meshStandardMaterial color="#1a1a1a" roughness={0.4} />
            </mesh>
          ))}
        </group>
      )}
      {/* wheels */}
      <group ref={steerL} position={[-trackW, 0, -1.38]}>
        <Wheel ref={fl} x={-0.02} z={0} camber={0.1} />
      </group>
      <group ref={steerR} position={[trackW, 0, -1.38]}>
        <Wheel ref={fr} x={0.02} z={0} camber={-0.1} />
      </group>
      <Wheel ref={rl} x={-trackW - 0.03} z={1.42} camber={0.14} />
      <Wheel ref={rr} x={trackW + 0.03} z={1.42} camber={-0.14} />
    </group>
  );
});

export default CarModel;
