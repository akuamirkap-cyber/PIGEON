import { useMemo } from 'react';
import * as THREE from 'three';
import { curve, terrainHeight, ROAD_WIDTH, GUTTER_WIDTH, TRACK_LENGTH } from '../world/track';
import { makeCurveSign } from '../world/textures';

const EDGE = ROAD_WIDTH / 2 + GUTTER_WIDTH;

interface Placement {
  pos: THREE.Vector3;
  yaw: number; // facing oncoming driver
  side: number;
}

function placeAlong(t: number, lateral: number): Placement {
  const p = curve.getPointAt(t);
  const tan = curve.getTangentAt(t).setY(0).normalize();
  const rx = -tan.z, rz = tan.x;
  const x = p.x + rx * lateral;
  const z = p.z + rz * lateral;
  const y = terrainHeight(x, z);
  // face back toward the driver approaching along the tangent
  const yaw = Math.atan2(tan.x, tan.z);
  return { pos: new THREE.Vector3(x, y, z), yaw, side: Math.sign(lateral) };
}

function CurveSign({ t }: { t: number }) {
  const tex = useMemo(() => makeCurveSign(), []);
  const pl = useMemo(() => placeAlong(t, EDGE + 0.9), [t]);
  return (
    <group position={pl.pos} rotation={[0, pl.yaw, 0]}>
      <mesh position={[0, 1.0, 0]} castShadow>
        <cylinderGeometry args={[0.035, 0.035, 2.0, 8]} />
        <meshStandardMaterial color="#8a8a86" metalness={0.6} roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.95, 0]} rotation={[0, 0, -0.06]} castShadow>
        <boxGeometry args={[0.6, 0.9, 0.03]} />
        <meshStandardMaterial map={tex} roughness={0.7} />
      </mesh>
    </group>
  );
}

function CurveMirror({ t, lateral }: { t: number; lateral: number }) {
  const pl = useMemo(() => placeAlong(t, lateral), [t, lateral]);
  return (
    <group position={pl.pos} rotation={[0, pl.yaw + 0.5 * -pl.side, 0]}>
      <mesh position={[0, 1.6, 0]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 3.2, 10]} />
        <meshStandardMaterial color="#e8641b" roughness={0.6} />
      </mesh>
      <mesh position={[0, 3.2, 0.1]} rotation={[0.25, 0, 0]}>
        <cylinderGeometry args={[0.45, 0.45, 0.05, 24]} />
        <meshStandardMaterial color="#e8641b" roughness={0.6} />
      </mesh>
      <mesh position={[0, 3.2, 0.14]} rotation={[Math.PI / 2 + 0.25, 0, 0]}>
        <circleGeometry args={[0.4, 24]} />
        <meshStandardMaterial color="#b9c6cc" metalness={1} roughness={0.08} />
      </mesh>
    </group>
  );
}

// Reflective delineator posts along the drop-off side
function Delineators() {
  const data = useMemo(() => {
    const out: Placement[] = [];
    const spacing = 9;
    const n = Math.floor(TRACK_LENGTH / spacing);
    for (let i = 0; i < n; i++) {
      const t = (i * spacing) / TRACK_LENGTH;
      // only on some stretches (not the whole loop) to look natural
      const seg = Math.floor(t * 6);
      if (seg % 2 === 1) continue;
      out.push(placeAlong(t, -(EDGE + 0.55)));
    }
    return out;
  }, []);
  return (
    <group>
      {data.map((p, i) => (
        <group key={i} position={p.pos} rotation={[0, p.yaw, 0]}>
          <mesh position={[0, 0.55, 0]} castShadow>
            <cylinderGeometry args={[0.04, 0.045, 1.1, 8]} />
            <meshStandardMaterial color="#f2efe6" roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.9, 0]}>
            <cylinderGeometry args={[0.043, 0.043, 0.12, 8]} />
            <meshStandardMaterial color="#d9261c" emissive="#d9261c" emissiveIntensity={0.3} roughness={0.5} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

// Rope-and-stake barrier like the yellow line in the reference photo
function RopeBarrier({ t0, t1 }: { t0: number; t1: number }) {
  const { stakes, rope } = useMemo(() => {
    const stakes: Placement[] = [];
    const pts: THREE.Vector3[] = [];
    const n = 10;
    for (let i = 0; i <= n; i++) {
      const t = t0 + ((t1 - t0) * i) / n;
      const pl = placeAlong(t, EDGE + 0.7);
      stakes.push(pl);
      pts.push(pl.pos.clone().add(new THREE.Vector3(0, 0.75, 0)));
      if (i < n) {
        const next = placeAlong(t0 + ((t1 - t0) * (i + 0.5)) / n, EDGE + 0.7);
        pts.push(next.pos.clone().add(new THREE.Vector3(0, 0.55, 0))); // sag
      }
    }
    const c = new THREE.CatmullRomCurve3(pts);
    const rope = new THREE.TubeGeometry(c, 120, 0.012, 5, false);
    return { stakes, rope };
  }, [t0, t1]);
  return (
    <group>
      {stakes.map((s, i) => (
        <mesh key={i} position={[s.pos.x, s.pos.y + 0.45, s.pos.z]} castShadow>
          <cylinderGeometry args={[0.025, 0.025, 0.9, 6]} />
          <meshStandardMaterial color="#3a3a3a" roughness={0.7} />
        </mesh>
      ))}
      <mesh geometry={rope}>
        <meshStandardMaterial color="#f0c419" roughness={0.8} />
      </mesh>
    </group>
  );
}

export default function RoadProps() {
  // find the sharpest right-hand bends for the 右カーブ signs
  const rightBends = useMemo(() => {
    const res: number[] = [];
    const N = 240;
    const turns: number[] = [];
    for (let i = 0; i < N; i++) {
      const t = i / N;
      const a = curve.getTangentAt(t).setY(0).normalize();
      const b = curve.getTangentAt((t + 0.015) % 1).setY(0).normalize();
      const ang = Math.atan2(a.x * b.z - a.z * b.x, a.x * b.x + a.z * b.z);
      turns.push(ang);
    }
    for (let i = 0; i < N; i++) {
      const v = turns[i];
      // right turn = heading rotating clockwise (ang > 0 in this convention)
      if (v > 0.12 && v >= turns[(i - 1 + N) % N] && v >= turns[(i + 1) % N]) {
        res.push(((i / N) - 0.035 + 1) % 1);
      }
    }
    return res.slice(0, 5);
  }, []);

  return (
    <group>
      {rightBends.map((t, i) => (
        <CurveSign key={i} t={t} />
      ))}
      <CurveMirror t={0.17} lateral={-(EDGE + 1.0)} />
      <CurveMirror t={0.47} lateral={EDGE + 1.2} />
      <CurveMirror t={0.78} lateral={-(EDGE + 1.0)} />
      <Delineators />
      <RopeBarrier t0={0.05} t1={0.09} />
      <RopeBarrier t0={0.6} t1={0.64} />
    </group>
  );
}
