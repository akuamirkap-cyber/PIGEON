import { mk } from "../game/sprites";
import { forestRockAtlas, forestVistaUrl, paintForestCover, paintForestPlant, paintForestRoots, paintForestTree, preloadForest } from "./forest";
import { crystalVistaUrl, hollowAccent, hollowRockAtlas, paintHollowCover, paintHollowDecor, preloadHollow } from "./hollow";

/**
 * The arenas of the side-view team deathmatch: tile maps built from a few primitives on the left half and mirrored,
 * so both teams get exactly the same ground. Also: painting the terrain pixel by pixel (sand ripples, sandstone strata,
 * crystal veins), a light layer for everything that glows, the parallax backdrops, the minimap, and the navigation grid
 * + pathfinding the bots fly by.
 */
export const AT = 8;
export const AIR = 0;
export const DIRT = 1;
export const ROCK = 2;
export const PLAT = 3;
export const solidT = (t: number) => t === DIRT || t === ROCK;

export type PickKind = "uzi" | "shotgun" | "rifle" | "sniper" | "rpg" | "flame" | "saw" | "magnum" | "e11" | "katana" | "saber" | "axe" | "tesla" | "portal" | "health" | "nades";

export interface Theme {
  id: string; name: string; sub: string;
  sky: [string, string, string];
  far: string; mid: string; near: string;
  dirt: [string, string, string];
  top: [string, string];
  rock: [string, string, string];
  plank: [string, string];
  wall: [string, string];
  cave: [string, string];
  dark: number; rain: number; fog: number; sun: boolean;
  decor: "desert" | "city" | "cave" | "jungle" | "brawl";
  weather: "sand" | "rain" | "spores" | "jungle";
  amb: { wind: number; birds: number; night: number; drone: number; water: number };
}
export interface Decor { x: number; y: number; k: string; v: number; h: number }
/** things that move: flags in the wind, swinging lanterns, waterfalls, crystal/sun light beams, shimmering pools, braziers, geysers, rotating Anthem Shaper ring */
export interface Dyn { k: "flag" | "lantern" | "fall" | "beamlight" | "pool" | "brazier" | "geyser" | "shaperring"; x: number; y: number; h: number; t: number; v: number; width?: number }
export interface River { x: number; y: number; w: number; depth: number; flow: number }
export interface Light { x: number; y: number; r: number; col: string; pulse: number }
export interface ArenaMap {
  id: number; theme: Theme; w: number; h: number; grid: Uint8Array; bg: Uint8Array;
  spawns: { x: number; y: number }[][];
  picks: { x: number; y: number; kind: PickKind }[];
  lights: Light[]; decor: Decor[]; dyn: Dyn[]; rivers: River[];
  nav: Uint8Array; nw: number; nh: number;
  /** hiding places (press E beside one) and the trapdoors over the rat-tunnels */
  hides: HideSpot[]; hatches: { x: number; y: number }[];
}
/** a hiding place: where its foot stands, what it is, and the box of cover (half-width w, height h) that stops a bullet */
export interface HideSpot { x: number; y: number; k: string; name: string; w: number; h: number }
export const HIDE_INFO: Record<string, { name: string; w: number; h: number; light: string }> = {
  grove: { name: "JAMUR RAKSASA", w: 12, h: 17, light: "#5ff0c8" },
  niche: { name: "CERUK BATU", w: 12, h: 17, light: "#ffc870" },
  cart: { name: "GEROBAK TAMBANG", w: 11, h: 14, light: "#ffc870" },
  crates: { name: "PETI TAMBANG", w: 12, h: 15, light: "#ffc870" },
  fern: { name: "SEMAK PAKIS", w: 12, h: 14, light: "#6bffb0" },
  boulder: { name: "BONGKAHAN KRISTAL", w: 12, h: 16, light: "#5ff0e0" },
  monstera: { name: "SEMAK MONSTERA", w: 13, h: 16, light: "#7aff8e" },
  blossom: { name: "RUMPUN ANGGREK", w: 13, h: 16, light: "#ff8ad8" },
  banyan: { name: "AKAR POHON PURBA", w: 13, h: 18, light: "#ffe27a" },
};

export const hsh = (x: number, y: number, s = 0) => {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
/** smooth value noise */
function vn(x: number, y: number, s: number) {
  const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  const a = hsh(xi, yi, s), b = hsh(xi + 1, yi, s), c = hsh(xi, yi + 1, s), d = hsh(xi + 1, yi + 1, s);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
const ss = (a: number, b: number, x: number) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const rgb = (h: string): number[] => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const mixc = (a: number[], b: number[], k: number) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const haloC: Record<string, HTMLCanvasElement> = {};
/** a soft round glow of one colour */
export function halo(col: string): HTMLCanvasElement {
  if (!haloC[col]) {
    const [c, g] = mk(32, 32), gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, col);
    gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 32, 32);
    haloC[col] = c;
  }
  return haloC[col];
}

const THEMES: Theme[] = [
  {
    id: "desert", name: "GURUN BADAI", sub: "Badai pasir, bunker berkarung pasir, reruntuhan kuno & menara tengah",
    sky: ["#a5653c", "#dc9a5c", "#f4d29a"], far: "#c48452", mid: "#d29b64", near: "#b77846",
    dirt: ["#d8a35c", "#c58d4a", "#7a4c26"], top: ["#efc27c", "#ffe2ac"], rock: ["#b47a48", "#cf9660", "#6e4222"],
    plank: ["#9a6a3a", "#5e3e20"], wall: ["#7c6b58", "#665646"], cave: ["#6a4a2e", "#56402a"],
    dark: 0, rain: 0, fog: 0, sun: true, decor: "desert", weather: "sand",
    amb: { wind: 0.85, birds: 0.08, night: 0, drone: 0, water: 0 },
  },
  {
    id: "city", name: "KOTA RUNTUH", sub: "Gedung hancur, jalan layang & kereta bawah tanah",
    sky: ["#231d3a", "#5e4466", "#e6865a"], far: "#3b3150", mid: "#2b2338", near: "#1d1828",
    dirt: ["#4b4549", "#58525a", "#211d26"], top: ["#77777e", "#9a9aa2"], rock: ["#7b7473", "#968f8b", "#3d3939"],
    plank: ["#8f5e3c", "#5a3a24"], wall: ["#3b3539", "#322c30"], cave: ["#2b2830", "#35313a"],
    dark: 0.32, rain: 1, fog: 0.25, sun: false, decor: "city", weather: "rain",
    amb: { wind: 0.45, birds: 0, night: 0.3, drone: 0.2, water: 0 },
  },
  {
    id: "cave", name: "GOA KRISTAL AGUNG", sub: "Crystal Sanctum: pesona gua kristal klasik dipadukan dengan kemegahan Hollow Earth. Batu amethyst, rune kuno, kristal sian-ungu, lentera hangat, sungai jernih dan air terjun berkabut.",
    sky: ["#121329", "#25213f", "#4c5271"], far: "#403d66", mid: "#292541", near: "#18162e",
    dirt: ["#47405d", "#655971", "#242037"], top: ["#3e7f6d", "#9ed7bd"], rock: ["#56506b", "#8a7f9c", "#28223c"],
    plank: ["#8a7150", "#4d4337"], wall: ["#2c253e", "#1b192e"], cave: ["#231e36", "#342a49"],
    dark: 0.19, rain: 0, fog: 0, sun: false, decor: "cave", weather: "spores",
    amb: { wind: 0.13, birds: 0, night: 0.07, drone: 0.24, water: 0.76 },
  },
  {
    id: "jungle", name: "HUTAN BASTION", sub: "Rimba purba berkanopi lebat, sungai pirus berpantulan dan riak, air terjun lebar berkabut, akar beringin raksasa, tebing batu basah & flora tropis. Terbang menembus air terjun untuk mengisi jetpack!",
    sky: ["#52796e", "#8eafa0", "#d5d6ac"], far: "#63897b", mid: "#345a44", near: "#1b3c30",
    dirt: ["#4b5039", "#697052", "#263b33"], top: ["#487844", "#a5b867"], rock: ["#4c6254", "#87917a", "#253c34"],
    plank: ["#79613b", "#423e29"], wall: ["#344c3b", "#21392f"], cave: ["#182e29", "#2b4738"],
    dark: 0.05, rain: 0, fog: 0, sun: false, decor: "jungle", weather: "jungle",
    amb: { wind: 0.24, birds: 0.85, night: 0, drone: 0.06, water: 0.78 },
  },
  {
    id: "brawl", name: "BRAWL LANGIT", sub: "Satu pulau tempur terapung, dua pijakan samping dan dua tingkat platform. Jatuh dari pulau mengurangi 35 HP sebelum kembali ke arena.",
    sky: ["#182552", "#6178ac", "#bed6dc"], far: "#475c88", mid: "#7193b4", near: "#a7c2c9",
    dirt: ["#567b80", "#7cb5b4", "#355663"], top: ["#8be8d8", "#d2fff2"], rock: ["#525a87", "#838db5", "#2c345e"],
    plank: ["#b8ddec", "#567d9d"], wall: ["#485579", "#667797"], cave: ["#343b65", "#525a80"],
    dark: 0, rain: 0, fog: 0, sun: false, decor: "brawl", weather: "spores",
    amb: { wind: 0.22, birds: 0.08, night: 0.04, drone: 0.02, water: 0 },
  },
];
export const MAP_INFO = THEMES.map((t) => ({ name: t.name, sub: t.sub }));

class Bld {
  g: Uint8Array;
  bg: Uint8Array;
  picks: [number, number, PickKind][] = [];
  cpicks: [number, PickKind][] = [];
  spawns: [number, number][] = [];
  lights: [number, number, number, string, number][] = [];
  decs: [number, number, string][] = [];
  dyns: [number, number, Dyn["k"]][] = [];
  waters: [number, number, number, number][] = [];
  hides: [number, number, string][] = [];
  hatches: [number, number][] = [];
  constructor(public w: number, public h: number) {
    this.g = new Uint8Array(w * h);
    this.bg = new Uint8Array(w * h);
  }
  in(x: number, y: number) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  set(x: number, y: number, t: number) { if (this.in(x, y)) this.g[y * this.w + x] = t; }
  get(x: number, y: number) { return this.in(x, y) ? this.g[y * this.w + x] : ROCK; }
  rect(x: number, y: number, w: number, h: number, t: number) { for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) this.set(xx, yy, t); }
  carve(x: number, y: number, w: number, h: number) { this.rect(x, y, w, h, AIR); }
  wall(x: number, y: number, w: number, h: number, v = 1) { for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (this.in(xx, yy)) this.bg[yy * this.w + xx] = v; }
  plat(x: number, y: number, w: number) { for (let xx = x; xx < x + w; xx++) if (this.get(xx, y) === AIR) this.set(xx, y, PLAT); }
  ell(cx: number, cy: number, rx: number, ry: number, t: number) {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1) this.set(x, y, t);
      }
  }
  line(x0: number, y0: number, x1: number, y1: number, r: number, t: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 2) + 1;
    for (let i = 0; i <= n; i++) { const k = i / n; this.ell(x0 + (x1 - x0) * k, y0 + (y1 - y0) * k, r, r, t); }
  }
  ground(f: (x: number) => number, x0: number, x1: number) { for (let x = x0; x < x1; x++) for (let y = Math.max(0, f(x)); y < this.h; y++) this.set(x, y, DIRT); }
  pick(x: number, y: number, k: PickKind) { this.picks.push([x, y, k]); }
  /** one pick in the very middle of the map (not mirrored): the prize both teams fight over */
  pickC(y: number, k: PickKind) { this.cpicks.push([y, k]); }
  spawn(x: number, y: number) { this.spawns.push([x, y]); }
  light(x: number, y: number, r: number, col: string, pulse = 0.04) { this.lights.push([x, y, r, col, pulse]); }
  dec(x: number, y: number, k: string) { this.decs.push([x, y, k]); }
  dyn(x: number, y: number, k: Dyn["k"]) { this.dyns.push([x, y, k]); }
  river(x: number, y: number, w: number, depth: number) {
    this.waters.push([x, y, w, depth]);
    for (let xx = x; xx < x + w; xx++) {
      const edge = Math.min(xx - x, x + w - 1 - xx);
      const bed = Math.min(depth, 2 + Math.floor(edge * 0.65));
      this.carve(xx, y - 1, 1, bed + 1);
      this.rect(xx, y + bed, 1, 2, ROCK);
    }
  }
  /** a hiding place on the floor at row y: stand beside it and press E to slip in behind its cover */
  hide(x: number, y: number, k: string) { this.hides.push([x, y, k]); }
  /** a trapdoor of planks (two tiles wide) over the shaft of a rat-tunnel: S drops through it */
  hatch(x: number, y: number) { this.plat(x, y, 2); this.hatches.push([x, y]); }
  mirror() {
    const W = this.w;
    for (let y = 0; y < this.h; y++)
      for (let x = 0; x < W >> 1; x++) {
        this.g[y * W + W - 1 - x] = this.g[y * W + x];
        this.bg[y * W + W - 1 - x] = this.bg[y * W + x];
      }
  }
}

/** desert outpost in a sandstorm: a sandbagged bunker each side, a tunnel all the way across under the dunes, ruins, a fortified tower */
function desert(): Bld {
  const b = new Bld(200, 90);
  const hgt = (x: number) => {
    const w = ss(30, 40, x) * (1 - ss(74, 84, x));
    return Math.round(62 - 2 * ss(30, 84, x) + w * (2 * Math.sin((x - 30) * 0.17) - 2.4 * Math.sin((x - 30) * 0.06 + 0.8)));
  };
  b.ground(hgt, 0, 100);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  // the bunker: roof, front wall with a door and a slit, a gallery inside
  b.rect(2, 44, 26, 2, ROCK);
  b.rect(26, 44, 2, 12, ROCK);
  b.rect(2, 41, 2, 3, ROCK);
  b.rect(23, 41, 5, 3, ROCK);
  b.carve(2, 46, 24, 16);
  b.wall(2, 46, 24, 16);
  b.plat(2, 53, 17);
  b.carve(26, 48, 2, 5);
  // the tunnel: down through the bunker floor, all the way to the other side
  b.carve(8, 62, 4, 4);
  b.wall(8, 62, 4, 4, 2);
  b.carve(4, 66, 96, 6);
  b.wall(4, 66, 96, 6, 2);
  for (const sx of [44, 72]) {
    const top = hgt(sx) - 1;
    b.carve(sx, top, 4, 66 - top);
    b.wall(sx, top + 1, 4, 65 - top, 2);
  }
  // a floating rock and scaffolding over the dunes
  b.ell(60, 34, 9, 2.6, ROCK);
  b.ell(60, 33, 7, 1.6, DIRT);
  b.plat(46, 46, 8);
  b.plat(68, 48, 8);
  b.plat(80, 38, 9);
  b.plat(32, 52, 6);
  // the tower in the middle: two floors, doors on both sides, a window you can step out of
  b.rect(92, 26, 8, 36, ROCK);
  b.carve(94, 30, 6, 30);
  b.wall(94, 30, 6, 30);
  b.carve(92, 52, 2, 8);
  b.carve(92, 39, 2, 6);
  b.plat(94, 45, 6);
  b.rect(92, 23, 2, 3, ROCK);
  b.rect(96, 23, 2, 3, ROCK);
  // sandbags on the bunker roof and the team's flag, crates and barrels, palms, the columns of an older city
  for (const x of [6, 12, 18]) b.dec(x, 44, "sandbag");
  b.dyn(25, 41, "flag");
  b.dec(15, 62, "crate"); b.dec(21, 62, "barrel"); b.dec(23, 62, "barrel"); b.dec(5, 53, "crate");
  b.dec(36, hgt(36), "palm"); b.dec(65, hgt(65), "palm"); b.dec(39, hgt(39), "sandbag");
  b.dec(54, hgt(54), "pillar"); b.dec(57, hgt(57), "pillar"); b.dec(79, hgt(79), "pillar");
  b.dec(58, 32, "pillar");
  b.dec(84, hgt(84), "crate"); b.dec(88, hgt(88), "sandbag");
  b.pick(60, 26, "sniper"); b.pick(97, 40, "rpg"); b.pick(84, 30, "magnum"); b.pick(50, 40, "rifle"); b.pick(72, 42, "shotgun");
  b.pick(38, 40, "uzi"); b.pick(56, 66, "health"); b.pick(30, 40, "nades"); b.pick(12, 48, "flame"); b.pick(84, 66, "saw"); b.pick(30, 66, "e11");
  b.pickC(24, "saber");
  b.hide(22, 72, "crates"); b.hide(64, 72, "crates");
  for (const x of [5, 9, 13, 17]) b.spawn(x, 47);
  for (const x of [6, 15, 21]) b.spawn(x, 56);
  return b;
}

/** ruined city at dusk, in the rain: a house each side, a bombed-out block, an overpass, the subway underneath */
function city(): Bld {
  const b = new Bld(200, 90);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  b.rect(2, 64, 98, 22, DIRT);
  b.carve(2, 70, 98, 6);
  b.wall(2, 70, 98, 6);
  for (const x of [30, 66]) { b.carve(x, 64, 4, 6); b.wall(x, 64, 4, 6); b.plat(x, 67, 4); }
  b.rect(2, 40, 20, 2, ROCK);
  b.rect(20, 42, 2, 12, ROCK);
  b.carve(2, 42, 18, 22);
  b.wall(2, 42, 18, 22);
  b.rect(2, 52, 13, 1, ROCK);
  b.plat(15, 52, 5);
  b.carve(20, 47, 2, 5);
  b.rect(2, 37, 2, 3, ROCK);
  b.rect(17, 37, 5, 3, ROCK);
  b.rect(36, 30, 2, 26, ROCK);
  b.rect(36, 30, 9, 2, ROCK);
  b.rect(50, 38, 2, 16, ROCK);
  b.wall(38, 32, 12, 32);
  b.rect(38, 44, 9, 1, ROCK);
  b.plat(47, 44, 3);
  b.plat(38, 54, 12);
  b.carve(36, 39, 2, 5);
  b.plat(56, 46, 44);
  b.rect(68, 47, 2, 17, ROCK);
  b.rect(86, 47, 2, 17, ROCK);
  b.plat(74, 34, 8);
  b.rect(77, 35, 1, 11, ROCK);
  b.rect(96, 60, 4, 4, ROCK);
  b.ell(57, 64, 4, 1.6, DIRT);
  b.ell(80, 64, 3, 1.3, DIRT);
  b.dyn(18, 37, "flag");
  for (const [x, y] of [[26, 64], [58, 64], [92, 64]]) { b.dec(x, y, "lamp"); b.light(x + 0.5, y - 3.6, 66, "#ffd98a"); }
  b.light(10, 45, 52, "#ffcf7a"); b.light(10, 56, 52, "#ffcf7a"); b.light(44, 48, 44, "#ff9a5a");
  for (const x of [20, 50, 80]) b.light(x, 72, 56, "#bfe0ff");
  b.pick(64, 40, "rifle"); b.pick(77, 28, "sniper"); b.pick(97, 72, "rpg"); b.pick(44, 50, "shotgun"); b.pick(26, 58, "uzi");
  b.pick(48, 72, "health"); b.pick(90, 40, "nades"); b.pick(44, 36, "flame"); b.pick(98, 54, "magnum"); b.pick(16, 72, "saw"); b.pick(82, 58, "e11");
  b.pickC(58, "saber");
  b.hide(38, 76, "crates"); b.hide(72, 76, "crates");
  for (const x of [5, 9, 13]) b.spawn(x, 44);
  b.spawn(17, 44);
  for (const x of [6, 12, 18]) b.spawn(x, 56);
  return b;
}

/**
 * GOA KRISTAL AGUNG (264x112): a colossal subterranean crystal cathedral built for soaring jetpack & jump-pack battles —
 * vaulted sanctuary bastions, sweeping amethyst geode amphitheaters, a starlit upper sky-vault, a floating crystal altar in the
 * central nave framed by triple cascading waterfalls, deep sapphire lagoons, mine railway galleries, thermal geysers & rat-tunnels.
 */
function cave(): Bld {
  const b = new Bld(264, 112);
  b.rect(0, 0, 132, 112, DIRT);

  // 1) Sanctuary Spawn Bastion — lofty vaulted chamber + wide chiseled stone terrace
  b.ell(22, 57, 22, 19, AIR);
  b.ell(22, 39, 12, 5, AIR);
  b.rect(2, 76, 28, 5, DIRT);
  b.rect(4, 75, 23, 2, ROCK);

  // 2) Amethyst Geode Grand Amphitheater — huge open dome for vertical jetpack skirmishes
  b.ell(58, 52, 28, 20, AIR);
  b.ell(58, 34, 15, 7, AIR);

  // 3) Starlight Upper Crystal Sky-Vault — elevated crystalline observatory high under the roof
  b.ell(92, 27, 26, 17, AIR);
  b.ell(92, 14, 12, 5, AIR);

  // 4) Imperial Colonnade Gallery — vaulted mid-level hall between Amphitheater & Great Cathedral
  b.ell(94, 61, 20, 13, AIR);

  // 5) THE GRAND CRYSTAL CATHEDRAL — colossal 54-tile-wide, 78-tile-tall central mega-nave + sapphire lagoon
  b.ell(132, 55, 30, 26, AIR);
  b.ell(132, 28, 19, 14, AIR);
  b.ell(132, 15, 9, 5, AIR);
  b.ell(132, 87, 19, 10, AIR);

  // 6) Broad connecting airways & lower Emerald Lagoon Mine Gallery (wide & smooth for fast flight)
  b.line(27, 63, 41, 57, 4.8, AIR);   // Spawn Bastion -> Amphitheater main arch
  b.line(24, 52, 47, 44, 3.4, AIR);   // Spawn Bastion upper balcony -> Amphitheater cupola
  b.line(68, 46, 78, 32, 4.6, AIR);   // Amphitheater -> Starlight Sky-Vault
  b.line(108, 27, 122, 31, 4.8, AIR); // Starlight Sky-Vault -> Great Cathedral upper spire
  b.line(107, 34, 111, 56, 3.8, AIR); // Sky-Vault vertical skylight shaft -> Cathedral upper balcony
  b.line(74, 63, 114, 62, 4.8, AIR);  // Amphitheater -> Imperial Colonnade -> Great Cathedral
  b.line(27, 71, 33, 90, 3.9, AIR);   // Spawn Bastion -> Lower Mine Gallery
  b.line(33, 89, 132, 90, 6.2, AIR);
  b.ell(56, 88, 16, 10, AIR);
  b.ell(92, 88, 17, 10, AIR);
  b.line(92, 84, 92, 70, 3.7, AIR);   // Thermal chimney linking Mine Grotto II up to Colonnade
  b.line(126, 75, 132, 90, 4.8, AIR); // Central Cathedral waterfall chasm into deep lagoon

  // Sculpted ancient stonework floors, floating crystal sky-altar & flanking cathedral balconies
  b.ell(58, 74, 13, 2.2, ROCK);       // Amphitheater carved floor stage
  b.ell(92, 40, 12, 2.1, ROCK);       // Sky-Vault carved observatory floor
  b.rect(86, 71, 14, 2, ROCK);        // Colonnade carved bridge deck
  b.ell(132, 47, 7.5, 2.2, ROCK);     // Floating Crystal Sky-Altar in the heart of the Cathedral!
  b.ell(132, 46, 6, 1.3, DIRT);       // Luminous emerald moss crown atop the floating altar
  b.rect(111, 51, 8, 2, ROCK);        // Upper Cathedral choir balcony
  b.rect(112, 76, 10, 3, ROCK);       // Lower Cathedral sanctuary balcony flanking the great lagoon
  b.ell(37, 46, 5, 2.5, ROCK);        // Mineral bastion keystone
  b.rect(0, 0, 2, 112, ROCK);
  b.rect(0, 0, 132, 2, ROCK);
  b.rect(0, 107, 132, 5, ROCK);

  b.river(32, 73, 10, 4);
  b.river(61, 72, 14, 4);
  b.river(86, 38, 13, 3);
  b.river(32, 94, 100, 5);
  // Dry crystal islets preserve cover and pickup access above the current.
  for (const [x, y, w, h] of [[63, 72, 4, 6], [94, 38, 4, 5], [51, 95, 6, 6], [61, 95, 4, 6], [73, 95, 4, 6], [97, 95, 6, 6], [117, 95, 4, 6]]) {
    b.rect(x, y, w, h, ROCK); b.rect(x, y, w, 1, DIRT);
  }

  // ── JALAN TIKUS: 3 secret crawl-height rat-tunnels per side (2 tiles tall, glowing emerald mouths) ──
  // 1) Spawn terrace trapdoor -> secret den under bastion -> emerges into lower mine ramp
  b.carve(7, 72, 2, 15);
  b.carve(9, 85, 22, 2);
  b.carve(15, 84, 5, 3);
  // 2) Colonnade floor trapdoor -> crawl passage beneath stonework -> emerges behind lower Cathedral terrace
  b.carve(78, 65, 2, 11);
  b.carve(80, 74, 32, 2);
  b.carve(96, 73, 5, 3);
  // 3) Secret tunnel beneath Amphitheater stage -> links Amphitheater floor to lower mid gallery
  b.carve(55, 69, 2, 11);
  b.carve(57, 78, 22, 2);
  b.carve(64, 77, 5, 3);
  b.hatch(7, 75);
  b.hatch(78, 67);
  b.hatch(55, 72);

  // Tactical low stone parapets (crouch [S] behind them for instant cover)
  b.rect(84, 70, 2, 1, ROCK);
  b.rect(101, 70, 2, 1, ROCK);
  b.rect(120, 75, 2, 1, ROCK);

  // Reinforced iron-and-timber suspension bridges & multi-tier jetpack perches
  b.plat(8, 65, 9);                   // Spawn bastion upper gallery
  b.plat(20, 61, 7);                  // Spawn lookout ledge
  b.plat(41, 63, 11);                 // Amphitheater west walkway
  b.plat(53, 54, 12);                 // Amphitheater grand center bridge
  b.plat(66, 61, 10);                 // Amphitheater east walkway
  b.plat(49, 45, 9);                  // Amphitheater high cupola perch
  b.plat(76, 31, 11);                 // Sky-Vault west terrace
  b.plat(88, 23, 11);                 // Sky-Vault high starlight bridge
  b.plat(101, 31, 10);                // Sky-Vault east bridge
  b.plat(88, 60, 12);                 // Colonnade elevated catwalk
  b.plat(119, 51, 5);                 // Cathedral upper choir bridge toward floating altar
  b.plat(114, 63, 13);                // Cathedral grand mid-nave suspension bridge
  b.plat(122, 76, 10);                // Cathedral grand waterfall bridge over sapphire lagoon
  b.plat(121, 33, 11);                // Cathedral high spire sky-bridge
  b.plat(50, 88, 10);                 // Emerald Mine Grotto bridge

  // Warm swinging sanctuary lanterns along bridges & vaulted ceilings
  for (const [x, y] of [[12, 61], [25, 65], [46, 59], [59, 50], [70, 57], [81, 27], [93, 19], [105, 27], [94, 56], [116, 47], [120, 59], [55, 84], [92, 84]]) {
    b.dyn(x, y, "lantern");
    b.light(x, y, 72, "#ffd07a", 0.08);
  }
  // Ambient deep crystal cathedral aura lights so the cavernous vaults shimmer with rich colour
  for (const [x, y, r, col] of [
    [18, 56, 86, "#5ff0e0"], [58, 50, 110, "#b86bff"], [92, 24, 108, "#5fe4ff"],
    [94, 62, 88, "#5ff0c8"], [126, 36, 115, "#ffe07a"], [124, 60, 115, "#68f0ff"],
    [56, 90, 84, "#56ffb0"], [92, 90, 88, "#6fd4ff"],
  ] as [number, number, number, string][]) {
    b.light(x, y, r, col, 0.1);
  }

  // Team banners, dwarven/imperial crystal braziers & roaring thermal geysers
  b.dyn(11, 75, "flag");
  b.dyn(23, 75, "brazier");
  b.dyn(62, 72, "brazier");
  b.dyn(96, 38, "brazier");
  b.dyn(113, 76, "brazier");
  b.dyn(114, 51, "brazier");
  b.dyn(129, 45, "brazier");
  // Geysers launch players skyward across the tall cathedral chambers!
  b.dyn(33, 94, "geyser");            // Mine shaft entrance -> up toward bastion/amphitheater
  b.dyn(51, 72, "geyser");            // Amphitheater floor -> up to cupola
  b.dyn(92, 95, "geyser");            // Sapphire mine grotto -> straight up chimney to colonnade!
  b.dyn(109, 66, "geyser");           // Cathedral entrance -> launches up to floating altar & spire!

  // Ornate ancient Gothic stone arches, glowing rune monoliths, carved rune pillars, lotus lilies & colossal crystal clusters
  b.dec(15, 75, "gotharch");
  b.dec(59, 72, "gotharch");
  b.dec(92, 38, "gotharch");
  b.dec(115, 76, "gotharch");
  b.dec(21, 75, "monolith");
  b.dec(65, 72, "monolith");
  b.dec(86, 38, "monolith");
  b.dec(128, 45, "monolith");
  b.dec(48, 72, "runepillar");
  b.dec(90, 71, "runepillar");
  b.dec(62, 95, "runepillar");
  b.dec(102, 95, "runepillar");
  b.dec(53, 72, "bigcrystal");
  b.dec(68, 72, "bigcrystal");
  b.dec(83, 38, "bigcrystal");
  b.dec(100, 38, "bigcrystal");
  b.dec(113, 51, "bigcrystal");
  b.dec(48, 95, "bigcrystal");
  b.dec(84, 95, "bigcrystal");
  b.dec(120, 95, "bigcrystal");
  // Secondary geode gardens give the long cave more depth without blocking routes.
  for (const [x, y] of [[28, 75], [39, 72], [76, 72], [105, 71], [110, 76], [126, 76], [36, 95], [69, 95], [110, 95], [77, 38], [106, 38]]) {
    b.dec(x, y, "bigcrystal");
    b.light(x, y - 3, 54, x % 2 ? "#ad83ff" : "#65e8e3", 0.16);
  }
  for (const [x, y] of [[35, 59], [72, 34], [108, 24], [119, 13]]) b.dec(x, y, "ceilcrystal");
  for (const [x, y] of [[14, 75], [44, 72], [70, 72], [88, 38], [101, 71], [45, 96], [85, 96], [116, 76]]) b.dec(x, y, "mycotree");
  for (const [x, y] of [[10, 75], [22, 75], [49, 72], [67, 72], [86, 38], [99, 38], [97, 71], [57, 95], [102, 95]]) b.dec(x, y, "cavefern");
  // Glowing crystal chandeliers & hanging sanctuary censers from the high vaulted domes
  b.dec(18, 46, "ceilcrystal");
  b.dec(58, 34, "ceilcrystal");
  b.dec(92, 9, "ceilcrystal");
  b.dec(80, 16, "ceilcrystal");
  b.dec(94, 52, "ceilcrystal");
  b.dec(130, 10, "ceilcrystal");
  b.dec(53, 36, "censer");
  b.dec(87, 10, "censer");
  b.dec(98, 10, "censer");
  b.dec(127, 11, "censer");

  // TEMPAT SEMBUNYI [E]: rich natural & ancient cover spots across all tiers
  b.hide(18, 75, "crates");
  b.hide(49, 72, "grove");
  b.hide(64, 72, "boulder");
  b.hide(95, 71, "niche");
  b.hide(53, 95, "crates");
  b.hide(74, 95, "cart");
  b.hide(98, 95, "grove");
  b.hide(95, 38, "fern");
  b.hide(117, 76, "boulder");

  // Faint emerald glow & signposts marking the secret rat-tunnel hatches
  for (const [x, y] of [[8, 76], [30, 86], [79, 68], [111, 75], [56, 73], [78, 79]]) b.light(x, y, 32, "#9dffb0", 0.22);
  b.dec(9, 75, "ratsign");
  b.dec(80, 67, "ratsign");
  b.dec(57, 72, "ratsign");

  // Dramatic multi-hued volumetric cathedral god-rays slanting down through the vaulted chambers
  b.dyn(17, 48, "beamlight");
  b.dyn(56, 36, "beamlight");
  b.dyn(63, 38, "beamlight");
  b.dyn(90, 11, "beamlight");
  b.dyn(98, 15, "beamlight");
  b.dyn(124, 18, "beamlight");
  b.dyn(130, 14, "beamlight");

  // Balanced pickups across every chamber (refill ammo, medkits, grenades & blade shrines)
  b.pick(92, 18, "sniper"); b.pick(125, 28, "rpg"); b.pick(59, 49, "magnum"); b.pick(58, 66, "rifle"); b.pick(72, 89, "shotgun");
  b.pick(22, 57, "uzi"); b.pick(56, 84, "health"); b.pick(115, 46, "health"); b.pick(46, 58, "nades"); b.pick(104, 89, "nades");
  b.pick(118, 58, "flame"); b.pick(80, 26, "saw"); b.pick(93, 55, "e11"); b.pick(12, 60, "katana"); b.pick(105, 26, "tesla"); b.pick(116, 70, "axe");
  b.pickC(41, "saber"); // gleaming lightsaber shrine atop the floating Crystal Sky-Altar!

  for (const x of [6, 10, 14, 18, 22]) b.spawn(x, 66);
  b.spawn(25, 66);
  return b;
}

/**
 * HUTAN BASTION (256x108): Anthem-inspired vertical tropical rainforest sanctuary!
 * Sun-drenched emerald canyon floor, soaring moss-crowned floating sky-islands, 5 cascading waterfalls that cool & recharge
 * jetpacks as you fly through them, an ancient rotating Shaper Ring centerpiece, sunlit golden canopy god-rays, a bioluminescent
 * subterranean root-river grotto, thermal updraft geysers, secret banyan-root rat-tunnels, and 12 rich botanical flora species!
 */
function jungle(): Bld {
  const b = new Bld(256, 108);
  // Gently terraced lush rainforest valley floor dipping into crystal lily ponds & the Great Bastion Lagoon
  const hgt = (x: number) => {
    if (x < 30) return 68;
    if (x >= 114) return 75;
    const u = (x - 30) / 84;
    return Math.round(70 + 3 * u + 2.2 * Math.sin((x - 30) * 0.14) - 1.6 * Math.cos((x - 30) * 0.075));
  };
  b.ground(hgt, 0, 128);
  b.rect(0, 0, 2, 108, ROCK);
  b.rect(0, 103, 128, 5, ROCK);

  // An open forest bank replaces the brick bunker; the old upper route is a root-covered rock shelf.
  b.ell(5, 50, 10, 3.2, ROCK);
  b.ell(5, 48.5, 9, 1.9, DIRT);
  b.carve(2, 52, 22, 16);
  b.rect(4, 68, 22, 2, DIRT);
  b.plat(4, 60, 13);

  // 2) FLOATING BASTION SKY-ISLANDS (Anthem signature vertical jetpack playground!)
  // Island A: Emerald Canopy Cliff-Isle (mid-west, pours a sparkling waterfall into the valley lily pond!)
  b.ell(54, 46, 12, 3.2, ROCK);
  b.ell(54, 44, 11, 2.0, DIRT);
  // Island B: High Sunlit Shaper Eyrie (soaring high in the azure sky with ancient relic & cascading veil waterfall!)
  b.ell(84, 28, 13, 3.3, ROCK);
  b.ell(84, 26, 12, 2.0, DIRT);
  // Island C: Upper Bastion Stepping Crag (between Spawn roof and Island A for effortless parkour)
  b.ell(35, 36, 7, 2.3, ROCK);
  b.ell(35, 35, 6, 1.5, DIRT);
  // Island D: Central Shaper Sky-Sanctuary (grand floating mossy altar crowned by the rotating Shaper Ring + Great Falls!)
  b.ell(128, 41, 14, 3.8, ROCK);
  b.ell(128, 38, 13, 2.2, DIRT);
  b.rect(121, 37, 14, 1, DIRT);       // level grass terrace atop the central Sky-Sanctuary

  // 3) Mid-Valley Mossy Shaper Ruin Pavilion (ancient stone colonnade wrapped in roots & flowering lianas)
  b.ell(99, 52, 10, 2.5, ROCK);
  b.ell(99, 50.5, 9, 1.7, DIRT);
  b.plat(94, 61, 10);
  // Level mossy terraces along the valley for giant trees, Rafflesia blooms & hiding thickets
  b.rect(45, 70, 16, 3, DIRT); b.carve(45, 64, 16, 6);
  b.rect(72, 72, 14, 3, DIRT); b.carve(72, 65, 14, 7);
  b.rect(93, 72, 13, 3, DIRT); b.carve(93, 64, 13, 8);
  b.rect(112, 74, 8, 3, ROCK);        // carved temple embankment overlooking the Great Bastion Lagoon
  b.carve(120, 62, 8, 13);            // wide turquoise Great Bastion Lagoon basin at center (y=75)

  // 4) Bioluminescent Subterranean Root-River Grotto (magical sunlit sinkhole river beneath the jungle floor!)
  b.carve(26, 84, 102, 8);
  b.wall(26, 84, 102, 8, 2);
  b.ell(56, 87, 12, 6, AIR); b.wall(44, 81, 24, 12, 2);
  b.ell(96, 87, 13, 6, AIR); b.wall(83, 81, 26, 12, 2);
  b.ell(128, 87, 15, 7, AIR); b.wall(113, 80, 15, 14, 2);
  // Sunlit sinkhole shafts plunging from the jungle floor down into the Root-River Grotto!
  for (const sx of [27, 86]) {
    const top = hgt(sx) - 2;
    b.carve(sx, top, 5, 86 - top);
    b.wall(sx, top + 2, 5, 84 - top, 2);
    b.plat(sx, top + 7, 5);
  }
  // Secret crawl-height Banyan Root Tunnels (JALAN TIKUS — press [S] on mossy hatches!)
  b.carve(8, 66, 2, 14);
  b.carve(10, 78, 28, 2);
  b.carve(18, 77, 5, 3);
  b.hatch(8, 68);
  b.carve(70, 68, 2, 11);
  b.carve(72, 77, 14, 2);
  b.hatch(70, 71);
  // Tactical low mossy ruin walls for crouch cover
  b.rect(68, hgt(68) - 1, 2, 1, ROCK);
  b.rect(110, hgt(110) - 1, 2, 1, ROCK);

  b.river(33, 70, 36, 6);
  b.river(75, 73, 31, 5);
  b.river(113, 75, 15, 6);
  b.river(29, 89, 99, 4);
  // Small vegetated islands interrupt the current without interrupting jetpack routes.
  b.rect(46, 69, 5, 8, ROCK); b.rect(46, 69, 5, 1, DIRT);
  b.rect(96, 72, 5, 7, ROCK); b.rect(96, 72, 5, 1, DIRT);

  // 5) Woven Jungle Timber & Vine Canopy Bridges connecting cliffs, trees & floating islands
  b.plat(29, 57, 9);
  b.plat(68, 42, 9);
  b.plat(65, 58, 10);
  b.plat(100, 35, 11);
  b.plat(109, 53, 10);
  b.plat(119, 64, 9);                 // grand suspension bridge right across the Great Bastion Falls!
  b.plat(118, 24, 10);                // sky-high canopy bridge above the Shaper Ring!
  b.plat(51, 88, 9);                  // grotto river bridge

  // 6) Anthem Shaper Centerpiece, Braziers, Lanterns, Sunbeams & Thermal Wind-Geysers
  b.dyn(12, 49, "flag");
  b.dyn(22, 68, "brazier");
  b.dyn(89, 25, "brazier");
  b.dyn(119, 74, "brazier");
  b.dyn(123, 37, "brazier");
  // Warm amber firefly lanterns along canopy bridges & the subterranean root-river grotto
  for (const [x, y] of [[12, 55], [33, 54], [70, 55], [99, 56], [114, 50], [56, 82], [96, 82], [122, 82]]) {
    b.dyn(x, y, "lantern");
    b.light(x, y, 64, "#ffe08a", 0.08);
  }
  // Thermal Bastion Wind/Water Geysers launching players high into the sunlit canopy!
  b.dyn(29, 92, "geyser");
  b.dyn(62, 72, "geyser");            // valley floor updraft -> launches to Island A & B!
  b.dyn(88, 92, "geyser");
  b.dyn(113, 74, "geyser");           // lagoon terrace updraft -> launches up to the Central Shaper Sanctuary!
  // Golden morning sunbeams pouring diagonally through the forest canopy & into the sinkholes!
  for (const [x, y] of [[28, 8], [52, 6], [76, 8], [104, 6], [122, 4], [39, 66], [79, 68]]) b.dyn(x, y, "beamlight");

  // 7) EXTRAORDINARY DIVERSITY OF FLORA & ANCIENT SHAPER RELICS!
  // Towering Ancient Emergent Canopy Trees & Mossy Banyan Trees
  b.dec(5, 48, "canopytree");
  b.dec(10, 68, "canopytree");
  b.dec(22, 68, "banyantree");
  b.dec(32, 71, "canopytree");
  b.dec(47, 69, "canopytree");
  b.dec(51, 43, "canopytree");
  b.dec(81, 25, "canopytree");
  b.dec(107, 73, "canopytree");
  b.dec(98, 50, "banyantree");
  b.dec(74, 72, "banyantree");
  b.dec(125, 37, "banyantree");
  b.dec(69, 72, "canopytree");
  b.dec(111, 74, "banyantree");
  // Prehistoric Giant Tree Ferns & Emerald Bamboo Groves
  b.dec(18, 49, "treefern");
  b.dec(35, 34, "treefern");
  b.dec(58, 43, "treefern");
  b.dec(89, 25, "treefern");
  b.dec(103, 50, "treefern");
  b.dec(58, 70, "bamboo");
  b.dec(84, 72, "bamboo");
  b.dec(104, 72, "bamboo");
  // Giant Exotic Rafflesia Sun-Blooms, Fiery Heliconia Bird-of-Paradise, Orchids & Bromeliads
  b.dec(52, 70, "rafflesia");
  b.dec(96, 72, "rafflesia");
  b.dec(121, 37, "rafflesia");
  b.dec(15, 49, "heliconia");
  b.dec(49, 43, "heliconia");
  b.dec(78, 25, "heliconia");
  b.dec(82, 72, "heliconia");
  b.dec(117, 74, "heliconia");
  b.dec(33, 34, "orchid");
  b.dec(56, 43, "orchid");
  b.dec(86, 25, "orchid");
  b.dec(94, 50, "orchid");
  b.dec(101, 72, "orchid");
  // Ancient Anthem Shaper Relic Obelisks (glowing cyan-gold geometric circuits wrapped in jungle vines)
  b.dec(16, 68, "wildfern");
  b.dec(55, 70, "wildfern");
  b.dec(84, 25, "shaperrelic");
  b.dec(116, 74, "shaperrelic");
  // Bioluminescent Root-River Grotto Mushrooms & Luminous Lotus Reeds
  b.dec(48, 93, "jungleshroom");
  b.dec(62, 93, "jungleshroom");
  b.dec(88, 93, "jungleshroom");
  b.dec(104, 93, "jungleshroom");
  b.dec(118, 94, "jungleshroom");
  b.dec(54, 70, "lotuspad");
  b.dec(119, 75, "lotuspad");
  b.dec(94, 93, "lotuspad");

  // 8) TEMPAT SEMBUNYI RIMBA [E]: giant Monstera bushes, exotic Orchid thickets, hollow Banyan roots & ferns
  b.hide(19, 68, "monstera");
  b.hide(49, 69, "monstera");
  b.hide(76, 72, "banyan");
  b.hide(99, 72, "blossom");
  b.hide(55, 43, "fern");
  b.hide(86, 25, "blossom");
  b.hide(54, 93, "grove");
  b.hide(98, 93, "monstera");
  // Rat-tunnel signposts & emerald glow
  for (const [x, y] of [[9, 69], [37, 79], [71, 72], [85, 78]]) b.light(x, y, 30, "#9dffb0", 0.2);
  b.dec(10, 68, "ratsign");
  b.dec(72, 71, "ratsign");

  // 9) Balanced Pickups across canopy islands, ruins & root-river grotto
  b.pick(84, 21, "sniper"); b.pick(123, 19, "rpg"); b.pick(54, 39, "magnum"); b.pick(99, 46, "rifle"); b.pick(74, 66, "shotgun");
  b.pick(33, 52, "uzi"); b.pick(55, 84, "health"); b.pick(114, 48, "health"); b.pick(35, 30, "nades"); b.pick(99, 57, "nades");
  b.pick(122, 59, "flame"); b.pick(72, 37, "saw"); b.pick(104, 30, "e11"); b.pick(12, 44, "katana"); b.pick(96, 86, "tesla"); b.pick(116, 68, "axe");
  b.pickC(32, "saber"); // Lightsaber shrine right beneath the rotating Anthem Shaper Ring!

  for (const x of [6, 10, 14, 18, 21]) b.spawn(x, 62);
  b.spawn(9, 54);
  return b;
}

/** A compact, symmetrical floating island with open air beneath every edge. */
function brawl(): Bld {
  const b = new Bld(96, 74);
  b.rect(27, 43, 21, 2, DIRT);
  b.rect(29, 45, 19, 2, ROCK);
  b.rect(31, 47, 17, 2, ROCK);
  b.rect(34, 49, 14, 2, ROCK);
  b.rect(38, 51, 10, 1, ROCK);
  b.plat(14, 34, 12);
  b.plat(31, 31, 12);
  b.plat(43, 25, 5);
  b.spawn(34, 38); b.spawn(39, 38); b.spawn(44, 38);
  b.pick(18, 32, "axe"); b.pick(35, 29, "saber"); b.pickC(23, "katana");
  return b;
}

const BUILDERS = [desert, city, cave, jungle, brawl];
const cache: ArenaMap[] = [];

export function getMap(id: number): ArenaMap {
  if (cache[id]) return cache[id];
  const b = BUILDERS[id](), theme = THEMES[id];
  b.mirror();
  const W = b.w, H = b.h, g = b.g;
  const tile = (x: number, y: number) => (x < 0 || y < 0 || x >= W || y >= H ? ROCK : g[y * W + x]);
  if (theme.decor === "cave") {
    // the back wall only hugs the rock: the big chambers open onto the deep cave behind them
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        if (solidT(tile(x, y))) continue;
        let near = false;
        for (let j = -1; j <= 1 && !near; j++) for (let i = -1; i <= 1; i++) if (solidT(tile(x + i, y + j))) { near = true; break; }
        b.bg[y * W + x] = near ? 2 : 0;
      }
  }
  const land = (tx: number, ty: number) => {
    for (let y = Math.max(0, ty); y < H - 1; y++) {
      const d = tile(tx, y + 1);
      if (tile(tx, y) === AIR && (solidT(d) || d === PLAT)) return (y + 1) * AT;
    }
    return ty * AT;
  };
  const mx = (x: number) => W - 1 - x;
  const picks: ArenaMap["picks"] = [];
  for (const [x, y, k] of b.picks) for (const xx of [x, mx(x)]) picks.push({ x: (xx + 0.5) * AT, y: land(xx, y), kind: k });
  for (const [y, k] of b.cpicks) picks.push({ x: (W >> 1) * AT, y: land(W >> 1, y), kind: k });
  const spawns: ArenaMap["spawns"] = [[], []];
  for (const [x, y] of b.spawns) {
    spawns[0].push({ x: (x + 0.5) * AT, y: land(x, y) });
    spawns[1].push({ x: (mx(x) + 0.5) * AT, y: land(mx(x), y) });
  }
  const lights: Light[] = [];
  const rivers: River[] = [];
  for (const [x, y, w, depth] of b.waters) {
    if (x + w === W / 2) rivers.push({ x: x * AT, y: y * AT, w: w * 2 * AT, depth: depth * AT, flow: 0.7 });
    else {
      rivers.push({ x: x * AT, y: y * AT, w: w * AT, depth: depth * AT, flow: 1 });
      rivers.push({ x: (W - x - w) * AT, y: y * AT, w: w * AT, depth: depth * AT, flow: -1 });
    }
  }
  for (const [x, y, r, col, pulse] of b.lights) for (const xx of [x, W - x]) lights.push({ x: xx * AT, y: y * AT, r, col, pulse });
  const decor: Decor[] = [], dyn: Dyn[] = [];
  for (const [x, y, k] of b.decs) for (const xx of [x, mx(x)]) decor.push({ x: (xx + 0.5) * AT, y: y * AT, k, v: hsh(xx, y, 9), h: 0 });
  for (const [x, y, k] of b.dyns) for (const xx of [x, mx(x)]) dyn.push({ k, x: (xx + 0.5) * AT, y: y * AT, h: 0, t: xx < W / 2 ? 0 : 1, v: hsh(xx, y, 4) });
  // level ground: where the floor (or the roof) is at one height across three tiles, a thing can stand with its whole foot on the rock
  const floorAt = (x: number, y0: number) => { for (let y = Math.max(1, y0); y < H - 1; y++) if (!solidT(tile(x, y)) && solidT(tile(x, y + 1))) return y + 1; return -1; };
  const ceilAt = (x: number, y0: number) => { for (let y = Math.min(H - 2, y0); y > 1; y--) if (!solidT(tile(x, y)) && solidT(tile(x, y - 1))) return y; return -1; };
  const flat = (tx: number, ty: number, roof = false): [number, number] | null => {
    for (let k = 0; k <= 5; k++)
      for (const sx of k ? (tx < W / 2 ? [-k, k] : [k, -k]) : [0]) {
        const x = tx + sx, f = roof ? ceilAt(x, ty + 4) : floorAt(x, ty - 4);
        if (f < 0 || Math.abs(f - ty) > 3) continue;
        if (roof ? ceilAt(x - 1, f + 2) === f && ceilAt(x + 1, f + 2) === f : floorAt(x - 1, f - 2) === f && floorAt(x + 1, f - 2) === f) return [x, f];
      }
    return null;
  };
  // the hiding places: each on level ground, each with a little light of its own
  const hides: HideSpot[] = [];
  for (const [x, y, k] of b.hides) for (const xx of [x, mx(x)]) {
    const at = flat(xx, y), info = HIDE_INFO[k];
    if (!at || !info) continue;
    hides.push({ x: (at[0] + 0.5) * AT, y: at[1] * AT, k, name: info.name, w: info.w, h: info.h });
    lights.push({ x: (at[0] + 0.5) * AT, y: at[1] * AT - 9, r: 46, col: info.light, pulse: 0.1 });
  }
  const hatches: { x: number; y: number }[] = [];
  for (const [x, y] of b.hatches) for (const xx of [x, mx(x) - 1]) hatches.push({ x: (xx + 1) * AT, y: y * AT });
  if (theme.decor === "cave") {
    // the great crystals, chandeliers, censers, gothic arches, monoliths & rune pillars: snapped to level ground/ceiling
    for (const d of decor) {
      const roof = d.k === "ceilcrystal" || d.k === "censer";
      if (!roof && !["bigcrystal", "runepillar", "monolith", "gotharch", "mycotree", "cavefern"].includes(d.k)) continue;
      const tx = Math.floor(d.x / AT), ty = Math.floor(d.y / AT);
      let at = flat(tx, ty, roof);
      if (!at) {
        const yy = roof ? ceilAt(tx, ty + 5) : floorAt(tx, Math.max(1, ty - 4));
        if (yy > 0 && Math.abs(yy - ty) < 22) at = [tx, yy];
      }
      if (!at) { d.k = "none"; continue; }
      d.x = (at[0] + 0.5) * AT; d.y = at[1] * AT;
      if (d.k === "censer") {
        d.h = 14 + Math.round(d.v * 14);
        lights.push({ x: d.x, y: d.y + d.h, r: 58, col: d.v > 0.5 ? "#ffe07a" : "#74f4ff", pulse: 0.15 });
        continue;
      }
      if (["bigcrystal", "ceilcrystal", "mycotree"].includes(d.k)) {
        let free = 0;
        const dir = roof ? 1 : -1;
        while (free < 32 && !solidT(tile(at[0], at[1] + (roof ? 0 : -1) + free * dir))) free++;
        d.h = Math.max(22, Math.min(d.k === "mycotree" ? (d.v < 0.4 ? 83 : 65) : 88, free * AT * (d.k === "mycotree" ? 0.63 : 0.6)));
      }
      const gem = hollowAccent(d.v);
      lights.push(
        roof ? { x: d.x, y: d.y + d.h * 0.45, r: 68, col: gem, pulse: 0.08 }
          : d.k === "bigcrystal" || d.k === "mycotree" ? { x: d.x, y: d.y - d.h * 0.5, r: 82, col: gem, pulse: 0.09 }
            : d.k === "monolith" ? { x: d.x, y: d.y - 28, r: 70, col: gem, pulse: 0.14 }
              : d.k === "gotharch" ? { x: d.x, y: d.y - 35, r: 64, col: gem, pulse: 0.12 }
                : { x: d.x, y: d.y - 16, r: 56, col: gem, pulse: 0.14 },
      );
    }
    for (const d of dyn) {
      const tx = Math.floor(d.x / AT), ty = Math.floor(d.y / AT);
      if (d.k === "geyser") {
        // on level ground, as tall as the space over it allows
        const at = flat(tx, ty);
        if (at) { d.x = (at[0] + 0.5) * AT; d.y = at[1] * AT; }
        let free = 0;
        while (free < 24 && !solidT(tile(Math.floor(d.x / AT), Math.floor(d.y / AT) - 1 - free))) free++;
        d.h = Math.max(40, Math.min(120, free * AT - 14));
        lights.push({ x: d.x, y: d.y - 6, r: 38, col: "#7fe8ff", pulse: 0.2 });
        continue;
      }
      if (d.k === "brazier") {
        const fy = floorAt(tx, Math.max(1, ty - 4));
        if (fy > 0) d.y = fy * AT;
        lights.push({ x: d.x, y: d.y - 10, r: 64, col: d.v > 0.5 ? "#d57dff" : "#5ff0e0", pulse: 0.15 });
      } else if (d.k === "flag") {
        const fy = floorAt(tx, Math.max(1, ty - 4));
        if (fy > 0) d.y = fy * AT;
      } else if (d.k === "beamlight") {
        const cy = ceilAt(tx, ty + 4);
        if (cy > 0) d.y = cy * AT;
        const fy = floorAt(tx, Math.floor(d.y / AT));
        d.h = fy > 0 ? (fy - Math.floor(d.y / AT)) * AT : 140;
      }
    }
    // the mine railway along the floor of the deep gallery & its iron-braced timber arches
    for (let x = 34; x < W - 34; x++) {
      if (Math.abs(x - (W >> 1)) < 16) continue;
      const f = floorAt(x, 86);
      if (rivers.some((r) => x * AT >= r.x && x * AT < r.x + r.w && f * AT > r.y)) continue;
      if (f > 0 && f < 100) decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "rail", v: 0, h: 0 });
    }
    for (const x0 of [41, 69, 80, 108]) for (const x of [x0, mx(x0)]) {
      const f = floorAt(x, 86);
      if (f < 0) continue;
      let c = f - 1;
      while (c > 0 && !solidT(tile(x, c))) c--;
      if (f - c < 14) decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "beam", v: 0, h: (f - c - 1) * AT });
    }
    // TRIPLE CATHEDRAL WATERFALLS + vast glowing sapphire lagoon beneath the floating crystal altar!
    const cx = W >> 1;
    // 1) Central cascade plunging from beneath the floating sky-altar into the deep sapphire lagoon
    let y0 = 50;
    while (y0 < H && solidT(tile(cx, y0))) y0++;
    let y1 = y0;
    while (y1 < H && !solidT(tile(cx, y1))) y1++;
    dyn.push({ k: "fall", x: cx * AT, y: y0 * AT, h: (y1 - y0) * AT, t: 0, v: 0 });
    dyn.push({ k: "geyser", x: cx * AT, y: y1 * AT, h: Math.max(80, Math.min(220, (y1 - y0) * AT - 24)), t: 0, v: 2 });
    dyn.push({ k: "pool", x: cx * AT, y: y1 * AT, h: 96, t: 0, v: 0.2 });
    lights.push({ x: cx * AT, y: y1 * AT - 5, r: 105, col: "#5ff0e0", pulse: 0.16 });
    for (let k = 0; k < 5; k++) lights.push({ x: cx * AT, y: y0 * AT + ((y1 - y0) * AT * (k + 0.5)) / 5, r: 66, col: "#6fe8ff", pulse: 0.13 });
    // 2) Twin symmetrical veil waterfalls streaming 78 tiles from the high cathedral dome down to the sapphire lagoon!
    for (const fx of [cx - 10, mx(cx - 10)]) {
      let sy0 = 14;
      while (sy0 < H && solidT(tile(fx, sy0))) sy0++;
      let sy1 = sy0;
      while (sy1 < H && !solidT(tile(fx, sy1))) sy1++;
      if (sy1 - sy0 > 18) {
        dyn.push({ k: "fall", x: (fx + 0.5) * AT, y: sy0 * AT, h: (sy1 - sy0) * AT, t: 0, v: 0.65 });
        for (let k = 0; k < 4; k++) lights.push({ x: (fx + 0.5) * AT, y: sy0 * AT + ((sy1 - sy0) * AT * (k + 0.5)) / 4, r: 52, col: "#86ecff", pulse: 0.12 });
      }
    }
    // Shimmering bioluminescent turquoise crystal pools across side basins & lower lagoons
    for (const [px, py0, pw] of [[58, 66, 44], [92, 32, 38], [56, 88, 46], [92, 88, 48]] as [number, number, number][]) {
      for (const xx of [px, mx(px)]) {
        const fy = floorAt(xx, py0);
        if (fy > 0) {
          dyn.push({ k: "pool", x: (xx + 0.5) * AT, y: fy * AT, h: pw, t: 0, v: hsh(xx, fy, 11) });
          lights.push({ x: (xx + 0.5) * AT, y: fy * AT - 4, r: 62, col: "#5ff0e0", pulse: 0.14 });
        }
      }
    }
    for (const d of dyn) if (d.k === "fall") {
      const river = rivers.find((r) => d.x > r.x && d.x < r.x + r.w && r.y > d.y && r.y <= d.y + d.h);
      if (river) d.h = river.y - d.y;
      d.width = Math.abs(d.x - cx * AT) < 10 ? 58 : 38;
    }
  }
  if (theme.decor === "jungle") {
    // Snap all hero Bastion botanical flora & Shaper relics cleanly onto level mossy terraces
    const JSNAP = new Set(["canopytree", "banyantree", "treefern", "bamboo", "rafflesia", "heliconia", "orchid", "shaperrelic", "jungleshroom", "lotuspad"]);
    for (const d of decor) {
      if (!JSNAP.has(d.k)) continue;
      const at = flat(Math.floor(d.x / AT), Math.floor(d.y / AT));
      if (at) { d.x = (at[0] + 0.5) * AT; d.y = at[1] * AT; }
      else { const fy = floorAt(Math.floor(d.x / AT), Math.max(1, Math.floor(d.y / AT) - 5)); if (fy > 0) d.y = fy * AT; else { d.k = "none"; continue; } }
      if (d.k === "shaperrelic") lights.push({ x: d.x, y: d.y - 18, r: 68, col: "#5ef4ff", pulse: 0.18 });
      else if (d.k === "rafflesia") lights.push({ x: d.x, y: d.y - 7, r: 46, col: "#ffd26a", pulse: 0.14 });
      else if (d.k === "jungleshroom") lights.push({ x: d.x, y: d.y - 8, r: 54, col: d.v < 0.5 ? "#54ffe0" : "#ffd668", pulse: 0.16 });
      else if (d.k === "lotuspad") lights.push({ x: d.x, y: d.y - 5, r: 42, col: "#82ffe8", pulse: 0.14 });
    }
    for (const d of decor) if (d.k === "lotuspad") {
      const water = rivers.find((r) => d.x > r.x && d.x < r.x + r.w && Math.abs(d.y - r.y) < r.depth + 10);
      if (water) d.y = water.y;
    }
    for (const d of dyn) {
      const tx = Math.floor(d.x / AT), ty = Math.floor(d.y / AT);
      if (d.k === "geyser") {
        const at = flat(tx, ty);
        if (at) { d.x = (at[0] + 0.5) * AT; d.y = at[1] * AT; }
        let free = 0;
        while (free < 28 && !solidT(tile(Math.floor(d.x / AT), Math.floor(d.y / AT) - 1 - free))) free++;
        d.h = Math.max(55, Math.min(155, free * AT - 10));
        lights.push({ x: d.x, y: d.y - 6, r: 44, col: "#88f8ff", pulse: 0.18 });
      } else if (d.k === "brazier") {
        const fy = floorAt(tx, Math.max(1, ty - 4));
        if (fy > 0) d.y = fy * AT;
        lights.push({ x: d.x, y: d.y - 10, r: 60, col: "#5ef4ff", pulse: 0.15 });
      } else if (d.k === "flag") {
        const fy = floorAt(tx, Math.max(1, ty - 4));
        if (fy > 0) d.y = fy * AT;
      } else if (d.k === "beamlight") {
        if (ty > 40) { const cy = ceilAt(tx, ty + 4); if (cy > 0) d.y = cy * AT; }
        const fy = floorAt(tx, Math.floor(d.y / AT) + 2);
        d.h = fy > 0 ? Math.min(340, (fy - Math.floor(d.y / AT)) * AT) : 220;
      }
    }
    // Iconic Rotating Ancient Anthem SHAPER RING hovering majestically over the Central Sky-Sanctuary!
    const cx = W >> 1;
    const altarY = floorAt(cx, 32);
    if (altarY > 0) {
      dyn.push({ k: "shaperring", x: cx * AT, y: (altarY - 9) * AT, h: 22, t: 0, v: 0.5 });
      lights.push({ x: cx * AT, y: (altarY - 9) * AT, r: 95, col: "#5ef4ff", pulse: 0.2 });
    }
    // 5 CASCADING BASTION WATERFALLS (fly through any waterfall to cool & recharge your Jetpack!) + Turquoise Lily Lagoons
    // 1) Central Great Bastion Falls plunging from under the Shaper Sky-Sanctuary into the Turquoise Sanctuary Lagoon
    let y0 = 42;
    while (y0 < H && solidT(tile(cx, y0))) y0++;
    let y1 = y0;
    while (y1 < H && !solidT(tile(cx, y1))) y1++;
    dyn.push({ k: "fall", x: cx * AT, y: y0 * AT, h: (y1 - y0) * AT, t: 0, v: 0 });
    dyn.push({ k: "geyser", x: cx * AT, y: y1 * AT, h: Math.max(90, Math.min(205, (y1 - y0) * AT - 12)), t: 0, v: 2 });
    dyn.push({ k: "pool", x: cx * AT, y: y1 * AT, h: 108, t: 0, v: 0.25 });
    lights.push({ x: cx * AT, y: y1 * AT - 5, r: 96, col: "#5ff8e8", pulse: 0.14 });
    // 2) Twin Canopy Cliff-Isle Waterfalls (x=59) & 3) Twin High Shaper-Eyrie Veil Waterfalls (x=76)
    for (const [fx0, topRow, poolW, veil] of [[59, 46, 52, 0.2], [75, 29, 44, 0.65]] as [number, number, number, number][]) {
      for (const fx of [fx0, mx(fx0)]) {
        let sy0 = topRow;
        while (sy0 < H && solidT(tile(fx, sy0))) sy0++;
        let sy1 = sy0;
        while (sy1 < H && !solidT(tile(fx, sy1))) sy1++;
        if (sy1 - sy0 > 12) {
          dyn.push({ k: "fall", x: (fx + 0.5) * AT, y: sy0 * AT, h: (sy1 - sy0) * AT, t: 0, v: veil });
          dyn.push({ k: "pool", x: (fx + 0.5) * AT, y: sy1 * AT, h: poolW, t: 0, v: hsh(fx, sy1, 13) });
          lights.push({ x: (fx + 0.5) * AT, y: sy1 * AT - 4, r: 62, col: "#5ff8e8", pulse: 0.14 });
        }
      }
    }
    // Bioluminescent emerald-turquoise lagoons inside the subterranean Root-River Grotto + central grotto basin
    dyn.push({ k: "pool", x: cx * AT, y: floorAt(cx, 86) * AT, h: 92, t: 0, v: 0.4 });
    lights.push({ x: cx * AT, y: floorAt(cx, 86) * AT - 4, r: 88, col: "#5ff8e8", pulse: 0.16 });
    for (const px of [56, 96]) {
      for (const xx of [px, mx(px)]) {
        const fy = floorAt(xx, 86);
        if (fy > 0) {
          dyn.push({ k: "pool", x: (xx + 0.5) * AT, y: fy * AT, h: 56, t: 0, v: hsh(xx, fy, 17) });
          lights.push({ x: (xx + 0.5) * AT, y: fy * AT - 4, r: 68, col: "#54ffe0", pulse: 0.16 });
        }
      }
    }
    for (const d of dyn) if (d.k === "fall") {
      const river = rivers.find((r) => d.x > r.x && d.x < r.x + r.w && r.y > d.y && r.y <= d.y + d.h);
      if (river) d.h = river.y - d.y;
      d.width = Math.abs(d.x - cx * AT) < 10 ? 56 : d.v > 0.4 ? 33 : 42;
    }
  }
  // scattered props on the surfaces (crystals, bioluminescent mushrooms, rich tropical Anthem jungle flora, hanging flowering vines!)
  for (let y = 2; y < H - 2; y++)
    for (let x = 3; x < W - 3; x++) {
      const t = tile(x, y), dn = tile(x, y + 1), up = tile(x, y - 1), q = hsh(x, y, 77);
      const gentle = (theme.decor === "cave" || theme.decor === "jungle") && (solidT(tile(x - 1, y + 1)) || solidT(tile(x - 1, y + 2))) && (solidT(tile(x + 1, y + 1)) || solidT(tile(x + 1, y + 2)));
      if (t === AIR && solidT(dn) && !solidT(tile(x - 1, y)) && !solidT(tile(x + 1, y)) && ((solidT(tile(x - 1, y + 1)) && solidT(tile(x + 1, y + 1))) || gentle)) {
        const px = (x + 0.5) * AT, py = (y + 1) * AT;
        if (decor.some((d) => d.k !== "rail" && Math.abs(d.x - px) < (d.k === "bigcrystal" || d.k === "runepillar" || d.k === "monolith" || d.k === "gotharch" || d.k === "canopytree" || d.k === "banyantree" || d.k === "shaperrelic" || d.k === "rafflesia" ? 20 : 11) && Math.abs(d.y - py) < 12)) continue;
        if (hides.some((h) => Math.abs(h.x - px) < 22 && Math.abs(h.y - py) < 12) || hatches.some((h) => Math.abs(h.x - px) < 14 && Math.abs(h.y - py) < 12)) continue;
        if (dyn.some((d) => (d.k === "flag" || d.k === "brazier" || d.k === "geyser") && Math.abs(d.x - px) < 16 && Math.abs(d.y - py) < 12)) continue;
        const k = hsh(x, y, 78);
        if (theme.decor === "desert" && q < 0.17) decor.push({ x: px, y: py, k: k < 0.28 ? "cactus" : k < 0.5 ? "rock" : k < 0.64 ? "bones" : "tuft", v: hsh(x, y, 5), h: 0 });
        else if (theme.decor === "city" && q < 0.12) decor.push({ x: px, y: py, k: k < 0.4 ? "rubble" : k < 0.6 ? "cone" : k < 0.8 ? "tire" : "weed", v: hsh(x, y, 5), h: 0 });
        else if (theme.decor === "cave" && q < 0.38 && !solidT(tile(x, y - 1)) && !solidT(tile(x, y - 2))) {
          const v = hsh(x, y, 5);
          const kind = k < 0.44 ? "crystal" : k < 0.68 ? "shroom" : k < 0.84 ? "glowlily" : k < 0.94 ? "stalagmite" : "rock";
          decor.push({ x: px, y: py, k: kind, v, h: 0 });
          if (kind === "crystal") lights.push({ x: px, y: py - 7, r: v > 0.5 ? 60 : 46, col: ["#5ff0e0", "#d57dff", "#6bffb0", "#ffd05a", "#ff72c0"][(v * 5) | 0], pulse: 0.18 });
          else if (kind === "shroom" && v > 0.35) lights.push({ x: px, y: py - 5, r: 32, col: v < 0.65 ? "#5ff0c8" : "#f070b8", pulse: 0.14 });
          else if (kind === "glowlily") lights.push({ x: px, y: py - 5, r: 36, col: v < 0.5 ? "#72f8ff" : "#ffe07a", pulse: 0.16 });
        } else if (theme.decor === "jungle" && q < 0.52 && !solidT(tile(x, y - 1)) && !solidT(tile(x, y - 2))) {
          // rich botanical undergrowth: grotto wears glowing mushrooms & lotus lilies; sunlit forest wears ferns, bromeliads, orchids, heliconias, bamboo & mossy boulders!
          const v = hsh(x, y, 5), grotto = y > 79;
          const kind = grotto
            ? (k < 0.38 ? "jungleshroom" : k < 0.62 ? "wildfern" : k < 0.8 ? "lotuspad" : k < 0.92 ? "orchid" : "mossrock")
            : (k < 0.24 ? "wildfern" : k < 0.44 ? "bromeliad" : k < 0.62 ? "orchid" : k < 0.76 ? "heliconia" : k < 0.86 ? "lotuspad" : k < 0.93 ? "jungleshroom" : "mossrock");
          decor.push({ x: px, y: py, k: kind, v, h: 0 });
          if (kind === "jungleshroom") lights.push({ x: px, y: py - 6, r: 38, col: v < 0.5 ? "#54ffe0" : "#ffd86b", pulse: 0.15 });
          else if (kind === "orchid" && grotto) lights.push({ x: px, y: py - 6, r: 30, col: "#ff86d8", pulse: 0.14 });
        }
      }
      if (theme.decor === "cave" && t === AIR && solidT(up) && !solidT(dn)) {
        if (q > 0.85 && !solidT(tile(x, y + 2))) decor.push({ x: (x + 0.5) * AT, y: y * AT, k: "stalag", v: hsh(x, y, 6), h: 0 });
        else if (q < 0.11 && !solidT(tile(x, y + 2)) && !solidT(tile(x, y + 3))) {
          const vh = 10 + Math.round(hsh(x, y, 19) * 18);
          decor.push({ x: (x + 0.5) * AT, y: y * AT, k: "vine", v: hsh(x, y, 21), h: vh });
        }
      } else if (theme.decor === "jungle" && t === AIR && solidT(up) && !solidT(dn) && q < 0.24 && !solidT(tile(x, y + 2)) && !solidT(tile(x, y + 3))) {
        // lush weeping tropical lianas studded with vibrant blossoms hanging beneath floating sky-islands, temple arches & grotto ceilings!
        const vh = 12 + Math.round(hsh(x, y, 19) * 22);
        decor.push({ x: (x + 0.5) * AT, y: y * AT, k: "flowervine", v: hsh(x, y, 21), h: vh });
      }
    }
  // navigation: 16px cells where a soldier fits standing (the cell and the one above it are clear)
  const nw = W >> 1, nh = H >> 1, open = new Uint8Array(nw * nh), nav = new Uint8Array(nw * nh);
  for (let cy = 0; cy < nh; cy++)
    for (let cx = 0; cx < nw; cx++) {
      let ok = 1;
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) if (solidT(tile(cx * 2 + dx, cy * 2 + dy))) ok = 0;
      open[cy * nw + cx] = ok;
    }
  for (let cy = 1; cy < nh; cy++) for (let cx = 0; cx < nw; cx++) nav[cy * nw + cx] = open[cy * nw + cx] && open[(cy - 1) * nw + cx] ? 1 : 0;
  const m: ArenaMap = { id, theme, w: W, h: H, grid: g, bg: b.bg, spawns, picks, lights, decor, dyn, rivers, nav, nw, nh, hides, hatches };
  cache[id] = m;
  return m;
}

export const tileAt = (m: ArenaMap, tx: number, ty: number) => (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h ? ROCK : m.grid[ty * m.w + tx]);
export const solidPx = (m: ArenaMap, x: number, y: number) => solidT(tileAt(m, Math.floor(x / AT), Math.floor(y / AT)));

// ───────────── pathfinding (BFS over the nav cells, then pulled tight) ─────────────
let prev = new Int32Array(0);
let queue = new Int32Array(0);
const D8 = [1, 0, -1, 0, 0, 1, 0, -1, 1, 1, -1, 1, 1, -1, -1, -1];

function navCell(m: ArenaMap, x: number, y: number): number {
  const cx = Math.max(0, Math.min(m.nw - 1, Math.floor(x / 16))), cy = Math.max(0, Math.min(m.nh - 1, Math.floor((y - 4) / 16)));
  if (m.nav[cy * m.nw + cx]) return cy * m.nw + cx;
  for (let r = 1; r <= 4; r++)
    for (let dy = -r; dy <= r; dy++)
      for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x2 = cx + dx, y2 = cy + dy;
        if (x2 >= 0 && y2 >= 0 && x2 < m.nw && y2 < m.nh && m.nav[y2 * m.nw + x2]) return y2 * m.nw + x2;
      }
  return -1;
}
function segClear(m: ArenaMap, x0: number, y0: number, x1: number, y1: number) {
  const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 6);
  for (let i = 1; i < n; i++) {
    const x = x0 + ((x1 - x0) * i) / n, y = y0 + ((y1 - y0) * i) / n;
    const cx = Math.floor(x / 16), cy = Math.floor((y - 4) / 16);
    if (cx < 0 || cy < 0 || cx >= m.nw || cy >= m.nh || !m.nav[cy * m.nw + cx]) return false;
  }
  return true;
}
/** a path for a flying soldier from feet (sx, sy) to (gx, gy): flat [x, y, x, y, ...] of feet positions, start excluded */
export function findPath(m: ArenaMap, sx: number, sy: number, gx: number, gy: number): number[] {
  const nw = m.nw, N = nw * m.nh, nav = m.nav;
  if (prev.length < N) { prev = new Int32Array(N); queue = new Int32Array(N); }
  const s = navCell(m, sx, sy), goal = navCell(m, gx, gy);
  if (s < 0 || goal < 0) return [];
  if (s === goal) return [gx, gy];
  prev.fill(-1, 0, N);
  let head = 0, tail = 0;
  queue[tail++] = s;
  prev[s] = s;
  let found = false;
  while (head < tail) {
    const cur = queue[head++];
    if (cur === goal) { found = true; break; }
    const cx = cur % nw, cy = (cur / nw) | 0;
    for (let d = 0; d < 16; d += 2) {
      const dx = D8[d], dy = D8[d + 1], nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= nw || ny >= m.nh) continue;
      const ni = ny * nw + nx;
      if (!nav[ni] || prev[ni] !== -1) continue;
      if (dx && dy && (!nav[cy * nw + nx] || !nav[ny * nw + cx])) continue;
      prev[ni] = cur;
      queue[tail++] = ni;
    }
  }
  if (!found) return [];
  const cells: number[] = [];
  for (let c = goal; c !== s; c = prev[c]) cells.push(c);
  cells.reverse();
  const pts: number[] = [];
  for (const c of cells) pts.push(((c % nw) + 0.5) * 16, (((c / nw) | 0) + 1) * 16 - 1);
  pts[pts.length - 2] = gx;
  pts[pts.length - 1] = gy;
  const out: number[] = [];
  let ax = sx, ay = sy, i = 0;
  while (i < pts.length) {
    let j = pts.length - 2;
    while (j > i && !segClear(m, ax, ay, pts[j], pts[j + 1])) j -= 2;
    out.push(pts[j], pts[j + 1]);
    ax = pts[j];
    ay = pts[j + 1];
    i = j + 2;
  }
  return out;
}

// ───────────── painting ─────────────
const CRYS = [
  ["#5ff0e0", "#dcfffb", "#187a82", "#34e0d0"],
  ["#d57dff", "#f7dcff", "#6526a0", "#b854ff"],
  ["#6bffb0", "#e2fff0", "#228252", "#3fe088"],
  ["#ffd05a", "#fff5cc", "#966016", "#ffb228"],
  ["#ff72c0", "#ffdcf0", "#982664", "#ff4ca8"],
];
type Ctx = CanvasRenderingContext2D;

const OUT = "#150d22";
/**
 * One crystal: a chunky six-sided prism - a shaft of even width whose last rows bevel into a flat, two-pixel tip (never a needle).
 * Lit from the left, shaded on the right, glowing softly from inside. dir 1 stands on the floor, -1 hangs from the roof.
 */
function prism(g: Ctx | null, eg: Ctx | null, bx: number, by: number, h: number, w: number, lean: number, pal: string[], dir = 1) {
  const cap = Math.max(2, Math.min(4, w - 1));
  for (let i = 0; i < h; i++) {
    const k = i < h - cap ? 0 : (i - (h - cap) + 1) / cap, ww = Math.max(2, w - Math.round(k * (w - 2)));
    const x0 = Math.round(bx + lean * i) - (ww >> 1), py = dir > 0 ? by - 1 - i : by + i;
    if (g) {
      const lit = Math.max(1, Math.round(ww * 0.34)), dark = ww >= 5 ? 2 : ww >= 3 ? 1 : 0;
      g.fillStyle = OUT; g.fillRect(x0 - 1, py, ww + 2, 1);
      g.fillStyle = pal[0]; g.fillRect(x0, py, ww, 1);
      g.fillStyle = pal[1]; g.fillRect(x0, py, lit, 1);
      if (dark) { g.fillStyle = pal[2]; g.fillRect(x0 + ww - dark, py, dark, 1); }
      // (the shoulder where the tip begins catches the light)
      if (i === h - cap - 1 && ww >= 3) { g.fillStyle = pal[1]; g.fillRect(x0, py, ww - 1, 1); }
    }
    if (eg) { eg.globalAlpha = 0.3; eg.fillStyle = pal[3]; eg.fillRect(x0, py, ww, 1); eg.globalAlpha = 1; }
  }
  if (g) {
    g.fillStyle = OUT; g.fillRect(Math.round(bx + lean * (h - 1)) - 1, dir > 0 ? by - 1 - h : by + h, 2, 1);
    g.fillStyle = "#ffffff"; g.fillRect(Math.round(bx + lean * (h >> 1)) - (w >> 1), dir > 0 ? by - 1 - (h >> 1) : by + (h >> 1), 1, 1);
  }
}

/** the crystals of a cluster, by size: [offset, height, width, lean] - the outer ones first, the tall one in the middle last */
const CLUSTERS: number[][][] = [
  [[-3, 5, 3, -0.18], [3, 6, 3, 0.16], [0, 9, 4, 0.02]],
  [[-6, 5, 3, -0.2], [6, 6, 3, 0.2], [-3, 9, 4, -0.1], [3, 10, 4, 0.08], [0, 14, 5, 0.02]],
  [[-9, 7, 4, -0.2], [9, 8, 4, 0.2], [-5, 13, 5, -0.1], [5, 15, 5, 0.09], [0, 21, 6, -0.02]],
];
/**
 * A cluster of crystals (size 0..2) growing out of a lump of rock whose foot is sunk into the ground - or into the roof (dir -1):
 * nothing floats and nothing sits on a dark strip. One soft, round glow around the whole cluster.
 */
function cluster(g: Ctx | null, eg: Ctx | null, x: number, y: number, pal: string[], size: number, T: Theme, dir = 1) {
  const set = CLUSTERS[size], hw = [5, 8, 12][size], H = set[set.length - 1][1];
  for (const [ox, h, w, lean] of set) prism(g, eg, x + ox, y + dir, h, w, lean, pal, dir);
  if (g)
    for (let i = -hw; i <= hw; i++) {
      const e = Math.abs(i) / hw, rise = e > 0.85 ? 0 : e > 0.5 ? 1 : 2, top = dir > 0 ? y - rise : y + rise - 1;
      g.fillStyle = "#2c2444";
      g.fillRect(x + i, dir > 0 ? y - rise : y - 2, 1, rise + 2);
      if (rise) { g.fillStyle = hsh(i, size, 61) < 0.5 ? "#4f4572" : "#5e5486"; g.fillRect(x + i, top, 1, 1); }
      if (hsh(i, size, 63) < 0.3) { g.fillStyle = T.top[hsh(i, size, 64) < 0.5 ? 0 : 1]; g.fillRect(x + i, top, 1, 1); }
    }
  if (eg) {
    const r = H * 0.95 + hw * 0.5, cy = y - dir * H * 0.42;
    eg.globalAlpha = 0.42; eg.drawImage(halo(pal[3]), x - r, cy - r, r * 2, r * 2);
    eg.globalAlpha = 0.28; eg.drawImage(halo(pal[1]), x - r * 0.45, cy - r * 0.45, r * 0.9, r * 0.9);
    eg.globalAlpha = 1;
  }
}

type Px = (c: string, x: number, y: number, w: number, h: number, a?: number) => void;
/** a clump of fern: fronds fanning out of one root, every one tipped with light */
function fernAt(R: Px, E: Px, cx: number, y: number, hgt: number, seed: number) {
  const fr: number[][] = [];
  for (let f = -3; f <= 3; f++) {
    const len = Math.max(3, hgt - Math.abs(f) * 2 + ((hsh(f, seed, 71) * 3) | 0));
    for (let j = 0; j < len; j++) fr.push([cx + Math.round(f * (0.45 + j * 0.22)), y - 1 - j, j === len - 1 ? 2 : (j + f + 8) % 2]);
  }
  for (const [px, py] of fr) R("#102a22", px - 1, py - 1, 3, 3);
  for (const [px, py, c] of fr) R(c === 2 ? "#b8ffe6" : c ? "#36b889" : "#2d8f68", px, py, 1, 1);
  for (const [px, py, c] of fr) if (c === 2) E("#8ef8d2", px, py, 1, 1);
}

/**
 * A hiding place, painted in two parts: 0 what stands behind whoever hides there (painted onto the arena), 1 the cover in front
 * of them (a sprite the game draws over the soldiers). With g null only what glows is painted, onto the light layer.
 */
function paintHide(g: Ctx | null, eg: Ctx | null, k: string, x: number, y: number, T: Theme, part: number) {
  if (T.decor === "jungle" && paintForestCover(g, k, x, y, part)) return;
  if (T.decor === "cave" && paintHollowCover(g, eg, k, x, y, part)) return;
  const R: Px = (c, px, py, w, h) => { if (g) { g.fillStyle = c; g.fillRect(Math.round(px), Math.round(py), w, h); } };
  const E: Px = (c, px, py, w, h, a = 0.7) => { if (eg) { eg.globalAlpha = a; eg.fillStyle = c; eg.fillRect(Math.round(px), Math.round(py), w, h); eg.globalAlpha = 1; } };
  const glow = (c: string, cx: number, cy: number, r: number, a: number) => { if (eg) { eg.globalAlpha = a; eg.drawImage(halo(c), cx - r, cy - r, r * 2, r * 2); eg.globalAlpha = 1; } };
  const K = "#16121a";
  /** a giant mushroom: a pale stem and a domed, spotted cap with glowing gills */
  const shroom = (cx: number, sh: number, hw: number, cap: string, hi: string, dk: string) => {
    const top = y - sh - 5, rows = [hw - 2, hw - 1, hw, hw, hw - 1];
    R(K, cx - 2, y - sh, 5, sh + 1); R("#d9d0bf", cx - 1, y - sh, 3, sh + 1); R("#a89f8f", cx + 1, y - sh, 1, sh + 1); R("#f4eee0", cx - 1, y - sh, 1, sh);
    rows.forEach((w2, r) => R(K, cx - w2 - 1, top + r - (r ? 0 : 1), w2 * 2 + 3, r ? 1 : 2));
    R(K, cx - hw + 1, top + 5, hw * 2 - 1, 1);
    rows.forEach((w2, r) => R(r === 4 ? "#f6ffe9" : r === 3 ? dk : cap, cx - w2, top + r, w2 * 2 + 1, 1));
    R(hi, cx - hw + 2, top, hw - 1, 1); R(hi, cx - hw + 1, top + 1, 2, 1);
    R("#ffffff", cx - 1, top + 1, 1, 1); R("#ffffff", cx + 2, top + 2, 2, 1); if (hw > 5) R("#ffffff", cx - 4, top + 2, 2, 1);
    R("#d9d0bf", cx - 1, top + 5, 3, 1);
    E(cap, cx - hw, top + 1, hw * 2 + 1, 3, 0.55); E("#f6ffe9", cx - hw + 1, top + 4, hw * 2 - 1, 1, 0.8);
    glow(cap, cx, top + 3, hw * 2.2, 0.38);
  };
  /** a wooden crate: boards, a diagonal brace, two nails */
  const crate = (cx: number, by: number, w: number, h: number) => {
    R(K, cx, by - h, w, h); R(T.plank[0], cx + 1, by - h + 1, w - 2, h - 2); R("rgba(255,255,255,0.22)", cx + 1, by - h + 1, w - 2, 1);
    R(T.plank[1], cx + 1, by - 2, w - 2, 1); R(T.plank[1], cx + 1, by - h + 1, 1, h - 2); R(T.plank[1], cx + w - 2, by - h + 1, 1, h - 2);
    for (let i = 2; i < h - 2; i++) R(T.plank[1], cx + 2 + Math.round(((i - 2) * (w - 5)) / Math.max(1, h - 5)), by - h + i, 1, 1);
    R("#9a9eb0", cx + 2, by - h + 2, 1, 1); R("#9a9eb0", cx + w - 3, by - 3, 1, 1);
  };
  switch (k) {
    case "grove":
      if (part === 0) { shroom(x - 9, 7, 5, "#e86cb8", "#ffd4ee", "#b0447f"); shroom(x + 9, 5, 4, "#74c2ff", "#d8f2ff", "#3f86c4"); }
      else { fernAt(R, E, x - 7, y, 8, 1); fernAt(R, E, x + 7, y, 7, 2); shroom(x, 10, 8, "#4ee8c2", "#ccfff2", "#249a82"); fernAt(R, E, x - 2, y, 5, 3); }
      break;
    case "niche":
      if (part === 0) {
        // the hollow in the rock behind: an arch of dressed stones around the dark, a rune of light over it
        R("#0b0814", x - 9, y - 16, 19, 16); R("#0b0814", x - 7, y - 18, 15, 2); R("#0b0814", x - 5, y - 19, 11, 1);
        R("#05040a", x - 6, y - 13, 13, 13);
        for (let i = 0; i < 8; i++) { R(i % 2 ? "#4c5170" : "#3c3d58", x - 11, y - 2 - i * 2, 2, 2); R(i % 2 ? "#3c3d58" : "#4c5170", x + 10, y - 2 - i * 2, 2, 2); }
        R("#4c5170", x - 9, y - 18, 2, 2); R("#3c3d58", x - 7, y - 20, 3, 2); R("#565c80", x - 4, y - 21, 9, 2); R("#3c3d58", x + 5, y - 20, 3, 2); R("#4c5170", x + 8, y - 18, 2, 2);
        R("#ffc870", x, y - 21, 1, 2); R("#ffc870", x - 1, y - 20, 3, 1); E("#ffc870", x, y - 21, 1, 2, 0.9); E("#ffc870", x - 1, y - 20, 3, 1, 0.9); glow("#ffc870", x + 0.5, y - 20, 7, 0.4);
      } else {
        // a parapet of stacked stones in front, a stalagmite post at either end, moss along the top
        R(K, x - 12, y - 10, 25, 11);
        for (let r = 0; r < 3; r++)
          for (let c = 0; c < 5; c++) {
            const bx = x - 11 + c * 6 - (r % 2 ? 3 : 0), by = y - 9 + r * 3, x0 = Math.max(x - 11, bx), x1 = Math.min(x + 12, bx + 5);
            if (x1 <= x0) continue;
            R(hsh(c, r, 81) < 0.5 ? T.rock[0] : "#5c6388", x0, by, x1 - x0, 2); R(T.rock[1], x0, by, x1 - x0, 1);
          }
        for (const sx of [-12, 11]) { R(K, x + sx - 1, y - 15, 4, 16); R(T.rock[0], x + sx, y - 14, 2, 15); R(T.rock[1], x + sx, y - 14, 1, 14); R(K, x + sx, y - 16, 2, 1); }
        for (let i = -11; i <= 11; i++) if (hsh(i, 3, 82) < 0.45) R(T.top[hsh(i, 3, 83) < 0.5 ? 0 : 1], x + i, y - 10, 1, 1);
      }
      break;
    case "cart":
      if (part === 0) {
        // the far wall of the cart, and the crystals heaped in it
        R(K, x - 10, y - 14, 21, 9); R("#1c1e28", x - 9, y - 13, 19, 8);
        prism(g, eg, x - 6, y - 12, 5, 3, -0.1, CRYS[0]); prism(g, eg, x + 5, y - 12, 6, 3, 0.12, CRYS[3]); prism(g, eg, x - 1, y - 12, 7, 4, 0.02, CRYS[1]);
        glow("#5ff0e0", x, y - 15, 12, 0.35);
      } else {
        R(K, x - 11, y - 12, 23, 9); R("#4c5162", x - 10, y - 11, 21, 7); R("#7a8298", x - 10, y - 11, 21, 1); R("#2e3240", x - 10, y - 5, 21, 1); R("#3a3f4e", x - 10, y - 8, 21, 1);
        for (const rx of [-8, -3, 2, 7]) R("#a8aec4", x + rx, y - 10, 1, 1);
        R("#23252f", x - 5, y - 4, 10, 3);
        for (const wx of [-9, 4]) { R(K, x + wx, y - 5, 5, 5); R("#3a3a44", x + wx + 1, y - 4, 3, 3); R("#b0b6ca", x + wx + 2, y - 3, 1, 1); }
        R(K, x + 9, y - 14, 4, 4); R("#ffd05a", x + 10, y - 13, 2, 2); E("#ffd05a", x + 10, y - 13, 2, 2, 0.9); glow("#ffd05a", x + 11, y - 12, 9, 0.5);
      }
      break;
    case "crates":
      if (part === 1) {
        crate(x - 12, y, 13, 12); crate(x, y, 12, 9); crate(x - 9, y - 12, 9, 6);
        R(K, x + 3, y - 14, 5, 5); R("#5a4a2a", x + 4, y - 13, 3, 1); R("#ffd27a", x + 4, y - 12, 3, 2); R("#fff6d8", x + 5, y - 12, 1, 1);
        E("#ffd27a", x + 4, y - 12, 3, 2, 0.9); glow("#ffc870", x + 5.5, y - 11, 9, 0.45);
      }
      break;
    case "fern":
      if (part === 0) { fernAt(R, E, x - 4, y, 13, 4); fernAt(R, E, x + 5, y, 12, 5); }
      else {
        fernAt(R, E, x - 8, y, 9, 6); fernAt(R, E, x + 8, y, 9, 7); fernAt(R, E, x, y, 11, 8);
        // a few buds of light among the fronds
        for (const [bx, by] of [[-6, 6], [4, 8], [9, 4], [-10, 3]]) { R("#fff2a0", x + bx, y - by, 1, 1); E("#fff2a0", x + bx, y - by, 1, 1, 0.9); }
        glow("#6bffb0", x, y - 6, 15, 0.3);
      }
      break;
    case "boulder":
      if (part === 1) {
        const prof = [5, 8, 10, 11, 12, 12, 12, 12, 12, 12, 12, 11, 11, 10];
        prof.forEach((w2, r) => R(K, x - w2 - 1, y - 14 + r, w2 * 2 + 2, 1));
        R(K, x - 5, y - 15, 10, 1);
        prof.forEach((w2, r) => {
          const py = y - 14 + r;
          R(r > 10 ? T.rock[2] : T.rock[0], x - w2, py, w2 * 2, 1);
          if (r < 9) R(T.rock[1], x - w2, py, Math.max(2, Math.round(w2 * (0.9 - r * 0.07))), 1);
          if (r > 2) R(T.rock[2], x + w2 - Math.min(5, r - 1), py, Math.min(5, r - 1), 1);
        });
        // cracks, and moss over the top
        R(T.rock[2], x - 3, y - 9, 1, 3); R(T.rock[2], x - 2, y - 6, 1, 2); R(T.rock[2], x + 4, y - 11, 1, 2);
        for (let i = -9; i <= 9; i++) if (hsh(i, 5, 84) < 0.6) R(T.top[hsh(i, 5, 85) < 0.5 ? 0 : 1], x + i, y - 14 + (Math.abs(i) > 7 ? 2 : Math.abs(i) > 4 ? 1 : 0), 1, 1 + (hsh(i, 5, 86) < 0.3 ? 1 : 0));
        prism(g, eg, x - 6, y - 12, 6, 4, -0.15, CRYS[0]); prism(g, eg, x + 6, y - 11, 5, 3, 0.14, CRYS[0]); prism(g, eg, x + 1, y - 13, 8, 4, 0.03, CRYS[0]);
        glow("#5ff0e0", x, y - 15, 13, 0.4);
      }
      break;
    case "monstera":
      // Giant lush split-leaf Monstera deliciosa bush accented with fiery scarlet-gold Heliconia bracts!
      if (part === 0) {
        fernAt(R, E, x - 6, y, 13, 11); fernAt(R, E, x + 6, y, 13, 12);
        R("#d62828", x - 3, y - 15, 2, 5); R("#ff9e1b", x - 2, y - 16, 2, 3);
        R("#d62828", x + 3, y - 14, 2, 4); R("#ffe04a", x + 3, y - 15, 2, 2);
      } else {
        const leaf = (cx: number, cy: number, rx: number, ry: number, c0: string, c1: string) => {
          R("#0d2618", cx - rx - 1, cy - ry - 1, rx * 2 + 3, ry * 2 + 3);
          R(c0, cx - rx, cy - ry, rx * 2 + 1, ry * 2 + 1);
          R(c1, cx - rx, cy - ry, rx + 1, ry);
          R("#b8ff7a", cx - rx + 1, cy - ry, Math.max(1, rx - 1), 1);
          // signature Monstera fenestration leaf slits!
          R("#0d2618", cx - rx + 1, cy, 2, 1); R("#0d2618", cx + rx - 2, cy - 1, 2, 1);
        };
        leaf(x - 8, y - 7, 5, 5, "#1d8c42", "#34c85a");
        leaf(x + 8, y - 7, 5, 5, "#197c3a", "#2eb852");
        leaf(x, y - 10, 6, 5, "#24a24a", "#52e068");
        leaf(x - 3, y - 4, 5, 3, "#1b843e", "#38cc5c");
        leaf(x + 4, y - 4, 5, 3, "#219646", "#4ce066");
        // vibrant coral-gold bird-of-paradise bloom peeking out
        R("#ff4238", x + 1, y - 15, 3, 2); R("#ffaa22", x + 2, y - 16, 3, 2); R("#fff066", x + 4, y - 17, 2, 1);
        E("#9aff7a", x - 1, y - 14, 2, 1, 0.7); glow("#7aff8e", x, y - 9, 14, 0.25);
      }
      break;
    case "blossom":
      // Exotic Bastion Orchid & Hibiscus flower thicket bursting with magenta, coral, turquoise & sun-gold blooms!
      if (part === 0) {
        fernAt(R, E, x - 5, y, 12, 15); fernAt(R, E, x + 5, y, 12, 16);
      } else {
        R("#0d2618", x - 13, y - 11, 27, 11); R("#0d2618", x - 10, y - 14, 21, 4);
        R("#18783c", x - 12, y - 10, 25, 10); R("#26a84e", x - 9, y - 13, 19, 8);
        R("#5ce26c", x - 8, y - 13, 14, 3); R("#9eff78", x - 6, y - 13, 8, 1);
        for (const [bx, by, c0, hi] of [
          [-8, 9, "#ff4ca8", "#ffd4ee"], [-2, 12, "#ff6b4a", "#ffe680"], [5, 11, "#c85eff", "#f4d8ff"],
          [9, 7, "#3ce8ff", "#e2ffff"], [-4, 5, "#ffc82e", "#fff9c8"], [3, 5, "#ff4ca8", "#ffffff"],
        ] as [number, number, string, string][]) {
          R("#0d2618", x + bx - 2, y - by - 2, 5, 5);
          R(c0, x + bx - 2, y - by - 1, 5, 3); R(c0, x + bx - 1, y - by - 2, 3, 5);
          R(hi, x + bx - 1, y - by - 1, 2, 2); R("#ffffff", x + bx, y - by, 1, 1);
          E(c0, x + bx - 1, y - by - 1, 3, 3, 0.65);
        }
        glow("#ff8ad8", x, y - 9, 15, 0.3);
      }
      break;
    case "banyan":
      // Ancient hollow Banyan root archway draped in emerald moss curtains & golden firefly blossoms!
      if (part === 0) {
        R("#0b1410", x - 9, y - 16, 19, 16); R("#060b08", x - 6, y - 13, 13, 13);
        R("#4c3220", x - 11, y - 17, 3, 17); R("#4c3220", x + 9, y - 17, 3, 17);
        R("#62422b", x - 9, y - 19, 19, 3);
      } else {
        // buttressed gnarled roots arching round the front + lush moss cap + golden orchid buds
        for (const sx of [-12, 9]) {
          R(K, x + sx - 1, y - 16, 5, 17); R("#5e3e28", x + sx, y - 15, 3, 16); R("#845a3c", x + sx, y - 15, 1, 14);
        }
        R(K, x - 11, y - 18, 23, 5); R("#68462e", x - 10, y - 17, 21, 3); R("#8e6242", x - 9, y - 17, 17, 1);
        R("#28b850", x - 10, y - 18, 21, 2); R("#96f86c", x - 8, y - 18, 14, 1);
        // curtain of hanging moss & roots across the front
        for (let i = -8; i <= 8; i += 3) {
          const l = 5 + ((Math.abs(i * 5) % 5));
          R(i % 2 === 0 ? "#28b850" : "#5e3e28", x + i, y - 14, 1, l);
          if (i % 2 === 0) { R("#ffe46b", x + i, y - 14 + l, 1, 2); E("#ffe46b", x + i, y - 14 + l, 1, 2, 0.85); }
        }
        R(K, x - 11, y - 6, 23, 6); R("#229848", x - 10, y - 5, 21, 5); R("#6ae86e", x - 9, y - 5, 16, 2);
        glow("#ffe27a", x, y - 11, 14, 0.3);
      }
      break;
  }
}

const hideC: Record<string, { c: HTMLCanvasElement; ox: number; oy: number }> = {};
/** the cover of a hiding place as a sprite: the game draws it over whoever is tucked in behind it */
export function hideSprite(k: string, T: Theme): { c: HTMLCanvasElement; ox: number; oy: number } {
  const key = T.id + k;
  if (!hideC[key]) {
    const [c, g] = mk(52, 40);
    paintHide(g, null, k, 26, 36, T, 1);
    hideC[key] = { c, ox: 26, oy: 36 };
  }
  return hideC[key];
}
/** the trapdoor over the shaft of a rat-tunnel: iron bands across the planks, a ring to lift it by, two studs of green light */
function hatchDraw(g: Ctx, eg: Ctx | null, x: number, y: number) {
  const R = (c: string, px: number, py: number, w: number, h: number) => { g.fillStyle = c; g.fillRect(px, py, w, h); };
  R("#3d4256", x - 8, y, 2, 3); R("#3d4256", x + 6, y, 2, 3); R("#a4aec6", x - 8, y, 2, 1); R("#a4aec6", x + 6, y, 2, 1);
  R("#16121a", x - 2, y + 1, 4, 2); R("#c9cdd9", x - 1, y + 1, 2, 1);
  for (const sx of [-5, 4]) { R("#9dffb0", x + sx, y + 1, 1, 1); if (eg) { eg.fillStyle = "#9dffb0"; eg.fillRect(x + sx, y + 1, 1, 1); } }
}


export function decorDraw(g: Ctx, eg: Ctx | null, d: Decor, T: Theme) {
  if (T.decor === "cave" && paintHollowDecor(g, eg, d)) return;
  if (T.decor === "jungle" && (d.k === "canopytree" || d.k === "banyantree")) {
    paintForestTree(g, d);
    return;
  }
  if (T.decor === "jungle" && paintForestPlant(g, eg, d)) return;
  const R = (c: string, x: number, y: number, w: number, h: number) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };
  const x = Math.round(d.x), y = Math.round(d.y), K = "#16121a";
  switch (d.k) {
    case "cactus": {
      const h = 9 + Math.round(d.v * 7);
      R(K, x - 2, y - h - 1, 5, h + 1); R("#3f7a3a", x - 1, y - h, 3, h); R("#5a9a4a", x - 1, y - h, 1, h); R("#2a5a2a", x + 1, y - h, 1, h);
      R(K, x - 5, y - h + 3, 4, 5); R("#3f7a3a", x - 4, y - h + 4, 2, 3); R(K, x + 2, y - h + 5, 4, 4); R("#3f7a3a", x + 3, y - h + 5, 2, 2);
      for (let i = 2; i < h; i += 3) R("#e9e2c8", x + (i % 2 ? -2 : 2), y - i, 1, 1);
      if (d.v > 0.55) { R("#ff6b8a", x, y - h - 2, 1, 2); R("#ffd84a", x, y - h - 1, 1, 1); }
      break;
    }
    case "rock": R(K, x - 5, y - 5, 10, 5); R(T.decor === "cave" ? "#6a6280" : "#a8885e", x - 4, y - 4, 8, 4); R(T.decor === "cave" ? "#8a82a0" : "#c9a676", x - 4, y - 4, 4, 1); R(T.decor === "cave" ? "#4a4258" : "#7a5c38", x + 1, y - 2, 3, 2); break;
    case "bones":
      R("#0a0a0f", x - 5, y - 4, 11, 4); R("#e9e2c8", x - 4, y - 3, 6, 2); R("#c9c0a0", x - 4, y - 2, 6, 1); R("#0a0a0f", x - 2, y - 3, 1, 1); R("#0a0a0f", x, y - 3, 1, 1);
      R("#e9e2c8", x - 6, y - 6, 2, 3); R("#e9e2c8", x + 2, y - 6, 2, 3); R("#e9e2c8", x + 3, y - 2, 3, 1);
      break;
    case "tuft": for (let i = 0; i < 5; i++) R(i % 2 ? "#b8a050" : "#d8c070", x - 2 + i, y - 2 - (i % 3), 1, 2 + (i % 3)); break;
    case "palm": {
      const h = 24 + Math.round(d.v * 10), lean = Math.round((d.v - 0.5) * 12), at = (i: number) => x + Math.round(lean * (i / h) * (i / h));
      for (let i = 0; i < h; i++) R(K, at(i) - 2, y - i - 1, 5, 1);
      for (let i = 0; i < h; i++) { const xx = at(i); R(i % 4 === 0 ? "#6a4826" : "#8e6438", xx - 1, y - i - 1, 3, 1); R("#b08452", xx - 1, y - i - 1, 1, 1); }
      const tx = at(h), ty = y - h;
      const fr: [number, number][] = [[-2.5, 1.1], [-1.9, 1.2], [-1.2, 0.8], [-0.45, 0.5], [0.45, 0.5], [1.2, 0.8], [1.9, 1.2], [2.5, 1.1]];
      for (const pass of [0, 1])
        for (const [a, dr] of fr)
          for (let j = 0; j < 12; j++) {
            const r = j * 1.2, fx = tx + Math.sin(a) * r, fy = ty - Math.cos(a) * r * 0.55 + j * j * 0.07 * dr;
            if (pass === 0) R(K, fx - 1, fy - 1, 3, 3);
            else R(j % 3 === 0 ? "#2c7231" : j % 3 === 1 ? "#4fa046" : "#6cc05a", fx, fy, j < 9 ? 2 : 1, 1);
          }
      R("#0a0a0f", tx - 3, ty, 7, 4); R("#5a3a1a", tx - 2, ty + 1, 2, 2); R("#6a4422", tx + 1, ty + 1, 2, 2);
      break;
    }
    case "sandbag":
      for (let r = 0; r < 2; r++)
        for (let k = 0; k < 3 - r; k++) {
          const bx = x - 9 + k * 6 + r * 3, by = y - 4 - r * 3;
          R(K, bx, by - 1, 7, 5); R("#c9aa76", bx + 1, by, 5, 3); R("#e4cb98", bx + 1, by, 5, 1); R("#9a7e52", bx + 1, by + 2, 5, 1); R("#9a7e52", bx + 3, by, 1, 3);
        }
      break;
    case "crate":
      R(K, x - 6, y - 11, 12, 11); R("#a87a48", x - 5, y - 10, 10, 9); R("#c8965a", x - 5, y - 10, 10, 1); R("#6e4c2a", x - 5, y - 2, 10, 1);
      for (let i = 0; i < 8; i++) R("#7a5430", x - 5 + i + 1, y - 9 + i, 1, 1);
      R("#7a5430", x - 5, y - 10, 1, 9); R("#7a5430", x + 4, y - 10, 1, 9);
      break;
    case "barrel":
      R(K, x - 4, y - 11, 9, 11); R("#5a6a7a", x - 3, y - 10, 7, 9); R("#8a9aaa", x - 2, y - 10, 1, 9); R("#2e3a46", x - 3, y - 8, 7, 1); R("#2e3a46", x - 3, y - 4, 7, 1);
      R("#9a5a2a", x + 1, y - 7, 2, 2); R("#e0483e", x - 1, y - 10, 3, 1);
      break;
    case "pillar": {
      const h = 12 + Math.round(d.v * 12);
      R(K, x - 5, y - 3, 11, 3); R(T.rock[1], x - 4, y - 2, 9, 2);
      R(K, x - 4, y - h, 9, h - 2); R(T.rock[0], x - 3, y - h + 1, 7, h - 3); R(T.rock[1], x - 3, y - h + 1, 1, h - 3); R(T.rock[2], x - 1, y - h + 1, 1, h - 3); R(T.rock[2], x + 2, y - h + 1, 1, h - 3);
      R(K, x - 4, y - h - 2, 3, 3); R(T.rock[0], x - 3, y - h - 1, 2, 2); R(K, x + 1, y - h - 1, 3, 2); R(T.rock[0], x + 2, y - h, 1, 1);
      break;
    }
    case "rubble": R(K, x - 4, y - 3, 9, 3); R("#7a7473", x - 3, y - 2, 3, 2); R("#968f8b", x, y - 3, 3, 3); R("#5a5458", x + 2, y - 1, 2, 1); break;
    case "cone": R(K, x - 3, y - 7, 6, 7); R("#f08a3c", x - 2, y - 6, 4, 6); R("#ffffff", x - 2, y - 4, 4, 1); R(K, x - 4, y - 1, 8, 1); break;
    case "tire": R(K, x - 4, y - 5, 8, 5); R("#2a2a30", x - 3, y - 4, 6, 3); R("#46464e", x - 1, y - 3, 2, 1); break;
    case "weed": for (let i = 0; i < 3; i++) R("#4a6a3a", x - 1 + i, y - 2 - i, 1, 2 + i); break;
    case "lamp":
      R(K, x - 1, y - 30, 3, 30); R("#4a4e5a", x, y - 30, 1, 30); R(K, x - 1, y - 31, 7, 3); R("#4a4e5a", x, y - 30, 5, 1); R("#ffe9a0", x + 3, y - 29, 3, 1);
      if (eg) { eg.fillStyle = "#ffe9a0"; eg.fillRect(x + 3, y - 29, 3, 1); eg.globalAlpha = 0.45; eg.drawImage(halo("#ffd98a"), x - 6, y - 38, 20, 20); eg.globalAlpha = 1; }
      break;
    case "crystal": cluster(g, eg, x, y, CRYS[(d.v * 5) | 0], d.v > 0.48 ? 1 : 0, T); break;
    case "bigcrystal": cluster(g, eg, x, y, CRYS[(d.v * 5) | 0], 2, T); break;
    case "ceilcrystal": cluster(g, eg, x, y, CRYS[(d.v * 5) | 0], d.v > 0.5 ? 2 : 1, T, -1); break;
    case "ratsign": {
      // a little signpost beside the hatch of a rat-tunnel: an arrow pointing down, glowing green
      R(K, x - 1, y - 9, 3, 9); R("#7a5a36", x, y - 9, 1, 9);
      R(K, x - 5, y - 16, 11, 8); R("#a67546", x - 4, y - 15, 9, 6); R("#c8965a", x - 4, y - 15, 9, 1); R("#5e3e22", x - 4, y - 10, 9, 1);
      R("#9dffb0", x, y - 14, 1, 3); R("#9dffb0", x - 1, y - 12, 3, 1); R("#9dffb0", x, y - 11, 1, 1);
      if (eg) { eg.fillStyle = "#9dffb0"; eg.fillRect(x, y - 14, 1, 3); eg.fillRect(x - 1, y - 12, 3, 1); eg.fillRect(x, y - 11, 1, 1); eg.globalAlpha = 0.4; eg.drawImage(halo("#9dffb0"), x - 8, y - 20, 16, 16); eg.globalAlpha = 1; }
      break;
    }
    case "runepillar": {
      const pal = CRYS[(d.v * 5) | 0], h = 24 + Math.round(d.v * 8);
      // ornate stepped plinth
      R(K, x - 7, y - 4, 15, 4); R("#3c3d58", x - 6, y - 3, 13, 3); R("#6a7096", x - 6, y - 3, 12, 1);
      // carved octagonal stone shaft
      R(K, x - 5, y - h, 11, h - 3); R("#34354e", x - 4, y - h + 1, 9, h - 4); R("#565c80", x - 4, y - h + 1, 2, h - 4); R("#201f34", x + 3, y - h + 1, 2, h - 4);
      // mossy temple capital + top crystal cap
      R(K, x - 7, y - h - 4, 15, 5); R("#4c5170", x - 6, y - h - 3, 13, 3); R("#8ef8d2", x - 5, y - h - 3, 6, 1); R("#36b889", x - 6, y - h - 2, 13, 1);
      prism(g, eg, x, y - h - 4, 7, 4, 0, pal);
      // glowing mystic runes etched vertically along the stone shaft
      for (let ry = y - h + 4; ry < y - 6; ry += 5) {
        R(pal[0], x - 1, ry, 3, 1); R(pal[1], x, ry + 1, 1, 2); R(pal[0], x - 1, ry + 2, 3, 1);
        if (eg) { eg.fillStyle = pal[1]; eg.fillRect(x - 1, ry, 3, 1); eg.fillRect(x, ry + 1, 1, 2); }
      }
      if (eg) { eg.globalAlpha = 0.45; eg.drawImage(halo(pal[3]), x - 18, y - h - 10, 36, h + 14); eg.globalAlpha = 1; }
      break;
    }
    case "gotharch": {
      // grand carved subterranean Gothic sanctuary arch with twin pilasters, pointed vault & glowing crystal keystone
      const pal = CRYS[(d.v * 5) | 0], W = 13, H = 34;
      for (const sx of [-W, W - 3]) {
        R(K, x + sx - 1, y - 24, 6, 24);
        R("#3a3e5c", x + sx, y - 23, 4, 23);
        R("#6e78a4", x + sx, y - 23, 1, 22);
        R("#23243a", x + sx + 3, y - 23, 1, 22);
        // carved stone plinth & capital with gold trim
        R("#565e84", x + sx - 1, y - 3, 6, 3); R("#9aa6d4", x + sx - 1, y - 3, 5, 1);
        R("#565e84", x + sx - 1, y - 25, 6, 3); R("#ffd86b", x + sx, y - 24, 4, 1);
        // tiny glowing rune slit on each column
        R(pal[1], x + sx + 1, y - 15, 2, 4);
        if (eg) { eg.fillStyle = pal[0]; eg.fillRect(x + sx + 1, y - 15, 2, 4); }
      }
      // pointed Gothic arch ribs meeting at the crown
      for (let i = 0; i <= 11; i++) {
        const k = i / 11, dx = Math.round((W - 1) * (1 - k * 0.88)), ay = y - 25 - Math.round(Math.pow(k, 0.78) * (H - 24));
        for (const sg of [-1, 1]) {
          const ax = x + sg * dx;
          R(K, ax - 2, ay - 2, 5, 4); R("#4c5378", ax - 1, ay - 1, 3, 2); R("#8e9ac8", ax - 1, ay - 1, 2, 1);
        }
      }
      // glowing golden-framed crystal keystone at apex + draping luminous moss
      R(K, x - 3, y - H - 4, 7, 7); R("#ffd86b", x - 2, y - H - 3, 5, 5); R(pal[0], x - 1, y - H - 2, 3, 3); R("#ffffff", x, y - H - 2, 1, 2);
      R("#34c492", x - 7, y - 27, 1, 4); R("#9affdc", x - 7, y - 23, 1, 1);
      R("#34c492", x + 8, y - 26, 1, 5); R("#9affdc", x + 8, y - 21, 1, 1);
      if (eg) {
        eg.fillStyle = pal[1]; eg.fillRect(x - 1, y - H - 2, 3, 3);
        eg.globalAlpha = 0.5; eg.drawImage(halo(pal[3]), x - 16, y - H - 14, 32, 28); eg.globalAlpha = 1;
      }
      break;
    }
    case "monolith": {
      // ancient Imperial-style crystal rune obelisk inlaid with gold filigree & crowned by a radiant floating gem
      const pal = CRYS[((d.v * 5) | 0) % 5], h = 30 + Math.round(d.v * 6);
      R(K, x - 8, y - 4, 17, 4); R("#444a6c", x - 7, y - 3, 15, 3); R("#8692c0", x - 7, y - 3, 14, 1);
      R("#ffd86b", x - 6, y - 4, 13, 1);
      R(K, x - 5, y - h, 11, h - 3); R("#2f3350", x - 4, y - h + 1, 9, h - 4);
      R("#5c6490", x - 4, y - h + 1, 2, h - 4); R("#1c1d32", x + 3, y - h + 1, 2, h - 4);
      // golden winged chevron + glowing sacred rune line
      R("#ffd86b", x - 4, y - h + 3, 9, 1); R("#fff2a8", x - 2, y - h + 2, 5, 1);
      for (let ry = y - h + 6; ry < y - 6; ry += 4) {
        R(pal[0], x - 1, ry, 3, 2); R("#ffffff", x, ry, 1, 1);
        if (eg) { eg.fillStyle = pal[1]; eg.fillRect(x - 1, ry, 3, 2); }
      }
      // floating radiant crystal diamond above the obelisk crown
      const cy = y - h - 7;
      R(K, x - 2, cy - 3, 5, 7); R(K, x - 3, cy - 1, 7, 3);
      R(pal[0], x - 2, cy - 1, 5, 3); R(pal[1], x - 1, cy - 2, 3, 5); R("#ffffff", x - 1, cy - 1, 2, 2);
      if (eg) {
        eg.fillStyle = "#ffffff"; eg.fillRect(x - 1, cy - 2, 3, 5);
        eg.globalAlpha = 0.58; eg.drawImage(halo(pal[3]), x - 18, cy - 16, 36, 36);
        eg.globalAlpha = 0.35; eg.drawImage(halo("#ffe07a"), x - 14, y - h - 2, 28, h);
        eg.globalAlpha = 1;
      }
      break;
    }
    case "glowlily": {
      // bioluminescent crystal-lotus flower blooming on emerald moss pads
      const c0 = d.v < 0.35 ? "#64f4ff" : d.v < 0.7 ? "#ffe06a" : "#f07aff";
      const hi = d.v < 0.35 ? "#e0ffff" : d.v < 0.7 ? "#fff9d2" : "#ffe2ff";
      R("#14382c", x - 5, y - 2, 11, 2); R("#34c492", x - 4, y - 2, 9, 1);
      R("#248a68", x, y - 6, 1, 4);
      R(K, x - 4, y - 9, 9, 4);
      R(c0, x - 3, y - 8, 7, 2); R(hi, x - 2, y - 9, 5, 2); R("#ffffff", x - 1, y - 8, 3, 1);
      if (eg) {
        eg.fillStyle = hi; eg.fillRect(x - 2, y - 9, 5, 3);
        eg.globalAlpha = 0.55; eg.drawImage(halo(c0), x - 11, y - 16, 22, 20); eg.globalAlpha = 1;
      }
      break;
    }
    case "censer": {
      // ancient wrought-iron cathedral chain suspending an ornate glowing crystal sanctuary censer
      const h = d.h || 18, c0 = d.v > 0.5 ? "#ffe07a" : "#6ef4ff";
      for (let i = 0; i < h; i += 2) { R("#161424", x - 1, y + i, 3, 2); R("#6e7698", x, y + i, 1, 1); }
      const by = y + h;
      R(K, x - 4, by, 9, 7); R("#c89020", x - 3, by + 1, 7, 1); R("#ffd86b", x - 2, by, 5, 1);
      R(c0, x - 2, by + 2, 5, 3); R("#ffffff", x - 1, by + 2, 3, 2);
      R("#c89020", x - 2, by + 5, 5, 1); R("#ffd86b", x, by + 6, 1, 2);
      if (eg) {
        eg.fillStyle = "#ffffff"; eg.fillRect(x - 2, by + 2, 5, 3);
        eg.globalAlpha = 0.62; eg.drawImage(halo(c0), x - 16, by - 12, 32, 32); eg.globalAlpha = 1;
      }
      break;
    }
    case "vine": {
      const h = d.h || 14, pal = CRYS[(d.v * 5) | 0];
      for (let i = 0; i < h; i++) {
        const sx = x + Math.round(Math.sin(i * 0.45 + d.v * 6) * 1.5);
        R("#183c30", sx, y + i, 2, 1);
        R(i % 3 === 0 ? "#4ed89f" : "#2d8f68", sx, y + i, 1, 1);
        if (i > 3 && i % 5 === 0) {
          const leaf = i % 10 === 0 ? -1 : 1;
          R("#36b889", sx + leaf, y + i, 2, 1);
          R(pal[1], sx + leaf, y + i + 1, 1, 1);
          if (eg) { eg.fillStyle = pal[0]; eg.fillRect(sx + leaf, y + i + 1, 1, 1); }
        }
      }
      // glowing dewdrop blossom at the tip
      const tx = x + Math.round(Math.sin(h * 0.45 + d.v * 6) * 1.5);
      R(pal[1], tx, y + h, 2, 2);
      if (eg) { eg.fillStyle = pal[1]; eg.fillRect(tx, y + h, 2, 2); eg.globalAlpha = 0.45; eg.drawImage(halo(pal[3]), tx - 7, y + h - 7, 16, 16); eg.globalAlpha = 1; }
      break;
    }
    case "shroom": {
      // multi-cap bioluminescent mushroom cluster with glowing spotted caps & luminous gills
      const c1 = d.v < 0.34 ? "#4ee8c2" : d.v < 0.67 ? "#e86cb8" : "#74c2ff";
      const hi = d.v < 0.34 ? "#ccfff2" : d.v < 0.67 ? "#ffd4ee" : "#d8f2ff";
      const h = 4 + Math.round(d.v * 5);
      // main cap
      R("#0e0918", x - 1, y - h, 3, h); R("#dfd7c8", x, y - h, 1, h);
      R(K, x - 5, y - h - 4, 11, 5); R(c1, x - 4, y - h - 3, 9, 3); R(hi, x - 3, y - h - 3, 3, 1);
      R("#ffffff", x - 2, y - h - 2, 1, 1); R("#ffffff", x + 2, y - h - 3, 1, 1);
      R(hi, x - 3, y - h, 7, 1); // glowing gills
      // companion baby shrooms
      R("#0e0918", x + 4, y - 3, 2, 3); R("#dfd7c8", x + 5, y - 3, 1, 3);
      R(K, x + 2, y - 5, 6, 3); R(c1, x + 3, y - 4, 4, 1); R("#ffffff", x + 4, y - 4, 1, 1);
      if (d.v > 0.45) {
        R("#0e0918", x - 6, y - 2, 2, 2); R(K, x - 7, y - 4, 5, 3); R(c1, x - 6, y - 3, 3, 1);
      }
      if (eg) {
        eg.fillStyle = c1; eg.fillRect(x - 4, y - h - 3, 9, 3); eg.fillRect(x + 3, y - 4, 4, 1);
        eg.globalAlpha = 0.58; eg.drawImage(halo(c1), x - 13, y - h - 14, 26, 26); eg.globalAlpha = 1;
      }
      break;
    }
    case "stalag": {
      // faceted wet cavern stalactite with glistening specular highlight & water droplet tip
      const h = 5 + Math.round(d.v * 9);
      for (let i = 0; i < h; i++) {
        const w = Math.max(1, 5 - (((i * 5) / h) | 0)), sx = x - (w >> 1);
        R("#140e22", sx - 1, y + i, w + 2, 1);
        R(i < h * 0.45 ? "#4a4068" : "#2f2746", sx, y + i, w, 1);
        if (w >= 2) R("#7a72a0", sx, y + i, 1, 1);
      }
      if (d.v > 0.55) R("#9ae8ff", x, y + h, 1, 1);
      break;
    }
    case "stalagmite": {
      const h = 5 + Math.round(d.v * 8);
      for (let i = 0; i < h; i++) {
        const w = Math.max(1, 5 - (((i * 5) / h) | 0)), sx = x - (w >> 1);
        R("#140e22", sx - 1, y - i - 1, w + 2, 1);
        R(i < h * 0.5 ? "#4a4068" : "#342c4c", sx, y - i - 1, w, 1);
        if (w >= 2) R("#8a82b4", sx, y - i - 1, 1, 1);
      }
      break;
    }
    case "rail":
      R("#2a1e14", x - 4, y - 2, 3, 2); R("#2a1e14", x, y - 2, 3, 2);
      R("#1a1a22", x - 4, y - 4, 8, 2); R("#aeb4c8", x - 4, y - 4, 8, 1);
      break;
    case "beam": {
      const h = d.h;
      R(K, x - 2, y - h, 5, h); R(T.plank[0], x - 1, y - h, 3, h); R(T.plank[1], x + 1, y - h, 1, h);
      // iron brace brackets + overhead crossbeam
      R(K, x - 11, y - h, 23, 5); R(T.plank[0], x - 10, y - h + 1, 21, 3); R("rgba(255,255,255,0.2)", x - 10, y - h + 1, 21, 1);
      R("#3a3e4c", x - 3, y - h + 4, 7, 2); R("#9a9eb0", x - 8, y - h + 2, 1, 1); R("#9a9eb0", x + 8, y - h + 2, 1, 1);
      break;
    }
    case "cart": {
      const pal = CRYS[(d.v * 5) | 0];
      for (let i = 0; i < 7; i++) {
        const ox = -7 + i * 2.3, h = 4 + ((i * 7) % 5);
        R("#0e0818", x + ox - 1, y - 16 - h, 4, h + 1);
        R(pal[i % 2], x + ox, y - 15 - h, 2, h);
        if (eg) { eg.fillStyle = pal[i % 2 === 0 ? 3 : 1]; eg.fillRect(Math.round(x + ox), y - 15 - h, 2, h); }
      }
      R(K, x - 10, y - 15, 21, 11); R("#4c5162", x - 9, y - 14, 19, 9); R("#7a8298", x - 9, y - 14, 19, 1); R("#2e3240", x - 9, y - 7, 19, 1);
      R("#ffd05a", x + 8, y - 12, 2, 2);
      for (const rx of [-7, -2, 3]) R("#a8aec4", x + rx, y - 12, 1, 1);
      for (const wx of [-7, 3]) { R(K, x + wx, y - 5, 5, 5); R("#3a3a44", x + wx + 1, y - 4, 3, 3); R("#b0b6ca", x + wx + 2, y - 3, 1, 1); }
      if (eg) { eg.fillStyle = "#ffd05a"; eg.fillRect(x + 8, y - 12, 2, 2); eg.globalAlpha = 0.6; eg.drawImage(halo(pal[3]), x - 18, y - 34, 36, 32); eg.globalAlpha = 1; }
      break;
    }

  }
}

/** the whole arena on one canvas - painted pixel by pixel - and a second one with everything that gives off its own light */
export function paintTerrain(m: ArenaMap): { terr: HTMLCanvasElement; emis: HTMLCanvasElement | null; base: HTMLCanvasElement; ebase: HTMLCanvasElement | null } {
  const T = m.theme, TW = m.w, TH = m.h, W = TW * AT, H = TH * AT, desert = T.decor === "desert", cave = T.decor === "cave", city = T.decor === "city", jungle = T.decor === "jungle", brawl = T.decor === "brawl";
  const [c, g] = mk(W, H), img = g.createImageData(W, H), d = img.data;
  let ec: HTMLCanvasElement | null = null, eg: Ctx | null = null;
  if (!desert) [ec, eg] = mk(W, H);
  const eimg = eg ? eg.createImageData(W, H) : null, e = eimg ? eimg.data : null;
  const sol = (x: number, y: number) => solidT(tileAt(m, x, y));
  const depth = new Uint16Array(TW * TH);
  for (let x = 0; x < TW; x++) { let n = 0; for (let y = 0; y < TH; y++) { const i = y * TW + x; n = solidT(m.grid[i]) ? n + 1 : 0; depth[i] = n; } }
  const D0 = rgb(T.dirt[0]), D1 = rgb(T.dirt[1]), D2 = rgb(T.dirt[2]), T0 = rgb(T.top[0]), T1 = rgb(T.top[1]);
  const R0 = rgb(T.rock[0]), R1 = rgb(T.rock[1]), R2 = rgb(T.rock[2]), W0 = rgb(T.wall[0]), W1 = rgb(T.wall[1]), C0 = rgb(T.cave[0]), C1 = rgb(T.cave[1]);
  const BLK = [8, 6, 16], CY = [95, 240, 224], WIN = rgb("#ffcf7a"), WOFF = rgb("#232030"), WFR = rgb("#15131c");
  const glow = (o: number, col: number[], k: number) => { if (e) { e[o] = col[0] * k; e[o + 1] = col[1] * k; e[o + 2] = col[2] * k; e[o + 3] = 255; } };
  const forestStone = jungle ? forestRockAtlas() : null;
  const caveStone = cave ? hollowRockAtlas() : null;
  const sanctuaryFloor = cave ? new Uint8Array(TW * TH) : null;
  if (sanctuaryFloor) for (const q of m.decor) {
    if (!["gotharch", "runepillar", "monolith"].includes(q.k)) continue;
    const tx = Math.floor(q.x / AT), ty = Math.floor(q.y / AT);
    for (let y = ty; y <= ty + 2; y++) for (let x = tx - 3; x <= tx + 3; x++) {
      if (x >= 0 && x < TW && y >= 0 && y < TH && m.grid[y * TW + x] === ROCK) sanctuaryFloor[y * TW + x] = 1;
    }
  }
  for (let py = 0; py < H; py++) {
    const ty = py >> 3, iy = py & 7;
    for (let px = 0; px < W; px++) {
      const tx = px >> 3, ix = px & 7, ti = ty * TW + tx, t = m.grid[ti], o = (py * W + px) * 4;
      let col: number[] | null = null;
      if (solidT(t)) {
        const sd = (depth[ti] - 1) * AT + iy;
        const edge = (ix === 0 && !sol(tx - 1, ty)) || (ix === 7 && !sol(tx + 1, ty)) || (iy === 7 && !sol(tx, ty + 1));
        if (cave && caveStone) {
          const p = ((py & 255) * 512) + (px & 511), so = p * 3;
          col = [caveStone.rgb[so], caveStone.rgb[so + 1], caveStone.rgb[so + 2]];
          col = mixc(col, [24, 20, 41], Math.min(0.28, sd / 300));
          if (sanctuaryFloor?.[ti]) {
            const row = Math.floor(py / 6), off = (row & 1) * 5;
            const joint = py % 6 === 0 || (px + off) % 11 === 0;
            col = joint ? mixc(col, [29, 25, 44], 0.56) : mixc(col, [112, 98, 130], 0.18 + hsh(Math.floor((px + off) / 11), row, 171) * 0.18);
            if (!joint && py % 6 === 1) col = mixc(col, [167, 151, 178], 0.2);
          }
          const moss = 3 + vn(px * 0.12, py * 0.08, 156) * 6;
          if (sd < 1) col = mixc([85, 111, 112], [153, 190, 176], vn(px * 0.06, py * 0.04, 157));
          else if (sd < moss && t === DIRT) col = mixc([39, 70, 65], [76, 119, 100], vn(px * 0.2, py * 0.12, 158));
          if (ix < 3 && !sol(tx - 1, ty)) col = mixc(col, [140, 142, 170], (3 - ix) * 0.09);
          if (ix > 4 && !sol(tx + 1, ty)) col = mixc(col, [23, 24, 43], (ix - 4) * 0.12);
          if (caveStone.glow[p] > 0) glow(o, [caveStone.veins[so], caveStone.veins[so + 1], caveStone.veins[so + 2]], caveStone.glow[p] / 320);
        } else if (jungle && forestStone) {
          const so = (((py & 255) * 512) + (px & 511)) * 3;
          col = [forestStone[so], forestStone[so + 1], forestStone[so + 2]];
          const dapple = vn(px * 0.036, py * 0.031, 147);
          col = mixc(col, [28, 49, 39], Math.min(0.34, sd / 340));
          if (t === DIRT && sd < 17) {
            const moss = 4 + vn(px * 0.1, py * 0.04, 148) * 7;
            if (sd < 1) col = mixc([85, 116, 60], [174, 184, 104], dapple);
            else if (sd < 3) col = mixc([57, 88, 45], [116, 147, 72], dapple);
            else if (sd < moss) col = mixc([44, 68, 38], [75, 103, 51], vn(px * 0.23, py * 0.18, 149));
            else col = mixc(col, [89, 76, 48], (1 - sd / 18) * 0.7);
          } else if (t === ROCK && sd < 4) col = mixc(col, [97, 129, 74], (1 - sd / 5) * 0.7);
          const l = !sol(tx - 1, ty) ? 1 - ix / 8 : 0;
          const r = !sol(tx + 1, ty) ? ix / 8 : 0;
          if (l > 0.5) col = mixc(col, [136, 145, 116], (l - 0.5) * 0.45);
          if (r > 0.5) col = mixc(col, [22, 41, 33], (r - 0.5) * 0.55);
        } else if (t === DIRT) {
          if (desert) {
            // sand: wind ripples, a bright crust on top, darker and more packed the deeper it goes
            const n = vn(px * 0.045, py * 0.045, 1);
            col = mixc(D0, D1, n);
            const rip = Math.sin(px * 0.4 + py * 1.3 + n * 7);
            if (rip > 0.87) col = mixc(col, T0, 0.6); else if (rip < -0.9) col = mixc(col, D2, 0.25);
            col = mixc(col, D2, Math.min(1, sd / 120) * 0.55);
            if (sd < 2) col = T1; else if (sd < 4) col = T0; else if (sd < 6 && hsh(px, py, 3) < 0.45) col = T0;
            if (hsh(px, py, 4) < 0.004) col = mixc(col, D2, 0.7);
          } else {
            const n = vn(px * 0.08, py * 0.08, 8);
            col = mixc(D0, D1, n);
            if (hsh(px, py, 9) < 0.01) col = mixc(col, D2, 0.6);
            if (sd < 3) col = sd < 1 ? T1 : T0;
            col = mixc(col, D2, Math.min(1, sd / 100) * 0.4);
          }
        } else if (brawl) {
          const facet = vn(px * 0.055, py * 0.07, 192), seam = Math.abs(Math.sin(px * 0.042 + py * 0.068 + facet * 4));
          col = mixc(R0, R1, facet * 0.8);
          col = mixc(col, R2, Math.min(0.6, sd / 80));
          if (sd < 2) col = mixc(T0, T1, 0.42 + facet * 0.38);
          else if (seam < 0.055) col = mixc(col, [117, 205, 224], 0.38);
        } else if (desert) {
          // sandstone: layered bands, pitted by the wind
          const n = vn(px * 0.03, py * 0.11, 2), bk = (((py + n * 5) / 3) | 0) % 5;
          col = bk === 0 ? R1 : bk === 2 ? mixc(R0, R2, 0.3) : bk === 4 ? mixc(R1, T0, 0.35) : R0;
          if (hsh(px >> 1, py, 5) < 0.03) col = mixc(col, R2, 0.55);
          if (sd < 2) col = mixc(R1, T1, 0.45);
        } else {
          const row = (py / 4) | 0, off = (row & 1) * 4, mortar = py % 4 === 0 || (px + off) % 8 === 0;
          col = mortar ? R2 : mixc(R0, R1, hsh(((px + off) / 8) | 0, row, 10) * 0.6);
        }
        if (edge) col = mixc(col, jungle ? [19, 36, 28] : cave ? [17, 31, 42] : BLK, jungle || cave ? 0.22 : 0.45);
      } else if (m.bg[ti]) {
        const v = m.bg[ti];
        let k = 0;
        if (sol(tx, ty - 1)) k = Math.max(k, (1 - iy / 8) * 0.55);
        if (sol(tx - 1, ty)) k = Math.max(k, (1 - ix / 8) * 0.4);
        if (sol(tx + 1, ty)) k = Math.max(k, (ix / 8) * 0.4);
        if (sol(tx, ty + 1)) k = Math.max(k, (iy / 8) * 0.25);
        if (v === 1) {
          if (city) {
            const row = (py / 4) | 0, off = (row & 1) * 4, mortar = py % 4 === 0 || (px + off) % 8 === 0;
            col = mortar ? W1 : mixc(W0, W1, hsh(((px + off) / 8) | 0, row, 11) * 0.5);
            for (const wx of [tx, tx - 1])
              for (const wy of [ty, ty - 1]) {
                if (wx % 4 !== 1 || wy % 5 !== 1 || hsh(wx, wy, 3) >= 0.55) continue;
                const lx = px - (wx * 8 + 1), ly = py - (wy * 8 + 2);
                if (lx < 0 || ly < 0 || lx >= 10 || ly >= 10) continue;
                const lit = hsh(wx, wy, 4) < 0.25, fr = lx === 0 || ly === 0 || lx === 9 || ly === 9;
                col = fr ? WFR : lit ? WIN : WOFF;
                if (lit && !fr) glow(o, WIN, 0.35);
              }
          } else if (jungle) {
            // Ivy-clad ancient Shaper sanctuary temple wall with subtle bronze bands & glowing cyan glyph lines
            const row = (py / 6) | 0, off = (row & 1) * 6, mortar = py % 6 === 0 || (px + off) % 12 === 0;
            col = mortar ? W1 : mixc(W0, W1, vn(px * 0.1, py * 0.1, 51) * 0.6);
            if (vn(px * 0.14, py * 0.14, 52) > 0.66) col = mixc(col, [34, 128, 62], 0.55); // lush wall ivy
            if (py % 18 === 9 && px % 8 < 5 && hsh(px >> 3, py, 53) < 0.35) { col = [86, 232, 240]; glow(o, CY, 0.45); }
          } else {
            // the bunker's concrete: panels, seams, stains
            col = px % 16 === 0 || py % 12 === 0 ? W1 : mixc(W0, W1, vn(px * 0.1, py * 0.1, 12) * 0.5);
            if (vn(px * 0.05, py * 0.2, 13) > 0.74) col = mixc(col, BLK, 0.18);
          }
        } else {
          // the back of the tunnels and caves
          const n = vn(px * 0.07, py * 0.07, 14), n2 = vn(px * 0.2, py * 0.2, 15);
          col = mixc(C0, C1, n * 0.7 + n2 * 0.3);
          if (desert && (py + ((n * 4) | 0)) % 6 === 0) col = mixc(col, BLK, 0.15);
          if (cave && n2 > 0.82) col = mixc(col, BLK, 0.25);
          if (jungle) {
            if (n > 0.62) col = mixc(col, [30, 118, 64], 0.42);
            if (hsh(px, py, 54) < 0.004) { col = mixc(col, CY, 0.7); glow(o, CY, 0.45); }
          }
        }
        col = mixc(col, BLK, k);
      }
      if (col) { d[o] = col[0]; d[o + 1] = col[1]; d[o + 2] = col[2]; d[o + 3] = cave && t === AIR && m.bg[ti] > 0 ? 185 : 255; }
    }
  }
  g.putImageData(img, 0, 0);
  if (eg && eimg) eg.putImageData(eimg, 0, 0);
  if (jungle) paintForestRoots(g, m);
  const R = (col: string, x: number, y: number, w: number, h: number) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  const at = (x: number, y: number) => tileAt(m, x, y);
  for (let y = 0; y < TH; y++)
    for (let x = 0; x < TW; x++) {
      const t = m.grid[y * TW + x], px = x * AT, py = y * AT;
      if (t === PLAT) {
        R(jungle ? "#343e29" : "#140e1c", px, py, AT, 4);
        R(T.plank[0], px, py, AT, 3);
        R(T.plank[1], px, py + 2, AT, 1);
        R("rgba(255,255,255,0.22)", px, py, AT, 1);
        if (x % 2 === 0) R("#16121a", px + 1, py + 1, 1, 1);
        R("rgba(0,0,0,0.24)", px, py + 4, AT, 1);
        if (cave || jungle) {
          if (cave && x % 3 === 0) { R("#3d4256", px + 2, py + 1, 3, 2); R("#a4aec6", px + 3, py + 1, 1, 1); }
          if (jungle && x % 2 === 0) R("#6c8944", px + 2, py, 3, 1);
          if (hsh(x, y, 47) < (jungle ? 0.58 : 0.38)) {
            const mx = px + ((hsh(x, y, 48) * 6) | 0), ml = 2 + ((hsh(x, y, 49) * (jungle ? 6 : 4)) | 0);
            R(jungle ? "#52763c" : "#36b889", mx, py + 3, 1, ml);
            if (jungle && hsh(x, y, 50) < 0.45) R(hsh(x, y, 51) < 0.5 ? "#ff6ca8" : "#ffe25a", mx, py + 3 + ml, 1, 1);
            else if (!jungle && hsh(x, y, 50) < 0.45 && eg) { R("#8ef8d2", mx, py + 3 + ml, 1, 1); eg.fillStyle = "#8ef8d2"; eg.fillRect(mx, py + 3 + ml, 1, 1); }
          }
        }
        if (at(x - 1, y) !== PLAT || at(x + 1, y) !== PLAT) { R("#140e1c", px + 3, py + 3, 3, 5); R(cave ? "#525878" : T.plank[1], px + 4, py + 3, 1, 4); }
      } else if (jungle && t === AIR && at(x, y + 1) === DIRT) {
        // lush blades of sunlit rainforest grass & tiny colourful meadow flowers sprouting from every grassy surface!
        for (let gx = 0; gx < AT; gx += 2) {
          const r = hsh(px + gx, py, 95);
          if (r < 0.65) {
            const gh = 1 + ((r * 4.5) | 0);
            R(gh > 2 ? "#a4b96b" : "#557c43", px + gx, py + AT - gh, 1, gh);
            if (r < 0.09) R(r < 0.03 ? "#ff669e" : r < 0.06 ? "#ffe452" : "#5ee8ff", px + gx, py + AT - gh - 1, 1, 1);
          }
        }
      } else if (t === AIR && solidT(at(x, y - 1))) {
        R("rgba(0,0,0,0.24)", px, py, AT, 2);
        R("rgba(0,0,0,0.12)", px, py + 2, AT, 3);
        // lush glowing moss tendrils and root curtains hang from cave roofs & floating Bastion sky-islands!
        if (cave || jungle) {
          const q = hsh(x, y, 91);
          if (q < (jungle ? 0.72 : 0.56)) {
            const sx = px + ((hsh(x, y, 92) * 7) | 0), len = 2 + ((hsh(x, y, 93) * (jungle ? 10 : 8)) | 0);
            R(q < (jungle ? 0.48 : 0.34) ? T.top[0] : jungle ? "#68442c" : "#46375a", sx, py, 1, len);
            if (jungle && q < 0.22) R(q < 0.08 ? "#ff6ca8" : q < 0.15 ? "#ffe25a" : "#96f86c", sx, py + len, 1, 2);
            else if (cave && q < 0.16 && eg) {
              const gc = q < 0.08 ? "#8ef8d2" : "#5ff0e0";
              R(gc, sx, py + len, 1, 2); eg.fillStyle = gc; eg.fillRect(sx, py + len, 1, 2);
            }
          }
        }
      }
    }
  for (const q of m.hatches) hatchDraw(g, eg, Math.round(q.x), Math.round(q.y));
  // the hiding places: what stands behind the one who hides is painted here - the cover in front is a sprite of the game (only its glow goes onto the light layer)
  for (const q of m.hides) { paintHide(g, eg, q.k, Math.round(q.x), Math.round(q.y), T, 0); paintHide(null, eg, q.k, Math.round(q.x), Math.round(q.y), T, 1); }
  // a copy of the bare arena, before anything is stood on it: what shows again where something is shot away
  const [bc, bcg] = mk(W, H);
  bcg.drawImage(c, 0, 0);
  let ebc: HTMLCanvasElement | null = null;
  if (ec) { const [q, qg] = mk(W, H); qg.drawImage(ec, 0, 0); ebc = q; }
  for (const dd of m.decor) decorDraw(g, eg, dd, T);
  return { terr: c, emis: ec, base: bc, ebase: ebc };
}

/** the minimap: one pixel per two tiles */
export function paintMini(m: ArenaMap): HTMLCanvasElement {
  const [c, g] = mk(m.w >> 1, m.h >> 1), T = m.theme;
  g.fillStyle = "rgba(10,10,18,0.72)";
  g.fillRect(0, 0, c.width, c.height);
  for (let y = 0; y < c.height; y++)
    for (let x = 0; x < c.width; x++) {
      const t = tileAt(m, x * 2, y * 2), t2 = tileAt(m, x * 2 + 1, y * 2 + 1);
      if (solidT(t) || solidT(t2)) { g.fillStyle = t === ROCK ? T.rock[1] : T.dirt[0]; g.fillRect(x, y, 1, 1); }
      else if (t === PLAT) { g.fillStyle = T.plank[0]; g.fillRect(x, y, 1, 1); }
    }
  for (const r of m.rivers) {
    g.fillStyle = "#4ba99f";
    for (let x = Math.floor(r.x / 16); x < (r.x + r.w) / 16; x++) {
      if (!solidPx(m, x * 16 + 4, r.y + 2)) g.fillRect(x, Math.floor(r.y / 16), 1, Math.max(1, Math.round(r.depth / 16)));
    }
  }
  return c;
}

/** a preview of the arena for the lobby */
export function mapPreview(id: number): string {
  if (id === 2) {
    preloadHollow();
    return crystalVistaUrl();
  }
  if (id === 3) {
    preloadForest();
    return forestVistaUrl();
  }
  const m = getMap(id), T = m.theme, [c, g] = mk(m.w, m.h);
  const grd = g.createLinearGradient(0, 0, 0, m.h);
  grd.addColorStop(0, T.sky[0]); grd.addColorStop(0.6, T.sky[1]); grd.addColorStop(1, T.sky[2]);
  g.fillStyle = grd;
  g.fillRect(0, 0, m.w, m.h);
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const t = m.grid[y * m.w + x];
      const col = t === DIRT ? (tileAt(m, x, y - 1) === DIRT ? T.dirt[0] : T.top[0]) : t === ROCK ? T.rock[0] : t === PLAT ? T.plank[0] : m.bg[y * m.w + x] ? (m.bg[y * m.w + x] === 1 ? T.wall[0] : T.cave[0]) : "";
      if (col) { g.fillStyle = col; g.fillRect(x, y, 1, 1); }
    }
  if (T.decor === "jungle") {
    // distant Bastion tepui silhouettes & lush forest horizon on the lobby preview card
    g.fillStyle = "rgba(33,105,91,0.48)";
    g.fillRect(0, Math.floor(m.h * 0.45), m.w, m.h);
    g.fillStyle = "#fff6cc"; g.fillRect(Math.floor(m.w * 0.72), 8, 8, 8);
  }
  for (const dd of m.dyn) {
    if (dd.k === "fall") { g.fillStyle = "#88f4ff"; g.fillRect(Math.floor(dd.x / AT) - 1, Math.floor(dd.y / AT), 2, Math.ceil(dd.h / AT)); }
    else if (dd.k === "pool") { g.fillStyle = "#48f4e2"; g.fillRect(Math.floor((dd.x - dd.h * 0.5) / AT), Math.floor(dd.y / AT) - 1, Math.max(2, Math.ceil(dd.h / AT)), 2); }
    else if (dd.k === "beamlight") { g.fillStyle = T.decor === "jungle" ? "rgba(255,244,170,0.22)" : "rgba(130,245,255,0.22)"; g.fillRect(Math.floor(dd.x / AT) - 1, Math.floor(dd.y / AT), 3, Math.ceil(dd.h / AT)); }
    else if (dd.k === "shaperring") { g.strokeStyle = "#5ef8ff"; g.lineWidth = 1.5; g.beginPath(); g.arc(dd.x / AT, dd.y / AT, 4, 0, Math.PI * 2); g.stroke(); }
  }
  for (const dd of m.decor) {
    if (dd.k === "crystal" || dd.k === "bigcrystal" || dd.k === "ceilcrystal") {
      g.fillStyle = CRYS[(dd.v * 5) | 0][0];
      const sz = dd.k === "bigcrystal" ? 3 : 1;
      g.fillRect(Math.floor(dd.x / AT) - (sz >> 1), Math.floor(dd.y / AT) - sz, sz, sz);
    } else if (dd.k === "canopytree" || dd.k === "banyantree") {
      const tx = Math.floor(dd.x / AT), ty = Math.floor(dd.y / AT);
      g.fillStyle = "#68432b"; g.fillRect(tx, ty - 5, 1, 5);
      g.fillStyle = "#22a84a"; g.fillRect(tx - 3, ty - 7, 7, 3);
      g.fillStyle = "#9cf86e"; g.fillRect(tx - 2, ty - 8, 5, 1);
    } else if (dd.k === "rafflesia" || dd.k === "heliconia" || dd.k === "orchid") {
      g.fillStyle = dd.k === "orchid" ? "#ff68c8" : "#ff4a42";
      g.fillRect(Math.floor(dd.x / AT), Math.floor(dd.y / AT) - 2, 2, 2);
    }
  }
  for (const p of m.picks) { g.fillStyle = p.kind === "saber" ? "#9ae8ff" : p.kind === "katana" ? "#ffffff" : p.kind === "health" ? "#ff6b7a" : p.kind === "nades" ? "#7dff9a" : "#ffe14a"; g.fillRect(Math.floor(p.x / AT), Math.floor(p.y / AT) - 1, 1, 1); }
  for (const q of m.hides) { g.fillStyle = "#4ee08a"; g.fillRect(Math.floor(q.x / AT) - 1, Math.floor(q.y / AT) - 2, 2, 2); }
  for (let t = 0; t < 2; t++) for (const s of m.spawns[t]) { g.fillStyle = t ? "#ff4d5e" : "#f5c542"; g.fillRect(Math.floor(s.x / AT), Math.floor(s.y / AT) - 2, 1, 2); }
  return c.toDataURL();
}

export interface Backdrop { far: HTMLCanvasElement | null; mid: HTMLCanvasElement | null; near: HTMLCanvasElement | null; clouds: HTMLCanvasElement[]; tile: boolean }

/** a horizontal band of the far landscape (960 wide, tileable) */
function band(draw: (g: Ctx, x0: number) => void): HTMLCanvasElement {
  const [c, g] = mk(960, 230);
  for (const x0 of [-960, 0, 960]) draw(g, x0);
  return c;
}
/** the parallax layers behind the arena: a skyline, the desert in a storm, or the 3-layer depths of the crystal cathedral cave */
export function paintBackdrop(T: Theme): Backdrop {
  if (T.decor === "cave" || T.decor === "jungle" || T.decor === "brawl") return { far: null, mid: null, near: null, clouds: [], tile: false };
  if (T.decor === "desert") {
    const lift = (hex: string, k: number) => { const c = rgb(hex); return `rgb(${Math.min(255, c[0] * k) | 0},${Math.min(255, c[1] * k) | 0},${Math.min(255, c[2] * k) | 0})`; };
    // far: flat-topped mesas and two pyramids, their sunny faces lighter
    const far = band((g, x0) => {
      for (let i = 0; i < 6; i++) {
        const x = x0 + i * 165 + hsh(i, 1, 1) * 50, w = 70 + hsh(i, 2, 1) * 60, h = 46 + hsh(i, 3, 1) * 46;
        g.fillStyle = T.far;
        g.beginPath(); g.moveTo(x, 230); g.lineTo(x + 10, 230 - h); g.lineTo(x + w - 14, 230 - h); g.lineTo(x + w, 230); g.closePath(); g.fill();
        g.fillStyle = lift(T.far, 1.08); g.fillRect(x + 10, 230 - h, w - 24, 3);
      }
      for (const [px, pw, ph] of [[300, 130, 78], [690, 96, 56]]) {
        const x = x0 + px;
        g.fillStyle = lift(T.far, 0.94); g.beginPath(); g.moveTo(x - pw / 2, 230); g.lineTo(x, 230 - ph); g.lineTo(x + pw / 2, 230); g.closePath(); g.fill();
        g.fillStyle = lift(T.far, 1.1); g.beginPath(); g.moveTo(x, 230 - ph); g.lineTo(x + pw / 2, 230); g.lineTo(x + pw * 0.1, 230); g.closePath(); g.fill();
      }
    });
    const dunes = (col: string, hgt: number, seed: number, ruins: boolean) => band((g, x0) => {
      g.fillStyle = col;
      g.beginPath();
      g.moveTo(x0, 230);
      for (let x = 0; x <= 960; x += 4) { const k = (x / 960) * Math.PI * 2; g.lineTo(x0 + x, 230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2) + 0.06 * Math.sin(k * 11 + seed))); }
      g.lineTo(x0 + 960, 230);
      g.fill();
      // the wind has drawn a bright line along every ridge
      g.fillStyle = lift(col, 1.12);
      for (let x = 0; x <= 960; x += 2) { const k = (x / 960) * Math.PI * 2; g.fillRect(x0 + x, Math.round(230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2) + 0.06 * Math.sin(k * 11 + seed))), 2, 1); }
      if (ruins) {
        g.fillStyle = lift(col, 0.82);
        for (const [rx, n] of [[140, 4], [520, 3], [800, 2]]) for (let i = 0; i < n; i++) {
          const x = x0 + rx + i * 22, k = ((rx + i * 22) / 960) * Math.PI * 2, base = 230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2)) + 4, h = 26 + ((i * 13 + rx) % 20);
          g.fillRect(x, base - h, 7, h); g.fillRect(x - 2, base - h - 3, 11, 3);
          if (i < n - 1 && i % 2 === 0) g.fillRect(x, base - h - 6, 29, 3);
        }
      }
    });
    const clouds: HTMLCanvasElement[] = [];
    for (let i = 0; i < 4; i++) {
      const [c, g] = mk(120, 36);
      g.fillStyle = "rgba(240,196,140,0.5)";
      for (let k = 0; k < 7; k++) { g.beginPath(); g.ellipse(18 + k * 14 + hsh(i, k, 1) * 6, 20 - hsh(i, k, 2) * 8, 14 + hsh(i, k, 3) * 6, 8 + hsh(i, k, 4) * 4, 0, 0, Math.PI * 2); g.fill(); }
      clouds.push(c);
    }
    return { far, mid: dunes(T.mid, 92, 3, false), near: dunes(T.near, 120, 5, true), clouds, tile: false };
  }
  const strip = (col: string, hgt: number, seed: number): HTMLCanvasElement => {
    const [c, g] = mk(960, 220);
    g.fillStyle = col;
    let x = 0;
    while (x < 960) {
      const w = 18 + Math.floor(hsh(x, seed, 1) * 34), h = hgt * (0.35 + hsh(x, seed, 2) * 0.65), broken = hsh(x, seed, 3) < 0.35;
      g.fillRect(x, 220 - h, w, h);
      if (broken) { g.clearRect(x + w * 0.5, 220 - h, w * 0.5, h * 0.18); g.fillRect(x + w * 0.55, 220 - h * 0.86, 2, -h * 0.12); }
      if (seed > 2) {
        g.fillStyle = "rgba(255,200,120,0.5)";
        for (let wy = 220 - h + 6; wy < 214; wy += 7) for (let wx = x + 3; wx < x + w - 3; wx += 5) if (hsh(wx, wy, seed) < 0.1) g.fillRect(wx, wy, 2, 2);
        g.fillStyle = col;
      }
      x += w + Math.floor(hsh(x, seed, 4) * 6);
    }
    return c;
  };
  const clouds: HTMLCanvasElement[] = [];
  for (let i = 0; i < 4; i++) {
    const [c, g] = mk(90, 30);
    g.fillStyle = "rgba(70,56,86,0.85)";
    for (let k = 0; k < 6; k++) { g.beginPath(); g.ellipse(18 + k * 11 + hsh(i, k, 1) * 6, 18 - hsh(i, k, 2) * 8, 12 + hsh(i, k, 3) * 6, 7 + hsh(i, k, 4) * 4, 0, 0, Math.PI * 2); g.fill(); }
    clouds.push(c);
  }
  return { far: strip(T.far, 150, 1), mid: strip(T.mid, 120, 3), near: null, clouds, tile: false };
}
