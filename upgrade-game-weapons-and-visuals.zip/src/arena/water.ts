import type { ArenaMap, Dyn, River } from "./maps";

type Ctx = CanvasRenderingContext2D;
const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const hash = (x: number, y: number, seed = 0) => {
  let n = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(seed | 0, 1442695041);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
};
const canvas = (w: number, h: number) => {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return [c, c.getContext("2d")!] as const;
};
const rect = (g: Ctx, col: string, x: number, y: number, w: number, h: number) => {
  g.fillStyle = col;
  g.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
};

interface Ripple { x: number; y: number; age: number; life: number; size: number }

export class WaterScene {
  protected map: ArenaMap;
  protected mist: HTMLCanvasElement;
  protected cavern: boolean;
  private ripples: Ripple[] = [];
  private contacts = new Map<number, { wet: boolean; time: number }>();

  constructor(map: ArenaMap, cavern = false) {
    this.map = map;
    this.cavern = cavern;
    const [mist, g] = canvas(128, 64);
    const fog = g.createRadialGradient(64, 32, 0, 64, 32, 64);
    fog.addColorStop(0, cavern ? "rgba(162,219,234,0.35)" : "rgba(224,247,225,0.32)");
    fog.addColorStop(0.4, cavern ? "rgba(119,190,215,0.18)" : "rgba(202,238,221,0.18)");
    fog.addColorStop(1, "rgba(170,223,235,0)");
    g.fillStyle = fog; g.fillRect(0, 0, 128, 64);
    this.mist = mist;
  }

  update(dt: number) {
    this.ripples = this.ripples.filter((r) => (r.age += dt) < r.life);
  }

  waterAt(x: number, y: number): River | null {
    for (const r of this.map.rivers) {
      if (x > r.x + 2 && x < r.x + r.w - 2 && y >= r.y - 1 && y < r.y + r.depth + 8) {
        const t = this.map.grid[Math.floor(r.y / 8) * this.map.w + Math.floor(x / 8)];
        if (t === 0) return r;
      }
    }
    return null;
  }

  splash(x: number, y: number, force = 1) {
    if (this.ripples.length > 44) this.ripples.shift();
    this.ripples.push({ x, y, age: 0, life: 0.7 + force * 0.2, size: 6 + force * 12 });
  }

  contact(id: number, x: number, y: number, vx: number, vy: number, dt: number) {
    const r = this.waterAt(x, y), prev = this.contacts.get(id) ?? { wet: false, time: 0 };
    prev.time -= dt;
    const entered = !!r && !prev.wet;
    if (r && (entered || (Math.abs(vx) > 10 && prev.time <= 0))) {
      this.splash(x, r.y, entered ? clamp(Math.abs(vy) / 150, 0.5, 2.5) : 0.25);
      prev.time = 0.22;
    }
    prev.wet = !!r;
    this.contacts.set(id, prev);
    return entered ? r : null;
  }

  private clipRiver(g: Ctx, r: River, cl: number, ct: number) {
    // Clip against the actual collision grid so stepping stones remain dry and shootable.
    g.beginPath();
    for (let x = Math.floor(r.x / 8); x < Math.ceil((r.x + r.w) / 8); x++) {
      let depth = 0;
      const row = Math.floor(r.y / 8);
      while (depth < r.depth && (this.map.grid[(row + Math.floor(depth / 8)) * this.map.w + x] ?? 2) === 0) depth += 8;
      if (depth > 0) g.rect(x * 8 - cl, r.y - ct, 8, Math.min(r.depth, depth));
    }
    g.clip();
  }

  drawRivers(g: Ctx, terrain: HTMLCanvasElement, cl: number, ct: number, W: number, H: number, t: number, front = false) {
    for (const r of this.map.rivers) {
      const x = r.x - cl, y = r.y - ct;
      if (x + r.w < 0 || x > W || y + r.depth < 0 || y > H) continue;
      g.save(); this.clipRiver(g, r, cl, ct);
      if (!front) {
        const water = g.createLinearGradient(0, y, 0, y + r.depth);
        water.addColorStop(0, this.cavern ? "#a0e7e9" : "#b4ead3");
        water.addColorStop(0.07, this.cavern ? "#3cabbc" : "#4bb9aa");
        water.addColorStop(0.32, this.cavern ? "#246b92" : "#267d7e");
        water.addColorStop(0.78, this.cavern ? "#203e71" : "#244f59");
        water.addColorStop(1, this.cavern ? "#1d2b50" : "#203d48");
        g.fillStyle = water; g.fillRect(x, y, r.w, r.depth);
        // Moving surface silhouette and refracted skylight keep pools from reading as flat rectangles.
        const from = Math.max(0, Math.floor((cl - r.x) / 6) * 6 - 6);
        const to = Math.min(r.w + 6, cl + W - r.x + 12);
        g.beginPath(); g.moveTo(x + from, y + 3);
        for (let px = from; px <= to; px += 6) {
          const wave = Math.sin(px * 0.085 - t * r.flow * 2.5) * 1.25 + Math.sin(px * 0.19 + t * 1.6) * 0.55;
          g.lineTo(x + px, y + 3 + wave);
        }
        g.lineTo(x + to, y + 8); g.lineTo(x + from, y + 8); g.closePath();
        g.fillStyle = this.cavern ? "rgba(166,242,255,0.28)" : "rgba(209,255,220,0.24)"; g.fill();
        // Reflected branches undulate in horizontal bands above a visible stony bed.
        for (let d = 1; d < Math.min(27, r.depth); d += 2) {
          const sy = Math.max(0, r.y - d * 2 - 2);
          g.globalAlpha = 0.21 * (1 - d / 36);
          g.drawImage(terrain, r.x, sy, r.w, 2, x + Math.sin(d * 0.7 + t * 2) * 2, y + d, r.w, 2);
        }
        g.globalAlpha = 0.8;
        for (let i = 0; i < r.w / 8; i++) {
          const bx = x + hash(i, r.x, 61) * r.w, by = y + r.depth - 2 - hash(i, r.x, 62) * 9;
          rect(g, i % 2 ? "#557b6c" : "#769787", bx, by, 3 + hash(i, r.y, 63) * 6, 2 + hash(i, r.y, 64) * 3);
          rect(g, "#a5b49a", bx + 1, by, 2, 1);
        }
        // Shifting sun-caustic threads, not a uniformly glowing neon stripe.
        g.globalAlpha = 0.32; g.strokeStyle = this.cavern ? "#acd7e6" : "#b4e8b2"; g.lineWidth = 0.6;
        const start = Math.max(0, Math.floor((cl - r.x) / 19) - 1), end = Math.min(r.w / 19, (cl + W - r.x) / 19 + 1);
        for (let i = start; i < end; i++) {
          const bx = x + i * 19 + Math.sin(t * 0.7 + i) * 3;
          const by = y + 9 + hash(i, r.y, 71) * (r.depth - 12);
          g.beginPath(); g.moveTo(bx - 3, by); g.lineTo(bx + 3, by - 2); g.lineTo(bx + 9, by + 1); g.lineTo(bx + 14, by - 1); g.stroke();
        }
        // Crystal and lantern light reflects down the water in broken, shifting columns.
        g.save(); g.globalCompositeOperation = "screen";
        for (const l of this.map.lights) {
          if (l.x < r.x || l.x > r.x + r.w || Math.abs(l.y - r.y) > 105 || l.x - cl < -50 || l.x - cl > W + 50) continue;
          const lx = l.x - cl, reach = Math.min(r.depth - 3, 22 + l.r * 0.25);
          for (let row = 0; row < reach; row += 4) {
            const width = Math.max(2, (16 - row * 0.27) * (0.6 + 0.4 * Math.sin(row * 0.42 + t * 3 + lx)));
            g.globalAlpha = (1 - row / reach) * 0.17;
            rect(g, l.col, lx + Math.sin(t * 2.5 + row * 0.4) * 3 - width / 2, y + row + 4, width, 1);
          }
        }
        g.restore();
        g.save(); g.globalCompositeOperation = "screen";
        for (let i = 0; i < Math.min(42, Math.ceil(r.w / 11)); i++) {
          const px = x + hash(i, r.x, 102) * r.w;
          const py = y + 7 + hash(i, r.y, 103) * Math.max(3, r.depth - 13);
          const shimmer = Math.max(0, Math.sin(t * 2.1 + i * 2.37));
          g.globalAlpha = 0.08 + shimmer * 0.28;
          rect(g, this.cavern ? (i % 3 ? "#b4fbff" : "#e8baff") : "#d9ffcc", px + Math.sin(t * r.flow + i) * 2, py, i % 7 ? 2 : 4, 1);
        }
        g.restore();
      } else {
        g.fillStyle = this.cavern ? "rgba(83,198,235,0.11)" : "rgba(53,163,157,0.13)"; g.fillRect(x, y + 3, r.w, r.depth);
      }
      g.globalAlpha = front ? 0.74 : 0.6;
      for (let row = 0; row < (front ? 1 : 4); row++) {
        for (let i = 0; i < r.w / 21; i++) {
          const rx = x + ((i * 21 + t * (8 + row * 3) * r.flow) % r.w + r.w) % r.w;
          const ry = y + row * 5 + Math.sin(i * 2 + t * 1.6 + row) * 0.7;
          rect(g, row === 0 ? (this.cavern ? "#dcfaff" : "#d8f4d8") : (this.cavern ? "#85d6eb" : "#70c6b9"), rx, ry, 3 + hash(i, row, 80) * 10, 1);
        }
      }
      g.restore();
      if (!front && !this.cavern) {
        for (let i = 0; i < 4; i++) {
          const lx = x + 11 + hash(i, r.x, 90) * (r.w - 22), ly = y + 1 + hash(i, r.y, 91) * 4;
          g.fillStyle = "#256747"; g.beginPath(); g.ellipse(lx, ly, 5, 1.7, 0, 0.18, TAU - 0.1); g.lineTo(lx, ly); g.fill();
          rect(g, "#6b9f63", lx - 3, ly - 1, 5, 1);
          if (i % 3 === 0) { rect(g, "#e5b4b6", lx - 1, ly - 3, 3, 2); rect(g, "#f3ddab", lx, ly - 3, 1, 1); }
        }
      } else if (!front && this.cavern) {
        for (let i = 0; i < 5; i++) {
          const lx = x + 12 + hash(i, r.x, 51) * (r.w - 24), ly = y + 2 + hash(i, r.y, 52) * 4;
          g.globalAlpha = 0.3 + Math.sin(t * 1.4 + i) * 0.12;
          rect(g, i % 3 ? "#a0d9e2" : "#d2b0ec", lx, ly, 4 + i % 3, 1);
        }
        g.globalAlpha = 1;
      }
    }
    if (front) for (const r of this.ripples) {
      const p = r.age / r.life, rx = r.size * (0.3 + p), x = r.x - cl, y = r.y - ct;
      g.globalAlpha = (1 - p) * 0.75; g.strokeStyle = this.cavern ? "#d9f9ff" : "#e3f5e6"; g.lineWidth = 0.8;
      g.beginPath(); g.ellipse(x, y + 1, rx, Math.max(1, rx * 0.12), 0, 0, TAU); g.stroke();
      if (p < 0.7) for (let i = 0; i < 6; i++) {
        const dx = (i - 2.5) * r.size * p * 0.4, dy = -Math.sin(p * Math.PI) * r.size * (0.4 + hash(i, 1, 33) * 0.5);
        rect(g, this.cavern ? "#b6edff" : "#d2f0e3", x + dx, y + dy, 1, 1 + (1 - p) * 2);
      }
    }
    g.globalAlpha = 1;
  }

  drawWaterfall(g: Ctx, d: Dyn, cl: number, ct: number, W: number, H: number, t: number) {
    const x = d.x - cl, top = d.y - ct, bottom = top + d.h, half = (d.width ?? 32) / 2;
    if (x + half + 55 < 0 || x - half - 55 > W || bottom < -35 || top > H + 20) return;
    g.save();
    const halo = g.createRadialGradient(x, bottom - 5, 3, x, bottom - 5, half * 3.6);
    halo.addColorStop(0, this.cavern ? "rgba(107,232,255,0.3)" : "rgba(191,255,212,0.27)");
    halo.addColorStop(1, "rgba(130,230,230,0)");
    g.fillStyle = halo; g.fillRect(x - half * 3.6, bottom - half * 3.6 - 5, half * 7.2, half * 7.2);
    const water = g.createLinearGradient(x - half, 0, x + half, 0);
    water.addColorStop(0, "rgba(125,203,189,0.03)"); water.addColorStop(0.13, this.cavern ? "rgba(93,178,228,0.58)" : "rgba(123,207,199,0.55)");
    water.addColorStop(0.4, this.cavern ? "rgba(184,225,255,0.87)" : "rgba(214,241,224,0.91)"); water.addColorStop(0.65, "rgba(240,252,255,0.94)");
    water.addColorStop(0.89, this.cavern ? "rgba(116,178,230,0.6)" : "rgba(106,185,178,0.6)"); water.addColorStop(1, "rgba(126,210,191,0)");
    g.fillStyle = water; g.beginPath(); g.moveTo(x - half * 0.72, top);
    g.bezierCurveTo(x - half * 0.8, top + d.h * 0.4, x - half, bottom - 23, x - half * 1.24, bottom);
    g.lineTo(x + half * 1.27, bottom);
    g.bezierCurveTo(x + half * 0.9, bottom - 30, x + half * 0.85, top + d.h * 0.3, x + half * 0.73, top);
    g.closePath(); g.fill();
    // Three translucent ribbons sway independently inside the falling sheet.
    g.globalCompositeOperation = "screen";
    for (let ribbon = 0; ribbon < 3; ribbon++) {
      g.strokeStyle = this.cavern ? (ribbon === 1 ? "#e0bdff" : "#8adeff") : (ribbon === 1 ? "#ffffff" : "#a6f4e2");
      g.globalAlpha = 0.12 + ribbon * 0.04; g.lineWidth = 2 + ribbon;
      g.beginPath();
      for (let sy = Math.max(top, 0); sy <= Math.min(bottom, H); sy += 8) {
        const p = (sy - top) / Math.max(1, d.h);
        const sx = x + (ribbon - 1) * half * (0.28 + p * 0.22) + Math.sin(p * 14 - t * (2.1 + ribbon * 0.3) + ribbon * 3) * (2 + p * 3);
        if (sy === Math.max(top, 0)) g.moveTo(sx, sy); else g.lineTo(sx, sy);
      }
      g.stroke();
    }
    g.globalCompositeOperation = "source-over"; g.globalAlpha = 1;
    const y0 = Math.max(0, top), y1 = Math.min(H, bottom);
    for (let i = -Math.floor(half); i < half; i += 2) {
      const strip = hash(i, Math.floor(d.x), 13), speed = 78 + strip * 80;
      const len = 10 + strip * 25, period = len + 16 + hash(i, 3, 14) * 20;
      const edge = 1 - Math.pow(Math.abs(i) / half, 2);
      for (let y = y0; y < y1; y += 2) {
        const phase = ((y - top - t * speed + strip * 77) % period + period) % period;
        if (phase > len) continue;
        const spread = 0.7 + ((y - top) / d.h) * 0.48;
        const px = x + i * spread + Math.sin(y * 0.065 + t * 1.2 + strip * 8) * 0.7;
        g.globalAlpha = edge * (phase < 3 ? 0.78 : 0.28 + strip * 0.3);
        rect(g, phase < 5 ? "#f8ffff" : strip > 0.5 ? (this.cavern ? "#d8eaff" : "#d8f0e4") : (this.cavern ? "#8fd9ed" : "#9dd7cf"), px, y, i % 3 ? 1 : 2, 3);
      }
    }
    // A soft breaking lip, spray crown, and broad rolling mist give the falls their mass.
    g.globalAlpha = 0.88; g.strokeStyle = "#e8f6df"; g.lineWidth = 1.2;
    g.beginPath(); g.ellipse(x, top + 1, half * 0.75, 2.2, 0, Math.PI, TAU); g.stroke();
    for (let i = 0; i < 18; i++) {
      const p = (t * 0.9 + i * 0.147) % 1;
      const sx = x + (hash(i, Math.round(d.x), 21) - 0.5) * half * (1.7 + p * 1.3);
      const sy = bottom - Math.sin(p * Math.PI) * (6 + hash(i, 3, 22) * 12);
      g.globalAlpha = (1 - p) * 0.65;
      rect(g, "#ebf9ed", sx, sy, 1 + (i % 3 === 0 ? 1 : 0), 1);
    }
    for (let i = 0; i < 3; i++) {
      const p = (t * 0.45 + i / 3) % 1;
      g.globalAlpha = (1 - p) * 0.52;
      g.strokeStyle = "#dcf4e4"; g.lineWidth = 1;
      g.beginPath(); g.ellipse(x, bottom + 1 + p * 3, half * (0.65 + p * 1.6), 2 + p * 3, 0, 0, TAU); g.stroke();
    }
    for (let i = 0; i < 4; i++) {
      const spread = Math.sin(t * 0.65 + i * 2 + d.x) * 10;
      g.globalAlpha = 0.6;
      g.drawImage(this.mist, x - half * 2.2 + spread - 18 + i * 7, bottom - 28 - i * 3, half * 4.4 + 35, 48 + i * 7);
    }
    g.restore();
  }

}
