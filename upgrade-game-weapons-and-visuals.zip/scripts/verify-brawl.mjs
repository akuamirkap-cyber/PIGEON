import assert from "node:assert/strict";
import { chromium } from "playwright";

const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1157, height: 776 } });
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));

try {
  await page.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
  await page.getByRole("button", { name: /MASUK ARENA/ }).first().click();
  await page.getByRole("button", { name: "BRAWL LANGIT" }).click();
  assert(await page.getByAltText("Peta pulau terapung Brawl Langit").isVisible(), "Brawl map preview must be shown");
  await page.getByRole("button", { name: /MASUK ARENA/ }).last().click();
  await page.getByText(/BRAWL LANGIT · JATUH/).waitFor();

  const simulation = await browser.newPage();
  simulation.on("pageerror", (error) => errors.push(error.message));
  await simulation.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
  const result = await simulation.evaluate(async () => {
    const { ArenaGame } = await import("/src/arena/engine.ts");
    const { AIR, AT, getMap, solidPx } = await import("/src/arena/maps.ts");
    window.__chibi?.destroy();
    document.getElementById("root").innerHTML = "";
    const canvas = document.createElement("canvas");
    document.body.append(canvas);
    const game = new ArenaGame(canvas, { hud() {}, end() {} });
    game.start({ mode: "brawl", map: 2, size: 1, kills: 10, time: 3, diff: "easy", skin: 6, startWep: "bolter" });
    cancelAnimationFrame(game.raf);
    game.paused = true; game.phase = "live";
    const map = getMap(4), player = game.me;
    const geometry = {
      map: game.map.id,
      voidBelow: Array.from(map.grid.slice((map.h - 1) * map.w)).every((tile) => tile === AIR),
      spawnsClear: map.spawns.flat().every((spawn) => !solidPx(map, spawn.x, spawn.y - 10)),
      platforms: Array.from(map.grid).filter((tile) => tile === 3).length,
    };
    const initial = { hp: player.hp, armor: player.armor, nades: player.nades, fuel: player.fuel, weapon: player.slots[player.cur]?.id, slots: player.slots.filter(Boolean).map((slot) => slot.id) };
    const falls = [];
    for (let i = 0; i < 5; i++) {
      player.y = map.h * AT - 18; player.vx = player.vy = 0;
      game.step(1 / 60);
      falls.push({ hp: player.hp, alive: player.alive, score: [...game.score], y: player.y });
      if (!player.alive) break;
    }
    game.start({ mode: "brawl", map: 2, size: 2, kills: 10, time: 3, diff: "easy", skin: 6, startWep: "chainsword" });
    cancelAnimationFrame(game.raf);
    game.phase = "live";
    for (let i = 0; i < 240; i++) game.step(1 / 60);
    const botsStable = game.sol.every((soldier) => [soldier.x, soldier.y, soldier.vx, soldier.vy, soldier.hp].every(Number.isFinite));
    game.destroy();
    return { geometry, initial, falls, botsStable };
  });
  await simulation.close();

  assert.equal(result.geometry.map, 4);
  assert(result.geometry.voidBelow && result.geometry.spawnsClear && result.geometry.platforms > 20, "The floating stage must be playable above open air");
  assert.deepEqual(result.initial, { hp: 150, armor: 0, nades: 0, fuel: 0.3, weapon: "chainsword", slots: ["chainsword", "katana", "saber", "axe"] });
  assert.deepEqual(result.falls.map((fall) => fall.hp), [115, 80, 45, 10, 0], "Each fall must remove 35 HP without an immediate KO");
  assert(result.falls.slice(0, 4).every((fall) => fall.alive && fall.y < 400), "Nonlethal falls must return to the stage");
  assert(!result.falls[4].alive && result.falls[4].score[1] === 1, "A lethal ringout must score for the opposing team");
  assert(result.botsStable, "Brawl bots and player must remain stable during a live match");
  assert.deepEqual(errors, [], "The browser must not report runtime errors");
  console.log(JSON.stringify(result, null, 2));
} finally {
  await browser.close();
}