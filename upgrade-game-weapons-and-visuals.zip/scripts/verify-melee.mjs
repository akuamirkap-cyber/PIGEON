import assert from "node:assert/strict";
import { chromium } from "playwright";

const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1157, height: 776 } });
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));

try {
  await page.goto(process.env.TEST_URL ?? "http://localhost:5173", { waitUntil: "networkidle" });
  const result = await page.evaluate(async () => {
    const { ArenaGame } = await import("/src/arena/engine.ts");
    window.__chibi?.destroy();
    document.getElementById("root").innerHTML = "";
    const canvas = document.createElement("canvas");
    document.body.append(canvas);
    const game = new ArenaGame(canvas, { hud() {}, end() {} });
    game.start({ map: 2, size: 1, kills: 10, time: 3, diff: "easy", skin: 6, startWep: "chainsword" });
    cancelAnimationFrame(game.raf);
    game.paused = true;
    game.phase = "live";
    const player = game.me, enemy = game.sol.find((soldier) => soldier.team !== player.team);
    game.sol = [player];
    player.cur = 1;
    player.fireCd = player.swingT = 0;
    player.ground = true;
    const tick = () => game.step(1 / 60);
    const tap = () => {
      game.mouse.pressed = game.mouse.released = true;
      game.mouse.heldFor = 0.05;
      game.mouse.down = false;
      tick();
    };

    tap();
    const quick = { active: player.swingT > 0, heavy: player.swingHeavy, instant: player.swingQuick, duration: player.swingDur };
    tap();
    const buffered = player.queuedAttack === 1;
    for (let i = 0; i < 17; i++) tick();
    const spam = { started: player.swingT > 0 && player.queuedAttack === 0, heavy: player.swingHeavy };
    for (let i = 0; i < 17; i++) tick();
    const miss = { ready: player.swingT <= 0 && player.fireCd <= 0.03 };

    player.fireCd = player.swingT = 0;
    player.trig = false;
    game.mouse.down = game.mouse.pressed = true;
    tick();
    for (let i = 0; i < 45; i++) tick();
    const charging = { full: game.hudState().chargeReady, noPrematureSwing: player.swingT <= 0 };
    game.mouse.down = false;
    game.mouse.released = true;
    game.mouse.heldFor = 0.8;
    tick();
    const signature = { active: player.swingT > 0, heavy: player.swingHeavy, longerRecovery: player.fireCd > quick.duration + 0.25 };

    game.sol = [player, enemy];
    player.x = 160; player.y = 500; player.aim = 0; player.face = 1;
    enemy.x = player.x + 20; enemy.y = player.y; enemy.shield = 0; enemy.holo = false;
    const hits = [];
    game.hurt = (_enemy, damage, _by, _weapon, _angle, knock) => hits.push({ damage, knock });
    for (const heavy of [false, true]) {
      player.swingHit = [];
      player.swingPlane = "horiz"; player.swingKind = 1;
      player.swingDur = heavy ? 0.4 : 0.29;
      player.swingT = player.swingDur * 0.65;
      player.swingHeavy = heavy; player.swingQuick = !heavy;
      game.swingTick(player, 0.01);
    }
    const measuredHits = hits.slice();

    game.cancelMeleeCharge();
    player.swingT = player.fireCd = 0; player.trig = false;
    game.hitStop = game.slow = 0;
    game.sol = [player];
    game.mouse.down = game.mouse.pressed = true;
    tick();
    game.mouse.right = true;
    tick();
    const shieldKeepsCharge = player.chargeArmed && player.holo;
    for (let i = 0; i < 45; i++) tick();
    const shieldReady = game.hudState().chargeReady && player.holo;
    game.mouse.down = false; game.mouse.released = true; game.mouse.heldFor = 0.8;
    tick();
    const shieldRelease = !player.holo && player.swingHeavy && player.swingT > 0 && player.holoLock > 0;

    game.mouse.right = false;
    tick();
    player.cur = 0; player.fireCd = 0; player.trig = false;
    const before = player.slots[0].mag;
    game.mouse.down = game.mouse.pressed = true;
    tick();
    const rangedUnchanged = player.slots[0].mag === before - 1;
    const allMelee = [];
    for (const [name, slot] of [["chainsword", 1], ["katana", 12], ["saber", 13], ["axe", 14]]) {
      game.cancelMeleeCharge();
      player.cur = slot; player.fireCd = player.swingT = 0; player.trig = false;
      player.holo = false; player.holoK = 0; player.saberOn = 1;
      game.mouse.pressed = game.mouse.released = true;
      game.mouse.heldFor = 0.8;
      tick();
      allMelee.push({ name, signature: player.swingHeavy && player.swingT > 0 });
    }
    game.start({ mode: "brawl", map: 2, size: 1, kills: 10, time: 3, diff: "easy", skin: 6, startWep: "chainsword" });
    cancelAnimationFrame(game.raf);
    game.phase = "live";
    const striker = game.me, target = game.sol.find((soldier) => soldier.team !== striker.team);
    target.bot = null;
    game.sol = [striker, target];
    striker.x = 34 * 8; striker.y = 43 * 8; striker.vx = striker.vy = 0;
    striker.cur = 1; striker.fireCd = striker.swingT = 0; striker.trig = false;
    target.x = 52 * 8; target.y = striker.y; target.vx = target.vy = 0;
    const beforeDash = Math.hypot(target.x - striker.x, target.y - striker.y);
    game.startSwing(striker, false, true);
    const dashStarted = striker.signatureTarget === target && striker.swingT <= 0;
    for (let i = 0; i < 17; i++) tick();
    const dash = { started: dashStarted, approached: Math.hypot(target.x - striker.x, target.y - striker.y) < beforeDash - 25, attacked: striker.swingHeavy && striker.swingT > 0 };
    game.destroy();
    return { quick, buffered, spam, miss, charging, signature, hits: measuredHits, shieldKeepsCharge, shieldReady, shieldRelease, rangedUnchanged, allMelee, dash };
  });

  console.log(JSON.stringify(result, null, 2));
  assert(result.quick.active && result.quick.instant && !result.quick.heavy, "A tap must attack immediately without charge bonus");
  assert(result.buffered && result.spam.started && !result.spam.heavy, "Rapid taps must buffer the next light attack");
  assert(result.miss.ready, "A missed light attack must recover quickly");
  assert(result.charging.full && result.charging.noPrematureSwing, "Holding must charge without attacking before release");
  assert(result.signature.active && result.signature.heavy && result.signature.longerRecovery, "A full release must trigger a heavy signature with longer recovery");
  assert.equal(result.hits.length, 2, "Both attacks must reach the same target");
  assert(Math.abs(result.hits[1].damage / result.hits[0].damage - 1.5) < 0.01, "Only charged attacks receive the 50% damage bonus");
  assert(Math.abs(result.hits[1].knock / result.hits[0].knock - 1.45) < 0.01, "Only charged attacks receive the knockback bonus");
  assert(result.shieldKeepsCharge && result.shieldReady && result.shieldRelease, "A charge must complete behind the shield and release into a heavy attack");
  assert(result.rangedUnchanged, "Automatic guns must still fire on press");
  assert(result.allMelee.every((weapon) => weapon.signature), "Every equipped melee weapon must support a charged signature");
  assert(result.dash.started && result.dash.approached && result.dash.attacked, "A charged signature must close in on the nearest enemy before striking");
  assert.deepEqual(errors, [], "The browser must not report runtime errors");
} finally {
  await browser.close();
}