import { useEffect, useMemo, useState } from "react";
import { SKINS, skinToSpecies } from "../game/species";
import { spriteDataURL, coinSprite } from "../game/sprites";
import type { JawState } from "../game/sprites";
import type { SaveData } from "../save";
import { UPGRADE_COSTS, MAX_UPGRADE } from "../save";
import type { Upgrades } from "../game/engine";

interface Props {
  save: SaveData;
  setSave: (s: SaveData) => void;
  onPlay: () => void;
}

const UPGRADES: { id: keyof Upgrades; name: string; desc: string; icon: string }[] = [
  { id: "suck", name: "Sedotan Super", desc: "Jangkauan & kekuatan sedot lebih mantap", icon: "🌀" },
  { id: "speed", name: "Sirip Turbo", desc: "Berenang & belok lebih lincah", icon: "💨" },
  { id: "size", name: "Ikan Bongsor", desc: "Mulai sedikit lebih besar", icon: "🍔" },
];

export function coinURL() {
  return coinSprite(0).toDataURL();
}

const PREVIEW_CYCLE: JawState[] = [0, 0, 0, 1, 2, 3, 3, -1, -1, 0, 0];

export default function Menu({ save, setSave, onPlay }: Props) {
  const [tab, setTab] = useState<"skin" | "shop">("skin");
  const [animStep, setAnimStep] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setAnimStep((s) => (s + 1) % PREVIEW_CYCLE.length), 210);
    return () => clearInterval(id);
  }, []);

  const skinImgs = useMemo(
    () => Object.fromEntries(SKINS.map((s) => [s.id, spriteDataURL(skinToSpecies(s), 190, 0)])),
    []
  );

  const cur = SKINS.find((s) => s.id === save.skin) || SKINS[0];
  const heroFrames = useMemo(() => {
    const sp = skinToSpecies(cur);
    const states: JawState[] = [-1, 0, 1, 2, 3];
    return Object.fromEntries(states.map((st) => [st, spriteDataURL(sp, 240, st)])) as Record<JawState, string>;
  }, [cur]);

  const coin = useMemo(() => coinURL(), []);

  const pickSkin = (id: string, price: number) => {
    if (save.owned.includes(id)) setSave({ ...save, skin: id });
    else if (save.coins >= price) setSave({ ...save, coins: save.coins - price, owned: [...save.owned, id], skin: id });
  };

  const buyUp = (id: keyof Upgrades) => {
    const lv = save.upgrades[id];
    if (lv >= MAX_UPGRADE) return;
    const cost = UPGRADE_COSTS[lv];
    if (save.coins < cost) return;
    setSave({ ...save, coins: save.coins - cost, upgrades: { ...save.upgrades, [id]: lv + 1 } });
  };

  const curJaw = PREVIEW_CYCLE[animStep];

  return (
    <div
      className="absolute inset-0 flex overflow-y-auto p-3 clean-font"
      style={{ background: "radial-gradient(ellipse at center, rgba(8,30,68,0.22), rgba(4,14,38,0.72))" }}
    >
      <div className="m-auto w-full max-w-[1060px] flex flex-col items-center gap-3.5 py-3">
        {/* Title */}
        <div className="bob text-center select-none">
          <div className="title-outline font-bold text-[40px] sm:text-[58px] leading-none tracking-wide" style={{ color: "#ffe047" }}>
            FEEDING
          </div>
          <div className="title-outline font-bold text-[42px] sm:text-[62px] leading-none -mt-1 tracking-wide" style={{ color: "#ff8c38" }}>
            FRENZY<span style={{ color: "#63e6ff" }}>.io</span>
          </div>
          <div className="text-outline font-semibold text-[13px] sm:text-[16px] mt-1.5 text-amber-100">
            ✨ Pilih Ikan Feeding Frenzy Favoritmu, Sedot &amp; Lahap Semua! ✨
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 w-full items-stretch">
          {/* Left: Live Animated Hero Preview & Play */}
          <div className="wood-panel p-5 flex-1 flex flex-col items-center justify-between gap-3">
            <div className="flex flex-col items-center">
              <img
                src={heroFrames[curJaw]}
                className="bob h-32 object-contain drop-shadow-[0_6px_10px_rgba(0,0,0,0.5)]"
                alt={cur.name}
              />
              <div className="text-[16px] font-bold text-amber-100 text-outline -mt-1">
                {cur.name} <span className="text-amber-300 text-[13px]">({cur.subtitle})</span>
              </div>
            </div>

            <input
              value={save.name}
              maxLength={14}
              onChange={(e) => setSave({ ...save, name: e.target.value })}
              onKeyDown={(e) => {
                if (e.key === "Enter") onPlay();
              }}
              placeholder="Nama ikanmu..."
              className="w-full font-semibold text-[16px] text-center py-2.5 px-4 rounded-xl bg-[#291608] text-amber-50 border-2 border-[#5c3618] outline-none focus:border-yellow-300 placeholder:text-amber-200/50 shadow-inner"
            />
            <button
              onClick={onPlay}
              className="ui-btn w-full py-3.5 text-[23px] text-white tracking-wide"
              style={{ background: "linear-gradient(180deg, #45e078, #1fa84d)" }}
            >
              ▶ MAIN SEKARANG!
            </button>
            <div className="text-[12.5px] leading-relaxed text-amber-50 text-center font-medium bg-[#2b1708]/65 rounded-xl px-3 py-2 w-full border border-[#593418]">
              🖱️ Gerak ikan super mulus, lembut &amp; responsif mengikuti kursor!
              <br />
              <span className="text-yellow-300 font-bold">KLIK KIRI / SPASI</span> = <b>SEDOT</b> 🌀 •{" "}
              <span className="text-orange-300 font-bold">KLIK KANAN / SHIFT</span> = <b>BOOST</b> ⚡
              <br />
              Makan beruntun menyalakan papan <span className="text-yellow-200 font-bold">FRENZY!</span>
            </div>
            {save.best > 0 && (
              <div className="text-[14px] font-bold text-yellow-200 text-outline">
                🏆 Skor Rekor: {save.best.toLocaleString("en-US")}
              </div>
            )}
          </div>

          {/* Right: Feeding Frenzy Cast Skins & Upgrades */}
          <div className="wood-panel p-4 sm:p-5 flex-[1.48] flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <button
                  onClick={() => setTab("skin")}
                  className="ui-btn px-4 py-1.5 text-[15px] text-white"
                  style={{ background: tab === "skin" ? "linear-gradient(180deg, #ff9938, #d95b12)" : "#4d2c14" }}
                >
                  🐠 IKAN FRENZY
                </button>
                <button
                  onClick={() => setTab("shop")}
                  className="ui-btn px-4 py-1.5 text-[15px] text-white"
                  style={{ background: tab === "shop" ? "linear-gradient(180deg, #ff9938, #d95b12)" : "#4d2c14" }}
                >
                  ⚡ UPGRADE
                </button>
              </div>
              <div className="ff-carved-slot px-3 py-1 flex items-center gap-1.5 text-[18px] font-bold text-yellow-200">
                <img src={coin} className="w-6 h-6" alt="" />
                {save.coins}
              </div>
            </div>

            {tab === "skin" ? (
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {SKINS.map((s) => {
                  const owned = save.owned.includes(s.id);
                  const sel = save.skin === s.id;
                  const afford = save.coins >= s.price;
                  return (
                    <button
                      key={s.id}
                      onClick={() => pickSkin(s.id, s.price)}
                      className="ui-btn px-2 py-1.5 flex flex-col items-center"
                      style={{
                        background: sel
                          ? "linear-gradient(180deg, #ffe359, #eb9f12)"
                          : owned
                            ? "linear-gradient(180deg, #5c371b, #3d220e)"
                            : "#2b180a",
                        opacity: owned || afford ? 1 : 0.7,
                      }}
                    >
                      <img src={skinImgs[s.id]} className="h-12 object-contain drop-shadow" alt={s.name} />
                      <div className={`text-[13px] font-bold leading-tight ${sel ? "text-[#2b1504]" : "text-amber-50"}`}>{s.name}</div>
                      <div className={`text-[10px] leading-tight ${sel ? "text-[#4d2808]" : "text-amber-200/80"}`}>{s.subtitle}</div>
                      <div className={`text-[11px] font-bold mt-0.5 ${sel ? "text-[#3b1e00]" : "text-yellow-300"}`}>
                        {sel ? "✓ DIPAKAI" : owned ? "PAKAI" : `🪙 ${s.price}`}
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {UPGRADES.map((u) => {
                  const lv = save.upgrades[u.id];
                  const max = lv >= MAX_UPGRADE;
                  const cost = max ? 0 : UPGRADE_COSTS[lv];
                  return (
                    <div key={u.id} className="flex items-center gap-3 bg-[#2b180a]/85 border-2 border-[#5c3618] rounded-xl p-3">
                      <div className="text-[28px]">{u.icon}</div>
                      <div className="flex-1">
                        <div className="text-[15px] font-bold text-amber-50">{u.name}</div>
                        <div className="text-[12px] text-amber-200/85">{u.desc}</div>
                        <div className="flex gap-1.5 mt-1.5">
                          {Array.from({ length: MAX_UPGRADE }).map((_, i) => (
                            <div
                              key={i}
                              className="w-6 h-3 rounded-sm border border-[#1a0d04]"
                              style={{ background: i < lv ? "#eff52c" : "#422712" }}
                            />
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={() => buyUp(u.id)}
                        disabled={max || save.coins < cost}
                        className="ui-btn px-4 py-2 text-[14px] text-white disabled:opacity-50"
                        style={{ background: max ? "#5c534a" : "linear-gradient(180deg, #ff9938, #d95b12)" }}
                      >
                        {max ? "MAX" : `🪙 ${cost}`}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
