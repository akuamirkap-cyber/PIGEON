import type { Species } from "./species";

export type EyeExpr = "normal" | "happy" | "panic";
// jawState: -1 = puffed chomp/chew! 0 = closed, 1 = slightly open, 2 = half open, 3 = wide hinged gape!
export type JawState = -1 | 0 | 1 | 2 | 3;

export interface Sprite {
  canvas: HTMLCanvasElement;
  w: number;
  h: number;
}

function hexRgb(h: string): [number, number, number] {
  const s = h.startsWith("#") ? h.slice(1) : h;
  const n = parseInt(s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mixHex(a: string, b: string, t: number): string {
  const ca = hexRgb(a),
    cb = hexRgb(b);
  const r = Math.round(ca[0] + (cb[0] - ca[0]) * t);
  const g = Math.round(ca[1] + (cb[1] - ca[1]) * t);
  const bl = Math.round(ca[2] + (cb[2] - ca[2]) * t);
  return `rgb(${r},${g},${bl})`;
}

function rgbaHex(h: string, alpha: number): string {
  const [r, g, b] = hexRgb(h);
  return `rgba(${r},${g},${b},${alpha})`;
}

const TAIL_FRAMES = 6;
const cache = new Map<string, HTMLCanvasElement>();

export function fishMouthOffset(sp: Species, bodyLen: number): [number, number] {
  const rx = bodyLen * 0.41;
  const ry = rx * sp.hRatio * 1.05;
  const bx = bodyLen * 0.05;
  if (sp.style === "andy" || sp.style === "boris" || sp.style === "layla") {
    return [bx + rx * 1.02, ry * 0.16];
  }
  if (sp.style === "orca" || sp.style === "shark" || sp.style === "barracuda") {
    return [bx + rx * 0.94, ry * 0.18];
  }
  return [bx + rx * 0.92, ry * 0.16];
}

export function fishSprite(
  sp: Species,
  worldLen: number,
  jawState: JawState,
  tailPhase: number,
  key: string,
  pixelMode = false,
  expr: EyeExpr = "normal"
): Sprite {
  const tf = (((Math.floor((tailPhase / (Math.PI * 2)) * TAIL_FRAMES) % TAIL_FRAMES) + TAIL_FRAMES) % TAIL_FRAMES);
  const tierPx = pixelMode ? Math.max(26, Math.min(60, Math.round(worldLen * 1.45))) : worldLen < 26 ? 160 : 280;
  const ck = `${key}|${tierPx}|${jawState}|${tf}|${pixelMode ? 1 : 0}|${expr}`;
  let cv = cache.get(ck);
  if (!cv) {
    cv = renderFishCanvas(sp, tierPx, jawState, tf, pixelMode, expr);
    cache.set(ck, cv);
    if (cache.size > 1800) {
      const first = cache.keys().next().value;
      if (first) cache.delete(first);
    }
  }
  const aspect = cv.height / cv.width;
  const drawW = worldLen * 1.4;
  return { canvas: cv, w: drawW, h: drawW * aspect };
}

// Builds the authentic Feeding Frenzy silhouette (including Image 1's tall swept-back Angelfish diamond + protruding cute snout!)
function buildBodyPath(ctx: CanvasRenderingContext2D, sp: Species, bx: number, rx: number, ry: number, jawState: JawState) {
  const open = jawState > 0 ? jawState / 3 : 0; // 0 .. 1
  const puff = jawState === -1 ? 1 : 0; // soft puffed cheek on CHOMP!
  const isAngelfish = sp.style === "andy" || sp.style === "boris" || sp.style === "layla";
  const longBody = sp.style === "orca" || sp.style === "shark" || sp.style === "barracuda";

  ctx.beginPath();

  if (isAngelfish) {
    // ============ EXACT IMAGE 1 FEEDING FRENZY ANGELFISH / BUTTERFLYFISH SILHOUETTE ============
    // Narrow tail stem (caudal peduncle) -> S-curve up to high rear dorsal peak -> steep forehead -> protruding little snout -> tucked mouth & hinged lower jaw -> round belly!
    const stemX = bx - rx * 0.94;
    const stemH = ry * 0.12;
    const peakX = sp.style === "andy" ? bx - rx * 0.44 : sp.style === "boris" ? bx - rx * 0.34 : bx - rx * 0.28;
    const peakY = sp.style === "andy" ? -ry * 1.08 : -ry * 0.98;

    const snoutLift = open * ry * 0.24;
    const snoutX = bx + rx * (1.16 + puff * 0.03);
    const snoutY = ry * 0.03 - snoutLift;

    // Start at bottom of narrow tail stem, go to top of tail stem
    ctx.moveTo(stemX, -stemH);
    // Concave rear edge rising dramatically up to the high dorsal apex (just like Image 1!)
    ctx.bezierCurveTo(
      bx - rx * 0.72,
      -ry * 0.32,
      peakX - rx * 0.16,
      peakY + ry * 0.22,
      peakX,
      peakY
    );
    // Rounded dorsal tip -> smooth steep convex forehead sloping down toward the eye!
    ctx.bezierCurveTo(
      peakX + rx * 0.34,
      peakY - ry * 0.02,
      bx + rx * 0.56,
      -ry * 0.62 - snoutLift * 0.25,
      bx + rx * 0.82,
      -ry * 0.24 - snoutLift * 0.6
    );
    // Concave nasal bridge jutting forward into the cute protruding Feeding Frenzy snout/beak!
    ctx.quadraticCurveTo(
      bx + rx * 0.96,
      -ry * 0.07 - snoutLift * 0.85,
      snoutX,
      snoutY
    );
    // Rounded cute snout tip curving underneath to upper lip
    const upperLipX = bx + rx * (1.03 + puff * 0.02);
    const upperLipY = snoutY + ry * 0.11;
    ctx.quadraticCurveTo(snoutX + rx * 0.02, snoutY + ry * 0.08, upperLipX, upperLipY);

    if (open > 0) {
      // Hinged lower jaw dropping cleanly right underneath the protruding snout (just like Image 1!)
      const hingeX = bx + rx * (0.66 - open * 0.08);
      const hingeY = ry * 0.18;
      const jawDrop = open * ry * 0.46;
      const lowerTipX = bx + rx * (0.98 - open * 0.05);
      const lowerTipY = ry * 0.25 + jawDrop;

      ctx.quadraticCurveTo(bx + rx * 0.84, upperLipY + ry * 0.05, hingeX, hingeY);
      ctx.quadraticCurveTo(bx + rx * 0.8, lowerTipY - ry * 0.04, lowerTipX, lowerTipY);
      // Plump rounded chest & belly sweeping back to the narrow tail stem
      ctx.bezierCurveTo(
        lowerTipX - rx * 0.08,
        lowerTipY + ry * 0.26,
        bx + rx * 0.35,
        ry * (1.0 + open * 0.1),
        bx - rx * 0.38,
        ry * 0.88
      );
      ctx.bezierCurveTo(bx - rx * 0.68, ry * 0.72, bx - rx * 0.8, ry * 0.28, stemX, stemH);
    } else {
      const chinPuff = puff * ry * 0.1;
      // Subtle tucked mouth notch under the snout -> round chin -> full plump belly!
      ctx.quadraticCurveTo(bx + rx * 0.92 + puff * rx * 0.04, ry * 0.19, bx + rx * 0.94 + puff * rx * 0.04, ry * 0.31 + chinPuff);
      ctx.bezierCurveTo(
        bx + rx * 0.78,
        ry * 0.88 + chinPuff,
        bx + rx * 0.12,
        ry * 1.04 + chinPuff,
        bx - rx * 0.42,
        ry * 0.86
      );
      ctx.bezierCurveTo(bx - rx * 0.7, ry * 0.68, bx - rx * 0.8, ry * 0.26, stemX, stemH);
    }
  } else {
    // Other Feeding Frenzy cast silhouettes (Orca, Barracuda, Eddy, Leon, Pierre, Peter, Clown, Minnow) with tapered FF snout!
    const wy = ry * (sp.style === "barracuda" ? 0.16 : longBody ? 0.19 : 0.2);
    const upLift = open * ry * 0.3;
    const snoutX = bx + rx * (longBody ? 1.12 : 1.09 + puff * 0.03);
    const snoutY = ry * 0.02 - upLift;

    ctx.moveTo(bx - rx, -wy);
    if (longBody) {
      ctx.bezierCurveTo(bx - rx * 0.5, -ry * 0.86, bx + rx * 0.12, -ry * 1.02, bx + rx * 0.56, -ry * 0.76);
      ctx.bezierCurveTo(bx + rx * 0.84, -ry * 0.54, bx + rx * 1.02, -ry * 0.2 - upLift * 0.6, snoutX, snoutY);
    } else {
      ctx.bezierCurveTo(bx - rx * 0.52, -ry * 0.92, bx + rx * 0.14, -ry * 1.06, bx + rx * 0.58, -ry * 0.78);
      ctx.bezierCurveTo(bx + rx * 0.82, -ry * 0.54, bx + rx * 0.96, -ry * 0.16 - upLift * 0.6, snoutX, snoutY);
    }

    if (open > 0) {
      const hingeX = bx + rx * (longBody ? 0.46 : 0.56 - open * 0.09);
      const hingeY = ry * 0.16;
      const jawDrop = open * ry * (sp.style === "eddy" ? 0.66 : 0.54);
      const lowerTipX = bx + rx * (longBody ? 1.0 - open * 0.05 : 0.96 - open * 0.05);
      const lowerTipY = ry * 0.22 + jawDrop;

      ctx.quadraticCurveTo(bx + rx * 0.82, snoutY + ry * 0.08, hingeX, hingeY);
      ctx.quadraticCurveTo(bx + rx * 0.75, lowerTipY - ry * 0.05, lowerTipX, lowerTipY);
      ctx.bezierCurveTo(
        lowerTipX - rx * 0.08,
        lowerTipY + ry * 0.25,
        bx + rx * 0.44,
        ry * (0.98 + open * 0.15),
        bx - rx * 0.38,
        ry * 0.9
      );
      ctx.quadraticCurveTo(bx - rx * 0.74, ry * 0.74, bx - rx, wy);
    } else {
      const chinPuff = puff * ry * 0.1;
      ctx.quadraticCurveTo(snoutX + rx * 0.01, ry * 0.12, bx + rx * 0.94 + puff * rx * 0.03, ry * 0.22);
      ctx.quadraticCurveTo(bx + rx * 0.96 + puff * rx * 0.03, ry * 0.36 + chinPuff, bx + rx * 0.82, ry * 0.54 + chinPuff);
      ctx.bezierCurveTo(bx + rx * 0.5, ry * 0.98 + chinPuff, bx - rx * 0.42, ry * 0.94, bx - rx, wy);
    }
  }
  ctx.closePath();
}

export function renderFishCanvas(
  sp: Species,
  W: number,
  jawState: JawState,
  tailFrame: number,
  pixelMode: boolean,
  expr: EyeExpr
): HTMLCanvasElement {
  const extraTop = sp.lure || sp.spinyCrest || sp.style === "orca" ? 0.24 : 0.16;
  const aspect = Math.max(0.62, Math.min(1.22, sp.hRatio * 1.16 + extraTop));
  const H = Math.max(20, Math.round(W * aspect));
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext("2d")!;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";

  const bodyLen = W * 0.7;
  const rx = bodyLen * 0.41;
  const ry = rx * sp.hRatio * 1.05;
  const cx = W * 0.5;
  const cy = H * (sp.lure || sp.spinyCrest ? 0.58 : 0.53);
  const bx = cx + bodyLen * 0.05;
  const isAngelfish = sp.style === "andy" || sp.style === "boris" || sp.style === "layla";
  const longBody = sp.style === "orca" || sp.style === "shark" || sp.style === "barracuda";
  const wy = ry * (isAngelfish ? 0.12 : sp.style === "barracuda" ? 0.16 : longBody ? 0.19 : 0.2);

  // Soft painterly edge stroke instead of harsh thick black cartoon lines!
  const softRimW = Math.max(1.1, W * 0.014);

  const wagAng = (tailFrame / TAIL_FRAMES) * Math.PI * 2;
  const wag = Math.sin(wagAng);
  const wagY = wag * ry * 0.14;

  const finBase = sp.pal.fin;
  const finDark = mixHex(finBase, sp.pal.dark, 0.55);
  const finLight = mixHex(finBase, "#ffffff", 0.35);

  const tailBase = sp.pal.tail || finBase;
  const tailDark = mixHex(tailBase, sp.pal.dark, 0.38);
  const tailLight = mixHex(tailBase, "#ffffff", 0.5);

  // ---------- 0. EDDY'S SOFT BIOLUMINESCENT LURE ANTENNA ----------
  if (sp.lure) {
    ctx.save();
    const lx0 = bx + rx * 0.38,
      ly0 = cy - ry * 0.84;
    const bulbX = bx + rx * 1.06,
      bulbY = cy - ry * 1.14 + wag * ry * 0.06;
    ctx.beginPath();
    ctx.moveTo(lx0, ly0);
    ctx.bezierCurveTo(bx + rx * 0.35, cy - ry * 1.54, bx + rx * 0.98, cy - ry * 1.5, bulbX, bulbY);
    ctx.strokeStyle = sp.pal.dark;
    ctx.lineWidth = Math.max(2, W * 0.022);
    ctx.stroke();

    const lCol = sp.pal.lure || "#d9ff42";
    const lg = ctx.createRadialGradient(bulbX, bulbY, 0.5, bulbX, bulbY, ry * 0.52);
    lg.addColorStop(0, "#ffffff");
    lg.addColorStop(0.28, lCol);
    lg.addColorStop(0.65, rgbaHex(lCol, 0.32));
    lg.addColorStop(1, "rgba(217,255,66,0)");
    ctx.fillStyle = lg;
    ctx.beginPath();
    ctx.arc(bulbX, bulbY, ry * 0.52, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // ---------- 1. SOFT RAYED TAIL FIN (Image 1 creamy-white fan wedge for Andy!) ----------
  const tx0 = bx - rx * (isAngelfish ? 0.9 : 0.94);
  const tailLen = rx * (sp.style === "orca" || sp.style === "shark" ? 0.76 : isAngelfish ? 0.58 : 0.66) * (1 - Math.abs(wag) * 0.06);
  const tailH = ry * (sp.style === "orca" || sp.style === "shark" ? 0.82 : isAngelfish ? 0.52 : 0.68);

  ctx.save();
  ctx.beginPath();
  if (sp.style === "minnow" || sp.style === "barracuda" || sp.style === "shark" || sp.style === "orca" || sp.style === "layla") {
    const topBoost = sp.style === "shark" ? 1.15 : 1;
    ctx.moveTo(tx0, cy - wy * 0.9);
    ctx.quadraticCurveTo(tx0 - tailLen * 0.55, cy - tailH * 0.92 * topBoost + wagY * 0.5, tx0 - tailLen, cy - tailH * topBoost + wagY);
    ctx.quadraticCurveTo(tx0 - tailLen * 0.5, cy - tailH * 0.14 + wagY * 0.7, tx0 - tailLen * 0.42, cy + wagY * 0.6);
    ctx.quadraticCurveTo(tx0 - tailLen * 0.5, cy + tailH * 0.14 + wagY * 0.7, tx0 - tailLen * 0.94, cy + tailH * 0.9 + wagY);
    ctx.quadraticCurveTo(tx0 - tailLen * 0.5, cy + tailH * 0.86 + wagY * 0.5, tx0, cy + wy * 0.9);
  } else {
    // Clean Feeding Frenzy triangular-fan wedge tail (exact match to Image 1's white-gold tail!)
    ctx.moveTo(tx0, cy - wy * 0.95);
    ctx.quadraticCurveTo(tx0 - tailLen * 0.55, cy - tailH * 0.88 + wagY * 0.5, tx0 - tailLen * 0.96, cy - tailH * 0.92 + wagY);
    ctx.bezierCurveTo(
      tx0 - tailLen * 1.12,
      cy - tailH * 0.38 + wagY,
      tx0 - tailLen * 1.12,
      cy + tailH * 0.38 + wagY,
      tx0 - tailLen * 0.96,
      cy + tailH * 0.92 + wagY
    );
    ctx.quadraticCurveTo(tx0 - tailLen * 0.55, cy + tailH * 0.88 + wagY * 0.5, tx0, cy + wy * 0.95);
  }
  ctx.closePath();

  const tg = ctx.createLinearGradient(tx0, cy, tx0 - tailLen * 1.08, cy + wagY);
  if (sp.style === "andy") {
    // Warm orange peduncle blending softly into bright creamy-white fan tail (exact Image 1!)
    tg.addColorStop(0, mixHex(sp.pal.dark, "#ffae38", 0.5));
    tg.addColorStop(0.28, "#ffe794");
    tg.addColorStop(0.68, "#fffdf2");
    tg.addColorStop(1, "rgba(255, 255, 255, 0.88)");
  } else {
    tg.addColorStop(0, tailDark);
    tg.addColorStop(0.55, tailBase);
    tg.addColorStop(1, tailLight);
  }
  ctx.fillStyle = tg;
  ctx.fill();

  if (W >= 60) {
    ctx.save();
    ctx.clip();
    if (sp.style === "leon") {
      ctx.fillStyle = sp.pal.spot || "#45190c";
      ctx.globalAlpha = 0.55;
      for (const [dx, dy] of [
        [0.45, -0.35],
        [0.72, -0.45],
        [0.65, 0],
        [0.48, 0.35],
        [0.75, 0.42],
      ]) {
        ctx.beginPath();
        ctx.arc(tx0 - tailLen * dx, cy + tailH * dy + wagY * 0.7, ry * 0.055, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    } else {
      ctx.strokeStyle = sp.style === "andy" ? "rgba(230, 155, 55, 0.32)" : rgbaHex(sp.pal.outline, 0.25);
      ctx.lineWidth = Math.max(0.9, softRimW * 0.7);
      for (const k of [-0.55, -0.26, 0, 0.26, 0.55]) {
        ctx.beginPath();
        ctx.moveTo(tx0, cy + k * wy);
        ctx.lineTo(tx0 - tailLen * 0.96, cy + k * tailH * 0.85 + wagY);
        ctx.stroke();
      }
    }
    ctx.restore();
  }
  ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.45);
  ctx.lineWidth = softRimW * 0.9;
  ctx.stroke();
  ctx.restore();

  // ---------- 2. DORSAL & RAYED ANAL FINS ----------
  if (sp.spinyCrest) {
    const rays = sp.style === "leon" ? 7 : 5;
    for (let i = 0; i < rays; i++) {
      const f = i / (rays - 1);
      const rx0 = bx + rx * (0.28 - f * 0.92);
      const ry0 = cy - ry * (0.86 - Math.abs(f - 0.35) * 0.22);
      const ang = -Math.PI * 0.56 - f * 0.42 + wag * 0.05;
      const len = ry * (sp.style === "leon" ? 0.92 - Math.abs(f - 0.35) * 0.38 : 0.72 - f * 0.25);
      const tipX = rx0 + Math.cos(ang) * len;
      const tipY = ry0 + Math.sin(ang) * len;
      const wRay = rx * (sp.style === "leon" ? 0.052 : 0.062);

      ctx.beginPath();
      ctx.moveTo(rx0 - wRay, ry0 + ry * 0.08);
      ctx.quadraticCurveTo((rx0 + tipX) * 0.5 - wRay * 0.5, (ry0 + tipY) * 0.5, tipX, tipY);
      ctx.quadraticCurveTo((rx0 + tipX) * 0.5 + wRay * 0.5, (ry0 + tipY) * 0.5, rx0 + wRay, ry0 + ry * 0.08);
      ctx.closePath();
      ctx.fillStyle = sp.style === "leon" ? (i % 2 === 0 ? "#fff5eb" : "#e85a2c") : "#ffe43b";
      ctx.fill();
      ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.55);
      ctx.lineWidth = softRimW * 0.85;
      ctx.stroke();
    }
  } else if (!isAngelfish) {
    // Non-angelfish dorsal fin (Angelfish dorsal crest is seamlessly part of its tall triangular body like Image 1!)
    ctx.beginPath();
    if (sp.style === "orca" || sp.style === "shark") {
      ctx.moveTo(bx + rx * 0.14, cy - ry * 0.86);
      ctx.quadraticCurveTo(bx - rx * 0.04, cy - ry * 1.72, bx - rx * 0.34, cy - ry * 1.74);
      ctx.quadraticCurveTo(bx - rx * 0.2, cy - ry * 1.15, bx - rx * 0.38, cy - ry * 0.78);
    } else if (sp.style === "clown") {
      ctx.moveTo(bx + rx * 0.24, cy - ry * 0.84);
      ctx.quadraticCurveTo(bx + rx * 0.04, cy - ry * 1.32, bx - rx * 0.2, cy - ry * 1.1);
      ctx.quadraticCurveTo(bx - rx * 0.46, cy - ry * 1.36, bx - rx * 0.74, cy - ry * 1.0);
      ctx.quadraticCurveTo(bx - rx * 0.84, cy - ry * 0.72, bx - rx * 0.78, cy - wy * 0.8);
    } else {
      ctx.moveTo(bx + rx * 0.26, cy - ry * 0.82);
      ctx.bezierCurveTo(bx - rx * 0.05, cy - ry * 1.3, bx - rx * 0.58, cy - ry * 1.28, bx - rx * 0.84, cy - ry * 0.86);
      ctx.lineTo(bx - rx * 0.78, cy - wy * 0.8);
    }
    ctx.closePath();
    const dg = ctx.createLinearGradient(bx, cy - ry * 1.5, bx, cy - ry * 0.7);
    dg.addColorStop(0, finLight);
    dg.addColorStop(0.65, finBase);
    dg.addColorStop(1, finDark);
    ctx.fillStyle = dg;
    ctx.fill();
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.55);
    ctx.lineWidth = softRimW;
    ctx.stroke();
  } else if (sp.style === "boris" || sp.style === "layla") {
    // Subtle yellow/cyan dorsal rim ribbon along the upper-back slope of Boris / Layla
    ctx.beginPath();
    ctx.moveTo(bx + rx * 0.26, cy - ry * 0.72);
    ctx.bezierCurveTo(bx - rx * 0.05, cy - ry * 1.18, bx - rx * 0.58, cy - ry * 1.2, bx - rx * 0.84, cy - ry * 0.45);
    ctx.lineTo(bx - rx * 0.78, cy - wy * 0.8);
    ctx.closePath();
    ctx.fillStyle = finBase;
    ctx.fill();
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.45);
    ctx.lineWidth = softRimW;
    ctx.stroke();
  }

  // Lower-Rear Rayed Anal Fin (matches the striped lower-rear fan fin visible on Image 1!)
  ctx.save();
  ctx.beginPath();
  if (isAngelfish) {
    ctx.moveTo(bx - rx * 0.14, cy + ry * 0.86);
    ctx.bezierCurveTo(
      bx - rx * 0.26,
      cy + ry * 1.16,
      bx - rx * 0.62,
      cy + ry * 1.18,
      bx - rx * 0.8,
      cy + ry * 0.56 + wagY * 0.2
    );
    ctx.lineTo(bx - rx * 0.86, cy + wy * 0.9);
  } else {
    ctx.moveTo(bx - rx * 0.08, cy + ry * 0.78);
    ctx.quadraticCurveTo(bx - rx * 0.44, cy + ry * 1.22, bx - rx * 0.76, cy + ry * 0.88);
    ctx.lineTo(bx - rx * 0.8, cy + wy * 0.8);
  }
  ctx.closePath();
  const ag = ctx.createLinearGradient(bx - rx * 0.2, cy + ry * 0.75, bx - rx * 0.75, cy + ry * 1.18);
  ag.addColorStop(0, finDark);
  ag.addColorStop(0.6, finBase);
  ag.addColorStop(1, finLight);
  ctx.fillStyle = ag;
  ctx.fill();
  ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.55);
  ctx.lineWidth = softRimW;
  ctx.stroke();

  // Delicate dark fin rays clipped cleanly inside anal fin (just like Image 1!)
  if (W >= 55) {
    ctx.save();
    ctx.clip();
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.45);
    ctx.lineWidth = Math.max(1, softRimW * 0.85);
    for (let i = 0; i < 5; i++) {
      const f = i / 4;
      ctx.beginPath();
      ctx.moveTo(bx - rx * (0.22 + f * 0.5), cy + ry * 0.72);
      ctx.lineTo(bx - rx * (0.34 + f * 0.5), cy + ry * 1.2);
      ctx.stroke();
    }
    ctx.restore();
  }
  ctx.restore();

  // ---------- 3. HINGED OPEN MOUTH INTERIOR (soft warm shaded throat under protruding snout!) ----------
  const open = jawState > 0 ? jawState / 3 : 0;
  if (open > 0) {
    ctx.save();
    ctx.translate(0, cy);
    const snoutLift = open * ry * (isAngelfish ? 0.24 : 0.3);
    const upperX = bx + rx * (isAngelfish ? 1.01 : longBody ? 1.06 : 1.02);
    const upperY = ry * (isAngelfish ? 0.12 : 0.04) - snoutLift;
    const hingeX = bx + rx * (isAngelfish ? 0.64 - open * 0.08 : longBody ? 0.44 : 0.54 - open * 0.09);
    const hingeY = ry * 0.17;
    const jawDrop = open * ry * (isAngelfish ? 0.46 : sp.style === "eddy" ? 0.66 : 0.54);
    const lowerX = bx + rx * (0.96 - open * 0.05);
    const lowerY = ry * 0.24 + jawDrop;

    ctx.beginPath();
    ctx.moveTo(upperX, upperY);
    ctx.quadraticCurveTo(bx + rx * (0.86 - open * 0.05), (upperY + lowerY) * 0.5, lowerX, lowerY);
    ctx.lineTo(hingeX - rx * 0.07, hingeY + ry * 0.16);
    ctx.lineTo(hingeX - rx * 0.07, hingeY - ry * 0.16);
    ctx.closePath();

    const mg = ctx.createRadialGradient(
      hingeX + rx * 0.08,
      hingeY + jawDrop * 0.3,
      ry * 0.04,
      (upperX + lowerX) * 0.5,
      (upperY + lowerY) * 0.5,
      ry * 0.55
    );
    mg.addColorStop(0, "#2b060f");
    mg.addColorStop(0.65, "#6b1528");
    mg.addColorStop(1, "#9c283e");
    ctx.fillStyle = mg;
    ctx.fill();

    ctx.save();
    ctx.clip();
    // Soft warm tongue inside lower jaw
    ctx.beginPath();
    ctx.ellipse((hingeX + lowerX) * 0.54, lowerY - ry * 0.04, rx * (0.18 + open * 0.06), ry * (0.1 + open * 0.08), 0.12, 0, Math.PI * 2);
    ctx.fillStyle = "#e85d88";
    ctx.fill();

    if (sp.teeth || sp.underbite) {
      ctx.fillStyle = "#fff8ee";
      for (let i = 0; i < 3; i++) {
        const t = (i + 0.5) / 3;
        if (!sp.underbite) {
          const tx = hingeX + (upperX - hingeX) * (0.35 + t * 0.55);
          const ty = upperY + (hingeY - upperY) * (1 - (0.35 + t * 0.55));
          ctx.beginPath();
          ctx.moveTo(tx - rx * 0.04, ty - ry * 0.02);
          ctx.lineTo(tx, ty + ry * 0.13 * open + ry * 0.03);
          ctx.lineTo(tx + rx * 0.04, ty - ry * 0.02);
          ctx.closePath();
          ctx.fill();
        }
        const bxT = hingeX + (lowerX - hingeX) * (0.35 + t * 0.55);
        const byT = hingeY + (lowerY - hingeY) * (0.35 + t * 0.55);
        ctx.beginPath();
        ctx.moveTo(bxT - rx * 0.04, byT + ry * 0.03);
        ctx.lineTo(bxT, byT - ry * 0.14 * open - ry * 0.03);
        ctx.lineTo(bxT + rx * 0.04, byT + ry * 0.03);
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.restore();
    ctx.restore();
  }

  // ---------- 4. SOFT 3D AIRBRUSHED BODY SHADING & PATTERNS (Image 1 Look!) ----------
  ctx.save();
  ctx.translate(0, cy);
  buildBodyPath(ctx, sp, bx, rx, ry, jawState);

  // Base vertical tone
  const baseGrad = ctx.createLinearGradient(bx, -ry * 1.05, bx, ry * 1.05);
  baseGrad.addColorStop(0, sp.pal.dark);
  baseGrad.addColorStop(0.45, sp.pal.body);
  baseGrad.addColorStop(0.85, mixHex(sp.pal.body, sp.pal.belly, 0.5));
  baseGrad.addColorStop(1, mixHex(sp.pal.dark, sp.pal.belly, 0.35));
  ctx.fillStyle = baseGrad;
  ctx.fill();

  ctx.save();
  ctx.clip();

  // Warm 3D spherical inner glow in the middle of the body (gives that plush pre-rendered PopCap 3D volume!)
  if (sp.style !== "orca") {
    const coreGrad = ctx.createRadialGradient(
      bx - rx * 0.05,
      -ry * 0.05,
      ry * 0.08,
      bx - rx * 0.05,
      0,
      Math.max(rx, ry) * 0.95
    );
    coreGrad.addColorStop(0, mixHex(sp.pal.belly, "#ffffff", 0.25));
    coreGrad.addColorStop(0.52, rgbaHex(sp.pal.body, 0.35));
    coreGrad.addColorStop(1, rgbaHex(sp.pal.dark, 0.65));
    ctx.fillStyle = coreGrad;
    ctx.fillRect(bx - rx * 1.3, -ry * 1.3, rx * 2.7, ry * 2.6);
  }

  // Species-specific markings
  if (sp.style === "orca") {
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.moveTo(bx + rx * 1.15, ry * 0.12);
    ctx.bezierCurveTo(bx + rx * 0.55, ry * 0.18, bx + rx * 0.1, ry * 0.45, bx - rx * 0.18, ry * 0.35);
    ctx.bezierCurveTo(bx - rx * 0.42, ry * 0.26, bx - rx * 0.58, -ry * 0.08, bx - rx * 0.78, ry * 0.08);
    ctx.quadraticCurveTo(bx - rx * 0.55, ry * 0.42, bx - rx * 1.05, ry * 0.48);
    ctx.lineTo(bx - rx * 1.05, ry * 1.3);
    ctx.lineTo(bx + rx * 1.2, ry * 1.3);
    ctx.closePath();
    ctx.fill();

    ctx.save();
    ctx.translate(bx + rx * 0.12, -ry * 0.24);
    ctx.rotate(-0.18);
    ctx.beginPath();
    ctx.ellipse(0, 0, rx * 0.22, ry * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else if (sp.style === "andy") {
    // ============ EXACT IMAGE 1 SWEEPING MAGENTA-VIOLET STRIPES ============
    // Flowing S-curved ribbons sweeping from the snout/cheek diagonally up toward the high dorsal peak & rear flank!
    const stCol = sp.pal.stripe || "#df22ff";
    const stGlow = mixHex(stCol, "#ffffff", 0.42);
    const drawAndyStripe = (x0: number, y0: number, cx1: number, cy1: number, cx2: number, cy2: number, x1: number, y1: number, w: number) => {
      // Soft outer magenta bloom
      ctx.strokeStyle = rgbaHex(stCol, 0.38);
      ctx.lineWidth = w * 1.65;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.bezierCurveTo(cx1, cy1, cx2, cy2, x1, y1);
      ctx.stroke();
      // Main vibrant stripe
      ctx.strokeStyle = stCol;
      ctx.lineWidth = w;
      ctx.stroke();
      // Soft bright inner core
      ctx.strokeStyle = rgbaHex(stGlow, 0.65);
      ctx.lineWidth = w * 0.38;
      ctx.stroke();
    };

    const sw = ry * 0.1;
    // Stripe 1: Upper forehead above eye -> sweeps smoothly up to upper dorsal slope (exact Image 1!)
    drawAndyStripe(
      bx + rx * 0.66, -ry * 0.34,
      bx + rx * 0.42, -ry * 0.42,
      bx + rx * 0.14, -ry * 0.72,
      bx - rx * 0.24, -ry * 0.98,
      sw * 0.9
    );
    // Stripe 2: Under eye / cheek -> sweeps diagonally up to high dorsal peak!
    drawAndyStripe(
      bx + rx * 0.78, ry * 0.12,
      bx + rx * 0.28, ry * 0.06,
      bx - rx * 0.04, -ry * 0.46,
      bx - rx * 0.42, -ry * 1.05,
      sw
    );
    // Stripe 3: Lower gill / chest -> curves across mid-flank up to rear dorsal tip!
    drawAndyStripe(
      bx + rx * 0.52, ry * 0.44,
      bx + rx * 0.04, ry * 0.46,
      bx - rx * 0.24, -ry * 0.14,
      bx - rx * 0.5, -ry * 0.92,
      sw * 1.04
    );
    // Stripe 4: Lower belly -> sweeps up along the rear flank contour!
    drawAndyStripe(
      bx + rx * 0.24, ry * 0.74,
      bx - rx * 0.22, ry * 0.76,
      bx - rx * 0.48, ry * 0.24,
      bx - rx * 0.62, -ry * 0.62,
      sw * 0.96
    );
  } else if (sp.style === "boris") {
    ctx.fillStyle = sp.pal.stripe || "#3562c9";
    for (const sx of [-0.46, -0.04]) {
      const x0 = bx + rx * sx;
      const wB = rx * 0.22;
      ctx.beginPath();
      ctx.moveTo(x0 - wB * 0.4, -ry * 1.15);
      ctx.quadraticCurveTo(x0 - wB * 1.05, 0, x0 - wB * 0.3, ry * 1.15);
      ctx.lineTo(x0 + wB * 0.65, ry * 1.15);
      ctx.quadraticCurveTo(x0 - wB * 0.1, 0, x0 + wB * 0.55, -ry * 1.15);
      ctx.closePath();
      ctx.fill();
    }
    ctx.strokeStyle = "#1d3570";
    ctx.lineWidth = rx * 0.16;
    ctx.beginPath();
    ctx.moveTo(bx + rx * 0.54, -ry * 1.0);
    ctx.quadraticCurveTo(bx + rx * 0.64, 0, bx + rx * 0.5, ry * 1.0);
    ctx.stroke();
    ctx.fillStyle = "#172542";
    ctx.beginPath();
    ctx.arc(bx - rx * 0.74, 0, ry * 0.14, 0, Math.PI * 2);
    ctx.fill();
  } else if (sp.style === "layla") {
    ctx.strokeStyle = sp.pal.stripe || "#28b2d4";
    ctx.lineWidth = ry * 0.095;
    ctx.beginPath();
    ctx.moveTo(bx + rx * 0.98, -ry * 0.02);
    ctx.quadraticCurveTo(bx + rx * 0.45, ry * 0.2, bx + rx * 0.05, ry * 0.75);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(bx + rx * 0.9, ry * 0.22);
    ctx.quadraticCurveTo(bx + rx * 0.5, ry * 0.44, bx + rx * 0.22, ry * 0.88);
    ctx.stroke();
    for (const s of [-0.45, -0.18, 0.08]) {
      ctx.beginPath();
      ctx.moveTo(bx + rx * s, -ry * 0.98);
      ctx.quadraticCurveTo(bx + rx * (s + 0.12), -ry * 0.48, bx + rx * (s - 0.06), -ry * 0.22);
      ctx.stroke();
    }
  } else if (sp.style === "peter") {
    ctx.strokeStyle = sp.pal.stripe || "#ffe43b";
    ctx.lineWidth = ry * 0.11;
    for (const yy of [-0.48, -0.16, 0.22, 0.52]) {
      ctx.beginPath();
      ctx.moveTo(bx - rx * 0.88, ry * yy);
      ctx.quadraticCurveTo(bx - rx * 0.15, ry * (yy - 0.1), bx + rx * 0.42, ry * (yy + 0.05));
      ctx.stroke();
    }
    ctx.fillStyle = "#ffe43b";
    ctx.beginPath();
    ctx.ellipse(bx - rx * 0.16, ry * 0.02, rx * 0.24, ry * 0.23, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#142416";
    ctx.beginPath();
    ctx.ellipse(bx - rx * 0.16, ry * 0.02, rx * 0.16, ry * 0.15, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (sp.style === "barracuda") {
    ctx.strokeStyle = sp.pal.stripe || "#2d5563";
    ctx.lineWidth = rx * 0.075;
    ctx.globalAlpha = 0.55;
    for (const s of [-0.62, -0.36, -0.1, 0.16]) {
      ctx.beginPath();
      ctx.moveTo(bx + rx * s, -ry * 1.0);
      ctx.lineTo(bx + rx * (s - 0.06), ry * 0.05);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  } else if (sp.style === "minnow") {
    ctx.strokeStyle = "rgba(225, 255, 255, 0.72)";
    ctx.lineWidth = ry * 0.16;
    ctx.beginPath();
    ctx.moveTo(bx - rx * 0.85, 0);
    ctx.quadraticCurveTo(bx, -ry * 0.1, bx + rx * 0.45, -ry * 0.04);
    ctx.stroke();
  }

  for (const s of sp.stripes) {
    const sx = bx + rx * s;
    const sw = rx * (sp.style === "leon" ? 0.14 : 0.19);
    ctx.beginPath();
    ctx.moveTo(sx - sw * 0.4, -ry * 1.15);
    ctx.quadraticCurveTo(sx - sw * 0.95, 0, sx - sw * 0.4, ry * 1.15);
    ctx.lineTo(sx + sw * 0.6, ry * 1.15);
    ctx.quadraticCurveTo(sx + sw * 0.05, 0, sx + sw * 0.6, -ry * 1.15);
    ctx.closePath();
    ctx.fillStyle = sp.pal.stripe || "#ffffff";
    ctx.fill();
    if (sp.style === "clown") {
      ctx.lineWidth = Math.max(1.1, softRimW * 0.9);
      ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.65);
      ctx.stroke();
    }
  }

  if (sp.spots && sp.style !== "leon") {
    ctx.fillStyle = sp.pal.spot || "#ffffff";
    ctx.globalAlpha = sp.style === "pierre" ? 0.88 : 0.55;
    const pts: [number, number, number][] =
      sp.style === "pierre"
        ? [
            [-0.62, -0.32, 0.075],
            [-0.38, -0.52, 0.085],
            [-0.1, -0.58, 0.085],
            [0.16, -0.5, 0.075],
            [-0.5, -0.05, 0.08],
            [-0.22, -0.22, 0.09],
            [0.05, -0.2, 0.08],
            [-0.32, 0.14, 0.07],
          ]
        : [
            [-0.48, -0.22, 0.085],
            [-0.2, -0.34, 0.095],
            [0.05, -0.24, 0.075],
            [-0.34, 0.1, 0.075],
          ];
    for (const [px, py, pr] of pts) {
      ctx.beginPath();
      ctx.ellipse(bx + rx * px, ry * py, rx * pr * 1.25, ry * pr, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  // ============ SOFT 3D CURVED GILL OPERCULUM CREASE (Exact match to Image 1 behind the eye!) ============
  if (W >= 48 && sp.style !== "orca") {
    const gx = bx + rx * (isAngelfish ? 0.52 : 0.36);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(gx + rx * 0.04, -ry * 0.34);
    ctx.quadraticCurveTo(gx - rx * 0.08, ry * 0.12, gx - rx * 0.2, ry * 0.52);
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.45);
    ctx.lineWidth = Math.max(1.4, softRimW * 1.35);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(gx + rx * 0.07, -ry * 0.32);
    ctx.quadraticCurveTo(gx - rx * 0.05, ry * 0.12, gx - rx * 0.17, ry * 0.5);
    ctx.strokeStyle = "rgba(255, 240, 195, 0.32)";
    ctx.lineWidth = Math.max(1, softRimW * 0.85);
    ctx.stroke();
    ctx.restore();
  }

  // Soft 3D inner shadow around belly & back edges for lush airbrushed depth
  buildBodyPath(ctx, sp, bx, rx, ry, jawState);
  ctx.strokeStyle = rgbaHex(sp.pal.dark, 0.45);
  ctx.lineWidth = softRimW * 2.8;
  ctx.stroke();

  // Soft satin top sheen along upper forehead/flank
  const sheen = ctx.createRadialGradient(bx + rx * 0.08, -ry * 0.48, ry * 0.02, bx + rx * 0.08, -ry * 0.48, rx * 0.55);
  sheen.addColorStop(0, "rgba(255, 255, 255, 0.32)");
  sheen.addColorStop(1, "rgba(255, 255, 255, 0)");
  ctx.fillStyle = sheen;
  ctx.beginPath();
  ctx.ellipse(bx + rx * 0.08, -ry * 0.48, rx * 0.52, ry * 0.22, -0.3, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore(); // end body clip

  // Subtle refined outer body rim (soft dark-warm edge instead of heavy comic black!)
  buildBodyPath(ctx, sp, bx, rx, ry, jawState);
  ctx.lineWidth = softRimW;
  ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.68);
  ctx.stroke();

  // ---------- 5. SOFT MOUTH DETAILS (Under-snout lip / Chomp puff / Eddy underbite) ----------
  const puff = jawState === -1 ? 1 : 0;
  if (open > 0) {
    const hingeX = bx + rx * (isAngelfish ? 0.66 - open * 0.08 : longBody ? 0.46 : 0.56 - open * 0.09);
    const hingeY = ry * 0.17;
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.6);
    ctx.lineWidth = Math.max(1.2, softRimW * 1.1);
    ctx.beginPath();
    ctx.arc(hingeX - rx * 0.03, hingeY, ry * 0.085, Math.PI * 0.65, Math.PI * 1.38);
    ctx.stroke();
  } else if (puff > 0) {
    // Soft puffed "NGEHAP!" chomp smile under snout
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.72);
    ctx.lineWidth = Math.max(1.4, softRimW * 1.25);
    ctx.beginPath();
    ctx.moveTo(bx + rx * (isAngelfish ? 1.04 : 1.0), ry * 0.16);
    ctx.quadraticCurveTo(bx + rx * 0.86, ry * 0.28, bx + rx * 0.72, ry * 0.17);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(bx + rx * 0.7, ry * 0.17, ry * 0.09, Math.PI * 0.6, Math.PI * 1.42);
    ctx.stroke();
  } else {
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.68);
    ctx.lineWidth = Math.max(1.2, softRimW * 1.1);
    if (sp.underbite) {
      ctx.beginPath();
      ctx.moveTo(bx + rx * 0.98, ry * 0.18);
      ctx.quadraticCurveTo(bx + rx * 0.82, ry * 0.26, bx + rx * 0.68, ry * 0.18);
      ctx.stroke();
      if (W >= 55) {
        ctx.fillStyle = "#fffaf0";
        for (const tx of [0.89, 0.77]) {
          ctx.beginPath();
          ctx.moveTo(bx + rx * (tx - 0.032), ry * 0.22);
          ctx.lineTo(bx + rx * tx, ry * 0.09);
          ctx.lineTo(bx + rx * (tx + 0.032), ry * 0.22);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }
    } else {
      // Soft natural Feeding Frenzy mouth line tucked neatly under the protruding snout!
      const mx0 = bx + rx * (isAngelfish ? 1.02 : 0.98);
      ctx.beginPath();
      ctx.moveTo(mx0, ry * 0.15);
      ctx.quadraticCurveTo(bx + rx * 0.86, ry * 0.24, bx + rx * 0.76, ry * 0.16);
      ctx.stroke();
    }
  }

  // ---------- 6. TRANSLUCENT RAYED PECTORAL FIN ----------
  const pFlutter = wag * 0.12;
  ctx.save();
  ctx.translate(bx + rx * (isAngelfish ? 0.24 : 0.08), ry * (isAngelfish ? 0.34 : 0.28));
  ctx.rotate(0.32 + pFlutter);
  ctx.beginPath();
  if (sp.style === "leon") {
    ctx.moveTo(0, -ry * 0.1);
    ctx.bezierCurveTo(-rx * 0.25, -ry * 0.34, -rx * 0.58, -ry * 0.2, -rx * 0.54, ry * 0.14);
    ctx.bezierCurveTo(-rx * 0.48, ry * 0.4, -rx * 0.18, ry * 0.34, 0, ry * 0.12);
  } else {
    ctx.moveTo(0, -ry * 0.07);
    ctx.bezierCurveTo(-rx * 0.18, -ry * 0.2, -rx * 0.42, -ry * 0.12, -rx * 0.4, ry * 0.08);
    ctx.bezierCurveTo(-rx * 0.36, ry * 0.26, -rx * 0.14, ry * 0.22, 0, ry * 0.09);
  }
  ctx.closePath();
  const pg = ctx.createLinearGradient(0, 0, -rx * 0.42, ry * 0.1);
  pg.addColorStop(0, rgbaHex(finDark, 0.85));
  pg.addColorStop(1, rgbaHex(finLight, 0.52));
  ctx.fillStyle = pg;
  ctx.fill();
  ctx.lineWidth = softRimW * 0.85;
  ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.48);
  ctx.stroke();
  ctx.restore();

  // ---------- 7. AUTHENTIC IMAGE 1 FEEDING FRENZY 3D TILTED OVAL EYE ----------
  // Seated right on the upper slope of the snout, tucked under a seamless soft 3D brow ridge,
  // bright 3D oval white sclera & small focused dark pupil right at the front edge!
  const ex = bx + rx * (isAngelfish ? 0.75 : longBody ? 0.64 : 0.6);
  const ey = -ry * (isAngelfish ? 0.14 + open * 0.1 : 0.16 + open * 0.1);
  const er = ry * sp.eye;
  const eyeRx = er * 0.66; // Authentic narrow 3/4-profile tilted oval like Image 1!
  const eyeRy = er * 1.04;
  const eyeTilt = isAngelfish ? -0.28 : -0.18;

  if (jawState === -1) {
    const cg = ctx.createRadialGradient(ex - er * 0.15, ey + er * 1.15, 0, ex - er * 0.15, ey + er * 1.15, er * 0.95);
    cg.addColorStop(0, "rgba(255, 95, 135, 0.44)");
    cg.addColorStop(1, "rgba(255, 95, 135, 0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(ex - er * 0.15, ey + er * 1.15, er * 0.95, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.save();
  ctx.translate(ex, ey);
  ctx.rotate(eyeTilt);

  if (expr === "happy" && !sp.angry) {
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.82);
    ctx.lineWidth = Math.max(1.6, softRimW * 1.35);
    ctx.beginPath();
    ctx.arc(0, eyeRy * 0.22, eyeRx * 0.95, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
  } else {
    // Subtle 3D brow hood behind & above the open eye (matches Image 1's magenta-orange brow ridge!)
    const browTopCol = sp.style === "andy" ? rgbaHex(sp.pal.stripe || "#df22ff", 0.5) : rgbaHex(sp.pal.dark, 0.45);
    ctx.beginPath();
    ctx.ellipse(-eyeRx * 0.12, -eyeRy * 0.04, eyeRx * 1.18, eyeRy * 1.12, 0, Math.PI * 0.55, Math.PI * 1.72);
    ctx.strokeStyle = browTopCol;
    ctx.lineWidth = Math.max(1.5, softRimW * 1.6);
    ctx.stroke();

    // Plump 3D Spherical White Sclera
    ctx.beginPath();
    ctx.ellipse(eyeRx * 0.08, 0, eyeRx * (expr === "panic" ? 1.14 : 1), eyeRy * (expr === "panic" ? 1.08 : 1), 0, 0, Math.PI * 2);
    const sclGrad = ctx.createRadialGradient(eyeRx * 0.2, -eyeRy * 0.15, eyeRx * 0.08, 0, 0, eyeRy * 1.05);
    sclGrad.addColorStop(0, "#ffffff");
    sclGrad.addColorStop(0.72, "#f7faff");
    sclGrad.addColorStop(1, "#b6cae0");
    ctx.fillStyle = sclGrad;
    ctx.fill();

    ctx.save();
    ctx.clip();

    // Small, crisp, eager forward-looking dark oval pupil right near the front edge (100% Image 1!)
    const pxOff = expr === "panic" ? eyeRx * 0.36 : eyeRx * 0.52;
    const pyOff = open > 0 ? eyeRy * 0.08 : eyeRy * 0.05;
    const pRx = eyeRx * (expr === "panic" ? 0.3 : 0.38);
    const pRy = eyeRy * (expr === "panic" ? 0.3 : 0.42);

    ctx.beginPath();
    ctx.ellipse(pxOff, pyOff, pRx * 1.18, pRy * 1.18, 0, 0, Math.PI * 2);
    ctx.fillStyle = sp.pal.iris || "#2b1608";
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(pxOff + eyeRx * 0.04, pyOff, pRx, pRy, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#090812";
    ctx.fill();

    // Crisp tiny 3D specular pinpoint glint
    ctx.beginPath();
    ctx.arc(pxOff - pRx * 0.28, pyOff - pRy * 0.34, Math.max(0.8, pRx * 0.32), 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255, 255, 255, 0.95)";
    ctx.fill();

    if (sp.angry) {
      ctx.beginPath();
      ctx.moveTo(-eyeRx * 1.3, -eyeRy * 1.05);
      ctx.lineTo(eyeRx * 1.3, -eyeRy * 0.08);
      ctx.lineTo(eyeRx * 1.3, -eyeRy * 1.3);
      ctx.closePath();
      ctx.fillStyle = sp.pal.dark;
      ctx.fill();
    }

    ctx.restore(); // end eyeball clip

    // Soft shadow crease only along the back/top socket arc so front of eye blends softly toward snout!
    ctx.beginPath();
    ctx.ellipse(eyeRx * 0.08, 0, eyeRx, eyeRy, 0, Math.PI * 0.35, Math.PI * 1.85);
    ctx.lineWidth = Math.max(1, softRimW * 0.9);
    ctx.strokeStyle = rgbaHex(sp.pal.outline, 0.52);
    ctx.stroke();
  }

  ctx.restore(); // end eye transform
  ctx.restore(); // end translate(0, cy)

  if (!pixelMode) return cv;

  const pw = Math.max(24, Math.round(W * 0.65));
  const ph = Math.max(16, Math.round(H * 0.65));
  const pc = document.createElement("canvas");
  pc.width = pw;
  pc.height = ph;
  const pctx = pc.getContext("2d")!;
  pctx.imageSmoothingEnabled = true;
  pctx.drawImage(cv, 0, 0, pw, ph);
  return pc;
}

// ---------- Soft Glossy Spinning Gold Coin ----------
const coinFrames: HTMLCanvasElement[] = [];
export function coinSprite(frame: number): HTMLCanvasElement {
  if (!coinFrames.length) {
    const scales = [1, 0.82, 0.5, 0.22, 0.5, 0.82];
    for (const sx of scales) {
      const S = 40;
      const c = document.createElement("canvas");
      c.width = S;
      c.height = S;
      const ctx = c.getContext("2d")!;
      const cx = S / 2,
        cy = S / 2,
        r = 15;
      ctx.fillStyle = "#c97408";
      ctx.strokeStyle = "#4a2500";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.ellipse(cx + (sx < 0.9 ? 1.5 : 0), cy, Math.max(3, r * sx), r, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
      g.addColorStop(0, "#fff8b8");
      g.addColorStop(0.45, "#ffd43b");
      g.addColorStop(1, "#f09400");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(cx, cy, Math.max(2.5, r * sx), r, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      if (sx > 0.45) {
        ctx.strokeStyle = "rgba(217, 128, 0, 0.7)";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.ellipse(cx, cy, r * 0.68 * sx, r * 0.68, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = "#fff9db";
        ctx.beginPath();
        ctx.roundRect(cx - 2 * sx, cy - 5, 4 * sx, 10, 2);
        ctx.fill();
      }
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(cx - r * 0.38 * sx, cy - r * 0.42, 2.3, 0, Math.PI * 2);
      ctx.fill();
      coinFrames.push(c);
    }
  }
  return coinFrames[((frame % coinFrames.length) + coinFrames.length) % coinFrames.length];
}

export function spriteDataURL(sp: Species, size = 200, jawState: JawState = 0): string {
  const c = renderFishCanvas(sp, size, jawState, 0, false, jawState === -1 ? "happy" : "normal");
  return c.toDataURL();
}
