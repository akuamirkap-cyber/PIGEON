export const WORLD_W = 3800;
export const WORLD_H = 1950;
export const DEEP_START = 820; // Transition into Twilight Canyon & Deep Grotto
export const FLOOR_TOP = WORLD_H - 330;

function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export function floorY(x: number) {
  return (
    WORLD_H -
    82 +
    Math.sin(x * 0.0035) * 28 +
    Math.sin(x * 0.011 + 1.2) * 15 +
    Math.sin(x * 0.029) * 5
  );
}

function hexToRgb(h: string): [number, number, number] {
  const s = h.startsWith("#") ? h.slice(1) : h;
  const n = parseInt(s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mixCol(a: string, b: string, t: number): string {
  const ca = hexToRgb(a),
    cb = hexToRgb(b);
  const r = Math.round(ca[0] + (cb[0] - ca[0]) * t);
  const g = Math.round(ca[1] + (cb[1] - ca[1]) * t);
  const bl = Math.round(ca[2] + (cb[2] - ca[2]) * t);
  return `rgb(${r},${g},${bl})`;
}

function rgbaHex(h: string, a: number): string {
  const [r, g, b] = hexToRgb(h);
  return `rgba(${r},${g},${b},${a})`;
}

// Cached pre-rendered soft radial glow sprites for ultra-smooth 60 FPS rendering!
const glowCache = new Map<string, HTMLCanvasElement>();
export function glowOrb(color: string, whiteCore = true): HTMLCanvasElement {
  const key = color + (whiteCore ? "|w" : "|n");
  let cv = glowCache.get(key);
  if (cv) return cv;
  const S = 64;
  cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  // Use matching RGB with 0 alpha at outer stop so Canvas never interpolates through black!
  let zeroCol = "rgba(190, 248, 255, 0)";
  if (color.startsWith("#")) {
    zeroCol = rgbaHex(color, 0);
  } else if (color.startsWith("rgba(")) {
    zeroCol = color.replace(/,[^,]+\)$/, ", 0)");
  }
  const rg = c.createRadialGradient(S / 2, S / 2, 0.5, S / 2, S / 2, S / 2);
  if (whiteCore) {
    rg.addColorStop(0, "#ffffff");
    rg.addColorStop(0.32, color);
    rg.addColorStop(0.68, color.startsWith("#") ? rgbaHex(color, 0.25) : "rgba(150, 238, 255, 0.2)");
    rg.addColorStop(1, zeroCol);
  } else {
    rg.addColorStop(0, color);
    rg.addColorStop(1, zeroCol);
  }
  c.fillStyle = rg;
  c.fillRect(0, 0, S, S);
  glowCache.set(key, cv);
  return cv;
}

type Ctx = CanvasRenderingContext2D;

export interface RockCollider {
  x: number;
  y: number;
  r: number;
}

interface RockFormation {
  x: number;
  y: number;
  w: number;
  h: number;
  cv: HTMLCanvasElement;
  colliders: RockCollider[];
  glows: { x: number; y: number; r: number; color: string }[];
  hangLeaves: { x: number; y: number; len: number; ph: number; col: string; glow?: boolean }[];
}

export interface SporeCluster {
  x: number;
  y: number;
  r: number;
  color: string;
  ph: number;
}

interface Jellyfish {
  x: number;
  y: number;
  r: number;
  p: number; // parallax factor (0.42 .. 0.72)
  ph: number;
  speed: number;
  col: string;
  rim: string;
}

interface DistantPelagic {
  x: number;
  y: number;
  scale: number;
  dir: number;
  speed: number;
  kind: "manta" | "whaleshark";
  ph: number;
}

// ============================================================================
// BOTANICAL, CORAL, CRYSTAL & MULTI-STRATA GEOLOGY PAINTERS
// ============================================================================

// 1. Organic Branching Staghorn / Elkhorn Coral with glowing polyp tips
function drawStaghornCoral(
  ctx: Ctx,
  r: () => number,
  x: number,
  y: number,
  ang: number,
  len: number,
  th: number,
  baseCol: string,
  tipCol: string,
  darkCol: string,
  depth: number
) {
  const x2 = x + Math.cos(ang) * len;
  const y2 = y + Math.sin(ang) * len;
  const cx = (x + x2) / 2 + (r() - 0.5) * len * 0.28;
  const cy = (y + y2) / 2 + (r() - 0.5) * len * 0.16;

  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  // Subtle shadow edge
  ctx.strokeStyle = darkCol;
  ctx.lineWidth = th + 1.8;
  ctx.beginPath();
  ctx.moveTo(x, y + 1);
  ctx.quadraticCurveTo(cx, cy + 1, x2, y2 + 0.5);
  ctx.stroke();

  // Main coral branch gradient
  const g = ctx.createLinearGradient(x, y, x2, y2);
  g.addColorStop(0, baseCol);
  g.addColorStop(1, tipCol);
  ctx.strokeStyle = g;
  ctx.lineWidth = th;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.quadraticCurveTo(cx, cy, x2, y2);
  ctx.stroke();

  if (depth > 0 && len > 5.5) {
    const branches = depth === 2 && r() > 0.45 ? 3 : 2;
    for (let i = 0; i < branches; i++) {
      const spread = branches === 3 ? (i - 1) * (0.42 + r() * 0.2) : (i === 0 ? -1 : 1) * (0.34 + r() * 0.32);
      drawStaghornCoral(
        ctx,
        r,
        x2,
        y2,
        ang + spread,
        len * (0.64 + r() * 0.18),
        th * 0.72,
        baseCol,
        tipCol,
        darkCol,
        depth - 1
      );
    }
  } else {
    // Luminous polyp tip bulb
    const rg = ctx.createRadialGradient(x2, y2, 0.2, x2, y2, th * 1.45);
    rg.addColorStop(0, "#ffffff");
    rg.addColorStop(0.42, tipCol);
    rg.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(x2, y2, th * 1.45, 0, Math.PI * 2);
    ctx.fill();
  }
}

// 2. Lacy Organic Gorgonian Sea Fan (natural lobed frond + branching vein tree, NOT a geometric pie wedge!)
function drawGorgonianFan(ctx: Ctx, r: () => number, x: number, y: number, R: number, col: string, rimCol: string, darkCol: string, tilt = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(tilt);

  // Woody holdfast stem
  ctx.strokeStyle = darkCol;
  ctx.lineCap = "round";
  ctx.lineWidth = Math.max(3, R * 0.14);
  ctx.beginPath();
  ctx.moveTo(0, 3);
  ctx.lineTo(0, -R * 0.16);
  ctx.stroke();

  // Wavy multi-lobed organic fan silhouette
  ctx.beginPath();
  ctx.moveTo(-R * 0.12, -R * 0.1);
  const steps = 22;
  for (let i = 0; i <= steps; i++) {
    const f = i / steps;
    const a = Math.PI * 1.06 + f * Math.PI * 0.88;
    const lobe = 0.84 + Math.sin(f * Math.PI * 5) * 0.14 + Math.cos(f * 11) * 0.05;
    const rad = R * lobe * Math.sin(f * Math.PI * 0.85 + 0.22);
    ctx.lineTo(Math.cos(a) * rad * 1.08, -R * 0.14 + Math.sin(a) * rad);
  }
  ctx.lineTo(R * 0.12, -R * 0.1);
  ctx.closePath();

  const fg = ctx.createRadialGradient(0, -R * 0.2, R * 0.08, 0, -R * 0.45, R * 1.05);
  fg.addColorStop(0, rgbaHex(darkCol, 0.88));
  fg.addColorStop(0.58, rgbaHex(col, 0.78));
  fg.addColorStop(1, rgbaHex(rimCol, 0.92));
  ctx.fillStyle = fg;
  ctx.fill();

  // Delicate curved organic fan veins + tiny glowing polyps inside the lacy frond
  ctx.save();
  ctx.clip();
  const drawVein = (vx: number, vy: number, vang: number, vlen: number, vw: number, d: number) => {
    const vx2 = vx + Math.cos(vang) * vlen;
    const vy2 = vy + Math.sin(vang) * vlen;
    const mx = (vx + vx2) * 0.5 + Math.sin(vang * 3) * vlen * 0.14;
    const my = (vy + vy2) * 0.5;
    ctx.strokeStyle = d === 2 ? darkCol : rimCol;
    ctx.globalAlpha = d === 2 ? 0.55 : 0.32;
    ctx.lineWidth = vw;
    ctx.beginPath();
    ctx.moveTo(vx, vy);
    ctx.quadraticCurveTo(mx, my, vx2, vy2);
    ctx.stroke();
    if (d > 0) {
      drawVein(vx2, vy2, vang - 0.28, vlen * 0.65, vw * 0.62, d - 1);
      drawVein(vx2, vy2, vang + 0.28, vlen * 0.65, vw * 0.62, d - 1);
    } else {
      ctx.fillStyle = "#ffffff";
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.arc(vx2, vy2, 0.9, 0, Math.PI * 2);
      ctx.fill();
    }
  };
  for (const baseA of [-2.12, -1.75, -1.39, -1.02]) {
    drawVein(0, -R * 0.08, baseA + (r() - 0.5) * 0.08, R * 0.38, Math.max(0.9, R * 0.042), 2);
  }
  ctx.restore();

  // Glowing lacy outer edge
  ctx.strokeStyle = rgbaHex(rimCol, 0.65);
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.restore();
}

// 3. Tiered Pagoda / Shelf Plate Corals (jutting out from cliffs & reef terraces!)
function drawShelfCoralCluster(
  ctx: Ctx,
  r: () => number,
  x: number,
  y: number,
  dir: number, // -1 left cliff, 0 top terrace, 1 right cliff
  scale: number,
  topCol: string,
  underCol: string,
  rimCol: string
) {
  const tiers = 3;
  for (let i = 0; i < tiers; i++) {
    const sx = x + dir * (i * 8 + 4) * scale + (dir === 0 ? (i - 1) * 14 * scale : 0);
    const sy = y - (tiers - 1 - i) * 9 * scale;
    const rx = (18 + r() * 12 - i * 2) * scale;
    const ry = (4.5 + r() * 2) * scale;

    // Dark underside shadow shelf
    ctx.fillStyle = underCol;
    ctx.beginPath();
    ctx.ellipse(sx, sy + ry * 0.55, rx * 0.94, ry * 0.95, dir * 0.08, 0, Math.PI * 2);
    ctx.fill();

    // Sunlit / bioluminescent upper plate
    const g = ctx.createLinearGradient(sx - rx, sy - ry, sx + rx, sy + ry);
    g.addColorStop(0, rimCol);
    g.addColorStop(0.5, topCol);
    g.addColorStop(1, underCol);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(sx, sy, rx, ry, dir * 0.08, 0, Math.PI * 2);
    ctx.fill();

    // Crisp glowing lip along the outer rim of the plate
    ctx.strokeStyle = rimCol;
    ctx.lineWidth = 1.3 * scale;
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    ctx.ellipse(sx, sy - 0.4, rx * 0.98, ry * 0.82, dir * 0.08, Math.PI * 1.05, Math.PI * 1.95);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }
}

// 4. Translucent Glowing Deep-Sea Crystal Cluster (Amethyst, Cyan & Magenta prisms!)
function drawCrystalCluster(ctx: Ctx, r: () => number, x: number, y: number, scale: number, baseCol: string, coreCol: string, baseAngle = -Math.PI / 2) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(baseAngle + Math.PI / 2);

  // Ambient inner glow pool
  const bg = ctx.createRadialGradient(0, -10 * scale, 1, 0, -10 * scale, 34 * scale);
  bg.addColorStop(0, rgbaHex(coreCol, 0.45));
  bg.addColorStop(1, rgbaHex(baseCol, 0));
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.arc(0, -10 * scale, 34 * scale, 0, Math.PI * 2);
  ctx.fill();

  const shards = 5;
  for (let i = 0; i < shards; i++) {
    const f = i / (shards - 1) - 0.5;
    const ang = f * 0.95 + (r() - 0.5) * 0.12;
    const len = (18 + (1 - Math.abs(f)) * 18 + r() * 8) * scale;
    const w = (3.8 + (1 - Math.abs(f)) * 2.8) * scale;

    ctx.save();
    ctx.rotate(ang);

    // Left facet (bright)
    const g1 = ctx.createLinearGradient(0, -len, 0, 2);
    g1.addColorStop(0, "#ffffff");
    g1.addColorStop(0.32, coreCol);
    g1.addColorStop(1, mixCol(baseCol, "#070b24", 0.55));
    ctx.fillStyle = g1;
    ctx.beginPath();
    ctx.moveTo(-w, 2);
    ctx.lineTo(-w * 0.72, -len * 0.76);
    ctx.lineTo(0, -len);
    ctx.lineTo(0, 2);
    ctx.closePath();
    ctx.fill();

    // Right facet (rich deep tone)
    const g2 = ctx.createLinearGradient(0, -len, 0, 2);
    g2.addColorStop(0, coreCol);
    g2.addColorStop(0.45, baseCol);
    g2.addColorStop(1, "#090d29");
    ctx.fillStyle = g2;
    ctx.beginPath();
    ctx.moveTo(0, 2);
    ctx.lineTo(0, -len);
    ctx.lineTo(w * 0.72, -len * 0.76);
    ctx.lineTo(w, 2);
    ctx.closePath();
    ctx.fill();

    // Specular central ridge highlight
    ctx.strokeStyle = "rgba(255,255,255,0.75)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, -len);
    ctx.lineTo(0, -len * 0.25);
    ctx.stroke();

    ctx.restore();
  }
  ctx.restore();
}

// 5. Ruffled Bioluminescent Lettuce / Brain Coral Mound
function drawBioVioletCoral(ctx: Ctx, r: () => number, x: number, y: number, rx: number, ry: number, baseCol: string, rimCol: string) {
  ctx.save();
  const bloom = ctx.createRadialGradient(x, y - ry * 0.35, 2, x, y - ry * 0.35, Math.max(rx, ry) * 1.55);
  bloom.addColorStop(0, rgbaHex(rimCol, 0.32));
  bloom.addColorStop(1, rgbaHex(baseCol, 0));
  ctx.fillStyle = bloom;
  ctx.beginPath();
  ctx.arc(x, y - ry * 0.35, Math.max(rx, ry) * 1.55, 0, Math.PI * 2);
  ctx.fill();

  for (let layer = 0; layer < 2; layer++) {
    const count = layer === 0 ? 5 : 4;
    for (let i = 0; i < count; i++) {
      const f = i / (count - 1) - 0.5;
      const lx = x + f * rx * (layer === 0 ? 1.15 : 0.78) + (r() - 0.5) * 3;
      const ly = y - (1 - f * f * 1.1) * ry * (layer === 0 ? 0.65 : 0.38);
      const pr = rx * (layer === 0 ? 0.42 : 0.34) * (0.85 + r() * 0.25);

      ctx.beginPath();
      const bumps = 9;
      for (let b = 0; b <= bumps; b++) {
        const a = Math.PI + (b / bumps) * Math.PI;
        const wave = 1 + Math.sin(b * 2.4 + i) * 0.16;
        const px = lx + Math.cos(a) * pr * wave;
        const py = ly + Math.sin(a) * pr * 0.85 * wave;
        if (b === 0) ctx.moveTo(px, py + pr * 0.35);
        ctx.lineTo(px, py);
      }
      ctx.lineTo(lx + pr, ly + pr * 0.35);
      ctx.closePath();

      const g = ctx.createLinearGradient(lx, ly - pr, lx, ly + pr * 0.4);
      g.addColorStop(0, mixCol(rimCol, "#ffffff", 0.38));
      g.addColorStop(0.32, baseCol);
      g.addColorStop(1, "#0f0526");
      ctx.fillStyle = g;
      ctx.fill();

      ctx.strokeStyle = rimCol;
      ctx.lineWidth = 1.2;
      ctx.globalAlpha = 0.78;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }
  ctx.restore();
}

// 6. Fluted Barrel & Golden Cup Sponges
function drawCupSponges(ctx: Ctx, r: () => number, x: number, y: number, colTop = "#ffe066", colMid = "#f59f00", colBot = "#662e08") {
  const n = 2 + Math.floor(r() * 3);
  for (let i = 0; i < n; i++) {
    const w = 6 + r() * 4.5;
    const h = 13 + r() * 18;
    const tx = x + (i - (n - 1) / 2) * (w * 1.05);
    const lean = (r() - 0.5) * 7;

    const g = ctx.createLinearGradient(tx, y - h, tx, y);
    g.addColorStop(0, colTop);
    g.addColorStop(0.55, colMid);
    g.addColorStop(1, colBot);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(tx - w * 0.42, y + 2);
    ctx.quadraticCurveTo(tx - w * 0.62 + lean * 0.5, y - h * 0.5, tx - w * 0.74 + lean, y - h);
    ctx.lineTo(tx + w * 0.74 + lean, y - h);
    ctx.quadraticCurveTo(tx + w * 0.62 + lean * 0.5, y - h * 0.5, tx + w * 0.42, y + 2);
    ctx.closePath();
    ctx.fill();

    // Sponge ridges
    ctx.strokeStyle = rgbaHex(colBot, 0.35);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(tx, y + 1);
    ctx.lineTo(tx + lean, y - h + 2);
    ctx.stroke();

    ctx.fillStyle = mixCol(colTop, "#ffffff", 0.35);
    ctx.beginPath();
    ctx.ellipse(tx + lean, y - h, w * 0.74, 2.7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#2b0d1a";
    ctx.beginPath();
    ctx.ellipse(tx + lean, y - h, w * 0.44, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  }
}

// 7. Porous Reef Craters & Geological Strata Cracks
function drawPorousCraters(ctx: Ctx, r: () => number, cx: number, cy: number, rx: number, ry: number, holeCol: string, rimCol: string, count: number) {
  for (let i = 0; i < count; i++) {
    const a = r() * Math.PI * 2;
    const d = Math.sqrt(r()) * 0.78;
    const hx = cx + Math.cos(a) * rx * d;
    const hy = cy + Math.sin(a) * ry * d;
    const hr = 2.0 + r() * 4.2;
    ctx.fillStyle = rimCol;
    ctx.beginPath();
    ctx.ellipse(hx, hy - 0.7, hr * 1.18, hr * 0.88, a * 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = holeCol;
    ctx.beginPath();
    ctx.ellipse(hx, hy, hr * 0.85, hr * 0.64, a * 0.3, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawGlowingCreviceRim(ctx: Ctx, x: number, y: number, w: number, col: string) {
  ctx.save();
  const g = ctx.createRadialGradient(x, y, 2, x, y, w * 0.76);
  g.addColorStop(0, "rgba(165, 255, 248, 0.62)");
  g.addColorStop(0.45, "rgba(28, 205, 215, 0.25)");
  g.addColorStop(1, "rgba(6, 20, 46, 0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.ellipse(x, y, w * 0.76, w * 0.34, -0.06, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#020714";
  ctx.beginPath();
  const segs = 14;
  for (let i = 0; i <= segs; i++) {
    const f = i / segs - 0.5;
    const jag = (i % 2 === 0 ? 1 : 0.8) * Math.cos(f * Math.PI);
    const px = x + f * w * 0.88;
    const py = y + 4 - jag * w * 0.21;
    if (i === 0) ctx.moveTo(px, y + 6);
    ctx.lineTo(px, py);
  }
  ctx.lineTo(x + w * 0.44, y + 6);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = col;
  ctx.lineWidth = 2;
  ctx.globalAlpha = 0.76;
  ctx.beginPath();
  for (let i = 1; i < segs; i++) {
    const f = i / segs - 0.5;
    const jag = (i % 2 === 0 ? 1 : 0.8) * Math.cos(f * Math.PI);
    const px = x + f * w * 0.88;
    const py = y + 4 - jag * w * 0.21;
    if (i === 1) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.restore();
}

function drawChest(ctx: Ctx, x: number, y: number) {
  ctx.save();
  ctx.lineJoin = "round";
  // Scattered gold coins & glowing pearl around chest!
  ctx.fillStyle = "#ffd43b";
  for (const [ox, oy] of [
    [-12, 1],
    [-7, 3],
    [31, 2],
    [36, 0],
    [28, 4],
  ]) {
    ctx.beginPath();
    ctx.ellipse(x + ox, y + oy, 3.2, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.strokeStyle = "#3b1d04";
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.ellipse(x + 13, y - 15, 14, 6.5, 0, Math.PI, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Glowing pearl inside chest
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(x + 16, y - 16.5, 3.2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#7a3b14";
  ctx.beginPath();
  ctx.roundRect(x - 1, y - 23, 28, 7.5, 3);
  ctx.fill();
  ctx.stroke();

  const g = ctx.createLinearGradient(x, y - 15, x, y);
  g.addColorStop(0, "#b35c24");
  g.addColorStop(1, "#5c290a");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.roundRect(x, y - 15, 26, 15, 2.5);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#fcc419";
  ctx.fillRect(x + 2.5, y - 15, 3, 15);
  ctx.fillRect(x + 20.5, y - 15, 3, 15);
  ctx.beginPath();
  ctx.roundRect(x + 10.5, y - 11.5, 5, 6, 1.5);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

const LAYER_SCALE = 1.6;

interface Kelp {
  x: number;
  y: number;
  h: number;
  ph: number;
  c1: string;
  c2: string;
  p: number; // parallax plane (0.52 = midground, 1.0 = main, 1.24 = foreground silhouette!)
}
interface Anemone {
  x: number;
  y: number;
  n: number;
  ph: number;
  c1: string;
  c2: string;
  len: number;
}
interface Ray {
  x: number;
  w: number;
  ph: number;
  a: number;
}

export class Ocean {
  ultraFar: HTMLCanvasElement; // Layer 1 (0.14x): Seamounts, Sunken Shipwreck & Ancient Ruins
  farArchReef: HTMLCanvasElement; // Layer 2 (0.28x): Natural Stone Reef Arches & Pagoda Corals
  midCoralTerrace: HTMLCanvasElement; // Layer 3 (0.52x): Rich Gorgonian Fans, Sponges & Terraces
  deepBackdrop: HTMLCanvasElement; // Layer 4A (0.24x): Cavern Skylights, Nautilus Fossils & Leviathan Ribs
  deepMidCurtain: HTMLCanvasElement; // Layer 4B (0.48x): Mid-ground Stalactite Spires & Crystal Columns
  floor: HTMLCanvasElement; // Layer 5B (1.0x): Sculpted Abyssal & Reef Floor
  fgClusters: HTMLCanvasElement[]; // Layer 6 (1.24x): Out-of-focus Foreground Coral/Crystal Vignettes!

  formations: RockFormation[] = [];
  colliders: RockCollider[] = [];
  spores: SporeCluster[] = [];
  jellies: Jellyfish[] = [];
  pelagics: DistantPelagic[] = [];
  kelps: Kelp[] = [];
  fgKelps: Kelp[] = [];
  anemones: Anemone[] = [];
  rays: Ray[] = [];
  vents: { x: number; y: number }[] = [];
  chestPos = { x: 0, y: 0 };
  schools: { x: number; y: number; dir: number; speed: number; n: number; p: number; seed: number; deep: boolean }[] = [];
  time = 0;

  constructor() {
    this.ultraFar = this.makeUltraFarSeamounts();
    this.farArchReef = this.makeFarArchReef();
    this.midCoralTerrace = this.makeMidCoralTerrace();
    this.deepBackdrop = this.makeDeepCavernBackdrop();
    this.deepMidCurtain = this.makeDeepMidCurtain();
    this.floor = this.makeAbyssalFloor();
    this.fgClusters = this.makeForegroundVignettes();
    this.buildRockFormations();

    const r = rng(99);

    // Mid-ground kelp forest (0.52x parallax) + Main reef kelp (1.0x parallax)
    for (let i = 0; i < 44; i++) {
      const x = r() * WORLD_W;
      this.kelps.push({
        x,
        y: 690 + Math.sin(x * 0.01) * 35,
        h: 65 + r() * 110,
        ph: r() * 6.28,
        c1: "#1f7a9c",
        c2: "#104c73",
        p: 0.52,
      });
    }
    for (let i = 0; i < 68; i++) {
      const x = r() * WORLD_W;
      const g = r() < 0.5;
      this.kelps.push({
        x,
        y: floorY(x) + 3,
        h: 42 + r() * 105,
        ph: r() * 6.28,
        c1: g ? "#2fd49b" : "#5ce6b8",
        c2: g ? "#0f5c52" : "#165e54",
        p: 1,
      });
    }

    // Foreground 1.24x parallax giant kelp silhouettes along the bottom edge!
    for (let i = 0; i < 18; i++) {
      const x = r() * WORLD_W * 1.24;
      this.fgKelps.push({
        x,
        y: WORLD_H + 35,
        h: 135 + r() * 130,
        ph: r() * 6.28,
        c1: "#092b47",
        c2: "#030e21",
        p: 1.24,
      });
    }

    // Drifting Translucent Moon Jellyfish (Mid-Twilight) & Neon Deep Jellyfish (Abyssal Grotto)!
    for (let i = 0; i < 22; i++) {
      const isDeep = i >= 10;
      const palette = isDeep
        ? i % 2 === 0
          ? ["#c026d3", "#fbcfe8"]
          : ["#06b6d4", "#cffafe"]
        : i % 2 === 0
          ? ["#38bdf8", "#e0f2fe"]
          : ["#818cf8", "#e0e7ff"];
      this.jellies.push({
        x: r() * 3400,
        y: isDeep ? 980 + r() * 720 : 320 + r() * 520,
        r: 9 + r() * 11,
        p: 0.44 + (i % 3) * 0.12,
        ph: r() * 6.28,
        speed: 5 + r() * 6,
        col: palette[0],
        rim: palette[1],
      });
    }

    // Majestic Distant Manta Rays & Whale Sharks gliding in the ultra-far blue haze!
    for (let i = 0; i < 7; i++) {
      this.pelagics.push({
        x: r() * 2600,
        y: 160 + r() * 580,
        scale: 0.75 + r() * 0.65,
        dir: i % 2 === 0 ? 1 : -1,
        speed: 7 + r() * 6,
        kind: i % 3 === 0 ? "whaleshark" : "manta",
        ph: r() * 6.28,
      });
    }

    const anCols = [
      ["#e048b8", "#ffb8f0"],
      ["#9b4dff", "#ebd1ff"],
      ["#29e8d8", "#d6fffa"],
      ["#ff6b9d", "#ffd6e6"],
    ];
    for (let i = 0; i < 46; i++) {
      const x = r() * WORLD_W;
      const c = anCols[Math.floor(r() * anCols.length)];
      this.anemones.push({ x, y: floorY(x) + 1, n: 7 + Math.floor(r() * 5), ph: r() * 6, c1: c[0], c2: c[1], len: 11 + r() * 10 });
    }

    for (let i = 0; i < 20; i++) {
      const deep = i >= 10;
      const p = i % 2 === 0 ? 0.32 : 0.58;
      this.schools.push({
        x: r() * 3000,
        y: deep ? 950 + r() * 750 : 90 + r() * 620,
        dir: r() < 0.5 ? 1 : -1,
        speed: 9 + r() * 15,
        n: 9 + Math.floor(r() * 15),
        p,
        seed: r() * 100,
        deep,
      });
    }
    for (let i = 0; i < 12; i++) this.rays.push({ x: r() * 1400, w: 34 + r() * 62, ph: r() * 6, a: 0.065 + r() * 0.075 });
    for (let i = 0; i < 15; i++) {
      const x = r() * WORLD_W;
      this.vents.push({ x, y: floorY(x) });
    }
  }

  private featherCanvasBottom(ctx: Ctx, w: number, h: number, featherH: number) {
    ctx.save();
    ctx.globalCompositeOperation = "destination-out";
    const fade = ctx.createLinearGradient(0, h - featherH, 0, h);
    fade.addColorStop(0, "rgba(0,0,0,0)");
    fade.addColorStop(1, "rgba(0,0,0,1)");
    ctx.fillStyle = fade;
    ctx.fillRect(0, h - featherH, w, featherH);
    ctx.restore();
  }

  // ==========================================================================
  // LAYER 1 (0.14x): ULTRA-FAR SEAMOUNTS, SUNKEN GALLEON & ANCIENT TEMPLE RUINS
  // ==========================================================================
  makeUltraFarSeamounts() {
    const w = 1800,
      h = 440;
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const ctx = cv.getContext("2d")!;

    const ridgeY = (x: number) => {
      const t = (x / w) * Math.PI * 2;
      return (
        215 -
        Math.sin(t * 2 + 0.5) * 58 -
        Math.cos(t * 3 - 1.1) * 34 -
        Math.pow(Math.max(0, Math.sin(t * 2 - 0.8)), 4) * 95
      );
    };

    // Distant Sunken Wooden Galleon Shipwreck resting on a misty seamount!
    ctx.save();
    ctx.translate(540, ridgeY(540) + 12);
    ctx.rotate(-0.14);
    ctx.fillStyle = "rgba(18, 78, 134, 0.42)";
    ctx.strokeStyle = "rgba(18, 78, 134, 0.48)";
    // Hull
    ctx.beginPath();
    ctx.moveTo(-78, -18);
    ctx.quadraticCurveTo(-20, 22, 65, 14);
    ctx.lineTo(88, -26);
    ctx.lineTo(42, -22);
    ctx.lineTo(25, -10);
    ctx.lineTo(-42, -10);
    ctx.lineTo(-58, -28);
    ctx.closePath();
    ctx.fill();
    // Bowsprit & broken masts
    ctx.lineWidth = 3.5;
    ctx.beginPath();
    ctx.moveTo(72, -18);
    ctx.lineTo(118, -36);
    ctx.moveTo(-12, -10);
    ctx.lineTo(-8, -96);
    ctx.moveTo(32, -12);
    ctx.lineTo(36, -78);
    ctx.stroke();
    // Cross-yards & tattered rigging
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-36, -68);
    ctx.lineTo(18, -72);
    ctx.moveTo(-28, -44);
    ctx.lineTo(14, -47);
    ctx.moveTo(14, -56);
    ctx.lineTo(54, -59);
    ctx.stroke();
    ctx.restore();

    // Distant Ancient Sunken Temple Columns & Broken Archway!
    ctx.save();
    ctx.translate(1360, ridgeY(1360) + 10);
    ctx.fillStyle = "rgba(18, 78, 134, 0.4)";
    for (const [cx, ch] of [
      [-52, 58],
      [-22, 74],
      [12, 46],
      [44, 68],
    ]) {
      ctx.fillRect(cx - 5, -ch, 10, ch + 15);
      ctx.fillRect(cx - 8, -ch - 4, 16, 4);
    }
    // Broken stone lintel across the two left pillars
    ctx.save();
    ctx.translate(-37, -76);
    ctx.rotate(-0.08);
    ctx.fillRect(-26, -6, 52, 8);
    ctx.restore();
    ctx.restore();

    // Sweeping misty seamount silhouette
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= w; x += 6) ctx.lineTo(x, ridgeY(x));
    ctx.lineTo(w, h);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, 70, 0, h);
    g.addColorStop(0, "rgba(22, 92, 152, 0.46)");
    g.addColorStop(0.55, "rgba(15, 68, 124, 0.55)");
    g.addColorStop(1, "rgba(11, 48, 98, 0)");
    ctx.fillStyle = g;
    ctx.fill();

    this.featherCanvasBottom(ctx, w, h, 85);
    return cv;
  }

  // ==========================================================================
  // LAYER 2 (0.28x): FAR CANYON STONE ARCHES & PAGODA TABLE CORALS
  // ==========================================================================
  makeFarArchReef() {
    const w = 1900,
      h = 430;
    const cv = document.createElement("canvas");
    cv.width = Math.round(w * LAYER_SCALE);
    cv.height = Math.round(h * LAYER_SCALE);
    const ctx = cv.getContext("2d")!;
    ctx.scale(LAYER_SCALE, LAYER_SCALE);
    const r = rng(303);

    const hillY = (x: number) => {
      const t = (x / w) * Math.PI * 2;
      return (
        235 -
        Math.sin(t * 2 + 1.4) * 44 -
        Math.sin(t * 5) * 22 -
        Math.pow(Math.max(0, Math.cos(t * 2 - 0.5)), 3) * 75
      );
    };

    // Coral silhouettes perched along ridge
    for (let x = 35; x < w - 35; x += 38 + r() * 32) {
      const y = hillY(x) + 6;
      if (r() < 0.45) {
        drawShelfCoralCluster(ctx, r, x, y - 4, 0, 0.85, "#2474b0", "#124275", "#4cb8eb");
      } else {
        drawStaghornCoral(ctx, r, x, y, -Math.PI / 2 + (r() - 0.5) * 0.4, 14 + r() * 12, 3.5, "#1e68a3", "#5cd6ff", "#103b6b", 2);
      }
    }

    // Main reef ridge silhouette
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= w; x += 5) ctx.lineTo(x, hillY(x));
    ctx.lineTo(w, h);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, 90, 0, h);
    g.addColorStop(0, "#195c99");
    g.addColorStop(0.55, "#103e73");
    g.addColorStop(1, "#0b2a56");
    ctx.fillStyle = g;
    ctx.fill();

    // Carve glowing natural underwater stone arch windows right through the far reef!
    ctx.save();
    ctx.globalCompositeOperation = "destination-out";
    for (const [ax, aw, ah] of [
      [380, 95, 68],
      [980, 115, 76],
      [1560, 92, 64],
    ]) {
      const ay = hillY(ax) + 115;
      ctx.beginPath();
      ctx.ellipse(ax, ay, aw, ah, -0.06, Math.PI * 0.92, Math.PI * 2.08);
      ctx.quadraticCurveTo(ax, ay + ah * 0.45, ax - aw, ay);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    // Rim-light the inside upper curve of each natural stone arch
    ctx.strokeStyle = "rgba(92, 224, 255, 0.35)";
    ctx.lineWidth = 3;
    for (const [ax, aw, ah] of [
      [380, 95, 68],
      [980, 115, 76],
      [1560, 92, 64],
    ]) {
      const ay = hillY(ax) + 115;
      ctx.beginPath();
      ctx.ellipse(ax, ay, aw + 1, ah + 1, -0.06, Math.PI * 1.08, Math.PI * 1.92);
      ctx.stroke();
    }

    this.featherCanvasBottom(ctx, w, h, 85);
    return cv;
  }

  // ==========================================================================
  // LAYER 3 (0.52x): MID-GROUND LUSH CORAL TERRACES, GORGONIAN FANS & SPONGES
  // ==========================================================================
  makeMidCoralTerrace() {
    const w = 2100,
      h = 390;
    const cv = document.createElement("canvas");
    cv.width = Math.round(w * LAYER_SCALE);
    cv.height = Math.round(h * LAYER_SCALE);
    const ctx = cv.getContext("2d")!;
    ctx.scale(LAYER_SCALE, LAYER_SCALE);
    const r = rng(509);

    const hillY = (x: number) => {
      const t = (x / w) * Math.PI * 2;
      return 225 - Math.sin(t * 3 + 0.4) * 38 - Math.cos(t * 6 + 2) * 20;
    };

    // Rich colorful mid-ground coral garden (atmospherically blended into water)
    let x = 28;
    while (x < w - 28) {
      const y = hillY(x) + 5;
      const k = r();
      if (k < 0.3) {
        drawGorgonianFan(ctx, r, x, y, 22 + r() * 16, "#b83b8c", "#ff99dc", "#4a1244", (r() - 0.5) * 0.35);
      } else if (k < 0.56) {
        drawStaghornCoral(ctx, r, x, y, -Math.PI / 2 + (r() - 0.5) * 0.45, 15 + r() * 12, 3.8, "#2982bd", "#8ceeff", "#103566", 2);
      } else if (k < 0.8) {
        drawShelfCoralCluster(ctx, r, x, y - 3, 0, 0.95, "#26949e", "#0e4359", "#7af5f0");
      } else {
        drawCupSponges(ctx, r, x, y + 2, "#ffb86c", "#c95b3c", "#421629");
      }
      x += 34 + r() * 34;
    }

    // Stepped reef terrace body
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let xx = 0; xx <= w; xx += 5) ctx.lineTo(xx, hillY(xx));
    ctx.lineTo(w, h);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, 140, 0, h);
    g.addColorStop(0, "#154b80");
    g.addColorStop(0.5, "#0d3261");
    g.addColorStop(1, "#081e45");
    ctx.fillStyle = g;
    ctx.fill();

    // Sunlit cyan rim highlight along terrace crest
    ctx.beginPath();
    for (let xx = 0; xx <= w; xx += 5) {
      const yy = hillY(xx);
      if (xx === 0) ctx.moveTo(xx, yy);
      else ctx.lineTo(xx, yy);
    }
    ctx.strokeStyle = "rgba(86, 212, 245, 0.32)";
    ctx.lineWidth = 2.4;
    ctx.stroke();

    this.featherCanvasBottom(ctx, w, h, 85);
    return cv;
  }

  // ==========================================================================
  // LAYER 4A & 4B: DEEP CAVERN SKYLIGHTS, FOSSILS & STALACTITE CRYSTAL CURTAINS
  // ==========================================================================
  makeDeepCavernBackdrop() {
    const w = 1800,
      h = 920;
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const ctx = cv.getContext("2d")!;
    const r = rng(777);

    // 1. Ethereal turquoise-violet cavern skylights streaming from upper grotto shafts
    for (const [wx, col1, col2] of [
      [280, "rgba(72, 236, 255, 0.46)", "rgba(24, 128, 218, 0.22)"],
      [860, "rgba(168, 95, 255, 0.36)", "rgba(56, 132, 235, 0.2)"],
      [1420, "rgba(64, 242, 232, 0.44)", "rgba(22, 118, 205, 0.22)"],
    ] as [number, string, string][]) {
      const wy = 260 + (r() - 0.5) * 80;
      const rg = ctx.createRadialGradient(wx, wy, 12, wx, wy, 340);
      rg.addColorStop(0, col1);
      rg.addColorStop(0.45, col2);
      rg.addColorStop(1, "rgba(4, 12, 42, 0)");
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(wx, wy, 340, 0, Math.PI * 2);
      ctx.fill();
    }

    // 2. Colossal Ancient Spiral Ammonite Fossils & Leviathan Rib Arches in the misty abyss!
    for (const fx of [310, 1360]) {
      const fy = 420;
      ctx.save();
      ctx.translate(fx, fy);
      ctx.strokeStyle = "rgba(88, 185, 238, 0.26)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      for (let a = 0; a < Math.PI * 5.2; a += 0.12) {
        const rad = 4 + a * 9.8;
        const px = Math.cos(a) * rad,
          py = Math.sin(a) * rad;
        if (a === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.lineWidth = 2.4;
      for (let a = 1.2; a < Math.PI * 5; a += 0.42) {
        const r1 = 4 + (a - 0.9) * 8.4;
        const r2 = 4 + a * 9.8;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * r1, Math.sin(a) * r1);
        ctx.quadraticCurveTo(
          Math.cos(a + 0.14) * ((r1 + r2) * 0.52),
          Math.sin(a + 0.14) * ((r1 + r2) * 0.52),
          Math.cos(a) * r2,
          Math.sin(a) * r2
        );
        ctx.stroke();
      }
      ctx.restore();
    }

    // Distant curved Leviathan Rib-Cage / Stone Cathedral Arches at x = 850
    ctx.save();
    ctx.strokeStyle = "rgba(64, 145, 212, 0.22)";
    ctx.lineCap = "round";
    for (let i = 0; i < 5; i++) {
      const rx0 = 730 + i * 58;
      ctx.lineWidth = 10 - i * 1.1;
      ctx.beginPath();
      ctx.moveTo(rx0 - 65, 640);
      ctx.quadraticCurveTo(rx0 - 10, 360 - i * 12, rx0 + 75, 480);
      ctx.stroke();
    }
    ctx.restore();

    // Soft feathered background cavern domes
    for (const px of [120, 580, 1080, 1580]) {
      const pw = 140 + r() * 85;
      const ph = 360 + r() * 160;
      const py = h * 0.56;
      const pg = ctx.createRadialGradient(px, py, 20, px, py, Math.max(pw, ph));
      pg.addColorStop(0, "rgba(4, 11, 36, 0.5)");
      pg.addColorStop(0.65, "rgba(4, 11, 36, 0.2)");
      pg.addColorStop(1, "rgba(4, 11, 36, 0)");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.ellipse(px, py, pw, ph, (r() - 0.5) * 0.2, 0, Math.PI * 2);
      ctx.fill();
    }

    return cv;
  }

  // Mid-parallax (0.48x) Deep Stalactite Curtains & Glowing Distant Crystal Columns
  makeDeepMidCurtain() {
    const w = 2000,
      h = 760;
    const cv = document.createElement("canvas");
    cv.width = w;
    cv.height = h;
    const ctx = cv.getContext("2d")!;
    const r = rng(1414);

    // Hanging cavern stalactite clusters receding in mid-distance
    for (let sx = 90; sx < w - 80; sx += 260 + r() * 140) {
      const spikes = 4 + Math.floor(r() * 3);
      for (let i = 0; i < spikes; i++) {
        const f = i / (spikes - 1) - 0.5;
        const x = sx + f * 95;
        const len = 110 + (1 - Math.abs(f)) * 135 + r() * 55;
        const sw = 18 + (1 - Math.abs(f)) * 16;
        const g = ctx.createLinearGradient(x, 40, x, 40 + len);
        g.addColorStop(0, "rgba(8, 22, 58, 0)");
        g.addColorStop(0.25, "rgba(9, 26, 66, 0.72)");
        g.addColorStop(0.85, "rgba(16, 56, 108, 0.78)");
        g.addColorStop(1, "rgba(45, 185, 225, 0.55)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(x - sw, 40);
        ctx.quadraticCurveTo(x - sw * 0.35, 40 + len * 0.65, x, 40 + len);
        ctx.quadraticCurveTo(x + sw * 0.35, 40 + len * 0.65, x + sw, 40);
        ctx.closePath();
        ctx.fill();
      }
      // Subtle distant crystal cluster perched on cavern pillar
      if (r() < 0.7) {
        drawCrystalCluster(
          ctx,
          r,
          sx + (r() - 0.5) * 40,
          560 + (r() - 0.5) * 80,
          0.95,
          r() < 0.5 ? "#6d28d9" : "#0284c7",
          r() < 0.5 ? "#f0abfc" : "#67e8f9"
        );
      }
    }

    return cv;
  }

  // ==========================================================================
  // LAYER 5: SCULPTED MULTI-STRATA ROCK ISLANDS, CRYSTALS & ABYSSAL REEF FLOOR
  // ==========================================================================
  buildRockFormations() {
    const r = rng(2026);

    const upperSpecs = [
      { x: 560, y: 460, rx: 168, ry: 74 },
      { x: 1420, y: 525, rx: 188, ry: 80 },
      { x: 2340, y: 455, rx: 172, ry: 75 },
      { x: 3220, y: 515, rx: 178, ry: 78 },
    ];
    for (const s of upperSpecs) {
      this.formations.push(this.createRockIsland(r, s.x, s.y, s.rx, s.ry, false));
    }

    const deepSpecs = [
      { x: 380, y: 990, rx: 212, ry: 94 },
      { x: 1020, y: 1065, rx: 198, ry: 90 },
      { x: 1760, y: 980, rx: 222, ry: 96 },
      { x: 2520, y: 1055, rx: 208, ry: 92 },
      { x: 3320, y: 995, rx: 216, ry: 94 },

      { x: 700, y: 1440, rx: 184, ry: 88 },
      { x: 1420, y: 1500, rx: 198, ry: 94 },
      { x: 2140, y: 1420, rx: 188, ry: 90 },
      { x: 2920, y: 1490, rx: 202, ry: 94 },
    ];
    for (const s of deepSpecs) {
      this.formations.push(this.createRockIsland(r, s.x, s.y, s.rx, s.ry, true));
    }

    for (const f of this.formations) {
      this.colliders.push(...f.colliders);
    }
  }

  createRockIsland(r: () => number, wx: number, wy: number, rx: number, ry: number, isDeep: boolean): RockFormation {
    const pad = 92;
    const W = Math.round((rx + pad) * 2);
    const H = Math.round((ry + pad) * 2);
    const cv = document.createElement("canvas");
    cv.width = Math.round(W * LAYER_SCALE);
    cv.height = Math.round(H * LAYER_SCALE);
    const ctx = cv.getContext("2d")!;
    ctx.scale(LAYER_SCALE, LAYER_SCALE);

    const cx = W / 2,
      cy = H / 2;
    const glows: { x: number; y: number; r: number; color: string }[] = [];
    const hangLeaves: { x: number; y: number; len: number; ph: number; col: string; glow?: boolean }[] = [];

    const pts: [number, number][] = [];
    const steps = 40;
    for (let i = 0; i < steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      const n1 = Math.sin(a * 3 + wx * 0.013) * 0.16;
      const n2 = Math.cos(a * 7 - wy * 0.019) * 0.09;
      const n3 = Math.sin(a * 11 + i) * 0.045;
      const stalactite = isDeep && Math.sin(a) > 0.26 && i % 3 === 0 ? 0.28 + r() * 0.24 : 0;
      const radX = rx * (0.9 + n1 + n2 + n3);
      const radY = ry * (0.88 + n1 * 0.8 + n3 + stalactite);
      pts.push([cx + Math.cos(a) * radX, cy + Math.sin(a) * radY]);
    }

    const traceRock = () => {
      ctx.beginPath();
      const [x0, y0] = pts[0];
      const [xLast, yLast] = pts[pts.length - 1];
      ctx.moveTo((xLast + x0) / 2, (yLast + y0) / 2);
      for (let i = 0; i < pts.length; i++) {
        const [px, py] = pts[i];
        const [nx, ny] = pts[(i + 1) % pts.length];
        ctx.quadraticCurveTo(px, py, (px + nx) / 2, (py + ny) / 2);
      }
      ctx.closePath();
    };

    // 1. Lush Reef & Crystal Flora crowning the top AND jutting out from left/right cliff walls!
    // Side shelf corals jutting from left & right cliff edges
    drawShelfCoralCluster(
      ctx,
      r,
      cx - rx * 0.88,
      cy - ry * 0.12,
      -1,
      0.9,
      isDeep ? "#7e22ce" : "#e85d9e",
      "#170936",
      isDeep ? "#f5d0fe" : "#ffc2e2"
    );
    drawShelfCoralCluster(
      ctx,
      r,
      cx + rx * 0.88,
      cy - ry * 0.08,
      1,
      0.9,
      isDeep ? "#0ea5e9" : "#2eb8ac",
      "#08223d",
      isDeep ? "#bae6fd" : "#b8fff5"
    );

    for (let i = 0; i < 10; i++) {
      const fx = (i / 9 - 0.5) * rx * 1.5;
      const tx = cx + fx;
      const ty = cy - ry * (0.78 - (fx / rx) ** 2 * 0.32);
      if (isDeep) {
        if (i % 3 === 0) {
          drawCrystalCluster(
            ctx,
            r,
            tx,
            ty + 8,
            0.85 + r() * 0.35,
            i % 2 === 0 ? "#9333ea" : "#0284c7",
            i % 2 === 0 ? "#f5d0fe" : "#a5f3fc",
            -Math.PI / 2 + (fx / rx) * 0.35
          );
          glows.push({
            x: wx + fx,
            y: wy - ry * 0.9,
            r: 62,
            color: i % 2 === 0 ? "rgba(232, 121, 249, 0.24)" : "rgba(56, 189, 248, 0.24)",
          });
        } else if (i % 3 === 1) {
          drawBioVioletCoral(ctx, r, tx, ty + 6, 22 + r() * 14, 18 + r() * 12, "#7e22ce", "#f472b6");
          this.spores.push({
            x: wx + fx + (r() - 0.5) * 24,
            y: wy - ry * 1.15 - r() * 28,
            r: 26 + r() * 18,
            color: r() < 0.65 ? "#ff66d9" : "#42f5ec",
            ph: r() * 6.28,
          });
        } else {
          drawGorgonianFan(ctx, r, tx, ty + 8, 22 + r() * 14, "#c026d3", "#fbcfe8", "#3b0764", (fx / rx) * 0.4);
        }
      } else {
        if (i % 4 === 0) drawCupSponges(ctx, r, tx, ty + 8);
        else if (i % 4 === 1)
          drawStaghornCoral(ctx, r, tx, ty + 8, -Math.PI / 2 + (r() - 0.5) * 0.45, 13 + r() * 10, 3.6, "#ff7b54", "#ffd8a8", "#5c1d12", 2);
        else if (i % 4 === 2)
          drawGorgonianFan(ctx, r, tx, ty + 8, 20 + r() * 14, "#e84a96", "#ffc2e2", "#590d38", (fx / rx) * 0.35);
        else drawStaghornCoral(ctx, r, tx, ty + 8, -Math.PI / 2 + (r() - 0.5) * 0.45, 13 + r() * 10, 3.6, "#2cb8d9", "#b8fbff", "#0e3c59", 2);
      }
    }

    // 2. Sculpted Multi-Strata Rock Body
    traceRock();
    const rg = ctx.createLinearGradient(cx, cy - ry * 1.1, cx, cy + ry * 1.25);
    if (isDeep) {
      rg.addColorStop(0, "#1c5885");
      rg.addColorStop(0.22, "#0e2b56");
      rg.addColorStop(0.58, "#071330");
      rg.addColorStop(1, "#020512");
    } else {
      rg.addColorStop(0, "#23749e");
      rg.addColorStop(0.28, "#11436b");
      rg.addColorStop(0.7, "#07203d");
      rg.addColorStop(1, "#030e21");
    }
    ctx.fillStyle = rg;
    ctx.fill();

    ctx.save();
    ctx.clip();

    // Stepped Geological Strata Ledges & Chiseled Cliff Facets!
    for (let s = 0; s < 4; s++) {
      const sy = cy - ry * 0.45 + s * ry * 0.34;
      ctx.beginPath();
      ctx.moveTo(cx - rx * 1.2, sy + (r() - 0.5) * 14);
      for (let xx = -rx; xx <= rx; xx += 28) {
        ctx.lineTo(cx + xx, sy + Math.sin(xx * 0.04 + s * 2) * 9 + (s % 2) * 4);
      }
      ctx.lineTo(cx + rx * 1.2, cy + ry * 1.5);
      ctx.lineTo(cx - rx * 1.2, cy + ry * 1.5);
      ctx.closePath();
      ctx.fillStyle = `rgba(3, 9, 28, ${0.22 + s * 0.06})`;
      ctx.fill();

      // Crisp sunlit/bioluminescent rim along upper lip of each rock stratum!
      ctx.strokeStyle = isDeep ? `rgba(72, 225, 250, ${0.24 - s * 0.04})` : `rgba(115, 235, 255, ${0.26 - s * 0.04})`;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let xx = -rx; xx <= rx; xx += 28) {
        const py = sy + Math.sin(xx * 0.04 + s * 2) * 9 + (s % 2) * 4;
        if (xx === -rx) ctx.moveTo(cx + xx, py);
        else ctx.lineTo(cx + xx, py);
      }
      ctx.stroke();
    }

    // Porous reef craters
    drawPorousCraters(
      ctx,
      r,
      cx - rx * 0.22,
      cy - ry * 0.12,
      rx * 0.72,
      ry * 0.62,
      "#020818",
      isDeep ? "rgba(56, 185, 232, 0.25)" : "rgba(72, 178, 218, 0.28)",
      20
    );

    // Glowing cyan/emerald moss sheen along upper rock crown
    const mossG = ctx.createRadialGradient(cx - rx * 0.24, cy - ry * 0.78, 4, cx - rx * 0.18, cy - ry * 0.6, rx * 0.8);
    mossG.addColorStop(0, isDeep ? "rgba(56, 248, 228, 0.5)" : "rgba(115, 240, 255, 0.42)");
    mossG.addColorStop(1, "rgba(18, 90, 140, 0)");
    ctx.fillStyle = mossG;
    ctx.fillRect(0, 0, W, H);

    // Glowing Grotto Crevice tucked into underside of rock arch
    drawGlowingCreviceRim(ctx, cx + (r() - 0.5) * rx * 0.35, cy + ry * 0.72, rx * 0.48, isDeep ? "#38f5e8" : "#4cf2d2");
    glows.push({ x: wx, y: wy + ry * 0.75, r: 68, color: "rgba(56, 245, 232, 0.22)" });

    ctx.restore(); // end rock clip

    traceRock();
    ctx.strokeStyle = isDeep ? "rgba(82, 225, 255, 0.32)" : "rgba(110, 228, 250, 0.3)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Hanging sea-fern leaves (upper reef) OR glowing bioluminescent vine tendrils (deep grotto)!
    const nVines = isDeep ? 6 : 5;
    for (let i = 0; i < nVines; i++) {
      const lx = wx + (i / (nVines - 1) - 0.5) * rx * 1.15;
      const ly = wy + ry * 0.76;
      hangLeaves.push({
        x: lx,
        y: ly,
        len: isDeep ? 22 + r() * 22 : 16 + r() * 14,
        ph: r() * 6.28,
        col: isDeep ? (i % 2 === 0 ? "#38f5e8" : "#e879f9") : i % 2 === 0 ? "#4ec994" : "#38ab82",
        glow: isDeep,
      });
    }

    const colliders: RockCollider[] = [
      { x: wx - rx * 0.46, y: wy, r: ry * 0.66 },
      { x: wx, y: wy, r: ry * 0.78 },
      { x: wx + rx * 0.46, y: wy, r: ry * 0.66 },
    ];

    return { x: wx - W / 2, y: wy - H / 2, w: W, h: H, cv, colliders, glows, hangLeaves };
  }

  makeAbyssalFloor() {
    const H = WORLD_H + 75 - FLOOR_TOP;
    const cv = document.createElement("canvas");
    cv.width = Math.round(WORLD_W * LAYER_SCALE);
    cv.height = Math.round(H * LAYER_SCALE);
    const ctx = cv.getContext("2d")!;
    ctx.scale(LAYER_SCALE, LAYER_SCALE);
    const r = rng(1234);
    const O = FLOOR_TOP;

    // Back dark rocky ridges & crystal spires
    for (let i = 0; i < 62; i++) {
      const x = r() * WORLD_W;
      const y = floorY(x) - O + 8;
      const rx = 20 + r() * 36,
        ry = 15 + r() * 30;
      const g = ctx.createLinearGradient(x, y - ry, x, y + 6);
      g.addColorStop(0, "#1f427d");
      g.addColorStop(1, "#060c21");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(x, y, rx, ry, 0, Math.PI, Math.PI * 2);
      ctx.fill();
    }

    // Lush Bioluminescent Deep-Sea Coral & Crystal Garden!
    let x = 18;
    while (x < WORLD_W - 18) {
      const y = floorY(x) - O + 4;
      const k = r();
      if (k < 0.25) {
        drawBioVioletCoral(ctx, r, x, y + 2, 24 + r() * 18, 18 + r() * 14, "#6d28d9", "#f472b6");
        if (r() < 0.6) {
          this.spores.push({
            x,
            y: floorY(x) - 34 - r() * 24,
            r: 28 + r() * 18,
            color: r() < 0.6 ? "#ff66d9" : "#38f5e8",
            ph: r() * 6.28,
          });
        }
      } else if (k < 0.45) {
        drawCrystalCluster(
          ctx,
          r,
          x,
          y + 4,
          0.85 + r() * 0.4,
          r() < 0.5 ? "#7e22ce" : "#0284c7",
          r() < 0.5 ? "#f5d0fe" : "#a5f3fc"
        );
      } else if (k < 0.66) {
        drawGorgonianFan(ctx, r, x, y + 2, 22 + r() * 16, "#db2777", "#fbcfe8", "#4c0519", (r() - 0.5) * 0.3);
      } else if (k < 0.84) {
        drawStaghornCoral(
          ctx,
          r,
          x,
          y + 2,
          -Math.PI / 2 + (r() - 0.5) * 0.5,
          14 + r() * 12,
          3.8,
          r() < 0.5 ? "#0ea5e9" : "#c026d3",
          "#f5d0fe",
          "#170936",
          2
        );
      } else {
        drawCupSponges(ctx, r, x, y + 2);
      }
      x += 24 + r() * 30;
    }

    // Sculpted layered abyssal floor
    ctx.beginPath();
    ctx.moveTo(0, H);
    for (let xx = 0; xx <= WORLD_W; xx += 4) ctx.lineTo(xx, floorY(xx) - O);
    ctx.lineTo(WORLD_W, H);
    ctx.closePath();
    const fg = ctx.createLinearGradient(0, WORLD_H - 95 - O, 0, H);
    fg.addColorStop(0, "#1d386e");
    fg.addColorStop(0.22, "#0d1b42");
    fg.addColorStop(0.65, "#050b21");
    fg.addColorStop(1, "#02040f");
    ctx.fillStyle = fg;
    ctx.fill();

    // Glowing bioluminescent rim along floor ridge
    ctx.beginPath();
    for (let xx = 0; xx <= WORLD_W; xx += 4) {
      const yy = floorY(xx) - O;
      if (xx === 0) ctx.moveTo(xx, yy);
      else ctx.lineTo(xx, yy);
    }
    ctx.strokeStyle = "rgba(125, 211, 252, 0.42)";
    ctx.lineWidth = 2.8;
    ctx.stroke();

    for (let gx = 220; gx < WORLD_W - 180; gx += 420) {
      const gy = floorY(gx) - O + 22;
      drawGlowingCreviceRim(ctx, gx, gy, 74, "#38f5e8");
    }

    const cx = WORLD_W * 0.62;
    this.chestPos = { x: cx + 13, y: floorY(cx) - 15 };
    drawChest(ctx, cx, floorY(cx) - O + 4);

    return cv;
  }

  // ==========================================================================
  // LAYER 6 (1.24x): FOREGROUND PARALLAX CORAL & CRYSTAL FRAMING SILHOUETTES!
  // ==========================================================================
  makeForegroundVignettes(): HTMLCanvasElement[] {
    const r = rng(8888);
    const list: HTMLCanvasElement[] = [];
    for (let v = 0; v < 4; v++) {
      const w = 210,
        h = 155;
      const cv = document.createElement("canvas");
      cv.width = w;
      cv.height = h;
      const ctx = cv.getContext("2d")!;

      // Dark foreground rock mound at bottom with glowing rim coral/crystals!
      if (v % 2 === 0) {
        drawStaghornCoral(ctx, r, w * 0.45, h - 18, -Math.PI / 2 - 0.18, 28, 6, "#09264a", "#38f5e8", "#03091c", 2);
        drawGorgonianFan(ctx, r, w * 0.66, h - 14, 42, "#190d42", "#e879f9", "#05081c", 0.22);
      } else {
        drawCrystalCluster(ctx, r, w * 0.5, h - 16, 1.25, "#0d1f4d", "#5eead4");
        drawStaghornCoral(ctx, r, w * 0.28, h - 12, -Math.PI / 2 - 0.3, 24, 5, "#170b3b", "#f472b6", "#03091c", 2);
      }

      ctx.fillStyle = "#03091c";
      ctx.beginPath();
      ctx.ellipse(w * 0.5, h + 12, w * 0.46, 42, 0, Math.PI, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(56, 225, 245, 0.28)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(w * 0.5, h + 12, w * 0.46, 42, 0, Math.PI * 1.12, Math.PI * 1.88);
      ctx.stroke();

      list.push(cv);
    }
    return list;
  }

  // Fast viewport-cropped horizontal tiling helper (blits ONLY visible pixels of wide parallax layers!)
  private blitTiledLayer(ctx: Ctx, cv: HTMLCanvasElement, scale: number, scrollX: number, dy: number, vw: number, vh: number) {
    const logicalW = cv.width / scale;
    const logicalH = cv.height / scale;
    if (dy > vh || dy + logicalH < -20) return;
    const off = ((scrollX % logicalW) + logicalW) % logicalW;
    let dx = 0;
    let curX = off;
    while (dx < vw) {
      const sliceW = Math.min(vw - dx, logicalW - curX);
      ctx.drawImage(
        cv,
        curX * scale,
        0,
        sliceW * scale,
        cv.height,
        dx,
        dy,
        sliceW,
        logicalH
      );
      dx += sliceW;
      curX = 0;
    }
  }

  // ==========================================================================
  // RUNTIME MULTI-LAYER RENDERING
  // ==========================================================================
  drawWater(ctx: Ctx, camTop: number, vw: number, vh: number) {
    if (camTop < 0) {
      const sky = ctx.createLinearGradient(0, 0, 0, -camTop + 4);
      sky.addColorStop(0, "#e3fbff");
      sky.addColorStop(1, "#99f0ff");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, vw, -camTop + 4);
    }
    const g = ctx.createLinearGradient(0, -camTop, 0, WORLD_H - camTop);
    g.addColorStop(0, "#5cf2ff");
    g.addColorStop(0.09, "#22b8eb");
    g.addColorStop(0.24, "#1275c7");
    g.addColorStop(0.42, "#0b468c");
    g.addColorStop(0.62, "#072761");
    g.addColorStop(0.82, "#05143d");
    g.addColorStop(1, "#02071a");
    ctx.fillStyle = g;
    const top = Math.max(0, -camTop);
    ctx.fillRect(0, top, vw, vh - top + 2);
  }

  // Soft shimmering sunlit caustic dapples right near the water surface (zero lines!)
  drawCaustics(ctx: Ctx, camLeft: number, camTop: number, vw: number, t: number) {
    if (camTop > 280) return;
    const alpha = Math.max(0, 1 - camTop / 280) * 0.28;
    const orb = glowOrb("rgba(205, 253, 255, 0.45)", false);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = alpha;
    for (let i = 0; i < 14; i++) {
      const period = 1200;
      const sx = ((((i * 92 - camLeft * 0.65 + Math.sin(t * 1.3 + i) * 26) % period) + period) % period) - 100;
      const sy = 22 + (i % 3) * 34 + Math.cos(t * 1.6 + i * 1.7) * 8 - camTop;
      if (sx < -90 || sx > vw + 90 || sy < -30 || sy > 240) continue;
      const rx = 44 + (i % 3) * 18;
      ctx.drawImage(orb, sx - rx, sy - 10, rx * 2, 20);
    }
    ctx.restore();
  }

  drawSurface(ctx: Ctx, camLeft: number, camTop: number, vw: number, t: number) {
    if (camTop > 28) return;
    const y = -camTop;
    ctx.save();
    ctx.beginPath();
    for (let x = 0; x <= vw + 8; x += 6) {
      const wx = x + camLeft;
      const h = Math.sin(wx * 0.045 + t * 2.2) * 2.2 + Math.sin(wx * 0.1 - t * 3.1) * 1.2;
      if (x === 0) ctx.moveTo(x, y + h);
      else ctx.lineTo(x, y + h);
    }
    ctx.strokeStyle = "rgba(155, 245, 255, 0.88)";
    ctx.lineWidth = 5.5;
    ctx.stroke();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2.2;
    ctx.stroke();
    ctx.restore();
  }

  drawRays(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    const top = -camTop;
    if (top + 1080 < 0) return;
    this.drawCaustics(ctx, camLeft, camTop, vw, t);
    void vh;

    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const r of this.rays) {
      const period = 1400;
      let x = (((r.x - camLeft * 0.28) % period) + period) % period;
      x -= 220;
      if (x > vw + 260) continue;
      const sway = Math.sin(t * 0.38 + r.ph) * 20;
      const a = r.a * (0.7 + 0.3 * Math.sin(t * 0.85 + r.ph));
      const len = 1020;
      ctx.save();
      ctx.translate(x + r.w * 0.5, top);
      ctx.rotate(-0.24 + sway * 0.0015);
      ctx.scale(r.w * 0.92, len);
      const rg = ctx.createRadialGradient(0, 0.12, 0.02, 0, 0.25, 0.78);
      rg.addColorStop(0, `rgba(205, 254, 255, ${a * 0.98})`);
      rg.addColorStop(0.45, `rgba(95, 222, 250, ${a * 0.44})`);
      rg.addColorStop(1, "rgba(60, 180, 235, 0)");
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(0, 0.25, 0.78, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  // Distant Manta Rays & Whale Sharks gliding majestically in the ultra-far blue haze!
  private drawDistantPelagics(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const t = this.time;
    ctx.save();
    ctx.fillStyle = "rgba(16, 72, 128, 0.42)";
    for (const m of this.pelagics) {
      const period = 2600;
      const sx = ((((m.x + m.dir * m.speed * t - camLeft * 0.18) % period) + period) % period) - 160;
      const sy = m.y - camTop * 0.48 + Math.sin(t * 0.7 + m.ph) * 12;
      if (sx < -120 || sx > vw + 120 || sy < -60 || sy > vh + 60) continue;

      ctx.save();
      ctx.translate(sx, sy);
      ctx.scale(m.dir * m.scale, m.scale);
      const flap = Math.sin(t * 2.1 + m.ph) * 6;
      if (m.kind === "manta") {
        // Graceful Manta Ray silhouette with sweeping wings & tail whip
        ctx.beginPath();
        ctx.moveTo(22, 0);
        ctx.quadraticCurveTo(6, -16 - flap, -10, -22 - flap * 1.2);
        ctx.quadraticCurveTo(-8, -6, -18, -2);
        ctx.lineTo(-42, -1);
        ctx.lineTo(-18, 2);
        ctx.quadraticCurveTo(-8, 6, -10, 18 + flap * 0.9);
        ctx.quadraticCurveTo(6, 12 + flap * 0.7, 22, 0);
        ctx.closePath();
        ctx.fill();
      } else {
        // Gentle Giant Whale Shark silhouette
        ctx.beginPath();
        ctx.ellipse(0, 0, 38, 10, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(-4, -8);
        ctx.lineTo(-14, -20);
        ctx.lineTo(-18, -8);
        ctx.moveTo(-34, 0);
        ctx.lineTo(-50, -14 + flap * 0.3);
        ctx.lineTo(-44, 0);
        ctx.lineTo(-48, 11 + flap * 0.3);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }
    ctx.restore();
  }

  // Translucent pulsing Moon & Bioluminescent Jellyfish drifting in the mid-ground!
  private drawJellyfish(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const t = this.time;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const j of this.jellies) {
      const period = 3400;
      const sx = ((((j.x - camLeft * j.p + Math.sin(t * 0.4 + j.ph) * 24) % period) + period) % period) - 100;
      const bob = Math.sin(t * 1.7 + j.ph);
      const sy = j.y - camTop * (0.72 + j.p * 0.28) - bob * 9;
      if (sx < -60 || sx > vw + 60 || sy < -60 || sy > vh + 60) continue;

      const pulseX = 1 + bob * 0.1;
      const pulseY = 1 - bob * 0.11;
      const r = j.r;

      ctx.save();
      ctx.translate(sx, sy);

      // Fast pre-rendered bioluminescent aura
      const auraOrb = glowOrb(rgbaHex(j.col, 0.28), false);
      ctx.drawImage(auraOrb, -r * 2.3, -r * 2.3, r * 4.6, r * 4.6);

      // Delicate trailing silk tentacles
      ctx.strokeStyle = rgbaHex(j.rim, 0.42);
      ctx.lineWidth = 1.1;
      for (let k = -1.5; k <= 1.5; k += 1) {
        const tx0 = k * r * 0.34;
        const sway1 = Math.sin(t * 2.4 + j.ph + k) * 4;
        const sway2 = Math.cos(t * 2.0 + j.ph + k) * 6;
        ctx.beginPath();
        ctx.moveTo(tx0, r * 0.15);
        ctx.bezierCurveTo(tx0 + sway1, r * 0.9, tx0 - sway2, r * 1.6, tx0 + sway2, r * 2.25);
        ctx.stroke();
      }

      // Translucent pulsing bell dome
      ctx.scale(pulseX, pulseY);
      ctx.fillStyle = rgbaHex(j.rim, 0.48);
      ctx.beginPath();
      ctx.arc(0, r * 0.15, r, Math.PI * 1.02, Math.PI * 1.98);
      ctx.quadraticCurveTo(0, -r * 0.05, -r, r * 0.15);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(255, 255, 255, 0.45)";
      ctx.beginPath();
      ctx.ellipse(0, -r * 0.35, r * 0.52, r * 0.26, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = rgbaHex(j.rim, 0.75);
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(0, r * 0.15, r, Math.PI * 1.06, Math.PI * 1.94);
      ctx.stroke();

      ctx.restore();
    }
    ctx.restore();
  }

  drawLayers(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const t = this.time;
    const deepBlend = Math.max(0, Math.min(1, (camTop - 560) / 460));

    // ---------- UPPER & TWILIGHT MULTI-PLANE PARALLAX (Layers 1, 2, 3) ----------
    if (deepBlend < 1) {
      ctx.save();
      ctx.globalAlpha = 1 - deepBlend * 0.82;

      // Layer 1 (0.14x): Ultra-far Seamounts, Shipwreck & Temple Ruins + Distant Manta Rays!
      {
        const h = this.ultraFar.height;
        const y = 580 - camTop * 0.45 - h;
        this.blitTiledLayer(ctx, this.ultraFar, 1, camLeft * 0.14, y, vw, vh);
        this.drawDistantPelagics(ctx, camLeft, camTop, vw, vh);
      }

      // Layer 2 (0.28x): Far Stone Reef Arches & Pagoda Corals
      {
        const h = this.farArchReef.height / LAYER_SCALE;
        const y = 760 - camTop * 0.62 - h;
        this.blitTiledLayer(ctx, this.farArchReef, LAYER_SCALE, camLeft * 0.28, y, vw, vh);
        this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.32, false);
      }

      // Layer 3 (0.52x): Mid-ground Lush Coral Terraces + Swaying Mid-ground Kelp!
      {
        const h = this.midCoralTerrace.height / LAYER_SCALE;
        const y = 920 - camTop * 0.78 - h;
        this.blitTiledLayer(ctx, this.midCoralTerrace, LAYER_SCALE, camLeft * 0.52, y, vw, vh);
        for (const k of this.kelps) {
          if (k.p !== 0.52) continue;
          const period = WORLD_W * 0.52;
          const sx = ((((k.x * 0.52 - camLeft * 0.52) % period) + period) % period);
          if (sx < -30 || sx > vw + 30) continue;
          const sy = k.y - camTop * 0.78;
          if (sy - k.h > vh || sy < -20) continue;
          this.drawKelpAt(ctx, sx, sy, k.h * 0.85, k.ph, k.c1, k.c2, t, false);
        }
        this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.58, false);
      }

      ctx.restore();
    }

    // ---------- DEEP CAVERN MULTI-PLANE PARALLAX (Layers 4A & 4B) ----------
    if (camTop + vh > DEEP_START - 240) {
      const alpha = Math.max(0.18, Math.min(1, (camTop + vh - (DEEP_START - 140)) / 340));
      ctx.save();
      ctx.globalAlpha = alpha;

      // Layer 4A (0.24x): Cavern Skylights, Nautilus Fossils & Leviathan Ribs
      this.blitTiledLayer(ctx, this.deepBackdrop, 1, camLeft * 0.24, DEEP_START + 60 - camTop, vw, vh);
      this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.32, true);

      // Layer 4B (0.48x): Mid-ground Stalactite Curtains & Distant Glowing Crystal Spires
      this.blitTiledLayer(ctx, this.deepMidCurtain, 1, camLeft * 0.48, DEEP_START + 110 - camTop * 0.92, vw, vh);

      this.drawSchools(ctx, camLeft, camTop, vw, vh, 0.58, true);
      ctx.restore();
    }

    // Drifting Translucent Moon & Bioluminescent Jellyfish across mid-water & deep grotto!
    this.drawJellyfish(ctx, camLeft, camTop, vw, vh);
  }

  drawSchools(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, layer: number, deep: boolean) {
    const t = this.time;
    ctx.fillStyle = deep
      ? "rgba(68, 212, 248, 0.36)"
      : layer < 0.45
        ? "rgba(24, 96, 156, 0.44)"
        : "rgba(32, 118, 182, 0.5)";
    for (const s of this.schools) {
      if (s.p !== layer || s.deep !== deep) continue;
      const period = 3000;
      const bx = ((((s.x + s.dir * s.speed * t - camLeft * s.p) % period) + period) % period) - 300;
      const by = s.y - camTop * (deep ? 0.95 : s.p * 0.85) + Math.sin(t * 0.5 + s.seed) * 10;
      if (bx < -120 || bx > vw + 120 || by < -60 || by > vh + 60) continue;
      const big = s.p > 0.45 ? 1.3 : 1;
      for (let i = 0; i < s.n; i++) {
        const ox = Math.sin(s.seed + i * 12.9) * 42 + Math.sin(t * 1.3 + i) * 3;
        const oy = Math.cos(s.seed + i * 7.3) * 16 + Math.sin(t * 2 + i * 0.7) * 2;
        const x = bx + ox,
          y = by + oy;
        ctx.beginPath();
        ctx.ellipse(x, y, 2.8 * big, 1.4 * big, 0, 0, Math.PI * 2);
        ctx.fill();
        const tx = x - s.dir * 3.2 * big;
        ctx.beginPath();
        ctx.moveTo(x - s.dir * 1.8 * big, y);
        ctx.lineTo(tx - s.dir * 1.8 * big, y - 1.8 * big);
        ctx.lineTo(tx - s.dir * 1.8 * big, y + 1.8 * big);
        ctx.closePath();
        ctx.fill();
      }
    }
  }

  drawRockFormations(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    for (const f of this.formations) {
      const sx = f.x - camLeft;
      const sy = f.y - camTop;
      if (sx + f.w < -40 || sx > vw + 40 || sy + f.h < -40 || sy > vh + 40) continue;

      // Hanging sea-fern leaves OR glowing bioluminescent cavern tendrils!
      for (const lv of f.hangLeaves) {
        const lx = lv.x - camLeft;
        const ly = lv.y - camTop;
        const sway = Math.sin(t * 1.8 + lv.ph) * 5;
        ctx.save();
        if (lv.glow) {
          ctx.globalCompositeOperation = "lighter";
          ctx.strokeStyle = rgbaHex(lv.col, 0.65);
          ctx.lineWidth = 2.0;
          ctx.beginPath();
          ctx.moveTo(lx, ly - 3);
          ctx.quadraticCurveTo(lx + sway * 0.5, ly + lv.len * 0.55, lx + sway, ly + lv.len);
          ctx.stroke();
          ctx.fillStyle = "#ffffff";
          ctx.beginPath();
          ctx.arc(lx + sway, ly + lv.len, 2.2, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.strokeStyle = "#165246";
          ctx.fillStyle = lv.col;
          ctx.lineWidth = 1.3;
          ctx.beginPath();
          ctx.moveTo(lx, ly - 3);
          ctx.quadraticCurveTo(lx + sway * 0.6 + 5, ly + lv.len * 0.5, lx + sway, ly + lv.len);
          ctx.quadraticCurveTo(lx + sway * 0.6 - 5, ly + lv.len * 0.5, lx, ly - 3);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
        ctx.restore();
      }

      ctx.drawImage(f.cv, sx, sy, f.w, f.h);

      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const pulse = 0.78 + Math.sin(t * 2.1 + f.x * 0.01) * 0.22;
      for (const gl of f.glows) {
        const gx = gl.x - camLeft,
          gy = gl.y - camTop;
        const rg = ctx.createRadialGradient(gx, gy, 2, gx, gy, gl.r * pulse);
        rg.addColorStop(0, gl.color);
        rg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = rg;
        ctx.beginPath();
        ctx.arc(gx, gy, gl.r * pulse, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Floating bioluminescent pink & cyan spore fireflies
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const sp of this.spores) {
      const sx = sp.x - camLeft;
      const sy = sp.y - camTop;
      if (sx < -60 || sx > vw + 60 || sy < -60 || sy > vh + 60) continue;
      for (let i = 0; i < 9; i++) {
        const a = sp.ph + i * 1.9;
        const driftY = ((t * 5 + i * 7) % 26) - 13;
        const px = sx + Math.cos(a + t * 0.6) * sp.r * (0.3 + (i % 3) * 0.28);
        const py = sy + Math.sin(a * 1.3) * sp.r * 0.45 - driftY;
        const pr = 3.2 + (i % 3) * 1.4;
        const rg = ctx.createRadialGradient(px, py, 0.2, px, py, pr);
        rg.addColorStop(0, "#ffffff");
        rg.addColorStop(0.38, sp.color);
        rg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = rg;
        ctx.beginPath();
        ctx.arc(px, py, pr, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  drawFloor(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number) {
    const y = FLOOR_TOP - camTop;
    if (y > vh) return;
    const sx = Math.max(0, camLeft);
    const sw = Math.min(WORLD_W - sx, vw + 4);
    if (sw <= 0) return;
    const dx = sx - camLeft;
    ctx.drawImage(
      this.floor,
      sx * LAYER_SCALE,
      0,
      sw * LAYER_SCALE,
      this.floor.height,
      dx,
      y,
      sw,
      this.floor.height / LAYER_SCALE
    );
  }

  private drawKelpAt(ctx: Ctx, bx: number, by: number, h: number, ph: number, c1: string, c2: string, t: number, leaves: boolean) {
    const steps = 8;
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const pts: [number, number][] = [];
    for (let i = 0; i <= steps; i++) {
      const f = i / steps;
      const sx = bx + Math.sin(t * 1.5 + ph + f * 3.2) * f * 11 + Math.sin(t * 0.7 + ph) * f * 5;
      const sy = by - f * h;
      pts.push([sx, sy]);
    }

    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.strokeStyle = c2;
    ctx.lineWidth = leaves ? 4.8 : 4.2;
    ctx.stroke();
    ctx.strokeStyle = c1;
    ctx.lineWidth = leaves ? 2.4 : 1.8;
    ctx.stroke();

    if (leaves) {
      ctx.fillStyle = c1;
      for (let i = 2; i < steps; i += 2) {
        const [lx, ly] = pts[i];
        const side = (i / 2) % 2 === 0 ? 1 : -1;
        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate(side * 0.55 + Math.sin(t * 2 + i) * 0.15);
        ctx.beginPath();
        ctx.ellipse(side * 4.2, 0, 4.4, 1.9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }
    ctx.restore();
  }

  drawAnemone(ctx: Ctx, a: Anemone, camLeft: number, camTop: number, t: number) {
    const bx = a.x - camLeft,
      by = a.y - camTop;
    ctx.save();
    ctx.lineCap = "round";
    for (let i = 0; i < a.n; i++) {
      const spread = (i / (a.n - 1) - 0.5) * 1.7;
      const sway = Math.sin(t * 2.1 + a.ph + i * 0.7) * 4;
      const tx = bx + spread * 8 + sway;
      const ty = by - a.len * 1.25 + Math.abs(spread) * 2.5;
      ctx.strokeStyle = mixCol(a.c1, "#080d26", 0.45);
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.moveTo(bx + spread * 4, by);
      ctx.quadraticCurveTo(bx + spread * 6 + sway * 0.4, by - a.len * 0.6, tx, ty);
      ctx.stroke();

      ctx.strokeStyle = a.c1;
      ctx.lineWidth = 2.2;
      ctx.stroke();

      ctx.fillStyle = a.c2;
      ctx.beginPath();
      ctx.arc(tx, ty, 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  drawBackDecor(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    for (const k of this.kelps) {
      if (k.p !== 1) continue;
      if (k.x - camLeft < -30 || k.x - camLeft > vw + 30 || k.y - k.h - camTop > vh) continue;
      this.drawKelpAt(ctx, k.x - camLeft, k.y - camTop, k.h, k.ph, k.c1, k.c2, t, true);
    }
    for (const a of this.anemones) {
      if (a.x - camLeft < -30 || a.x - camLeft > vw + 30 || a.y - 30 - camTop > vh) continue;
      this.drawAnemone(ctx, a, camLeft, camTop, t);
    }
    const cx = this.chestPos.x - camLeft,
      cy = this.chestPos.y - camTop;
    if (cx > -70 && cx < vw + 70 && cy < vh + 70) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const rg = ctx.createRadialGradient(cx, cy, 2, cx, cy, 48);
      rg.addColorStop(0, `rgba(255, 232, 110, ${0.46 + Math.sin(t * 3) * 0.1})`);
      rg.addColorStop(1, "rgba(255, 232, 110, 0)");
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(cx, cy, 48, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // ==========================================================================
  // LAYER 6 (1.24x): FOREGROUND PARALLAX SILHOUETTE DEPTH FRAMING!
  // ==========================================================================
  drawForegroundParallax(ctx: Ctx, camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    // 1. Foreground Coral/Crystal Vignettes sweeping faster along the ocean floor!
    const bottomY = WORLD_H + 26 - camTop * 1.12;
    if (bottomY - 155 < vh) {
      const period = 520;
      const off = (((camLeft * 1.24) % (period * 4)) + period * 4) % (period * 4);
      ctx.save();
      ctx.globalAlpha = 0.88;
      for (let i = 0; i < 8; i++) {
        const vx = i * period - (off % (period * 4));
        if (vx < -240 || vx > vw + 40) continue;
        const cv = this.fgClusters[i % this.fgClusters.length];
        ctx.drawImage(cv, vx, bottomY - cv.height);
      }
      ctx.restore();
    }

    // 2. Foreground Giant Kelp Silhouettes swaying at 1.24x parallax!
    const wSpan = WORLD_W * 1.24;
    for (const k of this.fgKelps) {
      const sx = ((((k.x - camLeft * 1.24) % wSpan) + wSpan) % wSpan);
      if (sx > vw + 40) continue;
      const sy = WORLD_H + 34 - camTop * 1.1;
      if (sy - k.h > vh) continue;
      this.drawKelpAt(ctx, sx, sy, k.h, k.ph, k.c1, k.c2, t, true);
    }
  }
}
