export interface Palette {
  body: string;
  dark: string;
  belly: string;
  fin: string;
  tail?: string;
  outline: string;
  iris?: string;
  stripe?: string;
  spot?: string;
  lure?: string;
}

export type BodyStyle =
  | "andy"
  | "clown"
  | "minnow"
  | "boris"
  | "layla"
  | "pierre"
  | "leon"
  | "peter"
  | "eddy"
  | "orca"
  | "barracuda"
  | "shark";

export interface Species {
  id: string;
  name: string;
  style: BodyStyle;
  hRatio: number; // body height / body length
  eye: number; // eye size relative to body half-height
  blush: boolean;
  angry: boolean;
  teeth: boolean;
  underbite?: boolean;
  lure?: boolean;
  spinyCrest?: boolean;
  stripes: number[];
  spots: boolean;
  deepPref?: "upper" | "any" | "deep"; // preferred ocean depth zone
  pal: Palette;
  minR: number;
  maxR: number;
  speed: number;
  predator: boolean;
  weight: number;
}

const base = {
  blush: false,
  angry: false,
  teeth: false,
  stripes: [] as number[],
  spots: false,
  predator: false,
  deepPref: "any" as "upper" | "any" | "deep",
};

// Food-chain species across both Sunlit Reef & Deep Bioluminescent Cavern
export const SPECIES: Species[] = [
  {
    ...base,
    id: "minnow",
    name: "Hiromi Teri",
    style: "minnow",
    hRatio: 0.54,
    eye: 0.34,
    deepPref: "any",
    pal: {
      body: "#6be8ce",
      dark: "#259c96",
      belly: "#eafff8",
      fin: "#9cf5e8",
      outline: "#13474d",
      iris: "#1e56a0",
      spot: "#18646e",
    },
    spots: true,
    minR: 3.2,
    maxR: 4.8,
    speed: 70,
    weight: 34,
  },
  {
    ...base,
    id: "boris_npc",
    name: "Boris",
    style: "boris",
    hRatio: 0.86,
    eye: 0.3,
    deepPref: "upper",
    pal: {
      body: "#e8f2ff",
      dark: "#8db6eb",
      belly: "#ffffff",
      fin: "#ffe138",
      tail: "#ffe854",
      outline: "#243b6b",
      iris: "#1f4e99",
      stripe: "#3562c9",
      spot: "#18294d",
    },
    minR: 4.8,
    maxR: 6.6,
    speed: 63,
    weight: 22,
  },
  {
    ...base,
    id: "andy_npc",
    name: "Andy",
    style: "andy",
    hRatio: 0.94,
    eye: 0.28,
    deepPref: "any",
    pal: {
      body: "#ff8c14",
      dark: "#b83c06",
      belly: "#ffb82e",
      fin: "#e8640c",
      tail: "#fff8dc",
      outline: "#591d04",
      iris: "#2b1608",
      stripe: "#df22ff",
    },
    minR: 6.3,
    maxR: 8.8,
    speed: 62,
    weight: 18,
  },
  {
    ...base,
    id: "layla_npc",
    name: "Layla",
    style: "layla",
    hRatio: 0.78,
    eye: 0.29,
    deepPref: "upper",
    pal: {
      body: "#ffc436",
      dark: "#db7814",
      belly: "#cfeaf2",
      fin: "#6be2ff",
      tail: "#32d492",
      outline: "#4a2c0b",
      iris: "#1a5276",
      stripe: "#28b2d4",
    },
    minR: 9.6,
    maxR: 12.8,
    speed: 58,
    weight: 13,
  },
  {
    ...base,
    id: "pierre_npc",
    name: "Pierre",
    style: "pierre",
    hRatio: 0.64,
    eye: 0.3,
    spots: true,
    deepPref: "any",
    pal: {
      body: "#4476ff",
      dark: "#1d3fb3",
      belly: "#9ec2ff",
      fin: "#5992ff",
      outline: "#142563",
      iris: "#d9920f",
      spot: "#f5fbff",
    },
    minR: 13.6,
    maxR: 17.5,
    speed: 56,
    weight: 10,
  },
  {
    ...base,
    id: "leon_npc",
    name: "Leon Lepu",
    style: "leon",
    hRatio: 0.68,
    eye: 0.3,
    spinyCrest: true,
    deepPref: "any",
    stripes: [-0.45, -0.16, 0.12],
    pal: {
      body: "#e65624",
      dark: "#9e2a0c",
      belly: "#ffe8d6",
      fin: "#ff986e",
      tail: "#fff2e6",
      outline: "#4a1708",
      iris: "#c97a10",
      stripe: "#fff5eb",
      spot: "#45190c",
    },
    minR: 18.0,
    maxR: 23.0,
    speed: 52,
    weight: 7,
  },
  {
    ...base,
    id: "eddy_npc",
    name: "Eddy Lentera",
    style: "eddy",
    hRatio: 0.78,
    eye: 0.29,
    lure: true,
    underbite: true,
    predator: true,
    deepPref: "deep",
    pal: {
      body: "#62bf36",
      dark: "#2d6b14",
      belly: "#b6eb75",
      fin: "#489426",
      tail: "#489426",
      outline: "#1b3d0b",
      iris: "#d9a414",
      lure: "#d9ff42",
    },
    minR: 23.5,
    maxR: 29.5,
    speed: 55,
    weight: 6,
  },
  {
    ...base,
    id: "barracuda",
    name: "Robert",
    style: "barracuda",
    hRatio: 0.42,
    eye: 0.32,
    angry: true,
    teeth: true,
    predator: true,
    deepPref: "any",
    pal: {
      body: "#9cd1d9",
      dark: "#4d8291",
      belly: "#f2fcff",
      fin: "#84bdb2",
      outline: "#1b3d4a",
      iris: "#d49b1a",
      stripe: "#2d5563",
      spot: "#1b3540",
    },
    spots: true,
    minR: 30.0,
    maxR: 38.0,
    speed: 62,
    weight: 4,
  },
  {
    ...base,
    id: "orca_npc",
    name: "Goliath Orca",
    style: "orca",
    hRatio: 0.52,
    eye: 0.27,
    teeth: true,
    predator: true,
    deepPref: "any",
    pal: {
      body: "#232a38",
      dark: "#0d111a",
      belly: "#ffffff",
      fin: "#181e29",
      outline: "#090d17",
      iris: "#2b6cb0",
      spot: "#ffffff",
    },
    minR: 39.0,
    maxR: 50.0,
    speed: 65,
    weight: 2,
  },
];

// Default Hero: Exact Image 1 Andy Angelfish shape, pointed snout & 3D oval eye!
export const HERO: Species = {
  ...base,
  id: "hero",
  name: "Andy",
  style: "andy",
  hRatio: 0.94,
  eye: 0.29,
  pal: {
    body: "#ff8c14",
    dark: "#b83c06",
    belly: "#ffb82e",
    fin: "#e8640c",
    tail: "#fff8dc",
    outline: "#591d04",
    iris: "#2b1608",
    stripe: "#df22ff",
  },
  minR: 7,
  maxR: 100,
  speed: 100,
  weight: 0,
};

export interface Skin {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  style: BodyStyle;
  hRatio: number;
  pal: Palette;
  stripes?: number[];
  spots?: boolean;
  spinyCrest?: boolean;
  lure?: boolean;
  underbite?: boolean;
  teeth?: boolean;
}

export const SKINS: Skin[] = [
  {
    id: "andy",
    name: "Andy",
    subtitle: "Angelfish Klasik",
    price: 0,
    style: "andy",
    hRatio: 0.94,
    pal: HERO.pal,
  },
  {
    id: "andy_blue",
    name: "Ryan",
    subtitle: "Angelfish Biru",
    price: 0,
    style: "andy",
    hRatio: 0.94,
    pal: {
      body: "#1fa2ff",
      dark: "#0e47a1",
      belly: "#66e0ff",
      fin: "#1677d9",
      tail: "#e0fbff",
      outline: "#092559",
      iris: "#122240",
      stripe: "#1ef5d8",
    },
  },
  {
    id: "orange",
    name: "Si Oren",
    subtitle: "Clownfish Badut",
    price: 40,
    style: "clown",
    hRatio: 0.72,
    pal: {
      body: "#ff9429",
      dark: "#c9480c",
      belly: "#ffe47a",
      fin: "#ffb838",
      outline: "#4d1d06",
      iris: "#241409",
      stripe: "#fff9eb",
    },
    stripes: [-0.44, 0.04],
  },
  {
    id: "boris",
    name: "Boris",
    subtitle: "Butterfly FF2",
    price: 70,
    style: "boris",
    hRatio: 0.86,
    pal: {
      body: "#e8f2ff",
      dark: "#8db6eb",
      belly: "#ffffff",
      fin: "#ffe138",
      tail: "#ffe854",
      outline: "#243b6b",
      iris: "#1f4e99",
      stripe: "#3562c9",
      spot: "#18294d",
    },
  },
  {
    id: "layla",
    name: "Layla",
    subtitle: "Queen Trigger",
    price: 130,
    style: "layla",
    hRatio: 0.78,
    pal: {
      body: "#ffc436",
      dark: "#db7814",
      belly: "#cfeaf2",
      fin: "#6be2ff",
      tail: "#32d492",
      outline: "#4a2c0b",
      iris: "#1a5276",
      stripe: "#28b2d4",
    },
  },
  {
    id: "pierre",
    name: "Pierre",
    subtitle: "Kerapu Bintik",
    price: 190,
    style: "pierre",
    hRatio: 0.64,
    spots: true,
    pal: {
      body: "#4476ff",
      dark: "#1d3fb3",
      belly: "#9ec2ff",
      fin: "#5992ff",
      outline: "#142563",
      iris: "#d9920f",
      spot: "#f5fbff",
    },
  },
  {
    id: "leon",
    name: "Leon",
    subtitle: "Lionfish Kipas",
    price: 280,
    style: "leon",
    hRatio: 0.68,
    spinyCrest: true,
    stripes: [-0.45, -0.16, 0.12],
    pal: {
      body: "#e65624",
      dark: "#9e2a0c",
      belly: "#ffe8d6",
      fin: "#ff986e",
      tail: "#fff2e6",
      outline: "#4a1708",
      iris: "#c97a10",
      stripe: "#fff5eb",
      spot: "#45190c",
    },
  },
  {
    id: "peter",
    name: "Peter",
    subtitle: "John Dory FF2",
    price: 380,
    style: "peter",
    hRatio: 0.8,
    spinyCrest: true,
    pal: {
      body: "#3ca355",
      dark: "#1d6e35",
      belly: "#d9f59d",
      fin: "#8fd957",
      tail: "#5ca345",
      outline: "#15361c",
      iris: "#d9a414",
      stripe: "#ffe43b",
      spot: "#141f14",
    },
  },
  {
    id: "eddy",
    name: "Eddy",
    subtitle: "Angler Laut Dalam",
    price: 520,
    style: "eddy",
    hRatio: 0.78,
    lure: true,
    underbite: true,
    pal: {
      body: "#62bf36",
      dark: "#2d6b14",
      belly: "#b6eb75",
      fin: "#489426",
      tail: "#489426",
      outline: "#1b3d0b",
      iris: "#d9a414",
      lure: "#d9ff42",
    },
  },
  {
    id: "orca",
    name: "Goliath",
    subtitle: "Orca Raja Laut",
    price: 800,
    style: "orca",
    hRatio: 0.54,
    teeth: true,
    pal: {
      body: "#232a38",
      dark: "#0d111a",
      belly: "#ffffff",
      fin: "#181e29",
      outline: "#090d17",
      iris: "#2b6cb0",
      spot: "#ffffff",
    },
  },
];

export function skinToSpecies(skin: Skin): Species {
  return {
    ...HERO,
    id: "skin-" + skin.id,
    name: skin.name,
    style: skin.style,
    hRatio: skin.hRatio,
    pal: skin.pal,
    stripes: skin.stripes ?? [],
    spots: !!skin.spots,
    spinyCrest: !!skin.spinyCrest,
    lure: !!skin.lure,
    underbite: !!skin.underbite,
    teeth: !!skin.teeth,
    eye: skin.style === "orca" ? 0.26 : skin.style === "andy" || skin.style === "boris" ? 0.29 : 0.31,
  };
}

export const BOT_NAMES = [
  "Boris_FF",
  "Andy_Gacor",
  "RyanBiru",
  "LaylaQueen",
  "LeonSpiky",
  "EddyLampu",
  "PeterDory",
  "PierreBiru",
  "OrcaImut",
  "IkanLele",
  "Nemo_KW",
  "BudiGacor",
  "Mujair",
  "ProPlayer",
  "Bandeng",
  "KakapMerah",
  "Gurame",
  "Patin_OP",
  "TuyulLaut",
  "Sultan_Ikan",
];
