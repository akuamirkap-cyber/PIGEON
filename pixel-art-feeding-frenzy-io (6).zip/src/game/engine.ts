import { SPECIES, SKINS, skinToSpecies, BOT_NAMES } from "./species";
import type { Species, Skin } from "./species";
import { fishSprite, fishMouthOffset, coinSprite } from "./sprites";
import type { EyeExpr, JawState } from "./sprites";
import { Ocean, WORLD_W, WORLD_H, DEEP_START, floorY, glowOrb } from "./ocean";

let bubbleStamp: HTMLCanvasElement | null = null;
function getBubbleStamp(): HTMLCanvasElement {
  if (bubbleStamp) return bubbleStamp;
  const S = 36;
  const cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  const r = S * 0.44;
  const bg = c.createRadialGradient(S * 0.36, S * 0.36, r * 0.08, S * 0.5, S * 0.5, r);
  bg.addColorStop(0, "rgba(255, 255, 255, 0.85)");
  bg.addColorStop(0.35, "rgba(195, 245, 255, 0.2)");
  bg.addColorStop(0.82, "rgba(165, 238, 255, 0.35)");
  bg.addColorStop(1, "rgba(165, 238, 255, 0.65)");
  c.fillStyle = bg;
  c.beginPath();
  c.arc(S * 0.5, S * 0.5, r, 0, Math.PI * 2);
  c.fill();
  bubbleStamp = cv;
  return cv;
}
import { sfx } from "./audio";

export const fishLen = (r: number) => r * 2.55 + 3;

export interface Upgrades {
  suck: number;
  speed: number;
  size: number;
}
export interface StartOpts {
  name: string;
  skin: Skin;
  upgrades: Upgrades;
}
export interface LeaderRow {
  name: string;
  score: number;
  me: boolean;
  color: string;
}
export interface HudState {
  coins: number;
  score: number;
  mass: number;
  energy: number;
  combo: number;
  comboT: number;
  frenzyStage: number;
  level: number;
  growthPct: number;
  stageNum: number;
  zoneName: string;
  rank: number;
  total: number;
  leaderboard: LeaderRow[];
  alive: boolean;
  exhausted: boolean;
  boost: number;
  boostExhausted: boolean;
  sucking: boolean;
  boosting: boolean;
}
export interface DeathInfo {
  score: number;
  coins: number;
  killer: string;
  maxMass: number;
  eaten: number;
  time: number;
}
export type GameEvent =
  | { type: "combo"; n: number }
  | { type: "frenzy"; n: number }
  | { type: "levelup"; text: string }
  | { type: "feed"; text: string }
  | { type: "coinbump" };

type Kind = "npc" | "bot" | "player";
let NEXT_ID = 1;

class Fish {
  id = NEXT_ID++;
  kind: Kind;
  sp: Species;
  key: string;
  skinRef?: Skin;
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  mass: number;
  r: number;
  face = 1;
  tilt = 0;
  sq = 0;
  sqv = 0;
  tailPh = Math.random() * 6;
  jaw = 0;
  mouthOpenT = 0;
  chompT = 0;
  wantOpen = false;
  sucking = false;
  suckVis = 0; // smooth 0..1 visual fade for suction mist
  turnFlip = 1; // smooth -1..+1 horizontal turn flip (zero instant mirror snap!)
  exhausted = false;
  energy = 1;
  boosting = false;
  boost = 1;
  boostExhausted = false;
  boostTrail = 0;
  name = "";
  color = "#fff";
  eatenBy: Fish | null = null;
  eatT = 0;
  eatFromX = 0;
  eatFromY = 0;
  dead = false;
  combo = 0;
  comboT = 0;
  score = 0;
  invuln = 0;
  sucked = 0;
  speedMul = 1;
  suckMul = 1;
  maxR = 999;
  ai = { tx: 0, ty: 0, timer: 0, target: null as Fish | null, chase: 0, rest: 0, flee: false };

  constructor(kind: Kind, sp: Species, key: string, x: number, y: number, mass: number) {
    this.kind = kind;
    this.sp = sp;
    this.key = key;
    this.x = x;
    this.y = y;
    this.mass = mass;
    this.r = Math.sqrt(mass);
    this.ai.tx = x;
    this.ai.ty = y;
  }

  mouthOff(): [number, number] {
    return fishMouthOffset(this.sp, fishLen(this.r));
  }
  mouthX() {
    const [ox, oy] = this.mouthOff();
    return this.x + this.face * (ox * Math.cos(this.tilt) - oy * Math.sin(this.tilt));
  }
  mouthY() {
    const [ox, oy] = this.mouthOff();
    return this.y + ox * Math.sin(this.tilt) + oy * Math.cos(this.tilt);
  }
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  type: "bubble" | "bit" | "spark" | "suck" | "ring" | "star" | "streak" | "chomp";
  color: string;
  size: number;
  dir?: number;
  target?: Fish;
}
interface Txt {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  max: number;
  size: number;
}
interface FlyCoin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number;
  value: number;
}
interface WorldCoin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number;
  value: number;
  settled: boolean;
}

export const EAT_RATIO = 0.88;
const GAIN = 0.115;
const NPC_TARGET = 430;
const NPC_SPEED = 1.3;
const BOT_COUNT = 22;
const WORDS = ["NYAM!", "HAP!", "GULP!", "CHOMP!", "YUMMY!", "MANTAP!", "SLURP!"];

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  ocean: Ocean;
  fish: Fish[] = [];
  player: Fish | null = null;
  particles: Particle[] = [];
  texts: Txt[] = [];
  flyCoins: FlyCoin[] = [];
  worldCoins: WorldCoin[] = [];
  motes: { x: number; y: number; s: number; col: string }[] = [];
  respawnQueue: { t: number; name: string; skin: Skin }[] = [];
  cam = { x: WORLD_W / 2, y: 520 };
  camLeft = 0;
  camTop = 0;
  zoom = 2.5;
  dpr = 1;
  pixelMode = false;
  vw = 320;
  vh = 180;
  mouse = { x: 0, y: 0, sx: 0, sy: 0, active: false };
  camVel = { x: 0, y: 0 };
  suckInput = false;
  boostInput = false;
  t = 0;
  shake = 0;
  freeze = 0;
  sessionCoins = 0;
  arcadeScore = 0;
  eatenCount = 0;
  maxMass = 0;
  startMass = 58;
  startTime = 0;
  level = 0;
  deathTimer = -1;
  killerName = "";
  coinTimer = 0;
  hudTimer = 0;
  last = 0;
  raf = 0;
  minimap: HTMLCanvasElement | null = null;
  miniTimer = 0;
  spectate: Fish | null = null;
  leaderId = -1;
  onHud?: (h: HudState) => void;
  onDeath?: (d: DeathInfo) => void;
  onEvent?: (e: GameEvent) => void;
  coinHudPos = { x: 900, y: 26 };

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.ocean = new Ocean();
    const moteCols = ["#cffafe", "#a5f3fc", "#f5d0fe", "#fde68a"];
    for (let i = 0; i < 165; i++) {
      this.motes.push({
        x: Math.random() * 2000,
        y: Math.random() * 1400,
        s: Math.random(),
        col: moteCols[i % moteCols.length],
      });
    }
    while (this.fish.length < NPC_TARGET) this.spawnNPC(true);
    const names = [...BOT_NAMES].sort(() => Math.random() - 0.5);
    for (let i = 0; i < BOT_COUNT; i++) {
      const botSkin = SKINS[i % SKINS.length];
      this.spawnBot(names[i % names.length], botSkin, 56 + Math.random() * Math.random() * 680);
    }
    this.resize(true);
    this.last = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
  }

  setPixelMode(pm: boolean) {
    this.pixelMode = pm;
    this.resize(true);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    sfx.setSuck(false);
  }

  isInsideRock(x: number, y: number, pad: number): boolean {
    for (const c of this.ocean.colliders) {
      const dx = x - c.x,
        dy = y - c.y;
      if (dx * dx + dy * dy < (c.r + pad) * (c.r + pad)) return true;
    }
    return false;
  }

  pickSpecies(): Species {
    const p = this.player;
    if (p && !p.dead && Math.random() < 0.52) {
      const r = p.r;
      const ok = SPECIES.filter((s) => s.maxR > r * 0.35 && s.minR < r * 1.1);
      if (ok.length) return ok[Math.floor(Math.random() * ok.length)];
    }
    const total = SPECIES.reduce((a, s) => a + s.weight, 0);
    let k = Math.random() * total;
    for (const s of SPECIES) {
      k -= s.weight;
      if (k <= 0) return s;
    }
    return SPECIES[0];
  }

  randomSpawnPos(margin: number, offscreen: boolean, pref: "upper" | "any" | "deep" = "any") {
    const near = offscreen && Math.random() < 0.55;
    for (let i = 0; i < 28; i++) {
      const x = near
        ? clamp(this.cam.x + (Math.random() < 0.5 ? -1 : 1) * (this.vw / 2 + 40 + Math.random() * 380), 50, WORLD_W - 50)
        : 50 + Math.random() * (WORLD_W - 100);
      const fy = floorY(x);
      let yMin = 50 + margin;
      let yMax = fy - 45 - margin;
      if (pref === "upper") yMax = Math.min(yMax, DEEP_START + 80);
      else if (pref === "deep") yMin = Math.max(yMin, DEEP_START + 60);
      if (yMax <= yMin) yMax = yMin + 40;
      const y = yMin + Math.random() * (yMax - yMin);

      if (this.isInsideRock(x, y, margin + 12)) continue;
      if (!offscreen) return { x, y };
      if (Math.abs(x - this.cam.x) > this.vw / 2 + 40 || Math.abs(y - this.cam.y) > this.vh / 2 + 40) return { x, y };
    }
    return { x: 180 + Math.random() * (WORLD_W - 360), y: 240 };
  }

  spawnNPC(initial = false) {
    const sp = this.pickSpecies();
    const r = sp.minR + Math.random() * (sp.maxR - sp.minR);
    const pos = this.randomSpawnPos(r, !initial, sp.deepPref || "any");
    const f = new Fish("npc", sp, sp.id, pos.x, pos.y, r * r);
    f.face = Math.random() < 0.5 ? 1 : -1;
    f.maxR = sp.maxR * 1.25;
    this.fish.push(f);

    const school =
      sp.id === "minnow"
        ? 4 + Math.floor(Math.random() * 6)
        : sp.id === "boris_npc" || sp.id === "andy_npc"
          ? Math.random() < 0.5
            ? 2 + Math.floor(Math.random() * 3)
            : 0
          : 0;
    if (school > 0) {
      for (let i = 0; i < school; i++) {
        const gr = r * (0.88 + Math.random() * 0.24);
        const gx = pos.x + (Math.random() - 0.5) * 42;
        const gy = pos.y + (Math.random() - 0.5) * 28;
        if (this.isInsideRock(gx, gy, gr + 6)) continue;
        const g = new Fish("npc", sp, sp.id, gx, gy, gr * gr);
        g.face = f.face;
        this.fish.push(g);
      }
    }
  }

  spawnBot(name: string, skin: Skin, mass: number) {
    const sp = skinToSpecies(skin);
    const pos = this.randomSpawnPos(24, true, "any");
    const f = new Fish("bot", sp, "bot-" + skin.id, pos.x, pos.y, mass);
    f.skinRef = skin;
    f.name = name;
    f.color = skin.pal.body;
    f.speedMul = 0.9;
    f.maxR = 62;
    f.invuln = 2;
    this.fish.push(f);
  }

  start(opts: StartOpts) {
    if (this.player) this.player.dead = true;
    const sp = skinToSpecies(opts.skin);
    const pos = this.randomSpawnPos(65, false, "upper");
    pos.y = clamp(pos.y, 180, 660);
    if (this.isInsideRock(pos.x, pos.y, 65)) {
      pos.x = 980;
      pos.y = 320;
    }
    const mass = 58 + opts.upgrades.size * 14;
    const p = new Fish("player", sp, "player-" + opts.skin.id, pos.x, pos.y, mass);
    p.skinRef = opts.skin;
    p.name = opts.name || "Kamu";
    p.color = "#ffffff";
    p.speedMul = 1 + opts.upgrades.speed * 0.07;
    p.suckMul = 1 + opts.upgrades.suck * 0.16;
    p.invuln = 3.5;
    p.maxR = 68;
    this.player = p;
    p.turnFlip = p.face;
    this.fish.push(p);
    this.resize(true);
    this.camVel.x = 0;
    this.camVel.y = 0;
    if (this.mouse.active) {
      this.mouse.sx = this.mouse.x;
      this.mouse.sy = this.mouse.y;
      const W = Math.max(1, window.innerWidth);
      const H = Math.max(1, window.innerHeight);
      const initOffX = clamp((this.mouse.sx / W - 0.5) * this.vw, -this.vw * 0.35, this.vw * 0.35);
      const initOffY = clamp((this.mouse.sy / H - 0.5) * this.vh, -this.vh * 0.35, this.vh * 0.35);
      const minCamX = this.vw >= WORLD_W ? WORLD_W / 2 : this.vw / 2;
      const maxCamX = this.vw >= WORLD_W ? WORLD_W / 2 : WORLD_W - this.vw / 2;
      this.cam.x = clamp(p.x - initOffX, minCamX, maxCamX);
      this.cam.y = clamp(p.y - initOffY, -34 + this.vh / 2, WORLD_H + 35 - this.vh / 2);
    } else {
      this.cam.x = p.x;
      this.cam.y = p.y;
    }
    this.sessionCoins = 0;
    this.arcadeScore = 0;
    this.eatenCount = 0;
    this.startMass = mass;
    this.maxMass = mass;
    this.startTime = this.t;
    this.deathTimer = -1;
    this.level = this.calcLevel(p.r);
    this.flyCoins = [];
    for (const f of this.fish) {
      if (f !== p && f.r > p.r && Math.hypot(f.x - p.x, f.y - p.y) < 480) {
        const np = this.randomSpawnPos(f.r, true);
        f.x = np.x;
        f.y = np.y;
      }
    }
    this.spawnRing(p.x, p.y, "#a5f3fc", 16);
    sfx.levelUp();
  }

  calcLevel(r: number) {
    return SPECIES.filter((s) => s.minR < r * EAT_RATIO).length;
  }

  calcGrowthPct(r: number): number {
    let prevR = 6.5;
    for (let i = 0; i < SPECIES.length; i++) {
      const needR = SPECIES[i].minR / EAT_RATIO;
      if (r < needR) {
        const prevMass = prevR * prevR;
        const needMass = needR * needR;
        const curMass = r * r;
        return clamp((curMass - prevMass) / Math.max(1, needMass - prevMass), 0, 1);
      }
      prevR = needR;
    }
    return 1;
  }

  setSuck(on: boolean) {
    this.suckInput = on;
  }

  setBoost(on: boolean) {
    this.boostInput = on;
  }

  applyBoost(f: Fish, want: boolean, dt: number) {
    const wasBoost = f.boosting;
    if (want && !f.boostExhausted && f.boost > 0) {
      f.boosting = true;
      f.boost -= dt * 0.55;
      if (f.boost <= 0) {
        f.boost = 0;
        f.boostExhausted = true;
        f.boosting = false;
      }
    } else {
      f.boosting = false;
      f.boost = Math.min(1, f.boost + dt * 0.24);
      if (f.boostExhausted && f.boost > 0.35) f.boostExhausted = false;
    }
    if (f.boosting && !wasBoost) {
      f.sqv -= 6;
      const onScreen = Math.abs(f.x - this.cam.x) < this.vw / 2 + 20 && Math.abs(f.y - this.cam.y) < this.vh / 2 + 20;
      if (onScreen) {
        sfx.whoosh();
        const bx = f.x - f.face * f.r;
        for (let i = 0; i < 8; i++) {
          this.particles.push(this.bubble(bx + (Math.random() - 0.5) * f.r, f.y + (Math.random() - 0.5) * f.r, 1 + Math.random() * 2));
        }
        this.spawnRing(bx, f.y, "#bff8ff", f.r * 0.65);
      }
    }
  }

  loop(now: number) {
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.05) dt = 0.05;
    if (this.freeze > 0) {
      this.freeze -= dt;
    } else {
      this.update(dt);
    }
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  }

  resize(instant = false) {
    const focus = this.player && !this.player.dead ? this.player : this.spectate;
    const r = focus ? focus.r : 9;
    const viewH = clamp(275 + (r - 7.6) * 4.5, 275, 650);
    const W = Math.max(1, window.innerWidth);
    const H = Math.max(1, window.innerHeight);
    const targetZoom = Math.max(1, Math.min(H / viewH, W / (viewH * 1.25)));
    this.zoom = instant ? targetZoom : this.zoom + (targetZoom - this.zoom) * 0.06;

    this.coinHudPos = { x: Math.min(W - 38, W / 2 + 465), y: 26 };

    if (this.pixelMode) {
      const qps = Math.max(1, Math.round(this.zoom * 20) / 20);
      const cw = Math.ceil(W / qps);
      const ch = Math.ceil(H / qps);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.dpr = 1;
      this.vw = cw;
      this.vh = ch;
    } else {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cw = Math.round(W * dpr);
      const ch = Math.round(H * dpr);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.dpr = dpr;
      this.vw = W / this.zoom;
      this.vh = H / this.zoom;
    }
  }

  // Smooth sliding collision against rocky overhangs & cavern walls so swimming through crevices feels silky-smooth!
  resolveRockCollisions(f: Fish) {
    const fr = f.r * 0.68;
    for (const c of this.ocean.colliders) {
      const dx = f.x - c.x;
      const dy = f.y - c.y;
      const minD = c.r + fr;
      if (Math.abs(dx) > minD || Math.abs(dy) > minD) continue;
      const d = Math.hypot(dx, dy) || 0.01;
      if (d < minD) {
        const nx = dx / d,
          ny = dy / d;
        const pen = minD - d;
        f.x += nx * pen;
        f.y += ny * pen;
        const vn = f.vx * nx + f.vy * ny;
        if (vn < 0) {
          f.vx -= nx * vn * 1.1;
          f.vy -= ny * vn * 1.1;
        }
      }
    }
  }

  update(dt: number) {
    this.t += dt;
    this.resize();
    const p = this.player;

    if (!p || p.dead) {
      if (!this.spectate || this.spectate.dead) {
        const bots = this.fish.filter((f) => f.kind === "bot" && !f.dead);
        bots.sort((a, b) => b.mass - a.mass);
        this.spectate = bots[Math.floor(Math.random() * Math.min(3, bots.length))] || null;
      }
    }

    if (p && !p.dead && !p.eatenBy) {
      this.applyBoost(p, this.boostInput, dt);
      const W = Math.max(1, window.innerWidth);
      const H = Math.max(1, window.innerHeight);

      // Sub-frame low-pass filter on raw OS mouse pixels: removes hardware stair-step jitter while staying agile!
      if (this.mouse.active) {
        if (this.mouse.sx === 0 && this.mouse.sy === 0) {
          this.mouse.sx = this.mouse.x;
          this.mouse.sy = this.mouse.y;
        } else {
          const mAlpha = 1 - Math.exp(-38 * dt);
          this.mouse.sx += (this.mouse.x - this.mouse.sx) * mAlpha;
          this.mouse.sy += (this.mouse.y - this.mouse.sy) * mAlpha;
        }
      }

      // 1. Silky-smooth ocean camera scrolling when cursor points away from screen center
      const offX = this.mouse.active ? (this.mouse.sx / W - 0.5) * this.vw : 0;
      const offY = this.mouse.active ? (this.mouse.sy / H - 0.5) * this.vh : 0;
      const offD = Math.hypot(offX, offY);
      const ms = this.maxSpeed(p);
      const deadzone = 10;
      let targetCamVx = 0,
        targetCamVy = 0;
      if (offD > deadzone) {
        const norm = clamp((offD - deadzone) / (this.vw * 0.17), 0, 1);
        const smoothCruise = norm * norm * (3 - 2 * norm) * ms;
        targetCamVx = (offX / offD) * smoothCruise;
        targetCamVy = (offY / offD) * smoothCruise;
      } else if (p.boosting) {
        targetCamVx = p.face * ms;
      }

      const camSmooth = 1 - Math.exp(-10 * dt);
      this.camVel.x += (targetCamVx - this.camVel.x) * camSmooth;
      this.camVel.y += (targetCamVy - this.camVel.y) * camSmooth;

      const minCamX = this.vw >= WORLD_W ? WORLD_W / 2 : this.vw / 2;
      const maxCamX = this.vw >= WORLD_W ? WORLD_W / 2 : WORLD_W - this.vw / 2;
      const minCamY = -34 + this.vh / 2;
      const maxCamY = WORLD_H + 35 - this.vh / 2;
      this.cam.x = clamp(this.cam.x + this.camVel.x * dt, minCamX, maxCamX);
      this.cam.y = clamp(this.cam.y + this.camVel.y * dt, minCamY, maxCamY);

      // 2. Buttery-Smooth, Ultra-Responsive Fish Gliding (zero jitter, agile dodging, comfortable water cushion!)
      if (this.mouse.active) {
        const baseCamLeft = this.vw >= WORLD_W ? (WORLD_W - this.vw) / 2 : clamp(this.cam.x - this.vw / 2, 0, WORLD_W - this.vw);
        const baseCamTop = clamp(this.cam.y - this.vh / 2, -34, WORLD_H + 35 - this.vh);
        const tx = clamp(baseCamLeft + (this.mouse.sx / W) * this.vw, p.r, WORLD_W - p.r);
        const ty = clamp(baseCamTop + (this.mouse.sy / H) * this.vh, 14 + p.r * 0.5, floorY(tx) - p.r * 0.6);

        const prevX = p.x,
          prevY = p.y;
        const follow = 1 - Math.exp(-26 * dt);
        const totalDx = (tx - p.x) * follow;
        const totalDy = (ty - p.y) * follow;
        const stepDist = Math.hypot(totalDx, totalDy);
        const steps = Math.min(12, Math.max(1, Math.ceil(stepDist / 8)));
        for (let s = 0; s < steps; s++) {
          p.x += totalDx / steps;
          p.y += totalDy / steps;
          this.resolveRockCollisions(p);
          const fy = floorY(p.x) - p.r * 0.6;
          if (p.y > fy) p.y = fy;
          if (p.y < 14 + p.r * 0.5) p.y = 14 + p.r * 0.5;
          p.x = clamp(p.x, p.r, WORLD_W - p.r);
        }

        // Softly keep camera leashed if player slides along a rock formation
        this.cam.x = clamp(this.cam.x, Math.max(minCamX, p.x - this.vw * 0.44), Math.min(maxCamX, p.x + this.vw * 0.44));
        this.cam.y = clamp(this.cam.y, Math.max(minCamY, p.y - this.vh * 0.44), Math.min(maxCamY, p.y + this.vh * 0.44));

        const instVx = (p.x - prevX) / Math.max(0.001, dt);
        const instVy = (p.y - prevY) / Math.max(0.001, dt);
        const vSmooth = 1 - Math.exp(-15 * dt);
        p.vx += (instVx - p.vx) * vSmooth;
        p.vy += (instVy - p.vy) * vSmooth;

        // Hysteresis deadband so tiny hand tremors NEVER flip the fish left/right!
        const cursorDx = tx - p.x;
        if (cursorDx > 3.2 || (Math.abs(cursorDx) > 1.2 && p.vx > 24)) {
          p.face = 1;
        } else if (cursorDx < -3.2 || (Math.abs(cursorDx) > 1.2 && p.vx < -24)) {
          p.face = -1;
        }
      } else if (p.boosting) {
        p.vx = p.face * ms;
        p.vy = 0;
        p.x = clamp(p.x + p.vx * dt, p.r, WORLD_W - p.r);
        this.resolveRockCollisions(p);
      }

      this.applySuckState(p, this.suckInput, dt);
      sfx.setSuck(p.sucking);
    } else {
      sfx.setSuck(false);
    }

    const predators = this.fish.filter((f) => !f.dead && !f.eatenBy && (f.kind !== "npc" || f.sp.predator));
    for (const f of this.fish) {
      if (f.dead || f.eatenBy || f.kind === "player") continue;
      f.ai.timer -= dt;
      if (f.kind === "bot") this.botAI(f, dt);
      else this.npcAI(f, dt, predators);
    }

    for (const f of this.fish) {
      if (f.sucking && !f.dead && !f.eatenBy) this.doSuck(f, dt);
    }

    for (const f of this.fish) {
      if (f.dead) continue;
      if (f.eatenBy) {
        f.eatT += dt / 0.14;
        if (f.eatT >= 1) this.finishEat(f.eatenBy, f);
        continue;
      }
      const isDirectPlayer = f === p && this.mouse.active;
      if (!isDirectPlayer) {
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        this.resolveRockCollisions(f);

        const fy = floorY(f.x) - f.r * 0.6;
        if (f.y > fy) {
          f.y = fy;
          f.vy = Math.min(0, f.vy);
        }
        if (f.y < 14 + f.r * 0.5) {
          f.y = 14 + f.r * 0.5;
          f.vy = Math.max(0, f.vy);
        }
        if (f.x < f.r) {
          f.x = f.r;
          f.vx = Math.abs(f.vx);
        }
        if (f.x > WORLD_W - f.r) {
          f.x = WORLD_W - f.r;
          f.vx = -Math.abs(f.vx);
        }
      }
      const sp = Math.hypot(f.vx, f.vy);
      if (!isDirectPlayer && Math.abs(f.vx) > 6) f.face = f.vx > 0 ? 1 : -1;

      // Smooth 3D-like turn flip (-1 .. +1) & gentle damped pitch tilt (zero micro-jitter when hovering!)
      const flipRate = 1 - Math.exp(-(f.kind === "player" ? 20 : 12) * dt);
      f.turnFlip += (f.face - f.turnFlip) * flipRate;

      const speedFactor = clamp((sp - 6) / 38, 0, 1);
      const targTilt = clamp(Math.atan2(f.vy, Math.abs(f.vx) + 28) * 0.62, -0.42, 0.42) * speedFactor;
      const tiltRate = 1 - Math.exp(-(f.kind === "player" ? 13 : 6.5) * dt);
      f.tilt += (targTilt - f.tilt) * tiltRate;
      f.tailPh += dt * (4.8 + Math.min(sp, 320) * 0.068);

      // Gentle breathing suction squash (no 40Hz buzz!) + smooth suction mist fade
      const targetSq = f.sucking ? 0.1 + Math.sin(this.t * 9) * 0.02 : 0;
      f.sqv += (-220 * (f.sq - targetSq) - 15 * f.sqv) * dt;
      f.sq += f.sqv * dt;
      const suckFade = 1 - Math.exp(-(f.sucking ? 14 : 10) * dt);
      f.suckVis += ((f.sucking ? 1 : 0) - f.suckVis) * suckFade;

      f.mouthOpenT -= dt;
      f.chompT -= dt;
      f.invuln -= dt;
      f.sucked -= dt;
      f.comboT -= dt;
      if (f.comboT <= 0) f.combo = 0;

      let jawTarget = 0;
      if (f.chompT > 0.06) jawTarget = 0;
      else if (f.mouthOpenT > 0) jawTarget = 1;
      else if (f.sucking) jawTarget = 0.9;
      else if (f.wantOpen) jawTarget = 0.72;
      else if (Math.sin(this.t * 2.2 + f.id) > 0.9) jawTarget = 0.32;
      const jawSpeed = jawTarget > f.jaw ? 18 : 22;
      f.jaw += (jawTarget - f.jaw) * Math.min(1, dt * jawSpeed);

      const tr = Math.sqrt(f.mass);
      f.r += (tr - f.r) * Math.min(1, dt * 3.2);
      f.wantOpen = false;
      if (f.kind !== "player" && !f.sucking) {
        f.energy = Math.min(1, f.energy + dt * 0.3);
      }
      if (f.boosting) {
        f.boostTrail -= dt;
        if (f.boostTrail <= 0 && Math.abs(f.x - this.cam.x) < this.vw && Math.abs(f.y - this.cam.y) < this.vh) {
          f.boostTrail = 0.036;
          const bx = f.x - f.face * f.r * 1.1,
            by = f.y + (Math.random() - 0.5) * f.r * 0.75;
          this.particles.push(this.bubble(bx, by, 0.9 + Math.random() * 1.3));
        }
      }
      if (f.kind === "npc" && Math.random() < dt * 0.15) this.particles.push(this.bubble(f.mouthX(), f.mouthY(), 1));
    }

    this.checkEating();

    this.fish = this.fish.filter((f) => !f.dead || f === this.player);
    if (this.player && this.player.dead) this.fish = this.fish.filter((f) => f !== this.player);
    let npcCount = 0;
    for (const f of this.fish) if (f.kind === "npc") npcCount++;
    if (npcCount < NPC_TARGET) for (let i = 0; i < Math.min(8, NPC_TARGET - npcCount); i++) this.spawnNPC();
    if (p && !p.dead && Math.random() < dt * 2) {
      const cand = this.fish[Math.floor(Math.random() * this.fish.length)];
      if (cand && cand.kind === "npc" && cand.r < p.r * 0.25 && Math.abs(cand.x - p.x) > this.vw) cand.dead = true;
    }
    for (const q of this.respawnQueue) q.t -= dt;
    const ready = this.respawnQueue.filter((q) => q.t <= 0);
    this.respawnQueue = this.respawnQueue.filter((q) => q.t > 0);
    for (const q of ready) this.spawnBot(q.name, q.skin, 58 + Math.random() * 140);

    // Spawn coins both from surface and inside glowing deep crevices!
    this.coinTimer -= dt;
    if (this.coinTimer <= 0) {
      this.coinTimer = 1.1 + Math.random() * 1.3;
      const x = this.cam.x + (Math.random() - 0.5) * this.vw * 1.4;
      this.worldCoins.push({
        x: clamp(x, 20, WORLD_W - 20),
        y: Math.random() < 0.35 ? DEEP_START + 120 + Math.random() * 550 : -4,
        vx: 0,
        vy: 16 + Math.random() * 14,
        t: 0,
        value: Math.random() < 0.35 ? 3 : 1 + Math.floor(Math.random() * 2),
        settled: false,
      });
      if (Math.random() < 0.35) {
        const c = this.ocean.chestPos;
        this.worldCoins.push({
          x: c.x,
          y: c.y - 6,
          vx: (Math.random() - 0.5) * 45,
          vy: -45 - Math.random() * 30,
          t: 0,
          value: 3,
          settled: false,
        });
      }
    }
    for (const c of this.worldCoins) {
      c.t += dt;
      if (!c.settled) {
        c.vy += (24 - c.vy) * dt * 0.8;
        c.vx *= 1 - dt * 1.5;
        c.x += c.vx * dt + Math.sin(c.t * 3) * 0.3;
        c.y += c.vy * dt;
        if (c.y > floorY(c.x) - 3) {
          c.y = floorY(c.x) - 3;
          c.settled = true;
        }
      }
      if (p && !p.dead && !p.eatenBy) {
        const d = Math.hypot(c.x - p.mouthX(), c.y - p.mouthY());
        if (d < p.r * 0.9 + 6) {
          c.t = 999;
          for (let i = 0; i < c.value; i++) this.addFlyCoin(c.x, c.y, 1);
          this.arcadeScore += c.value * 50;
          this.texts.push({ x: c.x, y: c.y - 6, text: "+" + c.value, color: "#ffe14a", life: 0.8, max: 0.8, size: 9 });
          this.spawnSparks(c.x, c.y, "#ffe14a", 6);
        }
      }
    }
    this.worldCoins = this.worldCoins.filter((c) => c.t < 24 && c.y < WORLD_H + 10);

    const hx = this.camLeft + (this.coinHudPos.x / Math.max(1, window.innerWidth)) * this.vw;
    const hy = this.camTop + (this.coinHudPos.y / Math.max(1, window.innerHeight)) * this.vh;
    for (const c of this.flyCoins) {
      c.t += dt;
      if (c.t < 0.35) {
        c.vy += 220 * dt;
        c.vx *= 1 - dt * 3;
        c.x += c.vx * dt;
        c.y += c.vy * dt;
      } else {
        const dx = hx - c.x,
          dy = hy - c.y;
        const d = Math.hypot(dx, dy) || 1;
        const sp = 200 + (c.t - 0.35) * 1400;
        c.x += (dx / d) * Math.min(d, sp * dt);
        c.y += (dy / d) * Math.min(d, sp * dt);
        if (d < 6) {
          c.t = 999;
          this.sessionCoins += c.value;
          sfx.coin();
          this.onEvent?.({ type: "coinbump" });
        }
      }
    }
    this.flyCoins = this.flyCoins.filter((c) => c.t < 999);

    if (Math.random() < dt * 7) {
      const v = this.ocean.vents[Math.floor(Math.random() * this.ocean.vents.length)];
      if (Math.abs(v.x - this.cam.x) < this.vw) this.particles.push(this.bubble(v.x + (Math.random() - 0.5) * 8, v.y, 1.2 + Math.random() * 2.2));
    }

    for (const pt of this.particles) {
      pt.life -= dt;
      if (pt.type === "bubble") {
        pt.vy -= 28 * dt;
        pt.vx = Math.sin(pt.life * 5.5 + pt.size) * 6;
        if (pt.y < 4) pt.life = 0;
      } else if (pt.type === "bit") {
        pt.vy += 45 * dt;
        pt.vx *= 1 - dt * 2.2;
        pt.vy *= 1 - dt * 1.2;
      } else if (pt.type === "suck" && pt.target) {
        const tx = pt.target.mouthX(),
          ty = pt.target.mouthY();
        const dx = tx - pt.x,
          dy = ty - pt.y;
        const d = Math.hypot(dx, dy) || 1;
        // Soft curved inward spiral toward mouth!
        const tangX = -dy / d,
          tangY = dx / d;
        const s = 135 + (pt.max - pt.life) * 280;
        pt.vx = (dx / d) * s + tangX * 26 * Math.sin(pt.size * 5);
        pt.vy = (dy / d) * s + tangY * 26 * Math.sin(pt.size * 5);
        if (d < 4 || pt.target.suckVis < 0.05) pt.life = 0;
      } else if (pt.type === "spark" || pt.type === "star") {
        pt.vx *= 1 - dt * 4;
        pt.vy *= 1 - dt * 4;
      }
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
    }
    this.particles = this.particles.filter((pt) => pt.life > 0);
    if (this.particles.length > 900) this.particles.splice(0, this.particles.length - 900);
    for (const tx of this.texts) {
      tx.life -= dt;
      tx.y -= dt * 18;
    }
    this.texts = this.texts.filter((tx) => tx.life > 0);

    // Camera smooth-follow only when spectating or during death animation (live player camera is driven above!)
    if (!p || p.dead || p.eatenBy) {
      const focus = p && !p.dead ? p.eatenBy || p : this.deathTimer >= 0 ? null : this.spectate;
      if (focus) {
        const lead = focus.vx * 0.22;
        this.cam.x += (focus.x + lead - this.cam.x) * Math.min(1, dt * 4.5);
        this.cam.y += (focus.y + focus.vy * 0.14 - this.cam.y) * Math.min(1, dt * 4.5);
      }
    }
    this.shake = Math.max(0, this.shake - dt * 20);

    if (this.deathTimer >= 0) {
      this.deathTimer -= dt;
      if (this.deathTimer < 0) {
        this.deathTimer = -1;
        for (const c of this.flyCoins) this.sessionCoins += c.value;
        this.flyCoins = [];
        this.onDeath?.({
          score: this.arcadeScore,
          coins: this.sessionCoins,
          killer: this.killerName,
          maxMass: Math.round(this.maxMass),
          eaten: this.eatenCount,
          time: Math.round(this.t - this.startTime),
        });
      }
    }

    if (p && !p.dead) {
      this.maxMass = Math.max(this.maxMass, p.mass);
      const lv = this.calcLevel(p.r);
      if (lv > this.level) {
        this.level = lv;
        const sp = SPECIES[Math.min(lv - 1, SPECIES.length - 1)];
        this.onEvent?.({ type: "levelup", text: "Ukuran naik! Bisa makan " + sp.name + "!" });
        sfx.levelUp();
        this.spawnRing(p.x, p.y, "#fff6a0", p.r * 2.1);
        this.spawnSparks(p.x, p.y, "#ffffff", 18);
      }
    }

    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.08;
      this.emitHud();
    }
    this.miniTimer -= dt;
    if (this.miniTimer <= 0) {
      this.miniTimer = 0.15;
      this.drawMinimap();
    }
  }

  maxSpeed(f: Fish) {
    if (f.kind === "npc") return f.sp.speed * NPC_SPEED;
    return 150 * Math.pow(8 / Math.max(8, f.r), 0.14) * f.speedMul * (f.boosting ? 1.85 : 1);
  }

  applySuckState(f: Fish, want: boolean, dt: number) {
    if (want && !f.exhausted && f.energy > 0) {
      f.sucking = true;
      f.energy -= (dt * 0.42) / (0.85 + f.suckMul * 0.15);
      if (f.energy <= 0) {
        f.energy = 0;
        f.exhausted = true;
        f.sucking = false;
      }
    } else {
      f.sucking = false;
      f.energy = Math.min(1, f.energy + dt * 0.28);
      if (f.exhausted && f.energy > 0.3) f.exhausted = false;
    }
  }

  suckRange(f: Fish) {
    return (f.r * 3.2 + 28) * f.suckMul;
  }

  doSuck(f: Fish, dt: number) {
    const mx = f.mouthX(),
      my = f.mouthY();
    const dirx = f.face * Math.cos(f.tilt),
      diry = Math.sin(f.tilt);
    const range = this.suckRange(f);
    for (const o of this.fish) {
      if (o === f || o.dead || o.eatenBy || o.invuln > 0) continue;
      if (o.r >= f.r * EAT_RATIO) continue;
      const dx = o.x - mx,
        dy = o.y - my;
      if (Math.abs(dx) > range + o.r || Math.abs(dy) > range + o.r) continue;
      const d = Math.hypot(dx, dy);
      if (d > range + o.r || d < 0.1) continue;
      const cos = (dx * dirx + dy * diry) / d;
      if (cos < 0.45) continue;
      const strength = 350 * f.suckMul * (1.1 - d / (range + o.r)) * clamp((f.r / o.r) * 0.45, 0.35, 1.4);
      o.vx -= (dx / d) * strength * dt * 3;
      o.vy -= (dy / d) * strength * dt * 3;
      o.vx *= 1 - dt * 2;
      o.vy *= 1 - dt * 2;
      o.sucked = 0.18;
      f.wantOpen = true;
    }
    if (f.kind === "player") {
      for (const c of this.worldCoins) {
        const dx = c.x - mx,
          dy = c.y - my;
        const d = Math.hypot(dx, dy);
        if (d < range * 1.2 && (dx * dirx + dy * diry) / (d || 1) > 0.3) {
          c.settled = false;
          c.vx = (-dx / d) * 160;
          c.vy = (-dy / d) * 160;
        }
      }
    }
    const onScreen = Math.abs(mx - this.cam.x) < this.vw && Math.abs(my - this.cam.y) < this.vh;
    if (onScreen && Math.random() < 0.65) {
      const a = Math.atan2(diry, dirx) + (Math.random() - 0.5) * 1.05;
      const dd = range * (0.45 + Math.random() * 0.48);
      this.particles.push({
        x: mx + Math.cos(a) * dd,
        y: my + Math.sin(a) * dd,
        vx: 0,
        vy: 0,
        life: 0.72,
        max: 0.72,
        type: "suck",
        color: "#a5f3fc",
        size: 0.9 + Math.random() * 1.0,
        target: f,
      });
    }
  }

  botAI(f: Fish, dt: number) {
    if (f.ai.timer <= 0) {
      f.ai.timer = 0.2 + Math.random() * 0.15;
      let threat: Fish | null = null,
        td = 1e9;
      let best: Fish | null = null,
        bv = 0;
      for (const o of this.fish) {
        if (o === f || o.dead || o.eatenBy) continue;
        const dx = o.x - f.x,
          dy = o.y - f.y;
        if (Math.abs(dx) > 300 || Math.abs(dy) > 300) continue;
        const d = Math.hypot(dx, dy);
        if (o.r * EAT_RATIO > f.r && (o.kind !== "npc" || o.sp.predator)) {
          if (d < 80 + o.r * 2.2 && d < td) {
            td = d;
            threat = o;
          }
        } else if (o.r < f.r * EAT_RATIO && o.invuln <= 0 && d < 260) {
          const pw = o.kind === "player" ? (this.t - this.startTime < 12 ? 0.25 : o.mass < 160 ? 0.6 : 1.1) : 1;
          const v = (o.mass * pw) / (d + 40);
          if (v > bv) {
            bv = v;
            best = o;
          }
        }
      }
      f.ai.flee = !!threat;
      if (threat) {
        const dx = f.x - threat.x,
          dy = f.y - threat.y;
        const d = Math.hypot(dx, dy) || 1;
        f.ai.tx = f.x + (dx / d) * 200;
        f.ai.ty = f.y + (dy / d) * 200;
        f.ai.target = null;
      } else if (best) {
        f.ai.target = best;
      } else {
        f.ai.target = null;
        if (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 30 || Math.random() < 0.05) {
          const p = this.randomSpawnPos(f.r, false);
          f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 600, 40, WORLD_W - 40);
          f.ai.ty = p.y;
        }
      }
    }
    let tx = f.ai.tx,
      ty = f.ai.ty;
    const tgt = f.ai.target;
    if (tgt && !tgt.dead && !tgt.eatenBy) {
      tx = tgt.x + tgt.vx * 0.3;
      ty = tgt.y + tgt.vy * 0.3;
    }
    const dx = tx - f.x,
      dy = ty - f.y;
    const d = Math.hypot(dx, dy) || 1;
    let wantBoost = false;
    if (f.ai.flee && f.boost > 0.25) wantBoost = true;
    if (tgt && !tgt.dead && d < 90 && d > this.suckRange(f) * 0.5 && f.boost > 0.5 && Math.random() < 0.6) wantBoost = true;
    this.applyBoost(f, wantBoost, dt);
    const ms = this.maxSpeed(f) * (f.ai.flee || f.boosting ? 1 : 0.85);
    f.vx += ((dx / d) * ms - f.vx) * Math.min(1, dt * 6);
    f.vy += ((dy / d) * ms - f.vy) * Math.min(1, dt * 6);
    const wantSuck = !!tgt && !tgt.dead && d < this.suckRange(f) * 0.9 && Math.sign(dx) === f.face && f.energy > 0.2;
    this.applySuckState(f, wantSuck, dt);
    if (f.mass > 3200) f.mass -= dt * 14;
  }

  npcAI(f: Fish, dt: number, predators: Fish[]) {
    if (f.ai.timer <= 0) {
      f.ai.timer = 0.25 + Math.random() * 0.25;
      f.ai.flee = false;
      let threat: Fish | null = null,
        td = 1e9;
      for (const o of predators) {
        if (o === f || o.r * EAT_RATIO <= f.r) continue;
        const dx = o.x - f.x,
          dy = o.y - f.y;
        if (Math.abs(dx) > 150 || Math.abs(dy) > 150) continue;
        const d = Math.hypot(dx, dy);
        if (d < 50 + o.r * 1.6 && d < td) {
          td = d;
          threat = o;
        }
      }
      if (threat && Math.random() < 0.85) {
        const dx = f.x - threat.x,
          dy = f.y - threat.y;
        const d = Math.hypot(dx, dy) || 1;
        f.ai.tx = f.x + (dx / d) * 120;
        f.ai.ty = f.y + (dy / d) * 120;
        f.ai.flee = true;
      } else if (f.sp.predator) {
        f.ai.rest -= 0.3;
        if (f.ai.chase > 0) f.ai.chase -= 0.3;
        if (f.ai.target && (f.ai.target.dead || f.ai.target.eatenBy || f.ai.chase <= 0)) {
          f.ai.target = null;
          f.ai.rest = 3;
        }
        if (!f.ai.target && f.ai.rest <= 0) {
          let best: Fish | null = null,
            bd = 170;
          for (const o of this.fish) {
            if (o === f || o.dead || o.r >= f.r * EAT_RATIO || o.invuln > 0) continue;
            if (o.kind === "npc" && o.r < f.r * 0.25) continue;
            const d = Math.hypot(o.x - f.x, o.y - f.y);
            const w = o.kind === "npc" ? d * 1.5 : d;
            if (w < bd) {
              bd = w;
              best = o;
            }
          }
          if (best) {
            f.ai.target = best;
            f.ai.chase = 3.5;
          }
        }
        if (!f.ai.target && (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 20 || Math.random() < 0.04)) {
          f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 500, 40, WORLD_W - 40);
          f.ai.ty = clamp(f.y + (Math.random() - 0.5) * 240, 80, floorY(f.x) - 50);
        }
      } else if (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 15 || Math.random() < 0.06) {
        f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 260, 20, WORLD_W - 20);
        f.ai.ty = clamp(f.y + (Math.random() - 0.5) * 140, 30, floorY(f.x) - 25);
      }
    }
    if (f.sucked > 0) return;
    let tx = f.ai.tx,
      ty = f.ai.ty;
    const tgt = f.ai.target;
    let boost = f.ai.flee ? 1.35 : 0.55;
    if (tgt && !tgt.dead) {
      tx = tgt.x;
      ty = tgt.y;
      boost = 1.2;
    }
    const dx = tx - f.x,
      dy = ty - f.y;
    const d = Math.hypot(dx, dy) || 1;
    const ms = f.sp.speed * NPC_SPEED * boost * (d < 10 ? d / 10 : 1);
    f.vx += ((dx / d) * ms - f.vx) * Math.min(1, dt * 4);
    f.vy += ((dy / d) * ms - f.vy) * Math.min(1, dt * 4);
  }

  checkEating() {
    const list = this.fish;
    for (const e of list) {
      if (e.dead || e.eatenBy) continue;
      if (e.kind === "npc" && !e.sp.predator) continue;
      if (e.chompT > 0.08) continue;
      const mx = e.mouthX(),
        my = e.mouthY();
      for (const o of list) {
        if (o === e || o.dead || o.eatenBy || o.invuln > 0) continue;
        if (o.r >= e.r * EAT_RATIO) continue;
        if (e.kind === "npc" && o.kind === "npc" && o.r < e.r * 0.25) continue;
        const dx = o.x - mx,
          dy = o.y - my;
        const reach = o.r + e.r * 0.5;
        if (Math.abs(dx) > reach * 3.0 || Math.abs(dy) > reach * 3.0) continue;
        const d = Math.hypot(dx, dy);
        if (d < reach * 2.8) e.wantOpen = true;
        if (d < reach || Math.hypot(o.x - e.x, o.y - e.y) < e.r * 0.55) {
          this.startEat(e, o);
          break;
        }
      }
    }
  }

  startEat(e: Fish, o: Fish) {
    o.eatenBy = e;
    o.eatT = 0;
    o.eatFromX = o.x;
    o.eatFromY = o.y;
    o.sucking = false;
    o.boosting = false;
    e.jaw = 1;
    e.mouthOpenT = 0.14;
    if (o === this.player) {
      sfx.setSuck(false);
    }
  }

  finishEat(e: Fish, o: Fish) {
    o.dead = true;
    o.eatenBy = null;
    const mx = e.mouthX(),
      my = e.mouthY();

    if (e.kind === "npc") {
      e.mass += o.mass * 0.025;
    } else {
      const taper = 1 / (1 + Math.max(0, e.r - 8) * 0.04);
      const rawGain = o.mass * GAIN * taper;
      const maxStep = e.mass * 0.055 + 2.0;
      e.mass += Math.min(rawGain, maxStep);
    }
    if (e.r > e.maxR) e.mass = e.maxR * e.maxR;

    e.jaw = 0;
    e.chompT = 0.26;
    e.sqv += 9.5 + Math.min(6, o.r / e.r) * 4.5;
    e.vx += e.face * Math.cos(e.tilt) * 18;
    e.vy += Math.sin(e.tilt) * 18;
    e.score += Math.round(o.mass * 12);

    const onScreen = Math.abs(mx - this.cam.x) < this.vw && Math.abs(my - this.cam.y) < this.vh;
    if (onScreen) {
      this.particles.push({
        x: mx + e.face * e.r * 0.15,
        y: my,
        vx: e.face * 10,
        vy: 0,
        life: 0.22,
        max: 0.22,
        type: "chomp",
        color: "#e0f7ff",
        size: Math.max(6, e.r * 0.65),
        dir: e.face,
      });

      const cols = [o.sp.pal.body, o.sp.pal.belly, o.sp.pal.fin];
      const n = 7 + Math.min(12, Math.round(o.r));
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const s = 20 + Math.random() * 58;
        this.particles.push({
          x: mx,
          y: my,
          vx: Math.cos(a) * s + e.face * 18,
          vy: Math.sin(a) * s - 16,
          life: 0.5 + Math.random() * 0.4,
          max: 0.9,
          type: "bit",
          color: cols[i % 3],
          size: 1.6 + Math.random() * 1.6,
        });
      }
      for (let i = 0; i < 4; i++) this.particles.push(this.bubble(mx + (Math.random() - 0.5) * 8, my, 1.2 + Math.random() * 2.2));
      this.spawnRing(mx, my, "#bae6fd", Math.max(5, o.r));
    }

    if (e === this.player) {
      e.combo++;
      e.comboT = 2.6;
      const mult = e.combo >= 10 ? 3 : e.combo >= 5 ? 2 : 1;
      const pts = Math.round((45 + o.mass * 3.5 + (o.kind === "bot" ? 500 : 0)) * mult);
      this.arcadeScore += pts;

      let coins = Math.max(1, Math.round(o.r / 2.6)) * mult;
      if (o.kind === "bot") coins += 15;
      const n = Math.min(coins, 10);
      for (let i = 0; i < n; i++) {
        const v = Math.floor(coins / n) + (i < coins % n ? 1 : 0);
        this.addFlyCoin(mx, my, v);
      }
      this.eatenCount++;
      this.texts.push({ x: mx, y: my - e.r * 0.8, text: "+" + pts, color: "#fff3a1", life: 0.85, max: 0.85, size: 8 });
      if (Math.random() < 0.55 || o.r > e.r * 0.5) {
        this.texts.push({
          x: mx + (Math.random() - 0.5) * 10,
          y: my - e.r * 1.4 - 8,
          text: WORDS[Math.floor(Math.random() * WORDS.length)],
          color: "#ffffff",
          life: 0.7,
          max: 0.7,
          size: 9,
        });
      }
      sfx.gulp(o.r / 6);
      this.shake = Math.min(5, this.shake + 0.8 + o.r / 6);
      if (o.r > 10) this.freeze = 0.04;
      if (e.combo === 7 || e.combo === 14 || e.combo === 22) {
        this.onEvent?.({ type: "frenzy", n: e.combo });
        sfx.frenzy();
        this.spawnSparks(e.x, e.y, "#ffe14a", 22);
      } else if (e.combo >= 3) {
        this.onEvent?.({ type: "combo", n: e.combo });
        sfx.combo(e.combo);
      }
      if (o.kind === "bot") this.onEvent?.({ type: "feed", text: `${e.name} memakan ${o.name}!` });
    } else if (onScreen && Math.abs(mx - this.cam.x) < this.vw / 2) {
      sfx.gulp(o.r / 6);
    }

    if (o.kind === "bot") {
      this.respawnQueue.push({ t: 3 + Math.random() * 3, name: o.name, skin: o.skinRef || SKINS[0] });
      if (e.kind === "bot") this.onEvent?.({ type: "feed", text: `${e.name} memakan ${o.name}!` });
    }
    if (o === this.player) {
      this.killerName = e.name || e.sp.name;
      this.deathTimer = 1.6;
      this.shake = 9;
      sfx.die();
      sfx.setSuck(false);
      this.texts.push({ x: mx, y: my - e.r - 10, text: "DIMAKAN!", color: "#ff5a6a", life: 1.5, max: 1.5, size: 16 });
      this.onEvent?.({ type: "feed", text: `${this.killerName} memakan ${o.name}!` });
      this.spectate = e;
    }
  }

  addFlyCoin(x: number, y: number, value: number) {
    const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.2;
    const s = 60 + Math.random() * 80;
    this.flyCoins.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, t: Math.random() * 0.1, value });
  }

  bubble(x: number, y: number, size: number): Particle {
    return { x, y, vx: 0, vy: -10 - Math.random() * 10, life: 2.2 + Math.random() * 2, max: 4.2, type: "bubble", color: "#e8ffff", size };
  }

  spawnRing(x: number, y: number, color: string, size: number) {
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0.36, max: 0.36, type: "ring", color, size });
  }

  spawnSparks(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 38 + Math.random() * 85;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.55 + Math.random() * 0.4,
        max: 0.95,
        type: Math.random() < 0.5 ? "star" : "spark",
        color,
        size: 1.8,
      });
    }
  }

  emitHud() {
    const p = this.player;
    const ranked = this.fish.filter((f) => (f.kind === "bot" || f.kind === "player") && !f.dead).sort((a, b) => b.mass - a.mass);
    this.leaderId = ranked[0]?.id ?? -1;
    const rank = p && !p.dead ? ranked.indexOf(p) + 1 : 0;
    const frenzyStage = p ? Math.min(7, p.combo) : 0;
    const py = p ? p.y : this.cam.y;
    const depthM = Math.max(1, Math.round(py * 0.1));
    const biome =
      py < 560
        ? "Laguna Cahaya Surya"
        : py < 1220
          ? "Ngarai Terumbu Senja"
          : "Gua Kristal Bioluminesensi";
    const zoneName = `${biome} (${depthM}m)`;
    this.onHud?.({
      coins: this.sessionCoins,
      score: this.arcadeScore,
      mass: p ? Math.round(p.mass) : 0,
      energy: p ? p.energy : 0,
      combo: p ? p.combo : 0,
      comboT: p ? p.comboT : 0,
      frenzyStage,
      level: this.level,
      growthPct: p ? this.calcGrowthPct(p.r) : 0,
      stageNum: Math.max(1, this.level - 1),
      zoneName,
      rank,
      total: ranked.length,
      leaderboard: ranked.slice(0, 6).map((f) => ({ name: f.name, score: Math.round(f.mass), me: f === p, color: f.sp.pal.body })),
      alive: !!p && !p.dead && this.deathTimer < 0,
      exhausted: p ? p.exhausted : false,
      boost: p ? p.boost : 0,
      boostExhausted: p ? p.boostExhausted : false,
      sucking: p ? p.sucking : false,
      boosting: p ? p.boosting : false,
    });
  }

  drawMinimap() {
    const m = this.minimap;
    if (!m) return;
    const c = m.getContext("2d")!;
    const w = m.width,
      h = m.height;
    const mg = c.createLinearGradient(0, 0, 0, h);
    mg.addColorStop(0, "#155e8a");
    mg.addColorStop(0.45, "#0c2d5e");
    mg.addColorStop(1, "#050d28");
    c.fillStyle = mg;
    c.fillRect(0, 0, w, h);

    const sx = w / WORLD_W,
      sy = h / WORLD_H;

    // Show cavern rock islands & crevices on minimap!
    c.fillStyle = "rgba(38, 95, 145, 0.7)";
    for (const col of this.ocean.colliders) {
      c.beginPath();
      c.arc(col.x * sx, col.y * sy, Math.max(1.5, col.r * sx * 1.2), 0, Math.PI * 2);
      c.fill();
    }

    c.fillStyle = "#4c2882";
    for (let x = 0; x < w; x++) {
      const fy = (floorY((x / w) * WORLD_W) / WORLD_H) * h;
      c.fillRect(x, fy, 1, h - fy);
    }

    c.strokeStyle = "rgba(255,245,190,0.75)";
    c.lineWidth = 1;
    c.strokeRect(this.camLeft * sx + 0.5, this.camTop * sy + 0.5, this.vw * sx, this.vh * sy);
    const p = this.player;
    for (const f of this.fish) {
      if (f.dead) continue;
      if (f.kind === "bot") {
        c.fillStyle = p && !p.dead && f.r * EAT_RATIO > p.r ? "#ff4a5a" : f.sp.pal.body;
        c.beginPath();
        c.arc(f.x * sx, f.y * sy, 1.9, 0, Math.PI * 2);
        c.fill();
      } else if (f.kind === "npc" && f.sp.predator) {
        c.fillStyle = "#ff8a8a";
        c.fillRect(f.x * sx - 1, f.y * sy - 1, 2, 2);
      }
    }
    if (p && !p.dead) {
      c.fillStyle = "#ffffff";
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, 3.2, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = "#ffa22a";
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, 2, 0, Math.PI * 2);
      c.fill();
    }
  }

  // Draws 100% Seamless, Line-Free, Velvety Water Suction Mist (zero lines, zero triangle cone borders!)
  drawSoftSuctionVortex(f: Fish, camLeft: number, camTop: number, vw: number, vh: number) {
    if (f.suckVis < 0.02) return;
    const mx = f.mouthX() - camLeft,
      my = f.mouthY() - camTop;
    if (mx < -180 || mx > vw + 180 || my < -180 || my > vh + 180) return;

    const ctx = this.ctx;
    const range = this.suckRange(f);
    // Notice: mouthX() is in front of fish along f.face!
    const ang = Math.atan2(Math.sin(f.tilt), f.face * Math.cos(f.tilt));
    const vis = f.suckVis;

    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.translate(mx, my);
    ctx.rotate(ang);

    // 1. Soft, completely borderless elliptical aqua mist STRICTLY in front of the mouth (ZERO straight edges!)
    ctx.save();
    ctx.translate(range * 0.48, 0);
    ctx.scale(1, 0.56);
    const rCloud = range * 0.52;
    const rg = ctx.createRadialGradient(-rCloud * 0.35, 0, 1, 0, 0, rCloud);
    rg.addColorStop(0, `rgba(215, 253, 255, ${0.42 * vis})`);
    rg.addColorStop(0.45, `rgba(130, 236, 255, ${0.2 * vis})`);
    rg.addColorStop(0.78, `rgba(80, 205, 250, ${0.06 * vis})`);
    rg.addColorStop(1, "rgba(80, 205, 250, 0)");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(0, 0, rCloud, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // 2. Three silky inward-flowing mist clouds gliding smoothly into the mouth (zero lines!)
    for (let i = 0; i < 3; i++) {
      const prog = ((this.t * 2.0 + i / 3) % 1);
      const dist = range * (0.12 + (1 - prog * prog) * 0.7);
      const env = Math.sin(prog * Math.PI);
      const rx = range * (0.12 + (1 - prog) * 0.18);
      const ry = range * (0.08 + (1 - prog) * 0.24);
      ctx.save();
      ctx.translate(dist, 0);
      ctx.scale(1, ry / rx);
      const pg = ctx.createRadialGradient(0, 0, 0.5, 0, 0, rx);
      pg.addColorStop(0, `rgba(235, 255, 255, ${0.38 * env * vis})`);
      pg.addColorStop(0.55, `rgba(150, 240, 255, ${0.16 * env * vis})`);
      pg.addColorStop(1, "rgba(150, 240, 255, 0)");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(0, 0, rx, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  render() {
    const ctx = this.ctx;
    const scale = this.pixelMode ? 1 : this.zoom * this.dpr;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.imageSmoothingEnabled = !this.pixelMode;

    const vw = this.vw,
      vh = this.vh;
    let camLeft = this.cam.x - vw / 2;
    let camTop = this.cam.y - vh / 2;
    camLeft = vw >= WORLD_W ? (WORLD_W - vw) / 2 : clamp(camLeft, 0, WORLD_W - vw);
    camTop = clamp(camTop, -34, WORLD_H + 35 - vh);
    if (this.shake > 0) {
      camLeft += (Math.random() - 0.5) * this.shake;
      camTop += (Math.random() - 0.5) * this.shake;
    }
    if (this.pixelMode) {
      camLeft = Math.round(camLeft);
      camTop = Math.round(camTop);
    }
    this.camLeft = camLeft;
    this.camTop = camTop;
    const t = this.t;
    const oc = this.ocean;
    oc.time = t;

    oc.drawWater(ctx, camTop, vw, vh);
    oc.drawRays(ctx, camLeft, camTop, vw, vh, t);
    oc.drawLayers(ctx, camLeft, camTop, vw, vh);

    // Soft glowing floating plankton & bioluminescent deep-sea dust (fast cached glowOrb blits!)
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const deepAmt = clamp((camTop - 550) / 500, 0, 1);
    ctx.globalAlpha = 0.38 + deepAmt * 0.36;
    for (const m of this.motes) {
      const p = 0.6 + m.s * 0.5;
      const x = ((((m.x - camLeft * p + t * 3.5 * m.s) % 2000) + 2000) % 2000) - 100;
      const y = ((((m.y - camTop * p + Math.sin(t + m.x) * 6) % 1400) + 1400) % 1400) - 100;
      if (x < -10 || x > vw + 10 || y < -10 || y > vh + 10) continue;
      const rad = (m.s > 0.7 ? 2.6 : 1.6) * (1 + deepAmt * 0.45);
      ctx.drawImage(glowOrb(m.col, true), x - rad, y - rad, rad * 2, rad * 2);
    }
    ctx.restore();

    // Scenic Rock Overhangs, Stalactite Arches & Glowing Bioluminescent Crevices!
    oc.drawRockFormations(ctx, camLeft, camTop, vw, vh, t);
    oc.drawFloor(ctx, camLeft, camTop, vw, vh);
    oc.drawBackDecor(ctx, camLeft, camTop, vw, vh, t);

    for (const c of this.worldCoins) {
      const x = c.x - camLeft,
        y = c.y - camTop;
      if (x < -12 || x > vw + 12 || y < -12 || y > vh + 12) continue;
      const blink = c.t > 20 && Math.floor(c.t * 8) % 2 === 0;
      if (blink) continue;
      ctx.drawImage(coinSprite(Math.floor(c.t * 10 + c.x)), x - 5.5, y - 5.5, 11, 11);
    }

    const sorted = this.fish.filter((f) => !f.dead).sort((a, b) => (a.eatenBy ? 1 : 0) - (b.eatenBy ? 1 : 0) || a.r - b.r);

    // Soft ambient bioluminescent aura & forward water-beam in the Deep Cavern (like Images 2 & 3!)
    const p = this.player;
    if (p && !p.dead && !p.eatenBy && p.y > DEEP_START - 120) {
      const kDeep = clamp((p.y - (DEEP_START - 120)) / 320, 0, 1);
      const px = p.x - camLeft,
        py = p.y - camTop;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      // Soft ambient aqua halo around player
      const haloR = p.r * 5.2 + 45;
      const hg = ctx.createRadialGradient(px, py, 2, px, py, haloR);
      hg.addColorStop(0, `rgba(110, 235, 255, ${0.22 * kDeep})`);
      hg.addColorStop(0.5, `rgba(56, 189, 248, ${0.09 * kDeep})`);
      hg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(px, py, haloR, 0, Math.PI * 2);
      ctx.fill();

        // Soft zero-hard-edge elliptical forward bioluminescent mist beam (fades 100% smoothly on all sides!)
      const mx = p.mouthX() - camLeft,
        my = p.mouthY() - camTop;
      const beamRx = p.r * 3.4 + 42;
      const beamRy = beamRx * 0.42;
      const ang = Math.atan2(Math.sin(p.tilt), p.face * Math.cos(p.tilt));
      ctx.translate(mx, my);
      ctx.rotate(ang);
      ctx.translate(beamRx * 0.72, 0);
      ctx.scale(1, beamRy / beamRx);
      const bg = ctx.createRadialGradient(-beamRx * 0.35, 0, 2, 0, 0, beamRx);
      bg.addColorStop(0, `rgba(155, 248, 255, ${0.22 * kDeep})`);
      bg.addColorStop(0.5, `rgba(56, 215, 245, ${0.09 * kDeep})`);
      bg.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg;
      ctx.beginPath();
      ctx.arc(0, 0, beamRx, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Soft Suction Vortex Cones & Gossamer Ribbons
    for (const f of sorted) {
      if (f.sucking && !f.eatenBy) {
        this.drawSoftSuctionVortex(f, camLeft, camTop, vw, vh);
      }
    }

    // Draw Fish
    for (const f of sorted) this.drawFish(f, camLeft, camTop);

    // Ultra-Soft Feathered Particles!
    for (const pt of this.particles) {
      const x = pt.x - camLeft,
        y = pt.y - camTop;
      if (x < -35 || x > vw + 35 || y < -35 || y > vh + 35) continue;
      const k = clamp(pt.life / pt.max, 0, 1);

      if (pt.type === "chomp") {
        // Soft silky water-bite ripple crescent ("HAP!")
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.translate(x, y);
        ctx.scale(pt.dir || 1, 1);
        ctx.globalAlpha = k * 0.75;
        const r = pt.size * (0.65 + (1 - k) * 0.48);
        const closeAmt = (1 - k) * 0.45;
        ctx.strokeStyle = "rgba(224, 248, 255, 0.9)";
        ctx.lineWidth = 2.0 * k + 0.6;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.arc(0, -r * (0.42 - closeAmt), r, -0.5, 0.5);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, r * (0.42 - closeAmt), r, -0.5, 0.5);
        ctx.stroke();
        ctx.restore();
      } else if (pt.type === "bubble") {
        const r = Math.max(1.4, pt.size * 1.35);
        ctx.drawImage(getBubbleStamp(), x - r, y - r, r * 2, r * 2);
      } else if (pt.type === "bit") {
        const rad = pt.size * (0.8 + k * 0.8);
        ctx.globalAlpha = k;
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
        ctx.globalAlpha = 1;
      } else if (pt.type === "suck") {
        const rad = pt.size * 2.0;
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.drawImage(glowOrb("#7dd3fc", true), x - rad, y - rad, rad * 2, rad * 2);
        ctx.restore();
      } else if (pt.type === "streak") {
        const d = Math.hypot(pt.vx, pt.vy) || 1;
        const len = 6 + k * 10;
        const x2 = x + (pt.vx / d) * len,
          y2 = y + (pt.vy / d) * len;
        ctx.strokeStyle = `rgba(210, 252, 255, ${k * 0.5})`;
        ctx.lineCap = "round";
        ctx.lineWidth = 1.8 * k;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      } else if (pt.type === "ring") {
        const r = pt.size * (0.9 + (1 - k) * 1.5);
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.strokeStyle = pt.color;
        ctx.globalAlpha = k * 0.52;
        ctx.lineWidth = 2.2 * k;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      } else {
        const rad = 3.8 * k + 1.2;
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
        ctx.restore();
      }
    }

    for (const c of this.flyCoins) {
      ctx.drawImage(coinSprite(Math.floor(c.t * 14)), c.x - camLeft - 5.5, c.y - camTop - 5.5, 11, 11);
    }

    const fontFam = this.pixelMode ? "'Press Start 2P', monospace" : "'Fredoka', system-ui, sans-serif";
    ctx.font = this.pixelMode ? `7px ${fontFam}` : `700 9px ${fontFam}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const f of sorted) {
      if (f.eatenBy) continue;
      const x = f.x - camLeft,
        y = f.y - camTop - f.r * 1.15 - 8;
      if (x < -60 || x > vw + 60 || y < -25 || y > vh + 40) continue;
      if (f.kind !== "npc") {
        const col =
          f.kind === "player"
            ? "#ffffff"
            : p && !p.dead && f.r * EAT_RATIO > p.r
              ? "#ff9494"
              : p && !p.dead && f.r < p.r * EAT_RATIO
                ? "#a8ffbe"
                : "#e8f4ff";
        this.outlinedText(f.name, x, y, col, 2.4);
        if (f.id === this.leaderId) {
          this.drawCrown(x, y - 9);
        }
      }
      if (p && !p.dead && f !== p && f.r * EAT_RATIO > p.r && p.invuln <= 0) {
        const d = Math.hypot(f.x - p.x, f.y - p.y);
        const hunting = f.ai.target === p || (f.kind === "bot" && d < 160);
        if (d < 200 && hunting && Math.floor(t * 6) % 2 === 0) {
          this.outlinedText("!", x, y - (f.kind === "npc" ? 0 : 11), "#ff3b4e", 2.8);
        }
      }
    }

    for (const tx of this.texts) {
      const k = tx.life / tx.max;
      const pop = k > 0.8 ? (1 - k) * 5 : 1;
      ctx.globalAlpha = k < 0.3 ? k / 0.3 : 1;
      ctx.font = this.pixelMode ? `${tx.size - 1}px ${fontFam}` : `700 ${tx.size + 2}px ${fontFam}`;
      const yy = tx.y - camTop - (1 - pop) * 6;
      this.outlinedText(tx.text, tx.x - camLeft, yy, tx.color, 2.8);
      ctx.globalAlpha = 1;
    }

    // Layer 6 (1.24x): Foreground Parallax Coral, Crystal & Giant Kelp Silhouettes!
    oc.drawForegroundParallax(ctx, camLeft, camTop, vw, vh, t);
    oc.drawSurface(ctx, camLeft, camTop, vw, t);
  }

  drawCrown(x: number, y: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.moveTo(-4.5, 2.5);
    ctx.lineTo(-5.2, -2.5);
    ctx.lineTo(-2, 0.2);
    ctx.lineTo(0, -3.5);
    ctx.lineTo(2, 0.2);
    ctx.lineTo(5.2, -2.5);
    ctx.lineTo(4.5, 2.5);
    ctx.closePath();
    ctx.fillStyle = "#ffd43b";
    ctx.fill();
    ctx.strokeStyle = "#4a2500";
    ctx.lineWidth = 1.2;
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
  }

  outlinedText(s: string, x: number, y: number, col: string, strokeW = 2.5) {
    const ctx = this.ctx;
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;
    ctx.strokeStyle = "rgba(8, 22, 52, 0.88)";
    ctx.lineWidth = strokeW;
    ctx.strokeText(s, x, y);
    ctx.fillStyle = col;
    ctx.fillText(s, x, y);
  }

  drawFish(f: Fish, camLeft: number, camTop: number) {
    const ctx = this.ctx;
    let x = f.x,
      y = f.y,
      sc = 1;
    let rot = f.tilt;
    let face = f.face;
    const spd = Math.hypot(f.vx, f.vy);
    let sx = 1 - f.sq * 0.48 + Math.min(0.08, spd * 0.0005) + (f.boosting ? 0.12 : 0);
    let sy = 1 + f.sq * 0.72 - Math.min(0.05, spd * 0.00035) - (f.boosting ? 0.06 : 0);

    if (f.jaw > 0.35 && !f.eatenBy) {
      sy += (f.jaw - 0.35) * 0.1;
      sx -= (f.jaw - 0.35) * 0.04;
    }

    if (f.eatenBy) {
      const e = f.eatenBy;
      const k = f.eatT * f.eatT;
      x = f.eatFromX + (e.mouthX() - f.eatFromX) * k;
      y = f.eatFromY + (e.mouthY() - f.eatFromY) * k;
      sc = 1 - f.eatT * 0.82;
      sx *= 1 + f.eatT * 0.55;
      sy *= 1 - f.eatT * 0.32;
      face = e.x > f.eatFromX ? -1 : 1;
      rot = 0;
    }

    const scrX = x - camLeft,
      scrY = y - camTop;
    const reach = f.r * 2.6;
    if (scrX < -reach || scrX > this.vw + reach || scrY < -reach || scrY > this.vh + reach) return;

    // Soft bioluminescent lure light pool for Eddy in deep water!
    if (f.sp.lure && !f.eatenBy && f.y > DEEP_START - 200) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const lx = scrX + face * f.r * 1.15,
        ly = scrY - f.r * 0.95;
      const lg = ctx.createRadialGradient(lx, ly, 1, lx, ly, f.r * 2.6 + 18);
      lg.addColorStop(0, "rgba(220, 255, 90, 0.38)");
      lg.addColorStop(1, "rgba(180, 255, 60, 0)");
      ctx.fillStyle = lg;
      ctx.beginPath();
      ctx.arc(lx, ly, f.r * 2.6 + 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    if (f.sucked > 0 && !f.eatenBy) {
      x += (Math.random() - 0.5) * 1.3;
      sx *= 1.12;
      sy *= 0.9;
    }

    let jawState: JawState = 0;
    if (f.eatenBy) jawState = 3;
    else if (f.chompT > 0.04) jawState = -1;
    else if (f.jaw > 0.74) jawState = 3;
    else if (f.jaw > 0.42) jawState = 2;
    else if (f.jaw > 0.16) jawState = 1;

    let expr: EyeExpr = "normal";
    if (f.eatenBy || f.sucked > 0) expr = "panic";
    else if (f.chompT > 0.02) expr = "happy";

    const spr = fishSprite(f.sp, fishLen(f.r), jawState, f.tailPh, f.key, this.pixelMode, expr);

    // Soft dreamy shield aura when invulnerable (zero rings/lines, keeps fish body 100% solid & vibrant!)
    if (f.invuln > 0 && !f.eatenBy) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.35 + Math.sin(this.t * 8) * 0.15;
      const hr = f.r * 2.1;
      ctx.drawImage(glowOrb("rgba(190, 248, 255, 0.5)", false), x - camLeft - hr, y - camTop - hr, hr * 2, hr * 2);
      ctx.restore();
    }

    const flipX = f.eatenBy ? face : Math.abs(f.turnFlip) < 0.15 ? (f.turnFlip >= 0 ? 0.15 : -0.15) : f.turnFlip;
    ctx.save();
    ctx.globalAlpha = 1;
    ctx.translate(x - camLeft, y - camTop);
    ctx.scale(flipX, 1);
    if (Math.abs(rot) > 0.004) ctx.rotate(rot);
    ctx.scale(sx * sc, sy * sc);
    ctx.drawImage(spr.canvas, -spr.w / 2, -spr.h / 2, spr.w, spr.h);
    ctx.restore();

    if (f.kind === "player" && !f.eatenBy && f.r < 14) {
      const yy = y - camTop - f.r * 1.18 - 16 + Math.sin(this.t * 6) * 2;
      const xx = x - camLeft;
      ctx.save();
      ctx.fillStyle = "#ffe14a";
      ctx.strokeStyle = "rgba(8, 22, 52, 0.8)";
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(xx - 3.2, yy - 2);
      ctx.lineTo(xx + 3.2, yy - 2);
      ctx.lineTo(xx, yy + 2.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  }
}
