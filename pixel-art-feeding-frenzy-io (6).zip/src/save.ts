import type { Upgrades } from "./game/engine";

export interface SaveData {
  coins: number;
  upgrades: Upgrades;
  owned: string[];
  skin: string;
  name: string;
  best: number;
}

const KEY = "ffio-save-v1";

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const d = JSON.parse(raw);
      const owned: string[] = Array.isArray(d.owned) ? d.owned : ["andy", "andy_blue"];
      if (!owned.includes("andy")) owned.push("andy");
      if (!owned.includes("andy_blue")) owned.push("andy_blue");
      return {
        coins: d.coins ?? 0,
        upgrades: { suck: 0, speed: 0, size: 0, ...(d.upgrades || {}) },
        owned,
        skin: d.skin ?? "andy",
        name: d.name ?? "",
        best: d.best ?? 0,
      };
    }
  } catch {
    /* ignore */
  }
  return { coins: 0, upgrades: { suck: 0, speed: 0, size: 0 }, owned: ["andy", "andy_blue"], skin: "andy", name: "", best: 0 };
}

export function writeSave(d: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(d));
  } catch {
    /* ignore */
  }
}

export const UPGRADE_COSTS = [40, 100, 220, 450, 800];
export const MAX_UPGRADE = UPGRADE_COSTS.length;
