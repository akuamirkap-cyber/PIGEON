import V2Shell from './original/v2/V2Shell';

export default function App() {
  return <V2Shell />;
}
