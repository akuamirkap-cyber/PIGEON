// TAMPILAN KANTOR V1 UNTUK GAME V2 (numpang).
// Peta kantor V2 (OT_* tiles) dikonversi ke peta V1, lalu digambar dengan seni Menara Kantor V1:
// tema ruangan, jendela, lampu, hiasan dinding, perabot, langit kota, 6 suasana, hujan deras & kilat.
// Juga: efek hit V1 (kilatan kecil di depan, semburan darah & gelombang kejut di belakang tubuh).
import { T, STORY, THEMES, type OfficeMap, type ThemeId, themeOf } from './map';
import { buildBuilding, drawProp, drawConnector, drawGlassTile, drawWallDecor, drawDecorAt, DECOR_LOG, propHeight, storySpan, hh, type Lamp, type Win, type WallDecor } from './art';
import { ATMOS, ATMO_LIST, mixAtmo, buildSky2, drawSky2, css, Weather, type AtmoDef, type AtmoId, type Sky2 } from './atmo';
import { FX } from './fx';
import { pfontO, pline } from '../../v2/games/maxkungfu/game/pixel';
import { rnd } from '../../v2/games/maxkungfu/game/rng';
import type { SfxLike as Sfx } from './atmo';

/** kluster perabot per tema (dibaca kiri ke kanan, '.' = celah) dengan bobot */
const SETS: Record<ThemeId, [string, number][]> = {
  lobby: [['kk', 3], ['B', 3], ['p', 2], ['I.I', 2], ['Y', 2], ['v', 1], ['w', 1], ['C', 1], ['Z', 1], ['l', 1], ['RRR', 1]],
  cubicle: [['cdd', 4], ['ddc', 4], ['cddc', 3], ['p', 2], ['x', 1], ['w', 1], ['ff', 2], ['b', 1], ['Z', 1], ['dd', 2]],
  meeting: [['cLLLLc', 4], ['cLLLc', 3], ['i', 2], ['p', 2], ['f', 1], ['y', 1], ['B', 1], ['Z', 1]],
  pantry: [['KKKK', 4], ['KKK', 2], ['F', 2], ['v', 2], ['y', 2], ['cCc', 3], ['w', 1], ['Z', 1], ['p', 1]],
  server: [['rrr', 4], ['rr', 3], ['rrrr', 2], ['b', 1], ['bb', 1], ['O', 1], ['Z', 1]],
  exec: [['DDD', 3], ['mmm', 3], ['kkk', 2], ['A', 2], ['h', 2], ['s', 1], ['B', 2], ['J', 1], ['Y', 1], ['l', 2], ['RRRR', 2]],
  gym: [['TT', 3], ['TTT', 2], ['W', 2], ['WW', 2], ['jjj', 2], ['w', 1], ['p', 1], ['Z', 1]],
  archive: [['mmmm', 4], ['mmm', 3], ['ff', 2], ['bb', 2], ['l', 1], ['C', 1], ['J', 1]],
  lab: [['ddO', 3], ['A', 3], ['AA', 2], ['xr', 2], ['F', 1], ['O', 1], ['w', 1], ['Z', 1]],
  lounge: [['kkk', 3], ['QQ', 2], ['V', 2], ['VV', 1], ['i', 2], ['C', 2], ['B', 2], ['l', 2], ['RRR', 2], ['p', 1]],
  security: [['OO', 3], ['OOO', 2], ['jjj', 2], ['s', 1], ['c', 1], ['w', 1], ['Z', 1]],
  roof: [['aa', 3], ['a', 2], ['b', 2], ['bb', 1], ['p', 2], ['B', 2], ['C', 1]],
};

const OT_WALL = 1, OT_FLOOR = 2, OT_STAIRS = 3, OT_GLASS = 4, OT_ELEV = 5;
type RGB = [number, number, number];
const rgba = (hex: string, a: number) => { const n = parseInt(hex.slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
const R = (g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, c: string) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };

/** level V2 yang dibutuhkan (subset Level) */
export interface V2Level { w: number; h: number; officeTiles?: Uint8Array; officeMap?: { theme?: string; props?: { tx: number; ty: number; kind: string }[]; decor?: { tx: number; ty: number; kind: string; w?: number; h?: number; label?: string }[]; leftGates?: { tx: number; ty: number }[]; rightGates?: { tx: number; ty: number }[] } }
interface View { ix: number; iy: number; bw: number; bh: number }

const FLAVOR: Record<string, ThemeId[]> = {
  cyber_night: ['cubicle', 'server', 'lounge', 'meeting', 'security', 'lab'],
  sunset_corp: ['meeting', 'pantry', 'exec', 'cubicle', 'archive', 'lounge'],
  midnight_rain: ['security', 'archive', 'server', 'cubicle', 'meeting', 'lab'],
  dojo_tower: ['gym', 'archive', 'exec', 'pantry', 'meeting', 'lounge'],
};

export const ATMO_KEY_V2 = 'v2_office_atmo';
export const HITFX_KEY_V2 = 'v2_office_hitfx';
export function loadV2Atmo(): 'auto' | AtmoId { try { const m = localStorage.getItem(ATMO_KEY_V2); return m === 'auto' || ATMO_LIST.some((a) => a.id === m) ? (m as 'auto' | AtmoId) : 'malam'; } catch { return 'malam'; } }
export function loadV2HitFx(): 'v1' | 'v2' { try { return localStorage.getItem(HITFX_KEY_V2) === 'v2' ? 'v2' : 'v1'; } catch { return 'v1'; } }

export class V1OfficeLook {
  on = true;
  m1: OfficeMap | null = null;
  lamps: Lamp[] = []; windows: Win[] = []; decor: WallDecor[] = [];
  /** untuk KANTOR 3D: daftar furnitur & semua hiasan dinding */
  furn: { ch: string; c: number; r: number; nl: boolean; nr: boolean }[] = []; decorAll: WallDecor[] = [];
  private lvlRef: V2Level | null = null; glows: { x: number; yF: number; h: number; ch: string; story: number }[] = [];
  spans: [number, number][] = []; outdoorStory: boolean[] = []; stories = 0; mapW = 0; mapH = 0;
  gates: { x: number; yF: number; ch: 'S' | 'E' }[] = [];
  sky: Sky2 = buildSky2(); weather = new Weather(); fx = new FX();
  mode: 'auto' | AtmoId = loadV2Atmo(); target: AtmoId = 'malam'; from: AtmoDef = ATMOS.malam; to: AtmoDef = ATMOS.malam; k = 1; A: AtmoDef = ATMOS.malam;
  lightning = 0; lightningT = 5; thunderT = 0; time = 0;
  /** posisi pemain (dunia): diberi cahaya tepi lembut agar selalu terbaca di ruangan gelap */
  hero: { x: number; y: number } | null = null;
  private exits: { x: number; y: number }[] = [];
  private cams: { x: number; y: number }[] = [];
  private sprites = new Map<string, HTMLCanvasElement>();

  setMode(m: 'auto' | AtmoId) { this.mode = m; try { localStorage.setItem(ATMO_KEY_V2, m); } catch { /* */ } this.apply(0, true); }

  /** bangun kanvas gedung bergaya V1 dari level kantor V2 */
  build(l: V2Level): HTMLCanvasElement {
    this.lvlRef = l;
    const w = l.w, h = l.h, H1 = Math.ceil(h / STORY) * STORY;
    const ot = l.officeTiles ?? new Uint8Array(w * h);
    const at = (c: number, r: number) => (r < 0 || c < 0 || c >= w ? OT_WALL : r >= h ? OT_WALL : ot[r * w + c]);
    const rows: string[][] = Array.from({ length: H1 }, (_, r) => Array.from({ length: w }, (_, c) => {
      const v = at(c, r);
      return v === OT_WALL || v === OT_FLOOR ? '#' : v === OT_GLASS ? 'G' : v === OT_ELEV ? 'E' : '.';
    }));
    // pintu musuh V2 (gerbang kiri / kanan) = pintu darurat V1
    const gateTiles = [...(l.officeMap?.leftGates ?? []), ...(l.officeMap?.rightGates ?? [])];
    for (const gt of gateTiles) { const r = gt.ty - 1; if (r >= 0 && r < H1 && gt.tx >= 0 && gt.tx < w && rows[r][gt.tx] === '.') rows[r][gt.tx] = 'S'; }
    // tema per lantai
    const n = H1 / STORY, flavor = FLAVOR[l.officeMap?.theme ?? 'cyber_night'] ?? FLAVOR.cyber_night;
    const roomStory: boolean[] = [];
    for (let s = 0; s < n; s++) { let air = 0; for (let r = s * STORY; r < s * STORY + STORY - 1; r++) for (let c = 0; c < w; c++) if (rows[r][c] !== '#') air++; roomStory.push(air > w * 0.5); }
    let lowest = -1; for (let s = n - 1; s >= 0; s--) if (roomStory[s]) { lowest = s; break; }
    const themes: string[] = []; let k = 0;
    for (let s = 0; s < n; s++) {
      if (!roomStory[s]) { themes.push('cubicle'); continue; }
      const openTop = s === 0 || !rows[s * STORY - 1].some((ch) => ch === '#');
      if (openTop) themes.push('roof');
      else if (s === lowest) themes.push('lobby');
      else themes.push(flavor[(k++) % flavor.length]);
    }
    const m1: OfficeMap = { name: 'V2', w, h: H1, rows: rows.map((r) => r.join('')), roof: false, themes };
    // perabot V1 otomatis (dekor statis) di lantai kosong, menghindari tangga, pintu, lift & props interaktif V2
    const v2props = (l.officeMap?.props ?? []).map((p) => ({ c: p.tx, r: p.ty - 1 }));
    const glows: V1OfficeLook['glows'] = [];
    const furn: { ch: string; c: number; r: number; nl: boolean; nr: boolean }[] = [];
    for (let s = 0; s < n; s++) {
      if (!roomStory[s]) continue;
      const th = themes[s] as ThemeId, fr = s * STORY + STORY - 2, set = SETS[th] ?? SETS.cubicle;
      const free = (c: number) => {
        if (c < 3 || c >= w - 3 || rows[fr][c] !== '.' || rows[fr + 1]?.[c] !== '#') return false;
        for (let d = -1; d <= 1; d++) { for (let r = s * STORY; r <= fr + 1; r++) { const v = at(c + d, r); if (v === OT_STAIRS || v === OT_ELEV) return false; } const ch = rows[fr][c + d]; if (ch === 'S' || ch === 'E') return false; }
        return !v2props.some((p) => p.r === fr && Math.abs(p.c - c) <= 1);
      };
      let c = 4;
      while (c < w - 4) {
        if (!free(c)) { c++; continue; }
        let tot = 0; for (const [, wt] of set) tot += wt;
        let x = hh(c, s, 911) * tot, pick = set[0][0];
        for (const [kk, wt] of set) { x -= wt; if (x <= 0) { pick = kk; break; } }
        let ok = true; for (let i = 0; i < pick.length; i++) if (!free(c + i)) { ok = false; break; }
        if (!ok) { c++; continue; }
        for (let i = 0; i < pick.length; i++) if (pick[i] !== '.') furn.push({ ch: pick[i], c: c + i, r: fr, nl: pick[i - 1] === pick[i], nr: pick[i + 1] === pick[i] });
        c += pick.length + 2 + Math.floor(hh(c, s, 913) * 3);
      }
    }
    const bb = buildBuilding(m1);
    const g = bb.cv.getContext('2d')!;
    // tangga V2 (sumur tangga) bergaya V1
    this.drawStairs(g, at, w, h, H1);
    this.drawBlueprintDetails(g, l);
    this.polish(g, m1, bb.lamps, bb.windows);
    for (const d of l.officeMap?.decor ?? []) if (d.kind === 'chandelier') {
      const story = Math.floor(d.ty / STORY);
      bb.lamps.push({ x: (d.tx + (d.w ?? 3) / 2) * T, y: d.ty * T + 10, floorY: (story + 1) * STORY * T - T, story, color: '#ffd5a0' });
    }
    for (const f of furn) {
      const s = Math.floor(f.r / STORY);
      drawProp(g, f.ch, f.c * T, (f.r + 1) * T, { broken: false, t: 0, seed: hh(f.c, f.r, 5), shake: 0, nl: f.nl, nr: f.nr, th: themeOf(m1, s) });
      if ('liVAOvy'.includes(f.ch)) glows.push({ x: f.c * T + 8, yF: (f.r + 1) * T, h: propHeight(f.ch), ch: f.ch, story: s });
    }
    this.gates = [];
    for (let r = 0; r < H1; r++) for (let c = 0; c < w; c++) { const ch = rows[r][c]; if (ch === 'S' || ch === 'E') this.gates.push({ x: c * T, yF: (r + 1) * T, ch }); }
    this.m1 = m1; this.lamps = bb.lamps; this.windows = bb.windows; this.decor = bb.decor; this.glows = glows;
    this.furn = furn; this.decorAll = [...DECOR_LOG];
    this.stories = n; this.mapW = w; this.mapH = h;
    this.spans = Array.from({ length: n }, (_, s) => storySpan(m1, s));
    this.outdoorStory = themes.map((t) => t === 'roof');
    this.sprites.clear();
    this.propCache.clear();
    this.fx.solid = (x, y) => { const c = Math.floor(x / T), r = Math.floor(y / T); const v = at(c, r); return v === OT_WALL || v === OT_FLOOR || v === OT_GLASS; };
    this.apply(0, true);
    return bb.cv;
  }

  /** Sentuhan desain di atas kanvas gedung: bayangan sudut (AO), lis & lantai mengilap, pipa plafon, kaca jendela, tanda EXIT, CCTV. */
  private polish(g: CanvasRenderingContext2D, m: OfficeMap, lamps: Lamp[], wins: Win[]) {
    const SP = STORY * T, n = Math.floor(m.h / STORY);
    this.exits = []; this.cams = [];
    for (let s = 0; s < n; s++) {
      if ((m.themes ?? [])[s] === 'roof') continue;
      const [ca, cb] = storySpan(m, s);
      const x0 = ca * T, x1 = (cb + 1) * T, w = x1 - x0, y0 = s * SP, yF = y0 + SP - T;
      if (w < T * 4) continue;
      // ---- AO: plafon & sudut dinding menggelap, lantai tertambat ----
      let gr = g.createLinearGradient(0, y0, 0, y0 + 18);
      gr.addColorStop(0, 'rgba(4,6,16,0.44)'); gr.addColorStop(1, 'rgba(4,6,16,0)');
      g.fillStyle = gr; g.fillRect(x0, y0, w, 18);
      gr = g.createLinearGradient(0, yF - 12, 0, yF);
      gr.addColorStop(0, 'rgba(4,6,16,0)'); gr.addColorStop(1, 'rgba(4,6,16,0.26)');
      g.fillStyle = gr; g.fillRect(x0, yF - 12, w, 12);
      for (const [gx, dir] of [[x0, 1], [x1, -1]] as const) {
        gr = g.createLinearGradient(gx, 0, gx + dir * 20, 0);
        gr.addColorStop(0, 'rgba(4,6,16,0.38)'); gr.addColorStop(1, 'rgba(4,6,16,0)');
        g.fillStyle = gr; g.fillRect(dir > 0 ? gx : gx - 20, y0, 20, yF - y0);
      }
      // ---- lantai mengilap, sambungan ubin, lis lantai ----
      const slab = m.rows[(s + 1) * STORY - 1] ?? '', low = m.rows[(s + 1) * STORY - 2] ?? '', top = m.rows[s * STORY] ?? '';
      for (let c = ca; c <= cb; c++) {
        const x = c * T;
        if (slab[c] === '#') {
          g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(x, yF, T, 1);
          g.fillStyle = 'rgba(0,0,0,0.24)'; g.fillRect(x + ((c * 7 + s * 3) % 2 ? 4 : 11), yF + 1, 1, 2);
          if (low[c] === '.') { g.fillStyle = 'rgba(6,8,18,0.46)'; g.fillRect(x, yF - 2, T, 2); g.fillStyle = 'rgba(255,255,255,0.07)'; g.fillRect(x, yF - 3, T, 1); }
        }
        // ---- pipa / kabel tray plafon: putus di armatur lampu ----
        if (top[c] !== '.' || lamps.some((l) => l.story === s && Math.abs(l.x - (x + 8)) < 15)) continue;
        const py = y0 + 3;
        g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(x, py + 2, T, 1);
        g.fillStyle = '#39415a'; g.fillRect(x, py, T, 2);
        g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(x, py, T, 1);
        if (c % 3 === 0) { g.fillStyle = '#1e2436'; g.fillRect(x + 6, y0, 2, py - y0); g.fillRect(x + 5, py - 1, 4, 4); g.fillStyle = 'rgba(255,255,255,0.2)'; g.fillRect(x + 5, py - 1, 4, 1); }
      }
      // ---- CCTV di ujung ruangan (lampu merahnya berkedip di drawLights) ----
      let cc = -1;
      for (let c = cb; c >= cb - 8 && c > ca + 2; c--) {
        if (top[c] === '.' && top[c - 1] === '.' && low[c] !== 'S' && !lamps.some((l) => l.story === s && Math.abs(l.x - (c * T + 8)) < 15)) { cc = c; break; }
      }
      if (cc >= 0) {
        const cx = cc * T + 5, cy = y0 + 6;
        g.fillStyle = '#10131f'; g.fillRect(cx + 3, y0 + 5, 1, 2); g.fillRect(cx - 1, cy + 1, 8, 5);
        g.fillStyle = '#4a546e'; g.fillRect(cx, cy + 2, 6, 3);
        g.fillStyle = '#9aa6c4'; g.fillRect(cx, cy + 2, 6, 1);
        g.fillStyle = '#05070c'; g.fillRect(cx - 1, cy + 3, 2, 2);
        this.cams.push({ x: cx + 5, y: cy + 4 });
      }
    }
    // ---- kaca jendela: pantulan miring, kilau bingkai, ambang ----
    for (const w of wins) {
      g.save(); g.beginPath(); g.rect(w.x, w.y, w.w, w.h); g.clip();
      g.fillStyle = 'rgba(214,232,255,0.075)';
      for (let k = 0; k < 2; k++) {
        const sx = w.x + w.w * (0.12 + k * 0.44), bw = k ? 3 : 6;
        g.beginPath(); g.moveTo(sx, w.y + w.h); g.lineTo(sx + w.h * 0.5, w.y); g.lineTo(sx + w.h * 0.5 + bw, w.y); g.lineTo(sx + bw, w.y + w.h); g.closePath(); g.fill();
      }
      g.restore();
      g.fillStyle = 'rgba(255,255,255,0.12)'; g.fillRect(w.x, w.y, w.w, 1);
      g.fillStyle = 'rgba(0,0,0,0.4)'; g.fillRect(w.x - 1, w.y + w.h, w.w + 2, 1);
      g.fillStyle = '#5a6480'; g.fillRect(w.x - 1, w.y + w.h + 1, w.w + 2, 1);
    }
    // ---- tanda EXIT hijau di atas setiap pintu darurat ----
    for (let r = 0; r < m.h; r++) for (let c = 0; c < m.w; c++) {
      if (m.rows[r][c] !== 'S') continue;
      const s = Math.floor(r / STORY), sx = c * T + 1, sy = s * STORY * T + 9;
      g.fillStyle = '#04100a'; g.fillRect(sx - 1, sy - 1, 15, 9); g.fillRect(sx + 6, sy - 4, 1, 3);
      g.fillStyle = '#12a05e'; g.fillRect(sx, sy, 13, 7);
      g.fillStyle = '#5dffa6'; g.fillRect(sx, sy, 13, 1);
      g.fillStyle = '#eafff3';
      g.fillRect(sx + 2, sy + 3, 6, 1); g.fillRect(sx + 6, sy + 2, 1, 3); g.fillRect(sx + 7, sy + 3, 2, 1); // panah
      g.fillRect(sx + 10, sy + 1, 1, 5); g.fillRect(sx + 11, sy + 1, 1, 1); g.fillRect(sx + 11, sy + 5, 1, 1); // kusen pintu
      this.exits.push({ x: sx + 6, y: sy + 3 });
    }
  }
  /** pantulan lampu di muka lantai yang mengilap */
  private reflSprite(c: string) {
    const key = `r${c}`;
    let cv = this.sprites.get(key);
    if (!cv) {
      cv = document.createElement('canvas'); cv.width = 28; cv.height = 9;
      const g = cv.getContext('2d')!;
      g.save(); g.scale(1, 9 / 14);
      const rg = g.createRadialGradient(14, 0, 0, 14, 0, 14); rg.addColorStop(0, rgba(c, 0.95)); rg.addColorStop(0.5, rgba(c, 0.35)); rg.addColorStop(1, rgba(c, 0));
      g.fillStyle = rg; g.fillRect(0, 0, 28, 14); g.restore();
      this.sprites.set(key, cv);
    }
    return cv;
  }
  /** Sentuhan akhir sinematik di atas dunia (di bawah HUD): vinyet elips yang menajamkan fokus ke tengah layar.
   *  Diisi langsung dengan gradien (bukan gambar ber-skala + multiply) supaya tidak muncul garis sambungan ubin raster. */
  drawGrade(g: CanvasRenderingContext2D, v: View) {
    const A = this.A, dk = Math.max(A.night, A.rain * 0.8, 0.3);
    const cx = v.ix + v.bw / 2, cy = v.iy + v.bh / 2, R = v.bw * 0.62;
    g.save();
    g.translate(cx, cy); g.scale(1, v.bh / v.bw);
    const gr = g.createRadialGradient(0, 0, R * 0.42, 0, 0, R);
    gr.addColorStop(0, 'rgba(5,7,20,0)');
    gr.addColorStop(0.55, `rgba(5,7,20,${0.1 + 0.1 * dk})`);
    gr.addColorStop(1, `rgba(5,7,20,${0.3 + 0.26 * dk})`);
    g.fillStyle = gr;
    g.fillRect(-v.bw / 2 - 2, -v.bw / 2 - 2, v.bw + 4, v.bw + 4);
    g.restore();
  }

  /** The actual V2 blueprint contributes its reception, signage and server equipment to V1 art. */
  private drawBlueprintDetails(g: CanvasRenderingContext2D, l: V2Level) {
    for (const d of l.officeMap?.decor ?? []) {
      const x = d.tx * T, y = d.ty * T, width = (d.w ?? 1) * T;
      if (d.kind === 'reception') {
        R(g, x + 2, y - 25, width - 4, 20, '#0c1422');
        R(g, x + 2, y - 25, width - 4, 1, '#c8a775');
        R(g, x + 2, y - 6, width - 4, 1, '#c8a775');
        pfontO(g, 'STIKFICK', x + width / 2, y - 20, '#f4e4c9', '#090d17', 1, 'center');
        for (const mx of [x + 10, x + width - 21]) {
          R(g, mx, y - 5, 11, 7, '#0c111c'); R(g, mx + 1, y - 4, 9, 5, '#559bb4');
          R(g, mx + 3, y - 2, 5, 1, '#c1eaff');
        }
        R(g, x, y + 2, width, 3, '#bcb1a0'); R(g, x + 1, y + 5, width - 2, 11, '#17202c');
        R(g, x + 6, y + 8, width - 12, 1, '#bd9565');
      } else if (d.kind === 'banner' && d.label) {
        R(g, x + 2, y + 1, width - 4, 10, '#101c2a');
        R(g, x + 2, y + 1, width - 4, 1, '#c49a62');
        pfontO(g, d.label, x + width / 2, y + 3, '#b8dce6', '#08101b', 1, 'center');
      } else if (d.kind === 'security_gate') {
        R(g, x + 1, y - 11, 2, 27, '#657581'); R(g, x + 13, y - 11, 2, 27, '#344a59');
        R(g, x + 1, y - 12, 14, 2, '#9caeb7'); R(g, x + 5, y - 11, 6, 1, '#68e9de');
      } else if (d.kind === 'server') {
        R(g, x + 2, y - 11, 12, 27, '#101621'); R(g, x + 3, y - 10, 10, 25, '#233042');
        for (let k = 0; k < 5; k++) {
          R(g, x + 4, y - 8 + k * 5, 8, 3, '#0b111a');
          R(g, x + 5, y - 7 + k * 5, 1, 1, k % 2 ? '#58eccb' : '#89c6ff');
        }
      }
    }
  }

  private drawStairs(g: CanvasRenderingContext2D, at: (c: number, r: number) => number, w: number, h: number, H1: number) {
    void H1;
    const seen = new Set<number>();
    for (let r = 0; r < h; r++) for (let c = 0; c < w; c++) {
      if (at(c, r) !== OT_STAIRS || seen.has(r * w + c)) continue;
      // satu sumur tangga = blok persegi kolom berurutan
      let c1 = c; while (at(c1 + 1, r) === OT_STAIRS) c1++;
      let r1 = r; while (at(c, r1 + 1) === OT_STAIRS) r1++;
      for (let rr = r; rr <= r1; rr++) for (let cc = c; cc <= c1; cc++) if (at(cc, rr) === OT_STAIRS) seen.add(rr * w + cc);
      const x0 = c * T, x1 = (c1 + 1) * T, yT = r * T, yB = (r1 + 1) * T;
      g.fillStyle = 'rgba(8,10,16,0.55)'; g.fillRect(x0, yT, x1 - x0, yB - yT);
      R(g, x0, yT, 1, yB - yT, '#5d6375'); R(g, x1 - 1, yT, 1, yB - yT, '#2b2e38');
      // anak tangga zig-zag (satu putaran per 2 lantai tegak)
      const flights = Math.max(1, Math.round((yB - yT) / (T * 2.5)));
      const fh = (yB - yT) / flights;
      for (let f = 0; f < flights; f++) {
        const fy0 = yB - f * fh, fy1 = fy0 - fh, ltr = f % 2 === 0;
        const steps = Math.max(4, Math.round(fh / 4));
        for (let k = 0; k < steps; k++) {
          const u = k / steps, sx = ltr ? x0 + (x1 - x0) * u : x1 - (x1 - x0) * (u + 1 / steps), sy = fy0 - fh * (k + 1) / steps;
          R(g, sx, sy, (x1 - x0) / steps + 1, 3, '#7d8494'); R(g, sx, sy, (x1 - x0) / steps + 1, 1, '#b8c0cf'); R(g, sx, sy + 3, (x1 - x0) / steps + 1, 1, '#3c414e');
        }
        g.strokeStyle = '#aab3c2'; g.lineWidth = 1; g.beginPath();
        g.moveTo(ltr ? x0 : x1, fy0 - 9); g.lineTo(ltr ? x1 : x0, fy1 - 9); g.stroke();
        for (let k = 0; k <= 3; k++) { const u = k / 3, px = ltr ? x0 + (x1 - x0) * u : x1 - (x1 - x0) * u, py = fy0 - fh * u; R(g, px, py - 9, 1, 9, '#8a93a2'); }
      }
      R(g, x0 + 3, yT + 2, 10, 5, '#0c3a1e'); R(g, x0 + 4, yT + 3, 8, 3, '#2bd96b');
    }
  }

  // ---------------------------------------------------------------- suasana
  private autoId(wave: number): AtmoId {
    const order: AtmoId[] = ['pagi', 'siang', 'sore', 'malam', 'subuh'];
    const w = Math.max(1, wave);
    if (w > 2 && hh(w, 7, 3) < 0.18) return 'hujan';
    return order[Math.floor((w - 1) / 2) % order.length];
  }
  apply(wave: number, instant = false) {
    const id = this.mode === 'auto' ? this.autoId(wave) : this.mode;
    if (id === this.target && !instant) return;
    this.from = this.A; this.to = ATMOS[id]; this.target = id; this.k = instant ? 1 : 0;
    if (instant) this.A = this.to;
  }
  update(raw: number, sfx: Sfx, active: boolean, wave: number) {
    this.time += raw;
    this.apply(wave);
    if (this.k < 1) { this.k = Math.min(1, this.k + raw / 3.5); const k = this.k; this.A = mixAtmo(this.from, this.to, k * k * (3 - 2 * k)); }
    if (this.A.lightning > 0.4) { this.lightningT -= raw; if (this.lightningT <= 0) { this.lightning = 0.75; this.lightningT = 3.5 + Math.random() * 5.5; this.thunderT = 0.25 + Math.random(); } }
    if (this.thunderT > 0) { this.thunderT -= raw; if (this.thunderT <= 0) this.weather.thunder(sfx, 0.55 + Math.random() * 0.45); }
    this.lightning = Math.max(0, this.lightning - raw * 2.6);
    this.weather.update(sfx, this.A.rain, active);
    this.fx.update(raw);
  }
  stop() { this.weather.stop(); }

  // ---------------------------------------------------------------- gambar
  drawSky(g: CanvasRenderingContext2D, sw: number, sh: number, camL: number, camT: number) {
    drawSky2(g, this.sky, this.A, sw, sh, camL, camT, this.mapH * T, this.time, this.lightning);
    if (this.A.gradeA > 0.01) { g.globalCompositeOperation = 'multiply'; g.fillStyle = css(this.tint()); g.fillRect(0, 0, sw, sh); g.globalCompositeOperation = 'source-over'; }
  }
  private tint(): RGB { const gg = this.A.grade, k = this.A.gradeA; return [255 + (gg[0] - 255) * k, 255 + (gg[1] - 255) * k, 255 + (gg[2] - 255) * k]; }
  /** kaca (dari tile V2 terkini), pintu darurat & lift, hiasan dinding beranimasi */
  drawLive(g: CanvasRenderingContext2D, l: V2Level, v: View) {
    const ot = l.officeTiles; if (!ot) return;
    const c0 = Math.max(0, Math.floor(v.ix / T) - 1), c1 = Math.min(l.w - 1, Math.ceil((v.ix + v.bw) / T) + 1);
    const r0 = Math.max(0, Math.floor(v.iy / T) - 1), r1 = Math.min(l.h - 1, Math.ceil((v.iy + v.bh) / T) + 1);
    for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) if (ot[r * l.w + c] === OT_GLASS) drawGlassTile(g, c * T, r * T, true, ot[(r - 1) * l.w + c] !== OT_GLASS, ot[(r + 1) * l.w + c] !== OT_GLASS, this.time);
    for (const gt of this.gates) if (gt.x > v.ix - 24 && gt.x < v.ix + v.bw + 8) drawConnector(g, gt.ch, gt.x, gt.yF, 0, this.time);
    for (const d of this.decor) if (d.x > v.ix - 30 && d.x < v.ix + v.bw + 10 && d.yF > v.iy && d.y0 < v.iy + v.bh) drawWallDecor(g, d, this.time);
  }
  /** interior digelapkan / dihangatkan sesuai suasana (dipanggil sebelum petarung digambar) */
  drawAmbient(g: CanvasRenderingContext2D, v: View) {
    const A = this.A, gt = this.tint();
    const ck = 1 - 0.17 * Math.max(A.night, A.rain * 0.7); // malam lebih kontras: bayangan lebih dalam & dingin, lampu yang mengangkatnya
    const amb: RGB = [A.ambient[0] * gt[0] / 255 * ck, A.ambient[1] * gt[1] / 255 * ck, A.ambient[2] * gt[2] / 255 * (ck + (1 - ck) * 0.5)];
    const dark = amb[0] < 250 || amb[1] < 250 || amb[2] < 250;
    const SP = STORY * T;
    for (let s = 0; s < this.stories; s++) {
      if (this.outdoorStory[s]) continue;
      const y0 = s * SP, y1 = y0 + SP - T + 6;
      if (y1 < v.iy || y0 > v.iy + v.bh) continue;
      const [ca, cb] = this.spans[s];
      const x0 = ca * T, w = (cb + 1) * T - x0;
      if (dark) { g.globalCompositeOperation = 'multiply'; g.fillStyle = css(amb); g.fillRect(x0, y0, w, y1 - y0); }
      if (A.lift > 0.01) { g.globalCompositeOperation = 'screen'; g.fillStyle = `rgba(255,248,236,${A.lift})`; g.fillRect(x0, y0, w, y1 - y0); }
    }
    g.globalCompositeOperation = 'source-over';
    // Cool window bounce sits behind the fighters; warm ceiling pools are drawn above them later.
    g.save(); g.globalCompositeOperation = 'lighter';
    for (const w of this.windows) {
      if (w.x + w.w < v.ix || w.x > v.ix + v.bw || w.y > v.iy + v.bh || w.y + w.h < v.iy) continue;
      const mid = w.x + w.w / 2, floorY = (w.story + 1) * STORY * T - T;
      const cool = A.night > 0.4 || A.rain > 0.2;
      g.globalAlpha = (cool ? 0.17 : 0.1) * (0.75 + 0.25 * Math.sin(this.time * 1.4 + w.x));
      g.drawImage(this.glowSprite(cool ? '#76bcff' : '#ffd3a0', 48), mid - 48, floorY - 16, 96, 26);
      g.globalAlpha = cool ? 0.12 : 0.07;
      g.drawImage(this.glowSprite(cool ? '#5fa8eb' : '#ffca96', 32), mid - 32, w.y + w.h * 0.3 - 32, 64, 64);
    }
    // Dinding di belakang tiap lampu ikut tersiram cahaya (di belakang para petarung), sehingga ruangan punya terang-gelap.
    if (A.lamp > 0.03) for (const l of this.lamps) {
      if (l.x < v.ix - 60 || l.x > v.ix + v.bw + 60 || l.floorY < v.iy - 10 || l.y > v.iy + v.bh + 10) continue;
      const lh = l.floorY - l.y, sp = this.glowSprite(l.color, 44);
      g.globalAlpha = Math.min(0.42, A.lamp * 0.27);
      g.drawImage(sp, 0, sp.height * 0.28, sp.width, sp.height * 0.72, l.x - 54, l.y, 108, lh + 4);
    }
    g.restore();
  }
  private glowSprite(c: string, r: number) {
    const Rr = Math.max(4, Math.round(r / 4) * 4), key = `g${c}${Rr}`;
    let cv = this.sprites.get(key);
    if (!cv) { cv = document.createElement('canvas'); cv.width = cv.height = Rr * 2; const g = cv.getContext('2d')!, gr = g.createRadialGradient(Rr, Rr, 0, Rr, Rr, Rr); gr.addColorStop(0, rgba(c, 1)); gr.addColorStop(0.45, rgba(c, 0.4)); gr.addColorStop(1, rgba(c, 0)); g.fillStyle = gr; g.fillRect(0, 0, Rr * 2, Rr * 2); this.sprites.set(key, cv); }
    return cv;
  }
  private lampSprite(c: string, hgt: number) {
    const key = `l${c}${hgt}`;
    let cv = this.sprites.get(key);
    if (!cv) {
      cv = document.createElement('canvas'); cv.width = 64; cv.height = hgt + 4;
      const g = cv.getContext('2d')!;
      const cg = g.createLinearGradient(0, 2, 0, hgt); cg.addColorStop(0, rgba(c, 0.22)); cg.addColorStop(0.42, rgba(c, 0.08)); cg.addColorStop(1, rgba(c, 0));
      g.fillStyle = cg; g.beginPath(); g.moveTo(26, 3); g.lineTo(38, 3); g.lineTo(64, hgt); g.lineTo(0, hgt); g.closePath(); g.fill();
      // inti kerucut yang lebih panas: memberi kesan volumetrik
      const ig = g.createLinearGradient(0, 2, 0, hgt * 0.82); ig.addColorStop(0, rgba(c, 0.2)); ig.addColorStop(1, rgba(c, 0));
      g.fillStyle = ig; g.beginPath(); g.moveTo(28, 3); g.lineTo(36, 3); g.lineTo(47, hgt * 0.82); g.lineTo(17, hgt * 0.82); g.closePath(); g.fill();
      g.save(); g.translate(0, hgt + 1); g.scale(1, 0.12); const rg = g.createRadialGradient(32, 0, 1, 32, 0, 32); rg.addColorStop(0, rgba(c, 0.26)); rg.addColorStop(1, rgba(c, 0)); g.fillStyle = rg; g.fillRect(0, -32, 64, 64); g.restore();
      g.fillStyle = rgba(c, 0.54); g.fillRect(26, 0, 12, 3);
      this.sprites.set(key, cv);
    }
    return cv;
  }
  /** lampu plafon, sinar matahari menembus jendela, cahaya perabot */
  drawLights(g: CanvasRenderingContext2D, v: View) {
    const A = this.A;
    const vis = (x: number, y: number, m = 40) => x > v.ix - m && x < v.ix + v.bw + m && y > v.iy - m - 60 && y < v.iy + v.bh + m;
    g.save(); g.globalCompositeOperation = 'lighter';
    if (A.lamp > 0.03) for (const l of this.lamps) {
      if (!vis(l.x, l.y)) continue;
      let k = A.lamp;
      if (A.rain > 0.5 && hh(Math.round(l.x), l.story, 3) > 0.8) k *= 0.5 + 0.5 * Math.abs(Math.sin(this.time * 23 + l.x));
      if (this.lightning > 0.3 && hh(Math.round(l.x), l.story, 5) > 0.6) k *= 0.3;
      const lh = Math.round(l.floorY - l.y);
      g.globalAlpha = Math.min(1, k); g.drawImage(this.lampSprite(l.color, lh), l.x - 32, l.y); g.globalAlpha = 1;
      // kolam cahaya di lantai + pantulan di muka lantai yang mengilap
      g.globalAlpha = Math.min(0.42, k * 0.31);
      g.drawImage(this.glowSprite(l.color, 38), l.x - 42, l.floorY - 13, 84, 21);
      g.globalAlpha = Math.min(0.36, k * 0.27);
      g.drawImage(this.reflSprite(l.color), l.x - 14, l.floorY + 1, 28, 9);
      // halo armatur + kilau lensa
      g.globalAlpha = Math.min(0.5, k * 0.36);
      g.drawImage(this.glowSprite(l.color, 16), l.x - 16, l.y - 12, 32, 32);
      g.globalAlpha = Math.min(0.72, k * 0.5);
      g.fillStyle = l.color; g.fillRect(Math.round(l.x - 5), Math.round(l.y + 1), 10, 1);
      g.globalAlpha = Math.min(0.3, k * 0.2);
      g.fillRect(Math.round(l.x - 13), Math.round(l.y + 1), 26, 1);
      // debu melayang di dalam kerucut cahaya
      for (let i = 0; i < 4; i++) {
        const u = (hh(Math.round(l.x), i, 31) + this.time * (0.02 + 0.015 * hh(i, l.story, 7))) % 1;
        const mx = l.x + (hh(i, Math.round(l.x), 17) - 0.5) * 2 * (5 + u * 24) + Math.sin(this.time * 0.7 + i * 2.1 + l.x) * 2;
        g.globalAlpha = Math.min(1, k) * 0.55 * Math.sin(u * Math.PI);
        g.fillRect(Math.round(mx), Math.round(l.y + 4 + u * (lh - 8)), 1, 1);
      }
      g.globalAlpha = 1;
    }
    // Night-time glass remains readable even when the daytime sun-beam parameter is zero.
    if (A.night > 0.25 || A.rain > 0.25) for (const w of this.windows) {
      if (!vis(w.x + w.w / 2, w.y)) continue;
      const k = Math.max(A.night, A.rain) * 0.13;
      g.globalAlpha = k;
      g.drawImage(this.glowSprite('#80c9ef', 32), w.x + w.w / 2 - 32, w.y + w.h * 0.4 - 32, 64, 64);
      g.globalAlpha = 1;
    }
    // Malam: berkas cahaya bulan / kota yang miring menembus jendela (saat tak ada sinar matahari)
    const moon = A.beam > 0.03 ? 0 : Math.max(0, Math.max(A.night, A.rain * 0.8) - 0.3);
    if (moon > 0.05) for (const w of this.windows) {
      if (!vis(w.x + w.w / 2, w.y, 90)) continue;
      const floorY = w.story * STORY * T + STORY * T - T, sh = (floorY - w.y) * 0.5;
      const a = 0.085 * moon * (0.85 + 0.15 * Math.sin(this.time * 0.6 + w.x * 0.05));
      g.fillStyle = `rgba(150,190,255,${a})`;
      g.beginPath(); g.moveTo(w.x, w.y); g.lineTo(w.x + w.w, w.y); g.lineTo(w.x + w.w + sh, floorY); g.lineTo(w.x + sh, floorY); g.closePath(); g.fill();
      g.fillStyle = `rgba(176,208,255,${a * 1.7})`; g.fillRect(Math.round(w.x + sh), floorY - 1, w.w, 2);
    }
    if (A.beam > 0.03) for (const w of this.windows) {
      if (!vis(w.x + w.w / 2, w.y)) continue;
      const floorY = w.story * STORY * T + STORY * T - T, sh = (floorY - w.y) * A.beamDir * 0.7;
      g.fillStyle = css(A.beamColor, 0.07 * A.beam); g.beginPath(); g.moveTo(w.x, w.y); g.lineTo(w.x + w.w, w.y); g.lineTo(w.x + w.w + sh, floorY); g.lineTo(w.x + sh, floorY); g.closePath(); g.fill();
      g.fillStyle = css(A.beamColor, 0.07 * A.beam); g.beginPath(); g.moveTo(w.x + 6, w.y); g.lineTo(w.x + w.w - 6, w.y); g.lineTo(w.x + w.w - 6 + sh * 0.6, w.y + (floorY - w.y) * 0.6); g.lineTo(w.x + 6 + sh * 0.6, w.y + (floorY - w.y) * 0.6); g.closePath(); g.fill();
      g.fillStyle = css(A.beamColor, 0.12 * A.beam); g.fillRect(w.x, w.y, w.w, w.h);
      g.fillStyle = css(A.beamColor, 0.22 * A.beam); g.fillRect(Math.round(w.x + sh), floorY - 1, w.w, 2);
    }
    const dk = Math.max(A.lamp, A.night * 0.8);
    if (dk > 0.15) for (const pr of this.glows) {
      const cx = pr.x, cy = pr.yF - pr.h * 0.6;
      if (!vis(cx, cy)) continue;
      const col = pr.ch === 'l' ? '#ffd99a' : pr.ch === 'i' ? '#7ab8ff' : pr.ch === 'V' ? '#ff3df2' : pr.ch === 'A' ? '#3ab8e8' : pr.ch === 'O' ? '#7aff9a' : pr.ch === 'v' ? '#ff5a5a' : '#ffb347';
      const r = pr.ch === 'l' ? 38 : 22, a = (pr.ch === 'l' ? 0.4 : 0.24 * (0.86 + 0.14 * Math.sin(this.time * 2.3 + pr.x))) * dk;
      g.globalAlpha = Math.min(1, a); g.drawImage(this.glowSprite(col, r), cx - r, (pr.ch === 'l' ? pr.yF - 22 : cy) - r, r * 2, r * 2); g.globalAlpha = 1;
    }
    for (const e of this.exits) {
      if (!vis(e.x, e.y)) continue;
      g.globalAlpha = 0.36 + 0.06 * Math.sin(this.time * 3 + e.x); g.drawImage(this.glowSprite('#58ffa0', 16), e.x - 16, e.y - 13, 32, 32);
    }
    for (const c of this.cams) {
      if (!vis(c.x, c.y) || (this.time * 0.9 + c.x * 0.013) % 1 > 0.55) continue;
      g.globalAlpha = 0.95; g.fillStyle = '#ff5050'; g.fillRect(Math.round(c.x), Math.round(c.y), 1, 1);
      g.globalAlpha = 0.4; g.drawImage(this.glowSprite('#ff3a3a', 8), c.x - 8, c.y - 8, 16, 16);
    }
    if (this.hero && dk > 0.15) {
      // cahaya tepi untuk sang jagoan: selalu terbaca, juga di sudut gelap
      const h = this.hero;
      g.globalAlpha = 0.13 * dk; g.drawImage(this.glowSprite('#ffe6c4', 44), h.x - 44, h.y - 40, 88, 80);
      g.globalAlpha = 0.17 * dk; g.drawImage(this.glowSprite('#ffe6c4', 24), h.x - 26, h.y + 3, 52, 10);
    }
    g.globalAlpha = 1;
    g.restore();
  }
  private outdoor(x: number, y: number) {
    if (y >= (this.mapH - 1) * T) return true;
    const s = Math.max(0, Math.min(this.stories - 1, Math.floor(y / (STORY * T))));
    if (this.outdoorStory[s]) return true;
    const sp = this.spans[s];
    return !sp || x < sp[0] * T || x > (sp[1] + 1) * T;
  }
  /** hujan (hanya di luar ruangan), tetesan di kaca, percikan atap, kilat */
  drawWeather(g: CanvasRenderingContext2D, v: View) {
    const A = this.A;
    if (A.rain > 0.02) {
      const n = Math.round(110 * A.rain);
      g.fillStyle = `rgba(190,210,240,${0.35 + 0.25 * A.rain})`;
      for (let i = 0; i < n; i++) {
        const sp = 300 + (i % 7) * 45;
        const x = v.ix + ((i * 71.3 + this.time * 70) % (v.bw + 20) + v.bw + 20) % (v.bw + 20) - 10;
        const y = v.iy + ((i * 37.9 + this.time * sp) % (v.bh + 20) + v.bh + 20) % (v.bh + 20) - 10;
        if (!this.outdoor(x, y)) continue;
        g.fillRect(Math.round(x), Math.round(y), 1, 5); g.fillRect(Math.round(x) - 1, Math.round(y) + 5, 1, 3);
      }
      g.fillStyle = 'rgba(200,225,255,0.55)';
      for (const w of this.windows) {
        if (w.x + w.w < v.ix || w.x > v.ix + v.bw || w.y > v.iy + v.bh || w.y + w.h < v.iy) continue;
        for (let k = 0; k < 5; k++) { const dx = Math.floor(hh(w.x, k, 13) * (w.w - 2)), sp = 14 + hh(k, w.x, 5) * 20, dy = (this.time * sp + hh(w.x, k, 7) * w.h) % w.h; g.fillRect(w.x + 1 + dx, Math.round(w.y + dy), 1, 3); }
      }
      if (Math.random() < A.rain) for (let i = 0; i < 3; i++) {
        const x = v.ix + Math.random() * v.bw;
        for (let s = 0; s < this.stories; s++) if (this.outdoorStory[s]) this.fx.add({ x, y: (s * STORY + STORY - 1) * T - 0.5, vx: (Math.random() - 0.5) * 50, vy: -25 - Math.random() * 45, life: 0.3, c: '#cfe3ff', s: 1, k: 12, g: 500 });
      }
    }
    this.fx.draw(g);
    if (this.lightning > 0.02) { g.save(); g.globalCompositeOperation = 'screen'; g.fillStyle = `rgba(200,215,255,${this.lightning * 0.4})`; g.fillRect(v.ix, v.iy, v.bw, v.bh); g.restore(); }
  }
  /** DATA GEDUNG untuk KANTOR 3D TOTAL (dinding, jendela, pintu, lift, tanda, dekor blueprint) */
  building3D() {
    const themes = Array.from({ length: this.stories }, (_, s) => (this.m1 ? themeOf(this.m1, s) : THEMES.cubicle));
    return {
      T, STORY, stories: this.stories, spans: this.spans, outdoor: this.outdoorStory, themes,
      windows: this.windows, gates: this.gates, exits: this.exits, cams: this.cams,
      decor: (this.lvlRef?.officeMap?.decor ?? []) as { kind: string; tx: number; ty: number; w?: number; label?: string }[],
      carpets: this.furn.filter((f) => f.ch === 'R').map((f) => ({ c: f.c, r: f.r })),
    };
  }
  // ===================== SPRITE UNTUK KANTOR 3D (divoxelisasi) =====================
  /** sprite furnitur: kanvas + posisi dunia kiri-atas */
  furnSprites(): { cv: HTMLCanvasElement; x: number; y: number; ch: string; h: number }[] {
    const out: { cv: HTMLCanvasElement; x: number; y: number; ch: string; h: number }[] = [];
    if (!this.m1) return out;
    for (const f of this.furn) {
      if (f.ch === 'R') continue;   // karpet tipis: biarkan dilukis di lantai
      const s = Math.floor(f.r / STORY);
      const cv = document.createElement('canvas'); cv.width = 32; cv.height = 56;
      const g = cv.getContext('2d')!;
      drawProp(g, f.ch, 8, 52, { broken: false, t: 0, seed: hh(f.c, f.r, 5), shake: 0, nl: f.nl, nr: f.nr, th: themeOf(this.m1, s) });
      out.push({ cv, x: f.c * T - 8, y: (f.r + 1) * T - 52, ch: f.ch, h: propHeight(f.ch) });
    }
    return out;
  }
  /** sprite hiasan dinding */
  decorSprites(): { cv: HTMLCanvasElement; x: number; y: number; kind: string }[] {
    return this.decorAll.map((d) => {
      const hgt = Math.max(8, d.yF - d.y0 + 2);
      const cv = document.createElement('canvas'); cv.width = 32; cv.height = hgt;
      drawDecorAt(cv.getContext('2d')!, d.kind, d.th, 8, 0, d.yF - d.y0, d.sd);
      return { cv, x: d.x - 8, y: d.y0, kind: d.kind };
    });
  }
  private propCache = new Map<string, HTMLCanvasElement>();
  /** sprite props interaktif (meja/pot/peti/tong), utuh atau hancur. Asal kanvas = (x-20, y-36) */
  propSprite(kind: string, y: number, dead: boolean): HTMLCanvasElement | null {
    const ch = kind === 'table' ? 'd' : kind === 'pot' ? 'p' : kind === 'crate' ? 'b' : kind === 'barrel' ? 'Z' : null;
    if (!ch) return null;
    const s = Math.max(0, Math.min(this.stories - 1, Math.floor((y - 1) / (STORY * T))));
    const key = `${ch}|${dead ? 1 : 0}|${s}`;
    let cv = this.propCache.get(key);
    if (!cv) {
      cv = document.createElement('canvas'); cv.width = 40; cv.height = 40;
      const g = cv.getContext('2d')!;
      const th = this.m1 ? themeOf(this.m1, s) : THEMES.cubicle;
      if (ch === 'd') {
        drawProp(g, 'd', 4, 36, { broken: dead, t: 0, seed: 0.8, shake: 0, nl: false, nr: true, th });
        drawProp(g, 'd', 20, 36, { broken: dead, t: 0, seed: 0.2, shake: 0, nl: true, nr: false, th });
      } else drawProp(g, ch, 12, 36, { broken: dead, t: 0, seed: 0.6, shake: 0, nl: false, nr: false, th });
      this.propCache.set(key, cv);
    }
    return cv;
  }
  /** props interaktif V2 (meja / pot / peti / tong) digambar dengan seni V1 */
  drawV2Prop(g: CanvasRenderingContext2D, pr: { x: number; y: number; kind: string; hp: number; dead?: boolean; flash?: number }, flash: boolean, time: number): boolean {
    const ch = pr.kind === 'table' ? 'd' : pr.kind === 'pot' ? 'p' : pr.kind === 'crate' ? 'b' : pr.kind === 'barrel' ? 'Z' : null;
    if (!ch) return false;
    const s = Math.max(0, Math.min(this.stories - 1, Math.floor((pr.y - 1) / (STORY * T))));
    const th = this.m1 ? themeOf(this.m1, s) : THEMES.cubicle;
    if (ch === 'd') { // meja V2: 20px, permukaan pijak y-9 — gambar dua petak meja V1 sambung
      drawProp(g, 'd', pr.x - 16, pr.y, { broken: !!pr.dead, t: time, seed: 0.8, shake: 0, nl: false, nr: true, th });
      drawProp(g, 'd', pr.x, pr.y, { broken: !!pr.dead, t: time, seed: 0.2, shake: 0, nl: true, nr: false, th });
    } else drawProp(g, ch, pr.x - 8, pr.y, { broken: !!pr.dead, t: time, seed: 0.6, shake: 0, nl: false, nr: false, th });
    if (flash) { g.globalAlpha = 0.6; g.fillStyle = '#ffffff'; g.fillRect(Math.round(pr.x - 9), Math.round(pr.y - 12), 18, 12); g.globalAlpha = 1; }
    return true;
  }
}

// ================================ EFEK HIT V1 ================================
/** Efek kena pukul gaya V1: sisi DEPAN cuma kilatan kecil (pukulan tetap terlihat jelas),
 *  darah, gelombang kejut, garis laju & bintang benturan keluar dari sisi BELAKANG tubuh (searah pukulan). */
export class V1HitFx {
  fx = new FX(); back = new FX();
  spurts: { x: number; y: number; t: number }[] = [];
  constructor(solid: (x: number, y: number) => boolean, stamp: (x: number, y: number, c: string, s: number, floor: boolean) => void) {
    this.fx.solid = solid; this.back.solid = solid; this.fx.onBlood = stamp; this.back.onBlood = stamp;
  }
  hit(ex: number, feet: number, scale: number, pt: { x: number; y: number }, dir: number, o: { heavy: boolean; blood: number; power: number; kill?: boolean; color?: string }) {
    const a = dir > 0 ? 0 : Math.PI, top = feet - 15 * scale;
    const by = Math.max(top + 2, Math.min(feet - 3, pt.y)), bx = ex + dir * (4.5 * scale + 1);
    this.fx.flash(pt.x, pt.y, o.heavy ? 3 : 2);
    if (o.heavy) this.fx.ring(pt.x, pt.y, 1, 4, '#ffffff', 0.09, 1);
    const B = this.back;
    B.impact(bx + dir * 2, by, o.kill ? 11 : o.heavy ? 8 : 5, o.color ?? (o.heavy ? '#ffd166' : '#ffffff'));
    B.lines(bx + dir * 3, by, o.heavy ? 5 : 3, '#ffffff', a, o.heavy ? 340 : 260);
    B.spark(bx, by, o.heavy ? 8 : 4, o.kill ? '#ff8a8a' : '#ffffff', a, 0.55, o.heavy ? 290 : 210);
    if (o.heavy || o.kill) B.shockwave(bx + dir * 3, by, o.kill ? 20 : 13, '#ffffff', o.kill ? 0.3 : 0.22);
    B.blood(bx, by, Math.round(o.blood), a, o.power, '#d40000', o.kill ? 0.55 : 0.42);
    B.mist(bx, by, o.kill ? 5 : o.heavy ? 3 : 1, a);
    if (o.kill) this.spurts.push({ x: ex, y: feet - 9 * scale, t: 0.9 });
  }
  update(dt: number) {
    for (const s of this.spurts) { s.t -= dt; if (Math.random() < 0.75) this.back.blood(s.x + (Math.random() - 0.5) * 4, s.y, 2, -Math.PI / 2 + (Math.random() - 0.5), 170, '#c80000', 0.25); }
    this.spurts = this.spurts.filter((s) => s.t > 0);
    this.fx.update(dt); this.back.update(dt);
  }
}

// ================================ GLOW V1 (bloom aditif) ================================
export const GLOW_KEY_V2 = 'v2_office_glow';
export function loadV2Glow(): boolean { try { return localStorage.getItem(GLOW_KEY_V2) !== 'off'; } catch { return true; } }

/** Cahaya dinamis gaya V1: pukulan keras & KO, moncong senjata, ledakan, plus pendar aura mode N (8 Gerbang)
 *  dan mode X (One For All). Sprite pendar radial disimpan per warna/ukuran/resolusi, digambar dengan 'lighter'. */
export class V1Glow {
  lights: { x: number; y: number; r: number; c: string; life: number; max: number }[] = [];
  private sprites = new Map<string, HTMLCanvasElement>();
  add(x: number, y: number, r: number, c: string, life: number) {
    this.lights.push({ x, y, r, c, life, max: life });
    if (this.lights.length > 48) this.lights.shift();
  }
  update(dt: number) {
    if (!this.lights.length) return;
    for (const l of this.lights) l.life -= dt;
    this.lights = this.lights.filter((l) => l.life > 0);
  }
  clear() { this.lights = []; }
  private sprite(c: string, r: number, q: number) {
    const Rr = Math.max(4, Math.round(r / 4) * 4), key = `${c}|${Rr}|${q}`;
    let cv = this.sprites.get(key);
    if (!cv) {
      if (this.sprites.size > 160) this.sprites.clear();
      cv = document.createElement('canvas'); const S = Rr * 2 * q; cv.width = cv.height = S;
      const g = cv.getContext('2d')!, gr = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
      gr.addColorStop(0, rgba(c, 1)); gr.addColorStop(0.45, rgba(c, 0.4)); gr.addColorStop(1, rgba(c, 0));
      g.fillStyle = gr; g.fillRect(0, 0, S, S); this.sprites.set(key, cv);
    }
    return cv;
  }
  /** pendar radial (q = kerapatan sprite: makin besar makin halus di layar resolusi tinggi) */
  glow(g: CanvasRenderingContext2D, x: number, y: number, r: number, c: string, a: number, q = 1) {
    if (a <= 0.01 || r < 2) return;
    g.globalAlpha = Math.min(1, a);
    g.drawImage(this.sprite(c, r, q), x - r, y - r, r * 2, r * 2);
    g.globalAlpha = 1;
  }
  drawLights(g: CanvasRenderingContext2D, q = 1) {
    for (const l of this.lights) { const k = l.life / l.max; this.glow(g, l.x, l.y, l.r * (0.7 + 0.3 * k), l.c, 0.42 * k, q); }
  }
  /** aura ONE FOR ALL di belakang tubuh: pendar cyan + petir kecil (persis drawOfaAura V1) */
  ofaAura(g: CanvasRenderingContext2D, x: number, y: number) {
    g.save(); g.globalCompositeOperation = 'lighter';
    const gr = g.createRadialGradient(x, y - 8, 2, x, y - 8, 16);
    gr.addColorStop(0, 'rgba(87,230,255,0.35)'); gr.addColorStop(1, 'rgba(87,230,255,0)');
    g.fillStyle = gr; g.fillRect(x - 16, y - 24, 32, 32);
    g.restore();
    for (let i = 0; i < 3; i++) {
      let px = x + rnd(-6, 6), py = y - rnd(0, 16);
      for (let k = 0; k < 3; k++) { const nx = px + rnd(-3, 3), ny = py + rnd(-4, 1); pline(g, px, py, nx, ny, Math.random() < 0.5 ? '#7df9ff' : '#ffffff'); px = nx; py = ny; }
    }
  }
}
