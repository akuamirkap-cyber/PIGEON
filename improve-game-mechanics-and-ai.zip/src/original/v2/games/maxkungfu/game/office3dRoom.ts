// KANTOR 3D TOTAL — interior gedung dibangun sebagai geometri 3D (bukan lukisan 2D di dinding belakang):
// dinding bertekstur HD per tema + wainscot, list lantai & crown molding, pilaster, lantai bertema (kayu/ubin/karpet),
// jendela berbingkai 3D dengan pemandangan kota ber-parallax, pintu darurat & lift 3D, tanda EXIT menyala, CCTV,
// meja resepsionis, rak server ber-LED, gerbang keamanan, banner, lampu kristal, karpet.
import * as THREE from 'three';

type Theme = { id: string; wall: string; wall2: string; panel: string; trim: string; floor: string; floorTop: string; light: string; accent: string };
export interface Building3D {
  T: number; STORY: number; stories: number; spans: [number, number][]; outdoor: boolean[]; themes: Theme[];
  windows: { x: number; y: number; w: number; h: number; story: number }[];
  gates: { x: number; yF: number; ch: 'S' | 'E' }[];
  exits: { x: number; y: number }[]; cams: { x: number; y: number }[];
  decor: { kind: string; tx: number; ty: number; w?: number; label?: string }[];
  carpets: { c: number; r: number }[];
}

const col = (h: string, k = 0) => { const c = new THREE.Color(h); if (k > 0) c.lerp(new THREE.Color('#ffffff'), k); else if (k < 0) c.multiplyScalar(1 + k); return c; };
const hex = (c: THREE.Color) => '#' + c.getHexString();

function hdTex(cv: HTMLCanvasElement, repeat = true): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.magFilter = THREE.LinearFilter;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.generateMipmaps = true;
  if (repeat) { t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.RepeatWrapping; }
  return t;
}

/** tekstur dinding per tema (128x256 = 32x64 px dunia, 4x lebih tajam) */
function wallTexture(th: Theme): HTMLCanvasElement {
  const cv = document.createElement('canvas'); cv.width = 128; cv.height = 256;
  const g = cv.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 0, 256);
  gr.addColorStop(0, hex(col(th.wall, -0.18))); gr.addColorStop(0.25, th.wall); gr.addColorStop(1, hex(col(th.wall, -0.08)));
  g.fillStyle = gr; g.fillRect(0, 0, 128, 256);
  // panel dinding: sambungan vertikal + bevel
  g.fillStyle = hex(col(th.wall2, -0.1)); g.fillRect(0, 0, 3, 256);
  g.fillStyle = hex(col(th.wall, 0.12)); g.fillRect(3, 0, 2, 256);
  // tekstur halus (noise lembut)
  for (let i = 0; i < 900; i++) { g.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.025)' : 'rgba(0,0,0,0.035)'; g.fillRect(Math.random() * 128, Math.random() * 256, 2, 2); }
  // rel tengah
  g.fillStyle = hex(col(th.panel, -0.05)); g.fillRect(0, 150, 128, 5);
  g.fillStyle = hex(col(th.panel, 0.2)); g.fillRect(0, 150, 128, 1);
  return cv;
}

/** tekstur lantai per tema: kayu / ubin / karpet / karet / raised floor */
function floorTexture(th: Theme): HTMLCanvasElement {
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 256;
  const g = cv.getContext('2d')!;
  const base = th.floorTop;
  g.fillStyle = base; g.fillRect(0, 0, 256, 256);
  const style = ({ meeting: 'wood', archive: 'wood', exec: 'carpet', cubicle: 'carpet', lounge: 'carpet', lab: 'tile', pantry: 'tile', lobby: 'marble', gym: 'rubber', server: 'raised', security: 'tile' } as Record<string, string>)[th.id] ?? 'tile';
  if (style === 'wood') {
    for (let y = 0; y < 256; y += 32) {
      for (let x = (y / 32) % 2 ? -64 : 0; x < 256; x += 128) {
        g.fillStyle = hex(col(base, (Math.random() - 0.5) * 0.18)); g.fillRect(x, y, 128, 32);
        g.strokeStyle = 'rgba(0,0,0,0.35)'; g.lineWidth = 2; g.strokeRect(x, y, 128, 32);
        for (let k = 0; k < 4; k++) { g.strokeStyle = 'rgba(0,0,0,0.08)'; g.beginPath(); g.moveTo(x, y + 6 + k * 7); g.bezierCurveTo(x + 40, y + 3 + k * 7, x + 80, y + 10 + k * 7, x + 128, y + 6 + k * 7); g.stroke(); }
      }
    }
  } else if (style === 'carpet') {
    for (let i = 0; i < 6000; i++) { g.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.07)'; g.fillRect(Math.random() * 256, Math.random() * 256, 1.5, 1.5); }
    g.strokeStyle = 'rgba(0,0,0,0.12)'; g.lineWidth = 2; for (let x = 0; x <= 256; x += 128) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 256); g.stroke(); }
  } else if (style === 'marble') {
    for (let y = 0; y < 256; y += 128) for (let x = 0; x < 256; x += 128) {
      g.fillStyle = hex(col(base, (x + y) % 256 ? 0.05 : -0.05)); g.fillRect(x, y, 128, 128);
      g.strokeStyle = 'rgba(255,255,255,0.18)'; g.lineWidth = 1.2;
      for (let k = 0; k < 3; k++) { g.beginPath(); g.moveTo(x + Math.random() * 128, y); g.bezierCurveTo(x + Math.random() * 128, y + 40, x + Math.random() * 128, y + 90, x + Math.random() * 128, y + 128); g.stroke(); }
      g.strokeStyle = 'rgba(0,0,0,0.3)'; g.lineWidth = 2; g.strokeRect(x, y, 128, 128);
    }
  } else if (style === 'rubber') {
    for (let y = 0; y < 256; y += 16) for (let x = (y / 16) % 2 ? 8 : 0; x < 256; x += 16) { g.fillStyle = 'rgba(0,0,0,0.18)'; g.beginPath(); g.arc(x, y, 2.5, 0, 6.3); g.fill(); }
  } else if (style === 'raised') {
    for (let y = 0; y < 256; y += 64) for (let x = 0; x < 256; x += 64) {
      g.strokeStyle = 'rgba(0,0,0,0.45)'; g.lineWidth = 3; g.strokeRect(x + 1, y + 1, 62, 62);
      for (let k = 0; k < 4; k++) for (let j = 0; j < 4; j++) { g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(x + 12 + k * 12, y + 12 + j * 12, 4, 4); }
    }
  } else {
    for (let y = 0; y < 256; y += 64) for (let x = 0; x < 256; x += 64) {
      g.fillStyle = hex(col(base, (Math.random() - 0.5) * 0.08)); g.fillRect(x, y, 64, 64);
      g.strokeStyle = 'rgba(0,0,0,0.3)'; g.lineWidth = 2; g.strokeRect(x, y, 64, 64);
      g.strokeStyle = 'rgba(255,255,255,0.12)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 2, y + 62); g.lineTo(x + 2, y + 2); g.lineTo(x + 62, y + 2); g.stroke();
    }
  }
  return cv;
}

/** pemandangan kota malam di balik jendela (dipakai berulang, offset parallax per jendela) */
function cityTexture(accent: string): HTMLCanvasElement {
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 256;
  const g = cv.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 0, 256);
  gr.addColorStop(0, '#070a18'); gr.addColorStop(0.6, '#141a36'); gr.addColorStop(1, hex(col(accent, -0.55)));
  g.fillStyle = gr; g.fillRect(0, 0, 512, 256);
  for (let i = 0; i < 60; i++) { g.fillStyle = `rgba(255,255,255,${Math.random() * 0.6})`; g.fillRect(Math.random() * 512, Math.random() * 120, 1.2, 1.2); }
  for (let layer = 0; layer < 3; layer++) {
    for (let x = -10; x < 512;) {
      const w = 24 + Math.random() * 46, h = 50 + Math.random() * (60 + layer * 50);
      g.fillStyle = ['#1a2140', '#121831', '#0a0e1f'][layer];
      g.fillRect(x, 256 - h, w - 3, h);
      for (let wy = 256 - h + 6; wy < 250; wy += 8) for (let wx = x + 4; wx < x + w - 8; wx += 6) {
        if (Math.random() < 0.3 + layer * 0.08) { g.fillStyle = Math.random() < 0.8 ? '#ffd78a' : '#8fd8ff'; g.globalAlpha = 0.35 + layer * 0.25; g.fillRect(wx, wy, 3, 4); g.globalAlpha = 1; }
      }
      x += w;
    }
  }
  return cv;
}

function textTex(text: string, fg: string, bg: string, w = 512, h = 96): HTMLCanvasElement {
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const g = cv.getContext('2d')!;
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.fillStyle = fg; g.font = `800 ${Math.round(h * 0.62)}px 'Barlow Condensed', 'Arial Narrow', sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, w / 2, h / 2 + 2);
  return cv;
}

export class Interior3D {
  group = new THREE.Group();
  private winViews: { mesh: THREE.Mesh; tex: THREE.Texture; x: number; w: number }[] = [];
  private disposables: { dispose(): void }[] = [];
  private blink: { m: THREE.MeshStandardMaterial; ph: number }[] = [];

  private keep<T extends { dispose(): void }>(o: T): T { this.disposables.push(o); return o; }
  private std(c: string | THREE.Color, o: Partial<THREE.MeshStandardMaterialParameters> = {}) { return this.keep(new THREE.MeshStandardMaterial({ color: c, roughness: 0.6, metalness: 0.05, ...o })); }
  private box(x0: number, y0: number, x1: number, y1: number, z0: number, z1: number, m: THREE.Material | THREE.Material[]) {
    const geo = this.keep(new THREE.BoxGeometry(Math.max(0.05, x1 - x0), Math.max(0.05, y1 - y0), Math.max(0.05, z1 - z0)));
    const mesh = new THREE.Mesh(geo, m);
    mesh.position.set((x0 + x1) / 2, -(y0 + y1) / 2, (z0 + z1) / 2);
    this.group.add(mesh);
    return mesh;
  }

  build(b: Building3D, DEPTH: number) {
    const T = b.T, SP = b.STORY * T;
    const ZW = -DEPTH + 0.02;
    const city = hdTex(cityTexture(b.themes[0]?.accent ?? '#3aa0ff'));
    this.keep(city);
    for (let s = 0; s < b.stories; s++) {
      if (b.outdoor[s]) continue;
      const th = b.themes[s]; const span = b.spans[s];
      if (!th || !span) continue;
      const x0 = span[0] * T, x1 = (span[1] + 1) * T, W = x1 - x0;
      const yS = s * SP, yF = yS + SP - T;
      // dinding belakang bertekstur HD
      const wt = this.keep(hdTex(wallTexture(th))); wt.repeat.set(W / 32, 1);
      const wall = new THREE.Mesh(this.keep(new THREE.PlaneGeometry(W, yF - yS)), this.std('#ffffff', { map: wt, roughness: 0.85 }));
      wall.position.set(x0 + W / 2, -(yS + yF) / 2, ZW);
      this.group.add(wall);
      // lantai bertema (permukaan rata dengan bidang pijak)
      const ft = this.keep(hdTex(floorTexture(th))); ft.repeat.set(W / 64, DEPTH / 64);
      const floor = new THREE.Mesh(this.keep(new THREE.PlaneGeometry(W, DEPTH)), this.std('#ffffff', { map: ft, roughness: th.id === 'lobby' || th.id === 'lab' ? 0.25 : 0.7, metalness: th.id === 'lobby' ? 0.15 : 0.02 }));
      floor.rotation.x = -Math.PI / 2;
      floor.position.set(x0 + W / 2, -(yF - 0.12), -DEPTH / 2);
      this.group.add(floor);
      // wainscot, list lantai, crown molding
      const wsc = this.std(col(th.wall2, -0.05), { roughness: 0.7 }), trim = this.std(th.trim, { roughness: 0.4, metalness: 0.3 });
      this.box(x0, yF - 18, x1, yF, -DEPTH, -DEPTH + 1.3, wsc);
      this.box(x0, yF - 18.8, x1, yF - 17.6, -DEPTH, -DEPTH + 2, trim);
      this.box(x0, yF - 3, x1, yF, -DEPTH, -DEPTH + 2.4, this.std(col(th.trim, -0.45)));
      this.box(x0, yS, x1, yS + 3, -DEPTH, -DEPTH + 2.6, this.std(col(th.wall, 0.12)));
      this.box(x0, yS + 3, x1, yS + 3.8, -DEPTH, -DEPTH + 1.8, trim);
      // pilaster berirama (dilewati bila menabrak jendela / pintu)
      const blocked = (px: number) => b.windows.some((w) => w.story === s && px + 5 > w.x - 3 && px - 5 < w.x + w.w + 3) || b.gates.some((g) => Math.abs(g.yF - yF) < 4 && Math.abs(g.x + 8 - px) < 18);
      for (let px = x0 + 48; px < x1 - 24; px += 96) {
        if (blocked(px)) continue;
        this.box(px - 3, yS + 3.8, px + 3, yF - 3, -DEPTH, -DEPTH + 3, this.std(col(th.panel, 0.05), { roughness: 0.55 }));
        this.box(px - 4, yF - 6, px + 4, yF - 3, -DEPTH, -DEPTH + 3.6, trim);
      }
    }
    // jendela: bingkai 3D + kaca + pemandangan kota parallax
    const frameM = this.std('#262c3a', { metalness: 0.6, roughness: 0.35 });
    const glassM = this.std('#bfe6ff', { transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0.4, depthWrite: false });
    for (const w of b.windows) {
      if (b.outdoor[w.story]) continue;
      const t = city.clone(); t.needsUpdate = true; this.keep(t);
      t.repeat.set(w.w / 512 * 1.6, w.h / 256 * 1.6);
      const view = new THREE.Mesh(this.keep(new THREE.PlaneGeometry(w.w, w.h)), this.keep(new THREE.MeshBasicMaterial({ map: t })));
      view.position.set(w.x + w.w / 2, -(w.y + w.h / 2), ZW + 0.18);
      this.group.add(view);
      this.winViews.push({ mesh: view, tex: t, x: w.x, w: w.w });
      const glass = new THREE.Mesh(this.keep(new THREE.PlaneGeometry(w.w, w.h)), glassM);
      glass.position.set(w.x + w.w / 2, -(w.y + w.h / 2), -DEPTH + 1.4);
      this.group.add(glass);
      const fz0 = -DEPTH, fz1 = -DEPTH + 2.4;
      this.box(w.x - 2, w.y - 2, w.x + w.w + 2, w.y, fz0, fz1, frameM);
      this.box(w.x - 2, w.y + w.h, w.x + w.w + 2, w.y + w.h + 2, fz0, fz1 + 2.5, frameM);   // ambang menonjol
      this.box(w.x - 2, w.y, w.x, w.y + w.h, fz0, fz1, frameM);
      this.box(w.x + w.w, w.y, w.x + w.w + 2, w.y + w.h, fz0, fz1, frameM);
      for (let mx = w.x + 16; mx < w.x + w.w - 4; mx += 16) this.box(mx - 0.6, w.y, mx + 0.6, w.y + w.h, fz0, fz1 - 0.6, frameM);
    }
    // pintu darurat & lift
    for (const g of b.gates) {
      const x = g.x, yF = g.yF;
      if (g.ch === 'S') {
        this.box(x + 0.5, yF - 24, x + 15.5, yF, -DEPTH, -DEPTH + 2.2, this.std('#3a4252', { metalness: 0.5, roughness: 0.4 }));
        this.box(x + 2, yF - 22, x + 14, yF, -DEPTH, -DEPTH + 2.8, this.std('#5d6677', { metalness: 0.55, roughness: 0.35 }));
        this.box(x + 4, yF - 19, x + 7, yF - 14, -DEPTH + 2.8, -DEPTH + 3, this.std('#a8d8ff', { emissive: '#4a7aa0', emissiveIntensity: 0.6, roughness: 0.1 }));
        this.box(x + 3, yF - 11.5, x + 13, yF - 10.5, -DEPTH + 2.8, -DEPTH + 4, this.std('#c9ced8', { metalness: 0.9, roughness: 0.2 }));
      } else {
        const steel = this.std('#b9c2cf', { metalness: 0.85, roughness: 0.22 });
        this.box(x - 2, yF - 27, x + 18, yF, -DEPTH, -DEPTH + 2.6, this.std('#6b7486', { metalness: 0.7, roughness: 0.3 }));
        this.box(x, yF - 24, x + 7.85, yF, -DEPTH, -DEPTH + 3, steel);
        this.box(x + 8.15, yF - 24, x + 16, yF, -DEPTH, -DEPTH + 3, steel);
        const ind = this.std('#ffcf6a', { emissive: '#ffb030', emissiveIntensity: 1.2 });
        this.box(x + 5, yF - 26.6, x + 11, yF - 25, -DEPTH + 2.6, -DEPTH + 3, ind);
        this.blink.push({ m: ind, ph: x * 0.1 });
      }
    }
    // tanda EXIT hijau menyala
    for (const e of b.exits) {
      const m = this.std('#12a05e', { emissive: '#18d47a', emissiveIntensity: 1.1 });
      this.box(e.x - 7, e.y - 4, e.x + 7, e.y + 4, -DEPTH, -DEPTH + 2, [m, m, m, m, this.keep(new THREE.MeshBasicMaterial({ map: this.keep(hdTex(textTex('EXIT', '#eafff3', '#12a05e', 256, 128), false)) })), m]);
    }
    // CCTV
    for (const c of b.cams) {
      const body = this.std('#d8dce4', { roughness: 0.4 });
      this.box(c.x - 1, c.y - 6, c.x, c.y - 2, -DEPTH, -DEPTH + 1.5, this.std('#3a3f4a'));
      this.box(c.x - 3, c.y - 3, c.x + 4, c.y + 1, -DEPTH + 1, -DEPTH + 6, body);
      const led = this.std('#ff3b3b', { emissive: '#ff2020', emissiveIntensity: 1.5 });
      this.box(c.x + 3.5, c.y - 2.5, c.x + 4.3, c.y - 1.7, -DEPTH + 5, -DEPTH + 6.2, led);
      this.blink.push({ m: led, ph: c.x });
    }
    // dekor blueprint
    for (const d of b.decor) {
      const x = d.tx * T, y = d.ty * T, w = (d.w ?? 1) * T;
      if (d.kind === 'reception') {
        this.box(x, y + 2, x + w, y + 16, -DEPTH + 4, -DEPTH + 18, this.std('#17202c', { roughness: 0.4 }));
        this.box(x - 0.5, y + 1, x + w + 0.5, y + 3, -DEPTH + 3.5, -DEPTH + 19, this.std('#bcb1a0', { roughness: 0.25, metalness: 0.1 }));
        this.box(x + 6, y + 8, x + w - 6, y + 9, -DEPTH + 18, -DEPTH + 18.4, this.std('#bd9565', { metalness: 0.8, roughness: 0.25 }));
        const sign = this.keep(new THREE.MeshBasicMaterial({ map: this.keep(hdTex(textTex('STIKFICK', '#f4e4c9', '#0c1422'), false)) }));
        const sm = this.std('#0c1422');
        this.box(x + 2, y - 25, x + w - 2, y - 5, -DEPTH, -DEPTH + 1.6, [sm, sm, sm, sm, sign, sm]);
        for (const mx of [x + 10, x + w - 21]) {
          this.box(mx, y - 5, mx + 11, y + 1, -DEPTH + 9, -DEPTH + 10, this.std('#0c111c'));
          this.box(mx + 1, y - 4, mx + 10, y, -DEPTH + 10, -DEPTH + 10.1, this.std('#559bb4', { emissive: '#3a8ab0', emissiveIntensity: 0.9 }));
        }
      } else if (d.kind === 'banner' && d.label) {
        const bm = this.std('#101c2a');
        const lab = this.keep(new THREE.MeshBasicMaterial({ map: this.keep(hdTex(textTex(d.label, '#b8dce6', '#101c2a'), false)) }));
        this.box(x + 2, y + 1, x + w - 2, y + 11, -DEPTH, -DEPTH + 1.2, [bm, bm, bm, bm, lab, bm]);
        this.box(x + 2, y + 1, x + w - 2, y + 1.6, -DEPTH, -DEPTH + 1.5, this.std('#c49a62', { metalness: 0.7 }));
      } else if (d.kind === 'security_gate') {
        const post = this.std('#657581', { metalness: 0.7, roughness: 0.3 });
        this.box(x + 1, y - 11, x + 3, y + 16, -DEPTH + 6, -DEPTH + 16, post);
        this.box(x + 13, y - 11, x + 15, y + 16, -DEPTH + 6, -DEPTH + 16, post);
        this.box(x + 1, y - 12, x + 15, y - 10, -DEPTH + 6, -DEPTH + 16, this.std('#9caeb7', { metalness: 0.7 }));
        const strip = this.std('#68e9de', { emissive: '#40e0d0', emissiveIntensity: 1.2 });
        this.box(x + 5, y - 11, x + 11, y - 10.4, -DEPTH + 15.8, -DEPTH + 16.2, strip);
        this.blink.push({ m: strip, ph: x });
      } else if (d.kind === 'server') {
        this.box(x + 2, y - 11, x + 14, y + 16, -DEPTH + 1, -DEPTH + 15, this.std('#101621', { metalness: 0.4, roughness: 0.4 }));
        for (let k = 0; k < 5; k++) {
          this.box(x + 3, y - 8 + k * 5, x + 13, y - 5 + k * 5, -DEPTH + 15, -DEPTH + 15.4, this.std('#1b2636', { metalness: 0.5 }));
          const led = this.std(k % 2 ? '#58eccb' : '#89c6ff', { emissive: k % 2 ? '#40e0b0' : '#5aa8ff', emissiveIntensity: 1.6 });
          this.box(x + 4.2, y - 7.2 + k * 5, x + 5.2, y - 6.2 + k * 5, -DEPTH + 15.3, -DEPTH + 15.7, led);
          this.blink.push({ m: led, ph: x + k * 7 });
        }
      } else if (d.kind === 'chandelier') {
        const cx = x + w / 2, cy = y + 10;
        const crys = this.std('#fff2d8', { emissive: '#ffd5a0', emissiveIntensity: 1.4, roughness: 0.1, metalness: 0.3 });
        this.box(cx - 0.4, y, cx + 0.4, cy - 3, -14, -12, this.std('#c9a033', { metalness: 0.9 }));
        for (let k = 0; k < 7; k++) {
          const a = (k / 7) * Math.PI * 2;
          const m = new THREE.Mesh(this.keep(new THREE.OctahedronGeometry(1.4, 0)), crys);
          m.position.set(cx + Math.cos(a) * 5, -(cy + Math.sin(k) * 1.5), -13 + Math.sin(a) * 5);
          this.group.add(m);
        }
      }
    }
    // karpet
    const rug = this.std('#8a2433', { roughness: 0.95 }), rugEdge = this.std('#e0b84a', { metalness: 0.4, roughness: 0.5 });
    for (const c of b.carpets) {
      const x = c.c * T, yF = (c.r + 1) * T;
      this.box(x, yF - 0.7, x + T, yF - 0.08, -DEPTH + 6, -6, rug);
      this.box(x, yF - 0.8, x + T, yF - 0.6, -7, -6, rugEdge);
    }
  }

  /** per frame: pemandangan jendela bergeser (parallax) mengikuti kamera, lampu LED berkedip */
  update(camX: number, time: number) {
    for (const v of this.winViews) v.tex.offset.x = ((camX - v.x) / 512) * 0.35;
    for (const b of this.blink) b.m.emissiveIntensity = 0.7 + 0.8 * Math.max(0, Math.sin(time * 3 + b.ph));
  }

  dispose() {
    for (const d of this.disposables) d.dispose();
    this.disposables = []; this.winViews = []; this.blink = [];
    this.group.clear();
  }
}
