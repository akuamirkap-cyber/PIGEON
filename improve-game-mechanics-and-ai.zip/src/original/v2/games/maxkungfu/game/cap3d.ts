// TANGKAP UNTUK KARAKTER 3D: saat aktif, stickman & senjata yang digambar ke canvas dunia tidak digambar 2D,
// melainkan kerangka (sendi) + posisi senjatanya dicatat lalu dirender sebagai model 3D HD (chars3d.ts).
type V = { x: number; y: number };

export interface CharRec {
  x: number; y: number; scale: number;
  hip: V; neck: V; head: V; ffoot: V; bfoot: V; fhand: V; bhand: V;
  fknee: V | null; bknee: V | null; felbow: V | null; belbow: V | null;
  c: string; c2: string; flash: boolean; outline: string | null; acc: string; eyes: string;
  facing: number; look: number; mood: string; alpha: number; strike: string | null; headR: number;
  /** id karakter untuk pegas gerak lanjutan 3D (undefined = tanpa) */
  id?: number;
  /** tubuh dikendalikan fisika ragdoll (tanpa putaran badan / pegas penghalus) */
  rag?: boolean;
}

export interface WeapRec {
  kind: string; bx: number; by: number; tx: number; ty: number; scale: number; color?: string; glow?: string | null; facing?: number; alpha?: number;
}

export const CAP = {
  on: false,
  ctx: null as unknown,
  chars: [] as CharRec[],
  weapons: [] as WeapRec[],
  /** tetesan darah untuk dirender 3D mengkilap */
  blood: [] as { x: number; y: number; vx: number; vy: number; s: number; c: string }[],
};

export function capReset(on: boolean, ctx: unknown) {
  CAP.on = on; CAP.ctx = ctx; CAP.chars.length = 0; CAP.weapons.length = 0; CAP.blood.length = 0;
}

/** true bila gambar ke ctx ini sedang ditangkap untuk 3D */
export function capOn(ctx: unknown): boolean { return CAP.on && ctx === CAP.ctx; }

/** Catat satu senjata (segmen pangkal -> ujung, koordinat dunia). Mengembalikan true bila ditangkap (lewati gambar 2D). */
export function capWeapon(ctx: unknown, kind: string, base: V, tip: V, scale = 1, extra?: Partial<WeapRec>): boolean {
  if (!capOn(ctx)) return false;
  CAP.weapons.push({ kind, bx: base.x, by: base.y, tx: tip.x, ty: tip.y, scale, ...extra });
  return true;
}
