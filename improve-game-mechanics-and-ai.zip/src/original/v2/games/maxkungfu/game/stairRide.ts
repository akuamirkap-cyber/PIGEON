// PARKOUR TANGGA: jalur anak tangga yang benar per lantai + salto depan / belakang (front flip / back flip)
// Dipakai pemain DAN musuh, supaya naik-turun tangga cepat, seru, dan musuh tidak lagi tersangkut/melayang di anak tangga.
import { officeStairPath, stairPathProject, stairPathAt, officeFloorSupportY } from './office';
import type { Enemy } from './types';

type Pt = { x: number; y: number };
export type StairFlip = { t: number; dur: number; s0: number; s1: number; h: number; kind: 'front' | 'back'; mdir: 1 | -1; path: Pt[] };
export type StairRide = { up: boolean; cd: number; flip?: StairFlip; life: number };

const easeIO = (u: number) => (u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2);
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

/**
 * Pilih jalur (flight) tangga yang tepat untuk arah naik / turun.
 * Di batas lantai, officeStairPath bisa mengembalikan flight di BAWAH saat ingin naik (penyebab stuck).
 * Di sini kita cek flight di sekitar kaki dan pilih yang benar-benar menuju arah yang diinginkan.
 */
export function stairPathFor(l: any, x: number, y: number, up: boolean): { path: Pt[]; pr: { s: number; total: number; dist: number } } | null { // eslint-disable-line @typescript-eslint/no-explicit-any
  const cands: Pt[][] = [];
  for (const oy of [0, -6, 6, -12, 12]) {
    const p = officeStairPath(l, x, y + oy);
    if (p && !cands.some((q) => Math.abs(q[0].y - p[0].y) < 0.5)) cands.push(p);
  }
  let best: { path: Pt[]; pr: { s: number; total: number; dist: number } } | null = null;
  for (const path of cands) {
    const bot = path[0].y, top = path[path.length - 1].y;
    const ok = up ? bot >= y - 2.5 && top < y - 2.5 : top <= y + 2.5 && bot > y + 2.5;
    if (!ok) continue;
    const pr = stairPathProject(path, x, y);
    if (!best || pr.dist < best.pr.dist) best = { path, pr };
  }
  return best;
}

/** Sudut putar badan selama salto (positif = searah jarum jam di layar). */
export function stairFlipAngle(f: StairFlip): number {
  const u = clamp(f.t / f.dur, 0, 1);
  // tuck cepat di tengah, melambat saat mendarat
  return Math.PI * 2 * easeIO(u) * f.mdir;
}

export function makeFlip(path: Pt[], s0: number, s1: number, kind: 'front' | 'back', mdir: number, dur = 0.42, h = 15): StairFlip {
  return { t: 0, dur, s0, s1, h, kind, mdir: (mdir >= 0 ? 1 : -1) as 1 | -1, path };
}

/** Maju satu frame salto: kembalikan posisi kaki dan apakah sudah mendarat. */
export function stepFlip(f: StairFlip, dt: number): { x: number; y: number; done: boolean; footY: number } {
  f.t += dt;
  const u = clamp(f.t / f.dur, 0, 1);
  const k = easeIO(u);
  const s = f.s0 + (f.s1 - f.s0) * k;
  const at = stairPathAt(f.path, s);
  return { x: at.x, y: at.y - Math.sin(Math.PI * u) * f.h, done: u >= 1, footY: at.y };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type G = any;
type RideEnemy = Enemy & { sRide?: StairRide; rideSpd?: number };

export function getRide(e: Enemy): StairRide | undefined { return (e as RideEnemy).sRide; }
export function clearRide(e: Enemy) { const r = e as RideEnemy; r.sRide = undefined; r.rideSpd = 0; }
export function startRide(e: Enemy, up: boolean) {
  const r = e as RideEnemy;
  if (r.sRide && r.sRide.up === up) return;
  r.sRide = { up, cd: 0.15 + Math.random() * 0.25, life: 0 };
}

/**
 * Gerak musuh di tangga berbasis jalur: kaki SELALU menapak anak tangga, tidak ada gravitasi/zig-zag yang bisa macet.
 * Kadang musuh melakukan salto depan / belakang menuruni-menaiki beberapa anak tangga sekaligus.
 */
export function stepEnemyRide(g: G, e: Enemy, dt: number) {
  const r = e as RideEnemy;
  const sr = r.sRide!;
  const l = g.level, p = g.player;
  sr.cd = Math.max(0, sr.cd - dt);
  sr.life += dt;
  e.kx = 0; e.ky = 0; e.svVy = 0; e.svGrounded = false; e.svDropT = 0.2; e.z = 0; e.vz = 0;

  if (sr.flip) {
    const st = stepFlip(sr.flip, dt);
    e.x = st.x; e.y = st.y; e.vx = 0; e.moving = false; r.rideSpd = 0;
    e.facing = sr.flip.kind === 'front' ? sr.flip.mdir : (-sr.flip.mdir as 1 | -1);
    if (st.done) {
      e.y = st.footY; sr.flip = undefined;
      e.sqx = 1.28; e.sqy = 0.74;
      g.particles?.smoke?.(e.x, e.y, 4, '#9a9a9a', 22, 0.3);
      g.sfx?.land?.();
    }
    return;
  }

  const holding = e.state === 'windup' || e.state === 'lunge' || e.state === 'recover' || e.state === 'attack' || e.stun > 0;
  const res = stairPathFor(l, e.x, e.y, sr.up);
  if (!res) { endRide(g, e); return; }
  const { path, pr } = res;
  const dir = sr.up ? 1 : -1;
  if (holding) {
    const at = stairPathAt(path, pr.s);
    e.x += (at.x - e.x) * Math.min(1, dt * 20); e.y = at.y; e.vx = 0; r.rideSpd = 0;
    return;
  }
  const spd = Math.max(80, e.speed * 1.35) + (e.elite ? 35 : 0);
  const ns = clamp(pr.s + dir * spd * dt, 0, pr.total);
  const at = stairPathAt(path, ns);
  // masuk ke jalur dengan halus kalau masih sedikit meleset
  const snap = pr.dist > 2 ? Math.min(1, dt * 22) : 1;
  e.x += (at.x - e.x) * snap;
  e.y += (at.y - e.y) * snap;
  e.vx = 0; e.moving = true; r.rideSpd = spd;
  const mdir = (at.dir * dir || e.facing) as 1 | -1;
  e.facing = mdir >= 0 ? 1 : -1;
  e.bodyAim = e.facing >= 0 ? 0 : Math.PI;
  if (e.role === 'melee') e.aim = e.bodyAim;

  const remaining = dir > 0 ? pr.total - ns : ns;
  // SALTO TANGGA: front flip / back flip melompati beberapa anak tangga
  if (sr.cd <= 0 && remaining > 30 && snap === 1) {
    const agile = e.elite || e.kind === 'fighter' || e.kind === 'duelist' || e.kind === 'monk' || e.kind === 'knife';
    if (Math.random() < (agile ? 0.75 : 0.4)) {
      const len = Math.min(remaining, 38 + Math.random() * 16);
      const kind: 'front' | 'back' = Math.random() < 0.55 ? 'front' : 'back';
      sr.flip = makeFlip(path, ns, ns + dir * len, kind, mdir, 0.4 + Math.random() * 0.08, 13 + Math.random() * 5);
      e.sqx = 0.8; e.sqy = 1.2;
      g.sfx?.whoosh?.();
      g.particles?.smoke?.(e.x, e.y, 3, '#9a9a9a', 16, 0.25);
      if (Math.random() < 0.35) g.texts?.add?.(e.x, e.y - 24, kind === 'front' ? 'FRONT FLIP!' : 'BACK FLIP!', '#ffb27f', 1, 0.45);
    }
    sr.cd = 0.55 + Math.random() * 0.6;
  }

  const atEnd = dir > 0 ? ns >= pr.total - 0.01 : ns <= 0.01;
  if (atEnd) {
    const wantMore = sr.up ? p.y < e.y - 26 : p.y > e.y + 26;
    const nxt = wantMore ? stairPathFor(l, at.x, at.y, sr.up) : null;
    if (!nxt || sr.life > 14) endRide(g, e);
  }
  // pengaman: perjalanan tangga yang tak wajar lamanya dihentikan
  if (sr.life > 20) endRide(g, e);
}

export function endRide(g: G, e: Enemy) {
  const p = g.player;
  clearRide(e);
  const sup = officeFloorSupportY(g.level, e.x, e.y - 3, e.r, false);
  if (sup !== null && Math.abs(sup - e.y) <= 5) e.y = sup;
  e.svGrounded = true; e.svVy = 0; e.svDropT = 0;
  e.vx = Math.sign(p.x - e.x || e.facing) * e.speed;
  e.moving = true;
}
