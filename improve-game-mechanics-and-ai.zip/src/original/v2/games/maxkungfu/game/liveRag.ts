// RAGDOLL AKTIF untuk musuh yang MASIH HIDUP: saat terangkat, terpental, membentur lantai dan rebah.
// Verlet 11 sendi (kepala, leher, pinggul, siku, tangan, lutut, kaki) dengan gravitasi, momentum, putaran dari pukulan,
// tabrakan lantai + gesekan, dan batas sendi. Pinggul ditarik pegas ke posisi fisika game (jadi gameplay tetap sama),
// sisanya bebas. Di udara ada sedikit "tonus otot" (active ragdoll) supaya tidak seperti tali; saat rebah tubuh lemas total.
import type { Skeleton } from './stick';

type V = { x: number; y: number };
interface RP { x: number; y: number; px: number; py: number; inv: number }

const HEAD = 0, NECK = 1, HIP = 2, FEL = 3, FH = 4, BEL = 5, BH = 6, FKN = 7, FF = 8, BKN = 9, BF = 10;
const BONES: [number, number][] = [[HEAD, NECK], [NECK, HIP], [NECK, FEL], [FEL, FH], [NECK, BEL], [BEL, BH], [HIP, FKN], [FKN, FF], [HIP, BKN], [BKN, BF]];
const GRAV = 920;

export class LiveRag {
  p: RP[] = [];
  len: number[] = [];
  torsoSpan = 0;       // jarak kepala-pinggul (menjaga badan lurus)
  legLen = 0; armLen = 0;
  s = 1;
  w = 0;               // bobot blend ragdoll vs animasi
  lastT = -1;
  private hPrev = 1 / 120;

  /** inisialisasi dari pose animasi saat ini (koordinat absolut layar) */
  init(sk: Skeleton, X: number, Y: number, vx: number, vy: number, s: number) {
    this.s = s;
    const A = (v: V) => ({ x: X + v.x, y: Y + v.y });
    const mid = (a: V, b: V, bend: number) => {
      const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, dx = b.x - a.x, dy = b.y - a.y, l = Math.hypot(dx, dy) || 1;
      return { x: mx - (dy / l) * bend * s, y: my + (dx / l) * bend * s };
    };
    const head = A(sk.head), neck = A(sk.neck), hip = A(sk.hip), fh = A(sk.fhand), bh = A(sk.bhand), ff = A(sk.ffoot), bf = A(sk.bfoot);
    const fel = sk.felbow ? A(sk.felbow) : mid(neck, fh, 1.2), bel = sk.belbow ? A(sk.belbow) : mid(neck, bh, -1.2);
    const fkn = sk.fknee ? A(sk.fknee) : mid(hip, ff, -1.4), bkn = sk.bknee ? A(sk.bknee) : mid(hip, bf, 1.4);
    const pts = [head, neck, hip, fel, fh, bel, bh, fkn, ff, bkn, bf];
    const h = 1 / 120;
    // massa: badan berat, ujung anggota ringan
    const inv = [1.2, 0.7, 0.45, 1.1, 1.5, 1.1, 1.5, 0.9, 1.3, 0.9, 1.3];
    this.p = pts.map((q, i) => ({ x: q.x, y: q.y, px: q.x - vx * h, py: q.y - vy * h, inv: inv[i] }));
    const d = (a: number, b: number) => Math.hypot(pts[a].x - pts[b].x, pts[a].y - pts[b].y);
    // panjang tulang standar stickman (dengan batas bawah supaya pose yang terlipat tidak memendekkan tulang)
    const std: Record<string, number> = { '0-1': 3.4, '1-2': 4.6, '1-3': 2.7, '3-4': 2.7, '1-5': 2.7, '5-6': 2.7, '2-7': 2.9, '7-8': 2.9, '2-9': 2.9, '9-10': 2.9 };
    this.len = BONES.map(([a, b]) => Math.max(std[`${a}-${b}`] * s, Math.min(d(a, b), std[`${a}-${b}`] * s * 1.25)));
    this.torsoSpan = this.len[0] + this.len[1] * 0.98;
    this.legLen = this.len[6] + this.len[7];
    this.armLen = this.len[2] + this.len[3];
    this.hPrev = h;
  }

  /** dorongan pukulan: arah (dx,dy), kekuatan, + putaran (badan berputar mengikuti titik kena) */
  impulse(dx: number, dy: number, power: number, spin: number) {
    if (!this.p.length) return;
    const h = this.hPrev, hip = this.p[HIP];
    const share = [1.0, 0.85, 0.55, 0.9, 1.0, 0.9, 1.0, 0.6, 0.55, 0.6, 0.55];
    for (let i = 0; i < this.p.length; i++) {
      const q = this.p[i];
      const rx = q.x - hip.x, ry = q.y - hip.y;
      const vx = dx * power * share[i] - ry * spin, vy = dy * power * share[i] + rx * spin;
      q.px -= vx * h; q.py -= vy * h;
    }
  }

  /**
   * satu frame simulasi.
   * @param hipT  target pinggul dari fisika game
   * @param pinY  kekuatan tarikan vertikal pinggul (0 saat rebah => jatuh bebas ke lantai)
   * @param floorY lantai (y layar)
   * @param tone  tonus otot 0..1 (0 = lemas total)
   * @param anim  pose animasi (absolut) sebagai arah tonus
   */
  step(dt: number, hipT: V, pinX: number, pinY: number, floorY: number, tone: number, anim: Skeleton | null, AX: number, AY: number, grav = GRAV) {
    if (!this.p.length || !(dt > 0)) return;
    const sub = 3, h = Math.min(dt, 1 / 30) / sub;
    const P = this.p;
    for (let it = 0; it < sub; it++) {
      const k = h / this.hPrev;
      for (const q of P) {
        let vx = (q.x - q.px) * k, vy = (q.y - q.py) * k;
        vx *= 0.996; vy *= 0.996;
        q.px = q.x; q.py = q.y;
        q.x += vx; q.y += vy + grav * h * h;
      }
      this.hPrev = h;
      // pinggul mengikuti posisi gameplay
      const hp = P[HIP];
      hp.x += (hipT.x - hp.x) * pinX;
      if (pinY > 0) hp.y += (hipT.y - hp.y) * pinY;
      // tonus otot: anggota ditarik ringan ke pose animasi dalam kerangka badan saat ini (badan tetap bebas berputar)
      if (tone > 0 && anim) {
        const ah = { x: AX + anim.hip.x, y: AY + anim.hip.y }, an = { x: AX + anim.neck.x, y: AY + anim.neck.y };
        const rot = Math.atan2(P[NECK].y - hp.y, P[NECK].x - hp.x) - Math.atan2(an.y - ah.y, an.x - ah.x);
        const c = Math.cos(rot), sn = Math.sin(rot);
        const tgt = (v: V | null, base: number, fallback: number) => {
          if (!v) return;
          const ox = AX + v.x - ah.x, oy = AY + v.y - ah.y;
          const tx = hp.x + ox * c - oy * sn, ty = hp.y + ox * sn + oy * c;
          const q = P[base];
          q.x += (tx - q.x) * tone * fallback; q.y += (ty - q.y) * tone * fallback;
        };
        tgt(anim.fhand, FH, 1); tgt(anim.bhand, BH, 1); tgt(anim.ffoot, FF, 0.8); tgt(anim.bfoot, BF, 0.8);
        tgt(anim.felbow, FEL, 0.6); tgt(anim.belbow, BEL, 0.6); tgt(anim.fknee, FKN, 0.6); tgt(anim.bknee, BKN, 0.6);
      }
      // constraint
      for (let iter = 0; iter < 6; iter++) {
        for (let b = 0; b < BONES.length; b++) this.dist(BONES[b][0], BONES[b][1], this.len[b], this.len[b], 1);
        this.dist(HEAD, HIP, this.torsoSpan * 0.93, this.torsoSpan, 0.9);          // badan tidak terlipat
        this.dist(HIP, FF, this.legLen * 0.42, this.legLen, 0.6);                 // lutut tidak melipat total
        this.dist(HIP, BF, this.legLen * 0.42, this.legLen, 0.6);
        this.dist(NECK, FH, this.armLen * 0.3, this.armLen, 0.5);
        this.dist(NECK, BH, this.armLen * 0.3, this.armLen, 0.5);
        this.dist(FKN, BKN, 0.6 * this.s, 99, 0.3);
        // lantai: tiap sendi menapak, gesekan meredam geser
        for (let i = 0; i < P.length; i++) {
          const q = P[i], r = i === HEAD ? 2.6 * this.s : 0.9 * this.s;
          if (q.y > floorY - r) {
            q.y = floorY - r;
            const vx = q.x - q.px;
            q.px = q.x - vx * 0.55;                  // gesekan lantai
            if (q.py < q.y) q.py = q.y + (q.y - q.py) * 0.12; // pantulan kecil
          }
        }
      }
    }
    // pengaman: tidak pernah meledak / NaN
    const hp = P[HIP];
    for (const q of P) {
      if (!Number.isFinite(q.x) || !Number.isFinite(q.y)) { q.x = hp.x; q.y = hp.y; q.px = q.x; q.py = q.y; }
      const dx = q.x - hp.x, dy = q.y - hp.y, L = Math.hypot(dx, dy), M = 16 * this.s;
      if (L > M) { q.x = hp.x + (dx / L) * M; q.y = hp.y + (dy / L) * M; q.px = q.x; q.py = q.y; }
    }
  }

  private dist(a: number, b: number, min: number, max: number, stiff: number) {
    const A = this.p[a], B = this.p[b];
    const dx = B.x - A.x, dy = B.y - A.y, L = Math.hypot(dx, dy) || 1e-4;
    const target = L < min ? min : L > max ? max : L;
    if (target === L) return;
    const diff = ((L - target) / L) * stiff, wa = A.inv / (A.inv + B.inv), wb = 1 - wa;
    A.x += dx * diff * wa; A.y += dy * diff * wa;
    B.x -= dx * diff * wb; B.y -= dy * diff * wb;
  }

  /** kerangka relatif terhadap (X, Y), dicampur dengan pose animasi sesuai bobot w */
  skeleton(X: number, Y: number, anim: Skeleton): Skeleton {
    const w = this.w, P = this.p;
    const R = (i: number, a: V | null): V => {
      const rx = P[i].x - X, ry = P[i].y - Y;
      if (!a || w >= 0.999) return { x: rx, y: ry };
      return { x: a.x + (rx - a.x) * w, y: a.y + (ry - a.y) * w };
    };
    return {
      head: R(HEAD, anim.head), neck: R(NECK, anim.neck), hip: R(HIP, anim.hip),
      fhand: R(FH, anim.fhand), bhand: R(BH, anim.bhand), ffoot: R(FF, anim.ffoot), bfoot: R(BF, anim.bfoot),
      felbow: R(FEL, anim.felbow ?? mid(anim.neck, anim.fhand)), belbow: R(BEL, anim.belbow ?? mid(anim.neck, anim.bhand)),
      fknee: R(FKN, anim.fknee ?? mid(anim.hip, anim.ffoot)), bknee: R(BKN, anim.bknee ?? mid(anim.hip, anim.bfoot)),
      trail: null,
    };
  }
}
const mid = (a: V, b: V): V => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
