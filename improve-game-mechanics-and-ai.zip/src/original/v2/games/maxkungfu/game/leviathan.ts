import { drawAxe, AXE_LEN } from './weapons';
import { pcircle, pline, pring, prect, px, type Ctx } from './pixel';
import type { Enemy, Pose, Vec } from './types';
import type { Move } from './moves';
import type { Game } from './game';

/**
 * LEVIATHAN — Kratos / viking axe.
 *
 *  LMB              the existing brutal melee chain (swing / backhand / home run).
 *  RMB  idle/walk   THROW: the axe flies spinning at the cursor (aim-assist), punches through enemies,
 *                   then RETURNS on a curved path and SNAPS back into the hand.
 *                   RMB again while it's out = recall early. The return also hits.
 *  RMB  on return   KICK-BACK: while the axe is flying home, RMB commits to a kick. The wind-up is welded
 *                   to the axe's arrival, so the foot always meets the steel and boots it straight back at
 *                   the nearest enemy (Avatar-style: stomp, pebbles lift, kick). The rebound flies faster,
 *                   hits harder, homes a little and RICOCHETS between enemies. When it comes home again you
 *                   can kick it again: every link of the RALLY is a new stunt and a stronger axe.
 *                   Pressing late (the axe almost in your hand) is a PERFECT KICK.
 *  SHIFT + RMB      LEAP SMASH: cancel the dash, jump, then bring the axe down from above.
 *                   Shockwave, freeze-frame, frost burst. If the axe was already flying it races
 *                   back so you catch it in the air and slam with it.
 */
const mk = (o: Partial<Move> & { id: string; name: string; dmg: number }): Move => ({
  pose: 'idle', structure: o.dmg * 5, range: 40, arc: 2, windup: 0, active: 0, recover: 0, kb: 420, knockdown: true, lunge: 0,
  hitstop: 0.08, shake: 0.5, sfx: 'axe', limb: 'blade', hitR: 6, bleed: true, ...o,
});
const M_THROW = mk({ id: 'a_throw', name: 'LEVIATHAN', dmg: 11, kb: 480, hitstop: 0.07, shake: 0.45 });
const M_RETURN = mk({ id: 'a_return', name: 'RECALL', dmg: 7, kb: 320, hitstop: 0.04, shake: 0.3 });
const M_SMASH = mk({ id: 'a_leapsmash', name: 'LEAP SMASH', dmg: 18, kb: 520, launch: 80, hitstop: 0.14, shake: 1.1, finisher: true });

/** every link of the rally is a different stunt */
const KICK_STUNTS: { pose: Pose; name: string }[] = [
  { pose: 'roundhouse', name: 'ROUNDHOUSE' },
  { pose: 'dragontail', name: 'DRAGON TAIL' },
  { pose: 'sidekick', name: 'FLYING SIDE KICK' },
  { pose: 'cranekick', name: 'CRANE KICK' },
  { pose: 'axekick', name: 'AXE KICK' },
];
/** seconds from the start of the throw until the axe leaves the hand / until the body has fully recovered */
const THROW_RELEASE = 0.17, THROW_END = 0.52;
/** seconds before arrival: committing this late is a PERFECT KICK */
const PERFECT_ETA = 0.16;
const FIRE = ['#ffb347', '#fff3c4', '#ff7a3d'];
const ROCK = ['#8a7a66', '#6b5d4d', '#b0a08a', '#4f453a'];

const angDiff = (a: number, b: number) => { let d = a - b; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; };
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
function segDist(ax: number, ay: number, bx: number, by: number, cx: number, cy: number) {
  const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy;
  const t = l > 0 ? cl(((cx - ax) * dx + (cy - ay) * dy) / l) : 0;
  return Math.hypot(ax + dx * t - cx, ay + dy * t - cy);
}

type Mode = 'held' | 'windup' | 'fly' | 'return' | 'leap' | 'kicked';
interface Chunk { x: number; y: number; gy: number; vx: number; vy: number; life: number; s: number; c: string }

export class Leviathan {
  mode: Mode = 'held';
  x = 0; y = 0; vx = 0; vy = 0;
  spin = 0;
  lift = 0;
  ang = 0;
  /** true when the axe is in the player's hands (so the regular drawAxe path can run) */
  held = true;
  bodyPose: Pose | null = null;
  bodyT = 0;
  /** KICK-BACK body pose. Unlike bodyPose it wins over running / attacking (see Game.drawPlayer). */
  kickPose: Pose | null = null;
  kickPoseT = 0;
  /** consecutive kick-backs without catching the axe */
  rally = 0;
  /** index into KICK_STUNTS of the kick being loaded: the wind-up pose (a_kickwind) chambers differently per stunt */
  stunt = 0;
  /** while the throw winds up the axe is cocked behind the head, then whips over the top (null = default carry angle) */
  axeAngle: number | null = null;
  private throwT = -1;
  /** best rally of this life (HUD brag) */
  bestRally = 0;
  private t = 0;
  private windT = 0;
  private flyT = 0;
  private maxFly = 0.42;
  private hit = new Set<number>();
  private trail: { x: number; y: number; a: number; t: number }[] = [];
  private catchFlash = 0;
  private leaping = false;
  private smashed = false;
  private aim = 0;
  // ---- kick-back state ----
  private kickArmed = false;
  private kickD0 = 1;
  private kickPerfect = false;
  private kickFollow = -1;
  private kickIdx = -1;
  private kickDir = 0;
  private kickFlash = 0;
  private kickMove: Move = M_THROW;
  private bounces = 0;
  private targetId = -1;
  private retD = 999;
  private retSp = 1;
  private hints = 0;
  /** wall-clock time of the last RMB pressed while the axe was coming home (input buffer for the kick) */
  private kickBufAt = -1e9;
  /** LEFT CLICK while the axe is in the air: the kick is queued and fires by itself when the axe comes home */
  private kickQueued = false;
  /** grace window after a catch: a click that came a hair too late still boots the axe straight back out */
  private lateT = 0;
  private lateRally = 0;
  private debris: Chunk[] = [];

  reset() {
    this.mode = 'held'; this.held = true; this.bodyPose = null; this.leaping = false; this.smashed = false;
    this.trail.length = 0; this.hit.clear(); this.catchFlash = 0;
    this.kickArmed = false; this.kickPose = null; this.kickFollow = -1; this.kickFlash = 0;
    this.rally = 0; this.bounces = 0; this.targetId = -1; this.debris.length = 0;
    this.throwT = -1; this.axeAngle = null; this.kickQueued = false; this.lateT = 0;
  }

  /** true while the axe is flying home and a kick can still be committed */
  get kickable() { return this.mode === 'return' && !this.kickArmed; }
  /** a left-click kick is queued and waiting for the axe (HUD) */
  get queued() { return this.kickQueued && this.mode !== 'held'; }
  /** the left mouse button belongs to the kick right now: the game must not start a punch / melee swing with it */
  get ownsClick() { return this.mode === 'return' || this.kickArmed || this.kickFollow >= 0 || this.lateT > 0; }

  update(g: Game, dt: number) {
    const p = g.player, m = g.input.mouse;
    // LEFT CLICK = KICK-BACK. One click at ANY time while the axe is in the air is enough: the kick is queued and fires by
    // itself when the axe comes home (no timing, no holding). Presses on frozen frames (hit-stop) are remembered too.
    if (m.pressed && (this.mode === 'fly' || this.mode === 'kicked' || this.mode === 'return') && !this.kickArmed) this.kickQueued = true;
    if (m.rpressed && this.mode === 'return' && !this.kickArmed) this.kickBufAt = performance.now();
    if (dt <= 0) return;
    this.t += dt;
    if (this.catchFlash > 0) this.catchFlash -= dt;
    if (this.kickFlash > 0) this.kickFlash -= dt;
    this.bodyPose = null; this.bodyT = 0;
    while (this.trail.length && this.t - this.trail[0].t > 0.22) this.trail.shift();
    this.updateDebris(dt);

    const interrupted = p.stunT > 0 || p.holdT > 0 || !!p.focusDash || p.rageDash || g.state !== 'playing' || !!p.fatality;
    if (interrupted) {
      this.kickArmed = false; this.kickPose = null; this.kickFollow = -1; this.throwT = -1; this.axeAngle = null;
      if (this.mode !== 'held' && this.mode !== 'leap') this.startReturn(g);
      if (this.mode === 'leap' && interrupted) { this.mode = 'held'; this.held = true; this.leaping = false; }
    }

    const shifting = p.dashT > 0 || p.sinceDash < 0.22 || g.input.keys.has('shift');
    const kickBuffered = performance.now() - this.kickBufAt < 280;
    if (this.lateT > 0) this.lateT -= dt;
    if (!interrupted && this.mode === 'return' && !this.leaping) {
      // the kick owns the buttons while the axe is on its way home: a queued left click, a held left button or a right click
      if (!this.kickArmed && (this.kickQueued || m.down || m.rpressed || kickBuffered)) { this.kickBufAt = -1e9; this.kickQueued = false; this.armKick(g); }
    } else if (!interrupted && this.mode === 'held' && this.lateT > 0 && m.pressed) {
      this.lateKick(g);
    } else if (!interrupted && m.rpressed) {
      if (shifting && !p.airborne && (this.mode === 'held' || this.mode === 'fly' || this.mode === 'kicked')) this.startLeap(g);
      else if (this.mode === 'held' && !this.leaping) this.startThrow(g);
      else if (this.mode === 'fly' || this.mode === 'kicked') this.startReturn(g);
    }

    switch (this.mode) {
      case 'held': {
        break;
      }
      case 'windup': {
        // tomahawk wind-up: the body coils first (axe cocked back behind the head), then the whip starts and the axe
        // leaves the hand halfway through it
        this.windT += dt;
        this.throwT = this.windT;
        const cock = cl(this.windT / 0.12), whip = cl((this.windT - 0.12) / (THROW_RELEASE - 0.12));
        this.axeAngle = this.aim + Math.PI + p.facing * (0.9 - 0.75 * cock + 1.4 * whip);
        this.held = true;
        p.aim = this.aim; p.facing = Math.cos(this.aim) >= 0 ? 1 : -1;
        if (this.windT >= THROW_RELEASE) this.release(g);
        break;
      }
      case 'fly': {
        this.flyT += dt;
        this.held = false;
        const x0 = this.x, y0 = this.y;
        this.x += this.vx * dt; this.y += this.vy * dt;
        this.spin += 18 * dt;
        this.ang = this.spin;
        this.lift = Math.max(0, this.lift - 40 * dt);
        this.hits(g, x0, y0, M_THROW, 0.18);
        this.trail.push({ x: this.x, y: this.y - this.lift, a: this.ang, t: this.t });
        this.frost(g, this.x, this.y - this.lift, 0.5);
        if (!g.isFree(this.x, this.y + 6, 2)) {
          this.x = x0; this.y = y0;
          g.particles.spark(this.x, this.y, 8, '#bfe8ff', this.ang + Math.PI, 1.2, 180);
          g.sfx.ricochet();
          this.startReturn(g);
          break;
        }
        if (this.flyT >= this.maxFly) this.startReturn(g);
        break;
      }
      case 'kicked': {
        // the rebound: faster, hotter, and it bends toward its victim so a good kick is never wasted
        this.flyT += dt;
        this.held = false;
        const sp = Math.hypot(this.vx, this.vy) || 1;
        const tg = this.victim(g);
        if (tg) {
          const want = Math.atan2(tg.y - tg.z - 6 - this.y, tg.x - this.x), cur = Math.atan2(this.vy, this.vx);
          const na = cur + cl(angDiff(want, cur), -9 * dt, 9 * dt);
          this.vx = Math.cos(na) * sp; this.vy = Math.sin(na) * sp;
        }
        const x0 = this.x, y0 = this.y;
        this.x += this.vx * dt; this.y += this.vy * dt;
        this.spin += 30 * dt;
        this.ang = this.spin;
        this.lift = 0;
        this.hits(g, x0, y0, this.kickMove, 0.18);
        this.trail.push({ x: this.x, y: this.y, a: this.ang, t: this.t });
        this.embers(g, this.x, this.y, 0.9);
        if (!g.isFree(this.x, this.y + 6, 2)) {
          this.x = x0; this.y = y0;
          g.particles.spark(this.x, this.y, 10, '#ffd27f', this.ang + Math.PI, 1.2, 200);
          g.sfx.ricochet();
          g.shake(0.25);
          this.startReturn(g);
          break;
        }
        if (this.flyT >= this.maxFly) this.startReturn(g);
        break;
      }
      case 'return': {
        this.held = false;
        const goal = this.kickArmed ? this.kickPoint(g) : this.hand(g);
        const x0 = this.x, y0 = this.y;
        const dx = goal.x - this.x, dy = goal.y - this.y, d = Math.hypot(dx, dy);
        const sp = Math.min(980, 420 + this.flyT * 1400);
        this.flyT += dt;
        this.retD = d; this.retSp = sp;
        if (this.kickArmed) {
          // wind-up welded to the arrival: 0 .. 0.3 of the strike pose is the chamber, the snap happens on contact
          // the wind-up (root -> load -> chamber) is welded to the axe's arrival: it is fully chambered on contact
          this.kickPose = 'a_kickwind'; this.kickPoseT = 1 - cl(d / this.kickD0);
          p.aim = this.kickDir; p.facing = Math.cos(this.kickDir) >= 0 ? 1 : -1;
          if (d < 12 + sp * dt) { this.kickImpact(g); break; }
        } else if (d < 10 + sp * dt) { this.catch(g); break; }
        this.vx = (dx / d) * sp; this.vy = (dy / d) * sp;
        this.x += this.vx * dt; this.y += this.vy * dt;
        this.spin += 22 * dt;
        this.ang = this.spin;
        this.lift = this.kickArmed ? 0 : Math.sin(cl(d / 80) * Math.PI) * 8;
        this.hits(g, x0, y0, M_RETURN, 0.16);
        this.trail.push({ x: this.x, y: this.y - this.lift, a: this.ang, t: this.t });
        if (this.rally > 0) this.embers(g, this.x, this.y - this.lift, 0.4); else this.frost(g, this.x, this.y - this.lift, 0.35);
        break;
      }
      case 'leap': {
        this.leaping = true;
        p.dashT = 0;
        // hop is driven by the game's jump physics; we just keep the pose and watch for landing
        const up = p.vz > 0;
        this.bodyPose = 'a_leap';
        this.bodyT = up ? cl(0.15 + 0.35 * (1 - p.vz / 340)) : (p.z > 8 ? 0.45 : 0.55 + 0.4 * (1 - p.z / 18));
        this.aim = p.aim;
        if (!p.airborne && this.t > 0.12 && !this.smashed) this.smash(g);
        break;
      }
    }

    // throw: the pose timeline keeps running after the axe has left the hand (whip, follow-through, recovery)
    if (this.throwT >= 0 && !this.kickArmed && this.kickFollow < 0) {
      if (this.mode !== 'windup') this.throwT += dt;
      this.kickPose = 'a_throw'; this.kickPoseT = this.throwPoseT(this.throwT);
      if (this.throwT < 0.3) { p.aim = this.aim; p.facing = Math.cos(this.aim) >= 0 ? 1 : -1; }
      if (this.throwT >= THROW_END) { this.throwT = -1; this.kickPose = null; }
    }

    // follow-through of the kick: snap to full extension, hold a beat, then recover
    if (this.kickFollow >= 0) {
      this.kickFollow += dt;
      const u = this.kickFollow;
      this.kickPoseT = u < 0.05 ? 0.3 + 0.12 * (u / 0.05) : 0.42 + 0.58 * cl((u - 0.05) / 0.3);
      p.aim = this.kickDir; p.facing = Math.cos(this.kickDir) >= 0 ? 1 : -1;
      if (u >= 0.35) { this.kickFollow = -1; this.kickPose = null; }
    }

    // if leaping, keep recalling the axe into the hand
    if (this.leaping && !this.held && this.mode === 'leap') {
      // pull the flying axe in while we jump
      const hand = this.hand(g);
      const dx = hand.x - this.x, dy = hand.y - this.y, d = Math.hypot(dx, dy);
      if (d < 14) { this.held = true; this.catchFlash = 0.12; }
      else {
        const sp = 1100;
        this.x += (dx / d) * sp * dt; this.y += (dy / d) * sp * dt;
        this.spin += 24 * dt; this.ang = this.spin;
        this.trail.push({ x: this.x, y: this.y, a: this.ang, t: this.t });
      }
    }
  }

  /** throw timeline (seconds since the wind-up began) -> a_throw pose time */
  private throwPoseT(time: number) {
    if (time < 0.12) { const u = time / 0.12; return 0.44 * (1 - (1 - u) * (1 - u)); } // wind-up eases into the cocked pose
    if (time < 0.22) return 0.44 + 0.22 * ((time - 0.12) / 0.1);                       // whip: the axe leaves the hand at THROW_RELEASE
    return 0.66 + 0.34 * cl((time - 0.22) / (THROW_END - 0.22));                        // follow-through and recovery
  }

  private hand(g: Game): Vec {
    const p = g.player;
    return { x: p.x + p.facing * 6, y: p.y - 8 - p.z };
  }

  /** where the boot meets the axe: shin height, a step out along the kick */
  private kickPoint(g: Game): Vec {
    const p = g.player;
    return { x: p.x + Math.cos(this.kickDir) * 9, y: p.y - 6 - p.z + Math.sin(this.kickDir) * 4 };
  }

  private victim(g: Game): Enemy | null {
    if (this.targetId < 0) return null;
    for (const e of g.enemies) if (e.id === this.targetId) return e.dead || e.spawnT > 0 || this.hit.has(e.id) ? null : e;
    return null;
  }

  private aimAt(g: Game): number {
    const p = g.player, mw = g.mouseWorld();
    let ang = Math.atan2(mw.y - (p.y - 6), mw.x - p.x);
    let best: Enemy | null = null, bs = Infinity;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d > 170) continue;
      const da = Math.abs(angDiff(Math.atan2(e.y - 6 - (p.y - 6), e.x - p.x), ang));
      if (da > 0.7) continue;
      const sc = da * 80 + d * 0.25;
      if (sc < bs) { bs = sc; best = e; }
    }
    if (best) ang = Math.atan2(best.y - 6 - (p.y - 6), best.x - p.x);
    return ang;
  }

  /** The rebound goes for the NEAREST enemy (the cursor only breaks ties). No enemy = it follows the cursor. */
  private kickAim(g: Game): number {
    const p = g.player, mw = g.mouseWorld(), side = !!g.level.sideView;
    const mouseA = Math.atan2(mw.y - (p.y - 6), mw.x - p.x);
    let best: Enemy | null = null, bs = Infinity;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d > 300 || (side && Math.abs(e.y - p.y) > 26)) continue;
      const da = Math.abs(angDiff(Math.atan2(e.y - p.y, e.x - p.x), mouseA));
      const sc = d + da * 70;
      if (sc < bs) { bs = sc; best = e; }
    }
    this.targetId = best ? best.id : -1;
    if (best) return Math.atan2(best.y - best.z - 6 - (p.y - 6 - p.z), best.x - p.x);
    return side ? (Math.cos(mouseA) >= 0 ? 0 : Math.PI) : mouseA;
  }

  private startThrow(g: Game) {
    const p = g.player;
    this.aim = this.aimAt(g);
    this.mode = 'windup'; this.windT = 0; this.held = true;
    this.throwT = 0; this.kickFollow = -1; this.kickQueued = false; this.lateT = 0;
    p.attackPhase = 'none'; p.buffered = null; // the throw owns the body
    p.facing = Math.cos(this.aim) >= 0 ? 1 : -1;
    p.aim = this.aim;
    p.kx += Math.cos(this.aim) * 40; p.ky += Math.sin(this.aim) * 36;
    g.sfx.whoosh();
    g.texts.add(p.x, p.y - 26, 'THROW', '#bfe8ff', 1, 0.45);
  }

  private release(g: Game) {
    const p = g.player;
    const hand = this.hand(g);
    this.x = hand.x; this.y = hand.y; this.lift = 2;
    const sp = 620;
    this.vx = Math.cos(this.aim) * sp; this.vy = Math.sin(this.aim) * sp;
    this.mode = 'fly'; this.flyT = 0; this.maxFly = 0.38; this.held = false;
    this.hit.clear(); this.spin = this.aim; this.targetId = -1;
    this.axeAngle = null;
    if (!p.airborne) g.particles.smoke(p.x + Math.cos(this.aim) * 7, p.y, 3, '#9a8f7d', 30, 0.3); // the lead foot stamps down
    g.sfx.axeSwing();
    g.sfx.whoosh();
    g.particles.dirBurst(hand.x, hand.y, 8, '#bfe8ff', this.aim, 0.5, 140, 0.3);
    g.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: this.aim, scale: 1 }, '#bfe8ff', { x: Math.cos(this.aim), y: Math.sin(this.aim) });
  }

  private startReturn(g: Game) {
    if (this.mode === 'held') return;
    const fresh = this.mode !== 'return';
    this.mode = 'return'; this.flyT = 0; this.hit.clear(); this.held = false; this.targetId = -1;
    this.retD = 999; this.retSp = 420;
    g.sfx.whoosh();
    // teach the kick the first few times the axe comes home
    if (fresh && this.hints < 5 && g.state === 'playing') {
      this.hints++;
      const p = g.player;
      g.texts.add(p.x, p.y - 32 - p.z, 'KLIK KIRI : TENDANG!', '#ffd27f', 1, 0.6);
    }
  }

  private catch(g: Game) {
    const p = g.player;
    this.mode = 'held'; this.held = true; this.lift = 0; this.trail.length = 0;
    this.catchFlash = 0.18;
    p.squash = Math.min(p.squash, 0.88); p.kx -= p.facing * 26; // the catch rocks the body back
    g.sfx.axeHit(false);
    g.sfx.batCrack();
    g.hitstop = Math.max(g.hitstop, 0.06);
    g.shake(0.25);
    g.particles.ring(p.x + p.facing * 6, p.y - 8 - p.z, 3, 14, '#bfe8ff', 0.2, 1);
    g.particles.burst(p.x + p.facing * 6, p.y - 8, 8, '#ffffff', 90, 0.3);
    if (this.rally >= 2) g.texts.add(p.x, p.y - 24, `RALLY x${this.rally} - CATCH`, '#ffd27f', 1, 0.6);
    else g.texts.add(p.x, p.y - 24, 'CATCH', '#ffffff', 1, 0.35);
    this.lateT = 0.2; this.lateRally = this.rally; this.kickQueued = false;
    this.rally = 0; this.bounces = 0; this.targetId = -1; this.kickBufAt = -1e9;
  }

  // ------------------------------------------------------------------ KICK-BACK
  /** A click a hair too late (the axe is already in the hand) still counts: the axe is booted straight out of the catch. */
  private lateKick(g: Game) {
    const h = this.hand(g);
    this.lateT = 0; this.rally = this.lateRally;
    this.mode = 'return'; this.held = false; this.x = h.x; this.y = h.y; this.flyT = 0.3;
    this.armKick(g);
    this.kickPerfect = false;
    this.kickImpact(g);
  }

  /** The axe is flying home and a kick was asked for (queued left click, held button or right click): plant the foot, read the target, start the stunt. */
  private armKick(g: Game) {
    const p = g.player;
    this.kickDir = this.kickAim(g);
    const kp = this.kickPoint(g);
    const d = Math.hypot(kp.x - this.x, kp.y - this.y);
    const eta = d / Math.max(1, Math.min(980, 420 + this.flyT * 1400));
    this.kickArmed = true;
    this.kickD0 = Math.max(24, d);
    this.kickPerfect = eta <= PERFECT_ETA;
    this.kickIdx = (this.kickIdx + 1) % KICK_STUNTS.length;
    this.stunt = this.kickIdx; this.throwT = -1;
    this.kickPose = 'a_kickwind'; this.kickPoseT = 0; this.kickFollow = -1;
    // the stunt takes over the body: drop whatever the fists were doing
    p.attackPhase = 'none'; p.buffered = null; p.dashT = 0;
    p.aim = this.kickDir; p.facing = Math.cos(this.kickDir) >= 0 ? 1 : -1;
    // earthbender stomp: dust puffs out and pebbles lift off the floor before the kick
    p.squash = 0.82;
    g.slow(0.1, 0.6); // a held breath: the wind-up reads even when the kick is committed late
    g.sfx.whoosh();
    g.particles.smoke(p.x, p.y, 5, '#9a8f7d', 34, 0.35);
    g.particles.ring(p.x, p.y - 1, 2, 12, '#d9c8a8', 0.16, 1);
    this.rocks(p.x, p.y, 5, -Math.PI / 2, 1.5, 70);
  }

  /** The boot meets the steel. */
  private kickImpact(g: Game) {
    const p = g.player;
    this.kickDir = this.kickAim(g); // enemies moved during the wind-up: re-read the target on contact
    const dir = this.kickDir, c = Math.cos(dir), s = Math.sin(dir);
    const kp = this.kickPoint(g);
    const perfect = this.kickPerfect;
    this.rally++;
    this.bestRally = Math.max(this.bestRally, this.rally);
    const r = Math.min(this.rally, 6);
    const sp = Math.min(1080, 720 + 60 * r) * (perfect ? 1.08 : 1);
    this.x = kp.x; this.y = kp.y; this.lift = 0;
    this.vx = c * sp; this.vy = s * sp;
    this.mode = 'kicked'; this.flyT = 0; this.maxFly = 0.46 + 0.02 * r; this.held = false;
    this.hit.clear(); this.spin = dir;
    this.bounces = Math.min(5, r + (perfect ? 1 : 0));
    this.kickMove = mk({ id: 'a_kickback', name: 'KICK BACK', dmg: (12 + 3 * r) * (perfect ? 1.35 : 1), kb: 520 + 20 * r, hitstop: 0.08, shake: 0.55 });
    this.kickArmed = false; this.kickFollow = 0; this.kickFlash = 0.22;
    this.kickPose = KICK_STUNTS[this.kickIdx].pose; this.kickPoseT = 0.3;
    p.aim = dir; p.facing = c >= 0 ? 1 : -1;
    p.kx -= c * 46; p.ky -= s * 30;
    p.iframes = Math.max(p.iframes, 0.18);

    const hot = perfect ? '#fff3c4' : '#ffb347';
    g.hitstop = Math.max(g.hitstop, perfect ? 0.13 : 0.085);
    g.slow(perfect ? 0.34 : 0.2, perfect ? 0.22 : 0.42);
    g.shake(perfect ? 0.95 : 0.6);
    g.flash(hot, perfect ? 0.2 : 0.1);
    g.sfx.batCrack(); g.sfx.axeHit(true); g.sfx.whoosh();
    if (perfect || r >= 3) g.sfx.slam();
    g.particles.shockwave(kp.x, kp.y, perfect ? 34 : 24, hot, 0.3);
    g.particles.ring(kp.x, kp.y, 3, 16 + r * 2, '#ffffff', 0.2, 1);
    g.particles.dirBurst(kp.x, kp.y, 12 + r * 2, '#ffd27f', dir, 0.5, 260, 0.35);
    g.particles.spark(kp.x, kp.y, 10, '#ffffff', dir, 0.9, 240);
    g.particles.smoke(p.x, p.y, 6, '#9a8f7d', 46, 0.45);
    this.rocks(p.x - c * 3, p.y, 7 + r, dir + Math.PI, 1.4, 120);
    g.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: dir, pose: KICK_STUNTS[this.kickIdx].pose, poseT: 0.42 }, hot, { x: c, y: s });
    g.texts.add(p.x, p.y - 28 - p.z, perfect ? 'PERFECT KICK!' : KICK_STUNTS[this.kickIdx].name, hot, 1, 0.6);
    if (this.rally >= 2) g.say(this.rally >= 5 ? `AVATAR RALLY x${this.rally}` : `RALLY x${this.rally}`, this.rally >= 5 ? '#ff7a3d' : '#ffd27f', 2, 0.7);
    p.focus = Math.min(300, p.focus + (perfect ? 10 : 5) * g.stats.focusGain);

    // the boot itself clears whoever stands right in front of it
    const boot = mk({ id: 'a_boot', name: 'BOOT', dmg: 5, kb: 440, hitstop: 0.04, shake: 0.3, bleed: false });
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const ex = e.x - p.x, ey = e.y - p.y;
      if (Math.hypot(ex, ey) > 22 + e.r || ex * c + ey * s < 0) continue;
      g.meleeHitEnemy(e, boot, Math.atan2(ey, ex), { x: e.x, y: e.y - e.z - 5 });
    }
  }

  /** after a rebound hit: jump to the next enemy while bounces remain */
  private ricochet(g: Game, from: Enemy) {
    const fy = from.y - from.z - 6;
    g.particles.ring(from.x, fy, 2, 12, '#ffd27f', 0.18, 1);
    if (this.bounces <= 0) { this.targetId = -1; return; }
    const side = !!g.level.sideView;
    let best: Enemy | null = null, bd = Infinity;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0 || this.hit.has(e.id)) continue;
      const d = Math.hypot(e.x - this.x, e.y - this.y);
      if (d > 210 || (side && Math.abs(e.y - from.y) > 26)) continue;
      if (d < bd) { bd = d; best = e; }
    }
    if (!best) { this.targetId = -1; return; }
    this.bounces--;
    this.targetId = best.id;
    const sp = Math.hypot(this.vx, this.vy) || 720, a = Math.atan2(best.y - best.z - 6 - this.y, best.x - this.x);
    this.vx = Math.cos(a) * sp; this.vy = Math.sin(a) * sp;
    this.flyT = Math.max(0, this.flyT - 0.16);
    g.sfx.ricochet();
    g.particles.spark(this.x, this.y, 8, '#ffffff', a, 0.8, 220);
    g.texts.add(from.x, from.y - 26, 'RICOCHET', '#ffd27f', 1, 0.4);
  }

  private startLeap(g: Game) {
    const p = g.player;
    // if the axe is out, yank it home so we slam WITH it
    if (!this.held) { this.mode = 'leap'; this.leaping = true; this.smashed = false; }
    else this.mode = 'leap';
    this.leaping = true; this.smashed = false; this.t = 0;
    this.kickArmed = false; this.kickPose = null; this.kickFollow = -1; this.rally = 0;
    this.throwT = -1; this.axeAngle = null;
    p.dashT = 0; p.vx *= 0.3; p.vy *= 0.3;
    p.airborne = true; p.vz = 340; p.z = 0.1; p.iframes = Math.max(p.iframes, 0.45);
    p.attackPhase = 'none'; p.buffered = null;
    this.aim = this.aimAt(g);
    p.aim = this.aim; p.facing = Math.cos(this.aim) >= 0 ? 1 : -1;
    g.sfx.whoosh(); g.sfx.dash();
    g.texts.add(p.x, p.y - 28, 'LEAP SMASH', '#ffb347', 1, 0.55);
    g.particles.smoke(p.x, p.y, 8, '#9a8f7d', 40, 0.4);
    g.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: this.aim, scale: 1 }, '#ffb347', { x: Math.cos(this.aim), y: Math.sin(this.aim) });
  }

  private smash(g: Game) {
    const p = g.player;
    this.smashed = true; this.leaping = false; this.mode = 'held'; this.held = true;
    p.z = 0; p.vz = 0; p.airborne = false; p.landT = 0.16; p.squash = 0.62;
    const ix = p.x + Math.cos(this.aim) * 16, iy = p.y + Math.sin(this.aim) * 10;
    g.flash('#ffffff', 0.18); g.slow(0.28, 0.22); g.shake(0.85);
    g.hitstop = Math.max(g.hitstop, 0.1);
    g.sfx.slam(); g.sfx.axeHit(true); g.sfx.batCrack();
    g.particles.shockwave(ix, iy - 2, 36, '#ffb347', 0.35);
    g.particles.burst(ix, iy - 2, 16, '#ffffff', 160, 0.45);
    g.particles.smoke(ix, iy, 10, '#9a8f7d', 50, 0.5);
    this.frost(g, ix, iy, 8);
    this.rocks(ix, iy, 10, -Math.PI / 2, 2.4, 130);
    g.say('CRUSH', '#ffb347', 2, 0.7);
    const mv = M_SMASH;
    let n = 0;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      if (Math.hypot(e.x - ix, e.y - iy) > 38 + e.r) continue;
      g.meleeHitEnemy(e, mv, Math.atan2(e.y - p.y, e.x - p.x), { x: e.x, y: e.y - e.z - 5 });
      n++;
    }
    g.shockwaveHit(ix, iy, 34, 6 * g.stats.meleeDmg, -1);
    if (n > 0) g.addCombo(n);
    p.focus = Math.min(300, p.focus + 8 * n * g.stats.focusGain);
  }

  private hits(g: Game, x0: number, y0: number, mv: Move, cd: number) {
    const p = g.player;
    const ax = this.x, ay = this.y - this.lift;
    const kicked = this.mode === 'kicked';
    let struck: Enemy | null = null;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      if (this.hit.has(e.id)) continue;
      const ey = e.y - e.z - 6;
      if (segDist(x0, y0, ax, ay, e.x, ey) > e.r + (kicked ? 9 : 7)) continue;
      this.hit.add(e.id);
      // a kicked axe throws its victim along its own flight, not away from the player
      g.meleeHitEnemy(e, mv, kicked ? Math.atan2(this.vy, this.vx) : Math.atan2(e.y - p.y, e.x - p.x), { x: e.x, y: ey });
      g.particles.spark(e.x, ey, 8, kicked ? '#ffd27f' : '#bfe8ff', this.ang, 1.1, 200);
      if (kicked) { this.embers(g, e.x, ey, 4); struck = e; } else this.frost(g, e.x, ey, 3);
      // a tiny freeze on the victim — the Leviathan "frosted" beat
      e.stun = Math.max(e.stun, kicked ? 0.25 : 0.12);
      void cd;
    }
    for (const pr of g.props) {
      if (pr.dead) continue;
      if (segDist(x0, y0, ax, ay, pr.x, pr.y - 4) > 7 + pr.r) continue;
      g.damageProp(pr, kicked ? 6 : 3, Math.atan2(pr.y - p.y, pr.x - p.x));
    }
    for (const b of g.bullets) {
      if (b.owner !== 'enemy' || b.kind === 'bomb') continue;
      if (segDist(x0, y0, ax, ay, b.x, b.y) > 8) continue;
      g.deflectBullet(b, this.ang);
    }
    if (struck && this.mode === 'kicked') {
      g.addCombo(1);
      this.ricochet(g, struck);
    }
  }

  private frost(g: Game, x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, sp = 18 + Math.random() * 50;
      g.particles.add({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.6 - 10, life: 0.28 + Math.random() * 0.2, c: Math.random() < 0.5 ? '#bfe8ff' : '#ffffff', k: 0, s: 1 });
    }
  }

  /** the kicked axe burns: sparks shed off the blade (fractional n = chance per frame) */
  private embers(g: Game, x: number, y: number, n: number) {
    const count = Math.floor(n) + (Math.random() < n % 1 ? 1 : 0);
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2, sp = 14 + Math.random() * 46;
      g.particles.add({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp * 0.6 - 16, life: 0.24 + Math.random() * 0.24, c: FIRE[(Math.random() * FIRE.length) | 0], k: 0, s: 1 });
    }
  }

  /** earth chunks torn off the floor by the stomp / kick (drawn by this module, they bounce once) */
  private rocks(x: number, y: number, n: number, dir: number, spread: number, power: number) {
    for (let i = 0; i < n; i++) {
      const a = dir + (Math.random() - 0.5) * spread, sp = power * (0.5 + Math.random() * 0.8);
      this.debris.push({
        x: x + (Math.random() - 0.5) * 8, y: y - 1, gy: y,
        vx: Math.cos(a) * sp * 0.7, vy: -Math.abs(Math.sin(a)) * sp - 30 - Math.random() * 50,
        life: 0.55 + Math.random() * 0.35, s: Math.random() < 0.35 ? 2 : 1, c: ROCK[(Math.random() * ROCK.length) | 0],
      });
    }
    if (this.debris.length > 90) this.debris.splice(0, this.debris.length - 90);
  }

  private updateDebris(dt: number) {
    for (let i = this.debris.length - 1; i >= 0; i--) {
      const d = this.debris[i];
      d.vy += 520 * dt; d.x += d.vx * dt; d.y += d.vy * dt; d.life -= dt;
      if (d.y > d.gy && d.vy > 0) { d.y = d.gy; d.vy *= -0.35; d.vx *= 0.6; }
      if (d.life <= 0) this.debris.splice(i, 1);
    }
  }

  /** flying axe + recall trail + kick prompt. Hand-held axe is drawn by game.ts when `held`. */
  draw(ctx: Ctx, g: Game) {
    const p = g.player;
    for (const d of this.debris) {
      ctx.globalAlpha = Math.min(1, d.life / 0.25);
      prect(ctx, Math.round(d.x), Math.round(d.y) - d.s, d.s, d.s, d.c);
    }
    ctx.globalAlpha = 1;
    if (this.catchFlash > 0) {
      ctx.globalAlpha = this.catchFlash / 0.18 * 0.5;
      pring(ctx, p.x + p.facing * 6, p.y - 8 - p.z, 10, '#ffffff', 1);
      ctx.globalAlpha = 1;
    }
    if (this.kickFlash > 0) {
      // impact star where the boot met the axe
      const k = cl(this.kickFlash / 0.22), kp = this.kickPoint(g);
      ctx.globalAlpha = k * 0.8;
      pring(ctx, kp.x, kp.y, 5 + (1 - k) * 20, '#fff3c4', 1);
      for (let i = 0; i < 4; i++) {
        const a = this.kickDir + i * Math.PI / 2 + 0.5;
        pline(ctx, kp.x + Math.cos(a) * 3, kp.y + Math.sin(a) * 3, kp.x + Math.cos(a) * (5 + 9 * k), kp.y + Math.sin(a) * (5 + 9 * k), '#ffffff', 1);
      }
      ctx.globalAlpha = 1;
    }
    if (this.held) return;

    // KICK PROMPT: a ring closes on the player as the axe comes home; gold = perfect window / committed
    if (this.mode === 'return') {
      const eta = this.retD / Math.max(1, this.retSp);
      const r = 7 + Math.min(1, this.retD / 200) * 20;
      const col = this.kickArmed ? (this.kickPerfect ? '#fff3c4' : '#ffb347') : this.kickQueued ? '#ffb347' : eta <= PERFECT_ETA ? '#fff3c4' : '#bfe8ff';
      ctx.globalAlpha = this.kickArmed || this.kickQueued ? 0.9 : 0.5 + 0.25 * Math.sin(this.t * 30);
      pring(ctx, p.x, p.y - 6 - p.z, r, col, 1);
      ctx.globalAlpha = 1;
    } else if (this.kickQueued) {
      // queued: a steady gold ring says "the kick is coming" while the axe is still on its way out
      ctx.globalAlpha = 0.55 + 0.2 * Math.sin(this.t * 14);
      pring(ctx, p.x, p.y - 6 - p.z, 13, '#ffb347', 1);
      ctx.globalAlpha = 1;
    }

    // ribbon: frost on a plain throw, fire once the axe has been kicked
    const hot = this.mode === 'kicked' || this.rally > 0;
    const tr = this.trail;
    for (let i = 1; i < tr.length; i++) {
      const a = tr[i - 1], b = tr[i];
      const k = 1 - (this.t - b.t) / 0.22;
      if (k <= 0) continue;
      ctx.globalAlpha = k * (hot ? 0.75 : 0.55);
      pline(ctx, a.x, a.y, b.x, b.y, hot ? FIRE[i % 3] : i % 2 ? '#bfe8ff' : '#ffffff', hot ? 3 : 2);
    }
    ctx.globalAlpha = 1;

    const bx = this.x, by = this.y - this.lift;
    ctx.globalAlpha = hot ? 0.42 : 0.35;
    pcircle(ctx, bx, by, hot ? 9 : 7, hot ? '#ffb347' : '#bfe8ff');
    ctx.globalAlpha = 1;
    drawAxe(ctx, { x: bx, y: by }, this.ang, 0);
    // spinning glint
    const gx = bx + Math.cos(this.ang) * AXE_LEN, gy = by + Math.sin(this.ang) * AXE_LEN * 0.6;
    px(ctx, gx, gy, '#ffffff');
    if (hot) px(ctx, bx - Math.cos(this.ang) * 4, by - Math.sin(this.ang) * 3, '#fff3c4');
  }
}
