// KANTOR 3D (tetap side-view): gedung kantor dirender sebagai geometri 3D sungguhan dengan Three.js
// di BELAKANG canvas game. Kamera perspektif off-axis disinkronkan piksel-presisi dengan kamera 2D:
// bidang z = 0 adalah bidang gameplay, jadi posisi kaki / hitbox / tangga tetap sama persis.
//  - lantai (slab) & dinding = balok dengan kedalaman ke belakang (z -DEPTH .. 0) -> kelihatan permukaan lantai, plafon, sisi pilar
//  - dinding belakang = art kantor asli (filter NEAREST, tidak blur) di z = -DEPTH
//  - anak tangga 3D, pegangan tangga, kaca partisi transparan, lift bercahaya, lampu plafon + point light dinamis
//  - kota malam jauh di belakang jendela (parallax)
// Dirender pada devicePixelRatio penuh + antialias supaya TAJAM.
import * as THREE from 'three';
import { TILE } from './constants';
import { OT_ELEV, OT_FLOOR, OT_GLASS, OT_STAIRS, OT_WALL, officeStairPath } from './office';
import { voxelize, mergeNonIndexed } from './voxel';
import { Interior3D, type Building3D } from './office3dRoom';

/** penyedia sprite dari officeLook (furnitur, hiasan dinding, props interaktif) */
export interface SpriteSource {
  furnSprites(): { cv: HTMLCanvasElement; x: number; y: number; ch: string; h: number }[];
  decorSprites(): { cv: HTMLCanvasElement; x: number; y: number; kind: string }[];
  propSprite(kind: string, y: number, dead: boolean): HTMLCanvasElement | null;
  building3D?(): Building3D;
}
type PropLike = { x: number; y: number; kind: string; dead: boolean; flash: number; hp: number };
const DECOR_DEPTH: Record<string, number> = { clock: 2, frame: 1.5, poster: 1, apar: 4, ac: 7, shelf: 6, tv: 2, board: 1.5, logo: 2, cctv: 6, mirror: 1, chart: 1, menu: 1.5, vent: 1, plug: 1, banner: 1 };

const DEPTH = 52;            // kedalaman ruangan (px dunia) dari bidang gameplay ke dinding belakang
const MAX_LIGHTS = 8;

type Pal = { bg: string; floor: string; floorAlt: string; wall: string; wallTop: string; accent: string; accent2: string };
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Lvl = any;
type Lamp = { x: number; y: number; floorY: number; color: string };

function shade(hex: string, k: number): THREE.Color {
  const c = new THREE.Color(hex);
  if (k >= 0) c.lerp(new THREE.Color('#ffffff'), k); else c.multiplyScalar(1 + k);
  return c;
}

function canvasTex(c: HTMLCanvasElement, repeat = false): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.RepeatWrapping; }
  return t;
}

export class Office3D {
  readonly el: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(40, 16 / 9, 1, 4000);
  private world = new THREE.Group();
  private tiles = new THREE.Group();
  private backTex: THREE.CanvasTexture | null = null;
  private levelRef: unknown = null;
  private canvasRef: HTMLCanvasElement | null = null;
  private tileSum = -1;
  private sumT = 0;
  private texT = 0;
  private lamps: Lamp[] = [];
  private lights: THREE.PointLight[] = [];
  private mats: THREE.Material[] = [];
  private geos: THREE.BufferGeometry[] = [];
  private texs: THREE.Texture[] = [];
  ok = true;
  private src: SpriteSource | null = null;
  private voxMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.62, metalness: 0.04 });
  private voxFlash = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.9 });
  private propGeo = new Map<HTMLCanvasElement, THREE.BufferGeometry | null>();
  private propPool: THREE.Mesh[] = [];
  private propGroup = new THREE.Group();
  private interior: Interior3D | null = null;

  constructor(host: HTMLCanvasElement) {
    this.el = document.createElement('canvas');
    this.el.className = 'office3d-layer';
    Object.assign(this.el.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', zIndex: '0', display: 'none' });
    const parent = host.parentElement;
    if (parent) {
      parent.insertBefore(this.el, host);
      host.style.position = 'relative';
      host.style.zIndex = '1';
    }
    try {
      this.renderer = new THREE.WebGLRenderer({ canvas: this.el, antialias: true, alpha: false, powerPreference: 'high-performance' });
      this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    } catch (err) {
      console.warn('Kantor 3D tidak tersedia (WebGL):', err);
      this.ok = false;
    }
    this.scene.add(this.world);
    this.scene.add(this.propGroup);
    for (let i = 0; i < MAX_LIGHTS; i++) {
      const L = new THREE.PointLight(0xffe2b8, 0, 190, 1.15);
      this.lights.push(L); this.scene.add(L);
    }
  }

  setVisible(v: boolean) { this.el.style.display = v ? 'block' : 'none'; }
  private prCap = 2; private maxLights = MAX_LIGHTS;
  setQuality(prCap: number, lights: number) { this.prCap = prCap; this.maxLights = lights; }

  private track<T extends THREE.Material | THREE.BufferGeometry | THREE.Texture>(o: T): T {
    if (o instanceof THREE.Material) this.mats.push(o);
    else if (o instanceof THREE.BufferGeometry) this.geos.push(o);
    else this.texs.push(o);
    return o;
  }

  private clearWorld() {
    this.interior?.dispose(); this.interior = null;
    this.world.clear();
    this.tiles = new THREE.Group();
    for (const m of this.mats) m.dispose();
    for (const g of this.geos) g.dispose();
    for (const t of this.texs) t.dispose();
    this.mats = []; this.geos = []; this.texs = [];
    this.backTex = null;
  }

  /** (Re)build seluruh gedung 3D dari tile level + art kantor. */
  build(l: Lvl, levelCanvas: HTMLCanvasElement, pal: Pal, lamps: Lamp[]) {
    this.clearWorld();
    for (const g of this.propGeo.values()) g?.dispose();
    this.propGeo.clear();
    this.levelRef = l; this.canvasRef = levelCanvas; this.lamps = lamps;
    const lw = l.w * TILE, lh = l.h * TILE;
    const bg = new THREE.Color(pal.bg);
    this.scene.background = bg.clone().multiplyScalar(0.55);
    this.scene.fog = new THREE.Fog(this.scene.background as THREE.Color, 900, 2600);

    // ---- cahaya global
    const amb = new THREE.AmbientLight(0xffffff, 1.0);
    const hemi = new THREE.HemisphereLight(0xdfe8ff, 0x261c2c, 1.0);
    const key = new THREE.DirectionalLight(0xfff1dc, 1.6); key.position.set(0.35, 0.9, 1.0);
    const rim = new THREE.DirectionalLight(new THREE.Color(pal.accent), 0.5); rim.position.set(-0.6, -0.2, 0.8);
    this.world.add(amb, hemi, key, rim);

    // ---- kota malam jauh (parallax)
    {
      const c = document.createElement('canvas'); c.width = 512; c.height = 256;
      const g = c.getContext('2d')!;
      const gr = g.createLinearGradient(0, 0, 0, 256);
      gr.addColorStop(0, '#' + bg.clone().multiplyScalar(0.5).getHexString());
      gr.addColorStop(1, '#' + bg.clone().lerp(new THREE.Color(pal.accent), 0.25).getHexString());
      g.fillStyle = gr; g.fillRect(0, 0, 512, 256);
      let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
      for (let layer = 0; layer < 2; layer++) {
        for (let x = 0; x < 512;) {
          const w = 18 + Math.floor(rnd() * 34), h = 60 + Math.floor(rnd() * (layer ? 150 : 110));
          g.fillStyle = layer ? '#0b0f1c' : '#151b2e';
          g.fillRect(x, 256 - h, w - 2, h);
          for (let wy = 256 - h + 4; wy < 252; wy += 6) for (let wx = x + 3; wx < x + w - 5; wx += 5) {
            if (rnd() < (layer ? 0.32 : 0.18)) { g.fillStyle = rnd() < 0.8 ? '#ffd58a' : '#8fd8ff'; g.globalAlpha = layer ? 0.85 : 0.45; g.fillRect(wx, wy, 2, 3); g.globalAlpha = 1; }
          }
          x += w;
        }
      }
      const t = this.track(canvasTex(c, true));
      t.repeat.set(4, 1);
      const m = this.track(new THREE.MeshBasicMaterial({ map: t, fog: false }));
      const geo = this.track(new THREE.PlaneGeometry(lw * 4 + 4000, Math.max(lh * 3, 1400)));
      const sky = new THREE.Mesh(geo, m);
      sky.position.set(lw / 2, -lh / 2 + 120, -1400);
      this.world.add(sky);
    }

    // ---- dinding belakang = art kantor asli, NEAREST (tajam)
    {
      const t = this.track(canvasTex(levelCanvas));
      this.backTex = t;
      const m = this.track(new THREE.MeshLambertMaterial({ map: t, transparent: true, alphaTest: 0.04, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: 0.35, color: 0x9a9a9a }));
      const geo = this.track(new THREE.PlaneGeometry(levelCanvas.width, levelCanvas.height));
      const back = new THREE.Mesh(geo, m);
      back.position.set(levelCanvas.width / 2, -levelCanvas.height / 2, -DEPTH);
      this.world.add(back);
      // KANTOR 3D TOTAL: interior dibangun dari geometri 3D; lukisan 2D di dinding belakang tidak dipakai lagi
      if (this.src?.building3D) {
        try {
          this.interior = new Interior3D();
          this.interior.build(this.src.building3D(), DEPTH);
          this.world.add(this.interior.group);
          back.visible = false;
          this.backTex = null;   // tekstur lama tidak perlu di-upload ulang
        } catch (err) { console.warn('Interior 3D gagal, pakai dinding 2D:', err); this.interior = null; back.visible = true; }
      }
    }

    this.world.add(this.tiles);
    this.buildTiles(l, pal);
    this.buildDecor();
    this.tileSum = this.sumTiles(l);
  }

  /** furnitur & hiasan dinding sebagai voxel 3D, menempel dinding belakang (menutupi lukisan 2D-nya) */
  private buildDecor() {
    if (!this.src) return;
    const items: { geo: THREE.BufferGeometry; x: number; y: number; z: number }[] = [];
    for (const f of this.src.furnSprites()) {
      const depth = f.ch === 'd' ? 16 : f.h >= 24 ? 11 : 12;
      const g = voxelize(f.cv, depth);
      if (g) items.push({ geo: g, x: f.x, y: -f.y, z: -DEPTH });
    }
    for (const d of this.src.decorSprites()) {
      const g = voxelize(d.cv, DECOR_DEPTH[d.kind] ?? 2);
      if (g) items.push({ geo: g, x: d.x, y: -d.y, z: -DEPTH + 0.05 });
    }
    const merged = mergeNonIndexed(items);
    for (const it of items) it.geo.dispose();
    if (merged) {
      this.track(merged);
      const mesh = new THREE.Mesh(merged, this.voxMat);
      this.world.add(mesh);
    }
  }

  /** props interaktif (meja, pot, peti, tong) — dinamis tiap frame, versi utuh / hancur */
  private drawProps(props: PropLike[]) {
    let used = 0;
    if (this.src) for (const pr of props) {
      const cv = this.src.propSprite(pr.kind, pr.y, pr.dead);
      if (!cv || pr.dead) continue;
      let geo = this.propGeo.get(cv);
      if (geo === undefined) { geo = voxelize(cv, 16, { back: true }); this.propGeo.set(cv, geo); }
      if (!geo) continue;
      let m = this.propPool[used];
      if (!m) { m = new THREE.Mesh(geo, this.voxMat); this.propPool.push(m); this.propGroup.add(m); }
      m.geometry = geo;
      m.material = pr.flash > 0 && pr.hp > 0 ? this.voxFlash : this.voxMat;
      m.position.set(pr.x - 20, -(pr.y - 36), -16);
      m.visible = true;
      used++;
    }
    for (let i = used; i < this.propPool.length; i++) this.propPool[i].visible = false;
  }

  private sumTiles(l: Lvl): number {
    const ot: Uint8Array | undefined = l.officeTiles; if (!ot) return 0;
    let s = 0; for (let i = 0; i < ot.length; i++) if (ot[i] === OT_GLASS) s += i + 1;
    return s;
  }

  private buildTiles(l: Lvl, pal: Pal) {
    const g = this.tiles;
    g.clear();
    const ot: Uint8Array | undefined = l.officeTiles;
    if (!ot) return;
    const W = l.w, H = l.h;
    const at = (c: number, r: number) => (c < 0 || r < 0 || c >= W || r >= H ? -1 : ot[r * W + c]);

    // material lantai: papan dengan garis sambungan (nearest)
    const plank = document.createElement('canvas'); plank.width = 32; plank.height = 16;
    {
      const p = plank.getContext('2d')!;
      p.fillStyle = '#' + shade(pal.wallTop, 0.18).getHexString(); p.fillRect(0, 0, 32, 16);
      p.fillStyle = '#' + shade(pal.wallTop, 0.3).getHexString(); p.fillRect(0, 0, 32, 1);
      p.fillStyle = '#' + shade(pal.wallTop, -0.18).getHexString();
      p.fillRect(0, 7, 32, 1); p.fillRect(0, 15, 32, 1); p.fillRect(11, 0, 1, 7); p.fillRect(26, 8, 1, 7);
    }
    const plankTex = this.track(canvasTex(plank, true));
    const topMatFor = (wTiles: number) => {
      const t = this.track(plankTex.clone()); t.needsUpdate = true; t.repeat.set(wTiles / 2, DEPTH / 16);
      return this.track(new THREE.MeshStandardMaterial({ map: t, roughness: 0.55, metalness: 0.08 }));
    };
    const frontMat = this.track(new THREE.MeshStandardMaterial({ color: shade(pal.wallTop, 0), roughness: 0.8 }));
    const sideMat = this.track(new THREE.MeshStandardMaterial({ color: shade(pal.wall, 0.05), roughness: 0.85 }));
    const ceilMat = this.track(new THREE.MeshStandardMaterial({ color: shade(pal.wall, -0.25), roughness: 0.95 }));
    const pillarFront = this.track(new THREE.MeshStandardMaterial({ color: shade(pal.wall, 0.12), roughness: 0.75 }));
    const trimMat = this.track(new THREE.MeshStandardMaterial({ color: new THREE.Color(pal.accent), emissive: new THREE.Color(pal.accent), emissiveIntensity: 0.6, roughness: 0.4 }));

    // ---- persegi greedy untuk dinding & lantai
    const seen = new Uint8Array(W * H);
    const solid = (v: number) => v === OT_WALL || v === OT_FLOOR;
    for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
      const v = at(c, r);
      if (!solid(v) || seen[r * W + c]) continue;
      const kind = v;
      let c1 = c;
      while (c1 + 1 < W && at(c1 + 1, r) === kind && !seen[r * W + c1 + 1]) c1++;
      let r1 = r;
      outer: while (r1 + 1 < H) {
        for (let cc = c; cc <= c1; cc++) if (at(cc, r1 + 1) !== kind || seen[(r1 + 1) * W + cc]) break outer;
        r1++;
      }
      for (let rr = r; rr <= r1; rr++) for (let cc = c; cc <= c1; cc++) seen[rr * W + cc] = 1;
      const wT = c1 - c + 1, hT = r1 - r + 1;
      const x0 = c * TILE, y0 = r * TILE, w = wT * TILE, h = hT * TILE;
      const slab = wT >= hT * 2;
      const geo = this.track(new THREE.BoxGeometry(w, h, DEPTH));
      // urutan material Box: +x, -x, +y(atas), -y(bawah/plafon), +z(depan), -z(belakang)
      const mats = slab
        ? [sideMat, sideMat, topMatFor(wT), ceilMat, frontMat, sideMat]
        : [sideMat, sideMat, sideMat, ceilMat, pillarFront, sideMat];
      const mesh = new THREE.Mesh(geo, mats);
      mesh.position.set(x0 + w / 2, -(y0 + h / 2), -DEPTH / 2);
      g.add(mesh);
      // list neon tipis di tepi depan lantai
      if (slab && kind === OT_FLOOR) {
        const tg = this.track(new THREE.BoxGeometry(w, 1, 1));
        const trim = new THREE.Mesh(tg, trimMat);
        trim.position.set(x0 + w / 2, -(y0 + 0.5), -0.5);
        g.add(trim);
      }
    }

    // ---- kaca partisi (transparan) & lift (bercahaya)
    const glassMat = this.track(new THREE.MeshStandardMaterial({ color: 0x9fe8ff, transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0.3, depthWrite: false }));
    const glassEdge = this.track(new THREE.MeshStandardMaterial({ color: 0xcff6ff, emissive: 0x6fd8ff, emissiveIntensity: 0.4, transparent: true, opacity: 0.6 }));
    const elevMat = this.track(new THREE.MeshStandardMaterial({ color: new THREE.Color(pal.accent2), emissive: new THREE.Color(pal.accent2), emissiveIntensity: 0.55, transparent: true, opacity: 0.35, depthWrite: false }));
    const seen2 = new Uint8Array(W * H);
    for (let c = 0; c < W; c++) for (let r = 0; r < H; r++) {
      const v = at(c, r);
      if ((v !== OT_GLASS && v !== OT_ELEV) || seen2[r * W + c]) continue;
      let r1 = r; while (r1 + 1 < H && at(c, r1 + 1) === v) r1++;
      for (let rr = r; rr <= r1; rr++) seen2[rr * W + c] = 1;
      const x0 = c * TILE, y0 = r * TILE, h = (r1 - r + 1) * TILE;
      if (v === OT_GLASS) {
        const geo = this.track(new THREE.BoxGeometry(3, h, DEPTH - 4));
        const m = new THREE.Mesh(geo, glassMat); m.position.set(x0 + TILE / 2, -(y0 + h / 2), -DEPTH / 2); g.add(m);
        const eg = this.track(new THREE.BoxGeometry(4, h, 1));
        const e = new THREE.Mesh(eg, glassEdge); e.position.set(x0 + TILE / 2, -(y0 + h / 2), -0.6); g.add(e);
      } else {
        const geo = this.track(new THREE.BoxGeometry(TILE - 2, h, 8));
        const m = new THREE.Mesh(geo, elevMat); m.position.set(x0 + TILE / 2, -(y0 + h / 2), -DEPTH + 6); g.add(m);
      }
    }

    // ---- TANGGA BETON 3D: profil anak tangga (gergaji) diekstrusi jadi badan tangga solid, tiang + pegangan besi, bordes
    const treadMat = this.track(new THREE.MeshStandardMaterial({ color: shade(pal.wallTop, 0.22), roughness: 0.5, metalness: 0.05 }));
    const sideMat2 = this.track(new THREE.MeshStandardMaterial({ color: shade(pal.wall, 0.02), roughness: 0.8 }));
    const railMat = this.track(new THREE.MeshStandardMaterial({ color: 0xd8dde4, metalness: 0.85, roughness: 0.22 }));
    const nosing = this.track(new THREE.MeshStandardMaterial({ color: new THREE.Color(pal.accent), emissive: new THREE.Color(pal.accent), emissiveIntensity: 0.35, roughness: 0.4 }));
    const postGeo = this.track(new THREE.CylinderGeometry(0.32, 0.32, 1, 10));
    const railGeo = this.track(new THREE.CylinderGeometry(0.45, 0.45, 1, 12));
    const rodBetween = (ax: number, ay: number, az: number, bx: number, by: number, bz: number, geo: THREE.BufferGeometry, mat: THREE.Material) => {
      const d = new THREE.Vector3(bx - ax, -(by - ay), bz - az); const len = d.length(); if (len < 0.01) return;
      const m = new THREE.Mesh(geo, mat);
      m.position.set((ax + bx) / 2, -(ay + by) / 2, (az + bz) / 2);
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
      m.scale.set(1, len, 1);
      g.add(m);
    };
    const doneFlights = new Set<string>();
    for (let c = 0; c < W; c++) for (let r = 0; r < H; r++) {
      if (at(c, r) !== OT_STAIRS) continue;
      for (const oy of [2, 8, 14]) {
        const path = officeStairPath(l, c * TILE + TILE / 2, r * TILE + oy);
        if (!path) continue;
        const key = `${Math.round(path[0].x)}:${Math.round(path[0].y)}`;
        if (doneFlights.has(key)) continue;
        doneFlights.add(key);
        let flightIdx = 0;
        for (let i = 0; i < path.length - 1; i++) {
          const a = path[i], b = path[i + 1];
          const dx = b.x - a.x, dy = b.y - a.y;
          if (Math.abs(dy) > 6) {
            const low = a.y > b.y ? a : b, high = a.y > b.y ? b : a;
            const zFront = flightIdx % 2 === 0 ? 0 : -DEPTH * 0.5;
            const zBack = flightIdx % 2 === 0 ? -DEPTH * 0.46 : -DEPTH + 1;
            const n = Math.max(3, Math.round(Math.abs(dy) / 4));
            const rh = Math.abs(dy) / n, dirX = Math.sign(high.x - low.x) || 1, sw = Math.abs(dx) / n;
            const shape = new THREE.Shape();
            shape.moveTo(low.x, -low.y);
            for (let k = 0; k < n; k++) {
              const xk = low.x + dirX * k * sw;
              const top = low.y - (k + 0.5) * rh;
              shape.lineTo(xk, -top);
              shape.lineTo(xk + dirX * sw, -top);
            }
            shape.lineTo(high.x, -high.y);
            shape.lineTo(high.x, -(high.y + 5));
            shape.lineTo(low.x + dirX * sw * 1.2, -low.y);
            shape.closePath();
            const geo = this.track(new THREE.ExtrudeGeometry(shape, { depth: zFront - zBack, bevelEnabled: false, steps: 1 }));
            const mesh = new THREE.Mesh(geo, [sideMat2, treadMat]);
            mesh.position.z = zBack;
            g.add(mesh);
            // list terang di bibir tiap anak tangga
            for (let k = 0; k < n; k++) {
              const xk = low.x + dirX * (k + 0.06) * sw, top = low.y - (k + 0.5) * rh;
              const ng = this.track(new THREE.BoxGeometry(0.7, 0.5, zFront - zBack));
              const nm = new THREE.Mesh(ng, nosing); nm.position.set(xk, -(top + 0.25), (zFront + zBack) / 2); g.add(nm);
            }
            // tiang & pegangan di sisi depan flight
            const zr = zFront - 0.8, railH = 9;
            for (let k = 0; k <= n; k += 2) {
              const xk = low.x + dirX * Math.min(n - 0.5, k + 0.5) * sw, top = low.y - (Math.min(n - 1, k) + 0.5) * rh;
              rodBetween(xk, top, zr, xk, top - railH, zr, postGeo, railMat);
            }
            rodBetween(low.x + dirX * 0.5 * sw, low.y - 0.5 * rh - railH, zr, high.x - dirX * 0.5 * sw, high.y + 0.5 * rh - railH, zr, railGeo, railMat);
            flightIdx++;
          } else if (Math.abs(dx) > 3) {
            // bordes (landing)
            const top = Math.min(a.y, b.y);
            const lg = this.track(new THREE.BoxGeometry(Math.abs(dx) + 3, 4, DEPTH - 1));
            const lm = new THREE.Mesh(lg, [sideMat2, sideMat2, treadMat, sideMat2, sideMat2, sideMat2]);
            lm.position.set((a.x + b.x) / 2, -(top + 2), -DEPTH / 2 + 0.5);
            g.add(lm);
          }
        }
      }
    }

    // ---- lampu plafon (fixture bercahaya)
    const lampGeo = this.track(new THREE.BoxGeometry(22, 2, 10));
    for (const lp of this.lamps) {
      const m = this.track(new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: new THREE.Color(lp.color), emissiveIntensity: 1.6 }));
      const mesh = new THREE.Mesh(lampGeo, m);
      mesh.position.set(lp.x, -(lp.y - 1), -10);
      g.add(mesh);
    }
  }

  /** Render satu frame, kamera disinkronkan dengan kamera 2D game. */
  render(xf: { ox: number; oy: number; sw: number; sh: number }, l: Lvl, levelCanvas: HTMLCanvasElement, pal: Pal, lamps: Lamp[], dt: number, src: SpriteSource | null = null, props: PropLike[] = []) {
    if (!this.ok || !this.renderer) return;
    if (src !== this.src) { this.src = src; this.levelRef = null; }
    if (l !== this.levelRef || levelCanvas !== this.canvasRef) this.build(l, levelCanvas, pal, lamps);
    this.drawProps(props);
    // kaca pecah -> bangun ulang tile
    this.sumT += dt;
    if (this.sumT > 0.4) {
      this.sumT = 0;
      const s = this.sumTiles(l);
      if (s !== this.tileSum) { this.tileSum = s; this.buildTiles(l, pal); }
    }
    // art dinding belakang (noda darah, kaca) disegarkan berkala
    this.texT += dt;
    if (this.backTex && this.texT > 0.5) { this.texT = 0; this.backTex.needsUpdate = true; }

    // ukuran buffer = ukuran tampilan x devicePixelRatio -> tajam, tidak blur
    const cw = this.el.clientWidth | 0, ch = this.el.clientHeight | 0;
    if (cw > 0 && ch > 0) {
      const pr = Math.min(this.prCap, Math.max(0.75, window.devicePixelRatio || 1));
      if (this.renderer.getPixelRatio() !== pr) this.renderer.setPixelRatio(pr);
      const sz = this.renderer.getSize(new THREE.Vector2());
      if (sz.x !== cw || sz.y !== ch) this.renderer.setSize(cw, ch, false);
    }

    // kamera off-axis: bidang z=0 memetakan PERSIS seperti canvas 2D (sw x sh piksel dunia), mata kamera sedikit di atas
    const cx = xf.sw / 2 - xf.ox, cy = xf.sh / 2 - xf.oy;
    const d = xf.sh * 1.75;               // jarak kamera ke bidang gameplay (skala ikut zoom)
    const up = xf.sh * 0.32;              // mata kamera di atas tengah layar -> permukaan lantai terlihat
    const camX = cx, camY = -cy + up;
    this.camera.position.set(camX, camY, d);
    this.camera.rotation.set(0, 0, 0);
    this.camera.updateMatrixWorld();
    const n = 1, f = d + 3000;
    const k = n / d;
    const left = (cx - xf.sw / 2 - camX) * k, right = (cx + xf.sw / 2 - camX) * k;
    const top = (-cy + xf.sh / 2 - camY) * k, bottom = (-cy - xf.sh / 2 - camY) * k;
    this.camera.projectionMatrix.makePerspective(left, right, top, bottom, n, f);
    this.camera.projectionMatrixInverse.copy(this.camera.projectionMatrix).invert();

    this.interior?.update(cx, performance.now() / 1000);
    // point light dinamis: lampu terdekat dengan pusat layar
    const near = [...lamps].sort((a, b) => Math.hypot(a.x - cx, a.y - cy) - Math.hypot(b.x - cx, b.y - cy));
    for (let i = 0; i < this.lights.length; i++) {
      const L = this.lights[i], lp = near[i];
      if (!lp || i >= this.maxLights) { L.intensity = 0; L.visible = false; continue; }
      L.visible = true;
      L.position.set(lp.x, -(lp.y + 6), -14);
      L.color.set(lp.color);
      L.intensity = 70;
    }
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.clearWorld();
    this.renderer?.dispose();
    this.el.remove();
  }
}
