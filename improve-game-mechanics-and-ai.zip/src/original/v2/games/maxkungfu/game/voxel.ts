// VOXELIZER: sprite pixel-art -> geometri 3D (tiap piksel = balok sedalam `depth`), warna asli per-verteks.
// Muka yang bersebelahan dengan piksel lain dibuang (hemat), muka belakang tidak dibuat (menempel dinding / tak terlihat).
// Hasilnya objek 3D tajam yang setia pada art aslinya.
import * as THREE from 'three';

export function voxelize(cv: HTMLCanvasElement, depth: number, opts: { back?: boolean } = {}): THREE.BufferGeometry | null {
  const w = cv.width, h = cv.height;
  const ctx = cv.getContext('2d');
  if (!ctx || w === 0 || h === 0) return null;
  return voxelizeData(ctx.getImageData(0, 0, w, h).data, w, h, depth, opts);
}

/** inti voxelizer dengan GREEDY MESHING: deretan piksel berwarna sama digabung jadi satu permukaan (jauh lebih ringan) */
export function voxelizeData(data: Uint8ClampedArray, w: number, h: number, depth: number, opts: { back?: boolean } = {}): THREE.BufferGeometry | null {
  const op = (x: number, y: number) => x >= 0 && y >= 0 && x < w && y < h && data[(y * w + x) * 4 + 3] > 90;
  const key = (x: number, y: number) => { const i = (y * w + x) * 4; return (data[i] << 16) | (data[i + 1] << 8) | data[i + 2]; };
  const pos: number[] = [], nor: number[] = [], col: number[] = [];
  const c = new THREE.Color();
  const setCol = (x: number, y: number) => { const i = (y * w + x) * 4; c.setRGB(data[i] / 255, data[i + 1] / 255, data[i + 2] / 255, THREE.SRGBColorSpace); };
  const quad = (a: number[], b: number[], cc: number[], d: number[], n: number[], k: number) => {
    for (const v of [a, b, cc, a, cc, d]) { pos.push(v[0], v[1], v[2]); nor.push(n[0], n[1], n[2]); col.push(c.r * k, c.g * k, c.b * k); }
  };
  const Z0 = 0, Z1 = depth;
  let any = false;
  // per baris: depan (+ belakang), atas, bawah digabung horizontal
  for (let y = 0; y < h; y++) {
    const Yt = -y, Yb = -(y + 1);
    for (const face of [0, 1, 2]) {           // 0 depan, 1 atas, 2 bawah
      let x = 0;
      while (x < w) {
        const ok = (xx: number) => op(xx, y) && (face === 0 || (face === 1 ? !op(xx, y - 1) : !op(xx, y + 1)));
        if (!ok(x)) { x++; continue; }
        const k0 = key(x, y);
        let x1 = x + 1;
        while (x1 < w && ok(x1) && key(x1, y) === k0) x1++;
        any = true;
        setCol(x, y);
        if (face === 0) {
          quad([x, Yb, Z1], [x1, Yb, Z1], [x1, Yt, Z1], [x, Yt, Z1], [0, 0, 1], 1);
          if (opts.back) quad([x1, Yb, Z0], [x, Yb, Z0], [x, Yt, Z0], [x1, Yt, Z0], [0, 0, -1], 1);
        } else if (face === 1) quad([x, Yt, Z1], [x1, Yt, Z1], [x1, Yt, Z0], [x, Yt, Z0], [0, 1, 0], 1.08);
        else quad([x, Yb, Z0], [x1, Yb, Z0], [x1, Yb, Z1], [x, Yb, Z1], [0, -1, 0], 0.7);
        x = x1;
      }
    }
  }
  // per kolom: sisi kiri & kanan digabung vertikal
  for (let x = 0; x < w; x++) {
    const X0 = x, X1 = x + 1;
    for (const side of [-1, 1]) {
      let y = 0;
      while (y < h) {
        const ok = (yy: number) => op(x, yy) && !op(x + side, yy);
        if (!ok(y)) { y++; continue; }
        const k0 = key(x, y);
        let y1 = y + 1;
        while (y1 < h && ok(y1) && key(x, y1) === k0) y1++;
        setCol(x, y);
        const Yt = -y, Yb = -y1;
        if (side < 0) quad([X0, Yb, Z0], [X0, Yb, Z1], [X0, Yt, Z1], [X0, Yt, Z0], [-1, 0, 0], 0.85);
        else quad([X1, Yb, Z1], [X1, Yb, Z0], [X1, Yt, Z0], [X1, Yt, Z1], [1, 0, 0], 0.85);
        y = y1;
      }
    }
  }
  if (!any) return null;
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.computeBoundingSphere();
  return g;
}

/** gabungkan banyak geometri non-indexed (posisi sudah di dunia) jadi satu => satu draw call */
export function mergeNonIndexed(list: { geo: THREE.BufferGeometry; x: number; y: number; z: number }[]): THREE.BufferGeometry | null {
  let n = 0;
  for (const it of list) n += it.geo.getAttribute('position').count;
  if (!n) return null;
  const P = new Float32Array(n * 3), N = new Float32Array(n * 3), C = new Float32Array(n * 3);
  let o = 0;
  for (const it of list) {
    const p = it.geo.getAttribute('position').array as Float32Array, nn = it.geo.getAttribute('normal').array as Float32Array, cc = it.geo.getAttribute('color').array as Float32Array;
    for (let i = 0; i < p.length; i += 3) { P[o + i] = p[i] + it.x; P[o + i + 1] = p[i + 1] + it.y; P[o + i + 2] = p[i + 2] + it.z; }
    N.set(nn, o); C.set(cc, o);
    o += p.length;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(P, 3));
  g.setAttribute('normal', new THREE.BufferAttribute(N, 3));
  g.setAttribute('color', new THREE.BufferAttribute(C, 3));
  g.computeBoundingSphere();
  return g;
}
