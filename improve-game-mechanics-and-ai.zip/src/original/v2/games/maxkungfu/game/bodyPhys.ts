// FISIKA TUBUH SEKUNDER (ragdoll feel) untuk pemain & musuh.
// Setiap bagian tubuh adalah pegas teredam (spring-damper) yang "ditarik" oleh percepatan badan yang nyata:
//  - lari mendadak  -> badan condong, kepala & tangan tertinggal lalu menyusul (overshoot kecil)
//  - rem / balik arah -> badan terlempar ke depan oleh inersia
//  - lompat         -> tangan terangkat, kaki tertinggal di bawah; di udara kaki terseret mengikuti momentum
//  - mendarat       -> lutut/pinggul mengempis lalu memantul, kepala mengangguk
//  - kena pukul / serang -> dorongan (kx) otomatis menjadi hentakan tubuh
// Hasilnya offset kecil (dalam satuan skala stickman) yang ditambahkan ke sendi saat menggambar.

export interface BodyPhys {
  lx: number; ly: number;         // posisi terakhir (world)
  vx: number; vy: number;         // kecepatan halus
  lastT: number;
  grounded: boolean;
  airT: number;
  // pegas: nilai + kecepatan
  lean: number; leanV: number;    // sudut condong torso (rad)
  hx: number; hxv: number; hy: number; hyv: number;   // kepala
  ax: number; axv: number; ay: number; ayv: number;   // tangan
  fx: number; fxv: number; fy: number; fyv: number;   // kaki
  bob: number; bobV: number;      // kompresi pinggul (positif = turun)
}

export interface PhysOut { lean: number; head: { x: number; y: number }; arm: { x: number; y: number }; leg: { x: number; y: number }; bob: number; air: number }

export function newBodyPhys(x: number, y: number, t: number): BodyPhys {
  return { lx: x, ly: y, vx: 0, vy: 0, lastT: t, grounded: true, airT: 0, lean: 0, leanV: 0, hx: 0, hxv: 0, hy: 0, hyv: 0, ax: 0, axv: 0, ay: 0, ayv: 0, fx: 0, fxv: 0, fy: 0, fyv: 0, bob: 0, bobV: 0 };
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

/** satu langkah pegas semi-implisit: x'' = -k(x - target) - c x' + f */
function spring(x: number, v: number, target: number, k: number, c: number, f: number, dt: number): [number, number] {
  const acc = -k * (x - target) - c * v + f;
  v += acc * dt;
  x += v * dt;
  return [x, v];
}

/**
 * Perbarui fisika tubuh dari posisi nyata entitas.
 * @param x,y   posisi kaki di layar (y sudah dikurangi tinggi lompatan z bila top-down)
 * @param grounded  kaki menapak?
 * @param t     waktu game (ikut slow-motion)
 * @param heavy 0..1 — makin besar makin "berat" (badan besar / bos bergerak lebih lamban)
 */
export function stepBodyPhys(b: BodyPhys, x: number, y: number, grounded: boolean, t: number, heavy = 0): PhysOut {
  let dt = t - b.lastT;
  b.lastT = t;
  if (!(dt > 0)) return out(b);
  // teleport / lompatan besar posisi (spawn, grab, scene) -> reset tanpa hentakan
  if (dt > 0.1 || Math.abs(x - b.lx) > 40 || Math.abs(y - b.ly) > 40) {
    b.lx = x; b.ly = y; b.vx = 0; b.vy = 0; b.grounded = grounded;
    return out(b);
  }
  dt = Math.min(dt, 1 / 30);
  // kecepatan dari perpindahan posisi (menangani tangga, dash, knockback, apa pun)
  const nvx = (x - b.lx) / dt, nvy = (y - b.ly) / dt;
  b.lx = x; b.ly = y;
  const sm = Math.min(1, dt * 30);
  const pvx = b.vx, pvy = b.vy;
  b.vx += (nvx - b.vx) * sm;
  b.vy += (nvy - b.vy) * sm;
  // percepatan (dibatasi supaya hentakan tidak berlebihan)
  const accX = clamp((b.vx - pvx) / dt, -5200, 5200);
  const accY = clamp((b.vy - pvy) / dt, -5200, 5200);

  // mendarat: kompresi sesuai kecepatan jatuh
  if (grounded && !b.grounded) {
    const impact = clamp(pvy, 0, 520);
    b.bobV += impact * 0.1;
    b.hyv += impact * 0.07;
    b.ayv += impact * 0.07;
  }
  // tolakan lompat: tubuh sedikit meregang, tangan terayun ke atas
  if (!grounded && b.grounded && b.vy < -40) {
    b.bobV -= 6;
    b.ayv -= 22;
  }
  b.grounded = grounded;
  b.airT = grounded ? 0 : b.airT + dt;

  const m = 1 + heavy * 1.2;        // massa relatif
  const kS = 1 / m;
  // TORSO: condong ke arah lari (target) + inersia dari percepatan
  const leanTarget = clamp(b.vx / 1500, -0.13, 0.13) * (grounded ? 1 : 0.5);
  [b.lean, b.leanV] = spring(b.lean, b.leanV, leanTarget, 120 * kS, 13, -accX * 0.014 * kS, dt);
  b.lean = clamp(b.lean, -0.42, 0.42);
  // KEPALA: tertinggal dari gerak badan
  [b.hx, b.hxv] = spring(b.hx, b.hxv, 0, 260 * kS, 17, -accX * 0.13 * kS, dt);
  [b.hy, b.hyv] = spring(b.hy, b.hyv, 0, 260 * kS, 16, -accY * 0.07 * kS, dt);
  // TANGAN: paling lentur — terayun ke belakang saat akselerasi, ke depan saat rem
  [b.ax, b.axv] = spring(b.ax, b.axv, clamp(-b.vx / 260, -1.1, 1.1) * (grounded ? 0.5 : 0.9), 150 * kS, 11, -accX * 0.12 * kS, dt);
  [b.ay, b.ayv] = spring(b.ay, b.ayv, grounded ? 0 : clamp(b.vy / 220, -1.6, 1.6), 150 * kS, 11, -accY * 0.1 * kS, dt);
  // KAKI: di udara terseret melawan arah gerak; di tanah hampir tidak bergeser (tetap menapak)
  const footGround = grounded ? 0.15 : 1;
  [b.fx, b.fxv] = spring(b.fx, b.fxv, grounded ? 0 : clamp(-b.vx / 200, -1.8, 1.8), 170 * kS, 13, -accX * 0.09 * footGround * kS, dt);
  [b.fy, b.fyv] = spring(b.fy, b.fyv, grounded ? 0 : clamp(b.vy / 260, -1.2, 1.4), 170 * kS, 13, -accY * 0.07 * footGround * kS, dt);
  // PINGGUL: pegas kompresi pendaratan
  [b.bob, b.bobV] = spring(b.bob, b.bobV, 0, 210 * kS, 15, 0, dt);

  b.hx = clamp(b.hx, -2.2, 2.2); b.hy = clamp(b.hy, -2, 2.2);
  b.ax = clamp(b.ax, -2.8, 2.8); b.ay = clamp(b.ay, -3, 2.8);
  b.fx = clamp(b.fx, -2.6, 2.6); b.fy = clamp(b.fy, -1.8, 2);
  b.bob = clamp(b.bob, -1.2, 2.6);
  return out(b);
}

function out(b: BodyPhys): PhysOut {
  return { lean: b.lean, head: { x: b.hx, y: b.hy }, arm: { x: b.ax, y: b.ay }, leg: { x: b.fx, y: b.fy }, bob: b.bob, air: b.grounded ? 0 : Math.min(1, b.airT * 6) };
}

/** Hentakan langsung ke pegas tubuh (serangan / kena pukul). dx,dy = arah dorongan (unit), k = kekuatan. */
export function bodyKick(b: BodyPhys | null | undefined, dx: number, dy: number, k: number) {
  if (!b) return;
  b.hxv += dx * 26 * k; b.hyv += dy * 20 * k;
  b.leanV += dx * 3.2 * k;
  b.axv += dx * 30 * k; b.ayv += dy * 24 * k;
  b.bobV += 5 * k;
}

let PHYS_ON = (() => { try { return localStorage.getItem('v2_body_phys') !== '0'; } catch { return true; } })();
export function physEnabled() { return PHYS_ON; }
export function setPhysEnabled(v: boolean) { PHYS_ON = v; try { localStorage.setItem('v2_body_phys', v ? '1' : '0'); } catch { /* ignore */ } }
