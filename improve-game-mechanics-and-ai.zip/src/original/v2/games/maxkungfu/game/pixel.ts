export type Ctx = CanvasRenderingContext2D;

// ===================== MODE VEKTOR HD =====================
// Saat canvas dunia dirender beresolusi layar penuh (karakter / kantor 3D aktif), primitif efek digambar
// sebagai vektor halus ber-antialias, dan kotak kecil (partikel, tetesan darah, percikan) otomatis jadi bulatan halus.
let VEC_CTX: Ctx | null = null;
let RAW_FILL: ((x: number, y: number, w: number, h: number) => void) | null = null;
let FONT_BYPASS = 0;
const TAU = Math.PI * 2;
export function isVec(ctx: Ctx) { return ctx === VEC_CTX; }
export function setVectorCtx(ctx: Ctx | null) {
  if (VEC_CTX === ctx) return;
  if (VEC_CTX && RAW_FILL) delete (VEC_CTX as unknown as { fillRect?: unknown }).fillRect;
  VEC_CTX = ctx; RAW_FILL = null;
  if (!ctx) return;
  const raw = CanvasRenderingContext2D.prototype.fillRect;
  RAW_FILL = raw;
  (ctx as unknown as { fillRect: (x: number, y: number, w: number, h: number) => void }).fillRect = function (this: Ctx, x: number, y: number, w: number, h: number) {
    if (FONT_BYPASS || w > 3.5 || h > 3.5 || w <= 0 || h <= 0) { raw.call(this, x, y, w, h); return; }
    this.beginPath();
    if (Math.abs(w - h) < 0.6) this.arc(x + w / 2, y + h / 2, Math.max(w, h) * 0.6, 0, TAU);
    else this.ellipse(x + w / 2, y + h / 2, w * 0.6, h * 0.6, 0, 0, TAU);
    this.fill();
  };
}

export function px(ctx: Ctx, x: number, y: number, c: string) {
  ctx.fillStyle = c;
  if (ctx === VEC_CTX) { ctx.beginPath(); ctx.arc(x + 0.5, y + 0.5, 0.6, 0, TAU); ctx.fill(); return; }
  ctx.fillRect(Math.round(x), Math.round(y), 1, 1);
}

export function prect(ctx: Ctx, x: number, y: number, w: number, h: number, c: string) {
  ctx.fillStyle = c;
  if (ctx === VEC_CTX) { ctx.fillRect(x, y, w, h); return; }
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

export function pline(ctx: Ctx, x0: number, y0: number, x1: number, y1: number, c: string, w = 1) {
  if (ctx === VEC_CTX) {
    const off = w / 2 - (w > 1 ? w >> 1 : 0);
    ctx.strokeStyle = c; ctx.lineWidth = w * 0.92; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x0 + off, y0 + off); ctx.lineTo(x1 + off + (x0 === x1 && y0 === y1 ? 0.01 : 0), y1 + off); ctx.stroke();
    return;
  }
  x0 = Math.round(x0);
  y0 = Math.round(y0);
  x1 = Math.round(x1);
  y1 = Math.round(y1);
  ctx.fillStyle = c;
  const dx = Math.abs(x1 - x0);
  const dy = -Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  const o = w > 1 ? w >> 1 : 0;
  for (let i = 0; i < 4000; i++) {
    ctx.fillRect(x0 - o, y0 - o, w, w);
    if (x0 === x1 && y0 === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) {
      err += dy;
      x0 += sx;
    }
    if (e2 <= dx) {
      err += dx;
      y0 += sy;
    }
  }
}

export function pcircle(ctx: Ctx, cx: number, cy: number, r: number, c: string) {
  if (ctx === VEC_CTX) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(cx + 0.5, cy + 0.5, Math.max(0.5, r + 0.4), 0, TAU); ctx.fill(); return; }
  cx = Math.round(cx);
  cy = Math.round(cy);
  ctx.fillStyle = c;
  const rr = r * r + r * 0.6;
  const ri = Math.ceil(r);
  for (let dy = -ri; dy <= ri; dy++) {
    const v = rr - dy * dy;
    if (v < 0) continue;
    const dx = Math.floor(Math.sqrt(v));
    ctx.fillRect(cx - dx, cy + dy, dx * 2 + 1, 1);
  }
}

export function pellipse(ctx: Ctx, cx: number, cy: number, rx: number, ry: number, c: string) {
  if (ctx === VEC_CTX) { ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(cx + 0.5, cy + 0.5, Math.max(0.5, rx + 0.4), Math.max(0.5, ry + 0.4), 0, 0, TAU); ctx.fill(); return; }
  cx = Math.round(cx);
  cy = Math.round(cy);
  ctx.fillStyle = c;
  const ryi = Math.ceil(ry);
  for (let dy = -ryi; dy <= ryi; dy++) {
    const f = 1 - (dy * dy) / (ry * ry + 0.5);
    if (f < 0) continue;
    const dx = Math.floor(Math.sqrt(f) * rx);
    ctx.fillRect(cx - dx, cy + dy, dx * 2 + 1, 1);
  }
}

export function pring(ctx: Ctx, cx: number, cy: number, r: number, c: string, w = 1, from = 0, to = Math.PI * 2) {
  if (ctx === VEC_CTX) {
    const off = w / 2 - (w > 1 ? w >> 1 : 0);
    ctx.strokeStyle = c; ctx.lineWidth = w * 0.9; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(cx + off, cy + off, Math.max(0.1, r), from, to); ctx.stroke();
    return;
  }
  ctx.fillStyle = c;
  const steps = Math.max(8, Math.ceil(r * 7 * ((to - from) / (Math.PI * 2))));
  const o = w > 1 ? w >> 1 : 0;
  let lx = -9999, ly = -9999;
  for (let i = 0; i <= steps; i++) {
    const a = from + ((to - from) * i) / steps;
    const x = Math.round(cx + Math.cos(a) * r);
    const y = Math.round(cy + Math.sin(a) * r);
    if (x === lx && y === ly) continue;
    lx = x;
    ly = y;
    ctx.fillRect(x - o, y - o, w, w);
  }
}

// ---- 3x5 bitmap font ----
const GLYPHS: Record<string, string> = {
  A: '010101111101101', B: '110101110101110', C: '011100100100011', D: '110101101101110', E: '111100110100111',
  F: '111100110100100', G: '011100101101011', H: '101101111101101', I: '111010010010111', J: '001001001101010',
  K: '101101110101101', L: '100100100100111', M: '101111111101101', N: '110101101101101', O: '010101101101010',
  P: '110101110100100', Q: '010101101111011', R: '110101110101101', S: '011100010001110', T: '111010010010010',
  U: '101101101101111', V: '101101101101010', W: '101101111111101', X: '101101010101101', Y: '101101010010010',
  Z: '111001010100111', '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111',
  '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001001001001', '8': '111101111101111',
  '9': '111101111001111', ' ': '000000000000000', '-': '000000111000000', '!': '010010010000010', '.': '000000000000010',
  ':': '000010000010000', '/': '001001010100100', '+': '000010111010000', '%': '101001010100101', "'": '010010000000000',
  ',': '000000000010100', '?': '111001011000010', '>': '100010001010100', '<': '001010100010001', '(': '010100100100010',
  ')': '010001001001010', '[': '110100100100110', ']': '011001001001011', '=': '000111000111000', '*': '101010111010101',
  '#': '101111101111101', '_': '000000000000111',
};

let SMOOTH_TEXT = false;
/** The office build keeps the original 3x5 pixel HUD font even in 3D Feel mode. */
export function setSmoothText(_v: boolean) { SMOOTH_TEXT = false; }
const smoothFont = (scale: number) => `700 ${Math.max(8, Math.round(7.5 * scale))}px 'Barlow Condensed', 'Arial Narrow', system-ui, sans-serif`;
export function textWidth(text: string, scale = 1) {
  return SMOOTH_TEXT ? text.length * 5 * scale : text.length * 4 * scale - scale;
}

/** TEKS INFO: bila diset, semua tulisan yang digambar ke ctx dunia ini (prompt tombol, info, popup) disembunyikan */
let HIDE_TEXT_CTX: unknown = null;
export function setHiddenTextCtx(ctx: unknown) { HIDE_TEXT_CTX = ctx; }
export function pfont(ctx: Ctx, text: string, x: number, y: number, c: string, scale = 1, align: 'left' | 'center' | 'right' = 'left') {
  if (HIDE_TEXT_CTX !== null && ctx === HIDE_TEXT_CTX) return;
  text = text.toUpperCase();
  if (SMOOTH_TEXT || ctx === VEC_CTX) {
    ctx.save(); ctx.font = smoothFont(scale); ctx.textAlign = align; ctx.textBaseline = 'top';
    ctx.fillStyle = c; ctx.fillText(text, x, y); ctx.restore(); return;
  }
  const w = textWidth(text, scale);
  let cx = Math.round(align === 'center' ? x - w / 2 : align === 'right' ? x - w : x);
  const cy = Math.round(y);
  ctx.fillStyle = c;
  for (let i = 0; i < text.length; i++) {
    const g = GLYPHS[text[i]] || GLYPHS['?'];
    for (let r = 0; r < 5; r++) {
      for (let col = 0; col < 3; col++) {
        if (g[r * 3 + col] === '1') { FONT_BYPASS++; ctx.fillRect(cx + col * scale, cy + r * scale, scale, scale); FONT_BYPASS--; }
      }
    }
    cx += 4 * scale;
  }
}

export function pfontO(ctx: Ctx, text: string, x: number, y: number, c: string, oc: string, scale = 1, align: 'left' | 'center' | 'right' = 'left') {
  if (HIDE_TEXT_CTX !== null && ctx === HIDE_TEXT_CTX) return;
  if (SMOOTH_TEXT || ctx === VEC_CTX) {
    ctx.save(); ctx.font = smoothFont(scale); ctx.textAlign = align; ctx.textBaseline = 'top';
    ctx.lineWidth = Math.max(0.7, scale * 0.7); ctx.lineJoin = 'round'; ctx.strokeStyle = oc; ctx.strokeText(text.toUpperCase(), x, y);
    ctx.fillStyle = c; ctx.fillText(text.toUpperCase(), x, y); ctx.restore(); return;
  }
  pfont(ctx, text, x - scale, y, oc, scale, align);
  pfont(ctx, text, x + scale, y, oc, scale, align);
  pfont(ctx, text, x, y - scale, oc, scale, align);
  pfont(ctx, text, x, y + scale, oc, scale, align);
  pfont(ctx, text, x, y, c, scale, align);
}
