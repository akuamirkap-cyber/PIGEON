// KARAKTER & SENJATA 3D HD
// Kerangka animasi stickman (dari cap3d) dirender sebagai model 3D: anggota badan kapsul halus, kepala bola,
// mata, ikat kepala / aksesori, outline toon, dan senjata 3D (katana, kapak, bat, buster, pistol, rifle, shotgun,
// sabit, pisau kembar, sarung tinju, busur, dll). Lapisan WebGL transparan DI ATAS canvas game,
// resolusi penuh devicePixelRatio + antialias => tajam / HD, tidak blur.
import * as THREE from 'three';
import type { CharRec, WeapRec } from './cap3d';

const MAX_SEG = 6000, MAX_SPH = 7000;
type XF = { ox: number; oy: number; sw: number; sh: number };

const UP = new THREE.Vector3(0, 1, 0);
const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpS = new THREE.Vector3(), tmpP = new THREE.Vector3(), tmpD = new THREE.Vector3();
const tmpC = new THREE.Color();

export class Chars3D {
  readonly el: HTMLCanvasElement;
  ok = true;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(40, 1, 1, 5000);
  private seg: THREE.InstancedMesh; private segO: THREE.InstancedMesh;
  private sph: THREE.InstancedMesh; private sphO: THREE.InstancedMesh;
  private nSeg = 0; private nSph = 0; private nSegO = 0; private nSphO = 0;
  private pools = new Map<string, { list: THREE.Object3D[]; used: number }>();
  /** darah 3D: tetesan mengkilap (instanced) */
  private drops: THREE.InstancedMesh;
  private glowMats = new Map<string, THREE.MeshStandardMaterial>();

  constructor(host: HTMLCanvasElement) {
    this.el = document.createElement('canvas');
    this.el.className = 'chars3d-layer';
    Object.assign(this.el.style, { position: 'absolute', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', zIndex: '2', display: 'none' });
    host.parentElement?.insertBefore(this.el, host.nextSibling);
    try {
      this.renderer = new THREE.WebGLRenderer({ canvas: this.el, antialias: true, alpha: true, premultipliedAlpha: true, powerPreference: 'high-performance' });
      this.renderer.setClearColor(0x000000, 0);
      this.renderer.setPixelRatio(Math.min(2.5, window.devicePixelRatio || 1));
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    } catch (err) { console.warn('Karakter 3D tidak tersedia:', err); this.ok = false; }

    // geometri halus (HD)
    const cyl = new THREE.CylinderGeometry(1, 1, 1, 18, 1, true);
    const ball = new THREE.SphereGeometry(1, 28, 18);
    const body = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.42, metalness: 0.05 });
    const outline = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.BackSide });
    this.seg = new THREE.InstancedMesh(cyl, body, MAX_SEG);
    this.sph = new THREE.InstancedMesh(ball, body, MAX_SPH);
    this.segO = new THREE.InstancedMesh(cyl, outline, MAX_SEG);
    this.sphO = new THREE.InstancedMesh(ball, outline, MAX_SPH);
    for (const m of [this.seg, this.sph, this.segO, this.sphO]) {
      m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      m.frustumCulled = false;
      m.setColorAt(0, new THREE.Color(1, 1, 1));
      this.scene.add(m);
    }
    this.segO.renderOrder = 0; this.sphO.renderOrder = 0; this.seg.renderOrder = 1; this.sph.renderOrder = 1;
    this.drops = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 12, 9), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.14, metalness: 0.05, emissive: 0x220000, emissiveIntensity: 0.4 }), 4000);
    this.drops.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.drops.frustumCulled = false;
    this.drops.setColorAt(0, new THREE.Color(1, 0, 0));
    this.scene.add(this.drops);

    // cahaya: kunci hangat dari depan-atas, isi dingin, rim dari belakang => volume jelas
    this.scene.add(new THREE.AmbientLight(0xffffff, 1.25));
    this.scene.add(new THREE.HemisphereLight(0xeaf2ff, 0x40303a, 0.9));
    const key = new THREE.DirectionalLight(0xfff3e2, 2.6); key.position.set(0.4, 0.9, 1.0); this.scene.add(key);
    const fill = new THREE.DirectionalLight(0x9fc4ff, 0.9); fill.position.set(-0.8, 0.1, 0.6); this.scene.add(fill);
    const rim = new THREE.DirectionalLight(0xffffff, 1.4); rim.position.set(0, 0.4, -1); this.scene.add(rim);
  }

  setVisible(v: boolean) { this.el.style.display = v ? 'block' : 'none'; }
  private prCap = 2.5;
  setQuality(prCap: number) { this.prCap = prCap; }

  // ---------- instancing helpers ----------
  private segment(ax: number, ay: number, az: number, bx: number, by: number, bz: number, r: number, col: string, outline: string | null, ow: number, bright = 0) {
    tmpD.set(bx - ax, -(by - ay), bz - az);
    const len = tmpD.length();
    if (len < 0.01) return;
    tmpD.divideScalar(len);
    tmpQ.setFromUnitVectors(UP, tmpD);
    tmpP.set((ax + bx) / 2, -(ay + by) / 2, (az + bz) / 2);
    if (this.nSeg < MAX_SEG) {
      tmpS.set(r, len, r); tmpM.compose(tmpP, tmpQ, tmpS);
      this.seg.setMatrixAt(this.nSeg, tmpM);
      tmpC.set(col); if (bright) tmpC.lerp(new THREE.Color('#ffffff'), bright);
      this.seg.setColorAt(this.nSeg++, tmpC);
    }
    if (outline && this.nSegO < MAX_SEG) {
      tmpS.set(r + ow, len, r + ow); tmpM.compose(tmpP, tmpQ, tmpS);
      this.segO.setMatrixAt(this.nSegO, tmpM); this.segO.setColorAt(this.nSegO++, tmpC.set(outline));
    }
  }
  private ball(x: number, y: number, z: number, r: number, col: string, outline: string | null, ow: number, sy = 1) {
    tmpP.set(x, -y, z); tmpQ.identity();
    if (this.nSph < MAX_SPH) {
      tmpS.set(r, r * sy, r); tmpM.compose(tmpP, tmpQ, tmpS);
      this.sph.setMatrixAt(this.nSph, tmpM); this.sph.setColorAt(this.nSph++, tmpC.set(col));
    }
    if (outline && this.nSphO < MAX_SPH) {
      tmpS.set(r + ow, r * sy + ow, r + ow); tmpM.compose(tmpP, tmpQ, tmpS);
      this.sphO.setMatrixAt(this.nSphO, tmpM); this.sphO.setColorAt(this.nSphO++, tmpC.set(outline));
    }
  }

  // ---------- keadaan pegas gerak lanjutan per karakter ----------
  private springs = new Map<number, { p: Float32Array; v: Float32Array; seen: number; init: boolean; hit?: boolean; rx?: number; ry?: number; rvx?: number; rvy?: number; tx?: number; ty?: number; tvx?: number; tvy?: number }>();
  private frameNo = 0;
  private lastNow = 0;
  private handDeltas: { x: number; y: number; dx: number; dy: number; r: number }[] = [];
  private dtS = 1 / 60;

  /** titik 3D tubuh (relatif pinggul) dari kerangka 2D: bahu/pinggul lebar, putaran badan, garis pukulan ke tengah */
  private build3D(c: CharRec): number[][] {
    const s = c.scale, f = c.facing >= 0 ? 1 : -1;
    const hip = c.hip, neck = c.neck, head = c.head;
    const SW = 1.75 * s, HW = 1.05 * s, ARM = 5.2 * s, LEG = 5.6 * s;
    if (c.rag) {
      // RAGDOLL: posisi sudah dari fisika — hanya beri lebar bahu/pinggul tetap, tanpa putaran badan buatan
      const chestR = { x: hip.x + (neck.x - hip.x) * 0.72, y: hip.y + (neck.y - hip.y) * 0.72 };
      const mid = (a: { x: number; y: number }, b: { x: number; y: number }) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
      const fe = c.felbow ?? mid(neck, c.fhand), be = c.belbow ?? mid(neck, c.bhand), fk = c.fknee ?? mid(hip, c.ffoot), bk = c.bknee ?? mid(hip, c.bfoot);
      const pts = [[neck.x, neck.y, 0], [head.x, head.y, 0], [chestR.x, chestR.y, 0], [neck.x, neck.y + 0.3 * s, SW * 0.9], [neck.x, neck.y + 0.3 * s, -SW * 0.9],
        [fe.x, fe.y, SW * 0.95], [c.fhand.x, c.fhand.y, SW], [be.x, be.y, -SW * 0.95], [c.bhand.x, c.bhand.y, -SW],
        [hip.x, hip.y, HW], [hip.x, hip.y, -HW], [fk.x, fk.y, HW * 1.05], [c.ffoot.x, c.ffoot.y, HW * 1.1], [bk.x, bk.y, -HW * 1.05], [c.bfoot.x, c.bfoot.y, -HW * 1.1]];
      return pts.map((q) => [q[0] - hip.x, q[1] - hip.y, q[2]]);
    }
    const ext = (h: { x: number; y: number }, base: { x: number; y: number }, L: number) => Math.max(-1, Math.min(1, ((h.x - base.x) * f) / L));
    // putaran bahu: tangan depan menjulur => bahu depan maju; tangan belakang menjulur (cross) => bahu belakang maju
    const twist = Math.max(-0.95, Math.min(0.95, (ext(c.fhand, neck, ARM) - ext(c.bhand, neck, ARM)) * 0.75));
    const kick = ext(c.ffoot, hip, LEG) - ext(c.bfoot, hip, LEG);
    const hipTwist = Math.max(-0.7, Math.min(0.7, kick * 0.45 - twist * 0.28));
    const chest = { x: hip.x + (neck.x - hip.x) * 0.72, y: hip.y + (neck.y - hip.y) * 0.72 };
    const shF = [neck.x + f * SW * Math.sin(twist) * 0.9, neck.y + 0.35 * s, SW * Math.cos(twist)];
    const shB = [neck.x - f * SW * Math.sin(twist) * 0.9, neck.y + 0.35 * s, -SW * Math.cos(twist)];
    const hpF = [hip.x + f * HW * Math.sin(hipTwist), hip.y, HW * Math.cos(hipTwist)];
    const hpB = [hip.x - f * HW * Math.sin(hipTwist), hip.y, -HW * Math.cos(hipTwist)];
    // tangan / kaki menuju garis tengah saat menjulur, siku & lutut membuka ke luar saat menekuk
    const limb = (root: number[], mid: { x: number; y: number } | null, end: { x: number; y: number }, L: number, center: number, flare: number) => {
      const reach = Math.min(1, Math.hypot(end.x - root[0], end.y - root[1]) / L);
      const zEnd = root[2] * (1 - center * reach * reach);
      const m = mid ?? { x: (root[0] + end.x) / 2, y: (root[1] + end.y) / 2 };
      const zMid = (root[2] + zEnd) / 2 + Math.sign(root[2] || 1) * flare * s * (1 - reach);
      return { mid: [m.x, m.y, zMid], end: [end.x, end.y, zEnd] };
    };
    const aF = limb(shF, c.felbow, c.fhand, ARM, 0.85, 1.1), aB = limb(shB, c.belbow, c.bhand, ARM, 0.85, 1.1);
    const lF = limb(hpF, c.fknee, c.ffoot, LEG, 0.55, 0.7), lB = limb(hpB, c.bknee, c.bfoot, LEG, 0.55, 0.7);
    // urutan: 0 leher,1 kepala,2 dada,3 bahuF,4 bahuB,5 sikuF,6 tanganF,7 sikuB,8 tanganB,9 pinggulF,10 pinggulB,11 lututF,12 kakiF,13 lututB,14 kakiB
    const pts = [[neck.x, neck.y, 0], [head.x, head.y, 0], [chest.x, chest.y, 0], shF, shB, aF.mid, aF.end, aB.mid, aB.end, hpF, hpB, lF.mid, lF.end, lB.mid, lB.end]
      .map((q) => [q[0] - hip.x, q[1] - hip.y, q[2]]);
    // BERAT BADAN: tubuh atas condong masuk ke arah pukulan (bukan hanya lengan yang bergerak)
    const reachP = Math.max(0, ext(c.fhand, neck, ARM), ext(c.bhand, neck, ARM));
    const lean = f * 0.17 * reachP * reachP;
    if (Math.abs(lean) > 0.002) {
      const cs = Math.cos(lean), sn = Math.sin(lean);
      for (const i of [0, 1, 2, 3, 4, 5, 7]) { const x = pts[i][0], y = pts[i][1]; pts[i][0] = x * cs - y * sn; pts[i][1] = x * sn + y * cs; }
    }
    return pts;
  }

  /** pegas teredam per sendi => gerak lanjutan & overshoot kecil, transisi pose tidak patah */
  private smooth(c: CharRec, tgt: number[][]): number[][] {
    if (c.id === undefined || c.rag) { if (c.id !== undefined) this.springs.delete(c.id); return tgt; }
    let st = this.springs.get(c.id);
    const N = tgt.length;
    if (!st) { st = { p: new Float32Array(N * 3), v: new Float32Array(N * 3), seen: 0, init: false }; this.springs.set(c.id, st); }
    st.seen = this.frameNo;
    if (!st.init) { for (let i = 0; i < N; i++) for (let k = 0; k < 3; k++) st.p[i * 3 + k] = tgt[i][k]; st.init = true; return tgt; }
    // frekuensi alami per sendi (rad/s): kepala paling lentur, tinju & kaki cepat supaya pukulan tetap tajam
    // gerak lanjutan berlapis (overlapping action): tinju & kaki cepat, siku/lutut/dada/kepala lebih lentur menyusul
    const W = [40, 21, 34, 40, 40, 30, 72, 30, 72, 52, 52, 32, 66, 32, 66];
    // tinju yang baru mengenai sasaran memantul sedikit ke belakang (recoil), dada ikut tersentak
    const striking = !!c.strike;
    if (striking && !st.hit) {
      const f = c.facing >= 0 ? 1 : -1;
      const hi = c.strike === 'bhand' ? 8 : c.strike === 'ffoot' ? 12 : c.strike === 'bfoot' ? 14 : 6;
      st.v[hi * 3] -= f * 55 * c.scale; st.v[2 * 3] -= f * 18 * c.scale; st.v[1 * 3] -= f * 22 * c.scale;
    }
    st.hit = striking;
    const dt = Math.min(1 / 30, this.dtS), sub = 2, h = dt / sub;
    const out: number[][] = [];
    for (let i = 0; i < N; i++) {
      const w = W[i] ?? 30, kk = w * w, cc = 2 * 0.62 * w;
      const o: number[] = [];
      for (let k = 0; k < 3; k++) {
        const idx = i * 3 + k;
        let p = st.p[idx], v = st.v[idx];
        // lompatan besar (teleport / reset pose) => langsung ikut
        if (Math.abs(tgt[i][k] - p) > 9 * c.scale) { p = tgt[i][k]; v = 0; }
        for (let n = 0; n < sub; n++) { v += (kk * (tgt[i][k] - p) - cc * v) * h; p += v * h; }
        st.p[idx] = p; st.v[idx] = v; o.push(p);
      }
      out.push(o);
    }
    return out;
  }

  private drawChar(c: CharRec) {
    const s = c.scale, X = c.x, Y = c.y, f = c.facing >= 0 ? 1 : -1;
    const col = c.flash ? '#ffffff' : c.c;
    const ol = c.flash ? null : (c.outline ?? '#000000');
    const ow = 0.42;
    let hx = X + c.hip.x, hy = Y + c.hip.y;
    const ohx = hx, ohy = hy;
    // PENGHALUS POSISI TUBUH: menutup sisa lompatan posisi antar-frame (skip frame) dengan pegas sangat kaku
    if (c.id !== undefined && !c.rag) {
      const st = this.springs.get(c.id);
      if (st && st.tx !== undefined && Math.hypot(hx - st.tx, hy - (st.ty ?? hy)) < 26 * s) {
        // PELURUHAN SELISIH: gerak wajar diikuti persis (tanpa tertinggal); bagian perpindahan yang melompat
        // di luar prediksi kecepatan diserap sebagai selisih lalu diluruhkan halus (~60 ms) => tidak ada skip frame
        const dtc = Math.max(1 / 240, Math.min(1 / 30, this.dtS));
        const dx = hx - st.tx, dy = hy - (st.ty ?? hy);
        const px = (st.tvx ?? 0) * dtc, py = (st.tvy ?? 0) * dtc;
        const ex = dx - px, ey = dy - py, lim = 1.6 * s;
        let ax = 0, ay = 0;
        if (Math.abs(ex) > lim) ax = ex - Math.sign(ex) * lim;
        if (Math.abs(ey) > lim) ay = ey - Math.sign(ey) * lim;
        st.rx = ((st.rx ?? 0) - ax) * Math.exp(-dtc / 0.06);
        st.ry = ((st.ry ?? 0) - ay) * Math.exp(-dtc / 0.06);
        st.tvx = (dx - ax) / dtc; st.tvy = (dy - ay) / dtc;
        st.tx = hx; st.ty = hy;
        hx += st.rx; hy += st.ry;      } else if (st) { st.rx = 0; st.ry = 0; st.tx = hx; st.ty = hy; st.tvx = 0; st.tvy = 0; }
    }
    const T3 = this.build3D(c);
    const J = this.smooth(c, T3).map((q) => [hx + q[0], hy + q[1], q[2]]);
    // geseran tangan akibat pegas => senjata di tangan itu ikut bergeser (tetap tergenggam)
    for (const hi of [6, 8]) this.handDeltas.push({ x: ohx + T3[hi][0], y: ohy + T3[hi][1], dx: J[hi][0] - (ohx + T3[hi][0]), dy: J[hi][1] - (ohy + T3[hi][1]), r: 4 * s });
    const [neck, head, chest, shF, shB, elF, haF, elB, haB, hpF, hpB, knF, ftF, knB, ftB] = J;
    const limbR = 0.86 * s, torsoR = 1.12 * s;
    const strikeB = (tag: string) => (c.strike && (c.strike === tag || (c.strike === 'both' && (tag === 'fhand' || tag === 'bhand'))) ? 0.45 : 0);
    const seg = (a: number[], b: number[], r: number, cl = col, br = 0) => this.segment(a[0], a[1], a[2], b[0], b[1], b[2], r, cl, ol, ow, br);
    const ball = (a: number[], r: number, cl = col, sy = 1) => this.ball(a[0], a[1], a[2], r, cl, ol, ow, sy);
    // badan: panggul -> dada -> leher (tulang belakang melengkung), dada & panggul bervolume
    seg([hx, hy, 0], chest, torsoR * 1.05);
    seg(chest, neck, torsoR);
    ball([hx, hy, 0], torsoR * 1.15, col, 0.9);
    ball(chest, torsoR * 1.32, col, 1.05);
    // gelang bahu & pinggul (memberi lebar tubuh yang ikut berputar)
    seg(shF, shB, torsoR * 0.78);
    seg(hpF, hpB, torsoR * 0.9);
    seg(chest, shF, torsoR * 0.85); seg(chest, shB, torsoR * 0.85);
    // anggota: belakang dulu lalu depan
    const limb = (root: number[], mid: number[], end: number[], tag: string, endR: number) => {
      const b = strikeB(tag);
      ball(root, limbR * 1.08);
      seg(root, mid, limbR, col, b);
      ball(mid, limbR * 1.02);
      seg(mid, end, limbR * 0.94, col, b);
      ball(end, endR, b ? '#ffffff' : col);
    };
    limb(hpB, knB, ftB, 'bfoot', limbR * 1.25);
    limb(shB, elB, haB, 'bhand', limbR * 1.38);
    limb(hpF, knF, ftF, 'ffoot', limbR * 1.25);
    limb(shF, elF, haF, 'fhand', limbR * 1.38);
    // leher & kepala
    seg(neck, head, limbR * 0.8);
    const hr = c.headR;
    ball(head, hr);
    const acc = c.acc;
    if (!c.flash) {
      if (acc === 'headband' || acc === 'band') {
        this.segment(head[0] - 0.01, head[1] - 0.55 * s, head[2], head[0] + 0.01, head[1] + 0.6 * s, head[2], hr * 1.06, c.c2, null, 0);
        const tx = head[0] - f * hr * 1.0, ty = head[1] - 0.1 * s;
        this.segment(tx, ty, -0.6, tx - f * 3.2 * s, ty + 1.6 * s, -1.2, 0.42 * s, c.c2, ol, 0.25);
        this.segment(tx, ty, -0.9, tx - f * 2.6 * s, ty + 2.6 * s, -1.8, 0.4 * s, c.c2, ol, 0.25);
      } else if (acc === 'helmet' || acc === 'hood') this.ball(head[0], head[1] - hr * 0.22, head[2], hr * 1.08, c.c2, ol, ow, 0.85);
      else if (acc === 'mask') this.ball(head[0] + f * hr * 0.15, head[1] + hr * 0.3, head[2] + 0.2, hr * 0.92, c.c2, null, 0, 0.7);
      else if (acc === 'crown') this.segment(head[0], head[1] - hr * 0.95, 0, head[0], head[1] - hr * 1.5, 0, hr * 0.7, '#ffd700', ol, 0.3);
      else if (acc === 'horns') {
        this.segment(head[0] - hr * 0.7, head[1] - hr * 0.6, 0, head[0] - hr * 1.2, head[1] - hr * 1.5, 0, 0.45 * s, c.c2, ol, 0.25);
        this.segment(head[0] + hr * 0.7, head[1] - hr * 0.6, 0, head[0] + hr * 1.2, head[1] - hr * 1.5, 0, 0.45 * s, c.c2, ol, 0.25);
      }
    }
    if (!c.flash && c.mood !== 'dead') {
      const lx = Math.cos(c.look);
      const ex = head[0] + (Math.abs(lx) > 0.2 ? Math.sign(lx) : f) * hr * 0.62;
      const ey = head[1] + Math.sin(c.look) * hr * 0.25 - 0.15 * s;
      const eyeC = c.mood === 'angry' ? '#ff2a2a' : c.eyes;
      const er = 0.55 * s * (c.mood === 'hurt' ? 0.75 : 1);
      if (c.acc === 'shades' || c.acc === 'glasses') this.segment(ex - f * 1.4 * s, ey, hr * 0.78, ex + f * 0.6 * s, ey, hr * 0.78, 0.65 * s, '#0b0b10', null, 0);
      else {
        this.ball(ex, ey, hr * 0.8, er, eyeC, null, 0, c.mood === 'hurt' ? 0.4 : 1.25);
        this.ball(ex - f * 0.9 * s, ey, hr * 0.62, er * 0.9, eyeC, null, 0, c.mood === 'hurt' ? 0.4 : 1.25);
      }
    }
  }

  // ---------- senjata ----------
  private mat(color: string, opts: Partial<THREE.MeshStandardMaterialParameters> = {}) {
    return new THREE.MeshStandardMaterial({ color, roughness: 0.4, metalness: 0.2, ...opts });
  }
  private build(kind: string): THREE.Object3D {
    // model dibangun sepanjang sumbu +X dengan panjang acuan 1 (diskalakan per frame)
    const g = new THREE.Group();
    const inner = new THREE.Group(); g.add(inner); // inner diskalakan panjang
    const add = (geo: THREE.BufferGeometry, m: THREE.Material, x: number, y = 0, z = 0, toInner = true) => {
      const mesh = new THREE.Mesh(geo, m); mesh.position.set(x, y, z); (toInner ? inner : g).add(mesh); return mesh;
    };
    const steel = this.mat('#dfe6ee', { metalness: 0.85, roughness: 0.18 });
    const dark = this.mat('#20242c', { metalness: 0.5, roughness: 0.35 });
    const wood = this.mat('#8a5a30', { roughness: 0.6 });
    const gold = this.mat('#d4a531', { metalness: 0.9, roughness: 0.25 });
    const box = (l: number, h: number, d: number) => new THREE.BoxGeometry(l, h, d);
    const rod = (r1: number, r2: number, l: number) => { const c = new THREE.CylinderGeometry(r2, r1, l, 16); c.rotateZ(-Math.PI / 2); return c; };
    switch (kind) {
      case 'katana': {
        add(box(1, 1.1, 0.4), steel, 0.5);                         // bilah (panjang acuan 1, tebal dalam px)
        add(box(1, 0.3, 0.45), this.mat('#ffffff', { emissive: '#cfe8ff', emissiveIntensity: 0.6 }), 0.5, 0.6); // mata pedang
        add(new THREE.CylinderGeometry(1.1, 1.1, 0.4, 20).rotateZ(Math.PI / 2), gold, 0, 0, 0, false); // tsuba
        add(rod(0.55, 0.55, 4.2), this.mat('#e8e0d0', { roughness: 0.8 }), -2.1, 0, 0, false); // tsuka
        add(new THREE.SphereGeometry(0.6, 16, 12), gold, -4.3, 0, 0, false);
        g.userData.thick = 1; break;
      }
      case 'short': case 'knife': {
        add(box(1, 1.0, 0.4), steel, 0.5);
        add(box(0.4, 1.6, 0.6), gold, 0, 0, 0, false);
        add(rod(0.45, 0.45, 2.4), dark, -1.2, 0, 0, false);
        break;
      }
      case 'bat': {
        add(rod(0.7, 1.45, 1), wood, 0.5);                        // badan melebar ke ujung
        add(rod(0.78, 0.78, 0.3), dark, 0.15);                    // lakban grip
        add(new THREE.SphereGeometry(0.75, 16, 12), dark, 0, 0, 0, false);
        break;
      }
      case 'axe': {
        add(rod(0.55, 0.55, 1), wood, 0.5);
        const head = add(new THREE.CylinderGeometry(3.2, 3.2, 0.7, 24, 1, false, 0, Math.PI), steel, 0, 0, 0, false);
        head.rotation.x = Math.PI / 2; head.userData.tip = 0.82;
        add(new THREE.SphereGeometry(0.8, 14, 10), gold, 0, 0, 0, false).userData.tip = 1;
        break;
      }
      case 'buster': {
        add(box(1, 4.4, 0.9), this.mat('#b8c2cc', { metalness: 0.8, roughness: 0.3 }), 0.55);
        add(box(1, 0.6, 1.0), this.mat('#ffffff', { metalness: 0.9, roughness: 0.1 }), 0.55, 2.2);
        add(box(0.6, 6, 1.4), dark, 0, 0, 0, false);
        add(rod(0.7, 0.7, 5), this.mat('#5a3a22'), -2.5, 0, 0, false);
        break;
      }
      case 'pistol': case 'smg': {
        add(box(1, 2.0, 1.2), dark, 0.5);
        add(box(1, 0.7, 1.25), this.mat('#8d99a6', { metalness: 0.8, roughness: 0.25 }), 0.5, 1.0);
        add(box(1.4, 3.2, 1.3), this.mat('#3a2a1e', { roughness: 0.7 }), 0.6, -1.6, 0, false).rotation.z = -0.25;
        break;
      }
      case 'rifle': {
        add(box(1, 1.4, 1.0), dark, 0.5);
        add(box(0.35, 2.2, 1.1), wood, 0.2, -0.3);
        add(box(0.14, 2.6, 0.9), dark, 0.42, -1.6);
        add(rod(0.35, 0.35, 0.3), this.mat('#59636e', { metalness: 0.8 }), 0.9, 0.5);
        break;
      }
      case 'shotgun': {
        add(box(0.38, 2.4, 1.1), wood, 0.19, -0.2);
        add(rod(0.6, 0.6, 0.62), dark, 0.69, 0.5);
        add(rod(0.7, 0.7, 0.5), this.mat('#6b4a2b'), 0.7, -0.6);
        break;
      }
      case 'scythe': {
        add(rod(0.55, 0.55, 1.25), this.mat('#3b2a4a', { roughness: 0.6 }), 0.375);
        const blade = add(new THREE.TorusGeometry(5.2, 0.55, 8, 28, Math.PI * 0.75), this.mat('#d9d0ff', { metalness: 0.9, roughness: 0.15, emissive: '#5b3a9a', emissiveIntensity: 0.25 }), 0, 0, 0, false);
        blade.userData.tip = 1; blade.scale.set(1, 1, 0.5);
        break;
      }
      case 'glove': {
        add(new THREE.SphereGeometry(2.5, 24, 18), this.mat('#d22', { roughness: 0.35 }), 0, 0, 0, false).userData.colorable = true;
        add(rod(1.4, 1.4, 1.6), this.mat('#ffffff', { roughness: 0.6 }), -2.2, 0, 0, false);
        break;
      }
      case 'bow': {
        const limb = add(new THREE.TorusGeometry(7.5, 0.45, 8, 32, Math.PI * 0.8), wood, 0, 0, 0, false);
        limb.rotation.z = -Math.PI * 0.4; limb.position.x = -6.2;
        break;
      }
      case 'staff': { add(rod(0.6, 0.6, 1), wood, 0.5); break; }
      case 'nunstick': {
        // tongkat nunchaku: kayu (warna mengikuti skin) + tutup logam di ujung rantai
        add(rod(0.85, 0.95, 1), this.mat('#b3763a', { roughness: 0.5 }), 0.5).userData.colorable = true;
        add(new THREE.SphereGeometry(1.0, 14, 10), steel, 0, 0, 0, false).userData.tip = 1;
        break;
      }
      case 'chain': {
        add(rod(0.3, 0.3, 1), this.mat('#c3ccd6', { metalness: 0.95, roughness: 0.2 }), 0.5);
        add(new THREE.TorusGeometry(0.45, 0.16, 6, 12), steel, 0, 0, 0, false).userData.tip = 0.5;
        break;
      }
      case 'guandao': {
        // tiang berpernis merah tua, cincin emas, bilah bulan sabit baja, jumbai merah
        add(rod(0.75, 0.75, 0.76), this.mat('#5a1a14', { roughness: 0.45, metalness: 0.1 }), 0.38);
        add(new THREE.SphereGeometry(1.1, 14, 10), gold, 0, 0, 0, false);
        const ring = add(rod(1.0, 1.0, 1.4), gold, 0, 0, 0, false); ring.userData.tip = 0.76;
        const bs = new THREE.Shape();
        bs.moveTo(0, -1.2); bs.quadraticCurveTo(8, -3.2, 15, 1.2); bs.quadraticCurveTo(9, 6.2, 0, 4.6); bs.closePath();
        const blade = add(new THREE.ExtrudeGeometry(bs, { depth: 0.7, bevelEnabled: true, bevelThickness: 0.15, bevelSize: 0.2, bevelSegments: 2, curveSegments: 16 }),
          this.mat('#e3e9f0', { metalness: 0.9, roughness: 0.15 }), 0, 0, -0.35, false);
        blade.userData.tip = 0.77; blade.userData.flipY = true;
        const tassel = add(new THREE.ConeGeometry(1.3, 4.5, 10), this.mat('#d42a2a', { roughness: 0.8 }), 0, -2.6, 0, false);
        tassel.userData.tip = 0.75;
        break;
      }
      case 'string': {
        add(rod(0.16, 0.16, 1), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.75 }), 0.5).userData.colorable = true;
        break;
      }
      case 'yoyo': {
        const disc = add(new THREE.CylinderGeometry(2.7, 2.7, 1.9, 28).rotateX(Math.PI / 2), this.mat('#ff4a4a', { roughness: 0.3, metalness: 0.3 }), 0, 0, 0, false);
        disc.userData.colorable = true;
        add(new THREE.TorusGeometry(2.6, 0.35, 8, 28), this.mat('#ffffff', { metalness: 0.8, roughness: 0.2 }), 0, 0, 0.95, false);
        add(new THREE.CylinderGeometry(0.7, 0.7, 2.2, 12).rotateX(Math.PI / 2), steel, 0, 0, 0, false);
        break;
      }
      case 'shield': { add(new THREE.CylinderGeometry(4, 4, 0.8, 24).rotateZ(Math.PI / 2), this.mat('#8899aa', { metalness: 0.6 }), 0, 0, 0, false).userData.colorable = true; break; }
      case 'bomb': { add(new THREE.SphereGeometry(1.7, 18, 14), this.mat('#151515', { roughness: 0.5 }), 0, 0, 0, false); break; }
      default: { add(box(1, 1, 0.6), steel, 0.5); }
    }
    g.userData.inner = inner;
    this.scene.add(g);
    return g;
  }

  private placeWeapon(w0: WeapRec) {
    let w = w0;
    let best: { dx: number; dy: number } | null = null, bd = 1e9;
    for (const h of this.handDeltas) { const d = Math.hypot(h.x - w0.bx, h.y - w0.by); if (d < h.r && d < bd) { bd = d; best = h; } }
    if (best && (best.dx || best.dy)) w = { ...w0, bx: w0.bx + best.dx, by: w0.by + best.dy, tx: w0.tx + best.dx, ty: w0.ty + best.dy };
    let pool = this.pools.get(w.kind);
    if (!pool) { pool = { list: [], used: 0 }; this.pools.set(w.kind, pool); }
    if (pool.used >= pool.list.length) pool.list.push(this.build(w.kind));
    const g = pool.list[pool.used++] as THREE.Group;
    g.visible = true;
    const dx = w.tx - w.bx, dy = w.ty - w.by;
    const len = Math.max(0.5, Math.hypot(dx, dy));
    g.position.set(w.bx, -w.by, 1.9 * w.scale);
    g.rotation.set(0, 0, Math.atan2(-dy, dx));
    const s = w.scale;
    g.scale.set(s, s, s);
    const inner = g.userData.inner as THREE.Group;
    inner.scale.set(len / s, 1, 1);
    // bagian di ujung (kepala kapak, bilah sabit) mengikuti panjang
    for (const ch of g.children) {
      if (ch.userData.tip !== undefined) ch.position.x = (len / s) * ch.userData.tip;
      if (ch.userData.flipY) ch.scale.y = (w.facing ?? 1) >= 0 ? 1 : -1;
    }
    // senjata pendek (tali/rantai/yoyo) tidak diberi kedalaman tangan depan berlebihan
    if (w.kind === 'chain' || w.kind === 'string') g.position.z = 2.2 * w.scale;
    // inner children dengan ketebalan relatif: pertahankan ketebalan absolut (skala y,z inner = 1 => sudah absolut × acuan)
    const thick = 1 / Math.max(1, 1);
    void thick;
    // warna sarung / perisai + nyala serangan
    g.traverse((o) => {
      const m = (o as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
      if (!m || !(o as THREE.Mesh).isMesh) return;
      if (o.userData.colorable && w.color) m.color.set(w.color);
      if (!m.emissive) return;   // material tanpa emissive (mis. tali) — jangan crash
      if (o.userData.baseEm === undefined) { o.userData.baseEm = m.emissiveIntensity ?? 0; o.userData.emCol = '#' + m.emissive.getHexString(); }
      if (w.glow) { m.emissive.set(w.glow); m.emissiveIntensity = 0.9; o.userData.glowing = true; }
      else if (o.userData.glowing) { m.emissive.set(o.userData.emCol ?? '#000000'); m.emissiveIntensity = o.userData.baseEm; o.userData.glowing = false; }
    });
  }

  /** Bangun ketebalan absolut: inner diskala panjang di X, jadi tinggi/kedalaman bilah dinyatakan langsung dalam px. */
  private fixThickness() { /* ditangani oleh dimensi geometri: tinggi & kedalaman dalam px, panjang = 1 */ }

  render(xf: XF, chars: CharRec[], weapons: WeapRec[], blood: { x: number; y: number; vx: number; vy: number; s: number; c: string }[] = []) {
    if (!this.ok || !this.renderer) return;
    const cw = this.el.clientWidth | 0, ch = this.el.clientHeight | 0;
    if (cw > 0 && ch > 0) {
      const pr = Math.min(this.prCap, Math.max(0.75, window.devicePixelRatio || 1));
      if (this.renderer.getPixelRatio() !== pr) this.renderer.setPixelRatio(pr);
      const sz = this.renderer.getSize(new THREE.Vector2());
      if (sz.x !== cw || sz.y !== ch) this.renderer.setSize(cw, ch, false);
    }
    // kamera sama persis dengan kantor 3D: bidang z=0 = canvas 2D, piksel-presisi
    const cx = xf.sw / 2 - xf.ox, cy = xf.sh / 2 - xf.oy;
    const d = xf.sh * 1.75, up = xf.sh * 0.32;
    const camX = cx, camY = -cy + up;
    this.camera.position.set(camX, camY, d); this.camera.rotation.set(0, 0, 0); this.camera.updateMatrixWorld();
    const n = 1, k = n / d;
    this.camera.projectionMatrix.makePerspective((cx - xf.sw / 2 - camX) * k, (cx + xf.sw / 2 - camX) * k, (-cy + xf.sh / 2 - camY) * k, (-cy - xf.sh / 2 - camY) * k, n, d + 2000);
    this.camera.projectionMatrixInverse.copy(this.camera.projectionMatrix).invert();

    this.nSeg = this.nSph = this.nSegO = this.nSphO = 0;
    this.handDeltas.length = 0;
    {
      const now = performance.now();
      this.dtS = this.lastNow ? Math.min(0.05, (now - this.lastNow) / 1000) : 1 / 60;
      this.lastNow = now;
      this.frameNo++;
      if (this.frameNo % 120 === 0) for (const [k, v] of this.springs) if (this.frameNo - v.seen > 60) this.springs.delete(k);
    }
    // urutkan berdasarkan y supaya yang di depan menutupi (z kecil per karakter)
    for (const c of chars) this.drawChar(c);
    for (const [m, nn] of [[this.seg, this.nSeg], [this.sph, this.nSph], [this.segO, this.nSegO], [this.sphO, this.nSphO]] as [THREE.InstancedMesh, number][]) {
      m.count = nn;
      m.instanceMatrix.needsUpdate = true;
      if (m.instanceColor) m.instanceColor.needsUpdate = true;
    }
    for (const p of this.pools.values()) { for (let i = 0; i < p.list.length; i++) p.list[i].visible = false; p.used = 0; }
    for (const w of weapons) this.placeWeapon(w);
    // darah: bola mengkilap, memanjang searah kecepatan (cairan, bukan konfeti)
    {
      let n = 0;
      for (const b of blood) {
        if (n >= 4000) break;
        const sp = Math.hypot(b.vx, b.vy);
        const r = Math.max(0.45, b.s * 0.55);
        const stretch = 1 + Math.min(2.6, sp / 90);
        tmpP.set(b.x, -b.y, 1.2);
        if (sp > 1) { tmpD.set(b.vx / sp, -b.vy / sp, 0); tmpQ.setFromUnitVectors(UP, tmpD); } else tmpQ.identity();
        tmpS.set(r, r * stretch, r);
        tmpM.compose(tmpP, tmpQ, tmpS);
        this.drops.setMatrixAt(n, tmpM);
        this.drops.setColorAt(n, tmpC.set(b.c));
        n++;
      }
      this.drops.count = n;
      this.drops.instanceMatrix.needsUpdate = true;
      if (this.drops.instanceColor) this.drops.instanceColor.needsUpdate = true;
    }
    void this.glowMats; void this.fixThickness;
    this.renderer.render(this.scene, this.camera);
  }
}
