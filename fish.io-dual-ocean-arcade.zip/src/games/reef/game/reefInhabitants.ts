import * as T from "three";
import type { Attachment } from "./laut/reefEcology";

export interface ReefCritter { x: number; y: number; z: number; phase: number; kind: "fish" | "shrimp"; color: number }
const choose = (seed: number) => {
  let state=seed|0;
  return () => {state=(Math.imul(state,1664525)+1013904223)|0;return (state>>>0)/4294967296;};
};

export function placeReefLife(anchors: Attachment[], seed: number): ReefCritter[] {
  const rng=choose(seed*313+77), result: ReefCritter[]=[], patches=new Set<number>();
  for (const a of anchors) {
    if (a.kind===5 || a.normal[1]<.34 || patches.has(a.patch) || a.size<9) continue;
    patches.add(a.patch);
    // Small fish shelter just above established colonies; shrimp keep their feet on rock.
    for(let i=0;i<3;i++)result.push({
      x:a.point[0]+(rng()-.5)*Math.min(16,a.size*.32),
      y:-a.point[1]-Math.max(5,a.size*.43)-(rng()*7),
      z:a.point[2]+4+rng()*7,
      phase:rng()*Math.PI*2+i*.47, kind:"fish", color:(seed+i)%3,
    });
    if (patches.size%2===0)result.push({
      x:a.point[0]+(rng()-.5)*Math.min(10,a.size*.2),
      y:-a.point[1]-1.6,z:a.point[2]+2,
      phase:rng()*Math.PI*2,kind:"shrimp",color:0,
    });
    if(patches.size>=8)break;
  }
  return result;
}

const colors=[0x8fe9ed,0xffce72,0x84b8fc];
const tmp=new T.Object3D();
function critterGeometry(shrimp:boolean) {
  const body=new T.SphereGeometry(1,10,7);
  if(shrimp)body.rotateZ(-.2);
  return body;
}
function finGeometry(){const g=new T.ConeGeometry(.85,1.4,3);g.rotateZ(-Math.PI/2);return g;}
function feelers(){
  const g=new T.BufferGeometry(),p:number[]=[],id:number[]=[];
  const blade=(a:number[],b:number[],width:number)=>{
    const o=p.length/3;p.push(a[0],a[1],a[2],b[0],b[1],b[2],a[0]+width,a[1],a[2]+width);
    id.push(o,o+1,o+2);
  };
  for(let side of [-1,1]){
    for(let i=0;i<4;i++)blade([-.9+i*.52,-.42,side*.33],[-1.35+i*.5,-1.95,side*.84],.12);
    blade([1.72,.38,side*.14],[3.3,2.1,side*.65],.075);
  }
  g.setAttribute("position",new T.Float32BufferAttribute(p,3));g.setIndex(id);g.computeVertexNormals();return g;
}

export class ReefLifeRenderer {
  readonly group=new T.Group();
  readonly fish: ReefCritter[];
  private bodies:T.InstancedMesh;
  private tails:T.InstancedMesh;
  private shrimps:T.InstancedMesh;
  private feelers:T.InstancedMesh;
  private bubbles:T.Points;
  constructor(all:ReefCritter[]) {
    this.fish=all;
    const max=all.length;
    const fishMat=new T.MeshBasicMaterial({color:0xffffff});
    this.bodies=new T.InstancedMesh(critterGeometry(false),fishMat,max);
    this.tails=new T.InstancedMesh(finGeometry(),fishMat,max);
    this.shrimps=new T.InstancedMesh(critterGeometry(true),new T.MeshBasicMaterial({color:0xf69d58}),max);
    this.feelers=new T.InstancedMesh(feelers(),new T.MeshBasicMaterial({color:0xffc28c,side:T.DoubleSide}),max);
    const bubbleBase:number[]=[],bubbleSeed:number[]=[];
    for(let k=0;k<all.length;k++)if(all[k].kind==="shrimp")for(let i=0;i<5;i++){
      bubbleBase.push(all[k].x+(i-2)*1.8,all[k].y-1.5,all[k].z+2);
      bubbleSeed.push((i/5+k*.187)%1);
    }
    const bg=new T.BufferGeometry();bg.setAttribute("position",new T.Float32BufferAttribute(bubbleBase,3));bg.setAttribute("aSeed",new T.Float32BufferAttribute(bubbleSeed,1));
    this.bubbles=new T.Points(bg,new T.ShaderMaterial({transparent:true,depthWrite:false,
      uniforms:{uTime:{value:0},uPx:{value:1}},
      vertexShader:`attribute float aSeed;uniform float uTime,uPx;varying float vFade;void main(){float t=fract(aSeed+uTime*(.08+.023*aSeed));float drift=sin(uTime*.68+aSeed*41.+t*10.)*3.;vec3 p=position+vec3(drift,t*66.,sin(aSeed*13.+t*8.)*3.);gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);gl_PointSize=clamp((2.+2.1*t)*uPx,1.4,9.);vFade=sin(t*3.14159)*.69;}`,
      fragmentShader:`varying float vFade;void main(){vec2 p=gl_PointCoord-.5;float r=length(p)*2.;float rim=smoothstep(.57,.85,r)*(1.-smoothstep(.94,1.,r));float shine=exp(-dot(p-vec2(-.18,-.19),p-vec2(-.18,-.19))*120.);gl_FragColor=vec4(mix(vec3(.54,.84,.94),vec3(1.),shine),vFade*(.72*rim+.68*shine));}`}));
    this.bubbles.frustumCulled=false;this.bubbles.renderOrder=31;
    this.bodies.frustumCulled=this.tails.frustumCulled=this.shrimps.frustumCulled=false;
    this.group.name="reef-microfauna";
    this.group.add(this.bodies,this.tails,this.shrimps,this.feelers,this.bubbles);
  }
  update(t:number,cx:number,cy:number,vw:number,vh:number) {
    (this.bubbles.material as T.ShaderMaterial).uniforms.uTime.value=t;
    (this.bubbles.material as T.ShaderMaterial).uniforms.uPx.value=Math.min(2,typeof devicePixelRatio==="number"?devicePixelRatio:1);
    let fish=0,shrimp=0;
    for(const a of this.fish){
      if(Math.abs(a.x-cx)>vw*.52+24||Math.abs(a.y-cy)>vh*.52+24)continue;
      if(a.kind==="shrimp"){
        tmp.position.set(a.x+Math.sin(t*.85+a.phase)*2,a.y+.3,a.z);
        tmp.scale.set(2.7,.67,.83);tmp.rotation.set(0,0,.12*Math.sin(t*2+a.phase));tmp.updateMatrix();
        this.shrimps.setMatrixAt(shrimp,tmp.matrix);
        tmp.scale.set(1,1,1);tmp.updateMatrix();this.feelers.setMatrixAt(shrimp,tmp.matrix);shrimp++;
        continue;
      }
      const swim=t*.87+a.phase,x=a.x+Math.sin(swim)*8,y=a.y+Math.sin(swim*1.9)*2.8;
      const facing=Math.cos(swim)>0?1:-1;
      tmp.position.set(x,y,a.z);tmp.scale.set(2.65,1.05,.72);tmp.rotation.set(0,facing<0?Math.PI:0,Math.sin(swim*1.9)*.13);tmp.updateMatrix();
      this.bodies.setMatrixAt(fish,tmp.matrix);
      this.bodies.setColorAt(fish,new T.Color(colors[a.color]));
      tmp.position.set(x-facing*3,y,a.z);tmp.scale.set(1,1.25,.55);tmp.rotation.set(0,facing<0?Math.PI:0,Math.sin(swim*5)*.24);tmp.updateMatrix();
      this.tails.setMatrixAt(fish,tmp.matrix);this.tails.setColorAt(fish,new T.Color(colors[a.color]));fish++;
    }
    this.bodies.count=this.tails.count=fish;this.shrimps.count=this.feelers.count=shrimp;
    this.bodies.instanceMatrix.needsUpdate=this.tails.instanceMatrix.needsUpdate=this.shrimps.instanceMatrix.needsUpdate=this.feelers.instanceMatrix.needsUpdate=true;
    if(this.bodies.instanceColor)this.bodies.instanceColor.needsUpdate=true;
    if(this.tails.instanceColor)this.tails.instanceColor.needsUpdate=true;
  }
  dispose(){for(const m of [this.bodies,this.tails,this.shrimps,this.feelers,this.bubbles]){m.geometry.dispose();(m.material as T.Material).dispose();}}
}

export function drawReefLife(c:CanvasRenderingContext2D,creatures:ReefCritter[],cl:number,ct:number,w:number,h:number,t:number){
  c.save();c.translate(-cl,-ct);
  for(const a of creatures){
    if(a.x<cl-24||a.x>cl+w+24||a.y<ct-24||a.y>ct+h+24)continue;
    if(a.kind==="shrimp"){
      const x=a.x+Math.sin(t*.85+a.phase)*2,y=a.y;
      c.save();c.translate(x,y);c.strokeStyle="#e7a382";c.lineWidth=.42;
      for(let i=0;i<3;i++){c.beginPath();c.moveTo(-1+i*1.1,.3);c.lineTo(-2+i*1.2,2.5);c.moveTo(-1+i*1.1,.3);c.lineTo(i*1.2,2.4);c.stroke();}
      c.fillStyle="#e96d42";c.beginPath();c.ellipse(0,0,3.1,1.5,-.18,0,Math.PI*2);c.fill();
      c.fillStyle="#ffb783";c.beginPath();c.ellipse(-.5,-.5,2.1,.49,-.19,0,Math.PI*2);c.fill();
      c.strokeStyle="#ffe0af";c.beginPath();c.moveTo(2,-.5);c.quadraticCurveTo(3.6,-3,5,-2);c.moveTo(2,-.5);c.quadraticCurveTo(4,-2,5.7,-.6);c.stroke();c.restore();continue;
    }
    const swim=t*.87+a.phase,x=a.x+Math.sin(swim)*8,y=a.y+Math.sin(swim*1.9)*2.8,dir=Math.cos(swim)>0?1:-1;
    c.save();c.translate(x,y);c.scale(dir,1);
    c.fillStyle=["#89f2e3","#ffda80","#9ac8ff"][a.color];c.beginPath();c.moveTo(-2.3,0);c.lineTo(-5,-2);c.lineTo(-5,2);c.closePath();c.fill();
    c.beginPath();c.ellipse(0,0,2.8,1.3,Math.sin(swim*1.9)*.12,0,Math.PI*2);c.fill();
    c.fillStyle="#fff";c.beginPath();c.arc(1.8,-.48,.39,0,Math.PI*2);c.fill();c.restore();
  }
  c.restore();
}