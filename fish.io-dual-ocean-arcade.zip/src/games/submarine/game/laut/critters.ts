// ============================================================================
// Reef critters for Dunia Laut 3D: tiny damselfish darting around the corals
// and cleaner shrimp perched on the rocks (antennae twitching, sudden flicks).
// Decor only – two instanced draw calls, all motion in the vertex shaders.
// ============================================================================
import * as THREE from "three";
import { SHARED } from "./glsl";
import { mergeAux } from "./corals";

export interface Spot {
  x: number;
  y: number;
  z: number;
  tilt?: number;
}

const FISH_VS = /* glsl */ `
attribute float aux;
attribute vec4 iA; // anchor x, y (game y, down), z, orbit radius
attribute vec4 iB; // phase, speed, palette, size
uniform float uTime;
varying vec3 vN; varying vec3 vLP; varying float vPal; varying vec3 vWP;
void main(){
  float t = uTime * iB.y + iB.x;
  float rx = iA.w, ry = iA.w * .35;
  // figure-of-eight patrol around the coral head with nervous darts
  float dart = pow(.5 + .5 * sin(t * 3.1 + iB.x * 7.), 6.);
  vec2 c = vec2(sin(t) * rx + sin(t * 2.3) * rx * .15, sin(t * 2.) * ry + dart * 4.);
  vec2 dc = vec2(cos(t) * rx + cos(t * 2.3) * rx * .35, cos(t * 2.) * ry * 2.);
  float face = dc.x >= 0. ? 1. : -1.;
  float pitch = clamp(dc.y / (abs(dc.x) + 1.), -.6, .6);
  vec3 p = position * iB.w;
  // tail & rear body wag
  float rear = smoothstep(.1, .9, -position.x);
  p.z += sin(uTime * (14. + 6. * dart) + iB.x * 3.) * rear * rear * .35 * iB.w;
  p.x *= face;
  // pitch with the travel direction
  float cp = cos(pitch), sp = sin(pitch);
  p = vec3(p.x * cp - p.y * sp * face, p.x * sp * face + p.y * cp, p.z);
  vec3 n = vec3(normal.x * face, normal.y, normal.z);
  vec3 wp = vec3(iA.x + c.x, -(iA.y + c.y), iA.z) + p;
  vN = n; vLP = position; vPal = iB.z; vWP = wp;
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(wp, 1.);
}`;

const FISH_FS = /* glsl */ `
varying vec3 vN; varying vec3 vLP; varying float vPal; varying vec3 vWP;
vec3 palette(float k){
  // tropical damsels & chromis: electric blue, orange, yellow, green chromis, purple
  if (k < .5) return vec3(.15, .55, 1.);
  if (k < 1.5) return vec3(1., .5, .15);
  if (k < 2.5) return vec3(1., .85, .2);
  if (k < 3.5) return vec3(.45, .95, .6);
  return vec3(.7, .4, 1.);
}
void main(){
  vec3 N = normalize(vN); if (!gl_FrontFacing) N = -N;
  vec3 base = palette(vPal);
  // pale belly, darker back, a bright stripe / spot
  float belly = smoothstep(-.1, -.35, vLP.y);
  vec3 col = mix(base, vec3(.95, .97, 1.), belly * .7);
  col = mix(col, base * .55, smoothstep(.1, .35, vLP.y));
  float stripe = smoothstep(.02, .0, abs(vLP.x + .15) - .05) * .6;
  col = mix(col, vec3(1.), stripe * step(1.5, vPal) * step(vPal, 2.5));
  float eye = smoothstep(.07, .04, length(vLP.xy - vec2(.55, .08)));
  col = mix(col, vec3(.02), eye);
  vec3 L = normalize(vec3(-.4, .8, .5));
  float ndl = max(dot(N, L), 0.);
  float wy = -vWP.y;
  float sk = sunK(wy);
  col = col * (.45 + .6 * ndl * sk + .15 * max(N.y, 0.)) * absorbK(wy * .4);
  col += vec3(1.) * pow(max(dot(N, normalize(L + vec3(0., 0., 1.))), 0.), 24.) * .35 * sk;
  col = mix(col, waterCol(wy), .18);
  gl_FragColor = vec4(col, 1.);
}`;

const SHRIMP_VS = /* glsl */ `
attribute float aux; // 0 body .. 1 tail, 2 = antennae, 3 = legs
attribute vec4 iA; // anchor x, y, z, face
attribute vec4 iB; // phase, size, tilt, 0
uniform float uTime;
varying vec3 vN; varying vec3 vLP; varying float vAux; varying vec3 vWP;
void main(){
  float ph = iB.x;
  vec3 p = position * iB.y;
  // occasional backward flick (tail snap), then a slow crawl back
  float cyc = fract(uTime * .11 + ph * .13);
  float flick = pow(max(0., sin(cyc * 6.2832)), 40.);
  float crawl = sin(uTime * 1.3 + ph) * .4 * iB.y;
  if (aux > 1.5 && aux < 2.5) {
    // antennae: long slow sweeps + tremble
    float s = sin(uTime * 1.7 + ph) * .25 + sin(uTime * 9. + ph * 3.) * .04;
    float u = clamp(position.x / 2.2, 0., 1.);
    p.y += s * u * u * iB.y * 2.;
    p.z += cos(uTime * 1.1 + ph) * u * u * iB.y * .6;
  } else if (aux > 2.5) {
    // legs: tiny walking twitch
    p.y += sin(uTime * 12. + position.x * 30. + ph) * .02 * iB.y;
  } else {
    // tail curls under during the flick
    float curl = flick * aux * aux * 1.2;
    p.y -= curl * iB.y * .5;
    p.x += curl * iB.y * .4;
  }
  p.x += crawl - flick * iB.y * 3.;
  p.y += flick * iB.y * 1.5;
  // perch tilt & facing
  float ct = cos(iB.z), st = sin(iB.z);
  p = vec3(p.x * ct - p.y * st, p.x * st + p.y * ct, p.z);
  p.x *= iA.w;
  vec3 n = vec3(normal.x * iA.w, normal.y, normal.z);
  vec3 wp = vec3(iA.x, -iA.y, iA.z) + p;
  vN = n; vLP = position; vAux = aux; vWP = wp;
  gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(wp, 1.);
}`;

const SHRIMP_FS = /* glsl */ `
varying vec3 vN; varying vec3 vLP; varying float vAux; varying vec3 vWP;
void main(){
  vec3 N = normalize(vN); if (!gl_FrontFacing) N = -N;
  // translucent glassy body with red & white bands, dark eyes
  float band = .5 + .5 * sin(vLP.x * 11. + 1.);
  vec3 col = mix(vec3(1., .96, .9), vec3(.95, .2, .15), smoothstep(.35, .65, band));
  float eye = smoothstep(.1, .06, length(vLP.xy - vec2(1., .32)));
  col = mix(col, vec3(.02), eye);
  if (vAux > 1.5) col = vec3(1., .98, .9);
  vec3 L = normalize(vec3(-.4, .8, .5));
  float ndl = max(dot(N, L), 0.);
  float wy = -vWP.y;
  float sk = sunK(wy);
  float fr = pow(1. - abs(N.z), 2.);
  col = col * (.5 + .55 * ndl * sk) * absorbK(wy * .4) + vec3(1.) * fr * .25;
  col += vec3(1.) * pow(max(dot(N, normalize(L + vec3(0., 0., 1.))), 0.), 30.) * .4;
  col = mix(col, waterCol(wy), .15);
  float a = vAux > 1.5 ? .75 : .85 + fr * .15;
  gl_FragColor = vec4(col * a, a);
}`;

function fishGeometry() {
  const body = new THREE.SphereGeometry(0.5, 16, 10);
  body.scale(1.1, 0.5, 0.26);
  const tail = new THREE.ConeGeometry(0.28, 0.42, 3);
  tail.rotateZ(Math.PI / 2);
  tail.scale(1, 1, 0.15);
  tail.translate(-0.72, 0, 0);
  const dorsal = new THREE.ConeGeometry(0.22, 0.22, 3);
  dorsal.scale(1.6, 1, 0.12);
  dorsal.translate(-0.05, 0.3, 0);
  const g = mergeAux([{ g: body, aux: 0 }, { g: tail, aux: 1 }, { g: dorsal, aux: 0.3 }]);
  g.deleteAttribute("uv");
  return g;
}

function shrimpGeometry() {
  const parts: { g: THREE.BufferGeometry; aux?: number }[] = [];
  // arched body: head (carapace) to tail, 7 shrinking segments along a curve
  for (let i = 0; i < 7; i++) {
    const t = i / 6;
    const r = 0.3 * (1 - t * 0.55);
    const seg = new THREE.SphereGeometry(r, 10, 7);
    seg.scale(1.25, 1, 0.8);
    const x = 0.9 - t * 1.9,
      y = 0.3 - Math.pow(t, 1.6) * 0.5 + Math.sin(t * Math.PI) * 0.18;
    seg.translate(x, y, 0);
    parts.push({ g: seg, aux: t });
  }
  // tail fan
  const fan = new THREE.ConeGeometry(0.22, 0.3, 4);
  fan.rotateZ(Math.PI / 2);
  fan.scale(1, 1, 0.3);
  fan.translate(-1.15, -0.25, 0);
  parts.push({ g: fan, aux: 1 });
  // rostrum
  const ros = new THREE.ConeGeometry(0.06, 0.4, 5);
  ros.rotateZ(-Math.PI / 2);
  ros.translate(1.3, 0.4, 0);
  parts.push({ g: ros, aux: 0 });
  // antennae (long, thin, forward-up)
  for (const s of [-1, 1]) {
    const a = new THREE.CylinderGeometry(0.012, 0.025, 2.2, 4);
    a.rotateZ(-Math.PI / 2 + 0.55);
    a.translate(2.0, 1.0, s * 0.08);
    parts.push({ g: a, aux: 2 });
  }
  // legs
  for (let i = 0; i < 5; i++) {
    const l = new THREE.CylinderGeometry(0.02, 0.02, 0.4, 4);
    l.rotateZ(0.5 - i * 0.2);
    l.translate(0.7 - i * 0.28, -0.1, (i % 2 ? 1 : -1) * 0.12);
    parts.push({ g: l, aux: 3 });
  }
  const g = mergeAux(parts);
  // ground the feet at y = 0
  g.computeBoundingBox();
  g.translate(0, -g.boundingBox!.min.y, 0);
  return g;
}

export class Critters {
  group = new THREE.Group();
  private disposables: { dispose: () => void }[] = [];

  constructor(fishSpots: Spot[], shrimpSpots: Spot[], rng: () => number, common: string) {
    // ---- damselfish
    if (fishSpots.length) {
      const g = fishGeometry();
      const n = fishSpots.length;
      const A = new Float32Array(n * 4),
        B = new Float32Array(n * 4);
      fishSpots.forEach((s, i) => {
        A.set([s.x, s.y, s.z, 10 + rng() * 16], i * 4);
        B.set([rng() * 100, 0.5 + rng() * 0.6, Math.floor(rng() * 5), 3.2 + rng() * 2.6], i * 4);
      });
      g.setAttribute("iA", new THREE.InstancedBufferAttribute(A, 4));
      g.setAttribute("iB", new THREE.InstancedBufferAttribute(B, 4));
      const m = new THREE.ShaderMaterial({ uniforms: { ...SHARED }, vertexShader: FISH_VS, fragmentShader: common + FISH_FS, side: THREE.DoubleSide });
      const mesh = new THREE.InstancedMesh(g, m, n);
      const mtx = new THREE.Matrix4();
      for (let i = 0; i < n; i++) mesh.setMatrixAt(i, mtx);
      mesh.frustumCulled = false;
      mesh.renderOrder = 14;
      this.group.add(mesh);
      this.disposables.push(g, m);
    }
    // ---- shrimp
    if (shrimpSpots.length) {
      const g = shrimpGeometry();
      const n = shrimpSpots.length;
      const A = new Float32Array(n * 4),
        B = new Float32Array(n * 4);
      shrimpSpots.forEach((s, i) => {
        A.set([s.x, s.y, s.z, rng() < 0.5 ? 1 : -1], i * 4);
        B.set([rng() * 100, 1.6 + rng() * 1.2, (s.tilt ?? 0) * 0.8, 0], i * 4);
      });
      g.setAttribute("iA", new THREE.InstancedBufferAttribute(A, 4));
      g.setAttribute("iB", new THREE.InstancedBufferAttribute(B, 4));
      const m = new THREE.ShaderMaterial({
        uniforms: { ...SHARED },
        vertexShader: SHRIMP_VS,
        fragmentShader: common + SHRIMP_FS,
        side: THREE.DoubleSide,
        transparent: true,
        depthWrite: false,
        blending: THREE.CustomBlending,
        blendEquation: THREE.AddEquation,
        blendSrc: THREE.OneFactor,
        blendDst: THREE.OneMinusSrcAlphaFactor,
      });
      const mesh = new THREE.InstancedMesh(g, m, n);
      const mtx = new THREE.Matrix4();
      for (let i = 0; i < n; i++) mesh.setMatrixAt(i, mtx);
      mesh.frustumCulled = false;
      mesh.renderOrder = 15;
      this.group.add(mesh);
      this.disposables.push(g, m);
    }
  }

  dispose() {
    for (const d of this.disposables) d.dispose();
  }
}
