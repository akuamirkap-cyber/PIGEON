import { useCallback, useEffect, useRef, useState } from 'react';
import bgUrl from './assets/bg.jpg';
import shadowUrl from './assets/shadow.jpg';
import titanUrl from './assets/titan.jpg';
import { Sound } from './game/audio';
import { CONFIG, OpponentKey } from './game/config';
import { AnnKind, Game, Hud, RoundResult } from './game/game';
import { TouchControls } from './ui/TouchControls';

type Screen = 'menu' | 'play' | 'end';
type Level = 'easy' | 'normal' | 'hard';
interface Ann {
  text: string;
  kind: AnnKind;
  id: number;
}

const LEVEL_LABEL: Record<Level, string> = { easy: 'Mudah', normal: 'Normal', hard: 'Sulit' };
const OPP_INFO: Record<OpponentKey, { note: string; img: string; cls: string }> = {
  ronin: { note: 'Petarung biasa · bisa dilucuti (Shock)', img: shadowUrl, cls: 'pf-ronin' },
  gatekeeper: { note: 'Gatekeeper · kebal Head Hit · anti-jatuh', img: titanUrl, cls: 'pf-gate' },
  titan: { note: 'Boss · kebal Shock · pukulan terkeras', img: titanUrl, cls: '' },
};
const HUD0: Hud = {
  hp: [1, 1], energy: [0, 0], armed: [true, true], names: ['SHADOW', 'TITAN'], rounds: [0, 0], round: 1, combo: 0, comboDmg: 0, timer: -1,
  ready: { jump: true, roll: true, flip: true, super: false },
};

const comboRank = (n: number) => (n >= 10 ? 'LEGENDARIS!' : n >= 7 ? 'BRUTAL!' : n >= 5 ? 'GANAS!' : n >= 3 ? 'BAGUS!' : '');

const loadCoins = (): number => {
  try {
    return Number(localStorage.getItem('sf_coins') ?? 0) || 0;
  } catch {
    return 0;
  }
};

function Bars({ hp, energy, side }: { hp: number; energy: number; side: 'l' | 'r' }) {
  const low = hp < 0.28;
  const full = energy >= 1;
  return (
    <>
      <div className={`bar bar-${side}`}>
        <div className="bar-ghost" style={{ transform: `scaleX(${hp})` }} />
        <div className={`bar-fill ${low ? 'bar-low' : ''}`} style={{ transform: `scaleX(${hp})` }} />
      </div>
      <div className={`ebar ebar-${side} ${full ? 'ebar-full' : ''}`} title="Shadow Energy">
        <div className="ebar-fill" style={{ transform: `scaleX(${energy})` }} />
      </div>
    </>
  );
}

function Marks({ won, side }: { won: number; side: 'l' | 'r' }) {
  return (
    <div className={`marks marks-${side}`}>
      {Array.from({ length: CONFIG.round.roundsToWin }, (_, i) => (
        <span key={i} className={`mark ${i < won ? 'mark-on' : ''}`} />
      ))}
    </div>
  );
}

/** on-screen control hints */
function Legend({ ready }: { ready: Hud['ready'] }) {
  const item = (keys: string[], label: string, cls = '') => (
    <span className={`lg ${cls}`}>
      {keys.map((k, i) => (
        <kbd key={i}>{k}</kbd>
      ))}
      <i>{label}</i>
    </span>
  );
  return (
    <div className="legend">
      {item(['A', 'D'], 'Mundur / Maju · tahan D = lari')}
      {item(['D', 'D'], 'Frontflip', ready.flip ? '' : 'lg-cd')}
      {item(['A', 'A'], 'Backflip', ready.flip ? '' : 'lg-cd')}
      {item(['W'], 'Lompat', ready.jump ? '' : 'lg-cd')}
      {item(['S'], 'Jongkok')}
      {item(['J'], 'Pukul')}
      {item(['K'], 'Tendang')}
      {item(['H'], 'Serangan berat')}
      {item(['J', 'K', 'H'], 'campur = kombo')}
      {item(['F'], 'Freestyle')}
      {item(['L'], 'Lempar')}
      {item(['Shift'], 'Blok')}
      {item(['Q'], 'Roll', ready.roll ? '' : 'lg-cd')}
      {item(['Space'], 'Super Strike', ready.super ? 'lg-super' : 'lg-cd')}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const soundRef = useRef<Sound>(new Sound());
  const screenRef = useRef<Screen>('menu');
  const levelRef = useRef<Level>('normal');
  const oppRef = useRef<OpponentKey>('titan');

  const [screen, setScreenState] = useState<Screen>('menu');
  const [hud, setHud] = useState<Hud>(HUD0);
  const [ann, setAnn] = useState<Ann | null>(null);
  const [paused, setPaused] = useState(false);
  const [won, setWon] = useState(false);
  const [results, setResults] = useState<RoundResult[]>([]);
  const [coins, setCoins] = useState<number>(loadCoins);
  const [level, setLevelState] = useState<Level>('normal');
  const [opp, setOppState] = useState<OpponentKey>('titan');
  const [muted, setMuted] = useState(false);
  const [touch, setTouch] = useState(false);
  const [help, setHelp] = useState(false);
  const [fatal, setFatal] = useState<string | null>(null);

  const setScreen = (s: Screen) => {
    screenRef.current = s;
    setScreenState(s);
  };
  const setLevel = (l: Level) => {
    levelRef.current = l;
    setLevelState(l);
    soundRef.current.init();
    soundRef.current.play('ui');
  };
  const setOpp = (o: OpponentKey) => {
    oppRef.current = o;
    setOppState(o);
    soundRef.current.init();
    soundRef.current.play('ui');
  };

  const start = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    const snd = soundRef.current;
    snd.init();
    snd.startMusic();
    setHud({ ...HUD0, names: [CONFIG.player.name, CONFIG.opponents[oppRef.current].name] });
    setAnn(null);
    setPaused(false);
    setScreen('play');
    g.startMatch(levelRef.current, oppRef.current);
  }, []);

  const toMenu = useCallback(() => {
    const g = gameRef.current;
    if (!g) return;
    g.paused = false;
    g.startAttract();
    soundRef.current.stopMusic();
    setPaused(false);
    setAnn(null);
    setScreen('menu');
  }, []);

  const togglePause = useCallback(() => {
    const g = gameRef.current;
    if (!g || screenRef.current !== 'play') return;
    g.paused = !g.paused;
    setPaused(g.paused);
    soundRef.current.play('ui');
  }, []);

  const toggleMute = () => {
    const m = !muted;
    setMuted(m);
    soundRef.current.init();
    soundRef.current.setMuted(m);
  };

  useEffect(() => {
    const cv = canvasRef.current!;
    const ctx = cv.getContext('2d')!;
    const snd = soundRef.current;
    let annId = 0;
    const game = new Game({
      hud: (h) => setHud(h),
      announce: (text, kind) => setAnn({ text, kind, id: ++annId }),
      end: (w, res) => {
        setWon(w);
        setResults(res);
        const gained = res.reduce((s, r) => s + r.total, 0);
        setCoins((c) => {
          const total = c + gained;
          try {
            localStorage.setItem('sf_coins', String(total));
          } catch {
            /* storage unavailable */
          }
          return total;
        });
        setScreen('end');
        snd.play(w ? 'win' : 'lose');
      },
      sfx: (n, v) => snd.play(n, v),
    });
    gameRef.current = game;

    const img = new Image();
    img.onload = () => {
      game.bg = img;
      game.bgW = img.naturalWidth;
      game.bgH = img.naturalHeight;
    };
    img.src = bgUrl;

    let k = 1;
    let ready = false;
    let lastW = -1;
    let lastH = -1;
    const resize = () => {
      const w = window.innerWidth, h = window.innerHeight;
      lastW = w;
      lastH = h;
      // the page can be loaded while its frame is still hidden (0 × 0): wait until it has a real size
      if (!(w > 0 && h > 0)) {
        ready = false;
        return;
      }
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const viewW = Math.max(960, Math.min(1800, (720 * w) / h));
      const scale = w / viewW;
      cv.width = Math.max(1, Math.round(w * dpr));
      cv.height = Math.max(1, Math.round(h * dpr));
      game.setView(viewW, h / scale);
      k = scale * dpr;
      ready = true;
    };
    resize();
    window.addEventListener('resize', resize);

    let raf = 0;
    let last = performance.now();
    let failures = 0;
    const loop = (now: number) => {
      // schedule the next frame FIRST: whatever happens below, the game can never stop for good
      raf = requestAnimationFrame(loop);
      if (window.innerWidth !== lastW || window.innerHeight !== lastH) resize();
      const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
      last = now;
      if (!ready) return;
      try {
        game.update(dt);
        ctx.setTransform(k, 0, 0, k, 0, 0);
        game.render(ctx);
        failures = 0;
      } catch (err) {
        // unwind whatever the broken frame left on the canvas state stack, repair the game and carry on
        for (let i = 0; i < 48; i++) ctx.restore();
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = 'source-over';
        try {
          game.recover();
        } catch {
          /* keep looping */
        }
        failures++;
        if (failures === 1) console.error('[game] frame failed:', err);
        if (failures === 90) setFatal(err instanceof Error ? err.message : String(err));
      }
    };
    raf = requestAnimationFrame(loop);

    // ── keyboard: A/D move, W jump, S crouch, J punch, K kick, L throw, Shift block, Q roll, E flip, Space super ──
    const P = game.player;
    const hold = (code: string, v: boolean): boolean => {
      switch (code) {
        case 'KeyA': case 'ArrowLeft': P.l = v; return true;
        case 'KeyD': case 'ArrowRight': P.r = v; return true;
        case 'KeyW': case 'ArrowUp': P.u = v; return true;
        case 'KeyS': case 'ArrowDown': P.d = v; return true;
        case 'ShiftLeft': case 'ShiftRight': P.block = v; return true;
      }
      return false;
    };
    const BUF = 0.22;
    // double-tap a direction = flip that way: towards the opponent = front flip, away = back flip
    const dirOf = (c: string) => (c === 'KeyD' || c === 'ArrowRight' ? 1 : c === 'KeyA' || c === 'ArrowLeft' ? -1 : 0);
    const TAP = CONFIG.movement.flip.doubleTap * 1000;
    let tapDir = 0;
    let tapT = 0;
    const kd = (e: KeyboardEvent) => {
      if (hold(e.code, true)) {
        e.preventDefault();
        const d = dirOf(e.code);
        if (!e.repeat && d !== 0) {
          const now = performance.now();
          if (tapDir === d && now - tapT < TAP) {
            P.flip = BUF;
            P.flipDir = d;
            tapDir = 0;
          } else {
            tapDir = d;
            tapT = now;
          }
        }
        return;
      }
      if (e.repeat) { if (e.code === 'Space') e.preventDefault(); return; }
      switch (e.code) {
        case 'KeyJ': P.punch = BUF; break;
        case 'KeyK': P.kick = BUF; break;
        case 'KeyH': P.heavy = BUF; break;
        case 'KeyF': P.style = BUF; break;
        case 'KeyL': P.throw = BUF; break;
        case 'KeyQ': P.roll = BUF; break;
        case 'KeyE': P.flip = BUF; P.flipDir = 0; break; // flip in the held direction
        case 'Space':
          e.preventDefault();
          if (screenRef.current === 'menu') start();
          else P.super = BUF;
          break;
        case 'Enter': if (screenRef.current === 'menu') start(); break;
        case 'Escape': case 'KeyP': togglePause(); break;
      }
    };
    const ku = (e: KeyboardEvent) => { hold(e.code, false); };
    const blur = () => { P.l = P.r = P.u = P.d = P.block = false; };
    const onTouch = () => setTouch(true);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    window.addEventListener('blur', blur);
    window.addEventListener('touchstart', onTouch, { passive: true });
    if (window.matchMedia?.('(pointer: coarse)').matches) setTouch(true);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('blur', blur);
      window.removeEventListener('touchstart', onTouch);
      snd.stopMusic();
      gameRef.current = null;
    };
  }, [start, togglePause]);

  const C = CONFIG;
  const pct = (v: number) => `${Math.round(v * 100)}%`;
  const controls = (
    <div className="keys">
      <div className="keys-grid">
        <span><kbd>A</kbd><kbd>D</kbd> Mundur / Maju <em>tahan maju = lari otomatis</em></span>
        <span><kbd>D</kbd><kbd>D</kbd> Frontflip <em>ketuk 2×</em></span>
        <span><kbd>A</kbd><kbd>A</kbd> Backflip <em>ketuk 2×</em></span>
        <span><kbd>W</kbd> Lompat</span>
        <span><kbd>S</kbd> Jongkok</span>
        <span><kbd>J</kbd> Pukul <em>cepat, damage kecil</em></span>
        <span><kbd>K</kbd> Tendang <em>lebih lambat, lebih jauh</em></span>
        <span><kbd>H</kbd> Serangan berat <em>paling lambat, damage besar</em></span>
        <span><kbd>F</kbd> Freestyle <em>trik pamer, +energi</em></span>
        <span><kbd>L</kbd> Lempar <em>menembus blok</em></span>
        <span><kbd>Shift</kbd> Blok <em>tahan</em></span>
        <span><kbd>Q</kbd> Roll <em>kebal sesaat</em></span>
        <span><kbd>E</kbd> Flip <em>ke arah yang ditahan</em></span>
        <span><kbd>Space</kbd> Super Strike <em>energi penuh</em></span>
      </div>
      <div className="keys-combo">
        <b>Kombo</b> – campur <kbd>J</kbd> <kbd>K</kbd> <kbd>H</kbd> sesukamu (maks. {C.combo.maxString} jurus); tiap urutan memberi jurus berbeda:<br />
        <kbd>J</kbd><kbd>J</kbd><kbd>J</kbd><kbd>J</kbd> tebas · sabet · putar · banting<br />
        <kbd>K</kbd><kbd>K</kbd><kbd>K</kbd><kbd>K</kbd> tendang · putar belakang · lutut terbang · tendangan kapak<br />
        <kbd>H</kbd><kbd>H</kbd><kbd>H</kbd> belah gunung · tebasan langit · roda maut <em>(kombo berat)</em><br />
        <kbd>J</kbd><kbd>K</kbd><kbd>J</kbd><kbd>J</kbd> &nbsp; <kbd>K</kbd><kbd>J</kbd><kbd>K</kbd><kbd>K</kbd> &nbsp; <kbd>J</kbd><kbd>J</kbd><kbd>H</kbd><kbd>H</kbd> &nbsp;
        <kbd>J</kbd><kbd>H</kbd><kbd>H</kbd><kbd>H</kbd> &nbsp; <kbd>K</kbd><kbd>K</kbd><kbd>H</kbd> &nbsp; <kbd>H</kbd><kbd>K</kbd><kbd>K</kbd> …<br />
        <kbd>H</kbd> setelah tebasan = jurus berat senjata, setelah tendangan = tendangan topan. <b>↑</b>/<b>↓</b> + tombol di tengah kombo =
        jurus penutup. <b>↑J</b> / <b>↑H</b> / lutut terbang melambungkan lawan → serang lagi selagi ia melayang (<b>juggle</b>, maks.{' '}
        {C.combo.juggleMax}×). <kbd>Space</kbd> saat serangan kena = langsung Super Strike.<br />
        <b>Freestyle</b> – tiap sambungan otomatis diberi gerakan gaya sesuai transisinya: bilah digulung (→<kbd>J</kbd>), pirouette
        (→<kbd>K</kbd>), kitiran di atas kepala (→<kbd>H</kbd>); kombo yang kena ditutup gulungan bilah. <kbd>F</kbd> = trik pamer
        (kincir · putaran · salto) yang mengisi Shadow Energy dan bisa langsung disambung serangan.
      </div>
      <div className="keys-note">
        <b>Head Hit</b> +{pct(C.headHit.bonus)} damage · <b>Critical</b> {pct(C.crit.chance)} peluang: +{pct(C.crit.bonus)} &amp; lawan jatuh ·
        <b> Shock</b> {pct(C.shock.chance)} peluang head hit melucuti senjata · <b>First Strike</b> +{C.coins.firstStrike} koin ·
        <b> Combo</b> reset bila diblok / meleset, +{C.coins.perComboHit} koin × combo tertinggi · <b>Shadow Energy</b> terisi saat
        menyerang &amp; terkena serangan. Arah + J/K memberi variasi jurus (↑ ↓ →).
      </div>
    </div>
  );

  const oi = OPP_INFO[opp];
  const total = results.reduce((s, r) => s + r.total, 0);

  return (
    <div className="stage">
      <canvas ref={canvasRef} className="game-canvas" />
      <div className="rotate-hint">⟳ Putar perangkat ke posisi lanskap untuk pengalaman terbaik</div>

      {screen !== 'menu' && (
        <div className="hud">
          <img className="portrait" src={shadowUrl} alt="Shadow" draggable={false} />
          <div className="side side-l">
            <div className="name">
              {hud.names[0]}
              {!hud.armed[0] && <span className="unarmed">TANPA SENJATA</span>}
            </div>
            <Bars hp={hud.hp[0]} energy={hud.energy[0]} side="l" />
            <Marks won={hud.rounds[0]} side="l" />
          </div>
          <div className="center">
            {hud.timer >= 0 ? (
              <div className={`timer ${hud.timer <= 10 ? 'timer-low' : ''}`}>{String(hud.timer).padStart(2, '0')}</div>
            ) : (
              <div className="round-no">
                <small>RONDE</small>
                {hud.round}
              </div>
            )}
            <button className="pause-btn" onClick={togglePause} aria-label="Jeda">
              <span /><span />
            </button>
          </div>
          <div className="side side-r">
            <div className="name">
              {!hud.armed[1] && <span className="unarmed">TANPA SENJATA</span>}
              {hud.names[1]}
            </div>
            <Bars hp={hud.hp[1]} energy={hud.energy[1]} side="r" />
            <Marks won={hud.rounds[1]} side="r" />
          </div>
          <img className={`portrait ${oi.cls}`} src={oi.img} alt={hud.names[1]} draggable={false} />
        </div>
      )}

      {screen === 'play' && hud.combo >= 2 && (
        <div className="combo" key={hud.combo}>
          <b>{hud.combo}</b> COMBO
          <span className="combo-rank">{comboRank(hud.combo)}</span>
          <span className="combo-dmg">{hud.comboDmg} damage</span>
        </div>
      )}

      {screen === 'play' && hud.ready.super && !paused && <div className="super-ready">SUPER STRIKE SIAP{!touch && ' — SPACE'}</div>}

      {screen !== 'menu' && ann && (
        <div key={ann.id} className="ann-wrap">
          {ann.kind === 'round' && <div className="fade-black" />}
          <div className={`ann ann-${ann.kind}`}>{ann.text}</div>
        </div>
      )}

      {screen === 'play' && !touch && !paused && <Legend ready={hud.ready} />}
      {screen === 'play' && touch && !paused && gameRef.current && <TouchControls input={gameRef.current.player} ready={hud.ready} />}

      {fatal && (
        <div className="overlay pause" style={{ zIndex: 50 }}>
          <div className="panel">
            <h2 style={{ fontSize: 'clamp(20px, 5vh, 34px)', letterSpacing: '0.2em' }}>ADA MASALAH</h2>
            <div className="hint" style={{ maxWidth: 520, textAlign: 'center' }}>Permainan tidak bisa digambar: {fatal}</div>
            <button className="btn-main" onClick={() => window.location.reload()}>MUAT ULANG</button>
          </div>
        </div>
      )}

      {screen === 'menu' && (
        <div className="overlay menu">
          <div className="menu-inner">
            <div className="title-sub">EDISI BROWSER</div>
            <h1 className="title">SHADOW FIGHT</h1>
            <div className="coins-top">◈ {coins} koin</div>

            <div className="opps">
              {(Object.keys(OPP_INFO) as OpponentKey[]).map((o) => (
                <button key={o} className={`opp ${opp === o ? 'opp-on' : ''}`} onClick={() => setOpp(o)}>
                  <img className={OPP_INFO[o].cls} src={OPP_INFO[o].img} alt="" draggable={false} />
                  <b>{C.opponents[o].name}</b>
                  <small>{OPP_INFO[o].note}</small>
                </button>
              ))}
            </div>
            <div className="levels">
              {(Object.keys(LEVEL_LABEL) as Level[]).map((l) => (
                <button key={l} className={`chip ${level === l ? 'chip-on' : ''}`} onClick={() => setLevel(l)}>
                  {LEVEL_LABEL[l]}
                </button>
              ))}
            </div>
            <button className="btn-main" onClick={start}>MULAI BERTARUNG</button>
            <button className="btn-link" onClick={() => setHelp((h) => !h)}>{help ? 'Tutup' : 'Kontrol & aturan'}</button>
            {help && controls}
            {!help && <div className="hint">Best of 3 · menangkan 2 ronde · <kbd>Enter</kbd> untuk mulai</div>}
          </div>
        </div>
      )}

      {screen === 'play' && paused && (
        <div className="overlay pause">
          <div className="panel">
            <h2>JEDA</h2>
            <button className="btn-main" onClick={togglePause}>LANJUTKAN</button>
            <button className="btn-ghost" onClick={start}>Ulangi pertarungan</button>
            <button className="btn-ghost" onClick={toggleMute}>Suara: {muted ? 'Mati' : 'Nyala'}</button>
            <button className="btn-ghost" onClick={toMenu}>Menu utama</button>
            {controls}
          </div>
        </div>
      )}

      {screen === 'end' && (
        <div className="overlay end">
          <div className="end-inner">
            <div className={`result ${won ? 'result-win' : 'result-lose'}`}>{won ? 'KEMENANGAN' : 'KALAH'}</div>
            <div className="result-sub">
              {won ? `${hud.names[1]} tumbang. Bayangan kembali berjaya.` : `${hud.names[1]} terlalu kuat… bangkit dan coba lagi.`}
            </div>
            <table className="res">
              <thead>
                <tr><th>Ronde</th><th>Hasil</th><th>First Strike</th><th>Combo tertinggi</th><th>Koin</th></tr>
              </thead>
              <tbody>
                {results.map((r) => (
                  <tr key={r.round}>
                    <td>{r.round}</td>
                    <td className={r.won ? 'ok' : 'no'}>{r.won ? `Menang +${r.coinsWin}` : 'Kalah'}</td>
                    <td className={r.firstStrike ? 'ok' : 'no'}>{r.firstStrike ? `Ya +${r.coinsFirst}` : '—'}</td>
                    <td>×{r.maxCombo} <span className="ok">+{r.coinsCombo}</span></td>
                    <td className="coin">◈ {r.total}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr><td colSpan={4}>Total pertarungan ini</td><td className="coin">◈ {total}</td></tr>
                <tr><td colSpan={4}>Dompet</td><td className="coin">◈ {coins}</td></tr>
              </tfoot>
            </table>
            <div className="end-btns">
              <button className="btn-main" onClick={start}>TANDING ULANG</button>
              <button className="btn-ghost" onClick={toMenu}>Menu utama</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
