import { Fighter, KICK_LIFE, TRAIL_LIFE } from './fighter';
import { TAU, V, clamp, hash, lerp } from './math';
import { Chain } from './ragdoll';
import {
  ANB, ANF, ELB, ELF, HAB, HAF, HEAD, KNB, KNF, NECK, PELVIS, TIP, TOB, TOF, WBASE,
} from './skeleton';

type Ctx = CanvasRenderingContext2D;

const INK = '#000000';
const INK_BACK = '#0f0a05';

// ───────────────────────── primitives ─────────────────────────
function limb(ctx: Ctx, ax: number, ay: number, bx: number, by: number, r1: number, r2: number, bulge = 0) {
  const dx = bx - ax, dy = by - ay;
  const len = Math.hypot(dx, dy);
  if (len < 0.01) {
    ctx.beginPath();
    ctx.arc(ax, ay, Math.max(r1, r2), 0, TAU);
    ctx.fill();
    return;
  }
  const nx = -dy / len, ny = dx / len;
  const ang = Math.atan2(dy, dx);
  const mx = (ax + bx) / 2, my = (ay + by) / 2;
  const rm = (r1 + r2) / 2 + bulge;
  ctx.beginPath();
  ctx.moveTo(ax + nx * r1, ay + ny * r1);
  ctx.quadraticCurveTo(mx + nx * rm, my + ny * rm, bx + nx * r2, by + ny * r2);
  ctx.arc(bx, by, r2, ang + Math.PI / 2, ang - Math.PI / 2, true);
  ctx.quadraticCurveTo(mx - nx * rm, my - ny * rm, ax - nx * r1, ay - ny * r1);
  ctx.arc(ax, ay, r1, ang - Math.PI / 2, ang + Math.PI / 2, true);
  ctx.closePath();
  ctx.fill();
}

function dot(ctx: Ctx, x: number, y: number, r: number) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
}

function poly(ctx: Ctx, pts: number[]) {
  ctx.beginPath();
  ctx.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
  ctx.closePath();
  ctx.fill();
}

function smoothPoly(ctx: Ctx, pts: number[]) {
  const n = pts.length / 2;
  ctx.beginPath();
  ctx.moveTo((pts[0] + pts[2]) / 2, (pts[1] + pts[3]) / 2);
  for (let i = 1; i <= n; i++) {
    const a = (i % n) * 2, b = ((i + 1) % n) * 2;
    ctx.quadraticCurveTo(pts[a], pts[a + 1], (pts[a] + pts[b]) / 2, (pts[a + 1] + pts[b + 1]) / 2);
  }
  ctx.closePath();
  ctx.fill();
}

type Pt = (x: number, y: number) => [number, number];
type Cmds = (string | number)[];

/** tiny path language: M x y · L x y · Q cx cy x y · Z – points are mapped through P */
function trace(ctx: Ctx, c: Cmds, P: Pt) {
  let i = 0;
  while (i < c.length) {
    const op = c[i++];
    if (op === 'M') {
      const p = P(c[i++] as number, c[i++] as number);
      ctx.moveTo(p[0], p[1]);
    } else if (op === 'L') {
      const p = P(c[i++] as number, c[i++] as number);
      ctx.lineTo(p[0], p[1]);
    } else if (op === 'Q') {
      const a = P(c[i++] as number, c[i++] as number);
      const p = P(c[i++] as number, c[i++] as number);
      ctx.quadraticCurveTo(a[0], a[1], p[0], p[1]);
    } else ctx.closePath();
  }
}

function shape(ctx: Ctx, c: Cmds, P: Pt) {
  ctx.beginPath();
  trace(ctx, c, P);
  ctx.fill();
}

/** cloth / hair strip following a chain, drawn as one smooth tapered shape */
function ribbon(ctx: Ctx, c: Chain, s: number) {
  const n = c.n;
  const pts: number[] = [];
  const back: number[] = [];
  for (let i = 0; i < n; i++) {
    const a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
    let tx = c.x[b] - c.x[a], ty = c.y[b] - c.y[a];
    const l = Math.hypot(tx, ty) || 1;
    tx /= l; ty /= l;
    const w = lerp(c.w0, c.w1, i / (n - 1)) * s * 0.5;
    pts.push(c.x[i] - ty * w, c.y[i] + tx * w);
    back.push(c.x[i] + ty * w, c.y[i] - tx * w);
  }
  for (let i = n - 1; i >= 0; i--) pts.push(back[i * 2], back[i * 2 + 1]);
  smoothPoly(ctx, pts);
  dot(ctx, c.x[0], c.y[0], c.w0 * s * 0.5);
}

// ───────────────────────── weapons ─────────────────────────
// local space: x runs from the hand to the tip, +y is the cutting edge

/** Shadow: curved sabre – saw-toothed spine, swelling belly, up-swept clip point */
const SABER: Cmds = [
  'M', 4, -5, 'L', 24, -6.5,
  'L', 29, -11.2, 'L', 34, -6.8, 'L', 39, -11.8, 'L', 44, -7.2, 'L', 49, -12.4, 'L', 54, -7.8, 'L', 59, -13, 'L', 64, -8.6,
  'Q', 84, -11.5, 109, -11,
  'Q', 104, 2, 90, 8.6,
  'Q', 62, 13.6, 32, 10,
  'Q', 14, 8.5, 4, 7, 'Z',
];
const SABER_GUARD: Cmds = ['M', 0, -10.5, 'Q', 4.5, -12, 6.5, -9, 'L', 6.5, 10, 'Q', 4.5, 13, 0, 11.5, 'Z'];

/** Titan: great sword – hooked barbs on the spine, heavy belly, breaker notch and a fullered slot */
const GREAT: Cmds = [
  'M', 9, -9, 'L', 34, -10.5, 'L', 40, -17.5, 'L', 47, -11,
  'L', 96, -13.5, 'L', 104, -22, 'L', 110, -13,
  'Q', 125, -11, 137, -2,
  'L', 128, 9,
  'Q', 118, 23, 100, 21,
  'L', 62, 17, 'L', 56, 10.5, 'L', 49, 17.5, 'L', 16, 14,
  'Q', 9, 13, 9, 9, 'Z',
  // slot
  'M', 60, 2, 'Q', 60, -1.6, 64, -1.6, 'L', 90, -2.6, 'Q', 94, -2.6, 94, 1.4, 'Q', 94, 5, 90, 5, 'L', 64, 5.6, 'Q', 60, 5.6, 60, 2, 'Z',
];
const GREAT_GUARD: Cmds = ['M', -3, -9, 'L', 2, -12, 'L', 8, -27, 'L', 11.5, -11, 'L', 11.5, 12, 'L', 8, 29, 'L', 2, 13, 'L', -3, 10, 'Z'];
const GREAT_POMMEL: Cmds = ['M', -27, -6.5, 'L', -42, 0, 'L', -27, 6.5, 'L', -24, 0, 'Z'];

/** draws a weapon between an explicit grip and tip – also used for weapons knocked out of a hand */
export function drawWeaponAt(
  ctx: Ctx, kind: 'shadow' | 'titan', bx: number, by: number, tx: number, ty: number, facing: number, s: number, wLen: number, proj = wLen, grow = 1,
) {
  let dx = tx - bx, dy = ty - by;
  const l = Math.hypot(dx, dy) || 1;
  dx /= l; dy /= l;
  const nx = -dy * facing, ny = dx * facing;
  if (kind === 'titan') {
    const k = wLen / 128, ky = (0.5 + 0.5 * k) * grow, kx = proj / 128;
    const P: Pt = (x, y) => [bx + (dx * x * kx + nx * y * ky) * s, by + (dy * x * kx + ny * y * ky) * s];
    const G: Pt = (x, y) => [bx + (dx * x + nx * y) * s, by + (dy * x + ny * y) * s];
    ctx.beginPath();
    trace(ctx, GREAT, P);
    const h = P(110, 4);
    ctx.moveTo(h[0] + 3.6 * s * k, h[1]);
    ctx.arc(h[0], h[1], 3.6 * s * k, 0, TAU);
    ctx.fill('evenodd');
    shape(ctx, GREAT_GUARD, G);
    shape(ctx, GREAT_POMMEL, G);
    const h0 = G(-28, 0), h1 = G(8, 0);
    limb(ctx, h0[0], h0[1], h1[0], h1[1], 4.3 * s, 4.8 * s);
  } else {
    const k = wLen / 104, ky = (0.55 + 0.45 * k) * grow, kx = proj / 104;
    const P: Pt = (x, y) => [bx + (dx * x * kx + nx * y * ky) * s, by + (dy * x * kx + ny * y * ky) * s];
    const G: Pt = (x, y) => [bx + (dx * x + nx * y) * s, by + (dy * x + ny * y) * s];
    shape(ctx, SABER, P);
    shape(ctx, SABER_GUARD, G);
    const h0 = G(-19, 0), h1 = G(4, 0);
    limb(ctx, h0[0], h0[1], h1[0], h1[1], 3 * s, 3.6 * s);
    const r = G(-24.6, 0);
    ctx.lineWidth = 2.5 * s;
    ctx.beginPath();
    ctx.arc(r[0], r[1], 4.6 * s, 0, TAU);
    ctx.stroke();
  }
}

/** a weapon lying / flying on its own (after a SHOCK) */
export function drawProp(ctx: Ctx, kind: 'shadow' | 'titan', bx: number, by: number, tx: number, ty: number, facing: number, s: number, wLen: number) {
  ctx.fillStyle = INK;
  ctx.strokeStyle = INK;
  drawWeaponAt(ctx, kind, bx, by, tx, ty, facing, s, wLen);
}

// ───────────────────────── fighter ─────────────────────────
/** ghost = afterimage: the body only, without cloth, hair or glowing details */
export function drawFighter(ctx: Ctx, f: Fighter, ghost = false) {
  const j = f.j, b = f.build, s = b.scale, th = b.thick * s, fc = f.facing;
  const titan = b.kind === 'titan';
  const pv = j[PELVIS], nk = j[NECK], hd = j[HEAD];
  const ex = f.ex, jz = ex.z;
  const shF = ex.shF, shB = ex.shB, hpF = ex.hpF, hpB = ex.hpB;
  // body yaw: cos = how much of the profile is visible, sin = how much of the front / back
  const cT = Math.cos(ex.tw), sT = Math.abs(Math.sin(ex.tw));
  const cH = Math.cos(ex.hw), sH = Math.abs(Math.sin(ex.hw));
  const cY = Math.cos(ex.hy);
  /** cheap perspective: whatever is nearer to the camera is drawn a little bigger */
  const pz = (z: number) => 1 + clamp(z, -110, 110) * 0.0038;

  // torso frame
  let ux = nk.x - pv.x, uy = nk.y - pv.y;
  const ul = Math.hypot(ux, uy) || 1;
  ux /= ul; uy /= ul;
  const fx = -uy * fc, fy = ux * fc; // towards the chest
  // head frame
  let hx = hd.x - nk.x, hy = hd.y - nk.y;
  const hl = Math.hypot(hx, hy) || 1;
  hx /= hl; hy /= hl;
  const hfx = -hy * fc, hfy = hx * fc; // towards the face

  /** torso space: t along the spine (0 pelvis … 1 shoulders), o towards the chest */
  const T: Pt = (t, o) => [pv.x + ux * ul * t + fx * o * th, pv.y + uy * ul * t + fy * o * th];
  /** head space: u up, o towards the face – the profile flattens as the head turns */
  const H: Pt = (u, o) => [hd.x + hx * u * s + hfx * o * cY * s, hd.y + hy * u * s + hfy * o * cY * s];
  /** shoulder armour rides on the weapon-side shoulder */
  const sdx = shF.x - nk.x, sdy = shF.y - nk.y;
  const TS: Pt = (t, o) => {
    const q = T(t, o);
    return [q[0] + sdx, q[1] + sdy];
  };

  const arm = (sh: V, el: V, ha: V, z0: number, z1: number, z2: number) => {
    const ath = titan ? th * 0.8 : th;
    const k0 = pz(z0), k1 = pz(z1), k2 = pz(z2);
    limb(ctx, sh.x, sh.y, el.x, el.y, 11.5 * ath * k0, 8 * ath * k1, 1.4 * ath);
    if (titan) {
      let ax = el.x - sh.x, ay = el.y - sh.y;
      const al = Math.hypot(ax, ay) || 1;
      ax /= al; ay /= al;
      let qx = ha.x - el.x, qy = ha.y - el.y;
      const ql = Math.hypot(qx, qy) || 1;
      qx /= ql; qy /= ql;
      // elbow cop
      let cx = ax - qx, cy = ay - qy;
      const cl = Math.hypot(cx, cy);
      if (cl > 0.35) {
        cx /= cl; cy /= cl;
        poly(ctx, [el.x - cy * 7 * s, el.y + cx * 7 * s, el.x + cx * 19 * s, el.y + cy * 19 * s, el.x + cy * 7 * s, el.y - cx * 7 * s]);
      }
      // flared gauntlet + fist
      limb(ctx, el.x, el.y, ha.x, ha.y, 8 * ath * k1, 9.4 * ath * k2, 0.4 * ath);
      limb(ctx, ha.x, ha.y, ha.x + qx * 7 * ath, ha.y + qy * 7 * ath, 8.8 * ath * k2, 7.2 * ath * k2);
    } else {
      limb(ctx, el.x, el.y, ha.x, ha.y, 7.4 * th * k1, 5.4 * th * k2, 1.4 * th);
      dot(ctx, ha.x, ha.y, 6.4 * th * k2);
    }
  };
  const legD = (hp: V, kn: V, an: V, to: V, zk: number, za: number) => {
    const k1 = pz(zk), k2 = pz(za);
    limb(ctx, hp.x, hp.y, kn.x, kn.y, 14.5 * th, 9 * th * k1, 2.2 * th);
    limb(ctx, kn.x, kn.y, an.x, an.y, 8.8 * th * k1, 5.6 * th * k2, 2 * th);
    limb(ctx, an.x, an.y, to.x, to.y, 6 * th * k2, 3.6 * th * k2);
  };
  const weapon = () => {
    if (!f.armed) return;
    let bx = j[WBASE].x, by = j[WBASE].y, tx = j[TIP].x, ty = j[TIP].y;
    if (f.sheath > 0.01 && !f.rag) {
      // slung across the back while both hands are busy grappling
      const a = T(1.3, -21 * cT), c = T(0.1, -6 * cT);
      const dx = c[0] - a[0], dy = c[1] - a[1];
      const l = Math.hypot(dx, dy) || 1, L = b.wLen * s, k = f.sheath;
      bx = lerp(bx, a[0], k); by = lerp(by, a[1], k);
      tx = lerp(tx, a[0] + (dx / l) * L, k); ty = lerp(ty, a[1] + (dy / l) * L, k);
    }
    // a blade that swings out of the picture plane is foreshortened
    // … and looks bigger while it points at the camera
    const grow = 1 + clamp((jz[TIP] + jz[HAF]) / 2, -90, 110) * 0.004 * (1 - f.sheath);
    drawWeaponAt(ctx, b.kind, bx, by, tx, ty, fc, s, b.wLen, Math.hypot(tx - bx, ty - by) / s, grow);
  };
  const weaponArm = () => {
    weapon();
    arm(shF, j[ELF], j[HAF], ex.zsF, jz[ELF], jz[HAF]);
  };
  const offArm = () => arm(shB, j[ELB], j[HAB], ex.zsB, jz[ELB], jz[HAB]);
  const frontLeg = () => {
    legD(hpF, j[KNF], j[ANF], j[TOF], jz[KNF], jz[ANF]);
    if (titan) {
      // knee spike
      const kn = j[KNF], an = j[ANF];
      let lx = an.x - kn.x, ly = an.y - kn.y;
      const ll = Math.hypot(lx, ly) || 1;
      lx /= ll; ly /= ll;
      const qx = ly * fc, qy = -lx * fc;
      poly(ctx, [kn.x - lx * 7 * s, kn.y - ly * 7 * s, kn.x + qx * 21 * s - lx * 4 * s, kn.y + qy * 21 * s - ly * 4 * s, kn.x + lx * 13 * s, kn.y + ly * 13 * s]);
    }
  };
  const backLeg = () => legD(hpB, j[KNB], j[ANB], j[TOB], jz[KNB], jz[ANB]);

  // depth sorting: limbs that swing to the other side of the body change layer
  const wArmBack = jz[HAF] < -16;
  const oArmFront = jz[HAB] > 16;
  const fLegBack = jz[ANF] < -18;
  const bLegFront = jz[ANB] > 18;

  // ── back layer ──
  ctx.fillStyle = INK_BACK;
  ctx.strokeStyle = INK_BACK;
  if (ghost) {
    // no cloth on an afterimage
  } else if (titan) {
    const c0 = f.chains[0], c2 = f.chains[2];
    ctx.beginPath();
    ctx.moveTo(c0.x[0], c0.y[0]);
    for (let i = 1; i < c0.n; i++) ctx.lineTo(c0.x[i], c0.y[i]);
    for (let i = c2.n - 1; i >= 0; i--) ctx.lineTo(c2.x[i], c2.y[i]);
    ctx.closePath();
    ctx.fill();
    for (const c of f.chains) ribbon(ctx, c, s);
  } else {
    ribbon(ctx, f.chains[1], s);
  }
  if (!oArmFront) offArm();
  if (wArmBack) weaponArm();
  if (!bLegFront) backLeg();
  if (fLegBack) frontLeg();

  // ── body ──
  ctx.fillStyle = INK;
  ctx.strokeStyle = INK;
  if (!titan) {
    // scabbard strapped across the back
    const a = T(1.3, -22 * cT), c = T(0.2, -5 * cT);
    limb(ctx, a[0], a[1], c[0], c[1], 3 * s, 3.6 * s);
    const k = T(1.43, -25 * cT);
    limb(ctx, a[0], a[1], k[0], k[1], 4.4 * s, 2.4 * s);
  }
  {
    // the trunk is a blend of its profile (chest / back) and its front view, depending on the yaw
    const ts = [-0.1, 0.3, 0.72, 1.0, 1.1];
    const fr = titan ? [11, 13, 19, 13, 6] : [10.5, 11, 19.5, 13, 6];
    const bk = titan ? [14, 12, 17, 16, 8] : [14, 9.5, 15.5, 14, 7];
    const lat = titan ? [15, 13.5, 20, 16, 7] : [13, 11, 18.5, 14.5, 6.5];
    const pts: number[] = [];
    const back: number[] = [];
    for (let i = 0; i < ts.length; i++) {
      const w = clamp((ts[i] - 0.2) / 0.5, 0, 1);
      const c = lerp(cH, cT, w), sn = lerp(sH, sT, w), ac = Math.abs(c);
      const q = T(ts[i], (c >= 0 ? fr[i] : bk[i]) * ac + lat[i] * sn);
      pts.push(q[0], q[1]);
      const r = T(ts[i], -((c >= 0 ? bk[i] : fr[i]) * ac + lat[i] * sn));
      back.push(r[0], r[1]);
    }
    for (let i = ts.length - 1; i >= 0; i--) pts.push(back[i * 2], back[i * 2 + 1]);
    smoothPoly(ctx, pts);
    // shoulder girdle and hips: two joints each that spread apart as the body turns
    const waist = T(0.3, 0);
    limb(ctx, shF.x, shF.y, waist[0], waist[1], 11.5 * th, 9.5 * th);
    limb(ctx, shB.x, shB.y, waist[0], waist[1], 11.5 * th, 9.5 * th);
    limb(ctx, shB.x, shB.y, shF.x, shF.y, 12 * th, 12 * th);
    limb(ctx, hpB.x, hpB.y, hpF.x, hpF.y, 13 * th, 13 * th);
    dot(ctx, nk.x, nk.y, 12 * th);
  }

  // neck + head
  limb(ctx, nk.x, nk.y, hd.x, hd.y, 7.5 * th, 6.5 * th);
  const ha = Math.atan2(hy, hx) + Math.PI / 2;
  if (titan) {
    // horned great helm: beaked visor, heavy jaw guard, swept horns and a blade crest
    ctx.beginPath();
    ctx.ellipse(hd.x, hd.y, 13 * s, 15.5 * s, ha, 0, TAU);
    ctx.fill();
    shape(ctx, [
      'M', -12, -14, 'L', 5, -17.5, 'Q', 14, -16, 17, -9, 'Q', 20.5, 0, 14, 12,
      'L', 6, 20.5, 'L', 1.5, 15, 'L', -4, 17, 'L', -16.5, 13, 'Q', -19.5, 6, -17.5, 0, 'L', -13, -8, 'Z',
    ], H);
    shape(ctx, ['M', 13, 6, 'Q', 29, 19, 42, 5, 'Q', 27, 9.5, 16, -2, 'Z'], H); // front horn
    shape(ctx, ['M', 13, -4, 'Q', 25, -8, 32, -26, 'Q', 19, -16, 7, -14, 'Z'], H); // rear horn
    shape(ctx, ['M', 17, -8, 'L', 46, -10, 'Q', 31, -1, 18.5, 4, 'Z'], H); // crest
    shape(ctx, ['M', -6, -13, 'L', -16, -21, 'L', -13, -9, 'Z'], H); // nape spike
  } else {
    // sleek helm: brow ridge, masked jaw with a sharp chin, flared neck guard, top knot
    ctx.beginPath();
    ctx.ellipse(hd.x, hd.y, 12.4 * s, 14.4 * s, ha, 0, TAU);
    ctx.fill();
    shape(ctx, [
      'M', 11.5, 8.5, 'L', 6.4, 12.9, 'L', 4.4, 12, 'L', 0.6, 15.4, 'L', -2.6, 13.2,
      'Q', -6.5, 13.8, -10, 12.2, 'L', -14.6, 8.2, 'Q', -14.4, 2, -10.5, -3, 'L', -2, -5, 'Z',
    ], H);
    shape(ctx, ['M', 1, -11.5, 'Q', -6, -13, -11.5, -15.5, 'Q', -11.5, -9, -8.5, -4.5, 'L', -3, -5, 'Z'], H); // neck guard
    const k = H(12, -8.5);
    dot(ctx, k[0], k[1], 5.2 * s);
    shape(ctx, ['M', 15.5, -6, 'Q', 21, -14, 19, -27, 'Q', 14, -19, 9, -11, 'Z'], H);
    shape(ctx, ['M', 12, -6, 'Q', 13, -17, 6, -27, 'Q', 6, -17, 7.5, -10, 'Z'], H);
    if (!ghost) ribbon(ctx, f.chains[0], s);
  }

  // ── front layer ──
  if (!fLegBack) frontLeg();
  if (bLegFront) backLeg();
  if (!wArmBack) weaponArm();
  if (oArmFront) offArm();

  if (titan) {
    // layered pauldron with a curved spike
    const p: number[] = [];
    for (const q of [[0.78, -17], [1.0, -21], [1.2, -15], [1.27, 0], [1.14, 14], [0.88, 16], [0.76, 0]]) {
      const w = TS(q[0], q[1]);
      p.push(w[0], w[1]);
    }
    smoothPoly(ctx, p);
    shape(ctx, ['M', 1.12, -12, 'Q', 1.34, -20, 1.66, -15, 'Q', 1.42, -10, 1.24, 3, 'Z'], TS);
    shape(ctx, ['M', 0.86, -16, 'L', 1.02, -33, 'L', 1.1, -15, 'Z'], TS);
  } else {
    // light shoulder guard
    const p: number[] = [];
    for (const q of [[0.84, -12], [1.05, -15], [1.17, -6], [1.1, 7], [0.9, 9]]) {
      const w = TS(q[0], q[1]);
      p.push(w[0], w[1]);
    }
    smoothPoly(ctx, p);
  }

  // ── glowing details (hidden while the face is turned away) ──
  if (!ghost && !f.dead && Math.abs(cY) > 0.3) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.lineCap = 'round';
    if (titan) {
      const e = H(4, 14.5);
      const g = ctx.createRadialGradient(e[0], e[1], 0, e[0], e[1], 10 * s);
      g.addColorStop(0, `rgba(${b.eye},0.8)`);
      g.addColorStop(0.45, `rgba(${b.eye},0.3)`);
      g.addColorStop(1, `rgba(${b.eye},0)`);
      ctx.fillStyle = g;
      dot(ctx, e[0], e[1], 10 * s);
      const e0 = H(6.5, 10), e1 = H(3.5, 17.2), e2 = H(4, 11);
      ctx.fillStyle = 'rgba(255,240,215,1)';
      poly(ctx, [e0[0], e0[1], e1[0], e1[1], e2[0], e2[1]]);
    } else {
      const e0 = H(5.2, 6.5), e1 = H(2.6, 13.6), e2 = H(3.2, 7.5);
      ctx.fillStyle = `rgba(${b.eye},0.95)`;
      poly(ctx, [e0[0], e0[1], e1[0], e1[1], e2[0], e2[1]]);
    }
    ctx.restore();
  }
}

export function drawTrail(ctx: Ctx, f: Fighter) {
  const tr = f.trail;
  if (tr.length < 2) return;
  const warm = f.build.kind === 'titan';
  for (let i = 1; i < tr.length; i++) {
    const a = tr[i - 1], b = tr[i];
    if (b.brk) continue;
    const k = Math.max(0, 1 - (a.age + b.age) / 2 / TRAIL_LIFE);
    const al = k * k;
    // outer bright band
    const m = 0.55;
    const amx = lerp(a.bx, a.tx, m), amy = lerp(a.by, a.ty, m), bmx = lerp(b.bx, b.tx, m), bmy = lerp(b.by, b.ty, m);
    ctx.fillStyle = b.sup ? `rgba(190,160,255,${(0.8 * al).toFixed(3)})` : warm ? `rgba(255,190,110,${(0.62 * al).toFixed(3)})` : `rgba(255,248,225,${(0.66 * al).toFixed(3)})`;
    ctx.beginPath();
    ctx.moveTo(amx, amy); ctx.lineTo(a.tx, a.ty); ctx.lineTo(b.tx, b.ty); ctx.lineTo(bmx, bmy);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = b.sup ? `rgba(120,80,255,${(0.42 * al).toFixed(3)})` : warm ? `rgba(255,140,50,${(0.22 * al).toFixed(3)})` : `rgba(255,220,150,${(0.24 * al).toFixed(3)})`;
    ctx.beginPath();
    ctx.moveTo(a.bx, a.by); ctx.lineTo(amx, amy); ctx.lineTo(bmx, bmy); ctx.lineTo(b.bx, b.by);
    ctx.closePath();
    ctx.fill();
    // razor-bright leading edge along the path of the tip
    ctx.strokeStyle = b.sup ? `rgba(235,225,255,${al.toFixed(3)})` : `rgba(255,255,246,${al.toFixed(3)})`;
    ctx.lineWidth = 0.6 + 3 * k;
    ctx.beginPath();
    ctx.moveTo(a.tx, a.ty); ctx.lineTo(b.tx, b.ty);
    ctx.stroke();
  }
}

export function drawKickTrail(ctx: Ctx, f: Fighter) {
  const kt = f.ktrail;
  if (kt.length < 2) return;
  const s = f.build.scale * Math.min(f.build.thick, 1.2);
  ctx.lineCap = 'butt';
  for (let i = 1; i < kt.length; i++) {
    const a = kt[i - 1], b = kt[i];
    if (b.brk) continue;
    const k = Math.max(0, 1 - (a.age + b.age) / 2 / KICK_LIFE);
    ctx.strokeStyle = `rgba(255,236,200,${(0.3 * k * k).toFixed(3)})`;
    ctx.lineWidth = (3 + 13 * k) * s;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }
}

// ───────────────────────── environment ─────────────────────────
export interface View {
  w: number;
  h: number;
  ground: number; // screen y of the floor
  camX: number;
  camY: number;
  zoom: number;
}

export function drawBackground(ctx: Ctx, v: View, time: number, img: CanvasImageSource | null, iw: number, ih: number) {
  const { w, h } = v;
  if (img && iw > 0) {
    const sc = Math.max((w * 1.2) / iw, (h * 1.08) / ih) * (1 + (v.zoom - 1) * 0.1);
    const dw = iw * sc, dh = ih * sc;
    const maxShift = (dw - w) / 2;
    const ox = Math.max(-maxShift, Math.min(maxShift, -v.camX * 0.11 * v.zoom));
    const oy = Math.min(dh - h, Math.max(0, (dh - h) * 0.75 - v.camY * 0.25));
    ctx.drawImage(img, (w - dw) / 2 + ox, -oy, dw, dh);
  } else {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#b97a1c');
    g.addColorStop(0.55, '#f1cf73');
    g.addColorStop(1, '#8a5210');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  // warm light pooling behind the fighters – makes the silhouettes pop
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const cx = w * 0.5 - v.camX * 0.2, cy = v.ground - h * 0.3;
  const pulse = 0.9 + Math.sin(time * 0.6) * 0.1;
  const rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, h * 0.85);
  rg.addColorStop(0, `rgba(255,236,170,${0.3 * pulse})`);
  rg.addColorStop(0.5, 'rgba(255,200,100,0.1)');
  rg.addColorStop(1, 'rgba(255,170,60,0)');
  ctx.fillStyle = rg;
  ctx.fillRect(0, 0, w, h);

  // drifting spores
  for (let i = 0; i < 46; i++) {
    const depth = 0.25 + hash(i * 3.1) * 0.75;
    const span = w + 200;
    let x = hash(i * 7.7) * span + time * (6 + hash(i) * 16) * (i % 2 ? 1 : -1) - v.camX * depth * 0.5;
    x = ((x % span) + span) % span - 100;
    const yy = ((hash(i * 1.3) * h - time * (7 + hash(i * 5.3) * 14) * depth) % (v.ground + 40) + v.ground + 40) % (v.ground + 40);
    const sway = Math.sin(time * (0.5 + hash(i * 2.9)) + i) * 14;
    const r = (1.2 + hash(i * 9.1) * 2.6) * depth;
    const al = (0.25 + 0.4 * Math.abs(Math.sin(time * (0.4 + hash(i * 4.1) * 0.8) + i * 2))) * depth;
    ctx.fillStyle = `rgba(255,214,130,${(al * 0.25).toFixed(3)})`;
    dot(ctx, x + sway, yy, r * 3.2);
    ctx.fillStyle = `rgba(255,244,205,${al.toFixed(3)})`;
    dot(ctx, x + sway, yy, r);
  }

  // glowing orbs (left side, like the spore cluster of the cavern)
  for (let i = 0; i < 6; i++) {
    const ox = (-520 + hash(i * 2.3) * 300 - v.camX * 0.3) * 1 + w * 0.5;
    const oy = v.ground - 90 - hash(i * 5.9) * h * 0.42 + Math.sin(time * 0.5 + i * 1.9) * 9;
    const r = (15 + hash(i * 8.7) * 22) * (0.92 + Math.sin(time * 1.4 + i * 2.2) * 0.08);
    const g = ctx.createRadialGradient(ox, oy, 0, ox, oy, r * 2.6);
    g.addColorStop(0, 'rgba(255,225,150,0.85)');
    g.addColorStop(0.22, 'rgba(255,150,40,0.5)');
    g.addColorStop(1, 'rgba(255,100,0,0)');
    ctx.fillStyle = g;
    dot(ctx, ox, oy, r * 2.6);
  }
  ctx.restore();

  // floor haze
  const hz = ctx.createLinearGradient(0, v.ground - h * 0.3, 0, v.ground);
  hz.addColorStop(0, 'rgba(255,224,150,0)');
  hz.addColorStop(0.75, 'rgba(244,196,110,0.3)');
  hz.addColorStop(1, 'rgba(120,70,20,0.55)');
  ctx.fillStyle = hz;
  ctx.fillRect(0, v.ground - h * 0.3, w, h * 0.3 + 2);
}

/** drawn in world space (y=0 is the floor) */
export function drawGround(ctx: Ctx, x0: number, x1: number, depth: number) {
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.moveTo(x0, depth);
  ctx.lineTo(x0, 0);
  const step = 36;
  const start = Math.floor(x0 / step) * step;
  for (let x = start; x <= x1 + step; x += step) {
    const i = Math.round(x / step);
    ctx.lineTo(x, -1 - hash(i * 1.37) * 3.5);
  }
  ctx.lineTo(x1, depth);
  ctx.closePath();
  ctx.fill();
  // tufts and stones
  const cell = 120;
  for (let c = Math.floor(x0 / cell); c <= Math.ceil(x1 / cell); c++) {
    const hsh = hash(c * 3.71);
    const bx = c * cell + hash(c * 9.3) * cell * 0.8;
    if (hsh < 0.42) {
      const n = 3 + Math.floor(hash(c * 2.1) * 4);
      for (let k = 0; k < n; k++) {
        const px = bx + k * 5, ht = 7 + hash(c * 4.4 + k * 1.9) * 15;
        const lean = (hash(c + k * 7.3) - 0.5) * 12;
        poly(ctx, [px - 2.4, 0, px + lean, -ht, px + 2.4, 0]);
      }
    } else if (hsh < 0.62) {
      const r = 6 + hash(c * 6.6) * 9;
      ctx.beginPath();
      ctx.ellipse(bx, 1, r * 1.5, r, 0, Math.PI, TAU);
      ctx.fill();
    }
  }
}

export function drawVignette(ctx: Ctx, w: number, h: number) {
  const g = ctx.createRadialGradient(w / 2, h * 0.52, h * 0.35, w / 2, h * 0.52, Math.max(w, h) * 0.78);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(0.7, 'rgba(30,12,0,0.28)');
  g.addColorStop(1, 'rgba(10,4,0,0.72)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

