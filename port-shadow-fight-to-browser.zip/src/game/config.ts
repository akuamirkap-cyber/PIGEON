/**
 * Semua angka gameplay ada di sini. Waktu dalam detik, jarak dalam piksel dunia (skala petarung = 1).
 */
export type AttackKind = 'punch' | 'kick' | 'heavy' | 'throw' | 'super';
export type FighterType = 'player' | 'normal' | 'gatekeeper' | 'boss';

export interface AttackCfg {
  startup: number; // ancang-ancang – hitbox mati
  active: number; // hitbox HANYA hidup di fase ini
  recovery: number; // pemulihan – hitbox mati
  damage: number;
  range: number; // jarak maksimum antar petarung agar serangan bisa kena
  energy: number; // shadow energy yang didapat saat serangan mendarat
}

export interface VariantCfg {
  base: AttackKind;
  dmg: number; // pengali damage dasar
  time: number; // pengali durasi ketiga fase
  range?: number; // pengali jangkauan dasar
}

export interface FighterCfg {
  name: string;
  body: 'shadow' | 'titan';
  type: FighterType;
  antiKnockdown: boolean; // critical hit tidak menjatuhkan (damage bonus tetap masuk)
  hp: number;
  power: number; // pengali damage
  speed: number; // pengali kecepatan gerak & animasi
  scale: number;
  weaponLen: number;
  reach: number; // pengali jangkauan (senjata besar)
  kickStep: number; // pengali langkah maju saat menendang
  eye: string;
}

export const CONFIG = {
  // ───────────── SISTEM RONDE ─────────────
  round: {
    roundsToWin: 2, // best of 3
    maxRounds: 3,
    timeLimit: 0, // 0 = tanpa batas waktu: ronde hanya selesai saat HP salah satu pihak habis
    introTime: 1.75,
    koTime: 3.8,
  },

  // ───────────── GERAKAN (durasi & cooldown) ─────────────
  movement: {
    forward: { speed: 215, duration: 0.5, cooldown: 0 }, // duration = lama satu siklus langkah (2 langkah)
    // LARI otomatis: cukup tahan maju. duration = satu siklus lari (2 langkah)
    run: {
      speed: 470, duration: 0.46, cooldown: 0,
      auto: true, // false = pemain hanya berjalan
      autoAfter: 0.15, // jeda sebelum jalan berubah jadi lari (0 = langsung lari)
      accel: 6, brake: 5.5, // seberapa cepat menambah kecepatan / mengerem (rem = meluncur sebentar)
      stopDist: 185, // berhenti berlari sendiri pada jarak ini dari lawan
      attackCarry: 0.5, // bagian momentum lari yang terbawa ke serangan
      jumpCarry: 0.85, // bagian momentum lari yang terbawa ke lompatan
    },
    back: { speed: 170, duration: 0.5, cooldown: 0 },
    jump: { duration: 0.7, cooldown: 0.2, squat: 0.09, drift: 230 }, // duration = lama di udara
    crouch: { duration: 0.15, cooldown: 0.1 }, // duration = lama minimum jongkok
    roll: { duration: 0.5, cooldown: 0.6, distance: 205, invulnUntil: 0.8 }, // kebal selama 80% durasi
    // FLIP: ketuk arah 2× – ke arah lawan = frontflip, menjauh = backflip
    flip: {
      duration: 0.62, cooldown: 0.8, invulnUntil: 0.4,
      distance: 240, // jarak frontflip
      backDistance: 205, // jarak backflip
      doubleTap: 0.28, // jeda maksimum antara dua ketukan
    },
  },

  // ───────────── SERANGAN (startup / active / recovery) ─────────────
  attacks: {
    // Pukulan: cepat, damage kecil
    punch: { startup: 0.13, active: 0.1, recovery: 0.2, damage: 6, range: 214, energy: 7 },
    // Tendangan: lebih lambat, damage sedang, jangkauan lebih jauh
    kick: { startup: 0.2, active: 0.12, recovery: 0.3, damage: 11, range: 246, energy: 10 },
    // Lemparan: menembus blok, damage sedang, recovery lama
    throw: { startup: 0.2, active: 0.1, recovery: 0.62, damage: 12, range: 118, energy: 12 },
    // Super strike: damage besar, memakai seluruh shadow energy
    super: { startup: 0.34, active: 0.18, recovery: 0.55, damage: 34, range: 340, energy: 0 },
    // Serangan berat (H): paling lambat, damage besar, selalu membuat lawan terhuyung / terlempar
    heavy: { startup: 0.24, active: 0.12, recovery: 0.4, damage: 13, range: 240, energy: 14 },
  } as Record<AttackKind, AttackCfg>,

  /** Variasi jurus (arah + tombol, kombo). Angka akhir = dasar × pengali. */
  variants: {
    slash1: { base: 'punch', dmg: 1, time: 1 },
    slash2: { base: 'punch', dmg: 1.15, time: 1 },
    slash3: { base: 'punch', dmg: 1.4, time: 1.6 }, // tebasan berputar 360°
    slash4: { base: 'punch', dmg: 1.7, time: 1.5 }, // lompat + bantingan pamungkas
    kick2: { base: 'kick', dmg: 1.15, time: 1.05 }, // tendangan putar belakang
    thrust: { base: 'punch', dmg: 1.6, time: 1.5, range: 1.05 },
    lowslash: { base: 'punch', dmg: 1.1, time: 1.1 },
    upper: { base: 'punch', dmg: 1.7, time: 1.4 },
    airslash: { base: 'punch', dmg: 1.4, time: 1 },
    jab: { base: 'punch', dmg: 1, time: 0.9 },
    cross: { base: 'punch', dmg: 1.2, time: 1 },
    uppercut: { base: 'punch', dmg: 1.7, time: 1.3 },
    rise: { base: 'punch', dmg: 1.2, time: 1.15 }, // sabetan naik
    kick1: { base: 'kick', dmg: 1, time: 1 },
    sidekick: { base: 'kick', dmg: 1.25, time: 1.15 },
    sweep: { base: 'kick', dmg: 0.9, time: 1.05 },
    roundhouse: { base: 'kick', dmg: 1.45, time: 1.2 },
    airkick: { base: 'kick', dmg: 1.2, time: 1 },
    knee: { base: 'kick', dmg: 0.9, time: 0.9 }, // lutut terbang (mengangkat lawan)
    axe: { base: 'kick', dmg: 1.35, time: 1.15 }, // tendangan kapak (menghempas ke tanah)
    heavy1: { base: 'heavy', dmg: 1, time: 1 }, // belah gunung
    heavy2: { base: 'heavy', dmg: 1.05, time: 1 }, // tebasan langit (pelambung)
    heavy3: { base: 'heavy', dmg: 1.2, time: 1.1 }, // roda maut (salto + belah)
    hkick: { base: 'heavy', dmg: 1.1, time: 1 }, // tendangan topan
    throw: { base: 'throw', dmg: 1, time: 1 },
    super: { base: 'super', dmg: 1, time: 1 },
  } as Record<string, VariantCfg>,

  // ───────────── FREESTYLE ─────────────
  freestyle: {
    transition: 0.92, // bagian startup jurus sambungan yang diisi gerakan freestyle (selesai sebelum hitbox aktif)
    ender: true, // kombo yang kena ditutup dengan gulungan bilah saat pemulihan
    energy: 6, // shadow energy tiap trik (F) yang selesai
    cooldown: 0.9, // jeda antar trik
  },

  // ───────────── KOMBO ─────────────
  combo: {
    maxString: 6, // jumlah jurus maksimum dalam satu rangkaian
    cancelAt: 0.12, // bagian recovery yang harus lewat sebelum jurus berikutnya memotong
    juggleMax: 3, // serangan tambahan pada lawan yang masih melayang
    juggleDamage: 0.6, // pengali damage serangan juggle
    juggleMinHeight: 34, // tinggi pinggul minimum agar lawan masih bisa diserang di udara
    jugglePop: [70, 430], // dorongan tiap serangan juggle: maju, naik
    // tiap pukulan berikutnya pada lawan yang belum sempat pulih sedikit lebih lemah
    scaling: 0.85, // pengali per pukulan
    scalingMin: 0.5, // batas bawah pengali
    finisherAt: 4, // combo ke-N yang ditutup jurus penjatuh -> gerak lambat sekejap
  },

  /** lemparan yang kena: pegang → angkat ke atas kepala → banting */
  throwAnim: {
    duration: 1.02, // lama seluruh sekuens bagi pelempar
    releaseAt: 0.6, // saat korban dilepas (damage masuk di sini)
    impulse: [430, 140], // kecepatan tambahan saat dilepas: maju, turun
  },

  // ───────────── BLOK ─────────────
  block: {
    damageMul: 0.2, // damage yang tembus saat diblok
    autoGuard: false, // true = pemain menangkis otomatis saat diam (tanpa Shift)
  },

  // ───────────── MEKANIKA INTI ─────────────
  headHit: {
    bonus: 0.6, // +60% damage
    exemptTypes: ['gatekeeper'], // tipe lawan yang tidak memberi bonus head hit
  },
  crit: {
    chance: 0.15,
    bonus: 0.5, // +50% damage dan menjatuhkan lawan (kecuali antiKnockdown)
  },
  shock: {
    chance: 0.1, // peluang head hit melucuti senjata
    immuneTypes: ['boss'],
    unarmedDamage: 0.6, // pengali damage pukulan tanpa senjata
    unarmedRange: 0.7, // pengali jangkauan pukulan tanpa senjata
  },
  energy: {
    max: 100,
    blockedFactor: 0.35, // bagian energi yang tetap didapat saat serangan diblok
    onHitTaken: 8,
    onBlockTaken: 3,
  },

  // ───────────── KOIN ─────────────
  coins: {
    roundWin: 50,
    perComboHit: 5, // × combo tertinggi ronde itu
    firstStrike: 25,
  },

  // ───────────── PETARUNG ─────────────
  player: {
    name: 'SHADOW', body: 'shadow', type: 'player', antiKnockdown: false,
    hp: 100, power: 1, speed: 1, scale: 1, weaponLen: 84, reach: 1, kickStep: 1, eye: '214,255,90',
  } as FighterCfg,

  opponents: {
    ronin: {
      name: 'RONIN', body: 'shadow', type: 'normal', antiKnockdown: false,
      hp: 100, power: 1, speed: 0.95, scale: 1, weaponLen: 84, reach: 1, kickStep: 1, eye: '255,90,70',
    },
    gatekeeper: {
      name: 'GATEKEEPER', body: 'titan', type: 'gatekeeper', antiKnockdown: true,
      hp: 115, power: 1.15, speed: 0.86, scale: 1.08, weaponLen: 102, reach: 1.1, kickStep: 1.4, eye: '120,220,255',
    },
    titan: {
      name: 'TITAN', body: 'titan', type: 'boss', antiKnockdown: false,
      hp: 125, power: 1.3, speed: 0.8, scale: 1.2, weaponLen: 116, reach: 1.15, kickStep: 1.6, eye: '255,150,50',
    },
  } as Record<string, FighterCfg>,
};

export type OpponentKey = 'ronin' | 'gatekeeper' | 'titan';
