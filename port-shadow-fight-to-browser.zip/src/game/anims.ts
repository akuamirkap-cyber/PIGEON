import { AttackKind, CONFIG } from './config';
import { Ease } from './math';
import { POSE_KEYS, Pose, STANCE, copyPose, mk, zeroPose } from './skeleton';

export interface Key {
  t: number;
  pose: Pose;
  e?: Ease;
}
export interface Anim {
  keys: Key[];
  dur: number;
  /** per-key tangents (monotone cubic / PCHIP) – gives C1 continuous, overshoot-free motion */
  m: Pose[];
}

const K = (t: number, p: Partial<Pose> = {}, e?: Ease): Key => ({ t, pose: mk(p), e });

const A = (...keys: Key[]): Anim => {
  const n = keys.length;
  const m: Pose[] = keys.map(() => zeroPose());
  for (const k of POSE_KEYS) {
    for (let i = 1; i < n - 1; i++) {
      const h0 = keys[i].t - keys[i - 1].t, h1 = keys[i + 1].t - keys[i].t;
      const d0 = (keys[i].pose[k] - keys[i - 1].pose[k]) / h0, d1 = (keys[i + 1].pose[k] - keys[i].pose[k]) / h1;
      if (d0 * d1 > 0) {
        const w1 = 2 * h1 + h0, w2 = h1 + 2 * h0;
        m[i][k] = (w1 + w2) / (w1 / d0 + w2 / d1);
      }
    }
  }
  return { keys, dur: keys[n - 1].t, m };
};

/** Hermite spline sampling: motion flows through the keys instead of stopping at each one. */
export function sample(a: Anim, t: number, out: Pose) {
  const ks = a.keys;
  if (t <= ks[0].t) return copyPose(out, ks[0].pose);
  for (let i = 1; i < ks.length; i++) {
    if (t < ks[i].t) {
      const h = ks[i].t - ks[i - 1].t;
      const u = (t - ks[i - 1].t) / h, u2 = u * u, u3 = u2 * u;
      const h00 = 2 * u3 - 3 * u2 + 1, h10 = (u3 - 2 * u2 + u) * h, h01 = -2 * u3 + 3 * u2, h11 = (u3 - u2) * h;
      const p0 = ks[i - 1].pose, p1 = ks[i].pose, m0 = a.m[i - 1], m1 = a.m[i];
      for (let c = 0; c < POSE_KEYS.length; c++) {
        const k = POSE_KEYS[c];
        out[k] = h00 * p0[k] + h10 * m0[k] + h01 * p1[k] + h11 * m1[k];
      }
      return;
    }
  }
  copyPose(out, ks[ks.length - 1].pose);
}

// ───────────────────────── static poses ─────────────────────────
export const P_CROUCH = mk({ py: 58, torso: 24, head: -16, sF: 22, eF: 48, wp: 22, sB: 46, eB: 100, fFx: 34, fBx: -36 });
export const P_BLOCK = mk({ tw: -42, hw: -16, zF: 24, py: 86, px: -8, torso: -4, head: -2, sF: 55, eF: 70, wp: 52, sB: 58, eB: 84, fFx: 28, fBx: -38 });
export const P_BLOCK_LOW = mk({ tw: -42, hw: -16, zF: 24, py: 62, px: -6, torso: 12, head: -10, sF: 58, eF: 72, wp: 44, sB: 60, eB: 86, fFx: 32, fBx: -38 });
export const P_ROLL = mk({ py: 18, px: 0, torso: 70, head: 30, sF: 62, eF: 72, wp: -46, sB: 72, eB: 82, fFx: 22, fFy: 26, fFa: -10, fBx: 2, fBy: 22, fBa: -10 });
export const P_ROLL_IN = mk({ py: 66, torso: 34, head: -6, sF: 30, eF: 50, wp: -10, sB: 50, eB: 80, fFx: 30, fBx: -30 });
export const P_SQUAT = mk({ py: 68, torso: 24, head: -14, sF: -10, eF: 40, sB: 10, eB: 70 });
export const P_LAND = mk({ py: 70, torso: 26, head: -16, sF: 20, eF: 40, sB: 30, eB: 80, fFx: 34, fBx: -38 });
export const P_AIR_UP = mk({ py: 98, torso: 4, head: -2, sF: 30, eF: 50, sB: 60, eB: 70, fFx: 14, fFy: 8, fFa: -45, fBx: -18, fBy: 2, fBa: -50 });
export const P_AIR_MID = mk({ py: 96, torso: 10, head: -6, sF: 40, eF: 60, sB: 70, eB: 80, fFx: 26, fFy: 40, fFa: -30, fBx: -16, fBy: 30, fBa: -40 });
export const P_AIR_TUCK = mk({ py: 92, torso: 44, head: 8, sF: 55, eF: 55, wp: -50, sB: 62, eB: 62, fFx: 32, fFy: 54, fFa: -20, fBx: 16, fBy: 50, fBa: -20 });
export const P_VICTORY = mk({ tw: -50, hw: -20, zF: 30, py: 99, torso: -3, head: -10, sF: 162, eF: 12, wp: 6, sB: 16, eB: 28, fFx: 20, fBx: -24 });
export const P_LIE = mk({ tw: 0, hw: 0, py: 13, px: 0, torso: -86, head: -6, sF: -80, eF: 0, wp: 0, sB: 72, eB: 8, fFx: 86, fFy: 0, fFa: 60, fBx: 70, fBy: 0, fBa: 50 });

// ───────────────────────── procedural loops ─────────────────────────
export function idlePose(out: Pose, t: number) {
  copyPose(out, STANCE);
  const w = t * 2.6;
  const br = Math.sin(w), br2 = Math.sin(w * 0.5 + 0.7);
  out.py += br * 1.8;
  out.px += br2 * 2.2;
  out.torso += Math.sin(w + 0.6) * 1.5 + br2 * 1.1;
  out.head += Math.sin(w + 2) * 1.2;
  out.sF += Math.sin(w + 1) * 2.5;
  out.eF += Math.sin(w + 0.4) * 2.5;
  out.sB += Math.sin(w + 0.9) * 2;
  out.eB += br * 3.5;
  out.wp += Math.sin(w * 0.7) * 3;
  out.tw += br2 * 4;
}

/**
 * Walk foot: [x, y, pitch]. Swing 40 % of the cycle, stance 60 %.
 * Heel strike with the toes up, roll over the foot, heel lifts before toe-off.
 */
function footCycle(u: number, S: number): [number, number, number] {
  u = u - Math.floor(u);
  if (u < 0.4) {
    const k = u / 0.4;
    const sm = k * k * (3 - 2 * k);
    const q = 1 - k;
    return [-S + 7.6 * q + (2 * S - 7.6 * q) * sm, 9 * q * q + Math.sin(k * Math.PI) * 12, -38 + 50 * sm];
  }
  const k = (u - 0.4) / 0.6;
  const x = S - 2 * S * k;
  if (k < 0.12) return [x, 0, 12 * (1 - k / 0.12)];
  if (k > 0.75) {
    const e = (k - 0.75) / 0.25;
    return [x + 7.6 * e, 9 * e * e, -38 * e]; // the ankle rolls forward over the planted toes
  }
  return [x, 0, 0];
}

/** stride = distance covered by one walk cycle (speed × duration from CONFIG) */
export function walkPose(out: Pose, ph: number, stride: number) {
  copyPose(out, STANCE);
  const S = stride * 0.3;
  const f = footCycle(ph, S), b = footCycle(ph + 0.5, S);
  out.fFx = 5 + f[0]; out.fFy = f[1]; out.fFa = f[2];
  out.fBx = -7 + b[0]; out.fBy = b[1]; out.fBa = b[2];
  const c = Math.cos((ph - 0.2) * Math.PI * 4); // +1 at mid-stance: the pelvis rides over the straight leg
  const sw = Math.cos((ph - 0.4) * Math.PI * 2); // +1 when the front leg is furthest forward
  out.py = 104.3 + c * 1.7;
  out.px = 1.5 * Math.sin((ph - 0.2) * Math.PI * 4);
  out.torso = 8 + c * 0.8;
  out.head = -3 - c * 0.8;
  out.sF = 13 - sw * 7;
  out.eF = 34 - sw * 4;
  out.sB = 30 + sw * 16; // the free arm swings against the legs
  out.eB = 84 + sw * 10;
  out.wp = 12 + c * 2.5;
  out.tw = -20 - sw * 10;
  out.hw = -4 + sw * 7;
}

/** periodic monotone-cubic curve through (u, value) keys; us[0] must be 0 */
function loopCurve(us: number[], vs: number[]): (u: number) => number {
  const n = us.length;
  const m = new Array<number>(n).fill(0);
  const h = (i: number) => (i === n - 1 ? 1 - us[i] : us[i + 1] - us[i]);
  for (let i = 0; i < n; i++) {
    const p = (i + n - 1) % n, q = (i + 1) % n;
    const h0 = h(p), h1 = h(i);
    const d0 = (vs[i] - vs[p]) / h0, d1 = (vs[q] - vs[i]) / h1;
    if (d0 * d1 > 0) {
      const w1 = 2 * h1 + h0, w2 = h1 + 2 * h0;
      m[i] = (w1 + w2) / (w1 / d0 + w2 / d1);
    }
  }
  return (u: number) => {
    u -= Math.floor(u);
    let i = n - 1;
    for (let k = 1; k < n; k++) {
      if (u < us[k]) { i = k - 1; break; }
    }
    const q = (i + 1) % n, hh = h(i), t = (u - us[i]) / hh, t2 = t * t, t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * vs[i] + (t3 - 2 * t2 + t) * hh * m[i] + (-2 * t3 + 3 * t2) * vs[q] + (t3 - t2) * hh * m[q];
  };
}

// ── run cycle ── u = 0 is the foot strike. Stance lasts 34 % of the cycle, so there are two flight phases.
// contact → mid-stance → heel off → toe-off → heel kicks up behind → knee drives through → reach → paw back
export const RUN_STRIDE = CONFIG.movement.run.speed * CONFIG.movement.run.duration;
const rx = (u: number) => 20 - RUN_STRIDE * u; // a planted foot travels back exactly as fast as the body moves on
const RU = [0, 0.05, 0.17, 0.26, 0.34, 0.45, 0.58, 0.74, 0.88];
const RUN_X = loopCurve(RU, [20, rx(0.05), rx(0.17), rx(0.26) + 1.8, rx(0.34) + 10.7, -66, -22, 40, 58]);
const RUN_Y = loopCurve(RU, [0, 0, 0, 3, 12, 48, 55, 44, 18]);
const RUN_A = loopCurve(RU, [14, 0, 0, -14, -48, -85, -62, -24, 6]);
/** phase offset that lines the run's mid-stance up with the walk's, so the two gaits blend cleanly */
export const RUN_SYNC = 0.47;

export function runPose(out: Pose, ph: number, armed: boolean) {
  copyPose(out, STANCE);
  const ub = ph + 0.5;
  out.fFx = RUN_X(ph); out.fFy = Math.max(0, RUN_Y(ph)); out.fFa = RUN_A(ph);
  out.fBx = RUN_X(ub); out.fBy = Math.max(0, RUN_Y(ub)); out.fBa = RUN_A(ub);
  const c2 = Math.cos((ph - 0.42) * Math.PI * 4); // +1 in mid-flight, -1 at mid-stance
  const sw = Math.cos((ph - 0.9) * Math.PI * 2); // +1 when the front leg reaches forward
  out.py = 105.8 + 2.4 * c2;
  out.px = 0;
  out.torso = 19 + 1.6 * Math.cos((ph - 0.3) * Math.PI * 4);
  out.head = -11;
  out.tw = -10 - 28 * sw; // shoulders turn against the hips
  out.hw = 14 * sw;
  // free arm pumps hard against the legs
  out.sB = 14 + 45 * sw;
  out.eB = 82 + 14 * sw;
  if (armed) {
    // weapon arm stays low, the blade streams out behind the body
    out.sF = -22 - 12 * sw;
    out.eF = 30 - 8 * sw;
    out.wp = -80 + 6 * c2 - out.sF - out.eF;
  } else {
    out.sF = 14 - 45 * sw;
    out.eF = 82 - 14 * sw;
  }
}

/** front flip: arms thrown forward, tight tuck, open up for the landing */
export const A_FRONTFLIP = A(
  K(0, { py: 104, torso: 16, head: -8, sF: 104, eF: 26, wp: 10, sB: 112, eB: 24, fFx: 6, fFy: 2, fFa: -52, fBx: -24, fBy: 0, fBa: -58 }),
  K(0.16, { py: 99, torso: 34, head: 2, sF: 84, eF: 44, wp: -20, sB: 90, eB: 46, fFx: 22, fFy: 30, fFa: -40, fBx: -4, fBy: 22, fBa: -48 }),
  K(0.34, { py: 92, torso: 46, head: 12, sF: 56, eF: 58, wp: -50, sB: 62, eB: 64, fFx: 32, fFy: 56, fFa: -20, fBx: 16, fBy: 52, fBa: -20 }),
  K(0.66, { py: 92, torso: 44, head: 10, sF: 54, eF: 56, wp: -50, sB: 60, eB: 62, fFx: 32, fFy: 54, fFa: -20, fBx: 16, fBy: 50, fBa: -20 }),
  K(0.86, { py: 97, torso: 26, head: -6, sF: 34, eF: 50, wp: -10, sB: 52, eB: 78, fFx: 28, fFy: 26, fFa: -16, fBx: -14, fBy: 18, fBa: -26 }),
  K(1, { py: 98, torso: 20, head: -10, sF: 26, eF: 46, wp: 6, sB: 48, eB: 84, fFx: 26, fFy: 10, fFa: -8, fBx: -26, fBy: 8, fBa: -18 }),
);
/** back flip: arms swing up and over, the body arches back, knees snap to the chest, legs reach for the floor */
export const A_BACKFLIP = A(
  K(0, { py: 106, torso: -18, head: 10, sF: 166, eF: 16, wp: 24, sB: 172, eB: 14, fFx: 12, fFy: 0, fFa: -52, fBx: -18, fBy: 2, fBa: -58 }),
  K(0.16, { py: 102, torso: -8, head: 16, sF: 150, eF: 30, wp: 10, sB: 156, eB: 30, fFx: 22, fFy: 24, fFa: -44, fBx: -4, fBy: 20, fBa: -50 }),
  K(0.34, { py: 92, torso: 32, head: 16, sF: 62, eF: 60, wp: -40, sB: 68, eB: 66, fFx: 30, fFy: 58, fFa: -20, fBx: 14, fBy: 54, fBa: -20 }),
  K(0.64, { py: 92, torso: 30, head: 12, sF: 60, eF: 58, wp: -40, sB: 66, eB: 64, fFx: 30, fFy: 56, fFa: -20, fBx: 14, fBy: 52, fBa: -20 }),
  K(0.86, { py: 98, torso: 8, head: -4, sF: 30, eF: 44, wp: -6, sB: 74, eB: 50, fFx: 20, fFy: 22, fFa: -24, fBx: -22, fBy: 24, fBa: -30 }),
  K(1, { py: 98, torso: 14, head: -8, sF: 20, eF: 44, wp: 8, sB: 46, eB: 84, fFx: 24, fFy: 10, fFa: -8, fBx: -27, fBy: 12, fBa: -18 }),
);

/** skid stop: weight thrown back, front leg braced, heel dug in */
export const P_BRAKE = mk({ py: 90, px: -14, torso: -9, head: 3, sF: -14, eF: 40, wp: -86, sB: 72, eB: 28, fFx: 44, fFy: 0, fFa: 18, fBx: -16, fBy: 0, fBa: 0 });

// ───────────────────────── reactions ─────────────────────────
export const A_BLOCKHIT = A(
  K(0, { ...P_BLOCK, torso: -15, px: -18, py: 82, sF: 62, eF: 86, wp: 40, head: -8 }),
  K(0.11, { ...P_BLOCK, torso: -8, px: -12, py: 84 }),
  K(0.24, { ...P_BLOCK }),
);
// head snaps back, the body arches and takes a recovery step
const HIT_HIGH_A = A(
  K(0, {}),
  K(0.05, { tw: -56, hw: -24, hy: -30, torso: -30, head: -36, px: -13, py: 91, sF: -26, eF: 18, wp: 36, sB: -14, eB: 38, fFx: 20, fBx: -40 }),
  K(0.16, { torso: -21, head: -14, px: -13, py: 88, sF: -10, eF: 28, wp: 26, sB: 8, eB: 58, fFx: 18, fBx: -50, fBy: 9, fBa: -20 }),
  K(0.3, { torso: 5, head: 2, px: -6, py: 86, sF: 16, eF: 36, sB: 34, eB: 86, fFx: 24, fBx: -44 }),
  K(0.46, {}),
);
// the blow whips the head round, the shoulders roll with it and the body ducks on the rebound
const HIT_HIGH_B = A(
  K(0, {}),
  K(0.05, { tw: 46, hw: 16, hy: 70, torso: -16, head: -42, px: -9, py: 87, sF: 24, eF: 62, wp: 30, sB: 74, eB: 58, fFx: 26, fBx: -38 }),
  K(0.18, { torso: 16, head: 20, px: -7, py: 80, sF: 30, eF: 48, sB: 52, eB: 92, fFx: 26, fBx: -40 }),
  K(0.32, { torso: 14, head: 2, px: -3, py: 85 }),
  K(0.46, {}),
);
// folds over the blow
const HIT_MID_A = A(
  K(0, {}),
  K(0.05, { tw: 30, hw: 20, torso: 42, head: 20, px: -19, py: 77, sF: 38, eF: 62, wp: -6, sB: 52, eB: 72, fFx: 24, fBx: -46 }),
  K(0.2, { torso: 31, head: 9, px: -12, py: 80, sF: 32, eF: 54, sB: 46, eB: 80, fFx: 18, fFy: 7, fFa: -15, fBx: -46 }),
  K(0.34, { torso: 18, head: -2, px: -5, py: 86, fFx: 28, fBx: -40 }),
  K(0.46, {}),
);
// hips driven back, chest thrown open, then the body curls in
const HIT_MID_B = A(
  K(0, {}),
  K(0.05, { tw: -62, hw: -40, torso: -12, head: 16, px: -22, py: 84, sF: -32, eF: 30, wp: 34, sB: -4, eB: 48, fFx: 22, fBx: -46 }),
  K(0.2, { torso: 26, head: 8, px: -13, py: 79, sF: 30, eF: 56, sB: 48, eB: 78, fBx: -44 }),
  K(0.34, { torso: 16, px: -5, py: 86 }),
  K(0.46, {}),
);
export const HITS_HIGH = [HIT_HIGH_A, HIT_HIGH_B];
export const HITS_MID = [HIT_MID_A, HIT_MID_B];
// the leg is knocked away and buckles
export const A_HIT_LOW = A(
  K(0, {}),
  K(0.05, { py: 70, torso: 29, head: -10, px: -6, fFx: 2, fFy: 19, fFa: -38, sF: 42, eF: 20, wp: 30, sB: 72, eB: 40 }),
  K(0.18, { py: 65, torso: 33, head: -14, px: -2, fFx: 14, fFy: 4, fFa: -10, sF: 34, eF: 34, sB: 60, eB: 60 }),
  K(0.32, { py: 80, torso: 18, fFx: 25 }),
  K(0.46, {}),
);
// heavy blow high: reeling, stumbling back-steps with windmilling arms, then catching the balance low
export const A_REEL = A(
  K(0, {}),
  K(0.07, { tw: -66, hw: -30, hy: -40, torso: -36, head: -28, px: -18, py: 90, sF: -62, eF: 10, wp: 52, sB: -52, eB: 14, fFx: 10, fFy: 15, fFa: -28, fBx: -40 }),
  K(0.2, { tw: 30, hw: 20, hy: 20, torso: -27, head: -16, px: -15, py: 86, sF: 58, eF: 28, wp: 34, sB: 122, eB: 38, fFx: -4, fFy: 0, fBx: -54, fBy: 15, fBa: -25 }),
  K(0.34, { torso: -13, head: -8, px: -10, py: 82, sF: 84, eF: 40, wp: 20, sB: 88, eB: 62, fFx: 6, fFy: 11, fFa: -20, fBx: -66, fBy: 0 }),
  K(0.5, { torso: 24, head: -6, px: -2, py: 70, sF: 40, eF: 50, wp: 10, sB: 50, eB: 82, fFx: 27, fFy: 0, fBx: -54 }),
  K(0.72, { torso: 17, head: -8, py: 80, fBx: -42 }),
  K(0.96, {}),
);
// heavy blow to the body: doubled over, skidding back on both feet, sagging before recovering
export const A_SKID = A(
  K(0, {}),
  K(0.07, { tw: 38, hw: 22, torso: 48, head: 24, px: -23, py: 75, sF: 52, eF: 72, wp: -22, sB: 62, eB: 82, fFx: 22, fBx: -50 }),
  K(0.3, { torso: 42, head: 16, px: -17, py: 71, sF: 46, eF: 66, wp: -14, sB: 56, eB: 84, fFx: 27, fBx: -56 }),
  K(0.55, { torso: 36, head: -6, px: -10, py: 63, sF: 34, eF: 50, sB: 48, eB: 80, fFx: 30, fBx: -50 }),
  K(0.8, { torso: 19, head: -8, py: 80, fBx: -40 }),
  K(1.0, {}),
);
export const P_PRONE = mk({ tw: 0, hw: 0, py: 13, px: 0, torso: 86, head: -22, sF: 80, eF: 10, wp: 0, sB: 100, eB: 10, fFx: -98, fFy: 0, fFa: -150, fBx: -90, fBy: 0, fBa: -150 });
// from the back: knees tuck, rock forward onto the feet, push up
export const A_GETUP = A(
  K(0, { ...P_LIE }),
  K(0.16, { py: 16, px: 0, torso: -72, head: 4, sF: -70, eF: 10, wp: 10, sB: 60, eB: 20, fFx: 44, fFy: 48, fFa: 20, fBx: 34, fBy: 42, fBa: 20 }),
  K(0.34, { py: 25, px: 10, torso: 8, head: 4, sF: -34, eF: 30, wp: 30, sB: 62, eB: 42, fFx: 54, fFy: 0, fFa: 10, fBx: 32, fBy: 0 }),
  K(0.54, { py: 50, px: 2, torso: 37, head: -18, sF: 30, eF: 42, sB: 42, eB: 62, fFx: 36, fBx: -16 }),
  K(0.72, { py: 75, torso: 21, head: -10, fFx: 30, fBx: -30 }),
  K(0.92, {}),
);
// from the belly: push up, drag a knee under, rise
export const A_GETUP_PRONE = A(
  K(0, { ...P_PRONE }),
  K(0.22, { py: 27, px: 0, torso: 62, head: -32, sF: 28, eF: 18, wp: 40, sB: 40, eB: 16, fFx: -62, fFy: 0, fFa: -120, fBx: -84, fBy: 0, fBa: -140 }),
  K(0.45, { py: 45, px: 0, torso: 45, head: -24, sF: 20, eF: 40, wp: 24, sB: 40, eB: 60, fFx: 20, fFy: 0, fFa: 0, fBx: -56, fBy: 0, fBa: -40 }),
  K(0.68, { py: 72, torso: 24, head: -12, fFx: 30, fBx: -36 }),
  K(0.92, {}),
);

// ───────────────────────── moves ─────────────────────────
export type Flair = 'twirl' | 'whirl' | 'pirouette';
export type Part = 'weapon' | 'footF' | 'footB' | 'handF' | 'handB' | 'grab';
export type MoveName =
  | 'slash1' | 'slash2' | 'slash3' | 'slash4' | 'rise' | 'thrust' | 'lowslash' | 'upper' | 'airslash'
  | 'jab' | 'cross' | 'uppercut'
  | 'heavy1' | 'heavy2' | 'heavy3' | 'hkick'
  | 'kick1' | 'kick2' | 'knee' | 'axe' | 'sidekick' | 'sweep' | 'roundhouse' | 'airkick'
  | 'throw' | 'super';

export interface Move {
  name: MoveName;
  anim: Anim;
  part: Part;
  /** animation-time marks of the strike (= base startup / startup+active); the real phases are mapped onto them */
  t0: number;
  t1: number;
  // resolved from CONFIG
  base: AttackKind;
  startup: number;
  active: number;
  recovery: number;
  dmg: number;
  range: number;
  energy: number;
  kb: number; // pushback speed when the victim stays on his feet
  heavy?: boolean; // heavy reaction (reel / skid)
  knock?: [number, number, number]; // knock-down impulse: forward, up, focus
  koImp: [number, number, number]; // ragdoll impulse used on a K.O.
  stop: number; // hit-stop seconds
  step?: { t0: number; t1: number; dist: number }; // root motion in animation time
  trail0?: number; // animation time at which the blade trail starts (default: just before the active phase)
  /** same move performed on the spot – blended with `anim` by how much of the step is really needed */
  anim0?: Anim;
  /** distance to the opponent at which the strike lands at full extension */
  ideal?: number;
  /** combo tree: which move follows when J (punch), K (kick) or H (heavy) is pressed */
  next?: { punch?: MoveName; kick?: MoveName; heavy?: MoveName };
  /** whole-body somersault in the picture plane between two animation times */
  spin?: { t0: number; t1: number; turns: number };
  slam?: number; // animation time of a heavy landing (dust + shake)
  /** freestyle flourish this move comes out of when it is chained (+ its direction) */
  flair?: Flair;
  flairDir?: number;
  /** the animation itself already spins the body */
  ownSpin: boolean;
  air?: boolean;
}

type MoveDef = Omit<Move, 'name' | 'base' | 't0' | 't1' | 'startup' | 'active' | 'recovery' | 'dmg' | 'range' | 'energy' | 'ownSpin'>;

/**
 * Every animation below is authored on the BASE timeline of its attack type
 * (punch 0.13 / 0.10 / 0.20, kick 0.20 / 0.12 / 0.30 …), so the key times read as real seconds.
 */
function def(name: MoveName, d: MoveDef): Move {
  const v = CONFIG.variants[name];
  const b = CONFIG.attacks[v.base];
  return {
    name, base: v.base, t0: b.startup, t1: b.startup + b.active,
    startup: b.startup * v.time, active: b.active * v.time, recovery: b.recovery * v.time,
    dmg: b.damage * v.dmg, range: b.range * (v.range ?? 1), energy: b.energy * v.dmg,
    ownSpin: !!d.spin || d.anim.keys.some((k) => Math.abs(k.pose.tw) > 270),
    ...d,
  };
}

const AIRLEGS = { fFx: 16, fFy: 34, fFa: -35, fBx: -22, fBy: 30, fBa: -40, py: 96 };

/*
 * Every strike is built like a real one: the hips turn first (hw), the shoulders follow (tw),
 * the arm and the blade whip through last (zF / wz) and carry on past the target.
 * At contact the blade is back in the picture plane (wz ≈ 0), so it reaches as far as it looks.
 */
export const MOVES: Record<MoveName, Move> = {
  // ══ PUKULAN (senjata) ══ timeline dasar: startup 0.13 · active 0.10 · recovery 0.20
  // tebasan diagonal: bahu ditarik jauh ke belakang, lalu memotong menyilang badan
  slash1: def('slash1', {
    part: 'weapon', kb: 200, stop: 0.06, koImp: [520, 330, 0.4], trail0: 0.09,
    next: { punch: 'slash2', kick: 'kick1', heavy: 'heavy1' },
    anim: A(
      K(0, {}),
      // rise and coil – held for a beat so the cut explodes out of it
      K(0.05, { py: 105, px: -10, torso: -12, head: 4, tw: -76, hw: -38, sF: 158, eF: 96, wp: 36, zF: 42, wz: 52, sB: 84, eB: 26, zB: -30, fFx: 20, fFy: 8, fFa: -12, fBx: -34 }),
      K(0.09, { py: 106, px: -11, torso: -14, head: 4, tw: -82, hw: -40, sF: 164, eF: 100, wp: 40, zF: 44, wz: 56, sB: 88, eB: 24, zB: -30, fFx: 22, fFy: 10, fFa: -14, fBx: -34 }),
      K(0.13, { py: 94, px: 4, torso: 6, head: -6, tw: -20, hw: 22, sF: 122, eF: 26, wp: -8, zF: 20, wz: 24, sB: 20, eB: 66, fFx: 46, fFy: 2, fBx: -40 }),
      // deep lunge: front knee bent, back leg straight, off arm thrown behind
      K(0.17, { py: 82, px: 15, torso: 25, head: -15, tw: 40, hw: 36, sF: 84, eF: 6, wp: -6, zF: 0, wz: 0, sB: -30, eB: 30, zB: 24, fFx: 54, fBx: -46, fBa: -22 }),
      K(0.23, { py: 79, px: 17, torso: 32, head: -19, tw: 66, hw: 40, sF: 46, eF: 8, wp: -14, zF: -30, wz: -40, sB: -44, eB: 26, zB: 30, fFx: 54, fBx: -46, fBa: -22 }),
      K(0.29, { py: 80, px: 16, torso: 33, head: -19, tw: 72, hw: 40, sF: 34, eF: 14, wp: -16, zF: -44, wz: -60, sB: -46, eB: 28, zB: 30, fFx: 54, fBx: -46, fBa: -18 }),
      K(0.43, {}),
    ),
  }),
  // sabetan mendatar: bilah melingkar dari sisi jauh, lewat depan, ke sisi kamera
  slash2: def('slash2', {
    part: 'weapon', kb: 230, stop: 0.07, koImp: [560, 300, 0.4], trail0: 0.07,
    step: { t0: 0.05, t1: 0.18, dist: 64 }, ideal: 160, // steps in only as far as needed
    next: { punch: 'slash3', kick: 'kick2', heavy: 'heavy2' },
    anim: A(
      K(0, { py: 80, px: 16, torso: 33, head: -19, tw: 72, hw: 40, sF: 34, eF: 14, wp: -16, zF: -44, wz: -60, sB: -46, eB: 28, fFx: 54, fBx: -46 }),
      // blade wrapped behind the far shoulder, held
      K(0.05, { py: 84, px: 10, torso: 22, head: -12, tw: 84, hw: 34, sF: 80, eF: 18, wp: -2, zF: -76, wz: -156, sB: 30, eB: 84, zB: 20, fFx: 52, fBx: -44 }),
      K(0.09, { py: 85, px: 9, torso: 20, head: -11, tw: 88, hw: 34, sF: 80, eF: 18, wp: -2, zF: -80, wz: -164, sB: 34, eB: 86, zB: 20, fFx: 52, fBx: -44 }),
      K(0.13, { py: 86, px: 11, torso: 17, head: -10, tw: 34, hw: 8, sF: 78, eF: 8, wp: 4, zF: -34, wz: -64, sB: 36, eB: 70, fFx: 52, fBx: -44 }),
      K(0.17, { py: 86, px: 14, torso: 17, head: -10, tw: -26, hw: -16, sF: 79, eF: 4, wp: 7, zF: 0, wz: 0, sB: 60, eB: 40, zB: -30, fFx: 52, fBx: -44 }),
      K(0.23, { py: 88, px: 12, torso: 8, head: -5, tw: -62, hw: -30, sF: 78, eF: 8, wp: 4, zF: 46, wz: 78, sB: 78, eB: 30, zB: -44, fFx: 50, fBx: -42 }),
      K(0.29, { py: 89, px: 10, torso: 5, head: -3, tw: -76, hw: -34, sF: 74, eF: 26, wp: -10, zF: 64, wz: 126, sB: 80, eB: 34, zB: -44, fFx: 48, fBx: -40 }),
      K(0.43, {}),
    ),
  }),
  // pamungkas: BERPUTAR 360° – punggung menghadap lawan, kepala mendahului, bilah menyapu satu lingkaran penuh
  slash3: def('slash3', {
    part: 'weapon', kb: 300, stop: 0.13, heavy: true, trail0: 0.02,
    koImp: [640, 360, 0.35],
    step: { t0: 0.04, t1: 0.18, dist: 30 }, // the spin travels forward
    next: { punch: 'slash4', kick: 'roundhouse', heavy: 'heavy3' },
    anim: A(
      K(0, { py: 89, px: 10, torso: 5, head: -3, tw: -76, hw: -34, hy: 0, sF: 74, eF: 26, wp: -10, zF: 64, wz: 126, sB: 80, eB: 34, zB: -44, fFx: 48, fBx: -40 }),
      K(0.05, { py: 96, px: 16, torso: 2, head: -2, tw: -165, hw: -140, hy: -150, sF: 80, eF: 4, wp: 6, zF: 150, wz: 196, sB: 70, eB: 50, zB: 50, fFx: 30, fBx: 20, fBy: 9, fBa: -10 }),
      K(0.09, { py: 97, px: 24, torso: 0, head: 0, tw: -255, hw: -240, hy: -270, sF: 80, eF: 4, wp: 6, zF: 236, wz: 272, sB: 70, eB: 50, zB: 140, fFx: 30, fBx: 58, fBy: 4, fBa: 0 }),
      K(0.13, { py: 92, px: 16, torso: 8, head: -4, tw: -335, hw: -325, hy: -352, sF: 80, eF: 4, wp: 6, zF: 312, wz: 330, sB: 40, eB: 70, zB: 230, fFx: 32, fBx: 16, fBy: 9, fBa: -10 }),
      K(0.18, { py: 85, px: 10, torso: 20, head: -12, tw: -388, hw: -384, hy: -360, sF: 79, eF: 4, wp: 7, zF: 360, wz: 360, sB: 20, eB: 60, zB: 320, fFx: 40, fBx: -40, fBa: -18 }),
      K(0.23, { py: 83, px: 10, torso: 24, head: -14, tw: -425, hw: -398, hy: -360, sF: 80, eF: 10, wp: -6, zF: 398, wz: 414, sB: 60, eB: 40, zB: 330, fFx: 42, fBx: -40, fBa: -18 }),
      K(0.3, { py: 84, px: 8, torso: 20, head: -12, tw: -436, hw: -400, hy: -360, sF: 70, eF: 24, wp: -10, zF: 414, wz: 446, sB: 70, eB: 40, zB: 330, fFx: 40, fBx: -38 }),
      K(0.43, { tw: -380, hw: -368, hy: -360, zF: 360, zB: 360, wz: 360 }),
    ),
  }),
  // pamungkas rangkaian: melompat, melenting, lalu membanting bilah dengan dua tangan – lawan terhempas ke tanah
  slash4: def('slash4', {
    part: 'weapon', kb: 320, stop: 0.15, heavy: true, trail0: 0.09, slam: 0.2, ideal: 150,
    knock: [240, -560, 0.3], koImp: [420, -300, 0.3],
    step: { t0: 0.03, t1: 0.19, dist: 58 },
    anim: A(
      K(0, {}),
      K(0.04, { py: 82, px: 0, torso: 22, head: -12, tw: -30, hw: -10, sF: 30, eF: 40, wp: -40, zF: 20, wz: 30, sB: 40, eB: 60, fFx: 28, fBx: -30 }),
      K(0.1, { py: 127, px: 6, torso: -14, head: 4, tw: -58, hw: -24, sF: 192, eF: 64, wp: 44, zF: 30, wz: 40, sB: 186, eB: 70, zB: -20, fFx: 22, fFy: 44, fFa: -40, fBx: -16, fBy: 50, fBa: -50 }),
      K(0.135, { py: 125, px: 10, torso: -8, head: 0, tw: -44, hw: -16, sF: 176, eF: 40, wp: 26, zF: 22, wz: 28, sB: 172, eB: 44, zB: -14, fFx: 30, fFy: 36, fFa: -30, fBx: -22, fBy: 44, fBa: -50 }),
      K(0.17, { py: 100, px: 16, torso: 24, head: -14, tw: 10, hw: 10, sF: 104, eF: 6, wp: -8, zF: 0, wz: 0, sB: 110, eB: 6, zB: 0, fFx: 50, fFy: 8, fFa: -10, fBx: -40, fBy: 14, fBa: -30 }),
      K(0.21, { py: 64, px: 22, torso: 50, head: -26, tw: 34, hw: 22, sF: 56, eF: 6, wp: -14, zF: -10, wz: -14, sB: 62, eB: 8, fFx: 60, fFy: 0, fBx: -46, fBy: 0, fBa: -24 }),
      K(0.3, { py: 62, px: 22, torso: 52, head: -26, tw: 36, hw: 22, sF: 50, eF: 8, wp: -16, zF: -12, wz: -16, sB: 56, eB: 10, fFx: 60, fBx: -46, fBa: -22 }),
      K(0.43, {}),
    ),
  }),
  // sabetan naik: dari rendah di sisi jauh, menyapu ke atas sampai dada terbuka ke kamera
  rise: def('rise', {
    part: 'weapon', kb: 210, stop: 0.08, koImp: [360, 640, 0.4], trail0: 0.08,
    step: { t0: 0.04, t1: 0.18, dist: 56 }, ideal: 165,
    next: { punch: 'slash4', kick: 'knee', heavy: 'heavy1' },
    anim: A(
      K(0, {}),
      K(0.05, { py: 80, px: 2, torso: 30, head: -16, tw: 64, hw: 30, sF: -30, eF: 14, wp: -40, zF: -40, wz: -60, sB: 50, eB: 86, fFx: 34, fBx: -36 }),
      K(0.09, { py: 78, px: 2, torso: 32, head: -17, tw: 70, hw: 32, sF: -34, eF: 14, wp: -44, zF: -44, wz: -66, sB: 52, eB: 88, fFx: 34, fBx: -36 }),
      K(0.13, { py: 85, px: 8, torso: 22, head: -12, tw: 34, hw: 16, sF: 26, eF: 14, wp: 6, zF: -16, wz: -24, sB: 30, eB: 70, fFx: 42, fBx: -38 }),
      K(0.18, { py: 96, px: 14, torso: 6, head: -4, tw: -20, hw: -8, sF: 92, eF: 8, wp: 8, zF: 0, wz: 0, sB: -20, eB: 40, zB: 20, fFx: 46, fBx: -40, fBa: -16 }),
      K(0.23, { py: 103, px: 13, torso: -8, head: 4, tw: -56, hw: -24, sF: 140, eF: 16, wp: 22, zF: 30, wz: 40, sB: -34, eB: 30, zB: 20, fFx: 46, fBx: -40, fBa: -16 }),
      K(0.29, { py: 103, px: 12, torso: -10, head: 5, tw: -64, hw: -26, sF: 150, eF: 22, wp: 28, zF: 36, wz: 50, sB: -36, eB: 30, zB: 20, fFx: 46, fBx: -40 }),
      K(0.43, {}),
    ),
  }),
  // tusukan menerjang: bahu senjata dari jauh di belakang didorong lurus ke depan
  thrust: def('thrust', {
    part: 'weapon', kb: 340, stop: 0.12, heavy: true,
    koImp: [900, 300, 0.3],
    next: { punch: 'slash2', kick: 'kick2', heavy: 'heavy1' },
    step: { t0: 0.08, t1: 0.18, dist: 6 },
    anim: A(
      K(0, {}),
      K(0.05, { py: 84, px: -14, torso: -6, head: 0, tw: -78, hw: -40, sF: -50, eF: 130, wp: 10, zF: 30, wz: 20, sB: 80, eB: 20, zB: -20, fFx: 22, fBx: -38 }),
      K(0.095, { py: 84, px: -14, torso: -6, head: 0, tw: -78, hw: -40, sF: -50, eF: 130, wp: 10, zF: 30, wz: 20, sB: 80, eB: 20, zB: -20, fFx: 22, fBx: -38 }),
      K(0.13, { py: 80, px: 2, torso: 14, head: -10, tw: -18, hw: 12, sF: 20, eF: 70, wp: 0, zF: 14, wz: 8, sB: 20, eB: 30, fFx: 44, fFy: 5, fBx: -42 }),
      K(0.18, { py: 76, px: 14, torso: 28, head: -20, tw: 68, hw: 42, sF: 88, eF: 2, wp: 0, zF: 0, wz: 0, sB: -45, eB: 25, zB: 30, fFx: 66, fBx: -48, fBy: 4, fBa: -30 }),
      K(0.23, { py: 76, px: 14, torso: 29, head: -20, tw: 74, hw: 44, sF: 88, eF: 3, wp: 0, sB: -47, eB: 25, zB: 30, fFx: 66, fBx: -48, fBy: 4, fBa: -30 }),
      K(0.3, { py: 78, px: 12, torso: 26, head: -16, tw: 50, hw: 30, sF: 80, eF: 14, wp: 2, sB: -30, eB: 34, fFx: 62, fBx: -46, fBa: -20 }),
      K(0.43, {}),
    ),
  }),
  // sabetan rendah mendatar setinggi lutut: dari sisi kamera, lewat depan, ke sisi jauh
  lowslash: def('lowslash', {
    part: 'weapon', kb: 190, stop: 0.07, koImp: [420, 260, 0.6], trail0: 0.05,
    next: { punch: 'slash2', kick: 'kick1', heavy: 'heavy2' },
    anim: A(
      K(0, {}),
      K(0.05, { py: 64, px: -2, torso: 24, head: -14, tw: -68, hw: -30, sF: 40, eF: 20, wp: 0, zF: 110, wz: 150, sB: 60, eB: 80, fFx: 34, fBx: -40 }),
      K(0.095, { py: 64, px: -2, torso: 24, head: -14, tw: -68, hw: -30, sF: 40, eF: 20, wp: 0, zF: 110, wz: 150, sB: 60, eB: 80, fFx: 34, fBx: -40 }),
      K(0.13, { py: 58, px: 6, torso: 30, head: -18, tw: -20, hw: 10, sF: 48, eF: 12, wp: 8, zF: 46, wz: 66, sB: 34, eB: 70, fFx: 40, fBx: -42 }),
      K(0.18, { py: 55, px: 10, torso: 36, head: -22, tw: 36, hw: 30, sF: 50, eF: 6, wp: 14, zF: 0, wz: 0, sB: 10, eB: 60, zB: 20, fFx: 42, fBx: -42 }),
      K(0.23, { py: 56, px: 10, torso: 34, head: -20, tw: 62, hw: 36, sF: 52, eF: 10, wp: 12, zF: -40, wz: -60, sB: -6, eB: 50, zB: 30, fFx: 42, fBx: -42 }),
      K(0.3, { py: 60, px: 8, torso: 30, head: -18, tw: 70, hw: 36, sF: 50, eF: 16, wp: 8, zF: -56, wz: -96, sB: -8, eB: 50, fFx: 40, fBx: -42 }),
      K(0.43, {}),
    ),
  }),
  // pelambung: menggulung rendah lalu membuka ke atas
  upper: def('upper', {
    part: 'weapon', kb: 200, stop: 0.12, heavy: true,
    knock: [60, 640, 0.25], koImp: [230, 760, 0.25],
    next: { punch: 'slash2', kick: 'roundhouse', heavy: 'heavy3' },
    step: { t0: 0.07, t1: 0.2, dist: 12 },
    anim: A(
      K(0, {}),
      K(0.05, { py: 66, px: 0, torso: 32, head: -18, tw: 60, hw: 30, sF: -35, eF: 10, wp: -40, zF: -30, wz: -50, sB: 55, eB: 85, fFx: 36, fBx: -38 }),
      K(0.095, { py: 66, px: 0, torso: 32, head: -18, tw: 60, hw: 30, sF: -35, eF: 10, wp: -40, zF: -30, wz: -50, sB: 55, eB: 85, fFx: 36, fBx: -38 }),
      K(0.13, { py: 82, px: 8, torso: 18, head: -10, tw: 30, hw: 20, sF: 40, eF: 16, wp: 6, zF: -12, wz: -20, sB: 24, eB: 60, fFx: 40, fBx: -38 }),
      K(0.18, { py: 99, px: 12, torso: -2, head: 2, tw: -10, hw: 0, sF: 104, eF: 14, wp: 14, zF: 0, wz: 0, sB: -10, eB: 40, fFx: 42, fBx: -36, fBy: 4, fBa: -25 }),
      K(0.23, { py: 105, px: 12, torso: -12, head: 8, tw: -46, hw: -20, sF: 150, eF: 18, wp: 20, zF: 20, wz: 30, sB: -30, eB: 30, zB: -30, fFx: 42, fFy: 3, fFa: -20, fBx: -34, fBy: 6, fBa: -30 }),
      K(0.3, { py: 104, px: 11, torso: -13, head: 8, tw: -56, hw: -24, sF: 160, eF: 22, wp: 24, zF: 28, wz: 40, sB: -32, eB: 30, zB: -30, fFx: 42, fFy: 2, fFa: -14, fBx: -34, fBy: 4, fBa: -24 }),
      K(0.43, {}),
    ),
  }),
  airslash: def('airslash', {
    part: 'weapon', kb: 260, stop: 0.09, air: true, koImp: [480, 200, 0.4],
    anim: A(
      K(0, { ...AIRLEGS }),
      K(0.07, { ...AIRLEGS, torso: -12, head: 2, tw: -66, hw: -30, sF: 160, eF: 92, wp: 35, zF: 36, wz: 46, sB: 70, eB: 40 }),
      K(0.13, { ...AIRLEGS, torso: 8, head: -6, tw: -20, hw: 10, sF: 118, eF: 28, wp: -10, zF: 20, wz: 24, sB: 30, eB: 60 }),
      K(0.18, { ...AIRLEGS, torso: 26, head: -14, tw: 36, hw: 26, sF: 84, eF: 8, wp: -8, sB: 0, eB: 50, fFx: 30, fFy: 44 }),
      K(0.23, { ...AIRLEGS, torso: 34, head: -16, tw: 62, hw: 30, sF: 48, eF: 8, wp: -10, zF: -28, wz: -36, sB: -20, eB: 40, fFx: 30, fFy: 44 }),
      K(0.43, { ...AIRLEGS, torso: 34, head: -16, tw: 66, hw: 30, sF: 36, eF: 12, wp: -10, zF: -36, wz: -50, sB: -22, eB: 40, fFx: 30, fFy: 44 }),
    ),
  }),

  // ══ PUKULAN TANGAN KOSONG (setelah SHOCK) ══
  jab: def('jab', {
    part: 'handF', kb: 170, stop: 0.05, koImp: [460, 280, 0.4],
    step: { t0: 0.03, t1: 0.16, dist: 18 },
    next: { punch: 'cross', kick: 'kick1', heavy: 'heavy1' },
    anim: A(
      K(0, {}),
      K(0.07, { py: 96, px: -4, torso: 2, head: -2, tw: -44, hw: -16, sF: 16, eF: 116, sB: 42, eB: 104, fFx: 30, fBx: -34 }),
      K(0.13, { py: 93, px: 6, torso: 12, head: -8, tw: 10, hw: 6, sF: 70, eF: 40, sB: 36, eB: 110, fFx: 38, fBx: -36 }),
      K(0.17, { py: 91, px: 11, torso: 17, head: -10, tw: 58, hw: 26, sF: 88, eF: 4, sB: 30, eB: 114, fFx: 41, fBx: -38 }),
      K(0.23, { py: 92, px: 9, torso: 14, head: -8, tw: 30, hw: 14, sF: 74, eF: 36, sB: 32, eB: 112, fFx: 40, fBx: -38 }),
      K(0.43, {}),
    ),
  }),
  cross: def('cross', {
    part: 'handB', kb: 230, stop: 0.07, koImp: [540, 300, 0.4],
    step: { t0: 0.03, t1: 0.17, dist: 22 },
    next: { punch: 'uppercut', kick: 'kick2', heavy: 'heavy2' },
    anim: A(
      K(0, { py: 92, px: 9, torso: 14, tw: 30, hw: 14, sF: 74, eF: 36, sB: 32, eB: 112 }),
      K(0.07, { py: 94, px: 0, torso: -6, head: 2, tw: 46, hw: 20, sF: 30, eF: 104, sB: 8, eB: 124, fFx: 34, fBx: -36 }),
      K(0.13, { py: 91, px: 10, torso: 14, head: -8, tw: -30, hw: -24, sF: 24, eF: 110, sB: 62, eB: 50, fFx: 40, fBx: -42, fBa: -14 }),
      K(0.18, { py: 88, px: 17, torso: 28, head: -14, tw: -86, hw: -52, sF: 18, eF: 114, sB: 90, eB: 2, fFx: 42, fBx: -45, fBa: -22 }),
      K(0.23, { py: 89, px: 15, torso: 25, head: -13, tw: -70, hw: -44, sF: 20, eF: 112, sB: 80, eB: 26, fFx: 42, fBx: -45, fBa: -20 }),
      K(0.43, {}),
    ),
  }),
  uppercut: def('uppercut', {
    part: 'handF', kb: 220, stop: 0.11, heavy: true,
    knock: [60, 560, 0.3], koImp: [230, 700, 0.3],
    step: { t0: 0.07, t1: 0.2, dist: 24 },
    anim: A(
      K(0, {}),
      K(0.07, { py: 66, px: 0, torso: 30, head: -16, tw: 52, hw: 26, sF: -24, eF: 60, sB: 52, eB: 94, fFx: 36, fBx: -38 }),
      K(0.13, { py: 82, px: 8, torso: 14, head: -8, tw: 20, hw: 14, sF: 30, eF: 84, sB: 30, eB: 70, fFx: 40, fBx: -38 }),
      K(0.18, { py: 98, px: 13, torso: -4, head: 4, tw: -24, hw: -10, sF: 96, eF: 66, sB: -10, eB: 46, fFx: 43, fBx: -36, fBy: 3, fBa: -20 }),
      K(0.23, { py: 104, px: 14, torso: -10, head: 8, tw: -48, hw: -20, sF: 134, eF: 50, sB: -22, eB: 40, fFx: 44, fBx: -36, fBy: 4, fBa: -24 }),
      K(0.3, { py: 103, px: 13, torso: -11, head: 8, tw: -50, hw: -20, sF: 140, eF: 46, sB: -24, eB: 40, fFx: 44, fBx: -36, fBy: 3, fBa: -20 }),
      K(0.43, {}),
    ),
  }),

  // ══ TENDANGAN ══ timeline dasar: startup 0.20 · active 0.12 · recovery 0.30
  // tendangan depan: pinggul sisi kaki didorong maju, bahu memutar berlawanan sebagai penyeimbang
  kick1: def('kick1', {
    part: 'footF', kb: 260, stop: 0.07, koImp: [560, 280, 0.4],
    step: { t0: 0.02, t1: 0.19, dist: 95 },
    next: { kick: 'kick2', punch: 'rise', heavy: 'hkick' },
    anim: A(
      K(0, {}),
      K(0.05, { py: 92, px: 0, torso: 6, head: -2, tw: -14, hw: -4, fFx: 22, fBx: -14, fBy: 14, fBa: -22, sF: 6, eF: 36, sB: 42, eB: 98 }),
      K(0.1, { py: 93, px: -2, torso: 2, head: 0, tw: 0, hw: -14, fFx: -13, fFa: -16, fBx: 12, fBy: 0, sF: -5, eF: 40, sB: 46, eB: 100 }),
      K(0.15, { py: 95, px: -6, torso: -10, head: 8, tw: -34, hw: 26, fFx: 20, fFy: 52, fFa: -30, fBx: -27, sF: -20, eF: 36, wp: 18, zF: 30, sB: 52, eB: 92, zB: -30 }),
      K(0.2, { py: 96, px: -8, torso: -22, head: 16, tw: -56, hw: 54, fFx: 100, fFy: 92, fFa: 55, fBx: -40, sF: -35, eF: 30, wp: 20, zF: 40, sB: 56, eB: 85, zB: -40 }),
      K(0.32, { py: 96, px: -8, torso: -21, head: 16, tw: -56, hw: 54, fFx: 98, fFy: 90, fFa: 55, fBx: -40, sF: -35, eF: 30, wp: 20, zF: 40, sB: 56, eB: 85, zB: -40 }),
      K(0.42, { py: 94, px: -4, torso: -8, head: 6, tw: -36, hw: 20, fFx: 34, fFy: 44, fFa: -20, fBx: -38, sF: -10, eF: 34, sB: 46, eB: 96 }),
      K(0.52, { py: 96, px: 0, torso: 6, head: -2, tw: -22, hw: -4, fFx: 34, fFy: 0, fBx: -36 }),
      K(0.62, {}),
    ),
  }),
  // tendangan putar belakang: berbalik memunggungi lawan (kepala lebih dulu), lalu kaki belakang menghunjam lurus
  kick2: def('kick2', {
    part: 'footB', kb: 380, stop: 0.11, heavy: true, koImp: [860, 280, 0.35],
    step: { t0: 0.02, t1: 0.19, dist: 80 }, ideal: 150,
    next: { kick: 'knee', punch: 'slash3', heavy: 'hkick' },
    anim: A(
      K(0, {}),
      K(0.06, { py: 100, px: 4, torso: 4, head: -2, tw: -80, hw: -64, hy: -100, sF: 30, eF: 70, wp: 10, sB: 50, eB: 90, fFx: 26, fBx: -18, fBy: 8, fBa: -16 }),
      K(0.13, { py: 99, px: 8, torso: -12, head: 6, tw: -170, hw: -178, hy: -250, lB: -70, sF: 40, eF: 90, wp: 10, sB: 44, eB: 100, fFx: 14, fBx: 12, fBy: 54, fBa: -20 }),
      K(0.2, { py: 100, px: 8, torso: -46, head: 30, tw: -214, hw: -232, hy: -326, lB: 0, sF: -16, eF: 44, wp: 26, sB: 76, eB: 56, fFx: -8, fBx: 118, fBy: 94, fBa: 60 }),
      K(0.32, { py: 100, px: 8, torso: -44, head: 30, tw: -236, hw: -256, hy: -340, lB: 0, sF: -16, eF: 44, wp: 26, sB: 76, eB: 56, fFx: -8, fBx: 116, fBy: 94, fBa: 60 }),
      K(0.44, { py: 98, px: 6, torso: -12, head: 6, tw: -322, hw: -330, hy: -360, lB: 36, sF: 0, eF: 44, sB: 56, eB: 90, fFx: -2, fBx: 28, fBy: 44, fBa: -20 }),
      K(0.54, { py: 99, px: 2, torso: 4, head: -2, tw: -372, hw: -364, hy: -360, sF: 10, eF: 36, sB: 40, eB: 96, fFx: 14, fFy: 4, fBx: -28, fBy: 0 }),
      K(0.62, { tw: -380, hw: -368, hy: -360 }),
    ),
  }),
  // lutut terbang: meraih kepala lawan lalu menghunjamkan lutut sambil melompat – lawan terangkat
  knee: def('knee', {
    part: 'footF', kb: 200, stop: 0.1, heavy: true,
    knock: [50, 500, 0.35], koImp: [300, 620, 0.35],
    step: { t0: 0.03, t1: 0.2, dist: 150 }, ideal: 110, // flies in as far as needed
    next: { kick: 'axe', punch: 'slash4', heavy: 'heavy3' },
    anim: A(
      K(0, {}),
      K(0.06, { py: 94, px: 4, torso: 14, head: -8, tw: -30, hw: -10, sF: 62, eF: 40, wp: 60, wz: 60, sB: 70, eB: 40, fFx: 30, fBx: -18, fBy: 8, fBa: -16 }),
      K(0.13, { py: 100, px: 10, torso: 10, head: -6, tw: -10, hw: 10, sF: 102, eF: 20, wp: 70, wz: 70, sB: 106, eB: 20, zB: 10, fFx: 30, fFy: 20, fFa: -40, fBx: -30, fBa: -30 }),
      K(0.2, { py: 113, px: 22, torso: 16, head: -10, tw: 20, hw: 40, sF: 72, eF: 50, wp: 60, wz: 70, sB: 76, eB: 50, fFx: 60, fFy: 62, fFa: -50, fBx: -24, fBy: 16, fBa: -40 }),
      K(0.26, { py: 119, px: 28, torso: 20, head: -12, tw: 30, hw: 50, sF: 52, eF: 70, wp: 60, wz: 70, sB: 56, eB: 70, fFx: 66, fFy: 76, fFa: -60, fBx: -20, fBy: 26, fBa: -44 }),
      K(0.32, { py: 118, px: 28, torso: 20, head: -12, tw: 30, hw: 50, sF: 50, eF: 72, wp: 60, wz: 70, sB: 54, eB: 72, fFx: 66, fFy: 74, fFa: -60, fBx: -20, fBy: 24, fBa: -44 }),
      K(0.45, { py: 92, px: 10, torso: 10, head: -6, tw: -10, hw: 0, sF: 30, eF: 40, sB: 44, eB: 90, fFx: 36, fFy: 4, fBx: -26, fBy: 0 }),
      K(0.62, {}),
    ),
  }),
  // tendangan kapak: kaki diayun lurus melewati kepala, lalu tumit dihempaskan ke bawah
  axe: def('axe', {
    part: 'footF', kb: 260, stop: 0.13, heavy: true, slam: 0.33,
    knock: [200, -520, 0.4], koImp: [380, -260, 0.4],
    step: { t0: 0.02, t1: 0.2, dist: 60 }, ideal: 86,
    anim: A(
      K(0, {}),
      K(0.06, { py: 101, px: -4, torso: -4, head: 2, tw: -30, hw: 10, fFx: 26, fFy: 30, fFa: -20, fBx: -28, sF: -10, eF: 40, sB: 50, eB: 90 }),
      K(0.13, { py: 104, px: -6, torso: -22, head: 14, tw: -46, hw: 30, lF: 50, fFx: 50, fFy: 150, fFa: 60, fBx: -30, sF: -30, eF: 30, wp: 20, zF: 30, sB: 70, eB: 60 }),
      K(0.2, { py: 106, px: -4, torso: -28, head: 18, tw: -50, hw: 40, lF: 0, fFx: 38, fFy: 200, fFa: 76, fBx: -30, sF: -36, eF: 30, wp: 20, zF: 30, sB: 76, eB: 56 }),
      K(0.26, { py: 99, px: 4, torso: -8, head: 4, tw: -20, hw: 30, fFx: 96, fFy: 122, fFa: 20, fBx: -34, sF: -10, eF: 36, sB: 60, eB: 70 }),
      K(0.32, { py: 86, px: 12, torso: 14, head: -8, tw: 10, hw: 20, fFx: 86, fFy: 12, fFa: 10, fBx: -36, sF: 20, eF: 40, sB: 40, eB: 90 }),
      K(0.44, { py: 84, px: 12, torso: 16, head: -9, tw: 10, hw: 16, fFx: 72, fFy: 0, fBx: -36 }),
      K(0.62, {}),
    ),
  }),
  // tendangan samping: badan berputar menghadap kamera, kaki belakang menghunjam lurus
  sidekick: def('sidekick', {
    part: 'footB', kb: 520, stop: 0.1, heavy: true, koImp: [820, 260, 0.35],
    next: { kick: 'kick2', punch: 'slash3', heavy: 'hkick' },
    step: { t0: 0.02, t1: 0.19, dist: 85 },
    anim: A(
      K(0, {}),
      K(0.05, { py: 92, px: 2, torso: 6, head: -2, tw: -34, hw: -30, fFx: 34, fFy: 10, fFa: -12, fBx: -42, fBa: -20, sF: 6, eF: 40, sB: 44, eB: 98 }),
      K(0.1, { py: 96, px: 6, torso: -4, head: 2, tw: -62, hw: -70, lB: -50, fFx: 36, fFy: 0, fBx: -20, fBy: 40, fBa: -30, sF: 0, eF: 46, sB: 52, eB: 96 }),
      K(0.15, { py: 98, px: 8, torso: -20, head: 12, tw: -80, hw: -95, lB: -30, fFx: 2, fBx: 20, fBy: 72, fBa: -10, sF: -10, eF: 44, wp: 20, sB: 62, eB: 88 }),
      K(0.2, { py: 98, px: 8, torso: -40, head: 28, tw: -88, hw: -105, lB: 0, fFx: -10, fBx: 112, fBy: 96, fBa: 60, sF: -20, eF: 40, wp: 30, sB: 70, eB: 70 }),
      K(0.32, { py: 98, px: 8, torso: -39, head: 28, tw: -88, hw: -105, lB: 0, fFx: -10, fBx: 110, fBy: 96, fBa: 60, sF: -20, eF: 40, wp: 30, sB: 70, eB: 70 }),
      K(0.44, { py: 95, px: 6, torso: -14, head: 8, tw: -60, hw: -60, lB: -20, fFx: -6, fBx: 30, fBy: 46, fBa: -20, sF: -6, eF: 40, sB: 56, eB: 90 }),
      K(0.54, { py: 96, px: 2, torso: 4, head: -2, tw: -30, hw: -20, fFx: 12, fFy: 6, fBx: -30, fBy: 0 }),
      K(0.62, {}),
    ),
  }),
  // sapuan kaki: kaki menyapu mendatar dari sisi kamera ke depan
  sweep: def('sweep', {
    part: 'footF', kb: 150, stop: 0.08,
    knock: [330, 400, 0.9], koImp: [420, 460, 0.85],
    step: { t0: 0.02, t1: 0.19, dist: 80 },
    anim: A(
      K(0, {}),
      K(0.05, { py: 80, px: 0, torso: 16, head: -8, tw: -30, hw: -20, fFx: 23, fBx: -18, fBy: 10, fBa: -20, sF: 20, eF: 36, sB: 40, eB: 90 }),
      K(0.1, { py: 60, px: -2, torso: 22, head: -12, tw: -50, hw: -40, fFx: -6, fFa: -10, fBx: 6, fBy: 0, sF: 30, eF: 30, sB: 30, eB: 70 }),
      K(0.15, { py: 49, px: -8, torso: 0, head: 6, tw: -60, hw: -50, lF: 66, fFx: 90, fFy: 6, fFa: 10, fBx: -27, sF: -20, eF: 24, wp: 30, sB: -10, eB: 40 }),
      K(0.2, { py: 44, px: -14, torso: -22, head: 20, tw: -10, hw: 30, lF: 0, fFx: 104, fFy: 3, fFa: 25, fBx: -38, sF: -50, eF: 20, wp: 40, sB: -40, eB: 30 }),
      K(0.32, { py: 44, px: -13, torso: -20, head: 19, tw: 30, hw: 55, lF: -32, fFx: 100, fFy: 3, fFa: 25, fBx: -38, sF: -50, eF: 20, wp: 40, sB: -40, eB: 30 }),
      K(0.44, { py: 56, px: -6, torso: 6, head: 0, tw: 0, hw: 20, lF: -10, fFx: 50, fFy: 10, fFa: 0, fBx: -36, sF: -10, eF: 30, sB: 10, eB: 60 }),
      K(0.54, { py: 78, px: -1, torso: 14, head: -6, fFx: 32, fFy: 0, fBx: -35 }),
      K(0.62, {}),
    ),
  }),
  // tendangan memutar tinggi: lutut diangkat ke samping, pinggul berputar penuh, kaki mencambuk mengelilingi badan
  roundhouse: def('roundhouse', {
    part: 'footB', kb: 300, stop: 0.13, heavy: true,
    knock: [600, 300, 0.6], koImp: [760, 380, 0.6],
    step: { t0: 0.02, t1: 0.19, dist: 85 },
    anim: A(
      K(0, {}),
      K(0.05, { py: 92, px: 2, torso: 6, head: -2, tw: -26, hw: -24, fFx: 34, fFy: 10, fFa: -12, fBx: -42, fBa: -20, sF: 8, eF: 44, sB: 44, eB: 96 }),
      K(0.1, { py: 97, px: 5, torso: -6, head: 4, tw: -34, hw: -56, lB: -84, fFx: 36, fFy: 0, fBx: 40, fBy: 76, fBa: -30, sF: 10, eF: 56, sB: 54, eB: 90 }),
      K(0.15, { py: 99, px: 5, torso: -24, head: 16, tw: -46, hw: -94, lB: -54, fFx: 2, fBx: 72, fBy: 124, fBa: -6, sF: -8, eF: 46, wp: 20, zF: 30, sB: 66, eB: 70 }),
      K(0.2, { py: 100, px: 4, torso: -44, head: 30, tw: -62, hw: -130, lB: 0, fFx: -10, fBx: 92, fBy: 146, fBa: 35, sF: -30, eF: 30, wp: 30, zF: 40, sB: 80, eB: 50 }),
      K(0.32, { py: 100, px: 4, torso: -42, head: 30, tw: -66, hw: -142, lB: 24, fFx: -10, fBx: 86, fBy: 148, fBa: 35, sF: -30, eF: 30, wp: 30, zF: 40, sB: 80, eB: 50 }),
      K(0.44, { py: 96, px: 4, torso: -14, head: 8, tw: -40, hw: -70, lB: 10, fFx: -6, fBx: 30, fBy: 46, fBa: -20, sF: -6, eF: 40, sB: 56, eB: 90 }),
      K(0.54, { py: 96, px: 2, torso: 4, head: -2, tw: -26, hw: -20, fFx: 12, fFy: 6, fBx: -30, fBy: 0 }),
      K(0.62, {}),
    ),
  }),
  airkick: def('airkick', {
    part: 'footF', kb: 320, stop: 0.11, air: true, heavy: true,
    knock: [640, 260, 0.4], koImp: [780, 320, 0.4],
    anim: A(
      K(0, { ...AIRLEGS }),
      K(0.1, { py: 95, torso: -10, head: 8, tw: -36, hw: 20, fFx: 30, fFy: 58, fFa: -20, fBx: -18, fBy: 44, fBa: -40, sF: -10, eF: 40, sB: 56, eB: 86 }),
      K(0.2, { py: 95, torso: -34, head: 24, tw: -58, hw: 52, fFx: 92, fFy: 60, fFa: 30, fBx: -14, fBy: 54, fBa: -40, sF: -40, eF: 40, wp: 30, zF: 36, sB: 60, eB: 80, zB: -36 }),
      K(0.62, { py: 95, torso: -34, head: 24, tw: -58, hw: 52, fFx: 92, fFy: 60, fFa: 30, fBx: -14, fBy: 54, fBa: -40, sF: -40, eF: 40, wp: 30, zF: 36, sB: 60, eB: 80, zB: -36 }),
    ),
  }),

  // ══ SERANGAN BERAT (H) ══ timeline dasar: startup 0.24 · active 0.12 · recovery 0.40
  // belah gunung: bilah diangkat dua tangan jauh ke belakang kepala, kaki depan dihentak, lalu dibanting sampai ke tanah
  heavy1: def('heavy1', {
    part: 'weapon', kb: 360, stop: 0.15, heavy: true, trail0: 0.17, slam: 0.31,
    koImp: [520, -200, 0.3],
    step: { t0: 0.18, t1: 0.3, dist: 46 }, ideal: 178,
    next: { heavy: 'heavy2', punch: 'rise', kick: 'knee' },
    anim: A(
      K(0, {}),
      K(0.08, { py: 104, px: -12, torso: -16, head: 6, tw: -60, hw: -30, sF: 186, eF: 40, wp: 6, zF: 14, wz: 16, sB: 180, eB: 46, zB: -10, fFx: 14, fFy: 14, fFa: -16, fBx: -32 }),
      K(0.19, { py: 108, px: -15, torso: -21, head: 8, tw: -68, hw: -34, sF: 194, eF: 46, wp: 10, zF: 16, wz: 18, sB: 188, eB: 52, zB: -10, fFx: 20, fFy: 22, fFa: -20, fBx: -32 }),
      K(0.24, { py: 100, px: 4, torso: 4, head: -4, tw: -10, hw: 10, sF: 142, eF: 20, wp: -6, zF: 10, wz: 12, sB: 148, eB: 22, fFx: 46, fFy: 8, fFa: -6, fBx: -40 }),
      K(0.29, { py: 80, px: 18, torso: 34, head: -20, tw: 30, hw: 26, sF: 84, eF: 6, wp: -4, zF: 0, wz: 0, sB: 90, eB: 6, fFx: 58, fFy: 0, fBx: -46, fBa: -22 }),
      K(0.33, { py: 68, px: 22, torso: 50, head: -26, tw: 44, hw: 30, sF: 48, eF: 6, wp: -10, zF: -10, wz: -14, sB: 54, eB: 8, fFx: 58, fBx: -46, fBa: -22 }),
      K(0.36, { py: 66, px: 22, torso: 52, head: -26, tw: 46, hw: 30, sF: 42, eF: 8, wp: -12, zF: -10, wz: -14, sB: 48, eB: 10, fFx: 58, fBx: -46, fBa: -22 }),
      K(0.5, { py: 66, px: 22, torso: 52, head: -24, tw: 46, hw: 30, sF: 42, eF: 8, wp: -12, zF: -10, wz: -14, sB: 48, eB: 10, fFx: 58, fBx: -46, fBa: -20 }),
      K(0.76, {}),
    ),
  }),
  // tebasan langit: merunduk dalam, lalu meledak ke atas dengan bilah dari tanah ke langit – lawan terlempar tinggi
  heavy2: def('heavy2', {
    part: 'weapon', kb: 240, stop: 0.15, heavy: true, trail0: 0.19,
    knock: [50, 720, 0.25], koImp: [220, 820, 0.25],
    step: { t0: 0.17, t1: 0.3, dist: 70 }, ideal: 160,
    next: { heavy: 'heavy3', punch: 'slash2', kick: 'roundhouse' },
    anim: A(
      K(0, {}),
      K(0.09, { py: 58, px: -6, torso: 36, head: -18, tw: 66, hw: 34, sF: -40, eF: 12, wp: -44, zF: -30, wz: -50, sB: -30, eB: 30, zB: 30, fFx: 38, fBx: -40 }),
      K(0.2, { py: 54, px: -8, torso: 40, head: -20, tw: 72, hw: 36, sF: -44, eF: 12, wp: -48, zF: -34, wz: -56, sB: -34, eB: 30, zB: 30, fFx: 38, fBx: -40 }),
      K(0.24, { py: 78, px: 6, torso: 22, head: -12, tw: 30, hw: 20, sF: 30, eF: 14, wp: 0, zF: -10, wz: -16, sB: 36, eB: 16, fFx: 44, fBx: -40 }),
      K(0.29, { py: 106, px: 14, torso: 0, head: 0, tw: -16, hw: -4, sF: 100, eF: 10, wp: 10, zF: 0, wz: 0, sB: 104, eB: 12, fFx: 42, fFy: 6, fFa: -20, fBx: -34, fBy: 8, fBa: -30 }),
      K(0.33, { py: 122, px: 16, torso: -16, head: 10, tw: -50, hw: -22, sF: 160, eF: 14, wp: 20, zF: 24, wz: 34, sB: 150, eB: 20, zB: -20, fFx: 34, fFy: 26, fFa: -30, fBx: -30, fBy: 30, fBa: -44 }),
      K(0.36, { py: 124, px: 16, torso: -18, head: 10, tw: -54, hw: -24, sF: 170, eF: 18, wp: 26, zF: 26, wz: 38, sB: 158, eB: 22, zB: -20, fFx: 34, fFy: 28, fFa: -30, fBx: -30, fBy: 32, fBa: -44 }),
      K(0.5, { py: 92, px: 12, torso: 4, head: -2, tw: -40, hw: -16, sF: 150, eF: 30, wp: 30, zF: 20, wz: 30, sB: 60, eB: 60, fFx: 36, fFy: 0, fBx: -32, fBy: 0 }),
      K(0.76, {}),
    ),
  }),
  // roda maut: salto ke depan dengan bilah terentang – bilah berputar satu lingkaran penuh lalu membelah dari atas
  heavy3: def('heavy3', {
    part: 'weapon', kb: 420, stop: 0.17, heavy: true, trail0: 0.1, slam: 0.36,
    knock: [300, -620, 0.3], koImp: [460, -300, 0.3],
    step: { t0: 0.08, t1: 0.35, dist: 130 }, ideal: 176,
    spin: { t0: 0.1, t1: 0.345, turns: 1 },
    anim: A(
      K(0, {}),
      K(0.07, { py: 76, px: 0, torso: 28, head: -14, tw: -10, hw: 0, sF: 70, eF: 30, wp: -20, sB: 74, eB: 40, fFx: 28, fBx: -30 }),
      K(0.13, { py: 116, px: 8, torso: 24, head: -6, tw: 0, hw: 0, sF: 96, eF: 6, wp: 0, zF: 0, wz: 0, sB: 100, eB: 8, fFx: 22, fFy: 36, fFa: -30, fBx: -8, fBy: 42, fBa: -40 }),
      K(0.2, { py: 130, px: 10, torso: 34, head: 4, tw: 0, hw: 0, sF: 98, eF: 4, wp: 0, sB: 102, eB: 6, fFx: 28, fFy: 62, fFa: -20, fBx: 8, fBy: 60, fBa: -24 }),
      K(0.29, { py: 128, px: 12, torso: 34, head: 2, tw: 0, hw: 0, sF: 98, eF: 4, wp: 0, sB: 102, eB: 6, fFx: 28, fFy: 60, fFa: -20, fBx: 8, fBy: 58, fBa: -24 }),
      K(0.345, { py: 84, px: 16, torso: 40, head: -22, tw: 30, hw: 20, sF: 62, eF: 6, wp: -8, sB: 68, eB: 8, fFx: 58, fFy: 0, fBx: -44, fBy: 0, fBa: -22 }),
      K(0.38, { py: 68, px: 20, torso: 50, head: -26, tw: 40, hw: 26, sF: 46, eF: 6, wp: -12, sB: 52, eB: 8, fFx: 58, fBx: -44, fBa: -22 }),
      K(0.52, { py: 68, px: 20, torso: 50, head: -24, tw: 40, hw: 26, sF: 44, eF: 8, wp: -12, sB: 50, eB: 10, fFx: 58, fBx: -44, fBa: -20 }),
      K(0.76, {}),
    ),
  }),
  // tendangan topan (H setelah tendangan): melompat sambil berputar 360°, kaki mencambuk setinggi kepala
  hkick: def('hkick', {
    part: 'footB', kb: 420, stop: 0.16, heavy: true,
    knock: [700, 330, 0.5], koImp: [880, 400, 0.5],
    step: { t0: 0.08, t1: 0.3, dist: 96 }, ideal: 132,
    anim: A(
      K(0, {}),
      K(0.08, { py: 84, px: 2, torso: 14, head: -8, tw: -60, hw: -40, hy: -50, sF: 30, eF: 70, wp: 10, sB: 50, eB: 90, fFx: 26, fBx: -24 }),
      K(0.16, { py: 116, px: 8, torso: -4, head: 2, tw: -170, hw: -180, hy: -250, lB: -60, sF: 40, eF: 84, wp: 10, sB: 44, eB: 98, fFx: 14, fFy: 30, fFa: -30, fBx: 6, fBy: 54, fBa: -30 }),
      K(0.24, { py: 122, px: 12, torso: -34, head: 22, tw: -232, hw: -252, hy: -330, lB: -24, sF: -10, eF: 40, wp: 26, sB: 80, eB: 50, fFx: 0, fFy: 42, fFa: -30, fBx: 100, fBy: 140, fBa: 50 }),
      K(0.3, { py: 122, px: 14, torso: -44, head: 30, tw: -262, hw: -292, hy: -350, lB: 0, sF: -16, eF: 40, wp: 26, sB: 84, eB: 46, fFx: -6, fFy: 44, fFa: -30, fBx: 104, fBy: 150, fBa: 55 }),
      K(0.36, { py: 120, px: 14, torso: -40, head: 28, tw: -300, hw: -330, hy: -360, lB: 34, sF: -10, eF: 40, wp: 26, sB: 80, eB: 50, fFx: -6, fFy: 40, fFa: -30, fBx: 96, fBy: 140, fBa: 50 }),
      K(0.5, { py: 88, px: 8, torso: 8, head: -4, tw: -366, hw: -362, hy: -360, sF: 10, eF: 40, sB: 44, eB: 92, fFx: -4, fFy: 0, fBx: 30, fBy: 0 }),
      K(0.62, { py: 98, px: 2, torso: 7, tw: -378, hw: -368, hy: -360, fFx: 12, fBx: -20 }),
      K(0.76, { tw: -380, hw: -368, hy: -360 }),
    ),
  }),

  // ══ LEMPARAN ══ timeline dasar: startup 0.20 · active 0.10 · recovery 0.62
  // (animasi di bawah adalah cengkeraman yang MELESET; bila kena, A_THROW_DO mengambil alih)
  throw: def('throw', {
    part: 'grab', kb: 0, stop: 0.08, koImp: [520, 100, 0.15],
    step: { t0: 0.04, t1: 0.2, dist: 34 },
    anim: A(
      K(0, {}),
      K(0.1, { py: 86, px: 4, torso: 12, head: -8, sF: 40, eF: 70, wp: -60, sB: 50, eB: 80, fFx: 38, fFy: 6, fBx: -36 }),
      K(0.2, { py: 82, px: 16, torso: 26, head: -16, tw: 0, sF: 76, eF: 14, wp: -80, sB: 84, eB: 10, fFx: 48, fBx: -40, fBa: -18 }),
      K(0.3, { py: 80, px: 19, torso: 30, head: -18, tw: 0, sF: 74, eF: 44, wp: -84, sB: 80, eB: 42, fFx: 48, fBx: -40, fBa: -18 }),
      K(0.46, { py: 76, px: 24, torso: 42, head: -14, sF: 50, eF: 70, wp: -60, sB: 56, eB: 70, fFx: 52, fBx: -30, fBy: 8, fBa: -30 }),
      K(0.66, { py: 84, px: 12, torso: 24, head: -10, sF: 30, eF: 50, wp: -20, sB: 44, eB: 84, fFx: 44, fBx: -34 }),
      K(0.92, {}),
    ),
  }),

  // ══ SUPER STRIKE ══ timeline dasar: startup 0.34 · active 0.18 · recovery 0.55
  super: def('super', {
    part: 'weapon', kb: 420, stop: 0.2, heavy: true,
    knock: [900, 430, 0.3], koImp: [1050, 480, 0.3],
    step: { t0: 0.33, t1: 0.5, dist: 150 },
    anim: A(
      K(0, {}),
      K(0.12, { py: 66, px: -14, torso: 12, head: -8, tw: -70, hw: -36, sF: -56, eF: 132, wp: 20, zF: 26, wz: 16, sB: 82, eB: 28, fFx: 30, fBx: -44 }),
      K(0.3, { py: 60, px: -20, torso: 18, head: -10, tw: -84, hw: -44, sF: -62, eF: 134, wp: 20, zF: 30, wz: 20, sB: 86, eB: 22, fFx: 32, fBx: -46 }),
      K(0.34, { py: 64, px: -8, torso: 24, head: -16, tw: -30, hw: 0, sF: -30, eF: 110, wp: 12, zF: 14, wz: 8, sB: 40, eB: 30, fFx: 44, fFy: 6, fBx: -46 }),
      K(0.43, { py: 72, px: 30, torso: 36, head: -24, tw: 72, hw: 44, sF: 88, eF: 4, wp: 0, sB: -50, eB: 20, zB: 30, fFx: 76, fBx: -46, fBy: 6, fBa: -30 }),
      K(0.52, { py: 76, px: 30, torso: 28, head: -18, tw: 44, hw: 30, sF: 120, eF: 14, wp: 20, wz: 10, sB: -48, eB: 22, zB: 30, fFx: 74, fBx: -46, fBy: 4, fBa: -26 }),
      K(0.64, { py: 86, px: 22, torso: 12, head: -6, tw: -30, hw: -10, sF: 156, eF: 24, wp: 34, zF: 20, wz: 30, sB: -40, eB: 30, fFx: 64, fBx: -44 }),
      K(0.85, { py: 90, px: 14, torso: 8, head: -4, tw: -40, hw: -14, sF: 140, eF: 30, wp: 30, zF: 20, wz: 30, sB: -20, eB: 40, fFx: 52, fBx: -40 }),
      K(1.07, {}),
    ),
  }),
};

// ───────────────────────── freestyle ─────────────────────────
/**
 * The flourish a move comes out of when it is chained in a combo:
 *  twirl     – the blade rolls a full turn around the hand
 *  whirl     – the blade sweeps a full horizontal circle (helicopter)
 *  pirouette – the whole body spins once around its vertical axis
 */
const FLAIR: Partial<Record<MoveName, [Flair, number]>> = {
  slash2: ['twirl', 1], rise: ['twirl', -1], slash4: ['twirl', 1], upper: ['twirl', -1], lowslash: ['twirl', -1],
  heavy1: ['whirl', 1], heavy2: ['twirl', -1],
  kick1: ['pirouette', 1], knee: ['pirouette', 1], roundhouse: ['pirouette', 1], sweep: ['pirouette', 1], axe: ['twirl', 1],
  cross: ['pirouette', 1],
};
for (const k of Object.keys(FLAIR) as MoveName[]) {
  const f = FLAIR[k]!;
  MOVES[k].flair = f[0];
  MOVES[k].flairDir = f[1];
}

/** a stand-alone freestyle trick (F) */
export interface Trick {
  name: string;
  anim: Anim;
  flair: Flair;
  dir: number;
  turns: number;
  f0: number; // the flourish runs from f0 to f1 (animation time)
  f1: number;
  spin?: { t0: number; t1: number; turns: number }; // somersault
}

export const TRICKS: Trick[] = [
  // kincir pedang: bilah digulung dua putaran di depan badan, lalu ditodongkan ke lawan
  {
    name: 'kincir', flair: 'twirl', dir: 1, turns: 2, f0: 0.1, f1: 0.58,
    anim: A(
      K(0, {}),
      K(0.12, { py: 105, px: 0, torso: 0, head: 0, tw: -46, hw: -16, sF: 72, eF: 30, wp: 0, zF: 22, wz: 22, sB: 24, eB: 112, fFx: 20, fBx: -26 }),
      K(0.5, { py: 104, px: 2, torso: 2, head: 0, tw: -52, hw: -18, sF: 76, eF: 28, wp: 0, zF: 24, wz: 24, sB: 24, eB: 112, fFx: 20, fBx: -26 }),
      K(0.62, { py: 84, px: 12, torso: 18, head: -10, tw: 46, hw: 30, sF: 88, eF: 4, wp: 0, zF: 0, wz: 0, sB: -40, eB: 26, zB: 26, fFx: 48, fBx: -44, fBa: -20 }),
      K(0.76, { py: 84, px: 12, torso: 18, head: -10, tw: 46, hw: 30, sF: 88, eF: 4, wp: 0, zF: 0, wz: 0, sB: -40, eB: 26, zB: 26, fFx: 48, fBx: -44, fBa: -20 }),
      K(0.92, {}),
    ),
  },
  // putaran: dua pirouette di ujung kaki dengan bilah terentang (cincin cahaya), lalu turun ke kuda-kuda rendah
  {
    name: 'putaran', flair: 'pirouette', dir: 1, turns: 2, f0: 0.12, f1: 0.58,
    anim: A(
      K(0, {}),
      K(0.1, { py: 98, torso: 8, head: -4, tw: -30, hw: -10, sF: 50, eF: 40, wp: 10, sB: 60, eB: 60, fFx: 18, fBx: -20 }),
      K(0.22, { py: 106, px: 0, torso: 0, head: 0, tw: -10, hw: 0, sF: 84, eF: 6, wp: 4, zF: 0, wz: 0, sB: 84, eB: 8, zB: 180, fFx: 8, fFa: -20, fBx: -10, fBa: -20 }),
      K(0.52, { py: 106, px: 0, torso: 0, head: 0, tw: -10, hw: 0, sF: 84, eF: 6, wp: 4, zF: 0, wz: 0, sB: 84, eB: 8, zB: 180, fFx: 8, fFa: -20, fBx: -10, fBa: -20 }),
      K(0.66, { py: 68, px: -6, torso: 28, head: -14, tw: 66, hw: 32, sF: -40, eF: 12, wp: -46, zF: -30, wz: -50, sB: 62, eB: 80, fFx: 40, fBx: -42 }),
      K(0.8, { py: 68, px: -6, torso: 28, head: -14, tw: 66, hw: 32, sF: -40, eF: 12, wp: -46, zF: -30, wz: -50, sB: 62, eB: 80, fFx: 40, fBx: -42 }),
      K(0.97, {}),
    ),
  },
  // salto pedang: salto ke belakang di tempat sambil menggulung bilah
  {
    name: 'salto', flair: 'twirl', dir: -1, turns: 1, f0: 0.22, f1: 0.64,
    spin: { t0: 0.2, t1: 0.66, turns: -1 },
    anim: A(
      K(0, {}),
      K(0.12, { py: 70, torso: 28, head: -12, tw: -10, hw: 0, sF: -34, eF: 30, wp: -20, sB: -24, eB: 40, fFx: 24, fBx: -26 }),
      K(0.24, { py: 124, px: -4, torso: -12, head: 10, tw: 0, hw: 0, sF: 168, eF: 20, wp: 20, sB: 174, eB: 16, fFx: 12, fFy: 26, fFa: -44, fBx: -14, fBy: 30, fBa: -50 }),
      K(0.38, { py: 136, px: -6, torso: 36, head: 12, tw: 0, hw: 0, sF: 62, eF: 62, wp: -30, sB: 68, eB: 66, fFx: 28, fFy: 62, fFa: -20, fBx: 12, fBy: 58, fBa: -20 }),
      K(0.56, { py: 130, px: -6, torso: 34, head: 10, tw: 0, hw: 0, sF: 60, eF: 60, wp: -30, sB: 66, eB: 64, fFx: 28, fFy: 58, fFa: -20, fBx: 12, fBy: 54, fBa: -20 }),
      K(0.7, { py: 74, px: -2, torso: 24, head: -12, sF: 24, eF: 42, sB: 44, eB: 84, fFx: 30, fFy: 0, fBx: -32, fBy: 0 }),
      K(0.8, { py: 78, torso: 20, head: -10, sF: 20, eF: 40, sB: 42, eB: 88, fFx: 28, fBx: -30 }),
      K(1.0, {}),
    ),
  },
];

/** copy of an animation with some keys overridden (used for the on-the-spot version of a stepping kick) */
function still(a: Anim, ov: Record<number, Partial<Pose>>): Anim {
  return A(...a.keys.map((k, i) => ({ t: k.t, pose: { ...k.pose, ...(ov[i] ?? {}) } })));
}

MOVES.kick1.ideal = 140;
MOVES.kick1.anim0 = still(MOVES.kick1.anim, {
  1: { fFx: 30, fBx: -34, fBy: 0, fBa: 0 }, 2: { fFx: 29, fFa: 0, fBx: -35 }, 3: { fBx: -36 }, 4: { fBx: -38 }, 5: { fBx: -38 }, 6: { fBx: -37 }, 7: { fBx: -35 },
});
MOVES.sweep.ideal = 136;
MOVES.sweep.anim0 = still(MOVES.sweep.anim, {
  1: { fFx: 30, fBx: -34, fBy: 0, fBa: 0 }, 2: { fFx: 28, fFa: 0, fBx: -32 }, 3: { fBx: -31 }, 4: { fBx: -30 }, 5: { fBx: -30 }, 6: { fBx: -33 }, 7: { fBx: -34 },
});
const REAR_KICK_STILL: Record<number, Partial<Pose>> = {
  1: { fFx: 30, fFy: 0, fFa: 0, fBx: -36, fBa: -10 }, 2: { fFx: 28 }, 3: { fFx: 26 }, 4: { fFx: 24 }, 5: { fFx: 24 }, 6: { fFx: 26 }, 7: { fFx: 28, fFy: 0 },
};
MOVES.sidekick.ideal = 152;
MOVES.sidekick.anim0 = still(MOVES.sidekick.anim, REAR_KICK_STILL);
MOVES.roundhouse.ideal = 128;
MOVES.roundhouse.anim0 = still(MOVES.roundhouse.anim, REAR_KICK_STILL);

// ───────────────────────── paired throw ─────────────────────────
/** thrower after the grab connected: pull in · get under · hoist overhead · arch · hurl · follow through */
export const A_THROW_DO = A(
  K(0, { py: 82, px: 16, torso: 26, head: -16, sF: 76, eF: 14, wp: -80, sB: 84, eB: 10, fFx: 48, fBx: -40, fBa: -18 }),
  K(0.12, { py: 72, px: 20, torso: 30, head: -18, sF: 74, eF: 62, wp: -70, sB: 80, eB: 60, fFx: 50, fBx: -34 }),
  K(0.26, { py: 62, px: 16, torso: 20, head: -8, sF: 112, eF: 70, wp: -40, sB: 118, eB: 66, fFx: 46, fBx: -32 }),
  K(0.42, { py: 99, px: 4, torso: -8, head: 4, sF: 172, eF: 14, wp: 40, sB: 178, eB: 12, fFx: 34, fBx: -30 }),
  K(0.52, { py: 100, px: -5, torso: -19, head: 10, sF: 193, eF: 20, wp: 60, sB: 199, eB: 18, fFx: 28, fBx: -34 }),
  K(0.64, { py: 82, px: 22, torso: 34, head: -18, sF: 96, eF: 8, wp: 0, sB: 102, eB: 8, fFx: 62, fBx: -44, fBa: -25 }),
  K(0.76, { py: 77, px: 24, torso: 45, head: -16, sF: 50, eF: 12, wp: 10, sB: 56, eB: 14, fFx: 62, fBx: -44, fBa: -25 }),
  K(0.86, { py: 80, px: 20, torso: 36, head: -14, sF: 40, eF: 20, wp: 12, sB: 50, eB: 40, fFx: 58, fBx: -42, fBa: -16 }),
  K(1.02, {}),
);

/** limp body of the fighter being carried */
export const P_HELD = mk({ tw: 0, hw: 0, py: 90, px: 0, torso: 8, head: -14, sF: 50, eF: 40, wp: 30, sB: 76, eB: 46, fFx: 14, fFy: 14, fFa: -32, fBx: -20, fBy: 10, fBa: -38 });

const THROW_ROT: [number, number][] = [[0, 0], [0.12, 14], [0.26, -6], [0.42, -86], [0.52, -102], [0.6, -138], [0.72, -175]];
/** body rotation of the victim (in its own frame) over the throw */
export function throwRot(t: number): number {
  const k = THROW_ROT;
  if (t <= k[0][0]) return k[0][1];
  for (let i = 1; i < k.length; i++) {
    if (t < k[i][0]) {
      const u = (t - k[i - 1][0]) / (k[i][0] - k[i - 1][0]);
      return k[i - 1][1] + (k[i][1] - k[i - 1][1]) * (u * u * (3 - 2 * u));
    }
  }
  return k[k.length - 1][1];
}
