import { V, clamp } from './math';
import {
  ANB, ANF, BONE, Build, ELB, ELF, HAB, HAF, HEAD, KNB, KNF, NECK, NJ, PELVIS, TIP, TOB, TOF, WBASE,
} from './skeleton';

export const GRAVITY = 2300;

interface Stick {
  a: number;
  b: number;
  len: number;
  k: number;
  mode: 0 | 1 | 2; // 0 = rigid, 1 = minimum distance, 2 = maximum distance
}
interface Bend {
  a: number;
  b: number;
  c: number;
  sign: number;
  tol: number;
}

export interface Impact {
  speed: number;
  x: number;
  weapon: boolean;
}

/**
 * Position based dynamics ragdoll. 15 particles joined by rigid sticks,
 * soft distance limits (acting as joint limits) and one-way bend limits for knees and elbows.
 */
export class Ragdoll {
  x = new Float64Array(NJ);
  y = new Float64Array(NJ);
  ox = new Float64Array(NJ);
  oy = new Float64Array(NJ);
  vx = new Float64Array(NJ);
  vy = new Float64Array(NJ);
  w = new Float64Array(NJ);
  r = new Float64Array(NJ);
  sticks: Stick[] = [];
  bends: Bend[] = [];
  weaponFree: boolean;
  impact: Impact = { speed: 0, x: 0, weapon: false };

  constructor(j: V[], pj: V[], invDt: number, b: Build, facing: number, weaponFree: boolean) {
    const s = b.scale;
    this.weaponFree = weaponFree;
    for (let i = 0; i < NJ; i++) {
      this.x[i] = j[i].x;
      this.y[i] = j[i].y;
      this.vx[i] = clamp((j[i].x - pj[i].x) * invDt, -700, 700);
      this.vy[i] = clamp((j[i].y - pj[i].y) * invDt, -700, 700);
    }
    const W = [1, 0.45, 0.4, 1.3, 1.6, 1.3, 1.6, 1, 1.3, 2.4, 1, 1.3, 2.4, 2.2, 2];
    const R = [14, 14, 13, 6, 6, 6, 6, 8, 7, 4, 8, 7, 4, 2, 3];
    for (let i = 0; i < NJ; i++) {
      this.w[i] = W[i] / b.mass;
      this.r[i] = R[i] * s * (i === TIP || i === WBASE ? 1 : Math.min(b.thick, 1.25));
    }
    const S = (a: number, c: number, len: number, k = 1, mode: 0 | 1 | 2 = 0) =>
      this.sticks.push({ a, b: c, len: len * s, k, mode });
    const { thigh, shin, foot, torso, neck, upper, fore } = BONE;
    S(HEAD, NECK, neck);
    S(NECK, PELVIS, torso);
    S(NECK, ELF, upper);
    S(ELF, HAF, fore);
    S(NECK, ELB, upper);
    S(ELB, HAB, fore);
    S(PELVIS, KNF, thigh);
    S(KNF, ANF, shin);
    S(ANF, TOF, foot);
    S(PELVIS, KNB, thigh);
    S(KNB, ANB, shin);
    S(ANB, TOB, foot);
    // keep the feet roughly perpendicular to the shins
    const ft = Math.hypot(shin, foot);
    S(KNF, TOF, ft, 0.25);
    S(KNB, TOB, ft, 0.25);
    // joint limits expressed as distance limits
    S(HEAD, PELVIS, torso + neck * 0.45, 0.8, 1); // neck
    S(HAF, NECK, 20, 0.6, 1); // elbow cannot fold flat
    S(HAB, NECK, 20, 0.6, 1);
    S(ANF, PELVIS, 42, 0.6, 1); // knee cannot fold flat
    S(ANB, PELVIS, 42, 0.6, 1);
    S(KNF, NECK, 34, 0.6, 1); // hip cannot fold flat
    S(KNB, NECK, 34, 0.6, 1);
    S(KNF, KNB, thigh * 1.45, 0.5, 2); // limited splits
    S(HEAD, ELF, 20, 0.4, 1);
    S(HEAD, ELB, 20, 0.4, 1);
    // weapon
    S(WBASE, TIP, b.wLen);
    if (!weaponFree) {
      S(HAF, WBASE, 0);
      S(ELF, TIP, (fore + b.wLen) * 0.8, 0.5, 1);
    }
    const B = (a: number, c: number, d: number, sign: number, tol: number) =>
      this.bends.push({ a, b: c, c: d, sign: sign * facing, tol });
    B(PELVIS, KNF, ANF, 1, 0.05);
    B(PELVIS, KNB, ANB, 1, 0.05);
    B(NECK, ELF, HAF, -1, 0.05);
    B(NECK, ELB, HAB, -1, 0.05);
    B(NECK, PELVIS, KNF, -1, 0.62); // hips: little backwards extension
    B(NECK, PELVIS, KNB, -1, 0.62);
  }

  /** ix/iy world-space velocity change. focus = share of the energy concentrated around (hx,hy). */
  impulse(ix: number, iy: number, hx: number, hy: number, focus: number, scale: number) {
    const cx = this.x[PELVIS], cy = (this.y[PELVIS] + this.y[NECK]) / 2;
    const spin = (Math.random() - 0.5) * 2.2;
    for (let i = 0; i < NJ; i++) {
      const d = Math.hypot(this.x[i] - hx, this.y[i] - hy);
      const wgt = Math.exp(-d / (75 * scale));
      const m = 1 - focus + focus * 2.6 * wgt;
      this.vx[i] += ix * m - (this.y[i] - cy) * spin;
      this.vy[i] += iy * m + (this.x[i] - cx) * spin;
    }
    if (this.weaponFree) {
      // the weapon flies off spinning
      const dx = this.x[TIP] - this.x[WBASE], dy = this.y[TIP] - this.y[WBASE];
      const sp = (Math.random() < 0.5 ? -1 : 1) * (5 + Math.random() * 5);
      this.vx[TIP] += -dy * sp + ix * 0.3;
      this.vy[TIP] += dx * sp - 260;
      this.vx[WBASE] += ix * 0.3;
      this.vy[WBASE] += -260;
    }
  }

  /** juggle: most of the fall is cancelled, then the body is launched again */
  pop(ix: number, iy: number) {
    const spin = (Math.random() - 0.5) * 3;
    const cx = this.x[PELVIS], cy = (this.y[PELVIS] + this.y[NECK]) / 2;
    for (let i = 0; i < NJ; i++) {
      this.vx[i] = this.vx[i] * 0.25 + ix - (this.y[i] - cy) * spin;
      this.vy[i] = Math.min(this.vy[i], 0) * 0.25 + iy + (this.x[i] - cx) * spin;
    }
  }

  private solveSticks() {
    const { x, y, w } = this;
    for (let n = 0; n < this.sticks.length; n++) {
      const st = this.sticks[n];
      const a = st.a, b = st.b;
      let dx = x[b] - x[a], dy = y[b] - y[a];
      let d = Math.hypot(dx, dy);
      if (st.mode === 1 && d >= st.len) continue;
      if (st.mode === 2 && d <= st.len) continue;
      if (d < 1e-4) { dx = 0; dy = 1; d = 1e-4; }
      const ws = w[a] + w[b];
      const diff = ((d - st.len) / d) * st.k;
      const ma = w[a] / ws, mb = w[b] / ws;
      x[a] += dx * diff * ma; y[a] += dy * diff * ma;
      x[b] -= dx * diff * mb; y[b] -= dy * diff * mb;
    }
  }

  private solveBends() {
    const { x, y } = this;
    for (let n = 0; n < this.bends.length; n++) {
      const bd = this.bends[n];
      const ux = x[bd.b] - x[bd.a], uy = y[bd.b] - y[bd.a];
      const vx = x[bd.c] - x[bd.b], vy = y[bd.c] - y[bd.b];
      const ul = Math.hypot(ux, uy), vl = Math.hypot(vx, vy);
      if (ul < 1e-3 || vl < 1e-3) continue;
      const sn = ((ux * vy - uy * vx) / (ul * vl)) * bd.sign;
      if (sn < -bd.tol) {
        // pull the end point towards the straight configuration
        const tx = x[bd.b] + (ux / ul) * vl, ty = y[bd.b] + (uy / ul) * vl;
        // momentum conserving correction shared between the joint and the end point
        const k = bd.tol > 0.3 ? 0.14 : 0.35;
        const wb = this.w[bd.b], wc = this.w[bd.c], ws = wb + wc;
        const cx = (tx - x[bd.c]) * k, cy = (ty - y[bd.c]) * k;
        x[bd.c] += cx * (wc / ws); y[bd.c] += cy * (wc / ws);
        x[bd.b] -= cx * (wb / ws); y[bd.b] -= cy * (wb / ws);
      }
    }
  }

  step(dt: number, ground: number, minX: number, maxX: number): Impact {
    const imp = this.impact;
    imp.speed = 0;
    if (dt <= 0) return imp;
    const n = Math.max(1, Math.ceil(dt / (1 / 150)));
    const h = dt / n;
    const { x, y, ox, oy, vx, vy, r } = this;
    for (let sub = 0; sub < n; sub++) {
      const drag = 1 - 0.25 * h;
      for (let i = 0; i < NJ; i++) {
        vy[i] += GRAVITY * h;
        vx[i] *= drag; vy[i] *= drag;
        ox[i] = x[i]; oy[i] = y[i];
        x[i] += vx[i] * h; y[i] += vy[i] * h;
      }
      for (let it = 0; it < 6; it++) {
        this.solveSticks();
        this.solveBends();
        for (let i = 0; i < NJ; i++) {
          const g = ground - r[i];
          if (y[i] > g) y[i] = g;
          if (x[i] < minX) x[i] = minX;
          else if (x[i] > maxX) x[i] = maxX;
        }
      }
      for (let i = 0; i < NJ; i++) {
        const pvy = vy[i];
        vx[i] = (x[i] - ox[i]) / h;
        vy[i] = (y[i] - oy[i]) / h;
        if (y[i] >= ground - r[i] - 0.01) {
          // contact: friction + a little bounce
          if (pvy > 160) {
            if (pvy > imp.speed) { imp.speed = pvy; imp.x = x[i]; imp.weapon = i === TIP || i === WBASE; }
            vy[i] = Math.min(vy[i], -pvy * 0.28);
          }
          vx[i] *= Math.max(0, 1 - 9 * h);
        }
      }
    }
    return imp;
  }

  /** mean squared speed of the body particles */
  energy(): number {
    let e = 0;
    for (let i = 0; i < TIP; i++) e += this.vx[i] * this.vx[i] + this.vy[i] * this.vy[i];
    return e / TIP;
  }

  write(out: V[]) {
    for (let i = 0; i < NJ; i++) {
      out[i].x = this.x[i];
      out[i].y = this.y[i];
    }
  }
}

/** Verlet-ish rope used for ribbons, pony tails and capes. */
export class Chain {
  x: Float64Array;
  y: Float64Array;
  vx: Float64Array;
  vy: Float64Array;
  n: number;
  constructor(n: number, public seg: number, public w0: number, public w1: number, public grav = 900, public dragK = 3.2) {
    this.n = n;
    this.x = new Float64Array(n);
    this.y = new Float64Array(n);
    this.vx = new Float64Array(n);
    this.vy = new Float64Array(n);
  }
  reset(ax: number, ay: number) {
    for (let i = 0; i < this.n; i++) {
      this.x[i] = ax;
      this.y[i] = Math.min(-1, ay + i * this.seg);
      this.vx[i] = this.vy[i] = 0;
    }
  }
  update(ax: number, ay: number, dt: number, wind: number) {
    if (dt <= 1e-5) return;
    const { x, y, vx, vy, n, seg } = this;
    const drag = Math.exp(-this.dragK * dt);
    const px = x.slice(), py = y.slice();
    x[0] = ax; y[0] = ay;
    for (let i = 1; i < n; i++) {
      vy[i] += this.grav * dt;
      vx[i] += wind * dt;
      vx[i] *= drag; vy[i] *= drag;
      x[i] += vx[i] * dt; y[i] += vy[i] * dt;
    }
    for (let it = 0; it < 3; it++) {
      for (let i = 1; i < n; i++) {
        let dx = x[i] - x[i - 1], dy = y[i] - y[i - 1];
        let d = Math.hypot(dx, dy);
        if (d < 1e-4) { dx = 0; dy = 1; d = 1; }
        const k = (d - seg) / d;
        if (i === 1) { x[i] -= dx * k; y[i] -= dy * k; }
        else {
          x[i] -= dx * k * 0.5; y[i] -= dy * k * 0.5;
          x[i - 1] += dx * k * 0.5; y[i - 1] += dy * k * 0.5;
        }
        if (y[i] > -1.5) y[i] = -1.5;
      }
    }
    for (let i = 1; i < n; i++) {
      vx[i] = clamp((x[i] - px[i]) / dt, -2500, 2500);
      vy[i] = clamp((y[i] - py[i]) / dt, -2500, 2500);
    }
  }
}
