import { MOVES, MoveName } from './anims';
import { CONFIG } from './config';
import { Fighter } from './fighter';

export interface AILevel {
  react: number; // seconds before reacting to an incoming attack
  aggr: number; // 0.4 .. 1.5
  block: number; // block probability
  combo: number; // probability to continue a combo
  dmg: number; // damage multiplier
  heavy: number; // how much the AI likes heavy / knock-down moves
  throws: number; // chance per second to throw a guarding opponent
}

export const LEVELS: Record<string, AILevel> = {
  easy: { react: 0.22, aggr: 0.42, block: 0.2, combo: 0.25, dmg: 0.7, heavy: 0.4, throws: 0.5 },
  normal: { react: 0.13, aggr: 0.9, block: 0.5, combo: 0.6, dmg: 0.95, heavy: 0.85, throws: 1.4 },
  hard: { react: 0.07, aggr: 1.45, block: 0.78, combo: 0.85, dmg: 1.15, heavy: 1.25, throws: 3 },
};

interface Opt {
  m: MoveName;
  w: number;
  u?: boolean;
  d?: boolean;
  f?: boolean;
  kick?: boolean;
  heavy?: boolean;
}

const OPTS: Opt[] = [
  { m: 'slash1', w: 5 },
  { m: 'lowslash', w: 1.6, d: true },
  { m: 'upper', w: 1.3, u: true },
  { m: 'thrust', w: 1.5, f: true },
  { m: 'kick1', w: 2.2, kick: true },
  { m: 'sidekick', w: 1.4, f: true, kick: true },
  { m: 'sweep', w: 1.2, d: true, kick: true },
  { m: 'roundhouse', w: 1.0, u: true, kick: true },
  { m: 'heavy1', w: 1.2, heavy: true },
  { m: 'heavy2', w: 0.6, u: true, heavy: true },
];

export class AI {
  private cd = 0.6;
  private retreat = false;
  private threatT = 0;
  private decided = false;
  private willBlock = false;
  private rolled = false;
  private comboLeft = 0;
  private taunted = false;
  private commit = false; // keeps swinging even when the strike was blocked or missed
  private jumpCd = 2;
  private blockHold = 0;

  constructor(public lvl: AILevel) {}

  think(me: Fighter, opp: Fighter, dt: number) {
    const inp = me.input;
    inp.l = inp.r = inp.u = inp.d = inp.block = inp.run = false;
    this.cd -= dt;
    this.jumpCd -= dt;
    this.blockHold -= dt;
    const dir = opp.x >= me.x ? 1 : -1;
    const hold = (fwd: boolean) => {
      if ((dir > 0) === fwd) inp.r = true;
      else inp.l = true;
    };
    const dist = Math.abs(opp.x - me.x);
    const sc = me.build.scale;
    const reach = (r: number) => r * sc * me.build.reach * 0.92;
    const runs = this.lvl.aggr > 0.6; // cautious fighters only walk
    const canAct = me.state === 'stand' || me.state === 'block' || me.state === 'blockhit';

    // defend: hold the guard while an attack is coming
    if (me.threatFrom(opp) && canAct) {
      this.threatT += dt;
      if (!this.decided) {
        this.decided = true;
        this.willBlock = Math.random() < this.lvl.block;
      }
      if (this.willBlock && this.threatT >= this.lvl.react) {
        // a throw cannot be blocked – skilled fighters roll away from it (and from heavy blows)
        const om = opp.move;
        if (om && (om.part === 'grab' || om.heavy) && !this.rolled && Math.random() < this.lvl.block * 0.6) {
          if (Math.random() < 0.5) inp.roll = 0.1;
          else { inp.flip = 0.1; inp.flipDir = -dir; }
          hold(false);
        } else {
          inp.block = true;
          this.blockHold = 0.18;
        }
        this.rolled = true;
        return;
      }
    } else {
      this.threatT = 0;
      this.decided = false;
      this.rolled = false;
      if (this.blockHold > 0 && canAct) {
        inp.block = true;
        return;
      }
    }

    if (me.state === 'attack') {
      const m = me.move!;
      // carry on with the string: one press per move, and mostly only when the last strike landed
      if (this.comboLeft > 0 && m.next && !me.queued && me.phase >= 1 && (me.connected || this.commit)) {
        const r = Math.random();
        if (m.next.heavy && r < 0.2 * this.lvl.heavy) inp.heavy = 0.1;
        else if (m.next.punch && (r < 0.68 || !m.next.kick)) inp.punch = 0.1;
        else if (m.next.kick) inp.kick = 0.1;
        else inp.heavy = 0.1;
        this.comboLeft--;
      }
      return;
    }
    if (me.state !== 'stand') return;

    if (opp.down || opp.dead) {
      // show off while the opponent is on the floor
      if (!this.taunted) {
        this.taunted = true;
        if (!opp.dead && dist > 140 * sc && Math.random() < this.lvl.aggr * 0.45) inp.style = 0.12;
      }
      if (dist < 210 * sc) hold(false);
      else if (dist > 330 * sc) hold(true);
      return;
    }

    this.taunted = false;

    // SUPER STRIKE as soon as the shadow energy is full and the target is in range
    if (me.energy >= CONFIG.energy.max && dist < reach(MOVES.super.range) && this.cd < 0.4) {
      inp.super = 0.1;
      this.cd = 1.4;
      return;
    }

    // a guarding opponent gets thrown
    if (opp.state === 'block' && dist < reach(MOVES.throw.range) + 40 * sc && Math.random() < this.lvl.throws * dt) {
      inp.throw = 0.1;
      this.cd = 1.1 / this.lvl.aggr;
      return;
    }

    if (this.cd > 0) {
      if (this.retreat && dist < 300 * sc) hold(false);
      else if (dist > 340 * sc) {
        hold(true);
        if (runs && dist > 400 * sc) inp.run = true;
      }
      return;
    }

    const far = reach(MOVES.kick1.range);
    if (dist > far) {
      hold(true);
      if (runs && dist > far + 30 * sc) inp.run = true; // sprint in from long range
      if (this.jumpCd <= 0 && dist < 520 && Math.random() < 0.5 * dt * this.lvl.aggr) {
        this.jumpCd = 3 + Math.random() * 3;
        if (Math.random() < 0.5) inp.flip = 0.1;
        else inp.u = true;
        setTimeout(() => {
          if (me.state === 'air') {
            if (Math.random() < 0.5) me.input.kick = 0.15;
            else me.input.punch = 0.15;
          }
        }, 330);
      }
      return;
    }

    // choose a move that reaches
    let total = 0;
    const cands: Opt[] = [];
    for (const o of OPTS) {
      const mv = MOVES[o.m];
      if (reach(mv.range) < dist) continue;
      let w = o.w;
      if (mv.heavy || mv.knock) w *= this.lvl.heavy;
      if (dist < 130 * sc && o.kick) w *= 1.6;
      cands.push({ ...o, w });
      total += w;
    }
    if (!cands.length) {
      hold(true);
      return;
    }
    // close in a little more instead of always poking from the very edge of the range
    if (dist > reach(MOVES.slash1.range) && Math.random() > 5 * dt * this.lvl.aggr) {
      hold(true);
      return;
    }
    // occasional throw attempt at close range
    if (dist < reach(MOVES.throw.range) && Math.random() < 0.12 * this.lvl.heavy) {
      inp.throw = 0.1;
      this.cd = 1.2 / this.lvl.aggr;
      return;
    }
    let r = Math.random() * total;
    let pick = cands[0];
    for (const c of cands) {
      r -= c.w;
      if (r <= 0) { pick = c; break; }
    }
    if (pick.u) inp.u = true;
    if (pick.d) inp.d = true;
    if (pick.f) hold(true);
    if (pick.heavy) inp.heavy = 0.1;
    else if (pick.kick) inp.kick = 0.1;
    else inp.punch = 0.1;
    this.comboLeft = 0;
    if (pick.m === 'slash1' || pick.m === 'kick1' || pick.m === 'heavy1') {
      if (Math.random() < this.lvl.combo) {
        this.comboLeft = 1 + (Math.random() < this.lvl.combo ? 1 : 0) + (Math.random() < this.lvl.combo * 0.6 ? 1 : 0);
      }
      this.commit = Math.random() < 0.35;
    }
    const mv = MOVES[pick.m];
    this.cd = (mv.startup + mv.active + mv.recovery) / me.build.speed + (0.15 + Math.random() * 0.75) / this.lvl.aggr;
    this.retreat = Math.random() < 0.3;
  }
}
