import {
  A_BACKFLIP, Flair, TRICKS, Trick, A_BLOCKHIT, A_FRONTFLIP, A_GETUP, A_GETUP_PRONE, A_HIT_LOW, A_REEL, A_SKID, A_THROW_DO, Anim, HITS_HIGH, HITS_MID, MOVES, Move, MoveName,
  P_AIR_MID, P_AIR_UP, P_BLOCK, P_BLOCK_LOW, P_CROUCH, P_BRAKE, P_HELD, P_LAND, P_LIE, P_PRONE, P_ROLL, P_ROLL_IN, P_SQUAT,
  P_VICTORY, RUN_SYNC, idlePose, runPose, sample, walkPose,
} from './anims';
import { CONFIG } from './config';
import { DEG, V, clamp, damp, lerp, smooth } from './math';
import { Chain, GRAVITY, Ragdoll } from './ragdoll';
import {
  Build, HEAD, NECK, NJ, PELVIS, POSE_KEYS, Pose, TIP, TOB, TOF, WBASE, copyPose, mixPose, mk, newJoints, solve,
  zeroPose, BONE, newExtra, wrapYaw, Extra, HAB, HAF, copyExtra,
} from './skeleton';

export type State =
  | 'stand' | 'squat' | 'air' | 'land' | 'attack' | 'block' | 'blockhit' | 'roll'
  | 'hit' | 'stagger' | 'ragdoll' | 'getup' | 'victory' | 'throwing' | 'grabbed' | 'style';

export interface Input {
  l: boolean;
  r: boolean;
  u: boolean;
  d: boolean;
  block: boolean; // held
  run: boolean; // held: sprint (AI) – human players run automatically
  flipDir: number; // world direction of a requested flip (-1 left, +1 right, 0 = direction held)
  // buffered presses (seconds left)
  punch: number;
  kick: number;
  heavy: number; // H – heavy attack
  style: number; // F – freestyle trick
  throw: number;
  roll: number;
  flip: number;
  super: number;
}
export const newInput = (): Input => ({
  l: false, r: false, u: false, d: false, block: false, run: false, flipDir: 0, punch: 0, kick: 0, heavy: 0, style: 0, throw: 0, roll: 0, flip: 0, super: 0,
});
export function decayInput(i: Input, dt: number) {
  i.punch = Math.max(0, i.punch - dt);
  i.kick = Math.max(0, i.kick - dt);
  i.heavy = Math.max(0, i.heavy - dt);
  i.style = Math.max(0, i.style - dt);
  i.throw = Math.max(0, i.throw - dt);
  i.roll = Math.max(0, i.roll - dt);
  i.flip = Math.max(0, i.flip - dt);
  i.super = Math.max(0, i.super - dt);
}
export function clearInput(i: Input) {
  i.l = i.r = i.u = i.d = i.block = i.run = false;
  i.flipDir = 0;
  i.punch = i.kick = i.heavy = i.style = i.throw = i.roll = i.flip = i.super = 0;
}

export interface Hooks {
  sfx(name: string, vol?: number): void;
  dust(x: number, amount: number): void;
  shake(a: number): void;
  superFx(f: Fighter): void;
  styleFx(f: Fighter): void;
  arena: number;
  time: number;
}

export interface TrailPt {
  bx: number;
  by: number;
  tx: number;
  ty: number;
  age: number;
  brk: boolean;
  sup: boolean;
}
export interface KickPt {
  x: number;
  y: number;
  age: number;
  brk: boolean;
}

export const TRAIL_LIFE = 0.17;
export const KICK_LIFE = 0.13;
/** afterimage of the body, left behind while a strike moves really fast */
export interface Ghost {
  j: V[];
  ex: Extra;
  age: number;
}
export const GHOST_LIFE = 0.15;
/** one freestyle flourish: every channel runs from its current value to a whole number of turns */
interface Flourish {
  t: number; dur: number;
  wp0: number; wp1: number; wz0: number; wz1: number; yaw0: number; yaw1: number; head0: number;
  tuck: number; lift: number;
  fold: number; // extra blade angle at the middle of the flourish
}
const settle = (v: number, k: number) => {
  const goal = Math.round(v / 360) * 360;
  const r = goal + (v - goal) * k;
  return Math.abs(r - goal) < 0.5 ? 0 : r;
};
const GHOST_EVERY = 0.032;
const GHOST_SPEED = 620; // px/s of the fastest hand / foot
const M = CONFIG.movement;

/**
 * Second-order follow per pose channel (order = POSE_KEYS).
 * Heavy parts and the off arm / head follow with a little lag and overshoot – overlapping action.
 */
//                px  py  torso head sF  eF  sB   eB   fFx fFy fFa fBx fBy fBa wp   tw hw hy zF zB wz lF lB
const SPR_HZ = [9, 9.5, 8.5, 6.2, 14, 14, 6.8, 6.8, 18, 18, 11, 18, 18, 11, 10.5, 10, 11, 12, 13, 7.5, 12, 16, 16];
const SPR_Z = [0.9, 0.78, 0.72, 0.58, 0.85, 0.8, 0.52, 0.55, 1, 1, 0.9, 1, 1, 0.9, 0.62, 0.8, 0.85, 0.9, 0.85, 0.6, 0.8, 0.95, 0.95];
const SPR_W = SPR_HZ.map((f) => f * Math.PI * 2);

export class Fighter {
  x = 0;
  elev = 0;
  vx = 0;
  vy = 0;
  kb = 0;
  mv = 0; // smoothed walking velocity (forward positive)
  facing = 1;
  rot = 0;
  rotGoal = 0;
  hp: number;
  dead = false;
  state: State = 'stand';
  stateT = 0;
  sub: 'idle' | 'walk' | 'crouch' = 'idle';
  invuln = 0;
  powerMul = 1;
  human = false;
  hitShake = 0;

  // core mechanics
  armed = true; // false after a SHOCK: fights bare handed until the round ends
  energy = 0; // shadow energy 0..max
  combo = 0;
  maxCombo = 0;
  connected = false; // current attack landed unblocked
  /** combo string: the move waiting for the cancel window, and how many moves the string has so far */
  queued: MoveName | null = null;
  chainN = 0;
  /** hits taken while airborne since the last knock-down */
  juggled = 0;
  /** unblocked hits taken since this fighter was last free to act (damage scaling) */
  hitsTaken = 0;
  ghosts: Ghost[] = Array.from({ length: 5 }, () => ({ j: newJoints(), ex: newExtra(), age: 9 }));
  private ghostT = 0;

  /** 0 = weapon in hand, 1 = slung on the back (while grappling) */
  sheath = 0;
  oppDist = 300;
  private stepK = 1; // share of a stepping attack's travel that is really needed to reach the opponent

  // paired throw
  throwRelease = false; // set for one frame when the thrower lets go
  private released = false;
  private heldX0 = 0;
  private heldE0 = 0;

  // movement cooldowns (seconds left)
  cdJump = 0;
  cdRoll = 0;
  cdFlip = 0;
  cdCrouch = 0;
  cdRun = 0;
  cdStyle = 0;
  /** FREESTYLE layer: showy rotations added on top of the animated pose – after the springs, so they are exact */
  sty = { wp: 0, wz: 0, yaw: 0, head: 0, tuck: 0, lift: 0 };
  flo: Flourish | null = null;
  trick: Trick | null = null;
  private trickN = 0;
  private styPaid = false;
  private styCue = false;
  private enderDone = false;
  private lastFlair: Flair | null = null;
  running = false;
  private fwdHold = 0;
  private skid = false;
  private jumpVx = 0;
  private crouchT = 0;
  private stride = M.forward.speed * M.forward.duration;

  pose: Pose = mk();
  vel: Pose = zeroPose();
  target: Pose = mk();
  private tmp: Pose = mk();
  private tmp2: Pose = mk();

  j: V[] = newJoints();
  pj: V[] = newJoints();
  /** shoulder / hip joints, depth and body yaw for the renderer */
  ex = newExtra();
  lastDt = 1 / 60;
  private snap: V[] | null = null;
  private snapT = 0;
  private snapDur = 0.2;

  rag: Ragdoll | null = null;
  private ragStill = 0;
  private impactCd = 0;

  move: Move | null = null;
  anim: Anim | null = null;
  animT = 0;
  moveT = 0; // real time spent in the current attack
  /** 0 = startup, 1 = active, 2 = recovery */
  phase: 0 | 1 | 2 = 0;
  hitActive = false;
  hitDone = false;
  private whooshed = false;
  private fresh = false;
  private freshBtn = 0;

  walkPhase = 0;
  private jumpDir = 0;
  private flip = 0;
  private airT = 0;
  private airDur = 0.7;
  private rollDir = 1;
  private hitVar = 0;
  private skidT = 0;

  private liftF = 0;
  private liftB = 0;
  private volV = 0;

  fl = 0;
  flv = 0;

  chains: Chain[] = [];
  trail: TrailPt[] = [];
  trailOn = false;
  private trailWas = false;
  ktrail: KickPt[] = [];
  kickOn = false;
  private kickWas = false;

  input: Input = newInput();

  constructor(public build: Build, public idx: number) {
    this.hp = build.hp;
    const s = build.scale;
    if (build.kind === 'shadow') {
      this.chains = [
        new Chain(5, 7 * s, 14, 3, 950, 7.5), // pony tail
        new Chain(6, 9 * s, 13, 4.5, 1000, 4), // scarf
      ];
    } else {
      this.chains = [
        new Chain(8, 15 * s, 30, 10, 900, 3.4), // cape
        new Chain(8, 14 * s, 26, 8, 980, 2.8),
        new Chain(7, 14 * s, 22, 6, 860, 3.9),
      ];
    }
  }

  private setPoseNow(p: Pose) {
    copyPose(this.pose, p);
    copyPose(this.target, p);
    for (let i = 0; i < POSE_KEYS.length; i++) this.vel[POSE_KEYS[i]] = 0;
  }

  /** new round: full HP, weapon back in hand. Shadow energy is kept between rounds. */
  reset(x: number, facing: number, keepEnergy = false) {
    this.x = x; this.facing = facing; this.elev = 0; this.vx = this.vy = this.kb = this.mv = 0;
    this.rot = 0; this.hp = this.build.hp; this.dead = false;
    this.state = 'stand'; this.stateT = 0; this.sub = 'idle'; this.invuln = 0;
    this.rag = null; this.anim = null; this.hitDone = false;
    this.armed = true; this.combo = 0; this.maxCombo = 0; this.connected = false; this.throwRelease = false;
    this.queued = null; this.chainN = 0; this.juggled = 0; this.hitsTaken = 0;
    for (const gh of this.ghosts) gh.age = 9;
    if (!keepEnergy) this.energy = 0;
    this.cdJump = this.cdRoll = this.cdFlip = this.cdCrouch = this.cdRun = this.cdStyle = 0;
    this.clearStyle(); this.trick = null;
    this.running = false; this.fwdHold = 0; this.skid = false;
    this.stopFx();
    this.snap = null; this.fl = this.flv = 0; this.trail.length = 0; this.ktrail.length = 0;
    this.liftF = this.liftB = this.volV = 0; this.hitShake = 0; this.sheath = 0;
    idlePose(this.tmp2, 0);
    this.setPoseNow(this.tmp2);
    this.solveNow();
    for (let i = 0; i < NJ; i++) { this.pj[i].x = this.j[i].x; this.pj[i].y = this.j[i].y; }
    const a = this.anchors();
    this.chains.forEach((c, i) => c.reset(a[i][0], a[i][1]));
  }

  get grounded() {
    return this.state !== 'air' && this.state !== 'ragdoll';
  }
  get down() {
    return this.state === 'ragdoll' || this.state === 'getup' || this.state === 'grabbed';
  }

  addEnergy(v: number) {
    this.energy = clamp(this.energy + v, 0, CONFIG.energy.max);
  }

  disarm() {
    this.armed = false;
    this.trailOn = false;
    this.trail.length = 0;
  }

  // ───────────── freestyle ─────────────
  private clearStyle() {
    const s = this.sty;
    s.wp = s.wz = s.yaw = s.head = s.tuck = s.lift = 0;
    this.flo = null;
  }

  /** start a flourish; it carries on from wherever the previous one was, so flourishes flow into each other */
  flourish(kind: Flair | 'settle', dir: number, dur: number, turns = 1, fold?: number) {
    const s = this.sty;
    const near = (v: number) => v - Math.round(v / 360) * 360;
    s.wp = near(s.wp); s.wz = near(s.wz); s.yaw = near(s.yaw); s.head = near(s.head);
    const f: Flourish = {
      t: 0, dur: Math.max(0.05, dur), wp0: s.wp, wp1: 0, wz0: s.wz, wz1: 0, yaw0: s.yaw, yaw1: 0, head0: s.head, tuck: 0, lift: 0, fold: 0,
    };
    if (kind === 'twirl') {
      f.wp1 = dir * 360 * turns; f.tuck = 38;
    } else if (kind === 'whirl') {
      // helicopter: the blade is laid flat so the circle is wide and passes above the heads
      f.wz1 = dir * 360 * turns; f.fold = fold ?? 36;
    } else if (kind === 'pirouette') {
      // the blade flips into a reverse grip along the forearm while the body spins, so it stays close to the body
      f.yaw1 = -dir * 360 * turns; f.lift = 5; f.fold = fold ?? -170;
    }
    this.flo = f;
    if (kind !== 'settle') this.styCue = true;
  }

  /** the flourish a chained move comes out of – chosen to fit the transition */
  private flairInto(m: Move, prev: Move | null) {
    let k: Flair | null = m.flair ?? null;
    // no second spin right after a spinning move: the blade rolls instead
    if (k === 'pirouette' && ((prev !== null && prev.ownSpin) || this.lastFlair === 'pirouette')) k = 'twirl';
    if (k !== null && k !== 'pirouette' && !this.armed) k = null;
    this.lastFlair = k;
    if (k === null) {
      // nothing showy for this move: bring a flourish that is still running to rest before the strike
      const st = this.sty;
      if (st.wp !== 0 || st.wz !== 0 || st.yaw !== 0 || st.head !== 0) this.flourish('settle', 1, m.startup * 0.8);
      else this.flo = null;
      return;
    }
    this.flourish(k, m.flairDir ?? 1, m.startup * CONFIG.freestyle.transition);
  }

  private startTrick() {
    this.stopFx();
    this.trick = TRICKS[this.trickN++ % TRICKS.length];
    this.state = 'style'; this.stateT = 0; this.animT = 0;
    this.styPaid = false;
    this.cdStyle = CONFIG.freestyle.cooldown;
  }

  private stepStyle(dt: number, g: Hooks) {
    const s = this.sty, f = this.flo;
    if (this.styCue) {
      this.styCue = false;
      g.sfx('twirl', 0.55);
    }
    if (f) {
      f.t += dt * this.build.speed;
      const u = clamp(f.t / f.dur, 0, 1), e = u * u * (3 - 2 * u);
      const b = Math.sin(Math.PI * u);
      s.wp = lerp(f.wp0, f.wp1, e) + f.fold * b; s.wz = lerp(f.wz0, f.wz1, e); s.yaw = lerp(f.yaw0, f.yaw1, e);
      s.head = lerp(f.head0, f.yaw1, smooth(u * 1.4)); // the head whips round ahead of the body
      s.tuck = f.tuck * b; s.lift = f.lift * b;
      if (u >= 1) this.clearStyle();
    } else if (s.wp !== 0 || s.wz !== 0 || s.yaw !== 0 || s.head !== 0 || s.tuck !== 0 || s.lift !== 0) {
      // interrupted: unwind to the nearest full turn instead of snapping
      const k = Math.exp(-16 * dt);
      s.wp = settle(s.wp, k); s.wz = settle(s.wz, k); s.yaw = settle(s.yaw, k); s.head = settle(s.head, k);
      s.tuck = Math.abs(s.tuck) < 0.3 ? 0 : s.tuck * k;
      s.lift = Math.abs(s.lift) < 0.3 ? 0 : s.lift * k;
    }
  }

  /** off the ground: jumping, flipping or in the middle of a somersault attack – a hit knocks the fighter down */
  get aloft() {
    return this.state === 'air' || ((this.state === 'style' || (this.state === 'attack' && !!this.move?.spin)) && this.rot !== 0);
  }

  private stopFx() {
    this.queued = null;
    if (this.move?.spin) this.rot = 0;
    if (this.trick) {
      if (this.trick.spin) this.rot = 0;
      this.trick = null;
    }
    this.flo = null; // a running flourish unwinds by itself
    this.move = null; this.hitActive = false; this.trailOn = false; this.kickOn = false;
  }

  /** an attack that reached its active phase without landing counts as a miss -> combo resets */
  private endMove() {
    if (this.move && !this.connected && this.phase >= 1) this.combo = 0;
  }

  toStand() {
    this.hitsTaken = 0;
    this.state = 'stand'; this.stateT = 0; this.sub = 'idle';
    this.stopFx();
  }

  /** the grab connected: play the hoist-and-hurl sequence */
  beginThrow() {
    this.state = 'throwing'; this.stateT = 0; this.animT = 0;
    this.released = false; this.throwRelease = false;
    this.stopFx();
  }

  beGrabbed() {
    this.state = 'grabbed'; this.stateT = 0;
    this.heldX0 = this.x; this.heldE0 = this.elev;
    this.clearStyle();
    this.kb = 0; this.vx = this.vy = this.mv = 0;
    this.snap = null;
    this.stopFx();
  }

  /**
   * Carried by the thrower: the body hangs from the grip point (ax, ay = between the thrower's hands)
   * and turns with the throw. k blends from the standing position into the grip.
   */
  heldUpdate(dt: number, ax: number, ay: number, rot: number, k: number, g: Hooks) {
    if (dt <= 0) return;
    this.lastDt = dt;
    for (let i = 0; i < NJ; i++) { this.pj[i].x = this.j[i].x; this.pj[i].y = this.j[i].y; }
    this.stateT += dt;
    copyPose(this.target, P_HELD);
    const w = this.stateT * 12;
    const t = this.target;
    t.fFx += Math.sin(w) * 13; t.fBx += Math.sin(w + 2.1) * 13;
    t.fFy += Math.cos(w) * 6; t.fBy += Math.cos(w + 2.1) * 6;
    t.sB += Math.sin(w * 0.8) * 16; t.eF += Math.cos(w * 0.9) * 14; t.torso += Math.sin(w * 0.6) * 5;
    this.follow(dt);
    const te = Math.max(0, -ay - (this.pose.py + 14) * this.build.scale);
    this.x = lerp(this.heldX0, ax, k);
    this.elev = lerp(this.heldE0, te, k);
    this.rot = rot;
    this.flv += (-230 * this.fl - 15 * this.flv) * dt;
    this.fl = clamp(this.fl + this.flv * dt, -40, 40);
    this.liftF = this.liftB = 0;
    this.solveNow();
    this.post(dt, g);
  }

  private snapFrom(dur: number) {
    this.snap = this.j.map((p) => ({ x: p.x - this.x, y: p.y + this.elev }));
    this.snapT = 0;
    this.snapDur = dur;
  }

  private autoFace(opp: Fighter) {
    const want = opp.x >= this.x ? 1 : -1;
    if (want !== this.facing) {
      this.snapFrom(0.2);
      this.facing = want;
      this.mv = -this.mv;
    }
  }

  threatFrom(opp: Fighter): boolean {
    const m = opp.move;
    if (!m || (opp.state !== 'attack' && opp.state !== 'air')) return false;
    return opp.phase < 2 && Math.abs(opp.x - this.x) < (m.range * opp.build.reach + 70) * opp.build.scale;
  }

  private fwdOf(inp: Input) {
    return ((inp.r ? 1 : 0) - (inp.l ? 1 : 0)) * this.facing;
  }

  private wantsGuard(inp: Input, fwd: number, opp: Fighter) {
    if (inp.block) return true;
    return CONFIG.block.autoGuard && this.human && fwd <= 0 && this.threatFrom(opp);
  }

  canBlock(): boolean {
    return this.state === 'block' || this.state === 'blockhit';
  }

  /** bare-handed fighters use the fist versions of the weapon moves */
  private resolveMove(name: MoveName): MoveName {
    if (this.armed) return name;
    switch (name) {
      case 'slash1': case 'lowslash': return 'jab';
      case 'slash2': case 'thrust': case 'rise': return 'cross';
      case 'slash3': case 'slash4': case 'upper': return 'uppercut';
      case 'airslash': return 'airkick';
      default: return name;
    }
  }

  startMove(name: MoveName, chained = false) {
    this.queued = null;
    this.chainN = chained ? this.chainN + 1 : 1;
    const m = MOVES[this.resolveMove(name)];
    // FREESTYLE: a chained move comes out of the flourish that fits the transition
    this.enderDone = false;
    this.trick = null;
    if (chained) this.flairInto(m, this.move);
    else { this.flo = null; this.lastFlair = null; }
    this.move = m; this.anim = m.anim; this.animT = 0; this.moveT = 0; this.phase = 0;
    this.hitDone = false; this.hitActive = false; this.whooshed = false; this.connected = false;
    // step in only as far as needed so the strike lands at full extension
    this.stepK = 1;
    if (m.step && m.ideal !== undefined) {
      const sc = this.build.scale;
      const full = m.step.dist * (m.base === 'kick' ? this.build.kickStep : 1) * sc;
      this.stepK = clamp((this.oppDist - m.ideal * sc) / full, 0, 1);
    }
    if (m.air) {
      this.rotGoal = Math.round(this.rot / 360) * 360;
    } else {
      this.state = 'attack'; this.stateT = 0;
    }
  }

  /** which button is waiting: 2 = heavy (H), 0 = punch (J), 1 = kick (K), -1 = none */
  private btnOf(inp: Input): number {
    return inp.heavy > 0 ? 2 : inp.punch > 0 ? 0 : inp.kick > 0 ? 1 : -1;
  }
  private eat(inp: Input, btn: number) {
    if (btn === 2) inp.heavy = 0;
    else if (btn === 1) inp.kick = 0;
    else inp.punch = 0;
  }

  private pick(inp: Input, fwd: number, btn: number): MoveName {
    if (btn === 2) return inp.u ? 'heavy2' : 'heavy1';
    if (btn === 1) return inp.u ? 'roundhouse' : inp.d ? 'sweep' : fwd > 0 ? 'sidekick' : 'kick1';
    return inp.u ? 'upper' : inp.d ? 'lowslash' : fwd > 0 ? 'thrust' : 'slash1';
  }

  /** running momentum carries into whatever is started out of the run */
  private carry(g: Hooks) {
    if (this.mv > M.forward.speed * 1.2 * this.build.speed * this.build.scale) {
      this.kb += this.facing * this.mv * M.run.attackCarry;
      g.dust(this.x, 0.4);
    }
  }

  /** every action that can start from a neutral or guarding stance */
  private tryActions(inp: Input, fwd: number, g: Hooks): boolean {
    if (inp.super > 0) {
      inp.super = 0;
      if (this.energy >= CONFIG.energy.max) {
        this.energy = 0; // uses ALL shadow energy
        this.carry(g);
        this.startMove('super');
        this.fresh = false;
        g.superFx(this);
        return true;
      }
      g.sfx('deny', 0.6);
    }
    if (inp.throw > 0) {
      inp.throw = 0;
      this.carry(g);
      this.startMove('throw');
      this.fresh = false;
      return true;
    }
    const btn = this.btnOf(inp);
    if (btn >= 0) {
      this.eat(inp, btn);
      this.carry(g);
      this.startMove(this.pick(inp, fwd, btn));
      this.fresh = true;
      this.freshBtn = btn;
      return true;
    }
    if (inp.style > 0 && this.cdStyle <= 0) {
      inp.style = 0;
      this.startTrick();
      return true;
    }
    if (inp.roll > 0 && this.cdRoll <= 0) {
      inp.roll = 0;
      this.state = 'roll'; this.stateT = 0;
      this.rollDir = fwd > 0 ? 1 : -1;
      this.stopFx();
      g.sfx('swish', 0.6);
      g.dust(this.x, 0.5);
      return true;
    }
    if (inp.flip > 0 && this.cdFlip <= 0) {
      inp.flip = 0;
      // +1 = front flip (towards the facing side), -1 = back flip
      const dir = inp.flipDir !== 0 ? inp.flipDir * this.facing : fwd < 0 ? -1 : 1;
      inp.flipDir = 0;
      this.state = 'air'; this.stateT = 0; this.airT = 0;
      this.airDur = M.flip.duration;
      this.vy = (GRAVITY * this.airDur) / 2;
      let v = ((dir > 0 ? M.flip.distance : M.flip.backDistance) * this.build.scale) / this.airDur;
      if (dir > 0) v = Math.max(v, this.mv); // a running front flip keeps its full speed
      this.vx = dir * this.facing * v;
      this.kb = 0;
      this.flip = dir;
      this.invuln = Math.max(this.invuln, this.airDur * M.flip.invulnUntil);
      this.stopFx();
      g.sfx('jump', 0.6);
      g.dust(this.x, 0.6);
      return true;
    }
    if (inp.u && this.cdJump <= 0) {
      this.jumpDir = fwd;
      this.jumpVx = fwd > 0 ? Math.max(M.jump.drift, this.mv * M.run.jumpCarry) : M.jump.drift;
      this.carry(g);
      this.state = 'squat'; this.stateT = 0;
      return true;
    }
    return false;
  }

  /** maps real time onto the animation through the configured startup / active / recovery phases */
  private runMove(dt: number, g: Hooks) {
    const m = this.move!;
    const prev = this.animT;
    this.moveT += dt * this.build.speed;
    const S = m.startup, A = m.air && m.name === 'airkick' ? 99 : m.active, R = m.recovery;
    const t = this.moveT;
    if (t < S) {
      this.phase = 0;
      this.animT = (m.t0 * t) / S;
    } else if (t < S + A) {
      this.phase = 1;
      this.animT = m.t0 + (m.t1 - m.t0) * Math.min(1, (t - S) / Math.min(A, m.active));
    } else {
      this.phase = 2;
      this.animT = m.t1 + (m.anim.dur - m.t1) * Math.min(1, (t - S - A) / R);
    }
    const ks = m.base === 'kick' ? this.build.kickStep : 1;
    sample(m.anim, this.animT, this.target);
    if (m.anim0) {
      sample(m.anim0, this.animT, this.tmp2);
      mixPose(this.target, this.tmp2, this.target, this.stepK * ks);
    }
    if (m.step) {
      const s = m.step;
      const dist = s.dist * ks * this.stepK;
      const p0 = smooth((prev - s.t0) / (s.t1 - s.t0)), p1 = smooth((this.animT - s.t0) / (s.t1 - s.t0));
      this.x += (p1 - p0) * dist * this.build.scale * this.facing;
      if (prev <= s.t0 && this.animT > s.t0 && dist > 30) g.dust(this.x, 0.35);
    }
    if (m.spin) {
      // somersault: the whole body turns around its centre of mass
      const u = smooth((this.animT - m.spin.t0) / (m.spin.t1 - m.spin.t0));
      this.rot = u >= 1 ? 0 : 360 * m.spin.turns * u;
    }
    if (m.slam !== undefined && prev < m.slam && this.animT >= m.slam) {
      g.dust(this.x + this.facing * 70 * this.build.scale, 1);
      g.shake(6);
      g.sfx('thud', 0.8);
    }
    if (!this.whooshed && this.animT >= m.t0 - 0.03) {
      this.whooshed = true;
      g.sfx(m.part === 'weapon' && this.armed ? 'whoosh' : 'swish', m.heavy ? 1 : 0.75);
    }
    // the hitbox only exists during the ACTIVE phase
    this.hitActive = this.phase === 1 && !this.hitDone;
    this.trailOn = this.armed && ((m.part === 'weapon' && this.animT > (m.trail0 ?? m.t0 - 0.06) && this.animT < m.t1 + 0.03) || this.flo !== null);
    this.kickOn = (m.part === 'footF' || m.part === 'footB') && this.animT > m.t0 - 0.06 && this.animT < m.t1 + 0.02;
  }

  get moveDone() {
    const m = this.move;
    return !m || this.moveT >= m.startup + m.active + m.recovery;
  }

  private land(g: Hooks) {
    this.endMove();
    this.elev = 0; this.vy = 0; this.vx = 0; this.rot = 0;
    if (this.flip) this.cdFlip = M.flip.cooldown;
    else this.cdJump = M.jump.cooldown;
    this.stopFx();
    this.state = 'land'; this.stateT = 0;
    copyPose(this.target, P_LAND);
    this.vel.py -= 170;
    this.flv += 70;
    g.dust(this.x, 0.8);
    g.sfx('land', 0.6);
  }

  // ───────────── reactions ─────────────
  private react(anim: Anim, state: State) {
    this.anim = anim; this.animT = 0; this.state = state; this.stateT = 0;
    this.stopFx();
  }
  private impactPose(anim: Anim, k: number) {
    sample(anim, anim.keys[1].t, this.tmp2);
    wrapYaw(this.pose, this.tmp2);
    mixPose(this.pose, this.pose, this.tmp2, k);
  }
  takeHit(region: 'high' | 'mid' | 'low', kb: number, dir: number) {
    this.hitVar++;
    const anim = region === 'high' ? HITS_HIGH[this.hitVar % 2] : region === 'mid' ? HITS_MID[this.hitVar % 2] : A_HIT_LOW;
    this.react(anim, 'hit');
    this.impactPose(anim, 0.5);
    this.kb = (dir * kb) / this.build.mass;
    const v = this.vel;
    if (region === 'mid') {
      this.flv += 260; v.sB += 320; v.eB -= 260; v.sF += 180; v.head += 260; v.py -= 90;
    } else {
      this.flv -= 320; v.sB -= 380; v.eB -= 200; v.sF -= 240; v.head -= 320; v.wp += 260;
    }
  }
  takeBlock(kb: number, dir: number) {
    this.react(A_BLOCKHIT, 'blockhit');
    this.kb = (dir * kb * 0.7) / this.build.mass;
    this.flv -= 160;
    this.vel.eF += 260; this.vel.wp -= 300; this.vel.py -= 60;
  }
  takeStagger(kb: number, dir: number, region: 'high' | 'mid' | 'low' = 'high') {
    const anim = region === 'mid' ? A_SKID : A_REEL;
    this.react(anim, 'stagger');
    this.impactPose(anim, 0.55);
    this.kb = (dir * kb) / this.build.mass;
    this.skidT = 0;
    const v = this.vel;
    if (region === 'mid') {
      this.flv += 340; v.head += 420; v.sB += 300; v.sF += 260; v.py -= 160; v.wp -= 240;
    } else {
      this.flv -= 400; v.sB -= 460; v.sF -= 340; v.head -= 420; v.wp += 360; v.py += 60;
    }
  }
  celebrate() {
    if (this.state === 'ragdoll') return;
    this.state = 'victory'; this.stateT = 0;
    this.stopFx();
    if (this.armed) this.flourish('twirl', 1, 0.8, 2); // a winner shows off
  }

  /** hit again while airborne */
  juggleHit(ix: number, iy: number) {
    if (!this.rag) return;
    const m = Math.sqrt(this.build.mass);
    this.rag.pop(ix / m, iy / m);
    this.juggled++;
    this.stateT = 0; this.ragStill = 0;
  }

  toRagdoll(ix: number, iy: number, hx: number, hy: number, focus: number, dead: boolean) {
    this.juggled = 0;
    this.clearStyle();
    const e = this.ex;
    e.tw = Math.atan2(Math.sin(e.tw), Math.cos(e.tw));
    e.hw = Math.atan2(Math.sin(e.hw), Math.cos(e.hw));
    e.hy = Math.atan2(Math.sin(e.hy), Math.cos(e.hy));
    this.rag = new Ragdoll(this.j, this.pj, 1 / Math.max(this.lastDt, 1 / 240), this.build, this.facing, dead && this.armed);
    const m = Math.sqrt(this.build.mass);
    this.rag.impulse(ix / m, iy / m, hx, hy, focus, this.build.scale);
    this.state = 'ragdoll'; this.stateT = 0; this.ragStill = 0; this.impactCd = 0.12;
    this.stopFx();
    this.snap = null;
    this.elev = 0; this.vx = this.vy = this.kb = this.mv = 0; this.rot = 0;
    if (dead) this.dead = true;
  }

  private wake(g: Hooks) {
    const j = this.j;
    // the body keeps its handedness: lying on the back or on the belly decides which get-up plays
    const prone = (j[NECK].x - j[PELVIS].x) * this.facing > 0;
    this.x = clamp(j[PELVIS].x, -g.arena, g.arena);
    this.elev = 0;
    this.snapFrom(0.42);
    this.rag = null;
    this.state = 'getup'; this.stateT = 0; this.anim = prone ? A_GETUP_PRONE : A_GETUP; this.animT = 0;
    this.setPoseNow(prone ? P_PRONE : P_LIE);
    this.invuln = 1.35;
    this.fl = this.flv = 0;
  }

  private follow(dt: number) {
    const n = Math.max(1, Math.ceil(dt / (1 / 240)));
    const h = dt / n;
    const p = this.pose, v = this.vel, t = this.target;
    wrapYaw(p, t); // a completed spin is the same pose as no spin at all
    for (let s = 0; s < n; s++) {
      for (let i = 0; i < POSE_KEYS.length; i++) {
        const k = POSE_KEYS[i];
        const w = SPR_W[i];
        v[k] += (w * w * (t[k] - p[k]) - 2 * SPR_Z[i] * w * v[k]) * h;
        p[k] += v[k] * h;
      }
    }
    if (p.fFy < 0) p.fFy = 0;
    if (p.fBy < 0) p.fBy = 0;
  }

  private solveNow() {
    const t = this.tmp;
    copyPose(t, this.pose);
    const off = this.build.off;
    for (let i = 0; i < POSE_KEYS.length; i++) {
      const k = POSE_KEYS[i];
      const o = off[k];
      if (o) t[k] += o;
    }
    t.fFy += this.liftF; t.fFa -= this.liftF * 1.6;
    t.fBy += this.liftB; t.fBa -= this.liftB * 1.6;
    t.torso += this.fl;
    t.head += this.fl * 0.7;
    t.sB -= this.fl * 0.5;
    // freestyle layer
    const st = this.sty;
    if (st.yaw !== 0 || st.head !== 0) {
      // pirouette: the whole body turns rigidly around its vertical axis
      const y = st.yaw, c = Math.cos(y * DEG);
      t.tw += y; t.hw += y; t.hy += st.head; t.zF += y; t.zB += y; t.wz += y; t.lF += y; t.lB += y;
      t.torso *= c; t.head *= c; t.px *= c;
    }
    t.wp += st.wp; t.wz += st.wz; t.eF += st.tuck; t.sF -= st.tuck * 0.4; t.py += st.lift;
    solve(t, this.build, this.x, -this.elev, this.facing, this.rot, this.j, this.ex);
  }

  update(dt: number, opp: Fighter, g: Hooks) {
    if (dt <= 0) return;
    this.lastDt = dt;
    for (let i = 0; i < NJ; i++) { this.pj[i].x = this.j[i].x; this.pj[i].y = this.j[i].y; }
    this.stateT += dt;
    this.invuln -= dt;
    // where the opponent will be once the current knock-back has run out
    const sliding = opp.state === 'hit' || opp.state === 'stagger' || opp.state === 'blockhit';
    this.oppDist = Math.abs(opp.x + (sliding ? opp.kb / 7 : 0) - this.x);
    this.sheath = damp(this.sheath, this.state === 'throwing' || (this.state === 'attack' && this.move?.part === 'grab') ? 1 : 0, 20, dt);
    this.cdJump -= dt; this.cdRoll -= dt; this.cdFlip -= dt; this.cdCrouch -= dt; this.cdRun -= dt; this.cdStyle -= dt;

    if (this.state === 'grabbed') return; // driven by the thrower (heldUpdate)
    if (this.state === 'ragdoll') {
      this.updateRagdoll(dt, g);
      this.post(dt, g);
      return;
    }

    const sp = this.build.speed;
    const sc = this.build.scale;
    const adt = dt * sp;
    const inp = this.input;
    const fwd = this.fwdOf(inp);

    if (this.state !== 'air') {
      this.x += this.kb * dt;
      this.kb *= Math.exp(-7 * dt);
    }
    if (this.state !== 'stand') {
      this.mv = 0; this.fwdHold = 0; this.skid = false;
      if (this.running) { this.running = false; this.cdRun = M.run.cooldown; }
    }
    const xVol = this.x;

    switch (this.state) {
      case 'stand': {
        this.autoFace(opp);
        if (this.tryActions(inp, fwd, g)) break;
        if (this.wantsGuard(inp, fwd, opp)) {
          this.state = 'block'; this.stateT = 0;
          break;
        }
        // crouch: minimum duration + cooldown from CONFIG
        const crouch = (inp.d && (this.sub === 'crouch' || this.cdCrouch <= 0)) || (this.sub === 'crouch' && this.crouchT < M.crouch.duration);
        const sub = crouch ? 'crouch' : fwd !== 0 ? 'walk' : 'idle';
        if (sub === 'crouch') this.crouchT += dt;
        else {
          if (this.sub === 'crouch') this.cdCrouch = M.crouch.cooldown;
          this.crouchT = 0;
        }
        this.sub = sub;
        const R = M.run;
        const u = sp * sc; // config speed -> px/s of this fighter
        // RUN: double-tap forward, or keep holding forward. It ends by itself in front of the opponent.
        this.fwdHold = sub === 'walk' && fwd > 0 ? this.fwdHold + dt : 0;
        const wantRun = sub === 'walk' && fwd > 0 && this.cdRun <= 0
          && (inp.run || (this.human && R.auto && this.fwdHold >= R.autoAfter))
          && this.oppDist > R.stopDist * sc * this.build.reach;
        if (this.running && !wantRun) this.cdRun = R.cooldown;
        this.running = wantRun;
        let tv = 0;
        if (sub === 'walk') {
          const w = fwd > 0 ? M.forward : M.back;
          tv = (wantRun ? R.speed : fwd > 0 ? w.speed : -w.speed) * u;
          this.stride = w.speed * w.duration;
        }
        // velocity eases in and out: a run builds up, and takes a skid to stop
        const rate = this.skid ? R.brake : wantRun && tv > this.mv ? R.accel : sub === 'walk' ? 13 : 17;
        this.mv = damp(this.mv, tv, rate, dt);
        const dx = this.mv * dt;
        this.x += dx * this.facing;
        const v = Math.abs(this.mv) / u;
        // 0 = walking gait … 1 = full run
        const r = this.mv > 0 ? smooth((v - M.forward.speed * 1.08) / (R.speed * 0.9 - M.forward.speed * 1.08)) : 0;
        const ph0 = this.walkPhase;
        this.walkPhase += dx / (lerp(this.stride, R.speed * R.duration, r) * sc);
        if (sub === 'crouch') {
          copyPose(this.target, P_CROUCH);
          this.target.py += Math.sin(g.time * 2.5 + this.idx) * 1.4;
          this.skid = false;
        } else {
          idlePose(this.target, g.time + this.idx * 1.7);
          const a = clamp(v / (M.back.speed * 0.7), 0, 1);
          if (a > 0.01) {
            walkPose(this.tmp2, this.walkPhase, this.stride);
            mixPose(this.target, this.target, this.tmp2, a);
          }
          if (r > 0.01) {
            runPose(this.tmp2, this.walkPhase + RUN_SYNC, this.armed);
            mixPose(this.target, this.target, this.tmp2, r);
            // every foot strike kicks up a little dust
            if (r > 0.5 && Math.floor((ph0 + RUN_SYNC) * 2) !== Math.floor((this.walkPhase + RUN_SYNC) * 2)) {
              g.sfx('step', 0.3 + 0.25 * r);
              g.dust(this.x + this.facing * 10 * sc, 0.08);
            }
          }
          // lean in the direction of travel and into the acceleration
          this.target.torso += clamp(this.mv / (M.forward.speed * u), -1, 1) * 2 + clamp((tv - this.mv) / (R.speed * u), 0, 1) * 10;
          // skid stop when a run is cut short: slide on braced legs until the speed is gone
          const over = (this.mv - Math.max(tv, 0)) / u;
          const was = this.skid;
          if (!this.skid && over > M.forward.speed * 1.25) this.skid = true;
          else if (this.skid && over < 25) this.skid = false;
          if (this.skid) {
            mixPose(this.target, this.target, P_BRAKE, clamp(over / 130, 0, 1));
            if (!was) { g.sfx('skid', 0.7); this.skidT = 0; }
            this.skidT -= dt;
            if (this.skidT <= 0) {
              this.skidT = 0.09;
              g.dust(this.x + this.facing * 44 * sc, 0.12);
            }
          }
        }
        break;
      }
      case 'squat': {
        copyPose(this.target, P_SQUAT);
        if (inp.punch > 0 || inp.kick > 0 || inp.heavy > 0) {
          // up + attack pressed together = rising attack instead of a jump
          if (this.tryActions(inp, fwd, g)) break;
        }
        if (this.stateT >= M.jump.squat) {
          this.state = 'air'; this.stateT = 0; this.airT = 0;
          this.airDur = M.jump.duration;
          this.vy = (GRAVITY * this.airDur) / 2;
          this.flip = 0;
          this.vx = this.jumpDir * this.facing * this.jumpVx;
          this.kb = 0;
          this.move = null;
          g.sfx('jump', 0.5);
          g.dust(this.x, 0.5);
        }
        break;
      }
      case 'air': {
        this.airT += dt;
        this.vy -= GRAVITY * dt;
        this.elev += this.vy * dt;
        this.x += this.vx * dt;
        const u = clamp(this.airT / this.airDur, 0, 1);
        if (this.move) {
          this.runMove(dt, g);
          this.rot = damp(this.rot, this.rotGoal, 22, dt);
        } else {
          if (this.flip > 0) {
            sample(A_FRONTFLIP, u, this.target);
            this.rot = 360 * smooth((u - 0.05) / 0.85);
          } else if (this.flip < 0) {
            sample(A_BACKFLIP, u, this.target);
            this.rot = -360 * smooth((u - 0.1) / 0.8);
          } else {
            mixPose(this.target, P_AIR_UP, P_AIR_MID, Math.sin(Math.PI * u));
          }
          if (inp.punch > 0) { inp.punch = 0; this.startMove('airslash'); }
          else if (inp.kick > 0) { inp.kick = 0; this.startMove('airkick'); }
        }
        if (this.elev <= 0 && this.vy < 0) this.land(g);
        break;
      }
      case 'land': {
        copyPose(this.target, P_LAND);
        if (this.stateT > 0.1) this.toStand();
        break;
      }
      case 'roll': {
        const D = M.roll.duration;
        const u1 = clamp((this.stateT * sp) / D, 0, 1);
        const u0 = clamp(((this.stateT - dt) * sp) / D, 0, 1);
        this.x += this.rollDir * this.facing * M.roll.distance * sc * (smooth(u1) - smooth(u0));
        mixPose(this.target, P_ROLL_IN, P_ROLL, Math.pow(Math.sin(Math.PI * u1), 0.55));
        this.rot = this.rollDir * 360 * smooth((u1 - 0.04) / 0.9);
        if (u1 < M.roll.invulnUntil) this.invuln = Math.max(this.invuln, 0.06);
        if (u1 >= 1) {
          this.rot = 0;
          this.cdRoll = M.roll.cooldown;
          this.toStand();
        }
        break;
      }
      case 'attack': {
        const m = this.move!;
        if (this.fresh && this.stateT < 0.065 && (m.name === 'slash1' || m.name === 'kick1' || m.name === 'jab' || m.name === 'heavy1')) {
          // lenient inputs: a direction pressed a few ms after the button still selects the directional move
          const want = this.resolveMove(this.pick(inp, fwd, this.freshBtn));
          if (want !== m.name) {
            const t = this.stateT;
            this.startMove(want);
            this.stateT = t;
            break;
          }
        } else this.fresh = false;
        this.runMove(dt, g);
        const K = CONFIG.combo;
        // FREESTYLE ender: a string that landed is rounded off with a roll of the blade while recovering
        if (CONFIG.freestyle.ender && !this.enderDone && this.phase === 2 && !this.queued && this.connected && this.armed
          && (this.chainN >= 2 || m.base === 'heavy') && this.moveT >= m.startup + m.active + m.recovery * 0.22) {
          this.enderDone = true;
          this.flourish('twirl', -1, m.recovery * 0.7);
        }
        // SUPER CANCEL: a strike that landed can be cut straight into the super strike
        if (inp.super > 0 && this.connected && m.base !== 'super' && this.energy >= CONFIG.energy.max) {
          inp.super = 0;
          this.energy = 0;
          this.endMove();
          this.startMove('super', true);
          g.superFx(this);
          break;
        }
        // COMBO: a press is remembered for the rest of the attack, so mashing and keeping the rhythm both work.
        // J / K / H without ↑↓ = the move the combo tree gives for that button · ↑ / ↓ + button = directional ender.
        if (m.next && !this.queued && this.chainN < K.maxString) {
          const btn = this.btnOf(inp);
          if (btn >= 0) {
            const nx = inp.u || inp.d ? this.pick(inp, 0, btn) : btn === 2 ? m.next.heavy : btn === 1 ? m.next.kick : m.next.punch;
            if (nx && this.resolveMove(nx) !== m.name) {
              this.queued = nx;
              this.eat(inp, btn);
            }
          }
        }
        // the queued move cuts the recovery short
        if (this.queued && this.phase === 2 && this.moveT >= m.startup + m.active + m.recovery * K.cancelAt) {
          const nx = this.queued;
          this.endMove();
          this.fresh = false;
          this.startMove(nx, true);
          break;
        }
        if (this.moveDone) {
          this.endMove();
          this.toStand();
        }
        break;
      }
      case 'block': {
        this.autoFace(opp);
        if (this.tryActions(inp, fwd, g)) break;
        copyPose(this.target, inp.d ? P_BLOCK_LOW : P_BLOCK);
        if (!this.wantsGuard(inp, fwd, opp) && this.stateT > 0.1) this.toStand();
        break;
      }
      case 'blockhit':
      case 'hit':
      case 'stagger':
      case 'getup': {
        this.animT += this.state === 'getup' ? adt : dt;
        sample(this.anim!, this.animT, this.target);
        if (this.state === 'stagger' && Math.abs(this.kb) > 120) {
          this.skidT -= dt;
          if (this.skidT <= 0) {
            this.skidT = 0.07;
            g.dust(this.x - Math.sign(this.kb) * 14, 0.3);
          }
        }
        if (this.animT >= this.anim!.dur) {
          if (this.state === 'blockhit' && this.wantsGuard(inp, fwd, opp)) {
            this.state = 'block'; this.stateT = 0;
          } else {
            if (this.state === 'getup') this.invuln = 0.25;
            this.toStand();
          }
        }
        break;
      }
      case 'throwing': {
        this.animT += adt;
        sample(A_THROW_DO, this.animT, this.target);
        if (!this.released && this.animT >= CONFIG.throwAnim.releaseAt) {
          this.released = true;
          this.throwRelease = true;
          g.sfx('whoosh', 1);
        }
        if (this.animT >= CONFIG.throwAnim.duration) this.toStand();
        break;
      }
      case 'style': {
        const tr = this.trick;
        if (!tr) { this.toStand(); break; }
        const prev = this.animT;
        this.animT += adt;
        sample(tr.anim, this.animT, this.target);
        if (prev < tr.f0 && this.animT >= tr.f0) {
          if (this.armed) this.flourish(tr.flair, tr.dir, tr.f1 - tr.f0, tr.turns, 0); // blade stays extended: a ring of light
          else if (!tr.spin) this.flourish('pirouette', 1, tr.f1 - tr.f0, 1);
        }
        if (tr.spin) {
          const u = (this.animT - tr.spin.t0) / (tr.spin.t1 - tr.spin.t0);
          this.rot = u <= 0 || u >= 1 ? 0 : 360 * tr.spin.turns * smooth(u);
          if (prev < tr.spin.t1 && this.animT >= tr.spin.t1) {
            g.dust(this.x, 0.7);
            g.sfx('land', 0.6);
          }
        }
        this.trailOn = this.armed && this.flo !== null;
        if (!this.styPaid && this.animT >= tr.f1) {
          this.styPaid = true;
          this.addEnergy(CONFIG.freestyle.energy);
          g.styleFx(this);
        }
        // a finished trick flows straight into whatever is pressed next
        if (this.styPaid && this.rot === 0 && this.tryActions(inp, fwd, g)) {
          if (this.state !== 'style') this.trick = null;
          break;
        }
        if (this.animT >= tr.anim.dur) this.toStand();
        break;
      }
      case 'victory': {
        copyPose(this.target, P_VICTORY);
        this.trailOn = this.armed && this.flo !== null;
        this.target.py += Math.sin(g.time * 2.2) * 1.5;
        this.target.wp += Math.sin(g.time * 1.6) * 3;
        break;
      }
    }

    this.volV = ((this.x - xVol) * this.facing) / (dt * sc);
    if (Math.abs(this.x) > g.arena) {
      this.x = clamp(this.x, -g.arena, g.arena);
      if (this.state === 'stand') this.mv = 0; // no running on the spot against the edge
    }

    this.follow(dt);

    {
      const st = this.state;
      const stepping = st === 'attack' || st === 'throwing' || st === 'stand' || st === 'block' || st === 'hit' || st === 'stagger' || st === 'blockhit';
      const lf = stepping && !this.skid && this.pose.fFy < 6 ? clamp((Math.abs(this.volV + this.vel.fFx) - 60) * 0.035, 0, 11) : 0;
      const lb = stepping && !this.skid && this.pose.fBy < 6 ? clamp((Math.abs(this.volV + this.vel.fBx) - 60) * 0.035, 0, 11) : 0;
      this.liftF = damp(this.liftF, lf, 28, dt);
      this.liftB = damp(this.liftB, lb, 28, dt);
    }

    this.flv += (-230 * this.fl - 15 * this.flv) * dt;
    this.fl = clamp(this.fl + this.flv * dt, -40, 40);

    this.stepStyle(dt, g);
    this.solveNow();

    if (this.snap) {
      this.snapT += dt;
      const u = smooth(this.snapT / this.snapDur);
      if (u >= 1) this.snap = null;
      else {
        for (let i = 0; i < NJ; i++) {
          this.j[i].x = lerp(this.x + this.snap[i].x, this.j[i].x, u);
          this.j[i].y = lerp(this.snap[i].y - this.elev, this.j[i].y, u);
        }
      }
    }
    this.post(dt, g);
  }

  /** ragdoll: the body goes flat again – shoulders and hips fall back onto the spine */
  private limpExtra(dt: number) {
    const e = this.ex, j = this.j, s = this.build.scale, wide = Math.min(this.build.thick, 1.25);
    const k = Math.exp(-12 * dt);
    e.tw *= k; e.hw *= k; e.hy *= k; e.zsF *= k; e.zsB *= k;
    for (let i = 0; i < NJ; i++) e.z[i] *= k;
    const nk = j[NECK], pv = j[PELVIS];
    let ux = nk.x - pv.x, uy = nk.y - pv.y;
    const ul = Math.hypot(ux, uy) || 1;
    ux /= ul; uy /= ul;
    const cx = -uy * this.facing, cy = ux * this.facing; // chest direction
    const sw = BONE.shoulder * s * wide * Math.sin(e.tw), hw = BONE.hip * s * wide * Math.sin(e.hw);
    e.shF.x = nk.x + cx * sw; e.shF.y = nk.y + cy * sw;
    e.shB.x = nk.x - cx * sw; e.shB.y = nk.y - cy * sw;
    e.hpF.x = pv.x + cx * hw; e.hpF.y = pv.y + cy * hw;
    e.hpB.x = pv.x - cx * hw; e.hpB.y = pv.y - cy * hw;
  }

  private updateRagdoll(dt: number, g: Hooks) {
    const rag = this.rag!;
    const imp = rag.step(dt, 0, -g.arena - 70, g.arena + 70);
    rag.write(this.j);
    this.limpExtra(dt);
    this.x = this.j[PELVIS].x;
    this.impactCd -= dt;
    if (imp.speed > 330 && this.impactCd <= 0) {
      this.impactCd = 0.14;
      const k = clamp(imp.speed / 900, 0.25, 1.2);
      if (imp.weapon) {
        g.sfx('clank', k * 0.7);
      } else {
        g.dust(imp.x, k * 1.6);
        g.sfx('thud', k);
        g.shake(k * 9 * this.build.mass);
      }
    }
    if (this.dead) return;
    if (rag.energy() < 6000) this.ragStill += dt;
    else this.ragStill = 0;
    if ((this.stateT > 0.55 && this.ragStill > 0.12) || this.stateT > 2.4) this.wake(g);
  }

  private anchors(): [number, number][] {
    const j = this.j, s = this.build.scale;
    const kh = Math.cos(this.ex.hy), kt = Math.cos(this.ex.tw); // hair and cloth swing round with the body
    let ux = j[HEAD].x - j[NECK].x, uy = j[HEAD].y - j[NECK].y;
    const ul = Math.hypot(ux, uy) || 1;
    ux /= ul; uy /= ul;
    const fx = -uy * this.facing, fy = ux * this.facing;
    if (this.build.kind === 'shadow') {
      const tx = j[HEAD].x + ux * 13 * s - fx * 7 * s * kh, ty = j[HEAD].y + uy * 13 * s - fy * 7 * s * kh;
      const nx = j[NECK].x + ux * 6 * s - fx * 9 * s * kt, ny = j[NECK].y + uy * 6 * s - fy * 9 * s * kt;
      return [[tx, ty], [nx, ny]];
    }
    let tx = j[NECK].x - j[PELVIS].x, ty = j[NECK].y - j[PELVIS].y;
    const tl = Math.hypot(tx, ty) || 1;
    tx /= tl; ty /= tl;
    const bx = -ty * this.facing, by = tx * this.facing;
    const ax = j[NECK].x - bx * 14 * s * kt, ay = j[NECK].y - by * 14 * s * kt;
    return [[ax, ay], [ax - tx * 6 * s, ay - ty * 6 * s], [ax + bx * 6 * s, ay + by * 6 * s]];
  }

  private post(dt: number, g: Hooks) {
    const a = this.anchors();
    for (let i = 0; i < this.chains.length; i++) {
      const wind = -this.facing * 160 + Math.sin(g.time * 1.3 + i * 1.7 + this.idx) * 120;
      this.chains[i].update(a[i][0], a[i][1], dt, wind);
    }
    const j = this.j, pj = this.pj;
    // afterimages while a hand or a foot moves really fast (strikes, spins, flips, rolls)
    for (const gh of this.ghosts) gh.age += dt;
    this.ghostT -= dt;
    const st = this.state;
    if (this.ghostT <= 0 && (st === 'attack' || st === 'roll' || (st === 'air' && (this.flip !== 0 || this.move !== null)))) {
      let v = 0;
      for (const i of [HAF, HAB, TOF, TOB, HEAD]) v = Math.max(v, Math.hypot(j[i].x - pj[i].x, j[i].y - pj[i].y));
      if (v > GHOST_SPEED * dt) {
        let gh = this.ghosts[0];
        for (const o of this.ghosts) if (o.age > gh.age) gh = o;
        for (let i = 0; i < NJ; i++) { gh.j[i].x = j[i].x; gh.j[i].y = j[i].y; }
        copyExtra(gh.ex, this.ex);
        gh.age = 0;
        this.ghostT = GHOST_EVERY;
      }
    }
    const tr = this.trail;
    for (let i = tr.length - 1; i >= 0; i--) {
      tr[i].age += dt;
      if (tr[i].age > TRAIL_LIFE) tr.splice(i, 1);
    }
    if (this.trailOn) {
      // projected blade length: shorter while the blade points towards / away from the camera
      const L0 = Math.hypot(pj[TIP].x - pj[WBASE].x, pj[TIP].y - pj[WBASE].y);
      const L1 = Math.hypot(j[TIP].x - j[WBASE].x, j[TIP].y - j[WBASE].y);
      const sup = this.move?.base === 'super';
      const inner = sup ? 0 : this.flo ? 0.5 : 0.3; // a flourish leaves a ring, a cut leaves a blade-wide band
      const a0 = Math.atan2(pj[TIP].y - pj[WBASE].y, pj[TIP].x - pj[WBASE].x);
      const a1 = Math.atan2(j[TIP].y - j[WBASE].y, j[TIP].x - j[WBASE].x);
      let da = a1 - a0;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      const n = clamp(Math.ceil(Math.abs(da) / 0.1), 1, 10);
      for (let k = 1; k <= n; k++) {
        const u = k / n;
        const bx = lerp(pj[WBASE].x, j[WBASE].x, u), by = lerp(pj[WBASE].y, j[WBASE].y, u);
        const an = a0 + da * u;
        const L = lerp(L0, L1, u);
        const c = Math.cos(an), s = Math.sin(an);
        tr.push({
          bx: bx + c * L * inner, by: by + s * L * inner, tx: bx + c * L * 1.02, ty: by + s * L * 1.02,
          age: (1 - u) * dt, brk: !this.trailWas && k === 1, sup,
        });
      }
    }
    this.trailWas = this.trailOn;
    const kt = this.ktrail;
    for (let i = kt.length - 1; i >= 0; i--) {
      kt[i].age += dt;
      if (kt[i].age > KICK_LIFE) kt.splice(i, 1);
    }
    if (this.kickOn && this.move) {
      const idx = this.move.part === 'footB' ? TOB : TOF;
      for (let k = 1; k <= 3; k++) {
        const u = k / 3;
        kt.push({ x: lerp(pj[idx].x, j[idx].x, u), y: lerp(pj[idx].y, j[idx].y, u), age: (1 - u) * dt, brk: !this.kickWas && k === 1 });
      }
    }
    this.kickWas = this.kickOn;
  }
}
