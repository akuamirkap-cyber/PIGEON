import { TAU, rand } from './math';

type Ctx = CanvasRenderingContext2D;

interface Spark { x: number; y: number; vx: number; vy: number; life: number; max: number; w: number; hot: boolean }
interface Dust { x: number; y: number; vx: number; vy: number; r: number; life: number; max: number }
interface Ring { x: number; y: number; r: number; vr: number; life: number; max: number; w: number }
interface Streak { x: number; y: number; a: number; len: number; life: number; max: number }
interface Glow { x: number; y: number; r: number; life: number; max: number }
interface Mote { x: number; y: number; vx: number; vy: number; life: number; max: number }
interface Txt { x: number; y: number; text: string; color: string; size: number; life: number; max: number }

export class Fx {
  sparks: Spark[] = [];
  dusts: Dust[] = [];
  rings: Ring[] = [];
  streaks: Streak[] = [];
  glows: Glow[] = [];
  motes: Mote[] = [];
  texts: Txt[] = [];

  clear() {
    this.sparks.length = this.dusts.length = this.rings.length = this.streaks.length = this.glows.length = this.motes.length = this.texts.length = 0;
  }

  /** impact burst. dir = direction the blow travels (+1/-1) */
  hit(x: number, y: number, dir: number, power: number, kind: 'slash' | 'blunt' | 'block') {
    const n = Math.round((kind === 'block' ? 14 : 9) * power);
    for (let i = 0; i < n; i++) {
      const spread = kind === 'block' ? Math.PI : 1.5;
      const a = (dir > 0 ? 0 : Math.PI) + rand(-spread, spread) * 0.6 - 0.25;
      const sp = rand(250, 900) * (0.6 + power * 0.5);
      const max = rand(0.16, 0.42);
      this.sparks.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 120, life: max, max, w: rand(1.4, 3.2), hot: kind === 'block' });
    }
    this.glows.push({ x, y, r: 60 + 55 * power, life: 0.16, max: 0.16 });
    if (kind !== 'block') {
      this.rings.push({ x, y, r: 8, vr: 380 + 260 * power, life: 0.24, max: 0.24, w: 5 * power });
    }
    if (kind === 'slash') {
      const a = rand(-0.9, -0.3) * dir + (dir > 0 ? 0 : Math.PI);
      this.streaks.push({ x, y, a, len: 120 + 90 * power, life: 0.16, max: 0.16 });
    } else if (kind === 'blunt') {
      for (let i = 0; i < 3; i++) this.streaks.push({ x, y, a: rand(TAU), len: 50 + 40 * power, life: 0.12, max: 0.12 });
    }
  }

  /** floating combat text (HEAD HIT, CRITICAL, SHOCK, FIRST STRIKE …) */
  text(x: number, y: number, text: string, color: string, size = 24) {
    // never draw one text over another: move up until there is room (combos spawn them in quick succession)
    let yy = y;
    for (let pass = 0; pass < 8; pass++) {
      let moved = false;
      for (const t of this.texts) {
        const gap = (t.size + size) * 0.56;
        if (Math.abs(t.x - x) < 150 && Math.abs(t.y - yy) < gap) {
          yy = t.y - gap;
          moved = true;
        }
      }
      if (!moved) break;
    }
    this.texts.push({ x, y: yy, text, color, size, life: 0.95, max: 0.95 });
  }

  /** shadow energy rushing into the fighter */
  charge(x: number, y: number, n = 34) {
    for (let i = 0; i < n; i++) {
      const a = rand(TAU), r = rand(90, 190);
      const max = rand(0.22, 0.42);
      this.motes.push({ x: x + Math.cos(a) * r, y: y + Math.sin(a) * r * 0.8, vx: (-Math.cos(a) * r) / max, vy: (-Math.sin(a) * r * 0.8) / max, life: max, max });
    }
    this.rings.push({ x, y, r: 150, vr: -420, life: 0.3, max: 0.3, w: 4 });
  }

  /** violet burst used by the super strike */
  burst(x: number, y: number) {
    for (let i = 0; i < 26; i++) {
      const a = rand(TAU), sp = rand(300, 900);
      const max = rand(0.25, 0.5);
      this.motes.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: max, max });
    }
  }

  dust(x: number, amount: number) {
    const n = Math.max(1, Math.round(1 + amount * 11));
    for (let i = 0; i < n; i++) {
      const max = rand(0.45, 1.0);
      const side = rand(-1, 1);
      this.dusts.push({
        x: x + side * 26, y: -2 - rand(5), vx: side * rand(70, 260) * (0.5 + amount), vy: -rand(10, 70) * (0.5 + amount),
        r: rand(5, 11) * (0.45 + amount * 0.6), life: max, max,
      });
    }
  }

  update(dt: number) {
    if (dt <= 0) return;
    for (let i = this.sparks.length - 1; i >= 0; i--) {
      const p = this.sparks[i];
      p.life -= dt;
      if (p.life <= 0) { this.sparks.splice(i, 1); continue; }
      p.vy += 1500 * dt;
      p.vx *= 1 - 2.2 * dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.y > -1) { p.y = -1; p.vy *= -0.4; p.vx *= 0.6; }
    }
    for (let i = this.dusts.length - 1; i >= 0; i--) {
      const p = this.dusts[i];
      p.life -= dt;
      if (p.life <= 0) { this.dusts.splice(i, 1); continue; }
      p.vx *= 1 - 2.6 * dt; p.vy *= 1 - 1.5 * dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.r += 22 * dt;
    }
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const p = this.rings[i];
      p.life -= dt;
      if (p.life <= 0) { this.rings.splice(i, 1); continue; }
      p.r += p.vr * dt; p.vr *= 1 - 5 * dt;
    }
    for (let i = this.streaks.length - 1; i >= 0; i--) {
      this.streaks[i].life -= dt;
      if (this.streaks[i].life <= 0) this.streaks.splice(i, 1);
    }
    for (let i = this.glows.length - 1; i >= 0; i--) {
      this.glows[i].life -= dt;
      if (this.glows[i].life <= 0) this.glows.splice(i, 1);
    }
    for (let i = this.motes.length - 1; i >= 0; i--) {
      const p = this.motes[i];
      p.life -= dt;
      if (p.life <= 0) { this.motes.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= 1 - 1.5 * dt; p.vy *= 1 - 1.5 * dt;
    }
  }

  /** texts keep real time so they stay readable during slow motion */
  updateTexts(dt: number) {
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt;
      t.y -= 34 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
  }

  drawTexts(ctx: Ctx) {
    ctx.save();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    for (const t of this.texts) {
      const age = t.max - t.life;
      const pop = age < 0.12 ? 1.5 - (age / 0.12) * 0.5 : 1;
      const al = Math.min(1, t.life / 0.3);
      ctx.globalAlpha = al;
      ctx.font = `900 ${Math.round(t.size * pop)}px Cinzel, Georgia, serif`;
      ctx.lineWidth = Math.max(3, t.size * 0.22);
      ctx.strokeStyle = 'rgba(20,8,0,0.9)';
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillStyle = t.color;
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.restore();
  }

  drawDust(ctx: Ctx) {
    for (const p of this.dusts) {
      const k = p.life / p.max;
      ctx.fillStyle = `rgba(70,46,20,${(0.13 * k).toFixed(3)})`;
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, p.r * 1.5, p.r * 0.75, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = `rgba(30,18,6,${(0.1 * k).toFixed(3)})`;
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, p.r * 0.85, p.r * 0.42, 0, 0, TAU);
      ctx.fill();
    }
  }

  drawLight(ctx: Ctx) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const g of this.glows) {
      const k = g.life / g.max;
      const gr = ctx.createRadialGradient(g.x, g.y, 0, g.x, g.y, g.r);
      gr.addColorStop(0, `rgba(255,250,225,${(0.95 * k).toFixed(3)})`);
      gr.addColorStop(0.35, `rgba(255,214,130,${(0.45 * k).toFixed(3)})`);
      gr.addColorStop(1, 'rgba(255,170,60,0)');
      ctx.fillStyle = gr;
      ctx.beginPath();
      ctx.arc(g.x, g.y, g.r, 0, TAU);
      ctx.fill();
    }
    for (const p of this.motes) {
      const k = p.life / p.max;
      ctx.strokeStyle = `rgba(${Math.round(150 + 60 * k)},${Math.round(120 + 40 * k)},255,${(0.9 * k).toFixed(3)})`;
      ctx.lineWidth = 1.5 + 2.5 * k;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - p.vx * 0.035, p.y - p.vy * 0.035);
      ctx.stroke();
    }
    ctx.lineCap = 'round';
    for (const p of this.sparks) {
      const k = p.life / p.max;
      ctx.strokeStyle = p.hot ? `rgba(255,${Math.round(170 + 80 * k)},${Math.round(90 + 140 * k)},${k.toFixed(3)})` : `rgba(255,${Math.round(215 + 40 * k)},${Math.round(150 + 90 * k)},${k.toFixed(3)})`;
      ctx.lineWidth = p.w * (0.4 + 0.6 * k);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - p.vx * 0.03, p.y - p.vy * 0.03);
      ctx.stroke();
    }
    for (const r of this.rings) {
      const k = r.life / r.max;
      ctx.strokeStyle = `rgba(255,244,214,${(0.7 * k).toFixed(3)})`;
      ctx.lineWidth = Math.max(0.5, r.w * k);
      ctx.beginPath();
      ctx.arc(r.x, r.y, r.r, 0, TAU);
      ctx.stroke();
    }
    for (const s of this.streaks) {
      const k = s.life / s.max;
      const len = s.len * (1.25 - k * 0.6);
      const wd = 7 * k;
      const c = Math.cos(s.a), sn = Math.sin(s.a);
      ctx.fillStyle = `rgba(255,252,238,${Math.min(1, k * 1.4).toFixed(3)})`;
      ctx.beginPath();
      ctx.moveTo(s.x - c * len, s.y - sn * len);
      ctx.lineTo(s.x - sn * wd, s.y + c * wd);
      ctx.lineTo(s.x + c * len, s.y + sn * len);
      ctx.lineTo(s.x + sn * wd, s.y - c * wd);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }
}
