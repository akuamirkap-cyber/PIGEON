import type { Telemetry } from './rally-course';

function clock(seconds: number) {
  const ms = Math.max(0, Math.floor(seconds * 1000 + .000001));
  return `${String(Math.floor(ms / 60000)).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}.${String(ms % 1000).padStart(3, '0')}`;
}

export function CockpitHud({ data, route, start }: { data: Telemetry; route: string; start: { x: number; y: number } }) {
  return <div className="cockpit-hud">
    <div className="lap-clock">
      <div className="lap-kicker"><span />PUTARAN {String(data.lap).padStart(2, '0')}</div>
      <output className="lap-time" aria-label="Waktu putaran" aria-live="off">{clock(data.time)}</output>
      <div className="lap-splits">
        <div className="lap-best"><span>TERBAIK</span><span>{data.best === null ? '--:--.---' : clock(data.best)}</span></div>
        <div className="lap-best"><span>TERAKHIR</span><span>{data.last === null ? '--:--.---' : clock(data.last)}</span></div>
      </div>
    </div>
    <div className="cockpit-speed">
      <div><output aria-label="Kecepatan di lintasan" aria-live="off">{String(data.speed).padStart(2, '0')}</output><span>KM/J</span></div>
      <div className="cockpit-gear"><span>GIGI</span><output aria-label="Gigi saat ini" aria-live="off">{data.gear}</output></div>
    </div>
    {route && <div className="course-map" aria-label="Peta Sirkuit Pinus">
      <svg viewBox="0 0 100 100" width="98" height="98" aria-hidden="true">
        <path className="map-track-outline" d={route}/><path className="map-track" d={route}/>
        <path className="map-start" d={`M${start.x - 4} ${start.y}h8`}/>
        <circle className="map-marker-shadow" cx={data.mapX} cy={data.mapY} r="5.2"/>
        <circle className="map-marker" cx={data.mapX} cy={data.mapY} r="3.2"/>
      </svg>
      <span>SIRKUIT PINUS</span>
    </div>}
  </div>;
}