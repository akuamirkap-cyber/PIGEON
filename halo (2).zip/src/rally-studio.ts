import type * as Three from 'three';
import type { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import type { RallyBuild } from './rally-config';
import { createRallyCourse } from './rally-course';
import type { Telemetry } from './rally-course';
import orbitCode from 'three/examples/jsm/controls/OrbitControls.js?raw';
import engineCode from '../node_modules/three/build/three.module.min.js?raw';

const threeURL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/0.160.0/three.module.min.js';
const threeIntegrity = 'sha384-8/hf5tabFfIo0BPku31TKUvGIKpWGYaMwNtlSNqNyZzXgZCMd4lnOGWbJElML9dv';
const TAU = Math.PI * 2;
export type ViewId = 'threeQuarter' | 'front' | 'noseDetail' | 'rear' | 'rearQuarter' | 'rearDetail' | 'left' | 'right' | 'top';
export type DriveKey = 'w' | 's' | 'a' | 'd';
export type GripKey = DriveKey | 'space';
export type ViewerMode = 'garage' | 'cockpit';

type ModelOptions = Partial<RallyBuild> & { build?: Partial<RallyBuild>; THREE?: typeof Three; headlights?: boolean; cockpit?: boolean; canvasFactory?: (width: number, height: number) => HTMLCanvasElement };
type RallyModel = Three.Group & { userData: {
  tick: (dt: number, state: { speed:number; steer:number; gear?:string; rev?:number; handbrake?:boolean; serviceBrake?:boolean; steerIntent?:number; displayKmh?:number }) => void;
  setHeadlights: (enabled: boolean) => void;
  updateGlow: (eye: Three.Vector3) => void;
  setCockpitView: (enabled: boolean) => void;
  setMirrorTexture: (texture: Three.Texture | null) => void;
  resetDriver: (gear?: string) => void;
  driverAction: { mode: 'wheel' | 'brake' | 'gear'; reach: number; contact: boolean };
  sockets: { driverEye: Three.Object3D };
  build: RallyBuild;
  setBuild: (patch: Partial<RallyBuild>) => RallyBuild;
} };
type ModelModule = {
  createRallyCarModel: (options?: ModelOptions) => RallyModel;
  configureRallyThree: (three: typeof Three) => void;
};

declare global {
  interface Window { createRallyCarModel?: ModelModule['createRallyCarModel']; }
}

type Libraries = { T: typeof Three; Controls: typeof OrbitControls };
let engineTask: Promise<Libraries> | undefined;
let modelTask: Promise<ModelModule> | undefined;
export function modelSource() { return document.getElementById('rally-model')?.textContent?.trim() ?? ''; }

function moduleBlob(source: string) { return URL.createObjectURL(new Blob([source], { type: 'text/javascript' })); }

function loadEngine() {
  return engineTask ??= (async () => {
    const abort = new AbortController();
    const deadline = window.setTimeout(() => abort.abort(), 1400);
    let engineSource = engineCode;
    try {
      if (navigator.onLine) {
        const response = await fetch(threeURL, { signal: abort.signal, mode: 'cors', integrity: threeIntegrity });
        if (response.ok) engineSource = await response.text();
      }
    } catch {
      // The embedded build remains available if the CDN cannot be reached.
    } finally {
      clearTimeout(deadline);
    }
    // OrbitControls imports the same engine URL, including when the HTML is opened offline.
    const engineUrl = moduleBlob(engineSource);
    const controlsUrl = moduleBlob(orbitCode.replace(/from ['"]three['"]/, `from ${JSON.stringify(engineUrl)}`));
    try {
      const [T, { OrbitControls: Controls }] = await Promise.all([
        import(/* @vite-ignore */ engineUrl) as Promise<typeof Three>,
        import(/* @vite-ignore */ controlsUrl) as Promise<{ OrbitControls: typeof OrbitControls }>,
      ]);
      return { T, Controls };
    } finally {
      URL.revokeObjectURL(engineUrl); URL.revokeObjectURL(controlsUrl);
    }
  })();
}

function loadModel() {
  if (!modelTask) {
    const moduleUrl = moduleBlob(modelSource());
    modelTask = import(/* @vite-ignore */ moduleUrl).finally(() => URL.revokeObjectURL(moduleUrl));
  }
  return modelTask;
}

type ViewPreset = { yaw: number; polar: number; y: number; x?: number; z?: number; zoom?: number };
const presets: Record<ViewId, ViewPreset> = {
  threeQuarter: { yaw: .870, polar: 1.288, y: .984 },
  front: { yaw: 0, polar: 1.471, y: 1.02, zoom: 1.125 },
  noseDetail: { yaw: -.765, polar: 1.245, x: -.106, y: .720, z: 2.098, zoom: 1.80 },
  rear: { yaw: Math.PI, polar: 1.493, y: 1.01, zoom: 1.12 },
  rearQuarter: { yaw: 2.67, polar: 1.378, y: 1.035, zoom: 1.08 },
  rearDetail: { yaw: -2.609, polar: 1.482, x: -.082, y: 1.030, z: -1.927, zoom: 1.58 },
  left: { yaw: Math.PI / 2, polar: 1.55, y: .96 },
  right: { yaw: -Math.PI / 2, polar: 1.55, y: .96 },
  top: { yaw: Math.PI / 2, polar: .001, y: .94, zoom: .98 },
};

type StudioCallbacks = {
  onManualOrbit: () => void;
  onSpeed: (kmh: number) => void;
  onTelemetry: (next: Telemetry) => void;
  onCourse: (route: string, start: { x: number; y: number }) => void;
};
export type Studio = {
  view: (name: ViewId) => void;
  mode: (name: ViewerMode) => void;
  pause: (paused: boolean) => void;
  restart: () => void;
  zoomBy: (direction: number) => void;
  turntable: (enabled: boolean, wait?: number) => void;
  configure: (build: RallyBuild) => void;
  headlights: (enabled: boolean) => void;
  input: (key: GripKey, down: boolean) => void;
  releaseInputs: () => void;
  dispose: () => void;
};

export async function createStudio(host: HTMLDivElement, callbacks: StudioCallbacks, signal: AbortSignal, initial: { build: RallyBuild; headlights: boolean; view: ViewId; mode: ViewerMode }): Promise<Studio | undefined> {
  const [{ T, Controls }, model] = await Promise.all([loadEngine(), loadModel()]);
  if (signal.aborted) return;
  model.configureRallyThree(T);
  window.createRallyCarModel = model.createRallyCarModel;

  const scene = new T.Scene();
  const renderer = new T.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = T.SRGBColorSpace;
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.13;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = T.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.domElement.setAttribute('aria-label', 'Model 3D interaktif coupe reli Grup B');
  renderer.domElement.setAttribute('role', 'img');
  host.append(renderer.domElement);

  const camera = new T.OrthographicCamera(-5, 5, 2.1, -2.1, .1, 64);
  const driverCamera = new T.PerspectiveCamera(60,1,.032,430);
  const cockpitLayer=2;
  driverCamera.layers.set(cockpitLayer);
  const mirrorCamera = new T.PerspectiveCamera(38,3.9,.15,240);
  const mirrorTarget = new T.WebGLRenderTarget(272,70,{ depthBuffer:true });
  mirrorTarget.texture.generateMipmaps=false;
  mirrorTarget.texture.repeat.x=-1; mirrorTarget.texture.offset.x=1;
  const controls = new Controls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = .085;
  controls.enablePan = false;
  controls.rotateSpeed = .73;
  controls.zoomSpeed = .93;
  controls.minZoom = .62;
  controls.maxZoom = 2.7;
  controls.minPolarAngle = .001;
  controls.maxPolarAngle = 1.77;

  const hemi = new T.HemisphereLight(0xe4eaff, 0x65594c, 1.52);
  scene.add(hemi);
  function directional(color: number, strength: number, at: [number, number, number]) {
    const light = new T.DirectionalLight(color, strength); light.position.set(...at); scene.add(light); return light;
  }
  const key = directional(0xffeee2, 2.68, [-3.8, 7.5, 5.4]);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  Object.assign(key.shadow.camera, { left: -4.5, right: 4.5, top: 4.5, bottom: -4.5, near: 1, far: 20 });
  key.shadow.bias = -.0006;
  key.shadow.normalBias = .026;
  directional(0xe8ecff, 1.25, [5.6, 3.2, 1.7]);
  directional(0xf3f2ff, 1.55, [-1.8, 4.6, -6.7]);

  const car = model.createRallyCarModel(initial);
  scene.add(car);
  const cockpitSun=new T.DirectionalLight(0xe6edf9,.93);
  cockpitSun.position.set(.55,1.746,.738);cockpitSun.target.position.set(.47,1.168,-.193);
  cockpitSun.layers.set(cockpitLayer);car.add(cockpitSun,cockpitSun.target);
  const roofBounce=new T.PointLight(0xf3f5ff,.32,1.92,1.65);
  roofBounce.layers.set(cockpitLayer);roofBounce.position.set(.248,1.729,-.412);car.add(roofBounce);
  // From the seat only the hood, glazing and cabin can enter the view; keep the other body kits out of that draw pass.
  for(const part of ['cabin','hood','mirrors','evoHeritageDecals','classicHeritageDecals','evoRallyDecals','classicRallyDecals']) {
    car.getObjectByName(part)?.traverse(object=>object.layers.enable(cockpitLayer));
  }
  car.getObjectByName('lights')?.traverse(object=>{
    if((object as Three.PointLight).isPointLight) object.layers.enable(cockpitLayer);
  });
  const eye = car.userData.sockets.driverEye;
  const eyeRotation=new T.Quaternion(), carRotation=new T.Quaternion(), aim=new T.Vector3(), driverLocal=new T.Vector3(),
    mirrorLocal=new T.Vector3(), mirrorAim=new T.Vector3();

  const grid = new T.Mesh(new T.PlaneGeometry(60, 60), new T.ShaderMaterial({
    transparent: true, depthWrite: false,
    vertexShader: `varying vec2 p; void main() { p = position.xy; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `varying vec2 p;
      void main() {
        vec2 p1 = p * 1.24;
        vec2 footprint = max(fwidth(p1), vec2(0.0001));
        vec2 q = abs(fract(p1 - 0.5) - 0.5) / footprint;
        vec2 resolved = (1.0 - min(q, 1.0)) * (1.0 - smoothstep(0.18, 0.63, footprint));
        float fade = 1.0 - smoothstep(2.4, 10.0, length(p));
        gl_FragColor = vec4(0.61, 0.64, 0.67, max(resolved.x, resolved.y) * fade * 0.101);
      }`,
  }));
  grid.rotation.x = -Math.PI / 2; grid.position.y = -.045; grid.renderOrder = -5; scene.add(grid);
  const ground = new T.Mesh(new T.PlaneGeometry(24, 24), new T.ShadowMaterial({ opacity: .13, depthWrite: false }));
  ground.rotation.x = -Math.PI / 2; ground.position.y = -.036; ground.receiveShadow = true; ground.renderOrder = -4; scene.add(ground);

  function contactMap() {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
    const c = canvas.getContext('2d')!;
    const gradient = c.createRadialGradient(64, 64, 4, 64, 64, 64);
    gradient.addColorStop(0, 'rgba(0,0,0,.83)'); gradient.addColorStop(.48, 'rgba(0,0,0,.61)');
    gradient.addColorStop(.77, 'rgba(0,0,0,.24)'); gradient.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = gradient; c.fillRect(0, 0, 128, 128);
    return new T.CanvasTexture(canvas);
  }
  const stamp = contactMap();
  function contact(x: number, z: number, w: number, l: number, alpha: number) {
    const mesh = new T.Mesh(new T.PlaneGeometry(w, l), new T.MeshBasicMaterial({ map: stamp, transparent: true, opacity: alpha, depthWrite: false }));
    mesh.rotation.x = -Math.PI / 2; mesh.position.set(x, -.028, z); mesh.renderOrder = -3; scene.add(mesh);
  }
  contact(0, .05, 3.83, 6.37, .77);
  for (const x of [-1.038, 1.038]) for (const z of [1.665, -1.433]) contact(x, z, .88, 1.06, .70);

  const lineMaterial = new T.LineBasicMaterial({ color: 0x83858a, opacity: .22, transparent: true, depthWrite: false });
  const circlePoints = Array.from({ length: 160 }, (_, i) => {
    const a = i / 160 * TAU;
    return new T.Vector3(Math.sin(a) * 3.25, -.023, Math.cos(a) * 3.25);
  });
  const circle = new T.LineLoop(new T.BufferGeometry().setFromPoints(circlePoints), lineMaterial);
  circle.renderOrder = -2; scene.add(circle);
  const tickPoints: Three.Vector3[] = [], accentPoints: Three.Vector3[] = [];
  for (let i = 0; i < 48; i++) {
    const a = i / 48 * TAU, r = i % 12 === 0 ? 3.46 : i % 4 === 0 ? 3.38 : 3.31;
    const target = i === 3 || i === 27 ? accentPoints : tickPoints;
    target.push(new T.Vector3(Math.sin(a) * 3.27, -.022, Math.cos(a) * 3.27), new T.Vector3(Math.sin(a) * r, -.022, Math.cos(a) * r));
  }
  scene.add(new T.LineSegments(new T.BufferGeometry().setFromPoints(tickPoints), lineMaterial));
  scene.add(new T.LineSegments(new T.BufferGeometry().setFromPoints(accentPoints), new T.LineBasicMaterial({ color: 0xc08d3b, transparent: true, opacity: .67, depthWrite: false })));

  const spherical = new T.Spherical(), orbit = new T.Vector3(), up = new T.Vector3(0, 1, 0);
  function setCamera(yaw: number, polar: number, y: number, x = 0, z = .013) {
    controls.target.set(x, y, z);
    orbit.setFromSpherical(spherical.set(11, polar, yaw));
    camera.position.copy(controls.target).add(orbit);
  }
  function presetFor(id: ViewId) {
    const s1 = car.userData.build.rear === 's1';
    const view: ViewPreset = s1 && id === 'rearQuarter' ? { yaw: -2.356, polar: 1.475, y: 1.055, z: -.084, zoom: 1.06 }
      : s1 && id === 'rear' ? { yaw: Math.PI, polar: 1.518, y: 1.066, z: -.088, zoom: 1.26 } : presets[id];
    const wingAllowance = car.userData.build.wing === 'high' && id !== 'noseDetail' && id !== 'top' ? .085 : 0;
    return { ...view, y: view.y + wingAllowance };
  }
  const initialView = presetFor(initial.view);
  setCamera(initialView.yaw, initialView.polar, initialView.y, initialView.x, initialView.z);
  camera.zoom = initialView.zoom ?? 1;
  controls.update();

  let dirty = true, frameId = 0, lastTime = performance.now();
  let auto = false, autoFrom = Infinity, dragged = false, pauseUntil = 0, redrawUntil = 0;
  let speed = 0, steer = 0, tapSteer = 0, tapUntil = 0, lastReading = 0;
  let destinationZoom = camera.zoom;
  let transition: null | { start: number; yaw: number; dyaw: number; polar: number; target: Three.Vector3; zoom: number; to: ViewPreset } = null;
  const keys = new Set<GripKey>();
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let mode:ViewerMode='garage', paused=false;
  let course:ReturnType<typeof createRallyCourse> | null=null;
  let recent:Telemetry | null=null, reportAt=0, mirrorAt=0;
  let headingOffset=0, bumpCycle=0, cockpitAspect=1.8, controlGlance=0;
  let pedalKey: 'w'|'s'|null=null, pedalUntil=0, handbrakeUntil=0;

  function resize() {
    const { width, height } = host.getBoundingClientRect();
    if (!width || !height) return;
    const aspect = width / height;
    cockpitAspect=aspect;
    const overhead = width >= 550 && car.userData.build.wing === 'high' ? 1.101 : 1;
    const vertical = Math.max(3.63, (width < 550 ? 6.92 : 7.40) / aspect) * overhead;
    camera.left = -vertical * aspect / 2; camera.right = vertical * aspect / 2;
    camera.top = vertical / 2; camera.bottom = -vertical / 2;
    camera.updateProjectionMatrix();
    driverCamera.aspect=aspect;
    driverCamera.fov=T.MathUtils.lerp(74,61,T.MathUtils.smoothstep(aspect,.80,1.72));
    driverCamera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
    dirty = true;
  }
  resize();
  const observer = new ResizeObserver(resize); observer.observe(host);
  renderer.shadowMap.needsUpdate = true;

  function changeView(id: ViewId) {
    const to = presetFor(id);
    const from = spherical.setFromVector3(orbit.copy(camera.position).sub(controls.target));
    const diff = to.yaw - from.theta, dyaw = Math.atan2(Math.sin(diff), Math.cos(diff));
    destinationZoom = to.zoom ?? 1;
    transition = { start: performance.now(), yaw: from.theta, dyaw, polar: from.phi, target: controls.target.clone(), zoom: camera.zoom, to };
    dirty = true;
  }

  function cockpitPose(dt:number) {
    if(!course) return;
    const run=course.state;
    car.position.set(run.x,0,run.z);car.rotation.y=run.yaw;
    eye.getWorldPosition(driverCamera.position);eye.getWorldQuaternion(eyeRotation);
    const movement=prefersReducedMotion?0:T.MathUtils.clamp(Math.abs(run.speed)/23,0,1);
    bumpCycle+=Math.abs(run.speed)*dt;
    headingOffset=T.MathUtils.damp(headingOffset,run.steer*.075,5,dt);
    const wide=T.MathUtils.smoothstep(cockpitAspect,.84,1.68);
    const reaching=car.userData.driverAction.reach;
    controlGlance=T.MathUtils.damp(controlGlance,reaching*reaching,10,dt);
    driverLocal.set(run.steer*.011,Math.sin(bumpCycle*2.78)*movement*.006,-wide*.040).applyQuaternion(eyeRotation);
    driverCamera.position.add(driverLocal);
    driverCamera.up.set(0,1,0).applyQuaternion(eyeRotation);
    aim.set(-.025*wide+headingOffset-controlGlance*T.MathUtils.lerp(.133,.018,wide),
      T.MathUtils.lerp(-.165,-.119,wide)-controlGlance*T.MathUtils.lerp(.035,.018,wide),1).applyQuaternion(eyeRotation).add(driverCamera.position);
    driverCamera.lookAt(aim);
  }

  function publishCourse(now:number,force=false) {
    if(!course||(!force&&now<reportAt)) return;
    reportAt=now+52;
    const next=course.snapshot();
    if(force||!recent||next.time!==recent.time||next.speed!==recent.speed||next.gear!==recent.gear||next.mapX!==recent.mapX||next.mapY!==recent.mapY) {
      recent=next;callbacks.onTelemetry(next);
    }
  }

  function updateMirror(now:number) {
    if(!course||now<mirrorAt) return;
    mirrorAt=now+157;
    car.getWorldQuaternion(carRotation);
    mirrorCamera.position.copy(car.localToWorld(mirrorLocal.set(-.17,1.59,-2.91)));
    mirrorAim.set(-.055,-.039,-1).applyQuaternion(carRotation).add(mirrorCamera.position);
    mirrorCamera.lookAt(mirrorAim);
    car.visible=false;
    renderer.setRenderTarget(mirrorTarget);
    renderer.render(course.scene,mirrorCamera);
    renderer.setRenderTarget(null);
    car.visible=true;
  }

  function setMode(next:ViewerMode) {
    if(mode===next) return;
    mode=next;releaseInputs();auto=false;dragged=false;paused=false;controlGlance=0;
    transition=null; controls.enabled=next==='garage'; dirty=true;
    if(next==='cockpit') {
      if(!course) {
        course=createRallyCourse(T);
        course.scene.traverse(object=>object.layers.enable(cockpitLayer));
        callbacks.onCourse(course.route,course.startMarker);
      }
      course.scene.add(car);
      renderer.shadowMap.enabled=false;
      renderer.toneMappingExposure=1.23;
      renderer.domElement.setAttribute('aria-label','Kokpit 3D dari kursi pengemudi di Sirkuit Pinus');
      car.userData.setCockpitView(true);car.userData.setMirrorTexture(mirrorTarget.texture);
      mirrorAt=0;cockpitPose(0);publishCourse(performance.now(),true);
    } else {
      scene.add(car);car.position.set(0,0,0);car.rotation.set(0,0,0);
      car.userData.setCockpitView(false);car.userData.setMirrorTexture(null);
      renderer.shadowMap.enabled=true;renderer.shadowMap.needsUpdate=true;
      renderer.toneMappingExposure=1.13;
      renderer.domElement.setAttribute('aria-label','Model 3D interaktif coupe reli Grup B');
      speed=steer=0;publishSpeed();
    }
  }

  controls.addEventListener('change', () => { dirty = true; });
  controls.addEventListener('start', () => {
    transition = null; destinationZoom = camera.zoom; dragged = true;
    auto = false; callbacks.onManualOrbit();
  });
  controls.addEventListener('end', () => { dragged = false; pauseUntil = performance.now() + 200; destinationZoom = camera.zoom; });

  function publishSpeed() {
    const kmh = Math.round(speed * 3.6);
    if (kmh !== lastReading) { lastReading = kmh; callbacks.onSpeed(kmh); }
  }

  function frame(now: number) {
    const elapsed=Math.max(0,(now-lastTime)/1000);
    const dt = Math.min(elapsed, .075);
    lastTime = now;
    if (mode==='cockpit' && course) {
      const run=course.state, rolling=Boolean(run.speed || run.steer);
      const left=keys.has('a'), right=keys.has('d');
      const wish=left||right?Number(left)-Number(right):now<tapUntil?tapSteer:0;
      const grabbing=now<handbrakeUntil||keys.has('space'), moved=run.speed;
      if(!paused) {
        const controls={ gas:keys.has('w')||(now<pedalUntil&&pedalKey==='w'),brake:keys.has('s')||(now<pedalUntil&&pedalKey==='s'),
          steer:wish,handbrake:grabbing };
        // Substep slower renders instead of making the clock and road slow down with the canvas.
        for(let left=Math.min(elapsed,.30);left>0;) {
          const stride=Math.min(.032,left);
          course.step(stride,controls);left-=stride;
        }
        publishCourse(now);
      }
      if(!paused&&(rolling||grabbing)) redrawUntil=Math.max(redrawUntil,now+285);
      const needsFrame=dirty||(!paused&&(rolling||run.speed||run.steer||keys.size||car.userData.driverAction.mode!=='wheel'||now<redrawUntil));
      if(needsFrame) {
        if(!paused) {
          car.userData.tick(dt,{...run,displayKmh:recent?.speed});
          if(moved!==run.speed||grabbing||car.userData.driverAction.mode!=='wheel') redrawUntil=Math.max(redrawUntil,now+105);
        }
        cockpitPose(paused?0:dt);
        car.userData.updateGlow(driverCamera.position);
        if(!paused||dirty) updateMirror(now);
        renderer.render(course.scene,driverCamera);dirty=false;
      }
      frameId=requestAnimationFrame(frame);
      return;
    }
    if (transition) {
      const st = transition;
      const progress = prefersReducedMotion ? 1 : T.MathUtils.clamp((now - st.start) / 570, 0, 1);
      const t = 1 - (1 - progress) ** 3;
      setCamera(st.yaw + st.dyaw * t, T.MathUtils.lerp(st.polar, st.to.polar, t), T.MathUtils.lerp(st.target.y, st.to.y, t),
        T.MathUtils.lerp(st.target.x, st.to.x ?? 0, t), T.MathUtils.lerp(st.target.z, st.to.z ?? .013, t));
      camera.zoom = T.MathUtils.lerp(st.zoom, destinationZoom, t); camera.updateProjectionMatrix();
      if (progress === 1) transition = null;
      dirty = true;
    } else if (!dragged) {
      if (Math.abs(camera.zoom - destinationZoom) > .0005) {
        camera.zoom = prefersReducedMotion ? destinationZoom : T.MathUtils.damp(camera.zoom, destinationZoom, 13, dt);
        camera.updateProjectionMatrix(); dirty = true;
      }
      if (auto && now > Math.max(autoFrom, pauseUntil)) {
        orbit.copy(camera.position).sub(controls.target).applyAxisAngle(up, -dt * .165);
        camera.position.copy(controls.target).add(orbit); dirty = true;
      }
    }
    controls.update();

    const oldSpeed = speed, oldSteer = steer;
    const accelerator = Number(keys.has('w')) - Number(keys.has('s'));
    if (accelerator) speed = T.MathUtils.clamp(speed + dt * (accelerator > 0 ? 9.5 : -8.5), -11.1, 29.16);
    else speed *= Math.exp(-dt * .66);
    if (Math.abs(speed) < .08) speed = 0;
    const steering = Number(keys.has('a')) - Number(keys.has('d'));
    steer = T.MathUtils.damp(steer, steering || (now < tapUntil ? tapSteer : 0), 10, dt);
    if (Math.abs(steer) < .001) steer = 0;
    publishSpeed();
    const active = Boolean(speed || oldSpeed || steer || oldSteer || now < redrawUntil);
    if (active) redrawUntil = speed || steer ? now + 220 : redrawUntil;
    if (dirty || active) {
      car.userData.tick(dt, { speed, steer });
      car.userData.updateGlow(camera.position);
      renderer.render(scene, camera);
      dirty = false;
    }
    frameId = requestAnimationFrame(frame);
  }
  if(initial.mode==='cockpit') setMode('cockpit');
  frameId = requestAnimationFrame(frame);
  function releaseInputs() {keys.clear();tapUntil=0;pedalUntil=0;handbrakeUntil=0;pedalKey=null;}

  return {
    view: changeView,
    mode:setMode,
    pause(value) { paused=value;releaseInputs();dirty=true; },
    restart() {
      if(!course) return;
      course.reset();releaseInputs();paused=false;headingOffset=controlGlance=0;bumpCycle=0;mirrorAt=0;
      car.userData.resetDriver(course.state.gear);
      car.userData.tick(.06,course.state);cockpitPose(0);publishCourse(performance.now(),true);dirty=true;
    },
    zoomBy(direction) {
      destinationZoom = T.MathUtils.clamp(destinationZoom * (direction > 0 ? 1.22 : 1 / 1.22), controls.minZoom, controls.maxZoom);
      dirty = true;
    },
    turntable(enabled, wait = 0) { auto = enabled; autoFrom = performance.now() + wait; },
    configure(build) {
      const previous = car.userData.build;
      car.userData.setBuild(build);
      if (previous.nose !== build.nose || previous.wing !== build.wing || previous.rear !== build.rear) renderer.shadowMap.needsUpdate = true;
      if (previous.wing !== build.wing) resize();
      dirty = true;
    },
    headlights(enabled) { car.userData.setHeadlights(enabled); redrawUntil = Math.max(redrawUntil, performance.now() + 470); dirty = true; },
    input(input, down) {
      if (!down) { keys.delete(input); return; }
      if(paused||(input==='space'&&mode==='garage')) return;
      if (keys.has(input)) return;
      keys.add(input);
      if (mode==='garage'&&(input === 'w' || input === 's')) {
        speed = T.MathUtils.clamp(speed + (input === 'w' ? .80 : -.80), -11.1, 29.16);
        publishSpeed();
      }
      else if (input==='w'||input==='s') {
        pedalKey=input;pedalUntil=performance.now()+105;
        if(course && mode==='cockpit') {
          course.step(.062,{gas:keys.has('w'),brake:keys.has('s'),steer:Number(keys.has('a'))-Number(keys.has('d')),handbrake:keys.has('space')});
          publishCourse(performance.now(),true);
        }
      }
      else if(input==='space') {handbrakeUntil=performance.now()+262;}
      else if(input==='a'||input==='d') { tapSteer = input === 'a' ? 1 : -1; tapUntil = performance.now() + 185; }
      dirty = true;
    },
    releaseInputs,
    dispose() {
      cancelAnimationFrame(frameId); observer.disconnect(); controls.dispose();
      const freed = new Set<unknown>();
      const disposeObject=(object:Three.Object3D)=>{
        const renderable = object as Three.Mesh;
        if (renderable.geometry && !freed.has(renderable.geometry)) { renderable.geometry.dispose(); freed.add(renderable.geometry); }
        const materials = renderable.material ? (Array.isArray(renderable.material) ? renderable.material : [renderable.material]) : [];
        materials.forEach(material => {
          if (freed.has(material)) return;
          for (const value of Object.values(material)) {
            if ((value as Three.Texture | undefined)?.isTexture && !freed.has(value)) { (value as Three.Texture).dispose(); freed.add(value); }
          }
          material.dispose(); freed.add(material);
        });
        if ((object as Three.InstancedMesh).isInstancedMesh) (object as Three.InstancedMesh).dispose();
      };
      scene.traverse(disposeObject);course?.scene.traverse(disposeObject);
      mirrorTarget.dispose();key.shadow.dispose(); renderer.dispose(); renderer.domElement.remove();
    },
  };
}