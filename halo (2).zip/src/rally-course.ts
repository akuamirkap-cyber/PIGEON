import type * as Three from 'three';

export type Telemetry = {
  lap: number;
  time: number;
  best: number | null;
  last: number | null;
  speed: number;
  gear: string;
  mapX: number;
  mapY: number;
};

type Frame = { x: number; z: number; tx: number; tz: number };
type DriverInput = { gas: boolean; brake: boolean; steer: number; handbrake: boolean };

export const emptyTelemetry: Telemetry = { lap:1,time:0,best:null,last:null,speed:0,gear:'1',mapX:0,mapY:0 };

export function createRallyCourse(T: typeof Three) {
  const scene = new T.Scene();
  const layout = [
    [0,-87],[0,-59],[0,-29],[-8,-9],[-26,6],[-46,24],[-57,53],[-51,82],[-26,105],
    [7,110],[37,98],[61,74],[68,41],[59,9],[45,-21],[46,-50],[31,-77],[13,-97],[2,-103],
  ];
  const curve = new T.CatmullRomCurve3(layout.map(([x,z]) => new T.Vector3(x,0,z)),true,'centripetal');
  curve.arcLengthDivisions = 2600;
  const length = curve.getLength(), segments = 852, start = 25, roadWidth = 5.65;
  const centers = curve.getSpacedPoints(segments).slice(0,-1);
  const dif = new T.Vector3();
  const frames = centers.map((p,i) => {
    dif.subVectors(centers[(i+1)%segments],centers[(i+segments-1)%segments]).normalize();
    return { x:p.x, z:p.z, tx:dif.x, tz:dif.z };
  });
  const at = (distance: number, target: Frame): Frame => {
    const a=T.MathUtils.euclideanModulo(distance,length)/length*segments, i=Math.floor(a);
    const p=frames[i], q=frames[(i+1)%segments], f=a-i;
    target.x=T.MathUtils.lerp(p.x,q.x,f); target.z=T.MathUtils.lerp(p.z,q.z,f);
    target.tx=T.MathUtils.lerp(p.tx,q.tx,f); target.tz=T.MathUtils.lerp(p.tz,q.tz,f);
    return target;
  };
  const movingFrame = { x:0,z:0,tx:0,tz:1 }, nextFrame = { ...movingFrame };
  const mx=Math.min(...centers.map(p=>p.x)), mz=Math.min(...centers.map(p=>p.z));
  const scale=77/Math.max(Math.max(...centers.map(p=>p.x))-mx,Math.max(...centers.map(p=>p.z))-mz);
  const mapOffset=(100-(Math.max(...centers.map(p=>p.x))-mx)*scale)/2;
  const toMapX=(x:number)=>100-mapOffset-(x-mx)*scale;
  const toMapY=(z:number)=>89-(z-mz)*scale;
  const route=`M${centers.filter((_,i)=>i%9===0).map(p=>`${toMapX(p.x).toFixed(2)},${toMapY(p.z).toFixed(2)}`).join(' ')}Z`;
  const origin = at(start, { ...movingFrame });
  const startMarker = { x:toMapX(origin.x), y:toMapY(origin.z) };

  let seed=77423;
  const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  const standard=(color:number, params:Three.MeshStandardMaterialParameters={}) => new T.MeshStandardMaterial({ color, flatShading:true, roughness:.94, ...params });
  const land=standard(0x669255);
  const ground=new T.Mesh(new T.PlaneGeometry(540,540),land);
  ground.rotation.x=-Math.PI/2; ground.position.y=-.081; scene.add(ground);
  scene.fog=new T.Fog(0xb3c7db,74,218);
  const sky = new T.Mesh(new T.SphereGeometry(370,35,18), new T.ShaderMaterial({
    side:T.BackSide, depthWrite:false, toneMapped:false,
    uniforms:{ lower:{value:new T.Color(0xc5d9ea)}, upper:{value:new T.Color(0x76acd9)} },
    vertexShader:`varying vec3 direction; void main(){ direction=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
    fragmentShader:`varying vec3 direction; uniform vec3 lower; uniform vec3 upper;
      void main(){ vec3 ray=normalize(direction); float gradient=pow(clamp(ray.y*2.36+.215,0.,1.),.56);
      float sun=pow(max(dot(ray,normalize(vec3(.46,.43,.82))),0.0),15.0)*.12;
      gl_FragColor=vec4(mix(lower,upper,gradient)+sun*vec3(1.0,.79,.52),1.);
      #include <colorspace_fragment>
      }`,
  }));
  sky.name='Pine Circuit daylight'; sky.renderOrder=-30; scene.add(sky);
  scene.add(new T.HemisphereLight(0xe4f2ff,0x879a8b,2.06));
  const sun=new T.DirectionalLight(0xfff1dc,2.14); sun.position.set(-18,38,22); scene.add(sun);
  const blueFill=new T.DirectionalLight(0xb7d5ff,.50); blueFill.position.set(25,12,-20); scene.add(blueFill);
  const trackPaint=standard(0xffffff,{vertexColors:true,side:T.DoubleSide});

  type Rail = [offset: number, height: number];
  const railsPoint=(point:Frame,rail:Rail)=>[point.x+point.tz*rail[0],rail[1],point.z-point.tx*rail[0]];
  function ribbon(name: string, rails: Rail[], color: (segment:number, band:number)=>Three.Color) {
    const points:number[]=[], colors:number[]=[];
    for(let i=0;i<segments;i++) for(let j=0;j<rails.length-1;j++) {
      const a=frames[i], b=frames[(i+1)%segments], r=rails[j], s=rails[j+1];
      const p=railsPoint(a,r),q=railsPoint(b,r),u=railsPoint(b,s),v=railsPoint(a,s);
      points.push(...p,...u,...q,...p,...v,...u);
      const c=color(i,j);
      for(let k=0;k<6;k++) colors.push(c.r,c.g,c.b);
    }
    const geometry=new T.BufferGeometry();
    geometry.setAttribute('position',new T.Float32BufferAttribute(points,3));
    geometry.setAttribute('color',new T.Float32BufferAttribute(colors,3)); geometry.computeVertexNormals();
    const mesh=new T.Mesh(geometry,trackPaint); mesh.name=name; scene.add(mesh);
  }
  const asphalt=new T.Color(0x383d47), tar=new T.Color(0x404650), variation=asphalt.clone();
  ribbon('Closed forest course',[[-roadWidth,-.017],[-3.1,-.012],[-.38,-.010],[2.4,-.009],[roadWidth,-.017]],(i,j)=>{
    return variation.copy(asphalt).lerp(tar,.27*([.64,.27,.18,.46][j])+.32*(Math.sin(i*.19)*.5+.5)+random()*.087);
  });
  const border=new T.Color(0xe1e9f5), curbs=[new T.Color(0xf2c15c),new T.Color(0xeee9e6),new T.Color(0xe8785b)];
  const wallTones=[0x657189,0x9da9bc,0xc0cadc,0xe1e5e9,0xb3bdcb,0x8595a1].map(h=>new T.Color(h));
  const curbLip=new T.Color(0x707c87), dry=new T.Color(0x9fa985), grass=new T.Color(0x77a269);
  for(const sign of [-1,1]) {
    const signed=(k:number,y:number):Rail=>[sign*k,y];
    ribbon(`Painted verge ${sign}`,[signed(5.38,-.003),signed(5.48,-.003)],()=>border);
    ribbon(`Raised rumble strip ${sign}`,[signed(5.53,-.008),signed(5.73,.031),signed(6.03,.051),signed(6.09,-.01)],(i,j)=>{
      const time=i/segments*length;
      if(j===2) return curbLip;
      return curbs[Math.floor(time/1.58)%2===0?1:((time>49&&time<101)||(time>175&&time<244))?0:2];
    });
    ribbon(`Concrete wall ${sign}`,[signed(6.19,-.05),signed(6.20,.12),signed(6.31,.22),signed(6.41,.724),signed(6.54,.768),signed(6.73,.768),signed(6.82,-.035)],(i,j)=>{
      const c=wallTones[j];
      return variation.copy(c).multiplyScalar(i%9===0?.87:.964+.045*Math.sin(i*.81)*Math.sin(i*.81));
    });
    ribbon(`Pine verge ${sign}`,[signed(6.11,-.071),signed(7.18,-.07),signed(8.64,-.075),signed(11.2,-.076)],(i,j)=>{
      return variation.copy(grass).lerp(dry,(j===0?.81:j===1?.52:.17)+.08*Math.sin(i*.14));
    });
  }

  const markPoints:number[]=[], startFrame=at(start-3.6,{...movingFrame});
  for(let row=0;row<2;row++) for(let col=0;col<16;col++) if((row+col)%2===0) {
    const right=5.44-col*.68,left=right-.68;
    const point=(u:number,v:number)=>[startFrame.x+startFrame.tz*u+startFrame.tx*v,.006,startFrame.z-startFrame.tx*u+startFrame.tz*v];
    const a=point(left,row*.36), b=point(right,row*.36), c=point(right,(row+1)*.36), d=point(left,(row+1)*.36);
    markPoints.push(...a,...b,...c,...a,...c,...d);
  }
  const startGeo=new T.BufferGeometry(); startGeo.setAttribute('position',new T.Float32BufferAttribute(markPoints,3)); startGeo.computeVertexNormals();
  scene.add(new T.Mesh(startGeo,standard(0xe2ddd2,{side:T.DoubleSide})));

  const ridgeTones=[0xb4c5d4,0xa7bfcc,0x9bb8c5];
  for(let ring=0;ring<3;ring++) {
    const pts:number[]=[], count=96, radius=199-ring*24;
    const hill=(angle:number)=>[Math.sin(angle)*radius, 6+Math.pow(Math.max(0,.54+.29*Math.sin(angle*3+ring)+.21*Math.cos(angle*7+ring*1.5)),1.4)*
      (ring===0?44:ring===1?33:20)+random()*2.5,Math.cos(angle)*radius+28];
    const row=Array.from({length:count},(_,i)=>hill(i/count*Math.PI*2));
    for(let i=0;i<count;i++) {
      const p=row[i],q=row[(i+1)%count],a=[p[0],-.1,p[2]],b=[q[0],-.1,q[2]];pts.push(...a,...p,...q,...a,...q,...b);
    }
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pts,3));geo.computeVertexNormals();
    scene.add(new T.Mesh(geo,new T.MeshBasicMaterial({ color:ridgeTones[ring],side:T.DoubleSide,toneMapped:false,fog:false })));
  }

  const prop=new T.Object3D(), colour=new T.Color();
  type Tree = { x:number; z:number; h:number; w:number; yaw:number; hue:number };
  const trees:Tree[]=[];
  function pine(x:number,z:number,h:number) {
    trees.push({x,z,h,w:.76+random()*.47,yaw:random()*Math.PI,hue:Math.floor(random()*8)});
  }
  for(const side of [-1,1]) for(let i=0;i<segments;i+=11) {
    const p=frames[(i+Math.floor(random()*8))%segments], offset=side*(8.5+random()*6.5);
    pine(p.x+p.tz*offset,p.z-p.tx*offset,3.8+random()*5.2);
    if(i%22===0) {
      const width=offset+side*(5.2+random()*7.7);
      pine(p.x+p.tz*width-p.tx*2.7,p.z-p.tx*width-p.tz*2.7,4.8+random()*4.5);
    }
  }
  for(let i=0;i<490;i++) {
    const x=(random()-.5)*355,z=(random()-.48)*350;
    let free=true;
    for(let j=0;j<segments;j+=4) {
      const p=frames[j];
      if((x-p.x)**2+(z-p.z)**2<14.5**2) {free=false;break;}
    }
    if(free) pine(x,z,3.2+random()*7.2);
  }
  const bark=standard(0xffffff), needles=standard(0xffffff);
  const trunks=new T.InstancedMesh(new T.CylinderGeometry(.51,1,1,5),bark,trees.length);
  const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=64;
  const shadowInk=shadowCanvas.getContext('2d')!;
  const contactShade=shadowInk.createRadialGradient(32,32,1,32,32,31);
  contactShade.addColorStop(0,'#142f1869');contactShade.addColorStop(.57,'#1a382333');contactShade.addColorStop(1,'#162d1700');
  shadowInk.fillStyle=contactShade;shadowInk.fillRect(0,0,64,64);
  const treeShadowMap=new T.CanvasTexture(shadowCanvas);treeShadowMap.colorSpace=T.SRGBColorSpace;
  const shadowGeo=new T.PlaneGeometry(1,1);shadowGeo.rotateX(-Math.PI/2);
  const treeContact=new T.InstancedMesh(shadowGeo,new T.MeshBasicMaterial({map:treeShadowMap,transparent:true,depthWrite:false,opacity:.74}),trees.length);
  const pineColors=[0x1c735b,0x348966,0x4a8c4a,0x559747,0x278e68,0x469759,0x6ea14d,0x247d62];
  const crowns=[new T.InstancedMesh(new T.CylinderGeometry(.095,1,1,7,1),needles,trees.length),
    new T.InstancedMesh(new T.CylinderGeometry(.064,1,1,6,1),needles,trees.length),
    new T.InstancedMesh(new T.ConeGeometry(1,1,6),needles,trees.length)];
  for(const [i,{x,z,h,w,yaw,hue}] of trees.entries()) {
    prop.position.set(x+.10*h,-.064,z-.095*h);prop.scale.set(h*.51,1,h*.64);prop.rotation.set(0,-.42,0);prop.updateMatrix();
    treeContact.setMatrixAt(i,prop.matrix);
    prop.position.set(x,h*.188-.03,z);prop.scale.set(h*.031,h*.40,h*.029);prop.rotation.set(0,yaw,0);prop.updateMatrix();
    trunks.setMatrixAt(i,prop.matrix);trunks.setColorAt(i,colour.setHex(i%2?0xaf8059:0x947057));
    for(let j=0;j<3;j++) {
      const r=h*[.216,.171,.116][j]*w;
      prop.position.set(x+.055*j,h*[.442,.625,.800][j],z-.021*j);
      prop.scale.set(r,h*[.403,.394,.394][j],r*w*.92);
      prop.rotation.set(.014*Math.sin(i),yaw+j*.471,.016*Math.cos(i));prop.updateMatrix();
      const mesh=crowns[j]; mesh.setMatrixAt(i,prop.matrix);
      mesh.setColorAt(i,colour.setHex(pineColors[hue]).multiplyScalar(.90+.075*j+.15*random()));
    }
  }
  for(const item of [treeContact,trunks,...crowns]) {item.instanceMatrix.needsUpdate=true; if(item.instanceColor)item.instanceColor.needsUpdate=true; scene.add(item);}
  trunks.name='Instanced cedar trunks'; crowns[0].name='Instanced low-poly conifers';

  const cloudShape=new T.IcosahedronGeometry(1,1), clouds=standard(0xf4f6f8,{roughness:1,fog:false,emissive:0xc8d3dc,emissiveIntensity:.32});
  const cloudPuffs=new T.InstancedMesh(cloudShape,clouds,42);
  for(let i=0;i<42;i++) {
    const a=Math.floor(i/6)*.92+.21,j=i%6;
    prop.position.set(Math.sin(a)*153+(j-2.6)*7.6,30+Math.floor(i/6)%3*6+random()*4,Math.cos(a)*147+12+random()*7);
    prop.scale.set(7.1+random()*5.2,1.5+random()*2,4+random()*3.5); prop.rotation.set(.11,random()*2,0);prop.updateMatrix();cloudPuffs.setMatrixAt(i,prop.matrix);
  }
  scene.add(cloudPuffs);

  const signCanvas=document.createElement('canvas');signCanvas.width=512;signCanvas.height=128;
  const signInk=signCanvas.getContext('2d')!;
  signInk.fillStyle='#252927';signInk.fillRect(0,0,512,128);
  signInk.fillStyle='#f6c165';signInk.fillRect(6,6,500,116);
  signInk.fillStyle='#252621';
  for(let x=42;x<460;x+=106) {
    signInk.beginPath(); signInk.moveTo(x,19);signInk.lineTo(x+33,19);signInk.lineTo(x+69,64);signInk.lineTo(x+33,109);
    signInk.lineTo(x,109);signInk.lineTo(x+34,64);signInk.closePath();signInk.fill();
  }
  const signMap=new T.CanvasTexture(signCanvas); signMap.colorSpace=T.SRGBColorSpace;
  const signFace=standard(0xffffff,{map:signMap,roughness:.74,emissive:0x584625,emissiveIntensity:.12});
  const pole=standard(0xadb3ae,{metalness:.10}), plate=standard(0x4f565a), lamp=standard(0xdcddcb,{emissive:0xeee3af,emissiveIntensity:.14});
  function part(parent:Three.Object3D,geometry:Three.BufferGeometry,mat:Three.Material,x:number,y:number,z:number) {
    const obj=new T.Mesh(geometry,mat);obj.position.set(x,y,z);parent.add(obj);return obj;
  }
  const tallTube=new T.CylinderGeometry(.044,.072,5.35,7), lampCase=new T.BoxGeometry(.49,.25,.31), lampLens=new T.BoxGeometry(.387,.158,.035);
  for(const [i,s] of [start+12,start+35,start+49,109,168,234,298,362].entries()) {
    const f=at(s,{...movingFrame}), side=i<2?(i===0?1:-1):i%2===0?1:-1, u=side*7.74;
    const stand=new T.Group();stand.position.set(f.x+f.tz*u,-.05,f.z-f.tx*u);stand.rotation.y=Math.atan2(f.tx,f.tz)+Math.PI*.81;scene.add(stand);
    part(stand,tallTube,pole,0,2.67,0);
    part(stand,new T.BoxGeometry(1.04,.064,.066),pole,0,5.1,0);
    for(const x of [-.293,.293]) {
      part(stand,lampCase,plate,x,5.14,0).rotation.x=.29;
      part(stand,lampLens,lamp,x,5.18,.15).rotation.x=.29;
    }
  }
  const signBack=new T.BoxGeometry(3.1,.72,.048), signFront=new T.PlaneGeometry(3.03,.681), signPole=new T.BoxGeometry(.056,1.6,.062);
  for(const [i,s] of [start+32,start+43,151,246,365].entries()) {
    const f=at(s,{...movingFrame}), d=(i%3===2?-1:1)*6.88, p=new T.Group();
    p.position.set(f.x+f.tz*d,0,f.z-f.tx*d);p.rotation.y=Math.atan2(-f.tx,-f.tz)+.18*Math.sign(d);scene.add(p);
    part(p,signBack,plate,0,1.48,0);part(p,signFront,signFace,0,1.48,.028);
    for(const x of [-.97,.97])part(p,signPole,pole,x,.80,-.040);
  }

  const state = { speed:0, steer:0, lateral:0, yaw:0, x:origin.x,z:origin.z,lap:1,time:0,best:null as number|null,last:null as number|null,
    gear:'1',rev:.22, handbrake:false,serviceBrake:false,steerIntent:0,mapX:startMarker.x,mapY:startMarker.y };
  const upshift=[0,7.5,14,20,26], downshift=[0,0,6.25,12.3,17.9,23.6];
  let travel=0,lane=0,yawError=0,lateralRate=0,started=false,driveGear=1,shiftLock=0,torqueDip=0;
  function position() {
    const f=at(start+travel,movingFrame);
    state.x=f.x+f.tz*lane;state.z=f.z-f.tx*lane;
    state.yaw=Math.atan2(f.tx,f.tz)+yawError;state.lateral=lane;
    state.mapX=toMapX(state.x);state.mapY=toMapY(state.z);
  }
  function reset() {
    travel=0;lane=0;yawError=0;lateralRate=0;started=false;driveGear=1;shiftLock=torqueDip=0;
    Object.assign(state,{speed:0,steer:0,lap:1,time:0,gear:'1',rev:.22,handbrake:false,serviceBrake:false,steerIntent:0});
    position();
  }
  function step(dt:number,input:DriverInput) {
    const { damp, clamp }=T.MathUtils;
    let speed=state.speed;
    const wasMovingForward=speed>.18;
    shiftLock=Math.max(0,shiftLock-dt);torqueDip=Math.max(0,torqueDip-dt);
    const normalised=Math.min(1,Math.abs(speed)/31.7);
    if(input.handbrake) speed=damp(speed,0,8.5,dt);
    else if(input.gas&&!input.brake) speed=Math.min(31.7,speed+(speed<-.15?16:9.6*(1-.56*normalised))*(torqueDip>0?.62:1)*dt);
    else if(input.brake&&!input.gas) speed=Math.max(-8.8,speed-(speed>.12?15.8:5.3)*dt);
    else speed=damp(speed,0,.47,dt);
    if(Math.abs(speed)<.068) speed=0;

    const f=at(start+travel,movingFrame), n=at(start+travel+3.6,nextFrame);
    const bank=Math.atan2(n.tx*f.tz-n.tz*f.tx,n.tx*f.tx+n.tz*f.tz);
    const speedSign=speed<0?-1:1, steer=clamp(input.steer,-1,1);
    const authority=(.23+.21*normalised)*(input.handbrake?1.48:1);
    yawError=damp(yawError,steer*authority*speedSign*Math.min(Math.abs(speed)/4,1),3.55,dt);
    lateralRate=damp(lateralRate,Math.sin(yawError)*speed,5,dt);
    lane+=lateralRate*dt;
    if(Math.abs(lane)>4.58) {
      lane=4.58*Math.sign(lane);
      if(Math.sign(steer)===Math.sign(lane)) speed=damp(speed,1.9*speedSign,4.5,dt);
      lateralRate*=.30; yawError*=.92;
    }
    travel+=speed*Math.cos(yawError)*dt;
    state.speed=speed;
    state.steer=damp(state.steer,clamp(steer*.94+clamp(bank*2.3,-.36,.36)*Math.min(Math.abs(speed)/6,1),-1,1),12,dt);
    if(Math.abs(state.steer)<.0014) state.steer=0;
    if(Math.abs(yawError)<.00035) yawError=0;
    if(Math.abs(lateralRate)<.0005) lateralRate=0;
    state.handbrake=input.handbrake;
    state.serviceBrake=input.brake&&!input.gas&&(wasMovingForward||speed>.18);
    state.steerIntent=steer;
    if(Math.abs(speed)>.21) started=true;
    if(started) state.time+=dt;
    if(travel>=state.lap*length) {
      state.last=state.time;
      state.best=state.best===null?state.time:Math.min(state.best,state.time);
      state.lap++;state.time=0;
    }
    const v=Math.abs(speed), oldGear=driveGear;
    if(speed<-.30||v<1.20) driveGear=1;
    else if(shiftLock===0) {
      if(driveGear<5&&v>=upshift[driveGear]) driveGear++;
      else if(driveGear>1&&v<downshift[driveGear]) driveGear--;
    }
    if(oldGear!==driveGear) {shiftLock=.32;torqueDip=.17;}
    state.gear=speed<-.30?'R':String(driveGear);
    const lower=[0,0,6.3,12.9,18,24][driveGear];
    state.rev=damp(state.rev,clamp(.20+(v-lower)*.105+(input.gas?.105:0)-(torqueDip>0?.11:0),.17,.985),7,dt);
    position();
  }
  position();
  const snapshot=():Telemetry=>({lap:state.lap,time:state.time,best:state.best,last:state.last,speed:Math.round(Math.abs(state.speed)*3.6),gear:state.gear,mapX:state.mapX,mapY:state.mapY});
  return { scene, route, startMarker, length, state, step, reset, snapshot };
}