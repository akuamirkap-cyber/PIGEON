export type RallyBuild = {
  nose: 'evo' | 'classic';
  rear: 's1' | 'standard';
  wing: 'works' | 'high';
  vinyl: 'heritage' | 'rally';
  theme: 'black' | 'blue' | 'green';
};

export const defaultBuild: RallyBuild = { nose: 'evo', rear: 's1', wing: 'works', vinyl: 'heritage', theme: 'black' };
const storageKey = 'rally-lab.garage.v2';

export const themes: { id: RallyBuild['theme']; name: string; label: string; accent: string }[] = [
  { id: 'black', name: 'Hitam', label: 'Hitam, merah, dan putih', accent: '#24252c' },
  { id: 'blue', name: 'Biru', label: 'Biru, merah, dan putih', accent: '#2457a6' },
  { id: 'green', name: 'Hijau', label: 'Hijau, merah, dan putih', accent: '#278058' },
];

export function readBuild(): RallyBuild {
  try {
    const saved: Partial<RallyBuild> | null = JSON.parse(localStorage.getItem(storageKey) ?? 'null');
    if (saved) return {
      nose: saved.nose === 'classic' ? 'classic' : 'evo',
      rear: saved.rear === 'standard' ? 'standard' : 's1',
      wing: saved.wing === 'high' ? 'high' : 'works',
      vinyl: saved.vinyl === 'rally' ? 'rally' : 'heritage',
      theme: saved.theme === 'blue' || saved.theme === 'green' ? saved.theme : 'black',
    };
  } catch { /* Storage can be unavailable when the HTML is opened directly. */ }
  return { ...defaultBuild };
}

export function writeBuild(build: RallyBuild) {
  try { localStorage.setItem(storageKey, JSON.stringify(build)); } catch { /* Still usable without persistence. */ }
}