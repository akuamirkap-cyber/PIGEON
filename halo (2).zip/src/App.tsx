import { useEffect, useRef, useState } from 'react';
import type { PointerEvent, ReactNode } from 'react';
import { BuildPanel } from './BuildPanel';
import { CockpitHud } from './CockpitHud';
import { defaultBuild, readBuild, writeBuild } from './rally-config';
import type { RallyBuild } from './rally-config';
import { createStudio, modelSource } from './rally-studio';
import type { GripKey, Studio, ViewId, ViewerMode } from './rally-studio';
import { emptyTelemetry } from './rally-course';

type CameraButton = Exclude<ViewId, 'rearQuarter' | 'rearDetail' | 'noseDetail'>;
type IconName = CameraButton | 'play' | 'pause' | 'full' | 'minimize' | 'plus' | 'minus' | 'reset' | 'mouse' | 'lamp' | 'code' | 'close' | 'copy' | 'check' | 'focus' | 'wheel';

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const shapes: Record<IconName, ReactNode> = {
    threeQuarter: <><path d="m12 3 8 4.6v8.8L12 21l-8-4.6V7.6L12 3Z"/><path d="m4.2 7.8 7.8 4.6 7.8-4.6M12 12.5V21m-4-15.7 8 4.6"/></>,
    front: <><path d="M4 11.2 5.9 6h12.2l1.9 5.2M3 15.8v-3.2l1.3-1.4h15.4l1.3 1.4v3.2l-1.5 1.5h-15L3 15.8Zm2 1.7V19m14-1.5V19M6 14h2.3m7.4 0H18"/></>,
    rear: <><path d="M4.1 11.1 5.3 7h13.4l1.2 4.1M4 11h16a1 1 0 0 1 1 1v4.1l-1.2 1.1H4.2L3 16.1V12a1 1 0 0 1 1-1Zm1.6-6h12.8M7 5v2m10-2v2M6 13.8h2.3m7.4 0H18m-7.4 2.1h2.8M5 17.5V19m14-1.5V19"/></>,
    left: <><path d="M2.8 16v-3l3-1 3-3.2h6.9l3 3.2 2.4 1v3h-2.2m-3.4 0h-7m-3.6 0H2.8"/><circle cx="6.5" cy="16" r="1.75"/><circle cx="17.2" cy="16" r="1.75"/><path d="M10.5 9V12m1.3 0h4.6"/></>,
    right: <g transform="matrix(-1 0 0 1 24 0)"><path d="M2.8 16v-3l3-1 3-3.2h6.9l3 3.2 2.4 1v3h-2.2m-3.4 0h-7m-3.6 0H2.8"/><circle cx="6.5" cy="16" r="1.75"/><circle cx="17.2" cy="16" r="1.75"/><path d="M10.5 9V12m1.3 0h4.6"/></g>,
    top: <><rect x="7" y="3" width="10" height="18" rx="2.5"/><path d="m7.5 9 2-2h5l2 2M8.5 9v6m7-6v6m-8 0 2 2h5l2-2M7 9H5.2M17 9h1.8"/></>,
    play: <path d="m9 5 11 7-11 7V5Z" fill="currentColor" strokeLinejoin="round"/>,
    pause: <><path d="M9 6v12m6-12v12" strokeWidth="2.5"/></>,
    full: <path d="M9 4H4v5m11-5h5v5M4 15v5h5m11-5v5h-5"/>,
    minimize: <path d="M4 9h5V4m11 5h-5V4m-6 16v-5H4m11 5v-5h5"/>,
    plus: <path d="M5 12h14m-7-7v14"/>,
    minus: <path d="M5 12h14"/>,
    reset: <><path d="M5.2 9a7 7 0 1 1 .8 7.5M5.2 4.5V9h4.5"/></>,
    mouse: <><rect x="6.5" y="3" width="11" height="18" rx="5.5"/><path d="M12 7v3"/></>,
    lamp: <><path d="M12.4 5.6h2.8a5.9 5.9 0 1 1 0 11.8h-2.8V5.6ZM4 6.5h4m-5 4h5m-5 4h5m-4 4h4"/></>,
    code: <><path d="m8 7-5 5 5 5m8-10 5 5-5 5m-2.2-13-3.6 16"/></>,
    close: <path d="m6 6 12 12M18 6 6 18"/>,
    copy: <><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 5V4H4v12h1"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    focus: <><path d="M9 4H4v5m11-5h5v5M4 15v5h5m11-5v5h-5"/><circle cx="12" cy="12" r="3.3"/></>,
    wheel: <><circle cx="12" cy="12" r="8.4"/><circle cx="12" cy="12" r="2.25"/><path d="m4 11 5.7.8m4.6 0 5.7-.8m-8 3.6v5.5"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{shapes[name]}</svg>;
}

const views: { id: CameraButton; label: string; name: string }[] = [
  { id: 'threeQuarter', label: 'Sudut 3/4', name: 'Sudut 3/4' },
  { id: 'front', label: 'Depan', name: 'Tampak depan' },
  { id: 'rear', label: 'Belakang', name: 'Tampak belakang' },
  { id: 'left', label: 'Kiri', name: 'Tampak kiri' },
  { id: 'right', label: 'Kanan', name: 'Tampak kanan' },
  { id: 'top', label: 'Atas', name: 'Tampak atas' },
];

const driveNames: Record<GripKey, string> = { w: 'Gas', s: 'Rem atau mundur', a: 'Belok kiri', d: 'Belok kanan', space: 'Rem tangan' };

function fromKey(event:KeyboardEvent, cockpit:boolean):GripKey | null {
  const key=event.key.toLowerCase();
  if(key==='w'||key==='a'||key==='s'||key==='d') return key;
  if(cockpit) {
    if(event.code==='Space'||key===' ') return 'space';
    if(key==='arrowup') return 'w';
    if(key==='arrowleft') return 'a';
    if(key==='arrowdown') return 's';
    if(key==='arrowright') return 'd';
  }
  return null;
}

export default function App() {
  const viewport = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const sourceDialog = useRef<HTMLDialogElement>(null);
  const studio = useRef<Studio | undefined>(undefined);
  const [build, setBuild] = useState(readBuild);
  const buildState = useRef(build);
  const [mode, setMode] = useState<ViewerMode>('cockpit');
  const modeState = useRef(mode);
  const isCockpit = mode==='cockpit';
  const [paused, setPaused] = useState(false);
  const pauseState = useRef(false);
  const [telemetry, setTelemetry] = useState(emptyTelemetry);
  const [route, setRoute] = useState({ path:'', start:{x:0,y:0} });
  const entryView = build.rear === 's1' ? 'rearQuarter' : 'threeQuarter';
  const [view, setView] = useState<ViewId | null>(entryView);
  const viewState = useRef<ViewId>(entryView);
  const [turning, setTurning] = useState(() => build.rear !== 's1' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const turnState = useRef(turning);
  const [headlights, setHeadlights] = useState(false);
  const lightState = useRef(false);
  const [speed, setSpeed] = useState(0);
  const [pressed, setPressed] = useState<GripKey[]>([]);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');
  const [expanded, setExpanded] = useState(false);
  const expandedState = useRef(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [source, setSource] = useState('');
  const inspectRear = view === 'rear' || view === 'rearQuarter' || view === 'rearDetail';
  const inspectLabel = inspectRear ? 'Detail belakang' : 'Detail depan';

  function toggleTurntable() {
    const next = !turnState.current;
    if (next && viewState.current === 'noseDetail') chooseView('threeQuarter');
    if (next && viewState.current === 'rearDetail') chooseView('rearQuarter');
    turnState.current = next; setTurning(next); studio.current?.turntable(next);
  }

  function chooseView(id: ViewId) {
    turnState.current = false; viewState.current = id; setTurning(false); setView(id);
    studio.current?.turntable(false); studio.current?.view(id);
  }

  function switchMode(next:ViewerMode) {
    if (modeState.current===next) return;
    releaseKeys();
    pauseState.current=false;setPaused(false);
    modeState.current=next;setMode(next);
    studio.current?.mode(next);
    if(next==='garage') {
      studio.current?.view(viewState.current);
      studio.current?.turntable(turnState.current,1800);
    }
  }

  function togglePause() {
    const next=!pauseState.current;
    pauseState.current=next;setPaused(next);
    releaseKeys();studio.current?.pause(next);
  }

  function restartRun() {
    pauseState.current=false;setPaused(false);
    releaseKeys();studio.current?.restart();
  }

  function applyBuild(next: RallyBuild) {
    buildState.current = next;
    setBuild(next); writeBuild(next); studio.current?.configure(next);
  }

  function selectPart<K extends keyof RallyBuild>(part: K, value: RallyBuild[K]) {
    if (buildState.current[part] !== value) applyBuild({ ...buildState.current, [part]: value });
    if (part === 'wing') chooseView('rearQuarter');
    else if (part === 'rear') chooseView(view === 'rear' || view === 'rearDetail' ? view : 'rearQuarter');
    else if (part === 'nose') {
      const showDetail = value === 'evo' || view === 'noseDetail';
      chooseView(view === 'front' ? 'front' : showDetail ? 'noseDetail' : 'threeQuarter');
    }
  }

  function resetBuild() { applyBuild({ ...defaultBuild }); chooseView('rearQuarter'); }
  function inspectPart() {
    if(inspectRear) chooseView(view === 'rearDetail' ? 'rearQuarter' : 'rearDetail');
    else chooseView(view === 'noseDetail' ? 'threeQuarter' : 'noseDetail');
  }
  function previewBuild() {
    stage.current?.scrollIntoView({ block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  }

  function toggleHeadlights() {
    const next = !lightState.current;
    lightState.current = next; setHeadlights(next); studio.current?.headlights(next);
  }

  function drive(key: GripKey, down: boolean) {
    if(down&&modeState.current==='cockpit'&&pauseState.current) return;
    studio.current?.input(key, down);
    setPressed(prev => down ? (prev.includes(key) ? prev : [...prev, key]) : prev.filter(input => input !== key));
  }

  function releaseKeys() {
    studio.current?.releaseInputs(); setPressed([]);
  }

  useEffect(() => {
    if (!viewport.current) return;
    const abort = new AbortController();
    createStudio(viewport.current, {
      onManualOrbit: () => { turnState.current = false; setTurning(false); setView(null); },
      onSpeed: setSpeed,
      onTelemetry: setTelemetry,
      onCourse: (path,start)=>setRoute({path,start}),
    }, abort.signal, { build: buildState.current, headlights: lightState.current, view: viewState.current, mode: modeState.current }).then(instance => {
      if (!instance) return;
      if (abort.signal.aborted) { instance.dispose(); return; }
      studio.current = instance;
      instance.configure(buildState.current);
      instance.mode(modeState.current);
      if(modeState.current==='garage') {
        studio.current.view(viewState.current);
        studio.current.turntable(turnState.current, 5200);
      } else if(pauseState.current) instance.pause(true);
      studio.current.headlights(lightState.current);
      setReady(true);
    }).catch((reason: unknown) => {
      if (abort.signal.aborted) return;
      console.error(reason);
      setError('Viewer 3D tidak bisa dimulai. Aktifkan WebGL, lalu muat ulang halaman.');
    });

    function keyDown(event: KeyboardEvent) {
      const node = event.target as HTMLElement | null;
      if (sourceDialog.current?.open || event.ctrlKey || event.metaKey || event.altKey || node?.matches('input, textarea, [contenteditable]')) return;
      const key = event.key.toLowerCase();
      const cockpit=modeState.current==='cockpit', used=fromKey(event,cockpit);
      if(used && !(used==='space'&&pauseState.current&&node?.closest('button:not(.keycap)'))) {
        event.preventDefault(); if (!event.repeat) drive(used,true);
      }
      if (event.repeat) return;
      if (key === 'l') toggleHeadlights();
      if (key === 'c') switchMode(cockpit?'garage':'cockpit');
      if (key === 't' && !cockpit) toggleTurntable();
      if (key === 'r') cockpit?restartRun():chooseView('threeQuarter');
      if (key === 'escape') {
        if(expandedState.current) { expandedState.current=false;setExpanded(false); }
        else if(cockpit&&!document.fullscreenElement) togglePause();
      }
    }
    function keyUp(event: KeyboardEvent) {
      const key=fromKey(event,true);
      if(key) drive(key,false);
    }
    function fullscreenChanged() { setIsFullscreen(document.fullscreenElement === stage.current); }
    function visibilityChanged() { if (document.hidden) releaseKeys(); }
    window.addEventListener('keydown', keyDown); window.addEventListener('keyup', keyUp); window.addEventListener('blur', releaseKeys);
    document.addEventListener('fullscreenchange', fullscreenChanged); document.addEventListener('visibilitychange', visibilityChanged);
    return () => {
      abort.abort(); studio.current?.dispose(); studio.current = undefined;
      window.removeEventListener('keydown', keyDown); window.removeEventListener('keyup', keyUp); window.removeEventListener('blur', releaseKeys);
      document.removeEventListener('fullscreenchange', fullscreenChanged); document.removeEventListener('visibilitychange', visibilityChanged);
    };
  }, []);

  async function toggleFullscreen() {
    if (expanded) { expandedState.current = false; setExpanded(false); return; }
    if (document.fullscreenElement === stage.current) { await document.exitFullscreen(); return; }
    try {
      if (!stage.current?.requestFullscreen) throw new Error('Fullscreen unavailable');
      await stage.current.requestFullscreen();
    } catch {
      expandedState.current = true; setExpanded(true);
    }
  }

  function openSource() {
    setSource(modelSource()); setCopied(false); releaseKeys(); sourceDialog.current?.showModal();
  }

  async function copySource() {
    try {
      await navigator.clipboard.writeText(source);
    } catch {
      const input = document.createElement('textarea'); input.value = source;
      input.style.position = 'fixed'; input.style.opacity = '0';
      sourceDialog.current?.append(input); input.select();
      const success = document.execCommand('copy'); input.remove();
      if (!success) return;
    }
    setCopied(true);
  }

  function keycap(key: GripKey) {
    function onDown(event: PointerEvent<HTMLButtonElement>) {
      if (event.button !== 0) return;
      event.currentTarget.setPointerCapture(event.pointerId); drive(key, true);
    }
    return <button type="button" className={`keycap ${key==='space'?'keycap-space':''} ${pressed.includes(key) ? 'keycap-active' : ''}`} aria-label={driveNames[key]} title={driveNames[key]}
      onPointerDown={onDown} onPointerUp={() => drive(key, false)} onPointerCancel={() => drive(key, false)} onLostPointerCapture={() => drive(key, false)}
      onClick={event => { if (event.detail === 0) { drive(key, true); window.setTimeout(() => drive(key, false), 180); } }}>{key==='space'?'Spasi':key.toUpperCase()}</button>;
  }

  const driveControls=<section className={`drive-bar ${isCockpit?'drive-cockpit':''}`} aria-label="Kontrol berkendara">
    <div className="drive-title"><span className="drive-rule"/>{isCockpit?'KONTROL':'UJI KENDARA'}</div>
    <div className="drive-inputs">
      <div className="drive-group"><div className="keycaps">{keycap('w')}{keycap('s')}</div><span>Gas / rem</span></div>
      <div className="drive-group"><div className="keycaps">{keycap('a')}{keycap('d')}</div><span>Belok</span></div>
      {isCockpit && <div className="drive-group handbrake-control"><div className="keycaps">{keycap('space')}</div><span>Rem tangan</span></div>}
    </div>
    <div className="drive-outputs">
      {!isCockpit && <div className="speed-readout" title={speed < 0 ? 'Kecepatan mundur' : 'Kecepatan'}><output aria-label="Kecepatan dalam kilometer per jam" aria-live="off">{speed < 0 ? '-' : ''}{String(Math.abs(speed)).padStart(2, '0')}</output><span>KM/J</span></div>}
      <button type="button" className="lights-switch" role="switch" aria-label="Lampu depan" aria-checked={headlights} onClick={toggleHeadlights} title="Hidupkan atau matikan lampu depan (L)">
        <Icon name="lamp" size={18}/><span>Lampu depan</span><kbd>L</kbd><span className="switch-track" aria-hidden="true"><span/></span>
      </button>
    </div>
  </section>;

  return (
    <div className={`lab ${isCockpit?'lab-in-cockpit':''}`}>
      <header className="topbar">
        <div className="wrap topbar-inner">
          <div className="wordmark" aria-label="Rally Lab">
            <span className="brand-mark"><svg viewBox="0 0 30 30" width="29" height="29" aria-hidden="true"><path d="M8 7h6l-2 5H6l2-5Zm10 0h6l-2 5h-6l2-5Zm-5 5h6l-2 5h-6l2-5Zm-9 5h6l-2 5H2l2-5Zm10 0h6l-2 5h-6l2-5Z" transform="translate(2 0)" fill="currentColor"/></svg></span>
            <span>RALLY<span className="wordmark-lab">LAB</span></span>
          </div>
          <nav className="mode-switch" aria-label="Mode tampilan">
            <button type="button" aria-pressed={!isCockpit} onClick={() => switchMode('garage')}><Icon name="threeQuarter" size={16}/><span>Garasi</span></button>
            <button type="button" aria-pressed={isCockpit} onClick={() => switchMode('cockpit')}><Icon name="wheel" size={17}/><span>Kokpit</span></button>
          </nav>
          <button className="source-button" type="button" aria-label="Kode model" onClick={openSource}><Icon name="code" size={16}/> <span>Kode model</span></button>
        </div>
      </header>

      <main className="wrap main">
        <section className="intro" aria-labelledby="model-title">
          <div>
            <div className="eyebrow"><span className="eyebrow-rule"/>{isCockpit?'UJI KENDARA':'GARASI 3D'} <span className="eyebrow-divider">/</span> {isCockpit?'01':'012'}</div>
            <h1 id="model-title">{isCockpit?'KOKPIT RALLY':'GROUP B COUPE'}</h1>
            <p>{isCockpit?'Uji mobil Group B rakitanmu dari kursi pengemudi.':'Rakit versi kamu dari ikon reli era 80-an.'}</p>
          </div>
          <div className="model-class">
            <div><span>{isCockpit?'LINTASAN 01':'KLASIFIKASI MODEL'}</span><strong>{isCockpit?'SIRKUIT PINUS':'OBJEK / HARD SURFACE'}</strong></div>
            <svg width="42" height="32" viewBox="0 0 42 32" fill="currentColor" aria-hidden="true"><path d="M13 2h8L8 30H0L13 2Zm10 0h8L18 30h-8L23 2Zm10 0h8L28 30h-8L33 2Z"/></svg>
          </div>
        </section>

        <div className={`workspace ${isCockpit?'workspace-cockpit':''}`}>
        <section ref={stage} className={`inspector ${expanded ? 'inspector-expanded' : ''}`} aria-label={isCockpit?'Simulator kokpit':'Studio mobil reli'}>
          <div className={`stage ${ready ? 'stage-ready' : ''} ${isCockpit?'stage-cockpit':''}`} data-mode={mode} data-view={isCockpit?'cockpit':view ?? 'free'} data-nose={build.nose} data-rear={build.rear} data-wing={build.wing} data-vinyl={build.vinyl} data-theme={build.theme}>
            <div className="viewport" ref={viewport}/>
            {!ready && <div className="stage-message" role="status"><span className={error ? 'stage-warning' : 'loader'}/>{error || (isCockpit?'Menyiapkan lintasan 3D':'Menyiapkan mobil 3D')}</div>}
            {isCockpit ? <>
              {ready && <CockpitHud data={telemetry} route={route.path} start={route.start}/>}
              <div className="cockpit-actions" aria-label="Kontrol sesi">
                <button type="button" className="stage-button icon-button" onClick={togglePause} aria-label={paused?'Lanjutkan':'Jeda'} title={paused?'Lanjutkan (Esc)':'Jeda (Esc)'}><Icon name={paused?'play':'pause'} size={16}/></button>
                <button type="button" className="stage-button icon-button" onClick={restartRun} aria-label="Ulang dari awal" title="Ulang dari awal (R)"><Icon name="reset" size={17}/></button>
                <button type="button" className="stage-button cabin-back" onClick={()=>switchMode('garage')} aria-label="Kembali ke garasi" title="Kembali ke garasi (C)"><Icon name="threeQuarter" size={16}/><span>Garasi</span><kbd>C</kbd></button>
                <button type="button" className="stage-button icon-button" onClick={toggleFullscreen} aria-label={expanded || isFullscreen ? 'Keluar layar penuh' : 'Layar penuh'} title={expanded || isFullscreen ? 'Keluar layar penuh' : 'Layar penuh'}><Icon name={expanded || isFullscreen ? 'minimize' : 'full'} size={17}/></button>
              </div>
              {paused && <div className="cockpit-pause"><p role="status">SESI DIJEDA</p><button type="button" onClick={togglePause}><Icon name="play" size={15}/>Lanjut mengemudi</button></div>}
            </> : <>
            <div className="stage-top">
              <div className="live-label"><span className={`live-dot ${error ? 'live-error' : ''}`}/><span>{error ? 'VIEWER NONAKTIF' : 'VIEWPORT 3D'}</span></div>
              <div className="stage-actions">
                <button type="button" className="stage-button focus-preview" aria-label={inspectLabel} aria-pressed={view === 'noseDetail' || view === 'rearDetail'} title={inspectLabel} onClick={inspectPart}>
                  <Icon name="focus" size={15}/><span>Detail<span className="focus-caption"> {inspectRear ? 'belakang' : 'depan'}</span></span>
                </button>
                <button type="button" className="stage-button turntable" onClick={toggleTurntable} aria-label="Putar otomatis" aria-pressed={turning} title={turning ? 'Jeda putaran (T)' : 'Putar otomatis (T)'}>
                  <Icon name={turning ? 'pause' : 'play'} size={14}/><span>Putar otomatis</span>
                </button>
                {(expanded || isFullscreen) && <button type="button" className="stage-button icon-button" onClick={()=>switchMode('cockpit')} aria-label="Masuk kokpit"><Icon name="wheel" size={17}/></button>}
                <button type="button" className="stage-button icon-button" onClick={toggleFullscreen} aria-label={expanded || isFullscreen ? 'Keluar layar penuh' : 'Layar penuh'} title={expanded || isFullscreen ? 'Keluar layar penuh' : 'Layar penuh'}><Icon name={expanded || isFullscreen ? 'minimize' : 'full'} size={17}/></button>
              </div>
            </div>
            <div className="stage-bottom">
              <div className="orbit-hint"><Icon name="mouse" size={16}/><span className="mouse-hint">Seret untuk putar <i/> Gulir untuk zoom</span><span className="touch-hint">Seret untuk putar <i/> Cubit untuk zoom</span></div>
              <div className="stage-actions zoom-controls" aria-label="Kontrol kamera">
                <div className="zoom-pair">
                  <button type="button" className="stage-button icon-button" onClick={() => studio.current?.zoomBy(-1)} aria-label="Perkecil" title="Perkecil"><Icon name="minus" size={16}/></button>
                  <button type="button" className="stage-button icon-button" onClick={() => studio.current?.zoomBy(1)} aria-label="Perbesar" title="Perbesar"><Icon name="plus" size={16}/></button>
                </div>
                <button type="button" className="stage-button icon-button" onClick={() => chooseView('threeQuarter')} aria-label="Reset kamera" title="Reset kamera (R)"><Icon name="reset" size={17}/></button>
              </div>
            </div>
            </>}
          </div>

          {isCockpit ? driveControls : <nav className="views" aria-label="Sudut pandang mobil">
            {views.map(item => {
              const active = view === item.id || (inspectRear && item.id === 'rear');
              return <button type="button" className={`view-button ${active ? 'view-active' : ''}`} aria-label={item.name} aria-pressed={active} key={item.id} onClick={() => chooseView(item.id)}>
                <Icon name={item.id} size={20}/> <span>{item.label}</span>
              </button>;
            })}
          </nav>}
        </section>
        {!isCockpit && <BuildPanel build={build} onPart={selectPart} onReset={resetBuild} onPreview={previewBuild}/>}
        </div>

        {!isCockpit && driveControls}

        <footer className="lab-footer"><span>GEOMETRI PROSEDURAL <i/> TANPA ASET EKSTERNAL</span><span>THREE.JS <b>/</b> R160</span></footer>
      </main>

      <dialog ref={sourceDialog} className="source-dialog" aria-labelledby="source-title" onClick={event => { if (event.target === event.currentTarget) sourceDialog.current?.close(); }}>
        <div className="source-dialog-inner">
          <div className="source-heading">
            <div><div className="eyebrow"><span className="eyebrow-rule"/>GARASI 3D / 012</div><h2 id="source-title">Kode model</h2></div>
            <button type="button" className="stage-button icon-button" onClick={() => sourceDialog.current?.close()} aria-label="Tutup kode model" autoFocus><Icon name="close"/></button>
          </div>
          <p>Salin modul prosedural, lalu panggil <code>createRallyCarModel({'{ THREE, build }'})</code>. Ganti part tanpa mereset animasi lewat <code>car.userData.setBuild(pilihan)</code>.</p>
          <pre tabIndex={0}><code>{source}</code></pre>
          <div className="source-footer"><span>JAVASCRIPT / ES MODULE</span><button type="button" className="copy-button" onClick={copySource}><Icon name={copied ? 'check' : 'copy'} size={16}/>{copied ? 'Tersalin' : 'Salin modul'}</button></div>
        </div>
      </dialog>
    </div>
  );
}