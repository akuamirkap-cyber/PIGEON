import { lazy, Suspense, useEffect, useState } from 'react';
import ProdriftMenu, { type MenuArenaId } from './menu/ProdriftMenu';

const RallyGame = lazy(() => import('./arenas/rc-drift/pigeon/RallyGame'));
const DriftSimGame = lazy(() => import('./arenas/drift-sim/DriftSimGame'));
const RmxGame = lazy(() => import('./arenas/rc-drift/RmxGame'));
const HarunaRoute33Game = lazy(() => import('./arenas/haruna-route33/HarunaRoute33Game'));
const HarunaDownhillGame = lazy(() => import('./arenas/haruna-downhill/HarunaDownhillGame'));

type Screen = 'menu' | 'play' | 'studio' | MenuArenaId;

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'F2' && screen !== 'menu') {
        e.preventDefault();
        setScreen('menu');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [screen]);

  if (screen === 'menu') {
    return (
      <ProdriftMenu
        onPlay={() => setScreen('play')}
        onStudio={() => setScreen('studio')}
        onArena={(id) => setScreen(id)}
      />
    );
  }

  return (
    <Suspense
      fallback={
        <div className="fixed inset-0 grid place-items-center bg-[#101828] text-[#f5f3ea]">
          <div className="flex flex-col items-center gap-3">
            <div className="h-7 w-7 animate-spin rounded-full border-2 border-white/25 border-t-[#ffae46]" />
            <span className="text-xs font-bold tracking-widest text-[#acb8cb] uppercase">
              Memuat lintasan...
            </span>
          </div>
        </div>
      }
    >
      {screen === 'play' && <RallyGame onExit={() => setScreen('menu')} initialMode="drive" />}
      {screen === 'studio' && <RallyGame onExit={() => setScreen('menu')} initialMode="garage" />}
      {screen === 'drift-sim' && <DriftSimGame onExit={() => setScreen('menu')} />}
      {screen === 'rc-arena' && <RmxGame onExit={() => setScreen('menu')} />}
      {screen === 'haruna-route33' && <HarunaRoute33Game onExit={() => setScreen('menu')} />}
      {screen === 'haruna-downhill' && <HarunaDownhillGame onExit={() => setScreen('menu')} />}
    </Suspense>
  );
}
