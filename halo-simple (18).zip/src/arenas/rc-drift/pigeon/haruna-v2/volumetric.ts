import * as THREE from 'three';
import { Effect, EffectAttribute, BlendFunction } from 'postprocessing';

const fragment = /* glsl */ `
uniform highp sampler2DShadow uShadowMap;
uniform mat4 uShadowMatrix;
uniform mat4 uProjInv;
uniform mat4 uViewInv;
uniform vec3 uCamPos;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform vec3 uAmbient;
uniform float uIntensity;
uniform float uDensity;
uniform float uMaxDist;
uniform float uGroundY;
uniform float uTime;
uniform float uHasShadow;
uniform float uExposure;

float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

vec3 worldFromDepth(vec2 uv, float d) {
  vec4 ndc = vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
  vec4 vp = uProjInv * ndc;
  vp /= vp.w;
  return (uViewInv * vp).xyz;
}

float hg(float c, float g) {
  float g2 = g * g;
  return (1.0 - g2) / pow(1.0 + g2 - 2.0 * g * c, 1.5);
}

float h31(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }
float vnoise(vec3 p) {
  vec3 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(h31(i), h31(i + vec3(1,0,0)), f.x), mix(h31(i + vec3(0,1,0)), h31(i + vec3(1,1,0)), f.x), f.y),
             mix(mix(h31(i + vec3(0,0,1)), h31(i + vec3(1,0,1)), f.x), mix(h31(i + vec3(0,1,1)), h31(i + vec3(1,1,1)), f.x), f.y), f.z);
}

void mainImage(const in vec4 inputColor, const in vec2 uv, const in float depth, out vec4 outputColor) {
  vec3 wp = worldFromDepth(uv, depth);
  vec3 rd = wp - uCamPos;
  float dist = length(rd);
  rd /= max(dist, 0.0001);
  float maxD = min(dist, uMaxDist);
  const int STEPS = 44;
  float stepL = maxD / float(STEPS);
  float j = ign(gl_FragCoord.xy);
  float lightAcc = 0.0;
  float ambAcc = 0.0;
  float trans = 1.0;
  for (int i = 0; i < STEPS; i++) {
    float t = (float(i) + j) * stepL;
    vec3 p = uCamPos + rd * t;
    vec4 sc = uShadowMatrix * vec4(p, 1.0);
    sc.xyz /= sc.w;
    float lit = 0.25;
    if (uHasShadow > 0.5 && all(greaterThan(sc.xyz, vec3(0.001))) && all(lessThan(sc.xyz, vec3(0.999)))) {
      lit = texture(uShadowMap, vec3(sc.xy, sc.z - 0.0008));
    }
    float hFall = exp(-max(p.y - uGroundY, 0.0) * 0.045);
    float n = vnoise(p * 0.12 + vec3(uTime * 0.05, 0.0, uTime * 0.03));
    float d = uDensity * hFall * (0.55 + 0.9 * n);
    lightAcc += lit * d * trans * stepL;
    ambAcc += d * trans * stepL;
    trans *= exp(-d * stepL * 0.6);
  }
  float c = dot(rd, uSunDir);
  float phase = mix(hg(c, 0.75), 1.0, 0.18) * 1.1 + hg(c, -0.2) * 0.1;
  vec3 scatter = uSunColor * lightAcc * phase * uIntensity + uAmbient * ambAcc * 0.05;
  outputColor = vec4((inputColor.rgb * mix(1.0, trans, 0.15) + scatter) * uExposure, inputColor.a);
}
`;

export class VolumetricLightEffect extends Effect {
  constructor() {
    super('VolumetricLightEffect', fragment, {
      attributes: EffectAttribute.DEPTH,
      blendFunction: BlendFunction.NORMAL,
      uniforms: new Map<string, THREE.Uniform>([
        ['uShadowMap', new THREE.Uniform(null)],
        ['uShadowMatrix', new THREE.Uniform(new THREE.Matrix4())],
        ['uProjInv', new THREE.Uniform(new THREE.Matrix4())],
        ['uViewInv', new THREE.Uniform(new THREE.Matrix4())],
        ['uCamPos', new THREE.Uniform(new THREE.Vector3())],
        ['uSunDir', new THREE.Uniform(new THREE.Vector3(0, 1, 0))],
        ['uSunColor', new THREE.Uniform(new THREE.Color(1, 0.92, 0.75))],
        ['uAmbient', new THREE.Uniform(new THREE.Color(0.55, 0.68, 0.72))],
        ['uIntensity', new THREE.Uniform(1)],
        ['uDensity', new THREE.Uniform(0.018)],
        ['uMaxDist', new THREE.Uniform(110)],
        ['uGroundY', new THREE.Uniform(0)],
        ['uTime', new THREE.Uniform(0)],
        ['uHasShadow', new THREE.Uniform(0)],
        ['uExposure', new THREE.Uniform(1)],
      ]),
    });
  }

  sync(camera: THREE.PerspectiveCamera, light: THREE.DirectionalLight, sunDir: THREE.Vector3, time: number) {
    const u = this.uniforms;
    u.get('uProjInv')!.value.copy(camera.projectionMatrixInverse);
    u.get('uViewInv')!.value.copy(camera.matrixWorld);
    u.get('uCamPos')!.value.setFromMatrixPosition(camera.matrixWorld);
    u.get('uSunDir')!.value.copy(sunDir);
    u.get('uTime')!.value = time;
    const map = light.shadow.map?.depthTexture ?? null;
    u.get('uShadowMap')!.value = map;
    u.get('uHasShadow')!.value = map ? 1 : 0;
    u.get('uShadowMatrix')!.value = light.shadow.matrix;
  }
}
