import * as THREE from 'three';
import { buildRoad } from '../../../haruna-downhill/game/roadMesh';
import { buildHarunaLandmarks } from '../../../haruna-downhill/game/scenery';
import { BED, buildLake, LAKE } from '../../../haruna-downhill/game/terrain';
import { makeHarunaFarGrid, makeReliefGrid, type ReliefGrid } from '../pigeon-world/haruna-relief';
import type { harunaRoute } from '../pigeon-world/route';
import { createRoadContact } from '../pigeon-world/road-contact';
import { GroundKind, type GroundAt } from '../pigeon-world/suspension';
import { createLibrary, type AssetDef } from '../haruna-v2/library';
import { globalUniforms } from '../haruna-v2/materials';
import { createNoise2D, mulberry32, rand } from '../haruna-v2/noise';
import type { V2TextureSet } from '../haruna-v2/textures';
import type { HarunaV2WorldOptions } from '../haruna-v2/world';
import {
  type BBGrassKind,
  createWildGrassTuftGeometry,
  createWildShrubGeometries,
  createWoodlandFernGeometry,
  makeBBGrassClump,
  makeKumazasaGeometry,
} from './foliage';
import { createV3SurfaceMaterials, v3FoliageUniforms } from './materials';
import { createRng, fbm2D, randRange, ridgedNoise2D, smoothstep } from './noise';
import type { V3SurfaceTextureSet } from './textures';

const V = THREE.Vector3;

function createCurledDryLeafGeometry(): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(0.115, 0.068, 3, 2);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const nx = pos.getX(i) / 0.0575;
    const nz = pos.getZ(i) / 0.034;
    const curlY = (nz * nz) * 0.015 + (nx * nx) * 0.011 + nx * nz * 0.008;
    pos.setY(i, curlY + 0.004);
  }
  geo.computeVertexNormals();
  return geo;
}

function createStrayRoadLeafGeometry(): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(0.11, 0.064, 3, 2);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) / 0.055;
    const z = pos.getZ(i) / 0.032;
    pos.setY(i, (z * z) * 0.013 + (x * x) * 0.009 + 0.004);
  }
  geo.computeVertexNormals();
  return geo;
}

function createPineNeedleTuftGeometry(): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const rng = createRng(8842);

  const needles = 7;
  let vOffset = 0;
  for (let n = 0; n < needles; n++) {
    const angle = (n / needles) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const len = randRange(rng, 0.11, 0.2);
    const lift = randRange(rng, 0.012, 0.055);
    const w = 0.0055;
    const dx = Math.cos(angle);
    const dz = Math.sin(angle);
    const px = -dz * w;
    const pz = dx * w;

    const pts = [
      { x: -dx * 0.01, y: 0.003, z: -dz * 0.01, scale: 1.0, v: 0 },
      { x: dx * len * 0.5, y: lift, z: dz * len * 0.5, scale: 0.72, v: 0.5 },
      { x: dx * len, y: lift * 0.38, z: dz * len, scale: 0.12, v: 1.0 },
    ];

    for (let s = 0; s < pts.length; s++) {
      const p = pts[s];
      positions.push(p.x - px * p.scale, p.y, p.z - pz * p.scale);
      positions.push(p.x + px * p.scale, p.y, p.z + pz * p.scale);
      normals.push(0, 1, 0, 0, 1, 0);
      uvs.push(0, p.v, 1, p.v);
    }

    indices.push(vOffset, vOffset + 1, vOffset + 2);
    indices.push(vOffset + 1, vOffset + 3, vOffset + 2);
    indices.push(vOffset + 2, vOffset + 3, vOffset + 4);
    indices.push(vOffset + 3, vOffset + 5, vOffset + 4);
    vOffset += 6;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function createFallenTwigGeometry(): THREE.BufferGeometry {
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.24, 0.008, -0.012),
    new THREE.Vector3(-0.07, 0.018, 0.016),
    new THREE.Vector3(0.09, 0.011, -0.01),
    new THREE.Vector3(0.26, 0.022, 0.022),
  ]);
  const geo = new THREE.TubeGeometry(curve, 7, 0.012, 5, false);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const t = (x + 0.25) / 0.52;
    const scale = 1.15 - t * 0.55;
    pos.setY(i, pos.getY(i) * scale);
  }
  geo.computeVertexNormals();
  return geo;
}

export function buildHarunaV3World(
  scene: THREE.Scene,
  spec: ReturnType<typeof harunaRoute>,
  v2Tex: V2TextureSet,
  v3Tex: V3SurfaceTextureSet,
  opts: HarunaV2WorldOptions,
) {
  const group = new THREE.Group();
  group.name = 'Mt. Haruna V3 world';
  scene.add(group);

  const { route, track, field, startLot, finishPlaza, bounds, cell } = spec;
  const v3Mats = createV3SurfaceMaterials(v3Tex, v2Tex);
  const noise = createNoise2D(7);
  const noise2 = createNoise2D(19);

  // ---------------- 1. HARUNA MOUNTAIN RELIEF WITH V3 DEAD-LEAF FOREST FLOOR ----------------
  const nearGrid = makeReliefGrid(bounds, cell, (x, z) => spec.terrain(x, z), true);
  const farGrid = makeHarunaFarGrid(bounds);

  const roadHalf = route.half; // 4.6m
  const v3FloorColor = (x: number, z: number, dist: number, signed: number) => {
    const sunBank = signed > 0 ? smoothstep(roadHalf, roadHalf + 4.5, dist) : 0;
    const deepShade = smoothstep(roadHalf, roadHalf + 11.5, dist) * (signed <= 0 ? 1.0 : 0.45);
    const microMoss = fbm2D(x * 0.45 + 1.3, z * 0.45 + 7.1, 3, 2.0, 0.5, 909);

    const r = 0.94 + sunBank * 0.16 - deepShade * 0.20 - Math.max(0, microMoss - 0.6) * 0.22;
    const g = 0.92 + sunBank * 0.13 - deepShade * 0.16 + Math.max(0, microMoss - 0.6) * 0.08;
    const b = 0.87 + sunBank * 0.08 - deepShade * 0.20 - Math.max(0, microMoss - 0.6) * 0.22;
    return [r, g, b] as const;
  };

  const nearGroup = renderV3Relief(
    nearGrid,
    128 / cell,
    v3Mats.forestFloor,
    (x, z) => {
      const q = route.nearest(x, z);
      return v3FloorColor(x, z, q.dist, q.signed);
    },
    true,
  );
  nearGroup.name = 'Mt. Haruna V3 hills (4 m) — Dead Leaf Forest Floor';
  group.add(nearGroup);

  const farGroup = renderV3Relief(
    farGrid,
    16,
    v3Mats.forestFloorFar,
    (x, z) => v3FloorColor(x, z, 120, -1),
    false,
  );
  farGroup.name = 'Mt. Haruna V3 mountain ranges (48 m)';
  const lake = buildLake();
  lake.name = 'Mt. Haruna caldera lake';
  group.add(farGroup, lake);

  // ---------------- 2. HARUNA ROAD CONTOUR + V3 FLUSH PARALLEL ASPHALT & NATURAL SHOULDERS (NO SIDEWALK/CURB) ----------------
  const contact = createRoadContact();
  const original = buildRoad(track, field, { skipLaneLines: true });
  original.group.name = 'Mt. Haruna V3 roadway, guardrails, signs & landmarks';
  original.markings.material.color.set(0xd5d2c8);

  original.guardrails.traverse(obj => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
  });

  // Exact V3 asphalt shape from realistic-3d-nature-assets/src/engine/assets/road.ts:
  // 26 cross-section segments, 0.22m parallel feathered skirtPad tapering straight into both forest shoulders (ZERO concrete sidewalks/curbs)
  const widthSegs = 26;
  const rows = track.n;
  const skirtPad = 0.22;
  const totalHalf = roadHalf + skirtPad;
  const tileScale = 0.52;

  const rPos: number[] = [];
  const rUv: number[] = [];
  const rCoords: number[] = [];
  const rIdx: number[] = [];
  let arcLen = 0;

  for (let i = 0; i < rows; i++) {
    if (i > 0) {
      arcLen += Math.hypot(track.x[i] - track.x[i - 1], track.z[i] - track.z[i - 1]);
    }
    const cos = Math.cos(track.psi[i]);
    const sin = Math.sin(track.psi[i]);
    const curvature = track.kappa[i];

    for (let j = 0; j <= widthSegs; j++) {
      const uRaw = j / widthSegs;
      const s = THREE.MathUtils.lerp(-totalHalf, totalHalf, uRaw);
      const px = track.x[i] + s * cos;
      const pz = track.z[i] - s * sin;

      const t = Math.max(-1.25, Math.min(1.25, s / roadHalf));
      const crown = 0.048 * Math.max(0, 1 - t * t);
      const camber = (-0.015 - curvature * 1.4) * t;
      const roadRipples = (fbm2D(px * 0.28 + 1.5, pz * 0.28 + 3.2, 2, 2.0, 0.5, 707) - 0.5) * 0.032;

      let edgeDrop = 0;
      if (Math.abs(s) > roadHalf) {
        const over = (Math.abs(s) - roadHalf) / skirtPad;
        edgeDrop = -over * over * 0.048;
      }

      const py = track.y[i] + crown + camber + roadRipples + edgeDrop + 0.018;
      rPos.push(px, py, pz);
      rUv.push((s + totalHalf) * tileScale, arcLen * tileScale);
      const uNormalized = Math.max(0, Math.min(1, (s + roadHalf) / (2 * roadHalf)));
      rCoords.push(uNormalized, arcLen);
    }
  }

  const rStride = widthSegs + 1;
  for (let i = 0; i < rows - 1; i++) {
    for (let j = 0; j < widthSegs; j++) {
      const a = i * rStride + j;
      const b = (i + 1) * rStride + j;
      const c = (i + 1) * rStride + (j + 1);
      const d = i * rStride + (j + 1);
      rIdx.push(a, b, d, b, c, d);
    }
  }

  const rGeo = new THREE.BufferGeometry();
  rGeo.setAttribute('position', new THREE.Float32BufferAttribute(rPos, 3));
  rGeo.setAttribute('uv', new THREE.Float32BufferAttribute(rUv, 2));
  rGeo.setAttribute('aRoadCoord', new THREE.Float32BufferAttribute(rCoords, 2));
  rGeo.setIndex(rIdx);
  rGeo.computeVertexNormals();

  const asphaltMesh = new THREE.Mesh(rGeo, v3Mats.tougeAsphalt);
  asphaltMesh.name = 'Mt. Haruna V3 touge asphalt surface';
  asphaltMesh.receiveShadow = true;
  original.group.add(asphaltMesh);
  contact.add(asphaltMesh, GroundKind.Asphalt);

  // Symmetrical parallel flush dead-leaf forest-floor shoulders on BOTH sides (no concrete curbs, no sidewalks, no U-drains)
  const shoulderProfile: Array<[number, number]> = [
    [roadHalf - 0.06, -0.028],
    [roadHalf + skirtPad, -0.025],
    [roadHalf + 0.85, -0.042],
    [roadHalf + 1.95, -0.14],
    [roadHalf + 3.55, -BED + 0.04],
  ];
  const profLen = shoulderProfile.length;
  const sPos: number[] = [];
  const sUv: number[] = [];
  const sCol: number[] = [];
  const sIdx: number[] = [];

  for (const sgn of [1, -1] as const) {
    const baseVertex = sPos.length / 3;
    for (let i = 0; i < rows; i++) {
      const cos = Math.cos(track.psi[i]);
      const sin = Math.sin(track.psi[i]);
      for (let p = 0; p < profLen; p++) {
        const [localS, localY] = shoulderProfile[p];
        const lat = localS * sgn;
        const px = track.x[i] + lat * cos;
        const pz = track.z[i] - lat * sin;
        const edgeUndo = p <= 1 ? (fbm2D(px * 0.28 + 1.5, pz * 0.28 + 3.2, 2, 2.0, 0.5, 707) - 0.5) * 0.018 : 0;
        const py = track.y[i] + localY + edgeUndo;
        sPos.push(px, py, pz);
        sUv.push(px / 3.4, pz / 3.4);
        const [cr, cg, cb] = v3FloorColor(px, pz, localS, sgn);
        sCol.push(cr, cg, cb);
      }
    }
    for (let i = 0; i < rows - 1; i++) {
      for (let p = 0; p < profLen - 1; p++) {
        const a = baseVertex + i * profLen + p;
        const b = baseVertex + (i + 1) * profLen + p;
        const c = baseVertex + (i + 1) * profLen + (p + 1);
        const d = baseVertex + i * profLen + (p + 1);
        if (sgn > 0) sIdx.push(a, b, d, b, c, d);
        else sIdx.push(a, d, b, b, d, c);
      }
    }
  }

  const shoulderGeo = new THREE.BufferGeometry();
  shoulderGeo.setAttribute('position', new THREE.Float32BufferAttribute(sPos, 3));
  shoulderGeo.setAttribute('uv', new THREE.Float32BufferAttribute(sUv, 2));
  shoulderGeo.setAttribute('color', new THREE.Float32BufferAttribute(sCol, 3));
  shoulderGeo.setIndex(sIdx);
  shoulderGeo.computeVertexNormals();

  const shoulderMesh = new THREE.Mesh(shoulderGeo, v3Mats.forestFloorShoulder);
  shoulderMesh.name = 'Haruna V3 parallel dead-leaf shoulders';
  shoulderMesh.receiveShadow = true;
  original.group.add(shoulderMesh);
  contact.add(shoulderMesh, GroundKind.Earth);

  original.baseAsphalt.removeFromParent();
  original.shoulders.removeFromParent();
  original.baseAsphalt.geometry.dispose();
  original.shoulders.geometry.dispose();
  original.baseAsphalt.material.dispose();

  // Haruna start parking lot & finish plaza landmarks (with V3 HD asphalt material)
  const landmarks = buildHarunaLandmarks(track, startLot, finishPlaza);
  const padAsphaltMat = new THREE.MeshStandardMaterial({
    map: v3Tex.asphalt.map,
    normalMap: v3Tex.asphalt.normalMap,
    normalScale: new THREE.Vector2(1.1, 1.1),
    roughnessMap: v3Tex.asphalt.roughnessMap,
    roughness: 0.9,
    metalness: 0.03,
    color: '#9c9e9f',
  });
  for (const surface of landmarks.surfaces) {
    const oldMat = surface.material;
    surface.material = padAsphaltMat;
    if (Array.isArray(oldMat)) oldMat.forEach(m => m.dispose());
    else oldMat.dispose();
    contact.add(surface, GroundKind.Asphalt);
  }
  original.group.add(landmarks.group);
  group.add(original.group);

  // ---------------- 3. UNIFIED COLLISION GROUND PROBE ----------------
  const scratch = { y: 0, kind: GroundKind.Void };
  const groundAt: GroundAt = (x, z, out = scratch) => {
    out.y = Math.max(nearGrid.heightAt(x, z), farGrid.heightAt(x, z));
    out.kind = Number.isFinite(out.y) ? GroundKind.Earth : GroundKind.Void;
    contact.sample(x, z, out);
    if (out.kind === GroundKind.Void) out.y = -200;
    return out;
  };

  // ---------------- 4. TREES ALONG HARUNA ----------------
  const lib = createLibrary(v2Tex);
  const defMap = new Map<string, AssetDef>(lib.map(d => [d.id, d]));
  const rng = mulberry32(2024);

  const CORRIDOR_CELL = 24;
  const corridorKey = (cx: number, cz: number) => cx * 65536 + cz;
  const nearCorridor = new Set<number>();
  const rCells = Math.ceil(165 / CORRIDOR_CELL);
  for (let i = 0; i < route.rows.length; i += 4) {
    const row = route.rows[i];
    const cx = Math.floor(row.x / CORRIDOR_CELL);
    const cz = Math.floor(row.z / CORRIDOR_CELL);
    for (let dz = -rCells; dz <= rCells; dz++) {
      for (let dx = -rCells; dx <= rCells; dx++) {
        nearCorridor.add(corridorKey(cx + dx, cz + dz));
      }
    }
  }
  const inCorridor = (x: number, z: number) =>
    nearCorridor.has(corridorKey(Math.floor(x / CORRIDOR_CELL), Math.floor(z / CORRIDOR_CELL)));

  const gates = [route.at(spec.start), route.at(spec.finish)];
  const inside = (x: number, z: number) => {
    if (x < bounds.x0 + 6 || x > bounds.x1 - 6 || z < bounds.z0 + 6 || z > bounds.z1 - 6) return false;
    if (!inCorridor(x, z)) return false;
    if (field.platformDist(x, z) < 1.8) return false;
    if ((x - LAKE.x) ** 2 + (z - LAKE.z) ** 2 < (LAKE.r + 4) ** 2) return false;
    for (const gate of gates) {
      const dx = x - gate.x;
      const dz = z - gate.z;
      if (Math.abs(dx * gate.tx + dz * gate.tz) < 5.8 && Math.abs(dx * gate.tz - dz * gate.tx) < 11.4) return false;
    }
    return true;
  };

  type Inst = { m: THREE.Matrix4; c: THREE.Color };
  const buckets = new Map<string, Inst[]>();
  const push = (defId: string, v: number, x: number, z: number, inst: Inst) => {
    const tx = Math.floor(x / 60);
    const tz = Math.floor(z / 60);
    const k = `${defId}|${v}|${tx},${tz}`;
    let list = buckets.get(k);
    if (!list) {
      list = [];
      buckets.set(k, list);
    }
    list.push(inst);
  };

  const pick = (w: [string, number][]) => {
    const tot = w.reduce((s, x) => s + x[1], 0);
    let t = rng() * tot;
    for (const [id, p] of w) {
      if ((t -= p) <= 0) return id;
    }
    return w[0][0];
  };

  const q = new THREE.Quaternion();
  const sc = new V();
  const pos = new V();
  const e = new THREE.Euler();
  const qLean = new THREE.Quaternion();
  const UP = new V(0, 1, 0);

  const place = (
    id: string,
    x: number,
    z: number,
    y: number,
    signed: number,
    tx: number,
    tz: number,
    scale: number,
    tilt = 0.04,
    lean = 0,
  ) => {
    const def = defMap.get(id)!;
    const v = Math.floor(rng() * def.variants);
    pos.set(x, y - 0.06, z);
    e.set(rand(rng, -tilt, tilt), rand(rng, 0, Math.PI * 2), rand(rng, -tilt, tilt));
    q.setFromEuler(e);
    if (lean > 0) {
      const toRoad = new V(-tz, 0, tx).multiplyScalar(-Math.sign(signed) || 1);
      const axis = UP.clone().cross(toRoad).normalize();
      if (axis.lengthSq() > 0.001) {
        qLean.setFromAxisAngle(axis, lean);
        q.premultiply(qLean);
      }
    }
    sc.setScalar(scale);
    const m = new THREE.Matrix4().compose(pos, q, sc);
    const c = new THREE.Color(rand(rng, 0.86, 1.06), rand(rng, 0.9, 1.08), rand(rng, 0.8, 1.0));
    push(id, v, x, z, { m, c });
  };

  const terrainProbe = { y: 0, kind: GroundKind.Void };

  const cellT = 5.6 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cellT) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cellT) {
      const px = x + rand(rng, 0, cellT);
      const pz = z - rand(rng, 0, cellT);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a < roadHalf + 2.2 || a > 64) continue;
      if (rng() > (a > 40 ? 0.6 : 0.78)) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      const n = noise(px * 0.018, pz * 0.018);
      let id: string;
      if (a < 15) id = pick([['maple', 0.26 + n * 0.1], ['sapling', 0.18], ['beech', 0.14], ['cedar', 0.24], ['pole', 0.18]]);
      else if (n > 0.35) id = pick([['beech', 0.35], ['maple', 0.25], ['cedar', 0.25], ['cypress', 0.15]]);
      else id = pick([['cedar', 0.4], ['pole', 0.32], ['cypress', 0.16], ['beech', 0.06], ['maple', 0.06]]);
      place(id, px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.82, 1.15), 0.04, a < 12 ? rand(rng, 0.02, 0.07) : 0);
    }
  }

  const rowStep = Math.max(4.5, 8.2 / Math.sqrt(opts.density));
  for (let s = 4; s < route.length - 4; s += rowStep) {
    for (const side of [-1, 1]) {
      if (rng() < 0.18) continue;
      const a = roadHalf + rand(rng, 2.3, 5.6);
      const f = route.at(s + rand(rng, 0, rowStep * 0.45));
      const px = f.x - f.tz * side * a;
      const pz = f.z + f.tx * side * a;
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      if (info.dist < roadHalf + 2.2) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      const id = pick([['maple', 0.38], ['beech', 0.42], ['sapling', 0.2]]);
      place(id, px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.95, 1.3), 0.03, rand(rng, 0.04, 0.13));
    }
  }

  const cellF = 9.0 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cellF) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cellF) {
      const px = x + rand(rng, 0, cellF);
      const pz = z - rand(rng, 0, cellF);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a <= 64 || a > 150 || rng() > 0.72) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      place(pick([['cedar', 0.5], ['pole', 0.3], ['cypress', 0.2]]), px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.9, 1.2));
    }
  }

  const cell2 = 7.0 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cell2) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cell2) {
      const px = x + rand(rng, 0, cell2);
      const pz = z - rand(rng, 0, cell2);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a < roadHalf + 2.0 || a > 26 || rng() > 0.55) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      place(rng() < 0.6 ? 'sapling' : 'maple', px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.6, 1.0), 0.08);
    }
  }

  const geoCache = new Map<string, ReturnType<AssetDef['make']>>();
  const getAsset = (def: AssetDef, v: number) => {
    const k = `${def.id}|${v}`;
    if (!geoCache.has(k)) geoCache.set(k, def.make(1000 + v * 97 + def.id.length * 13));
    return geoCache.get(k)!;
  };
  let treeCount = 0;
  for (const [key, list] of buckets) {
    const [id, vs] = key.split('|');
    const def = defMap.get(id)!;
    const asset = getAsset(def, Number(vs));
    treeCount += list.length;
    const lm = new THREE.InstancedMesh(asset.leaves, def.leaf.mat, list.length);
    lm.customDepthMaterial = def.leaf.depth;
    lm.castShadow = true;
    lm.receiveShadow = true;
    list.forEach((it, i) => {
      lm.setMatrixAt(i, it.m);
      lm.setColorAt(i, it.c);
    });
    lm.computeBoundingSphere();
    if (lm.boundingSphere) lm.boundingSphere.radius += 3;
    group.add(lm);
    if (asset.bark && def.bark) {
      const bm = new THREE.InstancedMesh(asset.bark, def.bark.mat, list.length);
      bm.customDepthMaterial = def.bark.depth;
      bm.castShadow = true;
      bm.receiveShadow = true;
      list.forEach((it, i) => bm.setMatrixAt(i, it.m));
      bm.computeBoundingSphere();
      if (bm.boundingSphere) bm.boundingSphere.radius += 2;
      group.add(bm);
    }
  }

  // ---------------- 5. V3 WILD PLANTS (SHRUB, FERN) & BB KUMAZASA BAMBOO GRASS (60m GPU-INSTANCED TILES) ----------------
  const wildRng = createRng(5521);
  const shrubVariants = [
    createWildShrubGeometries(4101),
    createWildShrubGeometries(4153),
    createWildShrubGeometries(4199),
  ];
  const fernVariants = [
    createWoodlandFernGeometry(4303),
    createWoodlandFernGeometry(4309),
    createWoodlandFernGeometry(4327),
  ];
  const sasaVariants = [
    makeKumazasaGeometry(7731),
    makeKumazasaGeometry(7789),
    makeKumazasaGeometry(7841),
  ];

  const dummy = new THREE.Object3D();
  const qAlign = new THREE.Quaternion();
  const qSpin = new THREE.Quaternion();
  const normVec = new V();
  const sampleTerrainNormal = (x: number, z: number, eps = 0.25) => {
    const hL = groundAt(x - eps, z, terrainProbe).y;
    const hR = groundAt(x + eps, z, terrainProbe).y;
    const hD = groundAt(x, z - eps, terrainProbe).y;
    const hU = groundAt(x, z + eps, terrainProbe).y;
    return normVec.set(hL - hR, 2 * eps, hD - hU).normalize();
  };

  type UnderBucket = { mats: THREE.Matrix4[]; cols: THREE.Color[] };
  const shrubBuckets = new Map<string, UnderBucket>();
  const fernBuckets = new Map<string, UnderBucket>();
  const sasaBuckets = new Map<string, UnderBucket>();

  const pushBucket = (map: Map<string, UnderBucket>, vIdx: number, px: number, pz: number, mat: THREE.Matrix4, col: THREE.Color) => {
    const key = `${vIdx}|${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let b = map.get(key);
    if (!b) {
      b = { mats: [], cols: [] };
      map.set(key, b);
    }
    b.mats.push(mat);
    b.cols.push(col);
  };

  const shrubCell = 2.4 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= shrubCell) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += shrubCell) {
      const px = x + randRange(wildRng, 0, shrubCell);
      const pz = z - randRange(wildRng, 0, shrubCell);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a < roadHalf + 0.72 || a > 46) continue;
      const pr = a < 10.5 ? 0.56 : 0.34;
      if (wildRng() > pr) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;

      const n = noise2(px * 0.05, pz * 0.05);
      const roll = wildRng();
      const tn = sampleTerrainNormal(px, pz);
      qAlign.setFromUnitVectors(UP, sc.copy(UP).lerp(tn, 0.25).normalize());
      qSpin.setFromAxisAngle(UP, wildRng() * Math.PI * 2);
      dummy.quaternion.copy(qAlign).multiply(qSpin);
      const tint = new THREE.Color().setRGB(
        randRange(wildRng, 0.84, 1.08),
        randRange(wildRng, 0.88, 1.12),
        randRange(wildRng, 0.78, 0.98)
      );

      if (a >= roadHalf + 1.3 && (roll < 0.28 && n < 0.32)) {
        const scS = randRange(wildRng, 0.72, 1.24);
        dummy.position.set(px, g.y - 0.04, pz);
        dummy.scale.set(scS, scS * randRange(wildRng, 0.9, 1.15), scS);
        dummy.updateMatrix();
        pushBucket(shrubBuckets, Math.floor(wildRng() * 3), px, pz, dummy.matrix.clone(), tint);
      } else if (roll < 0.56) {
        const scF = randRange(wildRng, 0.74, 1.26);
        dummy.position.set(px, g.y - 0.02, pz);
        dummy.scale.set(scF, scF * randRange(wildRng, 0.88, 1.15), scF);
        dummy.updateMatrix();
        pushBucket(fernBuckets, Math.floor(wildRng() * 3), px, pz, dummy.matrix.clone(), tint);
      } else {
        const scK = randRange(wildRng, 0.68, 1.22);
        dummy.position.set(px, g.y - 0.03, pz);
        dummy.scale.set(scK, scK * randRange(wildRng, 0.86, 1.16), scK);
        dummy.updateMatrix();
        pushBucket(sasaBuckets, Math.floor(wildRng() * 3), px, pz, dummy.matrix.clone(), tint);
      }
    }
  }

  for (const [key, b] of shrubBuckets) {
    const vIdx = Number(key.split('|')[0]);
    const geo = shrubVariants[vIdx];

    const stemIm = new THREE.InstancedMesh(geo.stems, v3Mats.wildStems, b.mats.length);
    stemIm.castShadow = opts.shadowsOnBushes;
    stemIm.receiveShadow = true;

    const mainIm = new THREE.InstancedMesh(geo.mainLeaves, v3Mats.wildShrubLeaf, b.mats.length);
    mainIm.customDepthMaterial = v3Mats.wildShrubLeaf.userData.customDepthMaterial;
    mainIm.castShadow = opts.shadowsOnBushes;
    mainIm.receiveShadow = true;

    const brightIm = new THREE.InstancedMesh(geo.brightLeaves, v3Mats.wildShrubBright, b.mats.length);
    brightIm.customDepthMaterial = v3Mats.wildShrubBright.userData.customDepthMaterial;
    brightIm.castShadow = opts.shadowsOnBushes;
    brightIm.receiveShadow = true;

    for (let i = 0; i < b.mats.length; i++) {
      stemIm.setMatrixAt(i, b.mats[i]);
      mainIm.setMatrixAt(i, b.mats[i]);
      mainIm.setColorAt(i, b.cols[i]);
      brightIm.setMatrixAt(i, b.mats[i]);
      brightIm.setColorAt(i, b.cols[i]);
    }
    stemIm.computeBoundingSphere();
    mainIm.computeBoundingSphere();
    brightIm.computeBoundingSphere();
    if (mainIm.boundingSphere) mainIm.boundingSphere.radius += 2;
    group.add(stemIm, mainIm, brightIm);
  }

  for (const [key, b] of fernBuckets) {
    const vIdx = Number(key.split('|')[0]);
    const im = new THREE.InstancedMesh(fernVariants[vIdx], v3Mats.wildFernFrond, b.mats.length);
    im.customDepthMaterial = v3Mats.wildFernFrond.userData.customDepthMaterial;
    im.receiveShadow = true;
    for (let i = 0; i < b.mats.length; i++) {
      im.setMatrixAt(i, b.mats[i]);
      im.setColorAt(i, b.cols[i]);
    }
    im.computeBoundingSphere();
    if (im.boundingSphere) im.boundingSphere.radius += 1.5;
    group.add(im);
  }

  for (const [key, b] of sasaBuckets) {
    const vIdx = Number(key.split('|')[0]);
    const im = new THREE.InstancedMesh(sasaVariants[vIdx], v3Mats.sasaLeaf, b.mats.length);
    im.customDepthMaterial = v3Mats.sasaLeaf.userData.customDepthMaterial;
    im.castShadow = opts.shadowsOnBushes;
    im.receiveShadow = true;
    for (let i = 0; i < b.mats.length; i++) {
      im.setMatrixAt(i, b.mats[i]);
      im.setColorAt(i, b.cols[i]);
    }
    im.computeBoundingSphere();
    if (im.boundingSphere) im.boundingSphere.radius += 1.5;
    group.add(im);
  }

  // ---------------- 6. V3 WILD MULTI-BLADE GRASS + PIGEON/bb 3D GRASS ALONG BOTH PARALLEL ROAD EDGES & BANKS ----------------
  const bbVariants: Record<BBGrassKind, THREE.BufferGeometry[]> = {
    short: [makeBBGrassClump(111, 'short'), makeBBGrassClump(222, 'short')],
    meadow: [makeBBGrassClump(333, 'meadow'), makeBBGrassClump(444, 'meadow')],
    tall: [makeBBGrassClump(555, 'tall'), makeBBGrassClump(666, 'tall')],
  };
  const wildTuftVariants = [
    createWildGrassTuftGeometry(4567),
    createWildGrassTuftGeometry(4679),
  ];

  const bbBuckets = new Map<string, UnderBucket>();
  const wildTuftBuckets = new Map<string, UnderBucket>();

  const greenGrassPalette = ['#588a24', '#6ea32b', '#44721d', '#82b832', '#3d661a', '#7aa935'];
  const dryGrassPalette = ['#9c7c48', '#b0915c', '#82653b', '#8d8045', '#c2a670'];

  // 6A. Dense flush roadside border grass hugging BOTH parallel asphalt edges closely
  const edgeGrassCount = Math.floor(38000 * opts.grass);
  for (let k = 0; k < edgeGrassCount; k++) {
    const s = wildRng() * route.length;
    const f = route.at(s);
    const side = wildRng() < 0.5 ? -1 : 1;
    const a = roadHalf + 0.24 + Math.pow(wildRng(), 1.65) * 2.15;
    const along = randRange(wildRng, -0.5, 0.5);
    const px = f.x - f.tz * a * side + f.tx * along;
    const pz = f.z + f.tx * a * side + f.tz * along;
    if (!inside(px, pz)) continue;
    const info = route.nearest(px, pz);
    if (info.dist < roadHalf + 0.22) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;

    const tn = sampleTerrainNormal(px, pz);
    qAlign.setFromUnitVectors(UP, sc.copy(UP).lerp(tn, 0.3).normalize());
    qSpin.setFromAxisAngle(UP, wildRng() * Math.PI * 2);
    dummy.quaternion.copy(qAlign).multiply(qSpin);

    if (wildRng() < 0.62) {
      const kind: BBGrassKind = info.dist < roadHalf + 1.0 ? 'short' : 'meadow';
      const vIdx = wildRng() < 0.5 ? 0 : 1;
      const scB = randRange(wildRng, 0.72, 1.18) * (info.dist < roadHalf + 0.6 ? 0.82 : 1.0);
      dummy.position.set(px, g.y - 0.015, pz);
      dummy.scale.set(scB * randRange(wildRng, 0.88, 1.22), scB * randRange(wildRng, 0.82, 1.26), scB * randRange(wildRng, 0.88, 1.22));
      dummy.updateMatrix();

      const col = new THREE.Color().setRGB(
        randRange(wildRng, 0.82, 1.12),
        randRange(wildRng, 0.88, 1.12),
        randRange(wildRng, 0.76, 0.98)
      );
      const tk = `${kind}|${vIdx}|${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
      let b = bbBuckets.get(tk);
      if (!b) { b = { mats: [], cols: [] }; bbBuckets.set(tk, b); }
      b.mats.push(dummy.matrix.clone());
      b.cols.push(col);
    } else {
      const vIdx = wildRng() < 0.5 ? 0 : 1;
      const scW = randRange(wildRng, 0.7, 1.28) * (info.dist < roadHalf + 0.6 ? 0.85 : 1.05);
      dummy.position.set(px, g.y - 0.012, pz);
      dummy.scale.set(scW * randRange(wildRng, 0.85, 1.22), scW * randRange(wildRng, 0.8, 1.32), scW * randRange(wildRng, 0.85, 1.22));
      dummy.updateMatrix();

      const isDry = wildRng() < 0.24;
      const pal = isDry ? dryGrassPalette : greenGrassPalette;
      const col = new THREE.Color(pal[Math.floor(wildRng() * pal.length)]);
      col.offsetHSL(randRange(wildRng, -0.02, 0.02), randRange(wildRng, -0.05, 0.05), randRange(wildRng, -0.05, 0.05));
      pushBucket(wildTuftBuckets, vIdx, px, pz, dummy.matrix.clone(), col);
    }
  }

  // 6B. Deeper woodland embankment grass ('meadow' + 'tall' BB clumps + wild grass tufts)
  const bankGrassCount = Math.floor(38000 * opts.grass);
  for (let k = 0; k < bankGrassCount; k++) {
    const f = route.at(wildRng() * route.length);
    const side = wildRng() < 0.5 ? -1 : 1;
    const a = roadHalf + 1.85 + Math.pow(wildRng(), 2.0) * 23;
    const along = randRange(wildRng, -0.7, 0.7);
    const px = f.x - f.tz * a * side + f.tx * along;
    const pz = f.z + f.tx * a * side + f.tz * along;
    if (!inside(px, pz)) continue;
    const info = route.nearest(px, pz);
    if (info.dist < roadHalf + 1.75) continue;
    const n = noise2(px * 0.08, pz * 0.08);
    if (info.dist > 11 && n < -0.18) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;

    const tn = sampleTerrainNormal(px, pz);
    qAlign.setFromUnitVectors(UP, sc.copy(UP).lerp(tn, 0.32).normalize());
    qSpin.setFromAxisAngle(UP, wildRng() * Math.PI * 2);
    dummy.quaternion.copy(qAlign).multiply(qSpin);

    if (wildRng() < 0.54) {
      const kind: BBGrassKind = info.dist > roadHalf + 3.2 && wildRng() < 0.34 ? 'tall' : 'meadow';
      const vIdx = wildRng() < 0.5 ? 0 : 1;
      const scB = randRange(wildRng, 0.78, 1.32);
      dummy.position.set(px, g.y - 0.015, pz);
      dummy.scale.set(scB * randRange(wildRng, 0.88, 1.24), scB * randRange(wildRng, 0.84, 1.34), scB * randRange(wildRng, 0.88, 1.24));
      dummy.updateMatrix();

      const col = new THREE.Color().setRGB(
        randRange(wildRng, 0.82, 1.12),
        randRange(wildRng, 0.88, 1.12),
        randRange(wildRng, 0.76, 0.98)
      );
      const tk = `${kind}|${vIdx}|${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
      let b = bbBuckets.get(tk);
      if (!b) { b = { mats: [], cols: [] }; bbBuckets.set(tk, b); }
      b.mats.push(dummy.matrix.clone());
      b.cols.push(col);
    } else {
      const vIdx = wildRng() < 0.5 ? 0 : 1;
      const scW = randRange(wildRng, 0.72, 1.35);
      dummy.position.set(px, g.y - 0.012, pz);
      dummy.scale.set(scW * randRange(wildRng, 0.86, 1.24), scW * randRange(wildRng, 0.8, 1.38), scW * randRange(wildRng, 0.86, 1.24));
      dummy.updateMatrix();

      const isDry = wildRng() < 0.28;
      const pal = isDry ? dryGrassPalette : greenGrassPalette;
      const col = new THREE.Color(pal[Math.floor(wildRng() * pal.length)]);
      col.offsetHSL(randRange(wildRng, -0.025, 0.025), randRange(wildRng, -0.06, 0.06), randRange(wildRng, -0.06, 0.06));
      pushBucket(wildTuftBuckets, vIdx, px, pz, dummy.matrix.clone(), col);
    }
  }

  for (const [key, b] of bbBuckets) {
    const [kindStr, vStr] = key.split('|');
    const kind = kindStr as BBGrassKind;
    const vIdx = Number(vStr);
    const im = new THREE.InstancedMesh(bbVariants[kind][vIdx], v3Mats.bbGrass, b.mats.length);
    im.customDepthMaterial = v3Mats.bbGrass.userData.customDepthMaterial;
    im.castShadow = kind === 'tall' && opts.shadowsOnBushes;
    im.receiveShadow = true;
    for (let i = 0; i < b.mats.length; i++) {
      im.setMatrixAt(i, b.mats[i]);
      im.setColorAt(i, b.cols[i]);
    }
    im.computeBoundingSphere();
    if (im.boundingSphere) im.boundingSphere.radius += 1;
    group.add(im);
  }

  for (const [key, b] of wildTuftBuckets) {
    const vIdx = Number(key.split('|')[0]);
    const im = new THREE.InstancedMesh(wildTuftVariants[vIdx], v3Mats.wildGrassClump, b.mats.length);
    im.customDepthMaterial = v3Mats.wildGrassClump.userData.customDepthMaterial;
    im.receiveShadow = true;
    for (let i = 0; i < b.mats.length; i++) {
      im.setMatrixAt(i, b.mats[i]);
      im.setColorAt(i, b.cols[i]);
    }
    im.computeBoundingSphere();
    if (im.boundingSphere) im.boundingSphere.radius += 1;
    group.add(im);
  }

  // ---------------- 7. V3 PHYSICAL 3D DEAD-LEAF DETRITUS & WIND-BLOWN ROAD LEAVES ----------------
  const v3Rng = createRng(31415);
  const dryLeafGeo = createCurledDryLeafGeometry();
  const strayLeafGeo = createStrayRoadLeafGeometry();
  const pineTuftGeo = createPineNeedleTuftGeometry();
  const twigGeo = createFallenTwigGeometry();

  const leafPalette = ['#cbb188', '#dcc7a1', '#9a6a3b', '#7a4e29', '#b58d5c', '#5e3d21', '#876742'];
  const needlePalette = ['#7d5935', '#997448', '#b09062', '#644528', '#8a6b42', '#523820'];

  // 7A. 3D Curled Fallen Dry Leaves along forest shoulders & embankments
  const dryLeafTiles = new Map<string, { mats: THREE.Matrix4[]; cols: THREE.Color[] }>();
  const dryLeafTotal = Math.floor(18000 * opts.grass);
  for (let k = 0; k < dryLeafTotal; k++) {
    const f = route.at(v3Rng() * route.length);
    const side = v3Rng() < 0.5 ? -1 : 1;
    const a = roadHalf + 0.3 + Math.pow(v3Rng(), 1.8) * 14.5;
    const along = randRange(v3Rng, -0.8, 0.8);
    const px = f.x - f.tz * a * side + f.tx * along;
    const pz = f.z + f.tx * a * side + f.tz * along;
    if (!inside(px, pz)) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;
    const n = sampleTerrainNormal(px, pz);
    qAlign.setFromUnitVectors(UP, n);
    qSpin.setFromEuler(new THREE.Euler(randRange(v3Rng, -0.32, 0.32), v3Rng() * Math.PI * 2, randRange(v3Rng, -0.32, 0.32)));
    dummy.position.set(px, g.y + randRange(v3Rng, 0.005, 0.025), pz);
    dummy.quaternion.copy(qAlign).multiply(qSpin);
    const scL = randRange(v3Rng, 0.9, 1.9);
    dummy.scale.set(scL, scL * randRange(v3Rng, 0.85, 1.3), scL * randRange(v3Rng, 0.8, 1.25));
    dummy.updateMatrix();
    const c = new THREE.Color(leafPalette[Math.floor(v3Rng() * leafPalette.length)]);
    c.offsetHSL(randRange(v3Rng, -0.02, 0.02), randRange(v3Rng, -0.06, 0.06), randRange(v3Rng, -0.06, 0.06));
    const tk = `${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let bucket = dryLeafTiles.get(tk);
    if (!bucket) { bucket = { mats: [], cols: [] }; dryLeafTiles.set(tk, bucket); }
    bucket.mats.push(dummy.matrix.clone());
    bucket.cols.push(c);
  }
  for (const bucket of dryLeafTiles.values()) {
    const im = new THREE.InstancedMesh(dryLeafGeo, v3Mats.dryLeafScatter, bucket.mats.length);
    for (let i = 0; i < bucket.mats.length; i++) {
      im.setMatrixAt(i, bucket.mats[i]);
      im.setColorAt(i, bucket.cols[i]);
    }
    im.receiveShadow = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // 7B. Wind-blown dry fallen leaves scattered along both asphalt shoulders (without sidewalks)
  const roadLeafTiles = new Map<string, { mats: THREE.Matrix4[]; cols: THREE.Color[] }>();
  const roadLeafTotal = Math.floor(6500 * opts.grass);
  for (let k = 0; k < roadLeafTotal; k++) {
    const s = spec.start + v3Rng() * (spec.finish - spec.start);
    const f = route.at(s);
    const side = v3Rng() < 0.5 ? -1 : 1;
    const edgePen = Math.pow(v3Rng(), 2.2) * 1.28;
    const lat = (roadHalf - edgePen + 0.1) * side;
    const px = f.x - f.tz * lat;
    const pz = f.z + f.tx * lat;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void) continue;
    dummy.position.set(px, g.y + 0.014, pz);
    dummy.rotation.set(randRange(v3Rng, -0.14, 0.14), v3Rng() * Math.PI * 2, randRange(v3Rng, -0.14, 0.14));
    const scR = randRange(v3Rng, 0.85, 1.55);
    dummy.scale.set(scR, scR, scR);
    dummy.updateMatrix();
    const c = new THREE.Color(leafPalette[Math.floor(v3Rng() * leafPalette.length)]);
    const tk = `${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let bucket = roadLeafTiles.get(tk);
    if (!bucket) { bucket = { mats: [], cols: [] }; roadLeafTiles.set(tk, bucket); }
    bucket.mats.push(dummy.matrix.clone());
    bucket.cols.push(c);
  }
  for (const bucket of roadLeafTiles.values()) {
    const im = new THREE.InstancedMesh(strayLeafGeo, v3Mats.dryLeafScatter, bucket.mats.length);
    for (let i = 0; i < bucket.mats.length; i++) {
      im.setMatrixAt(i, bucket.mats[i]);
      im.setColorAt(i, bucket.cols[i]);
    }
    im.receiveShadow = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // 7C. 3D Pine Needle Thatch & Fallen Twigs along roadside embankments
  const pineTuftTiles = new Map<string, { mats: THREE.Matrix4[]; cols: THREE.Color[] }>();
  const twigTiles = new Map<string, { mats: THREE.Matrix4[]; cols: THREE.Color[] }>();
  const pineTotal = Math.floor(8500 * opts.grass);
  for (let k = 0; k < pineTotal; k++) {
    const f = route.at(v3Rng() * route.length);
    const side = v3Rng() < 0.5 ? -1 : 1;
    const a = roadHalf + 0.55 + Math.pow(v3Rng(), 1.6) * 12;
    const px = f.x - f.tz * a * side;
    const pz = f.z + f.tx * a * side;
    if (!inside(px, pz)) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;
    const n = sampleTerrainNormal(px, pz);
    qAlign.setFromUnitVectors(UP, n);
    qSpin.setFromAxisAngle(UP, v3Rng() * Math.PI * 2);
    dummy.position.set(px, g.y + 0.004, pz);
    dummy.quaternion.copy(qAlign).multiply(qSpin);
    const sP = randRange(v3Rng, 0.9, 2.0);
    dummy.scale.set(sP, randRange(v3Rng, 0.75, 1.45), sP);
    dummy.updateMatrix();
    const tk = `${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let bucket = pineTuftTiles.get(tk);
    if (!bucket) { bucket = { mats: [], cols: [] }; pineTuftTiles.set(tk, bucket); }
    bucket.mats.push(dummy.matrix.clone());
    bucket.cols.push(new THREE.Color(needlePalette[Math.floor(v3Rng() * needlePalette.length)]));

    if (k % 8 === 0) {
      qSpin.setFromEuler(new THREE.Euler(randRange(v3Rng, -0.14, 0.14), v3Rng() * Math.PI * 2, randRange(v3Rng, -0.14, 0.14)));
      dummy.position.set(px, g.y + 0.01, pz);
      dummy.quaternion.copy(qAlign).multiply(qSpin);
      const lenScale = randRange(v3Rng, 0.7, 2.2);
      const thickScale = randRange(v3Rng, 0.7, 1.7);
      dummy.scale.set(lenScale, thickScale, thickScale);
      dummy.updateMatrix();
      const shade = randRange(v3Rng, 0.72, 1.3);
      let tb = twigTiles.get(tk);
      if (!tb) { tb = { mats: [], cols: [] }; twigTiles.set(tk, tb); }
      tb.mats.push(dummy.matrix.clone());
      tb.cols.push(new THREE.Color(shade, shade * 0.96, shade * 0.9));
    }
  }
  for (const bucket of pineTuftTiles.values()) {
    const im = new THREE.InstancedMesh(pineTuftGeo, v3Mats.pineNeedleThatch, bucket.mats.length);
    for (let i = 0; i < bucket.mats.length; i++) {
      im.setMatrixAt(i, bucket.mats[i]);
      im.setColorAt(i, bucket.cols[i]);
    }
    im.receiveShadow = true;
    im.computeBoundingSphere();
    group.add(im);
  }
  for (const bucket of twigTiles.values()) {
    const im = new THREE.InstancedMesh(twigGeo, v3Mats.wildStems, bucket.mats.length);
    for (let i = 0; i < bucket.mats.length; i++) {
      im.setMatrixAt(i, bucket.mats[i]);
      im.setColorAt(i, bucket.cols[i]);
    }
    im.castShadow = true;
    im.receiveShadow = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // ---------------- 8. V3 MOSSY ROCKS ----------------
  const rockGeo = new THREE.IcosahedronGeometry(1, 3);
  {
    const p = rockGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const v = new V(p.getX(i), p.getY(i), p.getZ(i));
      const dir = v.clone().normalize();
      const n1 = fbm2D(dir.x * 2.2 + 7, dir.z * 2.2 + dir.y * 1.9, 3, 2.0, 0.5, 7);
      const n2 = ridgedNoise2D(dir.x * 4.5 + 3.5, dir.z * 4.5 + dir.y * 3.8, 2, 24);
      v.multiplyScalar(0.72 + n1 * 0.42 + n2 * 0.16);
      v.y *= 0.62;
      p.setXYZ(i, v.x, v.y, v.z);
    }
    rockGeo.computeVertexNormals();
    const uv = new Float32Array(p.count * 2);
    for (let i = 0; i < p.count; i++) {
      uv[i * 2] = p.getX(i) * 0.5 + p.getZ(i) * 0.3;
      uv[i * 2 + 1] = p.getY(i) * 0.5;
    }
    rockGeo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  }
  const rockTiles = new Map<string, THREE.Matrix4[]>();
  for (let k = 0; k < 950; k++) {
    const f = route.at(rng() * route.length);
    const side = rng() < 0.7 ? 1 : -1;
    const a = roadHalf + 1.8 + rng() * 22;
    const px = f.x - f.tz * a * side;
    const pz = f.z + f.tx * a * side;
    if (!inside(px, pz)) continue;
    const info = route.nearest(px, pz);
    if (info.dist < roadHalf + 1.7) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;
    const sVal = rand(rng, 0.15, 0.7) * (rng() < 0.08 ? 2.2 : 1);
    pos.set(px, g.y - sVal * 0.2, pz);
    e.set(rand(rng, -0.4, 0.4), rand(rng, 0, 6.28), rand(rng, -0.4, 0.4));
    q.setFromEuler(e);
    sc.set(sVal * rand(rng, 0.8, 1.4), sVal, sVal * rand(rng, 0.8, 1.3));
    const tileKey = `${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let list = rockTiles.get(tileKey);
    if (!list) { list = []; rockTiles.set(tileKey, list); }
    list.push(new THREE.Matrix4().compose(pos, q, sc));
  }
  for (const list of rockTiles.values()) {
    const rocks = new THREE.InstancedMesh(rockGeo, v3Mats.mossyRock, list.length);
    list.forEach((m, i) => rocks.setMatrixAt(i, m));
    rocks.castShadow = true;
    rocks.receiveShadow = true;
    rocks.computeBoundingSphere();
    group.add(rocks);
  }

  // ---------------- 9. V2 DRIFT SMOKE / ROAD HAZE ----------------
  const smokeUniforms = {
    uTime: globalUniforms.uTime,
    uMap: { value: v2Tex.smoke },
    uSun: { value: new THREE.Color(1, 0.95, 0.85) },
    uAmb: { value: new THREE.Color(0.62, 0.7, 0.72) },
    uFogColor: { value: new THREE.Color('#a6bab2') },
    uFogDensity: { value: 0.0029 },
    uOpacity: { value: 1 },
  };
  const smokeMat = new THREE.ShaderMaterial({
    uniforms: smokeUniforms,
    transparent: true,
    depthWrite: false,
    vertexShader: /* glsl */ `
      attribute vec4 aData;
      uniform float uTime;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vFogDepth;
      void main() {
        vec3 c = (instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        float life = fract(uTime * aData.y + aData.x);
        float ang = aData.w * 6.2831;
        c += vec3(cos(ang) * life * 3.5 + life * 2.5, life * life * 3.5 + 0.3, sin(ang) * life * 3.5);
        float size = aData.z * (0.6 + life * 2.2);
        vec4 mv = viewMatrix * vec4(c, 1.0);
        float rot = aData.w * 6.28 + uTime * 0.08 * (aData.w - 0.5);
        vec2 p = mat2(cos(rot), -sin(rot), sin(rot), cos(rot)) * position.xy;
        mv.xy += p * size;
        vAlpha = smoothstep(0.0, 0.12, life) * pow(1.0 - life, 1.4);
        vUv = uv;
        vFogDepth = -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uMap;
      uniform vec3 uSun;
      uniform vec3 uAmb;
      uniform vec3 uFogColor;
      uniform float uFogDensity;
      uniform float uOpacity;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vFogDepth;
      void main() {
        vec4 t = texture2D(uMap, vUv);
        vec3 col = mix(uAmb, uSun, 0.35 + 0.3 * vUv.y) * 1.05;
        float f = 1.0 - exp(-uFogDensity * uFogDensity * vFogDepth * vFogDepth);
        col = mix(col, uFogColor, f * 0.6);
        gl_FragColor = vec4(col, t.a * vAlpha * 0.2 * uOpacity);
        #include <colorspace_fragment>
      }`,
  });
  const plane = new THREE.PlaneGeometry(1, 1);
  const smokeSpots = [
    { s: spec.start + 135, spread: 45, count: 55 },
    { s: spec.start + 520, spread: 50, count: 55 },
    { s: spec.start + 1150, spread: 60, count: 60 },
  ];
  const smokeTotal = smokeSpots.reduce((acc, x) => acc + x.count, 0);
  const smoke = new THREE.InstancedMesh(plane, smokeMat, smokeTotal);
  const aData = new Float32Array(smokeTotal * 4);
  let si = 0;
  for (const sp of smokeSpots) {
    for (let k = 0; k < sp.count; k++) {
      const f = route.at(sp.s + rand(rng, 0, sp.spread));
      const off = rand(rng, -3.4, 3.4);
      pos.set(f.x - f.tz * off, f.y + 0.25, f.z + f.tx * off);
      smoke.setMatrixAt(si, new THREE.Matrix4().makeTranslation(pos.x, pos.y, pos.z));
      aData.set([rng(), rand(rng, 0.025, 0.05), rand(rng, 2.2, 4.2), rng()], si * 4);
      si++;
    }
  }
  plane.setAttribute('aData', new THREE.InstancedBufferAttribute(aData, 4));
  smoke.frustumCulled = false;
  smoke.renderOrder = 10;
  smoke.visible = false;
  group.add(smoke);

  // ---------------- 10. V2 DUST MOTES ----------------
  const dustN = 5200;
  const dPos = new Float32Array(dustN * 3);
  for (let k = 0; k < dustN; k++) {
    const f = route.at(rng() * route.length);
    const off = rand(rng, -16, 16);
    dPos.set([f.x - f.tz * off, f.y + rand(rng, 0.3, 9), f.z + f.tx * off], k * 3);
  }
  const dGeo = new THREE.BufferGeometry();
  dGeo.setAttribute('position', new THREE.BufferAttribute(dPos, 3));
  const dustMat = new THREE.ShaderMaterial({
    uniforms: { uTime: globalUniforms.uTime },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      uniform float uTime;
      varying float vA;
      void main() {
        vec3 p = position;
        float s = fract(sin(dot(p.xz, vec2(12.9, 78.2))) * 437.5);
        p += vec3(sin(uTime * 0.3 + s * 20.0) * 0.6, sin(uTime * 0.21 + s * 9.0) * 0.4, cos(uTime * 0.27 + s * 14.0) * 0.6);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = clamp(26.0 / -mv.z, 1.0, 5.0);
        vA = (0.4 + 0.6 * sin(uTime * 1.5 + s * 30.0)) * smoothstep(40.0, 4.0, -mv.z);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vA;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.0, d) * vA * 0.35;
        gl_FragColor = vec4(vec3(1.0, 0.95, 0.8) * a, a);
      }`,
  });
  const dust = new THREE.Points(dGeo, dustMat);
  dust.frustumCulled = false;
  group.add(dust);

  let elapsed = 0;
  function tick(dt: number) {
    elapsed += dt;
    globalUniforms.uTime.value = elapsed;
  }

  function syncSun(dir: THREE.Vector3, col: THREE.Color) {
    v3FoliageUniforms.uSunDirection.value.copy(dir);
    v3FoliageUniforms.uSunColor.value.copy(col);
  }

  return {
    groundAt,
    tick,
    syncSun,
    treeCount,
    smokeBinding: { smoke, smokeUniforms },
    setOpenTerrain(enabled: boolean) {
      original.guardrails.visible = !enabled;
    },
  };
}

function renderV3Relief(
  grid: ReliefGrid,
  stride: number,
  material: THREE.Material,
  colorAt: (x: number, z: number) => readonly [number, number, number],
  shadow: boolean,
) {
  const { bounds, cell, nx, nz, width, heights } = grid;
  const group = new THREE.Group();
  for (let iz = 0; iz < nz; iz += stride) {
    for (let ix = 0; ix < nx; ix += stride) {
      const w = Math.min(stride, nx - ix);
      const h = Math.min(stride, nz - iz);
      const positions: number[] = [];
      const uv: number[] = [];
      const colors: number[] = [];
      const indices: number[] = [];
      for (let z = 0; z <= h; z++) {
        for (let x = 0; x <= w; x++) {
          const gx = ix + x;
          const gz = iz + z;
          const index = gx + gz * width;
          const wx = bounds.x0 + gx * cell;
          const wz = bounds.z0 + gz * cell;
          const y = heights[index];
          const [cr, cg, cb] = colorAt(wx, wz);
          positions.push(wx, y, wz);
          uv.push(wx / 3.4, wz / 3.4);
          colors.push(cr, cg, cb);
          if (x < w && z < h && grid.filled(gx, gz)) {
            const a = x + z * (w + 1);
            const b = a + w + 1;
            if (grid.alternate(gx, gz)) indices.push(a, b, b + 1, a, b + 1, a + 1);
            else indices.push(a, b, a + 1, a + 1, b, b + 1);
          }
        }
      }
      if (indices.length) {
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
        geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        geo.setIndex(indices);
        geo.computeVertexNormals();
        const mesh = new THREE.Mesh(geo, material);
        mesh.receiveShadow = shadow;
        group.add(mesh);
      }
    }
  }
  return group;
}
