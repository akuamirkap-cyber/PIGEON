import * as THREE from 'three';
import { createRng, randRange, tileableFbm2D } from './noise';

export interface PBRTextureSet {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
}

function configureTexture(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  repeat = false,
  anisotropy = 16
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  if (repeat) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
  } else {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
  }
  tex.anisotropy = anisotropy;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

function heightToNormalCanvas(
  heightCanvas: HTMLCanvasElement,
  strength: number,
  wrap: boolean
): HTMLCanvasElement {
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const srcCtx = heightCanvas.getContext('2d')!;
  const src = srcCtx.getImageData(0, 0, w, h).data;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = w;
  outCanvas.height = h;
  const outCtx = outCanvas.getContext('2d')!;
  const outImg = outCtx.createImageData(w, h);
  const dst = outImg.data;

  const sample = (x: number, y: number): number => {
    let sx = x;
    let sy = y;
    if (wrap) {
      sx = ((x % w) + w) % w;
      sy = ((y % h) + h) % h;
    } else {
      sx = Math.max(0, Math.min(w - 1, x));
      sy = Math.max(0, Math.min(h - 1, y));
    }
    return src[(sy * w + sx) * 4] / 255;
  };

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const tl = sample(x - 1, y - 1);
      const t = sample(x, y - 1);
      const tr = sample(x + 1, y - 1);
      const l = sample(x - 1, y);
      const r = sample(x + 1, y);
      const bl = sample(x - 1, y + 1);
      const b = sample(x, y + 1);
      const br = sample(x + 1, y + 1);

      const dx = (tr + 2 * r + br - (tl + 2 * l + bl)) * strength;
      const dy = (bl + 2 * b + br - (tl + 2 * t + tr)) * strength;
      const dz = 1.0;

      const invLen = 1.0 / Math.sqrt(dx * dx + dy * dy + dz * dz);
      const nx = -dx * invLen;
      const ny = -dy * invLen;
      const nz = dz * invLen;

      const idx = (y * w + x) * 4;
      dst[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      dst[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      dst[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      dst[idx + 3] = 255;
    }
  }

  outCtx.putImageData(outImg, 0, 0);
  return outCanvas;
}

function drawWrapped(
  size: number,
  x: number,
  y: number,
  margin: number,
  drawFn: (ox: number, oy: number) => void
) {
  const oxList = [0];
  const oyList = [0];
  if (x < margin) oxList.push(size);
  if (x > size - margin) oxList.push(-size);
  if (y < margin) oyList.push(size);
  if (y > size - margin) oyList.push(-size);

  for (let i = 0; i < oxList.length; i++) {
    for (let j = 0; j < oyList.length; j++) {
      drawFn(x + oxList[i], y + oyList[j]);
    }
  }
}

function paintBotanicalLeaf(
  aCtx: CanvasRenderingContext2D,
  hCtx: CanvasRenderingContext2D,
  rCtx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  length: number,
  width: number,
  colorBase: string,
  colorTip: string,
  colorVein: string,
  lobed: boolean,
  heightLevel: number
) {
  const drawLeafOutline = (ctx: CanvasRenderingContext2D) => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    if (lobed) {
      ctx.bezierCurveTo(length * 0.15, -width * 0.55, length * 0.32, -width * 0.85, length * 0.48, -width * 0.48);
      ctx.bezierCurveTo(length * 0.62, -width * 0.65, length * 0.82, -width * 0.35, length, 0);
      ctx.bezierCurveTo(length * 0.82, width * 0.35, length * 0.62, width * 0.65, length * 0.48, width * 0.48);
      ctx.bezierCurveTo(length * 0.32, width * 0.85, length * 0.15, width * 0.55, 0, 0);
    } else {
      ctx.bezierCurveTo(length * 0.22, -width * 0.68, length * 0.66, -width * 0.58, length, 0);
      ctx.bezierCurveTo(length * 0.66, width * 0.58, length * 0.22, width * 0.68, 0, 0);
    }
    ctx.closePath();
  };

  aCtx.save();
  aCtx.translate(x, y);
  aCtx.rotate(angle);

  const grad = aCtx.createLinearGradient(0, 0, length, 0);
  grad.addColorStop(0, colorBase);
  grad.addColorStop(0.58, colorTip);
  grad.addColorStop(1, colorTip);

  drawLeafOutline(aCtx);
  aCtx.fillStyle = grad;
  aCtx.fill();

  aCtx.save();
  aCtx.clip();
  aCtx.fillStyle = 'rgba(255, 255, 210, 0.11)';
  aCtx.fillRect(0, -width, length, width);
  aCtx.fillStyle = 'rgba(10, 28, 6, 0.12)';
  aCtx.fillRect(0, 0, length, width);
  aCtx.restore();

  aCtx.strokeStyle = colorVein;
  aCtx.lineWidth = Math.max(1.0, width * 0.045);
  aCtx.beginPath();
  aCtx.moveTo(0, 0);
  aCtx.lineTo(length * 0.94, 0);
  aCtx.stroke();

  aCtx.lineWidth = Math.max(0.65, width * 0.024);
  for (let v = 1; v <= 5; v++) {
    const t = v / 6.2;
    const vx = length * t;
    const span = width * (0.48 - Math.abs(t - 0.45) * 0.55);
    aCtx.beginPath();
    aCtx.moveTo(vx, 0);
    aCtx.lineTo(vx + length * 0.14, -span);
    aCtx.moveTo(vx, 0);
    aCtx.lineTo(vx + length * 0.14, span);
    aCtx.stroke();
  }
  aCtx.restore();

  hCtx.save();
  hCtx.translate(x, y);
  hCtx.rotate(angle);
  const hGrad = hCtx.createLinearGradient(0, -width * 0.7, 0, width * 0.7);
  const hHi = Math.min(255, heightLevel + 35);
  const hLo = Math.max(10, heightLevel - 28);
  hGrad.addColorStop(0, `rgb(${hHi},${hHi},${hHi})`);
  hGrad.addColorStop(0.5, `rgb(${hLo},${hLo},${hLo})`);
  hGrad.addColorStop(1, `rgb(${hHi},${hHi},${hHi})`);
  drawLeafOutline(hCtx);
  hCtx.fillStyle = hGrad;
  hCtx.fill();
  hCtx.restore();

  rCtx.save();
  rCtx.translate(x, y);
  rCtx.rotate(angle);
  drawLeafOutline(rCtx);
  rCtx.fillStyle = 'rgb(122, 122, 122)';
  rCtx.fill();
  rCtx.restore();
}

/**
 * 1. ULTRA-HD FOREST FLOOR MULCH, PINE NEEDLES & DRY FALLEN LEAVES (2048x2048 seamless PBR)
 * From realistic-3d-nature-assets.zip
 */
function createForestFloorPBR(anisotropy: number): PBRTextureSet {
  const size = 2048;
  const baseSize = 512;
  const rng = createRng(202604);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const baseA = document.createElement('canvas');
  baseA.width = baseSize;
  baseA.height = baseSize;
  const baCtx = baseA.getContext('2d')!;
  const baseH = document.createElement('canvas');
  baseH.width = baseSize;
  baseH.height = baseSize;
  const bhCtx = baseH.getContext('2d')!;
  const baseR = document.createElement('canvas');
  baseR.width = baseSize;
  baseR.height = baseSize;
  const brCtx = baseR.getContext('2d')!;

  const aImg = baCtx.createImageData(baseSize, baseSize);
  const hImg = bhCtx.createImageData(baseSize, baseSize);
  const rImg = brCtx.createImageData(baseSize, baseSize);

  for (let y = 0; y < baseSize; y++) {
    for (let x = 0; x < baseSize; x++) {
      const u = x / baseSize;
      const v = y / baseSize;
      const macro = tileableFbm2D(u, v, 6, 4, 301);
      const micro = tileableFbm2D(u, v, 24, 3, 719);
      const grit = tileableFbm2D(u, v, 64, 2, 911);

      const val = macro * 0.55 + micro * 0.3 + grit * 0.15;
      const mossMask = Math.max(0, tileableFbm2D(u, v, 5, 3, 444) - 0.62) * 2.2;

      const idx = (y * baseSize + x) * 4;
      let r = 34 + val * 44;
      let g = 25 + val * 32;
      let b = 17 + val * 22;

      if (mossMask > 0) {
        r = r * (1 - mossMask * 0.35) + 46 * (mossMask * 0.35);
        g = g * (1 - mossMask * 0.35) + 60 * (mossMask * 0.35);
        b = b * (1 - mossMask * 0.35) + 25 * (mossMask * 0.35);
      }

      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(35 + val * 70);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      const rVal = Math.round(188 + (1 - val) * 45);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }
  baCtx.putImageData(aImg, 0, 0);
  bhCtx.putImageData(hImg, 0, 0);
  brCtx.putImageData(rImg, 0, 0);
  aCtx.drawImage(baseA, 0, 0, size, size);
  hCtx.drawImage(baseH, 0, 0, size, size);
  rCtx.drawImage(baseR, 0, 0, size, size);

  const needlePalettes = [
    '#5c3e24', '#6e4b2c', '#7c5936', '#8c6b43',
    '#49321e', '#9d7e54', '#3d2918', '#a88c63',
  ];

  const drawNeedles = (count: number, minH: number, maxH: number) => {
    for (let i = 0; i < count; i++) {
      const x = rng() * size;
      const y = rng() * size;
      const len = randRange(rng, 28, 78);
      const angle = rng() * Math.PI * 2;
      const bend = randRange(rng, -12, 12);
      const width = randRange(rng, 1.4, 3.2);
      const col = needlePalettes[Math.floor(rng() * needlePalettes.length)];
      const hShade = Math.round(randRange(rng, minH, maxH));
      const rShade = Math.round(randRange(rng, 205, 240));

      drawWrapped(size, x, y, len + 10, (ox, oy) => {
        const ex = ox + Math.cos(angle) * len;
        const ey = oy + Math.sin(angle) * len;
        const cx = (ox + ex) * 0.5 - Math.sin(angle) * bend;
        const cy = (oy + ey) * 0.5 + Math.cos(angle) * bend;

        aCtx.strokeStyle = 'rgba(18, 11, 6, 0.35)';
        aCtx.lineWidth = width + 2.0;
        aCtx.lineCap = 'round';
        aCtx.beginPath();
        aCtx.moveTo(ox + 1.8, oy + 2.2);
        aCtx.quadraticCurveTo(cx + 1.8, cy + 2.2, ex + 1.8, ey + 2.2);
        aCtx.stroke();

        aCtx.strokeStyle = col;
        aCtx.lineWidth = width;
        aCtx.beginPath();
        aCtx.moveTo(ox, oy);
        aCtx.quadraticCurveTo(cx, cy, ex, ey);
        aCtx.stroke();

        hCtx.strokeStyle = `rgb(${hShade},${hShade},${hShade})`;
        hCtx.lineWidth = width + 0.8;
        hCtx.lineCap = 'round';
        hCtx.beginPath();
        hCtx.moveTo(ox, oy);
        hCtx.quadraticCurveTo(cx, cy, ex, ey);
        hCtx.stroke();

        rCtx.strokeStyle = `rgb(${rShade},${rShade},${rShade})`;
        rCtx.lineWidth = width + 0.8;
        rCtx.beginPath();
        rCtx.moveTo(ox, oy);
        rCtx.quadraticCurveTo(cx, cy, ex, ey);
        rCtx.stroke();
      });
    }
  };

  drawNeedles(3400, 75, 130);

  const leafColors = [
    { base: '#6f4827', edge: '#4d3018', vein: '#855c37' },
    { base: '#8a5d34', edge: '#5f3c1e', vein: '#a37548' },
    { base: '#b6976c', edge: '#896d49', vein: '#ccb088' },
    { base: '#c9b28a', edge: '#967e59', vein: '#dfd0ae' },
    { base: '#573a21', edge: '#372312', vein: '#6c492b' },
    { base: '#9e7446', edge: '#6f4f2c', vein: '#b58b5c' },
    { base: '#4a3523', edge: '#2b1d12', vein: '#5d442e' },
    { base: '#7d633d', edge: '#554126', vein: '#947950' },
  ];

  const drawDryLeafShape = (
    ctx: CanvasRenderingContext2D,
    len: number,
    wid: number,
    curl: number
  ) => {
    ctx.beginPath();
    ctx.moveTo(-len * 0.5, 0);
    ctx.bezierCurveTo(
      -len * 0.25,
      -wid * (0.95 + curl * 0.2),
      len * 0.22,
      -wid * (0.75 - curl * 0.15),
      len * 0.52,
      curl * wid * 0.25
    );
    ctx.bezierCurveTo(
      len * 0.22,
      wid * (0.85 + curl * 0.15),
      -len * 0.25,
      wid * (0.9 - curl * 0.2),
      -len * 0.5,
      0
    );
    ctx.closePath();
  };

  const leafCount = 2400;
  for (let i = 0; i < leafCount; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = randRange(rng, 24, 68);
    const wid = len * randRange(rng, 0.28, 0.52);
    const angle = rng() * Math.PI * 2;
    const curl = randRange(rng, -0.6, 0.6);
    const pal = leafColors[Math.floor(rng() * leafColors.length)];
    const progress = i / leafCount;
    const hBase = Math.round(95 + progress * 135);
    const rShade = Math.round(randRange(rng, 175, 232));

    drawWrapped(size, x, y, len + 16, (ox, oy) => {
      aCtx.save();
      aCtx.translate(ox, oy);
      aCtx.rotate(angle);

      aCtx.save();
      aCtx.translate(3.0, 3.8);
      drawDryLeafShape(aCtx, len * 1.03, wid * 1.03, curl);
      aCtx.fillStyle = 'rgba(14, 9, 4, 0.42)';
      aCtx.fill();
      aCtx.restore();

      const grad = aCtx.createLinearGradient(0, -wid, 0, wid);
      grad.addColorStop(0, pal.edge);
      grad.addColorStop(0.45, pal.base);
      grad.addColorStop(0.8, pal.vein);
      grad.addColorStop(1, pal.edge);
      drawDryLeafShape(aCtx, len, wid, curl);
      aCtx.fillStyle = grad;
      aCtx.fill();

      aCtx.strokeStyle = pal.edge;
      aCtx.lineWidth = 1.1;
      aCtx.stroke();

      aCtx.strokeStyle = pal.vein;
      aCtx.lineWidth = 1.0;
      aCtx.beginPath();
      aCtx.moveTo(-len * 0.48, 0);
      aCtx.quadraticCurveTo(0, curl * wid * 0.15, len * 0.48, curl * wid * 0.22);
      aCtx.stroke();
      aCtx.restore();

      hCtx.save();
      hCtx.translate(ox, oy);
      hCtx.rotate(angle);
      const hGrad = hCtx.createLinearGradient(0, -wid, 0, wid);
      const hLow = Math.max(20, hBase - 38);
      const hHigh = Math.min(255, hBase + 22);
      hGrad.addColorStop(0, `rgb(${hHigh},${hHigh},${hHigh})`);
      hGrad.addColorStop(0.45, `rgb(${hLow},${hLow},${hLow})`);
      hGrad.addColorStop(0.55, `rgb(${hBase},${hBase},${hBase})`);
      hGrad.addColorStop(1, `rgb(${hHigh},${hHigh},${hHigh})`);
      drawDryLeafShape(hCtx, len, wid, curl);
      hCtx.fillStyle = hGrad;
      hCtx.fill();
      hCtx.restore();

      rCtx.save();
      rCtx.translate(ox, oy);
      rCtx.rotate(angle);
      drawDryLeafShape(rCtx, len, wid, curl);
      rCtx.fillStyle = `rgb(${rShade},${rShade},${rShade})`;
      rCtx.fill();
      rCtx.restore();
    });

    if (i === 1450) {
      drawNeedles(1600, 145, 220);
    }
  }

  for (let i = 0; i < 140; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = randRange(rng, 35, 115);
    const angle = rng() * Math.PI * 2;
    const thick = randRange(rng, 3.0, 6.8);
    const twigCol = rng() > 0.45 ? '#6e5c4a' : '#897a68';

    drawWrapped(size, x, y, len + 16, (ox, oy) => {
      const ex = ox + Math.cos(angle) * len;
      const ey = oy + Math.sin(angle) * len;
      const mx = (ox + ex) * 0.5 + randRange(rng, -8, 8);
      const my = (oy + ey) * 0.5 + randRange(rng, -8, 8);

      aCtx.strokeStyle = 'rgba(12, 8, 5, 0.5)';
      aCtx.lineWidth = thick + 3;
      aCtx.lineCap = 'round';
      aCtx.beginPath();
      aCtx.moveTo(ox + 3, oy + 3.8);
      aCtx.lineTo(mx + 3, my + 3.8);
      aCtx.lineTo(ex + 3, ey + 3.8);
      aCtx.stroke();

      aCtx.strokeStyle = twigCol;
      aCtx.lineWidth = thick;
      aCtx.beginPath();
      aCtx.moveTo(ox, oy);
      aCtx.lineTo(mx, my);
      aCtx.lineTo(ex, ey);
      aCtx.stroke();

      hCtx.strokeStyle = 'rgb(245,245,245)';
      hCtx.lineWidth = thick + 1.5;
      hCtx.lineCap = 'round';
      hCtx.beginPath();
      hCtx.moveTo(ox, oy);
      hCtx.lineTo(mx, my);
      hCtx.lineTo(ex, ey);
      hCtx.stroke();
    });
  }

  drawNeedles(900, 195, 248);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.8, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 2. SINGLE DRY FALLEN LEAF ALPHA CARD (512x512 HD)
 */
function createDryLeafCardPBR(anisotropy: number): PBRTextureSet {
  const size = 512;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(30,30,30)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(210,210,210)';
  rCtx.fillRect(0, 0, size, size);

  paintBotanicalLeaf(
    aCtx,
    hCtx,
    rCtx,
    size * 0.08,
    size * 0.5,
    0,
    size * 0.84,
    size * 0.42,
    '#b8a384',
    '#e3d4b8',
    '#cbb796',
    true,
    170
  );

  aCtx.strokeStyle = '#6e583f';
  aCtx.lineWidth = 6;
  aCtx.beginPath();
  aCtx.moveTo(size * 0.02, size * 0.5);
  aCtx.lineTo(size * 0.14, size * 0.5);
  aCtx.stroke();

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.4, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 3. WILD FOREST SHRUB SPRIG PBR (1024x1024 HD alpha-cutout)
 */
function createShrubSprigPBR(anisotropy: number): PBRTextureSet {
  const size = 1024;
  const rng = createRng(5231);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(24,24,24)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(122,122,122)';
  rCtx.fillRect(0, 0, size, size);

  const palettes = [
    { base: '#234914', tip: '#487d1e', vein: '#649a31' },
    { base: '#2d5a17', tip: '#5d9623', vein: '#7cb239' },
    { base: '#1b3a10', tip: '#346319', vein: '#4d7c29' },
    { base: '#386b1a', tip: '#6ca828', vein: '#8bc33f' },
  ];

  const drawBranchStem = (
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    thick0: number,
    thick1: number
  ) => {
    const mx = (x0 + x1) * 0.5 + randRange(rng, -24, 24);
    const my = (y0 + y1) * 0.5 + randRange(rng, -18, 18);

    aCtx.strokeStyle = '#3d3022';
    aCtx.lineCap = 'round';
    aCtx.lineWidth = (thick0 + thick1) * 0.5;
    aCtx.beginPath();
    aCtx.moveTo(x0, y0);
    aCtx.quadraticCurveTo(mx, my, x1, y1);
    aCtx.stroke();

    hCtx.strokeStyle = 'rgb(140,140,140)';
    hCtx.lineCap = 'round';
    hCtx.lineWidth = (thick0 + thick1) * 0.5;
    hCtx.beginPath();
    hCtx.moveTo(x0, y0);
    hCtx.quadraticCurveTo(mx, my, x1, y1);
    hCtx.stroke();
  };

  interface TwigAnchor {
    x: number;
    y: number;
    angle: number;
    scale: number;
  }

  const anchors: TwigAnchor[] = [];
  const mainBaseX = size * 0.5;
  const mainBaseY = size * 0.96;
  const mainTopX = size * 0.5 + randRange(rng, -45, 45);
  const mainTopY = size * 0.14;
  drawBranchStem(mainBaseX, mainBaseY, mainTopX, mainTopY, 13, 3.5);

  const subBranches = 9;
  for (let b = 0; b < subBranches; b++) {
    const t = 0.12 + (b / (subBranches - 1)) * 0.76;
    const bx = mainBaseX + (mainTopX - mainBaseX) * t;
    const by = mainBaseY + (mainTopY - mainBaseY) * t;
    const side = b % 2 === 0 ? -1 : 1;
    const reach = size * randRange(rng, 0.26, 0.44) * (1.12 - Math.abs(t - 0.48) * 0.72);
    const branchAngle = -Math.PI * 0.5 + side * randRange(rng, 0.48, 1.24);
    const ex = Math.max(64, Math.min(size - 64, bx + Math.cos(branchAngle) * reach));
    const ey = Math.max(64, Math.min(size - 96, by + Math.sin(branchAngle) * reach));

    drawBranchStem(bx, by, ex, ey, 6.2 * (1 - t * 0.4), 1.9);

    const leavesPerTwig = 8;
    for (let k = 0; k < leavesPerTwig; k++) {
      const lt = 0.16 + (k / (leavesPerTwig - 1)) * 0.88;
      const lx = bx + (ex - bx) * lt;
      const ly = by + (ey - by) * lt;
      const leafSide = k % 2 === 0 ? -1 : 1;
      const spreadAngle =
        branchAngle + (k === leavesPerTwig - 1 ? 0 : leafSide * randRange(rng, 0.42, 1.08));
      anchors.push({
        x: lx,
        y: ly,
        angle: spreadAngle,
        scale: randRange(rng, 0.62, 1.02) * (1.06 - lt * 0.26),
      });
    }
  }

  for (let c = 0; c < 9; c++) {
    anchors.push({
      x: mainTopX + randRange(rng, -28, 28),
      y: mainTopY + randRange(rng, -14, 46),
      angle: -Math.PI * 0.5 + randRange(rng, -1.25, 1.25),
      scale: randRange(rng, 0.58, 0.92),
    });
  }

  anchors.forEach((anc, idx) => {
    const pal = palettes[Math.floor(rng() * palettes.length)];
    const baseLen = 122 * anc.scale;
    const baseWid = baseLen * randRange(rng, 0.42, 0.56);
    const hLvl = Math.round(85 + (idx / anchors.length) * 145);

    if (idx > anchors.length * 0.35) {
      aCtx.save();
      aCtx.translate(anc.x + 4, anc.y + 5);
      aCtx.rotate(anc.angle);
      aCtx.fillStyle = 'rgba(10, 26, 5, 0.16)';
      aCtx.beginPath();
      aCtx.ellipse(baseLen * 0.45, 0, baseLen * 0.46, baseWid * 0.36, 0, 0, Math.PI * 2);
      aCtx.fill();
      aCtx.restore();
    }

    paintBotanicalLeaf(
      aCtx,
      hCtx,
      rCtx,
      anc.x,
      anc.y,
      anc.angle,
      baseLen,
      baseWid,
      pal.base,
      pal.tip,
      pal.vein,
      false,
      hLvl
    );

    if (rng() > 0.25) {
      const pal2 = palettes[Math.floor(rng() * palettes.length)];
      paintBotanicalLeaf(
        aCtx,
        hCtx,
        rCtx,
        anc.x + randRange(rng, -12, 12),
        anc.y + randRange(rng, -12, 12),
        anc.angle + randRange(rng, -0.62, 0.62),
        baseLen * randRange(rng, 0.52, 0.78),
        baseWid * randRange(rng, 0.52, 0.8),
        pal2.base,
        pal2.tip,
        pal2.vein,
        false,
        Math.min(248, hLvl + 20)
      );
    }
  });

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.2, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 4. WOODLAND FERN FROND PBR (512x1024 HD alpha-cutout)
 */
function createFernFrondPBR(anisotropy: number): PBRTextureSet {
  const w = 512;
  const h = 1024;
  const rng = createRng(7711);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = w;
  albedoCanvas.height = h;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = w;
  heightCanvas.height = h;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(20,20,20)';
  hCtx.fillRect(0, 0, w, h);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = w;
  roughCanvas.height = h;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(125,125,125)';
  rCtx.fillRect(0, 0, w, h);

  aCtx.strokeStyle = '#33531b';
  aCtx.lineWidth = 7;
  aCtx.lineCap = 'round';
  aCtx.beginPath();
  aCtx.moveTo(w * 0.5, h * 0.99);
  aCtx.lineTo(w * 0.5, h * 0.04);
  aCtx.stroke();

  const pairs = 25;
  for (let i = 0; i < pairs; i++) {
    const t = i / (pairs - 1);
    const y = h * (0.91 - t * 0.84);
    const envelope = Math.sin(Math.pow(t, 0.72) * Math.PI);
    const pinnaLen = w * (0.1 + envelope * 0.37);

    for (let side = -1; side <= 1; side += 2) {
      const ang = side * (Math.PI * 0.42 - t * 0.25) - Math.PI * 0.5;
      const sx = w * 0.5;
      const sy = y + (side === 1 ? -6 : 0);

      const ex = sx + Math.cos(ang) * pinnaLen;
      const ey = sy + Math.sin(ang) * pinnaLen;

      aCtx.strokeStyle = '#3e6a1e';
      aCtx.lineWidth = Math.max(1.5, 3.2 - t * 1.5);
      aCtx.beginPath();
      aCtx.moveTo(sx, sy);
      aCtx.lineTo(ex, ey);
      aCtx.stroke();

      const subCount = Math.max(4, Math.floor(pinnaLen / 12));
      for (let j = 0; j < subCount; j++) {
        const st = (j + 0.3) / subCount;
        const px = sx + (ex - sx) * st;
        const py = sy + (ey - sy) * st;
        const pLen = (14 + (1 - st) * 16) * (0.75 + envelope * 0.4);
        const pWid = pLen * 0.38;

        for (let ps = -1; ps <= 1; ps += 2) {
          const pa = ang + ps * 0.85;
          paintBotanicalLeaf(
            aCtx,
            hCtx,
            rCtx,
            px,
            py,
            pa,
            pLen,
            pWid,
            t > 0.65 ? '#4c881f' : '#2d5c18',
            t > 0.65 ? '#87c930' : '#539024',
            '#73b038',
            false,
            Math.round(130 + randRange(rng, -20, 40))
          );
        }
      }
    }
  }

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.0, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 5. FIBROUS GRASS BLADE PBR (256x1024 HD)
 */
function createGrassBladePBR(anisotropy: number): PBRTextureSet {
  const w = 256;
  const h = 1024;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = w;
  albedoCanvas.height = h;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = w;
  heightCanvas.height = h;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = w;
  roughCanvas.height = h;
  const rCtx = roughCanvas.getContext('2d')!;

  const grad = aCtx.createLinearGradient(0, h, 0, 0);
  grad.addColorStop(0, '#5a6332');
  grad.addColorStop(0.25, '#89a342');
  grad.addColorStop(0.7, '#c2df63');
  grad.addColorStop(1, '#dcf285');
  aCtx.fillStyle = grad;
  aCtx.fillRect(0, 0, w, h);

  for (let x = 0; x < w; x += 8) {
    aCtx.fillStyle = x % 16 === 0 ? 'rgba(255,255,220,0.16)' : 'rgba(20,35,10,0.14)';
    aCtx.fillRect(x, 0, 3, h);

    const hv = 135 + Math.round(Math.sin((x / w) * Math.PI) * 95);
    hCtx.fillStyle = `rgb(${hv},${hv},${hv})`;
    hCtx.fillRect(x, 0, 8, h);
  }

  rCtx.fillStyle = 'rgb(138,138,138)';
  rCtx.fillRect(0, 0, w, h);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 1.9, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 6. KUMAZASA BAMBOO GRASS PBR (1024x1024 HD) from PIGEON/bb (1).zip
 */
function createSasaFoliagePBR(anisotropy: number): PBRTextureSet {
  const size = 1024;
  const rng = createRng(1410);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(30,30,30)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(142,142,142)';
  rCtx.fillRect(0, 0, size, size);

  aCtx.lineCap = 'round';
  interface SasaLeaf {
    x: number;
    y: number;
    a: number;
    len: number;
    layer: number;
  }
  const leaves: SasaLeaf[] = [];

  for (let i = 0; i < 18; i++) {
    const ang = -Math.PI / 2 + randRange(rng, -0.88, 0.88);
    let px = size * 0.5 + randRange(rng, -250, 250);
    let py = size * 0.98;
    let curAng = ang;
    const pts: Array<[number, number]> = [[px, py]];
    const stepLen = randRange(rng, 420, 800) / 8;
    const bend = randRange(rng, -0.04, 0.04);

    for (let s = 0; s < 8; s++) {
      curAng += bend + randRange(rng, -0.06, 0.06);
      px += Math.cos(curAng) * stepLen;
      py += Math.sin(curAng) * stepLen;
      pts.push([px, py]);
    }

    aCtx.strokeStyle = '#3d4d25';
    aCtx.lineWidth = 3.5;
    aCtx.beginPath();
    pts.forEach(([x, y], k) => (k === 0 ? aCtx.moveTo(x, y) : aCtx.lineTo(x, y)));
    aCtx.stroke();

    for (let k = 4; k < pts.length; k++) {
      const [lx, ly] = pts[k];
      const cnt = k === pts.length - 1 ? 4 : 2;
      for (let m = 0; m < cnt; m++) {
        leaves.push({
          x: lx,
          y: ly,
          a: curAng + randRange(rng, -1.35, 1.35),
          len: randRange(rng, 145, 240),
          layer: rng(),
        });
      }
    }
  }

  leaves.sort((a, b) => a.layer - b.layer);
  for (const l of leaves) {
    const hue = randRange(rng, 82, 102);
    const sat = randRange(rng, 44, 62);
    const lt = 22 + l.layer * 21;
    const w = l.len * 0.135;

    const drawShape = (ctx: CanvasRenderingContext2D) => {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(w * 1.4, -l.len * 0.35, 0, -l.len);
      ctx.quadraticCurveTo(-w * 1.4, -l.len * 0.35, 0, 0);
      ctx.closePath();
    };

    aCtx.save();
    aCtx.translate(l.x, l.y);
    aCtx.rotate(l.a + Math.PI / 2);
    drawShape(aCtx);
    aCtx.fillStyle = `hsl(${hue}, ${sat}%, ${lt}%)`;
    aCtx.fill();

    if (rng() < 0.45) {
      aCtx.strokeStyle = 'hsla(52, 34%, 72%, 0.72)';
      aCtx.lineWidth = 2.2;
      aCtx.stroke();
    }

    aCtx.strokeStyle = `hsla(${hue}, ${sat - 10}%, ${lt + 13}%, 0.75)`;
    aCtx.lineWidth = 1.6;
    aCtx.beginPath();
    aCtx.moveTo(0, 0);
    aCtx.lineTo(0, -l.len * 0.94);
    aCtx.stroke();
    aCtx.restore();

    const hv = Math.round(90 + l.layer * 140);
    hCtx.save();
    hCtx.translate(l.x, l.y);
    hCtx.rotate(l.a + Math.PI / 2);
    drawShape(hCtx);
    hCtx.fillStyle = `rgb(${hv},${hv},${hv})`;
    hCtx.fill();
    hCtx.restore();
  }

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.0, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 7. MOSSY FOREST STONE PBR (512x512 seamless)
 */
function createMossyRockPBR(anisotropy: number): PBRTextureSet {
  const size = 512;
  const seed = 610;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n1 = tileableFbm2D(u, v, 8, 4, seed);
      const n2 = tileableFbm2D(u, v, 24, 3, seed + 55);
      const val = n1 * 0.68 + n2 * 0.32;
      const moss = Math.max(0, tileableFbm2D(u, v, 5, 3, seed + 99) - 0.48) * 2.3;

      let r = 56 + val * 58;
      let g = 55 + val * 56;
      let b = 52 + val * 52;

      if (moss > 0) {
        const m = Math.min(0.75, moss);
        r = r * (1 - m) + 52 * m;
        g = g * (1 - m) + 74 * m;
        b = b * (1 - m) + 29 * m;
      }

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      const hv = Math.round(val * 255);
      hImg.data[idx] = hv;
      hImg.data[idx + 1] = hv;
      hImg.data[idx + 2] = hv;
      hImg.data[idx + 3] = 255;

      const rv = Math.round(190 + (1 - val) * 58);
      rImg.data[idx] = rv;
      rImg.data[idx + 1] = rv;
      rImg.data[idx + 2] = rv;
      rImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 3.0, true);
  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 8. ULTRA-HD PHOTOREALISTIC WEATHERED JAPANESE MOUNTAIN ASPHALT PBR (2048x2048 seamless)
 * Fine crushed basalt/granite aggregate chips, hairline fissures & bitumen pores.
 */
function createAsphaltPBR(anisotropy: number): PBRTextureSet {
  const size = 2048;
  const baseSize = 512;
  const rng = createRng(8686);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const baseA = document.createElement('canvas');
  baseA.width = baseSize;
  baseA.height = baseSize;
  const baCtx = baseA.getContext('2d')!;
  const baseH = document.createElement('canvas');
  baseH.width = baseSize;
  baseH.height = baseSize;
  const bhCtx = baseH.getContext('2d')!;
  const baseR = document.createElement('canvas');
  baseR.width = baseSize;
  baseR.height = baseSize;
  const brCtx = baseR.getContext('2d')!;

  const aImg = baCtx.createImageData(baseSize, baseSize);
  const hImg = bhCtx.createImageData(baseSize, baseSize);
  const rImg = brCtx.createImageData(baseSize, baseSize);

  for (let y = 0; y < baseSize; y++) {
    for (let x = 0; x < baseSize; x++) {
      const u = x / baseSize;
      const v = y / baseSize;

      const macro = tileableFbm2D(u, v, 4, 4, 811);
      const med = tileableFbm2D(u, v, 18, 3, 823);
      const grain = tileableFbm2D(u, v, 96, 2, 839);
      const micro = tileableFbm2D(u, v, 210, 2, 853);

      const val = macro * 0.34 + med * 0.24 + grain * 0.25 + micro * 0.17;
      const base = 76 + val * 62;

      const idx = (y * baseSize + x) * 4;
      aImg.data[idx] = Math.min(255, base * 0.985);
      aImg.data[idx + 1] = Math.min(255, base * 1.0);
      aImg.data[idx + 2] = Math.min(255, base * 1.035);
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(70 + grain * 105 + micro * 55);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      const rVal = Math.round(182 + (1 - grain) * 52);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }
  baCtx.putImageData(aImg, 0, 0);
  bhCtx.putImageData(hImg, 0, 0);
  brCtx.putImageData(rImg, 0, 0);
  aCtx.drawImage(baseA, 0, 0, size, size);
  hCtx.drawImage(baseH, 0, 0, size, size);
  rCtx.drawImage(baseR, 0, 0, size, size);

  const stoneTones = [
    '#9fa5aa', '#878d92', '#b5babd', '#52565a', '#3e4246', '#797e82', '#8b877e',
  ];

  for (let i = 0; i < 38000; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const rx = randRange(rng, 1.4, 4.4);
    const ry = randRange(rng, 1.2, 3.8);
    const rot = rng() * Math.PI;
    const col = stoneTones[Math.floor(rng() * stoneTones.length)];
    const isBright = col === '#b5babd' || col === '#9fa5aa';
    const isDark = col === '#3e4246' || col === '#52565a';
    const hShade = isDark
      ? Math.round(randRange(rng, 35, 85))
      : Math.round(randRange(rng, 170, 245));
    const rShade = isBright
      ? Math.round(randRange(rng, 138, 175))
      : Math.round(randRange(rng, 196, 240));

    drawWrapped(size, x, y, 8, (ox, oy) => {
      aCtx.save();
      aCtx.translate(ox, oy);
      aCtx.rotate(rot);
      aCtx.fillStyle = col;
      aCtx.fillRect(-rx * 0.5, -ry * 0.5, rx, ry);
      aCtx.restore();

      hCtx.fillStyle = `rgb(${hShade},${hShade},${hShade})`;
      hCtx.fillRect(ox - rx * 0.5, oy - ry * 0.5, rx, ry);

      rCtx.fillStyle = `rgb(${rShade},${rShade},${rShade})`;
      rCtx.fillRect(ox - rx * 0.5, oy - ry * 0.5, rx, ry);
    });
  }

  for (let c = 0; c < 18; c++) {
    let cx = rng() * size;
    let cy = rng() * size;
    let ang = rng() * Math.PI * 2;
    const segs = Math.floor(randRange(rng, 14, 34));

    for (let s = 0; s < segs; s++) {
      const step = randRange(rng, 14, 38);
      ang += randRange(rng, -0.42, 0.42);
      const nx = cx + Math.cos(ang) * step;
      const ny = cy + Math.sin(ang) * step;
      const w = randRange(rng, 1.2, 2.8);

      drawWrapped(size, cx, cy, 48, (ox, oy) => {
        const dx = nx - cx;
        const dy = ny - cy;
        aCtx.strokeStyle = 'rgba(26, 28, 30, 0.55)';
        aCtx.lineWidth = w;
        aCtx.beginPath();
        aCtx.moveTo(ox, oy);
        aCtx.lineTo(ox + dx, oy + dy);
        aCtx.stroke();

        hCtx.strokeStyle = 'rgb(20, 20, 20)';
        hCtx.lineWidth = w + 1.2;
        hCtx.beginPath();
        hCtx.moveTo(ox, oy);
        hCtx.lineTo(ox + dx, oy + dy);
        hCtx.stroke();

        rCtx.strokeStyle = 'rgb(245, 245, 245)';
        rCtx.lineWidth = w + 1.5;
        rCtx.beginPath();
        rCtx.moveTo(ox, oy);
        rCtx.lineTo(ox + dx, oy + dy);
        rCtx.stroke();
      });

      cx = ((nx % size) + size) % size;
      cy = ((ny % size) + size) % size;
    }
  }

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.5, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

export function createV3SurfaceTextures(maxAniso = 16) {
  const anisotropy = Math.min(16, Math.max(4, maxAniso));
  const forestFloor = createForestFloorPBR(anisotropy);
  const asphalt = createAsphaltPBR(anisotropy);
  const mossyRock = createMossyRockPBR(anisotropy);
  const dryLeafCard = createDryLeafCardPBR(anisotropy);
  const grassBlade = createGrassBladePBR(anisotropy);
  const sasaLeaf = createSasaFoliagePBR(anisotropy);
  const shrubLeaf = createShrubSprigPBR(anisotropy);
  const fernFrond = createFernFrondPBR(anisotropy);

  const textures = new Set<THREE.Texture>([
    forestFloor.map, forestFloor.normalMap, forestFloor.roughnessMap,
    asphalt.map, asphalt.normalMap, asphalt.roughnessMap,
    mossyRock.map, mossyRock.normalMap, mossyRock.roughnessMap,
    dryLeafCard.map, dryLeafCard.normalMap, dryLeafCard.roughnessMap,
    grassBlade.map, grassBlade.normalMap, grassBlade.roughnessMap,
    sasaLeaf.map, sasaLeaf.normalMap, sasaLeaf.roughnessMap,
    shrubLeaf.map, shrubLeaf.normalMap, shrubLeaf.roughnessMap,
    fernFrond.map, fernFrond.normalMap, fernFrond.roughnessMap,
  ]);

  return {
    forestFloor,
    asphalt,
    mossyRock,
    dryLeafCard,
    grassBlade,
    sasaLeaf,
    shrubLeaf,
    fernFrond,
    textures,
    dispose() {
      for (const t of textures) t.dispose();
    },
  };
}

export type V3SurfaceTextureSet = ReturnType<typeof createV3SurfaceTextures>;
