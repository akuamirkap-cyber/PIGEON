import * as THREE from 'three';
import { createRng, randRange } from './noise';

export type BBGrassKind = 'short' | 'meadow' | 'tall';

const V = THREE.Vector3;

class SimpleGeoBuilder {
  pos: number[] = [];
  nor: number[] = [];
  uv: number[] = [];
  ao: number[] = [];
  idx: number[] = [];

  get count() {
    return this.pos.length / 3;
  }

  v(p: THREE.Vector3, n: THREE.Vector3, u: number, w: number, ao = 1) {
    this.pos.push(p.x, p.y, p.z);
    this.nor.push(n.x, n.y, n.z);
    this.uv.push(u, w);
    this.ao.push(ao);
    return this.count - 1;
  }

  build() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.setAttribute('aAO', new THREE.Float32BufferAttribute(this.ao, 1));
    g.setIndex(this.idx);
    g.computeBoundingSphere();
    g.computeBoundingBox();
    return g;
  }
}

function addCard(
  b: SimpleGeoBuilder,
  base: THREE.Vector3,
  dir: THREE.Vector3,
  side: THREE.Vector3,
  h: number,
  w: number,
  droop: number
) {
  const s = b.count;
  const rows = 3;
  for (let i = 0; i < rows; i++) {
    const t = i / (rows - 1);
    const c = base.clone().addScaledVector(dir, h * t);
    c.y -= droop * t * t * h;
    for (let k = 0; k < 2; k++) {
      const p = c.clone().addScaledVector(side, (k - 0.5) * w * (0.75 + 0.25 * t));
      b.v(p, new V(0, 1, 0), k, t, 1);
    }
  }
  for (let i = 0; i < rows - 1; i++) {
    const a = s + i * 2;
    b.idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
  }
}

function randomPerp(rng: () => number, d: THREE.Vector3) {
  const a = new V(randRange(rng, -1, 1), randRange(rng, -1, 1), randRange(rng, -1, 1));
  const res = a.cross(d);
  if (res.lengthSq() < 1e-5) res.set(1, 0, 0).cross(d);
  return res.normalize();
}

function finalizeLeafNormals(
  b: SimpleGeoBuilder,
  center: THREE.Vector3,
  scale: THREE.Vector3,
  radius: number,
  up = 0.45,
  aoMin = 0.35
) {
  const p = new V();
  const n = new V();
  let minY = Infinity;
  let maxY = -Infinity;
  for (let i = 1; i < b.pos.length; i += 3) {
    minY = Math.min(minY, b.pos[i]);
    maxY = Math.max(maxY, b.pos[i]);
  }
  for (let i = 0; i < b.count; i++) {
    p.set(b.pos[i * 3], b.pos[i * 3 + 1], b.pos[i * 3 + 2]);
    n.subVectors(p, center).divide(scale);
    const d = n.length() / radius;
    n.normalize();
    n.y += up;
    n.normalize();
    b.nor[i * 3] = n.x;
    b.nor[i * 3 + 1] = n.y;
    b.nor[i * 3 + 2] = n.z;
    const hy = (p.y - minY) / Math.max(0.01, maxY - minY);
    const t = Math.max(0, Math.min(1, (d - 0.15) / 0.85));
    const sm = t * t * (3 - 2 * t);
    const ao = (aoMin + (1 - aoMin) * sm) * (0.72 + 0.28 * hy);
    b.ao[i] = Math.max(0.15, Math.min(1, ao));
  }
}

/**
 * 1. PIGEON/bb Real 3D Grass Clump ('short' | 'meadow' | 'tall'):
 * Individual tapered, curved 3D blades with vertex-color gradient (earthy base -> sunlit tips),
 * soft normals, and per-vertex ambient occlusion (`aAO`).
 */
export function makeBBGrassClump(seed: number, kind: BBGrassKind): THREE.BufferGeometry {
  const rng = createRng(seed);
  const P =
    kind === 'short'
      ? { n: 30, h: [0.16, 0.42], w: [0.022, 0.036], lean: [0.15, 0.55], rad: 0.24 }
      : kind === 'tall'
        ? { n: 22, h: [0.5, 1.0], w: [0.02, 0.032], lean: [0.45, 0.95], rad: 0.16 }
        : { n: 34, h: [0.22, 0.6], w: [0.016, 0.026], lean: [0.2, 0.7], rad: 0.28 };

  const segs = 3;
  const pos: number[] = [];
  const nor: number[] = [];
  const uv: number[] = [];
  const col: number[] = [];
  const ao: number[] = [];
  const idx: number[] = [];

  const up = new V(0, 1, 0);
  const baseC = new THREE.Color(0.045, 0.075, 0.022);
  const tips = [
    new THREE.Color(0.22, 0.42, 0.075),
    new THREE.Color(0.32, 0.5, 0.095),
    new THREE.Color(0.42, 0.49, 0.12),
    new THREE.Color(0.18, 0.35, 0.065),
  ];
  const dry = new THREE.Color(0.48, 0.36, 0.16);

  const c = new V();
  const tan = new V();
  const n = new V();
  const p = new V();

  for (let b = 0; b < P.n; b++) {
    const ang = randRange(rng, 0, Math.PI * 2);
    const d = Math.sqrt(rng()) * P.rad;
    const base = new V(Math.cos(ang) * d, -0.02, Math.sin(ang) * d);
    const la = ang + randRange(rng, -0.7, 0.7);
    const dirH = new V(Math.cos(la), 0, Math.sin(la));
    const h = randRange(rng, P.h[0], P.h[1]) * (1 - (d / P.rad) * 0.35);
    const lean = randRange(rng, P.lean[0], P.lean[1]);
    const w = randRange(rng, P.w[0], P.w[1]);
    const tw = randRange(rng, -0.6, 0.6);
    const side = new V(-dirH.z, 0, dirH.x)
      .multiplyScalar(Math.cos(tw))
      .addScaledVector(dirH, Math.sin(tw))
      .normalize();

    const tip = tips[Math.floor(rng() * tips.length)].clone();
    if (rng() < 0.15) tip.lerp(dry, randRange(rng, 0.5, 1));
    tip.multiplyScalar(randRange(rng, 0.85, 1.25));

    const start = pos.length / 3;
    for (let s = 0; s <= segs; s++) {
      const t = s / segs;
      const bt = t * t;
      c.copy(base)
        .addScaledVector(dirH, lean * h * bt)
        .addScaledVector(up, h * t * (1 - 0.4 * lean * bt));
      tan
        .copy(dirH)
        .multiplyScalar(2 * lean * h * t)
        .addScaledVector(up, h * (1 - 1.2 * lean * t))
        .normalize();
      n.crossVectors(side, tan).normalize();
      if (n.y < 0) n.negate();
      n.addScaledVector(up, 0.6).normalize();

      const width = s === segs ? w * 0.06 : w * (1 - t * 0.7);
      const cc = baseC.clone().lerp(tip, Math.pow(t, 0.6));
      for (let k = 0; k < 2; k++) {
        p.copy(c).addScaledVector(side, (k - 0.5) * width);
        pos.push(p.x, p.y, p.z);
        nor.push(n.x, n.y, n.z);
        uv.push(k, t);
        col.push(cc.r, cc.g, cc.b);
        ao.push(0.32 + 0.68 * Math.pow(t, 0.8));
      }
    }
    for (let s = 0; s < segs; s++) {
      const a = start + s * 2;
      idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  }

  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setAttribute('aAO', new THREE.Float32BufferAttribute(ao, 1));
  g.setIndex(idx);
  g.computeBoundingSphere();
  return g;
}

/**
 * 2. PIGEON/bb Kumazasa Bamboo Grass (Sasa veitchii) clump geometry
 */
export function makeKumazasaGeometry(seed: number): THREE.BufferGeometry {
  const rng = createRng(seed);
  const b = new SimpleGeoBuilder();
  const n = 18;
  for (let i = 0; i < n; i++) {
    const a = randRange(rng, 0, Math.PI * 2);
    const d = Math.sqrt(rng()) * 0.68;
    const base = new V(Math.cos(a) * d, -0.04, Math.sin(a) * d);
    const cd = new V(Math.cos(a) * randRange(rng, 0.25, 0.7), 1, Math.sin(a) * randRange(rng, 0.25, 0.7)).normalize();
    const h = randRange(rng, 0.85, 1.38);
    addCard(b, base, cd, randomPerp(rng, cd), h, h * 0.92, 0.22);
  }
  finalizeLeafNormals(b, new V(0, 0.12, 0), new V(1, 0.9, 1), 1.1, 0.8, 0.4);
  return b.build();
}

/**
 * Helper: Builds a gently arched multi-segment botanical leaf/frond card geometry
 */
function buildArchedCardIntoArrays(
  positions: number[],
  normals: number[],
  uvs: number[],
  indices: number[],
  vOffset: number,
  origin: THREE.Vector3,
  quaternion: THREE.Quaternion,
  width: number,
  length: number,
  archDrop: number,
  cup: number,
  centerForNormal: THREE.Vector3,
  segY = 4
): number {
  const segX = 2;
  const p = new THREE.Vector3();
  const n = new THREE.Vector3();
  const cDir = new THREE.Vector3();

  for (let iy = 0; iy <= segY; iy++) {
    const v = iy / segY;
    for (let ix = 0; ix <= segX; ix++) {
      const u = ix / segX;
      const xn = u * 2 - 1;

      const lx = xn * width * 0.5;
      const ly = v * length;
      const lz = -archDrop * v * v * length + cup * (1 - xn * xn) * width * 0.14;

      p.set(lx, ly, lz).applyQuaternion(quaternion).add(origin);
      n.set(-xn * 0.25, archDrop * v * 0.65, 1.0).normalize().applyQuaternion(quaternion);
      cDir.copy(p).sub(centerForNormal).add(new THREE.Vector3(0, 0.35, 0)).normalize();
      n.lerp(cDir, 0.58).normalize();

      positions.push(p.x, p.y, p.z);
      normals.push(n.x, n.y, n.z);
      uvs.push(u, v);
    }
  }

  const stride = segX + 1;
  for (let iy = 0; iy < segY; iy++) {
    for (let ix = 0; ix < segX; ix++) {
      const a = vOffset + iy * stride + ix;
      const b = vOffset + (iy + 1) * stride + ix;
      const c = vOffset + (iy + 1) * stride + (ix + 1);
      const d = vOffset + iy * stride + (ix + 1);
      indices.push(a, d, b, b, d, c);
    }
  }
  return vOffset + (segX + 1) * (segY + 1);
}

function mergeSimpleGeometries(geometries: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOffset = 0;

  for (const g of geometries) {
    const pos = g.attributes.position;
    const norm = g.attributes.normal;
    const uv = g.attributes.uv;
    for (let i = 0; i < pos.count; i++) {
      positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      normals.push(norm.getX(i), norm.getY(i), norm.getZ(i));
      uvs.push(uv ? uv.getX(i) : 0, uv ? uv.getY(i) : 0);
    }
    if (g.index) {
      for (let i = 0; i < g.index.count; i++) {
        indices.push(g.index.getX(i) + vOffset);
      }
    } else {
      for (let i = 0; i < pos.count; i++) {
        indices.push(i + vOffset);
      }
    }
    vOffset += pos.count;
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  out.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  out.setIndex(indices);
  return out;
}

/**
 * 3. Realistic Woody Wild Forest Shrub Geometries (from realistic-3d-nature-assets.zip)
 * Separated into stems, main foliage, and bright sunlit shoots for GPU instancing along Haruna.
 */
export function createWildShrubGeometries(seed: number): {
  stems: THREE.BufferGeometry;
  mainLeaves: THREE.BufferGeometry;
  brightLeaves: THREE.BufferGeometry;
} {
  const rng = createRng(seed);

  const stemGeos: THREE.BufferGeometry[] = [];
  const mainPos: number[] = [];
  const mainNorm: number[] = [];
  const mainUv: number[] = [];
  const mainIdx: number[] = [];
  let mainV = 0;

  const brightPos: number[] = [];
  const brightNorm: number[] = [];
  const brightUv: number[] = [];
  const brightIdx: number[] = [];
  let brightV = 0;

  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const shrubCore = new THREE.Vector3(0, 0.32, 0);

  const stemCount = Math.floor(randRange(rng, 6, 10));
  for (let s = 0; s < stemCount; s++) {
    const azim = (s / stemCount) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const spread = randRange(rng, 0.42, 0.92);
    const height = randRange(rng, 0.62, 1.25);

    const p0 = new THREE.Vector3(Math.cos(azim) * 0.04, -0.04, Math.sin(azim) * 0.04);
    const p1 = new THREE.Vector3(Math.cos(azim) * spread * 0.45, height * 0.55, Math.sin(azim) * spread * 0.45);
    const p2 = new THREE.Vector3(
      Math.cos(azim + randRange(rng, -0.25, 0.25)) * spread,
      height,
      Math.sin(azim + randRange(rng, -0.25, 0.25)) * spread
    );

    const curve = new THREE.CatmullRomCurve3([p0, p1, p2]);
    stemGeos.push(new THREE.TubeGeometry(curve, 5, 0.014, 4, false));

    const cardSpots = [0.48, 0.74, 0.98];
    for (let k = 0; k < cardSpots.length; k++) {
      const origin = curve.getPointAt(cardSpots[k]);
      const cardsHere = k === 2 ? 2 : 1;
      for (let c = 0; c < cardsHere; c++) {
        const yaw = azim + randRange(rng, -0.9, 0.9);
        const pitch = randRange(rng, 0.52, 1.18);
        const roll = randRange(rng, -0.45, 0.45);
        e.set(pitch, yaw, roll, 'YXZ');
        q.setFromEuler(e);

        const cw = randRange(rng, 0.46, 0.78);
        const cl = randRange(rng, 0.54, 0.88);
        const useBright = k === 2 && rng() > 0.38;

        if (useBright) {
          brightV = buildArchedCardIntoArrays(
            brightPos,
            brightNorm,
            brightUv,
            brightIdx,
            brightV,
            origin,
            q,
            cw,
            cl,
            randRange(rng, 0.22, 0.42),
            0.4,
            shrubCore,
            3
          );
        } else {
          mainV = buildArchedCardIntoArrays(
            mainPos,
            mainNorm,
            mainUv,
            mainIdx,
            mainV,
            origin,
            q,
            cw,
            cl,
            randRange(rng, 0.22, 0.44),
            0.4,
            shrubCore,
            3
          );
        }
      }
    }
  }

  const stems = mergeSimpleGeometries(stemGeos);
  stemGeos.forEach((g) => g.dispose());
  stems.computeBoundingSphere();

  const mainLeaves = new THREE.BufferGeometry();
  mainLeaves.setAttribute('position', new THREE.Float32BufferAttribute(mainPos, 3));
  mainLeaves.setAttribute('normal', new THREE.Float32BufferAttribute(mainNorm, 3));
  mainLeaves.setAttribute('uv', new THREE.Float32BufferAttribute(mainUv, 2));
  mainLeaves.setIndex(mainIdx);
  mainLeaves.computeBoundingSphere();

  const brightLeaves = new THREE.BufferGeometry();
  brightLeaves.setAttribute('position', new THREE.Float32BufferAttribute(brightPos, 3));
  brightLeaves.setAttribute('normal', new THREE.Float32BufferAttribute(brightNorm, 3));
  brightLeaves.setAttribute('uv', new THREE.Float32BufferAttribute(brightUv, 2));
  brightLeaves.setIndex(brightIdx);
  brightLeaves.computeBoundingSphere();

  return { stems, mainLeaves, brightLeaves };
}

/**
 * 4. Arching Woodland Fern Geometry (from realistic-3d-nature-assets.zip)
 * 16 gracefully curving pinnate fronds radiating from a forest crown.
 */
export function createWoodlandFernGeometry(seed: number): THREE.BufferGeometry {
  const rng = createRng(seed);

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOff = 0;

  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const origin = new THREE.Vector3(0, -0.02, 0);
  const center = new THREE.Vector3(0, 0.15, 0);

  const outerCount = 10;
  const innerCount = 6;

  for (let i = 0; i < outerCount; i++) {
    const yaw = (i / outerCount) * Math.PI * 2 + randRange(rng, -0.22, 0.22);
    const pitch = randRange(rng, 0.72, 1.08);
    e.set(pitch, yaw, randRange(rng, -0.15, 0.15), 'YXZ');
    q.setFromEuler(e);

    const len = randRange(rng, 0.78, 1.12);
    const wid = len * randRange(rng, 0.34, 0.44);
    vOff = buildArchedCardIntoArrays(
      positions,
      normals,
      uvs,
      indices,
      vOff,
      origin,
      q,
      wid,
      len,
      randRange(rng, 0.42, 0.62),
      0.35,
      center,
      5
    );
  }

  for (let i = 0; i < innerCount; i++) {
    const yaw = (i / innerCount) * Math.PI * 2 + 0.3 + randRange(rng, -0.25, 0.25);
    const pitch = randRange(rng, 0.28, 0.58);
    e.set(pitch, yaw, randRange(rng, -0.12, 0.12), 'YXZ');
    q.setFromEuler(e);

    const len = randRange(rng, 0.52, 0.76);
    const wid = len * 0.38;
    vOff = buildArchedCardIntoArrays(
      positions,
      normals,
      uvs,
      indices,
      vOff,
      origin,
      q,
      wid,
      len,
      randRange(rng, 0.26, 0.42),
      0.3,
      center,
      5
    );
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeBoundingSphere();
  return geo;
}

/**
 * 5. Natural Multi-Blade Wild Forest Grass Tuft Geometry (from realistic-3d-nature-assets.zip)
 * 12 curved, gracefully tapering 4-segment blades fanning organically in every clump.
 */
export function createWildGrassTuftGeometry(seed = 1234): THREE.BufferGeometry {
  const rng = createRng(seed);
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOff = 0;

  const bladeCount = 12;
  const segs = 4;

  for (let b = 0; b < bladeCount; b++) {
    const azim = (b / bladeCount) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const rootDist = randRange(rng, 0.0, 0.085);
    const rx = Math.cos(azim) * rootDist;
    const rz = Math.sin(azim) * rootDist;

    const dirAngle = azim + randRange(rng, -0.45, 0.45);
    const dx = Math.cos(dirAngle);
    const dz = Math.sin(dirAngle);
    const px = -dz;
    const pz = dx;

    const bladeH = randRange(rng, 0.24, 0.56);
    const baseW = randRange(rng, 0.013, 0.024);
    const leanOut = randRange(rng, 0.14, 0.42) * bladeH;
    const droopTip = randRange(rng, 0.08, 0.28) * bladeH;

    for (let s = 0; s <= segs; s++) {
      const t = s / segs;
      const w = baseW * Math.pow(1 - t, 0.85);
      const horiz = leanOut * Math.pow(t, 1.55);
      const y = bladeH * t - droopTip * t * t * t;
      const cx = rx + dx * horiz;
      const cz = rz + dz * horiz;

      const nx1 = -px * 0.35 + dx * 0.25;
      const nz1 = -pz * 0.35 + dz * 0.25;
      const nx2 = px * 0.35 + dx * 0.25;
      const nz2 = pz * 0.35 + dz * 0.25;

      if (s < segs) {
        positions.push(cx - px * w, y - 0.015, cz - pz * w);
        positions.push(cx + px * w, y - 0.015, cz + pz * w);
        normals.push(nx1, 0.88, nz1, nx2, 0.88, nz2);
        uvs.push(0, t, 1, t);
      } else {
        positions.push(cx, y - 0.015, cz);
        normals.push(dx * 0.25, 0.92, dz * 0.25);
        uvs.push(0.5, 1.0);
      }
    }

    for (let s = 0; s < segs - 1; s++) {
      const a = vOff + s * 2;
      const b2 = a + 1;
      const c = a + 2;
      const d = a + 3;
      indices.push(a, b2, c, b2, d, c);
    }
    const lastBase = vOff + (segs - 1) * 2;
    const tipIdx = lastBase + 2;
    indices.push(lastBase, lastBase + 1, tipIdx);

    vOff += segs * 2 + 1;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeBoundingSphere();
  return geo;
}
